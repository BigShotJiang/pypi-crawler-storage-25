"""Java AST parser using tree-sitter.

Extracts classes, interfaces, enums, methods, fields, constructors,
and relationships (CALLS, IMPORTS, EXTENDS, IMPLEMENTS, CONTAINS).

Spring Boot awareness:
  - @Autowired/@Inject fields → DATAFLOW edge (DI wiring)
  - @RequestMapping/@GetMapping/etc → endpoint path in signature
  - @Entity/@Table → JPA entity detection
  - @OneToMany/@ManyToOne/etc → DATAFLOW edges between entities
  - @Component/@Service/@Repository/@Controller → Spring bean markers
"""

from __future__ import annotations

from pathlib import Path

from codebrain.parser.base import BaseParser
from codebrain.parser.models import ParsedEdge, ParsedFile, ParsedNode
from codebrain.utils import content_hash

try:
    from tree_sitter_languages import get_parser

    _JAVA_AVAILABLE = True
except ImportError:
    _JAVA_AVAILABLE = False


def _node_text(node, source_bytes: bytes) -> str:
    """Extract text for a tree-sitter node."""
    return source_bytes[node.start_byte:node.end_byte].decode("utf-8", errors="replace")


def _find_child(node, *types: str):
    """Find first child of given type(s)."""
    for child in node.children:
        if child.type in types:
            return child
    return None


def _find_children(node, *types: str):
    """Find all children of given type(s)."""
    return [c for c in node.children if c.type in types]


def _get_modifiers(node, source_bytes: bytes) -> list[str]:
    """Extract modifiers (public, private, static, etc.)."""
    mods_node = _find_child(node, "modifiers")
    if not mods_node:
        return []
    return [_node_text(c, source_bytes) for c in mods_node.children
            if c.type not in ("marker_annotation", "annotation")]


def _get_annotations(node, source_bytes: bytes) -> list[str]:
    """Extract annotation names (@Override, @Deprecated, etc.)."""
    mods_node = _find_child(node, "modifiers")
    if not mods_node:
        return []
    annotations = []
    for c in mods_node.children:
        if c.type in ("marker_annotation", "annotation"):
            name_node = _find_child(c, "identifier", "scoped_identifier")
            if name_node:
                ann_name = _node_text(name_node, source_bytes)
                # For annotations with arguments, include the value
                args_node = _find_child(c, "annotation_argument_list")
                if args_node:
                    ann_text = _node_text(args_node, source_bytes)
                    # Extract simple string value: ("value") or (value = "...")
                    annotations.append(f"{ann_name}{ann_text}")
                else:
                    annotations.append(ann_name)
    return annotations


def _get_annotation_names(node, source_bytes: bytes) -> list[str]:
    """Extract just the annotation names (without arguments)."""
    mods_node = _find_child(node, "modifiers")
    if not mods_node:
        return []
    names = []
    for c in mods_node.children:
        if c.type in ("marker_annotation", "annotation"):
            name_node = _find_child(c, "identifier", "scoped_identifier")
            if name_node:
                names.append(_node_text(name_node, source_bytes))
    return names


# Spring Boot annotation sets
_SPRING_BEAN_ANNOTATIONS = frozenset({
    "Component", "Service", "Repository", "Controller",
    "RestController", "Configuration", "Bean",
})

_SPRING_ENDPOINT_ANNOTATIONS = frozenset({
    "RequestMapping", "GetMapping", "PostMapping",
    "PutMapping", "DeleteMapping", "PatchMapping",
})

_SPRING_DI_ANNOTATIONS = frozenset({
    "Autowired", "Inject", "Resource", "Value",
})

_JPA_ENTITY_ANNOTATIONS = frozenset({
    "Entity", "Table", "MappedSuperclass", "Embeddable",
})

_JPA_RELATIONSHIP_ANNOTATIONS = frozenset({
    "OneToMany", "ManyToOne", "OneToOne", "ManyToMany",
})

_HTTP_METHODS = {
    "GetMapping": "GET",
    "PostMapping": "POST",
    "PutMapping": "PUT",
    "DeleteMapping": "DELETE",
    "PatchMapping": "PATCH",
    "RequestMapping": "HTTP",
}


def _params_signature(params_node, source_bytes: bytes) -> str:
    """Build parameter signature string from formal_parameters node."""
    if not params_node:
        return "()"
    parts = []
    for param in _find_children(params_node, "formal_parameter", "spread_parameter"):
        parts.append(_node_text(param, source_bytes))
    return "(" + ", ".join(parts) + ")"


def _return_type(node, source_bytes: bytes) -> str:
    """Extract return type from a method declaration."""
    for child in node.children:
        if child.type == "identifier":
            break  # stop before method name
        if child.type in ("type_identifier", "generic_type", "void_type",
                          "integral_type", "floating_point_type", "boolean_type",
                          "array_type", "scoped_type_identifier"):
            return _node_text(child, source_bytes)
    return ""


class JavaTreeSitterParser:
    """Core Java parser implementation using tree-sitter."""

    def __init__(self):
        self._parser = get_parser("java")

    def parse(self, path: Path, repo_root: Path) -> ParsedFile:
        rel_path = path.relative_to(repo_root).as_posix()
        raw = path.read_bytes()
        hash_val = content_hash(raw)

        source = raw.decode("utf-8", errors="replace")
        source_bytes = source.encode("utf-8")
        line_count = source.count("\n") + 1

        tree = self._parser.parse(source_bytes)

        nodes: list[ParsedNode] = []
        edges: list[ParsedEdge] = []
        seen_ids: set[str] = set()
        package_name = ""

        # File node
        module_name = rel_path.replace("/", ".").removesuffix(".java")
        file_node_id = f"{rel_path}::__module__"
        nodes.append(ParsedNode(
            id=file_node_id,
            name=module_name.rsplit(".", 1)[-1],
            qualified_name=module_name,
            type="file",
            file_path=rel_path,
            line_start=1,
            line_end=line_count,
            is_exported=True,
        ))
        seen_ids.add(file_node_id)

        def _add_node(name: str, node_type: str, ts_node,
                      parent_id: str | None = None,
                      signature: str = "",
                      decorators: list[str] | None = None,
                      is_exp: bool = False,
                      qualified: str | None = None,
                      docstring: str = "") -> str:
            node_id = f"{rel_path}::{qualified or name}"
            if node_id in seen_ids:
                return node_id
            seen_ids.add(node_id)
            n = ParsedNode(
                id=node_id, name=name,
                qualified_name=qualified or name,
                type=node_type, file_path=rel_path,
                line_start=ts_node.start_point[0] + 1,
                line_end=ts_node.end_point[0] + 1,
                signature=signature, is_exported=is_exp,
                decorators=decorators or [],
                docstring=docstring,
            )
            nodes.append(n)
            container = parent_id or file_node_id
            edges.append(ParsedEdge(
                source=container, target=node_id,
                type="CONTAINS", file_path=rel_path,
                line=ts_node.start_point[0] + 1,
            ))
            # Emit CALLS edges for annotation references (e.g. @Override, @Partially.GwtIncompatible)
            for ann in (decorators or []):
                # Strip arguments: "Override" or "RequestMapping(/api)" -> "Override", "RequestMapping"
                ann_name = ann.split("(")[0].strip()
                if ann_name:
                    edges.append(ParsedEdge(
                        source=node_id, target=ann_name,
                        type="CALLS", file_path=rel_path,
                        line=ts_node.start_point[0] + 1,
                    ))
            return node_id

        def _get_javadoc(ts_node) -> str:
            """Extract Javadoc comment before a node."""
            # Look for block_comment sibling before this node
            parent = ts_node.parent
            if not parent:
                return ""
            idx = None
            for i, child in enumerate(parent.children):
                if child.id == ts_node.id:
                    idx = i
                    break
            if idx is None:
                return ""
            for i in range(idx - 1, -1, -1):
                sib = parent.children[i]
                if sib.type == "block_comment":
                    text = _node_text(sib, source_bytes)
                    if text.startswith("/**"):
                        # Extract first sentence
                        lines = text.strip("/* \n\r\t").split("\n")
                        cleaned = []
                        for line in lines:
                            line = line.strip().lstrip("* ").strip()
                            if line:
                                cleaned.append(line)
                        return " ".join(cleaned)[:4000] if cleaned else ""
                elif sib.type in ("line_comment",):
                    continue
                else:
                    break
            return ""

        def _walk_calls(node, caller_id: str, seen_calls: set[str]):
            """Recursively extract method calls from a block."""
            if node.type == "method_invocation":
                # Java method_invocation structure:
                #   object.method(args) -> [identifier("object"), ".", identifier("method"), argument_list]
                #   method(args) -> [identifier("method"), argument_list]
                # Find all identifiers (excluding those inside argument_list)
                identifiers = []
                for child in node.children:
                    if child.type == "argument_list":
                        break
                    if child.type == "identifier":
                        identifiers.append(_node_text(child, source_bytes))
                    elif child.type == "field_access":
                        identifiers.append(_node_text(child, source_bytes))

                if identifiers:
                    # Last identifier is the method name
                    method_name = identifiers[-1]
                    if len(identifiers) > 1:
                        # obj.method or chain.obj.method
                        full_name = ".".join(identifiers)
                    else:
                        full_name = method_name

                    if full_name not in _CALL_SKIP and full_name not in seen_calls:
                        seen_calls.add(full_name)
                        edges.append(ParsedEdge(
                            source=caller_id, target=full_name,
                            type="CALLS", file_path=rel_path,
                            line=node.start_point[0] + 1,
                        ))

            elif node.type == "object_creation_expression":
                # new ClassName(...)
                type_node = _find_child(node, "type_identifier", "scoped_type_identifier",
                                        "generic_type")
                if type_node:
                    type_name = _node_text(type_node, source_bytes)
                    # Strip generics for cleaner name
                    if "<" in type_name:
                        type_name = type_name[:type_name.index("<")]
                    if type_name not in seen_calls:
                        seen_calls.add(type_name)
                        edges.append(ParsedEdge(
                            source=caller_id, target=type_name,
                            type="CALLS", file_path=rel_path,
                            line=node.start_point[0] + 1,
                        ))

            elif node.type == "field_access":
                # this.field or obj.field — track as CALLS so fields
                # don't appear as dead code.  Structure:
                #   field_access -> [object, ".", identifier]
                field_id = _find_child(node, "identifier")
                if field_id:
                    fname = _node_text(field_id, source_bytes)
                    # Get the object part for qualified name
                    obj_parts = []
                    for child in node.children:
                        if child == field_id:
                            break
                        if child.type in ("identifier", "this"):
                            obj_parts.append(_node_text(child, source_bytes))
                    if obj_parts:
                        qualified = f"{'.'.join(obj_parts)}.{fname}"
                    else:
                        qualified = fname
                    if qualified not in seen_calls:
                        seen_calls.add(qualified)
                        edges.append(ParsedEdge(
                            source=caller_id, target=qualified,
                            type="CALLS", file_path=rel_path,
                            line=node.start_point[0] + 1,
                        ))

            for child in node.children:
                _walk_calls(child, caller_id, seen_calls)

        def _extract_calls(body_node, caller_id: str):
            if body_node is None:
                return
            seen_calls: set[str] = set()
            _walk_calls(body_node, caller_id, seen_calls)

        def _process_method(ts_node, parent_id: str, class_name: str):
            """Process method_declaration."""
            name_node = _find_child(ts_node, "identifier")
            if not name_node:
                return
            name = _node_text(name_node, source_bytes)
            mods = _get_modifiers(ts_node, source_bytes)
            annotations = _get_annotations(ts_node, source_bytes)
            is_exp = "public" in mods
            params = _find_child(ts_node, "formal_parameters")
            sig = _params_signature(params, source_bytes)
            ret = _return_type(ts_node, source_bytes)
            if ret:
                sig = f"{ret} {name}{sig}"
            else:
                sig = f"{name}{sig}"
            docstring = _get_javadoc(ts_node)
            qname = f"{class_name}.{name}"
            mid = _add_node(name, "method", ts_node, parent_id,
                            signature=sig, decorators=annotations,
                            is_exp=is_exp, qualified=qname, docstring=docstring)
            body = _find_child(ts_node, "block")
            _extract_calls(body, mid)

        def _process_constructor(ts_node, parent_id: str, class_name: str):
            """Process constructor_declaration."""
            name_node = _find_child(ts_node, "identifier")
            name = _node_text(name_node, source_bytes) if name_node else class_name
            mods = _get_modifiers(ts_node, source_bytes)
            annotations = _get_annotations(ts_node, source_bytes)
            is_exp = "public" in mods
            params = _find_child(ts_node, "formal_parameters")
            sig = f"{name}{_params_signature(params, source_bytes)}"
            qname = f"{class_name}.__init__"
            mid = _add_node("__init__", "method", ts_node, parent_id,
                            signature=sig, decorators=annotations,
                            is_exp=is_exp, qualified=qname)
            body = _find_child(ts_node, "constructor_body")
            _extract_calls(body, mid)

        def _process_field(ts_node, parent_id: str, class_name: str):
            """Process field_declaration."""
            mods = _get_modifiers(ts_node, source_bytes)
            annotations = _get_annotations(ts_node, source_bytes)
            is_exp = "public" in mods
            for declarator in _find_children(ts_node, "variable_declarator"):
                name_node = _find_child(declarator, "identifier")
                if not name_node:
                    continue
                name = _node_text(name_node, source_bytes)
                qname = f"{class_name}.{name}"
                fid = _add_node(name, "variable", ts_node, parent_id,
                                decorators=annotations, is_exp=is_exp, qualified=qname)
                # Extract calls from field initializer (e.g. new Foo(), SomeClass.method())
                _extract_calls(declarator, parent_id)

        def _process_class(ts_node, parent_id: str | None = None,
                           outer_class: str | None = None):
            """Process class_declaration."""
            name_node = _find_child(ts_node, "identifier")
            if not name_node:
                return
            name = _node_text(name_node, source_bytes)
            mods = _get_modifiers(ts_node, source_bytes)
            annotations = _get_annotations(ts_node, source_bytes)
            is_exp = "public" in mods
            docstring = _get_javadoc(ts_node)
            qname = f"{outer_class}.{name}" if outer_class else name
            class_id = _add_node(name, "class", ts_node, parent_id,
                                 decorators=annotations, is_exp=is_exp,
                                 qualified=qname, docstring=docstring)

            # Extends
            superclass = _find_child(ts_node, "superclass")
            if superclass:
                for child in superclass.children:
                    if child.type in ("type_identifier", "scoped_type_identifier", "generic_type"):
                        base = _node_text(child, source_bytes)
                        if "<" in base:
                            base = base[:base.index("<")]
                        edges.append(ParsedEdge(
                            source=class_id, target=base,
                            type="EXTENDS", file_path=rel_path,
                            line=child.start_point[0] + 1,
                        ))
                        break

            # Implements
            ifaces = _find_child(ts_node, "super_interfaces")
            if ifaces:
                type_list = _find_child(ifaces, "type_list")
                target = type_list if type_list else ifaces
                for child in target.children:
                    if child.type in ("type_identifier", "scoped_type_identifier", "generic_type"):
                        iface = _node_text(child, source_bytes)
                        if "<" in iface:
                            iface = iface[:iface.index("<")]
                        edges.append(ParsedEdge(
                            source=class_id, target=iface,
                            type="IMPLEMENTS", file_path=rel_path,
                            line=child.start_point[0] + 1,
                        ))

            # Body
            body = _find_child(ts_node, "class_body")
            if body:
                _process_class_body(body, class_id, name)

        def _process_interface(ts_node, parent_id: str | None = None,
                               outer_class: str | None = None):
            """Process interface_declaration."""
            name_node = _find_child(ts_node, "identifier")
            if not name_node:
                return
            name = _node_text(name_node, source_bytes)
            mods = _get_modifiers(ts_node, source_bytes)
            annotations = _get_annotations(ts_node, source_bytes)
            annotations.append("interface")
            is_exp = "public" in mods
            docstring = _get_javadoc(ts_node)
            qname = f"{outer_class}.{name}" if outer_class else name
            iface_id = _add_node(name, "class", ts_node, parent_id,
                                 decorators=annotations, is_exp=is_exp,
                                 qualified=qname, docstring=docstring)

            # Extends (interfaces can extend other interfaces)
            extends_node = _find_child(ts_node, "extends_interfaces")
            if extends_node:
                type_list = _find_child(extends_node, "type_list")
                target = type_list if type_list else extends_node
                for child in target.children:
                    if child.type in ("type_identifier", "scoped_type_identifier"):
                        base = _node_text(child, source_bytes)
                        edges.append(ParsedEdge(
                            source=iface_id, target=base,
                            type="EXTENDS", file_path=rel_path,
                            line=child.start_point[0] + 1,
                        ))

            # Methods in interface body
            body = _find_child(ts_node, "interface_body")
            if body:
                for member in body.children:
                    if member.type == "method_declaration":
                        _process_method(member, iface_id, name)
                    elif member.type == "constant_declaration":
                        _process_field(member, iface_id, name)

        def _process_enum(ts_node, parent_id: str | None = None,
                          outer_class: str | None = None):
            """Process enum_declaration."""
            name_node = _find_child(ts_node, "identifier")
            if not name_node:
                return
            name = _node_text(name_node, source_bytes)
            mods = _get_modifiers(ts_node, source_bytes)
            annotations = _get_annotations(ts_node, source_bytes)
            annotations.append("enum")
            is_exp = "public" in mods
            docstring = _get_javadoc(ts_node)
            qname = f"{outer_class}.{name}" if outer_class else name
            enum_id = _add_node(name, "class", ts_node, parent_id,
                                decorators=annotations, is_exp=is_exp,
                                qualified=qname, docstring=docstring)

            # Implements (enums can implement interfaces)
            ifaces = _find_child(ts_node, "super_interfaces")
            if ifaces:
                type_list = _find_child(ifaces, "type_list")
                target = type_list if type_list else ifaces
                for child in target.children:
                    if child.type in ("type_identifier", "scoped_type_identifier", "generic_type"):
                        iface = _node_text(child, source_bytes)
                        if "<" in iface:
                            iface = iface[:iface.index("<")]
                        edges.append(ParsedEdge(
                            source=enum_id, target=iface,
                            type="IMPLEMENTS", file_path=rel_path,
                            line=child.start_point[0] + 1,
                        ))

            # Enum body may contain constants and methods
            body = _find_child(ts_node, "enum_body")
            if body:
                for member in body.children:
                    if member.type == "enum_constant":
                        const_name = _find_child(member, "identifier")
                        if const_name:
                            cname = _node_text(const_name, source_bytes)
                            _add_node(cname, "variable", member, enum_id,
                                      qualified=f"{name}.{cname}", is_exp=True)
                    elif member.type == "enum_body_declarations":
                        # Methods/fields after the constants
                        _process_class_body(member, enum_id, name)

        def _process_class_body(body_node, parent_id: str, class_name: str):
            """Process members of a class/enum body."""
            for member in body_node.children:
                if member.type == "method_declaration":
                    _process_method(member, parent_id, class_name)
                elif member.type == "constructor_declaration":
                    _process_constructor(member, parent_id, class_name)
                elif member.type == "field_declaration":
                    _process_field(member, parent_id, class_name)
                elif member.type == "class_declaration":
                    _process_class(member, parent_id, outer_class=class_name)
                elif member.type == "interface_declaration":
                    _process_interface(member, parent_id, outer_class=class_name)
                elif member.type == "enum_declaration":
                    _process_enum(member, parent_id, outer_class=class_name)
                elif member.type == "static_initializer":
                    _extract_calls(member, parent_id)

        def _process_import(ts_node):
            """Process import_declaration."""
            scoped = _find_child(ts_node, "scoped_identifier")
            if not scoped:
                return
            import_path = _node_text(scoped, source_bytes)
            # Check for wildcard: import java.util.*
            asterisk = _find_child(ts_node, "asterisk")
            if asterisk:
                import_path += ".*"
            edges.append(ParsedEdge(
                source=file_node_id, target=import_path,
                type="IMPORTS", file_path=rel_path,
                line=ts_node.start_point[0] + 1,
            ))

        # Walk top-level declarations
        for child in tree.root_node.children:
            if child.type == "package_declaration":
                scoped = _find_child(child, "scoped_identifier")
                if scoped:
                    package_name = _node_text(scoped, source_bytes)
            elif child.type == "import_declaration":
                _process_import(child)
            elif child.type == "class_declaration":
                _process_class(child)
            elif child.type == "interface_declaration":
                _process_interface(child)
            elif child.type == "enum_declaration":
                _process_enum(child)

        # Store package as docstring on file node if present
        if package_name:
            nodes[0].docstring = f"package {package_name}"

        # --- Spring Boot / JPA post-processing ---
        _spring_postprocess(nodes, edges, rel_path, source_bytes, tree)

        return ParsedFile(
            path=rel_path,
            content_hash=hash_val,
            nodes=nodes,
            edges=edges,
            line_count=line_count,
        )


def _spring_postprocess(
    nodes: list[ParsedNode],
    edges: list[ParsedEdge],
    rel_path: str,
    source_bytes: bytes,
    tree,
) -> None:
    """Post-process parsed nodes/edges to add Spring Boot and JPA awareness.

    Emits:
    - DATAFLOW edges for @Autowired/@Inject field injection
    - DATAFLOW edges for JPA relationship annotations
    - Endpoint path info in method signatures for @GetMapping etc.
    - Spring bean metadata in class decorators
    """
    # Build lookup: node name → node for quick access
    node_by_qname: dict[str, ParsedNode] = {}
    class_nodes: list[ParsedNode] = []
    for n in nodes:
        node_by_qname[n.qualified_name] = n
        if n.type == "class":
            class_nodes.append(n)

    # Find parent class for fields/methods
    # edges with CONTAINS tell us parent → child
    parent_of: dict[str, str] = {}  # child_id → parent_id
    for e in edges:
        if e.type == "CONTAINS":
            parent_of[e.target] = e.source

    for n in nodes:
        ann_names = {_ann_base_name(a) for a in n.decorators}

        # --- Spring bean detection ---
        if n.type == "class" and ann_names & _SPRING_BEAN_ANNOTATIONS:
            # Already in decorators, but ensure the bean type is visible
            pass

        # --- @Autowired / @Inject fields → DATAFLOW edge ---
        if n.type == "variable" and ann_names & _SPRING_DI_ANNOTATIONS:
            # The field type is the injected dependency.
            # Extract type from the field's decorators or by scanning source.
            parent_id = parent_of.get(n.id, "")
            if parent_id:
                # Find the field type by looking at the variable's qualified_name
                # The type should be extractable from decorators or we use the name convention
                field_type = _extract_field_type_from_source(
                    source_bytes, n.line_start,
                )
                if field_type:
                    edges.append(ParsedEdge(
                        source=parent_id, target=field_type,
                        type="DATAFLOW", file_path=rel_path,
                        line=n.line_start,
                    ))

        # --- @RequestMapping / @GetMapping etc on methods ---
        if n.type == "method" and ann_names & _SPRING_ENDPOINT_ANNOTATIONS:
            # Extract HTTP method and path from annotation
            for ann in n.decorators:
                base = _ann_base_name(ann)
                if base in _SPRING_ENDPOINT_ANNOTATIONS:
                    http_method = _HTTP_METHODS.get(base, "HTTP")
                    path = _extract_ann_string_value(ann)
                    endpoint = f"[{http_method}]"
                    if path:
                        endpoint = f"[{http_method} {path}]"
                    # Prepend endpoint info to signature
                    if endpoint not in n.signature:
                        n.signature = f"{endpoint} {n.signature}"

        # --- Class-level @RequestMapping for base path ---
        if n.type == "class" and ann_names & _SPRING_ENDPOINT_ANNOTATIONS:
            for ann in n.decorators:
                base = _ann_base_name(ann)
                if base in _SPRING_ENDPOINT_ANNOTATIONS:
                    path = _extract_ann_string_value(ann)
                    if path and path not in n.docstring:
                        prefix = f"[API base: {path}]"
                        n.docstring = f"{prefix} {n.docstring}" if n.docstring else prefix

        # --- JPA entity detection ---
        if n.type == "class" and ann_names & _JPA_ENTITY_ANNOTATIONS:
            # Already marked via decorators. Extract table name if present.
            for ann in n.decorators:
                if _ann_base_name(ann) == "Table":
                    table = _extract_ann_named_value(ann, "name")
                    if table and table not in n.docstring:
                        prefix = f"[table: {table}]"
                        n.docstring = f"{prefix} {n.docstring}" if n.docstring else prefix

        # --- JPA relationship fields → DATAFLOW edges ---
        if n.type == "variable" and ann_names & _JPA_RELATIONSHIP_ANNOTATIONS:
            parent_id = parent_of.get(n.id, "")
            if parent_id:
                # The target entity type — extract from field type
                target_type = _extract_field_type_from_source(
                    source_bytes, n.line_start,
                )
                if target_type:
                    # Strip collection wrappers: List<User> → User, Set<Order> → Order
                    inner = _strip_generic_wrapper(target_type)
                    edges.append(ParsedEdge(
                        source=parent_id, target=inner,
                        type="DATAFLOW", file_path=rel_path,
                        line=n.line_start,
                    ))


def _ann_base_name(annotation: str) -> str:
    """Extract base name from annotation string: 'GetMapping("/users")' → 'GetMapping'."""
    paren = annotation.find("(")
    return annotation[:paren] if paren != -1 else annotation


def _extract_ann_string_value(annotation: str) -> str:
    """Extract first string value from annotation: 'GetMapping("/users")' → '/users'."""
    import re
    m = re.search(r'"([^"]*)"', annotation)
    return m.group(1) if m else ""


def _extract_ann_named_value(annotation: str, key: str) -> str:
    """Extract named value: 'Table(name = "users")' → 'users'."""
    import re
    m = re.search(rf'{key}\s*=\s*"([^"]*)"', annotation)
    return m.group(1) if m else ""


def _extract_field_type_from_source(source_bytes: bytes, line_num: int) -> str:
    """Extract the type of a field declaration from source at the given line.

    The line_num may point to the annotation line (e.g. @Autowired) rather
    than the actual field declaration, so we scan forward to find the line
    with the type declaration.
    """
    import re
    source = source_bytes.decode("utf-8", errors="replace")
    lines = source.split("\n")
    if line_num < 1 or line_num > len(lines):
        return ""

    # Scan from line_num forward (field_declaration may start at annotation)
    for i in range(line_num - 1, min(line_num + 5, len(lines))):
        line = lines[i].strip()
        # Skip pure annotation lines and blank lines
        if not line or re.match(r"^@\w+", line) and ";" not in line:
            continue
        # Remove inline annotations
        line = re.sub(r"@\w+(\([^)]*\))?\s*", "", line)
        # Remove modifiers
        line = re.sub(r"\b(private|protected|public|static|final|transient|volatile)\b\s*", "", line)
        line = line.strip()
        # First token is the type
        m = re.match(r"([\w<>,.\[\]?]+)\s+\w+", line)
        if m:
            return m.group(1)
    return ""


def _strip_generic_wrapper(type_name: str) -> str:
    """Strip collection wrapper: 'List<User>' → 'User', 'Set<Order>' → 'Order'."""
    import re
    m = re.match(r"(?:List|Set|Collection|Iterable|Optional)<(\w+)>", type_name)
    return m.group(1) if m else type_name


# Calls to skip (Java noise: standard library, logging, etc.)
_CALL_SKIP = frozenset({
    "if", "for", "while", "switch", "catch", "return", "throw",
    "new", "instanceof", "import", "class", "interface", "enum",
    "true", "false", "null", "this", "super",
    "System.out.println", "System.out.print", "System.err.println",
    "System.out.printf", "System.err.printf",
    "Objects.requireNonNull", "Objects.equals", "Objects.hash",
    "String.valueOf", "String.format",
    "Integer.parseInt", "Integer.valueOf",
    "Long.parseLong", "Long.valueOf",
    "Double.parseDouble", "Double.valueOf",
    "Boolean.parseBoolean", "Boolean.valueOf",
    "Math.abs", "Math.max", "Math.min", "Math.round",
    "Arrays.asList", "Arrays.sort", "Arrays.stream",
    "Collections.unmodifiableList", "Collections.singletonList",
    "Collections.emptyList", "Collections.emptyMap",
    "Optional.of", "Optional.ofNullable", "Optional.empty",
})


class JavaParser(BaseParser):
    """AST-based Java parser using tree-sitter.

    Requires tree-sitter-languages to be installed.
    """

    _JAVA_EXTENSIONS = frozenset({".java"})

    def __init__(self):
        if _JAVA_AVAILABLE:
            self._impl = JavaTreeSitterParser()
        else:
            self._impl = None

    def extensions(self) -> frozenset[str]:
        return self._JAVA_EXTENSIONS

    def parse(self, path: Path, repo_root: Path) -> ParsedFile:
        if self._impl is None:
            raise ImportError(
                "Java parsing requires tree-sitter-languages. "
                "Install with: pip install tree-sitter-languages"
            )
        return self._impl.parse(path, repo_root)
