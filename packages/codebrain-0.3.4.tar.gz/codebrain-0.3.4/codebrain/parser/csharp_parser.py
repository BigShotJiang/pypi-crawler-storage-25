"""C# AST parser using tree-sitter.

Extracts namespaces, classes, structs, interfaces, enums, methods,
constructors, properties, fields, events, delegates,
and relationships (CALLS, IMPORTS, EXTENDS, IMPLEMENTS, CONTAINS).

ASP.NET awareness:
  - [HttpGet], [HttpPost], [Route], [Authorize], [ApiController] attributes
  - XML doc comments (/// <summary>)
  - async methods, static members, partial classes
  - File-scoped namespaces (namespace X;)
"""

from __future__ import annotations

from pathlib import Path

from codebrain.parser.base import BaseParser
from codebrain.parser.models import ParsedEdge, ParsedFile, ParsedNode
from codebrain.utils import content_hash

try:
    from tree_sitter_languages import get_parser

    _CSHARP_AVAILABLE = True
except ImportError:
    _CSHARP_AVAILABLE = False


def _node_text(node, source_bytes: bytes) -> str:
    """Extract text for a tree-sitter node."""
    return source_bytes[node.start_byte:node.end_byte].decode("utf-8", errors="replace")


def _find_child(node, *types: str):
    """Find first child of given type(s)."""
    for child in node.children:
        if child.type in types:
            return child
    return None


def _find_children(node, *types: str):
    """Find all children of given type(s)."""
    return [c for c in node.children if c.type in types]


def _get_modifiers(node, source_bytes: bytes) -> list[str]:
    """Extract modifiers (public, private, static, etc.)."""
    mods = []
    for child in node.children:
        if child.type == "modifier":
            mods.append(_node_text(child, source_bytes))
        elif child.type in ("attribute_list",):
            continue
        elif child.type in ("identifier", "predefined_type", "generic_name",
                            "void_keyword", "class_declaration", "struct_declaration",
                            "interface_declaration", "enum_declaration",
                            "method_declaration", "property_declaration",
                            "field_declaration", "event_declaration",
                            "delegate_declaration", "constructor_declaration",
                            "block", "declaration_list", "base_list",
                            "parameter_list", "type_parameter_list",
                            "accessor_list", "variable_declaration",
                            "nullable_type", "array_type", "qualified_name",
                            "implicit_type", "tuple_type", "arrow_expression_clause",
                            "argument_list", "constructor_initializer",
                            "explicit_interface_specifier"):
            break
    return mods


def _get_attributes(node, source_bytes: bytes) -> list[str]:
    """Extract attribute names ([Serializable], [HttpGet("/path")], etc.)."""
    attrs = []
    for child in node.children:
        if child.type == "attribute_list":
            for attr in child.children:
                if attr.type == "attribute":
                    name_node = _find_child(attr, "identifier", "qualified_name")
                    if name_node:
                        attr_name = _node_text(name_node, source_bytes)
                        # Check for arguments
                        args_node = _find_child(attr, "attribute_argument_list")
                        if args_node:
                            args_text = _node_text(args_node, source_bytes)
                            attrs.append(f"{attr_name}{args_text}")
                        else:
                            attrs.append(attr_name)
    return attrs


def _get_attribute_names(node, source_bytes: bytes) -> list[str]:
    """Extract just attribute names without arguments."""
    attrs = _get_attributes(node, source_bytes)
    result = []
    for a in attrs:
        paren = a.find("(")
        result.append(a[:paren] if paren != -1 else a)
    return result


def _params_signature(params_node, source_bytes: bytes) -> str:
    """Build parameter signature string from parameter_list node."""
    if not params_node:
        return "()"
    parts = []
    for param in _find_children(params_node, "parameter"):
        parts.append(_node_text(param, source_bytes))
    return "(" + ", ".join(parts) + ")"


def _return_type(node, source_bytes: bytes) -> str:
    """Extract return type from a method declaration.

    In C# tree-sitter grammar, the return type can be:
    - predefined_type (int, string, void)
    - generic_name (List<T>, Task<T>)
    - identifier (User -- custom type)
    - nullable_type (int?)
    - array_type (int[])
    - void_keyword
    - qualified_name (System.String)
    - tuple_type ((int, string))

    When return type is an identifier, the method name is the SECOND identifier.
    """
    # Collect type nodes that appear before the parameter_list
    param_list = _find_child(node, "parameter_list")
    identifiers_before_params = []

    for child in node.children:
        if child.type == "parameter_list":
            break
        if child.type in ("predefined_type", "generic_name", "void_keyword",
                          "nullable_type", "array_type", "qualified_name",
                          "implicit_type", "tuple_type"):
            return _node_text(child, source_bytes)
        if child.type == "identifier":
            identifiers_before_params.append(child)

    # If there are 2+ identifiers before params, first is the return type
    if len(identifiers_before_params) >= 2:
        return _node_text(identifiers_before_params[0], source_bytes)
    return ""


# Calls to skip (C# noise: standard library, logging, etc.)
_CALL_SKIP = frozenset({
    "if", "for", "while", "switch", "catch", "return", "throw",
    "new", "is", "as", "lock", "using", "foreach",
    "true", "false", "null", "this", "base",
    "Console.WriteLine", "Console.Write", "Console.ReadLine",
    "Debug.WriteLine", "Trace.WriteLine",
    "string.Format", "string.IsNullOrEmpty", "string.IsNullOrWhiteSpace",
    "Convert.ToInt32", "Convert.ToString",
    "Math.Abs", "Math.Max", "Math.Min",
    "Object.Equals", "Object.GetHashCode", "Object.ToString",
    "Enumerable.Range", "Enumerable.Empty",
    "Task.Run", "Task.FromResult", "Task.WhenAll", "Task.WhenAny",
    "throw", "nameof", "typeof", "sizeof", "default",
})


class CSharpTreeSitterParser:
    """Core C# parser implementation using tree-sitter."""

    def __init__(self):
        self._parser = get_parser("c_sharp")

    def parse(self, path: Path, repo_root: Path) -> ParsedFile:
        rel_path = path.relative_to(repo_root).as_posix()
        raw = path.read_bytes()
        hash_val = content_hash(raw)

        source = raw.decode("utf-8", errors="replace")
        source_bytes = source.encode("utf-8")
        line_count = source.count("\n") + 1

        tree = self._parser.parse(source_bytes)

        nodes: list[ParsedNode] = []
        edges: list[ParsedEdge] = []
        seen_ids: set[str] = set()
        namespace_name = ""

        # File node
        module_name = rel_path.replace("/", ".").removesuffix(".cs")
        file_node_id = f"{rel_path}::__module__"
        nodes.append(ParsedNode(
            id=file_node_id,
            name=module_name.rsplit(".", 1)[-1],
            qualified_name=module_name,
            type="file",
            file_path=rel_path,
            line_start=1,
            line_end=line_count,
            is_exported=True,
        ))
        seen_ids.add(file_node_id)

        def _add_node(name: str, node_type: str, ts_node,
                      parent_id: str | None = None,
                      signature: str = "",
                      decorators: list[str] | None = None,
                      is_exp: bool = False,
                      qualified: str | None = None,
                      docstring: str = "") -> str:
            node_id = f"{rel_path}::{qualified or name}"
            if node_id in seen_ids:
                return node_id
            seen_ids.add(node_id)
            n = ParsedNode(
                id=node_id, name=name,
                qualified_name=qualified or name,
                type=node_type, file_path=rel_path,
                line_start=ts_node.start_point[0] + 1,
                line_end=ts_node.end_point[0] + 1,
                signature=signature, is_exported=is_exp,
                decorators=decorators or [],
                docstring=docstring,
            )
            nodes.append(n)
            container = parent_id or file_node_id
            edges.append(ParsedEdge(
                source=container, target=node_id,
                type="CONTAINS", file_path=rel_path,
                line=ts_node.start_point[0] + 1,
            ))
            return node_id

        def _get_xml_doc(ts_node) -> str:
            """Extract /// XML doc comment before a node."""
            import re
            parent = ts_node.parent
            if not parent:
                return ""
            idx = None
            for i, child in enumerate(parent.children):
                if child.id == ts_node.id:
                    idx = i
                    break
            if idx is None:
                return ""
            # Collect consecutive comment lines before this node
            doc_lines = []
            for i in range(idx - 1, -1, -1):
                sib = parent.children[i]
                if sib.type == "comment":
                    text = _node_text(sib, source_bytes).strip()
                    if text.startswith("///"):
                        doc_lines.insert(0, text[3:].strip())
                    else:
                        break
                else:
                    break
            if not doc_lines:
                return ""
            full_doc = " ".join(doc_lines)
            # Try to extract <summary> content
            m = re.search(r"<summary>\s*(.*?)\s*</summary>", full_doc, re.DOTALL)
            if m:
                return m.group(1).strip()[:4000]
            # Fallback: just return the cleaned text
            # Strip any remaining XML tags
            cleaned = re.sub(r"<[^>]+>", "", full_doc).strip()
            return cleaned[:4000] if cleaned else ""

        def _walk_calls(node, caller_id: str, seen_calls: set[str]):
            """Recursively extract method calls from a block."""
            if node.type == "invocation_expression":
                # C# invocation_expression: expr(args)
                # The first child is the expression being invoked
                expr = node.children[0] if node.children else None
                if expr:
                    if expr.type == "member_access_expression":
                        # obj.Method(args)
                        parts = []
                        for child in expr.children:
                            if child.type == "identifier" or child.type == "generic_name":
                                text = _node_text(child, source_bytes)
                                if "<" in text:
                                    text = text[:text.index("<")]
                                parts.append(text)
                            elif child.type == "predefined_type":
                                parts.append(_node_text(child, source_bytes))
                        if parts:
                            method_name = parts[-1]
                            full_name = ".".join(parts)
                            if full_name not in _CALL_SKIP and full_name not in seen_calls:
                                seen_calls.add(full_name)
                                edges.append(ParsedEdge(
                                    source=caller_id, target=full_name,
                                    type="CALLS", file_path=rel_path,
                                    line=node.start_point[0] + 1,
                                ))
                            if method_name != full_name and method_name not in _CALL_SKIP and method_name not in seen_calls:
                                seen_calls.add(method_name)
                                edges.append(ParsedEdge(
                                    source=caller_id, target=method_name,
                                    type="CALLS", file_path=rel_path,
                                    line=node.start_point[0] + 1,
                                ))
                    elif expr.type == "identifier":
                        name = _node_text(expr, source_bytes)
                        if name not in _CALL_SKIP and name not in seen_calls:
                            seen_calls.add(name)
                            edges.append(ParsedEdge(
                                source=caller_id, target=name,
                                type="CALLS", file_path=rel_path,
                                line=node.start_point[0] + 1,
                            ))
                    elif expr.type == "generic_name":
                        text = _node_text(expr, source_bytes)
                        name = text[:text.index("<")] if "<" in text else text
                        if name not in _CALL_SKIP and name not in seen_calls:
                            seen_calls.add(name)
                            edges.append(ParsedEdge(
                                source=caller_id, target=name,
                                type="CALLS", file_path=rel_path,
                                line=node.start_point[0] + 1,
                            ))

            elif node.type == "object_creation_expression":
                # new ClassName(...)
                type_node = _find_child(node, "identifier", "qualified_name",
                                        "generic_name")
                if type_node:
                    type_name = _node_text(type_node, source_bytes)
                    if "<" in type_name:
                        type_name = type_name[:type_name.index("<")]
                    if type_name not in seen_calls:
                        seen_calls.add(type_name)
                        edges.append(ParsedEdge(
                            source=caller_id, target=type_name,
                            type="CALLS", file_path=rel_path,
                            line=node.start_point[0] + 1,
                        ))

            for child in node.children:
                _walk_calls(child, caller_id, seen_calls)

        def _extract_calls(body_node, caller_id: str):
            if body_node is None:
                return
            seen_calls: set[str] = set()
            _walk_calls(body_node, caller_id, seen_calls)

        def _process_method(ts_node, parent_id: str, class_name: str):
            """Process method_declaration.

            In C# grammar, the return type can be an identifier (e.g. User)
            so we must find the identifier that is the method name, not the
            return type. The method name is the identifier right before
            the parameter_list.
            """
            # Find method name: the identifier immediately before parameter_list
            name_node = None
            all_identifiers = _find_children(ts_node, "identifier")
            if len(all_identifiers) >= 2:
                # Multiple identifiers: return type + method name
                # Method name is the last identifier before parameter_list
                param_list = _find_child(ts_node, "parameter_list")
                if param_list:
                    for ident in all_identifiers:
                        if ident.start_byte < param_list.start_byte:
                            name_node = ident  # keep updating, last one wins
                else:
                    name_node = all_identifiers[-1]
            elif len(all_identifiers) == 1:
                name_node = all_identifiers[0]
            if not name_node:
                return
            name = _node_text(name_node, source_bytes)
            mods = _get_modifiers(ts_node, source_bytes)
            attributes = _get_attributes(ts_node, source_bytes)
            is_exp = "public" in mods
            params = _find_child(ts_node, "parameter_list")
            sig = _params_signature(params, source_bytes)
            ret = _return_type(ts_node, source_bytes)
            prefix_parts = []
            if "async" in mods:
                prefix_parts.append("async")
            if "static" in mods:
                prefix_parts.append("static")
            if ret:
                prefix_parts.append(ret)
            prefix = " ".join(prefix_parts)
            if prefix:
                sig = f"{prefix} {name}{sig}"
            else:
                sig = f"{name}{sig}"
            docstring = _get_xml_doc(ts_node)
            qname = f"{class_name}.{name}"
            mid = _add_node(name, "method", ts_node, parent_id,
                            signature=sig, decorators=attributes,
                            is_exp=is_exp, qualified=qname, docstring=docstring)
            body = _find_child(ts_node, "block")
            if body is None:
                body = _find_child(ts_node, "arrow_expression_clause")
            _extract_calls(body, mid)

        def _process_constructor(ts_node, parent_id: str, class_name: str):
            """Process constructor_declaration."""
            name_node = _find_child(ts_node, "identifier")
            name = _node_text(name_node, source_bytes) if name_node else class_name
            mods = _get_modifiers(ts_node, source_bytes)
            attributes = _get_attributes(ts_node, source_bytes)
            is_exp = "public" in mods
            params = _find_child(ts_node, "parameter_list")
            sig = f"{name}{_params_signature(params, source_bytes)}"
            qname = f"{class_name}.__init__"
            mid = _add_node("__init__", "method", ts_node, parent_id,
                            signature=sig, decorators=attributes,
                            is_exp=is_exp, qualified=qname)
            body = _find_child(ts_node, "block")
            _extract_calls(body, mid)

        def _process_property(ts_node, parent_id: str, class_name: str):
            """Process property_declaration."""
            name_node = _find_child(ts_node, "identifier")
            if not name_node:
                return
            name = _node_text(name_node, source_bytes)
            mods = _get_modifiers(ts_node, source_bytes)
            attributes = _get_attributes(ts_node, source_bytes)
            is_exp = "public" in mods
            # Get property type
            prop_type = ""
            for child in ts_node.children:
                if child.type in ("predefined_type", "generic_name", "type_identifier",
                                  "nullable_type", "array_type", "qualified_name",
                                  "implicit_type", "tuple_type"):
                    prop_type = _node_text(child, source_bytes)
                    break
            sig = f"{prop_type} {name}" if prop_type else name
            # Check for get/set
            accessor_list = _find_child(ts_node, "accessor_list")
            if accessor_list:
                accessors = []
                for acc in accessor_list.children:
                    if acc.type == "accessor_declaration":
                        acc_text = _node_text(acc, source_bytes).strip()
                        if acc_text.startswith("get"):
                            accessors.append("get")
                        elif acc_text.startswith("set"):
                            accessors.append("set")
                        elif acc_text.startswith("init"):
                            accessors.append("init")
                if accessors:
                    sig += " { " + "; ".join(accessors) + "; }"
            qname = f"{class_name}.{name}"
            _add_node(name, "variable", ts_node, parent_id,
                      signature=sig, decorators=attributes,
                      is_exp=is_exp, qualified=qname)

        def _process_field(ts_node, parent_id: str, class_name: str):
            """Process field_declaration."""
            mods = _get_modifiers(ts_node, source_bytes)
            attributes = _get_attributes(ts_node, source_bytes)
            is_exp = "public" in mods
            var_decl = _find_child(ts_node, "variable_declaration")
            if not var_decl:
                return
            for declarator in _find_children(var_decl, "variable_declarator"):
                name_node = _find_child(declarator, "identifier")
                if not name_node:
                    continue
                name = _node_text(name_node, source_bytes)
                qname = f"{class_name}.{name}"
                _add_node(name, "variable", ts_node, parent_id,
                          decorators=attributes, is_exp=is_exp, qualified=qname)

        def _process_event(ts_node, parent_id: str, class_name: str):
            """Process event_declaration or event_field_declaration."""
            mods = _get_modifiers(ts_node, source_bytes)
            attributes = _get_attributes(ts_node, source_bytes)
            is_exp = "public" in mods
            # event_field_declaration has variable_declaration child
            var_decl = _find_child(ts_node, "variable_declaration")
            if var_decl:
                for declarator in _find_children(var_decl, "variable_declarator"):
                    name_node = _find_child(declarator, "identifier")
                    if not name_node:
                        continue
                    name = _node_text(name_node, source_bytes)
                    qname = f"{class_name}.{name}"
                    attributes_with_event = attributes + ["event"]
                    _add_node(name, "variable", ts_node, parent_id,
                              decorators=attributes_with_event, is_exp=is_exp,
                              qualified=qname)
            else:
                # event_declaration with explicit accessor
                name_node = _find_child(ts_node, "identifier")
                if name_node:
                    name = _node_text(name_node, source_bytes)
                    qname = f"{class_name}.{name}"
                    attributes_with_event = attributes + ["event"]
                    _add_node(name, "variable", ts_node, parent_id,
                              decorators=attributes_with_event, is_exp=is_exp,
                              qualified=qname)

        def _process_delegate(ts_node, parent_id: str, class_name: str | None = None):
            """Process delegate_declaration."""
            name_node = _find_child(ts_node, "identifier")
            if not name_node:
                return
            name = _node_text(name_node, source_bytes)
            mods = _get_modifiers(ts_node, source_bytes)
            attributes = _get_attributes(ts_node, source_bytes)
            attributes.append("delegate")
            is_exp = "public" in mods
            params = _find_child(ts_node, "parameter_list")
            sig = f"delegate {name}{_params_signature(params, source_bytes)}"
            qname = f"{class_name}.{name}" if class_name else name
            _add_node(name, "class", ts_node, parent_id,
                      signature=sig, decorators=attributes,
                      is_exp=is_exp, qualified=qname)

        def _process_base_list(ts_node, type_id: str, is_interface: bool = False):
            """Process base_list (: BaseClass, IInterface)."""
            if ts_node is None:
                return
            first_base = True
            for child in ts_node.children:
                if child.type in ("identifier", "generic_name", "qualified_name"):
                    base_name = _node_text(child, source_bytes)
                    if "<" in base_name:
                        base_name = base_name[:base_name.index("<")]
                    # Heuristic: interface names start with I followed by uppercase
                    # For interfaces, all bases are EXTENDS
                    if is_interface:
                        edge_type = "EXTENDS"
                    elif (base_name.startswith("I") and len(base_name) > 1
                          and base_name[1].isupper()):
                        edge_type = "IMPLEMENTS"
                    elif first_base:
                        # First non-I base is likely the parent class
                        edge_type = "EXTENDS"
                    else:
                        edge_type = "IMPLEMENTS"
                    edges.append(ParsedEdge(
                        source=type_id, target=base_name,
                        type=edge_type, file_path=rel_path,
                        line=child.start_point[0] + 1,
                    ))
                    first_base = False
                elif child.type == "simple_base_type":
                    # In C# grammar, base_list contains simple_base_type children
                    inner = _find_child(child, "identifier", "generic_name", "qualified_name")
                    if inner:
                        base_name = _node_text(inner, source_bytes)
                        if "<" in base_name:
                            base_name = base_name[:base_name.index("<")]
                        if is_interface:
                            edge_type = "EXTENDS"
                        elif (base_name.startswith("I") and len(base_name) > 1
                              and base_name[1].isupper()):
                            edge_type = "IMPLEMENTS"
                        elif first_base:
                            edge_type = "EXTENDS"
                        else:
                            edge_type = "IMPLEMENTS"
                        edges.append(ParsedEdge(
                            source=type_id, target=base_name,
                            type=edge_type, file_path=rel_path,
                            line=inner.start_point[0] + 1,
                        ))
                        first_base = False

        def _process_class(ts_node, parent_id: str | None = None,
                           outer_class: str | None = None):
            """Process class_declaration."""
            name_node = _find_child(ts_node, "identifier")
            if not name_node:
                return
            name = _node_text(name_node, source_bytes)
            mods = _get_modifiers(ts_node, source_bytes)
            attributes = _get_attributes(ts_node, source_bytes)
            is_exp = "public" in mods
            docstring = _get_xml_doc(ts_node)
            qname = f"{outer_class}.{name}" if outer_class else name
            class_id = _add_node(name, "class", ts_node, parent_id,
                                 decorators=attributes, is_exp=is_exp,
                                 qualified=qname, docstring=docstring)

            # Base list (inheritance)
            base_list = _find_child(ts_node, "base_list")
            _process_base_list(base_list, class_id, is_interface=False)

            # Body
            body = _find_child(ts_node, "declaration_list")
            if body:
                _process_type_body(body, class_id, name)

        def _process_struct(ts_node, parent_id: str | None = None,
                            outer_class: str | None = None):
            """Process struct_declaration."""
            name_node = _find_child(ts_node, "identifier")
            if not name_node:
                return
            name = _node_text(name_node, source_bytes)
            mods = _get_modifiers(ts_node, source_bytes)
            attributes = _get_attributes(ts_node, source_bytes)
            attributes.append("struct")
            is_exp = "public" in mods
            docstring = _get_xml_doc(ts_node)
            qname = f"{outer_class}.{name}" if outer_class else name
            struct_id = _add_node(name, "class", ts_node, parent_id,
                                  decorators=attributes, is_exp=is_exp,
                                  qualified=qname, docstring=docstring)

            base_list = _find_child(ts_node, "base_list")
            _process_base_list(base_list, struct_id, is_interface=False)

            body = _find_child(ts_node, "declaration_list")
            if body:
                _process_type_body(body, struct_id, name)

        def _process_interface(ts_node, parent_id: str | None = None,
                               outer_class: str | None = None):
            """Process interface_declaration."""
            name_node = _find_child(ts_node, "identifier")
            if not name_node:
                return
            name = _node_text(name_node, source_bytes)
            mods = _get_modifiers(ts_node, source_bytes)
            attributes = _get_attributes(ts_node, source_bytes)
            attributes.append("interface")
            is_exp = "public" in mods
            docstring = _get_xml_doc(ts_node)
            qname = f"{outer_class}.{name}" if outer_class else name
            iface_id = _add_node(name, "class", ts_node, parent_id,
                                 decorators=attributes, is_exp=is_exp,
                                 qualified=qname, docstring=docstring)

            # Interfaces can extend other interfaces
            base_list = _find_child(ts_node, "base_list")
            _process_base_list(base_list, iface_id, is_interface=True)

            body = _find_child(ts_node, "declaration_list")
            if body:
                for member in body.children:
                    if member.type == "method_declaration":
                        _process_method(member, iface_id, name)
                    elif member.type == "property_declaration":
                        _process_property(member, iface_id, name)
                    elif member.type == "event_declaration":
                        _process_event(member, iface_id, name)
                    elif member.type == "event_field_declaration":
                        _process_event(member, iface_id, name)

        def _process_enum(ts_node, parent_id: str | None = None,
                          outer_class: str | None = None):
            """Process enum_declaration."""
            name_node = _find_child(ts_node, "identifier")
            if not name_node:
                return
            name = _node_text(name_node, source_bytes)
            mods = _get_modifiers(ts_node, source_bytes)
            attributes = _get_attributes(ts_node, source_bytes)
            attributes.append("enum")
            is_exp = "public" in mods
            docstring = _get_xml_doc(ts_node)
            qname = f"{outer_class}.{name}" if outer_class else name
            enum_id = _add_node(name, "class", ts_node, parent_id,
                                decorators=attributes, is_exp=is_exp,
                                qualified=qname, docstring=docstring)

            # Enum body contains enum_member_declaration
            body = _find_child(ts_node, "enum_member_declaration_list")
            if body:
                for member in body.children:
                    if member.type == "enum_member_declaration":
                        const_name = _find_child(member, "identifier")
                        if const_name:
                            cname = _node_text(const_name, source_bytes)
                            _add_node(cname, "variable", member, enum_id,
                                      qualified=f"{name}.{cname}", is_exp=True)

        def _process_type_body(body_node, parent_id: str, class_name: str):
            """Process members of a class/struct body."""
            for member in body_node.children:
                if member.type == "method_declaration":
                    _process_method(member, parent_id, class_name)
                elif member.type == "constructor_declaration":
                    _process_constructor(member, parent_id, class_name)
                elif member.type == "property_declaration":
                    _process_property(member, parent_id, class_name)
                elif member.type == "field_declaration":
                    _process_field(member, parent_id, class_name)
                elif member.type == "event_declaration":
                    _process_event(member, parent_id, class_name)
                elif member.type == "event_field_declaration":
                    _process_event(member, parent_id, class_name)
                elif member.type == "delegate_declaration":
                    _process_delegate(member, parent_id, class_name)
                elif member.type == "class_declaration":
                    _process_class(member, parent_id, outer_class=class_name)
                elif member.type == "struct_declaration":
                    _process_struct(member, parent_id, outer_class=class_name)
                elif member.type == "interface_declaration":
                    _process_interface(member, parent_id, outer_class=class_name)
                elif member.type == "enum_declaration":
                    _process_enum(member, parent_id, outer_class=class_name)

        def _process_using(ts_node):
            """Process using_directive."""
            # using System.Collections.Generic;
            # using static System.Math;
            # using Alias = System.String;
            name_node = _find_child(ts_node, "qualified_name", "identifier")
            if name_node:
                import_path = _node_text(name_node, source_bytes)
                edges.append(ParsedEdge(
                    source=file_node_id, target=import_path,
                    type="IMPORTS", file_path=rel_path,
                    line=ts_node.start_point[0] + 1,
                ))

        def _process_namespace(ts_node):
            """Process namespace_declaration or file_scoped_namespace_declaration."""
            nonlocal namespace_name
            name_node = _find_child(ts_node, "qualified_name", "identifier")
            if name_node:
                namespace_name = _node_text(name_node, source_bytes)

            # Process declarations inside the namespace
            body = _find_child(ts_node, "declaration_list")
            if body:
                # Block-scoped namespace: namespace X { ... }
                _process_declarations(body.children)
            else:
                # File-scoped namespace: namespace X;
                # Declarations are direct children of file_scoped_namespace_declaration
                _process_declarations(ts_node.children)

        def _process_declarations(children):
            """Process a list of declaration nodes."""
            for child in children:
                if child.type == "using_directive":
                    _process_using(child)
                elif child.type == "namespace_declaration":
                    _process_namespace(child)
                elif child.type == "file_scoped_namespace_declaration":
                    _process_namespace(child)
                elif child.type == "class_declaration":
                    _process_class(child)
                elif child.type == "struct_declaration":
                    _process_struct(child)
                elif child.type == "interface_declaration":
                    _process_interface(child)
                elif child.type == "enum_declaration":
                    _process_enum(child)
                elif child.type == "delegate_declaration":
                    _process_delegate(child, None)

        # Walk top-level
        _process_declarations(tree.root_node.children)

        # Store namespace as docstring on file node if present
        if namespace_name:
            nodes[0].docstring = f"namespace {namespace_name}"

        return ParsedFile(
            path=rel_path,
            content_hash=hash_val,
            nodes=nodes,
            edges=edges,
            line_count=line_count,
        )


class CSharpParser(BaseParser):
    """AST-based C# parser using tree-sitter.

    Requires tree-sitter-languages to be installed.
    """

    _CS_EXTENSIONS = frozenset({".cs"})

    def __init__(self):
        if _CSHARP_AVAILABLE:
            self._impl = CSharpTreeSitterParser()
        else:
            self._impl = None

    def extensions(self) -> frozenset[str]:
        return self._CS_EXTENSIONS

    def parse(self, path: Path, repo_root: Path) -> ParsedFile:
        if self._impl is None:
            raise ImportError(
                "C# parsing requires tree-sitter-languages. "
                "Install with: pip install tree-sitter-languages"
            )
        return self._impl.parse(path, repo_root)
