"""Go AST parser using tree-sitter.

Extracts packages, functions, methods (with receivers), structs, interfaces,
type aliases, constants, variables, and relationships (CALLS, IMPORTS,
EXTENDS, CONTAINS).

Go-specific features:
  - Method receivers: func (s *Server) Handle() -> method of Server
  - Exported = capitalized first letter
  - Struct embedding (anonymous fields) -> EXTENDS edge
  - Interface method specs -> method nodes
  - Multiple return values in signatures
  - // doc comments before declarations
  - init() functions
"""

from __future__ import annotations

from pathlib import Path

from codebrain.parser.base import BaseParser
from codebrain.parser.models import ParsedEdge, ParsedFile, ParsedNode
from codebrain.utils import content_hash

try:
    from tree_sitter_languages import get_parser

    _GO_AVAILABLE = True
except ImportError:
    _GO_AVAILABLE = False


def _node_text(node, source_bytes: bytes) -> str:
    """Extract text for a tree-sitter node."""
    return source_bytes[node.start_byte:node.end_byte].decode("utf-8", errors="replace")


def _find_child(node, *types: str):
    """Find first child of given type(s)."""
    for child in node.children:
        if child.type in types:
            return child
    return None


def _find_children(node, *types: str):
    """Find all children of given type(s)."""
    return [c for c in node.children if c.type in types]


def _is_exported(name: str) -> bool:
    """Go exports symbols starting with an uppercase letter."""
    return bool(name) and name[0].isupper()


# Calls to skip (Go noise: builtins, fmt, log, errors, context)
_CALL_SKIP = frozenset({
    "fmt.Println", "fmt.Printf", "fmt.Sprintf", "fmt.Fprintf", "fmt.Errorf",
    "fmt.Print", "fmt.Fprint", "fmt.Fprintln", "fmt.Sscanf", "fmt.Scan",
    "log.Println", "log.Printf", "log.Fatal", "log.Fatalf",
    "log.Print", "log.Fatalln", "log.Panic", "log.Panicf", "log.Panicln",
    "errors.New", "errors.Is", "errors.As", "errors.Unwrap",
    "make", "len", "cap", "append", "copy", "delete", "close",
    "panic", "recover", "new", "print", "println",
    "string", "int", "float64", "float32", "bool", "byte", "rune",
    "int8", "int16", "int32", "int64",
    "uint", "uint8", "uint16", "uint32", "uint64",
    "complex64", "complex128",
    "context.Background", "context.TODO",
    "context.WithCancel", "context.WithTimeout",
    "context.WithDeadline", "context.WithValue",
})


class GoTreeSitterParser:
    """Core Go parser implementation using tree-sitter."""

    def __init__(self):
        self._parser = get_parser("go")

    def parse(self, path: Path, repo_root: Path) -> ParsedFile:
        rel_path = path.relative_to(repo_root).as_posix()
        raw = path.read_bytes()
        hash_val = content_hash(raw)

        source = raw.decode("utf-8", errors="replace")
        source_bytes = source.encode("utf-8")
        line_count = source.count("\n") + 1

        tree = self._parser.parse(source_bytes)

        nodes: list[ParsedNode] = []
        edges: list[ParsedEdge] = []
        seen_ids: set[str] = set()
        package_name = ""

        # File node
        module_name = rel_path.replace("/", ".").removesuffix(".go")
        file_node_id = f"{rel_path}::__module__"
        nodes.append(ParsedNode(
            id=file_node_id,
            name=module_name.rsplit(".", 1)[-1],
            qualified_name=module_name,
            type="file",
            file_path=rel_path,
            line_start=1,
            line_end=line_count,
            is_exported=True,
        ))
        seen_ids.add(file_node_id)

        def _add_node(name: str, node_type: str, ts_node,
                      parent_id: str | None = None,
                      signature: str = "",
                      decorators: list[str] | None = None,
                      is_exp: bool = False,
                      qualified: str | None = None,
                      docstring: str = "") -> str:
            node_id = f"{rel_path}::{qualified or name}"
            if node_id in seen_ids:
                return node_id
            seen_ids.add(node_id)
            n = ParsedNode(
                id=node_id, name=name,
                qualified_name=qualified or name,
                type=node_type, file_path=rel_path,
                line_start=ts_node.start_point[0] + 1,
                line_end=ts_node.end_point[0] + 1,
                signature=signature, is_exported=is_exp,
                decorators=decorators or [],
                docstring=docstring,
            )
            nodes.append(n)
            container = parent_id or file_node_id
            edges.append(ParsedEdge(
                source=container, target=node_id,
                type="CONTAINS", file_path=rel_path,
                line=ts_node.start_point[0] + 1,
            ))
            return node_id

        def _get_doc_comment(ts_node) -> str:
            """Extract // doc comments immediately before a node."""
            parent = ts_node.parent
            if not parent:
                return ""
            idx = None
            for i, child in enumerate(parent.children):
                if child.id == ts_node.id:
                    idx = i
                    break
            if idx is None:
                return ""
            lines: list[str] = []
            for i in range(idx - 1, -1, -1):
                sib = parent.children[i]
                if sib.type == "comment":
                    text = _node_text(sib, source_bytes).strip()
                    if text.startswith("//"):
                        cleaned = text[2:].strip()
                        lines.insert(0, cleaned)
                    else:
                        break
                else:
                    break
            return " ".join(lines)[:4000] if lines else ""

        def _walk_calls(node, caller_id: str, seen_calls: set[str]):
            """Recursively extract function/method calls and struct literals from a block."""
            if node.type == "call_expression":
                func_node = _find_child(node, "identifier", "selector_expression")
                if func_node:
                    if func_node.type == "selector_expression":
                        # e.g. obj.Method(...)
                        parts = []
                        for child in func_node.children:
                            if child.type == "identifier":
                                parts.append(_node_text(child, source_bytes))
                            elif child.type == "field_identifier":
                                parts.append(_node_text(child, source_bytes))
                        full_name = ".".join(parts)
                        method_name = parts[-1] if parts else ""
                        if full_name not in _CALL_SKIP and full_name not in seen_calls:
                            seen_calls.add(full_name)
                            edges.append(ParsedEdge(
                                source=caller_id, target=full_name,
                                type="CALLS", file_path=rel_path,
                                line=node.start_point[0] + 1,
                            ))
                        # Also add bare method/function name for cross-file resolution
                        if method_name and method_name != full_name and method_name not in _CALL_SKIP and method_name not in seen_calls:
                            seen_calls.add(method_name)
                            edges.append(ParsedEdge(
                                source=caller_id, target=method_name,
                                type="CALLS", file_path=rel_path,
                                line=node.start_point[0] + 1,
                            ))
                    elif func_node.type == "identifier":
                        name = _node_text(func_node, source_bytes)
                        if name not in _CALL_SKIP and name not in seen_calls:
                            seen_calls.add(name)
                            edges.append(ParsedEdge(
                                source=caller_id, target=name,
                                type="CALLS", file_path=rel_path,
                                line=node.start_point[0] + 1,
                            ))

            # Composite literals: authPair{...}, []string{...}, etc.
            # The type identifier is a reference to the struct type
            elif node.type == "composite_literal":
                type_node = node.children[0] if node.children else None
                if type_node and type_node.type == "type_identifier":
                    name = _node_text(type_node, source_bytes)
                    if name not in _CALL_SKIP and name not in seen_calls:
                        seen_calls.add(name)
                        edges.append(ParsedEdge(
                            source=caller_id, target=name,
                            type="CALLS", file_path=rel_path,
                            line=node.start_point[0] + 1,
                        ))

            for child in node.children:
                _walk_calls(child, caller_id, seen_calls)

        def _extract_calls(body_node, caller_id: str):
            if body_node is None:
                return
            seen_calls: set[str] = set()
            _walk_calls(body_node, caller_id, seen_calls)

        def _params_text(params_node) -> str:
            """Extract parameter list text from parameter_list node."""
            if not params_node:
                return "()"
            return _node_text(params_node, source_bytes)

        def _result_text(ts_node) -> str:
            """Extract return type(s) from a function/method declaration."""
            # Look for result node (parameter_list for multi-return or type for single)
            found_params = False
            for child in ts_node.children:
                if child.type == "parameter_list":
                    if found_params:
                        # Second parameter_list = return values
                        return _node_text(child, source_bytes)
                    found_params = True
                elif child.type in ("type_identifier", "pointer_type", "slice_type",
                                     "array_type", "map_type", "channel_type",
                                     "interface_type", "struct_type", "qualified_type",
                                     "function_type"):
                    if found_params:
                        return _node_text(child, source_bytes)
            return ""

        def _process_function(ts_node):
            """Process function_declaration."""
            name_node = _find_child(ts_node, "identifier")
            if not name_node:
                return
            name = _node_text(name_node, source_bytes)
            is_exp = _is_exported(name)
            params = _find_child(ts_node, "parameter_list")
            ret = _result_text(ts_node)
            sig = f"func {name}{_params_text(params)}"
            if ret:
                sig += f" {ret}"
            docstring = _get_doc_comment(ts_node)
            fid = _add_node(name, "function", ts_node,
                            signature=sig, is_exp=is_exp, docstring=docstring)
            body = _find_child(ts_node, "block")
            _extract_calls(body, fid)

        def _process_method(ts_node):
            """Process method_declaration (func with receiver)."""
            name_node = _find_child(ts_node, "field_identifier")
            if not name_node:
                return
            name = _node_text(name_node, source_bytes)
            is_exp = _is_exported(name)

            # Extract receiver type
            receiver_node = None
            param_lists = _find_children(ts_node, "parameter_list")
            if param_lists:
                receiver_node = param_lists[0]
            receiver_type = ""
            if receiver_node:
                # receiver is like (s *Server) or (s Server)
                recv_text = _node_text(receiver_node, source_bytes)
                # Extract the type name (strip pointer, strip var name)
                for child in receiver_node.children:
                    if child.type == "parameter_declaration":
                        type_child = _find_child(child, "type_identifier", "pointer_type")
                        if type_child:
                            rt = _node_text(type_child, source_bytes)
                            receiver_type = rt.lstrip("*")
                            break

            # Build signature
            # Skip the receiver parameter_list; use the second one for params
            params_node = param_lists[1] if len(param_lists) > 1 else None
            ret = _result_text(ts_node)
            recv_display = _node_text(receiver_node, source_bytes) if receiver_node else ""
            sig = f"func {recv_display} {name}{_params_text(params_node)}"
            if ret:
                sig += f" {ret}"

            docstring = _get_doc_comment(ts_node)
            qname = f"{receiver_type}.{name}" if receiver_type else name

            # Find parent struct node if it exists
            parent_id = None
            if receiver_type:
                candidate_id = f"{rel_path}::{receiver_type}"
                if candidate_id in seen_ids:
                    parent_id = candidate_id

            mid = _add_node(name, "method", ts_node,
                            parent_id=parent_id,
                            signature=sig, is_exp=is_exp,
                            qualified=qname, docstring=docstring)
            body = _find_child(ts_node, "block")
            _extract_calls(body, mid)

        def _process_type_declaration(ts_node):
            """Process type_declaration (struct, interface, alias)."""
            for spec in _find_children(ts_node, "type_spec"):
                name_node = _find_child(spec, "type_identifier")
                if not name_node:
                    continue
                name = _node_text(name_node, source_bytes)
                is_exp = _is_exported(name)
                docstring = _get_doc_comment(ts_node)

                struct_node = _find_child(spec, "struct_type")
                iface_node = _find_child(spec, "interface_type")

                if struct_node:
                    _process_struct(name, is_exp, struct_node, ts_node, docstring)
                elif iface_node:
                    _process_interface(name, is_exp, iface_node, ts_node, docstring)
                else:
                    # Type alias or named type
                    # e.g. type ID int, type Handler func(...)
                    alias_target = ""
                    for child in spec.children:
                        if child.type == "type_identifier" and child != name_node:
                            alias_target = _node_text(child, source_bytes)
                        elif child.type in ("slice_type", "map_type", "function_type",
                                            "pointer_type", "channel_type", "qualified_type",
                                            "array_type", "interface_type", "struct_type"):
                            alias_target = _node_text(child, source_bytes)
                    sig = f"type {name} = {alias_target}" if alias_target else f"type {name}"
                    _add_node(name, "variable", ts_node,
                              signature=sig, is_exp=is_exp, docstring=docstring)

        def _process_struct(name: str, is_exp: bool, struct_node, decl_node, docstring: str):
            """Process a struct type."""
            struct_id = _add_node(name, "class", decl_node,
                                  signature=f"type {name} struct",
                                  is_exp=is_exp, docstring=docstring)

            # Fields
            field_list = _find_child(struct_node, "field_declaration_list")
            if not field_list:
                return

            for field in _find_children(field_list, "field_declaration"):
                field_names = _find_children(field, "field_identifier")
                type_node = None
                for child in field.children:
                    if child.type not in ("field_identifier", "tag", "comment"):
                        type_node = child
                        break

                if field_names:
                    # Named field(s): e.g. Name string or X, Y int
                    for fn in field_names:
                        fname = _node_text(fn, source_bytes)
                        ftype = _node_text(type_node, source_bytes) if type_node else ""
                        _add_node(fname, "variable", field,
                                  parent_id=struct_id,
                                  signature=f"{fname} {ftype}",
                                  is_exp=_is_exported(fname),
                                  qualified=f"{name}.{fname}")
                else:
                    # Anonymous/embedded field (struct embedding)
                    # The type itself is the field: e.g. BaseModel or *BaseModel
                    if type_node:
                        embedded_type = _node_text(type_node, source_bytes).lstrip("*")
                        edges.append(ParsedEdge(
                            source=struct_id, target=embedded_type,
                            type="EXTENDS", file_path=rel_path,
                            line=field.start_point[0] + 1,
                        ))

        def _process_interface(name: str, is_exp: bool, iface_node, decl_node, docstring: str):
            """Process an interface type."""
            decorators = ["interface"]
            iface_id = _add_node(name, "class", decl_node,
                                 signature=f"type {name} interface",
                                 decorators=decorators,
                                 is_exp=is_exp, docstring=docstring)

            # Method specs
            # In tree-sitter go grammar, interface body has method_spec nodes
            for child in iface_node.children:
                if child.type == "method_spec":
                    mname_node = _find_child(child, "field_identifier")
                    if not mname_node:
                        continue
                    mname = _node_text(mname_node, source_bytes)
                    params = _find_child(child, "parameter_list")
                    sig = f"{mname}{_params_text(params)}"
                    # Return type
                    found_params = False
                    for mc in child.children:
                        if mc.type == "parameter_list":
                            if found_params:
                                sig += f" {_node_text(mc, source_bytes)}"
                            found_params = True
                        elif mc.type in ("type_identifier", "pointer_type", "slice_type",
                                          "qualified_type"):
                            if found_params:
                                sig += f" {_node_text(mc, source_bytes)}"
                    _add_node(mname, "method", child,
                              parent_id=iface_id,
                              signature=sig,
                              is_exp=_is_exported(mname),
                              qualified=f"{name}.{mname}")
                elif child.type == "type_identifier":
                    # Embedded interface
                    embedded = _node_text(child, source_bytes)
                    edges.append(ParsedEdge(
                        source=iface_id, target=embedded,
                        type="EXTENDS", file_path=rel_path,
                        line=child.start_point[0] + 1,
                    ))
                elif child.type == "qualified_type":
                    embedded = _node_text(child, source_bytes)
                    edges.append(ParsedEdge(
                        source=iface_id, target=embedded,
                        type="EXTENDS", file_path=rel_path,
                        line=child.start_point[0] + 1,
                    ))

        def _process_const(ts_node):
            """Process const_declaration."""
            docstring = _get_doc_comment(ts_node)
            for spec in _find_children(ts_node, "const_spec"):
                name_node = _find_child(spec, "identifier")
                if not name_node:
                    continue
                name = _node_text(name_node, source_bytes)
                is_exp = _is_exported(name)
                # Try to get value for signature
                sig = f"const {name}"
                # Check for type
                type_node = _find_child(spec, "type_identifier")
                if type_node:
                    sig += f" {_node_text(type_node, source_bytes)}"
                _add_node(name, "variable", spec,
                          signature=sig, is_exp=is_exp,
                          docstring=docstring, decorators=["const"])

        def _process_var(ts_node):
            """Process var_declaration (package-level)."""
            docstring = _get_doc_comment(ts_node)
            for spec in _find_children(ts_node, "var_spec"):
                names = _find_children(spec, "identifier")
                for name_node in names:
                    name = _node_text(name_node, source_bytes)
                    is_exp = _is_exported(name)
                    sig = f"var {name}"
                    type_node = _find_child(spec, "type_identifier", "pointer_type",
                                            "slice_type", "map_type", "qualified_type",
                                            "array_type")
                    if type_node:
                        sig += f" {_node_text(type_node, source_bytes)}"
                    _add_node(name, "variable", spec,
                              signature=sig, is_exp=is_exp,
                              docstring=docstring)

        def _process_import(ts_node):
            """Process import_declaration."""
            # Single import: import "fmt"
            # Grouped: import ( "fmt"\n "os" )
            specs = _find_children(ts_node, "import_spec")
            if not specs:
                # Check for import_spec_list
                spec_list = _find_child(ts_node, "import_spec_list")
                if spec_list:
                    specs = _find_children(spec_list, "import_spec")
            for spec in specs:
                path_node = _find_child(spec, "interpreted_string_literal")
                if not path_node:
                    continue
                import_path = _node_text(path_node, source_bytes).strip('"')
                edges.append(ParsedEdge(
                    source=file_node_id, target=import_path,
                    type="IMPORTS", file_path=rel_path,
                    line=spec.start_point[0] + 1,
                ))

        # Walk top-level declarations
        for child in tree.root_node.children:
            if child.type == "package_clause":
                pkg_name_node = _find_child(child, "package_identifier")
                if pkg_name_node:
                    package_name = _node_text(pkg_name_node, source_bytes)
            elif child.type == "import_declaration":
                _process_import(child)
            elif child.type == "function_declaration":
                _process_function(child)
            elif child.type == "method_declaration":
                _process_method(child)
            elif child.type == "type_declaration":
                _process_type_declaration(child)
            elif child.type == "const_declaration":
                _process_const(child)
            elif child.type == "var_declaration":
                _process_var(child)

        # Store package name as docstring on file node
        if package_name:
            nodes[0].docstring = f"package {package_name}"

        return ParsedFile(
            path=rel_path,
            content_hash=hash_val,
            nodes=nodes,
            edges=edges,
            line_count=line_count,
        )


class GoParser(BaseParser):
    """AST-based Go parser using tree-sitter.

    Requires tree-sitter-languages to be installed.
    """

    _GO_EXTENSIONS = frozenset({".go"})

    def __init__(self):
        if _GO_AVAILABLE:
            self._impl = GoTreeSitterParser()
        else:
            self._impl = None

    def extensions(self) -> frozenset[str]:
        return self._GO_EXTENSIONS

    def parse(self, path: Path, repo_root: Path) -> ParsedFile:
        if self._impl is None:
            raise ImportError(
                "Go parsing requires tree-sitter-languages. "
                "Install with: pip install tree-sitter-languages"
            )
        return self._impl.parse(path, repo_root)
