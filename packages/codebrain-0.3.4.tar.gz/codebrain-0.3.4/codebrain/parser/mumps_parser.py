"""MUMPS/M parser for healthcare system analysis.

Extracts labels (functions), variables, globals, and relationships
(CALLS via DO/GOTO, DATAFLOW via ^globals).

Regex-based. Expected accuracy ~70% on real-world code.

Known limitations:
- Indirect references (@VAR): flagged as warning, target not resolvable
- Argumentless DO (fall-through): detected but call target ambiguous
- XECUTE (execute string as code): flagged as dynamic dispatch warning
- Extremely terse single-line compound statements may miss later commands
"""

from __future__ import annotations

import re
from pathlib import Path

from codebrain.parser.base import BaseParser
from codebrain.parser.models import ParsedEdge, ParsedFile, ParsedNode
from codebrain.utils import content_hash

# ---------------------------------------------------------------------------
# Command abbreviation expansion
# ---------------------------------------------------------------------------

COMMAND_MAP = {
    "S": "SET", "D": "DO", "G": "GOTO", "Q": "QUIT",
    "N": "NEW", "K": "KILL", "W": "WRITE", "R": "READ",
    "I": "IF", "E": "ELSE", "F": "FOR", "H": "HALT",
    "X": "XECUTE", "O": "OPEN", "C": "CLOSE", "U": "USE",
    "L": "LOCK", "M": "MERGE", "ZW": "ZWRITE",
}

# ---------------------------------------------------------------------------
# Regex patterns
# ---------------------------------------------------------------------------

# Label: identifier at start of line (optionally followed by args in parens)
_LABEL_RE = re.compile(
    r"^(\w+)(?:\(([^)]*)\))?\s", re.MULTILINE
)

# DO label or DO label^routine
_DO_RE = re.compile(
    r"\b(?:DO|D)\s+(\w+)(?:\^(\w+))?", re.IGNORECASE
)

# GOTO label
_GOTO_RE = re.compile(
    r"\b(?:GOTO|G)\s+(\w+)(?:\^(\w+))?", re.IGNORECASE
)

# SET variable=value
_SET_RE = re.compile(
    r"\b(?:SET|S)\s+(\w+)\s*=", re.IGNORECASE
)

# NEW variable — local variable declaration
_NEW_RE = re.compile(
    r"\b(?:NEW|N)\s+([\w,\s]+)", re.IGNORECASE
)

# Global variable reference: ^NAME or ^NAME(subscript)
_GLOBAL_RE = re.compile(
    r"\^(\w+)"
)

# Indirect reference: @VAR
_INDIRECT_RE = re.compile(
    r"@(\w+)"
)

# XECUTE: dynamic code execution
_XECUTE_RE = re.compile(
    r"\b(?:XECUTE|X)\s+", re.IGNORECASE
)

# QUIT with value (return)
_QUIT_VALUE_RE = re.compile(
    r"\b(?:QUIT|Q)\s+(\S+)", re.IGNORECASE
)


def detect_m_language(path: Path) -> str:
    """Content-sniff a .m file to distinguish MUMPS from ObjC/MATLAB.

    Returns: 'mumps', 'objc', 'matlab', or 'unknown'.
    """
    try:
        content = path.read_text(encoding="utf-8", errors="replace")[:1000]
    except Exception:
        return "unknown"

    # Objective-C: strong signals
    if "#import" in content or "@interface" in content or "@implementation" in content:
        return "objc"
    # MATLAB: function/classdef at start
    if re.match(r"\s*function\s", content) or re.match(r"\s*classdef\s", content):
        return "matlab"
    # MUMPS signals
    mumps_signals = 0
    if re.search(r"^\w+\s", content, re.MULTILINE):
        mumps_signals += 1
    if re.search(r"\b(SET|DO|GOTO|QUIT|NEW)\b", content) or re.search(r"\b[SDGQN]\s", content):
        mumps_signals += 1
    if "^" in content:
        mumps_signals += 1
    if mumps_signals >= 2:
        return "mumps"
    return "unknown"


class MUMPSParser(BaseParser):
    """Parser for MUMPS/M source files (.mps, .zwr)."""

    def extensions(self) -> frozenset[str]:
        return frozenset({".mps", ".zwr"})

    def parse(self, path: Path, repo_root: Path) -> ParsedFile:
        rel_path = str(path.relative_to(repo_root)).replace("\\", "/")
        try:
            raw = path.read_text(encoding="utf-8", errors="replace")
        except Exception:
            return ParsedFile(path=rel_path, content_hash="", line_count=0)

        chash = content_hash(raw.encode("utf-8"))
        line_count = len(raw.splitlines())

        nodes: list[ParsedNode] = []
        edges: list[ParsedEdge] = []

        module_name = Path(rel_path).stem
        file_id = f"{rel_path}::{module_name}"

        # File node
        nodes.append(ParsedNode(
            id=file_id, name=module_name, qualified_name=module_name,
            type="file", file_path=rel_path,
            line_start=1, line_end=line_count,
            is_exported=True,
        ))

        # Labels (functions)
        seen_labels: set[str] = set()
        for m in _LABEL_RE.finditer(raw):
            label = m.group(1)
            params = m.group(2) or ""
            if label in seen_labels:
                continue
            # Skip if it looks like a command abbreviation
            if label.upper() in COMMAND_MAP or label.upper() in COMMAND_MAP.values():
                continue
            seen_labels.add(label)
            label_id = f"{rel_path}::{label}"
            sig = f"({params})" if params else ""
            nodes.append(ParsedNode(
                id=label_id, name=label, qualified_name=label,
                type="function", file_path=rel_path,
                line_start=1, line_end=1,
                signature=sig, is_exported=True,
            ))
            edges.append(ParsedEdge(
                source=file_id, target=label_id,
                type="CONTAINS", file_path=rel_path, line=1,
            ))

        # DO → CALLS
        for m in _DO_RE.finditer(raw):
            target_label = m.group(1)
            target_routine = m.group(2)
            if target_label.upper() in COMMAND_MAP or target_label.upper() in COMMAND_MAP.values():
                continue
            if target_routine:
                # Cross-routine call: DO label^routine
                edges.append(ParsedEdge(
                    source=file_id, target=f"{target_routine}::{target_label}",
                    type="CALLS", file_path=rel_path, line=1,
                ))
            else:
                edges.append(ParsedEdge(
                    source=file_id, target=f"{rel_path}::{target_label}",
                    type="CALLS", file_path=rel_path, line=1,
                ))

        # GOTO → CALLS with warning
        for m in _GOTO_RE.finditer(raw):
            target_label = m.group(1)
            target_routine = m.group(2)
            target = f"{target_routine}::{target_label}" if target_routine else f"{rel_path}::{target_label}"
            edges.append(ParsedEdge(
                source=file_id, target=target,
                type="CALLS", file_path=rel_path, line=1,
            ))

        goto_count = len(_GOTO_RE.findall(raw))
        if goto_count:
            nodes[0].summary = (nodes[0].summary + "|" if nodes[0].summary else "") + f"goto_count={goto_count}"

        # SET → variables
        seen_vars: set[str] = set()
        for m in _SET_RE.finditer(raw):
            var_name = m.group(1)
            if var_name.startswith("^"):
                continue  # globals handled separately
            if var_name in seen_vars or var_name in seen_labels:
                continue
            seen_vars.add(var_name)

        # NEW → local variables
        for m in _NEW_RE.finditer(raw):
            var_list = m.group(1)
            for v in var_list.split(","):
                v = v.strip()
                if v and v not in seen_vars and v not in seen_labels:
                    seen_vars.add(v)

        # ^GLOBALS → shared state + DATAFLOW
        seen_globals: set[str] = set()
        for m in _GLOBAL_RE.finditer(raw):
            global_name = m.group(1)
            if global_name in seen_globals:
                continue
            seen_globals.add(global_name)
            global_id = f"^{global_name}"
            nodes.append(ParsedNode(
                id=f"{rel_path}::^{global_name}", name=f"^{global_name}",
                qualified_name=f"^{global_name}",
                type="variable", file_path=rel_path,
                line_start=1, line_end=1,
                summary="global",
            ))
            edges.append(ParsedEdge(
                source=file_id, target=f"{rel_path}::^{global_name}",
                type="DATAFLOW", file_path=rel_path, line=1,
            ))

        # @VAR → indirect reference warning
        if _INDIRECT_RE.search(raw):
            nodes[0].summary = (nodes[0].summary + "|" if nodes[0].summary else "") + "indirect_reference_warning"

        # XECUTE → dynamic dispatch warning
        if _XECUTE_RE.search(raw):
            nodes[0].summary = (nodes[0].summary + "|" if nodes[0].summary else "") + "dynamic_dispatch_warning"

        return ParsedFile(
            path=rel_path, content_hash=chash,
            nodes=nodes, edges=edges, line_count=line_count,
        )
