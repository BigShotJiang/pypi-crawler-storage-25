"""Python AST visitor that extracts structural nodes and edges."""

from __future__ import annotations

import ast
import json
from pathlib import Path

from codebrain.parser.base import BaseParser
from codebrain.parser.models import ParsedEdge, ParsedFile, ParsedNode
from codebrain.utils import content_hash


def _get_docstring(node: ast.AST, max_length: int = 4000) -> str:
    """Extract full docstring from a function/class/module, or return ''."""
    ds = ast.get_docstring(node)
    if ds:
        return ds.strip()[:max_length]
    return ""


# ---------------------------------------------------------------------------
# Structural fingerprints
# ---------------------------------------------------------------------------

# Python 3.11+ has ast.TryStar for except* blocks
_TRY_TYPES: tuple = (ast.Try,)
if hasattr(ast, "TryStar"):
    _TRY_TYPES = (ast.Try, ast.TryStar)  # type: ignore[attr-defined]

# I/O pattern detection — module-level constants (not recreated per call)
_IO_BARE_NAMES = {
    "open": "file-io",
    "print": "stdout",
    "input": "stdin",
}

_IO_QUALIFIED = {
    "readlines": "file-io", "readline": "file-io", "writelines": "file-io",
    "fetchall": "sql", "fetchone": "sql", "fetchmany": "sql",
    "executemany": "sql", "executescript": "sql",
    "sendall": "network", "sendto": "network", "recvfrom": "network",
    "getaddrinfo": "network",
    "check_output": "subprocess", "check_call": "subprocess",
}

_IO_RECEIVER_METHOD = {
    ("requests", "get"): "http", ("requests", "post"): "http",
    ("requests", "put"): "http", ("requests", "delete"): "http",
    ("requests", "patch"): "http", ("requests", "head"): "http",
    ("urllib", "urlopen"): "http",
    ("subprocess", "run"): "subprocess", ("subprocess", "call"): "subprocess",
    ("subprocess", "Popen"): "subprocess",
    ("cursor", "execute"): "sql", ("conn", "execute"): "sql",
    ("connection", "execute"): "sql", ("db", "execute"): "sql",
    ("session", "execute"): "sql", ("session", "commit"): "sql",
    ("session", "query"): "sql",
    ("logger", "info"): "logging", ("logger", "warning"): "logging",
    ("logger", "error"): "logging", ("logger", "debug"): "logging",
    ("logging", "info"): "logging", ("logging", "warning"): "logging",
    ("time", "sleep"): "blocking", ("asyncio", "sleep"): "blocking",
}


def _collect_io_patterns(call_node: ast.Call, io_patterns: set) -> None:
    """Classify a Call AST node into I/O pattern categories."""
    if isinstance(call_node.func, ast.Name):
        if call_node.func.id in _IO_BARE_NAMES:
            io_patterns.add(_IO_BARE_NAMES[call_node.func.id])
    elif isinstance(call_node.func, ast.Attribute):
        method = call_node.func.attr
        if method in _IO_QUALIFIED:
            io_patterns.add(_IO_QUALIFIED[method])
        elif isinstance(call_node.func.value, ast.Name):
            key = (call_node.func.value.id, method)
            if key in _IO_RECEIVER_METHOD:
                io_patterns.add(_IO_RECEIVER_METHOD[key])


def _summarize_expr(node: ast.expr) -> str:
    """One-word summary of what a return/yield expression is."""
    if isinstance(node, ast.Constant):
        if node.value is None:
            return "None"
        elif isinstance(node.value, bool):
            return "bool"
        elif isinstance(node.value, str):
            return "str"
        elif isinstance(node.value, (int, float)):
            return "number"
        return type(node.value).__name__
    elif isinstance(node, ast.Name):
        return node.id
    elif isinstance(node, ast.Call):
        if isinstance(node.func, ast.Name):
            return f"{node.func.id}()"
        elif isinstance(node.func, ast.Attribute):
            return f"*.{node.func.attr}()"
        return "call()"
    elif isinstance(node, ast.Dict):
        return "dict"
    elif isinstance(node, ast.List):
        return "list"
    elif isinstance(node, ast.Tuple):
        return "tuple"
    elif isinstance(node, ast.BoolOp):
        return "bool-expr"
    elif isinstance(node, ast.Compare):
        return "comparison"
    elif isinstance(node, ast.IfExp):
        return "conditional"
    elif isinstance(node, ast.JoinedStr):
        return "f-string"
    elif isinstance(node, ast.Attribute):
        return f"*.{node.attr}"
    return "expr"


def _build_fingerprint(node: ast.FunctionDef | ast.AsyncFunctionDef) -> str:
    """Build a structural fingerprint from a function's AST.

    Single-pass ast.walk collecting: returns, raises, mutations, control flow,
    I/O patterns, and async awaits. Deterministic — no LLM involved.
    """
    returns: list[str] = []
    yields: list[str] = []
    raises: set[str] = set()
    mutations: set[str] = set()
    flow: list[str] = []
    io_patterns: set[str] = set()
    has_await = False

    for child in ast.walk(node):
        if isinstance(child, ast.Return) and child.value:
            returns.append(_summarize_expr(child.value))
        elif isinstance(child, (ast.Yield, ast.YieldFrom)):
            yields.append("yield")
        elif isinstance(child, ast.Raise) and child.exc:
            if isinstance(child.exc, ast.Call) and isinstance(child.exc.func, ast.Name):
                raises.add(child.exc.func.id)
            elif isinstance(child.exc, ast.Name):
                raises.add(child.exc.id)
        elif isinstance(child, ast.Assign):
            for target in child.targets:
                if (isinstance(target, ast.Attribute)
                        and isinstance(target.value, ast.Name)
                        and target.value.id == "self"):
                    mutations.add(f"self.{target.attr}")
        elif isinstance(child, ast.AugAssign):
            if (isinstance(child.target, ast.Attribute)
                    and isinstance(child.target.value, ast.Name)
                    and child.target.value.id == "self"):
                mutations.add(f"self.{child.target.attr}")
        elif isinstance(child, (ast.For, ast.AsyncFor)):
            flow.append("loop")
        elif isinstance(child, ast.While):
            flow.append("while-loop")
        elif isinstance(child, _TRY_TYPES):
            handlers: list[str] = []
            for handler in child.handlers:
                if handler.type:
                    if isinstance(handler.type, ast.Name):
                        handlers.append(handler.type.id)
                    elif isinstance(handler.type, ast.Tuple):
                        for elt in handler.type.elts:
                            if isinstance(elt, ast.Name):
                                handlers.append(elt.id)
                else:
                    handlers.append("Exception")
            is_star = hasattr(ast, "TryStar") and isinstance(child, getattr(ast, "TryStar"))
            label = "try/except*" if is_star else "try/except"
            flow.append(f"{label} {', '.join(handlers)}" if handlers else label)
        elif isinstance(child, (ast.With, ast.AsyncWith)):
            flow.append("context-manager")
        elif isinstance(child, ast.Assert):
            flow.append("assert")
        elif isinstance(child, ast.Call):
            _collect_io_patterns(child, io_patterns)
        elif isinstance(child, ast.Await):
            has_await = True

    parts: list[str] = []
    if returns:
        unique = list(dict.fromkeys(returns))[:5]
        parts.append(f"returns: {', '.join(unique)}")
    if yields:
        parts.append("yields values (generator)")
    if raises:
        parts.append(f"raises: {', '.join(sorted(raises))}")
    if mutations:
        parts.append(f"mutates: {', '.join(sorted(mutations))}")
    if flow:
        unique_flow = list(dict.fromkeys(flow))[:6]
        parts.append(f"control: {', '.join(unique_flow)}")
    if io_patterns:
        parts.append(f"io: {', '.join(sorted(io_patterns))}")
    if isinstance(node, ast.AsyncFunctionDef):
        parts.append("async with awaits" if has_await else "async")

    return " | ".join(parts) if parts else ""


def _build_class_fingerprint(node: ast.ClassDef) -> str:
    """Structural fingerprint for a class."""
    parts: list[str] = []

    methods = [n for n in node.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))]
    public = [m for m in methods if not m.name.startswith("_")]
    private = [m for m in methods if m.name.startswith("_") and m.name != "__init__"]
    parts.append(f"{len(public)} public methods, {len(private)} private")

    init = next((m for m in methods if m.name == "__init__"), None)
    if init:
        attrs: set[str] = set()
        for child in ast.walk(init):
            if isinstance(child, ast.Assign):
                for target in child.targets:
                    if (isinstance(target, ast.Attribute)
                            and isinstance(target.value, ast.Name)
                            and target.value.id == "self"):
                        attrs.add(target.attr)
        if attrs:
            parts.append(f"state: {', '.join(sorted(attrs)[:10])}")

    bases: list[str] = []
    for base in node.bases:
        if isinstance(base, ast.Name):
            bases.append(base.id)
        elif isinstance(base, ast.Attribute):
            bases.append(f"*.{base.attr}")
    if bases:
        parts.append(f"extends: {', '.join(bases)}")

    has_abstract = any(
        isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))
        and any(
            (isinstance(d, ast.Name) and d.id == "abstractmethod")
            or (isinstance(d, ast.Attribute) and d.attr == "abstractmethod")
            for d in n.decorator_list
        )
        for n in node.body
    )
    if has_abstract:
        parts.append("abstract")

    for dec in node.decorator_list:
        if isinstance(dec, ast.Name) and dec.id == "dataclass":
            parts.append("dataclass")
        elif isinstance(dec, ast.Call) and isinstance(dec.func, ast.Name) and dec.func.id == "dataclass":
            parts.append("dataclass")

    return " | ".join(parts) if parts else ""


def _get_decorator_names(node: ast.FunctionDef | ast.AsyncFunctionDef | ast.ClassDef) -> list[str]:
    """Return a list of decorator name strings."""
    names: list[str] = []
    for dec in node.decorator_list:
        if isinstance(dec, ast.Name):
            names.append(dec.id)
        elif isinstance(dec, ast.Attribute):
            names.append(ast.unparse(dec))
        elif isinstance(dec, ast.Call):
            if isinstance(dec.func, ast.Name):
                names.append(dec.func.id)
            elif isinstance(dec.func, ast.Attribute):
                names.append(ast.unparse(dec.func))
            else:
                names.append(ast.unparse(dec.func))
        else:
            names.append(ast.unparse(dec))
    return names


def _build_signature(node: ast.FunctionDef | ast.AsyncFunctionDef) -> str:
    """Build a human-readable function signature string."""
    params: list[str] = []
    args = node.args

    # positional-only
    for i, arg in enumerate(args.posonlyargs):
        p = arg.arg
        if arg.annotation:
            p += f": {ast.unparse(arg.annotation)}"
        params.append(p)
    if args.posonlyargs:
        params.append("/")

    # normal positional/keyword
    num_defaults = len(args.defaults)
    num_args = len(args.args)
    for i, arg in enumerate(args.args):
        p = arg.arg
        if arg.annotation:
            p += f": {ast.unparse(arg.annotation)}"
        default_idx = i - (num_args - num_defaults)
        if default_idx >= 0:
            p += f" = {ast.unparse(args.defaults[default_idx])}"
        params.append(p)

    # *args
    if args.vararg:
        p = f"*{args.vararg.arg}"
        if args.vararg.annotation:
            p += f": {ast.unparse(args.vararg.annotation)}"
        params.append(p)
    elif args.kwonlyargs:
        params.append("*")

    # keyword-only
    for i, arg in enumerate(args.kwonlyargs):
        p = arg.arg
        if arg.annotation:
            p += f": {ast.unparse(arg.annotation)}"
        if args.kw_defaults[i] is not None:
            p += f" = {ast.unparse(args.kw_defaults[i])}"
        params.append(p)

    # **kwargs
    if args.kwarg:
        p = f"**{args.kwarg.arg}"
        if args.kwarg.annotation:
            p += f": {ast.unparse(args.kwarg.annotation)}"
        params.append(p)

    sig = f"({', '.join(params)})"
    if node.returns:
        sig += f" -> {ast.unparse(node.returns)}"
    return sig


def _call_target_name(node: ast.Call) -> str | None:
    """Best-effort extraction of the callable name from a Call node."""
    func = node.func
    if isinstance(func, ast.Name):
        return func.id
    if isinstance(func, ast.Attribute):
        return ast.unparse(func)
    return None


# Route decorator patterns for API endpoint extraction
_ROUTE_METHODS = frozenset({"get", "post", "put", "delete", "patch", "head", "options", "route"})


def _extract_route_info(decorators: list[ast.expr]) -> str | None:
    """Extract API route path from decorators like @app.get('/path') or @router.post('/path')."""
    for dec in decorators:
        if isinstance(dec, ast.Call) and isinstance(dec.func, ast.Attribute):
            method = dec.func.attr
            if method in _ROUTE_METHODS and dec.args:
                arg = dec.args[0]
                if isinstance(arg, ast.Constant) and isinstance(arg.value, str):
                    return f"{method.upper()} {arg.value}"
    return None


# MongoDB collection access patterns
_MONGO_PATTERNS = (
    # db["collection_name"] or db['collection_name']
    r"""(?:db|database|mongo_db|self\.db|self\.database)\s*\[\s*['"](\w+)['"]\s*\]""",
    # db.collection_name (attribute access)
    r"""(?:db|database|mongo_db|self\.db|self\.database)\.(\w+)\b(?!\s*\()""",
    # get_collection("name") or collection("name")
    r"""(?:get_collection|collection)\s*\(\s*['"](\w+)['"]\s*\)""",
)

import re as _re
_MONGO_RE = [_re.compile(p) for p in _MONGO_PATTERNS]

# Significant comment patterns
_SIGNIFICANT_COMMENT = _re.compile(
    r"""#\s*(TODO|FIXME|HACK|NOTE|WARNING|BUG|XXX|IMPORTANT|REFACTOR)\b[:\s]*(.+)""",
    _re.IGNORECASE,
)


def _extract_significant_comments(source: str, max_comments: int = 20) -> list[str]:
    """Extract TODO, FIXME, HACK, NOTE and other significant comments."""
    comments: list[str] = []
    for m in _SIGNIFICANT_COMMENT.finditer(source):
        tag = m.group(1).upper()
        text = m.group(2).strip()[:100]
        line = source.count("\n", 0, m.start()) + 1
        comments.append(f"L{line} {tag}: {text}")
        if len(comments) >= max_comments:
            break
    return comments

# Common MongoDB method names to filter out
_MONGO_METHODS = frozenset({
    "find", "find_one", "insert_one", "insert_many", "update_one", "update_many",
    "delete_one", "delete_many", "aggregate", "count_documents", "create_index",
    "drop", "distinct", "bulk_write", "watch", "list_collection_names",
    "get_database", "get_collection", "client", "close", "command",
})


def _extract_mongo_collections(source: str) -> list[str]:
    """Extract MongoDB collection names from source code."""
    collections: set[str] = set()
    for pattern in _MONGO_RE:
        for m in pattern.finditer(source):
            name = m.group(1)
            if name and name not in _MONGO_METHODS and not name.startswith("_"):
                collections.add(name)
    return sorted(collections)


class PythonVisitor(ast.NodeVisitor):
    """Walk a Python AST and collect structural nodes and edges."""

    def __init__(self, file_path: str, module_name: str) -> None:
        self.file_path = file_path
        self.module_name = module_name
        self.nodes: list[ParsedNode] = []
        self.edges: list[ParsedEdge] = []
        self._scope_stack: list[str] = []  # qualified name parts
        self._all_names: set[str] | None = None  # populated if __all__ found
        self._current_class: str | None = None  # current class node id
        self._file_imports: set[str] = set()  # all import module paths in this file

    def _make_id(self, qualified_name: str) -> str:
        return f"{self.file_path}::{qualified_name}"

    def _resolve_call_target(self, name: str, class_node_id: str | None) -> str:
        """Resolve ``self.X`` to ``ClassName.X`` using the enclosing class context."""
        if class_node_id and name.startswith("self."):
            class_qname = class_node_id.split("::", 1)[1] if "::" in class_node_id else class_node_id
            return f"{class_qname}.{name[5:]}"
        return name

    def _qualified_name(self, name: str) -> str:
        if self._scope_stack:
            return ".".join(self._scope_stack) + "." + name
        return name

    def _is_exported(self, name: str) -> bool:
        if self._all_names is not None:
            return name in self._all_names
        # If no __all__, top-level non-underscore names are considered exported
        return len(self._scope_stack) == 0 and not name.startswith("_")

    # ------------------------------------------------------------------
    # Pre-scan for __all__
    # ------------------------------------------------------------------
    def _scan_all(self, tree: ast.Module) -> None:
        for node in ast.iter_child_nodes(tree):
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name) and target.id == "__all__":
                        if isinstance(node.value, (ast.List, ast.Tuple)):
                            self._all_names = set()
                            for elt in node.value.elts:
                                if isinstance(elt, ast.Constant) and isinstance(elt.value, str):
                                    self._all_names.add(elt.value)

    # ------------------------------------------------------------------
    # Visitors
    # ------------------------------------------------------------------
    def visit_Module(self, node: ast.Module) -> None:
        self._scan_all(node)
        # Emit CALLS edges for module-level code (assignments, expressions, etc.)
        # This catches patterns like: x = Foo(), metaclass=Bar, Name = OtherName
        self._scan_module_level_calls(node)
        self.generic_visit(node)

    def _scan_module_level_calls(self, module: ast.Module) -> None:
        """Emit CALLS edges for calls and references at module scope.

        Catches: module-level instantiations (x = Foo()), aliasing (X = Y),
        metaclass usage (class C(metaclass=M)), and other top-level calls.
        """
        file_node_id = self._make_id(self.module_name)
        for stmt in module.body:
            # Handle metaclass= in class definitions
            if isinstance(stmt, ast.ClassDef):
                for kw in stmt.keywords:
                    if kw.arg == "metaclass" and isinstance(kw.value, ast.Name):
                        self.edges.append(ParsedEdge(
                            source=file_node_id,
                            target=kw.value.id,
                            type="CALLS",
                            file_path=self.file_path,
                            line=stmt.lineno,
                        ))
                continue
            # Skip function defs — they have their own visitor
            if isinstance(stmt, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            # Walk all nodes in this top-level statement
            for child in ast.walk(stmt):
                if isinstance(child, ast.Call):
                    name = _call_target_name(child)
                    if name:
                        self.edges.append(ParsedEdge(
                            source=file_node_id,
                            target=name,
                            type="CALLS",
                            file_path=self.file_path,
                            line=getattr(child, "lineno", 0),
                        ))
                    # Also emit edges for Name arguments passed to module-level
                    # calls. Catches register_*(ClassName), app.add_*(handler), etc.
                    for arg in child.args:
                        if isinstance(arg, ast.Name):
                            self.edges.append(ParsedEdge(
                                source=file_node_id,
                                target=arg.id,
                                type="CALLS",
                                file_path=self.file_path,
                                line=getattr(child, "lineno", 0),
                            ))
                # Detect aliasing: X = Y where Y is a bare name reference
                if isinstance(child, ast.Assign) and isinstance(child.value, ast.Name):
                    self.edges.append(ParsedEdge(
                        source=file_node_id,
                        target=child.value.id,
                        type="CALLS",
                        file_path=self.file_path,
                        line=getattr(child, "lineno", 0),
                    ))

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        self._handle_function(node)

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        self._handle_function(node)

    def _handle_function(self, node: ast.FunctionDef | ast.AsyncFunctionDef) -> None:
        qname = self._qualified_name(node.name)
        node_id = self._make_id(qname)
        node_type = "method" if self._current_class else "function"

        decorators = _get_decorator_names(node)

        # Check for API route decorators
        route_info = _extract_route_info(node.decorator_list)
        if route_info:
            decorators.append(f"endpoint:{route_info}")

        pnode = ParsedNode(
            id=node_id,
            name=node.name,
            qualified_name=qname,
            type=node_type,
            file_path=self.file_path,
            line_start=node.lineno,
            line_end=node.end_lineno or node.lineno,
            signature=_build_signature(node),
            decorators=decorators,
            docstring=_get_docstring(node),
            is_exported=self._is_exported(node.name),
            summary=_build_fingerprint(node),
        )
        self.nodes.append(pnode)

        # CONTAINS edge from parent
        if self._current_class:
            self.edges.append(ParsedEdge(
                source=self._current_class,
                target=node_id,
                type="CONTAINS",
                file_path=self.file_path,
                line=node.lineno,
            ))
        else:
            # file contains this function
            file_node_id = self._make_id(self.module_name)
            self.edges.append(ParsedEdge(
                source=file_node_id,
                target=node_id,
                type="CONTAINS",
                file_path=self.file_path,
                line=node.lineno,
            ))

        # Walk body for calls, nested defs, etc.
        old_class = self._current_class
        self._current_class = None  # nested funcs are not methods
        self._scope_stack.append(node.name)
        self._visit_body_for_calls(node, class_node_id=old_class)
        self.generic_visit(node)
        self._scope_stack.pop()
        self._current_class = old_class

    def visit_ClassDef(self, node: ast.ClassDef) -> None:
        qname = self._qualified_name(node.name)
        node_id = self._make_id(qname)

        pnode = ParsedNode(
            id=node_id,
            name=node.name,
            qualified_name=qname,
            type="class",
            file_path=self.file_path,
            line_start=node.lineno,
            line_end=node.end_lineno or node.lineno,
            decorators=_get_decorator_names(node),
            docstring=_get_docstring(node),
            is_exported=self._is_exported(node.name),
            summary=_build_class_fingerprint(node),
        )
        self.nodes.append(pnode)

        # CONTAINS edge from file
        file_node_id = self._make_id(self.module_name)
        self.edges.append(ParsedEdge(
            source=file_node_id,
            target=node_id,
            type="CONTAINS",
            file_path=self.file_path,
            line=node.lineno,
        ))

        # EXTENDS edges for base classes
        base_names: list[str] = []
        for base in node.bases:
            base_name = ast.unparse(base)
            base_names.append(base_name)
            self.edges.append(ParsedEdge(
                source=node_id,
                target=base_name,
                type="EXTENDS",
                file_path=self.file_path,
                line=node.lineno,
            ))

        # ORM / Pydantic detection (uses AST-level imports)
        self._detect_orm_model(node, node_id, pnode, base_names)

        # Scan class body for calls in field assignments and class-level statements.
        # These are NOT inside methods, so _visit_body_for_calls won't catch them.
        # E.g. `input_formats = DateTimeFormatsIterator()` or `Foo.register(Bar)`
        for stmt in node.body:
            if isinstance(stmt, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue  # handled by visit_FunctionDef
            for child in ast.walk(stmt):
                if isinstance(child, ast.Call):
                    cname = _call_target_name(child)
                    if cname:
                        self.edges.append(ParsedEdge(
                            source=node_id, target=cname,
                            type="CALLS", file_path=self.file_path,
                            line=getattr(child, "lineno", 0),
                        ))
                    # Also emit for Name arguments (register patterns)
                    for arg in child.args:
                        if isinstance(arg, ast.Name):
                            self.edges.append(ParsedEdge(
                                source=node_id, target=arg.id,
                                type="CALLS", file_path=self.file_path,
                                line=getattr(child, "lineno", 0),
                            ))
                # Bare name references in assignments: x = SomeClass
                if isinstance(child, ast.Assign) and isinstance(child.value, ast.Name):
                    self.edges.append(ParsedEdge(
                        source=node_id, target=child.value.id,
                        type="CALLS", file_path=self.file_path,
                        line=getattr(child, "lineno", 0),
                    ))

        # Visit children
        old_class = self._current_class
        self._current_class = node_id
        self._scope_stack.append(node.name)
        self.generic_visit(node)
        self._scope_stack.pop()
        self._current_class = old_class

    def _detect_orm_model(
        self,
        node: ast.ClassDef,
        node_id: str,
        pnode: ParsedNode,
        base_names: list[str],
    ) -> None:
        """Detect ORM models (SQLAlchemy, Django) and Pydantic models.

        Uses AST-level imports from self._file_imports to gate detection.
        """
        has_sqlalchemy = any("sqlalchemy" in imp for imp in self._file_imports)
        has_django_db = any("django.db" in imp or "django" == imp for imp in self._file_imports)
        has_pydantic = any("pydantic" in imp for imp in self._file_imports)

        orm_type = ""
        # Classes that extend DeclarativeBase ARE the base definition, not ORM models
        sa_meta_bases = {"DeclarativeBase", "DeclarativeBaseNoMeta"}
        sa_model_bases = {"Base"}
        if has_sqlalchemy and any(b in sa_model_bases or b.endswith(".Base") for b in base_names):
            orm_type = "sqlalchemy"
        elif has_django_db and any(b in ("models.Model", "Model") for b in base_names):
            orm_type = "django"

        if orm_type:
            pnode.decorators.append("orm_model")
            pnode.decorators.append(orm_type)
            self._enrich_orm_class(node, node_id, pnode, orm_type)

        # Pydantic — separate from ORM
        if has_pydantic and any(
            b in ("BaseModel", "pydantic.BaseModel") for b in base_names
        ):
            pnode.decorators.append("pydantic_model")

    def _enrich_orm_class(
        self,
        node: ast.ClassDef,
        node_id: str,
        pnode: ParsedNode,
        orm_type: str,
    ) -> None:
        """Extract ORM-specific metadata from class body.

        Stores column info in the class node summary as:
        orm=sqlalchemy table=users cols:id/Integer/pk;name/String(100)/notnull;email/String(255)
        """
        summary_extra: list[str] = [f"orm={orm_type}"]
        columns: list[str] = []  # "name/type/flags" entries

        for stmt in ast.iter_child_nodes(node):
            # __tablename__ = "xyz"
            if isinstance(stmt, ast.Assign):
                for target in stmt.targets:
                    if isinstance(target, ast.Name) and target.id == "__tablename__":
                        if isinstance(stmt.value, ast.Constant) and isinstance(stmt.value.value, str):
                            summary_extra.append(f"table={stmt.value.value}")

            # SQLAlchemy: Column(), relationship(), ForeignKey()
            if orm_type == "sqlalchemy" and isinstance(stmt, ast.Assign):
                if isinstance(stmt.value, ast.Call):
                    func = stmt.value
                    func_name = ""
                    if isinstance(func.func, ast.Name):
                        func_name = func.func.id
                    elif isinstance(func.func, ast.Attribute):
                        func_name = func.func.attr

                    # Extract Column() with type info
                    if func_name == "Column":
                        col_type = self._extract_sa_column_type(func)
                        col_attrs = self._extract_sa_column_attrs(func)
                        for target in stmt.targets:
                            if isinstance(target, ast.Name):
                                flags = []
                                if col_attrs.get("primary_key"):
                                    flags.append("pk")
                                if col_attrs.get("nullable") is False:
                                    flags.append("notnull")
                                if col_attrs.get("default"):
                                    flags.append(f"default={col_attrs['default']}")
                                if col_attrs.get("foreign_key"):
                                    flags.append("fk")
                                flag_str = ",".join(flags) if flags else ""
                                columns.append(f"{target.id}/{col_type}/{flag_str}")

                    # relationship("Model") → DATAFLOW edge
                    if func_name == "relationship" and func.args:
                        arg = func.args[0]
                        if isinstance(arg, ast.Constant) and isinstance(arg.value, str):
                            self.edges.append(ParsedEdge(
                                source=node_id,
                                target=arg.value,
                                type="DATAFLOW",
                                file_path=self.file_path,
                                line=stmt.lineno,
                            ))

                    # Check for ForeignKey in Column args
                    for a in func.args:
                        if isinstance(a, ast.Call):
                            fk_name = ""
                            if isinstance(a.func, ast.Name):
                                fk_name = a.func.id
                            elif isinstance(a.func, ast.Attribute):
                                fk_name = a.func.attr
                            if fk_name == "ForeignKey" and a.args:
                                fk_arg = a.args[0]
                                if isinstance(fk_arg, ast.Constant) and isinstance(fk_arg.value, str):
                                    ref_table = fk_arg.value.split(".")[0]
                                    self.edges.append(ParsedEdge(
                                        source=node_id,
                                        target=ref_table,
                                        type="REFERENCES",
                                        file_path=self.file_path,
                                        line=stmt.lineno,
                                    ))

            # Django: ForeignKey, ManyToManyField, CharField, etc.
            if orm_type == "django" and isinstance(stmt, ast.Assign):
                if isinstance(stmt.value, ast.Call):
                    func = stmt.value
                    func_name = ""
                    if isinstance(func.func, ast.Name):
                        func_name = func.func.id
                    elif isinstance(func.func, ast.Attribute):
                        func_name = func.func.attr

                    django_fields = {
                        "CharField", "IntegerField", "TextField", "FloatField",
                        "BooleanField", "DateField", "DateTimeField", "DecimalField",
                        "EmailField", "URLField", "SlugField", "UUIDField",
                        "AutoField", "BigAutoField", "SmallAutoField",
                        "BigIntegerField", "SmallIntegerField", "PositiveIntegerField",
                        "FileField", "ImageField", "JSONField", "BinaryField",
                    }
                    rel_fields = {"ForeignKey", "ManyToManyField", "OneToOneField"}

                    if func_name in django_fields:
                        col_attrs = self._extract_django_field_attrs(func)
                        for target in stmt.targets:
                            if isinstance(target, ast.Name):
                                col_type = func_name
                                if col_attrs.get("max_length"):
                                    col_type = f"{func_name}({col_attrs['max_length']})"
                                flags = []
                                if col_attrs.get("primary_key"):
                                    flags.append("pk")
                                if col_attrs.get("nullable") is False:
                                    flags.append("notnull")
                                if col_attrs.get("default"):
                                    flags.append(f"default={col_attrs['default']}")
                                flag_str = ",".join(flags) if flags else ""
                                columns.append(f"{target.id}/{col_type}/{flag_str}")

                    if func_name in rel_fields and func.args:
                        ref_arg = func.args[0]
                        ref_target = ""
                        if isinstance(ref_arg, ast.Constant) and isinstance(ref_arg.value, str):
                            ref_target = ref_arg.value.split(".")[-1]
                        elif isinstance(ref_arg, ast.Name):
                            ref_target = ref_arg.id
                        if ref_target:
                            self.edges.append(ParsedEdge(
                                source=node_id,
                                target=ref_target,
                                type="REFERENCES",
                                file_path=self.file_path,
                                line=stmt.lineno,
                            ))

        # Store column info on the class node
        if columns:
            summary_extra.append("cols:" + ";".join(columns))

        # Append ORM summary to existing
        if summary_extra and pnode.summary:
            pnode.summary = pnode.summary + "|" + " ".join(summary_extra)
        elif summary_extra:
            pnode.summary = " ".join(summary_extra)

    @staticmethod
    def _extract_sa_column_type(call_node: ast.Call) -> str:
        """Extract SQLAlchemy Column type from first positional arg.

        Column(Integer) → "Integer"
        Column(String(255)) → "String(255)"
        Column(sa.Integer) → "Integer"
        """
        if not call_node.args:
            return "unknown"
        first = call_node.args[0]
        if isinstance(first, ast.Name):
            return first.id
        if isinstance(first, ast.Attribute):
            return first.attr
        if isinstance(first, ast.Call):
            # String(255), Numeric(10, 2)
            func_name = ""
            if isinstance(first.func, ast.Name):
                func_name = first.func.id
            elif isinstance(first.func, ast.Attribute):
                func_name = first.func.attr
            if func_name and first.args:
                arg_strs = []
                for a in first.args:
                    if isinstance(a, ast.Constant):
                        arg_strs.append(str(a.value))
                return f"{func_name}({','.join(arg_strs)})" if arg_strs else func_name
            return func_name or "unknown"
        return "unknown"

    @staticmethod
    def _extract_sa_column_attrs(call_node: ast.Call) -> dict:
        """Extract SQLAlchemy Column keyword attrs (nullable, primary_key, default)."""
        attrs: dict = {}
        for kw in call_node.keywords:
            if kw.arg == "primary_key" and isinstance(kw.value, ast.Constant):
                attrs["primary_key"] = bool(kw.value.value)
            elif kw.arg == "nullable" and isinstance(kw.value, ast.Constant):
                attrs["nullable"] = bool(kw.value.value)
            elif kw.arg == "default" and isinstance(kw.value, ast.Constant):
                attrs["default"] = str(kw.value.value)
            elif kw.arg == "server_default" and isinstance(kw.value, ast.Constant):
                attrs["default"] = str(kw.value.value)
        # Check for ForeignKey in positional args → implies not null typically
        for a in call_node.args:
            if isinstance(a, ast.Call):
                fn = ""
                if isinstance(a.func, ast.Name):
                    fn = a.func.id
                elif isinstance(a.func, ast.Attribute):
                    fn = a.func.attr
                if fn == "ForeignKey":
                    attrs["foreign_key"] = True
        return attrs

    @staticmethod
    def _extract_django_field_attrs(call_node: ast.Call) -> dict:
        """Extract Django field keyword attrs (max_length, null, primary_key)."""
        attrs: dict = {}
        for kw in call_node.keywords:
            if kw.arg == "max_length" and isinstance(kw.value, ast.Constant):
                attrs["max_length"] = str(kw.value.value)
            elif kw.arg == "null" and isinstance(kw.value, ast.Constant):
                attrs["nullable"] = bool(kw.value.value)
            elif kw.arg == "primary_key" and isinstance(kw.value, ast.Constant):
                attrs["primary_key"] = bool(kw.value.value)
            elif kw.arg == "default" and isinstance(kw.value, ast.Constant):
                attrs["default"] = str(kw.value.value)
        return attrs

    def visit_Import(self, node: ast.Import) -> None:
        container_id = self._make_id(
            ".".join(self._scope_stack) if self._scope_stack else self.module_name
        )
        for alias in node.names:
            self._file_imports.add(alias.name)
            self.edges.append(ParsedEdge(
                source=container_id,
                target=alias.name,
                type="IMPORTS",
                file_path=self.file_path,
                line=node.lineno,
            ))

    def visit_ImportFrom(self, node: ast.ImportFrom) -> None:
        container_id = self._make_id(
            ".".join(self._scope_stack) if self._scope_stack else self.module_name
        )
        module = node.module or ""
        if module:
            self._file_imports.add(module)
        if node.names:
            for alias in node.names:
                if alias.name == "*":
                    # Star import: create edge to the module itself so dependency
                    # tracking knows this file depends on the entire module.
                    if module:
                        self.edges.append(ParsedEdge(
                            source=container_id,
                            target=module,
                            type="IMPORTS",
                            file_path=self.file_path,
                            line=node.lineno,
                        ))
                    continue
                target = f"{module}.{alias.name}" if module else alias.name
                self.edges.append(ParsedEdge(
                    source=container_id,
                    target=target,
                    type="IMPORTS",
                    file_path=self.file_path,
                    line=node.lineno,
                ))

    def _visit_body_for_calls(self, parent: ast.AST, class_node_id: str | None = None) -> None:
        """Walk all Call nodes inside *parent* and emit CALLS and DATAFLOW edges.

        DATAFLOW edges represent data dependencies between symbols — cases where
        the return value of one callable flows into another.  They use the same
        ``source=consumer, target=producer`` convention as CALLS edges, except
        for nested-call patterns where ``source=inner, target=outer`` to show
        the inner call's result feeding into the outer call.

        DATAFLOW edges are created for the following patterns:

        1. **Assignment from call**: ``x = foo()`` — the enclosing function
           (container) has a DATAFLOW edge targeting ``foo`` because the
           container consumes the value produced by ``foo``.
        2. **Return of call**: ``return foo()`` — same as (1); the container's
           return value depends on ``foo``'s output.
        3. **Nested calls**: ``outer(inner())`` — ``inner``'s output flows into
           ``outer``, so ``source=inner, target=outer``.
        4. **Keyword-arg calls**: ``outer(key=inner())`` — same as (3).
        5. **Yield of call**: ``yield foo()`` — container yields ``foo``'s
           output, so ``source=container, target=foo``.
        6. **Await of call**: ``await foo()`` — container awaits ``foo``'s
           output, so ``source=container, target=foo``.

        Note: ``impact_of_change`` in ``graph/query.py`` currently traverses
        only CALLS and IMPORTS edges, so DATAFLOW edges do not inflate impact
        results.  They are available for finer-grained data-dependency analysis.
        """
        container_qname = ".".join(self._scope_stack) if self._scope_stack else self.module_name
        container_id = self._make_id(container_qname)
        for child in ast.walk(parent):
            if isinstance(child, ast.Call):
                name = _call_target_name(child)
                if name:
                    name = self._resolve_call_target(name, class_node_id)
                    self.edges.append(ParsedEdge(
                        source=container_id,
                        target=name,
                        type="CALLS",
                        file_path=self.file_path,
                        line=getattr(child, "lineno", 0),
                    ))
                # Track class/function references passed as arguments.
                # Catches: isinstance(x, MyClass), warnings.warn(MyWarning, ...),
                # register(MyHandler), super().__init__(callback_fn), etc.
                for arg in child.args:
                    if isinstance(arg, ast.Name) and arg.id[:1].isupper():
                        self.edges.append(ParsedEdge(
                            source=container_id,
                            target=arg.id,
                            type="CALLS",
                            file_path=self.file_path,
                            line=getattr(child, "lineno", 0),
                        ))
            # Data flow: variable = function_call()
            if isinstance(child, ast.Assign):
                if isinstance(child.value, ast.Call):
                    call_name = _call_target_name(child.value)
                    if call_name:
                        call_name = self._resolve_call_target(call_name, class_node_id)
                        for target in child.targets:
                            if isinstance(target, ast.Name):
                                self.edges.append(ParsedEdge(
                                    source=container_id,
                                    target=call_name,
                                    type="DATAFLOW",
                                    file_path=self.file_path,
                                    line=getattr(child, "lineno", 0),
                                ))
            # Data flow: return function_call()
            if isinstance(child, ast.Return) and child.value:
                if isinstance(child.value, ast.Call):
                    call_name = _call_target_name(child.value)
                    if call_name:
                        call_name = self._resolve_call_target(call_name, class_node_id)
                        self.edges.append(ParsedEdge(
                            source=container_id,
                            target=call_name,
                            type="DATAFLOW",
                            file_path=self.file_path,
                            line=getattr(child, "lineno", 0),
                        ))
            # Data flow: function_call(other_call()) — nested calls
            if isinstance(child, ast.Call):
                for arg in child.args:
                    if isinstance(arg, ast.Call):
                        inner = _call_target_name(arg)
                        outer = _call_target_name(child)
                        if inner and outer:
                            inner = self._resolve_call_target(inner, class_node_id)
                            outer = self._resolve_call_target(outer, class_node_id)
                            self.edges.append(ParsedEdge(
                                source=inner,
                                target=outer,
                                type="DATAFLOW",
                                file_path=self.file_path,
                                line=getattr(child, "lineno", 0),
                            ))
                # keyword args: func(x=other_call())
                for kw in child.keywords:
                    if isinstance(kw.value, ast.Call):
                        inner = _call_target_name(kw.value)
                        outer = _call_target_name(child)
                        if inner and outer:
                            inner = self._resolve_call_target(inner, class_node_id)
                            outer = self._resolve_call_target(outer, class_node_id)
                            self.edges.append(ParsedEdge(
                                source=inner,
                                target=outer,
                                type="DATAFLOW",
                                file_path=self.file_path,
                                line=getattr(child, "lineno", 0),
                            ))
            # Data flow: yield call()
            if isinstance(child, ast.Yield) and child.value and isinstance(child.value, ast.Call):
                call_name = _call_target_name(child.value)
                if call_name:
                    call_name = self._resolve_call_target(call_name, class_node_id)
                    self.edges.append(ParsedEdge(
                        source=container_id,
                        target=call_name,
                        type="DATAFLOW",
                        file_path=self.file_path,
                        line=getattr(child, "lineno", 0),
                    ))
            # Data flow: await call()
            if isinstance(child, ast.Await) and isinstance(child.value, ast.Call):
                call_name = _call_target_name(child.value)
                if call_name:
                    call_name = self._resolve_call_target(call_name, class_node_id)
                    self.edges.append(ParsedEdge(
                        source=container_id,
                        target=call_name,
                        type="DATAFLOW",
                        file_path=self.file_path,
                        line=getattr(child, "lineno", 0),
                    ))

    def visit_Assign(self, node: ast.Assign) -> None:
        # Only capture module-level variable assignments
        if self._scope_stack:
            self.generic_visit(node)
            return
        for target in node.targets:
            if isinstance(target, ast.Name):
                if target.id == "__all__":
                    continue
                qname = self._qualified_name(target.id)
                node_id = self._make_id(qname)
                pnode = ParsedNode(
                    id=node_id,
                    name=target.id,
                    qualified_name=qname,
                    type="variable",
                    file_path=self.file_path,
                    line_start=node.lineno,
                    line_end=node.end_lineno or node.lineno,
                    is_exported=self._is_exported(target.id),
                )
                self.nodes.append(pnode)
                file_node_id = self._make_id(self.module_name)
                self.edges.append(ParsedEdge(
                    source=file_node_id,
                    target=node_id,
                    type="CONTAINS",
                    file_path=self.file_path,
                    line=node.lineno,
                ))
        self.generic_visit(node)

    def visit_AnnAssign(self, node: ast.AnnAssign) -> None:
        if self._scope_stack:
            self.generic_visit(node)
            return
        if isinstance(node.target, ast.Name):
            name = node.target.id
            qname = self._qualified_name(name)
            node_id = self._make_id(qname)
            pnode = ParsedNode(
                id=node_id,
                name=name,
                qualified_name=qname,
                type="variable",
                file_path=self.file_path,
                line_start=node.lineno,
                line_end=node.end_lineno or node.lineno,
                is_exported=self._is_exported(name),
            )
            self.nodes.append(pnode)
            file_node_id = self._make_id(self.module_name)
            self.edges.append(ParsedEdge(
                source=file_node_id,
                target=node_id,
                type="CONTAINS",
                file_path=self.file_path,
                line=node.lineno,
            ))
        self.generic_visit(node)


def parse_file(path: Path, repo_root: Path) -> ParsedFile:
    """Parse a Python file and return a ParsedFile with nodes and edges."""
    rel_path = path.relative_to(repo_root).as_posix()
    source = path.read_bytes()
    hash_val = content_hash(source)

    try:
        tree = ast.parse(source, filename=str(path))
    except (SyntaxError, ValueError):
        # ValueError: null bytes in source. SyntaxError: bad syntax.
        # Retry with explicit UTF-8 decoding and null-byte stripping.
        try:
            text = source.decode("utf-8", errors="replace").replace("\x00", "")
            tree = ast.parse(text, filename=str(path))
        except (SyntaxError, ValueError):
            return ParsedFile(path=rel_path, content_hash=hash_val, line_count=source.count(b"\n") + 1)

    line_count = source.count(b"\n") + 1

    # Derive a module-like name from the relative path
    module_name = rel_path.replace("/", ".").removesuffix(".py")
    if module_name.endswith(".__init__"):
        module_name = module_name.removesuffix(".__init__")

    # Create a file-level node
    try:
        source_text_for_comments = source.decode("utf-8", errors="replace")
    except Exception:
        source_text_for_comments = ""
    significant_comments = _extract_significant_comments(source_text_for_comments)
    file_docstring = _get_docstring(tree)
    if significant_comments:
        comment_block = " | ".join(significant_comments)
        if file_docstring:
            file_docstring += f" [Comments: {comment_block}]"
        else:
            file_docstring = f"[Comments: {comment_block}]"

    file_node = ParsedNode(
        id=f"{rel_path}::{module_name}",
        name=module_name.rsplit(".", 1)[-1],
        qualified_name=module_name,
        type="file",
        file_path=rel_path,
        line_start=1,
        line_end=line_count,
        docstring=file_docstring,
        is_exported=True,
    )

    visitor = PythonVisitor(file_path=rel_path, module_name=module_name)
    visitor.visit(tree)

    nodes = [file_node] + visitor.nodes
    edges = visitor.edges

    # Extract MongoDB collection references
    try:
        source_text = source.decode("utf-8", errors="replace")
    except Exception:
        source_text = ""
    collections = _extract_mongo_collections(source_text)
    file_node_id = f"{rel_path}::{module_name}"
    for coll_name in collections:
        edges.append(ParsedEdge(
            source=file_node_id,
            target=f"mongodb:{coll_name}",
            type="DATAFLOW",
            file_path=rel_path,
            line=0,
        ))

    return ParsedFile(
        path=rel_path,
        content_hash=hash_val,
        nodes=nodes,
        edges=edges,
        line_count=line_count,
    )


class PythonParser(BaseParser):
    """BaseParser wrapper around the Python AST parser."""

    def extensions(self) -> frozenset[str]:
        return frozenset({".py"})

    def parse(self, path: Path, repo_root: Path) -> ParsedFile:
        return parse_file(path, repo_root)
