"""PL/SQL parser for Oracle stored procedure analysis.

Extracts packages, procedures, functions, cursors, and relationships
from PL/SQL source files (.pls, .plb, .pks, .pkb).

Regex-based. Expected accuracy ~75% on real-world code.

Known limitations:
- Nested anonymous blocks: only outer block parsed
- BULK COLLECT / FORALL: recognized but parameters not extracted
- Dynamic SQL (EXECUTE IMMEDIATE): flagged as warning
- Autonomous transactions: detected as metadata only
"""

from __future__ import annotations

import re
from pathlib import Path

from codebrain.parser.base import BaseParser
from codebrain.parser.models import ParsedEdge, ParsedFile, ParsedNode
from codebrain.utils import content_hash

# ---------------------------------------------------------------------------
# Regex patterns
# ---------------------------------------------------------------------------

_CREATE_PACKAGE_RE = re.compile(
    r"CREATE\s+(?:OR\s+REPLACE\s+)?PACKAGE\s+(?:BODY\s+)?(\w+)",
    re.IGNORECASE,
)

_PACKAGE_BODY_RE = re.compile(
    r"CREATE\s+(?:OR\s+REPLACE\s+)?PACKAGE\s+BODY\s+",
    re.IGNORECASE,
)

_PROCEDURE_RE = re.compile(
    r"(?:CREATE\s+(?:OR\s+REPLACE\s+)?)?PROCEDURE\s+(\w+)"
    r"\s*(?:\(([^)]*)\))?",
    re.IGNORECASE,
)

_FUNCTION_RE = re.compile(
    r"(?:CREATE\s+(?:OR\s+REPLACE\s+)?)?FUNCTION\s+(\w+)"
    r"\s*(?:\(([^)]*)\))?"
    r"\s+RETURN\s+(\w+)",
    re.IGNORECASE,
)

_CURSOR_RE = re.compile(
    r"CURSOR\s+(\w+)\s+IS",
    re.IGNORECASE,
)

_PROC_CALL_RE = re.compile(
    r"\b(\w+)\s*\(", re.IGNORECASE
)

_EXEC_IMMEDIATE_RE = re.compile(
    r"EXECUTE\s+IMMEDIATE", re.IGNORECASE,
)

_TYPE_REF_RE = re.compile(
    r"(\w+)\.(\w+)%(?:TYPE|ROWTYPE)", re.IGNORECASE,
)

_EXCEPTION_RE = re.compile(
    r"\bEXCEPTION\b", re.IGNORECASE,
)

_PRAGMA_AUTONOMOUS_RE = re.compile(
    r"PRAGMA\s+AUTONOMOUS_TRANSACTION", re.IGNORECASE,
)

# Parameter direction
_PARAM_RE = re.compile(
    r"(\w+)\s+(IN\s+OUT|IN|OUT)?\s*(\w+(?:\([^)]*\))?)?",
    re.IGNORECASE,
)


class PLSQLParser(BaseParser):
    """Parser for PL/SQL source files (.pls, .plb, .pks, .pkb)."""

    def extensions(self) -> frozenset[str]:
        return frozenset({".pls", ".plb", ".pks", ".pkb"})

    def parse(self, path: Path, repo_root: Path) -> ParsedFile:
        rel_path = str(path.relative_to(repo_root)).replace("\\", "/")
        try:
            raw = path.read_text(encoding="utf-8", errors="replace")
        except Exception:
            return ParsedFile(path=rel_path, content_hash="", line_count=0)

        chash = content_hash(raw.encode("utf-8"))
        line_count = len(raw.splitlines())

        nodes: list[ParsedNode] = []
        edges: list[ParsedEdge] = []

        module_name = Path(rel_path).stem
        file_id = f"{rel_path}::{module_name}"
        is_body = bool(_PACKAGE_BODY_RE.search(raw))
        is_spec = not is_body

        # File node
        nodes.append(ParsedNode(
            id=file_id, name=module_name, qualified_name=module_name,
            type="file", file_path=rel_path,
            line_start=1, line_end=line_count,
            is_exported=True,
        ))

        # Package
        pkg_match = _CREATE_PACKAGE_RE.search(raw)
        if pkg_match:
            pkg_name = pkg_match.group(1)
            pkg_id = f"{rel_path}::{pkg_name}"
            pkg_type = "spec" if is_spec else "body"
            nodes.append(ParsedNode(
                id=pkg_id, name=pkg_name, qualified_name=pkg_name,
                type="class", file_path=rel_path,
                line_start=1, line_end=line_count,
                is_exported=True,
                summary=f"package_{pkg_type}",
            ))
            edges.append(ParsedEdge(
                source=file_id, target=pkg_id,
                type="CONTAINS", file_path=rel_path, line=1,
            ))
            file_id = pkg_id  # subsequent items belong to package

        # Procedures
        for m in _PROCEDURE_RE.finditer(raw):
            proc_name = m.group(1)
            params_str = m.group(2) or ""
            sig = self._parse_params(params_str)
            proc_id = f"{rel_path}::{proc_name}"
            nodes.append(ParsedNode(
                id=proc_id, name=proc_name, qualified_name=proc_name,
                type="function", file_path=rel_path,
                line_start=1, line_end=1,
                signature=sig,
                is_exported=is_spec,
                summary="procedure",
            ))
            edges.append(ParsedEdge(
                source=file_id, target=proc_id,
                type="CONTAINS", file_path=rel_path, line=1,
            ))

        # Functions
        for m in _FUNCTION_RE.finditer(raw):
            func_name = m.group(1)
            params_str = m.group(2) or ""
            ret_type = m.group(3)
            sig = self._parse_params(params_str)
            if ret_type:
                sig = f"{sig} -> {ret_type}" if sig else f"() -> {ret_type}"
            func_id = f"{rel_path}::{func_name}"
            nodes.append(ParsedNode(
                id=func_id, name=func_name, qualified_name=func_name,
                type="function", file_path=rel_path,
                line_start=1, line_end=1,
                signature=sig,
                is_exported=is_spec,
                summary="function",
            ))
            edges.append(ParsedEdge(
                source=file_id, target=func_id,
                type="CONTAINS", file_path=rel_path, line=1,
            ))

        # Cursors
        for m in _CURSOR_RE.finditer(raw):
            cursor_name = m.group(1)
            cursor_id = f"{rel_path}::{cursor_name}"
            nodes.append(ParsedNode(
                id=cursor_id, name=cursor_name, qualified_name=cursor_name,
                type="variable", file_path=rel_path,
                line_start=1, line_end=1,
                summary="cursor",
            ))

        # %TYPE / %ROWTYPE references → DATAFLOW
        for m in _TYPE_REF_RE.finditer(raw):
            table_name = m.group(1)
            edges.append(ParsedEdge(
                source=file_id, target=table_name,
                type="DATAFLOW", file_path=rel_path, line=1,
            ))

        # EXECUTE IMMEDIATE → warning metadata
        if _EXEC_IMMEDIATE_RE.search(raw):
            nodes[0].summary = (nodes[0].summary + "|" if nodes[0].summary else "") + "dynamic_sql_warning"

        # EXCEPTION handlers → metadata
        exc_count = len(_EXCEPTION_RE.findall(raw))
        if exc_count:
            nodes[0].summary = (nodes[0].summary + "|" if nodes[0].summary else "") + f"exception_handlers={exc_count}"

        # PRAGMA AUTONOMOUS_TRANSACTION → metadata
        if _PRAGMA_AUTONOMOUS_RE.search(raw):
            nodes[0].summary = (nodes[0].summary + "|" if nodes[0].summary else "") + "autonomous_transaction"

        return ParsedFile(
            path=rel_path, content_hash=chash,
            nodes=nodes, edges=edges, line_count=line_count,
        )

    @staticmethod
    def _parse_params(params_str: str) -> str:
        """Parse PL/SQL parameter list into signature string."""
        if not params_str.strip():
            return "()"
        parts = []
        for param in params_str.split(","):
            param = param.strip()
            if not param:
                continue
            tokens = param.split()
            if tokens:
                name = tokens[0]
                direction = ""
                ptype = ""
                rest = tokens[1:]
                for i, t in enumerate(rest):
                    if t.upper() in ("IN", "OUT"):
                        if i + 1 < len(rest) and rest[i + 1].upper() == "OUT":
                            direction = "IN OUT"
                        elif t.upper() == "OUT":
                            direction = "OUT"
                        else:
                            direction = "IN"
                    elif t.upper() not in ("IN", "OUT"):
                        ptype = t
                if direction:
                    parts.append(f"{name} {direction} {ptype}".strip())
                else:
                    parts.append(f"{name} {ptype}".strip())
        return f"({', '.join(parts)})"
