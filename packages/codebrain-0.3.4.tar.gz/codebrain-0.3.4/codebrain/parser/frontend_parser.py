"""Frontend component post-processor — enriches the graph with frontend structure.

NOT a BaseParser. Runs after the TS/JS parser has populated the graph.
Upgrades generic CALLS edges to RENDERS, extracts props, routes, state
management, and API calls from JSX/TSX/JS/TS files.
"""

from __future__ import annotations

import json
import re
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path

from codebrain.graph.store import GraphStore
from codebrain.logging import get_logger

_log = get_logger("frontend_parser")

# ---------------------------------------------------------------------------
# Result data
# ---------------------------------------------------------------------------


@dataclass
class FrontendEnrichmentResult:
    """Summary of changes the post-processor made to the graph."""

    renders_created: int = 0
    props_extracted: int = 0
    routes_found: int = 0
    state_edges: int = 0
    api_calls: int = 0
    components_tagged: int = 0


# ---------------------------------------------------------------------------
# Patterns
# ---------------------------------------------------------------------------

# PascalCase — starts with uppercase, at least 2 chars, not ALL_CAPS
_PASCAL_RE = re.compile(r"^[A-Z][a-zA-Z0-9]+$")

# JSX self-closing or opening: <ComponentName ... />  or <ComponentName ...>
_JSX_COMPONENT_RE = re.compile(
    r"<([A-Z][a-zA-Z0-9]+)\s*(?:[^>]*?)(?:/>|>)", re.DOTALL
)

# JSX attributes: propName={expr} or propName="str"
_JSX_ATTR_RE = re.compile(
    r"\b([a-zA-Z_]\w*)=(?:\{[^}]*\}|\"[^\"]*\"|'[^']*')"
)

# React Router JSX patterns (single-line — kept for JSX <Route /> tags)
_REACT_ROUTE_JSX_PATTERNS = [
    # <Route path="/x" component={Comp} />
    re.compile(
        r'<Route\s+[^>]*path=["\']([^"\']+)["\'][^>]*component=\{(\w+)\}',
        re.DOTALL,
    ),
    # <Route path="/x" element={<Comp />} />
    re.compile(
        r'<Route\s+[^>]*path=["\']([^"\']+)["\'][^>]*element=\{<(\w+)',
        re.DOTALL,
    ),
]

# ---------------------------------------------------------------------------
# Block-based route parsing (SPEC-M29)
# ---------------------------------------------------------------------------

# Route array detection patterns
_ROUTES_ARRAY_RE = re.compile(
    r"(?:const|let|var)\s+routes\s*=\s*\[", re.DOTALL
)
_CREATE_ROUTER_INLINE_RE = re.compile(
    r"createRouter\s*\(\s*\{[^}]*routes:\s*\[", re.DOTALL
)
_CREATE_BROWSER_ROUTER_RE = re.compile(
    r"createBrowserRouter\s*\(\s*\[", re.DOTALL
)

# Within a route object block
_ROUTE_PATH_RE = re.compile(r"""path:\s*['"]([^'"]+)['"]""")
_ROUTE_COMPONENT_DIRECT_RE = re.compile(r"component:\s*([A-Z]\w+)")
_ROUTE_COMPONENT_LAZY_RE = re.compile(
    r"""component:\s*\(\)\s*=>\s*import\s*\(\s*['"]([^'"]+)['"]"""
)
_ROUTE_ELEMENT_RE = re.compile(r"element:\s*<(\w+)")
_ROUTE_CHILDREN_RE = re.compile(r"children:\s*\[")

# Redux patterns
_USE_SELECTOR_RE = re.compile(
    r"useSelector\s*\(\s*(?:\(?\s*\w+\s*\)?\s*=>|function)\s*\w*[\s.]*(\w+)\.(\w+)"
)
_DISPATCH_RE = re.compile(
    r"dispatch\s*\(\s*(\w+)\s*\("
)
_CREATE_SLICE_RE = re.compile(
    r"createSlice\s*\(\s*\{\s*name:\s*['\"](\w+)['\"]"
)

# Old-style Redux: connect(mapStateToProps, mapDispatchToProps)(Component) — SPEC-M31
_CONNECT_WRAP_RE = re.compile(
    r"connect\s*\(\s*(\w+|null)\s*(?:,\s*(\w+|\{[^}]*\}|null))?\s*\)\s*\(\s*(\w+)\s*\)"
)
# Fallback: connect() without wrapping (still useful)
_CONNECT_RE = re.compile(
    r"connect\s*\(\s*(\w+|null)\s*(?:,\s*(\w+|null))?\s*\)"
)
# mapStateToProps: state.xxx or state.xxx.yyy
_MAP_STATE_RE = re.compile(
    r"state\.(\w+)(?:\.(\w+))?",
)
# dispatch({ type: ACTION_NAME }) inside mapDispatchToProps
_DISPATCH_TYPE_RE = re.compile(
    r"dispatch\s*\(\s*\{\s*type:\s*(\w+)"
)
# dispatch(actionCreator(...)) inside mapDispatchToProps
_DISPATCH_CREATOR_RE = re.compile(
    r"dispatch\s*\(\s*(\w+)\s*\("
)

# Pinia/Vuex patterns
_DEFINE_STORE_RE = re.compile(
    r"defineStore\s*\(\s*['\"](\w+)['\"]"
)
_USE_STORE_RE = re.compile(
    r"(?:const|let|var)\s+\w+\s*=\s*(use\w+Store)\s*\("
)

# API call patterns
_FETCH_PATTERNS = [
    re.compile(r"""fetch\s*\(\s*['"`]([^'"`]+)['"`]"""),
    re.compile(r"""axios\.(?:get|post|put|patch|delete)\s*\(\s*['"`]([^'"`]+)['"`]"""),
    re.compile(r"""useSWR\s*\(\s*['"`]([^'"`]+)['"`]"""),
    re.compile(r"""useQuery\s*\([^)]*fetch\s*\(\s*['"`]([^'"`]+)['"`]"""),
    re.compile(r"""\.(?:get|post|put|patch|delete)\s*\(\s*['"`]([^'"`]+)['"`]"""),
]

# Custom hook pattern
_CUSTOM_HOOK_RE = re.compile(r"^use[A-Z]\w*$")

# ---------------------------------------------------------------------------
# Helpers — SPEC-M29 (balanced extraction, route parsing)
# ---------------------------------------------------------------------------


def _extract_balanced(source: str, start: int, open_char: str, close_char: str) -> str | None:
    """Extract content between balanced brackets starting at `start`."""
    if start >= len(source) or source[start] != open_char:
        return None
    depth = 0
    in_string = False
    string_char = ""
    for i in range(start, len(source)):
        ch = source[i]
        if in_string:
            if ch == "\\" and i + 1 < len(source):
                continue  # skip escaped chars (handled by next iteration)
            if ch == string_char:
                in_string = False
            continue
        if ch in ("'", '"', "`"):
            in_string = True
            string_char = ch
            continue
        if ch == open_char:
            depth += 1
        elif ch == close_char:
            depth -= 1
            if depth == 0:
                return source[start + 1 : i]
    return None


def _split_objects(arr_body: str) -> list[str]:
    """Split array body into individual { ... } object blocks."""
    blocks: list[str] = []
    depth = 0
    start = None
    in_string = False
    string_char = ""
    for i, ch in enumerate(arr_body):
        if in_string:
            if ch == "\\" and i + 1 < len(arr_body):
                continue
            if ch == string_char:
                in_string = False
            continue
        if ch in ("'", '"', "`"):
            in_string = True
            string_char = ch
            continue
        if ch == "{":
            if depth == 0:
                start = i
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0 and start is not None:
                blocks.append(arr_body[start : i + 1])
                start = None
    return blocks


def _filename_to_component(import_path: str) -> str:
    """Extract component name from import path.

    '@/views/TablesView.vue' → 'TablesView'
    '../pages/Home'          → 'Home'
    './Dashboard.tsx'        → 'Dashboard'
    """
    basename = import_path.rsplit("/", 1)[-1]
    name = basename.split(".")[0]
    return name


# ---------------------------------------------------------------------------
# Helpers — SPEC-M31 (connect() parsing)
# ---------------------------------------------------------------------------


def _find_function_body(source: str, fn_name: str) -> str | None:
    """Find the body of a named function/const arrow function."""
    # Match: const fnName = state => ({...}) or const fnName = (state) => ({...})
    # or: function fnName(state) { return {...} }
    # or: const fnName = state => { return {...} }
    patterns = [
        # Arrow: const fn = state => ({...}) or const fn = (state) => ({...})
        re.compile(
            rf"(?:const|let|var)\s+{re.escape(fn_name)}\s*=\s*"
            r"(?:\(?\s*\w+\s*\)?\s*=>)",
            re.DOTALL,
        ),
        # Function declaration: function fn(state) {
        re.compile(
            rf"function\s+{re.escape(fn_name)}\s*\(",
            re.DOTALL,
        ),
    ]
    for pat in patterns:
        m = pat.search(source)
        if not m:
            continue
        # Find the opening ( or { after the arrow/function header
        rest = source[m.end():]
        # Look for the body — could start with ( for implicit return or { for block
        for i, ch in enumerate(rest):
            if ch == "(":
                body = _extract_balanced(source, m.end() + i, "(", ")")
                if body:
                    return body
            elif ch == "{":
                body = _extract_balanced(source, m.end() + i, "{", "}")
                if body:
                    return body
    return None


def _parse_map_state_to_props(source: str, fn_name: str) -> list[str]:
    """Extract state.xxx.yyy references from a mapStateToProps function."""
    fn_body = _find_function_body(source, fn_name)
    if not fn_body:
        return []

    subscriptions: list[str] = []
    seen: set[str] = set()
    for m in _MAP_STATE_RE.finditer(fn_body):
        slice_name = m.group(1)
        field_name = m.group(2)
        target = f"{slice_name}.{field_name}" if field_name else slice_name
        if target not in seen:
            seen.add(target)
            subscriptions.append(target)
    return subscriptions


def _parse_map_dispatch_to_props(source: str, fn_name: str) -> list[str]:
    """Extract dispatched actions from a mapDispatchToProps function."""
    fn_body = _find_function_body(source, fn_name)
    if not fn_body:
        return []

    actions: list[str] = []
    seen: set[str] = set()

    # dispatch({ type: ACTION_NAME, ... })
    for m in _DISPATCH_TYPE_RE.finditer(fn_body):
        action = m.group(1)
        if action not in seen:
            seen.add(action)
            actions.append(action)

    # dispatch(actionCreator(...))
    for m in _DISPATCH_CREATOR_RE.finditer(fn_body):
        action = m.group(1)
        # Skip 'dispatch' itself and already-seen
        if action != "dispatch" and action not in seen:
            seen.add(action)
            actions.append(action)

    return actions


def _parse_dispatch_object_shorthand(obj_str: str) -> list[str]:
    """Parse { action1, action2 } shorthand for mapDispatchToProps."""
    # Strip braces
    inner = obj_str.strip().strip("{}")
    actions = []
    for part in inner.split(","):
        name = part.strip()
        if name and name.isidentifier():
            actions.append(name)
    return actions


# ---------------------------------------------------------------------------
# Post-processor
# ---------------------------------------------------------------------------


class FrontendComponentParser:
    """Post-processes TS parser output to extract frontend structure.

    Reads source files and the existing graph, then:
    1. Upgrades JSX CALLS to RENDERS edges
    2. Extracts PASSES_PROP edges from JSX attributes
    3. Extracts ROUTES_TO edges from router patterns
    4. Extracts DISPATCHES/SUBSCRIBES edges from state management
    5. Extracts FETCHES edges from API calls
    6. Tags component nodes with decorator metadata
    """

    def __init__(self, store: GraphStore, repo_root: Path | None = None) -> None:
        self.store = store
        self.repo_root = repo_root or Path.cwd()

    def enrich(self) -> FrontendEnrichmentResult:
        """Run all frontend enrichment passes on the graph."""
        result = FrontendEnrichmentResult()

        # Load all data
        all_nodes = self.store.get_all_nodes()
        all_edges = self.store.get_all_edges()

        # Index by name for fast lookup
        node_by_id: dict[str, dict] = {n["id"]: n for n in all_nodes}
        _nodes_by_name = defaultdict(list)
        for n in all_nodes:
            _nodes_by_name[n["name"]].append(n)
        nodes_by_name = dict(_nodes_by_name)

        _nodes_by_file = defaultdict(list)
        for n in all_nodes:
            _nodes_by_file[n["file_path"]].append(n)
        nodes_by_file = dict(_nodes_by_file)

        edges_by_file = defaultdict(list)
        for e in all_edges:
            edges_by_file[e["file_path"]].append(e)

        # Identify frontend files
        frontend_exts = {".tsx", ".jsx", ".ts", ".js", ".vue"}
        frontend_files = [
            fp for fp in nodes_by_file
            if Path(fp).suffix.lower() in frontend_exts
        ]

        if not frontend_files:
            _log.debug("No frontend files found")
            return result

        _log.info("Enriching %d frontend files", len(frontend_files))

        # Pass 1: Upgrade JSX CALLS to RENDERS
        result.renders_created = self._upgrade_jsx_calls_to_renders(
            all_edges, nodes_by_name, node_by_id
        )

        # Pass 2-5: Source-level analysis
        for fp in frontend_files:
            source = self._read_source(fp)
            if not source:
                continue

            file_nodes = nodes_by_file.get(fp, [])
            # Find the container node (function/class that's the component)
            container_id = self._find_component_container(file_nodes, fp)
            if not container_id:
                # Use file-level module node
                container_id = f"{fp}::__module__"

            # Pass 1b: Create RENDERS edges from JSX source (supplements CALLS upgrade)
            renders = self._extract_renders_from_jsx(source, fp, container_id, nodes_by_name)
            result.renders_created += renders

            # Pass 2: Extract props from JSX
            props = self._extract_props_from_jsx(source, fp, container_id, nodes_by_name)
            result.props_extracted += props

            # Pass 3: Extract routes
            routes = self._extract_routes(source, fp, container_id, nodes_by_name)
            result.routes_found += routes

            # Pass 4: Extract state management
            state = self._extract_state_management(source, fp, container_id)
            result.state_edges += state

            # Pass 5: Extract API calls
            apis = self._extract_api_calls(source, fp, container_id)
            result.api_calls += apis

        # Pass 6: Tag component nodes
        result.components_tagged = self._tag_component_nodes(
            all_nodes, nodes_by_name, all_edges
        )

        _log.info(
            "Frontend enrichment: %d RENDERS, %d props, %d routes, "
            "%d state edges, %d API calls, %d components tagged",
            result.renders_created, result.props_extracted, result.routes_found,
            result.state_edges, result.api_calls, result.components_tagged,
        )
        return result

    # ------------------------------------------------------------------
    # Pass 1: Upgrade JSX calls to RENDERS
    # ------------------------------------------------------------------

    def _upgrade_jsx_calls_to_renders(
        self,
        all_edges: list[dict],
        nodes_by_name: dict[str, list[dict]],
        node_by_id: dict[str, dict],
    ) -> int:
        """Find CALLS edges where target is PascalCase component; upgrade to RENDERS."""
        count = 0
        for edge in all_edges:
            if edge["type"] != "CALLS":
                continue
            target_name = edge["target"]
            # Extract bare name from qualified paths
            bare = target_name.rsplit("::", 1)[-1].rsplit(".", 1)[-1]
            if not _PASCAL_RE.match(bare):
                continue
            # Check if target is a known component node
            if bare in nodes_by_name or target_name in node_by_id:
                self.store.conn.execute(
                    "UPDATE edges SET type = 'RENDERS' "
                    "WHERE source = ? AND target = ? AND type = 'CALLS' AND file_path = ?",
                    (edge["source"], edge["target"], edge["file_path"]),
                )
                count += 1
        if count:
            self.store.conn.commit()
        return count

    # ------------------------------------------------------------------
    # Pass 1b: Extract RENDERS from JSX source directly
    # ------------------------------------------------------------------

    def _extract_renders_from_jsx(
        self,
        source: str,
        file_path: str,
        container_id: str,
        nodes_by_name: dict[str, list[dict]],
    ) -> int:
        """Scan source for JSX component usage and create RENDERS edges.

        Uses line-range attribution (SPEC-M30) to assign JSX references
        to the correct parent component in multi-component files.
        """
        # Build line ranges for this file
        file_nodes = self.store.conn.execute(
            "SELECT id, name, type, line_start, line_end FROM nodes WHERE file_path = ?",
            (file_path,),
        ).fetchall()
        file_node_dicts = [
            {"id": r[0], "name": r[1], "type": r[2],
             "line_start": r[3], "line_end": r[4]}
            for r in file_nodes
        ]
        ranges = self._build_component_ranges(file_node_dicts)

        count = 0
        # Track (owner, target) pairs to avoid duplicates
        seen_pairs: set[tuple[str, str]] = set()

        for match in _JSX_COMPONENT_RE.finditer(source):
            component_name = match.group(1)
            # Only create RENDERS if target is a known node
            if component_name not in nodes_by_name:
                continue
            line = source[:match.start()].count("\n") + 1

            # Find which component owns this JSX usage (M30)
            owner = self._find_container_at_line(ranges, line)
            if not owner:
                owner = container_id

            # Prevent self-renders (M30)
            owner_name = owner.rsplit("::", 1)[-1]
            if owner_name == component_name:
                continue

            pair = (owner, component_name)
            if pair in seen_pairs:
                continue
            seen_pairs.add(pair)

            # Check if RENDERS edge already exists (from Pass 1 upgrade)
            existing = self.store.conn.execute(
                "SELECT 1 FROM edges WHERE source = ? AND target = ? AND type = 'RENDERS' AND file_path = ?",
                (owner, component_name, file_path),
            ).fetchone()
            if existing:
                continue

            self.store.conn.execute(
                "INSERT OR IGNORE INTO edges (source, target, type, file_path, line) "
                "VALUES (?, ?, 'RENDERS', ?, ?)",
                (owner, component_name, file_path, line),
            )
            count += 1

        if count:
            self.store.conn.commit()
        return count

    # ------------------------------------------------------------------
    # Pass 2: Extract props from JSX
    # ------------------------------------------------------------------

    def _extract_props_from_jsx(
        self,
        source: str,
        file_path: str,
        container_id: str,
        nodes_by_name: dict[str, list[dict]],
    ) -> int:
        """Extract PASSES_PROP edges from JSX attributes."""
        count = 0
        # Find all JSX component usages
        for match in _JSX_COMPONENT_RE.finditer(source):
            component_name = match.group(1)
            jsx_text = match.group(0)
            line = source[:match.start()].count("\n") + 1

            # Extract attributes
            for attr_match in _JSX_ATTR_RE.finditer(jsx_text):
                prop_name = attr_match.group(1)
                # Skip event handlers and common noise
                if prop_name in ("key", "ref", "className", "style", "id", "class"):
                    continue

                self.store.conn.execute(
                    "INSERT OR IGNORE INTO edges (source, target, type, file_path, line) "
                    "VALUES (?, ?, 'PASSES_PROP', ?, ?)",
                    (container_id, component_name, file_path, line),
                )
                count += 1

        if count:
            self.store.conn.commit()
        return count

    # ------------------------------------------------------------------
    # Pass 3: Extract routes (SPEC-M29 — block-based parsing)
    # ------------------------------------------------------------------

    def _extract_routes(
        self,
        source: str,
        file_path: str,
        container_id: str,
        nodes_by_name: dict[str, list[dict]],
    ) -> int:
        """Extract route definitions from JSX and route arrays."""
        count = 0
        seen_routes: set[tuple[str, str]] = set()

        # Part A: JSX <Route /> patterns (React Router)
        for pattern in _REACT_ROUTE_JSX_PATTERNS:
            for match in pattern.finditer(source):
                route_path = match.group(1)
                component_name = match.group(2)
                key = (route_path, component_name)
                if key in seen_routes:
                    continue
                seen_routes.add(key)
                line = source[:match.start()].count("\n") + 1
                self._create_route_node(
                    file_path, route_path, component_name, line
                )
                count += 1

        # Part B: Block-based route array parsing (Vue/React data API)
        count += self._extract_routes_from_arrays(
            source, file_path, seen_routes
        )

        if count:
            self.store.conn.commit()
        return count

    def _extract_routes_from_arrays(
        self,
        source: str,
        file_path: str,
        seen_routes: set[tuple[str, str]],
    ) -> int:
        """Parse route arrays with multi-line objects (SPEC-M29)."""
        count = 0

        # Find all route array start positions
        array_starts: list[int] = []
        for pattern in [
            _ROUTES_ARRAY_RE,
            _CREATE_ROUTER_INLINE_RE,
            _CREATE_BROWSER_ROUTER_RE,
        ]:
            for m in pattern.finditer(source):
                # Position of '['
                bracket_pos = source.rfind("[", m.start(), m.end())
                if bracket_pos >= 0:
                    array_starts.append(bracket_pos)

        for arr_start in array_starts:
            arr_body = _extract_balanced(source, arr_start, "[", "]")
            if not arr_body:
                continue
            arr_line_offset = source[:arr_start].count("\n")
            count += self._parse_route_blocks(
                arr_body, file_path, seen_routes, arr_line_offset
            )

        return count

    def _parse_route_blocks(
        self,
        arr_body: str,
        file_path: str,
        seen_routes: set[tuple[str, str]],
        line_offset: int,
    ) -> int:
        """Parse individual route objects from an array body."""
        count = 0
        route_blocks = _split_objects(arr_body)

        for block in route_blocks:
            path_match = _ROUTE_PATH_RE.search(block)
            if not path_match:
                continue
            route_path = path_match.group(1)

            component_name = self._extract_route_component(block)
            if not component_name:
                continue

            key = (route_path, component_name)
            if key in seen_routes:
                continue
            seen_routes.add(key)

            # Approximate line from block position in body
            block_pos = arr_body.find(block)
            line = line_offset + arr_body[:block_pos].count("\n") + 1

            self._create_route_node(
                file_path, route_path, component_name, line
            )
            count += 1

            # Recurse for nested children
            children_match = _ROUTE_CHILDREN_RE.search(block)
            if children_match:
                ch_start = block.find("[", children_match.start())
                if ch_start >= 0:
                    ch_body = _extract_balanced(block, ch_start, "[", "]")
                    if ch_body:
                        ch_offset = line_offset + arr_body[:block_pos].count("\n")
                        count += self._parse_route_blocks(
                            ch_body, file_path, seen_routes, ch_offset
                        )

        return count

    def _extract_route_component(self, block: str) -> str | None:
        """Extract component name from a route object block."""
        # Direct component reference
        m = _ROUTE_COMPONENT_DIRECT_RE.search(block)
        if m:
            return m.group(1)

        # Lazy import: component: () => import('...')
        m = _ROUTE_COMPONENT_LAZY_RE.search(block)
        if m:
            return _filename_to_component(m.group(1))

        # JSX element: element: <Component />
        m = _ROUTE_ELEMENT_RE.search(block)
        if m:
            return m.group(1)

        return None

    def _create_route_node(
        self, file_path: str, route_path: str, component_name: str, line: int
    ) -> None:
        """Create a route node + ROUTES_TO edge."""
        route_id = f"{file_path}::route:{route_path}"
        self.store.conn.execute(
            """INSERT OR REPLACE INTO nodes
               (id, name, qualified_name, type, file_path,
                line_start, line_end, signature, decorators, docstring,
                is_exported, summary)
               VALUES (?, ?, ?, 'route', ?, ?, ?, ?, '[]', '', 0, ?)""",
            (
                route_id, route_path, route_path, file_path,
                line, line, f"path={route_path}",
                f"route|path:{route_path}|component:{component_name}",
            ),
        )
        self.store.conn.execute(
            "INSERT OR IGNORE INTO edges (source, target, type, file_path, line) "
            "VALUES (?, ?, 'ROUTES_TO', ?, ?)",
            (route_id, component_name, file_path, line),
        )

    # ------------------------------------------------------------------
    # Pass 4: State management (SPEC-M31 — proper connect() parsing)
    # ------------------------------------------------------------------

    def _extract_state_management(
        self,
        source: str,
        file_path: str,
        container_id: str,
    ) -> int:
        """Extract Redux/Pinia/Vuex state management edges."""
        count = 0

        # Redux: createSlice → store node
        for match in _CREATE_SLICE_RE.finditer(source):
            slice_name = match.group(1)
            line = source[:match.start()].count("\n") + 1
            store_id = f"{file_path}::store:{slice_name}"
            self.store.conn.execute(
                """INSERT OR REPLACE INTO nodes
                   (id, name, qualified_name, type, file_path,
                    line_start, line_end, signature, decorators, docstring,
                    is_exported, summary)
                   VALUES (?, ?, ?, 'store', ?, ?, ?, '', ?, '', 1, ?)""",
                (
                    store_id, slice_name, slice_name, file_path,
                    line, line, json.dumps(["redux_slice"]),
                    f"store|redux|name:{slice_name}",
                ),
            )
            count += 1

        # Pinia: defineStore → store node
        for match in _DEFINE_STORE_RE.finditer(source):
            store_name = match.group(1)
            line = source[:match.start()].count("\n") + 1
            store_id = f"{file_path}::store:{store_name}"
            self.store.conn.execute(
                """INSERT OR REPLACE INTO nodes
                   (id, name, qualified_name, type, file_path,
                    line_start, line_end, signature, decorators, docstring,
                    is_exported, summary)
                   VALUES (?, ?, ?, 'store', ?, ?, ?, '', ?, '', 1, ?)""",
                (
                    store_id, store_name, store_name, file_path,
                    line, line, json.dumps(["pinia_store"]),
                    f"store|pinia|name:{store_name}",
                ),
            )
            count += 1

        # Redux: useSelector → SUBSCRIBES
        for match in _USE_SELECTOR_RE.finditer(source):
            slice_name = match.group(1)
            field_name = match.group(2)
            line = source[:match.start()].count("\n") + 1
            target = f"{slice_name}.{field_name}"
            self.store.conn.execute(
                "INSERT OR IGNORE INTO edges (source, target, type, file_path, line) "
                "VALUES (?, ?, 'SUBSCRIBES', ?, ?)",
                (container_id, target, file_path, line),
            )
            count += 1

        # Redux: dispatch → DISPATCHES (modern hooks)
        for match in _DISPATCH_RE.finditer(source):
            action_name = match.group(1)
            line = source[:match.start()].count("\n") + 1
            self.store.conn.execute(
                "INSERT OR IGNORE INTO edges (source, target, type, file_path, line) "
                "VALUES (?, ?, 'DISPATCHES', ?, ?)",
                (container_id, action_name, file_path, line),
            )
            count += 1

        # Pinia: useXxxStore → SUBSCRIBES
        for match in _USE_STORE_RE.finditer(source):
            store_hook = match.group(1)
            line = source[:match.start()].count("\n") + 1
            self.store.conn.execute(
                "INSERT OR IGNORE INTO edges (source, target, type, file_path, line) "
                "VALUES (?, ?, 'SUBSCRIBES', ?, ?)",
                (container_id, store_hook, file_path, line),
            )
            count += 1

        # Old-style Redux: connect(mapState, mapDispatch)(Component) — SPEC-M31
        count += self._extract_connect_pattern(source, file_path, container_id)

        if count:
            self.store.conn.commit()
        return count

    def _extract_connect_pattern(
        self,
        source: str,
        file_path: str,
        fallback_container: str,
    ) -> int:
        """Parse Redux connect(mapState, mapDispatch)(Component) — SPEC-M31."""
        count = 0

        # Try the full connect()(Component) pattern first
        for match in _CONNECT_WRAP_RE.finditer(source):
            map_state_fn = match.group(1)
            map_dispatch_raw = match.group(2)
            component_name = match.group(3)
            line = source[:match.start()].count("\n") + 1

            # Resolve component to a node ID
            component_id = self._find_node_id(component_name, file_path)
            if not component_id:
                component_id = fallback_container

            # Parse mapStateToProps → SUBSCRIBES
            if map_state_fn and map_state_fn != "null":
                subs = _parse_map_state_to_props(source, map_state_fn)
                for target in subs:
                    self.store.conn.execute(
                        "INSERT OR IGNORE INTO edges (source, target, type, file_path, line) "
                        "VALUES (?, ?, 'SUBSCRIBES', ?, ?)",
                        (component_id, target, file_path, line),
                    )
                    count += 1

            # Parse mapDispatchToProps → DISPATCHES
            if map_dispatch_raw and map_dispatch_raw != "null":
                # Check if it's object shorthand: { action1, action2 }
                if map_dispatch_raw.startswith("{"):
                    actions = _parse_dispatch_object_shorthand(map_dispatch_raw)
                else:
                    actions = _parse_map_dispatch_to_props(source, map_dispatch_raw)
                for target in actions:
                    self.store.conn.execute(
                        "INSERT OR IGNORE INTO edges (source, target, type, file_path, line) "
                        "VALUES (?, ?, 'DISPATCHES', ?, ?)",
                        (component_id, target, file_path, line),
                    )
                    count += 1

        return count

    def _find_node_id(self, name: str, file_path: str) -> str | None:
        """Find a node ID by name, preferring same-file matches."""
        row = self.store.conn.execute(
            "SELECT id FROM nodes WHERE name = ? AND file_path = ? LIMIT 1",
            (name, file_path),
        ).fetchone()
        if row:
            return row[0]
        row = self.store.conn.execute(
            "SELECT id FROM nodes WHERE name = ? LIMIT 1",
            (name,),
        ).fetchone()
        return row[0] if row else None

    # ------------------------------------------------------------------
    # Pass 5: API calls
    # ------------------------------------------------------------------

    def _extract_api_calls(
        self,
        source: str,
        file_path: str,
        container_id: str,
    ) -> int:
        """Extract FETCHES edges from fetch/axios/useSWR/useQuery calls."""
        count = 0
        seen_urls: set[str] = set()

        for pattern in _FETCH_PATTERNS:
            for match in pattern.finditer(source):
                url = match.group(1)
                if url in seen_urls:
                    continue
                # Skip non-API URLs
                if url.startswith(("http://", "https://")) and "/api/" not in url:
                    continue
                seen_urls.add(url)
                line = source[:match.start()].count("\n") + 1
                self.store.conn.execute(
                    "INSERT OR IGNORE INTO edges (source, target, type, file_path, line) "
                    "VALUES (?, ?, 'FETCHES', ?, ?)",
                    (container_id, url, file_path, line),
                )
                count += 1

        if count:
            self.store.conn.commit()
        return count

    # ------------------------------------------------------------------
    # Pass 6: Tag component nodes
    # ------------------------------------------------------------------

    def _tag_component_nodes(
        self,
        all_nodes: list[dict],
        nodes_by_name: dict[str, list[dict]],
        all_edges: list[dict],
    ) -> int:
        """Tag functions/classes as components based on evidence."""
        count = 0
        # Nodes that are RENDERS targets are components
        render_targets: set[str] = set()
        for e in all_edges:
            if e["type"] == "RENDERS":
                bare = e["target"].rsplit("::", 1)[-1].rsplit(".", 1)[-1]
                render_targets.add(bare)

        for node in all_nodes:
            if node["type"] not in ("function", "class"):
                continue
            name = node["name"]
            fp = node["file_path"]
            ext = Path(fp).suffix.lower()
            if ext not in (".tsx", ".jsx", ".ts", ".js", ".vue"):
                continue

            is_component = False
            decorator_tag = None

            # Evidence: PascalCase + in a JSX/TSX file (high confidence)
            if _PASCAL_RE.match(name) and ext in (".tsx", ".jsx"):
                is_component = True
                decorator_tag = "react_component"

            # Evidence: PascalCase + in a JS/TS file inside components/views/pages dir
            if _PASCAL_RE.match(name) and ext in (".js", ".ts"):
                fp_lower = fp.lower()
                if any(d in fp_lower for d in ("component", "view", "page", "layout", "widget")):
                    is_component = True
                    decorator_tag = "react_component"

            # Evidence: is a RENDERS target
            if name in render_targets:
                is_component = True
                if not decorator_tag:
                    decorator_tag = "react_component"

            # Evidence: custom hook
            if _CUSTOM_HOOK_RE.match(name):
                # Tag as hook, not component
                self.store.conn.execute(
                    "UPDATE nodes SET type = 'hook', decorators = ? WHERE id = ?",
                    (json.dumps(["custom_hook"]), node["id"]),
                )
                count += 1
                continue

            if is_component:
                existing_decorators = json.loads(node.get("decorators", "[]") or "[]")
                if decorator_tag and decorator_tag not in existing_decorators:
                    existing_decorators.append(decorator_tag)
                self.store.conn.execute(
                    "UPDATE nodes SET type = 'component', decorators = ? WHERE id = ?",
                    (json.dumps(existing_decorators), node["id"]),
                )
                count += 1

        if count:
            self.store.conn.commit()
        return count

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _read_source(self, file_path: str) -> str | None:
        """Read a source file relative to repo root."""
        full = self.repo_root / file_path
        try:
            return full.read_text(encoding="utf-8", errors="replace")
        except (OSError, IOError):
            return None

    def _find_component_container(
        self, file_nodes: list[dict], file_path: str
    ) -> str | None:
        """Find the main component node in a file (PascalCase function/class)."""
        for n in file_nodes:
            if n["type"] in ("function", "class") and _PASCAL_RE.match(n["name"]):
                return n["id"]
        return None

    # ------------------------------------------------------------------
    # SPEC-M30: Line-range attribution for multi-component files
    # ------------------------------------------------------------------

    def _build_component_ranges(
        self, file_nodes: list[dict]
    ) -> list[tuple[str, int, int]]:
        """Build sorted list of (node_id, line_start, line_end) for components."""
        ranges = []
        for n in file_nodes:
            if n["type"] in ("function", "class", "component"):
                if _PASCAL_RE.match(n["name"]):
                    start = n.get("line_start", 0)
                    end = n.get("line_end", start)
                    if start and end:
                        ranges.append((n["id"], start, end))
        # Sort by line_start descending — inner scopes first
        ranges.sort(key=lambda r: -r[1])
        return ranges

    def _find_container_at_line(
        self,
        ranges: list[tuple[str, int, int]],
        line: int,
    ) -> str | None:
        """Find the innermost component whose line range contains `line`."""
        for node_id, start, end in ranges:
            if start <= line <= end:
                return node_id
        return None
