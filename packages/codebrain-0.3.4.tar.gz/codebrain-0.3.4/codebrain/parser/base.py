"""Abstract base class for language parsers."""

from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path

from codebrain.parser.models import ParsedFile


class BaseParser(ABC):
    """Interface that all language parsers must implement.

    Third-party parsers register via the ``codebrain.parsers``
    entry-points group.
    """

    @abstractmethod
    def extensions(self) -> frozenset[str]:
        """Return the set of file extensions this parser handles.

        Example: ``frozenset({".py"})``
        """

    @abstractmethod
    def parse(self, path: Path, repo_root: Path) -> ParsedFile:
        """Parse *path* and return a fully populated ParsedFile."""
