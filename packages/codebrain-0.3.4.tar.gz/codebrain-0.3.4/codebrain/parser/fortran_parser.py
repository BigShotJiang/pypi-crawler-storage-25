"""Fortran parser for scientific/HPC codebase analysis.

Extracts modules, programs, subroutines, functions, and relationships
(CALLS, IMPORTS via USE, DATAFLOW via COMMON blocks).

Regex-based. Handles both fixed-format (.f, .for) and free-format (.f90+).
Expected accuracy ~85% on real-world code.

Known limitations:
- EQUIVALENCE: detected as warning, aliasing not modeled
- Computed GOTO: parsed as CALLS to label but rare in modern code
- Preprocessor (#include, #ifdef): not handled
- INTERFACE blocks: parsed as container but generic resolution not done
"""

from __future__ import annotations

import re
from pathlib import Path

from codebrain.parser.base import BaseParser
from codebrain.parser.models import ParsedEdge, ParsedFile, ParsedNode
from codebrain.utils import content_hash

# ---------------------------------------------------------------------------
# Regex patterns
# ---------------------------------------------------------------------------

_MODULE_RE = re.compile(
    r"^\s*MODULE\s+(\w+)\s*$", re.IGNORECASE | re.MULTILINE
)
_END_MODULE_RE = re.compile(
    r"^\s*END\s+MODULE", re.IGNORECASE | re.MULTILINE
)

_PROGRAM_RE = re.compile(
    r"^\s*PROGRAM\s+(\w+)", re.IGNORECASE | re.MULTILINE
)

_SUBROUTINE_RE = re.compile(
    r"^\s*(?:RECURSIVE\s+)?SUBROUTINE\s+(\w+)\s*(?:\(([^)]*)\))?",
    re.IGNORECASE | re.MULTILINE,
)

_FUNCTION_RE = re.compile(
    r"^\s*(?:[\w()]+\s+)?FUNCTION\s+(\w+)\s*(?:\(([^)]*)\))?"
    r"(?:\s+RESULT\s*\((\w+)\))?",
    re.IGNORECASE | re.MULTILINE,
)

_USE_RE = re.compile(
    r"^\s*USE\s+(\w+)(?:\s*,\s*ONLY\s*:\s*(.+))?",
    re.IGNORECASE | re.MULTILINE,
)

_CALL_RE = re.compile(
    r"\bCALL\s+(\w+)", re.IGNORECASE,
)

_COMMON_RE = re.compile(
    r"COMMON\s+/(\w+)/\s*(.+)", re.IGNORECASE,
)

_INTENT_RE = re.compile(
    r"INTENT\s*\(\s*(IN\s*OUT|IN|OUT)\s*\)", re.IGNORECASE,
)

_IMPLICIT_NONE_RE = re.compile(
    r"IMPLICIT\s+NONE", re.IGNORECASE,
)

_EQUIVALENCE_RE = re.compile(
    r"\bEQUIVALENCE\b", re.IGNORECASE,
)


class FortranParser(BaseParser):
    """Parser for Fortran source files."""

    def extensions(self) -> frozenset[str]:
        return frozenset({".f", ".f90", ".f95", ".f03", ".f08", ".for"})

    def parse(self, path: Path, repo_root: Path) -> ParsedFile:
        rel_path = str(path.relative_to(repo_root)).replace("\\", "/")
        try:
            raw = path.read_text(encoding="utf-8", errors="replace")
        except Exception:
            return ParsedFile(path=rel_path, content_hash="", line_count=0)

        chash = content_hash(raw.encode("utf-8"))
        lines = raw.splitlines()
        line_count = len(lines)

        # Detect and handle format
        is_fixed = self._is_fixed_format(path, raw)
        if is_fixed:
            code = self._strip_fixed_format(lines)
        else:
            code = raw

        nodes: list[ParsedNode] = []
        edges: list[ParsedEdge] = []

        module_name = Path(rel_path).stem
        file_id = f"{rel_path}::{module_name}"

        # File node
        nodes.append(ParsedNode(
            id=file_id, name=module_name, qualified_name=module_name,
            type="file", file_path=rel_path,
            line_start=1, line_end=line_count,
            is_exported=True,
        ))

        # PROGRAM
        for m in _PROGRAM_RE.finditer(code):
            prog_name = m.group(1)
            nodes[0].name = prog_name
            nodes[0].qualified_name = prog_name
            nodes[0].id = f"{rel_path}::{prog_name}"
            file_id = nodes[0].id

        # MODULE
        for m in _MODULE_RE.finditer(code):
            mod_name = m.group(1)
            if mod_name.upper() == "PROCEDURE":
                continue
            mod_id = f"{rel_path}::{mod_name}"
            nodes.append(ParsedNode(
                id=mod_id, name=mod_name, qualified_name=mod_name,
                type="class", file_path=rel_path,
                line_start=1, line_end=line_count,
                is_exported=True, summary="module",
            ))
            edges.append(ParsedEdge(
                source=file_id, target=mod_id,
                type="CONTAINS", file_path=rel_path, line=1,
            ))

        # SUBROUTINE
        for m in _SUBROUTINE_RE.finditer(code):
            sub_name = m.group(1)
            params = m.group(2) or ""
            sig = f"({params.strip()})" if params.strip() else "()"
            sub_id = f"{rel_path}::{sub_name}"
            nodes.append(ParsedNode(
                id=sub_id, name=sub_name, qualified_name=sub_name,
                type="function", file_path=rel_path,
                line_start=1, line_end=1,
                signature=sig, is_exported=True,
                summary="subroutine",
            ))
            edges.append(ParsedEdge(
                source=file_id, target=sub_id,
                type="CONTAINS", file_path=rel_path, line=1,
            ))

        # FUNCTION
        for m in _FUNCTION_RE.finditer(code):
            func_name = m.group(1)
            if func_name.upper() in ("IF", "DO", "WHILE", "RESULT"):
                continue
            params = m.group(2) or ""
            result_var = m.group(3) or ""
            sig = f"({params.strip()})" if params.strip() else "()"
            if result_var:
                sig += f" RESULT({result_var})"
            func_id = f"{rel_path}::{func_name}"
            nodes.append(ParsedNode(
                id=func_id, name=func_name, qualified_name=func_name,
                type="function", file_path=rel_path,
                line_start=1, line_end=1,
                signature=sig, is_exported=True,
                summary="function",
            ))
            edges.append(ParsedEdge(
                source=file_id, target=func_id,
                type="CONTAINS", file_path=rel_path, line=1,
            ))

        # USE → IMPORTS
        for m in _USE_RE.finditer(code):
            used_module = m.group(1)
            only_clause = m.group(2)
            edges.append(ParsedEdge(
                source=file_id, target=used_module,
                type="IMPORTS", file_path=rel_path, line=1,
            ))
            # USE ... ONLY: selective imports
            if only_clause:
                for sym in only_clause.split(","):
                    sym = sym.strip().split("=>")[-1].strip()  # handle renaming
                    if sym:
                        edges.append(ParsedEdge(
                            source=file_id, target=sym,
                            type="IMPORTS", file_path=rel_path, line=1,
                        ))

        # CALL → CALLS
        for m in _CALL_RE.finditer(code):
            called = m.group(1)
            edges.append(ParsedEdge(
                source=file_id, target=called,
                type="CALLS", file_path=rel_path, line=1,
            ))

        # COMMON blocks → shared state
        for m in _COMMON_RE.finditer(code):
            block_name = m.group(1)
            vars_str = m.group(2)
            block_id = f"{rel_path}::COMMON_{block_name}"
            nodes.append(ParsedNode(
                id=block_id, name=f"COMMON_{block_name}",
                qualified_name=f"COMMON_{block_name}",
                type="variable", file_path=rel_path,
                line_start=1, line_end=1,
                summary="common_block",
            ))
            # DATAFLOW edge from file to common block
            edges.append(ParsedEdge(
                source=file_id, target=block_id,
                type="DATAFLOW", file_path=rel_path, line=1,
            ))

        # IMPLICIT NONE → metadata
        if _IMPLICIT_NONE_RE.search(code):
            nodes[0].summary = (nodes[0].summary + "|" if nodes[0].summary else "") + "implicit_none"

        # EQUIVALENCE → warning
        if _EQUIVALENCE_RE.search(code):
            nodes[0].summary = (nodes[0].summary + "|" if nodes[0].summary else "") + "equivalence_warning"

        # INTENT detection → metadata
        intent_count = len(_INTENT_RE.findall(code))
        if intent_count:
            nodes[0].summary = (nodes[0].summary + "|" if nodes[0].summary else "") + f"intent_decls={intent_count}"

        return ParsedFile(
            path=rel_path, content_hash=chash,
            nodes=nodes, edges=edges, line_count=line_count,
        )

    @staticmethod
    def _is_fixed_format(path: Path, content: str) -> bool:
        """Detect fixed-format Fortran."""
        ext = path.suffix.lower()
        if ext in (".f", ".for", ".ftn"):
            return True
        if ext in (".f90", ".f95", ".f03", ".f08"):
            return False
        # Ambiguous: heuristic check
        lines = content.splitlines()[:20]
        fixed_signals = sum(
            1 for line in lines
            if len(line) > 6 and line[0] in "Cc*!" and (len(line) < 7 or line[5] == " ")
        )
        return fixed_signals >= 3

    @staticmethod
    def _strip_fixed_format(lines: list[str]) -> str:
        """Strip fixed-format Fortran columns.

        Columns 1-5: label, Column 6: continuation, Columns 7-72: code.
        C, c, or * in column 1: comment.
        """
        result: list[str] = []
        for line in lines:
            if not line:
                continue
            if line[0] in ("C", "c", "*", "!"):
                continue
            if len(line) > 5 and line[5] not in (" ", "0", "\t"):
                # Continuation line
                cont = line[6:72].rstrip() if len(line) > 6 else ""
                if result and cont:
                    result[-1] = result[-1] + cont
                continue
            code = line[6:72].rstrip() if len(line) > 6 else line.rstrip()
            if code.strip():
                result.append(code)
        return "\n".join(result)
