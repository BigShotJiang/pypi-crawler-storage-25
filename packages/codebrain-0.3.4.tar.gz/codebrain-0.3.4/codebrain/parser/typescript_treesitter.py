"""TypeScript/JavaScript AST parser using tree-sitter.

Provides accurate structural extraction via real AST parsing.
Falls back to the regex parser if tree-sitter-languages is not installed.
"""

from __future__ import annotations

from pathlib import Path

from codebrain.parser.base import BaseParser
from codebrain.parser.models import ParsedEdge, ParsedFile, ParsedNode
from codebrain.utils import content_hash

try:
    from tree_sitter_languages import get_language, get_parser

    _TS_AVAILABLE = True
except ImportError:
    _TS_AVAILABLE = False


def _node_text(node, source_bytes: bytes) -> str:
    """Extract text for a tree-sitter node."""
    return source_bytes[node.start_byte:node.end_byte].decode("utf-8", errors="replace")


def _find_child(node, *types: str):
    """Find first child of given type(s)."""
    for child in node.children:
        if child.type in types:
            return child
    return None


def _find_children(node, *types: str):
    """Find all children of given type(s)."""
    return [c for c in node.children if c.type in types]


def _is_exported(node) -> bool:
    """Check if a declaration node is exported (has export_statement parent or sibling)."""
    parent = node.parent
    if parent and parent.type in ("export_statement", "export_default_declaration"):
        return True
    return False


def _collect_decorators(node, source_bytes: bytes) -> list[str]:
    """Collect decorator names from decorator nodes preceding a declaration.

    In tree-sitter, decorators are siblings of the declaration inside the
    export_statement parent, or siblings in the program/statement_block.
    """
    decorators = []
    # Check the parent for decorator siblings (e.g., inside export_statement)
    search_nodes = []
    parent = node.parent
    if parent and parent.type in ("export_statement", "export_default_declaration"):
        search_nodes = parent.children
    elif parent:
        search_nodes = parent.children

    # Find our node's index and look backwards for decorators
    idx = None
    for i, child in enumerate(search_nodes):
        if child.id == node.id:
            idx = i
            break
    if idx is not None:
        for i in range(idx - 1, -1, -1):
            sib = search_nodes[i]
            if sib.type == "decorator":
                text = _node_text(sib, source_bytes).lstrip("@").strip()
                paren = text.find("(")
                if paren != -1:
                    text = text[:paren].strip()
                if text:
                    decorators.append(text)
            elif sib.type in ("comment", "export"):
                continue
            else:
                break

    # Also check if the declaration's export_statement parent has decorators
    if not decorators and parent and parent.type in ("export_statement", "export_default_declaration"):
        for child in parent.children:
            if child.type == "decorator":
                text = _node_text(child, source_bytes).lstrip("@").strip()
                paren = text.find("(")
                if paren != -1:
                    text = text[:paren].strip()
                if text:
                    decorators.append(text)

    return decorators


def _params_text(params_node, source_bytes: bytes) -> str:
    """Extract parameter signature from a formal_parameters node."""
    if params_node is None:
        return "()"
    return _node_text(params_node, source_bytes)


def _return_type_text(node, source_bytes: bytes) -> str:
    """Extract return type annotation if present."""
    ann = _find_child(node, "type_annotation")
    if ann:
        return _node_text(ann, source_bytes).lstrip(":").strip()
    return ""


class TreeSitterTSParser:
    """Tree-sitter based TypeScript/JavaScript parser."""

    def __init__(self):
        self._ts_parser = get_parser("typescript")
        self._tsx_parser = get_parser("tsx")

    def parse(self, path: Path, repo_root: Path) -> ParsedFile:
        rel_path = path.relative_to(repo_root).as_posix()
        raw = path.read_bytes()
        hash_val = content_hash(raw)

        source = raw.decode("utf-8", errors="replace")
        source_bytes = source.encode("utf-8")
        line_count = source.count("\n") + 1
        module_name = rel_path.replace("/", ".").removesuffix(".ts").removesuffix(".tsx").removesuffix(".js").removesuffix(".jsx")

        # Use TSX parser for .tsx/.jsx, TS for others
        if path.suffix in (".tsx", ".jsx"):
            tree = self._tsx_parser.parse(source_bytes)
        else:
            tree = self._ts_parser.parse(source_bytes)

        nodes: list[ParsedNode] = []
        edges: list[ParsedEdge] = []
        exported_names: set[str] = set()
        seen_ids: set[str] = set()

        def _get_jsdoc(ts_node) -> str:
            """Extract JSDoc comment (/** ... */) preceding a node.

            Walks backwards through siblings to find a comment node whose
            text starts with ``/**``.  Strips leading ``*`` prefixes and
            returns cleaned text capped at 4000 characters.
            """
            parent = ts_node.parent
            if parent is None:
                return ""
            siblings = parent.children
            idx = None
            for i, sib in enumerate(siblings):
                if sib.id == ts_node.id:
                    idx = i
                    break
            if idx is None:
                return ""
            # Walk backwards looking for a comment
            for i in range(idx - 1, -1, -1):
                sib = siblings[i]
                if sib.type == "comment":
                    text = source_bytes[sib.start_byte:sib.end_byte].decode(
                        "utf-8", errors="replace"
                    )
                    if text.startswith("/**"):
                        # Strip opening /** and closing */
                        text = text[3:]
                        if text.endswith("*/"):
                            text = text[:-2]
                        # Clean each line: strip leading whitespace and * prefix
                        lines = []
                        for line in text.splitlines():
                            cleaned = line.strip()
                            if cleaned.startswith("*"):
                                cleaned = cleaned[1:].lstrip()
                            lines.append(cleaned)
                        result = "\n".join(lines).strip()
                        return result[:4000]
                    # Non-JSDoc comment, stop looking
                    return ""
                elif sib.type in ("decorator",):
                    # Decorators can appear between JSDoc and declaration
                    continue
                else:
                    break
            return ""

        file_node_id = f"{rel_path}::__module__"
        file_node = ParsedNode(
            id=file_node_id,
            name=module_name.rsplit(".", 1)[-1],
            qualified_name=module_name,
            type="file",
            file_path=rel_path,
            line_start=1,
            line_end=line_count,
            is_exported=True,
        )
        nodes.append(file_node)
        seen_ids.add(file_node_id)

        def _add_node(name: str, node_type: str, ts_node, parent_id: str | None = None,
                       signature: str = "", decorators: list[str] | None = None,
                       is_exp: bool = False, qualified: str | None = None,
                       docstring: str = "") -> str:
            node_id = f"{rel_path}::{qualified or name}"
            if node_id in seen_ids:
                return node_id
            seen_ids.add(node_id)
            if is_exp:
                exported_names.add(name)
            n = ParsedNode(
                id=node_id, name=name,
                qualified_name=qualified or name,
                type=node_type, file_path=rel_path,
                line_start=ts_node.start_point[0] + 1,
                line_end=ts_node.end_point[0] + 1,
                signature=signature, is_exported=is_exp,
                decorators=decorators or [],
                docstring=docstring,
            )
            nodes.append(n)
            container = parent_id or file_node_id
            edges.append(ParsedEdge(
                source=container, target=node_id,
                type="CONTAINS", file_path=rel_path,
                line=ts_node.start_point[0] + 1,
            ))
            return node_id

        def _extract_calls_from_body(body_node, caller_id: str):
            """Walk a function/method body and extract CALLS edges."""
            if body_node is None:
                return
            seen_calls: set[str] = set()
            _walk_calls(body_node, caller_id, seen_calls)

        def _walk_calls(node, caller_id: str, seen_calls: set[str]):
            if node.type == "call_expression":
                func_node = node.children[0] if node.children else None
                if func_node:
                    call_name = _node_text(func_node, source_bytes)
                    # Skip noise
                    if call_name not in _CALL_SKIP and call_name not in seen_calls:
                        seen_calls.add(call_name)
                        edges.append(ParsedEdge(
                            source=caller_id, target=call_name,
                            type="CALLS", file_path=rel_path,
                            line=node.start_point[0] + 1,
                        ))
            # Also capture JSX elements as CALLS
            if node.type in ("jsx_opening_element", "jsx_self_closing_element"):
                name_node = _find_child(node, "identifier", "member_expression")
                if name_node:
                    comp_name = _node_text(name_node, source_bytes)
                    if comp_name[0:1].isupper() and comp_name not in seen_calls:
                        seen_calls.add(comp_name)
                        edges.append(ParsedEdge(
                            source=caller_id, target=comp_name,
                            type="CALLS", file_path=rel_path,
                            line=node.start_point[0] + 1,
                        ))
            for child in node.children:
                _walk_calls(child, caller_id, seen_calls)

        def _process_function(ts_node, parent_id: str | None = None, class_name: str | None = None):
            """Process function_declaration or generator_function_declaration."""
            name_node = _find_child(ts_node, "identifier")
            if not name_node:
                return
            name = _node_text(name_node, source_bytes)
            params = _find_child(ts_node, "formal_parameters")
            sig = _params_text(params, source_bytes)
            ret = _return_type_text(ts_node, source_bytes)
            if ret:
                sig += f" => {ret}"
            is_exp = _is_exported(ts_node)
            decos = _collect_decorators(ts_node, source_bytes)
            doc = _get_jsdoc(ts_node)
            qname = f"{class_name}.{name}" if class_name else name
            ntype = "method" if class_name else "function"
            nid = _add_node(name, ntype, ts_node, parent_id,
                            signature=sig, decorators=decos,
                            is_exp=is_exp, qualified=qname, docstring=doc)
            body = _find_child(ts_node, "statement_block")
            _extract_calls_from_body(body, nid)

        def _process_arrow_or_variable(ts_node, parent_id: str | None = None):
            """Process variable declarations that may contain arrow functions."""
            for declarator in _find_children(ts_node, "variable_declarator"):
                name_node = _find_child(declarator, "identifier")
                if not name_node:
                    continue
                name = _node_text(name_node, source_bytes)
                value = None
                for child in declarator.children:
                    if child.type == "=":
                        continue
                    if child != name_node and child.type not in (":", "type_annotation", "="):
                        value = child
                # Check if value is an arrow function or function
                is_exp = _is_exported(ts_node)
                if value and value.type in ("arrow_function", "function_expression",
                                             "generator_function"):
                    params = _find_child(value, "formal_parameters")
                    sig = _params_text(params, source_bytes)
                    ret = _return_type_text(value, source_bytes)
                    if ret:
                        sig += f" => {ret}"
                    decos = _collect_decorators(ts_node, source_bytes)
                    doc = _get_jsdoc(ts_node)
                    # Check for React wrappers
                    if value.type == "call_expression":
                        decos.append("react_component")
                    nid = _add_node(name, "function", ts_node, parent_id,
                                    signature=sig, decorators=decos, is_exp=is_exp,
                                    docstring=doc)
                    body = _find_child(value, "statement_block")
                    if body is None:
                        # Single expression arrow — the value itself is the body
                        _extract_calls_from_body(value, nid)
                    else:
                        _extract_calls_from_body(body, nid)
                elif value and value.type == "call_expression":
                    # Could be React.memo(), connect(), etc.
                    func = value.children[0] if value.children else None
                    func_text = _node_text(func, source_bytes) if func else ""
                    is_wrapper = any(w in func_text for w in (
                        "memo", "forwardRef", "lazy", "connect",
                        "withRouter", "styled", "observer",
                    ))
                    decos = ["react_component"] if is_wrapper else []
                    doc = _get_jsdoc(ts_node)
                    nid = _add_node(name, "function", ts_node, parent_id,
                                    decorators=decos, is_exp=is_exp, docstring=doc)
                    _extract_calls_from_body(value, nid)
                else:
                    # Regular variable
                    nid = _add_node(name, "variable", ts_node, parent_id, is_exp=is_exp)

        def _process_class(ts_node, parent_id: str | None = None):
            """Process class_declaration."""
            name_node = _find_child(ts_node, "type_identifier", "identifier")
            if not name_node:
                return
            name = _node_text(name_node, source_bytes)
            is_exp = _is_exported(ts_node)
            decos = _collect_decorators(ts_node, source_bytes)
            doc = _get_jsdoc(ts_node)
            class_id = _add_node(name, "class", ts_node, parent_id,
                                 decorators=decos, is_exp=is_exp, docstring=doc)

            # Extends
            heritage = _find_child(ts_node, "class_heritage")
            if heritage:
                extends_clause = _find_child(heritage, "extends_clause")
                if extends_clause:
                    for child in extends_clause.children:
                        if child.type in ("identifier", "member_expression"):
                            base = _node_text(child, source_bytes)
                            edges.append(ParsedEdge(
                                source=class_id, target=base,
                                type="EXTENDS", file_path=rel_path,
                                line=child.start_point[0] + 1,
                            ))
                            break
                implements_clause = _find_child(heritage, "implements_clause")
                if implements_clause:
                    for child in implements_clause.children:
                        if child.type in ("identifier", "type_identifier", "generic_type"):
                            iface = _node_text(child, source_bytes)
                            if iface not in (",", "implements"):
                                edges.append(ParsedEdge(
                                    source=class_id, target=iface,
                                    type="IMPLEMENTS", file_path=rel_path,
                                    line=child.start_point[0] + 1,
                                ))

            # Methods and properties
            body = _find_child(ts_node, "class_body")
            if body:
                for member in body.children:
                    if member.type == "method_definition":
                        m_name_node = _find_child(member, "property_identifier", "identifier")
                        if not m_name_node:
                            continue
                        m_name = _node_text(m_name_node, source_bytes)
                        if m_name in ("constructor",):
                            m_name = "__init__"
                        params = _find_child(member, "formal_parameters")
                        sig = _params_text(params, source_bytes)
                        m_decos = _collect_decorators(member, source_bytes)
                        m_doc = _get_jsdoc(member)
                        m_qname = f"{name}.{m_name}"
                        m_id = _add_node(m_name, "method", member, class_id,
                                         signature=sig, qualified=m_qname,
                                         decorators=m_decos, docstring=m_doc)
                        m_body = _find_child(member, "statement_block")
                        _extract_calls_from_body(m_body, m_id)
                    # Skip field definitions — they're properties, not methods

        def _process_interface(ts_node, parent_id: str | None = None):
            """Process interface_declaration."""
            name_node = _find_child(ts_node, "type_identifier", "identifier")
            if not name_node:
                return
            name = _node_text(name_node, source_bytes)
            is_exp = _is_exported(ts_node)
            doc = _get_jsdoc(ts_node)
            _add_node(name, "class", ts_node, parent_id,
                      decorators=["interface"], is_exp=is_exp, docstring=doc)

            # extends
            extends = _find_child(ts_node, "extends_type_clause")
            if extends:
                for child in extends.children:
                    if child.type in ("identifier", "type_identifier"):
                        base = _node_text(child, source_bytes)
                        if base != "extends":
                            nid = f"{rel_path}::{name}"
                            edges.append(ParsedEdge(
                                source=nid, target=base,
                                type="EXTENDS", file_path=rel_path,
                                line=child.start_point[0] + 1,
                            ))

        def _process_type_alias(ts_node, parent_id: str | None = None):
            name_node = _find_child(ts_node, "type_identifier", "identifier")
            if not name_node:
                return
            name = _node_text(name_node, source_bytes)
            is_exp = _is_exported(ts_node)
            doc = _get_jsdoc(ts_node)
            _add_node(name, "variable", ts_node, parent_id,
                      decorators=["type_alias"], is_exp=is_exp, docstring=doc)

        def _process_enum(ts_node, parent_id: str | None = None):
            name_node = _find_child(ts_node, "identifier")
            if not name_node:
                return
            name = _node_text(name_node, source_bytes)
            is_exp = _is_exported(ts_node)
            doc = _get_jsdoc(ts_node)
            _add_node(name, "class", ts_node, parent_id,
                      decorators=["enum"], is_exp=is_exp, docstring=doc)

        def _process_namespace(ts_node, parent_id: str | None = None):
            name_node = _find_child(ts_node, "identifier")
            if not name_node:
                return
            name = _node_text(name_node, source_bytes)
            is_exp = _is_exported(ts_node)
            doc = _get_jsdoc(ts_node)
            ns_id = _add_node(name, "class", ts_node, parent_id,
                              decorators=["namespace"], is_exp=is_exp, docstring=doc)
            # Process body
            body = _find_child(ts_node, "statement_block")
            if body:
                _walk_statements(body, ns_id)

        def _process_import(ts_node):
            """Process import_statement."""
            source_node = _find_child(ts_node, "string")
            if not source_node:
                return
            module = _node_text(source_node, source_bytes).strip("'\"")

            # Check for named imports
            import_clause = _find_child(ts_node, "import_clause")
            if import_clause:
                named = _find_child(import_clause, "named_imports")
                if named:
                    for spec in _find_children(named, "import_specifier"):
                        imp_name = _find_child(spec, "identifier")
                        if imp_name:
                            edges.append(ParsedEdge(
                                source=file_node_id,
                                target=f"{module}.{_node_text(imp_name, source_bytes)}",
                                type="IMPORTS", file_path=rel_path,
                                line=ts_node.start_point[0] + 1,
                            ))
                    return
                # Default or namespace import
                edges.append(ParsedEdge(
                    source=file_node_id, target=module,
                    type="IMPORTS", file_path=rel_path,
                    line=ts_node.start_point[0] + 1,
                ))

        def _process_export(ts_node):
            """Process export_statement — may contain a declaration or re-export."""
            # Re-export: export { X } from "y" or export * from "y"
            source_node = _find_child(ts_node, "string")
            if source_node:
                module = _node_text(source_node, source_bytes).strip("'\"")
                edges.append(ParsedEdge(
                    source=file_node_id, target=module,
                    type="IMPORTS", file_path=rel_path,
                    line=ts_node.start_point[0] + 1,
                ))
                # Mark re-exported names
                export_clause = _find_child(ts_node, "export_clause")
                if export_clause:
                    for spec in _find_children(export_clause, "export_specifier"):
                        name_node = _find_child(spec, "identifier")
                        if name_node:
                            name = _node_text(name_node, source_bytes)
                            _add_node(name, "variable", ts_node, None,
                                      decorators=["re-export"], is_exp=True)
                return

            # Declaration export: export function/class/etc
            for child in ts_node.children:
                _dispatch(child, None)

        def _dispatch(ts_node, parent_id: str | None):
            """Route a node to the appropriate processor."""
            t = ts_node.type
            if t in ("function_declaration", "generator_function_declaration"):
                _process_function(ts_node, parent_id)
            elif t in ("lexical_declaration", "variable_declaration"):
                _process_arrow_or_variable(ts_node, parent_id)
            elif t in ("class_declaration", "abstract_class_declaration"):
                _process_class(ts_node, parent_id)
            elif t == "interface_declaration":
                _process_interface(ts_node, parent_id)
            elif t == "type_alias_declaration":
                _process_type_alias(ts_node, parent_id)
            elif t == "enum_declaration":
                _process_enum(ts_node, parent_id)
            elif t in ("module", "internal_module"):
                _process_namespace(ts_node, parent_id)
            elif t == "import_statement":
                _process_import(ts_node)
            elif t == "export_statement":
                _process_export(ts_node)

        def _walk_statements(parent_node, parent_id: str | None = None):
            for child in parent_node.children:
                _dispatch(child, parent_id)

        # Walk the root
        _walk_statements(tree.root_node)

        return ParsedFile(
            path=rel_path,
            content_hash=hash_val,
            nodes=nodes,
            edges=edges,
            line_count=line_count,
        )


# Calls to skip (noise reduction)
_CALL_SKIP = frozenset({
    "if", "for", "while", "switch", "catch", "return", "new", "typeof",
    "instanceof", "import", "require", "from", "throw", "delete", "void",
    "yield", "await", "case", "else", "try", "finally", "class", "function",
    "const", "let", "var", "export", "default", "extends", "implements",
    "true", "false", "null", "undefined", "this", "super",
    "console.log", "console.warn", "console.error",
    "JSON.stringify", "JSON.parse", "Object.keys", "Object.values",
    "Object.assign", "Object.entries", "Array.isArray", "Array.from",
    "Math.floor", "Math.ceil", "Math.round", "Math.max", "Math.min",
    "parseInt", "parseFloat", "String", "Number", "Boolean",
    "setTimeout", "setInterval", "clearTimeout", "clearInterval",
    "Promise.resolve", "Promise.reject", "Promise.all",
})


class TypeScriptTreeSitterParser(BaseParser):
    """AST-based TypeScript/JavaScript parser using tree-sitter.

    Falls back to the regex parser if tree-sitter-languages is not installed.
    """

    _TS_EXTENSIONS = frozenset({".ts", ".tsx", ".js", ".jsx"})

    def __init__(self):
        if _TS_AVAILABLE:
            self._impl = TreeSitterTSParser()
        else:
            self._impl = None

    def extensions(self) -> frozenset[str]:
        return self._TS_EXTENSIONS

    def parse(self, path: Path, repo_root: Path) -> ParsedFile:
        if self._impl:
            return self._impl.parse(path, repo_root)
        # Fallback to regex parser
        from codebrain.parser.typescript_parser import parse_typescript_file
        return parse_typescript_file(path, repo_root)
