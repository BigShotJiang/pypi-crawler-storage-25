"""Kotlin AST parser using tree-sitter.

Extracts classes, data classes, objects, interfaces, enums, functions,
properties, and relationships (CALLS, IMPORTS, EXTENDS, IMPLEMENTS, CONTAINS).

Kotlin-specific features:
  - Everything is public by default (no modifier = exported)
  - data class / sealed class / sealed interface detection
  - object declarations (singletons) and companion objects
  - Extension functions (fun String.toSlug())
  - suspend / inline / infix function modifiers
  - @Annotation extraction
  - /** KDoc */ docstring extraction
  - Primary constructor parameters as properties (val/var in constructor)
  - typealias support
"""

from __future__ import annotations

from pathlib import Path

from codebrain.parser.base import BaseParser
from codebrain.parser.models import ParsedEdge, ParsedFile, ParsedNode
from codebrain.utils import content_hash

try:
    from tree_sitter_languages import get_parser

    _KOTLIN_AVAILABLE = True
except ImportError:
    _KOTLIN_AVAILABLE = False


def _node_text(node, source_bytes: bytes) -> str:
    """Extract text for a tree-sitter node."""
    return source_bytes[node.start_byte:node.end_byte].decode("utf-8", errors="replace")


def _find_child(node, *types: str):
    """Find first child of given type(s)."""
    for child in node.children:
        if child.type in types:
            return child
    return None


def _find_children(node, *types: str):
    """Find all children of given type(s)."""
    return [c for c in node.children if c.type in types]


def _walk_descendants(node, *types: str):
    """Yield all descendants matching given type(s)."""
    for child in node.children:
        if child.type in types:
            yield child
        yield from _walk_descendants(child, *types)


def _get_visibility(node, source_bytes: bytes) -> str:
    """Extract visibility modifier. Returns '' if none (= public in Kotlin)."""
    mods = _find_child(node, "modifiers")
    if not mods:
        return ""
    for child in mods.children:
        if child.type == "visibility_modifier":
            return _node_text(child, source_bytes)
    return ""


def _get_class_modifiers(node, source_bytes: bytes) -> list[str]:
    """Extract class modifiers (data, sealed, inner, abstract, open, enum)."""
    mods_node = _find_child(node, "modifiers")
    if not mods_node:
        return []
    result = []
    for child in mods_node.children:
        if child.type in ("class_modifier", "inheritance_modifier"):
            result.append(_node_text(child, source_bytes))
    return result


def _get_function_modifiers(node, source_bytes: bytes) -> list[str]:
    """Extract function modifiers (suspend, inline, infix, operator, tailrec)."""
    mods_node = _find_child(node, "modifiers")
    if not mods_node:
        return []
    result = []
    for child in mods_node.children:
        if child.type in ("function_modifier", "platform_modifier",
                          "member_modifier"):
            result.append(_node_text(child, source_bytes))
    return result


def _get_annotations(node, source_bytes: bytes) -> list[str]:
    """Extract annotation names (@Override, @Deprecated, etc.)."""
    mods_node = _find_child(node, "modifiers")
    if not mods_node:
        return []
    annotations = []

    def _extract_from_ann(ann_node):
        """Extract annotation name(+args) from an annotation-like node."""
        # Direct constructor_invocation child: @Deprecated("msg")
        constructor_inv = _find_child(ann_node, "constructor_invocation")
        if constructor_inv:
            user_type = _find_child(constructor_inv, "user_type")
            if user_type:
                ann_name = _node_text(user_type, source_bytes)
                args = _find_child(constructor_inv, "value_arguments")
                if args:
                    annotations.append(f"{ann_name}{_node_text(args, source_bytes)}")
                else:
                    annotations.append(ann_name)
            return
        # Direct user_type child: @Override
        user_type = _find_child(ann_node, "user_type")
        if user_type:
            annotations.append(_node_text(user_type, source_bytes))

    for child in mods_node.children:
        if child.type == "annotation":
            # Kotlin tree-sitter: annotation node may contain:
            # - @ + constructor_invocation (with args)
            # - @ + user_type (marker annotation)
            # - single_annotation / multi_annotation wrappers
            has_sub = False
            for sub in child.children:
                if sub.type in ("single_annotation", "multi_annotation"):
                    has_sub = True
                    _extract_from_ann(sub)
            if not has_sub:
                _extract_from_ann(child)
    return annotations


def _params_signature(params_node, source_bytes: bytes) -> str:
    """Build parameter signature string from function_value_parameters node."""
    if not params_node:
        return "()"
    # Just use the full text of the parameters node
    return _node_text(params_node, source_bytes)


def _get_return_type(node, source_bytes: bytes) -> str:
    """Extract return type annotation from a function declaration."""
    # In Kotlin tree-sitter, return type appears as a child after ':'
    found_colon = False
    for child in node.children:
        if child.type == "function_value_parameters":
            found_colon = False
            continue
        if found_colon and child.type in ("user_type", "nullable_type",
                                           "type_identifier"):
            return _node_text(child, source_bytes)
        if child.type == ":" and not found_colon:
            found_colon = True
    return ""


# Calls to skip (Kotlin noise: standard library, control flow)
_CALL_SKIP = frozenset({
    "println", "print", "require", "check", "error",
    "listOf", "mapOf", "setOf", "arrayOf",
    "mutableListOf", "mutableMapOf", "mutableSetOf",
    "emptyList", "emptyMap", "emptySet",
    "to", "Pair", "Triple",
    "lazy", "by", "also", "let", "run", "with", "apply",
    "TODO", "throw", "return", "when", "if", "for", "while",
    "hashMapOf", "linkedMapOf", "sortedSetOf", "arrayListOf",
    "buildList", "buildMap", "buildSet",
    "repeat", "takeIf", "takeUnless",
    "requireNotNull", "checkNotNull",
    "String", "Int", "Long", "Double", "Float", "Boolean",
    "listOfNotNull", "sequenceOf",
})


class KotlinTreeSitterParser:
    """Core Kotlin parser implementation using tree-sitter."""

    def __init__(self):
        self._parser = get_parser("kotlin")

    def parse(self, path: Path, repo_root: Path) -> ParsedFile:
        rel_path = path.relative_to(repo_root).as_posix()
        raw = path.read_bytes()
        hash_val = content_hash(raw)

        source = raw.decode("utf-8", errors="replace")
        source_bytes = source.encode("utf-8")
        line_count = source.count("\n") + 1

        tree = self._parser.parse(source_bytes)

        nodes: list[ParsedNode] = []
        edges: list[ParsedEdge] = []
        seen_ids: set[str] = set()
        package_name = ""

        # File node
        module_name = rel_path.replace("/", ".").removesuffix(".kt").removesuffix(".kts")
        file_node_id = f"{rel_path}::__module__"
        nodes.append(ParsedNode(
            id=file_node_id,
            name=module_name.rsplit(".", 1)[-1],
            qualified_name=module_name,
            type="file",
            file_path=rel_path,
            line_start=1,
            line_end=line_count,
            is_exported=True,
        ))
        seen_ids.add(file_node_id)

        def _add_node(name: str, node_type: str, ts_node,
                      parent_id: str | None = None,
                      signature: str = "",
                      decorators: list[str] | None = None,
                      is_exp: bool = True,
                      qualified: str | None = None,
                      docstring: str = "") -> str:
            node_id = f"{rel_path}::{qualified or name}"
            if node_id in seen_ids:
                return node_id
            seen_ids.add(node_id)
            n = ParsedNode(
                id=node_id, name=name,
                qualified_name=qualified or name,
                type=node_type, file_path=rel_path,
                line_start=ts_node.start_point[0] + 1,
                line_end=ts_node.end_point[0] + 1,
                signature=signature, is_exported=is_exp,
                decorators=decorators or [],
                docstring=docstring,
            )
            nodes.append(n)
            container = parent_id or file_node_id
            edges.append(ParsedEdge(
                source=container, target=node_id,
                type="CONTAINS", file_path=rel_path,
                line=ts_node.start_point[0] + 1,
            ))
            return node_id

        def _is_exported(ts_node, source_bytes_: bytes) -> bool:
            """In Kotlin, everything is public by default."""
            vis = _get_visibility(ts_node, source_bytes_)
            return vis not in ("private", "internal", "protected")

        def _get_kdoc(ts_node) -> str:
            """Extract KDoc comment (/** ... */) before a node.

            In Kotlin tree-sitter, the multiline_comment is a sibling
            of the declaration node in the parent's children list.
            We also check inside modifiers since some grammars nest
            comments differently.
            """
            # Strategy 1: look at sibling nodes in the parent
            parent = ts_node.parent
            if parent:
                idx = None
                for i, child in enumerate(parent.children):
                    if child.start_byte == ts_node.start_byte and child.end_byte == ts_node.end_byte:
                        idx = i
                        break
                if idx is not None:
                    for i in range(idx - 1, -1, -1):
                        sib = parent.children[i]
                        if sib.type == "multiline_comment":
                            text = _node_text(sib, source_bytes)
                            if text.startswith("/**"):
                                lines = text.strip("/* \n\r\t").split("\n")
                                cleaned = []
                                for line in lines:
                                    line = line.strip().lstrip("* ").strip()
                                    if line:
                                        cleaned.append(line)
                                return " ".join(cleaned)[:4000] if cleaned else ""
                        elif sib.type in ("line_comment",):
                            continue
                        else:
                            break

            # Strategy 2: scan source lines above the node for /** ... */
            line_num = ts_node.start_point[0]  # 0-indexed
            src_lines = source.split("\n")
            # Walk backwards from the line before the node
            kdoc_lines = []
            in_kdoc = False
            for i in range(line_num - 1, max(line_num - 20, -1), -1):
                if i < 0:
                    break
                line = src_lines[i].strip()
                if line.endswith("*/"):
                    in_kdoc = True
                    kdoc_lines.insert(0, line)
                elif in_kdoc:
                    kdoc_lines.insert(0, line)
                    if line.startswith("/**"):
                        break
                elif not line or line.startswith("//"):
                    continue
                else:
                    break

            if kdoc_lines:
                text = "\n".join(kdoc_lines)
                if text.strip().startswith("/**"):
                    lines = text.strip("/* \n\r\t").split("\n")
                    cleaned = []
                    for ln in lines:
                        ln = ln.strip().lstrip("* ").strip()
                        if ln:
                            cleaned.append(ln)
                    return " ".join(cleaned)[:4000] if cleaned else ""
            return ""

        def _walk_calls(node, caller_id: str, seen_calls: set[str]):
            """Recursively extract function/method calls from a block."""
            if node.type == "call_expression":
                # call_expression children: expression + call_suffix
                # The expression can be simple_identifier or navigation_expression
                expr = node.children[0] if node.children else None
                if expr:
                    call_text = _node_text(expr, source_bytes).strip()
                    if "." in call_text:
                        # navigation call: obj.method
                        parts = call_text.rsplit(".", 1)
                        full_name = call_text
                        method_name = parts[-1]
                        if full_name not in _CALL_SKIP and full_name not in seen_calls:
                            seen_calls.add(full_name)
                            edges.append(ParsedEdge(
                                source=caller_id, target=full_name,
                                type="CALLS", file_path=rel_path,
                                line=node.start_point[0] + 1,
                            ))
                        if method_name != full_name and method_name not in _CALL_SKIP and method_name not in seen_calls:
                            seen_calls.add(method_name)
                            edges.append(ParsedEdge(
                                source=caller_id, target=method_name,
                                type="CALLS", file_path=rel_path,
                                line=node.start_point[0] + 1,
                            ))
                    else:
                        if call_text not in _CALL_SKIP and call_text not in seen_calls:
                            seen_calls.add(call_text)
                            edges.append(ParsedEdge(
                                source=caller_id, target=call_text,
                                type="CALLS", file_path=rel_path,
                                line=node.start_point[0] + 1,
                            ))

            for child in node.children:
                _walk_calls(child, caller_id, seen_calls)

        def _extract_calls(body_node, caller_id: str):
            if body_node is None:
                return
            seen_calls: set[str] = set()
            _walk_calls(body_node, caller_id, seen_calls)

        def _extract_supertypes(ts_node, node_id: str):
            """Extract EXTENDS and IMPLEMENTS edges from delegation_specifiers."""
            # Look for delegation_specifiers child
            for child in ts_node.children:
                if child.type == "delegation_specifier":
                    # Could be constructor_invocation (class) or user_type (interface)
                    for sub in child.children:
                        if sub.type == "constructor_invocation":
                            # Extending a class: BaseClass()
                            user_type = _find_child(sub, "user_type")
                            if user_type:
                                base = _node_text(user_type, source_bytes)
                                # Strip generics
                                if "<" in base:
                                    base = base[:base.index("<")]
                                edges.append(ParsedEdge(
                                    source=node_id, target=base,
                                    type="EXTENDS", file_path=rel_path,
                                    line=sub.start_point[0] + 1,
                                ))
                        elif sub.type == "user_type":
                            # Implementing an interface (no parentheses)
                            iface = _node_text(sub, source_bytes)
                            if "<" in iface:
                                iface = iface[:iface.index("<")]
                            edges.append(ParsedEdge(
                                source=node_id, target=iface,
                                type="IMPLEMENTS", file_path=rel_path,
                                line=sub.start_point[0] + 1,
                            ))
                    # If delegation_specifier directly holds a user_type or constructor_invocation
                    if child.child_count == 1:
                        only = child.children[0]
                        # Already handled above
                    elif child.child_count == 0:
                        text = _node_text(child, source_bytes).strip()
                        if text and text not in ("(", ")", ",", ":"):
                            edges.append(ParsedEdge(
                                source=node_id, target=text,
                                type="IMPLEMENTS", file_path=rel_path,
                                line=child.start_point[0] + 1,
                            ))

        def _process_function(ts_node, parent_id: str | None = None,
                              class_name: str | None = None):
            """Process function_declaration."""
            name_node = _find_child(ts_node, "simple_identifier")
            if not name_node:
                return
            name = _node_text(name_node, source_bytes)
            annotations = _get_annotations(ts_node, source_bytes)
            func_mods = _get_function_modifiers(ts_node, source_bytes)
            is_exp = _is_exported(ts_node, source_bytes)

            # Check for extension function: fun ReceiverType.name(...)
            # Look for user_type before the function name (receiver type)
            receiver_type = None
            for child in ts_node.children:
                if child.type == "simple_identifier" and child.id == name_node.id:
                    break
                if child.type in ("user_type", "nullable_type"):
                    receiver_type = _node_text(child, source_bytes)

            # Build signature
            params_node = _find_child(ts_node, "function_value_parameters")
            params_sig = _params_signature(params_node, source_bytes) if params_node else "()"
            ret_type = _get_return_type(ts_node, source_bytes)

            prefix = ""
            if "suspend" in func_mods:
                prefix = "suspend "
                if "suspend" not in annotations:
                    annotations.append("suspend")
            if "inline" in func_mods:
                prefix = f"inline {prefix}"

            if receiver_type:
                sig = f"{prefix}fun {receiver_type}.{name}{params_sig}"
                if "extension" not in annotations:
                    annotations.append("extension")
            else:
                sig = f"{prefix}fun {name}{params_sig}"

            if ret_type:
                sig = f"{sig}: {ret_type}"

            docstring = _get_kdoc(ts_node)

            node_type = "method" if class_name else "function"
            qname = f"{class_name}.{name}" if class_name else name

            fid = _add_node(name, node_type, ts_node, parent_id,
                            signature=sig, decorators=annotations,
                            is_exp=is_exp, qualified=qname, docstring=docstring)

            # Extract calls from body
            body = _find_child(ts_node, "function_body")
            _extract_calls(body, fid)

        def _process_property(ts_node, parent_id: str | None = None,
                              class_name: str | None = None):
            """Process property_declaration (val/var)."""
            # Find the property name
            # property_declaration has: val/var, optional type, identifier, optional initializer
            name_node = None
            # Look for variable_declaration which contains simple_identifier
            var_decl = _find_child(ts_node, "variable_declaration")
            if var_decl:
                name_node = _find_child(var_decl, "simple_identifier")
            if not name_node:
                name_node = _find_child(ts_node, "simple_identifier")
            if not name_node:
                return

            name = _node_text(name_node, source_bytes)
            annotations = _get_annotations(ts_node, source_bytes)
            is_exp = _is_exported(ts_node, source_bytes)

            # Determine val/var
            is_val = any(_node_text(c, source_bytes) == "val" for c in ts_node.children
                         if c.type in ("val", "var"))
            if not is_val:
                is_val = any(_node_text(c, source_bytes) == "val" for c in ts_node.children)

            qname = f"{class_name}.{name}" if class_name else name
            sig = _node_text(ts_node, source_bytes).split("=")[0].strip().split("\n")[0].strip()
            if len(sig) > 120:
                sig = sig[:120]

            _add_node(name, "variable", ts_node, parent_id,
                      signature=sig, decorators=annotations,
                      is_exp=is_exp, qualified=qname)

        def _process_class(ts_node, parent_id: str | None = None,
                           outer_class: str | None = None):
            """Process class_declaration."""
            name_node = _find_child(ts_node, "type_identifier")
            if not name_node:
                return
            name = _node_text(name_node, source_bytes)
            annotations = _get_annotations(ts_node, source_bytes)
            class_mods = _get_class_modifiers(ts_node, source_bytes)
            is_exp = _is_exported(ts_node, source_bytes)
            docstring = _get_kdoc(ts_node)
            qname = f"{outer_class}.{name}" if outer_class else name

            # Add class modifier tags to decorators
            if "data" in class_mods:
                annotations.append("data_class")
            if "sealed" in class_mods:
                annotations.append("sealed")
            if "abstract" in class_mods:
                annotations.append("abstract")
            if "open" in class_mods:
                annotations.append("open")
            if "inner" in class_mods:
                annotations.append("inner")

            # Check if enum class
            is_enum = "enum" in class_mods or any(
                _node_text(c, source_bytes) == "enum" for c in ts_node.children
            )
            if is_enum:
                annotations.append("enum")

            class_id = _add_node(name, "class", ts_node, parent_id,
                                 decorators=annotations, is_exp=is_exp,
                                 qualified=qname, docstring=docstring)

            # Extract supertypes
            _extract_supertypes(ts_node, class_id)

            # Process primary constructor parameters as properties
            primary_ctor = _find_child(ts_node, "primary_constructor")
            if primary_ctor:
                # class_parameter nodes can be direct children or inside (...)
                for param in _walk_descendants(primary_ctor, "class_parameter"):
                    # Only create property nodes for val/var parameters
                    has_val_var = any(
                        c.type in ("val", "var")
                        for c in param.children
                    )
                    if has_val_var:
                        pname_node = _find_child(param, "simple_identifier")
                        if pname_node:
                            pname = _node_text(pname_node, source_bytes)
                            pqname = f"{qname}.{pname}"
                            param_text = _node_text(param, source_bytes).strip()
                            _add_node(pname, "variable", param, class_id,
                                      signature=param_text,
                                      is_exp=is_exp, qualified=pqname)

            # Process body (enum uses enum_class_body, others use class_body)
            body = _find_child(ts_node, "enum_class_body") if is_enum else None
            if body is None:
                body = _find_child(ts_node, "class_body")
            if body:
                if is_enum:
                    _process_enum_body(body, class_id, name)
                else:
                    _process_class_body(body, class_id, name)

        def _process_enum_body(body_node, parent_id: str, class_name: str):
            """Process enum class body — enum entries + regular members."""
            for member in body_node.children:
                if member.type == "enum_entry":
                    entry_name_node = _find_child(member, "simple_identifier")
                    if entry_name_node:
                        entry_name = _node_text(entry_name_node, source_bytes)
                        _add_node(entry_name, "variable", member, parent_id,
                                  qualified=f"{class_name}.{entry_name}", is_exp=True)
                elif member.type == "function_declaration":
                    _process_function(member, parent_id, class_name)
                elif member.type == "property_declaration":
                    _process_property(member, parent_id, class_name)
                elif member.type == "class_declaration":
                    _process_class(member, parent_id, outer_class=class_name)
                elif member.type == "object_declaration":
                    _process_object(member, parent_id, outer_class=class_name)
                elif member.type == "companion_object":
                    _process_companion(member, parent_id, class_name)

        def _process_class_body(body_node, parent_id: str, class_name: str):
            """Process members of a class body."""
            for member in body_node.children:
                if member.type == "function_declaration":
                    _process_function(member, parent_id, class_name)
                elif member.type == "property_declaration":
                    _process_property(member, parent_id, class_name)
                elif member.type == "class_declaration":
                    _process_class(member, parent_id, outer_class=class_name)
                elif member.type == "object_declaration":
                    _process_object(member, parent_id, outer_class=class_name)
                elif member.type == "companion_object":
                    _process_companion(member, parent_id, class_name)
                elif member.type == "secondary_constructor":
                    _process_secondary_constructor(member, parent_id, class_name)
                elif member.type == "anonymous_initializer":
                    _extract_calls(member, parent_id)

        def _process_secondary_constructor(ts_node, parent_id: str, class_name: str):
            """Process secondary constructor."""
            params_node = _find_child(ts_node, "function_value_parameters")
            sig = f"constructor{_params_signature(params_node, source_bytes)}" if params_node else "constructor()"
            qname = f"{class_name}.__init__"
            cid = _add_node("__init__", "method", ts_node, parent_id,
                            signature=sig, is_exp=True, qualified=qname)
            body = _find_child(ts_node, "function_body", "block")
            _extract_calls(body, cid)

        def _process_companion(ts_node, parent_id: str, class_name: str):
            """Process companion object."""
            # Companion can have a name
            name_node = _find_child(ts_node, "type_identifier")
            comp_name = _node_text(name_node, source_bytes) if name_node else "Companion"
            qname = f"{class_name}.{comp_name}"
            annotations = ["companion_object"]

            comp_id = _add_node(comp_name, "class", ts_node, parent_id,
                                decorators=annotations, is_exp=True,
                                qualified=qname)

            body = _find_child(ts_node, "class_body")
            if body:
                _process_class_body(body, comp_id, qname)

        def _process_object(ts_node, parent_id: str | None = None,
                            outer_class: str | None = None):
            """Process object_declaration (singleton)."""
            name_node = _find_child(ts_node, "type_identifier")
            if not name_node:
                return
            name = _node_text(name_node, source_bytes)
            annotations = _get_annotations(ts_node, source_bytes)
            annotations.append("object")
            is_exp = _is_exported(ts_node, source_bytes)
            docstring = _get_kdoc(ts_node)
            qname = f"{outer_class}.{name}" if outer_class else name

            obj_id = _add_node(name, "class", ts_node, parent_id,
                               decorators=annotations, is_exp=is_exp,
                               qualified=qname, docstring=docstring)

            # Supertypes
            _extract_supertypes(ts_node, obj_id)

            body = _find_child(ts_node, "class_body")
            if body:
                _process_class_body(body, obj_id, name)

        def _process_interface(ts_node, parent_id: str | None = None,
                               outer_class: str | None = None):
            """Process interface declaration (class_declaration with 'interface' keyword)."""
            name_node = _find_child(ts_node, "type_identifier")
            if not name_node:
                return
            name = _node_text(name_node, source_bytes)
            annotations = _get_annotations(ts_node, source_bytes)
            annotations.append("interface")
            class_mods = _get_class_modifiers(ts_node, source_bytes)
            if "sealed" in class_mods:
                annotations.append("sealed")
            is_exp = _is_exported(ts_node, source_bytes)
            docstring = _get_kdoc(ts_node)
            qname = f"{outer_class}.{name}" if outer_class else name

            iface_id = _add_node(name, "class", ts_node, parent_id,
                                 decorators=annotations, is_exp=is_exp,
                                 qualified=qname, docstring=docstring)

            # Interfaces can extend other interfaces
            _extract_supertypes(ts_node, iface_id)

            body = _find_child(ts_node, "class_body")
            if body:
                _process_class_body(body, iface_id, name)

        def _process_import(ts_node):
            """Process import_header."""
            identifier = _find_child(ts_node, "identifier")
            if not identifier:
                return
            import_path = _node_text(identifier, source_bytes)
            # Check for wildcard import: import java.util.*
            star = _find_child(ts_node, "import_alias")
            if any(_node_text(c, source_bytes) == "*" for c in ts_node.children):
                import_path += ".*"
            edges.append(ParsedEdge(
                source=file_node_id, target=import_path,
                type="IMPORTS", file_path=rel_path,
                line=ts_node.start_point[0] + 1,
            ))

        def _process_typealias(ts_node):
            """Process type_alias."""
            name_node = _find_child(ts_node, "type_identifier")
            if not name_node:
                return
            name = _node_text(name_node, source_bytes)
            is_exp = _is_exported(ts_node, source_bytes)
            sig = _node_text(ts_node, source_bytes).strip()
            if len(sig) > 120:
                sig = sig[:120]
            _add_node(name, "variable", ts_node,
                      signature=sig, is_exp=is_exp,
                      decorators=["typealias"], qualified=name)

        def _dispatch_toplevel(child):
            """Route a top-level node to the correct processor."""
            if child.type == "package_header":
                nonlocal package_name
                ident = _find_child(child, "identifier")
                if ident:
                    package_name = _node_text(ident, source_bytes)
            elif child.type == "import_list":
                for imp in _find_children(child, "import_header"):
                    _process_import(imp)
            elif child.type == "import_header":
                _process_import(child)
            elif child.type == "class_declaration":
                # Determine if it's a class or interface
                # Check for 'interface' keyword in children
                is_interface = any(
                    _node_text(c, source_bytes) == "interface"
                    for c in child.children
                    if c.type in ("interface",)
                )
                if is_interface:
                    _process_interface(child)
                else:
                    _process_class(child)
            elif child.type == "object_declaration":
                _process_object(child)
            elif child.type == "function_declaration":
                _process_function(child)
            elif child.type == "property_declaration":
                _process_property(child)
            elif child.type == "type_alias":
                _process_typealias(child)

        def _extract_prefix_annotations(ts_node) -> list[str]:
            """Extract annotations from prefix_expression nodes.

            The Kotlin tree-sitter grammar sometimes parses standalone
            annotations as prefix_expression siblings rather than embedding
            them in the declaration's modifiers. We capture these and apply
            them to the next declaration node.
            """
            import re
            text = _node_text(ts_node, source_bytes).strip()
            anns = []
            for m in re.finditer(r'@(\w+)(?:\(([^)]*)\))?', text):
                name = m.group(1)
                args = m.group(2)
                if args is not None:
                    anns.append(f"{name}({args})")
                else:
                    anns.append(name)
            return anns

        # Walk top-level declarations, collecting prefix annotations
        pending_annotations: list[str] = []
        children = list(tree.root_node.children)
        for child in children:
            if child.type == "prefix_expression":
                # Standalone annotation before a declaration
                pending_annotations.extend(_extract_prefix_annotations(child))
                continue

            nodes_before = len(nodes)
            _dispatch_toplevel(child)

            # Apply pending annotations to the first new node added by this dispatch
            # (which is the top-level declaration, not its children)
            if pending_annotations and len(nodes) > nodes_before:
                target_node = nodes[nodes_before]
                if target_node.type != "file":
                    for ann in pending_annotations:
                        if ann not in target_node.decorators:
                            target_node.decorators.insert(0, ann)
                pending_annotations.clear()

        # Store package as docstring on file node if present
        if package_name:
            nodes[0].docstring = f"package {package_name}"

        return ParsedFile(
            path=rel_path,
            content_hash=hash_val,
            nodes=nodes,
            edges=edges,
            line_count=line_count,
        )


class KotlinParser(BaseParser):
    """AST-based Kotlin parser using tree-sitter.

    Requires tree-sitter-languages to be installed.
    """

    _KOTLIN_EXTENSIONS = frozenset({".kt", ".kts"})

    def __init__(self):
        if _KOTLIN_AVAILABLE:
            self._impl = KotlinTreeSitterParser()
        else:
            self._impl = None

    def extensions(self) -> frozenset[str]:
        return self._KOTLIN_EXTENSIONS

    def parse(self, path: Path, repo_root: Path) -> ParsedFile:
        if self._impl is None:
            raise ImportError(
                "Kotlin parsing requires tree-sitter-languages. "
                "Install with: pip install tree-sitter-languages"
            )
        return self._impl.parse(path, repo_root)
