"""Rust AST parser using tree-sitter.

Extracts functions, structs, enums, traits, impl blocks, methods, constants,
statics, type aliases, modules, and relationships (CALLS, IMPORTS, EXTENDS,
IMPLEMENTS, CONTAINS).

Rust-specific features:
  - pub keyword = exported
  - impl blocks: impl Struct { fn method() } -> method belongs to Struct
  - trait impl: impl Trait for Struct -> IMPLEMENTS edge from Struct to Trait
  - /// doc comments
  - #[derive(...)] and other attributes -> decorators list
  - Lifetime parameters stripped from signatures
  - Enum variants with data
  - Module declarations (mod name;)
"""

from __future__ import annotations

import re
from pathlib import Path

from codebrain.parser.base import BaseParser
from codebrain.parser.models import ParsedEdge, ParsedFile, ParsedNode
from codebrain.utils import content_hash

try:
    from tree_sitter_languages import get_parser

    _RUST_AVAILABLE = True
except ImportError:
    _RUST_AVAILABLE = False


def _node_text(node, source_bytes: bytes) -> str:
    """Extract text for a tree-sitter node."""
    return source_bytes[node.start_byte:node.end_byte].decode("utf-8", errors="replace")


def _find_child(node, *types: str):
    """Find first child of given type(s)."""
    for child in node.children:
        if child.type in types:
            return child
    return None


def _find_children(node, *types: str):
    """Find all children of given type(s)."""
    return [c for c in node.children if c.type in types]


def _strip_lifetimes(sig: str) -> str:
    """Strip lifetime annotations from a signature for readability.

    E.g. fn foo<'a>(x: &'a str) -> &'a str  =>  fn foo(x: &str) -> &str
    """
    # Remove lifetime parameters from generics: <'a, 'b, T> -> <T>, <'a> -> ""
    sig = re.sub(r"<'[a-z_]+(?:\s*,\s*'[a-z_]+)*\s*,\s*", "<", sig)
    sig = re.sub(r"<\s*'[a-z_]+(?:\s*,\s*'[a-z_]+)*\s*>", "", sig)
    # Remove lifetime references: &'a -> &, &'a mut -> &mut
    sig = re.sub(r"&'[a-z_]+\s*", "&", sig)
    return sig


# Macros and standard library noise to skip in CALLS edges
_CALL_SKIP = frozenset({
    "println", "print", "eprintln", "eprint", "format", "dbg",
    "todo", "unimplemented", "panic", "assert", "assert_eq", "assert_ne",
    "vec", "write", "writeln",
    "Ok", "Err", "Some", "None",
    "Box::new", "Rc::new", "Arc::new",
    "String::from", "String::new", "Vec::new",
    "HashMap::new", "HashSet::new", "BTreeMap::new",
    "Default::default", "From::from", "Into::into", "AsRef::as_ref",
    "Clone::clone", "Drop::drop", "Display::fmt",
    # Bare names too
    "new", "from", "into", "default", "clone", "drop", "fmt",
    "as_ref", "as_mut",
    "if", "for", "while", "match", "loop", "return",
    "true", "false", "self", "Self",
})


class RustTreeSitterParser:
    """Core Rust parser implementation using tree-sitter."""

    def __init__(self):
        self._parser = get_parser("rust")

    def parse(self, path: Path, repo_root: Path) -> ParsedFile:
        rel_path = path.relative_to(repo_root).as_posix()
        raw = path.read_bytes()
        hash_val = content_hash(raw)

        source = raw.decode("utf-8", errors="replace")
        source_bytes = source.encode("utf-8")
        line_count = source.count("\n") + 1

        tree = self._parser.parse(source_bytes)

        nodes: list[ParsedNode] = []
        edges: list[ParsedEdge] = []
        seen_ids: set[str] = set()

        # File node
        module_name = rel_path.replace("/", "::").removesuffix(".rs")
        file_node_id = f"{rel_path}::__module__"
        nodes.append(ParsedNode(
            id=file_node_id,
            name=module_name.rsplit("::", 1)[-1],
            qualified_name=module_name,
            type="file",
            file_path=rel_path,
            line_start=1,
            line_end=line_count,
            is_exported=True,
        ))
        seen_ids.add(file_node_id)

        def _add_node(name: str, node_type: str, ts_node,
                      parent_id: str | None = None,
                      signature: str = "",
                      decorators: list[str] | None = None,
                      is_exp: bool = False,
                      qualified: str | None = None,
                      docstring: str = "") -> str:
            node_id = f"{rel_path}::{qualified or name}"
            if node_id in seen_ids:
                return node_id
            seen_ids.add(node_id)
            n = ParsedNode(
                id=node_id, name=name,
                qualified_name=qualified or name,
                type=node_type, file_path=rel_path,
                line_start=ts_node.start_point[0] + 1,
                line_end=ts_node.end_point[0] + 1,
                signature=_strip_lifetimes(signature),
                is_exported=is_exp,
                decorators=decorators or [],
                docstring=docstring,
            )
            nodes.append(n)
            container = parent_id or file_node_id
            edges.append(ParsedEdge(
                source=container, target=node_id,
                type="CONTAINS", file_path=rel_path,
                line=ts_node.start_point[0] + 1,
            ))
            return node_id

        def _get_doc_comment(ts_node) -> str:
            """Extract /// doc comments before a node."""
            parent = ts_node.parent
            if not parent:
                return ""
            idx = None
            for i, child in enumerate(parent.children):
                if child.id == ts_node.id:
                    idx = i
                    break
            if idx is None:
                return ""
            doc_lines = []
            for i in range(idx - 1, -1, -1):
                sib = parent.children[i]
                if sib.type == "line_comment":
                    text = _node_text(sib, source_bytes).strip()
                    if text.startswith("///"):
                        doc_lines.insert(0, text[3:].strip())
                    elif text.startswith("//!"):
                        doc_lines.insert(0, text[3:].strip())
                    else:
                        break
                elif sib.type == "attribute_item":
                    # Attributes can appear before doc comments, keep scanning
                    continue
                else:
                    break
            return " ".join(doc_lines)[:4000] if doc_lines else ""

        def _get_attributes(ts_node) -> list[str]:
            """Extract #[...] attributes before or inside a node."""
            attrs = []

            # 1. Check sibling attribute_items before this node
            parent = ts_node.parent
            if parent:
                idx = None
                for i, child in enumerate(parent.children):
                    if child.id == ts_node.id:
                        idx = i
                        break
                if idx is not None:
                    for i in range(idx - 1, -1, -1):
                        sib = parent.children[i]
                        if sib.type == "attribute_item":
                            text = _node_text(sib, source_bytes).strip()
                            if text.startswith("#[") and text.endswith("]"):
                                text = text[2:-1]
                            attrs.insert(0, text)
                        elif sib.type == "line_comment":
                            continue
                        else:
                            break

            # 2. Check direct child attribute_items (e.g. #[cfg(test)] on mod)
            for child in ts_node.children:
                if child.type == "attribute_item":
                    text = _node_text(child, source_bytes).strip()
                    if text.startswith("#[") and text.endswith("]"):
                        text = text[2:-1]
                    if text not in attrs:
                        attrs.append(text)

            return attrs

        def _is_pub(ts_node) -> bool:
            """Check if node has pub visibility."""
            vis = _find_child(ts_node, "visibility_modifier")
            return vis is not None

        def _walk_calls(node, caller_id: str, seen_calls: set[str]):
            """Recursively extract function/method calls from a block."""
            if node.type == "call_expression":
                func = _find_child(node, "identifier", "field_expression",
                                   "scoped_identifier")
                if func:
                    call_name = _node_text(func, source_bytes)
                    # Strip macro ! suffix
                    call_name = call_name.rstrip("!")
                    if call_name not in _CALL_SKIP and call_name not in seen_calls:
                        seen_calls.add(call_name)
                        edges.append(ParsedEdge(
                            source=caller_id, target=call_name,
                            type="CALLS", file_path=rel_path,
                            line=node.start_point[0] + 1,
                        ))

            elif node.type == "macro_invocation":
                macro_node = _find_child(node, "identifier", "scoped_identifier")
                if macro_node:
                    macro_name = _node_text(macro_node, source_bytes)
                    if macro_name not in _CALL_SKIP and macro_name not in seen_calls:
                        seen_calls.add(macro_name)
                        edges.append(ParsedEdge(
                            source=caller_id, target=macro_name,
                            type="CALLS", file_path=rel_path,
                            line=node.start_point[0] + 1,
                        ))

            elif node.type == "scoped_identifier":
                # Path expressions like Round::Down, TransferState::Running
                # These reference enum variants / associated items and should
                # create CALLS edges so the parent type is not flagged as dead.
                # Skip if this node is already handled as part of a call_expression
                # or macro_invocation (parent check).
                parent_type = node.parent.type if node.parent else ""
                if parent_type not in ("call_expression", "macro_invocation",
                                       "use_declaration", "use_list",
                                       "scoped_use_list"):
                    scoped_name = _node_text(node, source_bytes)
                    # Normalize Rust :: separator to . for consistency with
                    # qualified_name conventions (e.g. Round::Down -> Round.Down)
                    # so that find_dead_code prefix matching works.
                    normalized = scoped_name.replace("::", ".")
                    if scoped_name not in _CALL_SKIP and normalized not in seen_calls:
                        seen_calls.add(normalized)
                        edges.append(ParsedEdge(
                            source=caller_id, target=normalized,
                            type="CALLS", file_path=rel_path,
                            line=node.start_point[0] + 1,
                        ))

            elif node.type in ("tuple_struct_pattern", "struct_pattern"):
                # Match arm patterns like TransferState::Running(buf) or
                # Config { port, .. } — these reference the type/variant.
                path_node = _find_child(node, "scoped_identifier",
                                        "type_identifier", "identifier")
                if path_node:
                    pat_name = _node_text(path_node, source_bytes)
                    normalized = pat_name.replace("::", ".")
                    if pat_name not in _CALL_SKIP and normalized not in seen_calls:
                        seen_calls.add(normalized)
                        edges.append(ParsedEdge(
                            source=caller_id, target=normalized,
                            type="CALLS", file_path=rel_path,
                            line=node.start_point[0] + 1,
                        ))

            for child in node.children:
                _walk_calls(child, caller_id, seen_calls)

        def _extract_calls(body_node, caller_id: str):
            if body_node is None:
                return
            seen_calls: set[str] = set()
            _walk_calls(body_node, caller_id, seen_calls)

        def _fn_signature(ts_node, name: str) -> str:
            """Build function signature from tree-sitter node."""
            params = _find_child(ts_node, "parameters")
            ret = _find_child(ts_node, "type_identifier", "reference_type",
                              "generic_type", "scoped_type_identifier",
                              "primitive_type", "tuple_type", "unit_type")
            # Look for return type after ->
            ret_type = ""
            saw_arrow = False
            for child in ts_node.children:
                if _node_text(child, source_bytes) == "->":
                    saw_arrow = True
                    continue
                if saw_arrow and child.type != "block":
                    ret_type = _node_text(child, source_bytes)
                    break

            params_str = ""
            if params:
                params_str = _node_text(params, source_bytes)

            sig = f"fn {name}{params_str}"
            if ret_type:
                sig += f" -> {ret_type}"
            return sig

        def _process_function(ts_node, parent_id: str | None = None,
                              owner_name: str | None = None):
            """Process function_item."""
            name_node = _find_child(ts_node, "identifier")
            if not name_node:
                return
            name = _node_text(name_node, source_bytes)
            is_exp = _is_pub(ts_node)
            attrs = _get_attributes(ts_node)
            docstring = _get_doc_comment(ts_node)
            sig = _fn_signature(ts_node, name)

            if owner_name:
                qname = f"{owner_name}.{name}"
                node_type = "method"
            else:
                qname = name
                node_type = "function"

            fid = _add_node(name, node_type, ts_node, parent_id,
                            signature=sig, decorators=attrs,
                            is_exp=is_exp, qualified=qname,
                            docstring=docstring)
            body = _find_child(ts_node, "block")
            _extract_calls(body, fid)

        def _process_struct(ts_node, parent_id: str | None = None):
            """Process struct_item."""
            name_node = _find_child(ts_node, "type_identifier")
            if not name_node:
                return
            name = _node_text(name_node, source_bytes)
            is_exp = _is_pub(ts_node)
            attrs = _get_attributes(ts_node)
            docstring = _get_doc_comment(ts_node)

            struct_id = _add_node(name, "class", ts_node, parent_id,
                                  decorators=attrs, is_exp=is_exp,
                                  qualified=name, docstring=docstring)

            # Fields
            field_list = _find_child(ts_node, "field_declaration_list")
            if field_list:
                for field in _find_children(field_list, "field_declaration"):
                    fname_node = _find_child(field, "field_identifier")
                    if fname_node:
                        fname = _node_text(fname_node, source_bytes)
                        ftype = ""
                        for child in field.children:
                            if child.type in ("type_identifier", "reference_type",
                                              "generic_type", "primitive_type",
                                              "scoped_type_identifier", "array_type"):
                                ftype = _node_text(child, source_bytes)
                                break
                        field_is_pub = _is_pub(field)
                        _add_node(fname, "variable", field, struct_id,
                                  signature=f"{fname}: {ftype}" if ftype else fname,
                                  is_exp=field_is_pub,
                                  qualified=f"{name}.{fname}")

        def _process_enum(ts_node, parent_id: str | None = None):
            """Process enum_item."""
            name_node = _find_child(ts_node, "type_identifier")
            if not name_node:
                return
            name = _node_text(name_node, source_bytes)
            is_exp = _is_pub(ts_node)
            attrs = _get_attributes(ts_node)
            docstring = _get_doc_comment(ts_node)
            attrs_with_tag = attrs + ["enum"]

            enum_id = _add_node(name, "class", ts_node, parent_id,
                                decorators=attrs_with_tag, is_exp=is_exp,
                                qualified=name, docstring=docstring)

            # Variants
            variant_list = _find_child(ts_node, "enum_variant_list")
            if variant_list:
                for variant in _find_children(variant_list, "enum_variant"):
                    vname_node = _find_child(variant, "identifier")
                    if vname_node:
                        vname = _node_text(vname_node, source_bytes)
                        _add_node(vname, "variable", variant, enum_id,
                                  is_exp=True, qualified=f"{name}.{vname}")

        def _process_trait(ts_node, parent_id: str | None = None):
            """Process trait_item."""
            name_node = _find_child(ts_node, "type_identifier")
            if not name_node:
                return
            name = _node_text(name_node, source_bytes)
            is_exp = _is_pub(ts_node)
            attrs = _get_attributes(ts_node)
            docstring = _get_doc_comment(ts_node)
            attrs_with_tag = attrs + ["trait"]

            trait_id = _add_node(name, "class", ts_node, parent_id,
                                 decorators=attrs_with_tag, is_exp=is_exp,
                                 qualified=name, docstring=docstring)

            # Trait body: methods and method signatures
            body = _find_child(ts_node, "declaration_list")
            if body:
                for member in body.children:
                    if member.type == "function_item":
                        _process_function(member, trait_id, owner_name=name)
                    elif member.type == "function_signature_item":
                        # Trait method signature (no body)
                        sig_name_node = _find_child(member, "identifier")
                        if sig_name_node:
                            sig_name = _node_text(sig_name_node, source_bytes)
                            sig = _fn_signature(member, sig_name)
                            _add_node(sig_name, "method", member, trait_id,
                                      signature=sig, is_exp=True,
                                      qualified=f"{name}.{sig_name}",
                                      docstring=_get_doc_comment(member))

        def _process_impl(ts_node, parent_id: str | None = None):
            """Process impl_item.

            Handles both:
              impl Struct { ... }
              impl Trait for Struct { ... }
            """
            # Determine if this is a trait impl
            trait_name = None
            struct_name = None

            # Look for 'for' keyword to distinguish trait impl
            has_for = False
            for child in ts_node.children:
                if _node_text(child, source_bytes) == "for":
                    has_for = True
                    break

            if has_for:
                # impl Trait for Struct
                # Nodes before 'for' = trait type, node after 'for' = struct type
                before_for = True
                for child in ts_node.children:
                    text = _node_text(child, source_bytes)
                    if text == "for":
                        before_for = False
                        continue
                    if child.type in ("type_identifier", "scoped_type_identifier",
                                      "generic_type"):
                        type_text = _node_text(child, source_bytes)
                        # Strip generics
                        if "<" in type_text:
                            type_text = type_text[:type_text.index("<")]
                        if before_for:
                            trait_name = type_text
                        else:
                            struct_name = type_text
                            break
            else:
                # impl Struct
                for child in ts_node.children:
                    if child.type in ("type_identifier", "scoped_type_identifier",
                                      "generic_type"):
                        type_text = _node_text(child, source_bytes)
                        if "<" in type_text:
                            type_text = type_text[:type_text.index("<")]
                        struct_name = type_text
                        break

            if not struct_name:
                return

            # Create IMPLEMENTS edge for trait impl
            if trait_name:
                # Find the struct node ID (may already exist)
                struct_node_id = f"{rel_path}::{struct_name}"
                edges.append(ParsedEdge(
                    source=struct_node_id, target=trait_name,
                    type="IMPLEMENTS", file_path=rel_path,
                    line=ts_node.start_point[0] + 1,
                ))

            # Process methods inside impl block
            body = _find_child(ts_node, "declaration_list")
            if body:
                # Find or create the struct node as parent
                struct_node_id = f"{rel_path}::{struct_name}"
                impl_parent = struct_node_id if struct_node_id in seen_ids else parent_id
                for member in body.children:
                    if member.type == "function_item":
                        _process_function(member, impl_parent,
                                          owner_name=struct_name)
                    elif member.type == "const_item":
                        _process_const(member, impl_parent,
                                       owner_name=struct_name)

        def _process_const(ts_node, parent_id: str | None = None,
                           owner_name: str | None = None):
            """Process const_item."""
            name_node = _find_child(ts_node, "identifier")
            if not name_node:
                return
            name = _node_text(name_node, source_bytes)
            is_exp = _is_pub(ts_node)
            attrs = _get_attributes(ts_node)
            qname = f"{owner_name}.{name}" if owner_name else name

            # Get type
            type_str = ""
            saw_colon = False
            for child in ts_node.children:
                if _node_text(child, source_bytes) == ":":
                    saw_colon = True
                    continue
                if saw_colon and child.type != "=" and child.type not in ("integer_literal", "string_literal", "boolean_literal", "float_literal"):
                    if child.type in ("type_identifier", "primitive_type",
                                      "reference_type", "generic_type",
                                      "scoped_type_identifier", "array_type"):
                        type_str = _node_text(child, source_bytes)
                    break

            sig = f"const {name}: {type_str}" if type_str else f"const {name}"
            _add_node(name, "variable", ts_node, parent_id,
                      signature=sig, decorators=attrs, is_exp=is_exp,
                      qualified=qname)

        def _process_static(ts_node, parent_id: str | None = None):
            """Process static_item."""
            name_node = _find_child(ts_node, "identifier")
            if not name_node:
                return
            name = _node_text(name_node, source_bytes)
            is_exp = _is_pub(ts_node)
            attrs = _get_attributes(ts_node)

            type_str = ""
            saw_colon = False
            for child in ts_node.children:
                if _node_text(child, source_bytes) == ":":
                    saw_colon = True
                    continue
                if saw_colon:
                    if child.type in ("type_identifier", "primitive_type",
                                      "reference_type", "generic_type",
                                      "scoped_type_identifier", "array_type"):
                        type_str = _node_text(child, source_bytes)
                    break

            sig = f"static {name}: {type_str}" if type_str else f"static {name}"
            _add_node(name, "variable", ts_node, parent_id,
                      signature=sig, decorators=attrs, is_exp=is_exp,
                      qualified=name)

        def _process_type_alias(ts_node, parent_id: str | None = None):
            """Process type_item (type alias)."""
            name_node = _find_child(ts_node, "type_identifier")
            if not name_node:
                return
            name = _node_text(name_node, source_bytes)
            is_exp = _is_pub(ts_node)
            full_text = _node_text(ts_node, source_bytes).strip().rstrip(";")
            _add_node(name, "variable", ts_node, parent_id,
                      signature=full_text, is_exp=is_exp,
                      qualified=name)

        def _process_mod(ts_node, parent_id: str | None = None):
            """Process mod_item (module declaration)."""
            name_node = _find_child(ts_node, "identifier")
            if not name_node:
                return
            name = _node_text(name_node, source_bytes)
            is_exp = _is_pub(ts_node)
            attrs = _get_attributes(ts_node)
            attrs_with_tag = attrs + ["mod"]

            # Check if it has a body (inline module) or is just a declaration
            body = _find_child(ts_node, "declaration_list")
            if body:
                # Inline module with body
                mod_id = _add_node(name, "class", ts_node, parent_id,
                                   signature=f"mod {name}",
                                   is_exp=is_exp, qualified=name,
                                   decorators=attrs_with_tag)
                # Process body contents
                for child in body.children:
                    _process_top_level(child, mod_id)
            else:
                # Module declaration: mod name;
                _add_node(name, "class", ts_node, parent_id,
                          signature=f"mod {name}",
                          is_exp=is_exp, qualified=name,
                          decorators=attrs_with_tag)

        def _process_use(ts_node):
            """Process use_declaration."""
            # Extract the full use path
            # use_declaration can contain scoped_identifier, use_wildcard, use_list, etc.
            text = _node_text(ts_node, source_bytes).strip()
            # Remove 'use ' prefix and ';' suffix
            text = text.removeprefix("pub ").removeprefix("use ").rstrip(";").strip()

            # Handle use lists: use std::{io, fs} -> std::io, std::fs
            if "{" in text:
                base = text[:text.index("{")].rstrip("::")
                items_str = text[text.index("{") + 1:text.index("}")].strip()
                items = [item.strip() for item in items_str.split(",") if item.strip()]
                for item in items:
                    # Handle nested: self, Item as Alias
                    item_name = item.split(" as ")[0].strip()
                    if item_name == "self":
                        import_path = base
                    else:
                        import_path = f"{base}::{item_name}"
                    edges.append(ParsedEdge(
                        source=file_node_id, target=import_path,
                        type="IMPORTS", file_path=rel_path,
                        line=ts_node.start_point[0] + 1,
                    ))
            else:
                # Simple use or wildcard
                import_path = text.split(" as ")[0].strip()
                edges.append(ParsedEdge(
                    source=file_node_id, target=import_path,
                    type="IMPORTS", file_path=rel_path,
                    line=ts_node.start_point[0] + 1,
                ))

        def _process_top_level(child, parent_id: str | None = None):
            """Process a single top-level (or inline module) declaration."""
            if child.type == "use_declaration":
                _process_use(child)
            elif child.type == "function_item":
                _process_function(child, parent_id)
            elif child.type == "struct_item":
                _process_struct(child, parent_id)
            elif child.type == "enum_item":
                _process_enum(child, parent_id)
            elif child.type == "trait_item":
                _process_trait(child, parent_id)
            elif child.type == "impl_item":
                _process_impl(child, parent_id)
            elif child.type == "const_item":
                _process_const(child, parent_id)
            elif child.type == "static_item":
                _process_static(child, parent_id)
            elif child.type == "type_item":
                _process_type_alias(child, parent_id)
            elif child.type == "mod_item":
                _process_mod(child, parent_id)

        # Walk top-level declarations
        for child in tree.root_node.children:
            _process_top_level(child)

        return ParsedFile(
            path=rel_path,
            content_hash=hash_val,
            nodes=nodes,
            edges=edges,
            line_count=line_count,
        )


class RustParser(BaseParser):
    """AST-based Rust parser using tree-sitter.

    Requires tree-sitter-languages to be installed.
    """

    _RUST_EXTENSIONS = frozenset({".rs"})

    def __init__(self):
        if _RUST_AVAILABLE:
            self._impl = RustTreeSitterParser()
        else:
            self._impl = None

    def extensions(self) -> frozenset[str]:
        return self._RUST_EXTENSIONS

    def parse(self, path: Path, repo_root: Path) -> ParsedFile:
        if self._impl is None:
            raise ImportError(
                "Rust parsing requires tree-sitter-languages. "
                "Install with: pip install tree-sitter-languages"
            )
        return self._impl.parse(path, repo_root)
