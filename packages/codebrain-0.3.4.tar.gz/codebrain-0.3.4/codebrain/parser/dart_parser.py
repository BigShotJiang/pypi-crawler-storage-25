"""Dart parser for Flutter/Dart codebases.

Extracts classes, mixins, enums, extensions, functions, methods, fields,
and relationships (CALLS, IMPORTS, EXTENDS, IMPLEMENTS, CONTAINS).

Uses regex-based parsing. Dart's syntax is clean and keyword-based,
making regex parsing reliable for structural extraction.
"""

from __future__ import annotations

import re
from pathlib import Path

from codebrain.parser.base import BaseParser
from codebrain.parser.models import ParsedEdge, ParsedFile, ParsedNode
from codebrain.utils import content_hash

# ---------------------------------------------------------------------------
# Regex patterns for Dart syntax
# ---------------------------------------------------------------------------

# Imports: import 'package:foo/bar.dart'; / import 'foo.dart' as alias;
_IMPORT_RE = re.compile(
    r"^import\s+['\"]([^'\"]+)['\"]"
    r"(?:\s+as\s+(\w+))?"
    r"(?:\s+show\s+([\w,\s]+))?"
    r"(?:\s+hide\s+([\w,\s]+))?"
    r"\s*;",
    re.MULTILINE,
)

# Export: export 'package:foo/bar.dart';
_EXPORT_RE = re.compile(
    r"^export\s+['\"]([^'\"]+)['\"]",
    re.MULTILINE,
)

# Part: part 'foo.g.dart'; / part of 'bar.dart';
_PART_RE = re.compile(r"^part\s+(?:of\s+)?['\"]([^'\"]+)['\"]", re.MULTILINE)

# Class: class Foo extends Bar with Mixin implements Interface {
_CLASS_RE = re.compile(
    r"^(\s*)"                           # indentation
    r"(abstract\s+)?"                    # optional abstract
    r"class\s+(\w+)"                     # class name
    r"(?:<[^>]+>)?"                      # optional generics
    r"(?:\s+extends\s+([\w.]+(?:<[^>]+>)?))?"  # extends
    r"(?:\s+with\s+([\w.,\s<>]+?))?"     # mixins
    r"(?:\s+implements\s+([\w.,\s<>]+?))?"  # implements
    r"\s*\{",
    re.MULTILINE,
)

# Mixin: mixin FooMixin on Bar implements Baz {
_MIXIN_RE = re.compile(
    r"^(\s*)"
    r"mixin\s+(\w+)"
    r"(?:<[^>]+>)?"
    r"(?:\s+on\s+([\w.,\s<>]+?))?"
    r"(?:\s+implements\s+([\w.,\s<>]+?))?"
    r"\s*\{",
    re.MULTILINE,
)

# Enum: enum Status { active, inactive }
_ENUM_RE = re.compile(
    r"^(\s*)"
    r"enum\s+(\w+)"
    r"(?:\s+with\s+([\w.,\s<>]+?))?"
    r"(?:\s+implements\s+([\w.,\s<>]+?))?"
    r"\s*\{",
    re.MULTILINE,
)

# Extension: extension StringExt on String {
_EXTENSION_RE = re.compile(
    r"^(\s*)"
    r"extension\s+(\w+)\s+on\s+([\w.<>]+)"
    r"\s*\{",
    re.MULTILINE,
)

# Top-level function: ReturnType functionName(params) { / => expr;
_TOPLEVEL_FUNC_RE = re.compile(
    r"^(?:[\w<>,?\s]+\s+)?(\w+)\s*"    # return type + name
    r"(<[^>]+>)?"                        # optional generics
    r"\(([^)]*)\)"                       # parameters
    r"\s*(?:async\s*)?(?:\{|=>|;)",      # body start
    re.MULTILINE,
)

# Method inside a class/mixin body
_METHOD_RE = re.compile(
    r"^\s+"                              # indentation (inside class)
    r"(?:static\s+)?"                    # optional static
    r"(?:[\w<>,?\s]+\s+)?(\w+)\s*"       # return type + name
    r"(<[^>]+>)?"                        # optional generics
    r"\(([^)]*)\)"                       # parameters
    r"\s*(?:async\s*)?(?:\{|=>|;)",      # body start
    re.MULTILINE,
)

# Constructor: ClassName(params) / ClassName.named(params)
_CONSTRUCTOR_RE = re.compile(
    r"^\s+"
    r"(?:const\s+|factory\s+)?"
    r"(\w+)(?:\.(\w+))?\s*"             # ClassName.namedCtor
    r"\(([^)]*)\)"                       # params
    r"\s*(?::\s*[^{]+)?(?:\{|=>|;)",     # initializer list + body
    re.MULTILINE,
)

# Field / property
_FIELD_RE = re.compile(
    r"^\s+"
    r"(?:static\s+)?(?:final\s+|const\s+|late\s+)*"
    r"([\w<>,?]+)\s+"                    # type
    r"(\w+)\s*"                          # name
    r"(?:=\s*[^;]+)?;",                  # optional initializer
    re.MULTILINE,
)

# Getter/setter
_GETTER_RE = re.compile(
    r"^\s+"
    r"(?:static\s+)?"
    r"(?:[\w<>,?]+\s+)?"
    r"get\s+(\w+)\s*(?:\{|=>)",
    re.MULTILINE,
)

_SETTER_RE = re.compile(
    r"^\s+"
    r"set\s+(\w+)\s*\(",
    re.MULTILINE,
)

# Function/method calls: name(, obj.name(, ClassName(
_CALL_RE = re.compile(r"(?:(\w+)\.)?(\w+)\s*\(", re.MULTILINE)

# Dart doc comments: /// comment
_DOC_COMMENT_RE = re.compile(r"(?:^\s*///\s?(.*?)$)+", re.MULTILINE)

# Annotation: @override, @required, @visibleForTesting
_ANNOTATION_RE = re.compile(r"^\s*@(\w+)", re.MULTILINE)

# Dart keywords that are NOT function names
_DART_KEYWORDS = frozenset({
    "if", "else", "for", "while", "do", "switch", "case", "break",
    "continue", "return", "throw", "try", "catch", "finally", "assert",
    "new", "const", "var", "final", "void", "null", "true", "false",
    "this", "super", "class", "extends", "implements", "with", "mixin",
    "enum", "abstract", "import", "export", "part", "library", "typedef",
    "dynamic", "await", "async", "yield", "get", "set", "operator",
    "late", "required", "covariant", "extension", "on", "show", "hide",
    "as", "is", "in", "factory", "static", "external",
})


def _find_block_end(source: str, open_brace_pos: int) -> int:
    """Find the matching closing brace for an opening brace."""
    depth = 0
    in_string = False
    string_char = ""
    i = open_brace_pos

    while i < len(source):
        ch = source[i]

        # Handle string literals
        if not in_string and ch in ("'", '"'):
            # Check for triple quotes
            if source[i:i + 3] in ("'''", '"""'):
                in_string = True
                string_char = source[i:i + 3]
                i += 3
                continue
            in_string = True
            string_char = ch
            i += 1
            continue

        if in_string:
            if len(string_char) == 3 and source[i:i + 3] == string_char:
                in_string = False
                i += 3
                continue
            elif len(string_char) == 1 and ch == string_char and (i == 0 or source[i - 1] != "\\"):
                in_string = False
                i += 1
                continue
            i += 1
            continue

        # Skip comments
        if ch == "/" and i + 1 < len(source):
            next_ch = source[i + 1]
            if next_ch == "/":
                # Line comment — skip to end of line
                nl = source.find("\n", i)
                i = nl + 1 if nl != -1 else len(source)
                continue
            elif next_ch == "*":
                # Block comment
                end = source.find("*/", i + 2)
                i = end + 2 if end != -1 else len(source)
                continue

        if ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                return i

        i += 1

    return len(source) - 1


def _extract_doc_comment(source: str, pos: int) -> str:
    """Extract /// doc comment immediately before a declaration."""
    lines = source[:pos].rstrip().split("\n")
    doc_lines = []

    for line in reversed(lines):
        stripped = line.strip()
        if stripped.startswith("///"):
            doc_lines.insert(0, stripped[3:].strip())
        elif stripped.startswith("@") or stripped == "":
            continue  # Skip annotations and blank lines
        else:
            break

    return " ".join(doc_lines).strip()[:4000] if doc_lines else ""


def _extract_annotations(source: str, pos: int) -> list[str]:
    """Extract @annotations immediately before a declaration."""
    lines = source[:pos].rstrip().split("\n")
    annotations = []

    for line in reversed(lines):
        stripped = line.strip()
        if stripped.startswith("@"):
            match = re.match(r"@(\w+)", stripped)
            if match:
                annotations.insert(0, match.group(1))
        elif stripped.startswith("///") or stripped == "":
            continue
        else:
            break

    return annotations


def _is_public(name: str) -> bool:
    """In Dart, names starting with _ are private."""
    return not name.startswith("_")


def _split_type_list(text: str) -> list[str]:
    """Split a comma-separated type list, handling generics."""
    if not text:
        return []
    # Remove generics for splitting
    depth = 0
    parts = []
    current = ""
    for ch in text:
        if ch == "<":
            depth += 1
        elif ch == ">":
            depth -= 1
        elif ch == "," and depth == 0:
            parts.append(current.strip())
            current = ""
            continue
        current += ch
    if current.strip():
        parts.append(current.strip())
    return [p.split("<")[0].strip() for p in parts if p.strip()]


class DartParser(BaseParser):
    """Dart parser for Flutter/Dart codebases."""

    def extensions(self) -> frozenset[str]:
        return frozenset({".dart"})

    def parse(self, path: Path, repo_root: Path) -> ParsedFile:
        rel = path.relative_to(repo_root).as_posix()
        source = path.read_text(encoding="utf-8", errors="replace")
        lines = source.split("\n")
        line_count = len(lines)

        nodes: list[ParsedNode] = []
        edges: list[ParsedEdge] = []
        chash = content_hash(source.encode("utf-8"))

        # File node
        file_id = rel
        # Extract library/part-of for docstring
        lib_match = re.search(r"^library\s+([\w.]+)\s*;", source, re.MULTILINE)
        file_doc = f"library {lib_match.group(1)}" if lib_match else ""
        if not file_doc:
            # Use first doc comment
            first_doc = re.search(r"^///\s?(.*)", source, re.MULTILINE)
            if first_doc:
                file_doc = first_doc.group(1).strip()

        nodes.append(ParsedNode(
            id=file_id,
            name=path.stem,
            qualified_name=path.stem,
            type="file",
            file_path=rel,
            line_start=1,
            line_end=line_count,
            docstring=file_doc,
            is_exported=True,
        ))

        # --- Imports ---
        for m in _IMPORT_RE.finditer(source):
            target = m.group(1)
            line = source[:m.start()].count("\n") + 1
            edges.append(ParsedEdge(
                source=file_id, target=target,
                type="IMPORTS", file_path=rel, line=line,
            ))

        for m in _EXPORT_RE.finditer(source):
            target = m.group(1)
            line = source[:m.start()].count("\n") + 1
            edges.append(ParsedEdge(
                source=file_id, target=target,
                type="IMPORTS", file_path=rel, line=line,
            ))

        # --- Classes ---
        for m in _CLASS_RE.finditer(source):
            cls_name = m.group(3)
            is_abstract = bool(m.group(2))
            extends = m.group(4)
            mixins_str = m.group(5)
            implements_str = m.group(6)
            line = source[:m.start()].count("\n") + 1

            brace_pos = m.end() - 1
            block_end = _find_block_end(source, brace_pos)
            end_line = source[:block_end].count("\n") + 1

            doc = _extract_doc_comment(source, m.start())
            annotations = _extract_annotations(source, m.start())
            if is_abstract:
                annotations = ["abstract"] + annotations

            cls_id = f"{rel}::{cls_name}"
            nodes.append(ParsedNode(
                id=cls_id,
                name=cls_name,
                qualified_name=cls_name,
                type="class",
                file_path=rel,
                line_start=line,
                line_end=end_line,
                docstring=doc,
                decorators=annotations,
                is_exported=_is_public(cls_name),
            ))

            edges.append(ParsedEdge(
                source=file_id, target=cls_id,
                type="CONTAINS", file_path=rel, line=line,
            ))

            # EXTENDS
            if extends:
                base_name = extends.split("<")[0].strip()
                edges.append(ParsedEdge(
                    source=cls_id, target=base_name,
                    type="EXTENDS", file_path=rel, line=line,
                ))

            # WITH (mixins)
            for mixin_name in _split_type_list(mixins_str):
                edges.append(ParsedEdge(
                    source=cls_id, target=mixin_name,
                    type="IMPLEMENTS", file_path=rel, line=line,
                ))

            # IMPLEMENTS
            for iface in _split_type_list(implements_str):
                edges.append(ParsedEdge(
                    source=cls_id, target=iface,
                    type="IMPLEMENTS", file_path=rel, line=line,
                ))

            # Parse class body
            class_body = source[brace_pos:block_end + 1]
            self._parse_class_body(
                class_body, cls_name, cls_id, rel, line,
                nodes, edges, source, brace_pos,
            )

        # --- Mixins ---
        for m in _MIXIN_RE.finditer(source):
            mixin_name = m.group(2)
            on_str = m.group(3)
            implements_str = m.group(4)
            line = source[:m.start()].count("\n") + 1

            brace_pos = m.end() - 1
            block_end = _find_block_end(source, brace_pos)
            end_line = source[:block_end].count("\n") + 1

            doc = _extract_doc_comment(source, m.start())

            mixin_id = f"{rel}::{mixin_name}"
            nodes.append(ParsedNode(
                id=mixin_id,
                name=mixin_name,
                qualified_name=mixin_name,
                type="class",
                file_path=rel,
                line_start=line,
                line_end=end_line,
                docstring=doc,
                decorators=["mixin"],
                is_exported=_is_public(mixin_name),
            ))

            edges.append(ParsedEdge(
                source=file_id, target=mixin_id,
                type="CONTAINS", file_path=rel, line=line,
            ))

            for base in _split_type_list(on_str):
                edges.append(ParsedEdge(
                    source=mixin_id, target=base,
                    type="EXTENDS", file_path=rel, line=line,
                ))

            for iface in _split_type_list(implements_str):
                edges.append(ParsedEdge(
                    source=mixin_id, target=iface,
                    type="IMPLEMENTS", file_path=rel, line=line,
                ))

            class_body = source[brace_pos:block_end + 1]
            self._parse_class_body(
                class_body, mixin_name, mixin_id, rel, line,
                nodes, edges, source, brace_pos,
            )

        # --- Enums ---
        for m in _ENUM_RE.finditer(source):
            enum_name = m.group(2)
            line = source[:m.start()].count("\n") + 1

            brace_pos = m.end() - 1
            block_end = _find_block_end(source, brace_pos)
            end_line = source[:block_end].count("\n") + 1

            doc = _extract_doc_comment(source, m.start())
            enum_body = source[brace_pos + 1:block_end]

            enum_id = f"{rel}::{enum_name}"
            nodes.append(ParsedNode(
                id=enum_id,
                name=enum_name,
                qualified_name=enum_name,
                type="class",
                file_path=rel,
                line_start=line,
                line_end=end_line,
                docstring=doc,
                decorators=["enum"],
                is_exported=_is_public(enum_name),
            ))

            edges.append(ParsedEdge(
                source=file_id, target=enum_id,
                type="CONTAINS", file_path=rel, line=line,
            ))

            # Extract enum values (before the first semicolon or method)
            enum_vals_section = enum_body.split(";")[0] if ";" in enum_body else enum_body
            for val_match in re.finditer(r"(\w+)(?:\s*\([^)]*\))?(?:\s*[,;}\n]|\s*$)", enum_vals_section):
                val_name = val_match.group(1)
                if val_name in _DART_KEYWORDS:
                    continue
                val_line = line + enum_body[:val_match.start()].count("\n")
                val_id = f"{rel}::{enum_name}.{val_name}"
                nodes.append(ParsedNode(
                    id=val_id,
                    name=val_name,
                    qualified_name=f"{enum_name}.{val_name}",
                    type="variable",
                    file_path=rel,
                    line_start=val_line,
                    line_end=val_line,
                    is_exported=_is_public(enum_name),
                ))
                edges.append(ParsedEdge(
                    source=enum_id, target=val_id,
                    type="CONTAINS", file_path=rel, line=val_line,
                ))

            # Parse with/implements for enhanced enums
            for mixin_name in _split_type_list(m.group(3)):
                edges.append(ParsedEdge(
                    source=enum_id, target=mixin_name,
                    type="IMPLEMENTS", file_path=rel, line=line,
                ))
            for iface in _split_type_list(m.group(4)):
                edges.append(ParsedEdge(
                    source=enum_id, target=iface,
                    type="IMPLEMENTS", file_path=rel, line=line,
                ))

        # --- Extensions ---
        for m in _EXTENSION_RE.finditer(source):
            ext_name = m.group(2)
            on_type = m.group(3).split("<")[0].strip()
            line = source[:m.start()].count("\n") + 1

            brace_pos = m.end() - 1
            block_end = _find_block_end(source, brace_pos)
            end_line = source[:block_end].count("\n") + 1

            doc = _extract_doc_comment(source, m.start())

            ext_id = f"{rel}::{ext_name}"
            nodes.append(ParsedNode(
                id=ext_id,
                name=ext_name,
                qualified_name=ext_name,
                type="class",
                file_path=rel,
                line_start=line,
                line_end=end_line,
                docstring=doc,
                decorators=["extension"],
                is_exported=_is_public(ext_name),
            ))

            edges.append(ParsedEdge(
                source=file_id, target=ext_id,
                type="CONTAINS", file_path=rel, line=line,
            ))

            edges.append(ParsedEdge(
                source=ext_id, target=on_type,
                type="EXTENDS", file_path=rel, line=line,
            ))

            class_body = source[brace_pos:block_end + 1]
            self._parse_class_body(
                class_body, ext_name, ext_id, rel, line,
                nodes, edges, source, brace_pos,
            )

        # --- Top-level functions ---
        # Only match at column 0 (not inside classes)
        for m in re.finditer(
            r"^(?:([\w<>,?\s]+)\s+)?(\w+)\s*(<[^>]+>)?\(([^)]*)\)\s*(?:async\s*)?(?:\{|=>)",
            source, re.MULTILINE,
        ):
            func_name = m.group(2)
            if func_name in _DART_KEYWORDS:
                continue
            # Skip if this is inside a class (check indentation)
            line_start_pos = source.rfind("\n", 0, m.start()) + 1
            indent = m.start() - line_start_pos
            if indent > 0:
                continue

            line = source[:m.start()].count("\n") + 1
            params = m.group(4).strip()
            return_type = (m.group(1) or "").strip()

            # Find function end
            brace_pos = source.find("{", m.end() - 2)
            arrow_pos = source.find("=>", m.end() - 3)

            if "=>" in source[m.end() - 3:m.end() + 1]:
                # Arrow function — find semicolon
                semi = source.find(";", m.end())
                end_pos = semi if semi != -1 else m.end() + 50
            elif brace_pos != -1 and brace_pos < m.end() + 2:
                end_pos = _find_block_end(source, brace_pos)
            else:
                end_pos = m.end()

            end_line = source[:end_pos].count("\n") + 1

            sig = f"{func_name}({params})"
            if return_type:
                sig = f"{return_type} {sig}"

            doc = _extract_doc_comment(source, m.start())
            annotations = _extract_annotations(source, m.start())

            func_id = f"{rel}::{func_name}"
            nodes.append(ParsedNode(
                id=func_id,
                name=func_name,
                qualified_name=func_name,
                type="function",
                file_path=rel,
                line_start=line,
                line_end=end_line,
                signature=sig,
                docstring=doc,
                decorators=annotations,
                is_exported=_is_public(func_name),
            ))

            edges.append(ParsedEdge(
                source=file_id, target=func_id,
                type="CONTAINS", file_path=rel, line=line,
            ))

            # Extract calls from function body
            func_body = source[m.end():end_pos]
            self._extract_calls(func_body, func_id, rel, line, edges)

        # --- Top-level variables ---
        for m in re.finditer(
            r"^(?:final|const|var|late\s+final|late)\s+"
            r"(?:([\w<>,?]+)\s+)?(\w+)\s*=",
            source, re.MULTILINE,
        ):
            var_name = m.group(2)
            if var_name in _DART_KEYWORDS:
                continue
            line = source[:m.start()].count("\n") + 1
            var_id = f"{rel}::{var_name}"
            nodes.append(ParsedNode(
                id=var_id,
                name=var_name,
                qualified_name=var_name,
                type="variable",
                file_path=rel,
                line_start=line,
                line_end=line,
                is_exported=_is_public(var_name),
            ))
            edges.append(ParsedEdge(
                source=file_id, target=var_id,
                type="CONTAINS", file_path=rel, line=line,
            ))

        return ParsedFile(
            path=rel,
            content_hash=chash,
            nodes=nodes,
            edges=edges,
            line_count=line_count,
        )

    def _parse_class_body(
        self,
        body: str,
        cls_name: str,
        cls_id: str,
        rel: str,
        cls_start_line: int,
        nodes: list[ParsedNode],
        edges: list[ParsedEdge],
        full_source: str,
        body_offset: int,
    ) -> None:
        """Parse methods, constructors, fields, getters inside a class body."""
        # Track names we've already added to avoid duplicates
        seen_names: set[str] = set()

        # --- Constructors ---
        for m in _CONSTRUCTOR_RE.finditer(body):
            ctor_class = m.group(1)
            named = m.group(2)
            params = m.group(3).strip()

            if ctor_class != cls_name:
                continue

            name = f"{cls_name}.{named}" if named else "__init__"
            if name in seen_names:
                continue
            seen_names.add(name)

            line = cls_start_line + body[:m.start()].count("\n")
            sig = f"{ctor_class}({params})" if not named else f"{ctor_class}.{named}({params})"

            abs_pos = body_offset + m.start()
            doc = _extract_doc_comment(full_source, abs_pos)

            ctor_id = f"{rel}::{cls_name}.{name}"
            nodes.append(ParsedNode(
                id=ctor_id,
                name=name,
                qualified_name=f"{cls_name}.{name}",
                type="method",
                file_path=rel,
                line_start=line,
                line_end=line,
                signature=sig,
                docstring=doc,
                is_exported=_is_public(name),
            ))
            edges.append(ParsedEdge(
                source=cls_id, target=ctor_id,
                type="CONTAINS", file_path=rel, line=line,
            ))

        # --- Methods ---
        for m in _METHOD_RE.finditer(body):
            method_name = m.group(1)
            if method_name in _DART_KEYWORDS or method_name == cls_name:
                continue
            if method_name in seen_names:
                continue
            seen_names.add(method_name)

            params = m.group(3).strip()
            line = cls_start_line + body[:m.start()].count("\n")
            sig = f"{method_name}({params})"

            abs_pos = body_offset + m.start()
            doc = _extract_doc_comment(full_source, abs_pos)
            # Extract annotations from lines preceding this method in the body
            preceding_lines = body[:m.start()].rstrip().split("\n")
            annotations = []
            for prev_line in reversed(preceding_lines):
                stripped = prev_line.strip()
                ann_m = re.match(r"@(\w+)", stripped)
                if ann_m:
                    annotations.insert(0, ann_m.group(1))
                elif stripped.startswith("///") or stripped == "":
                    continue
                else:
                    break

            method_id = f"{rel}::{cls_name}.{method_name}"
            nodes.append(ParsedNode(
                id=method_id,
                name=method_name,
                qualified_name=f"{cls_name}.{method_name}",
                type="method",
                file_path=rel,
                line_start=line,
                line_end=line,
                signature=sig,
                docstring=doc,
                decorators=annotations,
                is_exported=_is_public(method_name),
            ))
            edges.append(ParsedEdge(
                source=cls_id, target=method_id,
                type="CONTAINS", file_path=rel, line=line,
            ))

            # Extract calls from method body (approximate)
            method_body_start = m.end()
            # Find next method or end of body
            next_method = _METHOD_RE.search(body, method_body_start)
            method_body_end = next_method.start() if next_method else len(body)
            method_body = body[method_body_start:method_body_end]
            self._extract_calls(method_body, method_id, rel, line, edges)

        # --- Getters ---
        for m in _GETTER_RE.finditer(body):
            getter_name = m.group(1)
            if getter_name in seen_names:
                continue
            seen_names.add(getter_name)

            line = cls_start_line + body[:m.start()].count("\n")
            getter_id = f"{rel}::{cls_name}.{getter_name}"
            nodes.append(ParsedNode(
                id=getter_id,
                name=getter_name,
                qualified_name=f"{cls_name}.{getter_name}",
                type="method",
                file_path=rel,
                line_start=line,
                line_end=line,
                signature=f"get {getter_name}",
                is_exported=_is_public(getter_name),
            ))
            edges.append(ParsedEdge(
                source=cls_id, target=getter_id,
                type="CONTAINS", file_path=rel, line=line,
            ))

        # --- Fields ---
        for m in _FIELD_RE.finditer(body):
            field_type = m.group(1)
            field_name = m.group(2)
            if field_name in _DART_KEYWORDS or field_name in seen_names:
                continue
            # Skip if it's actually a method return type
            if field_type in _DART_KEYWORDS:
                continue
            seen_names.add(field_name)

            line = cls_start_line + body[:m.start()].count("\n")
            field_id = f"{rel}::{cls_name}.{field_name}"
            nodes.append(ParsedNode(
                id=field_id,
                name=field_name,
                qualified_name=f"{cls_name}.{field_name}",
                type="variable",
                file_path=rel,
                line_start=line,
                line_end=line,
                is_exported=_is_public(field_name),
            ))
            edges.append(ParsedEdge(
                source=cls_id, target=field_id,
                type="CONTAINS", file_path=rel, line=line,
            ))

    def _extract_calls(
        self,
        body: str,
        caller_id: str,
        rel: str,
        base_line: int,
        edges: list[ParsedEdge],
    ) -> None:
        """Extract function/method calls from a code body."""
        seen: set[str] = set()
        for m in _CALL_RE.finditer(body):
            obj = m.group(1)
            method = m.group(2)
            if method in _DART_KEYWORDS:
                continue

            line = base_line + body[:m.start()].count("\n")

            if obj:
                target = f"{obj}.{method}"
            else:
                target = method

            if target in seen:
                continue
            seen.add(target)

            edges.append(ParsedEdge(
                source=caller_id, target=target,
                type="CALLS", file_path=rel, line=line,
            ))

            # Also emit bare method name for cross-file resolution
            if obj and method not in seen:
                seen.add(method)
                edges.append(ParsedEdge(
                    source=caller_id, target=method,
                    type="CALLS", file_path=rel, line=line,
                ))
