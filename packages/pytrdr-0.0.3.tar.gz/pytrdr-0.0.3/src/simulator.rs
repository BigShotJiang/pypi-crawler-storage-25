// [AI_HEADER]: Discrete-Event Simulator (DES) - The Time Machine Engine.
// [TYPE]: Module: simulator
// [INTERFACE]: BacktestRunner
// [CONSTRAINTS]: Precision Tick Replay. 100% Deterministic.
// [PURPOSE]: Replaying history to validate EAs with ultimate fidelity.

#[cfg(feature = "python")]
use arrow::record_batch::RecordBatch;
#[cfg(feature = "python")]
use arrow::array::{Decimal128Array, StringArray, TimestampNanosecondArray};
use crate::account::AccountState;
use crate::matching::MatchingEngine;
#[cfg(feature = "python")]
use crate::traits::Tick;
#[cfg(feature = "python")]
use crate::schema::SCALE;
use rust_decimal::Decimal;
#[cfg(feature = "python")]
use rust_decimal_macros::dec;
#[cfg(feature = "python")]
use std::collections::HashMap;

#[cfg(feature = "python")]
use chrono::{DateTime, Utc, TimeZone};

pub struct BacktestReport {
    pub total_trades: usize,
    pub final_equity: Decimal,
    pub max_drawdown: Decimal,
    pub win_rate: f64,
}

pub struct BacktestRunner {
    pub account: AccountState,
    pub engine: MatchingEngine,
}

impl BacktestRunner {
    pub fn new(initial_balance: Decimal, leverage: Decimal) -> Self {
        Self {
            account: AccountState::new(initial_balance, leverage),
            engine: MatchingEngine::new(),
        }
    }

    /// Run a tick-by-tick simulation on a RecordBatch.
    /// Accuracy First: Processes every single price change in order.
    #[cfg(feature = "python")]
    pub fn run_simulation(&mut self, batch: RecordBatch) -> Result<BacktestReport, crate::error::PyTraderError> {
        let num_rows = batch.num_rows();
        
        // Extract Columns (Accuracy: Decimal128)
        let symbols = batch.column(0).as_any().downcast_ref::<StringArray>().unwrap();
        let bids = batch.column(1).as_any().downcast_ref::<Decimal128Array>().unwrap();
        let asks = batch.column(2).as_any().downcast_ref::<Decimal128Array>().unwrap();
        let volumes = batch.column(3).as_any().downcast_ref::<Decimal128Array>().unwrap();
        let timestamps = batch.column(4).as_any().downcast_ref::<TimestampNanosecondArray>().unwrap();

        let mut max_equity = self.account.balance;
        let mut max_drawdown = dec!(0.0);

        for i in 0..num_rows {
            let symbol = symbols.value(i).to_string();
            let bid = Decimal::from_i128_with_scale(bids.value(i), SCALE as u32);
            let ask = Decimal::from_i128_with_scale(asks.value(i), SCALE as u32);
            let volume = Decimal::from_i128_with_scale(volumes.value(i), SCALE as u32);
            let timestamp: DateTime<Utc> = Utc.timestamp_nanos(timestamps.value(i));

            let tick = Tick {
                symbol: symbol.clone(),
                bid,
                ask,
                volume,
                timestamp,
            };

            // 1. Update Market Prices for OME
            let mut current_prices = HashMap::new();
            current_prices.insert(symbol.clone(), tick.clone());

            // 2. Check for SL/TP or Pending Orders
            self.engine.update_positions(&current_prices);

            // 3. Update Account Equity (Precision check: Bid/Ask fidelity)
            self.account.update_equity(&self.engine.open_positions, &current_prices);

            // 4. Calculate Drawdown
            if self.account.equity > max_equity {
                max_equity = self.account.equity;
            }
            let dd = max_equity - self.account.equity;
            if dd > max_drawdown {
                max_drawdown = dd;
            }

            // [NOTE]: Here we would call the EA Strategy via an event callback
            // if we were running a full Strategy backtest.
        }

        Ok(BacktestReport {
            total_trades: self.engine.closed_positions.len(),
            final_equity: self.account.equity,
            max_drawdown,
            win_rate: 0.0, // Calculate later
        })
    }
}
