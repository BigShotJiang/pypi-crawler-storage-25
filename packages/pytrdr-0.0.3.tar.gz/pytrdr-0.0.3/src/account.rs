// [AI_HEADER]: Account Core - Precision Financial State Management.
// [TYPE]: Module: account
// [INTERFACE]: AccountState, Position
// [CONSTRAINTS]: 100% rust_decimal precision. NO f64.
// [PURPOSE]: Managing capital, margin, and exposure in the simulator.

use rust_decimal::Decimal;
use rust_decimal_macros::dec;
use serde::{Deserialize, Serialize};

/// Direction of the trading position.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum PositionSide {
    Buy,
    Sell,
}

/// Represents an open or closed trading position (Active Trade).
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Position {
    pub id: String,
    pub symbol: String,
    pub side: PositionSide,
    pub volume: Decimal,
    pub entry_price: Decimal,
    pub exit_price: Option<Decimal>,
    pub profit: Option<Decimal>,
    pub status: PositionStatus,
    pub sl: Option<Decimal>,
    pub tp: Option<Decimal>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum PositionStatus {
    Open,
    Closed,
}

/// The financial state of an account. 
/// Every calculation here must be perfect (Accuracy First).
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AccountState {
    pub balance: Decimal,
    pub equity: Decimal,
    pub margin: Decimal,
    pub free_margin: Decimal,
    pub leverage: Decimal,
}

impl AccountState {
    pub fn new(initial_balance: Decimal, leverage: Decimal) -> Self {
        Self {
            balance: initial_balance,
            equity: initial_balance,
            margin: dec!(0.0),
            free_margin: initial_balance,
            leverage,
        }
    }

    /// Calculate the floating Profit/Loss based on current market price.
    /// Accuracy First: Handles both Buy (Long) and Sell (Short) sides with Bid/Ask fidelity.
    pub fn update_equity(&mut self, open_positions: &[Position], current_prices: &std::collections::HashMap<String, crate::traits::Tick>) {
        let mut floating_pl = dec!(0.0);
        
        for pos in open_positions {
            if let Some(tick) = current_prices.get(&pos.symbol) {
                // Institutional P/L Calculation:
                // Long (Buy):  Closed at Bid   | P/L = (Bid - Entry) * Volume
                // Short (Sell): Closed at Ask   | P/L = (Entry - Ask) * Volume
                let p_l = match pos.side {
                    PositionSide::Buy => (tick.bid - pos.entry_price) * pos.volume,
                    PositionSide::Sell => (pos.entry_price - tick.ask) * pos.volume,
                };
                floating_pl += p_l;
            }
        }
        
        self.equity = self.balance + floating_pl;
        self.free_margin = self.equity - self.margin;
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::traits::Tick;
    use rust_decimal_macros::dec;
    use chrono::Utc;
    use std::collections::HashMap;

    #[test]
    fn test_equity_calculation_dual_side() {
        let mut account = AccountState::new(dec!(10000.0), dec!(100.0));
        let mut prices = HashMap::new();
        
        let sym = "EURUSD".to_string();
        // Current Market: Bid 1.0500, Ask 1.0502
        prices.insert(sym.clone(), Tick {
            symbol: sym.clone(),
            bid: dec!(1.0500),
            ask: dec!(1.0502),
            volume: dec!(100),
            timestamp: Utc::now(),
        });

        let positions = vec![
            Position {
                id: "B1".to_string(),
                symbol: sym.clone(),
                side: PositionSide::Buy,
                volume: dec!(100000.0), // 1 Lot
                entry_price: dec!(1.0400),
                exit_price: None,
                profit: None,
                status: PositionStatus::Open,
                sl: None,
                tp: None,
            },
            Position {
                id: "S1".to_string(),
                symbol: sym.clone(),
                side: PositionSide::Sell,
                volume: dec!(100000.0), // 1 Lot
                entry_price: dec!(1.0600),
                exit_price: None,
                profit: None,
                status: PositionStatus::Open,
                sl: None,
                tp: None,
            },
        ];

        account.update_equity(&positions, &prices);

        // Buy P/L: (1.0500 - 1.0400) * 100,000 = +1,000
        // Sell P/L: (1.0600 - 1.0502) * 100,000 = +980
        // Total P/L: +1,980
        // Final Equity: 11,980
        assert_eq!(account.equity, dec!(11980.0));
    }
}
