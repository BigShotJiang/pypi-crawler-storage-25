// [AI_HEADER]: Order Matching Engine (OME) - High-Fidelity Simulation.
// [TYPE]: Module: matching
// [INTERFACE]: MatchingEngine
// [CONSTRAINTS]: Precision Matching. Slippage & Spread Simulation.
// [PURPOSE]: Simulating broker execution logic with 100% fidelity.

use crate::traits::{OrderRequest, OrderAction, Tick};
use crate::account::{Position, PositionStatus, PositionSide};
use rust_decimal::Decimal;
use std::collections::HashMap;

pub struct MatchingEngine {
    pub open_positions: Vec<Position>,
    pub closed_positions: Vec<Position>,
    pub last_id: u64,
}

impl MatchingEngine {
    pub fn new() -> Self {
        Self {
            open_positions: Vec::new(),
            closed_positions: Vec::new(),
            last_id: 0,
        }
    }

    /// Process a new Order Request using the latest market tick.
    /// Accuracy First: Handles side assignment and slippage.
    pub fn process_order(&mut self, request: OrderRequest, tick: &Tick, slippage_pips: Decimal) -> Position {
        self.last_id += 1;
        let id = format!("TRD_{}", self.last_id);
        
        let side = match request.action {
            OrderAction::Buy => PositionSide::Buy,
            OrderAction::Sell => PositionSide::Sell,
        };

        let execution_price = match side {
            PositionSide::Buy => tick.ask + slippage_pips,
            PositionSide::Sell => tick.bid - slippage_pips,
        };

        let position = Position {
            id,
            symbol: request.symbol,
            side,
            volume: request.volume,
            entry_price: execution_price,
            exit_price: None,
            profit: None,
            status: PositionStatus::Open,
            sl: request.sl,
            tp: request.tp,
        };

        self.open_positions.push(position.clone());
        position
    }

    /// Check for SL/TP hits on open positions based on current market price.
    /// Fidelity: Handles Side-dependent SL/TP triggers and records P/L.
    pub fn update_positions(&mut self, current_prices: &HashMap<String, Tick>) {
        let mut to_close = Vec::new();

        for (i, pos) in self.open_positions.iter_mut().enumerate() {
            if let Some(tick) = current_prices.get(&pos.symbol) {
                let mut should_close = false;
                let mut exit_price = Decimal::ZERO;

                match pos.side {
                    PositionSide::Buy => {
                        // Long Position: Closes at Bid (Ask to Open)
                        if let Some(sl) = pos.sl {
                            if tick.bid <= sl { should_close = true; exit_price = sl; }
                        }
                        if let Some(tp) = pos.tp {
                            if tick.bid >= tp { should_close = true; exit_price = tp; }
                        }
                    }
                    PositionSide::Sell => {
                        // Short Position: Closes at Ask (Bid to Open)
                        if let Some(sl) = pos.sl {
                            if tick.ask >= sl { should_close = true; exit_price = sl; }
                        }
                        if let Some(tp) = pos.tp {
                            if tick.ask <= tp { should_close = true; exit_price = tp; }
                        }
                    }
                }

                if should_close {
                    // Record Exit Data
                    pos.exit_price = Some(exit_price);
                    pos.profit = match pos.side {
                        PositionSide::Buy => Some((exit_price - pos.entry_price) * pos.volume),
                        PositionSide::Sell => Some((pos.entry_price - exit_price) * pos.volume),
                    };
                    to_close.push(i);
                }
            }
        }

        // Move to closed list
        for &index in to_close.iter().rev() {
            let mut pos = self.open_positions.remove(index);
            pos.status = PositionStatus::Closed;
            self.closed_positions.push(pos);
        }
    }
}
