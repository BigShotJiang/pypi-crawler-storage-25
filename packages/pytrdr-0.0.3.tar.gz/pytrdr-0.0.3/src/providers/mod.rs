// [AI_HEADER]: Providers Module - Registry of Market Data Adapters.
// [TYPE]: Registry: mod providers
// [EXPORTS]: SimulatedFeed
// [PURPOSE]: Centralizing data ingestion handlers.

pub mod simulated;

pub use simulated::SimulatedFeed;
