// [AI_HEADER]: Simulated Market Provider - Accuracy-First Tick Generator.
// [TYPE]: Provider: SimulatedFeed
// [INTERFACE]: MarketProvider Trait
// [CONSTRAINTS]: Decimal-based random walk. High precision.
// [PURPOSE]: Stress-testing the Arrow ingestion pipeline with financial fidelity.

use crate::traits::{Tick, MarketProvider};
use crate::error::PyTraderError;
#[cfg(feature = "python")]
use crate::schema::get_tick_schema;
#[cfg(feature = "python")]
use crate::schema::{PRECISION, SCALE};
#[cfg(feature = "python")]
use arrow::array::{Decimal128Array, StringArray, TimestampNanosecondArray};
#[cfg(feature = "python")]
use arrow::record_batch::RecordBatch;
#[cfg(feature = "python")]
use std::sync::Arc;

use chrono::Utc;
use rand::Rng;
use rust_decimal::Decimal;
use rust_decimal_macros::dec;
use rust_decimal::prelude::*;
use std::collections::HashMap;


pub struct SimulatedFeed {
    symbols: Vec<String>,
    prices: HashMap<String, Decimal>,
}

impl SimulatedFeed {
    pub fn new(symbols: Vec<String>) -> Self {
        let mut prices = HashMap::new();
        for s in &symbols {
            prices.insert(s.clone(), dec!(100.00000)); // Start at exactly 100.00000
        }
        Self { symbols, prices }
    }

    /// Convert a batch of Ticks into an Arrow RecordBatch for zero-copy transmission
    #[cfg(feature = "python")]
    pub fn into_record_batch(ticks: &[Tick]) -> Result<RecordBatch, PyTraderError> {
        let schema = get_tick_schema();
        
        let symbols: Vec<&str> = ticks.iter().map(|t| t.symbol.as_str()).collect();
        
        // Convert Decimal to i128 for Arrow Decimal128Array
        let bids: Vec<i128> = ticks.iter().map(|t| {
            let mut v = t.bid;
            v.rescale(SCALE as u32);
            v.mantissa()
        }).collect();
        
        let asks: Vec<i128> = ticks.iter().map(|t| {
            let mut v = t.ask;
            v.rescale(SCALE as u32);
            v.mantissa()
        }).collect();

        let volumes: Vec<i128> = ticks.iter().map(|t| {
            let mut v = t.volume;
            v.rescale(SCALE as u32);
            v.mantissa()
        }).collect();

        let timestamps: Vec<i64> = ticks.iter().map(|t| t.timestamp.timestamp_nanos_opt().unwrap_or(0)).collect();

        let symbol_array = StringArray::from(symbols);
        
        let bid_array = Decimal128Array::from(bids)
            .with_precision_and_scale(PRECISION, SCALE)
            .map_err(|e| PyTraderError::InternalError(format!("Arrow Precision Error: {}", e)))?;
            
        let ask_array = Decimal128Array::from(asks)
            .with_precision_and_scale(PRECISION, SCALE)
            .map_err(|e| PyTraderError::InternalError(format!("Arrow Precision Error: {}", e)))?;

        let volume_array = Decimal128Array::from(volumes)
            .with_precision_and_scale(PRECISION, SCALE)
            .map_err(|e| PyTraderError::InternalError(format!("Arrow Precision Error: {}", e)))?;

        let timestamp_array = TimestampNanosecondArray::from(timestamps).with_timezone("UTC");

        RecordBatch::try_new(
            schema,
            vec![
                Arc::new(symbol_array),
                Arc::new(bid_array),
                Arc::new(ask_array),
                Arc::new(volume_array),
                Arc::new(timestamp_array),
            ],
        ).map_err(|e| PyTraderError::InternalError(format!("Arrow Batch Error: {}", e)))
    }

    /// Generate a batch of synthetic ticks with decimal precision
    pub fn generate_ticks(&mut self, count: usize) -> Vec<Tick> {
        let mut rng = rand::thread_rng();
        let mut ticks = Vec::with_capacity(count);

        for _ in 0..count {
            for symbol in &self.symbols {
                let current_price = self.prices.get_mut(symbol).unwrap();
                
                // Random walk using Decimal for 100% accuracy
                let change_f64 = (rng.gen::<f64>() - 0.5) * 0.1;
                let change = Decimal::from_f64(change_f64).unwrap_or(dec!(0.0));
                
                *current_price += change;

                ticks.push(Tick {
                    symbol: symbol.clone(),
                    bid: *current_price,
                    ask: *current_price + dec!(0.02000), // Exactly 2 pips spread
                    volume: Decimal::from_f64(rng.gen_range(1.0..10.0)).unwrap_or(dec!(1.0)),
                    timestamp: Utc::now(),
                });
            }
        }
        ticks
    }
}

impl MarketProvider for SimulatedFeed {
    fn connect(&mut self) -> Result<(), PyTraderError> {
        Ok(())
    }

    fn subscribe(&mut self, symbol: &str) -> Result<(), PyTraderError> {
        if !self.symbols.contains(&symbol.to_string()) {
            self.symbols.push(symbol.to_string());
            self.prices.insert(symbol.to_string(), dec!(100.00000));
        }
        Ok(())
    }

    fn get_latest_tick(&self, symbol: &str) -> Result<Tick, PyTraderError> {
        let price = self.prices.get(symbol).ok_or_else(|| {
            PyTraderError::InternalError(format!("Symbol {} not found", symbol))
        })?;
        
        Ok(Tick {
            symbol: symbol.to_string(),
            bid: *price,
            ask: *price + dec!(0.01000),
            volume: dec!(1.0),
            timestamp: Utc::now(),
        })
    }

    fn disconnect(&mut self) -> Result<(), PyTraderError> {
        Ok(())
    }
}
