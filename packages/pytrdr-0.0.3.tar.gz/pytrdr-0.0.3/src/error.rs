// [AI_HEADER]: Centralized Failure Protection - Unified Error Architecture for PyTrader.
// [TYPE]: Enum: PyTraderError
// [INTERFACE]: impl From<PyTraderError> for PyErr (Rust -> Python exception bridge)
// [CONSTRAINTS]: All internal Rust failures MUST be mapped to this Enum.
// [PURPOSE]: Fault localization and type-safe exception propagation.

#[cfg(feature = "python")]
use pyo3::exceptions::PyException;
#[cfg(feature = "python")]
use pyo3::prelude::*;
use std::fmt;

/// Standardized Error categories for PyTrader Core
#[derive(Debug)]
pub enum PyTraderError {
    NetworkError(String),
    ProtocolError(String),
    RiskLimitExceeded(String),
    InternalError(String),
    MemoryError(String),
    AuthenticationFailed(String),
}

impl fmt::Display for PyTraderError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::NetworkError(e) => write!(f, "Network Error: {}", e),
            Self::ProtocolError(e) => write!(f, "Protocol Error: {}", e),
            Self::RiskLimitExceeded(e) => write!(f, "Risk Limit Exceeded: {}", e),
            Self::InternalError(e) => write!(f, "Internal System Error: {}", e),
            Self::MemoryError(e) => write!(f, "Memory/Buffer Error: {}", e),
            Self::AuthenticationFailed(e) => write!(f, "Auth Failed: {}", e),
        }
    }
}

impl std::error::Error for PyTraderError {}

/// Map Rust-native error type to Python-side Exception
#[cfg(feature = "python")]
impl From<PyTraderError> for PyErr {
    fn from(error: PyTraderError) -> PyErr {
        PyException::new_err(error.to_string())
    }
}
