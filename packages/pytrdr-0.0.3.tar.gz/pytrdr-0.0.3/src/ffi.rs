// [AI_HEADER]: Manual Arrow FFI Bridge - Zero-Copy PyCapsule Implementation.
// [TYPE]: Bridge: mod ffi
// [INTERFACE]: Arrow PyCapsule Protocol
// [PROTOCOL]: __arrow_c_stream__
// [PURPOSE]: Exporting Arrow buffers to Python with zero overhead.

#[cfg(feature = "python")]
mod python_ffi {
    use pyo3::prelude::*;
    use pyo3::types::PyCapsule;
    use arrow::record_batch::RecordBatch;
    use arrow::ffi_stream::{FFI_ArrowArrayStream, export_reader_into_raw};
    use arrow::array::RecordBatchReader;
    use std::sync::Arc;
    use std::ffi::CStr;

    #[pyclass(module = "pytrdr._core")]
    #[derive(Clone)]
    pub struct ArrowBatchExporter {
        pub batch: Option<RecordBatch>,
    }

    impl ArrowBatchExporter {
        pub fn new(batch: RecordBatch) -> Self {
            Self { batch: Some(batch) }
        }
    }

    #[pymethods]
    impl ArrowBatchExporter {
        /// The standardized method for Arrow zero-copy ingestion.
        /// [REF]: https://arrow.apache.org/docs/format/CDataInterface/PyCapsuleInterface.html
        pub fn __arrow_c_stream__<'py>(
            &mut self,
            _py: Python<'py>,
            _requested_schema: Option<Bound<'py, PyCapsule>>,
        ) -> PyResult<Bound<'py, PyCapsule>> {
            let batch = self.batch.take().ok_or_else(|| {
                pyo3::exceptions::PyRuntimeError::new_err("Batch already consumed")
            })?;

            // Create a RecordBatchReader from the single batch
            let reader = Box::new(SingleBatchReader::new(batch));
            
            // Allocate the ArrowArrayStream on the heap
            let stream = Box::new(FFI_ArrowArrayStream::empty());
            let stream_ptr = Box::into_raw(stream);

            unsafe {
                export_reader_into_raw(reader, stream_ptr);
            }

            // Define the capsule name as a static C-string literal to ensure lifetime safety
            const CAPSULE_NAME: &CStr = c"arrow_array_stream";
            
            unsafe {
                let capsule_ptr = pyo3::ffi::PyCapsule_New(
                    stream_ptr as *mut _,
                    CAPSULE_NAME.as_ptr(),
                    Some(capsule_destructor_ffi),
                );
                
                if capsule_ptr.is_null() {
                    return Err(PyErr::fetch(_py));
                }
                
                Ok(Bound::from_owned_ptr(_py, capsule_ptr).downcast_into_unchecked())
            }
        }
    }

    /// Custom destructor to free the ArrowArrayStream pointer when Python is done with it.
    unsafe extern "C" fn capsule_destructor_ffi(capsule: *mut pyo3::ffi::PyObject) {
        const CAPSULE_NAME: &CStr = c"arrow_array_stream";
        let ptr = pyo3::ffi::PyCapsule_GetPointer(capsule, CAPSULE_NAME.as_ptr());
        if !ptr.is_null() {
            let stream_ptr = ptr as *mut FFI_ArrowArrayStream;
            // Re-construct the Box and let it drop to free the memory
            let _ = Box::from_raw(stream_ptr);
        }
    }

    /// Helper to wrap a single RecordBatch as a Reader
    struct SingleBatchReader {
        batch: Option<RecordBatch>,
        schema: Arc<arrow::datatypes::Schema>,
    }

    impl SingleBatchReader {
        fn new(batch: RecordBatch) -> Self {
            let schema = batch.schema();
            Self { batch: Some(batch), schema }
        }
    }

    impl Iterator for SingleBatchReader {
        type Item = arrow::error::Result<RecordBatch>;

        fn next(&mut self) -> Option<Self::Item> {
            self.batch.take().map(Ok)
        }
    }

    impl RecordBatchReader for SingleBatchReader {
        fn schema(&self) -> Arc<arrow::datatypes::Schema> {
            self.schema.clone()
        }
    }
}

#[cfg(feature = "python")]
pub use python_ffi::ArrowBatchExporter;
