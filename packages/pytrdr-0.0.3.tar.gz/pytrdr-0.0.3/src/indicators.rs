// [AI_HEADER]: Technical Analysis Engine - High-Precision Decimal Indicators.
// [TYPE]: Module: indicators
// [INTERFACE]: SMA, RSI
// [CONSTRAINTS]: Operate directly on arrow-rs Decimal128Array. Fixed-point math.
// [PURPOSE]: Ensuring 100% financial accuracy in signal generation.

#[cfg(feature = "python")]
mod python_indicators {
    use arrow::array::{Decimal128Array, Array, ArrayRef};
    use arrow::datatypes::{DataType, Field, Schema};
    use arrow::record_batch::RecordBatch;
    use rust_decimal::Decimal;
    use std::sync::Arc;

    use crate::schema::{PRECISION, SCALE};

    /// Enriches a RecordBatch with a high-precision decimal indicator column.
    pub fn enrich_batch(
        batch: RecordBatch,
        source_col: &str,
        indicator_name: &str,
        period: usize,
    ) -> Result<RecordBatch, crate::error::PyTraderError> {
        let _row_count = batch.num_rows();
        let schema = batch.schema();
        let mut columns: Vec<ArrayRef> = batch.columns().to_vec();
        
        // Find source column (must be Decimal128)
        let col_index: usize = schema.index_of(source_col).map_err(|_| {
            crate::error::PyTraderError::InternalError(format!("Column {} not found", source_col))
        })?;

        let array = columns[col_index]
            .as_any()
            .downcast_ref::<Decimal128Array>()
            .ok_or_else(|| {
                crate::error::PyTraderError::InternalError(format!("Column {} is not Decimal128", source_col))
            })?;

        // Compute indicator
        let indicator_array: ArrayRef = match indicator_name {
            "SMA" => Arc::new(compute_sma(array, period)),
            "RSI" => Arc::new(compute_rsi(array, period)),
            _ => return Err(crate::error::PyTraderError::InternalError("Unknown indicator".into())),
        };

        // Update Columns
        columns.push(indicator_array);

        // Update Schema (Stay in Decimal128 for consistency)
        let mut fields = schema.fields().to_vec();
        fields.push(Arc::new(Field::new(
            format!("{}_{}", indicator_name, period),
            DataType::Decimal128(PRECISION, SCALE),
            true,
        )));
        let new_schema = Arc::new(Schema::new(fields));

        RecordBatch::try_new(new_schema, columns).map_err(|e| {
            crate::error::PyTraderError::InternalError(format!("Arrow Enrichment Error: {}", e))
        })
    }

    /// Helper to convert Arrow i128 to rust_decimal::Decimal
    fn arrow_to_decimal(val: i128) -> Decimal {
        Decimal::from_i128_with_scale(val, SCALE as u32)
    }

    /// Helper to convert rust_decimal::Decimal to Arrow i128
    fn decimal_to_arrow(decimal: Decimal) -> i128 {
        let mut scaled = decimal;
        scaled.rescale(SCALE as u32);
        scaled.mantissa()
    }

    /// High-precision Vectorized SMA
    pub fn compute_sma(array: &Decimal128Array, period: usize) -> Decimal128Array {
        let len = array.len();
        let mut result = Vec::with_capacity(len);

        if len < period {
            return Decimal128Array::from(vec![None; len]).with_precision_and_scale(PRECISION, SCALE).unwrap();
        }

        for _ in 0..period - 1 {
            result.push(None);
        }

        // Moving window sum using rust_decimal for 100% accuracy
        let mut window: Vec<Decimal> = (0..period).map(|i| arrow_to_decimal(array.value(i))).collect();
        let mut sum: Decimal = window.iter().sum();
        
        result.push(Some(decimal_to_arrow(sum / Decimal::from(period))));

        for i in period..len {
            let old_val = window[i % period];
            let new_val = arrow_to_decimal(array.value(i));
            sum = sum - old_val + new_val;
            window[i % period] = new_val;
            result.push(Some(decimal_to_arrow(sum / Decimal::from(period))));
        }

        Decimal128Array::from(result).with_precision_and_scale(PRECISION, SCALE).unwrap()
    }

    /// High-precision Vectorized RSI (Wilder's Smoothing)
    pub fn compute_rsi(array: &Decimal128Array, period: usize) -> Decimal128Array {
        let len = array.len();
        let mut result = Vec::with_capacity(len);

        if len <= period {
            return Decimal128Array::from(vec![None; len]).with_precision_and_scale(PRECISION, SCALE).unwrap();
        }

        // 1. Calculate price changes accurately
        let diffs: Vec<Decimal> = (1..len)
            .map(|i| arrow_to_decimal(array.value(i)) - arrow_to_decimal(array.value(i - 1)))
            .collect();

        // 2. Initial averages
        let mut avg_gain: Decimal = diffs[0..period].iter().filter(|&&d| d > Decimal::ZERO).sum::<Decimal>() / Decimal::from(period);
        let mut avg_loss: Decimal = diffs[0..period].iter().filter(|&&d| d < Decimal::ZERO).map(|d| d.abs()).sum::<Decimal>() / Decimal::from(period);

        let calc_rsi = |g: Decimal, l: Decimal| -> Decimal {
            if l == Decimal::ZERO { return Decimal::from(100); }
            Decimal::from(100) - (Decimal::from(100) / (Decimal::ONE + (g / l)))
        };

        for _ in 0..period {
            result.push(None);
        }
        result.push(Some(decimal_to_arrow(calc_rsi(avg_gain, avg_loss))));

        // 3. Wilder's Smoothing
        for i in period..diffs.len() {
            let gain = if diffs[i] > Decimal::ZERO { diffs[i] } else { Decimal::ZERO };
            let loss = if diffs[i] < Decimal::ZERO { diffs[i].abs() } else { Decimal::ZERO };

            let p_minus_1 = Decimal::from(period - 1);
            let p = Decimal::from(period);

            avg_gain = (avg_gain * p_minus_1 + gain) / p;
            avg_loss = (avg_loss * p_minus_1 + loss) / p;

            result.push(Some(decimal_to_arrow(calc_rsi(avg_gain, avg_loss))));
        }

        Decimal128Array::from(result).with_precision_and_scale(PRECISION, SCALE).unwrap()
    }
}

#[cfg(feature = "python")]
pub use python_indicators::enrich_batch;
