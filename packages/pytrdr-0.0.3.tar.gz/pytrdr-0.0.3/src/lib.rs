// [AI_HEADER]: Master Bridge for PyTrader - Interface between Rust Core and Python SDK.
// [PRIMARY_INTERFACE]: _core (PyO3)
// [DEPENDS]: error.rs, traits.rs
// [CONSTRAINTS]: No logic inside lib.rs. Delegate to traits or specific modules.
// [INTERNAL]: Component Registration
pub mod error;
pub mod traits;
pub mod schema;
pub mod providers;
pub mod ffi;
pub mod indicators;
pub mod account;
pub mod matching;
pub mod simulator;
pub mod optimizer;
#[cfg(feature = "engine")]
pub mod engine;

#[cfg(feature = "python")]
use pyo3::prelude::*;

#[cfg(feature = "python")]
const VERSION: &str = "0.0.1";

/// Core version retrieval function
#[cfg(feature = "python")]
#[pyfunction]
fn version() -> PyResult<String> {
    Ok(VERSION.to_string())
}

/// Latency bridge test function (returns microseconds)
#[cfg(feature = "python")]
#[pyfunction]
fn ping() -> PyResult<u128> {
    let start = std::time::Instant::now();
    let elapsed = start.elapsed().as_micros();
    Ok(elapsed)
}

/// Primary PyO3 module export entry point
#[cfg(feature = "python")]
#[pymodule]
fn _core(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<ffi::ArrowBatchExporter>()?;
    
    m.add_function(wrap_pyfunction!(version, m)?)?;
    m.add_function(wrap_pyfunction!(ping, m)?)?;
    m.add_function(wrap_pyfunction!(show_chart, m)?)?;
    m.add_function(wrap_pyfunction!(generate_simulated_batch, m)?)?;
    m.add_function(wrap_pyfunction!(generate_enriched_batch, m)?)?;
    m.add_function(wrap_pyfunction!(run_backtest, m)?)?;
    Ok(())
}

/// Runs a high-fidelity backtest on an Arrow RecordBatch.
/// Accuracy First: Uses the Discrete-Event Simulator.
#[cfg(feature = "python")]
#[pyfunction]
fn run_backtest(
    exporter: PyRef<'_, ffi::ArrowBatchExporter>,
    initial_balance: f64,
    leverage: f64
) -> PyResult<PyObject> {
    use rust_decimal::prelude::{FromPrimitive, ToPrimitive};
    use rust_decimal::Decimal;
    
    let balance = Decimal::from_f64(initial_balance).unwrap();
    let lev = Decimal::from_f64(leverage).unwrap();
    
    let mut runner = simulator::BacktestRunner::new(balance, lev);
    
    // Safety check for batch
    let batch = exporter.batch.clone().ok_or_else(|| {
        pyo3::exceptions::PyRuntimeError::new_err("Exporter has no batch data")
    })?;

    let report = runner.run_simulation(batch)
        .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;
        
    // Return a simple dict for Python
    Python::with_gil(|py| {
        let dict = pyo3::types::PyDict::new(py);
        dict.set_item("total_trades", report.total_trades)?;
        dict.set_item("final_equity", report.final_equity.to_f64().unwrap_or(0.0))?;
        dict.set_item("max_drawdown", report.max_drawdown.to_f64().unwrap_or(0.0))?;
        Ok(dict.into())
    })
}

#[cfg(feature = "python")]
#[pyfunction]
fn generate_simulated_batch(symbols: Vec<String>, count: usize) -> PyResult<ffi::ArrowBatchExporter> {
    let mut feed = providers::SimulatedFeed::new(symbols);
    let ticks = feed.generate_ticks(count);
    let batch = providers::simulated::SimulatedFeed::into_record_batch(&ticks)
        .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;
    
    Ok(ffi::ArrowBatchExporter::new(batch))
}

#[cfg(feature = "python")]
#[pyfunction]
fn generate_enriched_batch(
    symbols: Vec<String>, 
    count: usize, 
    indicator: String, 
    period: usize
) -> PyResult<ffi::ArrowBatchExporter> {
    let mut feed = providers::SimulatedFeed::new(symbols);
    let ticks = feed.generate_ticks(count);
    let mut batch = providers::simulated::SimulatedFeed::into_record_batch(&ticks)
        .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;
    
    // Enrich with indicator (on "ask" just for demo)
    batch = indicators::enrich_batch(batch, "ask", &indicator, period)
        .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

    Ok(ffi::ArrowBatchExporter::new(batch))
}

/// Launches the native Sovereign WGPU chart window.
/// Institutional Solution: Spawns the engine sidecar for maximum macOS stability.
#[cfg(feature = "python")]
#[pyfunction]
pub fn show_chart() -> PyResult<()> {
    use std::process::Command;
    
    // Attempt to spawn the sidecar binary
    Command::new("cargo")
        .arg("run")
        .arg("--bin")
        .arg("pytrdr-engine")
        .spawn()
        .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(format!("Failed to launch Sovereign Engine: {}", e)))?;
        
    Ok(())
}
