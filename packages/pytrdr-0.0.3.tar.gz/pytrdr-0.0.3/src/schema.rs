// [AI_HEADER]: Master Schema Definitions - Accuracy-First Columnar Standard.
// [TYPE]: Module: schema
// [CORE_SCHEMAS]: TICK_SCHEMA, OHLC_SCHEMA
// [SPEC]: Apache Arrow Decimal128 (38, 10)
// [PURPOSE]: Ensuring 100% financial precision across the entire pipeline.

#[cfg(feature = "python")]
use arrow::datatypes::{DataType, Field, Schema, TimeUnit};
#[cfg(feature = "python")]
use std::sync::Arc;

/// Global Precision Standards for PyTrader
pub const PRECISION: u8 = 38;
pub const SCALE: i8 = 10;

/// Schema for real-time tick-by-tick market data.
/// Uses Decimal128 for absolute price accuracy.
#[cfg(feature = "python")]
pub fn get_tick_schema() -> Arc<Schema> {
    Arc::new(Schema::new(vec![
        Field::new("symbol", DataType::Utf8, false),
        Field::new("bid", DataType::Decimal128(PRECISION, SCALE), false),
        Field::new("ask", DataType::Decimal128(PRECISION, SCALE), false),
        Field::new("volume", DataType::Decimal128(PRECISION, SCALE), false),
        Field::new("timestamp", DataType::Timestamp(TimeUnit::Nanosecond, Some("UTC".into())), false),
    ]))
}

/// Schema for historical and real-time candle data (Bars).
#[cfg(feature = "python")]
pub fn get_ohlc_schema() -> Arc<Schema> {
    Arc::new(Schema::new(vec![
        Field::new("symbol", DataType::Utf8, false),
        Field::new("open", DataType::Decimal128(PRECISION, SCALE), false),
        Field::new("high", DataType::Decimal128(PRECISION, SCALE), false),
        Field::new("low", DataType::Decimal128(PRECISION, SCALE), false),
        Field::new("close", DataType::Decimal128(PRECISION, SCALE), false),
        Field::new("volume", DataType::Decimal128(PRECISION, SCALE), false),
        Field::new("timestamp", DataType::Timestamp(TimeUnit::Nanosecond, Some("UTC".into())), false),
    ]))
}
