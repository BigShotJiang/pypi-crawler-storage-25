// [AI_HEADER]: Systemic Contracts - The Architectural 'Steel Beams' of PyTrader.
// [CORE_TRAITS]: MarketProvider, ExecutionGateway
// [CORE_STRUCTS]: Tick, OrderRequest
// [CONSTRAINTS]: Any new broker or adapter MUST implement these traits.
// [PURPOSE]: Decoupling business logic from protocol-specific implementations (e.g., FIX).

use crate::error::PyTraderError;
use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use rust_decimal::Decimal;

/// Standardized Tick Data structure (Normalized)
/// Uses high-precision Decimal to ensure 100% financial accuracy.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Tick {
    pub symbol: String,
    pub bid: Decimal,
    pub ask: Decimal,
    pub volume: Decimal,
    pub timestamp: DateTime<Utc>,
}

/// Interface for Market Data Providers
/// Enforces consistency across different data sources (FIX, REST, etc.)
pub trait MarketProvider {
    fn connect(&mut self) -> Result<(), PyTraderError>;
    fn subscribe(&mut self, symbol: &str) -> Result<(), PyTraderError>;
    fn get_latest_tick(&self, symbol: &str) -> Result<Tick, PyTraderError>;
    fn disconnect(&mut self) -> Result<(), PyTraderError>;
}

/// Supported Market Order Actions
#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum OrderAction {
    Buy,
    Sell,
}

/// Order Execution Request (Order Packet)
/// Precision is maintained for volume, price, and SL/TP levels.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OrderRequest {
    pub symbol: String,
    pub action: OrderAction,
    pub volume: Decimal,
    pub price: Option<Decimal>,
    pub sl: Option<Decimal>,
    pub tp: Option<Decimal>,
}

/// Interface for Order Execution Gateways
/// Modeled after institutional FIX Engine messaging patterns
pub trait ExecutionGateway {
    fn send_order(&self, order: OrderRequest) -> Result<String, PyTraderError>;
    fn cancel_order(&self, order_id: &str) -> Result<(), PyTraderError>;
}
