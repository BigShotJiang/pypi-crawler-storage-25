// [AI_HEADER]: Sovereign Engine Core - Pure Rust + WGPU High-Performance Graphics
// [PRIMARY_INTERFACE]: RenderContext
// [DEPENDS]: wgpu, bytemuck
// [PHILOSOPHY]: Accuracy First, Zero-Copy, Institutional-Grade Rendering.

use std::sync::Arc;
use wgpu::{Adapter, Device, Instance, Queue, Surface};

/// Institutional Palette: Emerald/Ruby System
pub const COLOR_EMERALD: wgpu::Color = wgpu::Color { r: 0.1, g: 0.78, b: 0.47, a: 1.0 }; // #50C878
pub const COLOR_RUBY: wgpu::Color = wgpu::Color { r: 0.88, g: 0.07, b: 0.37, a: 1.0 };    // #E0115F
pub const COLOR_BG_SOLID: wgpu::Color = wgpu::Color { r: 0.05, g: 0.05, b: 0.06, a: 1.0 }; // Institutional Dark

/// Master Rendering Context - The 'Heart' of the Sovereign Engine
pub struct RenderContext {
    pub instance: Instance,
    pub adapter: Adapter,
    pub device: Arc<Device>,
    pub queue: Arc<Queue>,
}

impl RenderContext {
    /// Initializes a new high-performance RenderContext using WGPU
    pub async fn new() -> Result<Self, String> {
        let instance = Instance::new(wgpu::InstanceDescriptor {
            backends: wgpu::Backends::all(),
            ..Default::default()
        });

        let adapter = instance
            .request_adapter(&wgpu::RequestAdapterOptions {
                power_preference: wgpu::PowerPreference::HighPerformance,
                compatible_surface: None, // Will be attached per window
                force_fallback_adapter: false,
            })
            .await
            .ok_or("Failed to find a suitable GPU adapter")?;

        let (device, queue) = adapter
            .request_device(
                &wgpu::DeviceDescriptor {
                    label: Some("Sovereign Main Device"),
                    required_features: wgpu::Features::empty(),
                    required_limits: wgpu::Limits::default(),
                    memory_hints: wgpu::MemoryHints::Performance,
                },
                None,
            )
            .await
            .map_err(|e| format!("Failed to create WGPU device: {}", e))?;

        Ok(Self {
            instance,
            adapter,
            device: Arc::new(device),
            queue: Arc::new(queue),
        })
    }

    /// Creates a surface for a specific window handle
    pub fn create_surface<W>(&self, window: Arc<W>) -> Result<Surface<'static>, String> 
    where W: raw_window_handle::HasWindowHandle + raw_window_handle::HasDisplayHandle + Send + Sync + 'static {
        self.instance.create_surface(window)
            .map_err(|e| format!("Failed to create surface: {}", e))
    }
}

pub mod window;
pub mod pipeline;
