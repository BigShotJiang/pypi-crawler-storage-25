// [AI_HEADER]: Sovereign Window Management - Native Multi-Window Support
// [PRIMARY_INTERFACE]: WindowManager, SovereignWindow
// [DEPENDS]: wgpu, winit, raw-window-handle
// [PHILOSOPHY]: MT5-style detachability. Each window is a first-class Sovereign citizen.

use std::sync::Arc;
use winit::window::Window;
use wgpu::{Surface, SurfaceConfiguration};

/// Represents a single native chart window in the Sovereign Engine
pub struct SovereignWindow {
    pub window: Arc<Window>,
    pub surface: Surface<'static>,
    pub config: SurfaceConfiguration,
}

impl SovereignWindow {
    /// Creates a new SovereignWindow and initializes its WGPU surface
    pub fn new(
        window: Window,
        render_ctx: &crate::engine::RenderContext,
    ) -> Result<Self, String> {
        let window = Arc::new(window);
        let size = window.inner_size();

        // High-Stability: Create surface for the native window handle
        let surface = render_ctx.create_surface(window.clone())?;

        // Configuration: Institutional-Grade Defaults
        let surface_caps = surface.get_capabilities(&render_ctx.adapter);
        let surface_format = surface_caps.formats.iter()
            .copied()
            .find(|f| f.is_srgb())
            .unwrap_or(surface_caps.formats[0]);

        let config = SurfaceConfiguration {
            usage: wgpu::TextureUsages::RENDER_ATTACHMENT,
            format: surface_format,
            width: size.width.max(1),
            height: size.height.max(1),
            present_mode: wgpu::PresentMode::AutoVsync, // 60-144 FPS
            alpha_mode: surface_caps.alpha_modes[0],
            view_formats: vec![],
            desired_maximum_frame_latency: 2,
        };

        surface.configure(&render_ctx.device, &config);

        Ok(Self {
            window,
            surface,
            config,
        })
    }

    /// Handles window resizing events
    pub fn resize(&mut self, device: &wgpu::Device, new_size: winit::dpi::PhysicalSize<u32>) {
        if new_size.width > 0 && new_size.height > 0 {
            self.config.width = new_size.width;
            self.config.height = new_size.height;
            self.surface.configure(device, &self.config);
        }
    }
}
