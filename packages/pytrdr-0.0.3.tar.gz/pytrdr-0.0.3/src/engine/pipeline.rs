// [AI_HEADER]: Sovereign Render Pipeline - WGPU Pipeline Orchestration
// [PRIMARY_INTERFACE]: CandlePipeline
// [DEPENDS]: wgpu, bytemuck
// [PHILOSOPHY]: Zero-Debt GPU-Native Execution.

use wgpu::*;
use std::borrow::Cow;

/// Representation of a single Candle Instance in GPU memory
#[repr(C)]
#[derive(Copy, Clone, Debug, bytemuck::Pod, bytemuck::Zeroable)]
pub struct CandleInstance {
    pub time_x: f32,
    pub open: f32,
    pub high: f32,
    pub low: f32,
    pub close: f32,
}

impl CandleInstance {
    pub fn desc() -> VertexBufferLayout<'static> {
        VertexBufferLayout {
            array_stride: std::mem::size_of::<CandleInstance>() as BufferAddress,
            step_mode: VertexStepMode::Instance,
            attributes: &[
                VertexAttribute { offset: 0, shader_location: 1, format: VertexFormat::Float32 },
                VertexAttribute { offset: 4, shader_location: 2, format: VertexFormat::Float32 },
                VertexAttribute { offset: 8, shader_location: 3, format: VertexFormat::Float32 },
                VertexAttribute { offset: 12, shader_location: 4, format: VertexFormat::Float32 },
                VertexAttribute { offset: 16, shader_location: 5, format: VertexFormat::Float32 },
            ],
        }
    }
}

pub struct CandlePipeline {
    pub pipeline: RenderPipeline,
}

impl CandlePipeline {
    pub fn new(device: &Device, config: &SurfaceConfiguration) -> Self {
        let shader = device.create_shader_module(ShaderModuleDescriptor {
            label: Some("Sovereign Candle Shader"),
            source: ShaderSource::Wgsl(Cow::Borrowed(include_str!("shaders/candle.wgsl"))),
        });

        let pipeline_layout = device.create_pipeline_layout(&PipelineLayoutDescriptor {
            label: Some("Sovereign Pipeline Layout"),
            bind_group_layouts: &[], // Add globals layout here in Phase 26
            push_constant_ranges: &[],
        });

        let pipeline = device.create_render_pipeline(&RenderPipelineDescriptor {
            label: Some("Sovereign Render Pipeline"),
            layout: Some(&pipeline_layout),
            vertex: VertexState {
                module: &shader,
                entry_point: "vs_main",
                compilation_options: Default::default(),
                buffers: &[
                    // Vertex Buffer (Simple Quad for first light test)
                    VertexBufferLayout {
                        array_stride: 8,
                        step_mode: VertexStepMode::Vertex,
                        attributes: &[VertexAttribute { offset: 0, shader_location: 0, format: VertexFormat::Float32x2 }],
                    },
                    CandleInstance::desc(),
                ],
            },
            fragment: Some(FragmentState {
                module: &shader,
                entry_point: "fs_main",
                compilation_options: Default::default(),
                targets: &[Some(ColorTargetState {
                    format: config.format,
                    blend: Some(BlendState::REPLACE),
                    write_mask: ColorWrites::ALL,
                })],
            }),
            primitive: PrimitiveState {
                topology: PrimitiveTopology::TriangleList,
                ..Default::default()
            },
            depth_stencil: None,
            multisample: MultisampleState::default(),
            multiview: None,
            cache: None,
        });

        Self { pipeline }
    }
}
