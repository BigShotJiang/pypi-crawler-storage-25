// [AI_HEADER]: Sovereign Candle Shader - High-Performance Financial Rendering
// [VERSION]: 1.0 (Emerald/Ruby Edition)
// [INSTANCING]: Yes

struct VertexInput {
    @location(0) position: vec2<f32>,
};

struct InstanceInput {
    @location(1) time_x: f32,
    @location(2) open: f32,
    @location(3) high: f32,
    @location(4) low: f32,
    @location(5) close: f32,
};

struct VertexOutput {
    @builtin(position) clip_position: vec4<f32>,
    @location(0) color: vec4<f32>,
};

struct Globals {
    view_proj: mat4x4<f32>,
    viewport_size: vec2<f32>,
};

@group(0) @binding(0)
var<uniform> globals: Globals;

@vertex
fn vs_main(
    model: VertexInput,
    instance: InstanceInput,
) -> VertexOutput {
    var out: VertexOutput;

    // Institutional Colors
    let color_emerald = vec4<f32>(0.1, 0.78, 0.47, 1.0); // Bullish
    let color_ruby = vec4<f32>(0.88, 0.07, 0.37, 1.0);    // Bearish

    let is_bullish = instance.close >= instance.open;
    if (is_bullish) {
        out.color = color_emerald;
    } else {
        out.color = color_ruby;
    }

    // Candle Geometry Logic (Simplified for First Light)
    // We treat the model.position as local coordinates within the candle [-0.5, 0.5]
    let candle_width = 0.8; 
    let world_x = instance.time_x + (model.position.x * candle_width);
    
    // Calculate Y based on open/close for body, or high/low for wick
    var world_y = 0.0;
    if (model.position.y > 0.5) {
        world_y = instance.high;
    } else if (model.position.y < -0.5) {
        world_y = instance.low;
    } else {
        // Linear interpolation between open/close
        world_y = mix(instance.open, instance.close, model.position.y + 0.5);
    }

    out.clip_position = globals.view_proj * vec4<f32>(world_x, world_y, 0.0, 1.0);
    return out;
}

@fragment
fn fs_main(in: VertexOutput) -> @location(0) vec4<f32> {
    return in.color;
}
