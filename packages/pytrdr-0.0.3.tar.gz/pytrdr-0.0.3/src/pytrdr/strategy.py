# [AI_HEADER]: Strategy SDK - User-Facing Expert Advisor Interface.
# [TYPE]: SDK: strategy
# [BASE_CLASS]: BaseStrategy
# [PURPOSE]: Providing a Pythonic environment for high-performance trading logic.

import pandas as pd
from abc import ABC, abstractmethod

class BaseStrategy(ABC):
    """
    Base class for all PyTrader Expert Advisors (EAs).
    Users should inherit from this and override on_tick.
    """
    
    def __init__(self, name: str = "PyStrategy"):
        self.name = name
        self.account_id = None
        self.positions = {}

    @abstractmethod
    def on_tick(self, data: pd.DataFrame):
        """
        Called whenever new market data is available.
        'data' is a Pandas DataFrame enriched with technical indicators from Rust.
        """
        pass

    def buy(self, symbol: str, volume: float):
        """Placeholder for trade execution."""
        print(f"[TRADE] BUY {symbol} | Volume: {volume}")

    def sell(self, symbol: str, volume: float):
        """Placeholder for trade execution."""
        print(f"[TRADE] SELL {symbol} | Volume: {volume}")

class StrategyRunner:
    """
    Orchestrates the high-speed event loop between Rust data feed and Python strategy.
    """
    def __init__(self, strategy: BaseStrategy):
        self.strategy = strategy

    def run_simulated(self, symbols: list[str], count: int = 1000, indicator: str = "RSI", period: int = 14):
        """
        Runs the strategy on a simulated high-frequency batch.
        """
        from . import _core
        import pyarrow as pa
        
        print(f"🚀 Starting Strategy: {self.strategy.name}")
        
        # 1. Fetch Enriched Data from Rust (Zero-Copy)
        exporter = _core.generate_enriched_batch(symbols, count, indicator, period)
        
        # 2. Convert to Pandas
        df = pa.table(exporter).to_pandas()
        
        # 3. Trigger Event
        self.strategy.on_tick(df)
        
        print(f"🏁 Strategy Execution Finished.")
