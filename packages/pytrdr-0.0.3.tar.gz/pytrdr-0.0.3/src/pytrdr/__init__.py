# PyTrader: The Lean & Powerful Python-Native Trading SDK (WGPU Core)
# ------------------------------------------------------------------

# High-performance core components
try:
    from . import _core
except ImportError as e:
    raise ImportError(f"Fatality Error: PyTrader Native Core (_core) could not be loaded. Ensure the Rust extension is compiled properly. {e}")

import pyarrow as pa
import pandas as pd

# Core version retrieval
__version__ = _core.version()

# High-level API Exports
version = _core.version
ping = _core.ping
show_chart = _core.show_chart

# Strategy SDK Exports
from .strategy import BaseStrategy, StrategyRunner

class Data:
    """High-performance market data ingestion engine."""
    
    @staticmethod
    def get_simulated_ticks(symbols: list[str], count: int = 1000) -> pd.DataFrame:
        """
        Generates a simulated batch of ticks using the Rust core.
        Data is passed via the zero-copy Arrow PyCapsule interface.
        """
        exporter = _core.generate_simulated_batch(symbols, count)
        table = pa.table(exporter)
        return table.to_pandas()

# Singleton instance
data = Data()

__all__ = ["version", "ping", "show_chart", "data", "BaseStrategy", "StrategyRunner"]
