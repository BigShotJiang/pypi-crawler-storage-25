# pytrdr: High-Density Agent Protocol (HDAP)
# [STATUS]: ACTIVE-SOVEREIGN
# [VERSION]: 1.1 (AI-OPTIMIZED)

```yaml
context:
  project_name: "pytrdr"
  architect: "The Phantom Architect (welltilln)"
  engineering_lead: "Antigravity (AI-Agentic)"
  philosophy: "Accuracy-First, Zero-Debt, Interface-First, No Ouroboros"
  primary_stack: ["Rust (Core)", "Python (SDK)", "WASM (UI)"]

mandatory_discovery_paths:
  - "/Users/welltilln/Projects/pytrader/README.md"
  - "/Users/welltilln/Projects/pytrader/docs/llms.txt"
  - "/Users/welltilln/Projects/pytrader/docs/core_architectural_principles.md"
  - "/Users/welltilln/Projects/pytrader/docs/ai_agent_coding_standards.md"

agent_constraints:
  - "NEVER: Address symptoms without root cause (Ouroboros Protection)"
  - "ALWAYS: Prioritize Accuracy over Speed (Financial Precision > Latency)"
  - "ALWAYS: Use Fixed-Point/Decimal math (rust_decimal) for financial logic"
  - "ALWAYS: Benchmark against MT5/MQL5 to ensure zero feature debt"
  - "ALWAYS: Include Backtest Optimization (Genetic Algorithms) in core design"
  - "ALWAYS: Reference core traits in [rust_src/traits.rs] for logic"
  - "ALWAYS: Use [rust_src/error.rs] for all failure paths"
  - "PREFER: Zero-copy memory sharing (Apache Arrow) for tick data"
  - "COMMUNICATION: Thai (Live Chat), Concise English (Docs/Code/Logic)"

semantic_naming_rules:
  - "High Information Density: Avoid generic names (e.g., 'data_handler')"
  - "Explicit Intent: Name functions based on result, not action"

project_state:
  current_phase: 26.4 (Sovereign Documentation Refactoring)
  last_test_latency: "0.15 microseconds (Bridge Ping)"
  git_repo: "https://github.com/welltilln/pytrdr"
  milestones:
    - "Phase 25.1: Sovereign Decoupling Complete"
    - "Phase 26.3: Multi-Platform CI/CD Established"
```

---

## พันธสัญญาของเอเจนต์ (The Agent Covenant)

เอกสารฉบับนี้คือ "จริยธรรมของเครื่องจัก" ในโครงการ pytrdr เพื่อให้มั่นใจว่าทุกการเขียนโค้ดโดย AI จะรักษาความสมบูรณ์ของโครงสร้างสูงสุด

### 1. ความรับผิดชอบของ Agent (Responsibility)
เอเจนต์ทุกตัวที่เข้ามาในโปรเจกต์นี้ ต้องทำตัวเป็น **"Senior Multi-Agent Lead"** คือต้องมีการวางแผนก่อนลงมือ (Research -> Plan -> Execute -> Verify) เสมอ

### 2. การสื่อสาร (Communication)
*   **สำหรับแช้ม:** พูดภาษาไทย สไตล์เพื่อนสนิท (Direct & Friendly)
*   **สำหรับระบบ:** บันทึกในรูปแบบ HDAP เพื่อความประหยัด Token และความแม่นยำสูงสุด

---
**Status:** มีผลบังคับใช้ทันที
**ลงชื่อ:** The Phantom Architect Team
