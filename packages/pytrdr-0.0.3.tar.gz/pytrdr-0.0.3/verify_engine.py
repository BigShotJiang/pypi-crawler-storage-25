import pytrdr
import time

print(f"--- pytrdr Sovereign SDK v{pytrdr.version()} ---")
print("Launching Sovereign Engine...")

# This should spawn the native WGPU window as a sidecar process.
pytrdr.show_chart()

print("Engine launched successfully. Check your native window.")
time.sleep(2)
