# pytrdr: Sovereign Architecture Guide

**Internal Technical Strategy - ภูมิใจที่ได้สร้างมาตราสากลเพื่อแช้มนะครับ!**

## 🏛️ The Decoupling Principle
To achieve institutional-grade stability and global distribution (multi-platform), `pytrdr` follows a strict **Sovereign Decoupling** model.

### 1. The Core SDK (`pytrdr` / Python)
- **Nature:** Logic-only, high-performance Python extension.
- **Dependencies:** `pyo3`, `arrow`, `rust_decimal`.
- **Target:** Ubuntu (ManyLinux), macOS, Windows.
- **Constraint:** Zero graphics linkage. Must compile and run on headless servers/CI without Vulkan/Wayland headers.

### 2. The Native Engine (`pytrdr-engine` / Binary)
- **Nature:** Standalone high-performance renderer.
- **Dependencies:** `wgpu`, `winit`, `bytemuck`.
- **Target:** Desktop environments (macOS, Windows, Linux Desktop).
- **Responsibility:** Visualizing market data streamed from the Core SDK.

---

## 📡 Shmem/IPC Strategy (Phase 27)
The Core SDK and the Native Engine communicate via a high-speed bridge:
1. **Shared Memory:** For ticks and high-frequency data.
2. **IPC / Sockets:** For control commands (e.g., `show_chart`).

---

## 🛠️ Developer Workflow (Zero-Debt)
- **Build Core Logic:** `cargo check --no-default-features --features python`
- **Build Engine:** `cargo build --bin pytrdr-engine --no-default-features --features engine`

**[PROPRIETARY / INTERNAL]**
