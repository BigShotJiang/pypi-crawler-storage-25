# PyTrader: System Architecture (HDAP)
# [TYPE]: ARCHITECTURAL-SPEC
# [AI_HEADER]: Master blueprint for component interaction. 
# [GOAL]: Hybrid High-Performance Modular Design.

## 1. Core Component Strategy
- **Sovereign Logic SDK (Core):** Rust-native logic-only PyO3 extension. High-performance matching and ingestion without graphics-driver debt.
- **Native Rendering Engine (Eye):** Standalone WGPU-powered binary for high-density desktop visualization.
- **Hybrid Bridge (Pulse):** Shared Memory (Shmem) and IPC for zero-latency synchronization between SDK and Engine.

## 2. Distributed Decoupled Modules
### A. Data Ingestion Engine (Senses) - [Rust]
- [INPUT]: FIX Protocol / REST / WebSocket from Brokers.
- [OUTPUT]: Normalized Price Stream (Internal PyTrader Format).
- [PERSISTENCE]: TimescaleDB (Time-series ticks/bars).

### B. Risk Control Engine (Guardian) - [Rust]
- [PURPOSE]: Pre-trade validation (Margin, Size, Exposure).
- [CONSTRAINTS]: Nano-second latency threshold.
- [INVARIANT]: Must pass check before Order Matching.

### C. Order Matching & Routing (Heart) - [Rust]
- [PURPOSE]: Multi-broker connectivity & execution routing.
- [LOGGING]: Detailed audit trail of all execution events.

### D. PyTrader Interface SDK (Brain) - [Python]
- [INTERFACE]: Pip-installable high-level library.
- [CAPABILITIES]: `order.send()`, `data.stream()`, `ai.agent()`.

## 3. Data Flow Pattern
```mermaid
graph TD
    LP[Liquidity Provider / Broker] -- FIX Protocol --> DI[Data Ingestion Engine - Rust]
    DI -- Price Stream --> TE[Trader SDK Engine - Python]
    TE -- Strategy Output --> RE[Risk Control Engine - Rust]
    RE -- Validated Order --> OM[Order Matching/Routing - Rust]
    OM -- Execution --> LP
    
    DI -- Save --> DB[(TimescaleDB - History)]
    TE -- Analytics --> AI[Agentic AI Engine]
```

## 4. Security & Compliance
- **ZKP Module:** Copied-trade IP protection (Signal without logic).
- **TLS 1.3:** Mandatory encryption for all node-to-node traffic.
- **Vault:** HSM-backed storage for API keys and secrets.

---
**Status:** ACTIVE-SOVEREIGN
**Protocol:** HDAP v1.1
