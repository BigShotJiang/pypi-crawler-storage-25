# PyTrader: Core Architectural Principles (HDAP)
# [TYPE]: DESIGN-INVARAINT
# [AI_HEADER]: Master philosophy for all development. 
# [GOAL]: Zero-Debt Foundation (No Ouroboros).

## 1. Interface-First Design
- **Decoupling:** Business logic MUST be abstracted from Network/Broker protocols.
- **Traits:** Use Rust Traits to define standard interfaces for [MarketData] and [Execution].
- **FIX-Native:** Mimic FIX Protocol mechanical structures for high-level data consistency.

## 2. Performance: Zero-Copy Policy
- **Memory Management:** Tick data must NOT be copied between loops.
- **Shared Memory:** Use Apache Arrow (Arrow-rs) for Rust -> Python data streaming.
- **Cache Locality:** Prioritize L1/L2 cache alignment for nano-second latency.

## 3. Stability & Integrity
- **Error Propagation:** All Rust failures MUST be mapped to `PyTraderError` [error.rs]. 
- **Immutability:** Tick data is immutable once ingested (No Race Conditions).
- **Atomic Modules:** Maintain single-responsibility for LLM precision during maintenance.

## 4. Engineering Standard
- **Reasoning First:** Every architectural decision must be documented (The Why).
- **Self-Documenting:** Use semantic naming for high-density information discovery.
- **Phantom Authority:** Strategy decisions belong to The Phantom Architect.

---
**Status:** ACTIVE-SOVEREIGN
**Architect:** welltilln
**Protocol:** HDAP v1.1
