# PyTrader: MT5 Reverse Engineering (HDAP)
# [TYPE]: TECHNICAL-INTEL
# [AI_HEADER]: Architectural analysis of MT5 server structure. 
# [GOAL]: Benchmark against industry gold standard.

## 1. Distributed Server Architecture (MT5 Standard)
- **Trade Server (Core):** 
  - [PURPOSE]: Order execution, Margin check, P/L calculation.
  - [CONSTRAINT]: Real-time requirement.
- **History Server (Vault):**
  - [PURPOSE]: Massive Chart/Tick historical data storage.
  - [IMPROVEMENT]: Decoupled to avoid Trade Server load.
- **Access Server (Front-Line):**
  - [PURPOSE]: Global Proxy/DDoS protection.
  - [BENEFIT]: Latency optimization via geographic distribution.
- **Backup Server (Failover):**
  - [PURPOSE]: Real-time replication of Trade Server state.
- **Report/SQL Server:**
  - [PURPOSE]: External reporting and compliance.

## 2. Institutional Terminals (Internal Flows)
- **Administrator Terminal:** Group config, Symbol settings, Security.
- **Manager Terminal:** Client on-boarding, Cash/Crypto handling, Risk monitoring.

## 3. External Connectivity (Gateways)
- **FIX Protocol Engine:** Interface with global Banks/LPs.
- **Gateway Modules:** Bridge price/order data between MT5 and external markets.

## 4. Gap Analysis (PyTrader Disruption Vectors)
1. **C-Centric Limitations:** MT5 is legacy C++, difficult to extend with Python.
2. **Closed Ecosystem:** Limited developer freedom for custom plugins/AI.
3. **UI Fragmentation:** Disjointed experience between Broker and Trader.
4. **Agentic Missing:** No native reasoning/LLM-aided execution in MT5.

---
**Status:** REFERENCE-ONLY
**Protocol:** HDAP v1.1
