# PyTrader: Broker Operational Guide (HDAP)
# [TYPE]: OPERATIONAL-MANUAL
# [AI_HEADER]: Operational procedures for Broker partners. 
# [GOAL]: Ensure platform stability and risk mitigation.

## 1. Foundational Infrastructure (Deployment)
- **Trade Unit:** Order matching/execution (Ultra-Low Latency).
- **Data Unit:** Tick/History persistence (High-Capacity Storage).
- **Front-end Unit:** Client terminal connectivity (Global Access).

## 2. Symbol & Instrument Config
- **Digits:** Pricing precision (e.g., 5 for Majors).
- **Swap Rates:** Overnight financing logic.
- **Trading Hours:** Intraday session boundaries.
- **Contract Size:** Lot-based volume normalization.

## 3. Group & Risk Management
- **Group Rules (STP/ECN):** Segmented execution routing (Internal vs External).
- **Stop Out Protocol:** Automated liquidation trigger (e.g., 30% margin).
- **Max Order Size:** Fat-finger protection limit.
- **Exposure Cap:** Symbol-specific risk ceiling per group.

## 4. Staff Operational Workflows
- **Dealer (Manager Interface):**
  - Monitor open exposure (Risk).
  - Handle off-quote adjustments (Price).
  - Generate volume/tax reports (Admin).
- **Support (Manager Interface):**
  - Credential management & KYC.
  - Connection/Log failure analysis.
  - Balance & Credit adjustments.

## 5. Security & Licensing
- **License Validation:** Mandatory heartbeat to PyTrader License Server (24h).
- **Firewall:** Mandatory Broker-side ingress/egress filtering.
- **Backup:** Mandatory daily snapshot of SQL History & Transaction logs.

---
**Status:** CONFIDENTIAL-PARTNER
**Protocol:** HDAP v1.1
