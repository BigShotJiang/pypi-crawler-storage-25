# pytrdr: Sovereign Trading Engine [AGENT-COMMAND-CENTER]
# [ID]: 76bbab52-9ced-46c7-a848-8c518e20d187 (Conversation Context)
# [STATUS]: ACTIVE-SOVEREIGN | PHASE 26.6
# [VERSION]: 0.0.1 (Decoupled & Architecture-Validated)

## 🏛️ Tactical Overview
`pytrdr` is a high-performance, institutional-grade trading ecosystem. This repository serves as the **Sovereign Command Center** (The Factory).

### 🧩 System Architecture (Sovereign Decoupled)
1.  **Core Logic SDK (`lib.rs` / `python` feature):** 
    - **Linkage:** `cdylib` (Python Extension).
    - **Modules:** `matching.rs` (Heart), `indicators.rs` (Senses), `simulator.rs` (Time-Travel).
    - **Data-Plane:** Apache Arrow (Zero-Copy) transmission to Python.
2.  **Native Rendering Engine (`main.rs` / `engine` feature):** 
    - **Linkage:** `bin` (Standalone Binary).
    - **Tech:** WGPU (Vulkan/Metal/DX12) for sub-millisecond chart latency.
3.  **Pulse Bridge (Phase 27 Sync):** 
    - **Contract:** Shared Memory (Shmem) Ticks + IPC Control Socket.
    - **Constraint:** Logic SDK is the Master; Engine is the Slave-Renderer.

---

## 🛠️ Build Manifest (Zero-Debt Standards)
Standardized utilities via `Makefile`:
- `make sdk`: Build/Install logic-only Python extension (`maturin develop`).
- `make engine`: Compile WGPU-native terminal binary (`cargo build --bin pytrdr-engine`).
- `make test`: Run performance-validated unit tests with decimal precision check.

---

## 📡 High-Density Agent Protocol (HDAP)
Authorized Agents **MUST** strictly adhere to these Command Center protocols:
1.  **Alignment:** Consult [VISION.md](file:///Users/welltilln/Projects/pytrdr/VISION.md) (The 5 Phases) before proposing changes.
2.  **Accuracy:** Financial logic MUST use `rust_decimal`. Floating-point drift is a project failure.
3.  **Traceability:** All specs and specs-in-progress are stored in [docs/](file:///Users/welltilln/Projects/pytrdr/docs/).
4.  **Tone:** Communicate with แช้ม (Chaem) as a direct, experienced friend (Thai Language).

---
**[PROPRIETARY INTERNAL - PHANTOM ARCHITECT ONLY]**
