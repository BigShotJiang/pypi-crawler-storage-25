# [AI_TEST]: Backtest Fidelity Verification - The Time Machine Engine.
# [GOAL]: Confirm that the Rust DES engine processes ticks correctly and tracks equity precisely.

import pytrdr
from pytrdr import _core
import decimal

def test_backtest_fidelity():
    print("--- PyTrader: Phase 5 Verification (The Time Machine) ---")
    
    # 1. Generate a simulated batch of 1000 ticks
    symbols = ["EURUSD"]
    count = 1000
    exporter = _core.generate_simulated_batch(symbols, count)
    
    # 2. Run the High-Fidelity Backtest in Rust
    # Initial Balance: 10,000, Leverage: 30
    initial_balance = 10000.0
    leverage = 30.0
    
    print(f"🚀 Running Simulation: {count} ticks...")
    report = _core.run_backtest(exporter, initial_balance, leverage)
    
    # 3. Audit Results
    print("\n--- Simulation Report ---")
    print(f"Total Trades: {report['total_trades']}")
    print(f"Final Equity: {report['final_equity']:.4f}")
    print(f"Max Drawdown: {report['max_drawdown']:.4f}")
    
    # Verify precision (No weird f64 artifacts)
    final_equity = report['final_equity']
    if final_equity == initial_balance and report['total_trades'] == 0:
        print("✅ Account Integrity Verified (No trades = Original balance).")
    elif report['total_trades'] > 0:
        print("✅ Trade Logic Verified.")
    else:
        print("⚠️ Anomalous result detected.")

if __name__ == "__main__":
    test_backtest_fidelity()
