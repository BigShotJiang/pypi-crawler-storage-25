import pytrdr
import time

def test_bridge():
    print("--- PyTrader (pytrdr) Bridge Test ---")
    
    # 1. ทดสอบอ่านเวอร์ชันจาก Rust
    v = pytrdr.version()
    print(f"Core Version: {v}")
    
    # 2. ทดสอบความเร็ว (Latency) ของการเรียกข้ามภาษา
    # เราจะรัน 10,000 ครั้งเพื่อหาค่าเฉลี่ย
    iterations = 10000
    start_time = time.perf_counter()
    
    for _ in range(iterations):
        pytrdr.ping()
        
    end_time = time.perf_counter()
    total_time_ms = (end_time - start_time) * 1000
    avg_latency_us = (total_time_ms * 1000) / iterations
    
    print(f"Total time for {iterations} pings: {total_time_ms:.2f} ms")
    print(f"Average cross-language latency: {avg_latency_us:.4f} microseconds")
    
    if "0.0.1" in v:
        print("\n✅ RESULT: Bridge is working perfectly!")
    else:
        print("\n❌ RESULT: Bridge is not working as expected.")

if __name__ == "__main__":
    test_bridge()
