import pytrdr
import pandas as pd
import time

def test_market_data_ingestion():
    print("--- PyTrader: Phase 3 Verification (The Senses) ---")
    
    symbols = ["EURUSD", "GBPUSD", "USDJPY", "XAUUSD"]
    count = 100_000 # 100,000 ticks
    
    print(f"Generating {count} ticks for {len(symbols)} symbols in Rust...")
    
    start_time = time.perf_counter()
    
    # 1. Ingest via Arrow Zero-Copy
    df = pytrdr.data.get_simulated_ticks(symbols, count)
    
    end_time = time.perf_counter()
    total_latency = (end_time - start_time) * 1000
    
    print(f"✅ Ingestion Successful!")
    print(f"📊 Rows received: {len(df):,}")
    print(f"⏱️ Total Latency (Rust -> Arrow -> Python -> Pandas): {total_latency:.2f} ms")
    
    # Verify data integrity
    print("\nSample Data (First 5 rows):")
    print(df.head())
    
    # Check for empty values
    null_counts = df.isnull().sum().sum()
    if null_counts == 0:
        print("\n✅ Data Integrity Check passed: No null values found.")
    else:
        print(f"\n❌ Data Integrity Check failed: {null_counts} null values found.")

if __name__ == "__main__":
    test_market_data_ingestion()
