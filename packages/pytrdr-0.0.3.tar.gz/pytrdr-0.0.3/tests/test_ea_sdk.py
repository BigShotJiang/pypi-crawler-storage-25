# [AI_TEST]: Phase 4 EA SDK Verification - RSI Strategy.
# [GOAL]: Demonstrate Python-native EA experience with Rust-powered indicators.

import pytrdr
from pytrdr import BaseStrategy, StrategyRunner
import pandas as pd

class RSIStrategy(BaseStrategy):
    """
    Example EA that trades based on RSI levels.
    Demonstrates accessing Rust-enriched indicators in a Pythonic way.
    """
    def __init__(self):
        super().__init__("RSI_Scalper")
        self.buy_count = 0
        self.sell_count = 0

    def on_tick(self, data: pd.DataFrame):
        # 1. Access the RSI column (Calculated in Rust Core!)
        # Column name format: {Indicator}_{Period}
        rsi_col = "RSI_14"
        
        if rsi_col not in data.columns:
            print(f"❌ Error: Indicator {rsi_col} not found in market data.")
            return

        latest_rsi = data[rsi_col].iloc[-1]
        latest_bid = data['bid'].iloc[-1]
        
        print(f"📊 Strategy Check | Bid: {latest_bid:.2f} | RSI: {latest_rsi:.2f}")

        # 2. Strategic Logic (Simple Overbought/Oversold)
        if latest_rsi < 30:
            self.buy("EURUSD", 0.1)
            self.buy_count += 1
        elif latest_rsi > 70:
            self.sell("EURUSD", 0.1)
            self.sell_count += 1

def run_test_ea():
    print("--- PyTrader: Phase 4 Verification (The Brain) ---")
    
    # Initialize EA
    strategy = RSIStrategy()
    
    # Initialize Runner
    runner = StrategyRunner(strategy)
    
    # Run simulation: 1,000 ticks, with RSI(14) enrichment
    # Indicators are calculated in Rust Core during data ingestion
    runner.run_simulated(
        symbols=["EURUSD"], 
        count=100, 
        indicator="RSI", 
        period=14
    )
    
    print(f"\n--- Strategy Summary ---")
    print(f"Name: {strategy.name}")
    print(f"Total Transactions: {strategy.buy_count + strategy.sell_count}")
    print(f"✅ EA Loop Successful.")

if __name__ == "__main__":
    run_test_ea()
