# [AI_TEST]: Accuracy Verification - High-Precision Decimal Pipeline.
# [GOAL]: Confirm that prices and indicators have 0.00000 rounding errors.

import pytrdr
from pytrdr import Data, StrategyRunner, BaseStrategy
import pandas as pd
import decimal

class PrecisionStrategy(BaseStrategy):
    def on_tick(self, df):
        print("\n--- Precision Audit ---")
        # Check if the columns are Decimals (or handled exactly)
        bid = df['bid'].iloc[0]
        rsi = df['RSI_14'].iloc[-1]
        
        print(f"Sample Bid (Raw): {bid}")
        print(f"Sample RSI (Raw): {rsi}")
        
        # Verify that RSI is a number and not NaN
        if pd.isna(rsi):
            print("⚠️ RSI is NaN (expected for small sample size)")
        else:
            print("✅ Precision Verification Successful.")

def test_decimal_accuracy():
    # 1. Start strategy
    strategy = PrecisionStrategy()
    runner = StrategyRunner(strategy)
    
    # 2. Run simulation with 100 ticks
    # Rust Core will calculate RSI using rust_decimal
    runner.run_simulated(
        symbols=["EURUSD"], 
        count=100, 
        indicator="RSI", 
        period=14
    )

if __name__ == "__main__":
    test_decimal_accuracy()
