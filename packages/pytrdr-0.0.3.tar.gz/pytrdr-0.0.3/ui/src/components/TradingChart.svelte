<script>
  import { onMount, onDestroy } from 'svelte';
  import { createChart } from 'lightweight-charts';
  import { marketData } from '../lib/stores/market';
  import { settings } from '../lib/stores/settings';
  import QuickTrade from './QuickTrade.svelte';

  let chartContainer;
  let chart;
  let activeSeries;
  let unsubscribeMarket;
  let unsubscribeSettings;

  // Chart Generation Engine (Multi-Type Support)
  const createSeries = (type, colors) => {
    if (activeSeries) chart.removeSeries(activeSeries);
    const commonOptions = { priceFormat: { type: 'price', precision: 5, minMove: 0.00001 } };

    if (type === 'candle') {
      activeSeries = chart.addCandlestickSeries({
        ...commonOptions,
        upColor: colors.colorUp, downColor: colors.colorDown,
        borderVisible: false, wickUpColor: colors.colorUp, wickDownColor: colors.colorDown,
      });
    } else if (type === 'bar') {
      activeSeries = chart.addBarSeries({ ...commonOptions, upColor: colors.colorUp, downColor: colors.colorDown });
    } else {
      activeSeries = chart.addLineSeries({ ...commonOptions, color: '#00D1FF', lineWidth: 2 });
    }
  };

  onMount(() => {
    chart = createChart(chartContainer, {
      layout: { background: { color: 'transparent' }, textColor: '#808080' },
      grid: { vertLines: { color: 'rgba(128, 128, 128, 0.05)' }, horzLines: { color: 'rgba(128, 128, 128, 0.05)' } },
      rightPriceScale: { borderVisible: false },
      timeScale: { borderVisible: false, timeVisible: true, secondsVisible: true },
      handleScroll: true, handleScale: true,
    });

    unsubscribeSettings = settings.subscribe(s => {
      createSeries(s.chartType, { colorUp: s.colorUp, colorDown: s.colorDown });
      chart.applyOptions({ layout: { textColor: s.theme === 'dark' ? '#cccccc' : '#1d1d1f' } });
    });

    unsubscribeMarket = marketData.subscribe(tick => {
      if (!activeSeries) return;
      const ts = Math.floor(tick.timestamp / 1000);
      try {
        if ($settings.chartType === 'candle' || $settings.chartType === 'bar') {
           activeSeries.update({ time: ts, open: Number(tick.last), high: Number(tick.last), low: Number(tick.last), close: Number(tick.last) });
        } else {
           activeSeries.update({ time: ts, value: Number(tick.last) });
        }
      } catch (e) {}
    });

    const resizeObserver = new ResizeObserver(entries => {
      if (entries.length === 0 || !chart) return;
      const { width, height } = entries[0].contentRect;
      chart.applyOptions({ width, height });
    });
    resizeObserver.observe(chartContainer);

    return () => {
      if (unsubscribeMarket) unsubscribeMarket();
      if (unsubscribeSettings) unsubscribeSettings();
      resizeObserver.disconnect();
      chart.remove();
    };
  });
</script>

<div class="relative w-full h-full">
  <!-- One-Click Trading Overlay -->
  <QuickTrade />
  
  <!-- Chart Canvas -->
  <div bind:this={chartContainer} class="w-full h-full min-h-[300px]"></div>
</div>

<style>
  div { width: 100%; height: 100%; }
</style>
