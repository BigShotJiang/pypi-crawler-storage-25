<script>
  import { systemLogs } from '../lib/stores/market';
  import { Terminal, ShieldCheck, Activity } from 'lucide-svelte';
</script>

<footer class="w-full h-full bg-[var(--bg-secondary)] border-t border-[var(--border-primary)] flex flex-col shadow-inner">
  <!-- Terminal Header -->
  <div class="h-10 px-6 flex items-center justify-between border-b border-[var(--border-primary)] bg-[var(--bg-primary)]">
    <div class="flex items-center gap-2">
      <Terminal size={14} class="text-sovereign-blue" />
      <span class="text-[10px] uppercase font-bold text-[var(--text-secondary)] tracking-widest">Sovereign Terminal Console</span>
    </div>
    <div class="flex items-center gap-4 text-[9px] font-bold">
      <div class="flex items-center gap-1 text-green-500">
        <Activity size={12} />
        MARKET FEED: LIVE
      </div>
      <div class="flex items-center gap-1 text-sovereign-blue">
        <ShieldCheck size={12} />
        BRIDGE: ENCRYPTED
      </div>
    </div>
  </div>

  <!-- Terminal Content -->
  <div class="flex-1 p-4 font-mono text-[11px] overflow-y-auto space-y-1">
    {#each $systemLogs as log}
      <div class="flex gap-3 {log.includes('Pulse') ? 'text-sovereign-blue' : 'text-[var(--text-secondary)]'}">
        <span class="opacity-30 shrink-0">[{new Date().toLocaleTimeString('en-GB')}]</span>
        <span class="font-bold tracking-tight">{log}</span>
      </div>
    {/each}
  </div>
</footer>
