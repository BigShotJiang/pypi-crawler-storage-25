<script>
  import { Settings, Sun, Moon, BarChart2, TrendingUp, Activity } from 'lucide-svelte';
  import { marketData, appStatus } from '../lib/stores/market';
  import { settings, toggleTheme, setChartType } from '../lib/stores/settings';
</script>

<header class="h-20 solid-card flex items-center px-6 justify-between border-b border-[var(--border-primary)] shadow-sm z-10">
  <div class="flex items-center gap-8">
    <div>
      <div class="text-[10px] uppercase font-bold text-[var(--text-secondary)] tracking-widest mb-1">Active Symbol</div>
      <div class="text-lg font-bold text-sovereign-blue">{$marketData.symbol}</div>
    </div>
    <div class="hidden sm:block h-10 w-px bg-[var(--border-primary)]"></div>
    <div>
      <div class="text-[10px] uppercase font-bold text-[var(--text-secondary)] tracking-widest mb-1">Latency (Bridge)</div>
      <div class="text-lg font-bold text-green-500">0.8ms</div>
    </div>
  </div>

  <div class="flex items-center gap-2">
    <!-- Chart Type Switcher (Pro Standard) -->
    <div class="flex bg-[var(--bg-primary)] p-1 rounded-lg border border-[var(--border-primary)] mr-4">
      <button 
        class="h-8 px-3 rounded-md text-[11px] font-bold transition-all {$settings.chartType === 'candle' ? 'bg-sovereign-blue text-white shadow-md' : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]'}"
        on:click={() => setChartType('candle')}
      >
        CANDLES
      </button>
      <button 
        class="h-8 px-3 rounded-md text-[11px] font-bold transition-all {$settings.chartType === 'bar' ? 'bg-sovereign-blue text-white shadow-md' : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]'}"
        on:click={() => setChartType('bar')}
      >
        BARS
      </button>
      <button 
        class="h-8 px-3 rounded-md text-[11px] font-bold transition-all {$settings.chartType === 'line' ? 'bg-sovereign-blue text-white shadow-md' : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]'}"
        on:click={() => setChartType('line')}
      >
        LINE
      </button>
    </div>

    <div class="h-8 w-px bg-[var(--border-primary)] mx-2"></div>

    <!-- Theme Switcher -->
    <button class="btn-icon" on:click={toggleTheme} title="Switch Theme">
      {#if $settings.theme === 'dark'}
        <Sun size={20} />
      {:else}
        <Moon size={20} />
      {/if}
    </button>

    <button class="btn-icon" title="Terminal Settings">
      <Settings size={20} />
    </button>
  </div>
</header>
