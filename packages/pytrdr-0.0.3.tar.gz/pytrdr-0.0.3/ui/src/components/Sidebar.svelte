<script>
  import { LayoutDashboard, BarChart, LogOut, Terminal, Layers, Wallet, TrendingUp, ShieldCheck } from 'lucide-svelte';
  import { marketData } from '../lib/stores/market';
  import { settings } from '../lib/stores/settings';
</script>

<aside class="w-full h-full flex flex-col bg-[var(--bg-secondary)] border-r border-[var(--border-primary)] shadow-sm">
  <!-- Brand Logo Area -->
  <div class="px-6 py-10 flex items-center gap-3">
    <div class="h-10 w-10 bg-sovereign-blue rounded-lg flex items-center justify-center shadow-lg">
      <Terminal size={22} class="text-white" />
    </div>
    <div class="flex flex-col">
      <span class="text-lg font-bold tracking-tight text-[var(--text-primary)]">PYTRADER</span>
      <span class="text-[9px] uppercase tracking-widest text-sovereign-blue font-bold">Sovereign Edition</span>
    </div>
  </div>

  <!-- Primary Navigation -->
  <nav class="flex-1 px-4 space-y-1">
    <button class="w-full flex items-center gap-3 px-4 py-3 rounded-lg bg-sovereign-blue text-white shadow-md font-bold text-xs uppercase tracking-wider">
      <LayoutDashboard size={18} />
      Dashboard
    </button>
    <button class="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-[var(--text-secondary)] hover:bg-[var(--bg-primary)] hover:text-[var(--text-primary)] transition-all font-bold text-xs uppercase tracking-wider">
      <BarChart size={18} />
      Analytics
    </button>
    <button class="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-[var(--text-secondary)] hover:bg-[var(--bg-primary)] hover:text-[var(--text-primary)] transition-all font-bold text-xs uppercase tracking-wider">
      <Layers size={18} />
      EAs & Logic
    </button>
  </nav>

  <!-- Account Summary (Institutional Grade) -->
  <div class="m-4 p-5 rounded-xl border border-[var(--border-primary)] bg-[var(--bg-primary)] shadow-inner">
    <div class="flex items-center gap-2 mb-3">
      <Wallet size={16} class="text-sovereign-blue" />
      <span class="text-[10px] uppercase font-bold text-[var(--text-secondary)] tracking-widest">Account Details</span>
    </div>
    
    <div class="space-y-4">
      <div>
        <div class="text-[10px] text-[var(--text-secondary)] mb-1">EQUITY (USD)</div>
        <div class="text-xl font-mono font-bold text-[var(--text-primary)] tracking-tighter">
          ${$marketData.equity.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
        </div>
      </div>
      
      <div class="h-1 w-full bg-[var(--border-primary)] rounded-full overflow-hidden">
        <div class="h-full bg-sovereign-blue" style="width: 100%"></div>
      </div>

      <div class="flex items-center gap-2 text-[10px] font-bold text-green-500">
        <ShieldCheck size={12} />
        CONNECTION SECURE
      </div>
    </div>
  </div>

  <!-- Footer Actions -->
  <div class="p-4 border-t border-[var(--border-primary)]">
    <button class="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-red-500 hover:bg-red-500/5 transition-all font-bold text-xs uppercase tracking-wider">
      <LogOut size={18} />
      Terminal Exit
    </button>
  </div>
</aside>

<style>
  aside {
    z-index: 20;
  }
</style>
