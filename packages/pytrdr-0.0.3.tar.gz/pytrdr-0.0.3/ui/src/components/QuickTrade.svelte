<script>
  import { invoke } from '@tauri-apps/api/core';
  import { Plus, Minus, TrendingUp, TrendingDown } from 'lucide-svelte';
  import { marketData } from '../lib/stores/market';

  let volume = 0.01;
  let isExecuting = false;

  async function handleTrade(side) {
    isExecuting = true;
    try {
      const id = await invoke('place_order', { 
        symbol: $marketData.symbol, 
        side: side, 
        volume: volume.toString() 
      });
      console.log(`Trade Executed: ${side} ${volume} Lots. ID: ${id}`);
    } catch (e) {
      console.error("Trade Error:", e);
    } finally {
      isExecuting = false;
    }
  }

  function adjustVolume(delta) {
    volume = Math.max(0.01, parseFloat((volume + delta).toFixed(2)));
  }
</script>

<div class="absolute top-4 left-4 z-20 flex flex-col gap-2 p-2 rounded-xl border border-[var(--border-primary)] bg-[var(--bg-secondary)] shadow-xl w-64">
  <!-- Volume Selection -->
  <div class="flex items-center justify-between px-2 py-1 bg-[var(--bg-primary)] rounded-lg border border-[var(--border-primary)]">
    <button class="btn-icon h-8 w-8" on:click={() => adjustVolume(-0.01)}>
      <Minus size={14} />
    </button>
    <div class="flex flex-col items-center">
      <span class="text-[9px] font-bold text-[var(--text-secondary)] uppercase">Volume</span>
      <span class="text-sm font-mono font-bold">{volume.toFixed(2)}</span>
    </div>
    <button class="btn-icon h-8 w-8" on:click={() => adjustVolume(0.01)}>
      <Plus size={14} />
    </button>
  </div>

  <!-- Execution Buttons (Institutional Style) -->
  <div class="grid grid-cols-2 gap-2 h-16">
    <button 
      class="flex flex-col items-center justify-center rounded-lg bg-red-500 hover:bg-red-600 text-white font-bold transition-all disabled:opacity-50"
      on:click={() => handleTrade('sell')}
      disabled={isExecuting}
    >
      <TrendingDown size={18} />
      <span class="text-[10px] mt-1 text-white">SELL</span>
    </button>
    
    <button 
      class="flex flex-col items-center justify-center rounded-lg bg-green-500 hover:bg-green-600 text-white font-bold transition-all disabled:opacity-50"
      on:click={() => handleTrade('buy')}
      disabled={isExecuting}
    >
      <TrendingUp size={18} />
      <span class="text-[10px] mt-1 text-white">BUY</span>
    </button>
  </div>

  <div class="px-2 py-1 bg-black/5 dark:bg-white/5 rounded-md flex justify-between items-center">
    <span class="text-[9px] text-[var(--text-secondary)] font-bold uppercase">BID: <span class="text-[var(--text-primary)]">{$marketData.bid.toFixed(5)}</span></span>
    <span class="text-[9px] text-[var(--text-secondary)] font-bold uppercase">ASK: <span class="text-[var(--text-primary)]">{$marketData.ask.toFixed(5)}</span></span>
  </div>
</div>

<style>
  div {
    user-select: none;
  }
</style>
