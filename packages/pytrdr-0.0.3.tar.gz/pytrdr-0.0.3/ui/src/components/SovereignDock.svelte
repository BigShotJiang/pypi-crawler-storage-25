<script>
  import { onMount } from 'svelte';
  import { GoldenLayout } from 'golden-layout';
  import Sidebar from './Sidebar.svelte';
  import TradingChart from './TradingChart.svelte';
  import TerminalLog from './TerminalLog.svelte';
  import TradeLedger from './TradeLedger.svelte';

  // Styles
  import 'golden-layout/dist/css/goldenlayout-base.css';
  import 'golden-layout/dist/css/themes/goldenlayout-borderless-dark-theme.css';

  let layoutElement;
  let layout;

  const config = {
    settings: { showPopoutIcon: false, showMaximiseIcon: true, showCloseIcon: false },
    dimensions: { headerHeight: 32, borderWidth: 2 },
    root: {
      type: 'row',
      content: [
        {
          type: 'component',
          title: 'Fleet Watch',
          componentType: 'Sidebar',
          width: 15,
        },
        {
          type: 'column',
          content: [
            {
              type: 'component',
              title: 'Sovereign Eye',
              componentType: 'MainChart',
              height: 60,
            },
            {
              type: 'stack', // Stack for Tabs (Professional Workflow)
              height: 40,
              content: [
                {
                  type: 'component',
                  title: 'Trade Ledger',
                  componentType: 'TradeLedger',
                },
                {
                  type: 'component',
                  title: 'System Terminal',
                  componentType: 'TerminalLog',
                }
              ]
            }
          ]
        }
      ]
    }
  };

  onMount(() => {
    console.log("Dock: Initializing Tactical Workspace...");
    
    try {
        if (!layoutElement) {
            console.error("Dock: Layout element not found.");
            return;
        }

        layout = new GoldenLayout(layoutElement);

        // Individual Component Registrations (With Error Isolation)
        const registerData = [
            { name: 'Sidebar', comp: Sidebar },
            { name: 'MainChart', comp: TradingChart },
            { name: 'TerminalLog', comp: TerminalLog },
            { name: 'TradeLedger', comp: TradeLedger }
        ];

        registerData.forEach(item => {
            layout.registerComponentFactoryFunction(item.name, (container) => {
                try {
                    new item.comp({ target: container.element });
                } catch (e) {
                    console.error(`Dock: Failed to mount ${item.name}:`, e);
                    container.element.innerHTML = `<div class="p-4 text-red-500 font-bold">Error mounting ${item.name}</div>`;
                }
            });
        });

        layout.loadLayout(config);

        const resizeHandler = () => {
            if (layout) layout.updateSize();
        };
        window.addEventListener('resize', resizeHandler);

        return () => {
          window.removeEventListener('resize', resizeHandler);
          if (layout) layout.destroy();
        };
    } catch (e) {
        console.error("Dock: Critical initialization error:", e);
    }
  });
</script>

<div class="h-full w-full bg-[var(--bg-primary)]" bind:this={layoutElement}></div>

<style>
  /* Sovereign Professional Workspace Styles (Solid Design) */
  :global(.lm_content) { background: var(--bg-secondary) !important; overflow: hidden !important; }
  :global(.lm_header) { background: var(--bg-primary) !important; border-bottom: 1px solid var(--border-primary) !important; padding: 0 5px !important; }
  :global(.lm_title) { color: var(--text-secondary) !important; font-size: 10px !important; font-family: inherit !important; text-transform: uppercase !important; font-weight: bold !important; letter-spacing: 0.12em !important; padding-left: 10px !important; cursor: grab !important; }
  :global(.lm_tab) { background: var(--bg-primary) !important; border: 1px solid transparent !important; margin: 2px !important; border-radius: 4px 4px 0 0 !important; cursor: pointer !important; }
  :global(.lm_tab.lm_active) { background: var(--bg-secondary) !important; border-top: 2px solid var(--accent-primary) !important; border-left: 1px solid var(--border-primary) !important; border-right: 1px solid var(--border-primary) !important; }
  :global(.lm_tab.lm_active .lm_title) { color: var(--accent-primary) !important; }
  :global(.lm_splitter) { background: var(--bg-primary) !important; opacity: 1 !important; }
</style>
