<script>
  import { positions, accountData } from '../lib/stores/market';
  import { invoke } from '@tauri-apps/api/core';
  import { X, TrendingUp, TrendingDown, Wallet } from 'lucide-svelte';

  async function closePosition(id) {
    try {
      await invoke('close_position', { id });
      console.log(`Position Closed: ${id}`);
    } catch (e) {
      console.error("Ledger: Close Error:", e);
    }
  }

  function formatPrice(p) {
    return p.toFixed(5);
  }

  function formatPnL(p) {
    const sym = p >= 0 ? '+' : '';
    return `${sym}${p.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  }
</script>

<div class="h-full w-full bg-[var(--bg-secondary)] flex flex-col overflow-hidden">
  <!-- Ledger Header (Account Summary) -->
  <div class="h-12 px-6 flex items-center justify-between border-b border-[var(--border-primary)] bg-[var(--bg-primary)]">
    <div class="flex items-center gap-6">
      <div class="flex items-center gap-2">
        <Wallet size={14} class="text-sovereign-blue" />
        <span class="text-[10px] uppercase font-bold text-[var(--text-secondary)]">Exposure</span>
      </div>
      <div class="flex gap-4">
        <div class="text-[11px] font-bold">
          BALANCE: <span class="text-[var(--text-primary)] font-mono">${$accountData.balance.toLocaleString()}</span>
        </div>
        <div class="text-[11px] font-bold">
          EQUITY: <span class="text-sovereign-blue font-mono">${$accountData.equity.toLocaleString()}</span>
        </div>
      </div>
    </div>
    
    <div class="text-[11px] font-bold {($accountData.equity - $accountData.balance) >= 0 ? 'text-green-500' : 'text-red-500'}">
      FLOATING PNL: {formatPnL($accountData.equity - $accountData.balance)}
    </div>
  </div>

  <!-- Positions Table -->
  <div class="flex-1 overflow-y-auto">
    <table class="w-full text-left border-collapse">
      <thead>
        <tr class="bg-[var(--bg-primary)] text-[var(--text-secondary)] uppercase text-[10px] font-bold border-b border-[var(--border-primary)]">
          <th class="px-6 py-3">Symbol</th>
          <th class="px-6 py-3">Type</th>
          <th class="px-6 py-3">Volume</th>
          <th class="px-6 py-3">Entry</th>
          <th class="px-6 py-3">Current</th>
          <th class="px-6 py-3">Profit (USD)</th>
          <th class="px-6 py-3 text-right">Action</th>
        </tr>
      </thead>
      <tbody class="text-[var(--text-primary)] font-mono text-[11px]">
        {#each $positions as pos}
          <tr class="border-b border-[var(--border-primary)] hover:bg-[var(--bg-primary)] transition-colors">
            <td class="px-6 py-3 font-bold">{pos.symbol}</td>
            <td class="px-6 py-3">
              <span class="flex items-center gap-1 {pos.order_type === 'Buy' ? 'text-green-500' : 'text-red-500'} font-bold">
                {#if pos.order_type === 'Buy'}
                  <TrendingUp size={14} /> BUY
                {:else}
                  <TrendingDown size={14} /> SELL
                {/if}
              </span>
            </td>
            <td class="px-6 py-3">{pos.volume}</td>
            <td class="px-6 py-3">{formatPrice(pos.entry_price)}</td>
            <td class="px-6 py-3 font-bold">{formatPrice(pos.current_price)}</td>
            <td class="px-6 py-3 font-bold {pos.pnl >= 0 ? 'text-green-500' : 'text-red-500'}">
              {formatPnL(pos.pnl)}
            </td>
            <td class="px-6 py-3 text-right">
              <button 
                class="btn-icon h-8 w-8 text-red-500 hover:bg-red-500/10 ml-auto"
                on:click={() => closePosition(pos.id)}
              >
                <X size={16} />
              </button>
            </td>
          </tr>
        {/each}

        {#if $positions.length === 0}
          <tr>
            <td colspan="7" class="px-6 py-10 text-center text-[var(--text-secondary)] italic">
              No active positions detected. Bridge is awaiting execution orders.
            </td>
          </tr>
        {/if}
      </tbody>
    </table>
  </div>
</div>
