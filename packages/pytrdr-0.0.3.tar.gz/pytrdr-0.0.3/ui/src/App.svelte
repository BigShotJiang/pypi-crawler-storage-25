<script>
  import { onMount, onDestroy } from 'svelte';
  import Header from './components/Header.svelte';
  import SovereignDock from './components/SovereignDock.svelte';
  import { connectToBridge } from './lib/stores/market';
  import { settings } from './lib/stores/settings';

  let disconnect;

  onMount(async () => {
    // 1. Establish the Real-Time Bridge (The Pulse)
    disconnect = await connectToBridge();
    
    // 2. Ensure initial theme class is applied to root
    if ($settings.theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    
    console.log("App: Sovereign Terminal Initialized.");
  });

  onDestroy(() => {
    if (disconnect) disconnect();
  });
</script>

<main class="flex flex-col h-screen w-screen bg-[var(--bg-primary)] text-[var(--text-primary)] overflow-hidden font-sans">
  
  <!-- Global Stats (The Header) -->
  <Header />

  <!-- Workspace Orchestrator (The Tactical Dock) -->
  <div class="flex-1 w-full overflow-hidden bg-[var(--bg-primary)]">
    <SovereignDock />
  </div>

</main>

<style>
  /* Global Resets and Sovereign Standard Overrides */
  :global(body) {
    margin: 0;
    padding: 0;
    overflow: hidden;
    user-select: none;
  }
</style>
