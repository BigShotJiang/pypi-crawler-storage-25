/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{svelte,js,ts,jsx,tsx}",
  ],
  darkMode: 'class', // Enable class-based dark mode
  theme: {
    extend: {
      colors: {
        'sovereign-blue': 'var(--accent-primary)',
        'sovereign-bg': 'var(--bg-primary)',
        'sovereign-panel': 'var(--bg-secondary)',
        'sovereign-border': 'var(--border-primary)',
        'sovereign-text': 'var(--text-primary)',
        'sovereign-muted': 'var(--text-secondary)',
      },
      fontFamily: {
        'sans': ['Inter', 'system-ui', 'sans-serif'],
        'mono': ['JetBrains Mono', 'monospace'],
      }
    },
  },
  plugins: [],
}
