class Video:
    pass