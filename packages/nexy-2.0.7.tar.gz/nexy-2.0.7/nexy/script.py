class Script:
    pass