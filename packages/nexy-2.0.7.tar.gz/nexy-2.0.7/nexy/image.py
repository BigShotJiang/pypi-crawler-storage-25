class Image:
    pass