import scipy # nibabel uses scipy
import numpy as np
import nibabel as nib
from nibabel.processing import resample_to_output
from typing import Optional

def nii_file_original_zoom(filepath:str) -> tuple[float, float, float]:
    input_img = nib.load(filepath)
    x_raw, y_raw, z_raw = input_img.header.get_zooms()
    return float(x_raw), float(y_raw), float(z_raw)

def nii_file_to_numpy(filepath:str, 
    x_mm:Optional[float] = None, 
    y_mm:Optional[float] = None, 
    z_mm:Optional[float] = None) -> np.ndarray:
    input_img = nib.load(filepath)

    # Get Original Zoom
    x_raw, y_raw, z_raw = nii_file_original_zoom(filepath)

    # Get Zoom Now
    if x_mm is None:
        x_mm = x_raw
    if y_mm is None:
        y_mm = y_raw
    if z_mm is None:
        z_mm = z_raw

    resampled_img = resample_to_output(input_img, voxel_sizes=(x_mm, y_mm, z_mm))
    isotropic_data = resampled_img.get_fdata()
    return isotropic_data.astype(np.float32)
