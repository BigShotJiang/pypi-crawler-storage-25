# read_nii_to_numpy
Read the NIfTI file and resample it into a 3D NumPy array.

## Installation

```bash
pip install read_nii_to_numpy
```

## Usage

```python
from read_nii_to_numpy import nii_file_original_zoom, nii_file_to_numpy

# Get original zoom
#   the output (x_len, y_len, z_len) means:
#     1 voxel in x direction corresponds to x_len (mm)
#     1 voxel in y direction corresponds to y_len (mm)
#     1 voxel in z direction corresponds to z_len (mm)
print(nii_file_original_zoom("CT.nii"))

# Get original data matrix
odm = nii_file_to_numpy("CT.nii")
print(odm.shape)

# Get reshaped data matrix
rdm = nii_file_to_numpy("CT.nii", 1.0, 1.0, 1.0)
print(rdm.shape)
```
