"""
AIBrain Security Utilities — SSRF protection, URL validation, rate limiting, auth.
Phase 2 security hardening. No external dependencies.
"""

import base64
import hashlib
import hmac
import ipaddress
import json
import logging
import os
import secrets
import threading
import time
from urllib.parse import urlparse

logger = logging.getLogger(__name__)

from fastapi import Request
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware


# ---------------------------------------------------------------------------
# SSRF Protection — block internal/dangerous URLs
# ---------------------------------------------------------------------------

# Private/reserved IP ranges that should never be hit from user-supplied URLs
_BLOCKED_NETWORKS = [
    ipaddress.ip_network("127.0.0.0/8"),       # Loopback
    ipaddress.ip_network("10.0.0.0/8"),         # RFC1918
    ipaddress.ip_network("172.16.0.0/12"),      # RFC1918
    ipaddress.ip_network("192.168.0.0/16"),     # RFC1918
    ipaddress.ip_network("169.254.0.0/16"),     # Link-local
    ipaddress.ip_network("0.0.0.0/8"),          # "This" network
    ipaddress.ip_network("::1/128"),            # IPv6 loopback
    ipaddress.ip_network("fc00::/7"),           # IPv6 private
    ipaddress.ip_network("fe80::/10"),          # IPv6 link-local
]

_ALLOWED_SCHEMES = {"http", "https"}


def validate_url(url: str, *, pin_ip: bool = False) -> tuple[bool, str]:
    """Validate a URL for SSRF safety.

    Returns (is_safe, reason). If is_safe is False, reason explains why.

    When *pin_ip* is True and the URL is safe, the returned reason string
    is ``"pinned:<ip>"`` — callers MUST connect to that IP (with the original
    Host header) instead of re-resolving DNS.  This defeats DNS rebinding
    attacks where the attacker serves a safe IP at validation time then
    switches to an internal IP on the real connection.
    """
    if not url or not isinstance(url, str):
        return False, "Empty or invalid URL"

    try:
        parsed = urlparse(url.strip())
    except Exception as e:
        logger.warning("Malformed URL rejected: %s", e)
        return False, "Malformed URL"

    # Block dangerous schemes
    if parsed.scheme.lower() not in _ALLOWED_SCHEMES:
        return False, f"Blocked scheme: {parsed.scheme}. Only http/https allowed"

    hostname = parsed.hostname
    if not hostname:
        return False, "No hostname in URL"

    # Resolve hostname to IP and check against blocked ranges
    pinned_ip = None
    try:
        import socket
        # Resolve all addresses for the hostname
        addr_infos = socket.getaddrinfo(hostname, parsed.port or 80, proto=socket.IPPROTO_TCP)
        for family, _, _, _, sockaddr in addr_infos:
            ip = ipaddress.ip_address(sockaddr[0])
            # Also check IPv6-mapped IPv4 addresses (e.g. ::ffff:127.0.0.1)
            mapped = getattr(ip, "ipv4_mapped", None)
            for network in _BLOCKED_NETWORKS:
                if ip in network:
                    return False, f"Blocked: {hostname} resolves to internal IP ({ip})"
                if mapped and mapped in network:
                    return False, f"Blocked: {hostname} resolves to internal IP ({ip} maps to {mapped})"
            if pinned_ip is None:
                pinned_ip = str(ip)
    except socket.gaierror:
        return False, f"Cannot resolve hostname: {hostname}"
    except Exception as e:
        return False, f"URL validation error: {str(e)[:100]}"

    if pin_ip and pinned_ip:
        return True, f"pinned:{pinned_ip}"
    return True, "ok"


def resolve_and_pin_url(url: str) -> tuple[str, str]:
    """Validate URL and return (pinned_ip, original_hostname).

    Resolves DNS exactly once, validates the IP, and returns the pinned IP
    so callers can connect directly to it (setting Host header to the
    original hostname).  Raises ValueError if the URL is unsafe.

    Usage::

        pinned_ip, hostname = resolve_and_pin_url("http://example.com:8080/path")
        # Connect to pinned_ip:8080 with Host: example.com
    """
    is_safe, reason = validate_url(url, pin_ip=True)
    if not is_safe:
        raise ValueError(reason)
    parsed = urlparse(url.strip())
    hostname = parsed.hostname or ""
    pinned_ip = reason.split(":", 1)[1] if reason.startswith("pinned:") else ""
    return pinned_ip, hostname


def require_safe_url(url: str) -> str:
    """Validate URL and raise ValueError if unsafe. Returns the URL if safe."""
    is_safe, reason = validate_url(url)
    if not is_safe:
        raise ValueError(reason)
    return url


# ---------------------------------------------------------------------------
# Rate Limiting Middleware — simple in-memory token bucket per IP
# ---------------------------------------------------------------------------

class RateLimitMiddleware(BaseHTTPMiddleware):
    """Per-IP rate limiting with configurable limits per path prefix.

    Default: 60 req/min for API endpoints, 10 req/min for auth endpoints.
    Uses a sliding window counter (resets each minute).
    """

    # Maximum distinct IPs tracked before forced eviction of oldest entries
    _MAX_TRACKED_IPS = 10_000

    def __init__(self, app, general_rpm: int = 60, auth_rpm: int = 10):
        super().__init__(app)
        self.general_rpm = general_rpm
        self.auth_rpm = auth_rpm
        # Plain dict (NOT defaultdict) — prevents auto-creation of entries on read
        self._general: dict[str, dict] = {}
        self._auth: dict[str, dict] = {}
        self._lock = threading.Lock()
        # Paths that get stricter rate limits
        self._auth_prefixes = ("/api/agent/approvals/", "/api/auth", "/api/setup")
        # Cleanup tracking — prune stale IP entries every 60 seconds
        self._last_cleanup: float = 0.0

    # IPs of trusted reverse proxies — only trust X-Forwarded-For from these
    _TRUSTED_PROXIES = frozenset({"127.0.0.1", "::1"})

    def _get_client_ip(self, request: Request) -> str:
        """Extract client IP. Only trusts X-Forwarded-For from known proxies."""
        client_ip = request.client.host if request.client else "unknown"
        if client_ip in self._TRUSTED_PROXIES:
            forwarded = request.headers.get("x-forwarded-for")
            if forwarded:
                return forwarded.split(",")[0].strip()
        return client_ip

    def _check_limit(self, bucket: dict, rpm: int) -> tuple[bool, int]:
        """Check if request is within rate limit. Returns (allowed, remaining)."""
        now = time.time()
        # Reset window if expired (60-second sliding window)
        if now - bucket["window_start"] >= 60:
            bucket["count"] = 0
            bucket["window_start"] = now

        bucket["count"] += 1
        remaining = max(0, rpm - bucket["count"])
        return bucket["count"] <= rpm, remaining

    def _prune_stale_entries(self):
        """Remove IP entries whose rate window expired >120s ago to prevent unbounded growth.

        Runs every 60 seconds (down from 300s). Also enforces _MAX_TRACKED_IPS:
        if either bucket exceeds the cap, the oldest entries are evicted.
        """
        now = time.time()
        if now - self._last_cleanup < 60:
            return
        with self._lock:
            self._last_cleanup = now
            cutoff = now - 120
            for bucket in (self._general, self._auth):
                # Remove expired entries
                stale = [ip for ip, b in bucket.items() if b["window_start"] < cutoff]
                for ip in stale:
                    del bucket[ip]
                # Hard cap: evict oldest entries if over limit
                if len(bucket) > self._MAX_TRACKED_IPS:
                    sorted_ips = sorted(bucket.items(), key=lambda kv: kv[1]["window_start"])
                    excess = len(bucket) - self._MAX_TRACKED_IPS
                    for ip, _ in sorted_ips[:excess]:
                        del bucket[ip]

    async def dispatch(self, request: Request, call_next):
        # Skip rate limiting for WebSocket upgrades and health checks
        path = request.url.path
        if path.startswith("/ws/") or path in ("/health", "/health/deep"):  # noqa:PATH-STARTSWITH-BYPASS
            return await call_next(request)

        # Only rate-limit API paths
        if not path.startswith("/api"):  # noqa:PATH-STARTSWITH-BYPASS
            return await call_next(request)

        self._prune_stale_entries()

        client_ip = self._get_client_ip(request)

        # Apply a minimum rate limit for localhost — 600 req/min instead of
        # skipping entirely. Prevents unlimited brute-force from local processes.
        # The per-email DB limiter in auth_routes.py still applies independently.
        _LOCALHOST_RPM = 600
        is_localhost = client_ip in ("127.0.0.1", "::1", "localhost")

        # Determine which bucket to use
        is_auth_path = any(path.startswith(p) for p in self._auth_prefixes)  # noqa:PATH-STARTSWITH-BYPASS
        if is_localhost:
            # Localhost gets a single shared bucket at 600 req/min (all paths)
            if client_ip not in self._general:
                self._general[client_ip] = {"count": 0, "window_start": 0.0}
            allowed, remaining = self._check_limit(self._general[client_ip], _LOCALHOST_RPM)
            limit = _LOCALHOST_RPM
        elif is_auth_path:
            if client_ip not in self._auth:
                self._auth[client_ip] = {"count": 0, "window_start": 0.0}
            allowed, remaining = self._check_limit(self._auth[client_ip], self.auth_rpm)
            limit = self.auth_rpm
        else:
            if client_ip not in self._general:
                self._general[client_ip] = {"count": 0, "window_start": 0.0}
            allowed, remaining = self._check_limit(self._general[client_ip], self.general_rpm)
            limit = self.general_rpm

        if not allowed:
            return JSONResponse(
                {"error": "Rate limit exceeded. Try again in 60 seconds."},
                status_code=429,
                headers={
                    "X-RateLimit-Limit": str(limit),
                    "X-RateLimit-Remaining": "0",
                    "Retry-After": "60",
                },
            )

        response = await call_next(request)
        response.headers["X-RateLimit-Limit"] = str(limit)
        response.headers["X-RateLimit-Remaining"] = str(remaining)
        return response


# ---------------------------------------------------------------------------
# Authentication Middleware — API key (local) + JWT (remote)
# ---------------------------------------------------------------------------
# Auth modes (set via aibrain_db.config_set("auth_mode", mode)):
#   "none"    — no auth required (dev/local only)
#   "api_key" — require X-API-Key header (single-user local)
#   "jwt"     — require Bearer token (multi-user/remote)
#
# API keys are stored hashed (SHA-256) in config as "api_keys" list.
# JWT uses HS256 with a server-generated secret stored in config as "jwt_secret".
# ---------------------------------------------------------------------------

# Paths that never require auth
_AUTH_BYPASS_PATHS = frozenset({
    "/health", "/api/health", "/api/ready",
    # /api/health/deep is intentionally NOT here — it requires auth
    # Auth login/register endpoints must be reachable without an existing token
    "/api/auth/login", "/api/auth/register",
    # /api/auth/me — handler owns JWT check; bypass prevents double-auth overhead.
    # The endpoint at GET /api/auth/me in main.py performs its own full Bearer JWT
    # validation (jwt_decode + expiry + issuer/audience checks) and returns 401 on
    # any failure. Bypassing AuthMiddleware here avoids a redundant second auth pass
    # and allows clients with a valid JWT (but no API key) to reach the endpoint
    # regardless of the server's configured auth_mode. Do NOT remove from bypass
    # without also removing the handler's own JWT check — one layer must own auth.
    "/api/auth/me",
    # /api/auth/verify is an exact POST endpoint (no sub-paths) that validates
    # a token without requiring one. Listed as an exact path here — NOT in
    # _AUTH_BYPASS_PREFIXES — to avoid inadvertently bypassing any future
    # sub-paths (e.g. /api/auth/verify/<anything>).
    "/api/auth/verify",
    # Frontend HTML pages — served without auth (chat UI is the product surface)
    "/", "/chat",
    # Stripe calls /webhooks/stripe directly with its own signature verification;
    # JWT auth is wrong here — Stripe uses its own Stripe-Signature header, not JWT.
    # The handler verifies the Stripe-Signature header itself.
    "/webhooks/stripe",
    # Intentionally public stats endpoint
    "/public/stats",
    # Docs are only publicly accessible in development environments.
    # In production (AIBRAIN_ENV != "development"), /docs, /redoc, and
    # /openapi.json require authentication to prevent schema enumeration.
    *(["/docs", "/openapi.json", "/redoc"]
      if os.getenv("AIBRAIN_ENV", "production") == "development"
      else []),
})
# WebSocket auth: first-message token validation.
# On connect, client must send {"type": "auth", "token": "<api_key_or_jwt>"}
# within 5 seconds or the connection is closed.
# NOTE: _AUTH_BYPASS_PREFIXES is intentionally empty — all bypass paths are
# exact entries in _AUTH_BYPASS_PATHS above. Using prefix matching only when
# there are legitimate sub-path trees that need blanket bypass (none currently).
_AUTH_BYPASS_PREFIXES: tuple[str, ...] = ()


def _get_hash_secret() -> str:
    """Return the server-side HMAC secret for API key hashing.

    Uses AIBRAIN_API_HASH_SECRET env var if set, otherwise generates and
    persists one via aibrain_db config.  This ensures API key hashes are
    not reversible via rainbow tables (the secret acts as a global salt).
    """
    env_secret = os.environ.get("AIBRAIN_API_HASH_SECRET")
    if env_secret:
        return env_secret
    try:
        import aibrain_db
        secret = aibrain_db.config_get("api_hash_secret")
        if not secret:
            secret = secrets.token_hex(32)
            aibrain_db.config_set("api_hash_secret", secret)
        return secret
    except Exception:
        # Fallback for tests / import-time calls before DB is ready
        return ""


def _hash_key(key: str, *, _secret: str | None = None) -> str:
    """HMAC-SHA256 hash of an API key using a server-side secret.

    The secret prevents offline rainbow-table attacks against stored hashes.
    Falls back to unsalted SHA-256 only when no secret is available (first boot).
    """
    secret = _secret if _secret is not None else _get_hash_secret()
    if secret:
        return hmac.new(secret.encode(), key.encode(), hashlib.sha256).hexdigest()
    # Fallback: plain SHA-256 (only during initial bootstrap before DB exists)
    return hashlib.sha256(key.encode()).hexdigest()


def _needs_rehash(stored_hash: str, key: str) -> bool:
    """Check if a stored hash was created with the old unsalted SHA-256.

    Returns True if the key matches the stored hash via plain SHA-256
    but NOT via HMAC — meaning it needs to be rehashed on next use.
    """
    plain = hashlib.sha256(key.encode()).hexdigest()
    if not hmac.compare_digest(plain, stored_hash):
        return False
    # It matches plain SHA-256 — check if HMAC would produce different result
    hmac_hash = _hash_key(key)
    return not hmac.compare_digest(hmac_hash, stored_hash)


def generate_api_key() -> str:
    """Generate a new 48-char URL-safe API key."""
    return secrets.token_urlsafe(36)


# --------------- Minimal JWT (HS256, no PyJWT dep) ---------------

def _b64url_encode(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode()


def _b64url_decode(s: str) -> bytes:
    padding = 4 - len(s) % 4
    if padding != 4:
        s += "=" * padding
    return base64.urlsafe_b64decode(s)


_JWT_ISSUER = "aibrain"
_JWT_AUDIENCE = "aibrain-api"


def jwt_encode(payload: dict, secret: str, ttl: int = 86400) -> str:
    """Create a HS256 JWT. ttl in seconds (default 24h)."""
    header = {"alg": "HS256", "typ": "JWT"}
    now = int(time.time())
    payload = {**payload, "iat": now, "exp": now + ttl,
               "iss": _JWT_ISSUER, "aud": _JWT_AUDIENCE}

    segments = [
        _b64url_encode(json.dumps(header, separators=(",", ":")).encode()),
        _b64url_encode(json.dumps(payload, separators=(",", ":")).encode()),
    ]
    signing_input = f"{segments[0]}.{segments[1]}".encode()
    sig = hmac.new(secret.encode(), signing_input, hashlib.sha256).digest()
    segments.append(_b64url_encode(sig))
    return ".".join(segments)


def jwt_decode(token: str, secret: str) -> dict | None:
    """Decode and verify a HS256 JWT. Returns payload or None if invalid/expired."""
    try:
        parts = token.split(".")
        if len(parts) != 3:
            return None

        signing_input = f"{parts[0]}.{parts[1]}".encode()
        expected_sig = hmac.new(secret.encode(), signing_input, hashlib.sha256).digest()
        actual_sig = _b64url_decode(parts[2])

        if not hmac.compare_digest(expected_sig, actual_sig):
            return None

        payload = json.loads(_b64url_decode(parts[1]))

        # Check expiration
        if payload.get("exp", 0) < int(time.time()):
            return None

        # Validate issuer and audience — reject tokens missing or mismatching these claims
        if payload.get("iss") != _JWT_ISSUER:
            logger.warning("JWT rejected: bad issuer %r (expected %r)", payload.get("iss"), _JWT_ISSUER)
            return None
        if payload.get("aud") != _JWT_AUDIENCE:
            logger.warning("JWT rejected: bad audience %r (expected %r)", payload.get("aud"), _JWT_AUDIENCE)
            return None

        return payload
    except Exception as e:
        logger.warning("JWT decode failed: %s", e)
        return None


_jwt_secret_lock = threading.Lock()


class AuthMiddleware(BaseHTTPMiddleware):
    """Authentication middleware supporting API key and JWT modes.

    Auth mode is read from aibrain_db config on each request so it can be
    changed at runtime without restart. Lazy-imports aibrain_db to avoid
    circular imports at module load time.
    """

    def __init__(self, app):
        super().__init__(app)
        self._db = None

    def _get_db(self):
        """Lazy import to avoid circular dependency with main.py."""
        if self._db is None:
            import aibrain_db
            self._db = aibrain_db
        return self._db

    def _get_auth_mode(self) -> str:
        db = self._get_db()
        return db.config_get("auth_mode", "api_key")

    def _get_jwt_secret(self) -> str:
        db = self._get_db()
        secret = db.config_get("jwt_secret")
        if secret:
            return secret
        # Double-checked locking — prevents two requests racing to write different secrets
        with _jwt_secret_lock:
            secret = db.config_get("jwt_secret")
            if not secret:
                secret = secrets.token_hex(32)
                db.config_set("jwt_secret", secret)
        return secret

    def _verify_api_key(self, key: str) -> bool:
        db = self._get_db()
        stored_keys = db.config_get("api_keys", [])
        if not stored_keys:
            return False
        hashed = _hash_key(key)
        # Check HMAC hash first (new format)
        if any(hmac.compare_digest(hashed, sk) for sk in stored_keys):
            return True
        # Migration: check if any stored hash matches via legacy unsalted SHA-256
        for i, sk in enumerate(stored_keys):
            if _needs_rehash(sk, key):
                # Rehash with HMAC and update stored key in-place
                stored_keys[i] = hashed
                db.config_set("api_keys", stored_keys)
                logger.info("Migrated API key hash from SHA-256 to HMAC-SHA256")
                return True
        return False

    def _verify_jwt(self, token: str) -> dict | None:
        secret = self._get_jwt_secret()
        return jwt_decode(token, secret)

    def _should_bypass(self, path: str) -> bool:
        import posixpath
        # Normalize first — prevents ../  traversal bypass like /api/auth/verify/../agent/approvals
        normalized = posixpath.normpath(path)
        if normalized in _AUTH_BYPASS_PATHS:
            return True
        # Match prefix exactly or with trailing slash — prevents /api/auth/verify-evil bypass
        return any(normalized == p or normalized.startswith(p + "/") for p in _AUTH_BYPASS_PREFIXES)

    async def dispatch(self, request: Request, call_next):
        path = request.url.path

        # Always bypass auth for health, docs, websockets, auth endpoints,
        # frontend pages, webhooks, and other explicitly listed public paths.
        # NOTE: this replaces the former catch-all "not /api" bypass — all
        # unauthenticated paths must now be explicitly listed in
        # _AUTH_BYPASS_PATHS or _AUTH_BYPASS_PREFIXES above.
        if self._should_bypass(path):
            return await call_next(request)

        # Non-/api paths that weren't explicitly bypassed above are blocked.
        # This prevents accidentally exposing future routes added outside /api.
        if not path.startswith("/api"):
            from fastapi.responses import JSONResponse as _JR
            return _JR({"error": "Not found"}, status_code=404)

        # Local connections skip auth (local-first product)
        client_ip = request.client.host if request.client else "unknown"
        if client_ip in ("127.0.0.1", "::1", "localhost"):
            return await call_next(request)

        auth_mode = self._get_auth_mode()

        # No auth configured — pass through (dev mode)
        if auth_mode == "none":
            return await call_next(request)

        # API Key mode
        if auth_mode == "api_key":
            key = request.headers.get("x-api-key")
            if not key:
                return JSONResponse(
                    {"error": "Missing API key. Provide X-API-Key header."},
                    status_code=401,
                )
            if not self._verify_api_key(key):
                return JSONResponse(
                    {"error": "Invalid API key."},
                    status_code=403,
                )
            # RBAC check
            allowed, reason = check_rbac(request)
            if not allowed:
                return JSONResponse({"error": reason}, status_code=403)
            return await call_next(request)

        # JWT mode
        if auth_mode == "jwt":
            auth_header = request.headers.get("authorization", "")
            if not auth_header.lower().startswith("bearer "):
                return JSONResponse(
                    {"error": "Missing or malformed Authorization header. Use: Bearer <token>"},
                    status_code=401,
                )
            token = auth_header[7:].strip()
            payload = self._verify_jwt(token)
            if payload is None:
                return JSONResponse(
                    {"error": "Invalid or expired JWT token."},
                    status_code=403,
                )
            # Attach user info to request state for downstream handlers
            request.state.user = payload.get("sub", "anonymous")
            request.state.jwt_payload = payload
            # RBAC check
            allowed, reason = check_rbac(request)
            if not allowed:
                return JSONResponse({"error": reason}, status_code=403)
            return await call_next(request)

        # Unknown auth mode — fail closed
        return JSONResponse(
            {"error": f"Unknown auth mode: {auth_mode}. Set auth_mode to none/api_key/jwt."},
            status_code=500,
        )


# ---------------------------------------------------------------------------
# Auth API helpers — called by auth endpoints in main.py
# ---------------------------------------------------------------------------

def create_api_key() -> tuple[str, str]:
    """Generate a new API key. Returns (plaintext_key, hashed_key).
    Caller must store the hash and give the plaintext to the user ONCE."""
    key = generate_api_key()
    return key, _hash_key(key)


def register_api_key(db_module) -> str:
    """Generate, hash, and store a new API key. Returns the plaintext key."""
    key, hashed = create_api_key()
    existing = db_module.config_get("api_keys", [])
    existing.append(hashed)
    db_module.config_set("api_keys", existing)
    return key


def revoke_api_key(db_module, key_prefix: str) -> bool:
    """Revoke an API key by its first 8 chars (prefix match on hash). Returns success."""
    existing = db_module.config_get("api_keys", [])
    before = len(existing)
    existing = [k for k in existing if not k.startswith(key_prefix)]
    if len(existing) == before:
        return False
    db_module.config_set("api_keys", existing)
    return True


def issue_jwt(db_module, subject: str, ttl: int = 86400) -> str:
    """Issue a JWT token for the given subject. ttl in seconds (default 24h)."""
    secret = db_module.config_get("jwt_secret")
    if not secret:
        secret = secrets.token_hex(32)
        db_module.config_set("jwt_secret", secret)
    return jwt_encode({"sub": subject}, secret, ttl)


# ---------------------------------------------------------------------------
# Request ID Middleware — trace requests across logs
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# WebSocket Auth — first-message token validation
# ---------------------------------------------------------------------------

async def ws_authenticate(websocket, timeout: float = 5.0) -> bool:
    """Require first message to be an auth token. Returns True if valid.

    Expected message: {"type": "auth", "token": "<api_key_or_jwt>"}
    On auth_mode "none", always returns True (dev/local).
    On localhost (127.0.0.1), always returns True (local-first product).
    """
    # Local connections skip auth (local-first product)
    client_ip = websocket.client.host if websocket.client else "unknown"
    if client_ip in ("127.0.0.1", "::1"):
        return True

    import aibrain_db
    auth_mode = aibrain_db.config_get("auth_mode", "api_key")
    if auth_mode == "none":
        return True

    import asyncio
    try:
        data = await asyncio.wait_for(websocket.receive_json(), timeout=timeout)
    except (asyncio.TimeoutError, Exception):
        await websocket.close(code=4001, reason="Auth timeout — send auth message within 5s")
        return False

    if data.get("type") != "auth" or not data.get("token"):
        await websocket.close(code=4002, reason="First message must be {type: auth, token: ...}")
        return False

    token = data["token"]

    if auth_mode == "api_key":
        hashed = _hash_key(token)
        stored_keys = aibrain_db.config_get("api_keys", [])
        if stored_keys:
            # Check HMAC hash first, then legacy SHA-256 with migration
            if any(hmac.compare_digest(hashed, sk) for sk in stored_keys):
                return True
            for i, sk in enumerate(stored_keys):
                if _needs_rehash(sk, token):
                    stored_keys[i] = hashed
                    aibrain_db.config_set("api_keys", stored_keys)
                    logger.info("Migrated WS API key hash from SHA-256 to HMAC-SHA256")
                    return True
        await websocket.close(code=4003, reason="Invalid API key")
        return False

    if auth_mode == "jwt":
        secret = aibrain_db.config_get("jwt_secret", "")
        if secret and jwt_decode(token, secret) is not None:
            return True
        await websocket.close(code=4003, reason="Invalid or expired JWT")
        return False

    await websocket.close(code=4003, reason=f"Unknown auth mode: {auth_mode}")
    return False


class RequestIdMiddleware(BaseHTTPMiddleware):
    """Add a unique request ID to every response for tracing.

    Generates X-Request-ID if not provided by client/proxy.
    Stores on request.state for downstream handlers to use in logs.
    """

    async def dispatch(self, request: Request, call_next):
        import re
        req_id = request.headers.get("x-request-id") or secrets.token_hex(8)
        req_id = re.sub(r'[^a-zA-Z0-9\-]', '', req_id)[:64]
        request.state.request_id = req_id
        response = await call_next(request)
        response.headers["X-Request-ID"] = req_id
        return response


# ---------------------------------------------------------------------------
# Input Sanitization helpers
# ---------------------------------------------------------------------------

def safe_limit(value: int, max_val: int = 500, min_val: int = 1) -> int:
    """Clamp a LIMIT value to safe bounds."""
    return min(max(min_val, value), max_val)


# ---------------------------------------------------------------------------
# Role-Based Access Control (RBAC)
# ---------------------------------------------------------------------------
# Three roles:
#   admin  — full access to all endpoints
#   user   — read + limited write (memories, search, brain queries, chat)
#   viewer — read-only access
#
# Roles are stored:
#   - In JWT payload as "role" claim
#   - In config as "api_key_roles" mapping hash_prefix -> role
#   - Default role for unauthenticated local access: "admin" (local-first)
# ---------------------------------------------------------------------------

ROLES = ("admin", "user", "viewer")

# Endpoint classifications — path prefix -> minimum required role
# More specific paths checked first. Admin-only endpoints are things that
# change system configuration, manage auth, or modify infrastructure.
_ADMIN_PATHS = (
    "/api/auth/mode",
    "/api/auth/keys",
    "/api/auth/token",
    "/api/agent/scheduler/reload",
    "/api/config",              # PUT config
    "/api/mcp/servers",         # POST/DELETE MCP servers
    "/api/backups",             # POST/DELETE backups
    "/api/permissions",         # POST/DELETE permissions
    "/api/setup",
)

# Paths that require at least "user" role (read + limited write)
_USER_PATHS = (
    "/api/memories",
    "/api/search",
    "/api/brain",
    "/api/agent/chat",
    "/api/ingest",
    "/api/content",
    "/api/skills",
    "/api/workflows",
    "/api/projects",
    "/api/tasks",
    "/api/evolution",
    "/api/broker",
    "/api/links",
    "/api/tools",
)

# Everything else under /api is viewer-accessible (GET-only enforced by role)
# State-changing methods (POST/PUT/DELETE/PATCH) on viewer paths are blocked for viewers.


def get_role_for_request(request: Request) -> str:
    """Extract the role for the current request.

    Priority:
    1. JWT "role" claim (if JWT auth)
    2. API key role mapping in config (if API key auth)
    3. "admin" for localhost (local-first product)
    4. "viewer" as fallback
    """
    # Local connections get admin (local-first product)
    client_ip = request.client.host if request.client else "unknown"
    if client_ip in ("127.0.0.1", "::1", "localhost"):
        return "admin"

    # Check JWT payload
    jwt_payload = getattr(getattr(request, "state", None), "jwt_payload", None)
    if jwt_payload and isinstance(jwt_payload, dict):
        role = jwt_payload.get("role", "viewer")
        if role in ROLES:
            return role
        return "viewer"

    # Check API key role mapping
    api_key = request.headers.get("x-api-key", "")
    if api_key:
        try:
            import aibrain_db
            key_roles = aibrain_db.config_get("api_key_roles", {})
            hashed = _hash_key(api_key)
            prefix = hashed[:12]
            role = key_roles.get(prefix, "user")
            if role in ROLES:
                return role
        except Exception:
            pass
        return "user"

    return "viewer"


def _path_matches(request_path: str, prefix: str) -> bool:
    """Check if a request path matches a prefix (exact or with trailing segment)."""
    return request_path == prefix or request_path.startswith(prefix + "/")


def check_rbac(request: Request) -> tuple[bool, str]:
    """Check if the request is allowed by RBAC rules.

    Returns (allowed, reason).
    """
    import posixpath
    path = posixpath.normpath(request.url.path)
    method = request.method
    role = get_role_for_request(request)

    # Admin can do anything
    if role == "admin":
        return True, "admin"

    # Check if path is admin-only
    for admin_path in _ADMIN_PATHS:
        if _path_matches(path, admin_path):
            # Admin-only: allow GET for user role on some info endpoints,
            # but block all state-changing methods for non-admins
            if method in ("POST", "PUT", "DELETE", "PATCH"):
                return False, f"Admin role required for {method} {path}"
            if role == "viewer":
                # Viewers can read config/permissions but not auth management
                if any(_path_matches(path, p) for p in ("/api/auth/keys", "/api/auth/token", "/api/auth/mode")):
                    return False, f"Admin role required for {path}"
            return True, f"{role} read access"

    # Check user-level paths
    for user_path in _USER_PATHS:
        if _path_matches(path, user_path):
            if role == "viewer" and method in ("POST", "PUT", "DELETE", "PATCH"):
                return False, f"User role required for {method} {path}"
            return True, f"{role} access"

    # Default: allow GET for all roles, block writes for viewers
    if role == "viewer" and method in ("POST", "PUT", "DELETE", "PATCH"):
        return False, f"Viewer role is read-only, cannot {method} {path}"

    return True, f"{role} access"


def jwt_auth(request: Request) -> dict:
    """FastAPI Depends dependency — enforce JWT authentication on protected routers.

    Mirrors the logic in AuthMiddleware but as a per-router dependency so it can
    be applied granularly (e.g. router-level Depends on /api/agent/*).

    Bypass rules (identical to AuthMiddleware):
    - Localhost (127.0.0.1 / ::1) → always allowed (local-first product)
    - auth_mode == "none" → always allowed (dev mode)
    - auth_mode == "api_key" → X-API-Key header required and valid
    - auth_mode == "jwt" → Authorization: Bearer <token> required and valid

    Returns the JWT payload dict (or empty dict for non-JWT modes).
    Raises HTTPException 401/403 on auth failure.
    """
    from fastapi import HTTPException as _HTTPException

    client_ip = request.client.host if request.client else "unknown"
    if client_ip in ("127.0.0.1", "::1", "localhost"):
        return {}

    import aibrain_db
    auth_mode = aibrain_db.config_get("auth_mode", "api_key")

    if auth_mode == "none":
        return {}

    if auth_mode == "api_key":
        key = request.headers.get("x-api-key")
        if not key:
            raise _HTTPException(status_code=401, detail="Missing API key. Provide X-API-Key header.")
        hashed = _hash_key(key)
        stored_keys = aibrain_db.config_get("api_keys", [])
        valid = any(hmac.compare_digest(hashed, sk) for sk in stored_keys)
        if not valid:
            # Check legacy unsalted SHA-256 hashes and migrate
            for i, sk in enumerate(stored_keys):
                if _needs_rehash(sk, key):
                    stored_keys[i] = hashed
                    aibrain_db.config_set("api_keys", stored_keys)
                    valid = True
                    break
        if not valid:
            raise _HTTPException(status_code=403, detail="Invalid API key.")
        return {}

    if auth_mode == "jwt":
        auth_header = request.headers.get("authorization", "")
        if not auth_header.lower().startswith("bearer "):
            raise _HTTPException(
                status_code=401,
                detail="Missing or malformed Authorization header. Use: Bearer <token>",
            )
        token = auth_header[7:].strip()
        secret = aibrain_db.config_get("jwt_secret", "")
        payload = jwt_decode(token, secret) if secret else None
        if payload is None:
            raise _HTTPException(status_code=403, detail="Invalid or expired JWT token.")
        request.state.user = payload.get("sub", "anonymous")
        request.state.jwt_payload = payload
        return payload

    # Unknown mode — fail closed
    raise _HTTPException(
        status_code=500,
        detail=f"Unknown auth mode: {auth_mode}. Set auth_mode to none/api_key/jwt.",
    )


def set_api_key_role(db_module, key_hash_prefix: str, role: str) -> bool:
    """Set the role for an API key (identified by hash prefix)."""
    if role not in ROLES:
        raise ValueError(f"Invalid role: {role}. Must be one of {ROLES}")
    key_roles = db_module.config_get("api_key_roles", {})
    key_roles[key_hash_prefix] = role
    db_module.config_set("api_key_roles", key_roles)
    return True


def issue_jwt_with_role(db_module, subject: str, role: str = "user",
                        ttl: int = 86400) -> str:
    """Issue a JWT token with a role claim."""
    if role not in ROLES:
        raise ValueError(f"Invalid role: {role}. Must be one of {ROLES}")
    secret = db_module.config_get("jwt_secret")
    if not secret:
        secret = secrets.token_hex(32)
        db_module.config_set("jwt_secret", secret)
    return jwt_encode({"sub": subject, "role": role}, secret, ttl)
