"""
AIBrain Built-in Scheduler — runs workflows on cron schedules without external tools.
Uses APScheduler to execute workflow scripts based on scheduled_jobs.json.
"""

import json
import subprocess
import sys
import threading
from datetime import datetime
from pathlib import Path

import logging

from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger

logger = logging.getLogger(__name__)

# Will be initialized by init_scheduler()
_scheduler = None
_run_log = []  # Last 50 runs: [{job, time, exit_code, output_preview}]
_MAX_LOG = 50


def _parse_cron_expr(expr):
    """Parse '30 6 * * *' into APScheduler CronTrigger kwargs."""
    parts = expr.strip().split()
    if len(parts) != 5:
        return None
    return {
        "minute": parts[0],
        "hour": parts[1],
        "day": parts[2],
        "month": parts[3],
        "day_of_week": parts[4],
    }


def _run_workflow(job_name, script_path, aibrain_root, extra_args=None, timeout=120):
    """Execute a workflow script and log the result."""
    global _run_log
    start = datetime.now()
    try:
        cmd = [sys.executable, str(script_path)] + (extra_args or [])
        result = subprocess.run(
            cmd,
            capture_output=True, text=True, timeout=timeout,
            cwd=str(aibrain_root),
        )
        entry = {
            "job": job_name,
            "timestamp": start.isoformat(),
            "exit_code": result.returncode,
            "stdout_preview": (result.stdout or "")[-500:],
            "stderr_preview": (result.stderr or "")[-200:],
            "duration_ms": int((datetime.now() - start).total_seconds() * 1000),
        }
    except subprocess.TimeoutExpired:
        entry = {
            "job": job_name,
            "timestamp": start.isoformat(),
            "exit_code": -1,
            "stdout_preview": "",
            "stderr_preview": f"TIMEOUT after {timeout}s",
            "duration_ms": timeout * 1000,
        }
    except Exception as e:
        entry = {
            "job": job_name,
            "timestamp": start.isoformat(),
            "exit_code": -2,
            "stdout_preview": "",
            "stderr_preview": str(e),
            "duration_ms": int((datetime.now() - start).total_seconds() * 1000),
        }

    _run_log.append(entry)
    if len(_run_log) > _MAX_LOG:
        _run_log = _run_log[-_MAX_LOG:]

    # Log to trace system for observability dashboard
    try:
        from trace_logger import log_workflow_run
        log_workflow_run(
            workflow_id=job_name,
            status="ok" if entry["exit_code"] == 0 else "error",
            detail=entry.get("stderr_preview", "")[:500] or entry.get("stdout_preview", "")[:500],
            latency_ms=entry["duration_ms"],
        )
    except Exception as e:
        logger.warning("Failed to log workflow run for %s: %s", job_name, e)

    # Log to consolidated aibrain.db (same DB the API reads from)
    db = None
    try:
        import sqlite3
        consolidated_db = aibrain_root / "aibrain.db"
        db = sqlite3.connect(str(consolidated_db))
        db.execute("PRAGMA journal_mode=wal")
        db.execute(
            "CREATE TABLE IF NOT EXISTS activity (id INTEGER PRIMARY KEY AUTOINCREMENT, "
            "timestamp TEXT NOT NULL, agent TEXT NOT NULL DEFAULT 'agent', "
            "action TEXT NOT NULL, category TEXT DEFAULT 'general', "
            "detail TEXT DEFAULT '', status TEXT DEFAULT 'ok')"
        )
        db.execute(
            "INSERT INTO activity (timestamp, agent, action, category, detail, status) VALUES (?, ?, ?, ?, ?, ?)",
            (start.isoformat(), "scheduler", f"ran {job_name}", "workflow",
             f"exit={entry['exit_code']} duration={entry['duration_ms']}ms",
             "ok" if entry["exit_code"] == 0 else "error"),
        )
        # Update last_run on the scheduled_jobs row so the /api/agent/crons endpoint
        # reflects real execution state instead of staying frozen at the seed timestamp.
        db.execute(
            "UPDATE scheduled_jobs SET last_run=? WHERE name=?",
            (start.isoformat(), job_name),
        )
        db.commit()
    except Exception as e:
        logger.warning("Failed to log activity for %s to DB: %s", job_name, e)
    finally:
        if db:
            db.close()


def init_scheduler(aibrain_root: Path, cron_jobs_path: Path):
    """Start the background scheduler with jobs from scheduled_jobs.json."""
    global _scheduler

    if _scheduler and _scheduler.running:
        _scheduler.shutdown(wait=False)

    _scheduler = BackgroundScheduler(timezone="UTC")

    if cron_jobs_path.exists():
        try:
            data = json.loads(cron_jobs_path.read_text(encoding="utf-8"))
            workflows_dir = aibrain_root / "workflows"

            for job in data.get("jobs", []):
                if not job.get("enabled", True):
                    continue

                name = job["name"]
                cron_expr = job.get("cron", "")
                cron_kwargs = _parse_cron_expr(cron_expr)
                if not cron_kwargs:
                    continue

                # Prefer explicit script field, fall back to name.py
                script_field = job.get("script", f"workflows/{name}.py")
                # Handle args in script field (e.g. "workflows/foo.py --scan")
                script_parts = script_field.split()
                script = aibrain_root / script_parts[0]
                extra_args = script_parts[1:] if len(script_parts) > 1 else []

                # Path traversal check — script must be under workflows/
                resolved = script.resolve()
                workflows_dir = (aibrain_root / "workflows").resolve()
                if not str(resolved).startswith(str(workflows_dir)):
                    logger.warning("Blocked scheduled job %s: path traversal detected", name)
                    continue

                if not script.exists():
                    continue

                job_timeout = job.get("timeout", 120)

                _scheduler.add_job(
                    _run_workflow,
                    trigger=CronTrigger(**cron_kwargs),
                    args=[name, script, aibrain_root, extra_args, job_timeout],
                    id=name,
                    name=name,
                    replace_existing=True,
                    misfire_grace_time=300,
                )
        except (json.JSONDecodeError, OSError):
            pass

    _scheduler.start()
    return _scheduler


def reload_jobs(aibrain_root: Path, cron_jobs_path: Path):
    """Reload jobs from disk (called after enable/disable)."""
    global _scheduler
    if _scheduler and _scheduler.running:
        _scheduler.remove_all_jobs()
    return init_scheduler(aibrain_root, cron_jobs_path)


def get_scheduler_status():
    """Return scheduler state for the API."""
    if not _scheduler:
        return {"running": False, "job_count": 0, "jobs": [], "run_log": _run_log}

    jobs = []
    for job in _scheduler.get_jobs():
        next_run = job.next_run_time
        jobs.append({
            "id": job.id,
            "name": job.name,
            "next_run": next_run.isoformat() if next_run else None,
            "trigger": str(job.trigger),
        })

    return {
        "running": _scheduler.running,
        "job_count": len(jobs),
        "jobs": jobs,
        "run_log": _run_log[-20:],
    }


def get_or_create_scheduler() -> BackgroundScheduler:
    """Return the running scheduler, creating and starting one if needed.

    Used by components (e.g. buildit auto-improve) that need to add jobs even
    when no scheduled_jobs.json was found on startup.
    """
    global _scheduler
    if _scheduler and _scheduler.running:
        return _scheduler
    _scheduler = BackgroundScheduler(timezone="UTC")
    _scheduler.start()
    return _scheduler


def shutdown_scheduler():
    global _scheduler
    if _scheduler and _scheduler.running:
        _scheduler.shutdown(wait=False)
        _scheduler = None
