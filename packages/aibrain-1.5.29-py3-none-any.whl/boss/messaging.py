#!/usr/bin/env python3
"""
messaging.py — SQLite-backed persistent message store for the Boss Agent UI.

Replaces the previous in-memory pattern/channel messaging so that messages
survive across sessions and restarts.

Architecture:
  - BossMessageStore: single class backed by aibrain.db (boss_messages table).
  - One row per message. Reads filter by session_id.
  - Cleanup removes messages older than 24 hours for a given session.
  - No new dependencies — stdlib sqlite3 only.

Usage:
    from boss.messaging import BossMessageStore

    store = BossMessageStore()
    store.store(session_id, agent_id, role, content)
    messages = store.get_session(session_id)
    store.cleanup_session(session_id)          # manual 24h cleanup
    store.cleanup_old(max_age_hours=24)        # sweep all stale messages
"""

import logging
import secrets
import sqlite3
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Optional

log = logging.getLogger("boss.messaging")

# ---------------------------------------------------------------------------
# DB path resolution — follows the same pattern as aibrain/core/companies.py
# ---------------------------------------------------------------------------

def _resolve_db_path() -> Path:
    """Resolve aibrain.db using the same priority order as aibrain_db.py.

    Checks AIBRAIN_ROOT env var first, then the canonical dev layout, then
    the user-install layout. Never hardcodes a path.
    """
    import os

    env_root = os.environ.get("AIBRAIN_ROOT")
    if env_root:
        return Path(env_root) / "aibrain.db"

    # Try importing the canonical resolver — available when running inside aibrain
    try:
        from aibrain_db import AIBRAIN_ROOT  # type: ignore
        return AIBRAIN_ROOT / "aibrain.db"
    except ImportError:
        pass

    # Fallback: dev layout then user-install layout
    candidates = [
        Path.home() / "projects" / "aibrain" / "aibrain.db",
        Path.home() / "aibrain" / "aibrain.db",
    ]
    for c in candidates:
        if c.exists() and c.stat().st_size > 0:
            return c

    # Fresh install — use dev layout; DB will be created on first write
    return Path.home() / "projects" / "aibrain" / "aibrain.db"


# ---------------------------------------------------------------------------
# BossMessageStore
# ---------------------------------------------------------------------------

class BossMessageStore:
    """Persistent message store for boss-agent UI sessions.

    All messages are stored in the boss_messages table in aibrain.db.
    Message reads are always filtered by session_id so sessions remain isolated.

    Schema:
        boss_messages(
            id TEXT PRIMARY KEY,
            session_id TEXT NOT NULL,
            agent_id TEXT NOT NULL,
            role TEXT NOT NULL,          -- 'user' | 'assistant' | 'system'
            content TEXT NOT NULL,
            created_at TEXT NOT NULL     -- ISO-8601 UTC
        )
    """

    def __init__(self, db_path: Optional[str] = None):
        self.db_path = Path(db_path) if db_path else _resolve_db_path()
        self._ensure_table()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self.db_path))
        conn.row_factory = sqlite3.Row
        return conn

    def _ensure_table(self):
        """Create the boss_messages table and indexes if they don't exist."""
        with self._connect() as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS boss_messages (
                    id         TEXT PRIMARY KEY,
                    session_id TEXT NOT NULL,
                    agent_id   TEXT NOT NULL,
                    role       TEXT NOT NULL,
                    content    TEXT NOT NULL,
                    created_at TEXT NOT NULL
                )
            """)
            conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_bm_session_ts "
                "ON boss_messages(session_id, created_at)"
            )

    # ------------------------------------------------------------------
    # Write
    # ------------------------------------------------------------------

    def store(
        self,
        session_id: str,
        agent_id: str,
        role: str,
        content: str,
    ) -> str:
        """Insert a message and return its generated id.

        Args:
            session_id: Opaque session identifier (e.g. UUID or slug).
            agent_id:   ID of the agent sending the message.
            role:       'user' | 'assistant' | 'system'
            content:    Message text.

        Returns:
            The generated message id (hex string).
        """
        msg_id = f"bm-{secrets.token_hex(8)}"
        created_at = datetime.now(timezone.utc).isoformat()

        with self._connect() as conn:
            conn.execute(
                "INSERT INTO boss_messages (id, session_id, agent_id, role, content, created_at) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (msg_id, session_id, agent_id, role, content, created_at),
            )

        log.debug("stored message %s in session %s", msg_id, session_id)
        return msg_id

    # ------------------------------------------------------------------
    # Read
    # ------------------------------------------------------------------

    def get_session(self, session_id: str, limit: int = 500) -> list[dict]:
        """Return all messages for a session, ordered oldest-first.

        Args:
            session_id: The session to fetch.
            limit:      Max rows to return (default 500).

        Returns:
            List of message dicts with keys: id, session_id, agent_id, role,
            content, created_at.
        """
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT id, session_id, agent_id, role, content, created_at "
                "FROM boss_messages "
                "WHERE session_id = ? "
                "ORDER BY created_at ASC "
                "LIMIT ?",
                (session_id, limit),
            ).fetchall()

        return [dict(r) for r in rows]

    def get_message(self, msg_id: str) -> Optional[dict]:
        """Fetch a single message by id. Returns None if not found."""
        with self._connect() as conn:
            row = conn.execute(
                "SELECT id, session_id, agent_id, role, content, created_at "
                "FROM boss_messages WHERE id = ?",
                (msg_id,),
            ).fetchone()
        return dict(row) if row else None

    # ------------------------------------------------------------------
    # Cleanup
    # ------------------------------------------------------------------

    def cleanup_session(self, session_id: str, max_age_hours: int = 24) -> int:
        """Delete messages older than max_age_hours for a specific session.

        Args:
            session_id:    The session to clean up.
            max_age_hours: Messages older than this are deleted (default 24).

        Returns:
            Number of rows deleted.
        """
        cutoff = (datetime.now(timezone.utc) - timedelta(hours=max_age_hours)).isoformat()
        with self._connect() as conn:
            cur = conn.execute(
                "DELETE FROM boss_messages WHERE session_id = ? AND created_at < ?",
                (session_id, cutoff),
            )
            deleted = cur.rowcount

        if deleted:
            log.info("cleanup_session: removed %d messages from session %s", deleted, session_id)
        return deleted

    def cleanup_old(self, max_age_hours: int = 24) -> int:
        """Delete all messages older than max_age_hours across all sessions.

        Intended for periodic sweeps (e.g. called from a scheduled workflow).

        Args:
            max_age_hours: Messages older than this are deleted (default 24).

        Returns:
            Number of rows deleted.
        """
        cutoff = (datetime.now(timezone.utc) - timedelta(hours=max_age_hours)).isoformat()
        with self._connect() as conn:
            cur = conn.execute(
                "DELETE FROM boss_messages WHERE created_at < ?",
                (cutoff,),
            )
            deleted = cur.rowcount

        if deleted:
            log.info("cleanup_old: removed %d stale messages", deleted)
        return deleted
