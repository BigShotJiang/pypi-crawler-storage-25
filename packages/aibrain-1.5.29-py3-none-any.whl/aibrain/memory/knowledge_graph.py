"""
knowledge_graph.py — Temporal Knowledge Graph layer for AIBrain.

SQLite triple store with temporal validity windows (valid_from / valid_to),
confidence scoring, and source memory linkage.

Usage:
    from aibrain.memory.knowledge_graph import KnowledgeGraph

    kg = KnowledgeGraph()
    tid = kg.add_triple('AIBrain', 'uses', 'SQLite', confidence=0.9)
    results = kg.query(subject='AIBrain')
    history = kg.get_entity_history('AIBrain')
    kg.invalidate(tid)
"""

import logging
import re
import sqlite3
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# DDL — knowledge_triples table
# ---------------------------------------------------------------------------

_KG_DDL = """
CREATE TABLE IF NOT EXISTS knowledge_triples (
    id          TEXT PRIMARY KEY,
    subject     TEXT NOT NULL,
    predicate   TEXT NOT NULL,
    object      TEXT NOT NULL,
    valid_from  TEXT NOT NULL,
    valid_to    TEXT,
    confidence  REAL NOT NULL DEFAULT 1.0,
    source_memory_id TEXT REFERENCES memories(id) ON DELETE SET NULL,
    created_at  TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_kg_subject    ON knowledge_triples(subject);
CREATE INDEX IF NOT EXISTS idx_kg_predicate  ON knowledge_triples(predicate);
CREATE INDEX IF NOT EXISTS idx_kg_object     ON knowledge_triples(object);
CREATE INDEX IF NOT EXISTS idx_kg_valid_from ON knowledge_triples(valid_from);
CREATE INDEX IF NOT EXISTS idx_kg_source     ON knowledge_triples(source_memory_id);
"""

# ---------------------------------------------------------------------------
# Triple extractor — regex patterns, no LLM required
# ---------------------------------------------------------------------------

# Ordered list of (predicate_label, compiled_pattern) pairs.
# Each pattern captures (subject_group, object_group).
_TRIPLE_PATTERNS = [
    ("integrates with", re.compile(
        r'\b([A-Za-z][A-Za-z0-9\s_-]{1,60}?)\s+integrates\s+with\s+([A-Za-z][A-Za-z0-9\s_-]{1,60})',
        re.IGNORECASE,
    )),
    ("requires", re.compile(
        r'\b([A-Za-z][A-Za-z0-9\s_-]{1,60}?)\s+requires\s+([A-Za-z][A-Za-z0-9\s_-]{1,60})',
        re.IGNORECASE,
    )),
    ("supports", re.compile(
        r'\b([A-Za-z][A-Za-z0-9\s_-]{1,60}?)\s+supports\s+([A-Za-z][A-Za-z0-9\s_-]{1,60})',
        re.IGNORECASE,
    )),
    ("uses", re.compile(
        r'\b([A-Za-z][A-Za-z0-9\s_-]{1,60}?)\s+uses\s+([A-Za-z][A-Za-z0-9\s_-]{1,60})',
        re.IGNORECASE,
    )),
    ("has", re.compile(
        r'\b([A-Za-z][A-Za-z0-9\s_-]{1,60}?)\s+has\s+([A-Za-z][A-Za-z0-9\s_-]{1,60})',
        re.IGNORECASE,
    )),
    ("is", re.compile(
        r'\b([A-Za-z][A-Za-z0-9\s_-]{1,60}?)\s+is\s+([A-Za-z][A-Za-z0-9\s_-]{1,60})',
        re.IGNORECASE,
    )),
]

# Maximum token count for subject/object to avoid noise
_MAX_TOKENS = 6


def _extract_triples(content: str) -> list[tuple[str, str, str]]:
    """Extract (subject, predicate, object) triples from free text.

    Uses simple regex patterns — zero LLM calls. Correctness over completeness:
    triples are only emitted when both sides are short phrases (≤ _MAX_TOKENS words)
    to reduce noise.

    Args:
        content: Raw text to analyse.

    Returns:
        List of (subject, predicate, object) string tuples.
    """
    results: list[tuple[str, str, str]] = []
    seen: set[tuple[str, str, str]] = set()

    for predicate_label, pattern in _TRIPLE_PATTERNS:
        for match in pattern.finditer(content):
            subj = match.group(1).strip()
            obj = match.group(2).strip()

            # Strip trailing punctuation / conjunctions
            obj = re.split(r'[,;.()\n]', obj)[0].strip()
            subj = re.split(r'[,;.()\n]', subj)[0].strip()

            # Skip if too long (likely a sentence fragment, not a named entity)
            if len(subj.split()) > _MAX_TOKENS or len(obj.split()) > _MAX_TOKENS:
                continue
            # Skip very short / empty
            if len(subj) < 2 or len(obj) < 2:
                continue

            triple = (subj, predicate_label, obj)
            if triple not in seen:
                seen.add(triple)
                results.append(triple)

    return results


# ---------------------------------------------------------------------------
# KnowledgeGraph class
# ---------------------------------------------------------------------------


class KnowledgeGraph:
    """Temporal knowledge graph backed by SQLite.

    Stores subject–predicate–object triples with ISO8601 validity windows,
    confidence scores, and optional FK to source memories.

    The graph table is initialised on first use inside the same aibrain.db
    that all other AIBrain tables live in.
    """

    def __init__(self, db_path: Optional[str] = None):
        """Initialise KnowledgeGraph.

        Args:
            db_path: Path to SQLite database. If None, auto-discovers aibrain.db
                     via the standard aibrain_db module.
        """
        if db_path:
            self._conn = sqlite3.connect(str(db_path), check_same_thread=False)
            self._conn.row_factory = sqlite3.Row
        else:
            # Use the project-root aibrain_db singleton
            _project_root = Path(__file__).resolve().parent.parent.parent
            if str(_project_root) not in sys.path:
                sys.path.insert(0, str(_project_root))
            import aibrain_db
            self._conn = aibrain_db.get_db()

        self._ensure_table()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _ensure_table(self) -> None:
        """Create knowledge_triples table and indexes if not already present."""
        self._conn.executescript(_KG_DDL)
        self._conn.commit()

    @staticmethod
    def _now_iso() -> str:
        return datetime.now(timezone.utc).isoformat()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def add_triple(
        self,
        subject: str,
        predicate: str,
        object: str,
        valid_from: Optional[str] = None,
        valid_to: Optional[str] = None,
        confidence: float = 1.0,
        source_memory_id: Optional[str] = None,
    ) -> str:
        """Insert a new triple and return its generated ID.

        Args:
            subject: Entity or concept (e.g. "AIBrain").
            predicate: Relationship label (e.g. "uses").
            object: Target entity or value (e.g. "SQLite").
            valid_from: ISO8601 start of validity. Defaults to now.
            valid_to: ISO8601 end of validity. None = currently valid.
            confidence: Confidence score 0.0–1.0.
            source_memory_id: FK to the memories table row that sourced this triple.

        Returns:
            The triple's UUID string.
        """
        triple_id = str(uuid.uuid4())
        now = self._now_iso()
        if valid_from is None:
            valid_from = now

        self._conn.execute(
            """
            INSERT INTO knowledge_triples
                (id, subject, predicate, object, valid_from, valid_to,
                 confidence, source_memory_id, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (triple_id, subject, predicate, object, valid_from, valid_to,
             float(confidence), source_memory_id, now),
        )
        self._conn.commit()
        logger.debug("KG add_triple: %s —[%s]→ %s  id=%s", subject, predicate, object, triple_id)
        return triple_id

    def query(
        self,
        subject: Optional[str] = None,
        predicate: Optional[str] = None,
        object: Optional[str] = None,
        at_time: Optional[str] = None,
    ) -> list[dict]:
        """Query triples with optional filters.

        Args:
            subject: Filter by subject (exact match, case-insensitive).
            predicate: Filter by predicate (exact match, case-insensitive).
            object: Filter by object (exact match, case-insensitive).
            at_time: ISO8601 timestamp. If given, only returns triples where
                     valid_from <= at_time AND (valid_to IS NULL OR valid_to > at_time).

        Returns:
            List of triple dicts with keys: id, subject, predicate, object,
            valid_from, valid_to, confidence, source_memory_id, created_at.
        """
        clauses: list[str] = []
        params: list = []

        if subject is not None:
            clauses.append("LOWER(subject) = LOWER(?)")
            params.append(subject)
        if predicate is not None:
            clauses.append("LOWER(predicate) = LOWER(?)")
            params.append(predicate)
        if object is not None:
            clauses.append("LOWER(object) = LOWER(?)")
            params.append(object)
        if at_time is not None:
            clauses.append("valid_from <= ?")
            params.append(at_time)
            clauses.append("(valid_to IS NULL OR valid_to > ?)")
            params.append(at_time)

        sql = "SELECT * FROM knowledge_triples"
        if clauses:
            sql += " WHERE " + " AND ".join(clauses)
        sql += " ORDER BY created_at DESC"

        rows = self._conn.execute(sql, params).fetchall()
        return [dict(r) for r in rows]

    def get_entity_history(self, entity: str) -> list[dict]:
        """Return all triples where entity appears as subject OR object.

        Useful for tracing how knowledge about an entity has evolved over time.

        Args:
            entity: Entity name to look up (case-insensitive).

        Returns:
            List of triple dicts sorted by valid_from ascending.
        """
        rows = self._conn.execute(
            """
            SELECT * FROM knowledge_triples
            WHERE LOWER(subject) = LOWER(?) OR LOWER(object) = LOWER(?)
            ORDER BY valid_from ASC
            """,
            (entity, entity),
        ).fetchall()
        return [dict(r) for r in rows]

    def invalidate(
        self,
        triple_id: str,
        valid_to: Optional[str] = None,
    ) -> bool:
        """Mark a triple as no longer valid by setting valid_to.

        Args:
            triple_id: UUID of the triple to invalidate.
            valid_to: ISO8601 timestamp to set as end-of-validity.
                      Defaults to now.

        Returns:
            True if the triple was found and updated, False if not found.
        """
        if valid_to is None:
            valid_to = self._now_iso()

        cursor = self._conn.execute(
            "UPDATE knowledge_triples SET valid_to = ? WHERE id = ?",
            (valid_to, triple_id),
        )
        self._conn.commit()
        updated = cursor.rowcount > 0
        if not updated:
            logger.warning("KG invalidate: triple %s not found", triple_id)
        return updated

    # ------------------------------------------------------------------
    # Batch extraction helper — used by episodic integration
    # ------------------------------------------------------------------

    def extract_and_store(
        self,
        content: str,
        source_memory_id: Optional[str] = None,
        confidence: float = 0.7,
    ) -> list[str]:
        """Extract triples from text and persist them.

        Uses regex patterns only — no LLM calls. Confidence defaults to 0.7
        (lower than manually asserted triples) to reflect extraction uncertainty.

        Args:
            content: Free-text content to mine for triples.
            source_memory_id: FK to the memories row this content came from.
            confidence: Confidence to assign extracted triples (default 0.7).

        Returns:
            List of triple IDs that were stored.
        """
        triples = _extract_triples(content)
        ids = []
        for subj, pred, obj in triples:
            try:
                tid = self.add_triple(
                    subject=subj,
                    predicate=pred,
                    object=obj,
                    confidence=confidence,
                    source_memory_id=source_memory_id,
                )
                ids.append(tid)
            except Exception as exc:
                logger.debug("KG extract_and_store skip triple (%s,%s,%s): %s", subj, pred, obj, exc)
        return ids
