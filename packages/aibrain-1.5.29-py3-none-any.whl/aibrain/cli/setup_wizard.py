"""aibrain/cli/setup_wizard.py — honest, fail-fast, agent-friendly install.

Design principles:
  1. NEVER report success when prereqs failed. False-green is worse than fail.
  2. Always install Python packages via `sys.executable -m pip` — never bare `pip`.
  3. Always probe for Windows `.cmd`/`.exe` variants when looking for node/npm.
  4. Check Python version against the HARD requirement (3.10-3.14), not a soft warning.
  5. Fresh install creates COMPLETE schema including evolution_outcomes — no missing
     tables, no "doctor will fix it later."
  6. Batch mode (--yes) lets an agent install with zero interaction.
  7. Post-install always runs the 30-second demo so the user sees the gate catch a FAIL.
  8. Exit code reflects reality: 0 only if everything works.
"""
from __future__ import annotations
import os
import sys
import json
import argparse
import subprocess
import shutil
import platform
import sqlite3
import time
from pathlib import Path
from dataclasses import dataclass, field
from typing import Optional

# ─── Minimum supported versions ──────────────────────────────────
PYTHON_MIN = (3, 10)
PYTHON_MAX = (3, 14)  # Python 3.14 supported as of v1.5.24 — httptools wheels verified
REQUIRED_PIP_PACKAGES = ["fastapi", "uvicorn", "apscheduler", "requests", "pydantic"]
OPTIONAL_PIP_PACKAGES = ["sqlite-vec", "sentence-transformers"]

# ─── ANSI color (respects NO_COLOR and non-TTY) ──────────────────
_USE_COLOR = (
    sys.stdout.isatty()
    and not os.environ.get("NO_COLOR")
    and not os.environ.get("AIBRAIN_NO_COLOR")
)
def _c(code, text): return f"\033[{code}m{text}\033[0m" if _USE_COLOR else text
def _red(t): return _c("31", t)
def _green(t): return _c("32", t)
def _yellow(t): return _c("33", t)
def _blue(t): return _c("36", t)
def _dim(t): return _c("2", t)
def _bold(t): return _c("1", t)


@dataclass
class PrereqResult:
    ok: bool
    name: str
    detail: str = ""
    fix_hint: str = ""


@dataclass
class InstallReport:
    prereq_results: list = field(default_factory=list)
    packages_installed: list = field(default_factory=list)
    packages_failed: list = field(default_factory=list)
    db_created: bool = False
    schema_complete: bool = False
    config_written: bool = False
    errors: list = field(default_factory=list)
    warnings: list = field(default_factory=list)

    @property
    def success(self) -> bool:
        """Install is successful iff: all prereqs pass, no package failures,
        DB created with complete schema, config written, no errors."""
        return (
            all(r.ok for r in self.prereq_results)
            and not self.packages_failed
            and self.db_created
            and self.schema_complete
            and self.config_written
            and not self.errors
        )


# ─── Prerequisite checks ─────────────────────────────────────────

def _check_python_version() -> PrereqResult:
    cur = sys.version_info[:2]
    ver_str = f"{cur[0]}.{cur[1]}.{sys.version_info[2]}"
    if cur < PYTHON_MIN:
        return PrereqResult(
            False, "Python version",
            f"{ver_str} — need >= {PYTHON_MIN[0]}.{PYTHON_MIN[1]}",
            f"Install Python {PYTHON_MIN[0]}.{PYTHON_MIN[1]}+ from python.org",
        )
    if cur > PYTHON_MAX:
        return PrereqResult(
            False, "Python version",
            f"{ver_str} — too new, need <= {PYTHON_MAX[0]}.{PYTHON_MAX[1]}",
            f"Install Python {PYTHON_MAX[0]}.{PYTHON_MAX[1]}. "
            f"Python {cur[0]}.{cur[1]} is not yet supported (wheel compatibility).",
        )
    return PrereqResult(True, "Python version", ver_str)


def _find_executable(name: str) -> Optional[str]:
    """Find an executable, trying platform-specific extensions on Windows.

    This is the fix for the 'npm not found' bug — on Windows, npm is `npm.cmd`,
    node is `node.exe`, etc. A plain shutil.which('npm') misses npm.cmd.
    """
    candidates = [name]
    if platform.system() == "Windows":
        candidates = [f"{name}.cmd", f"{name}.exe", f"{name}.bat", name]
    for cand in candidates:
        found = shutil.which(cand)
        if found:
            return found
    return None


def _check_node() -> PrereqResult:
    path = _find_executable("node")
    if not path:
        return PrereqResult(
            False, "Node.js",
            "not found on PATH",
            "Install Node.js LTS from nodejs.org. Needed for the dashboard.",
        )
    try:
        r = subprocess.run([path, "--version"], capture_output=True, text=True,
                           timeout=10, check=False)
        if r.returncode == 0:
            return PrereqResult(True, "Node.js", r.stdout.strip())
    except Exception as exc:
        return PrereqResult(False, "Node.js", f"found but failed: {exc}",
                            "Reinstall Node.js from nodejs.org")
    return PrereqResult(False, "Node.js", "version check failed")


def _check_npm() -> PrereqResult:
    """THE fix for the npm PATH bug — use _find_executable which tries .cmd."""
    path = _find_executable("npm")
    if not path:
        return PrereqResult(
            False, "npm",
            "not found on PATH (usually ships with Node.js)",
            "Reinstall Node.js; npm should install automatically. "
            "On Windows, npm lives at npm.cmd — reopen your terminal after install.",
        )
    try:
        r = subprocess.run([path, "--version"], capture_output=True, text=True,
                           timeout=10, check=False)
        if r.returncode == 0:
            return PrereqResult(True, "npm", r.stdout.strip())
    except Exception as exc:
        return PrereqResult(False, "npm", f"found but failed: {exc}")
    return PrereqResult(False, "npm", "version check failed")


def _check_pip_package(pkg: str) -> PrereqResult:
    """Check if a Python package is importable."""
    # Map pypi name to import name where they differ
    import_name = {
        "sentence-transformers": "sentence_transformers",
        "sqlite-vec": "sqlite_vec",
    }.get(pkg, pkg.replace("-", "_"))
    try:
        __import__(import_name)
        return PrereqResult(True, f"py: {pkg}", "installed")
    except ImportError:
        return PrereqResult(False, f"py: {pkg}", "not installed",
                            f"Install with: {sys.executable} -m pip install {pkg}")


def _install_packages(packages: list, verbose: bool = True) -> tuple[list, list]:
    """Install packages via `sys.executable -m pip`. Returns (installed, failed).

    THE fix for the pip [WinError 2] bug — NEVER call bare `pip`. Always
    `sys.executable -m pip` which works regardless of PATH.
    """
    if not packages:
        return [], []
    installed, failed = [], []
    # Single pip call so dependency resolution is coherent
    cmd = [sys.executable, "-m", "pip", "install", "--upgrade", *packages]
    if verbose:
        print(_dim(f"    Running: {' '.join(cmd)}"))
    try:
        r = subprocess.run(cmd, capture_output=True, text=True,
                           timeout=600, check=False)
        if r.returncode == 0:
            installed.extend(packages)
            if verbose:
                # Show only the "Successfully installed" line, not the full 500-line log
                for line in r.stdout.splitlines():
                    if line.startswith("Successfully installed"):
                        print(_green(f"    {line}"))
                        break
        else:
            failed.extend(packages)
            if verbose:
                # Show the last 10 lines of stderr — that's where the real error is
                err_tail = "\n".join(r.stderr.splitlines()[-10:])
                print(_red(f"    pip install failed (exit {r.returncode}):"))
                print(_dim(f"    {err_tail}"))
    except subprocess.TimeoutExpired:
        failed.extend(packages)
        if verbose:
            print(_red("    pip install timed out after 10 minutes"))
    except Exception as exc:
        failed.extend(packages)
        if verbose:
            print(_red(f"    pip install errored: {exc}"))
    return installed, failed


# ─── Schema ──────────────────────────────────────────────────────

_SCHEMA_SQL = """
-- Core memory tables
CREATE TABLE IF NOT EXISTS memories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    content TEXT NOT NULL,
    type TEXT DEFAULT 'general',
    importance REAL DEFAULT 0.5,
    created TEXT DEFAULT (datetime('now')),
    updated TEXT DEFAULT (datetime('now')),
    verified_at TEXT,
    claim_type TEXT DEFAULT 'assertion',
    plan_deadline TEXT,
    base_confidence REAL DEFAULT 0.7,
    metadata TEXT
);
CREATE INDEX IF NOT EXISTS idx_memories_type ON memories(type);
CREATE INDEX IF NOT EXISTS idx_memories_created ON memories(created);

-- Execution + learning (the signal chain)
CREATE TABLE IF NOT EXISTS execution_log (
    run_id TEXT PRIMARY KEY,
    actor TEXT NOT NULL,
    task TEXT,
    success INTEGER,
    quality_score REAL,
    cost_cents INTEGER,
    model_used TEXT,
    entity_id TEXT,
    source TEXT,
    created_at TEXT DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_execlog_actor ON execution_log(actor);
CREATE INDEX IF NOT EXISTS idx_execlog_entity ON execution_log(entity_id);

-- THIS was the missing table in the broken setup
CREATE TABLE IF NOT EXISTS evolution_outcomes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id TEXT,
    task TEXT,
    outcome TEXT,
    quality_score REAL,
    divergence REAL,
    created_at TEXT DEFAULT (datetime('now')),
    metadata TEXT
);
CREATE INDEX IF NOT EXISTS idx_evo_run ON evolution_outcomes(run_id);

-- Workflow tracking
CREATE TABLE IF NOT EXISTS workflow_runs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    workflow_name TEXT NOT NULL,
    actor TEXT,
    started_at TEXT DEFAULT (datetime('now')),
    completed_at TEXT,
    status TEXT DEFAULT 'running',
    result TEXT
);
CREATE INDEX IF NOT EXISTS idx_wfr_name ON workflow_runs(workflow_name);

-- Event bus
CREATE TABLE IF NOT EXISTS pattern_bus_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    event_type TEXT NOT NULL,
    payload TEXT,
    created_at TEXT DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_pbe_type ON pattern_bus_events(event_type);

-- Company / agents / tasks (for Pro tier — free tier doesn't use but schema consistent)
CREATE TABLE IF NOT EXISTS companies (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    mission TEXT,
    created_at TEXT DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS agents (
    id TEXT PRIMARY KEY,
    company_id TEXT,
    name TEXT NOT NULL,
    role TEXT DEFAULT 'general',
    title TEXT,
    model TEXT DEFAULT 'auto',
    status TEXT DEFAULT 'active',
    capabilities TEXT,
    created_at TEXT DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS company_issues (
    id TEXT PRIMARY KEY,
    company_id TEXT,
    title TEXT NOT NULL,
    description TEXT,
    priority TEXT DEFAULT 'medium',
    status TEXT DEFAULT 'todo',
    assignee_agent_id TEXT,
    review_required INTEGER DEFAULT 0,
    work_output TEXT,
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now')),
    started_at TEXT,
    completed_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_ci_status ON company_issues(status);
CREATE INDEX IF NOT EXISTS idx_ci_assignee ON company_issues(assignee_agent_id);

-- Schema version marker
CREATE TABLE IF NOT EXISTS schema_version (
    version INTEGER PRIMARY KEY,
    applied_at TEXT DEFAULT (datetime('now'))
);
INSERT OR IGNORE INTO schema_version (version) VALUES (1);
"""

REQUIRED_TABLES = [
    "memories", "execution_log", "evolution_outcomes", "workflow_runs",
    "pattern_bus_events", "companies", "agents", "company_issues", "schema_version",
]


def _create_schema(db_path: Path) -> tuple[bool, str]:
    """Create the complete schema on a fresh or existing DB. Idempotent."""
    try:
        db_path.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(str(db_path))
        conn.executescript(_SCHEMA_SQL)
        conn.commit()
        # Verify every required table now exists
        rows = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        ).fetchall()
        existing = {r[0] for r in rows}
        missing = [t for t in REQUIRED_TABLES if t not in existing]
        conn.close()
        if missing:
            return False, f"tables missing after creation: {missing}"
        return True, "all required tables present"
    except Exception as exc:
        return False, f"schema creation failed: {exc}"


def _verify_schema(db_path: Path) -> tuple[bool, str]:
    """Verify the schema is complete. Used after creation AND on later invocations."""
    if not db_path.exists():
        return False, "db file does not exist"
    try:
        conn = sqlite3.connect(str(db_path))
        rows = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        ).fetchall()
        existing = {r[0] for r in rows}
        conn.close()
        missing = [t for t in REQUIRED_TABLES if t not in existing]
        if missing:
            return False, f"missing tables: {missing}"
        return True, "schema OK"
    except Exception as exc:
        return False, f"verification failed: {exc}"


# ─── Config ──────────────────────────────────────────────────────

def _write_config(root: Path, agent_name: str, location: Optional[dict],
                  llm_provider: str = "", api_key: str = "") -> bool:
    """Write config.json. Returns True on success."""
    try:
        # Gap 1 — version from importlib.metadata, not hardcoded
        try:
            from importlib.metadata import version as _pkg_version
            _ver = _pkg_version("aibrain")
        except Exception:
            _ver = "unknown"

        config = {
            "agent_name": agent_name,
            "data_dir": str(root),
            "db_path": str(root / "aibrain.db"),
            "version": _ver,
            "created_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        }
        if location:
            config["location"] = location

        # Gap 3 — persist LLM provider + key
        config["llm_provider"] = llm_provider
        if api_key:
            key_field = "anthropic_api_key" if llm_provider == "anthropic" else "openai_api_key"
            config[key_field] = api_key
            # Also persist to .aibrain_config.json (read by LLM layer)
            llm_cfg_path = root / ".aibrain_config.json"
            try:
                existing = json.loads(llm_cfg_path.read_text()) if llm_cfg_path.exists() else {}
                existing["llm_provider"] = llm_provider
                existing[key_field] = api_key
                llm_cfg_path.write_text(json.dumps(existing, indent=2))
            except Exception:
                pass

        (root / "config.json").write_text(json.dumps(config, indent=2))
        # Write scheduled_jobs.json stub (empty enabled list — user can turn on later)
        if not (root / "scheduled_jobs.json").exists():
            (root / "scheduled_jobs.json").write_text(json.dumps({
                "_description": "Scheduled workflows. Enable individually as needed.",
                "jobs": [],
            }, indent=2))
        return True
    except Exception:
        return False


# ─── Main flow ───────────────────────────────────────────────────

def _banner():
    print()
    print(_bold("  AIBrain Setup"))
    print(_dim("  " + "─" * 50))
    print()


def _print_prereq(r: PrereqResult):
    mark = _green("  ✓") if r.ok else _red("  ✗")
    name = r.name.ljust(18)
    print(f"{mark} {name} {_dim(r.detail)}")
    if not r.ok and r.fix_hint:
        print(_dim(f"    → {r.fix_hint}"))


def _ask(prompt: str, default: str = "", auto_yes: bool = False) -> str:
    """Prompt user, or return default in batch mode."""
    if auto_yes:
        print(f"  {prompt} {_dim('[auto: ' + (default or 'yes') + ']')}")
        return default or "yes"
    suffix = f" [{default}]" if default else ""
    resp = input(f"  {prompt}{suffix}: ").strip()
    return resp or default


def _yn(prompt: str, default_yes: bool = True, auto_yes: bool = False) -> bool:
    if auto_yes:
        print(f"  {prompt} {_dim('[auto: yes]')}")
        return True
    default = "Y/n" if default_yes else "y/N"
    resp = input(f"  {prompt} [{default}]: ").strip().lower()
    if not resp:
        return default_yes
    return resp.startswith("y")


def run_setup(root: Path, agent_name: Optional[str] = None,
              location: Optional[dict] = None,
              auto_yes: bool = False,
              skip_demo: bool = False) -> InstallReport:
    """Run setup. Returns InstallReport. Exit code is caller's responsibility."""
    report = InstallReport()
    _banner()

    # ── Step 1: Prereqs ────────────────────────────────────────
    print(_bold("  [1/4] Checking prerequisites"))
    print()
    for check in [_check_python_version, _check_node, _check_npm]:
        r = check()
        report.prereq_results.append(r)
        _print_prereq(r)

    missing_py = []
    for pkg in REQUIRED_PIP_PACKAGES:
        r = _check_pip_package(pkg)
        report.prereq_results.append(r)
        _print_prereq(r)
        if not r.ok:
            missing_py.append(pkg)

    print()

    # Fail fast on Python version — no point continuing
    py_check = report.prereq_results[0]
    if not py_check.ok:
        print(_red("  ✗ Python version check failed — cannot continue."))
        print(_dim(f"    {py_check.fix_hint}"))
        report.errors.append(f"python_version: {py_check.detail}")
        return report

    # ── Step 2: Install missing Python packages ───────────────
    if missing_py:
        print(_bold("  [2/4] Installing Python packages"))
        print()
        proceed = _yn(f"Install {len(missing_py)} missing packages now?",
                      default_yes=True, auto_yes=auto_yes)
        if proceed:
            installed, failed = _install_packages(missing_py, verbose=True)
            report.packages_installed = installed
            report.packages_failed = failed
            if failed:
                print()
                print(_red(f"  ✗ {len(failed)} package(s) failed to install: {failed}"))
                print(_dim(f"    Try: {sys.executable} -m pip install {' '.join(failed)}"))
                print(_dim("    If that fails, your Python version may lack wheels."))
                report.errors.append(f"package_install_failed: {failed}")
                return report
            else:
                print(_green(f"  ✓ Installed {len(installed)} package(s)"))
        else:
            print(_yellow("  ⊘ Skipped package install. Setup cannot continue without them."))
            report.errors.append("packages_required_but_not_installed")
            return report
    else:
        print(_bold("  [2/4] Python packages"))
        print(_green("  ✓ All required packages already installed"))

    print()

    # ── Step 3: Create DB + schema + config ───────────────────
    print(_bold("  [3/4] Initializing data directory"))
    print()
    print(_dim(f"  Data dir: {root}"))

    if agent_name is None:
        agent_name = _ask("Agent name", default="Agent", auto_yes=auto_yes)
    print(_green(f"  ✓ Agent: {agent_name}"))

    db_path = root / "aibrain.db"
    schema_ok, schema_msg = _create_schema(db_path)
    if not schema_ok:
        print(_red(f"  ✗ Schema creation failed: {schema_msg}"))
        report.errors.append(f"schema: {schema_msg}")
        return report
    report.db_created = True

    # Verify — don't trust the creation step blindly
    verify_ok, verify_msg = _verify_schema(db_path)
    if not verify_ok:
        print(_red(f"  ✗ Schema verification failed: {verify_msg}"))
        report.errors.append(f"schema_verify: {verify_msg}")
        return report
    report.schema_complete = True
    print(_green(f"  ✓ Database initialized ({db_path.stat().st_size // 1024}KB)"))
    print(_green(f"  ✓ Schema: {len(REQUIRED_TABLES)} tables present"))

    # Gap 2 — AIBRAIN_SIGNING_KEY auto-gen
    import secrets as _secrets
    _signing_key = os.environ.get("AIBRAIN_SIGNING_KEY", "")
    if not _signing_key:
        _env_file = Path.home() / ".aibrain.env"
        if _env_file.exists():
            for _line in _env_file.read_text(encoding="utf-8").splitlines():
                if _line.startswith("AIBRAIN_SIGNING_KEY="):
                    _signing_key = _line.split("=", 1)[1].strip()
        if not _signing_key:
            _signing_key = _secrets.token_hex(32)
            with open(_env_file, "a", encoding="utf-8") as _f:
                _f.write(f"\nAIBRAIN_SIGNING_KEY={_signing_key}\n")
            print(_green("  ✓ AIBRAIN_SIGNING_KEY generated"))
    os.environ["AIBRAIN_SIGNING_KEY"] = _signing_key

    # Gap 3 — LLM provider detection
    _anthropic_key = os.environ.get("ANTHROPIC_API_KEY", "")
    _openai_key = os.environ.get("OPENAI_API_KEY", "")
    _ollama = False
    try:
        import urllib.request as _ur
        _ur.urlopen("http://localhost:11434", timeout=1).close()
        _ollama = True
    except Exception:
        pass
    _llm_provider = "anthropic" if _anthropic_key else ("openai" if _openai_key else ("ollama" if _ollama else "none"))
    _api_key = _anthropic_key or _openai_key or ""

    if _write_config(root, agent_name, location, llm_provider=_llm_provider, api_key=_api_key):
        report.config_written = True
        print(_green("  ✓ Config written"))
    else:
        print(_red("  ✗ Failed to write config.json"))
        report.errors.append("config_write_failed")
        return report

    # Gap 4 — .aibrainrc
    try:
        (Path.home() / ".aibrainrc").write_text(str(root), encoding="utf-8")
    except OSError:
        pass

    print()

    # ── Step 4: Post-install sequence ────────────────────────────────
    _post_install_sequence(root, auto_yes=auto_yes, skip_demo=skip_demo)

    return report


def _post_install_sequence(root: Path, auto_yes: bool, skip_demo: bool) -> None:
    """Ordered post-install moments.

    1. Orientation — show files created
    2. Scripted 30-sec demo (explains the gate)
    3. Offer dashboard (shows the running product)
    4. Tell them about `aibrain review` and `aibrain explore`
    """
    print(_bold("  [4/4] Setup complete"))
    print()
    print(_dim("  Files created:"))
    print(_dim(f"    {root / 'config.json'}"))
    print(_dim(f"    {root / 'aibrain.db'}"))
    print(_dim(f"    {root / 'scheduled_jobs.json'}"))
    print()

    # ── Demo (the explainer) ────────────────────────────────
    if not skip_demo:
        run_demo_now = _yn(
            "See how the review gate works? (30 seconds, scripted)",
            default_yes=True, auto_yes=auto_yes,
        )
        if run_demo_now:
            print()
            try:
                from aibrain.cli.demo import run_demo
                run_demo()
            except ImportError:
                print(_dim("  (demo module not installed — skipping)"))
            except Exception as exc:
                print(_dim(f"  (demo error: {exc} — skipping)"))

    # ── Dashboard offer ─────────────────────────────────────
    # In --yes (agent) mode: print URL, don't launch browser.
    # In interactive mode: offer.
    if auto_yes:
        print()
        print(_dim("  To open the dashboard later:  aibrain up"))
    else:
        print()
        open_dash = _yn(
            "Start the dashboard and open it in your browser?",
            default_yes=True, auto_yes=False,
        )
        if open_dash:
            print()
            try:
                from aibrain.cli.dashboard_launcher import launch_dashboard
                launch_dashboard(
                    data_dir=root,
                    auto_open_browser=True,
                    start_backend=True,
                    quiet=False,
                )
            except ImportError:
                print(_dim("  (dashboard launcher not available — skipping)"))
            except Exception as exc:
                print(_dim(f"  (dashboard launcher error: {exc} — skipping)"))

    # ── Windows PATH guidance — warn BEFORE pointing users at `aibrain` commands ──
    # Windows Store / pymanager Python installs often leave the Scripts dir off
    # PATH. If so, `aibrain` won't resolve in a new shell; `python -m aibrain`
    # always works regardless of PATH.
    if sys.platform == "win32":
        import sysconfig as _sysconfig
        scripts_dir = _sysconfig.get_path("scripts")
        path_dirs = os.environ.get("PATH", "").split(os.pathsep)
        def norm(p):
            return os.path.normcase(os.path.normpath(p))
        if not any(norm(p) == norm(scripts_dir) for p in path_dirs):
            print()
            print(_bold("  [NOTE] Scripts directory is not on PATH:"))
            print(f"    {scripts_dir}")
            print("  If `aibrain` command is not found in a new shell, either:")
            print("    1) Add the directory above to your user PATH, OR")
            print("    2) Use `python -m aibrain` instead of `aibrain`")
            print()

    # ── What next ───────────────────────────────────────────
    print()
    print(_bold("  What next:"))
    print()
    print(f"    {_bold('aibrain review')}  {_dim('<< my.diff')}")
    print(f"       {_dim('Real Liaison review on your code. ~$0.02 per review.')}")
    print()
    print(f"    {_bold('aibrain explore')}")
    print(f"       {_dim('Browse everything AIBrain can do — pick what to try.')}")
    print()
    print(f"    {_bold('aibrain up')}")
    print(f"       {_dim('Start the dashboard if you skipped it above.')}")
    print()


def main(argv=None):
    parser = argparse.ArgumentParser(
        description="AIBrain setup — initialize a fresh install.",
        epilog="For agent-driven install: aibrain setup --yes --agent-name MyAgent",
    )
    parser.add_argument("--yes", "-y", action="store_true",
                        help="Batch mode: accept all defaults, no prompts (for agents)")
    parser.add_argument("--agent-name", default=None,
                        help="Agent name (default: prompt or 'Agent')")
    parser.add_argument("--location", default=None,
                        help="Optional location (city name)")
    parser.add_argument("--root", default=None,
                        help="Data directory (default: ~/aibrain)")
    parser.add_argument("--skip-demo", action="store_true",
                        help="Skip the post-install 30-second demo")
    args = parser.parse_args(argv)

    root = Path(args.root) if args.root else Path.home() / "aibrain"
    root.mkdir(parents=True, exist_ok=True)

    report = run_setup(
        root=root,
        agent_name=args.agent_name,
        location={"name": args.location} if args.location else None,
        auto_yes=args.yes,
        skip_demo=args.skip_demo,
    )

    print()
    if report.success:
        print(_green(_bold("  ✓ AIBrain is ready.")))
        print()
        print(f"  Next:  {_bold('aibrain demo')}     {_dim('# see the review gate catch a FAIL')}")
        print(f"         {_bold('aibrain run heartbeat')}  {_dim('# first real workflow')}")
        print(f"         {_bold('aibrain docs')}     {_dim('# learn more')}")
        print()
        return 0
    else:
        print(_red(_bold("  ✗ Setup did NOT complete successfully.")))
        print()
        if report.errors:
            print(_dim("  Errors:"))
            for err in report.errors:
                print(_dim(f"    - {err}"))
        if report.packages_failed:
            print(_dim("  Retry package install:"))
            print(_dim(f"    {sys.executable} -m pip install {' '.join(report.packages_failed)}"))
        print()
        print(_dim("  Re-run:  aibrain setup"))
        print()
        return 1


if __name__ == "__main__":
    sys.exit(main())
