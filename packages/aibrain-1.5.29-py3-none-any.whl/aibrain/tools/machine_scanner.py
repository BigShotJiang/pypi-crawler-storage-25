"""
AIBrain Machine Scanner — lightweight project discovery for onboarding.

Scans common directories for importable projects (git repos, VS Code
workspaces, Obsidian vaults, markdown folders). Returns a JSON-safe list
sorted by recently modified, capped at 20 results.

Usage:
    from aibrain.tools.machine_scanner import scan_machine
    results = scan_machine()
    # [{"path": "...", "type": "git_repo", "name": "...", "size_kb": 42, "modified": "..."}]
"""

from datetime import datetime
from pathlib import Path

# Directories to scan (relative to home)
_SEARCH_DIRS = [
    "projects",
    "code",
    "dev",
    "Documents",
    "Desktop",
    "src",
    "workspace",
    "repos",
]

# Directories to skip unconditionally
_SKIP_DIRS = {
    "node_modules", "__pycache__", ".venv", "venv", "env",
    ".next", ".nuxt", "dist", "build", ".cache", ".tox",
    ".mypy_cache", ".pytest_cache", ".ruff_cache", "coverage",
    ".idea", ".DS_Store", "vendor", "target", "tmp", "temp",
}

# Max depth below each search root when hunting for projects
_MAX_DEPTH = 3
# How many results to return
_MAX_RESULTS = 20


def _classify_dir(path: Path) -> str | None:
    """Return the project type string, or None if the directory is not interesting."""
    entries = set()
    try:
        entries = {e.name for e in path.iterdir()}
    except PermissionError:
        return None

    if ".git" in entries:
        return "git_repo"

    # VS Code workspace: contains .vscode/ or a *.code-workspace file
    if ".vscode" in entries or any(e.endswith(".code-workspace") for e in entries):
        return "vscode_workspace"

    # Obsidian vault: contains .obsidian/
    if ".obsidian" in entries:
        return "obsidian_vault"

    # Markdown folder: >3 .md files at top level
    md_count = sum(1 for e in entries if e.endswith(".md"))
    if md_count >= 3:
        return "markdown_folder"

    # Generic project: has a known project root file
    _PROJECT_FILES = {
        "package.json", "setup.py", "pyproject.toml", "requirements.txt",
        "Cargo.toml", "go.mod", "Gemfile", "pom.xml", "Makefile",
        "docker-compose.yml", "docker-compose.yaml",
    }
    if entries & _PROJECT_FILES:
        return "project"

    return None


def _dir_size_kb(path: Path) -> int:
    """Rough size estimate: sum of all top-level file sizes in KB."""
    total = 0
    try:
        for entry in path.iterdir():
            if entry.is_file():
                try:
                    total += entry.stat().st_size
                except OSError:
                    pass
    except PermissionError:
        pass
    return max(1, total // 1024)


def _mtime(path: Path) -> float:
    """Return mtime float for sorting (0 on error)."""
    try:
        return path.stat().st_mtime
    except OSError:
        return 0.0


def scan_machine(
    extra_dirs: list[str] | None = None,
    max_results: int = _MAX_RESULTS,
) -> list[dict]:
    """
    Scan common directories on the user's machine for importable projects.

    Args:
        extra_dirs: Additional absolute paths to scan beyond the defaults.
        max_results: Cap on returned results (default 20).

    Returns:
        List of dicts: [{path, type, name, size_kb, modified}], sorted
        descending by modification time.
    """
    home = Path.home()
    roots: list[Path] = []

    for rel in _SEARCH_DIRS:
        candidate = home / rel
        if candidate.is_dir():
            roots.append(candidate)

    for extra in (extra_dirs or []):
        p = Path(extra)
        if p.is_dir():
            roots.append(p)

    found: list[dict] = []
    seen: set[str] = set()

    def _walk(path: Path, depth: int):
        if depth > _MAX_DEPTH:
            return
        try:
            subdirs = [e for e in path.iterdir() if e.is_dir() and e.name not in _SKIP_DIRS and not e.name.startswith(".")]
        except PermissionError:
            return

        for sub in subdirs:
            key = str(sub.resolve())
            if key in seen:
                continue
            seen.add(key)

            ptype = _classify_dir(sub)
            if ptype:
                found.append({
                    "path": key,
                    "type": ptype,
                    "name": sub.name,
                    "size_kb": _dir_size_kb(sub),
                    "modified": datetime.fromtimestamp(_mtime(sub)).isoformat(),
                    "_mtime": _mtime(sub),
                })
                # Don't recurse into detected project dirs (avoids double-listing)
                continue

            # Recurse one level deeper looking for nested projects
            if depth < _MAX_DEPTH:
                _walk(sub, depth + 1)

    for root in roots:
        _walk(root, 1)

    # Sort by most recently modified, cap results
    found.sort(key=lambda r: r["_mtime"], reverse=True)
    for r in found:
        del r["_mtime"]

    return found[:max_results]


if __name__ == "__main__":
    import json
    results = scan_machine()
    print(json.dumps(results, indent=2))
