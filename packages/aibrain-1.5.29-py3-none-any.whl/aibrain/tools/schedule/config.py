"""
aibrain.tools.schedule.config — Interactive scheduled jobs configuration menu.

Reads the scheduled_jobs table and lets the user toggle jobs enabled/disabled.

Entry point: interactive_menu()
"""
from __future__ import annotations

import sqlite3
import sys
from typing import Dict, List

from aibrain.cli.utils import _getch


# ---------------------------------------------------------------------------
# Data loading
# ---------------------------------------------------------------------------

def _resolve_db_path() -> str:
    """Resolve the aibrain.db path via the canonical resolver — see aibrain_db.AIBRAIN_ROOT."""
    from aibrain_db import AIBRAIN_ROOT
    return str(AIBRAIN_ROOT / "aibrain.db")


def _load_jobs(db_path: str) -> List[Dict]:
    """Load all scheduled jobs."""
    conn = sqlite3.connect(db_path, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    try:
        rows = conn.execute(
            "SELECT id, name, cron, prompt, enabled, notes FROM scheduled_jobs ORDER BY name"
        ).fetchall()
    except sqlite3.OperationalError:
        conn.close()
        return []
    conn.close()
    return [dict(r) for r in rows]


def _save_job_status(db_path: str, job_id: int, enabled: bool) -> None:
    """Toggle a job's enabled status."""
    conn = sqlite3.connect(db_path, check_same_thread=False)
    conn.execute(
        "UPDATE scheduled_jobs SET enabled=? WHERE id=?",
        (1 if enabled else 0, job_id)
    )
    conn.commit()
    conn.close()


# ---------------------------------------------------------------------------
# Status helpers (for settings_menu.py)
# ---------------------------------------------------------------------------

def get_schedule_status() -> str:
    """Return a brief status string like '35/49 enabled'."""
    try:
        db_path = _resolve_db_path()
        jobs = _load_jobs(db_path)
        if not jobs:
            return 'no jobs'
        enabled = sum(1 for j in jobs if j.get("enabled"))
        return f'{enabled}/{len(jobs)} enabled'
    except Exception:
        return 'unavailable'


# ---------------------------------------------------------------------------
# Rendering
# ---------------------------------------------------------------------------

PAGE_SIZE = 12


def _render_menu(jobs: List[Dict], states: Dict[int, bool],
                 focused: int, page: int) -> str:
    start = page * PAGE_SIZE
    page_jobs = jobs[start:start + PAGE_SIZE]
    total_pages = max(1, (len(jobs) + PAGE_SIZE - 1) // PAGE_SIZE)
    enabled_count = sum(1 for v in states.values() if v)

    lines = [
        '',
        '  Schedule Config  (SPACE/number to toggle, P next page, ENTER save, Q quit)',
        '',
        f'  {enabled_count}/{len(jobs)} jobs enabled',
        '',
    ]

    for i, job in enumerate(page_jobs):
        marker = 'x' if states[job["id"]] else ' '
        cursor = '>' if i == focused else ' '
        name = job.get("name", "?")
        cron = job.get("cron", "")
        num = i + 1 if i < 9 else 0
        lines.append(f'  {cursor} [{marker}] {num}. {name:<30s} {cron}')

    if total_pages > 1:
        lines.append('')
        lines.append(f'  Page {page + 1}/{total_pages}  [P] next page')

    lines.append('')
    lines.append('  ENTER to save  |  Q to quit without saving')
    lines.append('')
    return '\n'.join(lines)


# ---------------------------------------------------------------------------
# Interactive menu
# ---------------------------------------------------------------------------

def interactive_menu() -> None:
    """Launch the interactive schedule configuration menu."""
    db_path = _resolve_db_path()
    jobs = _load_jobs(db_path)

    if not jobs:
        print('No scheduled jobs found.')
        return

    # Non-tty fallback
    if not sys.stdout.isatty():
        for j in jobs:
            status = "enabled" if j.get("enabled") else "disabled"
            print(f'{j["name"]}={status} [{j.get("cron", "")}]')
        return

    # Build states
    states: Dict[int, bool] = {}
    original: Dict[int, bool] = {}
    for j in jobs:
        enabled = bool(j.get("enabled", 0))
        states[j["id"]] = enabled
        original[j["id"]] = enabled

    focused = 0
    page = 0

    menu_text = _render_menu(jobs, states, focused, page)
    sys.stdout.write(menu_text)
    sys.stdout.flush()
    menu_lines = menu_text.count('\n')

    while True:
        ch = _getch()

        if ch in ('\r', '\n'):
            sys.stdout.write('\n')
            changes = 0
            for jid, enabled in states.items():
                if enabled != original[jid]:
                    _save_job_status(db_path, jid, enabled)
                    changes += 1
            enabled_count = sum(1 for v in states.values() if v)
            if changes:
                print(f'Saved. {enabled_count}/{len(jobs)} jobs enabled ({changes} changed).')
            else:
                print(f'No changes. {enabled_count}/{len(jobs)} jobs enabled.')
            return

        if ch in ('q', 'Q'):
            sys.stdout.write('\n')
            print('No changes.')
            return

        if ch in ('p', 'P'):
            total_pages = max(1, (len(jobs) + PAGE_SIZE - 1) // PAGE_SIZE)
            page = (page + 1) % total_pages
            focused = 0

        elif ch == ' ':
            start = page * PAGE_SIZE
            page_jobs = jobs[start:start + PAGE_SIZE]
            if 0 <= focused < len(page_jobs):
                jid = page_jobs[focused]["id"]
                states[jid] = not states[jid]

        elif ch.isdigit() and ch != '0':
            idx = int(ch) - 1
            start = page * PAGE_SIZE
            page_jobs = jobs[start:start + PAGE_SIZE]
            if 0 <= idx < len(page_jobs):
                focused = idx
                jid = page_jobs[idx]["id"]
                states[jid] = not states[jid]

        elif ch == '\x1b':
            try:
                next1 = _getch()
                if next1 == '[':
                    next2 = _getch()
                    n_items = min(PAGE_SIZE, len(jobs) - page * PAGE_SIZE)
                    if n_items > 0:
                        if next2 == 'A':
                            focused = (focused - 1) % n_items
                        elif next2 == 'B':
                            focused = (focused + 1) % n_items
            except Exception:
                pass

        elif ch == '\xe0' or ch == '\x00':
            try:
                next1 = _getch()
                n_items = min(PAGE_SIZE, len(jobs) - page * PAGE_SIZE)
                if n_items > 0:
                    if next1 == 'H':
                        focused = (focused - 1) % n_items
                    elif next1 == 'P':
                        focused = (focused + 1) % n_items
            except Exception:
                pass

        else:
            continue

        sys.stdout.write(f'\x1b[{menu_lines}A')
        new_text = _render_menu(jobs, states, focused, page)
        sys.stdout.write(new_text)
        sys.stdout.flush()
        menu_lines = new_text.count('\n')
