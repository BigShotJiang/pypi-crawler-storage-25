"""Local-first conversation history importer — ChatGPT and Claude.ai exports.

No external API calls. No OpenAI API key required. Uses AIBrain's bundled
local embeddings (MiniLM) for deduplication.

Supported formats:
  - ChatGPT export: conversations.json (array with 'mapping' dict of nodes)
  - Claude.ai export: conversations.json (array with 'name' + 'chat_messages')

Usage (Python API):
    from aibrain.tools.import_history import import_conversations
    result = import_conversations("conversations.json", verbose=True)
    print(result)  # {"imported": N, "skipped": N, "errors": N}

Usage (CLI — wired via aibrain/__main__.py):
    aibrain import conversations.json
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

__all__ = [
    "parse_chatgpt_export",
    "parse_claude_export",
    "detect_format",
    "import_conversations",
]

_MAX_CONTENT_CHARS = 4000
_SOURCE_CHATGPT = "chatgpt_export"
_SOURCE_CLAUDE = "claude_export"


# ---------------------------------------------------------------------------
# Parsers
# ---------------------------------------------------------------------------

def parse_chatgpt_export(filepath: str | Path) -> list[dict]:
    """Parse a ChatGPT conversations.json export.

    Format:
        [
          {
            "title": "...",
            "mapping": {
              "node_id": {
                "message": {
                  "author": {"role": "user" | "assistant" | "system" | "tool"},
                  "content": {"parts": ["text", ...]}
                }
              },
              ...
            }
          },
          ...
        ]

    Returns:
        List of {"title": str, "messages": [{"role": str, "content": str}]}
        Only user/assistant messages with non-empty text are included.
        Messages are ordered by their position in the mapping dict (insertion order,
        which reflects conversation order in ChatGPT exports).
    """
    filepath = Path(filepath)
    with open(filepath, "r", encoding="utf-8") as fh:
        data = json.load(fh)

    if not isinstance(data, list):
        raise ValueError(
            f"ChatGPT export must be a JSON array at top level, got {type(data).__name__}"
        )

    conversations = []
    for conv in data:
        if not isinstance(conv, dict):
            continue

        title = (conv.get("title") or "Untitled conversation").strip()
        mapping = conv.get("mapping") or {}

        messages = []
        for node in mapping.values():
            if not isinstance(node, dict):
                continue
            msg = node.get("message")
            if not isinstance(msg, dict):
                continue

            author = msg.get("author") or {}
            role = author.get("role", "")
            if role not in ("user", "assistant"):
                continue

            content_block = msg.get("content") or {}
            parts = content_block.get("parts") or []
            # parts can contain strings or dicts (for images/files — skip non-strings)
            text = " ".join(p for p in parts if isinstance(p, str)).strip()
            if not text:
                continue

            messages.append({"role": role, "content": text})

        conversations.append({"title": title, "messages": messages})

    return conversations


def parse_claude_export(filepath: str | Path) -> list[dict]:
    """Parse a Claude.ai conversations.json export.

    Format:
        [
          {
            "name": "...",
            "chat_messages": [
              {"sender": "human" | "assistant", "text": "..."},
              ...
            ]
          },
          ...
        ]

    Returns:
        List of {"title": str, "messages": [{"role": str, "content": str}]}
        Sender "human" is normalised to role "user".
    """
    filepath = Path(filepath)
    with open(filepath, "r", encoding="utf-8") as fh:
        data = json.load(fh)

    if not isinstance(data, list):
        raise ValueError(
            f"Claude export must be a JSON array at top level, got {type(data).__name__}"
        )

    _role_map = {"human": "user", "assistant": "assistant"}

    conversations = []
    for conv in data:
        if not isinstance(conv, dict):
            continue

        title = (conv.get("name") or "Untitled conversation").strip()
        chat_messages = conv.get("chat_messages") or []

        messages = []
        for msg in chat_messages:
            if not isinstance(msg, dict):
                continue
            sender = msg.get("sender", "")
            role = _role_map.get(sender, sender)
            text = (msg.get("text") or "").strip()
            if not text:
                continue
            messages.append({"role": role, "content": text})

        conversations.append({"title": title, "messages": messages})

    return conversations


def detect_format(filepath: str | Path) -> str:
    """Detect whether a file is a ChatGPT or Claude.ai export.

    Heuristic:
      - Claude export: top-level array items have a "chat_messages" key
      - ChatGPT export: top-level array items have a "mapping" key
      - Returns "unknown" if neither pattern matches or the file is unreadable.

    Returns:
        "chatgpt" | "claude" | "unknown"
    """
    filepath = Path(filepath)
    try:
        with open(filepath, "r", encoding="utf-8") as fh:
            data = json.load(fh)
    except Exception:
        return "unknown"

    if not isinstance(data, list) or not data:
        return "unknown"

    # Sample up to the first 3 items to be robust against mixed content
    sample = [item for item in data[:3] if isinstance(item, dict)]
    if not sample:
        return "unknown"

    has_mapping = any("mapping" in item for item in sample)
    has_chat_messages = any("chat_messages" in item for item in sample)

    if has_chat_messages:
        return "claude"
    if has_mapping:
        return "chatgpt"
    return "unknown"


# ---------------------------------------------------------------------------
# Core importer
# ---------------------------------------------------------------------------

def _build_memory_content(title: str, messages: list[dict]) -> str:
    """Concatenate conversation into a single storable string, truncated to _MAX_CONTENT_CHARS."""
    lines = [f"Conversation: {title}", ""]
    for msg in messages:
        role = msg.get("role", "unknown").capitalize()
        content = msg.get("content", "")
        lines.append(f"{role}: {content}")

    full = "\n".join(lines)
    if len(full) > _MAX_CONTENT_CHARS:
        full = full[:_MAX_CONTENT_CHARS - 3] + "..."
    return full


def _title_already_imported(title: str, source: str) -> bool:
    """Return True if a memory with this conversation title already exists.

    Uses FTS search on the memory name field. This is a best-effort dedup —
    the dedup_threshold in create_memory also guards against near-duplicates
    at the embedding level.
    """
    try:
        import aibrain_db
        db = aibrain_db.get_db()
        name_pattern = f"Conversation: {title[:60]}"
        rows = db.execute(
            "SELECT id FROM memories WHERE name LIKE ? LIMIT 1",
            (name_pattern[:70] + "%",),
        ).fetchall()
        return len(rows) > 0
    except Exception:
        # If dedup check fails, allow import (better to have duplicate than miss)
        return False


def import_conversations(
    filepath: str | Path,
    db_path: str | None = None,
    max_conversations: int | None = None,
    verbose: bool = False,
) -> dict[str, int]:
    """Import ChatGPT or Claude.ai conversation exports into AIBrain memory.

    Detects format automatically. Each conversation becomes one memory entry.
    Messages are concatenated and truncated to 4000 chars. Deduplicates by
    conversation title — skips if a memory with the same title already exists.

    Args:
        filepath:          Path to the export file (conversations.json).
        db_path:           Override brain DB path (default: auto-resolved via AIBRAIN_ROOT).
        max_conversations: Limit how many conversations to import (None = all).
        verbose:           Print per-entry progress to stdout.

    Returns:
        Dict with keys "imported", "skipped", "errors".
    """
    filepath = Path(filepath)
    if not filepath.exists():
        raise FileNotFoundError(f"Export file not found: {filepath}")

    # Set DB path override before any aibrain_db import if provided.
    # os.environ["AIBRAIN_DB"] is a no-op if aibrain_db is already imported
    # (the module only reads the env var once at import time). Instead, set
    # DB_PATH directly on the module so the override is honoured even in a
    # long-running process that has already imported aibrain_db.
    if db_path:
        import aibrain_db
        from pathlib import Path as _Path
        aibrain_db.DB_PATH = _Path(db_path)

    import aibrain_db

    fmt = detect_format(filepath)
    if fmt == "chatgpt":
        conversations = parse_chatgpt_export(filepath)
        source_tag = _SOURCE_CHATGPT
    elif fmt == "claude":
        conversations = parse_claude_export(filepath)
        source_tag = _SOURCE_CLAUDE
    else:
        raise ValueError(
            f"Could not detect format of {filepath}. "
            "Expected ChatGPT (has 'mapping') or Claude.ai (has 'chat_messages') export."
        )

    if max_conversations is not None:
        conversations = conversations[:max_conversations]

    total = len(conversations)
    imported = 0
    skipped = 0
    errors = 0
    imported_at = datetime.now(timezone.utc).isoformat()

    if verbose:
        print(f"  Detected format: {fmt}")
        print(f"  Total conversations: {total}")
        print()

    for i, conv in enumerate(conversations, start=1):
        title = conv.get("title", "Untitled conversation")
        messages = conv.get("messages", [])

        # Skip empty conversations
        if not messages:
            if verbose:
                print(f"  [{i}/{total}] Skip (empty): {title!r}")
            skipped += 1
            continue

        # Dedup by title
        if _title_already_imported(title, source_tag):
            if verbose:
                print(f"  [{i}/{total}] Skip (duplicate): {title!r}")
            skipped += 1
            continue

        content = _build_memory_content(title, messages)

        # Name: first 60 chars of title for the memory name field
        name_prefix = title[:60]
        name = f"Conversation: {name_prefix}"
        if len(title) > 60:
            name += "..."

        tags = f"{source_tag},conversation,imported"

        try:
            aibrain_db.create_memory(
                name=name,
                mem_type="user",
                content=content,
                tags=tags,
                importance=0.4,
                source_agent="import-history",
            )
            imported += 1
            if verbose:
                if total <= 20 or i % 10 == 0 or i == total:
                    print(f"  [{i}/{total}] Imported: {title!r}")
        except Exception as exc:
            if verbose:
                print(f"  [{i}/{total}] Error: {title!r} — {exc}")
            errors += 1

    return {"imported": imported, "skipped": skipped, "errors": errors}
