"""
aibrain.tools.marketing.analytics -- Social analytics data layer.

Reads posting_log.json, syncs to social_analytics table, generates summaries.
"""
from __future__ import annotations

import json
import sqlite3
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from pathlib import Path


# Default paths
_POSTING_LOG = Path.home() / "decker_system" / "12_social" / "posting_log.json"


def _get_db_path() -> str:
    """Resolve aibrain.db path via the canonical resolver — see aibrain_db.AIBRAIN_ROOT."""
    from aibrain_db import AIBRAIN_ROOT
    return str(AIBRAIN_ROOT / "aibrain.db")


def get_connection(db_path: str | None = None) -> sqlite3.Connection:
    """Open a connection to aibrain.db with row factory."""
    path = db_path or _get_db_path()
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    return conn


def ensure_table(conn: sqlite3.Connection) -> None:
    """Create the social_analytics table if it doesn't exist."""
    conn.execute("""
        CREATE TABLE IF NOT EXISTS social_analytics (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            post_id TEXT,
            platform TEXT NOT NULL,
            posted_at TEXT,
            content_type TEXT,
            content_summary TEXT,
            impressions INTEGER DEFAULT 0,
            likes INTEGER DEFAULT 0,
            comments INTEGER DEFAULT 0,
            shares INTEGER DEFAULT 0,
            clicks INTEGER DEFAULT 0,
            follower_delta INTEGER DEFAULT 0,
            measured_at TEXT,
            created TEXT DEFAULT (datetime('now'))
        )
    """)
    conn.commit()


def load_posting_log(path: str | Path | None = None) -> list[dict]:
    """Load posting_log.json. Returns list of post dicts."""
    log_path = Path(path) if path else _POSTING_LOG
    if not log_path.exists():
        return []
    with open(log_path, "r", encoding="utf-8") as f:
        data = json.load(f)
    if isinstance(data, list):
        return data
    return []


def sync_posts(conn: sqlite3.Connection, posts: list[dict]) -> int:
    """
    Sync posted items from posting_log into social_analytics.
    Only inserts posts not already tracked (by post_id).
    Returns count of newly inserted rows.
    """
    ensure_table(conn)
    existing = {
        row[0]
        for row in conn.execute("SELECT post_id FROM social_analytics WHERE post_id IS NOT NULL").fetchall()
    }

    inserted = 0
    for post in posts:
        if post.get("status") != "posted":
            continue
        post_id = post.get("id", "")
        if post_id in existing:
            continue

        # Derive content_type from content_file or platform
        content_file = post.get("content_file", "")
        if "tiktok" in content_file.lower() or post.get("platform") == "tiktok":
            content_type = "video"
        elif "image" in content_file.lower() or "visual" in content_file.lower():
            content_type = "image"
        else:
            content_type = "text"

        engagement = post.get("engagement", {})
        conn.execute(
            """INSERT INTO social_analytics
               (post_id, platform, posted_at, content_type, content_summary,
                impressions, likes, comments, shares, clicks)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                post_id,
                post.get("platform", "unknown"),
                post.get("posted_at", ""),
                content_type,
                post.get("content_summary", "")[:200],
                engagement.get("impressions", 0),
                engagement.get("likes", 0),
                engagement.get("comments", 0),
                engagement.get("shares", 0),
                engagement.get("clicks", 0),
            ),
        )
        inserted += 1

    conn.commit()
    return inserted


def update_engagement(
    conn: sqlite3.Connection,
    post_id: str,
    impressions: int = 0,
    likes: int = 0,
    comments: int = 0,
    shares: int = 0,
    clicks: int = 0,
    follower_delta: int = 0,
) -> bool:
    """Update engagement metrics for a specific post. Returns True if row existed."""
    now = datetime.now(timezone.utc).isoformat()
    cur = conn.execute(
        """UPDATE social_analytics
           SET impressions = ?, likes = ?, comments = ?, shares = ?,
               clicks = ?, follower_delta = ?, measured_at = ?
           WHERE post_id = ?""",
        (impressions, likes, comments, shares, clicks, follower_delta, now, post_id),
    )
    conn.commit()
    return cur.rowcount > 0


def get_all_analytics(conn: sqlite3.Connection) -> list[dict]:
    """Return all analytics rows as dicts."""
    rows = conn.execute(
        "SELECT * FROM social_analytics ORDER BY posted_at DESC"
    ).fetchall()
    return [dict(r) for r in rows]


def get_platform_breakdown(conn: sqlite3.Connection) -> dict[str, dict]:
    """Aggregate metrics by platform."""
    rows = conn.execute("""
        SELECT platform,
               COUNT(*) as post_count,
               SUM(impressions) as total_impressions,
               SUM(likes) as total_likes,
               SUM(comments) as total_comments,
               SUM(shares) as total_shares,
               SUM(clicks) as total_clicks
        FROM social_analytics
        GROUP BY platform
        ORDER BY total_impressions DESC
    """).fetchall()
    return {r["platform"]: dict(r) for r in rows}


_VALID_METRICS = frozenset({"impressions", "likes", "comments", "shares", "clicks"})

# Pre-built query map — avoids f-string SQL while keeping the metric dynamic.
# Every key is a known column name (frozenset above), so no injection risk.
_TOP_QUERIES = {m: "SELECT * FROM social_analytics ORDER BY {} DESC LIMIT ?".format(m) for m in _VALID_METRICS}
_WORST_QUERIES = {m: "SELECT * FROM social_analytics ORDER BY {} ASC LIMIT ?".format(m) for m in _VALID_METRICS}


def get_top_posts(conn: sqlite3.Connection, n: int = 5, metric: str = "likes") -> list[dict]:
    """Return top N posts by a given metric."""
    if metric not in _VALID_METRICS:
        metric = "likes"
    rows = conn.execute(_TOP_QUERIES[metric], (n,)).fetchall()  # noqa:SQL-F-STRING
    return [dict(r) for r in rows]


def get_worst_posts(conn: sqlite3.Connection, n: int = 5, metric: str = "likes") -> list[dict]:
    """Return bottom N posts by a given metric (only posted items with data)."""
    if metric not in _VALID_METRICS:
        metric = "likes"
    rows = conn.execute(_WORST_QUERIES[metric], (n,)).fetchall()  # noqa:SQL-F-STRING
    return [dict(r) for r in rows]


def get_time_slot_analysis(conn: sqlite3.Connection) -> list[dict]:
    """Analyze which posting hours perform best."""
    rows = conn.execute("""
        SELECT
            CAST(strftime('%H', posted_at) AS INTEGER) as hour,
            COUNT(*) as post_count,
            AVG(impressions) as avg_impressions,
            AVG(likes) as avg_likes,
            AVG(comments) as avg_comments
        FROM social_analytics
        WHERE posted_at IS NOT NULL AND posted_at != ''
        GROUP BY hour
        ORDER BY avg_likes DESC
    """).fetchall()
    return [dict(r) for r in rows]


def get_content_type_analysis(conn: sqlite3.Connection) -> list[dict]:
    """Analyze performance by content type (text, image, video)."""
    rows = conn.execute("""
        SELECT
            content_type,
            COUNT(*) as post_count,
            AVG(impressions) as avg_impressions,
            AVG(likes) as avg_likes,
            AVG(comments) as avg_comments,
            AVG(shares) as avg_shares
        FROM social_analytics
        WHERE content_type IS NOT NULL
        GROUP BY content_type
        ORDER BY avg_likes DESC
    """).fetchall()
    return [dict(r) for r in rows]


def generate_weekly_summary(conn: sqlite3.Connection, weeks_back: int = 1) -> str:
    """
    Generate a text summary of social performance over the last N weeks.
    Suitable for Telegram delivery.
    """
    now = datetime.now(timezone.utc)
    start = now - timedelta(weeks=weeks_back)
    start_str = start.strftime("%Y-%m-%dT%H:%M:%SZ")

    # Get posts in range
    rows = conn.execute(
        """SELECT * FROM social_analytics
           WHERE posted_at >= ? ORDER BY posted_at DESC""",
        (start_str,),
    ).fetchall()

    if not rows:
        return f"No posts found in the last {weeks_back} week(s)."

    posts = [dict(r) for r in rows]
    total_posts = len(posts)

    # Aggregate
    total_impressions = sum(p.get("impressions", 0) or 0 for p in posts)
    total_likes = sum(p.get("likes", 0) or 0 for p in posts)
    total_comments = sum(p.get("comments", 0) or 0 for p in posts)
    total_shares = sum(p.get("shares", 0) or 0 for p in posts)

    # Platform breakdown
    by_platform: dict[str, int] = defaultdict(int)
    for p in posts:
        by_platform[p["platform"]] += 1

    # Best post
    best = max(posts, key=lambda p: (p.get("likes", 0) or 0))
    worst = min(posts, key=lambda p: (p.get("likes", 0) or 0))

    # Content type breakdown
    by_type: dict[str, int] = defaultdict(int)
    for p in posts:
        by_type[p.get("content_type", "unknown")] += 1

    # Time slot analysis
    by_hour: dict[int, list[int]] = defaultdict(list)
    for p in posts:
        pa = p.get("posted_at", "")
        if pa and "T" in pa:
            try:
                hour = int(pa.split("T")[1][:2])
                by_hour[hour].append(p.get("likes", 0) or 0)
            except (ValueError, IndexError):
                pass

    best_hour = ""
    if by_hour:
        best_h = max(by_hour, key=lambda h: sum(by_hour[h]) / len(by_hour[h]))
        best_hour = f"\nBest time slot: {best_h:02d}:00 UTC (avg {sum(by_hour[best_h]) / len(by_hour[best_h]):.0f} likes)"

    lines = [
        "=== Social Analytics Weekly Summary ===",
        f"Period: {start.strftime('%Y-%m-%d')} to {now.strftime('%Y-%m-%d')}",
        "",
        f"Posts: {total_posts}",
        f"Impressions: {total_impressions:,}",
        f"Likes: {total_likes:,}",
        f"Comments: {total_comments:,}",
        f"Shares: {total_shares:,}",
        "",
        "--- Platform Breakdown ---",
    ]
    for plat, count in sorted(by_platform.items(), key=lambda x: -x[1]):
        lines.append(f"  {plat}: {count} posts")

    lines.append("")
    lines.append("--- Content Types ---")
    for ct, count in sorted(by_type.items(), key=lambda x: -x[1]):
        lines.append(f"  {ct}: {count} posts")

    lines.append("")
    lines.append("--- Best Post ---")
    lines.append(f"  [{best.get('platform')}] {best.get('content_summary', 'N/A')[:60]}")
    lines.append(f"  Likes: {best.get('likes', 0)}, Comments: {best.get('comments', 0)}, Shares: {best.get('shares', 0)}")

    lines.append("")
    lines.append("--- Worst Post ---")
    lines.append(f"  [{worst.get('platform')}] {worst.get('content_summary', 'N/A')[:60]}")
    lines.append(f"  Likes: {worst.get('likes', 0)}, Comments: {worst.get('comments', 0)}, Shares: {worst.get('shares', 0)}")

    if best_hour:
        lines.append(best_hour)

    return "\n".join(lines)
