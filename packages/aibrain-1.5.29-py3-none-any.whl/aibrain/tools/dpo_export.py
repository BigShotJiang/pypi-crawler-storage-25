"""
dpo_export.py — Export AIBrain correction memories as a DPO preference dataset.

The AIBrain memory system stores four signal types that map to DPO preference pairs:

  feedback        — manually written lessons (highest quality, clear wrong/right split)
  self_reflection — session-level self-corrections ("You're right, I should have...")
  correction      — retrolearn-extracted conversation turns (large volume, variable quality)
  fix             — retrolearn-extracted fix/debug turns (technical corrections)

DPO triple structure:
  prompt          — the situation / context that triggered a correction
  chosen          — the correct / preferred behaviour
  rejected        — the wrong / penalised behaviour (inferred or extracted from content)
  error_category  — coarse label derived from tags or content heuristics
  source          — which memory type this triple came from
  memory_id       — original row id in the memories table
  confidence      — 0.0–1.0 quality signal (feedback=1.0, self_reflection=0.9, etc.)

Output: data/corrections_dpo.jsonl — one JSON object per line.

Usage:
    python -m aibrain.tools.dpo_export
    python -m aibrain.tools.dpo_export --out /path/to/custom.jsonl
    python -m aibrain.tools.dpo_export --source feedback,self_reflection
"""

from __future__ import annotations

import json
import re
import sys
from collections import Counter
from pathlib import Path
from typing import Any

# ─── DB connection ─────────────────────────────────────────────────────────────


def _get_db():
    """Return a sqlite3 connection to the AIBrain DB via the canonical resolver."""
    try:
        from aibrain_db import AIBRAIN_ROOT
        import sqlite3
        return sqlite3.connect(str(AIBRAIN_ROOT / "aibrain.db"))
    except Exception:
        # Fallback: look for aibrain.db relative to this file's package root
        import sqlite3
        pkg_root = Path(__file__).resolve().parent.parent.parent
        candidate = pkg_root / "aibrain.db"
        if not candidate.exists():
            raise FileNotFoundError(
                f"Cannot find aibrain.db. Tried: {candidate}\n"
                "Set AIBRAIN_ROOT env var or run from the aibrain project directory."
            )
        return sqlite3.connect(str(candidate))


# ─── Error category inference ──────────────────────────────────────────────────

# Ordered patterns: first match wins.
_CATEGORY_PATTERNS: list[tuple[str, list[str]]] = [
    ("verify_before_done",      ["verify", "verif", "actual output", "declaring done", "check first", "confirm"]),
    ("git_workflow",            ["git ", "push", "commit", "stash", "rebase", "branch", "repo", "github"]),
    ("delegation",              ["delegate", "company task", "assign", "ceo", "spawn agent", "create_task"]),
    ("auth_credentials",        ["credential", "token", "secret", "api key", "password", "auth", "403", "401"]),
    ("harness_execution",       ["harness", "workflow_runner", "run_workflow", "audit trail"]),
    ("memory_accuracy",         ["memory", "stale", "recall", "MEMORY.md", "brain", "hallucin"]),
    ("scope_creep",             ["scope", "out of scope", "too broad", "overreach", "stay focused"]),
    ("process_safety",          ["never kill", "taskkill", "process", "browser", "chrome", "edge"]),
    ("communication",           ["telegram", "email", "reply", "message", "notify", "report"]),
    ("tool_selection",          ["tool", "playwright", "mcp", "skill", "bash", "script"]),
    ("decision_making",         ["decision", "ask decker", "approval", "explicit", "permission"]),
    ("code_correctness",        ["bug", "error", "exception", "traceback", "fix", "crash", "broken"]),
    ("data_integrity",          ["db", "database", "migration", "schema", "constraint", "foreign key"]),
    ("security_ops",            ["scan", "wintermute", "cve", "vuln", "exploit", "target", "pentest"]),
    ("content_publication",     ["publish", "post", "linkedin", "twitter", "content", "draft", "communications_agent"]),
    ("file_system",             ["file", "path", "directory", "rename", "delete", "archive", "backup"]),
    ("task_tracking",           ["task", "backlog", "complete_task", "checkout_task", "queue"]),
]

_CATEGORY_FALLBACK = "general_correction"


def _infer_category(name: str, tags: str, content: str) -> str:
    haystack = f"{name} {tags} {content[:500]}".lower()
    for category, keywords in _CATEGORY_PATTERNS:
        if any(kw.lower() in haystack for kw in keywords):
            return category
    return _CATEGORY_FALLBACK


# ─── Content parsing helpers ───────────────────────────────────────────────────


def _strip_posttool_prefix(text: str) -> str:
    """Remove [posttool], [historical_scan], line-number prefixes etc."""
    text = re.sub(r"^\[posttool\]\s*", "", text, flags=re.IGNORECASE)
    text = re.sub(r"^\[historical_scan\]\s*", "", text, flags=re.IGNORECASE)
    # Strip numeric line-prefix lines like "  42→..." from historical scans
    text = re.sub(r"^\s*\d+→", "", text, flags=re.MULTILINE)
    return text.strip()


def _split_feedback_content(name: str, content: str) -> tuple[str, str, str]:
    """
    Parse a 'feedback' type memory into (prompt, rejected, chosen).

    Feedback memories follow a pattern:
        [situation described in first paragraph]
        **Why:** [why the wrong action happened]
        **How to apply:** [what to do instead]

    Falls back to using name as prompt and content as chosen when structure absent.
    """
    # Clean markdown artifacts
    clean = content.strip()

    # Try to find an explicit "Why:" section — text before it is the context/wrong
    why_match = re.search(r"\*?\*?Why:?\*?\*?\s*", clean, re.IGNORECASE)
    apply_match = re.search(r"\*?\*?How to apply:?\*?\*?\s*", clean, re.IGNORECASE)

    if apply_match:
        chosen = clean[apply_match.end():].strip()
        if why_match:
            rejected = clean[why_match.end():apply_match.start()].strip()
            prompt_text = clean[: why_match.start()].strip() or name
        else:
            rejected = clean[: apply_match.start()].strip()[:300]
            prompt_text = name
        return prompt_text, rejected, chosen

    # No explicit sections — use name as prompt, content as chosen (no rejected recoverable)
    return name, "", clean


def _split_self_reflection(name: str, content: str) -> tuple[str, str, str]:
    """
    Parse a 'self_reflection' memory.

    Pattern: "You're right. I [did wrong thing]. I should have [correct action]."
    Or:      "You're right — [what I should have done instead]."

    Returns (prompt, rejected_behaviour, chosen_behaviour).
    """
    clean = content.strip()

    # "I should have / should not have / should be" → the part before is context/wrong
    should_match = re.search(
        r"\bI should(?:n[''']t| not)?\s+have\b|\bI should\b|\bshould have\b",
        clean, re.IGNORECASE
    )
    if should_match:
        before = clean[: should_match.start()].strip()
        chosen = clean[should_match.start():].strip()
        # The before text often contains what the agent DID wrong
        rejected = before if len(before) > 20 else ""
        prompt_text = name if not rejected else before[:200]
        return prompt_text, rejected, chosen

    # "Won't happen again." style
    wont_match = re.search(r"won[''']t happen again", clean, re.IGNORECASE)
    if wont_match:
        chosen = clean[: wont_match.end()].strip()
        return name, "", chosen

    # Fallback: whole content is the chosen correction acknowledgment
    return name, "", clean


def _split_retrolearn_correction(name: str, tags: str, content: str) -> tuple[str, str, str]:
    """
    Parse a retrolearn shard4 correction turn.

    role_user turns = Decker issuing a correction (context is Decker's message)
    role_assistant turns = agent's self-correction acknowledgment

    For role_assistant turns, we use the content as `chosen` (what the agent corrected to)
    with the name as prompt.
    """
    clean = _strip_posttool_prefix(content)

    is_user_role = "role_user" in tags

    if is_user_role:
        # Decker's correction: use as prompt context, no chosen/rejected split
        # These are less useful for DPO but still captured as correction-context records
        return clean[:300], "", ""

    # role_assistant: self-correction mid-session
    # Check for typical self-correction openers
    self_corr_match = re.search(
        r"(?:You'?re right|Good catch|I was wrong|I missed|I should|Got it|"
        r"Let me correct|Actually|Wait —|Stopping\.|I hear you)",
        clean, re.IGNORECASE
    )
    if self_corr_match:
        chosen = clean[self_corr_match.start():].strip()
        rejected = clean[: self_corr_match.start()].strip()[:200]
        return name, rejected, chosen

    return name, "", clean[:500]


def _split_fix_content(name: str, content: str) -> tuple[str, str, str]:
    """Parse a 'fix' type memory — typically a debug finding followed by the resolution."""
    clean = _strip_posttool_prefix(content)
    # Fixes often follow: "[diagnosis] ... fix: [resolution]"
    fix_match = re.search(
        r"(?:fix(?:ed)?:|root cause:|the fix:|solution:)\s*",
        clean, re.IGNORECASE
    )
    if fix_match:
        rejected = clean[: fix_match.start()].strip()[:300]
        chosen = clean[fix_match.start():].strip()
        return name, rejected, chosen
    # Fallback
    return name, "", clean[:500]


# ─── Per-source extractors ─────────────────────────────────────────────────────


def _extract_feedback(conn) -> list[dict[str, Any]]:
    rows = conn.execute(
        "SELECT id, name, type, tags, content FROM memories "
        "WHERE type='feedback' AND status='active'"
    ).fetchall()

    triples = []
    for row_id, name, mtype, tags, content in rows:
        prompt, rejected, chosen = _split_feedback_content(name, content or "")
        if not chosen:
            continue  # skip empty
        triples.append({
            "prompt": prompt,
            "chosen": chosen,
            "rejected": rejected,
            "error_category": _infer_category(name, tags or "", content or ""),
            "source": "feedback",
            "memory_id": row_id,
            "confidence": 1.0,
        })
    return triples


def _extract_self_reflections(conn) -> list[dict[str, Any]]:
    rows = conn.execute(
        "SELECT id, name, type, tags, content FROM memories "
        "WHERE type='self_reflection' AND status='active'"
    ).fetchall()

    triples = []
    for row_id, name, mtype, tags, content in rows:
        prompt, rejected, chosen = _split_self_reflection(name, content or "")
        if not chosen:
            continue
        triples.append({
            "prompt": prompt,
            "chosen": chosen,
            "rejected": rejected,
            "error_category": _infer_category(name, tags or "", content or ""),
            "source": "self_reflection",
            "memory_id": row_id,
            "confidence": 0.9,
        })
    return triples


def _extract_corrections(conn) -> list[dict[str, Any]]:
    """
    Extract correction-type memories.

    Priority tiers:
      1. Shard4 role_assistant turns — highest signal (self-corrections with session context)
      2. Shard1/2 retrolearn corrections that contain "should have" patterns
      3. Realtime non-consolidated corrections (active only)
    """
    triples = []

    # Tier 1: shard4 assistant self-corrections
    rows = conn.execute(
        "SELECT id, name, type, tags, content FROM memories "
        "WHERE type='correction' AND status='active' "
        "AND tags LIKE '%phase2_shard_4%' AND tags LIKE '%role_assistant%'"
    ).fetchall()

    for row_id, name, mtype, tags, content in rows:
        prompt, rejected, chosen = _split_retrolearn_correction(name, tags or "", content or "")
        if not chosen:
            continue
        triples.append({
            "prompt": prompt,
            "chosen": chosen,
            "rejected": rejected,
            "error_category": _infer_category(name, tags or "", content or ""),
            "source": "correction_shard4",
            "memory_id": row_id,
            "confidence": 0.7,
        })

    # Tier 2: shard1/2 corrections with explicit "should have" self-corrections
    rows2 = conn.execute(
        "SELECT id, name, type, tags, content FROM memories "
        "WHERE type='correction' AND status='active' "
        "AND (tags LIKE '%shard1%' OR tags LIKE '%shard2%') "
        "AND (content LIKE '%should have%' OR content LIKE '%You are right%')"
    ).fetchall()

    for row_id, name, mtype, tags, content in rows2:
        prompt, rejected, chosen = _split_retrolearn_correction(name, tags or "", content or "")
        if not chosen:
            continue
        triples.append({
            "prompt": prompt,
            "chosen": chosen,
            "rejected": rejected,
            "error_category": _infer_category(name, tags or "", content or ""),
            "source": "correction_retrolearn",
            "memory_id": row_id,
            "confidence": 0.6,
        })

    # Tier 3: realtime corrections (not consolidated, active)
    rows3 = conn.execute(
        "SELECT id, name, type, tags, content FROM memories "
        "WHERE type='correction' AND status='active' "
        "AND tags NOT LIKE '%phase2_shard_4%' "
        "AND tags NOT LIKE '%shard1%' AND tags NOT LIKE '%shard2%' "
        "AND tags NOT LIKE '%consolidated_into%'"
    ).fetchall()

    for row_id, name, mtype, tags, content in rows3:
        clean = _strip_posttool_prefix(content or "")
        if not clean or len(clean) < 20:
            continue
        # Only include turns that show actual correction signal
        has_signal = any(kw in clean.lower() for kw in [
            "should have", "you're right", "you are right", "i was wrong",
            "my mistake", "let me correct", "actually", "wait —",
            "i missed", "i should", "good catch",
        ])
        if not has_signal:
            continue
        prompt, rejected, chosen = _split_retrolearn_correction(name, tags or "", clean)
        if not chosen:
            continue
        triples.append({
            "prompt": prompt,
            "chosen": chosen,
            "rejected": rejected,
            "error_category": _infer_category(name, tags or "", clean),
            "source": "correction_realtime",
            "memory_id": row_id,
            "confidence": 0.5,
        })

    return triples


def _extract_fixes(conn) -> list[dict[str, Any]]:
    """Extract 'fix' type memories that have a clear diagnosis → resolution structure."""
    rows = conn.execute(
        "SELECT id, name, type, tags, content FROM memories "
        "WHERE type='fix' AND status='active'"
    ).fetchall()

    triples = []
    for row_id, name, mtype, tags, content in rows:
        clean = _strip_posttool_prefix(content or "")
        if not clean or len(clean) < 20:
            continue
        # Only include rows with an explicit resolution marker
        has_resolution = any(kw in clean.lower() for kw in [
            "fix:", "fixed:", "root cause:", "solution:", "the fix:", "resolution:",
        ])
        if not has_resolution:
            continue
        prompt, rejected, chosen = _split_fix_content(name, clean)
        if not chosen:
            continue
        triples.append({
            "prompt": prompt,
            "chosen": chosen,
            "rejected": rejected,
            "error_category": _infer_category(name, tags or "", clean),
            "source": "fix",
            "memory_id": row_id,
            "confidence": 0.6,
        })
    return triples


# ─── Deduplication ─────────────────────────────────────────────────────────────


def _dedup(triples: list[dict]) -> list[dict]:
    """Remove near-duplicate triples (same chosen[:100] fingerprint)."""
    seen: set[str] = set()
    result = []
    for t in triples:
        key = re.sub(r"\s+", " ", t["chosen"][:100].lower().strip())
        if key not in seen:
            seen.add(key)
            result.append(t)
    return result


# ─── Main export ───────────────────────────────────────────────────────────────


def export_dpo(
    out_path: str | None = None,
    sources: list[str] | None = None,
) -> dict[str, Any]:
    """
    Query the AIBrain DB and write a DPO dataset to JSONL.

    Args:
        out_path: Destination path. Defaults to data/corrections_dpo.jsonl relative
                  to the aibrain project root.
        sources:  Which memory types to include. Defaults to all:
                  ['feedback', 'self_reflection', 'correction', 'fix']

    Returns:
        Summary dict: total, by_source, by_category, file_path, file_size_bytes.
    """
    if sources is None:
        sources = ["feedback", "self_reflection", "correction", "fix"]

    conn = _get_db()

    all_triples: list[dict] = []

    if "feedback" in sources:
        all_triples.extend(_extract_feedback(conn))
    if "self_reflection" in sources:
        all_triples.extend(_extract_self_reflections(conn))
    if "correction" in sources:
        all_triples.extend(_extract_corrections(conn))
    if "fix" in sources:
        all_triples.extend(_extract_fixes(conn))

    conn.close()

    # Sort by confidence descending, then deduplicate
    all_triples.sort(key=lambda t: -t["confidence"])
    all_triples = _dedup(all_triples)

    # Resolve output path
    if out_path is None:
        try:
            from aibrain_db import AIBRAIN_ROOT
            data_dir = AIBRAIN_ROOT / "data"
        except Exception:
            data_dir = Path(__file__).resolve().parent.parent.parent / "data"
        data_dir.mkdir(parents=True, exist_ok=True)
        dest = data_dir / "corrections_dpo.jsonl"
    else:
        dest = Path(out_path).resolve()
        dest.parent.mkdir(parents=True, exist_ok=True)

    with open(dest, "w", encoding="utf-8") as fh:
        for triple in all_triples:
            fh.write(json.dumps(triple, ensure_ascii=False) + "\n")

    # Build summary
    by_source: Counter = Counter(t["source"] for t in all_triples)
    by_category: Counter = Counter(t["error_category"] for t in all_triples)
    has_rejected = sum(1 for t in all_triples if t.get("rejected"))

    return {
        "total": len(all_triples),
        "has_rejected_pair": has_rejected,
        "prompt_only": len(all_triples) - has_rejected,
        "by_source": dict(by_source.most_common()),
        "by_category": dict(by_category.most_common()),
        "file_path": str(dest),
        "file_size_bytes": dest.stat().st_size,
    }


# ─── CLI entry ─────────────────────────────────────────────────────────────────


def _cli_main() -> None:
    args = sys.argv[1:]
    out_path = None
    sources = None

    if "-h" in args or "--help" in args:
        print(__doc__)
        print("Usage:")
        print("  python -m aibrain.tools.dpo_export")
        print("  python -m aibrain.tools.dpo_export --out /path/to/file.jsonl")
        print("  python -m aibrain.tools.dpo_export --source feedback,self_reflection")
        sys.exit(0)

    if "--out" in args:
        idx = args.index("--out")
        if idx + 1 < len(args):
            out_path = args[idx + 1]

    if "--source" in args:
        idx = args.index("--source")
        if idx + 1 < len(args):
            sources = [s.strip() for s in args[idx + 1].split(",")]

    print("Exporting DPO preference dataset from AIBrain memories...")
    if sources:
        print(f"  Sources: {', '.join(sources)}")
    else:
        print("  Sources: feedback, self_reflection, correction, fix")
    print()

    summary = export_dpo(out_path=out_path, sources=sources)

    print(f"Total triples:          {summary['total']:,}")
    print(f"  Full pairs (w/rejected): {summary['has_rejected_pair']:,}")
    print(f"  Context+chosen only:     {summary['prompt_only']:,}")
    print()
    print("By source:")
    for source, count in summary["by_source"].items():
        print(f"  {source:<28} {count:>5}")
    print()
    print("By error_category (top 15):")
    for cat, count in list(summary["by_category"].items())[:15]:
        print(f"  {cat:<28} {count:>5}")
    print()
    print(f"Output: {summary['file_path']}")
    print(f"Size:   {summary['file_size_bytes']:,} bytes  "
          f"({summary['file_size_bytes'] / 1024:.1f} KB)")

    # Print one sanitised sample triple
    if summary["total"] > 0:
        sample_path = Path(summary["file_path"])
        with open(sample_path, encoding="utf-8") as fh:
            first_line = fh.readline()
        triple = json.loads(first_line)
        print()
        print("Sample triple (highest confidence):")
        print(f"  source:         {triple['source']}")
        print(f"  confidence:     {triple['confidence']}")
        print(f"  error_category: {triple['error_category']}")
        print(f"  prompt:         {triple['prompt'][:120]!r}")
        print(f"  chosen[:120]:   {triple['chosen'][:120]!r}")
        rej = triple.get("rejected", "")
        if rej:
            print(f"  rejected[:120]: {rej[:120]!r}")
        else:
            print("  rejected:       (not available for this source)")


if __name__ == "__main__":
    try:
        from aibrain.core.workflow_base import workflow_execute

        def _entry():
            _cli_main()

        workflow_execute(
            workflow_name="dpo_export",
            action=_entry,
            task_type="simple",
            actor="cli",
        )
    except ImportError:
        # Allow running standalone without the full harness
        _cli_main()
