"""
eval_runner.py — Held-out evaluation set runner for AIBrain quality measurement.

Loads eval_set_v1.jsonl and provides:
- Summary table of domain/difficulty distribution
- evaluate_task() — raises NotImplementedError until AIBRAIN_EVAL_MODEL is configured

Usage:
    python -m aibrain.tools.eval_runner
    python -m aibrain.tools.eval_runner --file data/eval_set_v1.jsonl
    python -m aibrain.tools.eval_runner --domain git
"""

from __future__ import annotations

import argparse
import json
import sys
from collections import Counter, defaultdict
from pathlib import Path
from typing import Optional


EVAL_SET_DEFAULT = Path(__file__).parent.parent.parent / "data" / "eval_set_v1.jsonl"

# Difficulty ordering for display
DIFFICULTY_ORDER = ["easy", "medium", "hard"]


def load_eval_set(path: Path) -> list[dict]:
    tasks = []
    with open(path, "r", encoding="utf-8") as f:
        for lineno, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue
            try:
                tasks.append(json.loads(line))
            except json.JSONDecodeError as exc:
                print(f"[WARN] line {lineno}: JSON parse error — {exc}", file=sys.stderr)
    return tasks


def print_summary(tasks: list[dict], filter_domain: Optional[str] = None) -> None:
    if filter_domain:
        tasks = [t for t in tasks if t.get("domain") == filter_domain]
        if not tasks:
            print(f"No tasks found for domain '{filter_domain}'")
            return

    domain_counts: Counter = Counter(t.get("domain", "unknown") for t in tasks)
    difficulty_counts: Counter = Counter(t.get("difficulty", "unknown") for t in tasks)
    domain_difficulty: dict[str, Counter] = defaultdict(Counter)
    for t in tasks:
        domain_difficulty[t.get("domain", "unknown")][t.get("difficulty", "unknown")] += 1

    col_widths = (20, 7, 7, 7, 7)
    header = f"{'Domain':<{col_widths[0]}} {'Total':>{col_widths[1]}} {'Easy':>{col_widths[2]}} {'Medium':>{col_widths[3]}} {'Hard':>{col_widths[4]}}"
    divider = "-" * sum(col_widths) + "------"

    print(f"\nEval set: {len(tasks)} tasks")
    print(divider)
    print(header)
    print(divider)
    for domain in sorted(domain_counts.keys()):
        dc = domain_difficulty[domain]
        total = domain_counts[domain]
        easy = dc.get("easy", 0)
        medium = dc.get("medium", 0)
        hard = dc.get("hard", 0)
        print(f"{domain:<{col_widths[0]}} {total:>{col_widths[1]}} {easy:>{col_widths[2]}} {medium:>{col_widths[3]}} {hard:>{col_widths[4]}}")
    print(divider)
    print(
        f"{'TOTAL':<{col_widths[0]}} {len(tasks):>{col_widths[1]}} "
        f"{difficulty_counts.get('easy', 0):>{col_widths[2]}} "
        f"{difficulty_counts.get('medium', 0):>{col_widths[3]}} "
        f"{difficulty_counts.get('hard', 0):>{col_widths[4]}}"
    )
    print()


def evaluate_task(task: dict, agent_response: str) -> float:
    """
    Score an agent response against a task definition.

    Returns a float in [0.0, 1.0].

    This function requires LLM-as-judge configuration to operate. Set the
    AIBRAIN_EVAL_MODEL environment variable to the model ID to use for
    evaluation (e.g. ``AIBRAIN_EVAL_MODEL=claude-3-5-haiku-20241022``).

    Real scoring requires:
      - Anti-pattern detection (keyword/semantic match against task['anti_patterns'])
      - Expected-behavior coverage check (LLM-as-judge or rubric-based)
      - Domain-specific validation rules

    Raises:
        NotImplementedError: Always — evaluation requires explicit LLM-as-judge
            configuration via the AIBRAIN_EVAL_MODEL environment variable.
    """
    _ = task, agent_response  # suppress unused-argument warnings
    raise NotImplementedError(
        "evaluate_task requires LLM-as-judge configuration — set AIBRAIN_EVAL_MODEL env var"
    )


def run_task(task: dict) -> None:
    print(f"  [{task['id']}] ({task['difficulty']}) {task['prompt'][:80]}...")
    print(f"    expected: {task['expected_behavior'][:100]}...")
    print(f"    anti-patterns: {len(task.get('anti_patterns', []))} defined")
    try:
        score = evaluate_task(task, agent_response="")
        status = f"{score:.2f}"
    except NotImplementedError as exc:
        status = f"NOT_IMPLEMENTED — {exc}"
    print(f"    score: {status}")
    print()


def main(argv: Optional[list[str]] = None) -> int:
    parser = argparse.ArgumentParser(
        description="AIBrain held-out eval set runner",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument(
        "--file",
        type=Path,
        default=EVAL_SET_DEFAULT,
        help="Path to .jsonl eval set (default: data/eval_set_v1.jsonl)",
    )
    parser.add_argument(
        "--domain",
        type=str,
        default=None,
        help="Filter to a specific domain (e.g. git, memory, company_tasks)",
    )
    parser.add_argument(
        "--list",
        action="store_true",
        help="Print full task list (id + prompt preview)",
    )
    args = parser.parse_args(argv)

    if not args.file.exists():
        print(f"[ERROR] Eval set not found: {args.file}", file=sys.stderr)
        return 1

    tasks = load_eval_set(args.file)
    if not tasks:
        print("[ERROR] No tasks loaded — check file format", file=sys.stderr)
        return 1

    print_summary(tasks, filter_domain=args.domain)

    if args.list:
        display = [t for t in tasks if not args.domain or t.get("domain") == args.domain]
        for task in display:
            run_task(task)

    return 0


if __name__ == "__main__":
    sys.exit(main())
