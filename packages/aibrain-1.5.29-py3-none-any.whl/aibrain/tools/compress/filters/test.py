"""
Test runner output compression filters.

Covers: pytest, cargo test, vitest, jest, go test.

Design goals:
  - Show ONLY failures + final summary line (strip all passing output)
  - Group failures by file when multiple failures exist
  - Show "... and N more similar" for repeated failure patterns
  - Stack traces: first frame + last frame, collapse middle
"""
from __future__ import annotations

import re
from collections import defaultdict


# ---------------------------------------------------------------------------
# Stack trace collapser
# ---------------------------------------------------------------------------

def _collapse_stack_trace(lines: list[str], max_middle: int = 2) -> list[str]:
    """
    Collapse a stack trace: keep first + last frames, abbreviate middle.

    Heuristic: lines starting with 'File "', '  at ', or matching
    frame patterns are stack frames.
    """
    frame_re = re.compile(
        r'^\s*(File ".+", line \d+|at .+\(.+:\d+:\d+\)|at .+\(.+\)|\S+\.py:\d+|\S+\.(js|ts|jsx|tsx|rs|go):\d+)'
    )
    frames = [(i, ln) for i, ln in enumerate(lines) if frame_re.match(ln)]

    if len(frames) <= max_middle + 2:
        return lines  # short enough, no collapse needed

    # Keep lines before first frame unchanged (error message etc.)
    first_frame_idx = frames[0][0]
    last_frame_idx = frames[-1][0]

    before = lines[:first_frame_idx]
    first = [lines[i] for i, _ in frames[:1]]
    middle_count = len(frames) - 2
    collapsed = [f'    ... ({middle_count} frames collapsed)']
    last = [lines[i] for i, _ in frames[-1:]]
    after = lines[last_frame_idx + 1:]

    return before + first + collapsed + last + after


# ---------------------------------------------------------------------------
# Failure grouping
# ---------------------------------------------------------------------------

def _group_failures_by_file(failure_blocks: list[tuple[str, list[str]]]) -> str:
    """
    Given list of (test_name, failure_lines), group by file and format compactly.
    """
    by_file: dict[str, list[tuple[str, list[str]]]] = defaultdict(list)

    for test_name, lines in failure_blocks:
        # Extract file from test name (e.g. "tests/test_api.py::TestFoo::test_bar")
        parts = test_name.split('::')
        file_key = parts[0] if parts else 'unknown'
        by_file[file_key].append((test_name, lines))

    result: list[str] = []
    for file_key, failures in by_file.items():
        result.append(f'{file_key} ({len(failures)} failure{"s" if len(failures) != 1 else ""}):')
        for test_name, lines in failures:
            short_name = '::'.join(test_name.split('::')[1:]) or test_name
            result.append(f'  FAILED {short_name}')
            # Show up to 5 lines of the failure body
            body = [ln for ln in lines if ln.strip()][:5]
            for ln in body:
                result.append(f'    {ln.strip()}')
        result.append('')

    return '\n'.join(result).rstrip()


# ---------------------------------------------------------------------------
# Per-runner filters
# ---------------------------------------------------------------------------

def compress_pytest(output: str) -> str:
    """
    Keep only FAILED test blocks + final summary line.

    Groups failures by file when multiple files are affected.
    """
    lines = output.splitlines()

    # Extract failure blocks
    failure_blocks: list[tuple[str, list[str]]] = []
    summary_lines: list[str] = []
    current_test: str = ''
    current_body: list[str] = []
    in_failure = False
    in_short_summary = False
    short_summary: list[str] = []

    for line in lines:
        # Short test summary section
        if line.startswith('=') and 'short test summary' in line.lower():
            in_short_summary = True
            continue
        if in_short_summary:
            if line.startswith('='):
                in_short_summary = False
                summary_lines.append(line)
            else:
                short_summary.append(line)
            continue

        # Final summary lines (=== N passed, N failed ===)
        if line.startswith('=') and re.search(r'(passed|failed|error)', line, re.I):
            summary_lines.append(line)
            continue

        # Failure section header: "FAILED tests/foo.py::bar" or "_ FAILED bar _"
        fail_header = re.match(r'^(FAILED|ERROR)\s+(\S+)', line)
        if fail_header:
            if current_test:
                failure_blocks.append((current_test, current_body))
            current_test = fail_header.group(2)
            current_body = []
            in_failure = True
            continue

        # Section separator lines: "___ test_name ___"
        separator = re.match(r'^_+\s+(.+?)\s+_+\s*$', line)
        if separator:
            if in_failure and current_test:
                failure_blocks.append((current_test, current_body))
            current_test = separator.group(1)
            current_body = []
            in_failure = True
            continue

        if in_failure:
            current_body.append(line)

    if current_test and current_body:
        failure_blocks.append((current_test, current_body))

    if not failure_blocks and not short_summary:
        # No failures found — try to extract just the last summary line
        last_lines = [ln for ln in lines if ln.strip()]
        return last_lines[-1] if last_lines else '(all passed)'

    if not failure_blocks and short_summary:
        return '\n'.join(short_summary + summary_lines)

    # Build output
    parts: list[str] = []

    if len(failure_blocks) == 1:
        # Single failure: show full block (with stack trace collapsed)
        test_name, body = failure_blocks[0]
        parts.append(f'FAILED {test_name}')
        collapsed = _collapse_stack_trace(body)
        parts.extend(collapsed[:30])  # cap at 30 lines per failure
    else:
        # Multiple failures: group by file
        parts.append(_group_failures_by_file(failure_blocks))

    if summary_lines:
        parts.append('')
        parts.extend(summary_lines)

    return '\n'.join(parts)


def compress_cargo_test(output: str) -> str:
    """
    Keep only test failures and final summary.

    Groups failures, shows "... and N more" for similar panics.
    """
    lines = output.splitlines()
    failures: list[str] = []
    failure_detail: list[str] = []
    in_failures_section = False
    summary: list[str] = []

    for line in lines:
        if line.startswith('failures:') or line == 'failures:':
            in_failures_section = True
            continue
        if line.startswith('test result'):
            summary.append(line)
            in_failures_section = False
            continue
        if in_failures_section:
            if re.match(r'^\s+\S', line):
                failures.append(line.strip())
            else:
                failure_detail.append(line)
        elif 'FAILED' in line and '...' in line:
            failures.append(line.strip())

    result: list[str] = []
    if failures:
        result.append(f'{len(failures)} test failure{"s" if len(failures) != 1 else ""}:')
        # Show up to 20 failures; collapse the rest
        shown = failures[:20]
        hidden = len(failures) - 20
        for f in shown:
            result.append(f'  FAILED {f}')
        if hidden > 0:
            result.append(f'  ... and {hidden} more similar failures')

    if failure_detail:
        # Collapse stack traces in detail output
        collapsed = _collapse_stack_trace(failure_detail)
        result.extend(collapsed[:20])

    result.extend(summary)
    return '\n'.join(result) if result else (output.strip().splitlines()[-1] if output.strip() else '(no output)')


def compress_vitest(output: str) -> str:
    """Keep only failing tests and summary."""
    lines = output.splitlines()
    result: list[str] = []
    in_fail = False
    fail_count = 0
    pass_count = 0

    for line in lines:
        # Count stats
        if re.search(r'Tests\s+\d+', line):
            result.append(line)
            continue
        if re.search(r'Duration', line):
            result.append(line)
            continue

        # Failure markers
        if re.search(r'[x×✗]\s', line) or 'FAIL' in line:
            in_fail = True
            fail_count += 1
        elif re.search(r'[v✓✔]\s', line) or 'PASS' in line:
            in_fail = False
            pass_count += 1
            continue

        if in_fail:
            result.append(line)

    if not result:
        return f'(all {pass_count} passed)' if pass_count else '(all passed)'

    return '\n'.join(result)


def compress_jest(output: str) -> str:
    """Keep only failing tests and summary for jest."""
    lines = output.splitlines()
    result: list[str] = []
    in_fail_block = False
    fail_blocks: list[list[str]] = []
    current_block: list[str] = []

    for line in lines:
        stripped = line.strip()
        # Suite-level fail/pass
        if stripped.startswith('FAIL '):
            in_fail_block = True
            if current_block:
                fail_blocks.append(current_block)
            current_block = [line]
            continue
        if stripped.startswith('PASS '):
            in_fail_block = False
            continue

        # Failure body marker
        if stripped.startswith('●'):
            if current_block:
                fail_blocks.append(current_block)
            current_block = [line]
            in_fail_block = True
            continue

        # Summary lines
        if 'Tests:' in line or 'Test Suites:' in line or 'Snapshots:' in line:
            result.append(line)
            continue

        if in_fail_block:
            current_block.append(line)

    if current_block:
        fail_blocks.append(current_block)

    # Collapse each block's stack trace
    for block in fail_blocks:
        collapsed = _collapse_stack_trace(block)
        result = collapsed[:25] + result  # failures before summary

    return '\n'.join(result) if result else '(all passed)'


def compress_go_test(output: str) -> str:
    """Keep only failing tests and final summary for go test."""
    lines = output.splitlines()
    result: list[str] = []

    for line in lines:
        if re.search(r'^--- FAIL:|^FAIL\s|^ok\s', line):
            result.append(line)
        elif result and result[-1].startswith('--- FAIL:'):
            result.append(line)

    return '\n'.join(result) if result else output.strip().splitlines()[-1] if output.strip() else '(no output)'


# ---------------------------------------------------------------------------
# Dispatcher
# ---------------------------------------------------------------------------

def compress_test(runner: str, output: str) -> str:
    """Dispatch test compression by runner name."""
    if not output.strip():
        return output

    r = runner.lower()
    if 'pytest' in r or r == 'py.test':
        return compress_pytest(output)
    if 'cargo' in r:
        return compress_cargo_test(output)
    if 'vitest' in r:
        return compress_vitest(output)
    if 'jest' in r:
        return compress_jest(output)
    if r in ('go', 'go test'):
        return compress_go_test(output)

    # Generic: keep FAIL/ERROR lines + last 3 lines
    lines = output.splitlines()
    fail_lines = [ln for ln in lines if re.search(r'(FAIL|ERROR|fail|error)', ln)]
    if fail_lines:
        return '\n'.join(fail_lines + lines[-3:])
    return lines[-1] if lines else '(no output)'
