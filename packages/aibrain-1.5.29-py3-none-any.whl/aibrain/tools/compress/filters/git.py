"""
Git output compression filters.

Covers: status, diff, log, commit, push, pull, add, stash, fetch, branch,
        merge, rebase, cherry-pick, show, worktree, and any unknown git sub.

Design goals (beat RTK):
  - git diff:   zero context by default — show only +/- lines and headers.
                Configurable via AIBRAIN_COMPRESS_DIFF_CONTEXT env var.
  - git log:    force --oneline style, cap at 20 entries unless --all passed.
  - push/pull:  strip all object-counting noise, keep destination + summary.
  - status:     strip every hint line, collapse clean state to one line.
"""
from __future__ import annotations

import os
import re


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _strip_blank_edges(lines: list[str]) -> list[str]:
    """Remove leading/trailing blank lines from a list."""
    while lines and not lines[0].strip():
        lines.pop(0)
    while lines and not lines[-1].strip():
        lines.pop()
    return lines


def _default_diff_context() -> int:
    """Read context depth from env; default 0 (change lines only)."""
    try:
        return int(os.environ.get('AIBRAIN_COMPRESS_DIFF_CONTEXT', '0'))
    except (ValueError, TypeError):
        return 0


def _compact_diff_hunk(lines: list[str], context: int | None = None) -> list[str]:
    """
    Reduce diff context lines to *context* lines around changes.

    context=0 (default): show ONLY change lines (+/-) and diff/index/@@/--- /+++
    headers.  No unchanged context lines — maximum token savings.

    context=N: show N unchanged lines around each change.

    Unchanged lines beyond the context window are replaced with a single
    '...' separator.
    """
    if context is None:
        context = _default_diff_context()

    result: list[str] = []
    n = len(lines)
    keep: set[int] = set()

    for i, line in enumerate(lines):
        if line.startswith(('+', '-', '@@', 'diff', 'index', '---', '+++')):
            for j in range(max(0, i - context), min(n, i + context + 1)):
                keep.add(j)

    i = 0
    while i < n:
        if i in keep:
            result.append(lines[i])
            i += 1
        else:
            result.append('...')
            while i < n and i not in keep:
                i += 1

    # Deduplicate consecutive '...' separators
    deduped: list[str] = []
    for line in result:
        if line == '...' and deduped and deduped[-1] == '...':
            continue
        deduped.append(line)
    return deduped


_LOG_LIMIT = 20  # default cap for git log entries


# ---------------------------------------------------------------------------
# Sub-command filters
# ---------------------------------------------------------------------------

def filter_status(output: str) -> str:
    """
    Compact `git status`.

    Removes:
    - "On branch ..." header (redundant)
    - 'nothing to commit, working tree clean' -> single line
    - All verbose hints (use "git add", "use git restore", etc.)
    - Blank lines between sections

    Keeps:
    - Branch divergence lines ("Your branch is ahead/behind ...")
    - Staged / unstaged / untracked file listings
    """
    lines = output.splitlines()
    result: list[str] = []
    skip_patterns = [
        r'^\s*\(use "git',
        r'^\s*\(to restore',
        r'^\s*\(to unstage',
        r'^nothing added to commit',
        r'^no changes added to commit',
    ]
    skip_re = re.compile('|'.join(skip_patterns))

    for line in lines:
        if skip_re.search(line):
            continue
        if 'nothing to commit' in line:
            result.append('nothing to commit, working tree clean')
            continue
        result.append(line)

    return '\n'.join(_strip_blank_edges(result))


def filter_diff(output: str) -> str:
    """
    Compact `git diff`.

    Default (context=0): keep ONLY +/- change lines and diff/index/@@/--- /+++
    headers.  No unchanged context lines -- maximum token savings.

    Override: AIBRAIN_COMPRESS_DIFF_CONTEXT=2 to show 2 lines of context.
    """
    if not output.strip():
        return '(no diff)'
    lines = output.splitlines()
    compacted = _compact_diff_hunk(lines)
    return '\n'.join(compacted)


def filter_log(output: str, limit: int = _LOG_LIMIT) -> str:
    """
    Compact `git log` -- enforce one-line-per-commit format, cap at *limit*.

    If already --oneline style, just cap entries.
    Otherwise condense each full commit block to:
        <8-char hash> <message> (<author>, <date>)
    """
    lines = output.splitlines()
    if not lines:
        return output

    # Detect --oneline (each non-blank line starts with a short hash)
    oneline_re = re.compile(r'^[0-9a-f]{6,12}[\s*]')
    content_lines = [ln for ln in lines if ln.strip()]
    if content_lines and all(oneline_re.match(ln) for ln in content_lines):
        capped = content_lines[:limit]
        omitted = len(content_lines) - limit
        result = '\n'.join(capped)
        if omitted > 0:
            result += f'\n... and {omitted} more (pass --all to see all)'
        return result

    # Full-format log -- condense each commit to one line
    result: list[str] = []
    commit_hash = author = date = ''
    msg_lines: list[str] = []

    def flush() -> None:
        if commit_hash:
            short = commit_hash[:8]
            msg = ' '.join(msg_lines).strip()
            # Use only the date part (drop timezone) to keep it compact
            date_short = date.strip().split('+')[0].strip() if date else ''
            author_name = author.split('<')[0].strip() if author else ''
            meta = f'({author_name}, {date_short})' if author_name else ''
            result.append(f'{short} {msg} {meta}'.strip())

    for line in lines:
        if line.startswith('commit '):
            flush()
            commit_hash = line.split()[1] if len(line.split()) > 1 else ''
            author = date = ''
            msg_lines = []
        elif line.startswith('Author:'):
            author = line[7:].strip()
        elif line.startswith('Date:'):
            date = line[5:].strip()
        elif line.strip() and not line.startswith('Merge:'):
            msg_lines.append(line.strip())

    flush()

    capped = result[:limit]
    omitted = len(result) - limit
    out = '\n'.join(capped)
    if omitted > 0:
        out += f'\n... and {omitted} more (pass --all to see all)'
    return out


def filter_summary_only(output: str) -> str:
    """
    For commit / push / pull / add / fetch / stash.

    Keep only lines that carry meaningful info:
    - Lines with 'branch', 'HEAD', 'fast-forward', 'error', 'warning',
      file counts, byte counts, 'master', 'main', specific filenames.
    - Remove ALL progress lines (Counting objects, Compressing, Writing, etc.)
    - Remove blank lines and hint lines.
    """
    noise_patterns = [
        r'^Counting objects',
        r'^Compressing objects',
        r'^Writing objects',
        r'^remote:\s*Counting',
        r'^remote:\s*Compressing',
        r'^remote:\s*Writing',
        r'^remote:\s*Processing',
        r'^remote:\s*$',
        r'^Delta compression',
        r'^Resolving deltas',
        r'^\s*$',
        r'^hint:',
        r'^\(use "git',
        r'^Total \d+ \(delta',
        r'^\s*pack-reused',
    ]
    noise_re = re.compile('|'.join(noise_patterns))

    lines = [ln for ln in output.splitlines() if not noise_re.match(ln)]
    return '\n'.join(_strip_blank_edges(lines))


def filter_branch(output: str) -> str:
    """Compact `git branch` -- trim whitespace, keep all branch lines."""
    lines = [ln.rstrip() for ln in output.splitlines() if ln.strip()]
    return '\n'.join(lines)


def filter_stash(output: str) -> str:
    """Compact `git stash list` / `git stash` output."""
    return filter_summary_only(output)


def filter_show(output: str) -> str:
    """Compact `git show` -- diff section compressed, commit header kept."""
    lines = output.splitlines()
    diff_start = next((i for i, ln in enumerate(lines) if ln.startswith('diff --git')), None)
    if diff_start is None:
        return output.strip()
    header = lines[:diff_start]
    # Condense header: keep commit hash + subject + stats, drop Author/Date/blank
    condensed_header: list[str] = []
    for ln in header:
        if ln.startswith('commit ') or ln.startswith('    ') or re.search(r'\d+ file', ln):
            condensed_header.append(ln)
    diff_body = _compact_diff_hunk(lines[diff_start:])
    return '\n'.join(condensed_header + diff_body)


def filter_worktree(output: str) -> str:
    """Compact `git worktree list`."""
    lines = [ln.rstrip() for ln in output.splitlines() if ln.strip()]
    return '\n'.join(lines)


# ---------------------------------------------------------------------------
# Dispatcher
# ---------------------------------------------------------------------------

_SUBCOMMAND_MAP: dict[str, callable] = {
    'status':        filter_status,
    'diff':          filter_diff,
    'log':           filter_log,
    'commit':        filter_summary_only,
    'push':          filter_summary_only,
    'pull':          filter_summary_only,
    'add':           filter_summary_only,
    'fetch':         filter_summary_only,
    'stash':         filter_stash,
    'branch':        filter_branch,
    'show':          filter_show,
    'worktree':      filter_worktree,
    'merge':         filter_summary_only,
    'rebase':        filter_summary_only,
    'cherry-pick':   filter_summary_only,
    'reset':         filter_summary_only,
    'checkout':      filter_summary_only,
    'switch':        filter_summary_only,
    'restore':       filter_summary_only,
    'tag':           filter_branch,
    'remote':        filter_branch,
    'clone':         filter_summary_only,
    'init':          filter_summary_only,
}


def compress_git(subcommand: str, output: str) -> str:
    """
    Dispatch to the appropriate git filter.

    :param subcommand: First non-flag git argument ('status', 'diff', etc.)
    :param output: Combined stdout+stderr from the git command.
    :returns: Compressed string.
    """
    if not output.strip():
        return output

    fn = _SUBCOMMAND_MAP.get(subcommand, filter_summary_only)
    try:
        return fn(output)
    except Exception:
        return output
