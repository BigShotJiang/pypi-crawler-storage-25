"""
Shell hook installation for aibrain-compress.

Writes a wrapper function / alias to ~/.bashrc (Linux/macOS) or the
PowerShell profile (Windows) so plain `git <cmd>` output is auto-filtered.

Usage:
    aibrain-compress init          # install hook
    aibrain-compress uninstall     # remove hook
"""
from __future__ import annotations

import os
import platform
import re
import shutil
from datetime import datetime
from pathlib import Path


_BASH_MARKER_START = '# >>> aibrain-compress hook start >>>'
_BASH_MARKER_END   = '# <<< aibrain-compress hook end <<<'

# MAJOR #2 fixed: capture output to variable, compress it, preserve exit code.
_BASH_HOOK = """\
# >>> aibrain-compress hook start >>>
# AIBrain token compression hook — auto-installed by aibrain-compress init
git() {{
    local _out _ec
    _out=$(command git "$@" 2>&1)
    _ec=$?
    printf '%s\\n' "$_out" | aibrain-compress -- git "$@"
    return $_ec
}}
export -f git
# <<< aibrain-compress hook end <<<
"""

_PS_MARKER_START = '# >>> aibrain-compress hook start >>>'
_PS_MARKER_END   = '# <<< aibrain-compress hook end <<<'

# MAJOR #2 fixed: capture output, preserve $LASTEXITCODE, return it.
_PS_HOOK = """\
# >>> aibrain-compress hook start >>>
# AIBrain token compression hook — auto-installed by aibrain-compress init
function git {{
    $out = & (Get-Command git -CommandType Application | Select-Object -First 1).Source @args 2>&1 | Out-String
    $ec = $LASTEXITCODE
    $out | & aibrain-compress -- git @args
    exit $ec
}}
# <<< aibrain-compress hook end <<<
"""


def _is_windows() -> bool:
    return platform.system() == 'Windows'


def _get_shell_profile() -> Path:
    """Return the best shell profile path for the current platform."""
    if _is_windows():
        # PowerShell profile
        ps_profile = os.environ.get('PROFILE')
        if ps_profile:
            return Path(ps_profile)
        # Fallback: Documents\PowerShell\Microsoft.PowerShell_profile.ps1
        docs = Path.home() / 'Documents' / 'PowerShell' / 'Microsoft.PowerShell_profile.ps1'
        return docs
    else:
        # Prefer .bashrc; fall back to .bash_profile
        rc = Path.home() / '.bashrc'
        if not rc.exists():
            rc = Path.home() / '.bash_profile'
        return rc


def _get_backup_dir() -> Path:
    """Return the platform-appropriate config backup directory."""
    return Path.home() / '.aibrain' / 'config_backup'


def _backup_profile(path: Path) -> None:
    """
    Back up the shell profile before modification.

    MAJOR #3: Config backup rule — backup before ANY write to a profile file.
    Keeps last 3 backups for this specific profile; prunes older ones.
    Backup location: ~/.aibrain/config_backup/
    Timestamp format: YYYYMMDD_HHMMSS
    """
    if not path.exists():
        return  # nothing to back up

    backup_dir = _get_backup_dir()
    backup_dir.mkdir(parents=True, exist_ok=True)

    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    stem = path.name  # e.g. ".bashrc" or "Microsoft.PowerShell_profile.ps1"
    backup_path = backup_dir / f'{stem}_{timestamp}'
    shutil.copy2(str(path), str(backup_path))

    # Prune: keep only the 3 most recent backups for this specific profile file
    existing_backups = sorted(
        backup_dir.glob(f'{stem}_*'),
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )
    for old in existing_backups[3:]:
        old.unlink(missing_ok=True)


def _remove_hook_block(text: str, start: str, end: str) -> str:
    """Strip a delimited block from text (handles missing block gracefully)."""
    pattern = re.compile(
        re.escape(start) + r'.*?' + re.escape(end) + r'\n?',
        re.DOTALL
    )
    return pattern.sub('', text)


def install_hook(profile_path: Path | None = None) -> str:
    """
    Install the shell hook.  Returns a status message.

    :param profile_path: Override the auto-detected profile path (for testing).
    """
    path = profile_path or _get_shell_profile()
    path.parent.mkdir(parents=True, exist_ok=True)

    # MAJOR #3: backup before any modification
    _backup_profile(path)

    existing = path.read_text(encoding='utf-8') if path.exists() else ''

    # Remove any existing block first (idempotent)
    cleaned = _remove_hook_block(existing, _BASH_MARKER_START, _BASH_MARKER_END)

    hook_block = _PS_HOOK if _is_windows() else _BASH_HOOK

    new_content = cleaned.rstrip('\n') + '\n\n' + hook_block + '\n'
    path.write_text(new_content, encoding='utf-8')

    return f'Hook installed in {path}\nRestart your shell or run: source {path}'


def uninstall_hook(profile_path: Path | None = None) -> str:
    """
    Remove the shell hook.  Returns a status message.
    """
    path = profile_path or _get_shell_profile()

    if not path.exists():
        return f'No profile found at {path} — nothing to remove.'

    # MAJOR #3: backup before any modification
    _backup_profile(path)

    existing = path.read_text(encoding='utf-8')
    cleaned = _remove_hook_block(existing, _BASH_MARKER_START, _BASH_MARKER_END)

    if cleaned == existing:
        return 'No aibrain-compress hook found — nothing to remove.'

    path.write_text(cleaned.rstrip('\n') + '\n', encoding='utf-8')
    return f'Hook removed from {path}'
