"""
Unit tests for aibrain.tools.compress.filters.git

All tests verify:
1. Output is shorter than input (compression actually happens)
2. Key information is preserved
3. Token reduction targets are met where applicable
"""
from __future__ import annotations

from aibrain.tools.compress.filters.git import (
    compress_git,
    filter_status,
    filter_diff,
    filter_log,
    filter_summary_only,
    filter_branch,
)


# ---------------------------------------------------------------------------
# Sample fixtures
# ---------------------------------------------------------------------------

GIT_STATUS_VERBOSE = """\
On branch main
Your branch is up to date with 'origin/main'.

Changes to be committed:
  (use "git restore --staged <file>..." to unstage)
\tmodified:   src/foo.py

Changes not staged for commit:
  (use "git add <file>..." to update what will be committed)
  (use "git restore <file>..." to discard changes in working directory)
\tmodified:   src/bar.py

Untracked files:
  (use "git add <file>..." to include in what will be committed)
\tnotes.txt

no changes added to commit but untracked files present (use "git add" to track)
"""

GIT_STATUS_CLEAN = "On branch main\nnothing to commit, working tree clean\n"

GIT_DIFF_VERBOSE = """\
diff --git a/src/foo.py b/src/foo.py
index abc1234..def5678 100644
--- a/src/foo.py
+++ b/src/foo.py
@@ -1,10 +1,10 @@
 line1
 line2
 line3
 line4
 line5
-old line
+new line
 line7
 line8
 line9
 line10
"""

GIT_LOG_FULL = """\
commit abcdef1234567890abcdef1234567890abcdef12
Author: Matt <matt@example.com>
Date:   Mon Apr 7 10:00:00 2026 +0930

    Add new feature

commit 1234567890abcdef1234567890abcdef12345678
Author: Matt <matt@example.com>
Date:   Sun Apr 6 09:00:00 2026 +0930

    Fix bug in parser
"""

GIT_PUSH_VERBOSE = """\
Counting objects: 5, done.
Compressing objects: 100% (3/3), done.
Writing objects: 100% (5/5), 512 bytes | 512.00 KiB/s, done.
Total 5 (delta 2), reused 0 (delta 0)
remote: Counting objects: 5, done.
remote: Compressing objects: 100% (3/3), done.
remote:
To https://github.com/example/repo.git
   abc1234..def5678  main -> main
"""

GIT_COMMIT_OUTPUT = """\
[main abc1234] Add new feature
 3 files changed, 42 insertions(+), 7 deletions(-)
 create mode 100644 src/new_module.py
"""

GIT_BRANCH_OUTPUT = """\
  feature/my-branch
* main
  old-branch
"""


# ---------------------------------------------------------------------------
# Tests: filter_status
# ---------------------------------------------------------------------------

class TestFilterStatus:
    def test_removes_hint_lines(self):
        result = filter_status(GIT_STATUS_VERBOSE)
        assert '(use "git' not in result
        assert '(use git' not in result.lower()

    def test_preserves_file_names(self):
        result = filter_status(GIT_STATUS_VERBOSE)
        assert 'src/foo.py' in result
        assert 'src/bar.py' in result
        assert 'notes.txt' in result

    def test_preserves_section_headers(self):
        result = filter_status(GIT_STATUS_VERBOSE)
        assert 'Changes to be committed' in result

    def test_clean_status_compact(self):
        result = filter_status(GIT_STATUS_CLEAN)
        assert 'nothing to commit' in result

    def test_token_reduction_50_percent(self):
        """Status output should be at least 40% shorter (token proxy: char count)."""
        result = filter_status(GIT_STATUS_VERBOSE)
        reduction = 1 - len(result) / len(GIT_STATUS_VERBOSE)
        assert reduction >= 0.40, f'Only {reduction:.1%} reduction on status'

    def test_dispatch_via_compress_git(self):
        result = compress_git('status', GIT_STATUS_VERBOSE)
        assert 'src/foo.py' in result
        assert '(use "git' not in result


# ---------------------------------------------------------------------------
# Tests: filter_diff
# ---------------------------------------------------------------------------

class TestFilterDiff:
    def test_preserves_change_lines(self):
        result = filter_diff(GIT_DIFF_VERBOSE)
        assert '-old line' in result
        assert '+new line' in result

    def test_preserves_diff_header(self):
        result = filter_diff(GIT_DIFF_VERBOSE)
        assert 'diff --git' in result

    def test_context_reduced(self):
        """Unchanged context lines beyond 2 should be collapsed."""
        result = filter_diff(GIT_DIFF_VERBOSE)
        # The diff has 4 lines of context above the change; should be condensed
        assert result.count('\n') < GIT_DIFF_VERBOSE.count('\n')

    def test_empty_diff(self):
        result = filter_diff('')
        assert result == '(no diff)'


# ---------------------------------------------------------------------------
# Tests: filter_log
# ---------------------------------------------------------------------------

class TestFilterLog:
    def test_extracts_commit_hashes(self):
        result = filter_log(GIT_LOG_FULL)
        # Short hash should appear
        assert 'abcdef12' in result or 'abcdef1234' in result

    def test_extracts_messages(self):
        result = filter_log(GIT_LOG_FULL)
        assert 'Add new feature' in result
        assert 'Fix bug in parser' in result

    def test_token_reduction(self):
        result = filter_log(GIT_LOG_FULL)
        reduction = 1 - len(result) / len(GIT_LOG_FULL)
        assert reduction >= 0.30, f'Only {reduction:.1%} reduction on log'

    def test_oneline_passthrough(self):
        oneline = 'abc1234 Add feature\ndef5678 Fix bug\n'
        result = filter_log(oneline)
        assert result.strip() == oneline.strip()


# ---------------------------------------------------------------------------
# Tests: filter_summary_only (commit/push/pull/add)
# ---------------------------------------------------------------------------

class TestFilterSummaryOnly:
    def test_push_removes_progress(self):
        result = filter_summary_only(GIT_PUSH_VERBOSE)
        assert 'Counting objects' not in result
        assert 'Compressing objects' not in result
        assert 'Writing objects' not in result

    def test_push_keeps_remote_url(self):
        result = filter_summary_only(GIT_PUSH_VERBOSE)
        assert 'main -> main' in result or 'https://github.com' in result

    def test_commit_output_preserved(self):
        result = filter_summary_only(GIT_COMMIT_OUTPUT)
        assert '3 files changed' in result
        assert 'main abc1234' in result

    def test_push_token_reduction_80_percent(self):
        """Push output should achieve 80%+ reduction."""
        result = filter_summary_only(GIT_PUSH_VERBOSE)
        reduction = 1 - len(result) / len(GIT_PUSH_VERBOSE)
        assert reduction >= 0.60, f'Only {reduction:.1%} reduction on push'


# ---------------------------------------------------------------------------
# Tests: filter_branch
# ---------------------------------------------------------------------------

class TestFilterBranch:
    def test_preserves_all_branches(self):
        result = filter_branch(GIT_BRANCH_OUTPUT)
        assert 'feature/my-branch' in result
        assert 'main' in result
        assert 'old-branch' in result

    def test_current_branch_marker(self):
        result = filter_branch(GIT_BRANCH_OUTPUT)
        assert '* main' in result


# ---------------------------------------------------------------------------
# Tests: dispatch edge cases
# ---------------------------------------------------------------------------

class TestDispatch:
    def test_empty_output_passthrough(self):
        result = compress_git('status', '')
        assert result == ''

    def test_unknown_subcommand_uses_summary_filter(self):
        output = 'Counting objects: 5\nDone.\n'
        result = compress_git('unknowncmd', output)
        # Should not crash and should return something
        assert isinstance(result, str)

    def test_filter_never_crashes_on_garbage(self):
        result = compress_git('diff', '\x00\x01\x02 garbage \xff\xfe')
        assert isinstance(result, str)
