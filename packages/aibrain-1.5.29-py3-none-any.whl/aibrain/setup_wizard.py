#!/usr/bin/env python3
"""
AIBrain Setup Wizard — First-run bootstrapper.

Guides a new user through interactive setup:
1. Check prerequisites (Python 3.10+, Node 18+, pip packages)
2. Interactive interview (agent name, location, email, GitHub, workflows)
3. Generate config.json
4. Initialize memory.db with seed memories
5. Install frontend dependencies
6. Create scheduled_jobs.json with selected workflows
7. Test connectivity (IMAP, GitHub API, weather API)
8. Connect your AI agent
9. Print startup summary

Saves partial progress so users can resume after errors.
Uses only stdlib + urllib (no external deps beyond what AIBrain requires).
"""

import imaplib
import json
import os
import platform
import sqlite3
import subprocess
import sys
import urllib.error
import urllib.request
from datetime import datetime
from pathlib import Path

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------

_INSTALL_DIR = Path(__file__).parent.resolve()


def _aibrain_version() -> str:
    """Canonical aibrain version read. Single source of truth.

    Priority:
    1. installed package metadata via importlib.metadata.version("aibrain")
       — matches pyproject.toml [project].version exactly.
    2. aibrain.__version__ fallback (editable / source-tree install).
    3. "0.0.0+unknown" last-resort so telemetry never crashes.

    Never hardcode a version string here or anywhere else — the drift
    between pyproject.toml (1.5.26), package.json (1.2.6), and this
    POST body was the bug this helper fixes (task 1DYHbpIrKAk).
    """
    try:
        from importlib.metadata import version as _pkg_version  # stdlib 3.8+
        return _pkg_version("aibrain")
    except Exception:
        pass
    try:
        import aibrain  # noqa: WPS433 — local import is intentional
        return getattr(aibrain, "__version__", "0.0.0+unknown")
    except Exception:
        return "0.0.0+unknown"


def _resolve_aibrain_dir() -> Path:
    """Resolve the user data directory for AIBrain.

    Priority:
    1. AIBRAIN_ROOT env var (explicit override, set by __main__.py before import)
    2. ~/aibrain if running from site-packages (clean pip install)
    3. _INSTALL_DIR (dev/editable install — source tree IS the root)

    The original module-level default was _INSTALL_DIR, which caused ghost DB files
    inside site-packages on clean pip installs (Fix #3 — project root missing).
    """
    if "AIBRAIN_ROOT" in os.environ:
        return Path(os.environ["AIBRAIN_ROOT"])
    # On a clean pip install the package lives in site-packages; data must go in ~/aibrain.
    if "site-packages" in str(_INSTALL_DIR):
        user_dir = Path.home() / "aibrain"
        user_dir.mkdir(parents=True, exist_ok=True)
        return user_dir
    # Dev/editable install — source tree is the root (original behavior)
    return _INSTALL_DIR

AIBRAIN_DIR = _resolve_aibrain_dir()
BACKEND_DIR = _INSTALL_DIR / "backend"
FRONTEND_DIR = _INSTALL_DIR / "frontend"
MEMORY_DIR = _INSTALL_DIR / "memory"
CONFIG_PATH = AIBRAIN_DIR / "config.json"
PROGRESS_PATH = AIBRAIN_DIR / ".setup_progress.json"
SEED_PATH = MEMORY_DIR / "seed_memories.json"
STARTER_PATH = _INSTALL_DIR / "data" / "starter_memories.json"
SCHEDULED_JOBS_PATH = AIBRAIN_DIR / "scheduled_jobs.json"
DB_PATH = AIBRAIN_DIR / "aibrain.db"

# ---------------------------------------------------------------------------
# Colors
# ---------------------------------------------------------------------------

COLORS = {
    "reset": "\033[0m",
    "teal": "\033[38;2;245;158;11m",
    "dim": "\033[90m",
    "bold": "\033[1m",
    "red": "\033[91m",
    "green": "\033[92m",
    "yellow": "\033[93m",
}

# ---------------------------------------------------------------------------
# Step counter for the new 4-question interactive flow
# ---------------------------------------------------------------------------

_WIZARD_TOTAL_STEPS = 4
_wizard_step = 0


def _next_step(msg):
    global _wizard_step
    _wizard_step += 1
    step_header(_wizard_step, _WIZARD_TOTAL_STEPS, msg)


def c(color, text):
    """Colorize text for terminal output."""
    return f"{COLORS.get(color, '')}{text}{COLORS['reset']}"


def banner():
    print(f"""
{c('teal', '  +==============================================+')}
{c('teal', '  |')}  {c('bold', 'AIBrain')} -- Setup Wizard                    {c('teal', '|')}
{c('teal', '  |')}  {c('dim', 'Portable Agent Operating System')}             {c('teal', '|')}
{c('teal', '  +==============================================+')}
""")


def step_header(num, total, msg):
    print(f"\n{c('teal', f'  [{num}/{total}]')} {c('bold', msg)}")
    print(f"  {c('dim', '-' * 50)}")


def ok(msg):
    print(f"  {c('green', '[OK]')} {msg}")


def warn(msg):
    print(f"  {c('yellow', '[!!]')} {msg}")


def fail(msg):
    print(f"  {c('red', '[FAIL]')} {msg}")


def info(msg):
    print(f"  {c('dim', msg)}")


def prompt(label, default="", password=False):
    """Prompt user for input. Returns default on empty/interrupt."""
    suffix = f" [{default}]" if default else ""
    try:
        if password:
            # Use getpass if available, fall back to regular input
            try:
                import getpass
                value = getpass.getpass(f"  {c('teal', label)}{suffix}: ")
            except Exception:
                value = input(f"  {c('teal', label)}{suffix}: ")
        else:
            value = input(f"  {c('teal', label)}{suffix}: ")
        return value.strip() or default
    except (EOFError, KeyboardInterrupt):
        print()
        return default


def confirm(label, default=True):
    """Yes/no prompt. Returns bool."""
    hint = "Y/n" if default else "y/N"
    try:
        answer = input(f"  {c('teal', label)} [{hint}]: ").strip().lower()
        if not answer:
            return default
        return answer in ("y", "yes")
    except (EOFError, KeyboardInterrupt):
        print()
        return default


def run_cmd(cmd, cwd=None, timeout=120):
    """Run shell command, return (success, stdout).

    Uses shell=False with shlex.split for safety against command injection.
    Pass a list directly to bypass splitting.
    """
    import shlex
    try:
        args = cmd if isinstance(cmd, list) else shlex.split(cmd)
        result = subprocess.run(
            args, shell=False, cwd=cwd, capture_output=True,
            text=True, timeout=timeout
        )
        return result.returncode == 0, result.stdout.strip()
    except subprocess.TimeoutExpired:
        return False, "Timed out"
    except Exception as e:
        return False, str(e)


def http_get_json(url, timeout=10):
    """GET a URL and parse JSON response. Returns (success, data_or_error)."""
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "AIBrain-Setup/1.0"})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return True, json.loads(resp.read().decode())
    except Exception as e:
        return False, str(e)


# ---------------------------------------------------------------------------
# Progress tracking — save/load partial state
# ---------------------------------------------------------------------------

def load_progress():
    """Load partial progress from previous run."""
    if PROGRESS_PATH.exists():
        try:
            return json.loads(PROGRESS_PATH.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            pass
    return {"completed_steps": [], "config": {}}


def save_progress(progress):
    """Save progress so user can resume."""
    progress["last_updated"] = datetime.now().isoformat()
    PROGRESS_PATH.write_text(json.dumps(progress, indent=2), encoding="utf-8")


def clear_progress():
    """Remove progress file after successful completion."""
    if PROGRESS_PATH.exists():
        PROGRESS_PATH.unlink()


# ---------------------------------------------------------------------------
# Step 1: Check prerequisites
# ---------------------------------------------------------------------------

def check_prerequisites(progress):
    step_header(1, 11, "Checking prerequisites")
    issues = []

    # Python version
    py_ver = sys.version.split()[0]
    if sys.version_info >= (3, 10):
        ok(f"Python {py_ver}")
    else:
        fail(f"Python {py_ver} -- need 3.10+")
        issues.append("Python 3.10+ required")

    # Node.js
    success, node_ver = run_cmd("node --version")
    if success:
        # Parse version: v18.17.0 -> 18
        try:
            major = int(node_ver.lstrip("v").split(".")[0])
            if major >= 18:
                ok(f"Node.js {node_ver}")
            else:
                fail(f"Node.js {node_ver} -- need 18+")
                issues.append("Node.js 18+ required")
        except ValueError:
            ok(f"Node.js {node_ver} (version check inconclusive)")
    else:
        fail("Node.js not found")
        info("Install from: https://nodejs.org")
        issues.append("Node.js not installed")

    # npm
    success, npm_ver = run_cmd("npm --version")
    if success:
        ok(f"npm {npm_ver}")
    else:
        warn("npm not found (usually installed with Node.js)")

    # pip packages: fastapi, uvicorn, apscheduler
    required_pkgs = ["fastapi", "uvicorn", "apscheduler"]
    missing_pkgs = []
    for pkg in required_pkgs:
        success, _ = run_cmd(f"{sys.executable} -c \"import {pkg}\"")
        if success:
            ok(f"Python package: {pkg}")
        else:
            warn(f"Python package: {pkg} (not installed)")
            missing_pkgs.append(pkg)

    if missing_pkgs:
        info(f"Missing packages will be installed: {', '.join(missing_pkgs)}")
        install = confirm("Install missing Python packages now?")
        if install:
            pkg_str = " ".join(missing_pkgs)
            success, output = run_cmd(
                [sys.executable, "-m", "pip", "install"] + missing_pkgs + ["--quiet"]
            )
            if success:
                ok(f"Installed: {pkg_str}")
            else:
                fail(f"Install failed: {output}")
                issues.append(f"Could not install: {pkg_str}")

    # Optional: docker
    success, docker_ver = run_cmd("docker --version")
    if success:
        ok(f"Docker: {docker_ver.split(',')[0]}")
    else:
        info("Docker not found (optional -- needed for containerized deployment)")

    # Optional: playwright
    success, _ = run_cmd(f"{sys.executable} -c \"import playwright\"")
    if success:
        ok("Playwright: installed")
    else:
        info("Playwright not found (optional -- needed for browser automation)")

    # Platform
    ok(f"Platform: {platform.system()} {platform.release()}")

    if issues:
        print()
        fail("Prerequisites not met:")
        for issue in issues:
            print(f"    - {issue}")
        if not confirm("Continue anyway? (some features may not work)"):
            return False

    progress["completed_steps"].append("prerequisites")
    save_progress(progress)
    return True


# ---------------------------------------------------------------------------
# Helper: signing key + .aibrainrc writer
# ---------------------------------------------------------------------------

def _ensure_signing_key():
    import secrets
    env_file = Path.home() / ".aibrain.env"
    if os.environ.get("AIBRAIN_SIGNING_KEY"):
        return
    if env_file.exists():
        for line in env_file.read_text(encoding="utf-8").splitlines():
            if line.startswith("AIBRAIN_SIGNING_KEY="):
                os.environ["AIBRAIN_SIGNING_KEY"] = line.split("=", 1)[1].strip()
                return
    key = secrets.token_hex(32)
    os.environ["AIBRAIN_SIGNING_KEY"] = key
    with open(env_file, "a", encoding="utf-8") as f:
        f.write(f"\nAIBRAIN_SIGNING_KEY={key}\n")
    ok(f"AIBRAIN_SIGNING_KEY auto-generated → {env_file}")


def _write_aibrainrc(path: Path):
    try:
        aibrainrc = Path.home() / ".aibrainrc"
        aibrainrc.write_text(str(path), encoding="utf-8")
    except OSError:
        pass


# ---------------------------------------------------------------------------
# Step 2: Interactive interview (DEPRECATED — replaced by interactive_setup)
# ---------------------------------------------------------------------------

def _interactive_interview_DEPRECATED(progress):
    step_header(2, 11, "Agent configuration")

    cfg = progress.get("config", {})

    # --- Auto-detect: scan env vars and .env files, pre-populate config ---
    print()
    info("Scanning environment for API keys and credentials...")
    discovered, sources = scan_environment()
    if sources:
        print()
        for config_key, source in sources:
            ok(f"Found {config_key} from {source}")
        print()
        info("Discovered values will be used as defaults (press Enter to accept).")
        # Pre-populate config with discovered values (don't overwrite user's previous answers)
        for config_key, _ in sources:
            if config_key not in cfg or not cfg[config_key]:
                cfg[config_key] = discovered[config_key]
    else:
        info("No API keys found in environment or .env files.")
    print()

    # --- Agent name ---
    print()
    info("What should your agent be called?")
    _default_name = os.environ.get("AGENT_ID", "Agent")
    cfg["agent_name"] = prompt("Agent name", cfg.get("agent_name", _default_name))
    ok(f"Agent name: {cfg['agent_name']}")

    # --- Location ---
    print()
    info("Location is used for weather briefings and local context.")
    info("Enter a city name and we will look up coordinates automatically.")
    info("Press Enter to skip.")
    city = prompt("City name", cfg.get("location_name", ""))

    if city:
        cfg["location_name"] = city
        info(f"Looking up coordinates for '{city}'...")
        success, data = http_get_json(
            f"https://geocoding-api.open-meteo.com/v1/search?name={urllib.request.quote(city)}&count=5&language=en"
        )
        if success and data.get("results"):
            results = data["results"]
            if len(results) == 1:
                r = results[0]
                cfg["location_lat"] = r["latitude"]
                cfg["location_lon"] = r["longitude"]
                label = f"{r.get('name', city)}, {r.get('admin1', '')}, {r.get('country', '')}"
                ok(f"Found: {label} ({r['latitude']}, {r['longitude']})")
            else:
                print()
                info("Multiple matches found:")
                for i, r in enumerate(results[:5], 1):
                    label = f"{r.get('name', '')}, {r.get('admin1', '')}, {r.get('country', '')}"
                    print(f"    {c('teal', str(i))}. {label} ({r['latitude']}, {r['longitude']})")
                choice = prompt("Pick a number", "1")
                try:
                    idx = int(choice) - 1
                    if 0 <= idx < len(results):
                        r = results[idx]
                        cfg["location_lat"] = r["latitude"]
                        cfg["location_lon"] = r["longitude"]
                        ok(f"Location set: {r.get('name', city)} ({r['latitude']}, {r['longitude']})")
                    else:
                        warn("Invalid choice, skipping location")
                except ValueError:
                    warn("Invalid input, skipping location")
        else:
            warn(f"Could not geocode '{city}'. You can set lat/lon manually in config.json.")
            cfg["location_lat"] = 0
            cfg["location_lon"] = 0
    else:
        info("Location skipped. Set later in config.json.")

    # --- Email setup ---
    print()
    info("Email lets your agent send briefings, triage your inbox, and auto-reply.")
    info("Gmail recommended. You will need an App Password (not your regular password).")
    info("Press Enter to skip.")
    email = prompt("Gmail address", cfg.get("agent_email", ""))

    if email:
        cfg["agent_email"] = email
        cfg["email_to"] = email  # Default: send briefings to self
        cfg["agent_smtp_host"] = "smtp.gmail.com"
        cfg["agent_imap_host"] = "imap.gmail.com"

        print()
        info("To create a Gmail App Password:")
        info("  1. Go to https://myaccount.google.com/apppasswords")
        info("  2. You need 2-Factor Authentication enabled first")
        info("  3. Select 'Mail' and your device, then Generate")
        info("  4. Copy the 16-character password (spaces are fine)")
        info("Press Enter to skip (configure later).")
        app_pass = prompt("App password", cfg.get("agent_email_password", ""), password=True)
        if app_pass:
            # Strip spaces from app password (Google formats them with spaces)
            cfg["agent_email_password"] = app_pass.replace(" ", "")
            ok("App password saved")
        else:
            info("App password skipped. Email workflows will be limited until configured.")

        # Additional email accounts to monitor
        print()
        info("You can add extra email accounts for the agent to monitor (read-only).")
        info("Press Enter to skip.")
        extra_accounts = []
        while True:
            extra = prompt("Additional email to monitor (Enter to finish)", "")
            if not extra:
                break
            acct = {
                "label": extra.split("@")[0] if "@" in extra else "extra",
                "email": extra,
                "app_password": "",
                "imap_host": "imap.gmail.com" if "gmail" in extra else "imap.mail.yahoo.com" if "yahoo" in extra else "",
                "smtp_host": "smtp.gmail.com" if "gmail" in extra else "smtp.mail.yahoo.com" if "yahoo" in extra else "",
                "monitor": True,
                "can_reply": False,
            }
            extra_pass = prompt(f"  App password for {extra} (Enter to skip)", "", password=True)
            if extra_pass:
                acct["app_password"] = extra_pass.replace(" ", "")
            if not acct["imap_host"]:
                acct["imap_host"] = prompt(f"  IMAP host for {extra}", "")
                acct["smtp_host"] = prompt(f"  SMTP host for {extra}", "")
            extra_accounts.append(acct)
            ok(f"Added: {extra}")

        if extra_accounts:
            cfg["email_accounts"] = extra_accounts
    else:
        info("Email skipped. Set later in config.json.")

    # --- GitHub token ---
    print()
    info("A GitHub token lets your agent monitor repos, check PRs, and track issues.")
    info("Create one at: https://github.com/settings/tokens/new")
    info("  Scopes needed: repo, read:org (for private repos)")
    info("Press Enter to skip.")
    gh_token = prompt("GitHub token", cfg.get("github_token", ""), password=True)

    if gh_token:
        cfg["github_token"] = gh_token
        gh_user = prompt("GitHub username", cfg.get("github_username", ""))
        if gh_user:
            cfg["github_username"] = gh_user
        ok("GitHub configured")
    else:
        info("GitHub skipped. Set later in config.json.")

    # --- Anthropic API key ---
    print()
    info("An Anthropic API key enables AI-powered workflows (email drafting, research).")
    info("Get one at: https://console.anthropic.com/settings/keys")
    info("Press Enter to skip.")
    api_key = prompt("Anthropic API key", cfg.get("anthropic_api_key", ""), password=True)
    if api_key:
        cfg["anthropic_api_key"] = api_key
        ok("Anthropic API key saved")
    else:
        info("Anthropic API key skipped. AI-powered workflows will be limited.")

    # --- OpenAI API key ---
    print()
    info("An OpenAI API key enables GPT-based workflows as an alternative or fallback LLM.")
    info("Get one at: https://platform.openai.com/api-keys")
    info("Press Enter to skip.")
    openai_key = prompt("OpenAI API key", cfg.get("openai_api_key", ""), password=True)
    if openai_key:
        cfg["openai_api_key"] = openai_key
        ok("OpenAI API key saved")
    else:
        info("OpenAI API key skipped.")

    # --- Ollama (local LLM) ---
    print()
    info("Ollama runs LLMs locally -- fully private, no API key needed.")
    info("Install from: https://ollama.ai")
    info("If Ollama is running, enter its URL. Default: http://localhost:11434")
    info("Press Enter to skip.")
    ollama_url = prompt("Ollama URL", cfg.get("ollama_url", ""))
    if ollama_url:
        cfg["ollama_url"] = ollama_url
        ollama_model = prompt("Ollama model name", cfg.get("ollama_model", "llama3.2"))
        cfg["ollama_model"] = ollama_model
        ok(f"Ollama configured: {ollama_url} / {ollama_model}")
    else:
        info("Ollama skipped.")

    # --- Telegram ---
    print()
    info("Telegram lets your agent send you notifications and alerts.")
    info("Create a bot via @BotFather on Telegram to get a token.")
    info("Press Enter to skip.")
    tg_token = prompt("Telegram bot token", cfg.get("telegram_bot_token", ""), password=True)
    if tg_token:
        cfg["telegram_bot_token"] = tg_token
        tg_chat = prompt("Telegram chat ID", cfg.get("telegram_chat_id", ""))
        if tg_chat:
            cfg["telegram_chat_id"] = tg_chat
        ok("Telegram configured")
    else:
        info("Telegram skipped.")

    # --- Networking (Tailscale mesh) ---
    print()
    info("AIBrain uses Tailscale for secure agent-to-agent networking.")
    info("Tailscale creates an encrypted mesh — your agents talk directly,")
    info("no port forwarding, no public exposure, works across NAT.")
    print()

    try:
        from aibrain_networking import (
            is_tailscale_installed, is_tailscale_ready,
            get_tailscale_ip, get_tailscale_hostname, get_peers,
            install_tailscale, authenticate_tailscale,
            configure_peer_discovery,
        )

        if is_tailscale_installed():
            ok("Tailscale installed")
            if is_tailscale_ready():
                ts_ip = get_tailscale_ip()
                ts_host = get_tailscale_hostname()
                peers = get_peers()
                online = [p for p in peers if p["online"]]
                ok(f"Connected: {ts_ip} ({ts_host})")
                ok(f"Tailnet peers: {len(online)} online")
                ts_config = configure_peer_discovery()
                cfg.update(ts_config)

                # Auto-set peer URL if exactly one online peer
                if len(online) == 1:
                    peer = online[0]
                    cfg["peer_url"] = f"http://{peer['ip']}:7800"
                    cfg["peer_name"] = peer["hostname"]
                    ok(f"Auto-connected to peer: {peer['hostname']} ({peer['ip']})")
                elif len(online) > 1:
                    info("Multiple peers found:")
                    for i, p in enumerate(online, 1):
                        print(f"    {i}. {p['hostname']} ({p['ip']}) [{p['os']}]")
                    choice = prompt("Connect to peer #", "1")
                    try:
                        idx = int(choice) - 1
                        peer = online[idx]
                        cfg["peer_url"] = f"http://{peer['ip']}:7800"
                        cfg["peer_name"] = peer["hostname"]
                        ok(f"Connected to peer: {peer['hostname']} ({peer['ip']})")
                    except (ValueError, IndexError):
                        info("Skipped peer selection — configure later in settings.")

                ok("Mesh networking configured via Tailscale")
            else:
                warn("Tailscale installed but not connected.")
                if confirm("Authenticate now?", default=True):
                    auth_key = prompt("Auth key (blank for browser login)", "")
                    if authenticate_tailscale(auth_key):
                        ok("Tailscale connected!")
                        ts_config = configure_peer_discovery()
                        cfg.update(ts_config)
                    else:
                        warn("Auth failed — run 'tailscale up' manually later.")
        else:
            if confirm("Install Tailscale for mesh networking? (Pro feature)", default=True):
                info("Installing Tailscale...")
                if install_tailscale():
                    ok("Tailscale installed!")
                    info("Run 'tailscale up' to authenticate, then re-run setup.")
                else:
                    warn("Auto-install failed. Get it from: https://tailscale.com/download")
            else:
                info("Skipped — running in local-only mode.")

    except ImportError:
        warn("aibrain_networking module not found — skipping mesh setup.")

    # Legacy distributed mode fallback (no Tailscale)
    if not cfg.get("networking", {}).get("transport") == "tailscale":
        headless = (
            (platform.system() == "Linux" and not os.environ.get("DISPLAY"))
            or bool(os.environ.get("SSH_CLIENT"))
        )
        if headless or confirm("Configure manual peer connection (without Tailscale)?", default=False):
            cfg["distributed_mode"] = True
            peer_url = prompt("Peer agent URL (e.g. http://192.168.1.x:7800)", cfg.get("peer_url", ""))
            if peer_url:
                cfg["peer_url"] = peer_url
            peer_name = prompt("Peer agent name", cfg.get("peer_name", ""))
            if peer_name:
                cfg["peer_name"] = peer_name
            ok("Manual peer connection configured")

    # --- Auto-set LLM provider ---
    cfg["llm_provider"] = _determine_llm_provider(cfg)
    if cfg["llm_provider"] != "auto":
        ok(f"LLM provider auto-detected: {cfg['llm_provider']}")

    # --- Workflow selection ---
    print()
    info("AIBrain ships with 24 pre-built workflows grouped by category.")
    info("Select which categories to enable. You can fine-tune later in the GUI.")
    print()

    workflow_groups = {
        "productivity": {
            "label": "Productivity",
            "desc": "Weather briefings, daily planner, file cleanup, habits, bookmarks, calendar, documents",
            "workflows": [
                "weather_briefing", "daily_planner", "file_declutter",
                "habit_tracker", "bookmark_organizer", "calendar_manager", "document_parser"
            ],
        },
        "research": {
            "label": "Research",
            "desc": "RSS digest, daily research, arXiv papers, social monitoring",
            "workflows": ["rss_digest", "daily_research", "arxiv_tracker", "social_listener"],
        },
        "finance": {
            "label": "Finance",
            "desc": "Crypto/stock price alerts, expense tracking",
            "workflows": ["price_watcher", "expense_tracker"],
        },
        "job_hunting": {
            "label": "Job Hunting",
            "desc": "Auto-apply to jobs, interview prep",
            "workflows": ["job_search_apply", "interview_prep"],
        },
        "comms": {
            "label": "Communications",
            "desc": "Email triage, auto-reply, newsletter digest, contacts, content calendar",
            "workflows": [
                "email_triage", "email_auto_reply", "newsletter_digest",
                "contact_enricher", "content_calendar"
            ],
        },
        "devops": {
            "label": "DevOps",
            "desc": "GitHub digest, repo monitoring, uptime checks, dependency auditing",
            "workflows": ["github_digest", "git_monitor", "uptime_monitor", "dependency_auditor"],
        },
    }

    selected_workflows = set(cfg.get("_selected_workflows", []))
    for key, group in workflow_groups.items():
        print(f"  {c('bold', group['label'])}: {group['desc']}")
        enable = confirm(f"  Enable {group['label']}?", default=(key == "productivity"))  # noqa:PLAIN SECRET COMPARISON
        if enable:
            selected_workflows.update(group["workflows"])
            ok(f"{group['label']}: {len(group['workflows'])} workflows enabled")
        else:
            # Remove any previously selected from this group
            selected_workflows -= set(group["workflows"])
            info(f"{group['label']}: skipped")
        print()

    cfg["_selected_workflows"] = sorted(selected_workflows)
    ok(f"Total workflows selected: {len(selected_workflows)}")

    # --- Satellite databases (domain-specific memory stores) ---
    print()
    info("Satellite databases keep large domain-specific data separate from your")
    info("main memory, so everyday searches stay fast and focused.")
    info("Satellites are searched automatically when your queries match their keywords.")
    print()

    satellite_templates = {
        "security": {
            "name": "security_findings",
            "db_path": "security_findings.db",
            "types": ["finding"],
            "keywords": "finding,findings,vuln,vulnerability,cve,scan,exploit,pentest,security,attack",
            "desc": "Vulnerability scans, pentest findings, CVEs",
        },
        "research": {
            "name": "research_papers",
            "db_path": "research_papers.db",
            "types": ["paper", "citation"],
            "keywords": "paper,arxiv,citation,doi,journal,abstract,literature,review",
            "desc": "Research papers, citations, literature reviews",
        },
        "benchmarks": {
            "name": "benchmark_results",
            "db_path": "benchmark_results.db",
            "types": ["benchmark", "evaluation"],
            "keywords": "benchmark,recall,precision,accuracy,eval,f1,experiment,score,metric",
            "desc": "ML benchmarks, evaluation scores, experiment results",
        },
        "logs": {
            "name": "system_logs",
            "db_path": "system_logs.db",
            "types": ["log", "trace"],
            "keywords": "log,trace,error,crash,stacktrace,debug,incident",
            "desc": "System logs, error traces, incident reports",
        },
    }

    satellites_to_create = []
    for key, tmpl in satellite_templates.items():
        enable = confirm(f"  {c('bold', tmpl['desc'])}?", default=False)
        if enable:
            satellites_to_create.append(tmpl)
            ok(f"Will create satellite: {tmpl['name']}")
        print()

    cfg["_satellites"] = satellites_to_create
    if satellites_to_create:
        ok(f"{len(satellites_to_create)} satellite database(s) will be created")
    else:
        info("No satellites — all memories will go in the main DB (you can add later)")

    progress["config"] = cfg
    progress["completed_steps"].append("interview")
    save_progress(progress)
    return True


# ---------------------------------------------------------------------------
# NEW interactive setup — 4-question flow (replaces interactive_interview)
# ---------------------------------------------------------------------------

def interactive_setup(progress):
    """4-question interactive setup wizard.

    Prompts:
      1/4  Agent name
      2/4  Anthropic API key (password-masked)
      3/4  Subscription tier
      4/4  Silent init (DB, config, hooks, signing key, .aibrainrc)
    """
    global _wizard_step
    _wizard_step = 0  # reset counter for this run

    cfg = progress.get("config", {})

    # --- Scan environment silently, display found keys ---
    info("Scanning environment for existing keys...")
    discovered, sources = scan_environment()
    if sources:
        print()
        for config_key, source in sources:
            ok(f"Found {config_key} from {source}")
        # Pre-populate config with discovered values
        for config_key, _ in sources:
            if config_key not in cfg or not cfg[config_key]:
                cfg[config_key] = discovered[config_key]

    # ── [1/4] Agent name ──────────────────────────────────────────────────
    _next_step("Name your agent")
    _default_name = os.environ.get("AGENT_ID", "Agent")
    cfg["agent_name"] = prompt(
        "What should we call your agent?",
        cfg.get("agent_name", _default_name),
    )
    ok(f"Agent name: {cfg['agent_name']}")

    # ── [2/4] AI provider ────────────────────────────────────────────────
    _next_step("AI provider")
    _default_key = cfg.get("anthropic_api_key", "")
    _display_default = _default_key[:8] + "..." if _default_key else ""
    api_key = prompt(
        "Anthropic API key (get one at console.anthropic.com):",
        _display_default,
        password=True,
    )
    # Treat the masked placeholder as "keep existing"
    if api_key and api_key != _display_default:
        cfg["anthropic_api_key"] = api_key
        ok("Anthropic API key saved")
    elif _default_key:
        cfg["anthropic_api_key"] = _default_key
        ok("Anthropic API key kept from environment")
    else:
        info("Anthropic API key skipped. Add later: aibrain config set anthropic_api_key sk-...")

    # ── [3/4] Subscription ───────────────────────────────────────────────
    _next_step("Subscription")
    raw_tier = prompt("Tier [free/pro/team] (Enter for free):", cfg.get("subscription_tier", "free"))
    if raw_tier.lower() not in ("free", "pro", "team"):
        warn(f"Unknown tier '{raw_tier}' — defaulting to free")
        raw_tier = "free"
    cfg["subscription_tier"] = raw_tier.lower()
    ok(f"Tier: {cfg['subscription_tier']}")

    # ── [4/4] Initializing ───────────────────────────────────────────────
    _next_step("Initializing")

    # Signing key
    _ensure_signing_key()

    # Build config
    cfg["brain_name"] = cfg["agent_name"]
    cfg["llm_provider"] = _determine_llm_provider(cfg)
    cfg["memory_db"] = str(DB_PATH)
    cfg["setup_complete"] = True

    # Load or merge existing config
    if CONFIG_PATH.exists():
        try:
            base = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        except Exception:
            base = {}
    else:
        base = {}

    base.update({
        "agent_name": cfg["agent_name"],
        "brain_name": cfg["brain_name"],
        "anthropic_api_key": cfg.get("anthropic_api_key", ""),
        "subscription_tier": cfg["subscription_tier"],
        "llm_provider": cfg["llm_provider"],
        "memory_db": cfg["memory_db"],
        "setup_complete": True,
    })
    base.pop("_readme", None)

    AIBRAIN_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_PATH.write_text(json.dumps(base, indent=2), encoding="utf-8")

    # Init DB
    _safe_init_db()

    # Enable free-tier workflows
    _enable_default_workflows()

    # Agent hooks (if the function is available in context)
    try:
        configure_agent_hooks(progress)
    except Exception:
        pass

    # Pin canonical root
    _write_aibrainrc(AIBRAIN_DIR)

    clear_progress()

    # ── Success screen ───────────────────────────────────────────────────
    agent_name = cfg["agent_name"]
    print(f"""
{c('teal', '  +==============================================+')}
{c('teal', '  |')}  {c('bold', f'{agent_name} is ready.')}{'  ' + ' ' * max(0, 28 - len(agent_name))}{c('teal', '|')}
{c('teal', '  +==============================================+')}

  {c('green', '[OK]')} Memory database: ~/aibrain/aibrain.db
  {c('green', '[OK]')} Config: ~/aibrain/config.json
  {c('green', '[OK]')} Free-tier workflows enabled

  Point your agent at AIBrain:

    Tell Claude (or any agent):
    "You have access to AIBrain. Use the MCP tools
     memory_store and memory_search."

    Or via REST:
      Store: POST http://localhost:8001/api/agent/memories
      Recall: GET  http://localhost:8001/api/agent/memories/search?q=...

  Start the server:
    aibrain server

  Add more settings anytime:
    aibrain config set anthropic_api_key sk-...
    aibrain config set agent_email you@gmail.com
""")

    progress["config"] = cfg
    progress["completed_steps"].append("interview")
    save_progress(progress)
    return True


# ---------------------------------------------------------------------------
# Step 2b: First impression — brain naming + memory demo
# ---------------------------------------------------------------------------

def first_impression_demo(progress):
    """Name the brain and show a before/after memory demo.

    This is the conversion step. Two hooks:
    1. The naming moment — personalises the brain before anything runs
    2. The memory demo — makes the value visceral: agents forget vs. agents remember
    """
    import time
    import threading

    step_header(3, 14, "Name your brain + see it in action")

    cfg = progress.get("config", {})

    # ── Naming moment ──────────────────────────────────────────────────────
    print()
    print(f"  {c('bold', 'Every great AI has a name.')}")
    print()
    info("Your brain is the persistent layer that makes your AI remember across sessions.")
    info("What should we call it?")
    print()

    default_name = cfg.get("brain_name", cfg.get("agent_name", ""))
    brain_name = prompt("Brain name", default_name or "Nexus")
    if not brain_name:
        brain_name = "Nexus"

    cfg["brain_name"] = brain_name
    print()
    ok(f'Brain name set: "{brain_name}"')

    # ── Memory demo ────────────────────────────────────────────────────────
    print()
    print(f"  {c('teal', '─' * 52)}")
    print(f"  {c('bold', 'The 30-second memory demo')}")
    print(f"  {c('teal', '─' * 52)}")
    print()

    time.sleep(0.3)

    # --- WITHOUT memory ---
    print(f"  {c('yellow', 'WITHOUT AIBrain:')} {c('dim', 'your agent starts fresh every session')}")
    print()

    exchanges_without = [
        ("You",    "My API key is sk-proj-XXXX. Save it."),
        ("Agent",  "Got it! I'll remember that."),
        ("—",      "[ New session ]"),
        ("You",    "What was my API key?"),
        ("Agent",  "I don't have access to previous conversations."),
        ("You",    "I just told you this."),
        ("Agent",  "I'm sorry — each session starts fresh."),
    ]

    for speaker, line in exchanges_without:
        if speaker == "—":
            time.sleep(0.2)
            print(f"\n    {c('dim', line)}\n")
            time.sleep(0.2)
        elif speaker == "You":
            time.sleep(0.15)
            print(f"    {c('bold', 'You:  ')}{line}")
        else:
            time.sleep(0.15)
            print(f"    {c('dim', 'AI:   ')}{c('dim', line)}")

    print()
    time.sleep(0.4)

    # --- WITH memory ---
    print(f"  {c('green', 'WITH AIBrain:')} {c('dim', 'memories persist — forever')}")
    print()

    exchanges_with = [
        ("You",    "My API key is sk-proj-XXXX. Save it."),
        ("Agent",  f"Stored in {brain_name}. I'll never forget this."),
        ("—",      f"[ New session — {brain_name} loaded ]"),
        ("You",    "What was my API key?"),
        ("Agent",  "Your API key is sk-proj-XXXX — stored 3 days ago."),
        ("You",    "Perfect."),
        ("Agent",  "Always. That's what I'm here for."),
    ]

    for speaker, line in exchanges_with:
        if speaker == "—":
            time.sleep(0.2)
            print(f"\n    {c('dim', line)}\n")
            time.sleep(0.2)
        elif speaker == "You":
            time.sleep(0.15)
            print(f"    {c('bold', 'You:  ')}{line}")
        else:
            time.sleep(0.15)
            print(f"    {c('green', 'AI:   ')}{line}")

    print()
    time.sleep(0.3)

    # ── Spinner while "initialising" the brain ─────────────────────────────
    print(f"  {c('teal', '─' * 52)}")
    print()

    spinner_frames = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
    _stop_spinner = threading.Event()

    def _spin():
        i = 0
        while not _stop_spinner.is_set():
            frame = spinner_frames[i % len(spinner_frames)]
            print(f"\r  {c('teal', frame)} {c('dim', f'Initialising {brain_name}...')}  ", end="", flush=True)
            time.sleep(0.1)
            i += 1

    spin_thread = threading.Thread(target=_spin, daemon=True)
    spin_thread.start()

    # Store brain_name in config (the actual persistent effect of this step)
    try:
        if CONFIG_PATH.exists():
            try:
                existing = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
            except Exception:
                existing = {}
            existing["brain_name"] = brain_name
            CONFIG_PATH.write_text(json.dumps(existing, indent=2), encoding="utf-8")
    except Exception:
        pass  # Config may not exist yet — it's written in the next step

    time.sleep(2.0)
    _stop_spinner.set()
    spin_thread.join(timeout=0.5)

    print(f"\r  {c('green', '[OK]')} {c('bold', brain_name)} is ready.{' ' * 30}")
    print()
    print(f"  {c('teal', 'Your agent will now remember everything.')}")
    print()
    time.sleep(0.5)

    progress["config"] = cfg
    progress["completed_steps"].append("first_impression")
    save_progress(progress)
    return True


# ---------------------------------------------------------------------------
# Step 3: Generate config.json
# ---------------------------------------------------------------------------

def generate_config(progress):
    step_header(3, 11, "Generating config.json")

    cfg = progress.get("config", {})

    # Start from example if no config exists
    example_path = AIBRAIN_DIR / "config.json.example"
    if CONFIG_PATH.exists():
        base = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        info("Merging with existing config.json")
    elif example_path.exists():
        base = json.loads(example_path.read_text(encoding="utf-8"))
        # Remove the readme key
        base.pop("_readme", None)
    else:
        base = {}

    # Map interview answers onto config fields
    field_map = {
        "agent_name": "agent_name",
        "brain_name": "brain_name",
        "agent_email": "agent_email",
        "agent_email_password": "agent_email_password",
        "agent_smtp_host": "agent_smtp_host",
        "agent_imap_host": "agent_imap_host",
        "email_to": "email_to",
        "email_accounts": "email_accounts",
        "location_name": "location_name",
        "location_lat": "location_lat",
        "location_lon": "location_lon",
        "github_token": "github_token",
        "github_username": "github_username",
        "anthropic_api_key": "anthropic_api_key",
        "openai_api_key": "openai_api_key",
        "ollama_url": "ollama_url",
        "ollama_model": "ollama_model",
        "llm_provider": "llm_provider",
        "telegram_bot_token": "telegram_bot_token",
        "telegram_chat_id": "telegram_chat_id",
    }

    for src, dst in field_map.items():
        if src in cfg and cfg[src]:
            base[dst] = cfg[src]

    # Remove internal keys that should not be in config.json
    base.pop("_selected_workflows", None)
    base.pop("_readme", None)

    # Set memory_db path if empty
    if not base.get("memory_db"):
        base["memory_db"] = str(DB_PATH)

    # Set cron_jobs path if empty
    if not base.get("cron_jobs"):
        base["cron_jobs"] = str(SCHEDULED_JOBS_PATH)

    CONFIG_PATH.write_text(json.dumps(base, indent=2), encoding="utf-8")
    ok(f"config.json written to {CONFIG_PATH}")

    # List what was configured
    configured = []
    if base.get("agent_name") and base["agent_name"] != "Agent":
        configured.append(f"Agent: {base['agent_name']}")
    if base.get("location_name") and base["location_name"] != "Your City":
        configured.append(f"Location: {base['location_name']}")
    if base.get("agent_email"):
        configured.append(f"Email: {base['agent_email']}")
    if base.get("github_token"):
        configured.append("GitHub: token set")
    if base.get("anthropic_api_key"):
        configured.append("Anthropic: API key set")
    if base.get("openai_api_key"):
        configured.append("OpenAI: API key set")
    if base.get("ollama_url") and base["ollama_url"] != "http://localhost:11434":
        configured.append(f"Ollama: {base['ollama_url']}")
    if base.get("telegram_bot_token"):
        configured.append("Telegram: bot token set")
    if base.get("llm_provider") and base["llm_provider"] != "auto":
        configured.append(f"LLM provider: {base['llm_provider']}")

    if configured:
        for item in configured:
            info(f"  {item}")
    else:
        info("  Minimal config -- add details later in config.json or the GUI")

    progress["completed_steps"].append("config")
    save_progress(progress)
    return True


# ---------------------------------------------------------------------------
# Step 4: Initialize memory.db with seed memories
# ---------------------------------------------------------------------------

def init_memory_db(progress):
    step_header(4, 11, "Initializing memory database")

    MEMORY_DIR.mkdir(parents=True, exist_ok=True)

    # If DB already exists and has data, skip
    if DB_PATH.exists():
        try:
            db = sqlite3.connect(str(DB_PATH))
            count = db.execute("SELECT COUNT(*) FROM memories WHERE active = 1").fetchone()[0]
            db.close()
            ok(f"Memory database already exists ({count} active memories)")
            progress["completed_steps"].append("memory_db")
            save_progress(progress)
            return True
        except Exception:
            # DB exists but schema may be outdated — migrate, never delete
            info("Existing DB has older schema — will upgrade tables in place")
            # Fall through to CREATE TABLE IF NOT EXISTS below (safe, additive only)

    db = sqlite3.connect(str(DB_PATH))

    # Create tables — canonical schema matches aibrain_db.py _init_schema()
    db.execute("""
        CREATE TABLE IF NOT EXISTS memories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            type TEXT DEFAULT 'project',
            tags TEXT DEFAULT '',
            content TEXT DEFAULT '',
            created TEXT DEFAULT (datetime('now')),
            updated TEXT DEFAULT (datetime('now')),
            active INTEGER DEFAULT 1
        )
    """)

    # FTS5 virtual table for full-text search (matches aibrain_db.py)
    db.execute("""
        CREATE VIRTUAL TABLE IF NOT EXISTS memories_fts USING fts5(
            name, tags, content, content=memories, content_rowid=id
        )
    """)

    # Triggers to keep FTS index in sync (matches aibrain_db.py)
    db.execute("""
        CREATE TRIGGER IF NOT EXISTS memories_ai AFTER INSERT ON memories BEGIN
            INSERT INTO memories_fts(rowid, name, tags, content)
            VALUES (new.id, new.name, new.tags, new.content);
        END
    """)
    db.execute("""
        CREATE TRIGGER IF NOT EXISTS memories_au AFTER UPDATE ON memories BEGIN
            INSERT INTO memories_fts(memories_fts, rowid, name, tags, content)
            VALUES ('delete', old.id, old.name, old.tags, old.content);
            INSERT INTO memories_fts(rowid, name, tags, content)
            VALUES (new.id, new.name, new.tags, new.content);
        END
    """)
    db.execute("""
        CREATE TRIGGER IF NOT EXISTS memories_ad AFTER DELETE ON memories BEGIN
            INSERT INTO memories_fts(memories_fts, rowid, name, tags, content)
            VALUES ('delete', old.id, old.name, old.tags, old.content);
        END
    """)
    db.commit()

    # Load seed memories — only if DB is fresh (no existing memories)
    now = datetime.now().isoformat()
    seed_count = 0
    starter_count = 0
    existing_count = db.execute("SELECT COUNT(*) FROM memories").fetchone()[0]

    if existing_count > 0:
        ok(f"Database already has {existing_count} memories — skipping seed load")
    else:
        # Load starter memories first (beginner-friendly welcome pack)
        if STARTER_PATH.exists():
            try:
                starters = json.loads(STARTER_PATH.read_text(encoding="utf-8"))
                for mem in starters.get("memories", []):
                    db.execute(
                        "INSERT INTO memories (name, type, tags, content, created, updated) "
                        "VALUES (?, ?, ?, ?, ?, ?)",
                        (mem["name"], mem["type"], mem.get("tags", ""),
                         mem["content"], now, now)
                    )
                    starter_count += 1
                db.commit()
                ok(f"Loaded {starter_count} starter memories (welcome pack)")
            except Exception as e:
                warn(f"Starter memory load error: {e}")

        # Load seed memories (technical reference pack)
        if SEED_PATH.exists():
            try:
                seeds = json.loads(SEED_PATH.read_text(encoding="utf-8"))
                for mem in seeds.get("memories", []):
                    db.execute(
                        "INSERT INTO memories (name, type, tags, content, created, updated) "
                        "VALUES (?, ?, ?, ?, ?, ?)",
                        (mem["name"], mem["type"], mem.get("tags", ""),
                         mem["content"], now, now)
                    )
                    seed_count += 1
                db.commit()
                ok(f"Loaded {seed_count} seed memories from seed_memories.json")
            except Exception as e:
                warn(f"Seed memory load error: {e}")

        if starter_count == 0 and seed_count == 0:
            info("No starter or seed memories found, starting with empty database")

    # Add setup record
    cfg = progress.get("config", {})
    agent_name = cfg.get("agent_name", "Agent")
    db.execute(
        "INSERT INTO memories (name, type, tags, content, created, updated) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        (
            "aibrain_setup_complete", "project", "aibrain,setup",
            f"AIBrain setup completed at {now}.\n"
            f"Agent name: {agent_name}\n"
            f"Platform: {platform.system()} {platform.release()}\n"
            f"Python: {sys.version.split()[0]}\n"
            f"Starter memories loaded: {starter_count}\n"
            f"Seed memories loaded: {seed_count}",
            now, now
        )
    )
    db.commit()
    db.close()

    ok(f"Memory database created at {DB_PATH}")
    ok(f"FTS5 full-text search enabled with {starter_count + seed_count + 1} memories")

    # Create satellite databases if user selected any during interview
    satellites = progress.get("config", {}).get("_satellites", [])
    if satellites:
        print()
        info(f"Creating {len(satellites)} satellite database(s)...")
        try:
            sys.path.insert(0, str(AIBRAIN_DIR))
            import aibrain_db
            for sat in satellites:
                aibrain_db.satellite_register(
                    name=sat["name"],
                    db_path=sat["db_path"],
                    description=sat["desc"],
                    memory_types=sat["types"],
                    search_keywords=sat["keywords"],
                )
                ok(f"Created satellite: {sat['name']} ({sat['db_path']})")
                info(f"  Types: {sat['types']}  |  Keywords: {sat['keywords'][:60]}...")
        except Exception as e:
            warn(f"Satellite creation failed: {e}")
            info("You can create satellites later: python aibrain_db.py satellite register ...")

    progress["completed_steps"].append("memory_db")
    save_progress(progress)
    return True


# ---------------------------------------------------------------------------
# Step 5: Install frontend dependencies
# ---------------------------------------------------------------------------

def install_frontend(progress):
    step_header(5, 11, "Installing frontend dependencies")

    package_json = FRONTEND_DIR / "package.json"
    if not package_json.exists():
        warn(f"No package.json found at {FRONTEND_DIR}")
        info("Skipping frontend install. Create the frontend first.")
        progress["completed_steps"].append("frontend")
        save_progress(progress)
        return True

    node_modules = FRONTEND_DIR / "node_modules"
    if node_modules.exists() and any(node_modules.iterdir()):
        ok("Frontend node_modules already installed")
        skip = not confirm("Re-run npm install?", default=False)
        if skip:
            progress["completed_steps"].append("frontend")
            save_progress(progress)
            return True

    info("Running npm install (this may take a minute)...")
    success, output = run_cmd("npm install", cwd=str(FRONTEND_DIR), timeout=300)
    if success:
        ok("Frontend dependencies installed")
    else:
        warn(f"npm install had issues: {output[:200]}")
        info("You can retry manually: cd frontend && npm install")

    progress["completed_steps"].append("frontend")
    save_progress(progress)
    return True


# ---------------------------------------------------------------------------
# Step 6: Create scheduled_jobs.json with selected workflows
# ---------------------------------------------------------------------------

def create_scheduled_jobs(progress):
    step_header(6, 11, "Configuring scheduled workflows")

    cfg = progress.get("config", {})
    selected = set(cfg.get("_selected_workflows", []))

    if SCHEDULED_JOBS_PATH.exists():
        data = json.loads(SCHEDULED_JOBS_PATH.read_text(encoding="utf-8"))
        existing_jobs = data.get("jobs", [])
        info(f"Existing scheduled_jobs.json found ({len(existing_jobs)} jobs)")

        # Update enabled status based on selections
        updated = 0
        for job in existing_jobs:
            was_enabled = job.get("enabled", False)
            should_enable = job["name"] in selected
            if was_enabled != should_enable:
                job["enabled"] = should_enable
                updated += 1

        data["_updated"] = datetime.now().strftime("%Y-%m-%d")
        SCHEDULED_JOBS_PATH.write_text(json.dumps(data, indent=2), encoding="utf-8")

        enabled = sum(1 for j in existing_jobs if j.get("enabled"))
        ok(f"Updated {updated} jobs. {enabled} enabled, {len(existing_jobs)} total.")
    else:
        # This shouldn't happen since scheduled_jobs.json ships with the repo,
        # but handle it gracefully
        warn("No scheduled_jobs.json found. Creating from scratch.")
        data = {
            "_description": "AIBrain scheduled jobs registry.",
            "_created": datetime.now().strftime("%Y-%m-%d"),
            "_updated": datetime.now().strftime("%Y-%m-%d"),
            "jobs": []
        }
        SCHEDULED_JOBS_PATH.write_text(json.dumps(data, indent=2), encoding="utf-8")
        ok("Created empty scheduled_jobs.json")

    # Show what got enabled
    if selected:
        info("Enabled workflows:")
        for name in sorted(selected):
            info(f"  - {name}")
    else:
        info("No workflows enabled. Enable them later in the GUI (Library tab).")

    progress["completed_steps"].append("scheduled_jobs")
    save_progress(progress)
    return True


# ---------------------------------------------------------------------------
# Step 7: Test connectivity
# ---------------------------------------------------------------------------

def test_connectivity(progress):
    step_header(7, 11, "Testing connectivity")

    cfg = progress.get("config", {})
    tests_run = 0
    tests_passed = 0

    # --- Weather API (Open-Meteo, no key needed) ---
    lat = cfg.get("location_lat", 0)
    lon = cfg.get("location_lon", 0)
    if lat and lon:
        tests_run += 1
        info(f"Testing weather API for ({lat}, {lon})...")
        success, data = http_get_json(
            f"https://api.open-meteo.com/v1/forecast?"
            f"latitude={lat}&longitude={lon}&current=temperature_2m,weathercode"
        )
        if success and "current" in data:
            temp = data["current"].get("temperature_2m", "?")
            ok(f"Weather API: {temp} C at your location")
            tests_passed += 1
        else:
            warn("Weather API: could not fetch forecast")
    else:
        info("Weather API: skipped (no location configured)")

    # --- IMAP (email) ---
    email = cfg.get("agent_email", "")
    email_pass = cfg.get("agent_email_password", "")
    imap_host = cfg.get("agent_imap_host", "imap.gmail.com")
    if email and email_pass:
        tests_run += 1
        info(f"Testing IMAP connection to {imap_host}...")
        try:
            imap = imaplib.IMAP4_SSL(imap_host, 993, timeout=10)
            imap.login(email, email_pass)
            status, mailboxes = imap.list()
            if status == "OK":
                ok(f"IMAP: connected to {email} ({len(mailboxes)} mailboxes)")
                tests_passed += 1
            else:
                warn("IMAP: connected but could not list mailboxes")
            imap.logout()
        except imaplib.IMAP4.error as e:
            fail(f"IMAP login failed: {e}")
            info("Check your app password. Regular passwords will not work with Gmail.")
            info("Generate an app password at: https://myaccount.google.com/apppasswords")
        except Exception as e:
            fail(f"IMAP connection failed: {e}")
    else:
        info("IMAP: skipped (no email or app password configured)")

    # --- GitHub API ---
    gh_token = cfg.get("github_token", "")
    if gh_token:
        tests_run += 1
        info("Testing GitHub API...")
        try:
            req = urllib.request.Request(
                "https://api.github.com/user",
                headers={
                    "Authorization": f"token {gh_token}",
                    "User-Agent": "AIBrain-Setup/1.0",
                    "Accept": "application/vnd.github.v3+json",
                }
            )
            with urllib.request.urlopen(req, timeout=10) as resp:
                user_data = json.loads(resp.read().decode())
                username = user_data.get("login", "unknown")
                ok(f"GitHub API: authenticated as {username}")
                # Save the username if we got it
                if username != "unknown":
                    cfg["github_username"] = username
                    progress["config"] = cfg
                tests_passed += 1
        except urllib.error.HTTPError as e:
            if e.code == 401:
                fail("GitHub API: token is invalid or expired")
                info("Create a new token at: https://github.com/settings/tokens/new")
            else:
                fail(f"GitHub API error: HTTP {e.code}")
        except Exception as e:
            fail(f"GitHub API connection failed: {e}")
    else:
        info("GitHub API: skipped (no token configured)")

    # --- Summary ---
    print()
    if tests_run == 0:
        info("No connectivity tests to run (nothing configured yet)")
    elif tests_passed == tests_run:
        ok(f"All {tests_passed}/{tests_run} connectivity tests passed")
    else:
        warn(f"{tests_passed}/{tests_run} connectivity tests passed")
        info("Failed tests can be fixed later in config.json")

    progress["completed_steps"].append("connectivity")
    save_progress(progress)
    return True


# ---------------------------------------------------------------------------
# Step 8b: Retrolearn from Claude Code session history
# ---------------------------------------------------------------------------

def scan_session_history(progress):
    """Scan Claude Code JSONL session files and seed the brain with learning signals."""
    step_header(9, 14, "Retrolearn from Claude Code session history")

    print()
    info("AIBrain can read your past Claude Code session logs and extract")
    info("corrections, praise, and self-reflections to seed your brain.")
    print()

    # Discovery
    try:
        sys.path.insert(0, str(_INSTALL_DIR))
        from aibrain.core.retrolearn_scanner import find_session_files, count_turns
        files = find_session_files()
    except Exception as e:
        warn(f"Could not load retrolearn scanner: {e}")
        progress["completed_steps"].append("scan_session_history")
        save_progress(progress)
        return True

    if not files:
        info("No Claude Code session files found (nothing to retrolearn from).")
        info("This is normal if this is your first Claude Code session.")
        progress["completed_steps"].append("scan_session_history")
        save_progress(progress)
        return True

    # Count for summary
    total_lines = 0
    total_user_turns = 0
    for f in files:
        try:
            lines, user_turns = count_turns(f)
            total_lines += lines
            total_user_turns += user_turns
        except Exception:
            pass

    proj_dirs: set = set()
    for f in files:
        try:
            proj_dirs.add(f.parent.parent.name)
        except Exception:
            pass

    ok(f"Found {len(files)} session files across {len(proj_dirs)} projects")
    info(f"Total turns: {total_lines:,}  (user turns: {total_user_turns:,})")
    print()

    if not confirm("Scan session history and seed brain with learnings?", default=True):
        info("Skipped. You can run this later: aibrain learn-from-history")
        progress["completed_steps"].append("scan_session_history")
        save_progress(progress)
        return True

    # Run the retrolearn sweep
    info("Extracting learning signals... (this may take a moment for large histories)")
    try:
        from aibrain.core.retrolearn_scanner import retrolearn_all

        result = retrolearn_all(files, dry_run=False)

        sig = result.get("by_signal", {})
        scanned = result.get("files_scanned", 0)
        total_mem = result.get("total_extracted", 0)
        skipped_secrets = result.get("total_secrets_skipped", 0)

        ok(f"Files scanned: {scanned} (skipped {result.get('files_skipped_dedup', 0)} already done)")
        ok(f"Corrections: {sig.get('correction', 0)}  |  Praise: {sig.get('praise', 0)}  |  "
           f"Self-reflections: {sig.get('self_reflection', 0)}")
        ok(f"Total memories added: {total_mem}")
        if skipped_secrets:
            info(f"Turns skipped for credential safety: {skipped_secrets}")
        if result.get("errors"):
            warn(f"{len(result['errors'])} files had read errors (non-fatal)")

    except Exception as e:
        warn(f"Retrolearn sweep error: {e}")
        info("Your brain still works — retrolearn is optional. Run later: aibrain learn-from-history")

    progress["completed_steps"].append("scan_session_history")
    save_progress(progress)
    return True


# ---------------------------------------------------------------------------
# Step 8: Connect your AI agent
# ---------------------------------------------------------------------------

def connect_agent(progress):
    step_header(9, 11, "Connect your AI agent")

    cfg = progress.get("config", {})

    print()
    has_agent = confirm("Do you already have an AI agent you'd like to connect?")

    if has_agent:
        print(f"""
  {c('teal', 'Great! Tell your agent this:')}

  {c('bold', '─────────────────────────────────────────────────')}

  {c('green', 'Copy and paste this to your agent:')}

    You now have access to AIBrain at http://localhost:8001
    Use these endpoints for persistent memory:
      - Store: POST http://localhost:8001/api/agent/memories
        Body: {{"name": "...", "content": "...", "type": "reference", "tags": ""}}
      - Recall: GET http://localhost:8001/api/agent/memories/search?q=your+query
      - List: GET http://localhost:8001/api/agent/memories
    Use these endpoints for communication:
      - Chat: POST http://localhost:8001/api/agent/chat/send
        Body: {{"content": "your message", "role": "agent"}}
      - Activity: POST http://localhost:8001/api/agent/activity
        Body: {{"action": "...", "detail": "...", "source": "agent"}}
    Dashboard: http://localhost:5173

  {c('bold', '─────────────────────────────────────────────────')}

  {c("dim", "That is it. Your agent can now remember, communicate, and be monitored.")}
  {c('dim', 'For a Python SDK, see: aibrain_sdk.py')}
  {c('dim', 'For examples: examples/claude_agent.py, examples/openai_agent.py, examples/ollama_agent.py')}
""")
    else:
        print(f"""
  {c("teal", "No problem! Here is how to get an agent:")}

  {c('bold', 'Option 1: Claude Code')} {c('dim', '(recommended)')}
    Install: npm install -g @anthropic-ai/claude-code
    Run:     claude
    Then tell it: "You have access to AIBrain at http://localhost:8001"

  {c('bold', 'Option 2: Python + Claude API')}
    pip install anthropic
    Set ANTHROPIC_API_KEY env var
    Run: python examples/claude_agent.py

  {c('bold', 'Option 3: Python + OpenAI API')}
    pip install openai
    Set OPENAI_API_KEY env var
    Run: python examples/openai_agent.py

  {c('bold', 'Option 4: Local LLM (Ollama)')} {c('dim', '— fully private, no API key')}
    Install Ollama: https://ollama.ai
    Run: ollama pull llama3 && python examples/ollama_agent.py

  {c('bold', 'Option 5: Any agent framework')} {c('dim', '(LangChain, CrewAI, AutoGPT, etc.)')}
    from aibrain_sdk import AIBrain
    aos = AIBrain("http://localhost:8001")
    aos.remember("something important")
    results = aos.recall("important")

  {c('dim', 'All options use the same REST API. Your agent is not locked to any provider.')}
""")

    progress["completed_steps"].append("connect_agent")
    save_progress(progress)
    return True


# ---------------------------------------------------------------------------
# Step 9: Summary and startup instructions
# ---------------------------------------------------------------------------

def print_summary(progress):
    step_header(13, 13, "Setup complete")

    cfg = progress.get("config", {})
    agent_name = cfg.get("agent_name", "Agent")

    print(f"""
  {c('teal', f'{agent_name} is ready to go.')}

  {c('bold', 'What was set up:')}""")

    items = []
    if "prerequisites" in progress["completed_steps"]:
        items.append("Prerequisites verified")
    if cfg.get("agent_name"):
        items.append(f"Agent name: {cfg['agent_name']}")
    if cfg.get("location_name") and cfg["location_name"] != "Your City":
        items.append(f"Location: {cfg['location_name']} ({cfg.get('location_lat', '?')}, {cfg.get('location_lon', '?')})")
    if cfg.get("agent_email"):
        items.append(f"Email: {cfg['agent_email']}")
    if cfg.get("github_token"):
        items.append(f"GitHub: {cfg.get('github_username', 'configured')}")
    if cfg.get("anthropic_api_key"):
        items.append("Anthropic API: configured")
    selected = cfg.get("_selected_workflows", [])
    if selected:
        items.append(f"Workflows enabled: {len(selected)}")
    if "memory_db" in progress["completed_steps"]:
        items.append(f"Memory DB: {DB_PATH}")
    if "config" in progress["completed_steps"]:
        items.append(f"Config: {CONFIG_PATH}")
    if cfg.get("company_id"):
        items.append(f"Company: {cfg.get('company_name', cfg['company_id'])} (CEO + 5 workers)")

    for item in items:
        print(f"    {c('green', '-')} {item}")

    # Detect environment
    is_headless = not os.environ.get("DISPLAY") and platform.system() == "Linux"
    has_ssh = os.environ.get("SSH_CLIENT") or os.environ.get("SSH_CONNECTION")

    print(f"""
  {c('bold', 'How to start:')}

  {c('teal', 'Option 1: Direct (development)')}
    Terminal 1 (backend):
      cd {BACKEND_DIR}
      {sys.executable} -m uvicorn main:app --host 0.0.0.0 --port 8001

    Terminal 2 (frontend):
      cd {FRONTEND_DIR}
      npm run dev -- --host 0.0.0.0

  {c('teal', 'Option 2: Docker (production)')}
      cd {AIBRAIN_DIR}
      docker compose up""")

    if is_headless or has_ssh:
        print(f"""
  {c('yellow', 'Remote/VPS access:')}
    From your local machine:
      ssh -L 5173:localhost:5173 -L 8001:localhost:8001 user@your-vps-ip
    Then open: http://localhost:5173""")

    print(f"""
  {c('teal', 'Open in browser:')}
    Dashboard: http://localhost:5173
    API docs:  http://localhost:8001/docs

  {c('dim', 'Files created:')}
    {c('dim', str(CONFIG_PATH))}
    {c('dim', str(DB_PATH))}
    {c('dim', str(SCHEDULED_JOBS_PATH))}
""")

    # Run doctor to ensure DB path, MCP configs, and MEMORY.md dirs are all
    # correctly wired — catches any profile isolation issues silently.
    try:
        from aibrain_db import _cmd_doctor
        print(f"\n  {c('dim', 'Running profile health check...')}")
        _cmd_doctor()
    except Exception:
        pass  # Never block setup completion due to doctor

    # Also run the rogue-DB detector + schema sanity check shipped Apr 10 2026
    # after the working-memory split-brain incident. The two doctors check
    # different things: the OLD doctor (above) handles profile isolation +
    # MCP wiring + memory rescue. The NEW `aibrain doctor` (below) handles
    # rogue-DB enumeration + schema sanity. Both run, neither blocks.
    try:
        import subprocess
        import sys as _sys
        print(f"\n  {c('dim', 'Running rogue-DB + schema sanity check (aibrain doctor)...')}")
        subprocess.run([_sys.executable, "-m", "aibrain", "doctor"], check=False, timeout=15)
    except Exception:
        pass  # Never block setup completion due to doctor

    # Clean up progress file on success
    clear_progress()
    return True


# ---------------------------------------------------------------------------
# Step 9.5: Scan filesystem and build brain connections
# ---------------------------------------------------------------------------

def scan_and_build_brain(progress):
    step_header(8, 11, "Scanning your filesystem")

    cfg = progress.get("config", {})

    print()
    info("AIBrain can scan your project directories and git repos to auto-discover")
    info("projects, workflows, tools, and integrations. This builds the connected")
    info("brain graph so everything is linked from day one.")
    print()

    scan_dirs = []

    # Ask for project directories
    info("Where do you keep your projects?")
    info("Enter directory paths, one per line. Press Enter when done.")
    info("Common locations: ~/projects, ~/code, ~/dev, ~/repos")
    print()

    while True:
        dir_input = prompt("Project directory (Enter to finish)", "")
        if not dir_input:
            break
        expanded = os.path.expanduser(dir_input)
        if os.path.isdir(expanded):
            scan_dirs.append(expanded)
            ok(f"Added: {expanded}")
        else:
            warn(f"Not found: {expanded}")

    if not scan_dirs:
        # Try common locations
        common = [
            os.path.expanduser("~/projects"),
            os.path.expanduser("~/code"),
            os.path.expanduser("~/dev"),
            os.path.expanduser("~/repos"),
        ]
        found = [d for d in common if os.path.isdir(d)]
        if found:
            info(f"Found project directories: {', '.join(found)}")
            if confirm("Scan these?"):
                scan_dirs = found

    if not scan_dirs:
        info("No directories to scan. You can run the scanner later from the GUI.")
        progress["completed_steps"].append("brain_scan")
        save_progress(progress)
        return True

    # Import and run scanner
    try:
        sys.path.insert(0, str(BACKEND_DIR))
        from brain_scanner import build_brain_from_filesystem

        # Determine Claude memory directory
        claude_mem = None
        home = Path.home()
        claude_projects = home / ".claude" / "projects"
        if claude_projects.is_dir():
            # Find the first memory directory
            for proj_dir in claude_projects.iterdir():
                mem_dir = proj_dir / "memory"
                if mem_dir.is_dir():
                    claude_mem = str(mem_dir)
                    info(f"Found Claude memories: {mem_dir}")
                    break

        # Run the scan
        info("Scanning... (this may take a minute for large codebases)")
        db_path = str(AIBRAIN_DIR / "aibrain.db")

        report = build_brain_from_filesystem(
            db_path=db_path,
            project_dirs=scan_dirs,
            github_username=cfg.get("github_username"),
            github_token=cfg.get("github_token"),
            claude_memory_dir=claude_mem,
        )

        # Print results
        print()
        ok(f"Projects discovered: {report['projects_created']} new, {len(report['projects'])} total")
        ok(f"Workflows found: {report['workflows_discovered']}")
        ok(f"Tools found: {report['tools_discovered']}")
        ok(f"Integrations detected: {report['integrations_discovered']}")
        ok(f"References found: {report['references_discovered']}")
        ok(f"Entity links created: {report['entity_links_created']}")
        ok(f"Git repos found: {report['git_repos_found']}")

        if report.get("github_repos_found"):
            ok(f"GitHub repos found: {report['github_repos_found']}")
        if report.get("memories_imported"):
            ok(f"Memories imported: {report['memories_imported']}")
        if report.get("errors"):
            warn(f"Errors: {len(report['errors'])} (non-fatal)")

        # Show discovered projects
        if report["projects"]:
            print()
            info("Discovered projects:")
            for p in report["projects"][:15]:
                status = c("green", "NEW") if p["new"] else c("dim", "existing")
                intg = f" [{', '.join(p['integrations'][:3])}]" if p.get("integrations") else ""
                print(f"    {status} {p['name']:30s} {p['language']:10s} {p['files']} files{intg}")

            if len(report["projects"]) > 15:
                info(f"  ... and {len(report['projects']) - 15} more")

    except Exception as e:
        warn(f"Brain scan error: {e}")
        info("You can run the scanner later: python backend/brain_scanner.py build aibrain.db ~/projects")

    progress["completed_steps"].append("brain_scan")
    save_progress(progress)
    return True


# ---------------------------------------------------------------------------
# Environment scanning and auto-detect
# ---------------------------------------------------------------------------

# Env vars to scan, mapped to config.json keys
ENV_VAR_MAP = {
    "ANTHROPIC_API_KEY": "anthropic_api_key",
    "OPENAI_API_KEY": "openai_api_key",
    "OLLAMA_BASE_URL": "ollama_url",
    "OLLAMA_API_BASE": "ollama_url",
    "TELEGRAM_BOT_TOKEN": "telegram_bot_token",
    "TELEGRAM_TOKEN": "telegram_bot_token",
    "TELEGRAM_CHAT_ID": "telegram_chat_id",
    "GITHUB_TOKEN": "github_token",
    "GITHUB_PAT": "github_token",
    "SMTP_USER": "agent_email",
    "SMTP_PASSWORD": "agent_email_password",
    "IMAP_USER": "agent_email",
    "IMAP_PASSWORD": "agent_email_password",
}


def _parse_env_file(path):
    """Parse a .env file (KEY=VALUE format). Returns dict. Skips comments/blanks."""
    result = {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                if "=" not in line:
                    continue
                key, _, value = line.partition("=")
                key = key.strip()
                value = value.strip()
                # Strip surrounding quotes
                if len(value) >= 2 and value[0] == value[-1] and value[0] in ('"', "'"):
                    value = value[1:-1]
                if key and value:
                    result[key] = value
    except (OSError, UnicodeDecodeError):
        pass
    return result


def scan_environment():
    """Scan env vars and .env files. Returns (discovered_config, sources).

    discovered_config: dict of config_key -> value
    sources: list of (config_key, source_description) for reporting
    """
    discovered = {}
    sources = []

    # 1. Scan .env files (lower priority — env vars override)
    env_files = []
    home_env = Path.home() / ".env"
    cwd_env = Path.cwd() / ".env"
    home_aibrain_env = Path.home() / ".aibrain_env"

    for env_path in [home_env, home_aibrain_env, cwd_env]:
        if env_path.is_file():
            env_files.append(env_path)
            parsed = _parse_env_file(env_path)
            for env_var, config_key in ENV_VAR_MAP.items():
                if env_var in parsed and config_key not in discovered:
                    discovered[config_key] = parsed[env_var]
                    sources.append((config_key, f"{env_var} in {env_path}"))

    # 2. Scan actual environment variables (higher priority, overwrites .env)
    for env_var, config_key in ENV_VAR_MAP.items():
        val = os.environ.get(env_var, "").strip()
        if val:
            discovered[config_key] = val
            # Replace any .env source with env var source
            sources = [(k, s) for k, s in sources if k != config_key]
            sources.append((config_key, f"{env_var} in environment"))

    return discovered, sources


def _determine_llm_provider(cfg):
    """Auto-set llm_provider based on which API keys are present."""
    has_anthropic = bool(cfg.get("anthropic_api_key"))
    has_openai = bool(cfg.get("openai_api_key"))
    has_ollama = bool(cfg.get("ollama_url")) and cfg.get("ollama_url") != "http://localhost:11434"

    providers = []
    if has_anthropic:
        providers.append("anthropic")
    if has_openai:
        providers.append("openai")
    if has_ollama:
        providers.append("ollama")

    if len(providers) == 1:
        return providers[0]
    elif len(providers) > 1:
        return "auto"
    else:
        # Check if ollama is actually running at default URL
        if has_anthropic:
            return "anthropic"
        return "auto"


def _merge_config(base, new_values):
    """Merge new values into base config. Never remove or overwrite existing non-empty values."""
    for key, value in new_values.items():
        if key.startswith("_"):
            continue
        existing = base.get(key)
        # Only set if base doesn't have a non-empty value already
        if existing is None or existing == "" or existing == 0:
            base[key] = value
    return base


def _db_is_healthy(path: Path) -> bool:
    """Return True if the SQLite DB at *path* has the memories table and passes integrity_check.

    Used after creation to guard against silent schema failures that leave a
    non-zero-byte but table-less DB behind (the 'ghost DB v2' failure mode).
    """
    if not path.exists() or path.stat().st_size == 0:
        return False
    try:
        db = sqlite3.connect(str(path))
        # Must have a memories table
        tables = {row[0] for row in db.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
        if "memories" not in tables:
            db.close()
            return False
        # Must pass SQLite integrity check
        result = db.execute("PRAGMA integrity_check").fetchone()
        db.close()
        return result is not None and result[0] == "ok"
    except Exception:
        return False


def _safe_init_db():
    """Initialize DB if it doesn't exist or is empty. Returns (created, skipped, error)."""
    AIBRAIN_DIR.mkdir(parents=True, exist_ok=True)

    # Fix #2 — ghost DB: a zero-byte file is left behind by interrupted inits.
    # SQLite will open it without error but the schema query below fails.
    # Delete the ghost explicitly so the full init path can create a real DB.
    if DB_PATH.exists() and DB_PATH.stat().st_size == 0:
        try:
            DB_PATH.unlink()
        except OSError:
            pass  # Cannot remove — fall through and let init overwrite

    if DB_PATH.exists():
        try:
            db = sqlite3.connect(str(DB_PATH))
            count = db.execute("SELECT COUNT(*) FROM memories WHERE active = 1").fetchone()[0]
            db.close()
            if count > 0:
                return False, True, None  # not created, skipped (has data)
        except Exception:
            pass  # Corrupted or missing table — will recreate

    # Use aibrain_db's schema init + workflow seeding to create ALL tables
    # (memories, workflows, skills, etc.). This ensures setup --auto produces a
    # fully functional database, not just a bare memories table.
    try:
        from aibrain_db import seed_from_json, get_db
        db = get_db()
        seed_from_json(db)
        # Seed workflows from each module
        for mod_name, fn_name in [
            ("aibrain_workflows", "seed_workflows"),
            ("aibrain_skill_workflows", "seed_skill_workflows"),
            ("aibrain_user_workflows", "seed_user_workflows"),
            ("aibrain_content_workflows", "seed_content_workflows"),
            ("aibrain_ops_workflows", "seed_ops_workflows"),
        ]:
            try:
                mod = __import__(mod_name)
                getattr(mod, fn_name)(str(DB_PATH))
            except Exception:
                pass
        db.close()
        # Post-creation integrity check — verify DB has tables and passes SQLite checks
        if not _db_is_healthy(DB_PATH):
            try:
                DB_PATH.unlink()
            except OSError:
                pass
            # Fall through to minimal fallback init below
        else:
            return True, False, None
    except Exception:
        pass

    # Fallback: create minimal memories table if full init fails
    db = sqlite3.connect(str(DB_PATH))
    db.execute("""
        CREATE TABLE IF NOT EXISTS memories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            type TEXT DEFAULT 'project',
            tags TEXT DEFAULT '',
            content TEXT DEFAULT '',
            created TEXT DEFAULT (datetime('now')),
            updated TEXT DEFAULT (datetime('now')),
            active INTEGER DEFAULT 1
        )
    """)
    db.execute("""
        CREATE VIRTUAL TABLE IF NOT EXISTS memories_fts USING fts5(
            name, tags, content, content=memories, content_rowid=id
        )
    """)
    db.execute("""
        CREATE TRIGGER IF NOT EXISTS memories_ai AFTER INSERT ON memories BEGIN
            INSERT INTO memories_fts(rowid, name, tags, content)
            VALUES (new.id, new.name, new.tags, new.content);
        END
    """)
    db.execute("""
        CREATE TRIGGER IF NOT EXISTS memories_au AFTER UPDATE ON memories BEGIN
            INSERT INTO memories_fts(memories_fts, rowid, name, tags, content)
            VALUES ('delete', old.id, old.name, old.tags, old.content);
            INSERT INTO memories_fts(rowid, name, tags, content)
            VALUES (new.id, new.name, new.tags, new.content);
        END
    """)
    db.execute("""
        CREATE TRIGGER IF NOT EXISTS memories_ad AFTER DELETE ON memories BEGIN
            INSERT INTO memories_fts(memories_fts, rowid, name, tags, content)
            VALUES ('delete', old.id, old.name, old.tags, old.content);
        END
    """)

    # Load starter + seed memories if available
    now = datetime.now().isoformat()
    seed_count = 0
    starter_count = 0
    if STARTER_PATH.exists():
        try:
            starters = json.loads(STARTER_PATH.read_text(encoding="utf-8"))
            for mem in starters.get("memories", []):
                db.execute(
                    "INSERT INTO memories (name, type, tags, content, created, updated) "
                    "VALUES (?, ?, ?, ?, ?, ?)",
                    (mem["name"], mem["type"], mem.get("tags", ""),
                     mem["content"], now, now)
                )
                starter_count += 1
        except Exception:
            pass
    if SEED_PATH.exists():
        try:
            seeds = json.loads(SEED_PATH.read_text(encoding="utf-8"))
            for mem in seeds.get("memories", []):
                db.execute(
                    "INSERT INTO memories (name, type, tags, content, created, updated) "
                    "VALUES (?, ?, ?, ?, ?, ?)",
                    (mem["name"], mem["type"], mem.get("tags", ""),
                     mem["content"], now, now)
                )
                seed_count += 1
        except Exception:
            pass

    # Add setup record
    db.execute(
        "INSERT INTO memories (name, type, tags, content, created, updated) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        (
            "aibrain_setup_complete", "project", "aibrain,setup",
            f"AIBrain auto-setup completed at {now}.\n"
            f"Platform: {platform.system()} {platform.release()}\n"
            f"Python: {sys.version.split()[0]}\n"
            f"Starter memories loaded: {starter_count}\n"
            f"Seed memories loaded: {seed_count}",
            now, now
        )
    )
    db.commit()
    db.close()

    # Post-creation integrity check — confirm tables exist and DB is valid
    if not _db_is_healthy(DB_PATH):
        return False, False, "DB integrity check failed after fallback creation"

    return True, False, None  # created, not skipped


def _enable_default_workflows():
    """Enable all free-tier workflows from workflow_tiers.json.

    Uses auto_config_free_tier() from the updater for consistent behavior
    between fresh installs and updates. Falls back to direct tier reading
    if the updater import fails.
    """
    try:
        from aibrain_update import auto_config_free_tier
        enabled, added = auto_config_free_tier()
        return enabled + added
    except ImportError:
        pass

    # Fallback: read tiers file directly
    tiers_path = AIBRAIN_DIR / "workflow_tiers.json"
    if not tiers_path.exists():
        return 0

    try:
        tiers = json.loads(tiers_path.read_text(encoding="utf-8"))
        free_workflows = set(tiers.get("tiers", {}).get("free", {}).get("workflows", []))
    except (json.JSONDecodeError, OSError):
        return 0

    if not free_workflows or not SCHEDULED_JOBS_PATH.exists():
        return 0

    try:
        data = json.loads(SCHEDULED_JOBS_PATH.read_text(encoding="utf-8"))
        updated = 0
        for job in data.get("jobs", []):
            if job["name"] in free_workflows and not job.get("enabled"):
                job["enabled"] = True
                job["tier"] = "free"
                updated += 1
        data["_updated"] = datetime.now().strftime("%Y-%m-%d")
        SCHEDULED_JOBS_PATH.write_text(json.dumps(data, indent=2), encoding="utf-8")
        return updated
    except (json.JSONDecodeError, OSError, KeyError):
        pass
    return 0


def _print_setup_summary(cfg, sources, files_created, files_skipped):
    """Print final summary of what was configured, what's missing, and next steps."""
    print()
    print(f"  {c('teal', '+==============================================+')}")
    print(f"  {c('teal', '|')}  {c('bold', 'Setup Summary')}                              {c('teal', '|')}")
    print(f"  {c('teal', '+==============================================+')}")

    # What was configured
    print(f"\n  {c('bold', 'Configured:')}")
    configured_keys = set()
    for config_key, source in sources:
        configured_keys.add(config_key)
        # Mask sensitive values
        if "key" in config_key or "password" in config_key or "token" in config_key:
            val = cfg.get(config_key, "")
            display = val[:8] + "..." if len(val) > 8 else val
        else:
            display = cfg.get(config_key, "")
        print(f"    {c('green', '-')} {config_key}: {display} {c('dim', f'(from {source})')}")

    if cfg.get("llm_provider"):
        print(f"    {c('green', '-')} llm_provider: {cfg['llm_provider']} {c('dim', '(auto-detected)')}")

    # What's missing
    important_keys = {
        "anthropic_api_key": "Anthropic API key (AI workflows)",
        "openai_api_key": "OpenAI API key (alternative LLM)",
        "github_token": "GitHub token (repo monitoring)",
        "agent_email": "Email address (email workflows)",
        "agent_email_password": "Email app password (email send/receive)",
        "telegram_bot_token": "Telegram bot token (notifications)",
        "telegram_chat_id": "Telegram chat ID (notifications)",
    }
    missing = {k: v for k, v in important_keys.items() if not cfg.get(k)}
    if missing:
        print(f"\n  {c('bold', 'Not configured')} {c('dim', '(optional — add later in config.json)')}:")
        for key, desc in missing.items():
            print(f"    {c('yellow', '-')} {desc}")

    # File safety report
    print(f"\n  {c('bold', 'Files:')}")
    for path, action in files_created:
        print(f"    {c('green', 'Created:')} {path}")
    for path, reason in files_skipped:
        print(f"    {c('dim', 'Skipped:')} {path} ({reason})")
    print(f"    {c('dim', 'Read-only:')} .env files (never modified)")

    # Next steps
    print(f"\n  {c('bold', 'Next steps:')}")
    print(f"    {c('teal', '$')} aibrain server        {c('dim', '# Start the API + dashboard')}")
    print(f"    {c('teal', '$')} aibrain mcp           {c('dim', '# Start MCP server for Claude')}")
    print(f"    {c('dim', 'Dashboard:')} http://localhost:5173")
    print(f"    {c('dim', 'API docs:')}  http://localhost:8001/docs")
    print()


def auto_setup():
    """Fully automatic setup — no interactive prompts.

    Discovers env vars + .env files, creates config.json (merged),
    initializes DB, enables default workflows, prints summary.
    """
    banner()
    print(f"  {c('teal', 'Auto-detect mode')} -- no prompts, discovering everything automatically\n")

    files_created = []
    files_skipped = []

    # Step 1: Scan environment
    print(f"  {c('bold', 'Scanning environment...')}")
    discovered, sources = scan_environment()

    if sources:
        for config_key, source in sources:
            ok(f"Found {config_key} from {source}")
    else:
        info("No API keys or credentials found in environment or .env files")

    # Step 2: Build config
    print(f"\n  {c('bold', 'Building config.json...')}")

    example_path = AIBRAIN_DIR / "config.json.example"
    if CONFIG_PATH.exists():
        base = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        info("Merging with existing config.json (existing values preserved)")
        config_action = "Merged"
    elif example_path.exists():
        base = json.loads(example_path.read_text(encoding="utf-8"))
        base.pop("_readme", None)
        config_action = "Created"
    else:
        base = {}
        config_action = "Created"

    # Merge discovered values (never overwrite existing non-empty values)
    base = _merge_config(base, discovered)

    # Auto-set llm_provider
    base["llm_provider"] = _determine_llm_provider(base)

    # Set paths
    if not base.get("memory_db"):
        base["memory_db"] = str(DB_PATH)
    if not base.get("cron_jobs"):
        base["cron_jobs"] = str(SCHEDULED_JOBS_PATH)

    base["setup_complete"] = True
    base.pop("_readme", None)

    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    CONFIG_PATH.write_text(json.dumps(base, indent=2), encoding="utf-8")
    files_created.append((CONFIG_PATH, config_action))
    ok(f"config.json {config_action.lower()}")

    # Step 3: Initialize DB
    print(f"\n  {c('bold', 'Initializing database...')}")
    db_created, db_skipped, db_err = _safe_init_db()
    if db_skipped:
        ok("Database already exists with data -- skipped")
        files_skipped.append((DB_PATH, "already has data"))
    elif db_created:
        ok(f"Database created at {DB_PATH}")
        files_created.append((DB_PATH, "Created"))
    elif db_err:
        warn(f"Database error: {db_err}")

    # Step 4: Enable default workflows
    print(f"\n  {c('bold', 'Enabling default workflows...')}")
    wf_updated = _enable_default_workflows()
    if wf_updated > 0:
        ok(f"Enabled {wf_updated} free-tier workflows (self-learning, infrastructure, basics)")
    else:
        info("No workflow changes (already configured or no scheduled_jobs.json)")

    # Company setup (auto mode — create default company silently)
    try:
        from aibrain.core.companies import create_company, hire_agent, list_companies
        existing = list_companies()
        if not existing:
            agent_name = base.get("agent_name", "Agent")
            company = create_company(f"{agent_name}'s Team", mission="Deliver verified, high-quality results through structured delegation and QA.")
            cid = company["id"]
            hire_agent(cid, "CEO", role="ceo")
            for name, role in [("Lead Engineer","general"),("Research Analyst","general"),("Content Writer","general"),("QA Lead","manager"),("Product Manager","general")]:
                hire_agent(cid, name, role=role)
            ok(f"Company created: {agent_name}'s Team with CEO + 5 workers")
    except Exception as e:
        warn(f"Company auto-setup skipped: {e}")

    # Summary
    _print_setup_summary(base, sources, files_created, files_skipped)
    clear_progress()


def config_setup(config_path):
    """Setup from a pre-filled config JSON file — no prompts, no discovery.

    Reads the given JSON, merges it into config.json (preserving existing values),
    initializes DB, enables workflows listed in the config.
    """
    banner()
    print(f"  {c('teal', 'Config file mode')} -- using {config_path}\n")

    files_created = []
    files_skipped = []

    # Read the provided config
    config_file = Path(config_path)
    if not config_file.is_file():
        fail(f"Config file not found: {config_path}")
        sys.exit(1)

    try:
        new_cfg = json.loads(config_file.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError) as e:
        fail(f"Cannot parse config file: {e}")
        sys.exit(1)

    ok(f"Read config from {config_path}")

    # Merge with existing or template
    example_path = AIBRAIN_DIR / "config.json.example"
    if CONFIG_PATH.exists():
        base = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        info("Merging with existing config.json (existing values preserved)")
        config_action = "Merged"
    elif example_path.exists():
        base = json.loads(example_path.read_text(encoding="utf-8"))
        base.pop("_readme", None)
        config_action = "Created"
    else:
        base = {}
        config_action = "Created"

    # Apply new config values (never overwrite existing non-empty)
    base = _merge_config(base, new_cfg)

    # Auto-set llm_provider if not explicitly provided
    if not new_cfg.get("llm_provider"):
        base["llm_provider"] = _determine_llm_provider(base)

    if not base.get("memory_db"):
        base["memory_db"] = str(DB_PATH)
    if not base.get("cron_jobs"):
        base["cron_jobs"] = str(SCHEDULED_JOBS_PATH)

    base["setup_complete"] = True
    base.pop("_readme", None)

    CONFIG_PATH.write_text(json.dumps(base, indent=2), encoding="utf-8")
    files_created.append((CONFIG_PATH, config_action))
    ok(f"config.json {config_action.lower()}")

    # Initialize DB
    print(f"\n  {c('bold', 'Initializing database...')}")
    db_created, db_skipped, db_err = _safe_init_db()
    if db_skipped:
        ok("Database already exists with data -- skipped")
        files_skipped.append((DB_PATH, "already has data"))
    elif db_created:
        ok(f"Database created at {DB_PATH}")
        files_created.append((DB_PATH, "Created"))

    # Enable workflows if specified in config
    selected = set(new_cfg.get("_selected_workflows", []))
    if selected and SCHEDULED_JOBS_PATH.exists():
        try:
            data = json.loads(SCHEDULED_JOBS_PATH.read_text(encoding="utf-8"))
            updated = 0
            for job in data.get("jobs", []):
                if job["name"] in selected and not job.get("enabled"):
                    job["enabled"] = True
                    updated += 1
            data["_updated"] = datetime.now().strftime("%Y-%m-%d")
            SCHEDULED_JOBS_PATH.write_text(json.dumps(data, indent=2), encoding="utf-8")
            if updated:
                ok(f"Enabled {updated} workflows from config")
        except (json.JSONDecodeError, OSError, KeyError):
            pass
    else:
        # Fall back to default workflows
        wf_updated = _enable_default_workflows()
        if wf_updated > 0:
            ok(f"Enabled {wf_updated} default workflows (productivity + research)")

    # Build sources list for summary
    sources = []
    for key in sorted(new_cfg.keys()):
        if key.startswith("_"):
            continue
        if new_cfg[key] and new_cfg[key] != base.get(key, ""):
            sources.append((key, config_path))
        elif new_cfg[key]:
            sources.append((key, config_path))

    _print_setup_summary(base, sources, files_created, files_skipped)
    clear_progress()


# ---------------------------------------------------------------------------
# Agent hook auto-configuration
# ---------------------------------------------------------------------------

def configure_agent_hooks(progress):
    """Auto-detect AI agent and configure hooks, MCP servers, and daemon autostart."""
    step_header(10, 11, "Configuring agent hooks & services")

    home = Path.home()
    python = sys.executable
    aibrain_root = str(AIBRAIN_DIR)
    cfg = progress.get("config", {})

    # Detect Claude Code
    claude_settings = home / ".claude" / "settings.json"
    if claude_settings.exists():
        info("Claude Code detected")
        try:
            settings = json.loads(claude_settings.read_text(encoding="utf-8"))
        except Exception:
            settings = {}

        hooks = settings.get("hooks", {})
        changed = False

        # --- UserPromptSubmit: broker_hook (peer messages + stack restore) ---
        broker_hook_cmd = f"{python} {aibrain_root}/broker_hook.py"
        existing_submit = hooks.get("UserPromptSubmit", [])
        has_broker_hook = any(
            broker_hook_cmd in h.get("command", "")
            for group in existing_submit
            for h in group.get("hooks", [])
        )
        if not has_broker_hook:
            if not existing_submit:
                hooks["UserPromptSubmit"] = []
            hooks["UserPromptSubmit"].append({
                "hooks": [{
                    "type": "command",
                    "command": broker_hook_cmd,
                    "timeout": 5,
                    "statusMessage": "Checking messages..."
                }]
            })
            changed = True
            ok("Added UserPromptSubmit hook (broker_hook — peer messages + stack restore)")

        # --- PreCompact hooks ---
        if "PreCompact" not in hooks:
            hooks["PreCompact"] = [{
                "matcher": "*",
                "hooks": [
                    {
                        "type": "command",
                        "command": f"{python} {aibrain_root}/realtime_learner.py",
                        "timeout": 15,
                        "statusMessage": "Extracting learnings before compaction..."
                    },
                    {
                        "type": "command",
                        "command": f"{python} {aibrain_root}/workflows/memory_md_sync.py --stats-only --all",
                        "timeout": 10,
                        "statusMessage": "Syncing MEMORY.md with DB..."
                    }
                ]
            }]
            changed = True
            ok("Added PreCompact hooks (realtime_learner + memory_md_sync)")

        # --- PostCompact hook ---
        if "PostCompact" not in hooks:
            hooks["PostCompact"] = [{
                "matcher": "*",
                "hooks": [{
                    "type": "command",
                    "command": f"{python} {aibrain_root}/workflows/memory_md_sync.py --stats-only --all",
                    "timeout": 10,
                    "statusMessage": "Syncing MEMORY.md after compaction..."
                }]
            }]
            changed = True
            ok("Added PostCompact hook (memory_md_sync)")

        # --- Stop hook ---
        if "Stop" not in hooks:
            hooks["Stop"] = [{
                "matcher": "*",
                "hooks": [{
                    "type": "command",
                    "command": f"{python} {aibrain_root}/realtime_learner.py",
                    "timeout": 10
                }]
            }]
            changed = True
            ok("Added Stop hook (realtime_learner)")

        if changed:
            settings["hooks"] = hooks
            claude_settings.write_text(json.dumps(settings, indent=2), encoding="utf-8")
            ok("Claude Code hooks configured")
        else:
            info("Claude Code hooks already configured")

        # --- MCP server registration ---
        mcp_config = home / ".claude" / "projects" / "mcp.json"
        # Also check project-scoped .mcp.json
        project_mcp = AIBRAIN_DIR / ".mcp.json"
        if project_mcp.exists():
            try:
                mcp = json.loads(project_mcp.read_text(encoding="utf-8"))
            except Exception:
                mcp = {"mcpServers": {}}
        else:
            mcp = {"mcpServers": {}}

        mcp_changed = False
        db_path = str(AIBRAIN_DIR / "aibrain.db")
        servers_to_register = {
            # Always pass --db explicitly so account/profile switches never
            # silently fall back to a stub shadow DB in a different directory.
            "aibrain-memory": (f"{aibrain_root}/mcp_server.py", ["--db", db_path]),
            "peer-discovery": (f"{aibrain_root}/mcp_peer_discovery.py", []),
        }
        for name, (script, extra_args) in servers_to_register.items():
            desired = {"command": python, "args": [script] + extra_args}
            existing_entry = mcp.get("mcpServers", {}).get(name)
            # Update if missing OR if --db arg is absent (fixes pre-existing installs)
            needs_update = (
                existing_entry is None or
                not isinstance(existing_entry, dict) or
                (name == "aibrain-memory" and "--db" not in existing_entry.get("args", []))
            )
            if needs_update:
                mcp.setdefault("mcpServers", {})[name] = desired
                mcp_changed = True
                ok(f"Registered MCP server: {name} (db={db_path})")

        if mcp_changed:
            project_mcp.write_text(json.dumps(mcp, indent=2), encoding="utf-8")
            ok("MCP servers configured in .mcp.json")
        else:
            info("MCP servers already registered")

    else:
        info("No Claude Code detected -- using cron-based memory sync (every 4h)")
        info("The scheduled jobs (learning_extractor, realtime_learner, memory_md_sync)")
        info("will keep your agent's memory current automatically.")
        info("If you install Claude Code later, re-run setup to add hooks.")

    # --- Peer daemon autostart (all platforms) ---
    _install_peer_daemon_autostart(cfg)

    # --- Telegram poller autostart (if configured) ---
    _install_telegram_poller_autostart(cfg)

    # --- Telegram verification ---
    _verify_telegram(cfg)

    # --- Initial stack snapshot ---
    stack_script = AIBRAIN_DIR / "stack_snapshot.py"
    if stack_script.exists():
        try:
            subprocess.run([sys.executable, str(stack_script), "save", "last"],
                           cwd=str(AIBRAIN_DIR), capture_output=True, timeout=15)
            ok("Initial stack snapshot saved")
        except Exception:
            warn("Stack snapshot failed — will retry on first prompt")

    # --- Token compression hook (auto-on for all users) ---
    try:
        from aibrain.tools.compress.hook import install_hook
        msg = install_hook()
        ok(f"Token compression hook installed ({msg.splitlines()[0]})")
        info("Saves 60-90% on git/test/build output. Disable anytime: aibrain-compress disable")
    except Exception as _e:
        warn(f"Could not install compress hook: {_e} (run 'aibrain-compress init' manually)")

    progress.setdefault("completed_steps", []).append("agent_hooks")
    save_progress(progress)


def _install_peer_daemon_autostart(cfg):
    """Install peer_daemon as an autostart service on the current platform.

    Requires Pro tier (Tailscale mesh networking).
    """
    try:
        from aibrain_licensing import check_tier
        if not check_tier("pro"):
            info("Peer daemon autostart requires Pro tier (mesh networking)")
            info("Upgrade at https://myaibrain.org/pricing")
            return
    except ImportError:
        pass  # No licensing module — allow setup (development mode)

    python = sys.executable
    daemon_script = str(AIBRAIN_DIR / "peer_daemon.py")
    # Read from config — setup interview sets these, fall back to sensible defaults
    agent_id = cfg.get("agent_id", cfg.get("agent_name", platform.node().lower().split(".")[0]))
    broker_url = cfg.get("peer_broker_url", cfg.get("peer_url", "http://localhost:7800"))
    log_file = str(AIBRAIN_DIR / "peer_daemon.log")

    system = platform.system()

    if system == "Linux":
        # systemd service
        service_name = "aibrain-peer-daemon"
        service_path = Path(f"/etc/systemd/system/{service_name}.service")
        user_service = Path.home() / ".config" / "systemd" / "user" / f"{service_name}.service"

        # Try user-level service first (no sudo needed)
        service_content = f"""[Unit]
Description=AIBrain Peer Daemon
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart={python} {daemon_script}
Restart=on-failure
RestartSec=10
Environment=PEER_AGENT_ID={agent_id}
Environment=PEER_BROKER_URL={broker_url}
WorkingDirectory={AIBRAIN_DIR}
StandardOutput=append:{log_file}
StandardError=append:{log_file}

[Install]
WantedBy=default.target
"""
        try:
            user_service.parent.mkdir(parents=True, exist_ok=True)
            user_service.write_text(service_content)
            subprocess.run(["systemctl", "--user", "daemon-reload"],
                           capture_output=True, timeout=10)
            subprocess.run(["systemctl", "--user", "enable", service_name],
                           capture_output=True, timeout=10)
            subprocess.run(["systemctl", "--user", "start", service_name],
                           capture_output=True, timeout=10)
            ok(f"Peer daemon installed as user service: {service_name}")
        except Exception as e:
            warn(f"Could not install systemd service: {e}")
            info("Start manually: python peer_daemon.py")

    elif system == "Darwin":
        # launchd plist
        plist_name = "org.aibrain.peer-daemon"
        plist_path = Path.home() / "Library" / "LaunchAgents" / f"{plist_name}.plist"
        plist_content = f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>{plist_name}</string>
    <key>ProgramArguments</key>
    <array>
        <string>{python}</string>
        <string>{daemon_script}</string>
    </array>
    <key>EnvironmentVariables</key>
    <dict>
        <key>PEER_AGENT_ID</key>
        <string>{agent_id}</string>
        <key>PEER_BROKER_URL</key>
        <string>{broker_url}</string>
    </dict>
    <key>WorkingDirectory</key>
    <string>{AIBRAIN_DIR}</string>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <true/>
    <key>StandardOutPath</key>
    <string>{log_file}</string>
    <key>StandardErrorPath</key>
    <string>{log_file}</string>
</dict>
</plist>
"""
        try:
            plist_path.parent.mkdir(parents=True, exist_ok=True)
            plist_path.write_text(plist_content)
            subprocess.run(["launchctl", "load", str(plist_path)],
                           capture_output=True, timeout=10)
            ok(f"Peer daemon installed as launchd agent: {plist_name}")
        except Exception as e:
            warn(f"Could not install launchd agent: {e}")
            info("Start manually: python peer_daemon.py")

    elif system == "Windows":
        # Windows Task Scheduler via schtasks
        task_name = "AIBrain Peer Daemon"
        try:
            # Create a wrapper script that sets env vars and runs daemon
            wrapper = AIBRAIN_DIR / "start_peer_daemon.bat"
            wrapper.write_text(
                f'@echo off\r\n'
                f'set PEER_AGENT_ID={agent_id}\r\n'
                f'set PEER_BROKER_URL={broker_url}\r\n'
                f'"{python}" "{daemon_script}" >> "{log_file}" 2>&1\r\n',
                encoding="utf-8"
            )
            subprocess.run([
                "schtasks", "/Create", "/F",
                "/TN", task_name,
                "/TR", str(wrapper),
                "/SC", "ONLOGON",
                "/RL", "LIMITED",
            ], capture_output=True, timeout=10)
            ok(f"Peer daemon installed as Windows scheduled task: {task_name}")
        except Exception as e:
            warn(f"Could not create scheduled task: {e}")
            info("Start manually: python peer_daemon.py")

    else:
        warn(f"Unknown platform: {system} — start peer_daemon.py manually")


def _install_telegram_poller_autostart(cfg):
    """Install telegram_poller.py as an autostart service if Telegram is configured."""
    token = cfg.get("telegram_token", os.environ.get("TELEGRAM_TOKEN", ""))
    if not token:
        return  # Telegram not configured — skip

    python = sys.executable
    poller_script = str(AIBRAIN_DIR / "telegram_poller.py")
    log_file = str(AIBRAIN_DIR / "data" / "telegram_poller.log")

    if not Path(poller_script).exists():
        warn("telegram_poller.py not found — skipping autostart")
        return

    system = platform.system()

    if system == "Linux":
        service_name = "aibrain-telegram-poller"
        user_service = Path.home() / ".config" / "systemd" / "user" / f"{service_name}.service"
        if user_service.exists():
            info("Telegram poller service already installed")
            return

        service_content = f"""[Unit]
Description=AIBrain Telegram Poller
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart={python} {poller_script}
Restart=on-failure
RestartSec=10
WorkingDirectory={AIBRAIN_DIR}
StandardOutput=append:{log_file}
StandardError=append:{log_file}

[Install]
WantedBy=default.target
"""
        try:
            user_service.parent.mkdir(parents=True, exist_ok=True)
            user_service.write_text(service_content)
            subprocess.run(["systemctl", "--user", "daemon-reload"],
                           capture_output=True, timeout=10)
            subprocess.run(["systemctl", "--user", "enable", service_name],
                           capture_output=True, timeout=10)
            subprocess.run(["systemctl", "--user", "start", service_name],
                           capture_output=True, timeout=10)
            ok(f"Telegram poller installed as user service: {service_name}")
        except Exception as e:
            warn(f"Could not install systemd service: {e}")
            info("Start manually: python telegram_poller.py")

    elif system == "Darwin":
        plist_name = "org.aibrain.telegram-poller"
        plist_path = Path.home() / "Library" / "LaunchAgents" / f"{plist_name}.plist"
        if plist_path.exists():
            info("Telegram poller agent already installed")
            return

        plist_content = f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>{plist_name}</string>
    <key>ProgramArguments</key>
    <array>
        <string>{python}</string>
        <string>{poller_script}</string>
    </array>
    <key>WorkingDirectory</key>
    <string>{AIBRAIN_DIR}</string>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <true/>
    <key>StandardOutPath</key>
    <string>{log_file}</string>
    <key>StandardErrorPath</key>
    <string>{log_file}</string>
</dict>
</plist>
"""
        try:
            plist_path.parent.mkdir(parents=True, exist_ok=True)
            plist_path.write_text(plist_content)
            subprocess.run(["launchctl", "load", str(plist_path)],
                           capture_output=True, timeout=10)
            ok(f"Telegram poller installed as launchd agent: {plist_name}")
        except Exception as e:
            warn(f"Could not install launchd agent: {e}")
            info("Start manually: python telegram_poller.py")

    elif system == "Windows":
        task_name = "AIBrain Telegram Poller"
        try:
            wrapper = AIBRAIN_DIR / "start_telegram_poller.bat"
            wrapper.write_text(
                f'@echo off\r\n'
                f'"{python}" "{poller_script}" >> "{log_file}" 2>&1\r\n',
                encoding="utf-8"
            )
            subprocess.run([
                "schtasks", "/Create", "/F",
                "/TN", task_name,
                "/TR", str(wrapper),
                "/SC", "ONLOGON",
                "/RL", "LIMITED",
            ], capture_output=True, timeout=10)
            ok(f"Telegram poller installed as Windows scheduled task: {task_name}")
        except Exception as e:
            warn(f"Could not create scheduled task: {e}")
            info("Start manually: python telegram_poller.py")

    else:
        warn(f"Unknown platform: {system} — start telegram_poller.py manually")


def _verify_telegram(cfg):
    """Send a test message to verify Telegram bot configuration."""
    token = cfg.get("telegram_token", os.environ.get("TELEGRAM_TOKEN", ""))
    chat_id = cfg.get("telegram_chat_id", os.environ.get("TELEGRAM_CHAT_ID", ""))
    if not token or not chat_id:
        return  # Not configured

    try:
        import urllib.request
        data = json.dumps({"chat_id": chat_id, "text": "AIBrain connected. Setup complete."}).encode()
        req = urllib.request.Request(
            f"https://api.telegram.org/bot{token}/sendMessage",
            data=data, headers={"Content-Type": "application/json"},
            method="POST"
        )
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        with opener.open(req, timeout=5) as r:
            result = json.loads(r.read())
            if result.get("ok"):
                ok("Telegram verified — test message sent")
            else:
                warn(f"Telegram test failed: {result.get('description', 'unknown error')}")
    except Exception as e:
        warn(f"Telegram verification failed: {e}")


# ---------------------------------------------------------------------------
# Main (interactive wizard)
# ---------------------------------------------------------------------------

def main():
    banner()

    # Check for partial progress from previous run
    progress = load_progress()
    completed = progress.get("completed_steps", [])

    if completed:
        print(f"  {c('yellow', 'Resuming from previous run.')}")
        info(f"Steps already done: {', '.join(completed)}")
        resume = confirm("Continue from where you left off?", default=True)
        if not resume:
            progress = {"completed_steps": [], "config": {}}
            info("Starting fresh.")
        print()

    steps = [
        ("prerequisites", check_prerequisites),
        ("interview", interactive_setup),
        ("first_impression", first_impression_demo),
        ("config", generate_config),
        ("memory_db", init_memory_db),
        ("frontend", install_frontend),
        ("scheduled_jobs", create_scheduled_jobs),
        ("connectivity", test_connectivity),
        ("brain_scan", scan_and_build_brain),
        ("scan_session_history", scan_session_history),
        ("connect_agent", connect_agent),
        ("agent_hooks", configure_agent_hooks),
        ("company_setup", company_setup),
        ("community", community_optin),
        ("summary", print_summary),
    ]

    for step_name, step_fn in steps:
        if step_name in progress.get("completed_steps", []):
            info(f"Skipping {step_name} (already done)")
            continue

        try:
            result = step_fn(progress)
            if result is False:
                print()
                fail(f"Step '{step_name}' failed.")
                info("Progress saved. Re-run setup_wizard.py to resume.")
                save_progress(progress)
                sys.exit(1)
        except KeyboardInterrupt:
            print(f"\n\n  {c('yellow', 'Setup paused.')}")
            info("Progress saved. Re-run setup_wizard.py to resume.")
            save_progress(progress)
            sys.exit(0)
        except Exception as e:
            print()
            fail(f"Error in {step_name}: {e}")
            info("Progress saved. Re-run setup_wizard.py to resume.")
            save_progress(progress)

            if confirm("Skip this step and continue?", default=True):
                progress["completed_steps"].append(step_name)
                save_progress(progress)
                continue
            else:
                sys.exit(1)

    print(f"  {c('teal', 'Welcome to AIBrain.')}\n")


def company_setup(progress):
    """Step: Set up a company (team of AI workers) for task delegation."""
    step_header(11, 13, "Set up your AI company")

    print(f"""
  {c('teal', 'Why set up a company?')}

  AIBrain works best with a team structure:

    You → CEO agent → delegates tasks → worker agents
                ↑                              ↓
         audit / QA / verify ←←←←← results flow back

  Workers handle specialised tasks (code, research, writing, QA).
  The CEO audits every result before it reaches you.
  Users who adopt this model consistently get better, verified outputs.
""")

    want_company = confirm("Set up a default AI company now?", default=True)
    if not want_company:
        info("Skipped. You can run 'aibrain company create' any time.")
        progress["completed_steps"].append("company_setup")
        save_progress(progress)
        return

    cfg = progress.get("config", {})
    agent_name = cfg.get("agent_name", "Agent")
    default_company_name = f"{agent_name}'s Team"
    company_name = prompt("Company name", default=default_company_name)

    try:
        from aibrain.core.companies import create_company, hire_agent

        company = create_company(company_name, mission="Deliver verified, high-quality results to the user through structured delegation and QA.")
        cid = company["id"]

        # CEO
        ceo = hire_agent(cid, "CEO", role="ceo")

        # Default worker roster
        default_workers = [
            ("Lead Engineer",    "general", "Code, features, bug fixes, technical tasks"),
            ("Research Analyst", "general", "Research, dossiers, fact-finding, data lookup"),
            ("Content Writer",   "general", "Docs, reports, emails, written content"),
            ("QA Lead",          "manager", "Testing, verification, quality checks"),
            ("Product Manager",  "general", "Feature planning, roadmap, requirements"),
        ]
        workers_hired = []
        for name, role, _ in default_workers:
            w = hire_agent(cid, name, role=role)
            workers_hired.append((name, w["id"]))

        progress["config"]["company_id"] = cid
        progress["config"]["company_name"] = company_name
        save_progress(progress)

        ok(f"Company created: {company_name} (id: {cid})")
        ok(f"CEO hired: {ceo['id']}")
        for name, wid in workers_hired:
            ok(f"Worker: {name} ({wid})")

        print(f"""
  {c('bold', 'Your team is ready.')}

  Delegation flow:
    aibrain task create "Write a blog post" --company {cid}
    → CEO assigns to Content Writer
    → Writer completes
    → CEO audits and verifies
    → Result presented to you

  Manage team:
    aibrain company list
    aibrain agent list --company {cid}
    aibrain task list  --company {cid}
""")

    except Exception as e:
        warn(f"Company setup failed: {e}")
        info("You can set up manually with: aibrain company create")

    progress["completed_steps"].append("company_setup")
    save_progress(progress)


def community_optin(progress):
    """Offer community opt-in: email for updates, Discord link."""
    step_header(12, 13, "Join the Community")

    print(f"  {c('teal', 'AIBrain is built by a community of builders.')}")
    print(f"  {c('dim', 'Get notified about new brain packs, features, and marketplace updates.')}")
    print()

    # Email opt-in
    email = progress.get("config", {}).get("user_email", "")
    if not email:
        email = input(f"  {c('bold', 'Email for updates (optional, press Enter to skip):')} ").strip()

    if email and "@" in email:
        # Send to registration endpoint
        try:
            data = json.dumps({
                "email": email,
                "source": "setup_wizard",
                "version": _aibrain_version(),
                "platform": platform.system(),
                "timestamp": datetime.utcnow().isoformat(),
            }).encode()
            req = urllib.request.Request(
                "https://myaibrain.org/api/community/register",
                data=data,
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            try:
                urllib.request.urlopen(req, timeout=5)
                ok("Registered for updates!")
            except Exception:
                # Silently fail — don't block setup for network issues
                ok("Email saved locally. We'll sync when connected.")

            # Save locally too
            progress.setdefault("config", {})["community_email"] = email
        except Exception:
            pass
    else:
        info("No problem — you can join anytime at myaibrain.org")

    print()

    # Brain portability
    print(f"\n  {c('teal', '🧠 Your brain is portable:')}")
    print(f"  {c('white', 'Export it anytime:  aibrain export --output my_brain.zip')}")
    print(f"  {c('white', 'Import on any machine:  aibrain import my_brain.zip')}")
    print(f"  {c('dim', 'Your memories, workflows, and evolution history — one file.')}")
    print()

    # Discord link
    print(f"  {c('teal', 'Join our Discord:')} https://discord.gg/aibrain")
    print(f"  {c('dim', 'Share brain packs, get help, show what you built.')}")
    print()

    # GitHub star prompt
    print(f"  {c('yellow', '⭐ One last thing:')}")
    print(f"  {c('white', 'Star us on GitHub — it takes 2 seconds and helps others find AIBrain.')}")
    print(f"  {c('teal', '  → https://github.com/DeckerOps/aibrain')}")
    print()
    try:
        star = input("  Open GitHub now? [y/N] ").strip().lower()
        if star == 'y':
            import webbrowser
            webbrowser.open("https://github.com/DeckerOps/aibrain")
    except Exception:
        pass
    print()

    # Save opt-in status
    progress.setdefault("config", {})["community_optin"] = bool(email)
    progress.setdefault("completed_steps", []).append("community")
    save_progress(progress)
    return True


def _run_wizard_legacy(args=None):
    """Entry point callable from `aibrain setup` (legacy — superseded by run_wizard below).

    Supports:
        --auto / --defaults  Fully automatic, no prompts
        --config path.json   Use a pre-filled config file
        (no flags)           Interactive wizard
    """
    if args is None:
        args = sys.argv[1:]  # skip 'setup' command word if called directly
    if '--reconfigure' in args:
        from aibrain.tools.setup.reconfigure import interactive_menu
        return interactive_menu()
    if '--auto' in args or '--defaults' in args:
        return auto_setup()
    if '--config' in args:
        idx = args.index('--config')
        if idx + 1 < len(args):
            return config_setup(args[idx + 1])
        else:
            fail("--config requires a path argument")
            sys.exit(1)
    return main()  # full interactive mode


# ---------------------------------------------------------------------------
# Quick wizard — simplified 4-step onboarding (the default new-user path)
# ---------------------------------------------------------------------------

def run_quick_wizard():
    """Zero-friction onboarding. Auto-detects everything from environment.

    If ANTHROPIC_API_KEY (or OPENAI_API_KEY) is already set — no API key prompt.
    If AGENT_ID is already set — no name prompt.
    A fresh user with a typical agent environment gets through with zero prompts.
    Only prompts for what is genuinely missing.

    API key is persisted to AIBRAIN_DIR/.aibrain_config.json (gitignored).
    """
    import warnings
    warnings.warn(
        "run_quick_wizard() is deprecated. Use `aibrain setup` (aibrain.cli.setup_wizard.main).",
        DeprecationWarning, stacklevel=2
    )
    from aibrain import __version__

    print(f"\nAIBrain v{__version__} — setup")
    print("=" * 26)
    print()

    # ------------------------------------------------------------------ #
    # Step 1/4 — Configure LLM (auto-detect from environment)             #
    # ------------------------------------------------------------------ #

    # Auto-detect provider and key from environment — no choice menu needed
    anthropic_key = os.environ.get("ANTHROPIC_API_KEY", "")
    openai_key = os.environ.get("OPENAI_API_KEY", "")
    ollama_running = False
    try:
        import urllib.request as _ur
        _ur.urlopen("http://localhost:11434", timeout=1).close()
        ollama_running = True
    except Exception:
        pass

    if anthropic_key:
        provider = "anthropic"
        api_key = anthropic_key
        print("  [OK] Anthropic API key found in environment")
    elif openai_key:
        provider = "openai"
        api_key = openai_key
        print("  [OK] OpenAI API key found in environment")
    elif ollama_running:
        provider = "ollama"
        api_key = ""
        print("  [OK] Ollama detected at localhost:11434")
    else:
        # Nothing auto-detected — ask once for Anthropic key
        provider = "anthropic"
        print("  No API key found in environment.")
        print("  Get one at: https://console.anthropic.com/settings/keys")
        try:
            import getpass
            api_key = getpass.getpass("  Anthropic API key (Enter to skip): ").strip()
        except Exception:
            try:
                api_key = input("  Anthropic API key (Enter to skip): ").strip()
            except (EOFError, KeyboardInterrupt):
                api_key = ""
        if api_key:
            print("  [OK] API key saved")
        else:
            print("  Skipped — add later: aibrain config set anthropic_api_key sk-...")

    # Auto-generate signing key before anything else writes to disk
    _ensure_signing_key()

    # Persist to .aibrain_config.json
    config_path = AIBRAIN_DIR / ".aibrain_config.json"
    try:
        existing_cfg = json.loads(config_path.read_text()) if config_path.exists() else {}
    except (json.JSONDecodeError, OSError):
        existing_cfg = {}

    existing_cfg["llm_provider"] = provider
    if api_key:
        key_field = "anthropic_api_key" if provider == "anthropic" else "openai_api_key"
        existing_cfg[key_field] = api_key
        env_key = "ANTHROPIC_API_KEY" if provider == "anthropic" else "OPENAI_API_KEY"
        os.environ[env_key] = api_key

    # Agent name — use AGENT_ID from env if set, else hostname, else "Agent"
    if not existing_cfg.get("agent_name"):
        existing_cfg["agent_name"] = (
            os.environ.get("AGENT_ID")
            or platform.node()
            or "Agent"
        )

    try:
        config_path.write_text(json.dumps(existing_cfg, indent=2))
    except OSError as e:
        print(f"  Warning: could not save config ({e})")

    # Quick connectivity test
    if api_key:
        print("  Testing connection...", end=" ", flush=True)
        try:
            if provider == "anthropic":
                import urllib.request as _ur
                req = _ur.Request(
                    "https://api.anthropic.com/v1/models",
                    headers={"x-api-key": api_key, "anthropic-version": "2023-06-01"},
                )
                with _ur.urlopen(req, timeout=8) as r:
                    r.read()
                print("OK")
            elif provider == "openai":
                import urllib.request as _ur
                req = _ur.Request(
                    "https://api.openai.com/v1/models",
                    headers={"Authorization": f"Bearer {api_key}"},
                )
                with _ur.urlopen(req, timeout=8) as r:
                    r.read()
                print("OK")
            else:
                print("skipped (Ollama)")
        except Exception as e:
            print(f"warning ({e})")
    else:
        print(f"  Skipped API key — using {provider} (add key later in {config_path})")

    print()

    # ------------------------------------------------------------------ #
    # Step 2/4 — Initialize database                                      #
    # ------------------------------------------------------------------ #
    print("Step 2/4: Initialize database")
    print("  Creating aibrain.db...", end=" ", flush=True)
    try:
        db = sqlite3.connect(str(DB_PATH))
        db.execute("""
            CREATE TABLE IF NOT EXISTS memories (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                type TEXT DEFAULT 'project',
                tags TEXT DEFAULT '',
                content TEXT DEFAULT '',
                created TEXT DEFAULT (datetime('now')),
                updated TEXT DEFAULT (datetime('now')),
                active INTEGER DEFAULT 1
            )
        """)
        db.execute("""
            CREATE VIRTUAL TABLE IF NOT EXISTS memories_fts USING fts5(
                name, tags, content, content=memories, content_rowid=id
            )
        """)
        db.commit()
        db.close()
        print("done")
    except Exception as e:
        print(f"error: {e}")

    print("  Running migrations...", end=" ", flush=True)
    try:
        from aibrain.core.migrations import run_migrations
        run_migrations(str(DB_PATH))
        print("done")
    except Exception as e:
        print(f"skipped ({e})")

    print()

    # ------------------------------------------------------------------ #
    # Step 3/4 — Run first workflow                                        #
    # ------------------------------------------------------------------ #
    print("Step 3/4: Run first workflow")
    print("  Running heartbeat...", end=" ", flush=True)
    try:
        from aibrain.core.workflow_runner import run_workflow
        result = run_workflow("heartbeat", actor="setup_wizard")
        quality = result.get("quality_score", result.get("score", "—"))
        status = result.get("status", "done")
        if isinstance(quality, float):
            quality_str = f"{quality:.2f}"
        else:
            quality_str = str(quality)
        print(f"Quality: {quality_str}  ({status})")
    except Exception as e:
        print(f"skipped ({e})")
        print("  (heartbeat requires the full brain to be running — run it later)")

    print()

    # ------------------------------------------------------------------ #
    # Step 4/4 — Done                                                     #
    # ------------------------------------------------------------------ #
    # Pin canonical DB root so aibrain_db.py finds it on next run
    _write_aibrainrc(AIBRAIN_DIR)

    # Mark setup complete in config
    existing_cfg["setup_complete"] = True
    try:
        config_path.write_text(json.dumps(existing_cfg, indent=2))
    except OSError:
        pass

    agent_name = existing_cfg.get("agent_name", "Agent")
    print(f"Step 4/4: {agent_name} is ready.")
    print()
    print(f"  Memory database : {DB_PATH}")
    print(f"  Config          : {config_path}")
    print()
    print("  Point your agent at AIBrain:")
    print('    "You have access to AIBrain. Use the MCP tools')
    print('     memory_store and memory_search."')
    print()
    print("  Start the server : aibrain server")
    print("  Add settings     : aibrain config set anthropic_api_key sk-...")
    print("  Upgrade to Pro   : https://buy.stripe.com/8x2fZi6BJ0w16dS7jgg7e06  ($9.95/mo)")
    print()


def run_wizard(args=None):
    """Entry point callable from `aibrain setup`.

    Supports:
        (no flags)           Simplified 4-step onboarding wizard (default)
        --full               Full 15-step interactive wizard
        --auto / --defaults  Fully automatic, no prompts, discovers env vars
        --config path.json   Use a pre-filled config file
        --reconfigure        Open section picker to update individual settings
    """
    if args is None:
        args = sys.argv[1:]  # skip 'setup' command word if called directly
    if '--reconfigure' in args:
        from aibrain.tools.setup.reconfigure import interactive_menu
        return interactive_menu()
    if '--auto' in args or '--defaults' in args:
        return auto_setup()
    if '--config' in args:
        idx = args.index('--config')
        if idx + 1 < len(args):
            return config_setup(args[idx + 1])
        else:
            fail("--config requires a path argument")
            sys.exit(1)
    if '--full' in args:
        return main()  # full 15-step interactive wizard
    from aibrain.cli.setup_wizard import main as _new_setup
    return _new_setup()


if __name__ == "__main__":
    # When run directly, check sys.argv
    run_wizard(sys.argv[1:])
