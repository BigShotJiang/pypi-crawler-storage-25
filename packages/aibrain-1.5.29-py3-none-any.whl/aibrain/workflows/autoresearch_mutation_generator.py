from __future__ import annotations
import logging
import os
import sys
import time
from datetime import datetime
from pathlib import Path

log = logging.getLogger(__name__)

MUTATION_STRATEGIES = ['Rewrite pressure-test modes: add, remove, or reframe the 3-5 pressure modes (e.g. assume pre-seed zero traction vs 1k users). Each mode probes a different strategic angle.', 'Adjust analysis depth weights: rebalance competitive landscape, product differentiation, and go-to-market emphasis (e.g. 50/30/20 -> 40/40/20 or 60/20/20).', 'Swap evaluator prompts: replace the inner evaluation chain ranking criterion (e.g. rank by defensibility -> rank by customer capture speed or moat durability).', 'Add/remove research vectors: expand or contract competitor research angles (GitHub activity, pricing, hiring, compliance posture, API surface, community health).', 'Voice/tone refinements: adjust persona formality, technical depth, and narrative framing (analytical vs advisory vs provocateur).']


def _call_via_claude_cli(prompt, claude_cli_path, timeout_s=300):
    cli_dir = str(Path(claude_cli_path).parent)
    if cli_dir not in sys.path:
        sys.path.insert(0, cli_dir)
    try:
        from claude_cli import call_claude_cli  # type: ignore[import]
        rc, stdout, stderr = call_claude_cli(prompt=prompt, timeout_s=timeout_s)
        if rc == 0 and stdout.strip():
            return stdout.strip()
        log.warning("claude_cli rc=%d stderr=%s", rc, (stderr or "")[:200])
        return None
    except Exception as exc:  # noqa: BLE001
        log.warning("claude_cli failed: %s", exc)
        return None


def _call_via_anthropic_api(prompt, timeout_s=300):
    try:
        import anthropic  # type: ignore[import]
    except ImportError:
        log.warning("anthropic package not installed -- cannot fall back to API")
        return None
    api_key = os.environ.get("ANTHROPIC_API_KEY", "")
    if not api_key:
        decker_env = Path.home() / ".decker_env"
        if decker_env.is_file():
            for line in decker_env.read_text(encoding="utf-8").splitlines():
                stripped = line.strip()
                if stripped.startswith("ANTHROPIC_API_KEY="):
                    val = stripped.split("=", 1)[1].strip()
                    api_key = val.strip('"').strip("'")
                    break
    if not api_key:
        log.warning("ANTHROPIC_API_KEY not found in env or ~/.decker_env")
        return None
    try:
        client = anthropic.Anthropic(api_key=api_key)
        msg = client.messages.create(
            model="claude-sonnet-4-6",
            max_tokens=4000,
            messages=[{"role": "user", "content": prompt}],
        )
        return msg.content[0].text if msg.content else None
    except Exception as exc:  # noqa: BLE001
        log.warning("Anthropic API failed: %s", exc)
        return None


def _call_claude(prompt, claude_cli_path, timeout_s=300):
    out = _call_via_claude_cli(prompt, claude_cli_path, timeout_s)
    if out:
        return out
    log.info("Falling back to Anthropic API for mutation generation")
    return _call_via_anthropic_api(prompt, timeout_s)


def _build_prompt(baseline_text, program_md_text, strategy, strategy_index):
    return (
        "You are a persona evolution engine for a Karpathy-style self-improvement loop.\n\n"
        "Produce ONE improved variant of the intel_agent_v2 persona by applying this mutation strategy:\n\n"
        f"Strategy #{strategy_index + 1}: {strategy}\n\n"
        f"## Current Baseline Persona\n{baseline_text}\n\n"
        f"## Loop Program\n{program_md_text}\n\n"
        "## Output Instructions\n"
        "1. Apply the mutation strategy above -- make the change concrete and substantive\n"
        "2. Retain essential identity, core philosophy, and structural integrity\n"
        f"3. Start with header: # Intel Agent V2 -- Mutant (Strategy: {strategy_index + 1})\n"
        "4. Include a 3-5 line comment at top: WHAT was mutated and WHY it may improve performance\n\n"
        "Output ONLY the persona file content. Do NOT truncate.\n"
    )


def generate_mutations(
    baseline_text: str,
    program_md_text: str,
    variants_dir: Path,
    n: int = 3,
    claude_cli_path: str = r"C:\Users\sinde\decker_system\04_tools\claude_cli.py",
) -> list:
    """Generate n mutation candidates and write them to variants_dir.

    Args:
        baseline_text:    Contents of the current persona (intel_agent_v2.md).
        program_md_text:  Contents of research/intel_agent/program.md.
        variants_dir:     Path to research/intel_agent/variants/ directory.
        n:                Number of distinct variants to generate (default 3).
        claude_cli_path:  Path to the canonical claude_cli.py helper.

    Returns:
        List of Path objects for every variant file successfully written.
        May be shorter than n if some Claude calls fail.
    """
    variants_dir = Path(variants_dir)
    variants_dir.mkdir(parents=True, exist_ok=True)
    strategies = [MUTATION_STRATEGIES[i % len(MUTATION_STRATEGIES)] for i in range(n)]
    written = []
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    for idx, strategy in enumerate(strategies):
        sn = idx % len(MUTATION_STRATEGIES)
        log.info("Generating mutation %d/%d strategy #%d", idx + 1, n, sn + 1)
        prompt = _build_prompt(baseline_text, program_md_text, strategy, sn)
        output = _call_claude(prompt=prompt, claude_cli_path=claude_cli_path)
        if not output:
            log.error("Mutation %d/%d failed -- Claude returned nothing", idx + 1, n)
            continue
        path = variants_dir / f"mutant_{ts}_{idx + 1}.md"
        path.write_text(output, encoding="utf-8")
        written.append(path)
        log.info("Wrote variant: %s (%d chars)", path, len(output))
        if idx < n - 1:
            time.sleep(1)
    log.info("generate_mutations: %d/%d written to %s", len(written), n, variants_dir)
    return written
