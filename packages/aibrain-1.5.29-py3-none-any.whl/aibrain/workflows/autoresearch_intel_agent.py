"""
Karpathy loop orchestration for intel_agent_v2 persona evolution.

This workflow runs the autoresearch engine against the intel_agent target,
iteratively improving the persona via a frozen battery of competitive positioning
questions per decker_system/03_playbooks/karpathy_loop_playbook.md.

Usage:
  python -m aibrain.core.workflow_runner autoresearch_intel_agent
  python -m aibrain.core.workflow_runner autoresearch_intel_agent --shadow-only

Per CLAUDE.md harness execution rule: all workflow execution goes through the harness.
"""

import logging
from pathlib import Path

logger = logging.getLogger(__name__)

# Paths to key resources
BASELINE_PERSONA_PATH = Path(
    r"C:\Users\sinde\decker_system\02_subagents\intel_agent_v2.md"
)
PROGRAM_MD_PATH = Path(
    r"C:\Users\sinde\projects\aibrain\research\intel_agent\program.md"
)
VARIANTS_DIR = Path(
    r"C:\Users\sinde\projects\aibrain\research\intel_agent\variants"
)


def run(config=None, **kwargs):
    """
    Run the intel_agent autoresearch loop.

    Generates fresh mutation candidates BEFORE calling run_autoresearch() so
    the engine always has new variants to score. Without this, the loop
    re-scores the same v2_entry1.md on every iteration and never evolves.

    Args:
        config (dict, optional): Override config (e.g., max_iterations, plateau_limit)
        **kwargs: Passed to run_autoresearch (e.g., shadow_mode=True)

    Returns:
        dict: Loop results (best_variant, score, iterations_run, etc.)
    """

    # Import here to avoid circular deps
    try:
        from aibrain.workflows.autoresearch_engine import run_autoresearch
    except ImportError as e:
        logger.error("autoresearch_engine not found: %s. Run from aibrain package root.", e)
        return {"status": "error", "message": f"Import failed: {e}"}

    # Default configuration per program.md stop rules
    default_config = {
        "target": "intel_agent",
        "max_iterations": 20,
        "plateau_limit": 5,
        "drift_threshold": 0.50,
        "iteration_timeout_seconds": 900,
        "shadow_mode": True,  # Conservative: mutations in shadow, human promotes
        "margin": 0.0,  # Strict > comparison
    }

    # Merge with provided overrides
    if config:
        default_config.update(config)

    # Merge with CLI kwargs (higher priority than config)
    for key in ["max_iterations", "plateau_limit", "drift_threshold", "shadow_mode", "margin"]:
        if key in kwargs:
            default_config[key] = kwargs[key]

    logger.info("Starting intel_agent autoresearch loop: %s", default_config)

    # --- Generate fresh mutations before scoring ---
    # This is the key step that makes evolution happen. Without new candidates
    # the engine re-scores v2_entry1.md on every iteration forever.
    if BASELINE_PERSONA_PATH.is_file():
        baseline_text = BASELINE_PERSONA_PATH.read_text(encoding="utf-8")
        program_md_text = (
            PROGRAM_MD_PATH.read_text(encoding="utf-8")
            if PROGRAM_MD_PATH.is_file()
            else ""
        )
        try:
            from aibrain.workflows.autoresearch_mutation_generator import generate_mutations
            generated = generate_mutations(
                baseline_text=baseline_text,
                program_md_text=program_md_text,
                variants_dir=VARIANTS_DIR,
                n=3,
            )
            logger.info(
                "Mutation generator produced %d new variants: %s", len(generated), generated
            )
        except Exception as exc:  # noqa: BLE001
            logger.warning(
                "Mutation generator failed (non-fatal — engine will score existing variants): %s",
                exc,
            )
    else:
        logger.warning(
            "Baseline persona not found at %s — skipping mutation generation",
            BASELINE_PERSONA_PATH,
        )

    # --- Run the scoring engine ---
    try:
        results = run_autoresearch(**default_config)
        return results
    except Exception as e:
        logger.error("Autoresearch failed: %s: %s", type(e).__name__, e, exc_info=True)
        return {"status": "error", "message": str(e)}


if __name__ == "__main__":
    # For manual testing
    import json
    result = run()
    print(json.dumps(result, indent=2))
