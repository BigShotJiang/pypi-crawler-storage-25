"""
Karpathy loop orchestration for lead_engineer_v2 persona evolution.

Mirrors autoresearch_intel_agent.py structure. Runs the autoresearch engine
against the lead_engineer target, with paths resolved to research/lead_engineer/.

Per CLAUDE.md harness execution rule: all workflow execution goes through the harness.
"""

import logging
from pathlib import Path

logger = logging.getLogger(__name__)

BASELINE_PERSONA_PATH = Path(
    r"C:\Users\sinde\decker_system\02_subagents\lead_engineer_agent_v2.md"
)
PROGRAM_MD_PATH = Path(
    r"C:\Users\sinde\projects\aibrain\research\lead_engineer\program.md"
)
VARIANTS_DIR = Path(
    r"C:\Users\sinde\projects\aibrain\research\lead_engineer\variants"
)


def run(config=None, **kwargs):
    """
    Run the lead_engineer autoresearch loop.

    Scores pre-seeded variants in research/lead_engineer/variants/ against
    the frozen 12-item engineering battery. Mutation generation is deferred —
    the current generator hardcodes intel_agent branding in its prompt,
    so until a lead_engineer-aware mutation generator ships we rely on
    hand-seeded variants in variants/.
    """
    try:
        from aibrain.workflows.autoresearch_engine import run_autoresearch
    except ImportError as e:
        logger.error("autoresearch_engine not found: %s", e)
        return {"status": "error", "message": f"Import failed: {e}"}

    default_config = {
        "target": "lead_engineer",
        "max_iterations": 20,
        "plateau_limit": 5,
        "drift_threshold": 0.50,
        "iteration_timeout_seconds": 900,
        "shadow_mode": True,
        "margin": 0.0,
        "stage2_mckee": True,
        "stage2_n": 20,
    }

    if config:
        default_config.update(config)
    for key in (
        "max_iterations",
        "plateau_limit",
        "drift_threshold",
        "shadow_mode",
        "margin",
        "stage2_mckee",
        "stage2_n",
    ):
        if key in kwargs:
            default_config[key] = kwargs[key]

    logger.info("Starting lead_engineer autoresearch loop: %s", default_config)

    try:
        results = run_autoresearch(**default_config)
        return results
    except Exception as e:
        logger.error("Autoresearch failed: %s: %s", type(e).__name__, e, exc_info=True)
        return {"status": "error", "message": str(e)}


if __name__ == "__main__":
    import json
    result = run()
    print(json.dumps(result, indent=2, default=str))
