"""
autoresearch_engine.py — shared Karpathy-loop runner.

This module is NOT registered directly in WORKFLOW_REGISTRY. Per-target
workflows (autoresearch_intel_agent, autoresearch_aibrain_memory,
autoresearch_wintermute_chain, …) import `run_autoresearch` from this module
and pass their target name. The engine consumes a per-target config dir and
drives the iteration + shadow-mode logic.

Primary design source:
    decker_system/00_meta/karpathy_loop_design_2026_04_19.md

Procedural playbook:
    decker_system/03_playbooks/karpathy_loop_playbook.md

---------------------------------------------------------------------------
Contract — what the engine expects in ``research/<target>/``
---------------------------------------------------------------------------

``program.md``
    Plain-text spec for the loop. The engine does not parse semantic
    content — it is the candidate-proposing agent (autoresearch_agent_v2)
    that reads this. The engine only requires the file to exist so the
    agent has something to read before it proposes a mutation. Required
    by the playbook (Section 4) — enforce presence here.

``battery.jsonl``
    Frozen battery of scoring inputs, one JSON object per line. Each
    line is passed verbatim to ``metric.score(baseline, candidate, input)``
    as the ``input`` argument. Size (20-50 + 3-5 novelty probes) is
    convention, not enforced by the engine.

``metric.py``
    Python module that exposes a single callable ``score(output, input)
    -> float``. The engine calls this for each battery row against the
    baseline output and the candidate output. Higher is better. The
    engine is metric-agnostic — the scalar returned is the scalar that
    drives keep/revert and promotion.

``variants/<variant_name>.{md|py}``
    Candidate artifacts proposed by the autoresearch agent. The engine
    reads them verbatim and hands them to a caller-supplied
    ``produce_output(unit_text, input) -> str`` adapter which is how the
    engine stays agnostic to whether the unit is a persona, a chain
    YAML, a router config, or anything else. The adapter defaults to
    returning the unit text unchanged — sufficient for the unit-test
    fake-target path.

---------------------------------------------------------------------------
Spec gaps resolved at build time (2026-04-19) — documented for Decker
---------------------------------------------------------------------------

1. The task brief says ``evolution_outcomes.outcome_type`` — the actual
   schema (see aibrain/core/companies.py:1074) has no ``outcome_type``
   column. The canonical string column is ``action``. The engine writes
   ``action='autoresearch_iteration'`` with the iteration payload packed
   into ``details`` as JSON (target, iteration_n, baseline_score,
   candidate_score, kept_or_reverted, drift_ratio, candidate_id). Source
   ``source='autoresearch'`` and ``source_id=<target>``.

2. ``shadow_runs`` schema — the task brief lists columns ``id, task_id,
   target, candidate_id, baseline_output, candidate_output,
   baseline_score, candidate_score, created_at``. Migration v4 creates
   the table exactly as listed, v5 adds a ``(target, candidate_id)``
   index so shadow retrieval is not a table scan for high-traffic
   targets.

3. Token-level drift is implemented as a deterministic Jaccard-style
   symmetric difference over whitespace-split tokens of the candidate
   unit vs the baseline unit. The design doc (Section 4, "novelty
   probe") frames "50%" as a first-cut default, not a formal method;
   the engine exposes ``drift_threshold`` per call for per-target
   tuning without invention.

4. Battery-pass detection — a candidate is considered to "pass the
   battery" (and thus becomes shadow-eligible) when its aggregate
   battery score strictly exceeds the baseline's aggregate score. The
   task brief phrases this as the "keep-if-better" rule; there is no
   separate threshold spec, so the engine uses ``>`` with no epsilon
   for v1 and surfaces the gap as a config knob (``margin``) for
   per-target workflows to override.

None of these resolutions change the intent of the spec — they fill in
mechanics the spec did not pin down. Flag any of them to Decker for
ratification.

---------------------------------------------------------------------------
Public API
---------------------------------------------------------------------------

``run_autoresearch(target, ...) -> dict``
    Entry point. Drives the iteration loop, runs shadow mode if the
    candidate passes the battery, writes evolution_outcomes rows, and
    returns a structured result dict.

``run_shadow_iteration(target, baseline_text, candidate_text, battery_input,
                       produce_output, score, db_path, …) -> dict``
    Single production-invocation helper. Used by a per-target
    production hook to run baseline + candidate in parallel on one
    real query. Writes a shadow_runs row and returns the pair of
    outputs + scores.

``compute_token_drift(baseline_text, candidate_text) -> float``
    Deterministic token-diff ratio in [0.0, 1.0]. Exposed for tests and
    for per-target workflows that want to pre-check drift before
    handing a candidate to the engine.

Stage-2 McKee gate (2026-04-23, task n_0MZrSVY7U)
-------------------------------------------------

A Stage-1 battery PASS is no longer sufficient for promotion. When a
candidate beats the baseline on the frozen battery AND ``stage2_mckee``
is True (default for production, False for the fake-target unit tests)
the engine calls ``aibrain.workflows.mckee_generator.run_mckee_gate``
to score both persona texts against ``n`` adversarial questions the
generator was blind to. Stage-2 PASS → ``shadow_eligible=True``,
``stage2_mckee_verdict='PASS'``. Stage-2 FAIL → ``shadow_eligible=False``,
``stage2_mckee_verdict='FAIL'``, and the iteration outcome is rewritten
to ``REVERTED`` with ``failure_reason='stage2_mckee_fail'``. The
per-target wrapper reads ``stage2_mckee_verdict`` to decide whether to
copy the variant over ``baseline.md``.
"""

from __future__ import annotations

import importlib.util
import json
import logging
import sqlite3
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Optional

# P0-1 backfill (2026-04-11): workflows route execution through the harness.
# This module is primarily imported by per-target wrappers — when invoked
# directly via `python -m workflows.autoresearch_engine <target>` it routes
# through workflow_execute below.
from aibrain.core.workflow_base import workflow_execute

# Stage-2 adversarial gate. Imported lazily inside run_autoresearch so the
# fake-target unit tests that pass ``stage2_mckee=False`` do not pull in
# the Claude CLI subprocess dependency.
from aibrain.workflows import mckee_generator  # noqa: F401  (re-export for callers)
from aibrain.workflows.mckee_generator import run_mckee_gate  # noqa: F401

log = logging.getLogger("aibrain.autoresearch_engine")

# ---------------------------------------------------------------------------
# Constants — named, so per-target overrides do not silently drift the spec.
# ---------------------------------------------------------------------------

DEFAULT_DRIFT_THRESHOLD = 0.50       # design-doc default (Section 4)
DEFAULT_PLATEAU_LIMIT = 5            # task-spec default — 5 iterations flat → stop
DEFAULT_MAX_ITERATIONS = 20          # conservative cap; tune per target
DEFAULT_SHADOW_N = 10                # design-doc Section 6 default
DEFAULT_SHADOW_DAYS = 7              # design-doc Section 6 default
DEFAULT_ITERATION_TIMEOUT_SECONDS = 900  # 15 minutes per revolution


# ---------------------------------------------------------------------------
# Loop-state signals — explicit, not magic strings.
# ---------------------------------------------------------------------------

class LoopState:
    KEPT = "kept"
    REVERTED = "reverted"
    DRIFT_GUARDRAIL_PAUSED = "drift_guardrail_paused"
    PLATEAU_STOPPED = "plateau_stopped"
    ITERATION_CAP = "iteration_cap"
    NO_VARIANTS = "no_variants"
    BATTERY_PASS = "battery_pass"  # candidate beat baseline — shadow eligible
    # Hypothesis-injection states — engine stays DORMANT (not closed) waiting
    # on either a human hypothesis drop or a synthesis-then-approve cycle.
    DORMANT_AWAITING_HYPOTHESIS = "dormant_awaiting_hypothesis"
    DORMANT_AWAITING_SYNTHESIS = "dormant_awaiting_synthesis"


class EngineConfigError(ValueError):
    """Raised when the target config dir is missing a required artifact.

    Not a silent fallback — the engine refuses to run without all four
    playbook ingredients (program.md, battery.jsonl, metric.py, variants/).
    """


# ---------------------------------------------------------------------------
# Target config loader
# ---------------------------------------------------------------------------

@dataclass
class TargetConfig:
    name: str
    root: Path
    program_md: Path
    battery_jsonl: Path
    metric_py: Path
    variants_dir: Path

    def load_battery(self) -> list[dict]:
        rows: list[dict] = []
        with self.battery_jsonl.open("r", encoding="utf-8") as fh:
            for line_num, raw in enumerate(fh, start=1):
                raw = raw.strip()
                if not raw:
                    continue
                try:
                    rows.append(json.loads(raw))
                except json.JSONDecodeError as e:
                    raise EngineConfigError(
                        f"{self.battery_jsonl}:{line_num} is not valid JSON: {e}"
                    )
        if not rows:
            raise EngineConfigError(f"{self.battery_jsonl} is empty — battery must have >=1 row")
        return rows

    def load_metric(self) -> Callable[[Any, Any], float]:
        """Import metric.py and return its ``score`` callable."""
        spec = importlib.util.spec_from_file_location(
            f"autoresearch_metric_{self.name}", self.metric_py
        )
        if spec is None or spec.loader is None:
            raise EngineConfigError(f"Could not load metric module from {self.metric_py}")
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)  # type: ignore[union-attr]
        score_fn = getattr(mod, "score", None)
        if score_fn is None or not callable(score_fn):
            raise EngineConfigError(
                f"{self.metric_py} must define a callable `score(output, input) -> float`"
            )
        return score_fn

    def list_variants(self) -> list[Path]:
        if not self.variants_dir.is_dir():
            return []
        return sorted(
            p for p in self.variants_dir.iterdir()
            if p.is_file() and p.suffix in {".md", ".py"}
        )


def load_target_config(research_root: Path, target: str) -> TargetConfig:
    root = research_root / target
    program_md = root / "program.md"
    battery_jsonl = root / "battery.jsonl"
    metric_py = root / "metric.py"
    variants_dir = root / "variants"

    missing = [
        str(p.relative_to(research_root))
        for p in (program_md, battery_jsonl, metric_py)
        if not p.is_file()
    ]
    if not variants_dir.is_dir():
        missing.append(str(variants_dir.relative_to(research_root)))
    if missing:
        raise EngineConfigError(
            f"Target '{target}' is missing required artifacts: {missing}. "
            f"Every Karpathy loop needs program.md + battery.jsonl + metric.py + "
            f"variants/ (playbook Section 4)."
        )

    return TargetConfig(
        name=target,
        root=root,
        program_md=program_md,
        battery_jsonl=battery_jsonl,
        metric_py=metric_py,
        variants_dir=variants_dir,
    )


# ---------------------------------------------------------------------------
# Drift guardrail — deterministic token-set diff ratio.
# ---------------------------------------------------------------------------

def _tokenize(text: str) -> list[str]:
    return text.split()


def compute_token_drift(baseline_text: str, candidate_text: str) -> float:
    """Return the symmetric-difference ratio of tokens in [0.0, 1.0].

    Both-empty → 0.0. One-empty → 1.0. Otherwise:
        |symmetric_difference| / |union|

    This is Jaccard distance on the multiset flattened to a set. The 50%
    default threshold from the design doc maps directly onto this ratio.
    """
    a = set(_tokenize(baseline_text))
    b = set(_tokenize(candidate_text))
    if not a and not b:
        return 0.0
    union = a | b
    if not union:
        return 0.0
    sym_diff = a.symmetric_difference(b)
    return len(sym_diff) / len(union)


# ---------------------------------------------------------------------------
# DB layer — the engine owns its connection, supports test-DB injection.
# ---------------------------------------------------------------------------

def _open_db(db_path: str | Path) -> sqlite3.Connection:
    conn = sqlite3.connect(str(db_path))
    conn.execute("PRAGMA journal_mode=WAL")
    conn.row_factory = sqlite3.Row
    # Apply migrations — cheap, idempotent, guarantees shadow_runs + schema_migrations.
    from aibrain.core.migrations import run_migrations
    run_migrations(conn)
    # evolution_outcomes is owned by companies.py — create here too so the engine
    # works against a fresh test DB that has never been touched by companies._get_db.
    conn.execute("""
        CREATE TABLE IF NOT EXISTS evolution_outcomes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            source TEXT, source_id TEXT, action TEXT,
            result TEXT, details TEXT, failure_reason TEXT,
            duration_seconds REAL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            session_id TEXT
        )
    """)
    conn.commit()
    return conn


def _write_iteration_outcome(
    conn: sqlite3.Connection,
    target: str,
    iteration_n: int,
    baseline_score: float,
    candidate_score: float,
    kept_or_reverted: str,
    candidate_id: str,
    drift_ratio: float,
    duration_seconds: float,
    failure_reason: Optional[str] = None,
) -> int:
    """Append one autoresearch_iteration row to evolution_outcomes.

    ``action='autoresearch_iteration'`` is the constant the consumer
    side queries on. ``source='autoresearch'``, ``source_id=<target>``
    lets downstream retrolearn/promotion-review queries group by target.
    """
    details = json.dumps({
        "target": target,
        "iteration_n": iteration_n,
        "baseline_score": baseline_score,
        "candidate_score": candidate_score,
        "kept_or_reverted": kept_or_reverted,
        "candidate_id": candidate_id,
        "drift_ratio": drift_ratio,
    }, sort_keys=True)
    cur = conn.execute(
        """
        INSERT INTO evolution_outcomes
            (source, source_id, action, result, details,
             failure_reason, duration_seconds)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        """,
        (
            "autoresearch",
            target,
            "autoresearch_iteration",
            kept_or_reverted,
            details,
            failure_reason,
            duration_seconds,
        ),
    )
    conn.commit()
    return cur.lastrowid or 0


def _write_shadow_run(
    conn: sqlite3.Connection,
    target: str,
    candidate_id: str,
    baseline_output: str,
    candidate_output: str,
    baseline_score: Optional[float],
    candidate_score: Optional[float],
    task_id: Optional[str] = None,
) -> int:
    cur = conn.execute(
        """
        INSERT INTO shadow_runs
            (task_id, target, candidate_id,
             baseline_output, candidate_output,
             baseline_score, candidate_score)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        """,
        (
            task_id,
            target,
            candidate_id,
            baseline_output,
            candidate_output,
            baseline_score,
            candidate_score,
        ),
    )
    conn.commit()
    return cur.lastrowid or 0


# ---------------------------------------------------------------------------
# Battery scoring — single pass over the frozen battery for one unit.
# ---------------------------------------------------------------------------

def _score_unit_against_battery(
    unit_text: str,
    battery: list[dict],
    produce_output: Callable[[str, dict], str],
    score: Callable[[str, dict], float],
) -> tuple[float, list[float]]:
    """Run ``produce_output`` for each battery row, then ``score`` each.

    Returns (mean_score, per_row_scores). Aggregate is the arithmetic
    mean — single scalar per the playbook's single-metric rule.
    """
    per_row: list[float] = []
    for row in battery:
        output = produce_output(unit_text, row)
        row_score = float(score(output, row))
        per_row.append(row_score)
    if not per_row:
        return 0.0, per_row
    return sum(per_row) / len(per_row), per_row


# ---------------------------------------------------------------------------
# Shadow-mode helpers
# ---------------------------------------------------------------------------

@dataclass
class ShadowRunResult:
    shadow_run_id: int
    baseline_output: str
    candidate_output: str
    baseline_score: Optional[float]
    candidate_score: Optional[float]


def run_shadow_iteration(
    target: str,
    baseline_text: str,
    candidate_text: str,
    battery_input: dict,
    produce_output: Callable[[str, dict], str],
    score: Callable[[str, dict], float],
    db_path: str | Path,
    candidate_id: str,
    task_id: Optional[str] = None,
) -> ShadowRunResult:
    """Run baseline + candidate on one real production input.

    The caller's production code decides which output to serve — this
    helper only runs both and records the pair. No implicit "candidate
    wins" logic; the incumbent always serves per the design doc
    (Section 5).
    """
    baseline_output = produce_output(baseline_text, battery_input)
    candidate_output = produce_output(candidate_text, battery_input)
    try:
        baseline_score = float(score(baseline_output, battery_input))
    except Exception as e:
        log.warning("shadow baseline score failed for target=%s: %s", target, e)
        baseline_score = None
    try:
        candidate_score = float(score(candidate_output, battery_input))
    except Exception as e:
        log.warning("shadow candidate score failed for target=%s: %s", target, e)
        candidate_score = None

    conn = _open_db(db_path)
    try:
        shadow_run_id = _write_shadow_run(
            conn,
            target=target,
            candidate_id=candidate_id,
            baseline_output=baseline_output,
            candidate_output=candidate_output,
            baseline_score=baseline_score,
            candidate_score=candidate_score,
            task_id=task_id,
        )
    finally:
        conn.close()

    return ShadowRunResult(
        shadow_run_id=shadow_run_id,
        baseline_output=baseline_output,
        candidate_output=candidate_output,
        baseline_score=baseline_score,
        candidate_score=candidate_score,
    )


def shadow_stop_ready(
    db_path: str | Path,
    target: str,
    candidate_id: str,
    n_threshold: int = DEFAULT_SHADOW_N,
    days_threshold: int = DEFAULT_SHADOW_DAYS,
) -> dict:
    """Return whether the shadow-mode stopping rule has fired.

    Rule (design doc Section 6):
        accumulated_runs >= n_threshold OR elapsed_days >= days_threshold
        → ready.
    """
    conn = _open_db(db_path)
    try:
        row = conn.execute(
            """
            SELECT COUNT(*) AS n, MIN(created_at) AS first_at
            FROM shadow_runs
            WHERE target = ? AND candidate_id = ?
            """,
            (target, candidate_id),
        ).fetchone()
        n = int(row["n"] or 0)
        first_at = row["first_at"]
    finally:
        conn.close()

    elapsed_days: Optional[float] = None
    if first_at:
        import datetime as _dt
        try:
            first_dt = _dt.datetime.fromisoformat(str(first_at).replace("Z", ""))
            elapsed_days = (_dt.datetime.utcnow() - first_dt).total_seconds() / 86400.0
        except ValueError:
            elapsed_days = None

    ready = (n >= n_threshold) or (
        elapsed_days is not None and elapsed_days >= days_threshold
    )
    return {
        "ready": ready,
        "n": n,
        "elapsed_days": elapsed_days,
        "n_threshold": n_threshold,
        "days_threshold": days_threshold,
    }


def shadow_differential(
    db_path: str | Path,
    target: str,
    candidate_id: str,
) -> dict:
    """Aggregate mean candidate_score vs baseline_score across shadow_runs."""
    conn = _open_db(db_path)
    try:
        rows = conn.execute(
            """
            SELECT baseline_score, candidate_score
            FROM shadow_runs
            WHERE target = ? AND candidate_id = ?
              AND baseline_score IS NOT NULL
              AND candidate_score IS NOT NULL
            """,
            (target, candidate_id),
        ).fetchall()
    finally:
        conn.close()

    if not rows:
        return {
            "n_scored": 0,
            "baseline_mean": None,
            "candidate_mean": None,
            "shadow_score_margin": None,
        }
    baseline_mean = sum(r["baseline_score"] for r in rows) / len(rows)
    candidate_mean = sum(r["candidate_score"] for r in rows) / len(rows)
    return {
        "n_scored": len(rows),
        "baseline_mean": baseline_mean,
        "candidate_mean": candidate_mean,
        "shadow_score_margin": candidate_mean - baseline_mean,
    }


# ---------------------------------------------------------------------------
# Main iteration loop
# ---------------------------------------------------------------------------

def _default_produce_output(unit_text: str, battery_input: dict) -> str:
    """Fallback adapter — returns the unit text verbatim.

    Sufficient for test-only fake targets where the unit text IS the
    model output. Real targets override this with an adapter that
    takes a persona/chain/config + an input and produces the actual
    downstream artifact to score.
    """
    return unit_text


def run_autoresearch(
    target: str,
    research_root: str | Path | None = None,
    db_path: str | Path | None = None,
    max_iterations: int = DEFAULT_MAX_ITERATIONS,
    plateau_limit: int = DEFAULT_PLATEAU_LIMIT,
    drift_threshold: float = DEFAULT_DRIFT_THRESHOLD,
    iteration_timeout_seconds: int = DEFAULT_ITERATION_TIMEOUT_SECONDS,
    shadow_mode: bool = True,
    margin: float = 0.0,
    produce_output: Optional[Callable[[str, dict], str]] = None,
    baseline_unit: Optional[str] = None,
    hypothesis_queue_enabled: bool = True,
    telegram_sender: Optional[Callable[[str], bool]] = None,
    stage2_mckee: bool = True,
    stage2_mckee_set_path: Optional[Path] = None,
    stage2_haiku_model: str = "claude-haiku-4-5",
    stage2_n: int = 100,
) -> dict:
    """Drive the Karpathy loop for ``target``.

    Parameters
    ----------
    target
        Name of the research subdirectory under ``research/``.
    research_root
        Path to the research/ parent. Defaults to aibrain/research/ via
        ``AIBRAIN_ROOT``. Tests pass their own ``tmp_path``.
    db_path
        SQLite DB to write evolution_outcomes + shadow_runs into. Tests
        pass a tmp DB. Defaults to aibrain.db alongside aibrain_db.py.
    max_iterations
        Hard cap. Playbook Section 5.5.
    plateau_limit
        Consecutive non-improving iterations before auto-stop. Default 5
        per task spec.
    drift_threshold
        Jaccard drift ratio above which a candidate is flagged for human
        review and the loop pauses. Default 0.50.
    iteration_timeout_seconds
        Per-iteration wall-clock budget. Exceeded → iteration is marked
        as a revert with failure_reason="iteration_timeout".
    shadow_mode
        If True and a candidate's battery score beats the baseline, the
        engine flips loop_state to BATTERY_PASS and returns — production
        shadow mode is expected to be driven by a per-target hook that
        calls ``run_shadow_iteration`` on each real invocation. If False
        the engine keeps iterating against the newly-promoted candidate.
    margin
        Epsilon on the "battery pass" rule; candidate_score must exceed
        baseline_score + margin. Default 0.0 (strict inequality).
    produce_output
        Adapter ``(unit_text, battery_input) -> str``. Defaults to
        returning ``unit_text`` verbatim (test-only shape).
    baseline_unit
        Optional override of the baseline unit text. When None, the
        engine reads ``research/<target>/baseline.md`` if present,
        otherwise falls back to the empty string and surfaces that as
        a spec gap via ``failure_reason`` on iteration 0.

    Returns
    -------
    dict
        Structured outcome:
            target, iterations_run, loop_state, baseline_score,
            best_candidate_id, best_candidate_score, drift_ratio,
            shadow_eligible, outcomes (list of per-iteration dicts).
    """
    from aibrain_db import AIBRAIN_ROOT as _AIBRAIN_ROOT

    # Resolve roots — tests inject, production uses the canonical defaults.
    if research_root is None:
        research_root_path = Path(_AIBRAIN_ROOT) / "research"
    else:
        research_root_path = Path(research_root)

    if db_path is None:
        db_path_resolved: str | Path = Path(_AIBRAIN_ROOT) / "aibrain.db"
    else:
        db_path_resolved = db_path

    cfg = load_target_config(research_root_path, target)
    battery = cfg.load_battery()
    score_fn = cfg.load_metric()
    variants = cfg.list_variants()
    produce = produce_output or _default_produce_output

    # Baseline unit — from arg, or from research/<target>/baseline.md, or empty.
    if baseline_unit is not None:
        baseline_text = baseline_unit
        baseline_source = "arg"
    else:
        bpath = cfg.root / "baseline.md"
        if bpath.is_file():
            baseline_text = bpath.read_text(encoding="utf-8")
            baseline_source = "baseline.md"
        else:
            baseline_text = ""
            baseline_source = "empty_fallback"

    if not variants:
        return {
            "target": target,
            "iterations_run": 0,
            "loop_state": LoopState.NO_VARIANTS,
            "baseline_score": None,
            "best_candidate_id": None,
            "best_candidate_score": None,
            "drift_ratio": None,
            "shadow_eligible": False,
            "baseline_source": baseline_source,
            "outcomes": [],
        }

    # Baseline score — one pass over the battery.
    baseline_mean, _ = _score_unit_against_battery(
        baseline_text, battery, produce, score_fn
    )

    conn = _open_db(db_path_resolved)
    hypothesis_pull_result: Optional[dict] = None
    try:
        outcomes: list[dict] = []
        best_candidate_id: Optional[str] = None
        best_candidate_score: float = baseline_mean
        plateau_count = 0
        shadow_eligible = False
        loop_state: str = LoopState.ITERATION_CAP

        current_baseline_text = baseline_text
        current_baseline_score = baseline_mean

        for iteration_n, variant_path in enumerate(variants[:max_iterations], start=1):
            iter_start = time.monotonic()
            candidate_text = variant_path.read_text(encoding="utf-8")
            candidate_id = variant_path.stem

            drift = compute_token_drift(current_baseline_text, candidate_text)
            if drift > drift_threshold:
                _write_iteration_outcome(
                    conn,
                    target=target,
                    iteration_n=iteration_n,
                    baseline_score=current_baseline_score,
                    candidate_score=float("nan"),
                    kept_or_reverted=LoopState.DRIFT_GUARDRAIL_PAUSED,
                    candidate_id=candidate_id,
                    drift_ratio=drift,
                    duration_seconds=time.monotonic() - iter_start,
                    failure_reason=f"drift_ratio={drift:.3f} > {drift_threshold:.3f}",
                )
                outcomes.append({
                    "iteration_n": iteration_n,
                    "candidate_id": candidate_id,
                    "state": LoopState.DRIFT_GUARDRAIL_PAUSED,
                    "drift_ratio": drift,
                    "baseline_score": current_baseline_score,
                    "candidate_score": None,
                })
                loop_state = LoopState.DRIFT_GUARDRAIL_PAUSED
                break

            # Iteration-timeout budget — not an LLM timeout, a wall-clock gate.
            # We do not preempt `produce`/`score` mid-flight (no threads/signals
            # here — those belong to the harness). Instead we measure after the
            # iteration and if it exceeded budget we mark it as a revert with
            # the reason logged, so plateau tracking does not credit a timeout.
            candidate_score, _per_row = _score_unit_against_battery(
                candidate_text, battery, produce, score_fn
            )
            elapsed = time.monotonic() - iter_start

            if elapsed > iteration_timeout_seconds:
                _write_iteration_outcome(
                    conn,
                    target=target,
                    iteration_n=iteration_n,
                    baseline_score=current_baseline_score,
                    candidate_score=candidate_score,
                    kept_or_reverted=LoopState.REVERTED,
                    candidate_id=candidate_id,
                    drift_ratio=drift,
                    duration_seconds=elapsed,
                    failure_reason=f"iteration_timeout elapsed={elapsed:.1f}s > {iteration_timeout_seconds}s",
                )
                outcomes.append({
                    "iteration_n": iteration_n,
                    "candidate_id": candidate_id,
                    "state": LoopState.REVERTED,
                    "drift_ratio": drift,
                    "baseline_score": current_baseline_score,
                    "candidate_score": candidate_score,
                    "failure_reason": "iteration_timeout",
                })
                plateau_count += 1
                if plateau_count >= plateau_limit:
                    loop_state = LoopState.PLATEAU_STOPPED
                    break
                continue

            kept = candidate_score > (current_baseline_score + margin)
            state = LoopState.KEPT if kept else LoopState.REVERTED

            _write_iteration_outcome(
                conn,
                target=target,
                iteration_n=iteration_n,
                baseline_score=current_baseline_score,
                candidate_score=candidate_score,
                kept_or_reverted=state,
                candidate_id=candidate_id,
                drift_ratio=drift,
                duration_seconds=elapsed,
            )
            outcomes.append({
                "iteration_n": iteration_n,
                "candidate_id": candidate_id,
                "state": state,
                "drift_ratio": drift,
                "baseline_score": current_baseline_score,
                "candidate_score": candidate_score,
            })

            if kept:
                plateau_count = 0
                if candidate_score > best_candidate_score:
                    best_candidate_id = candidate_id
                    best_candidate_score = candidate_score

                # Stage-2 McKee gate — only promote if the candidate ALSO
                # survives 100 adversarial questions the generator was blind
                # to. Migrated from tmp/mckee_score_and_close.py 2026-04-23.
                if stage2_mckee:
                    stage2_baseline_path = cfg.root / "baseline.md"
                    if not stage2_baseline_path.is_file():
                        # Engine was seeded via baseline_unit arg with no on-disk
                        # baseline.md — surface the gap rather than silent-skip.
                        stage2_verdict = "SKIPPED"
                        stage2_failure = (
                            "stage2_mckee_skipped_no_baseline_md: "
                            f"{stage2_baseline_path}"
                        )
                        stage2_result: dict = {
                            "verdict": stage2_verdict,
                            "baseline_score": None,
                            "candidate_score": None,
                            "delta": None,
                            "n_calls": 0,
                            "mckee_set_path": None,
                        }
                    else:
                        try:
                            mckee_set_resolved: Path
                            if stage2_mckee_set_path is not None:
                                mckee_set_resolved = Path(stage2_mckee_set_path)
                            else:
                                mckee_set_resolved = mckee_generator.generate_mckee_set(
                                    target=target,
                                    research_dir=cfg.root,
                                    n=stage2_n,
                                )
                            stage2_result = run_mckee_gate(
                                target=target,
                                baseline_path=stage2_baseline_path,
                                variant_path=variant_path,
                                mckee_set_path=mckee_set_resolved,
                                haiku_model=stage2_haiku_model,
                            )
                            stage2_verdict = stage2_result["verdict"]
                            stage2_failure = (
                                None if stage2_verdict == "PASS"
                                else "stage2_mckee_fail"
                            )
                        except Exception as exc:  # noqa: BLE001
                            log.exception(
                                "Stage-2 McKee gate crashed for target=%s "
                                "candidate=%s",
                                target, candidate_id,
                            )
                            stage2_verdict = "ERROR"
                            stage2_failure = f"stage2_mckee_error: {exc}"
                            stage2_result = {
                                "verdict": stage2_verdict,
                                "baseline_score": None,
                                "candidate_score": None,
                                "delta": None,
                                "n_calls": 0,
                                "mckee_set_path": None,
                                "error": str(exc),
                            }

                    outcomes[-1]["stage2_mckee_verdict"] = stage2_verdict
                    outcomes[-1]["stage2_mckee"] = stage2_result
                    if stage2_verdict != "PASS":
                        # Rewrite the iteration outcome from KEPT → REVERTED so
                        # battery-pass-without-gate-pass never reads as a true
                        # promotion. plateau_count is re-incremented because
                        # the iteration did not actually improve the pipeline.
                        outcomes[-1]["state"] = LoopState.REVERTED
                        outcomes[-1]["failure_reason"] = stage2_failure
                        plateau_count = 1
                        if candidate_id == best_candidate_id:
                            best_candidate_id = None
                            best_candidate_score = current_baseline_score
                        loop_state = LoopState.BATTERY_PASS
                        shadow_eligible = False
                        break

                if shadow_mode:
                    # Flip to shadow-eligible and stop iterating in-engine.
                    # Real shadow traffic is driven by a per-target production
                    # hook that calls run_shadow_iteration; post-shadow
                    # promotion is a separate decision path.
                    shadow_eligible = True
                    loop_state = LoopState.BATTERY_PASS
                    break
                # shadow_mode=False — keep iterating, candidate becomes new baseline.
                current_baseline_text = candidate_text
                current_baseline_score = candidate_score
            else:
                plateau_count += 1
                if plateau_count >= plateau_limit:
                    loop_state = LoopState.PLATEAU_STOPPED
                    break
        else:
            # Exhausted variants without hitting cap — that IS the cap for this
            # target unless max_iterations was lower.
            loop_state = LoopState.ITERATION_CAP

        # Hypothesis-injection layer — on plateau, pull from the queue rather
        # than close the loop. Preserves Decker's creative abstract input as
        # the default recovery path instead of a manual re-seed.
        if hypothesis_queue_enabled and loop_state == LoopState.PLATEAU_STOPPED:
            from aibrain.core.hypothesis_queue import on_plateau
            pr = on_plateau(
                target=target,
                research_root=research_root_path,
                db_path=db_path_resolved,
                current_best_score=best_candidate_score,
                telegram_sender=telegram_sender,
            )
            hypothesis_pull_result = {
                "action": pr.action,
                "hypothesis_title": pr.hypothesis.title if pr.hypothesis else None,
                "telegram_sent": pr.telegram_sent,
                "evolution_outcome_id": pr.evolution_outcome_id,
            }
            if pr.action == "hypothesis_pulled":
                loop_state = LoopState.DORMANT_AWAITING_SYNTHESIS
            elif pr.action == "queue_empty":
                loop_state = LoopState.DORMANT_AWAITING_HYPOTHESIS

    finally:
        conn.close()

    # Surface the Stage-2 McKee verdict at the top level so per-target
    # wrappers do not have to dig into outcomes[-1] to decide whether to
    # copy the variant over baseline.md. Promotion rule:
    #     Stage-1 battery pass AND Stage-2 McKee PASS → promote
    #     (stage2_mckee_verdict=='PASS' AND shadow_eligible=True)
    stage2_mckee_verdict: Optional[str] = None
    stage2_mckee_details: Optional[dict] = None
    if outcomes:
        stage2_mckee_verdict = outcomes[-1].get("stage2_mckee_verdict")
        stage2_mckee_details = outcomes[-1].get("stage2_mckee")

    return {
        "target": target,
        "iterations_run": len(outcomes),
        "loop_state": loop_state,
        "baseline_score": baseline_mean,
        "best_candidate_id": best_candidate_id,
        "best_candidate_score": best_candidate_score if best_candidate_id else None,
        "drift_ratio": outcomes[-1]["drift_ratio"] if outcomes else None,
        "shadow_eligible": shadow_eligible,
        "baseline_source": baseline_source,
        "outcomes": outcomes,
        "hypothesis_pull": hypothesis_pull_result,
        "stage2_mckee_verdict": stage2_mckee_verdict,
        "stage2_mckee": stage2_mckee_details,
    }


# ---------------------------------------------------------------------------
# Promotion criterion helper — pure-function, easy to test + audit.
# ---------------------------------------------------------------------------

@dataclass
class PromotionInputs:
    battery_score: float
    baseline_battery_score: float
    shadow_score_margin: Optional[float]
    self_feedback_entry_rate: float
    self_feedback_entry_rate_threshold: float
    consolidation_conflicts: int


def promotion_eligible(p: PromotionInputs) -> tuple[bool, list[str]]:
    """Return (eligible, reasons_against).

    Promotion criterion per the task brief:
        battery_score > baseline
        AND shadow_score > baseline
        AND new_self_feedback_entry_rate < threshold
        AND no_consolidation_conflicts

    Any failing clause is returned in ``reasons_against``. All clauses
    are AND-ed — any False → not eligible.
    """
    reasons: list[str] = []
    if not (p.battery_score > p.baseline_battery_score):
        reasons.append(
            f"battery_score ({p.battery_score}) <= baseline ({p.baseline_battery_score})"
        )
    if p.shadow_score_margin is None or not (p.shadow_score_margin > 0.0):
        reasons.append(
            f"shadow_score_margin ({p.shadow_score_margin}) must be > 0.0"
        )
    if not (p.self_feedback_entry_rate < p.self_feedback_entry_rate_threshold):
        reasons.append(
            f"self_feedback_entry_rate ({p.self_feedback_entry_rate}) "
            f">= threshold ({p.self_feedback_entry_rate_threshold})"
        )
    if p.consolidation_conflicts != 0:
        reasons.append(
            f"consolidation_conflicts ({p.consolidation_conflicts}) != 0"
        )
    return (len(reasons) == 0), reasons


if __name__ == "__main__":
    # P0-1 backfill: CLI entry routes through harness via workflow_execute.
    # Usage: python -m workflows.autoresearch_engine <target>
    import sys as _sys

    def _workflow_entry():
        if len(_sys.argv) < 2:
            print("usage: python -m workflows.autoresearch_engine <target>",
                  file=_sys.stderr)
            _sys.exit(2)
        target = _sys.argv[1]
        return run_autoresearch(target)

    workflow_execute(
        workflow_name="autoresearch_engine",
        action=_workflow_entry,
        task_type="judgment",
        actor="cli",
    )
