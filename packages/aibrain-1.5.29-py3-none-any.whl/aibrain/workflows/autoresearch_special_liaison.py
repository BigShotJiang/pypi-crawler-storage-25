"""
Karpathy loop orchestration for Special Liaison persona evolution.

Iteratively improves the Special Liaison reviewer persona via a frozen battery
of review-quality tasks. Plateau champion will be promoted and named Codex.

Usage:
  python -m aibrain.core.workflow_runner autoresearch_special_liaison
  python -m aibrain.core.workflow_runner autoresearch_special_liaison --shadow-only
"""

import logging
from pathlib import Path

logger = logging.getLogger(__name__)

BASELINE_PERSONA_PATH = Path(
    r"C:\Users\sinde\decker_system\02_subagents\special_liaison.md"
)
PROGRAM_MD_PATH = Path(
    r"C:\Users\sinde\projects\aibrain\research\special_liaison\program.md"
)
VARIANTS_DIR = Path(
    r"C:\Users\sinde\projects\aibrain\research\special_liaison\variants"
)


def run(config=None, **kwargs):
    """Run the Special Liaison autoresearch loop. Plateau champion = Codex."""
    try:
        from aibrain.workflows.autoresearch_engine import run_autoresearch
    except ImportError as e:
        logger.error("autoresearch_engine not found: %s", e)
        return {"status": "error", "message": f"Import failed: {e}"}

    default_config = {
        "target": "special_liaison",
        "max_iterations": 20,
        "plateau_limit": 5,
        "drift_threshold": 0.50,
        "iteration_timeout_seconds": 900,
        "shadow_mode": True,
        "margin": 0.0,
    }

    if config:
        default_config.update(config)
    for key in ["max_iterations", "plateau_limit", "drift_threshold", "shadow_mode", "margin"]:
        if key in kwargs:
            default_config[key] = kwargs[key]

    logger.info("Starting special_liaison autoresearch loop: %s", default_config)

    if BASELINE_PERSONA_PATH.is_file():
        baseline_text = BASELINE_PERSONA_PATH.read_text(encoding="utf-8")
        program_md_text = (
            PROGRAM_MD_PATH.read_text(encoding="utf-8")
            if PROGRAM_MD_PATH.is_file()
            else ""
        )
        try:
            from aibrain.workflows.autoresearch_mutation_generator import generate_mutations
            generated = generate_mutations(
                baseline_text=baseline_text,
                program_md_text=program_md_text,
                variants_dir=VARIANTS_DIR,
                n=3,
            )
            logger.info("Mutation generator produced %d new variants: %s", len(generated), generated)
        except Exception as exc:  # noqa: BLE001
            logger.warning("Mutation generator failed (non-fatal): %s", exc)
    else:
        logger.warning("Baseline persona not found at %s", BASELINE_PERSONA_PATH)

    try:
        results = run_autoresearch(**default_config)
        return results
    except Exception as e:
        logger.error("Autoresearch failed: %s: %s", type(e).__name__, e, exc_info=True)
        return {"status": "error", "message": str(e)}


if __name__ == "__main__":
    import json
    result = run()
    print(json.dumps(result, indent=2))
