"""
subscriber_watch.py — First paid subscriber detection + Telegram alert.

Runs once, exits. Designed for cron every 15min.

Detection sources (in priority order):
  1. license_state table: tier != 'free', stripe_subscription_id present
  2. unattributed_license_events table: event_type = 'subscription.*' or tier != 'free'

No 'subscriptions' table exists in aibrain.db — the actual subscription state
lives in license_state (attributed) and unattributed_license_events (Stripe webhooks
not yet matched to a user).
"""

import json
import os
import sqlite3
import urllib.request
import urllib.parse
from datetime import datetime, timezone

from aibrain.core.workflow_base import workflow_execute

# Original: C:/Users/sinde/projects/aibrain/aibrain.db
_aibrain_root = os.environ.get("AIBRAIN_ROOT", "")
AIBRAIN_DB = os.environ.get("AIBRAIN_DB_PATH", f"{_aibrain_root}/aibrain.db" if _aibrain_root else "")
TELEGRAM_TOKEN = os.environ.get("TELEGRAM_TOKEN", "")
TELEGRAM_CHAT_ID = -5288572284
ACTOR = "subscriber_watch"


# ---------------------------------------------------------------------------
# DB helpers
# ---------------------------------------------------------------------------

def get_con() -> sqlite3.Connection:
    con = sqlite3.connect(AIBRAIN_DB)
    con.row_factory = sqlite3.Row
    return con


def log_event(con: sqlite3.Connection, event_type: str, payload: dict) -> None:
    """Write to event_bus_log so the detection is auditable."""
    con.execute(
        "INSERT INTO event_bus_log (event_type, payload, created, actor) VALUES (?, ?, ?, ?)",
        (
            event_type,
            json.dumps(payload),
            datetime.now(timezone.utc).isoformat(),
            ACTOR,
        ),
    )
    con.commit()


# ---------------------------------------------------------------------------
# Subscriber detection
# ---------------------------------------------------------------------------

def detect_first_paid_from_license_state(con: sqlite3.Connection) -> dict | None:
    """
    Check license_state for any non-free, active Stripe subscription.
    Joined to users table for email/name context.
    """
    row = con.execute(
        """
        SELECT
            ls.user_id,
            ls.tier,
            ls.stripe_customer_id,
            ls.stripe_subscription_id,
            ls.valid_until,
            ls.updated_at,
            u.email,
            u.name
        FROM license_state ls
        LEFT JOIN users u ON u.id = ls.user_id
        WHERE ls.tier != 'free'
          AND ls.stripe_subscription_id IS NOT NULL
          AND ls.stripe_subscription_id != ''
        ORDER BY ls.updated_at ASC
        LIMIT 1
        """
    ).fetchone()
    return dict(row) if row else None


def detect_first_paid_from_webhook_events(con: sqlite3.Connection) -> dict | None:
    """
    Fallback: check unattributed_license_events for any non-free tier event
    that looks like a new subscription (Stripe webhook not yet matched to user).
    """
    row = con.execute(
        """
        SELECT
            id,
            event_type,
            tier,
            email,
            stripe_customer_id,
            stripe_subscription_id,
            license_key,
            received_at
        FROM unattributed_license_events
        WHERE tier IS NOT NULL
          AND tier != ''
          AND tier != 'free'
        ORDER BY received_at ASC
        LIMIT 1
        """
    ).fetchone()
    return dict(row) if row else None


# ---------------------------------------------------------------------------
# Already-alerted guard (avoid duplicate Telegram pings)
# ---------------------------------------------------------------------------

def already_alerted(con: sqlite3.Connection) -> bool:
    """Return True if we already fired the first-subscriber alert."""
    row = con.execute(
        "SELECT 1 FROM event_bus_log WHERE event_type = 'subscriber.first_paid' LIMIT 1"
    ).fetchone()
    return row is not None


# ---------------------------------------------------------------------------
# Telegram
# ---------------------------------------------------------------------------

def send_telegram(message: str) -> bool:
    if not TELEGRAM_TOKEN:
        print("[subscriber_watch] ERROR: TELEGRAM_TOKEN not set — cannot send alert", flush=True)
        return False
    url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"
    data = urllib.parse.urlencode({
        "chat_id": TELEGRAM_CHAT_ID,
        "text": message,
        "parse_mode": "Markdown",
    }).encode()
    try:
        req = urllib.request.Request(url, data=data, method="POST")
        with urllib.request.urlopen(req, timeout=10) as resp:
            result = json.loads(resp.read())
            return result.get("ok", False)
    except Exception as exc:
        print(f"[subscriber_watch] Telegram send failed: {exc}", flush=True)
        return False


def build_alert_message(source: str, info: dict) -> str:
    lines = [
        "FIRST PAID SUBSCRIBER DETECTED",
        "",
        f"Source: {source}",
        f"Tier: {info.get('tier', 'unknown')}",
    ]
    if info.get("email"):
        lines.append(f"Email: {info['email']}")
    if info.get("name"):
        lines.append(f"Name: {info['name']}")
    if info.get("user_id"):
        lines.append(f"User ID: {info['user_id']}")
    if info.get("stripe_customer_id"):
        lines.append(f"Stripe customer: {info['stripe_customer_id']}")
    if info.get("stripe_subscription_id"):
        lines.append(f"Stripe subscription: {info['stripe_subscription_id']}")
    if info.get("license_key"):
        lines.append(f"License key: {info['license_key']}")
    ts = info.get("updated_at") or info.get("received_at") or info.get("valid_until") or "unknown"
    lines.append(f"Timestamp: {ts}")
    lines.append("")
    lines.append("Verify: https://dashboard.stripe.com/customers")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> int:
    print(f"[subscriber_watch] {datetime.now(timezone.utc).isoformat()} — checking for first paid subscriber", flush=True)

    con = get_con()

    # Guard: don't re-fire if we already sent the alert
    if already_alerted(con):
        print("[subscriber_watch] Already alerted — first subscriber recorded in event_bus_log. Exiting.", flush=True)
        con.close()
        return 0

    # Detection: license_state (attributed) first
    info = detect_first_paid_from_license_state(con)
    source = "license_state"

    if not info:
        # Fallback: Stripe webhook events not yet matched to a user
        info = detect_first_paid_from_webhook_events(con)
        source = "unattributed_license_events (Stripe webhook)"

    if not info:
        print("[subscriber_watch] No paid subscribers found. license_state and unattributed_license_events are both empty.", flush=True)
        print("[subscriber_watch] Manual check: https://dashboard.stripe.com/subscriptions", flush=True)
        con.close()
        return 0

    # Found one — alert + log
    print(f"[subscriber_watch] FOUND first paid subscriber via {source}: tier={info.get('tier')}", flush=True)

    message = build_alert_message(source, info)
    sent = send_telegram(message)
    print(f"[subscriber_watch] Telegram alert {'sent' if sent else 'FAILED'}.", flush=True)

    # Log to event_bus_log regardless of Telegram result
    log_event(con, "subscriber.first_paid", {
        "source": source,
        "tier": info.get("tier"),
        "email": info.get("email"),
        "user_id": info.get("user_id"),
        "stripe_customer_id": info.get("stripe_customer_id"),
        "stripe_subscription_id": info.get("stripe_subscription_id"),
        "detected_at": datetime.now(timezone.utc).isoformat(),
    })
    print("[subscriber_watch] Logged to event_bus_log as subscriber.first_paid.", flush=True)

    con.close()
    return 0


if __name__ == "__main__":
    workflow_execute(
        workflow_name="subscriber_watch",
        action=main,
        task_type="deterministic",
        actor="cli",
    )
