"""
aibrain.integrations.strands_adapter — AWS Strands Agents memory backed by
AIBrain.

AWS Strands Agents SDK uses a tool-based architecture.  Memory is provided via
tool functions that agents can call.  This adapter provides AIBrain-backed
memory tools for use with Strands agents.

Strands is imported at call time only — no hard dependency.

Usage:
    from aibrain.integrations.strands_adapter import (
        AIBrainMemoryStore,
        memory_search,
        memory_store,
    )
    from strands import Agent

    brain_store = AIBrainMemoryStore(user_id="strands-alice")

    agent = Agent(
        tools=[
            brain_store.as_search_tool(),
            brain_store.as_store_tool(),
        ]
    )
    agent("Remember that Alice prefers SI units.")
    agent("What units does Alice prefer?")
"""

from __future__ import annotations

from typing import Callable, List, Optional


class AIBrainMemoryStore:
    """AIBrain memory backend for AWS Strands agents.

    Provides tool factories that return Strands-compatible tool functions
    decorated with the ``@tool`` decorator if Strands is installed.

    Parameters:
        user_id:   Scope memories to this user.
        agent_id:  Scope memories to this agent.
        db_path:   Override path to aibrain.db.
        k:         Max memories per search (default 5).
    """

    def __init__(
        self,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        db_path: Optional[str] = None,
        k: int = 5,
    ) -> None:
        from aibrain.core.memory_api import Brain

        self._brain = Brain(db_path=db_path) if db_path else Brain()
        self._user_id = user_id
        self._agent_id = agent_id
        self._k = k

    def save(self, content: str, metadata: Optional[dict] = None) -> List[dict]:
        """Store a memory directly."""
        return self._brain.add(
            content,
            user_id=self._user_id,
            agent_id=self._agent_id,
            metadata=metadata,
            infer=True,
        )

    def search(self, query: str, limit: Optional[int] = None) -> List[dict]:
        """Search memories."""
        return self._brain.search(
            query,
            user_id=self._user_id,
            agent_id=self._agent_id,
            limit=limit or self._k,
        )

    def recall_as_str(self, query: str) -> str:
        results = self.search(query)
        return "\n".join(r.get("memory", "") for r in results if r.get("memory"))

    def as_search_tool(self) -> Callable:
        """Return a Strands-compatible tool function for memory search.

        The returned function is decorated with ``@tool`` if Strands is
        available; otherwise it is a plain callable.
        """
        brain = self

        def memory_search(query: str) -> str:
            """Search persistent memory for facts relevant to the query.

            Use this to recall user preferences, past decisions, and project
            context from previous sessions.
            """
            text = brain.recall_as_str(query)
            return text or "No relevant memories found."

        return _maybe_decorate(memory_search)

    def as_store_tool(self) -> Callable:
        """Return a Strands-compatible tool function for memory storage."""
        brain = self

        def memory_store(content: str) -> str:
            """Store a fact or piece of information in persistent memory.

            Use this to remember user preferences, decisions, or any context
            the agent should retain across sessions.
            """
            results = brain.save(content)
            stored = len([r for r in results if r.get("event") != "SKIP"])
            return f"Stored {stored} fact(s)." if stored else "Already known."

        return _maybe_decorate(memory_store)


def _maybe_decorate(fn: Callable) -> Callable:
    """Wrap with @tool if Strands is installed."""
    try:
        from strands import tool  # type: ignore[import]
        return tool(fn)
    except ImportError:
        return fn


# ------------------------------------------------------------------
# Module-level convenience tools (pre-bound to default Brain)
# ------------------------------------------------------------------

def memory_search(query: str, user_id: Optional[str] = None) -> str:
    """Module-level memory search — uses default aibrain.db.

    For use when you want a single shared brain without instantiating
    AIBrainMemoryStore explicitly.
    """
    from aibrain.core.memory_api import Brain
    brain = Brain()
    results = brain.search(query, user_id=user_id, limit=5)
    texts = [r.get("memory", "") for r in results if r.get("memory")]
    return "\n".join(texts) if texts else "No relevant memories found."


def memory_store(content: str, user_id: Optional[str] = None) -> str:
    """Module-level memory store — uses default aibrain.db."""
    from aibrain.core.memory_api import Brain
    brain = Brain()
    results = brain.add(content, user_id=user_id, infer=True)
    stored = len([r for r in results if r.get("event") != "SKIP"])
    return f"Stored {stored} fact(s)." if stored else "Already known."


# Decorate module-level tools if Strands is installed
memory_search = _maybe_decorate(memory_search)  # type: ignore[assignment]
memory_store = _maybe_decorate(memory_store)  # type: ignore[assignment]
