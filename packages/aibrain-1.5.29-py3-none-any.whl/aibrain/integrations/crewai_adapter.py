"""
aibrain.integrations.crewai_adapter — CrewAI memory provider backed by AIBrain.

Wraps AIBrain's Brain.search() and Brain.add() as a CrewAI-compatible memory
provider.  CrewAI is imported at call time only — no hard dependency.

Usage:
    from aibrain.integrations.crewai_adapter import AIBrainCrewMemory

    memory = AIBrainCrewMemory(user_id="crew-research")

    # Store knowledge
    memory.save("The target company was founded in 2019 in Berlin.")

    # Retrieve relevant context
    results = memory.search("When was the company founded?", limit=3)
    for r in results:
        print(r["memory"], r["score"])

    # Use with a CrewAI crew:
    from crewai import Crew, Agent, Task

    researcher = Agent(
        role="Researcher",
        goal="Find company info",
        memory=True,
    )
    crew = Crew(
        agents=[researcher],
        tasks=[Task(description="Research the company", agent=researcher)],
        memory_provider=memory,
    )
"""

from __future__ import annotations

from typing import Optional


class AIBrainCrewMemory:
    """CrewAI-compatible memory provider using AIBrain as the backend.

    Parameters:
        user_id:   Scope memories to this user/crew.
        agent_id:  Scope memories to this agent.
        db_path:   Override path to aibrain.db.
        compress:  If True, compress search results via aibrain-compress.
    """

    def __init__(
        self,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        db_path: Optional[str] = None,
        compress: bool = False,
    ) -> None:
        from aibrain.core.memory_api import Brain

        self._brain = Brain(db_path=db_path) if db_path else Brain()
        self._user_id = user_id
        self._agent_id = agent_id
        self._compress = compress

    # -- CrewAI memory provider interface --------------------------------------

    def save(
        self,
        content: str,
        metadata: Optional[dict] = None,
        agent_id: Optional[str] = None,
    ) -> list[dict]:
        """Store a memory (text or extracted fact).

        Args:
            content:  Text to memorise.
            metadata: Optional metadata tags.
            agent_id: Override the default agent_id for this save.

        Returns:
            List of stored/updated memory dicts from Brain.add().
        """
        return self._brain.add(
            content,
            user_id=self._user_id,
            agent_id=agent_id or self._agent_id,
            metadata=metadata,
            infer=True,
        )

    def search(
        self,
        query: str,
        limit: int = 5,
        agent_id: Optional[str] = None,
    ) -> list[dict]:
        """Semantic search over memories.

        Args:
            query: Natural-language query.
            limit: Max results.
            agent_id: Override default agent_id filter.

        Returns:
            List of memory dicts with id, memory, score, reason fields.
        """
        results = self._brain.search(
            query,
            user_id=self._user_id,
            agent_id=agent_id or self._agent_id,
            limit=limit,
        )

        if self._compress and results:
            try:
                from aibrain.tools.compress import compress
                for r in results:
                    r["memory"] = compress(
                        command=["memory", "search"],
                        output=r.get("memory", ""),
                    )
            except Exception:
                pass

        return results

    def reset(self) -> None:
        """Reset is a no-op — AIBrain uses soft-delete, not hard wipe."""
        pass
