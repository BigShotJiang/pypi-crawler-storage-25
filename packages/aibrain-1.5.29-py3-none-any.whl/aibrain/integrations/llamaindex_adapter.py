"""
aibrain.integrations.llamaindex_adapter — LlamaIndex BaseMemory backend using
AIBrain.

Implements the LlamaIndex ``BaseMemory`` interface so any LlamaIndex chat
engine or agent can use AIBrain as its persistent memory store.

LlamaIndex is imported at call time only — no hard dependency.

Usage:
    from aibrain.integrations.llamaindex_adapter import AIBrainChatMemory
    from llama_index.core.chat_engine import SimpleChatEngine

    memory = AIBrainChatMemory.from_defaults(user_id="llamaindex-alice")

    engine = SimpleChatEngine.from_defaults(memory=memory)
    response = engine.chat("I work at Acme Corp in the AI team.")
    response = engine.chat("Where do I work?")
    # → "You mentioned you work at Acme Corp in the AI team."
"""

from __future__ import annotations

import json
from typing import Any, Dict, List, Optional


class AIBrainChatMemory:
    """LlamaIndex BaseMemory implementation backed by AIBrain.

    Subclasses ``llama_index.core.memory.BaseMemory`` at runtime so the
    LlamaIndex import is only required when this class is instantiated.

    Parameters:
        user_id:   Scope memories to this user.
        agent_id:  Scope memories to this agent.
        db_path:   Override path to aibrain.db.
        token_limit: Soft limit on tokens returned (default 1500).
        k:           Max memories retrieved per turn (default 5).
    """

    # LlamaIndex expects these class-level annotations
    token_limit: int = 1500

    def __new__(cls, *args: Any, **kwargs: Any) -> "AIBrainChatMemory":
        try:
            from llama_index.core.memory import BaseMemory as _BaseMemory  # type: ignore[import]
        except ImportError:
            try:
                # Older LlamaIndex path
                from llama_index.memory import BaseMemory as _BaseMemory  # type: ignore[import]
            except ImportError:
                raise ImportError(
                    "llama-index-core is required for AIBrainChatMemory. "
                    "Install it with: pip install llama-index-core"
                )
        if _BaseMemory not in cls.__bases__:
            cls.__bases__ = (_BaseMemory, *cls.__bases__)
        return super().__new__(cls)

    def __init__(
        self,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        db_path: Optional[str] = None,
        token_limit: int = 1500,
        k: int = 5,
    ) -> None:
        if hasattr(self, "_brain"):
            return
        from aibrain.core.memory_api import Brain

        self._brain = Brain(db_path=db_path) if db_path else Brain()
        self._user_id = user_id
        self._agent_id = agent_id
        self._k = k
        self.token_limit = token_limit
        self._chat_history: List[Any] = []  # In-session buffer

    @classmethod
    def from_defaults(
        cls,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        db_path: Optional[str] = None,
        token_limit: int = 1500,
        k: int = 5,
    ) -> "AIBrainChatMemory":
        """Factory method (LlamaIndex convention)."""
        return cls(
            user_id=user_id,
            agent_id=agent_id,
            db_path=db_path,
            token_limit=token_limit,
            k=k,
        )

    # ------------------------------------------------------------------
    # BaseMemory interface
    # ------------------------------------------------------------------

    def get(self, input: Optional[str] = None, **kwargs: Any) -> List[Any]:
        """Return relevant chat messages for the given input.

        Retrieves memories from AIBrain and wraps them as ChatMessage objects.

        Args:
            input: The current user message (used for semantic retrieval).

        Returns:
            List of ChatMessage objects with role=SYSTEM.
        """
        try:
            from llama_index.core.llms import ChatMessage, MessageRole  # type: ignore[import]
        except ImportError:
            from llama_index.llms import ChatMessage, MessageRole  # type: ignore[import]

        if not input:
            return list(self._chat_history)

        results = self._brain.search(
            input,
            user_id=self._user_id,
            agent_id=self._agent_id,
            limit=self._k,
        )
        texts = [r.get("memory", "") for r in results if r.get("memory")]

        if not texts:
            return list(self._chat_history)

        memory_block = "\n".join(f"- {t}" for t in texts)
        memory_msg = ChatMessage(
            role=MessageRole.SYSTEM,
            content=f"[Relevant memories from past sessions]\n{memory_block}",
        )
        return [memory_msg] + list(self._chat_history)

    def get_all(self) -> List[Any]:
        """Return all in-session chat messages."""
        return list(self._chat_history)

    def put(self, message: Any) -> None:
        """Add a message to memory.

        Both persists in AIBrain and appends to in-session buffer.

        Args:
            message: A LlamaIndex ChatMessage.
        """
        self._chat_history.append(message)
        content = getattr(message, "content", None) or str(message)
        role = getattr(getattr(message, "role", None), "value", "unknown")
        if content:
            self._brain.add(
                f"[{role}] {content}",
                user_id=self._user_id,
                agent_id=self._agent_id,
            )

    def set(self, messages: List[Any]) -> None:
        """Replace the in-session buffer."""
        self._chat_history = list(messages)

    def reset(self) -> None:
        """Clear in-session buffer (AIBrain memories are retained)."""
        self._chat_history = []

    def to_string(self) -> str:
        """Serialise to JSON string (LlamaIndex persistence interface)."""
        return json.dumps({
            "user_id": self._user_id,
            "agent_id": self._agent_id,
            "token_limit": self.token_limit,
            "k": self._k,
        })

    @classmethod
    def from_string(cls, data: str) -> "AIBrainChatMemory":
        """Deserialise from JSON string."""
        kwargs = json.loads(data)
        return cls(**kwargs)

    def to_dict(self, **kwargs: Any) -> Dict[str, Any]:
        return json.loads(self.to_string())

    @classmethod
    def from_dict(cls, data: Dict[str, Any], **kwargs: Any) -> "AIBrainChatMemory":
        return cls(**data)
