"""
workflow_runner.py — Run any workflow through the execution harness.

Wraps existing workflow functions with eval, audit, authority, and model routing.
Drop-in replacement for direct workflow execution.

Usage:
    from aibrain.core.workflow_runner import run_workflow

    result = run_workflow("heartbeat", dry_run=True)
    result = run_workflow("db_backup")
    result = run_workflow("email_auto_reply", authority="elevated")

Or from CLI:
    python -m aibrain.core.workflow_runner heartbeat --dry-run
    python -m aibrain.core.workflow_runner db_backup
"""

import atexit
import importlib
import logging
import os
import re
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Optional

from aibrain.core.harness import (
    execute, HarnessConfig, HarnessResult
)

log = logging.getLogger("aibrain.workflow_runner")

# Thread pool for event-triggered workflow dispatch.
# Keeps event bus handlers non-blocking — workflows are submitted here instead
# of running synchronously on the bus caller's thread (300s blocking risk).
_dispatch_executor = ThreadPoolExecutor(
    max_workers=os.cpu_count() or 4,
    thread_name_prefix="wf_dispatch",
)
atexit.register(_dispatch_executor.shutdown, wait=False)

# Workflow directory
WORKFLOW_DIR = Path(__file__).parent.parent / "workflows"

# Workflow metadata — task type, authority, budget
# This is the per-workflow capability scoping Decker asked for
#
# Schema for each entry:
#   task_type        (str)  "deterministic"|"simple"|"judgment"|"complex"
#   authority        (str)  "read_only"|"standard"|"elevated"|"admin"
#   max_cost         (int)  max spend in cents (0 = no LLM)
#   timeout_seconds  (int)  optional — per-workflow harness timeout.
#                           Falls back to the harness default (300s) when absent.
#   internal         (bool) optional — excluded from user-facing workflow list
#   capabilities     (list) optional — declared capability requirements
#   requires_approval(list) optional — capabilities that need Decker approval
WORKFLOW_REGISTRY = {
    # Deterministic: no LLM needed, just code execution
    "heartbeat": {"task_type": "deterministic", "authority": "read_only", "max_cost": 0, "timeout_seconds": 30},
    "db_backup": {"task_type": "deterministic", "authority": "standard", "max_cost": 0},
    "service_monitor": {"task_type": "deterministic", "authority": "read_only", "max_cost": 0, "internal": True},
    "smart_file_organizer": {"task_type": "deterministic", "authority": "standard", "max_cost": 0},
    "build_installer_sidecar": {"task_type": "deterministic", "authority": "standard", "max_cost": 0, "timeout_seconds": 900},
    "smoke_test_backend_chat": {"task_type": "deterministic", "authority": "standard", "max_cost": 0, "timeout_seconds": 300},

    # Simple: light LLM use for formatting/parsing
    "telegram_check": {"task_type": "deterministic", "authority": "standard", "max_cost": 0, "internal": True},

    # Social posting: Playwright only, computer use requires CEO approval
    "social_poster": {"task_type": "simple", "authority": "elevated", "max_cost": 0, "requires_approval": ["computer_use", "desktop_control"], "capabilities": ["computer_use", "desktop_control", "post_to_platform"]},
    "social_scheduler": {"task_type": "deterministic", "authority": "elevated", "max_cost": 0, "requires_approval": ["computer_use", "desktop_control"], "capabilities": ["computer_use", "desktop_control", "post_to_platform"]},
    "instagram_poster": {"task_type": "simple", "authority": "elevated", "max_cost": 0, "requires_approval": ["computer_use", "desktop_control"], "capabilities": ["computer_use", "desktop_control", "post_to_platform"]},

    # Judgment: needs real LLM reasoning
    "cross_domain_questions": {"task_type": "judgment", "authority": "standard", "max_cost": 50},
    "contradiction_detector": {"task_type": "judgment", "authority": "standard", "max_cost": 50},
    "evolution_auto_loop": {"task_type": "judgment", "authority": "elevated", "max_cost": 200, "timeout_seconds": 900},
    "evolution_experiment": {"task_type": "complex", "authority": "elevated", "max_cost": 500},

    # Elevated: can send emails, push to git, post to platforms
    "email_auto_reply": {"task_type": "judgment", "authority": "elevated", "max_cost": 100, "capabilities": ["send_email", "write_file"]},
    "email_to_task": {"task_type": "simple", "authority": "elevated", "max_cost": 10, "capabilities": ["send_email"]},

    # Complex: architecture, security, novel reasoning
    "code_review_runner": {"task_type": "complex", "authority": "elevated", "max_cost": 300},

    # Knowledge: memory and brain operations
    "knowledge_graph_builder": {"task_type": "judgment", "authority": "standard", "max_cost": 100},
    "memory_consolidation": {"task_type": "judgment", "authority": "standard", "max_cost": 100},
    # dream: nightly REM pass (CLS phase). No LLM, no embeddings — pure SQL prune/dedup/decay.
    # Complements the heavier weekly memory_consolidation (cluster+merge+Ebbinghaus+archive+rebuild).
    # Runs nightly at 02:00. Deterministic, zero cost.
    "dream": {"task_type": "deterministic", "authority": "standard", "max_cost": 0},
    "memory_md_sync": {"task_type": "deterministic", "authority": "standard", "max_cost": 0},
    "learning_extractor": {"task_type": "judgment", "authority": "standard", "max_cost": 100},
    "auto_experiment": {"task_type": "complex", "authority": "elevated", "max_cost": 500},

    # Research & monitoring: read-heavy, low authority
    "arxiv_tracker": {"task_type": "simple", "authority": "read_only", "max_cost": 10},
    "daily_research": {"task_type": "judgment", "authority": "read_only", "max_cost": 50},
    "rss_digest": {"task_type": "simple", "authority": "read_only", "max_cost": 10},
    "newsletter_digest": {"task_type": "simple", "authority": "read_only", "max_cost": 10},
    "github_digest": {"task_type": "simple", "authority": "read_only", "max_cost": 10},
    "security_advisories": {"task_type": "simple", "authority": "read_only", "max_cost": 10},
    "price_watcher": {"task_type": "deterministic", "authority": "read_only", "max_cost": 0},
    "weather_briefing": {"task_type": "deterministic", "authority": "read_only", "max_cost": 0},
    "uptime_monitor": {"task_type": "deterministic", "authority": "read_only", "max_cost": 0},
    "seo_monitor": {"task_type": "simple", "authority": "read_only", "max_cost": 10},
    "social_listener": {"task_type": "simple", "authority": "read_only", "max_cost": 10},

    # Productivity: standard authority
    "daily_planner": {"task_type": "judgment", "authority": "standard", "max_cost": 50},
    "calendar_manager": {"task_type": "simple", "authority": "standard", "max_cost": 10},
    "habit_tracker": {"task_type": "deterministic", "authority": "standard", "max_cost": 0},
    "expense_tracker": {"task_type": "deterministic", "authority": "standard", "max_cost": 0},
    "meeting_notes": {"task_type": "judgment", "authority": "standard", "max_cost": 50},
    "bookmark_organizer": {"task_type": "simple", "authority": "standard", "max_cost": 10},
    "document_parser": {"task_type": "simple", "authority": "standard", "max_cost": 10},
    "contact_enricher": {"task_type": "simple", "authority": "standard", "max_cost": 10},
    "file_declutter": {"task_type": "deterministic", "authority": "standard", "max_cost": 0},
    "weekly_report": {"task_type": "judgment", "authority": "standard", "max_cost": 50},
    "report_generator": {"task_type": "judgment", "authority": "standard", "max_cost": 50},

    # Content: standard to elevated
    "content_calendar": {"task_type": "judgment", "authority": "standard", "max_cost": 50},

    # Email & comms: elevated (can send)
    "email_triage": {"task_type": "simple", "authority": "standard", "max_cost": 10, "capabilities": ["read_file", "query_db"]},
    "morning_check_email_summarize": {"task_type": "simple", "authority": "standard", "max_cost": 10, "capabilities": ["read_file", "query_db"]},

    # Job search: elevated (can apply/respond)
    "job_search_apply": {"task_type": "judgment", "authority": "elevated", "max_cost": 100},
    "job_response_checker": {"task_type": "simple", "authority": "standard", "max_cost": 10},
    "job_tracker_db": {"task_type": "deterministic", "authority": "standard", "max_cost": 0},
    "interview_prep": {"task_type": "judgment", "authority": "standard", "max_cost": 50},

    # Code & dev: elevated (can write files, run commands)
    "dependency_auditor": {"task_type": "simple", "authority": "standard", "max_cost": 10},
    "git_monitor": {"task_type": "deterministic", "authority": "read_only", "max_cost": 0},
    "friday_check_github_new": {"task_type": "simple", "authority": "read_only", "max_cost": 10},
    "cli_anything_bridge": {"task_type": "judgment", "authority": "elevated", "max_cost": 100, "capabilities": ["execute_command", "subprocess"]},

    # Risk & analysis: elevated
    "risk_analyst": {"task_type": "complex", "authority": "elevated", "max_cost": 200},

    # intel_agent V2 persona self-improvement experiment (Phase B / Phase C)
    # Both workflows are LLM-authored-content + deterministic-glue shape.
    # Audit files a one-page spec; rewrite files a full V2 persona body.
    # Gated by structural header validation inside each workflow.
    "intel_agent_v2_audit_persona": {"task_type": "judgment", "authority": "standard", "max_cost": 100},
    "intel_agent_v2_rewrite_persona": {"task_type": "judgment", "authority": "standard", "max_cost": 200},

    # Content freshness: regenerates decker_system/00_meta/aibrain_live_truth_v1_4_0.md
    # from live source counts. Pure deterministic file I/O + pytest collect count.
    "update_aibrain_live_truth": {"task_type": "deterministic", "authority": "standard", "max_cost": 10},

    # Subscriber watch: detect first paid subscriber in aibrain.db, fire Telegram alert once.
    # Guard in event_bus_log prevents duplicate alerts. Runs every 15min via cron.
    "subscriber_watch": {"task_type": "deterministic", "authority": "elevated", "max_cost": 0, "capabilities": ["send_email", "post_to_platform"]},

    # intel_agent_run: scheduled competitive intelligence sweep using intel_agent V2 methodology.
    # Reads targets from ~/.aibrain/intel_targets.json (or uses defaults), runs research loops,
    # stores findings as competitive_intel memories, sends Telegram digest to Decker.
    # Budget: up to $5/run for deep research. Runs weekly (Monday 9am ACST) via cron.
    "intel_agent_run": {"task_type": "judgment", "authority": "elevated", "max_cost": 500},

    # grc_snapshot: nightly compliance snapshot via GRC API at :8002.
    # POSTs to /api/reports/executive/snapshot, logs result for trend tracking.
    # No auth required (public_router). Runs nightly at 2am via cron.
    "grc_snapshot": {"task_type": "deterministic", "authority": "standard", "max_cost": 10},

    # retrolearn: backfill evolution_outcomes from unlinked honest execution_log rows.
    # Reads execution_log rows with quality_score set but no entity_id linkage (post-Apr-10).
    # Idempotent — safe to re-run. No LLM calls, pure DB reads + writes.
    "retrolearn": {"task_type": "deterministic", "authority": "standard", "max_cost": 0},

    # architecture_review: dispatch an architecture & performance review task to the
    # Architecture & Performance Analyst (BJAnXavx2Nk) via the company task system.
    # Accepts optional --target (path or description). Creates a tracked company task
    # and returns the task ID for dashboard follow-up.
    "architecture_review": {"task_type": "judgment", "authority": "standard", "max_cost": 50},

    # stripe_drift_check: weekly Stripe config integrity monitor.
    # Fetches live webhook/product/price state via Stripe API, diffs against
    # workers/stripe_config.md canonical anchors, sends Telegram alert on drift.
    # No LLM calls — pure API + string comparison. Runs every Monday 9am ACST.
    "stripe_drift_check": {"task_type": "deterministic", "authority": "read_only", "max_cost": 0},

    # competitor_analysis: targeted single-competitor deep dive via intel_agent_v2 methodology.
    # Accepts --target (name or URL) and optional --prompt override.
    # Used for biweekly SLM pivot watch (slm_watch cron) and any ad-hoc competitor research.
    # Escalates to Decker via Telegram immediately if substrate pivot signals are detected.
    "competitor_analysis": {"task_type": "judgment", "authority": "elevated", "max_cost": 500, "timeout_seconds": 600},

    # cover_letter: generates tailored cover letters using Playwright company research +
    # LLM generation from decker_profile.json. Read-only document generation — no external writes.
    "cover_letter": {"task_type": "simple", "authority": "standard", "max_cost": 10},

    # job_apply: ATS form-fill layer — fills job applications but NEVER auto-submits.
    # Stops at final confirmation, screenshots, logs as 'review_required' for Decker review.
    # Elevated: uses Playwright browser automation and writes to job_tracker.db.
    "job_apply": {"task_type": "judgment", "authority": "elevated", "max_cost": 100, "capabilities": ["computer_use", "desktop_control", "write_file"]},

    # pain_points_monitor: monitors LinkedIn/Reddit/HN/X for AI agent pain-point posts.
    # Read-only monitoring — drafts suggested replies and sends to Telegram for approval.
    # NEVER posts without Decker approval.
    "pain_points_monitor": {"task_type": "simple", "authority": "standard", "max_cost": 10},

    # pain_post_commenter: searches Twitter/X for AI memory frustration posts, drafts replies.
    # Elevated: can post replies via Tweepy if --dry-run is not set.
    # External posting requires elevated authority.
    "pain_post_commenter": {"task_type": "judgment", "authority": "elevated", "max_cost": 50},

    # social_analytics: syncs posting_log.json to social_analytics DB table, optionally
    # scrapes engagement metrics via Playwright, generates weekly summary.
    # Read-only analytics — no external writes beyond local DB.
    "social_analytics": {"task_type": "deterministic", "authority": "standard", "max_cost": 0},

    # viral_poster: unified 6-hour posting runner for publishing_calendar.json.
    # Reads 686-entry viral launch calendar, posts overdue entries to platforms.
    # Elevated: posts externally to LinkedIn and other platforms.
    "viral_poster": {"task_type": "judgment", "authority": "elevated", "max_cost": 50},

    # autoresearch_intel_agent: Karpathy-loop target wrapper for intel_agent persona.
    # Wraps workflows.autoresearch_engine with intel_agent-specific defaults.
    # Complex task (full iteration + scoring), standard authority (no external writes),
    # 10c budget cap (engine itself is no-LLM; budget covers any future LLM scorer),
    # 60min timeout (≤20 iterations × 20min time-box each per task brief).
    "autoresearch_intel_agent": {"task_type": "complex", "authority": "standard", "max_cost": 10, "timeout_seconds": 3600},

    # autoresearch_special_liaison: Karpathy-loop target for Special Liaison reviewer persona.
    # Plateau champion will be promoted and named Codex.
    "autoresearch_special_liaison": {"task_type": "complex", "authority": "standard", "max_cost": 10, "timeout_seconds": 3600},

    # autoresearch_aibrain_memory: Karpathy-loop target wrapper for retrieval knobs.
    # Wraps workflows.autoresearch_engine with aibrain_memory-specific defaults.
    # Variant = YAML knob block consumed by the adapter; the adapter calls
    # aibrain_db.search_memories with those kwargs. Canonical retrieval code is
    # never mutated by this loop. Complex task, standard authority, 5c budget
    # (no LLM in the loop — deterministic recall@k metric), 30min timeout.
    "autoresearch_aibrain_memory": {"task_type": "complex", "authority": "standard", "max_cost": 5, "timeout_seconds": 1800},

    # ship_release: harnessed release ship workflow — silent install NSIS, verify
    # CLI/HTML/native surfaces, upload to sindecker GH release, flip myaibrain-site
    # _redirects, commit + push aibrain source, close company task with review gate.
    # Elevated: writes git, posts GH release asset, deploys Cloudflare Pages.
    "ship_release": {"task_type": "simple", "authority": "elevated", "max_cost": 0, "timeout_seconds": 1800, "capabilities": ["execute_command", "subprocess", "write_file"]},
}

_VALID_TASK_TYPES = frozenset({"deterministic", "simple", "judgment", "complex"})


def _validate_registry() -> None:
    for name, meta in WORKFLOW_REGISTRY.items():
        tt = meta.get("task_type")
        if tt not in _VALID_TASK_TYPES:
            log.warning("WORKFLOW_REGISTRY[%s].task_type=%r is not a valid task type", name, tt)

_validate_registry()


def get_user_facing_workflows() -> dict:
    """Return WORKFLOW_REGISTRY entries excluding internal-only workflows."""
    return {k: v for k, v in WORKFLOW_REGISTRY.items() if not v.get("internal")}


def clarify_workflow(name: str) -> dict:
    """
    Return what a workflow requires before it can run: env vars, config keys,
    authority level, task type, and a short description from the run function.

    Useful for pre-flight checks before scheduling or automating a workflow.

    Returns:
        {
          "workflow": name,
          "task_type": "deterministic"|"simple"|"judgment"|"complex",
          "authority": "read_only"|"standard"|"elevated"|"admin",
          "max_cost_cents": int,
          "description": str,          # from module/run-fn docstring
          "env_vars": [str],            # detected os.getenv/os.environ calls
          "config_keys": [str],         # detected config.get() calls
          "requires_approval": [str],   # from registry
          "run_fn": str,                # which function will be called
        }
    """
    import re

    meta = WORKFLOW_REGISTRY.get(name, {
        "task_type": "judgment", "authority": "standard", "max_cost": 100,
    })

    workflow_path = WORKFLOW_DIR / f"{name}.py"
    if not workflow_path.exists():
        return {"error": f"Workflow '{name}' not found"}

    source = workflow_path.read_text(encoding="utf-8", errors="ignore")

    # Extract env var names from os.getenv / os.environ.get patterns
    env_vars = sorted(set(
        re.findall(r'os\.(?:getenv|environ\.get)\(["\']([A-Z_][A-Z0-9_]*)["\']', source)
    ))

    # Extract config.get keys
    config_keys = sorted(set(
        re.findall(r'config\.get\(["\']([a-z_][a-z0-9_]*)["\']', source)
    ))

    # Get module/run function docstring
    description = ""
    mod_doc_match = re.search(r'^"""(.*?)"""', source, re.DOTALL | re.MULTILINE)
    if mod_doc_match:
        description = mod_doc_match.group(1).strip().split("\n")[0]

    # Find which run function would be called
    run_fn_name = "run"
    for candidate in [f"run_{name}", "main", "run_pipeline", "run_scan",
                      "run_backup", "run_auto_loop", "run_full_cycle",
                      "check", "execute", "process", "start"]:
        if re.search(rf"^def {candidate}\b", source, re.MULTILINE):
            if candidate != "run" and not re.search(r"^def run\b", source, re.MULTILINE):
                run_fn_name = candidate
                break
    if re.search(r"^def run\b", source, re.MULTILINE):
        run_fn_name = "run"

    return {
        "workflow": name,
        "task_type": meta.get("task_type", "judgment"),
        "authority": meta.get("authority", "standard"),
        "max_cost_cents": meta.get("max_cost", 100),
        "description": description,
        "env_vars": env_vars,
        "config_keys": config_keys,
        "requires_approval": meta.get("requires_approval", []),
        "run_fn": run_fn_name,
    }


def plan_workflow(name: str) -> dict:
    """
    Return a structured execution plan for a workflow: what it will do,
    what model it will use, estimated cost, and what side effects it has.

    Useful for reviewing automation before enabling it.
    """
    clarification = clarify_workflow(name)
    if "error" in clarification:
        return clarification

    meta = WORKFLOW_REGISTRY.get(name, {
        "task_type": "judgment", "authority": "standard", "max_cost": 100,
    })

    # Model routing preview — reads user config if available
    task_type = clarification["task_type"]
    try:
        from aibrain.tools.model.config import load_model_config
        _mcfg = load_model_config()
        _routing = _mcfg.get('routing', {})
    except Exception:
        _routing = {}
    _cost_labels = {
        "code_only": "$0", "haiku": "~$0.001", "local": "$0",
        "sonnet": "~$0.01", "opus": "~$0.05",
    }
    model_map = {}
    for _tier, _default in [("deterministic", "code_only"), ("simple", "haiku"),
                             ("judgment", "sonnet"), ("complex", "opus")]:
        _model = _routing.get(_tier, _default)
        _cost = _cost_labels.get(_model, "~$0.01")
        model_map[_tier] = f"{_model} ({_cost})"
    model_preview = model_map.get(task_type, "sonnet (~$0.01)")

    # Side effects from authority level
    side_effects = {
        "read_only": ["read files", "read DB", "read APIs"],
        "standard": ["read files", "write DB", "write local files"],
        "elevated": ["read files", "write DB", "send emails", "post to platforms", "run commands"],
        "admin": ["all elevated actions", "modify system config", "manage users"],
    }

    return {
        "workflow": name,
        "plan": [
            f"1. Classify task as '{task_type}'",
            f"2. Check authority ('{clarification['authority']}') against permissions DB",
            f"3. Check budget (max ${clarification['max_cost_cents'] / 100:.2f})",
            f"4. Route to model: {model_preview}",
            f"5. Execute {clarification['run_fn']}()",
            "6. Evaluate quality (0.0–1.0)",
            "7. Write audit trail entry",
            "8. Store learning in evolution_outcomes",
        ],
        "model": model_preview,
        "side_effects": side_effects.get(clarification["authority"], []),
        "requires_approval": clarification["requires_approval"],
        "env_vars_needed": clarification["env_vars"],
        "description": clarification["description"],
    }


def run_workflow(
    name: str,
    dry_run: bool = False,
    actor: str = "system",
    authority: Optional[str] = None,
    until_green: bool = False,
    max_retries: int = 5,
    mode: str = "execute",
    event_payload: Optional[dict] = None,
    v3_task_type: Optional[str] = None,
    **kwargs
) -> HarnessResult:
    """
    Run a workflow through the execution harness.

    The harness handles: classification, budget, authority, execution,
    evaluation, audit trail, learning, and retry.

    Args:
        mode:         "execute" (default), "plan" (preview only), or
                      "clarify" (show requirements without executing).
        until_green:  If True, keep retrying until quality_score >= 0.7 or
                      max_retries is reached (inspired by the ralph pattern).
        max_retries:  Maximum retry attempts when until_green=True (default 5).
        v3_task_type: Optional SelRoute v3 task category (e.g. "code_review",
                      "security_review", "polish_refine"). When set, the
                      workflow is routed via aibrain.core.agent_router.route()
                      BEFORE the harness action runs. If the routing decision
                      is `superworker`, the workflow's normal run() function
                      is replaced by a call to aibrain.core.superworker.invoke()
                      that channels the routed lens roster. After execution,
                      agent_router.record_outcome() writes the quality_score
                      back to routing_outcomes for the SelRoute feedback loop.
                      When None (default), routing is skipped — pure backwards
                      compatible behaviour.
    """
    # Short-circuit for plan/clarify modes — no harness needed
    if mode == "clarify":
        info = clarify_workflow(name)
        return HarnessResult(
            success="error" not in info,
            output=info,
            error=info.get("error"),
        )

    if mode == "plan":
        plan = plan_workflow(name)
        return HarnessResult(
            success="error" not in plan,
            output=plan,
            error=plan.get("error"),
        )
    # Validate workflow name before any import or file access — prevents path injection
    # via importlib.import_module(). Only lowercase alphanumeric + underscores allowed.
    if not re.match(r'^[a-z][a-z0-9_]*$', name):
        raise ValueError(f"Invalid workflow name: {name!r}")

    # Look up workflow metadata
    meta = WORKFLOW_REGISTRY.get(name, {
        "task_type": "judgment",  # default to judgment (safe)
        "authority": "standard",
        "max_cost": 100,
    })

    # Override authority if explicitly provided
    _authority_overridden = False
    _registry_authority = meta.get("authority", "standard")
    if authority and authority != _registry_authority:
        meta["authority"] = authority
        _authority_overridden = True
        log.warning(
            "AUTHORITY OVERRIDE: workflow=%s authority=%s (registry default: %s) actor=%s",
            name, authority, _registry_authority, actor,
        )
    elif authority:
        meta["authority"] = authority

    # Find the workflow module
    workflow_path = WORKFLOW_DIR / f"{name}.py"
    if not workflow_path.exists():
        return HarnessResult(
            success=False,
            error=f"Workflow '{name}' not found at {workflow_path}",
        )

    # Import and find the run function
    def _execute_workflow():
        """Load and run the workflow."""
        wf_dir = str(WORKFLOW_DIR)
        parent_dir = str(WORKFLOW_DIR.parent)

        # Track which paths we insert so we only remove what we added
        inserted: list[str] = []
        if wf_dir not in sys.path:
            sys.path.insert(0, wf_dir)
            inserted.append(wf_dir)
        if parent_dir not in sys.path:
            sys.path.insert(0, parent_dir)
            inserted.append(parent_dir)

        # Clear sys.argv to prevent workflow's argparse from firing on import
        original_argv = sys.argv[:]
        sys.argv = [name]
        try:
            # Force reimport if already cached
            if name in sys.modules:
                del sys.modules[name]
            mod = importlib.import_module(name)
        except SystemExit:
            # Some modules call argparse at import level — catch the exit
            raise RuntimeError(f"Workflow '{name}' has module-level argparse that conflicts. Use direct import.")
        except ImportError as e:
            raise RuntimeError(f"Cannot import workflow '{name}': {e}")
        finally:
            sys.argv = original_argv
            # Remove the paths we added — WORKFLOW_DIR must not persist in sys.path
            # between calls. Only remove paths this call inserted to avoid clobbering
            # paths added by other threads or callers.
            for p in inserted:
                try:
                    sys.path.remove(p)
                except ValueError:
                    pass  # already removed (e.g. by a concurrent caller)

        # Find the run function — try multiple common entry point names
        run_fn = getattr(mod, "run", None)
        if run_fn is None:
            for fn_name in [f"run_{name}", "main", "run_pipeline", "run_scan",
                           "run_backup", "run_auto_loop", "run_full_cycle",
                           "check", "execute", "process", "start",
                           f"{name}_run", f"do_{name}"]:
                run_fn = getattr(mod, fn_name, None)
                if run_fn and callable(run_fn):
                    break

        if run_fn is None:
            raise RuntimeError(f"Workflow '{name}' has no run() function")

        # Execute — handle different function signatures gracefully
        import inspect
        sig = inspect.signature(run_fn)
        params = sig.parameters

        call_kwargs = dict(kwargs)
        if dry_run and "dry_run" in params:
            call_kwargs["dry_run"] = True
        if event_payload is not None and "event_payload" in params:
            call_kwargs["event_payload"] = event_payload

        # Only pass kwargs the function actually accepts
        if any(p.kind == inspect.Parameter.VAR_KEYWORD for p in params.values()):
            return run_fn(**call_kwargs)  # accepts **kwargs
        else:
            filtered = {k: v for k, v in call_kwargs.items() if k in params}
            return run_fn(**filtered)

    # ─── SelRoute v3 routing (optional, opt-in via v3_task_type) ─────────
    # When v3_task_type is set, route the workflow through agent_router BEFORE
    # the harness action runs. If the decision is "superworker" we replace the
    # workflow's normal run() with a call to superworker.invoke() that channels
    # the routed lens roster. record_outcome() is called after execute() so
    # SelRoute can learn from the quality_score the harness measures.
    route_decision = None
    if v3_task_type:
        try:
            from aibrain.core.agent_router import route as v3_route
            route_decision = v3_route(
                task_type=v3_task_type,
                task_description=name,
                actor=actor,
            )
            log.info(
                "Workflow '%s' routed via SelRoute v3: shape=%s model=%s reason=%s",
                name,
                route_decision.handler_shape,
                route_decision.model_recommendation,
                route_decision.routing_reason,
            )
        except Exception as e:
            log.warning(
                "v3 routing failed for '%s': %s — falling back to direct execution",
                name, e,
            )
            route_decision = None

    # If routed to SuperWorker, swap the workflow's action for an invoke() call.
    # The harness still runs the action through eval/audit/verify-and-followup;
    # only the action body changes.
    if route_decision and route_decision.handler_shape == "superworker":
        try:
            from aibrain.core.superworker import invoke as sw_invoke
            sw_task_type = v3_task_type
            sw_task = f"workflow.{name}"

            def _execute_via_superworker():
                sw_result = sw_invoke(task=sw_task, task_type=sw_task_type)
                # to_harness_dict returns the contract harness.py:318 reads
                # for self-reported _cost_cents + _model_used.
                return sw_result.to_harness_dict()

            log.info(
                "Workflow '%s' will execute via SuperWorker (lenses=%d)",
                name, len(route_decision.lens_set or []),
            )
            _execute_workflow = _execute_via_superworker
        except Exception as e:
            log.warning(
                "SuperWorker dispatch failed for '%s': %s — falling back to direct execution",
                name, e,
            )

    # Quality thresholds vary by task type — a deterministic workflow that pings
    # a URL has a different quality bar than a judgment workflow producing analysis.
    # The old hardcoded 0.3 applied the same (too-low) bar to everything.
    _QUALITY_THRESHOLDS = {
        "deterministic": 0.1,   # just needs to run without error
        "simple": 0.3,          # light formatting/parsing — current default
        "judgment": 0.5,        # requires meaningful output
        "complex": 0.6,         # high-stakes work
    }
    _workflow_quality_threshold = _QUALITY_THRESHOLDS.get(meta["task_type"], 0.3)

    # Per-workflow timeout: use registry value when present, else 300s default.
    _timeout_seconds = meta.get("timeout_seconds") or 300

    # Configure harness
    config = HarnessConfig(
        task_type=meta["task_type"],
        authority=meta["authority"],
        max_cost_cents=meta["max_cost"],
        timeout_seconds=_timeout_seconds,
        quality_threshold=_workflow_quality_threshold,
        max_retries=0,  # don't retry workflows automatically
        actor=actor,
        tags=[name, "workflow"] + (["authority_override"] if _authority_overridden else []),
        capabilities=meta.get("capabilities", []),  # declared capability requirements for authority gate
    )

    log.info("Running workflow '%s' through harness [type=%s, auth=%s]",
             name, meta["task_type"], meta["authority"])

    # ─── Write workflow_runs row (INSERT before, UPDATE after) ───────────────
    # The harness writes to execution_log only. workflow_runs is the per-workflow
    # run history table (read by the dashboard and scheduled_jobs history API).
    # This was the missing link: harness runs never populated workflow_runs.
    _wf_run_id: int | None = None
    _wf_run_start: float = 0.0
    try:
        import sqlite3
        import secrets
        import time as _time
        from aibrain_db import AIBRAIN_ROOT
        _wf_run_start = _time.monotonic()
        _wf_db_path = AIBRAIN_ROOT / "aibrain.db"
        _wf_conn = sqlite3.connect(str(_wf_db_path))
        _wf_conn.execute("PRAGMA journal_mode=WAL")
        try:
            _wf_trigger = "cron" if actor == "cron" else "manual"
            cur = _wf_conn.execute(
                "INSERT INTO workflow_runs (workflow_id, workflow_name, trigger_type, status) VALUES (?, ?, ?, 'running')",
                (secrets.token_urlsafe(8), name, _wf_trigger),
            )
            _wf_run_id = cur.lastrowid
            _wf_conn.commit()
        finally:
            _wf_conn.close()
    except Exception as _wf_err:
        log.warning("workflow_runs INSERT failed for '%s': %s", name, _wf_err)

    GREEN_THRESHOLD = 0.7
    attempts = 1 if not until_green else max(1, max_retries)

    result = None
    for attempt in range(1, attempts + 1):
        if until_green and attempt > 1:
            log.info("Workflow '%s' retry %d/%d (previous quality=%.2f)",
                     name, attempt, attempts, result.quality if result else 0.0)

        result = execute(
            task=f"workflow.{name}",
            action=_execute_workflow,
            config=config,
        )

        if result.success:
            _q_display = f"{result.quality:.2f}" if result.quality is not None else "unmeasurable"
            log.info("Workflow '%s' completed: quality=%s, duration=%dms",
                     name, _q_display, result.duration_ms)
        else:
            log.warning("Workflow '%s' failed: %s", name, result.error)

        if not until_green:
            break

        is_green = result.quality >= GREEN_THRESHOLD and result.success and not result.error
        if is_green:
            log.info("Workflow '%s' is green after %d attempt(s) (quality=%.2f)",
                     name, attempt, result.quality)
            break

        if attempt < attempts:
            log.info("Workflow '%s' not green yet (quality=%.2f, error=%s) — retrying...",
                     name, result.quality, result.error or "none")
    else:
        if until_green:
            log.warning("Workflow '%s' did not reach green after %d attempt(s) (final quality=%.2f)",
                        name, attempts, result.quality if result else 0.0)

    # ─── Update workflow_runs row with final status ───────────────────────────
    if _wf_run_id is not None and result is not None:
        try:
            import sqlite3 as _sqlite3
            from aibrain_db import AIBRAIN_ROOT as _AIBRAIN_ROOT
            _wf_status = "completed" if result.success else "failed"
            _wf_duration_s = round(result.duration_ms / 1000.0, 3) if result.duration_ms else None
            _wf_output = str(result.output)[:2000] if result.output is not None else None
            _wf_error = str(result.error)[:500] if result.error else None
            _wf_conn2 = _sqlite3.connect(str(_AIBRAIN_ROOT / "aibrain.db"))
            _wf_conn2.execute("PRAGMA journal_mode=WAL")
            try:
                _wf_conn2.execute(
                    "UPDATE workflow_runs SET status=?, completed_at=CURRENT_TIMESTAMP, duration_s=?, output_summary=?, error=? WHERE id=?",
                    (_wf_status, _wf_duration_s, _wf_output, _wf_error, _wf_run_id),
                )
                _wf_conn2.commit()
            finally:
                _wf_conn2.close()
            log.debug("workflow_runs row %d updated: status=%s duration_s=%s",
                      _wf_run_id, _wf_status, _wf_duration_s)
        except Exception as _wf_upd_err:
            log.warning("workflow_runs UPDATE failed for '%s' (row %s): %s",
                        name, _wf_run_id, _wf_upd_err)

    # ─── Route scheduled workflows through company task system for evolution_outcomes ────
    # Cron-triggered workflows are delegated work and should record quality/learning.
    # Manual/one-off runs skip this to avoid overhead.
    if actor == "cron" and result is not None:
        try:
            from aibrain.core.companies import create_task, checkout_task, complete_task, TaskReviewFailed
            task = create_task(
                company_id='GT_LRWrEBQQ',
                title=f"Scheduled: {name}",
                description=f"Automated workflow — {meta.get('task_type', 'judgment')} type",
                assignee_agent_id='5qbok8h7CIg',  # Neuro (CEO)
                priority='low',
            )
            checkout_task(task['id'], '5qbok8h7CIg')
            quality_str = f"{result.quality:.2f}" if result.quality is not None else "N/A"
            output_str = str(result.output)[:200] if result.output else "(none)"
            work_output = (
                f"Workflow: {name}\n"
                f"Status: {'completed' if result.success else 'failed'}\n"
                f"Quality: {quality_str}\n"
                f"Duration: {result.duration_ms}ms\n"
                f"Output: {output_str}"
            )
            complete_task(
                task['id'],
                work_output=work_output,
                quality_score=result.quality if result.quality is not None else 0.0
            )
            log.debug("Workflow '%s' routed through company task %s", name, task['id'])
        except TaskReviewFailed as _tre:
            log.warning("Workflow '%s' task review failed: %s", name, _tre)
        except Exception as _cte:
            log.warning("Workflow '%s' company task routing failed: %s", name, _cte)

    # Record SelRoute v3 outcome for the routing feedback loop.
    # Honest-rubric: record_outcome drops None-quality runs so unmeasured
    # outcomes don't pollute the learned routing preferences.
    # Synthesis rule: successful runs with no rubric signal get quality=0.6
    # (baseline "it worked without measurable quality") so routing has signal
    # to learn from. Only failed runs (result.success=False) stay as None.
    if route_decision is not None and result is not None:
        try:
            from aibrain.core.agent_router import record_outcome as v3_record
            _routing_quality = result.quality
            if _routing_quality is None and result.success:
                _routing_quality = 0.6  # baseline: completed without measurable quality
            v3_record(
                task_type=v3_task_type,
                handler_shape=route_decision.handler_shape,
                quality_score=_routing_quality,
                override_mode=route_decision.override_mode,
                duration_ms=result.duration_ms,
                actor=actor,
            )
        except Exception as e:
            log.warning("record_outcome failed for '%s': %s", name, e)

    # Log prediction accuracy (non-blocking, best-effort)
    try:
        from aibrain.core.state_predictor import predict_next, log_prediction_accuracy
        predictions = predict_next(n=3)
        if predictions:
            log_prediction_accuracy(predictions, name)
    except Exception:
        pass  # prediction logging is advisory, never breaks workflows

    # Emit WORKFLOW_EXECUTED event
    try:
        from aibrain.core.event_bus import emit as bus_emit, EventTypes
        bus_emit(EventTypes.WORKFLOW_EXECUTED, {
            "workflow": name,
            "success": result.success if result else False,
            "quality": result.quality if result else 0.0,
            "duration_ms": result.duration_ms if result else 0,
            "error": str(result.error) if result and result.error else None,
            "actor": actor,
        })
    except Exception:
        pass  # Event emission never blocks workflow execution

    return result


# ---------------------------------------------------------------------------
# Event-triggered workflow execution
# ---------------------------------------------------------------------------

# Maps event_type → list of (workflow_name, actor) to run when event fires
_event_triggers: dict[str, list[tuple[str, str]]] = {}
_triggers_registered: bool = False


def trigger_on_event(
    workflow_name: str,
    event_type: str,
    actor: str = "event_trigger",
) -> None:
    """Register a workflow to auto-run when an event fires.

    The workflow is executed through the harness (run_workflow) when
    the event bus emits the specified event type. The event payload
    is passed as a kwarg to the workflow if it accepts one.

    Args:
        workflow_name: Name of a workflow in WORKFLOW_REGISTRY.
        event_type: Event type string to listen for.
        actor: Actor label for audit trail (default: "event_trigger").

    Raises:
        ValueError: If workflow_name is not in WORKFLOW_REGISTRY.
    """
    if workflow_name not in WORKFLOW_REGISTRY:
        wf_path = WORKFLOW_DIR / f"{workflow_name}.py"
        if not wf_path.exists():
            raise ValueError(
                f"Unknown workflow: {workflow_name!r} — not in WORKFLOW_REGISTRY and "
                f"{wf_path} does not exist"
            )

    if event_type not in _event_triggers:
        _event_triggers[event_type] = []

    # Avoid duplicate registrations
    entry = (workflow_name, actor)
    if entry not in _event_triggers[event_type]:
        _event_triggers[event_type].append(entry)

        # Register a handler on the event bus for this event type
        _ensure_event_handler(event_type)

        log.info("Workflow '%s' will trigger on event '%s' (actor=%s)",
                 workflow_name, event_type, actor)


def untrigger_on_event(workflow_name: str, event_type: str) -> bool:
    """Remove an event trigger for a workflow.

    Returns True if a trigger was removed, False if not found.
    """
    entries = _event_triggers.get(event_type, [])
    original_len = len(entries)
    _event_triggers[event_type] = [
        (wf, act) for wf, act in entries if wf != workflow_name
    ]
    removed = len(_event_triggers[event_type]) < original_len
    # Clean up empty lists
    if not _event_triggers[event_type]:
        del _event_triggers[event_type]
    return removed


def get_event_triggers() -> dict[str, list[str]]:
    """Return a dict of event_type → list of workflow names."""
    return {
        event_type: [wf for wf, _actor in entries]
        for event_type, entries in _event_triggers.items()
    }


def clear_event_triggers() -> None:
    """Remove all event triggers. For testing."""
    _event_triggers.clear()


# Track which event types already have a bus handler to avoid double-registration
_registered_event_types: set[str] = set()


def _ensure_event_handler(event_type: str) -> None:
    """Register a single handler on the event bus for the given event type.

    The handler dispatches to all workflows registered for that event type.
    Only registers once per event type.
    """
    if event_type in _registered_event_types:
        return

    from aibrain.core.event_bus import on as bus_on

    def _dispatch(payload: dict, _et: str = event_type) -> None:
        """Dispatch event to all registered workflows for this event type.

        Each workflow is submitted to _dispatch_executor so the event bus
        handler returns immediately — no blocking the caller's thread for
        up to 300s (harness timeout).
        """
        entries = _event_triggers.get(_et, [])
        for workflow_name, actor in entries:
            log.info(
                "Event '%s' scheduling workflow '%s' on dispatch thread pool",
                _et, workflow_name,
            )
            _dispatch_executor.submit(
                run_workflow,
                workflow_name,
                actor=actor,
                event_payload=payload,
            )

    bus_on(event_type, _dispatch)
    _registered_event_types.add(event_type)


# ---------------------------------------------------------------------------
# Startup validation: warn if scheduled_jobs.json references workflow names
# not in WORKFLOW_REGISTRY. Prevents silent failures after registry gaps open.
# Runs at module import time. Never crashes startup — all exceptions swallowed.
# ---------------------------------------------------------------------------
try:
    import json as _json
    import os as _os
    _sj_path = (
        _os.path.join(_os.environ.get("DECKER_SYSTEM", ""), "04_tools", "scheduled_jobs.json")
    )
    if _os.path.isfile(_sj_path):
        with open(_sj_path, encoding="utf-8") as _sj_f:
            _sj_data = _json.load(_sj_f)
        _jobs = _sj_data if isinstance(_sj_data, list) else _sj_data.get("jobs", [])
        for _job in _jobs:
            _cmd = _job.get("command", "") or ""
            _wf_name = _job.get("workflow") or None
            if not _wf_name and "workflow_runner" in _cmd:
                # Extract workflow name from command strings like:
                #   python -m aibrain.core.workflow_runner heartbeat
                #   aibrain.core.workflow_runner heartbeat --dry-run
                import re as _re
                _m = _re.search(r'workflow_runner\s+([a-z][a-z0-9_]*)', _cmd)
                if _m:
                    _wf_name = _m.group(1)
            if _wf_name and _wf_name not in WORKFLOW_REGISTRY:
                log.warning(
                    "startup_check: scheduled job %r references workflow %r "
                    "which is NOT in WORKFLOW_REGISTRY — it will fail at runtime",
                    _job.get("name", _job.get("id", "?")), _wf_name,
                )
except Exception:
    pass  # startup check must never crash the module


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import argparse
    from aibrain.core.harness import Authority as _Authority

    # Authority values allowed from the CLI (admin is blocked — programmatic only)
    _CLI_BLOCKED_AUTHORITY = {_Authority.ADMIN}
    _CLI_VALID_AUTHORITY = [a for a in _Authority if a not in _CLI_BLOCKED_AUTHORITY]

    def _parse_authority(val: str) -> _Authority:
        """Argparse type= converter: string → Authority enum, blocking admin."""
        try:
            member = _Authority(val.lower())
        except ValueError:
            valid = [a.value for a in _CLI_VALID_AUTHORITY]
            raise argparse.ArgumentTypeError(
                f"Invalid authority: {val!r}. Valid values: {valid}"
            )
        if member in _CLI_BLOCKED_AUTHORITY:
            valid = [a.value for a in _CLI_VALID_AUTHORITY]
            raise argparse.ArgumentTypeError(
                f"Authority {val!r} is not permitted via CLI. Valid values: {valid}"
            )
        return member

    parser = argparse.ArgumentParser(description="Run workflow through harness")
    parser.add_argument("workflow", help="Workflow name (e.g. heartbeat, db_backup)")
    parser.add_argument("--dry-run", action="store_true", help="Preview mode")
    parser.add_argument("--actor", default="cli", help="Who initiated this")
    parser.add_argument("--authority", type=_parse_authority,
                        metavar="{" + ",".join(a.value for a in _CLI_VALID_AUTHORITY) + "}",
                        help="Override authority level. "
                             "admin authority requires programmatic invocation only — "
                             "CLI limited to: " + ", ".join(a.value for a in _CLI_VALID_AUTHORITY))
    parser.add_argument("--until-green", action="store_true",
                        help="Retry until quality >= 0.7 or max-retries reached")
    parser.add_argument("--max-retries", type=int, default=5,
                        help="Max retry attempts when --until-green is set (default 5)")
    parser.add_argument("--mode", default="execute",
                        choices=["execute", "plan", "clarify"],
                        help="execute (default), plan (preview), or clarify (show requirements)")
    parser.add_argument("--v3-task-type", default=None, dest="v3_task_type",
                        help="SelRoute v3 task category (e.g. code_review, security_review, polish_refine). "
                             "When set, the workflow is routed via agent_router and may dispatch to SuperWorker.")

    args, remaining = parser.parse_known_args()

    # Parse remaining args as --key value pairs to pass as workflow kwargs.
    # e.g. --target SuperLocalMemory --prompt "..." → {"target": "SuperLocalMemory", "prompt": "..."}
    workflow_kwargs: dict = {}
    i = 0
    while i < len(remaining):
        token = remaining[i]
        if token.startswith("--"):
            key = token[2:].replace("-", "_")
            if i + 1 < len(remaining) and not remaining[i + 1].startswith("--"):
                workflow_kwargs[key] = remaining[i + 1]
                i += 2
            else:
                workflow_kwargs[key] = True  # flag with no value
                i += 1
        else:
            i += 1  # skip bare positional tokens

    # Clear sys.argv BEFORE running workflow (prevents imported modules' argparse from firing)
    sys.argv = [sys.argv[0]]

    logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

    # plan/clarify modes print structured output without running harness
    if args.mode in ("plan", "clarify"):
        import json as _json
        fn = plan_workflow if args.mode == "plan" else clarify_workflow
        data = fn(args.workflow)
        print(_json.dumps(data, indent=2))
        sys.exit(0 if "error" not in data else 1)

    result = run_workflow(
        args.workflow,
        dry_run=args.dry_run,
        actor=args.actor,
        authority=args.authority.value if args.authority is not None else None,
        until_green=args.until_green,
        max_retries=args.max_retries,
        mode=args.mode,
        v3_task_type=args.v3_task_type,
        **workflow_kwargs,
    )

    # Honest-rubric: quality / model_used / duration_ms can legitimately be None
    # ("could not measure"). Handle each gracefully — never format None with :.2f.
    quality_str = f"{result.quality:.2f}" if result.quality is not None else "(unmeasurable)"
    model_str = result.model_used if result.model_used is not None else "(unknown)"
    duration_str = f"{result.duration_ms}ms" if result.duration_ms is not None else "(not recorded)"

    print(f"\n{'='*50}")
    print(f"Workflow: {args.workflow}")
    print(f"Success:  {result.success}")
    print(f"Quality:  {quality_str}")
    print(f"Model:    {model_str}")
    print(f"Duration: {duration_str}")
    print(f"Audit ID: {result.audit_id}")

    # Autoresearch metrics (Karpathy loop workflows)
    if result._autoresearch_metrics:
        metrics = result._autoresearch_metrics
        print("")
        print("Karpathy Loop Metrics:")
        print(f"  Baseline Score:  {metrics.get('baseline_score', 'N/A')}")
        print(f"  Best Score:      {metrics.get('best_score', 'N/A')}")
        print(f"  Iterations:      {metrics.get('iterations', 0)}")
        print(f"  Promoted:        {metrics.get('promoted', False)}")
        print(f"  State:           {metrics.get('state', 'unknown')}")

    if result.error:
        print(f"Error:    {result.error}")
    print(f"{'='*50}")
