"""
competitor_analysis.py — Targeted competitor analysis workflow.

Runs a focused intel_agent_v2 research sweep on a specific competitor target.
Accepts --target (name or URL) and an optional --prompt override.

Unlike the broad intel_agent_run sweep (which cycles through ~/.aibrain/intel_targets.json),
this workflow is for single-target deep dives — e.g. a biweekly SLM pivot watch.

The workflow:
1. Loads the target (from --target arg or COMPETITOR_ANALYSIS_TARGET env var)
2. Dispatches an intel research task via the company task system
3. Stores findings to memory as type='competitive_intel'
4. Sends a Telegram digest to Decker — with ESCALATE flag if substrate pivot detected

Usage:
    python -m aibrain.core.workflow_runner competitor_analysis
    python -m aibrain.core.workflow_runner competitor_analysis --target SuperLocalMemory
"""

import json
import logging
import os
from datetime import datetime, timezone
from pathlib import Path

from aibrain.core.circuit_breaker import telegram_call
from aibrain.core.workflow_base import workflow_execute

log = logging.getLogger("aibrain.competitor_analysis")

# Default escalation keywords — if any appear in findings, ESCALATE to Decker immediately
ESCALATION_KEYWORDS = [
    "substrate",
    "os-level",
    "kernel",
    "system memory",
    "category 3b",
    "3b",
    "pivot",
    "native integration",
    "v3.4",
    "v3.5",
    "v4.",
]


def run(target: str = None, prompt: str = None, **kwargs) -> dict:
    """
    Run a targeted competitor analysis sweep.

    Args:
        target: Competitor name or URL (e.g. "SuperLocalMemory" or "github.com/qualixar/superlocalmemory")
        prompt: Research prompt override. If None, uses default SLM pivot watch prompt.

    Returns:
        dict with keys: target, run_timestamp, findings, escalate, summary,
                        task_id, dispatch_id, status
    """
    def _action():
        return _run_analysis(target=target, prompt=prompt, **kwargs)

    result = workflow_execute("competitor_analysis", _action, task_type="judgment")
    # workflow_execute wraps the return value in HarnessResult — unwrap for callers
    # that expect the raw dict (e.g. workflow_runner, tests).
    if hasattr(result, "output") and isinstance(result.output, dict):
        return result.output
    return result


def _run_analysis(target: str = None, prompt: str = None, **kwargs) -> dict:
    """Internal implementation called via workflow_execute harness."""
    if target is None:
        target = os.environ.get("COMPETITOR_ANALYSIS_TARGET", "SuperLocalMemory")

    if prompt is None:
        prompt = (
            "Run competitor analysis on SuperLocalMemory (github.com/qualixar/superlocalmemory). "
            "Look for: new releases past v3.3, any pivot from sidecar memory (category 3a) toward "
            "substrate/OS-level integration (category 3b). "
            "If any substrate pivot signals found, ESCALATE immediately to Decker via Telegram. "
            "Otherwise include delta in weekly intel brief."
        )

    log.info("competitor_analysis: target=%s", target)

    run_ts = datetime.now(timezone.utc).isoformat()

    # Duplicate-spawn guard: skip if a pending/running company task already exists for
    # this target within the last 14 days.  Uses company_issues (the tasks table) because
    # execution_log rows don't carry the target name in a queryable column — only the
    # generic action string 'workflow.competitor_analysis'.
    try:
        from aibrain_db import get_db as _get_db
        _conn = _get_db()
        # Verify the expected columns exist before querying (schema drift safety).
        _cols = {row[1] for row in _conn.execute("PRAGMA table_info(company_issues)").fetchall()}
        if {"title", "status", "created_at"}.issubset(_cols):
            _row = _conn.execute(
                """SELECT id, created_at FROM company_issues
                   WHERE title LIKE ?
                     AND status IN ('todo', 'in_progress', 'backlog')
                     AND created_at > datetime('now', '-14 days')
                   LIMIT 1""",
                (f"%{target[:40]}%",),
            ).fetchone()
            if _row:
                _existing_task_id = _row[0]
                _since = _row[1]
                log.info(
                    "competitor_analysis: recent spawn pending for %s (task %s since %s), skipping duplicate",
                    target, _existing_task_id, _since,
                )
                return {
                    "target": target,
                    "run_timestamp": run_ts,
                    "findings": [],
                    "summary": f"Skipped — spawn already pending since {_since} (task {_existing_task_id})",
                    "escalate": False,
                    "status": "skipped_duplicate",
                    "task_id": _existing_task_id,
                    "dispatch_id": None,
                    "stub_output": True,
                }
        else:
            log.warning(
                "competitor_analysis: company_issues missing expected columns — "
                "skipping duplicate-spawn guard (found: %s)",
                sorted(_cols),
            )
    except Exception as _guard_err:
        log.warning(
            "competitor_analysis: duplicate-spawn guard failed (non-fatal, proceeding): %s",
            _guard_err,
        )

    # Wire to company task system + dispatch log so cron runs produce real audit signal.
    # Agent() spawns require Neuro's orchestration layer (Claude Code turn) — they cannot
    # run inside a Python function. This block does the two things that CAN happen here:
    #   1. Creates a company task so the work is tracked and routable
    #   2. Logs a dispatch record (execution_log row) so harness knows a spawn is pending
    # Neuro's next session reads pending tasks and spawns intel_agent_v2 to complete them.
    task_id = None
    dispatch_id = None
    try:
        from aibrain.core.companies import create_task, checkout_task
        from aibrain.core.agent_dispatch import dispatch_agent, build_agent_prompt

        # Competitive Intelligence Analyst (AQR2b6C2k6Q) owns this domain
        COMPANY_ID = "GT_LRWrEBQQ"
        ANALYST_AGENT_ID = "AQR2b6C2k6Q"

        task = create_task(
            company_id=COMPANY_ID,
            title=f"Competitor analysis: {target[:60]}",
            description=(
                f"Deep competitive intelligence sweep requested by cron workflow.\n\n"
                f"Target: {target}\n\n"
                f"Prompt:\n{prompt}\n\n"
                f"Deliver: findings list (signal/category/significance/source per entry), "
                f"summary, version_delta, category_delta. "
                f"Flag ESCALATE if any substrate pivot keyword detected: {', '.join(ESCALATION_KEYWORDS[:6])}..."
            ),
            assignee_agent_id=ANALYST_AGENT_ID,
            priority="medium",
            auto_route=False,
        )
        task_id = task["id"]
        checkout_task(task_id, ANALYST_AGENT_ID)

        full_prompt = build_agent_prompt(ANALYST_AGENT_ID, prompt)
        dispatch_info = dispatch_agent(
            task_id=task_id,
            prompt=full_prompt,
            actor="competitor_analysis_workflow",
            classification="judgment",
        )
        dispatch_id = dispatch_info["dispatch_id"]
        log.info("competitor_analysis: task_id=%s dispatch_id=%s", task_id, dispatch_id)
    except Exception as e:
        log.warning("competitor_analysis: task/dispatch wiring failed (non-fatal): %s", e)

    finding = {
        "target": target,
        "run_timestamp": run_ts,
        "prompt": prompt,
        "findings": [],          # populated by intel_agent_v2 subagent when Neuro spawns it
        "summary": (
            f"competitor_analysis queued for {target}. "
            f"Task {task_id or 'UNKNOWN'} dispatched to Competitive Intelligence Analyst. "
            "Neuro must spawn intel_agent_v2 subagent to complete the research."
        ),
        "escalate": False,       # set True if any substrate pivot signal detected in findings
        "threat_level": "unknown",
        "version_delta": None,   # e.g. "v3.3 -> v3.4" if new release found
        "category_delta": None,  # e.g. "3a -> 3b" if pivot detected
        "task_id": task_id,
        "dispatch_id": dispatch_id,
        "status": "pending_agent_spawn" if task_id else "dispatch_failed",
        # stub_output=True signals the harness to skip quality eval and learning
        # recording. This is a dispatch placeholder — no real analysis has run yet.
        "stub_output": True,
    }

    # Escalation check — scan findings for substrate pivot signals.
    # Only check actual findings list, NOT the summary string (which is always a stub
    # message and could false-positive on target names containing version-like patterns).
    if finding.get("findings"):
        all_text = json.dumps(finding["findings"]).lower()
        if any(kw in all_text for kw in ESCALATION_KEYWORDS):
            finding["escalate"] = True
            log.warning("competitor_analysis: ESCALATION triggered for %s", target)

    # Store to memory — only if findings are populated (non-stub run)
    if finding.get("findings"):
        _store_finding(finding)
    else:
        log.debug(
            "competitor_analysis: skipping memory write for %s — findings empty (status=%s)",
            target,
            finding.get("status"),
        )

    # Telegram dispatch
    _send_telegram(finding)

    return finding


def _store_finding(finding: dict) -> bool:
    """Store finding to aibrain memory as type='competitive_intel'.

    Returns False immediately (without DB write) if the finding is a stub —
    i.e. status=='pending_agent_spawn' or findings list is empty. Defense-in-depth
    guard so stub records never pollute the memories table even if the call-site
    guard in _run_analysis() is bypassed.
    """
    if finding.get("status") == "pending_agent_spawn" or finding.get("findings") == []:
        log.debug(
            "_store_finding: skipping stub for %s (status=%s, findings_count=%d)",
            finding.get("target"),
            finding.get("status"),
            len(finding.get("findings") or []),
        )
        return False
    try:
        from aibrain_db import get_db as _get_db
        content = json.dumps(finding, indent=2)
        source = finding.get("target", "unknown")
        ts = finding.get("run_timestamp", datetime.now(timezone.utc).isoformat())

        conn = _get_db()
        conn.execute(
            """INSERT INTO memories (name, type, content, source_agent, importance, created, updated, tags)
               VALUES (?, 'competitive_intel', ?, ?, 0.8, ?, ?, 'intel,competitive,slm_watch,automated')""",
            (source, content, source, ts, ts),
        )
        conn.commit()
        log.info("Stored competitor_analysis finding for %s", source)
        return True
    except Exception as e:
        log.warning("_store_finding failed for %s: %s", finding.get("target"), e)
        return False


def _send_telegram(finding: dict) -> bool:
    """Send Telegram digest. Escalates immediately if finding['escalate'] is True."""
    try:
        import requests

        token = os.environ.get("TELEGRAM_TOKEN")
        chat_id = os.environ.get("TELEGRAM_CHAT_ID", "-5288572284")
        if not token:
            log.warning("TELEGRAM_TOKEN not set — skipping Telegram dispatch")
            return False

        target = finding.get("target", "unknown")
        escalate = finding.get("escalate", False)
        summary = finding.get("summary", "")
        version_delta = finding.get("version_delta")
        category_delta = finding.get("category_delta")

        if escalate:
            header = f"ESCALATE — {target} SUBSTRATE PIVOT DETECTED"
            importance = "IMMEDIATE ACTION REQUIRED"
        else:
            header = f"SLM Watch — {target} biweekly check"
            importance = "No pivot signals found."

        lines = [
            f"*{header}*",
            f"Run: {finding.get('run_timestamp', '')[:19]}Z",
            f"Status: {importance}",
        ]
        if version_delta:
            lines.append(f"Version: {version_delta}")
        if category_delta:
            lines.append(f"Category pivot: {category_delta}")
        lines.append(f"Summary: {summary[:300]}")

        msg = "\n".join(lines)

        resp = telegram_call(
            requests.post,
            f"https://api.telegram.org/bot{token}/sendMessage",
            json={"chat_id": chat_id, "text": msg, "parse_mode": "Markdown"},
            timeout=10,
        )
        resp.raise_for_status()
        log.info("Telegram digest sent for %s (escalate=%s)", target, escalate)
        return True
    except Exception as e:
        log.warning("_send_telegram failed: %s", e)
        return False
