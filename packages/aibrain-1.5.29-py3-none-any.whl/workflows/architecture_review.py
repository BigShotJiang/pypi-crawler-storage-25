#!/usr/bin/env python3
"""AIBrain Workflow: Architecture Review — dispatches to Architecture & Performance Analyst.

Accepts an optional --target argument (path or description to review).
Creates a company task assigned to the Architecture & Performance Analyst
(BJAnXavx2Nk) via the DeckerOps company task system, then returns a
structured report.

Usage:
    python architecture_review.py                         # generic review
    python architecture_review.py --target aibrain/core  # review specific path
    python architecture_review.py --target "async worker concurrency"
"""

import argparse
import datetime
import json
import sys
from pathlib import Path

# P0-1: route workflow execution through the harness
from aibrain.core.workflow_base import workflow_execute

from aibrain_db import AIBRAIN_ROOT, get_db

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

COMPANY_ID = "GT_LRWrEBQQ"
ANALYST_AGENT_ID = "BJAnXavx2Nk"  # Architecture & Performance Analyst


# ---------------------------------------------------------------------------
# Core logic
# ---------------------------------------------------------------------------

def run(target: str = None) -> dict:
    """Dispatch an architecture review task and return a structured report.

    When called by the workflow_runner (cron path), execution is wrapped through
    the harness via workflow_execute so every invocation lands in execution_log.

    Args:
        target: Optional path or description of what to review.
                If None, a general architecture health review is requested.

    Returns:
        dict with keys: task_id, status, target, report_summary, created_at
    """
    def _action():
        return _run_review(target=target)

    result = workflow_execute("architecture_review", _action, task_type="judgment")
    if hasattr(result, "output") and isinstance(result.output, dict):
        return result.output
    return result


def _run_review(target: str = None) -> dict:
    """Internal implementation — called via workflow_execute harness."""
    now = datetime.datetime.now(datetime.timezone.utc).isoformat()
    target = target or "general AIBrain architecture health review"

    title = f"Architecture review: {target[:80]}"
    description = (
        f"Architecture & Performance review requested via workflow runner.\n\n"
        f"Target: {target}\n\n"
        f"Scope:\n"
        f"- asyncio patterns (deadlocks, event loop blocking, task leaks)\n"
        f"- worker pool sizing and concurrency limits\n"
        f"- database write patterns (batch vs serial, connection pooling, write amplification)\n"
        f"- memory management (object retention, large result sets)\n"
        f"- timeout handling completeness\n"
        f"- load behaviour under concurrent operations\n\n"
        f"Deliver: bottleneck list, architectural risks, specific fixes with before/after impact estimates."
    )

    # Create + checkout task via company system
    from aibrain.core.companies import create_task, checkout_task, complete_task

    task = create_task(
        company_id=COMPANY_ID,
        title=title,
        description=description,
        assignee_agent_id=ANALYST_AGENT_ID,
        priority="medium",
        auto_route=False,  # explicit assignee — no routing needed
    )
    task_id = task["id"]

    checkout_task(task_id, ANALYST_AGENT_ID)

    # The actual analysis work is done by the human/agent who picks up the task.
    # This workflow wires the task into the audit trail and returns the task ref
    # so it can be tracked via the dashboard and evolution_outcomes.
    report = {
        "task_id": task_id,
        "status": "dispatched",
        "target": target,
        "assignee": "Architecture & Performance Analyst",
        "assignee_id": ANALYST_AGENT_ID,
        "report_summary": (
            f"Architecture review task created and assigned to Architecture & Performance Analyst "
            f"(agent {ANALYST_AGENT_ID}). Task ID: {task_id}. "
            f"Track progress via the company dashboard at http://localhost:8001."
        ),
        "created_at": now,
    }

    # Persist report summary to memory for future reference
    try:
        db = get_db()
        content = json.dumps(report)
        mem_name = f"workflow_state:architecture_review:{task_id}"
        existing = db.execute(
            "SELECT id FROM memories WHERE name=? AND active=1", (mem_name,)
        ).fetchone()
        if existing:
            db.execute(
                "UPDATE memories SET content=?, updated=? WHERE id=?",
                (content, now, existing["id"]),
            )
        else:
            db.execute(
                "INSERT INTO memories (name, type, tags, content, created, updated, active) "
                "VALUES (?, ?, ?, ?, ?, ?, 1)",
                (mem_name, "reference", "workflow,architecture,review", content, now, now),
            )
        db.commit()
        db.close()
    except Exception as mem_err:
        print(f"  [warn] Memory store failed (non-fatal): {mem_err}", file=sys.stderr)

    print(f"Architecture review dispatched.")
    print(f"  Task ID : {task_id}")
    print(f"  Target  : {target}")
    print(f"  Assignee: Architecture & Performance Analyst ({ANALYST_AGENT_ID})")
    print(f"  Status  : {report['status']}")
    print(f"  Track   : http://localhost:8001")

    return report


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Dispatch an architecture review to the Architecture & Performance Analyst."
    )
    parser.add_argument(
        "--target",
        default=None,
        help="Path or description to review (default: general architecture health review)",
    )
    _args = parser.parse_args()
    # run() already routes through workflow_execute — call directly here
    run(target=_args.target)
