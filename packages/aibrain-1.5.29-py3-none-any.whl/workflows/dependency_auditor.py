#!/usr/bin/env python3
"""AIBrain Workflow: Dependency Auditor — scan project deps for vulnerabilities & updates."""

import argparse
import datetime
import json
import os
import re
import smtplib
import sqlite3
import subprocess
import sys
from email.mime.text import MIMEText
from pathlib import Path

import urllib.request

import requests

# P0-1 backfill (2026-04-11): route workflow execution through the harness
from aibrain.core.workflow_base import workflow_execute

from aibrain_db import AIBRAIN_ROOT, get_db
API_BASE = os.environ.get("AIBRAIN_API", os.environ.get("AIBRAIN_API", "http://localhost:8001/api/agent"))


def log_activity(action, detail="", status="ok"):
    """Log activity to AIBrain API."""
    try:
        data = json.dumps({
            "action": action, "category": "devops",
            "detail": detail, "status": status,
        }).encode()
        req = urllib.request.Request(
            f"{API_BASE}/activity", data=data,
            headers={"Content-Type": "application/json"},
        )
        urllib.request.urlopen(req, timeout=5)
    except Exception:
        pass
_cfg_path = AIBRAIN_ROOT / "config.json"
CONFIG = json.loads(_cfg_path.read_text()) if _cfg_path.exists() else {}
def _find_db():
    """Find best DB path, checking both new and legacy names."""
    for name in ["aibrain.db"]:
        p = AIBRAIN_ROOT / name
        if p.exists():
            return str(p)
    configured = CONFIG.get("db_path")
    if configured and Path(configured).exists():
        return configured
    mem_db = AIBRAIN_ROOT / "memory" / "memory.db"
    if mem_db.exists():
        return str(mem_db)
    return str(AIBRAIN_ROOT / "aibrain.db")

MEMORY_DB = CONFIG.get("db_path", _find_db())


def get_db():
    db = get_db()
    db.execute("PRAGMA journal_mode=wal")
    db.row_factory = sqlite3.Row
    return db

def load_state(name):
    try:
        db = get_db()
        row = db.execute("SELECT content FROM memories WHERE name=? AND active=1",
                         (f"workflow_state:{name}",)).fetchone()
        db.close()
        return json.loads(row["content"]) if row else {}
    except Exception:
        return {}

def save_state(name, state):
    db = get_db()
    try:
        now = datetime.datetime.now().isoformat()
        existing = db.execute("SELECT id FROM memories WHERE name=? AND active=1",
                             (f"workflow_state:{name}",)).fetchone()
        if existing:
            db.execute("UPDATE memories SET content=?, updated=? WHERE id=?",
                       (json.dumps(state), now, existing["id"]))
        else:
            db.execute("INSERT INTO memories (name,type,tags,content,created,updated,active) VALUES (?,?,?,?,?,?,1)",
                       (f"workflow_state:{name}", "reference", "workflow,state", json.dumps(state), now, now))
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()

def send_email(to, subject, body, dry_run=False):
    if dry_run:
        print(f"TO: {to}\nSUBJECT: {subject}\n\n{body}")
        return
    agent_email = CONFIG.get("agent_email", "aibrain@localhost")
    agent_password = CONFIG.get("agent_email_password", CONFIG.get("email_app_password", ""))
    msg = MIMEText(body, "plain")
    msg["From"] = agent_email
    msg["To"] = to
    msg["Subject"] = subject
    with smtplib.SMTP_SSL(CONFIG.get("agent_smtp_host", CONFIG.get("email_smtp_host", "smtp.gmail.com")), 465) as s:
        s.login(agent_email, agent_password)
        s.send_message(msg)


def parse_requirements(path):
    """Parse requirements.txt or pyproject.toml for dependencies."""
    deps = []
    p = Path(path)
    if not p.exists():
        return deps

    if p.name == "requirements.txt":
        for line in p.read_text().splitlines():
            line = line.strip()
            if line and not line.startswith("#"):
                match = re.match(r"([\w-]+)", line)
                if match:
                    deps.append({"name": match.group(1), "source": str(p)})

    elif p.name == "package.json":
        try:
            data = json.loads(p.read_text())
            for section in ["dependencies", "devDependencies"]:
                for name in data.get(section, {}):
                    deps.append({"name": name, "source": str(p), "type": "npm"})
        except Exception:
            pass

    return deps


def check_pypi_version(package_name):
    """Check latest version on PyPI."""
    try:
        resp = requests.get(f"https://pypi.org/pypi/{package_name}/json", timeout=5)
        if resp.status_code == 200:
            data = resp.json()
            return {
                "latest": data["info"]["version"],
                "summary": data["info"].get("summary", ""),
                "home_page": data["info"].get("home_page", ""),
            }
    except Exception:
        pass
    return None


def check_npm_version(package_name):
    """Check latest version on npm."""
    try:
        resp = requests.get(f"https://registry.npmjs.org/{package_name}/latest", timeout=5)
        if resp.status_code == 200:
            data = resp.json()
            return {"latest": data.get("version", "unknown")}
    except Exception:
        pass
    return None


def scan_project(project_path):
    """Scan a project directory for dependency files."""
    p = Path(project_path)
    dep_files = []
    for name in ["requirements.txt", "package.json"]:
        found = list(p.rglob(name))
        # Skip node_modules and venv
        for f in found:
            if "node_modules" not in str(f) and ".venv" not in str(f) and "venv" not in str(f):
                dep_files.append(f)
    return dep_files


def format_report(results):
    lines = [
        f"DEPENDENCY AUDIT — {datetime.datetime.now().strftime('%A %B %d, %Y')}",
        f"Scanned: {len(results)} dependencies",
        "=" * 50,
        "",
    ]

    outdated = [r for r in results if r.get("outdated")]
    if outdated:
        lines.append(f"OUTDATED ({len(outdated)})")
        for r in outdated:
            lines.append(f"  {r['name']:25s} installed: {r.get('installed', '?'):10s} latest: {r.get('latest', '?')}")
        lines.append("")

    current = [r for r in results if not r.get("outdated") and r.get("latest")]
    if current:
        lines.append(f"UP TO DATE ({len(current)})")
        for r in current:
            lines.append(f"  {r['name']:25s} {r.get('latest', '?')}")
        lines.append("")

    unknown = [r for r in results if not r.get("latest")]
    if unknown:
        lines.append(f"COULD NOT CHECK ({len(unknown)})")
        for r in unknown:
            lines.append(f"  {r['name']}")
        lines.append("")

    lines.append("—\nPowered by AIBrain")
    return "\n".join(lines), len(outdated)


def main():
    parser = argparse.ArgumentParser(description="AIBrain Dependency Auditor")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--path", default=str(AIBRAIN_ROOT), help="Project path to scan")
    args = parser.parse_args()

    email_to = CONFIG.get("email_to", CONFIG.get("agent_email", ""))
    project_path = args.path

    print(f"Scanning {project_path}...")
    dep_files = scan_project(project_path)
    print(f"Found {len(dep_files)} dependency files")

    all_deps = []
    for f in dep_files:
        all_deps.extend(parse_requirements(f))

    # Deduplicate
    seen = set()
    unique_deps = []
    for d in all_deps:
        if d["name"] not in seen:
            seen.add(d["name"])
            unique_deps.append(d)

    print(f"Checking {len(unique_deps)} packages...")
    results = []
    for dep in unique_deps:
        pkg_type = dep.get("type", "pypi")
        if pkg_type == "npm":
            info = check_npm_version(dep["name"])
        else:
            info = check_pypi_version(dep["name"])

        result = {"name": dep["name"], "source": dep.get("source", "")}
        if info:
            result["latest"] = info.get("latest", "")
            # For simplicity, mark as potentially outdated if we can't compare versions
            result["outdated"] = False  # Would need installed version to compare
        results.append(result)

    report, outdated_count = format_report(results)

    if not email_to or args.dry_run:
        print(report)
    elif outdated_count > 0:
        # Only email when there are actual outdated/vulnerable packages — suppress clean-run noise
        prefix = f"[{outdated_count} OUTDATED] "
        send_email(email_to, f"{prefix}Dependency Audit — {len(results)} packages", report)
    else:
        # Clean run — log locally only
        print(f"  All {len(results)} packages up to date — skipping email")
        print(report)

    save_state("dependency_auditor", {
        "last_run": datetime.datetime.now().isoformat(),
        "packages_checked": len(results),
        "outdated": outdated_count,
    })

    log_activity(
        "dependency_audit",
        f"{len(results)} packages checked, {outdated_count} outdated",
        "warning" if outdated_count > 0 else "ok",
    )


if __name__ == "__main__":
    # P0-1 backfill: entry point routes through harness via workflow_execute
    def _workflow_entry():
        main()
    workflow_execute(
        workflow_name='dependency_auditor',
        action=_workflow_entry,
        task_type='simple',
        actor='cli',
    )
