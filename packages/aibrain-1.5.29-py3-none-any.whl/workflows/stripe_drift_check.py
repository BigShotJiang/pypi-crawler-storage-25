"""
Stripe Drift Check — weekly config integrity monitor.

Pulls current Stripe dashboard state via API and compares against the
canonical stripe_config.md. If drift is detected (webhook URL changed,
canonical price deactivated, product deactivated, unexpected new active
product) it sends a Telegram alert with the specific diff.

Usage:
    python -m aibrain.core.workflow_runner stripe_drift_check
    python workflows/stripe_drift_check.py --dry-run
    python workflows/stripe_drift_check.py --verbose

Checks performed:
    1. Webhook URL, status, and enabled events match stripe_config.md
    2. All canonical AIBrain price IDs are still active
    3. All canonical active AIBrain product IDs are still active
    4. No unexpected new active products with metadata.app=aibrain appear
"""

import argparse
import json
import os
import sys
import threading
import urllib.request
import urllib.error
from datetime import datetime, timezone
from pathlib import Path

from aibrain.core.workflow_base import workflow_execute

# ---------------------------------------------------------------------------
# Paths & constants
# ---------------------------------------------------------------------------

SCRIPT_DIR = Path(__file__).parent
AIBRAIN_ROOT = SCRIPT_DIR.parent
CONFIG_MD = AIBRAIN_ROOT / "workers" / "stripe_config.md"

# Canonical anchors extracted from stripe_config.md Drift Check Anchors section.
# Update stripe_config.md AND these constants together when config changes.

CANONICAL_WEBHOOK_URL = "https://myaibrain.org/api/webhooks/stripe"
CANONICAL_WEBHOOK_EVENTS = ["checkout.session.completed"]
CANONICAL_WEBHOOK_STATUS = "enabled"

# Active canonical AIBrain product IDs (the v2 canonical set, not the v1 dupes)
CANONICAL_AIBRAIN_PRODUCT_IDS = {
    "prod_UFUdnVrRHoctzI",  # Pro (canonical)
    "prod_UFUWNQvXeW5XGZ",  # Team (canonical)
    "prod_UGaMgQP8Vvkyiu",  # Enterprise (canonical)
}

# All six canonical price IDs from env vars (must stay active)
CANONICAL_PRICE_IDS = {
    "price_1TGzsAJxa7SDFzOyjwWhSbiH",  # Pro monthly $9.95
    "price_1TJxjHJxa7SDFzOyXiUdTcAU",  # Pro yearly $99.50
    "price_1TGzXVJxa7SDFzOygFQ8APWO",  # Team monthly $29.95
    "price_1TJxjHJxa7SDFzOy27GJjX7x",  # Team yearly $299.50
    "price_1TI3BjJxa7SDFzOyaqm2EWmC",  # Enterprise monthly $99.00
    "price_1TI3BkJxa7SDFzOycpu7AJNG",  # Enterprise yearly $990.00
}

# ---------------------------------------------------------------------------
# Env loading
# ---------------------------------------------------------------------------


def _load_decker_env() -> None:
    """Populate os.environ from ~/.decker_env if keys are missing."""
    _env = Path.home() / ".decker_env"
    if not _env.exists():
        return
    try:
        for _line in _env.read_text(encoding="utf-8", errors="replace").splitlines():
            _line = _line.strip()
            if _line and not _line.startswith("#") and "=" in _line:
                k, v = _line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip().strip("'\""))
    except Exception:
        pass


_load_decker_env()

STRIPE_SECRET_KEY = os.environ.get("STRIPE_SECRET_KEY", "")
TELEGRAM_BOT_TOKEN = (
    os.environ.get("TELEGRAM_TOKEN")
    or os.environ.get("TELEGRAM_BOT_TOKEN")
    or ""
)
TELEGRAM_CHAT_ID = os.environ.get("TELEGRAM_CHAT_ID", "-5288572284")

# ---------------------------------------------------------------------------
# Stripe API helpers
# ---------------------------------------------------------------------------


def _stripe_get(path: str) -> dict:
    """GET from Stripe API with basic auth. Returns parsed JSON."""
    if not STRIPE_SECRET_KEY:
        raise RuntimeError("STRIPE_SECRET_KEY not set — cannot query Stripe API")

    url = f"https://api.stripe.com{path}"
    import base64
    creds = base64.b64encode(f"{STRIPE_SECRET_KEY}:".encode()).decode()
    req = urllib.request.Request(
        url,
        headers={"Authorization": f"Basic {creds}"},
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            return json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        body = e.read().decode(errors="replace")
        raise RuntimeError(f"Stripe API error {e.code} for {path}: {body}") from e


def _stripe_list_all(path: str) -> list:
    """Paginate through a Stripe list endpoint and return all items."""
    items = []
    url_path = f"{path}?limit=100"
    while True:
        data = _stripe_get(url_path)
        items.extend(data.get("data", []))
        if not data.get("has_more"):
            break
        last_id = items[-1]["id"]
        url_path = f"{path}?limit=100&starting_after={last_id}"
    return items


# ---------------------------------------------------------------------------
# Drift checks
# ---------------------------------------------------------------------------


def check_webhooks() -> list[str]:
    """Return list of drift messages for webhook endpoints."""
    drifts = []
    webhooks = _stripe_list_all("/v1/webhook_endpoints")

    # Find our known webhook
    known = next((w for w in webhooks if w["id"] == "we_1TGzfEJxa7SDFzOyWaISZ5xp"), None)
    if known is None:
        # Check if it exists under a different ID at the same URL
        url_match = next((w for w in webhooks if w.get("url") == CANONICAL_WEBHOOK_URL), None)
        if url_match:
            drifts.append(
                f"WEBHOOK ID CHANGED: expected we_1TGzfEJxa7SDFzOyWaISZ5xp, "
                f"found {url_match['id']} at same URL"
            )
        else:
            drifts.append(
                f"WEBHOOK MISSING: no endpoint found at {CANONICAL_WEBHOOK_URL}"
            )
        return drifts

    if known.get("url") != CANONICAL_WEBHOOK_URL:
        drifts.append(
            f"WEBHOOK URL: expected {CANONICAL_WEBHOOK_URL!r}, "
            f"got {known.get('url')!r}"
        )

    if known.get("status") != CANONICAL_WEBHOOK_STATUS:
        drifts.append(
            f"WEBHOOK STATUS: expected {CANONICAL_WEBHOOK_STATUS!r}, "
            f"got {known.get('status')!r}"
        )

    live_events = sorted(known.get("enabled_events", []))
    expected_events = sorted(CANONICAL_WEBHOOK_EVENTS)
    if live_events != expected_events:
        drifts.append(
            f"WEBHOOK EVENTS: expected {expected_events}, got {live_events}"
        )

    return drifts


def check_products() -> list[str]:
    """Return drift messages for AIBrain products."""
    drifts = []
    products = _stripe_list_all("/v1/products")

    # Check canonical products are still active
    by_id = {p["id"]: p for p in products}
    for pid in CANONICAL_AIBRAIN_PRODUCT_IDS:
        prod = by_id.get(pid)
        if prod is None:
            drifts.append(f"PRODUCT MISSING: {pid} not found in Stripe")
        elif not prod.get("active"):
            drifts.append(
                f"PRODUCT DEACTIVATED: {pid} ({prod.get('name')}) is no longer active"
            )

    # Detect unexpected new active AIBrain products (not in our canonical set)
    known_aibrain_ids = CANONICAL_AIBRAIN_PRODUCT_IDS | {
        # Known inactive/legacy IDs — not expected to be active but not alarming
        "prod_UGaM6hcHDxqPz6",  # Pro v1
        "prod_UGaMQCIetRz9XR",  # Team v1
        "prod_UG4908AMZ9Gbas",  # Enterprise v1 (duplicate)
        "prod_UFUd09LN3PGOob",  # Team old
        "prod_UFUWz9kYpJq6uC",  # Pro old
    }
    for prod in products:
        meta = prod.get("metadata", {})
        if meta.get("app") == "aibrain" and prod.get("active") and prod["id"] not in known_aibrain_ids:
            drifts.append(
                f"UNEXPECTED ACTIVE PRODUCT: {prod['id']} ({prod.get('name')}) "
                f"has metadata.app=aibrain but is not in canonical set"
            )

    return drifts


def check_prices() -> list[str]:
    """Return drift messages for canonical price IDs."""
    drifts = []
    prices = _stripe_list_all("/v1/prices")
    by_id = {p["id"]: p for p in prices}

    for pid in CANONICAL_PRICE_IDS:
        price = by_id.get(pid)
        if price is None:
            drifts.append(f"PRICE MISSING: {pid} not found in Stripe")
        elif not price.get("active"):
            product_id = price.get("product", "?")
            amount = price.get("unit_amount", 0)
            interval = (price.get("recurring") or {}).get("interval", "one_time")
            drifts.append(
                f"PRICE DEACTIVATED: {pid} (product={product_id}, "
                f"${amount/100:.2f}/{interval}) is no longer active"
            )

    return drifts


# ---------------------------------------------------------------------------
# Persistence
# ---------------------------------------------------------------------------


def _store_result(result: dict) -> bool:
    """Store drift check result to aibrain memories DB as type='stripe_drift_check'."""
    try:
        from aibrain_db import get_db as _get_db
        content = json.dumps(result, indent=2)
        ts = datetime.now(timezone.utc).isoformat()
        name = f"stripe_drift_check_{result.get('timestamp', ts)}"

        conn = _get_db()
        conn.execute(
            """INSERT INTO memories (name, type, content, source_agent, importance, created, updated, tags)
               VALUES (?, 'stripe_drift_check', ?, 'stripe_drift_check', 0.9, ?, ?, 'stripe,drift,financial,automated')""",
            (name, content, ts, ts),
        )
        conn.commit()
        return True
    except Exception:
        return False


# ---------------------------------------------------------------------------
# Telegram
# ---------------------------------------------------------------------------


def _send_telegram(message: str) -> None:
    """Send Telegram message to Decker group. Fire-and-forget daemon thread."""
    token = TELEGRAM_BOT_TOKEN
    if not token:
        return

    def _send():
        url = f"https://api.telegram.org/bot{token}/sendMessage"
        data = json.dumps({
            "chat_id": TELEGRAM_CHAT_ID,
            "text": message,
            "parse_mode": "HTML",
        }).encode()
        req = urllib.request.Request(
            url, data=data, headers={"Content-Type": "application/json"}
        )
        try:
            urllib.request.urlopen(req, timeout=10)
        except Exception:
            pass

    t = threading.Thread(target=_send, daemon=True)
    t.start()
    t.join(timeout=12)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def run(dry_run: bool = False, verbose: bool = False) -> dict:
    """Run all drift checks. Returns dict with drift list and clean flag."""
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    all_drifts: list[str] = []

    try:
        webhook_drifts = check_webhooks()
    except Exception as e:
        webhook_drifts = [f"WEBHOOK CHECK ERROR: {e}"]

    try:
        product_drifts = check_products()
    except Exception as e:
        product_drifts = [f"PRODUCT CHECK ERROR: {e}"]

    try:
        price_drifts = check_prices()
    except Exception as e:
        price_drifts = [f"PRICE CHECK ERROR: {e}"]

    all_drifts = webhook_drifts + product_drifts + price_drifts

    result = {
        "timestamp": now,
        "clean": len(all_drifts) == 0,
        "drift_count": len(all_drifts),
        "drifts": all_drifts,
    }

    _store_result(result)

    if verbose:
        print(f"STRIPE DRIFT CHECK — {now}")
        if all_drifts:
            print(f"  {len(all_drifts)} drift(s) detected:")
            for d in all_drifts:
                print(f"    - {d}")
        else:
            print("  Clean — no drift detected")

    if all_drifts and not dry_run:
        drift_lines = "\n".join(f"  • {d}" for d in all_drifts)
        msg = (
            f"<b>STRIPE DRIFT DETECTED</b> — {now}\n"
            f"{len(all_drifts)} issue(s) found:\n\n"
            f"{drift_lines}\n\n"
            f"Update <code>workers/stripe_config.md</code> if this is intentional."
        )
        _send_telegram(msg)

    elif not all_drifts and verbose:
        print("  No Telegram alert sent (clean run)")

    return result


if __name__ == "__main__":
    def _workflow_entry():
        parser = argparse.ArgumentParser(
            description="Stripe Drift Check — weekly config integrity monitor"
        )
        parser.add_argument("--dry-run", action="store_true",
                            help="Run checks but do not send Telegram alert")
        parser.add_argument("--verbose", "-v", action="store_true",
                            help="Print detailed output")
        args = parser.parse_args()

        if args.dry_run:
            args.verbose = True

        result = run(dry_run=args.dry_run, verbose=args.verbose)

        if not args.verbose:
            status = "CLEAN" if result["clean"] else f"{result['drift_count']} DRIFTS"
            print(f"[stripe_drift_check] {status}")

        sys.exit(0 if result["clean"] else 1)

    workflow_execute(
        workflow_name="stripe_drift_check",
        action=_workflow_entry,
        task_type="deterministic",
        actor="cli",
    )
