"""
retrolearn — backfill evolution_outcomes from unlinked honest execution_log rows.

Reads execution_log rows that have quality_score set but no entity_id linkage
(post-Apr-10 rows only, since pre-Apr-10 evo metrics are unreliable due to the
split-brain incident). Creates corresponding evolution_outcomes entries so the
learning loop has signal from historical executions.

Idempotent — safe to re-run. Skips rows already linked in evolution_outcomes
(matched by source_id = execution_log.run_id).

No LLM calls. Pure DB reads + writes.

Usage:
    python -m aibrain.core.workflow_runner retrolearn
    python workflows/retrolearn.py [--dry-run] [--verbose]
"""

import argparse
import json
import logging
import sqlite3
import sys
from datetime import datetime, timezone
from pathlib import Path

# Resolve DB path the same way as other workflows
sys.path.insert(0, str(Path(__file__).parent.parent))
from aibrain_db import AIBRAIN_ROOT, get_db
from aibrain.core.workflow_base import workflow_execute

log = logging.getLogger(__name__)


def _get_db_path() -> str:
    p = AIBRAIN_ROOT / "aibrain.db"
    if p.exists():
        return str(p)
    return str(AIBRAIN_ROOT / "aibrain.db")


def run(dry_run: bool = False, verbose: bool = False) -> dict:
    """
    Backfill evolution_outcomes from unlinked execution_log rows.

    Returns:
        {"backfilled": N, "skipped": N, "errors": N}
    """
    def _action():
        return _run_backfill(dry_run=dry_run, verbose=verbose)

    result = workflow_execute("retrolearn", _action, task_type="deterministic")
    if hasattr(result, "output") and isinstance(result.output, dict):
        return result.output
    return result


def _run_backfill(dry_run: bool = False, verbose: bool = False) -> dict:
    db_path = _get_db_path()
    db = sqlite3.connect(db_path)
    db.execute("PRAGMA journal_mode=WAL")
    db.row_factory = sqlite3.Row

    try:
        # Ensure evolution_outcomes table exists (harness creates it, but be safe)
        db.execute("""
            CREATE TABLE IF NOT EXISTS evolution_outcomes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source TEXT, source_id TEXT, action TEXT,
                result TEXT, details TEXT, failure_reason TEXT,
                duration_seconds REAL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # Find execution_log rows post-Apr-10 with quality_score but no entity_id
        # that haven't already been backfilled (no matching source_id in evolution_outcomes)
        candidates = db.execute("""
            SELECT el.run_id, el.actor, el.action, el.quality_score,
                   el.task_type, el.success, el.error, el.duration_ms,
                   el.model_used, el.cost_cents, el.authority
            FROM execution_log el
            WHERE el.quality_score IS NOT NULL
              AND (el.entity_id IS NULL OR el.entity_id = '')
              AND el.created_at >= '2026-04-10'
              AND el.run_id NOT IN (
                  SELECT source_id FROM evolution_outcomes
                  WHERE source_id IS NOT NULL
              )
            ORDER BY el.created_at ASC
        """).fetchall()

        backfilled = 0
        skipped = 0
        errors = 0

        for row in candidates:
            try:
                quality = row["quality_score"]
                success = bool(row["success"])
                error_msg = row["error"]

                # Classify outcome using same logic as harness
                failure_reason = None
                if not success:
                    outcome = "failure"
                    failure_reason = (error_msg or "execution failed")[:500]
                elif quality is None:
                    outcome = "no_signal"
                    failure_reason = "rubric could not measure"
                elif quality >= 0.8:
                    outcome = "succeeded"
                elif quality >= 0.5:
                    outcome = "partial"
                    failure_reason = f"quality {quality:.2f} in partial band (0.5-0.8)"
                else:
                    outcome = "flagged"
                    failure_reason = f"quality {quality:.2f} below threshold 0.5"

                details = json.dumps({
                    "quality": quality,
                    "model_used": row["model_used"],
                    "cost_cents": row["cost_cents"],
                    "task_type": row["task_type"],
                    "authority": row["authority"],
                    "retrolearn": True,  # tag so it's distinguishable from live records
                })

                duration_s = (row["duration_ms"] or 0) / 1000.0
                action = row["action"] or row["actor"] or "unknown"
                source = f"retrolearn:{row['task_type'] or 'unknown'}"

                if verbose:
                    print(f"  backfill run_id={row['run_id']} action={action} outcome={outcome}")

                if not dry_run:
                    db.execute("""
                        INSERT INTO evolution_outcomes
                            (source, source_id, action, result, details, failure_reason, duration_seconds)
                        VALUES (?, ?, ?, ?, ?, ?, ?)
                    """, [source, row["run_id"], action, outcome, details, failure_reason, duration_s])
                backfilled += 1

            except Exception as e:
                log.warning("retrolearn: error on run_id=%s: %s", row["run_id"] if row else "?", e)
                errors += 1
                skipped += 1

        if not dry_run:
            db.commit()

        summary = {
            "backfilled": backfilled,
            "skipped": skipped,
            "errors": errors,
            "dry_run": dry_run,
        }
        if verbose or dry_run:
            prefix = "[DRY RUN] " if dry_run else ""
            print(f"{prefix}retrolearn: {backfilled} backfilled, {skipped} skipped, {errors} errors")

        return summary

    finally:
        db.close()


def main() -> None:
    parser = argparse.ArgumentParser(description="Backfill evolution_outcomes from execution_log")
    parser.add_argument("--dry-run", action="store_true", help="Show what would be backfilled without writing")
    parser.add_argument("--verbose", action="store_true", help="Print each backfilled row")
    args = parser.parse_args()

    logging.basicConfig(level=logging.WARNING, format="%(levelname)s %(message)s")
    result = _run_backfill(dry_run=args.dry_run, verbose=args.verbose)
    if result.get("errors"):
        sys.exit(1)


if __name__ == "__main__":
    main()
