"""
mckee_run.py — Generalized McKee gate runner.

Launched as a detached Windows process (Start-Process) so it survives
session death. Runs run_mckee_gate() directly as a Python function call
(no sub-agent, no extra spawning).

Usage:
    python mckee_run.py <candidate_md_path> [--mckee-set <jsonl_path>] [--task-id <company_task_id>]

Defaults:
    research_dir  = <aibrain_root>/research/special_liaison/
    baseline      = <research_dir>/baseline.md
    mckee-set     = generated fresh if not provided

On PASS:
    - copies candidate -> baseline.md
    - appends PROMOTED entry to hypothesis_queue.md
    - git add + commit + push

On FAIL:
    - appends REVERTED_OVERFIT entry to hypothesis_queue.md

Always:
    - sends Telegram to -5288572284
    - if --task-id given, calls complete_task(task_id)
    - writes all output to C:/Users/sinde/tmp/mckee_run_<timestamp>.log
"""
import argparse
import json
import os
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

from aibrain.core.workflow_base import workflow_execute

# ── Anchor paths ─────────────────────────────────────────────────────────────
AIBRAIN_DIR = Path(r"C:\Users\sinde\projects\aibrain")
DECKER_ENV = Path.home() / ".decker_env"
TELEGRAM_CHAT_ID = "-5288572284"

DEFAULT_RESEARCH_DIR = AIBRAIN_DIR / "research" / "special_liaison"
DEFAULT_BASELINE = DEFAULT_RESEARCH_DIR / "baseline.md"
DEFAULT_HYPOTHESIS_QUEUE = DEFAULT_RESEARCH_DIR / "hypothesis_queue.md"

LOG_DIR = Path(r"C:\Users\sinde\tmp")


# ── Logging ───────────────────────────────────────────────────────────────────
_log_path: Path | None = None


def _init_log(timestamp: str) -> Path:
    global _log_path
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    _log_path = LOG_DIR / f"mckee_run_{timestamp}.log"
    return _log_path


def log(msg: str) -> None:
    ts = datetime.now().strftime("%H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line, flush=True)
    if _log_path is not None:
        with _log_path.open("a", encoding="utf-8") as f:
            f.write(line + "\n")


# ── Environment ───────────────────────────────────────────────────────────────
def load_decker_env() -> None:
    if not DECKER_ENV.exists():
        return
    for line in DECKER_ENV.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("export "):
            line = line[7:]
        if "=" in line:
            k, v = line.split("=", 1)
            v = v.strip().strip('"').strip("'")
            os.environ.setdefault(k.strip(), v)


# ── Telegram ──────────────────────────────────────────────────────────────────
def send_telegram(token: str, chat_id: str, text: str) -> bool:
    import urllib.parse
    import urllib.request

    url = f"https://api.telegram.org/bot{token}/sendMessage"
    data = urllib.parse.urlencode({"chat_id": chat_id, "text": text}).encode()
    try:
        with urllib.request.urlopen(url, data=data, timeout=15) as r:
            resp = json.loads(r.read())
            return resp.get("ok", False)
    except Exception as e:
        log(f"Telegram error: {e}")
        return False


# ── Git ───────────────────────────────────────────────────────────────────────
def git_commit_push(files: list[Path], message: str) -> bool:
    """Stage specific files, commit, and push. No Co-Authored-By."""
    try:
        str_files = [str(f) for f in files]
        subprocess.run(
            ["git", "add"] + str_files,
            cwd=AIBRAIN_DIR, check=True, capture_output=True,
        )
        subprocess.run(
            ["git", "commit", "-m", message],
            cwd=AIBRAIN_DIR, check=True, capture_output=True,
        )
        subprocess.run(
            ["git", "push"],
            cwd=AIBRAIN_DIR, check=True, capture_output=True,
        )
        return True
    except subprocess.CalledProcessError as e:
        stderr = e.stderr.decode(errors="replace") if e.stderr else str(e)
        log(f"Git error: {stderr}")
        return False


# ── Company task ───────────────────────────────────────────────────────────────
def complete_company_task(task_id: str, work_output: str) -> None:
    try:
        sys.path.insert(0, str(AIBRAIN_DIR))
        os.chdir(str(AIBRAIN_DIR))
        from aibrain.core.companies import complete_task
        complete_task(task_id, work_output=work_output)
        log(f"complete_task({task_id}) succeeded")
    except Exception as e:
        log(f"complete_task({task_id}) error: {e}")


# ── Main ──────────────────────────────────────────────────────────────────────
def main() -> None:
    parser = argparse.ArgumentParser(description="Generalized McKee gate runner")
    parser.add_argument("candidate", help="Path to candidate .md file")
    parser.add_argument("--mckee-set", dest="mckee_set", default=None,
                        help="Path to existing .jsonl question set (generates new one if omitted)")
    parser.add_argument("--task-id", dest="task_id", default=None,
                        help="DeckerOps company task ID to complete when done")
    args = parser.parse_args()

    # Init log
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_path = _init_log(timestamp)

    log("mckee_run.py starting")
    log(f"Log: {log_path}")
    log(f"Candidate: {args.candidate}")
    log(f"McKee set: {args.mckee_set or '(generate new)'}")
    log(f"Task ID: {args.task_id or '(none)'}")

    load_decker_env()
    token = os.environ.get("TELEGRAM_TOKEN", "")

    # Resolve paths
    candidate_path = Path(args.candidate)
    research_dir = DEFAULT_RESEARCH_DIR
    baseline_path = DEFAULT_BASELINE
    hypothesis_queue = DEFAULT_HYPOTHESIS_QUEUE

    # Derive candidate name for log messages
    candidate_name = candidate_path.stem

    # Validate inputs
    missing = []
    if not candidate_path.exists():
        missing.append(f"candidate: {candidate_path}")
    if not baseline_path.exists():
        missing.append(f"baseline: {baseline_path}")
    if args.mckee_set and not Path(args.mckee_set).exists():
        missing.append(f"mckee-set: {args.mckee_set}")
    if missing:
        for m in missing:
            log(f"ERROR: not found — {m}")
        sys.exit(1)

    mckee_path = Path(args.mckee_set) if args.mckee_set else None

    # Load texts
    baseline_text = baseline_path.read_text(encoding="utf-8")
    candidate_text = candidate_path.read_text(encoding="utf-8")

    # Wire aibrain into sys.path
    if str(AIBRAIN_DIR) not in sys.path:
        sys.path.insert(0, str(AIBRAIN_DIR))
    os.chdir(str(AIBRAIN_DIR))

    from workflows.mckee_generator import run_mckee_gate

    action = "reusing" if mckee_path else "generating new"
    log(f"Starting run_mckee_gate() — 200 Haiku calls, ~10-15 min ({action} question set)...")

    result = run_mckee_gate(
        target="special_liaison",
        baseline_text=baseline_text,
        candidate_text=candidate_text,
        research_dir=research_dir,
        mckee_path=mckee_path,
    )

    passed = result["passed"]
    baseline_score = result["baseline_mckee_score"]
    candidate_score = result["candidate_mckee_score"]
    delta = candidate_score - baseline_score
    log(f"McKee result: passed={passed}  baseline={baseline_score:.4f}  candidate={candidate_score:.4f}  delta={delta:+.4f}")

    ts_now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

    if passed:
        log("PASS — promoting candidate to baseline")
        shutil.copy2(str(candidate_path), str(baseline_path))
        log(f"Copied {candidate_name} -> baseline.md")

        entry = (
            f"\n---\n## {candidate_name} — PROMOTED\n"
            f"status: promoted\n"
            f"promoted_at: {ts_now}\n"
            f"baseline_mckee_score: {baseline_score}\n"
            f"candidate_mckee_score: {candidate_score}\n"
            f"delta: {delta:+.4f}\n"
        )
        with hypothesis_queue.open("a", encoding="utf-8") as f:
            f.write(entry)
        log("Appended PROMOTED to hypothesis_queue.md")

        commit_msg = (
            f"Promote {candidate_name} to SL baseline — "
            f"McKee PASS {candidate_score:.4f} > {baseline_score:.4f}"
        )
        ok = git_commit_push([baseline_path, hypothesis_queue], commit_msg)
        log(f"Git commit+push: {'ok' if ok else 'FAILED'}")

        tg_text = (
            f"McKee PASS — {candidate_name} promoted to SL baseline\n"
            f"baseline={baseline_score:.4f}  candidate={candidate_score:.4f}  delta={delta:+.4f}"
        )
        tg_ok = send_telegram(token, TELEGRAM_CHAT_ID, tg_text) if token else False
        log(f"Telegram: {'ok' if tg_ok else 'FAILED (no token or error)'}")

        work_output = (
            f"DONE:\n"
            f"- research/special_liaison/baseline.md: replaced with {candidate_name} (McKee PASS)\n"
            f"- research/special_liaison/hypothesis_queue.md: PROMOTED entry appended\n"
            f"- git commit+push: {commit_msg}\n\n"
            f"DIDN'T TOUCH:\n"
            f"- {candidate_path.name}: left as-is (source only)\n\n"
            f"VERIFICATION:\n"
            f"- McKee passed={passed}  baseline={baseline_score:.4f}  candidate={candidate_score:.4f}\n"
            f"- Telegram ok={tg_ok}\n"
            f"- git log --oneline -1 shows promotion commit\n\n"
            f"OPEN CONCERNS: None."
        )
    else:
        log("FAIL — candidate did not beat baseline, not promoting")
        entry = (
            f"\n---\n## {candidate_name} — REVERTED_OVERFIT\n"
            f"status: reverted_overfit\n"
            f"reverted_at: {ts_now}\n"
            f"baseline_mckee_score: {baseline_score}\n"
            f"candidate_mckee_score: {candidate_score}\n"
            f"delta: {delta:+.4f}\n"
        )
        with hypothesis_queue.open("a", encoding="utf-8") as f:
            f.write(entry)
        log("Appended REVERTED_OVERFIT to hypothesis_queue.md")

        tg_text = (
            f"McKee FAIL — {candidate_name} NOT promoted\n"
            f"baseline={baseline_score:.4f}  candidate={candidate_score:.4f}  delta={delta:+.4f}"
        )
        tg_ok = send_telegram(token, TELEGRAM_CHAT_ID, tg_text) if token else False
        log(f"Telegram: {'ok' if tg_ok else 'FAILED (no token or error)'}")

        work_output = (
            f"DONE:\n"
            f"- research/special_liaison/hypothesis_queue.md: REVERTED_OVERFIT entry appended\n\n"
            f"DIDN'T TOUCH:\n"
            f"- baseline.md: not touched (McKee FAIL — candidate did not beat baseline)\n\n"
            f"VERIFICATION:\n"
            f"- McKee passed={passed}  baseline={baseline_score:.4f}  candidate={candidate_score:.4f}\n"
            f"- Telegram ok={tg_ok}\n"
            f"- hypothesis_queue.md contains REVERTED_OVERFIT entry for {candidate_name}\n\n"
            f"OPEN CONCERNS: None."
        )

    if args.task_id:
        complete_company_task(args.task_id, work_output)

    log("mckee_run.py done.")


if __name__ == "__main__":
    # P0-1 harness: entry point routes through workflow_execute for audit trail
    workflow_execute(
        workflow_name="mckee_run",
        action=main,
        task_type="judgment",
        actor="cli",
    )
