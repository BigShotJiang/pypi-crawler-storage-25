#!/usr/bin/env python3
"""
viral_poster.py — Unified 6-hour posting runner for publishing_calendar.json.

Reads the 686-entry viral launch calendar, finds all entries with
scheduled <= now and status='pending', posts to each platform, then
updates the calendar JSON and appends to posting_log.json.

Usage:
    python viral_poster.py --post-due          # Post all overdue entries
    python viral_poster.py --post-due --dry-run  # Preview without posting
    python viral_poster.py --status            # Show platform status
"""

import argparse
import datetime
import json
import os
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.error import URLError

# Harness integration (P0-1 workflow discipline)
from aibrain.core.workflow_base import workflow_execute

# LinkedIn posting — adapter wraps social_poster.post_linkedin to match poster contract
from workflows.social_poster import post_linkedin as _social_post_linkedin

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------

DECKER_ENV = Path.home() / ".decker_env"

# Portable paths — override via env vars for new machine installs
_SOCIAL_DIR = Path(os.environ.get("AIBRAIN_SOCIAL_DIR", Path.home() / "decker_system" / "12_social"))
_TOOLS_DIR  = Path(os.environ.get("AIBRAIN_TOOLS_DIR",  Path.home() / "decker_system" / "04_tools"))

CALENDAR_PATH      = Path(os.environ.get("CONTENT_CALENDAR_PATH",  _SOCIAL_DIR / "publishing_calendar.json"))
POSTING_LOG_PATH   = Path(os.environ.get("CONTENT_LOG_PATH",       _SOCIAL_DIR / "posting_log.json"))
POSTING_STATE_PATH = Path(os.environ.get("CONTENT_STATE_PATH",     _SOCIAL_DIR / "posting_state.json"))
GRAPHICS_DIR       = Path(os.environ.get("CONTENT_GRAPHICS_DIR",   _TOOLS_DIR  / "social_graphic" / "output" / "aibrain"))
TIKTOK_VIDEO_DIR   = Path(os.environ.get("TIKTOK_VIDEO_DIR",       _SOCIAL_DIR / "tiktok_videos"))
CHROME_PROFILE_DIR = Path(os.environ.get("CHROME_PROFILE_DIR",     Path.home() / "AppData" / "Local" / "Google" / "Chrome" / "User Data"))
RATE_LIMIT_HOURS   = int(os.environ.get("CONTENT_RATE_LIMIT_HOURS", "3"))

# ---------------------------------------------------------------------------
# Credential loader
# ---------------------------------------------------------------------------

def load_env() -> dict:
    """Parse ~/.decker_env into a dict."""
    env = {}
    if not DECKER_ENV.exists():
        return env
    for line in DECKER_ENV.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" in line:
            k, v = line.split("=", 1)
            env[k.strip()] = v.strip()
    return env

ENV = load_env()
for k, v in ENV.items():
    os.environ.setdefault(k, v)

# ---------------------------------------------------------------------------
# Chrome CDP health + auto-launch
# ---------------------------------------------------------------------------

_CHROME_EXE_CANDIDATES = [
    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
    r"C:\Users\sinde\AppData\Local\Google\Chrome\Application\chrome.exe",
]

# Use port 9223 for the poster's own dedicated Chrome — avoids conflict with
# any existing Chrome on 9222 whose WS may be in a stuck state.
CDP_PORT = int(os.environ.get("POSTER_CDP_PORT", "9223"))
CDP_URL  = f"http://localhost:{CDP_PORT}"


def _cdp_ws_healthy(port: int = CDP_PORT, timeout_s: float = 3.0) -> bool:
    """Return True only if Chrome CDP HTTP is responsive on the given port."""
    try:
        r = urlopen(f"http://localhost:{port}/json/version", timeout=timeout_s)
        data = json.loads(r.read())
        return bool(data.get("webSocketDebuggerUrl"))
    except Exception:
        return False


def ensure_chrome_cdp() -> bool:
    """Ensure a poster-owned Chrome is running on CDP_PORT with a healthy WS.

    Uses port 9223 (not 9222) so it never conflicts with the user's primary Chrome.
    Launches headlessly with the user's profile dir for saved login sessions.
    Returns True when CDP is ready, False if unable to start.
    """
    if _cdp_ws_healthy():
        return True

    chrome_exe = None
    for candidate in _CHROME_EXE_CANDIDATES:
        if Path(candidate).exists():
            chrome_exe = candidate
            break
    if not chrome_exe:
        chrome_exe = shutil.which("chrome") or shutil.which("google-chrome")
    if not chrome_exe:
        print("  [WARN] Chrome not found — cannot auto-launch CDP")
        return False

    # Use a dedicated poster profile dir so it never conflicts with the user's
    # running Chrome (which locks "User Data"). Sessions are stored here after
    # a one-time manual login via: chrome.exe --remote-debugging-port=9223
    # --user-data-dir="C:\Users\sinde\AppData\Local\Google\Chrome\Poster"
    poster_profile = str(Path.home() / "AppData" / "Local" / "Google" / "Chrome" / "Poster")

    print(f"  [CDP] Launching poster Chrome on port {CDP_PORT}: {chrome_exe}", flush=True)
    try:
        subprocess.Popen(
            [
                chrome_exe,
                f"--remote-debugging-port={CDP_PORT}",
                "--headless=new",
                "--no-first-run",
                "--no-default-browser-check",
                "--disable-extensions",
                "--disable-gpu",
                "--user-data-dir=" + poster_profile,
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.DETACHED_PROCESS,
        )
    except Exception as e:
        print(f"  [WARN] Chrome launch failed: {e}", flush=True)
        return False

    # Wait up to 30s for CDP to become responsive
    for i in range(30):
        time.sleep(1)
        if _cdp_ws_healthy():
            print(f"  [CDP] Poster Chrome ready on port {CDP_PORT} ({i+1}s)", flush=True)
            return True

    print(f"  [WARN] Chrome launched but CDP not ready after 30s on port {CDP_PORT}", flush=True)
    return False


# ---------------------------------------------------------------------------
# Per-platform rate-limit state helpers
# ---------------------------------------------------------------------------

def load_posting_state() -> dict:
    if POSTING_STATE_PATH.exists():
        try:
            return json.loads(POSTING_STATE_PATH.read_text(encoding="utf-8"))
        except Exception:
            return {}
    return {}

def save_posting_state(state: dict) -> None:
    POSTING_STATE_PATH.write_text(json.dumps(state, indent=2), encoding="utf-8")

def platform_on_cooldown(platform: str, state: dict) -> bool:
    last = state.get(platform)
    if not last:
        return False
    try:
        last_dt = datetime.datetime.fromisoformat(last)
        if last_dt.tzinfo is None:
            last_dt = last_dt.replace(tzinfo=datetime.timezone.utc)
        return (datetime.datetime.now(datetime.timezone.utc) - last_dt).total_seconds() < RATE_LIMIT_HOURS * 3600
    except Exception:
        return False

# ---------------------------------------------------------------------------
# Content file helpers
# ---------------------------------------------------------------------------

def read_content(content_file: str) -> str:
    """Read raw content from a .md file, returning full text."""
    p = Path(content_file)
    if not p.exists():
        return ""
    return p.read_text(encoding="utf-8")


def extract_post_text(content: str, platform: str) -> str:
    """
    Extract the actual post body from a viral-launch .md file.

    The files use a format like:
      # Day N — Platform — Variant
      **Post time:** ...
      **Format:** ...
      ---
      ## Section heading (optional)
      **Title:** ...  (for Reddit)
      **Post:**
      <body text>
      ---
      # Another section
    Returns the first post body found.
    """
    if not content:
        return ""

    # For Twitter threads: extract from "**Main tweet:**" or numbered tweets
    if platform == "twitter":
        # Try "**Main tweet:**\n<text>"
        m = re.search(r'\*\*Main tweet:\*\*\s*\n(.*?)(?=\n\n---|\n\n\*\*\d/|\Z)', content, re.DOTALL)
        if m:
            return m.group(1).strip()
        # Single standalone tweet: strip frontmatter
        lines = content.splitlines()
        body_lines = []
        in_body = False
        for line in lines:
            if line.strip() == "---":
                in_body = not in_body
                continue
            if in_body and not line.startswith("**") and line.strip():
                body_lines.append(line)
            elif in_body and line.startswith("**Post:**"):
                # next content is the body
                continue
        if body_lines:
            return "\n".join(body_lines[:5]).strip()  # First 5 lines for standalone
        # Fallback: take first non-header paragraph
        for line in lines:
            stripped = line.strip()
            if stripped and not stripped.startswith("#") and not stripped.startswith("**"):
                return stripped
        return content.strip()[:280]

    # For Reddit: extract first **Post:** section
    if platform == "reddit":
        m = re.search(r'\*\*Post:\*\*\s*\n(.*?)(?=\n---|\n## |\Z)', content, re.DOTALL)
        if m:
            return m.group(1).strip()
        return content.strip()[:1000]

    # For Instagram: extract caption after **Caption:** or first paragraph
    if platform == "instagram":
        m = re.search(r'\*\*Caption:\*\*\s*\n?(.*?)(?=\n\*\*|\n---|\Z)', content, re.DOTALL)
        if m:
            return m.group(1).strip()
        # Fall back: take meaningful lines after frontmatter
        lines = content.splitlines()
        body = []
        in_body = False
        for line in lines:
            if line.strip() == "---":
                in_body = True
                continue
            if in_body and line.strip() and not line.startswith("#") and not line.startswith("**Post time") and not line.startswith("**Format"):
                body.append(line.strip())
            if len(body) >= 5:
                break
        if body:
            return "\n".join(body)
        return content.strip()[:2200]

    # LinkedIn / default: strip frontmatter
    lines = content.splitlines()
    body = []
    past_header = False
    for line in lines:
        if not past_header:
            if line.strip() == "---":
                past_header = True
            continue
        if line.startswith("#") and not body:
            continue
        body.append(line)
    return "\n".join(body).strip()[:1300] if body else content.strip()[:1300]


def extract_reddit_title(content: str) -> str:
    """Extract Reddit post title from **Title:** field."""
    m = re.search(r'\*\*Title:\*\*\s*(.+)', content)
    if m:
        return m.group(1).strip()
    # Fallback: first non-empty, non-header line
    for line in content.splitlines():
        stripped = line.strip()
        if stripped and not stripped.startswith("#") and not stripped.startswith("**"):
            return stripped[:300]
    return "AIBrain — Local AI Agent Memory"


def extract_subreddit(content: str, entry_id: str) -> str:
    """
    Extract subreddit name from content file.
    Looks for '## r/subreddit' or '**Format:** r/subreddit' patterns.
    Falls back to known mappings by entry day/index.
    """
    # Look for ## r/subreddit_name heading
    m = re.search(r'## r/(\w+)', content)
    if m:
        return m.group(1)
    # Look for **Format:** r/subreddit + r/other
    m = re.search(r'r/(\w+)', content)
    if m:
        return m.group(1)
    # Default: safe general sub for AIBrain content
    return "selfhosted"


RENDERED_IG_DIR = GRAPHICS_DIR / "rendered"


def _extract_ig_hook(md_content: str) -> tuple[str, str]:
    """
    Extract (hook, support) text from an Instagram-spec markdown file.
    Returns a short punchy hook (slide 1) and optional secondary line.
    Falls back to caption first sentence if no slide structure found.
    """
    if not md_content:
        return ("AIBrain", "Persistent memory for any AI agent.")

    def _clean(s: str) -> str:
        return s.strip().strip('"').strip("'").strip()

    # Pattern 1: **Slide 1 (hook):** <newline> "text"
    m = re.search(r'\*\*Slide\s*1[^*]*?\*\*\s*\n+(.+?)(?:\n\n|\n\*\*Slide)', md_content, re.DOTALL | re.IGNORECASE)
    hook = ""
    if m:
        # Take first 1-3 non-empty lines from the slide 1 block
        lines = [_clean(l) for l in m.group(1).splitlines() if _clean(l) and not _clean(l).startswith("(")]
        if lines:
            hook = "\n".join(lines[:3])

    # Fallback: use Caption first paragraph
    if not hook:
        cap = re.search(r'\*\*Caption:\*\*\s*\n+(.+?)(?:\n\n|\*\*)', md_content, re.DOTALL)
        if cap:
            first = _clean(cap.group(1).split("\n\n")[0])
            hook = first[:180]

    if not hook:
        hook = "AIBrain"

    # Pull Slide 2 as optional support
    support = ""
    m2 = re.search(r'\*\*Slide\s*2[^*]*?\*\*\s*\n+(.+?)(?:\n\n|\n\*\*Slide)', md_content, re.DOTALL | re.IGNORECASE)
    if m2:
        lines = [_clean(l) for l in m2.group(1).splitlines() if _clean(l) and not _clean(l).startswith("(")]
        if lines:
            support = " ".join(lines[:2])[:160]

    return (hook, support)


def _render_ig_card(hook: str, support: str, out_path: Path) -> bool:
    """
    Render a 1080x1080 Instagram card with the hook text.
    Returns True on success, False on any failure. Never raises.
    """
    try:
        from playwright.sync_api import sync_playwright
    except Exception:
        return False

    # HTML-escape
    import html as _html
    hook_html = _html.escape(hook).replace("\n", "<br>")
    support_html = _html.escape(support).replace("\n", "<br>") if support else ""

    html = f"""<!DOCTYPE html><html><head><meta charset="UTF-8"><style>
* {{ margin: 0; padding: 0; box-sizing: border-box; }}
body {{
  width: 1080px; height: 1080px; background: #0a0a0a;
  font-family: 'Courier New', Courier, monospace; overflow: hidden;
  display: flex; flex-direction: column; justify-content: space-between;
  padding: 96px 80px; position: relative;
}}
.eyebrow {{ font-size: 18px; color: #00f5d4; letter-spacing: 4px; text-transform: uppercase; }}
.hook {{ font-size: 72px; font-weight: 700; color: #e8e8e8; line-height: 1.15;
        letter-spacing: -1.5px; margin-top: 24px; }}
.support {{ font-size: 26px; color: #c8c8c8; line-height: 1.4; margin-top: 40px;
           max-width: 860px; }}
.footer {{ display: flex; justify-content: space-between; align-items: flex-end; }}
.brand {{ font-size: 14px; color: #333; letter-spacing: 3px; text-align: right; line-height: 1.8; }}
.brand span {{ color: #00f5d4; }}
.install {{ font-size: 22px; color: #00f5d4; letter-spacing: 1px; }}
.corner-tl, .corner-br {{ position: absolute; width: 32px; height: 32px;
  border-color: #00f5d4; border-style: solid; opacity: 0.4; }}
.corner-tl {{ top: 40px; left: 40px; border-width: 2px 0 0 2px; }}
.corner-br {{ bottom: 40px; right: 40px; border-width: 0 2px 2px 0; }}
.scanline {{ position: absolute; inset: 0; pointer-events: none;
  background: repeating-linear-gradient(0deg, transparent, transparent 2px,
    rgba(0,0,0,0.03) 2px, rgba(0,0,0,0.03) 4px); }}
</style></head><body>
<div class="scanline"></div><div class="corner-tl"></div><div class="corner-br"></div>
<div>
  <div class="eyebrow">// AIBRAIN</div>
  <div class="hook">{hook_html}</div>
  {"<div class='support'>" + support_html + "</div>" if support_html else ""}
</div>
<div class="footer">
  <div class="install">pip install aibrain</div>
  <div class="brand">PERSISTENT MEMORY FOR ANY AI<br><span>AIBRAIN</span> // MYAIBRAIN.ORG</div>
</div>
</body></html>"""

    import tempfile
    tmp = None
    try:
        out_path.parent.mkdir(parents=True, exist_ok=True)
        with tempfile.NamedTemporaryFile(mode="w", suffix=".html", delete=False,
                                         encoding="utf-8") as f:
            f.write(html)
            tmp = Path(f.name)
        with sync_playwright() as p:
            browser = p.chromium.launch()
            page = browser.new_page(viewport={"width": 1080, "height": 1080})
            page.goto(f"file:///{tmp.resolve().as_posix()}")
            page.wait_for_timeout(300)
            page.screenshot(path=str(out_path), full_page=False)
            browser.close()
        return out_path.exists() and out_path.stat().st_size > 0
    except Exception as e:
        print(f"  [render] failed: {e}")
        return False
    finally:
        if tmp and tmp.exists():
            try: tmp.unlink()
            except Exception: pass


def _render_unique_ig_image(entry: dict) -> str | None:
    """
    Render a per-entry unique IG image from the entry's markdown content_file.
    Cached by md5(content). Returns path or None on failure.
    """
    content_file = entry.get("content_file", "")
    if not content_file:
        return None
    p = Path(content_file)
    if not p.exists():
        return None
    try:
        md = p.read_text(encoding="utf-8")
    except Exception:
        return None
    if not md.strip():
        return None

    import hashlib
    digest = hashlib.md5(md.encode("utf-8")).hexdigest()[:16]
    out_path = RENDERED_IG_DIR / f"{digest}.png"
    if out_path.exists() and out_path.stat().st_size > 0:
        return str(out_path)

    hook, support = _extract_ig_hook(md)
    if _render_ig_card(hook, support, out_path):
        return str(out_path)
    return None


def find_instagram_image(entry: dict) -> str | None:
    """
    Find the best matching image for an Instagram entry.

    Priority:
      1. entry['image_file'] explicit override
      2. Per-entry rendered card from content_file markdown (cached by content hash)
      3. Day-based fallback graphic
      4. Any day*.png in the graphics dir
    """
    # Explicit override in calendar entry
    if "image_file" in entry:
        p = Path(entry["image_file"])
        if p.exists():
            return str(p)

    # Per-entry unique render from markdown — the anti-duplicate path
    rendered = _render_unique_ig_image(entry)
    if rendered:
        return rendered

    # --- Fallback: day-based graphic (original behavior) ---
    day = entry.get("day", 1)
    day_map = {
        1: "day1_amnesia.png",
        2: "day2_benchmarks.png",
        3: "day3_hottake.png",
        4: "day4_builder.png",
        5: "day5_marketplace.png",
        6: "day6_security.png",
        7: "day7_stats.png",
    }

    # Try day-specific graphic
    if day in day_map:
        candidate = GRAPHICS_DIR / day_map[day]
        if candidate.exists():
            return str(candidate)
        # For days > 7, cycle through the week
        cycle_day = ((day - 1) % 7) + 1
        if cycle_day in day_map:
            candidate = GRAPHICS_DIR / day_map[cycle_day]
            if candidate.exists():
                return str(candidate)

    # Last resort: any day*.png in the graphics dir
    for p in sorted(GRAPHICS_DIR.glob("day*.png")):
        return str(p)

    return None

# ---------------------------------------------------------------------------
# Platform posters
# ---------------------------------------------------------------------------

def post_twitter(entry: dict, content: str, dry_run: bool = False) -> dict:
    """Post to Twitter/X via the Twitter API v2 using stored OAuth 1.0a credentials."""
    post_text = extract_post_text(content, "twitter")
    if not post_text:
        return {"status": "error", "reason": "Empty post text", "platform": "twitter"}
    if len(post_text) > 280:
        post_text = post_text[:277] + "..."

    if dry_run:
        print(f"  [DRY RUN] Twitter: would post ({len(post_text)} chars):")
        print(f"    {post_text[:100]}...")
        return {"status": "dry_run", "platform": "twitter", "text_preview": post_text[:100]}

    api_key        = os.environ.get("TWITTER_API_KEY", "")
    api_secret     = os.environ.get("TWITTER_API_SECRET", "")
    access_token   = os.environ.get("TWITTER_ACCESS_TOKEN", "")
    access_secret  = os.environ.get("TWITTER_ACCESS_TOKEN_SECRET", "")

    if not all([api_key, api_secret, access_token, access_secret]):
        return {"status": "skipped", "reason": "Twitter API credentials missing from env", "platform": "twitter"}

    try:
        import tweepy
        client = tweepy.Client(
            consumer_key=api_key,
            consumer_secret=api_secret,
            access_token=access_token,
            access_token_secret=access_secret,
        )
        resp = client.create_tweet(text=post_text)
        tweet_id = resp.data["id"]
        tweet_url = f"https://x.com/i/web/status/{tweet_id}"
        print(f"  [OK] Twitter posted via API — {tweet_url}")
        return {"status": "posted", "platform": "twitter", "post_url": tweet_url, "post_id": tweet_id}
    except Exception as e:
        return {"status": "error", "reason": str(e), "platform": "twitter"}


def post_reddit(entry: dict, content: str, dry_run: bool = False) -> dict:
    """Post to Reddit via Playwright using saved Chrome browser session.

    Chrome persistent-context failures (e.g. Chrome already running, profile
    locked, headless crash) are returned as status=skipped so the calendar
    entry stays pending and retries next cycle — NOT permanently errored.
    Only true posting failures (page not reached, auth errors) become errors.
    """
    subreddit_name = extract_subreddit(content, entry.get("id", ""))
    title = extract_reddit_title(content)
    body = extract_post_text(content, "reddit")
    if not body:
        return {"status": "error", "reason": "Empty post body", "platform": "reddit"}
    if dry_run:
        return {"status": "dry_run", "platform": "reddit", "subreddit": subreddit_name, "text_preview": body[:100]}

    if not ensure_chrome_cdp():
        return {"status": "skipped", "reason": "Chrome CDP unavailable and could not auto-launch", "platform": "reddit"}

    try:
        from playwright.sync_api import sync_playwright
        with sync_playwright() as p:
            try:
                browser = p.chromium.connect_over_cdp(CDP_URL, timeout=12000)
            except Exception as launch_err:
                reason = f"Reddit: could not connect to Chrome CDP: {str(launch_err)[:120]}"
                print(f"  [SKIP] Reddit: {reason}")
                return {"status": "skipped", "reason": reason, "platform": "reddit"}
            context = browser.contexts[0] if browser.contexts else browser.new_context()
            page = context.new_page()
            # Use old.reddit.com — classic HTML form, no shadow DOM web components
            page.goto(f"https://old.reddit.com/r/{subreddit_name}/submit", timeout=30000)
            page.wait_for_load_state("domcontentloaded", timeout=15000)
            page.wait_for_timeout(1500)
            if "login" in page.url or page.locator('input[name="passwd"]').count() > 0:
                page.close()
                return {"status": "skipped", "reason": "Reddit not logged in — open Chrome and log in first", "platform": "reddit"}
            # Select "Text" post type (self post)
            try:
                page.locator('a[href*="?selftext=true"], a:has-text("Text"), #link-desc a:has-text("Self Text")').first.click(timeout=3000)
                page.wait_for_timeout(500)
            except Exception:
                try:
                    page.locator('input[value="self"]').first.click(timeout=2000)
                    page.wait_for_timeout(500)
                except Exception:
                    pass
            # Fill title
            title_box = page.locator('textarea[name="title"]').first
            title_box.wait_for(state="visible", timeout=5000)
            title_box.click()
            title_box.press_sequentially(title, delay=20)
            page.wait_for_timeout(500)
            # Fill body text
            try:
                body_box = page.locator('textarea[name="text"]').first
                if body_box.count() > 0:
                    body_box.click()
                    body_box.press_sequentially(body[:500], delay=10)
            except Exception:
                pass
            page.wait_for_timeout(500)
            # Submit
            submit_btn = page.locator('button[name="submit"]:not([disabled]), button[type="submit"]:not([disabled])').last
            submit_btn.wait_for(state="visible", timeout=5000)
            submit_btn.click(timeout=8000)
            page.wait_for_timeout(4000)
            post_url = page.url
            page.close()
            print(f"  [OK] Reddit posted to r/{subreddit_name} — {post_url}")
            return {"status": "posted", "platform": "reddit", "subreddit": subreddit_name, "post_url": post_url}
    except Exception as e:
        return {"status": "error", "reason": str(e), "platform": "reddit"}


def post_instagram(entry: dict, content: str, dry_run: bool = False) -> dict:
    """
    Post photo + caption to Instagram via instagrapi.
    Requires: INSTAGRAM_USERNAME, INSTAGRAM_PASSWORD in .decker_env.
    Image: matched by day number from the social_graphic/output/aibrain/ directory.
    """
    username = ENV.get("INSTAGRAM_USERNAME", "")
    password = ENV.get("INSTAGRAM_PASSWORD", "")

    missing = [k for k, v in {
        "INSTAGRAM_USERNAME": username,
        "INSTAGRAM_PASSWORD": password,
    }.items() if not v]

    if missing:
        return {
            "status": "skipped",
            "reason": f"Missing Instagram credentials: {', '.join(missing)}",
            "platform": "instagram",
        }

    image_path = find_instagram_image(entry)
    if not image_path:
        return {
            "status": "error",
            "reason": "No image found for Instagram post (checked GRAPHICS_DIR for day*.png)",
            "platform": "instagram",
        }

    caption = extract_post_text(content, "instagram")
    if not caption:
        caption = "AIBrain — persistent memory for any AI agent. Free on PyPI. myaibrain.org"

    if dry_run:
        print(f"  [DRY RUN] Instagram: would post image={Path(image_path).name}")
        print(f"    Caption: {caption[:80]}...")
        return {
            "status": "dry_run",
            "platform": "instagram",
            "image": image_path,
            "caption_preview": caption[:80],
        }

    try:
        from instagrapi import Client
        cl = Client()
        cl.login(username, password)
        media = cl.photo_upload(path=image_path, caption=caption)
        post_id = f"{media.id}_{media.user.pk}"
        print(f"  [OK] Instagram posted — post_id: {post_id}")
        return {
            "status": "posted",
            "platform": "instagram",
            "post_id": post_id,
        }
    except Exception as e:
        print(f"  [ERROR] Instagram: {e}")
        return {"status": "error", "reason": str(e), "platform": "instagram"}


def post_linkedin(entry: dict, content: str, dry_run: bool = False) -> dict:
    """
    Post to LinkedIn via social_poster.post_linkedin().
    Adapter: converts viral_poster poster contract → social_poster API.
    Requires: LINKEDIN_ACCESS_TOKEN in .decker_env.
    """
    post_text = extract_post_text(content, "linkedin")
    if not post_text:
        return {"status": "error", "reason": "Empty post text", "platform": "linkedin"}

    if dry_run:
        print(f"  [DRY RUN] LinkedIn: would post ({len(post_text)} chars):")
        print(f"    {post_text[:100]}...")
        return {"status": "dry_run", "platform": "linkedin", "text_preview": post_text[:100]}

    token = ENV.get("LINKEDIN_ACCESS_TOKEN", "")
    if not token:
        reason = "Missing LinkedIn credential: LINKEDIN_ACCESS_TOKEN"
        print(f"  [SKIP] LinkedIn: {reason}")
        return {"status": "skipped", "reason": reason, "platform": "linkedin"}

    success = _social_post_linkedin(post_text, ENV)
    if success:
        return {"status": "posted", "platform": "linkedin"}
    else:
        return {"status": "error", "reason": "post_linkedin() returned False — check logs above", "platform": "linkedin"}


def post_facebook(entry: dict, content: str, dry_run: bool = False) -> dict:
    """Post to Facebook page via Playwright using saved browser session."""
    post_text = extract_post_text(content, "facebook")
    if not post_text:
        return {"status": "error", "reason": "Empty post text", "platform": "facebook"}
    if dry_run:
        return {"status": "dry_run", "platform": "facebook", "text_preview": post_text[:100]}
    try:
        from playwright.sync_api import sync_playwright
        with sync_playwright() as p:
            try:
                browser = p.chromium.connect_over_cdp(CDP_URL, timeout=12000)
            except Exception as e:
                return {"status": "skipped", "reason": f"Facebook: could not connect to Chrome CDP: {str(e)[:120]}", "platform": "facebook"}
            context = browser.contexts[0] if browser.contexts else browser.new_context()
            page = context.new_page()
            page.goto("https://www.facebook.com/", timeout=30000)
            # Check if logged in
            if "login" in page.url or page.locator('[data-testid="royal_email"]').count() > 0:
                page.close()
                return {"status": "skipped", "reason": "Facebook not logged in — open Chrome and log in first", "platform": "facebook"}
            # Find "What's on your mind" post box and post
            page.locator('[data-testid="status-attachment-mentions-input"], [role="textbox"]').first.click()
            page.wait_for_timeout(1000)
            page.keyboard.type(post_text)
            page.wait_for_timeout(500)
            # Click Post button
            post_btn = page.locator('div[aria-label="Post"], button:has-text("Post")').last
            post_btn.click()
            page.wait_for_timeout(3000)
            page.close()
            print(f"  [OK] Facebook posted")
            return {"status": "posted", "platform": "facebook"}
    except Exception as e:
        return {"status": "error", "reason": str(e), "platform": "facebook"}


def post_medium(entry: dict, content: str, dry_run: bool = False) -> dict:
    """Post to Medium via Playwright using saved Chrome browser session."""
    post_text = extract_post_text(content, "medium")
    if not post_text:
        return {"status": "error", "reason": "Empty post text", "platform": "medium"}
    # Use first line as title, rest as body
    lines = post_text.strip().split("\n", 1)
    title = lines[0].lstrip("#").strip()[:100]
    body = lines[1].strip() if len(lines) > 1 else post_text
    if dry_run:
        return {"status": "dry_run", "platform": "medium", "text_preview": post_text[:100]}
    try:
        from playwright.sync_api import sync_playwright
        with sync_playwright() as p:
            try:
                browser = p.chromium.connect_over_cdp(CDP_URL, timeout=12000)
            except Exception as e:
                return {"status": "skipped", "reason": f"Medium: could not connect to Chrome CDP: {str(e)[:120]}", "platform": "medium"}
            context = browser.contexts[0] if browser.contexts else browser.new_context()
            page = context.new_page()
            page.goto("https://medium.com/new-story", timeout=30000)
            page.wait_for_load_state("networkidle", timeout=15000)
            if "login" in page.url or "signin" in page.url:
                page.close()
                return {"status": "skipped", "reason": "Medium not logged in — open Chrome and log in first", "platform": "medium"}
            # Fill title
            page.locator('[data-testid="editor-title-input"], h3[data-placeholder="Title"]').first.click(timeout=5000)
            page.keyboard.type(title)
            page.keyboard.press("Tab")
            page.wait_for_timeout(500)
            # Fill body
            page.keyboard.type(body)
            page.wait_for_timeout(1000)
            # Publish: click "Publish" button
            page.locator('button:has-text("Publish")').first.click(timeout=5000)
            page.wait_for_timeout(2000)
            # Confirm publish dialog
            publish_confirm = page.locator('button:has-text("Publish now"), button:has-text("Publish story")').first
            if publish_confirm.count() > 0:
                publish_confirm.click(timeout=3000)
                page.wait_for_timeout(3000)
            post_url = page.url
            page.close()
            print(f"  [OK] Medium published — {post_url}")
            return {"status": "posted", "platform": "medium", "post_url": post_url}
    except Exception as e:
        return {"status": "error", "reason": str(e), "platform": "medium"}


def post_x_reels(entry: dict, content: str, dry_run: bool = False) -> dict:
    """Post video/reel content to X (Twitter). Falls back to text tweet if no video found."""
    # Reuse Twitter credentials and post as a text tweet (video upload requires media upload API)
    return post_twitter(entry, content, dry_run=dry_run)


def _find_tiktok_video(entry: dict) -> Path | None:
    """Find the right video file for this calendar entry by day number."""
    entry_id = entry.get("id", "")
    # Extract day number from entry ID like "viral_day3_tiktok-1"
    import re as _re
    m = _re.search(r'day(\d+)', entry_id)
    if not m:
        return None
    day = int(m.group(1))
    day_map = {
        1: "day1_grand_launch.mp4",
        2: "day2_vibe_coding.mp4",
        3: "day3_pentesting_playbook.mp4",
        4: "day4_ai_deception.mp4",
        5: "day5_red_blue.mp4",
        6: "day6_behind_scenes.mp4",
        7: "day7_last_call.mp4",
    }
    filename = day_map.get(day)
    if filename:
        p = TIKTOK_VIDEO_DIR / filename
        if p.exists():
            return p
    # Fallback: try v150 demos for newer content
    demos = ["v150_buildit_demo.mp4", "v150_memory_demo.mp4", "v150_native_app_demo.mp4"]
    for d in demos:
        p = TIKTOK_VIDEO_DIR / d
        if p.exists():
            return p
    return None


def post_tiktok(entry: dict, content: str, dry_run: bool = False) -> dict:
    """Upload video to TikTok via Playwright using saved Chrome browser session."""
    video_path = _find_tiktok_video(entry)
    if not video_path:
        return {"status": "skipped", "reason": f"No video file found for {entry.get('id')} in {TIKTOK_VIDEO_DIR}", "platform": "tiktok"}
    caption = extract_post_text(content, "tiktok") or extract_post_text(content, "instagram")
    if not caption:
        caption = entry.get("id", "AIBrain")
    # TikTok captions max 2200 chars, strip hashtag excess
    caption = caption[:2200]
    if dry_run:
        return {"status": "dry_run", "platform": "tiktok", "video": str(video_path), "caption_preview": caption[:80]}
    try:
        from playwright.sync_api import sync_playwright
        with sync_playwright() as p:
            try:
                browser = p.chromium.connect_over_cdp(CDP_URL, timeout=12000)
            except Exception as e:
                return {"status": "skipped", "reason": f"TikTok: could not connect to Chrome CDP: {str(e)[:120]}", "platform": "tiktok"}
            context = browser.contexts[0] if browser.contexts else browser.new_context()
            page = context.new_page()
            page.goto("https://www.tiktok.com/upload?lang=en", timeout=30000)
            page.wait_for_load_state("networkidle", timeout=15000)
            if "login" in page.url:
                page.close()
                return {"status": "skipped", "reason": "TikTok not logged in — open Chrome and log in first", "platform": "tiktok"}
            # Upload video file
            page.wait_for_timeout(2000)
            upload_input = page.locator('input[type="file"]').first
            upload_input.set_input_files(str(video_path))
            print(f"  Uploading {video_path.name} to TikTok...")
            # Wait for upload to process (up to 90s)
            page.wait_for_timeout(10000)
            # Fill caption
            caption_box = page.locator('[data-text="true"], [contenteditable="true"], .notranslate').first
            if caption_box.count() > 0:
                caption_box.click()
                page.keyboard.press("Control+a")
                page.keyboard.type(caption[:150])  # TikTok UI caption field
            page.wait_for_timeout(1000)
            # Post
            post_btn = page.locator('button:has-text("Post"), button[type="submit"]').last
            post_btn.click(timeout=5000)
            page.wait_for_timeout(5000)
            post_url = page.url
            page.close()
            print(f"  [OK] TikTok video posted — {post_url}")
            return {"status": "posted", "platform": "tiktok", "video": str(video_path), "post_url": post_url}
    except Exception as e:
        return {"status": "error", "reason": str(e), "platform": "tiktok"}


# ---------------------------------------------------------------------------
# Calendar manager
# ---------------------------------------------------------------------------

def load_calendar() -> list:
    return json.loads(CALENDAR_PATH.read_text(encoding="utf-8"))


def save_calendar(cal: list) -> None:
    CALENDAR_PATH.write_text(json.dumps(cal, indent=2), encoding="utf-8")


def load_posting_log() -> list:
    if not POSTING_LOG_PATH.exists():
        return []
    try:
        return json.loads(POSTING_LOG_PATH.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return []


def save_posting_log(log: list) -> None:
    POSTING_LOG_PATH.write_text(json.dumps(log, indent=2, ensure_ascii=False), encoding="utf-8")


def append_posting_log(entry: dict, result: dict) -> None:
    """Append a result record to posting_log.json."""
    log = load_posting_log()
    now_iso = datetime.datetime.utcnow().isoformat() + "Z"
    record = {
        "calendar_id": entry.get("id"),
        "platform": entry.get("platform"),
        "scheduled": entry.get("scheduled"),
        "content_file": entry.get("content_file"),
        "day": entry.get("day"),
        "attempted_at": now_iso,
        **result,
    }
    log.append(record)
    POSTING_LOG_PATH.write_text(json.dumps(log, indent=2), encoding="utf-8")


# ---------------------------------------------------------------------------
# Main runner
# ---------------------------------------------------------------------------

POSTER_MAP = {
    "twitter": post_twitter,
    "reddit": post_reddit,
    "instagram": post_instagram,
    "linkedin": post_linkedin,
    "facebook": post_facebook,
    "medium": post_medium,
    "x_reels": post_x_reels,
    "x-reels": post_x_reels,
    "tiktok": post_tiktok,
}


def post_due(dry_run: bool = False) -> None:
    """Find pending entries with scheduled <= now and post at most one per platform per 3 hours."""
    cal = load_calendar()
    now = datetime.datetime.now(datetime.timezone.utc)
    now_local = datetime.datetime.now()
    state = load_posting_state()

    due = []
    for entry in cal:
        if entry.get("status") != "pending":
            continue
        if entry.get("manual") is True:
            # Skip manual_required entries silently
            continue
        platform = entry.get("platform", "")
        if platform not in POSTER_MAP:
            continue
        sched_str = entry.get("scheduled", "")
        if not sched_str:
            continue
        # Parse ISO8601 with optional timezone offset
        try:
            # Handle offset-aware timestamps
            sched_str_norm = sched_str
            # Python 3.11+ handles +HH:MM fine; for older, strip and compare
            sched_dt = datetime.datetime.fromisoformat(sched_str_norm)
            if sched_dt.tzinfo is None:
                sched_dt = sched_dt.replace(tzinfo=datetime.timezone.utc)
            if sched_dt <= now:
                due.append(entry)
        except ValueError:
            print(f"  [WARN] Cannot parse scheduled time '{sched_str}' for {entry.get('id')}")
            continue

    if not due:
        print(f"No posts due as of {now_local.strftime('%Y-%m-%d %H:%M')} UTC")
        return {"status": "ok", "posted": 0, "errors": 0, "skipped": 0, "message": "no posts due"}

    print(f"Found {len(due)} posts due (as of {now.strftime('%Y-%m-%d %H:%M')} UTC):")
    for e in due:
        print(f"  - [{e['platform']:<12}] {e.get('id')} (scheduled {e.get('scheduled')})")
    print()

    # Group by platform — pick only the FIRST due entry per platform
    by_platform: dict[str, list] = {}
    for e in due:
        by_platform.setdefault(e["platform"], []).append(e)
    # Reduce to first entry per platform
    first_per_platform: dict[str, dict] = {p: entries[0] for p, entries in by_platform.items()}

    posted_count = 0
    error_count = 0

    for platform, entry in first_per_platform.items():
        poster = POSTER_MAP[platform]
        print(f"\n--- {platform.upper()} ---")

        # Rate-limit check — skip platform if posted within the last 3 hours
        if platform_on_cooldown(platform, state):
            print(f"  [{platform}] on cooldown — skipping")
            continue

        content_file = entry.get("content_file", "")
        content = read_content(content_file) if content_file else ""
        # Inline content takes precedence when no content_file, or as fallback
        if not content:
            content = entry.get("content", entry.get("text", ""))
        if not content:
            print(f"  [WARN] No content for entry {entry.get('id')} (content_file={content_file!r})")
            result = {"status": "error", "reason": f"No content found (content_file={content_file!r})"}
        else:
            result = poster(entry, content, dry_run=dry_run)

        append_posting_log(entry, result)

        if not dry_run:
            status = result.get("status")
            if status == "posted":
                entry["status"] = "posted"
                entry["posted_at"] = datetime.datetime.utcnow().isoformat() + "Z"
                if "post_id" in result:
                    entry["post_id"] = result["post_id"]
                if "post_url" in result:
                    entry["post_url"] = result["post_url"]
                posted_count += 1
                # Update rate-limit state for this platform
                state[platform] = datetime.datetime.now(datetime.timezone.utc).isoformat()
                save_posting_state(state)
            elif status == "skipped":
                # Credentials missing — leave as pending so manual posting is possible
                print(f"    -> Left as 'pending' (credentials missing)")
            elif status == "error":
                reason = result.get("reason", "unknown")
                print(f"  [ERROR] {platform}: {reason}")
                entry["status"] = "error"
                entry["error"] = reason
                error_count += 1
        else:
            posted_count += 1

    if not dry_run:
        save_calendar(cal)

    label = "[DRY RUN] " if dry_run else ""
    print(f"\n{label}Done: {posted_count} posted, {error_count} errors")
    if not dry_run:
        print(f"Calendar updated: {CALENDAR_PATH}")
        print(f"Log appended: {POSTING_LOG_PATH}")
    return {"status": "ok", "posted": posted_count, "errors": error_count, "skipped": len(due) - posted_count - error_count}


def show_status() -> None:
    """Show credential status and pending post counts per platform."""
    print("=== viral_poster status ===\n")

    # Credentials
    cred_checks = {
        "Twitter": [],  # Playwright-based — uses Chrome profile session; no API keys required
        "Reddit": ["REDDIT_USERNAME"],  # Playwright-based — uses Chrome profile session, not API
        "Instagram": ["INSTAGRAM_USERNAME", "INSTAGRAM_PASSWORD"],
        "LinkedIn": ["LINKEDIN_ACCESS_TOKEN"],
    }
    print("Credentials:")
    for platform, keys in cred_checks.items():
        missing = [k for k in keys if not ENV.get(k)]
        if missing:
            print(f"  {platform:<12} MISSING: {', '.join(missing)}")
        else:
            print(f"  {platform:<12} OK (all {len(keys)} keys present)")

    print()

    # Calendar summary
    cal = load_calendar()
    now = datetime.datetime.now(datetime.timezone.utc)
    by_platform: dict[str, dict] = {}
    for e in cal:
        p = e.get("platform", "unknown")
        if p not in by_platform:
            by_platform[p] = {"pending": 0, "posted": 0, "due": 0, "error": 0, "manual": 0}
        status = e.get("status", "")
        if status == "pending":
            by_platform[p]["pending"] += 1
            # Check if due
            sched_str = e.get("scheduled", "")
            if sched_str:
                try:
                    sched_dt = datetime.datetime.fromisoformat(sched_str)
                    if sched_dt.tzinfo is None:
                        sched_dt = sched_dt.replace(tzinfo=datetime.timezone.utc)
                    if sched_dt <= now:
                        by_platform[p]["due"] += 1
                except ValueError:
                    pass
        elif status == "posted":
            by_platform[p]["posted"] += 1
        elif status == "manual_required":
            by_platform[p]["manual"] += 1
        elif status == "error":
            by_platform[p]["error"] += 1

    print("Calendar summary:")
    print(f"  {'Platform':<14} {'Pending':>8} {'Due now':>8} {'Posted':>8} {'Errors':>8} {'Manual':>8}")
    print("  " + "-" * 56)
    for p, counts in sorted(by_platform.items()):
        print(f"  {p:<14} {counts['pending']:>8} {counts['due']:>8} {counts['posted']:>8} {counts['error']:>8} {counts['manual']:>8}")

    print(f"\n  Total entries: {len(cal)}")
    print(f"  Checked at: {now.strftime('%Y-%m-%d %H:%M')} UTC")


def main():
    parser = argparse.ArgumentParser(
        description="Viral launch calendar poster — posts due entries across Twitter, Reddit, Instagram."
    )
    parser.add_argument("--post-due", action="store_true",
                        help="Post all entries with scheduled <= now and status=pending")
    parser.add_argument("--dry-run", action="store_true",
                        help="Preview without actually posting or updating the calendar")
    parser.add_argument("--status", action="store_true",
                        help="Show credential status and pending post counts")
    args = parser.parse_args()

    if args.status:
        show_status()
    elif args.post_due:
        post_due(dry_run=args.dry_run)
    else:
        parser.print_help()


if __name__ == "__main__":
    def _workflow_entry():
        # Re-parse args here so post_due() result flows back to harness for quality eval
        import argparse as _ap
        _parser = _ap.ArgumentParser()
        _parser.add_argument("--post-due", action="store_true")
        _parser.add_argument("--dry-run", action="store_true")
        _parser.add_argument("--status", action="store_true")
        _args = _parser.parse_args()
        if _args.status:
            show_status()
            return {"status": "ok", "action": "status"}
        elif _args.post_due:
            return post_due(dry_run=_args.dry_run)
        else:
            _parser.print_help()
            return {"status": "ok", "action": "help"}
    workflow_execute(
        workflow_name="viral_poster",
        action=_workflow_entry,
        task_type="judgment",
        actor="cli",
    )
