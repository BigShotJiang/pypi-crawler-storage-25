"""
GRC Nightly Compliance Snapshot — calls save_compliance_snapshot() directly via
the grc Python package and logs the result. Runs nightly at 2am to capture
compliance trend data.

The previous implementation POSTed to the GRC HTTP API (localhost:8002), which
meant the snapshot silently failed whenever the server was not running. This
version imports the GRC package directly so no server dependency is required.

GRC_PROJECT_DIR environment variable can override the default project path.

Usage:
    python grc_snapshot.py              # run snapshot, log result
    python grc_snapshot.py --dry-run    # print what would happen, no write
    python grc_snapshot.py --verbose    # detailed output
"""

import argparse
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

# Route execution through the harness
from aibrain.core.workflow_base import workflow_execute

# --- Config ---

GRC_PROJECT_DIR = Path(
    os.environ.get("GRC_PROJECT_DIR",
                   str(Path(os.environ.get("AIBRAIN_ROOT", ".")).parent / "grc"))
)


def _get_grc_modules():
    """Import grc.db and grc.report_generator, adding the project to sys.path if needed."""
    grc_path = str(GRC_PROJECT_DIR)
    if grc_path not in sys.path:
        sys.path.insert(0, grc_path)
    from grc.db import get_connection  # noqa: PLC0415
    from grc.report_generator import save_compliance_snapshot  # noqa: PLC0415
    return get_connection, save_compliance_snapshot


def run(dry_run: bool = False, verbose: bool = False) -> dict:
    """Save a compliance snapshot row directly via the grc package. Returns dict with status and data."""
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")

    if dry_run:
        if verbose:
            print(f"GRC SNAPSHOT (dry-run) — {now}")
            print(f"  Would write snapshot to GRC DB at: {GRC_PROJECT_DIR / 'grc.db'}")
        return {
            "status": "dry_run",
            "timestamp": now,
            "db_path": str(GRC_PROJECT_DIR / "grc.db"),
            "snapshot": None,
        }

    try:
        get_connection, save_compliance_snapshot = _get_grc_modules()
        conn = get_connection()
        try:
            snapshot = save_compliance_snapshot(conn)
            conn.commit()
        finally:
            conn.close()

        status = "success"
        if verbose:
            print(f"GRC SNAPSHOT — {now}")
            print(f"  DB: {GRC_PROJECT_DIR / 'grc.db'}")
            print(f"  Snapshot: {snapshot}")

    except ImportError as exc:
        status = "import_error"
        snapshot = {"error": str(exc)}
        print(f"[grc_snapshot] Import error (is GRC_PROJECT_DIR set correctly?): {exc}")
    except Exception as exc:  # noqa: BLE001
        status = "error"
        snapshot = {"error": str(exc)}
        print(f"[grc_snapshot] Unexpected error: {exc}")

    result = {
        "status": status,
        "timestamp": now,
        "db_path": str(GRC_PROJECT_DIR / "grc.db"),
        "snapshot": snapshot,
    }

    if not verbose and status == "success":
        print(f"[grc_snapshot] ok — {now}")
    elif not verbose and status != "dry_run":
        print(f"[grc_snapshot] {status} — {now}")

    return result


if __name__ == "__main__":
    def _workflow_entry():
        parser = argparse.ArgumentParser(
            description="GRC Nightly Compliance Snapshot — write directly to GRC DB"
        )
        parser.add_argument("--dry-run", action="store_true", help="Print what would happen, no write")
        parser.add_argument("--verbose", action="store_true", help="Detailed output")
        args = parser.parse_args()

        if args.dry_run:
            args.verbose = True

        result = run(dry_run=args.dry_run, verbose=args.verbose)

        if not args.verbose:
            print(f"[{result['status']}] grc_snapshot done")

    workflow_execute(
        workflow_name="grc_snapshot",
        action=_workflow_entry,
        task_type="deterministic",
        actor="cli",
    )
