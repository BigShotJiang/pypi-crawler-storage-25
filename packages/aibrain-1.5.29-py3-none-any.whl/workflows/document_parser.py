#!/usr/bin/env python3
"""AIBrain Workflow: Document Parser — parse PDF, DOCX, PPTX, images via Docling."""

import argparse
import datetime
import hashlib
import json
import os
import sqlite3
import sys
import urllib.request
from pathlib import Path

# P0-1 backfill (2026-04-11): route workflow execution through the harness
from aibrain.core.workflow_base import workflow_execute

# ---------------------------------------------------------------------------
# Config & DB helpers
# ---------------------------------------------------------------------------

from aibrain_db import AIBRAIN_ROOT, get_db
_cfg_path = AIBRAIN_ROOT / "config.json"
CONFIG = json.loads(_cfg_path.read_text()) if _cfg_path.exists() else {}
def _find_db():
    """Find best DB path, checking both new and legacy names."""
    for name in ["aibrain.db"]:
        p = AIBRAIN_ROOT / name
        if p.exists():
            return str(p)
    configured = CONFIG.get("db_path")
    if configured and Path(configured).exists():
        return configured
    mem_db = AIBRAIN_ROOT / "memory" / "memory.db"
    if mem_db.exists():
        return str(mem_db)
    return str(AIBRAIN_ROOT / "aibrain.db")

MEMORY_DB = CONFIG.get("db_path", _find_db())
API_BASE = os.environ.get("AIBRAIN_API", os.environ.get("AIBRAIN_API", "http://localhost:8001/api/agent"))

SUPPORTED_EXTENSIONS = {".pdf", ".docx", ".pptx", ".png", ".jpg", ".jpeg", ".tiff", ".bmp"}

# Max characters to store per document (avoid bloating the DB)
MAX_CONTENT_LENGTH = 50_000


def log_activity(action, detail="", status="ok"):
    """Log activity to AIBrain API."""
    try:
        data = json.dumps({
            "action": action, "category": "productivity",
            "detail": detail, "status": status,
        }).encode()
        req = urllib.request.Request(
            f"{API_BASE}/activity", data=data,
            headers={"Content-Type": "application/json"},
        )
        urllib.request.urlopen(req, timeout=5)
    except Exception:
        pass


def get_db():
    db = get_db()
    db.execute("PRAGMA journal_mode=wal")
    db.row_factory = sqlite3.Row
    return db


def load_state(name):
    try:
        db = get_db()
        row = db.execute(
            "SELECT content FROM memories WHERE name=? AND active=1",
            (f"workflow_state:{name}",),
        ).fetchone()
        db.close()
        return json.loads(row["content"]) if row else {}
    except Exception:
        return {}


def save_state(name, state):
    db = get_db()
    try:
        now = datetime.datetime.now().isoformat()
        existing = db.execute(
            "SELECT id FROM memories WHERE name=? AND active=1",
            (f"workflow_state:{name}",),
        ).fetchone()
        if existing:
            db.execute("UPDATE memories SET content=?, updated=? WHERE id=?",
                       (json.dumps(state), now, existing["id"]))
        else:
            db.execute(
                "INSERT INTO memories (name,type,tags,content,created,updated,active) VALUES (?,?,?,?,?,?,1)",
                (f"workflow_state:{name}", "reference", "workflow,state",
                 json.dumps(state), now, now),
            )
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


def store_memory(name, content, tags):
    """Store parsed document content as a reference memory."""
    db = get_db()
    now = datetime.datetime.now().isoformat()
    # Check if this document was already stored (by name)
    existing = db.execute(
        "SELECT id FROM memories WHERE name=? AND active=1",
        (name,),
    ).fetchone()
    if existing:
        db.execute("UPDATE memories SET content=?, tags=?, updated=? WHERE id=?",
                   (content, tags, now, existing["id"]))
    else:
        db.execute(
            "INSERT INTO memories (name,type,tags,content,created,updated,active) VALUES (?,?,?,?,?,?,1)",
            (name, "reference", tags, content, now, now),
        )
    db.commit()
    db.close()


# ---------------------------------------------------------------------------
# File hashing for change detection
# ---------------------------------------------------------------------------

def file_hash(filepath):
    """SHA-256 of file contents for dedup / change detection."""
    h = hashlib.sha256()
    with open(filepath, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


# ---------------------------------------------------------------------------
# Docling integration
# ---------------------------------------------------------------------------

def ensure_docling():
    """Import docling, exit gracefully if not installed."""
    try:
        from docling.document_converter import DocumentConverter
        return DocumentConverter
    except ImportError:
        print(
            "docling not installed — document_parser skipped (no-op).\n"
            "To enable: pip install docling",
            file=sys.stderr,
        )
        sys.exit(0)


def parse_document(filepath, DocumentConverter):
    """Parse a single document and return extracted metadata + text."""
    filepath = Path(filepath).resolve()
    if not filepath.exists():
        print(f"File not found: {filepath}", file=sys.stderr)
        return None

    ext = filepath.suffix.lower()
    if ext not in SUPPORTED_EXTENSIONS:
        print(f"Unsupported format: {ext} (supported: {', '.join(sorted(SUPPORTED_EXTENSIONS))})",
              file=sys.stderr)
        return None

    print(f"Parsing: {filepath}")
    converter = DocumentConverter()
    result = converter.convert(str(filepath))
    doc = result.document

    # Extract text content
    text = doc.export_to_markdown()
    if len(text) > MAX_CONTENT_LENGTH:
        text = text[:MAX_CONTENT_LENGTH] + "\n\n[... truncated ...]"

    # Extract metadata
    title = ""
    dates = []
    names = []

    # Try to get title from document metadata or first heading
    if hasattr(doc, "title") and doc.title:
        title = doc.title
    elif hasattr(doc, "name") and doc.name:
        title = doc.name

    # If no title from metadata, use filename
    if not title:
        title = filepath.stem

    # Build summary (first ~500 chars of text content)
    summary_text = text[:500].strip()
    if len(text) > 500:
        summary_text += "..."

    return {
        "filepath": str(filepath),
        "filename": filepath.name,
        "extension": ext,
        "title": title,
        "summary": summary_text,
        "text": text,
        "file_hash": file_hash(filepath),
        "parsed_at": datetime.datetime.now().isoformat(),
        "size_bytes": filepath.stat().st_size,
    }


# ---------------------------------------------------------------------------
# Watch mode: scan directories for new/changed documents
# ---------------------------------------------------------------------------

def scan_directories(watch_dirs, parsed_hashes, DocumentConverter, dry_run=False):
    """Scan configured directories for new or changed documents."""
    results = []

    for dir_path in watch_dirs:
        # Expand ~ and resolve
        dir_path = Path(dir_path).expanduser().resolve()
        if not dir_path.is_dir():
            print(f"Watch directory not found, skipping: {dir_path}")
            continue

        print(f"Scanning: {dir_path}")
        for fpath in dir_path.iterdir():
            if not fpath.is_file():
                continue
            if fpath.suffix.lower() not in SUPPORTED_EXTENSIONS:
                continue

            fhash = file_hash(fpath)
            if fhash in parsed_hashes:
                continue  # Already parsed, no changes

            print(f"  New/changed: {fpath.name}")
            if dry_run:
                results.append({"filepath": str(fpath), "status": "would_parse"})
                continue

            parsed = parse_document(fpath, DocumentConverter)
            if parsed:
                results.append(parsed)
                parsed_hashes[fhash] = {
                    "filepath": str(fpath),
                    "parsed_at": parsed["parsed_at"],
                }

    return results


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(description="AIBrain Document Parser — Docling-powered")
    parser.add_argument("--file", type=str, help="Parse a specific file (direct mode)")
    parser.add_argument("--dry-run", action="store_true", help="Show what would be parsed without storing")
    args = parser.parse_args()

    DocumentConverter = ensure_docling()

    # Load state (tracks already-parsed file hashes)
    state = load_state("document_parser")
    parsed_hashes = state.get("parsed_hashes", {})

    if args.file:
        # --- Direct mode: parse a single file ---
        parsed = parse_document(args.file, DocumentConverter)
        if not parsed:
            sys.exit(1)

        print(f"\nTitle: {parsed['title']}")
        print(f"Size: {parsed['size_bytes']:,} bytes")
        print(f"Summary: {parsed['summary'][:200]}")
        print(f"Text length: {len(parsed['text']):,} chars")

        if args.dry_run:
            print("\n[dry-run] Would store as memory. Content preview:")
            print(parsed["text"][:500])
        else:
            # Store as memory
            mem_name = f"doc:{parsed['filename']}"
            tags = f"document,parsed,{parsed['filename']}"
            content = json.dumps({
                "title": parsed["title"],
                "summary": parsed["summary"],
                "text": parsed["text"],
                "source_file": parsed["filepath"],
                "parsed_at": parsed["parsed_at"],
                "size_bytes": parsed["size_bytes"],
            })
            store_memory(mem_name, content, tags)
            print(f"\nStored as memory: {mem_name}")

            # Update state
            parsed_hashes[parsed["file_hash"]] = {
                "filepath": parsed["filepath"],
                "parsed_at": parsed["parsed_at"],
            }
            save_state("document_parser", {
                "last_run": datetime.datetime.now().isoformat(),
                "mode": "direct",
                "parsed_hashes": parsed_hashes,
                "total_parsed": len(parsed_hashes),
            })

    else:
        # --- Watch mode: scan configured directories ---
        watch_dirs = CONFIG.get("document_watch_dirs", [])
        if not watch_dirs:
            print("No watch directories configured. Set 'document_watch_dirs' in config.json", file=sys.stderr)
            print("Or use --file to parse a specific document.", file=sys.stderr)
            sys.exit(1)

        results = scan_directories(watch_dirs, parsed_hashes, DocumentConverter, dry_run=args.dry_run)

        if not results:
            print("No new documents found.")
        else:
            stored = 0
            for parsed in results:
                if args.dry_run:
                    print(f"  [dry-run] Would parse: {parsed['filepath']}")
                    continue

                mem_name = f"doc:{parsed['filename']}"
                tags = f"document,parsed,{parsed['filename']}"
                content = json.dumps({
                    "title": parsed["title"],
                    "summary": parsed["summary"],
                    "text": parsed["text"],
                    "source_file": parsed["filepath"],
                    "parsed_at": parsed["parsed_at"],
                    "size_bytes": parsed["size_bytes"],
                })
                store_memory(mem_name, content, tags)
                stored += 1
                print(f"  Stored: {mem_name}")

            if not args.dry_run:
                print(f"\nParsed and stored {stored} document(s).")

        # Save state
        if not args.dry_run:
            save_state("document_parser", {
                "last_run": datetime.datetime.now().isoformat(),
                "mode": "watch",
                "dirs_scanned": len(watch_dirs),
                "new_documents": len(results),
                "parsed_hashes": parsed_hashes,
                "total_parsed": len(parsed_hashes),
            })

    log_activity("document_parser", f"Parsed {len(parsed_hashes)} document(s), mode={'direct' if args.file else 'watch'}")


if __name__ == "__main__":
    # P0-1 backfill: entry point routes through harness via workflow_execute
    def _workflow_entry():
        main()
    workflow_execute(
        workflow_name='document_parser',
        action=_workflow_entry,
        task_type='simple',
        actor='cli',
    )
