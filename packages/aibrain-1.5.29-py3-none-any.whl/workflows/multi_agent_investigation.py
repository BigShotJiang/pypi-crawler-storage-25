#!/usr/bin/env python3
"""AIBrain Workflow: Multi-Agent Code Investigation

Three-phase adversarial investigation process for code issues:
  Phase 1: Three independent agents (Liaison, Champion, Lead Engineer) each
           audit the target independently and propose fixes — no cross-knowledge.
  Phase 2: Liaison and Champion each independently consolidate all three Phase 1
           reports into a single unified, prioritized recommendation — blind to
           each other's consolidation.
  Phase 3 (manual): Decker takes both Phase 2 outputs to external LLMs (GPT-4,
           Grok) for final evaluation.

Usage:
    python multi_agent_investigation.py --target "tier gate enforcement" --files "backend/tiers.py,backend/aibrain_api.py"
    python multi_agent_investigation.py --target "authentication bypass" --files "backend/security.py"
    python multi_agent_investigation.py --status   # check status of active investigation
"""

import argparse
import json
import os
import sys
from datetime import datetime
from pathlib import Path

from aibrain.core.workflow_base import workflow_execute
from aibrain_db import AIBRAIN_ROOT, get_db

# Agent IDs
_LIAISON_ID = "bwHDCnvlGFY"
_CHAMPION_ID = "rrSo0lFItV0"
_LEAD_ENG_ID = "CDTYrHYkyH8"

_COMPANY_ID = "GT_LRWrEBQQ"
_WORKING_DIR = str(AIBRAIN_ROOT)

_INVESTIGATION_STATE_KEY = "multi_agent_investigation_state"


def _get_companies():
    from aibrain.core.companies import create_task, checkout_task, complete_task, get_task
    return create_task, checkout_task, complete_task, get_task


def _save_state(state: dict):
    db = get_db()
    db.execute(
        "INSERT OR REPLACE INTO config (key, value) VALUES (?, ?)",
        (_INVESTIGATION_STATE_KEY, json.dumps(state))
    )
    db.commit()


def _load_state() -> dict:
    db = get_db()
    row = db.execute(
        "SELECT value FROM config WHERE key = ?", (_INVESTIGATION_STATE_KEY,)
    ).fetchone()
    return json.loads(row[0]) if row else {}


def _phase1_description(role: str, target: str, files: str, extra: str = "") -> str:
    role_specific = {
        "liaison": (
            "You are the Special Liaison — an independent auditor with elevated authority. "
            "Be adversarial. Assume the worst-case user is actively trying to exploit every gap."
        ),
        "champion": (
            "You are Champion — an Intel Agent V2 with deep analytical expertise. "
            "Apply structured intelligence methodology. Look for what others miss."
        ),
        "lead_engineer": (
            "You are the Lead Engineer with full codebase access. "
            "Read the source code precisely. Find exact file:line references for every finding."
        ),
    }
    intro = role_specific.get(role, "You are an expert code investigator.")
    return f"""{intro}

INVESTIGATION TARGET: {target}
WORKING DIRECTORY: {_WORKING_DIR}
KEY FILES: {files}

INSTRUCTIONS:
- Do NOT reference any prior analysis — read the source code yourself
- Form your own independent findings
- Be thorough, specific, and adversarial

DELIVERABLE:
1. Every issue found — exact file:line reference, severity, description
2. Every gap that should be addressed but isn't
3. Concrete proposed fix for each finding — exact file, function, line, change required
4. Severity rating and business impact assessment

{extra}

Return a comprehensive, self-contained report."""


def _phase2_description(role: str, target: str, phase1_paths: list) -> str:
    paths_str = "\n".join(f"- {p}" for p in phase1_paths)
    role_specific = {
        "liaison": (
            "You are the Special Liaison — adjudicating three independent investigations. "
            "Where investigators disagree, read the source and settle it definitively."
        ),
        "champion": (
            "You are Champion — independently consolidating three investigations. "
            "Do not be influenced by any other consolidation effort."
        ),
    }
    intro = role_specific.get(role, "You are an expert code investigator consolidating three reports.")
    return f"""{intro}

INVESTIGATION TOPIC: {target}
WORKING DIRECTORY: {_WORKING_DIR}

Phase 1 reports (read ALL THREE before writing):
{paths_str}

YOUR TASK:
1. Cross-reference findings — rate confidence: 3/3 (all agree), 2/3, 1/3 (solo finding)
2. For any 1/3 finding, verify it yourself by reading the actual source file:line
3. Produce a UNIFIED fix list: de-duplicate, resolve contradictions
4. For any disagreements: read the source and adjudicate
5. Find any gaps ALL THREE missed (do a final independent check)

DELIVERABLE FORMAT:
- Section A: Verified findings (with confidence rating + source verification for 1/3 cases)
- Section B: De-duplicated fix list with exact file:line:change for each
- Section C: Carve-outs that must NOT be changed (with reasoning)
- Section D: Prioritized implementation order (P1/P2/P3) with business rationale
- Section E: Gaps none of the three found (your independent additions)
- Section F: Overall severity rating + revenue/security/stability impact

Be adversarial. Adjudicate, don't average.

Return ONLY the full consolidation report text."""


def run_investigation(target: str, files: str):
    create_task, checkout_task, complete_task, get_task = _get_companies()

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_dir = Path(_WORKING_DIR) / "tmp" / f"investigation_{timestamp}"
    output_dir.mkdir(parents=True, exist_ok=True)

    print(f"\n=== MULTI-AGENT INVESTIGATION: {target} ===")
    print(f"Output directory: {output_dir}")
    print(f"Timestamp: {timestamp}\n")

    # --- PHASE 1 ---
    print("PHASE 1: Spawning three independent investigators...")

    liaison_task = create_task(
        _COMPANY_ID,
        title=f"PHASE1/LIAISON — Independent investigation: {target[:60]}",
        description=_phase1_description("liaison", target, files),
        assignee_agent_id=_LIAISON_ID,
        priority="critical"
    )
    checkout_task(liaison_task["id"], _LIAISON_ID)
    print(f"  Liaison task:       {liaison_task['id']}")

    champion_task = create_task(
        _COMPANY_ID,
        title=f"PHASE1/CHAMPION — Independent investigation: {target[:60]}",
        description=_phase1_description("champion", target, files),
        assignee_agent_id=_CHAMPION_ID,
        priority="critical"
    )
    checkout_task(champion_task["id"], _CHAMPION_ID)
    print(f"  Champion task:      {champion_task['id']}")

    le_task = create_task(
        _COMPANY_ID,
        title=f"PHASE1/LEAD_ENG — Independent investigation: {target[:60]}",
        description=_phase1_description("lead_engineer", target, files),
        assignee_agent_id=_LEAD_ENG_ID,
        priority="critical"
    )
    checkout_task(le_task["id"], _LEAD_ENG_ID)
    print(f"  Lead Engineer task: {le_task['id']}")

    state = {
        "target": target,
        "files": files,
        "timestamp": timestamp,
        "output_dir": str(output_dir),
        "phase": 1,
        "phase1": {
            "liaison_task_id": liaison_task["id"],
            "champion_task_id": champion_task["id"],
            "le_task_id": le_task["id"],
        }
    }
    _save_state(state)

    print(f"""
PHASE 1 tasks created. Spawn three parallel agents with these task IDs:
  Liaison:       {liaison_task['id']} (agent {_LIAISON_ID})
  Champion:      {champion_task['id']} (agent {_CHAMPION_ID})
  Lead Engineer: {le_task['id']} (agent {_LEAD_ENG_ID})

After all three complete, run:
  python multi_agent_investigation.py --phase2 --timestamp {timestamp}
""")
    return state


def run_phase2(timestamp: str):
    state = _load_state()
    if not state or state.get("timestamp") != timestamp:
        print(f"ERROR: No active investigation with timestamp {timestamp}")
        sys.exit(1)

    output_dir = Path(state["output_dir"])
    target = state["target"]
    files = state["files"]
    p1 = state["phase1"]

    create_task, checkout_task, complete_task, get_task = _get_companies()

    print(f"\n=== PHASE 2: CONSOLIDATION — {target} ===")

    # Collect Phase 1 output paths
    phase1_paths = [
        output_dir / "phase1_liaison.md",
        output_dir / "phase1_champion.md",
        output_dir / "phase1_lead_engineer.md",
    ]

    # Verify phase1 outputs exist
    for p in phase1_paths:
        if not p.exists():
            print(f"WARNING: {p} not found — Phase 2 may be incomplete")

    liaison_p2 = create_task(
        _COMPANY_ID,
        title=f"PHASE2/LIAISON — Consolidate investigations: {target[:55]}",
        description=_phase2_description("liaison", target, [str(p) for p in phase1_paths]),
        assignee_agent_id=_LIAISON_ID,
        priority="critical"
    )
    checkout_task(liaison_p2["id"], _LIAISON_ID)
    print(f"  Liaison Phase 2 task:  {liaison_p2['id']}")

    champion_p2 = create_task(
        _COMPANY_ID,
        title=f"PHASE2/CHAMPION — Consolidate investigations: {target[:55]}",
        description=_phase2_description("champion", target, [str(p) for p in phase1_paths]),
        assignee_agent_id=_CHAMPION_ID,
        priority="critical"
    )
    checkout_task(champion_p2["id"], _CHAMPION_ID)
    print(f"  Champion Phase 2 task: {champion_p2['id']}")

    state["phase"] = 2
    state["phase2"] = {
        "liaison_task_id": liaison_p2["id"],
        "champion_task_id": champion_p2["id"],
    }
    _save_state(state)

    print(f"""
PHASE 2 tasks created. Spawn two parallel agents (blind to each other):
  Liaison Phase 2:  {liaison_p2['id']} (agent {_LIAISON_ID})
  Champion Phase 2: {champion_p2['id']} (agent {_CHAMPION_ID})

Outputs will be saved to:
  {output_dir}/phase2_liaison.md
  {output_dir}/phase2_champion.md

After both complete, deliver both files to external LLMs (GPT-4, Grok) for Phase 3 evaluation.
""")
    return state


def show_status():
    state = _load_state()
    if not state:
        print("No active investigation.")
        return
    print(f"\n=== ACTIVE INVESTIGATION ===")
    print(f"Target:    {state.get('target')}")
    print(f"Files:     {state.get('files')}")
    print(f"Phase:     {state.get('phase')}")
    print(f"Timestamp: {state.get('timestamp')}")
    print(f"Output:    {state.get('output_dir')}")
    if state.get("phase1"):
        p1 = state["phase1"]
        print(f"\nPhase 1 tasks:")
        print(f"  Liaison:       {p1.get('liaison_task_id')}")
        print(f"  Champion:      {p1.get('champion_task_id')}")
        print(f"  Lead Engineer: {p1.get('le_task_id')}")
    if state.get("phase2"):
        p2 = state["phase2"]
        print(f"\nPhase 2 tasks:")
        print(f"  Liaison:  {p2.get('liaison_task_id')}")
        print(f"  Champion: {p2.get('champion_task_id')}")


def main():
    parser = argparse.ArgumentParser(description="Multi-agent code investigation workflow")
    parser.add_argument("--target", help="What to investigate (e.g. 'tier gate enforcement')")
    parser.add_argument("--files", help="Comma-separated key files to examine")
    parser.add_argument("--phase2", action="store_true", help="Run Phase 2 consolidation")
    parser.add_argument("--timestamp", help="Timestamp from Phase 1 run (required for --phase2)")
    parser.add_argument("--status", action="store_true", help="Show status of active investigation")
    args = parser.parse_args()

    if args.status:
        show_status()
        return

    if args.phase2:
        if not args.timestamp:
            print("ERROR: --phase2 requires --timestamp")
            sys.exit(1)
        workflow_execute(
            workflow_name="multi_agent_investigation",
            action=lambda: run_phase2(args.timestamp),
            task_type="judgment",
            actor="cli",
        )
    elif args.target:
        files = args.files or "backend/"
        workflow_execute(
            workflow_name="multi_agent_investigation",
            action=lambda: run_investigation(args.target, files),
            task_type="judgment",
            actor="cli",
        )
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
