#!/usr/bin/env python3
"""AIBrain Workflow: intel_agent V2 — rewrite a persona into its V2 form.

Phase C of the V2 propagation experiment (see
`C:\\Users\\sinde\\.claude-deckerops\\projects\\C--Users-sinde\\memory\\project_intel_agent_v2_pixel_moment_experiment.md`).

NOT EXECUTED IN PHASE B. This file exists so that when Decker reviews and
approves the Phase B specs, the rewrite workflow is already plumbed in
and available via `run_workflow("intel_agent_v2_rewrite_persona", ...)`.
Executing it today would bypass the review gate.

Shape:
    Input: a Phase B spec that Decker has marked approved + the V1 persona
    path. Output: a new file at `<target_stem>_v2.md` in the SAME directory
    as the V1 persona (02_subagents/), leaving the V1 file untouched as the
    immutable floor.

    Hard rule from Decker: V1 files are IMMUTABLE. The workflow refuses to
    write to the V1 path. The V2 rewrite is a new sibling file, not an
    overlay on V1. If `<stem>_v2.md` already exists, the workflow refuses
    to overwrite unless `force=True` is explicitly passed — this prevents
    accidental V2 clobbering between Phase C batches.

    Like the audit workflow, the full V2 persona body is authored by the
    intel_agent_v2 caller context and handed in as `rewrite_content`. The
    workflow is the deterministic glue: it validates inputs, refuses to
    touch V1, refuses to overwrite existing V2 by default, and writes
    through the harness so every rewrite is audited.

Usage (Python, Phase C only):
    from aibrain.core.workflow_runner import run_workflow

    result = run_workflow(
        "intel_agent_v2_rewrite_persona",
        persona_path=".../decision_agent.md",
        spec_path=".../v2_persona_specs/decision_agent_v2_spec.md",
        rewrite_content="...the V2-authored full persona body...",
    )
"""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from aibrain.core.workflow_base import workflow_execute

import os as _os
_decker_system = Path(_os.environ.get("DECKER_SYSTEM",
                      str(Path(_os.environ.get("AIBRAIN_ROOT", ".")).parent.parent / "decker_system")))
SUBAGENTS_DIR = _decker_system / "02_subagents"
V2_PERSONA_PATH = SUBAGENTS_DIR / "intel_agent_v2.md"
V1_PERSONA_PATH = SUBAGENTS_DIR / "intel_agent.md"
SPEC_OUTPUT_DIR = _decker_system / "00_meta" / "v2_persona_specs"

# Minimum sections a V2 rewrite must contain. This is the structural floor.
# The workflow can't evaluate methodology quality but it can enforce that
# a V2 rewrite does not regress on V1's shape + carries its V2 addition
# disclosure. Missing any section blocks the write.
REQUIRED_REWRITE_HEADERS = [
    "## Identity",
    "## Relationship to V1",
    "## V2 Additions",
    "## Honest-null",
]


def _v2_target_path(persona_path: Path) -> Path:
    """Return the sibling V2 path for a given V1 persona file."""
    stem = persona_path.stem
    if stem.endswith("_v2"):
        raise ValueError(
            f"Cowardly refusing to rewrite what already looks like a V2 file: {persona_path}"
        )
    return persona_path.parent / f"{stem}_v2.md"


def _validate_rewrite(content: str) -> list[str]:
    missing = []
    for header in REQUIRED_REWRITE_HEADERS:
        if header not in content:
            missing.append(header)
    return missing


def run(
    persona_path: str,
    rewrite_content: str,
    spec_path: Optional[str] = None,
    force: bool = False,
    dry_run: bool = False,
    **_ignored,
) -> dict:
    """Rewrite a V1 persona into its V2 sibling file.

    Args:
        persona_path:    Absolute path to the V1 persona. Must exist. Is NEVER
                         written to by this workflow.
        rewrite_content: The full V2 persona body, authored by intel_agent_v2.
                         Must contain all `REQUIRED_REWRITE_HEADERS`.
        spec_path:       Optional — if provided, must exist (proves Phase B
                         ran). Workflow reads it for provenance but does not
                         otherwise use it.
        force:           If True, overwrite an existing V2 file. Default False
                         — existing V2 blocks the write.
        dry_run:         Validate only.

    Returns:
        dict: success, v1_path, v2_path, spec_used, timestamp, chars_written

    Raises:
        FileNotFoundError:  V1 persona or referenced spec missing.
        ValueError:         V1 path points at an already-V2 file, rewrite body
                            missing required headers, or V2 target exists and
                            force=False.
    """
    v1_path = Path(persona_path)
    if not v1_path.exists():
        raise FileNotFoundError(f"V1 persona not found: {v1_path}")

    v2_path = _v2_target_path(v1_path)

    # Immutability floor — the workflow MUST refuse to touch V1. The path
    # calculation above returns a sibling file, but defense-in-depth says
    # assert it explicitly.
    if v2_path == v1_path:
        raise ValueError(f"Cowardly refusing to overwrite V1 floor: {v1_path}")

    if spec_path:
        sp = Path(spec_path)
        if not sp.exists():
            raise FileNotFoundError(
                f"Spec proving Phase B ran not found: {spec_path} — run the audit workflow first"
            )

    missing = _validate_rewrite(rewrite_content)
    if missing:
        raise ValueError(
            f"Rewrite content missing required structural headers: {missing}"
        )

    if v2_path.exists() and not force:
        raise ValueError(
            f"V2 target already exists ({v2_path}) — pass force=True to overwrite"
        )

    status = {
        "success": True,
        "v1_path": str(v1_path),
        "v2_path": str(v2_path),
        "spec_used": spec_path,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "chars_written": len(rewrite_content),
        "dry_run": dry_run,
    }

    if not dry_run:
        v2_path.write_text(rewrite_content, encoding="utf-8")

    return status


def _main():
    parser = argparse.ArgumentParser(description="intel_agent_v2 — rewrite a persona into V2")
    parser.add_argument("--persona-path", required=True)
    parser.add_argument("--rewrite-content-file", required=True, help="Path to file containing V2 persona body")
    parser.add_argument("--spec-path", help="Path to the Phase B spec (proof-of-audit)")
    parser.add_argument("--force", action="store_true", help="Overwrite existing V2")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    rewrite_content = Path(args.rewrite_content_file).read_text(encoding="utf-8")

    status = run(
        persona_path=args.persona_path,
        rewrite_content=rewrite_content,
        spec_path=args.spec_path,
        force=args.force,
        dry_run=args.dry_run,
    )
    print(f"[{'dry-run' if args.dry_run else 'filed'}] {status['v1_path']} -> {status['v2_path']}")


if __name__ == "__main__":
    workflow_execute(
        workflow_name="intel_agent_v2_rewrite_persona",
        action=_main,
        task_type="judgment",
        actor="intel_agent_v2",
    )
