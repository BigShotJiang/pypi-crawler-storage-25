"""
dream — nightly memory consolidation (CLS REM phase).
Deduplicates near-duplicate memories, updates importance scores,
prunes low-importance old memories, logs consolidation stats.
No LLM calls. Pure DB reads + writes.

Relationship to memory_consolidation.py
----------------------------------------
memory_consolidation.py is the heavyweight weekly sleep cycle:
  cluster (embedding similarity) → merge → Ebbinghaus decay → archive → rebuild.

dream.py is the lightweight nightly REM pass:
  1. PRUNE   — mark memories with importance < 0.3 AND age > 30 days as archived
  2. DEDUP   — exact (type + name) duplicates: keep highest importance, archive rest
  3. DECAY   — importance * 0.9 for memories not accessed in 60+ days (gradual forgetting)
  4. LOG     — write stats to execution_log and print summary

Design choices:
  - Idempotent: safe to re-run, already-archived rows are skipped
  - No embeddings, no LLM: pure SQL + Python arithmetic
  - Nightly cadence (02:00): complements weekly memory_consolidation (Sunday 22:13)

Usage:
    python -m aibrain.core.workflow_runner dream
    python workflows/dream.py
    python workflows/dream.py --dry-run
    python workflows/dream.py --verbose
"""

import argparse
import json
import logging
import sys
from datetime import datetime, timezone
from pathlib import Path

# Harness wrapper — routes through audit/eval/model-routing infrastructure
from aibrain.core.workflow_base import workflow_execute

# --- Path setup ---
from aibrain_db import AIBRAIN_ROOT
if str(AIBRAIN_ROOT) not in sys.path:
    sys.path.insert(0, str(AIBRAIN_ROOT))

import aibrain_db

logger = logging.getLogger("aibrain.dream")

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

PRUNE_IMPORTANCE_THRESHOLD = 0.3   # memories below this importance are prune candidates
PRUNE_AGE_DAYS = 30                # must also be older than this many days
DECAY_UNACCESSED_DAYS = 60         # memories not accessed in this many days get decayed
DECAY_RATE = 0.9                   # multiply importance by this factor per decay pass


# ---------------------------------------------------------------------------
# Step 1: PRUNE
# ---------------------------------------------------------------------------

def prune_weak_old_memories(db, dry_run: bool = False) -> int:
    """Archive memories with importance < PRUNE_IMPORTANCE_THRESHOLD AND age > PRUNE_AGE_DAYS.

    Only touches active memories with status='active'. Already-archived rows are skipped.
    Returns count of memories archived.
    """
    rows = db.execute("""
        SELECT id, importance, created
        FROM memories
        WHERE active = 1
          AND status = 'active'
          AND importance IS NOT NULL
          AND importance < ?
    """, (PRUNE_IMPORTANCE_THRESHOLD,)).fetchall()

    now = datetime.now(timezone.utc)
    to_archive = []

    for row in rows:
        mem_id, importance, created_str = row
        if not created_str:
            continue
        try:
            dt_str = str(created_str).replace("T", " ").split(".")[0][:19]
            created_dt = datetime.strptime(dt_str, "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc)
            age_days = (now - created_dt).total_seconds() / 86400.0
        except (ValueError, TypeError):
            continue

        if age_days >= PRUNE_AGE_DAYS:
            to_archive.append(mem_id)

    if not dry_run and to_archive:
        placeholders = ",".join("?" * len(to_archive))
        db.execute(
            f"UPDATE memories SET status = 'archived' WHERE id IN ({placeholders})",  # noqa:SQL-FSTRING
            to_archive,
        )
        db.commit()

    logger.info("PRUNE: %d memories archived (importance < %.1f AND age > %d days)%s",
                len(to_archive), PRUNE_IMPORTANCE_THRESHOLD, PRUNE_AGE_DAYS,
                " [dry-run]" if dry_run else "")
    return len(to_archive)


# ---------------------------------------------------------------------------
# Step 2: DEDUP
# ---------------------------------------------------------------------------

def dedup_exact_name_memories(db, dry_run: bool = False) -> int:
    """For each (type, name) group with 2+ active memories, keep the highest-importance
    entry and archive the rest.

    Returns count of duplicate memories archived.
    """
    rows = db.execute("""
        SELECT id, type, name, importance, created
        FROM memories
        WHERE active = 1
          AND status = 'active'
          AND name IS NOT NULL
          AND name != ''
        ORDER BY type, name, importance DESC
    """).fetchall()

    # Group by (type, name)
    groups: dict[tuple, list] = {}
    for row in rows:
        mem_id, mem_type, name, importance, created = row
        key = (mem_type or "", name or "")
        groups.setdefault(key, []).append(mem_id)

    to_archive = []
    for key, ids in groups.items():
        if len(ids) > 1:
            # ids are already sorted DESC by importance — keep first, archive rest
            to_archive.extend(ids[1:])

    if not dry_run and to_archive:
        placeholders = ",".join("?" * len(to_archive))
        db.execute(
            f"UPDATE memories SET status = 'archived' WHERE id IN ({placeholders})",  # noqa:SQL-FSTRING
            to_archive,
        )
        db.commit()

    logger.info("DEDUP: %d duplicate memories archived (exact type+name match)%s",
                len(to_archive), " [dry-run]" if dry_run else "")
    return len(to_archive)


# ---------------------------------------------------------------------------
# Step 3: DECAY
# ---------------------------------------------------------------------------

def decay_unaccessed_importance(db, dry_run: bool = False) -> int:
    """Apply importance * DECAY_RATE to memories not accessed in DECAY_UNACCESSED_DAYS days.

    Uses last_accessed if available, falls back to updated timestamp.
    Importance floor: 0.05 (prevent zeroing out memories that are still active).
    Returns count of memories decayed.
    """
    rows = db.execute("""
        SELECT id, importance, last_accessed, updated
        FROM memories
        WHERE active = 1
          AND status = 'active'
          AND importance IS NOT NULL
          AND importance > 0.05
    """).fetchall()

    now = datetime.now(timezone.utc)
    to_decay: list[tuple[float, int]] = []

    for row in rows:
        mem_id, importance, last_accessed_str, updated_str = row
        importance = float(importance) if importance is not None else 0.5

        # Prefer last_accessed; fall back to updated
        ref_str = last_accessed_str or updated_str
        if not ref_str:
            continue

        try:
            dt_str = str(ref_str).replace("T", " ").split(".")[0][:19]
            ref_dt = datetime.strptime(dt_str, "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc)
            days_since = (now - ref_dt).total_seconds() / 86400.0
        except (ValueError, TypeError):
            continue

        if days_since >= DECAY_UNACCESSED_DAYS:
            new_importance = max(0.05, importance * DECAY_RATE)
            if abs(new_importance - importance) >= 0.001:  # skip if change is negligible
                to_decay.append((new_importance, mem_id))

    if not dry_run and to_decay:
        db.executemany(
            "UPDATE memories SET importance = ? WHERE id = ?",
            to_decay,
        )
        db.commit()

    logger.info("DECAY: %d memories had importance decayed (* %.2f, unaccessed > %d days)%s",
                len(to_decay), DECAY_RATE, DECAY_UNACCESSED_DAYS,
                " [dry-run]" if dry_run else "")
    return len(to_decay)


# ---------------------------------------------------------------------------
# Main dream runner
# ---------------------------------------------------------------------------

def run_dream(dry_run: bool = False, verbose: bool = False) -> dict:
    """Execute the 3-step nightly REM consolidation pass.

    Returns a summary dict with counts for each step.
    """
    if verbose:
        logging.basicConfig(level=logging.DEBUG)
    else:
        logging.basicConfig(level=logging.INFO)

    db = aibrain_db.get_db()

    result = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "dry_run": dry_run,
        "pruned": 0,
        "deduplicated": 0,
        "decayed": 0,
    }

    logger.info("dream: nightly REM pass starting%s", " (dry-run)" if dry_run else "")

    # Step 1: PRUNE
    result["pruned"] = prune_weak_old_memories(db, dry_run=dry_run)

    # Step 2: DEDUP
    result["deduplicated"] = dedup_exact_name_memories(db, dry_run=dry_run)

    # Step 3: DECAY
    result["decayed"] = decay_unaccessed_importance(db, dry_run=dry_run)

    total = result["pruned"] + result["deduplicated"] + result["decayed"]
    logger.info(
        "dream: complete — pruned=%d deduplicated=%d decayed=%d total=%d%s",
        result["pruned"], result["deduplicated"], result["decayed"], total,
        " [dry-run]" if dry_run else "",
    )

    # Self-report quality for the harness learning loop.
    # The harness reads _self_score from the returned dict (same convention as
    # _cost_cents). Deterministic tasks always score 1.0 on completion; the
    # synthetic binary quality in harness Step 6c uses this as confirmation.
    # execution_log is written by the harness via _log_audit — no direct INSERT
    # needed here (the redundant INSERT was removed; it was missing NOT NULL
    # columns run_id + actor and silently failed every run).
    result["_self_score"] = 1.0
    result["_cost_cents"] = 0  # deterministic, no LLM

    return result


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="dream — nightly REM memory consolidation (CLS phase)"
    )
    parser.add_argument("--dry-run", action="store_true",
                        help="Preview what would happen without making changes")
    parser.add_argument("--verbose", action="store_true",
                        help="Detailed output")
    args = parser.parse_args()

    result = run_dream(dry_run=args.dry_run, verbose=args.verbose)
    print(json.dumps(result, indent=2, default=str))
    return 0


if __name__ == "__main__":
    def _workflow_entry():
        sys.exit(main())

    workflow_execute(
        workflow_name="dream",
        action=_workflow_entry,
        task_type="deterministic",
        actor="cli",
    )
