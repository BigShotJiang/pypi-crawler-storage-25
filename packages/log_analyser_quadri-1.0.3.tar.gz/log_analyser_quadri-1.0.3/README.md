

# Python Log File Analyser and Basic Security Detection Tool

A lightweight log analysis application that parses Apache
Combined Log Format files and detects suspicious activity
using three configurable threshold-based rules.

## Installation

pip install log-analyser-quadri

## Usage

After installation, launch the application from any terminal:

log-analyser

The application opens in your browser at http://localhost:8501

## Detection Rules

- R1: High Request Volume - flags IPs exceeding 1,000 requests
- R2: Brute-Force Login - flags IPs with more than 20% HTTP 401 rate
- R3: Error Rate Anomaly - flags IPs with more than 50% error responses

## Requirements

Python 3.8 or later
