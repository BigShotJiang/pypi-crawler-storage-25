from setuptools import setup, find_packages

setup(
    name="log-analyser-quadri",
    version="1.0.3",
    author="Quadri Adelakun",
    author_email="L00203051@atu.ie",
    description="Python Log File Analyser and Basic Security Detection Tool",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    install_requires=[
        "pandas>=1.3.0",
        "streamlit>=1.0.0",
        "matplotlib>=3.4.0",
        "seaborn>=0.11.0",
    ],
    entry_points={
        "console_scripts": [
            "log-analyser=log_analyser.app:main",
        ],
    },
    python_requires=">=3.8",
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
        "Topic :: Security",
        "Topic :: System :: Logging",
    ],
)
