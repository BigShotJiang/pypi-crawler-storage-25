from constants import (
    HIGH_VOLUME_THRESHOLD,
    AUTH_FAIL_RATIO,
    ERROR_RATIO,
    MIN_REQUESTS_FOR_RATIO,
)


def detect(summary, df):
    findings = []

    # Rule R1 — High Request Volume
    for ip, count in summary["top_ips"].items():
        if count > HIGH_VOLUME_THRESHOLD:
            findings.append({
                "ip":           ip,
                "rule":         "R1 — High Volume",
                "metric_value": count,
                "detail": (
                    f"{count:,} total requests "
                    f"(threshold: {HIGH_VOLUME_THRESHOLD:,})"
                ),
            })

    # Build per-IP status code pivot for R2 and R3
    ip_status = (
        df.groupby(["ip_address", "status_code"])
          .size()
          .unstack(fill_value=0)
    )
    ip_totals = ip_status.sum(axis=1)
    eligible  = ip_totals[ip_totals >= MIN_REQUESTS_FOR_RATIO]

    # Rule R2 — Brute-Force Login
    if 401 in ip_status.columns:
        ratios_401 = ip_status[401] / ip_totals
        for ip in eligible.index:
            ratio = ratios_401.get(ip, 0)
            if ratio > AUTH_FAIL_RATIO:
                findings.append({
                    "ip":           ip,
                    "rule":         "R2 — Brute-Force Login",
                    "metric_value": round(ratio * 100, 1),
                    "detail": (
                        f"{ratio*100:.1f}% of requests returned HTTP 401 "
                        f"(threshold: {AUTH_FAIL_RATIO*100:.0f}%)"
                    ),
                })

    # Rule R3 — Error Rate Anomaly
    error_cols = [
        c for c in ip_status.columns
        if isinstance(c, int) and 400 <= c < 600
    ]
    if error_cols:
        error_counts = ip_status[error_cols].sum(axis=1)
        ratios_err   = error_counts / ip_totals
        for ip in eligible.index:
            ratio = ratios_err.get(ip, 0)
            if ratio > ERROR_RATIO:
                findings.append({
                    "ip":           ip,
                    "rule":         "R3 — Error Rate Anomaly",
                    "metric_value": round(ratio * 100, 1),
                    "detail": (
                        f"{ratio*100:.1f}% of requests returned 4xx/5xx errors "
                        f"(threshold: {ERROR_RATIO*100:.0f}%)"
                    ),
                })

    return findings