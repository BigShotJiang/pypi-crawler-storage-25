import pandas as pd


def summarise(df):
    summary = {}

    summary["total_requests"] = len(df)
    summary["unique_ips"]     = df["ip_address"].nunique()

    summary["top_ips"] = (
        df["ip_address"].value_counts().head(10)
    )

    summary["status_distribution"] = (
        df["status_code"].value_counts().sort_index()
    )

    summary["top_paths"] = (
        df["path"].value_counts().head(10)
    )

    summary["hourly_counts"] = (
        df.set_index("timestamp")
          .resample("h")
          .size()
    )

    return summary