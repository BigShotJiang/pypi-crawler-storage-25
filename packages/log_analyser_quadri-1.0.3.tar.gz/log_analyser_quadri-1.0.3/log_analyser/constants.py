LOG_PATTERN_STR = (
    r'^(\S+)\s\S+\s\S+\s'
    r'\[([^\]]+)\]\s'
    r'"(\S+)\s(\S+)\s\S+"\s'
    r'(\d{3})\s(\d+|-)'
)

HIGH_VOLUME_THRESHOLD  = 1000
AUTH_FAIL_RATIO        = 0.20
ERROR_RATIO            = 0.50
MIN_REQUESTS_FOR_RATIO = 10