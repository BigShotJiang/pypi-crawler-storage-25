import re
import pandas as pd
from constants import LOG_PATTERN_STR

PATTERN = re.compile(LOG_PATTERN_STR)


def parse(filepath):
    records = []
    error_count = 0

    with open(filepath, encoding="utf-8", errors="replace") as f:
        for line in f:
            match = PATTERN.match(line)
            if match:
                records.append({
                    "ip_address":  match.group(1),
                    "timestamp":   match.group(2),
                    "method":      match.group(3),
                    "path":        match.group(4),
                    "status_code": int(match.group(5)),
                    "bytes_sent":  (
                        0 if match.group(6) == "-"
                        else int(match.group(6))
                    ),
                })
            else:
                error_count += 1

    df = pd.DataFrame(records)

    if not df.empty:
        df["timestamp"] = pd.to_datetime(
            df["timestamp"],
            format="%d/%b/%Y:%H:%M:%S %z",
            utc=True
        )

    return df, error_count