import os
import tempfile
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import seaborn as sns
import streamlit as st

from parser   import parse
from analyser import summarise
from detector import detect


# ── Page configuration ────────────────────────────────────────────────
st.set_page_config(
    page_title="Python Log File Analyser and Basic Security Detection Tool",
    page_icon="🔍",
    layout="wide"
)

# ── Page title ────────────────────────────────────────────────────────
st.markdown(
    "<h2 style='text-align:center; color:#1F4D78; margin-bottom:20px;'>"
    "Python Log File Analyser and Basic Security Detection Tool"
    "</h2>",
    unsafe_allow_html=True
)


# ═════════════════════════════════════════════════════════════════════
# AREA 1 — INPUT
# ═════════════════════════════════════════════════════════════════════
st.markdown(
    """
    <div style='
        border: 2px solid #1F4D78;
        border-radius: 8px;
        background-color: #EBF3FB;
        padding: 10px 16px 4px 16px;
        margin-bottom: 16px;
    '>
    <span style='color:#1F4D78; font-weight:bold; font-size:13px;'>
    AREA 1 — INPUT
    </span>
    </div>
    """,
    unsafe_allow_html=True
)

col_upload, col_button = st.columns([3, 1])

with col_upload:
    uploaded_file = st.file_uploader(
        "Upload a log file",
        type=["log", "txt"],
        label_visibility="collapsed"
    )

with col_button:
    st.markdown("<div style='height:28px'></div>", unsafe_allow_html=True)
    analyse_clicked = st.button(
        "Analyse",
        type="primary",
        use_container_width=True
    )

if uploaded_file is not None and analyse_clicked:
    with st.spinner("Parsing log file and running analysis..."):

        with tempfile.NamedTemporaryFile(
                delete=False, suffix=".log") as tmp:
            tmp.write(uploaded_file.read())
            tmp_path = tmp.name

        df, error_count = parse(tmp_path)
        os.unlink(tmp_path)

        if df.empty:
            st.error(
                "No valid log lines could be parsed. "
                "Please check the file is in Apache Combined Log Format."
            )
            st.stop()

        summary  = summarise(df)
        findings = detect(summary, df)

        st.session_state["df"]          = df
        st.session_state["summary"]     = summary
        st.session_state["findings"]    = findings
        st.session_state["error_count"] = error_count
        st.session_state["filename"]    = uploaded_file.name


# ═════════════════════════════════════════════════════════════════════
# AREA 2 — SUMMARY STATISTICS
# ═════════════════════════════════════════════════════════════════════
if "summary" in st.session_state:
    summary     = st.session_state["summary"]
    error_count = st.session_state["error_count"]

    st.markdown(
        """
        <div style='
            border: 2px solid #5D8A3C;
            border-radius: 8px;
            background-color: #EEF5E9;
            padding: 10px 16px 4px 16px;
            margin-bottom: 12px;
        '>
        <span style='color:#5D8A3C; font-weight:bold; font-size:13px;'>
        AREA 2 — SUMMARY STATISTICS
        </span>
        </div>
        """,
        unsafe_allow_html=True
    )

    # Three metric cards
    c1, c2, c3 = st.columns(3)

    for col, label, value in [
        (c1, "Total Requests", f"{summary['total_requests']:,}"),
        (c2, "Unique IPs",     f"{summary['unique_ips']:,}"),
        (c3, "Parse Errors",   f"{error_count:,}"),
    ]:
        with col:
            st.markdown(
                f"""
                <div style='
                    border: 1px solid #DDDDDD;
                    border-radius: 6px;
                    padding: 16px;
                    text-align: center;
                    background: #FFFFFF;
                    margin-bottom: 12px;
                '>
                <div style='font-size:13px; color:#555555;'>{label}</div>
                <div style='font-size:30px; font-weight:bold;
                            color:#1F4D78;'>{value}</div>
                </div>
                """,
                unsafe_allow_html=True
            )

    if error_count > 0:
        st.warning(
            f"{error_count:,} lines did not match the expected log "
            "format and were excluded from the analysis."
        )

    # Two side-by-side tables
    left, right = st.columns(2)

    with left:
        st.markdown(
            "<div style='background:#FFFFFF; border:1px solid #DDDDDD;"
            "border-radius:6px; padding:14px; margin-bottom:12px;'>",
            unsafe_allow_html=True
        )
        st.markdown(
            "<div style='font-weight:bold; font-size:13px; "
            "margin-bottom:8px;'>Top 10 IP Addresses</div>",
            unsafe_allow_html=True
        )
        top_df = summary["top_ips"].rename("Requests").reset_index()
        top_df.columns = ["IP Address", "Requests"]
        for _, row in top_df.iterrows():
            st.markdown(
                f"<div style='font-size:13px; margin-bottom:3px;'>"
                f"{row['IP Address']} &mdash; "
                f"<b>{int(row['Requests']):,}</b> reqs</div>",
                unsafe_allow_html=True
            )
        st.markdown("</div>", unsafe_allow_html=True)

    with right:
        labels = {
            200: "OK", 201: "Created", 204: "No Content",
            301: "Moved Permanently", 302: "Found", 304: "Not Modified",
            400: "Bad Request", 401: "Unauthorised", 403: "Forbidden",
            404: "Not Found", 405: "Method Not Allowed",
            500: "Internal Server Error", 502: "Bad Gateway",
            503: "Service Unavailable"
        }
        st.markdown(
            "<div style='background:#FFFFFF; border:1px solid #DDDDDD;"
            "border-radius:6px; padding:14px; margin-bottom:12px;'>",
            unsafe_allow_html=True
        )
        st.markdown(
            "<div style='font-weight:bold; font-size:13px; "
            "margin-bottom:8px;'>Status Code Distribution</div>",
            unsafe_allow_html=True
        )
        status_df = (
            summary["status_distribution"].rename("Count").reset_index()
        )
        status_df.columns = ["Status Code", "Count"]
        for _, row in status_df.iterrows():
            code    = int(row["Status Code"])
            label   = labels.get(code, "")
            display = f"{code} {label}" if label else str(code)
            st.markdown(
                f"<div style='font-size:13px; margin-bottom:3px;'>"
                f"{display} &mdash; "
                f"<b>{int(row['Count']):,}</b></div>",
                unsafe_allow_html=True
            )
        st.markdown("</div>", unsafe_allow_html=True)


# ═════════════════════════════════════════════════════════════════════
# AREA 3 — CHARTS AND FINDINGS
# ═════════════════════════════════════════════════════════════════════
if "summary" in st.session_state:
    summary  = st.session_state["summary"]
    findings = st.session_state["findings"]

    st.markdown(
        """
        <div style='
            border: 2px solid #B8860B;
            border-radius: 8px;
            background-color: #FDF8E8;
            padding: 10px 16px 4px 16px;
            margin-bottom: 12px;
        '>
        <span style='color:#B8860B; font-weight:bold; font-size:13px;'>
        AREA 3 — CHARTS AND FINDINGS
        </span>
        </div>
        """,
        unsafe_allow_html=True
    )

    # Time-series chart full width
    st.markdown(
        "<div style='border:1px dashed #CCCCCC; border-radius:6px;"
        "padding:14px; background:#FAFAFA; margin-bottom:12px;'>",
        unsafe_allow_html=True
    )
    hourly = summary["hourly_counts"]
    fig, ax = plt.subplots(figsize=(12, 3))
    ax.plot(hourly.index, hourly.values, color="#1F4D78", linewidth=1.4)
    ax.fill_between(
        hourly.index, hourly.values, alpha=0.12, color="#1F4D78"
    )
    ax.set_xlabel("Time (UTC)", fontsize=10)
    ax.set_ylabel("Requests", fontsize=10)
    ax.set_title(
        "Time-series chart: hourly request volume",
        fontsize=11, color="#555555", style="italic"
    )
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%d %b %H:%M"))
    ax.tick_params(axis="x", rotation=45, labelsize=8)
    ax.tick_params(axis="y", labelsize=8)
    ax.grid(axis="y", linestyle="--", alpha=0.4)
    fig.tight_layout()
    st.pyplot(fig)
    plt.close(fig)
    st.markdown("</div>", unsafe_allow_html=True)

    # Two bar charts side by side
    col_a, col_b = st.columns(2)

    with col_a:
        st.markdown(
            "<div style='border:1px dashed #CCCCCC; border-radius:6px;"
            "padding:14px; background:#FAFAFA; margin-bottom:12px;'>",
            unsafe_allow_html=True
        )
        top_ips = summary["top_ips"]
        fig, ax = plt.subplots(figsize=(6, 4))
        bars = ax.barh(
            top_ips.index[::-1],
            top_ips.values[::-1],
            color="#1F4D78"
        )
        for bar, val in zip(bars, top_ips.values[::-1]):
            ax.text(
                bar.get_width() + max(top_ips.values) * 0.01,
                bar.get_y() + bar.get_height() / 2,
                f"{val:,}", va="center", fontsize=8
            )
        ax.set_title(
            "Bar chart: top IP addresses by request count",
            fontsize=10, color="#555555", style="italic"
        )
        ax.set_xlabel("Requests", fontsize=9)
        ax.tick_params(labelsize=8)
        ax.grid(axis="x", linestyle="--", alpha=0.4)
        fig.tight_layout()
        st.pyplot(fig)
        plt.close(fig)
        st.markdown("</div>", unsafe_allow_html=True)

    with col_b:
        st.markdown(
            "<div style='border:1px dashed #CCCCCC; border-radius:6px;"
            "padding:14px; background:#FAFAFA; margin-bottom:12px;'>",
            unsafe_allow_html=True
        )
        status = summary["status_distribution"]
        colours = []
        for code in status.index:
            if code < 300:
                colours.append("#2e7d32")
            elif code < 400:
                colours.append("#1565c0")
            elif code < 500:
                colours.append("#e65100")
            else:
                colours.append("#b71c1c")

        fig, ax = plt.subplots(figsize=(6, 4))
        bars = ax.bar(
            status.index.astype(str),
            status.values,
            color=colours
        )
        for bar, val in zip(bars, status.values):
            ax.text(
                bar.get_x() + bar.get_width() / 2,
                bar.get_height() + max(status.values) * 0.01,
                f"{val:,}", ha="center", va="bottom", fontsize=7
            )
        ax.set_title(
            "Bar chart: HTTP status code distribution",
            fontsize=10, color="#555555", style="italic"
        )
        ax.set_xlabel("Status Code", fontsize=9)
        ax.tick_params(axis="x", rotation=45, labelsize=8)
        ax.tick_params(axis="y", labelsize=8)
        ax.grid(axis="y", linestyle="--", alpha=0.4)
        fig.tight_layout()
        st.pyplot(fig)
        plt.close(fig)
        st.markdown("</div>", unsafe_allow_html=True)

    # Flagged Events and Export CSV
    findings_col, export_col = st.columns([5, 1])

    with findings_col:
        if findings:
            rows_html = ""
            for f in findings:
                rows_html += (
                    f"<div style='font-size:13px; color:#b71c1c;"
                    f"margin-bottom:5px;'>"
                    f"<b>{f['ip']}</b>"
                    f" &middot; {f['rule']}"
                    f" &middot; {f['detail']}"
                    f"</div>"
                )
            st.markdown(
                f"""
                <div style='
                    border: 1px solid #F1AAAA;
                    border-radius: 6px;
                    background: #FFF5F5;
                    padding: 14px 16px;
                '>
                <div style='font-weight:bold; font-size:14px;
                            color:#222222; margin-bottom:10px;'>
                    Flagged Events
                </div>
                {rows_html}
                </div>
                """,
                unsafe_allow_html=True
            )
        else:
            st.success(
                "No suspicious activity detected based on the "
                "configured detection thresholds."
            )

    with export_col:
        if findings:
            findings_df = pd.DataFrame(findings)
            findings_df.columns = [
                "IP Address", "Rule", "Metric Value", "Detail"
            ]
            csv   = findings_df.to_csv(index=False).encode("utf-8")
            fname = st.session_state.get("filename", "log")
            st.markdown(
                "<div style='height:32px'></div>",
                unsafe_allow_html=True
            )
            st.download_button(
                label="Export CSV",
                data=csv,
                file_name=f"{fname}_findings.csv",
                mime="text/csv",
                use_container_width=True
            )


# ═════════════════════════════════════════════════════════════════════
# ENTRY POINT
# ═════════════════════════════════════════════════════════════════════
def main():
    import subprocess
    import sys
    import os
    app_path = os.path.join(os.path.dirname(__file__), "app.py")
    subprocess.run([
        sys.executable, "-m", "streamlit", "run", app_path,
        "--server.headless", "true",
        "--server.port", "8501"
    ])
