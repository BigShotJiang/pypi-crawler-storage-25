"""
cli.py — Entry point chính của qa-skills CLI.
"""
import click
from colorama import init as colorama_init

from qa_skills import __version__
from qa_skills.commands import hub_cmd, init_cmd, list_cmd, path_cmd, status_cmd, kb_cmd

colorama_init(autoreset=True)


@click.group()
@click.version_option(version=__version__, prog_name="qa-skills")
def main():
    """
    \b
    ╔═══════════════════════════════════════╗
    ║   qa-skills — QA Prompt Skill Hub    ║
    ║   Centralized prompt manager for QA  ║
    ╚═══════════════════════════════════════╝

    Quản lý bộ skill prompts QA tập trung.
    Dùng 'qa-skills COMMAND --help' để xem chi tiết từng lệnh.
    """
    pass


# ── Register subcommands ────────────────────────────────────────────────
main.add_command(hub_cmd.hub)
main.add_command(init_cmd.init)
main.add_command(list_cmd.list_skills, name="list")
main.add_command(path_cmd.path)
main.add_command(status_cmd.status)
main.add_command(kb_cmd.kb)


if __name__ == "__main__":
    main()
