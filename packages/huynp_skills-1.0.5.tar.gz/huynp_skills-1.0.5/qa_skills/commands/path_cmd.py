"""
path_cmd.py — Lấy absolute path của một skill prompt.

Command:
  qa-skills path <skill-id>
"""
import click
from colorama import Fore

from qa_skills import config as cfg
from qa_skills import resolver


@click.command()
@click.argument("skill_id")
@click.option("--copy", "-c", is_flag=True, help="Copy path vào clipboard")
def path(skill_id: str, copy: bool):
    """
    In ra đường dẫn tuyệt đối của một skill prompt.

    \b
    Ví dụ:
      qa-skills path generate/manual/checklist/ui-checklist
      qa-skills path study/Study project requirements
      qa-skills path manage/regression_management
    """
    project_config_file = cfg.find_project_config()
    project_config = cfg.read_project_config(project_config_file) if project_config_file else None
    hub = cfg.resolve_hub(project_config)

    skill_path = resolver.resolve_skill_path(skill_id, hub)

    if not skill_path:
        # Thử fuzzy match
        all_skills = resolver.list_skills(hub)
        matches = [s for s in all_skills if skill_id.lower() in s["id"].lower()]
        if matches:
            click.echo(Fore.YELLOW + f"⚠️  Không tìm thấy chính xác '{skill_id}'. Có thể bạn muốn:")
            for m in matches[:5]:
                click.echo(f"   {m['id']}")
        else:
            click.echo(Fore.RED + f"❌ Không tìm thấy skill: '{skill_id}'")
            click.echo(f"   Dùng 'qa-skills list' để xem tất cả skills.")
        raise SystemExit(1)

    # In path (sạch không có màu để dễ copy)
    click.echo(str(skill_path))

    if copy:
        try:
            import subprocess
            subprocess.run(["clip"], input=str(skill_path).encode("utf-8"), check=True)
            click.echo(Fore.GREEN + "✅ Đã copy vào clipboard!", err=True)
        except Exception:
            click.echo(Fore.YELLOW + "⚠️  Không thể copy clipboard. Tự copy path trên.", err=True)
