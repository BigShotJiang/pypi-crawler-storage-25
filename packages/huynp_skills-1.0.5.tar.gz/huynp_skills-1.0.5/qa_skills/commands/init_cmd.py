"""
init_cmd.py — Khởi tạo QA Skills cho một project mới.

Command:
  qa-skills init [--name NAME] [--desc DESC] [--hub HUB]

Tạo ra:
  .qa-skills                         ← Project config
  .agents/workflows/qc_follow.md     ← Workflow với absolute paths đến hub
  Master_Instruction.md              ← Project context (load mỗi task)
  01_knowledge_base/requirements/    ← Đặt PRD/Rule/SRS tại đây
  01_knowledge_base/examples/
  03_test_design/manual/checklist/
  03_test_design/manual/test_cases/
  03_test_design/manual/test_plan/
  03_test_design/automation/scripts/
  03_test_design/automation/test_plan/
  README.md                          ← Hướng dẫn sử dụng project
"""
import os
from datetime import datetime
from importlib import resources
from pathlib import Path

import click
from colorama import Fore, Style

from qa_skills import config as cfg


def _read_template(template_name: str) -> str:
    """Đọc template file từ package."""
    try:
        # Python 3.9+
        with resources.files("qa_skills.templates").joinpath(template_name).open(
            "r", encoding="utf-8"
        ) as f:
            return f.read()
    except AttributeError:
        # Python 3.8 fallback
        import pkg_resources
        return pkg_resources.resource_string(
            "qa_skills", f"templates/{template_name}"
        ).decode("utf-8")


def _create_dir(path: Path, label: str, markers: list) -> None:
    """Tạo thư mục và thêm .gitkeep để git track folder rỗng."""
    path.mkdir(parents=True, exist_ok=True)
    gitkeep = path / ".gitkeep"
    if not gitkeep.exists():
        gitkeep.touch()
    markers.append(f"  ✅ {label}")


def _write_file(path: Path, content: str, label: str, markers: list) -> None:
    """Ghi file (bỏ qua nếu đã tồn tại)."""
    if path.exists():
        markers.append(f"  ⏭️  {label} (đã tồn tại — bỏ qua)")
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    markers.append(f"  ✅ {label}")


@click.command()
@click.option("--name", "-n", default="", help="Tên project (mặc định: tên folder)")
@click.option("--desc", "-d", default="", help="Mô tả ngắn về project")
@click.option(
    "--hub",
    "-h",
    "hub_override",
    default="",
    type=click.Path(file_okay=False),
    help="Override hub path (mặc định: dùng global hub)",
)
def init(name: str, desc: str, hub_override: str) -> None:
    """
    Khởi tạo QA Skills cho project hiện tại.

    \b
    Tạo cấu trúc thư mục chuẩn và file config cho AI workflow.

    \b
    Ví dụ:
      qa-skills init
      qa-skills init --name "Karter School" --desc "AI Camera QA"
      qa-skills init --hub D:\\custom-skills\\_core
    """
    project_dir = Path.cwd().resolve()

    # ── Resolve project name ────────────────────────────────────────────
    if not name:
        name = project_dir.name
        prompted = click.prompt(
            f"  Tên project",
            default=name,
        )
        name = prompted.strip() or name

    if not desc:
        desc = click.prompt("  Mô tả project (Enter để bỏ qua)", default="", show_default=False)

    # ── Resolve hub ─────────────────────────────────────────────────────
    if hub_override:
        hub = Path(hub_override).resolve()
    else:
        hub = cfg.get_global_hub()
        if not hub:
            click.echo(Fore.RED + "\n❌ Chưa có global hub. Chạy trước:")
            click.echo("   qa-skills hub set <đường_dẫn_đến__core_folder>")
            raise SystemExit(1)
        if not hub.exists():
            click.echo(Fore.RED + f"\n❌ Hub không tồn tại: {hub}")
            raise SystemExit(1)

    click.echo(
        Fore.CYAN + Style.BRIGHT + f"\n🔧 Khởi tạo QA Skills cho: {name}"
    )
    click.echo(f"   Thư mục  : {project_dir}")
    click.echo(f"   Hub      : {hub}")
    click.echo("─" * 55)

    created: list[str] = []

    # ── 1. .qa-skills config ────────────────────────────────────────────
    config_file = project_dir / ".qa-skills"
    if not config_file.exists():
        cfg.write_project_config(
            project_dir=project_dir,
            name=name,
            description=desc,
            hub=hub,
            kb_rel="01_knowledge_base",
        )
        created.append("  ✅ .qa-skills")
    else:
        created.append("  ⏭️  .qa-skills (đã tồn tại — bỏ qua)")

    # ── 2. .agents/workflows/qc_follow.md ──────────────────────────────
    master_role_path = hub / "master_role.md"
    master_instruction_path = project_dir / "Master_Instruction.md"
    kb_path = project_dir / "01_knowledge_base"
    kb_req_path = kb_path / "requirements"

    workflow_content = _read_template("workflow_template.md").format(
        MASTER_ROLE_PATH=str(master_role_path),
        MASTER_INSTRUCTION_PATH=str(master_instruction_path),
        KB_PATH=str(kb_path),
        KB_REQUIREMENTS_PATH=str(kb_req_path),
    )
    _write_file(
        project_dir / ".agents" / "workflows" / "qc_follow.md",
        workflow_content,
        ".agents/workflows/qc_follow.md",
        created,
    )

    # ── 3. Master_Instruction.md (project context) ──────────────────────
    mi_content = _read_template("master_instruction_template.md").format(
        PROJECT_NAME=name,
        PROJECT_DESCRIPTION=desc or f"Dự án {name}",
    )
    _write_file(
        master_instruction_path,
        mi_content,
        "Master_Instruction.md",
        created,
    )

    # ── 4. Knowledge Base ───────────────────────────────────────────────
    _create_dir(kb_req_path, "01_knowledge_base/requirements/", created)
    _create_dir(kb_path / "examples", "01_knowledge_base/examples/", created)

    # ── 5. 03_test_design output structure ──────────────────────────────
    _create_dir(project_dir / "03_test_design" / "manual" / "checklist",  "03_test_design/manual/checklist/",  created)
    _create_dir(project_dir / "03_test_design" / "manual" / "test_cases", "03_test_design/manual/test_cases/", created)
    _create_dir(project_dir / "03_test_design" / "manual" / "test_plan",  "03_test_design/manual/test_plan/",  created)
    _create_dir(project_dir / "03_test_design" / "automation" / "scripts",    "03_test_design/automation/scripts/",    created)
    _create_dir(project_dir / "03_test_design" / "automation" / "test_plan",  "03_test_design/automation/test_plan/",  created)

    # ── 6. README.md ────────────────────────────────────────────────────
    readme_content = _read_template("project_readme_template.md").format(
        PROJECT_NAME=name,
        MASTER_ROLE_PATH=str(master_role_path),
        CREATED_AT=datetime.now().strftime("%Y-%m-%d"),
    )
    _write_file(project_dir / "README.md", readme_content, "README.md", created)

    # ── Summary ─────────────────────────────────────────────────────────
    click.echo(Fore.GREEN + "\n📦 Kết quả:")
    for line in created:
        click.echo(line)

    click.echo(Fore.CYAN + Style.BRIGHT + "\n🚀 Bước tiếp theo:")
    click.echo(f"  1. Đặt tài liệu requirement vào:")
    click.echo(Fore.WHITE + f"       {kb_req_path}")
    click.echo(f"  2. Load System Prompt vào AI tool:")
    click.echo(Fore.WHITE + f"       {master_role_path}")
    click.echo(f"  3. Đọc Master_Instruction.md khi bắt đầu task mới")
    click.echo(f"  4. Xem tất cả prompts: {Fore.YELLOW}qa-skills list")
    click.echo()
