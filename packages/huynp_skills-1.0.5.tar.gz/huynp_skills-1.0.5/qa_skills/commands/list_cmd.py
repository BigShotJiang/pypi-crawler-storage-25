"""
list_cmd.py — Liệt kê tất cả prompts từ hub.

Command:
  qa-skills list [--filter <keyword>]
"""
import click
from colorama import Fore, Style

from qa_skills import config as cfg
from qa_skills import resolver


@click.command()
@click.option("--filter", "-f", "keyword", default="", help="Lọc theo tên skill")
@click.option("--category", "-c", default="", help="Lọc theo category (generate/manage/study)")
def list_skills(keyword: str, category: str):
    """
    Liệt kê tất cả prompts có sẵn trong hub.

    \b
    Ví dụ:
      qa-skills list
      qa-skills list --filter checklist
      qa-skills list --category generate
    """
    # Resolve hub
    project_config_file = cfg.find_project_config()
    project_config = cfg.read_project_config(project_config_file) if project_config_file else None
    hub = cfg.resolve_hub(project_config)

    skills = resolver.list_skills(hub)

    # Filter
    if keyword:
        skills = [s for s in skills if keyword.lower() in s["id"].lower()]
    if category:
        skills = [s for s in skills if s["category"].lower() == category.lower()]

    if not skills:
        click.echo(Fore.YELLOW + "⚠️  Không tìm thấy skill nào.")
        return

    click.echo(Fore.CYAN + Style.BRIGHT + f"\n📚 QA Skills — {len(skills)} prompts")
    click.echo(f"   Hub: {hub}")
    click.echo("─" * 60)

    # Group by category
    grouped: dict[str, list] = {}
    for s in skills:
        grouped.setdefault(s["category"], []).append(s)

    for cat in sorted(grouped.keys()):
        click.echo(Fore.YELLOW + Style.BRIGHT + f"\n[{cat}]")
        for s in grouped[cat]:
            # Bỏ category prefix khỏi id để hiển thị gọn
            display_id = s["id"]
            click.echo(f"  {Fore.GREEN}{display_id:<55}{Style.RESET_ALL}")

    click.echo()
    click.echo(Fore.CYAN + "💡 Dùng path để lấy đường dẫn:")
    click.echo(f"   qa-skills path <id>")
