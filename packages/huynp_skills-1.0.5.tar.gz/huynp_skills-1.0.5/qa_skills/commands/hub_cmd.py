"""
hub_cmd.py — Quản lý global skill hub.

Commands:
  qa-skills hub set <path>   → Ghi global hub path
  qa-skills hub status       → Hiển thị hub đang dùng
"""
import click
from colorama import Fore, Style
from pathlib import Path

from qa_skills import config as cfg
from qa_skills import resolver


@click.group()
def hub():
    """Quản lý Skill Hub trung tâm."""
    pass


@hub.command("set")
@click.argument("hub_path", type=click.Path(exists=True, file_okay=False))
def hub_set(hub_path: str):
    """
    Set đường dẫn Skill Hub toàn cục.
    Hỗ trợ:
      - Absolute path: D:\\testing-skills\\_core
      - Relative path: ..\\testing-skills\\_core
      - Environment variable: QA_SKILLS_HUB

    \b
    Ví dụ:
      qa-skills hub set D:\\testing-skills\\_core
    """
    hub = Path(hub_path).resolve()

    # Validate hub structure
    master_role = hub / "master_role.md"
    prompts_dir = hub / "02_prompts"
    
    if not master_role.exists() or not prompts_dir.exists():
        click.echo(
            Fore.YELLOW + f"⚠️  Cảnh báo: Không tìm thấy cấu trúc hub đầy đủ trong '{hub}'.\n"
            f"   Cần có: master_role.md, 02_prompts/"
        )
        if not click.confirm("Vẫn muốn set hub này?"):
            return

    cfg.set_global_hub(hub)
    click.echo(Fore.GREEN + f"✅ Global hub đã được set:")
    click.echo(f"   📁 {hub}")
    click.echo(f"   Config: {cfg.GLOBAL_CONFIG_FILE}")
    click.echo(Fore.CYAN + "\n📝 Setup tips:")
    click.echo(f"   • Environment var: set QA_SKILLS_HUB={hub}")
    click.echo(f"   • Hoặc dùng relative path: ../testing-skills/_core")

    # Thống kê nhanh
    skills = resolver.list_skills(hub)
    click.echo(f"   ✨ Skills: {len(skills)} prompts khả dụng")


@hub.command("status")
def hub_status():
    """Hiển thị thông tin Skill Hub hiện tại."""
    global_hub = cfg.get_global_hub()

    click.echo(Fore.CYAN + Style.BRIGHT + "\n📦 QA Skills — Hub Status")
    click.echo("─" * 40)

    if not global_hub:
        click.echo(Fore.RED + "❌ Chưa có global hub.")
        click.echo(f"   Chạy: qa-skills hub set <path>")
        return

    if not global_hub.exists():
        click.echo(Fore.RED + f"❌ Global hub không tồn tại: {global_hub}")
        return

    skills = resolver.list_skills(global_hub)

    # Đếm theo category
    categories = {}
    for s in skills:
        cat = s["category"]
        categories[cat] = categories.get(cat, 0) + 1

    click.echo(Fore.GREEN + f"✅ Global hub: {global_hub}")
    click.echo(f"   Config   : {cfg.GLOBAL_CONFIG_FILE}")
    click.echo(f"   Skills   : {len(skills)} prompts")
    for cat, count in sorted(categories.items()):
        click.echo(f"     [{cat}] {count} files")
    click.echo()


@hub.command("auto-detect")
def hub_auto_detect():
    """Auto-detect hub từ parent directories."""
    click.echo(Fore.CYAN + "🔍 Searching for _core folder...")
    
    auto_hub = cfg.auto_detect_hub()
    if auto_hub:
        click.echo(Fore.GREEN + f"✅ Found: {auto_hub}")
        if click.confirm("Set this as global hub?"):
            cfg.set_global_hub(auto_hub)
            click.echo(Fore.GREEN + "✅ Hub đã được set!")
    else:
        click.echo(Fore.RED + "❌ Không tìm thấy _core folder gần đây")
        click.echo("   Hãy chạy: qa-skills hub set <path>")


@hub.command("env")
def hub_env():
    """Hướng dẫn set environment variable."""
    click.echo(Fore.CYAN + "\n📝 Cách set Environment Variable:")
    click.echo("─" * 50)
    click.echo("\n1️⃣  Windows (PowerShell):")
    click.echo("   $env:QA_SKILLS_HUB = 'D:\\testing-skills\\_core'")
    click.echo("\n2️⃣  Windows (CMD):")
    click.echo("   set QA_SKILLS_HUB=D:\\testing-skills\\_core")
    click.echo("\n3️⃣  Linux/Mac (Bash):")
    click.echo("   export QA_SKILLS_HUB=/path/to/_core")
    click.echo("\n4️⃣  Permanent (Windows - System Properties):")
    click.echo("   1. Win+X → System")
    click.echo("   2. Advanced → Environment Variables")
    click.echo("   3. New → QA_SKILLS_HUB = D:\\testing-skills\\_core")
    click.echo(Fore.CYAN + "\n✨ Sau đó package sẽ tự động detect!")
    click.echo()
