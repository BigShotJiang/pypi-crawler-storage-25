"""
status_cmd.py — Hiển thị trạng thái project hiện tại.

Command:
  qa-skills status
"""
import click
from colorama import Fore, Style

from qa_skills import config as cfg
from qa_skills import resolver


@click.command()
def status():
    """Hiển thị trạng thái project và skill hub."""
    click.echo(Fore.CYAN + Style.BRIGHT + "\n📦 QA Skills — Project Status")
    click.echo("─" * 50)

    # ── Global hub ──────────────────────────────────────
    global_hub = cfg.get_global_hub()
    if global_hub and global_hub.exists():
        click.echo(Fore.GREEN + f"✅ Global hub : {global_hub}")
    elif global_hub:
        click.echo(Fore.RED + f"❌ Global hub : {global_hub} (không tồn tại!)")
    else:
        click.echo(Fore.RED + "❌ Global hub : Chưa set. Chạy: qa-skills hub set <path>")

    # ── Project config ──────────────────────────────────
    config_file = cfg.find_project_config()
    if not config_file:
        click.echo(Fore.YELLOW + "\n⚠️  Không có .qa-skills trong project này.")
        click.echo(f"   Chạy: qa-skills init")
        click.echo()
        return

    pc = cfg.read_project_config(config_file)
    click.echo(f"\n📁 Project  : {Fore.WHITE + Style.BRIGHT}{pc['name']}{Style.RESET_ALL}")
    if pc.get("description"):
        click.echo(f"   Mô tả    : {pc['description']}")
    click.echo(f"   Config   : {config_file}")

    # ── Hub (project override) ──────────────────────────
    hub = cfg.resolve_hub(pc)
    if hub:
        skills = resolver.list_skills(hub)
        click.echo(f"\n🧠 Hub       : {Fore.GREEN}{hub}{Style.RESET_ALL}")
        click.echo(f"   Skills   : {len(skills)} prompts")

    # ── Knowledge Base ──────────────────────────────────
    kb = pc.get("knowledge_base")
    if kb and kb.exists():
        kb_files = resolver.list_kb_files(kb)
        click.echo(f"\n📚 KB        : {Fore.GREEN}{kb}{Style.RESET_ALL}")
        if kb_files:
            click.echo(f"   Files    : {len(kb_files)} documents")
            for f in kb_files[:5]:
                click.echo(f"     • {f['relative']}")
            if len(kb_files) > 5:
                click.echo(f"     ... và {len(kb_files) - 5} files khác")
        else:
            click.echo(Fore.YELLOW + "   Files    : (trống — hãy thêm requirement docs)")
    elif kb:
        click.echo(Fore.YELLOW + f"\n⚠️  KB        : {kb} (chưa tạo)")
        click.echo(f"   Chạy: qa-skills kb init")

    # ── Output folder ───────────────────────────────────
    project_dir = pc["project_dir"]
    output_dir = project_dir / "03_test_design"
    if output_dir.exists():
        output_files = list(output_dir.rglob("*.md"))
        click.echo(f"\n📄 Output    : {Fore.GREEN}{output_dir}{Style.RESET_ALL}")
        click.echo(f"   Artifacts: {len(output_files)} files")
    else:
        click.echo(Fore.YELLOW + f"\n⚠️  Output    : 03_test_design/ (chưa tạo)")

    # ── Agents workflow ─────────────────────────────────
    agents_dir = project_dir / ".agents" / "workflows"
    if agents_dir.exists():
        workflows = list(agents_dir.glob("*.md"))
        click.echo(f"\n⚙️  Workflow  : {Fore.GREEN}{len(workflows)} file(s){Style.RESET_ALL}")
        for w in workflows:
            click.echo(f"     • {w.name}")
    else:
        click.echo(Fore.YELLOW + "\n⚠️  Workflow  : .agents/workflows/ (chưa tạo)")
        click.echo(f"   Chạy: qa-skills init để tạo lại")

    click.echo()
