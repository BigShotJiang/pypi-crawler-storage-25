"""
kb_cmd.py — Quản lý project-local Knowledge Base (01_knowledge_base/).

Commands:
  qa-skills kb init             → Tạo thư mục 01_knowledge_base/
  qa-skills kb list             → Liệt kê files trong KB
  qa-skills kb path <file>      → In absolute path của file KB
"""
import click
from colorama import Fore, Style

from qa_skills import config as cfg
from qa_skills import resolver


@click.group()
def kb():
    """Quản lý Knowledge Base của project (01_knowledge_base/)."""
    pass


@kb.command("init")
def kb_init():
    """Tạo thư mục 01_knowledge_base/ trong project hiện tại."""
    config_file = cfg.find_project_config()
    if not config_file:
        click.echo(Fore.RED + "❌ Không tìm thấy .qa-skills. Chạy: qa-skills init trước.")
        raise SystemExit(1)

    pc = cfg.read_project_config(config_file)
    kb_root = pc["knowledge_base"]

    (kb_root / "requirements").mkdir(parents=True, exist_ok=True)
    (kb_root / "examples").mkdir(parents=True, exist_ok=True)

    click.echo(Fore.GREEN + f"✅ Knowledge Base đã tạo:")
    click.echo(f"   {kb_root / 'requirements'} ← Đặt PRD/Rule/SRS tại đây")
    click.echo(f"   {kb_root / 'examples'}     ← Ví dụ tham khảo")


@kb.command("list")
def kb_list():
    """Liệt kê tất cả documents trong Knowledge Base."""
    config_file = cfg.find_project_config()
    if not config_file:
        click.echo(Fore.RED + "❌ Không tìm thấy .qa-skills. Chạy: qa-skills init trước.")
        raise SystemExit(1)

    pc = cfg.read_project_config(config_file)
    kb_root = pc["knowledge_base"]

    if not kb_root.exists():
        click.echo(Fore.YELLOW + f"⚠️  KB chưa tạo. Chạy: qa-skills kb init")
        return

    files = resolver.list_kb_files(kb_root)
    if not files:
        click.echo(Fore.YELLOW + f"⚠️  KB trống. Thêm requirement docs vào:")
        click.echo(f"   {kb_root / 'requirements'}")
        return

    click.echo(Fore.CYAN + Style.BRIGHT + f"\n📚 Knowledge Base — {len(files)} documents")
    click.echo(f"   Root: {kb_root}")
    click.echo("─" * 50)

    grouped: dict[str, list] = {}
    for f in files:
        grouped.setdefault(f["subfolder"], []).append(f)

    for folder in sorted(grouped.keys()):
        click.echo(Fore.YELLOW + f"\n[{folder}]")
        for f in grouped[folder]:
            click.echo(f"  {Fore.GREEN}{f['name']:<40}{Style.RESET_ALL}")
    click.echo()


@kb.command("path")
@click.argument("file_id")
def kb_path(file_id: str):
    """
    In đường dẫn tuyệt đối của một document trong KB.

    \b
    Ví dụ:
      qa-skills kb path rule_MCROSSR
      qa-skills kb path rule_LOADHIGH
    """
    config_file = cfg.find_project_config()
    if not config_file:
        click.echo(Fore.RED + "❌ Không tìm thấy .qa-skills. Chạy: qa-skills init trước.")
        raise SystemExit(1)

    pc = cfg.read_project_config(config_file)
    kb_root = pc["knowledge_base"]

    file_path = resolver.resolve_kb_path(file_id, kb_root)
    if not file_path:
        click.echo(Fore.RED + f"❌ Không tìm thấy: '{file_id}' trong KB")
        click.echo(f"   Dùng 'qa-skills kb list' để xem danh sách.")
        raise SystemExit(1)

    click.echo(str(file_path))
