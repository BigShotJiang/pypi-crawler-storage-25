"""qa-skills — QA Prompt Skill Manager"""
import os

# Đọc version từ pyproject.toml
def _get_version():
    pyproject_path = os.path.join(os.path.dirname(__file__), '..', 'pyproject.toml')
    try:
        with open(pyproject_path, 'r', encoding='utf-8') as f:
            for line in f:
                if line.strip().startswith('version'):
                    # Extract version: version = "1.0.3"
                    version = line.split('=')[1].strip().strip('"').strip("'")
                    return version
    except Exception:
        pass
    return "0.0.0"

__version__ = _get_version()
__author__ = "HuyNP"
