"""
resolver.py — Resolve paths cho skills và knowledge base.
Phân biệt 2 loại path:
  - Skills (02_prompts/)     → từ hub trung tâm
  - Knowledge base           → từ project local (01_knowledge_base/)
"""
from pathlib import Path
from typing import Optional


PROMPTS_DIR = "02_prompts"
KB_DIR_NAME = "01_knowledge_base"
REQUIREMENTS_DIR = "requirements"
EXAMPLES_DIR = "examples"


def resolve_skill_path(skill_id: str, hub: Path) -> Optional[Path]:
    """
    Resolve skill_id → absolute path trong hub.
    skill_id có thể là:
      - "generate/manual/checklist/ui-checklist"      (không có extension)
      - "generate/manual/checklist/ui-checklist.md"   (có extension)
      - "study/Study project requirements"
      - "manage/regression_management"
    """
    prompts_root = hub / PROMPTS_DIR

    # Thêm .md nếu chưa có
    if not skill_id.endswith(".md"):
        skill_id = skill_id + ".md"

    candidate = prompts_root / skill_id
    if candidate.exists():
        return candidate.resolve()
    return None


def list_skills(hub: Path) -> list[dict]:
    """
    Liệt kê tất cả skills từ hub/02_prompts/.
    Return: list of {id, name, path, category}
    """
    prompts_root = hub / PROMPTS_DIR
    if not prompts_root.exists():
        return []

    skills = []
    for md_file in sorted(prompts_root.rglob("*.md")):
        rel = md_file.relative_to(prompts_root)
        parts = rel.parts

        # Category = thư mục đầu tiên (generate, manage, study)
        category = parts[0] if len(parts) > 1 else "root"

        # skill_id = relative path không có extension
        skill_id = str(rel.with_suffix("")).replace("\\", "/")

        skills.append({
            "id": skill_id,
            "name": md_file.stem,
            "path": md_file.resolve(),
            "category": category,
            "relative": str(rel).replace("\\", "/"),
        })
    return skills


def resolve_kb_path(file_id: str, kb_root: Path) -> Optional[Path]:
    """
    Resolve file trong knowledge base.
    file_id: tên file có hoặc không có extension
    """
    if not file_id.endswith(".md"):
        file_id = file_id + ".md"

    # Tìm trong requirements/ trước
    req_path = kb_root / REQUIREMENTS_DIR / file_id
    if req_path.exists():
        return req_path.resolve()

    # Tìm toàn bộ kb
    for found in kb_root.rglob(file_id):
        return found.resolve()

    return None


def list_kb_files(kb_root: Path) -> list[dict]:
    """Liệt kê tất cả files trong knowledge base."""
    if not kb_root.exists():
        return []

    files = []
    for f in sorted(kb_root.rglob("*.md")):
        rel = f.relative_to(kb_root)
        files.append({
            "name": f.stem,
            "path": f.resolve(),
            "relative": str(rel).replace("\\", "/"),
            "subfolder": rel.parts[0] if len(rel.parts) > 1 else "root",
        })
    return files
