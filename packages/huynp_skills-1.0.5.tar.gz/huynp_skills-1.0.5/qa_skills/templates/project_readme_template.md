# {PROJECT_NAME}

> QA Framework — powered by [qa-skills](https://github.com/huynp/qa-skills)

---

## Cấu trúc project

```
{PROJECT_NAME}/
├── .agents/
│   └── workflows/
│       └── qc_follow.md          ← Workflow AI agent (trỏ đến hub)
├── .qa-skills                    ← Package config
├── Master_Instruction.md         ← Context dự án (load mỗi task)
├── 01_knowledge_base/
│   ├── requirements/             ← ĐẶT PRD / RULE / SRS TẠI ĐÂY
│   └── examples/
└── 03_test_design/
    ├── manual/
    │   ├── checklist/            ← Output: CL_*.md
    │   ├── test_cases/           ← Output: TC_*.md
    │   └── test_plan/            ← Output: TP_*.md
    └── automation/
        ├── scripts/
        └── test_plan/
```

---

## Hướng dẫn sử dụng

### Bước 1 — Load System Prompt
Mở file tại hub và dán vào **System Prompt** của AI tool:
```
{MASTER_ROLE_PATH}
```

### Bước 2 — Bắt đầu task
Đọc `Master_Instruction.md` (file này, tại thư mục project) mỗi khi bắt đầu task mới.

### Bước 3 — Thêm requirement documents
Đặt tài liệu PRD/Rule/SRS vào:
```
01_knowledge_base/requirements/
```

### Bước 4 — Chọn prompt phù hợp
```bash
qa-skills list                                           # Xem tất cả prompts
qa-skills path generate/manual/checklist/ui-checklist   # Lấy path của prompt
```

### Bước 5 — Lưu output
AI generate xong → lưu vào `03_test_design/` đúng thư mục.

---

## QA Skills CLI

```bash
huynp-skills status        # Kiểm tra trạng thái project
huynp-skills list          # Xem tất cả prompts từ hub
huynp-skills path <id>     # Lấy absolute path của prompt
huynp-skills kb list       # Xem documents trong knowledge base
huynp-skills kb path <f>   # Lấy path của requirement doc
```

---

*Được tạo tự động bởi `huynp-skills init` — {HuyNP}*
