> **⚙️ TASK PROMPT** — Kế thừa Role & Core Rules từ `master_role.md` tại hub.
> File này định nghĩa **Workflow thực thi**, **Output Routing** và **Context dự án**.
> Đọc file này **mỗi khi bắt đầu task**.

---

## 📌 Context

Project: **{PROJECT_NAME}** — {PROJECT_DESCRIPTION}
Người dùng cần các test case được định dạng khoa học để áp dụng trực tiếp vào quy trình QA.
Test case phải bao gồm: tiền điều kiện, các bước thực hiện, kết quả mong đợi, và dữ liệu thử nghiệm.

---

## 🎯 Objective

Hỗ trợ người dùng tạo bộ test case / checklist theo cấu trúc chuẩn, đảm bảo:
- Định dạng rõ ràng, đầy đủ thông tin
- Dễ sử dụng trong quá trình kiểm thử thực tế
- Chọn đúng Format output theo loại testing (xem mục Instructions)

---

## 🔄 Quy trình thực thi (STEP 0→6)

```
[INPUT: PRD / SRS / Feature / API Spec / Rule]
         │
         ▼
  STEP 0: Load Master_Instruction   → File này — lấy Context, Format, Routing
         │
         ▼
  STEP 1: Requirement Review        → Phát hiện Gap / Mâu thuẫn / Thiếu sót (Sub-skill 01)
         │
         ▼
  STEP 2: Risk Assessment           → Ma trận Likelihood × Impact (Sub-skill 02)
         │
         ▼
  STEP 3: User Flow + Use Case      → Mermaid Diagram (Sub-skill 03)
         │
         ▼
  STEP 4: Test Plan                 → Phạm vi, chiến lược, môi trường (Sub-skill 04)
         │
         ▼
  STEP 5: Test Checklist            → Danh sách kiểm tra nhanh (Sub-skill 05)
         │
         ▼
  STEP 6: Test Case Table           → Format A hoặc B theo Sub-skill 06
         │
         ▼
[OUTPUT: Tài liệu QA hoàn chỉnh → lưu vào 03_test_design/]
```

> **STEP 0 là bắt buộc** — không được bỏ qua dù người dùng chỉ yêu cầu một bước cụ thể.

---

## 🗺️ Hướng dẫn vận hành nhanh

| Tình huống | Hành động |
|---|---|
| Nhận PRD/SRS đầy đủ | Step 0 → Step 1 → 6 |
| Chỉ có mô tả ngắn | Step 0 → Step 1 (hỏi làm rõ) → Step 2–6 |
| Chỉ cần test case nhanh | Step 0 → Step 3 (flow) → Step 6 (table) |
| Chỉ cần review requirement | Step 0 → Step 1 + Step 2 |
| Chỉ cần checklist release | Step 0 → Step 5 |
| Hệ thống AI/Camera | Step 0 → Step 1–6 + Sub-skill 08 + Sub-skill 10 |
| Rule AI có thông số kỹ thuật nội bộ | Step 0 → Sub-skill 10 → Step 6 |

---

## 📐 Instructions — Chọn Format output

| Loại testing | Format | Tham chiếu |
|---|---|---|
| Functional / Regression / UI | **Format A** — Bảng 11 cột | → Sub-skill 06 trong `master_role.md` |
| AI Rule / Camera / Safety | **Format B** — Bảng 12 cột (+ cột `Test Data`) | → Sub-skill 06 trong `master_role.md` |
| Checklist nhanh | Danh sách `- [ ]` với Title, Precondition, Expected | → Sub-skill 05 trong `master_role.md` |

---

## 📁 Output Routing

| Loại output | Thư mục đích |
|---|---|
| Test Case | `03_test_design/manual/test_cases/[module]/` |
| Checklist | `03_test_design/manual/checklist/` |
| Test Plan | `03_test_design/manual/test_plan/` |
| Script | `03_test_design/automation/scripts/` |

---

## ⛔ Quy tắc Workflow

1. **STEP 0 bắt buộc** — Mọi task phải đọc file này trước khi thực hiện STEP 1–6
2. **Không dùng Format A cho rule AI** — phải dùng Format B (12 cột + cột `Test Data`)
3. **Không dùng pixels/frame** trong cột `Test Data` của Format B — áp dụng Sub-skill 10
4. **Không tạo test case khi chưa xác định loại rule** — hỏi rõ AI hay Functional trước
