"""
config.py — Đọc/ghi global config và project config (.qa-skills)
Priority: 
  1. Environment variable QA_SKILLS_HUB
  2. Project .qa-skills [hub]
  3. Global ~/.config/qa-skills/config.ini [hub]
  4. Auto-detect from package location
"""
import configparser
import os
from pathlib import Path

# ── Paths ──────────────────────────────────────────────────────────────
GLOBAL_CONFIG_DIR = Path.home() / ".config" / "qa-skills"
GLOBAL_CONFIG_FILE = GLOBAL_CONFIG_DIR / "config.ini"
PROJECT_CONFIG_NAME = ".qa-skills"
PACKAGE_ROOT = Path(__file__).parent.parent  # d:\testing-skills\_pkg


# ── Global config ───────────────────────────────────────────────────────
def get_global_hub() -> Path | None:
    """Đọc hub path từ global config (hoặc từ env var)."""
    # 1. Check environment variable
    env_hub = os.getenv("QA_SKILLS_HUB")
    if env_hub:
        hub_path = Path(env_hub)
        if hub_path.exists():
            return hub_path.resolve()
    
    # 2. Check global config
    if not GLOBAL_CONFIG_FILE.exists():
        return None
    cfg = configparser.ConfigParser()
    cfg.read(GLOBAL_CONFIG_FILE, encoding="utf-8")
    hub = cfg.get("global", "hub", fallback=None)
    if hub:
        hub_path = Path(hub)
        # Support relative path từ package
        if not hub_path.is_absolute():
            hub_path = PACKAGE_ROOT / hub_path
        if hub_path.exists():
            return hub_path.resolve()
    return None


def set_global_hub(hub_path: Path) -> None:
    """Ghi hub path vào global config."""
    GLOBAL_CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    cfg = configparser.ConfigParser()
    cfg["global"] = {"hub": str(hub_path)}
    with open(GLOBAL_CONFIG_FILE, "w", encoding="utf-8") as f:
        cfg.write(f)


# ── Project config ──────────────────────────────────────────────────────
def find_project_config(start_dir: Path = None) -> Path | None:
    """Tìm file .qa-skills từ thư mục hiện tại lên trên (walk-up)."""
    current = (start_dir or Path.cwd()).resolve()
    for directory in [current, *current.parents]:
        candidate = directory / PROJECT_CONFIG_NAME
        if candidate.exists():
            return candidate
    return None


def read_project_config(config_file: Path) -> dict:
    """Parse .qa-skills → dict."""
    cfg = configparser.ConfigParser()
    cfg.read(config_file, encoding="utf-8")
    project_dir = config_file.parent

    raw_hub = cfg.get("project", "hub", fallback="")
    raw_kb = cfg.get("project", "knowledge_base", fallback="01_knowledge_base")

    # Resolve hub: nếu là relative path thì resolve từ project dir
    hub_path = Path(raw_hub) if raw_hub else None
    if hub_path and not hub_path.is_absolute():
        hub_path = (project_dir / hub_path).resolve()

    # KB luôn là relative từ project dir
    kb_path = (project_dir / raw_kb).resolve()

    return {
        "config_file": config_file,
        "project_dir": project_dir,
        "name": cfg.get("project", "name", fallback=project_dir.name),
        "description": cfg.get("project", "description", fallback=""),
        "hub": hub_path,
        "knowledge_base": kb_path,
        "version": cfg.get("project", "version", fallback="1.0.0"),
    }


def write_project_config(project_dir: Path, name: str, description: str,
                          hub: Path, kb_rel: str = "01_knowledge_base") -> Path:
    """Tạo file .qa-skills trong project_dir."""
    cfg = configparser.ConfigParser()
    cfg["project"] = {
        "name": name,
        "description": description,
        "hub": str(hub),
        "knowledge_base": kb_rel,
        "version": "1.0.0",
    }
    config_file = project_dir / PROJECT_CONFIG_NAME
    with open(config_file, "w", encoding="utf-8") as f:
        cfg.write(f)
    return config_file


def auto_detect_hub() -> Path | None:
    """Auto-detect hub từ parent directories."""
    current = PACKAGE_ROOT
    # Tìm thư mục _core từ cùng level với _pkg hoặc trên
    for _ in range(3):  # Search up to 3 levels
        parent = current.parent
        candidate = parent / "_core"
        if candidate.exists() and (candidate / "02_prompts").exists():
            return candidate.resolve()
        current = parent
    return None


# ── Hub resolver (priority chain) ──────────────────────────────────────
def resolve_hub(project_config: dict = None) -> Path:
    """
    Resolve hub path theo priority:
    1. Environment variable QA_SKILLS_HUB
    2. Project .qa-skills [hub]
    3. Global ~/.config/qa-skills/config.ini [hub]
    4. Auto-detect from parent directories
    5. Raise error với hướng dẫn
    """
    import click

    # 1. Environment variable
    env_hub = os.getenv("QA_SKILLS_HUB")
    if env_hub:
        hub = Path(env_hub).resolve()
        if hub.exists():
            return hub

    # 2. Project config
    if project_config and project_config.get("hub"):
        hub = project_config["hub"]
        if hub and hub.exists():
            return hub

    # 3. Global config
    global_hub = get_global_hub()
    if global_hub and global_hub.exists():
        return global_hub

    # 4. Auto-detect
    auto_hub = auto_detect_hub()
    if auto_hub:
        return auto_hub

    # 5. Error
    raise click.ClickException(
        "\n❌ Không tìm thấy Skill Hub.\n"
        "\nCách fix:\n"
        "  1️⃣  Set environment variable: QA_SKILLS_HUB=D:\\testing-skills\\_core\n"
        "  2️⃣  Hoặc chạy: qa-skills hub set <path>\n"
        "  3️⃣  Hoặc tạo file .qa-skills trong project"
    )
