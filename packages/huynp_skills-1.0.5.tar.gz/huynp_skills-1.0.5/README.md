# huynp-skills

> **Centralized QA Prompt Skill Manager** — Quản lý bộ skill prompts QA tập trung cho nhiều project.

[![PyPI version](https://badge.fury.io/py/huynp-skills.svg)](https://badge.fury.io/py/huynp-skills)
[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)

---

## Giới thiệu

`qa-skills` là CLI tool giúp bạn:
- **Tập trung** toàn bộ QA prompt skills tại một nơi (skill hub)
- **Mỗi project** chỉ cần chạy `qa-skills init` → tự động scaffold cấu trúc chuẩn
- **Không copy file** — tất cả project chia sẻ cùng một nguồn skill
- **Cài qua pip** — không cần quyền Admin

## Cài đặt

```bash
pip install --user huynp-skills
```

## Thiết lập lần đầu

### 🚀 Quick Setup (Auto-detect)

```bash
# 1. Install package
pip install --user huynp-skills

# 2. Auto-detect hub (nếu _core folder gần vị trí cài)
huynp-skills hub auto-detect

# 3. Kiểm tra
huynp-skills hub status
```

### 📝 Hoặc Setup Manual

```bash
# Set global hub path
huynp-skills hub set D:\testing-skills\_core

# Kiểm tra
huynp-skills hub status
```

### 🔧 Hoặc Set Environment Variable

```bash
# PowerShell
$env:QA_SKILLS_HUB = 'D:\testing-skills\_core'

# Then verify
huynp-skills hub status
```

📖 **Xem chi tiết**: [SETUP_GUIDE.md](SETUP_GUIDE.md) — 3 cách setup linh hoạt

## Sử dụng với project mới

```bash
# Mỗi project mới
cd D:\my-new-project
huynp-skills init

# Xem prompts có sẵn
huynp-skills list

# Lấy path của prompt để dùng với AI tool
huynp-skills path generate/manual/checklist/ui-checklist

# Xem trạng thái project
huynp-skills status
```

## Commands

| Command | Mô tả |
|---|---|
| `huynp-skills hub set <path>` | Set global skill hub |
| `huynp-skills hub status` | Xem hub hiện tại |
| `huynp-skills init` | Khởi tạo project (scaffold + config) |
| `huynp-skills status` | Trạng thái project (hub + KB + output) |
| `huynp-skills list` | Liệt kê tất cả prompts từ hub |
| `huynp-skills path <id>` | Lấy absolute path của prompt |
| `huynp-skills kb list` | Liệt kê documents trong Knowledge Base |
| `huynp-skills kb path <file>` | Lấy path của requirement document |

## Cấu trúc Project sau `qa-skills init`

```
my-project/
├── .agents/
│   └── workflows/
│       └── qc_follow.md          ← Workflow AI (paths đến hub)
├── .qa-skills                    ← Package config
├── Master_Instruction.md         ← Context dự án (load mỗi task)
├── 01_knowledge_base/
│   └── requirements/             ← Đặt PRD/Rule/SRS tại đây
└── 03_test_design/
    ├── manual/
    │   ├── checklist/            ← Output: CL_*.md
    │   ├── test_cases/           ← Output: TC_*.md
    │   └── test_plan/
    └── automation/
        └── scripts/
```

## License

MIT
