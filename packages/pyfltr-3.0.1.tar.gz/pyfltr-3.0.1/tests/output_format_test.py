# pylint: disable=missing-module-docstring
# pylint: disable=missing-function-docstring
# pylint: disable=protected-access

import json
import logging
import pathlib
import subprocess

import pytest

import pyfltr.config
import pyfltr.llm_output
import pyfltr.main
from tests.conftest import make_command_result as _make_result
from tests.conftest import make_error_location as _make_error


@pytest.fixture(name="default_config")
def _default_config() -> pyfltr.config.Config:
    return pyfltr.config.create_default_config()


# ---------------------------------------------------------------------------
# build_lines のユニットテスト
# ---------------------------------------------------------------------------


def test_build_lines_supported_tool_diagnostics(default_config):
    """error_parser 対応ツールの診断が diagnostic レコードとして出ること。"""
    errors = [
        _make_error("mypy", "src/a.py", 10, "bad type", col=4),
        _make_error("mypy", "src/a.py", 20, "missing return"),
    ]
    result = _make_result("mypy", returncode=1, errors=errors)
    lines = pyfltr.llm_output.build_lines([result], default_config, exit_code=1, commands=["mypy"], files=5)
    parsed = [json.loads(line) for line in lines]

    assert [r["kind"] for r in parsed] == ["header", "diagnostic", "diagnostic", "tool", "summary"]
    assert parsed[1] == {
        "kind": "diagnostic",
        "tool": "mypy",
        "file": "src/a.py",
        "line": 10,
        "col": 4,
        "msg": "bad type",
    }
    assert parsed[2] == {
        "kind": "diagnostic",
        "tool": "mypy",
        "file": "src/a.py",
        "line": 20,
        "msg": "missing return",
    }
    assert parsed[3]["diagnostics"] == 2
    assert parsed[3]["status"] == "failed"
    assert parsed[4]["diagnostics"] == 2
    assert parsed[4]["failed"] == 1


def test_build_lines_warnings_prepended(default_config):
    """warnings 引数の内容が diagnostic より前に kind="warning" で出力されること。"""
    result = _make_result("ruff-format", returncode=0, command_type="formatter")
    warnings = [
        {"source": "config", "message": "pre-commit 設定ファイル不在"},
        {"source": "git", "message": "git が見つからない"},
    ]
    lines = pyfltr.llm_output.build_lines(
        [result], default_config, exit_code=0, commands=["ruff-format"], files=1, warnings=warnings
    )
    parsed = [json.loads(line) for line in lines]

    assert parsed[0]["kind"] == "header"
    assert [r["kind"] for r in parsed[1:3]] == ["warning", "warning"]
    assert parsed[1] == {"kind": "warning", "source": "config", "msg": "pre-commit 設定ファイル不在"}
    assert parsed[2] == {"kind": "warning", "source": "git", "msg": "git が見つからない"}
    # warnings の後に tool レコード、最後に summary が並ぶ
    assert [r["kind"] for r in parsed[3:]] == ["tool", "summary"]


def test_build_lines_no_warnings_when_omitted(default_config):
    """warnings 引数を省略すると warning レコードは出ない。"""
    result = _make_result("ruff-format", returncode=0, command_type="formatter")
    lines = pyfltr.llm_output.build_lines([result], default_config, exit_code=0)
    parsed = [json.loads(line) for line in lines]
    assert all(r["kind"] != "warning" for r in parsed)


def test_build_lines_unsupported_tool_only(default_config):
    """error_parser 非対応ツール (ruff-format) は tool レコードのみ（header省略時）。"""
    result = _make_result("ruff-format", returncode=1, command_type="formatter", has_error=False)
    lines = pyfltr.llm_output.build_lines([result], default_config, exit_code=1)
    parsed = [json.loads(line) for line in lines]

    assert [r["kind"] for r in parsed] == ["tool", "summary"]
    assert parsed[0]["tool"] == "ruff-format"
    assert parsed[0]["status"] == "formatted"
    assert parsed[0]["diagnostics"] == 0
    assert "message" not in parsed[0]
    assert parsed[1]["formatted"] == 1


def test_build_lines_mixed_order(default_config):
    """ツール単位でdiagnostic+toolがグルーピングされ、config.command_names順に並ぶこと。"""
    mypy_result = _make_result(
        "mypy",
        returncode=1,
        errors=[
            _make_error("mypy", "src/b.py", 5, "later"),
            _make_error("mypy", "src/a.py", 30, "earlier in a"),
        ],
    )
    pylint_result = _make_result(
        "pylint",
        returncode=1,
        errors=[_make_error("pylint", "src/a.py", 10, "C0114: missing docstring")],
    )
    ruff_format_result = _make_result("ruff-format", returncode=0, command_type="formatter")

    # config.command_names 順では ruff-format → mypy → pylint
    lines = pyfltr.llm_output.build_lines(
        [mypy_result, pylint_result, ruff_format_result],
        default_config,
        exit_code=1,
        commands=["ruff-format", "mypy", "pylint"],
        files=10,
    )
    parsed = [json.loads(line) for line in lines]

    # header → ツール順でグルーピング: ruff-format(tool) → mypy(diag, diag, tool) → pylint(diag, tool) → summary
    assert [r["kind"] for r in parsed] == [
        "header",
        "tool",  # ruff-format
        "diagnostic",
        "diagnostic",
        "tool",  # mypy
        "diagnostic",
        "tool",  # pylint
        "summary",
    ]

    # mypy 内の diagnostic はファイル/行順
    mypy_diagnostics = [r for r in parsed if r["kind"] == "diagnostic" and r["tool"] == "mypy"]
    assert [(r["file"], r["line"]) for r in mypy_diagnostics] == [
        ("src/a.py", 30),
        ("src/b.py", 5),
    ]

    tool_records = [r for r in parsed if r["kind"] == "tool"]
    assert [r["tool"] for r in tool_records] == ["ruff-format", "mypy", "pylint"]


def test_build_lines_ensure_ascii_false(default_config):
    """日本語メッセージが生のまま出ること (ensure_ascii=False)。"""
    errors = [_make_error("mypy", "src/a.py", 1, "型が合いません")]
    result = _make_result("mypy", returncode=1, errors=errors)
    lines = pyfltr.llm_output.build_lines([result], default_config, exit_code=1)
    assert "型が合いません" in lines[0]
    assert "\\u" not in lines[0]


def test_build_lines_skipped_status(default_config):
    """returncode=None (skipped) は rc キーを省略し diagnostics=0 の tool レコードを出す。"""
    result = _make_result("mypy", returncode=None, has_error=False)
    lines = pyfltr.llm_output.build_lines([result], default_config, exit_code=0)
    parsed = [json.loads(line) for line in lines]

    tool_record = parsed[0]
    assert tool_record["kind"] == "tool"
    assert tool_record["status"] == "skipped"
    assert "rc" not in tool_record


# ---------------------------------------------------------------------------
# tool レコードの message フィールド
# ---------------------------------------------------------------------------


def test_tool_record_message_on_failure_without_diagnostics(default_config):
    """status=failed かつ diagnostics=0 のとき、output 末尾が message に入ること。"""
    output = "line1\nline2\nError: command not found\n"
    result = _make_result("shellcheck", returncode=127, output=output)
    lines = pyfltr.llm_output.build_lines([result], default_config, exit_code=1)
    tool_record = json.loads(lines[0])
    assert tool_record["status"] == "failed"
    assert "message" in tool_record
    assert "Error: command not found" in tool_record["message"]


def test_tool_record_message_truncates_long_output(default_config):
    """長い output は末尾 30 行かつ 2000 文字にトリムされること。"""
    many_lines = "\n".join(f"line{i}" for i in range(100))
    result = _make_result("shellcheck", returncode=1, output=many_lines)
    lines = pyfltr.llm_output.build_lines([result], default_config, exit_code=1)
    tool_record = json.loads(lines[0])
    msg = tool_record["message"]
    assert msg.startswith("... (truncated)")
    assert "line99" in msg
    assert "line70" in msg  # 末尾 30 行の範囲
    assert "line69" not in msg  # 範囲外
    assert len(msg) <= 2000 + len("... (truncated)\n")


def test_tool_record_no_message_when_diagnostics_present(default_config):
    """failed でも diagnostics > 0 のときは message を出さない。"""
    errors = [_make_error("mypy", "src/a.py", 1, "bad")]
    result = _make_result("mypy", returncode=1, output="verbose mypy output", errors=errors)
    lines = pyfltr.llm_output.build_lines([result], default_config, exit_code=1)
    tool_record = next(json.loads(line) for line in lines if json.loads(line)["kind"] == "tool")
    assert "message" not in tool_record


def test_tool_record_no_message_on_success(default_config):
    """status=succeeded/formatted では message を出さない。"""
    ok = _make_result("mypy", returncode=0, output="all ok")
    fmt = _make_result("ruff-format", returncode=1, command_type="formatter", output="reformatted", has_error=False)
    lines = pyfltr.llm_output.build_lines([ok, fmt], default_config, exit_code=0)
    for line in lines:
        record = json.loads(line)
        if record["kind"] == "tool":
            assert "message" not in record


def test_tool_record_no_message_when_output_empty(default_config):
    """failed でも output が空なら message を出さない (キーごと省略)。"""
    result = _make_result("shellcheck", returncode=1, output="")
    lines = pyfltr.llm_output.build_lines([result], default_config, exit_code=1)
    tool_record = json.loads(lines[0])
    assert "message" not in tool_record


# ---------------------------------------------------------------------------
# write_jsonl の出力先
# ---------------------------------------------------------------------------


def test_write_jsonl_stdout(default_config, capsys):
    """destination=None のとき sys.stdout に書き出す。"""
    result = _make_result("mypy", returncode=0)
    pyfltr.llm_output.write_jsonl([result], default_config, exit_code=0, destination=None)
    captured = capsys.readouterr()
    assert captured.err == ""
    parsed = [json.loads(line) for line in captured.out.splitlines()]
    assert parsed[-1]["kind"] == "summary"
    assert parsed[-1]["succeeded"] == 1


def test_write_jsonl_file_creates_parent(default_config, tmp_path):
    """destination 指定時、親ディレクトリが自動作成される。"""
    destination = tmp_path / "sub" / "dir" / "out.jsonl"
    result = _make_result("mypy", returncode=0)
    pyfltr.llm_output.write_jsonl([result], default_config, exit_code=0, destination=destination)
    assert destination.exists()
    content = destination.read_text(encoding="utf-8")
    parsed = [json.loads(line) for line in content.splitlines()]
    assert parsed[-1]["kind"] == "summary"


def test_calculate_returncode_matches_summary_exit(default_config):
    """summary.exit と calculate_returncode の戻り値が一致すること。"""
    results = [
        _make_result("mypy", returncode=1, errors=[_make_error("mypy", "a.py", 1, "bad")]),
        _make_result("ruff-format", returncode=0, command_type="formatter"),
    ]
    exit_code = pyfltr.main.calculate_returncode(results, exit_zero_even_if_formatted=False)
    lines = pyfltr.llm_output.build_lines(
        results, default_config, exit_code=exit_code, commands=["mypy", "ruff-format"], files=3
    )
    summary = json.loads(lines[-1])
    assert summary["exit"] == exit_code == 1


# ---------------------------------------------------------------------------
# CLI 統合テスト (pyfltr.main.run)
# ---------------------------------------------------------------------------


def test_run_cli_jsonl_stdout_suppresses_text(mocker, capsys):
    """jsonl + stdout モードでは stdout は JSONL のみで text ログは出ない。"""
    proc = subprocess.CompletedProcess(["mypy"], returncode=0, stdout="mypy ok")
    mocker.patch("pyfltr.command._run_subprocess", return_value=proc)

    returncode = pyfltr.main.run(["ci", "--output-format=jsonl", "--commands=mypy", str(pathlib.Path(__file__).parent.parent)])
    assert returncode == 0
    captured = capsys.readouterr()
    assert "----- pyfltr" not in captured.out
    assert "summary" not in captured.out or '"kind":"summary"' in captured.out
    lines = [line for line in captured.out.splitlines() if line.strip()]
    assert lines, "JSONL が 1 行も出ていない"
    first = json.loads(lines[0])
    assert first["kind"] == "header"
    assert "mypy" in first["commands"]
    last = json.loads(lines[-1])
    assert last["kind"] == "summary"
    assert last["exit"] == 0


def test_run_cli_output_file_keeps_text_stdout(mocker, caplog, tmp_path):
    """--output-file 指定時は stdout には従来 text、ファイルには JSONL。"""
    proc = subprocess.CompletedProcess(["mypy"], returncode=0, stdout="mypy ok")
    mocker.patch("pyfltr.command._run_subprocess", return_value=proc)

    destination = tmp_path / "out.jsonl"
    with caplog.at_level(logging.INFO):
        returncode = pyfltr.main.run(
            [
                "ci",
                "--output-format=jsonl",
                f"--output-file={destination}",
                "--commands=mypy",
                str(pathlib.Path(__file__).parent.parent),
            ]
        )
    assert returncode == 0
    # 従来の text ログが logging 経由で出ている
    assert "summary" in caplog.text
    # ファイルには JSONL
    lines = destination.read_text(encoding="utf-8").splitlines()
    assert json.loads(lines[-1])["kind"] == "summary"


def test_run_cli_jsonl_ignores_ui(mocker, capsys):
    """jsonl + stdout モードでは --ui が silently 無効化される (stderr に漏れない)。"""
    proc = subprocess.CompletedProcess(["mypy"], returncode=0, stdout="mypy ok")
    mocker.patch("pyfltr.command._run_subprocess", return_value=proc)

    returncode = pyfltr.main.run(
        ["ci", "--output-format=jsonl", "--ui", "--commands=mypy", str(pathlib.Path(__file__).parent.parent)]
    )
    assert returncode == 0
    captured = capsys.readouterr()
    assert captured.err == ""
    lines = [line for line in captured.out.splitlines() if line.strip()]
    assert lines, "JSONL が 1 行も出ていない"
    last = json.loads(lines[-1])
    assert last["kind"] == "summary"


def test_run_cli_env_var_jsonl(mocker, capsys, monkeypatch):
    """PYFLTR_OUTPUT_FORMAT=jsonl で --output-format 未指定でも JSONL 出力になる。"""
    proc = subprocess.CompletedProcess(["mypy"], returncode=0, stdout="mypy ok")
    mocker.patch("pyfltr.command._run_subprocess", return_value=proc)
    monkeypatch.setenv("PYFLTR_OUTPUT_FORMAT", "jsonl")

    returncode = pyfltr.main.run(["ci", "--commands=mypy", str(pathlib.Path(__file__).parent.parent)])
    assert returncode == 0
    captured = capsys.readouterr()
    assert "----- pyfltr" not in captured.out
    lines = [line for line in captured.out.splitlines() if line.strip()]
    assert lines, "JSONL が 1 行も出ていない"
    last = json.loads(lines[-1])
    assert last["kind"] == "summary"


def test_run_cli_env_var_overridden_by_cli(mocker, caplog, monkeypatch):
    """PYFLTR_OUTPUT_FORMAT より CLI --output-format=text が優先される。"""
    proc = subprocess.CompletedProcess(["mypy"], returncode=0, stdout="mypy ok")
    mocker.patch("pyfltr.command._run_subprocess", return_value=proc)
    monkeypatch.setenv("PYFLTR_OUTPUT_FORMAT", "jsonl")

    with caplog.at_level(logging.INFO):
        pyfltr.main.run(["ci", "--output-format=text", "--commands=mypy", str(pathlib.Path(__file__).parent.parent)])
    # CLI で text を明示しているので従来 text ログが出るべき
    assert "summary" in caplog.text


def test_run_cli_env_var_invalid(monkeypatch):
    """PYFLTR_OUTPUT_FORMAT に不正値が入っている場合は SystemExit で終了する。"""
    # argparse の parents 共有によるデフォルト汚染を避けるため、_resolve_output_format を直接テストする。
    # （cli_value=None の場合のみ環境変数が参照される）
    monkeypatch.setenv("PYFLTR_OUTPUT_FORMAT", "yaml")
    parser = pyfltr.main.build_parser()
    with pytest.raises(SystemExit):
        pyfltr.main._resolve_output_format(parser, None)


def test_run_cli_jsonl_restores_logger_state(mocker, caplog, capsys):
    """jsonl モード実行後、text モードの logger が復元されること。"""
    proc = subprocess.CompletedProcess(["mypy"], returncode=0, stdout="mypy ok")
    mocker.patch("pyfltr.command._run_subprocess", return_value=proc)

    # 1 回目: jsonl モード (logger 抑止)
    pyfltr.main.run(["ci", "--output-format=jsonl", "--commands=mypy", str(pathlib.Path(__file__).parent.parent)])
    # 1 回目の stdout は読み捨てる (capsys をリセット)
    capsys.readouterr()
    caplog.clear()

    # 2 回目: text モード (従来どおりのログが出るべき)。
    with caplog.at_level(logging.INFO):
        pyfltr.main.run(["ci", "--commands=mypy", str(pathlib.Path(__file__).parent.parent)])

    assert "summary" in caplog.text


# ---------------------------------------------------------------------------
# build_tool_lines のユニットテスト
# ---------------------------------------------------------------------------


def test_build_tool_lines_with_diagnostics(default_config):
    """diagnostic行+tool行がツール単位でまとまること。"""
    errors = [
        _make_error("mypy", "src/b.py", 5, "later"),
        _make_error("mypy", "src/a.py", 10, "earlier"),
    ]
    result = _make_result("mypy", returncode=1, errors=errors)
    lines = pyfltr.llm_output.build_tool_lines(result, default_config)
    parsed = [json.loads(line) for line in lines]

    assert len(parsed) == 3
    # diagnostic行はツール内でファイル/行順にソートされる
    assert parsed[0]["kind"] == "diagnostic"
    assert parsed[0]["file"] == "src/a.py"
    assert parsed[1]["kind"] == "diagnostic"
    assert parsed[1]["file"] == "src/b.py"
    # 最後にtool行
    assert parsed[2]["kind"] == "tool"
    assert parsed[2]["diagnostics"] == 2


def test_build_tool_lines_no_diagnostics(default_config):
    """diagnosticがないツールはtool行のみ。"""
    result = _make_result("ruff-format", returncode=0, command_type="formatter")
    lines = pyfltr.llm_output.build_tool_lines(result, default_config)
    parsed = [json.loads(line) for line in lines]

    assert len(parsed) == 1
    assert parsed[0]["kind"] == "tool"
    assert parsed[0]["diagnostics"] == 0


# ---------------------------------------------------------------------------
# write_jsonl_streaming のユニットテスト
# ---------------------------------------------------------------------------


def test_write_jsonl_streaming(default_config, capsys):
    """ストリーミング書き出しがstdoutに即時出力されること。"""
    errors = [_make_error("mypy", "src/a.py", 10, "bad type")]
    result = _make_result("mypy", returncode=1, errors=errors)
    pyfltr.llm_output.write_jsonl_streaming(result, default_config)

    captured = capsys.readouterr()
    assert captured.err == ""
    parsed = [json.loads(line) for line in captured.out.splitlines()]
    assert len(parsed) == 2
    assert parsed[0]["kind"] == "diagnostic"
    assert parsed[1]["kind"] == "tool"


# ---------------------------------------------------------------------------
# write_jsonl_footer のユニットテスト
# ---------------------------------------------------------------------------


def test_write_jsonl_footer_with_warnings(capsys):
    """warning行+summary行がstdoutに出力されること。"""
    result = _make_result("mypy", returncode=1, errors=[_make_error("mypy", "a.py", 1, "bad")])
    warnings = [{"source": "config", "message": "test warning"}]
    pyfltr.llm_output.write_jsonl_footer(
        [result],
        exit_code=1,
        warnings=warnings,
    )

    captured = capsys.readouterr()
    parsed = [json.loads(line) for line in captured.out.splitlines()]
    assert len(parsed) == 2
    assert parsed[0]["kind"] == "warning"
    assert parsed[0]["msg"] == "test warning"
    assert parsed[1]["kind"] == "summary"
    assert parsed[1]["exit"] == 1


def test_write_jsonl_footer_no_warnings(capsys):
    """warningがない場合はsummary行のみ。"""
    result = _make_result("mypy", returncode=0)
    pyfltr.llm_output.write_jsonl_footer([result], exit_code=0)

    captured = capsys.readouterr()
    parsed = [json.loads(line) for line in captured.out.splitlines()]
    assert len(parsed) == 1
    assert parsed[0]["kind"] == "summary"
    assert parsed[0]["succeeded"] == 1


# ---------------------------------------------------------------------------
# header レコードのユニットテスト
# ---------------------------------------------------------------------------


def test_build_header_record_fields():
    """_build_header_record が必要なフィールドをすべて含むこと。"""
    record = pyfltr.llm_output._build_header_record(["ruff-format", "mypy"], 42)
    assert record["kind"] == "header"
    assert record["commands"] == ["ruff-format", "mypy"]
    assert record["files"] == 42
    assert "version" in record
    assert "python" in record
    assert "executable" in record
    assert "platform" in record
    assert "cwd" in record


def test_build_lines_header_first(default_config):
    """commands/filesを指定するとheader行が先頭に出力されること。"""
    result = _make_result("mypy", returncode=0)
    lines = pyfltr.llm_output.build_lines([result], default_config, exit_code=0, commands=["mypy"], files=10)
    parsed = [json.loads(line) for line in lines]
    assert parsed[0]["kind"] == "header"
    assert parsed[0]["commands"] == ["mypy"]
    assert parsed[0]["files"] == 10
    assert parsed[-1]["kind"] == "summary"


def test_build_lines_no_header_when_omitted(default_config):
    """commands/filesを省略するとheader行は出力されないこと。"""
    result = _make_result("mypy", returncode=0)
    lines = pyfltr.llm_output.build_lines([result], default_config, exit_code=0)
    parsed = [json.loads(line) for line in lines]
    assert all(r["kind"] != "header" for r in parsed)


def test_write_jsonl_header_stdout(capsys):
    """write_jsonl_headerがstdoutにheader行を書き出すこと。"""
    pyfltr.llm_output.write_jsonl_header(commands=["ruff-format", "mypy"], files=5)
    captured = capsys.readouterr()
    parsed = [json.loads(line) for line in captured.out.splitlines()]
    assert len(parsed) == 1
    assert parsed[0]["kind"] == "header"
    assert parsed[0]["commands"] == ["ruff-format", "mypy"]
    assert parsed[0]["files"] == 5
