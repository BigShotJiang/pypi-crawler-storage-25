__author__ = "Robust Robot Systems, TU Delft"
__copyright__ = "Copyright 2026, R2S"
__license__ = "Apache-2.0"
__version__ = "1.0.3"

from abc import ABC, abstractmethod
from greenhouse_sim.dynamics import *


class Sensor(ABC):
    """
    Abstract base class for all greenhouse sensors.
    Every sensor must define:
      - NAME (string, variable type)
      - retrieve_data(tag_id, position, env_state)
    """

    type: str

    @abstractmethod
    def retrieve_data(self, position, time):
        """Return a simulated sensor reading."""
        pass

    def __add__(self, other):
        """
        Overload add to auto create composite sensors
        :param other: Other sensor
        :return: Composite sensor
        """
        if isinstance(other, Sensor):
            if self.type != other.type:
                raise ValueError("Cannot combine sensors of different types.")
            return CompositeSensor([self, other])
        raise TypeError("Can only add Sensor objects.")

    def __str__(self):
        return f"{self.type} sensor"

class CompositeSensor(Sensor):
    """
    Composite sensor which combines multiple sensors using max operation.
    """
    type = "composite"

    def __init__(self, sensors):
        self.sensors = sensors


    def retrieve_data(self, position, time):
        # This sensor doesn't simulate data itself, but combines others
        values = [s.retrieve_data(position, time) for s in self.sensors]
        return max(values)


    def __add__(self, other):
        if isinstance(other, Sensor):
            if other.type != self.sensors[0].type:
                raise ValueError("Cannot combine sensors of different types.")
            # append and return a NEW composed sensor
            return CompositeSensor(self.sensors + [other])
        raise TypeError("Can only add Sensor objects.")

    def __str__(self):
        return f"Composite {self.sensors[0].type} sensor with {len(self.sensors)} components"

class TemperatureSensor(Sensor):
    """
    Temperature sensor.
    """
    type = "temperature"

    def __init__(self, params: dict):
        self.params = params
        self.dynamics = AVAILABLE_DYNAMICS[params.get("dynamics", 'uniform')](params)


    def retrieve_data(self, position, time):
        return self.dynamics.query(position, time)


class HumiditySensor(Sensor):
    """
    Humidity sensor.
    """

    type = "humidity"

    def __init__(self, params: dict):
        self.params = params
        self.dynamics = AVAILABLE_DYNAMICS[params.get("dynamics", 'uniform')](params)

    def retrieve_data(self, position, time):
        return self.dynamics.query(position, time)


class CO2Sensor(Sensor):
    """
    CO2 sensor.
    """

    type = "co2"

    def __init__(self, params: dict):
        self.params = params
        self.dynamics = AVAILABLE_DYNAMICS[params.get("dynamics", 'uniform')](params)

    def retrieve_data(self, position, time):
        return self.dynamics.query(position, time)


class LightSensor(Sensor):
    """
    Light sensor.
    """

    type = "light"

    def __init__(self, params: dict):
        self.params = params
        self.dynamics = AVAILABLE_DYNAMICS[params.get("dynamics", 'uniform')](params)

    def retrieve_data(self, position, time):
        return self.dynamics.query(position, time)


class SoilMoistureSensor(Sensor):
    """
    Soil moisture sensor.
    """

    type = "soil_moisture"

    def __init__(self, params: dict):
        self.params = params
        self.dynamics = AVAILABLE_DYNAMICS[params.get("dynamics", 'uniform')](params)

    def retrieve_data(self, position, time):
        return self.dynamics.query(position, time)


# Convenience list for GUI (checkbox generation)
AVAILABLE_SENSORS = {cls({}).type: cls for cls in Sensor.__subclasses__() if cls is not CompositeSensor}

if __name__ == '__main__':

    print(AVAILABLE_SENSORS)