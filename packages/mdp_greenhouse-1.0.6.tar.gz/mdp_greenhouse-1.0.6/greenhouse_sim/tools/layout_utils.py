from __future__ import annotations
__author__ = "Robust Robot Systems, TU Delft"
__copyright__ = "Copyright 2026, R2S"
__license__ = "Apache-2.0"
__version__ = "1.0.3"


import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Tuple

from greenhouse_sim.tools.config_loader import Config

CONFIG_DIR = Path(__file__).resolve().parent.parent / "configs"
DEFAULT_CONFIG_FILE = CONFIG_DIR / "greenhouse_config.yaml"
DEFAULT_TAG_FILE = CONFIG_DIR / "tag_locations.json"


def resolve_config_paths(config_folder=None) -> Tuple[Path, Path]:
    if config_folder is None:
        return DEFAULT_CONFIG_FILE, DEFAULT_TAG_FILE

    folder = Path(config_folder).expanduser().resolve()
    if not folder.exists() or not folder.is_dir():
        raise FileNotFoundError(f"Config folder not found: {folder}")

    config_path = folder / "greenhouse_config.yaml"
    tag_path = folder / "tag_locations.json"
    missing = [str(path.name) for path in (config_path, tag_path) if not path.exists()]
    if missing:
        raise FileNotFoundError(
            f"Missing required config files in '{folder}': {', '.join(missing)}"
        )

    return config_path, tag_path


@dataclass(frozen=True)
class VisualizationSettings:
    greenhouse_width_m: float = 15.0
    greenhouse_height_m: float = 10.0
    grid_spacing_m: float = 1.0
    snap_step_m: float = 0.1
    mesh_cell_m: float = 0.25
    table_default_w_m: float = 1.1
    table_default_h_m: float = 0.25
    canvas_padding_px: int = 24
    colorbar_ranges: Dict[str, Tuple[float, float]] = field(default_factory=dict)


@dataclass(frozen=True)
class ViewTransform:
    greenhouse_width_m: float
    greenhouse_height_m: float
    canvas_w: float
    canvas_h: float
    padding_px: float
    scale_px_per_m: float
    offset_x: float
    offset_y: float

    @classmethod
    def from_canvas(
            cls,
            canvas_w: float,
            canvas_h: float,
            settings: VisualizationSettings,
    ) -> "ViewTransform":
        canvas_w = max(float(canvas_w), 1.0)
        canvas_h = max(float(canvas_h), 1.0)
        gh_w = max(float(settings.greenhouse_width_m), 0.1)
        gh_h = max(float(settings.greenhouse_height_m), 0.1)
        padding = float(settings.canvas_padding_px)
        usable_w = max(canvas_w - 2 * padding, 1.0)
        usable_h = max(canvas_h - 2 * padding, 1.0)
        scale = min(usable_w / gh_w, usable_h / gh_h)
        draw_w = gh_w * scale
        draw_h = gh_h * scale
        offset_x = (canvas_w - draw_w) / 2.0
        offset_y = (canvas_h - draw_h) / 2.0
        return cls(gh_w, gh_h, canvas_w, canvas_h, padding, scale, offset_x, offset_y)

    def world_to_canvas(self, x_m: float, y_m: float) -> Tuple[float, float]:
        return self.offset_x + x_m * self.scale_px_per_m, self.offset_y + y_m * self.scale_px_per_m

    def canvas_to_world(self, x_px: float, y_px: float, clamp: bool = False) -> Tuple[float, float]:
        x_m = (x_px - self.offset_x) / self.scale_px_per_m
        y_m = (y_px - self.offset_y) / self.scale_px_per_m
        if clamp:
            x_m = min(max(x_m, 0.0), self.greenhouse_width_m)
            y_m = min(max(y_m, 0.0), self.greenhouse_height_m)
        return x_m, y_m

    def length_to_px(self, length_m: float) -> float:
        return length_m * self.scale_px_per_m

    def contains_canvas_point(self, x_px: float, y_px: float) -> bool:
        x_m, y_m = self.canvas_to_world(x_px, y_px)
        return 0.0 <= x_m <= self.greenhouse_width_m and 0.0 <= y_m <= self.greenhouse_height_m

    def greenhouse_bbox(self) -> Tuple[float, float, float, float]:
        x0, y0 = self.world_to_canvas(0.0, 0.0)
        x1, y1 = self.world_to_canvas(self.greenhouse_width_m, self.greenhouse_height_m)
        return x0, y0, x1, y1


def load_visualization_settings(config_path=None) -> VisualizationSettings:
    data = Config(config_path).data
    vis = data.get("visualization", {})
    return VisualizationSettings(
        greenhouse_width_m=float(vis.get("greenhouse_width_m", 15.0)),
        greenhouse_height_m=float(vis.get("greenhouse_height_m", 10.0)),
        grid_spacing_m=float(vis.get("grid_spacing_m", 1.0)),
        snap_step_m=float(vis.get("snap_step_m", 0.1)),
        mesh_cell_m=float(vis.get("mesh_cell_m", 0.25)),
        table_default_w_m=float(vis.get("table_default_w_m", 1.1)),
        table_default_h_m=float(vis.get("table_default_h_m", 0.25)),
        canvas_padding_px=int(vis.get("canvas_padding_px", 24)),
        colorbar_ranges=_parse_colorbar_ranges(vis.get("colorbar_ranges", {})),
    )


def _parse_colorbar_ranges(raw_ranges) -> Dict[str, Tuple[float, float]]:
    parsed: Dict[str, Tuple[float, float]] = {}
    if not isinstance(raw_ranges, dict):
        return parsed

    for sensor_name, range_values in raw_ranges.items():
        if not isinstance(range_values, dict):
            continue
        if "min" not in range_values or "max" not in range_values:
            continue
        try:
            min_value = float(range_values["min"])
            max_value = float(range_values["max"])
        except (TypeError, ValueError):
            continue
        if max_value <= min_value:
            continue
        parsed[str(sensor_name)] = (min_value, max_value)

    return parsed


def load_layout(tag_path=None):
    path = Path(tag_path) if tag_path is not None else DEFAULT_TAG_FILE
    if not path.exists():
        return {}, {}

    with open(path) as f:
        data = json.load(f)

    if "tags" in data and isinstance(data["tags"], dict):
        return data["tags"], data.get("tables", {})

    first = next(iter(data.values()), {})
    if isinstance(first, dict) and "x" in first and "y" in first:
        return data, {}

    return {}, {}


def save_layout(tags: dict, tables: dict, tag_path=None):
    path = Path(tag_path) if tag_path is not None else DEFAULT_TAG_FILE
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "units": "m",
        "tags": _round_tag_values(tags),
        "tables": _round_table_values(tables),
    }
    with open(path, "w") as f:
        json.dump(payload, f, indent=4)


def _round_tag_values(tags: dict) -> dict:
    rounded = {}
    for tag_id, data in tags.items():
        rounded[tag_id] = {
            "x": round(float(data["x"]), 2),
            "y": round(float(data["y"]), 2),
            "sensors": list(data.get("sensors", [])),
        }
    return rounded


def _round_table_values(tables: dict) -> dict:
    rounded = {}
    for name, data in tables.items():
        rounded[name] = {
            "x0": round(float(data["x0"]), 2),
            "y0": round(float(data["y0"]), 2),
            "x1": round(float(data["x1"]), 2),
            "y1": round(float(data["y1"]), 2),
        }
    return rounded
