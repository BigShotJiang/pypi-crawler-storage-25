__author__ = "Robust Robot Systems, TU Delft"
__copyright__ = "Copyright 2026, R2S"
__license__ = "Apache-2.0"
__version__ = "1.0.3"

import argparse
import shutil
import sys
from pathlib import Path

CONFIG_DIR = Path(__file__).resolve().parent.parent / "configs"
DEFAULT_CONFIG = CONFIG_DIR / "greenhouse_config.yaml"
DEFAULT_TAGS = CONFIG_DIR / "tag_locations_empty.json"


def _default_sources() -> dict:
    return {
        "greenhouse_config.yaml": DEFAULT_CONFIG,
        "tag_locations.json": DEFAULT_TAGS,
    }


def _copy_defaults(target_dir: Path, overwrite: bool) -> int:
    sources = _default_sources()

    missing_sources = [name for name, path in sources.items() if not path.exists()]
    if missing_sources:
        print(
            "Missing default template files: " + ", ".join(missing_sources),
            file=sys.stderr,
        )
        return 2

    target_dir.mkdir(parents=True, exist_ok=True)

    existing = [name for name in sources if (target_dir / name).exists()]
    if existing and not overwrite:
        print(
            "Refusing to overwrite existing files (use --overwrite): "
            + ", ".join(existing),
            file=sys.stderr,
        )
        return 1

    for name, source in sources.items():
        destination = target_dir / name
        shutil.copy2(source, destination)
        print(f"Wrote {destination}")

    return 0


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(
        description=(
            "Create default greenhouse configuration files in a target folder."
        )
    )
    parser.add_argument(
        "target_folder",
        help="Folder where greenhouse_config.yaml and tag_locations.json will be created",
    )
    parser.add_argument(
        "--overwrite",
        action="store_true",
        help="Overwrite existing config files in the target folder",
    )
    args = parser.parse_args(argv)

    target = Path(args.target_folder).expanduser().resolve()
    return _copy_defaults(target, overwrite=args.overwrite)


if __name__ == "__main__":
    raise SystemExit(main())

