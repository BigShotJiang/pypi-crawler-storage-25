__author__ = "Robust Robot Systems, TU Delft"
__copyright__ = "Copyright 2026, R2S"
__license__ = "Apache-2.0"
__version__ = "1.0.3"

import yaml
from pathlib import Path

CONFIG_DIR = Path(__file__).resolve().parent.parent / "configs"


class Config:
    """
    Loads configuration file for the greenhouse simulation
    """
    def __init__(self, config_path=None):
        if config_path is None:
            config_path = CONFIG_DIR / "greenhouse_config.yaml"
        with open(config_path, "r") as f:
            data = yaml.safe_load(f)

        self.data = data
        self.version = data.get("version", 1.0)

        # Time simulation settings
        t = data.get("time", {})
        self.speedup_factor = t.get("speedup_factor", 1)

        self.debug_mode = t.get("debug_mode", False)
        self.debug_time_of_day = t.get("debug_time_of_day", False)

        # Environment parameters
        self.env = data.get("environment", {})

        # Plant parameters
        self.plant = data.get("plant", {})
