__author__ = "Robust Robot Systems, TU Delft"
__copyright__ = "Copyright 2026, R2S"
__license__ = "Apache-2.0"
__version__ = "1.0.3"

import argparse
import tkinter as tk
from tkinter import filedialog, simpledialog, messagebox, ttk

from greenhouse_sim.tools.layout_utils import (
    DEFAULT_CONFIG_FILE,
    DEFAULT_TAG_FILE,
    ViewTransform,
    load_layout,
    load_visualization_settings,
    resolve_config_paths,
    save_layout,
)

TAG_FILE = DEFAULT_TAG_FILE

# ── Appearance constants ──────────────────────────────────────────────────────
CANVAS_W, CANVAS_H = 900, 650
PANEL_W = 230

BG = "#f1f8f1"
CANVAS_BG = "#eaf4ea"
TOOLBAR_BG = "#2e7d32"
ACCENT = "#43a047"
TAG_COL = "#e53935"
TAG_SEL = "#ff8f00"
TABLE_COL = "#6d4c41"
TABLE_FILL = "#d7ccc8"
TEXT_COL = "#212121"
SCALE_COL = "#37474f"
GRID_COL = "#c8e6c9"
OUTLINE_COL = "#7cb342"


class SensorSelectionDialog(simpledialog.Dialog):
    def __init__(self, parent, sensors, current_sensors=None):
        self.sensors = sensors
        self.current_sensors = current_sensors or []
        self.selected = list(self.current_sensors)
        super().__init__(parent, title="Select Sensors")

    def body(self, master):
        master.configure(bg=BG)
        tk.Label(
            master,
            text="Select sensors for this tag:",
            bg=BG,
            font=("Helvetica", 10, "bold"),
        ).pack(pady=(8, 4))
        self.vars = {}
        for sensor in self.sensors:
            var = tk.BooleanVar(value=sensor in self.current_sensors)
            cb = tk.Checkbutton(
                master,
                text=sensor.replace("_", " ").title(),
                variable=var,
                bg=BG,
                activebackground=BG,
                font=("Helvetica", 10),
            )
            cb.pack(anchor="w", padx=16, pady=2)
            self.vars[sensor] = var
        return master

    def apply(self):
        self.selected = [sensor for sensor, value in self.vars.items() if value.get()]


class TagPlacer:
    def __init__(self, root: tk.Tk, config_path=None, tag_path=None):
        self.root = root
        self.root.title("🌿  Greenhouse Layout Tool")
        self.root.configure(bg=BG)
        self.root.resizable(True, True)

        self.config_path = config_path or DEFAULT_CONFIG_FILE
        self.tag_path = tag_path or DEFAULT_TAG_FILE

        self.visualization = load_visualization_settings(self.config_path)
        self.grid_spacing_m = self.visualization.grid_spacing_m
        self.snap_step_m = self.visualization.snap_step_m
        self.gh_w_m = self.visualization.greenhouse_width_m
        self.gh_h_m = self.visualization.greenhouse_height_m

        self.mode: str = "tag"
        self.table_orientation = tk.StringVar(value="horizontal")
        self.selected_tag = None
        self.selected_table = None
        self._drag_state = None
        self._pending_action = None
        self._preview_id = None
        self._preview_label_id = None
        self._default_hint_id = None
        self._default_hint_label_id = None
        self._tooltip_rect = None
        self._tooltip_text = None
        self._canvas_item_map = {}

        self._build_ui()

        self.tags, self.tables = load_layout(self.tag_path)
        self._redraw_all()

    # ── UI construction ───────────────────────────────────────────────────────

    def _build_ui(self):
        toolbar = tk.Frame(self.root, bg=TOOLBAR_BG, pady=5)
        toolbar.pack(fill=tk.X)

        def tlbl(text):
            return tk.Label(toolbar, text=text, bg=TOOLBAR_BG,
                            fg="white", font=("Helvetica", 10))

        tlbl("Mode:").pack(side=tk.LEFT, padx=(12, 4))

        self._mode_var = tk.StringVar(value="tag")
        for value, label in (("tag", "📍 Place Tag"), ("table", "🟫 Draw Table")):
            tk.Radiobutton(
                toolbar,
                text=label,
                variable=self._mode_var,
                value=value,
                command=self._on_mode_change,
                bg=TOOLBAR_BG,
                fg="white",
                selectcolor=TOOLBAR_BG,
                activebackground=TOOLBAR_BG,
                activeforeground="white",
                font=("Helvetica", 10),
                cursor="hand2",
            ).pack(side=tk.LEFT, padx=4)

        tk.Frame(toolbar, bg="#81c784", width=1, height=24).pack(
            side=tk.LEFT, padx=10, fill=tk.Y
        )

        tlbl("Layout:").pack(side=tk.LEFT, padx=(0, 4))
        tk.Label(
            toolbar,
            text=(
                f"Auto-fit  •  Grid {self.grid_spacing_m:g} m  •  "
                f"Snap {self.snap_step_m:g} m  •  "
                f"Size {self.gh_w_m:g} × {self.gh_h_m:g} m"
            ),
            bg=TOOLBAR_BG,
            fg="#c8e6c9",
            font=("Helvetica", 10, "bold"),
        ).pack(side=tk.LEFT, padx=(0, 6))

        tk.Frame(toolbar, bg="#81c784", width=1, height=24).pack(
            side=tk.LEFT, padx=10, fill=tk.Y
        )

        tlbl("Default Table:").pack(side=tk.LEFT, padx=(0, 4))
        for value, label in (("horizontal", "↔ Horizontal"), ("vertical", "↕ Vertical")):
            tk.Radiobutton(
                toolbar,
                text=label,
                variable=self.table_orientation,
                value=value,
                bg=TOOLBAR_BG,
                fg="white",
                selectcolor=TOOLBAR_BG,
                activebackground=TOOLBAR_BG,
                activeforeground="white",
                font=("Helvetica", 10),
                cursor="hand2",
            ).pack(side=tk.LEFT, padx=2)

        self._coord_lbl = tk.Label(
            toolbar, text="", bg=TOOLBAR_BG, fg="#a5d6a7", font=("Helvetica", 9)
        )
        self._coord_lbl.pack(side=tk.RIGHT, padx=12)

        body = tk.Frame(self.root, bg=BG)
        body.pack(fill=tk.BOTH, expand=True)

        canvas_frame = tk.Frame(body, bg=BG)
        canvas_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(8, 4), pady=8)

        self.canvas = tk.Canvas(
            canvas_frame,
            width=CANVAS_W,
            height=CANVAS_H,
            bg=CANVAS_BG,
            cursor="crosshair",
            highlightthickness=2,
            highlightbackground="#a5d6a7",
        )
        self.canvas.pack(fill=tk.BOTH, expand=True)
        self.canvas.bind("<Button-1>", self._on_click)
        self.canvas.bind("<B1-Motion>", self._on_drag)
        self.canvas.bind("<ButtonRelease-1>", self._on_release)
        self.canvas.bind("<Motion>", self._on_mouse_move)
        self.canvas.bind("<Configure>", lambda _e: self._redraw_all())

        self._build_right_panel(body)

    def _build_right_panel(self, parent):
        panel = tk.Frame(parent, bg="#fafafa", width=PANEL_W, relief=tk.GROOVE, bd=1)
        panel.pack(side=tk.RIGHT, fill=tk.Y, padx=(0, 8), pady=8)
        panel.pack_propagate(False)

        def section_label(text, bg_col, fg_col):
            tk.Label(
                panel,
                text=text,
                bg=bg_col,
                fg=fg_col,
                font=("Helvetica", 11, "bold"),
                anchor="w",
                padx=8,
            ).pack(fill=tk.X, pady=(10, 2))

        def action_btn(text, cmd, bg=ACCENT):
            tk.Button(
                panel,
                text=text,
                command=cmd,
                bg=bg,
                fg="white",
                font=("Helvetica", 9),
                relief=tk.FLAT,
                padx=6,
                pady=4,
                cursor="hand2",
            ).pack(fill=tk.X, padx=8, pady=2)

        section_label("📍  Tags", "#e8f5e9", TOOLBAR_BG)
        lf = tk.Frame(panel, bg="#fafafa")
        lf.pack(fill=tk.BOTH, expand=True, padx=8, pady=(0, 4))

        self._tag_lb = tk.Listbox(
            lf,
            font=("Helvetica", 9),
            selectbackground=ACCENT,
            selectforeground="white",
            bg="white",
            relief=tk.FLAT,
            bd=1,
            activestyle="none",
            height=8,
        )
        vsb = tk.Scrollbar(lf, orient=tk.VERTICAL, command=self._tag_lb.yview)
        self._tag_lb.config(yscrollcommand=vsb.set)
        vsb.pack(side=tk.RIGHT, fill=tk.Y)
        self._tag_lb.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        self._tag_lb.bind("<<ListboxSelect>>", self._on_tag_select)

        action_btn("✏️  Edit Sensors", self._edit_sensors, "#43a047")
        action_btn("🗑  Delete Tag", self._delete_tag, "#e53935")

        ttk.Separator(panel, orient=tk.HORIZONTAL).pack(fill=tk.X, padx=8, pady=8)

        section_label("🟫  Plant Tables", "#efebe9", TABLE_COL)
        tf = tk.Frame(panel, bg="#fafafa")
        tf.pack(fill=tk.BOTH, expand=True, padx=8, pady=(0, 4))

        self._tbl_lb = tk.Listbox(
            tf,
            font=("Helvetica", 9),
            selectbackground=TABLE_COL,
            selectforeground="white",
            bg="white",
            relief=tk.FLAT,
            bd=1,
            activestyle="none",
            height=7,
        )
        vsb2 = tk.Scrollbar(tf, orient=tk.VERTICAL, command=self._tbl_lb.yview)
        self._tbl_lb.config(yscrollcommand=vsb2.set)
        vsb2.pack(side=tk.RIGHT, fill=tk.Y)
        self._tbl_lb.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        self._tbl_lb.bind("<<ListboxSelect>>", self._on_table_select)

        action_btn("✏️  Rename Table", self._rename_table, "#795548")
        action_btn("🗑  Delete Table", self._delete_table, "#e53935")

    # ── Coordinate helpers ────────────────────────────────────────────────────

    def _transform(self) -> ViewTransform:
        return ViewTransform.from_canvas(self._cw(), self._ch(), self.visualization)

    def _round_m(self, value: float) -> float:
        return round(float(value), 2)

    def _clamp_point(self, x_m: float, y_m: float):
        return (
            min(max(x_m, 0.0), self.gh_w_m),
            min(max(y_m, 0.0), self.gh_h_m),
        )

    def _snap_value(self, value: float) -> float:
        step = max(float(self.snap_step_m), 0.01)
        return round(round(value / step) * step, 6)

    def _snap_point(self, x_m: float, y_m: float):
        sx = self._snap_value(x_m)
        sy = self._snap_value(y_m)
        return self._clamp_point(sx, sy)

    def _grid_positions(self, limit: float):
        step = max(self.grid_spacing_m, 0.1)
        count = int(limit / step)
        values = [round(i * step, 6) for i in range(count + 1)]
        if abs(values[-1] - limit) > 1e-6:
            values.append(limit)
        return values

    def _fmt_m(self, value: float) -> str:
        return f"{int(value)}" if abs(value - round(value)) < 1e-6 else f"{value:g}"

    def _fit_table_origin(self, x0_m: float, y0_m: float, width_m: float, height_m: float):
        x0_m = min(max(x0_m, 0.0), max(self.gh_w_m - width_m, 0.0))
        y0_m = min(max(y0_m, 0.0), max(self.gh_h_m - height_m, 0.0))
        return x0_m, y0_m

    def _normalized_table(self, x0_m: float, y0_m: float, x1_m: float, y1_m: float):
        x0_m, y0_m = self._snap_point(x0_m, y0_m)
        x1_m, y1_m = self._snap_point(x1_m, y1_m)
        left, right = sorted((x0_m, x1_m))
        top, bottom = sorted((y0_m, y1_m))
        if abs(right - left) < 1e-9:
            left = min(left, max(self.gh_w_m - self.snap_step_m, 0.0))
            right = min(left + self.snap_step_m, self.gh_w_m)
        if abs(bottom - top) < 1e-9:
            top = min(top, max(self.gh_h_m - self.snap_step_m, 0.0))
            bottom = min(top + self.snap_step_m, self.gh_h_m)
        return {
            "x0": self._round_m(left),
            "y0": self._round_m(top),
            "x1": self._round_m(right),
            "y1": self._round_m(bottom),
        }

    def _default_table_at(self, x_m: float, y_m: float):
        x0_m, y0_m = self._snap_point(x_m, y_m)
        width = self.visualization.table_default_w_m
        height = self.visualization.table_default_h_m
        if self.table_orientation.get() == "vertical":
            width, height = height, width
        x0_m, y0_m = self._fit_table_origin(x0_m, y0_m, width, height)
        return {
            "x0": self._round_m(x0_m),
            "y0": self._round_m(y0_m),
            "x1": self._round_m(x0_m + width),
            "y1": self._round_m(y0_m + height),
        }

    def _hit_test(self, x_px: float, y_px: float):
        current = self.canvas.find_withtag("current")
        for item_id in current:
            hit = self._canvas_item_map.get(item_id)
            if hit:
                return hit
        nearby = self.canvas.find_overlapping(x_px - 2, y_px - 2, x_px + 2, y_px + 2)
        for item_id in reversed(nearby):
            hit = self._canvas_item_map.get(item_id)
            if hit:
                return hit
        return None

    # ── Mode ──────────────────────────────────────────────────────────────────

    def _on_mode_change(self):
        self.mode = self._mode_var.get()
        self.canvas.config(cursor="crosshair" if self.mode == "tag" else "sizing")
        if self.mode != "table":
            self._hide_default_table_hint()

    def _update_default_table_hint(self, x_px: float, y_px: float):
        transform = self._transform()
        if not transform.contains_canvas_point(x_px, y_px):
            self._hide_default_table_hint()
            return

        x_m, y_m = transform.canvas_to_world(x_px, y_px, clamp=True)
        table = self._default_table_at(x_m, y_m)
        x0, y0 = transform.world_to_canvas(table["x0"], table["y0"])
        x1, y1 = transform.world_to_canvas(table["x1"], table["y1"])
        width = table["x1"] - table["x0"]
        height = table["y1"] - table["y0"]
        hint_text = f"{width:.2f} x {height:.2f} m"

        if self._default_hint_id:
            self.canvas.coords(self._default_hint_id, x0, y0, x1, y1)
            if self._default_hint_label_id:
                self.canvas.coords(self._default_hint_label_id, x0, y0 - 10)
                self.canvas.itemconfigure(self._default_hint_label_id, text=hint_text)
            return

        self._default_hint_id = self.canvas.create_rectangle(
            x0,
            y0,
            x1,
            y1,
            fill=TABLE_FILL,
            outline=TABLE_COL,
            width=1,
            dash=(3, 3),
            stipple="gray50",
            tags=("default_hint",),
        )
        self._default_hint_label_id = self.canvas.create_text(
            x0,
            y0 - 10,
            text=hint_text,
            anchor="sw",
            fill="#8d6e63",
            font=("Helvetica", 8, "bold"),
            tags=("default_hint",),
        )

    def _hide_default_table_hint(self):
        if self._default_hint_id:
            self.canvas.delete(self._default_hint_id)
            self._default_hint_id = None
        if self._default_hint_label_id:
            self.canvas.delete(self._default_hint_label_id)
            self._default_hint_label_id = None

    # ── Canvas events ─────────────────────────────────────────────────────────

    def _on_mouse_move(self, event):
        transform = self._transform()
        if transform.contains_canvas_point(event.x, event.y):
            x_m, y_m = transform.canvas_to_world(event.x, event.y, clamp=True)
            self._coord_lbl.config(text=f"({x_m:.2f} m, {y_m:.2f} m)")
        else:
            self._coord_lbl.config(text="Outside greenhouse")

        if self._drag_state:
            self._hide_default_table_hint()
            self._hide_tooltip()
            return

        if self.mode == "table" and not self._pending_action:
            self._update_default_table_hint(event.x, event.y)
        else:
            self._hide_default_table_hint()

        hit = self._hit_test(event.x, event.y)
        if not hit:
            self._hide_tooltip()
            return

        kind, item_id = hit
        if kind == "tag" and item_id in self.tags:
            self._show_tag_tooltip(item_id, event.x, event.y)
        elif kind == "table" and item_id in self.tables:
            self._show_table_tooltip(item_id, event.x, event.y)
        else:
            self._hide_tooltip()

    def _on_click(self, event):
        transform = self._transform()
        if not transform.contains_canvas_point(event.x, event.y):
            return

        self._hide_default_table_hint()
        self._hide_tooltip()
        x_m, y_m = transform.canvas_to_world(event.x, event.y, clamp=True)
        hit = self._hit_test(event.x, event.y)
        if hit:
            kind, item_id = hit
            if kind == "tag" and item_id in self.tags:
                self.selected_tag = item_id
                self.selected_table = None
                tag = self.tags[item_id]
                self._drag_state = {
                    "kind": "tag",
                    "id": item_id,
                    "moved": False,
                    "offset": (x_m - tag["x"], y_m - tag["y"]),
                }
                self._redraw_all()
                return
            # In tag mode, allow placing tags over tables instead of activating them.
            if self.mode == "table" and kind == "table" and item_id in self.tables:
                self.selected_table = item_id
                self.selected_tag = None
                self._drag_state = {
                    "kind": "table",
                    "id": item_id,
                    "moved": False,
                    "pointer_start": (x_m, y_m),
                    "original": dict(self.tables[item_id]),
                }
                self._redraw_all()
                return

        if self.mode == "tag":
            self._pending_action = {"kind": "place_tag", "point": self._snap_point(x_m, y_m)}
        else:
            self._pending_action = {
                "kind": "new_table",
                "start_px": (event.x, event.y),
                "start_m": self._snap_point(x_m, y_m),
            }

    def _on_drag(self, event):
        transform = self._transform()
        self._hide_default_table_hint()
        if self._drag_state:
            x_m, y_m = transform.canvas_to_world(event.x, event.y, clamp=True)
            self._drag_state["moved"] = True
            if self._drag_state["kind"] == "tag":
                dx, dy = self._drag_state["offset"]
                new_x, new_y = self._snap_point(x_m - dx, y_m - dy)
                self.tags[self._drag_state["id"]]["x"] = self._round_m(new_x)
                self.tags[self._drag_state["id"]]["y"] = self._round_m(new_y)
            else:
                name = self._drag_state["id"]
                original = self._drag_state["original"]
                start_x, start_y = self._drag_state["pointer_start"]
                width = original["x1"] - original["x0"]
                height = original["y1"] - original["y0"]
                desired_x0 = self._snap_value(original["x0"] + (x_m - start_x))
                desired_y0 = self._snap_value(original["y0"] + (y_m - start_y))
                desired_x0, desired_y0 = self._fit_table_origin(desired_x0, desired_y0, width, height)
                self.tables[name] = {
                    "x0": self._round_m(desired_x0),
                    "y0": self._round_m(desired_y0),
                    "x1": self._round_m(desired_x0 + width),
                    "y1": self._round_m(desired_y0 + height),
                }
            self._redraw_all()
            return

        if not self._pending_action or self._pending_action.get("kind") != "new_table":
            return

        start_x_m, start_y_m = self._pending_action["start_m"]
        end_x_m, end_y_m = transform.canvas_to_world(event.x, event.y, clamp=True)
        preview = self._normalized_table(start_x_m, start_y_m, end_x_m, end_y_m)
        x0, y0 = transform.world_to_canvas(preview["x0"], preview["y0"])
        x1, y1 = transform.world_to_canvas(preview["x1"], preview["y1"])
        if self._preview_id:
            self.canvas.delete(self._preview_id)
        self._preview_id = self.canvas.create_rectangle(
            x0,
            y0,
            x1,
            y1,
            outline=TABLE_COL,
            fill=TABLE_FILL,
            dash=(5, 3),
            width=2,
            stipple="gray25",
        )

        width_m = preview["x1"] - preview["x0"]
        height_m = preview["y1"] - preview["y0"]
        preview_text = f"{width_m:.2f} x {height_m:.2f} m"
        cx = (x0 + x1) / 2
        cy = (y0 + y1) / 2

        if self._preview_label_id:
            self.canvas.coords(self._preview_label_id, cx, cy)
            self.canvas.itemconfigure(self._preview_label_id, text=preview_text)
        else:
            self._preview_label_id = self.canvas.create_text(
                cx,
                cy,
                text=preview_text,
                fill=TABLE_COL,
                font=("Helvetica", 9, "bold"),
                tags=("preview_hint",),
            )

    def _on_release(self, event):
        if self._drag_state:
            moved = self._drag_state.get("moved", False)
            self._drag_state = None
            if moved:
                self._save()
            self._redraw_all()
            return

        if not self._pending_action:
            return

        action = self._pending_action
        self._pending_action = None

        if self._preview_id:
            self.canvas.delete(self._preview_id)
            self._preview_id = None
        if self._preview_label_id:
            self.canvas.delete(self._preview_label_id)
            self._preview_label_id = None

        if action["kind"] == "place_tag":
            self._place_tag(*action["point"])
            return

        start_x_px, start_y_px = action["start_px"]
        start_x_m, start_y_m = action["start_m"]
        if abs(event.x - start_x_px) < 8 and abs(event.y - start_y_px) < 8:
            table = self._default_table_at(start_x_m, start_y_m)
        else:
            transform = self._transform()
            end_x_m, end_y_m = transform.canvas_to_world(event.x, event.y, clamp=True)
            table = self._normalized_table(start_x_m, start_y_m, end_x_m, end_y_m)

        name = simpledialog.askstring(
            "Table Name", "Enter a name for this plant table:", parent=self.root
        )
        if not name:
            self._redraw_all()
            return

        self.tables[name] = table
        self._save()
        self._redraw_all()

    # ── Tag placement ─────────────────────────────────────────────────────────

    def _place_tag(self, x_m: float, y_m: float):
        from greenhouse_sim.sensors import AVAILABLE_SENSORS

        tag_id = simpledialog.askstring("Tag ID", "Enter Tag ID:", parent=self.root)
        if not tag_id:
            return

        dlg = SensorSelectionDialog(self.root, list(AVAILABLE_SENSORS.keys()))
        x_m, y_m = self._snap_point(x_m, y_m)
        self.tags[tag_id] = {
            "x": self._round_m(x_m),
            "y": self._round_m(y_m),
            "sensors": dlg.selected,
        }
        self._save()
        self._redraw_all()
        self._select_tag(tag_id)

    # ── Drawing ───────────────────────────────────────────────────────────────

    def _cw(self) -> int:
        w = self.canvas.winfo_width()
        return w if w > 1 else CANVAS_W

    def _ch(self) -> int:
        h = self.canvas.winfo_height()
        return h if h > 1 else CANVAS_H

    def _draw_greenhouse_outline(self):
        transform = self._transform()
        x0, y0, x1, y1 = transform.greenhouse_bbox()
        self.canvas.create_rectangle(
            x0,
            y0,
            x1,
            y1,
            fill="#f7fbf4",
            outline=OUTLINE_COL,
            width=2,
            tags="greenhouse",
        )

    def _draw_grid(self):
        transform = self._transform()
        x0, y0, _, _ = transform.greenhouse_bbox()
        x_max, _ = transform.world_to_canvas(self.gh_w_m, 0.0)
        _, y_max = transform.world_to_canvas(0.0, self.gh_h_m)

        for x_m in self._grid_positions(self.gh_w_m):
            px, _ = transform.world_to_canvas(x_m, 0.0)
            self.canvas.create_line(px, y0, px, y_max, fill=GRID_COL, dash=(2, 6), tags="grid")
            if x_m > 0:
                self.canvas.create_text(
                    px + 3,
                    y0 + 10,
                    text=f"{self._fmt_m(x_m)}m",
                    fill="#81c784",
                    font=("Helvetica", 7),
                    anchor="nw",
                    tags="grid",
                )

        for y_m in self._grid_positions(self.gh_h_m):
            _, py = transform.world_to_canvas(0.0, y_m)
            self.canvas.create_line(x0, py, x_max, py, fill=GRID_COL, dash=(2, 6), tags="grid")
            if y_m > 0:
                self.canvas.create_text(
                    x0 + 3,
                    py + 3,
                    text=f"{self._fmt_m(y_m)}m",
                    fill="#81c784",
                    font=("Helvetica", 7),
                    anchor="nw",
                    tags="grid",
                )

    def _draw_scale_bar(self):
        transform = self._transform()
        x0, _, _, y1 = transform.greenhouse_bbox()
        bar_px = transform.length_to_px(1.0)
        bx = x0 + 18
        by = y1 - 18
        self.canvas.create_rectangle(
            bx - 4,
            by - 18,
            bx + bar_px + 4,
            by + 8,
            fill="white",
            outline="#c8e6c9",
            tags="scale",
        )
        self.canvas.create_line(bx, by, bx + bar_px, by, fill=SCALE_COL, width=3, tags="scale")
        for sx in (bx, bx + bar_px):
            self.canvas.create_line(sx, by - 5, sx, by + 5, fill=SCALE_COL, width=2, tags="scale")
        self.canvas.create_text(
            bx + bar_px / 2,
            by - 9,
            text="1 m",
            fill=SCALE_COL,
            font=("Helvetica", 9, "bold"),
            tags="scale",
        )

    def _draw_table(self, name: str, table: dict, selected=False):
        transform = self._transform()
        x0, y0 = transform.world_to_canvas(table["x0"], table["y0"])
        x1, y1 = transform.world_to_canvas(table["x1"], table["y1"])
        outline = TAG_SEL if selected else TABLE_COL
        width = 2.5 if selected else 1.5
        rect_id = self.canvas.create_rectangle(
            x0,
            y0,
            x1,
            y1,
            fill="",
            outline=outline,
            width=width,
        )
        cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
        wm = table["x1"] - table["x0"]
        hm = table["y1"] - table["y0"]
        text_id = self.canvas.create_text(
            cx,
            cy,
            text=f"🌱 {name}\n{wm:.2f} × {hm:.2f} m",
            fill=TABLE_COL,
            font=("Helvetica", 9, "bold"),
            justify=tk.CENTER,
        )
        self._canvas_item_map[rect_id] = ("table", name)
        self._canvas_item_map[text_id] = ("table", name)

    def _draw_tag(self, tag_id: str, tag: dict, selected=False):
        transform = self._transform()
        x, y = transform.world_to_canvas(tag["x"], tag["y"])
        color = TAG_SEL if selected else TAG_COL
        radius = max(5, int(round(transform.length_to_px(0.08))))
        item_id = self.canvas.create_oval(
            x - radius,
            y - radius,
            x + radius,
            y + radius,
            fill=color,
            outline="white",
            width=1.5,
        )
        self._canvas_item_map[item_id] = ("tag", tag_id)

    def _show_tooltip(self, text: str, x: int, y: int):
        self._hide_tooltip()
        self._tooltip_text = self.canvas.create_text(
            x + 12,
            y - 12,
            text=text,
            anchor="nw",
            fill=TEXT_COL,
            font=("Helvetica", 8, "bold"),
            tags=("tooltip",),
        )
        x0, y0, x1, y1 = self.canvas.bbox(self._tooltip_text)
        self._tooltip_rect = self.canvas.create_rectangle(
            x0 - 5,
            y0 - 4,
            x1 + 5,
            y1 + 4,
            fill="#fffde7",
            outline="#c5e1a5",
            width=1,
            tags=("tooltip",),
        )
        self.canvas.tag_raise(self._tooltip_text, self._tooltip_rect)

    def _show_tag_tooltip(self, tag_id: str, x: int, y: int):
        tag = self.tags[tag_id]
        sensors = tag.get("sensors", [])
        text = (
            f"{tag_id}\n"
            f"[{', '.join(sensors) or '-'}]\n"
            f"({tag['x']:.2f}, {tag['y']:.2f}) m"
        )
        self._show_tooltip(text, x, y)

    def _show_table_tooltip(self, name: str, x: int, y: int):
        table = self.tables[name]
        width = table["x1"] - table["x0"]
        height = table["y1"] - table["y0"]
        text = (
            f"{name}\n"
            f"Origin: ({table['x0']:.2f}, {table['y0']:.2f}) m\n"
            f"Size: {width:.2f} × {height:.2f} m"
        )
        self._show_tooltip(text, x, y)

    def _hide_tooltip(self):
        if self._tooltip_rect:
            self.canvas.delete(self._tooltip_rect)
            self._tooltip_rect = None
        if self._tooltip_text:
            self.canvas.delete(self._tooltip_text)
            self._tooltip_text = None

    def _redraw_all(self):
        self.canvas.delete("all")
        self._preview_id = None
        self._preview_label_id = None
        self._default_hint_id = None
        self._default_hint_label_id = None
        self._tooltip_rect = None
        self._tooltip_text = None
        self._canvas_item_map = {}
        self._draw_greenhouse_outline()
        self._draw_grid()
        for name, table in self.tables.items():
            self._draw_table(name, table, selected=(name == self.selected_table))
        for tag_id, tag in self.tags.items():
            self._draw_tag(tag_id, tag, selected=(tag_id == self.selected_tag))
        self._draw_scale_bar()
        self._refresh_tag_list()
        self._refresh_table_list()

    # ── Sidebar ───────────────────────────────────────────────────────────────

    def _refresh_tag_list(self):
        self._tag_lb.delete(0, tk.END)
        for tag_id, data in self.tags.items():
            sensors = data.get("sensors", [])
            self._tag_lb.insert(
                tk.END,
                f"{tag_id}  ({data['x']:.2f},{data['y']:.2f}m)  [{', '.join(sensors) or '—'}]",
            )

    def _refresh_table_list(self):
        self._tbl_lb.delete(0, tk.END)
        for name, table in self.tables.items():
            width = table["x1"] - table["x0"]
            height = table["y1"] - table["y0"]
            self._tbl_lb.insert(tk.END, f"{name}  {width:.2f} × {height:.2f} m")

    def _select_tag(self, tag_id: str):
        self.selected_tag = tag_id
        self.selected_table = None
        self._redraw_all()
        keys = list(self.tags.keys())
        if tag_id in keys:
            idx = keys.index(tag_id)
            self._tag_lb.selection_clear(0, tk.END)
            self._tag_lb.selection_set(idx)
            self._tag_lb.see(idx)

    def _on_tag_select(self, _event):
        sel = self._tag_lb.curselection()
        if not sel:
            return
        keys = list(self.tags.keys())
        if sel[0] < len(keys):
            self.selected_tag = keys[sel[0]]
            self.selected_table = None
            self._redraw_all()

    def _on_table_select(self, _event):
        sel = self._tbl_lb.curselection()
        if not sel:
            return
        keys = list(self.tables.keys())
        if sel[0] < len(keys):
            self.selected_table = keys[sel[0]]
            self.selected_tag = None
            self._redraw_all()

    # ── Actions ───────────────────────────────────────────────────────────────

    def _edit_sensors(self):
        from greenhouse_sim.sensors import AVAILABLE_SENSORS

        if not self.selected_tag:
            messagebox.showinfo("No Tag Selected", "Select a tag from the list first.")
            return
        current = self.tags[self.selected_tag].get("sensors", [])
        dlg = SensorSelectionDialog(
            self.root,
            list(AVAILABLE_SENSORS.keys()),
            current_sensors=current,
        )
        self.tags[self.selected_tag]["sensors"] = dlg.selected
        self._save()
        self._redraw_all()

    def _delete_tag(self):
        if not self.selected_tag:
            messagebox.showinfo("No Tag Selected", "Select a tag from the list first.")
            return
        if messagebox.askyesno("Delete Tag", f"Delete tag '{self.selected_tag}'?"):
            del self.tags[self.selected_tag]
            self.selected_tag = None
            self._save()
            self._redraw_all()

    def _rename_table(self):
        if not self.selected_table:
            messagebox.showinfo("No Table Selected", "Select a table from the list first.")
            return
        new_name = simpledialog.askstring(
            "Rename Table",
            "New name:",
            initialvalue=self.selected_table,
            parent=self.root,
        )
        if new_name and new_name != self.selected_table:
            self.tables[new_name] = self.tables.pop(self.selected_table)
            self.selected_table = new_name
            self._save()
            self._redraw_all()

    def _delete_table(self):
        if not self.selected_table:
            messagebox.showinfo("No Table Selected", "Select a table from the list first.")
            return
        if messagebox.askyesno("Delete Table", f"Delete table '{self.selected_table}'?"):
            del self.tables[self.selected_table]
            self.selected_table = None
            self._save()
            self._redraw_all()

    # ── Persistence ───────────────────────────────────────────────────────────

    def _save(self):
        save_layout(self.tags, self.tables, self.tag_path)


def _resolve_startup_paths(config_folder_arg=None):
    if config_folder_arg:
        return resolve_config_paths(config_folder_arg)

    use_default = messagebox.askyesno(
        "Load Configuration",
        (
            "Load configuration from default folder?\n\n"
            f"Default:\n{DEFAULT_CONFIG_FILE.parent}\n\n"
            "Click 'No' to choose a custom folder containing\n"
            "greenhouse_config.yaml and tag_locations.json."
        ),
    )
    if use_default:
        return resolve_config_paths(None)

    while True:
        folder = filedialog.askdirectory(title="Select config folder")
        if not folder:
            return None, None
        try:
            return resolve_config_paths(folder)
        except FileNotFoundError as exc:
            messagebox.showerror("Invalid Folder", str(exc))


def main(argv=None):
    parser = argparse.ArgumentParser(
        description=(
            "Start greenhouse layout editor. Optionally provide a folder that "
            "contains greenhouse_config.yaml and tag_locations.json."
        )
    )
    parser.add_argument(
        "config_folder",
        nargs="?",
        help="Folder containing greenhouse_config.yaml and tag_locations.json",
    )
    args = parser.parse_args(argv)

    root = tk.Tk()
    config_path, tag_path = _resolve_startup_paths(args.config_folder)
    if not config_path or not tag_path:
        root.destroy()
        return 0

    TagPlacer(root, config_path=config_path, tag_path=tag_path)
    root.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
