__author__ = "Robust Robot Systems, TU Delft"
__copyright__ = "Copyright 2026, R2S"
__license__ = "Apache-2.0"
__version__ = "1.0.3"

import argparse
import time
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from greenhouse_sim.simulator import SensorRegistry
from greenhouse_sim.tools.config_loader import Config
from greenhouse_sim.tools.layout_utils import (
    DEFAULT_CONFIG_FILE,
    DEFAULT_TAG_FILE,
    ViewTransform,
    load_layout,
    load_visualization_settings,
    resolve_config_paths,
)

# Visual defaults
CANVAS_W, CANVAS_H = 980, 680
BG = "#f1f8f1"
CANVAS_BG = "#f8fbf8"
TOOLBAR_BG = "#2e7d32"
ACCENT = "#43a047"
GRID_LINE = "#d7ecd8"
TABLE_OUTLINE = "#6d4c41"
TABLE_FILL = "#efebe9"
TAG_COL = "#e53935"
TEXT_COL = "#1b1b1b"
OUTLINE_COL = "#7cb342"
DAY_SECONDS = 24 * 60 * 60


class SimulationViewer:
    def __init__(self, root: tk.Tk, config_path=None, tag_path=None):
        self.root = root
        self.root.title("Greenhouse Simulation Viewer")
        self.root.configure(bg=BG)
        self.root.geometry("1240x760")

        self.config_path = config_path or DEFAULT_CONFIG_FILE
        self.tag_path = tag_path or DEFAULT_TAG_FILE

        self.tags = {}
        self.tables = {}
        self.sensor_registry = None
        self.sim_data = {}
        self.visualization = load_visualization_settings(self.config_path)

        self.selected_sensor = tk.StringVar(value="")
        self.time_var = tk.DoubleVar(value=12 * 3600)  # noon default
        self.time_text_var = tk.StringVar(value="12:00:00")
        self.speed_var = tk.StringVar(value="60")      # sim sec per real sec
        self.mesh_cell_var = tk.StringVar(value=f"{self.visualization.mesh_cell_m:g}")
        self.show_tags_var = tk.BooleanVar(value=True)
        self.show_tables_var = tk.BooleanVar(value=True)

        self.playing = False
        self._last_tick = None
        self._tooltip_ids = []
        self._canvas_item_map = {}

        self._build_ui()
        self._reload_all()

    # ---------- UI ----------

    def _build_ui(self):
        toolbar = tk.Frame(self.root, bg=TOOLBAR_BG, pady=6)
        toolbar.pack(fill=tk.X)

        def tlabel(text):
            return tk.Label(toolbar, text=text, bg=TOOLBAR_BG, fg="white",
                            font=("Helvetica", 10))

        tlabel("Sensor:").pack(side=tk.LEFT, padx=(10, 4))
        self.sensor_combo = ttk.Combobox(toolbar, textvariable=self.selected_sensor,
                                         width=18, state="readonly")
        self.sensor_combo.pack(side=tk.LEFT, padx=4)
        self.sensor_combo.bind("<<ComboboxSelected>>", lambda _e: self._render())

        tlabel("Mesh:").pack(side=tk.LEFT, padx=(12, 4))
        tk.Label(toolbar, textvariable=self.mesh_cell_var,
                 bg=TOOLBAR_BG, fg="#c8e6c9",
                 font=("Helvetica", 10, "bold")).pack(side=tk.LEFT, padx=2)
        tk.Label(toolbar, text="m", bg=TOOLBAR_BG, fg="white",
                 font=("Helvetica", 10)).pack(side=tk.LEFT)

        tlabel("Speed x:").pack(side=tk.LEFT, padx=(12, 4))
        tk.Entry(toolbar, textvariable=self.speed_var, width=6,
                 font=("Helvetica", 10)).pack(side=tk.LEFT, padx=2)

        self.play_btn = tk.Button(toolbar, text="Play", command=self._toggle_play,
                                  bg=ACCENT, fg="white", relief=tk.FLAT,
                                  padx=12, cursor="hand2")
        self.play_btn.pack(side=tk.LEFT, padx=(10, 4))

        tk.Button(toolbar, text="Reload", command=self._reload_all,
                  bg="#558b2f", fg="white", relief=tk.FLAT,
                  padx=10, cursor="hand2").pack(side=tk.LEFT, padx=4)

        tk.Checkbutton(toolbar, text="Tags", variable=self.show_tags_var,
                       command=self._render, bg=TOOLBAR_BG, fg="white",
                       selectcolor=TOOLBAR_BG, activebackground=TOOLBAR_BG,
                       activeforeground="white").pack(side=tk.LEFT, padx=(12, 4))

        tk.Checkbutton(toolbar, text="Tables", variable=self.show_tables_var,
                       command=self._render, bg=TOOLBAR_BG, fg="white",
                       selectcolor=TOOLBAR_BG, activebackground=TOOLBAR_BG,
                       activeforeground="white").pack(side=tk.LEFT, padx=4)

        self.coord_lbl = tk.Label(toolbar, text="", bg=TOOLBAR_BG, fg="#c5e1a5",
                                  font=("Helvetica", 9))
        self.coord_lbl.pack(side=tk.RIGHT, padx=12)

        time_bar = tk.Frame(self.root, bg="#e8f5e9", pady=6)
        time_bar.pack(fill=tk.X)

        tk.Label(time_bar, text="Time of day", bg="#e8f5e9",
                 font=("Helvetica", 10, "bold")).pack(side=tk.LEFT, padx=(10, 6))

        self.time_scale = tk.Scale(
            time_bar,
            from_=0,
            to=DAY_SECONDS,
            orient=tk.HORIZONTAL,
            resolution=60,
            length=800,
            showvalue=False,
            variable=self.time_var,
            command=self._on_time_slider
        )
        self.time_scale.pack(side=tk.LEFT, padx=4)

        tk.Label(time_bar, textvariable=self.time_text_var,
                 bg="#e8f5e9", fg="#1b5e20",
                 font=("Helvetica", 10, "bold")).pack(side=tk.LEFT, padx=10)

        body = tk.Frame(self.root, bg=BG)
        body.pack(fill=tk.BOTH, expand=True, padx=8, pady=(0, 8))

        self.canvas = tk.Canvas(body, bg=CANVAS_BG, width=CANVAS_W, height=CANVAS_H,
                                highlightthickness=2, highlightbackground="#a5d6a7")
        self.canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        self.canvas.bind("<Motion>", self._on_mouse_move)
        self.canvas.bind("<Leave>", lambda _e: self._hide_tooltip())
        self.canvas.bind("<Configure>", lambda _e: self._render())

        side = tk.Frame(body, bg="#fafafa", width=260, relief=tk.GROOVE, bd=1)
        side.pack(side=tk.RIGHT, fill=tk.Y, padx=(8, 0))
        side.pack_propagate(False)

        tk.Label(side, text="Loaded Data", bg="#e8f5e9", fg="#1b5e20",
                 font=("Helvetica", 11, "bold"), anchor="w", padx=8).pack(fill=tk.X, pady=(8, 4))

        self.info_text = tk.Text(side, height=14, width=32, bg="white",
                                 relief=tk.FLAT, font=("Menlo", 10))
        self.info_text.pack(fill=tk.BOTH, expand=True, padx=8, pady=(0, 8))
        self.info_text.config(state=tk.DISABLED)

    # ---------- Data loading ----------

    def _reload_all(self):
        try:
            self.sim_data = Config(self.config_path).data
            self.sensor_registry = SensorRegistry(self.sim_data)
            self.visualization = load_visualization_settings(self.config_path)
            self.tags, self.tables = load_layout(self.tag_path)
        except Exception as exc:
            messagebox.showerror("Load Error", str(exc))
            return

        self.mesh_cell_var.set(f"{self.visualization.mesh_cell_m:g}")

        sensors = sorted(self.sensor_registry.sensors.keys())
        self.sensor_combo["values"] = sensors
        if sensors:
            if self.selected_sensor.get() not in sensors:
                self.selected_sensor.set(sensors[0])
        else:
            self.selected_sensor.set("")

        self._refresh_info_panel()
        self._render()

    # ---------- Coordinate helpers ----------

    def _transform(self) -> ViewTransform:
        return ViewTransform.from_canvas(self._cw(), self._ch(), self.visualization)

    def _grid_positions(self, limit: float):
        step = max(self.visualization.grid_spacing_m, 0.1)
        count = int(limit / step)
        values = [round(i * step, 6) for i in range(count + 1)]
        if abs(values[-1] - limit) > 1e-6:
            values.append(limit)
        return values

    def _mesh_ranges(self):
        step = max(self.visualization.mesh_cell_m, 0.05)
        x = 0.0
        while x < self.visualization.greenhouse_width_m - 1e-9:
            x1 = min(x + step, self.visualization.greenhouse_width_m)
            yield x, x1
            x = x1

    def _mesh_rows(self):
        step = max(self.visualization.mesh_cell_m, 0.05)
        y = 0.0
        while y < self.visualization.greenhouse_height_m - 1e-9:
            y1 = min(y + step, self.visualization.greenhouse_height_m)
            yield y, y1
            y = y1

    # ---------- Rendering ----------

    def _cw(self):
        w = self.canvas.winfo_width()
        return w if w > 1 else CANVAS_W

    def _ch(self):
        h = self.canvas.winfo_height()
        return h if h > 1 else CANVAS_H

    def _render(self):
        self.canvas.delete("all")
        self._hide_tooltip()
        self._canvas_item_map = {}

        if not self.sensor_registry or not self.selected_sensor.get():
            self.canvas.create_text(16, 16, anchor="nw", fill=TEXT_COL,
                                    text="No sensor configured.", font=("Helvetica", 11, "bold"))
            return

        self._draw_greenhouse_outline()
        self._draw_mesh()
        self._draw_grid()
        if self.show_tables_var.get():
            self._draw_tables()
        if self.show_tags_var.get():
            self._draw_tags()
        self._draw_scale_bar()

    def _draw_greenhouse_outline(self):
        transform = self._transform()
        x0, y0, x1, y1 = transform.greenhouse_bbox()
        self.canvas.create_rectangle(
            x0, y0, x1, y1,
            fill="#f7fbf4",
            outline=OUTLINE_COL,
            width=2,
        )

    def _draw_mesh(self):
        sensor_type = self.selected_sensor.get()
        sensor = self.sensor_registry.get_sensor(sensor_type)
        t = float(self.time_var.get())
        transform = self._transform()

        samples = []
        min_v = float("inf")
        max_v = float("-inf")

        for y0_m, y1_m in self._mesh_rows():
            for x0_m, x1_m in self._mesh_ranges():
                cx_m = (x0_m + x1_m) / 2.0
                cy_m = (y0_m + y1_m) / 2.0
                value = sensor.retrieve_data((cx_m, cy_m), t)
                samples.append((x0_m, y0_m, x1_m, y1_m, value))
                min_v = min(min_v, value)
                max_v = max(max_v, value)

        if not samples:
            return

        configured_range = self.visualization.colorbar_ranges.get(sensor_type)
        if configured_range:
            min_v, max_v = configured_range

        span = max(max_v - min_v, 1e-9)

        for x0_m, y0_m, x1_m, y1_m, value in samples:
            n = (value - min_v) / span
            color = self._value_to_color(n)
            x0, y0 = transform.world_to_canvas(x0_m, y0_m)
            x1, y1 = transform.world_to_canvas(x1_m, y1_m)
            self.canvas.create_rectangle(x0, y0, x1, y1, fill=color, outline=color)

        self._draw_legend(min_v, max_v)

    def _draw_grid(self):
        transform = self._transform()
        x0, y0, _, _ = transform.greenhouse_bbox()

        for x_m in self._grid_positions(self.visualization.greenhouse_width_m):
            px, _ = transform.world_to_canvas(x_m, 0.0)
            _, y1 = transform.world_to_canvas(x_m, self.visualization.greenhouse_height_m)
            self.canvas.create_line(px, y0, px, y1, fill=GRID_LINE, dash=(2, 6))
            if x_m > 0:
                self.canvas.create_text(px + 3, y0 + 10, anchor="nw",
                                        text=f"{x_m:g}m", fill="#81c784",
                                        font=("Helvetica", 7))

        for y_m in self._grid_positions(self.visualization.greenhouse_height_m):
            _, py = transform.world_to_canvas(0.0, y_m)
            x1, _ = transform.world_to_canvas(self.visualization.greenhouse_width_m, y_m)
            self.canvas.create_line(x0, py, x1, py, fill=GRID_LINE, dash=(2, 6))
            if y_m > 0:
                self.canvas.create_text(x0 + 3, py + 3, anchor="nw",
                                        text=f"{y_m:g}m", fill="#81c784",
                                        font=("Helvetica", 7))

    def _draw_tables(self):
        transform = self._transform()
        for name, table in self.tables.items():
            x0, y0 = transform.world_to_canvas(table["x0"], table["y0"])
            x1, y1 = transform.world_to_canvas(table["x1"], table["y1"])
            rect_id = self.canvas.create_rectangle(
                x0, y0, x1, y1,
                fill="", outline=TABLE_OUTLINE, width=2
            )
            cx, cy = (x0 + x1) / 2.0, (y0 + y1) / 2.0
            text_id = self.canvas.create_text(cx, cy, text=name, fill=TABLE_OUTLINE,
                                              font=("Helvetica", 9, "bold"))
            self._canvas_item_map[rect_id] = ("table", name)
            self._canvas_item_map[text_id] = ("table", name)

    def _draw_tags(self):
        transform = self._transform()
        radius = max(5, int(round(transform.length_to_px(0.08))))
        for tag_id, data in self.tags.items():
            x, y = transform.world_to_canvas(data["x"], data["y"])
            item_id = self.canvas.create_oval(
                x - radius, y - radius, x + radius, y + radius,
                fill=TAG_COL, outline="white", width=1.5,
                tags=("tag", f"tag_{tag_id}")
            )
            self._canvas_item_map[item_id] = ("tag", tag_id)

    def _draw_scale_bar(self):
        transform = self._transform()
        x0, _, _, y1 = transform.greenhouse_bbox()
        bar_m = 1.0
        bar_px = transform.length_to_px(bar_m)
        bx = x0 + 18
        by = y1 - 18
        self.canvas.create_rectangle(bx - 4, by - 18, bx + bar_px + 4, by + 8,
                                     fill="white", outline="#d0d0d0")
        self.canvas.create_line(bx, by, bx + bar_px, by, fill="#263238", width=3)
        self.canvas.create_line(bx, by - 5, bx, by + 5, fill="#263238", width=2)
        self.canvas.create_line(bx + bar_px, by - 5, bx + bar_px, by + 5, fill="#263238", width=2)
        self.canvas.create_text(bx + bar_px / 2, by - 9, text="1 m",
                                fill="#263238", font=("Helvetica", 9, "bold"))

    def _draw_legend(self, min_v, max_v):
        cw = self._cw()
        x0 = cw - 52
        y0 = 24
        w = 18
        h = 170
        n = 28
        for i in range(n):
            frac = i / (n - 1)
            color = self._value_to_color(1.0 - frac)
            yy0 = y0 + i * (h / n)
            yy1 = y0 + (i + 1) * (h / n)
            self.canvas.create_rectangle(x0, yy0, x0 + w, yy1,
                                         fill=color, outline=color)
        self.canvas.create_rectangle(x0, y0, x0 + w, y0 + h, outline="#263238", width=1)
        self.canvas.create_text(x0 + w + 8, y0, anchor="nw", text=f"{max_v:.2f}",
                                fill=TEXT_COL, font=("Helvetica", 8))
        self.canvas.create_text(x0 + w + 8, y0 + h - 10, anchor="nw", text=f"{min_v:.2f}",
                                fill=TEXT_COL, font=("Helvetica", 8))
        self.canvas.create_text(x0 - 4, y0 - 12, anchor="nw",
                                text=self.selected_sensor.get(),
                                fill=TEXT_COL, font=("Helvetica", 8, "bold"))

    def _value_to_color(self, n: float) -> str:
        n = max(0.0, min(1.0, n))
        if n < 0.5:
            t = n / 0.5
            r = int(40 + t * (255 - 40))
            g = int(120 + t * (230 - 120))
            b = int(255 - t * (255 - 80))
        else:
            t = (n - 0.5) / 0.5
            r = 255
            g = int(230 - t * 210)
            b = int(80 - t * 80)
        return f"#{r:02x}{g:02x}{b:02x}"

    # ---------- Interaction ----------

    def _on_time_slider(self, _value):
        self.time_text_var.set(self._format_hms(self.time_var.get()))
        self._render()

    def _toggle_play(self):
        self.playing = not self.playing
        self.play_btn.config(text="Pause" if self.playing else "Play")
        if self.playing:
            self._last_tick = time.monotonic()
            self._tick()

    def _tick(self):
        if not self.playing:
            return

        now = time.monotonic()
        dt_real = max(0.0, now - (self._last_tick or now))
        self._last_tick = now

        try:
            speed = float(self.speed_var.get())
            if speed < 0:
                speed = 0.0
        except ValueError:
            speed = 0.0

        new_t = (self.time_var.get() + dt_real * speed) % DAY_SECONDS
        self.time_var.set(new_t)
        self.time_text_var.set(self._format_hms(new_t))
        self._render()
        self.root.after(33, self._tick)

    def _on_mouse_move(self, event):
        transform = self._transform()
        if transform.contains_canvas_point(event.x, event.y):
            x_m, y_m = transform.canvas_to_world(event.x, event.y, clamp=True)
            self.coord_lbl.config(text=f"({x_m:.2f} m, {y_m:.2f} m)")
        else:
            self.coord_lbl.config(text="Outside greenhouse")

        hit = self._hit_test(event.x, event.y)
        if hit is None:
            self._hide_tooltip()
            return
        kind, item_id = hit
        if kind == "tag":
            self._show_tag_tooltip(item_id, event.x, event.y)
        else:
            self._show_table_tooltip(item_id, event.x, event.y)

    def _hit_test(self, x, y):
        current = self.canvas.find_withtag("current")
        for item_id in current:
            hit = self._canvas_item_map.get(item_id)
            if hit:
                return hit
        nearby = self.canvas.find_overlapping(x - 2, y - 2, x + 2, y + 2)
        for item_id in reversed(nearby):
            hit = self._canvas_item_map.get(item_id)
            if hit:
                return hit
        return None

    def _show_tag_tooltip(self, tag_id, x, y):
        self._hide_tooltip()
        data = self.tags[tag_id]
        sensors = data.get("sensors", [])

        text = (
            f"{tag_id}\n"
            f"Sensors: {', '.join(sensors) if sensors else '-'}\n"
            f"Pos: ({data['x']:.2f}, {data['y']:.2f}) m"
        )

        txt_id = self.canvas.create_text(
            x + 14, y - 14,
            text=text, anchor="nw",
            fill=TEXT_COL, font=("Helvetica", 8, "bold")
        )
        x0, y0, x1, y1 = self.canvas.bbox(txt_id)
        box_id = self.canvas.create_rectangle(
            x0 - 5, y0 - 4, x1 + 5, y1 + 4,
            fill="#fffde7", outline="#c5e1a5", width=1
        )
        self.canvas.tag_raise(txt_id, box_id)
        self._tooltip_ids = [box_id, txt_id]

    def _show_table_tooltip(self, name, x, y):
        self._hide_tooltip()
        table = self.tables[name]
        width = table["x1"] - table["x0"]
        height = table["y1"] - table["y0"]
        text = (
            f"{name}\n"
            f"Origin: ({table['x0']:.2f}, {table['y0']:.2f}) m\n"
            f"Size: {width:.2f} × {height:.2f} m"
        )

        txt_id = self.canvas.create_text(
            x + 14, y - 14,
            text=text, anchor="nw",
            fill=TEXT_COL, font=("Helvetica", 8, "bold")
        )
        x0, y0, x1, y1 = self.canvas.bbox(txt_id)
        box_id = self.canvas.create_rectangle(
            x0 - 5, y0 - 4, x1 + 5, y1 + 4,
            fill="#fffde7", outline="#c5e1a5", width=1
        )
        self.canvas.tag_raise(txt_id, box_id)
        self._tooltip_ids = [box_id, txt_id]

    def _hide_tooltip(self):
        for cid in self._tooltip_ids:
            self.canvas.delete(cid)
        self._tooltip_ids = []

    # ---------- Misc ----------

    def _refresh_info_panel(self):
        sensor_list = sorted(self.sensor_registry.sensors.keys()) if self.sensor_registry else []
        lines = [
            f"Config: {self.config_path.name}",
            f"Tag file: {self.tag_path.name}",
            "",
            f"Greenhouse: {self.visualization.greenhouse_width_m:g} × {self.visualization.greenhouse_height_m:g} m",
            f"Grid: {self.visualization.grid_spacing_m:g} m",
            f"Mesh cell: {self.visualization.mesh_cell_m:g} m",
            "",
            f"Tags: {len(self.tags)}",
            f"Tables: {len(self.tables)}",
            "",
            "Sensors in config:",
        ]
        lines.extend([f"  - {sensor}" for sensor in sensor_list] or ["  (none)"])

        self.info_text.config(state=tk.NORMAL)
        self.info_text.delete("1.0", tk.END)
        self.info_text.insert(tk.END, "\n".join(lines))
        self.info_text.config(state=tk.DISABLED)

    @staticmethod
    def _format_hms(sec):
        sec = int(sec) % DAY_SECONDS
        h = sec // 3600
        m = (sec % 3600) // 60
        s = sec % 60
        return f"{h:02d}:{m:02d}:{s:02d}"


def _resolve_startup_paths(config_folder_arg=None):
    if config_folder_arg:
        return resolve_config_paths(config_folder_arg)

    use_default = messagebox.askyesno(
        "Load Configuration",
        (
            "Load configuration from default folder?\n\n"
            f"Default:\n{DEFAULT_CONFIG_FILE.parent}\n\n"
            "Click 'No' to choose a custom folder containing\n"
            "greenhouse_config.yaml and tag_locations.json."
        ),
    )
    if use_default:
        return resolve_config_paths(None)

    while True:
        folder = filedialog.askdirectory(title="Select config folder")
        if not folder:
            return None, None
        try:
            return resolve_config_paths(folder)
        except FileNotFoundError as exc:
            messagebox.showerror("Invalid Folder", str(exc))


def main(argv=None):
    parser = argparse.ArgumentParser(
        description=(
            "Start greenhouse simulation viewer. Optionally provide a folder that "
            "contains greenhouse_config.yaml and tag_locations.json."
        )
    )
    parser.add_argument(
        "config_folder",
        nargs="?",
        help="Folder containing greenhouse_config.yaml and tag_locations.json",
    )
    args = parser.parse_args(argv)

    root = tk.Tk()
    config_path, tag_path = _resolve_startup_paths(args.config_folder)
    if not config_path or not tag_path:
        root.destroy()
        return 0

    SimulationViewer(root, config_path=config_path, tag_path=tag_path)
    root.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
