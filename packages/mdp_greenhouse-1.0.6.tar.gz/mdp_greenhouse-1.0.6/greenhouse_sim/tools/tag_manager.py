__author__ = "Robust Robot Systems, TU Delft"
__copyright__ = "Copyright 2026, R2S"
__license__ = "Apache-2.0"
__version__ = "1.0.3"

from pathlib import Path
import json

class TagManager:
    """
    Tag manager object that manages the tag locations and their associated sensors in a simulation.
    """
    def __init__(self, path = None):
        if path is None:
            module_root = Path(__file__).resolve().parent.parent
            config_dir = module_root / "configs"
            self.file_path = config_dir / "tag_locations.json"
        else:
            self.file_path = path
        self.tags = self.load()

    def load(self):
        if self.file_path.exists():
            with open(self.file_path) as f:
                data = json.load(f)
            # Support new nested format {"tags": {...}, "tables": {...}}
            if "tags" in data and isinstance(data["tags"], dict):
                return data["tags"]
            return data
        return {}

    def get_tags(self):
        return self.tags

    def get_position(self, tag_id):
        tag = self.tags[tag_id]
        return (tag["x"], tag["y"])

    def get_sensors(self, tag_id):
        return self.tags[tag_id]["sensors"]
