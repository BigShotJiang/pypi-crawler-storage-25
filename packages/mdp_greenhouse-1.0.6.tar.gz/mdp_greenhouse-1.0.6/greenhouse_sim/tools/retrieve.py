__author__ = "Robust Robot Systems, TU Delft"
__copyright__ = "Copyright 2026, R2S"
__license__ = "Apache-2.0"
__version__ = "1.0.3"

import argparse
import json
import time

from greenhouse_sim.simulator import GreenhouseSimulator
from greenhouse_sim.tools.layout_utils import resolve_config_paths


def _build_simulator(config_folder=None) -> GreenhouseSimulator:
    config_path, tag_path = resolve_config_paths(config_folder)
    return GreenhouseSimulator(tag_file=tag_path, sim_config_file=config_path)


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(
        description=(
            "Stream sensor data for a tag every second. "
            "Optionally list available tag IDs."
        )
    )
    parser.add_argument("tag_id", nargs="?", help="Tag ID to retrieve")
    parser.add_argument(
        "--config-folder",
        help="Folder containing greenhouse_config.yaml and tag_locations.json",
    )
    parser.add_argument(
        "--list-tags",
        action="store_true",
        help="List available tag IDs and exit",
    )
    parser.add_argument(
        "--count",
        type=int,
        default=None,
        help="Number of samples to print before exiting (default: infinite)",
    )
    args = parser.parse_args(argv)

    sim = _build_simulator(args.config_folder)
    tag_ids = sim.tags()

    if args.list_tags:
        for tag_id in tag_ids:
            print(tag_id)
        return 0

    if not args.tag_id:
        parser.error("tag_id is required unless --list-tags is used")

    if args.tag_id not in tag_ids:
        raise ValueError(f"Unknown tag_id '{args.tag_id}'. Use --list-tags to see valid IDs.")

    sample_count = 0
    while True:
        data = sim.get_sensor_data(args.tag_id)
        print(json.dumps(data, sort_keys=True))
        sample_count += 1

        if args.count is not None and sample_count >= args.count:
            break
        time.sleep(1.0)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())

