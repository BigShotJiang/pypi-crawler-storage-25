__author__ = "Robust Robot Systems, TU Delft"
__copyright__ = "Copyright 2026, R2S"
__license__ = "Apache-2.0"
__version__ = "1.0.3"

import argparse
import sys

from greenhouse_sim.tools.retrieve import main as retrieve_main
from greenhouse_sim.tools.scaffold_config import main as scaffold_main
from greenhouse_sim.tools.tag_place_gui import main as edit_main
from greenhouse_sim.tools.viewer import main as view_main


def main(argv=None) -> int:
    if argv is None:
        argv = sys.argv[1:]

    parser = argparse.ArgumentParser(
        prog="mdp-greenhouse",
        description=(
            "Unified CLI for the MDP greenhouse tools. Choose exactly one mode and pass "
            "the mode-specific arguments after it."
        ),
        add_help=False,
    )
    parser.add_argument("-h", "--help", action="store_true", dest="help_requested")
    mode = parser.add_mutually_exclusive_group(required=False)
    mode.add_argument("--edit", action="store_true", help="Launch the tag placement GUI")
    mode.add_argument("--view", action="store_true", help="Launch the simulation viewer GUI")
    mode.add_argument("--init", action="store_true", help="Create default config files in a target folder")
    mode.add_argument("--read", action="store_true", help="Read or list live tag data")
    parsed, forwarded = parser.parse_known_args(argv)

    selected_mode = any((parsed.edit, parsed.view, parsed.init, parsed.read))

    if parsed.help_requested and not selected_mode:
        parser.print_help()
        return 0

    if parsed.help_requested:
        forwarded = [*forwarded, "--help"]

    if not selected_mode:
        parser.error("one of the arguments --edit --view --init --read is required")

    if parsed.edit:
        return edit_main(forwarded)
    if parsed.view:
        return view_main(forwarded)
    if parsed.init:
        return scaffold_main(forwarded)
    if parsed.read:
        return retrieve_main(forwarded)

    return 2


if __name__ == "__main__":
    raise SystemExit(main())

