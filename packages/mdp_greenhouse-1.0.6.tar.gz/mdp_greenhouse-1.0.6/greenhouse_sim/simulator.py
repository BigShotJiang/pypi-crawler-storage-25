__author__ = "Robust Robot Systems, TU Delft"
__copyright__ = "Copyright 2026, R2S"
__license__ = "Apache-2.0"
__version__ = "1.0.3"

from datetime import datetime

from greenhouse_sim.tools.config_loader import Config
from greenhouse_sim.sensors import AVAILABLE_SENSORS
from greenhouse_sim.tools.tag_manager import TagManager


class SensorRegistry:
    """
    Sensor registry object that manages the sensor instances in a simulation.
    """

    def __init__(self, config: dict):
        self.config = config
        self.sensors: dict = {}

        # setup sensors from config file
        self._setup()

    def _setup(self):
        """
        Initialize the sensor registry by checking all the sensors in the simulation.
        :return:
        """

        sensor_setup = self.config['sensors']

        for s in sensor_setup.keys():
            # check if sensor is available in simulation
            if s not in AVAILABLE_SENSORS:
                raise TypeError(f"Specified sensor of type {s} not available!")

            # start creating the sensor
            cls = AVAILABLE_SENSORS[s]

            # single sensor first
            self.sensors[s] = cls(sensor_setup[s][0])

            # check if composite sensor and create it iteratively
            if len(sensor_setup[s]) > 1:
                for i in range(1, len(sensor_setup[s])):
                    self.sensors[s] += cls(sensor_setup[s][i])

    def get_sensor(self, type: str):
        """
        Return the sensor instance with the specified type.
        :param type: The type of sensor to return.
        :return: The sensor instance of the specified type.
        """
        if type not in self.sensors.keys():
            raise ValueError(f"Sensor type {type} not available")
        return self.sensors[type]


class GreenhouseSimulator:
    """
    Greenhouse simulator object that manages the simulation.
    """

    def __init__(self, tag_file=None, sim_config_file=None):
        """
        Initialize the simulator object.
        :param tag_file: The tag file to load.
        :param sim_config_file: The simulation config file.
        """

        self.tag_manager = TagManager(tag_file)
        self.sim_config = Config(sim_config_file).data
        self.sensor_registry = SensorRegistry(self.sim_config)

        if self.sim_config["time"]['debug_mode']:
            # set fixed seed
            import random
            random.seed(self.sim_config["time"]['debug_seed'])
            print('// Greenhouse Simulator running in debug mode!')

    def tags(self):
        """
        Return a list of tags in the simulator.
        :return: A list of tags in the simulator.
        """
        return list(self.tag_manager.get_tags().keys())

    def sensors(self):
        """
        Return a list of sensors in the simulator.
        :return: A list of sensors in the simulator.
        """
        return list(self.sensor_registry.sensors.keys())

    def current_time(self):
        """
        Return the current simulation time in seconds.
        :return: Current simulation time in seconds.
        """
        if self.sim_config["time"]['debug_mode']:
            # in hours
            t_h = self.sim_config["time"]['debug_time_of_day']
            # convert to seconds and return
            return (t_h * 24 * 60 * 60) % (24 * 60 * 60)
        else:
            speed_up = self.sim_config["time"]["speedup_factor"]
            now = datetime.now()
            t = 24 * 60 * now.hour + now.minute * 60 + now.second
            # return sped up time in hours wrapped to seconds of day
            return (speed_up * t) % (24 * 60 * 60)

    def get_sensor_data(self, tag_id):
        """
        Return the sensor data for the specified tag.
        :param tag_id: The ID of the tag to retrieve sensor data for.
        :return: The retrieved sensor data for the specified tag as a dictionary.
        """
        """
        Return a dictionary:
            {
                "temperature": 21.3,
                "humidity": 59.2,
                ...
            }

        Only for the requested tag.
        """
        # Safety: unknown tag
        if tag_id not in self.tag_manager.get_tags():
            return {}

        tag = self.tag_manager.get_tags()[tag_id]
        pos = (tag["x"], tag["y"])
        tag_sensors = tag["sensors"]

        t = self.current_time()
        data = {'timestamp': t}

        for sensor_name in tag_sensors:
            sensor = self.sensor_registry.sensors[sensor_name]
            value = sensor.retrieve_data(
                position=pos,
                time=t
            )
            data[sensor_name] = value

        return data


if __name__ == '__main__':
    sim = GreenhouseSimulator()
    print(f'Available tags are {sim.tags()}')
    print(f'Available sensors are {sim.sensors()}')

    print(f'Retrieveing sensor data for tag {sim.tags()[0]}:')
    print(sim.get_sensor_data(sim.tags()[0]))
