__author__ = "Robust Robot Systems, TU Delft"
__copyright__ = "Copyright 2026, R2S"
__license__ = "Apache-2.0"
__version__ = "1.0.3"

from abc import ABC, abstractmethod
import math
import random


class Dynamics(ABC):
    """
    Abstract base class to describe greenhouse dynamics
    """

    type: str

    def __init__(self, params: dict):
        self.params = params

    @abstractmethod
    def query(self, position, time):
        """
        Return sensed environment value at given position and time
        :param position: The position of the query
        :param time: The time of the query
        :return: The sensed environment information
        """
        pass


class UniformDynamics(Dynamics):
    """
    Uniform dynamics describing uniform values over the position space
    """

    type = 'uniform'

    def __init__(self, params: dict):
        super().__init__(params)

    def query(self, position, time):
        # convert time in seconds to hours of day
        hour = (time / 3600.0) % 24

        mid = self.params.get("value_at_midnight", 20.0)
        noon = self.params.get("value_at_noon", 25.0)
        sigma = self.params.get("noise_sigma", 0.0)

        # daily sinusoid
        average = (mid + noon) / 2.
        amplitude = (noon - mid) / 2.
        value = average + amplitude * math.sin(2 * math.pi * (hour - 6.) / 24)

        # Gaussian noise
        if sigma > 0:
            value += random.gauss(0, sigma)

        return value


class LinearDynamics(Dynamics):
    """
    Linear dynamics describing linear gradients over the position space
    """

    type = 'linear'

    def __init__(self, params: dict):
        super().__init__(params)

    def query(self, position, time):
        hour = (time / 3600.0) % 24
        mid = self.params.get("value_at_midnight", 20.0)
        noon = self.params.get("value_at_noon", 25.0)
        sigma = self.params.get("noise_sigma", 0.0)
        average = (mid + noon) / 2.
        amplitude = (noon - mid) / 2.
        value_time = average + amplitude * math.sin(2 * math.pi * (hour - 6.) / 24)

        # linear gradient at position and angle
        # point defining the line and angle
        alpha = self.params.get("angle", 0.0)

        # convert angle to radian
        alpha = math.radians(alpha)

        # line coefficients ax + by + c = 0
        a = math.sin(alpha)
        b = math.cos(alpha)
        pos_sensor = self.params.get("position", (0, 0))  # simulator fills this
        # Ensure the line passes through the sensor anchor point.
        c = -(a * pos_sensor[0] + b * pos_sensor[1])
        # compute distance
        d = abs(a * position[0] + b * position[1] + c)

        decay_distance = self.params.get("decay_distance", 100.0)
        decay_type = self.params.get("decay_type", "linear")

        if decay_type == "quadratic":
            decay_factor = max(0, 1 - (d / decay_distance) ** 2)
        else:
            decay_factor = max(0, 1 - d / decay_distance)

        value = value_time * decay_factor

        if sigma > 0:
            value += random.gauss(0, sigma)

        return value


class RadialDynamics(Dynamics):
    """
    Radial dynamics describing radial gradients over the position space
    """
    type = 'radial'

    def __init__(self, params: dict):
        super().__init__(params)

    def query(self, position, time):
        # convert time in seconds to hours of day
        hour = (time / 3600.0) % 24

        mid = self.params.get("value_at_midnight", 20.0)
        noon = self.params.get("value_at_noon", 25.0)
        sigma = self.params.get("noise_sigma", 0.0)

        # daily sinusoid
        average = (mid + noon) / 2.
        amplitude = (noon - mid) / 2.
        value_time = average + amplitude * math.sin(2 * math.pi * (hour - 6.) / 24)

        # spatial decay relative to sensor’s own location
        pos_sensor = self.params.get("position", (0, 0))  # simulator fills this
        dx = position[0] - pos_sensor[0]
        dy = position[1] - pos_sensor[1]
        d = math.sqrt(dx * dx + dy * dy)

        decay_distance = self.params.get("decay_distance", 100.0)
        decay_type = self.params.get("decay_type", "linear")

        if decay_type == "quadratic":
            decay_factor = max(0, 1 - (d / decay_distance) ** 2)
        else:
            decay_factor = max(0, 1 - d / decay_distance)

        value = value_time * decay_factor

        # Gaussian noise
        if sigma > 0:
            value += random.gauss(0, sigma)

        return value


# Convenience list for fast generation in sensors
AVAILABLE_DYNAMICS = {cls({}).type: cls for cls in Dynamics.__subclasses__()}

if __name__ == '__main__':
    print(AVAILABLE_DYNAMICS)
