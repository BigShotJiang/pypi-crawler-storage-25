from pathlib import Path

from setuptools import find_packages, setup


ROOT = Path(__file__).resolve().parent
README = ROOT / "README.md"
REQUIREMENTS = ROOT / "requirements.txt"


def _read_requirements(path: Path):
    if not path.exists():
        return []
    lines = []
    for line in path.read_text().splitlines():
        item = line.strip()
        if not item or item.startswith("#"):
            continue
        lines.append(item)
    return lines


setup(
    name="mdp-greenhouse-sim",
    version="0.1.0",
    description="Greenhouse simulation and GUI layout tools",
    long_description=README.read_text(encoding="utf-8") if README.exists() else "",
    long_description_content_type="text/markdown",
    packages=find_packages(),
    include_package_data=True,
    package_data={"greenhouse_sim": ["configs/*.yaml", "configs/*.json"]},
    install_requires=_read_requirements(REQUIREMENTS),
    python_requires=">=3.9",
    entry_points={
        "console_scripts": [
            "mdp-greenhouse=greenhouse_sim.cli:main",
        ]
    },
)

