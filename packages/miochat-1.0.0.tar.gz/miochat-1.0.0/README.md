# Without Token - Way 1

```python
from miochat.vira import ViraChat

phone = "09xxxxxxxxx"

vira = ViraChat()
vira.sendOtpCode(phone)
log = vira.login(phone, input("enter code: "))
print("your token:", log.token)
prompt = vira.sendPrompt("سلام")
print("ai:", prompt.message.content)
```

# With Token - Way 2

```python
from miochat.vira import ViraChat

token = ""

vira = ViraChat(token)
prompt = vira.sendPrompt("سلام")
print("ai:", prompt.message.content)
```
