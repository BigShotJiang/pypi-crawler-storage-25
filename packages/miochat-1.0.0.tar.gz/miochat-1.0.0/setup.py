from setuptools import setup, find_packages

setup(
    name='miochat',
    version='1.0.0',
    packages=find_packages(),
    description='MioChat Module',
    long_description=open('README.md', encoding='utf-8').read(),
    long_description_content_type='text/markdown',
    author='Akuma & Soroush Ahmadi',
    author_email='testoftesttestfortest@gmail.com',
    license='MIT',
    install_requires=["requests"],
)
