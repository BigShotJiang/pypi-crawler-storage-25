from dataclasses import dataclass
from typing import Union, Any
import sys

dataclasses_config = {}

if sys.version_info >= (3, 10):
    dataclasses_config['slots'] = True

@dataclass(**dataclasses_config)
class ActiveTokens(object):
    tokenId: Union[str, None] = None
    remainingTime: Union[int, None] = None
    remainingUsage: Union[str, None] = None
    serviceList: Union[list[str], None] = None

    @classmethod
    def from_json(cls, data: dict = {}) -> "ActiveTokens":
        return cls(
            tokenId=data.get("tokenId"),
            remainingTime=data.get("remainingTime"),
            remainingUsage=data.get("remainingUsage"),
            serviceList=data.get("serviceList")
        )
    
    def to_json(self) -> dict:
        return {
            "tokenId": self.tokenId,
            "remainingTime": self.remainingTime,
            "remainingUsage": self.remainingUsage,
            "serviceList": self.serviceList
        }


@dataclass(**dataclasses_config)
class ActiveSubscriptions(object):
    remainingTimeByHour: Union[int, None] = None
    activeSubscriptions: Union[list[Any], None] = None
    upcomingSubscriptions: Union[list[Any], None] = None
    activeTokens: Union[list[ActiveTokens], None] = None

    @classmethod
    def from_json(cls, data: dict = {}) -> "ActiveSubscriptions":
        return cls(
            remainingTimeByHour=data.get("remainingTimeByHour"),
            activeSubscriptions=data.get("activeSubscriptions"),
            upcomingSubscriptions=data.get("upcomingSubscriptions"),
            activeTokens=[ActiveTokens.from_json(x) for x in data.get("activeTokens", [])]
        )
    
    def to_json(self) -> dict:
        return {
            "remainingTimeByHour": self.remainingTimeByHour,
            "activeSubscriptions": self.activeSubscriptions,
            "upcomingSubscriptions": self.upcomingSubscriptions,
            "activeTokens": [x.to_json() for x in (self.activeTokens if self.activeTokens else [])]
        }

@dataclass(**dataclasses_config)
class Login(object):
    token: Union[str, None] = None
    authenticatePack: Union[dict[str, Union[str, Any]], None] = None
    roles: Union[list[str], None] = None
    expireTime: Union[int, None] = None
    activeSubscriptions: Union[ActiveSubscriptions, None] = None
    walletBalance: Union[int, None] = None

    @classmethod
    def from_json(cls, data: dict = {}) -> "Login":
        return cls(
            token=data.get("token"),
            authenticatePack=data.get("authenticatePack"),
            roles=data.get("roles"),
            expireTime=data.get("expireTime"),
            walletBalance=data.get("walletBalance"),
            activeSubscriptions=ActiveSubscriptions.from_json(data.get("activeSubscriptions", {}))
        )
    
    def to_json(self) -> dict:
        return {
            "token": self.token,
            "authenticatePack": self.authenticatePack,
            "roles": self.roles,
            "expireTime": self.expireTime,
            "walletBalance": self.walletBalance,
            "activeSubscriptions": self.activeSubscriptions.to_json() if self.activeSubscriptions else {}
        }

@dataclass(**dataclasses_config)
class Message(object):
    fileId: Union[str, None] = None
    content: Union[str, None] = None

    @classmethod
    def from_json(cls, data: dict = {}) -> "Message":
        return cls(
            fileId=data.get("fileId"),
            content=data.get("content")
        )
    
    def to_json(self) -> dict:
        return {
            "fileId": self.fileId,
            "content": self.content
        }

@dataclass(**dataclasses_config)
class SendMessage(object):
    conversationId: Union[str, None] = None
    message: Union[Message, None] = None

    @classmethod
    def from_json(cls, data: dict = {}) -> "SendMessage":
        return cls(
            conversationId=data.get("conversationId"),
            message=Message.from_json(data.get("message", {}))
        )
    
    def to_json(self) -> dict:
        return {
            "conversationId": self.conversationId,
            "message": self.message.to_json() if self.message else {}
        }
