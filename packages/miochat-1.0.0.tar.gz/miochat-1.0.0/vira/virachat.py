import requests
import json
from typing import Union
from .bundles import Login, SendMessage

class ViraChat(object):
    def __init__(self, token: Union[str, None] = None):
        self.token = token
        self.sync_http = requests
        self.__base_url = "https://gw-web.ivira.ai"
        self.__signup_payload = {
            "Accept": "application/json, text/plain, */*",
            "Accept-Encoding": "gzip, deflate, br, zstd",
            "Accept-Language": "en-US,en;q=0.9",
            "baggage": "sentry-environment=prod,sentry-release=2.7.6,sentry-public_key=82b868450fe88ef0a16b4c5464779282,sentry-trace_id=66317c67e155428bb1498d61d8af9953,sentry-replay_id=7c783dcf16994836a919524db19c8427,sentry-transaction=Login,sentry-sampled=true,sentry-sample_rand=0.14617130090537855,sentry-sample_rate=1",
            "Connection": "keep-alive",
            "Content-Type": "application/json",
            "Host": "gw-web.ivira.ai",
            "Origin": "https://web.ivira.ai",
            "Priority": "u=0",
            "Referer": "https://web.ivira.ai/",
            "Sec-Fetch-Dest": "empty",
            "Sec-Fetch-Mode": "cors",
            "Sec-Fetch-Site": "same-site",
            "sentry-trace": "66317c67e155428bb1498d61d8af9953-9fca9b0304329305-1",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0",
            "x-gateway-system-viraWeb": "1"
        }

        self.__login_payload = {
            "Accept": "application/json, text/plain, */*",
            "Accept-Encoding": "gzip, deflate, br, zstd",
            "Accept-Language": "en-US,en;q=0.9",
            "baggage": "sentry-environment=prod,sentry-release=2.7.6,sentry-public_key=82b868450fe88ef0a16b4c5464779282,sentry-trace_id=46afb8cdf7f7462d93c2bcb402038233,sentry-transaction=Otp,sentry-sampled=true,sentry-sample_rand=0.13445990840995004,sentry-sample_rate=1",
            "Connection": "keep-alive",
            "Content-Type": "application/json",
            "Host": "gw-web.ivira.ai",
            "Origin": "https://web.ivira.ai",
            "Priority": "u=0",
            "Referer": "https://web.ivira.ai/",
            "Sec-Fetch-Dest": "empty",
            "Sec-Fetch-Mode": "cors",
            "Sec-Fetch-Site": "same-site",
            "sentry-trace": "46afb8cdf7f7462d93c2bcb402038233-880f4d2b5e451a6a-1",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0",
            "x-gateway-system-viraWeb": "1"
        }

        self.__sendmessage_payload = {
            "Accept": "application/json, text/plain, */*",
            "Accept-Encoding": "gzip, deflate, br, zstd",
            "Accept-Language": "en-US,en;q=0.9",
            "baggage": "sentry-environment=prod,sentry-release=2.7.6,sentry-public_key=82b868450fe88ef0a16b4c5464779282,sentry-trace_id=c009c16c9c5341bfbcb9ab96e3a76edc,sentry-replay_id=31d3366ca0ac40b2b821f9ae4cd2ae78,sentry-transaction=Conversation,sentry-sampled=true,sentry-sample_rand=0.3484160677396023,sentry-sample_rate=1",
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "Content-Length": "46",
            "Content-Type": "application/json",
            "Host": "gw-web.ivira.ai",
            "Origin": "https://web.ivira.ai",
            "Pragma": "no-cache",
            "Priority": "u=0",
            "Referer": "https://web.ivira.ai/",
            "Sec-Fetch-Dest": "empty",
            "Sec-Fetch-Mode": "no-cors",
            "Sec-Fetch-Site": "same-site",
            "sentry-trace": "c009c16c9c5341bfbcb9ab96e3a76edc-a1be564b6251aaf6-1",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0",
            "User-Token": self.token,
            "x-access-token": "P~W~d909febb-3cf0-4bf6-9db7-c6737639083e",
            "x-gateway-system-viraWeb": "1"
        }
    
    def __phone_slicer(self, phone: str):
        if phone.startswith("0"):
            return phone
        elif phone.startswith("9"):
            return "0" + phone
        elif phone.startswith("+98"):
            return "0" + phone[3:]
        else:
            return phone


    def sendOtpCode(self, mobile: str) -> dict:
        try:
            mobile = self.__phone_slicer(mobile)
            response = self.sync_http.post(self.__base_url + "/vira@1/userManager/sendOtp", headers=self.__signup_payload, data=json.dumps({ "mobile": mobile }))
            response.raise_for_status()
            jsoned = response.json()
            if "data" in jsoned:
                return jsoned['data']
            else:
                return {"status": False, "message": "invalid data structure", "data": jsoned}
        except Exception as E:
            print("[sendOtpCode] error", E)
            return {"status": False, "message": E}
    
    def login(self, mobile: str, code: str, set_on_self: bool = True) -> Login:
        try:
            mobile = self.__phone_slicer(mobile)
            response = self.sync_http.post(self.__base_url + "/vira@1/userManager/signIn", headers=self.__login_payload, data=json.dumps({ "mobile": mobile, "otp": code }))
            response.raise_for_status()
            jsoned = response.json()
            if "data" in jsoned:
                log = Login.from_json(jsoned['data'])
                if set_on_self:
                    self.token = log.token
                return log
            else:
                print("[login] error", "invalid data structure")
                return Login()
        except Exception as E:
            print("[login] error", E)
            return Login()
        
    def sendPrompt(self, text: str) -> SendMessage:
        try:
            response = self.sync_http.post(self.__base_url + "/compound-vira/conversation", headers=self.__sendmessage_payload, data=json.dumps({ "message": text, "conversationId": "sL7ykMob" }), cookies={"cookiesession1": "678B286EB8C33E3ECE54C713B625F2C4"})
            response.raise_for_status()
            jsoned = response.json()
            if "data" in jsoned:
                return SendMessage.from_json(jsoned['data'])
            else:
                print("[sendMessage] error", "invalid data structure")
                return SendMessage()
        except Exception as E:
            print("[sendMessage] error", E)
            return SendMessage()
