#
# Unified Query Algebra
#
# Copyright (c) 2023-2026 Cognica, Inc.
#

"""Relational physical operators for the Volcano execution engine.

These operators implement the standard relational algebra over batches:
filter, project, sort, limit, hash-aggregate, and distinct.  Each
follows the ``open / next / close`` iterator protocol.

Sort, hash-aggregate, and distinct are *blocking* operators -- they
materialize all input before producing output.  Filter, project, and
limit are *streaming* operators that process one batch at a time.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, cast

from uqa.execution.batch import DEFAULT_BATCH_SIZE, Batch
from uqa.execution.physical import PhysicalOperator


@dataclass(frozen=True, slots=True)
class WindowSpec:
    """Specification for a single window function evaluation.

    Attributes:
        alias: Output column name.
        func_name: Window function name (row_number, rank, lag, sum, ...).
        partition_cols: Columns for PARTITION BY.
        order_keys: List of (column, descending) pairs for ORDER BY.
        arg_col: Column argument for aggregate/navigation functions.
        offset: Row offset for LAG/LEAD (default 1).
        default_value: Default value for LAG/LEAD when out of bounds.
        ntile_buckets: Number of buckets for NTILE.
        frame_start: Frame start type: "unbounded_preceding", "current_row",
            "offset_preceding", "offset_following", or None for default.
        frame_end: Frame end type (same options).
        frame_start_offset: Integer offset for start (if offset type).
        frame_end_offset: Integer offset for end (if offset type).
    """

    alias: str
    func_name: str
    partition_cols: list[str] = field(default_factory=list)
    order_keys: list[tuple[str, bool]] = field(default_factory=list)
    arg_col: str | None = None
    offset: int = 1
    default_value: Any = None
    ntile_buckets: int = 1
    frame_start: str | None = None
    frame_end: str | None = None
    frame_start_offset: int = 0
    frame_end_offset: int = 0
    frame_type: str = "rows"  # "rows" or "range"
    filter_node: Any = None


def _try_arrow_filter(col: Any, predicate: Any, selection: Any) -> list[int] | None:
    """Attempt vectorized Arrow filter for simple predicates.

    Returns a list of active indices, or None if the predicate cannot
    be vectorized (caller should fall back to per-row evaluation).
    """
    import pyarrow.compute as pc

    from uqa.core.types import (
        Equals,
        GreaterThan,
        GreaterThanOrEqual,
        IsNotNull,
        IsNull,
        LessThan,
        LessThanOrEqual,
        NotEquals,
    )

    arrow_arr = col.array
    mask = None

    if isinstance(predicate, Equals):
        mask = pc.equal(arrow_arr, predicate.target)
    elif isinstance(predicate, NotEquals):
        mask = pc.not_equal(arrow_arr, predicate.target)
    elif isinstance(predicate, GreaterThan):
        mask = pc.greater(arrow_arr, predicate.target)
    elif isinstance(predicate, GreaterThanOrEqual):
        mask = pc.greater_equal(arrow_arr, predicate.target)
    elif isinstance(predicate, LessThan):
        mask = pc.less(arrow_arr, predicate.target)
    elif isinstance(predicate, LessThanOrEqual):
        mask = pc.less_equal(arrow_arr, predicate.target)
    elif isinstance(predicate, IsNull):
        mask = pc.is_null(arrow_arr)
    elif isinstance(predicate, IsNotNull):
        mask = pc.is_valid(arrow_arr)
    else:
        return None

    try:
        bool_arr = mask.to_pylist()
    except Exception:
        return None

    if selection is not None:
        return [i for i in selection if bool_arr[i]]
    return [i for i in range(len(bool_arr)) if bool_arr[i]]


class FilterOp(PhysicalOperator):
    """Evaluate a predicate on a column, setting the selection vector.

    Streaming operator: processes one batch at a time.  Batches with
    no matching rows are skipped (pulls the next batch from the child).

    For simple scalar predicates (=, !=, <, >, <=, >=, IS NULL, IS NOT NULL),
    uses vectorized Arrow compute for faster evaluation.  Falls back to
    per-row Python evaluation for LIKE, BETWEEN, and custom predicates.
    """

    def __init__(
        self,
        child: PhysicalOperator,
        column: str,
        predicate: Any,
    ) -> None:
        self._child = child
        self._column = column
        self._predicate = predicate
        from uqa.core.types import is_null_predicate

        self._null_aware = is_null_predicate(predicate)

    def open(self) -> None:
        self._child.open()

    def next(self) -> Batch | None:
        while True:
            self.check_cancelled()
            batch = self._child.next()
            if batch is None:
                return None

            col = batch.get_column(self._column)
            if col is None:
                continue

            # Try vectorized Arrow compute for simple predicates.
            active = _try_arrow_filter(col, self._predicate, batch.selection)
            if active is None:
                # Fall back to per-row evaluation.
                if batch.selection is not None:
                    indices = batch.selection
                else:
                    indices = range(batch.size)

                active = []
                null_aware = self._null_aware
                for i in indices:
                    val = col[i]
                    if null_aware:
                        matched = self._predicate.evaluate(val)
                    else:
                        matched = val is not None and self._predicate.evaluate(val)
                    if matched:
                        active.append(i)

            if not active:
                continue

            return batch.with_selection(active)

    def close(self) -> None:
        self._child.close()


class ExprFilterOp(PhysicalOperator):
    """Filter rows using an AST expression evaluated by ExprEvaluator.

    Used for WHERE clauses on join results where cross-table column
    comparisons are needed (e.g., WHERE a.id = b.user_id).
    """

    def __init__(
        self,
        child: PhysicalOperator,
        where_node: Any,
        subquery_executor: Any = None,
        params: list[Any] | None = None,
    ) -> None:
        self._child = child
        self._where_node = where_node
        self._subquery_executor = subquery_executor
        self._params = params

    def open(self) -> None:
        self._child.open()
        from uqa.sql.expr_evaluator import ExprEvaluator

        self._evaluator = ExprEvaluator(
            subquery_executor=self._subquery_executor, params=self._params
        )

    def next(self) -> Batch | None:
        while True:
            self.check_cancelled()
            batch = self._child.next()
            if batch is None:
                return None

            # Compact first so selection indices align with the rows
            # returned by to_rows(). Without this, stacked filters
            # produce indices relative to the compacted rows but
            # apply them to the original (pre-compact) RecordBatch.
            batch = batch.compact()
            rows = batch.to_rows()
            active: list[int] = []
            for i, row in enumerate(rows):
                result = self._evaluator.evaluate(self._where_node, row)
                if result:
                    active.append(i)

            if not active:
                continue

            return batch.with_selection(active)

    def close(self) -> None:
        self._child.close()


class ProjectOp(PhysicalOperator):
    """Select specific columns from the input.

    Streaming operator: compacts and projects each batch individually.
    Column renaming is supported via the *aliases* dict.
    """

    def __init__(
        self,
        child: PhysicalOperator,
        columns: list[str],
        aliases: dict[str, str] | None = None,
    ) -> None:
        self._child = child
        self._columns = columns
        self._aliases = aliases or {}

    def open(self) -> None:
        self._child.open()

    def next(self) -> Batch | None:
        batch = self._child.next()
        if batch is None:
            return None

        return batch.compact().select_columns(self._columns, self._aliases)

    def close(self) -> None:
        self._child.close()


class ExprProjectOp(PhysicalOperator):
    """Evaluate SQL expression AST nodes to produce computed columns.

    Streaming operator: evaluates each expression against every row in
    the batch.  Unlike :class:`ProjectOp`, this operator handles arbitrary
    expressions (arithmetic, CASE, CAST, function calls, etc.) via the
    :class:`~uqa.sql.expr_evaluator.ExprEvaluator`.

    *targets* is a list of ``(output_name, ast_node)`` pairs.
    """

    def __init__(
        self,
        child: PhysicalOperator,
        targets: list[tuple[str, Any]],
        subquery_executor: Any = None,
        sequences: dict | None = None,
        outer_row: dict[str, Any] | None = None,
        engine: Any = None,
        params: list[Any] | None = None,
        analyzer: Any = None,
    ) -> None:
        self._child = child
        self._targets = targets
        self._subquery_executor = subquery_executor
        self._sequences = sequences
        self._outer_row = outer_row
        self._engine = engine
        self._params = params
        self._analyzer = analyzer

    def open(self) -> None:
        self._child.open()
        from uqa.sql.expr_evaluator import ExprEvaluator

        self._evaluator = ExprEvaluator(
            subquery_executor=self._subquery_executor,
            sequences=self._sequences,
            outer_row=self._outer_row,
            engine=self._engine,
            params=self._params,
            analyzer=self._analyzer,
        )

    def next(self) -> Batch | None:
        batch = self._child.next()
        if batch is None:
            return None

        batch = batch.compact()

        # Try vectorized Arrow evaluation for simple expressions.
        result = self._try_vectorized(batch)
        if result is not None:
            return result

        # Fall back to row-by-row evaluation.
        input_rows = batch.to_rows()
        output_rows: list[dict[str, Any]] = []
        for row in input_rows:
            out: dict[str, Any] = {}
            for col_name, node in self._targets:
                out[col_name] = self._evaluator.evaluate(node, row)
            output_rows.append(out)

        if not output_rows:
            return None
        return Batch.from_rows(output_rows)

    def _try_vectorized(self, batch: Batch) -> Batch | None:
        """Evaluate all targets using Arrow compute. Returns None if any
        target expression cannot be vectorized, causing the caller to
        fall back to row-by-row evaluation."""
        import pyarrow as pa

        rb = batch.record_batch
        n = rb.num_rows
        if n == 0:
            return None

        arrays = []
        names = []
        for col_name, node in self._targets:
            arr = self._vectorize_node(node, rb, n)
            if arr is None:
                return None
            arrays.append(arr)
            names.append(col_name)

        return Batch(pa.RecordBatch.from_arrays(arrays, names=names))

    def _vectorize_node(self, node: Any, rb: Any, n: int) -> Any:
        """Convert a single AST node to an Arrow array, or None if the
        node type is not supported for vectorized evaluation."""
        import pyarrow as pa
        import pyarrow.compute as pc
        from pglast.ast import A_Const, A_Expr, ColumnRef
        from pglast.ast import Boolean as PgBoolean
        from pglast.ast import Float as PgFloat
        from pglast.ast import Integer as PgInteger
        from pglast.ast import String as PgString
        from pglast.enums.parsenodes import A_Expr_Kind

        if isinstance(node, ColumnRef):
            fields_list: list[Any] = list(node.fields or ())
            if len(fields_list) >= 2 and hasattr(fields_list[0], "sval"):
                qualified = f"{fields_list[0].sval}.{fields_list[-1].sval}"
                if qualified in rb.schema.names:
                    return rb.column(qualified)
            col = fields_list[-1].sval
            if col in rb.schema.names:
                return rb.column(col)
            return None

        if isinstance(node, A_Const):
            if node.isnull:
                return pa.nulls(n)
            val = node.val
            if isinstance(val, PgInteger):
                return pa.array([val.ival] * n, type=pa.int64())
            if isinstance(val, PgFloat):
                return pa.array([float(cast("str", val.fval))] * n, type=pa.float64())
            if isinstance(val, PgString):
                return pa.array([val.sval] * n, type=pa.utf8())
            if isinstance(val, PgBoolean):
                return pa.array([val.boolval] * n, type=pa.bool_())
            return None

        if isinstance(node, A_Expr) and A_Expr_Kind(node.kind) == A_Expr_Kind.AEXPR_OP:
            op = node.name[0].sval if node.name else None
            if op not in ("+", "-", "*", "/"):
                return None
            left = self._vectorize_node(node.lexpr, rb, n)
            right = self._vectorize_node(node.rexpr, rb, n)
            if left is None or right is None:
                return None
            try:
                if op == "+":
                    return pc.add(left, right)
                if op == "-":
                    return pc.subtract(left, right)
                if op == "*":
                    return pc.multiply(left, right)
                if op == "/":
                    # SQL semantics: division by zero yields NULL.
                    zero_mask = pc.equal(right, 0)
                    safe_right = pc.if_else(zero_mask, 1, right)
                    result = pc.divide(left, safe_right)
                    return pc.if_else(zero_mask, None, result)
            except (
                pa.ArrowInvalid,
                pa.ArrowTypeError,
                pa.ArrowNotImplementedError,
            ):
                return None

        return None

    def close(self) -> None:
        self._child.close()


class SortOp(PhysicalOperator):
    """Sort all input rows by the specified keys.

    Blocking operator: materializes all input before producing sorted
    output in batches.  Sort stability is guaranteed (Python's
    ``list.sort`` is stable).

    When *spill_threshold* > 0 and the input exceeds that many rows,
    sorted runs are spilled to disk as Arrow IPC files and merged via
    a k-way merge (external merge sort).
    """

    def __init__(
        self,
        child: PhysicalOperator,
        sort_keys: list[tuple[str, bool] | tuple[str, bool, bool]],
        batch_size: int = DEFAULT_BATCH_SIZE,
        spill_threshold: int = 0,
    ) -> None:
        self._child = child
        # Normalize to 3-tuple: (col_name, is_desc, nulls_first)
        # Default follows PostgreSQL: NULLS FIRST for DESC, NULLS LAST for ASC
        self._sort_keys: list[tuple[str, bool, bool]] = [
            (k[0], k[1], k[2] if len(k) > 2 else k[1]) for k in sort_keys
        ]
        self._batch_size = batch_size
        self._spill_threshold = spill_threshold
        self._sorted_rows: list[dict[str, Any]] | None = None
        self._merge_iter: Any = None
        self._spill_mgr: Any = None
        self._offset = 0

    # Arrow sort is faster for large batches but the dict->Table->dict
    # conversion overhead dominates for small batches.  Threshold tuned
    # to the crossover point measured on CPython 3.12 / pyarrow 18.
    _ARROW_SORT_THRESHOLD = 5000

    @staticmethod
    def _try_arrow_sort(
        rows: list[dict[str, Any]],
        sort_keys: list[tuple[str, bool, bool]],
    ) -> bool:
        """Attempt in-place Arrow-native sort.  Returns True on success."""
        if len(rows) < SortOp._ARROW_SORT_THRESHOLD:
            return False

        import pyarrow as pa
        import pyarrow.compute as pc

        # Arrow sort_indices uses a single global null_placement.
        # If different keys need different null placements, fall back.
        placements = {nf for _, _, nf in sort_keys}
        if len(placements) > 1:
            return False

        null_placement = "at_start" if placements.pop() else "at_end"

        try:
            table = pa.Table.from_pylist(rows)
        except (
            pa.ArrowInvalid,
            pa.ArrowTypeError,
            pa.ArrowNotImplementedError,
            KeyError,
            TypeError,
            ValueError,
        ):
            return False

        arrow_keys = []
        for col_name, desc, _ in sort_keys:
            if col_name not in table.column_names:
                return False
            arrow_keys.append((col_name, "descending" if desc else "ascending"))

        try:
            indices = pc.sort_indices(
                table, sort_keys=arrow_keys, null_placement=null_placement
            )
            sorted_table = table.take(indices)
            rows[:] = sorted_table.to_pylist()
        except (
            pa.ArrowInvalid,
            pa.ArrowTypeError,
            pa.ArrowNotImplementedError,
            KeyError,
            TypeError,
            ValueError,
        ):
            return False

        return True

    @staticmethod
    def _sort_rows(
        rows: list[dict[str, Any]],
        sort_keys: list[tuple[str, bool, bool]],
    ) -> None:
        if SortOp._try_arrow_sort(rows, sort_keys):
            return

        import functools

        def _cmp(a: dict[str, Any], b: dict[str, Any]) -> int:
            for col_name, desc, nulls_first in sort_keys:
                va = a.get(col_name)
                vb = b.get(col_name)
                a_null = va is None
                b_null = vb is None
                if a_null and b_null:
                    continue
                if a_null:
                    return -1 if nulls_first else 1
                if b_null:
                    return 1 if nulls_first else -1
                if va < vb:
                    return 1 if desc else -1
                if va > vb:
                    return -1 if desc else 1
            return 0

        rows.sort(key=functools.cmp_to_key(_cmp))

    def open(self) -> None:
        self._child.open()

        if self._spill_threshold <= 0:
            all_rows: list[dict[str, Any]] = []
            while True:
                self.check_cancelled()
                batch = self._child.next()
                if batch is None:
                    break
                all_rows.extend(batch.to_rows())
            self._child.close()
            self.check_cancelled()
            self._sort_rows(all_rows, self._sort_keys)
            self._sorted_rows = all_rows
            self._offset = 0
            return

        # External merge sort with disk spilling.
        from uqa.execution.spill import (
            SpillManager,
            SpillWriter,
            merge_sorted_runs,
            read_rows_from_ipc,
        )

        spill_mgr = SpillManager()
        self._spill_mgr = spill_mgr
        buffer: list[dict[str, Any]] = []
        run_paths: list[str] = []

        while True:
            self.check_cancelled()
            batch = self._child.next()
            if batch is None:
                break
            buffer.extend(batch.to_rows())
            if len(buffer) >= self._spill_threshold:
                self._sort_rows(buffer, self._sort_keys)
                path = spill_mgr.new_path()
                writer = SpillWriter(path)
                writer.write_rows(buffer)
                writer.close()
                run_paths.append(path)
                buffer.clear()
        self._child.close()

        if not run_paths:
            # Everything fit in memory.
            self._sort_rows(buffer, self._sort_keys)
            self._sorted_rows = buffer
            self._offset = 0
            return

        runs: list[Any] = [read_rows_from_ipc(p) for p in run_paths]
        if buffer:
            self._sort_rows(buffer, self._sort_keys)
            runs.append(iter(buffer))
        self._merge_iter = merge_sorted_runs(
            runs,
            cast("list[tuple[str, bool] | tuple[str, bool, bool]]", self._sort_keys),
        )

    def next(self) -> Batch | None:
        self.check_cancelled()
        if self._merge_iter is not None:
            rows: list[dict[str, Any]] = []
            for row in self._merge_iter:
                rows.append(row)
                if len(rows) >= self._batch_size:
                    break
            if not rows:
                return None
            return Batch.from_rows(rows)

        if self._sorted_rows is None:
            return None
        if self._offset >= len(self._sorted_rows):
            return None

        end = min(self._offset + self._batch_size, len(self._sorted_rows))
        batch_rows = self._sorted_rows[self._offset : end]
        self._offset = end
        return Batch.from_rows(batch_rows)

    def close(self) -> None:
        self._sorted_rows = None
        self._merge_iter = None
        self._offset = 0
        if self._spill_mgr is not None:
            self._spill_mgr.cleanup()
            self._spill_mgr = None


class LimitOp(PhysicalOperator):
    """Limit output to at most *limit* rows, optionally skipping *offset*.

    Streaming operator: skips the first *offset* rows, then passes
    through up to *limit* rows from the child.  Truncates the last
    batch if needed and stops pulling once the limit is reached.
    """

    def __init__(self, child: PhysicalOperator, limit: int, offset: int = 0) -> None:
        self._child = child
        self._limit = limit
        self._offset = offset
        self._skipped = 0
        self._emitted = 0

    def open(self) -> None:
        self._child.open()
        self._skipped = 0
        self._emitted = 0

    def next(self) -> Batch | None:
        if self._emitted >= self._limit:
            return None

        while True:
            batch = self._child.next()
            if batch is None:
                return None

            batch = batch.compact()

            # Skip rows for OFFSET
            if self._skipped < self._offset:
                need_to_skip = self._offset - self._skipped
                if batch.size <= need_to_skip:
                    self._skipped += batch.size
                    continue
                batch = batch.slice(need_to_skip, batch.size - need_to_skip)
                self._skipped = self._offset

            # Apply LIMIT
            remaining = self._limit - self._emitted
            if batch.size <= remaining:
                self._emitted += batch.size
                return batch

            self._emitted += remaining
            return batch.slice(0, remaining)

    def close(self) -> None:
        self._child.close()
        self._skipped = 0
        self._emitted = 0


class HashAggOp(PhysicalOperator):
    """Hash-based GROUP BY with aggregate functions.

    Blocking operator: materializes all input, groups by the specified
    columns, computes aggregates per group, and yields the result in
    batches.

    When *group_columns* is empty, the entire input is treated as a
    single group (aggregate-only query like ``SELECT COUNT(*) FROM t``).

    When *spill_threshold* > 0 and the input exceeds that many rows,
    rows are hash-partitioned into 16 on-disk partitions (Grace hash)
    and each partition is aggregated independently.
    """

    _NUM_PARTITIONS = 16

    def __init__(
        self,
        child: PhysicalOperator,
        group_columns: list[str],
        agg_specs: list[
            tuple[str, str, str | None] | tuple[str, str, str | None, bool, Any]
        ],
        batch_size: int = DEFAULT_BATCH_SIZE,
        spill_threshold: int = 0,
        group_aliases: dict[str, str] | None = None,
    ) -> None:
        self._child = child
        self._group_columns = group_columns
        self._agg_specs = agg_specs
        self._batch_size = batch_size
        self._spill_threshold = spill_threshold
        self._group_aliases = group_aliases or {}
        self._result_rows: list[dict[str, Any]] | None = None
        self._result_iter: Any = None
        self._spill_mgr: Any = None
        self._offset = 0
        self._filter_evaluator: Any = None

    # Aggregates that can be computed incrementally without
    # materializing all rows per group.
    _INCREMENTAL_AGGS = frozenset(
        {"count", "sum", "avg", "min", "max", "bool_and", "bool_or"}
    )

    def _can_stream(self) -> bool:
        """Return True if all agg specs can use incremental accumulators."""
        for spec in self._agg_specs:
            func_name = spec[1]
            distinct = spec[3] if len(spec) > 3 else False
            filter_node = spec[5] if len(spec) > 5 else None
            order_keys = spec[6] if len(spec) > 6 else None
            if func_name not in self._INCREMENTAL_AGGS:
                return False
            if distinct or filter_node is not None or order_keys:
                return False
        return True

    def _aggregate_rows(self, rows_iter: Any) -> list[dict[str, Any]]:
        if self._can_stream():
            return self._aggregate_rows_streaming(rows_iter)
        return self._aggregate_rows_materialized(rows_iter)

    def _aggregate_rows_streaming(self, rows_iter: Any) -> list[dict[str, Any]]:
        """Incremental aggregation without per-group row materialization."""
        # Per-group accumulators: {group_key: [(count, sum, min, max, bool_and, bool_or), ...]}
        # For each agg spec, maintain: (count_nonnull, total, min_val, max_val)
        n_aggs = len(self._agg_specs)
        # accumulators[key] = list of [count, total, min_val, max_val] per agg
        accumulators: dict[tuple, list[list[Any]]] = {}
        group_keys_order: list[tuple] = []

        for row in rows_iter:
            key = tuple(row.get(c) for c in self._group_columns)
            if key not in accumulators:
                accumulators[key] = [[0, 0.0, None, None] for _ in range(n_aggs)]
                group_keys_order.append(key)
            accs = accumulators[key]
            for i, spec in enumerate(self._agg_specs):
                func_name = spec[1]
                arg_col = spec[2]
                acc = accs[i]
                if func_name == "count" and arg_col is None:
                    acc[0] += 1
                    continue
                val = row.get(arg_col) if arg_col is not None else None
                if func_name == "count":
                    if val is not None:
                        acc[0] += 1
                elif func_name in ("sum", "avg"):
                    if isinstance(val, int | float):
                        acc[0] += 1
                        acc[1] += val
                elif func_name == "min":
                    if isinstance(val, int | float):
                        acc[0] += 1
                        if acc[2] is None or val < acc[2]:
                            acc[2] = val
                elif func_name == "max":
                    if isinstance(val, int | float):
                        acc[0] += 1
                        if acc[3] is None or val > acc[3]:
                            acc[3] = val
                elif func_name == "bool_and":
                    if val is not None:
                        acc[0] += 1
                        if acc[2] is None:
                            acc[2] = bool(val)
                        else:
                            acc[2] = acc[2] and bool(val)
                elif func_name == "bool_or" and val is not None:
                    acc[0] += 1
                    if acc[2] is None:
                        acc[2] = bool(val)
                    else:
                        acc[2] = acc[2] or bool(val)

        if not accumulators and not self._group_columns:
            accumulators[()] = [[0, 0.0, None, None] for _ in range(n_aggs)]
            group_keys_order.append(())

        result: list[dict[str, Any]] = []
        for key in group_keys_order:
            row_out: dict[str, Any] = {}
            for col, val in zip(self._group_columns, key):
                row_out[col] = val
                alias = self._group_aliases.get(col)
                if alias and alias != col:
                    row_out[alias] = val
            accs = accumulators[key]
            for i, spec in enumerate(self._agg_specs):
                alias_name = spec[0]
                func_name = spec[1]
                arg_col = spec[2]
                acc = accs[i]
                cnt = acc[0]
                if func_name == "count":
                    value: Any = cnt
                elif func_name == "sum":
                    value = acc[1] if cnt > 0 else None
                elif func_name == "avg":
                    value = acc[1] / cnt if cnt > 0 else None
                elif func_name == "min":
                    value = acc[2]
                elif func_name == "max":
                    value = acc[3]
                elif func_name in ("bool_and", "bool_or"):
                    value = acc[2]
                else:
                    value = None
                row_out[alias_name] = value
                natural = func_name if arg_col is None else f"{func_name}_{arg_col}"
                if natural != alias_name:
                    row_out[natural] = value
            result.append(row_out)
        return result

    def _aggregate_rows_materialized(self, rows_iter: Any) -> list[dict[str, Any]]:
        """Full-row materialization fallback for complex aggregates."""
        groups: dict[tuple, list[dict[str, Any]]] = {}
        for row in rows_iter:
            key = tuple(row.get(c) for c in self._group_columns)
            groups.setdefault(key, []).append(row)
        if not groups and not self._group_columns:
            groups[()] = []
        result: list[dict[str, Any]] = []
        for key, rows in groups.items():
            row_out: dict[str, Any] = {}
            for col, val in zip(self._group_columns, key):
                row_out[col] = val
                alias = self._group_aliases.get(col)
                if alias and alias != col:
                    row_out[alias] = val
            for spec in self._agg_specs:
                alias_name = spec[0]
                func_name = spec[1]
                arg_col = spec[2]
                distinct = spec[3] if len(spec) > 3 else False
                extra = spec[4] if len(spec) > 4 else None
                filter_node = spec[5] if len(spec) > 5 else None
                order_keys = spec[6] if len(spec) > 6 else None

                agg_rows = rows
                if filter_node is not None:
                    evaluator = self._filter_evaluator
                    agg_rows = [
                        r for r in agg_rows if evaluator.evaluate(filter_node, r)
                    ]
                if order_keys:
                    agg_rows = list(agg_rows)
                    for col, desc in reversed(order_keys):
                        agg_rows.sort(
                            key=lambda r, c=col: (r.get(c) is None, r.get(c)),
                            reverse=desc,
                        )

                value = _compute_aggregate(
                    func_name,
                    arg_col,
                    agg_rows,
                    distinct=distinct,
                    extra=extra,
                )
                row_out[alias_name] = value
                natural = func_name if arg_col is None else f"{func_name}_{arg_col}"
                if natural != alias_name:
                    row_out[natural] = value
            result.append(row_out)
        return result

    def open(self) -> None:
        self._child.open()

        # Create a shared ExprEvaluator for FILTER clauses (reused across groups).
        has_filter = any(
            len(spec) > 5 and spec[5] is not None for spec in self._agg_specs
        )
        if has_filter:
            from uqa.sql.expr_evaluator import ExprEvaluator

            self._filter_evaluator = ExprEvaluator()

        if self._spill_threshold <= 0:
            self._result_rows = self._aggregate_rows(self._drain_child())
            self._offset = 0
            return

        # Try in-memory first.
        buffer: list[dict[str, Any]] = []
        exceeded = False
        while True:
            batch = self._child.next()
            if batch is None:
                break
            buffer.extend(batch.to_rows())
            if len(buffer) >= self._spill_threshold:
                exceeded = True
                break

        if not exceeded:
            self._child.close()
            self._result_rows = self._aggregate_rows(iter(buffer))
            self._offset = 0
            return

        # Grace hash partitioning.
        from uqa.execution.spill import (
            SpillManager,
            SpillWriter,
            read_rows_from_ipc,
        )

        spill_mgr = SpillManager()
        self._spill_mgr = spill_mgr
        num_parts = self._NUM_PARTITIONS
        flush_size = max(1024, self._spill_threshold // num_parts)
        partition_paths = [spill_mgr.new_path() for _ in range(num_parts)]
        writers = [SpillWriter(p) for p in partition_paths]
        part_buffers: list[list[dict[str, Any]]] = [[] for _ in range(num_parts)]
        group_cols = self._group_columns

        def _partition_row(row: dict[str, Any]) -> None:
            key = tuple(row.get(c) for c in group_cols)
            h = hash(key) % num_parts
            part_buffers[h].append(row)
            if len(part_buffers[h]) >= flush_size:
                writers[h].write_rows(part_buffers[h])
                part_buffers[h].clear()

        for row in buffer:
            _partition_row(row)
        buffer.clear()

        while True:
            batch = self._child.next()
            if batch is None:
                break
            for row in batch.to_rows():
                _partition_row(row)
        self._child.close()

        active_paths: list[str] = []
        for h in range(num_parts):
            if part_buffers[h]:
                writers[h].write_rows(part_buffers[h])
                part_buffers[h].clear()
            writers[h].close()
            if writers[h].row_count > 0:
                active_paths.append(partition_paths[h])

        if not active_paths and not self._group_columns:
            self._result_rows = self._aggregate_rows(iter([]))
            self._offset = 0
            return

        def _process_partitions():
            for path in active_paths:
                yield from self._aggregate_rows(read_rows_from_ipc(path))

        self._result_iter = _process_partitions()

    def _drain_child(self) -> Any:
        while True:
            self.check_cancelled()
            batch = self._child.next()
            if batch is None:
                break
            yield from batch.to_rows()
        self._child.close()

    def next(self) -> Batch | None:
        self.check_cancelled()
        if self._result_iter is not None:
            rows: list[dict[str, Any]] = []
            for row in self._result_iter:
                rows.append(row)
                if len(rows) >= self._batch_size:
                    break
            if not rows:
                return None
            return Batch.from_rows(rows)

        if self._result_rows is None:
            return None
        if self._offset >= len(self._result_rows):
            return None

        end = min(self._offset + self._batch_size, len(self._result_rows))
        batch_rows = self._result_rows[self._offset : end]
        self._offset = end
        return Batch.from_rows(batch_rows)

    def close(self) -> None:
        self._result_rows = None
        self._result_iter = None
        self._filter_evaluator = None
        self._offset = 0
        if self._spill_mgr is not None:
            self._spill_mgr.cleanup()
            self._spill_mgr = None


class DistinctOp(PhysicalOperator):
    """Remove duplicate rows based on specified columns.

    Blocking operator: materializes all input to perform deduplication.

    When *spill_threshold* > 0 and the input exceeds that many rows,
    rows are hash-partitioned to disk and deduplicated per partition.
    """

    _NUM_PARTITIONS = 16

    def __init__(
        self,
        child: PhysicalOperator,
        columns: list[str],
        batch_size: int = DEFAULT_BATCH_SIZE,
        spill_threshold: int = 0,
    ) -> None:
        self._child = child
        self._columns = columns
        self._batch_size = batch_size
        self._spill_threshold = spill_threshold
        self._unique_rows: list[dict[str, Any]] | None = None
        self._result_iter: Any = None
        self._spill_mgr: Any = None
        self._offset = 0

    @staticmethod
    def _dedup(
        rows_iter: Any,
        columns: list[str],
    ) -> list[dict[str, Any]]:
        seen: set[tuple] = set()
        unique: list[dict[str, Any]] = []
        for row in rows_iter:
            key = tuple(row.get(c) for c in columns)
            if key not in seen:
                seen.add(key)
                unique.append(row)
        return unique

    def open(self) -> None:
        self._child.open()

        if self._spill_threshold <= 0:
            all_rows: list[dict[str, Any]] = []
            while True:
                self.check_cancelled()
                batch = self._child.next()
                if batch is None:
                    break
                all_rows.extend(batch.to_rows())
            self._child.close()
            self._unique_rows = self._dedup(all_rows, self._columns)
            self._offset = 0
            return

        # Try in-memory first.
        buffer: list[dict[str, Any]] = []
        exceeded = False
        while True:
            batch = self._child.next()
            if batch is None:
                break
            buffer.extend(batch.to_rows())
            if len(buffer) >= self._spill_threshold:
                exceeded = True
                break

        if not exceeded:
            self._child.close()
            self._unique_rows = self._dedup(buffer, self._columns)
            self._offset = 0
            return

        # Hash partition dedup.
        from uqa.execution.spill import (
            SpillManager,
            SpillWriter,
            read_rows_from_ipc,
        )

        spill_mgr = SpillManager()
        self._spill_mgr = spill_mgr
        num_parts = self._NUM_PARTITIONS
        flush_size = max(1024, self._spill_threshold // num_parts)
        partition_paths = [spill_mgr.new_path() for _ in range(num_parts)]
        writers = [SpillWriter(p) for p in partition_paths]
        part_buffers: list[list[dict[str, Any]]] = [[] for _ in range(num_parts)]
        columns = self._columns

        def _partition_row(row: dict[str, Any]) -> None:
            key = tuple(row.get(c) for c in columns)
            h = hash(key) % num_parts
            part_buffers[h].append(row)
            if len(part_buffers[h]) >= flush_size:
                writers[h].write_rows(part_buffers[h])
                part_buffers[h].clear()

        for row in buffer:
            _partition_row(row)
        buffer.clear()

        while True:
            batch = self._child.next()
            if batch is None:
                break
            for row in batch.to_rows():
                _partition_row(row)
        self._child.close()

        active_paths: list[str] = []
        for h in range(num_parts):
            if part_buffers[h]:
                writers[h].write_rows(part_buffers[h])
                part_buffers[h].clear()
            writers[h].close()
            if writers[h].row_count > 0:
                active_paths.append(partition_paths[h])

        def _dedup_partitions():
            for path in active_paths:
                yield from self._dedup(read_rows_from_ipc(path), columns)

        self._result_iter = _dedup_partitions()

    def next(self) -> Batch | None:
        if self._result_iter is not None:
            rows: list[dict[str, Any]] = []
            for row in self._result_iter:
                rows.append(row)
                if len(rows) >= self._batch_size:
                    break
            if not rows:
                return None
            return Batch.from_rows(rows)

        if self._unique_rows is None:
            return None
        if self._offset >= len(self._unique_rows):
            return None

        end = min(self._offset + self._batch_size, len(self._unique_rows))
        batch_rows = self._unique_rows[self._offset : end]
        self._offset = end
        return Batch.from_rows(batch_rows)

    def close(self) -> None:
        self._unique_rows = None
        self._result_iter = None
        self._offset = 0
        if self._spill_mgr is not None:
            self._spill_mgr.cleanup()
            self._spill_mgr = None


class WindowOp(PhysicalOperator):
    """Evaluate window functions over partitioned, ordered rows.

    Blocking operator: materializes all input, partitions by the
    specified columns, sorts each partition by the order keys, then
    evaluates window functions (ROW_NUMBER, RANK, DENSE_RANK, NTILE,
    LAG, LEAD, FIRST_VALUE, LAST_VALUE, SUM/COUNT/AVG/MIN/MAX OVER).
    """

    def __init__(
        self,
        child: PhysicalOperator,
        window_specs: list[WindowSpec],
        batch_size: int = DEFAULT_BATCH_SIZE,
        spill_threshold: int = 0,
    ) -> None:
        self._child = child
        self._window_specs = window_specs
        self._batch_size = batch_size
        self._spill_threshold = spill_threshold
        self._result_rows: list[dict[str, Any]] | None = None
        self._offset = 0

    def open(self) -> None:
        self._child.open()

        all_rows: list[dict[str, Any]] = []
        while True:
            self.check_cancelled()
            batch = self._child.next()
            if batch is None:
                break
            all_rows.extend(batch.to_rows())
        self._child.close()

        for spec in self._window_specs:
            # Sort by partition keys + order keys
            sorted_rows = list(all_rows)
            for col, desc in reversed(spec.order_keys):
                sorted_rows.sort(
                    key=lambda r, c=col: (r.get(c) is None, r.get(c)),
                    reverse=desc,
                )
            if spec.partition_cols:
                sorted_rows.sort(
                    key=lambda r: tuple(r.get(c) for c in spec.partition_cols)
                )

            # Build a mapping from original row identity to sorted index
            # We use id() to track row objects
            row_id_to_sorted_idx: dict[int, int] = {}
            for idx, row in enumerate(sorted_rows):
                row_id_to_sorted_idx[id(row)] = idx

            # Partition the sorted rows
            partitions: list[list[int]] = []
            current_key: tuple | None = None
            for idx, row in enumerate(sorted_rows):
                key = tuple(row.get(c) for c in spec.partition_cols)
                if key != current_key:
                    partitions.append([])
                    current_key = key
                partitions[-1].append(idx)

            # Compute window values for sorted rows
            win_values: dict[int, Any] = {}
            for part_indices in partitions:
                part_rows = [sorted_rows[i] for i in part_indices]
                values = _compute_window_function(spec, part_rows)
                for i, idx in enumerate(part_indices):
                    win_values[idx] = values[i]

            # Apply computed values back to original rows
            for row in all_rows:
                sorted_idx = row_id_to_sorted_idx[id(row)]
                row[spec.alias] = win_values[sorted_idx]

        self._result_rows = all_rows
        self._offset = 0

    def next(self) -> Batch | None:
        if self._result_rows is None:
            return None
        if self._offset >= len(self._result_rows):
            return None

        end = min(self._offset + self._batch_size, len(self._result_rows))
        batch_rows = self._result_rows[self._offset : end]
        self._offset = end
        return Batch.from_rows(batch_rows)

    def close(self) -> None:
        self._result_rows = None
        self._offset = 0


def _compute_window_function(
    spec: WindowSpec,
    partition_rows: list[dict[str, Any]],
) -> list[Any]:
    """Compute a window function over an ordered partition.

    Returns a list of values, one per row in the partition.
    """
    func_name = spec.func_name
    n = len(partition_rows)

    if func_name == "row_number":
        return list(range(1, n + 1))

    if func_name == "rank":
        order_cols = [c for c, _ in spec.order_keys]
        ranks: list[int] = []
        for i in range(n):
            if i == 0:
                ranks.append(1)
            else:
                prev = partition_rows[i - 1]
                cur = partition_rows[i]
                if _rows_equal_on_columns(prev, cur, order_cols):
                    ranks.append(ranks[-1])
                else:
                    ranks.append(i + 1)
        return ranks

    if func_name == "dense_rank":
        order_cols = [c for c, _ in spec.order_keys]
        ranks = []
        current_rank = 0
        for i in range(n):
            if i == 0:
                current_rank = 1
            else:
                prev = partition_rows[i - 1]
                cur = partition_rows[i]
                if not _rows_equal_on_columns(prev, cur, order_cols):
                    current_rank += 1
            ranks.append(current_rank)
        return ranks

    if func_name == "ntile":
        buckets: list[int] = []
        for i in range(n):
            bucket = (i * spec.ntile_buckets) // n + 1
            buckets.append(bucket)
        return buckets

    if func_name == "lag":
        assert spec.arg_col is not None
        lag_values: list[Any] = []
        for i in range(n):
            if i - spec.offset >= 0:
                lag_values.append(partition_rows[i - spec.offset].get(spec.arg_col))
            else:
                lag_values.append(spec.default_value)
        return lag_values

    if func_name == "lead":
        assert spec.arg_col is not None
        lead_values: list[Any] = []
        for i in range(n):
            if i + spec.offset < n:
                lead_values.append(partition_rows[i + spec.offset].get(spec.arg_col))
            else:
                lead_values.append(spec.default_value)
        return lead_values

    if func_name == "percent_rank":
        if n <= 1:
            return [0.0] * n
        order_cols = [c for c, _ in spec.order_keys]
        ranks: list[int] = []
        for i in range(n):
            if i == 0:
                ranks.append(1)
            else:
                prev = partition_rows[i - 1]
                cur = partition_rows[i]
                if _rows_equal_on_columns(prev, cur, order_cols):
                    ranks.append(ranks[-1])
                else:
                    ranks.append(i + 1)
        return [(r - 1) / (n - 1) for r in ranks]

    if func_name == "cume_dist":
        if n == 0:
            return []
        order_cols = [c for c, _ in spec.order_keys]
        # Single linear pass: identify peer group boundaries, then fill.
        cume_values: list[float] = [0.0] * n
        i = 0
        while i < n:
            # Find end of peer group starting at i.
            j = i + 1
            while j < n and _rows_equal_on_columns(
                partition_rows[i], partition_rows[j], order_cols
            ):
                j += 1
            # All rows in [i, j) get cume_dist = j / n.
            val = j / n
            for k in range(i, j):
                cume_values[k] = val
            i = j
        return cume_values

    if func_name == "nth_value":
        assert spec.arg_col is not None
        # ntile_buckets is reused to store the N parameter
        nth = spec.ntile_buckets
        if n == 0 or nth < 1 or nth > n:
            return [None] * n
        val = partition_rows[nth - 1].get(spec.arg_col)
        return [val] * n

    if func_name == "first_value":
        assert spec.arg_col is not None
        if n == 0:
            return []
        val = partition_rows[0].get(spec.arg_col)
        return [val] * n

    if func_name == "last_value":
        assert spec.arg_col is not None
        if n == 0:
            return []
        val = partition_rows[-1].get(spec.arg_col)
        return [val] * n

    # Aggregate window functions (SUM, COUNT, AVG, MIN, MAX, STRING_AGG, etc.)
    if func_name in (
        "sum",
        "count",
        "avg",
        "min",
        "max",
        "string_agg",
        "array_agg",
        "bool_and",
        "bool_or",
    ):
        # Apply FILTER (WHERE ...) if present
        filtered_rows = partition_rows
        if spec.filter_node is not None:
            from uqa.sql.expr_evaluator import ExprEvaluator

            evaluator = ExprEvaluator()
            filtered_rows = [
                r for r in partition_rows if evaluator.evaluate(spec.filter_node, r)
            ]
        # Check for explicit frame specification
        if spec.frame_start is not None:
            return _compute_framed_aggregate(
                func_name, spec.arg_col, filtered_rows, spec
            )
        # SQL standard: when ORDER BY is present without an explicit frame,
        # the default is RANGE BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW.
        if spec.order_keys:
            default_spec = WindowSpec(
                alias=spec.alias,
                func_name=spec.func_name,
                partition_cols=spec.partition_cols,
                order_keys=spec.order_keys,
                arg_col=spec.arg_col,
                frame_start="unbounded_preceding",
                frame_end="current_row",
                frame_type="rows",
                filter_node=spec.filter_node,
            )
            return _compute_framed_aggregate(
                func_name, spec.arg_col, filtered_rows, default_spec
            )
        agg_val = _compute_aggregate(func_name, spec.arg_col, filtered_rows)
        return [agg_val] * n

    raise ValueError(f"Unknown window function: {func_name}")


def _compute_framed_aggregate(
    func_name: str,
    arg_col: str | None,
    partition_rows: list[dict[str, Any]],
    spec: WindowSpec,
) -> list[Any]:
    """Compute aggregate over a per-row window frame."""
    n = len(partition_rows)
    results: list[Any] = []

    if spec.frame_type == "range" and spec.order_keys:
        # RANGE frame: "current_row" means all peers (same ORDER BY value)
        order_col = spec.order_keys[0][0]
        # Pre-compute order values once for the entire partition.
        pre_order_vals = [partition_rows[i].get(order_col) for i in range(n)]
        pre_non_null_vals = [v for v in pre_order_vals if v is not None]
        pre_non_null_indices = [
            i for i, v in enumerate(pre_order_vals) if v is not None
        ]
        for i in range(n):
            start = _resolve_range_frame_index(
                i,
                n,
                partition_rows,
                order_col,
                spec.frame_start,
                spec.frame_start_offset,
                is_start=True,
                precomputed_order_vals=pre_order_vals,
                precomputed_non_null_vals=pre_non_null_vals,
                precomputed_non_null_indices=pre_non_null_indices,
            )
            end = _resolve_range_frame_index(
                i,
                n,
                partition_rows,
                order_col,
                spec.frame_end,
                spec.frame_end_offset,
                is_start=False,
                precomputed_order_vals=pre_order_vals,
                precomputed_non_null_vals=pre_non_null_vals,
                precomputed_non_null_indices=pre_non_null_indices,
            )
            frame_rows = partition_rows[start : end + 1]
            results.append(_compute_aggregate(func_name, arg_col, frame_rows))
        return results

    for i in range(n):
        start = _resolve_frame_index(i, n, spec.frame_start, spec.frame_start_offset)
        end = _resolve_frame_index(i, n, spec.frame_end, spec.frame_end_offset)
        frame_rows = partition_rows[start : end + 1]
        results.append(_compute_aggregate(func_name, arg_col, frame_rows))
    return results


def _resolve_frame_index(current: int, n: int, bound: str | None, offset: int) -> int:
    """Resolve a frame bound to a concrete row index."""
    if bound is None or bound == "unbounded_preceding":
        return 0
    if bound == "unbounded_following":
        return n - 1
    if bound == "current_row":
        return current
    if bound == "offset_preceding":
        return max(0, current - offset)
    if bound == "offset_following":
        return min(n - 1, current + offset)
    return current


def _resolve_range_frame_index(
    current: int,
    n: int,
    rows: list[dict[str, Any]],
    order_col: str,
    bound: str | None,
    offset: int,
    *,
    is_start: bool,
    precomputed_order_vals: list[Any] | None = None,
    precomputed_non_null_vals: list[Any] | None = None,
    precomputed_non_null_indices: list[int] | None = None,
) -> int:
    """Resolve a RANGE frame bound using ORDER BY values.

    In RANGE mode, "current_row" means the first/last peer (rows with
    the same ORDER BY value), not the physical current row.

    For offset bounds (PRECEDING/FOLLOWING), uses bisect for O(log n)
    lookup instead of linear scan.
    """
    from bisect import bisect_left, bisect_right

    if bound is None or bound == "unbounded_preceding":
        return 0
    if bound == "unbounded_following":
        return n - 1
    if bound == "current_row":
        order_vals = precomputed_order_vals
        if order_vals is None:
            order_vals = [rows[i].get(order_col) for i in range(n)]
        cur_val = order_vals[current]
        if is_start:
            idx = current
            while idx > 0 and order_vals[idx - 1] == cur_val:
                idx -= 1
            return idx
        else:
            idx = current
            while idx < n - 1 and order_vals[idx + 1] == cur_val:
                idx += 1
            return idx
    if bound in ("offset_preceding", "offset_following"):
        order_vals = precomputed_order_vals
        if order_vals is None:
            order_vals = [rows[i].get(order_col) for i in range(n)]
        non_null_vals = precomputed_non_null_vals
        non_null_indices = precomputed_non_null_indices
        if non_null_vals is None:
            non_null_vals = [v for v in order_vals if v is not None]
            non_null_indices = [i for i, v in enumerate(order_vals) if v is not None]
        assert non_null_indices is not None
        cur_val = order_vals[current]
        if cur_val is None:
            if bound == "offset_preceding":
                return 0 if is_start else current
            else:
                return current if is_start else n - 1
        target = cur_val - offset if bound == "offset_preceding" else cur_val + offset
        if not non_null_vals:
            if bound == "offset_preceding":
                return 0 if is_start else -1
            else:
                return n if is_start else -1
        if is_start:
            pos = bisect_left(non_null_vals, target)
            return non_null_indices[pos] if pos < len(non_null_indices) else n
        else:
            pos = bisect_right(non_null_vals, target)
            return non_null_indices[pos - 1] if pos > 0 else -1
    return current


def _rows_equal_on_columns(
    a: dict[str, Any],
    b: dict[str, Any],
    columns: list[str],
) -> bool:
    """Check if two rows have equal values on the given columns."""
    return all(a.get(c) == b.get(c) for c in columns)


def _compute_aggregate(
    func_name: str,
    arg_col: str | None,
    rows: list[dict[str, Any]],
    distinct: bool = False,
    extra: Any = None,
) -> Any:
    """Compute a single aggregate value over a group of rows."""
    if callable(extra):
        return extra(rows)

    if func_name == "count":
        if arg_col is None:
            return len(rows)
        if distinct:
            return len({r.get(arg_col) for r in rows if r.get(arg_col) is not None})
        return sum(1 for r in rows if r.get(arg_col) is not None)

    # All remaining aggregates require a non-None arg_col.
    assert arg_col is not None

    if func_name == "string_agg":
        delimiter = extra if extra is not None else ","
        vals = [str(r.get(arg_col)) for r in rows if r.get(arg_col) is not None]
        if distinct:
            seen: set[str] = set()
            deduped: list[str] = []
            for v in vals:
                if v not in seen:
                    seen.add(v)
                    deduped.append(v)
            vals = deduped
        return str(delimiter).join(vals) if vals else None

    if func_name == "array_agg":
        vals = [r.get(arg_col) for r in rows if r.get(arg_col) is not None]
        if distinct:
            seen_vals: list = []
            seen_set: set = set()
            for v in vals:
                key = repr(v)
                if key not in seen_set:
                    seen_set.add(key)
                    seen_vals.append(v)
            vals = seen_vals
        return vals if vals else None

    if func_name == "bool_and":
        vals = [r.get(arg_col) for r in rows if r.get(arg_col) is not None]
        if not vals:
            return None
        return all(bool(v) for v in vals)

    if func_name == "bool_or":
        vals = [r.get(arg_col) for r in rows if r.get(arg_col) is not None]
        if not vals:
            return None
        return any(bool(v) for v in vals)

    if func_name in ("json_object_agg", "jsonb_object_agg"):
        # extra holds the value column name
        val_col = extra
        result: dict = {}
        for r in rows:
            k = r.get(arg_col)
            if k is None:
                continue
            result[str(k)] = r.get(val_col)
        return result if result else None

    if func_name == "mode":
        # arg_col comes from WITHIN GROUP (ORDER BY col)
        vals = [r.get(arg_col) for r in rows if r.get(arg_col) is not None]
        if not vals:
            return None
        from collections import Counter

        return Counter(vals).most_common(1)[0][0]

    values: list[Any] = [
        v for r in rows if isinstance((v := r.get(arg_col)), int | float)
    ]
    if not values:
        return None
    if func_name == "sum":
        return sum(values)
    if func_name == "avg":
        return sum(values) / len(values)
    if func_name == "min":
        return min(values)
    if func_name == "max":
        return max(values)

    if func_name in ("stddev", "stddev_samp"):
        if len(values) < 2:
            return None
        mean = sum(values) / len(values)
        variance = sum((v - mean) ** 2 for v in values) / (len(values) - 1)
        return variance**0.5
    if func_name == "stddev_pop":
        mean = sum(values) / len(values)
        variance = sum((v - mean) ** 2 for v in values) / len(values)
        return variance**0.5
    if func_name in ("variance", "var_samp"):
        if len(values) < 2:
            return None
        mean = sum(values) / len(values)
        return sum((v - mean) ** 2 for v in values) / (len(values) - 1)
    if func_name == "var_pop":
        mean = sum(values) / len(values)
        return sum((v - mean) ** 2 for v in values) / len(values)

    if func_name == "percentile_cont":
        fraction = float(extra)
        sorted_vals = sorted(values)
        n = len(sorted_vals)
        pos = fraction * (n - 1)
        lo = int(pos)
        hi = min(lo + 1, n - 1)
        frac = pos - lo
        return sorted_vals[lo] + frac * (sorted_vals[hi] - sorted_vals[lo])
    if func_name == "percentile_disc":
        fraction = float(extra)
        sorted_vals = sorted(values)
        n = len(sorted_vals)
        idx = int(fraction * (n - 1))
        return sorted_vals[idx]

    # -- Two-argument statistical aggregates (corr, covar, regr) --------
    # These require both arg_col (y) and extra (x column name).
    if func_name in (
        "covar_pop",
        "covar_samp",
        "corr",
        "regr_count",
        "regr_avgx",
        "regr_avgy",
        "regr_sxx",
        "regr_syy",
        "regr_sxy",
        "regr_slope",
        "regr_intercept",
        "regr_r2",
    ):
        x_col = extra
        # Collect paired (y, x) where both are non-null numeric values
        pairs: list[tuple[Any, Any]] = []
        for r in rows:
            y_val = r.get(arg_col)
            x_val = r.get(x_col)
            if isinstance(y_val, int | float) and isinstance(x_val, int | float):
                pairs.append((y_val, x_val))
        n = len(pairs)
        if n == 0:
            return None

        if func_name == "regr_count":
            return n

        ys = [p[0] for p in pairs]
        xs = [p[1] for p in pairs]
        mean_y = sum(ys) / n
        mean_x = sum(xs) / n

        if func_name == "regr_avgx":
            return mean_x
        if func_name == "regr_avgy":
            return mean_y

        sxy = sum((yi - mean_y) * (xi - mean_x) for yi, xi in pairs)
        sxx = sum((xi - mean_x) ** 2 for xi in xs)
        syy = sum((yi - mean_y) ** 2 for yi in ys)

        if func_name == "covar_pop":
            return sxy / n
        if func_name == "covar_samp":
            if n < 2:
                return None
            return sxy / (n - 1)

        if func_name == "regr_sxy":
            return sxy
        if func_name == "regr_sxx":
            return sxx
        if func_name == "regr_syy":
            return syy

        if func_name == "regr_slope":
            if sxx == 0:
                return None
            return sxy / sxx
        if func_name == "regr_intercept":
            if sxx == 0:
                return None
            slope = sxy / sxx
            return mean_y - slope * mean_x

        if func_name == "corr":
            stddev_y = syy**0.5
            stddev_x = sxx**0.5
            if stddev_y == 0 or stddev_x == 0:
                return None
            return sxy / (stddev_y * stddev_x)

        if func_name == "regr_r2":
            if sxx == 0 or syy == 0:
                return None
            return (sxy**2) / (sxx * syy)

    raise ValueError(f"Unknown aggregate: {func_name}")
