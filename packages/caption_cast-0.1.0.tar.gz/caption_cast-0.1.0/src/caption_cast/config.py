# Filepath: caption_cast/config.py
# Condensed Description: Pydantic v2 configuration model for caption rendering
# Architecture Layer: Core
# Environment: Both
# Script Hierarchy: CaptionConfig, default_config_for_style
# Dependencies: Internal: none; External: pydantic>=2; Providers: none
# Exposes: CaptionConfig, default_config_for_style
# Configuration: None
from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict


class CaptionConfig(BaseModel):
    """All rendering parameters for a caption style application."""

    model_config = ConfigDict(extra="forbid")

    style: str
    font_family: str | None = None
    font_size: int | None = None
    font_weight: Literal["regular", "medium", "bold", "black"] | None = None
    position: Literal["top", "center", "bottom", "lower_third", "custom"] = "bottom"
    position_custom: tuple[int, int] | None = None
    safe_area_padding: int = 80
    vertical_safe_zone: Literal["minimal", "standard", "max"] = "standard"
    color: str | None = None
    highlight_color: str | None = None
    background_color: str | None = None
    background_opacity: float = 0.7
    stroke_color: str | None = None
    stroke_width: int | None = None
    in_animation: str | None = None
    out_animation: str | None = None
    word_interval: float = 0.0
    max_words_per_line: int = 6
    max_chars_per_line: int = 42
    emphasis_words: list[str] = []
    emoji_position: Literal["inline", "end", "above"] = "inline"
    burn_in: bool = True


def default_config_for_style(style_slug: str) -> CaptionConfig:
    """Return a CaptionConfig with package defaults for the given style slug.

    Args:
        style_slug: The caption style identifier.

    Returns:
        A CaptionConfig populated with defaults only.
    """
    return CaptionConfig(style=style_slug)
