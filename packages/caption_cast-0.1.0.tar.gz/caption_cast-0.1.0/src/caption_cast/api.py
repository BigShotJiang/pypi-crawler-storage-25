# Filepath: caption_cast/api.py
# Condensed Description: Public API surface for caption-cast: apply_caption, burn_lyrics, burn_subtitles, beat_synced_captions
# Architecture Layer: API
# Environment: Both
# Script Hierarchy: apply_caption, burn_lyrics, burn_subtitles, beat_synced_captions, list_styles, get_style_info
# Dependencies: Internal: caption_cast.config, caption_cast.exceptions, caption_cast.styles.recipes, caption_cast.styles.loader; External: text_fx; Providers: none
# Exposes: apply_caption, burn_lyrics, burn_subtitles, beat_synced_captions, list_styles, get_style_info
# Configuration: None
from __future__ import annotations

import logging
import tempfile
from pathlib import Path

from caption_cast.config import CaptionConfig, default_config_for_style
from caption_cast.exceptions import CompositionError

_log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _default_output(video: Path, suffix: str = "_captioned") -> Path:
    """Derive a default output path from the input video path."""
    return video.parent / f"{video.stem}{suffix}{video.suffix}"


def _tmp_path(suffix: str = ".mp4") -> Path:
    """Return a path to a fresh temporary file."""
    fd, path = tempfile.mkstemp(suffix=suffix)
    import os  # noqa: PLC0415

    os.close(fd)
    return Path(path)


def _resolve_canvas_size(video_path: Path) -> tuple[int, int]:
    """Return (width, height) for the given video using text-fx helpers if available."""
    try:
        from text_fx.video_utils import video_height, video_width  # noqa: PLC0415

        return (video_width(str(video_path)), video_height(str(video_path)))
    except Exception:
        # Graceful fallback for environments where text-fx is not fully installed
        return (1920, 1080)


def _apply_single_effect(
    video_path: Path,
    text: str,
    effect: str,
    start_time: float,
    duration: float,
    config: CaptionConfig,
    recipe: dict,
    output_path: Path,
) -> Path:
    """Call text_fx.apply_text_effect with parameters derived from config + recipe.

    Args:
        video_path: Source video path.
        text: Caption text.
        effect: text-fx effect slug.
        start_time: Start time in seconds.
        duration: Duration in seconds.
        config: Active CaptionConfig.
        recipe: Style recipe dict.
        output_path: Desired output path.

    Returns:
        Path to the rendered output video.

    Raises:
        CompositionError: If text_fx raises an exception during rendering.
    """
    import text_fx  # noqa: PLC0415

    color = config.color or recipe.get("default_color", "#FFFFFF")
    font_size = config.font_size or recipe.get("default_font_size", 72)
    stroke = recipe.get("default_stroke") or {}
    stroke_color = config.stroke_color or stroke.get("color")
    stroke_width = (
        config.stroke_width if config.stroke_width is not None else stroke.get("width", 0)
    )

    try:
        text_fx.apply_text_effect(
            video=str(video_path),
            text=text,
            effect=effect,
            output=str(output_path),
            duration=max(0.1, duration),
            start_time=start_time,
            color=color,
            font_size=font_size,
            stroke_color=stroke_color,
            stroke_width=stroke_width,
        )
    except Exception as exc:
        raise CompositionError(
            f"text-fx failed for effect={effect!r}, text={text!r}: {exc}"
        ) from exc

    return output_path


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def apply_caption(
    video: str | Path,
    text: str,
    style: str,
    start_time: float = 0.0,
    duration: float = 2.0,
    output: str | Path | None = None,
    **kwargs: object,
) -> Path:
    """Apply a single caption to a video at a specific time.

    Extra keyword arguments are forwarded to :class:`CaptionConfig` so callers
    can override individual rendering parameters (e.g. ``color="#FF0000"``).

    Args:
        video: Path to the source video file.
        text: Caption text to display.
        style: Caption style slug, e.g. ``"pop_caption"``.
        start_time: Caption start time in seconds.
        duration: Caption display duration in seconds.
        output: Output file path; derived from *video* if omitted.
        **kwargs: Additional CaptionConfig fields to override.

    Returns:
        Path to the output video file.

    Raises:
        UnknownStyleError: If *style* is not a known caption style.
        CompositionError: If the underlying text-fx composition fails.
    """
    from caption_cast.styles.recipes import get_recipe  # noqa: PLC0415

    video = Path(video)
    out = Path(output) if output else _default_output(video)

    recipe = get_recipe(style)
    cfg = CaptionConfig(style=style, **kwargs)

    split_mode = recipe.get("split_mode", "all")

    if split_mode == "word":
        # For a bare apply_caption call with no word-level timing, fall back to line mode
        _log.debug("apply_caption: split_mode=word but no word timings; treating as line")
        effect = recipe.get("per_line_animation") or recipe.get("per_word_animation") or "fade_in"
        return _apply_single_effect(video, text, effect, start_time, duration, cfg, recipe, out)

    effect = recipe.get("per_line_animation") or "fade_in"
    return _apply_single_effect(video, text, effect, start_time, duration, cfg, recipe, out)


def burn_lyrics(
    video: str | Path,
    audio: str | Path,
    lyrics: object,
    style: str = "karaoke_highlight",
    output: str | Path | None = None,
    config: CaptionConfig | None = None,
) -> Path:
    """Burn karaoke/lyric captions onto a video file.

    *lyrics* may be:
    - a path (str or Path) to a ``.srt``, ``.vtt``, or ``.lrc`` file
    - a ``list[dict]`` with keys ``text``, ``start``, ``end``, and optionally ``words``
    - a ``lyric_sync.LyricSync`` object (duck-typed: must expose an ``as_list()`` method)

    Args:
        video: Path to the source video file.
        audio: Path to the audio file (used by word-aligning styles).
        lyrics: Lyric/subtitle data in any supported form.
        style: Caption style slug.
        output: Output file path; derived from *video* if omitted.
        config: Optional CaptionConfig; defaults are applied for the style if omitted.

    Returns:
        Path to the output video file.

    Raises:
        UnknownStyleError: If *style* is not recognised.
        CompositionError: If composition fails.
    """
    from caption_cast.lyrics.normalize import TimedLine, lines_from_dicts  # noqa: PLC0415
    from caption_cast.styles.recipes import get_recipe  # noqa: PLC0415

    video = Path(video)
    out = Path(output) if output else _default_output(video)
    cfg = config or default_config_for_style(style)
    recipe = get_recipe(style)

    # Resolve lyrics to list[TimedLine]
    timed_lines: list[TimedLine]
    if isinstance(lyrics, (str, Path)):
        from caption_cast.lyrics.parser import parse_file  # noqa: PLC0415

        timed_lines = parse_file(Path(lyrics))
    elif isinstance(lyrics, list):
        timed_lines = lines_from_dicts(lyrics)
    elif hasattr(lyrics, "as_list"):
        timed_lines = lines_from_dicts(lyrics.as_list())
    else:
        raise TypeError(
            f"lyrics must be a path, list of dicts, or a lyric_sync object; got {type(lyrics)}"
        )

    split_mode = recipe.get("split_mode", "line")
    canvas_size = _resolve_canvas_size(video)

    if split_mode == "word":
        from caption_cast.styles.karaoke import render_karaoke  # noqa: PLC0415

        current_video = video
        for idx, line in enumerate(timed_lines):
            words = line.words
            if not words:
                _log.warning(f"No word-level timing for line {idx}; skipping word-split")
                continue
            line_out = out.parent / f"_lyr_{idx:04d}.mp4"
            render_karaoke(
                video_path=current_video,
                words=words,
                config=cfg,
                canvas_size=canvas_size,
                output_path=line_out,
            )
            current_video = line_out

        import shutil  # noqa: PLC0415

        shutil.copy2(str(current_video), str(out))
        return out

    # Line-level or all: use subtitle burn-in
    from caption_cast.styles.subtitle import render_subtitle_burn_in  # noqa: PLC0415

    return render_subtitle_burn_in(
        video_path=video,
        timed_lines=timed_lines,
        config=cfg,
        output_path=out,
    )


def burn_subtitles(
    video: str | Path,
    subtitles: str | Path,
    style: str = "subtitle_burn_in",
    output: str | Path | None = None,
    config: CaptionConfig | None = None,
) -> Path:
    """Burn subtitles from a ``.srt``, ``.vtt``, or ``.lrc`` file onto a video.

    Args:
        video: Path to the source video file.
        subtitles: Path to the subtitle file.
        style: Caption style slug.
        output: Output file path; derived from *video* if omitted.
        config: Optional CaptionConfig; style defaults applied if omitted.

    Returns:
        Path to the output video file.

    Raises:
        UnknownStyleError: If *style* is not recognised.
        CompositionError: If composition fails.
    """
    from caption_cast.lyrics.parser import parse_file  # noqa: PLC0415
    from caption_cast.styles.recipes import get_recipe  # noqa: PLC0415

    video = Path(video)
    out = Path(output) if output else _default_output(video)
    cfg = config or default_config_for_style(style)
    recipe = get_recipe(style)  # validates style slug early

    timed_lines = parse_file(Path(subtitles))

    effect = recipe.get("per_line_animation") or "fade_in"
    current_video = video

    import text_fx  # noqa: PLC0415

    for idx, line in enumerate(timed_lines):
        if not line.text.strip():
            continue
        ln_out = out.parent / f"_srt_{idx:04d}.mp4"
        color = cfg.color or recipe.get("default_color", "#FFFFFF")
        font_size = cfg.font_size or recipe.get("default_font_size", 56)
        stroke = recipe.get("default_stroke") or {}
        stroke_color = cfg.stroke_color or stroke.get("color")
        stroke_width = cfg.stroke_width if cfg.stroke_width is not None else stroke.get("width", 0)

        try:
            text_fx.apply_text_effect(
                video=str(current_video),
                text=line.text,
                effect=effect,
                output=str(ln_out),
                duration=max(0.1, line.end - line.start),
                start_time=line.start,
                color=color,
                font_size=font_size,
                stroke_color=stroke_color,
                stroke_width=stroke_width,
            )
        except Exception as exc:
            raise CompositionError(f"Subtitle burn-in failed at line {idx}: {exc}") from exc

        current_video = ln_out

    import shutil  # noqa: PLC0415

    shutil.copy2(str(current_video), str(out))
    return out


def beat_synced_captions(
    video: str | Path,
    audio: str | Path,
    text_lines: list[str],
    style: str = "lyric_bounce",
    output: str | Path | None = None,
    bpm_hint: float | None = None,
    config: CaptionConfig | None = None,
) -> Path:
    """Synchronise text lines to audio beats and apply them to a video.

    Text lines are paired with detected beat timestamps by index. Extra lines
    or beats are silently dropped.

    Args:
        video: Path to the source video file.
        audio: Path to the audio or video file for beat analysis.
        text_lines: Ordered list of caption lines, one per beat.
        style: Caption style slug.
        output: Output file path; derived from *video* if omitted.
        bpm_hint: Optional BPM hint passed to the beat detector.
        config: Optional CaptionConfig; style defaults applied if omitted.

    Returns:
        Path to the output video file.

    Raises:
        UnknownStyleError: If *style* is not recognised.
        CompositionError: If composition fails.
    """
    from caption_cast.beats.detector import detect_beats  # noqa: PLC0415
    from caption_cast.styles.beat_bounce import render_beat_bounce  # noqa: PLC0415
    from caption_cast.styles.recipes import get_recipe  # noqa: PLC0415

    video = Path(video)
    out = Path(output) if output else _default_output(video)
    cfg = config or default_config_for_style(style)
    get_recipe(style)  # validates early

    beat_times = detect_beats(audio, bpm_hint=bpm_hint)
    _log.info(f"Detected {len(beat_times)} beats; have {len(text_lines)} lines")

    return render_beat_bounce(
        video_path=video,
        text_lines=text_lines,
        beat_times=beat_times,
        config=cfg,
        output_path=out,
    )


def list_styles(category: str | None = None) -> list[str]:
    """Return all known caption style slugs, optionally filtered by category.

    Args:
        category: If provided, only styles whose ``categories`` list contains
            this value are returned.

    Returns:
        Alphabetically sorted list of style slug strings.
    """
    from caption_cast.styles.loader import load_styles  # noqa: PLC0415

    styles = load_styles()
    if category:
        styles = [s for s in styles if category in s.get("categories", [])]
    return sorted(s["slug"] for s in styles)


def get_style_info(slug: str) -> dict:
    """Return the full metadata dict for a caption style slug.

    Args:
        slug: Caption style identifier.

    Returns:
        Style metadata dict from the catalog.

    Raises:
        UnknownStyleError: If no style with the given slug is found.
    """
    from caption_cast.styles.loader import get_style  # noqa: PLC0415

    return get_style(slug)
