# Filepath: caption_cast/cli.py
# Condensed Description: argparse CLI entry point for caption-cast with subcommands
# Architecture Layer: CLI
# Environment: Both
# Script Hierarchy: main, _cmd_caption, _cmd_lyrics, _cmd_subtitles, _cmd_beats, _cmd_styles, _cmd_info, _cmd_preview, _cmd_schema
# Dependencies: Internal: caption_cast.api, caption_cast.schema.generator; External: none; Providers: none
# Exposes: main
# Configuration: None
from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path

_log = logging.getLogger(__name__)


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="caption-cast",
        description="Audio-driven caption overlay tool.",
    )
    parser.add_argument("--verbose", "-v", action="store_true", help="Enable debug logging.")
    sub = parser.add_subparsers(dest="command", metavar="COMMAND")

    # ---- caption ----
    p_cap = sub.add_parser("caption", help="Apply a single caption to a video.")
    p_cap.add_argument("--video", required=True, help="Input video path.")
    p_cap.add_argument("--text", required=True, help="Caption text.")
    p_cap.add_argument("--style", required=True, help="Caption style slug.")
    p_cap.add_argument("--start", type=float, default=0.0, help="Start time in seconds.")
    p_cap.add_argument("--duration", type=float, default=2.0, help="Duration in seconds.")
    p_cap.add_argument("--out", default=None, help="Output video path.")

    # ---- lyrics ----
    p_lyr = sub.add_parser("lyrics", help="Burn lyric captions onto a video.")
    p_lyr.add_argument("--video", required=True, help="Input video path.")
    p_lyr.add_argument("--audio", required=True, help="Audio file path.")
    p_lyr.add_argument("--lyrics", required=True, help="Lyrics file (.srt/.vtt/.lrc).")
    p_lyr.add_argument("--style", default="karaoke_highlight", help="Caption style slug.")
    p_lyr.add_argument("--out", default=None, help="Output video path.")

    # ---- subtitles ----
    p_sub = sub.add_parser("subtitles", help="Burn subtitle file onto a video.")
    p_sub.add_argument("--video", required=True, help="Input video path.")
    p_sub.add_argument("--srt", required=True, help="Subtitle file (.srt/.vtt/.lrc).")
    p_sub.add_argument("--style", default="subtitle_burn_in", help="Caption style slug.")
    p_sub.add_argument("--out", default=None, help="Output video path.")

    # ---- beats ----
    p_beat = sub.add_parser("beats", help="Sync text lines to audio beats.")
    p_beat.add_argument("--video", required=True, help="Input video path.")
    p_beat.add_argument("--audio", required=True, help="Audio file path.")
    p_beat.add_argument(
        "--lines", nargs="+", required=True, metavar="LINE", help="Text lines (one per beat)."
    )
    p_beat.add_argument("--style", default="lyric_bounce", help="Caption style slug.")
    p_beat.add_argument("--out", default=None, help="Output video path.")
    p_beat.add_argument("--bpm", type=float, default=None, help="Optional BPM hint.")

    # ---- styles ----
    p_sty = sub.add_parser("styles", help="List available caption styles.")
    p_sty.add_argument("--category", default=None, help="Filter by category.")

    # ---- info ----
    p_info = sub.add_parser("info", help="Show details for a caption style.")
    p_info.add_argument("style", help="Caption style slug.")

    # ---- preview ----
    p_prev = sub.add_parser("preview", help="Render a preview clip for a style.")
    p_prev.add_argument("--style", required=True, help="Caption style slug.")
    p_prev.add_argument("--text", default="Preview text", help="Sample text.")
    p_prev.add_argument("--out", default=None, help="Output video path.")
    p_prev.add_argument("--width", type=int, default=1920, help="Canvas width.")
    p_prev.add_argument("--height", type=int, default=1080, help="Canvas height.")
    p_prev.add_argument("--duration", type=float, default=2.0, help="Duration in seconds.")
    p_prev.add_argument("--bg-color", default="#000000", help="Background colour.")

    # ---- schema ----
    p_sch = sub.add_parser("schema", help="Print the JSON schema for LLM tool use.")
    p_sch.add_argument("--pretty", action="store_true", help="Pretty-print JSON.")

    return parser


# ---------------------------------------------------------------------------
# Sub-command handlers
# ---------------------------------------------------------------------------


def _cmd_caption(args: argparse.Namespace) -> int:
    from caption_cast.api import apply_caption  # noqa: PLC0415

    out = apply_caption(
        video=args.video,
        text=args.text,
        style=args.style,
        start_time=args.start,
        duration=args.duration,
        output=args.out,
    )
    print(str(out))
    return 0


def _cmd_lyrics(args: argparse.Namespace) -> int:
    from caption_cast.api import burn_lyrics  # noqa: PLC0415

    out = burn_lyrics(
        video=args.video,
        audio=args.audio,
        lyrics=args.lyrics,
        style=args.style,
        output=args.out,
    )
    print(str(out))
    return 0


def _cmd_subtitles(args: argparse.Namespace) -> int:
    from caption_cast.api import burn_subtitles  # noqa: PLC0415

    out = burn_subtitles(
        video=args.video,
        subtitles=args.srt,
        style=args.style,
        output=args.out,
    )
    print(str(out))
    return 0


def _cmd_beats(args: argparse.Namespace) -> int:
    from caption_cast.api import beat_synced_captions  # noqa: PLC0415

    out = beat_synced_captions(
        video=args.video,
        audio=args.audio,
        text_lines=args.lines,
        style=args.style,
        output=args.out,
        bpm_hint=args.bpm,
    )
    print(str(out))
    return 0


def _cmd_styles(args: argparse.Namespace) -> int:
    from caption_cast.api import list_styles  # noqa: PLC0415

    slugs = list_styles(category=args.category)
    for slug in slugs:
        print(slug)
    return 0


def _cmd_info(args: argparse.Namespace) -> int:
    import json  # noqa: PLC0415

    from caption_cast.api import get_style_info  # noqa: PLC0415

    info = get_style_info(args.style)
    print(json.dumps(info, indent=2))
    return 0


def _cmd_preview(args: argparse.Namespace) -> int:
    """Generate a preview by creating a blank background video then applying the caption."""
    import subprocess  # noqa: PLC0415
    import tempfile  # noqa: PLC0415

    from caption_cast.api import apply_caption  # noqa: PLC0415

    out_path = Path(args.out) if args.out else Path(f"preview_{args.style}.mp4")

    # Create a solid-colour background clip via ffmpeg
    with tempfile.NamedTemporaryFile(suffix=".mp4", delete=False) as tmp:
        bg_path = tmp.name

    r, g, b = _hex_to_rgb(args.bg_color)
    cmd = [
        "ffmpeg",
        "-y",
        "-f",
        "lavfi",
        "-i",
        f"color=c={r:02x}{g:02x}{b:02x}:size={args.width}x{args.height}:duration={args.duration}:rate=25",
        "-c:v",
        "libx264",
        "-pix_fmt",
        "yuv420p",
        bg_path,
    ]
    result = subprocess.run(cmd, capture_output=True)
    if result.returncode != 0:
        _log.error(f"ffmpeg background generation failed: {result.stderr.decode()}")
        return 1

    apply_caption(
        video=bg_path,
        text=args.text,
        style=args.style,
        start_time=0.0,
        duration=args.duration,
        output=str(out_path),
    )
    print(str(out_path))
    return 0


def _hex_to_rgb(hex_color: str) -> tuple[int, int, int]:
    """Convert a ``#RRGGBB`` hex string to an RGB tuple."""
    h = hex_color.lstrip("#")
    r = int(h[0:2], 16)
    g = int(h[2:4], 16)
    b = int(h[4:6], 16)
    return r, g, b


def _cmd_schema(args: argparse.Namespace) -> int:
    from caption_cast.schema.generator import schema_json  # noqa: PLC0415

    print(schema_json(pretty=args.pretty))
    return 0


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

_HANDLERS = {
    "caption": _cmd_caption,
    "lyrics": _cmd_lyrics,
    "subtitles": _cmd_subtitles,
    "beats": _cmd_beats,
    "styles": _cmd_styles,
    "info": _cmd_info,
    "preview": _cmd_preview,
    "schema": _cmd_schema,
}


def main(argv: list[str] | None = None) -> int:
    """CLI entry point for caption-cast.

    Args:
        argv: Argument list; defaults to ``sys.argv[1:]`` when None.

    Returns:
        Process exit code (0 = success, non-zero = error).
    """
    parser = _build_parser()
    args = parser.parse_args(argv)

    if args.verbose:
        logging.basicConfig(level=logging.DEBUG)
    else:
        logging.basicConfig(level=logging.WARNING)

    if not args.command:
        parser.print_help()
        return 1

    handler = _HANDLERS.get(args.command)
    if handler is None:
        parser.print_help()
        return 1

    try:
        return handler(args)
    except KeyboardInterrupt:
        return 130
    except Exception as exc:
        _log.error(f"{type(exc).__name__}: {exc}")
        if args.verbose:
            import traceback  # noqa: PLC0415

            traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main())
