# Filepath: caption_cast/lyrics/aligner.py
# Condensed Description: Align plain text lines to audio using lyric-sync if installed
# Architecture Layer: Lyrics
# Environment: Both
# Script Hierarchy: align
# Dependencies: Internal: caption_cast.lyrics.normalize; External: lyric-sync (optional); Providers: none
# Exposes: align
# Configuration: None
from __future__ import annotations

import logging
from pathlib import Path

from caption_cast.lyrics.normalize import TimedLine

_log = logging.getLogger(__name__)


def align(text_lines: list[str], audio_path: str | Path) -> list[TimedLine]:
    """Align plain text lines to audio using lyric-sync.

    Args:
        text_lines: Ordered list of lyric/caption lines to align.
        audio_path: Path to the audio (or video) file used for alignment.

    Returns:
        List of TimedLine objects with timestamps derived from forced alignment.

    Raises:
        ImportError: If ``lyric-sync`` is not installed.
    """
    try:
        from lyric_sync import align as ls_align  # noqa: PLC0415
    except ImportError as exc:
        raise ImportError(
            "lyric-sync is required for automatic word alignment. "
            "Install: pip install caption-cast[lyrics]"
        ) from exc

    _log.debug(f"Aligning {len(text_lines)} lines against {audio_path}")
    raw_result = ls_align(text_lines, str(audio_path))

    # lyric-sync returns dicts with text/start/end/words keys
    from caption_cast.lyrics.normalize import lines_from_dicts  # noqa: PLC0415

    return lines_from_dicts(raw_result)
