# Filepath: caption_cast/lyrics/normalize.py
# Condensed Description: Dataclasses for timed lyrics/subtitle data structures
# Architecture Layer: Lyrics
# Environment: Both
# Script Hierarchy: TimedWord, TimedLine, lines_from_dicts
# Dependencies: Internal: none; External: none; Providers: none
# Exposes: TimedWord, TimedLine, lines_from_dicts
# Configuration: None
from __future__ import annotations

import logging
from dataclasses import dataclass, field

_log = logging.getLogger(__name__)


@dataclass
class TimedWord:
    """A single word with start/end timestamps in seconds."""

    text: str
    start: float
    end: float


@dataclass
class TimedLine:
    """A line of text with start/end timestamps and optional word-level data."""

    text: str
    start: float
    end: float
    words: list[TimedWord] | None = field(default=None)


def lines_from_dicts(data: list[dict]) -> list[TimedLine]:
    """Convert a list of dict records to TimedLine objects.

    Args:
        data: List of dicts with keys ``text``, ``start``, ``end``, and
            optionally ``words`` (list of dicts with the same three keys).

    Returns:
        List of TimedLine dataclass instances.
    """
    result: list[TimedLine] = []
    for record in data:
        raw_words = record.get("words")
        words: list[TimedWord] | None = None
        if raw_words:
            words = [
                TimedWord(text=w["text"], start=float(w["start"]), end=float(w["end"]))
                for w in raw_words
            ]
        result.append(
            TimedLine(
                text=record["text"],
                start=float(record["start"]),
                end=float(record["end"]),
                words=words,
            )
        )
    _log.debug(f"Converted {len(result)} records to TimedLine objects")
    return result
