# Filepath: caption_cast/lyrics/__init__.py
# Condensed Description: Lyrics sub-package marker
# Architecture Layer: Lyrics
# Environment: Both
# Script Hierarchy: none
# Dependencies: Internal: none; External: none; Providers: none
# Exposes: none
# Configuration: None
from __future__ import annotations
