# Filepath: caption_cast/lyrics/parser.py
# Condensed Description: Parse .lrc, .srt, and .vtt subtitle files into TimedLine lists
# Architecture Layer: Lyrics
# Environment: Both
# Script Hierarchy: parse_file, parse_srt, parse_lrc, parse_vtt
# Dependencies: Internal: caption_cast.lyrics.normalize, caption_cast.exceptions; External: pysubs2; Providers: none
# Exposes: parse_file, parse_srt, parse_lrc, parse_vtt
# Configuration: None
from __future__ import annotations

import logging
import re
from pathlib import Path

from caption_cast.exceptions import LyricsParseError
from caption_cast.lyrics.normalize import TimedLine

_log = logging.getLogger(__name__)

# LRC timestamp pattern: [mm:ss.xx] or [mm:ss.xxx]
_LRC_PATTERN = re.compile(r"\[(\d{2}):(\d{2})\.(\d{2,3})\](.*)$")


def parse_file(path: str | Path) -> list[TimedLine]:
    """Auto-detect subtitle format from extension and parse into TimedLine list.

    Args:
        path: Path to a ``.lrc``, ``.srt``, or ``.vtt`` file.

    Returns:
        Parsed list of timed lines.

    Raises:
        LyricsParseError: If the format is unsupported or the file cannot be parsed.
    """
    path = Path(path)
    ext = path.suffix.lower()
    dispatch = {
        ".srt": parse_srt,
        ".vtt": parse_vtt,
        ".lrc": parse_lrc,
    }
    if ext not in dispatch:
        raise LyricsParseError(f"Unsupported subtitle format: {ext!r}. Supported: .srt, .vtt, .lrc")
    return dispatch[ext](path)


def parse_srt(path: str | Path) -> list[TimedLine]:
    """Parse an SRT subtitle file using pysubs2.

    Args:
        path: Path to the ``.srt`` file.

    Returns:
        List of TimedLine objects, one per subtitle event.

    Raises:
        LyricsParseError: If the file cannot be read or parsed.
    """
    try:
        import pysubs2
    except ImportError as exc:
        raise ImportError(
            "pysubs2 is required to parse SRT files. Install: pip install caption-cast[lyrics]"
        ) from exc

    try:
        subs = pysubs2.load(str(path), encoding="utf-8")
    except Exception as exc:
        raise LyricsParseError(f"Failed to parse SRT file {path}: {exc}") from exc

    return _pysubs2_to_lines(subs)


def parse_vtt(path: str | Path) -> list[TimedLine]:
    """Parse a WebVTT subtitle file using pysubs2.

    Args:
        path: Path to the ``.vtt`` file.

    Returns:
        List of TimedLine objects.

    Raises:
        LyricsParseError: If the file cannot be read or parsed.
    """
    try:
        import pysubs2
    except ImportError as exc:
        raise ImportError(
            "pysubs2 is required to parse VTT files. Install: pip install caption-cast[lyrics]"
        ) from exc

    try:
        subs = pysubs2.load(str(path), encoding="utf-8")
    except Exception as exc:
        raise LyricsParseError(f"Failed to parse VTT file {path}: {exc}") from exc

    return _pysubs2_to_lines(subs)


def parse_lrc(path: str | Path) -> list[TimedLine]:
    """Parse an LRC lyric file with [mm:ss.xx] timestamps.

    Args:
        path: Path to the ``.lrc`` file.

    Returns:
        List of TimedLine objects sorted by start time.

    Raises:
        LyricsParseError: If the file cannot be read.
    """
    path = Path(path)
    try:
        raw = path.read_text(encoding="utf-8")
    except OSError as exc:
        raise LyricsParseError(f"Cannot read LRC file {path}: {exc}") from exc

    entries: list[tuple[float, str]] = []
    for ln in raw.splitlines():
        match = _LRC_PATTERN.match(ln.strip())
        if not match:
            continue
        minutes, seconds, centis, text = match.groups()
        # Normalise to two-digit centiseconds regardless of input precision
        centi_str = centis[:2] if len(centis) >= 2 else centis.ljust(2, "0")
        timestamp = int(minutes) * 60 + int(seconds) + int(centi_str) / 100.0
        entries.append((timestamp, text.strip()))

    if not entries:
        _log.warning(f"No timed entries found in LRC file: {path}")

    entries.sort(key=lambda x: x[0])

    lines: list[TimedLine] = []
    for idx, (start, text) in enumerate(entries):
        if not text:
            continue
        end = entries[idx + 1][0] if idx + 1 < len(entries) else start + 3.0
        lines.append(TimedLine(text=text, start=start, end=end))

    return lines


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _pysubs2_to_lines(subs: object) -> list[TimedLine]:
    """Convert a pysubs2 SSAFile to a list of TimedLine objects.

    Args:
        subs: A loaded pysubs2 SSAFile instance.

    Returns:
        List of TimedLine objects.
    """
    lines: list[TimedLine] = []
    for event in subs:
        if event.is_comment:
            continue
        # pysubs2 times are in milliseconds
        start = event.start / 1000.0
        end = event.end / 1000.0
        text = event.plaintext if hasattr(event, "plaintext") else _strip_ssa_tags(event.text)
        if not text:
            continue
        lines.append(TimedLine(text=text, start=start, end=end))
    return lines


def _strip_ssa_tags(text: str) -> str:
    """Remove SSA/ASS override tags from subtitle text.

    Args:
        text: Raw SSA event text possibly containing ``{\\an8}`` style tags.

    Returns:
        Plain text with all tag blocks removed.
    """
    return re.sub(r"\{[^}]*\}", "", text).replace("\\N", " ").replace("\\n", " ").strip()
