# Filepath: caption_cast/schema/generator.py
# Condensed Description: Generate JSON schema for LLM caption request validation
# Architecture Layer: Schema
# Environment: Both
# Script Hierarchy: caption_schema, schema_json
# Dependencies: Internal: caption_cast.styles.loader; External: none; Providers: none
# Exposes: caption_schema, schema_json
# Configuration: None
from __future__ import annotations

import json
import logging

_log = logging.getLogger(__name__)


def caption_schema() -> dict:
    """Return a JSON Schema dict describing a caption request for LLM tool use.

    Returns:
        A dict conforming to JSON Schema draft-07, listing all valid style slugs
        as an enum on the ``style`` property.
    """
    from caption_cast.styles.loader import load_styles  # noqa: PLC0415

    slugs = [s["slug"] for s in load_styles()]
    return {
        "type": "object",
        "title": "CaptionRequest",
        "properties": {
            "style": {"type": "string", "enum": slugs},
            "text": {"type": "string"},
            "start_time": {"type": "number", "minimum": 0},
            "duration": {"type": "number", "minimum": 0.1},
        },
        "required": ["style", "text"],
    }


def schema_json(pretty: bool = False) -> str:
    """Serialise the caption schema to a JSON string.

    Args:
        pretty: If True, indent the output with 2 spaces.

    Returns:
        JSON string representation of the schema.
    """
    schema = caption_schema()
    return json.dumps(schema, indent=2 if pretty else None)
