# Filepath: caption_cast/schema/__init__.py
# Condensed Description: Schema sub-package marker
# Architecture Layer: Schema
# Environment: Both
# Script Hierarchy: none
# Dependencies: Internal: none; External: none; Providers: none
# Exposes: none
# Configuration: None
from __future__ import annotations
