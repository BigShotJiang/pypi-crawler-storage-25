# Filepath: caption_cast/schema/parser.py
# Condensed Description: Parse LLM JSON responses into caption request dicts
# Architecture Layer: Schema
# Environment: Both
# Script Hierarchy: parse_llm_response
# Dependencies: Internal: none; External: none; Providers: none
# Exposes: parse_llm_response
# Configuration: None
from __future__ import annotations

import json
import logging

_log = logging.getLogger(__name__)


def parse_llm_response(response: str | dict) -> dict:
    """Parse an LLM JSON response into a normalised caption request dict.

    Accepts either a pre-parsed dict or a raw JSON string (which may be
    wrapped in a markdown code fence, as is common with many LLM outputs).

    Args:
        response: A JSON string or already-decoded dict from the LLM.

    Returns:
        Decoded caption request dict.

    Raises:
        json.JSONDecodeError: If ``response`` is a string that does not decode
            as valid JSON after stripping markdown fences.
    """
    if isinstance(response, dict):
        return response

    # Strip common markdown code-fence wrappers before decoding
    cleaned = response.strip()
    if cleaned.startswith("```"):
        lines = cleaned.splitlines()
        # Drop opening fence (```json or ```) and closing fence
        inner = lines[1:-1] if lines[-1].strip() == "```" else lines[1:]
        cleaned = "\n".join(inner)

    parsed = json.loads(cleaned)
    _log.debug(f"Parsed LLM response: {list(parsed.keys())}")
    return parsed
