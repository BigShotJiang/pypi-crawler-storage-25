# Filepath: caption_cast/layout/safe_area.py
# Condensed Description: Safe-area inset calculation and caption y-position resolution
# Architecture Layer: Layout
# Environment: Both
# Script Hierarchy: safe_area_insets, caption_y_position
# Dependencies: Internal: none; External: none; Providers: none
# Exposes: safe_area_insets, caption_y_position
# Configuration: None
from __future__ import annotations

import logging

_log = logging.getLogger(__name__)

_ZONE_MULTIPLIERS: dict[str, float] = {
    "minimal": 0.5,
    "standard": 1.0,
    "max": 1.5,
}


def safe_area_insets(
    canvas_size: tuple[int, int],
    zone: str = "standard",
    padding: int = 80,
) -> dict[str, int]:
    """Return safe-area insets as pixel values for each edge.

    Args:
        canvas_size: ``(width, height)`` of the output canvas.
        zone: One of ``"minimal"``, ``"standard"``, or ``"max"``.
        padding: Base padding value in pixels before zone multiplier is applied.

    Returns:
        Dict with keys ``"top"``, ``"bottom"``, ``"left"``, ``"right"`` mapping to
        pixel inset values.
    """
    multiplier = _ZONE_MULTIPLIERS.get(zone, 1.0)
    base = int(padding * multiplier)
    return {"top": base, "bottom": base, "left": base, "right": base}


def caption_y_position(
    position: str,
    canvas_size: tuple[int, int],
    text_height: int,
    insets: dict[str, int],
) -> int:
    """Compute the y pixel coordinate for a caption block.

    Args:
        position: One of ``"top"``, ``"center"``, ``"bottom"``, or ``"lower_third"``.
        canvas_size: ``(width, height)`` of the output canvas.
        text_height: Pixel height of the rendered text block.
        insets: Safe-area inset dict from :func:`safe_area_insets`.

    Returns:
        The y coordinate (top of the text block) in pixels.
    """
    _, height = canvas_size
    if position == "top":
        return insets["top"]
    if position == "center":
        return (height - text_height) // 2
    if position == "bottom":
        return height - text_height - insets["bottom"]
    if position == "lower_third":
        # Conventional lower-third sits at roughly 75 % of the canvas height
        return int(height * 0.75) - text_height // 2
    # Fallback to bottom for unknown values — callers should validate upstream
    _log.warning(f"Unknown position {position!r}; falling back to bottom")
    return height - text_height - insets["bottom"]
