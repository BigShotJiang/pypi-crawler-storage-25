# Filepath: caption_cast/layout/wrap.py
# Condensed Description: Word-wrap utility respecting word-count and character-count limits
# Architecture Layer: Layout
# Environment: Both
# Script Hierarchy: wrap_text
# Dependencies: Internal: none; External: none; Providers: none
# Exposes: wrap_text
# Configuration: None
from __future__ import annotations

import logging

_log = logging.getLogger(__name__)


def wrap_text(
    text: str,
    max_words: int = 6,
    max_chars: int = 42,
) -> list[str]:
    """Split a string into lines that respect word-count and character-count limits.

    Lines are broken whenever either limit would be exceeded by adding the next
    word.

    Args:
        text: The input string to wrap.
        max_words: Maximum number of words per output line.
        max_chars: Maximum number of characters per output line.

    Returns:
        List of wrapped line strings.
    """
    words = text.split()
    if not words:
        return []

    lines: list[str] = []
    current_words: list[str] = []
    current_chars = 0

    for word in words:
        # +1 for the space that would precede the word (except at line start)
        space_needed = 1 if current_words else 0
        would_exceed_chars = (current_chars + space_needed + len(word)) > max_chars
        would_exceed_words = len(current_words) >= max_words

        if current_words and (would_exceed_chars or would_exceed_words):
            lines.append(" ".join(current_words))
            current_words = [word]
            current_chars = len(word)
        else:
            current_words.append(word)
            current_chars += space_needed + len(word)

    if current_words:
        lines.append(" ".join(current_words))

    return lines
