# Filepath: caption_cast/layout/__init__.py
# Condensed Description: Layout sub-package marker
# Architecture Layer: Layout
# Environment: Both
# Script Hierarchy: none
# Dependencies: Internal: none; External: none; Providers: none
# Exposes: none
# Configuration: None
from __future__ import annotations
