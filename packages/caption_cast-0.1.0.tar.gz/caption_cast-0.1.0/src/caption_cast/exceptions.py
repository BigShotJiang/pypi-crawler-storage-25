# Filepath: caption_cast/exceptions.py
# Condensed Description: Custom exception hierarchy for caption-cast
# Architecture Layer: Core
# Environment: Both
# Script Hierarchy: CaptionCastError, UnknownStyleError, LyricsParseError, BeatDetectionError, CompositionError, EmojiRenderError
# Dependencies: Internal: none; External: none; Providers: none
# Exposes: CaptionCastError, UnknownStyleError, LyricsParseError, BeatDetectionError, CompositionError, EmojiRenderError
# Configuration: None
from __future__ import annotations


class CaptionCastError(Exception):
    """Base exception for all caption-cast errors."""


class UnknownStyleError(CaptionCastError):
    """Raised when an unrecognised caption style slug is requested."""

    def __init__(self, slug: str) -> None:
        super().__init__(
            f"Unknown caption style: {slug!r}. Use list_styles() to see available styles."
        )
        self.slug = slug


class LyricsParseError(CaptionCastError):
    """Raised when a subtitle or lyrics file cannot be parsed."""


class BeatDetectionError(CaptionCastError):
    """Raised when beat detection fails or the required dependency is unavailable."""


class CompositionError(CaptionCastError):
    """Raised when ffmpeg overlay composition fails."""


class EmojiRenderError(CaptionCastError):
    """Raised when emoji rendering fails."""
