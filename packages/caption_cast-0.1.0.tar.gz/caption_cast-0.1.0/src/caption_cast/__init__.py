# Filepath: caption_cast/__init__.py
# Condensed Description: caption-cast package root: version and public API re-exports
# Architecture Layer: API
# Environment: Both
# Script Hierarchy: __version__, apply_caption, burn_lyrics, burn_subtitles, beat_synced_captions, list_styles, get_style_info
# Dependencies: Internal: caption_cast.api; External: none; Providers: none
# Exposes: __version__, apply_caption, burn_lyrics, burn_subtitles, beat_synced_captions, list_styles, get_style_info
# Configuration: None
from __future__ import annotations

__version__ = "0.1.0"

from caption_cast.api import (
    apply_caption,
    beat_synced_captions,
    burn_lyrics,
    burn_subtitles,
    get_style_info,
    list_styles,
)

__all__ = [
    "__version__",
    "apply_caption",
    "burn_lyrics",
    "burn_subtitles",
    "beat_synced_captions",
    "list_styles",
    "get_style_info",
]
