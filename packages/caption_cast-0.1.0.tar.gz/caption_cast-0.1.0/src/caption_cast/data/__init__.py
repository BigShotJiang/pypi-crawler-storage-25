# Filepath: caption_cast/data/__init__.py
# Condensed Description: Data package marker for caption-cast bundled assets
# Architecture Layer: Data
# Environment: Both
# Script Hierarchy: none
# Dependencies: Internal: none; External: none; Providers: none
# Exposes: none
# Configuration: None
from __future__ import annotations
