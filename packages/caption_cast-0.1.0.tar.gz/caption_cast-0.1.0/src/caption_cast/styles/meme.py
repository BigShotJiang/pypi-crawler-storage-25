# Filepath: caption_cast/styles/meme.py
# Condensed Description: Meme-style caption renderers for top/bottom text, sticker, and hashtag
# Architecture Layer: Styles
# Environment: Both
# Script Hierarchy: render_meme_top, render_meme_bottom, render_sticker_text, render_hashtag_sticker
# Dependencies: Internal: caption_cast.config; External: text_fx; Providers: none
# Exposes: render_meme_top, render_meme_bottom, render_sticker_text, render_hashtag_sticker
# Configuration: None
from __future__ import annotations

import logging
from pathlib import Path

from caption_cast.config import CaptionConfig

_log = logging.getLogger(__name__)


def _apply_meme_effect(
    video_path: Path,
    text: str,
    start_time: float,
    duration: float,
    effect: str,
    color: str,
    font_size: int,
    stroke_color: str | None,
    stroke_width: int,
    output_path: Path,
) -> Path:
    import text_fx  # noqa: PLC0415

    text_fx.apply_text_effect(
        video=str(video_path),
        text=text,
        effect=effect,
        output=str(output_path),
        duration=max(0.1, duration),
        start_time=start_time,
        color=color,
        font_size=font_size,
        stroke_color=stroke_color,
        stroke_width=stroke_width,
    )
    return output_path


def render_meme_top(
    video_path: Path,
    text: str,
    start_time: float,
    duration: float,
    config: CaptionConfig,
    output_path: Path,
) -> Path:
    """Render classic top-of-frame meme caption with heavy black stroke.

    Args:
        video_path: Path to the source video file.
        text: Caption text (typically uppercase).
        start_time: Start time in seconds.
        duration: Display duration in seconds.
        config: Active CaptionConfig instance.
        output_path: Desired output path.

    Returns:
        Path to the rendered output video.
    """
    _log.debug(f"render_meme_top: {text!r}")
    return _apply_meme_effect(
        video_path=video_path,
        text=text.upper(),
        start_time=start_time,
        duration=duration,
        effect="fade_in",
        color=config.color or "#FFFFFF",
        font_size=config.font_size or 80,
        stroke_color=config.stroke_color or "#000000",
        stroke_width=config.stroke_width if config.stroke_width is not None else 6,
        output_path=output_path,
    )


def render_meme_bottom(
    video_path: Path,
    text: str,
    start_time: float,
    duration: float,
    config: CaptionConfig,
    output_path: Path,
) -> Path:
    """Render classic bottom-of-frame meme caption with heavy black stroke.

    Args:
        video_path: Path to the source video file.
        text: Caption text (typically uppercase).
        start_time: Start time in seconds.
        duration: Display duration in seconds.
        config: Active CaptionConfig instance.
        output_path: Desired output path.

    Returns:
        Path to the rendered output video.
    """
    _log.debug(f"render_meme_bottom: {text!r}")
    return _apply_meme_effect(
        video_path=video_path,
        text=text.upper(),
        start_time=start_time,
        duration=duration,
        effect="fade_in",
        color=config.color or "#FFFFFF",
        font_size=config.font_size or 80,
        stroke_color=config.stroke_color or "#000000",
        stroke_width=config.stroke_width if config.stroke_width is not None else 6,
        output_path=output_path,
    )


def render_sticker_text(
    video_path: Path,
    text: str,
    start_time: float,
    duration: float,
    config: CaptionConfig,
    output_path: Path,
) -> Path:
    """Render sticker-style text with thick outline.

    Args:
        video_path: Path to the source video file.
        text: Caption text.
        start_time: Start time in seconds.
        duration: Display duration in seconds.
        config: Active CaptionConfig instance.
        output_path: Desired output path.

    Returns:
        Path to the rendered output video.
    """
    _log.debug(f"render_sticker_text: {text!r}")
    return _apply_meme_effect(
        video_path=video_path,
        text=text,
        start_time=start_time,
        duration=duration,
        effect="fade_in",
        color=config.color or "#FFFFFF",
        font_size=config.font_size or 80,
        stroke_color=config.stroke_color or "#000000",
        stroke_width=config.stroke_width if config.stroke_width is not None else 8,
        output_path=output_path,
    )


def render_hashtag_sticker(
    video_path: Path,
    text: str,
    start_time: float,
    duration: float,
    config: CaptionConfig,
    output_path: Path,
) -> Path:
    """Render a hashtag label with a fade-in animation.

    Prepends ``#`` if the text does not already start with one.

    Args:
        video_path: Path to the source video file.
        text: Hashtag text (with or without leading ``#``).
        start_time: Start time in seconds.
        duration: Display duration in seconds.
        config: Active CaptionConfig instance.
        output_path: Desired output path.

    Returns:
        Path to the rendered output video.
    """
    _log.debug(f"render_hashtag_sticker: {text!r}")
    label = text if text.startswith("#") else f"#{text}"
    return _apply_meme_effect(
        video_path=video_path,
        text=label,
        start_time=start_time,
        duration=duration,
        effect="fade_in",
        color=config.color or "#FFFFFF",
        font_size=config.font_size or 60,
        stroke_color=config.stroke_color,
        stroke_width=config.stroke_width if config.stroke_width is not None else 0,
        output_path=output_path,
    )
