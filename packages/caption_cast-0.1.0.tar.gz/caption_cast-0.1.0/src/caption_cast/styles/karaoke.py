# Filepath: caption_cast/styles/karaoke.py
# Condensed Description: Karaoke word-highlight renderer using text-fx fade_in per word
# Architecture Layer: Styles
# Environment: Both
# Script Hierarchy: render_karaoke
# Dependencies: Internal: caption_cast.config, caption_cast.lyrics.normalize; External: text_fx; Providers: none
# Exposes: render_karaoke
# Configuration: None
from __future__ import annotations

import logging
import shutil
from pathlib import Path

from caption_cast.config import CaptionConfig
from caption_cast.lyrics.normalize import TimedWord

_log = logging.getLogger(__name__)


def render_karaoke(
    video_path: Path,
    words: list[TimedWord],
    config: CaptionConfig,
    canvas_size: tuple[int, int],
    output_path: Path,
) -> Path:
    """Render karaoke-style highlighting: each word fades in with a highlight colour.

    The full line stays visible throughout; each word is individually
    highlighted in sequence as its timestamp arrives.

    Args:
        video_path: Path to the source video file.
        words: Ordered list of timed words.
        config: Active CaptionConfig instance.
        canvas_size: ``(width, height)`` of the video canvas.
        output_path: Desired path for the final output video.

    Returns:
        Path to the rendered output video.
    """
    import text_fx  # noqa: PLC0415

    highlight_color = config.highlight_color or "#FFFF00"
    color = config.color or "#FFFFFF"
    font_size = config.font_size or 72

    current_video = video_path

    for idx, word in enumerate(words):
        word_out = output_path.parent / f"_karaoke_{idx:04d}.mp4"
        duration = max(0.1, word.end - word.start)

        _log.debug(f"Karaoke highlight word {word.text!r} at t={word.start:.2f}")

        text_fx.apply_text_effect(
            video=str(current_video),
            text=word.text,
            effect="fade_in",
            output=str(word_out),
            duration=duration,
            start_time=word.start,
            color=highlight_color,
            font_size=font_size,
        )
        current_video = word_out

    # Suppress unused variable warning — color is kept for future base-text layer
    _ = color

    shutil.copy2(str(current_video), str(output_path))
    return output_path
