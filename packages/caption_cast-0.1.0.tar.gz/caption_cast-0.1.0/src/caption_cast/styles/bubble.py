# Filepath: caption_cast/styles/bubble.py
# Condensed Description: Comment bubble, DM bubble and speech balloon caption renderers
# Architecture Layer: Styles
# Environment: Both
# Script Hierarchy: render_comment_bubble, render_dm_bubble, render_speech_balloon
# Dependencies: Internal: caption_cast.config; External: text_fx; Providers: none
# Exposes: render_comment_bubble, render_dm_bubble, render_speech_balloon
# Configuration: None
from __future__ import annotations

import logging
from pathlib import Path

from caption_cast.config import CaptionConfig

_log = logging.getLogger(__name__)

# Bubble background drawing is deferred to v0.2 (requires PIL compositing pipeline).
# v0.1 applies text via text-fx with the style's default animation.


def render_comment_bubble(
    video_path: Path,
    text: str,
    start_time: float,
    duration: float,
    config: CaptionConfig,
    output_path: Path,
) -> Path:
    """Render a comment-bubble style caption using slide_left_text.

    Args:
        video_path: Path to the source video file.
        text: Caption text to display.
        start_time: Start time in seconds.
        duration: Display duration in seconds.
        config: Active CaptionConfig instance.
        output_path: Desired output path.

    Returns:
        Path to the rendered output video.
    """
    import text_fx  # noqa: PLC0415

    color = config.color or "#000000"
    font_size = config.font_size or 52

    _log.debug(f"render_comment_bubble: {text!r} at t={start_time:.2f}")

    text_fx.apply_text_effect(
        video=str(video_path),
        text=text,
        effect="slide_left_text",
        output=str(output_path),
        duration=max(0.1, duration),
        start_time=start_time,
        color=color,
        font_size=font_size,
    )
    return output_path


def render_dm_bubble(
    video_path: Path,
    text: str,
    start_time: float,
    duration: float,
    config: CaptionConfig,
    output_path: Path,
) -> Path:
    """Render a DM-bubble style caption using slide_right_text.

    Args:
        video_path: Path to the source video file.
        text: Caption text to display.
        start_time: Start time in seconds.
        duration: Display duration in seconds.
        config: Active CaptionConfig instance.
        output_path: Desired output path.

    Returns:
        Path to the rendered output video.
    """
    import text_fx  # noqa: PLC0415

    color = config.color or "#000000"
    font_size = config.font_size or 48

    _log.debug(f"render_dm_bubble: {text!r} at t={start_time:.2f}")

    text_fx.apply_text_effect(
        video=str(video_path),
        text=text,
        effect="slide_right_text",
        output=str(output_path),
        duration=max(0.1, duration),
        start_time=start_time,
        color=color,
        font_size=font_size,
    )
    return output_path


def render_speech_balloon(
    video_path: Path,
    text: str,
    start_time: float,
    duration: float,
    config: CaptionConfig,
    output_path: Path,
) -> Path:
    """Render a comic speech-balloon caption using kinetic_pop.

    Args:
        video_path: Path to the source video file.
        text: Caption text to display.
        start_time: Start time in seconds.
        duration: Display duration in seconds.
        config: Active CaptionConfig instance.
        output_path: Desired output path.

    Returns:
        Path to the rendered output video.
    """
    import text_fx  # noqa: PLC0415

    color = config.color or "#000000"
    font_size = config.font_size or 56

    _log.debug(f"render_speech_balloon: {text!r} at t={start_time:.2f}")

    text_fx.apply_text_effect(
        video=str(video_path),
        text=text,
        effect="kinetic_pop",
        output=str(output_path),
        duration=max(0.1, duration),
        start_time=start_time,
        color=color,
        font_size=font_size,
    )
    return output_path
