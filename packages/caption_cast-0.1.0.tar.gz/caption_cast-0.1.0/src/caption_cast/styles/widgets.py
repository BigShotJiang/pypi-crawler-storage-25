# Filepath: caption_cast/styles/widgets.py
# Condensed Description: Widget-style caption renderers: countdown, poll, callout, comic SFX, lower third
# Architecture Layer: Styles
# Environment: Both
# Script Hierarchy: render_countdown, render_poll, render_callout_arrow, render_comic_sfx, render_lower_third
# Dependencies: Internal: caption_cast.config; External: text_fx; Providers: none
# Exposes: render_countdown, render_poll, render_callout_arrow, render_comic_sfx, render_lower_third
# Configuration: None
from __future__ import annotations

import logging
import shutil
from pathlib import Path

from caption_cast.config import CaptionConfig

_log = logging.getLogger(__name__)


def render_countdown(
    video_path: Path,
    numbers: list[str | int],
    interval: float,
    start_time: float,
    config: CaptionConfig,
    output_path: Path,
) -> Path:
    """Render a countdown sequence where each number pops in at a regular interval.

    Args:
        video_path: Path to the source video file.
        numbers: Ordered list of values to display (typically descending integers).
        interval: Duration in seconds between each number.
        start_time: Timestamp for the first number in seconds.
        config: Active CaptionConfig instance.
        output_path: Desired output path.

    Returns:
        Path to the rendered output video.
    """
    import text_fx  # noqa: PLC0415

    color = config.color or "#FFFFFF"
    font_size = config.font_size or 160
    stroke_color = config.stroke_color or "#000000"
    stroke_width = config.stroke_width if config.stroke_width is not None else 8

    current_video = video_path

    for idx, number in enumerate(numbers):
        num_out = output_path.parent / f"_countdown_{idx:04d}.mp4"
        t = start_time + idx * interval

        _log.debug(f"Countdown: {number!r} at t={t:.2f}")

        text_fx.apply_text_effect(
            video=str(current_video),
            text=str(number),
            effect="kinetic_pop",
            output=str(num_out),
            duration=max(0.1, interval),
            start_time=t,
            color=color,
            font_size=font_size,
            stroke_color=stroke_color,
            stroke_width=stroke_width,
        )
        current_video = num_out

    shutil.copy2(str(current_video), str(output_path))
    return output_path


def render_poll(
    video_path: Path,
    question: str,
    options: list[str],
    start_time: float,
    duration: float,
    config: CaptionConfig,
    output_path: Path,
) -> Path:
    """Render a poll question and its answer options onto the video.

    Question and options are staggered by 0.3 s each for a sequential reveal.

    Args:
        video_path: Path to the source video file.
        question: Poll question text.
        options: List of answer option strings.
        start_time: Start time in seconds for the question.
        duration: Display duration for each item in seconds.
        config: Active CaptionConfig instance.
        output_path: Desired output path.

    Returns:
        Path to the rendered output video.
    """
    import text_fx  # noqa: PLC0415

    color = config.color or "#FFFFFF"
    font_size = config.font_size or 60

    current_video = video_path

    # Render the question first, then each option staggered
    all_items = [question] + options
    for idx, item in enumerate(all_items):
        item_out = output_path.parent / f"_poll_{idx:04d}.mp4"
        t = start_time + idx * 0.3

        _log.debug(f"Poll item {idx}: {item!r} at t={t:.2f}")

        text_fx.apply_text_effect(
            video=str(current_video),
            text=item,
            effect="fade_in",
            output=str(item_out),
            duration=max(0.1, duration),
            start_time=t,
            color=color,
            font_size=font_size,
        )
        current_video = item_out

    shutil.copy2(str(current_video), str(output_path))
    return output_path


def render_callout_arrow(
    video_path: Path,
    text: str,
    start_time: float,
    duration: float,
    config: CaptionConfig,
    output_path: Path,
) -> Path:
    """Render a callout label with a fade-in animation.

    Arrow drawing is a v0.2 enhancement; v0.1 renders the text label only.

    Args:
        video_path: Path to the source video file.
        text: Callout label text.
        start_time: Start time in seconds.
        duration: Display duration in seconds.
        config: Active CaptionConfig instance.
        output_path: Desired output path.

    Returns:
        Path to the rendered output video.
    """
    import text_fx  # noqa: PLC0415

    color = config.color or "#FFFFFF"
    font_size = config.font_size or 52

    _log.debug(f"render_callout_arrow: {text!r} at t={start_time:.2f}")

    text_fx.apply_text_effect(
        video=str(video_path),
        text=text,
        effect="fade_in",
        output=str(output_path),
        duration=max(0.1, duration),
        start_time=start_time,
        color=color,
        font_size=font_size,
    )
    return output_path


def render_comic_sfx(
    video_path: Path,
    text: str,
    start_time: float,
    duration: float,
    config: CaptionConfig,
    output_path: Path,
) -> Path:
    """Render a comic sound-effect (BAM/POW style) caption with kinetic_pop.

    Args:
        video_path: Path to the source video file.
        text: SFX text, e.g. ``"BAM!"``.
        start_time: Start time in seconds.
        duration: Display duration in seconds.
        config: Active CaptionConfig instance.
        output_path: Desired output path.

    Returns:
        Path to the rendered output video.
    """
    import text_fx  # noqa: PLC0415

    color = config.color or "#FFFF00"
    font_size = config.font_size or 120
    stroke_color = config.stroke_color or "#000000"
    stroke_width = config.stroke_width if config.stroke_width is not None else 8

    _log.debug(f"render_comic_sfx: {text!r} at t={start_time:.2f}")

    text_fx.apply_text_effect(
        video=str(video_path),
        text=text,
        effect="kinetic_pop",
        output=str(output_path),
        duration=max(0.1, duration),
        start_time=start_time,
        color=color,
        font_size=font_size,
        stroke_color=stroke_color,
        stroke_width=stroke_width,
    )
    return output_path


def render_lower_third(
    video_path: Path,
    text: str,
    start_time: float,
    duration: float,
    config: CaptionConfig,
    output_path: Path,
) -> Path:
    """Render a lower-third social handle bar using slide_left_text.

    Args:
        video_path: Path to the source video file.
        text: Handle or name text, e.g. ``"@username"``.
        start_time: Start time in seconds.
        duration: Display duration in seconds.
        config: Active CaptionConfig instance.
        output_path: Desired output path.

    Returns:
        Path to the rendered output video.
    """
    import text_fx  # noqa: PLC0415

    color = config.color or "#FFFFFF"
    font_size = config.font_size or 56

    _log.debug(f"render_lower_third: {text!r} at t={start_time:.2f}")

    text_fx.apply_text_effect(
        video=str(video_path),
        text=text,
        effect="slide_left_text",
        output=str(output_path),
        duration=max(0.1, duration),
        start_time=start_time,
        color=color,
        font_size=font_size,
    )
    return output_path
