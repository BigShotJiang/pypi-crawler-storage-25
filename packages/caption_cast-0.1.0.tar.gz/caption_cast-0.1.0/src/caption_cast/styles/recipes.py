# Filepath: caption_cast/styles/recipes.py
# Condensed Description: Dispatch table mapping caption style slugs to rendering parameters
# Architecture Layer: Styles
# Environment: Both
# Script Hierarchy: STYLE_RECIPES, get_recipe
# Dependencies: Internal: caption_cast.exceptions; External: none; Providers: none
# Exposes: STYLE_RECIPES, get_recipe
# Configuration: None
from __future__ import annotations

import logging

from caption_cast.exceptions import UnknownStyleError

_log = logging.getLogger(__name__)

STYLE_RECIPES: dict[str, dict] = {
    "pop_caption": {
        "per_word_animation": "kinetic_pop",
        "per_line_animation": None,
        "split_mode": "word",
        "word_stagger": 0.08,
        "default_position": "center",
        "default_color": "#FFFFFF",
        "default_font_size": 96,
        "default_font_weight": "black",
        "default_stroke": {"color": "#000000", "width": 6},
    },
    "karaoke_highlight": {
        "per_word_animation": None,
        "per_line_animation": None,
        "split_mode": "word",
        "word_stagger": 0.0,
        "default_position": "bottom",
        "default_color": "#FFFFFF",
        "default_font_size": 72,
        "default_font_weight": "bold",
        "default_stroke": None,
    },
    "lyric_bounce": {
        "per_word_animation": None,
        "per_line_animation": "bounce_text",
        "split_mode": "line",
        "word_stagger": 0.0,
        "default_position": "center",
        "default_color": "#FFFFFF",
        "default_font_size": 88,
        "default_font_weight": "black",
        "default_stroke": {"color": "#000000", "width": 4},
    },
    "emoji_caption": {
        "per_word_animation": "kinetic_pop",
        "per_line_animation": None,
        "split_mode": "word",
        "word_stagger": 0.05,
        "default_position": "bottom",
        "default_color": "#FFFFFF",
        "default_font_size": 80,
        "default_font_weight": "bold",
        "default_stroke": None,
    },
    "sticker_text": {
        "per_word_animation": None,
        "per_line_animation": "fade_in",
        "split_mode": "all",
        "word_stagger": 0.0,
        "default_position": "center",
        "default_color": "#FFFFFF",
        "default_font_size": 80,
        "default_font_weight": "black",
        "default_stroke": {"color": "#000000", "width": 8},
    },
    "meme_caption_top": {
        "per_word_animation": None,
        "per_line_animation": "fade_in",
        "split_mode": "all",
        "word_stagger": 0.0,
        "default_position": "top",
        "default_color": "#FFFFFF",
        "default_font_size": 80,
        "default_font_weight": "black",
        "default_stroke": {"color": "#000000", "width": 6},
    },
    "meme_caption_bottom": {
        "per_word_animation": None,
        "per_line_animation": "fade_in",
        "split_mode": "all",
        "word_stagger": 0.0,
        "default_position": "bottom",
        "default_color": "#FFFFFF",
        "default_font_size": 80,
        "default_font_weight": "black",
        "default_stroke": {"color": "#000000", "width": 6},
    },
    "subtitle_burn_in": {
        "per_word_animation": None,
        "per_line_animation": "fade_in",
        "split_mode": "line",
        "word_stagger": 0.0,
        "default_position": "bottom",
        "default_color": "#FFFFFF",
        "default_font_size": 56,
        "default_font_weight": "regular",
        "default_stroke": {"color": "#000000", "width": 2},
    },
    "auto_caption_box": {
        "per_word_animation": None,
        "per_line_animation": "fade_in",
        "split_mode": "line",
        "word_stagger": 0.0,
        "default_position": "bottom",
        "default_color": "#FFFFFF",
        "default_font_size": 56,
        "default_font_weight": "regular",
        "default_stroke": None,
    },
    "word_emphasis_pop": {
        "per_word_animation": "kinetic_pop",
        "per_line_animation": None,
        "split_mode": "word",
        "word_stagger": 0.05,
        "default_position": "center",
        "default_color": "#FFFFFF",
        "default_font_size": 80,
        "default_font_weight": "bold",
        "default_stroke": None,
    },
    "reaction_text": {
        "per_word_animation": None,
        "per_line_animation": "kinetic_pop",
        "split_mode": "all",
        "word_stagger": 0.0,
        "default_position": "center",
        "default_color": "#FFFFFF",
        "default_font_size": 112,
        "default_font_weight": "black",
        "default_stroke": {"color": "#000000", "width": 6},
    },
    "comment_bubble": {
        "per_word_animation": None,
        "per_line_animation": "slide_left_text",
        "split_mode": "all",
        "word_stagger": 0.0,
        "default_position": "bottom",
        "default_color": "#000000",
        "default_font_size": 52,
        "default_font_weight": "regular",
        "default_stroke": None,
    },
    "dm_bubble": {
        "per_word_animation": None,
        "per_line_animation": "slide_right_text",
        "split_mode": "all",
        "word_stagger": 0.0,
        "default_position": "bottom",
        "default_color": "#000000",
        "default_font_size": 48,
        "default_font_weight": "regular",
        "default_stroke": None,
    },
    "hashtag_sticker": {
        "per_word_animation": None,
        "per_line_animation": "fade_in",
        "split_mode": "all",
        "word_stagger": 0.0,
        "default_position": "center",
        "default_color": "#FFFFFF",
        "default_font_size": 60,
        "default_font_weight": "bold",
        "default_stroke": None,
    },
    "callout_arrow_text": {
        "per_word_animation": None,
        "per_line_animation": "fade_in",
        "split_mode": "all",
        "word_stagger": 0.0,
        "default_position": "center",
        "default_color": "#FFFFFF",
        "default_font_size": 52,
        "default_font_weight": "bold",
        "default_stroke": None,
    },
    "speech_balloon": {
        "per_word_animation": None,
        "per_line_animation": "kinetic_pop",
        "split_mode": "all",
        "word_stagger": 0.0,
        "default_position": "center",
        "default_color": "#000000",
        "default_font_size": 56,
        "default_font_weight": "regular",
        "default_stroke": None,
    },
    "comic_sfx_text": {
        "per_word_animation": None,
        "per_line_animation": "kinetic_pop",
        "split_mode": "all",
        "word_stagger": 0.0,
        "default_position": "center",
        "default_color": "#FFFF00",
        "default_font_size": 120,
        "default_font_weight": "black",
        "default_stroke": {"color": "#000000", "width": 8},
    },
    "lower_third_social_handle": {
        "per_word_animation": None,
        "per_line_animation": "slide_left_text",
        "split_mode": "all",
        "word_stagger": 0.0,
        "default_position": "lower_third",
        "default_color": "#FFFFFF",
        "default_font_size": 56,
        "default_font_weight": "bold",
        "default_stroke": None,
    },
    "countdown_text": {
        "per_word_animation": None,
        "per_line_animation": "kinetic_pop",
        "split_mode": "all",
        "word_stagger": 0.0,
        "default_position": "center",
        "default_color": "#FFFFFF",
        "default_font_size": 160,
        "default_font_weight": "black",
        "default_stroke": {"color": "#000000", "width": 8},
    },
    "poll_text": {
        "per_word_animation": None,
        "per_line_animation": "fade_in",
        "split_mode": "all",
        "word_stagger": 0.0,
        "default_position": "center",
        "default_color": "#FFFFFF",
        "default_font_size": 60,
        "default_font_weight": "bold",
        "default_stroke": None,
    },
}


def get_recipe(style_slug: str) -> dict:
    """Return the rendering recipe dict for a given style slug.

    Args:
        style_slug: A caption style identifier, e.g. ``"pop_caption"``.

    Returns:
        The recipe dict from :data:`STYLE_RECIPES`.

    Raises:
        UnknownStyleError: If the slug is not in the dispatch table.
    """
    if style_slug not in STYLE_RECIPES:
        raise UnknownStyleError(style_slug)
    return STYLE_RECIPES[style_slug]
