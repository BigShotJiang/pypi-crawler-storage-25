# Filepath: caption_cast/styles/beat_bounce.py
# Condensed Description: Beat-synced text bounce renderer dropping lines on detected beat times
# Architecture Layer: Styles
# Environment: Both
# Script Hierarchy: render_beat_bounce
# Dependencies: Internal: caption_cast.config; External: text_fx; Providers: none
# Exposes: render_beat_bounce
# Configuration: None
from __future__ import annotations

import logging
import shutil
from pathlib import Path

from caption_cast.config import CaptionConfig

_log = logging.getLogger(__name__)


def render_beat_bounce(
    video_path: Path,
    text_lines: list[str],
    beat_times: list[float],
    config: CaptionConfig,
    output_path: Path,
) -> Path:
    """Drop text lines onto the video on beat timestamps using text-fx bounce_text.

    Lines and beat times are paired by index; extra beats or lines are
    silently ignored via ``zip(strict=False)``.

    Args:
        video_path: Path to the source video file.
        text_lines: List of caption lines, one per beat.
        beat_times: Beat onset timestamps in seconds.
        config: Active CaptionConfig instance.
        output_path: Desired path for the final output video.

    Returns:
        Path to the rendered output video.
    """
    import text_fx  # noqa: PLC0415

    color = config.color or "#FFFFFF"
    font_size = config.font_size or 88

    current_video = video_path

    for idx, (line, beat_t) in enumerate(zip(text_lines, beat_times, strict=False)):
        line_out = output_path.parent / f"_beat_{idx:04d}.mp4"

        _log.debug(f"Beat bounce line {idx} at t={beat_t:.2f}: {line!r}")

        text_fx.apply_text_effect(
            video=str(current_video),
            text=line,
            effect="bounce_text",
            output=str(line_out),
            duration=0.8,
            start_time=beat_t,
            color=color,
            font_size=font_size,
        )
        current_video = line_out

    shutil.copy2(str(current_video), str(output_path))
    return output_path
