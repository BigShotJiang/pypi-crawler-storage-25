# Filepath: caption_cast/styles/word_pop.py
# Condensed Description: Per-word pop animation renderer using text-fx
# Architecture Layer: Styles
# Environment: Both
# Script Hierarchy: render_word_pop
# Dependencies: Internal: caption_cast.config, caption_cast.lyrics.normalize; External: text_fx; Providers: none
# Exposes: render_word_pop
# Configuration: None
from __future__ import annotations

import logging
import shutil
from pathlib import Path

from caption_cast.config import CaptionConfig
from caption_cast.lyrics.normalize import TimedWord

_log = logging.getLogger(__name__)


def render_word_pop(
    video_path: Path,
    words: list[TimedWord],
    recipe: dict,
    config: CaptionConfig,
    canvas_size: tuple[int, int],
    output_path: Path,
) -> Path:
    """Apply per-word pop animation to a video using text-fx.

    Each word is applied sequentially; the output of each iteration becomes
    the input of the next so all words accumulate on the clip.

    Args:
        video_path: Path to the source video file.
        words: Ordered list of timed words to animate.
        recipe: Style recipe dict from :mod:`caption_cast.styles.recipes`.
        config: Active CaptionConfig instance.
        canvas_size: ``(width, height)`` of the video canvas.
        output_path: Desired path for the final output video.

    Returns:
        Path to the rendered output video.
    """
    import text_fx  # noqa: PLC0415

    effect_slug = recipe.get("per_word_animation") or "fade_in"
    color = config.color or recipe.get("default_color", "#FFFFFF")
    font_size = config.font_size or recipe.get("default_font_size", 72)
    stroke = recipe.get("default_stroke") or {}

    current_video = video_path

    for idx, word in enumerate(words):
        word_out = output_path.parent / f"_word_{idx:04d}.mp4"
        duration = max(0.1, word.end - word.start)

        _log.debug(f"Applying {effect_slug!r} to word {word.text!r} at t={word.start:.2f}")

        text_fx.apply_text_effect(
            video=str(current_video),
            text=word.text,
            effect=effect_slug,
            output=str(word_out),
            duration=duration,
            start_time=word.start,
            color=color,
            font_size=font_size,
            stroke_color=stroke.get("color"),
            stroke_width=stroke.get("width", 0),
        )
        current_video = word_out

    shutil.copy2(str(current_video), str(output_path))
    return output_path
