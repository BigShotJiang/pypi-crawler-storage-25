# Filepath: caption_cast/styles/subtitle.py
# Condensed Description: Subtitle burn-in and auto caption box renderers
# Architecture Layer: Styles
# Environment: Both
# Script Hierarchy: render_subtitle_burn_in, render_auto_caption_box
# Dependencies: Internal: caption_cast.config, caption_cast.lyrics.normalize; External: text_fx; Providers: none
# Exposes: render_subtitle_burn_in, render_auto_caption_box
# Configuration: None
from __future__ import annotations

import logging
import shutil
from pathlib import Path

from caption_cast.config import CaptionConfig
from caption_cast.lyrics.normalize import TimedLine

_log = logging.getLogger(__name__)


def _burn_lines(
    video_path: Path,
    timed_lines: list[TimedLine],
    config: CaptionConfig,
    output_path: Path,
    effect: str,
    default_color: str,
    default_font_size: int,
    stroke_color: str | None,
    stroke_width: int,
) -> Path:
    """Shared implementation for line-by-line subtitle burn-in.

    Args:
        video_path: Path to the source video.
        timed_lines: Ordered list of timed subtitle lines.
        config: Active CaptionConfig.
        output_path: Desired output path.
        effect: text-fx effect slug.
        default_color: Fallback text colour.
        default_font_size: Fallback font size.
        stroke_color: Stroke colour or None.
        stroke_width: Stroke width in pixels.

    Returns:
        Path to the rendered output video.
    """
    import text_fx  # noqa: PLC0415

    color = config.color or default_color
    font_size = config.font_size or default_font_size
    eff_stroke_color = config.stroke_color or stroke_color
    eff_stroke_width = config.stroke_width if config.stroke_width is not None else stroke_width

    current_video = video_path

    for idx, line in enumerate(timed_lines):
        if not line.text.strip():
            continue
        line_out = output_path.parent / f"_sub_{idx:04d}.mp4"
        duration = max(0.1, line.end - line.start)

        _log.debug(f"Burning subtitle line {idx} at t={line.start:.2f}: {line.text!r}")

        text_fx.apply_text_effect(
            video=str(current_video),
            text=line.text,
            effect=effect,
            output=str(line_out),
            duration=duration,
            start_time=line.start,
            color=color,
            font_size=font_size,
            stroke_color=eff_stroke_color,
            stroke_width=eff_stroke_width,
        )
        current_video = line_out

    shutil.copy2(str(current_video), str(output_path))
    return output_path


def render_subtitle_burn_in(
    video_path: Path,
    timed_lines: list[TimedLine],
    config: CaptionConfig,
    output_path: Path,
) -> Path:
    """Burn subtitle lines onto the video with a simple fade-in per line.

    Args:
        video_path: Path to the source video file.
        timed_lines: Ordered list of timed subtitle lines.
        config: Active CaptionConfig instance.
        output_path: Desired output path.

    Returns:
        Path to the rendered output video.
    """
    return _burn_lines(
        video_path=video_path,
        timed_lines=timed_lines,
        config=config,
        output_path=output_path,
        effect="fade_in",
        default_color="#FFFFFF",
        default_font_size=56,
        stroke_color="#000000",
        stroke_width=2,
    )


def render_auto_caption_box(
    video_path: Path,
    timed_lines: list[TimedLine],
    config: CaptionConfig,
    output_path: Path,
) -> Path:
    """Burn subtitle lines inside a semi-transparent caption box.

    The box background is a future v0.2 enhancement; v0.1 applies text
    via fade_in without the box overlay.

    Args:
        video_path: Path to the source video file.
        timed_lines: Ordered list of timed subtitle lines.
        config: Active CaptionConfig instance.
        output_path: Desired output path.

    Returns:
        Path to the rendered output video.
    """
    return _burn_lines(
        video_path=video_path,
        timed_lines=timed_lines,
        config=config,
        output_path=output_path,
        effect="fade_in",
        default_color="#FFFFFF",
        default_font_size=56,
        stroke_color=None,
        stroke_width=0,
    )
