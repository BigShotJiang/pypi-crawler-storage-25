# Filepath: caption_cast/styles/loader.py
# Condensed Description: Load and query caption style metadata from bundled JSON catalog
# Architecture Layer: Styles
# Environment: Both
# Script Hierarchy: load_styles, get_style
# Dependencies: Internal: caption_cast.data, caption_cast.exceptions; External: none; Providers: none
# Exposes: load_styles, get_style
# Configuration: None
from __future__ import annotations

import importlib.resources as pkg_resources
import json
import logging

from caption_cast.exceptions import UnknownStyleError

_log = logging.getLogger(__name__)

_STYLES_CACHE: list[dict] | None = None


def load_styles() -> list[dict]:
    """Return the list of style dicts from the bundled caption_styles.json.

    Returns:
        A list of style metadata dicts, each containing at minimum 'slug' and 'name'.
    """
    global _STYLES_CACHE
    if _STYLES_CACHE is not None:
        return _STYLES_CACHE

    ref = pkg_resources.files("caption_cast.data").joinpath("caption_styles.json")
    raw = json.loads(ref.read_text(encoding="utf-8"))
    _STYLES_CACHE = raw["transitions"]
    _log.debug(f"Loaded {len(_STYLES_CACHE)} caption styles from catalog")
    return _STYLES_CACHE


def get_style(slug: str) -> dict:
    """Get a style metadata dict by slug.

    Args:
        slug: The style identifier, e.g. ``"pop_caption"``.

    Returns:
        The style metadata dict.

    Raises:
        UnknownStyleError: If no style with the given slug exists in the catalog.
    """
    for style in load_styles():
        if style["slug"] == slug:
            return style
    raise UnknownStyleError(slug)
