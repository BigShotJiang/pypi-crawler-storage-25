# Filepath: caption_cast/emoji/render.py
# Condensed Description: Emoji detection, stripping, and best-effort PIL rendering
# Architecture Layer: Emoji
# Environment: Both
# Script Hierarchy: has_emoji, strip_emoji, render_emoji
# Dependencies: Internal: caption_cast.exceptions; External: Pillow; Providers: none
# Exposes: has_emoji, strip_emoji, render_emoji
# Configuration: None
from __future__ import annotations

import logging
import re

_log = logging.getLogger(__name__)

_EMOJI_PATTERN = re.compile(
    "[\U0001f300-\U0001ffff\U00002600-\U000027bf\U0001f900-\U0001f9ff]",
    flags=re.UNICODE,
)


def has_emoji(text: str) -> bool:
    """Return True if the text contains at least one emoji character.

    Args:
        text: Input string to check.

    Returns:
        True when an emoji codepoint is found, False otherwise.
    """
    return bool(_EMOJI_PATTERN.search(text))


def strip_emoji(text: str) -> str:
    """Remove all emoji characters from the text and strip surrounding whitespace.

    Args:
        text: Input string.

    Returns:
        Text with emoji codepoints removed and leading/trailing whitespace stripped.
    """
    return _EMOJI_PATTERN.sub("", text).strip()


def render_emoji(emoji_char: str, size: int = 64) -> object | None:
    """Render a single emoji character to a square RGBA PIL image.

    Falls back to None when Pillow cannot render the glyph (e.g. no colour
    emoji font is available on the system).

    Args:
        emoji_char: A single emoji character or ZWJ sequence.
        size: Side length of the output square in pixels.

    Returns:
        An RGBA Pillow Image, or None if rendering failed.
    """
    try:
        from PIL import Image, ImageDraw  # noqa: PLC0415

        img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)
        # PIL's default font has very limited emoji coverage; this is a best-effort
        # attempt — callers should handle None gracefully.
        draw.text((0, 0), emoji_char, fill=(255, 255, 255, 255))
        return img
    except Exception as exc:
        _log.debug(f"Emoji render failed for {emoji_char!r}: {exc}")
        return None
