# Filepath: caption_cast/emoji/__init__.py
# Condensed Description: Emoji sub-package marker
# Architecture Layer: Emoji
# Environment: Both
# Script Hierarchy: none
# Dependencies: Internal: none; External: none; Providers: none
# Exposes: none
# Configuration: None
from __future__ import annotations
