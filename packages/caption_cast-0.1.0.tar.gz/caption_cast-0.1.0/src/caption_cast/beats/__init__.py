# Filepath: caption_cast/beats/__init__.py
# Condensed Description: Beats sub-package marker
# Architecture Layer: Beats
# Environment: Both
# Script Hierarchy: none
# Dependencies: Internal: none; External: none; Providers: none
# Exposes: none
# Configuration: None
from __future__ import annotations
