# Filepath: caption_cast/beats/detector.py
# Condensed Description: Beat detection facade over audio-arrange optional dependency
# Architecture Layer: Beats
# Environment: Both
# Script Hierarchy: detect_beats
# Dependencies: Internal: caption_cast.exceptions; External: audio-arrange (optional); Providers: none
# Exposes: detect_beats
# Configuration: None
from __future__ import annotations

import logging
from pathlib import Path

_log = logging.getLogger(__name__)


def detect_beats(audio_path: str | Path, bpm_hint: float | None = None) -> list[float]:
    """Detect beat timestamps (in seconds) from an audio or video file.

    Args:
        audio_path: Path to the audio or video file to analyse.
        bpm_hint: Optional BPM hint to guide the detector.

    Returns:
        Sorted list of beat onset timestamps in seconds.

    Raises:
        ImportError: If ``audio-arrange`` is not installed.
    """
    try:
        from audio_arrange import detect_beats as aa_beats  # noqa: PLC0415
    except ImportError as exc:
        raise ImportError(
            "audio-arrange is required for beat detection. Install: pip install caption-cast[beats]"
        ) from exc

    _log.debug(f"Running beat detection on {audio_path} (bpm_hint={bpm_hint})")
    kwargs: dict = {}
    if bpm_hint is not None:
        kwargs["bpm_hint"] = bpm_hint
    beats: list[float] = aa_beats(str(audio_path), **kwargs)
    _log.debug(f"Detected {len(beats)} beats")
    return beats
