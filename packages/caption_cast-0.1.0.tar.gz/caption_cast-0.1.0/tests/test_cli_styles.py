"""Tests for the caption-cast CLI: styles, info subcommands."""

from __future__ import annotations

import json
import subprocess
import sys


def _run(*args: str) -> subprocess.CompletedProcess:
    """Run caption-cast CLI via the current Python interpreter's entry point."""
    return subprocess.run(
        [sys.executable, "-m", "caption_cast.cli", *args],
        capture_output=True,
        text=True,
    )


def test_cli_styles_returns_20_lines():
    result = _run("styles")
    assert result.returncode == 0, f"stderr: {result.stderr}"
    lines = [ln for ln in result.stdout.strip().splitlines() if ln.strip()]
    assert len(lines) == 20, f"Expected 20 style lines, got {len(lines)}: {lines}"


def test_cli_info_known_style():
    result = _run("info", "pop_caption")
    assert result.returncode == 0, f"stderr: {result.stderr}"
    assert "pop_caption" in result.stdout


def test_cli_info_unknown_style():
    result = _run("info", "nonexistent_style_xyz")
    assert result.returncode != 0, "Expected non-zero exit for unknown style"


def test_cli_info_returns_json():
    result = _run("info", "pop_caption")
    assert result.returncode == 0, f"stderr: {result.stderr}"
    data = json.loads(result.stdout)
    assert data["slug"] == "pop_caption"


def test_cli_styles_category_filter():
    result = _run("styles", "--category", "social_caption")
    assert result.returncode == 0, f"stderr: {result.stderr}"
    lines = [ln for ln in result.stdout.strip().splitlines() if ln.strip()]
    assert len(lines) == 20
