"""Tests for caption_cast.layout.safe_area: safe_area_insets and caption_y_position."""

from __future__ import annotations

from caption_cast.layout.safe_area import caption_y_position, safe_area_insets


def test_safe_area_standard_padding():
    insets = safe_area_insets((1920, 1080), zone="standard", padding=80)
    assert insets["top"] == 80
    assert insets["bottom"] == 80
    assert insets["left"] == 80
    assert insets["right"] == 80


def test_safe_area_minimal_less_than_standard():
    minimal = safe_area_insets((1920, 1080), zone="minimal", padding=80)
    standard = safe_area_insets((1920, 1080), zone="standard", padding=80)
    assert minimal["bottom"] < standard["bottom"]


def test_safe_area_max_greater_than_standard():
    maximum = safe_area_insets((1920, 1080), zone="max", padding=80)
    standard = safe_area_insets((1920, 1080), zone="standard", padding=80)
    assert maximum["bottom"] > standard["bottom"]


def test_caption_y_bottom():
    canvas = (1920, 1080)
    text_height = 60
    insets = safe_area_insets(canvas, zone="standard", padding=80)
    y = caption_y_position("bottom", canvas, text_height, insets)
    # Bottom y should be near the bottom: height - text_height - inset
    expected = 1080 - text_height - insets["bottom"]
    assert y == expected
    # Sanity: value is in the lower half of the canvas
    assert y > canvas[1] // 2
