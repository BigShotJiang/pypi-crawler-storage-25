"""Tests for CaptionConfig pydantic model."""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from caption_cast.config import CaptionConfig


def test_caption_config_defaults():
    cfg = CaptionConfig(style="pop_caption")
    assert cfg.position == "bottom"
    assert cfg.burn_in is True


def test_caption_config_extra_field_raises():
    with pytest.raises(ValidationError):
        CaptionConfig(style="x", unknown_field=1)


def test_caption_config_font_weight_valid():
    cfg = CaptionConfig(style="pop_caption", font_weight="bold")
    assert cfg.font_weight == "bold"


def test_caption_config_font_weight_invalid():
    with pytest.raises(ValidationError):
        CaptionConfig(style="pop_caption", font_weight="ultralight")
