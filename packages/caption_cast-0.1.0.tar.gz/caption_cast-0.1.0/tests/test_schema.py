"""Tests for caption_cast.schema.generator: caption_schema and schema_json."""

from __future__ import annotations

import json

from caption_cast.schema.generator import caption_schema, schema_json


def test_schema_has_20_style_slugs():
    schema = caption_schema()
    style_enum = schema["properties"]["style"]["enum"]
    assert len(style_enum) == 20


def test_schema_json_valid_json():
    raw = schema_json()
    parsed = json.loads(raw)
    assert isinstance(parsed, dict)


def test_schema_json_pretty():
    pretty = schema_json(pretty=True)
    assert "\n" in pretty


def test_schema_has_required_fields():
    schema = caption_schema()
    assert "required" in schema
    assert "style" in schema["required"]
    assert "text" in schema["required"]


def test_schema_properties_present():
    schema = caption_schema()
    props = schema["properties"]
    assert "style" in props
    assert "text" in props
    assert "start_time" in props
    assert "duration" in props
