"""Tests for SRT subtitle file parsing."""

from __future__ import annotations

import pytest

from caption_cast.lyrics.normalize import TimedLine
from caption_cast.lyrics.parser import parse_file


def test_parse_srt_returns_timed_lines(sample_srt):
    lines = parse_file(sample_srt)
    assert len(lines) == 3
    assert all(isinstance(ln, TimedLine) for ln in lines)


def test_parse_srt_start_end_correct(sample_srt):
    lines = parse_file(sample_srt)
    assert lines[0].start == pytest.approx(0.0)
    assert lines[0].end == pytest.approx(1.5)


def test_parse_srt_text_content(sample_srt):
    lines = parse_file(sample_srt)
    assert lines[0].text == "Hello world"
