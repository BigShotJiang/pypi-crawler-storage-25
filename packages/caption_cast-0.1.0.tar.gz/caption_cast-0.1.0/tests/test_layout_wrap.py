"""Tests for caption_cast.layout.wrap: wrap_text."""

from __future__ import annotations

from caption_cast.layout.wrap import wrap_text


def test_wrap_respects_max_words():
    text = "one two three four five six seven eight nine ten"
    lines = wrap_text(text, max_words=5, max_chars=200)
    assert len(lines) >= 2


def test_wrap_respects_max_chars():
    # Each word is 8 chars; with max_chars=20, at most 2 words fit (8+1+8=17 <= 20, but 17+1+8=26 > 20)
    text = "longword longword longword longword"
    lines = wrap_text(text, max_words=10, max_chars=20)
    assert len(lines) >= 2
    for ln in lines:
        assert len(ln) <= 20, f"Line exceeds max_chars=20: {ln!r}"


def test_wrap_short_text_one_line():
    text = "hello world foo"
    lines = wrap_text(text, max_words=6, max_chars=42)
    assert len(lines) == 1
    assert lines[0] == "hello world foo"
