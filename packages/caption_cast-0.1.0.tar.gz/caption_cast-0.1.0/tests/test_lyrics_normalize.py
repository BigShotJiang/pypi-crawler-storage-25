"""Tests for caption_cast.lyrics.normalize: lines_from_dicts and TimedLine."""

from __future__ import annotations

from caption_cast.lyrics.normalize import TimedLine, TimedWord, lines_from_dicts


def test_lines_from_dicts_basic():
    data = [
        {"text": "Hello", "start": 0.0, "end": 1.5},
        {"text": "World", "start": 1.5, "end": 3.0},
    ]
    result = lines_from_dicts(data)
    assert len(result) == 2
    assert all(isinstance(ln, TimedLine) for ln in result)
    assert result[0].text == "Hello"
    assert result[0].start == 0.0
    assert result[0].end == 1.5


def test_timed_line_has_words_when_provided():
    data = [
        {
            "text": "Hello world",
            "start": 0.0,
            "end": 2.0,
            "words": [
                {"text": "Hello", "start": 0.0, "end": 1.0},
                {"text": "world", "start": 1.0, "end": 2.0},
            ],
        }
    ]
    result = lines_from_dicts(data)
    assert result[0].words is not None
    assert len(result[0].words) == 2
    assert all(isinstance(w, TimedWord) for w in result[0].words)
    assert result[0].words[0].text == "Hello"


def test_timed_line_words_none_when_absent():
    data = [{"text": "No words", "start": 0.0, "end": 1.0}]
    result = lines_from_dicts(data)
    assert result[0].words is None
