"""Shared fixtures for caption-cast test suite."""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

import pytest


@pytest.fixture(scope="session", autouse=True)
def ensure_venv_on_path():
    scripts_dir = str(Path(sys.executable).parent)
    current_path = os.environ.get("PATH", "")
    if scripts_dir not in current_path:
        os.environ["PATH"] = scripts_dir + os.pathsep + current_path


@pytest.fixture(scope="session")
def tiny_video(tmp_path_factory):
    out = tmp_path_factory.mktemp("clips") / "bg.mp4"
    subprocess.run(
        [
            "ffmpeg",
            "-y",
            "-f",
            "lavfi",
            "-i",
            "color=darkblue:s=640x360:d=5",
            "-f",
            "lavfi",
            "-i",
            "sine=frequency=440:duration=5",
            "-c:v",
            "libx264",
            "-pix_fmt",
            "yuv420p",
            "-c:a",
            "aac",
            "-shortest",
            str(out),
        ],
        check=True,
        capture_output=True,
    )
    return out


@pytest.fixture(scope="session")
def sample_srt(tmp_path_factory):
    """Write a simple 3-line SRT file."""
    srt_dir = tmp_path_factory.mktemp("subs")
    srt_path = srt_dir / "test.srt"
    srt_path.write_text(
        "1\n00:00:00,000 --> 00:00:01,500\nHello world\n\n"
        "2\n00:00:01,500 --> 00:00:03,000\nThis is a test\n\n"
        "3\n00:00:03,000 --> 00:00:05,000\nCaption three\n",
        encoding="utf-8",
    )
    return srt_path


@pytest.fixture(scope="session")
def sample_lrc(tmp_path_factory):
    lrc_dir = tmp_path_factory.mktemp("lrc")
    lrc_path = lrc_dir / "test.lrc"
    lrc_path.write_text(
        "[00:00.00]Hello world\n[00:01.50]This is a test\n[00:03.00]Final line\n",
        encoding="utf-8",
    )
    return lrc_path
