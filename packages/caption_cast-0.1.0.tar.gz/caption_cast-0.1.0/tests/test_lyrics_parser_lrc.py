"""Tests for LRC lyric file parsing."""

from __future__ import annotations

from caption_cast.lyrics.normalize import TimedLine
from caption_cast.lyrics.parser import parse_file


def test_parse_lrc_returns_timed_lines(sample_lrc):
    lines = parse_file(sample_lrc)
    assert len(lines) == 3
    assert all(isinstance(ln, TimedLine) for ln in lines)


def test_parse_lrc_start_times_correct(sample_lrc):
    lines = parse_file(sample_lrc)
    assert lines[0].start == 0.0
    assert lines[1].start == 1.5


def test_parse_lrc_text_nonempty(sample_lrc):
    lines = parse_file(sample_lrc)
    for ln in lines:
        assert ln.text.strip(), f"Line text is empty: {ln!r}"
