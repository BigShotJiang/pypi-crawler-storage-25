"""Tests for caption_cast.beats.detector when audio-arrange is unavailable."""

from __future__ import annotations

import builtins
import sys
from unittest.mock import patch

import pytest

_real_import = builtins.__import__


def _make_blocking_import(blocked: str):
    def _import(name, *args, **kwargs):
        if name == blocked:
            raise ImportError(f"{blocked} is not installed (test-induced block)")
        return _real_import(name, *args, **kwargs)

    return _import


def test_detect_beats_without_audio_arrange_raises(tmp_path):
    """detect_beats must raise ImportError when audio_arrange is not available."""
    from caption_cast.beats.detector import detect_beats

    dummy_audio = tmp_path / "dummy.wav"
    dummy_audio.write_bytes(b"\x00" * 44)  # minimal placeholder

    # Remove cached module so the import inside detect_beats actually executes
    saved = sys.modules.pop("audio_arrange", None)
    try:
        with (
            patch("builtins.__import__", side_effect=_make_blocking_import("audio_arrange")),
            pytest.raises(ImportError, match="audio-arrange"),
        ):
            detect_beats(str(dummy_audio))
    finally:
        if saved is not None:
            sys.modules["audio_arrange"] = saved
