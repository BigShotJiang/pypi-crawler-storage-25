"""Tests for caption_cast.styles.recipes: get_recipe and STYLE_RECIPES."""

from __future__ import annotations

import pytest

from caption_cast.exceptions import UnknownStyleError
from caption_cast.styles.recipes import STYLE_RECIPES, get_recipe

ALL_SLUGS = [
    "pop_caption",
    "karaoke_highlight",
    "lyric_bounce",
    "emoji_caption",
    "sticker_text",
    "meme_caption_top",
    "meme_caption_bottom",
    "subtitle_burn_in",
    "auto_caption_box",
    "word_emphasis_pop",
    "reaction_text",
    "comment_bubble",
    "dm_bubble",
    "hashtag_sticker",
    "callout_arrow_text",
    "speech_balloon",
    "comic_sfx_text",
    "lower_third_social_handle",
    "countdown_text",
    "poll_text",
]


def test_all_recipes_present():
    for slug in ALL_SLUGS:
        recipe = get_recipe(slug)
        assert isinstance(recipe, dict), f"Recipe for {slug!r} is not a dict"


def test_recipe_has_required_keys():
    for slug in ALL_SLUGS:
        recipe = get_recipe(slug)
        assert "split_mode" in recipe, f"Missing 'split_mode' in {slug!r} recipe"
        assert "default_color" in recipe, f"Missing 'default_color' in {slug!r} recipe"
        assert "default_font_size" in recipe, f"Missing 'default_font_size' in {slug!r} recipe"


def test_unknown_recipe_raises():
    with pytest.raises(UnknownStyleError):
        get_recipe("nonexistent")


def test_style_recipes_count():
    assert len(STYLE_RECIPES) == 20
