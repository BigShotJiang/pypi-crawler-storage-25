"""Tests for the styles catalog: list_styles and get_style_info."""

from __future__ import annotations

import pytest

from caption_cast import get_style_info, list_styles
from caption_cast.exceptions import UnknownStyleError


def test_list_styles_returns_20():
    assert len(list_styles()) == 20


def test_all_slugs_nonempty():
    for slug in list_styles():
        assert isinstance(slug, str) and slug.strip(), f"Slug is empty or not a string: {slug!r}"


def test_get_style_info_known_slug():
    info = get_style_info("pop_caption")
    assert isinstance(info, dict)
    assert "slug" in info
    assert info["slug"] == "pop_caption"


def test_get_style_info_unknown_raises():
    with pytest.raises(UnknownStyleError):
        get_style_info("nonexistent_style")


def test_list_styles_category_filter():
    filtered = list_styles(category="social_caption")
    assert len(filtered) == 20
