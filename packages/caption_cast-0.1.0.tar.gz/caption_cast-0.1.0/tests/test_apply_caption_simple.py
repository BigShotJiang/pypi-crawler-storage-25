"""Tests for the top-level apply_caption API."""

from __future__ import annotations

from pathlib import Path

from caption_cast import apply_caption


def test_apply_caption_subtitle_burn_in(tiny_video, tmp_path):
    out = tmp_path / "subtitle_burn_in.mp4"
    result = apply_caption(
        video=str(tiny_video),
        text="Hello World",
        style="subtitle_burn_in",
        start_time=0.5,
        duration=2.0,
        output=str(out),
    )
    assert out.exists()
    assert out.stat().st_size > 0
    assert Path(result) == out


def test_apply_caption_meme_top(tiny_video, tmp_path):
    out = tmp_path / "meme_caption_top.mp4"
    result = apply_caption(
        video=str(tiny_video),
        text="MEME TEXT",
        style="meme_caption_top",
        start_time=0.0,
        duration=2.0,
        output=str(out),
    )
    assert out.exists()
    assert out.stat().st_size > 0
    assert Path(result) == out


def test_apply_caption_sticker(tiny_video, tmp_path):
    out = tmp_path / "sticker_text.mp4"
    result = apply_caption(
        video=str(tiny_video),
        text="STICKER",
        style="sticker_text",
        start_time=1.0,
        duration=1.5,
        output=str(out),
    )
    assert out.exists()
    assert out.stat().st_size > 0
    assert Path(result) == out


def test_apply_caption_output_defaults(tiny_video, tmp_path):
    # When output=None the function must return a Path
    # We derive the output from tiny_video's stem, which lives in a session tmp dir.
    # Instead: pass a video we copy to a writable tmp location so the default output
    # can be created there without touching the session fixture.
    import shutil

    local_video = tmp_path / "bg.mp4"
    shutil.copy2(str(tiny_video), str(local_video))

    result = apply_caption(
        video=str(local_video),
        text="Default output",
        style="poll_text",
        start_time=0.0,
        duration=1.0,
        output=None,
    )
    assert isinstance(result, Path)
    assert result.exists()
    assert result.stat().st_size > 0
