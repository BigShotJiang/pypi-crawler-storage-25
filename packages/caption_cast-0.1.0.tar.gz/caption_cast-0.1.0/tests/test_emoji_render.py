"""Tests for caption_cast.emoji.render: has_emoji, strip_emoji."""

from __future__ import annotations

from caption_cast.emoji.render import has_emoji, strip_emoji


def test_has_emoji_detects_emoji():
    assert has_emoji("Hello \U0001f600") is True


def test_has_emoji_no_emoji():
    assert has_emoji("Hello World") is False


def test_strip_emoji_removes_emoji():
    result = strip_emoji("Hello \U0001f600")
    assert "\U0001f600" not in result
    assert "Hello" in result


def test_strip_emoji_pure_text_unchanged():
    result = strip_emoji("No emoji here")
    assert result == "No emoji here"


def test_has_emoji_multiple_emoji():
    assert has_emoji("\U0001f525\U0001f44d") is True


def test_strip_emoji_strips_whitespace():
    # Leading/trailing whitespace is stripped after emoji removal
    result = strip_emoji("\U0001f600 ")
    assert result == ""
