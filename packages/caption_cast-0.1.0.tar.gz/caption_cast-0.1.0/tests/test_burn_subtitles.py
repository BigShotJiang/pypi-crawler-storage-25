"""Tests for burn_subtitles with SRT and LRC inputs."""

from __future__ import annotations

from pathlib import Path

from caption_cast import burn_subtitles


def test_burn_subtitles_srt(tiny_video, sample_srt, tmp_path):
    out = tmp_path / "burned_srt.mp4"
    result = burn_subtitles(
        video=str(tiny_video),
        subtitles=str(sample_srt),
        style="subtitle_burn_in",
        output=str(out),
    )
    assert out.exists()
    assert out.stat().st_size > 0
    assert Path(result) == out


def test_burn_subtitles_lrc(tiny_video, sample_lrc, tmp_path):
    out = tmp_path / "burned_lrc.mp4"
    result = burn_subtitles(
        video=str(tiny_video),
        subtitles=str(sample_lrc),
        style="subtitle_burn_in",
        output=str(out),
    )
    assert out.exists()
    assert out.stat().st_size > 0
    assert Path(result) == out
