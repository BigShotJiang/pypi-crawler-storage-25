"""Resolve paths to bundled assets when installed via pip (not cwd-dependent)."""
from __future__ import annotations

from pathlib import Path

_PKG = Path(__file__).resolve().parent


def package_root() -> Path:
    return _PKG


def cluster_viz_directory() -> str:
    return str(_PKG / "cluster_viz")


def default_data_csv() -> str:
    """Bundled sample dataset shipped with the package."""
    return str(_PKG / "data" / "dirty_hardware_data_40k.csv")


def resolve_data_path(user_path: str | None) -> str:
    """Resolve CSV path: absolute, cwd-relative, or package-relative."""
    if not user_path:
        return default_data_csv()
    p = Path(user_path).expanduser()
    if p.is_file():
        return str(p.resolve())
    cwd_try = Path.cwd() / user_path
    if cwd_try.is_file():
        return str(cwd_try.resolve())
    pkg_try = _PKG / user_path
    if pkg_try.is_file():
        return str(pkg_try.resolve())
    return str(p.resolve())


def resolve_ifixit_devices_path() -> str | None:
    """Prefer cwd ifixit_devices.json, then bundled copy next to the package."""
    cwd = Path.cwd() / "ifixit_devices.json"
    if cwd.is_file():
        return str(cwd.resolve())
    bundled = _PKG / "ifixit_devices.json"
    if bundled.is_file():
        return str(bundled.resolve())
    return None
