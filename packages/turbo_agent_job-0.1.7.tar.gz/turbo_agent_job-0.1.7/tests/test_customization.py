from __future__ import annotations

import importlib

from turbo_agent_job.customization import JobWorkerCustomizer


class DummyCustomizer(JobWorkerCustomizer):
    pass


def test_get_worker_customizer_loads_from_env(monkeypatch):
    customization = importlib.import_module("turbo_agent_job.customization")
    monkeypatch.setenv("TA_JOB_WORKER_CUSTOMIZER", "test_customization:DummyCustomizer")
    monkeypatch.setattr(customization, "_customizer_instance", None)

    customizer = customization.get_worker_customizer()

    assert isinstance(customizer, DummyCustomizer)