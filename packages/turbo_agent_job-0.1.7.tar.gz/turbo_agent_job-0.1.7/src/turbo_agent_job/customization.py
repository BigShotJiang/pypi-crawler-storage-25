from __future__ import annotations

import importlib
import os
from dataclasses import dataclass, field
from typing import Any

from loguru import logger

from turbo_agent_core.schema.jobs import TaskSpec
from turbo_agent_core.schema.agents import Agent, Character
from turbo_agent_core.schema.states import Conversation


@dataclass
class WorkerRuntimePreparation:
    """Worker 在 runtime 执行前的预处理结果。"""

    conversation: Conversation
    runtime_kwargs: dict[str, Any] = field(default_factory=dict)


class JobWorkerCustomizer:
    """Job Worker 定制化扩展点。"""

    async def prepare_conversation(
        self,
        task_spec: TaskSpec,
        fallback_conversation: Conversation,
    ) -> Conversation:
        """允许业务方替换或补全 Conversation。"""
        del task_spec
        return fallback_conversation

    async def prepare_executor(
        self,
        task_spec: TaskSpec,
        conversation: Conversation,
    ) -> Agent | Character | None:
        """允许业务方在 Worker 侧对 executor 做二次确权或替换。"""
        del conversation
        return task_spec.executor

    async def prepare_runtime(
        self,
        task_spec: TaskSpec,
        conversation: Conversation,
        runtime: Any,
    ) -> WorkerRuntimePreparation:
        """允许业务方在 runtime 执行前注入额外上下文。"""
        del task_spec, runtime
        return WorkerRuntimePreparation(conversation=conversation)

    async def mark_conversation_running(
        self,
        task_spec: TaskSpec,
        conversation: Conversation,
    ) -> None:
        del task_spec, conversation

    async def mark_conversation_finished(
        self,
        task_spec: TaskSpec,
        conversation: Conversation,
    ) -> None:
        del task_spec, conversation

    async def mark_conversation_failed(
        self,
        task_spec: TaskSpec,
        conversation: Conversation,
        error: Exception,
    ) -> None:
        del task_spec, conversation, error


_customizer_instance: JobWorkerCustomizer | None = None


def _load_object(import_path: str) -> Any:
    module_path, sep, attr_name = import_path.partition(":")
    if not sep:
        raise ValueError(f"无效的 customizer 导入路径: {import_path}")
    module = importlib.import_module(module_path)
    return getattr(module, attr_name)


def get_worker_customizer() -> JobWorkerCustomizer:
    """根据环境变量加载 Worker customizer。"""
    global _customizer_instance
    if _customizer_instance is not None:
        return _customizer_instance

    import_path = (os.getenv("TA_JOB_WORKER_CUSTOMIZER") or "").strip()
    if not import_path:
        _customizer_instance = JobWorkerCustomizer()
        return _customizer_instance

    target = _load_object(import_path)
    if isinstance(target, JobWorkerCustomizer):
        _customizer_instance = target
        return _customizer_instance

    if isinstance(target, type):
        instance = target()
    elif callable(target):
        instance = target()
    else:
        instance = target

    if not isinstance(instance, JobWorkerCustomizer):
        raise TypeError(f"TA_JOB_WORKER_CUSTOMIZER 必须返回 JobWorkerCustomizer 实例，当前为: {type(instance)}")

    logger.info("已启用 Job Worker customizer: {}", import_path)
    _customizer_instance = instance
    return _customizer_instance