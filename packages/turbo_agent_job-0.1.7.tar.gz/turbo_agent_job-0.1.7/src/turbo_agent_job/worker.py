import asyncio
import importlib
import os
from typing import Any

import dramatiq
from loguru import logger

from turbo_agent_core.schema.jobs import TaskSpec, InlineExecutorConfig
from turbo_agent_job.dramatiq_broker import broker as dramatiq_broker
from turbo_agent_job.pipeline import JobWorkerPipeline


# 注册所有已知队列，确保 Dramatiq worker 进程监听这些队列
KNOWN_QUEUES = [
    "ta_job_online_external",
    "ta_job_online_internal",
    "ta_job_offline_external",
    "ta_job_offline_internal"
]
for q in KNOWN_QUEUES:
    dramatiq_broker.queues.add(q)

# ── Pipeline 注册 ──
# 通过环境变量 TA_JOB_PIPELINE_FACTORY 或 register_pipeline() 注入 Pipeline 实例。

_pipeline_instance: JobWorkerPipeline | None = None
_pipeline_load_error: Exception | None = None


def register_pipeline(pipeline: JobWorkerPipeline) -> None:
    """注册 JobWorkerPipeline 实例（全局唯一）。"""
    global _pipeline_instance
    _pipeline_instance = pipeline
    logger.info("已注册 JobWorkerPipeline 实例")


def _load_pipeline_from_env() -> JobWorkerPipeline | None:
    """从环境变量 TA_JOB_PIPELINE_FACTORY 加载 Pipeline。

    格式：module.path:callable_name
    callable 应返回 JobWorkerPipeline 实例。
    """
    global _pipeline_load_error
    _pipeline_load_error = None

    factory_path = (os.getenv("TA_JOB_PIPELINE_FACTORY") or "").strip()
    if not factory_path:
        return None

    module_path, sep, attr_name = factory_path.partition(":")
    if not sep:
        logger.error("TA_JOB_PIPELINE_FACTORY 格式无效: {}", factory_path)
        return None

    try:
        module = importlib.import_module(module_path)
        factory = getattr(module, attr_name)
        pipeline = factory() if callable(factory) else factory
        if not isinstance(pipeline, JobWorkerPipeline):
            _pipeline_load_error = TypeError(
                f"TA_JOB_PIPELINE_FACTORY 返回值不是 JobWorkerPipeline: {type(pipeline)}"
            )
            logger.error("TA_JOB_PIPELINE_FACTORY 返回值不是 JobWorkerPipeline: {}", type(pipeline))
            return None
        logger.info("已从环境变量加载 Pipeline: {}", factory_path)
        return pipeline
    except Exception as e:
        _pipeline_load_error = e
        logger.exception("加载 TA_JOB_PIPELINE_FACTORY 失败: {}", factory_path)
        return None


def get_pipeline() -> JobWorkerPipeline:
    """获取 Pipeline 实例。

    优先返回已注册实例，否则从环境变量 TA_JOB_PIPELINE_FACTORY 加载。
    未配置时抛出异常。
    """
    global _pipeline_instance, _pipeline_load_error
    if _pipeline_instance is not None:
        return _pipeline_instance

    factory_path = (os.getenv("TA_JOB_PIPELINE_FACTORY") or "").strip()
    _pipeline_instance = _load_pipeline_from_env()
    if _pipeline_instance is None:
        if factory_path:
            if _pipeline_load_error is not None:
                raise RuntimeError(
                    "Pipeline 工厂加载失败。"
                    f"TA_JOB_PIPELINE_FACTORY={factory_path}。"
                    f"原始错误: {_pipeline_load_error}"
                ) from _pipeline_load_error
            raise RuntimeError(
                "Pipeline 工厂加载失败。"
                f"TA_JOB_PIPELINE_FACTORY={factory_path}，"
                "但未返回有效的 JobWorkerPipeline 实例。"
            )
        raise RuntimeError(
            "Pipeline 未注册且环境变量 TA_JOB_PIPELINE_FACTORY 未配置。"
            "请通过 register_pipeline() 注册或设置 TA_JOB_PIPELINE_FACTORY 环境变量。"
        )
    return _pipeline_instance


@dramatiq.actor(broker=dramatiq_broker)
def execute_task(task_spec_dict: dict):
    """执行任务（基于 TaskSpec）。"""
    try:
        task_spec = _deserialize_task_spec(task_spec_dict)
        logger.info(
            "Worker 接收到任务，完整 TaskSpec 如下:\n{}",
            task_spec.model_dump_json(indent=2, exclude_none=True),
        )
        pipeline = get_pipeline()
        asyncio.run(pipeline.execute(task_spec))
    except Exception as e:
        logger.exception("Worker 处理任务时发生异常: {}", e)
        raise


def _deserialize_task_spec(task_spec_dict: dict[str, Any]) -> TaskSpec:
    """显式反序列化 TaskSpec。

    关键原因：
    - worker 运行期可能仍持有旧版 TaskSpec schema；
    - 旧 schema 会把 executor 误按 Agent/Character/Tool 联合类型校验；
    - 这里先对主体做标准校验，再单独按 InlineExecutorConfig 解析 executor，避免内联执行器被误判。
    """
    normalized = dict(task_spec_dict)
    raw_executor = normalized.pop("executor", None)

    task_spec = TaskSpec.model_validate({**normalized, "executor": None})

    if raw_executor is not None:
        executor = raw_executor if isinstance(raw_executor, InlineExecutorConfig) else InlineExecutorConfig.model_validate(raw_executor)
        object.__setattr__(task_spec, "executor", executor)

    return task_spec
