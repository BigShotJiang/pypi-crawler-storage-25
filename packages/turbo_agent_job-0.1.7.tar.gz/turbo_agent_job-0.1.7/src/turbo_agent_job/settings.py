from uuid import uuid4
from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    REDIS_URL: str = "redis://localhost:6379/0"
    REDIS_CACHE_URL: str = "redis://localhost:6379/1"
    REDIS_RESULT_URL: str = "redis://localhost:6379/2"
    LOGURU_LEVEL: str = "INFO"
    TA_STORE_CONSUMER: str | None = Field(default=None)

    model_config = SettingsConfigDict(
        env_file=str(".env"),
        env_file_encoding="utf-8",
        extra="ignore",
    )

    def get_store_consumer_name(self) -> str:
        return self.TA_STORE_CONSUMER or f"consumer-{uuid4().hex[:8]}"

settings = Settings()
