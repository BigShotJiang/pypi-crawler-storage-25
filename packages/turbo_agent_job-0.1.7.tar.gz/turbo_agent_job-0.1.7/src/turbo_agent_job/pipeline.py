# coding=utf-8
"""Job Worker 执行管线与扩展钩子。

JobWorkerPipeline 承担 Worker 的完整编排流程：
- 加载/合并会话
- 过滤知识资源（鉴权）
- 组装执行器（三模式编排）
- 准备工作区上下文
- 会话状态管理
- 监控 + 流式执行

JobWorkerHooks 提供细粒度的差异化扩展点，
由集成方（如 cloud）实现个性化逻辑（如 ADMIN_MODE 工具注入）。
"""
from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Union

import redis.asyncio as aioredis
from loguru import logger

from turbo_agent_core.schema.agents import Agent, Character
from turbo_agent_core.schema.enums import ConversationStatus, RunType, TaskAction
from turbo_agent_core.schema.events import (
    ExecutorMetadata,
    RunLifecycleCreatedEvent,
    RunLifecycleCreatedPayload,
    RunLifecycleFailedEvent,
    RunLifecycleFailedPayload,
    UserInfo as EventUserInfo,
)
from turbo_agent_core.schema.jobs import AgentPayload, InlineExecutorConfig, TaskSpec
from turbo_agent_core.schema.states import Conversation, Message, MessageKnowledgeResourceContent
from turbo_agent_core.utils.executor_helpers import (
    build_inline_executor,
    merge_conversation,
    merge_executor_overrides,
)
from turbo_agent_core.utils.identity import build_ephemeral_executor_id, parse_run_type

from turbo_agent_runtime.executors.character import CharacterRuntime
from turbo_agent_runtime.executors.agent import AgentRuntime

from turbo_agent_store.interface import PermissionStore, ResourceEntityStore, StateStore
from turbo_agent_store.interface.runtime import RuntimeStore
from turbo_agent_store.files.file_manage.base import FileManageStore
from turbo_agent_store.files.workspace import WorkspaceContextLoader, WorkspaceContextUserInfo
from turbo_agent_store.stream import RedisRuntimeMonitor, monitor_object, set_monitor_context


# ---------------------------------------------------------------------------
# 扩展钩子
# ---------------------------------------------------------------------------


class JobWorkerHooks:
    """可选的 Worker 差异化扩展点。

    集成方（如 cloud）可继承此类覆盖特定方法，用于实现
    ADMIN_MODE 工具注入等产品形态特有的逻辑。
    """

    async def on_executor_assembled(
        self,
        task_spec: TaskSpec,
        executor: Union[Agent, Character],
    ) -> Union[Agent, Character]:
        """执行器组装完成后的后处理钩子。"""
        return executor

    async def on_runtime_kwargs(
        self,
        task_spec: TaskSpec,
        kwargs: Dict[str, Any],
    ) -> Dict[str, Any]:
        """允许追加额外 runtime 参数。"""
        return kwargs


# ---------------------------------------------------------------------------
# Pipeline
# ---------------------------------------------------------------------------


class JobWorkerPipeline:
    """Job Worker 编排管线。

    编排完整的 Worker 执行流程，通过注入的 store 接口获取数据，
    通过 core 工具函数完成逻辑操作。
    """

    def __init__(
        self,
        *,
        state_store: StateStore,
        resource_store: ResourceEntityStore,
        runtime_store: RuntimeStore,
        file_manage_store: FileManageStore,
        permission_store: PermissionStore,
        redis_result_url: str,
        hooks: Optional[JobWorkerHooks] = None,
    ) -> None:
        self.state_store = state_store
        self.resource_store = resource_store
        self.runtime_store = runtime_store
        self.file_manage_store = file_manage_store
        self.permission_store = permission_store
        self.redis_result_url = redis_result_url
        self.hooks = hooks or JobWorkerHooks()

    # ── 主入口 ──

    async def execute(self, task_spec: TaskSpec) -> None:
        """执行一个完整的 Worker 任务。"""
        # 确保存储连接可用
        await self.runtime_store.ensure_connected()

        conversation: Optional[Conversation] = None
        monitor: Optional[RedisRuntimeMonitor] = None

        # 初始化监控器
        try:
            redis_client = aioredis.from_url(self.redis_result_url, decode_responses=False)
            monitor = RedisRuntimeMonitor(redis_client)
            monitor.start()
            set_monitor_context(monitor)
        except Exception as e:
            logger.error("初始化监控器失败: {}", e)
            return

        try:
            # 1. 校验操作类型
            if task_spec.action != TaskAction.START:
                logger.warning("目前 Worker 仅部分支持 START 操作，收到: {}", task_spec.action)
                return

            # 2. 校验 payload
            payload = task_spec.payload
            if not isinstance(payload, AgentPayload):
                logger.error("需要 AgentPayload，收到: {}", type(payload))
                return

            # 3. 加载 + 合并会话
            conversation = await self._load_and_merge_conversation(task_spec, payload)

            # 4. 解析用户信息
            user_id = self._resolve_user_id(task_spec, conversation)

            # 5. 过滤知识资源（鉴权）
            conversation = await self._filter_conversation_resources(conversation, user_id)

            # 6. 组装执行器（三模式编排）
            executor = await self._resolve_executor(task_spec, user_id)
            if not isinstance(executor, (Character, Agent)):
                logger.error("目前仅支持 Character/Agent 类型的执行器，收到: {}", type(executor))
                return

            if executor.tools is None:
                executor.tools = []

            # 7. 钩子：执行器后处理
            executor = await self.hooks.on_executor_assembled(task_spec, executor)

            logger.info(
                "Worker 执行器准备完成，完整数据如下:\n{}",
                executor.model_dump_json(indent=2, exclude_none=True),
            )

            # 8. 准备工作区上下文
            conversation, runtime_kwargs = await self._prepare_workspace(
                task_spec, conversation, user_id,
            )

            # 9. 钩子：允许追加 runtime 参数
            runtime_kwargs = await self.hooks.on_runtime_kwargs(task_spec, runtime_kwargs)

            # 10. 构建 runtime
            if isinstance(executor, Character):
                logger.info("正在启动 Character: {} (ID: {})", executor.name, executor.id)
                runtime = CharacterRuntime(**executor.model_dump())
            else:
                logger.info("正在启动 Agent: {} (ID: {})", executor.name, executor.id)
                runtime = AgentRuntime(**executor.model_dump())

            trace_id = task_spec.trace_id or task_spec.task_id or str(uuid.uuid4())

            # 11. 会话状态 → running
            await self._update_conversation_status(task_spec, conversation, ConversationStatus.running)

            # 绑定用户信息到 runtime_kwargs
            if task_spec.user:
                runtime_kwargs.setdefault("user_info", task_spec.user.model_dump(exclude_none=True))
                runtime_kwargs.setdefault("user_id", task_spec.user.id)
                runtime_kwargs.setdefault(
                    "username",
                    task_spec.user.username or task_spec.user.firstname or task_spec.user.id,
                )
                logger.info("Worker 绑定用户信息: {} role={}", task_spec.user.id, task_spec.user.role)

            logger.info(
                "开始流式执行 (Conversation ID: {}, Trace ID: {})",
                conversation.id,
                trace_id,
            )

            # 12. 绑定监控器
            monitor_object(runtime, user_info=task_spec.user, override_trace_id=trace_id)

            # 13. 流式执行
            async for _ in runtime.a_stream(
                input=conversation,
                leaf_message_id=payload.leaf_id,
                **runtime_kwargs,
            ):
                pass  # 仅驱动生成器运行

            # 14. 会话状态 → finished
            await self._update_conversation_status(task_spec, conversation, ConversationStatus.finished)
            logger.info("任务 {} 执行完成", task_spec.task_id)

        except Exception as e:
            if conversation is not None:
                try:
                    await self._update_conversation_status(
                        task_spec, conversation, ConversationStatus.error,
                    )
                except Exception as status_err:
                    logger.error("Worker 更新会话 error 状态失败: {}", status_err)
            logger.exception(
                "执行任务时发生未捕获异常: task_id={}, trace_id={}, conversation_id={}, error={}",
                task_spec.task_id,
                task_spec.trace_id,
                getattr(task_spec.payload, "conversation_id", None),
                e,
            )
            await self._emit_failure_events(monitor, task_spec, e)
            raise
        finally:
            if monitor is not None:
                await monitor.close()

    # ── 会话加载 ──

    async def _load_and_merge_conversation(
        self,
        task_spec: TaskSpec,
        payload: AgentPayload,
    ) -> Conversation:
        """从数据库加载会话并与 fallback 合并。"""
        fallback = self._build_fallback_conversation(payload, task_spec.task_id)

        if not payload.conversation_id:
            return fallback

        stored = await self.state_store.get_conversation(payload.conversation_id)
        if stored:
            logger.info(
                "Worker 已加载数据库会话: conversation_id={}, root_user_id={}, message_count={}",
                stored.id,
                stored.root_user_id,
                len(stored.messages or []),
            )
            conversation = merge_conversation(stored, fallback)
        else:
            logger.warning(
                "Worker 未从数据库加载到会话，回退到 payload 会话: conversation_id={}, fallback_root_user_id={}, fallback_message_count={}",
                payload.conversation_id,
                fallback.root_user_id,
                len(fallback.messages or []),
            )
            conversation = fallback

        user_id = self._resolve_user_id(task_spec, conversation)
        logger.info(
            "Worker 会话准备完成: conversation_id={}, root_user_id={}, resolved_user_id={}, payload_conversation_id={}",
            conversation.id,
            conversation.root_user_id,
            user_id,
            payload.conversation_id,
        )
        return conversation

    @staticmethod
    def _build_fallback_conversation(
        payload: AgentPayload,
        task_id: Optional[str],
    ) -> Conversation:
        """基于 payload 构造最小可运行的 Conversation。"""
        messages = list(payload.messages or [])
        current_input = payload.current_input

        if isinstance(current_input, dict):
            if "id" not in current_input:
                current_input["id"] = str(uuid.uuid4())
            try:
                msg = Message.model_validate(current_input)
            except Exception:
                msg = Message(id=str(uuid.uuid4()), role="user", content=str(current_input))
            messages.append(msg)
        elif isinstance(current_input, Message):
            messages.append(current_input)

        return Conversation(
            id=payload.conversation_id or task_id or str(uuid.uuid4()),
            messages=messages,
        )

    # ── 执行器组装（三模式编排） ──

    async def _resolve_executor(
        self,
        task_spec: TaskSpec,
        user_id: str,
    ) -> Union[Agent, Character]:
        """根据 TaskSpec 中的 executor_id / executor 进行三模式编排。"""
        executor_id = task_spec.executor_id
        inline = task_spec.executor

        if executor_id is None and inline is None:
            raise ValueError("请提供 executor 或 executor_id")

        # 模式 1: 仅 executor_id → 直接获取 runnable
        if executor_id and not inline:
            logger.info("执行器解析模式 1: 仅 executor_id={}", executor_id)
            return await self.runtime_store.get_runnable_executor(executor_id, user_id)

        # 模式 2: 纯 inline → 解析各组件 → 构建临时实体
        if inline and not executor_id:
            logger.info("执行器解析模式 2: 纯 inline, run_type={}", inline.run_type)
            if inline.run_type not in {RunType.AGENT, RunType.Character}:
                raise ValueError("内联执行器 run_type 仅支持 AGENT 或 CHARACTER")

            model = None
            if inline.model is not None:
                model = await self.runtime_store.get_runnable_model(inline.model, user_id)

            tools = []
            for tool_detail in inline.tools:
                tool = await self.runtime_store.get_runnable_tool(tool_detail, user_id)
                if tool:
                    tools.append(tool)

            setting = None
            if inline.setting is not None:
                setting = await self.runtime_store.get_runnable_setting(inline.setting, user_id)

            return build_inline_executor(
                inline,
                model=model,
                tools=tools,
                setting=setting,
            )

        # 模式 3: executor_id + inline → 先取基础，再 merge 覆盖
        logger.info(
            "执行器解析模式 3: executor_id={} + inline 覆盖",
            executor_id,
        )
        base = await self.runtime_store.get_runnable_executor(executor_id, user_id)

        override_model = None
        if inline.model is not None:
            override_model = await self.runtime_store.get_runnable_model(inline.model, user_id)

        override_setting = None
        if inline.setting is not None:
            override_setting = await self.runtime_store.get_runnable_setting(inline.setting, user_id)

        return merge_executor_overrides(
            base,
            inline,
            model=override_model,
            setting=override_setting,
        )

    # ── 知识资源过滤 ──

    async def _filter_conversation_resources(
        self,
        conversation: Conversation,
        user_id: str,
    ) -> Conversation:
        """按用户权限过滤会话中的知识资源引用。"""
        resource_cache: Dict[str, Any] = {}
        filtered_messages: List[Message] = []
        for message in conversation.messages:
            filtered_messages.append(
                await self._filter_message_knowledge_resources(message, user_id, resource_cache),
            )

        filtered_knowledge_refs = []
        for knowledge_ref in conversation.knowledge_refs:
            if await self._get_readable_knowledge_resource(knowledge_ref.id, user_id, resource_cache) is not None:
                filtered_knowledge_refs.append(knowledge_ref)
            else:
                logger.warning(
                    "已过滤会话级不可访问知识引用 user_id={}, conversation_id={}, knowledge_id={}",
                    user_id,
                    conversation.id,
                    knowledge_ref.id,
                )

        return conversation.model_copy(
            update={
                "messages": filtered_messages,
                "knowledge_refs": filtered_knowledge_refs,
            },
        )

    async def _filter_message_knowledge_resources(
        self,
        message: Message,
        user_id: str,
        resource_cache: Dict[str, Any],
    ) -> Message:
        """过滤单条消息中的知识资源引用。"""
        filtered_content = message.content
        if isinstance(message.content, list):
            filtered_items: List[Any] = []
            for item in message.content:
                if isinstance(item, str):
                    filtered_items.append(item)
                    continue
                try:
                    resource_item = (
                        item
                        if isinstance(item, MessageKnowledgeResourceContent)
                        else MessageKnowledgeResourceContent.model_validate(item)
                    )
                except Exception:
                    filtered_items.append(item)
                    continue

                readable_resource = await self._get_readable_knowledge_resource(
                    resource_item.id, user_id, resource_cache,
                )
                if readable_resource is None:
                    logger.warning(
                        "已过滤消息中的不可访问知识资源 user_id={}, message_id={}, knowledge_id={}",
                        user_id,
                        message.id,
                        resource_item.id,
                    )
                    continue
                filtered_items.append(
                    MessageKnowledgeResourceContent(
                        id=readable_resource.id,
                        uri=readable_resource.uri,
                        type=readable_resource.type,
                        name=readable_resource.name,
                        mimetype=readable_resource.mime_type,
                        fileType=readable_resource.fileType,
                    ),
                )
            filtered_content = filtered_items

        filtered_knowledge_resources = []
        for resource in message.knowledge_resources:
            readable_resource = await self._get_readable_knowledge_resource(
                resource.id, user_id, resource_cache,
            )
            if readable_resource is None:
                logger.warning(
                    "已过滤消息附带的不可访问知识资源 user_id={}, message_id={}, knowledge_id={}",
                    user_id,
                    message.id,
                    resource.id,
                )
                continue
            filtered_knowledge_resources.append(readable_resource)

        return message.model_copy(
            update={
                "content": filtered_content,
                "knowledge_resources": filtered_knowledge_resources,
            },
        )

    async def _get_readable_knowledge_resource(
        self,
        resource_id: str,
        user_id: str,
        resource_cache: Dict[str, Any],
    ) -> Any:
        """获取用户可读的知识资源（含缓存）。"""
        if resource_id not in resource_cache:
            resource_cache[resource_id] = await self.resource_store.get_knowledge_resource(
                resource_id,
                user_id=user_id,
            )
        return resource_cache[resource_id]

    # ── 工作区上下文准备 ──

    async def _prepare_workspace(
        self,
        task_spec: TaskSpec,
        conversation: Conversation,
        user_id: str,
    ) -> tuple[Conversation, Dict[str, Any]]:
        """初始化工作区上下文并转换消息内容。"""
        user_model = task_spec.user
        user_payload = user_model.model_dump(exclude_none=True) if user_model else {"user_id": user_id}

        loader = WorkspaceContextLoader(
            file_manage_store=self.file_manage_store,
            permission_store=self.permission_store,
            conversation=conversation,
            user_info=WorkspaceContextUserInfo(user_id=user_id, metadata=user_payload),
        )
        logger.info(
            "Worker 准备初始化 WorkspaceContextLoader: conversation_id={}, root_user_id={}, runtime_user_id={}, message_count={}",
            conversation.id,
            conversation.root_user_id,
            user_id,
            len(conversation.messages or []),
        )
        snapshot = await loader.initialize()

        for message in conversation.messages:
            if isinstance(message.content, list):
                message.content = loader.parse_message_content(message)

        logger.info(
            "Worker 已初始化 WorkspaceContextLoader: conversation={}, root={}",
            conversation.id,
            snapshot.root_path,
        )
        return conversation, {
            "workspace_context_loader": loader,
            "workspace_context": snapshot,
        }

    # ── 会话状态管理 ──

    async def _update_conversation_status(
        self,
        task_spec: TaskSpec,
        conversation: Conversation,
        status: ConversationStatus,
    ) -> None:
        """更新会话状态。"""
        payload = task_spec.payload
        if not isinstance(payload, AgentPayload):
            return
        conversation_id = payload.conversation_id or conversation.id
        if not conversation_id:
            return
        updated = await self.state_store.update_conversation_status(
            conversation_id,
            status,
        )
        logger.info(
            "Worker 更新会话状态为 {}: conversation_id={}, updated={}",
            status.value if hasattr(status, "value") else status,
            conversation_id,
            updated,
        )

    # ── 用户信息解析 ──

    @staticmethod
    def _resolve_user_id(task_spec: TaskSpec, conversation: Conversation) -> str:
        """从 TaskSpec 或 Conversation 中解析用户 ID。"""
        user_model = task_spec.user
        return user_model.id if user_model else conversation.root_user_id or "anonymous"

    # ── 错误事件发布 ──

    async def _emit_failure_events(
        self,
        monitor: Optional[RedisRuntimeMonitor],
        task_spec: TaskSpec,
        error: Exception,
    ) -> None:
        """发布任务失败事件到 Redis Stream。"""
        if monitor is None:
            logger.error(
                "无法发布错误事件流：monitor 未初始化，task_id={}, trace_id={}, error_type={}, error={}",
                task_spec.task_id,
                task_spec.trace_id,
                type(error).__name__,
                error,
            )
            return

        try:
            from datetime import datetime, timezone

            trace_id = task_spec.trace_id or task_spec.task_id or str(uuid.uuid4())
            run_id = str(uuid.uuid4())
            ts_ms = datetime.now(timezone.utc).timestamp() * 1000

            executor = task_spec.executor
            executor_id = task_spec.executor_id

            if executor_id:
                resolved_executor_id = executor_id
            elif isinstance(executor, InlineExecutorConfig):
                resolved_executor_id = build_ephemeral_executor_id(executor, executor.run_type)
            else:
                resolved_executor_id = f"unknown:{task_spec.task_id}"

            raw_executor_type = getattr(executor, "run_type", None) if executor else None
            executor_type = parse_run_type(str(raw_executor_type)) if raw_executor_type else parse_run_type("None")

            user_id = task_spec.user.id if task_spec.user else "unknown"
            username = (
                (task_spec.user.username or task_spec.user.firstname or task_spec.user.id)
                if task_spec.user
                else "unknown"
            )

            executor_metadata = ExecutorMetadata(
                id=getattr(executor, "id", None) or resolved_executor_id,
                name=getattr(executor, "name", None) or getattr(executor, "name_id", None) or resolved_executor_id,
                belong_to_project_path=getattr(executor, "belong_to_project_path", None),
                name_id=getattr(executor, "name_id", None),
                description=getattr(executor, "description", None),
                avatar_uri=getattr(executor, "avatar_uri", None),
                run_type=(executor_type.value if hasattr(executor_type, "value") else executor_type),
                version_id=getattr(executor, "version_id", None),
                version=getattr(executor, "version_tag", None) or getattr(executor, "version", None),
            )

            created_event = RunLifecycleCreatedEvent(
                trace_id=trace_id,
                trace_path=[],
                run_id=run_id,
                run_path=[run_id],
                executor_id=resolved_executor_id,
                executor_type=executor_type,
                executor_path=[resolved_executor_id],
                executor_metadata=executor_metadata,
                user_metadata=EventUserInfo(id=str(user_id), username=str(username)),
                timestamp=ts_ms,
                payload=RunLifecycleCreatedPayload(input_data=None),
            )
            failed_event = RunLifecycleFailedEvent(
                trace_id=trace_id,
                trace_path=[],
                run_id=run_id,
                run_path=[run_id],
                executor_id=resolved_executor_id,
                executor_type=executor_type,
                executor_path=[resolved_executor_id],
                timestamp=ts_ms + 1,
                payload=RunLifecycleFailedPayload(
                    error={"code": type(error).__name__, "message": str(error)},
                ),
            )

            monitor.write(created_event)
            monitor.write(failed_event)
            logger.info(
                "已发布错误事件流: trace_id={}, run_id={}, error_type={}, error={}",
                trace_id,
                run_id,
                type(error).__name__,
                error,
            )
        except Exception as emit_err:
            logger.error(
                "发布错误事件流失败: task_id={}, trace_id={}, error_type={}, emit_error={}",
                task_spec.task_id,
                task_spec.trace_id,
                type(error).__name__,
                emit_err,
            )
