"""
Cicada Database — простое JSON-хранилище для постоянных данных.
"""

import json
import os
from pathlib import Path


class Database:
    """Хранит данные в JSON-файле per user."""

    def __init__(self, db_path: str = "cicada_data.json"):
        self.db_path = Path(db_path)
        self._data = {}
        self._load()

    def _load(self):
        """Загружает данные из файла."""
        if self.db_path.exists():
            try:
                with open(self.db_path, "r", encoding="utf-8") as f:
                    self._data = json.load(f)
            except (json.JSONDecodeError, IOError):
                self._data = {}
        else:
            self._data = {}

    def _save(self):
        """Сохраняет данные в файл."""
        try:
            with open(self.db_path, "w", encoding="utf-8") as f:
                json.dump(self._data, f, ensure_ascii=False, indent=2)
        except IOError as e:
            print(f"⚠️ Ошибка сохранения БД: {e}")

    def set(self, user_id: str, key: str, value):
        """Сохраняет значение для пользователя."""
        if user_id not in self._data:
            self._data[user_id] = {}
        self._data[user_id][key] = value
        self._save()

    def get(self, user_id: str, key: str, default=None):
        """Получает значение для пользователя."""
        return self._data.get(user_id, {}).get(key, default)

    def delete(self, user_id: str, key: str):
        """Удаляет ключ для пользователя."""
        if user_id in self._data and key in self._data[user_id]:
            del self._data[user_id][key]
            self._save()

    def get_all(self, user_id: str):
        """Возвращает все данные пользователя."""
        return self._data.get(user_id, {}).copy()


# Глобальный экземпляр БД
_db_instance = None


def get_db(db_path: str = "cicada_data.json") -> Database:
    """Возвращает глобальный экземпляр БД."""
    global _db_instance
    if _db_instance is None:
        _db_instance = Database(db_path)
    return _db_instance


def reset_db():
    """Сбрасывает глобальный экземпляр (для тестов)."""
    global _db_instance
    _db_instance = None
