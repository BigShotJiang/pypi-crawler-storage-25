"""Reddit source.

Reads ``config.content.subreddits`` and fetches ``r/<sub>/.json`` for each
concurrently. Self-posts (``is_self``) are skipped — we link to external
articles only — and the global A/V filter handles the rest.
"""

from __future__ import annotations

import asyncio
import logging
from datetime import UTC, datetime

import httpx

from wyrd.core.sources import ContentItem, register

log = logging.getLogger(__name__)

_USER_AGENT = "wyrd/1.0 (+https://codeberg.org/brhodes/wyrd; personal feed reader)"
_LIMIT = 25
# Reddit's anon API rate limit is ~10/min; 429 with Retry-After is what we see in
# practice. Cap how long we'll wait — beyond this we give up for this run and
# let the next auto-refresh try again rather than blocking the scheduler.
_MAX_BACKOFF_SECONDS = 60.0


def _parse_retry_after(value: str | None) -> float | None:
    """Reddit returns ``Retry-After`` as a number of seconds; return ``None`` for
    anything we don't recognise (e.g. an HTTP-date)."""
    if not value:
        return None
    try:
        return max(0.0, float(value))
    except ValueError:
        return None


class RedditSource:
    kind = "reddit"

    async def fetch(self, cfg) -> list[ContentItem]:
        subs: list[str] = list(getattr(getattr(cfg, "content", None), "subreddits", []) or [])
        if not subs:
            return []
        async with httpx.AsyncClient(
            timeout=20.0, follow_redirects=True, headers={"User-Agent": _USER_AGENT}
        ) as client:
            results = await asyncio.gather(
                *(self._fetch_sub(client, sub) for sub in subs), return_exceptions=True
            )
        items: list[ContentItem] = []
        errors: list[str] = []
        for sub, result in zip(subs, results, strict=True):
            if isinstance(result, BaseException):
                errors.append(f"r/{sub}: {result}")
                log.warning("reddit r/%s failed: %s", sub, result)
            else:
                items.extend(result)
        if errors and not items:
            raise RuntimeError(f"all {len(subs)} subreddit(s) failed; e.g. {errors[0]}")
        return items

    async def _fetch_sub(self, client: httpx.AsyncClient, sub: str) -> list[ContentItem]:
        sub = sub.strip().lstrip("/").removeprefix("r/")
        if not sub:
            return []
        url = f"https://www.reddit.com/r/{sub}/.json"
        resp = await client.get(url, params={"limit": _LIMIT})
        if resp.status_code == 429:
            wait = _parse_retry_after(resp.headers.get("retry-after"))
            if wait is not None and wait <= _MAX_BACKOFF_SECONDS:
                log.info("reddit r/%s rate-limited; sleeping %.1fs then retrying", sub, wait)
                await asyncio.sleep(wait)
                resp = await client.get(url, params={"limit": _LIMIT})
        resp.raise_for_status()
        payload = resp.json() or {}
        children = (payload.get("data") or {}).get("children") or []
        out: list[ContentItem] = []
        for child in children:
            data = (child or {}).get("data") or {}
            if data.get("is_self"):
                continue
            url = data.get("url_overridden_by_dest") or data.get("url")
            if not url:
                continue
            published: datetime | None = None
            ts = data.get("created_utc")
            if isinstance(ts, (int, float)):
                try:
                    published = datetime.fromtimestamp(int(ts), tz=UTC)
                except (OverflowError, OSError, ValueError):
                    published = None
            permalink = data.get("permalink")
            out.append(
                ContentItem(
                    url=url,
                    title=data.get("title"),
                    author=data.get("author"),
                    summary=None,
                    published_at=published,
                    raw={
                        "subreddit": data.get("subreddit") or sub,
                        "score": data.get("score"),
                        "num_comments": data.get("num_comments"),
                        "comments_url": (
                            f"https://www.reddit.com{permalink}" if permalink else None
                        ),
                        "over_18": data.get("over_18"),
                    },
                )
            )
        return out


register(RedditSource())
