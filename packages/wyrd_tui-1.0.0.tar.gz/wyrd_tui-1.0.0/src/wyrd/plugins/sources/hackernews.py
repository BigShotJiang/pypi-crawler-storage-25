"""Hacker News source.

Hits the public Firebase API: pulls the current top-stories list, then
fetches each item concurrently. Items without a ``url`` (Ask/Show HN text
posts) are skipped so we always link to something external.
"""

from __future__ import annotations

import asyncio
import logging
from datetime import UTC, datetime

import httpx

from wyrd.core.sources import ContentItem, register

log = logging.getLogger(__name__)

_USER_AGENT = "wyrd/1.0 (+https://codeberg.org/brhodes/wyrd; personal feed reader)"
_BASE = "https://hacker-news.firebaseio.com/v0"
_DEFAULT_LIMIT = 30


def _limit(cfg) -> int:
    content = getattr(cfg, "content", None)
    raw = getattr(content, "hackernews_limit", None) if content is not None else None
    try:
        n = int(raw) if raw is not None else _DEFAULT_LIMIT
    except (TypeError, ValueError):
        n = _DEFAULT_LIMIT
    return max(1, min(n, 100))


class HackerNewsSource:
    kind = "hackernews"

    async def fetch(self, cfg) -> list[ContentItem]:
        limit = _limit(cfg)
        async with httpx.AsyncClient(
            timeout=20.0, follow_redirects=True, headers={"User-Agent": _USER_AGENT}
        ) as client:
            resp = await client.get(f"{_BASE}/topstories.json")
            resp.raise_for_status()
            ids = resp.json()[:limit]
            stories = await asyncio.gather(
                *(self._fetch_item(client, item_id) for item_id in ids), return_exceptions=True
            )
        items: list[ContentItem] = []
        for item_id, story in zip(ids, stories, strict=True):
            if isinstance(story, BaseException):
                log.warning("hn item %s failed: %s", item_id, story)
                continue
            if story is None:
                continue
            items.append(story)
        return items

    async def _fetch_item(self, client: httpx.AsyncClient, item_id: int) -> ContentItem | None:
        resp = await client.get(f"{_BASE}/item/{item_id}.json")
        resp.raise_for_status()
        data = resp.json() or {}
        url = data.get("url")
        if not url:
            return None
        published: datetime | None = None
        ts = data.get("time")
        if isinstance(ts, (int, float)):
            try:
                published = datetime.fromtimestamp(int(ts), tz=UTC)
            except (OverflowError, OSError, ValueError):
                published = None
        return ContentItem(
            url=url,
            title=data.get("title"),
            author=data.get("by"),
            summary=None,
            published_at=published,
            raw={
                "hn_id": data.get("id"),
                "score": data.get("score"),
                "descendants": data.get("descendants"),
                "comments_url": f"https://news.ycombinator.com/item?id={data.get('id')}",
            },
        )


register(HackerNewsSource())
