"""Helpers shared by the panes that render an item as a Markdown article."""

from __future__ import annotations

import sqlite3
from datetime import datetime


def fmt_when(value: str | None) -> str:
    if not value:
        return ""
    try:
        return datetime.fromisoformat(value).astimezone().strftime("%Y-%m-%d %H:%M")
    except (TypeError, ValueError):
        return value


def feed_when(row: sqlite3.Row) -> str:
    return fmt_when(row["published_at"] or row["discovered_at"])


def md_escape(text: str) -> str:
    """Escape the characters that would otherwise be Markdown syntax in a header line."""
    return text.replace("\\", "\\\\").replace("`", "\\`").replace("*", "\\*").replace("_", "\\_")


def header_markdown(row: sqlite3.Row, *, lede: str | None = None) -> str:
    title = md_escape(row["title"] or "(untitled)")
    meta = " · ".join(p for p in (row["source_kind"], row["author"], feed_when(row)) if p)
    lines = [f"# {title}", ""]
    if meta:
        lines.append(f"*{md_escape(meta)}*")
    if row["url"]:
        lines.append(f"<{row['url']}>")
    if lede and lede.strip():
        lines += ["", f"> {' '.join(lede.split())}"]
    return "\n".join(lines)


def article_markdown(row: sqlite3.Row, *, body: str | None, lede: str | None = None) -> str:
    header = header_markdown(row, lede=lede)
    body = (body or "").strip()
    return f"{header}\n\n---\n\n{body}" if body else header
