"""Setup / preferences wizard.

A single form: search interval, feed URLs, and keywords — plus, when the
``claude`` CLI is available, an "ask Claude for suggestions" button that fills
in feeds and keywords from a free-text description of your interests. Saving
rewrites ``config.toml`` and reloads it into the running app. Shown
automatically on first run; reachable any time with F2.
"""

from __future__ import annotations

from dataclasses import replace
from typing import TYPE_CHECKING, cast

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, VerticalScroll
from textual.screen import Screen
from textual.widgets import Button, Footer, Input, Label, Select, Static, TextArea

from wyrd.core import config as config_mod
from wyrd.core import llm, paths

if TYPE_CHECKING:
    from wyrd.ui.app import WyrdApp

_SUGGEST_LABEL = "✨ Suggest feeds & keywords with Claude"

_FALLBACK_THEMES = [
    "textual-dark",
    "textual-light",
    "nord",
    "gruvbox",
    "tokyo-night",
    "dracula",
    "monokai",
    "solarized-light",
    "catppuccin-mocha",
    "catppuccin-latte",
    "flexoki",
]


class SetupScreen(Screen[None]):
    @property
    def app(self) -> WyrdApp:  # type: ignore[override]
        return cast("WyrdApp", super().app)

    BINDINGS = [Binding("escape", "cancel", "Cancel")]

    DEFAULT_CSS = """
    SetupScreen { align: center middle; }
    SetupScreen #form {
        width: 90%; max-width: 100; height: auto; max-height: 90%;
        border: round $primary; padding: 1 2; background: $surface;
    }
    SetupScreen Label.h { text-style: bold; margin-top: 1; }
    SetupScreen .hint { color: $text-muted; }
    SetupScreen Input, SetupScreen TextArea, SetupScreen Select { width: 100%; }
    SetupScreen TextArea#feeds { height: 8; }
    SetupScreen .key-row Input { width: 24; }
    SetupScreen .key-row Label { width: 14; padding-top: 1; }
    SetupScreen .key-row { height: auto; }
    SetupScreen #buttons { margin-top: 1; height: auto; align-horizontal: right; }
    SetupScreen #buttons Button { margin-left: 2; }
    """

    def __init__(self, *, first_run: bool = False) -> None:
        super().__init__()
        self._first_run = first_run
        self._original_theme: str | None = None

    def _theme_names(self) -> list[str]:
        themes = getattr(self.app, "available_themes", None)
        if isinstance(themes, dict) and themes:
            return [str(name) for name in themes]
        return list(_FALLBACK_THEMES)

    def compose(self) -> ComposeResult:
        cfg = self.app.config
        with VerticalScroll(id="form"):
            yield Static(
                "Welcome to wyrd — let's set things up." if self._first_run else "Preferences",
                classes="h",
            )

            yield Label("Search interval (minutes)", classes="h")
            yield Input(str(cfg.general.refresh_interval_minutes), id="interval", type="integer")

            if llm.available():
                yield Label("Your interests (optional)", classes="h")
                yield Static(
                    "A few words about what you're into — used to suggest feeds.",
                    classes="hint",
                )
                yield Input(
                    placeholder="rust, distributed systems, indie games, climate tech…",
                    id="interests",
                )
                yield Button(_SUGGEST_LABEL, id="suggest", variant="primary")

            yield Label("RSS / Atom feed URLs (one per line)", classes="h")
            yield TextArea("\n".join(cfg.content.feeds), id="feeds")

            yield Label("Subreddits (comma-separated, without r/)", classes="h")
            yield Input(", ".join(cfg.content.subreddits), id="subreddits")

            yield Label("Keywords (comma-separated)", classes="h")
            yield Static("Items matching these get flagged as interesting.", classes="hint")
            yield Input(", ".join(cfg.content.keywords), id="keywords")

            yield Label("Research output folder", classes="h")
            yield Static(
                "Where the deep-research agent saves its papers. Leave blank for the default.",
                classes="hint",
            )
            yield Input(
                cfg.research.output_dir,
                placeholder=str(paths.research_dir()),
                id="research-dir",
            )

            yield Label("Obsidian vault", classes="h")
            yield Static(
                "Path to an Obsidian vault. When set, liked articles land in "
                "<vault>/<folder>/saved/ and research runs in <vault>/<folder>/research/ "
                "so Obsidian picks them up automatically. Leave the vault blank to disable.",
                classes="hint",
            )
            yield Input(
                cfg.obsidian.vault,
                placeholder="~/Documents/MyVault",
                id="obsidian-vault",
            )
            yield Static("Subfolder inside the vault:", classes="hint")
            yield Input(
                cfg.obsidian.folder,
                placeholder="wyrd",
                id="obsidian-folder",
            )
            yield Button(
                "Export saved items to vault",
                id="obsidian-export",
            )

            yield Label("Theme", classes="h")
            theme_options = [(name, name) for name in self._theme_names()]
            current = cfg.ui.theme
            if current not in {n for n, _ in theme_options}:
                theme_options.insert(0, (current, current))
            yield Select(
                options=theme_options,
                value=current,
                allow_blank=False,
                id="theme",
            )

            yield Label("Keybindings", classes="h")
            yield Static(
                "Use Textual key syntax — e.g. '1', 'ctrl+r', 'f2', 'shift+a'.",
                classes="hint",
            )
            for name in config_mod.DEFAULT_KEYS:
                current_key = getattr(cfg.keys, name)
                with Horizontal(classes="key-row"):
                    yield Label(name, classes="key-label")
                    yield Input(
                        current_key,
                        id=f"key-{name}",
                        placeholder=config_mod.DEFAULT_KEYS[name],
                    )

            with Horizontal(id="buttons"):
                yield Button("Cancel", id="cancel")
                yield Button("Save", id="save", variant="success")
        yield Footer()

    def on_mount(self) -> None:
        self._original_theme = self.app.theme

    # --- actions ------------------------------------------------------------

    def action_cancel(self) -> None:
        if self._original_theme is not None:
            try:
                self.app.theme = self._original_theme
            except Exception:
                pass
        self.app.pop_screen()

    def on_select_changed(self, event: Select.Changed) -> None:
        if event.control.id == "theme" and isinstance(event.value, str):
            try:
                self.app.theme = event.value
            except Exception:
                pass

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "save":
            self._save()
        elif event.button.id == "cancel":
            self.action_cancel()
        elif event.button.id == "suggest":
            self._suggest()
        elif event.button.id == "obsidian-export":
            self._export_saved_to_obsidian()

    def _values(self) -> tuple[int, list[str], list[str], list[str]]:
        raw_interval = self.query_one("#interval", Input).value.strip()
        try:
            interval = max(1, int(raw_interval or "60"))
        except ValueError:
            interval = 60
        feeds = [
            line.strip()
            for line in self.query_one("#feeds", TextArea).text.splitlines()
            if line.strip()
        ]
        keywords = [
            k.strip().lower()
            for k in self.query_one("#keywords", Input).value.split(",")
            if k.strip()
        ]
        subreddits = [
            s.strip().lstrip("/").removeprefix("r/")
            for s in self.query_one("#subreddits", Input).value.split(",")
            if s.strip()
        ]
        subreddits = [s for s in subreddits if s]
        return interval, feeds, keywords, subreddits

    def _theme_value(self) -> str:
        select = self.query_one("#theme", Select)
        value = select.value
        if isinstance(value, str):
            return value
        return self.app.config.ui.theme

    def _keys_value(self) -> config_mod.KeysConfig:
        values: dict[str, str] = {}
        for name, default in config_mod.DEFAULT_KEYS.items():
            field = self.query_one(f"#key-{name}", Input).value.strip()
            values[name] = field or default
        return config_mod.KeysConfig(**values)

    def _save(self) -> None:
        interval, feeds, keywords, subreddits = self._values()
        research = replace(
            self.app.config.research,
            output_dir=self.query_one("#research-dir", Input).value.strip(),
        )
        obsidian_folder = self.query_one("#obsidian-folder", Input).value.strip() or "wyrd"
        obsidian = config_mod.ObsidianConfig(
            vault=self.query_one("#obsidian-vault", Input).value.strip(),
            folder=obsidian_folder,
        )
        theme = self._theme_value()
        keys = self._keys_value()
        config_mod.write(
            refresh_interval_minutes=interval,
            feeds=feeds,
            keywords=keywords,
            subreddits=subreddits,
            theme=theme,
            research=research,
            keys=keys,
            obsidian=obsidian,
        )
        self.app.reload_config()
        self._original_theme = None
        self.app.pop_screen()
        self.app.notify(
            f"Saved — {len(feeds)} feed(s), {len(subreddits)} subreddit(s), {len(keywords)} keyword(s). Press Ctrl+R to fetch.",
            title="wyrd",
        )

    # --- Obsidian one-shot migration ----------------------------------------

    def _export_saved_to_obsidian(self) -> None:
        """Write every previously-saved item to the vault path in the inputs.

        Reads the path from the on-screen inputs, not the saved config — so a
        user can configure + migrate in a single trip through the wizard, no
        Save-then-reopen dance.
        """
        from wyrd.core import obsidian

        vault = self.query_one("#obsidian-vault", Input).value.strip()
        if not vault:
            self.app.notify(
                "Set a vault path first, then press the button.",
                severity="warning",
                title="Obsidian",
            )
            return
        folder = self.query_one("#obsidian-folder", Input).value.strip() or "wyrd"
        cfg_for_export = replace(
            self.app.config,
            obsidian=config_mod.ObsidianConfig(vault=vault, folder=folder),
        )
        written, skipped = obsidian.export_all_saved(cfg_for_export, self.app.db)
        if written + skipped == 0:
            self.app.notify(
                "No saved items yet — like something in the Feed first.",
                title="Obsidian",
            )
            return
        target = obsidian.saved_dir(cfg_for_export)
        msg = f"Wrote {written} note(s) to {target}"
        if skipped:
            msg += f"; skipped {skipped} without an article body"
        self.app.notify(msg, title="Obsidian")

    # --- AI suggestions -----------------------------------------------------

    def _suggest(self) -> None:
        interests = self.query_one("#interests", Input).value.strip()
        if not interests:
            self.app.notify("Type a few interests first.", severity="warning")
            return
        button = self.query_one("#suggest", Button)
        button.disabled = True
        button.label = "Asking Claude…"
        self.run_worker(self._do_suggest(interests), exclusive=True, group="suggest")

    async def _do_suggest(self, interests: str) -> None:
        button = self.query_one("#suggest", Button)
        try:
            result = await llm.suggest_feeds_and_keywords(interests)
        finally:
            button.disabled = False
            button.label = _SUGGEST_LABEL
        if not result:
            self.app.notify(
                "No suggestions — is the `claude` CLI installed and working?",
                severity="warning",
            )
            return

        feeds_area = self.query_one("#feeds", TextArea)
        existing_feeds = [line.strip() for line in feeds_area.text.splitlines() if line.strip()]
        merged_feeds = existing_feeds + [f for f in result["feeds"] if f not in existing_feeds]
        feeds_area.load_text("\n".join(merged_feeds))

        kw_input = self.query_one("#keywords", Input)
        existing_kw = [k.strip().lower() for k in kw_input.value.split(",") if k.strip()]
        merged_kw = existing_kw + [k for k in result["keywords"] if k not in existing_kw]
        kw_input.value = ", ".join(merged_kw)

        self.app.notify(
            f"Claude suggested {len(result['feeds'])} feed(s) and {len(result['keywords'])} keyword(s).",
            title="Suggestions",
        )
