"""Feed pane — the stream of discovered content.

Left: a table of items that are `new`/`seen` (newest first). Right: an in-app
reader. Highlighting an item marks it `seen` and (lazily, in the background)
fetches the page and turns it into Markdown with trafilatura so you can read it
without leaving the TUI. Results are cached in the `extractions` table — the
same item never gets fetched twice.

`l` likes the item (snapshots it into the Saved pane), `d` dismisses it, and
`o` opens it in a real browser if the in-app reader can't make sense of the page.
"""

from __future__ import annotations

import sqlite3
import webbrowser
from typing import TYPE_CHECKING, Literal, cast

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Vertical, VerticalScroll
from textual.coordinate import Coordinate
from textual.timer import Timer
from textual.widget import Widget
from textual.widgets import DataTable, Input, Markdown, Static

from wyrd.core import extract as extract_mod
from wyrd.core import obsidian, store
from wyrd.core.scoring import score_item
from wyrd.ui import _reader

if TYPE_CHECKING:
    from wyrd.ui.app import WyrdApp


ViewMode = Literal["all", "interesting", "ranked"]
_MODE_LABELS: dict[ViewMode, str] = {
    "all": "view: all  ·  press [b]f[/] to filter",
    "interesting": "view: interesting only (★)  ·  press [b]f[/] to cycle",
    "ranked": "view: ranked by keyword score  ·  press [b]f[/] to cycle",
}
_MODE_ORDER: list[ViewMode] = ["all", "interesting", "ranked"]


class FeedPane(Widget):
    @property
    def app(self) -> WyrdApp:  # type: ignore[override]
        return cast("WyrdApp", super().app)

    BINDINGS = [
        Binding("l", "like", "Like / save"),
        Binding("d", "dismiss", "Dismiss"),
        Binding("o", "open_in_browser", "Open in browser"),
        Binding("y", "copy_url", "Copy URL"),
        Binding("f", "cycle_filter", "Filter"),
        Binding("f4", "toggle_focus", "Focus reader"),
        Binding("slash", "focus_search", "Search", show=False),
    ]

    DEFAULT_CSS = """
    FeedPane { layout: horizontal; height: 1fr; }
    FeedPane #feed-left { width: 50%; }
    FeedPane #feed-search { margin: 0 0 1 0; }
    FeedPane #feed-mode { height: 1; color: $text-muted; padding: 0 1; }
    FeedPane #feed-table { height: 1fr; }
    FeedPane #feed-reader { width: 1fr; border-left: solid $panel-darken-1; padding: 0 2; }
    FeedPane.focus-reader #feed-left { display: none; }
    FeedPane.focus-reader #feed-reader { border-left: none; }
    """

    def __init__(self) -> None:
        super().__init__()
        self._items: list[sqlite3.Row] = []
        self._unsubs: list = []
        self._extracting: set[int] = set()
        self._search_timer: Timer | None = None
        self._mode: ViewMode = "all"

    def compose(self) -> ComposeResult:
        with Vertical(id="feed-left"):
            yield Input(placeholder="search feed…", id="feed-search")
            yield Static(_MODE_LABELS["all"], id="feed-mode")
            yield DataTable(id="feed-table", cursor_type="row", zebra_stripes=True)
        yield VerticalScroll(Markdown("", id="feed-article"), id="feed-reader")

    def on_mount(self) -> None:
        table = self.query_one("#feed-table", DataTable)
        table.add_columns("", "Title", "Source", "When")
        self._unsubs = [self.app.events.subscribe("refresh_finished", self._on_refresh)]
        self.reload()

    def on_unmount(self) -> None:
        for unsub in self._unsubs:
            unsub()
        self._unsubs = []

    def _on_refresh(self, **_) -> None:
        self.call_after_refresh(self.reload)

    # --- list ---------------------------------------------------------------

    def _keywords(self) -> list[str]:
        return list(getattr(getattr(self.app.config, "content", None), "keywords", []) or [])

    def _marker(self, row: sqlite3.Row) -> str:
        if score_item(row, self._keywords()) > 0:
            return "★"
        return "●" if row["state"] == "new" else " "

    def _apply_mode(self, rows: list[sqlite3.Row]) -> list[sqlite3.Row]:
        if self._mode == "all":
            return rows
        keywords = self._keywords()
        scored = [(score_item(r, keywords), r) for r in rows]
        if self._mode == "interesting":
            return [r for s, r in scored if s > 0]
        # ranked: sort by score desc; Python's sort is stable, so ties keep the
        # fetched (chronological) order.
        return [r for _, r in sorted(scored, key=lambda p: -p[0])]

    def reload(self, *, query: str | None = None) -> None:
        if query is None:
            try:
                query = self.query_one("#feed-search", Input).value
            except Exception:
                query = ""
        table = self.query_one("#feed-table", DataTable)
        keep_id = self._highlighted_id()
        prev_index = table.cursor_row  # fallback when keep_id is gone (e.g., just liked/dismissed)
        if query and query.strip():
            fetched = list(store.search_feed(self.app.db, query))
        else:
            fetched = list(store.list_feed_items(self.app.db))
        self._items = self._apply_mode(fetched)
        table.clear()
        for row in self._items:
            table.add_row(
                self._marker(row),
                _shorten(row["title"] or row["url"]),
                row["source_kind"],
                _reader.feed_when(row),
            )
        self._update_mode_label()
        if not self._items:
            if query and query.strip():
                self._set_article("# No matches\n\nTry a different search.")
            elif self._mode == "interesting" and fetched:
                self._set_article(
                    "# Nothing flagged interesting\n\n"
                    "No items match your configured keywords. "
                    "Press **f** to switch the view, or **F2** to edit keywords."
                )
            else:
                self._set_article(
                    "# No content yet\n\n"
                    "Press **Ctrl+R** to fetch your feeds, or **F2** to add some."
                )
            return
        # If the previously highlighted item still exists, stay on it; otherwise
        # hold the cursor position so the next item drops into view.
        found = next((i for i, r in enumerate(self._items) if r["id"] == keep_id), None)
        if found is not None:
            idx = found
        elif prev_index is not None and prev_index >= 0:
            idx = min(prev_index, len(self._items) - 1)
        else:
            idx = 0
        table.move_cursor(row=idx)
        self._show(idx)

    def _update_mode_label(self) -> None:
        try:
            self.query_one("#feed-mode", Static).update(_MODE_LABELS[self._mode])
        except Exception:
            pass

    def action_cycle_filter(self) -> None:
        i = _MODE_ORDER.index(self._mode)
        self._mode = _MODE_ORDER[(i + 1) % len(_MODE_ORDER)]
        self.reload()

    def action_toggle_focus(self) -> None:
        self.toggle_class("focus-reader")

    def _highlighted_id(self) -> int | None:
        table = self.query_one("#feed-table", DataTable)
        i = table.cursor_row
        if i is None or not (0 <= i < len(self._items)):
            return None
        return self._items[i]["id"]

    # --- reader -------------------------------------------------------------

    def _show(self, idx: int) -> None:
        row = self._items[idx]
        if row["state"] == "new":
            store.set_item_state(self.app.db, row["id"], "seen")
            row = self._items[idx] = store.get_item(self.app.db, row["id"]) or row
            try:
                self.query_one("#feed-table", DataTable).update_cell_at(
                    Coordinate(idx, 0), self._marker(row)
                )
            except Exception:
                pass
        self._render_article(row)
        # The reader keeps its own scroll position per article — reset it so the
        # new article starts at the top instead of wherever the last one left off.
        try:
            self.query_one("#feed-reader", VerticalScroll).scroll_home(animate=False)
        except Exception:
            pass

    def _render_article(self, row: sqlite3.Row) -> None:
        extraction = store.get_extraction(self.app.db, row["id"])
        lede = row["summary"]

        if extraction is not None and extraction["markdown"]:
            self._set_article(_reader.article_markdown(row, body=extraction["markdown"], lede=lede))
            return
        if extraction is not None and extraction["error"]:
            self._set_article(
                _reader.article_markdown(
                    row,
                    body=(
                        "*Couldn't extract this page automatically.*\n\n"
                        f"`{extraction['error']}`\n\n"
                        "_Press_ `o` _to open it in a browser as a fallback._"
                    ),
                    lede=lede,
                )
            )
            return
        # not extracted yet — show what we have and kick off the worker
        self._set_article(_reader.article_markdown(row, body="*Loading article…*", lede=lede))
        self._kick_extraction(row["id"], row["url"])

    def _set_article(self, markdown: str) -> None:
        self.query_one("#feed-article", Markdown).update(markdown)

    def _kick_extraction(self, item_id: int, url: str) -> None:
        if item_id in self._extracting:
            return
        self._extracting.add(item_id)
        self.run_worker(
            self._do_extract(item_id, url),
            exclusive=False,
            group=f"extract-{item_id}",
        )

    async def _do_extract(self, item_id: int, url: str) -> None:
        markdown: str | None = None
        try:
            article = await extract_mod.fetch_and_extract(url)
            markdown = article.markdown
            store.save_extraction(self.app.db, item_id, markdown=markdown, title=article.title)
        except Exception as exc:  # noqa: BLE001
            store.save_extraction(self.app.db, item_id, error=f"{type(exc).__name__}: {exc}")
        finally:
            self._extracting.discard(item_id)
        # if the user already liked this item, give the saved copy the real text
        if markdown and store.is_saved(self.app.db, item_id):
            store.update_saved(self.app.db, item_id, full_text=markdown)
            self._write_obsidian_note(item_id)
        if self._highlighted_id() == item_id:
            row = store.get_item(self.app.db, item_id)
            if row is not None:
                self._render_article(row)

    # --- events / actions ---------------------------------------------------

    def on_data_table_row_highlighted(self, event: DataTable.RowHighlighted) -> None:
        if 0 <= event.cursor_row < len(self._items):
            self._show(event.cursor_row)

    def on_data_table_row_selected(self, event: DataTable.RowSelected) -> None:  # noqa: ARG002
        # Enter on a row activates reader focus mode — the article fills the
        # pane. Naturally one-way: the left side is hidden, so Enter can't fire
        # again until the user comes back with F4.
        self.add_class("focus-reader")

    def on_input_changed(self, event: Input.Changed) -> None:
        if event.input.id != "feed-search":
            return
        if self._search_timer is not None:
            self._search_timer.stop()
        self._search_timer = self.set_timer(0.25, self.reload)

    def on_input_submitted(self, event: Input.Submitted) -> None:
        if event.input.id == "feed-search":
            if self._search_timer is not None:
                self._search_timer.stop()
                self._search_timer = None
            self.reload(query=event.value)

    def action_focus_search(self) -> None:
        self.query_one("#feed-search", Input).focus()

    def _current_row(self) -> sqlite3.Row | None:
        i = self.query_one("#feed-table", DataTable).cursor_row
        if i is None or not (0 <= i < len(self._items)):
            return None
        return self._items[i]

    def action_like(self) -> None:
        row = self._current_row()
        if row is None:
            return
        extraction = store.get_extraction(self.app.db, row["id"])
        full_text = extraction["markdown"] if extraction else None
        store.like_item(self.app.db, row["id"], full_text=full_text)
        if full_text is None:
            # body not extracted yet; the worker will write the Obsidian note
            # once it lands (see _do_extract).
            self._kick_extraction(row["id"], row["url"])
        else:
            self._write_obsidian_note(row["id"])
        self.app.events.emit("item_saved", item_id=row["id"])
        title = _shorten(row["title"] or row["url"], 48)
        self.notify(f"Saved: {title}", title="Liked")
        self.reload()

    def _write_obsidian_note(self, item_id: int) -> None:
        """Mirror the saved snapshot to the Obsidian vault, if one is configured."""
        if not obsidian.enabled(self.app.config):
            return
        item = store.get_item(self.app.db, item_id)
        saved = store.get_saved(self.app.db, item_id)
        if item is None or saved is None or not saved["full_text"]:
            return
        path = obsidian.write_saved_note(self.app.config, item, saved, saved["full_text"])
        if path is not None:
            self.notify(f"Obsidian: {path.name}", title="Vault")

    def action_dismiss(self) -> None:
        row = self._current_row()
        if row is None:
            return
        store.dismiss_item(self.app.db, row["id"])
        self.notify(f"Dismissed: {_shorten(row['title'] or row['url'], 48)}")
        self.reload()

    def action_copy_url(self) -> None:
        row = self._current_row()
        if row is None or not row["url"]:
            return
        url = row["url"]
        self.app.copy_to_clipboard(url)
        self.notify(f"Copied: {_shorten(url, 60)}", title="Clipboard")

    def action_open_in_browser(self) -> None:
        row = self._current_row()
        if row is None:
            return
        url = row["url"]
        try:
            webbrowser.open(url)
        except Exception as exc:  # noqa: BLE001
            self.notify(f"Couldn't open a browser: {exc}", severity="warning")
        else:
            self.notify(f"Opened {url}", title="Feed")


def _shorten(text: str, limit: int = 72) -> str:
    text = " ".join(text.split())
    return text if len(text) <= limit else text[: limit - 1].rstrip() + "…"
