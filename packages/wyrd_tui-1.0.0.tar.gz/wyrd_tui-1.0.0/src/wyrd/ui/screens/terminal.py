"""Full-screen terminal: an embedded `$SHELL` on a PTY.

Pushed from the main screen (key `3`). Press **F12** to detach (pop back). The
embedded widget grabs essentially every keystroke while focused, so F12 is the
escape hatch; F10 (handled by the app, when this screen isn't up) suspends the
whole TUI and drops you into a real shell for anything the embedded emulator
can't handle.
"""

from __future__ import annotations

from textual.app import ComposeResult
from textual.binding import Binding
from textual.screen import Screen
from textual.widgets import Footer

from wyrd.ui.widgets.terminal import TerminalWidget


class TerminalScreen(Screen[None]):
    BINDINGS = [Binding("f12", "detach", "Detach")]

    DEFAULT_CSS = """
    TerminalScreen TerminalWidget {
        width: 1fr;
        height: 1fr;
    }
    """

    def __init__(self, command: list[str] | None = None) -> None:
        super().__init__()
        self._command = command

    def compose(self) -> ComposeResult:
        yield TerminalWidget(self._command)
        yield Footer()

    def action_detach(self) -> None:
        self.app.pop_screen()

    def on_terminal_widget_exited(self, _: TerminalWidget.Exited) -> None:
        self.app.pop_screen()
