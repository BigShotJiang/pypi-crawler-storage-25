"""Activity / run history — a modal view of recent scheduler runs.

Pushed on `F3`. Lists the most recent runs of every source (started_at, source
kind, duration, items found / new, status). The bottom pane shows the full
error for the highlighted row when there is one. Subscribes to
``refresh_finished`` so it stays current while a refresh happens with this
screen open. `Esc` closes.
"""

from __future__ import annotations

import sqlite3
from datetime import datetime
from typing import TYPE_CHECKING, cast

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Vertical
from textual.screen import Screen
from textual.widgets import DataTable, Footer, Static

from wyrd.core import store
from wyrd.ui import _reader

if TYPE_CHECKING:
    from wyrd.ui.app import WyrdApp


_EMPTY = "No refreshes yet — press Ctrl+R to fetch your feeds."


class RunsScreen(Screen[None]):
    BINDINGS = [Binding("escape", "close", "Close")]

    DEFAULT_CSS = """
    RunsScreen { align: center middle; }
    RunsScreen #wrap {
        width: 90%; max-width: 120; height: 80%;
        border: round $primary; padding: 1 2; background: $surface;
    }
    RunsScreen #title { text-style: bold; padding-bottom: 1; }
    RunsScreen #runs-table { height: 1fr; }
    RunsScreen #runs-detail {
        height: auto; min-height: 1; max-height: 8;
        margin-top: 1; padding: 0 1; color: $text-muted;
        border-top: solid $panel-darken-1;
    }
    RunsScreen #runs-detail.error { color: $error; }
    """

    @property
    def app(self) -> WyrdApp:  # type: ignore[override]
        return cast("WyrdApp", super().app)

    def __init__(self) -> None:
        super().__init__()
        self._rows: list[sqlite3.Row] = []
        self._unsubs: list = []

    def compose(self) -> ComposeResult:
        with Vertical(id="wrap"):
            yield Static("Activity — recent refreshes", id="title")
            yield DataTable(id="runs-table", cursor_type="row", zebra_stripes=True)
            yield Static(_EMPTY, id="runs-detail")
        yield Footer()

    def on_mount(self) -> None:
        table = self.query_one("#runs-table", DataTable)
        table.add_columns("When", "Source", "Duration", "Found", "New", "Status")
        self._unsubs = [self.app.events.subscribe("refresh_finished", self._on_refresh)]
        self.reload()

    def on_unmount(self) -> None:
        for unsub in self._unsubs:
            unsub()
        self._unsubs = []

    def _on_refresh(self, **_) -> None:
        self.call_after_refresh(self.reload)

    def reload(self) -> None:
        table = self.query_one("#runs-table", DataTable)
        table.clear()
        self._rows = list(store.recent_runs(self.app.db))
        for row in self._rows:
            table.add_row(
                _reader.fmt_when(row["started_at"]),
                row["source_kind"],
                _duration(row),
                str(row["found"]),
                str(row["new"]),
                _status(row),
            )
        self._update_detail()

    def on_data_table_row_highlighted(self, _: DataTable.RowHighlighted) -> None:
        self._update_detail()

    def _update_detail(self) -> None:
        detail = self.query_one("#runs-detail", Static)
        if not self._rows:
            detail.update(_EMPTY)
            detail.remove_class("error")
            return
        table = self.query_one("#runs-table", DataTable)
        idx = table.cursor_row
        if idx is None or idx < 0 or idx >= len(self._rows):
            idx = 0
        row = self._rows[idx]
        error = row["error"]
        if error:
            detail.update(f"Error: {error}")
            detail.add_class("error")
        else:
            detail.update(
                f"Found {row['found']}, {row['new']} new — finished "
                f"{_reader.fmt_when(row['finished_at']) or 'in progress'}."
            )
            detail.remove_class("error")

    def action_close(self) -> None:
        self.app.pop_screen()


def _duration(row: sqlite3.Row) -> str:
    started, finished = row["started_at"], row["finished_at"]
    if not (started and finished):
        return "—"
    try:
        delta = datetime.fromisoformat(finished) - datetime.fromisoformat(started)
    except (TypeError, ValueError):
        return "—"
    seconds = delta.total_seconds()
    if seconds < 1:
        return f"{int(seconds * 1000)}ms"
    if seconds < 60:
        return f"{seconds:.1f}s"
    return f"{int(seconds // 60)}m{int(seconds % 60):02d}s"


def _status(row: sqlite3.Row) -> str:
    if row["error"]:
        return "✗ failed"
    if row["finished_at"] is None:
        return "… running"
    return "✓ ok"
