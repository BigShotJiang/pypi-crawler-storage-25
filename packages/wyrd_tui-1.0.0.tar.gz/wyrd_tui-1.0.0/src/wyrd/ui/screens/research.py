"""Research pane — the deep-research agent.

Type a topic, press Enter, and the agent (driven by the ``claude`` CLI's web
tools) reads the *peer-reviewed* literature and writes a review paper; for each
cited paper it saves a Markdown note holding the agent's summary plus, where a
free open-access copy exists, the paper's **full text** (PDF/HTML → Markdown).
One folder per run under your configured research folder.

The left column is a tree of past runs — expand a run to see every Markdown
file it produced (the review paper and one note per cited paper); highlight any
of them to read it on the right. While a run is in progress the left column also
shows what the agent is doing right now.

Keys: `o` opens the highlighted file in your OS editor, `Ctrl+O` opens the
research folder, `Delete` removes a run **and its whole folder** (after a
confirmation).
"""

from __future__ import annotations

import json
import os
import shutil
import sqlite3
import subprocess
import sys
import time
import webbrowser
from pathlib import Path
from typing import TYPE_CHECKING, cast
from urllib.parse import unquote, urlparse

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical, VerticalScroll
from textual.screen import ModalScreen
from textual.widget import Widget
from textual.widgets import Button, Input, Label, Markdown, Static, Tree
from textual.widgets.tree import TreeNode

from wyrd.core import llm, store
from wyrd.core import research as research_mod
from wyrd.ui import _reader

if TYPE_CHECKING:
    from wyrd.ui.app import WyrdApp

_INTRO = (
    "# Deep research\n\n"
    "Type a topic above and press **Enter**. The agent searches the web, gathers "
    "**peer-reviewed papers**, writes a literature review, and — for each cited paper "
    "— saves a Markdown note with its summary and, where an open-access copy exists, "
    "the **full text**. One folder per run in your research folder (`F2` to change "
    "where).\n\n"
    "On the left, expand a run to see every Markdown file it produced; highlight one "
    "to read it here.\n\n"
    "_Needs the `claude` CLI on your PATH — it does the searching, reading, and writing._\n"
)


class ResearchPane(Widget):
    @property
    def app(self) -> WyrdApp:  # type: ignore[override]
        return cast("WyrdApp", super().app)

    BINDINGS = [
        Binding("o", "open_file", "Open file"),
        Binding("ctrl+o", "open_folder", "Open folder"),
        Binding("delete", "delete", "Delete"),
        Binding("f4", "toggle_focus", "Focus reader"),
    ]

    DEFAULT_CSS = """
    ResearchPane { layout: horizontal; height: 1fr; }
    ResearchPane #research-left { width: 42%; layout: vertical; }
    ResearchPane #research-status {
        height: auto; min-height: 1; padding: 0 1; color: $text-muted;
        border-bottom: solid $panel-darken-1;
    }
    ResearchPane #research-status.busy { color: $warning; text-style: bold; }
    ResearchPane #research-status.failed { color: $error; }
    ResearchPane #research-tree { height: 1fr; padding: 0 1; }
    ResearchPane #research-reader {
        width: 1fr; border-left: solid $panel-darken-1; padding: 0 2;
    }
    ResearchPane.focus-reader #research-left { display: none; }
    ResearchPane.focus-reader #research-reader { border-left: none; }
    """

    def __init__(self) -> None:
        super().__init__()
        self._rows: list[sqlite3.Row] = []
        self._loaded_path: Path | None = (
            None  # the .md currently shown on the right (for `o`/tests)
        )
        self._busy = False
        self._started_at = 0.0
        self._last_action = ""
        self._tick = None

    def compose(self) -> ComposeResult:
        with Vertical(id="research-left"):
            yield Input(
                placeholder="Research a topic…  e.g. “microplastics and human health”",
                id="research-topic",
            )
            yield Static("", id="research-status")
            yield Tree("Research", id="research-tree")
        yield VerticalScroll(Markdown(_INTRO, id="research-doc"), id="research-reader")

    def on_mount(self) -> None:
        tree = self.query_one("#research-tree", Tree)
        tree.show_root = False
        tree.guide_depth = 3
        self.reload()

    # --- the tree -----------------------------------------------------------

    def reload(self, *, select_run_id: int | None = None) -> None:
        tree = self.query_one("#research-tree", Tree)
        keep = select_run_id if select_run_id is not None else self._current_run_id()
        self._rows = list(store.list_research(self.app.db))
        tree.clear()
        tree.root.expand()
        node_by_run_id: dict[int, TreeNode] = {}
        for row in self._rows:
            children = self._file_children(row)
            run_node = tree.root.add(
                self._run_label(row),
                data={"kind": "run", "id": row["id"], "row": row},
                allow_expand=bool(children),
            )
            node_by_run_id[row["id"]] = run_node
            for label, path in children:
                run_node.add_leaf(label, data={"kind": "file", "path": str(path)})
        if not self._rows:
            self._set_doc(_INTRO)
            self._loaded_path = None
            return
        target = (node_by_run_id.get(keep) if keep is not None else None) or tree.root.children[0]
        tree.move_cursor(target)
        self._load_node(target)

    def _run_label(self, row: sqlite3.Row) -> str:
        topic = _shorten(row["topic"], 44)
        return f"⚠ {topic}" if row["error"] else f"{topic}  ({row['source_count']})"

    def _file_children(self, row: sqlite3.Row) -> list[tuple[str, Path]]:
        """Every Markdown file a run produced: the review paper, then a note per cited paper."""
        path = row["path"]
        if not path or row["error"]:
            return []
        run_dir = Path(path).parent
        children: list[tuple[str, Path]] = [("📄 Review paper", Path(path))]
        for label, note in _parse_source_notes(row["sources_json"], run_dir):
            children.append((f"📄 {label}", note))
        return children

    def _load_node(self, node: TreeNode | None) -> None:
        data = (node.data if node is not None else None) or {}
        kind = data.get("kind")
        if kind == "run":
            row = data["row"]
            if row["error"]:
                self._set_doc(
                    f"# {row['topic']}\n\n*Research failed — {_reader.fmt_when(row['created_at'])}*\n\n"
                    f"```\n{row['error']}\n```\n"
                )
                self._loaded_path = None
                return
            body = row["markdown"]
            path = row["path"]
            if not body and path:
                try:
                    body = Path(path).read_text(encoding="utf-8")
                except OSError as exc:
                    body = f"*Couldn't read `{path}`: {exc}*"
            self._set_doc(research_mod.display_markdown(body or "*(empty)*", path=path))
            self._loaded_path = Path(path) if path else None
        elif kind == "file":
            p = Path(data["path"])
            try:
                text = p.read_text(encoding="utf-8")
            except OSError as exc:
                text = f"*Couldn't read `{p}`: {exc}*"
            self._set_doc(research_mod.display_markdown(text, path=p))
            self._loaded_path = p
        else:
            self._set_doc(_INTRO)
            self._loaded_path = None

    def _set_doc(self, markdown: str) -> None:
        self.query_one("#research-doc", Markdown).update(markdown)

    def _current_run_id(self) -> int | None:
        row = self._current_run_row()
        return row["id"] if row is not None else None

    def _current_run_row(self) -> sqlite3.Row | None:
        node = self.query_one("#research-tree", Tree).cursor_node
        while node is not None:
            data = node.data or {}
            if data.get("kind") == "run":
                return data["row"]
            node = node.parent
        return None

    def _cursor_path(self) -> Path | None:
        node = self.query_one("#research-tree", Tree).cursor_node
        data = (node.data if node else None) or {}
        if data.get("kind") == "file":
            return Path(data["path"])
        if data.get("kind") == "run" and data["row"]["path"]:
            return Path(data["row"]["path"])
        return None

    def on_tree_node_highlighted(self, event: Tree.NodeHighlighted) -> None:
        self._load_node(event.node)

    def on_markdown_link_clicked(self, event: Markdown.LinkClicked) -> None:
        # The only useful link we inject is the "open this file" header; citation
        # links are rendered as plain text, so this is just belt-and-braces.
        event.stop()
        href = (event.href or "").strip()
        if href.startswith("file:"):
            self._open_path(_path_from_file_uri(href))
        elif href:
            self.notify(href, title="External link (not opened)")

    # --- running the agent --------------------------------------------------

    def on_input_submitted(self, event: Input.Submitted) -> None:
        if event.input.id != "research-topic":
            return
        topic = event.value.strip()
        if not topic:
            return
        if self._busy:
            self.notify("A research run is already in progress.", severity="warning")
            return
        if not llm.available():
            self.notify(
                "The `claude` CLI isn't on your PATH — install it to use deep research.",
                severity="error",
            )
            return
        event.input.value = ""
        self._begin(topic)

    def _begin(self, topic: str) -> None:
        self._busy = True
        self._started_at = time.monotonic()
        self._last_action = "starting…"
        status = self.query_one("#research-status", Static)
        status.remove_class("failed")
        status.add_class("busy")
        self.query_one("#research-topic", Input).disabled = True
        self._render_status()
        self._tick = self.set_interval(1.0, self._render_status)
        self.run_worker(self._do_research(topic), exclusive=True, group="research")

    def _render_status(self) -> None:
        if not self._busy:
            return
        mm, ss = divmod(int(time.monotonic() - self._started_at), 60)
        self.query_one("#research-status", Static).update(
            f"⏳ {mm}:{ss:02d}  ·  {self._last_action}"
        )

    def _on_event(self, kind: str, text: str) -> None:
        # Called from the worker (same event loop) as the agent searches & reads.
        text = " ".join(text.split())
        if not text:
            return
        if kind == "text" and len(text) > 90:
            text = text[:89].rstrip() + "…"
        self._last_action = text
        if self._busy:
            self._render_status()

    async def _do_research(self, topic: str) -> None:
        result = None
        try:
            result = await research_mod.run_research(
                topic, db=self.app.db, config=self.app.config, on_event=self._on_event
            )
        except Exception as exc:  # noqa: BLE001 — surface, don't crash the pane
            self.notify(f"Research crashed: {type(exc).__name__}: {exc}", severity="error")
        finally:
            self._busy = False
            if self._tick is not None:
                self._tick.stop()
                self._tick = None
            self.query_one("#research-topic", Input).disabled = False
            self.query_one("#research-status", Static).remove_class("busy")

        status = self.query_one("#research-status", Static)
        if result is None:
            status.update("")
        elif result.ok:
            where = result.dir or result.path
            status.update(f"✓ {result.source_count} sources · {where.name if where else ''}")
            self.notify(
                f"Saved “{_shorten(result.title, 50)}” — {result.source_count} source note(s)\n{where}",
                title="Research complete",
            )
        else:
            status.add_class("failed")
            status.update(f"⚠ {result.error}")
            self.notify(f"Research failed: {result.error}", severity="error", title="Research")

        self.reload(select_run_id=result.research_id if result else None)

    # --- file actions -------------------------------------------------------

    def action_open_file(self) -> None:
        path = self._cursor_path()
        if path is None:
            self.notify("Nothing to open here.", severity="warning")
            return
        self._open_path(path)

    def action_open_folder(self) -> None:
        self._open_path(research_mod.output_dir(self.app.config))

    def _open_path(self, path: Path) -> None:
        """Hand *path* to the OS default opener (an editor for .md, a file browser for dirs)."""
        try:
            if sys.platform == "darwin":
                subprocess.Popen(
                    ["open", str(path)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
                )
            elif os.name == "nt":
                os.startfile(str(path))  # type: ignore[attr-defined]  # noqa: S606
            elif shutil.which("xdg-open"):
                subprocess.Popen(
                    ["xdg-open", str(path)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
                )
            else:
                webbrowser.open(path.as_uri())
        except Exception as exc:  # noqa: BLE001
            self.notify(f"Couldn't open {path}: {exc}", severity="warning")

    def action_delete(self) -> None:
        if self._busy:
            return
        row = self._current_run_row()
        if row is None:
            return
        research_id, topic = row["id"], row["topic"]
        target = self._delete_target(row["path"])

        def _resolved(confirmed: bool | None) -> None:
            if not confirmed:
                return
            store.delete_research(self.app.db, research_id)
            removed = False
            problem: str | None = None
            if target is not None:
                try:
                    if target.is_dir():
                        shutil.rmtree(target)
                        removed = True
                    elif target.is_file():
                        target.unlink()
                        removed = True
                except OSError as exc:
                    problem = str(exc)
            self.reload()
            if problem:
                self.notify(
                    f"Removed the entry, but couldn't delete the files: {problem}",
                    severity="warning",
                )
            else:
                self.notify(
                    f"Deleted “{_shorten(topic, 44)}”{' and its files.' if removed else '.'}"
                )

        self.app.push_screen(_ConfirmDelete(topic=topic, target=target), _resolved)

    def action_toggle_focus(self) -> None:
        self.toggle_class("focus-reader")

    def _delete_target(self, path: str | None) -> Path | None:
        """What `Delete` should remove: the run folder (`…/<run>/paper.md`), else the bare file."""
        if not path:
            return None
        p = Path(path)
        run_dir = p.parent
        out_dir = research_mod.output_dir(self.app.config)
        try:
            if p.name == "paper.md" and run_dir != out_dir and run_dir.parent == out_dir:
                return run_dir
        except OSError:
            pass
        return p


def _parse_source_notes(sources_json: str | None, run_dir: Path) -> list[tuple[str, Path]]:
    """``[(label, absolute path)]`` for each cited-paper note recorded for a run."""
    notes: list[tuple[str, Path]] = []
    parsed = None
    if sources_json:
        try:
            parsed = json.loads(sources_json)
        except (TypeError, json.JSONDecodeError):
            parsed = None
    if isinstance(parsed, list) and parsed:
        for entry in parsed:
            if not isinstance(entry, dict) or not entry.get("file"):
                continue
            cite = _shorten(str(entry.get("citation") or entry["file"]), 48)
            n = entry.get("n")
            label = f"[{n}] {cite}" if n is not None else cite
            if entry.get("fulltext"):
                label += "  ✓"
            notes.append((label, run_dir / entry["file"]))
        return notes
    # older runs (or a missing sources_json): fall back to listing the sources/ folder
    folder = run_dir / "sources"
    if folder.is_dir():
        notes = [(p.stem, p) for p in sorted(folder.glob("*.md"))]
    return notes


class _ConfirmDelete(ModalScreen[bool]):
    """A small yes/no over the Research pane before we delete a run (paper + source notes)."""

    BINDINGS = [
        Binding("escape", "cancel", "Cancel"),
        Binding("y", "confirm", "Delete"),
    ]

    DEFAULT_CSS = """
    _ConfirmDelete { align: center middle; }
    _ConfirmDelete #box {
        width: 70; max-width: 90%; height: auto; padding: 1 2;
        border: round $error; background: $surface;
    }
    _ConfirmDelete #box Label { width: 100%; margin-bottom: 1; }
    _ConfirmDelete .muted { color: $text-muted; }
    _ConfirmDelete #buttons { height: auto; align-horizontal: right; }
    _ConfirmDelete #buttons Button { margin-left: 2; }
    """

    def __init__(self, *, topic: str, target: Path | None) -> None:
        super().__init__()
        self._topic = topic
        self._target = target

    def compose(self) -> ComposeResult:
        with Vertical(id="box"):
            yield Label(f"Delete the research on “{_shorten(self._topic, 50)}”?")
            if self._target is None:
                yield Label("(There's nothing on disk for this entry.)", classes="muted")
            elif self._target.is_dir():
                yield Label(
                    f"This permanently deletes the whole folder — the review and every source note:\n{self._target}",
                    classes="muted",
                )
            else:
                yield Label(f"This permanently deletes the file:\n{self._target}", classes="muted")
            with Horizontal(id="buttons"):
                yield Button("Cancel", id="cancel")
                yield Button("Delete", id="confirm", variant="error")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        self.dismiss(event.button.id == "confirm")

    def action_cancel(self) -> None:
        self.dismiss(False)

    def action_confirm(self) -> None:
        self.dismiss(True)


def _path_from_file_uri(uri: str) -> Path:
    return Path(unquote(urlparse(uri).path))


def _shorten(text: str, limit: int = 72) -> str:
    text = " ".join(str(text).split())
    return text if len(text) <= limit else text[: limit - 1].rstrip() + "…"
