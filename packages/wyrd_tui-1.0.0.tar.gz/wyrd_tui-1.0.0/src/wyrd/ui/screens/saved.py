"""Saved pane — items you've liked, with the article snapshot, tags and notes.

Left: a search box over a table of saved items (newest first). Right: editable
**Tags** (comma-separated) and **Notes** fields above the article rendered as
Markdown. Edits are written back when you move to another item, on Ctrl+S, and
when the pane closes. A simple substring search (`/` focuses the box) covers
title / summary / url / article text / notes / tags; FTS5 ranking is M5.
"""

from __future__ import annotations

import sqlite3
from typing import TYPE_CHECKING, cast

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Vertical, VerticalScroll
from textual.widget import Widget
from textual.widgets import DataTable, Input, Markdown, TextArea

from wyrd.core import store
from wyrd.ui import _reader

if TYPE_CHECKING:
    from wyrd.ui.app import WyrdApp


class SavedPane(Widget):
    @property
    def app(self) -> WyrdApp:  # type: ignore[override]
        return cast("WyrdApp", super().app)

    BINDINGS = [
        Binding("ctrl+s", "save_meta", "Save tags/notes"),
        Binding("y", "copy_url", "Copy URL"),
        Binding("f4", "toggle_focus", "Focus reader"),
        Binding("slash", "focus_search", "Search", show=False),
    ]

    DEFAULT_CSS = """
    SavedPane { layout: horizontal; height: 1fr; }
    SavedPane #saved-left { width: 45%; }
    SavedPane #saved-search { margin: 0 0 1 0; }
    SavedPane #saved-table { height: 1fr; }
    SavedPane #saved-right { width: 1fr; border-left: solid $panel-darken-1; padding: 0 1; }
    SavedPane #saved-tags { border: round $panel; }
    SavedPane #saved-notes { border: round $panel; height: 6; }
    SavedPane #saved-article-wrap { height: 1fr; padding: 0 1; }
    SavedPane.focus-reader #saved-left { display: none; }
    SavedPane.focus-reader #saved-right { border-left: none; }
    """

    def __init__(self) -> None:
        super().__init__()
        self._items: list[sqlite3.Row] = []
        self._current_id: int | None = None
        self._unsubs: list = []

    def compose(self) -> ComposeResult:
        with Vertical(id="saved-left"):
            yield Input(placeholder="search saved…", id="saved-search")
            yield DataTable(id="saved-table", cursor_type="row", zebra_stripes=True)
        with Vertical(id="saved-right"):
            tags = Input(id="saved-tags", placeholder="comma, separated, tags")
            tags.border_title = "Tags"
            yield tags
            notes = TextArea(id="saved-notes")
            notes.border_title = "Notes"
            yield notes
            yield VerticalScroll(Markdown("", id="saved-article"), id="saved-article-wrap")

    def on_mount(self) -> None:
        self.query_one("#saved-table", DataTable).add_columns("Title", "Source", "Saved")
        self._unsubs = [
            self.app.events.subscribe(
                "item_saved", lambda **_: self.call_after_refresh(self.reload)
            )
        ]
        self.reload()

    def on_unmount(self) -> None:
        self._flush_current()
        for unsub in self._unsubs:
            unsub()
        self._unsubs = []

    # --- list ---------------------------------------------------------------

    def reload(self, *, query: str | None = None) -> None:
        self._flush_current()
        if query is None:
            query = self.query_one("#saved-search", Input).value
        table = self.query_one("#saved-table", DataTable)
        keep_id = self._current_id
        self._items = list(store.list_saved_items(self.app.db, query=query))
        table.clear()
        for row in self._items:
            table.add_row(
                _shorten(row["title"] or row["url"]),
                row["source_kind"],
                _reader.fmt_when(row["saved_at"]),
            )
        if not self._items:
            self._current_id = None
            self.query_one("#saved-tags", Input).value = ""
            self.query_one("#saved-notes", TextArea).load_text("")
            empty = "# Nothing matches" if (query or "").strip() else "# Nothing saved yet"
            hint = (
                "Try a different search."
                if (query or "").strip()
                else "Press **l** on an item in the Feed to save it here."
            )
            self.query_one("#saved-article", Markdown).update(f"{empty}\n\n{hint}")
            return
        idx = next((i for i, r in enumerate(self._items) if r["id"] == keep_id), 0)
        table.move_cursor(row=idx)
        self._show(idx)

    def _show(self, idx: int) -> None:
        row = self._items[idx]
        self._current_id = row["id"]
        self.query_one("#saved-tags", Input).value = ", ".join(store.parse_tags(row["tags_json"]))
        self.query_one("#saved-notes", TextArea).load_text(row["notes"] or "")
        body = row["full_text"]
        if not body:
            extraction = store.get_extraction(self.app.db, row["id"])
            body = extraction["markdown"] if extraction and extraction["markdown"] else None
        self.query_one("#saved-article", Markdown).update(
            _reader.article_markdown(
                row, body=body or "*(no article text saved)*", lede=row["summary"]
            )
        )

    # --- editing ------------------------------------------------------------

    def _flush_current(self) -> None:
        if self._current_id is None:
            return
        try:
            tags = [
                t.strip()
                for t in self.query_one("#saved-tags", Input).value.split(",")
                if t.strip()
            ]
            notes = self.query_one("#saved-notes", TextArea).text
        except Exception:
            return  # widgets not mounted (e.g. during teardown)
        store.update_saved(self.app.db, self._current_id, tags=tags, notes=notes)

    def action_save_meta(self) -> None:
        if self._current_id is None:
            return
        self._flush_current()
        self.notify("Saved tags & notes.", title="Saved")

    def action_focus_search(self) -> None:
        self.query_one("#saved-search", Input).focus()

    def action_toggle_focus(self) -> None:
        self.toggle_class("focus-reader")

    def action_copy_url(self) -> None:
        if self._current_id is None:
            return
        row = next((r for r in self._items if r["id"] == self._current_id), None)
        if row is None or not row["url"]:
            return
        url = row["url"]
        self.app.copy_to_clipboard(url)
        self.notify(f"Copied: {url[:60]}", title="Clipboard")

    # --- events -------------------------------------------------------------

    def on_data_table_row_highlighted(self, event: DataTable.RowHighlighted) -> None:
        if (
            0 <= event.cursor_row < len(self._items)
            and self._items[event.cursor_row]["id"] != self._current_id
        ):
            self._flush_current()
            self._show(event.cursor_row)

    def on_data_table_row_selected(self, event: DataTable.RowSelected) -> None:  # noqa: ARG002
        # Enter on a row activates reader focus mode (matches the Feed pane).
        self.add_class("focus-reader")

    def on_input_submitted(self, event: Input.Submitted) -> None:
        if event.input.id == "saved-search":
            self.reload(query=event.value)
        elif event.input.id == "saved-tags":
            self._flush_current()
            self.notify("Tags saved.", title="Saved")


def _shorten(text: str, limit: int = 64) -> str:
    text = " ".join(text.split())
    return text if len(text) <= limit else text[: limit - 1].rstrip() + "…"
