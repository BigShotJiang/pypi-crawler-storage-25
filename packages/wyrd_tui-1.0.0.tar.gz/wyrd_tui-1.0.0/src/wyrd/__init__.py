"""wyrd — a TUI for personal knowledge management.

Reads RSS / Hacker News / Reddit, snapshots what you like, runs deep-research
papers, and (optionally) exports everything into an Obsidian vault. The name is
Anglo-Saxon for the woven thread of personal fate — the thing that ties what
you've read, saved, and learned into one strand.
"""

__version__ = "1.0.0"


def main() -> None:
    """Console-script entrypoint (`wyrd`)."""
    from wyrd.ui.app import WyrdApp

    WyrdApp().run()
