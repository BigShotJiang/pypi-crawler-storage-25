"""SQLite storage: connection, schema, and forward-only migrations.

The schema is versioned via ``meta('schema_version')`` and brought up to date by
applying the ordered list of :data:`MIGRATIONS`. Each migration is a plain SQL
script run inside a transaction.
"""

from __future__ import annotations

import sqlite3
from pathlib import Path

from wyrd.core import paths

# --- migrations -------------------------------------------------------------
# Append-only. Never edit a migration once it has shipped; add a new one.

_M1_INITIAL = """
CREATE TABLE sources (
    id          INTEGER PRIMARY KEY,
    kind        TEXT NOT NULL,
    config_json TEXT NOT NULL DEFAULT '{}',
    enabled     INTEGER NOT NULL DEFAULT 1,
    last_run_at TEXT
);

CREATE TABLE items (
    id            INTEGER PRIMARY KEY,
    source_id     INTEGER REFERENCES sources(id),
    url           TEXT NOT NULL,
    url_hash      TEXT NOT NULL UNIQUE,
    title         TEXT,
    author        TEXT,
    summary       TEXT,
    published_at  TEXT,
    discovered_at TEXT NOT NULL,
    raw_json      TEXT,
    state         TEXT NOT NULL DEFAULT 'new'
                  CHECK (state IN ('new', 'seen', 'liked', 'dismissed'))
);
CREATE INDEX items_state_idx ON items(state);
CREATE INDEX items_source_idx ON items(source_id);

CREATE TABLE saved (
    item_id   INTEGER PRIMARY KEY REFERENCES items(id),
    saved_at  TEXT NOT NULL,
    full_text TEXT,
    tags_json TEXT NOT NULL DEFAULT '[]',
    notes     TEXT
);

CREATE TABLE runs (
    id          INTEGER PRIMARY KEY,
    source_id   INTEGER REFERENCES sources(id),
    started_at  TEXT NOT NULL,
    finished_at TEXT,
    found       INTEGER NOT NULL DEFAULT 0,
    new         INTEGER NOT NULL DEFAULT 0,
    error       TEXT
);

CREATE VIRTUAL TABLE items_fts USING fts5(
    title, summary, full_text,
    content=''  -- contentless: we manage rows explicitly
);
"""

_M2_EXTRACTIONS = """
CREATE TABLE extractions (
    item_id    INTEGER PRIMARY KEY REFERENCES items(id),
    fetched_at TEXT NOT NULL,
    title      TEXT,
    markdown   TEXT,
    error      TEXT
);
"""

_M3_RESEARCH = """
CREATE TABLE research (
    id           INTEGER PRIMARY KEY,
    topic        TEXT NOT NULL,
    title        TEXT,
    path         TEXT,
    markdown     TEXT,
    source_count INTEGER NOT NULL DEFAULT 0,
    created_at   TEXT NOT NULL,
    error        TEXT
);
CREATE INDEX research_created_idx ON research(created_at DESC);
"""

# Per-run list of cited papers: [{"n", "citation", "url", "file"}], "file"
# being the source note's path relative to the run directory.
_M4_RESEARCH_SOURCES = """
ALTER TABLE research ADD COLUMN sources_json TEXT;
"""

# Populate the contentless items_fts virtual table and install triggers that
# keep it in sync with items + saved. items_fts is contentless, so every row has
# to be managed by hand: inserts/updates go through INSERT, deletes use the
# special INSERT INTO items_fts(items_fts, rowid, ...) VALUES('delete', ...)
# contract documented at https://www.sqlite.org/fts5.html#the_delete_command.
# The full_text column carries a space-joined blob of saved.full_text + notes +
# tags_json so all three are searchable by the same MATCH query.
_M5_FTS_SYNC = """
INSERT INTO items_fts(rowid, title, summary, full_text)
SELECT i.id,
       COALESCE(i.title, ''),
       COALESCE(i.summary, ''),
       TRIM(COALESCE(sv.full_text, '') || ' ' ||
            COALESCE(sv.notes, '')     || ' ' ||
            COALESCE(sv.tags_json, ''))
FROM items i LEFT JOIN saved sv ON sv.item_id = i.id;

CREATE TRIGGER items_fts_ai AFTER INSERT ON items BEGIN
    INSERT INTO items_fts(rowid, title, summary, full_text)
    VALUES (new.id, COALESCE(new.title, ''), COALESCE(new.summary, ''), '');
END;

CREATE TRIGGER items_fts_au AFTER UPDATE OF title, summary ON items BEGIN
    INSERT INTO items_fts(items_fts, rowid, title, summary, full_text)
    VALUES ('delete', old.id,
            COALESCE(old.title, ''), COALESCE(old.summary, ''),
            TRIM(COALESCE((SELECT full_text FROM saved WHERE item_id = old.id), '') || ' ' ||
                 COALESCE((SELECT notes     FROM saved WHERE item_id = old.id), '') || ' ' ||
                 COALESCE((SELECT tags_json FROM saved WHERE item_id = old.id), '')));
    INSERT INTO items_fts(rowid, title, summary, full_text)
    VALUES (new.id, COALESCE(new.title, ''), COALESCE(new.summary, ''),
            TRIM(COALESCE((SELECT full_text FROM saved WHERE item_id = new.id), '') || ' ' ||
                 COALESCE((SELECT notes     FROM saved WHERE item_id = new.id), '') || ' ' ||
                 COALESCE((SELECT tags_json FROM saved WHERE item_id = new.id), '')));
END;

CREATE TRIGGER items_fts_ad AFTER DELETE ON items BEGIN
    INSERT INTO items_fts(items_fts, rowid, title, summary, full_text)
    VALUES ('delete', old.id,
            COALESCE(old.title, ''), COALESCE(old.summary, ''),
            TRIM(COALESCE((SELECT full_text FROM saved WHERE item_id = old.id), '') || ' ' ||
                 COALESCE((SELECT notes     FROM saved WHERE item_id = old.id), '') || ' ' ||
                 COALESCE((SELECT tags_json FROM saved WHERE item_id = old.id), '')));
END;

CREATE TRIGGER saved_fts_ai AFTER INSERT ON saved BEGIN
    INSERT INTO items_fts(items_fts, rowid, title, summary, full_text)
    VALUES ('delete', new.item_id,
            COALESCE((SELECT title   FROM items WHERE id = new.item_id), ''),
            COALESCE((SELECT summary FROM items WHERE id = new.item_id), ''),
            '');
    INSERT INTO items_fts(rowid, title, summary, full_text)
    VALUES (new.item_id,
            COALESCE((SELECT title   FROM items WHERE id = new.item_id), ''),
            COALESCE((SELECT summary FROM items WHERE id = new.item_id), ''),
            TRIM(COALESCE(new.full_text, '') || ' ' ||
                 COALESCE(new.notes, '')     || ' ' ||
                 COALESCE(new.tags_json, '')));
END;

CREATE TRIGGER saved_fts_au AFTER UPDATE OF full_text, notes, tags_json ON saved BEGIN
    INSERT INTO items_fts(items_fts, rowid, title, summary, full_text)
    VALUES ('delete', new.item_id,
            COALESCE((SELECT title   FROM items WHERE id = new.item_id), ''),
            COALESCE((SELECT summary FROM items WHERE id = new.item_id), ''),
            TRIM(COALESCE(old.full_text, '') || ' ' ||
                 COALESCE(old.notes, '')     || ' ' ||
                 COALESCE(old.tags_json, '')));
    INSERT INTO items_fts(rowid, title, summary, full_text)
    VALUES (new.item_id,
            COALESCE((SELECT title   FROM items WHERE id = new.item_id), ''),
            COALESCE((SELECT summary FROM items WHERE id = new.item_id), ''),
            TRIM(COALESCE(new.full_text, '') || ' ' ||
                 COALESCE(new.notes, '')     || ' ' ||
                 COALESCE(new.tags_json, '')));
END;

CREATE TRIGGER saved_fts_ad AFTER DELETE ON saved BEGIN
    INSERT INTO items_fts(items_fts, rowid, title, summary, full_text)
    VALUES ('delete', old.item_id,
            COALESCE((SELECT title   FROM items WHERE id = old.item_id), ''),
            COALESCE((SELECT summary FROM items WHERE id = old.item_id), ''),
            TRIM(COALESCE(old.full_text, '') || ' ' ||
                 COALESCE(old.notes, '')     || ' ' ||
                 COALESCE(old.tags_json, '')));
    INSERT INTO items_fts(rowid, title, summary, full_text)
    VALUES (old.item_id,
            COALESCE((SELECT title   FROM items WHERE id = old.item_id), ''),
            COALESCE((SELECT summary FROM items WHERE id = old.item_id), ''),
            '');
END;
"""

MIGRATIONS: list[str] = [
    _M1_INITIAL,
    _M2_EXTRACTIONS,
    _M3_RESEARCH,
    _M4_RESEARCH_SOURCES,
    _M5_FTS_SYNC,
]
SCHEMA_VERSION = len(MIGRATIONS)


# --- connection -------------------------------------------------------------


def connect(db_path: Path | None = None) -> sqlite3.Connection:
    """Open (creating if needed) the database and apply pending migrations."""
    path = db_path or paths.db_file()
    conn = sqlite3.connect(path, isolation_level=None)  # autocommit; we manage txns
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode = WAL")
    conn.execute("PRAGMA foreign_keys = ON")
    _ensure_meta(conn)
    _migrate(conn)
    return conn


def _ensure_meta(conn: sqlite3.Connection) -> None:
    conn.execute("CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT)")


def _current_version(conn: sqlite3.Connection) -> int:
    row = conn.execute("SELECT value FROM meta WHERE key = 'schema_version'").fetchone()
    return int(row[0]) if row else 0


def _migrate(conn: sqlite3.Connection) -> None:
    version = _current_version(conn)
    if version >= SCHEMA_VERSION:
        return
    for index in range(version, SCHEMA_VERSION):
        # executescript() manages its own transaction (it COMMITs any pending one
        # first), so we don't wrap it by hand. The meta bump that follows is the
        # commit point for "this migration applied".
        conn.executescript(MIGRATIONS[index])
        conn.execute(
            "INSERT INTO meta(key, value) VALUES ('schema_version', ?) "
            "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
            (str(index + 1),),
        )
