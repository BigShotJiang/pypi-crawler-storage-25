"""Convert trafilatura's XML output to clean Markdown.

trafilatura's built-in ``output_format="markdown"`` mangles things we care
about — it flattens the indentation inside code blocks, splits paragraphs that
contain inline ``<code>``, and sometimes emits the article body twice. Its XML
output, on the other hand, is well structured (``<head>``, ``<p>``, ``<code>``,
``<list>``/``<item>``, ``<table>``/``<row>``/``<cell>``, ``<quote>``, ``<hi>``,
``<ref>``), so we render Markdown from that instead.

The element vocabulary handled here:

- ``<head rend="hN">`` → ``#`` … ``######``
- ``<p>`` → a paragraph (inline ``<hi>``/``<ref>``/``<code>``/``<lb>`` handled)
- ``<code>`` as a block child → a fenced ``` block, indentation preserved verbatim
- ``<code>`` inside a ``<p>`` → inline `` `code` ``
- ``<list rend="ul|ol">`` with ``<item>`` (nesting supported) → ``-`` / ``1.``
- ``<table>`` with ``<row>`` / ``<cell role="head">`` → a GitHub pipe table
- ``<quote>`` → ``>`` blockquote
- ``<graphic>`` → dropped (images don't render in the TUI)
"""

from __future__ import annotations

import re
import xml.etree.ElementTree as ET

_WS = re.compile(r"[ \t\r\f\v]+")
_NL_WS = re.compile(r" *\n *")
# Characters that would otherwise be read as Markdown syntax mid-text. We keep
# this minimal — escaping everything makes the source noisy for little gain.
_INLINE_ESCAPE = re.compile(r"([`*])")


def xml_to_markdown(xml: str) -> str:
    """Render trafilatura XML (a ``<doc><main>…</main></doc>`` string) as Markdown."""
    try:
        root = ET.fromstring(xml)
    except ET.ParseError:
        return ""
    body = root.find("main")
    if body is None:
        body = root

    blocks: list[str] = []
    seen: set[str] = set()
    for child in body:
        if child.tag == "comments":
            continue
        for block in _render_block(child):
            block = block.rstrip()
            if not block.strip():
                continue
            key = " ".join(block.split())
            if len(key) >= 16:  # trafilatura occasionally repeats the whole body
                if key in seen:
                    continue
                seen.add(key)
            blocks.append(block)
    return "\n\n".join(blocks).strip()


# --- block-level ------------------------------------------------------------


def _render_block(el: ET.Element) -> list[str]:
    tag = el.tag
    if tag == "head":
        level = _heading_level(el.get("rend"))
        text = _inline(el).strip()
        return [f"{'#' * level} {text}"] if text else []
    if tag in ("p", "item", "comment"):
        text = _inline(el).strip()
        return [text] if text else []
    if tag == "code":
        code = _code_text(el).rstrip("\n")
        return [f"```\n{code}\n```"]
    if tag == "quote":
        return _render_quote(el)
    if tag == "list":
        lines = _render_list(el, ordered=(el.get("rend") == "ol"), level=0)
        return ["\n".join(lines)] if lines else []
    if tag == "table":
        return _render_table(el)
    if tag in ("graphic", "figure"):
        return []
    # unknown block — best effort as a paragraph
    text = _inline(el).strip()
    return [text] if text else []


def _render_quote(el: ET.Element) -> list[str]:
    inner_blocks: list[str] = []
    if el.text and el.text.strip():
        inner_blocks.append(_collapse(el.text).strip())
    for child in el:
        inner_blocks.extend(_render_block(child))
    text = "\n\n".join(b for b in inner_blocks if b.strip())
    if not text.strip():
        return []
    quoted = "\n".join(f"> {line}" if line else ">" for line in text.split("\n"))
    return [quoted]


def _render_list(el: ET.Element, *, ordered: bool, level: int) -> list[str]:
    lines: list[str] = []
    pad = "    " * level  # 4 spaces/level keeps sublists valid under "1." markers too
    counter = 1
    for item in el:
        if item.tag != "item":
            continue
        bullet = f"{counter}." if ordered else "-"
        counter += 1

        inline_parts: list[str] = []
        nested: list[tuple[ET.Element, bool]] = []
        if item.text:
            inline_parts.append(_escape(item.text))
        for child in item:
            if child.tag == "list":
                nested.append((child, child.get("rend") == "ol"))
            elif child.tag in ("p", "item"):
                inline_parts.append(_inline(child))
            elif child.tag == "code":
                inline_parts.append(f"`{_code_text(child).strip()}`")
            else:
                inline_parts.append(_inline_child(child))
            if child.tail:
                inline_parts.append(_escape(child.tail))
        first = _collapse("".join(inline_parts)).strip()
        lines.append(f"{pad}{bullet} {first}".rstrip())
        for sub_el, sub_ordered in nested:
            lines.extend(_render_list(sub_el, ordered=sub_ordered, level=level + 1))
    return lines


def _render_table(el: ET.Element) -> list[str]:
    rows: list[tuple[list[str], bool]] = []
    for row in el:
        if row.tag != "row":
            continue
        cells: list[str] = []
        is_head = False
        for cell in row:
            if cell.tag != "cell":
                continue
            if cell.get("role") == "head":
                is_head = True
            text = _collapse(_inline(cell)).strip().replace("|", "\\|")
            text = text.replace("\n", " ")
            cells.append(text)
        if cells:
            rows.append((cells, is_head))
    if not rows:
        return []

    ncols = max(len(cells) for cells, _ in rows)

    def fmt(cells: list[str]) -> str:
        cells = (cells + [""] * ncols)[:ncols]
        return "| " + " | ".join(c or " " for c in cells) + " |"

    head_index = next((i for i, (_, is_head) in enumerate(rows) if is_head), None)
    if head_index is None:
        header = [""] * ncols
        body = rows
    else:
        header = rows[head_index][0]
        body = [r for i, r in enumerate(rows) if i != head_index]

    out = [fmt(header), "| " + " | ".join(["---"] * ncols) + " |"]
    out.extend(fmt(cells) for cells, _ in body)
    return ["\n".join(out)]


# --- inline-level -----------------------------------------------------------


def _inline(el: ET.Element) -> str:
    parts: list[str] = []
    if el.text:
        parts.append(_escape(el.text))
    for child in el:
        parts.append(_inline_child(child))
        if child.tail:
            parts.append(_escape(child.tail))
    return _collapse("".join(parts))


def _inline_child(child: ET.Element) -> str:
    tag = child.tag
    if tag == "lb":
        return "\n"
    if tag in ("graphic", "figure"):
        return ""
    if tag == "code":
        return f"`{_code_text(child).strip()}`"
    inner = _inline(child).strip()
    if tag == "hi":
        rend = (child.get("rend") or "").lstrip("#").lower()
        if not inner:
            return ""
        if rend.startswith("b"):  # bold
            return f"**{inner}**"
        if rend.startswith("i"):  # italic
            return f"*{inner}*"
        return inner  # underline / sup / sub etc. — no Markdown equivalent
    if tag == "ref":
        target = (child.get("target") or "").strip()
        if target and not target.startswith("#"):
            return f"[{inner or target}]({target})"
        return inner
    if tag in ("p", "item", "quote", "list"):
        return inner  # unexpected nesting; flatten
    return inner


# --- helpers ----------------------------------------------------------------


def _heading_level(rend: str | None) -> int:
    if rend and rend.startswith("h") and rend[1:].isdigit():
        return min(max(int(rend[1:]), 1), 6)
    return 2


def _code_text(el: ET.Element) -> str:
    out: list[str] = []
    if el.text:
        out.append(el.text)
    for sub in el:
        if sub.tag == "lb":
            out.append("\n")
        else:
            out.append("".join(sub.itertext()))
        if sub.tail:
            out.append(sub.tail)
    return "".join(out)


def _escape(text: str) -> str:
    return _INLINE_ESCAPE.sub(r"\\\1", text)


def _collapse(text: str) -> str:
    text = _WS.sub(" ", text)
    return _NL_WS.sub("\n", text)
