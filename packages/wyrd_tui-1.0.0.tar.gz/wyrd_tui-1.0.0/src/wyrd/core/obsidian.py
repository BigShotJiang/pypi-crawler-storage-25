"""Obsidian-vault export: write liked articles + research output into a vault.

Direct filesystem writes — no Obsidian CLI required. Obsidian picks up new
files in a vault automatically because a vault is just a folder of `.md`
files. This means the integration works headless (over SSH, on a server)
even if Obsidian Desktop isn't installed on the host.

Layout::

    <vault>/<folder>/
      saved/                       ← liked articles, flat ``<date>-<slug>.md``
      research/                    ← research runs, ``<date>-<slug>/paper.md`` +
                                     ``sources/NN-….md`` notes

``folder`` defaults to ``wyrd``; the ``saved/`` and ``research/`` split is
hardcoded so the two kinds of artifact don't commingle in the same directory.
"""

from __future__ import annotations

import json
import logging
import re
import sqlite3
from datetime import datetime
from pathlib import Path

from wyrd.core import store
from wyrd.core.config import Config

log = logging.getLogger(__name__)

_SLUG_RE = re.compile(r"[^a-z0-9]+")


def enabled(config: Config) -> bool:
    return bool(getattr(getattr(config, "obsidian", None), "vault", "").strip())


def wyrd_dir(config: Config) -> Path | None:
    """The ``<vault>/<folder>`` parent directory, or None if Obsidian isn't configured."""
    if not enabled(config):
        return None
    vault = Path(config.obsidian.vault).expanduser()
    folder = (config.obsidian.folder or "wyrd").strip().strip("/")
    return (vault / folder) if folder else vault


def saved_dir(config: Config) -> Path | None:
    """``<vault>/<folder>/saved`` — where liked-article notes land."""
    parent = wyrd_dir(config)
    return None if parent is None else parent / "saved"


def research_dir(config: Config) -> Path | None:
    """``<vault>/<folder>/research`` — where research runs land."""
    parent = wyrd_dir(config)
    return None if parent is None else parent / "research"


def _ensure_dir(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    return path


def slugify(text: str, max_len: int = 60) -> str:
    """Turn a title into a filesystem-safe slug."""
    text = (text or "").strip().lower()
    if not text:
        return "untitled"
    slug = _SLUG_RE.sub("-", text).strip("-")
    if not slug:
        return "untitled"
    if len(slug) > max_len:
        slug = slug[:max_len].rstrip("-") or slug[:max_len]
    return slug


def _yaml_scalar(value: str) -> str:
    """Render *value* as a double-quoted YAML scalar (JSON escaping is good enough)."""
    return json.dumps(value, ensure_ascii=False)


def _frontmatter(meta: dict) -> str:
    """Render *meta* as YAML frontmatter. Lists become flow-sequences for terseness."""
    lines = ["---"]
    for key, raw in meta.items():
        if raw is None or raw == "":
            continue
        if isinstance(raw, list):
            items = [_yaml_scalar(str(v)) for v in raw if str(v).strip()]
            if not items:
                continue
            lines.append(f"{key}: [{', '.join(items)}]")
        else:
            lines.append(f"{key}: {_yaml_scalar(str(raw))}")
    lines.append("---")
    return "\n".join(lines)


def _saved_filename(item_row: sqlite3.Row, saved_row: sqlite3.Row | None) -> str:
    saved_at = (saved_row["saved_at"] if saved_row else None) or _now_iso()
    try:
        date = datetime.fromisoformat(saved_at).date().isoformat()
    except (TypeError, ValueError):
        date = datetime.now().date().isoformat()
    return f"{date}-{slugify(item_row['title'] or item_row['url'])}.md"


def _now_iso() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


def _parse_tags(tags_json: str | None) -> list[str]:
    return store.parse_tags(tags_json)


def write_saved_note(
    config: Config,
    item_row: sqlite3.Row,
    saved_row: sqlite3.Row | None,
    body_markdown: str,
) -> Path | None:
    """Write *item_row* as a Markdown note under the vault, or return None when
    Obsidian isn't configured / the body is empty.

    The file is overwritten on every call — re-liking the same item is
    idempotent, and a body that lands after extraction will replace any earlier
    placeholder we might have written.
    """
    out_root = saved_dir(config)
    if out_root is None:
        return None
    body = (body_markdown or "").strip()
    if not body:
        return None
    try:
        _ensure_dir(out_root)
    except OSError as exc:
        log.warning("can't create Obsidian folder %s: %s", out_root, exc)
        return None
    tags = [
        "wyrd/saved",
        item_row["source_kind"],
        *_parse_tags(saved_row["tags_json"] if saved_row else None),
    ]
    meta = {
        "title": item_row["title"] or "(untitled)",
        "url": item_row["url"],
        "source": item_row["source_kind"],
        "author": item_row["author"],
        "published": item_row["published_at"],
        "saved": saved_row["saved_at"] if saved_row else _now_iso(),
        "tags": sorted({t for t in tags if t}),
        "wyrd_id": item_row["id"],
    }
    notes = (saved_row["notes"] if saved_row else None) or ""
    parts = [_frontmatter(meta), ""]
    if notes.strip():
        parts.append(notes.strip())
        parts.append("")
    parts.append(body)
    path = out_root / _saved_filename(item_row, saved_row)
    try:
        path.write_text("\n".join(parts) + "\n", encoding="utf-8")
    except OSError as exc:
        log.warning("can't write Obsidian note %s: %s", path, exc)
        return None
    return path


def export_all_saved(config: Config, conn: sqlite3.Connection) -> tuple[int, int]:
    """Write every saved item with a body to the configured vault.

    Returns ``(written, skipped)``. Items without an extracted body are skipped
    (an article that was liked but never reached its extraction worker, etc.).
    Idempotent: re-running overwrites the same ``<date>-<slug>.md`` files, so
    this is safe to invoke as many times as you like.
    """
    if not enabled(config):
        return (0, 0)
    written = skipped = 0
    # list_saved_items() returns a JOIN of items+sources+saved, so the same row
    # carries every column write_saved_note needs.
    for row in store.list_saved_items(conn):
        full_text = row["full_text"]
        if not full_text or not full_text.strip():
            skipped += 1
            continue
        if write_saved_note(config, row, row, full_text) is None:
            skipped += 1
        else:
            written += 1
    return (written, skipped)
