"""Fetch a web page and turn it into clean Markdown.

Used by the Feed pane to render an item's content in-app instead of opening a
browser. We let trafilatura strip the boilerplate (it returns structured XML),
then build Markdown from that XML ourselves — trafilatura's own Markdown output
loses code-block indentation and mangles inline code, so :mod:`wyrd.core.xml2md`
does the conversion instead. trafilatura's parsing is synchronous, so we fetch
HTML asynchronously with httpx and run the extraction step on a thread.
"""

from __future__ import annotations

import asyncio
import io
import re
from dataclasses import dataclass

import httpx
import trafilatura

from wyrd.core.xml2md import xml_to_markdown

_USER_AGENT = "wyrd/1.0 (+https://codeberg.org/brhodes/wyrd; personal reader)"


@dataclass(slots=True)
class ExtractedArticle:
    markdown: str
    title: str | None = None


async def fetch_and_extract(url: str, *, timeout: float = 25.0) -> ExtractedArticle:
    async with httpx.AsyncClient(
        timeout=timeout, follow_redirects=True, headers={"User-Agent": _USER_AGENT}
    ) as client:
        resp = await client.get(url)
        resp.raise_for_status()
        ctype = resp.headers.get("content-type", "").lower()
        if "html" not in ctype and not ctype.startswith("text/"):
            raise RuntimeError(f"non-text content type: {ctype or 'unknown'}")
        html = resp.text
    return await asyncio.to_thread(_extract_sync, html, url)


def _extract_xml(html: str, *, favor_recall: bool) -> str | None:
    return trafilatura.extract(
        html,
        output_format="xml",
        include_links=True,
        include_formatting=True,
        include_tables=True,
        include_images=False,
        include_comments=False,
        with_metadata=False,
        favor_recall=favor_recall,
    )


def _extract_sync(html: str, url: str) -> ExtractedArticle:
    xml = _extract_xml(html, favor_recall=False)
    markdown = xml_to_markdown(xml) if xml else ""
    if not markdown.strip():
        # Retry with looser heuristics for pages trafilatura is unsure about.
        xml = _extract_xml(html, favor_recall=True)
        markdown = xml_to_markdown(xml) if xml else ""
    if not markdown.strip():
        raise RuntimeError("nothing extractable on the page")

    title: str | None = None
    try:
        meta = trafilatura.extract_metadata(html, default_url=url)
        if meta is not None:
            title = getattr(meta, "title", None)
    except Exception:  # noqa: BLE001 — metadata is a nice-to-have
        pass

    return ExtractedArticle(markdown=markdown.strip(), title=title)


# --- full documents (PDF or HTML) ------------------------------------------
#
# Used by the deep-research agent to pull down the full text of a cited paper —
# an open-access PDF or HTML article — and turn it into Markdown for later
# checking. PDF text extraction is layout-imperfect but complete; HTML reuses
# the trafilatura pipeline above.

_MAX_DOC_BYTES = 60 * 1024 * 1024
_ARXIV_ABS_RE = re.compile(r"^https?://arxiv\.org/abs/([^?#]+)$", re.IGNORECASE)


def _normalize_doc_url(url: str) -> str:
    """Small nudges toward the actual document (e.g. an arXiv abstract page → its PDF)."""
    match = _ARXIV_ABS_RE.match(url.strip())
    return f"https://arxiv.org/pdf/{match.group(1)}" if match else url.strip()


def _pdf_to_text(data: bytes) -> str:
    from pypdf import PdfReader

    parts: list[str] = []
    try:
        reader = PdfReader(io.BytesIO(data))
        if reader.is_encrypted:
            try:
                reader.decrypt("")  # many "encrypted" PDFs use an empty password
            except Exception:  # noqa: BLE001
                raise RuntimeError("the PDF is password-protected") from None
        for page in reader.pages:
            try:
                text = (page.extract_text() or "").strip()
            except Exception:  # noqa: BLE001 — one bad page shouldn't sink the rest
                text = ""
            if text:
                parts.append(text)
    except RuntimeError:
        raise
    except Exception as exc:  # noqa: BLE001 — any PDF-parsing failure → a clean error
        raise RuntimeError(f"couldn't parse the PDF: {exc}") from exc
    text = re.sub(r"\n{3,}", "\n\n", "\n\n".join(parts)).strip()
    if not text:
        raise RuntimeError("no extractable text in the PDF (a scanned image?)")
    return text


async def fetch_document_markdown(url: str, *, timeout: float = 45.0) -> str:
    """Fetch *url* — a PDF or an HTML page — and return its full content as Markdown.

    Raises ``RuntimeError`` / ``httpx`` errors on anything we can't fetch or read.
    """
    url = _normalize_doc_url(url)
    async with httpx.AsyncClient(
        timeout=timeout, follow_redirects=True, headers={"User-Agent": _USER_AGENT}
    ) as client:
        resp = await client.get(url)
        resp.raise_for_status()
        declared = resp.headers.get("content-length")
        if declared and declared.isdigit() and int(declared) > _MAX_DOC_BYTES:
            raise RuntimeError(f"document too large ({int(declared) // (1024 * 1024)} MB)")
        ctype = resp.headers.get("content-type", "").split(";", 1)[0].strip().lower()
        body = resp.content
        is_pdf = ctype == "application/pdf" or url.lower().endswith(".pdf") or body[:5] == b"%PDF-"
        if is_pdf:
            if len(body) > _MAX_DOC_BYTES:
                raise RuntimeError(f"document too large ({len(body) // (1024 * 1024)} MB)")
            return await asyncio.to_thread(_pdf_to_text, body)
        if "html" in ctype or ctype.startswith("text/") or not ctype:
            return (await asyncio.to_thread(_extract_sync, resp.text, url)).markdown
        raise RuntimeError(f"unsupported content type: {ctype or 'unknown'}")
