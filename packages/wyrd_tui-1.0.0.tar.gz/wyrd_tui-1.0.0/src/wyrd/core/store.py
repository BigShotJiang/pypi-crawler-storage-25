"""Thin data-access layer over the SQLite schema in :mod:`wyrd.core.db`.

Keeps all the SQL in one place. Timestamps are stored as ISO-8601 UTC strings.
"""

from __future__ import annotations

import json
import sqlite3
from datetime import UTC, datetime

from wyrd.core.sources import ContentItem

FEED_STATES = ("new", "seen")


def _now() -> str:
    return datetime.now(UTC).isoformat()


def _last_insert_id(cur: sqlite3.Cursor) -> int:
    rowid = cur.lastrowid
    assert rowid is not None, "INSERT executed but lastrowid is unset"
    return rowid


# --- sources ----------------------------------------------------------------


def ensure_source(conn: sqlite3.Connection, kind: str) -> int:
    row = conn.execute("SELECT id FROM sources WHERE kind = ?", (kind,)).fetchone()
    if row is not None:
        return int(row[0])
    cur = conn.execute("INSERT INTO sources(kind) VALUES (?)", (kind,))
    return _last_insert_id(cur)


def mark_source_run(conn: sqlite3.Connection, source_id: int) -> None:
    conn.execute("UPDATE sources SET last_run_at = ? WHERE id = ?", (_now(), source_id))


# --- runs -------------------------------------------------------------------


def start_run(conn: sqlite3.Connection, source_id: int) -> int:
    cur = conn.execute("INSERT INTO runs(source_id, started_at) VALUES (?, ?)", (source_id, _now()))
    return _last_insert_id(cur)


def finish_run(
    conn: sqlite3.Connection,
    run_id: int,
    *,
    found: int,
    new: int,
    error: str | None = None,
) -> None:
    conn.execute(
        "UPDATE runs SET finished_at = ?, found = ?, new = ?, error = ? WHERE id = ?",
        (_now(), found, new, error, run_id),
    )


def recent_runs(conn: sqlite3.Connection, limit: int = 50) -> list[sqlite3.Row]:
    return conn.execute(
        "SELECT r.*, s.kind AS source_kind FROM runs r "
        "JOIN sources s ON s.id = r.source_id ORDER BY r.id DESC LIMIT ?",
        (limit,),
    ).fetchall()


# --- items ------------------------------------------------------------------


def upsert_item(conn: sqlite3.Connection, source_id: int, item: ContentItem) -> int | None:
    """Insert *item* if its URL hasn't been seen. Returns the new id, or ``None`` if a dupe."""
    published = item.published_at.isoformat() if item.published_at else None
    cur = conn.execute(
        "INSERT OR IGNORE INTO items"
        "(source_id, url, url_hash, title, author, summary, published_at, discovered_at, raw_json, state) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'new')",
        (
            source_id,
            item.url,
            item.url_hash(),
            item.title,
            item.author,
            item.summary,
            published,
            _now(),
            json.dumps(item.raw, default=str),
        ),
    )
    return _last_insert_id(cur) if cur.rowcount else None


def list_feed_items(conn: sqlite3.Connection, limit: int = 200) -> list[sqlite3.Row]:
    return conn.execute(
        "SELECT i.*, s.kind AS source_kind FROM items i "
        "JOIN sources s ON s.id = i.source_id "
        f"WHERE i.state IN ({','.join('?' * len(FEED_STATES))}) "
        "ORDER BY COALESCE(i.published_at, i.discovered_at) DESC, i.id DESC LIMIT ?",
        (*FEED_STATES, limit),
    ).fetchall()


def get_item(conn: sqlite3.Connection, item_id: int) -> sqlite3.Row | None:
    return conn.execute(
        "SELECT i.*, s.kind AS source_kind FROM items i "
        "JOIN sources s ON s.id = i.source_id WHERE i.id = ?",
        (item_id,),
    ).fetchone()


def set_item_state(conn: sqlite3.Connection, item_id: int, state: str) -> None:
    conn.execute("UPDATE items SET state = ? WHERE id = ?", (state, item_id))


# --- extractions ------------------------------------------------------------


def get_extraction(conn: sqlite3.Connection, item_id: int) -> sqlite3.Row | None:
    return conn.execute("SELECT * FROM extractions WHERE item_id = ?", (item_id,)).fetchone()


def save_extraction(
    conn: sqlite3.Connection,
    item_id: int,
    *,
    markdown: str | None = None,
    title: str | None = None,
    error: str | None = None,
) -> None:
    """Cache a fetch+extract result for *item_id* (overwrites any previous attempt)."""
    conn.execute(
        "INSERT INTO extractions(item_id, fetched_at, title, markdown, error) "
        "VALUES (?, ?, ?, ?, ?) "
        "ON CONFLICT(item_id) DO UPDATE SET "
        "fetched_at = excluded.fetched_at, title = excluded.title, "
        "markdown = excluded.markdown, error = excluded.error",
        (item_id, _now(), title, markdown, error),
    )


# --- saved items ------------------------------------------------------------


def _tags_to_json(tags: list[str] | None) -> str:
    cleaned = []
    for tag in tags or []:
        tag = " ".join(str(tag).split()).strip()
        if tag and tag not in cleaned:
            cleaned.append(tag)
    return json.dumps(cleaned)


def parse_tags(tags_json: str | None) -> list[str]:
    try:
        value = json.loads(tags_json or "[]")
    except (TypeError, json.JSONDecodeError):
        return []
    return [str(t) for t in value] if isinstance(value, list) else []


def is_saved(conn: sqlite3.Connection, item_id: int) -> bool:
    return conn.execute("SELECT 1 FROM saved WHERE item_id = ?", (item_id,)).fetchone() is not None


def like_item(
    conn: sqlite3.Connection,
    item_id: int,
    *,
    full_text: str | None = None,
    tags: list[str] | None = None,
    notes: str | None = None,
) -> None:
    """Mark *item_id* liked and snapshot it into ``saved`` (upsert)."""
    set_item_state(conn, item_id, "liked")
    conn.execute(
        "INSERT INTO saved(item_id, saved_at, full_text, tags_json, notes) "
        "VALUES (?, ?, ?, ?, ?) "
        "ON CONFLICT(item_id) DO UPDATE SET "
        "full_text = COALESCE(excluded.full_text, saved.full_text)",
        (item_id, _now(), full_text, _tags_to_json(tags), notes),
    )


def update_saved(
    conn: sqlite3.Connection,
    item_id: int,
    *,
    tags: list[str] | None = None,
    notes: str | None = None,
    full_text: str | None = None,
) -> None:
    """Patch a saved row. Only the keyword args you pass are touched."""
    sets, params = [], []
    if tags is not None:
        sets.append("tags_json = ?")
        params.append(_tags_to_json(tags))
    if notes is not None:
        sets.append("notes = ?")
        params.append(notes)
    if full_text is not None:
        sets.append("full_text = ?")
        params.append(full_text)
    if not sets:
        return
    params.append(item_id)
    conn.execute(f"UPDATE saved SET {', '.join(sets)} WHERE item_id = ?", params)


def unsave_item(conn: sqlite3.Connection, item_id: int) -> None:
    conn.execute("DELETE FROM saved WHERE item_id = ?", (item_id,))
    set_item_state(conn, item_id, "seen")


def dismiss_item(conn: sqlite3.Connection, item_id: int) -> None:
    set_item_state(conn, item_id, "dismissed")


def get_saved(conn: sqlite3.Connection, item_id: int) -> sqlite3.Row | None:
    return conn.execute(
        "SELECT i.*, s.kind AS source_kind, "
        "sv.saved_at, sv.full_text, sv.tags_json, sv.notes "
        "FROM saved sv JOIN items i ON i.id = sv.item_id "
        "JOIN sources s ON s.id = i.source_id WHERE sv.item_id = ?",
        (item_id,),
    ).fetchone()


def list_saved_items(
    conn: sqlite3.Connection, *, query: str | None = None, limit: int = 500
) -> list[sqlite3.Row]:
    if query and query.strip():
        return search_saved(conn, query, limit=limit)
    return conn.execute(
        "SELECT i.*, s.kind AS source_kind, "
        "sv.saved_at, sv.full_text, sv.tags_json, sv.notes "
        "FROM saved sv JOIN items i ON i.id = sv.item_id "
        "JOIN sources s ON s.id = i.source_id "
        "ORDER BY sv.saved_at DESC, sv.item_id DESC LIMIT ?",
        (limit,),
    ).fetchall()


# --- research ---------------------------------------------------------------


def record_research(
    conn: sqlite3.Connection,
    *,
    topic: str,
    title: str | None = None,
    path: str | None = None,
    markdown: str | None = None,
    source_count: int = 0,
    error: str | None = None,
    sources_json: str | None = None,
) -> int:
    cur = conn.execute(
        "INSERT INTO research"
        "(topic, title, path, markdown, source_count, created_at, error, sources_json) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        (topic, title, path, markdown, int(source_count), _now(), error, sources_json),
    )
    return _last_insert_id(cur)


def list_research(conn: sqlite3.Connection, limit: int = 200) -> list[sqlite3.Row]:
    return conn.execute(
        "SELECT * FROM research ORDER BY created_at DESC, id DESC LIMIT ?", (limit,)
    ).fetchall()


def get_research(conn: sqlite3.Connection, research_id: int) -> sqlite3.Row | None:
    return conn.execute("SELECT * FROM research WHERE id = ?", (research_id,)).fetchone()


def delete_research(conn: sqlite3.Connection, research_id: int) -> None:
    conn.execute("DELETE FROM research WHERE id = ?", (research_id,))


# --- FTS5 search ------------------------------------------------------------


def _fts_query(raw: str) -> str | None:
    """Turn user input into an FTS5 MATCH expression, or return None if empty.

    Each whitespace-separated token is wrapped in double quotes (with inner ``"``
    doubled) so column filters (``foo:bar``) and operators (``OR``, ``NOT``,
    parens) become literal terms — FTS5 won't crash on hostile input.
    """
    tokens = (raw or "").split()
    if not tokens:
        return None
    quoted = ['"' + tok.replace('"', '""') + '"' for tok in tokens]
    return " ".join(quoted)


def search_feed(conn: sqlite3.Connection, query: str, *, limit: int = 200) -> list[sqlite3.Row]:
    match = _fts_query(query)
    if match is None:
        return []
    placeholders = ",".join("?" * len(FEED_STATES))
    return conn.execute(
        "SELECT i.*, s.kind AS source_kind FROM items_fts f "
        "JOIN items i ON i.id = f.rowid "
        "JOIN sources s ON s.id = i.source_id "
        f"WHERE items_fts MATCH ? AND i.state IN ({placeholders}) "
        "ORDER BY bm25(items_fts) ASC, "
        "COALESCE(i.published_at, i.discovered_at) DESC, i.id DESC "
        "LIMIT ?",
        (match, *FEED_STATES, limit),
    ).fetchall()


def search_saved(conn: sqlite3.Connection, query: str, *, limit: int = 500) -> list[sqlite3.Row]:
    match = _fts_query(query)
    if match is None:
        return []
    return conn.execute(
        "SELECT i.*, s.kind AS source_kind, "
        "sv.saved_at, sv.full_text, sv.tags_json, sv.notes "
        "FROM items_fts f "
        "JOIN saved sv ON sv.item_id = f.rowid "
        "JOIN items i ON i.id = sv.item_id "
        "JOIN sources s ON s.id = i.source_id "
        "WHERE items_fts MATCH ? "
        "ORDER BY bm25(items_fts) ASC, sv.saved_at DESC, sv.item_id DESC "
        "LIMIT ?",
        (match, limit),
    ).fetchall()
