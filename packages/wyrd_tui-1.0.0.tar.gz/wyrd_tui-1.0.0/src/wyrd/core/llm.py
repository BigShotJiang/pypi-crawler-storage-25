"""Optional LLM help, via the ``claude`` CLI (Claude Code in headless mode).

We shell out to ``claude -p <prompt>`` rather than calling an API directly, so
no API key wrangling — if the CLI is on ``PATH`` it works, otherwise these
helpers degrade to ``None`` and callers carry on without them.
"""

from __future__ import annotations

import asyncio
import json
import logging
import re
import shutil
from collections.abc import Callable

log = logging.getLogger(__name__)


def available() -> bool:
    return shutil.which("claude") is not None


async def ask(prompt: str, *, timeout: float = 90.0) -> str | None:
    """Run ``claude -p <prompt>`` and return its stdout, or ``None`` on any failure."""
    if not available():
        return None
    try:
        proc = await asyncio.create_subprocess_exec(
            "claude",
            "-p",
            prompt,
            stdin=asyncio.subprocess.DEVNULL,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
    except OSError:
        log.exception("failed to launch claude CLI")
        return None
    try:
        out, err = await asyncio.wait_for(proc.communicate(), timeout=timeout)
    except TimeoutError:
        proc.kill()
        await proc.wait()
        log.warning("claude CLI timed out after %ss", timeout)
        return None
    if proc.returncode != 0:
        log.warning("claude CLI exited %s: %s", proc.returncode, err.decode(errors="replace")[:500])
        return None
    return out.decode(errors="replace").strip() or None


def _extract_json(text: str):
    """Pull the first JSON object/array out of *text*, tolerating ``` fences and prose."""
    fenced = re.search(r"```(?:json)?\s*(.*?)```", text, re.DOTALL)
    candidates = [fenced.group(1)] if fenced else []
    candidates.append(text)
    for candidate in candidates:
        candidate = candidate.strip()
        try:
            return json.loads(candidate)
        except json.JSONDecodeError:
            pass
        match = re.search(r"(\{.*\}|\[.*\])", candidate, re.DOTALL)
        if match:
            try:
                return json.loads(match.group(1))
            except json.JSONDecodeError:
                pass
    return None


# --- deep research (streaming) ---------------------------------------------
#
# The deep-research agent leans on Claude Code's own web tools: we run the CLI
# in headless streaming mode so we can surface what it's doing (searching,
# reading papers) as it goes, then keep the final Markdown it produces.

# Web tools we let the headless agent use without prompting. Kept narrow on
# purpose — this agent reads the web and writes a paper, nothing else.
RESEARCH_TOOLS: list[str] = ["WebSearch", "WebFetch"]


def _describe_tool_use(name: str, inp: dict) -> str:
    if name == "WebSearch":
        query = str(inp.get("query") or "").strip()
        return f"🔍 Searching: {query}" if query else "🔍 Searching the web"
    if name == "WebFetch":
        url = str(inp.get("url") or "").strip()
        return f"📄 Reading: {url}" if url else "📄 Reading a page"
    return f"🛠  {name}"


def parse_stream_event(msg: dict) -> list[tuple[str, str]]:
    """Turn one ``stream-json`` line from ``claude`` into ``(kind, text)`` events.

    Kinds: ``"tool"`` (a tool call the agent made), ``"text"`` (assistant prose),
    ``"result"`` (the final output text), ``"error"`` (the run failed; *text* is
    the message). Lines we don't care about yield nothing.
    """
    out: list[tuple[str, str]] = []
    kind = msg.get("type")
    if kind == "assistant":
        for block in (msg.get("message") or {}).get("content") or []:
            if not isinstance(block, dict):
                continue
            if block.get("type") == "tool_use":
                out.append(
                    (
                        "tool",
                        _describe_tool_use(str(block.get("name") or ""), block.get("input") or {}),
                    )
                )
            elif block.get("type") == "text":
                text = " ".join(str(block.get("text") or "").split())
                if text:
                    out.append(("text", text))
    elif kind == "result":
        if msg.get("is_error") or msg.get("subtype") not in (None, "success"):
            out.append(
                ("error", str(msg.get("result") or msg.get("subtype") or "research run failed"))
            )
        else:
            result = msg.get("result")
            if isinstance(result, str) and result.strip():
                out.append(("result", result.strip()))
    return out


async def deep_research(
    prompt: str,
    *,
    timeout: float = 900.0,
    on_event: Callable[[str, str], None] | None = None,
) -> tuple[str | None, str | None]:
    """Run one deep-research pass with the ``claude`` CLI.

    Returns ``(markdown, error)`` with exactly one of them non-``None``.
    *on_event* — if given — is called ``(kind, text)`` for each progress event
    while the agent searches the web and reads sources (see
    :func:`parse_stream_event`); ``"result"`` / ``"error"`` events aren't
    forwarded to it, they become the return value.
    """
    if not available():
        return None, "the `claude` CLI isn't installed or isn't on PATH"
    args = [
        "claude",
        "-p",
        prompt,
        "--output-format",
        "stream-json",
        "--verbose",
        "--allowedTools",
        *RESEARCH_TOOLS,
    ]
    try:
        proc = await asyncio.create_subprocess_exec(
            *args,
            stdin=asyncio.subprocess.DEVNULL,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            limit=16 * 1024 * 1024,  # a result line carries the whole paper
        )
    except OSError as exc:
        log.exception("failed to launch claude CLI")
        return None, f"couldn't launch claude: {exc}"

    result_md: str | None = None
    err_msg: str | None = None
    stderr_chunks: list[bytes] = []

    async def _drain_stdout() -> None:
        nonlocal result_md, err_msg
        assert proc.stdout is not None
        async for raw in proc.stdout:
            line = raw.decode(errors="replace").strip()
            if not line:
                continue
            try:
                msg = json.loads(line)
            except json.JSONDecodeError:
                continue
            if not isinstance(msg, dict):
                continue
            for kind, text in parse_stream_event(msg):
                if kind == "result":
                    result_md = text
                elif kind == "error":
                    err_msg = text
                elif on_event is not None:
                    try:
                        on_event(kind, text)
                    except Exception:  # noqa: BLE001 — a bad listener shouldn't kill the run
                        log.exception("research on_event handler failed")

    async def _drain_stderr() -> None:
        assert proc.stderr is not None
        async for chunk in proc.stderr:
            stderr_chunks.append(chunk)

    try:
        await asyncio.wait_for(asyncio.gather(_drain_stdout(), _drain_stderr()), timeout=timeout)
        await asyncio.wait_for(proc.wait(), timeout=10)
    except TimeoutError:
        proc.kill()
        await proc.wait()
        return None, f"research timed out after {int(timeout)}s"

    if result_md:
        return result_md, None
    if err_msg:
        return None, err_msg
    if proc.returncode:
        tail = b"".join(stderr_chunks).decode(errors="replace").strip()
        return None, (f"claude exited {proc.returncode}: {tail[:300]}").strip()
    return None, "the research agent finished without producing anything"


async def suggest_feeds_and_keywords(interests: str) -> dict[str, list[str]] | None:
    """Ask the model for RSS feeds + keywords matching a free-text interest description."""
    interests = interests.strip()
    if not interests:
        return None
    prompt = (
        "I'm setting up a personal content reader. Based on these interests, suggest "
        "real, working RSS/Atom feed URLs and a short list of keywords to flag the most "
        "interesting items.\n\n"
        f"Interests: {interests}\n\n"
        "Respond with ONLY a JSON object, no prose, of the form:\n"
        '{"feeds": ["https://...", ...], "keywords": ["...", ...]}\n'
        "Aim for 5-12 feeds and 5-15 keywords. Prefer well-known, stable feeds."
    )
    raw = await ask(prompt)
    if raw is None:
        return None
    data = _extract_json(raw)
    if not isinstance(data, dict):
        return None
    feeds = [str(f).strip() for f in data.get("feeds", []) if str(f).strip().startswith("http")]
    keywords = [str(k).strip().lower() for k in data.get("keywords", []) if str(k).strip()]
    if not feeds and not keywords:
        return None
    return {"feeds": feeds, "keywords": keywords}
