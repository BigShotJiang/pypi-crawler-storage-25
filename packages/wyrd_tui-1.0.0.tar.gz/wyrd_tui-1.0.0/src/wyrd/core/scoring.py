"""Item scoring for keyword/score filtering.

A single deterministic rule: count keyword matches in title (weight 3) and
summary (weight 1). A future LLM ranker can sit behind the same interface.
"""

from __future__ import annotations

import sqlite3
from collections.abc import Iterable

TITLE_WEIGHT = 3
SUMMARY_WEIGHT = 1


def score_item(row: sqlite3.Row, keywords: Iterable[str]) -> int:
    """Return a non-negative integer score for *row* against *keywords*.

    Matches are case-insensitive substring matches. An empty keyword list always
    scores 0 (no signal to weigh against).
    """
    kws = [k.strip().lower() for k in keywords if k and k.strip()]
    if not kws:
        return 0
    title = (row["title"] or "").lower()
    summary = (row["summary"] or "").lower()
    score = 0
    for k in kws:
        score += title.count(k) * TITLE_WEIGHT
        score += summary.count(k) * SUMMARY_WEIGHT
    return score
