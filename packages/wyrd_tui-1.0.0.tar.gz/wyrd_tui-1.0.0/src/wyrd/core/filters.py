"""Drop video/audio items from the content pipeline.

wyrd is a *reader*; we don't want podcasts or YouTube clips in the feed. The
scheduler runs :func:`is_av_item` over every fetched item and skips anything
that smells like A/V — by host (youtube.com, vimeo.com, podcasts.apple.com, …),
by file extension (.mp3 / .mp4 / …), or by RSS enclosure MIME type.
"""

from __future__ import annotations

from urllib.parse import urlparse

from wyrd.core.sources import ContentItem

_AV_HOSTS = frozenset(
    {
        # video
        "youtube.com",
        "m.youtube.com",
        "music.youtube.com",
        "youtu.be",
        "vimeo.com",
        "player.vimeo.com",
        "twitch.tv",
        "clips.twitch.tv",
        "tiktok.com",
        "rumble.com",
        "dailymotion.com",
        "bitchute.com",
        # audio / podcasts
        "soundcloud.com",
        "on.soundcloud.com",
        "mixcloud.com",
        "bandcamp.com",
        "open.spotify.com",
        "podcasts.apple.com",
        "podcasts.google.com",
        "anchor.fm",
        "overcast.fm",
        "pca.st",
        "podcastaddict.com",
        "castbox.fm",
        "castro.fm",
        "stitcher.com",
    }
)

_AV_EXTS = frozenset(
    {
        # audio
        ".mp3",
        ".m4a",
        ".wav",
        ".ogg",
        ".oga",
        ".flac",
        ".aac",
        ".opus",
        ".aiff",
        ".wma",
        # video
        ".mp4",
        ".m4v",
        ".mov",
        ".mkv",
        ".webm",
        ".avi",
        ".wmv",
        ".flv",
    }
)


def _host(url: str) -> str:
    netloc = urlparse(url).netloc.lower()
    return netloc.removeprefix("www.")


def is_av_url(url: str | None) -> bool:
    if not url:
        return False
    if _host(url) in _AV_HOSTS:
        return True
    path = urlparse(url).path.lower()
    return any(path.endswith(ext) for ext in _AV_EXTS)


def is_av_item(item: ContentItem) -> bool:
    if is_av_url(item.url):
        return True
    enclosures = (item.raw or {}).get("enclosures") or []
    for enc in enclosures:
        mime = (enc.get("type") or "").lower()
        if mime.startswith(("audio/", "video/")):
            return True
        if is_av_url(enc.get("href") or enc.get("url")):
            return True
    return False
