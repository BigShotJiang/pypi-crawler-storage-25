"""Load (and on first run, create) the TOML config file.

The config is intentionally small for M0 — it grows alongside features. We keep
a hand-written default file (with comments) rather than serializing a dict, so
the on-disk file stays friendly to edit.
"""

from __future__ import annotations

import json
import logging
import tomllib
from dataclasses import dataclass, field, fields
from pathlib import Path

from wyrd.core import paths

logger = logging.getLogger(__name__)

DEFAULT_KEYS: dict[str, str] = {
    "feed": "1",
    "saved": "2",
    "research": "3",
    "terminal": "4",
    "refresh": "ctrl+r",
    "activity": "f3",
    "setup": "f2",
    "shell": "f10",
    "quit": "ctrl+q",
}

DEFAULT_CONFIG_TOML = """\
# wyrd configuration. Edit freely; missing keys fall back to built-in defaults.

[general]
# How often the background worker searches for new content.
refresh_interval_minutes = 60

[content]
# RSS/Atom feeds to poll (used once the RSS source lands in M2).
feeds = [
    # "https://hnrss.org/frontpage",
    # "https://www.theverge.com/rss/index.xml",
]
# Subreddits to poll (without the leading "r/").
subreddits = []
# Case-insensitive keywords used to flag items as "interesting".
keywords = []

[research]
# Folder where the deep-research agent writes its Markdown papers.
# Leave blank to use the app data dir (~/.local/share/wyrd/research).
output_dir = ""
# How many peer-reviewed papers to gather (the agent aims for this range).
min_sources = 8
max_sources = 25
# Wall-clock budget for a single research run, in seconds.
timeout_seconds = 900

[ui]
# Textual theme name (see the command palette > "Change theme").
theme = "textual-dark"

[obsidian]
# Path to an Obsidian vault. When set, every liked article and every finished
# research run lands as Markdown under <vault>/<folder>. Leave blank to disable.
vault = ""
# The folder inside the vault (defaults to "wyrd").
folder = "wyrd"

[keys]
# Override individual key bindings. Use Textual key syntax: "1", "ctrl+r", "f2",
# "shift+a", etc. Invalid values are ignored (falls back to the default).
feed = "1"
saved = "2"
research = "3"
terminal = "4"
refresh = "ctrl+r"
activity = "f3"
setup = "f2"
shell = "f10"
quit = "ctrl+q"
"""


@dataclass(frozen=True)
class GeneralConfig:
    refresh_interval_minutes: int = 60


@dataclass(frozen=True)
class ContentConfig:
    feeds: list[str] = field(default_factory=list)
    subreddits: list[str] = field(default_factory=list)
    keywords: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class ResearchConfig:
    output_dir: str = ""
    min_sources: int = 8
    max_sources: int = 25
    timeout_seconds: int = 900


@dataclass(frozen=True)
class UIConfig:
    theme: str = "textual-dark"


@dataclass(frozen=True)
class ObsidianConfig:
    # Path to an Obsidian vault folder. When set, every liked article and every
    # finished research run lands as Markdown under <vault>/wyrd. Empty = off.
    vault: str = ""
    # The subfolder inside the vault. Defaults to "wyrd"; everything goes here.
    folder: str = "wyrd"


@dataclass(frozen=True)
class KeysConfig:
    feed: str = DEFAULT_KEYS["feed"]
    saved: str = DEFAULT_KEYS["saved"]
    research: str = DEFAULT_KEYS["research"]
    terminal: str = DEFAULT_KEYS["terminal"]
    refresh: str = DEFAULT_KEYS["refresh"]
    activity: str = DEFAULT_KEYS["activity"]
    setup: str = DEFAULT_KEYS["setup"]
    shell: str = DEFAULT_KEYS["shell"]
    quit: str = DEFAULT_KEYS["quit"]

    def as_dict(self) -> dict[str, str]:
        return {f.name: getattr(self, f.name) for f in fields(self)}


@dataclass(frozen=True)
class Config:
    general: GeneralConfig = field(default_factory=GeneralConfig)
    content: ContentConfig = field(default_factory=ContentConfig)
    research: ResearchConfig = field(default_factory=ResearchConfig)
    ui: UIConfig = field(default_factory=UIConfig)
    keys: KeysConfig = field(default_factory=KeysConfig)
    obsidian: ObsidianConfig = field(default_factory=ObsidianConfig)
    path: Path | None = None


def _int(value, default: int, *, minimum: int = 1) -> int:
    try:
        return max(minimum, int(value))
    except (TypeError, ValueError):
        return default


def _coerce_keys(raw: dict) -> KeysConfig:
    values: dict[str, str] = {}
    for name, default in DEFAULT_KEYS.items():
        v = raw.get(name, default)
        if not isinstance(v, str) or not v.strip():
            logger.warning(
                "keys.%s in config is not a non-empty string; using default %r", name, default
            )
            values[name] = default
        else:
            values[name] = v.strip()
    return KeysConfig(**values)


def _coerce(raw: dict, path: Path | None) -> Config:
    g = raw.get("general", {})
    c = raw.get("content", {})
    r = raw.get("research", {})
    u = raw.get("ui", {})
    k = raw.get("keys", {})
    o = raw.get("obsidian", {}) if isinstance(raw.get("obsidian", {}), dict) else {}
    min_sources = _int(r.get("min_sources", 8), 8)
    max_sources = max(min_sources, _int(r.get("max_sources", 25), 25))
    return Config(
        general=GeneralConfig(
            refresh_interval_minutes=int(g.get("refresh_interval_minutes", 60)),
        ),
        content=ContentConfig(
            feeds=list(c.get("feeds", [])),
            subreddits=[
                str(s).strip().lstrip("/").removeprefix("r/")
                for s in c.get("subreddits", [])
                if str(s).strip()
            ],
            keywords=[str(kw).lower() for kw in c.get("keywords", [])],
        ),
        research=ResearchConfig(
            output_dir=str(r.get("output_dir", "") or ""),
            min_sources=min_sources,
            max_sources=max_sources,
            timeout_seconds=_int(r.get("timeout_seconds", 900), 900, minimum=30),
        ),
        ui=UIConfig(theme=str(u.get("theme", "textual-dark"))),
        keys=_coerce_keys(k if isinstance(k, dict) else {}),
        obsidian=ObsidianConfig(
            vault=str(o.get("vault", "") or "").strip(),
            folder=str(o.get("folder", "wyrd") or "wyrd").strip() or "wyrd",
        ),
        path=path,
    )


def load(create_if_missing: bool = True) -> Config:
    path = paths.config_file()
    if not path.exists():
        if create_if_missing:
            path.write_text(DEFAULT_CONFIG_TOML)
        else:
            return Config(path=path)
    with path.open("rb") as fh:
        raw = tomllib.load(fh)
    return _coerce(raw, path)


def _toml_str(value: str) -> str:
    # TOML basic strings accept the same escaping as JSON strings for our purposes.
    return json.dumps(value, ensure_ascii=False)


def _toml_array(values: list[str], indent: str = "    ") -> str:
    if not values:
        return "[]"
    body = ",\n".join(f"{indent}{_toml_str(v)}" for v in values)
    return f"[\n{body},\n]"


def render_toml(
    *,
    refresh_interval_minutes: int,
    feeds: list[str],
    keywords: list[str],
    subreddits: list[str] | None = None,
    theme: str = "textual-dark",
    research: ResearchConfig | None = None,
    keys: KeysConfig | None = None,
    obsidian: ObsidianConfig | None = None,
) -> str:
    research = research or ResearchConfig()
    keys = keys or KeysConfig()
    obsidian = obsidian or ObsidianConfig()
    subs = subreddits or []
    keys_block = "\n".join(f"{name} = {_toml_str(getattr(keys, name))}" for name in DEFAULT_KEYS)
    return (
        "# wyrd configuration. Edit freely; missing keys fall back to built-in defaults.\n\n"
        "[general]\n"
        "# How often the background worker searches for new content.\n"
        f"refresh_interval_minutes = {int(refresh_interval_minutes)}\n\n"
        "[content]\n"
        "# RSS/Atom feeds to poll.\n"
        f"feeds = {_toml_array(feeds)}\n"
        '# Subreddits to poll (without the leading "r/").\n'
        f"subreddits = {_toml_array(subs)}\n"
        '# Case-insensitive keywords used to flag items as "interesting".\n'
        f"keywords = {_toml_array(keywords)}\n\n"
        "[research]\n"
        "# Folder where the deep-research agent writes its Markdown papers.\n"
        "# Leave blank to use the app data dir (or the Obsidian vault, when set).\n"
        f"output_dir = {_toml_str(research.output_dir)}\n"
        "# How many peer-reviewed papers to gather (the agent aims for this range).\n"
        f"min_sources = {int(research.min_sources)}\n"
        f"max_sources = {int(research.max_sources)}\n"
        "# Wall-clock budget for a single research run, in seconds.\n"
        f"timeout_seconds = {int(research.timeout_seconds)}\n\n"
        "[ui]\n"
        '# Textual theme name (see the command palette > "Change theme").\n'
        f"theme = {_toml_str(theme)}\n\n"
        "[obsidian]\n"
        "# Path to an Obsidian vault. When set, every liked article and every\n"
        "# finished research run lands as Markdown under <vault>/<folder>. Leave\n"
        "# blank to disable.\n"
        f"vault = {_toml_str(obsidian.vault)}\n"
        '# The folder inside the vault (defaults to "wyrd").\n'
        f"folder = {_toml_str(obsidian.folder)}\n\n"
        "[keys]\n"
        '# Override individual key bindings. Use Textual key syntax ("1", "ctrl+r", "f2", ...).\n'
        f"{keys_block}\n"
    )


def write(
    *,
    refresh_interval_minutes: int,
    feeds: list[str],
    keywords: list[str],
    subreddits: list[str] | None = None,
    theme: str = "textual-dark",
    research: ResearchConfig | None = None,
    keys: KeysConfig | None = None,
    obsidian: ObsidianConfig | None = None,
) -> Path:
    """Overwrite the config file with the given values and return its path."""
    path = paths.config_file()
    path.write_text(
        render_toml(
            refresh_interval_minutes=refresh_interval_minutes,
            feeds=feeds,
            keywords=keywords,
            subreddits=subreddits,
            theme=theme,
            research=research,
            keys=keys,
            obsidian=obsidian,
        )
    )
    return path
