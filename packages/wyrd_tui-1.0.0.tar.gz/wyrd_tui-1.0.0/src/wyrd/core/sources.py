"""Content sources: the pluggable bits that go find things on the internet.

A *source* is anything with a ``kind`` string and an ``async fetch(cfg) -> list[ContentItem]``
method. The scheduler iterates whatever is registered here; nothing in the core
imports a concrete source. M5 grows this into proper plugin discovery — for now
sources register themselves at import time via :func:`register`.
"""

from __future__ import annotations

import hashlib
from collections.abc import Awaitable
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Protocol, runtime_checkable


@dataclass(slots=True)
class ContentItem:
    """One discovered thing. ``url`` is the identity; everything else is best-effort."""

    url: str
    title: str | None = None
    author: str | None = None
    summary: str | None = None
    published_at: datetime | None = None
    raw: dict[str, Any] = field(default_factory=dict)

    def url_hash(self) -> str:
        return hashlib.sha256(normalize_url(self.url).encode("utf-8")).hexdigest()


def normalize_url(url: str) -> str:
    """A cheap canonical form for de-duplication: strip fragments and trailing slash."""
    url = url.strip()
    if "#" in url:
        url = url.split("#", 1)[0]
    if len(url) > 1 and url.endswith("/"):
        url = url[:-1]
    return url


@runtime_checkable
class Source(Protocol):
    kind: str

    def fetch(self, cfg: Any) -> Awaitable[list[ContentItem]]: ...


_REGISTRY: dict[str, Source] = {}


def register(source: Source) -> Source:
    _REGISTRY[source.kind] = source
    return source


def all_sources() -> list[Source]:
    return list(_REGISTRY.values())


def get_source(kind: str) -> Source | None:
    return _REGISTRY.get(kind)
