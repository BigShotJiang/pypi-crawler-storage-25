"""The deep-research agent.

Give it a topic; it drives the ``claude`` CLI (which can search and fetch the
web) to hunt down *peer-reviewed academic papers* on the subject and write a
literature-review paper. For each cited paper it then writes a Markdown note —
the agent's summary, plus, where a freely/legally accessible copy exists, the
paper's **full text** converted to Markdown (so the review can be checked
against the originals). Each run becomes a folder under the configured dir::

    2026-05-12-microplastics-and-human-health/
        paper.md                      # the review (normal citations: source text, not links)
        sources/
            01-smith-2020-....md      # summary + full text of one cited paper
            02-...

The searching, reading and synthesising happen inside ``claude``; this module
is the orchestration — it writes the brief, parses what comes back, downloads
the open-access full texts (via :mod:`wyrd.core.extract`), lays out the files,
and records the run.
"""

from __future__ import annotations

import asyncio
import json
import logging
import re
import sqlite3
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import date
from pathlib import Path

from wyrd.core import extract as extract_mod
from wyrd.core import llm, paths, store
from wyrd.core.config import Config

log = logging.getLogger(__name__)

Progress = Callable[[str, str], None]


@dataclass(slots=True)
class ResearchSource:
    n: int
    citation: str
    url: str  # the DOI / canonical link
    fulltext_url: str  # an open-access full-text URL, if one was found
    file: Path  # the local .md note (summary, plus full text when we got it)
    has_fulltext: bool = False


@dataclass(slots=True)
class ResearchResult:
    topic: str
    title: str
    markdown: str | None = None
    path: Path | None = None  # the run's paper.md
    source_count: int = 0
    sources: list[ResearchSource] = field(default_factory=list)
    error: str | None = None
    research_id: int | None = None

    @property
    def ok(self) -> bool:
        return self.error is None and self.markdown is not None

    @property
    def dir(self) -> Path | None:
        return self.path.parent if self.path else None


def _safe_output_dir(raw: str) -> Path | None:
    # The override is a convenience knob, not a "write anywhere on disk" hatch —
    # anything that resolves outside $HOME is treated as a paste accident and
    # falls back to the default. Use the Obsidian `vault` setting if you really
    # do want research files elsewhere (it's a more explicit opt-in).
    candidate = Path(raw).expanduser().resolve()
    home = Path.home().resolve()
    try:
        candidate.relative_to(home)
    except ValueError:
        return None
    return candidate


def output_dir(config: Config) -> Path:
    """Where research runs land.

    Preference order: Obsidian vault (when configured) > ``research.output_dir``
    override > app data dir. The Obsidian path wins because it's a more explicit
    opt-in than the historical ``output_dir`` knob.
    """
    from wyrd.core import obsidian  # local import to avoid a config <-> store cycle

    obs_dir = obsidian.research_dir(config)
    if obs_dir is not None:
        obs_dir.mkdir(parents=True, exist_ok=True)
        return obs_dir
    raw = (getattr(getattr(config, "research", None), "output_dir", "") or "").strip()
    if raw:
        path = _safe_output_dir(raw)
        if path is None:
            log.warning(
                "ignoring [research] output_dir=%r (must resolve under $HOME); using default",
                raw,
            )
        else:
            path.mkdir(parents=True, exist_ok=True)
            return path
    return paths.research_dir()


_SLUG_RE = re.compile(r"[^a-z0-9]+")


def slugify(text: str, *, max_len: int = 60) -> str:
    slug = _SLUG_RE.sub("-", text.strip().lower()).strip("-")
    if len(slug) > max_len:
        slug = slug[:max_len].rstrip("-")
    return slug or "research"


# --- the brief --------------------------------------------------------------


def _build_prompt(topic: str, *, min_sources: int, max_sources: int, today: str) -> str:
    return (
        "You are a meticulous academic research assistant. Research the topic below: gather the relevant "
        "peer-reviewed literature, write a literature-review paper, and summarise each paper you cite.\n\n"
        f'TOPIC: "{topic}"\n\n'
        "How to work:\n"
        "- Use web search and page fetches to find the relevant scholarly literature, and read the papers "
        "(at least their abstracts; full text wherever you can reach it).\n"
        "- Cite ONLY peer-reviewed academic papers: journal articles, or papers in peer-reviewed conference "
        "proceedings. Do NOT cite preprints (arXiv, bioRxiv, SSRN working papers, and the like) unless they "
        "were subsequently published in a peer-reviewed venue, and do NOT cite blog posts, news articles, "
        "Wikipedia, vendor or marketing pages, theses, or other non-peer-reviewed material. Before citing a "
        "paper, confirm it really is peer-reviewed; if you can't confirm it, drop it.\n"
        "- For each cited paper, also locate a freely and legally accessible copy of the FULL TEXT — an "
        "open-access PDF or full HTML article (the publisher's open-access version, an arXiv/preprint copy "
        "when it corresponds to the published paper, PubMed Central, an institutional or subject repository, "
        "etc.). Put its URL in `fulltext_url` (prefer a direct PDF link). Do NOT use paywalled, login-walled, "
        "or 'rent this article' pages; if there is genuinely no free full-text copy, leave `fulltext_url` "
        'empty ("").\n'
        "- Prefer well-cited and recent work; cover the major findings, methods, and disagreements.\n"
        f"- Aim for roughly {min_sources}-{max_sources} cited papers (more if the topic clearly warrants it, "
        "but never more than you actually verified).\n\n"
        "Output — return a SINGLE JSON object and NOTHING ELSE (no prose before or after, no code fence). "
        "Shape:\n\n"
        "{\n"
        '  "title": "<a precise, descriptive title for the review>",\n'
        '  "paper": "<the full review, in Markdown — structure described below>",\n'
        '  "sources": [\n'
        "    {\n"
        '      "n": 1,\n'
        '      "citation": "Author(s) (Year). Title. *Venue*. DOI or stable URL.",\n'
        '      "url": "https://doi.org/...  (the DOI or canonical link; \\"\\" if you have none)",\n'
        '      "fulltext_url": "https://...  (a freely/legally accessible full-text URL — open-access PDF or '
        'HTML; \\"\\" if none — never a paywalled or login-walled page)",\n'
        '      "summary": "<Markdown: 2-4 paragraphs on THIS paper — its research question, methods/data, '
        "key findings, and limitations. You may use ### subheadings and bullet lists. Be concrete; do not "
        'just restate the title.>"\n'
        "    }\n"
        '    // one object per cited paper; "n" must run 1, 2, 3, … and match the inline citations\n'
        "  ]\n"
        "}\n\n"
        'The "paper" Markdown must use this structure:\n\n'
        "# <title>\n\n"
        f'*Deep-research review · generated {today} · topic: "{topic}"*\n\n'
        "## Abstract\n"
        "150-250 words on what the literature collectively says.\n\n"
        "## Background\n"
        "Context and why the topic matters; define the key terms.\n\n"
        "## Themes and Findings\n"
        "Several `###` subsections, each on one sub-question or theme, *synthesising* the papers (not a "
        'paper-by-paper recap). Use inline numeric citations like [1], [3] that match the "sources" list.\n\n'
        "## Open Questions and Limitations\n"
        "What's unsettled, contested, or under-studied; weaknesses in the evidence base.\n\n"
        "## References\n"
        "A numbered list, one cited paper per line — `1. Author(s) (Year). Title. *Venue*. DOI or URL.` — "
        'with the numbers matching the "sources" list and the inline citations.\n\n'
        "Make sure the JSON is valid: escape newlines inside string values as \\n.\n"
    )


# --- parsing what comes back ------------------------------------------------

_FENCE_RE = re.compile(r"^```(?:markdown|md)?\s*\n(.*)\n```\s*$", re.DOTALL)


def _strip_outer_fence(md: str) -> str:
    md = (md or "").strip()
    match = _FENCE_RE.match(md)
    return match.group(1).strip() if match else md


_TITLE_RE = re.compile(r"^\s{0,3}#\s+(.+?)\s*$", re.MULTILINE)


def _extract_title(md: str, topic: str) -> str:
    match = _TITLE_RE.search(md)
    if match:
        title = match.group(1).strip().lstrip("#").strip()
        if title:
            return title
    return f"Literature review: {topic}"


_HEADING_RE = re.compile(r"^\s{0,3}#{1,6}\s+\S")
_REF_HEADING_RE = re.compile(
    r"^\s{0,3}#{1,6}\s+(references|bibliography|works cited|sources|citations)\s*$", re.IGNORECASE
)
_REF_LINE_RE = re.compile(r"^\s*(?:\[?\d+[.)\]]|[-*])\s+\S", re.MULTILINE)


def _count_references(md: str) -> int:
    lines = md.splitlines()
    start = next((i + 1 for i, line in enumerate(lines) if _REF_HEADING_RE.match(line)), None)
    if start is None:
        return 0
    end = next((j for j in range(start, len(lines)) if _HEADING_RE.match(lines[j])), len(lines))
    return len(_REF_LINE_RE.findall("\n".join(lines[start:end])))


def _parse_agent_output(raw: str, *, topic: str) -> tuple[str, str, list[dict]]:
    """Return ``(paper_markdown, title, sources)``; falls back to treating *raw* as the paper."""
    data = llm._extract_json(raw)
    if isinstance(data, dict) and isinstance(data.get("paper"), str) and data["paper"].strip():
        paper = _strip_outer_fence(str(data["paper"]))
        title = str(data.get("title") or "").strip() or _extract_title(paper, topic)
        sources: list[dict] = []
        for i, entry in enumerate(data.get("sources") or [], start=1):
            if not isinstance(entry, dict):
                continue
            citation = " ".join(str(entry.get("citation") or "").split())
            summary = str(entry.get("summary") or "").strip()
            if not citation and not summary:
                continue
            try:
                n = int(entry.get("n", i))
            except (TypeError, ValueError):
                n = i
            ft_url = str(entry.get("fulltext_url") or entry.get("full_text_url") or "").strip()
            sources.append(
                {
                    "n": n,
                    "citation": citation or f"Source {n}",
                    "url": str(entry.get("url") or "").strip(),
                    "fulltext_url": ft_url
                    if ft_url.lower().startswith(("http://", "https://"))
                    else "",
                    "summary": summary or "_(no summary provided)_",
                }
            )
        seen: set[int] = set()
        sources = [
            s
            for s in sorted(sources, key=lambda s: s["n"])
            if not (s["n"] in seen or seen.add(s["n"]))
        ]
        return paper, title, sources
    paper = _strip_outer_fence(raw)
    return paper, _extract_title(paper, topic), []


# --- full-text retrieval ---------------------------------------------------

_FULLTEXT_TIMEOUT = 45.0
_FULLTEXT_CONCURRENCY = 4


def _short(text: str, limit: int = 60) -> str:
    text = " ".join(str(text).split())
    return text if len(text) <= limit else text[: limit - 1].rstrip() + "…"


async def _fetch_fulltexts(entries: list[dict], *, on_event: Progress | None) -> dict[int, str]:
    """Best-effort download + Markdown conversion of each source's ``fulltext_url``."""
    out: dict[int, str] = {}
    sem = asyncio.Semaphore(_FULLTEXT_CONCURRENCY)

    async def _one(entry: dict) -> None:
        url = entry.get("fulltext_url") or ""
        if not url:
            return
        async with sem:
            if on_event:
                on_event("tool", f"📥 Full text: {_short(entry['citation'])}")
            try:
                md = await extract_mod.fetch_document_markdown(url, timeout=_FULLTEXT_TIMEOUT)
            except Exception as exc:  # noqa: BLE001 — full text is a nice-to-have, never fatal
                log.info("full-text fetch failed for %s: %s", url, exc)
                return
        if md and md.strip():
            out[entry["n"]] = md.strip()

    if entries:
        await asyncio.gather(*(_one(e) for e in entries), return_exceptions=True)
    return out


# --- laying out the files ---------------------------------------------------


def _source_filename(n: int, citation: str) -> str:
    return f"{n:02d}-{slugify(citation, max_len=50)}.md"


def _source_note_text(src: dict, fulltext_md: str | None = None) -> str:
    today = date.today().isoformat()
    lines = [f"# {src['citation']}", ""]
    if src.get("url"):
        lines.append(f"- **Original:** {src['url']}")
    if src.get("fulltext_url") and fulltext_md is not None:
        lines.append(f"- **Open-access full text:** {src['fulltext_url']}  *(retrieved {today})*")
    elif src.get("fulltext_url"):
        lines.append(
            f"- **Full text:** {src['fulltext_url']}  *(could not be retrieved automatically)*"
        )
    else:
        lines.append("- _Full text: no freely-accessible copy was identified._")
    lines += ["", "## Summary (by the research agent)", "", src["summary"].strip(), ""]
    if fulltext_md is not None:
        lines += [
            "---",
            "",
            "## Full text",
            "",
            f"> Extracted from {src['fulltext_url']} on {today}. "
            "Automatic conversion (PDF→text where applicable) — formatting may be imperfect.",
            "",
            fulltext_md.strip(),
            "",
        ]
    return "\n".join(lines)


def _unique_run_dir(out_dir: Path, topic: str, *, when: date) -> Path:
    slug = slugify(topic)
    path = out_dir / f"{when.isoformat()}-{slug}"
    n = 2
    while path.exists():
        path = out_dir / f"{when.isoformat()}-{slug}-{n}"
        n += 1
    return path


# --- rendering for the in-app reader ---------------------------------------
#
# What the pane shows for any of these Markdown files — the review or a source
# note. External links (DOIs, OA URLs) become inert text: the TUI can't follow
# them, and a click on one is just an error. We also add one link the pane *can*
# follow: to the file on disk itself, so it can be opened in a real editor.

_MD_LINK_RE = re.compile(r"\[([^\]\n]*)\]\((https?://[^)\s]+)\)")
_AUTOLINK_RE = re.compile(r"<(https?://[^>\s]+)>")
_CODE_SPAN_RE = re.compile(r"`[^`\n]*`")
_URL_RE = re.compile(r"https?://[^\s<>)\]`]+")


def _neutralize_links(md: str) -> str:
    """Render external links and bare URLs as inert text — the TUI can't follow them."""

    def _unlink(match: re.Match[str]) -> str:
        label, url = match.group(1).strip(), match.group(2).strip()
        return url if (not label or label == url) else f"{label} ({url})"

    md = _AUTOLINK_RE.sub(lambda m: m.group(1), _MD_LINK_RE.sub(_unlink, md or ""))

    out: list[str] = []
    pos = 0
    for span in _CODE_SPAN_RE.finditer(md):
        out.append(_URL_RE.sub(lambda u: f"`{u.group(0)}`", md[pos : span.start()]))
        out.append(span.group(0))
        pos = span.end()
    out.append(_URL_RE.sub(lambda u: f"`{u.group(0)}`", md[pos:]))
    return "".join(out)


def display_markdown(markdown: str, *, path: Path | str | None = None) -> str:
    """The reader version of a Markdown file: external links de-clicked, a link to the file added."""
    md = _neutralize_links(markdown or "")
    if not path:
        return md
    path = Path(path)
    return f"📄 **[Open this file]({path.as_uri()})** · `{path}`\n\n---\n\n{md}"


# --- the run ----------------------------------------------------------------


async def run_research(
    topic: str,
    *,
    db: sqlite3.Connection,
    config: Config,
    on_event: Progress | None = None,
) -> ResearchResult:
    """Research *topic*, lay out the paper + source notes, record the run, and return the result."""
    topic = " ".join(topic.split()).strip()
    title = f"Literature review: {topic}" if topic else ""
    if not topic:
        return ResearchResult(topic="", title="", error="give me a topic to research")

    today = date.today()
    if on_event:
        on_event("status", "Briefing the research agent…")
    prompt = _build_prompt(
        topic,
        min_sources=config.research.min_sources,
        max_sources=config.research.max_sources,
        today=today.isoformat(),
    )
    raw, error = await llm.deep_research(
        prompt, timeout=float(config.research.timeout_seconds), on_event=on_event
    )
    if error or not raw:
        err = error or "the research agent returned nothing"
        rid = store.record_research(db, topic=topic, title=title, error=err)
        return ResearchResult(topic=topic, title=title, error=err, research_id=rid)

    if on_event:
        on_event("status", "Reading the agent's report…")
    paper_md, title, raw_sources = _parse_agent_output(raw, topic=topic)

    run_dir = _unique_run_dir(output_dir(config), topic, when=today)
    sources: list[ResearchSource] = []
    if raw_sources:
        sources_dir = run_dir / "sources"
        sources_dir.mkdir(parents=True, exist_ok=True)
        used: set[str] = set()
        plan: list[tuple[dict, str]] = []  # (entry, filename within sources/)
        for entry in raw_sources:
            fname = _source_filename(entry["n"], entry["citation"])
            stem, k = fname[:-3], 2
            while fname in used:
                fname = f"{stem}-{k}.md"
                k += 1
            used.add(fname)
            plan.append((entry, fname))

        wanted = sum(1 for e, _ in plan if e.get("fulltext_url"))
        if on_event and wanted:
            on_event("status", f"Fetching full text for {wanted} source(s)…")
        fulltexts = await _fetch_fulltexts([e for e, _ in plan], on_event=on_event)

        if on_event:
            on_event("status", "Saving the paper and source notes…")
        for entry, fname in plan:
            ft = fulltexts.get(entry["n"])
            (sources_dir / fname).write_text(_source_note_text(entry, ft), encoding="utf-8")
            sources.append(
                ResearchSource(
                    n=entry["n"],
                    citation=entry["citation"],
                    url=entry["url"],
                    fulltext_url=entry["fulltext_url"],
                    file=sources_dir / fname,
                    has_fulltext=ft is not None,
                )
            )
    else:
        run_dir.mkdir(parents=True, exist_ok=True)

    paper_path = run_dir / "paper.md"
    paper_path.write_text(
        paper_md if paper_md.endswith("\n") else paper_md + "\n", encoding="utf-8"
    )

    source_count = len(sources) or _count_references(paper_md)
    sources_json = json.dumps(
        [
            {
                "n": s.n,
                "citation": s.citation,
                "url": s.url,
                "fulltext_url": s.fulltext_url,
                "fulltext": s.has_fulltext,
                "file": s.file.relative_to(run_dir).as_posix(),
            }
            for s in sources
        ]
    )
    rid = store.record_research(
        db,
        topic=topic,
        title=title,
        path=str(paper_path),
        markdown=paper_md,
        source_count=source_count,
        sources_json=sources_json,
    )
    return ResearchResult(
        topic=topic,
        title=title,
        markdown=paper_md,
        path=paper_path,
        source_count=source_count,
        sources=sources,
        research_id=rid,
    )
