"""A tiny synchronous event bus.

Decouples producers (the scheduler, sources) from consumers (UI panes) without
making everything a Textual widget. Handlers run inline on whatever loop calls
:meth:`EventBus.emit`; a misbehaving handler is logged-and-skipped so one bad
subscriber can't take down a refresh.

Event names used so far:

- ``"refresh_started"``        — payload: ``source_kinds: list[str]``
- ``"item_discovered"``        — payload: ``item_id: int``, ``source_kind: str``
- ``"refresh_finished"``       — payload: ``found: int``, ``new: int``, ``errors: list[str]``
- ``"item_state_changed"``     — payload: ``item_id: int``, ``state: str``  (M3+)
"""

from __future__ import annotations

import logging
from collections import defaultdict
from collections.abc import Callable
from typing import Any

log = logging.getLogger(__name__)

Handler = Callable[..., Any]


class EventBus:
    def __init__(self) -> None:
        self._handlers: dict[str, list[Handler]] = defaultdict(list)

    def subscribe(self, event: str, handler: Handler) -> Callable[[], None]:
        """Register *handler* for *event*. Returns a function that unsubscribes it."""
        self._handlers[event].append(handler)

        def unsubscribe() -> None:
            try:
                self._handlers[event].remove(handler)
            except ValueError:
                pass

        return unsubscribe

    def emit(self, event: str, **payload: Any) -> None:
        for handler in list(self._handlers.get(event, ())):
            try:
                handler(**payload)
            except Exception:  # noqa: BLE001 — one bad subscriber shouldn't break emit
                log.exception("event handler for %r failed", event)
