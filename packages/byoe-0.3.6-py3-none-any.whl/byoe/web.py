"""byoe web — browser UI for the BYOE Agent (JetBot frontend).

Single-file HTTP server using only the Python standard library.
No new runtime dependencies beyond what byoe already requires.

Architecture
------------
- ThreadingHTTPServer handles concurrent requests (one thread per connection)
- Server-Sent Events (SSE) stream tokens + tool-call progress to the browser
- All state lives in a single WebSession object shared across HTTP handlers
- A one-time token printed to the terminal gates every /api/* request (CSRF-safe)
- JetBot React frontend is served from byoe/static/ (pre-built dist)
- Falls back to inline HTML if byoe/static/ is absent

Endpoints
---------
  GET  /              → JetBot UI (or fallback inline HTML)
  GET  /assets/*      → Static assets (JS/CSS)
  GET  /api/status    → JSON: model, base_url, token usage, changed files
  GET  /api/sessions  → JSON list of saved sessions
  GET  /api/models    → JSON: proxied model list from the configured LLM provider
  POST /api/chat      → SSE stream: { "q": "...", "model"?, "api_key"?, "base_url"? }
  POST /api/reset     → Reset conversation history
  POST /api/abort     → Abort current agent loop (non-destructive)
  POST /api/save      → Save session, returns { "id": "..." }
  GET  /api/diff      → JSON list of changed files
  GET  /api/tokens    → JSON token usage
  GET  /api/crew      → JSON Crew workspace status
"""
from __future__ import annotations

import hashlib
import html
import io
import json
import os
import queue
import secrets
import sys
import threading
import time
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import TYPE_CHECKING
from urllib.parse import parse_qs, urlparse

if TYPE_CHECKING:
    from .engine.agent import Agent
    from .engine.config import Config


# ─────────────────────────────────────────────────────────────────────────────

# Minimal fallback HTML — shown only when byoe/static/ (JetBot dist) is absent.
# Rebuild: run `npm run build` in jetbot/ and copy dist/ to byoe/byoe/static/
_HTML_FALLBACK = (
    "<!DOCTYPE html><html lang='en'><head>"
    "<meta charset='UTF-8'>"
    "<meta name='viewport' content='width=device-width,initial-scale=1'>"
    "<title>BYOE</title>"
    "<style>body{font-family:system-ui,sans-serif;background:#0d1117;color:#e6edf3;"
    "display:flex;align-items:center;justify-content:center;height:100vh;margin:0;"
    "flex-direction:column;gap:16px}a{color:#58a6ff}code{background:#161b22;"
    "padding:2px 6px;border-radius:4px}</style></head><body>"
    "<h2>\u535c\u4e00\u667a\u822a · BYOE __VERSION__</h2>"
    "<p>JetBot frontend not found. Install or upgrade:</p>"
    "<code>pip install --upgrade byoe</code>"
    "<p>Or rebuild frontend: see <a href='https://byoe.net'>byoe.net</a></p>"
    "</body></html>"
)



# ─────────────────────────────────────────────────────────────────────────────
# Shared web session state
# ─────────────────────────────────────────────────────────────────────────────

class WebSession:
    """Holds the single Agent instance shared across all HTTP requests."""

    def __init__(self, agent: "Agent", config: "Config", token: str, cwd: str):
        self.agent = agent
        self.config = config
        self.token = token
        self.cwd = cwd
        self._lock = threading.Lock()   # serialise chat calls

    def verify(self, req_token: str) -> bool:
        return secrets.compare_digest(self.token, req_token)


# ─────────────────────────────────────────────────────────────────────────────
# HTTP handler
# ─────────────────────────────────────────────────────────────────────────────

class ByoeHandler(BaseHTTPRequestHandler):

    # injected by start_web() below
    session: WebSession

    def log_message(self, fmt, *args):  # noqa: A002
        pass  # suppress default access log; errors still go to stderr

    # ── auth ──────────────────────────────────────────────────────────────────

    def _token_from_request(self) -> str:
        qs = parse_qs(urlparse(self.path).query)
        t = qs.get("token", [""])[0]
        if t:
            return t
        # also accept header (used by fetch() with X-BYOE-Token)
        return self.headers.get("X-BYOE-Token", "")

    def _authorized(self) -> bool:
        return self.session.verify(self._token_from_request())

    # ── response helpers ──────────────────────────────────────────────────────

    def _json(self, code: int, data: object) -> None:
        body = json.dumps(data, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _html_response(self, code: int, body: str) -> None:
        b = body.encode()
        self.send_response(code)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(b)))
        self.end_headers()
        self.wfile.write(b)

    def _read_body(self) -> dict:
        length = int(self.headers.get("Content-Length", 0))
        if length <= 0:
            return {}
        raw = self.rfile.read(length)
        try:
            return json.loads(raw)
        except Exception:
            return {}

    # ── routing ───────────────────────────────────────────────────────────────

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET,POST,DELETE,OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type,X-BYOE-Token")
        self.end_headers()

    def _serve_static(self, path: str) -> bool:
        """Try to serve a file from byoe/static/. Returns True if handled."""
        import mimetypes
        # Explicit MIME types — Windows registry often lacks these
        _MIME_OVERRIDES = {
            ".js":   "application/javascript",
            ".mjs":  "application/javascript",
            ".css":  "text/css",
            ".svg":  "image/svg+xml",
            ".ico":  "image/x-icon",
            ".png":  "image/png",
            ".json": "application/json",
            ".woff2": "font/woff2",
            ".woff":  "font/woff",
        }
        static_dir = Path(__file__).parent / "static"
        if not static_dir.is_dir():
            return False
        # Map "/" to "index.html"
        rel = "index.html" if path in ("", "/") else path.lstrip("/")
        file_path = static_dir / rel
        # Security: ensure path stays within static_dir
        try:
            resolved = file_path.resolve()
            static_dir.resolve().resolve()
            resolved.relative_to(static_dir.resolve())
        except (ValueError, OSError):
            return False
        if not resolved.is_file():
            # SPA fallback ONLY for extension-less paths (HTML routes)
            # Never serve index.html for asset requests (.js/.css/etc.)
            suffix = Path(rel).suffix.lower()
            if suffix:
                # It's an asset request but file is missing — return 404
                self._json(404, {"error": "Not found"})
                return True  # handled (with 404)
            # No extension → SPA route, serve index.html
            resolved = static_dir / "index.html"
            if not resolved.is_file():
                return False
        data = resolved.read_bytes()
        suffix = resolved.suffix.lower()
        mime = _MIME_OVERRIDES.get(suffix) or mimetypes.guess_type(str(resolved))[0] or "application/octet-stream"
        self.send_response(200)
        self.send_header("Content-Type", mime)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "public, max-age=31536000, immutable" if "/assets/" in str(resolved) else "no-cache")
        self.end_headers()
        self.wfile.write(data)
        return True

    def do_GET(self):
        path = urlparse(self.path).path

        if not path.startswith("/api/"):
            # Serve JetBot static frontend (with token in URL for auto-auth)
            if self._serve_static(path):
                return
            # Fallback to inline HTML if no static dir
            self._html_response(200, _HTML_FALLBACK.replace("__VERSION__", _byoe_version()))
            return

        if not self._authorized():
            self._json(401, {"error": "Unauthorized"})
            return

        if path == "/api/status":
            self._handle_status()
        elif path == "/api/sessions":
            self._handle_list_sessions()
        elif path == "/api/diff":
            self._handle_diff()
        elif path == "/api/tokens":
            self._handle_tokens()
        elif path == "/api/crew":
            self._handle_crew()
        elif path == "/api/models":
            self._handle_models()
        else:
            self._json(404, {"error": "Not found"})

    def do_POST(self):
        path = urlparse(self.path).path

        if not self._authorized():
            self._json(401, {"error": "Unauthorized"})
            return

        if path == "/api/chat":
            self._handle_chat()
        elif path == "/api/reset":
            self._handle_reset()
        elif path == "/api/abort":
            self._handle_abort()
        elif path == "/api/save":
            self._handle_save()
        elif path == "/api/load":
            self._handle_load()
        else:
            self._json(404, {"error": "Not found"})

    def do_DELETE(self):
        path = urlparse(self.path).path

        if not self._authorized():
            self._json(401, {"error": "Unauthorized"})
            return

        # DELETE /api/sessions/<id>
        if path.startswith("/api/sessions/"):
            sid = path[len("/api/sessions/"):]
            if not sid:
                self._json(400, {"error": "Missing session id"})
                return
            from byoe.engine.session import delete_session
            ok = delete_session(sid)
            if ok:
                self._json(200, {"ok": True, "id": sid})
            else:
                self._json(404, {"ok": False, "error": f"Session not found: {sid}"})
        else:
            self._json(404, {"error": "Not found"})

    # ── GET handlers ─────────────────────────────────────────────────────────

    def _handle_status(self):
        agent = self.session.agent
        llm = agent.llm
        cost = llm.estimated_cost
        # Mask api_key: show only last 4 chars for display
        raw_key = getattr(llm, '_api_key', '') or ''
        masked_key = ('*' * (len(raw_key) - 4) + raw_key[-4:]) if len(raw_key) > 4 else ('*' * len(raw_key))
        self._json(200, {
            "model": llm.model,
            "base_url": getattr(llm, '_base_url', None),
            "api_key_masked": masked_key,
            "cwd": self.session.cwd,
            "prompt_tokens": llm.total_prompt_tokens,
            "completion_tokens": llm.total_completion_tokens,
            "estimated_cost": round(cost, 6) if cost is not None else None,
            "changed_files": len(agent.changed_files),
            "message_count": len(agent.messages),
        })

    def _handle_list_sessions(self):
        from byoe.engine.session import list_sessions
        self._json(200, list_sessions())

    def _handle_diff(self):
        files = sorted(self.session.agent.changed_files)
        self._json(200, {"files": files})

    def _handle_tokens(self):
        llm = self.session.agent.llm
        cost = llm.estimated_cost
        self._json(200, {
            "prompt_tokens": llm.total_prompt_tokens,
            "completion_tokens": llm.total_completion_tokens,
            "total": llm.total_prompt_tokens + llm.total_completion_tokens,
            "estimated_cost": round(cost, 6) if cost is not None else None,
        })

    def _handle_models(self):
        """Proxy GET /v1/models from the configured LLM provider."""
        import urllib.request
        import urllib.error
        llm = self.session.agent.llm
        base = (getattr(llm, '_base_url', None) or 'https://api.openai.com/v1').rstrip('/')
        api_key = getattr(llm, '_api_key', '') or ''
        try:
            req = urllib.request.Request(
                f"{base}/models",
                headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
            )
            with urllib.request.urlopen(req, timeout=8) as resp:
                data = json.loads(resp.read().decode())
            # Normalise to a flat list of model id strings
            models = sorted({m.get("id", "") for m in data.get("data", [])} - {""})
            self._json(200, {"models": models})
        except Exception as exc:
            # Return the current model as a fallback so the UI always has something
            self._json(200, {"models": [llm.model], "error": str(exc)})

    def _handle_crew(self):
        """Return Crew workspace status as JSON (equiv. to `byoe status`)."""
        cwd = Path(self.session.cwd)
        crew_dir = cwd / "crew"

        if not crew_dir.exists():
            self._json(200, {"active": False, "reason": "no crew/ directory"})
            return

        changes_dir = crew_dir / "changes"
        archive_dir = crew_dir / "archive"

        active_changes = []
        if changes_dir.exists():
            for d in sorted(changes_dir.iterdir()):
                if d.is_dir():
                    info: dict = {"name": d.name}
                    proposal = d / "proposal.md"
                    if proposal.exists():
                        txt = proposal.read_text(encoding="utf-8")
                        # extract title from first heading
                        for line in txt.splitlines():
                            if line.startswith("# "):
                                info["title"] = line[2:].strip()
                                break
                    tasks_total = tasks_done = 0
                    tasks_file = d / "tasks.md"
                    if tasks_file.exists():
                        for line in tasks_file.read_text(encoding="utf-8").splitlines():
                            if line.strip().startswith("- ["):
                                tasks_total += 1
                                if line.strip().startswith("- [x]") or line.strip().startswith("- [X]"):
                                    tasks_done += 1
                    info["tasks_total"] = tasks_total
                    info["tasks_done"] = tasks_done
                    active_changes.append(info)

        archived_count = (
            len([x for x in archive_dir.iterdir() if x.is_dir()])
            if archive_dir.exists() else 0
        )

        # blockers
        open_blockers: list[dict] = []
        blockers_file = crew_dir / "blockers.md"
        if blockers_file.exists():
            import re
            for line in blockers_file.read_text(encoding="utf-8").splitlines():
                m = re.match(r"\[([A-Z0-9-]+)\]\s+\[?(OPEN|CLOSED)\]?\s+(.*)", line.strip())
                if m and m.group(2) == "OPEN":
                    open_blockers.append({"id": m.group(1), "title": m.group(3).strip()})

        # next steps from resume.md
        next_steps: list[str] = []
        resume = crew_dir / "resume.md"
        if resume.exists():
            import re
            in_section = False
            for line in resume.read_text(encoding="utf-8").splitlines():
                if re.match(r"#+\s*(next|下一步)", line, re.I):
                    in_section = True
                    continue
                if in_section:
                    if line.startswith("#"):
                        break
                    stripped = line.strip()
                    if stripped.startswith("-") or stripped.startswith("*"):
                        next_steps.append(stripped.lstrip("-* ").strip())

        self._json(200, {
            "active": True,
            "active_changes": active_changes,
            "archived_count": archived_count,
            "open_blockers": open_blockers,
            "next_steps": next_steps[:5],
        })

    # ── POST handlers ─────────────────────────────────────────────────────────

    def _handle_abort(self):
        self.session.agent.abort()
        self._json(200, {"ok": True})

    def _handle_reset(self):
        self.session.agent.reset()
        self._json(200, {"ok": True})

    def _handle_save(self):
        from byoe.engine.session import save_session
        agent = self.session.agent
        sid = save_session(
            agent.messages,
            agent.llm.model,
            changed_files=agent.changed_files,
        )
        self._json(200, {"id": sid})

    def _handle_load(self):
        from byoe.engine.session import load_session
        body = self._read_body()
        sid = body.get("id", "")
        loaded = load_session(sid)
        if not loaded:
            self._json(404, {"ok": False, "error": f"Session not found: {sid}"})
            return
        msgs, model, changed = loaded
        agent = self.session.agent
        agent.messages = msgs
        agent.changed_files.update(changed)
        agent.llm.model = model
        self._json(200, {"ok": True, "model": model, "messages": msgs})

    def _handle_chat(self):
        """SSE stream: each event is a JSON line prefixed with 'data: '."""
        body = self._read_body()
        q = body.get("q", "").strip()
        if not q:
            self._json(400, {"error": "Empty message"})
            return

        # Optional per-request overrides: model, api_key, base_url
        model_override    = (body.get("model",    "") or "").strip() or None
        api_key_override  = (body.get("api_key",  "") or "").strip() or None
        base_url_override = (body.get("base_url", "") or "").strip() or None
        if model_override or api_key_override or base_url_override:
            self.session.agent.llm.reconfigure(
                model=model_override,
                api_key=api_key_override,
                base_url=base_url_override,
            )

        # Optional skill injection — client sends active skill instructions
        skill_instructions = (body.get("skill_instructions", "") or "").strip()
        agent = self.session.agent
        _orig_system = agent._system
        if skill_instructions:
            agent._system = _orig_system + (
                f"\n\n---\n# Active Skill\n{skill_instructions}"
            )

        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream; charset=utf-8")
        self.send_header("Cache-Control", "no-cache")
        self.send_header("X-Accel-Buffering", "no")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()

        def emit(data: dict) -> bool:
            """Write one SSE event. Returns False if the client disconnected."""
            try:
                line = "data: " + json.dumps(data, ensure_ascii=False) + "\n\n"
                self.wfile.write(line.encode())
                self.wfile.flush()
                return True
            except (BrokenPipeError, ConnectionResetError, OSError):
                return False

        def on_token(tok: str):
            emit({"type": "token", "text": tok})

        def on_tool(name: str, kwargs: dict):
            detail = (
                kwargs.get("command") or kwargs.get("path") or
                kwargs.get("file_path") or kwargs.get("pattern") or ""
            )
            if len(detail) > 120:
                detail = detail[:117] + "..."
            emit({"type": "tool", "name": name, "arg": detail})

        def on_tool_result(name: str, kwargs: dict, result: str):
            if name != "bash":
                return
            if not result or result == "(no output)":
                return
            has_error = "[exit code:" in result or result.startswith("Error")
            if has_error or len(result) <= 200:
                emit({"type": "tool_err", "name": name,
                      "arg": kwargs.get("command", ""),
                      "snippet": result[:300]})

        def on_compress(layer: str, before: int, after: int):
            labels = {
                "snip":      "工具输出已裁剪",
                "summarize": "上下文已摘要压缩",
                "collapse":  "上下文已硬重置",
            }
            emit({"type": "compress", "label": labels.get(layer, layer),
                  "before": before, "after": after})

        with self.session._lock:
            old_cwd = os.getcwd()
            try:
                os.chdir(self.session.cwd)
                response = self.session.agent.chat(
                    q,
                    on_token=on_token,
                    on_tool=on_tool,
                    on_tool_result=on_tool_result,
                    on_compress=on_compress,
                )
            except Exception as e:
                emit({"type": "token", "text": f"\n\n**Error:** {e}"})
                response = ""
            finally:
                os.chdir(old_cwd)
                # Always restore the base system prompt after this turn
                agent._system = _orig_system

        emit({"type": "done", "text": response})
        try:
            self.wfile.write(b"data: [DONE]\n\n")
            self.wfile.flush()
        except OSError:
            pass


# ─────────────────────────────────────────────────────────────────────────────
# Public entry point
# ─────────────────────────────────────────────────────────────────────────────

def start_web(
    host: str = "127.0.0.1",
    port: int = 7860,
    open_browser: bool = True,
    model: str | None = None,
    resume: str | None = None,
) -> None:
    """Build agent, start ThreadingHTTPServer, optionally open browser."""
    from byoe.engine.config import Config
    from byoe.engine.llm import LLM
    from byoe.engine.agent import Agent
    from byoe import __version__

    config = Config.from_env()
    if model:
        config.model = model
    if not config.api_key:
        print(
            "Error: API Key not found.\n"
            "Set BYOE_API_KEY / OPENAI_API_KEY / DEEPSEEK_API_KEY / ANTHROPIC_API_KEY"
        )
        sys.exit(1)

    llm = LLM(
        model=config.model,
        api_key=config.api_key,
        base_url=config.base_url,
        temperature=config.temperature,
        max_tokens=config.max_tokens,
    )
    agent = Agent(llm=llm, max_context_tokens=config.max_context_tokens)

    # Resume an existing session if requested
    if resume:
        from byoe.engine.session import load_session
        loaded = load_session(resume)
        if loaded:
            msgs, sess_model, changed = loaded
            agent.messages = msgs
            agent.changed_files.update(changed)
            if not model:          # don't override explicit --model flag
                agent.llm.model = sess_model
                config.model = sess_model
            print(f"  Resumed: {resume}  ({len(msgs)} messages)")
        else:
            print(f"  Warning: session '{resume}' not found, starting fresh.")

    token = secrets.token_urlsafe(16)
    cwd = os.getcwd()

    # Inject handler's session reference via class attribute
    # (avoids global state while keeping BaseHTTPRequestHandler compatible)
    session = WebSession(agent=agent, config=config, token=token, cwd=cwd)
    ByoeHandler.session = session  # type: ignore[attr-defined]

    server = ThreadingHTTPServer((host, port), ByoeHandler)

    url = f"http://{host}:{port}/?token={token}"

    print("=" * 60)
    print(f"  BYOE Web UI  —  v{_byoe_version()}")
    print(f"  Model : {config.model}")
    print(f"  CWD   : {cwd}")
    print("=" * 60)
    print(f"\n  URL:  {url}\n")
    print("  Ctrl+C to stop\n")

    if open_browser:
        # Delay slightly so the server is ready before the browser connects
        threading.Timer(0.8, webbrowser.open, args=(url,)).start()

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")
        server.server_close()


def _byoe_version() -> str:
    try:
        from byoe import __version__
        return __version__
    except Exception:
        return "?"
