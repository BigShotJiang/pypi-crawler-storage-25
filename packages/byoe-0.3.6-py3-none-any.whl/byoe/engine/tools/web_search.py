"""Web search tool via DuckDuckGo Lite (no API key required).

Returns a ranked list of result titles + URLs + snippets.
"""

import re
import urllib.parse
import urllib.request
from .base import Tool

MAX_RESULTS = 8
TIMEOUT     = 15
DDG_URL     = "https://lite.duckduckgo.com/lite/"


def _parse_ddg_lite(html: str) -> list[dict]:
    """Extract results from DuckDuckGo Lite HTML (no JS required)."""
    results = []

    # Each result block: <a class="result-link" href="...">Title</a>
    # followed by a snippet in a <td class="result-snippet">
    link_pattern   = re.compile(r'<a[^>]+class="result-link"[^>]*href="([^"]+)"[^>]*>(.*?)</a>', re.S)
    snippet_pattern = re.compile(r'<td[^>]+class="result-snippet"[^>]*>(.*?)</td>', re.S)

    links   = link_pattern.findall(html)
    snippets = snippet_pattern.findall(html)

    def clean(text: str) -> str:
        text = re.sub(r"<[^>]+>", "", text)
        text = text.replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">") \
                   .replace("&quot;", '"').replace("&#39;", "'").replace("&nbsp;", " ")
        return re.sub(r"\s+", " ", text).strip()

    for i, (url, title) in enumerate(links[:MAX_RESULTS]):
        snippet = clean(snippets[i]) if i < len(snippets) else ""
        results.append({
            "title":   clean(title),
            "url":     url,
            "snippet": snippet,
        })

    return results


class WebSearchTool(Tool):
    name = "web_search"
    description = (
        "Search the web using DuckDuckGo and return a list of results with titles, "
        "URLs, and snippets. No API key required. "
        "Useful for finding documentation, error solutions, or recent information."
    )
    parameters = {
        "type": "object",
        "properties": {
            "query": {
                "type": "string",
                "description": "The search query.",
            },
            "max_results": {
                "type": "integer",
                "description": f"Number of results to return. Default: 5. Max: {MAX_RESULTS}.",
            },
        },
        "required": ["query"],
    }

    def execute(self, query: str, max_results: int = 5) -> str:
        max_results = max(1, min(int(max_results), MAX_RESULTS))

        params  = urllib.parse.urlencode({"q": query, "kl": "us-en"})
        url     = f"{DDG_URL}?{params}"
        headers = {
            "User-Agent": "Mozilla/5.0 (compatible; byoe-agent/1.0)",
            "Accept":     "text/html",
        }
        req = urllib.request.Request(url, headers=headers)

        try:
            with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
                html = resp.read(64_000).decode("utf-8", errors="replace")
        except Exception as e:
            return f"Error fetching search results: {e}"

        results = _parse_ddg_lite(html)

        if not results:
            return f"No results found for: {query}"

        lines = [f"Search results for: {query}\n"]
        for i, r in enumerate(results[:max_results], 1):
            lines.append(f"{i}. {r['title']}")
            lines.append(f"   URL: {r['url']}")
            if r["snippet"]:
                lines.append(f"   {r['snippet']}")
            lines.append("")

        return "\n".join(lines).strip()
