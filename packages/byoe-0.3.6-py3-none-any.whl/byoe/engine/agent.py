"""Core agent loop.

Pattern:  user message -> LLM (with tools) -> tool calls? -> execute -> loop
                                            -> text reply? -> return to user
"""

import concurrent.futures
import threading
from .llm import LLM
from .tools import ALL_TOOLS
from .tools.base import Tool
from .tools.agent import AgentTool
from .tools.bash import BashTool
from .tools.edit import EditFileTool
from .tools.write import WriteFileTool
from .tools.todo_tool import TodoTool
from .prompt import system_prompt
from .context import ContextManager


class Agent:
    def __init__(
        self,
        llm: LLM,
        tools: list[Tool] | None = None,
        max_context_tokens: int = 128_000,
        max_rounds: int = 50,
    ):
        self.llm = llm
        self.tools = tools if tools is not None else ALL_TOOLS
        self.messages: list[dict] = []
        self.context = ContextManager(max_tokens=max_context_tokens)
        self.max_rounds = max_rounds
        self._system = system_prompt(self.tools)

        # Session-scoped change tracker shared by EditFileTool & WriteFileTool.
        self.changed_files: set[str] = set()
        self._wire_tools()

        # Per-tool locks: serialise concurrent calls on the same stateful instance
        # (e.g. two parallel BashTool calls both updating self._cwd).
        self._tool_locks: dict[str, threading.Lock] = {
            t.name: threading.Lock() for t in self.tools
        }
        # O(1) name to wired-instance map (built after _wire_tools).
        self._tool_map: dict[str, Tool] = {t.name: t for t in self.tools}

        # Abort flag: set by abort() to request early termination of chat().
        self._abort_flag = threading.Event()

    # ── wiring & lifecycle ────────────────────────────────────────────────────

    def _wire_tools(self) -> None:
        """Inject per-session state into tools that need it."""
        for t in self.tools:
            if isinstance(t, AgentTool):
                t._parent_agent = self
            if isinstance(t, (EditFileTool, WriteFileTool)):
                t._set_changed_files(self.changed_files)

    def reset(self) -> None:
        self.messages.clear()
        self.changed_files.clear()
        self._abort_flag.clear()
        # Reset per-session token counters so the UI shows usage for the new
        # conversation, not accumulated across all previous resets.
        self.llm.total_prompt_tokens = 0
        self.llm.total_completion_tokens = 0
        for t in self.tools:
            if isinstance(t, BashTool):
                t.reset_cwd()
            if isinstance(t, TodoTool):
                t._reset()
        # Re-build system prompt (picks up any file changes on disk).
        self._system = system_prompt(self.tools)

    # ── abort ─────────────────────────────────────────────────────────────────

    def abort(self) -> None:
        """Signal the currently-running chat() loop to stop after the current step."""
        self._abort_flag.set()

    # ── message helpers ───────────────────────────────────────────────────────

    def _full_messages(self) -> list[dict]:
        return [{"role": "system", "content": self._system}] + self.messages

    def _tool_schemas(self) -> list[dict]:
        return [t.schema() for t in self.tools]

    # ── main chat loop ────────────────────────────────────────────────────────

    def chat(self, user_input: str, on_token=None, on_tool=None, on_tool_result=None, on_compress=None) -> str:
        """Run one user turn through the agent loop.

        Args:
            user_input:     The user message.
            on_token:       Callback(str) for streaming tokens.
            on_tool:        Callback(name, kwargs) called *before* each tool execution.
            on_tool_result: Callback(name, kwargs, result) called *after* each tool execution.
            on_compress:    Callback(layer, before_tokens, after_tokens) on context compression.
        """
        self.messages.append({"role": "user", "content": user_input})
        self.context.maybe_compress(self.messages, self.llm, on_compress=on_compress)
        self._abort_flag.clear()   # reset from any previous abort

        for _ in range(self.max_rounds):
            if self._abort_flag.is_set():
                return "(aborted by user)"

            resp = self.llm.chat(
                messages=self._full_messages(),
                tools=self._tool_schemas(),
                on_token=on_token,
            )

            if not resp.tool_calls:
                self.messages.append(resp.message)
                return resp.content

            self.messages.append(resp.message)

            if len(resp.tool_calls) == 1:
                tc = resp.tool_calls[0]
                if on_tool:
                    on_tool(tc.name, tc.arguments)
                result = self._exec_tool(tc)
                if on_tool_result:
                    on_tool_result(tc.name, tc.arguments, result)
                self.messages.append({
                    "role": "tool",
                    "tool_call_id": tc.id,
                    "content": result,
                })
            else:
                results = self._exec_tools_parallel(
                    resp.tool_calls, on_tool=on_tool, on_tool_result=on_tool_result
                )
                for tc, result in zip(resp.tool_calls, results):
                    self.messages.append({
                        "role": "tool",
                        "tool_call_id": tc.id,
                        "content": result,
                    })

            self.context.maybe_compress(self.messages, self.llm, on_compress=on_compress)

        return "(reached maximum tool-call rounds)"

    # ── tool execution ────────────────────────────────────────────────────────

    def _exec_tool(self, tc) -> str:
        """Execute a single tool call using the Agent's wired instance map."""
        tool = self._tool_map.get(tc.name)
        if tool is None:
            return f"Error: unknown tool '{tc.name}'"
        try:
            return tool.execute(**tc.arguments)
        except TypeError as e:
            return f"Error calling {tc.name}: {e}"
        except Exception as e:
            return f"Tool error ({tc.name}): {e}"

    def _exec_tools_parallel(self, tool_calls, on_tool=None, on_tool_result=None) -> list[str]:
        """Execute multiple tool calls in parallel, serialising per-tool to
        prevent concurrent mutation of stateful instances (e.g. BashTool._cwd)."""
        results: list[str] = [""] * len(tool_calls)
        with concurrent.futures.ThreadPoolExecutor() as executor:
            futures = {}
            for i, tc in enumerate(tool_calls):
                if on_tool:
                    on_tool(tc.name, tc.arguments)
                lock = self._tool_locks.get(tc.name)

                def _run(tc=tc, lock=lock):
                    if lock:
                        with lock:
                            return self._exec_tool(tc)
                    return self._exec_tool(tc)

                futures[executor.submit(_run)] = (i, tc)
            for future in concurrent.futures.as_completed(futures):
                idx, tc = futures[future]
                try:
                    r = future.result()
                    results[idx] = r
                    if on_tool_result:
                        on_tool_result(tc.name, tc.arguments, r)
                except Exception as e:
                    results[idx] = f"Error: {e}"
        return results
