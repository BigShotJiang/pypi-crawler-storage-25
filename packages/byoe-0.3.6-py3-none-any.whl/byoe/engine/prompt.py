"""System prompt — turns an LLM into a coding agent aware of BYOE project context.

Deep integration: if the current directory contains Crew project files
(INSTRUCTIONS.md, crew.yaml, crew/resume.md), they are automatically
appended to the system prompt so the agent understands the project's workflow,
active changes, and architectural constraints without the user having to paste
anything manually.
"""

import os
import platform
from pathlib import Path


def system_prompt(tools) -> str:
    cwd = os.getcwd()
    tool_list = "\n".join(f"- **{t.name}**: {t.description}" for t in tools)
    uname = platform.uname()

    base = f"""\
You are 卜一智航 (BYOE Executive), an AI coding assistant by 卜一智元 (byoe.net).
You help with software engineering: writing code, fixing bugs, refactoring,
explaining code, running commands, and more.

# Environment
- Working directory: {cwd}
- OS: {uname.system} {uname.release} ({uname.machine})
- Python: {platform.python_version()}

# Tools
{tool_list}

# Rules
1. **Read before edit.** Always read a file before modifying it.
2. **edit_file for small changes.** Use edit_file for targeted edits; write_file only for new files or complete rewrites.
3. **Verify your work.** After making changes, run relevant tests or commands to confirm correctness.
4. **Be concise.** Show code over prose. Explain only what's necessary.
5. **One step at a time.** For multi-step tasks, execute them sequentially.
6. **edit_file uniqueness.** When using edit_file, include enough surrounding context in old_string to guarantee a unique match.
7. **Respect existing style.** Match the project's coding conventions.
8. **Ask when unsure.** If the request is ambiguous, ask for clarification rather than guessing.
"""

    # ── Deep integration: inject Crew project context if present ───────────
    crew_context = _load_crew_context(Path(cwd))
    if crew_context:
        base += crew_context

    return base


def _load_crew_context(cwd: Path) -> str:
    """Load Crew orchestration files from the current project directory.

    Returns a formatted string to append to the system prompt, or "" if this
    is not a Crew-managed project.
    """
    instructions = cwd / "INSTRUCTIONS.md"
    crew_yaml     = cwd / "crew.yaml"
    resume        = cwd / "crew" / "resume.md"
    blockers      = cwd / "crew" / "blockers.md"

    # Only inject if at least INSTRUCTIONS.md or crew.yaml exists
    if not instructions.exists() and not crew_yaml.exists():
        return ""

    parts: list[str] = ["\n\n---\n# BYOE Project Context (Crew)\n"]
    parts.append(
        "_The following context is auto-loaded from the Crew workspace. "
        "Follow the workflow and constraints described below._\n"
    )

    if instructions.exists():
        parts.append(f"\n## Project Instructions\n\n{_read_truncated(instructions, 6000)}")

    if crew_yaml.exists():
        parts.append(
            f"\n## Project Configuration ({crew_yaml.name})\n\n"
            f"```yaml\n{_read_truncated(crew_yaml, 2000)}```"
        )

    if resume.exists():
        parts.append(f"\n## Current Sprint Status\n\n{_read_truncated(resume, 3000)}")

    if blockers.exists():
        content = blockers.read_text(encoding="utf-8").strip()
        if content and "（无待解决问题）" not in content:
            parts.append(f"\n## Open Blockers\n\n{_read_truncated(blockers, 1500)}")

    return "\n".join(parts)


def _read_truncated(path: Path, max_chars: int) -> str:
    """Read a file and truncate if it exceeds max_chars to protect context window."""
    text = path.read_text(encoding="utf-8")
    if len(text) <= max_chars:
        return text
    half = max_chars // 2
    return (
        text[:half]
        + f"\n\n... [{len(text) - max_chars} chars omitted to fit context window] ...\n\n"
        + text[-(max_chars - half):]
    )
