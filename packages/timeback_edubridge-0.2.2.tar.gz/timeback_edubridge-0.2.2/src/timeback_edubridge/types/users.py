"""
EduBridge User Types

Types for user management.
"""

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field

from .base import Grade, GUIDRef, GUIDRefBase, Role, Status

# ═══════════════════════════════════════════════════════════════════════════════
# USER TYPES
# ═══════════════════════════════════════════════════════════════════════════════


class UserId(BaseModel):
    """User identifier (external ID)."""

    type: str
    identifier: str


class UserRole(BaseModel):
    """User role assignment."""

    role_type: Literal["primary", "secondary"] = Field(alias="roleType")
    role: Role
    org: GUIDRefBase
    user_profile: str | None = Field(default=None, alias="userProfile")
    metadata: dict[str, Any] | None = None
    begin_date: str | None = Field(default=None, alias="beginDate")
    end_date: str | None = Field(default=None, alias="endDate")

    model_config = ConfigDict(populate_by_name=True)


class UserCredential(BaseModel):
    """Application credentials for a user."""

    id: str
    type: str
    username: str
    password: str | None = None


class UserApp(BaseModel):
    """Application info within a user profile."""

    sourced_id: str = Field(alias="sourcedId")
    name: str
    description: str | None = None
    domain: list[str]
    metadata: dict[str, Any] | None = None

    model_config = ConfigDict(populate_by_name=True)


class UserProfile(BaseModel):
    """User profile for an application."""

    profile_id: str = Field(alias="profileId")
    profile_type: str = Field(alias="profileType")
    vendor_id: str = Field(alias="vendorId")
    application_id: str = Field(alias="applicationId")
    description: str | None = None
    app: UserApp
    credentials: list[UserCredential]

    model_config = ConfigDict(populate_by_name=True)


class PrimaryOrg(BaseModel):
    """Primary organization reference."""

    sourced_id: str = Field(alias="sourcedId")
    name: str

    model_config = ConfigDict(populate_by_name=True)


DemographicsSex = Literal["male", "female", "other", "unspecified"]
"""Biological sex, mirroring the server's ``GenderSchema``."""

DemographicsFlag = Literal["true", "false"]
"""
Stringified boolean demographics flag, mirroring the server's
``booleanToString()`` output.
"""


class Demographics(BaseModel):
    """
    Student demographics.

    Fields mirror the server's ``DemographicsSchema``. The race and ethnicity
    flags are emitted as the literal strings ``"true"`` / ``"false"`` (not
    booleans) after the server converts its boolean database columns via
    ``booleanToString()``. Unlike the other nullable fields, those flags are
    always present when a demographics object exists because the serializer
    falls back to ``"false"`` when the DB value is ``null``. Other nullable
    fields may be omitted after the server's ``sanitizeData`` strips ``null``
    values.
    """

    sourced_id: str = Field(alias="sourcedId")
    status: Status
    date_last_modified: str = Field(alias="dateLastModified")
    metadata: dict[str, Any] | None = None
    birth_date: str | None = Field(default=None, alias="birthDate")
    """ISO-8601 date (YYYY-MM-DD)."""
    sex: DemographicsSex | None = None
    american_indian_or_alaska_native: DemographicsFlag = Field(alias="americanIndianOrAlaskaNative")
    asian: DemographicsFlag
    black_or_african_american: DemographicsFlag = Field(alias="blackOrAfricanAmerican")
    native_hawaiian_or_other_pacific_islander: DemographicsFlag = Field(
        alias="nativeHawaiianOrOtherPacificIslander"
    )
    white: DemographicsFlag
    demographic_race_two_or_more_races: DemographicsFlag = Field(
        alias="demographicRaceTwoOrMoreRaces"
    )
    hispanic_or_latino_ethnicity: DemographicsFlag = Field(alias="hispanicOrLatinoEthnicity")
    country_of_birth_code: str | None = Field(default=None, alias="countryOfBirthCode")
    state_of_birth_abbreviation: str | None = Field(default=None, alias="stateOfBirthAbbreviation")
    city_of_birth: str | None = Field(default=None, alias="cityOfBirth")
    public_school_residence_status: str | None = Field(
        default=None, alias="publicSchoolResidenceStatus"
    )

    model_config = ConfigDict(populate_by_name=True)


class User(BaseModel):
    """
    A user in the system.

    Fields mirror the server's ``UserSchema`` / ``synthesizeUser`` output.
    Nullability tracks ``.nullable()`` / ``.optional()`` on the server schema.
    """

    sourced_id: str = Field(alias="sourcedId")
    status: Status
    date_last_modified: str = Field(alias="dateLastModified")
    metadata: dict[str, Any] | None = None
    user_master_identifier: str | None = Field(default=None, alias="userMasterIdentifier")
    username: str | None = None
    user_ids: list[UserId] = Field(alias="userIds")
    enabled_user: Literal["true", "false"] = Field(alias="enabledUser")
    given_name: str = Field(alias="givenName")
    family_name: str = Field(alias="familyName")
    middle_name: str | None = Field(default=None, alias="middleName")
    roles: list[UserRole]
    agents: list[GUIDRef]
    user_profiles: list[UserProfile] = Field(alias="userProfiles")
    primary_org: PrimaryOrg | None = Field(default=None, alias="primaryOrg")
    identifier: str | None = None
    email: str
    preferred_first_name: str | None = Field(default=None, alias="preferredFirstName")
    preferred_middle_name: str | None = Field(default=None, alias="preferredMiddleName")
    preferred_last_name: str | None = Field(default=None, alias="preferredLastName")
    pronouns: str | None = None
    grades: list[Grade] | None = None
    password: str | None = None
    sms: str | None = None
    phone: str | None = None
    demographics: Demographics | None = None
    """
    Student demographics, when present. Typically only populated for users
    with the ``student`` role. Absent when the underlying record is null.
    """

    model_config = ConfigDict(populate_by_name=True)
