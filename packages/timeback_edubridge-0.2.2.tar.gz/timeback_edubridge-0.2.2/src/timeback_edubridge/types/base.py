"""
EduBridge Base Types

Common types shared across EduBridge resources.
"""

from typing import Literal, TypeVar

from pydantic import BaseModel, ConfigDict

# ═══════════════════════════════════════════════════════════════════════════════
# COMMON TYPES
# ═══════════════════════════════════════════════════════════════════════════════

Status = Literal["active", "tobedeleted"]

Role = Literal[
    "administrator",
    "aide",
    "guardian",
    "parent",
    "proctor",
    "relative",
    "student",
    "teacher",
]

EnrollmentRole = Literal["administrator", "proctor", "student", "teacher"]

Grade = Literal[
    "-1",
    "0",
    "1",
    "2",
    "3",
    "4",
    "5",
    "6",
    "7",
    "8",
    "9",
    "10",
    "11",
    "12",
    "13",
]
"""
Grade level, mirroring the server's ``GradeEnum``.

``-1`` is Pre-K, ``0`` is Kindergarten, ``1``-``12`` are grades 1-12, and
``13`` is AP.  Values are strings because the Edubridge ``synthesizeUser``
API emits them as strings after validation by the server's
``GradeInputSchema``.
"""


class GUIDRef(BaseModel):
    """
    Full reference to another entity, including the sourcedId.

    Use this when the API returns the complete reference with sourcedId.
    """

    href: str
    sourced_id: str
    type: str

    model_config = ConfigDict(populate_by_name=True, alias_generator=lambda s: s)


class GUIDRefBase(BaseModel):
    """
    Base reference with minimal fields.

    Some API responses (e.g., user role orgs) only return `href` and `type`
    without the `sourcedId`. Use this type for those contexts.
    """

    href: str
    type: str

    model_config = ConfigDict(populate_by_name=True)


# ═══════════════════════════════════════════════════════════════════════════════
# RESPONSE WRAPPERS
# ═══════════════════════════════════════════════════════════════════════════════

T = TypeVar("T")


class DataResponse[T](BaseModel):
    """Standard EduBridge API response wrapper."""

    data: T
