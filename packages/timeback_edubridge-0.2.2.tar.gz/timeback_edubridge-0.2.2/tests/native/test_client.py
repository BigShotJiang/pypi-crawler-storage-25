"""Native tests for EduBridge client wiring."""

from __future__ import annotations

import pytest

from timeback_common import EdubridgePaths as Paths
from timeback_edubridge import EdubridgeClient


class TestEdubridgeClient:
    def test_client_requires_config(self) -> None:
        with pytest.raises(ValueError, match="Missing required environment variable"):
            EdubridgeClient()

    def test_client_initializes_with_explicit_config(self) -> None:
        client = EdubridgeClient(
            base_url="https://api.example.com",
            auth_url="https://auth.example.com/oauth2/token",
            client_id="test-id",
            client_secret="test-secret",
        )
        assert client._transport.base_url == "https://api.example.com"
        assert client.enrollments is not None
        assert client.users is not None
        assert client.analytics is not None
        assert client.applications is not None
        assert client.subject_tracks is not None
        assert client.learning_reports is not None

    def test_timeout_propagates_to_provider(self) -> None:
        client = EdubridgeClient(
            base_url="https://api.example.com",
            auth_url="https://auth.example.com/oauth2/token",
            client_id="test-id",
            client_secret="test-secret",
            timeout=60.0,
        )
        assert client._provider is not None
        assert client._provider.timeout == 60.0


class TestPaths:
    def test_default_paths(self) -> None:
        assert Paths().base == "/edubridge"

    def test_custom_paths(self) -> None:
        assert Paths(base="/custom/v2").base == "/custom/v2"
