"""Native tests for EduBridge models."""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from timeback_edubridge import (
    Application,
    DefaultClass,
    Demographics,
    DemographicsFlag,
    DemographicsSex,
    Enrollment,
    Grade,
    HighestGradeMastered,
    MapProfile,
    SubjectTrack,
    SubjectTrackUpsertInput,
    TimeSaved,
    User,
)


def test_enrollment_parsing() -> None:
    enrollment = Enrollment.model_validate(
        {
            "id": "enroll-123",
            "role": "student",
            "beginDate": "2025-01-01",
            "endDate": "2025-06-30",
            "course": {"id": "course-456", "title": "Algebra 1", "metadata": {}},
            "school": {"id": "school-789", "name": "Test School"},
        }
    )
    assert enrollment.course.id == "course-456"
    assert enrollment.school.name == "Test School"


def test_default_class_parsing() -> None:
    default_class = DefaultClass.model_validate(
        {
            "id": "class-123",
            "title": "Default Class",
            "subjectCodes": ["MATH"],
            "subjects": ["Mathematics"],
            "periods": ["term-456"],
            "course": {"id": "course-789", "title": "Algebra 1", "metadata": {}},
        }
    )
    assert default_class.subject_codes == ["MATH"]


def test_user_parsing() -> None:
    user = User.model_validate(
        {
            "sourcedId": "user-123",
            "status": "active",
            "dateLastModified": "2025-01-01T00:00:00Z",
            "userIds": [{"type": "email", "identifier": "test@example.com"}],
            "enabledUser": "true",
            "givenName": "John",
            "familyName": "Doe",
            "roles": [],
            "agents": [],
            "userProfiles": [],
            "email": "john@example.com",
        }
    )
    assert user.sourced_id == "user-123"
    assert user.enabled_user == "true"
    assert user.email == "john@example.com"


def test_highest_grade_mastered_parsing() -> None:
    result = HighestGradeMastered.model_validate(
        {
            "studentId": "student-123",
            "subject": "Math",
            "grades": {"ritGrade": 220, "highestGradeOverall": "8"},
        }
    )
    assert result.grades.rit_grade == 220


def test_misc_models_parsing() -> None:
    app = Application.model_validate(
        {"sourcedId": "app-123", "name": "Math", "domain": ["math.io"]}
    )
    track = SubjectTrack.model_validate(
        {
            "id": "track-123",
            "subject": "Math",
            "grade": "9",
            "course": {"sourcedId": "course-456", "title": "Algebra 1"},
        }
    )
    profile = MapProfile.model_validate({"userId": "user-123", "ritScore": 220})
    time_saved = TimeSaved.model_validate({"totalHoursSaved": 5})
    assert app.sourced_id == "app-123"
    assert track.course.sourced_id == "course-456"
    assert profile.rit_score == 220
    assert time_saved.total_hours_saved == 5


def test_subject_track_upsert_input_trims_non_empty_string_fields() -> None:
    model = SubjectTrackUpsertInput.model_validate(
        {
            "subject": "  Math  ",
            "grade": "  9  ",
            "courseId": "  course-123  ",
        }
    )

    assert model.subject == "Math"
    assert model.grade == "9"
    assert model.course_id == "course-123"


def test_subject_track_upsert_input_rejects_whitespace_only_course_id() -> None:
    with pytest.raises(ValidationError):
        SubjectTrackUpsertInput.model_validate(
            {
                "subject": "Math",
                "grade": "9",
                "courseId": "   ",
            }
        )


# ─── User field tests (port of users.type-test.ts) ───────────────────────────


def test_user_full_payload() -> None:
    """Full payload mirrors synthesizeUser output."""
    user = User.model_validate(
        {
            "sourcedId": "user-123",
            "status": "active",
            "dateLastModified": "2025-01-01T00:00:00.000Z",
            "enabledUser": "true",
            "givenName": "Jane",
            "familyName": "Doe",
            "userIds": [],
            "roles": [],
            "agents": [],
            "userProfiles": [],
            "email": "jane.doe@example.com",
            "phone": "+15555550100",
            "sms": "+15555550100",
            "grades": ["5"],
            "identifier": "ext-id-1",
            "pronouns": "she/her",
            "preferredFirstName": "Janie",
            "preferredMiddleName": None,
            "preferredLastName": None,
            "password": None,
            "demographics": {
                "sourcedId": "user-123",
                "status": "active",
                "dateLastModified": "2025-01-01T00:00:00.000Z",
                "birthDate": "2010-06-15",
                "sex": "female",
                "americanIndianOrAlaskaNative": "false",
                "asian": "false",
                "blackOrAfricanAmerican": "false",
                "nativeHawaiianOrOtherPacificIslander": "false",
                "white": "true",
                "demographicRaceTwoOrMoreRaces": "false",
                "hispanicOrLatinoEthnicity": "false",
                "countryOfBirthCode": "US",
                "stateOfBirthAbbreviation": "CA",
                "cityOfBirth": "San Francisco",
                "publicSchoolResidenceStatus": None,
            },
        }
    )
    assert user.email == "jane.doe@example.com"
    assert user.phone == "+15555550100"
    assert user.sms == "+15555550100"
    assert user.grades == ["5"]
    assert user.identifier == "ext-id-1"
    assert user.pronouns == "she/her"
    assert user.preferred_first_name == "Janie"
    assert user.preferred_middle_name is None
    assert user.preferred_last_name is None
    assert user.password is None
    assert user.demographics is not None
    assert user.demographics.sourced_id == "user-123"
    assert user.demographics.sex == "female"
    assert user.demographics.white == "true"
    assert user.demographics.city_of_birth == "San Francisco"


def test_user_nullable_optional_fields() -> None:
    """Nullable optional fields accept None."""
    user = User.model_validate(
        {
            "sourcedId": "user-123",
            "status": "active",
            "dateLastModified": "2025-01-01T00:00:00.000Z",
            "enabledUser": "true",
            "givenName": "Jane",
            "familyName": "Doe",
            "userIds": [],
            "roles": [],
            "agents": [],
            "userProfiles": [],
            "email": "jane.doe@example.com",
            "phone": None,
            "sms": None,
            "identifier": None,
            "pronouns": None,
            "preferredFirstName": None,
            "preferredMiddleName": None,
            "preferredLastName": None,
            "password": None,
            "demographics": None,
        }
    )
    assert user.phone is None
    assert user.sms is None
    assert user.demographics is None


def test_user_without_demographics() -> None:
    """Omitting demographics entirely is valid — non-student roles usually have none."""
    user = User.model_validate(
        {
            "sourcedId": "teacher-1",
            "status": "active",
            "dateLastModified": "2025-01-01T00:00:00.000Z",
            "enabledUser": "true",
            "givenName": "Taylor",
            "familyName": "Teacher",
            "userIds": [],
            "roles": [],
            "agents": [],
            "userProfiles": [],
            "email": "taylor@example.com",
        }
    )
    assert user.demographics is None
    assert user.phone is None
    assert user.grades is None


def test_user_requires_email() -> None:
    """email is required (server schema: z.string().email() with no .optional())."""
    with pytest.raises(ValidationError):
        User.model_validate(
            {
                "sourcedId": "user-123",
                "status": "active",
                "dateLastModified": "2025-01-01T00:00:00.000Z",
                "enabledUser": "true",
                "givenName": "John",
                "familyName": "Doe",
                "userIds": [],
                "roles": [],
                "agents": [],
                "userProfiles": [],
                # email intentionally omitted
            }
        )


def test_demographics_sex_values() -> None:
    """DemographicsSex accepts the server's GenderSchema values."""
    valid_values: list[DemographicsSex] = ["male", "female", "other", "unspecified"]
    for val in valid_values:
        assert val in ("male", "female", "other", "unspecified")


def test_demographics_flag_values() -> None:
    """DemographicsFlag is a stringified boolean."""
    valid_flags: list[DemographicsFlag] = ["true", "false"]
    for flag in valid_flags:
        assert flag in ("true", "false")


def test_grade_values() -> None:
    """Grade type covers -1 (Pre-K) through 13 (AP)."""
    valid_grades: list[Grade] = [
        "-1",
        "0",
        "1",
        "2",
        "3",
        "4",
        "5",
        "6",
        "7",
        "8",
        "9",
        "10",
        "11",
        "12",
        "13",
    ]
    assert len(valid_grades) == 15


def test_demographics_parsing() -> None:
    """Demographics model parses a full server payload."""
    demo = Demographics.model_validate(
        {
            "sourcedId": "user-123",
            "status": "active",
            "dateLastModified": "2025-01-01T00:00:00.000Z",
            "birthDate": "2010-06-15",
            "sex": "female",
            "americanIndianOrAlaskaNative": "false",
            "asian": "false",
            "blackOrAfricanAmerican": "false",
            "nativeHawaiianOrOtherPacificIslander": "false",
            "white": "true",
            "demographicRaceTwoOrMoreRaces": "false",
            "hispanicOrLatinoEthnicity": "false",
            "countryOfBirthCode": "US",
            "stateOfBirthAbbreviation": "CA",
            "cityOfBirth": "San Francisco",
        }
    )
    assert demo.sourced_id == "user-123"
    assert demo.birth_date == "2010-06-15"
    assert demo.sex == "female"
    assert demo.white == "true"
    assert demo.asian == "false"
    assert demo.country_of_birth_code == "US"
    assert demo.city_of_birth == "San Francisco"
