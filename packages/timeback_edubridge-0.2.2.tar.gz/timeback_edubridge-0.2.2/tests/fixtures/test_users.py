"""Fixture-driven tests for EduBridge users resource."""

from __future__ import annotations

from test_support.fixtures import fixtures_dir, make_resource_fixture_test
from timeback_edubridge.lib.testing import create_recording_transport
from timeback_edubridge.resources.users import UsersResource

FIXTURES_DIR = fixtures_dir("edubridge", "users")


def _setup(
    fail_request: dict[str, object] | None, transport_config: dict[str, object] | None
) -> dict[str, object]:
    transport = create_recording_transport(fail_request, transport_config)
    return {"resource": UsersResource(transport), "calls": transport.calls}


test_edubridge_users_fixtures = make_resource_fixture_test(
    name="edubridge > users",
    fixtures_dir=FIXTURES_DIR,
    setup=_setup,
    method_configs={"list": {"options_arg_index": 0}},
)
