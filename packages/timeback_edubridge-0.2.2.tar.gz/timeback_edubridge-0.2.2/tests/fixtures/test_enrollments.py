"""Fixture-driven tests for EduBridge enrollments resource."""

from __future__ import annotations

from test_support.fixtures import fixtures_dir, make_resource_fixture_test
from timeback_edubridge.lib.testing import create_recording_transport
from timeback_edubridge.resources.enrollments import EnrollmentsResource

FIXTURES_DIR = fixtures_dir("edubridge", "enrollments")


def _setup(
    fail_request: dict[str, object] | None, transport_config: dict[str, object] | None
) -> dict[str, object]:
    transport = create_recording_transport(fail_request, transport_config)
    return {"resource": EnrollmentsResource(transport), "calls": transport.calls}


test_edubridge_enrollments_fixtures = make_resource_fixture_test(
    name="edubridge > enrollments",
    fixtures_dir=FIXTURES_DIR,
    setup=_setup,
    method_configs={"list": {"options_arg_index": 0}},
)
