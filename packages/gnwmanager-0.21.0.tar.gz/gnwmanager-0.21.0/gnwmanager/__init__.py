# Don't manually change, let poetry-dynamic-versioning handle it.
__version__ = "0.21.0"

__all__ = []

from gnwmanager.gnw import GnW
