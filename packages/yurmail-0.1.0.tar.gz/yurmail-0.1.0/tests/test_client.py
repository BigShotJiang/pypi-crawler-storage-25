"""
tests/test_client.py
"""

import base64
import pytest
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

from YurMail import (
    MailAddress,
    Message,
    Draft,
    UserProfile,
    GraphAPIError,
    GraphMailClient,
    attachment_from_bytes,
)
from YurMail.mail.client import _encode_attachment, _normalize_attachment


# ══════════════════════════════════════════════════════════════════════════════
# Helpers de mocking HTTP
# ══════════════════════════════════════════════════════════════════════════════

def make_mock_response(status: int, json_data: dict, ok: bool = True, content_type: str = "application/json"):
    resp = AsyncMock()
    resp.status = status
    resp.ok = ok
    resp.json = AsyncMock(return_value=json_data)
    resp.content_type = content_type
    return resp


def make_mock_session(response):
    """
    Construye un mock de aiohttp.ClientSession con el patrón correcto
    para context managers anidados: `async with session.get(...) as resp`.
    """
    session = MagicMock()
    session.__aenter__ = AsyncMock(return_value=session)
    session.__aexit__ = AsyncMock(return_value=False)
    for method in ("get", "post", "patch", "delete"):
        getattr(session, method).return_value.__aenter__ = AsyncMock(return_value=response)
        getattr(session, method).return_value.__aexit__ = AsyncMock(return_value=False)
    return session


# ══════════════════════════════════════════════════════════════════════════════
# MailAddress
# ══════════════════════════════════════════════════════════════════════════════

class TestMailAddress:

    def test_from_graph_parses_correctly(self):
        data = {"emailAddress": {"name": "Ana García", "address": "ana@empresa.com"}}
        addr = MailAddress.from_graph(data)
        assert addr.name == "Ana García"
        assert addr.address == "ana@empresa.com"

    def test_from_graph_empty_data(self):
        addr = MailAddress.from_graph({})
        assert addr.name == ""
        assert addr.address == ""

    def test_from_graph_missing_name(self):
        addr = MailAddress.from_graph({"emailAddress": {"address": "test@test.com"}})
        assert addr.name == ""
        assert addr.address == "test@test.com"

    def test_from_graph_missing_address(self):
        addr = MailAddress.from_graph({"emailAddress": {"name": "Solo Nombre"}})
        assert addr.name == "Solo Nombre"
        assert addr.address == ""


# ══════════════════════════════════════════════════════════════════════════════
# Message
# ══════════════════════════════════════════════════════════════════════════════

class TestMessage:

    def test_from_graph_parses_all_fields(self, graph_message_payload):
        msg = Message.from_graph(graph_message_payload)
        assert msg.id == "msg-001"
        assert msg.subject == "Reunión mañana"
        assert msg.sender.name == "Carlos"
        assert msg.sender.address == "carlos@empresa.com"
        assert len(msg.to_recipients) == 1
        assert msg.to_recipients[0].address == "ana@empresa.com"
        assert msg.received_at == "2024-05-01T10:00:00Z"
        assert msg.is_read is False
        assert msg.body_content == "<p>Hola Ana</p>"
        assert msg.body_type == "html"
        assert msg.conversation_id == "conv-001"

    def test_from_graph_defaults_on_empty(self):
        msg = Message.from_graph({})
        assert msg.id == ""
        assert msg.subject == "(sin asunto)"
        assert msg.is_read is False

    def test_from_graph_multiple_recipients(self, graph_message_payload):
        graph_message_payload["toRecipients"].append(
            {"emailAddress": {"name": "Pedro", "address": "pedro@empresa.com"}}
        )
        msg = Message.from_graph(graph_message_payload)
        assert len(msg.to_recipients) == 2


# ══════════════════════════════════════════════════════════════════════════════
# Draft
# ══════════════════════════════════════════════════════════════════════════════

class TestDraft:

    def test_from_graph_parses_correctly(self, graph_draft_payload):
        draft = Draft.from_graph(graph_draft_payload)
        assert draft.id == "draft-001"
        assert draft.subject == "Borrador de prueba"
        assert draft.body_content == "<p>Hola Luis</p>"
        assert draft.body_type == "html"
        assert draft.created_at == "2024-05-01T09:00:00Z"
        assert draft.to_recipients[0].address == "luis@empresa.com"

    def test_from_graph_defaults_on_empty(self):
        draft = Draft.from_graph({})
        assert draft.id == ""
        assert draft.subject == "(sin asunto)"


# ══════════════════════════════════════════════════════════════════════════════
# UserProfile
# ══════════════════════════════════════════════════════════════════════════════

class TestUserProfile:

    def test_from_graph_parses_correctly(self, graph_user_payload):
        user = UserProfile.from_graph(graph_user_payload)
        assert user.id == "user-abc-123"
        assert user.display_name == "José Luis"
        assert user.mail == "jose@empresa.com"
        assert user.user_principal_name == "jose@empresa.onmicrosoft.com"

    def test_from_graph_defaults_on_empty(self):
        user = UserProfile.from_graph({})
        assert user.id == ""
        assert user.display_name == ""


# ══════════════════════════════════════════════════════════════════════════════
# GraphAPIError
# ══════════════════════════════════════════════════════════════════════════════

class TestGraphAPIError:

    def test_stores_attributes(self):
        err = GraphAPIError(401, "Unauthorized", "Token expired")
        assert err.status == 401
        assert err.code == "Unauthorized"

    def test_str_representation(self):
        err = GraphAPIError(403, "Forbidden", "Access denied")
        assert "403" in str(err)
        assert "Forbidden" in str(err)

    def test_is_exception(self):
        assert isinstance(GraphAPIError(500, "Err", "msg"), Exception)

    def test_can_be_raised_and_caught(self):
        with pytest.raises(GraphAPIError) as exc_info:
            raise GraphAPIError(404, "NotFound", "Resource missing")
        assert exc_info.value.status == 404


# ══════════════════════════════════════════════════════════════════════════════
# GraphMailClient
# ══════════════════════════════════════════════════════════════════════════════

@pytest.fixture
def client():
    return GraphMailClient("fake_access_token")


class TestGraphMailClientInit:

    def test_sets_authorization_header(self):
        c = GraphMailClient("my_token")
        assert c._headers["Authorization"] == "Bearer my_token"

    def test_sets_content_type_header(self):
        c = GraphMailClient("my_token")
        assert c._headers["Content-Type"] == "application/json"


class TestGetMe:

    @pytest.mark.asyncio
    async def test_returns_user_profile(self, client, graph_user_payload):
        resp = make_mock_response(200, graph_user_payload)
        with patch("aiohttp.ClientSession", return_value=make_mock_session(resp)):
            user = await client.get_me()
        assert isinstance(user, UserProfile)
        assert user.id == graph_user_payload["id"]

    @pytest.mark.asyncio
    async def test_raises_graph_error_on_failure(self, client):
        error_payload = {"error": {"code": "Unauthorized", "message": "Token expired"}}
        resp = make_mock_response(401, error_payload, ok=False)
        with patch("aiohttp.ClientSession", return_value=make_mock_session(resp)):
            with pytest.raises(GraphAPIError) as exc_info:
                await client.get_me()
        assert exc_info.value.status == 401


class TestSendMail:

    @pytest.mark.asyncio
    async def test_send_mail_success(self, client):
        resp = make_mock_response(202, {})
        resp.status = 202
        with patch("aiohttp.ClientSession", return_value=make_mock_session(resp)):
            result = await client.send_mail(to=["a@b.com"], subject="S", body="<p>B</p>")
        assert result is None

    @pytest.mark.asyncio
    async def test_send_mail_builds_correct_payload(self, client):
        resp = make_mock_response(202, {})
        resp.status = 202
        session = make_mock_session(resp)
        with patch("aiohttp.ClientSession", return_value=session):
            await client.send_mail(
                to=["a@b.com", "c@d.com"],
                subject="Asunto",
                body="Cuerpo",
                cc=["cc@b.com"],
            )
        payload = session.post.call_args[1]["json"]
        assert payload["message"]["subject"] == "Asunto"
        assert len(payload["message"]["toRecipients"]) == 2
        assert len(payload["message"]["ccRecipients"]) == 1

    @pytest.mark.asyncio
    async def test_send_mail_without_cc_bcc(self, client):
        resp = make_mock_response(202, {})
        resp.status = 202
        session = make_mock_session(resp)
        with patch("aiohttp.ClientSession", return_value=session):
            await client.send_mail(to=["a@b.com"], subject="S", body="B")
        payload = session.post.call_args[1]["json"]
        assert "ccRecipients" not in payload["message"]
        assert "bccRecipients" not in payload["message"]

    @pytest.mark.asyncio
    async def test_send_mail_raises_on_error(self, client):
        error_payload = {"error": {"code": "MailboxNotFound", "message": "Not found"}}
        resp = make_mock_response(404, error_payload, ok=False)
        with patch("aiohttp.ClientSession", return_value=make_mock_session(resp)):
            with pytest.raises(GraphAPIError) as exc_info:
                await client.send_mail(to=["x@y.com"], subject="S", body="B")
        assert exc_info.value.status == 404


class TestCreateDraft:

    @pytest.mark.asyncio
    async def test_create_draft_returns_draft(self, client, graph_draft_payload):
        resp = make_mock_response(201, graph_draft_payload)
        with patch("aiohttp.ClientSession", return_value=make_mock_session(resp)):
            draft = await client.create_draft(
                to=["luis@empresa.com"], subject="Borrador de prueba", body="<p>Hola Luis</p>"
            )
        assert isinstance(draft, Draft)
        assert draft.id == "draft-001"

    @pytest.mark.asyncio
    async def test_create_draft_posts_to_messages_endpoint(self, client, graph_draft_payload):
        resp = make_mock_response(201, graph_draft_payload)
        session = make_mock_session(resp)
        with patch("aiohttp.ClientSession", return_value=session):
            await client.create_draft(to=["a@b.com"], subject="S", body="B")
        assert "/me/messages" in session.post.call_args[0][0]


class TestMarkAsRead:

    @pytest.mark.asyncio
    async def test_mark_as_read(self, client):
        resp = make_mock_response(200, {}, content_type="application/json")
        session = make_mock_session(resp)
        with patch("aiohttp.ClientSession", return_value=session):
            await client.mark_as_read("msg-001", read=True)
        assert session.patch.call_args[1]["json"]["isRead"] is True

    @pytest.mark.asyncio
    async def test_mark_as_unread(self, client):
        resp = make_mock_response(200, {}, content_type="application/json")
        session = make_mock_session(resp)
        with patch("aiohttp.ClientSession", return_value=session):
            await client.mark_as_read("msg-001", read=False)
        assert session.patch.call_args[1]["json"]["isRead"] is False


class TestMoveToTrash:

    @pytest.mark.asyncio
    async def test_moves_to_deleted_items(self, client):
        resp = make_mock_response(200, {})
        resp.status = 200
        session = make_mock_session(resp)
        with patch("aiohttp.ClientSession", return_value=session):
            await client.move_to_trash("msg-001")
        assert session.post.call_args[1]["json"]["destinationId"] == "deleteditems"


# ══════════════════════════════════════════════════════════════════════════════
# Helpers de adjuntos
# ══════════════════════════════════════════════════════════════════════════════

class TestEncodeAttachment:

    def test_encodes_file_to_base64(self, tmp_path):
        content = b"contenido de prueba"
        f = tmp_path / "doc.txt"
        f.write_bytes(content)
        result = _encode_attachment(f)
        assert base64.b64decode(result["contentBytes"]) == content

    def test_includes_filename(self, tmp_path):
        f = tmp_path / "reporte.pdf"
        f.write_bytes(b"%PDF-1.4")
        assert _encode_attachment(f)["name"] == "reporte.pdf"

    def test_raises_if_file_not_found(self, tmp_path):
        with pytest.raises(FileNotFoundError):
            _encode_attachment(tmp_path / "inexistente.txt")

    def test_includes_odata_type(self, tmp_path):
        f = tmp_path / "a.txt"
        f.write_bytes(b"hola")
        assert _encode_attachment(f)["@odata.type"] == "#microsoft.graph.fileAttachment"


class TestNormalizeAttachment:

    def test_passes_dict_through(self):
        att = {"@odata.type": "#microsoft.graph.fileAttachment", "name": "file.pdf"}
        assert _normalize_attachment(att) is att

    def test_converts_path_object(self, tmp_path):
        f = tmp_path / "doc.txt"
        f.write_bytes(b"hola")
        assert _normalize_attachment(f)["name"] == "doc.txt"

    def test_converts_string_path(self, tmp_path):
        f = tmp_path / "doc.txt"
        f.write_bytes(b"hola")
        assert _normalize_attachment(str(f))["name"] == "doc.txt"

    def test_raises_on_invalid_type(self):
        with pytest.raises(TypeError):
            _normalize_attachment(12345)  # type: ignore


class TestAttachmentFromBytes:

    def test_creates_valid_attachment(self):
        data = b"PDF content here"
        att = attachment_from_bytes(data, "report.pdf", "application/pdf")
        assert att["name"] == "report.pdf"
        assert att["contentType"] == "application/pdf"
        assert base64.b64decode(att["contentBytes"]) == data

    def test_guesses_mime_type_from_filename(self):
        att = attachment_from_bytes(b"data", "image.png")
        assert "png" in att["contentType"] or "image" in att["contentType"]

    def test_fallback_mime_type_for_unknown_extension(self):
        att = attachment_from_bytes(b"data", "file.xyz123")
        assert att["contentType"] == "application/octet-stream"

    def test_odata_type_is_set(self):
        att = attachment_from_bytes(b"data", "file.txt")
        assert att["@odata.type"] == "#microsoft.graph.fileAttachment"

    def test_empty_bytes(self):
        att = attachment_from_bytes(b"", "empty.txt")
        assert base64.b64decode(att["contentBytes"]) == b""