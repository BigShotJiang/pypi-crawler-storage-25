"""
tests/test_authentication.py
"""

import pytest
import base64
import hashlib
import re
from unittest.mock import AsyncMock, MagicMock, patch
from urllib.parse import urlparse, parse_qs

from YurMail import GraphAuthManager, OAuthCallbackResult


# ══════════════════════════════════════════════════════════════════════════════
# Helper: mock de aiohttp para POST
# ══════════════════════════════════════════════════════════════════════════════

def make_aiohttp_post_mock(json_data: dict):
    """Construye un mock de aiohttp.ClientSession para llamadas POST."""
    mock_response = AsyncMock()
    mock_response.raise_for_status = MagicMock()
    mock_response.json = AsyncMock(return_value=json_data)

    mock_session = MagicMock()
    mock_session.__aenter__ = AsyncMock(return_value=mock_session)
    mock_session.__aexit__ = AsyncMock(return_value=False)
    mock_session.post.return_value.__aenter__ = AsyncMock(return_value=mock_response)
    mock_session.post.return_value.__aexit__ = AsyncMock(return_value=False)
    return mock_session


# ══════════════════════════════════════════════════════════════════════════════
# Fixture local
# ══════════════════════════════════════════════════════════════════════════════

@pytest.fixture
def manager(auth_config):
    return GraphAuthManager(**auth_config)


# ══════════════════════════════════════════════════════════════════════════════
# __init__ — validación del redirect_uri
# ══════════════════════════════════════════════════════════════════════════════

class TestInitValidation:

    def test_valid_config_creates_instance(self, auth_config):
        mgr = GraphAuthManager(**auth_config)
        assert mgr.client_id == auth_config["client_id"]
        assert mgr.tenant == auth_config["tenant"]

    def test_redirect_uri_sets_internal_attributes(self, manager):
        assert manager._redirect_host == "localhost"
        assert manager._redirect_port == 8765
        assert manager._redirect_path == "/callback"

    def test_invalid_scheme_raises(self, auth_config):
        auth_config["redirect_uri"] = "ftp://localhost:8765/callback"
        with pytest.raises(ValueError, match="http"):
            GraphAuthManager(**auth_config)

    def test_missing_port_raises(self, auth_config):
        auth_config["redirect_uri"] = "http://localhost/callback"
        with pytest.raises(ValueError, match="port"):
            GraphAuthManager(**auth_config)

    def test_https_scheme_is_accepted(self, auth_config):
        auth_config["redirect_uri"] = "https://localhost:9000/cb"
        mgr = GraphAuthManager(**auth_config)
        assert mgr._redirect_port == 9000

    def test_endpoints_use_tenant(self, auth_config):
        auth_config["tenant"] = "mytenant"
        mgr = GraphAuthManager(**auth_config)
        assert "mytenant" in mgr._authorize_endpoint
        assert "mytenant" in mgr._token_endpoint


# ══════════════════════════════════════════════════════════════════════════════
# Métodos estáticos criptográficos
# ══════════════════════════════════════════════════════════════════════════════

class TestCryptoHelpers:

    def test_generate_state_returns_string(self):
        assert isinstance(GraphAuthManager._generate_state(), str)

    def test_generate_state_is_url_safe(self):
        assert re.match(r'^[A-Za-z0-9\-_]+$', GraphAuthManager._generate_state())

    def test_generate_state_minimum_length(self):
        assert len(GraphAuthManager._generate_state()) >= 32

    def test_generate_state_is_random(self):
        states = {GraphAuthManager._generate_state() for _ in range(10)}
        assert len(states) == 10

    def test_generate_code_verifier_max_length(self):
        assert len(GraphAuthManager._generate_code_verifier()) <= 128

    def test_generate_code_verifier_min_length(self):
        assert len(GraphAuthManager._generate_code_verifier()) >= 43

    def test_generate_code_verifier_is_url_safe(self):
        assert re.match(r'^[A-Za-z0-9\-_]+$', GraphAuthManager._generate_code_verifier())

    def test_generate_code_challenge_is_s256(self):
        verifier = "test_verifier_abc123"
        challenge = GraphAuthManager._generate_code_challenge(verifier)
        expected_digest = hashlib.sha256(verifier.encode("ascii")).digest()
        expected = base64.urlsafe_b64encode(expected_digest).decode("ascii").rstrip("=")
        assert challenge == expected

    def test_generate_code_challenge_no_padding(self):
        verifier = GraphAuthManager._generate_code_verifier()
        assert "=" not in GraphAuthManager._generate_code_challenge(verifier)

    def test_challenge_differs_from_verifier(self):
        verifier = GraphAuthManager._generate_code_verifier()
        assert verifier != GraphAuthManager._generate_code_challenge(verifier)


# ══════════════════════════════════════════════════════════════════════════════
# build_authorization_url
# ══════════════════════════════════════════════════════════════════════════════

class TestBuildAuthorizationUrl:

    def test_returns_string(self, manager):
        assert isinstance(manager.build_authorization_url("s"), str)

    def test_url_starts_with_authorize_endpoint(self, manager):
        url = manager.build_authorization_url("s")
        assert url.startswith(manager._authorize_endpoint)

    def test_url_contains_required_params(self, manager):
        url = manager.build_authorization_url("my-state")
        qs = parse_qs(urlparse(url).query)
        assert qs["client_id"] == [manager.client_id]
        assert qs["response_type"] == ["code"]
        assert qs["redirect_uri"] == [manager.redirect_uri]
        assert qs["state"] == ["my-state"]
        assert qs["code_challenge_method"] == ["S256"]

    def test_url_contains_scopes(self, manager):
        url = manager.build_authorization_url("s")
        assert "offline_access" in parse_qs(urlparse(url).query)["scope"][0]

    def test_stores_state_internally(self, manager):
        manager.build_authorization_url("stored-state")
        assert manager._last_state == "stored-state"

    def test_stores_code_verifier_internally(self, manager):
        manager.build_authorization_url("s")
        assert manager._last_code_verifier is not None

    def test_challenge_in_url_matches_stored_verifier(self, manager):
        url = manager.build_authorization_url("s")
        challenge_in_url = parse_qs(urlparse(url).query)["code_challenge"][0]
        expected = GraphAuthManager._generate_code_challenge(manager._last_code_verifier)
        assert challenge_in_url == expected

    def test_successive_calls_update_state(self, manager):
        manager.build_authorization_url("first")
        manager.build_authorization_url("second")
        assert manager._last_state == "second"


# ══════════════════════════════════════════════════════════════════════════════
# exchange_code_for_token
# ══════════════════════════════════════════════════════════════════════════════

class TestExchangeCodeForToken:

    @pytest.mark.asyncio
    async def test_raises_without_code_verifier(self, manager):
        with pytest.raises(RuntimeError, match="code verifier"):
            await manager.exchange_code_for_token("auth-code-xyz")

    @pytest.mark.asyncio
    async def test_returns_token_data(self, manager, sample_token_response):
        manager._last_code_verifier = "fake_verifier"
        mock_session = make_aiohttp_post_mock(sample_token_response)

        with patch("aiohttp.ClientSession", return_value=mock_session):
            result = await manager.exchange_code_for_token("real-code")

        assert result["access_token"] == sample_token_response["access_token"]

    @pytest.mark.asyncio
    async def test_stores_last_token_response(self, manager, sample_token_response):
        manager._last_code_verifier = "fake_verifier"
        mock_session = make_aiohttp_post_mock(sample_token_response)

        with patch("aiohttp.ClientSession", return_value=mock_session):
            await manager.exchange_code_for_token("real-code")

        assert manager._last_token_response == sample_token_response

    @pytest.mark.asyncio
    async def test_post_sent_to_token_endpoint(self, manager, sample_token_response):
        manager._last_code_verifier = "fake_verifier"
        mock_session = make_aiohttp_post_mock(sample_token_response)

        with patch("aiohttp.ClientSession", return_value=mock_session):
            await manager.exchange_code_for_token("code-abc")

        mock_session.post.assert_called_once()
        assert manager._token_endpoint in mock_session.post.call_args[0]


# ══════════════════════════════════════════════════════════════════════════════
# refresh_access_token
# ══════════════════════════════════════════════════════════════════════════════

class TestRefreshAccessToken:

    @pytest.mark.asyncio
    async def test_returns_new_token_data(self, manager, sample_token_response):
        new_token = {**sample_token_response, "access_token": "new_access_token"}
        mock_session = make_aiohttp_post_mock(new_token)

        with patch("aiohttp.ClientSession", return_value=mock_session):
            result = await manager.refresh_access_token("old_refresh_token")

        assert result["access_token"] == "new_access_token"

    @pytest.mark.asyncio
    async def test_uses_refresh_grant_type(self, manager, sample_token_response):
        mock_session = make_aiohttp_post_mock(sample_token_response)

        with patch("aiohttp.ClientSession", return_value=mock_session):
            await manager.refresh_access_token("my_refresh_token")

        call_kwargs = mock_session.post.call_args[1]
        assert call_kwargs["data"]["grant_type"] == "refresh_token"
        assert call_kwargs["data"]["refresh_token"] == "my_refresh_token"


# ══════════════════════════════════════════════════════════════════════════════
# login — timeout y state mismatch
# ══════════════════════════════════════════════════════════════════════════════

class TestLoginFlow:

    @pytest.mark.asyncio
    async def test_login_timeout_raises(self, manager):
        import asyncio

        with patch("webbrowser.open"), \
             patch.object(manager, "build_authorization_url", return_value="http://fake"), \
             patch("aiohttp.web.AppRunner") as MockRunner, \
             patch("aiohttp.web.TCPSite") as MockSite, \
             patch("asyncio.wait_for", side_effect=asyncio.TimeoutError):

            MockRunner.return_value = AsyncMock()
            MockSite.return_value = AsyncMock()

            with pytest.raises(TimeoutError):
                await manager.login()