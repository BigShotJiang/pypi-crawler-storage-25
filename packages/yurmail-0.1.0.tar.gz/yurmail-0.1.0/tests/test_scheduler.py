"""
tests/test_scheduler.py
"""

import pytest
from datetime import datetime, timezone, timedelta
from unittest.mock import AsyncMock, MagicMock, patch

from YurMail import (
    Scheduler,
    InMemoryStore,
    ScheduledEmail,
    ScheduleStatus,
    SchedulerResult,
    TriggerType,
)


# ══════════════════════════════════════════════════════════════════════════════
# Factory
# ══════════════════════════════════════════════════════════════════════════════

def make_email(
    send_at: datetime | None = None,
    subject: str | None = None,
    body: str | None = None,
    status: ScheduleStatus = ScheduleStatus.PENDING,
    save_as_draft: bool = False,
    trigger_type: TriggerType = TriggerType.ONCE,
) -> ScheduledEmail:
    return ScheduledEmail(
        id="",
        purpose="Recordar reunión",
        to=["destino@empresa.com"],
        send_at=send_at or (datetime.now(timezone.utc) - timedelta(minutes=1)),
        recipient_name="Equipo",
        tone="formal",
        language="es",
        subject=subject,
        body=body,
        status=status,
        save_as_draft=save_as_draft,
        trigger_type=trigger_type,
    )


# ══════════════════════════════════════════════════════════════════════════════
# Fixtures
# ══════════════════════════════════════════════════════════════════════════════

@pytest.fixture
def store():
    return InMemoryStore()


@pytest.fixture
def scheduler(mock_mail_client, mock_llm_client, store):
    return Scheduler(
        mail_client=mock_mail_client,
        llm_client=mock_llm_client,
        store=store,
    )


# ══════════════════════════════════════════════════════════════════════════════
# schedule()
# ══════════════════════════════════════════════════════════════════════════════

class TestSchedule:

    def test_schedule_returns_email_with_id(self, scheduler):
        result = scheduler.schedule(make_email())
        assert result.id != ""

    def test_schedule_adds_to_pending(self, scheduler):
        scheduler.schedule(make_email())
        assert len(scheduler.list_pending()) == 1

    def test_schedule_multiple_emails(self, scheduler):
        scheduler.schedule(make_email())
        scheduler.schedule(make_email())
        assert len(scheduler.list_pending()) == 2

    def test_scheduled_email_has_pending_status(self, scheduler):
        result = scheduler.schedule(make_email())
        assert result.status == ScheduleStatus.PENDING


# ══════════════════════════════════════════════════════════════════════════════
# cancel()
# ══════════════════════════════════════════════════════════════════════════════

class TestCancel:

    def test_cancel_pending_returns_true(self, scheduler):
        email = scheduler.schedule(make_email())
        assert scheduler.cancel(email.id) is True

    def test_cancel_sets_cancelled_status(self, scheduler):
        email = scheduler.schedule(make_email())
        scheduler.cancel(email.id)
        assert scheduler.get(email.id).status == ScheduleStatus.CANCELLED

    def test_cancel_removes_from_pending(self, scheduler):
        email = scheduler.schedule(make_email())
        scheduler.cancel(email.id)
        assert len(scheduler.list_pending()) == 0

    def test_cancel_nonexistent_returns_false(self, scheduler):
        assert scheduler.cancel("id-inexistente") is False

    def test_cancel_already_sent_returns_false(self, scheduler, store):
        added = store.add(make_email(status=ScheduleStatus.SENT))
        assert scheduler.cancel(added.id) is False

    def test_cancel_already_failed_returns_false(self, scheduler, store):
        added = store.add(make_email(status=ScheduleStatus.FAILED))
        assert scheduler.cancel(added.id) is False


# ══════════════════════════════════════════════════════════════════════════════
# list_pending / list_sent / list_failed / get
# ══════════════════════════════════════════════════════════════════════════════

class TestListMethods:

    def test_list_pending_only_pending(self, scheduler, store):
        store.add(make_email(status=ScheduleStatus.PENDING))
        store.add(make_email(status=ScheduleStatus.SENT))
        store.add(make_email(status=ScheduleStatus.FAILED))
        assert len(scheduler.list_pending()) == 1

    def test_list_sent_only_sent(self, scheduler, store):
        store.add(make_email(status=ScheduleStatus.SENT))
        store.add(make_email(status=ScheduleStatus.SENT))
        store.add(make_email(status=ScheduleStatus.PENDING))
        assert len(scheduler.list_sent()) == 2

    def test_list_failed_only_failed(self, scheduler, store):
        store.add(make_email(status=ScheduleStatus.FAILED))
        store.add(make_email(status=ScheduleStatus.PENDING))
        assert len(scheduler.list_failed()) == 1

    def test_get_returns_email_by_id(self, scheduler):
        email = scheduler.schedule(make_email())
        assert scheduler.get(email.id).id == email.id

    def test_get_returns_none_for_unknown_id(self, scheduler):
        assert scheduler.get("no-existe") is None


# ══════════════════════════════════════════════════════════════════════════════
# run_once()
# ══════════════════════════════════════════════════════════════════════════════

class TestRunOnce:

    @pytest.mark.asyncio
    async def test_run_once_no_due_emails(self, scheduler):
        scheduler.schedule(make_email(
            send_at=datetime.now(timezone.utc) + timedelta(hours=1)
        ))
        result = await scheduler.run_once()
        assert len(result.sent) == 0

    @pytest.mark.asyncio
    async def test_run_once_sends_due_email(self, scheduler, mock_mail_client):
        scheduler.schedule(make_email(subject="Asunto", body="<p>Cuerpo</p>"))
        result = await scheduler.run_once()
        assert len(result.sent) == 1
        mock_mail_client.send_mail.assert_called_once()

    @pytest.mark.asyncio
    async def test_run_once_marks_email_as_sent(self, scheduler):
        email = scheduler.schedule(make_email(subject="S", body="<p>B</p>"))
        await scheduler.run_once()
        assert scheduler.get(email.id).status == ScheduleStatus.SENT

    @pytest.mark.asyncio
    async def test_run_once_sets_sent_at(self, scheduler):
        email = scheduler.schedule(make_email(subject="S", body="<p>B</p>"))
        await scheduler.run_once()
        assert scheduler.get(email.id).sent_at is not None

    @pytest.mark.asyncio
    async def test_run_once_generates_draft_if_no_subject_body(self, scheduler, mock_llm_client):
        scheduler.schedule(make_email())
        await scheduler.run_once()
        mock_llm_client.generate_draft.assert_called_once()

    @pytest.mark.asyncio
    async def test_run_once_skips_llm_if_draft_exists(self, scheduler, mock_llm_client):
        scheduler.schedule(make_email(subject="Ya listo", body="<p>cuerpo</p>"))
        await scheduler.run_once()
        mock_llm_client.generate_draft.assert_not_called()

    @pytest.mark.asyncio
    async def test_run_once_marks_email_as_failed_on_error(self, scheduler, mock_mail_client):
        mock_mail_client.send_mail.side_effect = Exception("Error de red")
        email = scheduler.schedule(make_email(subject="S", body="<p>B</p>"))
        result = await scheduler.run_once()
        assert len(result.failed) == 1
        updated = scheduler.get(email.id)
        assert updated.status == ScheduleStatus.FAILED
        assert "Error de red" in updated.error


    @pytest.mark.asyncio
    async def test_run_once_returns_skipped_count(self, scheduler):
        scheduler.schedule(make_email(send_at=datetime.now(timezone.utc) + timedelta(hours=2)))
        scheduler.schedule(make_email(send_at=datetime.now(timezone.utc) + timedelta(hours=2)))
        scheduler.schedule(make_email(subject="S", body="<p>B</p>"))
        result = await scheduler.run_once()
        assert result.skipped == 2

    @pytest.mark.asyncio
    async def test_run_once_uses_save_as_draft(self, scheduler, mock_mail_client):
        mock_mail_client.create_draft.return_value = MagicMock(id="draft-xyz")
        scheduler.schedule(make_email(subject="S", body="<p>B</p>", save_as_draft=True))
        await scheduler.run_once()
        mock_mail_client.create_draft.assert_called_once()
        mock_mail_client.send_mail.assert_not_called()

    @pytest.mark.asyncio
    async def test_run_once_does_not_process_future_emails(self, scheduler, mock_mail_client):
        scheduler.schedule(make_email(
            send_at=datetime.now(timezone.utc) + timedelta(days=1),
            subject="S", body="<p>B</p>",
        ))
        await scheduler.run_once()
        mock_mail_client.send_mail.assert_not_called()


# ══════════════════════════════════════════════════════════════════════════════
# _clean_subject()
# ══════════════════════════════════════════════════════════════════════════════

class TestCleanSubject:

    def test_removes_bold_markdown(self):
        assert Scheduler._clean_subject("**Asunto importante**") == "Asunto importante"

    def test_removes_italic_asterisk(self):
        assert Scheduler._clean_subject("*Reunión*") == "Reunión"

    def test_removes_bold_underscore(self):
        assert Scheduler._clean_subject("__Asunto__") == "Asunto"

    def test_removes_italic_underscore(self):
        assert Scheduler._clean_subject("_Recordatorio_") == "Recordatorio"

    def test_removes_inline_code(self):
        assert Scheduler._clean_subject("`código`") == "código"

    def test_strips_whitespace(self):
        assert Scheduler._clean_subject("  Asunto limpio  ") == "Asunto limpio"

    def test_plain_text_unchanged(self):
        subject = "Recordatorio de reunión semanal"
        assert Scheduler._clean_subject(subject) == subject


# ══════════════════════════════════════════════════════════════════════════════
# _looks_like_html()
# ══════════════════════════════════════════════════════════════════════════════

class TestLooksLikeHtml:

    def test_detects_p_tag(self):
        assert Scheduler._looks_like_html("<p>Hola</p>") is True

    def test_detects_div_tag(self):
        assert Scheduler._looks_like_html("<div class='x'>texto</div>") is True

    def test_plain_text_is_not_html(self):
        assert Scheduler._looks_like_html("Hola, esto es texto plano.") is False

    def test_markdown_is_not_html(self):
        assert Scheduler._looks_like_html("# Título\n\nPárrafo.") is False

    def test_empty_string_is_not_html(self):
        assert Scheduler._looks_like_html("") is False

    def test_self_closing_tag_is_html(self):
        assert Scheduler._looks_like_html("Imagen: <img src='x.png' />") is True


# ══════════════════════════════════════════════════════════════════════════════
# _prepare_body_for_send()
# ══════════════════════════════════════════════════════════════════════════════

class TestPrepareBodyForSend:

    def test_html_body_returned_as_is(self, scheduler):
        body = "<p>Hola equipo</p>"
        prepared, body_type = scheduler._prepare_body_for_send(body)
        assert prepared == body
        assert body_type == "HTML"

    def test_plain_text_converted_to_html(self, scheduler):
        prepared, body_type = scheduler._prepare_body_for_send("Hola equipo.")
        assert body_type == "HTML"
        assert "<" in prepared

    def test_body_type_always_html(self, scheduler):
        _, body_type = scheduler._prepare_body_for_send("<b>test</b>")
        assert body_type == "HTML"


# ══════════════════════════════════════════════════════════════════════════════
# Callbacks on_sent / on_failed
# ══════════════════════════════════════════════════════════════════════════════

class TestCallbacks:

    @pytest.mark.asyncio
    async def test_on_sent_called_after_success(self, mock_mail_client, mock_llm_client, store):
        on_sent = AsyncMock()
        scheduler = Scheduler(mock_mail_client, mock_llm_client, store, on_sent=on_sent)
        scheduler.schedule(make_email(subject="S", body="<p>B</p>"))
        await scheduler.run_once()
        on_sent.assert_called_once()

    @pytest.mark.asyncio
    async def test_on_failed_called_after_failure(self, mock_mail_client, mock_llm_client, store):
        mock_mail_client.send_mail.side_effect = Exception("Fallo")
        on_failed = AsyncMock()
        scheduler = Scheduler(mock_mail_client, mock_llm_client, store, on_failed=on_failed)
        scheduler.schedule(make_email(subject="S", body="<p>B</p>"))
        await scheduler.run_once()
        on_failed.assert_called_once()

    @pytest.mark.asyncio
    async def test_sync_callback_is_supported(self, mock_mail_client, mock_llm_client, store):
        on_sent = MagicMock()
        scheduler = Scheduler(mock_mail_client, mock_llm_client, store, on_sent=on_sent)
        scheduler.schedule(make_email(subject="S", body="<p>B</p>"))
        await scheduler.run_once()
        on_sent.assert_called_once()

    @pytest.mark.asyncio
    async def test_failing_callback_does_not_crash(self, mock_mail_client, mock_llm_client, store):
        on_sent = AsyncMock(side_effect=Exception("Error en callback"))
        scheduler = Scheduler(mock_mail_client, mock_llm_client, store, on_sent=on_sent)
        scheduler.schedule(make_email(subject="S", body="<p>B</p>"))
        result = await scheduler.run_once()
        assert len(result.sent) == 1


# ══════════════════════════════════════════════════════════════════════════════
# Recurrencia
# ══════════════════════════════════════════════════════════════════════════════

class TestNextOccurrence:

    @pytest.mark.asyncio
    async def test_once_email_does_not_create_next(self, scheduler):
        scheduler.schedule(make_email(subject="S", body="<p>B</p>", trigger_type=TriggerType.ONCE))
        await scheduler.run_once()
        assert len(scheduler.list_pending()) == 0

    @pytest.mark.asyncio
    async def test_daily_email_creates_next_occurrence(self, mock_mail_client, mock_llm_client):
        store = InMemoryStore()
        scheduler = Scheduler(mock_mail_client, mock_llm_client, store)
        scheduler.schedule(make_email(subject="S", body="<p>B</p>", trigger_type=TriggerType.DAILY))
        await scheduler.run_once()

        pending = scheduler.list_pending()
        assert len(pending) == 1
        assert pending[0].send_at > datetime.now(timezone.utc)
        assert pending[0].subject is None
        assert pending[0].body is None

    @pytest.mark.asyncio
    async def test_weekly_email_creates_next_occurrence(self, mock_mail_client, mock_llm_client):
        store = InMemoryStore()
        scheduler = Scheduler(mock_mail_client, mock_llm_client, store)
        scheduler.schedule(make_email(subject="S", body="<p>B</p>", trigger_type=TriggerType.WEEKLY))
        await scheduler.run_once()

        pending = scheduler.list_pending()
        assert len(pending) == 1
        assert pending[0].send_at > datetime.now(timezone.utc)


# ══════════════════════════════════════════════════════════════════════════════
# Concurrencia
# ══════════════════════════════════════════════════════════════════════════════

class TestConcurrency:

    @pytest.mark.asyncio
    async def test_all_due_emails_processed_with_low_concurrency(
        self, mock_mail_client, mock_llm_client
    ):
        store = InMemoryStore()
        scheduler = Scheduler(mock_mail_client, mock_llm_client, store, concurrency=1)
        for _ in range(5):
            scheduler.schedule(make_email(subject="S", body="<p>B</p>"))
        result = await scheduler.run_once()
        assert len(result.sent) == 5