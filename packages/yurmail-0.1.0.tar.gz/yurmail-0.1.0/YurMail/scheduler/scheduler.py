"""
scheduler/scheduler.py

Orchestrador principal: une Authentication + Mail + LLM para
procesar y enviar correos programados de forma asíncrona.

Flujo por cada correo vencido:
  1. Genera el draft (subject + body) con OpenAIDraftClient
  2. Envía el correo con GraphMailClient
  3. Actualiza el estado en el store
  4. Si es recurrente, crea la siguiente ocurrencia automáticamente

Uso básico:
    from mail_scheduler import GraphAuthManager, GraphMailClient
    from mail_scheduler.LLM import OpenAIDraftClient
    from mail_scheduler.scheduler import Scheduler, InMemoryStore, ScheduledEmail, TriggerType
    from datetime import datetime, timedelta, timezone
    import asyncio

    async def main():
        # Auth
        auth = GraphAuthManager(client_id=..., tenant=..., redirect_uri=..., scopes=[...])
        token_data = await auth.login()
        mail_client = GraphMailClient(token_data["access_token"])

        # LLM
        llm_client = OpenAIDraftClient(api_key="sk-...")

        # Scheduler
        store = InMemoryStore()
        scheduler = Scheduler(mail_client=mail_client, llm_client=llm_client, store=store)

        # Programar un correo
        scheduler.schedule(ScheduledEmail(
            id="",
            purpose="Recordar al equipo la reunión de mañana",
            to=["equipo@empresa.com"],
            send_at=datetime.now(timezone.utc) + timedelta(minutes=5),
            recipient_name="Equipo",
            tone="casual",
            language="es",
        ))

        # Procesar los correos vencidos
        result = await scheduler.run_once()
        print(f"Enviados: {result.sent}, Fallidos: {result.failed}")

    asyncio.run(main())
"""

from __future__ import annotations

import inspect
import asyncio
import logging
from datetime import datetime, timezone
from typing import Callable

from ..LLM.client import OpenAIDraftClient
from ..mail.client import GraphMailClient, GraphAPIError
from .store import AbstractScheduleStore, InMemoryStore
from .types import ScheduledEmail, ScheduleStatus, SchedulerResult
from ..mail.templates import text_to_html

logger = logging.getLogger(__name__)


class Scheduler:
    """
    Orquestador de correos programados.

    Parámetros
    ----------
    mail_client:
        Instancia autenticada de GraphMailClient.
    llm_client:
        Instancia de OpenAIDraftClient para generar drafts.
    store:
        Donde se guardan los correos. Por defecto InMemoryStore.
    concurrency:
        Máximo de correos procesados en paralelo por ciclo.
    on_sent:
        Callback opcional invocado tras un envío exitoso.
        Firma: async def on_sent(email: ScheduledEmail) -> None
    on_failed:
        Callback opcional invocado tras un fallo.
        Firma: async def on_failed(email: ScheduledEmail, error: Exception) -> None
    """

    def __init__(
        self,
        mail_client: GraphMailClient,
        llm_client: OpenAIDraftClient,
        store: AbstractScheduleStore | None = None,
        concurrency: int = 5,
        on_sent: Callable | None = None,
        on_failed: Callable | None = None,
    ) -> None:
        self._mail = mail_client
        self._llm = llm_client
        self._store = store or InMemoryStore()
        self._concurrency = concurrency
        self._on_sent = on_sent
        self._on_failed = on_failed

    # ── API pública ───────────────────────────────────────────────────────────

    def schedule(self, email: ScheduledEmail) -> ScheduledEmail:
        """
        Agrega un correo al store y lo retorna con su ID asignado.
        """
        return self._store.add(email)

    def cancel(self, email_id: str) -> bool:
        """
        Cancela un correo pendiente. Devuelve True si se pudo cancelar.
        """
        email = self._store.get(email_id)
        if email is None:
            return False
        if email.status != ScheduleStatus.PENDING:
            return False
        email.status = ScheduleStatus.CANCELLED
        self._store.update(email)
        return True

    def list_pending(self) -> list[ScheduledEmail]:
        return self._store.filter(lambda e: e.status == ScheduleStatus.PENDING)

    def list_sent(self) -> list[ScheduledEmail]:
        return self._store.filter(lambda e: e.status == ScheduleStatus.SENT)

    def list_failed(self) -> list[ScheduledEmail]:
        return self._store.filter(lambda e: e.status == ScheduleStatus.FAILED)

    def get(self, email_id: str) -> ScheduledEmail | None:
        return self._store.get(email_id)

    # ── Ciclo de procesamiento ────────────────────────────────────────────────

    async def run_once(self, now: datetime | None = None) -> SchedulerResult:
        """
        Procesa todos los correos vencidos en este instante.

        - Genera el draft con el LLM si aún no tiene subject/body.
        - Envía el correo con el cliente de Graph.
        - Actualiza el estado en el store.
        - Crea la siguiente ocurrencia si es recurrente.

        Devuelve un SchedulerResult con el resumen del ciclo.
        """
        now = now or datetime.now(timezone.utc)
        due = self._store.pending(now)  # pending() también normaliza a UTC-aware

        if not due:
            logger.debug("Scheduler.run_once: no hay correos vencidos.")
            return SchedulerResult(skipped=0)

        logger.info(f"Scheduler.run_once: {len(due)} correo(s) vencido(s).")

        sem = asyncio.Semaphore(self._concurrency)
        result = SchedulerResult(skipped=len(self._list_all_pending()) - len(due))

        async def process(email: ScheduledEmail) -> None:
            async with sem:
                await self._process_one(email, result)

        await asyncio.gather(*(process(e) for e in due))
        return result

    async def run_loop(self, interval_seconds: float = 60.0) -> None:
        """
        Bucle infinito que llama a run_once() cada `interval_seconds`.
        Útil para correr el scheduler como un servicio en background.

        Ejemplo:
            asyncio.create_task(scheduler.run_loop(interval_seconds=30))
        """
        logger.info(f"Scheduler arrancando — ciclo cada {interval_seconds}s.")
        while True:
            try:
                result = await self.run_once()
                if result.total_processed:
                    logger.info(
                        f"Ciclo completado — enviados: {len(result.sent)}, "
                        f"fallidos: {len(result.failed)}"
                    )
            except Exception as exc:
                logger.error(f"Error inesperado en el ciclo del scheduler: {exc}")
            await asyncio.sleep(interval_seconds)

    # ── Procesamiento individual ──────────────────────────────────────────────

    async def _process_one(
        self,
        email: ScheduledEmail,
        result: SchedulerResult,
    ) -> None:
        """
        Maneja el ciclo completo de un correo: generar → enviar → actualizar.
        """
        # Marcar como 'en proceso' para evitar envíos dobles
        email.status = ScheduleStatus.SENDING
        self._store.update(email)

        try:
            await self._generate_draft_if_needed(email)
            await self._send(email)

            email.status = ScheduleStatus.SENT
            email.sent_at = datetime.now(timezone.utc)
            self._store.update(email)
            result.sent.append(email.id)

            logger.info(f"Correo enviado [{email.id}]: {email.subject!r} → {email.to}")

            # Recurrencia
            self._schedule_next_occurrence(email)

            if self._on_sent:
                await self._safe_callback(self._on_sent, email)

        except Exception as exc:
            email.status = ScheduleStatus.FAILED
            email.error = str(exc)
            self._store.update(email)
            result.failed.append(email.id)

            logger.error(f"✗ Correo fallido [{email.id}]: {exc}")

            if self._on_failed:
                await self._safe_callback(self._on_failed, email, exc)

    async def _generate_draft_if_needed(self, email: ScheduledEmail) -> None:
        """
        Si el correo no tiene subject y body ya definidos, los genera con el LLM.
        Esto permite que los drafts se generen justo antes del envío,
        con información lo más actualizada posible.
        """
        if email.subject and email.body:
            logger.debug(f"[{email.id}] Draft ya provisto, se omite la generación LLM.")
            return

        logger.debug(f"[{email.id}] Generando draft con LLM...")
        draft = await self._llm.generate_draft(
            purpose=email.purpose,
            recipient_name=email.recipient_name,
            tone=email.tone,
            context=email.context,
            language=email.language,
        )

        email.subject = self._clean_subject(draft.subject)
        email.body = draft.body
        self._store.update(email)

    @staticmethod
    def _looks_like_html(text: str) -> bool:
        """
        Heurística simple: si parece contener etiquetas HTML, lo tratamos como HTML.
        """
        import re
        return bool(re.search(r"<[a-zA-Z][^>]*>", text))

    @staticmethod
    def _clean_subject(subject: str) -> str:
        import re

        subject = subject.strip()
        subject = re.sub(r"\*\*(.*?)\*\*", r"\1", subject)
        subject = re.sub(r"\*(.*?)\*", r"\1", subject)
        subject = re.sub(r"__(.*?)__", r"\1", subject)
        subject = re.sub(r"_(.*?)_", r"\1", subject)
        subject = re.sub(r"`(.*?)`", r"\1", subject)

        return subject.strip()

    def _prepare_body_for_send(self, body: str) -> tuple[str, str]:
        """
        Devuelve (body_preparado, body_type).

        - Si ya parece HTML, lo deja intacto.
        - Si parece texto plano, lo convierte con text_to_html().
        """
        if self._looks_like_html(body):
            return body, "HTML"

        return text_to_html(body), "HTML"

    async def _send(self, email: ScheduledEmail) -> None:
        """Envía el correo o lo guarda como borrador según `save_as_draft`."""
        if not email.subject or not email.body:
            raise ValueError(f"[{email.id}] No hay subject o body para enviar.")

        prepared_body, prepared_body_type = self._prepare_body_for_send(email.body)

        if email.save_as_draft:
            draft = await self._mail.create_draft(
                to=email.to,
                subject=email.subject,
                body=prepared_body,
                cc=email.cc or None,
                bcc=email.bcc or None,
                body_type=prepared_body_type,
                attachments=email.attachments or None,
            )
            logger.info(f"Borrador guardado [{email.id}] draft_id={draft.id!r}")
        else:
            await self._mail.send_mail(
                to=email.to,
                subject=email.subject,
                body=prepared_body,
                cc=email.cc or None,
                bcc=email.bcc or None,
                body_type=prepared_body_type,
                attachments=email.attachments or None,
            )
        
    def _schedule_next_occurrence(self, sent_email: ScheduledEmail) -> None:
        """
        Si el correo es recurrente, crea la siguiente ocurrencia en el store.
        """
        next_at = sent_email.next_send_at()
        if next_at is None:
            return

        import copy
        next_email = copy.deepcopy(sent_email)
        next_email.id = self._store.new_id()
        next_email.send_at = next_at
        next_email.status = ScheduleStatus.PENDING
        next_email.sent_at = None
        next_email.error = None
        # Limpiar el draft para que se regenere con el LLM en el momento de envío
        next_email.subject = None
        next_email.body = None

        self._store.add(next_email)
        logger.info(f"↻ Nueva ocurrencia programada [{next_email.id}] para {next_at.isoformat()}")

    @staticmethod
    async def _safe_callback(cb: Callable, *args) -> None:
        """Ejecuta un callback sin que un error rompa el flujo principal."""
        try:
            if inspect.iscoroutinefunction(cb):
                await cb(*args)
            else:
                cb(*args)
        except Exception as exc:
            logger.warning(f"Error en callback: {exc}")

    def _list_all_pending(self) -> list[ScheduledEmail]:
        return self._store.filter(lambda e: e.status == ScheduleStatus.PENDING)