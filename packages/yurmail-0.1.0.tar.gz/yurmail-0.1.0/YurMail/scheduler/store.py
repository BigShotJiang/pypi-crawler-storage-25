"""
scheduler/store.py

Almacenamiento de correos programados.

Ofrece dos implementaciones:
  - InMemoryStore     → útil para tests y uso efímero
  - JsonFileStore     → persiste los jobs en un archivo JSON entre ejecuciones

Ambas implementan la interfaz AbstractScheduleStore, por lo que son
intercambiables sin cambiar nada en el Scheduler.
"""

from __future__ import annotations

import json
import uuid
from abc import ABC, abstractmethod
from datetime import datetime
from pathlib import Path
from typing import Callable

from .types import ScheduledEmail, ScheduleStatus, TriggerType


# ── Serialización / deserialización ──────────────────────────────────────────

def _email_to_dict(email: ScheduledEmail) -> dict:
    return {
        "id": email.id,
        "purpose": email.purpose,
        "to": email.to,
        "send_at": email.send_at.isoformat(),
        "recipient_name": email.recipient_name,
        "tone": email.tone,
        "context": email.context,
        "language": email.language,
        "cc": email.cc,
        "bcc": email.bcc,
        "attachments": email.attachments,
        "subject": email.subject,
        "body": email.body,
        "trigger_type": email.trigger_type.value,
        "recur_day": email.recur_day,
        "status": email.status.value,
        "created_at": email.created_at.isoformat(),
        "sent_at": email.sent_at.isoformat() if email.sent_at else None,
        "error": email.error,
        "metadata": email.metadata,
    }


def _dict_to_email(data: dict) -> ScheduledEmail:
    return ScheduledEmail(
        id=data["id"],
        purpose=data["purpose"],
        to=data["to"],
        send_at=datetime.fromisoformat(data["send_at"]),
        recipient_name=data.get("recipient_name"),
        tone=data.get("tone", "professional"),
        context=data.get("context"),
        language=data.get("language", "es"),
        cc=data.get("cc", []),
        bcc=data.get("bcc", []),
        attachments=data.get("attachments", []),
        subject=data.get("subject"),
        body=data.get("body"),
        trigger_type=TriggerType(data.get("trigger_type", "once")),
        recur_day=data.get("recur_day"),
        status=ScheduleStatus(data.get("status", "pending")),
        created_at=datetime.fromisoformat(data["created_at"]),
        sent_at=datetime.fromisoformat(data["sent_at"]) if data.get("sent_at") else None,
        error=data.get("error"),
        metadata=data.get("metadata", {}),
    )


# ── Interfaz base ─────────────────────────────────────────────────────────────

class AbstractScheduleStore(ABC):
    """Interfaz que deben implementar todos los stores."""

    @abstractmethod
    def add(self, email: ScheduledEmail) -> ScheduledEmail:
        """Agrega un correo programado y lo devuelve."""

    @abstractmethod
    def get(self, email_id: str) -> ScheduledEmail | None:
        """Devuelve un correo por ID, o None si no existe."""

    @abstractmethod
    def list_all(self) -> list[ScheduledEmail]:
        """Lista todos los correos almacenados."""

    @abstractmethod
    def update(self, email: ScheduledEmail) -> None:
        """Persiste cambios sobre un correo existente."""

    @abstractmethod
    def delete(self, email_id: str) -> bool:
        """Elimina un correo. Devuelve True si existía."""

    def pending(self, now: datetime | None = None) -> list[ScheduledEmail]:
        """Lista los correos vencidos y pendientes de envío."""
        now = now or datetime.utcnow()
        return [e for e in self.list_all() if e.is_due(now)]

    def filter(self, predicate: Callable[[ScheduledEmail], bool]) -> list[ScheduledEmail]:
        return [e for e in self.list_all() if predicate(e)]

    @staticmethod
    def new_id() -> str:
        return str(uuid.uuid4())


# ── Implementaciones ──────────────────────────────────────────────────────────

class InMemoryStore(AbstractScheduleStore):
    """
    Store en memoria. Rápido, sin dependencias, pero no persiste entre reinicios.
    Ideal para tests y uso dentro de un mismo proceso.
    """

    def __init__(self) -> None:
        self._data: dict[str, ScheduledEmail] = {}

    def add(self, email: ScheduledEmail) -> ScheduledEmail:
        if not email.id:
            email.id = self.new_id()
        self._data[email.id] = email
        return email

    def get(self, email_id: str) -> ScheduledEmail | None:
        return self._data.get(email_id)

    def list_all(self) -> list[ScheduledEmail]:
        return list(self._data.values())

    def update(self, email: ScheduledEmail) -> None:
        self._data[email.id] = email

    def delete(self, email_id: str) -> bool:
        if email_id in self._data:
            del self._data[email_id]
            return True
        return False


class JsonFileStore(AbstractScheduleStore):
    """
    Store persistente en un archivo JSON.

    Los cambios se escriben en disco en cada operación de escritura,
    garantizando que el estado no se pierde si el proceso termina inesperadamente.

    Uso:
        store = JsonFileStore("scheduled_emails.json")
    """

    def __init__(self, path: str | Path) -> None:
        self._path = Path(path)
        self._ensure_file()

    def _ensure_file(self) -> None:
        if not self._path.exists():
            self._path.parent.mkdir(parents=True, exist_ok=True)
            self._path.write_text("[]", encoding="utf-8")

    def _load(self) -> dict[str, ScheduledEmail]:
        raw = json.loads(self._path.read_text(encoding="utf-8"))
        return {item["id"]: _dict_to_email(item) for item in raw}

    def _save(self, data: dict[str, ScheduledEmail]) -> None:
        serialized = [_email_to_dict(e) for e in data.values()]
        self._path.write_text(
            json.dumps(serialized, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    def add(self, email: ScheduledEmail) -> ScheduledEmail:
        if not email.id:
            email.id = self.new_id()
        data = self._load()
        data[email.id] = email
        self._save(data)
        return email

    def get(self, email_id: str) -> ScheduledEmail | None:
        return self._load().get(email_id)

    def list_all(self) -> list[ScheduledEmail]:
        return list(self._load().values())

    def update(self, email: ScheduledEmail) -> None:
        data = self._load()
        data[email.id] = email
        self._save(data)

    def delete(self, email_id: str) -> bool:
        data = self._load()
        if email_id in data:
            del data[email_id]
            self._save(data)
            return True
        return False
