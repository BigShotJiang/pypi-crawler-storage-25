"""
scheduler/builder.py
 
Builder fluido para crear ScheduledEmail de forma legible y sin errores.
 
Ejemplo:
    from mail_scheduler.scheduler import EmailBuilder, TriggerType
    from datetime import datetime, timezone, timedelta
 
    email = (
        EmailBuilder()
        .to(["gerente@empresa.com"])
        .purpose("Enviar reporte semanal de ventas al gerente")
        .recipient_name("Carlos")
        .tone("formal")
        .language("es")
        .context("El reporte cubre del lunes al viernes de la semana en curso.")
        .send_at(datetime.now(timezone.utc) + timedelta(hours=2))
        .weekly(recur_day=4)   # Todos los viernes
        .cc(["copia@empresa.com"])
        .build()
    )
"""
 
from __future__ import annotations
 
import uuid
from datetime import datetime, timezone
from typing import Self
 
from .types import ScheduledEmail, TriggerType
 
 
class EmailBuilder:
    """
    Builder fluido para construir ScheduledEmail.
    Valida los campos mínimos al llamar a build().
    """
 
    def __init__(self) -> None:
        self._id: str = str(uuid.uuid4())
        self._purpose: str | None = None
        self._to: list[str] = []
        self._send_at: datetime | None = None
        self._recipient_name: str | None = None
        self._tone: str = "professional"
        self._context: str | None = None
        self._language: str = "es"
        self._cc: list[str] = []
        self._bcc: list[str] = []
        self._attachments: list[str] = []
        self._subject: str | None = None
        self._body: str | None = None
        self._trigger_type: TriggerType = TriggerType.ONCE
        self._recur_day: int | None = None
        self._metadata: dict = {}
        self._save_as_draft: bool = False
 
    # ── Fluent setters ────────────────────────────────────────────────────────
 
    def id(self, value: str) -> Self:
        self._id = value
        return self
 
    def purpose(self, value: str) -> Self:
        self._purpose = value
        return self
 
    def to(self, recipients: list[str]) -> Self:
        self._to = recipients
        return self
 
    def send_at(self, when: datetime) -> Self:
        # Asegurarse de que sea UTC-aware
        if when.tzinfo is None:
            when = when.replace(tzinfo=timezone.utc)
        self._send_at = when
        return self
 
    def recipient_name(self, name: str) -> Self:
        self._recipient_name = name
        return self
 
    def tone(self, value: str) -> Self:
        self._tone = value
        return self
 
    def context(self, value: str) -> Self:
        self._context = value
        return self
 
    def language(self, value: str) -> Self:
        self._language = value
        return self
 
    def cc(self, addresses: list[str]) -> Self:
        self._cc = addresses
        return self
 
    def bcc(self, addresses: list[str]) -> Self:
        self._bcc = addresses
        return self
 
    def attach(self, paths: list[str]) -> Self:
        self._attachments = paths
        return self
 
    def subject(self, value: str) -> Self:
        """Provee el asunto directamente (omite la generación con LLM)."""
        self._subject = value
        return self
 
    def body(self, value: str) -> Self:
        """Provee el cuerpo directamente (omite la generación con LLM)."""
        self._body = value
        return self
 
    def metadata(self, data: dict) -> Self:
        self._metadata = data
        return self
 
    def save_as_draft(self, value: bool = True) -> Self:
        """
        Si True, el correo se guardará como borrador en lugar de enviarse.
        Útil cuando el contenido lo genera el LLM y quieres revisarlo antes.
        """
        self._save_as_draft = value
        return self
 
    # ── Trigger helpers ───────────────────────────────────────────────────────
 
    def once(self) -> Self:
        self._trigger_type = TriggerType.ONCE
        return self
 
    def daily(self) -> Self:
        self._trigger_type = TriggerType.DAILY
        return self
 
    def weekly(self, recur_day: int) -> Self:
        """
        Repite semanalmente.
        recur_day: 0 = lunes, 1 = martes, ..., 6 = domingo
        """
        if not 0 <= recur_day <= 6:
            raise ValueError("recur_day debe estar entre 0 (lunes) y 6 (domingo).")
        self._trigger_type = TriggerType.WEEKLY
        self._recur_day = recur_day
        return self
 
    # ── Build ─────────────────────────────────────────────────────────────────
 
    def build(self) -> ScheduledEmail:
        errors = []
        if not self._purpose:
            errors.append("purpose es obligatorio.")
        if not self._to:
            errors.append("to (destinatarios) es obligatorio.")
        if self._send_at is None:
            errors.append("send_at es obligatorio.")
        if errors:
            raise ValueError("EmailBuilder.build() falló:\n  - " + "\n  - ".join(errors))
 
        return ScheduledEmail(
            id=self._id,
            purpose=self._purpose,
            to=self._to,
            send_at=self._send_at,
            recipient_name=self._recipient_name,
            tone=self._tone,
            context=self._context,
            language=self._language,
            cc=self._cc,
            bcc=self._bcc,
            attachments=self._attachments,
            subject=self._subject,
            body=self._body,
            trigger_type=self._trigger_type,
            recur_day=self._recur_day,
            metadata=self._metadata,
            save_as_draft=self._save_as_draft,
        )