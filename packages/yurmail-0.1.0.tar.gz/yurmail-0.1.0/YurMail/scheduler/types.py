"""
scheduler/types.py
 
Tipos de datos para el scheduler de correos.
"""
 
from __future__ import annotations
 
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any
 
 
class ScheduleStatus(str, Enum):
    PENDING   = "pending"    # Esperando su momento de envío
    SENDING   = "sending"    # En proceso de envío
    SENT      = "sent"       # Enviado exitosamente
    FAILED    = "failed"     # Falló el envío
    CANCELLED = "cancelled"  # Cancelado manualmente
 
 
class TriggerType(str, Enum):
    ONCE      = "once"      # Enviar una vez en una fecha/hora exacta
    DAILY     = "daily"     # Repetir cada día a la misma hora
    WEEKLY    = "weekly"    # Repetir cada semana en el mismo día/hora
 
 
@dataclass
class ScheduledEmail:
    """
    Representa un correo programado para envío futuro.
 
    Campos requeridos:
        purpose        — descripción del propósito del correo (para el LLM)
        to             — lista de destinatarios
        send_at        — cuándo enviarlo (datetime UTC)
 
    Campos opcionales para generación con LLM:
        recipient_name — nombre del destinatario (para personalizar el draft)
        tone           — tono del correo ("professional", "casual", "formal")
        context        — contexto adicional para el LLM
        language       — idioma del correo ("es", "en", etc.)
 
    Campos opcionales para el envío:
        cc             — lista de CC
        bcc            — lista de BCC
        attachments    — rutas de archivos a adjuntar
 
    Campos para recurrencia:
        trigger_type   — ONCE, DAILY o WEEKLY
        recur_day      — día de la semana (0=lunes … 6=domingo) si trigger=WEEKLY
    """
 
    # --- Identificación ---
    id: str
 
    # --- Contenido (puede venir ya generado o generarse con LLM) ---
    purpose: str
    to: list[str]
    send_at: datetime
 
    # --- Parámetros LLM ---
    recipient_name: str | None = None
    tone: str = "professional"
    context: str | None = None
    language: str = "es"
 
    # --- Parámetros de envío ---
    cc: list[str] = field(default_factory=list)
    bcc: list[str] = field(default_factory=list)
    attachments: list[str] = field(default_factory=list)
 
    # --- Draft generado (se rellena al momento del envío) ---
    subject: str | None = None
    body: str | None = None
 
    # --- Comportamiento de envío ---
    save_as_draft: bool = False  # Si True, guarda como borrador en lugar de enviar
 
    # --- Recurrencia ---
    trigger_type: TriggerType = TriggerType.ONCE
    recur_day: int | None = None          # Solo para WEEKLY (0–6)
 
    # --- Estado ---
    status: ScheduleStatus = ScheduleStatus.PENDING
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    sent_at: datetime | None = None
    error: str | None = None
 
    # --- Metadata libre ---
    metadata: dict[str, Any] = field(default_factory=dict)
 
    def is_due(self, now: datetime | None = None) -> bool:
        """Devuelve True si el correo debe enviarse ahora o ya pasó su hora."""
        now = now or datetime.now(timezone.utc)
        # Normalizar send_at a UTC-aware si llegara naked (offset-naive)
        send_at = self.send_at
        if send_at.tzinfo is None:
            send_at = send_at.replace(tzinfo=timezone.utc)
        return self.status == ScheduleStatus.PENDING and send_at <= now
 
    def next_send_at(self) -> datetime | None:
        """
        Calcula el próximo datetime de envío para correos recurrentes.
        Devuelve None si es ONCE o si no hay lógica definida.
        """
        from datetime import timedelta
 
        if self.trigger_type == TriggerType.DAILY:
            return self.send_at + timedelta(days=1)
 
        if self.trigger_type == TriggerType.WEEKLY:
            return self.send_at + timedelta(weeks=1)
 
        return None
 
 
@dataclass
class SchedulerResult:
    """Resultado de un ciclo de procesamiento del scheduler."""
    sent: list[str] = field(default_factory=list)       # IDs enviados OK
    failed: list[str] = field(default_factory=list)     # IDs que fallaron
    skipped: int = 0                                     # Correos no vencidos
 
    @property
    def total_processed(self) -> int:
        return len(self.sent) + len(self.failed)