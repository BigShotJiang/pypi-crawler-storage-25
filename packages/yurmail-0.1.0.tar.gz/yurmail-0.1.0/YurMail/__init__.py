from .authentication_microsoft import GraphAuthManager, OAuthCallbackResult
from .mail import (
    GraphMailClient, GraphAPIError,
    Message, MailAddress, UserProfile, Draft,
    attachment_from_bytes,
    MailTemplate, TemplateRegistry,
    TemplateMissingVariableError, TemplateNotFoundError,
    TEMPLATE_RECORDATORIO, TEMPLATE_SEGUIMIENTO, TEMPLATE_REPORTE, text_to_html,
)
from .LLM import OpenAIDraftClient, DraftResult
from .scheduler import (
    Scheduler,
    AbstractScheduleStore,
    InMemoryStore,
    JsonFileStore,
    ScheduledEmail,
    ScheduleStatus,
    SchedulerResult,
    TriggerType,
    EmailBuilder,
)

__version__ = "0.3.0"

__all__ = [
    # Auth
    "GraphAuthManager",
    "OAuthCallbackResult",
    # Mail cliente
    "GraphMailClient",
    "GraphAPIError",
    # Modelos
    "Message",
    "MailAddress",
    "UserProfile",
    "Draft",
    # Adjuntos
    "attachment_from_bytes",
    # Templates
    "MailTemplate",
    "TemplateRegistry",
    "TemplateMissingVariableError",
    "TemplateNotFoundError",
    "TEMPLATE_RECORDATORIO",
    "TEMPLATE_SEGUIMIENTO",
    "TEMPLATE_REPORTE",
    "text_to_html",
    # LLM
    "OpenAIDraftClient",
    "DraftResult",
    # Scheduler
    "Scheduler",
    "AbstractScheduleStore",
    "InMemoryStore",
    "JsonFileStore",
    "ScheduledEmail",
    "ScheduleStatus",
    "SchedulerResult",
    "TriggerType",
    "EmailBuilder",
]