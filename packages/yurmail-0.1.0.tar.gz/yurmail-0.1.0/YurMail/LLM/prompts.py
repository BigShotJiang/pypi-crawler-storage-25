def build_draft_prompt(
    purpose: str,
    recipient_name: str | None = None,
    tone: str = "professional",
    context: str | None = None,
    language: str = "es",
) -> str:
    """
    Build a prompt for generating an email draft.

    Parameters
    ----------
    purpose:
        Main objective of the email.
    recipient_name:
        Optional recipient name.
    tone:
        Desired writing tone.
    context:
        Extra context or constraints.
    language:
        Output language, e.g. "es" or "en".
    """
    recipient_text = recipient_name or "destinatario"
    context_text = context or "Sin contexto adicional."

    return f"""
Redacta un correo electrónico en {language}.

Objetivo: {purpose}
Destinatario: {recipient_text}
Tono: {tone}
Contexto adicional: {context_text}

Instrucciones:
- Escribe un asunto claro y profesional.
- Escribe un cuerpo de correo natural, bien redactado y coherente.
- No inventes hechos que no aparezcan en el contexto.
- Mantén el tono solicitado.
- Si falta información, redacta de forma prudente y general.

Devuelve tu respuesta estrictamente en este formato:

SUBJECT: ...
BODY: ...
""".strip()