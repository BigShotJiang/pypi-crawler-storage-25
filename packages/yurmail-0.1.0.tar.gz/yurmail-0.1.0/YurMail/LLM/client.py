from __future__ import annotations

from openai import AsyncOpenAI

from .prompts import build_draft_prompt
from .types import DraftResult


class OpenAIDraftClient:
    """
    Small async client for generating email drafts with OpenAI.
    """

    def __init__(self, api_key: str | None = None, model: str = "gpt-5.4-mini"):
        self._client = AsyncOpenAI(api_key=api_key)
        self._model = model

    async def test_connection(self, message: str) -> str:
        """
        Simple helper to verify that the LLM connection works.
        """
        response = await self._client.responses.create(
            model=self._model,
            input=message,
        )
        return response.output_text.strip()

    async def generate_draft(
        self,
        purpose: str,
        recipient_name: str | None = None,
        tone: str = "professional",
        context: str | None = None,
        language: str = "es",
    ) -> DraftResult:
        """
        Generate an email draft and return structured subject/body output.
        """
        prompt = build_draft_prompt(
            purpose=purpose,
            recipient_name=recipient_name,
            tone=tone,
            context=context,
            language=language,
        )

        response = await self._client.responses.create(
            model=self._model,
            input=prompt,
        )

        text = response.output_text.strip()
        subject, body = self._parse_subject_and_body(text)

        return DraftResult(subject=subject, body=body, raw=text)

    @staticmethod
    def _parse_subject_and_body(text: str) -> tuple[str, str]:
        """
        Parse a response of the form:

        SUBJECT: ...
        BODY: ...
        """
        subject = ""
        body = text

        if "SUBJECT:" in text and "BODY:" in text:
            before, after = text.split("BODY:", 1)
            subject = before.replace("SUBJECT:", "").strip()
            body = after.strip()

        return subject, body