from dataclasses import dataclass

@dataclass
class DraftResult:
    subject: str
    body: str
    raw: str