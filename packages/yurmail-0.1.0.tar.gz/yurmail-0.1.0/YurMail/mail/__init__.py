from .client import (
    GraphMailClient, GraphAPIError,
    Message, MailAddress, UserProfile, Draft,
    attachment_from_bytes,
)
from .templates import (
    MailTemplate, TemplateRegistry,
    TemplateMissingVariableError, TemplateNotFoundError,
    TEMPLATE_RECORDATORIO, TEMPLATE_SEGUIMIENTO, TEMPLATE_REPORTE, text_to_html,
)
 
__all__ = [
    "GraphMailClient",
    "GraphAPIError",
    "Message",
    "MailAddress",
    "UserProfile",
    "Draft",
    "attachment_from_bytes",
    "MailTemplate",
    "TemplateRegistry",
    "TemplateMissingVariableError",
    "TemplateNotFoundError",
    "TEMPLATE_RECORDATORIO",
    "TEMPLATE_SEGUIMIENTO",
    "TEMPLATE_REPORTE",
    "text_to_html",
]