"""
mail/templates.py

Sistema de templates para correos electrónicos.

Soporta dos tipos de templates:
  - HTML con placeholders tipo {{ variable }}
  - Texto plano

Ejemplo de uso:
    from mail_scheduler.mail.templates import MailTemplate, TemplateRegistry

    # Definir un template
    bienvenida = MailTemplate(
        name="bienvenida",
        subject="Bienvenido, {{ nombre }}",
        body=\"\"\"
        <p>Hola {{ nombre }},</p>
        <p>Tu cuenta ha sido creada exitosamente.</p>
        <p>Tu usuario es: <strong>{{ usuario }}</strong></p>
        \"\"\",
    )

    # Renderizar con variables
    subject, body = bienvenida.render(nombre="Carlos", usuario="carlos123")

    # Usar con el cliente
    await client.send_mail(to=["carlos@outlook.com"], subject=subject, body=body)

    # O con un registry para manejar múltiples templates
    registry = TemplateRegistry()
    registry.register(bienvenida)
    subject, body = registry.render("bienvenida", nombre="Ana", usuario="ana456")
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any
import html as html_mod

# ── Errores ────────────────────────────────────────────────────────────────────

class TemplateNotFoundError(KeyError):
    """Template no registrado en el TemplateRegistry."""
    pass


class TemplateMissingVariableError(ValueError):
    """Una variable requerida por el template no fue provista."""
    pass


# ── Template ───────────────────────────────────────────────────────────────────

@dataclass
class MailTemplate:
    """
    Template de correo con placeholders tipo {{ variable }}.

    Parámetros
    ----------
    name:
        Identificador único del template (usado en TemplateRegistry).
    subject:
        Asunto del correo. Puede contener placeholders.
    body:
        Cuerpo del correo en HTML o texto plano. Puede contener placeholders.
    body_type:
        "HTML" (default) o "Text".
    description:
        Descripción opcional del template para documentación.
    defaults:
        Valores por defecto para variables. Se usan si no se pasan al render().
    """

    name: str
    subject: str
    body: str
    body_type: str = "HTML"
    description: str = ""
    defaults: dict[str, Any] = field(default_factory=dict)

    # Regex para detectar {{ variable }} con espacios opcionales
    _PLACEHOLDER_RE: re.Pattern = re.compile(r"\{\{\s*(\w+)\s*\}\}")

    def variables(self) -> set[str]:
        """Devuelve el conjunto de variables que usa este template."""
        found = set()
        found.update(self._PLACEHOLDER_RE.findall(self.subject))
        found.update(self._PLACEHOLDER_RE.findall(self.body))
        return found

    def render(self, **kwargs: Any) -> tuple[str, str]:
        """
        Renderiza el template con las variables dadas.

        Combina `defaults` con `kwargs` (kwargs tiene prioridad).
        Lanza TemplateMissingVariableError si falta alguna variable requerida.

        Devuelve:
            (subject_renderizado, body_renderizado)
        """
        variables = {**self.defaults, **kwargs}
        required = self.variables()
        missing = required - set(variables.keys())

        if missing:
            raise TemplateMissingVariableError(
                f"Template '{self.name}' requiere las variables: {sorted(missing)}"
            )

        def replace(text: str) -> str:
            def _sub(match: re.Match) -> str:
                return str(variables[match.group(1)])
            return self._PLACEHOLDER_RE.sub(_sub, text)

        return replace(self.subject), replace(self.body)

    @classmethod
    def from_files(
        cls,
        name: str,
        subject: str,
        body_path: str | Path,
        body_type: str = "HTML",
        description: str = "",
        defaults: dict[str, Any] | None = None,
    ) -> "MailTemplate":
        """
        Crea un template leyendo el body desde un archivo.

        Útil para templates HTML largos almacenados en archivos separados.

        Ejemplo:
            template = MailTemplate.from_files(
                name="reporte_semanal",
                subject="Reporte semanal — {{ semana }}",
                body_path="templates/reporte.html",
            )
        """
        path = Path(body_path)
        if not path.exists():
            raise FileNotFoundError(f"Archivo de template no encontrado: {path}")

        return cls(
            name=name,
            subject=subject,
            body=path.read_text(encoding="utf-8"),
            body_type=body_type,
            description=description,
            defaults=defaults or {},
        )


# Helper: texto plano → HTML 

def text_to_html(text: str) -> str:
    """
    Convierte texto plano con formato ligero tipo Markdown a HTML básico para correo.

    Soporta:
    - **negritas**
    - *cursivas*
    - [texto](https://ejemplo.com)
    - listas con - item o * item
    - párrafos separados por líneas en blanco
    - saltos de línea simples -> <br>

    Primero escapa HTML y después convierte solo patrones permitidos.
    """

    text = text.strip()
    if not text:
        return ""

    # Escapar HTML arbitrario
    text = html_mod.escape(text)

    # Aplicar formato inline permitido
    text = _apply_inline_formatting(text)

    # Separar bloques por líneas en blanco
    blocks = re.split(r"\n\s*\n", text)

    html_parts = []
    for block in blocks:
        lines = [line.rstrip() for line in block.split("\n")]
        nonempty_lines = [line for line in lines if line.strip()]

        if not nonempty_lines:
            continue

        # Si todas las líneas del bloque son items, se convierte en lista
        if _is_list_block(nonempty_lines):
            items = []
            for line in nonempty_lines:
                item = re.sub(r"^\s*[-*]\s+", "", line)
                items.append(f"<li>{item}</li>")
            html_parts.append("<ul>\n" + "\n".join(items) + "\n</ul>")
        else:
            paragraph = "<br>\n".join(nonempty_lines)
            html_parts.append(f"<p>{paragraph}</p>")

    return "\n".join(html_parts)


def _apply_inline_formatting(text: str) -> str:
    """
    Aplica formato inline después de escapar HTML.
    """

    # Links: [texto](url)
    def replace_link(match: re.Match) -> str:
        label = match.group(1)
        url = match.group(2)

        if not re.match(r"^https?://", url, flags=re.IGNORECASE):
            return match.group(0)

        return f'<a href="{url}">{label}</a>'

    text = re.sub(r"\[([^\]]+)\]\((https?://[^\s)]+)\)", replace_link, text)

    # Negritas: **texto**
    text = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", text)

    # Cursivas: *texto*
    text = re.sub(r"(?<!\*)\*(?!\*)(.+?)(?<!\*)\*(?!\*)", r"<em>\1</em>", text)

    return text


def _is_list_block(lines: list[str]) -> bool:
    """
    Un bloque es lista si todas sus líneas no vacías empiezan con '- ' o '* '.
    """
    return all(re.match(r"^\s*[-*]\s+", line) for line in lines)

class TemplateRegistry:
    """
    Registro central de templates.

    Permite registrar templates con nombre y luego renderizarlos
    por nombre sin tener que mantener referencias directas.

    Ejemplo:
        registry = TemplateRegistry()
        registry.register(MailTemplate(
            name="recordatorio",
            subject="Recordatorio: {{ evento }}",
            body="<p>No olvides {{ evento }} el {{ fecha }}.</p>",
        ))

        subject, body = registry.render("recordatorio",
            evento="reunión de equipo",
            fecha="viernes 18 de abril"
        )
    """

    def __init__(self) -> None:
        self._templates: dict[str, MailTemplate] = {}

    def register(self, template: MailTemplate) -> None:
        """Registra un template. Si ya existe con ese nombre, lo sobreescribe."""
        self._templates[template.name] = template

    def get(self, name: str) -> MailTemplate:
        """Obtiene un template por nombre. Lanza TemplateNotFoundError si no existe."""
        if name not in self._templates:
            available = list(self._templates.keys())
            raise TemplateNotFoundError(
                f"Template '{name}' no encontrado. Disponibles: {available}"
            )
        return self._templates[name]

    def render(self, name: str, **kwargs: Any) -> tuple[str, str]:
        """
        Renderiza un template por nombre con las variables dadas.
        Devuelve (subject, body).
        """
        return self.get(name).render(**kwargs)

    def list(self) -> list[str]:
        """Lista los nombres de todos los templates registrados."""
        return list(self._templates.keys())

    def __contains__(self, name: str) -> bool:
        return name in self._templates

    def __len__(self) -> int:
        return len(self._templates)


# Templates predefinidos 
# Templates listos para usar. Importar directamente en el registry. 

TEMPLATE_RECORDATORIO = MailTemplate(
    name="recordatorio",
    subject="Recordatorio: {{ evento }}",
    body="""
<p>Hola {{ nombre }},</p>
<p>Este es un recordatorio sobre: <strong>{{ evento }}</strong>.</p>
<p>Fecha: {{ fecha }}</p>
<p>Saludos.</p>
""".strip(),
    description="Recordatorio genérico con evento y fecha.",
    defaults={"nombre": "", "fecha": ""},
)

TEMPLATE_SEGUIMIENTO = MailTemplate(
    name="seguimiento",
    subject="Seguimiento: {{ tema }}",
    body="""
<p>Hola {{ nombre }},</p>
<p>Me pongo en contacto para dar seguimiento a: <strong>{{ tema }}</strong>.</p>
<p>{{ mensaje }}</p>
<p>Quedo a tus órdenes.</p>
""".strip(),
    description="Correo de seguimiento con tema y mensaje personalizable.",
    defaults={"mensaje": "Por favor avísame si necesitas algo más."},
)

TEMPLATE_REPORTE = MailTemplate(
    name="reporte",
    subject="Reporte {{ periodo }}: {{ titulo }}",
    body="""
<p>Hola {{ nombre }},</p>
<p>Adjunto encontrarás el reporte de <strong>{{ periodo }}</strong>.</p>
<h3>{{ titulo }}</h3>
<p>{{ resumen }}</p>
<p>Para cualquier duda, con gusto te atiendo.</p>
""".strip(),
    description="Template para envío de reportes con resumen ejecutivo.",
    defaults={"nombre": "equipo"},
)