"""
mail/client.py

Cliente para Microsoft Graph Mail API.
Requiere un access_token válido obtenido con GraphAuthManager.login().

Scopes mínimos necesarios en tu app registration:
  - User.Read        → get_me()
  - Mail.Read        → list_messages(), get_message()
  - Mail.ReadWrite   → move_to_trash(), mark_as_read()
  - Mail.Send        → send_mail(), reply_to_message()
"""

from __future__ import annotations

import base64
import mimetypes
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import aiohttp


GRAPH_BASE = "https://graph.microsoft.com/v1.0"


@dataclass
class MailAddress:
    name: str
    address: str

    @classmethod
    def from_graph(cls, data: dict) -> "MailAddress":
        ea = data.get("emailAddress", {})
        return cls(name=ea.get("name", ""), address=ea.get("address", ""))


@dataclass
class Draft:
    """Representa un borrador guardado en Microsoft Graph."""
    id: str
    subject: str
    to_recipients: list[MailAddress]
    body_content: str
    body_type: str
    created_at: str

    @classmethod
    def from_graph(cls, data: dict) -> "Draft":
        body = data.get("body", {})
        return cls(
            id=data.get("id", ""),
            subject=data.get("subject", "(sin asunto)"),
            to_recipients=[
                MailAddress.from_graph(r) for r in data.get("toRecipients", [])
            ],
            body_content=body.get("content", ""),
            body_type=body.get("contentType", "html"),
            created_at=data.get("createdDateTime", ""),
        )


@dataclass
class Message:
    id: str
    subject: str
    sender: MailAddress
    to_recipients: list[MailAddress]
    received_at: str          # ISO 8601
    is_read: bool
    body_preview: str
    body_content: str         # HTML completo (solo en get_message)
    body_type: str            # "html" | "text"
    conversation_id: str

    @classmethod
    def from_graph(cls, data: dict) -> "Message":
        body = data.get("body", {})
        return cls(
            id=data.get("id", ""),
            subject=data.get("subject", "(sin asunto)"),
            sender=MailAddress.from_graph(data.get("sender", {})),
            to_recipients=[
                MailAddress.from_graph(r) for r in data.get("toRecipients", [])
            ],
            received_at=data.get("receivedDateTime", ""),
            is_read=data.get("isRead", False),
            body_preview=data.get("bodyPreview", ""),
            body_content=body.get("content", ""),
            body_type=body.get("contentType", "html"),
            conversation_id=data.get("conversationId", ""),
        )


@dataclass
class UserProfile:
    id: str
    display_name: str
    mail: str
    user_principal_name: str

    @classmethod
    def from_graph(cls, data: dict) -> "UserProfile":
        return cls(
            id=data.get("id", ""),
            display_name=data.get("displayName", ""),
            mail=data.get("mail", ""),
            user_principal_name=data.get("userPrincipalName", ""),
        )


# Errores

class GraphAPIError(Exception):
    """Error devuelto por Microsoft Graph."""

    def __init__(self, status: int, code: str, message: str):
        self.status = status
        self.code = code
        super().__init__(f"[{status}] {code}: {message}")


# Cliente principal

class GraphMailClient:
    """
    Cliente async para la Mail API de Microsoft Graph.

    Uso básico:
        client = GraphMailClient(access_token)
        mensajes = await client.list_messages(top=10)
        await client.send_mail(
            to=["alguien@ejemplo.com"],
            subject="Hola",
            body="<p>Mensaje de prueba</p>",
        )

    El cliente NO maneja el refresh del token — eso le corresponde
    a GraphAuthManager. Si recibes un 401, llama a
    GraphAuthManager.refresh_access_token() y crea una nueva instancia.
    """

    def __init__(self, access_token: str):
        self._token = access_token
        self._headers = {
            "Authorization": f"Bearer {access_token}",
            "Content-Type": "application/json",
        }

    # Helpers internos

    async def _get(self, path: str, params: dict | None = None) -> Any:
        url = f"{GRAPH_BASE}{path}"
        async with aiohttp.ClientSession() as session:
            async with session.get(
                url,
                headers=self._headers,
                params=params,
                timeout=aiohttp.ClientTimeout(total=30),
            ) as resp:
                data = await resp.json()
                if not resp.ok:
                    err = data.get("error", {})
                    raise GraphAPIError(
                        resp.status,
                        err.get("code", "Unknown"),
                        err.get("message", ""),
                    )
                return data

    async def _post(self, path: str, body: dict) -> Any:
        url = f"{GRAPH_BASE}{path}"
        async with aiohttp.ClientSession() as session:
            async with session.post(
                url,
                headers=self._headers,
                json=body,
                timeout=aiohttp.ClientTimeout(total=30),
            ) as resp:
                # sendMail devuelve 202 sin body
                if resp.status == 202:
                    return None
                data = await resp.json()
                if not resp.ok:
                    err = data.get("error", {})
                    raise GraphAPIError(
                        resp.status,
                        err.get("code", "Unknown"),
                        err.get("message", ""),
                    )
                return data

    async def _patch(self, path: str, body: dict) -> Any:
        url = f"{GRAPH_BASE}{path}"
        async with aiohttp.ClientSession() as session:
            async with session.patch(
                url,
                headers=self._headers,
                json=body,
                timeout=aiohttp.ClientTimeout(total=30),
            ) as resp:
                if not resp.ok:
                    data = await resp.json()
                    err = data.get("error", {})
                    raise GraphAPIError(
                        resp.status,
                        err.get("code", "Unknown"),
                        err.get("message", ""),
                    )
                # Algunas respuestas PATCH pueden no traer JSON útil
                if resp.content_type == "application/json":
                    return await resp.json()
                return None

    # Perfil del usuario

    async def get_me(self) -> UserProfile:
        """Devuelve el perfil del usuario autenticado."""
        data = await self._get("/me")
        return UserProfile.from_graph(data)

    # Lectura de mensajes

    async def list_messages(
        self,
        top: int = 20,
        folder: str = "inbox",
        only_unread: bool = False,
        search: str | None = None,
    ) -> list[Message]:
        """
        Lista mensajes del buzón.

        Parámetros:
            top         — máximo de mensajes a devolver (máx. 1000 por llamada)
            folder      — carpeta: "inbox", "sentitems", "drafts", "deleteditems"
            only_unread — si True, filtra solo los no leídos
            search      — búsqueda de texto libre (sujeto, cuerpo, remitente)
        """
        params: dict[str, Any] = {
            "$top": top,
            "$orderby": "receivedDateTime DESC",
            "$select": "id,subject,sender,toRecipients,receivedDateTime,isRead,bodyPreview,conversationId",
        }

        if only_unread:
            params["$filter"] = "isRead eq false"

        if search:
            # $search y $filter no se pueden usar juntos
            params.pop("$filter", None)
            params["$search"] = f'"{search}"'

        data = await self._get(f"/me/mailFolders/{folder}/messages", params=params)
        return [Message.from_graph(m) for m in data.get("value", [])]

    async def get_message(self, message_id: str) -> Message:
        """
        Obtiene un mensaje completo incluyendo el body HTML.
        Necesario porque list_messages solo trae bodyPreview.
        """
        data = await self._get(
            f"/me/messages/{message_id}",
            params={"$select": "id,subject,sender,toRecipients,receivedDateTime,isRead,body,conversationId"},
        )
        return Message.from_graph(data)

    # Envío de mensajes

    async def send_mail(
        self,
        to: list[str],
        subject: str,
        body: str,
        cc: list[str] | None = None,
        bcc: list[str] | None = None,
        body_type: str = "HTML",
        attachments: list[str | Path | dict] | None = None,
        save_to_sent: bool = True,
    ) -> None:
        """
        Envía un correo electrónico.

        Parámetros:
            to           — lista de direcciones destino
            subject      — asunto
            body         — cuerpo del mensaje (HTML por defecto)
            cc           — lista de CC (opcional)
            bcc          — lista de BCC (opcional)
            body_type    — "HTML" o "Text"
            attachments  — lista de rutas o adjuntos ya serializados
            save_to_sent — guardar en Elementos enviados (default True)
        """

        def _recipient(address: str) -> dict:
            return {"emailAddress": {"address": address}}

        message: dict[str, Any] = {
            "subject": subject,
            "body": {"contentType": body_type, "content": body},
            "toRecipients": [_recipient(a) for a in to],
        }

        if cc:
            message["ccRecipients"] = [_recipient(a) for a in cc]
        if bcc:
            message["bccRecipients"] = [_recipient(a) for a in bcc]

        if attachments:
            message["attachments"] = [
                _normalize_attachment(p) for p in attachments
            ]

        payload = {
            "message": message,
            "saveToSentItems": save_to_sent,
        }

        await self._post("/me/sendMail", payload)

    async def create_draft(
        self,
        to: list[str],
        subject: str,
        body: str,
        cc: list[str] | None = None,
        bcc: list[str] | None = None,
        body_type: str = "HTML",
        attachments: list[str | Path | dict] | None = None,
    ) -> Draft:
        """
        Guarda un correo como borrador en la carpeta Drafts.
        No envía nada — el usuario puede revisarlo y enviarlo manualmente.

        Devuelve el Draft creado con su ID de Graph.
        """

        def _recipient(address: str) -> dict:
            return {"emailAddress": {"address": address}}

        message: dict[str, Any] = {
            "subject": subject,
            "body": {"contentType": body_type, "content": body},
            "toRecipients": [_recipient(a) for a in to],
        }

        if cc:
            message["ccRecipients"] = [_recipient(a) for a in cc]
        if bcc:
            message["bccRecipients"] = [_recipient(a) for a in bcc]
        if attachments:
            message["attachments"] = [
                _normalize_attachment(p) for p in attachments
            ]

        data = await self._post("/me/messages", message)
        return Draft.from_graph(data)

    async def send_draft(self, draft_id: str) -> None:
        """Envía un borrador existente por su ID."""
        await self._post(f"/me/messages/{draft_id}/send", {})

    async def delete_draft(self, draft_id: str) -> None:
        """Elimina un borrador sin enviarlo."""
        url = f"{GRAPH_BASE}/me/messages/{draft_id}"
        async with aiohttp.ClientSession() as session:
            async with session.delete(
                url,
                headers=self._headers,
                timeout=aiohttp.ClientTimeout(total=30),
            ) as resp:
                if not resp.ok:
                    data = await resp.json()
                    err = data.get("error", {})
                    raise GraphAPIError(
                        resp.status,
                        err.get("code", "Unknown"),
                        err.get("message", ""),
                    )

    async def reply_to_message(
        self,
        message_id: str,
        body: str,
        body_type: str = "HTML",
    ) -> None:
        """
        Responde a un mensaje existente manteniendo el hilo.
        Graph agrega automáticamente la cita del original.
        """
        await self._post(
            f"/me/messages/{message_id}/reply",
            {"message": {"body": {"contentType": body_type, "content": body}}},
        )

    async def forward_message(
        self,
        message_id: str,
        to: list[str],
        comment: str = "",
    ) -> None:
        """Reenvía un mensaje a nuevos destinatarios."""

        def _recipient(address: str) -> dict:
            return {"emailAddress": {"address": address}}

        await self._post(
            f"/me/messages/{message_id}/forward",
            {
                "toRecipients": [_recipient(a) for a in to],
                "comment": comment,
            },
        )

    # Gestión de mensajes

    async def mark_as_read(self, message_id: str, read: bool = True) -> None:
        """Marca un mensaje como leído o no leído."""
        await self._patch(f"/me/messages/{message_id}", {"isRead": read})

    async def move_to_trash(self, message_id: str) -> None:
        """Mueve un mensaje a la carpeta de eliminados."""
        await self._post(
            f"/me/messages/{message_id}/move",
            {"destinationId": "deleteditems"},
        )

    async def move_to_folder(self, message_id: str, folder_id: str) -> None:
        """Mueve un mensaje a una carpeta específica por su ID o nombre conocido."""
        await self._post(
            f"/me/messages/{message_id}/move",
            {"destinationId": folder_id},
        )


# ── Helpers de adjuntos ───────────────────────────────────────────────────────

def _encode_attachment(path: Path) -> dict:
    """Convierte un archivo local al formato de adjunto que espera Graph."""
    if not path.exists():
        raise FileNotFoundError(f"Adjunto no encontrado: {path}")

    mime_type, _ = mimetypes.guess_type(str(path))
    mime_type = mime_type or "application/octet-stream"
    content_bytes = base64.b64encode(path.read_bytes()).decode("utf-8")

    return {
        "@odata.type": "#microsoft.graph.fileAttachment",
        "name": path.name,
        "contentType": mime_type,
        "contentBytes": content_bytes,
    }


def _normalize_attachment(att: str | Path | dict) -> dict:
    """
    Normaliza un adjunto al formato que espera Microsoft Graph.

    Soporta:
    - rutas en disco (str | Path)
    - adjuntos ya construidos como dict, por ejemplo con attachment_from_bytes()
    """
    if isinstance(att, dict):
        return att

    if isinstance(att, (str, Path)):
        return _encode_attachment(Path(att))

    raise TypeError(f"Tipo de adjunto no soportado: {type(att)!r}")


def attachment_from_bytes(
    data: bytes,
    filename: str,
    mime_type: str | None = None,
) -> dict:
    """
    Crea un adjunto desde bytes en memoria (sin necesidad de archivo en disco).

    Útil para adjuntar contenido generado dinámicamente (PDFs, CSVs, imágenes).

    Ejemplo:
        pdf_bytes = generate_report()
        adj = attachment_from_bytes(pdf_bytes, "reporte.pdf", "application/pdf")
        await client.send_mail(to=[...], subject="...", body="...", attachments=[adj])

        # También funciona con create_draft():
        draft = await client.create_draft(
            to=[...],
            subject="...",
            body="...",
            attachments=[adj],
        )
    """
    if mime_type is None:
        guessed, _ = mimetypes.guess_type(filename)
        mime_type = guessed or "application/octet-stream"

    return {
        "@odata.type": "#microsoft.graph.fileAttachment",
        "name": filename,
        "contentType": mime_type,
        "contentBytes": base64.b64encode(data).decode("utf-8"),
    }