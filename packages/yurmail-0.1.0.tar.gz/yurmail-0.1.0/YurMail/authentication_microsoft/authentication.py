import asyncio
import base64
import hashlib
import secrets
import webbrowser
from dataclasses import dataclass
from typing import Any
from urllib.parse import urlencode, urlparse

import aiohttp
from aiohttp import web


@dataclass
class OAuthCallbackResult:
    code: str | None = None
    state: str | None = None
    error: str | None = None
    error_description: str | None = None


class GraphAuthManager:
    """
    Handle Microsoft OAuth 2.0 Authorization Code Flow with PKCE
    for a local/public client.

    Parameters
  
    client_id:
        Application (client) ID from Microsoft Entra app registration.
    tenant:
        Usually "common", "organizations"
    redirect_uri:
        Must exactly match a registered redirect URI, e.g.
        "http://localhost:8765/callback".
    scopes:
        List of scopes such as:
        ["offline_access", "User.Read", "Mail.Send"]
    """

    def __init__(self, client_id, tenant, redirect_uri, scopes):
        self.client_id = client_id
        self.tenant = tenant
        self.redirect_uri = redirect_uri
        self.scopes = scopes

        self._authorize_endpoint = (
            f"https://login.microsoftonline.com/{self.tenant}/oauth2/v2.0/authorize"
        )
        self._token_endpoint = (
            f"https://login.microsoftonline.com/{self.tenant}/oauth2/v2.0/token"
        )

        parsed = urlparse(self.redirect_uri)
        if parsed.scheme not in {"http", "https"}:
            raise ValueError("redirect_uri must start with http:// or https://")
        if not parsed.hostname:
            raise ValueError("redirect_uri must include a hostname")
        if not parsed.port:
            raise ValueError(
                "redirect_uri must include an explicit port for the local callback server"
            )

        self._redirect_host = parsed.hostname
        self._redirect_port = parsed.port
        self._redirect_path = parsed.path or "/"

        self._last_state: str | None = None
        self._last_code_verifier: str | None = None
        self._last_token_response: dict[str, Any] | None = None

    @staticmethod
    def _generate_state() -> str:
        """Generate a random state value for CSRF protection."""
        return secrets.token_urlsafe(32)

    @staticmethod
    def _generate_code_verifier() -> str:
        """
        Generate a PKCE code verifier.
        RFC 7636 allows 43-128 chars; urlsafe token is convenient here.
        """
        verifier = secrets.token_urlsafe(64)
        return verifier[:128]

    @staticmethod
    def _generate_code_challenge(code_verifier: str) -> str:
        """Generate the PKCE S256 code challenge from a verifier."""
        digest = hashlib.sha256(code_verifier.encode("ascii")).digest()
        return base64.urlsafe_b64encode(digest).decode("ascii").rstrip("=")


    def build_authorization_url(self, state: str) -> str:
        """
        Build the Microsoft authorization URL.

        This implementation uses PKCE for a public/local client.
        """
        code_verifier = self._generate_code_verifier()
        code_challenge = self._generate_code_challenge(code_verifier)

        self._last_state = state
        self._last_code_verifier = code_verifier

        params = {
            "client_id": self.client_id,
            "response_type": "code",
            "redirect_uri": self.redirect_uri,
            "response_mode": "query",
            "scope": " ".join(self.scopes),
            "state": state,
            "code_challenge": code_challenge,
            "code_challenge_method": "S256",
        }
        return f"{self._authorize_endpoint}?{urlencode(params)}"

    def _build_callback_app(
        self,
        result: OAuthCallbackResult,
        stop_event: asyncio.Event,
    ) -> web.Application:
        """
        Construye una app aiohttp de un solo endpoint para capturar
        el redirect de Microsoft.

        `stop_event` se activa una vez que se recibe la respuesta,
        permitiendo que `login()` detenga el servidor limpiamente.
        """
        expected_path = self._redirect_path

        async def callback_handler(request: web.Request) -> web.Response:
            if request.path != expected_path:
                raise web.HTTPNotFound()

            result.code = request.query.get("code")
            result.state = request.query.get("state")
            result.error = request.query.get("error")
            result.error_description = request.query.get("error_description")

            stop_event.set()

            return web.Response(
                content_type="text/html",
                text="""
                <html>
                    <body style="font-family: Arial, sans-serif; margin: 2rem;">
                        <h2>Autenticacion completada</h2>
                        <p>Ya puedes cerrar esta ventana y volver a la terminal.</p>
                    </body>
                </html>
                """,
            )

        app = web.Application()
        app.router.add_get(expected_path, callback_handler)
        # Captura también requests inesperados (e.g. favicon) sin crashear.
        app.router.add_get("/{tail:.*}", lambda r: web.Response(status=204))
        return app

    async def login(self) -> dict:
        """
        Complete the interactive login flow.

        Steps:
        1. Generate state
        2. Build authorization URL with PKCE
        3. Start local aiohttp callback server
        4. Open browser
        5. Wait for redirect with authorization code
        6. Exchange code for tokens
        7. Shut down callback server
        """
        state = self._generate_state()
        auth_url = self.build_authorization_url(state)

        stop_event = asyncio.Event()
        result = OAuthCallbackResult()
        app = self._build_callback_app(result, stop_event)

        runner = web.AppRunner(app)
        await runner.setup()

        site = web.TCPSite(runner, self._redirect_host, self._redirect_port)
        await site.start()

        webbrowser.open(auth_url)

        try:
            await asyncio.wait_for(stop_event.wait(), timeout=300)
        except asyncio.TimeoutError:
            raise TimeoutError("Timed out waiting for OAuth callback")
        finally:
            await runner.cleanup()

        if result.error:
            raise RuntimeError(
                f"Authorization failed: {result.error} - {result.error_description}"
            )

        if not result.code:
            raise RuntimeError("No authorization code received in callback")

        if result.state != self._last_state:
            raise RuntimeError("State mismatch in OAuth callback")

        return await self.exchange_code_for_token(result.code)


    async def exchange_code_for_token(self, code: str) -> dict:
        """
        Exchange an authorization code for tokens.

        Uses PKCE code_verifier instead of a client secret.
        Migrado a aiohttp para no mezclar requests síncronos con asyncio.
        """
        if not self._last_code_verifier:
            raise RuntimeError(
                "No PKCE code verifier available. Call build_authorization_url() first."
            )

        data = {
            "client_id": self.client_id,
            "grant_type": "authorization_code",
            "code": code,
            "redirect_uri": self.redirect_uri,
            "scope": " ".join(self.scopes),
            "code_verifier": self._last_code_verifier,
        }

        async with aiohttp.ClientSession() as session:
            async with session.post(
                self._token_endpoint, data=data, timeout=aiohttp.ClientTimeout(total=30)
            ) as response:
                response.raise_for_status()
                token_data = await response.json()

        self._last_token_response = token_data
        return token_data

    async def refresh_access_token(self, refresh_token: str) -> dict:
        """
        Use a refresh token to get a new token set.
        Migrado a aiohttp para consistencia async.
        """
        data = {
            "client_id": self.client_id,
            "grant_type": "refresh_token",
            "refresh_token": refresh_token,
            "scope": " ".join(self.scopes),
        }

        async with aiohttp.ClientSession() as session:
            async with session.post(
                self._token_endpoint, data=data, timeout=aiohttp.ClientTimeout(total=30)
            ) as response:
                response.raise_for_status()
                token_data = await response.json()

        self._last_token_response = token_data
        return token_data