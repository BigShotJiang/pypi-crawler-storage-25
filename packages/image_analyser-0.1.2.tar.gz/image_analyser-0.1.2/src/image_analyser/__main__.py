"""Make `python -m image_analyser` invoke the CLI."""

from .cli import main

if __name__ == "__main__":
    main()
