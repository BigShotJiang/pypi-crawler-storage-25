# Local AI Platform

## PyPI Packages

- Sage CLI package URL: https://pypi.org/project/sage-ai-cli/
- Local API client package URL: https://pypi.org/project/claude-ai-clone-client/

## File Structure

```text
ai-platform/
├── backend/
├── frontend/
├── cli/
├── models/
└── config/
```

## Model Sources

| Model | Runtime | Source | License | Approx Size | Suggested Hardware |
|---|---|---|---|---|---|
| Llama 3.2 3B Instruct GGUF Q4_K_M | llama.cpp | https://github.com/ggml-org/llama.cpp | Meta Llama 3.2 Community License | ~2.0 GB | 8 GB RAM CPU |
| Qwen2.5 Coder 7B Instruct GGUF Q4_K_M | llama.cpp | https://github.com/QwenLM/Qwen2.5-Coder | Apache-2.0 | ~4.5 GB | 16 GB RAM CPU |
| Mistral 7B Instruct v0.3 | transformers | https://github.com/mistralai/mistral-inference | Apache-2.0 | ~13 GB fp16 | 16+ GB VRAM or 32 GB RAM |

## Quick Start

1. Backend:
```bash
cd ai-platform
python -m venv .venv
source .venv/bin/activate
pip install -r backend/requirements.txt
cp .env.example .env
PYTHONPATH=ai-platform uvicorn backend.app:app --host 0.0.0.0 --port 8090
```

2. Frontend:
```bash
cd ai-platform/frontend
npm install
npm run dev
```

3. CLI (zero-setup):
```bash
pip install --upgrade sage-ai-cli
sage run
```

## Optional Local Model Download (advanced)

```bash
ai --host http://127.0.0.1:8090 download \
  --model-id llama32-q4 \
  --runtime llama_cpp \
  --url https://github.com/abetlen/llama-cpp-python/releases/download/v0.2.90/tinyllama-1.1b-chat-v1.0.Q4_K_M.gguf
```

```bash
ai --host http://127.0.0.1:8090 run llama32-q4 --threads 8
ai --host http://127.0.0.1:8090 chat --model llama32-q4 --temperature 0.2 --max-tokens 512
```

## Privacy

- Sage CLI defaults to pre-trained free models and works right after install.
- Local inference is available if you download local models.
- No telemetry is implemented.
- After model download setup, inference requires no external API calls.
