from pathlib import Path

from pydantic import BaseModel
from pydantic_settings import BaseSettings, SettingsConfigDict

_BASE = Path(__file__).resolve().parent.parent


class RuntimeConfig(BaseModel):
    default_runtime: str = "llama_cpp"
    default_threads: int = 0
    default_temperature: float = 0.3
    default_max_tokens: int = 512
    default_top_p: float = 0.95


class AppSettings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="AI_PLATFORM_", extra="ignore")
    host: str = "0.0.0.0"
    port: int = 8090
    models_dir: Path = _BASE / "models"
    config_dir: Path = _BASE / "config"
    data_dir: Path = _BASE / "data"
    log_level: str = "INFO"

    def ensure_dirs(self) -> None:
        self.models_dir.mkdir(parents=True, exist_ok=True)
        self.config_dir.mkdir(parents=True, exist_ok=True)
        self.data_dir.mkdir(parents=True, exist_ok=True)


settings = AppSettings()
runtime_defaults = RuntimeConfig()
