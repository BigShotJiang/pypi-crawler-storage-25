from .runtimes.llama_cpp_runtime import LlamaCppRuntime
from .runtimes.onnx_runtime import OnnxRuntime
from .runtimes.transformers_runtime import TransformersRuntime
from .runtimes.vllm_runtime import VllmRuntime

RUNTIME_MAP = {
    "llama_cpp": LlamaCppRuntime,
    "transformers": TransformersRuntime,
    "vllm": VllmRuntime,
    "onnx": OnnxRuntime,
}


class RuntimeManager:
    def __init__(self) -> None:
        self.runtime = None
        self.loaded_model_id: str | None = None
        self.loaded_runtime: str | None = None

    def load(
        self, runtime_name: str, model_id: str, model_path: str, threads: int | None
    ) -> None:
        cls = RUNTIME_MAP.get(runtime_name)
        if cls is None:
            raise ValueError(
                f"Unsupported runtime: {runtime_name}. "
                f"Available: {', '.join(RUNTIME_MAP)}"
            )
        runtime = cls()
        runtime.load(model_path, threads=threads)
        self.runtime = runtime
        self.loaded_model_id = model_id
        self.loaded_runtime = runtime_name

    def ensure_loaded(self) -> None:
        if self.runtime is None:
            raise RuntimeError("No model loaded")
