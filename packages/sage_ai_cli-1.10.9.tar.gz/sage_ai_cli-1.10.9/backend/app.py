import json
import logging

import uvicorn
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse

from .auto_updater import AutoUpdater
from .config import runtime_defaults, settings
from .conversations import ConversationStore
from .hardware import detect_hardware_summary
from .model_catalog import (
    filter_by_ram,
    get_recommended_models,
    list_catalog_models,
)
from .model_registry import ModelRegistry
from .runtime_manager import RuntimeManager
from .schemas import (
    AddSourceReq,
    ChatMessage,
    ChatReq,
    CreateConversationReq,
    DownloadModelReq,
    LoadModelReq,
)

settings.ensure_dirs()
logging.basicConfig(level=getattr(logging, settings.log_level.upper(), logging.INFO))
logger = logging.getLogger("ai-platform")

app = FastAPI(title="Local AI Platform", version="3.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

registry = ModelRegistry()
runtime_manager = RuntimeManager()
conversation_store = ConversationStore()
updater = AutoUpdater(registry)


@app.get("/health")
def health():
    return {
        "ok": True,
        "version": "3.0.0",
        "loaded_model_id": runtime_manager.loaded_model_id,
        "loaded_runtime": runtime_manager.loaded_runtime,
    }


@app.get("/hardware")
def hardware():
    return detect_hardware_summary()


@app.get("/models")
def list_models():
    return {"ok": True, "models": [m.model_dump() for m in registry.list_models()]}


@app.get("/models/names")
def model_names():
    names = {m.model_id for m in registry.list_models()}
    for source in updater.list_sources():
        names.add(source.model_id)
    return {"ok": True, "names": sorted(names)}


@app.get("/models/{model_id}")
def get_model(model_id: str):
    try:
        record = registry.get_model(model_id)
    except KeyError:
        raise HTTPException(status_code=404, detail="Model not found")
    return {"ok": True, "model": record.model_dump()}


@app.post("/models/download")
def download_model(req: DownloadModelReq):
    try:
        record = registry.download_and_register(req)
    except ValueError as exc:
        detail = str(exc)
        if "GitHub" in detail or "allowed" in detail:
            detail = f"source not allowed: {detail}"
        raise HTTPException(status_code=400, detail=detail)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))
    return {"ok": True, "model": record.model_dump()}


@app.post("/models/load")
def load_model(req: LoadModelReq):
    try:
        record = registry.get_model(req.model_id)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    try:
        active = record.active()
        threads = (
            req.threads
            or runtime_defaults.default_threads
            or detect_hardware_summary().get("cpu_threads", 1)
        )
        runtime_manager.load(
            record.runtime, req.model_id, active.file_path, threads=threads
        )
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))
    return {
        "ok": True,
        "loaded_model_id": runtime_manager.loaded_model_id,
        "loaded_runtime": runtime_manager.loaded_runtime,
        "threads": threads,
    }


@app.post("/chat")
def chat(req: ChatReq):
    runtime_manager.ensure_loaded()
    if runtime_manager.loaded_model_id != req.model_id:
        raise HTTPException(status_code=400, detail="Requested model is not loaded")
    conv_id = req.conversation_id
    if conv_id:
        for msg in req.messages:
            conversation_store.append_message(conv_id, msg.role, msg.content)

    messages = [
        (
            ChatMessage(**m.model_dump())
            if isinstance(m, ChatMessage)
            else ChatMessage(**m)
        )
        for m in req.messages
    ]

    def stream():
        chunks = []
        for token in runtime_manager.runtime.stream_chat(
            messages,
            temperature=req.temperature,
            max_tokens=req.max_tokens,
        ):
            chunks.append(token)
            yield f"data: {json.dumps({'token': token})}\n\n"
        final = "".join(chunks).strip()
        if conv_id:
            conversation_store.append_message(conv_id, "assistant", final)
        yield f"data: {json.dumps({'done': True, 'conversation_id': conv_id})}\n\n"

    if req.stream:
        return StreamingResponse(stream(), media_type="text/event-stream")
    text = runtime_manager.runtime.chat(
        messages,
        temperature=req.temperature,
        max_tokens=req.max_tokens,
    )
    if conv_id:
        conversation_store.append_message(conv_id, "assistant", text)
    return {"ok": True, "output": text, "conversation_id": conv_id}


@app.post("/conversations")
def create_conversation(req: CreateConversationReq):
    conversation = conversation_store.create(req.title)
    return {"ok": True, "conversation": conversation}


@app.get("/conversations")
def list_conversations():
    return {"ok": True, "conversations": conversation_store.list_all()}


@app.get("/conversations/{conversation_id}")
def get_conversation(conversation_id: str):
    try:
        conversation = conversation_store.get(conversation_id)
    except KeyError:
        raise HTTPException(status_code=404, detail="Conversation not found")
    return {"ok": True, "conversation": conversation}


@app.get("/sources")
def list_sources():
    return {"ok": True, "sources": [s.__dict__ for s in updater.list_sources()]}


@app.post("/sources/add")
def add_source(req: AddSourceReq):
    try:
        source = updater.add_source(
            repo_url=req.repo_url,
            model_id=req.model_id,
            runtime=req.runtime,
            asset_pattern=req.asset_pattern,
            license=req.license,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return {"ok": True, "source": source.__dict__}


@app.delete("/sources/{model_id}")
def remove_source(model_id: str):
    updater.remove_source(model_id)
    return {"ok": True}


@app.get("/catalog")
def catalog():
    return {"ok": True, "models": list_catalog_models()}


@app.get("/catalog/recommended")
def catalog_recommended():
    return {"ok": True, "models": get_recommended_models()}


@app.get("/catalog/fits-ram")
def catalog_fits_ram(max_gb: float):
    return {"ok": True, "models": filter_by_ram(max_gb)}


def main():
    uvicorn.run(app, host="0.0.0.0", port=8080)


if __name__ == "__main__":
    main()
