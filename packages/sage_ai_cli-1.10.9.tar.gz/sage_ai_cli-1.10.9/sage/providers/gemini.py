"""Google Gemini provider — uses the free-tier REST API via httpx."""

from __future__ import annotations

import json
from typing import Iterator

import httpx

from ..config import SageConfig
from .base import Message, ModelInfo, ProviderBase

_BASE_URL = "https://generativelanguage.googleapis.com/v1beta"

# Models available on the Gemini free tier
_FREE_MODELS = [
    ModelInfo(id="gemini-2.0-flash", provider="gemini", name="Gemini 2.0 Flash", local=False),
    ModelInfo(id="gemini-2.5-flash-preview-05-20", provider="gemini", name="Gemini 2.5 Flash Preview", local=False),
    ModelInfo(id="gemini-1.5-flash", provider="gemini", name="Gemini 1.5 Flash", local=False),
]


def _build_payload(
    messages: list[Message],
    temperature: float,
    max_tokens: int,
) -> dict:
    """Convert internal messages to Gemini API format."""
    system_parts: list[dict] = []
    contents: list[dict] = []

    for msg in messages:
        if msg.role == "system":
            system_parts.append({"text": msg.content})
            continue
        # Gemini uses "user" and "model" (not "assistant")
        role = "model" if msg.role == "assistant" else "user"
        contents.append({"role": role, "parts": [{"text": msg.content}]})

    # Gemini requires contents to start with a user turn.
    # If conversation starts with assistant (shouldn't normally), prepend empty user.
    if contents and contents[0]["role"] == "model":
        contents.insert(0, {"role": "user", "parts": [{"text": ""}]})

    payload: dict = {
        "contents": contents,
        "generationConfig": {
            "temperature": temperature,
            "maxOutputTokens": max_tokens,
        },
    }
    if system_parts:
        payload["systemInstruction"] = {"parts": system_parts}
    return payload


def _extract_text(data: dict) -> str:
    """Pull generated text from a Gemini response chunk."""
    try:
        return data["candidates"][0]["content"]["parts"][0]["text"]
    except (KeyError, IndexError, TypeError):
        return ""


class GeminiProvider(ProviderBase):
    """Gemini free-tier provider using the REST API."""

    name = "gemini"

    def __init__(self, config: SageConfig) -> None:
        self._api_key = config.gemini_api_key()

    def is_available(self) -> bool:
        return bool(self._api_key)

    def list_models(self) -> list[ModelInfo]:
        if not self.is_available():
            return []
        return list(_FREE_MODELS)

    def generate(
        self,
        messages: list[Message],
        model: str = "gemini-2.0-flash",
        temperature: float = 0.7,
        max_tokens: int = 2048,
    ) -> str:
        if not self._api_key:
            raise RuntimeError("Gemini API key not configured. Run: sage config set api_keys.gemini YOUR_KEY")

        url = f"{_BASE_URL}/models/{model}:generateContent?key={self._api_key}"
        payload = _build_payload(messages, temperature, max_tokens)

        with httpx.Client(timeout=120) as client:
            resp = client.post(url, json=payload)
            resp.raise_for_status()
            return _extract_text(resp.json())

    def stream(
        self,
        messages: list[Message],
        model: str = "gemini-2.0-flash",
        temperature: float = 0.7,
        max_tokens: int = 2048,
    ) -> Iterator[str]:
        if not self._api_key:
            raise RuntimeError("Gemini API key not configured. Run: sage config set api_keys.gemini YOUR_KEY")

        url = (
            f"{_BASE_URL}/models/{model}:streamGenerateContent"
            f"?alt=sse&key={self._api_key}"
        )
        payload = _build_payload(messages, temperature, max_tokens)

        with httpx.Client(timeout=120) as client:
            with client.stream("POST", url, json=payload) as resp:
                resp.raise_for_status()
                for line in resp.iter_lines():
                    if not line.startswith("data: "):
                        continue
                    try:
                        chunk = json.loads(line[6:])
                    except json.JSONDecodeError:
                        continue
                    text = _extract_text(chunk)
                    if text:
                        yield text
