"""Local GGUF model provider via llama-cpp-python."""

from __future__ import annotations

import platform
from typing import Iterator

from ..config import SageConfig, LocalModel
from .base import Message, ModelInfo, ProviderBase


class LlamaCppProvider(ProviderBase):
    """Runs GGUF models locally through llama-cpp-python."""

    name = "llama_cpp"

    def __init__(self, config: SageConfig) -> None:
        self._config = config
        self._loaded_name: str | None = None
        self._model: object | None = None  # Llama instance (lazy import)

    def is_available(self) -> bool:
        try:
            import llama_cpp as _  # noqa: F401
        except ImportError:
            return False
        return len(self._config.local_model_names()) > 0

    def list_models(self) -> list[ModelInfo]:
        try:
            import llama_cpp as _  # noqa: F401
        except ImportError:
            return []
        return [
            ModelInfo(
                id=name,
                provider="llama_cpp",
                name=name,
                local=True,
            )
            for name in self._config.local_model_names()
        ]

    def _ensure_loaded(self, model_name: str) -> None:
        """Load the model if not already loaded (or if a different model is requested)."""
        if self._loaded_name == model_name and self._model is not None:
            return

        entry: LocalModel | None = self._config.get_local_model(model_name)
        if entry is None:
            raise RuntimeError(
                f"Model '{model_name}' not registered. "
                f"Run: sage config set models.{model_name}.path /path/to/model.gguf"
            )

        from llama_cpp import Llama

        kwargs: dict = {
            "model_path": entry.path,
            "n_ctx": 16384,
            "n_batch": 1024,
            "verbose": False,
        }
        # Disable GPU on x86_64 macOS (Rosetta) — Metal requires arm64
        if platform.system() == "Darwin" and platform.machine() == "x86_64":
            kwargs["n_gpu_layers"] = 0
        if entry.threads:
            kwargs["n_threads"] = entry.threads

        self._model = Llama(**kwargs)
        self._loaded_name = model_name

    def _to_chat_messages(self, messages: list[Message]) -> list[dict]:
        return [{"role": m.role, "content": m.content} for m in messages]

    def generate(
        self,
        messages: list[Message],
        model: str = "",
        temperature: float = 0.7,
        max_tokens: int = 2048,
    ) -> str:
        name = model or self._first_model()
        self._ensure_loaded(name)
        result = self._model.create_chat_completion(  # type: ignore[union-attr]
            messages=self._to_chat_messages(messages),
            temperature=temperature,
            max_tokens=max_tokens,
            stream=False,
        )
        return result["choices"][0]["message"]["content"]

    def stream(
        self,
        messages: list[Message],
        model: str = "",
        temperature: float = 0.7,
        max_tokens: int = 2048,
    ) -> Iterator[str]:
        name = model or self._first_model()
        self._ensure_loaded(name)
        chunks = self._model.create_chat_completion(  # type: ignore[union-attr]
            messages=self._to_chat_messages(messages),
            temperature=temperature,
            max_tokens=max_tokens,
            stream=True,
        )
        for chunk in chunks:
            delta = chunk["choices"][0].get("delta", {})
            text = delta.get("content")
            if text:
                yield text

    def _first_model(self) -> str:
        names = self._config.local_model_names()
        if not names:
            raise RuntimeError("No local models registered. Run: sage config set models.<name>.path /path/to/model.gguf")
        return names[0]
