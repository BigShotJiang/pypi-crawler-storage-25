"""Configuration management for Sage CLI.

Config lives at ~/.sage/config.json with environment variable overrides.

Environment variables:
    SAGE_DEFAULT_MODEL      — Override default model (e.g. "gemini:gemini-2.0-flash")
    SAGE_GEMINI_API_KEY     — Google Gemini API key
    SAGE_GROQ_API_KEY       — Groq API key (free: console.groq.com)
    SAGE_OPENROUTER_API_KEY — OpenRouter API key (free models available)
    SAGE_CEREBRAS_API_KEY   — Cerebras API key (free: cloud.cerebras.ai)
    SAGE_SAMBANOVA_API_KEY  — SambaNova API key (free: cloud.sambanova.ai)
    SAGE_TOGETHER_API_KEY   — Together AI API key (free tier)
    SAGE_MISTRAL_API_KEY    — Mistral API key (free tier: console.mistral.ai)
    SAGE_COHERE_API_KEY     — Cohere API key (free: dashboard.cohere.com)
    SAGE_DEEPSEEK_API_KEY   — DeepSeek API key (cheap: platform.deepseek.com)
    GITHUB_TOKEN            — GitHub token for GitHub Models (free)
    SAGE_TEMPERATURE        — Default temperature (0.0–2.0)
    SAGE_MAX_TOKENS         — Default max output tokens
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any

SAGE_DIR = Path.home() / ".sage"
CONFIG_PATH = SAGE_DIR / "config.json"

# Env var → config key mapping
_ENV_MAP: dict[str, tuple[str, type]] = {
    "SAGE_DEFAULT_MODEL": ("default_model", str),
    "SAGE_GEMINI_API_KEY": ("api_keys.gemini", str),
    "SAGE_GROQ_API_KEY": ("api_keys.groq", str),
    "SAGE_OPENROUTER_API_KEY": ("api_keys.openrouter", str),
    "SAGE_CEREBRAS_API_KEY": ("api_keys.cerebras", str),
    "SAGE_SAMBANOVA_API_KEY": ("api_keys.sambanova", str),
    "SAGE_TOGETHER_API_KEY": ("api_keys.together", str),
    "SAGE_MISTRAL_API_KEY": ("api_keys.mistral", str),
    "SAGE_COHERE_API_KEY": ("api_keys.cohere", str),
    "SAGE_DEEPSEEK_API_KEY": ("api_keys.deepseek", str),
    "GITHUB_TOKEN": ("api_keys.github", str),
    "SAGE_TEMPERATURE": ("temperature", float),
    "SAGE_MAX_TOKENS": ("max_tokens", int),
}


@dataclass
class LocalModel:
    """A registered local GGUF model."""

    path: str
    provider: str = "llama_cpp"
    threads: int | None = None


@dataclass
class SageConfig:
    """Full configuration state."""

    default_model: str = "pollinations:qwen2.5-coder-3b"
    temperature: float = 0.7
    max_tokens: int = 2048
    system_prompt: str = ""
    api_keys: dict[str, str] = field(default_factory=dict)
    models: dict[str, dict[str, Any]] = field(default_factory=dict)

    # ── Serialization ───────────────────────────────────────

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SageConfig:
        return cls(
            default_model=data.get("default_model", cls.default_model),
            temperature=data.get("temperature", cls.temperature),
            max_tokens=data.get("max_tokens", cls.max_tokens),
            system_prompt=data.get("system_prompt", cls.system_prompt),
            api_keys=data.get("api_keys", {}),
            models=data.get("models", {}),
        )

    # ── Convenience accessors ───────────────────────────────

    def gemini_api_key(self) -> str | None:
        return self.api_keys.get("gemini") or None

    def get_local_model(self, name: str) -> LocalModel | None:
        entry = self.models.get(name)
        if not entry:
            return None
        return LocalModel(
            path=entry["path"],
            provider=entry.get("provider", "llama_cpp"),
            threads=entry.get("threads"),
        )

    def local_model_names(self) -> list[str]:
        return list(self.models.keys())


# ── Load / Save ─────────────────────────────────────────────


def _ensure_dir() -> None:
    SAGE_DIR.mkdir(parents=True, exist_ok=True)


def load_config(path: Path = CONFIG_PATH) -> SageConfig:
    """Load config from disk, then apply environment variable overrides."""
    if path.exists():
        try:
            data = json.loads(path.read_text("utf-8"))
        except (json.JSONDecodeError, OSError):
            data = {}
    else:
        data = {}

    cfg = SageConfig.from_dict(data)
    _apply_env_overrides(cfg)
    return cfg


def save_config(cfg: SageConfig, path: Path = CONFIG_PATH) -> None:
    """Persist config to disk."""
    _ensure_dir()
    path.write_text(json.dumps(cfg.to_dict(), indent=2) + "\n", "utf-8")


def _apply_env_overrides(cfg: SageConfig) -> None:
    """Apply SAGE_* environment variables on top of loaded config."""
    for env_var, (key, cast) in _ENV_MAP.items():
        value = os.environ.get(env_var)
        if value is None:
            continue
        if "." in key:
            # Nested key like "api_keys.gemini"
            parts = key.split(".", 1)
            container = getattr(cfg, parts[0])
            container[parts[1]] = cast(value)
        else:
            setattr(cfg, key, cast(value))


def set_config_value(key: str, value: str, path: Path = CONFIG_PATH) -> None:
    """Set a single config key and save. Supports dot notation for nested keys."""
    cfg = load_config(path)

    if key == "default_model":
        cfg.default_model = value
    elif key == "temperature":
        cfg.temperature = float(value)
    elif key == "max_tokens":
        cfg.max_tokens = int(value)
    elif key == "system_prompt":
        cfg.system_prompt = value
    elif key.startswith("api_keys."):
        subkey = key.split(".", 1)[1]
        cfg.api_keys[subkey] = value
    elif key.startswith("models."):
        # models.deepseek.path = /path/to/file
        parts = key.split(".", 2)
        if len(parts) == 3:
            model_name, field_name = parts[1], parts[2]
            if model_name not in cfg.models:
                cfg.models[model_name] = {"path": "", "provider": "llama_cpp"}
            cfg.models[model_name][field_name] = value
    else:
        raise KeyError(f"Unknown config key: {key}")

    save_config(cfg, path)


def get_config_value(key: str, path: Path = CONFIG_PATH) -> Any:
    """Read a single config value. Supports dot notation."""
    cfg = load_config(path)

    if key == "default_model":
        return cfg.default_model
    elif key == "temperature":
        return cfg.temperature
    elif key == "max_tokens":
        return cfg.max_tokens
    elif key == "system_prompt":
        return cfg.system_prompt
    elif key.startswith("api_keys."):
        subkey = key.split(".", 1)[1]
        return cfg.api_keys.get(subkey)
    elif key.startswith("models."):
        parts = key.split(".", 2)
        model_name = parts[1]
        if len(parts) == 3:
            return (cfg.models.get(model_name) or {}).get(parts[2])
        return cfg.models.get(model_name)
    else:
        raise KeyError(f"Unknown config key: {key}")
