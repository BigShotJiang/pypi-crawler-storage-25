"""Terminal rendering — Rich markdown, code highlighting, streaming display, status indicators."""

from __future__ import annotations

import signal
import sys
import time
from contextlib import contextmanager
from typing import Iterator

from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.text import Text
from rich.live import Live
from rich.spinner import Spinner
from rich.columns import Columns
from rich.rule import Rule
from rich.table import Table


console = Console()
err_console = Console(stderr=True)


# ── Phase & Status Display ─────────────────────────────────


# Phase icons and colors for the agent workflow
_PHASE_STYLES = {
    "thinking": ("bold yellow", "⟡"),
    "planning": ("bold blue", "◈"),
    "reading": ("bold cyan", "◉"),
    "coding": ("bold magenta", "◆"),
    "writing": ("bold green", "▶"),
    "testing": ("bold yellow", "⧫"),
    "fixing": ("bold red", "⟐"),
    "executing": ("bold cyan", "▷"),
    "validating": ("bold yellow", "◇"),
    "done": ("bold green", "✓"),
    "error": ("bold red", "✗"),
}


def phase(name: str, detail: str = "") -> None:
    """Print a phase indicator with icon and optional detail."""
    style, icon = _PHASE_STYLES.get(name, ("dim", "·"))
    detail_str = f"  [dim]{detail}[/dim]" if detail else ""
    console.print(f"  [{style}]{icon} {name.capitalize()}[/{style}]{detail_str}")


@contextmanager
def status_spinner(message: str, phase_name: str = "thinking"):
    """Context manager that shows a Rich spinner with a message.

    Usage:
        with status_spinner("Analyzing your request..."):
            do_work()
    """
    style, icon = _PHASE_STYLES.get(phase_name, ("dim", "·"))
    spinner = Spinner(
        "dots", text=Text.from_markup(f"  [{style}]{icon} {message}[/{style}]")
    )
    with Live(spinner, console=console, refresh_per_second=12, transient=True):
        yield


def step(number: int, total: int, description: str, style: str = "bold cyan") -> None:
    """Print a numbered step indicator."""
    console.print(
        f"  [{style}]Step {number}/{total}[/{style}] [dim]─[/dim] {description}"
    )


def step_done(description: str) -> None:
    """Print a completed step."""
    console.print(f"  [green]✓[/green] {description}")


def step_fail(description: str) -> None:
    """Print a failed step."""
    console.print(f"  [red]✗[/red] {description}")


def divider(title: str = "", style: str = "dim") -> None:
    """Print a horizontal divider."""
    if title:
        console.print(Rule(title, style=style))
    else:
        console.print(Rule(style=style))


# ── Streaming with stats ───────────────────────────────────


def stream_tokens(tokens: Iterator[str], show_stats: bool = True) -> str:
    """Print tokens to stdout in real-time and return the full text.

    Tracks timing and token count for display after streaming completes.
    Ctrl+C cancels generation and returns what was collected so far.
    """
    parts: list[str] = []
    token_count = 0
    t0 = time.monotonic()
    cancelled = False

    try:
        for token in tokens:
            sys.stdout.write(token)
            sys.stdout.flush()
            parts.append(token)
            token_count += 1
    except KeyboardInterrupt:
        cancelled = True

    elapsed = time.monotonic() - t0
    sys.stdout.write("\n")
    sys.stdout.flush()

    if cancelled:
        console.print("  [dim yellow]─ Cancelled (Ctrl+C)[/dim yellow]")
    elif show_stats and token_count > 0 and elapsed > 0.1:
        tps = token_count / elapsed if elapsed > 0 else 0
        console.print(
            f"  [dim]─ {token_count} tokens · {elapsed:.1f}s · {tps:.0f} tok/s[/dim]"
        )

    return "".join(parts)


def stream_tokens_with_phase(tokens: Iterator[str], model_id: str = "") -> str:
    """Stream tokens with a thinking spinner that transitions to output.

    Shows 'Thinking...' spinner until first token arrives, then streams normally.
    Ctrl+C cancels generation at any point — during thinking or streaming.

    Uses a SIGINT handler to reliably catch Ctrl+C even inside Rich.Live,
    which can swallow KeyboardInterrupt in its refresh thread.
    """
    parts: list[str] = []
    token_count = 0
    t0 = time.monotonic()
    first_token_time = None
    cancelled = False

    # Install a SIGINT handler that sets a flag — Rich.Live can swallow
    # KeyboardInterrupt, but our handler always fires.
    _sigint_received = False
    _original_handler = signal.getsignal(signal.SIGINT)

    def _handle_sigint(signum, frame):
        nonlocal _sigint_received
        _sigint_received = True

    signal.signal(signal.SIGINT, _handle_sigint)

    # Show thinking spinner
    spinner = Spinner(
        "dots",
        text=Text.from_markup(
            f"  [bold yellow]⟡ Thinking...[/bold yellow]  [dim](Ctrl+C to cancel)[/dim]"
            + (f"  [dim]({model_id})[/dim]" if model_id else "")
        ),
    )
    live = Live(spinner, console=console, refresh_per_second=12, transient=True)
    live.start()

    try:
        for token in tokens:
            if _sigint_received:
                cancelled = True
                break

            if first_token_time is None:
                first_token_time = time.monotonic()
                # Kill the spinner, print the sage prompt
                live.stop()
                ttft = first_token_time - t0
                console.print(f"  [dim]─ First token in {ttft:.1f}s[/dim]")
                console.print("[bold green]sage>[/bold green] ", end="")

            sys.stdout.write(token)
            sys.stdout.flush()
            parts.append(token)
            token_count += 1

            if _sigint_received:
                cancelled = True
                break
    except KeyboardInterrupt:
        cancelled = True
    finally:
        if live.is_started:
            live.stop()
        # Restore the original signal handler
        signal.signal(signal.SIGINT, _original_handler)

    elapsed = time.monotonic() - t0
    sys.stdout.write("\n")
    sys.stdout.flush()

    if cancelled:
        console.print("  [dim yellow]─ Cancelled (Ctrl+C)[/dim yellow]")
    elif token_count > 0 and elapsed > 0.1:
        tps = token_count / elapsed if elapsed > 0 else 0
        console.print(
            f"  [dim]─ {token_count} tokens · {elapsed:.1f}s · {tps:.0f} tok/s[/dim]"
        )

    return "".join(parts)


# ── File operation display ─────────────────────────────────


def print_files_written(files: list[str]) -> None:
    """Print a styled list of written files."""
    console.print()
    phase("writing", f"{len(files)} file(s)")
    for f in files:
        console.print(f"    [green]+ {f}[/green]")


def print_files_deleted(files: list[str]) -> None:
    """Print a styled list of deleted files."""
    for f in files:
        console.print(f"    [red]- {f}[/red]")


def print_file_read(filepath: str, line_count: int) -> None:
    """Print a styled file-read indicator."""
    phase("reading", f"{filepath} ({line_count} lines)")


# ── Test result display ────────────────────────────────────


def print_test_results(output: str, passed: bool) -> None:
    """Print test results with pass/fail styling."""
    if passed:
        console.print()
        phase("done", "All tests passed")
        # Extract summary line if present
        for line in output.splitlines():
            if "passed" in line.lower():
                console.print(f"    [green]{line.strip()}[/green]")
                break
    else:
        console.print()
        phase("error", "Tests failed")
        # Show the failure summary
        in_failures = False
        shown = 0
        for line in output.splitlines():
            if "FAILED" in line or "ERROR" in line:
                console.print(f"    [red]{line.strip()}[/red]")
                shown += 1
            elif "short test summary" in line.lower():
                in_failures = True
            elif in_failures and line.strip() and shown < 10:
                console.print(f"    [red]{line.strip()}[/red]")
                shown += 1


def print_validation_start(cmd: str) -> None:
    """Print the start of a validation step."""
    console.print()
    phase("validating", cmd)


def print_retry(attempt: int, max_retries: int) -> None:
    """Print a retry indicator."""
    console.print()
    phase("fixing", f"Auto-fixing (attempt {attempt}/{max_retries})")


# ── Command execution display ──────────────────────────────


def print_shell_start(cmd: str) -> None:
    """Print shell command being executed."""
    phase("executing", cmd[:100] + ("..." if len(cmd) > 100 else ""))


def print_shell_output(output: str, max_lines: int = 30) -> None:
    """Print shell output, truncated if too long."""
    lines = output.splitlines()
    if len(lines) > max_lines:
        for line in lines[:10]:
            console.print(f"    [dim]{line}[/dim]")
        console.print(f"    [dim]... ({len(lines) - 20} lines hidden) ...[/dim]")
        for line in lines[-10:]:
            console.print(f"    [dim]{line}[/dim]")
    else:
        for line in lines:
            console.print(f"    [dim]{line}[/dim]")


# ── Existing functions (upgraded) ──────────────────────────


def render_markdown(text: str) -> None:
    """Render a complete response as Rich Markdown with code highlighting."""
    console.print(Markdown(text))


def print_model_table(models: list[dict]) -> None:
    """Print a formatted table of available models."""
    table = Table(title="Available Models", show_lines=False)
    table.add_column("Model ID", style="cyan bold")
    table.add_column("Provider", style="green")
    table.add_column("Name", style="white")
    table.add_column("Type", style="yellow")

    for m in models:
        table.add_row(
            m["id"],
            m["provider"],
            m["name"],
            "local" if m["local"] else "API",
        )
    console.print(table)


def print_catalog_table(models: list[dict], show_status: bool = True) -> None:
    """Print a formatted table of models from the catalog."""
    table = Table(title="Downloadable Models", show_lines=False)
    table.add_column("Name", style="cyan bold")
    table.add_column("Size", style="yellow", justify="right")
    table.add_column("Params", style="green")
    table.add_column("Family", style="magenta")
    table.add_column("Description", style="white")
    if show_status:
        table.add_column("Status", style="bold")

    for m in models:
        row = [m["name"], m["size"], m["params"], m["family"], m["description"]]
        if show_status:
            row.append(m.get("status", ""))
        table.add_row(*row)
    console.print(table)


def print_download_complete(name: str, path: str, size_gb: float) -> None:
    """Print a success message after a model download."""
    console.print()
    console.print(
        Panel(
            f"[bold green]Downloaded:[/bold green] {name}\n"
            f"[dim]Path:[/dim] {path}\n"
            f"[dim]Size:[/dim] {size_gb:.1f} GB\n\n"
            f"Run with: [bold cyan]sage run --model llama_cpp:{name}[/bold cyan]",
            title="Model Ready",
            border_style="green",
        )
    )


def print_config(data: dict) -> None:
    """Pretty-print config as a panel."""
    import json

    text = json.dumps(data, indent=2)
    console.print(Panel(text, title="~/.sage/config.json", border_style="dim"))


def info(msg: str) -> None:
    """Print an info message."""
    console.print(f"[dim]{msg}[/dim]")


def success(msg: str) -> None:
    """Print a success message."""
    console.print(f"[green]{msg}[/green]")


def error(msg: str) -> None:
    """Print an error message to stderr."""
    err_console.print(f"[red bold]Error:[/red bold] {msg}")


def warning(msg: str) -> None:
    """Print a warning to stderr."""
    err_console.print(f"[yellow]Warning:[/yellow] {msg}")


def print_welcome(model_id: str) -> None:
    """Print the REPL welcome banner."""
    console.print(
        Panel(
            Text.from_markup(
                f"[bold cyan]Sage[/bold cyan] — local-first AI assistant\n"
                f"[dim]Model: {model_id}[/dim]\n\n"
                f"[dim]Commands: /help /clear /model /system /exit[/dim]\n"
                f'[dim]Multi-line: start with """ and end with """[/dim]'
            ),
            border_style="cyan",
        )
    )


def print_help() -> None:
    """Print REPL command reference."""
    help_text = (
        "[bold]Commands:[/bold]\n"
        "  [cyan]/help[/cyan]           Show this help\n"
        "  [cyan]/clear[/cyan]          Clear conversation history\n"
        "  [cyan]/model[/cyan] [id]     Show or change active model\n"
        "  [cyan]/system[/cyan] [text]  Show or set system prompt\n"
        "  [cyan]/history[/cyan]        Show conversation turn count\n"
        "  [cyan]/exit[/cyan]           Quit\n"
    )
    console.print(Panel(help_text, title="Help", border_style="dim"))


def print_agent_welcome(model_id: str, cwd: str) -> None:
    """Print the agent-mode welcome banner."""
    console.print()
    console.print(
        Panel(
            Text.from_markup(
                f"[bold cyan]  ╔═╗┌─┐┌─┐┌─┐[/bold cyan]\n"
                f"[bold cyan]  ╚═╗├─┤│ ┬├┤ [/bold cyan]\n"
                f"[bold cyan]  ╚═╝┴ ┴└─┘└─┘[/bold cyan]\n"
                f"\n"
                f"  [bold]Autonomous AI Coding Agent[/bold]\n"
                f"\n"
                f"  [dim]Model:[/dim]  {model_id}\n"
                f"  [dim]Dir:[/dim]    {cwd}\n"
                f"\n"
                f"  [dim]Sage plans, writes code, runs tests, and auto-fixes failures.[/dim]\n"
                f"  [dim]Watch each step as it happens in real time.[/dim]\n"
                f"\n"
                f"  [dim cyan]Commands:[/dim cyan] /help /models /prompts /autopolit /think /test /read /files /compact /clear /exit\n"
                f'  [dim cyan]Shell:[/dim cyan]    !<command>    [dim cyan]Multi-line:[/dim cyan] """..."""\n'
                f"  [dim cyan]Models:[/dim cyan]   sage pull --list    sage pull <name>"
            ),
            border_style="cyan",
            padding=(0, 2),
        )
    )
    console.print()


def print_agent_help() -> None:
    """Print agent-mode command reference."""
    help_text = (
        "[bold]Agent Commands:[/bold]\n"
        "  [cyan]/help[/cyan]           Show this help\n"
        "  [cyan]/models[/cyan]         List all available AI models\n"
        "  [cyan]/prompts[/cyan]        Browse and reuse previous prompts\n"
        "  [cyan]/autopolit[/cyan] [n]  Endless autonomous loop (optional max cycles)\n"
        "  [cyan]/think[/cyan] <task>   Force step-by-step planning before implementing\n"
        "  [cyan]/read[/cyan] <file>    Read a file into conversation context\n"
        "  [cyan]/test[/cyan] [cmd]     Run tests (default: pytest -v --tb=short)\n"
        "  [cyan]/files[/cyan]          Show all written files this session\n"
        "  [cyan]/undo[/cyan]           Delete last written files\n"
        "  [cyan]/compact[/cyan]        Trim conversation to free context space\n"
        "  [cyan]/clear[/cyan]          Clear conversation + file history\n"
        "  [cyan]/model[/cyan] [id]     Show or change active model\n"
        "  [cyan]/history[/cyan]        Show conversation turns + recent prompts\n"
        "  [cyan]/exit[/cyan]           Quit\n"
        "\n[bold]Shell:[/bold]\n"
        "  [cyan]!<command>[/cyan]      Run a shell command (e.g. !python test.py)\n"
        "\n[bold]Download Models (no API key needed):[/bold]\n"
        "  [cyan]sage pull --list[/cyan]          See all downloadable models\n"
        "  [cyan]sage pull <name>[/cyan]           Download a model\n"
        "  [cyan]sage pull --search code[/cyan]    Find code-focused models\n"
        "  [cyan]sage pull --recommended[/cyan]    Top picks for getting started\n"
        "\n[bold]How Sage Works:[/bold]\n"
        "  [dim]⟡ Thinking[/dim]     Analyzing your request\n"
        "  [dim]◈ Planning[/dim]     Breaking the task into steps\n"
        "  [dim]◆ Coding[/dim]       Generating code\n"
        "  [dim]▶ Writing[/dim]      Saving files to disk\n"
        "  [dim]⧫ Testing[/dim]      Running tests automatically\n"
        "  [dim]⟐ Fixing[/dim]       Auto-fixing failures\n"
        "  [dim]✓ Done[/dim]         Task complete\n"
        "\n[bold]Flags:[/bold]\n"
        "  [dim]--auto-run       Skip bash execution prompts[/dim]\n"
        "  [dim]--max-retries N  Auto-fix retry limit (default: 10)[/dim]\n"
        "\n[bold]Autopolit Controls:[/bold]\n"
        "  [dim]Ctrl+C once      Stop after current task finishes[/dim]\n"
        "  [dim]Ctrl+C twice     Cancel immediately[/dim]\n"
    )
    console.print(Panel(help_text, title="Agent Help", border_style="dim"))
