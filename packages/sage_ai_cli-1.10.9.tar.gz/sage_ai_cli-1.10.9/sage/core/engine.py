"""Conversation engine — manages message history, system prompts, and context limits."""

from __future__ import annotations

from sage.providers.base import Message


class ConversationEngine:
    """Maintains multi-turn conversation state.

    Responsibilities:
      - Store message history (system + user + assistant turns)
      - Enforce context window limits by truncating oldest messages
      - Provide the full message list for each provider call
    """

    def __init__(
        self,
        system_prompt: str = "",
        max_history: int = 50,
    ) -> None:
        self._system_prompt = system_prompt
        self._max_history = max_history
        self._messages: list[Message] = []

    # ── Public API ──────────────────────────────────────────

    @property
    def system_prompt(self) -> str:
        return self._system_prompt

    @system_prompt.setter
    def system_prompt(self, value: str) -> None:
        self._system_prompt = value

    def add_user(self, content: str) -> None:
        """Append a user message."""
        self._messages.append(Message(role="user", content=content))
        self._trim()

    def add_assistant(self, content: str) -> None:
        """Append an assistant response."""
        self._messages.append(Message(role="assistant", content=content))
        self._trim()

    def build_messages(self) -> list[Message]:
        """Return the full message list to send to a provider.

        Includes the system prompt (if set) as the first message,
        followed by conversation history.
        """
        out: list[Message] = []
        if self._system_prompt:
            out.append(Message(role="system", content=self._system_prompt))
        out.extend(self._messages)
        return out

    def clear(self) -> None:
        """Reset conversation history (keeps system prompt)."""
        self._messages.clear()

    @property
    def history(self) -> list[Message]:
        """Read-only view of conversation history (excludes system prompt)."""
        return list(self._messages)

    @property
    def turn_count(self) -> int:
        """Number of user messages in history."""
        return sum(1 for m in self._messages if m.role == "user")

    # ── Internal ────────────────────────────────────────────

    def _trim(self) -> None:
        """Drop oldest messages if history exceeds the limit.

        Always keeps messages in pairs (user + assistant) to avoid
        sending orphaned turns to the model.
        """
        while len(self._messages) > self._max_history:
            # Drop from the front — remove two messages (a full turn)
            if len(self._messages) >= 2:
                self._messages.pop(0)
                self._messages.pop(0)
            else:
                self._messages.pop(0)
