"""Model downloader with progress bar support.

Downloads GGUF models from HuggingFace to ~/.sage/models/
and auto-registers them in the Sage config.
"""

from __future__ import annotations

import os
from pathlib import Path

import httpx

from sage.config import SAGE_DIR, load_config, save_config
from sage.models.catalog import CatalogModel

MODELS_DIR = SAGE_DIR / "models"


def models_dir() -> Path:
    """Return the models directory, creating it if needed."""
    MODELS_DIR.mkdir(parents=True, exist_ok=True)
    return MODELS_DIR


def model_path(model: CatalogModel) -> Path:
    """Return the expected local path for a catalog model."""
    return models_dir() / model.filename


def is_downloaded(model: CatalogModel) -> bool:
    """Check if a model is already downloaded."""
    p = model_path(model)
    return p.exists() and p.stat().st_size > 0


def download_model(
    model: CatalogModel,
    progress_callback: callable | None = None,
) -> Path:
    """Download a GGUF model to ~/.sage/models/.

    Args:
        model: The catalog model to download.
        progress_callback: Optional callback(downloaded_bytes, total_bytes)
            called periodically during download.

    Returns:
        Path to the downloaded file.

    Raises:
        httpx.HTTPStatusError: If the download fails.
        OSError: If writing to disk fails.
    """
    dest = model_path(model)

    # Support resuming partial downloads
    downloaded = 0
    headers: dict[str, str] = {}
    if dest.exists():
        downloaded = dest.stat().st_size
        headers["Range"] = f"bytes={downloaded}-"

    with httpx.Client(follow_redirects=True, timeout=httpx.Timeout(30.0, read=300.0)) as client:
        with client.stream("GET", model.url, headers=headers) as response:
            # If we get 416 (Range Not Satisfiable), file is complete
            if response.status_code == 416:
                return dest

            # For range requests, expect 206; for full downloads, expect 200
            if response.status_code not in (200, 206):
                response.raise_for_status()

            # If server doesn't support range (returns 200 instead of 206),
            # restart from scratch
            if downloaded > 0 and response.status_code == 200:
                downloaded = 0

            total = None
            content_length = response.headers.get("content-length")
            if content_length:
                total = int(content_length) + downloaded

            mode = "ab" if response.status_code == 206 else "wb"
            with open(dest, mode) as f:
                for chunk in response.iter_bytes(chunk_size=1024 * 256):
                    f.write(chunk)
                    downloaded += len(chunk)
                    if progress_callback and total:
                        progress_callback(downloaded, total)

    return dest


def register_model(model: CatalogModel) -> None:
    """Register a downloaded model in the Sage config so it's available via llama_cpp."""
    cfg = load_config()
    cfg.models[model.name] = {
        "path": str(model_path(model)),
        "provider": "llama_cpp",
    }
    # If the user still has the factory default, switch to local model
    if cfg.default_model == "pollinations:qwen2.5-coder-3b":
        cfg.default_model = f"llama_cpp:{model.name}"
    save_config(cfg)


def unregister_model(name: str) -> None:
    """Remove a model from config and optionally delete the file."""
    cfg = load_config()
    cfg.models.pop(name, None)
    if cfg.default_model == f"llama_cpp:{name}":
        cfg.default_model = "pollinations:qwen2.5-coder-3b"
    save_config(cfg)


def list_downloaded() -> list[tuple[str, Path]]:
    """Return list of (model_name, path) for all downloaded models."""
    cfg = load_config()
    result = []
    for name, entry in cfg.models.items():
        p = Path(entry.get("path", ""))
        if p.exists():
            result.append((name, p))
    return result


def delete_model(name: str) -> bool:
    """Delete a downloaded model file and unregister it."""
    cfg = load_config()
    entry = cfg.models.get(name)
    if entry:
        p = Path(entry.get("path", ""))
        if p.exists():
            p.unlink()
        unregister_model(name)
        return True
    return False
