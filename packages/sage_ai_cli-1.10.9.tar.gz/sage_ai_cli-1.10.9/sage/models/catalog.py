"""Curated catalog of downloadable GGUF models for local inference.

All models here are free, open-weight, and verified accessible from HuggingFace
in GGUF format (Q4_K_M quantization for CPU-friendly inference).
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class CatalogModel:
    """A downloadable model entry."""

    name: str  # Short CLI name (e.g. "gemma3-4b")
    display_name: str  # Human-readable name
    filename: str  # GGUF filename
    url: str  # Direct download URL
    size_gb: float  # Approximate file size in GB
    params: str  # Parameter count (e.g. "4B")
    family: str  # Model family (e.g. "Gemma")
    description: str  # Short description


# ── HuggingFace base URL helper ────────────────────────────

def _hf_url(repo: str, filename: str) -> str:
    return f"https://huggingface.co/{repo}/resolve/main/{filename}"


# ── Model Catalog (all verified accessible without auth) ───

MODEL_CATALOG: list[CatalogModel] = [
    # ── Meta Llama ──────────────────────────────────────────
    CatalogModel(
        name="llama3.2-1b",
        display_name="Llama 3.2 1B",
        filename="Llama-3.2-1B-Instruct-Q4_K_M.gguf",
        url=_hf_url("bartowski/Llama-3.2-1B-Instruct-GGUF", "Llama-3.2-1B-Instruct-Q4_K_M.gguf"),
        size_gb=0.8,
        params="1B",
        family="Llama",
        description="Meta's tiny Llama — fast, good for simple coding",
    ),
    CatalogModel(
        name="llama3.2-3b",
        display_name="Llama 3.2 3B",
        filename="Llama-3.2-3B-Instruct-Q4_K_M.gguf",
        url=_hf_url("bartowski/Llama-3.2-3B-Instruct-GGUF", "Llama-3.2-3B-Instruct-Q4_K_M.gguf"),
        size_gb=2.0,
        params="3B",
        family="Llama",
        description="Meta Llama 3.2 3B — solid coding ability",
    ),
    CatalogModel(
        name="llama3.1-8b",
        display_name="Llama 3.1 8B",
        filename="Meta-Llama-3.1-8B-Instruct-Q4_K_M.gguf",
        url=_hf_url("bartowski/Meta-Llama-3.1-8B-Instruct-GGUF", "Meta-Llama-3.1-8B-Instruct-Q4_K_M.gguf"),
        size_gb=4.9,
        params="8B",
        family="Llama",
        description="Meta Llama 3.1 8B — strong general + coding",
    ),
    # ── Alibaba Qwen (Coder) ───────────────────────────────
    CatalogModel(
        name="qwen2.5-coder-1.5b",
        display_name="Qwen 2.5 Coder 1.5B",
        filename="Qwen2.5-Coder-1.5B-Instruct-Q4_K_M.gguf",
        url=_hf_url("bartowski/Qwen2.5-Coder-1.5B-Instruct-GGUF", "Qwen2.5-Coder-1.5B-Instruct-Q4_K_M.gguf"),
        size_gb=1.1,
        params="1.5B",
        family="Qwen",
        description="Alibaba's coding model — best code quality for its size",
    ),
    CatalogModel(
        name="qwen2.5-coder-3b",
        display_name="Qwen 2.5 Coder 3B",
        filename="Qwen2.5-Coder-3B-Instruct-Q4_K_M.gguf",
        url=_hf_url("bartowski/Qwen2.5-Coder-3B-Instruct-GGUF", "Qwen2.5-Coder-3B-Instruct-Q4_K_M.gguf"),
        size_gb=2.0,
        params="3B",
        family="Qwen",
        description="Qwen Coder 3B — excellent code generation",
    ),
    CatalogModel(
        name="qwen2.5-coder-7b",
        display_name="Qwen 2.5 Coder 7B",
        filename="Qwen2.5-Coder-7B-Instruct-Q4_K_M.gguf",
        url=_hf_url("bartowski/Qwen2.5-Coder-7B-Instruct-GGUF", "Qwen2.5-Coder-7B-Instruct-Q4_K_M.gguf"),
        size_gb=4.7,
        params="7B",
        family="Qwen",
        description="Qwen Coder 7B — top-tier coding, rivals GPT-3.5",
    ),
    CatalogModel(
        name="qwen2.5-7b",
        display_name="Qwen 2.5 7B",
        filename="Qwen2.5-7B-Instruct-Q4_K_M.gguf",
        url=_hf_url("bartowski/Qwen2.5-7B-Instruct-GGUF", "Qwen2.5-7B-Instruct-Q4_K_M.gguf"),
        size_gb=4.7,
        params="7B",
        family="Qwen",
        description="Qwen 2.5 7B — strong general-purpose + reasoning",
    ),
    # ── DeepSeek ────────────────────────────────────────────
    CatalogModel(
        name="deepseek-r1-1.5b",
        display_name="DeepSeek R1 Distill Qwen 1.5B",
        filename="DeepSeek-R1-Distill-Qwen-1.5B-Q4_K_M.gguf",
        url=_hf_url("bartowski/DeepSeek-R1-Distill-Qwen-1.5B-GGUF", "DeepSeek-R1-Distill-Qwen-1.5B-Q4_K_M.gguf"),
        size_gb=1.1,
        params="1.5B",
        family="DeepSeek",
        description="DeepSeek R1 reasoning distilled into tiny model",
    ),
    CatalogModel(
        name="deepseek-r1-7b",
        display_name="DeepSeek R1 Distill Qwen 7B",
        filename="DeepSeek-R1-Distill-Qwen-7B-Q4_K_M.gguf",
        url=_hf_url("bartowski/DeepSeek-R1-Distill-Qwen-7B-GGUF", "DeepSeek-R1-Distill-Qwen-7B-Q4_K_M.gguf"),
        size_gb=4.7,
        params="7B",
        family="DeepSeek",
        description="DeepSeek R1 reasoning — strong chain-of-thought",
    ),
    # ── Mistral ─────────────────────────────────────────────
    CatalogModel(
        name="mistral-7b",
        display_name="Mistral 7B Instruct v0.3",
        filename="Mistral-7B-Instruct-v0.3-Q4_K_M.gguf",
        url=_hf_url("bartowski/Mistral-7B-Instruct-v0.3-GGUF", "Mistral-7B-Instruct-v0.3-Q4_K_M.gguf"),
        size_gb=4.4,
        params="7B",
        family="Mistral",
        description="Mistral 7B v0.3 — fast, strong general model",
    ),
    # ── Google CodeGemma ────────────────────────────────────
    CatalogModel(
        name="codegemma-7b",
        display_name="CodeGemma 7B Instruct",
        filename="codegemma-7b-it-Q4_K_M.gguf",
        url=_hf_url("bartowski/codegemma-7b-it-GGUF", "codegemma-7b-it-Q4_K_M.gguf"),
        size_gb=5.0,
        params="7B",
        family="Gemma",
        description="Google CodeGemma — specifically trained for code tasks",
    ),
    # ── TinyLlama (ultra-fast) ──────────────────────────────
    CatalogModel(
        name="tinyllama-1.1b",
        display_name="TinyLlama 1.1B Chat",
        filename="tinyllama-1.1b-chat-v1.0.Q4_K_M.gguf",
        url=_hf_url("TheBloke/TinyLlama-1.1B-Chat-v1.0-GGUF", "tinyllama-1.1b-chat-v1.0.Q4_K_M.gguf"),
        size_gb=0.7,
        params="1.1B",
        family="TinyLlama",
        description="Ultra-fast tiny model — good for quick tasks",
    ),
    # ── HuggingFace SmolLM2 ────────────────────────────────
    CatalogModel(
        name="smollm2-1.7b",
        display_name="SmolLM2 1.7B Instruct",
        filename="SmolLM2-1.7B-Instruct-Q4_K_M.gguf",
        url=_hf_url("bartowski/SmolLM2-1.7B-Instruct-GGUF", "SmolLM2-1.7B-Instruct-Q4_K_M.gguf"),
        size_gb=1.1,
        params="1.7B",
        family="SmolLM",
        description="HuggingFace SmolLM2 — small but surprisingly capable",
    ),
    # ── 01.AI Yi Coder ─────────────────────────────────────
    CatalogModel(
        name="yi-coder-1.5b",
        display_name="Yi Coder 1.5B Chat",
        filename="Yi-Coder-1.5B-Chat-Q4_K_M.gguf",
        url=_hf_url("bartowski/Yi-Coder-1.5B-Chat-GGUF", "Yi-Coder-1.5B-Chat-Q4_K_M.gguf"),
        size_gb=1.0,
        params="1.5B",
        family="Yi",
        description="01.AI Yi Coder — tiny but code-focused",
    ),
]

# Quick lookup by name
CATALOG_BY_NAME: dict[str, CatalogModel] = {m.name: m for m in MODEL_CATALOG}


def search_catalog(query: str) -> list[CatalogModel]:
    """Search the catalog by name, family, or description."""
    q = query.lower()
    return [
        m for m in MODEL_CATALOG
        if q in m.name.lower()
        or q in m.family.lower()
        or q in m.display_name.lower()
        or q in m.description.lower()
    ]


def get_recommended_models() -> list[CatalogModel]:
    """Return a curated list of recommended starter models."""
    recs = ["qwen2.5-coder-3b", "llama3.2-3b", "deepseek-r1-1.5b", "qwen2.5-coder-1.5b"]
    return [CATALOG_BY_NAME[n] for n in recs if n in CATALOG_BY_NAME]
