"""Integration tests for FastAPI endpoints using httpx test client."""

import pytest
from fastapi.testclient import TestClient


@pytest.fixture()
def client(isolated_dirs, monkeypatch):
    """Create a test client with isolated dirs.

    We must patch settings BEFORE importing app, so backend modules
    pick up the temp directories.
    """
    from backend.app import app

    return TestClient(app)


def test_health(client):
    resp = client.get("/health")
    assert resp.status_code == 200
    data = resp.json()
    assert data["ok"] is True
    assert data["version"] == "3.0.0"


def test_hardware(client):
    resp = client.get("/hardware")
    assert resp.status_code == 200
    data = resp.json()
    assert "cpu_threads" in data
    assert "gpu" in data


def test_list_models_empty(client):
    resp = client.get("/models")
    assert resp.status_code == 200
    assert resp.json()["models"] == []


def test_model_names_empty(client):
    resp = client.get("/models/names")
    assert resp.status_code == 200
    data = resp.json()
    assert data["ok"] is True
    assert data["names"] == []


def test_get_model_404(client):
    resp = client.get("/models/nonexistent")
    assert resp.status_code == 404


def test_list_conversations_empty(client):
    resp = client.get("/conversations")
    assert resp.status_code == 200
    assert resp.json()["conversations"] == []


def test_create_conversation(client):
    resp = client.post("/conversations", json={"title": "Test Chat"})
    assert resp.status_code == 200
    data = resp.json()
    assert data["ok"] is True
    assert data["conversation"]["title"] == "Test Chat"


def test_create_conversation_blank_title(client):
    resp = client.post("/conversations", json={"title": ""})
    assert resp.status_code == 422  # validation error


def test_sources_empty(client):
    resp = client.get("/sources")
    assert resp.status_code == 200
    assert resp.json()["sources"] == []


def test_add_source(client):
    resp = client.post("/sources/add", json={
        "repo_url": "owner/repo",
        "model_id": "my-model",
        "runtime": "llama_cpp",
    })
    assert resp.status_code == 200
    source = resp.json()["source"]
    assert source["model_id"] == "my-model"
    assert source["owner"] == "owner"


def test_add_source_duplicate(client):
    client.post("/sources/add", json={"repo_url": "owner/repo", "model_id": "dup"})
    resp = client.post("/sources/add", json={"repo_url": "owner/repo", "model_id": "dup"})
    assert resp.status_code == 400


def test_remove_source(client):
    client.post("/sources/add", json={"repo_url": "owner/repo", "model_id": "remove-me"})
    resp = client.delete("/sources/remove-me")
    assert resp.status_code == 200


def test_model_names_includes_sources(client):
    """Model names endpoint should include tracked source model_ids."""
    client.post("/sources/add", json={"repo_url": "owner/repo", "model_id": "from-source"})
    resp = client.get("/models/names")
    assert "from-source" in resp.json()["names"]


def test_catalog(client):
    """Catalog endpoint should return free models."""
    resp = client.get("/catalog")
    assert resp.status_code == 200
    data = resp.json()
    assert data["ok"] is True
    assert len(data["models"]) >= 4


def test_catalog_recommended(client):
    resp = client.get("/catalog/recommended")
    assert resp.status_code == 200
    assert len(resp.json()["models"]) >= 2


def test_catalog_fits_ram(client):
    resp = client.get("/catalog/fits-ram", params={"max_gb": 2})
    assert resp.status_code == 200
    for m in resp.json()["models"]:
        assert m["min_ram_gb"] <= 2


def test_download_bad_url(client):
    """Downloading from a non-GitHub host should be rejected."""
    resp = client.post("/models/download", json={
        "model_id": "bad-model",
        "source_url": "https://huggingface.co/model.gguf",
        "runtime": "llama_cpp",
    })
    assert resp.status_code == 400
    assert "not allowed" in resp.json()["detail"]


def test_chat_no_model_loaded(client):
    """Chat without loading a model should fail."""
    try:
        resp = client.post("/chat", json={
            "model_id": "test",
            "messages": [{"role": "user", "content": "hi"}],
        })
        # FastAPI may surface the RuntimeError as a 500
        assert resp.status_code == 500
    except RuntimeError:
        pass  # RuntimeError propagates directly in test client
