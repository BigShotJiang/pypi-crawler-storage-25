#!/bin/bash
# GCE startup template: install wisent-compute, start the agent in idle-shutdown
# mode. The agent reads its own VRAM via nvidia-smi and packs as many queued
# jobs as fit — no constant slot count. Self-deletes the VM when the queue
# stops yielding eligible work.
set -euxo pipefail
exec > /var/log/wisent-agent.log 2>&1

echo "Wisent agent VM start: $(date -u)"

while fuser /var/lib/dpkg/lock-frontend >/dev/null 2>&1 || fuser /var/lib/apt/lists/lock >/dev/null 2>&1; do
    echo "Waiting for apt lock..."
done
apt-get update
apt-get install -y python3-venv python3-pip git ca-certificates curl gnupg

WORK=/opt/wisent-agent
rm -rf "$WORK"
mkdir -p "$WORK"
cd "$WORK"
python3 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install --upgrade wisent-compute wisent wisent-extractors wisent-evaluators wisent-tools \
    lm-eval optuna matplotlib word2number evaluate
# Pin transformers to a 4.x version. transformers 5.6.2 raises
# 'does not appear to have files named (model-00000-of-...)'  with a
# zero-indexed range that mismatches HF's 1-indexed sharded
# safetensors (proven on Qwen/Qwen3-8B and openai/gpt-oss-20b). 4.55.x
# uses range(1, n+1) and loads them correctly.
pip install --upgrade --force-reinstall 'transformers>=4.55,<5.0' 'tokenizers>=0.20,<0.22'
# Pin datasets to <4.0. The 4.x line dropped support for dataset loading
# scripts (raises 'Dataset scripts are no longer supported, but found
# flores.py' on basque_bench_flores_*, gsm8k via script-based forks,
# etc.). Verified live on b141c65f at 23:18: agent has datasets==4.8.5
# and the script-based load failed with that exact RuntimeError. 3.x
# preserves the script-loader path for tasks that haven't migrated to
# parquet yet.
pip install --upgrade --force-reinstall 'datasets>=3.0,<4.0' 'huggingface-hub>=0.34.0,<1.0'
pip uninstall -y hf-xet || true

export HF_TOKEN="${HF_TOKEN}"
export HUGGING_FACE_HUB_TOKEN="${HF_TOKEN}"
export WISENT_DTYPE=auto
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
export PYTHONUNBUFFERED=1
export WC_LOCAL_SLOTS=0
# Pin numba threads BEFORE numba is imported. wisent code sets this to 1 in
# 8 modules but the import order on the agent's subprocess path lets numba
# initialise with the system cpu count first, and the later os.environ
# rewrite raises 'Cannot set NUMBA_NUM_THREADS once threads have been
# launched'. Setting it in the agent's own env propagates to subprocesses.
export NUMBA_NUM_THREADS=1
# Slow HF API calls so we don't hit the 1000-requests-per-5min limit when
# 20+ cloud agents all hit ArabicMMLU/etc dataset metadata at once.
export HF_HUB_DOWNLOAD_TIMEOUT=120

# Pre-warm the small auxiliary models so each claimed job skips the download.
huggingface-cli download cross-encoder/nli-deberta-v3-small || true
huggingface-cli download sentence-transformers/all-MiniLM-L6-v2 || true

# Run the agent. --idle-shutdown makes it exit + self-delete the VM when the
# queue holds nothing this VM can run. No timer, no slot constant — pure
# condition-driven on (slots empty AND no eligible queued job).
.venv/bin/wc agent --kind gcp --gpu-type "${ACCEL_TYPE}" --idle-shutdown
EXIT=$?
echo "Agent exited with $EXIT at $(date -u)"
