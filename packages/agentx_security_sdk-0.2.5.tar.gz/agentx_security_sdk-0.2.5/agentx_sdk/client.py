import os
import requests

class AgentXClient:
    def __init__(self, gateway_url="http://localhost:8000"):
        self.gateway_url = gateway_url
        # ❌ REMOVE the self.api_key line from here

    def evaluate_intent(self, agent_id, query, chain_of_thought, receipt_id=None, trace_id=None):
        # ✅ Fetch it dynamically right when the network request is made
        api_key = os.environ.get("AGENTX_API_KEY")
        
        if not api_key:
            return {"status": "ERROR", "message": "AGENTX_API_KEY is missing from environment."}

        payload = {
            "agent_id": agent_id,
            "query": query,
            "cot": chain_of_thought,
            "receipt_id": receipt_id,
            "trace_id": trace_id 
        }
        
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
        
        try:
            response = requests.post(
                f"{self.gateway_url}/v1/evaluate", 
                json=payload,
                headers=headers,
                timeout=15.0 # Adding a timeout is always a safe bet for SDKs
            )
            
            if response.status_code == 401:
                return {"status": "ERROR", "message": "Invalid AgentX API Key."}
                
            return response.json()
            
        except Exception as e:
            return {"status": "ERROR", "message": f"AgentX Gateway unreachable: {e}"}