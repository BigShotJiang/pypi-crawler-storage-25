"""omb update — upgrade oh-my-braincrew from PyPI."""

from __future__ import annotations

import shutil
import subprocess
import sys

import click


def _run(cmd: list[str]) -> subprocess.CompletedProcess[str]:
    """Run a subprocess, raising on failure."""
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        stderr = result.stderr.strip() or result.stdout.strip()
        raise click.ClickException(f"`{' '.join(cmd)}` failed:\n{stderr}")
    return result


@click.command("update")
def update_cmd() -> None:
    """Update omb to the latest version from PyPI."""
    uv = shutil.which("uv")
    if uv:
        cmd = [uv, "pip", "install", "--upgrade", "oh-my-braincrew"]
    else:
        cmd = [sys.executable, "-m", "pip", "install", "--upgrade", "oh-my-braincrew"]

    click.echo("Upgrading oh-my-braincrew from PyPI...")
    _run(cmd)

    click.echo("Update complete.")
    _run([sys.executable, "-m", "omb", "version"])
