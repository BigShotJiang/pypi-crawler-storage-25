"""Behavioral tests for `regard hl outcomes` and `regard hl outcome <id>`.

The contract tests in test_contract.py verify the JSON envelope on every
command/error path. This module pins the field-level contract: numeric values
ARE strings (Constitution Article I), implied probability arithmetic uses
Decimal precision, and `<id>` argument parsing routes correctly.
"""

import json

from typer.testing import CliRunner

from regard.main import app

runner = CliRunner()


# ---------------------------------------------------------------------------
# `regard hl outcomes` — list-view
# ---------------------------------------------------------------------------


class TestOutcomesList:
    def test_returns_envelope_with_outcomes_array(self, patched):
        result = runner.invoke(app, ["hl", "outcomes"])
        envelope = json.loads(result.stdout)
        assert envelope["ok"] is True
        assert isinstance(envelope["data"]["outcomes"], list)

    def test_seeded_outcome_present(self, patched):
        result = runner.invoke(app, ["hl", "outcomes"])
        envelope = json.loads(result.stdout)
        outcomes = envelope["data"]["outcomes"]
        assert len(outcomes) >= 1
        btc = outcomes[0]
        assert btc["outcome"] == 1
        assert btc["underlying"] == "BTC"
        assert btc["class"] == "priceBinary"
        assert btc["yes_coin"] == "#10"
        assert btc["no_coin"] == "#11"

    def test_target_price_is_string(self, patched):
        """Article I: financial values are strings, not JSON numbers."""
        result = runner.invoke(app, ["hl", "outcomes"])
        envelope = json.loads(result.stdout)
        btc = envelope["data"]["outcomes"][0]
        assert isinstance(btc["target_price"], str)
        assert btc["target_price"] == "78213"

    def test_has_display(self, patched):
        result = runner.invoke(app, ["hl", "outcomes"])
        envelope = json.loads(result.stdout)
        assert envelope["display"]


# ---------------------------------------------------------------------------
# `regard hl outcome <id>` — single market
# ---------------------------------------------------------------------------


class TestOutcomeSingle:
    def test_bare_integer_returns_both_sides(self, patched):
        result = runner.invoke(app, ["hl", "outcome", "1"])
        envelope = json.loads(result.stdout)
        assert envelope["ok"] is True
        data = envelope["data"]
        assert data["outcome"] == 1
        assert "yes" in data
        assert "no" in data

    def test_full_coin_form_returns_only_that_side(self, patched):
        # `#10` is YES — only that side should appear in the response.
        result = runner.invoke(app, ["hl", "outcome", "#10"])
        envelope = json.loads(result.stdout)
        data = envelope["data"]
        assert "yes" in data
        assert "no" not in data
        assert data["yes"]["coin"] == "#10"

    def test_named_side_yes(self, patched):
        result = runner.invoke(app, ["hl", "outcome", "1:yes"])
        envelope = json.loads(result.stdout)
        data = envelope["data"]
        assert "yes" in data
        assert "no" not in data

    def test_named_side_no(self, patched):
        result = runner.invoke(app, ["hl", "outcome", "1:no"])
        envelope = json.loads(result.stdout)
        data = envelope["data"]
        assert "no" in data
        assert "yes" not in data

    def test_numeric_side_form(self, patched):
        result = runner.invoke(app, ["hl", "outcome", "1:1"])
        envelope = json.loads(result.stdout)
        data = envelope["data"]
        assert "no" in data
        assert "yes" not in data

    def test_book_prices_are_strings(self, patched):
        """Article I: every numeric field in the book must be a JSON string."""
        result = runner.invoke(app, ["hl", "outcome", "1"])
        envelope = json.loads(result.stdout)
        data = envelope["data"]
        for side in ("yes", "no"):
            book = data[side]
            assert isinstance(book["top_bid"], str)
            assert isinstance(book["top_ask"], str)
            assert isinstance(book["mid"], str)
            for level in book["bids"] + book["asks"]:
                assert isinstance(level["price"], str)
                assert isinstance(level["size"], str)

    def test_implied_total_uses_decimal_precision(self, patched):
        """The fixture has YES mid (0.45+0.46)/2=0.455 and NO mid (0.54+0.55)/2=0.545.
        Sum = exactly 1.000 — would also match if computed via float, but the
        Decimal path guarantees the string is faithful to the inputs."""
        result = runner.invoke(app, ["hl", "outcome", "1"])
        envelope = json.loads(result.stdout)
        data = envelope["data"]
        assert isinstance(data["implied_total"], str)
        # Allow `1.000` / `1.00` / `1.0` — Decimal preserves trailing zeros.
        # The relevant assertion is the value rounds to 1.0.
        from decimal import Decimal
        assert Decimal(data["implied_total"]) == Decimal("1.000")

    def test_parsed_description_present(self, patched):
        result = runner.invoke(app, ["hl", "outcome", "1"])
        envelope = json.loads(result.stdout)
        parsed = envelope["data"]["parsed_description"]
        assert parsed["class"] == "priceBinary"
        assert parsed["underlying"] == "BTC"
        assert parsed["target_price"] == "78213"  # string
        assert parsed["expiry"] == "20260504-0600"
        assert parsed["period"] == "1d"

    def test_unknown_outcome_id_dies_with_structured_error(self, patched):
        result = runner.invoke(app, ["hl", "outcome", "99999"])
        envelope = json.loads(result.stdout)
        assert envelope["ok"] is False
        assert envelope["error"]["code"] == "UNKNOWN_OUTCOME"
        assert envelope["error"]["type"] == "validation_error"

    def test_invalid_id_dies_with_structured_error(self, patched):
        result = runner.invoke(app, ["hl", "outcome", "1:bogus"])
        envelope = json.loads(result.stdout)
        assert envelope["ok"] is False
        assert envelope["error"]["code"] == "INVALID_OUTCOME_ID"

    def test_side_out_of_range_dies_with_structured_error(self, patched):
        """Regression (peer-review SIDE-OOB): `#12` decodes to outcome=1,
        side=2. Pre-fix, the command silently emitted `{ok: true,
        implied_total: null}` with no yes/no keys — agent couldn't
        distinguish from a thin market. Now rejected at parse time."""
        result = runner.invoke(app, ["hl", "outcome", "#12"])
        envelope = json.loads(result.stdout)
        assert envelope["ok"] is False
        assert envelope["error"]["code"] == "INVALID_OUTCOME_ID"
        assert envelope["error"]["type"] == "validation_error"
        assert "side 2" in envelope["error"]["message"]

    def test_unicode_digit_in_coin_id_returns_validation_error(self, patched):
        """Regression (peer-review UNICODE-VAL): pre-fix, `'²'.isdigit()`
        was True, `int('²')` raised ValueError, caller's `is None` check
        missed it, exited with internal_error / exit 7. Now rejected at
        parse time as validation_error / exit 2 per Article IV."""
        result = runner.invoke(app, ["hl", "outcome", "#²"])
        envelope = json.loads(result.stdout)
        assert envelope["ok"] is False
        assert envelope["error"]["type"] == "validation_error"
        assert envelope["error"]["code"] == "INVALID_OUTCOME_ID"
        # Critical: exit code is 2 (validation), not 7 (internal_error)
        assert result.exit_code == 2

    def test_leading_zero_coin_rejected(self, patched):
        """Regression (peer-review LEAD-ZERO): pre-fix, `#010` silently
        aliased `#10`. Now decode_coin returns None and the parser
        surfaces INVALID_OUTCOME_ID."""
        result = runner.invoke(app, ["hl", "outcome", "#010"])
        envelope = json.loads(result.stdout)
        assert envelope["ok"] is False
        assert envelope["error"]["code"] == "INVALID_OUTCOME_ID"

    def test_has_display(self, patched):
        result = runner.invoke(app, ["hl", "outcome", "1"])
        envelope = json.loads(result.stdout)
        assert envelope["display"]
