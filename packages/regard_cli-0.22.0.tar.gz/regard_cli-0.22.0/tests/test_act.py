"""Tests for act commands — order, cancel, cancel-all, leverage, transfer, preflight."""

import json
from unittest.mock import patch

import pytest

from regard.main import app
from tests.conftest import load_fixture

# Known-asset token entries for send tests come from the golden fixture —
# Constitution Article IV forbids hand-authored shapes for real coins. See
# test_constitution_alignment.py for the guardrail.
_SPOT_GOLDEN = load_fixture("hyperliquid", "spot_meta")


def _spot_token(name: str) -> dict:
    for t in _SPOT_GOLDEN["tokens"]:
        if t["name"] == name:
            return dict(t)
    raise KeyError(f"{name} not in golden spot_meta.json tokens")

ACTIVE_ASSET_DATA_EMPTY = {
    "user": "0xTEST",
    "coin": "xyz:CL",
    "leverage": {"type": "isolated", "value": 20, "rawUsd": "0.0"},
    "maxTradeSzs": ["0.0", "0.0"],
    "availableToTrade": ["0.0", "0.0"],
    "markPx": "100.50",
}


def parse(result):
    return json.loads(result.output)


def data(result):
    return parse(result)["data"]



class TestOrder:
    """Order now creates proposals — tests verify proposal output, not execution."""

    def test_market_buy_creates_proposal(self, runner, patched):
        result = runner.invoke(app, ["hl", "order", "BTC", "buy", "0.1", "--market"])
        assert result.exit_code == 0
        d = data(result)
        assert d["id"].startswith("p_")
        assert d["status"] == "pending"
        assert d["venue"] == "hl"
        assert d["command"] == "order"
        assert d["params"]["asset"] == "BTC"
        assert d["params"]["side"] == "buy"
        assert d["params"]["size"] == "0.1"
        assert d["params"]["market"] is True
        assert d["checks"]["mark_price"] == "69666.5"

    def test_limit_buy_creates_proposal(self, runner, patched):
        result = runner.invoke(app, ["hl", "order", "BTC", "buy", "0.1", "65000"])
        assert result.exit_code == 0
        d = data(result)
        assert d["status"] == "pending"
        assert d["params"]["price"] == "65000"
        assert d["params"]["market"] is False

    def test_side_aliases(self, runner, patched):
        for side in ["buy", "long", "sell", "short"]:
            result = runner.invoke(app, ["hl", "order", "BTC", side, "0.1", "--market"])
            assert result.exit_code == 0, f"Failed for side={side}"
            d = data(result)
            assert d["status"] == "pending"

    def test_invalid_side(self, runner, patched):
        result = runner.invoke(app, ["hl", "order", "BTC", "yolo", "0.1", "65000"])
        assert result.exit_code == 2
        assert parse(result)["error"]["code"] == "INVALID_SIDE"

    def test_unknown_asset(self, runner, patched):
        result = runner.invoke(app, ["hl", "order", "FAKECOIN", "buy", "0.1", "--market"])
        assert result.exit_code == 2
        assert parse(result)["error"]["code"] == "UNKNOWN_ASSET"

    def test_limit_with_sl_and_tp(self, runner, patched):
        """Order with --sl and --tp creates proposal with those params."""
        result = runner.invoke(app, ["hl", "order", "BTC", "buy", "0.1", "65000",
                                     "--sl", "60000", "--tp", "75000"])
        assert result.exit_code == 0
        d = data(result)
        assert d["status"] == "pending"
        assert d["params"]["sl"] == "60000"
        assert d["params"]["tp"] == "75000"
        # Exchange should NOT be called (propose only)
        patched["exchange"].bulk_orders.assert_not_called()
        patched["exchange"].order.assert_not_called()

    def test_reduce_only_flag(self, runner, patched):
        """--reduce-only is captured in proposal params."""
        result = runner.invoke(app, ["hl", "order", "BTC", "sell", "0.05", "75000", "--reduce-only"])
        assert result.exit_code == 0
        d = data(result)
        assert d["params"]["reduce_only"] is True
        # Exchange should NOT be called (propose only)
        patched["exchange"].order.assert_not_called()

    def test_hip3_asset_order(self, runner, patched):
        """Order on a HIP-3 asset (xyz:TSLA) creates proposal with resolved name."""
        result = runner.invoke(app, ["hl", "order", "xyz:TSLA", "buy", "1.0", "--market"])
        assert result.exit_code == 0
        d = data(result)
        assert d["params"]["asset"] == "xyz:TSLA"
        assert d["status"] == "pending"

    def test_market_with_sl_rejected(self, runner, patched):
        """--market with --sl is rejected at propose time."""
        result = runner.invoke(app, ["hl", "order", "BTC", "buy", "0.1", "--market", "--sl", "60000"])
        assert result.exit_code == 2
        assert parse(result)["error"]["code"] == "MARKET_WITH_TPSL"

    def test_market_with_tp_rejected(self, runner, patched):
        """--market with --tp is rejected at propose time."""
        result = runner.invoke(app, ["hl", "order", "BTC", "buy", "0.1", "--market", "--tp", "80000"])
        assert result.exit_code == 2
        assert parse(result)["error"]["code"] == "MARKET_WITH_TPSL"

    def test_no_exchange_call_on_propose(self, runner, patched):
        """Proposing an order must NOT call the exchange."""
        runner.invoke(app, ["hl", "order", "BTC", "buy", "0.1", "--market"])
        patched["exchange"].market_open.assert_not_called()
        patched["exchange"].order.assert_not_called()
        patched["exchange"].bulk_orders.assert_not_called()


class TestCancel:
    def test_by_oid_auto_lookup(self, runner, patched):
        result = runner.invoke(app, ["hl", "cancel", "100001"])
        assert result.exit_code == 0
        d = data(result)
        assert d["status"] == "pending"
        assert d["command"] == "cancel"
        assert d["params"]["oid"] == 100001
        assert d["params"]["asset"] == "BTC"

    def test_by_oid_with_asset(self, runner, patched):
        result = runner.invoke(app, ["hl", "cancel", "BTC", "100001"])
        assert result.exit_code == 0
        d = data(result)
        assert d["status"] == "pending"
        assert d["params"]["asset"] == "BTC"
        assert d["params"]["oid"] == 100001

    def test_oid_not_found(self, runner, patched):
        result = runner.invoke(app, ["hl", "cancel", "999999"])
        assert result.exit_code == 2
        assert parse(result)["error"]["code"] == "ORDER_NOT_FOUND"

    def test_cloid_cancel(self, runner, patched):
        """Cancel by cloid creates proposal with cloid param."""
        result = runner.invoke(app, ["hl", "cancel", "0", "--cloid", "0x0123456789abcdef0123456789abcdef", "--asset", "BTC"])
        assert result.exit_code == 0
        d = data(result)
        assert d["status"] == "pending"
        assert d["params"]["cloid"] == "0x0123456789abcdef0123456789abcdef"

    def test_cloid_invalid_format(self, runner, patched):
        """Malformed cloid is rejected at propose time."""
        result = runner.invoke(app, ["hl", "cancel", "0", "--cloid", "not-a-cloid", "--asset", "BTC"])
        assert result.exit_code == 2
        assert parse(result)["error"]["code"] == "INVALID_CLOID"

    def test_no_exchange_call(self, runner, patched):
        runner.invoke(app, ["hl", "cancel", "100001"])
        patched["exchange"].cancel.assert_not_called()
        patched["exchange"].cancel_by_cloid.assert_not_called()


class TestCancelAll:
    def test_all(self, runner, patched):
        result = runner.invoke(app, ["hl", "cancel-all"])
        assert result.exit_code == 0
        d = data(result)
        assert d["status"] == "pending"
        assert d["command"] == "cancel-all"
        assert d["params"]["count"] == 2
        assert sorted(d["params"]["assets"]) == ["BTC", "ETH"]

    def test_filtered(self, runner, patched):
        result = runner.invoke(app, ["hl", "cancel-all", "BTC"])
        assert result.exit_code == 0
        d = data(result)
        assert d["status"] == "pending"
        assert d["params"]["count"] == 1
        assert d["params"]["assets"] == ["BTC"]

    def test_no_exchange_call(self, runner, patched):
        """cancel-all creates proposal but does not call exchange."""
        runner.invoke(app, ["hl", "cancel-all"])
        patched["exchange"].bulk_cancel.assert_not_called()

    def test_empty(self, runner, patched):
        patched["info"].frontend_open_orders.return_value = []
        result = runner.invoke(app, ["hl", "cancel-all"])
        assert result.exit_code == 0
        d = data(result)
        # Empty cancel-all returns immediately (no proposal needed)
        assert d["cancelled"] == 0


class TestLeverage:
    def test_cross_default(self, runner, patched):
        result = runner.invoke(app, ["hl", "leverage", "BTC", "10"])
        assert result.exit_code == 0
        d = data(result)
        assert d["status"] == "pending"
        assert d["command"] == "leverage"
        assert d["params"]["asset"] == "BTC"
        assert d["params"]["leverage"] == 10
        assert d["params"]["is_cross"] is True

    def test_isolated(self, runner, patched):
        result = runner.invoke(app, ["hl", "leverage", "BTC", "10", "--isolated"])
        assert result.exit_code == 0
        d = data(result)
        assert d["params"]["is_cross"] is False

    def test_both_flags_error(self, runner, patched):
        result = runner.invoke(app, ["hl", "leverage", "BTC", "10", "--cross", "--isolated"])
        assert result.exit_code == 2
        assert parse(result)["error"]["code"] == "CONFLICTING_OPTIONS"

    def test_hip3_forces_isolated(self, runner, patched):
        """HIP-3 assets force isolated margin even without --isolated flag."""
        result = runner.invoke(app, ["hl", "leverage", "xyz:TSLA", "5"])
        assert result.exit_code == 0
        lines = result.output.strip().split("\n")
        json_line = [l for l in lines if l.startswith("{")][-1]
        d = json.loads(json_line)["data"]
        assert d["params"]["is_cross"] is False
        assert d["params"]["asset"] == "xyz:TSLA"

    def test_no_exchange_call(self, runner, patched):
        runner.invoke(app, ["hl", "leverage", "BTC", "10"])
        patched["exchange"].update_leverage.assert_not_called()


class TestPreflight:
    def test_can_trade(self, runner, patched):
        result = runner.invoke(app, ["hl", "preflight", "BTC", "buy", "0.01"])
        assert result.exit_code == 0
        d = data(result)
        assert d["can_trade"] is True
        assert d["asset"] == "BTC"
        assert d["dex"] == "default"
        assert float(d["max_size"]) > 0

    def test_cannot_trade_hip3(self, runner, patched):
        # Add xyz:CL to resolver's known coins
        patched["info"].coin_to_asset["xyz:CL"] = 110029
        with patch("regard.venues.hyperliquid.commands.act.get_active_asset_data", return_value=ACTIVE_ASSET_DATA_EMPTY):
            result = runner.invoke(app, ["hl", "preflight", "xyz:CL", "buy", "0.5"])
            assert result.exit_code == 0
            d = data(result)
            assert d["can_trade"] is False
            assert d["dex"] == "xyz"

    def test_invalid_side(self, runner, patched):
        result = runner.invoke(app, ["hl", "preflight", "BTC", "sideways", "1.0"])
        assert result.exit_code == 2
        assert parse(result)["error"]["code"] == "INVALID_SIDE"

    def test_risk_metrics(self, runner, patched):
        """Preflight returns notional, equity, notional_pct, margin_required, liq_price_est."""
        result = runner.invoke(app, ["hl", "preflight", "BTC", "buy", "0.01"])
        assert result.exit_code == 0
        d = data(result)
        # mark_px from ACTIVE_ASSET_DATA is 69666.0, size 0.01
        assert d["notional"] == pytest.approx(696.66, abs=1)
        assert d["equity"] == pytest.approx(10000.0, abs=1)
        assert d["notional_pct"] == pytest.approx(6.97, abs=0.1)
        assert "margin_required" in d
        assert "leverage" in d

    def test_liq_price_est_isolated(self, runner, patched):
        """Isolated leverage: liq_price_est = mark * (1 - 1/lev) for longs."""
        patched["info"].coin_to_asset["xyz:CL"] = 110029
        with patch("regard.venues.hyperliquid.commands.act.get_active_asset_data", return_value=ACTIVE_ASSET_DATA_EMPTY):
            result = runner.invoke(app, ["hl", "preflight", "xyz:CL", "buy", "0.5"])
            assert result.exit_code == 0
            d = data(result)
            # mark 100.50, leverage 20x isolated: liq = 100.50 * (1 - 1/20) = 95.475
            assert d["liq_price_est"] == pytest.approx(95.475, abs=0.01)

    def test_liq_price_est_cross_is_null(self, runner, patched):
        """Cross leverage: liq_price_est is null (depends on portfolio)."""
        result = runner.invoke(app, ["hl", "preflight", "BTC", "buy", "0.01"])
        assert result.exit_code == 0
        d = data(result)
        # BTC in ACTIVE_ASSET_DATA has cross leverage
        assert d["liq_price_est"] is None

    def test_high_notional_warning(self, runner, patched):
        """Warns when notional > 50% of equity."""
        result = runner.invoke(app, ["hl", "preflight", "BTC", "buy", "0.1"])
        assert result.exit_code == 0
        d = data(result)
        # 0.1 * 69666 = $6966.6, equity $10000 → 69.7%
        codes = [w["code"] for w in d["warnings"]]
        assert "HIGH_NOTIONAL" in codes

    def test_liq_above_stop_warning(self, runner, patched):
        """Warns when liq estimate is above planned stop for a long."""
        patched["info"].coin_to_asset["xyz:CL"] = 110029
        with patch("regard.venues.hyperliquid.commands.act.get_active_asset_data", return_value=ACTIVE_ASSET_DATA_EMPTY):
            # mark 100.50, 20x isolated → liq ~95.475, stop at 96 → liq < stop (OK)
            result = runner.invoke(app, ["hl", "preflight", "xyz:CL", "buy", "0.5", "--sl", "96"])
            assert result.exit_code == 0
            d = data(result)
            codes = [w["code"] for w in d["warnings"]]
            assert "LIQ_ABOVE_STOP" not in codes

            # stop at 94 → liq 95.475 > 94 → warning
            result = runner.invoke(app, ["hl", "preflight", "xyz:CL", "buy", "0.5", "--sl", "94"])
            assert result.exit_code == 0
            d = data(result)
            codes = [w["code"] for w in d["warnings"]]
            assert "LIQ_ABOVE_STOP" in codes
            liq_warn = [w for w in d["warnings"] if w["code"] == "LIQ_ABOVE_STOP"][0]
            assert "suggested_leverage" in liq_warn

    def test_max_loss_with_sl(self, runner, patched):
        """--sl flag adds stop_price and max_loss to output."""
        result = runner.invoke(app, ["hl", "preflight", "BTC", "buy", "0.01", "--sl", "65000"])
        assert result.exit_code == 0
        d = data(result)
        assert d["stop_price"] == "65000"
        # max_loss = 0.01 * abs(69666 - 65000) = 46.66
        assert d["max_loss"] == pytest.approx(46.66, abs=1)

    def test_existing_position_warning(self, runner, patched):
        """Warns when an existing position exists for the same asset."""
        # BTC has an existing long 0.05 position in USER_STATE
        result = runner.invoke(app, ["hl", "preflight", "BTC", "buy", "0.01"])
        assert result.exit_code == 0
        d = data(result)
        assert d["existing_position"]["side"] == "long"
        assert d["existing_position"]["size"] == 0.05
        codes = [w["code"] for w in d["warnings"]]
        assert "EXISTING_POSITION" in codes

    def test_liq_vs_stop_cross_margin_existing_position(self, runner, patched):
        """Cross margin: warns when existing position's liq price is above planned stop."""
        # BTC has an existing long 0.05 position with liquidationPx in USER_STATE
        result = runner.invoke(app, ["hl", "preflight", "BTC", "buy", "0.01", "--sl", "1000"])
        assert result.exit_code == 0
        d = data(result)
        codes = [w["code"] for w in d["warnings"]]
        # liq_price_est is null (cross), but existing position has real liquidationPx
        assert d["liq_price_est"] is None
        assert "LIQ_ABOVE_STOP" in codes

    def test_liq_price_est_isolated_short(self, runner, patched):
        """Isolated short: liq_price_est = mark * (1 + 1/lev)."""
        patched["info"].coin_to_asset["xyz:CL"] = 110029
        with patch("regard.venues.hyperliquid.commands.act.get_active_asset_data", return_value=ACTIVE_ASSET_DATA_EMPTY):
            result = runner.invoke(app, ["hl", "preflight", "xyz:CL", "sell", "0.5"])
            assert result.exit_code == 0
            d = data(result)
            # mark 100.50, leverage 20x isolated: liq = 100.50 * (1 + 1/20) = 105.525
            assert d["liq_price_est"] == pytest.approx(105.525, abs=0.01)

    def test_unified_account_uses_total_equity(self, runner, patched):
        """Unified account: equity is total account value, not dex-specific."""
        with patch("regard.venues.hyperliquid.commands.act.get_account_mode", return_value="unifiedAccount"):
            result = runner.invoke(app, ["hl", "preflight", "BTC", "buy", "0.01"])
            assert result.exit_code == 0
            d = data(result)
            # user_state returns crossMarginSummary.accountValue = 10000
            assert d["equity"] == pytest.approx(10000.0, abs=1)

    def test_display_field(self, runner, patched):
        """Preflight includes a display string."""
        result = runner.invoke(app, ["hl", "preflight", "BTC", "buy", "0.01"])
        assert result.exit_code == 0
        d = data(result)
        assert "Preflight:" in d["display"]
        assert "Mark price" in d["display"]


class TestDirectionValidation:
    """Tests for _validate_trigger_direction shared helper via order --sl/--tp."""

    def test_order_sl_wrong_direction_long(self, runner, patched):
        """--sl above market for a buy/long is rejected."""
        result = runner.invoke(app, ["hl", "order", "BTC", "buy", "0.01", "65000", "--sl", "75000"])
        assert result.exit_code == 2
        assert parse(result)["error"]["code"] == "BAD_STOP"

    def test_order_sl_wrong_direction_short(self, runner, patched):
        """--sl below market for a sell/short is rejected."""
        result = runner.invoke(app, ["hl", "order", "BTC", "sell", "0.01", "75000", "--sl", "60000"])
        assert result.exit_code == 2
        assert parse(result)["error"]["code"] == "BAD_STOP"

    def test_order_tp_wrong_direction_long(self, runner, patched):
        """--tp below market for a buy/long is rejected."""
        result = runner.invoke(app, ["hl", "order", "BTC", "buy", "0.01", "65000", "--tp", "60000"])
        assert result.exit_code == 2
        assert parse(result)["error"]["code"] == "BAD_TP"

    def test_order_sl_correct_passes(self, runner, patched):
        """--sl below market for a buy/long passes validation → creates proposal."""
        result = runner.invoke(app, ["hl", "order", "BTC", "buy", "0.01", "65000", "--sl", "60000"])
        assert result.exit_code == 0
        assert data(result)["status"] == "pending"


class TestStop:
    """Tests for stop command — now creates proposals."""

    def test_tp_mode(self, runner, patched):
        """--tp creates a proposal with is_tp=True."""
        with patch("regard.venues.hyperliquid.commands.act.get_all_positions", return_value=[
            {"coin": "BTC", "szi": "0.05", "entryPx": "68000.00",
             "liquidationPx": "62000.00", "leverage": {"type": "cross", "value": 10}},
        ]), patch("regard.venues.hyperliquid.commands.act.get_all_mids", return_value={"BTC": "69666.5"}):
            result = runner.invoke(app, ["hl", "stop", "BTC", "75000", "--tp"])
            assert result.exit_code == 0
            d = data(result)
            assert d["status"] == "pending"
            assert d["command"] == "stop"
            assert d["params"]["is_tp"] is True
            assert d["params"]["trigger_price"] == "75000"
            assert d["checks"]["mark_price"] == "69666.5"

    def test_no_position_error(self, runner, patched):
        """Stop on an asset with no open position fails."""
        with patch("regard.venues.hyperliquid.commands.act.get_all_positions", return_value=[]):
            result = runner.invoke(app, ["hl", "stop", "BTC", "60000"])
            assert result.exit_code == 2
            assert parse(result)["error"]["code"] == "NO_POSITION"

    def test_no_exchange_call(self, runner, patched):
        with patch("regard.venues.hyperliquid.commands.act.get_all_positions", return_value=[
            {"coin": "BTC", "szi": "0.05", "entryPx": "68000.00",
             "liquidationPx": "62000.00"},
        ]), patch("regard.venues.hyperliquid.commands.act.get_all_mids", return_value={"BTC": "69666.5"}):
            runner.invoke(app, ["hl", "stop", "BTC", "64000"])
            patched["exchange"].order.assert_not_called()


class TestStopLiqWarning:
    """Tests for liq-vs-stop warning — now in proposal warnings."""

    def test_stop_warns_liq_above_stop_long(self, runner, patched):
        with patch("regard.venues.hyperliquid.commands.act.get_all_positions", return_value=[
            {"coin": "BTC", "szi": "0.05", "entryPx": "68000.00",
             "liquidationPx": "62000.00", "leverage": {"type": "cross", "value": 10}},
        ]), patch("regard.venues.hyperliquid.commands.act.get_all_mids", return_value={"BTC": "69666.5"}):
            result = runner.invoke(app, ["hl", "stop", "BTC", "61000"])
            assert result.exit_code == 0
            d = data(result)
            codes = [w["code"] for w in d["warnings"]]
            assert "LIQ_ABOVE_STOP" in codes
            warn = [w for w in d["warnings"] if w["code"] == "LIQ_ABOVE_STOP"][0]
            assert warn["liq_price"] == pytest.approx(62000, abs=1)

    def test_stop_no_warning_liq_below_stop(self, runner, patched):
        with patch("regard.venues.hyperliquid.commands.act.get_all_positions", return_value=[
            {"coin": "BTC", "szi": "0.05", "entryPx": "68000.00",
             "liquidationPx": "62000.00", "leverage": {"type": "cross", "value": 10}},
        ]), patch("regard.venues.hyperliquid.commands.act.get_all_mids", return_value={"BTC": "69666.5"}), \
           patch("regard.venues.hyperliquid.commands.act.get_asset_oracle_px", return_value=None):
            result = runner.invoke(app, ["hl", "stop", "BTC", "64000"])
            assert result.exit_code == 0
            d = data(result)
            assert d["warnings"] == []

    def test_stop_warns_liq_below_stop_short(self, runner, patched):
        with patch("regard.venues.hyperliquid.commands.act.get_all_positions", return_value=[
            {"coin": "ETH", "szi": "-1.0", "entryPx": "3300.00",
             "liquidationPx": "3800.00", "leverage": {"type": "cross", "value": 5}},
        ]), patch("regard.venues.hyperliquid.commands.act.get_all_mids", return_value={"ETH": "3250.0"}):
            result = runner.invoke(app, ["hl", "stop", "ETH", "3900"])
            assert result.exit_code == 0
            d = data(result)
            codes = [w["code"] for w in d["warnings"]]
            assert "LIQ_BELOW_STOP" in codes


class TestStopLiqIsolatedReject:
    """Isolated margin: liq-vs-stop must hard reject, not warn."""

    def test_isolated_stop_inside_liq_rejects(self, runner, patched):
        """Isolated margin + stop inside liq → die with STOP_INSIDE_LIQ."""
        with patch("regard.venues.hyperliquid.commands.act.get_all_positions", return_value=[
            {"coin": "BTC", "szi": "0.05", "entryPx": "68000.00",
             "liquidationPx": "62000.00", "leverage": {"type": "isolated", "value": 10}},
        ]), patch("regard.venues.hyperliquid.commands.act.get_all_mids", return_value={"BTC": "69666.5"}):
            result = runner.invoke(app, ["hl", "stop", "BTC", "61000"])
            assert result.exit_code == 2
            assert parse(result)["error"]["code"] == "STOP_INSIDE_LIQ"

    def test_isolated_stop_outside_liq_passes(self, runner, patched):
        """Isolated margin + stop outside liq → proposal created."""
        with patch("regard.venues.hyperliquid.commands.act.get_all_positions", return_value=[
            {"coin": "BTC", "szi": "0.05", "entryPx": "68000.00",
             "liquidationPx": "62000.00", "leverage": {"type": "isolated", "value": 10}},
        ]), patch("regard.venues.hyperliquid.commands.act.get_all_mids", return_value={"BTC": "69666.5"}), \
           patch("regard.venues.hyperliquid.commands.act.get_asset_oracle_px", return_value=None):
            result = runner.invoke(app, ["hl", "stop", "BTC", "64000"])
            assert result.exit_code == 0
            assert data(result)["warnings"] == []


class TestOrderSlLiqCheck:
    """order --sl must also check liq-vs-stop on existing positions."""

    def test_order_sl_inside_liq_isolated_rejects(self, runner, patched):
        """order --sl inside liq on isolated position → STOP_INSIDE_LIQ."""
        with patch("regard.venues.hyperliquid.commands.act.get_all_positions", return_value=[
            {"coin": "BTC", "szi": "0.05", "entryPx": "68000.00",
             "liquidationPx": "62000.00", "leverage": {"type": "isolated", "value": 10}},
        ]), patch("regard.venues.hyperliquid.commands.act.get_all_mids", return_value={"BTC": "69666.5"}):
            result = runner.invoke(app, ["hl", "order", "BTC", "buy", "0.1", "65000", "--sl", "61000"])
            assert result.exit_code == 2
            assert parse(result)["error"]["code"] == "STOP_INSIDE_LIQ"

    def test_order_sl_no_position_skips_liq_check(self, runner, patched):
        """order --sl with no existing position → proposal created (liq unknown)."""
        with patch("regard.venues.hyperliquid.commands.act.get_all_positions", return_value=[]):
            result = runner.invoke(app, ["hl", "order", "BTC", "buy", "0.1", "65000", "--sl", "60000"])
            assert result.exit_code == 0
            assert data(result)["status"] == "pending"


class TestLimitPriceSanity:
    """Warn when limit price is far from market (likely hallucinated)."""

    def test_buy_limit_far_above_market_warns(self, runner, patched):
        """Buy limit 16x above mark → warning in proposal."""
        result = runner.invoke(app, ["hl", "order", "ETH", "buy", "0.01", "35000"])
        assert result.exit_code == 0
        d = data(result)
        assert any("above mark" in str(w).lower() for w in d["warnings"])

    def test_sell_limit_far_below_market_warns(self, runner, patched):
        """Sell limit 90% below mark → warning in proposal."""
        result = runner.invoke(app, ["hl", "order", "BTC", "sell", "0.001", "5000"])
        assert result.exit_code == 0
        d = data(result)
        assert any("below mark" in str(w).lower() for w in d["warnings"])

    def test_reasonable_limit_no_warning(self, runner, patched):
        """Limit within 50% of mark → no price warning."""
        result = runner.invoke(app, ["hl", "order", "BTC", "buy", "0.001", "50000"])
        assert result.exit_code == 0
        d = data(result)
        assert not any("mark" in str(w).lower() for w in d["warnings"])

    def test_market_order_no_price_warning(self, runner, patched):
        """Market orders have no limit price → no warning."""
        result = runner.invoke(app, ["hl", "order", "BTC", "buy", "0.001", "--market"])
        assert result.exit_code == 0
        d = data(result)
        assert not any("mark" in str(w).lower() for w in d["warnings"])

    def test_alo_no_false_warning(self, runner, patched):
        """ALO (post-only) orders are cancelled if marketable, not filled — no warning."""
        result = runner.invoke(app, ["hl", "order", "BTC", "buy", "0.001", "200000", "--tif", "alo"])
        assert result.exit_code == 0
        d = data(result)
        assert not any("fill immediately" in str(w).lower() for w in d["warnings"])


class TestMinNotional:
    """Reject orders below $10 notional at mark price."""

    def test_below_min_rejected(self, runner, patched):
        """BTC 0.0001 × $69666.5 = $6.97 → BELOW_MIN_NOTIONAL."""
        result = runner.invoke(app, ["hl", "order", "BTC", "buy", "0.0001", "50000"])
        assert result.exit_code == 2
        err = parse(result)["error"]
        assert err["code"] == "BELOW_MIN_NOTIONAL"
        assert "$10" in err["message"]
        assert "hint" in err

    def test_above_min_accepted(self, runner, patched):
        """BTC 0.001 × $69666.5 = $69.67 → proposal created."""
        result = runner.invoke(app, ["hl", "order", "BTC", "buy", "0.001", "50000"])
        assert result.exit_code == 0
        assert data(result)["status"] == "pending"

    def test_market_order_below_min_rejected(self, runner, patched):
        """Market orders also checked against mark price."""
        result = runner.invoke(app, ["hl", "order", "BTC", "buy", "0.0001", "--market"])
        assert result.exit_code == 2
        assert parse(result)["error"]["code"] == "BELOW_MIN_NOTIONAL"


class TestHlPrecision:
    """HL order size precision validation against szDecimals."""

    def test_excess_precision_rejected(self, runner, patched):
        """Size with more decimals than szDecimals → PRECISION_EXCEEDED."""
        # BTC has szDecimals from mock meta — need to add it
        with patch("regard.venues.hyperliquid.commands.act.get_all_mids", return_value={"BTC": "69666.5"}):
            # Default mock meta doesn't have szDecimals, so let's provide it
            meta = {"universe": [
                {"name": "BTC", "szDecimals": 4, "maxLeverage": 50},
                {"name": "ETH", "szDecimals": 3, "maxLeverage": 50},
                {"name": "SOL", "szDecimals": 1, "maxLeverage": 20},
            ]}
            patched["info"].meta.return_value = meta
            result = runner.invoke(app, ["hl", "order", "BTC", "buy", "0.12345", "65000"])
            assert result.exit_code == 2
            assert parse(result)["error"]["code"] == "PRECISION_EXCEEDED"

    def test_valid_precision_passes(self, runner, patched):
        """Size within szDecimals → proposal created."""
        with patch("regard.venues.hyperliquid.commands.act.get_all_mids", return_value={"BTC": "69666.5"}):
            meta = {"universe": [
                {"name": "BTC", "szDecimals": 4, "maxLeverage": 50},
                {"name": "ETH", "szDecimals": 3, "maxLeverage": 50},
                {"name": "SOL", "szDecimals": 1, "maxLeverage": 20},
            ]}
            patched["info"].meta.return_value = meta
            result = runner.invoke(app, ["hl", "order", "BTC", "buy", "0.1234", "65000"])
            assert result.exit_code == 0
            assert data(result)["status"] == "pending"


class TestTransfer:
    """Transfer now creates proposals."""

    def test_missing_direction(self, runner, patched):
        result = runner.invoke(app, ["hl", "transfer", "5.00"])
        assert result.exit_code == 2
        assert parse(result)["error"]["code"] == "MISSING_OPTION"

    def test_both_from_and_to(self, runner, patched):
        """Both --from and --to is valid — creates proposal."""
        result = runner.invoke(app, ["hl", "transfer", "5.00", "--to", "xyz", "--from", "default"])
        assert result.exit_code == 0
        d = data(result)
        assert d["status"] == "pending"
        assert d["command"] == "transfer"

    def test_successful_proposal(self, runner, patched):
        """Transfer to USDC dex creates proposal with correct params."""
        result = runner.invoke(app, ["hl", "transfer", "5.00", "--to", "xyz"])
        assert result.exit_code == 0
        d = data(result)
        assert d["status"] == "pending"
        assert d["params"]["token"] == "USDC"
        assert d["params"]["dest_label"] == "xyz"
        assert d["params"]["source_label"] == "default"
        # Exchange should NOT be called
        patched["exchange"].send_asset.assert_not_called()

    def test_collateral_mismatch(self, runner, patched):
        """Transfer between dexes with different collateral tokens fails."""
        result = runner.invoke(app, ["hl", "transfer", "5.00", "--to", "flx"])
        assert result.exit_code == 2
        err = parse(result)["error"]
        assert err["code"] == "COLLATERAL_MISMATCH"
        assert "USDC" in err["message"]
        assert "USDH" in err["message"]

    def test_spot_transfer_with_token(self, runner, patched):
        """Transfer to spot with --token creates proposal."""
        result = runner.invoke(app, ["hl", "transfer", "5.00", "--to", "spot", "--token", "USDC"])
        assert result.exit_code == 0
        d = data(result)
        assert d["status"] == "pending"
        assert d["params"]["dest_label"] == "spot"
        assert d["params"]["token"] == "USDC"

    def test_spot_transfer_missing_token_from_spot(self, runner, patched):
        """Transfer from spot without --token fails (spot→perp direction)."""
        result = runner.invoke(app, ["hl", "transfer", "5.00", "--from", "spot"])
        assert result.exit_code == 2
        assert parse(result)["error"]["code"] == "MISSING_TOKEN"

    def test_spot_transfer_missing_token_to_spot(self, runner, patched):
        """Transfer to spot without --token fails (perp→spot direction).

        Regression: act.py:686 previously did `token = "USDC"` silently on
        `--to spot` when --token was omitted. That's wrong for non-USDC
        collateral dexes (flx=USDH, hyna=USDE, cash=USDT0) AND a silent pick
        among candidates for default→spot, violating Article I.
        """
        result = runner.invoke(app, ["hl", "transfer", "5.00", "--to", "spot"])
        assert result.exit_code == 2
        assert parse(result)["error"]["code"] == "MISSING_TOKEN"

    def test_transfer_uses_withdrawable_not_account_value(self, runner, patched):
        """Transfer checks withdrawable at propose time."""
        result = runner.invoke(app, ["hl", "transfer", "9800", "--to", "xyz"])
        assert result.exit_code == 4
        err = parse(result)["error"]
        assert err["code"] == "INSUFFICIENT_BALANCE"
        assert "withdrawable" in err["message"]

    def test_spot_source_balance_check(self, runner, patched):
        """Transfer from spot checks spot balance for the specific token."""
        # Mock spot_user_state to return a balance less than transfer amount
        patched["info"].spot_user_state.return_value = {
            "balances": [{"token": 0, "total": "3.00"}]
        }
        result = runner.invoke(app, ["hl", "transfer", "5.00", "--from", "spot", "--to", "default", "--token", "USDC"])
        assert result.exit_code == 4
        err = parse(result)["error"]
        assert err["code"] == "INSUFFICIENT_BALANCE"
        assert "Spot" in err["message"]

    def test_unified_account_rejected(self, runner, patched):
        """Unified accounts cannot transfer between dexes — margin is shared."""
        with patch("regard.venues.hyperliquid.commands.act.get_account_mode", return_value="unifiedAccount"):
            result = runner.invoke(app, ["hl", "transfer", "5.00", "--to", "xyz"])
            assert result.exit_code == 2
            err = parse(result)["error"]
            assert err["code"] == "UNIFIED_ACCOUNT"
            assert "unifiedAccount" in err["message"]

    def test_portfolio_margin_rejected(self, runner, patched):
        """Portfolio margin accounts also share margin — transfers are no-ops."""
        with patch("regard.venues.hyperliquid.commands.act.get_account_mode", return_value="portfolioMargin"):
            result = runner.invoke(app, ["hl", "transfer", "5.00", "--to", "xyz"])
            assert result.exit_code == 2
            err = parse(result)["error"]
            assert err["code"] == "UNIFIED_ACCOUNT"
            assert "portfolioMargin" in err["message"]

    def test_invalid_amount(self, runner, patched):
        """Non-numeric amount is rejected at propose time."""
        result = runner.invoke(app, ["hl", "transfer", "abc", "--to", "xyz"])
        assert result.exit_code == 2
        assert parse(result)["error"]["code"] == "INVALID_AMOUNT"


# ---------------------------------------------------------------------------
# Executor integration: approve → execute → exchange SDK called correctly
# ---------------------------------------------------------------------------


class TestHlOrderExecutor:
    """Approve an HL order proposal → executor fires → exchange SDK called."""

    def _propose_and_approve(self, runner, propose_args):
        """Propose an order, then approve with price bypass (delta=0)."""
        result = runner.invoke(app, propose_args)
        d = data(result)
        proposal_id = d["id"]
        mark_price = d["checks"]["mark_price"]
        with patch("regard.main._fetch_current_price", return_value=mark_price):
            return runner.invoke(app, ["approve", proposal_id])

    def test_market_order_calls_market_open(self, runner, patched):
        """Market order: approve calls exchange.market_open."""
        exchange = patched["exchange"]
        result = self._propose_and_approve(runner, ["hl", "order", "BTC", "buy", "0.1", "--market"])
        d = parse(result)
        assert d["ok"] is True
        assert d["data"]["status"] == "filled"

        exchange.market_open.assert_called_once()
        args, kwargs = exchange.market_open.call_args
        assert args[0] == "BTC"
        assert args[1] is True  # is_buy
        assert args[2] == 0.1  # size

    def test_limit_order_calls_order(self, runner, patched):
        """Limit order: approve calls exchange.order."""
        exchange = patched["exchange"]
        result = self._propose_and_approve(runner, ["hl", "order", "BTC", "buy", "0.1", "65000"])
        d = parse(result)
        assert d["ok"] is True

        exchange.order.assert_called_once()
        args, kwargs = exchange.order.call_args
        assert args[0] == "BTC"
        assert args[1] is True  # is_buy
        assert args[2] == 0.1  # size
        assert args[3] == 65000.0  # price

    def test_limit_order_with_sl_tp_calls_bulk_orders(self, runner, patched):
        """Limit + SL + TP: approve calls exchange.bulk_orders with 3 legs."""
        exchange = patched["exchange"]
        result = self._propose_and_approve(runner, [
            "hl", "order", "BTC", "buy", "0.1", "65000",
            "--sl", "60000", "--tp", "75000",
        ])
        d = parse(result)
        assert d["ok"] is True

        exchange.bulk_orders.assert_called_once()
        call_args, kwargs = exchange.bulk_orders.call_args
        order_list = call_args[0]
        assert len(order_list) == 3, f"Expected 3 legs (main + SL + TP), got {len(order_list)}"
        assert kwargs.get("grouping") == "normalTpsl"


class TestHlCancelExecutor:
    """Approve an HL cancel proposal → executor fires → exchange SDK called."""

    def test_cancel_calls_exchange_cancel(self, runner, patched):
        """Cancel: approve calls exchange.cancel."""
        exchange = patched["exchange"]
        result = runner.invoke(app, ["hl", "cancel", "BTC", "100001"])
        proposal_id = data(result)["id"]

        # Cancel proposals skip price check — no _fetch_current_price patch needed
        result = runner.invoke(app, ["approve", proposal_id])
        d = parse(result)
        assert d["ok"] is True

        exchange.cancel.assert_called_once()
        args = exchange.cancel.call_args[0]
        assert args[0] == "BTC"  # coin
        assert args[1] == 100001  # oid


# ---------------------------------------------------------------------------
# Send
# ---------------------------------------------------------------------------

MOCK_ADDRESSES = {
    "trading": {
        "address": "0xF373B4A25FC2CcF1A54d7Ce6b8326d5d15D99080",
        "chains": ["hl", "polygon"],
        "added_at": "2026-04-16T12:00:00Z",
    },
    "reserve": {
        "address": "0x3710f20c8a8b2781D878105Fbd61CC0c20fE0411",
        "chains": ["hl", "polygon"],
        "added_at": "2026-04-16T12:00:00Z",
    },
}

MOCK_SPOT_META = {
    "tokens": [_spot_token("USDC"), _spot_token("USDH")],
    "universe": [],
}


class TestHlSend:
    """HL send command tests."""

    def test_send_to_label(self, runner, patched):
        """Send to a labeled address creates proposal with balance snapshot."""
        mock_balances = [{"token": "USDC", "balance": "100.0"}]
        with patch("regard.commands.address._load_addresses", return_value=MOCK_ADDRESSES), \
             patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.venues.hyperliquid.commands.act.get_address", return_value="0xSENDER"), \
             patch("regard.venues.hyperliquid.client.get_spot_balances", return_value=mock_balances):
            patched["info"].spot_meta.return_value = MOCK_SPOT_META
            result = runner.invoke(app, ["hl", "send", "5", "--to", "reserve", "--token", "USDC"])
            d = parse(result)
            assert d["ok"] is True
            assert d["data"]["status"] == "pending"
            assert d["data"]["command"] == "send"
            assert d["data"]["params"]["dest_address"] == "0x3710f20c8a8b2781D878105Fbd61CC0c20fE0411"
            assert d["data"]["params"]["dest_label"] == "reserve"
            assert d["data"]["params"]["token"] == "USDC"
            assert d["data"]["params"]["amount"] == "5.0"
            assert "sender_balance" in d["data"]["checks"]
            assert "risk" in d["data"]["checks"]

    def test_send_missing_token(self, runner, patched):
        """Omitting --token MUST fail with MISSING_TOKEN (Constitution Article I).

        Regression guard: an earlier default of --token="USDC" silently picked
        USDC on a multi-token spot wallet (USDC + USDH + USDE + USDT0), which
        is a silent pick among candidates — forbidden by Article I.
        """
        with patch("regard.commands.address._load_addresses", return_value=MOCK_ADDRESSES), \
             patch("regard.core.project_state.load_project_env", return_value={}):
            result = runner.invoke(app, ["hl", "send", "5", "--to", "reserve"])
            assert result.exit_code == 2
            assert parse(result)["error"]["code"] == "MISSING_TOKEN"

    def test_send_unknown_label(self, runner, patched):
        """Send to unknown label fails."""
        with patch("regard.commands.address._load_addresses", return_value=MOCK_ADDRESSES), \
             patch("regard.core.project_state.load_project_env", return_value={}):
            result = runner.invoke(app, ["hl", "send", "5", "--to", "unknown", "--token", "USDC"])
            assert result.exit_code == 2
            assert parse(result)["error"]["code"] == "UNKNOWN_ADDRESS"

    def test_send_no_destination(self, runner, patched):
        """Send without --to or --to-address fails."""
        with patch("regard.core.project_state.load_project_env", return_value={}):
            result = runner.invoke(app, ["hl", "send", "5", "--token", "USDC"])
            assert result.exit_code == 2
            assert parse(result)["error"]["code"] == "MISSING_DESTINATION"

    def test_send_raw_address_blocked(self, runner, patched):
        """Raw addresses blocked by default."""
        with patch("regard.core.project_state.load_project_env", return_value={}):
            result = runner.invoke(app, ["hl", "send", "5", "--to-address", "0xF373B4A25FC2CcF1A54d7Ce6b8326d5d15D99080", "--token", "USDC"])
            assert result.exit_code == 2
            assert parse(result)["error"]["code"] == "RAW_ADDRESS_BLOCKED"

    def test_send_self_send_blocked(self, runner, patched):
        """Cannot send to yourself."""
        with patch("regard.commands.address._load_addresses", return_value={
            "myself": {"address": "0xTEST", "chains": ["hl"], "added_at": ""},
        }), patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.venues.hyperliquid.commands.act.get_address", return_value="0xTEST"):
            patched["info"].spot_meta.return_value = MOCK_SPOT_META
            result = runner.invoke(app, ["hl", "send", "5", "--to", "myself", "--token", "USDC"])
            assert result.exit_code == 2
            assert parse(result)["error"]["code"] == "SELF_SEND"

    def test_send_unknown_token(self, runner, patched):
        """Unknown token rejected."""
        with patch("regard.commands.address._load_addresses", return_value=MOCK_ADDRESSES), \
             patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.venues.hyperliquid.commands.act.get_address", return_value="0xSENDER"):
            patched["info"].spot_meta.return_value = MOCK_SPOT_META
            result = runner.invoke(app, ["hl", "send", "5", "--to", "reserve", "--token", "FAKE"])
            assert result.exit_code == 2
            assert parse(result)["error"]["code"] == "UNKNOWN_TOKEN"

    def test_send_insufficient_balance(self, runner, patched):
        """Insufficient balance rejected."""
        with patch("regard.commands.address._load_addresses", return_value=MOCK_ADDRESSES), \
             patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.venues.hyperliquid.commands.act.get_address", return_value="0xSENDER"):
            patched["info"].spot_meta.return_value = MOCK_SPOT_META
            result = runner.invoke(app, ["hl", "send", "99999", "--to", "reserve", "--token", "USDC"])
            assert result.exit_code == 4
            assert parse(result)["error"]["code"] == "INSUFFICIENT_BALANCE"


class TestHlSendExecutor:
    """Test the execute_hl_send executor."""

    def test_executor_calls_send_asset(self):
        from unittest.mock import MagicMock

        mock_exchange = MagicMock()
        mock_exchange.send_asset.return_value = {"status": "ok"}

        with patch("regard.venues.hyperliquid.commands.act.get_exchange", return_value=mock_exchange), \
             patch("regard.venues.hyperliquid.commands.act.get_address", return_value="0xSENDER"), \
             patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.core.audit.log_event"):
            from regard.venues.hyperliquid.commands.act import execute_hl_send
            result = execute_hl_send({
                "sender": "0xSENDER",
                "dest_address": "0xDEST",
                "dest_label": "reserve",
                "token": "USDC",
                "sdk_token": "USDC",
                "amount": "5.0",
                "testnet": False,
            })

        assert result["status"] == "sent"
        assert result["amount"] == "5.0"
        assert result["destination"] == "0xDEST"
        mock_exchange.send_asset.assert_called_once_with("0xDEST", "spot", "spot", "USDC", 5.0)

    def test_executor_handles_error_response(self):
        from unittest.mock import MagicMock

        mock_exchange = MagicMock()
        mock_exchange.send_asset.return_value = {"status": "err", "response": "Insufficient balance"}

        with patch("regard.venues.hyperliquid.commands.act.get_exchange", return_value=mock_exchange), \
             patch("regard.venues.hyperliquid.commands.act.get_address", return_value="0xSENDER"), \
             patch("regard.core.project_state.load_project_env", return_value={}), \
             patch("regard.core.audit.log_event"), \
             pytest.raises(SystemExit):
            from regard.venues.hyperliquid.commands.act import execute_hl_send
            execute_hl_send({
                "sender": "0xSENDER",
                "dest_address": "0xDEST",
                "dest_label": "reserve",
                "token": "USDC",
                "sdk_token": "USDC",
                "amount": "5.0",
                "testnet": False,
            })


# ---------------------------------------------------------------------------
# HIP-4 outcome order — Phase 2 write path
#
# Article II rule → test mapping per Constitutional alignment §IV. Every
# named test here pins one safety-gate rule from the brief §6 trading
# constraints. Auto-round / silent-truncate are explicitly forbidden.
# ---------------------------------------------------------------------------


class TestOutcomeOrderValidation:
    """`regard hl order #<enc> buy <int_size> <price>` validation rules.

    The conftest seeds outcomeMeta with outcome=1 (BTC daily binary) so
    `#10` (YES) / `#11` (NO) are valid coins for these tests. l2_snapshot
    returns YES at mid 0.455, NO at mid 0.545 (per conftest mock).
    """

    # --- Happy path: a valid outcome order creates a proposal ---

    def test_outcome_order_valid_returns_proposal_id(self, runner, patched):
        # 50 contracts × $0.5 = $25 notional ≥ $10 min; tick-aligned.
        result = runner.invoke(app, ["hl", "order", "#10", "buy", "50", "0.5"])
        assert result.exit_code == 0, result.output
        d = data(result)
        assert d["id"].startswith("p_")
        assert d["status"] == "pending"
        assert d["params"]["asset"] == "#10"
        assert d["params"]["size"] == "50"
        assert d["params"]["price"] == "0.5"
        # mark_price should be captured from l2_snapshot mid (Phase 2 wiring)
        assert "mark_price" in d["checks"]

    def test_outcome_order_market_skips_price_validation(self, runner, patched):
        # Market orders pass with no price; size still validated.
        result = runner.invoke(app, ["hl", "order", "#10", "buy", "50", "--market"])
        assert result.exit_code == 0
        d = data(result)
        assert d["params"]["market"] is True

    # --- Article II rule → test mapping (each safety rule has a named test) ---

    def test_outcome_order_rejects_price_below_min(self, runner, patched):
        result = runner.invoke(app, ["hl", "order", "#10", "buy", "50000", "0.0009"])
        assert result.exit_code == 2
        assert parse(result)["error"]["code"] == "OUTCOME_PRICE_OUT_OF_RANGE"

    def test_outcome_order_rejects_price_above_max(self, runner, patched):
        result = runner.invoke(app, ["hl", "order", "#10", "buy", "20", "0.9991"])
        assert result.exit_code == 2
        assert parse(result)["error"]["code"] == "OUTCOME_PRICE_OUT_OF_RANGE"

    def test_outcome_order_rejects_sub_tick_price(self, runner, patched):
        # 0.50005 is half a tick (default 0.0001).
        result = runner.invoke(app, ["hl", "order", "#10", "buy", "50", "0.50005"])
        assert result.exit_code == 2
        assert parse(result)["error"]["code"] == "OUTCOME_TICK_VIOLATION"

    def test_outcome_order_rejects_non_integer_size(self, runner, patched):
        # 1.5 contracts — Article II MUST reject (no rounding).
        result = runner.invoke(app, ["hl", "order", "#10", "buy", "1.5", "0.5"])
        assert result.exit_code == 2
        assert parse(result)["error"]["code"] == "OUTCOME_SIZE_NON_INTEGER"

    def test_outcome_order_rejects_zero_size(self, runner, patched):
        result = runner.invoke(app, ["hl", "order", "#10", "buy", "0", "0.5"])
        assert result.exit_code == 2
        assert parse(result)["error"]["code"] == "OUTCOME_SIZE_NON_INTEGER"

    def test_outcome_order_rejects_below_min_notional(self, runner, patched):
        # 5 contracts × $0.5 = $2.5 < $10 min.
        result = runner.invoke(app, ["hl", "order", "#10", "buy", "5", "0.5"])
        assert result.exit_code == 2
        assert parse(result)["error"]["code"] == "OUTCOME_MIN_NOTIONAL"

    def test_outcome_order_rejects_nan_price(self, runner, patched):
        # NaN must be rejected as OUTCOME_PRICE_OUT_OF_RANGE per
        # validate_outcome_order — Decimal-based finite check.
        result = runner.invoke(app, ["hl", "order", "#10", "buy", "50", "NaN"])
        assert result.exit_code == 2
        assert parse(result)["error"]["code"] == "OUTCOME_PRICE_OUT_OF_RANGE"

    def test_outcome_order_rejects_infinity_price(self, runner, patched):
        result = runner.invoke(app, ["hl", "order", "#10", "buy", "50", "Infinity"])
        assert result.exit_code == 2
        assert parse(result)["error"]["code"] == "OUTCOME_PRICE_OUT_OF_RANGE"

    # --- HIP-4-specific rejections ---

    def test_outcome_order_rejects_tp_sl_with_hip4_no_triggers(self, runner, patched):
        # HIP-4 has no liquidations, no triggers — reject TP/SL upfront.
        result = runner.invoke(app, ["hl", "order", "#10", "buy", "50", "0.5", "--sl", "0.4"])
        assert result.exit_code == 2
        assert parse(result)["error"]["code"] == "HIP4_NO_TRIGGERS"

    def test_outcome_order_rejects_tp_with_hip4_no_triggers(self, runner, patched):
        result = runner.invoke(app, ["hl", "order", "#10", "buy", "50", "0.5", "--tp", "0.7"])
        assert result.exit_code == 2
        assert parse(result)["error"]["code"] == "HIP4_NO_TRIGGERS"

    # --- Server classifier patterns (safety net for client-side gaps) ---


class TestOutcomeClassifier:
    """`_classify_hl_error` HIP-4 patterns. Server-side fallback for any
    edge case the client validator misses (e.g. future tick-size change)."""

    def test_classifier_maps_invalid_size_to_outcome_size_non_integer(self):
        from regard.venues.hyperliquid.commands.act import _classify_hl_error
        code, hint = _classify_hl_error("Order has invalid size")
        assert code == "OUTCOME_SIZE_NON_INTEGER"
        assert hint and "integer size" in hint

    def test_classifier_maps_min_usdh_to_outcome_min_notional(self):
        from regard.venues.hyperliquid.commands.act import _classify_hl_error
        code, hint = _classify_hl_error("Order must have minimum value of 10 USDH")
        assert code == "OUTCOME_MIN_NOTIONAL"
        assert hint and "$10 USDH" in hint

    def test_classifier_maps_tick_violation_to_outcome_tick_violation(self):
        # Pattern requires HIP-4-specific context ('outcome' or 'usdh') to
        # avoid misclassifying perp tick errors. See peer-review fixup.
        from regard.venues.hyperliquid.commands.act import _classify_hl_error
        code, _ = _classify_hl_error("Outcome price must be a multiple of 0.0001 tick")
        assert code == "OUTCOME_TICK_VIOLATION"

    def test_classifier_falls_back_to_order_rejected_for_unknown(self):
        from regard.venues.hyperliquid.commands.act import _classify_hl_error
        code, _ = _classify_hl_error("Some new venue error we haven't seen")
        assert code == "ORDER_REJECTED"

    def test_classifier_does_not_misclassify_perp_tick_error(self):
        """Regression (peer-review): pre-fix the OUTCOME_TICK_VIOLATION
        pattern matched any 'must be a multiple of 0.0001' message,
        including perp tick errors. Post-fix the pattern requires
        HIP-4-specific context ('usdh' or 'outcome') to gate."""
        from regard.venues.hyperliquid.commands.act import _classify_hl_error
        # Bare perp tick message — must NOT match OUTCOME_TICK_VIOLATION.
        code, _ = _classify_hl_error("price must be a multiple of 0.0001")
        assert code == "ORDER_REJECTED"
        # HIP-4-flavored message — must match.
        code, _ = _classify_hl_error("Outcome price must be a multiple of 0.0001 tick")
        assert code == "OUTCOME_TICK_VIOLATION"
        code, _ = _classify_hl_error("USDH-denominated price must be a multiple of 0.0001")
        assert code == "OUTCOME_TICK_VIOLATION"


class TestOutcomeApprovePriceDelta:
    """Approve-time price-delta enforcement for outcome orders.

    Constitutional alignment locked threshold: 5% pct OR 0.01 absolute,
    whichever rejects first. This test pins the absolute floor — at
    mark=0.5, a drift to 0.515 is only 3% (within pct threshold) but
    1.5¢ absolute (over the 0.01 floor) — must reject.
    """

    def test_threshold_returns_outcome_specific_for_hash_asset(self):
        from regard.main import _get_price_threshold
        # HIP-4 outcome → tight absolute floor + 5% pct.
        pct, abs_max = _get_price_threshold("hl", {"asset": "#10"})
        assert pct == 5.0
        assert abs_max == 0.01

    def test_threshold_returns_perp_default_for_non_outcome(self):
        from regard.main import _get_price_threshold
        # Perp → 0.5% pct, no absolute floor.
        pct, abs_max = _get_price_threshold("hl", {"asset": "BTC"})
        assert pct == 0.5
        assert abs_max is None

    def test_threshold_handles_missing_params(self):
        from regard.main import _get_price_threshold
        pct, abs_max = _get_price_threshold("hl", None)
        assert pct == 0.5
        assert abs_max is None


class TestOutcomeApproveE2E:
    """End-to-end: propose HIP-4 order, approve, exchange SDK called.

    Confirms that the Phase 1 resolver patch + Phase 2 validation +
    Phase 2 approve-time threshold all integrate cleanly across propose
    and approve. The mocked exchange.order stays valid because
    `info.coin_to_asset[#10]` is injected by the resolver during
    propose, so `Exchange.order(coin="#10", ...)` resolves the asset id.
    """

    # conftest l2 mock for #10 (YES): top_bid 0.45, top_ask 0.46 → mid 0.455.
    # HIP-4 thresholds: 5% pct OR 0.01 abs (whichever rejects first).
    # From mark=0.455: abs floor permits ±0.01 → 0.445–0.465; pct 5%
    # permits ±0.0228 → 0.432–0.478. Stricter is abs floor (±0.01).

    def test_outcome_limit_order_propose_then_approve_within_threshold(self, runner, patched):
        """Drift within BOTH pct AND abs thresholds → approves and executes."""
        result = runner.invoke(app, ["hl", "order", "#10", "buy", "50", "0.5"])
        d = data(result)
        proposal_id = d["id"]
        # Drift 0.455 → 0.460: pct 1.1%, abs 0.005 — well inside both.
        with patch("regard.main._fetch_current_price", return_value="0.460"):
            approve_result = runner.invoke(app, ["approve", proposal_id])
        approve_data = parse(approve_result)
        assert approve_data["ok"] is True, approve_result.output
        # Exchange SDK called with #<encoding> coin (resolver-injected asset_id).
        exchange = patched["exchange"]
        exchange.order.assert_called_once()
        args = exchange.order.call_args.args
        assert args[0] == "#10"

    def test_outcome_approve_rejects_when_mid_drifts_beyond_absolute_threshold(self, runner, patched):
        """Drift over abs (>0.01) but UNDER pct (<5%) → MUST reject.

        Load-bearing case: abs floor catches drifts that pct-only checks
        would let through on a thin book.
        """
        result = runner.invoke(app, ["hl", "order", "#10", "buy", "50", "0.5"])
        d = data(result)
        proposal_id = d["id"]
        # Drift 0.455 → 0.467: pct 2.6% (<5%), abs 0.012 (>0.01 floor).
        # Pct-only check would allow; abs floor rejects per locked threshold.
        with patch("regard.main._fetch_current_price", return_value="0.467"):
            approve_result = runner.invoke(app, ["approve", proposal_id])
        approve_data = parse(approve_result)
        assert approve_data["ok"] is False
        assert approve_data["error"]["code"] == "PRICE_DELTA_EXCEEDED"
        # Exchange NOT called — proposal rejected at gate.
        patched["exchange"].order.assert_not_called()
        patched["exchange"].market_open.assert_not_called()

    def test_outcome_approve_rejects_when_mid_drifts_beyond_percentage_threshold(self, runner, patched):
        """Drift over pct (>5%) — also over abs. Confirms either rejects."""
        result = runner.invoke(app, ["hl", "order", "#10", "buy", "50", "0.5"])
        d = data(result)
        proposal_id = d["id"]
        # Drift 0.455 → 0.485: pct 6.6% (>5%), abs 0.030 (>0.01) — both fire.
        with patch("regard.main._fetch_current_price", return_value="0.485"):
            approve_result = runner.invoke(app, ["approve", proposal_id])
        approve_data = parse(approve_result)
        assert approve_data["ok"] is False
        assert approve_data["error"]["code"] == "PRICE_DELTA_EXCEEDED"

    def test_outcome_approve_rejection_envelope_has_machine_readable_threshold_fields(self, runner, patched):
        """Regression (peer-review): the rejection envelope must carry
        `threshold_pct`, `threshold_abs`, and `triggered_by` as separate
        fields so an agent can pattern-match on which condition fired
        without parsing the human-readable label string."""
        result = runner.invoke(app, ["hl", "order", "#10", "buy", "50", "0.5"])
        d = data(result)
        proposal_id = d["id"]
        # Drift 0.455 → 0.467: abs 0.012 (>0.01), pct 2.6% (<5%) → abs fires alone.
        with patch("regard.main._fetch_current_price", return_value="0.467"):
            approve_result = runner.invoke(app, ["approve", proposal_id])
        envelope = parse(approve_result)
        err = envelope["error"]
        # Machine-readable threshold components present:
        assert err["threshold_pct"] == 5.0
        assert err["threshold_abs"] == 0.01
        # `triggered_by` distinguishes which condition fired.
        assert err["triggered_by"] == "abs"

    def test_outcome_approve_triggered_by_pct_when_pct_alone_fires(self, runner, patched):
        """`triggered_by` reflects the rejecting condition. Because the abs
        floor is the stricter check at this mark, finding a drift that
        rejects on pct ALONE (without abs) is mathematically impossible
        from mark=0.455 — abs 0.01 → ±2.2% around mark, well inside 5%.
        So pct-alone rejection requires a higher mark price (e.g. mark=1.0
        where 5% pct = 0.05 > 0.01 abs floor). Use the threshold helper
        directly to validate the triggered_by logic instead."""
        # The integration path is harder to construct; cover it via direct
        # function call in a separate test (already exists). Keep this
        # placeholder as documentation of the asymmetry.
        from regard.main import _get_price_threshold
        # Confirm at mark=0.455 abs is indeed stricter than pct.
        threshold_pct, threshold_abs = _get_price_threshold("hl", {"asset": "#10"})
        # 5% of 0.455 = 0.02275; abs 0.01. abs is stricter (smaller).
        assert threshold_abs < threshold_pct * 0.455 / 100
