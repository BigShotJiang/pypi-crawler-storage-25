"""Wallet + selfup command tests.

Tests the unified `regard wallet` command:
- Bare `regard wallet` reports status JSON
- `regard wallet <key>` saves key for all venues to project-local wallet.json
- `regard wallet --prompt` interactive path is getpass, covered via key validation
- `regard wallet --export` emits shell-eval-able export lines
"""

import json
import os
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from typer.testing import CliRunner

from regard.commands.update import _parse_version
from regard.commands.wallet import _validate_hex_key
from regard.main import app

runner = CliRunner()


# ---------------------------------------------------------------------------
# Key validation
# ---------------------------------------------------------------------------

class TestValidateHexKey:
    def test_valid_with_prefix(self):
        key = "0x" + "a" * 64
        assert _validate_hex_key(key) == "0x" + "a" * 64

    def test_valid_without_prefix(self):
        key = "b" * 64
        assert _validate_hex_key(key) == "0x" + "b" * 64

    def test_too_short(self):
        assert _validate_hex_key("0xabc") == ""

    def test_too_long(self):
        assert _validate_hex_key("0x" + "a" * 65) == ""

    def test_non_hex(self):
        assert _validate_hex_key("0x" + "g" * 64) == ""

    def test_empty(self):
        assert _validate_hex_key("") == ""

    def test_whitespace_stripped(self):
        key = "  0x" + "c" * 64 + "  "
        assert _validate_hex_key(key) == "0x" + "c" * 64


# ---------------------------------------------------------------------------
# Wallet status
# ---------------------------------------------------------------------------

class TestWalletStatus:
    """`regard wallet` with no args reports status."""

    def test_no_credentials(self):
        env = {k: v for k, v in os.environ.items()
               if not any(x in k for x in ("HYPERLIQUID", "POLYMARKET"))}
        with patch.dict(os.environ, env, clear=True):
            with patch("regard.commands.wallet.load_project_env", return_value={}):
                result = runner.invoke(app, ["wallet"])
                d = json.loads(result.stdout)
                assert d["ok"] is True
                hl = d["data"]["venues"]["hyperliquid"]
                assert hl["configured"] is False
                poly = d["data"]["venues"]["polymarket"]
                assert poly["configured"] is False
                assert "unified_key" not in d["data"]

    def test_with_hl_key_only(self):
        fake_key = "0x" + "a" * 64
        env = {k: v for k, v in os.environ.items()
               if not any(x in k for x in ("HYPERLIQUID", "POLYMARKET"))}
        env["HYPERLIQUID_PRIVATE_KEY"] = fake_key
        mock_account = MagicMock(address="0xTEST")
        with patch.dict(os.environ, env, clear=True):
            with patch("regard.commands.wallet.load_project_env", return_value={}):
                with patch("eth_account.Account.from_key", return_value=mock_account):
                    result = runner.invoke(app, ["wallet"])
                    d = json.loads(result.stdout)
                    assert d["ok"] is True
                    hl = d["data"]["venues"]["hyperliquid"]
                    assert hl["configured"] is True
                    assert hl["address"] == "0xTEST"
                    assert "mode" not in hl
                    assert d["data"]["venues"]["polymarket"]["configured"] is False
                    assert "unified_key" not in d["data"]

    def test_with_poly_key_only(self):
        fake_key = "0x" + "b" * 64
        env = {k: v for k, v in os.environ.items()
               if not any(x in k for x in ("HYPERLIQUID", "POLYMARKET"))}
        env["POLYMARKET_PRIVATE_KEY"] = fake_key
        mock_account = MagicMock(address="0xPOLY")
        with patch.dict(os.environ, env, clear=True):
            with patch("regard.commands.wallet.load_project_env", return_value={}):
                with patch("eth_account.Account.from_key", return_value=mock_account):
                    result = runner.invoke(app, ["wallet"])
                    d = json.loads(result.stdout)
                    poly = d["data"]["venues"]["polymarket"]
                    assert poly["configured"] is True
                    assert poly["address"] == "0xPOLY"

    def test_unified_key_collapses_address(self):
        """When HL + Poly resolve to the same address, report it at the top level."""
        fake_key = "0x" + "c" * 64
        env = {k: v for k, v in os.environ.items()
               if not any(x in k for x in ("HYPERLIQUID", "POLYMARKET"))}
        env["HYPERLIQUID_PRIVATE_KEY"] = fake_key
        env["POLYMARKET_PRIVATE_KEY"] = fake_key
        mock_account = MagicMock(address="0xUNIFIED")
        with patch.dict(os.environ, env, clear=True):
            with patch("regard.commands.wallet.load_project_env", return_value={}):
                with patch("eth_account.Account.from_key", return_value=mock_account):
                    result = runner.invoke(app, ["wallet"])
                    d = json.loads(result.stdout)
                    assert d["data"]["unified_key"] is True
                    assert d["data"]["address"] == "0xUNIFIED"


class TestWalletExport:
    """`regard wallet --export` emits shell-eval-able export lines to stdout.

    Designed for harnesses without env auto-injection (Codex CLI, plain
    shell). Reads keys from env first, falls back to `.regard/secrets/wallet.json`.
    Errors go to stderr so `eval "$(regard wallet --export)"` stays clean.
    """

    _HL = "0x" + "a" * 64
    _POLY = "0x" + "b" * 64

    def test_emits_both_keys_from_env(self):
        env = {k: v for k, v in os.environ.items()
               if not any(x in k for x in ("HYPERLIQUID", "POLYMARKET"))}
        env["HYPERLIQUID_PRIVATE_KEY"] = self._HL
        env["POLYMARKET_PRIVATE_KEY"] = self._POLY
        with patch.dict(os.environ, env, clear=True):
            with patch("regard.commands.wallet.load_project_env", return_value={}):
                result = runner.invoke(app, ["wallet", "--export"])
        assert result.exit_code == 0
        assert f"export HYPERLIQUID_PRIVATE_KEY={self._HL}" in result.stdout
        assert f"export POLYMARKET_PRIVATE_KEY={self._POLY}" in result.stdout
        assert not result.stdout.strip().startswith("{")

    def test_emits_from_wallet_fallback(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        secrets = tmp_path / ".regard" / "secrets"
        secrets.mkdir(parents=True, exist_ok=True)
        (secrets / "wallet.json").write_text(json.dumps({
            "evm": {"private_key": self._HL, "address": "0xTEST"}
        }))
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path.parent.parent)
        env = {k: v for k, v in os.environ.items()
               if not any(x in k for x in ("HYPERLIQUID", "POLYMARKET"))}
        with patch.dict(os.environ, env, clear=True):
            result = runner.invoke(app, ["wallet", "--export"])
        assert result.exit_code == 0
        # Single EVM wallet expands to BOTH HL and Poly export lines
        assert f"export HYPERLIQUID_PRIVATE_KEY={self._HL}" in result.stdout
        assert f"export POLYMARKET_PRIVATE_KEY={self._HL}" in result.stdout

    def test_env_wins_over_wallet_file(self, tmp_path, monkeypatch):
        """Env var takes precedence over wallet.json (same priority as the rest of the CLI)."""
        monkeypatch.chdir(tmp_path)
        secrets = tmp_path / ".regard" / "secrets"
        secrets.mkdir(parents=True, exist_ok=True)
        stale = "0x" + "c" * 64
        (secrets / "wallet.json").write_text(json.dumps({
            "evm": {"private_key": stale, "address": "0xSTALE"}
        }))
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path.parent.parent)
        env = {k: v for k, v in os.environ.items()
               if not any(x in k for x in ("HYPERLIQUID", "POLYMARKET"))}
        env["HYPERLIQUID_PRIVATE_KEY"] = self._HL
        with patch.dict(os.environ, env, clear=True):
            result = runner.invoke(app, ["wallet", "--export"])
        assert result.exit_code == 0
        assert f"export HYPERLIQUID_PRIVATE_KEY={self._HL}" in result.stdout

    def test_emits_only_configured_keys(self):
        """Only-HL configured → only HL export emitted, no Poly line."""
        env = {k: v for k, v in os.environ.items()
               if not any(x in k for x in ("HYPERLIQUID", "POLYMARKET"))}
        env["HYPERLIQUID_PRIVATE_KEY"] = self._HL
        with patch.dict(os.environ, env, clear=True):
            with patch("regard.commands.wallet.load_project_env", return_value={}):
                result = runner.invoke(app, ["wallet", "--export"])
        assert result.exit_code == 0
        assert f"export HYPERLIQUID_PRIVATE_KEY={self._HL}" in result.stdout
        assert "POLYMARKET_PRIVATE_KEY" not in result.stdout

    @pytest.mark.no_project_seed
    def test_no_keys_exits_nonzero_with_hint(self, tmp_path, monkeypatch):
        """No keys → exit 1, error hint emitted, and crucially NO `export` line
        in the output — a user who blindly eval'd the output wouldn't get junk
        in their shell env. The click/typer test runner merges stderr into
        `result.output`, so we assert on the merged stream.
        """
        monkeypatch.chdir(tmp_path)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path.parent.parent)
        env = {k: v for k, v in os.environ.items()
               if not any(x in k for x in ("HYPERLIQUID", "POLYMARKET"))}
        with patch.dict(os.environ, env, clear=True):
            result = runner.invoke(app, ["wallet", "--export"])
        assert result.exit_code == 1
        assert "no wallet found" in result.output.lower()
        assert "regard wallet <key>" in result.output
        assert "export HYPERLIQUID_PRIVATE_KEY" not in result.output
        assert "export POLYMARKET_PRIVATE_KEY" not in result.output

    def test_export_mutually_exclusive_with_key_arg(self):
        result = runner.invoke(app, ["wallet", "--export", "0x" + "a" * 64])
        assert result.exit_code == 1
        assert "does not take a key argument" in result.output

    def test_export_mutually_exclusive_with_prompt(self):
        result = runner.invoke(app, ["wallet", "--export", "--prompt"])
        assert result.exit_code == 1
        assert "does not take a key argument or --prompt" in result.output

    def test_no_json_envelope_output(self):
        """Output must be plain shell exports — any JSON framing would break eval."""
        env = {k: v for k, v in os.environ.items()
               if not any(x in k for x in ("HYPERLIQUID", "POLYMARKET"))}
        env["HYPERLIQUID_PRIVATE_KEY"] = self._HL
        env["POLYMARKET_PRIVATE_KEY"] = self._POLY
        with patch.dict(os.environ, env, clear=True):
            with patch("regard.commands.wallet.load_project_env", return_value={}):
                result = runner.invoke(app, ["wallet", "--export"])
        lines = [ln for ln in result.stdout.splitlines() if ln.strip() and not ln.strip().startswith("#")]
        assert all(ln.startswith("export ") and "=" in ln for ln in lines), lines

    def test_export_quotes_metacharacters(self):
        """A wallet/config value with shell metacharacters must NOT eval as a command.

        Defense in depth: wallet.json values go through `_validate_hex_key`
        on save, so they're clean. But config.json is hand-editable, and
        an `env.HYPERLIQUID_PRIVATE_KEY` override there could otherwise
        reach `eval` unquoted. shlex.quote() neutralizes any metachar by
        wrapping in single quotes — `eval` then assigns the literal string
        as the value, never executing the trailing command.
        """
        import shlex
        injected = "0xabc; touch /tmp/regard_pwn_marker"
        env = {k: v for k, v in os.environ.items()
               if not any(x in k for x in ("HYPERLIQUID", "POLYMARKET"))}
        env["HYPERLIQUID_PRIVATE_KEY"] = injected
        with patch.dict(os.environ, env, clear=True):
            with patch("regard.commands.wallet.load_project_env", return_value={}):
                result = runner.invoke(app, ["wallet", "--export"])
        assert result.exit_code == 0
        # shlex.quote() is the correctness contract — its output is what
        # `eval` will see as a single shell-safe token.
        expected = f"export HYPERLIQUID_PRIVATE_KEY={shlex.quote(injected)}"
        assert expected in result.stdout, f"missing safe-quoted export, got: {result.stdout!r}"


class TestWalletSaveKey:
    """`regard wallet <key>` writes to `<cwd>/.regard/secrets/wallet.json`."""

    def test_saves_to_project_local(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        fake_key = "0x" + "d" * 64
        mock_account = MagicMock(address="0xDEED")
        with patch("eth_account.Account.from_key", return_value=mock_account):
            result = runner.invoke(app, ["wallet", fake_key])
        assert result.exit_code == 0

        wallet_path = tmp_path / ".regard" / "secrets" / "wallet.json"
        assert wallet_path.exists()
        data = json.loads(wallet_path.read_text())
        assert data["evm"]["private_key"] == fake_key
        assert data["evm"]["address"] == "0xDEED"

    @pytest.mark.no_project_seed
    def test_rejects_invalid_key(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        result = runner.invoke(app, ["wallet", "not-a-key"])
        assert result.exit_code == 1
        assert not (tmp_path / ".regard" / "secrets" / "wallet.json").exists()

    @pytest.mark.no_project_seed
    def test_refuses_bootstrap_at_home(self, tmp_path, monkeypatch):
        """Saving a wallet at $HOME would write `~/.regard/` which `find_project_dir`
        skips on subsequent commands (HOME guard). Must error clearly instead
        of silently writing to a location no later command will read.
        """
        fake_home = tmp_path / "home"
        fake_home.mkdir()
        monkeypatch.chdir(fake_home)
        monkeypatch.setattr("pathlib.Path.home", lambda: fake_home)

        fake_key = "0x" + "d" * 64
        with patch("eth_account.Account.from_key", return_value=MagicMock(address="0xDEED")):
            result = runner.invoke(app, ["wallet", fake_key])
        assert result.exit_code == 1
        assert "cannot save a wallet at $HOME" in result.output
        assert not (fake_home / ".regard" / "secrets" / "wallet.json").exists()

    def test_preserves_other_top_level_fields(self, tmp_path, monkeypatch):
        """A future `solana` block (or any other top-level field) must survive re-save of EVM."""
        monkeypatch.chdir(tmp_path)
        secrets = tmp_path / ".regard" / "secrets"
        secrets.mkdir(parents=True, exist_ok=True)
        (secrets / "wallet.json").write_text(json.dumps({
            "evm": {"private_key": "0x" + "1" * 64, "address": "0xOLD"},
            "solana": {"private_key": "abc", "address": "SoL"},
        }))

        fake_key = "0x" + "e" * 64
        with patch("eth_account.Account.from_key", return_value=MagicMock(address="0xEEE")):
            result = runner.invoke(app, ["wallet", fake_key])
        assert result.exit_code == 0

        data = json.loads((secrets / "wallet.json").read_text())
        assert data["evm"]["private_key"] == fake_key
        assert data["evm"]["address"] == "0xEEE"
        assert data["solana"]["private_key"] == "abc"


class TestProjectStateLoadsWallet:
    """load_project_env() reads from .regard/secrets/wallet.json + .regard/config.json,
    walking up from CWD but stopping at HOME."""

    def test_reads_wallet_from_cwd(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path.parent)
        secrets = tmp_path / ".regard" / "secrets"
        secrets.mkdir(parents=True, exist_ok=True)
        fake_key = "0x" + "a" * 64
        (secrets / "wallet.json").write_text(json.dumps({
            "evm": {"private_key": fake_key, "address": "0xAAA"}
        }))

        from regard.core.project_state import load_project_env
        env = load_project_env()
        assert env.get("HYPERLIQUID_PRIVATE_KEY") == fake_key
        assert env.get("POLYMARKET_PRIVATE_KEY") == fake_key

    def test_reads_config_from_cwd(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path.parent)
        regard_dir = tmp_path / ".regard"
        regard_dir.mkdir(parents=True, exist_ok=True)
        (regard_dir / "config.json").write_text(json.dumps({
            "env": {"TEST_VAR": "from-config"}
        }))

        from regard.core.project_state import load_project_env
        env = load_project_env()
        assert env.get("TEST_VAR") == "from-config"

    def test_walks_up_from_subdirectory(self, tmp_path, monkeypatch):
        """User running `regard` from a subdir of the project should still
        resolve the wallet at the project root."""
        project = tmp_path / "my-project"
        subdir = project / "subdir" / "deeper"
        subdir.mkdir(parents=True)
        secrets = project / ".regard" / "secrets"
        secrets.mkdir(parents=True)
        fake_key = "0x" + "1" * 64
        (secrets / "wallet.json").write_text(json.dumps({
            "evm": {"private_key": fake_key, "address": "0x111"}
        }))

        monkeypatch.chdir(subdir)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path.parent)

        from regard.core.project_state import load_project_env
        env = load_project_env()
        assert env.get("HYPERLIQUID_PRIVATE_KEY") == fake_key

    def test_walk_stops_at_home(self, tmp_path, monkeypatch):
        """Walk must not pick up `~/.regard/` even if it exists."""
        fake_home = tmp_path / "home"
        fake_home.mkdir()
        (fake_home / ".regard" / "secrets").mkdir(parents=True)
        (fake_home / ".regard" / "secrets" / "wallet.json").write_text(
            json.dumps({"evm": {"private_key": "0x" + "f" * 64, "address": "0xLEAK"}})
        )

        project = fake_home / "project"
        project.mkdir()

        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: fake_home)

        from regard.core.project_state import load_project_env
        env = load_project_env()
        assert env == {}


class TestWalletValidatesKeyCurve:
    """Valid hex but invalid secp256k1 scalar must abort, not save a bad key.

    Note: eth_account 0.13+ actually accepts the all-zero scalar and derives a
    deterministic address from it, so we can't use that as a test case — the
    "invalid scalar" surface is specifically values >= curve order n.
    """

    @pytest.mark.no_project_seed
    def test_rejects_above_curve_order(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path.parent)
        bad_key = "0x" + "f" * 64
        result = runner.invoke(app, ["wallet", bad_key])
        assert result.exit_code == 1
        assert not (tmp_path / ".regard" / "secrets" / "wallet.json").exists()


class TestWalletPromptEmpty:
    """`regard wallet --prompt` with empty input must error, not fall through to status."""

    @pytest.mark.no_project_seed
    def test_prompt_empty_errors(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        with patch("getpass.getpass", return_value=""):
            with patch("sys.stdin.isatty", return_value=True):
                result = runner.invoke(app, ["wallet", "--prompt"])
        assert result.exit_code == 1
        assert not (tmp_path / ".regard" / "secrets" / "wallet.json").exists()


class TestAtomicWrite:
    """save_wallet uses tmp+rename so a crash mid-write can't wipe the wallet."""

    def test_uses_tmp_file_and_rename(self, tmp_path):
        from regard.core.project_state import save_wallet
        path = save_wallet({"evm": {"private_key": "0x" + "a" * 64, "address": "0xAAA"}}, tmp_path)
        assert path.exists()
        assert not (path.parent / (path.name + ".tmp")).exists()
        data = json.loads(path.read_text())
        assert data["evm"]["address"] == "0xAAA"

    def test_preserves_contents_on_simulated_crash(self, tmp_path):
        """If write_text to .tmp raises, the real wallet file must be intact."""
        from regard.core.project_state import save_wallet
        existing_wallet = {"evm": {"private_key": "0x" + "1" * 64, "address": "0xKEEP"}}
        save_wallet(existing_wallet, tmp_path)

        target = tmp_path / ".regard" / "secrets" / "wallet.json"
        original = Path  # type: ignore[assignment]

        def write_text_fail(self, *a, **kw):
            if self.suffix == ".tmp":
                raise OSError("disk full")
            return original.write_text(self, *a, **kw)

        with patch.object(Path, "write_text", write_text_fail):
            try:
                save_wallet({"evm": {"private_key": "0x" + "2" * 64, "address": "0xNEW"}}, tmp_path)
            except OSError:
                pass

        data = json.loads(target.read_text())
        assert data["evm"]["address"] == "0xKEEP"


# ---------------------------------------------------------------------------
# Selfup
# ---------------------------------------------------------------------------

class TestSelfup:
    def test_no_update(self):
        with patch("regard.commands.update._get_pypi_latest", return_value="0.6.0"):
            result = runner.invoke(app, ["selfup"])
            d = json.loads(result.stdout)
            assert d["ok"] is True
            assert d["data"]["update_available"] is False

    def test_update_available(self):
        with patch("regard.commands.update._get_pypi_latest", return_value="99.0.0"):
            result = runner.invoke(app, ["selfup"])
            d = json.loads(result.stdout)
            assert d["ok"] is True
            assert d["data"]["update_available"] is True
            assert "command" in d["data"]

    def test_pypi_unreachable(self):
        with patch("regard.commands.update._get_pypi_latest", return_value=None):
            result = runner.invoke(app, ["selfup"])
            d = json.loads(result.stdout)
            assert d["ok"] is True
            assert d["data"]["update_available"] is False
            assert d["data"]["latest"] is None


class TestParseVersion:
    def test_basic(self):
        from packaging.version import Version
        assert _parse_version("0.10.6") == Version("0.10.6")

    def test_comparison(self):
        assert _parse_version("0.10.6") > _parse_version("0.10.5")
        assert _parse_version("0.11.0") > _parse_version("0.10.99")
        assert _parse_version("1.0.0") > _parse_version("0.99.99")

    def test_rc_comparison(self):
        assert _parse_version("0.15.0rc1") > _parse_version("0.6.0")
        assert _parse_version("0.15.0") > _parse_version("0.15.0rc1")
        assert _parse_version("0.15.0rc2") > _parse_version("0.15.0rc1")

    def test_invalid(self):
        from packaging.version import Version
        assert _parse_version("") == Version("0")
        assert _parse_version(None) == Version("0")


# ---------------------------------------------------------------------------
# File permissions: wallet.json must be 0o600 (defends against other users
# on multi-user machines + umask-misconfig footguns). secrets/ dir must be
# 0o700 (defends against directory enumeration).
# ---------------------------------------------------------------------------

class TestWalletFilePermissions:
    """Ensure all writes produce locked-down permissions."""

    def test_wallet_save_sets_0o600(self, tmp_path):
        import stat

        from regard.core.project_state import save_wallet

        path = save_wallet({"evm": {"private_key": "0x" + "a" * 64, "address": "0xAAA"}}, tmp_path)
        mode = stat.S_IMODE(os.stat(path).st_mode)
        assert mode == 0o600, f"expected 0o600, got {oct(mode)}"

    def test_secrets_dir_is_0o700(self, tmp_path):
        import stat

        from regard.core.project_state import save_wallet

        save_wallet({"evm": {"private_key": "0x" + "a" * 64, "address": "0xAAA"}}, tmp_path)
        secrets_dir = tmp_path / ".regard" / "secrets"
        mode = stat.S_IMODE(os.stat(secrets_dir).st_mode)
        assert mode == 0o700, f"expected 0o700 on secrets/, got {oct(mode)}"

    def test_config_set_sets_0o600(self, tmp_path, monkeypatch):
        import stat

        from regard.commands.config import _write_setting

        monkeypatch.chdir(tmp_path)
        path = _write_setting("TEST_KEY", "test-value")

        mode = stat.S_IMODE(os.stat(path).st_mode)
        assert mode == 0o600, f"expected 0o600, got {oct(mode)}"

    def test_address_save_sets_0o600(self, tmp_path, monkeypatch):
        import stat

        from regard.commands.address import _save_addresses

        monkeypatch.chdir(tmp_path)
        _save_addresses({"alice": {"address": "0xabc", "chain": "hl"}})

        path = tmp_path / ".regard" / "config.json"
        mode = stat.S_IMODE(os.stat(path).st_mode)
        assert mode == 0o600, f"expected 0o600, got {oct(mode)}"

    def test_overwrites_existing_loose_permissions(self, tmp_path):
        """If wallet.json already exists with loose perms (e.g. user upgraded
        from a pre-chmod version), the next write should tighten to 0o600."""
        import stat

        from regard.core.project_state import save_wallet

        path = save_wallet({"evm": {"private_key": "0x" + "1" * 64, "address": "0x111"}}, tmp_path)
        os.chmod(path, 0o644)
        assert stat.S_IMODE(os.stat(path).st_mode) == 0o644

        save_wallet({"evm": {"private_key": "0x" + "2" * 64, "address": "0x222"}}, tmp_path)

        mode = stat.S_IMODE(os.stat(path).st_mode)
        assert mode == 0o600, f"expected 0o600 after overwrite, got {oct(mode)}"
