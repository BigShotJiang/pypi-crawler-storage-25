"""Contract tests — every command produces valid JSON, no tracebacks, no ANSI.

The meta-test: invoke every command (success + error cases) and assert
the output is always valid JSON with the correct envelope shape.
This single file would have caught all 10 bugs from the 2026-03-31 test run.
"""

import json
import re

import pytest

from regard.main import app

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def parse_stdout(result) -> dict:
    """Parse CLI result stdout as JSON. Fails with clear message if non-JSON."""
    stdout = result.stdout.strip() if result.stdout else ""
    assert "Traceback" not in stdout, f"Traceback in stdout: {stdout[:300]}"
    assert not re.search(r"\x1b\[[0-9;]*[a-zA-Z]", stdout), "ANSI codes in stdout"
    try:
        return json.loads(stdout)
    except json.JSONDecodeError:
        pytest.fail(f"Non-JSON stdout (exit={result.exit_code}): {stdout!r}")


def assert_envelope(data: dict):
    """Assert the output follows the envelope contract."""
    assert isinstance(data, dict)
    assert "ok" in data
    if data["ok"]:
        assert "data" in data
        assert "meta" in data
    else:
        assert "error" in data


# ---------------------------------------------------------------------------
# HL commands — success paths (with mocked SDK)
# ---------------------------------------------------------------------------

HL_SUCCESS_COMMANDS = [
    ["hl", "status"],
    ["hl", "balance"],
    ["hl", "positions"],
    ["hl", "orders"],
    ["hl", "assets"],
    ["hl", "assets", "BTC"],
    ["hl", "prices"],
    ["hl", "prices", "BTC"],
    ["hl", "book", "BTC"],
    ["hl", "funding"],
    ["hl", "funding", "BTC"],
    ["hl", "funding", "BTC", "--history", "--limit", "3"],
    ["hl", "candles", "BTC", "1h", "--limit", "2"],
    ["hl", "trades"],
    ["hl", "trades", "BTC"],
    ["hl", "preflight", "BTC", "buy", "0.01"],
    ["hl", "order", "BTC", "buy", "0.01", "65000"],
    ["hl", "order", "BTC", "sell", "0.01", "--market"],
    ["hl", "cancel", "BTC", "100001"],
    ["hl", "cancel-all"],
    ["hl", "leverage", "BTC", "10"],
    # HIP-4 read-path commands
    ["hl", "outcomes"],
    ["hl", "outcome", "1"],            # bare integer → both sides
    ["hl", "outcome", "1:yes"],        # named side
    ["hl", "outcome", "1:no"],
    ["hl", "outcome", "1:0"],          # numeric side
    ["hl", "outcome", "#10"],          # full coin form
]


@pytest.mark.parametrize("args", HL_SUCCESS_COMMANDS, ids=lambda a: " ".join(a))
def test_hl_command_produces_valid_json(runner, patched, args):
    result = runner.invoke(app, args)
    data = parse_stdout(result)
    assert_envelope(data)
    assert data["ok"] is True, f"Expected ok=True for {args}: {data}"


# ---------------------------------------------------------------------------
# HL commands — error paths (should STILL produce valid JSON)
# ---------------------------------------------------------------------------

HL_ERROR_COMMANDS = [
    # Unknown asset
    (["hl", "prices", "FAKECOIN123"], "UNKNOWN_ASSET"),
    # Invalid side
    (["hl", "order", "BTC", "invalidside", "1", "65000"], "INVALID_SIDE"),
    # Invalid TIF
    (["hl", "order", "BTC", "buy", "1", "65000", "--tif", "badvalue"], "INVALID_TIF"),
    # Missing required args (Click/Typer parse error → JSON via monkey-patch)
    (["hl", "order"], "USAGE_ERROR"),
    (["hl", "book"], "USAGE_ERROR"),
    (["hl", "candles"], "USAGE_ERROR"),
    (["hl", "leverage", "BTC"], "USAGE_ERROR"),
    (["hl", "preflight", "BTC"], "USAGE_ERROR"),
    (["hl", "outcome"], "USAGE_ERROR"),
    # HIP-4 outcome id parsing — every malformed form has its own code.
    (["hl", "outcome", ""], "INVALID_OUTCOME_ID"),
    (["hl", "outcome", "#"], "INVALID_OUTCOME_ID"),       # empty body
    (["hl", "outcome", "#abc"], "INVALID_OUTCOME_ID"),    # non-digit body
    (["hl", "outcome", "1:badside"], "INVALID_OUTCOME_ID"),
    (["hl", "outcome", "abc"], "INVALID_OUTCOME_ID"),     # not an int
    (["hl", "outcome", "1.5"], "INVALID_OUTCOME_ID"),     # not an int (float)
    # Peer-review regression cases (commit 155bc26 + fixup):
    (["hl", "outcome", "#12"], "INVALID_OUTCOME_ID"),     # SIDE-OOB: side=2 (categoricals not supported)
    (["hl", "outcome", "#010"], "INVALID_OUTCOME_ID"),    # LEAD-ZERO: leading zeros aliased #10 pre-fix
    (["hl", "outcome", "#²"], "INVALID_OUTCOME_ID"),      # UNICODE-VAL: was internal_error/exit 7 pre-fix
    (["hl", "outcome", "99999"], "UNKNOWN_OUTCOME"),      # parses but not in meta
    # Unknown option
    (["hl", "status", "--nonexistent"], "USAGE_ERROR"),
]


@pytest.mark.parametrize("args,expected_code", HL_ERROR_COMMANDS,
                         ids=lambda a: " ".join(a) if isinstance(a, list) else a)
def test_hl_error_produces_json(runner, patched, args, expected_code):
    result = runner.invoke(app, args)
    data = parse_stdout(result)
    assert_envelope(data)
    assert data["ok"] is False
    assert data["error"]["code"] == expected_code


# ---------------------------------------------------------------------------
# Display conformance — every agent-safe read MUST include `display`
# ---------------------------------------------------------------------------
#
# Regression guard against silent display-field omissions. Caught two gaps in
# 2026-04-17: (1) hl spot-balances missing display field, (2) the entire Poly
# venue missing display. Keeps the invariant enforceable as new reads land.
# Mutating commands (order/cancel/leverage/etc.) are not in scope — their
# envelopes carry proposals, not renderable data.

HL_READ_COMMANDS = [
    ["hl", "status"],
    ["hl", "balance"],
    ["hl", "positions"],
    ["hl", "orders"],
    ["hl", "spot-balances"],
    ["hl", "assets"],
    ["hl", "prices"],
    ["hl", "prices", "BTC"],
    ["hl", "book", "BTC"],
    ["hl", "funding"],
    ["hl", "candles", "BTC", "1h", "--limit", "2"],
    ["hl", "trades"],
    ["hl", "pulse"],
    ["hl", "outcomes"],
    ["hl", "outcome", "1"],
]


@pytest.mark.parametrize("args", HL_READ_COMMANDS, ids=lambda a: " ".join(a))
def test_hl_read_has_display(runner, patched, args):
    """Every HL agent-safe read MUST populate `display`.

    Poly venue has an equivalent test in test_poly.py::test_poly_read_has_display.
    """
    result = runner.invoke(app, args)
    data = parse_stdout(result)
    assert data["ok"] is True, f"{args} did not succeed: {data}"
    assert "display" in data, f"{args} missing `display` field"
    assert data["display"], f"{args} has empty `display` field"


# ---------------------------------------------------------------------------
# Global flags
# ---------------------------------------------------------------------------

def test_version_flag(runner):
    result = runner.invoke(app, ["--version"])
    # Version output is plain text (not JSON) — that's OK, it's a special case
    assert result.exit_code == 0


def test_fields_projection(runner, patched):
    result = runner.invoke(app, ["--fields", "account_value", "hl", "status"])
    data = parse_stdout(result)
    assert data["ok"] is True
    assert "account_value" in data["data"]


def test_no_args_help(runner):
    result = runner.invoke(app, [])
    # no_args_is_help exits 0 or 2 depending on Typer version — help text, not JSON (acceptable)
    assert result.exit_code in (0, 2)
