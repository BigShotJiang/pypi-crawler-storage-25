"""Tests for HIP-3 margin-mode detection and oracle-bound preflight (v0.19.11).

Covers:
- `is_isolated_only()` helper — pure function mapping margin_info dict → bool
- `get_asset_margin_info()` — runtime query against info.meta() / info.post(meta, dex=X)
- `_check_oracle_bound()` — preflight warning when price is outside oracle bound
- `regard hl leverage` command — auto-detects per-asset margin mode, no longer
  hardcoded on ':' prefix
- `regard hl order` / `regard hl stop` — oracle-bound warning appears in proposal
  warnings[] when limit/trigger is >1% from oracle
"""

import json
from unittest.mock import MagicMock, patch

import pytest
from typer.testing import CliRunner

from regard.main import app
from regard.venues.hyperliquid.client import (
    get_asset_margin_info,
    is_isolated_only,
)
from regard.venues.hyperliquid.commands.act import _check_oracle_bound, _classify_hl_error

# -----------------------------------------------------------------------------
# is_isolated_only — pure function, no mocks
# -----------------------------------------------------------------------------


class TestIsIsolatedOnly:
    def test_empty_dict_returns_false(self):
        # Native perp — no margin mode configured → cross-capable
        assert is_isolated_only({}) is False

    def test_margin_mode_normal_returns_false(self):
        assert is_isolated_only({"margin_mode": "normal"}) is False

    def test_margin_mode_strict_isolated_returns_true(self):
        assert is_isolated_only({"margin_mode": "strictIsolated"}) is True

    def test_margin_mode_no_cross_returns_true(self):
        assert is_isolated_only({"margin_mode": "noCross"}) is True

    def test_only_isolated_true_returns_true(self):
        # Deprecated flag — still honored
        assert is_isolated_only({"only_isolated": True}) is True

    def test_only_isolated_false_returns_false(self):
        assert is_isolated_only({"only_isolated": False}) is False

    def test_margin_mode_beats_only_isolated(self):
        # Both present — margin_mode is canonical
        assert is_isolated_only({"margin_mode": "normal", "only_isolated": True}) is False
        assert is_isolated_only({"margin_mode": "strictIsolated", "only_isolated": False}) is True


# -----------------------------------------------------------------------------
# get_asset_margin_info — info.meta() / info.post routing
# -----------------------------------------------------------------------------


class TestGetAssetMarginInfo:
    def test_native_perp_reads_default_meta(self):
        info = MagicMock()
        info.meta.return_value = {
            "universe": [
                {"name": "BTC", "szDecimals": 5, "maxLeverage": 50},
                {"name": "ETH", "szDecimals": 4, "maxLeverage": 50, "marginMode": "normal"},
            ]
        }
        result = get_asset_margin_info(info, "BTC")
        assert result["max_leverage"] == 50
        assert result["margin_mode"] is None  # native BTC: field absent
        assert result["only_isolated"] is None

        result_eth = get_asset_margin_info(info, "ETH")
        assert result_eth["margin_mode"] == "normal"

    def test_hip3_asset_reads_dex_scoped_meta(self):
        info = MagicMock()

        def mock_post(endpoint, payload):
            if payload.get("type") == "meta" and payload.get("dex") == "xyz":
                return {
                    "universe": [
                        {"name": "xyz:CL", "szDecimals": 3, "maxLeverage": 20,
                         "marginMode": "strictIsolated", "onlyIsolated": True},
                        {"name": "xyz:NATGAS", "szDecimals": 3, "maxLeverage": 20,
                         "marginMode": "normal", "onlyIsolated": False},
                    ]
                }
            return []

        info.post.side_effect = mock_post
        result = get_asset_margin_info(info, "xyz:CL")
        assert result["margin_mode"] == "strictIsolated"
        assert result["only_isolated"] is True
        assert result["max_leverage"] == 20

        result_ng = get_asset_margin_info(info, "xyz:NATGAS")
        assert result_ng["margin_mode"] == "normal"
        assert result_ng["only_isolated"] is False

    def test_asset_not_found_returns_empty(self):
        info = MagicMock()
        info.meta.return_value = {"universe": [{"name": "BTC"}]}
        assert get_asset_margin_info(info, "UNKNOWN") == {}

    def test_info_raises_returns_empty(self):
        info = MagicMock()
        info.meta.side_effect = RuntimeError("network down")
        # Should swallow exception, not propagate
        assert get_asset_margin_info(info, "BTC") == {}


# -----------------------------------------------------------------------------
# _check_oracle_bound — preflight warning
# -----------------------------------------------------------------------------


class TestCheckOracleBound:
    def test_within_bound_no_warning(self):
        info = MagicMock()
        with patch("regard.venues.hyperliquid.commands.act.get_asset_oracle_px", return_value=100.0):
            warnings = _check_oracle_bound(info, "BTC", 100.5, threshold_pct=1.0)
            assert warnings == []

    def test_outside_bound_emits_warning(self):
        info = MagicMock()
        with patch("regard.venues.hyperliquid.commands.act.get_asset_oracle_px", return_value=94.235):
            warnings = _check_oracle_bound(info, "xyz:CL", 93.00, "sl trigger")
            assert len(warnings) == 1
            w = warnings[0]
            assert w["code"] == "ORACLE_BOUND_WARNING"
            assert w["oracle_price"] == 94.235
            assert w["price"] == 93.00
            assert w["kind"] == "sl trigger"
            assert abs(w["delta_pct"] - 1.31) < 0.01  # ~1.31% off

    def test_no_oracle_returns_empty(self):
        info = MagicMock()
        with patch("regard.venues.hyperliquid.commands.act.get_asset_oracle_px", return_value=None):
            assert _check_oracle_bound(info, "BTC", 100.0) == []

    def test_oracle_zero_returns_empty(self):
        info = MagicMock()
        with patch("regard.venues.hyperliquid.commands.act.get_asset_oracle_px", return_value=0.0):
            assert _check_oracle_bound(info, "BTC", 100.0) == []

    def test_custom_threshold(self):
        info = MagicMock()
        with patch("regard.venues.hyperliquid.commands.act.get_asset_oracle_px", return_value=100.0):
            # At threshold 5%, 104 is within (4%), 106 is outside (6%)
            assert _check_oracle_bound(info, "X", 104.0, threshold_pct=5.0) == []
            assert len(_check_oracle_bound(info, "X", 106.0, threshold_pct=5.0)) == 1


# -----------------------------------------------------------------------------
# Integration: regard hl leverage — no more hardcoded ':' check
# -----------------------------------------------------------------------------


@pytest.fixture
def runner():
    return CliRunner()


def _parse(result):
    # stdout + stderr are mixed by CliRunner; warnings land on stderr and follow
    # the JSON response. Take the first line to get the JSON payload only.
    first_line = result.output.split("\n", 1)[0]
    return json.loads(first_line)


class TestLeverageMarginMode:
    def test_native_perp_cross_allowed(self, runner, patched):
        # Native BTC has no marginMode — cross allowed. No warning.
        with patch("regard.venues.hyperliquid.commands.act.get_asset_margin_info",
                   return_value={"margin_mode": None, "only_isolated": None, "max_leverage": 50}):
            result = runner.invoke(app, ["hl", "leverage", "BTC", "10"])
            assert result.exit_code == 0
            d = _parse(result)["data"]
            assert d["params"]["is_cross"] is True
            assert "isolated margin only" not in (result.stderr or "")

    def test_hip3_normal_mode_cross_allowed(self, runner, patched):
        # HIP-3 asset with marginMode=normal → cross allowed (no warning, no force-isolated)
        with patch("regard.venues.hyperliquid.commands.act.get_asset_margin_info",
                   return_value={"margin_mode": "normal", "only_isolated": False, "max_leverage": 20}):
            result = runner.invoke(app, ["hl", "leverage", "xyz:TSLA", "5"])
            assert result.exit_code == 0
            d = _parse(result)["data"]
            assert d["params"]["is_cross"] is True
            # Before v0.19.11, the CLI hardcoded "HIP-3 = isolated" and would force is_cross=False here

    def test_hip3_strict_isolated_forces_isolated(self, runner, patched):
        # marginMode=strictIsolated → forced isolated + warning. Use xyz:TSLA (mocked).
        with patch("regard.venues.hyperliquid.commands.act.get_asset_margin_info",
                   return_value={"margin_mode": "strictIsolated", "only_isolated": True, "max_leverage": 20}):
            result = runner.invoke(app, ["hl", "leverage", "xyz:TSLA", "5"])
            assert result.exit_code == 0
            d = _parse(result)["data"]
            assert d["params"]["is_cross"] is False

    def test_hip3_no_cross_mode_forces_isolated(self, runner, patched):
        with patch("regard.venues.hyperliquid.commands.act.get_asset_margin_info",
                   return_value={"margin_mode": "noCross", "only_isolated": True, "max_leverage": 10}):
            result = runner.invoke(app, ["hl", "leverage", "xyz:TSLA", "5"])
            assert result.exit_code == 0
            d = _parse(result)["data"]
            assert d["params"]["is_cross"] is False

    def test_deprecated_only_isolated_fallback(self, runner, patched):
        # marginMode not set, only_isolated=True (deprecated shape) → forced isolated
        with patch("regard.venues.hyperliquid.commands.act.get_asset_margin_info",
                   return_value={"margin_mode": None, "only_isolated": True, "max_leverage": 20}):
            result = runner.invoke(app, ["hl", "leverage", "xyz:TSLA", "5"])
            assert result.exit_code == 0
            d = _parse(result)["data"]
            assert d["params"]["is_cross"] is False

    def test_explicit_isolated_flag_forces_isolated(self, runner, patched):
        # User explicitly passed --isolated — params.is_cross must be False.
        # Note: as of v0.19.13 we always query margin_info (preflight needs
        # strictIsolated detection even when user set --isolated explicitly).
        with patch("regard.venues.hyperliquid.commands.act.get_asset_margin_info",
                   return_value={"margin_mode": "normal", "only_isolated": False, "max_leverage": 20}):
            result = runner.invoke(app, ["hl", "leverage", "xyz:TSLA", "5", "--isolated"])
            assert result.exit_code == 0
            d = _parse(result)["data"]
            assert d["params"]["is_cross"] is False


# -----------------------------------------------------------------------------
# Integration: regard hl order — oracle-bound warning on limit / sl / tp
# -----------------------------------------------------------------------------


class TestOrderOracleBoundWarning:
    def test_limit_within_bound_no_warning(self, runner, patched):
        # BTC at mark 69666.5 (from conftest MIDS), oracle at same → limit close → no warn
        with patch("regard.venues.hyperliquid.commands.act.get_asset_oracle_px", return_value=69666.5):
            result = runner.invoke(app, ["hl", "order", "BTC", "buy", "0.1", "69700"])
            assert result.exit_code == 0
            d = _parse(result)["data"]
            oracle_warnings = [w for w in d.get("warnings", [])
                               if isinstance(w, dict) and w.get("code") == "ORACLE_BOUND_WARNING"]
            assert oracle_warnings == []

    def test_limit_outside_bound_emits_warning(self, runner, patched):
        # Oracle 94.235, limit 93 → ~1.3% off → warn
        with patch("regard.venues.hyperliquid.commands.act.get_asset_oracle_px", return_value=94.235):
            result = runner.invoke(app, ["hl", "order", "BTC", "buy", "0.1", "93"])
            assert result.exit_code == 0
            d = _parse(result)["data"]
            oracle_warnings = [w for w in d.get("warnings", [])
                               if isinstance(w, dict) and w.get("code") == "ORACLE_BOUND_WARNING"]
            assert len(oracle_warnings) >= 1  # limit price triggered
            assert oracle_warnings[0]["kind"] == "limit"

    def test_sl_trigger_outside_bound_warns(self, runner, patched):
        # Limit at mark (no warn), but sl trigger far from oracle → warn on sl
        with patch("regard.venues.hyperliquid.commands.act.get_asset_oracle_px", return_value=69666.5):
            result = runner.invoke(app, ["hl", "order", "BTC", "buy", "0.1", "69666", "--sl", "60000"])
            assert result.exit_code == 0
            d = _parse(result)["data"]
            oracle_warnings = [w for w in d.get("warnings", [])
                               if isinstance(w, dict) and w.get("code") == "ORACLE_BOUND_WARNING"]
            # sl at 60000 vs oracle 69666.5 → ~14% off
            assert any(w["kind"] == "sl trigger" for w in oracle_warnings)


# -----------------------------------------------------------------------------
# _classify_hl_error — venue error string → specific CLI code
# -----------------------------------------------------------------------------


class TestClassifyHlError:
    def test_price_too_far_from_oracle(self):
        code, hint = _classify_hl_error("Order 0: Price too far from oracle")
        assert code == "PRICE_TOO_FAR_FROM_ORACLE"
        assert hint is not None and "oracle" in hint.lower()

    def test_price_too_far_alt_phrasing(self):
        # Alternate phrasing should also match
        code, _ = _classify_hl_error("price too far")
        assert code == "PRICE_TOO_FAR_FROM_ORACLE"

    def test_insufficient_margin(self):
        code, hint = _classify_hl_error("Insufficient margin for order")
        assert code == "INSUFFICIENT_MARGIN"
        # Hint is attached by _die_with_dex_hint for HIP-3 assets, not by the classifier itself
        assert hint is None

    def test_unknown_error_falls_back(self):
        code, hint = _classify_hl_error("Some unknown rejection from exchange")
        assert code == "ORDER_REJECTED"
        assert hint is None

    def test_case_insensitive(self):
        assert _classify_hl_error("PRICE TOO FAR FROM ORACLE")[0] == "PRICE_TOO_FAR_FROM_ORACLE"
        assert _classify_hl_error("INSUFFICIENT MARGIN")[0] == "INSUFFICIENT_MARGIN"


# -----------------------------------------------------------------------------
# Integration: stop execution surfaces classified error codes
# -----------------------------------------------------------------------------


class TestExecuteStopErrorClassification:
    def test_oracle_rejection_classified(self, patched, capsys):
        """execute_stop catches HL's 'Price too far from oracle' and classifies."""
        from regard.venues.hyperliquid.commands.act import execute_stop

        patched["exchange"].order.side_effect = RuntimeError("Order 0: Price too far from oracle")
        params = {"asset": "BTC", "trigger_price": "64000", "size": "0.05",
                  "is_long": True, "is_tp": False, "testnet": False}
        with pytest.raises(SystemExit) as exc_info:
            execute_stop(params)
        assert exc_info.value.code == 4
        captured = capsys.readouterr()
        payload = json.loads(captured.out.split("\n", 1)[0])
        assert payload["ok"] is False
        assert payload["error"]["code"] == "PRICE_TOO_FAR_FROM_ORACLE"
        assert "too far from oracle" in payload["error"]["message"].lower()
        assert "oracle" in payload["error"]["hint"].lower()

    def test_unknown_rejection_falls_back_to_generic(self, patched, capsys):
        """Unclassified errors still use ORDER_REJECTED (raw message preserved)."""
        from regard.venues.hyperliquid.commands.act import execute_stop

        patched["exchange"].order.side_effect = RuntimeError("Some unknown exchange error")
        params = {"asset": "BTC", "trigger_price": "64000", "size": "0.05",
                  "is_long": True, "is_tp": False, "testnet": False}
        with pytest.raises(SystemExit) as exc_info:
            execute_stop(params)
        assert exc_info.value.code == 4
        captured = capsys.readouterr()
        payload = json.loads(captured.out.split("\n", 1)[0])
        assert payload["error"]["code"] == "ORDER_REJECTED"
        assert "some unknown exchange error" in payload["error"]["message"].lower()


class TestStopOracleBoundWarning:
    def test_stop_within_bound_no_warning(self, runner, patched):
        # Set up a mock position for BTC at mark 69666.5, stop at 69000 → close enough
        with patch("regard.venues.hyperliquid.commands.act.get_all_positions",
                   return_value=[{"coin": "BTC", "szi": "0.1", "liquidationPx": "50000"}]):
            with patch("regard.venues.hyperliquid.commands.act.get_asset_oracle_px", return_value=69666.5):
                result = runner.invoke(app, ["hl", "stop", "BTC", "69500"])
                assert result.exit_code == 0
                d = _parse(result)["data"]
                oracle_warnings = [w for w in d.get("warnings", [])
                                   if isinstance(w, dict) and w.get("code") == "ORACLE_BOUND_WARNING"]
                assert oracle_warnings == []

    def test_stop_outside_bound_warns(self, runner, patched):
        # xyz:CL-style tight bound: oracle 94.235, stop at 93.00 → ~1.3% off → warn
        # Use BTC in test since positions are mocked — thresholds still apply
        with patch("regard.venues.hyperliquid.commands.act.get_all_positions",
                   return_value=[{"coin": "BTC", "szi": "0.1", "liquidationPx": "50000"}]):
            with patch("regard.venues.hyperliquid.commands.act.get_asset_oracle_px", return_value=69666.5):
                result = runner.invoke(app, ["hl", "stop", "BTC", "50000"])
                # Stop at 50000 vs oracle 69666.5 → ~28% off
                assert result.exit_code == 0
                d = _parse(result)["data"]
                oracle_warnings = [w for w in d.get("warnings", [])
                                   if isinstance(w, dict) and w.get("code") == "ORACLE_BOUND_WARNING"]
                assert len(oracle_warnings) >= 1
                assert oracle_warnings[0]["kind"] == "sl trigger"


# -----------------------------------------------------------------------------
# v0.19.13: leverage error classification + preflight on open positions
# -----------------------------------------------------------------------------


class TestClassifyLeverageTypeLocked:
    """'Cannot switch leverage type with open position' maps to LEVERAGE_TYPE_LOCKED."""

    def test_exact_phrase(self):
        code, hint = _classify_hl_error("Cannot switch leverage type with open position.")
        assert code == "LEVERAGE_TYPE_LOCKED"
        assert hint is not None and "close" in hint.lower()

    def test_case_insensitive(self):
        code, _ = _classify_hl_error("CANNOT SWITCH LEVERAGE TYPE with open position")
        assert code == "LEVERAGE_TYPE_LOCKED"

    def test_embedded_in_wrapper(self):
        # ccxt wraps the message — our classifier looks at substring.
        code, _ = _classify_hl_error(
            'hyperliquid {"status":"err","response":"Cannot switch leverage type with open position."}'
        )
        assert code == "LEVERAGE_TYPE_LOCKED"


class TestExecuteLeverageErrorResponse:
    """execute_leverage now checks status:err and classifies — no silent swallow.

    Previously the response was discarded; HL rejections that come as HTTP 200
    + `{"status":"err","response":msg}` were masked as success.
    """

    def test_type_switch_rejection_classified(self, patched, capsys):
        from regard.venues.hyperliquid.commands.act import execute_leverage

        patched["exchange"].update_leverage.return_value = {
            "status": "err",
            "response": "Cannot switch leverage type with open position.",
        }
        params = {"asset": "BTC", "leverage": 10, "is_cross": False, "testnet": False}
        with pytest.raises(SystemExit) as exc_info:
            execute_leverage(params)
        assert exc_info.value.code == 4
        captured = capsys.readouterr()
        payload = json.loads(captured.out.split("\n", 1)[0])
        assert payload["ok"] is False
        assert payload["error"]["code"] == "LEVERAGE_TYPE_LOCKED"
        assert "cannot switch leverage type" in payload["error"]["message"].lower()

    def test_unknown_rejection_falls_back(self, patched, capsys):
        from regard.venues.hyperliquid.commands.act import execute_leverage

        patched["exchange"].update_leverage.return_value = {
            "status": "err",
            "response": "Some novel leverage rejection from HL",
        }
        params = {"asset": "BTC", "leverage": 10, "is_cross": True, "testnet": False}
        with pytest.raises(SystemExit) as exc_info:
            execute_leverage(params)
        assert exc_info.value.code == 4
        captured = capsys.readouterr()
        payload = json.loads(captured.out.split("\n", 1)[0])
        # Unclassified → generic fallback, but raw message preserved
        assert payload["error"]["code"] == "ORDER_REJECTED"
        assert "some novel leverage rejection" in payload["error"]["message"].lower()

    def test_success_response_unchanged(self, patched):
        """status:ok response still returns normally."""
        from regard.venues.hyperliquid.commands.act import execute_leverage

        patched["exchange"].update_leverage.return_value = {
            "status": "ok",
            "response": {"type": "default"},
        }
        params = {"asset": "BTC", "leverage": 10, "is_cross": True, "testnet": False}
        result = execute_leverage(params)
        assert result["asset"] == "BTC"
        assert result["leverage"] == 10
        assert result["margin_mode"] == "cross"

    def test_non_dict_response_not_swallowed(self, patched, capsys):
        """Defensive: future SDK drift returning a bare string must not be
        silently treated as success — same class of bug this fix addresses."""
        from regard.venues.hyperliquid.commands.act import execute_leverage

        patched["exchange"].update_leverage.return_value = "Cannot switch leverage type with open position."
        params = {"asset": "BTC", "leverage": 10, "is_cross": False, "testnet": False}
        with pytest.raises(SystemExit) as exc_info:
            execute_leverage(params)
        assert exc_info.value.code == 4
        captured = capsys.readouterr()
        payload = json.loads(captured.out.split("\n", 1)[0])
        assert payload["ok"] is False
        # Message should still be classifiable
        assert payload["error"]["code"] == "LEVERAGE_TYPE_LOCKED"


class TestLeveragePreflight:
    """regard hl leverage emits warnings[] when a position is already open.

    Positions from conftest DEFAULT_USER_STATE: BTC @ 10x cross, ETH @ 5x cross.
    """

    def test_no_open_position_no_warnings(self, runner, patched):
        # SOL is in the resolver (conftest mock_info.coin_to_asset) but has no
        # position in DEFAULT_USER_STATE (only BTC + ETH).
        result = runner.invoke(app, ["hl", "leverage", "SOL", "5"])
        assert result.exit_code == 0
        d = _parse(result)["data"]
        codes = [w.get("code") for w in d.get("warnings", []) if isinstance(w, dict)]
        assert "LEVERAGE_TYPE_SWITCH_WITH_POSITION" not in codes
        assert "LEVERAGE_INCREASE_STRICT_ISOLATED" not in codes

    def test_type_switch_warns(self, runner, patched):
        # BTC has cross 10x position in conftest; request --isolated → type switch
        result = runner.invoke(app, ["hl", "leverage", "BTC", "10", "--isolated"])
        assert result.exit_code == 0
        d = _parse(result)["data"]
        warnings = [w for w in d.get("warnings", []) if isinstance(w, dict)]
        codes = [w.get("code") for w in warnings]
        assert "LEVERAGE_TYPE_SWITCH_WITH_POSITION" in codes
        warning = next(w for w in warnings if w.get("code") == "LEVERAGE_TYPE_SWITCH_WITH_POSITION")
        assert warning["current_margin_type"] == "cross"
        assert warning["requested_margin_type"] == "isolated"

    def test_strict_isolated_increase_warns(self, runner, patched):
        # xyz:TSLA (in resolver) with strictIsolated 10x position, request 20x → margin removal
        with patch("regard.venues.hyperliquid.commands.act.get_asset_margin_info",
                   return_value={"margin_mode": "strictIsolated", "only_isolated": True, "max_leverage": 20}):
            with patch("regard.venues.hyperliquid.commands.act.get_all_positions",
                       return_value=[{
                           "coin": "xyz:TSLA",
                           "szi": "1.0",
                           "leverage": {"type": "isolated", "value": 10},
                       }]):
                result = runner.invoke(app, ["hl", "leverage", "xyz:TSLA", "20"])
                assert result.exit_code == 0
                d = _parse(result)["data"]
                codes = [w.get("code") for w in d.get("warnings", []) if isinstance(w, dict)]
                assert "LEVERAGE_INCREASE_STRICT_ISOLATED" in codes

    def test_strict_isolated_decrease_no_hard_warning(self, runner, patched):
        # Decreasing leverage on strictIsolated ADDS margin → allowed, only info-level warn
        with patch("regard.venues.hyperliquid.commands.act.get_asset_margin_info",
                   return_value={"margin_mode": "strictIsolated", "only_isolated": True, "max_leverage": 20}):
            with patch("regard.venues.hyperliquid.commands.act.get_all_positions",
                       return_value=[{
                           "coin": "xyz:TSLA",
                           "szi": "1.0",
                           "leverage": {"type": "isolated", "value": 20},
                       }]):
                result = runner.invoke(app, ["hl", "leverage", "xyz:TSLA", "10"])
                assert result.exit_code == 0
                d = _parse(result)["data"]
                codes = [w.get("code") for w in d.get("warnings", []) if isinstance(w, dict)]
                assert "LEVERAGE_INCREASE_STRICT_ISOLATED" not in codes
                # Expect info-level warn about value change on an open position
                assert "LEVERAGE_CHANGE_WITH_POSITION" in codes

    def test_same_leverage_same_type_no_warning(self, runner, patched):
        # BTC position is 10x cross; request BTC 10 (cross) → no change → no warn
        result = runner.invoke(app, ["hl", "leverage", "BTC", "10"])
        assert result.exit_code == 0
        d = _parse(result)["data"]
        codes = [w.get("code") for w in d.get("warnings", []) if isinstance(w, dict)]
        assert "LEVERAGE_TYPE_SWITCH_WITH_POSITION" not in codes
        assert "LEVERAGE_CHANGE_WITH_POSITION" not in codes

    def test_value_change_same_type_info_warning(self, runner, patched):
        # BTC position is 10x cross; request BTC 5 (cross) → value change info-warn
        result = runner.invoke(app, ["hl", "leverage", "BTC", "5"])
        assert result.exit_code == 0
        d = _parse(result)["data"]
        codes = [w.get("code") for w in d.get("warnings", []) if isinstance(w, dict)]
        assert "LEVERAGE_CHANGE_WITH_POSITION" in codes
        assert "LEVERAGE_TYPE_SWITCH_WITH_POSITION" not in codes

    def test_positions_fetch_error_emits_preflight_unavailable(self, runner, patched):
        # get_all_positions raising shouldn't block proposal creation, but the
        # agent must see a PREFLIGHT_UNAVAILABLE warning so silence != "safe".
        with patch("regard.venues.hyperliquid.commands.act.get_all_positions",
                   side_effect=Exception("RPC down")):
            result = runner.invoke(app, ["hl", "leverage", "BTC", "10"])
            assert result.exit_code == 0
            d = _parse(result)["data"]
            assert d["status"] == "pending"
            codes = [w.get("code") for w in d.get("warnings", []) if isinstance(w, dict)]
            assert "PREFLIGHT_UNAVAILABLE" in codes

    def test_strict_isolated_missing_leverage_value_still_warns(self, runner, patched):
        # Data gap: position exists but leverage.value is missing/None. strictIsolated
        # asset means ANY leverage change is risky — warn unconditionally rather
        # than let the strictIsolated guard short-circuit on current_lev=0.
        with patch("regard.venues.hyperliquid.commands.act.get_asset_margin_info",
                   return_value={"margin_mode": "strictIsolated", "only_isolated": True, "max_leverage": 20}):
            with patch("regard.venues.hyperliquid.commands.act.get_all_positions",
                       return_value=[{
                           "coin": "xyz:TSLA",
                           "szi": "1.0",
                           "leverage": {"type": "isolated"},  # no "value"
                       }]):
                result = runner.invoke(app, ["hl", "leverage", "xyz:TSLA", "10"])
                assert result.exit_code == 0
                d = _parse(result)["data"]
                warnings = [w for w in d.get("warnings", []) if isinstance(w, dict)]
                codes = [w.get("code") for w in warnings]
                assert "LEVERAGE_INCREASE_STRICT_ISOLATED" in codes
                w = next(w for w in warnings if w.get("code") == "LEVERAGE_INCREASE_STRICT_ISOLATED")
                assert w["current_leverage"] is None
