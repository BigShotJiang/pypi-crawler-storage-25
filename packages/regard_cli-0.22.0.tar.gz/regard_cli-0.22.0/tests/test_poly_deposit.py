"""Tests for `regard poly deposit` — Bridge API integration.

Flow under test:
1. `poly deposit <amount>` — proposal-time Bridge API checks (supported, min, balance)
2. execute_poly_deposit — submits USDC.transfer to bridge deposit address on Polygon,
   polls /status until COMPLETED / FAILED / timeout.

Isolation strategy: directly patch `_get_key` and `get_address` on the client
module rather than relying on env/settings files. Previous test-suite attempts
with `monkeypatch.setenv` hit cross-test state pollution (some other test's
short/bad key ended up in `os.environ` under certain ordering).
"""

import json
from contextlib import ExitStack
from unittest.mock import MagicMock, patch

import pytest
from typer.testing import CliRunner

from regard.main import app
from regard.venues.polymarket.commands.act import execute_poly_deposit

runner = CliRunner()

WALLET = "0x1293F4b3E29f427defFc14300d5d926b2671a221"
DEPOSIT_ADDRESS = "0x883741180B1Ef758fc9d65218f78A9cc942D0Fb4"
USDC_NATIVE = "0x3c499c542cEF5E3811e1192ce70d8cC03d5c3359"
PUSD_ADDRESS = "0xC011a7E12a19f7B1f670d46F03B03f3342E82DFB"
FAKE_KEY = "0x" + "1" + "2" * 63

# Matches the canonical supported-asset row on Polygon for native USDC
_POLYGON_USDC_ASSET = {
    "chainId": "137",
    "chainName": "Polygon",
    "token": {
        "name": "USD Coin",
        "symbol": "USDC",
        "address": USDC_NATIVE,
        "decimals": 6,
    },
    "minCheckoutUsd": 2,
}


def _parse(result) -> dict:
    """Parse CliRunner stdout as JSON, surfacing raw output on failure."""
    stdout = result.stdout.strip() if result.stdout else ""
    try:
        return json.loads(stdout)
    except json.JSONDecodeError:
        pytest.fail(f"Non-JSON stdout (exit={result.exit_code}): {stdout!r}")


def _key_patches():
    """Return a list of patch() objects that fix _get_key + get_address.

    Use with `contextlib.ExitStack` for clean stacking alongside test-specific patches.
    """
    return [
        patch("regard.venues.polymarket.client._get_key", return_value=FAKE_KEY),
        patch("regard.venues.polymarket.client.get_address", return_value=WALLET),
    ]


# ---------------------------------------------------------------------------
# Proposal creation (poly deposit)
# ---------------------------------------------------------------------------


class TestDepositProposal:
    def test_creates_proposal(self):
        """Happy path: amount + wallet balance ok → proposal with deposit_address locked in."""
        with ExitStack() as stack:
            for p in _key_patches():
                stack.enter_context(p)
            stack.enter_context(patch("regard.venues.polymarket.commands.act.get_bridge_asset_spec",
                                      return_value=_POLYGON_USDC_ASSET))
            stack.enter_context(patch("regard.venues.polymarket.commands.act.get_bridge_deposit_addresses",
                                      return_value={"evm": DEPOSIT_ADDRESS, "svm": "", "btc": "", "tron": ""}))
            stack.enter_context(patch("regard.venues.polymarket.client.get_wallet_balances",
                                      return_value={"pusd": "0.00", "usdc_e": "0.00", "usdc": "10.00",
                                                    "pol": "1.0", "rpc_ok": True}))
            result = runner.invoke(app, ["poly", "deposit", "5"])

        data = _parse(result)
        assert data["ok"] is True, f"expected ok=True, got {data}"
        p = data["data"]
        assert p["venue"] == "poly"
        assert p["command"] == "deposit"
        assert p["params"]["amount"] == "5.000000"
        assert p["params"]["amount_raw"] == "5000000"
        assert p["params"]["token"] == "usdc"
        assert p["params"]["token_address"] == USDC_NATIVE
        assert p["params"]["deposit_address"] == DEPOSIT_ADDRESS
        assert p["params"]["source_chain_id"] == 137
        assert p["checks"]["source_chain"] == "Polygon"
        assert p["checks"]["deposit_address"] == DEPOSIT_ADDRESS
        warnings_text = " ".join(p["warnings"]).lower()
        # Two-step narrative: bridge → USDC.e, then wrap → pUSD
        assert "poly wrap" in warnings_text
        assert "pusd" in warnings_text

    def test_rejects_below_min(self):
        """Amount below min ($2 USD on Polygon) → BELOW_MIN_DEPOSIT."""
        with ExitStack() as stack:
            for p in _key_patches():
                stack.enter_context(p)
            stack.enter_context(patch("regard.venues.polymarket.commands.act.get_bridge_asset_spec",
                                      return_value=_POLYGON_USDC_ASSET))
            result = runner.invoke(app, ["poly", "deposit", "1"])

        data = _parse(result)
        assert data["ok"] is False
        assert data["error"]["code"] == "BELOW_MIN_DEPOSIT"

    def test_rejects_insufficient_balance(self):
        """Balance check at propose time — wallet < requested → INSUFFICIENT_BALANCE."""
        with ExitStack() as stack:
            for p in _key_patches():
                stack.enter_context(p)
            stack.enter_context(patch("regard.venues.polymarket.commands.act.get_bridge_asset_spec",
                                      return_value=_POLYGON_USDC_ASSET))
            stack.enter_context(patch("regard.venues.polymarket.client.get_wallet_balances",
                                      return_value={"pusd": "0.00", "usdc_e": "0.00", "usdc": "3.00",
                                                    "pol": "1.0", "rpc_ok": True}))
            result = runner.invoke(app, ["poly", "deposit", "10"])

        data = _parse(result)
        assert data["ok"] is False
        assert data["error"]["code"] == "INSUFFICIENT_BALANCE"

    def test_rejects_unsupported_token(self):
        """--token that isn't usdc/usdc_e → UNSUPPORTED_DEPOSIT_TOKEN."""
        result = runner.invoke(app, ["poly", "deposit", "5", "--token", "dai"])
        data = _parse(result)
        assert data["ok"] is False
        assert data["error"]["code"] == "UNSUPPORTED_DEPOSIT_TOKEN"

    def test_rejects_non_listed_token_from_bridge(self):
        """If Bridge API /supported-assets drops USDC (e.g. during migration), reject."""
        with ExitStack() as stack:
            for p in _key_patches():
                stack.enter_context(p)
            stack.enter_context(patch("regard.venues.polymarket.commands.act.get_bridge_asset_spec",
                                      return_value=None))
            result = runner.invoke(app, ["poly", "deposit", "5"])

        data = _parse(result)
        assert data["ok"] is False
        assert data["error"]["code"] == "UNSUPPORTED_DEPOSIT_TOKEN"

    def test_bridge_api_unreachable(self):
        """Bridge API network failure → BRIDGE_API_UNREACHABLE (retryable)."""
        with ExitStack() as stack:
            for p in _key_patches():
                stack.enter_context(p)
            stack.enter_context(patch("regard.venues.polymarket.commands.act.get_bridge_asset_spec",
                                      side_effect=RuntimeError("connection refused")))
            result = runner.invoke(app, ["poly", "deposit", "5"])

        data = _parse(result)
        assert data["ok"] is False
        assert data["error"]["code"] == "BRIDGE_API_UNREACHABLE"
        assert data["error"]["retryable"] is True


# ---------------------------------------------------------------------------
# Executor (execute_poly_deposit)
# ---------------------------------------------------------------------------


def _mock_w3(balance_raw: int = 100 * 10**6):
    """Build a w3 mock: balance check + transfer build + receipt."""
    w3 = MagicMock()
    w3.to_checksum_address.side_effect = lambda a: a
    w3.eth.block_number = 55000000
    w3.eth.get_transaction_count.return_value = 1

    token_contract = MagicMock()
    token_contract.functions.balanceOf.return_value.call.return_value = balance_raw
    transfer_tx = {
        "from": WALLET, "nonce": 1, "gas": 100_000,
        "gasPrice": 30_000_000_000, "chainId": 137,
    }
    token_contract.functions.transfer.return_value.build_transaction.return_value = transfer_tx
    w3.eth.contract.return_value = token_contract

    receipt = {"status": 1, "blockNumber": 55000001}
    w3.eth.wait_for_transaction_receipt.return_value = receipt
    return w3


_BASE_PARAMS = {
    "sender": WALLET,
    "recipient": WALLET,
    "amount": "5.000000",
    "amount_raw": "5000000",
    "token": "usdc",
    "token_name": "USDC",
    "token_address": USDC_NATIVE,
    "token_decimals": 6,
    "source_chain_id": 137,
    "deposit_address": DEPOSIT_ADDRESS,
    "min_usd": 2,
}


def test_executor_completed_pusd_dest():
    """Bridge reports pUSD delivery → no next_command hint (nothing to chain)."""
    mock_w3 = _mock_w3()
    src_tx_bytes = b"\x01" * 32

    bridge_final = {
        "fromChainId": "137",
        "fromTokenAddress": USDC_NATIVE,
        "fromAmountBaseUnit": "5000000",
        "toChainId": "137",
        "toTokenAddress": PUSD_ADDRESS,
        "status": "COMPLETED",
        "txHash": "0xabc123",
        "createdTimeMs": 1700000000000,
    }

    with patch("regard.venues.polymarket.commands.act.get_web3", return_value=mock_w3), \
         patch("regard.venues.polymarket.client._get_key", return_value=FAKE_KEY), \
         patch("regard.core.evm.simulate_and_send", return_value=src_tx_bytes), \
         patch("regard.core.evm.get_safe_gas_price", return_value=30_000_000_000), \
         patch("regard.venues.polymarket.commands.act.poll_bridge_status", return_value=bridge_final), \
         patch("regard.core.audit.log_event"), \
         patch("eth_account.Account.from_key") as mock_from_key:
        mock_account = MagicMock()
        mock_account.address = WALLET
        mock_from_key.return_value = mock_account
        result = execute_poly_deposit(_BASE_PARAMS)

    assert result["status"] == "COMPLETED"
    assert result["src_tx_hash"].startswith("0x")
    assert result["bridge_tx_id"] == "0xabc123"
    assert result["token_source"] == "USDC"
    assert result["token_dest"] == "pUSD"
    assert "next_command" not in result  # pUSD-destination case: nothing to chain


def test_executor_completed_usdce_dest_surfaces_wrap_hint():
    """Bridge delivered USDC.e (the actual same-chain Polygon behavior) →
    result includes next_command telling agent to chain `regard poly wrap`.
    """
    USDCE = "0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174"
    src_tx_bytes = b"\x01" * 32

    # Mock w3 where balanceOf() returns 9.99 USDC.e (post-bridge, after fee)
    mock_w3 = _mock_w3()
    # Override the default balance mock to return delivered-amount-sized balance
    token_contract = MagicMock()
    token_contract.functions.balanceOf.return_value.call.return_value = 9990000  # 9.99 USDC.e
    token_contract.functions.transfer.return_value.build_transaction.return_value = {
        "from": WALLET, "nonce": 1, "gas": 100_000,
        "gasPrice": 30_000_000_000, "chainId": 137,
    }
    mock_w3.eth.contract.return_value = token_contract

    bridge_final = {
        "fromChainId": "137",
        "fromTokenAddress": USDC_NATIVE,
        "fromAmountBaseUnit": "10000000",
        "toChainId": "137",
        "toTokenAddress": USDCE,
        "status": "COMPLETED",
        "txHash": "0xbridge_internal_id",
        "createdTimeMs": 1700000000000,
    }

    with patch("regard.venues.polymarket.commands.act.get_web3", return_value=mock_w3), \
         patch("regard.venues.polymarket.client._get_key", return_value=FAKE_KEY), \
         patch("regard.core.evm.simulate_and_send", return_value=src_tx_bytes), \
         patch("regard.core.evm.get_safe_gas_price", return_value=30_000_000_000), \
         patch("regard.venues.polymarket.commands.act.poll_bridge_status", return_value=bridge_final), \
         patch("regard.core.audit.log_event"), \
         patch("eth_account.Account.from_key") as mock_from_key:
        mock_account = MagicMock()
        mock_account.address = WALLET
        mock_from_key.return_value = mock_account
        result = execute_poly_deposit(_BASE_PARAMS)

    assert result["status"] == "COMPLETED"
    assert result["token_dest"] == "USDC.e"
    assert result["token_dest_address"].lower() == USDCE.lower()
    assert result["amount_delivered"] == "9.990000"
    # next_command directs the agent to chain into the pUSD wrap
    assert result["next_command"] == "regard poly wrap 9.990000"
    assert "usdc.e" in result["next_command_reason"].lower()
    assert "pusd" in result["next_command_reason"].lower()


def test_executor_bridge_failed():
    """Source tx mined, bridge FAILED → die DEPOSIT_BRIDGE_FAILED with tx context."""
    mock_w3 = _mock_w3()
    src_tx_bytes = b"\x01" * 32

    bridge_final = {"status": "FAILED", "txHash": None, "createdTimeMs": 1700000000000}

    with patch("regard.venues.polymarket.commands.act.get_web3", return_value=mock_w3), \
         patch("regard.venues.polymarket.client._get_key", return_value=FAKE_KEY), \
         patch("regard.core.evm.simulate_and_send", return_value=src_tx_bytes), \
         patch("regard.core.evm.get_safe_gas_price", return_value=30_000_000_000), \
         patch("regard.venues.polymarket.commands.act.poll_bridge_status", return_value=bridge_final), \
         patch("regard.core.audit.log_event"), \
         patch("eth_account.Account.from_key") as mock_from_key:
        mock_account = MagicMock()
        mock_account.address = WALLET
        mock_from_key.return_value = mock_account
        with pytest.raises(SystemExit):
            execute_poly_deposit(_BASE_PARAMS)


def test_executor_bridge_timeout_returns_submitted():
    """Bridge still processing at timeout → return SUBMITTED partial (don't die)."""
    mock_w3 = _mock_w3()
    src_tx_bytes = b"\x01" * 32

    bridge_final = {"status": "PROCESSING", "createdTimeMs": 1700000000000}

    with patch("regard.venues.polymarket.commands.act.get_web3", return_value=mock_w3), \
         patch("regard.venues.polymarket.client._get_key", return_value=FAKE_KEY), \
         patch("regard.core.evm.simulate_and_send", return_value=src_tx_bytes), \
         patch("regard.core.evm.get_safe_gas_price", return_value=30_000_000_000), \
         patch("regard.venues.polymarket.commands.act.poll_bridge_status", return_value=bridge_final), \
         patch("regard.core.audit.log_event"), \
         patch("eth_account.Account.from_key") as mock_from_key:
        mock_account = MagicMock()
        mock_account.address = WALLET
        mock_from_key.return_value = mock_account
        result = execute_poly_deposit(_BASE_PARAMS)

    assert result["status"] == "SUBMITTED"
    assert result["bridge_status_at_timeout"] == "PROCESSING"
    assert "poll" in result["hint"].lower()


def test_executor_bridge_undetected_returns_partial():
    """Bridge never detected the source tx (poll returned None) → partial status, don't die."""
    mock_w3 = _mock_w3()
    src_tx_bytes = b"\x01" * 32

    with patch("regard.venues.polymarket.commands.act.get_web3", return_value=mock_w3), \
         patch("regard.venues.polymarket.client._get_key", return_value=FAKE_KEY), \
         patch("regard.core.evm.simulate_and_send", return_value=src_tx_bytes), \
         patch("regard.core.evm.get_safe_gas_price", return_value=30_000_000_000), \
         patch("regard.venues.polymarket.commands.act.poll_bridge_status", return_value=None), \
         patch("regard.core.audit.log_event"), \
         patch("eth_account.Account.from_key") as mock_from_key:
        mock_account = MagicMock()
        mock_account.address = WALLET
        mock_from_key.return_value = mock_account
        result = execute_poly_deposit(_BASE_PARAMS)

    assert result["status"] == "SOURCE_CONFIRMED_BRIDGE_UNDETECTED"
    assert result["src_tx_hash"].startswith("0x")


def test_executor_sender_mismatch():
    """Current key doesn't match proposal sender → SENDER_MISMATCH."""
    mock_w3 = _mock_w3()

    with patch("regard.venues.polymarket.commands.act.get_web3", return_value=mock_w3), \
         patch("regard.venues.polymarket.client._get_key", return_value=FAKE_KEY), \
         patch("eth_account.Account.from_key") as mock_from_key:
        mock_account = MagicMock()
        mock_account.address = "0x000000000000000000000000000000000000dead"
        mock_from_key.return_value = mock_account
        with pytest.raises(SystemExit):
            execute_poly_deposit(_BASE_PARAMS)


def test_executor_source_tx_reverts():
    """Source USDC.transfer tx reverts → DEPOSIT_TX_REVERTED."""
    mock_w3 = _mock_w3()
    mock_w3.eth.wait_for_transaction_receipt.return_value = {"status": 0, "blockNumber": 1}
    src_tx_bytes = b"\x01" * 32

    with patch("regard.venues.polymarket.commands.act.get_web3", return_value=mock_w3), \
         patch("regard.venues.polymarket.client._get_key", return_value=FAKE_KEY), \
         patch("regard.core.evm.simulate_and_send", return_value=src_tx_bytes), \
         patch("regard.core.evm.get_safe_gas_price", return_value=30_000_000_000), \
         patch("regard.core.audit.log_event"), \
         patch("eth_account.Account.from_key") as mock_from_key:
        mock_account = MagicMock()
        mock_account.address = WALLET
        mock_from_key.return_value = mock_account
        with pytest.raises(SystemExit):
            execute_poly_deposit(_BASE_PARAMS)


def test_executor_execute_time_balance_drift():
    """Balance dropped between propose + approve → die INSUFFICIENT_BALANCE with current state."""
    mock_w3 = _mock_w3(balance_raw=1 * 10**6)  # only 1 USDC now, needed 5

    with patch("regard.venues.polymarket.commands.act.get_web3", return_value=mock_w3), \
         patch("regard.venues.polymarket.client._get_key", return_value=FAKE_KEY), \
         patch("regard.core.audit.log_event"), \
         patch("eth_account.Account.from_key") as mock_from_key:
        mock_account = MagicMock()
        mock_account.address = WALLET
        mock_from_key.return_value = mock_account
        with pytest.raises(SystemExit):
            execute_poly_deposit(_BASE_PARAMS)
