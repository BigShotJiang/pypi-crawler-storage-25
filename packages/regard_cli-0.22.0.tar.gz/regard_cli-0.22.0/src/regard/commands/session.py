"""Session commands — context management and trading analysis.

Reads Claude Code session transcripts (~/.claude/projects/<encoded-cwd>/*.jsonl),
extracts trades, research chains, tilt signals, and session context.

Commands: gm, gg, cope, pnl, tilt, what
"""

import json
import os
import re
from datetime import datetime, timedelta, timezone
from pathlib import Path

import typer

session_app = typer.Typer(
    name="session",
    no_args_is_help=True,
    help="Session commands — context management and trading analysis.",
)


# --- Session discovery ---

UUID_RE = re.compile(r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\.jsonl$')


def _get_session_base_path():
    """Derive session directory from CWD."""
    cwd = os.getcwd()
    encoded = cwd.replace("/", "-")
    session_dir = Path.home() / ".claude" / "projects" / encoded
    return str(session_dir) if session_dir.is_dir() else None


def _find_session_files(base_path):
    """Session JSONL files sorted by modification time, newest first."""
    try:
        files = [
            os.path.join(base_path, f) for f in os.listdir(base_path)
            if UUID_RE.match(f)
        ]
    except OSError:
        return []
    files.sort(key=lambda f: os.path.getmtime(f), reverse=True)
    return files


# --- Entry parsing ---

def _extract_entries(filepath):
    """Parse session JSONL into (timestamp, role, text) tuples.

    Roles: U=user, A=assistant, T=tool_use, R=tool_result
    """
    entries = []
    try:
        with open(filepath, encoding='utf-8', errors='ignore') as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    e = json.loads(line)
                    ts = e.get("timestamp", "")
                    t = e.get("type")

                    if t == "user":
                        c = e.get("message", {}).get("content", "")
                        if isinstance(c, str) and c.strip():
                            if "<command-name>" not in c[:50]:
                                entries.append((ts, "U", c))
                        elif isinstance(c, list):
                            for item in c:
                                if item.get("type") == "text":
                                    entries.append((ts, "U", item.get("text", "")))
                                elif item.get("type") == "tool_result":
                                    content = item.get("content", "")
                                    if isinstance(content, list):
                                        content = " ".join(
                                            b.get("text", str(b)) if isinstance(b, dict) else str(b)
                                            for b in content
                                        )
                                    entries.append((ts, "R", content))

                    elif t == "assistant":
                        for b in e.get("message", {}).get("content", []) or []:
                            if b.get("type") == "text":
                                entries.append((ts, "A", b.get("text", "")))
                            elif b.get("type") == "tool_use":
                                n = b.get("name", "")
                                inp = json.dumps(b.get("input", {}))
                                entries.append((ts, "T", f"{n}: {inp}"))
                except (json.JSONDecodeError, KeyError):
                    pass
    except OSError:
        pass
    return entries


def _load_entries(session_files, max_sessions=5):
    """Load and merge entries from multiple session files."""
    all_entries = []
    for sf in session_files[:max_sessions]:
        all_entries.extend(_extract_entries(sf))
    all_entries.sort(key=lambda x: x[0])
    return all_entries


# --- Trade & research extraction ---

RESEARCH_SKILLS = frozenset({
    'chans-research', 'discord-research', 'dune', 'x',
    'substack-research', 'telegram-research', 'reddit-chainstack',
    'search-obsidian', 'youtube-transcript',
})


def _extract_hl_command(text):
    """Extract regard hl command string from a Bash tool call entry."""
    m = re.search(r'"command":\s*"(regard hl [^"]+)"', text)
    return m.group(1) if m else None


def _is_hl_order(text):
    # Trailing space discriminates `hl order` (placement) from `hl orders` (list).
    return text.startswith("Bash:") and '"regard hl order ' in text


_HL_ORDER_SIDES = {"buy", "sell"}
_HL_ORDER_ASSET_RE = re.compile(r'^[A-Za-z][A-Za-z0-9:_-]*$')
_HL_ORDER_NUMERIC_RE = re.compile(r'^-?\d+(\.\d+)?$')


def _parse_hl_order(cmd):
    """Parse 'regard hl order ASSET SIDE SIZE [PRICE] [--flags]' into dict.

    Returns None for invocations that don't match a real order placement
    (help mode, shell noise, wrong arg order, piped variants). Validates:
      - side ∈ {buy, sell}
      - asset is an identifier (letters/digits/colon/underscore/hyphen)
      - size is numeric
    """
    parts = cmd.split()
    if len(parts) < 6:
        return None
    asset, side, size = parts[3], parts[4].lower(), parts[5]
    if side not in _HL_ORDER_SIDES:
        return None
    if not _HL_ORDER_ASSET_RE.match(asset):
        return None
    if not _HL_ORDER_NUMERIC_RE.match(size):
        return None
    price = parts[6] if len(parts) > 6 and not parts[6].startswith('--') else None
    if price is not None and not _HL_ORDER_NUMERIC_RE.match(price):
        price = None
    return {
        'asset': asset,
        'side': side,
        'size': size,
        'price': price,
        'market': '--market' in cmd,
        'reduce_only': '--reduce-only' in cmd,
    }


def _extract_trades(entries):
    """Find all regard hl order calls with their results."""
    trades = []
    for i, (ts, role, text) in enumerate(entries):
        if role != "T" or not _is_hl_order(text):
            continue
        cmd = _extract_hl_command(text)
        if not cmd:
            continue
        info = _parse_hl_order(cmd)
        if not info:
            continue
        info['timestamp'] = ts
        info['index'] = i
        info['raw'] = cmd
        # Find result (next R entry within 10 entries)
        for j in range(i + 1, min(i + 10, len(entries))):
            if entries[j][1] == "R":
                try:
                    raw = json.loads(entries[j][2])
                    # Unwrap output envelope if present
                    if isinstance(raw, dict) and raw.get("ok") and "data" in raw:
                        info['result'] = raw["data"]
                    else:
                        info['result'] = raw
                except (json.JSONDecodeError, TypeError):
                    info['result_raw'] = entries[j][2][:500]
                break
        trades.append(info)
    return trades


def _extract_research(entries):
    """Find research skill invocations and web searches."""
    research = []
    for i, (ts, role, text) in enumerate(entries):
        if role != "T":
            continue
        if text.startswith("Skill:"):
            m = re.search(r'"skill":\s*"([^"]+)"', text)
            if m:
                name = m.group(1).split(':')[0]
                if name in RESEARCH_SKILLS:
                    research.append({'timestamp': ts, 'skill': m.group(1), 'index': i})
        elif text.startswith(("WebSearch:", "WebFetch:")):
            research.append({'timestamp': ts, 'skill': text.split(':')[0], 'index': i})
    return research


def _get_context_window(entries, trade_index):
    """Entries between previous trade (or start) and this trade."""
    prev = 0
    for i in range(trade_index - 1, -1, -1):
        if entries[i][1] == "T" and _is_hl_order(entries[i][2]):
            prev = i + 1
            break
    return entries[prev:trade_index]



# --- Time helpers ---

def _parse_ts(ts):
    if not ts:
        return None
    try:
        return datetime.fromisoformat(ts.replace("Z", "+00:00"))
    except (ValueError, TypeError):
        return None


def _parse_time_modifier(mod):
    """Parse pnl modifier into (start, end) UTC datetimes."""
    now = datetime.now(timezone.utc)
    today_start = now.replace(hour=0, minute=0, second=0, microsecond=0)

    if not mod or mod == '1d':
        return today_start, now
    if mod == 'max':
        return datetime.min.replace(tzinfo=timezone.utc), now
    if mod == 'ytd':
        return now.replace(month=1, day=1, hour=0, minute=0, second=0, microsecond=0), now

    m = re.match(r'^(\d+)([dwmy])$', mod)
    if m:
        n, u = int(m.group(1)), m.group(2)
        delta = {'d': timedelta(days=n), 'w': timedelta(weeks=n),
                 'm': timedelta(days=n * 30), 'y': timedelta(days=n * 365)}[u]
        return now - delta, now

    m = re.match(r'^(\d{1,2}/\d{1,2})-(\d{1,2}/\d{1,2})$', mod)
    if m:
        y = now.year
        start = datetime.strptime(f"{y}/{m.group(1)}", "%Y/%m/%d").replace(tzinfo=timezone.utc)
        end = datetime.strptime(f"{y}/{m.group(2)}", "%Y/%m/%d").replace(
            hour=23, minute=59, second=59, tzinfo=timezone.utc)
        return start, end

    return today_start, now


def _filter_by_time(entries, start, end):
    return [(ts, r, t) for ts, r, t in entries
            if (dt := _parse_ts(ts)) and start <= dt <= end]


def _today_entries(entries):
    today = datetime.now().date()
    return [(ts, r, t) for ts, r, t in entries
            if (dt := _parse_ts(ts)) and dt.astimezone().date() == today]



# --- Session loading helper ---

# Scan depth per command
_DEPTHS = {
    'gm': 10,
    'gg': 3,
    'cope': 20,
    'pnl': 30,
    'tilt': 3,
    'what': 5,
}


def _load_session(command: str, pnl_max: bool = False):
    """Load session entries, exit with error if none found."""
    from regard.core.output import die
    base_path = _get_session_base_path()
    if not base_path:
        die("validation_error", "NO_SESSION_DIR", "No session directory found for CWD",
            hint="Run from the regard-computer workspace directory", exit_code=2)

    session_files = _find_session_files(base_path)
    if not session_files:
        die("validation_error", "NO_SESSION_FILES", "No session files found",
            hint="Start a session first — session transcripts accumulate automatically", exit_code=2)

    if pnl_max:
        return _load_entries(session_files, max_sessions=len(session_files))
    return _load_entries(session_files, max_sessions=_DEPTHS.get(command, 5))


# --- Commands ---

def _find_gg_handoffs() -> list:
    """Find gg handoff docs in CWD/gg/handoffs/, newest first."""
    gg_dir = Path.cwd() / "gg" / "handoffs"
    if not gg_dir.is_dir():
        return []
    files = sorted(gg_dir.glob("*.md"), key=lambda f: f.stat().st_mtime, reverse=True)
    return [str(f) for f in files]


@session_app.command()
def gm():
    """Pick up where you left off — reads gg handoffs, falls back to transcript reconstruction.

    Outputs JSON with handoff content, recent trades, and research for the skill to present.
    """
    from regard.core.output import output

    result = {
        "handoff": None,
        "handoff_path": None,
        "unwrapped_trades": [],
        "unwrapped_research": [],
        "transcript_trades": [],
        "transcript_research": [],
        "source": "none",
    }

    # 1. Check for gg handoff docs
    handoffs = _find_gg_handoffs()
    if handoffs:
        latest = handoffs[0]
        try:
            content = Path(latest).read_text()
            result["handoff"] = content
            result["handoff_path"] = latest
            result["source"] = "handoff"
        except Exception:
            pass

    # 2. Load transcripts for unwrapped activity / fallback reconstruction
    base_path = _get_session_base_path()
    if not base_path:
        output(result, None)
        return
    session_files = _find_session_files(base_path)
    if not session_files:
        output(result, None)
        return
    entries = _load_entries(session_files[:_DEPTHS.get('gm', 10)])

    trades = _extract_trades(entries)
    research = _extract_research(entries)

    if result["handoff"]:
        # Find activity AFTER the handoff file's mtime
        handoff_mtime = Path(result["handoff_path"]).stat().st_mtime
        handoff_ts = datetime.fromtimestamp(handoff_mtime, tz=timezone.utc).isoformat()
        after = [(ts, r, t) for ts, r, t in entries if ts > handoff_ts]
        after_trades = _extract_trades(after)
        after_research = _extract_research(after)
        result["unwrapped_trades"] = [{"asset": t["asset"], "side": t["side"], "size": t["size"],
                                        "timestamp": t.get("timestamp", ""), "raw": t.get("raw", "")}
                                       for t in after_trades]
        result["unwrapped_research"] = [{"timestamp": r["timestamp"], "skill": r["skill"]}
                                         for r in after_research]
    else:
        # No handoff — fall back to transcript reconstruction
        result["source"] = "transcript"
        for t in trades[-20:]:
            ctx = _get_context_window(entries, t['index'])
            ctx_entries = [{"timestamp": ts, "role": {"U": "user", "A": "assistant", "T": "tool", "R": "result"}.get(role, role),
                            "text": text[:300]} for ts, role, text in ctx]
            result["transcript_trades"].append({
                "asset": t["asset"], "side": t["side"], "size": t["size"],
                "price": t.get("price"), "reduce_only": t.get("reduce_only", False),
                "timestamp": t.get("timestamp", ""),
                "result": t.get("result", ""),
                "context": ctx_entries,
            })
        result["transcript_research"] = [{"timestamp": r["timestamp"], "skill": r["skill"]}
                                          for r in research[-20:]]

    result["all_handoffs"] = handoffs[:10]
    output(result, None)


@session_app.command()
def gg():
    """Wrap session — extract structured data for handoff doc.

    Outputs JSON with trades, research, context per trade, and key messages.
    The skill reads this output and writes the actual handoff markdown to gg/handoffs/.
    """
    from regard.core.output import output

    entries = _load_session('gg')
    today = _today_entries(entries)
    if not today:
        today = entries[-500:]  # fallback: last 500 entries if nothing "today"

    trades = _extract_trades(today)
    research = _extract_research(today)

    # Build per-trade context (conversation leading up to each trade)
    trade_data = []
    for t in trades:
        ctx = _get_context_window(today, t['index'])
        ctx_entries = []
        for ts, role, text in ctx:
            ctx_entries.append({
                "timestamp": ts,
                "role": {"U": "user", "A": "assistant", "T": "tool", "R": "result"}.get(role, role),
                "text": text[:500],
            })
        trade_data.append({
            "asset": t["asset"],
            "side": t["side"],
            "size": t["size"],
            "price": t.get("price"),
            "market": t.get("market", False),
            "reduce_only": t.get("reduce_only", False),
            "timestamp": t.get("timestamp", ""),
            "result": t.get("result", t.get("result_raw", "")),
            "context": ctx_entries,
        })

    research_data = [{"timestamp": r["timestamp"], "skill": r["skill"]} for r in research]

    # Key user messages (for thesis extraction)
    user_msgs = []
    for ts, role, text in today:
        if role == "U" and len(text.strip()) > 20:
            user_msgs.append({"timestamp": ts, "text": text[:500]})

    # Key assistant messages (for reasoning extraction)
    assistant_msgs = []
    for ts, role, text in today:
        if role == "A" and len(text.strip()) > 50:
            assistant_msgs.append({"timestamp": ts, "text": text[:500]})

    result = {
        "trades": trade_data,
        "trade_count": len(trade_data),
        "research": research_data,
        "research_count": len(research_data),
        "user_messages": user_msgs[-30:],
        "assistant_messages": assistant_msgs[-30:],
        "total_entries": len(today),
        "time_range": {
            "first": today[0][0] if today else "",
            "last": today[-1][0] if today else "",
        },
    }
    output(result, None)


@session_app.command()
def cope(
    assets: list[str] = typer.Argument(None, help="Assets to check thesis for"),
):
    """Thesis check — find original reasoning for positions.

    Searches gg handoff docs first, falls back to transcript reconstruction.
    Outputs JSON with thesis context per asset for the skill to reason about.
    """
    from regard.core.output import output

    if not assets:
        from regard.core.output import die
        die("validation_error", "MISSING_ARGUMENT", "Specify assets to check", hint="cope BTC ETH", exit_code=2)

    # Search handoff docs for thesis
    handoffs = _find_gg_handoffs()
    handoff_content = {}
    for hf in handoffs:
        try:
            content = Path(hf).read_text()
            for asset in assets:
                au = asset.upper()
                if au in content.upper() and au not in handoff_content:
                    handoff_content[au] = {"path": hf, "content": content}
        except Exception:
            continue

    # Search transcripts for trade context
    base_path = _get_session_base_path()
    if base_path:
        session_files = _find_session_files(base_path)
        entries = _load_entries(session_files[:_DEPTHS.get('cope', 20)]) if session_files else []
    else:
        entries = []

    trades = _extract_trades(entries) if entries else []

    results = []
    for asset in assets:
        au = asset.upper()
        entry = {"asset": au, "source": "none", "handoff": None, "trade": None, "context": []}

        # Handoff doc?
        if au in handoff_content:
            entry["source"] = "handoff"
            entry["handoff"] = {
                "path": handoff_content[au]["path"],
                "content": handoff_content[au]["content"][:3000],
            }

        # Transcript trade?
        opening = None
        for t in reversed(trades):
            if t['asset'].upper() == au and not t.get('reduce_only'):
                opening = t
                break

        if opening:
            r = opening.get('result', {})
            price = r.get('avg_price', opening.get('price', '?')) if isinstance(r, dict) else '?'
            entry["trade"] = {
                "side": opening["side"],
                "size": opening["size"],
                "price": price,
                "timestamp": opening.get("timestamp", ""),
            }

            ctx = _get_context_window(entries, opening['index'])
            entry["context"] = [
                {"timestamp": ts, "role": {"U": "user", "A": "assistant", "T": "tool", "R": "result"}.get(role, role),
                 "text": text[:500]}
                for ts, role, text in ctx
            ]
            if entry["source"] == "none":
                entry["source"] = "transcript"

        results.append(entry)

    output(results, None)


@session_app.command()
def pnl(
    modifier: str | None = typer.Argument(None, help="Time range: 1d, 5d, 1m, ytd, max, MM/DD-MM/DD"),
):
    """P&L for a time range."""
    from regard.core.output import output

    entries = _load_session('pnl', pnl_max=(modifier == 'max'))
    start, end = _parse_time_modifier(modifier)
    filtered = _filter_by_time(entries, start, end)
    trades = _extract_trades(filtered)

    balance_calls = []
    for ts, role, text in filtered:
        if role == "T":
            cmd = _extract_hl_command(text)
            if cmd and (cmd.startswith('regard hl balance') or cmd.startswith('regard hl status')):
                balance_calls.append(ts)

    trade_data = []
    for t in trades:
        r = t.get('result', {})
        price = r.get('avg_price', t.get('price', '')) if isinstance(r, dict) else t.get('price', '')
        status = r.get('status', '') if isinstance(r, dict) else ''
        trade_data.append({
            "asset": t["asset"],
            "side": t["side"],
            "size": t["size"],
            "price": price,
            "status": status,
            "reduce_only": t.get("reduce_only", False),
            "timestamp": t.get("timestamp", ""),
        })

    result = {
        "range": modifier or "1d",
        "trade_count": len(trades),
        "balance_checks": len(balance_calls),
        "trades": trade_data,
        "time_range": {
            "start": start.isoformat(),
            "end": end.isoformat(),
        },
    }
    output(result, None)


_LEVEL_RANK = {"GREEN": 0, "YELLOW": 1, "ORANGE": 2, "RED": 3, "BLACK": 4}


def _level_from_score(score: float) -> str:
    """Score → level. Worse score = higher level.

    Note: BLACK is *not* derived from score. It's a hard-limit state
    (daily budget hit, sleep > 36h, sentinel dissent) — caller layers
    BLACK on top of the score-derived level.
    """
    if score < 30:
        return "RED"
    if score < 50:
        return "ORANGE"
    if score < 70:
        return "YELLOW"
    return "GREEN"


def _level_from_count(n: int) -> str:
    """Indicator count → level. Each compound trigger bumps a tier."""
    if n >= 3:
        return "RED"
    if n >= 2:
        return "ORANGE"
    if n >= 1:
        return "YELLOW"
    return "GREEN"


def _max_level(*levels: str) -> str:
    """Take the worst (highest-ranked) of the given levels."""
    return max(levels, key=lambda lv: _LEVEL_RANK[lv])


@session_app.command()
def tilt():
    """Session health check — score-based tilt detection.

    Composite tilt score in [0, 100]; lower = worse. Level is the WORSE of
    score-derived (GREEN ≥70 / YELLOW 50–69 / ORANGE 30–49 / RED <30) and
    count-derived (GREEN 0 / YELLOW 1 / ORANGE 2 / RED 3+). Indicators
    surface the *why*. See `thoughts/research/2026-04-30_tilt-v2-design.md`
    Section 4.3 for the score formula and weights.
    """
    from regard.core.output import output

    entries = _load_session('tilt')
    today = _today_entries(entries)
    trades = _extract_trades(today)

    # Phase 1 signal contributions — placeholders for signals landing in
    # subsequent tasks. Each task replaces the zero with a real computation.
    # Score formula stays stable; only the inputs evolve.

    # Today's HL fills, newest-first. Single fetch shared across the loss-
    # streak, first-red, and (future) daily-budget signals. Degrades to []
    # if no wallet or no network — the transcript-derived signals (freq,
    # size, revenge) below still work standalone.
    from regard.core.project_state import load_tilt_config
    from regard.venues.hyperliquid.trades_history import (
        consecutive_losses as _hl_consecutive_losses,
    )
    from regard.venues.hyperliquid.trades_history import (
        fetch_recent_fills,
        first_red_in_session,
        rolling_baseline,
        win_streak_with_size_escalation,
    )
    _tilt_cfg = load_tilt_config()
    _today_start = datetime.now(timezone.utc).replace(
        hour=0, minute=0, second=0, microsecond=0,
    )
    _hl_fills = fetch_recent_fills(start=_today_start, limit=200)
    consecutive_losses = _hl_consecutive_losses(_hl_fills)

    # Rolling baseline pulled from a longer window (default 7 days). Used to
    # refine size-deviation and frequency-acceleration signals against the
    # trader's typical pattern, not just current-session internal averages.
    # Cold-start: returns None when <50 samples → caller falls back to
    # session-relative computation below.
    _baseline_days = int(_tilt_cfg.get("size_deviation_baseline_days", 7) or 7)
    _baseline_start = datetime.now(timezone.utc) - timedelta(days=_baseline_days)
    _baseline_fills = fetch_recent_fills(start=_baseline_start, limit=2000)
    _baseline = rolling_baseline(_baseline_fills)

    # First-red-of-session pivot — community 73%-of-losses-after-first-red
    # finding. Fires once any of today's realized fills closes at a loss;
    # raises propose-approve friction for the rest of the session.
    # Honors the `tilt.first_red_pivot_enabled` config flag (default true).
    first_red_pivot = (
        bool(_tilt_cfg.get("first_red_pivot_enabled", True))
        and first_red_in_session(_hl_fills)
    )

    # Win-streak + size-escalation — Tendler's Winner's Tilt. Compound
    # only: pure streaks aren't tilt; upsizing on streaks is.
    win_streak_size_escalation = win_streak_with_size_escalation(
        _hl_fills,
        win_threshold=int(_tilt_cfg.get("win_streak_threshold", 5)),
    )

    # Session wall-clock duration — hours since first HL trade today.
    # Captures the "I've been at the screen" pattern even when fills
    # are absent (no trades yet → 0). Independent from sleep signal.
    # Use `default=0` on the generator so a fills list with all-zero/missing
    # `time_ms` does not crash with ValueError("min() arg is empty sequence").
    session_wallclock_hours = 0.0
    _earliest_ms = min(
        (f["time_ms"] for f in _hl_fills if f.get("time_ms")),
        default=0,
    )
    if _earliest_ms:
        try:
            _now = datetime.now(timezone.utc)
            _elapsed = (
                _now - datetime.fromtimestamp(_earliest_ms / 1000, tz=timezone.utc)
            ).total_seconds()
            session_wallclock_hours = max(0.0, _elapsed / 3600)
        except (OverflowError, OSError, ValueError):
            # Defensive — extreme/garbage timestamps shouldn't crash tilt
            session_wallclock_hours = 0.0

    # Sleep / time-since-rest — declarative-only in Phase 1. Returns 0
    # when sleep_window_local isn't set; users who haven't declared their
    # schedule don't get penalized. Wearable/inactivity inference is Phase 5.
    from regard.core.sleep_signal import hours_since_last_wakeup
    sleep_debt_hours = hours_since_last_wakeup(_tilt_cfg.get("sleep_window_local"))

    # Daily-loss-budget — sum today's realized losses, compute % of budget.
    # If budget is unset, signal contributes 0 (no penalty for users who
    # haven't pre-committed). Account-value-based default deferred to later.
    daily_loss_pct_consumed = 0.0
    _loss_budget_usd = _tilt_cfg.get("daily_loss_budget_usd")
    if _loss_budget_usd and _loss_budget_usd > 0:
        _today_realized_loss = sum(
            f.get("closed_pnl", 0)
            for f in _hl_fills
            if f.get("closed_pnl", 0) < 0
        )
        _loss_abs = abs(_today_realized_loss)
        daily_loss_pct_consumed = min(100.0, (_loss_abs / _loss_budget_usd) * 100)

    # HL leverage-ratchet — within-session 2× → 10× → 50× progression.
    # Snapshots leverage from `info.user_state` to a tilt-scoped session
    # state file at `<project>/.regard/tilt_session.json`; detects ratchet
    # by comparing current to earliest-in-session.
    leverage_ratchet = False
    leverage_ratchet_descriptions: list[str] = []
    try:
        from regard.core.project_dir import find_project_dir
        from regard.core.tilt_session_state import (
            load_leverage_history,
            record_leverage_snapshot,
        )
        from regard.venues.hyperliquid.leverage_helper import (
            detect_leverage_ratchet,
            fetch_current_leverage,
        )
        _hl_cfg = _tilt_cfg.get("hyperliquid", {}) if isinstance(_tilt_cfg.get("hyperliquid"), dict) else {}
        _lev_threshold = float(_hl_cfg.get("leverage_ratchet_threshold", 5))
        _current_leverage = fetch_current_leverage()
        _project_dir_for_state = find_project_dir()
        if _project_dir_for_state is not None:
            _history = load_leverage_history(_project_dir_for_state)
            leverage_ratchet, leverage_ratchet_descriptions = detect_leverage_ratchet(
                _history, _current_leverage, threshold=_lev_threshold,
            )
            # Record AFTER detection so the comparison uses pre-existing
            # history; the new snapshot becomes baseline for the NEXT call.
            record_leverage_snapshot(_current_leverage, _project_dir_for_state)
    except (Exception, SystemExit):
        leverage_ratchet = False
        leverage_ratchet_descriptions = []

    # Polymarket long-shot escalation — count positions priced ≤5¢ that
    # have no thesis logged in `<project>/gg/`. Thesis-vs-evidence mismatch
    # is the "I have an edge" tilt signature (community u/pathway_surfer).
    polymarket_longshot_count = 0
    try:
        from regard.core.project_dir import find_project_dir
        from regard.venues.polymarket.positions_helper import (
            count_unguarded_longshots,
            fetch_polymarket_positions,
        )
        _pm_positions = fetch_polymarket_positions()
        if _pm_positions:
            _pm_cfg = _tilt_cfg.get("polymarket", {}) if isinstance(_tilt_cfg.get("polymarket"), dict) else {}
            _ls_threshold = float(_pm_cfg.get("longshot_threshold_cents", 5)) / 100.0
            polymarket_longshot_count = count_unguarded_longshots(
                _pm_positions,
                find_project_dir(),
                longshot_threshold=_ls_threshold,
            )
    except (Exception, SystemExit):
        # Polymarket signal degrades to 0 on any failure — same pattern as
        # HL signals above. The other signals still fire standalone.
        polymarket_longshot_count = 0

    # BLACK hard-limit overrides apply REGARDLESS of transcript trade count.
    # A user with no transcript trades but an exhausted budget or 36h+ awake
    # is still in BLACK — the v1 early-return that ignored these is a bug.
    _hard_black = (
        daily_loss_pct_consumed >= 100
        or sleep_debt_hours >= float(
            _tilt_cfg.get("sleep_thresholds_hours", {}).get("red", 36)
        )
    )

    if len(trades) < 2 and not _hard_black:
        # Transcript-derived signals (size, freq, revenge) need 2+ trades to
        # mean anything; HL-API signals can still fire. Surface ALL non-
        # transcript signals here for parity with the full-path indicators —
        # missing entries here cause silent under-warning when the trader
        # has no transcript context (the prior peer-review pattern).
        _early_sleep_thresholds = _tilt_cfg.get("sleep_thresholds_hours", {})
        _early_sleep_yellow = float(_early_sleep_thresholds.get("yellow", 18) or 18)
        early_indicators = []
        if consecutive_losses >= 3:
            early_indicators.append(f"loss-streak: {consecutive_losses} in a row")
        if first_red_pivot:
            early_indicators.append("first red of session")
        if win_streak_size_escalation:
            early_indicators.append("win-streak + size escalation")
        if session_wallclock_hours >= 6:
            early_indicators.append(f"session: {session_wallclock_hours:.1f}h continuous")
        if sleep_debt_hours >= _early_sleep_yellow:
            early_indicators.append(f"awake: {sleep_debt_hours:.0f}h")
        if daily_loss_pct_consumed >= 50:
            early_indicators.append(f"daily budget: {daily_loss_pct_consumed:.0f}% consumed")
        if polymarket_longshot_count >= 1:
            early_indicators.append(
                f"polymarket long-shots without thesis: {polymarket_longshot_count}"
            )
        if leverage_ratchet:
            early_indicators.append(
                f"leverage ratchet: {leverage_ratchet_descriptions[0]}"
            )
        # Compute partial score from non-transcript signals (parity with
        # the full-path formula minus size_dev/freq_factor/revenge).
        early_score = (
            100.0
            - consecutive_losses * 10
            - daily_loss_pct_consumed * 1.0
            - (8 if first_red_pivot else 0)
            - (12 if win_streak_size_escalation else 0)
            - sleep_debt_hours * 1.5
            - session_wallclock_hours * 0.5
            - polymarket_longshot_count * 8
            - (15 if leverage_ratchet else 0)
        )
        early_score_int = round(max(0.0, min(100.0, early_score)))
        early_level = _max_level(
            _level_from_score(early_score),
            _level_from_count(len(early_indicators)),
        )
        output({
            "level": early_level,
            "score": early_score_int,
            "session_health": early_score_int,  # deprecated alias; remove post-v0.20
            "trades_today": len(trades),
            "indicators": early_indicators,
            "note": "limited transcript context — HL/PM signals only",
        }, None)
        return

    timestamps = [dt for t in trades if (dt := _parse_ts(t['timestamp']))]
    intervals = [(timestamps[i] - timestamps[i - 1]).total_seconds()
                 for i in range(1, len(timestamps))]

    # Frequency acceleration — prefer rolling baseline when available; fall
    # back to session-relative for cold-start traders or sparse-fills cases.
    freq_factor = 0.0
    if intervals and intervals[-1] > 0:
        baseline_interval = (
            _baseline["avg_interval_seconds"]
            if _baseline and _baseline["avg_interval_seconds"] > 0
            else (sum(intervals) / len(intervals)) if len(intervals) >= 3 else 0
        )
        if baseline_interval > 0:
            freq_factor = max(0, (baseline_interval / intervals[-1]) - 1)

    sizes = []
    for t in trades:
        try:
            sizes.append(float(t['size']))
        except (ValueError, TypeError):
            pass

    # Size deviation — same baseline preference as frequency. Rolling 7d
    # baseline gives a more diagnostic comparison than session-internal avg
    # for traders who started this session with only a few trades.
    size_dev = 0.0
    if sizes:
        baseline_size = (
            _baseline["avg_size"]
            if _baseline and _baseline["avg_size"] > 0
            else (sum(sizes) / len(sizes)) if len(sizes) >= 3 else 0
        )
        if baseline_size > 0:
            size_dev = max(0, ((sizes[-1] / baseline_size) - 1) * 100)

    revenge = 0
    for i in range(1, len(trades)):
        prev, curr = trades[i - 1], trades[i]
        if (curr['asset'].upper() == prev['asset'].upper()
                and curr['side'] == prev['side']):
            t1, t2 = _parse_ts(prev['timestamp']), _parse_ts(curr['timestamp'])
            if t1 and t2 and (t2 - t1).total_seconds() < 300:
                revenge += 1

    # Score formula — design doc Section 4.3.
    # NOTE: size_dev weight FIXED to ×1.5 (was ×0.5 in v1). The original
    # design intent had size as the highest-weighted single signal; v1 code
    # contradicted that. Restoring per Tendler/Coval & Shumway evidence.
    score = (
        100.0
        - consecutive_losses * 10
        - size_dev * 1.5
        - freq_factor * 15
        - daily_loss_pct_consumed * 1.0
        - revenge * 20
        - (8 if first_red_pivot else 0)
        - (12 if win_streak_size_escalation else 0)
        - sleep_debt_hours * 1.5
        - session_wallclock_hours * 0.5
        - polymarket_longshot_count * 8
        - (15 if leverage_ratchet else 0)
    )
    score = max(0.0, min(100.0, score))

    indicators = []
    if consecutive_losses >= 3:
        indicators.append(f"loss-streak: {consecutive_losses} in a row")
    if first_red_pivot:
        indicators.append("first red of session")
    if win_streak_size_escalation:
        indicators.append("win-streak + size escalation")
    if session_wallclock_hours >= 6:
        indicators.append(f"session: {session_wallclock_hours:.1f}h continuous")
    _sleep_thresholds = _tilt_cfg.get("sleep_thresholds_hours", {})
    _sleep_yellow = float(_sleep_thresholds.get("yellow", 18) or 18)
    if sleep_debt_hours >= _sleep_yellow:
        indicators.append(f"awake: {sleep_debt_hours:.0f}h")
    if daily_loss_pct_consumed >= 50:
        indicators.append(f"daily budget: {daily_loss_pct_consumed:.0f}% consumed")
    if polymarket_longshot_count >= 1:
        indicators.append(f"polymarket long-shots without thesis: {polymarket_longshot_count}")
    if leverage_ratchet:
        # Use first asset's progression as the indicator detail; full list
        # is retrievable via the leverage_ratchet_descriptions debug field.
        indicators.append(f"leverage ratchet: {leverage_ratchet_descriptions[0]}")
    if freq_factor >= 1.0:
        indicators.append(f"frequency: {freq_factor:.1f}x faster than avg")
    if size_dev >= 50:
        indicators.append(f"size: +{size_dev:.0f}% vs avg")
    if revenge > 0:
        indicators.append(f"revenge: {revenge} re-entry(s) <5min")

    # Level = worse of score-derived and count-derived. Score-derived is
    # how badly the trader is degraded along any single dimension; count-
    # derived is how many independent signals are converging. Convergence
    # matters even if no single signal is severe.
    level = _max_level(_level_from_score(score), _level_from_count(len(indicators)))

    # BLACK escalation — hard-limit trip. Daily budget exhausted is the
    # primary Phase 1 trigger; sleep beyond the configured red-threshold
    # (default 36h) is the second. Once BLACK, the agent should refuse
    # new entries — only reduce/hedge/exit allowed (enforcement at the
    # propose layer reaches the agent through the level signal, not a
    # CLI hard block). Sentinel-dissent BLACK comes in Phase 3.
    _sleep_red = float(_sleep_thresholds.get("red", 36) or 36)
    if daily_loss_pct_consumed >= 100:
        level = "BLACK"
    elif sleep_debt_hours >= _sleep_red:
        level = "BLACK"

    score_int = round(score)
    result = {
        "level": level,
        "score": score_int,
        "session_health": score_int,  # deprecated alias; remove post-v0.20
        "trades_today": len(trades),
        "indicators": indicators,
    }
    if intervals:
        result["avg_interval_min"] = round(sum(intervals) / len(intervals) / 60, 1)
        result["last_interval_min"] = round(intervals[-1] / 60, 1)
    if sizes:
        result["avg_size"] = round(sum(sizes) / len(sizes), 4)
        result["last_size"] = round(sizes[-1], 4)

    output(result, None)


@session_app.command()
def what():
    """Session context for open-ended trading interview."""
    from regard.core.output import output

    entries = _load_session('what')
    today = _today_entries(entries)
    if not today:
        today = entries[-100:] if len(entries) > 100 else entries

    trades = _extract_trades(today)
    research = _extract_research(today)

    timeline = []
    for ts, role, text in today[-50:]:
        text_clean = text.replace('\n', ' ')
        if role == "U":
            timeline.append({"timestamp": ts, "role": "user", "text": text_clean[:500]})
        elif role == "A":
            timeline.append({"timestamp": ts, "role": "assistant", "text": text_clean[:500]})
        elif role == "T" and ('regard hl ' in text or
              any(s in text for s in RESEARCH_SKILLS) or
              text.startswith(("WebSearch:", "WebFetch:", "Skill:"))):
            timeline.append({"timestamp": ts, "role": "tool", "text": text_clean[:200]})

    result = {
        "total_entries": len(today),
        "trade_count": len(trades),
        "research_count": len(research),
        "timeline": timeline,
    }
    output(result, None)


@session_app.command()
def ctx():
    """Context estimate — rough session weight from transcript data."""
    from regard.core.output import die
    base_path = _get_session_base_path()
    if not base_path:
        die("validation_error", "NO_SESSION_DIR", "No session directory found for CWD",
            hint="Run from the regard-computer workspace directory", exit_code=2)

    session_files = _find_session_files(base_path)
    if not session_files:
        die("validation_error", "NO_SESSION_FILES", "No session files found",
            hint="Start a session first — session transcripts accumulate automatically", exit_code=2)

    # Read the current (most recent) session file raw
    current = session_files[0]

    total_chars = 0

    try:
        with open(current, encoding='utf-8', errors='ignore') as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    e = json.loads(line)
                    t = e.get("type")

                    if t == "user":
                        c = e.get("message", {}).get("content", "")
                        if isinstance(c, str):
                            total_chars += len(c)
                        elif isinstance(c, list):
                            for item in c:
                                if item.get("type") == "text":
                                    total_chars += len(item.get("text", ""))
                                elif item.get("type") == "tool_result":
                                    content = item.get("content", "")
                                    if isinstance(content, str):
                                        total_chars += len(content)
                                    elif isinstance(content, list):
                                        for b in content:
                                            if isinstance(b, dict):
                                                total_chars += len(b.get("text", ""))

                    elif t == "assistant":
                        for b in e.get("message", {}).get("content", []) or []:
                            if b.get("type") == "text":
                                total_chars += len(b.get("text", ""))
                            elif b.get("type") == "tool_use":
                                total_chars += len(json.dumps(b.get("input", {})))
                            elif b.get("type") == "thinking":
                                total_chars += len(b.get("thinking", ""))

                except (json.JSONDecodeError, KeyError):
                    pass
    except OSError:
        pass

    from regard.core.output import output
    output({"estimated_tokens": total_chars // 4}, None)
