"""Asset name resolution — maps short tickers to full coin names.

Also owns lazy-loading of HIP-3 dex metadata and HIP-4 outcomeMeta into the
underlying SDK's `coin_to_asset` / `name_to_coin` maps. The official
hyperliquid-python-sdk has zero HIP-4 awareness; the resolver patches it at
runtime so existing commands (`book`, `order`, etc.) work against
`#<encoding>` outcome coins without changes.
"""

from typing import Any

from hyperliquid.info import Info

from regard.core.output import die
from regard.venues.hyperliquid.outcomes import (
    encode_asset_id,
    encode_balance_coin,
    encode_coin,
    parse_description,
)


class Resolver:
    """Resolves user-typed asset names to SDK coin names.

    - Exact match on known coin (e.g. "BTC", "xyz:TSLA", "#59150") -> use it
    - Case-insensitive match on default perps -> use it
    - Short HIP-3 ticker (e.g. "TSLA") -> resolve, error if ambiguous
    - Lazy-loads HIP-3 dex metadata on first miss against default perps
    - Lazy-loads HIP-4 outcomeMeta when an unknown name might be `#<encoding>`
      or when `get_outcomes()` is called directly
    """

    def __init__(self, info: Info):
        self.info = info
        self._dexes_loaded = False
        self._outcomes_loaded = False
        self._short_map: dict[str, list[str]] = {}  # UPPER ticker -> [full names]
        # Structured outcome data, populated by _load_outcomes(). Each entry:
        # {outcome (int), name (str), description (str), parsed_description (dict),
        #  sides: [{side (int), name (str), coin (str), balance_coin (str),
        #           asset_id (int)}, ...]}
        self._outcomes: list[dict[str, Any]] = []
        # Reverse lookup: outcome integer → entry in self._outcomes (cached so
        # CLI commands and tests can resolve bare `<outcome>` arguments in O(1)).
        self._outcomes_by_id: dict[int, dict[str, Any]] = {}
        self._build_default_map()

    def _build_default_map(self):
        """Index default perps by uppercase name. Skip `#`-prefixed outcome
        coins — those are HIP-4 and live in their own resolution path; folding
        them into the short-map would clutter ambiguity errors."""
        for name in self.info.coin_to_asset:
            if ":" not in name and not name.startswith("#"):
                key = name.upper()
                self._short_map.setdefault(key, []).append(name)

    def _load_dexes(self):
        """Lazily load all HIP-3 deployer metadata into the Info client."""
        if self._dexes_loaded:
            return
        self._dexes_loaded = True

        try:
            dex_list = self.info.post("/info", {"type": "perpDexs"})
        except Exception:
            return  # can't load dexes, resolve will fail with unknown_asset

        for idx, dex_info in enumerate(dex_list[1:]):  # skip default dex
            dex_name = dex_info["name"]
            try:
                dex_meta = self.info.meta(dex=dex_name)
                offset = 110000 + idx * 10000
                self.info.set_perp_meta(dex_meta, offset)

                # Index by short ticker for disambiguation
                for asset_info in dex_meta["universe"]:
                    full_name = asset_info["name"]
                    # The API may or may not prefix with dex name
                    if ":" in full_name:
                        _, ticker = full_name.split(":", 1)
                    else:
                        ticker = full_name
                    key = ticker.upper()
                    self._short_map.setdefault(key, []).append(full_name)
            except Exception:
                continue

    def _load_outcomes(self):
        """Lazily load HIP-4 outcomeMeta into the Info client.

        Mirrors `_load_dexes()`: sets the loaded flag BEFORE the network call so
        a transient failure doesn't trigger a retry storm. The official SDK has
        zero HIP-4 awareness (per the implementation brief §9), so we inject
        `#<encoding>` entries directly into `info.coin_to_asset` and
        `info.name_to_coin` — once injected, downstream SDK helpers (e.g.
        `info.l2_snapshot(coin="#59150")`) work transparently.
        """
        if self._outcomes_loaded:
            return
        self._outcomes_loaded = True

        # Import lazily to avoid circulars (models imports outcomes for shared
        # constants in future, but right now this is just import hygiene).
        from regard.venues.hyperliquid.models import OutcomeMeta

        try:
            raw = self.info.post("/info", {"type": "outcomeMeta"})
        except Exception:
            return  # silent — outcomes just won't resolve, same as missing dexes

        try:
            meta = OutcomeMeta.model_validate(raw)
        except Exception:
            return  # malformed response: degrade gracefully, don't propagate

        for entry in meta.outcomes:
            sides_data = []
            for side_idx, side_spec in enumerate(entry.sideSpecs):
                if side_idx not in (0, 1):
                    # Categorical markets (>2 sides) — skip extra sides for
                    # now; binary trading commands are scoped to 0/1 only.
                    # Phase 4 (categoricals) revisits this.
                    continue
                coin = encode_coin(entry.outcome, side_idx)
                balance_coin = encode_balance_coin(entry.outcome, side_idx)
                asset_id = encode_asset_id(entry.outcome, side_idx)
                # Inject into the SDK's resolver maps so existing commands
                # (book, order, etc.) accept #<encoding> coins natively.
                self.info.coin_to_asset[coin] = asset_id
                self.info.name_to_coin[coin] = coin
                sides_data.append({
                    "side": side_idx,
                    "name": side_spec.name,
                    "coin": coin,
                    "balance_coin": balance_coin,
                    "asset_id": asset_id,
                })
            outcome_record = {
                "outcome": entry.outcome,
                "name": entry.name,
                "description": entry.description,
                "parsed_description": parse_description(entry.description),
                "sides": sides_data,
            }
            self._outcomes.append(outcome_record)
            self._outcomes_by_id[entry.outcome] = outcome_record

    def get_outcomes(self) -> list[dict[str, Any]]:
        """Return all known outcomes as structured dicts (lazy-loads on first call).

        Used by `regard hl outcomes` and `regard hl outcome <id>`. Each entry
        has shape:
            {
              outcome: int,
              name: str,
              description: str,                 # raw, unparsed
              parsed_description: dict,         # {class, underlying, expiry, ...}
              sides: [{side, name, coin, balance_coin, asset_id}, ...]
            }
        """
        if not self._outcomes_loaded:
            self._load_outcomes()
        return list(self._outcomes)

    def get_outcome_by_id(self, outcome: int) -> dict[str, Any] | None:
        """Return a single outcome record by its integer id, or None if not found."""
        if not self._outcomes_loaded:
            self._load_outcomes()
        return self._outcomes_by_id.get(outcome)

    def _find_exact(self, name: str) -> str | None:
        """Case-insensitive exact match against all known coins."""
        if name in self.info.coin_to_asset:
            return name
        upper = name.upper()
        for known in self.info.coin_to_asset:
            if known.upper() == upper:
                return known
        return None

    def resolve(self, name: str) -> str:
        """Resolve a user-typed asset name to the SDK coin name.

        Returns the canonical coin name or calls die() on error.
        """
        # Exact match (already known to SDK)
        exact = self._find_exact(name)
        if exact:
            return exact

        # Short-name match against indexed tickers
        key = name.upper()
        matches = self._short_map.get(key)

        if matches is None and not self._dexes_loaded:
            # Try loading HIP-3 dexes
            self._load_dexes()
            # Re-check exact match (full names now loaded)
            exact = self._find_exact(name)
            if exact:
                return exact
            matches = self._short_map.get(key)

        # `#<encoding>` outcome coins won't appear in the dex maps. If the name
        # looks like an outcome coin and outcomes haven't been loaded yet, try
        # one more round after pulling outcomeMeta. Skip lazy-load for names
        # that obviously aren't outcomes — saves a network call per typo.
        if matches is None and not self._outcomes_loaded and name.startswith("#"):
            self._load_outcomes()
            exact = self._find_exact(name)
            if exact:
                return exact

        if not matches:
            # `#<enc>` names that we still can't resolve after a fresh
            # outcomeMeta load are presumed to be expired/settled outcome
            # markets (the validators auto-deploy fresh ones, so the coin
            # may be valid in some other window but not "now"). Surface a
            # distinct error code so agents using `book` / future `order`
            # can pattern-match expired-outcome separately from a perp
            # typo. Article IV: structured error codes are the agent contract.
            if name.startswith("#"):
                die(
                    "validation_error", "UNKNOWN_OUTCOME",
                    f"Unknown outcome coin: {name}",
                    hint="Run `regard hl outcomes` to see live HIP-4 markets — this coin may have settled and been removed from outcomeMeta",
                )
            die(
                "validation_error", "UNKNOWN_ASSET",
                f"Unknown asset: {name}",
                hint="Use 'regard hl assets' to list available assets, 'regard hl outcomes' for HIP-4 markets, or specify full name like 'xyz:TSLA' / '#59150'",
            )

        if len(matches) == 1:
            return matches[0]

        # Multiple matches — prefer default perp (no colon) over HIP-3
        defaults = [m for m in matches if ":" not in m]
        if len(defaults) == 1:
            return defaults[0]

        # Ambiguous — build match info for the error
        mids = {}
        try:
            mids = self.info.all_mids()
            # Also fetch HIP-3 mids for the deployers involved
            dex_list = self.info.post("/info", {"type": "perpDexs"})
            deployers = {m.split(":")[0] for m in matches if ":" in m}
            for dex_info in dex_list[1:]:
                if dex_info["name"] in deployers:
                    dex_mids = self.info.post("/info", {"type": "allMids", "dex": dex_info["name"]})
                    mids.update(dex_mids)
        except Exception:
            pass

        match_info = []
        for m in matches:
            deployer = m.split(":")[0] if ":" in m else ""
            match_info.append({"asset": m, "deployer": deployer, "mid": mids.get(m, "")})

        die(
            "validation_error", "AMBIGUOUS_ASSET",
            f"{name} matches multiple markets",
            hint=f"Use full name: regard hl <command> {matches[0]} ...",
            extra={"matches": match_info},
        )


# Module-level singleton per Info instance
_resolvers: dict[int, Resolver] = {}


def get_resolver(info: Info) -> Resolver:
    """Get or create a Resolver for the given Info client."""
    key = id(info)
    if key not in _resolvers:
        _resolvers[key] = Resolver(info)
    return _resolvers[key]
