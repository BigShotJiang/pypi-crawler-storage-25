"""Tests for the Gemini VLM backend.

Mirrors the Anthropic test layout: we install a fake `google.genai` package
into `sys.modules` before each test so the suite passes on machines that
haven't installed the optional [gemini] extra.
"""

from __future__ import annotations

import importlib
import json
import sys
import types
from unittest.mock import MagicMock

import pytest
from PIL import Image
from pydantic import BaseModel


class _Verdict(BaseModel):
    interesting: bool
    label: str
    confidence: float


def _install_fake_genai_sdk(
    *,
    parsed=None,
    text: str | None = None,
    raise_on_create: Exception | None = None,
    raise_then_text: tuple[Exception, str] | None = None,
) -> tuple[MagicMock, MagicMock]:
    """Build and register a fake `google.genai` SDK.

    Returns (client_ctor, models_mock) so tests can assert on the
    `Client(...)` call AND the `models.generate_content` payload.
    """
    response = MagicMock()
    response.parsed = parsed
    response.text = text or json.dumps(
        {"interesting": True, "label": "person", "confidence": 0.81}
    )

    models = MagicMock()
    if raise_on_create is not None:
        models.generate_content.side_effect = raise_on_create
    elif raise_then_text is not None:
        first_err, fallback_text = raise_then_text
        fallback_response = MagicMock()
        fallback_response.parsed = None
        fallback_response.text = fallback_text
        models.generate_content.side_effect = [first_err, fallback_response]
    else:
        models.generate_content.return_value = response

    client = MagicMock()
    client.models = models
    client_ctor = MagicMock(return_value=client)

    # Build the package shape: `google.genai`, `google.genai.types`.
    google_pkg = sys.modules.get("google")
    if not isinstance(google_pkg, types.ModuleType):
        google_pkg = types.ModuleType("google")
        google_pkg.__path__ = []  # type: ignore[attr-defined] — mark as a package
        sys.modules["google"] = google_pkg

    genai_module = types.ModuleType("google.genai")
    genai_module.Client = client_ctor  # type: ignore[attr-defined]
    sys.modules["google.genai"] = genai_module
    google_pkg.genai = genai_module  # type: ignore[attr-defined]

    types_module = types.ModuleType("google.genai.types")

    class _FakePart:
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)

        @classmethod
        def from_text(cls, *, text):
            return cls(kind="text", text=text)

        @classmethod
        def from_bytes(cls, *, data, mime_type):
            return cls(kind="image", data=data, mime_type=mime_type)

    class _FakeConfig:
        def __init__(self, **kwargs):
            self.kwargs = kwargs
            for k, v in kwargs.items():
                setattr(self, k, v)

    types_module.Part = _FakePart  # type: ignore[attr-defined]
    types_module.GenerateContentConfig = _FakeConfig  # type: ignore[attr-defined]
    sys.modules["google.genai.types"] = types_module
    genai_module.types = types_module  # type: ignore[attr-defined]

    return client_ctor, models


def _reload_backend():
    sys.modules.pop("tesla_clip_tools.vlm.gemini", None)
    return importlib.import_module("tesla_clip_tools.vlm.gemini")


def _img(color=(40, 80, 160)) -> Image.Image:
    return Image.new("RGB", (8, 8), color)


# ---------------------------------------------------------------------------
# 1. Class instantiation respects model arg.
# ---------------------------------------------------------------------------


def test_instantiation_passes_model_and_uses_env_api_key(monkeypatch):
    monkeypatch.setenv("GOOGLE_API_KEY", "google-key-from-env")
    ctor, _ = _install_fake_genai_sdk()
    backend_mod = _reload_backend()

    backend = backend_mod.GeminiBackend(model="gemini-2.0-flash")

    ctor.assert_called_once_with(api_key="google-key-from-env")
    assert backend.model == "gemini-2.0-flash"


# ---------------------------------------------------------------------------
# 2. classify() emits one image part per input.
# ---------------------------------------------------------------------------


def test_classify_sends_one_image_part_per_input(monkeypatch):
    monkeypatch.setenv("GOOGLE_API_KEY", "k")
    parsed = _Verdict(interesting=True, label="person", confidence=0.91)
    _, models = _install_fake_genai_sdk(parsed=parsed)
    backend_mod = _reload_backend()

    backend = backend_mod.GeminiBackend()
    backend.classify(
        images=[_img(), _img((10, 10, 10))],
        captions=["[front t=0]", "[back t=1]"],
        system_prompt="be concise",
        response_format=_Verdict,
    )

    assert models.generate_content.call_count == 1
    kwargs = models.generate_content.call_args.kwargs
    parts = kwargs["contents"]
    image_parts = [p for p in parts if getattr(p, "kind", None) == "image"]
    text_parts = [p for p in parts if getattr(p, "kind", None) == "text"]
    assert len(image_parts) == 2
    # 1 leading "Classify this event." + 2 captions = 3 text parts.
    assert len(text_parts) == 3
    assert text_parts[0].text == "Classify this event."
    for part in image_parts:
        assert part.mime_type == "image/jpeg"
        assert isinstance(part.data, (bytes, bytearray)) and part.data
    # System instruction + structured-output config wired through GenerateContentConfig.
    config = kwargs["config"]
    assert config.system_instruction == "be concise"
    assert config.response_mime_type == "application/json"
    assert config.response_schema is _Verdict


def test_classify_rejects_mismatched_images_and_captions(monkeypatch):
    monkeypatch.setenv("GOOGLE_API_KEY", "k")
    _install_fake_genai_sdk()
    backend_mod = _reload_backend()

    backend = backend_mod.GeminiBackend()
    with pytest.raises(ValueError, match="must align"):
        backend.classify(
            images=[_img()],
            captions=["a", "b"],
            system_prompt="x",
            response_format=_Verdict,
        )


# ---------------------------------------------------------------------------
# 3. Returns a parsed instance of the Pydantic response_format.
# ---------------------------------------------------------------------------


def test_classify_returns_parsed_instance_when_sdk_supplies_it(monkeypatch):
    monkeypatch.setenv("GOOGLE_API_KEY", "k")
    parsed = _Verdict(interesting=True, label="dog", confidence=0.55)
    _install_fake_genai_sdk(parsed=parsed)
    backend_mod = _reload_backend()

    backend = backend_mod.GeminiBackend()
    out = backend.classify(
        images=[_img()],
        captions=["c"],
        system_prompt="s",
        response_format=_Verdict,
    )

    assert out is parsed  # same object: SDK did the parsing
    assert isinstance(out, _Verdict)


def test_classify_falls_back_to_text_json_when_parsed_missing(monkeypatch):
    monkeypatch.setenv("GOOGLE_API_KEY", "k")
    _install_fake_genai_sdk(
        parsed=None,
        text=json.dumps({"interesting": False, "label": "leaf", "confidence": 0.4}),
    )
    backend_mod = _reload_backend()

    backend = backend_mod.GeminiBackend()
    out = backend.classify(
        images=[_img()],
        captions=["c"],
        system_prompt="s",
        response_format=_Verdict,
    )

    assert isinstance(out, _Verdict)
    assert out.interesting is False
    assert out.label == "leaf"


# ---------------------------------------------------------------------------
# 4. Raises a clean error on malformed JSON.
# ---------------------------------------------------------------------------


def test_classify_raises_clean_error_on_malformed_json(monkeypatch):
    monkeypatch.setenv("GOOGLE_API_KEY", "k")
    _install_fake_genai_sdk(parsed=None, text="not even json {[}")
    backend_mod = _reload_backend()

    backend = backend_mod.GeminiBackend()
    with pytest.raises(RuntimeError, match="non-JSON"):
        backend.classify(
            images=[_img()],
            captions=["c"],
            system_prompt="s",
            response_format=_Verdict,
        )


def test_classify_raises_clean_error_on_schema_violation(monkeypatch):
    monkeypatch.setenv("GOOGLE_API_KEY", "k")
    # Valid JSON but missing required fields → Pydantic ValidationError → clean RuntimeError.
    _install_fake_genai_sdk(parsed=None, text=json.dumps({"interesting": True}))
    backend_mod = _reload_backend()

    backend = backend_mod.GeminiBackend()
    with pytest.raises(RuntimeError, match="schema validation"):
        backend.classify(
            images=[_img()],
            captions=["c"],
            system_prompt="s",
            response_format=_Verdict,
        )


def test_classify_falls_back_to_v20_when_v25_rejected(monkeypatch):
    """If gemini-2.5-flash isn't recognised, retry once on gemini-2.0-flash."""
    monkeypatch.setenv("GOOGLE_API_KEY", "k")
    err = RuntimeError("model not found: gemini-2.5-flash")
    _, models = _install_fake_genai_sdk(
        raise_then_text=(err, json.dumps(
            {"interesting": True, "label": "person", "confidence": 0.7}
        )),
    )
    backend_mod = _reload_backend()

    backend = backend_mod.GeminiBackend()  # default = gemini-2.5-flash
    out = backend.classify(
        images=[_img()],
        captions=["c"],
        system_prompt="s",
        response_format=_Verdict,
    )

    assert isinstance(out, _Verdict)
    assert models.generate_content.call_count == 2
    # Second attempt used the fallback model name.
    second_kwargs = models.generate_content.call_args_list[1].kwargs
    assert second_kwargs["model"] == "gemini-2.0-flash"


# ---------------------------------------------------------------------------
# 5. Lazy import: module imports cleanly without the SDK installed.
# ---------------------------------------------------------------------------


def test_module_imports_without_sdk_installed():
    """Drop the fake SDK and re-import the backend — it must NOT crash."""
    # Remove anything that looks like the google-genai SDK from sys.modules.
    for key in list(sys.modules):
        if key == "google" or key.startswith("google."):
            del sys.modules[key]
    sys.modules.pop("tesla_clip_tools.vlm.gemini", None)

    backend_mod = importlib.import_module("tesla_clip_tools.vlm.gemini")
    assert hasattr(backend_mod, "GeminiBackend")

    # Construction should fail with a clean ImportError pointing at the extra.
    with pytest.raises(ImportError, match=r"\[gemini\]"):
        backend_mod.GeminiBackend()
