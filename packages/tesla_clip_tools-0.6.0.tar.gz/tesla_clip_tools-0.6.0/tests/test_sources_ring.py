"""Tests for the Ring exported-clip reader."""

from __future__ import annotations

from datetime import datetime
from pathlib import Path

import pytest

from tesla_clip_tools.sources.ring import RingSource


@pytest.fixture()
def fake_ring_root(tmp_path: Path) -> Path:
    """Mix of all 3 supported filename shapes plus garbage."""
    root = tmp_path / "ring-export"
    root.mkdir()
    # Pattern 1: Neighbors export with event type
    (root / "Front_Door_motion_2026-05-08T14-22-31.mp4").write_bytes(b"fake")
    # Pattern 1: with trailing Z
    (root / "Front_Door_ding_2026-05-08T14-30-00Z.mp4").write_bytes(b"fake")
    # Pattern 2: web UI download
    (root / "Backyard_2026-05-08-15-00-00.mp4").write_bytes(b"fake")
    # Pattern 3: T-separator without event type
    (root / "Driveway_2026-05-08T16-30-15.mp4").write_bytes(b"fake")
    # Date subdir with one valid file
    (root / "2026-05-09").mkdir()
    (root / "2026-05-09" / "Garage_motion_2026-05-09T08-00-00.mp4").write_bytes(b"fake")
    # Garbage
    (root / "random.mp4").write_bytes(b"fake")
    (root / "notes.txt").write_bytes(b"fake")
    (root / "Cam_motion_2026-13-32T99-99-99.mp4").write_bytes(b"fake")  # invalid date
    return root


def test_discover_finds_all_valid_files(fake_ring_root: Path) -> None:
    events = RingSource(fake_ring_root).discover()
    assert len(events) == 5


def test_events_sorted_by_timestamp(fake_ring_root: Path) -> None:
    events = RingSource(fake_ring_root).discover()
    assert [e.timestamp for e in events] == [
        datetime(2026, 5, 8, 14, 22, 31),
        datetime(2026, 5, 8, 14, 30, 0),
        datetime(2026, 5, 8, 15, 0, 0),
        datetime(2026, 5, 8, 16, 30, 15),
        datetime(2026, 5, 9, 8, 0, 0),
    ]


def test_event_id_uses_ring_prefix(fake_ring_root: Path) -> None:
    events = RingSource(fake_ring_root).discover()
    assert events[0].id == "ring:Front_Door:20260508-142231"


def test_neighbors_export_captures_event_type(fake_ring_root: Path) -> None:
    events = RingSource(fake_ring_root).discover()
    by_cam_event = {(next(iter(e.cams)), e.metadata.get("event_type")) for e in events}
    assert ("Front_Door", "motion") in by_cam_event
    assert ("Front_Door", "ding") in by_cam_event
    assert ("Garage", "motion") in by_cam_event


def test_web_export_omits_event_type(fake_ring_root: Path) -> None:
    events = RingSource(fake_ring_root).discover()
    backyard = next(e for e in events if next(iter(e.cams)) == "Backyard")
    assert "event_type" not in backyard.metadata


def test_invalid_date_filename_ignored(fake_ring_root: Path) -> None:
    events = RingSource(fake_ring_root).discover()
    assert all("2026-13-32" not in e.metadata["filename"] for e in events)


def test_subdir_files_included(fake_ring_root: Path) -> None:
    events = RingSource(fake_ring_root).discover()
    paths = [str(next(iter(e.cams.values()))) for e in events]
    assert any("2026-05-09" in p.replace("\\", "/") for p in paths)


def test_scan_for_new_filters_by_timestamp(fake_ring_root: Path) -> None:
    events = RingSource(fake_ring_root).scan_for_new(
        after=datetime(2026, 5, 8, 15, 30)
    )
    assert [e.timestamp for e in events] == [
        datetime(2026, 5, 8, 16, 30, 15),
        datetime(2026, 5, 9, 8, 0, 0),
    ]


def test_missing_root_returns_empty(tmp_path: Path) -> None:
    assert RingSource(tmp_path / "no-such-dir").discover() == []
