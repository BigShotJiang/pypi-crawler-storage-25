"""Tests for the Google Nest exported-clip reader."""

from __future__ import annotations

from datetime import datetime
from pathlib import Path

import pytest

from tesla_clip_tools.sources.nest import NestSource


@pytest.fixture()
def fake_nest_root(tmp_path: Path) -> Path:
    """Mix unix-millis + dashed-date shapes + garbage."""
    root = tmp_path / "nest-export"
    root.mkdir()
    # Pattern 1: unix-millis format (1747749600000 = 2025-05-20 14:00:00 UTC)
    (root / "FrontDoor_1762610551000_person.mp4").write_bytes(b"fake")  # 2025-11-08 ~12:42 UTC
    (root / "Backyard_1762610551000.mp4").write_bytes(b"fake")          # same time, no event
    # Pattern 2: dashed-date format
    (root / "Garage_2026-05-08_14-22-31_doorbell.mp4").write_bytes(b"fake")
    (root / "Driveway_2026-05-08_15-00-00.mp4").write_bytes(b"fake")
    # Garbage
    (root / "random.mp4").write_bytes(b"fake")
    (root / "Cam_2026-13-32_99-99-99.mp4").write_bytes(b"fake")  # invalid date
    (root / "Cam_short.mp4").write_bytes(b"fake")  # too short for either pattern
    return root


def test_discover_finds_all_valid_files(fake_nest_root: Path) -> None:
    events = NestSource(fake_nest_root).discover()
    assert len(events) == 4


def test_unix_millis_parsed_to_utc(fake_nest_root: Path) -> None:
    events = NestSource(fake_nest_root).discover()
    millis_event = next(
        e for e in events if next(iter(e.cams)) == "FrontDoor"
    )
    # 1762610551000 ms = 2025-11-08 12:42:31 UTC. Stored as naive UTC for
    # consistency with the other sources (which return naive datetimes).
    assert millis_event.timestamp.tzinfo is None
    assert millis_event.timestamp.year == 2025
    assert millis_event.timestamp.month == 11


def test_event_type_captured_when_present(fake_nest_root: Path) -> None:
    events = NestSource(fake_nest_root).discover()
    by_cam = {next(iter(e.cams)): e for e in events}
    assert by_cam["FrontDoor"].metadata.get("event_type") == "person"
    assert by_cam["Garage"].metadata.get("event_type") == "doorbell"
    # Backyard + Driveway have no event_type
    assert "event_type" not in by_cam["Backyard"].metadata
    assert "event_type" not in by_cam["Driveway"].metadata


def test_event_id_uses_nest_prefix(fake_nest_root: Path) -> None:
    events = NestSource(fake_nest_root).discover()
    ids = {e.id for e in events}
    assert any(i.startswith("nest:Garage:20260508-142231") for i in ids)
    assert any(i.startswith("nest:FrontDoor:") for i in ids)


def test_invalid_date_filename_ignored(fake_nest_root: Path) -> None:
    events = NestSource(fake_nest_root).discover()
    assert all("2026-13-32" not in e.metadata["filename"] for e in events)


def test_random_filename_ignored(fake_nest_root: Path) -> None:
    events = NestSource(fake_nest_root).discover()
    assert all("random.mp4" not in e.metadata["filename"] for e in events)


def test_scan_for_new_filters_by_timestamp(fake_nest_root: Path) -> None:
    events = NestSource(fake_nest_root).scan_for_new(
        after=datetime(2026, 5, 8, 14, 30)
    )
    # Garage was at 14:22 -- before cutoff. Driveway was at 15:00 -- after.
    # FrontDoor + Backyard (Nov 2025) -- before cutoff in 2026-05.
    assert [next(iter(e.cams)) for e in events] == ["Driveway"]


def test_missing_root_returns_empty(tmp_path: Path) -> None:
    assert NestSource(tmp_path / "no-such-dir").discover() == []
