"""Tests for the Discord webhook notifier.

All network calls are mocked — no httpx requests escape the test process.
"""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import httpx
import pytest

from tesla_clip_tools.notify.base import NotifyError
from tesla_clip_tools.notify.discord import DiscordNotifier

_FAKE_WEBHOOK = "https://discord.com/api/webhooks/123456789/fake-token-abcdef"


def _ok_response() -> MagicMock:
    r = MagicMock()
    r.raise_for_status.return_value = None
    return r


def test_init_reads_webhook_url_from_env(monkeypatch):
    monkeypatch.setenv("DISCORD_WEBHOOK_URL", _FAKE_WEBHOOK)
    n = DiscordNotifier()
    assert n.webhook_url == _FAKE_WEBHOOK


def test_init_constructor_arg_overrides_env(monkeypatch):
    monkeypatch.setenv("DISCORD_WEBHOOK_URL", "env-url")
    n = DiscordNotifier(webhook_url="ctor-url")
    assert n.webhook_url == "ctor-url"


def test_init_missing_env_raises_clean_error(monkeypatch):
    """No KeyError, no AttributeError — a NotifyError with usable instructions."""
    monkeypatch.delenv("DISCORD_WEBHOOK_URL", raising=False)
    with pytest.raises(NotifyError, match="DISCORD_WEBHOOK_URL"):
        DiscordNotifier()


def test_send_text_only_posts_json_payload(monkeypatch):
    monkeypatch.setenv("DISCORD_WEBHOOK_URL", _FAKE_WEBHOOK)
    n = DiscordNotifier()
    with patch(
        "tesla_clip_tools.notify.discord.httpx.post",
        return_value=_ok_response(),
    ) as mock_post:
        n.send("Sentry: vandal", "someone keyed the front quarter panel")

    assert mock_post.call_count == 1
    args, kwargs = mock_post.call_args
    assert args[0] == _FAKE_WEBHOOK
    payload = kwargs["json"]
    assert payload["content"] == "Sentry: vandal"
    assert payload["embeds"][0]["description"] == "someone keyed the front quarter panel"
    # No `files` should sneak into a text-only send.
    assert "files" not in kwargs


def test_send_with_attachment_uses_multipart(monkeypatch, tmp_path: Path):
    monkeypatch.setenv("DISCORD_WEBHOOK_URL", _FAKE_WEBHOOK)
    img = tmp_path / "front.jpg"
    img.write_bytes(b"\xff\xd8\xff\xe0fake-jpeg")

    n = DiscordNotifier()
    with patch(
        "tesla_clip_tools.notify.discord.httpx.post",
        return_value=_ok_response(),
    ) as mock_post:
        n.send("Sentry: person", "stranger near the driver door", attachment=img)

    args, kwargs = mock_post.call_args
    assert args[0] == _FAKE_WEBHOOK
    # Multipart: payload_json carries the JSON, files[0] carries the binary.
    assert "files" in kwargs and "data" in kwargs
    assert "files[0]" in kwargs["files"]
    file_tuple = kwargs["files"]["files[0]"]
    assert file_tuple[0] == "front.jpg"
    assert file_tuple[2] == "image/jpeg"
    payload = json.loads(kwargs["data"]["payload_json"])
    assert payload["content"] == "Sentry: person"
    assert payload["embeds"][0]["description"] == "stranger near the driver door"


def test_send_with_video_attachment_sets_video_mime(monkeypatch, tmp_path: Path):
    monkeypatch.setenv("DISCORD_WEBHOOK_URL", _FAKE_WEBHOOK)
    clip = tmp_path / "front.mp4"
    clip.write_bytes(b"\x00\x00\x00\x18ftypmp42")

    n = DiscordNotifier()
    with patch(
        "tesla_clip_tools.notify.discord.httpx.post",
        return_value=_ok_response(),
    ) as mock_post:
        n.send("Sentry: hit", "tap on the rear bumper", attachment=clip)

    file_tuple = mock_post.call_args.kwargs["files"]["files[0]"]
    assert file_tuple[0] == "front.mp4"
    assert file_tuple[2] == "video/mp4"


def test_send_network_error_wrapped_as_notifyerror(monkeypatch):
    monkeypatch.setenv("DISCORD_WEBHOOK_URL", _FAKE_WEBHOOK)
    n = DiscordNotifier()
    with patch(
        "tesla_clip_tools.notify.discord.httpx.post",
        side_effect=httpx.ConnectError("dns failed"),
    ), pytest.raises(NotifyError, match="Discord webhook POST failed"):
        n.send("title", "body")


def test_send_4xx_raised_as_notifyerror(monkeypatch):
    monkeypatch.setenv("DISCORD_WEBHOOK_URL", _FAKE_WEBHOOK)
    n = DiscordNotifier()
    bad = MagicMock()
    bad.raise_for_status.side_effect = httpx.HTTPStatusError(
        "bad webhook", request=MagicMock(), response=MagicMock(status_code=401)
    )
    with patch(
        "tesla_clip_tools.notify.discord.httpx.post", return_value=bad
    ), pytest.raises(NotifyError, match="Discord webhook POST failed"):
        n.send("t", "b")


def test_send_truncates_overlong_body(monkeypatch):
    """Discord caps embed description at 4096 chars — backend must trim, not 400."""
    monkeypatch.setenv("DISCORD_WEBHOOK_URL", _FAKE_WEBHOOK)
    n = DiscordNotifier()
    huge = "x" * 5000
    with patch(
        "tesla_clip_tools.notify.discord.httpx.post",
        return_value=_ok_response(),
    ) as mock_post:
        n.send("title", huge)

    desc = mock_post.call_args.kwargs["json"]["embeds"][0]["description"]
    assert len(desc) <= 4096
    assert desc.endswith("(truncated)")


def test_attachment_path_missing_falls_back_to_text(monkeypatch, tmp_path: Path):
    """A path that points at nothing should still send the text — not crash."""
    monkeypatch.setenv("DISCORD_WEBHOOK_URL", _FAKE_WEBHOOK)
    n = DiscordNotifier()
    nonexistent = tmp_path / "does-not-exist.jpg"
    with patch(
        "tesla_clip_tools.notify.discord.httpx.post",
        return_value=_ok_response(),
    ) as mock_post:
        n.send("title", "body", attachment=nonexistent)

    # Falls through to text-only JSON post.
    assert "json" in mock_post.call_args.kwargs
    assert "files" not in mock_post.call_args.kwargs
