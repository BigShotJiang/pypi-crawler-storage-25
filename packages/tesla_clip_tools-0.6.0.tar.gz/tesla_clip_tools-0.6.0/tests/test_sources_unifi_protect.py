"""Tests for the UniFi Protect exported-clip reader."""

from __future__ import annotations

from datetime import datetime
from pathlib import Path

import pytest

from tesla_clip_tools.sources.unifi_protect import UniFiProtectSource


@pytest.fixture()
def fake_unifi_root(tmp_path: Path) -> Path:
    """Mix flat-root files with date-partitioned subdir files plus garbage."""
    root = tmp_path / "unifi-export"
    root.mkdir()
    # Flat: with event type
    (root / "FrontDoor_2026-05-08_14-22-31_motion.mp4").write_bytes(b"fake")
    # Flat: without event type
    (root / "Backyard_2026-05-08_15-00-00.mp4").write_bytes(b"fake")
    # Date subdir: with event type
    (root / "2026-05-08").mkdir()
    (root / "2026-05-08" / "Garage_2026-05-08_16-30-15_smartdetect.mp4").write_bytes(b"fake")
    # Date subdir: garbage filename
    (root / "2026-05-08" / "random.mp4").write_bytes(b"fake")
    # Top-level garbage
    (root / "notes.txt").write_bytes(b"fake")
    # Invalid date
    (root / "Cam_2026-99-99_25-61-61_x.mp4").write_bytes(b"fake")
    return root


def test_discover_finds_all_valid_files(fake_unifi_root: Path) -> None:
    events = UniFiProtectSource(fake_unifi_root).discover()
    assert len(events) == 3


def test_events_sorted_by_timestamp(fake_unifi_root: Path) -> None:
    events = UniFiProtectSource(fake_unifi_root).discover()
    assert [e.timestamp for e in events] == [
        datetime(2026, 5, 8, 14, 22, 31),
        datetime(2026, 5, 8, 15, 0, 0),
        datetime(2026, 5, 8, 16, 30, 15),
    ]


def test_event_id_uses_unifi_prefix(fake_unifi_root: Path) -> None:
    events = UniFiProtectSource(fake_unifi_root).discover()
    assert events[0].id == "unifi:FrontDoor:20260508-142231"


def test_event_type_captured_when_present(fake_unifi_root: Path) -> None:
    events = UniFiProtectSource(fake_unifi_root).discover()
    by_cam = {next(iter(e.cams)): e for e in events}
    assert by_cam["FrontDoor"].metadata.get("event_type") == "motion"
    assert by_cam["Garage"].metadata.get("event_type") == "smartdetect"
    # The file without an event type should NOT have an event_type key.
    assert "event_type" not in by_cam["Backyard"].metadata


def test_finds_files_in_date_subdirs(fake_unifi_root: Path) -> None:
    events = UniFiProtectSource(fake_unifi_root).discover()
    paths = [str(next(iter(e.cams.values()))) for e in events]
    assert any("2026-05-08/Garage" in p.replace("\\", "/") for p in paths)


def test_invalid_date_filename_ignored(fake_unifi_root: Path) -> None:
    events = UniFiProtectSource(fake_unifi_root).discover()
    assert all("2026-99-99" not in e.metadata["filename"] for e in events)


def test_scan_for_new_filters_by_timestamp(fake_unifi_root: Path) -> None:
    events = UniFiProtectSource(fake_unifi_root).scan_for_new(
        after=datetime(2026, 5, 8, 15, 30)
    )
    assert [e.timestamp for e in events] == [datetime(2026, 5, 8, 16, 30, 15)]


def test_missing_root_returns_empty(tmp_path: Path) -> None:
    assert UniFiProtectSource(tmp_path / "no-such-dir").discover() == []
