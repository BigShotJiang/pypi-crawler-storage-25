"""Tests for the Tesla SentryClips folder reader.

Pure-Python tests; no ffmpeg, no network, no Tesla required.
"""

from __future__ import annotations

from datetime import datetime
from pathlib import Path

import pytest

from tesla_clip_tools.sources.tesla import TeslaSource


@pytest.fixture()
def fake_sentry_root(tmp_path: Path) -> Path:
    root = tmp_path / "SentryClips"
    root.mkdir()

    # HW3-era 4-cam event.
    e1 = root / "2026-05-08_14-22-31"
    e1.mkdir()
    for cam in ("front", "back", "left_repeater", "right_repeater"):
        (e1 / f"{cam}.mp4").write_bytes(b"fake-mp4")

    # HW4-era 6-cam event with metadata sidecar.
    e2 = root / "2026-05-08_15-00-00"
    e2.mkdir()
    for cam in (
        "front",
        "back",
        "left_repeater",
        "right_repeater",
        "left_pillar",
        "right_pillar",
    ):
        (e2 / f"{cam}.mp4").write_bytes(b"fake-mp4")
    (e2 / "event.json").write_text('{"reason": "vehicle_alarm"}', encoding="utf-8")

    # Folder that doesn't match the timestamp pattern — must be skipped.
    (root / "RecentClips_2026-05-08").mkdir()

    # Pattern-matching folder with no camera files — must be skipped.
    e3 = root / "2026-05-08_16-00-00"
    e3.mkdir()
    (e3 / "event.json").write_text("{}", encoding="utf-8")

    return root


def test_discover_returns_only_well_formed_events(fake_sentry_root: Path) -> None:
    events = TeslaSource(fake_sentry_root).discover()
    assert [e.timestamp for e in events] == [
        datetime(2026, 5, 8, 14, 22, 31),
        datetime(2026, 5, 8, 15, 0, 0),
    ]


def test_hw3_event_has_four_cams(fake_sentry_root: Path) -> None:
    events = TeslaSource(fake_sentry_root).discover()
    hw3 = next(e for e in events if e.timestamp == datetime(2026, 5, 8, 14, 22, 31))
    assert set(hw3.cams) == {"front", "back", "left_repeater", "right_repeater"}
    assert "left_pillar" not in hw3.cams


def test_hw4_event_has_six_cams_and_metadata(fake_sentry_root: Path) -> None:
    events = TeslaSource(fake_sentry_root).discover()
    hw4 = next(e for e in events if e.timestamp == datetime(2026, 5, 8, 15, 0, 0))
    assert "left_pillar" in hw4.cams
    assert "right_pillar" in hw4.cams
    assert hw4.metadata == {"reason": "vehicle_alarm"}


def test_event_id_uses_tesla_prefix(fake_sentry_root: Path) -> None:
    events = TeslaSource(fake_sentry_root).discover()
    assert events[0].id == "tesla:2026-05-08_14-22-31"


def test_scan_for_new_filters_by_timestamp(fake_sentry_root: Path) -> None:
    cutoff = datetime(2026, 5, 8, 14, 30)
    new_events = TeslaSource(fake_sentry_root).scan_for_new(after=cutoff)
    assert [e.timestamp for e in new_events] == [datetime(2026, 5, 8, 15, 0, 0)]


def test_missing_root_returns_empty(tmp_path: Path) -> None:
    assert TeslaSource(tmp_path / "does-not-exist").discover() == []
