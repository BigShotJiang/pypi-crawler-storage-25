"""Tests for the SMTP email notifier.

Network calls (smtplib.SMTP, smtplib.SMTP_SSL) are patched out — no real
mail leaves the test process.
"""

from __future__ import annotations

import smtplib
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from tesla_clip_tools.notify.base import NotifyError
from tesla_clip_tools.notify.email_smtp import EmailNotifier

_ENV_FULL = {
    "SMTP_HOST": "smtp.example.com",
    "SMTP_USER": "alice",
    "SMTP_PASSWORD": "s3cret",
    "EMAIL_FROM": "alice@example.com",
    "EMAIL_TO": "bob@example.com,carol@example.com",
}


def _set_env(monkeypatch, **overrides):
    for k, v in {**_ENV_FULL, **overrides}.items():
        if v is None:
            monkeypatch.delenv(k, raising=False)
        else:
            monkeypatch.setenv(k, v)
    monkeypatch.delenv("SMTP_PORT", raising=False)


def test_init_reads_env_vars_with_defaults(monkeypatch):
    _set_env(monkeypatch)
    n = EmailNotifier()
    assert n.host == "smtp.example.com"
    assert n.port == 587  # default
    assert n.user == "alice"
    assert n.sender == "alice@example.com"
    assert n.recipients == ["bob@example.com", "carol@example.com"]


def test_init_constructor_args_override_env(monkeypatch):
    _set_env(monkeypatch)
    n = EmailNotifier(host="overrid.example.com", port=2525, recipients=["only@example.com"])
    assert n.host == "overrid.example.com"
    assert n.port == 2525
    assert n.recipients == ["only@example.com"]


def test_init_missing_env_raises_clean_error_listing_missing(monkeypatch):
    """KeyError would leak; we want a NotifyError that names the gaps."""
    monkeypatch.delenv("SMTP_HOST", raising=False)
    monkeypatch.delenv("SMTP_USER", raising=False)
    monkeypatch.delenv("SMTP_PASSWORD", raising=False)
    monkeypatch.delenv("EMAIL_FROM", raising=False)
    monkeypatch.delenv("EMAIL_TO", raising=False)
    with pytest.raises(NotifyError) as excinfo:
        EmailNotifier()
    msg = str(excinfo.value)
    for var in ("SMTP_HOST", "SMTP_USER", "SMTP_PASSWORD", "EMAIL_FROM", "EMAIL_TO"):
        assert var in msg


def test_send_uses_starttls_on_port_587(monkeypatch):
    _set_env(monkeypatch)
    fake_smtp = MagicMock()
    smtp_cm = MagicMock()
    smtp_cm.__enter__.return_value = fake_smtp
    smtp_cm.__exit__.return_value = None
    with patch(
        "tesla_clip_tools.notify.email_smtp.smtplib.SMTP",
        return_value=smtp_cm,
    ) as mock_ctor, patch(
        "tesla_clip_tools.notify.email_smtp.smtplib.SMTP_SSL",
    ) as mock_ssl_ctor:
        EmailNotifier().send("Sentry: vandal", "someone keyed the door")

    mock_ssl_ctor.assert_not_called()
    mock_ctor.assert_called_once()
    args, kwargs = mock_ctor.call_args
    assert args[0] == "smtp.example.com"
    assert args[1] == 587
    fake_smtp.starttls.assert_called_once()
    fake_smtp.login.assert_called_once_with("alice", "s3cret")
    fake_smtp.send_message.assert_called_once()
    msg = fake_smtp.send_message.call_args.args[0]
    assert msg["Subject"] == "Sentry: vandal"
    assert msg["From"] == "alice@example.com"
    assert msg["To"] == "bob@example.com, carol@example.com"
    assert "someone keyed the door" in msg.get_content()


def test_send_uses_smtp_ssl_on_port_465(monkeypatch):
    _set_env(monkeypatch)
    monkeypatch.setenv("SMTP_PORT", "465")
    fake_smtp = MagicMock()
    smtp_cm = MagicMock()
    smtp_cm.__enter__.return_value = fake_smtp
    smtp_cm.__exit__.return_value = None
    with patch(
        "tesla_clip_tools.notify.email_smtp.smtplib.SMTP_SSL",
        return_value=smtp_cm,
    ) as mock_ssl_ctor, patch(
        "tesla_clip_tools.notify.email_smtp.smtplib.SMTP",
    ) as mock_ctor:
        EmailNotifier().send("title", "body")

    mock_ctor.assert_not_called()
    mock_ssl_ctor.assert_called_once()
    args, kwargs = mock_ssl_ctor.call_args
    assert args[0] == "smtp.example.com"
    assert args[1] == 465
    # No starttls() on the SSL path.
    fake_smtp.starttls.assert_not_called()
    fake_smtp.login.assert_called_once_with("alice", "s3cret")
    fake_smtp.send_message.assert_called_once()


def test_send_with_attachment_includes_file_bytes(monkeypatch, tmp_path: Path):
    _set_env(monkeypatch)
    img = tmp_path / "front.jpg"
    img_bytes = b"\xff\xd8\xff\xe0fake-jpeg"
    img.write_bytes(img_bytes)

    fake_smtp = MagicMock()
    smtp_cm = MagicMock()
    smtp_cm.__enter__.return_value = fake_smtp
    smtp_cm.__exit__.return_value = None
    with patch("tesla_clip_tools.notify.email_smtp.smtplib.SMTP", return_value=smtp_cm):
        EmailNotifier().send("title", "body", attachment=img)

    msg = fake_smtp.send_message.call_args.args[0]
    parts = list(msg.iter_attachments())
    assert len(parts) == 1
    part = parts[0]
    assert part.get_filename() == "front.jpg"
    assert part.get_content_type() == "image/jpeg"
    assert part.get_payload(decode=True) == img_bytes


def test_send_smtp_exception_wrapped_as_notifyerror(monkeypatch):
    _set_env(monkeypatch)
    fake_smtp = MagicMock()
    fake_smtp.login.side_effect = smtplib.SMTPAuthenticationError(535, b"bad creds")
    smtp_cm = MagicMock()
    smtp_cm.__enter__.return_value = fake_smtp
    smtp_cm.__exit__.return_value = None
    with patch(
        "tesla_clip_tools.notify.email_smtp.smtplib.SMTP",
        return_value=smtp_cm,
    ), pytest.raises(NotifyError, match="Email send failed"):
        EmailNotifier().send("t", "b")


def test_send_connection_error_wrapped_as_notifyerror(monkeypatch):
    _set_env(monkeypatch)
    with patch(
        "tesla_clip_tools.notify.email_smtp.smtplib.SMTP",
        side_effect=ConnectionRefusedError("port 587 closed"),
    ), pytest.raises(NotifyError, match="Email send failed"):
        EmailNotifier().send("t", "b")


def test_recipients_list_arg_works_directly(monkeypatch):
    _set_env(monkeypatch, EMAIL_TO=None)
    n = EmailNotifier(recipients=["x@example.com", "y@example.com"])
    assert n.recipients == ["x@example.com", "y@example.com"]
