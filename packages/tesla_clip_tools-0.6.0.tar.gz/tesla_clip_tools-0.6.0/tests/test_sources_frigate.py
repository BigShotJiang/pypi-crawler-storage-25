"""Tests for the Frigate exported-clip reader."""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path

import pytest

from tesla_clip_tools.sources.frigate import FrigateSource


def _epoch_for(ts: datetime) -> int:
    """Naive-local datetime → unix seconds. Frigate writes naive-local on disk."""
    return int(ts.timestamp())


@pytest.fixture()
def fake_frigate_root(tmp_path: Path) -> Path:
    """Hierarchical and flat Frigate layouts with JSON sidecars."""
    root = tmp_path / "frigate"
    clips = root / "clips"
    clips.mkdir(parents=True)

    # Hierarchical: <camera>/<YYYY-MM-DD>/<HH>/<event_id>.mp4 (+ sibling .json)
    front_ts = datetime(2026, 5, 8, 14, 22, 31)
    front_dir = clips / "front_door" / "2026-05-08" / "14"
    front_dir.mkdir(parents=True)
    front_event_id = f"{_epoch_for(front_ts)}-abcd1234"
    (front_dir / f"{front_event_id}.mp4").write_bytes(b"fake")
    (front_dir / f"{front_event_id}.json").write_text(
        json.dumps(
            {
                "camera": "front_door",
                "label": "person",
                "score": 0.91,
                "zones": ["porch", "walkway"],
            }
        ),
        encoding="utf-8",
    )

    # Hierarchical with NO sibling JSON
    back_ts = datetime(2026, 5, 8, 15, 0, 0)
    back_dir = clips / "backyard" / "2026-05-08" / "15"
    back_dir.mkdir(parents=True)
    back_event_id = f"{_epoch_for(back_ts)}-no-json"
    (back_dir / f"{back_event_id}.mp4").write_bytes(b"fake")

    # Flat layout: <camera>-<YYYYMMDDHHMMSS>-<event_id>.mp4
    flat_dir = clips / "driveway-flat"
    flat_dir.mkdir()
    (flat_dir / "driveway-20260508163015-evt9.mp4").write_bytes(b"fake")
    (flat_dir / "driveway-20260508163015-evt9.json").write_text(
        json.dumps({"label": "car", "score": 0.77, "zones": ["driveway"]}),
        encoding="utf-8",
    )

    # Garbage files
    (clips / "random.mp4").write_bytes(b"fake")  # not in cam/date/hour layout
    (clips / "notes.txt").write_bytes(b"fake")

    return root


def test_discover_finds_all_valid_files(fake_frigate_root: Path) -> None:
    events = FrigateSource(fake_frigate_root).discover()
    # 3 valid: front_door, backyard, driveway-flat. random.mp4 sits at clips/
    # which is too shallow for hierarchical and doesn't match the flat pattern.
    assert len(events) == 3


def test_event_id_uses_frigate_prefix(fake_frigate_root: Path) -> None:
    events = FrigateSource(fake_frigate_root).discover()
    by_cam = {next(iter(e.cams)): e for e in events}
    assert by_cam["front_door"].id.startswith("frigate:front_door:")
    assert by_cam["backyard"].id.startswith("frigate:backyard:")


def test_sibling_json_metadata_captured(fake_frigate_root: Path) -> None:
    events = FrigateSource(fake_frigate_root).discover()
    by_cam = {next(iter(e.cams)): e for e in events}
    front = by_cam["front_door"]
    assert front.metadata["label"] == "person"
    assert front.metadata["score"] == pytest.approx(0.91)
    assert front.metadata["zones"] == ["porch", "walkway"]


def test_missing_sibling_json_still_creates_event(fake_frigate_root: Path) -> None:
    events = FrigateSource(fake_frigate_root).discover()
    by_cam = {next(iter(e.cams)): e for e in events}
    back = by_cam["backyard"]
    # Event was still created
    assert back.timestamp == datetime(2026, 5, 8, 15, 0, 0)
    # Metadata has only the basics — no label/score/zones.
    assert "label" not in back.metadata
    assert "score" not in back.metadata
    assert "zones" not in back.metadata
    # But the core source/filename/event_id/camera fields are still there.
    assert back.metadata["source"] == "frigate"
    assert back.metadata["camera"] == "backyard"


def test_flat_layout_parses_and_captures_json(fake_frigate_root: Path) -> None:
    events = FrigateSource(fake_frigate_root).discover()
    by_cam = {next(iter(e.cams)): e for e in events}
    driveway = by_cam["driveway"]
    assert driveway.timestamp == datetime(2026, 5, 8, 16, 30, 15)
    assert driveway.metadata["label"] == "car"
    assert driveway.metadata["score"] == pytest.approx(0.77)
    assert driveway.metadata["zones"] == ["driveway"]


def test_multiple_cams_yield_multiple_events(fake_frigate_root: Path) -> None:
    events = FrigateSource(fake_frigate_root).discover()
    cams = {next(iter(e.cams)) for e in events}
    assert cams == {"front_door", "backyard", "driveway"}


def test_events_sorted_by_timestamp(fake_frigate_root: Path) -> None:
    events = FrigateSource(fake_frigate_root).discover()
    timestamps = [e.timestamp for e in events]
    assert timestamps == sorted(timestamps)


def test_invalid_path_layout_ignored(tmp_path: Path) -> None:
    # An mp4 too shallow / not matching either layout — should NOT crash.
    root = tmp_path / "frigate"
    (root / "clips").mkdir(parents=True)
    (root / "clips" / "random.mp4").write_bytes(b"fake")
    events = FrigateSource(root).discover()
    assert events == []


def test_malformed_sibling_json_does_not_crash(tmp_path: Path) -> None:
    root = tmp_path / "frigate"
    bad_dir = root / "clips" / "cam" / "2026-05-08" / "14"
    bad_dir.mkdir(parents=True)
    ts = datetime(2026, 5, 8, 14, 22, 31)
    eid = f"{_epoch_for(ts)}-bad"
    (bad_dir / f"{eid}.mp4").write_bytes(b"fake")
    (bad_dir / f"{eid}.json").write_text("not json {", encoding="utf-8")
    events = FrigateSource(root).discover()
    assert len(events) == 1
    # Falls back gracefully — no label/score/zones, but the event is intact.
    assert "label" not in events[0].metadata


def test_scan_for_new_filters_by_timestamp(fake_frigate_root: Path) -> None:
    events = FrigateSource(fake_frigate_root).scan_for_new(
        after=datetime(2026, 5, 8, 15, 30)
    )
    cams = [next(iter(e.cams)) for e in events]
    # front_door (14:22) and backyard (15:00) are before cutoff; driveway (16:30) after.
    assert cams == ["driveway"]


def test_missing_root_returns_empty(tmp_path: Path) -> None:
    assert FrigateSource(tmp_path / "no-such-dir").discover() == []


def test_empty_directory_returns_empty(tmp_path: Path) -> None:
    empty = tmp_path / "empty"
    empty.mkdir()
    assert FrigateSource(empty).discover() == []
