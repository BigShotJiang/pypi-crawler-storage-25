"""Tests for the Anthropic VLM backend.

All tests inject a fake `anthropic` module into `sys.modules` *before* the
backend module is imported, so the suite passes even on a machine without the
real SDK installed (which is the whole point of the optional extra).
"""

from __future__ import annotations

import importlib
import sys
import types
from unittest.mock import MagicMock

import pytest
from PIL import Image
from pydantic import BaseModel


class _Verdict(BaseModel):
    """Tiny stand-in for the consumer's Pydantic response_format."""

    interesting: bool
    label: str
    confidence: float


def _install_fake_anthropic_sdk(
    *,
    tool_name: str = "record_classification",
    tool_input: dict | str | None = None,
    raise_on_create: Exception | None = None,
) -> tuple[types.ModuleType, MagicMock, MagicMock]:
    """Build and register a minimal fake `anthropic` module + return the mock client.

    Returns (fake_module, ctor_mock, client_mock) so tests can assert on the
    `Anthropic(...)` constructor call AND on the messages.create payload.
    """
    if tool_input is None:
        tool_input = {"interesting": True, "label": "person", "confidence": 0.91}

    tool_block = MagicMock()
    tool_block.type = "tool_use"
    tool_block.name = tool_name
    tool_block.input = tool_input

    response = MagicMock()
    response.content = [tool_block]

    client = MagicMock()
    if raise_on_create is not None:
        client.messages.create.side_effect = raise_on_create
    else:
        client.messages.create.return_value = response

    ctor = MagicMock(return_value=client)
    fake_module = types.ModuleType("anthropic")
    fake_module.Anthropic = ctor  # type: ignore[attr-defined]
    sys.modules["anthropic"] = fake_module
    return fake_module, ctor, client


def _reload_backend():
    """Drop and re-import the anthropic backend module so the lazy import sees
    whatever fake we just registered (or the absence thereof)."""
    sys.modules.pop("tesla_clip_tools.vlm.anthropic", None)
    return importlib.import_module("tesla_clip_tools.vlm.anthropic")


def _img(color=(120, 200, 80)) -> Image.Image:
    return Image.new("RGB", (8, 8), color)


# ---------------------------------------------------------------------------
# 1. Class instantiation respects model arg.
# ---------------------------------------------------------------------------


def test_instantiation_passes_model_and_uses_env_api_key(monkeypatch):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key-from-env")
    _, ctor, _ = _install_fake_anthropic_sdk()
    backend_mod = _reload_backend()

    backend = backend_mod.AnthropicBackend(model="claude-haiku-4-6")

    ctor.assert_called_once_with(api_key="test-key-from-env")
    assert backend.model == "claude-haiku-4-6"


# ---------------------------------------------------------------------------
# 2. classify() calls messages.create with the right number of image blocks.
# ---------------------------------------------------------------------------


def test_classify_sends_one_image_block_per_input(monkeypatch):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "k")
    _, _, client = _install_fake_anthropic_sdk()
    backend_mod = _reload_backend()

    backend = backend_mod.AnthropicBackend()
    backend.classify(
        images=[_img(), _img((10, 10, 10)), _img((250, 0, 0))],
        captions=["[front t=0]", "[back t=1]", "[left t=2]"],
        system_prompt="be concise",
        response_format=_Verdict,
    )

    assert client.messages.create.call_count == 1
    kwargs = client.messages.create.call_args.kwargs
    user_blocks = kwargs["messages"][0]["content"]
    image_blocks = [b for b in user_blocks if b.get("type") == "image"]
    assert len(image_blocks) == 3
    # And each image block carries a base64 source with the JPEG media type.
    for block in image_blocks:
        assert block["source"]["type"] == "base64"
        assert block["source"]["media_type"] == "image/jpeg"
        assert isinstance(block["source"]["data"], str) and block["source"]["data"]
    # Tool wiring: single tool, tool_choice forces it.
    assert len(kwargs["tools"]) == 1
    assert kwargs["tools"][0]["name"] == "record_classification"
    assert kwargs["tool_choice"] == {"type": "tool", "name": "record_classification"}
    # System prompt is on the top-level system kwarg, not in the message list.
    assert kwargs["system"] == "be concise"


def test_classify_rejects_mismatched_images_and_captions(monkeypatch):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "k")
    _install_fake_anthropic_sdk()
    backend_mod = _reload_backend()

    backend = backend_mod.AnthropicBackend()
    with pytest.raises(ValueError, match="must align"):
        backend.classify(
            images=[_img(), _img()],
            captions=["only one"],
            system_prompt="ignored",
            response_format=_Verdict,
        )


# ---------------------------------------------------------------------------
# 3. Returns a parsed instance of the Pydantic response_format.
# ---------------------------------------------------------------------------


def test_classify_returns_parsed_pydantic_instance(monkeypatch):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "k")
    payload = {"interesting": False, "label": "leaf", "confidence": 0.42}
    _install_fake_anthropic_sdk(tool_input=payload)
    backend_mod = _reload_backend()

    backend = backend_mod.AnthropicBackend()
    out = backend.classify(
        images=[_img()],
        captions=["[front t=0]"],
        system_prompt="x",
        response_format=_Verdict,
    )

    assert isinstance(out, _Verdict)
    assert out.interesting is False
    assert out.label == "leaf"
    assert out.confidence == pytest.approx(0.42)


def test_classify_handles_string_tool_input(monkeypatch):
    """Some SDK versions hand back `input` as a JSON string. Backend must cope."""
    monkeypatch.setenv("ANTHROPIC_API_KEY", "k")
    _install_fake_anthropic_sdk(
        tool_input='{"interesting": true, "label": "raccoon", "confidence": 0.7}',
    )
    backend_mod = _reload_backend()

    backend = backend_mod.AnthropicBackend()
    out = backend.classify(
        images=[_img()],
        captions=["c"],
        system_prompt="s",
        response_format=_Verdict,
    )

    assert out.interesting is True
    assert out.label == "raccoon"


# ---------------------------------------------------------------------------
# 4. Raises a clean error (not an SDK leak) on malformed payloads.
# ---------------------------------------------------------------------------


def test_classify_raises_clean_error_on_malformed_tool_input(monkeypatch):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "k")
    # Missing required fields -> Pydantic validation error wrapped in a clean RuntimeError.
    _install_fake_anthropic_sdk(tool_input={"interesting": True})
    backend_mod = _reload_backend()

    backend = backend_mod.AnthropicBackend()
    with pytest.raises(RuntimeError, match="schema validation"):
        backend.classify(
            images=[_img()],
            captions=["c"],
            system_prompt="s",
            response_format=_Verdict,
        )


def test_classify_raises_when_no_tool_use_block_present(monkeypatch):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "k")
    _, _, client = _install_fake_anthropic_sdk()
    # Replace the response with one that has only a text block (no tool_use).
    text_block = MagicMock()
    text_block.type = "text"
    response = MagicMock()
    response.content = [text_block]
    client.messages.create.return_value = response
    backend_mod = _reload_backend()

    backend = backend_mod.AnthropicBackend()
    with pytest.raises(RuntimeError, match="no tool_use block"):
        backend.classify(
            images=[_img()],
            captions=["c"],
            system_prompt="s",
            response_format=_Verdict,
        )


def test_classify_raises_clean_error_on_invalid_json_string_input(monkeypatch):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "k")
    _install_fake_anthropic_sdk(tool_input="this is not json")
    backend_mod = _reload_backend()

    backend = backend_mod.AnthropicBackend()
    with pytest.raises(RuntimeError, match="not valid JSON"):
        backend.classify(
            images=[_img()],
            captions=["c"],
            system_prompt="s",
            response_format=_Verdict,
        )


# ---------------------------------------------------------------------------
# 5. Lazy import: importing the module without the SDK installed doesn't crash.
# ---------------------------------------------------------------------------


def test_module_imports_without_sdk_installed():
    """Even with `anthropic` absent, `import tesla_clip_tools.vlm.anthropic`
    must succeed — the SDK is only touched inside `__init__`."""
    sys.modules.pop("anthropic", None)
    sys.modules.pop("tesla_clip_tools.vlm.anthropic", None)

    backend_mod = importlib.import_module("tesla_clip_tools.vlm.anthropic")

    # Module imported cleanly and the class is exposed.
    assert hasattr(backend_mod, "AnthropicBackend")

    # Trying to actually construct should raise a clean ImportError pointing
    # at the optional extra — not whatever cryptic AttributeError the SDK
    # would have raised had we touched it.
    with pytest.raises(ImportError, match=r"\[anthropic\]"):
        backend_mod.AnthropicBackend()
