"""Tests for the Wyze SD-card layout reader."""

from __future__ import annotations

from datetime import datetime
from pathlib import Path

import pytest

from tesla_clip_tools.sources.wyze import WyzeSource


@pytest.fixture()
def fake_wyze_root(tmp_path: Path) -> Path:
    """Build a synthetic Wyze SD-card layout:

        20260508/
          14/
            22.mp4   ← 14:22
            23.mp4   ← 14:23
          15/
            00.mp4   ← 15:00
        20260509/
          09/
            05.mp4   ← 09:05 next day
        ZZZZZZZZ/    ← garbage day folder, ignored
        20260508/garbage/   ← non-numeric hour, ignored
    """
    root = tmp_path / "WYZE"
    root.mkdir()

    (root / "20260508" / "14").mkdir(parents=True)
    (root / "20260508" / "14" / "22.mp4").write_bytes(b"fake")
    (root / "20260508" / "14" / "23.mp4").write_bytes(b"fake")
    (root / "20260508" / "14" / "garbage.mp4").write_bytes(b"fake")  # ignored
    (root / "20260508" / "15").mkdir()
    (root / "20260508" / "15" / "00.mp4").write_bytes(b"fake")
    (root / "20260508" / "garbage").mkdir()  # ignored
    (root / "20260509" / "09").mkdir(parents=True)
    (root / "20260509" / "09" / "05.mp4").write_bytes(b"fake")
    (root / "ZZZZZZZZ").mkdir()  # ignored
    return root


def test_discover_returns_minute_clips_in_order(fake_wyze_root: Path) -> None:
    events = WyzeSource(fake_wyze_root).discover()
    assert [e.timestamp for e in events] == [
        datetime(2026, 5, 8, 14, 22),
        datetime(2026, 5, 8, 14, 23),
        datetime(2026, 5, 8, 15, 0),
        datetime(2026, 5, 9, 9, 5),
    ]


def test_event_has_single_wyze_cam(fake_wyze_root: Path) -> None:
    events = WyzeSource(fake_wyze_root).discover()
    assert all(set(e.cams) == {"wyze"} for e in events)


def test_cam_alias_overrides_default(fake_wyze_root: Path) -> None:
    events = WyzeSource(fake_wyze_root, cam_alias="porch").discover()
    assert all(set(e.cams) == {"porch"} for e in events)


def test_event_id_uses_wyze_prefix(fake_wyze_root: Path) -> None:
    events = WyzeSource(fake_wyze_root).discover()
    assert events[0].id == "wyze:20260508-1422"


def test_metadata_marks_minute_clip(fake_wyze_root: Path) -> None:
    events = WyzeSource(fake_wyze_root).discover()
    assert events[0].metadata == {"source": "wyze", "minute_clip": True}


def test_scan_for_new_filters_by_timestamp(fake_wyze_root: Path) -> None:
    events = WyzeSource(fake_wyze_root).scan_for_new(
        after=datetime(2026, 5, 8, 14, 30)
    )
    assert [e.timestamp for e in events] == [
        datetime(2026, 5, 8, 15, 0),
        datetime(2026, 5, 9, 9, 5),
    ]


def test_missing_root_returns_empty(tmp_path: Path) -> None:
    assert WyzeSource(tmp_path / "no-such-dir").discover() == []


def test_skips_non_minute_filenames(fake_wyze_root: Path) -> None:
    # `garbage.mp4` was inserted into the 14:00 hour folder; verify ignored.
    events = WyzeSource(fake_wyze_root).discover()
    paths = [str(next(iter(e.cams.values())).name) for e in events]
    assert "garbage.mp4" not in paths
