"""Tests for the Reolink filename-parsing reader."""

from __future__ import annotations

from datetime import datetime
from pathlib import Path

import pytest

from tesla_clip_tools.sources.reolink import ReolinkSource


@pytest.fixture()
def fake_reolink_root(tmp_path: Path) -> Path:
    """Mix of all 3 supported filename shapes plus garbage to ignore."""
    root = tmp_path / "reolink-export"
    root.mkdir()
    # Pattern 1: compact <Cam>_YYYYMMDDHHMMSS.mp4
    (root / "Driveway_20260508142231.mp4").write_bytes(b"fake")
    # Pattern 2: NVR with RecS / DST
    (root / "Backyard_RecS01_DST20260508150045_120_abc123.mp4").write_bytes(b"fake")
    # Pattern 3: dashed
    (root / "Garage_2026-05-08_16-30-12.mp4").write_bytes(b"fake")
    # Garbage filenames — ignored
    (root / "random.mp4").write_bytes(b"fake")
    (root / "notes.txt").write_bytes(b"fake")
    (root / "Cam_2026-13-32_99-99-99.mp4").write_bytes(b"fake")  # invalid date
    return root


def test_discover_parses_all_three_patterns(fake_reolink_root: Path) -> None:
    events = ReolinkSource(fake_reolink_root).discover()
    assert len(events) == 3
    by_cam = {next(iter(e.cams)) for e in events}
    assert by_cam == {"Driveway", "Backyard", "Garage"}


def test_events_sorted_by_timestamp(fake_reolink_root: Path) -> None:
    events = ReolinkSource(fake_reolink_root).discover()
    assert [e.timestamp for e in events] == [
        datetime(2026, 5, 8, 14, 22, 31),
        datetime(2026, 5, 8, 15, 0, 45),
        datetime(2026, 5, 8, 16, 30, 12),
    ]


def test_event_id_includes_cam_and_timestamp(fake_reolink_root: Path) -> None:
    events = ReolinkSource(fake_reolink_root).discover()
    ids = [e.id for e in events]
    assert "reolink:Driveway:20260508-142231" in ids
    assert "reolink:Backyard:20260508-150045" in ids


def test_metadata_includes_filename(fake_reolink_root: Path) -> None:
    events = ReolinkSource(fake_reolink_root).discover()
    for e in events:
        assert e.metadata["source"] == "reolink"
        assert e.metadata["filename"].endswith(".mp4")


def test_invalid_date_in_filename_ignored(fake_reolink_root: Path) -> None:
    events = ReolinkSource(fake_reolink_root).discover()
    assert all("2026-13-32" not in e.metadata["filename"] for e in events)


def test_scan_for_new_filters_by_timestamp(fake_reolink_root: Path) -> None:
    events = ReolinkSource(fake_reolink_root).scan_for_new(
        after=datetime(2026, 5, 8, 15, 30)
    )
    assert [e.timestamp for e in events] == [datetime(2026, 5, 8, 16, 30, 12)]


def test_missing_root_returns_empty(tmp_path: Path) -> None:
    assert ReolinkSource(tmp_path / "no-such-dir").discover() == []
