"""Tests for the Eufy exported-clip reader."""

from __future__ import annotations

from datetime import datetime
from pathlib import Path

import pytest

from tesla_clip_tools.sources.eufy import EufySource


@pytest.fixture()
def fake_eufy_root(tmp_path: Path) -> Path:
    """Mix of all 3 supported filename shapes plus garbage."""
    root = tmp_path / "eufy-export"
    root.mkdir()
    # Pattern 1: app export
    (root / "FrontDoor_2026-05-08_14-22-31.mp4").write_bytes(b"fake")
    (root / "Backyard_2026-05-08_15-00-00.mp4").write_bytes(b"fake")
    # Pattern 2: alternate web UI / NAS export
    (root / "Driveway-20260508-163015.mp4").write_bytes(b"fake")
    # Pattern 3: HomeBase NAS-style (1762610551000 ms = 2025-11-08 12:42:31 UTC)
    (root / "eufy_T8210ABC_1762610551000.mp4").write_bytes(b"fake")
    # Per-device subdir with a valid file
    (root / "Garage").mkdir()
    (root / "Garage" / "Garage_2026-05-09_08-00-00.mp4").write_bytes(b"fake")
    # Garbage
    (root / "random.mp4").write_bytes(b"fake")
    (root / "notes.txt").write_bytes(b"fake")
    (root / "Cam_2026-13-32_99-99-99.mp4").write_bytes(b"fake")  # invalid date
    return root


def test_discover_finds_all_valid_files(fake_eufy_root: Path) -> None:
    events = EufySource(fake_eufy_root).discover()
    assert len(events) == 5


def test_event_id_uses_eufy_prefix(fake_eufy_root: Path) -> None:
    events = EufySource(fake_eufy_root).discover()
    by_cam = {next(iter(e.cams)): e for e in events}
    assert by_cam["FrontDoor"].id == "eufy:FrontDoor:20260508-142231"


def test_alternate_web_pattern_parses(fake_eufy_root: Path) -> None:
    events = EufySource(fake_eufy_root).discover()
    by_cam = {next(iter(e.cams)): e for e in events}
    assert by_cam["Driveway"].timestamp == datetime(2026, 5, 8, 16, 30, 15)


def test_homebase_pattern_captures_device_id(fake_eufy_root: Path) -> None:
    events = EufySource(fake_eufy_root).discover()
    by_cam = {next(iter(e.cams)): e for e in events}
    homebase = by_cam["T8210ABC"]
    assert homebase.metadata.get("device_id") == "T8210ABC"
    assert homebase.metadata["source"] == "eufy"
    # 1762610551000 ms → 2025-11-08 12:42:31 UTC, stored naive.
    assert homebase.timestamp.year == 2025
    assert homebase.timestamp.month == 11


def test_multiple_cams_yield_multiple_events(fake_eufy_root: Path) -> None:
    events = EufySource(fake_eufy_root).discover()
    cams = {next(iter(e.cams)) for e in events}
    assert {"FrontDoor", "Backyard", "Driveway", "Garage", "T8210ABC"} <= cams


def test_subdir_files_included(fake_eufy_root: Path) -> None:
    events = EufySource(fake_eufy_root).discover()
    paths = [str(next(iter(e.cams.values()))) for e in events]
    assert any("Garage/Garage_" in p.replace("\\", "/") for p in paths)


def test_invalid_date_filename_ignored(fake_eufy_root: Path) -> None:
    events = EufySource(fake_eufy_root).discover()
    assert all("2026-13-32" not in e.metadata["filename"] for e in events)


def test_metadata_captures_source_and_filename(fake_eufy_root: Path) -> None:
    events = EufySource(fake_eufy_root).discover()
    for e in events:
        assert e.metadata["source"] == "eufy"
        assert e.metadata["filename"].endswith(".mp4")


def test_scan_for_new_filters_by_timestamp(fake_eufy_root: Path) -> None:
    events = EufySource(fake_eufy_root).scan_for_new(
        after=datetime(2026, 5, 8, 15, 30)
    )
    # FrontDoor (14:22) + Backyard (15:00) + HomeBase (Nov 2025) all before cutoff.
    # Driveway (16:30) and Garage (May 9) come after.
    cams = [next(iter(e.cams)) for e in events]
    assert cams == ["Driveway", "Garage"]


def test_missing_root_returns_empty(tmp_path: Path) -> None:
    assert EufySource(tmp_path / "no-such-dir").discover() == []


def test_empty_directory_returns_empty(tmp_path: Path) -> None:
    empty = tmp_path / "empty"
    empty.mkdir()
    assert EufySource(empty).discover() == []
