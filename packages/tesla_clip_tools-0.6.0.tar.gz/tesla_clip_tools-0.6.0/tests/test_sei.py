"""Tests for the SEI byte-walking primitives.

`iter_sei_payloads` runs without protobuf. We test the helpers against tiny
hand-rolled byte sequences — not real Tesla MP4 atoms, just enough to exercise
the parser branches.
"""

from __future__ import annotations

import io
import struct

import pytest

from tesla_clip_tools.sei import (
    NAL_ID_SEI,
    NAL_SEI_ID_USER_DATA_UNREGISTERED,
    _find_mdat,
    _iter_proto_payloads,
    _strip_emu,
)


def test_strip_emu_removes_03_after_two_zeros() -> None:
    # Inserted emulation-prevention byte: 00 00 03 01 -> 00 00 01
    assert _strip_emu(b"\x00\x00\x03\x01") == b"\x00\x00\x01"


def test_strip_emu_leaves_unrelated_03_alone() -> None:
    assert _strip_emu(b"\x01\x03\x02") == b"\x01\x03\x02"


def test_strip_emu_handles_runs_of_zeros() -> None:
    # 00 00 03 00 03 -> 00 00 00 03 (second 03 stays because zeros reset after first 03)
    assert _strip_emu(b"\x00\x00\x03\x00\x03") == b"\x00\x00\x00\x03"


def test_find_mdat_locates_mdat_after_other_atoms() -> None:
    # ftyp atom (size=12, type=ftyp, 4 bytes payload) then mdat (size=10, 2 bytes payload).
    ftyp = struct.pack(">I4s", 12, b"ftyp") + b"abcd"
    mdat = struct.pack(">I4s", 10, b"mdat") + b"xy"
    fp = io.BytesIO(ftyp + mdat)
    offset, size = _find_mdat(fp)
    assert offset == len(ftyp) + 8
    assert size == 2


def test_find_mdat_raises_when_absent() -> None:
    ftyp = struct.pack(">I4s", 12, b"ftyp") + b"abcd"
    fp = io.BytesIO(ftyp + struct.pack(">I4s", 10, b"moov") + b"xy")
    with pytest.raises(RuntimeError, match="mdat atom not found"):
        _find_mdat(fp)


def test_iter_proto_payloads_skips_non_sei_nals() -> None:
    # Build one non-SEI NAL (type=1 == coded slice) of length 5.
    non_sei = struct.pack(">I", 5) + bytes([0x01, 0x02, 0x03, 0x04, 0x05])
    fp = io.BytesIO(non_sei)
    payloads = list(_iter_proto_payloads(fp, 0, len(non_sei)))
    assert payloads == []


def test_iter_proto_payloads_extracts_sei_user_data_unregistered() -> None:
    # NAL header byte: nal_ref_idc=0, nal_unit_type=6 (SEI). 0x06.
    # Second byte: SEI payload type 5 (user_data_unregistered).
    # Then an arbitrary 0x42-padding sequence, then the 0x69 marker, then the
    # proto bytes (b"hello"), then a trailing 0x00 (the parser drops the last byte).
    nal_body = bytes([NAL_ID_SEI, NAL_SEI_ID_USER_DATA_UNREGISTERED, 0x42, 0x69]) + b"hello\x00"
    nal = struct.pack(">I", len(nal_body)) + nal_body
    fp = io.BytesIO(nal)
    payloads = list(_iter_proto_payloads(fp, 0, len(nal)))
    assert payloads == [b"hello"]
