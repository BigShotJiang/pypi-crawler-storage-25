# Changelog

All notable changes to `tesla-clip-tools` are documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.6.0] - 2026-05-14

Two new notifier backends — **Discord** (incoming webhooks) and **Email**
(SMTP) — bringing the total to four (alongside the existing Pushover and
Telegram). Self-hosters now have a no-account-required path (Discord
webhook) and a universal fallback (any SMTP relay).

### Added
- `notify/discord.py` — `DiscordNotifier`. Reads `DISCORD_WEBHOOK_URL`
  (the full webhook URL from a Discord channel's *Integrations ->
  Webhooks* page). Text-only sends use a JSON payload
  (`{"content": title, "embeds": [{"description": body}]}`); attachments
  switch to `multipart/form-data` with a `payload_json` field plus a
  `files[0]` part. Auto-truncates the embed description at Discord's
  4096-char limit (with an explicit `(truncated)` marker) instead of
  letting the webhook 400.
- `notify/email_smtp.py` — `EmailNotifier`, named `email_smtp` so it
  doesn't shadow the stdlib `email` module. Uses only stdlib
  (`smtplib` + `email.message.EmailMessage`), so zero new deps. Reads
  `SMTP_HOST`, `SMTP_PORT` (default 587), `SMTP_USER`, `SMTP_PASSWORD`,
  `EMAIL_FROM`, `EMAIL_TO` (comma-separated recipients). Port-based
  TLS dispatch: 465 -> implicit `SMTP_SSL`, anything else -> `SMTP` +
  `STARTTLS`. Attachments via `EmailMessage.add_attachment()` with
  MIME type guessed from the filename.
- Per-backend tests (`tests/test_notify_{discord,email}.py`) — 10 tests
  each covering env-var wiring, payload shape (JSON vs multipart, MIME
  via attachment), TLS dispatch, network/SMTP error wrapping, oversize
  body truncation, and missing-attachment fallback. All `httpx.post`
  / `smtplib.SMTP` / `smtplib.SMTP_SSL` calls are mocked, so no traffic
  leaves the test process.

### Changed
- `notify/__init__.py` exports `DiscordNotifier` and `EmailNotifier`
  alongside `PushoverNotifier` and `TelegramNotifier`.

## [0.5.0] - 2026-05-13

Two new cloud VLM backends — **Anthropic** (Claude) and **Google Gemini** —
alongside the existing OpenAI + Ollama. Removes single-vendor lock-in for
downstream tools (`sentrytriage`, `fsd-disengagement-studio`).

### Added
- `vlm/anthropic.py` — `AnthropicBackend` using the `anthropic` SDK. Default
  model `claude-sonnet-4-6`. Reads `ANTHROPIC_API_KEY`. Structured output is
  produced via the Messages tools API (`tool_choice` forces a single tool call
  whose `input_schema` is the consumer's Pydantic `model_json_schema()`),
  since Anthropic doesn't yet ship a native structured-output endpoint.
- `vlm/gemini.py` — `GeminiBackend` using the `google-genai` SDK. Default
  model `gemini-2.5-flash` with an automatic single-retry fallback to
  `gemini-2.0-flash` if the SDK rejects the newer name. Reads
  `GOOGLE_API_KEY`. Structured output is native: passes the Pydantic class
  through `GenerateContentConfig.response_schema` plus
  `response_mime_type="application/json"`.
- Optional install extras `[anthropic]` and `[gemini]` so the base install
  stays lean — both backends lazy-import their SDKs and surface a clean
  `ImportError` (pointing at the right extra) when the SDK is absent.
- Per-backend tests (`tests/test_vlm_{anthropic,gemini}.py`) — 5 tests each,
  all running off `sys.modules`-injected fakes so the suite passes on
  machines without either SDK installed.

### Notes
- Both backends downscale images to 1024 px and JPEG-encode at quality 85
  before sending, matching the OpenAI/Ollama payload budget. RGBA inputs are
  flattened on a black background since JPEG can't carry transparency.

## [0.4.0] - 2026-05-13

Adds two new camera sources, bringing the total to 8 plugins.

### Added
- `EufySource` — reads Eufy security camera exports in three filename
  shapes: app export (`<Device>_<YYYY-MM-DD>_<HH-MM-SS>.mp4`), alternate
  web/NAS export (`<Device>-<YYYYMMDD>-<HHMMSS>.mp4`), and HomeBase NAS
  style (`eufy_<DeviceID>_<UnixMillis>.mp4`). Walks one level of subdirs.
- `FrigateSource` — reads a Frigate NVR `clips/` directory. Supports the
  canonical hierarchical layout (`<cam>/<YYYY-MM-DD>/<HH>/<event_id>.mp4`)
  and a flat fallback (`<cam>-<YYYYMMDDHHMMSS>-<event_id>.mp4`). When a
  sibling `<event_id>.json` exists, captures `label`, `score`, and `zones`
  into `Event.metadata`.
- Per-source unit tests (`tests/test_sources_{eufy,frigate}.py`).

### Changed
- `sources/__init__.py` now exports all 8 source classes (the missing
  `RingSource`/`NestSource` re-exports from 0.3 are also added).

## [0.3.0] - 2026-05-12

First release published to PyPI. Adds multi-source support so downstream tools
(`sentrytriage`, `fsd-disengagement-studio`) can target Wyze, Reolink, UniFi
Protect, Ring, and Nest folder layouts with the same pipeline.

### Added
- New camera sources: `WyzeSource`, `ReolinkSource`, `UniFiProtectSource`,
  `RingSource`, `NestSource` (all subclass `Source` and emit the same `Event`
  shape as `TeslaSource`).
- Per-source unit tests covering folder-layout discovery
  (`tests/test_sources_{wyze,reolink,unifi_protect,ring,nest}.py`).
- Per-repo GitHub Actions workflow (`.github/workflows/ci.yml`) running ruff +
  pytest on Python 3.12 and 3.13.
- PyPI metadata: `authors.email`, expanded `keywords`, additional
  `classifiers` (`Intended Audience`, `Operating System :: OS Independent`,
  `Programming Language :: Python :: 3`), and `Repository` + `Changelog`
  project URLs.
- Release runbook (`RELEASE.md`).

### Changed
- `description` tightened to a single short line for clean PyPI rendering.
- README: added install-from-PyPI snippet, PyPI + CI badges, link to this
  changelog.

## [0.2.0] - 2026-05-09

### Added
- `vlm/ollama.py` — local Qwen2.5-VL backend via the Ollama HTTP API with
  JSON-schema structured output, alongside the existing OpenAI backend.
- `notify/` package with Pushover and Telegram notifiers (optional).
- SEI helpers: `iter_sei_payloads()` (no protobuf required) and
  `sei_dataframe()` (requires the `sei` extra: `protobuf`, `pandas`).
- Vendored `dashcam.proto` from Tesla's published schema.

### Changed
- VLM backends parameterised on a Pydantic `response_format` so each consumer
  defines its own verdict schema without forking the backend.

## [0.1.0] - 2026-05-08

Initial extraction from `sentrytriage` v0.2 → v0.3.

### Added
- `sources/base.py` — `Source` ABC and `Event` dataclass.
- `sources/tesla.py` — TeslaCam SentryClips folder-layout reader (HW3 4-cam
  and HW4 6-cam).
- `sampler.py` — frame extraction via `imageio[ffmpeg]` (bundled ffmpeg
  binary, no system dependency on the read path).
- `vlm/base.py` and `vlm/openai.py` — generic VLM backend protocol with a
  default OpenAI `gpt-4o-mini` implementation using
  `beta.chat.completions.parse` for structured outputs.
- MIT license, initial README, and pytest suite.

[Unreleased]: https://github.com/Raymondriter/tesla-clip-tools/compare/v0.6.0...HEAD
[0.6.0]: https://github.com/Raymondriter/tesla-clip-tools/compare/v0.5.0...v0.6.0
[0.5.0]: https://github.com/Raymondriter/tesla-clip-tools/compare/v0.4.0...v0.5.0
[0.4.0]: https://github.com/Raymondriter/tesla-clip-tools/releases/tag/v0.4.0
[0.3.0]: https://github.com/Raymondriter/tesla-clip-tools/releases/tag/v0.3.0
[0.2.0]: https://github.com/Raymondriter/tesla-clip-tools/releases/tag/v0.2.0
[0.1.0]: https://github.com/Raymondriter/tesla-clip-tools/releases/tag/v0.1.0
