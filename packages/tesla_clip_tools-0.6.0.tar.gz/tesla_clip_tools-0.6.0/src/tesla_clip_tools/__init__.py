"""Reusable primitives for TeslaCam, Wyze, Reolink, UniFi, Ring, Nest, Eufy, and Frigate clips."""

__version__ = "0.6.0"
