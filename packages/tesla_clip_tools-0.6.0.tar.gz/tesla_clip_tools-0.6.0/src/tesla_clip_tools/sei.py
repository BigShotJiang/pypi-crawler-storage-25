"""SEI metadata extraction from Tesla Dashcam (SavedClips/RecentClips) MP4s.

**Important caveat from `ideas/v2/wave3/sei_dashcam_tooling.md`**: SEI is
only embedded in *Dashcam* clips (SavedClips and RecentClips), NOT in Sentry
events. Triagers operating on `SentryClips/` won't see SEI.

Two layers of API:

- `iter_sei_payloads(mp4_path)` — pure stdlib. Yields raw protobuf-encoded
  bytes per video frame. Use this if you want to do your own decoding.
- `sei_dataframe(mp4_path)` — convenience wrapper that decodes via
  `dashcam_pb2` (generated from `dashcam.proto`) and returns a pandas
  DataFrame. Requires `tesla-clip-tools[sei]` extra (`pip install
  tesla-clip-tools[sei]`) plus a one-time `protoc --python_out=. dashcam.proto`
  to generate `dashcam_pb2.py`.

Implementation ported from the worked example in wave 3.
"""

from __future__ import annotations

import struct
from collections.abc import Iterator
from pathlib import Path

NAL_ID_SEI = 6
NAL_SEI_ID_USER_DATA_UNREGISTERED = 5


def iter_sei_payloads(mp4_path: Path | str) -> Iterator[bytes]:
    """Yield raw protobuf-encoded SEI payloads from an MP4 file's mdat atom."""
    with open(mp4_path, "rb") as fp:
        offset, size = _find_mdat(fp)
        yield from _iter_proto_payloads(fp, offset, size)


def sei_dataframe(mp4_path: Path | str):
    """Return a pandas DataFrame, one row per video frame's SEI metadata.

    Requires the `[sei]` extra (`pip install tesla-clip-tools[sei]`) and a
    generated `dashcam_pb2.py`:

        protoc --python_out=src/tesla_clip_tools src/tesla_clip_tools/dashcam.proto
    """
    try:
        import pandas as pd  # noqa: PLC0415 — defer heavy import
        from google.protobuf.json_format import MessageToDict  # noqa: PLC0415
        from google.protobuf.message import DecodeError  # noqa: PLC0415

        from . import dashcam_pb2  # noqa: PLC0415 — vendored generated module
    except ImportError as exc:
        raise RuntimeError(
            "sei_dataframe requires the [sei] extra (pip install tesla-clip-tools[sei]) "
            "AND a generated dashcam_pb2.py. Run: "
            "protoc --python_out=src/tesla_clip_tools src/tesla_clip_tools/dashcam.proto"
        ) from exc

    rows: list[dict] = []
    for payload in iter_sei_payloads(mp4_path):
        try:
            meta = dashcam_pb2.SeiMetadata()
            meta.ParseFromString(payload)
        except DecodeError:
            continue
        rows.append(
            MessageToDict(
                meta,
                preserving_proto_field_name=True,
                including_default_value_fields=True,
            )
        )
    return pd.DataFrame(rows)


def _find_mdat(fp) -> tuple[int, int]:
    """Walk MP4 atoms, return (offset, size) of first mdat box."""
    fp.seek(0)
    while True:
        header = fp.read(8)
        if len(header) < 8:
            raise RuntimeError("mdat atom not found")
        size32, atom_type = struct.unpack(">I4s", header)
        if size32 == 1:  # 64-bit extended size
            atom_size = struct.unpack(">Q", fp.read(8))[0]
            header_size = 16
        else:
            atom_size = size32 if size32 else 0
            header_size = 8
        if atom_type == b"mdat":
            return fp.tell(), (atom_size - header_size if atom_size else 0)
        fp.seek(atom_size - header_size, 1)


def _iter_proto_payloads(fp, offset: int, size: int) -> Iterator[bytes]:
    """Yield proto-encoded SEI payloads from inside the mdat atom."""
    fp.seek(offset)
    consumed = 0
    while size == 0 or consumed < size:
        header = fp.read(4)
        if len(header) < 4:
            break
        nal_size = struct.unpack(">I", header)[0]
        if nal_size < 2:
            fp.seek(nal_size, 1)
            consumed += 4 + nal_size
            continue
        first_two = fp.read(2)
        if len(first_two) != 2:
            break
        is_sei_user_data = (
            (first_two[0] & 0x1F) == NAL_ID_SEI
            and first_two[1] == NAL_SEI_ID_USER_DATA_UNREGISTERED
        )
        if not is_sei_user_data:
            fp.seek(nal_size - 2, 1)
            consumed += 4 + nal_size
            continue
        nal = first_two + fp.read(nal_size - 2)
        consumed += 4 + nal_size
        # Walk past 0x42 padding to the 0x69 proto marker; emulation-strip the payload.
        for i in range(3, len(nal) - 1):
            if nal[i] == 0x42:
                continue
            if nal[i] == 0x69 and i > 2:
                yield _strip_emu(nal[i + 1 : -1])
            break


def _strip_emu(data: bytes) -> bytes:
    """Strip H.264 emulation-prevention 0x03 bytes following 0x00 0x00."""
    out = bytearray()
    zeros = 0
    for b in data:
        if zeros >= 2 and b == 0x03:
            zeros = 0
            continue
        out.append(b)
        zeros = 0 if b != 0 else zeros + 1
    return bytes(out)
