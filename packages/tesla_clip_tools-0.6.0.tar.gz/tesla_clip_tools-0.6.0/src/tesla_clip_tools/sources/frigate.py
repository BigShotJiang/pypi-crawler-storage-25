"""Frigate NVR exported-clips reader.

Frigate (https://frigate.video/) is a popular self-hosted NVR. Default file
structure on disk:

    <storage_root>/clips/<camera>/<YYYY-MM-DD>/<HH>/<event_id>.mp4
    <storage_root>/clips/<camera>-<YYYYMMDDHHMMSS>-<event_id>.mp4    (flat configs)

Each event-triggered clip typically has a sibling `<event_id>.json` snapshot
file containing metadata (camera, label, score, zones). When that JSON exists
we capture `{"label", "score", "zones"}` into the Event's metadata.

Each Event is keyed `frigate:<camera>:<timestamp>`.
"""

from __future__ import annotations

import contextlib
import json
import re
from datetime import datetime
from pathlib import Path

from .base import Event, Source

# Hierarchical layout: <root>/clips/<camera>/<YYYY-MM-DD>/<HH>/<event_id>.mp4
_DATE_DIR_RE = re.compile(r"^(?P<year>\d{4})-(?P<month>\d{2})-(?P<day>\d{2})$")
_HOUR_DIR_RE = re.compile(r"^(?P<hour>\d{2})$")

# Flat layout: <camera>-<YYYYMMDDHHMMSS>-<event_id>.mp4
_PATTERN_FLAT = re.compile(
    r"^(?P<cam>[A-Za-z0-9][A-Za-z0-9_-]*?)-"
    r"(?P<year>\d{4})(?P<month>\d{2})(?P<day>\d{2})"
    r"(?P<hour>\d{2})(?P<minute>\d{2})(?P<second>\d{2})-"
    r"(?P<event_id>[A-Za-z0-9_.-]+)\.mp4$"
)


class FrigateSource(Source):
    """Reads a Frigate `clips/` directory (hierarchical or flat layout)."""

    def __init__(self, root: Path | str):
        self.root = Path(root).expanduser()

    def discover(self) -> list[Event]:
        if not self.root.is_dir():
            return []
        events: list[Event] = []
        for path in self._iter_clip_files():
            event = self._maybe_parse(path)
            if event is not None:
                events.append(event)
        events.sort(key=lambda e: (e.timestamp, sorted(e.cams)))
        return events

    def scan_for_new(self, after: datetime | None = None) -> list[Event]:
        events = self.discover()
        if after is None:
            return events
        return [e for e in events if e.timestamp > after]

    def _iter_clip_files(self):
        for path in self.root.rglob("*.mp4"):
            if path.is_file():
                yield path

    def _maybe_parse(self, path: Path) -> Event | None:
        # Try the flat layout first (filename carries the timestamp).
        m = _PATTERN_FLAT.match(path.name)
        if m is not None:
            try:
                ts = datetime(
                    int(m.group("year")),
                    int(m.group("month")),
                    int(m.group("day")),
                    int(m.group("hour")),
                    int(m.group("minute")),
                    int(m.group("second")),
                )
            except ValueError:
                return None
            return self._build_event(
                path, m.group("cam"), ts, event_id=m.group("event_id")
            )

        # Hierarchical layout: parse path segments.
        # Expected: .../<camera>/<YYYY-MM-DD>/<HH>/<event_id>.mp4
        parts = path.parts
        if len(parts) < 4:
            return None
        hour_seg = parts[-2]
        date_seg = parts[-3]
        cam_seg = parts[-4]
        date_match = _DATE_DIR_RE.match(date_seg)
        hour_match = _HOUR_DIR_RE.match(hour_seg)
        if date_match is None or hour_match is None:
            return None
        # event_id is the filename stem; if it parses as a unix timestamp use it,
        # otherwise fall back to the hour boundary.
        event_id = path.stem
        try:
            base_ts = datetime(
                int(date_match.group("year")),
                int(date_match.group("month")),
                int(date_match.group("day")),
                int(hour_match.group("hour")),
                0,
                0,
            )
        except ValueError:
            return None
        ts = base_ts
        # Frigate event_ids are typically `<unix_seconds>-<random>`. Pull the
        # leading int when present so we get minute/second precision.
        leading_digits = re.match(r"^(\d{10})", event_id)
        if leading_digits is not None:
            with contextlib.suppress(OverflowError, ValueError, OSError):
                candidate = datetime.fromtimestamp(int(leading_digits.group(1)))
                # Only use it if it lines up with the date/hour folder.
                if (
                    candidate.year == base_ts.year
                    and candidate.month == base_ts.month
                    and candidate.day == base_ts.day
                    and candidate.hour == base_ts.hour
                ):
                    ts = candidate
        return self._build_event(path, cam_seg, ts, event_id=event_id)

    def _build_event(
        self, path: Path, cam: str, ts: datetime, *, event_id: str
    ) -> Event:
        metadata: dict = {
            "source": "frigate",
            "filename": path.name,
            "event_id": event_id,
            "camera": cam,
        }
        sibling_json = path.with_suffix(".json")
        if sibling_json.is_file():
            with contextlib.suppress(OSError, json.JSONDecodeError, ValueError):
                with sibling_json.open("r", encoding="utf-8") as fh:
                    payload = json.load(fh)
                if isinstance(payload, dict):
                    if "label" in payload:
                        metadata["label"] = payload["label"]
                    if "score" in payload:
                        metadata["score"] = payload["score"]
                    if "zones" in payload:
                        metadata["zones"] = payload["zones"]
        return Event(
            id=f"frigate:{cam}:{ts.strftime('%Y%m%d-%H%M%S')}",
            timestamp=ts,
            folder=path.parent,
            cams={cam: path},
            metadata=metadata,
        )
