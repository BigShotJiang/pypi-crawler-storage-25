"""Wyze Cam SD-card layout reader.

Wyze cameras (v3, v4, Pan v3, Cam OG) write to the SD card as one MP4 per
minute, organized by date and hour:

    <root>/
      YYYYMMDD/
        HH/
          MM.mp4

Each file is a single 60-second clip, single-camera. To use this with
sentrytriage, point it at the SD card mount (or a directory you've rsync'd
from the SD card or the Wyze app's local download path).

Each Event represents one minute-clip. The cam name is fixed to "wyze".
Pass `cam_alias` to the constructor if you want a friendlier label that gets
emitted as the Event.cams key (useful when triaging multiple cameras with
their footage in separate roots).
"""

from __future__ import annotations

import re
from datetime import datetime
from pathlib import Path

from .base import Event, Source

_DATE_DIR_RE = re.compile(r"^(\d{4})(\d{2})(\d{2})$")
_HOUR_DIR_RE = re.compile(r"^(\d{2})$")
_MINUTE_FILE_RE = re.compile(r"^(\d{2})\.mp4$", re.IGNORECASE)


class WyzeSource(Source):
    """Reads the canonical Wyze Cam SD-card layout."""

    def __init__(self, root: Path | str, *, cam_alias: str = "wyze"):
        self.root = Path(root).expanduser()
        self.cam_alias = cam_alias

    def discover(self) -> list[Event]:
        if not self.root.is_dir():
            return []
        events: list[Event] = []
        for date_dir in sorted(self.root.iterdir()):
            if not date_dir.is_dir():
                continue
            date_match = _DATE_DIR_RE.match(date_dir.name)
            if not date_match:
                continue
            year, month, day = (int(g) for g in date_match.groups())
            for hour_dir in sorted(date_dir.iterdir()):
                if not hour_dir.is_dir():
                    continue
                hour_match = _HOUR_DIR_RE.match(hour_dir.name)
                if not hour_match:
                    continue
                hour = int(hour_match.group(1))
                for clip in sorted(hour_dir.iterdir()):
                    if not clip.is_file():
                        continue
                    minute_match = _MINUTE_FILE_RE.match(clip.name)
                    if not minute_match:
                        continue
                    minute = int(minute_match.group(1))
                    try:
                        ts = datetime(year, month, day, hour, minute)
                    except ValueError:
                        continue
                    events.append(
                        Event(
                            id=f"wyze:{date_dir.name}-{hour:02d}{minute:02d}",
                            timestamp=ts,
                            folder=hour_dir,
                            cams={self.cam_alias: clip},
                            metadata={"source": "wyze", "minute_clip": True},
                        )
                    )
        return events

    def scan_for_new(self, after: datetime | None = None) -> list[Event]:
        events = self.discover()
        if after is None:
            return events
        return [e for e in events if e.timestamp > after]
