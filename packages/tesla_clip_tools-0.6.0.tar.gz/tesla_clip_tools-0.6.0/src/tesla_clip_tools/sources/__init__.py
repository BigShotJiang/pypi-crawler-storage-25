"""Pluggable event sources. v0.4 ships 8 plugins: Tesla, Wyze, Reolink, UniFi, Ring, Nest, Eufy, Frigate."""  # noqa: E501

from .base import Event, Source
from .eufy import EufySource
from .frigate import FrigateSource
from .nest import NestSource
from .reolink import ReolinkSource
from .ring import RingSource
from .tesla import TeslaSource
from .unifi_protect import UniFiProtectSource
from .wyze import WyzeSource

__all__ = [
    "Event",
    "Source",
    "TeslaSource",
    "WyzeSource",
    "ReolinkSource",
    "UniFiProtectSource",
    "RingSource",
    "NestSource",
    "EufySource",
    "FrigateSource",
]
