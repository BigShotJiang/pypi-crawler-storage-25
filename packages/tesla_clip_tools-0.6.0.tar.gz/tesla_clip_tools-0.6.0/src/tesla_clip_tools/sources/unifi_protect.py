"""UniFi Protect exported-clips reader.

Ubiquiti's UniFi Protect web UI exports clips with the camera name + event
type + timestamp in the filename. We accept the two most common shapes:

    <CamName>_<YYYY-MM-DD>_<HH-MM-SS>_<eventtype>.mp4
    <CamName>_<YYYY-MM-DD>_<HH-MM-SS>.mp4

The exported filename is canonically date-partitioned per UniFi's date-folder
convention; we walk subdirectories one level deep so

    <root>/
      <YYYY-MM-DD>/
        <CamName>_<YYYY-MM-DD>_<HH-MM-SS>_<eventtype>.mp4

works as well as a flat root. Each matching file becomes one Event keyed by
camera name; metadata includes the event type when present.
"""

from __future__ import annotations

import re
from datetime import datetime
from pathlib import Path

from .base import Event, Source

_PATTERN_WITH_EVENT = re.compile(
    r"^(?P<cam>[A-Za-z0-9][A-Za-z0-9 _.-]*?)_"
    r"(?P<year>\d{4})-(?P<month>\d{2})-(?P<day>\d{2})_"
    r"(?P<hour>\d{2})-(?P<minute>\d{2})-(?P<second>\d{2})_"
    r"(?P<event>[A-Za-z0-9_-]+)\.mp4$"
)
_PATTERN_NO_EVENT = re.compile(
    r"^(?P<cam>[A-Za-z0-9][A-Za-z0-9 _.-]*?)_"
    r"(?P<year>\d{4})-(?P<month>\d{2})-(?P<day>\d{2})_"
    r"(?P<hour>\d{2})-(?P<minute>\d{2})-(?P<second>\d{2})\.mp4$"
)


class UniFiProtectSource(Source):
    """Reads UniFi Protect exported clip files (flat root or 1-level dated)."""

    def __init__(self, root: Path | str):
        self.root = Path(root).expanduser()

    def discover(self) -> list[Event]:
        if not self.root.is_dir():
            return []
        events: list[Event] = []
        for path in self._iter_clip_files():
            event = self._maybe_parse(path)
            if event is not None:
                events.append(event)
        events.sort(key=lambda e: (e.timestamp, sorted(e.cams)))
        return events

    def scan_for_new(self, after: datetime | None = None) -> list[Event]:
        events = self.discover()
        if after is None:
            return events
        return [e for e in events if e.timestamp > after]

    def _iter_clip_files(self):
        # Top-level mp4s
        for child in self.root.iterdir():
            if child.is_file() and child.suffix.lower() == ".mp4":
                yield child
        # One level of subdirectories (commonly date-partitioned)
        for subdir in self.root.iterdir():
            if not subdir.is_dir():
                continue
            for child in subdir.iterdir():
                if child.is_file() and child.suffix.lower() == ".mp4":
                    yield child

    def _maybe_parse(self, path: Path) -> Event | None:
        m = _PATTERN_WITH_EVENT.match(path.name)
        event_type: str | None = None
        if m is not None:
            event_type = m.group("event")
        else:
            m = _PATTERN_NO_EVENT.match(path.name)
            if m is None:
                return None
        try:
            ts = datetime(
                int(m.group("year")),
                int(m.group("month")),
                int(m.group("day")),
                int(m.group("hour")),
                int(m.group("minute")),
                int(m.group("second")),
            )
        except ValueError:
            return None
        cam = m.group("cam")
        metadata: dict = {"source": "unifi_protect", "filename": path.name}
        if event_type:
            metadata["event_type"] = event_type
        return Event(
            id=f"unifi:{cam}:{ts.strftime('%Y%m%d-%H%M%S')}",
            timestamp=ts,
            folder=path.parent,
            cams={cam: path},
            metadata=metadata,
        )
