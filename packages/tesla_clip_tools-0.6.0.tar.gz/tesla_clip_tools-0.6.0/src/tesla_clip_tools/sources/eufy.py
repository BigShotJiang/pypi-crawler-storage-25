"""Eufy security camera exported-clips reader.

Eufy security cameras (eufyCam 2/2C/3, Indoor 2K, Doorbell Dual, etc.) export
clips via the Eufy Security app or HomeBase share. We accept the most common
shapes:

    <DeviceName>_<YYYY-MM-DD>_<HH-MM-SS>.mp4   (most common, app export)
    <DeviceName>-<YYYYMMDD>-<HHMMSS>.mp4       (alternate web UI / NAS export)
    eufy_<DeviceID>_<UnixMillis>.mp4           (HomeBase NAS-style)

Each matching file becomes one Event keyed by device name; metadata captures
`{"source": "eufy", "filename": ...}` and the device id when present.
"""

from __future__ import annotations

import re
from datetime import UTC, datetime
from pathlib import Path

from .base import Event, Source

# 1) <DeviceName>_<YYYY-MM-DD>_<HH-MM-SS>.mp4  (app export)
_PATTERN_APP = re.compile(
    r"^(?P<cam>[A-Za-z0-9][A-Za-z0-9 _.-]*?)_"
    r"(?P<year>\d{4})-(?P<month>\d{2})-(?P<day>\d{2})_"
    r"(?P<hour>\d{2})-(?P<minute>\d{2})-(?P<second>\d{2})\.mp4$"
)
# 2) <DeviceName>-<YYYYMMDD>-<HHMMSS>.mp4  (alternate web UI)
_PATTERN_WEB = re.compile(
    r"^(?P<cam>[A-Za-z0-9][A-Za-z0-9 _.]*?)-"
    r"(?P<year>\d{4})(?P<month>\d{2})(?P<day>\d{2})-"
    r"(?P<hour>\d{2})(?P<minute>\d{2})(?P<second>\d{2})\.mp4$"
)
# 3) eufy_<DeviceID>_<UnixMillis>.mp4  (HomeBase NAS-style)
_PATTERN_HOMEBASE = re.compile(
    r"^eufy_(?P<device_id>[A-Za-z0-9]+)_(?P<millis>\d{12,16})\.mp4$"
)


class EufySource(Source):
    """Reads a flat or 1-level-nested directory of Eufy-exported MP4 files."""

    def __init__(self, root: Path | str):
        self.root = Path(root).expanduser()

    def discover(self) -> list[Event]:
        if not self.root.is_dir():
            return []
        events: list[Event] = []
        for path in self._iter_clip_files():
            event = self._maybe_parse(path)
            if event is not None:
                events.append(event)
        events.sort(key=lambda e: (e.timestamp, sorted(e.cams)))
        return events

    def scan_for_new(self, after: datetime | None = None) -> list[Event]:
        events = self.discover()
        if after is None:
            return events
        return [e for e in events if e.timestamp > after]

    def _iter_clip_files(self):
        # Top-level mp4s
        for child in self.root.iterdir():
            if child.is_file() and child.suffix.lower() == ".mp4":
                yield child
        # One level of subdirectories (commonly per-device or per-day folder)
        for subdir in self.root.iterdir():
            if not subdir.is_dir():
                continue
            for child in subdir.iterdir():
                if child.is_file() and child.suffix.lower() == ".mp4":
                    yield child

    def _maybe_parse(self, path: Path) -> Event | None:
        # HomeBase / NAS-style: eufy_<DeviceID>_<UnixMillis>.mp4
        m = _PATTERN_HOMEBASE.match(path.name)
        if m is not None:
            try:
                millis = int(m.group("millis"))
                ts = datetime.fromtimestamp(
                    millis / 1000.0, tz=UTC
                ).replace(tzinfo=None)
            except (OverflowError, ValueError):
                return None
            device_id = m.group("device_id")
            return Event(
                id=f"eufy:{device_id}:{ts.strftime('%Y%m%d-%H%M%S')}",
                timestamp=ts,
                folder=path.parent,
                cams={device_id: path},
                metadata={
                    "source": "eufy",
                    "filename": path.name,
                    "device_id": device_id,
                },
            )

        # App or web UI export
        for pattern in (_PATTERN_APP, _PATTERN_WEB):
            m = pattern.match(path.name)
            if m is None:
                continue
            try:
                ts = datetime(
                    int(m.group("year")),
                    int(m.group("month")),
                    int(m.group("day")),
                    int(m.group("hour")),
                    int(m.group("minute")),
                    int(m.group("second")),
                )
            except ValueError:
                return None
            cam = m.group("cam")
            return Event(
                id=f"eufy:{cam}:{ts.strftime('%Y%m%d-%H%M%S')}",
                timestamp=ts,
                folder=path.parent,
                cams={cam: path},
                metadata={"source": "eufy", "filename": path.name},
            )
        return None
