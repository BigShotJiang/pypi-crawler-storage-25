"""Source abstraction — anything that produces multi-camera event folders."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class Event:
    """A single recorded event with one or more synchronized camera clips."""

    id: str  # stable ID, typically "<source>:<event_timestamp>"
    timestamp: datetime
    folder: Path
    cams: dict[str, Path]  # cam_name -> mp4 path
    metadata: dict[str, Any] = field(default_factory=dict)


class Source(ABC):
    """Abstract event source. Implementations: TeslaSource, WyzeSource (planned), ..."""

    @abstractmethod
    def discover(self) -> list[Event]:
        """Return all events currently in the source."""

    @abstractmethod
    def scan_for_new(self, after: datetime | None = None) -> list[Event]:
        """Return events newer than `after` (or all events if `after` is None)."""
