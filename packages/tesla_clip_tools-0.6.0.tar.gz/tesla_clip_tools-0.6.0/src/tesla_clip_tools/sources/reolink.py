"""Reolink camera/NVR exported-clips reader.

Reolink cameras and NVRs export clips with the camera name + timestamp baked
into the filename. Common shapes (which we accept):

    <CamName>_<YYYYMMDDHHMMSS>.mp4
    <CamName>_RecS<NN>_DST<YYYYMMDDHHMMSS>_<duration>_<hash>.mp4
    <CamName>_<YYYY-MM-DD>_<HH-MM-SS>.mp4

This source flattens — every matching file is one Event with `cams` keyed by
the parsed camera name. Multi-camera "events" (front + back recorded at the
same instant) aren't a Reolink primitive, so we don't try to fuse them. If
you want fused events, group by timestamp post-hoc.
"""

from __future__ import annotations

import re
from datetime import datetime
from pathlib import Path

from .base import Event, Source

# 1) <Cam>_<YYYYMMDDHHMMSS>.mp4
_PATTERN_COMPACT = re.compile(
    r"^(?P<cam>[A-Za-z0-9][A-Za-z0-9_-]*?)_"
    r"(?P<year>\d{4})(?P<month>\d{2})(?P<day>\d{2})"
    r"(?P<hour>\d{2})(?P<minute>\d{2})(?P<second>\d{2})\.mp4$"
)
# 2) <Cam>_RecS<NN>_DST<YYYYMMDDHHMMSS>_<duration>_<hash>.mp4
_PATTERN_NVR = re.compile(
    r"^(?P<cam>[A-Za-z0-9][A-Za-z0-9_-]*?)_RecS\d+_DST"
    r"(?P<year>\d{4})(?P<month>\d{2})(?P<day>\d{2})"
    r"(?P<hour>\d{2})(?P<minute>\d{2})(?P<second>\d{2})_.*\.mp4$"
)
# 3) <Cam>_<YYYY-MM-DD>_<HH-MM-SS>.mp4
_PATTERN_DASHED = re.compile(
    r"^(?P<cam>[A-Za-z0-9][A-Za-z0-9_-]*?)_"
    r"(?P<year>\d{4})-(?P<month>\d{2})-(?P<day>\d{2})_"
    r"(?P<hour>\d{2})-(?P<minute>\d{2})-(?P<second>\d{2})\.mp4$"
)
_PATTERNS = (_PATTERN_NVR, _PATTERN_COMPACT, _PATTERN_DASHED)


class ReolinkSource(Source):
    """Reads a flat directory of Reolink-exported MP4 files."""

    def __init__(self, root: Path | str):
        self.root = Path(root).expanduser()

    def discover(self) -> list[Event]:
        if not self.root.is_dir():
            return []
        events: list[Event] = []
        for child in sorted(self.root.iterdir()):
            if not child.is_file():
                continue
            event = self._maybe_parse(child)
            if event is not None:
                events.append(event)
        # Reolink exports often have multiple files per second across cameras —
        # use a stable sort by timestamp then cam name.
        events.sort(key=lambda e: (e.timestamp, sorted(e.cams)))
        return events

    def scan_for_new(self, after: datetime | None = None) -> list[Event]:
        events = self.discover()
        if after is None:
            return events
        return [e for e in events if e.timestamp > after]

    def _maybe_parse(self, path: Path) -> Event | None:
        for pattern in _PATTERNS:
            m = pattern.match(path.name)
            if m is None:
                continue
            try:
                ts = datetime(
                    int(m.group("year")),
                    int(m.group("month")),
                    int(m.group("day")),
                    int(m.group("hour")),
                    int(m.group("minute")),
                    int(m.group("second")),
                )
            except ValueError:
                return None
            cam = m.group("cam")
            return Event(
                id=f"reolink:{cam}:{ts.strftime('%Y%m%d-%H%M%S')}",
                timestamp=ts,
                folder=path.parent,
                cams={cam: path},
                metadata={"source": "reolink", "filename": path.name},
            )
        return None
