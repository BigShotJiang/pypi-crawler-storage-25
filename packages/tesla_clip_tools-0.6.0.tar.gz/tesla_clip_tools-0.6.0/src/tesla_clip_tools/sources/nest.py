"""Google Nest camera exported-clips reader.

Nest (Cam Battery, Cam Wired, Doorbell Battery, Doorbell Wired) clips
exported via the Google Home app land with two common shapes:

    <CameraName>_<UNIX_MILLIS>.mp4              (newer Google Home exports)
    <CameraName>_<YYYY-MM-DD>_<HH-MM-SS>.mp4    (older format + manual rename)

The Unix-millis path defines a tighter event_type tag when one is available
in the filename's tail (e.g., `_person`, `_doorbell`). We don't try to parse
beyond what the filename reveals — Google Home exports are notoriously sparse.
"""

from __future__ import annotations

import re
from datetime import UTC, datetime
from pathlib import Path

from .base import Event, Source

# 1) <Cam>_<UNIX_MILLIS>[_<event>].mp4
_PATTERN_MILLIS = re.compile(
    r"^(?P<cam>[A-Za-z0-9][A-Za-z0-9 _.-]*?)_"
    r"(?P<millis>\d{12,16})"
    r"(?:_(?P<event>[A-Za-z0-9_-]+))?\.mp4$"
)
# 2) <Cam>_<YYYY-MM-DD>_<HH-MM-SS>[_<event>].mp4
_PATTERN_DASHED = re.compile(
    r"^(?P<cam>[A-Za-z0-9][A-Za-z0-9 _.-]*?)_"
    r"(?P<year>\d{4})-(?P<month>\d{2})-(?P<day>\d{2})_"
    r"(?P<hour>\d{2})-(?P<minute>\d{2})-(?P<second>\d{2})"
    r"(?:_(?P<event>[A-Za-z0-9_-]+))?\.mp4$"
)


class NestSource(Source):
    """Reads a flat directory of Nest-exported MP4 files."""

    def __init__(self, root: Path | str):
        self.root = Path(root).expanduser()

    def discover(self) -> list[Event]:
        if not self.root.is_dir():
            return []
        events: list[Event] = []
        for child in sorted(self.root.iterdir()):
            if not child.is_file():
                continue
            event = self._maybe_parse(child)
            if event is not None:
                events.append(event)
        events.sort(key=lambda e: (e.timestamp, sorted(e.cams)))
        return events

    def scan_for_new(self, after: datetime | None = None) -> list[Event]:
        events = self.discover()
        if after is None:
            return events
        return [e for e in events if e.timestamp > after]

    def _maybe_parse(self, path: Path) -> Event | None:
        m = _PATTERN_MILLIS.match(path.name)
        if m is not None:
            try:
                millis = int(m.group("millis"))
            except ValueError:
                return None
            try:
                # Normalize to naive UTC for consistency with the other sources
                # (which return naive datetimes parsed from their filenames).
                ts = datetime.fromtimestamp(
                    millis / 1000.0, tz=UTC
                ).replace(tzinfo=None)
            except (OverflowError, ValueError):
                return None
            return self._build_event(path, m.group("cam"), ts, m.groupdict().get("event"))

        m = _PATTERN_DASHED.match(path.name)
        if m is not None:
            try:
                ts = datetime(
                    int(m.group("year")),
                    int(m.group("month")),
                    int(m.group("day")),
                    int(m.group("hour")),
                    int(m.group("minute")),
                    int(m.group("second")),
                )
            except ValueError:
                return None
            return self._build_event(path, m.group("cam"), ts, m.groupdict().get("event"))

        return None

    def _build_event(self, path: Path, cam: str, ts: datetime, event_type) -> Event:
        metadata: dict = {"source": "nest", "filename": path.name}
        if event_type:
            metadata["event_type"] = event_type.lower()
        return Event(
            id=f"nest:{cam}:{ts.strftime('%Y%m%d-%H%M%S')}",
            timestamp=ts,
            folder=path.parent,
            cams={cam: path},
            metadata=metadata,
        )
