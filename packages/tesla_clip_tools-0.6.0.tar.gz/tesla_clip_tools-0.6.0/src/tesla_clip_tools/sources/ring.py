"""Ring camera exported-clips reader.

Ring (Doorbell, Stick Up Cam, Floodlight Cam, Spotlight Cam) exports clips
with the device name + timestamp in the filename. We accept the most common
shapes:

    <DeviceName>_<EventType>_<YYYY-MM-DDTHH-MM-SS>.mp4   (Neighbors export)
    <DeviceName>_<YYYY-MM-DD-HH-MM-SS>.mp4               (web UI download)
    <DeviceName>_<YYYY-MM-DDTHH-MM-SSZ>.mp4              (some API exports use trailing Z)

Each matching file becomes one Event keyed by device name; metadata captures
the event type when present (`motion`, `ding`, `live_view`, etc.).
"""

from __future__ import annotations

import contextlib
import re
from datetime import datetime
from pathlib import Path

from .base import Event, Source

_PATTERN_NEIGHBORS = re.compile(
    r"^(?P<cam>[A-Za-z0-9][A-Za-z0-9 _.-]*?)_"
    r"(?P<event>motion|ding|live_view|alert|person|package|vehicle)_"
    r"(?P<year>\d{4})-(?P<month>\d{2})-(?P<day>\d{2})T"
    r"(?P<hour>\d{2})-(?P<minute>\d{2})-(?P<second>\d{2})Z?\.mp4$",
    re.IGNORECASE,
)
_PATTERN_WEB = re.compile(
    r"^(?P<cam>[A-Za-z0-9][A-Za-z0-9 _.-]*?)_"
    r"(?P<year>\d{4})-(?P<month>\d{2})-(?P<day>\d{2})-"
    r"(?P<hour>\d{2})-(?P<minute>\d{2})-(?P<second>\d{2})\.mp4$"
)
_PATTERN_T = re.compile(
    r"^(?P<cam>[A-Za-z0-9][A-Za-z0-9 _.-]*?)_"
    r"(?P<year>\d{4})-(?P<month>\d{2})-(?P<day>\d{2})T"
    r"(?P<hour>\d{2})-(?P<minute>\d{2})-(?P<second>\d{2})Z?\.mp4$"
)
# Order matters: Neighbors-with-event-type must come before T-without-event-type
# so the event-type group isn't accidentally matched as part of cam.
_PATTERNS = (_PATTERN_NEIGHBORS, _PATTERN_T, _PATTERN_WEB)


class RingSource(Source):
    """Reads a flat or 1-level-nested directory of Ring-exported MP4 files."""

    def __init__(self, root: Path | str):
        self.root = Path(root).expanduser()

    def discover(self) -> list[Event]:
        if not self.root.is_dir():
            return []
        events: list[Event] = []
        for path in self._iter_clip_files():
            event = self._maybe_parse(path)
            if event is not None:
                events.append(event)
        events.sort(key=lambda e: (e.timestamp, sorted(e.cams)))
        return events

    def scan_for_new(self, after: datetime | None = None) -> list[Event]:
        events = self.discover()
        if after is None:
            return events
        return [e for e in events if e.timestamp > after]

    def _iter_clip_files(self):
        for child in self.root.iterdir():
            if child.is_file() and child.suffix.lower() == ".mp4":
                yield child
        # one level of subdirs (commonly a per-camera or per-day folder)
        for subdir in self.root.iterdir():
            if not subdir.is_dir():
                continue
            for child in subdir.iterdir():
                if child.is_file() and child.suffix.lower() == ".mp4":
                    yield child

    def _maybe_parse(self, path: Path) -> Event | None:
        for pattern in _PATTERNS:
            m = pattern.match(path.name)
            if m is None:
                continue
            try:
                ts = datetime(
                    int(m.group("year")),
                    int(m.group("month")),
                    int(m.group("day")),
                    int(m.group("hour")),
                    int(m.group("minute")),
                    int(m.group("second")),
                )
            except ValueError:
                return None
            cam = m.group("cam")
            metadata: dict = {"source": "ring", "filename": path.name}
            with contextlib.suppress(IndexError, AttributeError):
                metadata["event_type"] = m.group("event").lower()
            return Event(
                id=f"ring:{cam}:{ts.strftime('%Y%m%d-%H%M%S')}",
                timestamp=ts,
                folder=path.parent,
                cams={cam: path},
                metadata=metadata,
            )
        return None
