"""Tesla SentryClips folder layout reader.

Layout (stable across firmware since 2018, additively grown):

    SentryClips/
      <YYYY-MM-DD_HH-MM-SS>/
        front.mp4
        back.mp4
        left_repeater.mp4
        right_repeater.mp4
        left_pillar.mp4    (HW4 only, 2025.14+)
        right_pillar.mp4   (HW4 only, 2025.14+)
        event.json         (optional Tesla metadata: reason, location, etc.)

Saved/Recent clips share the layout but live in `SavedClips/` and
`RecentClips/`. Point the source at whichever directory you want triaged.
"""

from __future__ import annotations

import json
import re
from datetime import datetime
from pathlib import Path

from .base import Event, Source

# Tesla event-folder name pattern: YYYY-MM-DD_HH-MM-SS
_EVENT_DIR_RE = re.compile(r"^(\d{4})-(\d{2})-(\d{2})_(\d{2})-(\d{2})-(\d{2})$")

# All possible camera names; pillar cams are HW4-only.
_CAM_NAMES: tuple[str, ...] = (
    "front",
    "back",
    "left_repeater",
    "right_repeater",
    "left_pillar",
    "right_pillar",
)


class TeslaSource(Source):
    """Reads the canonical TeslaCam SentryClips folder layout."""

    def __init__(self, root: Path | str):
        self.root = Path(root).expanduser()

    def discover(self) -> list[Event]:
        if not self.root.is_dir():
            return []
        events: list[Event] = []
        for child in sorted(self.root.iterdir()):
            if not child.is_dir():
                continue
            event = self._maybe_parse(child)
            if event is not None:
                events.append(event)
        return events

    def scan_for_new(self, after: datetime | None = None) -> list[Event]:
        events = self.discover()
        if after is None:
            return events
        return [e for e in events if e.timestamp > after]

    def _maybe_parse(self, folder: Path) -> Event | None:
        match = _EVENT_DIR_RE.match(folder.name)
        if match is None:
            return None
        try:
            ts = datetime(*(int(g) for g in match.groups()))
        except ValueError:
            return None

        cams: dict[str, Path] = {}
        for name in _CAM_NAMES:
            mp4 = folder / f"{name}.mp4"
            if mp4.is_file():
                cams[name] = mp4
        if not cams:
            return None  # event folder with no camera files

        metadata: dict = {}
        meta_file = folder / "event.json"
        if meta_file.is_file():
            try:
                metadata = json.loads(meta_file.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                metadata = {}

        return Event(
            id=f"tesla:{folder.name}",
            timestamp=ts,
            folder=folder,
            cams=cams,
            metadata=metadata,
        )
