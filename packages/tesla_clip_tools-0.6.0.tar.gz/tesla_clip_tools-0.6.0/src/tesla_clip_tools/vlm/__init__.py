"""Pluggable VLM backends, parameterised on a Pydantic response_format.

The OpenAI and Ollama backends are eagerly imported because their dependencies
ship with the base install. AnthropicBackend and GeminiBackend live behind
optional extras (`[anthropic]`, `[gemini]`) — import them directly from
`tesla_clip_tools.vlm.anthropic` / `.gemini` only when you've installed the
SDK; importing here would bloat the base install with two extra heavyweight
SDKs that most users won't touch.
"""

from .base import VLMBackend
from .ollama import OllamaBackend
from .openai import OpenAIBackend

__all__ = ["VLMBackend", "OpenAIBackend", "OllamaBackend"]
