"""OpenAI VLM backend (gpt-4o, gpt-4o-mini, etc.)."""

from __future__ import annotations

import base64
import io
import os
from typing import TypeVar

from openai import OpenAI
from PIL import Image
from pydantic import BaseModel

from .base import VLMBackend

T = TypeVar("T", bound=BaseModel)


class OpenAIBackend(VLMBackend):
    def __init__(
        self,
        model: str = "gpt-4o-mini",
        api_key: str | None = None,
        base_url: str | None = None,
    ):
        self.client = OpenAI(
            api_key=api_key or os.environ.get("OPENAI_API_KEY"),
            base_url=base_url,
        )
        self.model = model

    def classify(
        self,
        images: list[Image.Image],
        captions: list[str],
        system_prompt: str,
        response_format: type[T],
    ) -> T:
        if len(images) != len(captions):
            raise ValueError(
                f"images and captions must align: got {len(images)} vs {len(captions)}"
            )
        content: list[dict] = [{"type": "text", "text": "Classify this event."}]
        for img, caption in zip(images, captions, strict=True):
            content.append({"type": "text", "text": caption})
            content.append(
                {
                    "type": "image_url",
                    "image_url": {"url": _png_data_url(img)},
                }
            )

        response = self.client.beta.chat.completions.parse(
            model=self.model,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": content},
            ],
            response_format=response_format,
        )
        verdict = response.choices[0].message.parsed
        if verdict is None:
            raise RuntimeError("OpenAI returned no parsed verdict.")
        return verdict


def _png_data_url(img: Image.Image) -> str:
    buf = io.BytesIO()
    if max(img.size) > 1024:
        img = img.copy()
        img.thumbnail((1024, 1024))
    img.save(buf, format="PNG")
    return "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode("ascii")
