"""Google Gemini VLM backend (via the `google-genai` SDK).

Defaults to `gemini-2.5-flash` — the current-generation Flash model as of v0.5.
If the installed SDK rejects that name (e.g. older client pinned to 2.0), fall
back to `gemini-2.0-flash` automatically with a single retry.

Structured output uses Gemini's native `response_schema` + `response_mime_type`
mechanism, which accepts a Pydantic model directly. No tool-call workaround
needed (unlike Anthropic).

The `google-genai` SDK is lazy-imported inside `__init__` so this module stays
importable on machines that haven't installed the optional `[gemini]` extra.
"""

from __future__ import annotations

import json
import os
from typing import TypeVar

from PIL import Image as PILImage  # avoid clashing with the SDK's `types.Image`
from pydantic import BaseModel, ValidationError

from .base import VLMBackend

T = TypeVar("T", bound=BaseModel)

_FALLBACK_MODEL = "gemini-2.0-flash"


class GeminiBackend(VLMBackend):
    def __init__(
        self,
        model: str = "gemini-2.5-flash",
        api_key: str | None = None,
    ):
        # Lazy import: keeps the module importable without the SDK installed.
        try:
            from google import genai  # type: ignore[import-not-found]
        except ImportError as exc:  # pragma: no cover - exercised by test_lazy_import
            raise ImportError(
                "The 'google-genai' SDK is required for GeminiBackend. "
                "Install with: pip install 'tesla-clip-tools[gemini]'"
            ) from exc

        self.client = genai.Client(
            api_key=api_key or os.environ.get("GOOGLE_API_KEY"),
        )
        self.model = model

    def classify(
        self,
        images: list[PILImage.Image],
        captions: list[str],
        system_prompt: str,
        response_format: type[T],
    ) -> T:
        if len(images) != len(captions):
            raise ValueError(
                f"images and captions must align: got {len(images)} vs {len(captions)}"
            )

        # Gemini accepts a flat list of "parts" (text or image bytes) plus a
        # system_instruction in GenerateContentConfig. Build the parts list to
        # interleave caption text and image bytes, matching the OpenAI layout.
        from google.genai import types as genai_types  # type: ignore[import-not-found]

        parts: list[object] = [genai_types.Part.from_text(text="Classify this event.")]
        for img, caption in zip(images, captions, strict=True):
            parts.append(genai_types.Part.from_text(text=caption))
            parts.append(
                genai_types.Part.from_bytes(
                    data=_jpeg_bytes(img), mime_type="image/jpeg"
                )
            )

        config = genai_types.GenerateContentConfig(
            system_instruction=system_prompt,
            response_mime_type="application/json",
            response_schema=response_format,
        )

        try:
            response = self.client.models.generate_content(
                model=self.model,
                contents=parts,
                config=config,
            )
        except Exception as exc:
            # Single retry on the v2.0 fallback if the requested model name was
            # rejected. Anything else (auth, quota, timeouts) bubbles unchanged.
            if self.model != _FALLBACK_MODEL and _looks_like_unknown_model(exc):
                response = self.client.models.generate_content(
                    model=_FALLBACK_MODEL,
                    contents=parts,
                    config=config,
                )
            else:
                raise

        return _parse_response(response, response_format)


def _parse_response[U: BaseModel](response, response_format: type[U]) -> U:
    """Extract a parsed Pydantic instance from a Gemini response.

    Prefers the SDK's `.parsed` attribute when present (it returns the schema
    instance directly); falls back to JSON-decoding `.text` if the SDK is on
    an older shape that only emits raw text.
    """
    parsed = getattr(response, "parsed", None)
    if parsed is not None:
        if isinstance(parsed, response_format):
            return parsed
        # Some SDK versions return a dict here; coerce through model_validate.
        if isinstance(parsed, dict):
            try:
                return response_format.model_validate(parsed)
            except ValidationError as exc:
                raise RuntimeError(
                    f"Gemini parsed payload failed schema validation: {exc}"
                ) from exc

    text = getattr(response, "text", None)
    if not text:
        raise RuntimeError("Gemini returned an empty response.")
    try:
        data = json.loads(text)
    except json.JSONDecodeError as exc:
        raise RuntimeError(
            f"Gemini returned non-JSON content: {text[:200]!r}"
        ) from exc
    try:
        return response_format.model_validate(data)
    except ValidationError as exc:
        raise RuntimeError(
            f"Gemini response failed schema validation: {exc}"
        ) from exc


def _looks_like_unknown_model(exc: Exception) -> bool:
    """Heuristic: did Gemini reject the model name itself (vs a real failure)?

    The google-genai SDK doesn't expose a typed "model not found" exception, so
    we sniff the message. Conservative — only the obvious phrasings count.
    """
    msg = str(exc).lower()
    return any(
        phrase in msg
        for phrase in (
            "model not found",
            "is not found",
            "no such model",
            "unknown model",
            "not supported",
            "does not exist",
        )
    )


def _jpeg_bytes(img: PILImage.Image) -> bytes:
    """JPEG-encode `img` (downscaled to 1024px) so it fits Gemini's inline-data
    payload budget without round-tripping through base64 strings."""
    import io

    if max(img.size) > 1024:
        img = img.copy()
        img.thumbnail((1024, 1024))
    if img.mode in ("RGBA", "LA", "P"):
        background = PILImage.new("RGB", img.size, (0, 0, 0))
        if img.mode == "P":
            img = img.convert("RGBA")
        background.paste(img, mask=img.split()[-1] if img.mode == "RGBA" else None)
        img = background
    elif img.mode != "RGB":
        img = img.convert("RGB")
    buf = io.BytesIO()
    img.save(buf, format="JPEG", quality=85)
    return buf.getvalue()
