"""Anthropic (Claude) VLM backend.

Defaults to `claude-sonnet-4-6` — the latest Sonnet line as of v0.5. Anthropic
doesn't yet ship a native structured-output endpoint, so we use the tools API:
we expose a single tool whose input_schema mirrors the consumer's Pydantic
`response_format`, and the model "calls" that tool. We then parse the tool
input back into the Pydantic class.

The `anthropic` SDK is lazy-imported inside `__init__` so this module stays
importable on machines that haven't installed the optional `[anthropic]` extra.
"""

from __future__ import annotations

import base64
import io
import json
import os
from typing import TypeVar

from PIL import Image
from pydantic import BaseModel, ValidationError

from .base import VLMBackend

T = TypeVar("T", bound=BaseModel)

# Single deterministic name for the structured-output tool. The model is told
# (via system prompt + tool_choice) that it MUST emit this tool call.
_TOOL_NAME = "record_classification"
_TOOL_DESCRIPTION = (
    "Record the structured classification verdict for the supplied event. "
    "You must call this tool exactly once with arguments that match the schema."
)


class AnthropicBackend(VLMBackend):
    def __init__(
        self,
        model: str = "claude-sonnet-4-6",
        api_key: str | None = None,
        max_tokens: int = 1024,
    ):
        # Lazy import: keeps the module importable without the SDK installed.
        try:
            import anthropic  # type: ignore[import-not-found]
        except ImportError as exc:  # pragma: no cover - exercised by test_lazy_import
            raise ImportError(
                "The 'anthropic' SDK is required for AnthropicBackend. "
                "Install with: pip install 'tesla-clip-tools[anthropic]'"
            ) from exc

        self.client = anthropic.Anthropic(
            api_key=api_key or os.environ.get("ANTHROPIC_API_KEY"),
        )
        self.model = model
        self.max_tokens = max_tokens

    def classify(
        self,
        images: list[Image.Image],
        captions: list[str],
        system_prompt: str,
        response_format: type[T],
    ) -> T:
        if len(images) != len(captions):
            raise ValueError(
                f"images and captions must align: got {len(images)} vs {len(captions)}"
            )

        content: list[dict] = [{"type": "text", "text": "Classify this event."}]
        for img, caption in zip(images, captions, strict=True):
            content.append({"type": "text", "text": caption})
            content.append(
                {
                    "type": "image",
                    "source": {
                        "type": "base64",
                        "media_type": "image/jpeg",
                        "data": _b64_jpeg(img),
                    },
                }
            )

        tool_schema = response_format.model_json_schema()

        response = self.client.messages.create(
            model=self.model,
            max_tokens=self.max_tokens,
            system=system_prompt,
            tools=[
                {
                    "name": _TOOL_NAME,
                    "description": _TOOL_DESCRIPTION,
                    "input_schema": tool_schema,
                }
            ],
            tool_choice={"type": "tool", "name": _TOOL_NAME},
            messages=[{"role": "user", "content": content}],
        )

        # Find the tool_use block — Anthropic returns a list of content blocks.
        tool_input = _extract_tool_input(response, _TOOL_NAME)
        if tool_input is None:
            raise RuntimeError(
                f"Anthropic returned no tool_use block for tool {_TOOL_NAME!r}."
            )
        try:
            return response_format.model_validate(tool_input)
        except ValidationError as exc:
            raise RuntimeError(
                f"Anthropic tool input failed schema validation: {exc}"
            ) from exc


def _extract_tool_input(response, tool_name: str) -> dict | None:
    """Pull the tool's `input` dict out of a Messages API response.

    Tolerates both the SDK object form (`response.content[i].type == "tool_use"`)
    and a stringified JSON arguments payload, since some Anthropic SDK versions
    serialise `input` as a JSON string instead of a dict.
    """
    blocks = getattr(response, "content", None) or []
    for block in blocks:
        block_type = getattr(block, "type", None) or (
            block.get("type") if isinstance(block, dict) else None
        )
        if block_type != "tool_use":
            continue
        block_name = getattr(block, "name", None) or (
            block.get("name") if isinstance(block, dict) else None
        )
        if block_name != tool_name:
            continue
        block_input = getattr(block, "input", None)
        if block_input is None and isinstance(block, dict):
            block_input = block.get("input")
        if isinstance(block_input, str):
            try:
                return json.loads(block_input)
            except json.JSONDecodeError as exc:
                raise RuntimeError(
                    f"Anthropic tool_use input was a string but not valid JSON: {exc}"
                ) from exc
        if isinstance(block_input, dict):
            return block_input
    return None


def _b64_jpeg(img: Image.Image) -> str:
    """Return a base64-encoded JPEG of `img`, downscaled to fit 1024x1024.

    JPEG keeps the request payload small — Anthropic charges per image-size band
    and the OpenAI/Ollama backends already downscale to 1024px. RGBA inputs are
    flattened on a black background since JPEG can't carry transparency.
    """
    if max(img.size) > 1024:
        img = img.copy()
        img.thumbnail((1024, 1024))
    if img.mode in ("RGBA", "LA", "P"):
        # JPEG can't encode alpha — flatten onto black to match the OpenAI
        # PNG path's visual output as closely as possible.
        background = Image.new("RGB", img.size, (0, 0, 0))
        if img.mode == "P":
            img = img.convert("RGBA")
        background.paste(img, mask=img.split()[-1] if img.mode == "RGBA" else None)
        img = background
    elif img.mode != "RGB":
        img = img.convert("RGB")
    buf = io.BytesIO()
    img.save(buf, format="JPEG", quality=85)
    return base64.b64encode(buf.getvalue()).decode("ascii")
