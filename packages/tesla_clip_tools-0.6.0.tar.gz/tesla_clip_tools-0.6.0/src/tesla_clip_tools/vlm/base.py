"""Generic VLM backend interface.

Each consumer (sentrytriage, FSD-Disengagement Studio, ...) supplies its own
Pydantic `response_format` so the same backend can produce arbitrary verdict
shapes without forking.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TypeVar

from PIL import Image
from pydantic import BaseModel

T = TypeVar("T", bound=BaseModel)


class VLMBackend(ABC):
    @abstractmethod
    def classify(
        self,
        images: list[Image.Image],
        captions: list[str],
        system_prompt: str,
        response_format: type[T],
    ) -> T:
        """Send images + per-image captions and return a parsed Pydantic instance."""
