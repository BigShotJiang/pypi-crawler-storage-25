"""Ollama VLM backend (Qwen2.5-VL, Llama-3.2-Vision, MiniCPM-V).

Defaults to qwen2.5vl:7b — best small-VLM accuracy in May 2026 per the v2
local_llm_stack deep-dive. Requires Ollama 0.4+ for `format` accepting a full
JSON schema.
"""

from __future__ import annotations

import base64
import io
import json
import os
from typing import TypeVar

import httpx
from PIL import Image
from pydantic import BaseModel

from .base import VLMBackend

T = TypeVar("T", bound=BaseModel)


class OllamaBackend(VLMBackend):
    def __init__(self, model: str = "qwen2.5vl:7b", host: str | None = None):
        self.host = (
            host or os.environ.get("OLLAMA_HOST") or "http://localhost:11434"
        ).rstrip("/")
        self.model = model

    def classify(
        self,
        images: list[Image.Image],
        captions: list[str],
        system_prompt: str,
        response_format: type[T],
    ) -> T:
        if len(images) != len(captions):
            raise ValueError(
                f"images and captions must align: got {len(images)} vs {len(captions)}"
            )
        prompt = "Classify this event.\n\n" + "\n".join(captions)
        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {
                    "role": "user",
                    "content": prompt,
                    "images": [_b64_png(img) for img in images],
                },
            ],
            "format": response_format.model_json_schema(),
            "stream": False,
            "options": {"temperature": 0.1},
        }
        try:
            r = httpx.post(f"{self.host}/api/chat", json=payload, timeout=120)
            r.raise_for_status()
        except httpx.HTTPError as exc:
            raise RuntimeError(f"Ollama request failed: {exc}") from exc

        body = r.json()
        content = body.get("message", {}).get("content", "")
        try:
            data = json.loads(content)
        except json.JSONDecodeError as exc:
            raise RuntimeError(
                f"Ollama returned non-JSON content: {content[:200]!r}"
            ) from exc
        return response_format.model_validate(data)


def _b64_png(img: Image.Image) -> str:
    if max(img.size) > 1024:
        img = img.copy()
        img.thumbnail((1024, 1024))
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return base64.b64encode(buf.getvalue()).decode("ascii")
