"""Frame sampler — uses imageio[ffmpeg]'s bundled ffmpeg binary so end users
don't need a system-wide ffmpeg install for the read path.
"""

from __future__ import annotations

from pathlib import Path
from typing import NamedTuple

import imageio.v3 as iio
from PIL import Image


class Sample(NamedTuple):
    cam: str
    timestamp_seconds: float
    image: Image.Image


def sample_keyframes(
    cam_paths: dict[str, Path],
    n_per_cam: int = 4,
) -> list[Sample]:
    """Extract `n_per_cam` evenly-spaced frames from each camera clip.

    Streams each clip exactly once, retaining only the requested frames.
    """
    samples: list[Sample] = []
    for cam, path in cam_paths.items():
        try:
            meta = iio.immeta(str(path), plugin="FFMPEG")
        except Exception:  # noqa: BLE001
            continue

        fps = float(meta.get("fps") or 0.0)
        duration = float(meta.get("duration") or 0.0)
        if fps <= 0 or duration <= 0:
            continue

        target_indices = sorted(
            min(int(ts * fps), int(duration * fps) - 1)
            for ts in _evenly_spaced(duration, n_per_cam)
        )
        if not target_indices:
            continue

        wanted = set(target_indices)
        max_idx = max(target_indices)
        try:
            for i, frame in enumerate(iio.imiter(str(path), plugin="FFMPEG")):
                if i in wanted:
                    samples.append(
                        Sample(
                            cam=cam,
                            timestamp_seconds=i / fps,
                            image=Image.fromarray(frame),
                        )
                    )
                if i >= max_idx:
                    break
        except Exception:  # noqa: BLE001
            continue
    return samples


def _evenly_spaced(duration: float, n: int) -> list[float]:
    if n <= 0 or duration <= 0:
        return []
    if n == 1:
        return [duration / 2]
    step = duration / (n + 1)
    return [step * (i + 1) for i in range(n)]
