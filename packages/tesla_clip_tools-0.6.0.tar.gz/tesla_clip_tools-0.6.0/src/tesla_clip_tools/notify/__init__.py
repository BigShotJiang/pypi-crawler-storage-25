"""Notification backends. Pushover, Telegram, Discord, and SMTP email."""

from .base import Notifier, NotifyError
from .discord import DiscordNotifier
from .email_smtp import EmailNotifier
from .pushover import PushoverNotifier
from .telegram import TelegramNotifier

__all__ = [
    "Notifier",
    "NotifyError",
    "PushoverNotifier",
    "TelegramNotifier",
    "DiscordNotifier",
    "EmailNotifier",
]
