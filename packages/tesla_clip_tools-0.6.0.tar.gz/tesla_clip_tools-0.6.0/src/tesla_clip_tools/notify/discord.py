"""Discord webhook notifier.

Set `DISCORD_WEBHOOK_URL` to the full webhook URL from a Discord channel's
Integrations -> Webhooks page (looks like
``https://discord.com/api/webhooks/<id>/<token>``).

Webhooks need no bot token, no OAuth, and no scopes — they're the easiest
thing in the Discord product. Free for personal use.
"""

from __future__ import annotations

import json
import os
from pathlib import Path

import httpx

from .base import Notifier, NotifyError

# Discord caps embed `description` at 4096 chars. Trim with a marker so users
# at least know the body was truncated rather than silently dropped.
_DISCORD_DESCRIPTION_LIMIT = 4096
_TRUNCATED_MARKER = "\n…(truncated)"

# Discord caps `content` at 2000 chars. We use it as the message title, so
# this would have to be a *very* long category string to ever trip — but we
# defend against it anyway.
_DISCORD_CONTENT_LIMIT = 2000


class DiscordNotifier(Notifier):
    """Posts to a Discord channel via an incoming webhook URL."""

    def __init__(self, webhook_url: str | None = None):
        self.webhook_url = webhook_url or os.environ.get("DISCORD_WEBHOOK_URL")
        if not self.webhook_url:
            raise NotifyError(
                "Discord requires DISCORD_WEBHOOK_URL "
                "(env var or constructor arg). "
                "Get one from a channel's Integrations -> Webhooks page."
            )

    def send(self, title: str, body: str, attachment: Path | None = None) -> None:
        payload: dict = {
            "content": _truncate(title, _DISCORD_CONTENT_LIMIT),
            "embeds": [{"description": _truncate(body, _DISCORD_DESCRIPTION_LIMIT)}],
        }
        if attachment is not None and attachment.is_file():
            self._post_with_attachment(payload, attachment)
            return
        self._post_json(payload)

    def _post_json(self, payload: dict) -> None:
        try:
            r = httpx.post(self.webhook_url, json=payload, timeout=30)
            r.raise_for_status()
        except httpx.HTTPError as exc:
            raise NotifyError(f"Discord webhook POST failed: {exc}") from exc

    def _post_with_attachment(self, payload: dict, attachment: Path) -> None:
        # Discord wants multipart/form-data: a `payload_json` field with the
        # JSON body, plus one or more `files[N]` fields with the binary data.
        # The webhook returns 200 if either the embed or the file makes it.
        try:
            with attachment.open("rb") as fp:
                files = {
                    "files[0]": (attachment.name, fp, _guess_mime(attachment)),
                }
                data = {"payload_json": json.dumps(payload)}
                r = httpx.post(
                    self.webhook_url, data=data, files=files, timeout=120
                )
                r.raise_for_status()
        except httpx.HTTPError as exc:
            raise NotifyError(f"Discord webhook upload failed: {exc}") from exc


def _truncate(text: str, limit: int) -> str:
    if len(text) <= limit:
        return text
    return text[: limit - len(_TRUNCATED_MARKER)] + _TRUNCATED_MARKER


_MIME_BY_SUFFIX = {
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".png": "image/png",
    ".gif": "image/gif",
    ".webp": "image/webp",
    ".mp4": "video/mp4",
    ".mov": "video/quicktime",
    ".webm": "video/webm",
    ".m4v": "video/mp4",
}


def _guess_mime(path: Path) -> str:
    return _MIME_BY_SUFFIX.get(path.suffix.lower(), "application/octet-stream")
