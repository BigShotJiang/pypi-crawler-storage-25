"""SMTP email notifier (named ``email_smtp`` to avoid shadowing stdlib ``email``).

Reads from the environment::

    SMTP_HOST       (required)   SMTP server, e.g. smtp.gmail.com
    SMTP_PORT       (default 587) 587 = STARTTLS, 465 = implicit SSL
    SMTP_USER       (required)   login username
    SMTP_PASSWORD   (required)   login password (or app-specific password)
    EMAIL_FROM      (required)   "Display Name <addr@example.com>" or just an addr
    EMAIL_TO        (required)   one or more recipients, comma-separated

Uses only stdlib (``smtplib`` + ``email.message.EmailMessage``) so this adds
zero dependencies.
"""

from __future__ import annotations

import mimetypes
import os
import smtplib
import ssl
from email.message import EmailMessage
from pathlib import Path

from .base import Notifier, NotifyError

# 465 is implicit-TLS (SMTPS). Everything else uses STARTTLS by convention.
_IMPLICIT_TLS_PORT = 465


class EmailNotifier(Notifier):
    """Sends notifications over SMTP. TLS-on-by-default."""

    def __init__(
        self,
        host: str | None = None,
        port: int | None = None,
        user: str | None = None,
        password: str | None = None,
        sender: str | None = None,
        recipients: str | list[str] | None = None,
    ):
        self.host = host or os.environ.get("SMTP_HOST")
        self.port = port if port is not None else int(os.environ.get("SMTP_PORT", "587"))
        self.user = user or os.environ.get("SMTP_USER")
        self.password = password or os.environ.get("SMTP_PASSWORD")
        self.sender = sender or os.environ.get("EMAIL_FROM")
        recipients_raw = recipients if recipients is not None else os.environ.get("EMAIL_TO")
        self.recipients = _parse_recipients(recipients_raw)

        missing = [
            name
            for name, value in [
                ("SMTP_HOST", self.host),
                ("SMTP_USER", self.user),
                ("SMTP_PASSWORD", self.password),
                ("EMAIL_FROM", self.sender),
                ("EMAIL_TO", self.recipients),
            ]
            if not value
        ]
        if missing:
            raise NotifyError(
                "Email notifier missing required settings: "
                f"{', '.join(missing)} "
                "(set as env vars or pass to EmailNotifier())."
            )

    def send(self, title: str, body: str, attachment: Path | None = None) -> None:
        msg = EmailMessage()
        msg["Subject"] = title
        msg["From"] = self.sender
        msg["To"] = ", ".join(self.recipients)
        msg.set_content(body)

        if attachment is not None and attachment.is_file():
            _attach_file(msg, attachment)

        try:
            self._send_message(msg)
        except (smtplib.SMTPException, OSError) as exc:
            # OSError catches the connection-refused / DNS-failure case.
            raise NotifyError(f"Email send failed: {exc}") from exc

    def _send_message(self, msg: EmailMessage) -> None:
        if self.port == _IMPLICIT_TLS_PORT:
            context = ssl.create_default_context()
            with smtplib.SMTP_SSL(self.host, self.port, timeout=30, context=context) as smtp:
                smtp.login(self.user, self.password)
                smtp.send_message(msg)
            return
        # Default path: STARTTLS on 587 (or any non-465 port).
        with smtplib.SMTP(self.host, self.port, timeout=30) as smtp:
            smtp.starttls(context=ssl.create_default_context())
            smtp.login(self.user, self.password)
            smtp.send_message(msg)


def _parse_recipients(raw: str | list[str] | None) -> list[str]:
    if raw is None:
        return []
    if isinstance(raw, list):
        return [r.strip() for r in raw if r and r.strip()]
    return [r.strip() for r in raw.split(",") if r.strip()]


def _attach_file(msg: EmailMessage, attachment: Path) -> None:
    ctype, _ = mimetypes.guess_type(attachment.name)
    if ctype is None:
        maintype, subtype = "application", "octet-stream"
    else:
        maintype, subtype = ctype.split("/", 1)
    msg.add_attachment(
        attachment.read_bytes(),
        maintype=maintype,
        subtype=subtype,
        filename=attachment.name,
    )
