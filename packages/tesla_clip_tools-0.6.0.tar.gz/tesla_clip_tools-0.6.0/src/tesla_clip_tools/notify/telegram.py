"""Telegram bot notifier.

Set TELEGRAM_BOT_TOKEN (from @BotFather) and TELEGRAM_CHAT_ID (your user id or
group id where the bot is a member).
"""

from __future__ import annotations

import os
from pathlib import Path

import httpx

from .base import Notifier, NotifyError

_VIDEO_SUFFIXES = {".mp4", ".mov", ".webm", ".m4v"}
_PHOTO_SUFFIXES = {".jpg", ".jpeg", ".png", ".gif"}


class TelegramNotifier(Notifier):
    def __init__(self, bot_token: str | None = None, chat_id: str | None = None):
        self.bot_token = bot_token or os.environ.get("TELEGRAM_BOT_TOKEN")
        self.chat_id = chat_id or os.environ.get("TELEGRAM_CHAT_ID")
        if not self.bot_token or not self.chat_id:
            raise NotifyError(
                "Telegram requires TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID."
            )
        self._base = f"https://api.telegram.org/bot{self.bot_token}"

    def send(self, title: str, body: str, attachment: Path | None = None) -> None:
        text = f"<b>{title}</b>\n{body}"
        if attachment is not None and attachment.is_file():
            suffix = attachment.suffix.lower()
            if suffix in _VIDEO_SUFFIXES:
                self._send_video(attachment, text)
                return
            if suffix in _PHOTO_SUFFIXES:
                self._send_photo(attachment, text)
                return
        self._send_text(text)

    def _send_text(self, text: str) -> None:
        try:
            r = httpx.post(
                f"{self._base}/sendMessage",
                data={"chat_id": self.chat_id, "text": text, "parse_mode": "HTML"},
                timeout=30,
            )
            r.raise_for_status()
        except httpx.HTTPError as exc:
            raise NotifyError(f"Telegram sendMessage failed: {exc}") from exc

    def _send_photo(self, attachment: Path, caption: str) -> None:
        try:
            with attachment.open("rb") as fp:
                r = httpx.post(
                    f"{self._base}/sendPhoto",
                    data={"chat_id": self.chat_id, "caption": caption, "parse_mode": "HTML"},
                    files={"photo": (attachment.name, fp)},
                    timeout=60,
                )
                r.raise_for_status()
        except httpx.HTTPError as exc:
            raise NotifyError(f"Telegram sendPhoto failed: {exc}") from exc

    def _send_video(self, attachment: Path, caption: str) -> None:
        try:
            with attachment.open("rb") as fp:
                r = httpx.post(
                    f"{self._base}/sendVideo",
                    data={"chat_id": self.chat_id, "caption": caption, "parse_mode": "HTML"},
                    files={"video": (attachment.name, fp)},
                    timeout=120,
                )
                r.raise_for_status()
        except httpx.HTTPError as exc:
            raise NotifyError(f"Telegram sendVideo failed: {exc}") from exc
