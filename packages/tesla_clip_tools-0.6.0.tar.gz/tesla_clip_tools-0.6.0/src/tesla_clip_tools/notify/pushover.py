"""Pushover notifier.

Set PUSHOVER_TOKEN (your application token) and PUSHOVER_USER (your user key)
or pass them in directly. Free tier is 10k messages/month per app.
"""

from __future__ import annotations

import os
from pathlib import Path

import httpx

from .base import Notifier, NotifyError


class PushoverNotifier(Notifier):
    URL = "https://api.pushover.net/1/messages.json"

    def __init__(self, token: str | None = None, user: str | None = None):
        self.token = token or os.environ.get("PUSHOVER_TOKEN")
        self.user = user or os.environ.get("PUSHOVER_USER")
        if not self.token or not self.user:
            raise NotifyError(
                "Pushover requires PUSHOVER_TOKEN and PUSHOVER_USER (env vars or constructor args)."
            )

    def send(self, title: str, body: str, attachment: Path | None = None) -> None:
        data = {
            "token": self.token,
            "user": self.user,
            "title": title,
            "message": body,
        }
        files = None
        if (
            attachment is not None
            and attachment.is_file()
            and attachment.suffix.lower() in {".jpg", ".jpeg", ".png", ".gif"}
        ):
            files = {"attachment": (attachment.name, attachment.open("rb"))}
        try:
            r = httpx.post(self.URL, data=data, files=files, timeout=30)
            r.raise_for_status()
        except httpx.HTTPError as exc:
            raise NotifyError(f"Pushover send failed: {exc}") from exc
        finally:
            if files is not None:
                files["attachment"][1].close()
