"""Abstract notification interface."""

from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path


class NotifyError(RuntimeError):
    """Notifier failed to deliver — credentials missing or upstream rejected."""


class Notifier(ABC):
    @abstractmethod
    def send(
        self,
        title: str,
        body: str,
        attachment: Path | None = None,
    ) -> None:
        """Send a notification. `attachment` may be an image (.png/.jpg) or a video (.mp4)."""
