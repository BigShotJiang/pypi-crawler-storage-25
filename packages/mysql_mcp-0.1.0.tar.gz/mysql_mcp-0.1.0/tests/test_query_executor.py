# tests/test_query_executor.py
import pytest
from unittest.mock import MagicMock, patch
from mysql_mcp.query_executor import QueryExecutor
from mysql_mcp.connection_manager import ConnectionManager
from mysql_mcp.config_loader import DatasourceConfig, Config, QueryConfig

@pytest.fixture
def sample_config():
    return Config(
        datasources={
            "prod": DatasourceConfig(
                host="localhost",
                port=3306,
                user="root",
                password="secret",
                database="test",
                pool_size=2,
                pool_name="prod_pool"
            )
        },
        query=QueryConfig(default_timeout=30, max_rows=1000)
    )

def test_execute_query_success(sample_config):
    mock_cursor = MagicMock()
    mock_cursor.fetchall.return_value = [(1, "Alice")]
    mock_cursor.description = [("id",), ("name",)]

    mock_pool = MagicMock()
    mock_conn = MagicMock()
    mock_conn.cursor.return_value = mock_cursor
    mock_pool.get_connection.return_value = mock_conn

    with patch.object(ConnectionManager, "__init__", lambda self, config: None):
        with patch.object(ConnectionManager, "get_pool", return_value=mock_pool):
            manager = ConnectionManager(sample_config)
            manager.config = sample_config
            executor = QueryExecutor(manager, sample_config.query)

            result = executor.execute("SELECT * FROM users", datasource="prod", format="json")

            assert result["columns"] == ["id", "name"]
            assert result["rows"] == [(1, "Alice")]
            assert result["row_count"] == 1

def test_execute_with_params(sample_config):
    mock_cursor = MagicMock()
    mock_cursor.fetchall.return_value = [(1, "Alice")]
    mock_cursor.description = [("id",), ("name",)]

    mock_pool = MagicMock()
    mock_conn = MagicMock()
    mock_conn.cursor.return_value = mock_cursor
    mock_pool.get_connection.return_value = mock_conn

    with patch.object(ConnectionManager, "__init__", lambda self, config: None):
        with patch.object(ConnectionManager, "get_pool", return_value=mock_pool):
            manager = ConnectionManager(sample_config)
            executor = QueryExecutor(manager, sample_config.query)

            result = executor.execute(
                "SELECT * FROM users WHERE id = %s",
                datasource="prod",
                params=(1,),
                format="json"
            )

            mock_cursor.execute.assert_called_once()
            call_args = mock_cursor.execute.call_args
            assert call_args[0][1] == (1,)

def test_execute_unknown_datasource(sample_config):
    with patch.object(ConnectionManager, "__init__", lambda self, config: None):
        manager = ConnectionManager(sample_config)
        manager.config = sample_config
        executor = QueryExecutor(manager, sample_config.query)

        with pytest.raises(ValueError, match="Datasource not found: unknown"):
            executor.execute("SELECT 1", datasource="unknown")
