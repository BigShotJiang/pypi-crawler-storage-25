# tests/test_connection_manager.py
import pytest
from unittest.mock import MagicMock, patch
from mysql_mcp.connection_manager import ConnectionManager
from mysql_mcp.config_loader import DatasourceConfig, Config, QueryConfig

@pytest.fixture
def sample_config():
    return Config(
        datasources={
            "prod": DatasourceConfig(
                host="localhost",
                port=3306,
                user="root",
                password="secret",
                database="test",
                pool_size=2,
                pool_name="prod_pool"
            )
        },
        query=QueryConfig(default_timeout=30, max_rows=1000)
    )

def test_get_pool_creates_pool(sample_config):
    mock_pool = MagicMock()
    with patch("mysql.connector.pooling.MySQLConnectionPool", return_value=mock_pool):
        manager = ConnectionManager(sample_config)
        pool = manager.get_pool("prod")

        assert pool is mock_pool

def test_get_pool_unknown_datasource(sample_config):
    manager = ConnectionManager(sample_config)

    with pytest.raises(ValueError, match="Datasource not found: unknown"):
        manager.get_pool("unknown")

def test_list_datasources(sample_config):
    manager = ConnectionManager(sample_config)
    datasources = manager.list_datasources()

    assert len(datasources) == 1
    assert datasources[0]["name"] == "prod"
