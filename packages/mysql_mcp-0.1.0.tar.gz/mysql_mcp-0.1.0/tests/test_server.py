# tests/test_server.py
import pytest
from unittest.mock import MagicMock, patch
from mysql_mcp.server import MySQLMCPServer

def test_list_datasources_tool():
    mock_manager = MagicMock()
    mock_manager.list_datasources.return_value = [
        {"name": "prod", "host": "localhost", "database": "test"}
    ]

    mock_config = MagicMock()
    mock_config.query.default_timeout = 30

    with patch("mysql_mcp.server.ConfigLoader") as mock_loader:
        with patch("mysql_mcp.server.ConnectionManager", return_value=mock_manager):
            mock_loader.return_value.load.return_value = mock_config

            server = MySQLMCPServer(config_path="config.yaml")
            result = server.list_datasources()

            assert len(result["datasources"]) == 1
            assert result["datasources"][0]["name"] == "prod"
