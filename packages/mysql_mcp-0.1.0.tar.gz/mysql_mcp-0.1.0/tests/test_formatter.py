# tests/test_formatter.py
import pytest
from mysql_mcp.formatter import ResultFormatter

def test_format_json():
    formatter = ResultFormatter()
    columns = ["id", "name"]
    rows = [[1, "Alice"], [2, "Bob"]]

    result = formatter.format(columns, rows, "json")

    assert result["columns"] == ["id", "name"]
    assert result["rows"] == [[1, "Alice"], [2, "Bob"]]
    assert result["row_count"] == 2

def test_format_table():
    formatter = ResultFormatter()
    columns = ["id", "name"]
    rows = [[1, "Alice"], [2, "Bob"]]

    result = formatter.format(columns, rows, "table")

    assert "+----+" in result
    assert "| id | name  |" in result
    assert "| 1  | Alice |" in result
    assert "| 2  | Bob   |" in result
