# tests/test_integration.py
import pytest
import yaml
from mysql_mcp.config_loader import ConfigLoader
from mysql_mcp.connection_manager import ConnectionManager
from mysql_mcp.query_executor import QueryExecutor
from mysql_mcp.formatter import ResultFormatter

def test_config_to_executor_integration(tmp_path):
    config_data = {
        "datasources": {
            "test": {
                "host": "localhost",
                "port": 3306,
                "user": "root",
                "password": "test",
                "database": "test",
                "pool_size": 1
            }
        },
        "query": {
            "default_timeout": 10,
            "max_rows": 100
        }
    }
    config_file = tmp_path / "config.yaml"
    config_file.write_text(yaml.dump(config_data))

    config = ConfigLoader(str(config_file)).load()
    formatter = ResultFormatter()

    assert config.datasources["test"].host == "localhost"
    assert config.query.max_rows == 100
    assert formatter.format(["a"], [[1]], "json")["row_count"] == 1
