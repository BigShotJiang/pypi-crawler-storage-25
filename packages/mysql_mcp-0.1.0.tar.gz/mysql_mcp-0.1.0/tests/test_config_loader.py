# tests/test_config_loader.py
import pytest
import yaml
from mysql_mcp.config_loader import ConfigLoader

def test_load_config_success(tmp_path):
    config_data = {
        "datasources": {
            "prod": {
                "host": "localhost",
                "port": 3306,
                "user": "root",
                "password": "secret",
                "database": "test"
            }
        }
    }
    config_file = tmp_path / "config.yaml"
    config_file.write_text(yaml.dump(config_data))

    loader = ConfigLoader(str(config_file))
    config = loader.load()

    assert "prod" in config.datasources
    assert config.datasources["prod"].host == "localhost"
    assert config.datasources["prod"].port == 3306

def test_load_config_file_not_found():
    with pytest.raises(FileNotFoundError):
        ConfigLoader("/nonexistent/config.yaml").load()


def test_load_config_expands_environment_variables(tmp_path, monkeypatch):
    monkeypatch.setenv("MYSQL_PASSWORD", "from-env")
    config_data = {
        "datasources": {
            "prod": {
                "host": "localhost",
                "port": 3306,
                "user": "root",
                "password": "${MYSQL_PASSWORD}",
                "database": "test",
            }
        }
    }
    config_file = tmp_path / "config.yaml"
    config_file.write_text(yaml.dump(config_data))

    config = ConfigLoader(str(config_file)).load()

    assert config.datasources["prod"].password == "from-env"
