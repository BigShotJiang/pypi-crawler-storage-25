from typing import Any, Dict, List


class ResultFormatter:
    def format(
        self, columns: List[str], rows: List[List[Any]], format_type: str = "json"
    ) -> Dict | str:
        if format_type == "json":
            return self._format_json(columns, rows)
        if format_type == "table":
            return self._format_table(columns, rows)
        raise ValueError(f"Unknown format type: {format_type}")

    def _format_json(self, columns: List[str], rows: List[List[Any]]) -> Dict:
        return {
            "columns": columns,
            "rows": rows,
            "row_count": len(rows),
        }

    def _format_table(self, columns: List[str], rows: List[List[Any]]) -> str:
        lines = []

        col_widths = [len(col) for col in columns]
        for row in rows:
            for i, val in enumerate(row):
                col_widths[i] = max(col_widths[i], len(str(val)))

        def format_row(values: List[Any], widths: List[int]) -> str:
            cells = [str(v).ljust(w) for v, w in zip(values, widths)]
            return "| " + " | ".join(cells) + " |"

        separator = "+" + "+".join("-" * (w + 2) for w in col_widths) + "+"

        lines.append(separator)
        lines.append(format_row(columns, col_widths))
        lines.append(separator)

        for row in rows:
            lines.append(format_row(row, col_widths))

        lines.append(separator)

        return "\n".join(lines)
