from typing import Any, Dict, List

import mcp.server.stdio
from mcp.server import Server
from mcp.types import TextContent, Tool

from mysql_mcp.config_loader import ConfigLoader
from mysql_mcp.connection_manager import ConnectionManager
from mysql_mcp.query_executor import QueryExecutor


class MySQLMCPServer:
    def __init__(self, config_path: str):
        self.config = ConfigLoader(config_path).load()
        self.connection_manager = ConnectionManager(self.config)
        self.query_executor = QueryExecutor(self.connection_manager, self.config.query)
        self.server = Server("mysql-mcp")

        self._register_tools()

    def _register_tools(self):
        @self.server.list_tools()
        async def list_tools() -> List[Tool]:
            return [
                Tool(
                    name="query_mysql",
                    description="Execute a read-only SQL query on a MySQL datasource",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "datasource": {
                                "type": "string",
                                "description": "Name of the datasource from config",
                            },
                            "query": {
                                "type": "string",
                                "description": "SQL query to execute",
                            },
                            "params": {
                                "type": "array",
                                "description": "Query parameters",
                                "items": {"type": "string"},
                            },
                            "format": {
                                "type": "string",
                                "description": "Output format: json or table",
                                "enum": ["json", "table"],
                                "default": "json",
                            },
                        },
                        "required": ["datasource", "query"],
                    },
                ),
                Tool(
                    name="list_datasources",
                    description="List all configured MySQL datasources",
                    inputSchema={"type": "object", "properties": {}},
                ),
            ]

        @self.server.call_tool()
        async def call_tool(name: str, arguments: Dict[str, Any]) -> List[TextContent]:
            if name == "query_mysql":
                result = self.query_executor.execute(
                    query=arguments["query"],
                    datasource=arguments["datasource"],
                    params=tuple(arguments.get("params", [])),
                    format=arguments.get("format", "json"),
                )
                return [TextContent(type="text", text=str(result))]

            if name == "list_datasources":
                datasources = self.connection_manager.list_datasources()
                return [TextContent(type="text", text=str({"datasources": datasources}))]

            raise ValueError(f"Unknown tool: {name}")

    def list_datasources(self) -> Dict:
        datasources = self.connection_manager.list_datasources()
        return {"datasources": datasources}

    async def run(self):
        async with mcp.server.stdio.stdio_server() as (read_stream, write_stream):
            await self.server.run(
                read_stream,
                write_stream,
                self.server.create_initialization_options(),
            )


async def main():
    import sys

    config_path = sys.argv[1] if len(sys.argv) > 1 else "config.yaml"
    server = MySQLMCPServer(config_path)
    await server.run()


def run():
    import asyncio

    asyncio.run(main())


if __name__ == "__main__":
    run()
