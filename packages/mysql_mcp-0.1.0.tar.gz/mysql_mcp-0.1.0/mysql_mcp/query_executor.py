from typing import Dict, Optional, Union

from mysql_mcp.connection_manager import ConnectionManager
from mysql_mcp.config_loader import QueryConfig
from mysql_mcp.formatter import ResultFormatter


class QueryExecutor:
    def __init__(self, connection_manager: ConnectionManager, query_config: QueryConfig):
        self.connection_manager = connection_manager
        self.query_config = query_config
        self.formatter = ResultFormatter()

    def execute(
        self,
        query: str,
        datasource: str,
        params: Optional[tuple] = None,
        format: str = "json",
    ) -> Union[Dict, str]:
        try:
            pool = self.connection_manager.get_pool(datasource)
        except ValueError as e:
            raise e

        conn = pool.get_connection()
        cursor = conn.cursor()

        try:
            cursor.execute(query, params or ())

            columns = [desc[0] for desc in cursor.description] if cursor.description else []
            rows = cursor.fetchall()

            if len(rows) > self.query_config.max_rows:
                rows = rows[: self.query_config.max_rows]

            return self.formatter.format(columns, rows, format)

        finally:
            cursor.close()
            conn.close()
