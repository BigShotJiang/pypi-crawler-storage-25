from typing import Dict, List

from mysql.connector import pooling

from mysql_mcp.config_loader import Config


class ConnectionManager:
    def __init__(self, config: Config):
        self.config = config
        self._pools: Dict[str, pooling.MySQLConnectionPool] = {}

    def get_pool(self, name: str) -> pooling.MySQLConnectionPool:
        if name not in self.config.datasources:
            raise ValueError(f"Datasource not found: {name}")

        if name not in self._pools:
            ds_config = self.config.datasources[name]
            pool = pooling.MySQLConnectionPool(
                pool_name=ds_config.pool_name,
                pool_size=ds_config.pool_size,
                host=ds_config.host,
                port=ds_config.port,
                user=ds_config.user,
                password=ds_config.password,
                database=ds_config.database,
            )
            self._pools[name] = pool

        return self._pools[name]

    def list_datasources(self) -> List[Dict]:
        result = []
        for name, ds_config in self.config.datasources.items():
            result.append(
                {
                    "name": name,
                    "host": ds_config.host,
                    "database": ds_config.database,
                }
            )
        return result
