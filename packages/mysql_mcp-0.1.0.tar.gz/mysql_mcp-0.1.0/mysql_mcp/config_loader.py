import os
from dataclasses import dataclass
from typing import Dict

import yaml


@dataclass
class DatasourceConfig:
    host: str
    port: int
    user: str
    password: str
    database: str
    pool_size: int = 5
    pool_name: str = ""


@dataclass
class QueryConfig:
    default_timeout: int = 30
    max_rows: int = 10000


@dataclass
class Config:
    datasources: Dict[str, DatasourceConfig]
    query: QueryConfig


class ConfigLoader:
    def __init__(self, config_path: str):
        self.config_path = config_path

    def load(self) -> Config:
        with open(self.config_path, "r", encoding="utf-8") as f:
            data = self._expand_env_vars(yaml.safe_load(f))

        datasources = {}
        for name, ds_data in data.get("datasources", {}).items():
            datasources[name] = DatasourceConfig(
                host=ds_data["host"],
                port=ds_data["port"],
                user=ds_data["user"],
                password=ds_data["password"],
                database=ds_data["database"],
                pool_size=ds_data.get("pool_size", 5),
                pool_name=ds_data.get("pool_name", f"{name}_pool"),
            )

        query_data = data.get("query", {})
        query_config = QueryConfig(
            default_timeout=query_data.get("default_timeout", 30),
            max_rows=query_data.get("max_rows", 10000),
        )

        return Config(datasources=datasources, query=query_config)

    def _expand_env_vars(self, value):
        if isinstance(value, dict):
            return {k: self._expand_env_vars(v) for k, v in value.items()}
        if isinstance(value, list):
            return [self._expand_env_vars(item) for item in value]
        if isinstance(value, str):
            return os.path.expandvars(value)
        return value
