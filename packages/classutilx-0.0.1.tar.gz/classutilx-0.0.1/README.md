# Class utilities

The noneclass is a class doing nothing.
PyType is a Python implementation of type.
The ObjectLink is an object linking system.
