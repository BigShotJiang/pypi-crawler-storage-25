import copy
import warnings

class ObjectLink:
    """An object link"""

    def __init__(self, source, target, expression, code, globals_=None, locals_=None):
        self.expression = expression
        self.source = source
        self.target = target
        self.code = code

        # real globals (leakback enabled)
        self.globals = globals_ if globals_ is not None else globals()

        # shared locals (persistent + leakback)
        self.locals = locals_ if locals_ is not None else {}

    @property
    def result(self):
        """The expression result"""

        # inject/update dynamic values each run
        self.locals["source"] = self.source
        self.locals["target"] = self.target

        try:
            # execute with shared state and capture warnings
            with warnings.catch_warnings(record=True) as caught:
                warnings.simplefilter("always")  # catch all warnings
                exec(self.code, self.globals, self.locals)

                # automatically convert any DeprecationWarning to RuntimeWarning
                for w in caught:
                    if issubclass(w.category, DeprecationWarning):
                        warnings.warn(
                            f"Dubious deprecated behavior detected: {w.message}",
                            RuntimeWarning,
                            stacklevel=9999999999999999999
                        )

            # evaluate expression in same persistent state
            return eval(self.expression, self.globals, self.locals)

        except Exception as e:
            raise ObjectLinkExecutionError(e)

        except Warning as w:
            raise ObjectLinkWarning(w)


class ObjectLinkError(Exception):
    """Base class for exceptions related to object links."""
    def __init__(self, *args):
        super().__init__(*args)

class ObjectLinkExecutionError(ObjectLinkError):
    """Base class for exceptions occurred while execution of object links."""
    def __init__(self, *args):
        super().__init__(*args)

class ObjectLinkWarning(Warning):
    """Base class for warnings generated in object links and related to them"""
    def __init__(self, *args):
        super().__init__(*args)





