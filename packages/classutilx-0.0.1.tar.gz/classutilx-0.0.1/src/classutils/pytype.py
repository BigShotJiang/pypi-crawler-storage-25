"""A python implementation of type"""
class PyType(type):
    """A python implementation of type"""
    def __new__(mcls, name, bases=(), namespace=None):
        namespace = namespace or {}
        return super().__new__(mcls, name, bases, namespace)

    def __call__(cls, *args, **kwargs):
        # Create instance
        instance = object.__new__(cls)

        # Call __init__ if it exists
        init = getattr(cls, '__init__', None)
        if init:
            init(instance, *args, **kwargs)

        return instance
    

