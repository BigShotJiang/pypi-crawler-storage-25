"""A class that does nothings"""
class NoneClass:
    """A class that does nothing"""
    def __new__(cls):
        pass
