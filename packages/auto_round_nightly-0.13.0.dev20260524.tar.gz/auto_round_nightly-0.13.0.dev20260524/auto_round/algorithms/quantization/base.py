# Copyright (c) 2026 Intel Corporation
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
import importlib
import traceback
from collections import defaultdict
from typing import Union

import torch

from auto_round.algorithms.quantization.config import QuantizationConfig
from auto_round.algorithms.quantization.utils import register_act_max_hooks
from auto_round.compressors.utils import (
    block_forward,
    immediate_pack,
)
from auto_round.data_type import QUANT_FUNC_WITH_DTYPE
from auto_round.logger import logger
from auto_round.utils import (
    INNER_SUPPORTED_LAYER_TYPES,
    SUPPORTED_LAYER_TYPES,
    check_to_quantized,
    clear_memory,
    compile_func,
    convert_module_to_hp_if_necessary,
    get_module,
    set_module,
)
from auto_round.wrapper import WrapperLinear


class BaseQuantizers:
    # Class-level attribute declarations for convenient access in quantization methods.
    # Scheme-related attrs (layer_config, scale_dtype, has_qlayer_outside_block, etc.)
    # are resolved by SchemeMixin in BaseCompressor and synced here after post_init().
    model_context = None
    compress_context = None
    dataset = None
    supported_types = SUPPORTED_LAYER_TYPES
    inner_supported_types = INNER_SUPPORTED_LAYER_TYPES
    enable_alg_ext = False
    # Subclasses that support diffusion models should override this with the
    # appropriate output key mapping, e.g.:
    #   DIFFUSION_OUTPUT_CONFIGS = {"FluxTransformerBlock": ["encoder_hidden_states", "hidden_states"]}
    DIFFUSION_OUTPUT_CONFIGS: dict = {
        "FluxTransformerBlock": ["encoder_hidden_states", "hidden_states"],
        "FluxSingleTransformerBlock": ["encoder_hidden_states", "hidden_states"],
        "OvisImageTransformerBlock": ["encoder_hidden_states", "hidden_states"],
        "OvisImageSingleTransformerBlock": ["encoder_hidden_states", "hidden_states"],
        "StableAudioDiTBlock": ["hidden_states"],
        "WanTransformerBlock": ["hidden_states"],
    }

    def __init__(self, config: QuantizationConfig):
        self.config = config
        self.layer_config = None
        self.bits = config.bits
        self.group_size = config.group_size
        self.sym = config.sym
        self.data_type = config.data_type
        self.act_bits = config.act_bits
        self.act_group_size = config.act_group_size
        self.act_sym = config.act_sym
        self.act_data_type = config.act_data_type
        self.act_dynamic = config.act_dynamic
        self.super_bits = config.super_bits
        self.super_group_size = config.super_group_size
        self.scale_dtype = config.scale_dtype
        self.ignore_layers = config.ignore_layers
        self.quant_lm_head = config.quant_lm_head
        self.to_quant_block_names = config.to_quant_block_names
        # Calibration-time state lives on a shared
        # :class:`~auto_round.calibration.state.CalibrationState` instance.
        # The compressor wires its own instance here in ``_resolve_scheme``;
        # until then we own a private placeholder so property-based reads /
        # writes during construction don't blow up.
        from auto_round.calibration.state import CalibrationState

        self._calibration_state = CalibrationState()
        self.infer_bs_coeff = getattr(config, "infer_bs_coeff", 1)
        # Whether to feed quantized-block outputs as inputs to the next block.
        # Subclasses that support cascaded quantized-input (e.g. SignRoundQuantizer)
        # override this from their config.  Defaults to False for zero-shot algorithms
        # (RTN) where activations are not used during weight optimization.
        self.enable_quanted_input = getattr(config, "enable_quanted_input", False)

    # ── Shared CalibrationState forwarders ───────────────────────────────────────
    @property
    def calibration_state(self):
        return self._calibration_state

    @calibration_state.setter
    def calibration_state(self, new_state) -> None:
        # Compressor-supplied shared instance; just rebind.
        self._calibration_state = new_state

    @property
    def attention_mask(self) -> list:
        return self._calibration_state.attention_mask

    @attention_mask.setter
    def attention_mask(self, value) -> None:
        self._calibration_state.attention_mask = value if value is not None else []

    @property
    def batch_dim(self):
        return self._calibration_state.batch_dim

    @batch_dim.setter
    def batch_dim(self, value) -> None:
        self._calibration_state.batch_dim = value

    @property
    def batch_size(self) -> int:
        return self._calibration_state.batch_size

    @batch_size.setter
    def batch_size(self, value) -> None:
        self._calibration_state.batch_size = value

    @property
    def nsamples(self) -> int:
        return self._calibration_state.nsamples

    @property
    def seqlen(self) -> int:
        return self._calibration_state.seqlen

    @classmethod
    def from_config(cls, config: QuantizationConfig):
        if cls.__name__ == config._alg_cls:
            return cls(config)
        else:
            module = importlib.import_module("auto_round.algorithms.quantization")
            alg_cls = getattr(module, config._alg_cls)
            return alg_cls(config)

    def bind(self, compressor) -> None:
        """Wire shared state from the owning compressor.

        The compressor owns the authoritative ``model_context`` /
        ``compress_context`` / ``CalibrationState`` and resolves
        ``scale_dtype`` (string → torch dtype).  All quantizer fields that
        merely mirror the compressor are pulled from here in one place.
        """
        self.model_context = compressor.model_context
        self.compress_context = compressor.compress_context
        self.scale_dtype = compressor.scale_dtype
        # Share the compressor's CalibrationState instance.
        self._calibration_state = compressor._calibration_state

    @property
    def model(self):
        return self.model_context.model if self.model_context is not None else None

    @property
    def formats(self):
        return getattr(self.compress_context, "formats", None)

    @property
    def amp(self):
        return getattr(self.model_context, "amp", False)

    @property
    def amp_dtype(self):
        import torch

        return getattr(self.model_context, "amp_dtype", torch.float32)

    def register_calibration_hooks(self, model, *, act_max: bool = True, imatrix: bool = True):
        return register_act_max_hooks(self, model) if act_max else []

    @torch.inference_mode()
    def _quantize_embedding_layer(self):
        """Quantizes embedding layers in the model according to the configuration.

        This method iterates through all modules in the model, identifies embedding
        layers specified in `self.quantizer.layer_config`, and applies the appropriate quantization
        function based on bit precision, grouping strategy, and dtype.

        Returns:
            bool: True if the quantization process completes without critical errors.
        """
        is_quantized = False
        for name, module in self.model_context.model.named_modules():
            # Skip non-Embedding modules or layers not in config
            if not isinstance(module, torch.nn.Embedding) or name not in self.layer_config:
                continue

            config = self.layer_config[name]

            # Skip layers that are not marked for quantization
            if not check_to_quantized(config):
                continue
            is_quantized = True
            config["scale_dtype"] = self.scale_dtype
            dtype = config["data_type"]

            # Determine quantization function key with symmetry/asymmetry
            if dtype not in QUANT_FUNC_WITH_DTYPE:
                dtype = f"{dtype}_{'sym' if config['sym'] else 'asym'}"

            quant_func = QUANT_FUNC_WITH_DTYPE[dtype]
            dtype = module.weight.dtype
            # As typically float32 are used in RTN to search scale zp,
            # to avoid cache a bf16 copy we'd better use float32
            if config.get("super_group_size", None) is not None:
                dtype = torch.float32

            # Attempt quantization on GPU, fall back to CPU if OOM
            try:
                weight, scale, zp = quant_func(
                    module.weight.to(dtype=dtype, device=self.compress_context.device),
                    **{
                        k: config.get(k, None)
                        for k in ["bits", "group_size", "super_bits", "super_group_size", "scale_dtype"]
                    },
                )
            except torch.OutOfMemoryError:
                cuda_error_msg = traceback.format_exc()
                try:
                    logger.error(cuda_error_msg)
                    logger.warning("falling back to CPU")
                    weight, scale, zp = quant_func(
                        module.weight.to("cpu"),
                        **{
                            k: config.get(k, None)
                            for k in ["bits", "group_size", "super_bits", "super_group_size", "scale_dtype"]
                        },
                    )
                except Exception as e:
                    raise

            # Overwrite the module's weights with the quantized version
            module.weight.data.copy_(weight.cpu())

            # Attach scale and zero point (zp) to the module
            for param_name, value in zip(["scale", "zp"], [scale, zp]):
                if isinstance(value, dict):
                    for k, v in value.items():
                        setattr(module, k if k == "scale" else f"w_{k}", v.cpu())
                elif isinstance(value, torch.Tensor):
                    setattr(module, param_name, value.cpu())
                else:
                    setattr(module, param_name, value)

            # Update config
            self.layer_config.setdefault(name, {}).update(config)
            del weight
            del scale
            del zp
            clear_memory(device_list=self.compress_context.device_list)

        return is_quantized

    def quantize_block(
        self, block: torch.nn.Module, input_ids=None, input_others=None, reference_output=None, **kwargs
    ) -> dict:
        """Apply the quantization algorithm to a prepared block.

        This is the **pure-algorithm** entry point called by the Compressor after
        all infrastructure work (device placement, data collection, act-max hook
        registration, DDP setup) has been completed.

        Implementations should:
        - Perform the algorithm-specific weight/activation quantization on ``block``.
        - Return a dict of best parameters (may be empty for zero-shot algorithms).

        Args:
            block: Module already placed on the correct device(s).
            input_ids: Calibration inputs on cache_device (None for zero-shot RTN).
            input_others: Additional inputs (None for zero-shot RTN).
            reference_output: FP reference outputs collected by Compressor
                (None for algorithms that don't need a reconstruction loss).
            **kwargs: Algorithm-specific keyword arguments (e.g. ``loss_device``,
                ``card_0_in_high_risk`` for SignRoundQuantizer).

        Returns:
            dict: Best quantization parameters found, or ``{}`` if not applicable.
        """
        raise NotImplementedError("quantize_block must be implemented in subclasses of BaseQuantizers")

    @torch.no_grad()
    def quantize_layer_via_rtn(self, layer_name: str, disable_opt_rtn: bool | None = None) -> None:
        """Quantize one layer with RTN and handle optional immediate pack/save."""
        layer = get_module(self.model, layer_name)
        layer = convert_module_to_hp_if_necessary(layer, self.model_context.amp_dtype, self.compress_context.device)
        set_module(self.model, layer_name, layer)
        tuning_device = layer.tuning_device if hasattr(layer, "tuning_device") else self.compress_context.device
        if (
            self.compress_context.is_immediate_packing
            and self.compress_context.formats[0].is_gguf()
            and not getattr(self.config, "disable_opt_rtn", False)
        ):
            layer = layer.to(tuning_device)
            layer.scale = None
            layer.zp = None
        else:
            try:
                if disable_opt_rtn is None:
                    disable_opt_rtn = bool(getattr(self.config, "disable_opt_rtn", False))
                if (
                    not disable_opt_rtn
                    and getattr(self.config, "orig_disable_opt_rtn", None) is None
                    and self.model_context.is_moe_model
                    and "expert" in layer.global_name
                    and "shared_expert" not in layer.global_name
                    and self.config.super_bits is None
                ):
                    disable_opt_rtn = True
                    logger.warning_once(
                        "MoE layer detected: optimized RTN is disabled for efficiency. "
                        "Use `--enable_opt_rtn` to force-enable it for MoE layers."
                    )
                layer = layer.to(tuning_device)
                layer = WrapperLinear(
                    layer,
                    device=tuning_device,
                    enable_minmax_tuning=False,
                    enable_norm_bias_tuning=False,
                    enable_round_tuning=False,
                    enable_torch_compile=self.compress_context.enable_torch_compile,
                    disable_opt_rtn=disable_opt_rtn,
                    iters=0,
                )
                layer = layer.unwrapper({})
            except torch.OutOfMemoryError:
                cuda_error_msg = traceback.format_exc()
                layer = layer.orig_layer if hasattr(layer, "orig_layer") else layer
                try:
                    logger.error(cuda_error_msg)
                    logger.warning("falling back to CPU.")
                    layer.to("cpu")
                    layer = WrapperLinear(
                        layer,
                        enable_minmax_tuning=False,
                        enable_norm_bias_tuning=False,
                        enable_round_tuning=False,
                        enable_torch_compile=self.compress_context.enable_torch_compile,
                        iters=0,
                    )
                    layer = layer.unwrapper({})
                except Exception:
                    raise

        set_module(self.model, layer_name, layer)
        self._immediate_pack_and_save_module(layer_name)

    def _immediate_pack_and_save_module(self, module_name):
        from auto_round.compressors.shard_writer import ShardWriter

        shard_writer = ShardWriter.get_shard_writer()
        to_cpu = self.compress_context.low_gpu_mem_usage
        module = get_module(self.model, module_name)
        if self.compress_context.is_immediate_packing:
            immediate_pack(module_name, self.layer_config)
            if to_cpu:
                module = module.to("cpu")
                packed_module = get_module(self.model, module_name)
                set_module(self.model, module_name, packed_module.to("cpu"))
        else:
            if to_cpu:
                module = module.to("cpu")
            set_module(self.model, module_name, module)
        if self.compress_context.is_immediate_saving:
            module = get_module(self.model, module_name)
            module.to("cpu")
            shard_writer.write(module, module_name, False)
            module.to("meta")

    def quantize_layer(self, layer_name: str, **kwargs):
        """Quantizes a single layer of the model.

        Args:
            layer_name (str): The name of the layer to quantize. The layer module is
                retrieved internally via get_module(model, layer_name).
        """
        raise NotImplementedError("quantize_layer must be implemented in subclasses of BaseQuantizers")

    def quantize_layer_outside_block(self, layer_name: str, input_ids=None, **kwargs):
        """Quantizes a single layer of the model outside of a block.

        Args:
            layer_name (str): The name of the layer to quantize. The layer module is
                retrieved internally via get_module(model, layer_name).
            input_ids: Optional calibration inputs for data-driven outside-layer quantization.
        """
        dtype = kwargs.pop("dtype", None)
        if dtype is not None:
            layer = get_module(self.model, layer_name)
            set_module(self.model, layer_name, layer.to(dtype))
        self.quantize_layer_via_rtn(layer_name, **kwargs)

    @torch.no_grad()
    def _get_block_outputs(
        self,
        block: torch.nn.Module,
        input_ids,
        input_others,
        bs: int,
        save_output: bool = True,
        device_override: Union[torch.device, str, None] = None,
    ):
        """Compute the output of a block for calibration inputs.

        Shared by SignRoundQuantizer and OptimizedRTNQuantizer.  Algorithm-specific
        block-forward selection (compile vs. plain) is handled here based on
        ``enable_alg_ext`` and act-quantization flags.

        Args:
            device_override: Override the target device.  Used by diffusion with
                multi-device dispatch to pass None so block_forward uses the block's
                current device instead of forcing a specific device.
        """
        diffusion_fn = getattr(self, "_get_diffusion_block_outputs", None)
        if getattr(self.model_context, "is_diffusion", False):
            device = device_override if device_override is not None else self.compress_context.device
            return self._get_diffusion_block_outputs(
                block,
                input_ids,
                input_others,
                bs,
                device,
                self.compress_context.cache_device,
            )

        _bf = self._resolve_block_forward()

        output = []
        nsamples = len(input_ids)
        for i in range(0, nsamples, bs):
            end_index = min(nsamples, i + bs)
            indices = torch.arange(i, end_index).to(torch.long)
            tmp_input_ids, tmp_input_others = self._sampling_inputs(
                input_ids,
                input_others,
                indices,
                self.seqlen,
                self.batch_dim,
                share_cache_keys=self.model_context.shared_cache_keys,
            )
            tmp_output = _bf(
                block,
                tmp_input_ids,
                tmp_input_others,
                self.model_context.amp,
                self.model_context.amp_dtype,
                self.compress_context.device,
            ).to(self.compress_context.cache_device)
            if save_output:
                if self.batch_size == 1:
                    output.append(tmp_output)
                else:
                    output.extend(list(torch.split(tmp_output, 1, dim=self.batch_dim)))
        self.compress_context.clear_memory()

        return output

    def _resolve_block_forward(self):
        """Resolve and cache the block forward function once.

        This avoids repeated attribute checks in the hot training loop
        (called thousands of times per block).

        Mirrors old-arch behaviour: act-quant hooks, alg-ext, and optimized RTN
        use the plain ``block_forward`` instead of ``torch.compile``.
        """
        cached = self.__dict__.get("_resolved_block_forward")
        if cached is not None:
            return cached
        if (
            (self.config.is_act_quantize and (not self.config.act_dynamic or self.config.is_act_nv_fp))
            or self.enable_alg_ext
            or not getattr(self.config, "disable_opt_rtn", True)
        ):
            self._resolved_block_forward = block_forward
        elif self.compress_context.enable_torch_compile:
            compiled = self.__dict__.get("_compiled_block_forward")
            if compiled is None:
                compiled = compile_func(block_forward, self.compress_context.device)
                self._compiled_block_forward = compiled
            self._resolved_block_forward = compiled
        else:
            self._resolved_block_forward = block_forward
        return self._resolved_block_forward

    def _invalidate_block_forward_cache(self):
        """Clear the cached block forward function (call when block changes)."""
        self.__dict__.pop("_resolved_block_forward", None)
        self.__dict__.pop("_compiled_block_forward", None)

    def _get_current_q_output(
        self,
        block: torch.nn.Module,
        input_ids,
        input_others: dict,
        indices,
        device,
        cache_device: str = "cpu",
    ) -> torch.Tensor:
        """Compute block output for a mini-batch selected by *indices* (used during training).

        Handles both LLM and diffusion model block formats.  Uses the compiled
        block_forward when enable_torch_compile is True (same as _get_block_outputs),
        matching old-arch behavior where self.block_forward was compiled at init.
        """
        current_input_ids, current_input_others = self._sampling_inputs(
            input_ids,
            input_others,
            indices,
            seqlen=self.seqlen,
            batch_dim=self.batch_dim,
            share_cache_keys=self.model_context.shared_cache_keys,
        )
        _bf = self._resolve_block_forward()

        if getattr(self.model_context, "is_diffusion", False):
            output_config = self.DIFFUSION_OUTPUT_CONFIGS.get(block.__class__.__name__, ["hidden_states"])
            idx = None if "hidden_states" not in output_config else output_config.index("hidden_states")
            if isinstance(current_input_ids, dict):
                hidden_states = current_input_ids.pop("hidden_states")
                current_input_others.update(current_input_ids)
                current_input_ids = hidden_states
            output_q = _bf(
                block,
                current_input_ids,
                current_input_others,
                self.model_context.amp,
                self.model_context.amp_dtype,
                device,
                idx,
            )
        else:
            output_q = _bf(
                block,
                current_input_ids,
                current_input_others,
                self.model_context.amp,
                self.model_context.amp_dtype,
                device,
            )
        return output_q.to(cache_device)

    @classmethod
    @torch.no_grad()
    def _sampling_inputs(
        cls,
        input_ids: Union[list[torch.Tensor], dict],
        input_others: dict,
        indices,
        seqlen: int,
        batch_dim: int = 0,
        share_cache_keys: tuple = (),
    ):
        """Sample a mini-batch of calibration inputs by indices.

        Shared by SignRoundQuantizer and OptimizedRTNQuantizer.
        """
        if isinstance(input_ids, list):
            current_input_ids = [input_ids[i] for i in indices]
            current_input_ids = torch.cat(current_input_ids, dim=batch_dim)
        elif isinstance(input_ids, dict):
            current_input_ids = defaultdict(list)
            for k in input_ids.keys():
                current_input_ids[k].extend([input_ids[k][i] for i in indices])
                current_input_ids[k] = torch.cat(current_input_ids[k], dim=batch_dim)

        current_input_others = {"positional_inputs": input_others["positional_inputs"]}
        for key in input_others.keys():
            if "positional_inputs" in key:
                continue
            if key in share_cache_keys:
                # Shared keys are stored once (not per-sample), often wrapped in a
                # 1-element list by the caching hook.  Unwrap so the model receives
                # the raw value (e.g. (cos, sin) tuple, not [(cos, sin)]).
                # Exception: if the hook detected that the "shared" key actually varies
                # per sample (e.g. position_embeddings in a VLM visual encoder), it
                # upgrades the storage to a per-sample list with >1 elements.
                val = input_others[key]
                if isinstance(val, list) and len(val) == 1:
                    current_input_others[key] = val[0]
                elif isinstance(val, list) and len(val) > 1:
                    # Per-sample storage for a nominally-shared key that varies across
                    # calibration samples (e.g. position_embeddings in Qwen2-VL visual
                    # encoder blocks where each image has a different patch count).
                    idx = int(indices[0]) if len(indices) == 1 else 0
                    current_input_others[key] = val[idx] if idx < len(val) else val[0]
                else:
                    current_input_others[key] = val
            elif not isinstance(input_others[key], (str, bool, type(None))):
                current_input_others[key] = None
                if input_others[key] is not None:
                    current_input_others[key] = [input_others[key][i] for i in indices]
                    if len(indices) == 1:
                        current_input_others[key] = current_input_others[key][0]
                    else:
                        try:
                            current_input_others[key] = torch.cat(current_input_others[key], dim=0)
                        except TypeError as err:
                            logger.warning_once("Please check the model cache inputs or try setting batch_size to 1.")
            else:
                current_input_others[key] = input_others[key]

        return current_input_ids, current_input_others

    @torch.no_grad()
    def _get_diffusion_block_outputs(
        self,
        block: torch.nn.Module,
        input_ids: Union[torch.Tensor, dict],
        input_others,
        bs: int,
        device: Union[str, torch.device],
        cache_device: Union[str, torch.device],
        save_output: bool = True,
    ):
        """Compute block outputs for diffusion models.

        Uses ``self.DIFFUSION_OUTPUT_CONFIGS`` to map block class names to their
        output keys.  Subclasses override ``DIFFUSION_OUTPUT_CONFIGS`` to add
        support for new diffusion architectures.
        """
        output = defaultdict(list)
        output_config = self.DIFFUSION_OUTPUT_CONFIGS.get(block.__class__.__name__, ["hidden_states"])
        if isinstance(input_ids, dict):
            nsamples = len(input_ids["hidden_states"])
        else:
            nsamples = len(input_ids)

        for i in range(0, nsamples, bs):
            end_index = min(nsamples, i + bs)
            indices = torch.arange(i, end_index).to(torch.long)
            tmp_input_ids, tmp_input_others = self._sampling_inputs(
                input_ids,
                input_others,
                indices,
                self.seqlen,
                self.batch_dim,
                share_cache_keys=self.model_context.shared_cache_keys,
            )
            if isinstance(tmp_input_ids, dict):
                hidden_states = tmp_input_ids.pop("hidden_states")
                tmp_input_others.update(tmp_input_ids)
                tmp_input_ids = hidden_states

            tmp_output = block_forward(
                block,
                tmp_input_ids,
                tmp_input_others,
                self.model_context.amp,
                self.model_context.amp_dtype,
                device,
                None,
            )
            if isinstance(tmp_output, torch.Tensor):
                tmp_output = [tmp_output]
            assert len(output_config) == len(tmp_output)
            tmp_output = dict(zip(output_config, tmp_output))

            if save_output:
                for name, out in tmp_output.items():
                    if self.batch_size == 1:
                        output[name].append(out.to(cache_device))
                    else:
                        output[name].extend(list(torch.split(out.to(cache_device), 1, dim=self.batch_dim)))
        self.compress_context.clear_memory()

        return output
