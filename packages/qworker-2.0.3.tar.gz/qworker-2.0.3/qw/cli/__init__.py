"""QWorker CLI subcommand package."""
