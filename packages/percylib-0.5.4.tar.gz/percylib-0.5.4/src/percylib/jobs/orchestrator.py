from __future__ import annotations

from collections.abc import Generator
from typing import Any, Generic, cast

from pydantic import BaseModel

from percylib.external.models import (
    BatchStartedEvent,
    BatchStartJobEventVariant,
    ConfigFileLocation,
    JobBatchInfo,
    JobBatchProgress,
    JobCompletedEvent,
    JobCompleteJobEventVariant,
    JobEvent,
    JobFailureResult,
    JobFailureResultVariant,
    JobPersistenceConfig,
    JobStartedEvent,
    JobStartJobEventVariant,
    JobSuccessResult,
    JobSuccessResultVariant,
    JsonValue,
)
from percylib.jobs import (
    BaseEventSink,
    BaseJobExecutor,
    BaseJobLoader,
    BaseJobPersister,
    JobT,
    OutputT,
)


def _to_json_value(value: Any) -> JsonValue:
    """Convert a generic value to a JSON-compatible value for events."""
    if isinstance(value, BaseModel):
        return cast(JsonValue, value.model_dump())
    return cast(JsonValue, value)


class DefaultJobOrchestrator(Generic[JobT, OutputT]):
    """Orchestrates job execution, yielding events as jobs are processed.

    Pops pending jobs from the persister, executes each one via the
    executor, and persists the result.  A :class:`JobEvent` is yielded
    for every lifecycle transition (batch start, job start, job complete).

    If an *event_sink* is provided, each event is also published there.
    """

    def __init__(
        self,
        *,
        id: str,
        display_name: str | None = None,
        description: str | None = None,
        persistence: JobPersistenceConfig | None = None,
        config: ConfigFileLocation | None = None,
        persister: BaseJobPersister[JobT, OutputT],
        executor: BaseJobExecutor[JobT, OutputT],
        event_sink: BaseEventSink | None = None,
        loader: BaseJobLoader[JobT] | None = None,
    ) -> None:
        self._id = id
        self._display_name = display_name if display_name is not None else description
        self._description = description
        self._persistence = persistence
        self._config = config
        self._persister = persister
        self._executor = executor
        self._event_sink = event_sink
        self._loader = loader

    def _emit(self, event: JobEvent) -> None:
        """Publish event to the event sink if one is configured."""
        if self._event_sink is not None:
            self._event_sink.consume_event(event)

    def _get_progress(self) -> JobBatchProgress:
        progress = self._persister.get_job_progress()
        return JobBatchProgress(
            total=progress.total,
            success=progress.success,
            failure=progress.failure,
        )

    def run(self) -> Generator[JobEvent, None, None]:
        """Execute all pending jobs, yielding events."""
        if self._loader is not None:
            self._persister.upsert_jobs(list(self._loader.load_jobs()))

        batch_start = JobEvent(
            variant=BatchStartJobEventVariant(
                type="batchStart",
                value=BatchStartedEvent(
                    id=self._id,
                    info=JobBatchInfo(
                        displayName=self._display_name,
                        description=self._description,
                        persistence=self._persistence,
                        config=self._config,
                    ),
                    progress=self._get_progress(),
                ),
            )
        )
        self._emit(batch_start)
        yield batch_start

        job = self._persister.pop_pending()
        while job is not None:
            job_id = job.id()

            job_start = JobEvent(
                variant=JobStartJobEventVariant(
                    type="jobStart",
                    value=JobStartedEvent(
                        jobId=job_id,
                        input=_to_json_value(job.input()),
                    ),
                )
            )
            self._emit(job_start)
            yield job_start

            try:
                result = self._executor.execute_job(job)
                self._persister.save_success(job.id(), result.output)
                job_complete = JobEvent(
                    variant=JobCompleteJobEventVariant(
                        type="jobComplete",
                        value=JobCompletedEvent(
                            jobId=job_id,
                            result=JobSuccessResultVariant(
                                type="success",
                                value=JobSuccessResult(
                                    output=_to_json_value(result.output),
                                ),
                            ),
                            progress=self._get_progress(),
                        ),
                    )
                )
            except Exception as e:
                self._persister.save_failure(job.id(), e)
                job_complete = JobEvent(
                    variant=JobCompleteJobEventVariant(
                        type="jobComplete",
                        value=JobCompletedEvent(
                            jobId=job_id,
                            result=JobFailureResultVariant(
                                type="failure",
                                value=JobFailureResult(message=str(e)),
                            ),
                            progress=self._get_progress(),
                        ),
                    )
                )

            self._emit(job_complete)
            yield job_complete

            job = self._persister.pop_pending()
