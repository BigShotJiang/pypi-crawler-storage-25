from __future__ import annotations

from typing import Any

from percylib.jobs import (
    BaseJobPersister,
    FullJob,
    JobProgress,
    JobStatus,
    JobT,
    SuccessT,
)


class MemoryPersister(BaseJobPersister[JobT, SuccessT]):
    """In-memory job persister for testing.

    Stores all job state in plain Python data structures with no
    external dependencies.  Useful for unit tests and quick
    experiments that don't need durable storage.

    Generic over the job type and success type, so original job
    objects are preserved as-is (no serialization).
    """

    def __init__(self) -> None:
        self._pending: list[JobT] = []
        self._running: list[JobT] = []
        self._successes: dict[str, SuccessT] = {}
        self._failures: dict[str, Exception] = {}
        self._all_jobs: dict[str, JobT] = {}
        self._group_scores: dict[str, float] = {}

    def upsert_jobs(self, jobs: list[JobT]) -> list[bool]:
        """Upsert a list of jobs with status ``pending``.

        Returns a list of booleans parallel to *jobs*: ``True`` when the
        job was newly added, ``False`` when it already existed (in which
        case the existing record is left unchanged).
        """
        results: list[bool] = []
        existing_ids = {j.id() for j in self._pending + self._running}
        existing_ids |= set(self._successes) | set(self._failures)
        for job in jobs:
            if job.id() in existing_ids:
                results.append(False)
            else:
                self._pending.append(job)
                self._all_jobs[job.id()] = job
                existing_ids.add(job.id())
                results.append(True)
        return results

    def pop_pending(self) -> JobT | None:
        """Pop a pending job, mark it as in progress, and return it."""
        if not self._pending:
            return None
        job = self._pending.pop(0)
        self._running.append(job)
        return job

    def save_success(self, job_id: str, value: SuccessT) -> None:
        """Mark a job as successful and store its output."""
        if job_id not in self._all_jobs:
            return
        self._running = [j for j in self._running if j.id() != job_id]
        self._successes[job_id] = value

    def save_failure(self, job_id: str, error: Exception) -> None:
        """Mark a job as failed and store the error message."""
        if job_id not in self._all_jobs:
            return
        self._running = [j for j in self._running if j.id() != job_id]
        self._failures[job_id] = error

    def mark_running_as_pending(self) -> None:
        """Reset all in-progress jobs back to pending."""
        self._pending.extend(self._running)
        self._running.clear()

    def get_jobs_in_group(self, group_id: str) -> list[FullJob[JobT, SuccessT]]:
        """Return every job that belongs to *group_id*."""
        results: list[FullJob[JobT, SuccessT]] = []
        for job in self._all_jobs.values():
            if job.job_group() != group_id:
                continue
            job_id = job.id()
            status: JobStatus
            output: SuccessT | None = None
            if job_id in self._successes:
                status = "success"
                output = self._successes[job_id]
            elif job_id in self._failures:
                status = "failure"
            elif any(j.id() == job_id for j in self._running):
                status = "in_progress"
            else:
                status = "pending"
            results.append(FullJob(job=job, status=status, output=output))
        return results

    def get_job_progress(self) -> JobProgress:
        """Return aggregate counts for all known jobs."""
        return JobProgress(
            total=len(self._all_jobs),
            success=len(self._successes),
            failure=len(self._failures),
        )

    def store_group_score(self, group_id: str, score: float) -> None:
        """Persist a validation score for *group_id*."""
        self._group_scores[group_id] = score

    # ── Query helpers (useful in tests) ─────────────────────────────

    def get_status(self, job_id: str) -> str | None:
        """Return the status of a job, or ``None`` if it doesn't exist."""
        if job_id in self._successes:
            return "success"
        if job_id in self._failures:
            return "failure"
        if any(j.id() == job_id for j in self._running):
            return "in_progress"
        if any(j.id() == job_id for j in self._pending):
            return "pending"
        return None

    def get_output(self, job_id: str) -> Any:
        """Return the output stored for a job, or ``None`` if not found."""
        if job_id in self._successes:
            return self._successes[job_id]
        if job_id in self._failures:
            return str(self._failures[job_id])
        return None

    def get_group_score(self, group_id: str) -> float | None:
        """Return the stored validation score for a group, or ``None``."""
        return self._group_scores.get(group_id)
