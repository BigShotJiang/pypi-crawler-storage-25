#!/usr/bin/env python3
"""Fetch external.zip artifact from GitHub and sync it into the repository.

Supports downloading from either a GitHub Actions run artifact or a GitHub
release asset. Uses the ``gh`` CLI for authentication.

Usage:
    python scripts/fetch_external.py <github-url>

Examples:
    python scripts/fetch_external.py https://github.com/OWNER/REPO/actions/runs/12345
    python scripts/fetch_external.py https://github.com/OWNER/REPO/releases/tag/v1.0.0
"""

from __future__ import annotations

import argparse
import json
import pathlib
import re
import shutil
import subprocess
import sys
import tempfile
import zipfile
from datetime import datetime, timezone


def _ensure_repo_import_paths(script_path: pathlib.Path | None = None) -> None:
    """Add the repository root and ``src/`` to ``sys.path`` for direct execution."""
    if script_path is None:
        script_path = pathlib.Path(__file__).resolve()

    repo_root = script_path.parent.parent
    for path in reversed((repo_root, repo_root / "src")):
        path_str = str(path)
        if path_str not in sys.path:
            sys.path.insert(0, path_str)


_ensure_repo_import_paths()


def sync_fetched_migrations(
    repo_root: pathlib.Path, fetched_external_dir: pathlib.Path
) -> None:
    """Move fetched migrations into the packaged runtime location."""
    fetched_migrations_dir = fetched_external_dir / "migrations"
    package_migrations_dir = repo_root / "src" / "percylib" / "migrations"

    if not fetched_migrations_dir.is_dir():
        raise FileNotFoundError(
            f"Fetched artifact is missing migrations: {fetched_migrations_dir}"
        )

    if package_migrations_dir.exists():
        shutil.rmtree(package_migrations_dir)

    package_migrations_dir.parent.mkdir(parents=True, exist_ok=True)
    shutil.move(str(fetched_migrations_dir), str(package_migrations_dir))


def parse_url(url: str) -> tuple[str, str, str]:
    """Parse a GitHub URL to determine if it refers to a run or a release.

    Returns:
        A tuple of ``(artifact_type, repo, identifier)`` where
        *artifact_type* is ``"run"`` or ``"release"``, *repo* is
        ``"owner/repo"``, and *identifier* is the run ID or tag name.

    Raises:
        ValueError: If the URL does not match a recognised pattern.
    """
    run_match = re.match(r"https://github\.com/([^/]+/[^/]+)/actions/runs/(\d+)", url)
    if run_match:
        return ("run", run_match.group(1), run_match.group(2))

    release_match = re.match(
        r"https://github\.com/([^/]+/[^/]+)/releases/tag/(.+)", url
    )
    if release_match:
        return ("release", release_match.group(1), release_match.group(2))

    raise ValueError(f"Unrecognized GitHub URL format: {url}")


def get_repo_root() -> pathlib.Path:
    """Return the root directory of the current git repository."""
    result = subprocess.run(
        ["git", "rev-parse", "--show-toplevel"],
        capture_output=True,
        text=True,
        check=True,
    )
    return pathlib.Path(result.stdout.strip())


def fetch_run_artifact(repo: str, run_id: str, output_dir: pathlib.Path) -> None:
    """Download a run artifact and extract it into *output_dir*.

    ``gh run download`` extracts the Actions artifact wrapper, yielding
    ``external.zip`` on disk. This function then extracts that zip's
    contents into *output_dir*.
    """
    with tempfile.TemporaryDirectory() as tmpdir:
        subprocess.run(
            [
                "gh",
                "run",
                "download",
                run_id,
                "-n",
                "external.zip",
                "-R",
                repo,
                "-D",
                tmpdir,
            ],
            check=True,
        )
        zip_path = pathlib.Path(tmpdir) / "external.zip"
        with zipfile.ZipFile(zip_path, "r") as zf:
            zf.extractall(output_dir)


def fetch_release_asset(repo: str, tag: str, output_dir: pathlib.Path) -> None:
    """Download a release asset and extract it into *output_dir*."""
    with tempfile.TemporaryDirectory() as tmpdir:
        subprocess.run(
            [
                "gh",
                "release",
                "download",
                tag,
                "-p",
                "external.zip",
                "-R",
                repo,
                "-D",
                tmpdir,
            ],
            check=True,
        )
        zip_path = pathlib.Path(tmpdir) / "external.zip"
        with zipfile.ZipFile(zip_path, "r") as zf:
            zf.extractall(output_dir)


def write_metadata(
    metadata_path: pathlib.Path, artifact_type: str, identifier: str
) -> None:
    """Write ``external_metadata.json`` describing the fetched artifact."""
    timestamp = datetime.now(timezone.utc).isoformat(timespec="seconds")
    if artifact_type == "run":
        metadata = {"runId": identifier, "timestamp": timestamp}
    else:
        metadata = {"tag": identifier, "timestamp": timestamp}

    with open(metadata_path, "w", encoding="utf-8") as f:
        json.dump(metadata, f, indent=2)
        f.write("\n")


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(
        description="Fetch external.zip from GitHub and extract it."
    )
    parser.add_argument(
        "url",
        help=(
            "GitHub URL — either a workflow run "
            "(https://github.com/OWNER/REPO/actions/runs/ID) "
            "or a release "
            "(https://github.com/OWNER/REPO/releases/tag/TAG)"
        ),
    )
    parser.add_argument(
        "--generate",
        action="store_true",
        default=False,
        help="Run model generation after fetching the schemas.",
    )
    args = parser.parse_args(argv)

    artifact_type, repo, identifier = parse_url(args.url)
    repo_root = get_repo_root()
    output_dir = repo_root / "external"
    metadata_path = repo_root / "external_metadata.json"

    # Remove any previous external directory to ensure a clean state.
    if output_dir.exists():
        shutil.rmtree(output_dir)
    output_dir.mkdir(parents=True)

    if artifact_type == "run":
        fetch_run_artifact(repo, identifier, output_dir)
    else:
        fetch_release_asset(repo, identifier, output_dir)

    sync_fetched_migrations(repo_root, output_dir)
    write_metadata(metadata_path, artifact_type, identifier)
    print(f"Successfully fetched external.zip ({artifact_type}: {identifier})")

    if args.generate:
        from scripts.generate_models import generate_all_models

        generate_all_models(repo_root)


if __name__ == "__main__":
    main()
