# PercyLib
A set of python helpers that can be used with [Percy](https://percivaltech.com) to accelerate data science work.

## Local Development

### Prerequisites

Install [uv](https://docs.astral.sh/uv/getting-started/installation/), the Python package manager used by this project:

```bash
curl -LsSf https://astral.sh/uv/install.sh | sh
```

### VS Code Extensions

For the best development experience, install the following VS Code extensions:

- [Ruff](https://marketplace.visualstudio.com/items?itemName=astral-sh.ruff) — linting and formatting
- [ty](https://marketplace.visualstudio.com/items?itemName=astral-sh.ty) — type checking

The repository includes a `.vscode/settings.json` that configures these extensions automatically.

### Setup

Clone the repository and install all dependencies (including dev tools):

```bash
uv sync
```

### Available Tasks

This project uses [poethepoet](https://poethepoet.natn.io/) as its task runner. Run tasks with `uv run poe <task>`:

| Task      | Command               | Description                        |
|-----------|-----------------------|------------------------------------|
| `compile` | `uv run poe compile`  | Type check with ty                 |
| `lint`    | `uv run poe lint`     | Lint with ruff                     |
| `format`  | `uv run poe format`   | Format code with ruff              |
| `test`    | `uv run poe test`     | Run tests with pytest              |
| `build`   | `uv run poe build`    | Build the package with uv          |
