from __future__ import annotations

from typing import Optional

from percylib.jobs import (
    BaseJob,
    BaseJobExecutor,
    JobOutput,
    JobStatus,
    MemoryPersister,
)

# ── Concrete test doubles ──────────────────────────────────────────


class _EchoJob(BaseJob[str]):
    def __init__(self, job_id: str, payload: str, group: str | None = None):
        self._id = job_id
        self._payload = payload
        self._group = group

    def id(self) -> str:
        return self._id

    def job_group(self) -> Optional[str]:
        return self._group

    def input(self) -> str:
        return self._payload


class _UpperExecutor(BaseJobExecutor[_EchoJob, str]):
    def execute_job(self, job: _EchoJob) -> JobOutput[str]:
        return JobOutput(output=job.input().upper())


class _FailingExecutor(BaseJobExecutor[_EchoJob, str]):
    def execute_job(self, job: _EchoJob) -> JobOutput[str]:
        raise RuntimeError(f"failed on {job.id()}")


# ── Tests ───────────────────────────────────────────────────────────


class TestBaseJob:
    def test_id(self) -> None:
        job = _EchoJob("j1", "hello")
        assert job.id() == "j1"

    def test_input(self) -> None:
        job = _EchoJob("j1", "hello")
        assert job.input() == "hello"

    def test_job_group_default_none(self) -> None:
        job = _EchoJob("j1", "hello")
        assert job.job_group() is None

    def test_job_group_custom(self) -> None:
        job = _EchoJob("j1", "hello", group="grp")
        assert job.job_group() == "grp"


class TestBaseJobExecutor:
    def test_execute_returns_output(self) -> None:
        executor = _UpperExecutor()
        job = _EchoJob("j1", "hello")
        assert executor.execute_job(job) == JobOutput(output="HELLO")


class TestBaseJobPersister:
    def test_add_and_pop(self) -> None:
        persister: MemoryPersister[_EchoJob, str] = MemoryPersister()
        jobs = [_EchoJob("j1", "a"), _EchoJob("j2", "b")]
        persister.upsert_jobs(jobs)

        first = persister.pop_pending()
        assert first is not None
        assert first.id() == "j1"

    def test_pop_empty_returns_none(self) -> None:
        persister: MemoryPersister[_EchoJob, str] = MemoryPersister()
        assert persister.pop_pending() is None

    def test_save_success(self) -> None:
        persister: MemoryPersister[_EchoJob, str] = MemoryPersister()
        persister.upsert_jobs([_EchoJob("j1", "a")])
        persister.pop_pending()
        persister.save_success("j1", "RESULT")
        assert persister._successes == {"j1": "RESULT"}
        assert persister._running == []

    def test_save_failure(self) -> None:
        persister: MemoryPersister[_EchoJob, str] = MemoryPersister()
        persister.upsert_jobs([_EchoJob("j1", "a")])
        persister.pop_pending()
        err = RuntimeError("boom")
        persister.save_failure("j1", err)
        assert persister._failures == {"j1": err}
        assert persister._running == []

    def test_mark_running_as_pending(self) -> None:
        persister: MemoryPersister[_EchoJob, str] = MemoryPersister()
        persister.upsert_jobs([_EchoJob("j1", "a"), _EchoJob("j2", "b")])
        persister.pop_pending()
        persister.pop_pending()
        assert len(persister._running) == 2

        persister.mark_running_as_pending()
        assert persister._running == []
        assert len(persister._pending) == 2


class TestExecutionLoop:
    """Validate the pseudocode execution loop from the spec."""

    def test_all_succeed(self) -> None:
        persister: MemoryPersister[_EchoJob, str] = MemoryPersister()
        executor = _UpperExecutor()
        persister.upsert_jobs([_EchoJob("j1", "hi"), _EchoJob("j2", "bye")])

        job = persister.pop_pending()
        while job is not None:
            try:
                result = executor.execute_job(job)
                persister.save_success(job.id(), result.output)
            except Exception as e:
                persister.save_failure(job.id(), e)
            job = persister.pop_pending()

        assert persister._successes == {"j1": "HI", "j2": "BYE"}
        assert persister._failures == {}

    def test_mixed_success_and_failure(self) -> None:
        persister: MemoryPersister[_EchoJob, str] = MemoryPersister()
        executor = _FailingExecutor()
        persister.upsert_jobs([_EchoJob("j1", "x")])

        job = persister.pop_pending()
        while job is not None:
            try:
                result = executor.execute_job(job)
                persister.save_success(job.id(), result.output)
            except Exception as e:
                persister.save_failure(job.id(), e)
            job = persister.pop_pending()

        assert persister._successes == {}
        assert "j1" in persister._failures


class TestJobStatus:
    def test_valid_statuses(self) -> None:
        valid: list[JobStatus] = ["pending", "in_progress", "success", "failure"]
        assert len(valid) == 4
