from __future__ import annotations

from typing import Any

import pytest

import percylib.ai.model_provider as model_provider
from percylib.ai import DefaultAiModelProvider
from percylib.external.models import (
    CustomJobLanguageModelSpecVariant,
    LanguageModelType,
    PercyJobLanguageModelSpecVariant,
    PercyLanguageModelSpec,
)


def _percy_spec(model: LanguageModelType) -> PercyJobLanguageModelSpecVariant:
    return PercyJobLanguageModelSpecVariant(
        type="percy",
        value=PercyLanguageModelSpec(model=model),
    )


def test_supported_percy_model_map_covers_all_supported_percy_models() -> None:
    supported_models = set(model_provider._PERCY_MODEL_SPECS)
    expected_models = set(LanguageModelType) - {LanguageModelType.ollama_qwen2_5}

    assert supported_models == expected_models


def test_get_model_rejects_custom_specs() -> None:
    provider = DefaultAiModelProvider()
    spec = CustomJobLanguageModelSpecVariant(type="custom", value={"model": "custom"})

    with pytest.raises(ValueError, match="Custom model specs are not supported"):
        provider.get_model(spec)


def test_get_model_rejects_unsupported_percy_models() -> None:
    provider = DefaultAiModelProvider()
    spec = _percy_spec(LanguageModelType.ollama_qwen2_5)

    with pytest.raises(ValueError, match="ollama_qwen2_5"):
        provider.get_model(spec)


def test_get_model_requires_auth_token(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("PERCY_AUTH_TOKEN", raising=False)

    provider = DefaultAiModelProvider()
    spec = _percy_spec(LanguageModelType.openai_4_1)

    with pytest.raises(ValueError, match="PERCY_AUTH_TOKEN"):
        provider.get_model(spec)


def test_get_model_builds_openai_responses_model(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    captured: dict[str, Any] = {}
    sentinel = object()

    def fake_create_openai_model(**kwargs: Any) -> object:
        captured.update(kwargs)
        return sentinel

    monkeypatch.setenv("PERCY_AUTH_TOKEN", "secret-token")
    monkeypatch.setenv("PERCY_BASE_URL", "https://proxy.example.com")
    monkeypatch.setattr(
        model_provider,
        "_create_openai_model",
        fake_create_openai_model,
    )

    provider = DefaultAiModelProvider()
    model = provider.get_model(_percy_spec(LanguageModelType.openai_5_codex_high))

    assert model is sentinel
    assert captured == {
        "model_name": "gpt-5-codex",
        "base_url": "https://proxy.example.com/proxy/openai",
        "auth_token": "secret-token",
        "settings": {"openai_reasoning_effort": "high"},
    }


def test_get_model_builds_google_model_with_default_base_url(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    captured: dict[str, Any] = {}
    sentinel = object()

    def fake_create_google_model(**kwargs: Any) -> object:
        captured.update(kwargs)
        return sentinel

    monkeypatch.setenv("PERCY_AUTH_TOKEN", "secret-token")
    monkeypatch.delenv("PERCY_BASE_URL", raising=False)
    monkeypatch.setattr(
        model_provider,
        "_create_google_model",
        fake_create_google_model,
    )

    provider = DefaultAiModelProvider()
    model = provider.get_model(
        _percy_spec(LanguageModelType.gemini_3_1_pro_preview_customtools)
    )

    assert model is sentinel
    assert captured == {
        "model_name": "gemini-3.1-pro-preview",
        "base_url": "https://percy.percivaltech.com/proxy/gemini",
        "auth_token": "secret-token",
        "settings": None,
    }


def test_get_model_builds_anthropic_model_with_thinking_config(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    captured: dict[str, Any] = {}
    sentinel = object()

    def fake_create_anthropic_model(**kwargs: Any) -> object:
        captured.update(kwargs)
        return sentinel

    monkeypatch.setenv("PERCY_AUTH_TOKEN", "secret-token")
    monkeypatch.setenv("PERCY_BASE_URL", "https://proxy.example.com/")
    monkeypatch.setattr(
        model_provider,
        "_create_anthropic_model",
        fake_create_anthropic_model,
    )

    provider = DefaultAiModelProvider()
    model = provider.get_model(
        _percy_spec(LanguageModelType.claude_sonnet_4_6_thinking)
    )

    assert model is sentinel
    assert captured == {
        "model_name": "claude-sonnet-4-6",
        "base_url": "https://proxy.example.com/proxy/anthropic",
        "auth_token": "secret-token",
        "settings": {
            "anthropic_thinking": {
                "type": "enabled",
                "budget_tokens": 1024,
            }
        },
    }
