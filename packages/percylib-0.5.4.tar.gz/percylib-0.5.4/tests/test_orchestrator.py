from __future__ import annotations

import types
import uuid
from collections.abc import Iterator
from typing import Optional

from percylib.external.models import (
    BatchStartedEvent,
    BatchStartJobEventVariant,
    JobBatchProgress,
    JobCompletedEvent,
    JobCompleteJobEventVariant,
    JobEvent,
    JobFailureResultVariant,
    JobPersistenceConfig,
    JobStartedEvent,
    JobStartJobEventVariant,
    JobSuccessResultVariant,
    SqliteJobPersistenceVariant,
    SqlitePersistenceConfig,
)
from percylib.jobs import (
    BaseEventSink,
    BaseJob,
    BaseJobExecutor,
    BaseJobLoader,
    JobOutput,
    MemoryPersister,
)
from percylib.jobs.orchestrator import DefaultJobOrchestrator

# ── Test doubles ────────────────────────────────────────────────────


class _TestJob(BaseJob[str]):
    def __init__(self, job_id: str, payload: str, group: str | None = None):
        self._id = job_id
        self._payload = payload
        self._group = group

    def id(self) -> str:
        return self._id

    def job_group(self) -> Optional[str]:
        return self._group

    def input(self) -> str:
        return self._payload


class _UpperExecutor(BaseJobExecutor["_TestJob", str]):
    def execute_job(self, job: _TestJob) -> JobOutput[str]:
        return JobOutput(output=job.input().upper())


class _FailingExecutor(BaseJobExecutor["_TestJob", str]):
    def execute_job(self, job: _TestJob) -> JobOutput[str]:
        raise RuntimeError(f"failed on {job.id()}")


class _RecordingEventSink(BaseEventSink):
    def __init__(self) -> None:
        self.events: list[JobEvent] = []

    def consume_event(self, event: JobEvent) -> None:
        self.events.append(event)


def _make_uuid() -> str:
    return str(uuid.uuid4())


# ── Tests ───────────────────────────────────────────────────────────


class TestDefaultJobOrchestrator:
    def test_run_returns_generator(self) -> None:
        orch = DefaultJobOrchestrator(
            id="batch-1",
            persister=MemoryPersister(),
            executor=_UpperExecutor(),
        )
        assert isinstance(orch.run(), types.GeneratorType)

    def test_empty_queue_yields_only_batch_start(self) -> None:
        orch = DefaultJobOrchestrator(
            id="batch-1",
            description="test batch",
            persister=MemoryPersister(),
            executor=_UpperExecutor(),
        )
        events = list(orch.run())
        assert len(events) == 1
        assert events[0].variant.type == "batchStart"

    def test_batch_start_has_correct_id_and_description(self) -> None:
        orch = DefaultJobOrchestrator(
            id="my-batch",
            description="My Batch",
            persister=MemoryPersister(),
            executor=_UpperExecutor(),
        )
        events = list(orch.run())
        batch_variant = events[0].variant
        assert isinstance(batch_variant, BatchStartJobEventVariant)
        assert isinstance(batch_variant.value, BatchStartedEvent)
        assert batch_variant.value.id == "my-batch"
        assert batch_variant.value.info.displayName == "My Batch"
        assert batch_variant.value.info.description == "My Batch"

    def test_batch_start_reports_progress(self) -> None:
        persister: MemoryPersister[_TestJob, str] = MemoryPersister()
        persister.upsert_jobs(
            [_TestJob(_make_uuid(), "a"), _TestJob(_make_uuid(), "b")]
        )
        orch = DefaultJobOrchestrator(
            id="batch-1",
            persister=persister,
            executor=_UpperExecutor(),
        )

        events = list(orch.run())
        batch_variant = events[0].variant

        assert isinstance(batch_variant, BatchStartJobEventVariant)
        assert isinstance(batch_variant.value, BatchStartedEvent)
        assert isinstance(batch_variant.value.progress, JobBatchProgress)
        assert batch_variant.value.progress.total == 2
        assert batch_variant.value.progress.success == 0
        assert batch_variant.value.progress.failure == 0

    def test_batch_start_reports_persistence(self) -> None:
        persistence = JobPersistenceConfig(
            variant=SqliteJobPersistenceVariant(
                type="sqlite",
                value=SqlitePersistenceConfig(path="/tmp/jobs.sqlite"),
            )
        )
        orch = DefaultJobOrchestrator(
            id="batch-1",
            persister=MemoryPersister(),
            executor=_UpperExecutor(),
            persistence=persistence,
        )

        events = list(orch.run())
        batch_variant = events[0].variant

        assert isinstance(batch_variant, BatchStartJobEventVariant)
        assert isinstance(batch_variant.value, BatchStartedEvent)
        assert batch_variant.value.info.persistence == persistence

    def test_single_successful_job(self) -> None:
        job_id = _make_uuid()
        persister: MemoryPersister[_TestJob, str] = MemoryPersister()
        persister.upsert_jobs([_TestJob(job_id, "hello")])
        orch = DefaultJobOrchestrator(
            id="batch-1",
            persister=persister,
            executor=_UpperExecutor(),
        )
        events = list(orch.run())

        assert len(events) == 3
        assert events[0].variant.type == "batchStart"
        assert events[1].variant.type == "jobStart"
        start_variant = events[1].variant
        assert isinstance(start_variant, JobStartJobEventVariant)
        assert isinstance(start_variant.value, JobStartedEvent)
        assert start_variant.value.jobId == job_id
        assert start_variant.value.input == "hello"
        complete_variant = events[2].variant
        assert isinstance(complete_variant, JobCompleteJobEventVariant)
        assert isinstance(complete_variant.value, JobCompletedEvent)
        assert complete_variant.value.result.type == "success"
        success_result = complete_variant.value.result
        assert isinstance(success_result, JobSuccessResultVariant)
        assert success_result.value.output == "HELLO"
        assert complete_variant.value.progress is not None
        assert complete_variant.value.progress.total == 1
        assert complete_variant.value.progress.success == 1
        assert complete_variant.value.progress.failure == 0

    def test_single_failing_job(self) -> None:
        job_id = _make_uuid()
        persister: MemoryPersister[_TestJob, str] = MemoryPersister()
        persister.upsert_jobs([_TestJob(job_id, "hello")])
        orch = DefaultJobOrchestrator(
            id="batch-1",
            persister=persister,
            executor=_FailingExecutor(),
        )
        events = list(orch.run())

        assert len(events) == 3
        complete_variant = events[2].variant
        assert isinstance(complete_variant, JobCompleteJobEventVariant)
        assert isinstance(complete_variant.value, JobCompletedEvent)
        assert complete_variant.value.result.type == "failure"
        fail_result = complete_variant.value.result
        assert isinstance(fail_result, JobFailureResultVariant)
        assert fail_result.value.message is not None
        assert "failed on" in fail_result.value.message
        assert complete_variant.value.progress is not None
        assert complete_variant.value.progress.total == 1
        assert complete_variant.value.progress.success == 0
        assert complete_variant.value.progress.failure == 1

    def test_multiple_jobs(self) -> None:
        ids = [_make_uuid(), _make_uuid()]
        persister: MemoryPersister[_TestJob, str] = MemoryPersister()
        persister.upsert_jobs([_TestJob(ids[0], "a"), _TestJob(ids[1], "b")])
        orch = DefaultJobOrchestrator(
            id="batch-1",
            persister=persister,
            executor=_UpperExecutor(),
        )
        events = list(orch.run())

        # 1 batch start + 2 * (job start + job complete) = 5
        assert len(events) == 5
        types_ = [e.variant.type for e in events]
        assert types_ == [
            "batchStart",
            "jobStart",
            "jobComplete",
            "jobStart",
            "jobComplete",
        ]

    def test_mixed_success_and_failure(self) -> None:
        """First job succeeds, second fails."""
        id1, id2 = _make_uuid(), _make_uuid()
        persister: MemoryPersister[_TestJob, str] = MemoryPersister()
        persister.upsert_jobs([_TestJob(id1, "ok"), _TestJob(id2, "bad")])

        class _MixedExecutor(BaseJobExecutor["_TestJob", str]):
            def execute_job(self, job: _TestJob) -> JobOutput[str]:
                if job.input() == "bad":
                    raise ValueError("nope")
                return JobOutput(output=job.input().upper())

        orch = DefaultJobOrchestrator(
            id="batch-1",
            persister=persister,
            executor=_MixedExecutor(),
        )
        events = list(orch.run())

        assert len(events) == 5
        v2 = events[2].variant
        assert isinstance(v2, JobCompleteJobEventVariant)
        assert isinstance(v2.value, JobCompletedEvent)
        assert v2.value.result.type == "success"
        assert v2.value.progress is not None
        assert v2.value.progress.total == 2
        assert v2.value.progress.success == 1
        assert v2.value.progress.failure == 0
        v4 = events[4].variant
        assert isinstance(v4, JobCompleteJobEventVariant)
        assert isinstance(v4.value, JobCompletedEvent)
        assert v4.value.result.type == "failure"
        assert v4.value.progress is not None
        assert v4.value.progress.total == 2
        assert v4.value.progress.success == 1
        assert v4.value.progress.failure == 1

    def test_event_sink_receives_all_events(self) -> None:
        job_id = _make_uuid()
        persister: MemoryPersister[_TestJob, str] = MemoryPersister()
        persister.upsert_jobs([_TestJob(job_id, "hi")])
        sink = _RecordingEventSink()
        orch = DefaultJobOrchestrator(
            id="batch-1",
            persister=persister,
            executor=_UpperExecutor(),
            event_sink=sink,
        )
        events = list(orch.run())

        assert sink.events == events

    def test_no_event_sink_is_fine(self) -> None:
        orch = DefaultJobOrchestrator(
            id="batch-1",
            persister=MemoryPersister(),
            executor=_UpperExecutor(),
            event_sink=None,
        )
        events = list(orch.run())
        assert len(events) == 1

    def test_persister_records_success(self) -> None:
        job_id = _make_uuid()
        persister: MemoryPersister[_TestJob, str] = MemoryPersister()
        persister.upsert_jobs([_TestJob(job_id, "hello")])
        orch = DefaultJobOrchestrator(
            id="batch-1",
            persister=persister,
            executor=_UpperExecutor(),
        )
        list(orch.run())

        assert persister._successes == {job_id: "HELLO"}

    def test_persister_records_failure(self) -> None:
        job_id = _make_uuid()
        persister: MemoryPersister[_TestJob, str] = MemoryPersister()
        persister.upsert_jobs([_TestJob(job_id, "hello")])
        orch = DefaultJobOrchestrator(
            id="batch-1",
            persister=persister,
            executor=_FailingExecutor(),
        )
        list(orch.run())

        assert job_id in persister._failures

    def test_description_defaults_to_none(self) -> None:
        orch = DefaultJobOrchestrator(
            id="batch-1",
            persister=MemoryPersister(),
            executor=_UpperExecutor(),
        )
        events = list(orch.run())
        batch_variant = events[0].variant
        assert isinstance(batch_variant, BatchStartJobEventVariant)
        assert isinstance(batch_variant.value, BatchStartedEvent)
        assert batch_variant.value.info.displayName is None


class _TestLoader(BaseJobLoader["_TestJob"]):
    def __init__(self, jobs: list[_TestJob]) -> None:
        self._jobs = jobs

    def load_jobs(self) -> Iterator[_TestJob]:
        yield from self._jobs


class TestDefaultJobOrchestratorWithLoader:
    def test_loader_jobs_are_persisted_and_executed(self) -> None:
        job_id = _make_uuid()
        persister: MemoryPersister[_TestJob, str] = MemoryPersister()
        loader = _TestLoader([_TestJob(job_id, "hello")])
        orch = DefaultJobOrchestrator(
            id="batch-1",
            persister=persister,
            executor=_UpperExecutor(),
            loader=loader,
        )
        events = list(orch.run())

        assert len(events) == 3
        assert events[0].variant.type == "batchStart"
        assert events[1].variant.type == "jobStart"
        assert events[2].variant.type == "jobComplete"
        assert persister._successes == {job_id: "HELLO"}

    def test_loader_none_is_fine(self) -> None:
        orch = DefaultJobOrchestrator(
            id="batch-1",
            persister=MemoryPersister(),
            executor=_UpperExecutor(),
            loader=None,
        )
        events = list(orch.run())
        assert len(events) == 1

    def test_loader_with_existing_persisted_jobs(self) -> None:
        id1, id2 = _make_uuid(), _make_uuid()
        persister: MemoryPersister[_TestJob, str] = MemoryPersister()
        persister.upsert_jobs([_TestJob(id1, "pre-loaded")])
        loader = _TestLoader([_TestJob(id2, "loaded")])
        orch = DefaultJobOrchestrator(
            id="batch-1",
            persister=persister,
            executor=_UpperExecutor(),
            loader=loader,
        )
        events = list(orch.run())

        # batch start + 2 * (job start + job complete) = 5
        assert len(events) == 5
        assert persister._successes == {id1: "PRE-LOADED", id2: "LOADED"}

    def test_loader_duplicate_jobs_not_duplicated(self) -> None:
        job_id = _make_uuid()
        persister: MemoryPersister[_TestJob, str] = MemoryPersister()
        persister.upsert_jobs([_TestJob(job_id, "original")])
        loader = _TestLoader([_TestJob(job_id, "duplicate")])
        orch = DefaultJobOrchestrator(
            id="batch-1",
            persister=persister,
            executor=_UpperExecutor(),
            loader=loader,
        )
        events = list(orch.run())

        # Only 1 job should be executed (the original one)
        assert len(events) == 3
        assert persister._successes == {job_id: "ORIGINAL"}
