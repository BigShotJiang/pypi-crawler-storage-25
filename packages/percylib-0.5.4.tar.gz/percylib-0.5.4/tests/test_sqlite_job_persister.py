from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from typing import Any, Optional, TypeVar, cast

from pydantic import BaseModel as PydanticBaseModel
from sqlalchemy import create_engine

from percylib.jobs import BaseJob, FullJob, JobProgress
from percylib.jobs.sqlite import (
    Serde,
    SqliteJobPersister,
    create_migrated_jobs_sqlite,
    create_pydantic_serde,
)

InputT = TypeVar("InputT")
SuccessT = TypeVar("SuccessT")


def _identity(value: str) -> str:
    return value


STRING_SERDE: Serde[str] = Serde(serializer=_identity, deserializer=_identity)
DICT_SERDE: Serde[dict[str, Any]] = Serde(
    serializer=json.dumps,
    deserializer=lambda value: cast(dict[str, Any], json.loads(value)),
)


def _create_persister(
    path: Path,
    input_serde: Serde[InputT],
    success_serde: Serde[SuccessT],
) -> SqliteJobPersister[InputT, SuccessT]:
    return SqliteJobPersister.create(
        path,
        input_serde=input_serde,
        success_serde=success_serde,
    )


def _create_string_persister(path: Path) -> SqliteJobPersister[str, str]:
    return _create_persister(path, input_serde=STRING_SERDE, success_serde=STRING_SERDE)


class _SimpleJob(BaseJob[str]):
    """Minimal concrete job for testing."""

    def __init__(self, job_id: str, payload: str, group: str | None = None) -> None:
        self._id = job_id
        self._payload = payload
        self._group = group

    def id(self) -> str:
        return self._id

    def job_group(self) -> Optional[str]:
        return self._group

    def input(self) -> str:
        return self._payload


class _DictJob(BaseJob[dict[str, Any]]):
    """Job with a dict input."""

    def __init__(
        self,
        job_id: str,
        payload: dict[str, Any],
        group: str | None = None,
    ) -> None:
        self._id = job_id
        self._payload = payload
        self._group = group

    def id(self) -> str:
        return self._id

    def job_group(self) -> Optional[str]:
        return self._group

    def input(self) -> dict[str, Any]:
        return self._payload


class _InputModel(PydanticBaseModel):
    name: str
    score: float


class _SuccessModel(PydanticBaseModel):
    status: str
    total: int


class _PydanticJob(BaseJob[_InputModel]):
    """Job with a Pydantic model input."""

    def __init__(
        self,
        job_id: str,
        payload: _InputModel,
        group: str | None = None,
    ) -> None:
        self._id = job_id
        self._payload = payload
        self._group = group

    def id(self) -> str:
        return self._id

    def job_group(self) -> Optional[str]:
        return self._group

    def input(self) -> _InputModel:
        return self._payload


# ── Factory tests ───────────────────────────────────────────────────


class TestSqliteJobPersisterCreate:
    def test_create_produces_sqlite_file(self, tmp_path: Path) -> None:
        db_path = tmp_path / "jobs.sqlite"
        _create_string_persister(db_path)
        assert db_path.exists()

    def test_create_creates_parent_directories(self, tmp_path: Path) -> None:
        db_path = tmp_path / "a" / "b" / "jobs.sqlite"
        _create_string_persister(db_path)
        assert db_path.exists()

    def test_create_returns_persister(self, tmp_path: Path) -> None:
        db_path = tmp_path / "jobs.sqlite"
        persister = _create_string_persister(db_path)
        assert isinstance(persister, SqliteJobPersister)


# ── Constructor tests ───────────────────────────────────────────────


class TestSqliteJobPersisterInit:
    def test_init_with_engine(self, tmp_path: Path) -> None:
        db_path = tmp_path / "jobs.sqlite"
        create_migrated_jobs_sqlite(db_path)
        engine = create_engine(f"sqlite:///{db_path}")
        persister = SqliteJobPersister(
            engine,
            input_serde=STRING_SERDE,
            success_serde=STRING_SERDE,
        )
        assert isinstance(persister, SqliteJobPersister)


# ── Integration tests ──────────────────────────────────────────────


class TestUpsertJobs:
    def test_add_single_job(self, tmp_path: Path) -> None:
        persister = _create_string_persister(tmp_path / "jobs.sqlite")
        persister.upsert_jobs([_SimpleJob("j1", "payload")])

        conn = sqlite3.connect(str(tmp_path / "jobs.sqlite"))
        row = conn.execute("SELECT * FROM jobs WHERE id='j1'").fetchone()
        conn.close()

        assert row is not None

    def test_add_multiple_jobs(self, tmp_path: Path) -> None:
        persister = _create_string_persister(tmp_path / "jobs.sqlite")
        jobs: list[BaseJob[str]] = [_SimpleJob(f"j{i}", f"data{i}") for i in range(5)]
        persister.upsert_jobs(jobs)

        conn = sqlite3.connect(str(tmp_path / "jobs.sqlite"))
        count = conn.execute("SELECT COUNT(*) FROM jobs").fetchone()[0]
        conn.close()

        assert count == 5

    def test_upsert_jobs_stores_pending_status(self, tmp_path: Path) -> None:
        persister = _create_string_persister(tmp_path / "jobs.sqlite")
        persister.upsert_jobs([_SimpleJob("j1", "payload")])

        conn = sqlite3.connect(str(tmp_path / "jobs.sqlite"))
        status = conn.execute("SELECT status FROM jobs WHERE id='j1'").fetchone()[0]
        conn.close()

        assert status == "pending"

    def test_upsert_jobs_stores_input(self, tmp_path: Path) -> None:
        persister = _create_string_persister(tmp_path / "jobs.sqlite")
        persister.upsert_jobs([_SimpleJob("j1", "my-input")])

        conn = sqlite3.connect(str(tmp_path / "jobs.sqlite"))
        inp = conn.execute("SELECT input FROM jobs WHERE id='j1'").fetchone()[0]
        conn.close()

        assert inp == "my-input"

    def test_upsert_jobs_with_group(self, tmp_path: Path) -> None:
        persister = _create_string_persister(tmp_path / "jobs.sqlite")
        persister.upsert_jobs([_SimpleJob("j1", "data", group="grp1")])

        conn = sqlite3.connect(str(tmp_path / "jobs.sqlite"))
        group_row = conn.execute("SELECT id FROM job_groups WHERE id='grp1'").fetchone()
        job_row = conn.execute("SELECT group_id FROM jobs WHERE id='j1'").fetchone()
        conn.close()

        assert group_row is not None
        assert job_row[0] == "grp1"

    def test_upsert_jobs_same_group_no_duplicate(self, tmp_path: Path) -> None:
        persister = _create_string_persister(tmp_path / "jobs.sqlite")
        persister.upsert_jobs(
            [
                _SimpleJob("j1", "a", group="grp1"),
                _SimpleJob("j2", "b", group="grp1"),
            ]
        )

        conn = sqlite3.connect(str(tmp_path / "jobs.sqlite"))
        count = conn.execute(
            "SELECT COUNT(*) FROM job_groups WHERE id='grp1'"
        ).fetchone()[0]
        conn.close()

        assert count == 1

    def test_upsert_returns_true_for_new_jobs(self, tmp_path: Path) -> None:
        persister = _create_string_persister(tmp_path / "jobs.sqlite")
        result = persister.upsert_jobs([_SimpleJob("j1", "a"), _SimpleJob("j2", "b")])
        assert result == [True, True]

    def test_upsert_returns_false_for_existing_job(self, tmp_path: Path) -> None:
        persister = _create_string_persister(tmp_path / "jobs.sqlite")
        persister.upsert_jobs([_SimpleJob("j1", "original")])
        result = persister.upsert_jobs([_SimpleJob("j1", "updated")])
        assert result == [False]

    def test_upsert_does_not_overwrite_existing_job(self, tmp_path: Path) -> None:
        persister = _create_string_persister(tmp_path / "jobs.sqlite")
        persister.upsert_jobs([_SimpleJob("j1", "original")])
        persister.upsert_jobs([_SimpleJob("j1", "updated")])

        conn = sqlite3.connect(str(tmp_path / "jobs.sqlite"))
        inp = conn.execute("SELECT input FROM jobs WHERE id='j1'").fetchone()[0]
        conn.close()

        assert inp == "original"

    def test_upsert_mixed_new_and_existing(self, tmp_path: Path) -> None:
        persister = _create_string_persister(tmp_path / "jobs.sqlite")
        persister.upsert_jobs([_SimpleJob("j1", "a")])
        result = persister.upsert_jobs(
            [_SimpleJob("j1", "a"), _SimpleJob("j2", "b"), _SimpleJob("j3", "c")]
        )
        assert result == [False, True, True]

    def test_upsert_assigns_ascending_priorities(self, tmp_path: Path) -> None:
        persister = _create_string_persister(tmp_path / "jobs.sqlite")
        persister.upsert_jobs(
            [
                _SimpleJob("j1", "a"),
                _SimpleJob("j2", "b"),
                _SimpleJob("j3", "c"),
            ]
        )

        conn = sqlite3.connect(str(tmp_path / "jobs.sqlite"))
        rows = conn.execute(
            "SELECT id, priority FROM jobs ORDER BY priority ASC, id ASC"
        ).fetchall()
        conn.close()

        assert rows == [("j1", 0), ("j2", 1), ("j3", 2)]

    def test_upsert_starts_from_zero_when_no_jobs_are_pending(
        self,
        tmp_path: Path,
    ) -> None:
        persister = _create_string_persister(tmp_path / "jobs.sqlite")
        persister.upsert_jobs([_SimpleJob("j1", "a"), _SimpleJob("j2", "b")])
        persister.pop_pending()
        persister.pop_pending()

        persister.upsert_jobs([_SimpleJob("j3", "c")])

        conn = sqlite3.connect(str(tmp_path / "jobs.sqlite"))
        priority = conn.execute("SELECT priority FROM jobs WHERE id='j3'").fetchone()[0]
        conn.close()

        assert priority == 0


class TestPopPending:
    def test_pop_returns_pending_job(self, tmp_path: Path) -> None:
        persister = _create_string_persister(tmp_path / "jobs.sqlite")
        persister.upsert_jobs([_SimpleJob("j1", "hello")])

        job = persister.pop_pending()

        assert job is not None
        assert job.id() == "j1"
        assert job.input() == "hello"

    def test_pop_marks_job_running(self, tmp_path: Path) -> None:
        persister = _create_string_persister(tmp_path / "jobs.sqlite")
        persister.upsert_jobs([_SimpleJob("j1", "hello")])
        persister.pop_pending()

        conn = sqlite3.connect(str(tmp_path / "jobs.sqlite"))
        status = conn.execute("SELECT status FROM jobs WHERE id='j1'").fetchone()[0]
        conn.close()

        assert status == "in_progress"

    def test_pop_empty_returns_none(self, tmp_path: Path) -> None:
        persister = _create_string_persister(tmp_path / "jobs.sqlite")
        assert persister.pop_pending() is None

    def test_pop_preserves_group(self, tmp_path: Path) -> None:
        persister = _create_string_persister(tmp_path / "jobs.sqlite")
        persister.upsert_jobs([_SimpleJob("j1", "data", group="grp1")])

        job = persister.pop_pending()

        assert job is not None
        assert job.job_group() == "grp1"

    def test_pop_does_not_return_running_jobs(self, tmp_path: Path) -> None:
        persister = _create_string_persister(tmp_path / "jobs.sqlite")
        persister.upsert_jobs([_SimpleJob("j1", "a")])
        persister.pop_pending()  # marks j1 as in_progress

        assert persister.pop_pending() is None

    def test_pop_returns_lowest_priority_value_first(self, tmp_path: Path) -> None:
        persister = _create_string_persister(tmp_path / "jobs.sqlite")
        persister.upsert_jobs(
            [
                _SimpleJob("j1", "first"),
                _SimpleJob("j2", "second"),
                _SimpleJob("j3", "third"),
            ]
        )

        conn = sqlite3.connect(str(tmp_path / "jobs.sqlite"))
        conn.execute("UPDATE jobs SET priority = 10 WHERE id='j1'")
        conn.execute("UPDATE jobs SET priority = 1 WHERE id='j2'")
        conn.execute("UPDATE jobs SET priority = 5 WHERE id='j3'")
        conn.commit()
        conn.close()

        first = persister.pop_pending()
        second = persister.pop_pending()
        third = persister.pop_pending()

        assert first is not None
        assert second is not None
        assert third is not None
        assert [first.id(), second.id(), third.id()] == ["j2", "j3", "j1"]


class TestSaveSuccess:
    def test_save_success_updates_status(self, tmp_path: Path) -> None:
        persister = _create_string_persister(tmp_path / "jobs.sqlite")
        persister.upsert_jobs([_SimpleJob("j1", "x")])
        persister.pop_pending()
        persister.save_success("j1", "RESULT")

        conn = sqlite3.connect(str(tmp_path / "jobs.sqlite"))
        row = conn.execute("SELECT status, output FROM jobs WHERE id='j1'").fetchone()
        conn.close()

        assert row[0] == "success"
        assert row[1] == "RESULT"

    def test_save_success_nonexistent_job_is_noop(self, tmp_path: Path) -> None:
        persister = _create_string_persister(tmp_path / "jobs.sqlite")
        persister.save_success("nonexistent", "value")


class TestSaveFailure:
    def test_save_failure_updates_status(self, tmp_path: Path) -> None:
        persister = _create_string_persister(tmp_path / "jobs.sqlite")
        persister.upsert_jobs([_SimpleJob("j1", "x")])
        persister.pop_pending()
        persister.save_failure("j1", RuntimeError("boom"))

        conn = sqlite3.connect(str(tmp_path / "jobs.sqlite"))
        row = conn.execute("SELECT status, output FROM jobs WHERE id='j1'").fetchone()
        conn.close()

        assert row[0] == "failure"
        assert row[1] == "boom"

    def test_save_failure_nonexistent_job_is_noop(self, tmp_path: Path) -> None:
        persister = _create_string_persister(tmp_path / "jobs.sqlite")
        persister.save_failure("nonexistent", RuntimeError("oops"))


class TestMarkRunningAsPending:
    def test_resets_running_to_pending(self, tmp_path: Path) -> None:
        persister = _create_string_persister(tmp_path / "jobs.sqlite")
        persister.upsert_jobs([_SimpleJob("j1", "a"), _SimpleJob("j2", "b")])
        persister.pop_pending()
        persister.pop_pending()

        persister.mark_running_as_pending()

        conn = sqlite3.connect(str(tmp_path / "jobs.sqlite"))
        rows = conn.execute("SELECT status FROM jobs ORDER BY id").fetchall()
        conn.close()

        assert all(row[0] == "pending" for row in rows)

    def test_does_not_affect_other_statuses(self, tmp_path: Path) -> None:
        persister = _create_string_persister(tmp_path / "jobs.sqlite")
        persister.upsert_jobs([_SimpleJob("j1", "a"), _SimpleJob("j2", "b")])
        persister.pop_pending()
        persister.save_success("j1", "done")

        persister.pop_pending()
        persister.mark_running_as_pending()

        conn = sqlite3.connect(str(tmp_path / "jobs.sqlite"))
        j1_status = conn.execute("SELECT status FROM jobs WHERE id='j1'").fetchone()[0]
        j2_status = conn.execute("SELECT status FROM jobs WHERE id='j2'").fetchone()[0]
        conn.close()

        assert j1_status == "success"
        assert j2_status == "pending"


class TestExecutionLoop:
    """Full lifecycle integration test."""

    def test_process_all_jobs(self, tmp_path: Path) -> None:
        persister = _create_string_persister(tmp_path / "jobs.sqlite")
        persister.upsert_jobs([_SimpleJob("j1", "hello"), _SimpleJob("j2", "world")])

        job = persister.pop_pending()
        while job is not None:
            persister.save_success(job.id(), job.input().upper())
            job = persister.pop_pending()

        conn = sqlite3.connect(str(tmp_path / "jobs.sqlite"))
        rows = conn.execute(
            "SELECT id, status, output FROM jobs ORDER BY id"
        ).fetchall()
        conn.close()

        assert rows[0] == ("j1", "success", "HELLO")
        assert rows[1] == ("j2", "success", "WORLD")


# ── Serialization tests ────────────────────────────────────────────


class TestDictInputSerde:
    def test_dict_input_is_serialized(self, tmp_path: Path) -> None:
        persister = _create_persister(
            tmp_path / "jobs.sqlite",
            input_serde=DICT_SERDE,
            success_serde=STRING_SERDE,
        )
        persister.upsert_jobs([_DictJob("j1", {"key": "value", "n": 42})])

        conn = sqlite3.connect(str(tmp_path / "jobs.sqlite"))
        inp = conn.execute("SELECT input FROM jobs WHERE id='j1'").fetchone()[0]
        conn.close()

        assert json.loads(inp) == {"key": "value", "n": 42}

    def test_dict_input_roundtrip_via_pop(self, tmp_path: Path) -> None:
        persister = _create_persister(
            tmp_path / "jobs.sqlite",
            input_serde=DICT_SERDE,
            success_serde=STRING_SERDE,
        )
        persister.upsert_jobs([_DictJob("j1", {"a": [1, 2, 3]})])

        job = persister.pop_pending()
        assert job is not None
        assert job.input() == {"a": [1, 2, 3]}


class TestPydanticSerde:
    def test_create_pydantic_serde_roundtrip(self) -> None:
        serde = create_pydantic_serde(_InputModel)
        model = _InputModel(name="alice", score=0.95)

        serialized = serde.serializer(model)
        restored = serde.deserializer(serialized)

        assert restored == model

    def test_pydantic_input_roundtrip_via_pop(self, tmp_path: Path) -> None:
        input_serde = create_pydantic_serde(_InputModel)
        success_serde = create_pydantic_serde(_SuccessModel)
        model = _InputModel(name="bob", score=0.8)
        persister = _create_persister(
            tmp_path / "jobs.sqlite",
            input_serde=input_serde,
            success_serde=success_serde,
        )
        persister.upsert_jobs([_PydanticJob("j1", model)])

        job = persister.pop_pending()

        assert job is not None
        assert job.input() == model

    def test_pydantic_success_serde_can_restore_stored_output(
        self,
        tmp_path: Path,
    ) -> None:
        input_serde = create_pydantic_serde(_InputModel)
        success_serde = create_pydantic_serde(_SuccessModel)
        persister = _create_persister(
            tmp_path / "jobs.sqlite",
            input_serde=input_serde,
            success_serde=success_serde,
        )
        persister.upsert_jobs([_PydanticJob("j1", _InputModel(name="in", score=1.0))])
        persister.pop_pending()
        persister.save_success("j1", _SuccessModel(status="done", total=2))

        conn = sqlite3.connect(str(tmp_path / "jobs.sqlite"))
        out = conn.execute("SELECT output FROM jobs WHERE id='j1'").fetchone()[0]
        conn.close()

        restored = success_serde.deserializer(out)
        assert restored == _SuccessModel(status="done", total=2)


class TestSaveSuccessSerialization:
    def test_save_success_with_dict(self, tmp_path: Path) -> None:
        persister = _create_persister(
            tmp_path / "jobs.sqlite",
            input_serde=STRING_SERDE,
            success_serde=DICT_SERDE,
        )
        persister.upsert_jobs([_SimpleJob("j1", "x")])
        persister.pop_pending()
        persister.save_success("j1", {"result": True})

        conn = sqlite3.connect(str(tmp_path / "jobs.sqlite"))
        out = conn.execute("SELECT output FROM jobs WHERE id='j1'").fetchone()[0]
        conn.close()

        assert json.loads(out) == {"result": True}

    def test_save_success_with_pydantic_model(self, tmp_path: Path) -> None:
        success_serde = create_pydantic_serde(_SuccessModel)
        persister = _create_persister(
            tmp_path / "jobs.sqlite",
            input_serde=STRING_SERDE,
            success_serde=success_serde,
        )
        persister.upsert_jobs([_SimpleJob("j1", "x")])
        persister.pop_pending()
        persister.save_success("j1", _SuccessModel(status="out", total=1))

        conn = sqlite3.connect(str(tmp_path / "jobs.sqlite"))
        out = conn.execute("SELECT output FROM jobs WHERE id='j1'").fetchone()[0]
        conn.close()

        restored = success_serde.deserializer(out)
        assert restored == _SuccessModel(status="out", total=1)


class TestCustomSerde:
    def test_custom_serde_used_for_input_roundtrip(self, tmp_path: Path) -> None:
        custom_serde: Serde[str] = Serde(
            serializer=lambda value: f"custom:{value}",
            deserializer=lambda value: value.removeprefix("custom:"),
        )
        persister = _create_persister(
            tmp_path / "jobs.sqlite",
            input_serde=custom_serde,
            success_serde=STRING_SERDE,
        )
        persister.upsert_jobs([_SimpleJob("j1", "data")])

        conn = sqlite3.connect(str(tmp_path / "jobs.sqlite"))
        inp = conn.execute("SELECT input FROM jobs WHERE id='j1'").fetchone()[0]
        conn.close()

        job = persister.pop_pending()

        assert inp == "custom:data"
        assert job is not None
        assert job.input() == "data"

    def test_custom_serde_used_for_success(self, tmp_path: Path) -> None:
        custom_serde: Serde[str] = Serde(
            serializer=lambda value: f"custom:{value}",
            deserializer=lambda value: value.removeprefix("custom:"),
        )
        persister = _create_persister(
            tmp_path / "jobs.sqlite",
            input_serde=STRING_SERDE,
            success_serde=custom_serde,
        )
        persister.upsert_jobs([_SimpleJob("j1", "x")])
        persister.pop_pending()
        persister.save_success("j1", "result")

        conn = sqlite3.connect(str(tmp_path / "jobs.sqlite"))
        out = conn.execute("SELECT output FROM jobs WHERE id='j1'").fetchone()[0]
        conn.close()

        assert out == "custom:result"
        assert custom_serde.deserializer(out) == "result"

    def test_constructor_accepts_serdes(self, tmp_path: Path) -> None:
        db_path = tmp_path / "jobs.sqlite"
        create_migrated_jobs_sqlite(db_path)
        engine = create_engine(f"sqlite:///{db_path}")
        dict_input_serde: Serde[dict[str, Any]] = Serde(
            serializer=repr,
            deserializer=lambda value: cast(dict[str, Any], {"raw": value}),
        )
        persister = SqliteJobPersister(
            engine,
            input_serde=dict_input_serde,
            success_serde=STRING_SERDE,
        )
        persister.upsert_jobs([_DictJob("j1", {"k": "v"})])

        conn = sqlite3.connect(str(db_path))
        inp = conn.execute("SELECT input FROM jobs WHERE id='j1'").fetchone()[0]
        conn.close()

        assert inp == repr({"k": "v"})


# ── get_jobs_in_group tests ────────────────────────────────────────


class TestGetJobsInGroup:
    def test_returns_empty_for_unknown_group(self, tmp_path: Path) -> None:
        persister = _create_string_persister(tmp_path / "jobs.sqlite")
        assert persister.get_jobs_in_group("no-such-group") == []

    def test_returns_pending_jobs(self, tmp_path: Path) -> None:
        persister = _create_string_persister(tmp_path / "jobs.sqlite")
        persister.upsert_jobs([_SimpleJob("j1", "a", group="g1")])
        jobs = persister.get_jobs_in_group("g1")
        assert len(jobs) == 1
        assert jobs[0].job.id() == "j1"
        assert jobs[0].status == "pending"
        assert jobs[0].output is None

    def test_returns_running_jobs(self, tmp_path: Path) -> None:
        persister = _create_string_persister(tmp_path / "jobs.sqlite")
        persister.upsert_jobs([_SimpleJob("j1", "a", group="g1")])
        persister.pop_pending()
        jobs = persister.get_jobs_in_group("g1")
        assert len(jobs) == 1
        assert jobs[0].status == "in_progress"

    def test_returns_successful_jobs_with_output(self, tmp_path: Path) -> None:
        persister = _create_string_persister(tmp_path / "jobs.sqlite")
        persister.upsert_jobs([_SimpleJob("j1", "a", group="g1")])
        persister.pop_pending()
        persister.save_success("j1", "RESULT")
        jobs = persister.get_jobs_in_group("g1")
        assert len(jobs) == 1
        assert jobs[0].status == "success"
        assert jobs[0].output == "RESULT"

    def test_returns_failed_jobs_without_output(self, tmp_path: Path) -> None:
        persister = _create_string_persister(tmp_path / "jobs.sqlite")
        persister.upsert_jobs([_SimpleJob("j1", "a", group="g1")])
        persister.pop_pending()
        persister.save_failure("j1", RuntimeError("boom"))
        jobs = persister.get_jobs_in_group("g1")
        assert len(jobs) == 1
        assert jobs[0].status == "failure"
        assert jobs[0].output is None

    def test_returns_only_jobs_in_requested_group(self, tmp_path: Path) -> None:
        persister = _create_string_persister(tmp_path / "jobs.sqlite")
        persister.upsert_jobs(
            [
                _SimpleJob("j1", "a", group="g1"),
                _SimpleJob("j2", "b", group="g2"),
                _SimpleJob("j3", "c", group="g1"),
            ]
        )
        jobs = persister.get_jobs_in_group("g1")
        ids = {fj.job.id() for fj in jobs}
        assert ids == {"j1", "j3"}

    def test_mixed_statuses_in_group(self, tmp_path: Path) -> None:
        persister = _create_string_persister(tmp_path / "jobs.sqlite")
        persister.upsert_jobs(
            [
                _SimpleJob("j1", "a", group="g1"),
                _SimpleJob("j2", "b", group="g1"),
                _SimpleJob("j3", "c", group="g1"),
            ]
        )
        persister.pop_pending()
        persister.save_success("j1", "OK")
        persister.pop_pending()
        persister.save_failure("j2", RuntimeError("err"))
        # j3 is still pending
        jobs = persister.get_jobs_in_group("g1")
        by_id = {fj.job.id(): fj for fj in jobs}
        assert by_id["j1"].status == "success"
        assert by_id["j1"].output == "OK"
        assert by_id["j2"].status == "failure"
        assert by_id["j3"].status == "pending"

    def test_result_is_full_job(self, tmp_path: Path) -> None:
        persister = _create_string_persister(tmp_path / "jobs.sqlite")
        persister.upsert_jobs([_SimpleJob("j1", "data", group="g1")])
        jobs = persister.get_jobs_in_group("g1")
        assert isinstance(jobs[0], FullJob)

    def test_deserialized_input_roundtrips(self, tmp_path: Path) -> None:
        persister = _create_string_persister(tmp_path / "jobs.sqlite")
        persister.upsert_jobs([_SimpleJob("j1", "my-input", group="g1")])
        jobs = persister.get_jobs_in_group("g1")
        assert jobs[0].job.input() == "my-input"

    def test_preserves_group_on_returned_job(self, tmp_path: Path) -> None:
        persister = _create_string_persister(tmp_path / "jobs.sqlite")
        persister.upsert_jobs([_SimpleJob("j1", "x", group="g1")])
        jobs = persister.get_jobs_in_group("g1")
        assert jobs[0].job.job_group() == "g1"


# ── get_job_progress tests ─────────────────────────────────────────


class TestGetJobProgress:
    def test_returns_zero_counts_for_empty_persister(self, tmp_path: Path) -> None:
        persister = _create_string_persister(tmp_path / "jobs.sqlite")

        assert persister.get_job_progress() == JobProgress(
            total=0, success=0, failure=0
        )

    def test_counts_pending_running_success_and_failure_jobs(
        self, tmp_path: Path
    ) -> None:
        persister = _create_string_persister(tmp_path / "jobs.sqlite")
        persister.upsert_jobs(
            [
                _SimpleJob("j1", "a"),
                _SimpleJob("j2", "b"),
                _SimpleJob("j3", "c"),
                _SimpleJob("j4", "d"),
            ]
        )
        persister.pop_pending()
        persister.save_success("j1", "A")
        persister.pop_pending()
        persister.save_failure("j2", RuntimeError("boom"))
        persister.pop_pending()

        assert persister.get_job_progress() == JobProgress(
            total=4, success=1, failure=1
        )


# ── store_group_score tests ────────────────────────────────────────


class TestStoreGroupScore:
    def test_store_score(self, tmp_path: Path) -> None:
        persister = _create_string_persister(tmp_path / "jobs.sqlite")
        persister.upsert_jobs([_SimpleJob("j1", "a", group="g1")])
        persister.store_group_score("g1", 0.85)

        conn = sqlite3.connect(str(tmp_path / "jobs.sqlite"))
        score = conn.execute(
            "SELECT validation_score FROM job_groups WHERE id='g1'"
        ).fetchone()[0]
        conn.close()

        assert score == 0.85

    def test_overwrite_existing_score(self, tmp_path: Path) -> None:
        persister = _create_string_persister(tmp_path / "jobs.sqlite")
        persister.upsert_jobs([_SimpleJob("j1", "a", group="g1")])
        persister.store_group_score("g1", 0.5)
        persister.store_group_score("g1", 0.9)

        conn = sqlite3.connect(str(tmp_path / "jobs.sqlite"))
        score = conn.execute(
            "SELECT validation_score FROM job_groups WHERE id='g1'"
        ).fetchone()[0]
        conn.close()

        assert score == 0.9

    def test_nonexistent_group_is_noop(self, tmp_path: Path) -> None:
        persister = _create_string_persister(tmp_path / "jobs.sqlite")
        persister.store_group_score("no-such-group", 0.5)

    def test_multiple_groups(self, tmp_path: Path) -> None:
        persister = _create_string_persister(tmp_path / "jobs.sqlite")
        persister.upsert_jobs(
            [
                _SimpleJob("j1", "a", group="g1"),
                _SimpleJob("j2", "b", group="g2"),
            ]
        )
        persister.store_group_score("g1", 0.7)
        persister.store_group_score("g2", 0.3)

        conn = sqlite3.connect(str(tmp_path / "jobs.sqlite"))
        g1 = conn.execute(
            "SELECT validation_score FROM job_groups WHERE id='g1'"
        ).fetchone()[0]
        g2 = conn.execute(
            "SELECT validation_score FROM job_groups WHERE id='g2'"
        ).fetchone()[0]
        conn.close()

        assert g1 == 0.7
        assert g2 == 0.3
