from __future__ import annotations

import glob
import os
import random
from collections import Counter
from pathlib import Path, PurePosixPath

import pytest
from pydantic_ai.models import Model
from pydantic_ai.models.test import TestModel

from percylib.external.models import (
    DocExtractExampleConfig,
    FileLocator,
    FolderFileSource,
    FolderV1FileSourceVariant,
    JobLanguageModelSpec,
    LanguageModelType,
    LlmDocExtractIterationSpec,
    LlmDocExtractSpec,
    LlmDocExtractV1Input,
    ObjectPropertyDefinition,
    ObjectSchema,
    ObjectSchemaVariant,
    PercyJobLanguageModelSpecVariant,
    PercyLanguageModelSpec,
    SingleDocExtractExample,
    StringSchema,
    StringSchemaVariant,
)
from percylib.jobs.ai.doc_extract_v1 import (
    DocExtractJob,
    DocExtractJobExecutor,
    FolderDocExtractJobLoader,
)


def _percy_model_spec() -> PercyJobLanguageModelSpecVariant:
    return PercyJobLanguageModelSpecVariant(
        type="percy",
        value=PercyLanguageModelSpec(model=LanguageModelType.openai_4_1),
    )


def _iteration_spec() -> LlmDocExtractIterationSpec:
    return LlmDocExtractIterationSpec(model=_percy_model_spec())


def _make_spec(
    *,
    output_schema: ObjectSchemaVariant | None = None,
    example: DocExtractExampleConfig | None = None,
    prompt: str = "Extract the name",
) -> LlmDocExtractSpec:
    if output_schema is None:
        output_schema = ObjectSchemaVariant(
            type="object",
            value=ObjectSchema(
                properties=[
                    ObjectPropertyDefinition(
                        key="name",
                        optional=False,
                        schema=StringSchemaVariant(type="string", value=StringSchema()),
                    )
                ]
            ),
        )
    return LlmDocExtractSpec(
        source=FolderV1FileSourceVariant(
            type="folderV1",
            value=FolderFileSource(
                path="/tmp/test", includePatterns=["**/*.pdf"], excludePatterns=[]
            ),
        ),
        iterations=[LlmDocExtractIterationSpec(model=_percy_model_spec())],
        prompt=prompt,
        outputSchema=output_schema,
        example=example,
    )


class _MockModelProvider:
    """Returns a predetermined TestModel regardless of spec."""

    def __init__(self, test_model: TestModel) -> None:
        self._test_model = test_model

    def get_model(self, spec: JobLanguageModelSpec) -> Model:
        return self._test_model


def _make_iterations(count: int) -> list[LlmDocExtractIterationSpec]:
    return [LlmDocExtractIterationSpec(model=_percy_model_spec()) for _ in range(count)]


def _glob_reference_matches(
    root: Path,
    include_patterns: list[str],
    exclude_patterns: list[str],
) -> set[str]:
    effective_includes = include_patterns or ["**/*.pdf"]
    included: set[str] = set()
    excluded: set[str] = set()

    for pattern in effective_includes:
        included.update(_glob_matches(root, pattern))

    for pattern in exclude_patterns:
        excluded.update(_glob_matches(root, pattern))

    return included - excluded


def _glob_matches(root: Path, pattern: str) -> set[str]:
    matches: set[str] = set()
    for match in glob.glob(str(root / pattern), recursive=True):
        match_path = Path(match)
        if match_path.is_file():
            matches.add(match_path.relative_to(root).as_posix())
    return matches


def _loaded_relative_paths(root: Path, jobs: list[DocExtractJob]) -> set[str]:
    relative_paths: set[str] = set()
    for job in jobs:
        job_file = job.input().file
        assert isinstance(job_file, str)
        relative_paths.add(Path(job_file).relative_to(root).as_posix())
    return relative_paths


def _assert_loader_matches_reference(
    root: Path,
    include_patterns: list[str],
    exclude_patterns: list[str],
    iterations: list[LlmDocExtractIterationSpec],
    *,
    case_label: str,
) -> list[DocExtractJob]:
    loader = FolderDocExtractJobLoader(
        FolderFileSource(
            path=str(root),
            includePatterns=include_patterns,
            excludePatterns=exclude_patterns,
        ),
        iterations,
    )
    jobs = list(loader.load_jobs())
    expected_paths = _glob_reference_matches(root, include_patterns, exclude_patterns)

    assert _loaded_relative_paths(root, jobs) == expected_paths, case_label
    assert {job.id() for job in jobs} == {
        f"{relative_path}-{iteration_number}"
        for relative_path in expected_paths
        for iteration_number in range(1, len(iterations) + 1)
    }, case_label

    if len(iterations) == 1:
        assert all(job.job_group() is None for job in jobs), case_label
    else:
        assert Counter(job.job_group() for job in jobs) == Counter(
            {relative_path: len(iterations) for relative_path in expected_paths}
        ), case_label

    return jobs


def _random_name(rng: random.Random, min_length: int = 3, max_length: int = 8) -> str:
    alphabet = "abcdefghijklmnopqrstuvwxyz0123456789"
    return "".join(
        rng.choice(alphabet) for _ in range(rng.randint(min_length, max_length))
    )


def _random_segment(rng: random.Random, *, allow_hidden: bool = True) -> str:
    segment = _random_name(rng)
    if allow_hidden and rng.random() < 0.15:
        return f".{segment}"
    return segment


def _create_random_tree(root: Path, rng: random.Random) -> list[str]:
    extensions = ["pdf", "txt", "json", "md", "csv", "png"]
    directories = [PurePosixPath(".")]

    for _ in range(rng.randint(8, 16)):
        parent = rng.choice(directories)
        if len(parent.parts) >= 4:
            parent = PurePosixPath(".")
        candidate = parent / _random_segment(rng)
        if candidate in directories:
            continue
        directories.append(candidate)
        (root / Path(candidate)).mkdir(parents=True, exist_ok=True)

    files: set[str] = set()
    while len(files) < rng.randint(35, 60):
        directory = rng.choice(directories)
        filename = f"{_random_segment(rng)}.{rng.choice(extensions)}"
        relative_path = (directory / filename).as_posix()
        if relative_path == "./" or relative_path in files:
            continue
        files.add(relative_path.removeprefix("./"))
        file_path = root / Path(relative_path)
        file_path.parent.mkdir(parents=True, exist_ok=True)
        file_path.write_text(relative_path)

    if not any(path.endswith(".pdf") for path in files):
        pdf_path = f"{_random_segment(rng)}.pdf"
        files.add(pdf_path)
        (root / pdf_path).write_text(pdf_path)

    return sorted(files)


def _wildcard_segment(segment: str, rng: random.Random) -> str:
    options = [segment, "*"]

    if len(segment) > 1:
        index = rng.randrange(len(segment))
        question_mark = list(segment)
        question_mark[index] = "?"
        options.append("".join(question_mark))
        options.append(f"{segment[:index]}*")
        options.append(f"*{segment[index + 1 :]}")

    if "." in segment:
        stem, suffix = segment.rsplit(".", 1)
        options.append(f"*.{suffix}")
        if stem:
            options.append(f"{stem[0]}*.{suffix}")

    return rng.choice(options)


def _sample_pattern_from_path(path: str, rng: random.Random) -> str:
    parts = list(PurePosixPath(path).parts)
    if len(parts) > 1 and rng.random() < 0.5:
        suffix_length = rng.randint(1, len(parts))
        parts = ["**", *parts[-suffix_length:]]

    for index, part in enumerate(parts):
        if part == "**":
            continue
        if rng.random() < 0.6:
            parts[index] = _wildcard_segment(part, rng)

    if all("*" not in part and "?" not in part for part in parts if part != "**"):
        non_glob_indexes = [index for index, part in enumerate(parts) if part != "**"]
        chosen_index = rng.choice(non_glob_indexes)
        parts[chosen_index] = _wildcard_segment(parts[chosen_index], rng)

    return "/".join(parts)


def _sample_synthetic_pattern(rng: random.Random) -> str:
    extension = rng.choice(["pdf", "txt", "json", "md", "csv", "png"])
    token = _random_name(rng)
    choices = [
        f"**/{token}*.{extension}",
        f"{token}/**/*.{extension}",
        f"*{token}*.{extension}",
        f"**/*.{extension}",
    ]
    return rng.choice(choices)


def _sample_glob_patterns(
    rng: random.Random,
    file_paths: list[str],
    *,
    allow_empty: bool,
) -> list[str]:
    if allow_empty and rng.random() < 0.2:
        return []

    patterns: set[str] = set()
    target_count = rng.randint(1, 4)
    while len(patterns) < target_count:
        if file_paths and rng.random() < 0.8:
            patterns.add(_sample_pattern_from_path(rng.choice(file_paths), rng))
        else:
            patterns.add(_sample_synthetic_pattern(rng))
    return sorted(patterns)


class TestDocExtractJob:
    def test_id(self) -> None:
        inp = LlmDocExtractV1Input(file="/tmp/f.txt", spec=_iteration_spec())
        job = DocExtractJob("j1", None, inp)
        assert job.id() == "j1"

    def test_group(self) -> None:
        inp = LlmDocExtractV1Input(file="/tmp/f.txt", spec=_iteration_spec())
        job = DocExtractJob("j1", "g1", inp)
        assert job.job_group() == "g1"

    def test_input(self) -> None:
        inp = LlmDocExtractV1Input(file="/tmp/f.txt", spec=_iteration_spec())
        job = DocExtractJob("j1", None, inp)
        assert job.input() is inp


class TestDocExtractJobExecutor:
    def test_basic_execution(self, tmp_path: Path) -> None:
        """Executor returns the model's output for a simple file."""
        doc = tmp_path / "doc.txt"
        doc.write_text("Alice")

        expected = {"name": "Alice"}
        model = TestModel(custom_output_args=expected)
        provider = _MockModelProvider(model)
        spec = _make_spec(prompt="Extract the name")
        executor = DocExtractJobExecutor(provider, spec)

        inp = LlmDocExtractV1Input(file=str(doc), spec=_iteration_spec())
        job = DocExtractJob("j1", None, inp)

        result = executor.execute_job(job)
        assert result.output == expected

    def test_prompt_passed_as_developer_instructions(self, tmp_path: Path) -> None:
        """The spec prompt is forwarded to the Agent as developer instructions."""
        doc = tmp_path / "doc.txt"
        doc.write_text("test")

        model = TestModel(custom_output_args={"name": "x"})
        provider = _MockModelProvider(model)
        spec = _make_spec(prompt="Custom prompt here")
        executor = DocExtractJobExecutor(provider, spec)

        inp = LlmDocExtractV1Input(file=str(doc), spec=_iteration_spec())
        job = DocExtractJob("j1", None, inp)
        result = executor.execute_job(job)

        assert result.output == {"name": "x"}

    def test_file_sent_as_binary_content(self, tmp_path: Path) -> None:
        """The target file is sent as BinaryContent in the final user prompt."""
        doc = tmp_path / "doc.txt"
        doc.write_bytes(b"raw bytes here")

        model = TestModel(custom_output_args={"name": "v"})
        provider = _MockModelProvider(model)
        executor = DocExtractJobExecutor(provider, _make_spec())

        inp = LlmDocExtractV1Input(file=str(doc), spec=_iteration_spec())
        job = DocExtractJob("j1", None, inp)
        result = executor.execute_job(job)

        assert result.output == {"name": "v"}

    def test_examples_in_message_history(self, tmp_path: Path) -> None:
        """Each example produces a user message with file content + expected output."""
        ex_file = tmp_path / "example.txt"
        ex_file.write_text("Example content")

        doc = tmp_path / "doc.txt"
        doc.write_text("Actual content")

        example_cfg = DocExtractExampleConfig(
            examples=[
                SingleDocExtractExample(
                    file=str(ex_file), expected={"name": "Bob"}, rationale=None
                )
            ]
        )
        expected = {"name": "Result"}
        model = TestModel(custom_output_args=expected)
        provider = _MockModelProvider(model)
        spec = _make_spec(example=example_cfg)
        executor = DocExtractJobExecutor(provider, spec)

        inp = LlmDocExtractV1Input(file=str(doc), spec=_iteration_spec())
        job = DocExtractJob("j1", None, inp)
        result = executor.execute_job(job)

        assert result.output == expected

    def test_example_with_rationale(self, tmp_path: Path) -> None:
        """When a rationale is provided, it is appended to the expected text."""
        ex_file = tmp_path / "example.txt"
        ex_file.write_text("Example")

        doc = tmp_path / "doc.txt"
        doc.write_text("Doc")

        example_cfg = DocExtractExampleConfig(
            examples=[
                SingleDocExtractExample(
                    file=str(ex_file),
                    expected={"name": "X"},
                    rationale="Because X is the name",
                )
            ]
        )
        model = TestModel(custom_output_args={"name": "Y"})
        provider = _MockModelProvider(model)
        spec = _make_spec(example=example_cfg)
        executor = DocExtractJobExecutor(provider, spec)

        inp = LlmDocExtractV1Input(file=str(doc), spec=_iteration_spec())
        job = DocExtractJob("j1", None, inp)
        result = executor.execute_job(job)

        assert result.output == {"name": "Y"}

    def test_multiple_examples_separate_messages(self, tmp_path: Path) -> None:
        """Multiple examples each produce their own user message."""
        ex1 = tmp_path / "ex1.txt"
        ex1.write_text("First")
        ex2 = tmp_path / "ex2.txt"
        ex2.write_text("Second")

        doc = tmp_path / "doc.txt"
        doc.write_text("Target")

        example_cfg = DocExtractExampleConfig(
            examples=[
                SingleDocExtractExample(
                    file=str(ex1), expected={"name": "A"}, rationale=None
                ),
                SingleDocExtractExample(
                    file=str(ex2), expected={"name": "B"}, rationale=None
                ),
            ]
        )
        model = TestModel(custom_output_args={"name": "C"})
        provider = _MockModelProvider(model)
        spec = _make_spec(example=example_cfg)
        executor = DocExtractJobExecutor(provider, spec)

        inp = LlmDocExtractV1Input(file=str(doc), spec=_iteration_spec())
        job = DocExtractJob("j1", None, inp)
        result = executor.execute_job(job)

        assert result.output == {"name": "C"}

    def test_no_examples(self, tmp_path: Path) -> None:
        """When no examples are provided, message history is empty."""
        doc = tmp_path / "doc.txt"
        doc.write_text("Content")

        model = TestModel(custom_output_args={"name": "Z"})
        provider = _MockModelProvider(model)
        spec = _make_spec(example=None)
        executor = DocExtractJobExecutor(provider, spec)

        inp = LlmDocExtractV1Input(file=str(doc), spec=_iteration_spec())
        job = DocExtractJob("j1", None, inp)
        result = executor.execute_job(job)

        assert result.output == {"name": "Z"}

    def test_unresolvable_file_raises(self) -> None:
        """Raises ValueError when the job file cannot be resolved."""
        from percylib.external.models import FileLocator

        model = TestModel(custom_output_args={"name": "x"})
        provider = _MockModelProvider(model)
        executor = DocExtractJobExecutor(provider, _make_spec())

        # FileLocator with a source that doesn't exist
        locator = FileLocator(source="nonexistent_source", path="file.txt")
        inp = LlmDocExtractV1Input(file=locator, spec=_iteration_spec())
        job = DocExtractJob("j1", None, inp)

        with pytest.raises(ValueError, match="Could not resolve file"):
            executor.execute_job(job)

    def test_unresolvable_example_file_raises(self, tmp_path: Path) -> None:
        """Raises ValueError when an example file cannot be resolved."""
        from percylib.external.models import FileLocator

        doc = tmp_path / "doc.txt"
        doc.write_text("Content")

        locator = FileLocator(source="nonexistent_source", path="example.txt")
        example_cfg = DocExtractExampleConfig(
            examples=[
                SingleDocExtractExample(
                    file=locator, expected={"name": "A"}, rationale=None
                )
            ]
        )
        model = TestModel(custom_output_args={"name": "x"})
        provider = _MockModelProvider(model)
        spec = _make_spec(example=example_cfg)
        executor = DocExtractJobExecutor(provider, spec)

        inp = LlmDocExtractV1Input(file=str(doc), spec=_iteration_spec())
        job = DocExtractJob("j1", None, inp)

        with pytest.raises(ValueError, match="Could not resolve example file"):
            executor.execute_job(job)


class TestFolderDocExtractJobLoader:
    def test_loads_one_job_per_iteration_per_matching_file(
        self, tmp_path: Path
    ) -> None:
        docs = tmp_path / "docs"
        docs.mkdir()
        (docs / "root.pdf").write_text("root")
        (docs / "ignore.txt").write_text("ignore")
        (docs / "nested").mkdir()
        (docs / "nested" / "child.pdf").write_text("child")
        (docs / "nested" / "skip.pdf").write_text("skip")

        iterations = _make_iterations(2)
        jobs = _assert_loader_matches_reference(
            docs,
            ["**/*.pdf"],
            ["nested/skip.pdf"],
            iterations,
            case_label="hand-crafted include/exclude case",
        )

        assert sorted(job.id() for job in jobs) == [
            "nested/child.pdf-1",
            "nested/child.pdf-2",
            "root.pdf-1",
            "root.pdf-2",
        ]
        assert sorted(job.job_group() for job in jobs) == [
            "nested/child.pdf",
            "nested/child.pdf",
            "root.pdf",
            "root.pdf",
        ]
        assert sorted(str(job.input().file) for job in jobs) == [
            str(docs / "nested" / "child.pdf"),
            str(docs / "nested" / "child.pdf"),
            str(docs / "root.pdf"),
            str(docs / "root.pdf"),
        ]

    def test_empty_include_defaults_to_all_pdfs(self, tmp_path: Path) -> None:
        docs = tmp_path / "docs"
        docs.mkdir()
        (docs / "root.pdf").write_text("root")
        (docs / "root.txt").write_text("text")
        (docs / "nested").mkdir()
        (docs / "nested" / "child.pdf").write_text("child")

        jobs = _assert_loader_matches_reference(
            docs,
            [],
            [],
            _make_iterations(1),
            case_label="empty include defaults to PDFs",
        )

        assert sorted(job.id() for job in jobs) == ["nested/child.pdf-1", "root.pdf-1"]
        assert all(job.job_group() is None for job in jobs)

    def test_randomized_glob_reference_matches_lazy_loader(
        self, tmp_path: Path
    ) -> None:
        rng = random.Random(1337)

        for case_index in range(25):
            docs = tmp_path / f"random-case-{case_index}"
            docs.mkdir()
            file_paths = _create_random_tree(docs, rng)
            include_patterns = _sample_glob_patterns(
                rng,
                file_paths,
                allow_empty=True,
            )
            exclude_patterns = _sample_glob_patterns(
                rng,
                file_paths,
                allow_empty=False,
            )
            iteration_count = rng.randint(1, 3)

            _assert_loader_matches_reference(
                docs,
                include_patterns,
                exclude_patterns,
                _make_iterations(iteration_count),
                case_label=(
                    "randomized case "
                    f"{case_index} seed=1337 "
                    f"include={include_patterns} "
                    f"exclude={exclude_patterns}"
                ),
            )

    def test_hidden_paths_follow_glob_visibility_rules(self, tmp_path: Path) -> None:
        docs = tmp_path / "docs"
        docs.mkdir()
        (docs / "visible.pdf").write_text("visible")
        (docs / ".hidden.pdf").write_text("hidden")
        (docs / ".hidden-dir").mkdir()
        (docs / ".hidden-dir" / "nested.pdf").write_text("hidden nested")
        (docs / "visible-dir").mkdir()
        (docs / "visible-dir" / ".nested").mkdir()
        (docs / "visible-dir" / ".nested" / "inside.pdf").write_text("inside")

        _assert_loader_matches_reference(
            docs,
            ["**/*.pdf"],
            [],
            _make_iterations(1),
            case_label="hidden files should not match implicit glob segments",
        )
        _assert_loader_matches_reference(
            docs,
            [".*.pdf", "**/.nested/*.pdf", ".hidden-dir/*.pdf"],
            [],
            _make_iterations(2),
            case_label="hidden files should match explicit dot segments",
        )

    def test_load_jobs_uses_scandir_lazily(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        docs = tmp_path / "docs"
        docs.mkdir()
        (docs / "root.pdf").write_text("root")

        loader = FolderDocExtractJobLoader(
            FolderFileSource(path=str(docs), includePatterns=[], excludePatterns=[]),
            _make_iterations(1),
        )

        scandir_calls = 0
        real_scandir = os.scandir

        def counting_scandir(path: str | Path):
            nonlocal scandir_calls
            scandir_calls += 1
            return real_scandir(path)

        monkeypatch.setattr(
            "percylib.jobs.ai.doc_extract_v1.os.scandir",
            counting_scandir,
        )

        jobs = loader.load_jobs()

        assert scandir_calls == 0
        first_job = next(jobs)
        assert scandir_calls >= 1
        assert first_job.id() == "root.pdf-1"

    def test_preserves_locator_inputs_for_workspace_relative_source(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        workspace = tmp_path / "workspace"
        workspace.mkdir()
        (workspace / ".percy").mkdir()
        docs = workspace / "docs"
        docs.mkdir()
        (docs / "root.pdf").write_text("root")
        monkeypatch.chdir(workspace)

        loader = FolderDocExtractJobLoader(
            FolderFileSource(
                path=FileLocator(source=None, path="docs"),
                includePatterns=[],
                excludePatterns=[],
            ),
            [LlmDocExtractIterationSpec(model=_percy_model_spec())],
        )

        job = next(loader.load_jobs())
        job_file = job.input().file

        assert job.id() == "root.pdf-1"
        assert isinstance(job_file, FileLocator)
        assert job_file.source is None
        assert job_file.path == "docs/root.pdf"

    def test_unresolvable_folder_source_raises(self) -> None:
        loader = FolderDocExtractJobLoader(
            FolderFileSource(
                path=FileLocator(source="missing", path="docs"),
                includePatterns=[],
                excludePatterns=[],
            ),
            [LlmDocExtractIterationSpec(model=_percy_model_spec())],
        )

        with pytest.raises(ValueError, match="Could not resolve folder source path"):
            list(loader.load_jobs())
