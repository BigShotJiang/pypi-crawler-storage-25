This is a helper library for interacting with Percy and should be installable via standard Python package management tools like pip or uv.

This is a library that is intended for external use, but currently in private development. Do no worry about things like backwards compa

## Commands
`uv run poe compile` - Run type checking with `ty`. Ensure that this passes before finishing.
`uv run poe lint` - Run linting with `ruff`. Ensure that this passes before finishing.
`uv run poe format` - Run code formatting with `ruff`. Run this as the final step before finishing to ensure that the code is properly formatted.
`uv run poe test` - Run tests with `pytest`. Ensure that all tests pass before finishing.

## Coding Guidelines
Only use Python features from Python 3.9 or earlier, since that is the compatibility target for this library.
Try to make sure everything is strongly typed. It's fine to use `Any` when necessary or if it would be too difficult to be more specific, but prefer to be as specific as possible with types, especially externally facing APIs.
