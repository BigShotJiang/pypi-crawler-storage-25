class DepthCacheClusterNotReachableError(Exception):
    message: str
    def __init__(self, url=None) -> None: ...

class DepthCacheOutOfSync(Exception):
    message: str
    def __init__(self, market=None) -> None: ...

class DepthCacheAlreadyStopped(Exception):
    message: str
    def __init__(self, market=None) -> None: ...

class DepthCacheNotFound(Exception):
    message: str
    def __init__(self, market=None) -> None: ...
