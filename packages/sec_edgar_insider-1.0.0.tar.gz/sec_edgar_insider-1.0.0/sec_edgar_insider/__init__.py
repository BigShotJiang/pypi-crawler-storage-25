"""SEC EDGAR Insider Trading API client — track Form 4 filings and insider buy/sell signals."""

import requests

__version__ = "1.0.0"

BASE_URL = "https://sec-insider-trades.p.rapidapi.com"


class SECEdgarClient:
    """Client for the SEC EDGAR Insider Trading Alerts API on RapidAPI.

    Get your API key at: https://rapidapi.com/lulzasaur9192/api/sec-insider-trades
    """

    def __init__(self, api_key: str):
        if not api_key:
            raise ValueError(
                "API key required — get one at "
                "https://rapidapi.com/lulzasaur9192/api/sec-insider-trades"
            )
        self.session = requests.Session()
        self.session.headers.update({
            "x-rapidapi-key": api_key,
            "x-rapidapi-host": "sec-insider-trades.p.rapidapi.com",
        })

    def _get(self, path: str, params: dict = None) -> dict:
        resp = self.session.get(f"{BASE_URL}{path}", params=params)
        resp.raise_for_status()
        return resp.json()

    def get_recent_trades(self, days: int = 3, limit: int = 20, offset: int = 0, ticker: str = None) -> dict:
        """Get recent Form 4 insider trading filings.

        Args:
            days: Lookback period (1-30, default 3)
            limit: Results per page (1-100, default 20)
            offset: Pagination offset
            ticker: Filter by company ticker symbol
        """
        params = {"days": days, "limit": limit, "offset": offset}
        if ticker:
            params["ticker"] = ticker
        return self._get("/sec/insider-trades", params)

    def get_trades_by_ticker(self, ticker: str, days: int = 30, limit: int = 50) -> dict:
        """Get all insider trades for a specific company.

        Args:
            ticker: Company ticker symbol (e.g. "AAPL")
            days: Lookback period (1-365, default 30)
            limit: Results per page (1-100, default 50)
        """
        return self._get(f"/sec/insider-trades/company/{ticker}", {"days": days, "limit": limit})

    def get_filing(self, accession: str) -> dict:
        """Get full parsed Form 4 filing details.

        Args:
            accession: Accession number (format: XXXXXXXXXX-YY-ZZZZZZ)
        """
        return self._get(f"/sec/insider-trades/filing/{accession}")
