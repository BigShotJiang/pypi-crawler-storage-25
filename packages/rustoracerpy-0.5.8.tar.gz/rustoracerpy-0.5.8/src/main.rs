mod car;
mod map;
#[cfg(feature = "ros")]
mod ros;
mod sim;
mod skeleton;

#[cfg(not(feature = "ros"))]
fn main() {
    let mut sim = sim::Sim::new("maps/my_map.yaml", 1, 10_000);
    sim.reset();
    for _ in 0..1_000_000 {
        let _obs = sim.step(&[0.0, 0.5]);
    }
}

#[cfg(feature = "ros")]
#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    ros::RosBridge {
        sim: sim::Sim::new("maps/berlin.yaml", 1, 10_000),
        hz: 100.0,
    }
    .spin(vec![[0.0, 0.0, 0.0]])
    .await
}
