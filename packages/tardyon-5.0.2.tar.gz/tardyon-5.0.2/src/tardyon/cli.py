# SPDX-License-Identifier: AGPL-3.0-or-later
# SPDX-FileCopyrightText: Copyright 2023 David Seaward and contributors


import os
import subprocess
import sys
from importlib import metadata
from pathlib import Path
from typing import NoReturn


def get_tardy_dir() -> Path:
    return Path.home() / ".local" / "bin" / "tardy"


def invoke() -> None:
    args = sys.argv[1:]
    if not args or args[0] == "--help":
        print_help()
        sys.exit(0)
    elif args[0] == "--version":
        print_metadata()
        sys.exit(0)
    elif len(args) < 2:
        print_help()
        sys.exit(1)
    else:
        verb, noun, *extra_args = args

        if verb == "show" and noun == "yourself":
            show_tardyon_folder()
            sys.exit(0)
        elif verb == "check" and noun == "yourself":
            check_yourself()
            sys.exit(0)
        else:
            try:
                launch_tardyon_script(verb, noun, extra_args)
            except Exception as e:
                print(f"Script could not be invoked: {e}", file=sys.stderr)
                sys.exit(1)


def print_metadata() -> None:
    try:
        version = metadata.version("tardyon")
    except metadata.PackageNotFoundError:
        version = "unknown"

    metadata_msg = f'tardyon v{version}\nCall "tardyon VERB NOUN"'
    print(metadata_msg)


def print_help() -> None:
    print_metadata()
    print("\nAvailable scripts:")
    scripts = get_available_scripts()
    for noun, verbs in scripts.items():
        prefix = f"- {noun}: "
        indent = " " * len(prefix)
        for i, verb in enumerate(verbs):
            if i == 0:
                print(f"{prefix}{verb}")
            else:
                print(f"{indent}{verb}")


def get_available_scripts() -> dict[str, list[str]]:
    scripts: dict[str, list[str]] = {"yourself": ["check", "show"]}
    tardy_dir = get_tardy_dir()
    if tardy_dir.exists():
        for path in tardy_dir.rglob("*"):
            if not path.is_file():
                continue
            rel_path = path.relative_to(tardy_dir)
            parts = rel_path.parts
            verb, noun = None, None
            if len(parts) == 1:
                name_parts = parts[0].rsplit(".", 1)
                if len(name_parts) == 2:
                    verb, noun = name_parts
            elif len(parts) == 2:
                folder_noun = parts[0]
                name_parts = parts[1].rsplit(".", 1)
                if len(name_parts) == 2:
                    v, n = name_parts
                    if folder_noun == n:
                        verb, noun = v, n
            if verb and noun:
                if noun not in scripts:
                    scripts[noun] = []
                if verb not in scripts[noun]:
                    scripts[noun].append(verb)

    return {n: sorted(scripts[n]) for n in sorted(scripts.keys())}


def show_tardyon_folder() -> None:
    target = get_tardy_dir()
    target.mkdir(parents=True, exist_ok=True)

    opened = False
    if sys.platform == "win32":
        try:
            os.startfile(target)
            opened = True
        except (AttributeError, OSError):
            pass
    elif sys.platform == "darwin":
        try:
            subprocess.run(["open", str(target)], check=True)
            opened = True
        except (subprocess.CalledProcessError, FileNotFoundError):
            pass
    else:
        try:
            subprocess.run(["xdg-open", str(target)], check=True)
            opened = True
        except (subprocess.CalledProcessError, FileNotFoundError):
            pass

    if not opened:
        print(target)


def check_yourself() -> None:
    tardy_dir = get_tardy_dir()
    if not tardy_dir.exists():
        return

    scripts: dict[tuple[str, str], Path] = {}

    for path in sorted(tardy_dir.rglob("*")):
        if not path.is_file():
            continue

        rel_path = path.relative_to(tardy_dir)
        parts = rel_path.parts

        verb, noun = None, None
        if len(parts) == 1:
            # flat: verb.noun
            name_parts = parts[0].rsplit(".", 1)
            if len(name_parts) == 2:
                verb, noun = name_parts
        elif len(parts) == 2:
            # nested: noun/verb.noun
            folder_noun = parts[0]
            name_parts = parts[1].rsplit(".", 1)
            if len(name_parts) == 2:
                v, n = name_parts
                if folder_noun == n:
                    verb, noun = v, n

        if verb is None or noun is None:
            print(
                f"Error: {path} does not match pattern verb.noun or noun/verb.noun",
                file=sys.stderr,
            )
            continue

        key = (verb, noun)
        if key in scripts:
            print(
                f"Error: Duplicate found for {verb} {noun}: {path} and {scripts[key]}",
                file=sys.stderr,
            )
            continue

        scripts[key] = path

        if not os.access(path, os.X_OK):
            try:
                path.chmod(path.stat().st_mode | 0o111)
            except OSError as e:
                print(f"Error: Could not fix permissions for {path}: {e}", file=sys.stderr)

    print("Check complete.")


def launch_tardyon_script(verb: str, noun: str, args: list[str]) -> NoReturn:
    tardy_dir = get_tardy_dir()
    nested_path = tardy_dir / noun / f"{verb}.{noun}"
    flat_path = tardy_dir / f"{verb}.{noun}"

    if nested_path.exists():
        script_path = nested_path
    elif flat_path.exists():
        script_path = flat_path
    else:
        raise FileNotFoundError(f"{nested_path} does not exist")

    if not os.access(script_path, os.X_OK):
        raise PermissionError(f"{script_path} is not executable")

    os.execv(str(script_path), [str(script_path)] + args)


if __name__ == "__main__":
    invoke()
