# tardyon

If you write custom scripts, tardyon helps you maintain and invoke them.

## Usage

### Example script

Save the following script as `$HOME/.local/bin/tardy/all/upgrade.all`

```shell
#!/bin/sh

# Escalate session once
sudo -v || exit 1

# Update and upgrade APT packages
sudo apt update && sudo apt upgrade -y

# Update Flatpak packages
flatpak update -y
```

You can now call `tardyon upgrade all` to upgrade packages across all your package managers
(in this example, APT and Flatpak).

### Organizing scripts

Tardyon follows a strict but simple organizing principle: `tardyon foo bar` will invoke the script
`$HOME/.local/bin/tardy/bar/foo.bar`

Commands are shaped like ordinary English clauses, an imperative with a vocative.
So you write `tardyon clear cache` rather than `tardyon cache clear`.

Scripts can be any executable file with a shebang, or even a compiled binary.

### Show yourself

Tardyon has one special command, `tardyon show yourself`. This opens the folder containing your tardyon scripts.

## Development environment

Initialize with `uv sync`. Test with `uv run pytest`.

## Release

```shell
git tag -a 2.0.0 -m "Version 2.0.0"
uv build
uv publish  # uses tag for version number
```

# Sharing and contributions

```
tardyon
https://lofidevops.neocities.org
Copyright 2023 David Seaward and contributors
SPDX-License-Identifier: AGPL-3.0-or-later
```

Shared under AGPL-3.0-or-later. We adhere to the Contributor Covenant 2.1, and
certify origin per DCO 1.1 with a signed-off-by line. Contributions under the
same terms are welcome.

Submit security and conduct issues as private tickets. Sign commits with
`git commit --signoff`. For a software bill of materials run `reuse spdx`.

# Colophon

Originally inspired by [Ansible](https://docs.ansible.com) but with subluminal ambition.
