# SPDX-License-Identifier: AGPL-3.0-or-later
# SPDX-FileCopyrightText: Copyright 2023 David Seaward and contributors

import io
import os
from pathlib import Path
from unittest.mock import patch

import pytest

from tardyon import cli


def test_print_metadata():
    with (
        patch("tardyon.cli.metadata.version", return_value="5.0.0"),
        patch("sys.stdout", new_callable=io.StringIO) as mock_stdout,
    ):
        cli.print_metadata()
        output = mock_stdout.getvalue()
        assert "tardyon v5.0.0\n" in output
        assert 'Call "tardyon VERB NOUN"\n' in output


def test_print_metadata_unknown():
    from importlib import metadata

    with (
        patch(
            "tardyon.cli.metadata.version", side_effect=metadata.PackageNotFoundError
        ),
        patch("sys.stdout", new_callable=io.StringIO) as mock_stdout,
    ):
        cli.print_metadata()
        output = mock_stdout.getvalue()
        assert "tardyon vunknown\n" in output
        assert 'Call "tardyon VERB NOUN"\n' in output


def test_show_tardyon_folder_linux():
    mock_home = Path("/tmp/mock_home")
    target = mock_home / ".local" / "bin" / "tardy"
    with (
        patch("pathlib.Path.home", return_value=mock_home),
        patch("pathlib.Path.mkdir") as mock_mkdir,
        patch("sys.platform", "linux"),
        patch("subprocess.run") as mock_run,
    ):
        cli.show_tardyon_folder()
        mock_mkdir.assert_called_once_with(parents=True, exist_ok=True)
        mock_run.assert_called_once_with(["xdg-open", str(target)], check=True)


def test_show_tardyon_folder_windows():
    mock_home = Path("/tmp/mock_home")
    target = mock_home / ".local" / "bin" / "tardy"
    with (
        patch("pathlib.Path.home", return_value=mock_home),
        patch("pathlib.Path.mkdir") as mock_mkdir,
        patch("sys.platform", "win32"),
        patch("os.startfile", create=True) as mock_startfile,
    ):
        cli.show_tardyon_folder()
        mock_mkdir.assert_called_once_with(parents=True, exist_ok=True)
        mock_startfile.assert_called_once_with(target)


def test_show_tardyon_folder_macos():
    mock_home = Path("/tmp/mock_home")
    target = mock_home / ".local" / "bin" / "tardy"
    with (
        patch("pathlib.Path.home", return_value=mock_home),
        patch("pathlib.Path.mkdir") as mock_mkdir,
        patch("sys.platform", "darwin"),
        patch("subprocess.run") as mock_run,
    ):
        cli.show_tardyon_folder()
        mock_mkdir.assert_called_once_with(parents=True, exist_ok=True)
        mock_run.assert_called_once_with(["open", str(target)], check=True)


def test_show_tardyon_folder_fallback():
    mock_home = Path("/tmp/mock_home")
    target = mock_home / ".local" / "bin" / "tardy"
    with (
        patch("pathlib.Path.home", return_value=mock_home),
        patch("pathlib.Path.mkdir") as mock_mkdir,
        patch("sys.platform", "linux"),
        patch("subprocess.run", side_effect=FileNotFoundError),
        patch("sys.stdout", new_callable=io.StringIO) as mock_stdout,
    ):
        cli.show_tardyon_folder()
        mock_mkdir.assert_called_once_with(parents=True, exist_ok=True)
        assert str(target) in mock_stdout.getvalue()


def test_launch_tardyon_script_happy_path():
    mock_home = Path("/tmp/mock_home")
    expected_path = str(mock_home / ".local" / "bin" / "tardy" / "bar" / "foo.bar")
    with (
        patch("pathlib.Path.home", return_value=mock_home),
        patch("pathlib.Path.exists", return_value=True),
        patch("os.access", return_value=True),
        patch("os.execv", side_effect=SystemExit(0)) as mock_execv,
    ):
        with pytest.raises(SystemExit):
            cli.launch_tardyon_script("foo", "bar", ["extra"])
        mock_execv.assert_called_once_with(expected_path, [expected_path, "extra"])


def test_launch_tardyon_script_failure():
    mock_home = Path("/tmp/mock_home")
    with (
        patch("pathlib.Path.home", return_value=mock_home),
        patch("pathlib.Path.exists", return_value=True),
        patch("os.access", return_value=True),
        patch("os.execv", side_effect=OSError("denied")),
    ):
        with pytest.raises(OSError, match="denied"):
            cli.launch_tardyon_script("foo", "bar", [])


def test_launch_tardyon_script_not_found():
    mock_home = Path("/tmp/mock_home")
    with (
        patch("pathlib.Path.home", return_value=mock_home),
        patch("pathlib.Path.exists", return_value=False),
    ):
        with pytest.raises(FileNotFoundError, match="does not exist"):
            cli.launch_tardyon_script("foo", "bar", [])


def test_launch_tardyon_script_not_executable():
    mock_home = Path("/tmp/mock_home")
    with (
        patch("pathlib.Path.home", return_value=mock_home),
        patch("pathlib.Path.exists", return_value=True),
        patch("os.access", return_value=False),
    ):
        with pytest.raises(PermissionError, match="is not executable"):
            cli.launch_tardyon_script("foo", "bar", [])


def test_invoke_zero_arguments():
    with (
        patch("sys.argv", ["tardyon"]),
        patch("tardyon.cli.print_help") as mock_print,
        patch("sys.exit") as mock_exit,
    ):
        cli.invoke()
        mock_print.assert_called_once()
        mock_exit.assert_called_once_with(0)


def test_invoke_one_argument():
    with (
        patch("sys.argv", ["tardyon", "foo"]),
        patch("tardyon.cli.print_help") as mock_print,
        patch("sys.exit") as mock_exit,
    ):
        cli.invoke()
        mock_print.assert_called_once()
        mock_exit.assert_called_once_with(1)


def test_invoke_help_argument():
    with (
        patch("sys.argv", ["tardyon", "--help"]),
        patch("tardyon.cli.print_help") as mock_print,
        patch("sys.exit") as mock_exit,
    ):
        cli.invoke()
        mock_print.assert_called_once()
        mock_exit.assert_called_once_with(0)


def test_invoke_version_argument():
    with (
        patch("sys.argv", ["tardyon", "--version"]),
        patch("tardyon.cli.print_metadata") as mock_print,
        patch("sys.exit") as mock_exit,
    ):
        cli.invoke()
        mock_print.assert_called_once()
        mock_exit.assert_called_once_with(0)


def test_invoke_show_yourself():
    with (
        patch("sys.argv", ["tardyon", "show", "yourself"]),
        patch("tardyon.cli.show_tardyon_folder") as mock_show,
        patch("sys.exit") as mock_exit,
    ):
        cli.invoke()
        mock_show.assert_called_once()
        mock_exit.assert_called_once_with(0)


def test_invoke_launch_script():
    with (
        patch("sys.argv", ["tardyon", "foo", "bar", "extra"]),
        patch("tardyon.cli.launch_tardyon_script") as mock_launch,
    ):
        cli.invoke()
        mock_launch.assert_called_once_with("foo", "bar", ["extra"])


def test_invoke_launch_script_error():
    with (
        patch("sys.argv", ["tardyon", "foo", "bar"]),
        patch(
            "tardyon.cli.launch_tardyon_script",
            side_effect=FileNotFoundError("oops"),
        ),
        patch("sys.stderr", new_callable=io.StringIO) as mock_stderr,
        patch("sys.exit") as mock_exit,
    ):
        cli.invoke()
        assert "Script could not be invoked: oops" in mock_stderr.getvalue()
        mock_exit.assert_called_once_with(1)


def test_invoke_show_other():
    # If it's not "show yourself", it should try to launch a script
    # e.g. "tardyon show something" -> verb="show", noun="something"
    with (
        patch("sys.argv", ["tardyon", "show", "something"]),
        patch("tardyon.cli.launch_tardyon_script") as mock_launch,
    ):
        cli.invoke()
        mock_launch.assert_called_once_with("show", "something", [])


def test_invoke_multiple_args():
    with (
        patch("sys.argv", ["tardyon", "foo", "bar", "extra1", "extra2"]),
        patch("tardyon.cli.launch_tardyon_script") as mock_launch,
    ):
        cli.invoke()
        mock_launch.assert_called_once_with("foo", "bar", ["extra1", "extra2"])


def test_launch_tardyon_script_flat_path():
    mock_home = Path("/tmp/mock_home")
    expected_path = str(mock_home / ".local" / "bin" / "tardy" / "foo.bar")

    def mock_exists(self):
        return str(self) == expected_path

    with (
        patch("pathlib.Path.home", return_value=mock_home),
        patch("pathlib.Path.exists", side_effect=mock_exists, autospec=True),
        patch("os.access", return_value=True),
        patch("os.execv", side_effect=SystemExit(0)) as mock_execv,
    ):
        with pytest.raises(SystemExit):
            cli.launch_tardyon_script("foo", "bar", [])
        mock_execv.assert_called_once_with(expected_path, [expected_path])


def test_launch_tardyon_script_prefers_nested():
    mock_home = Path("/tmp/mock_home")
    nested_path = str(mock_home / ".local" / "bin" / "tardy" / "bar" / "foo.bar")

    with (
        patch("pathlib.Path.home", return_value=mock_home),
        patch("pathlib.Path.exists", return_value=True),  # Both exist
        patch("os.access", return_value=True),
        patch("os.execv", side_effect=SystemExit(0)) as mock_execv,
    ):
        with pytest.raises(SystemExit):
            cli.launch_tardyon_script("foo", "bar", [])
        mock_execv.assert_called_once_with(nested_path, [nested_path])


def test_invoke_check_yourself():
    with (
        patch("sys.argv", ["tardyon", "check", "yourself"]),
        patch("tardyon.cli.check_yourself") as mock_check,
        patch("sys.exit") as mock_exit,
    ):
        cli.invoke()
        mock_check.assert_called_once()
        mock_exit.assert_called_once_with(0)


def test_check_yourself_success(tmp_path):
    tardy_dir = tmp_path / ".local" / "bin" / "tardy"
    tardy_dir.mkdir(parents=True)

    # Flat script
    flat = tardy_dir / "verb1.noun1"
    flat.write_text("content")
    flat.chmod(0o755)

    # Nested script
    nested_dir = tardy_dir / "noun2"
    nested_dir.mkdir()
    nested = nested_dir / "verb2.noun2"
    nested.write_text("content")
    nested.chmod(0o755)

    with patch("tardyon.cli.get_tardy_dir", return_value=tardy_dir):
        with patch("sys.stderr", new_callable=io.StringIO) as mock_stderr:
            cli.check_yourself()
            assert mock_stderr.getvalue() == ""


def test_check_yourself_invalid_pattern(tmp_path):
    tardy_dir = tmp_path / ".local" / "bin" / "tardy"
    tardy_dir.mkdir(parents=True)

    # Invalid flat file (no dot)
    invalid1 = tardy_dir / "invalid1"
    invalid1.write_text("content")

    # Invalid nested file (wrong extension)
    nested_dir = tardy_dir / "noun2"
    nested_dir.mkdir()
    invalid2 = nested_dir / "verb2.wrong"
    invalid2.write_text("content")

    # Too deep
    deep_dir = tardy_dir / "level1" / "level2"
    deep_dir.mkdir(parents=True)
    invalid3 = deep_dir / "verb.noun"
    invalid3.write_text("content")

    with patch("tardyon.cli.get_tardy_dir", return_value=tardy_dir):
        with patch("sys.stderr", new_callable=io.StringIO) as mock_stderr:
            cli.check_yourself()
            output = mock_stderr.getvalue()
            assert "Error" in output
            assert str(invalid1) in output
            assert str(invalid2) in output
            assert str(invalid3) in output


def test_check_yourself_duplicates(tmp_path):
    tardy_dir = tmp_path / ".local" / "bin" / "tardy"
    tardy_dir.mkdir(parents=True)

    # Flat
    flat = tardy_dir / "verb.noun"
    flat.write_text("content")

    # Nested (duplicate)
    nested_dir = tardy_dir / "noun"
    nested_dir.mkdir()
    nested = nested_dir / "verb.noun"
    nested.write_text("content")

    with patch("tardyon.cli.get_tardy_dir", return_value=tardy_dir):
        with patch("sys.stderr", new_callable=io.StringIO) as mock_stderr:
            cli.check_yourself()
            output = mock_stderr.getvalue()
            assert "Duplicate found for verb noun" in output


def test_check_yourself_fix_permissions(tmp_path):
    tardy_dir = tmp_path / ".local" / "bin" / "tardy"
    tardy_dir.mkdir(parents=True)

    script = tardy_dir / "verb.noun"
    script.write_text("content")
    script.chmod(0o644)  # Not executable

    # On some systems, os.access might still return True if the user is root,
    # but in a typical test environment it should be False.
    # However, Path.chmod should work anyway.

    with patch("tardyon.cli.get_tardy_dir", return_value=tardy_dir):
        cli.check_yourself()

    assert os.access(script, os.X_OK)


def test_print_help(tmp_path):
    tardy_dir = tmp_path / "tardy"
    tardy_dir.mkdir()
    (tardy_dir / "verb1.noun1").write_text("")
    (tardy_dir / "noun2").mkdir()
    (tardy_dir / "verb2.noun2").write_text("")
    (tardy_dir / "verb3.noun2").write_text("")

    with (
        patch("tardyon.cli.get_tardy_dir", return_value=tardy_dir),
        patch("tardyon.cli.metadata.version", return_value="1.0.0"),
        patch("sys.stdout", new_callable=io.StringIO) as mock_stdout,
    ):
        cli.print_help()
        output = mock_stdout.getvalue()
        assert "tardyon v1.0.0" in output
        assert "Available scripts:" in output
        assert "- noun1: verb1" in output
        assert "- noun2: verb2" in output
        assert "         verb3" in output
        assert "- yourself: check" in output
        assert "           show" in output
