from __future__ import annotations

import json
import logging
from datetime import datetime
from pathlib import Path

import matplotlib.pyplot as plt
import typer
from module_qc_data_tools import (
    load_json,
    save_dict_list,
)

from module_qc_analysis_tools.analysis.hv_group_iv_measure import (
    analyse,
)
from module_qc_analysis_tools.cli.globals import (
    CONTEXT_SETTINGS,
    OPTIONS,
    LogLevel,
)

app = typer.Typer(context_settings=CONTEXT_SETTINGS)

TEST_TYPE = "HV_GROUP_IV_MEASURE"


@app.command()
def main(
    input_meas: Path = OPTIONS["input_meas"],
    base_output_dir: Path = OPTIONS["output_dir"],
    qc_criteria_path: Path = OPTIONS["qc_criteria"],
    site: str = OPTIONS["site"],
    verbosity: LogLevel = OPTIONS["verbosity"],
):
    """
    Performs the IV Measure LLS analysis.

    It produces the IV curve plots with breakdown detection and an output file with the qualification control tests results
    """
    time_start = datetime.now().strftime("%Y-%m-%d_%H%M%S")
    output_dir = base_output_dir.joinpath(TEST_TYPE).joinpath(f"{time_start}")
    output_dir.mkdir(parents=True, exist_ok=False)

    log = logging.getLogger("analysis")
    log.setLevel(verbosity.value)
    log.addHandler(logging.FileHandler(f"{output_dir}/output.log"))

    # Turn off matplotlib DEBUG messages
    plt.set_loglevel(level="warning")
    # Turn off pytest DEBUG messages
    pil_logger = logging.getLogger("PIL")
    pil_logger.setLevel(logging.INFO)

    log.info("")
    log.info(" ===============================================")
    log.info(" \tPerforming IV MEASURE LLS analysis")
    log.info(" ===============================================")
    log.info("")

    if not input_meas.is_dir():
        msg = "input_meas must be a directory containing both the hv_file and the modules_files, got: {}"
        raise ValueError(msg.format(input_meas))

    metadata_path = input_meas / "metadata.json"

    if not metadata_path.exists():
        msg = f"Metadata file not found at: {metadata_path}"
        raise FileNotFoundError(msg)

    with Path.open(metadata_path, "r", encoding="utf-8") as f:
        metadata = json.load(f)

    # Extract HV Group Info
    hv_group_data = metadata.get("hv_group", {})
    hv_filename = hv_group_data.get("raw_file_name")

    if not hv_filename:
        msg = "Metadata is missing 'raw_file_name' for the HV group."
        raise ValueError(msg)

    hv_file = input_meas / hv_filename

    if not hv_file.exists():
        msg = "HV file defined in metadata does not exist: {hv_file}"
        raise FileNotFoundError(msg)

    # Extract Module Info
    modules_files = []
    for module in hv_group_data.get("modules", []):
        module_filename = module.get("raw_file_name")

        if module_filename:
            module_path = input_meas / module_filename

            # Validate module file existence
            if not module_path.exists():
                msg = f"Module file defined in metadata does not exist: {module_path}"
                raise FileNotFoundError(msg)

            modules_files.append(module_path)

    log.info(f"Loaded HV File: {hv_file.name}")
    log.info(f"Loaded {len(modules_files)} Module Files.")

    input_hv_data = load_json(Path(hv_file))[0]

    input_modules_data_list = [
        load_json(module_file)[0] for module_file in modules_files
    ]

    output_df, _ = analyse(
        input_hv_data,
        input_modules_data_list,
        metadata,
        qc_criteria_path,
        output_dir,
        site,
    )

    alloutput = []
    alloutput.append(output_df.to_dict(True))

    outfile = output_dir.joinpath("analysis_results.json")
    log.info(f"Saving output of analysis to: {outfile}")
    save_dict_list(outfile, alloutput)


if __name__ == "__main__":
    typer.run(main)
