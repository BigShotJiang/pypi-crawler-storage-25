from __future__ import annotations

import logging
from pathlib import Path

import arrow
import matplotlib.pyplot as plt
import numpy as np
from module_qc_data_tools import (
    outputDataFrame,
    qcDataFrame,
)
from scipy.interpolate import interp1d

from module_qc_analysis_tools import __version__
from module_qc_analysis_tools import data as data_path
from module_qc_analysis_tools.utils.analysis import (
    find_breakdown_and_current_tim,
    normalise_current,
    perform_qc_analysis,
)
from module_qc_analysis_tools.utils.misc import (
    JsonChecker,
    bcolors,
    convert_prefix,
    get_qc_config,
)

TEST_TYPE = "HV_GROUP_IV_MEASURE"

log = logging.getLogger(f"analysis.{TEST_TYPE}")

COLOR_CONFIG = {
    "hv": "black",
    "sum": "red",
    "modules": [
        "blue",
        "green",
        "purple",
        "orange",
        "cyan",
        "magenta",
    ],
}

MARK_CONFIG = {
    "hv": "o",
    "sum": "s",
    "modules": ["^", "D", "v", "p", "h", "<", ">", "*", "x", "+"],
}


def get_breakdown_plot_lines(voltages, currents, breakdown_voltage):
    """
    Helper function to generate plot lines for breakdown visualization.
    Re-calculates linear polyfits on log-currents split by the breakdown voltage.
    """
    if breakdown_voltage == -999:
        return None, None, None, None

    voltages_fit = voltages[2:]
    currents_log = np.log(currents[2:])

    # Split data based on breakdown voltage
    mask_pre = voltages_fit <= breakdown_voltage
    mask_post = voltages_fit > breakdown_voltage

    # Fit Pre-breakdown
    poly_pre = np.polyfit(voltages_fit[mask_pre], currents_log[mask_pre], 1)

    # Fit Post-breakdown
    poly_post = np.polyfit(voltages_fit[mask_post], currents_log[mask_post], 1)

    # Generate Y values
    v_pre = voltages_fit[mask_pre]
    # include the breakdown voltage point for continuity
    v_pre_draw = np.append(v_pre, breakdown_voltage)
    y_pre_draw = poly_pre[0] * v_pre_draw + poly_pre[1]

    v_post = voltages_fit[mask_post]
    # include the breakdown voltage point for continuity
    v_post_draw = np.insert(v_post, 0, breakdown_voltage)
    y_post_draw = poly_post[0] * v_post_draw + poly_post[1]

    return v_pre_draw, y_pre_draw, v_post_draw, y_post_draw


def analyse(
    hv_data: outputDataFrame,
    modules_data_list: list[outputDataFrame],
    run_metadata: dict,
    qc_criteria_path: Path,
    output_dir: Path,
    site: str = "",
):
    # Check file integrity
    hv_checker = JsonChecker(hv_data, TEST_TYPE)

    try:
        hv_checker.check()
    except BaseException as exc:
        log.exception(exc)
        log.warning(
            bcolors.WARNING
            + " JsonChecker check not passed, skipping this input."
            + bcolors.ENDC
        )
        return None

    for module in modules_data_list:
        module_checker = JsonChecker(module, "IV_MEASURE")

        try:
            module_checker.check()
        except BaseException as exc:
            log.exception(exc)
            log.warning(
                bcolors.WARNING
                + " JsonChecker check not passed, skipping this input."
                + bcolors.ENDC
            )
            return None

    log.debug(" JsonChecker check passed!")

    hv_results = hv_data.get_results()

    # Get info
    metadata = hv_results.get_meta_data()
    institution = metadata.get("Institution")
    if site != "" and institution != "":
        log.warning(
            bcolors.WARNING
            + f" Overwriting default institution {institution} with manual input {site}!"
            + bcolors.ENDC
        )
        institution = site
    elif site != "":
        institution = site

    if institution == "":
        log.error(
            bcolors.ERROR
            + "No institution found. Please specify your testing site either in the measurement data or specify with the --site option. "
            + bcolors.ENDC
        )
        return None

    # Load config
    qc_config = get_qc_config(
        qc_criteria_path or data_path / "analysis_cuts.json",
        TEST_TYPE,
    )

    # Create figure with two subplots (top for IV curve, bottom for breakdown detection)
    plt.figure(figsize=(10, 8))
    upper_plot = plt.subplot(2, 1, 1)
    lower_plot = plt.subplot(2, 1, 2)

    # Standardize current and voltage to positive values
    hv_voltage = np.abs(hv_results["voltage"])
    hv_current = np.abs(hv_results["current"])

    # Standardize to SI
    hv_voltage = np.array(
        convert_prefix(
            hv_voltage,
            inprefix=hv_results.get_unit("voltage"),
            targetprefix="",
        )
    )
    hv_current = np.array(
        convert_prefix(
            hv_current,
            inprefix=hv_results.get_unit("current"),
            targetprefix="",
        )
    )

    # Save HV modules ground voltages
    hv_modules_ground_voltages = {}
    for i in range(len(metadata["ModuleSN"])):
        hv_modules_ground_voltages[metadata["ModuleSN"][i]] = convert_prefix(
            metadata["moduleGroundVoltage"][i], hv_results.get_unit("voltage"), ""
        )

    # Save modules data
    modules_data = {}
    for module_data in modules_data_list:
        # Shift voltage to HV chain corresponding ground voltage
        module_voltage = np.abs(module_data.get_results()["voltage"])
        module_voltage = np.array(
            convert_prefix(
                module_voltage, module_data.get_results().get_unit("voltage"), ""
            )
        )
        ground_voltage = np.array(
            convert_prefix(
                hv_modules_ground_voltages[module_data._serialNumber],
                module_data.get_results().get_unit("voltage"),
                "",
            )
        )
        shifted_voltage = module_voltage + ground_voltage
        module_current = np.abs(module_data.get_results()["current"])
        module_current = np.array(
            convert_prefix(
                module_current, module_data.get_results().get_unit("current"), ""
            )
        )

        modules_data[module_data._serialNumber] = {
            "current": module_current,
            "voltage": shifted_voltage,
            "temperature": module_data.get_results()["temperature"],
        }

    module_index = {sn: i for i, sn in enumerate(metadata["ModuleSN"])}

    for serial_number in metadata["ModuleSN"]:
        idx = module_index[serial_number]

        # Extract the per-module temperature array from the HV scan
        module_temp_values = np.array([t[idx] for t in hv_results["temperature"]])

        module_data = modules_data[serial_number]

        # Create an interpolation function for the HV temperatures
        hv_temp_interp = interp1d(
            hv_voltage,
            module_temp_values,
            kind="linear",
            bounds_error=False,
            fill_value="extrapolate",
        )

        # Interpolate the HV temperatures onto this specific module's voltage grid
        target_temps_at_module_voltages = hv_temp_interp(module_data["voltage"])

        # Apply point-by-point normalization
        module_data["current"] = normalise_current(
            module_data["current"],
            module_data["temperature"],
            target_temps_at_module_voltages,
        )

    # Plot HV chain data
    upper_plot.errorbar(
        hv_voltage,
        np.array(convert_prefix(hv_current, "", "uA")),
        yerr=convert_prefix(
            np.abs(hv_results["sigma current"]),
            hv_results.get_unit("current"),
            "uA",
        ),
        fmt="-o",
        label=f"{hv_data._serialNumber}",
        markersize=5,
        color=COLOR_CONFIG["hv"],
        linewidth=2,
        zorder=3,
    )

    modules_current_sum = np.zeros_like(hv_results["current"])
    for module_index, (module_serial_number, module_data) in enumerate(
        modules_data.items()
    ):
        # Standardize module voltage and current to HV voltage through linear extrapolation
        interpolation_function = interp1d(
            module_data["voltage"],
            module_data["current"],
            kind="linear",
            bounds_error=False,
            fill_value="extrapolate",
        )

        module_current_interpolated = interpolation_function(hv_voltage)
        modules_current_sum += module_current_interpolated

        # Plot module data
        upper_plot.errorbar(
            hv_voltage,
            convert_prefix(module_current_interpolated, "", "uA"),
            fmt="-o",
            color=COLOR_CONFIG["modules"][module_index % len(COLOR_CONFIG["modules"])],
            markersize=5,
            linewidth=2,
            zorder=2,
            label=f"Module: {module_serial_number}",
        )

    # Plot IV sum
    upper_plot.errorbar(
        hv_voltage,
        convert_prefix(modules_current_sum, "", "uA"),
        fmt="-o",
        color=COLOR_CONFIG["sum"],
        markersize=5,
        linewidth=2,
        zorder=2,
        label="Module IV sum",
    )

    upper_plot.set_xlabel("Bias Voltage [V]")
    upper_plot.set_ylabel("Leakage Current [uA]")
    upper_plot.grid(True)

    # CALCULATE BREAKDOWN AND LEAKAGE
    # Calculate for HV Chain
    hv_bd_voltage, hv_leakage_current = find_breakdown_and_current_tim(
        voltages=hv_voltage,
        currents=hv_current,
        slope_ratio_range=qc_config["NON_BREAKDOWN_SLOPE_RATIO_RANGE"]["sel"],
        leakage_eval_voltage=qc_config["LEAKAGE_CURRENT_EVALUATION_POINT"]["sel"][0],
    )

    # Calculate for Module Sum
    sum_bd_voltage, sum_leakage_current = find_breakdown_and_current_tim(
        voltages=hv_voltage,
        currents=modules_current_sum,
        slope_ratio_range=qc_config["NON_BREAKDOWN_SLOPE_RATIO_RANGE"]["sel"],
        leakage_eval_voltage=qc_config["LEAKAGE_CURRENT_EVALUATION_POINT"]["sel"][0],
    )

    log.info(f"HV Leakage current: {hv_leakage_current}")
    log.info(f"Modules sum leakage current: {sum_leakage_current}")

    # Plotting lower plot (Breakdown Detection)
    # Plot raw log data
    lower_plot.plot(
        hv_voltage,
        np.log(hv_current),
        "o",
        color=COLOR_CONFIG["hv"],
        linewidth=2,
    )

    lower_plot.plot(
        hv_voltage,
        np.log(modules_current_sum),
        "o",
        color=COLOR_CONFIG["sum"],
        linewidth=2,
    )

    # --- Reconstruct fit lines for HV Chain plotting ---
    if hv_bd_voltage is not None:
        v_pre, y_pre, v_post, y_post = get_breakdown_plot_lines(
            hv_voltage, hv_current, hv_bd_voltage
        )
        if v_pre is not None:
            # Plot pre-breakdown line
            lower_plot.plot(
                v_pre, y_pre, "--", color=COLOR_CONFIG["hv"], linewidth=2, alpha=0.5
            )
            # Plot post-breakdown line
            lower_plot.plot(
                v_post, y_post, "--", color=COLOR_CONFIG["hv"], linewidth=2, alpha=0.5
            )

            log.info(f"Breakdown voltage for HV chain at {hv_bd_voltage:.1f}V")

            upper_plot.axvline(
                hv_bd_voltage,
                linewidth=2,
                color=COLOR_CONFIG["hv"],
                linestyle="--",
            )
            lower_plot.axvline(
                hv_bd_voltage,
                linewidth=2,
                color=COLOR_CONFIG["hv"],
                linestyle="--",
                label=f"HV chain breakdown: {hv_bd_voltage:.1f}V",
            )

    # --- Reconstruct fit lines for Module Sum plotting ---
    if sum_bd_voltage is not None:
        v_pre, y_pre, v_post, y_post = get_breakdown_plot_lines(
            hv_voltage, modules_current_sum, sum_bd_voltage
        )
        if v_pre is not None:
            # Plot pre-breakdown line
            lower_plot.plot(
                v_pre, y_pre, "--", color=COLOR_CONFIG["sum"], linewidth=2, alpha=0.5
            )
            # Plot post-breakdown line
            lower_plot.plot(
                v_post, y_post, "--", color=COLOR_CONFIG["sum"], linewidth=2, alpha=0.5
            )

            log.info(f"Breakdown voltage for module sum at {sum_bd_voltage:.1f}V")

            upper_plot.axvline(
                sum_bd_voltage,
                linewidth=2,
                color=COLOR_CONFIG["sum"],
                linestyle="--",
            )
            lower_plot.axvline(
                sum_bd_voltage,
                linewidth=2,
                color=COLOR_CONFIG["sum"],
                linestyle="--",
                label=f"Sum breakdown: {sum_bd_voltage:.1f}V",
            )

    # Configure lower plot
    lower_plot.set_xlabel(f"Bias Voltage [{hv_results.get_unit('voltage')}]")
    lower_plot.set_ylabel(
        f"Logarithm of current [Log[{hv_results.get_unit('current')}]]"
    )
    lower_plot.grid(True)

    # Legends
    lower_plot.legend(loc="upper left")
    upper_plot.legend(loc="upper left")

    # Save figure
    plt.tight_layout()
    iv_curves_plot_path = output_dir.joinpath("IV_curves_comparison.png")
    plt.savefig(iv_curves_plot_path)
    log.info(f"IV curves LLS plot saved to: {iv_curves_plot_path}")
    plt.close()

    # -------------------------------------------------------------------------
    # QC CHECKS
    # -------------------------------------------------------------------------

    if hv_bd_voltage is None and sum_bd_voltage is None:
        log.info(
            "No breakdown detected for either HV chain or module sum. Passing breakdown check."
        )
        breakdown_voltage_ratio = 1.0
    elif hv_bd_voltage is None or sum_bd_voltage is None:
        log.warning(
            "FAILED: Breakdown detected for either HV chain or module sum, but not both."
        )
        breakdown_voltage_ratio = -999
    else:
        breakdown_voltage_ratio = hv_bd_voltage / sum_bd_voltage

    leakage_current_ratio = hv_leakage_current / sum_leakage_current

    results_to_check = {
        "BREAKDOWN_VOLTAGE_PASS_RATIO": breakdown_voltage_ratio,
        "LEAKAGE_CURRENT_PASS_RATIO": leakage_current_ratio,
    }

    LLS_passes_QC, _, rounded_results = perform_qc_analysis(
        test_type=TEST_TYPE,
        qc_selections=qc_config,
        layer_name="L0",  # Safely bypasses the strict layer check
        results=results_to_check,
        check=False,  # Prevents warning about unused cuts
    )

    if LLS_passes_QC:
        log.info(
            " LLS passes QC? " + bcolors.OKGREEN + f"{LLS_passes_QC}" + bcolors.ENDC
        )
    else:
        log.info(
            " LLS passes QC? " + bcolors.BADRED + f"{LLS_passes_QC}" + bcolors.ENDC
        )
    log.info("")

    rounded_bd_ratio = rounded_results.get("BREAKDOWN_VOLTAGE_PASS_RATIO", -999)
    bd_cuts = qc_config["BREAKDOWN_VOLTAGE_PASS_RATIO"]["sel"]
    breakdown_voltage_pass = bd_cuts[0] <= rounded_bd_ratio <= bd_cuts[1]

    rounded_lc_ratio = rounded_results.get("LEAKAGE_CURRENT_PASS_RATIO", -999)
    lc_cuts = qc_config["LEAKAGE_CURRENT_PASS_RATIO"]["sel"]
    leakage_current_pass = lc_cuts[0] <= rounded_lc_ratio <= lc_cuts[1]

    ANALYSIS_IV_ARRAY = {
        "voltage": hv_voltage.tolist(),
        "current": convert_prefix(hv_current.tolist(), "", "uA"),
        "current_estimate": convert_prefix(modules_current_sum.tolist(), "", "uA"),
    }

    HV_results = {
        "ANALYSIS_IV_ARRAY": ANALYSIS_IV_ARRAY,
        "NON_BREAKDOWN_SLOPE_RATIO_RANGE": qc_config["NON_BREAKDOWN_SLOPE_RATIO_RANGE"][
            "sel"
        ],
        "HV_GROUP_BREAKDOWN_VOLTAGE": (
            hv_bd_voltage if hv_bd_voltage is not None else -999
        ),
        "MODULE_SUM_BREAKDOWN_VOLTAGE": (
            sum_bd_voltage if sum_bd_voltage is not None else -999
        ),
        "BREAKDOWN_VOLTAGE_RATIO": rounded_bd_ratio,
        "BREAKDOWN_VOLTAGE_PASS_RATIO": bd_cuts,
        "BREAKDOWN_VOLTAGE_PASS": bool(breakdown_voltage_pass),
        "LEAKAGE_CURRENT_EVALUATION_POINT": qc_config[
            "LEAKAGE_CURRENT_EVALUATION_POINT"
        ]["sel"][0],
        "HV_GROUP_LEAKAGE_CURRENT": convert_prefix(hv_leakage_current, "", "uA"),
        "MODULE_SUM_LEAKAGE_CURRENT": convert_prefix(sum_leakage_current, "", "uA"),
        "LEAKAGE_CURRENT_RATIO": rounded_lc_ratio,
        "LEAKAGE_CURRENT_PASS_RATIO": lc_cuts,
        "LEAKAGE_CURRENT_PASS": bool(leakage_current_pass),
    }

    module_stages = []
    for m in run_metadata["hv_group"]["modules"]:
        stage = m["comparison_stage"]
        module_stages.append(stage)

        if "cold" in stage.lower():
            log.warning(
                bcolors.WARNING
                + f" Module {m.get('serial_number', 'Unknown')} has a cold comparison stage: '{stage}'! Temperature normalization might fail"
                + bcolors.ENDC
            )

    # Output a json file
    output_df = outputDataFrame()
    output_df.set_test_type(TEST_TYPE)
    output_df.set_serial_num(hv_data._serialNumber)
    data = qcDataFrame()

    for key, result in HV_results.items():
        data.add_parameter(key, result)

    data.add_property(
        "ANALYSIS_VERSION",
        __version__,
    )
    data.add_property(
        "MEASUREMENT_VERSION",
        hv_results.get_properties()["IV_MEASURE_MEASUREMENT_VERSION"],
    )
    time_start = metadata["TimeStart"]
    time_end = metadata["TimeEnd"]
    duration = arrow.get(time_end) - arrow.get(time_start)

    data.add_property(
        "MEASUREMENT_DATE",
        arrow.get(time_start).isoformat(timespec="milliseconds"),
    )
    data.add_property("MEASUREMENT_DURATION", int(duration.total_seconds()))
    data.add_property("HUM", np.mean(hv_results["humidity"]))
    data.add_property("TEMP", np.mean(hv_results["temperature"]))
    data.add_property("MODULE_IV_COMPARISON_STAGES", module_stages)
    data.add_meta_data("INSTITUTION", institution)
    # data.add_meta_data("MODULE_SN", metadata["ModuleSN"])
    data.add_meta_data("MODULE_SN", "")

    passes_qc = bool(LLS_passes_QC)

    output_df.set_results(data)
    output_df.set_pass_flag(passes_qc)
    return output_df, passes_qc
