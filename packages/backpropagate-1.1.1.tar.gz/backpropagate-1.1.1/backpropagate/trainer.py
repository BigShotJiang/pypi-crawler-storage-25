"""
Backpropagate - Core Trainer Module
====================================

Production-ready LLM fine-tuning with smart defaults and Windows support.

Usage:
    from backpropagate import Trainer

    # Simple usage
    trainer = Trainer("unsloth/Qwen2.5-7B-Instruct-bnb-4bit")
    trainer.train("my_data.jsonl")
    trainer.save("./my-model")

    # With options
    trainer = Trainer(
        model="unsloth/Llama-3.2-3B-Instruct-bnb-4bit",
        lora_r=32,
        learning_rate=1e-4,
    )
    trainer.train(dataset="my_data.jsonl", steps=200)
    trainer.export("gguf")  # Export to GGUF for Ollama

Features:
- Auto VRAM detection for batch size
- Windows-safe multiprocessing
- QLoRA with Unsloth optimization
- Multiple export formats (LoRA, merged, GGUF)
"""

from __future__ import annotations

import gc
import logging
import os
import uuid
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from .export import ExportResult
    from .multi_run import MultiRunResult

from .checkpoints import RunHistoryManager
from .config import settings
from .datasets import DatasetLoader
from .exceptions import (
    BackpropagateError,
    DatasetError,
    DatasetNotFoundError,
    DatasetParseError,
    GPUNotAvailableError,
    InvalidSettingError,
    ModelLoadError,
    TrainingAbortedError,
    TrainingError,
)
from .feature_flags import check_feature
from .gpu_safety import check_gpu_safe
from .logging_config import bind_run_context, unbind_run_context

logger = logging.getLogger(__name__)


# =============================================================================
# B-017 HUGGINGFACE HUB TRANSIENT RETRY
# =============================================================================
# HF Hub has ~99.5% uptime with periodic 503/timeout spikes that last 30-60s.
# A multi-hour training job that starts by loading a model + dataset will die
# in the first 30s if HF blips during the load. tenacity wraps the call with
# exponential backoff so a transient blip becomes a logged WARN instead of a
# session-killing exception.
#
# Wrapped surfaces: model from_pretrained, dataset_load, snapshot_download.

_RETRY_ATTEMPTS = 3
_RETRY_BASE_SECONDS = 5
_RETRY_MAX_SECONDS = 60
_RETRY_MULTIPLIER = 2


def _hf_transient_exceptions() -> tuple[type[BaseException], ...]:
    """Return the exception classes tenacity should consider for HF calls.

    Note this returns the *candidate* set; status-code filtering happens in
    ``_is_transient_hf_exception`` so we don't over-retry 401/403/404.
    Imported lazily so the trainer module doesn't hard-require huggingface_hub
    or requests at import time.
    """
    excs: list[type[BaseException]] = [ConnectionError, TimeoutError]
    try:
        import requests  # type: ignore

        excs.extend([
            requests.exceptions.ConnectionError,
            requests.exceptions.Timeout,
            requests.exceptions.HTTPError,
        ])
    except ImportError:
        pass
    try:
        from huggingface_hub.utils import HfHubHTTPError  # type: ignore

        excs.append(HfHubHTTPError)
    except ImportError:
        pass
    return tuple(excs)


def _is_transient_hf_exception(exc: BaseException) -> bool:
    """Decide whether ``exc`` is worth retrying as a transient HF failure.

    Connection / timeout errors → always retry. HTTPError-shaped exceptions
    (requests.HTTPError, HfHubHTTPError) → retry ONLY on status 429 / 5xx /
    unknown. Skips 4xx (401 auth, 403 gated repo, 404 typo'd model) so users
    see the real error in <1s instead of waiting ~65s for the backoff to
    exhaust.
    """
    transient_excs = _hf_transient_exceptions()
    if not isinstance(exc, transient_excs):
        return False
    # If the exception carries an HTTP response, inspect its status code.
    response = getattr(exc, "response", None)
    status = getattr(response, "status_code", None)
    if status is None:
        # No status code attached → connection/timeout/other → retry
        return True
    return status == 429 or status >= 500


def _retry_hf_call(
    fn: Callable[..., Any],
    *args: Any,
    _label: str = "hf_call",
    **kwargs: Any,
) -> Any:
    """B-017: invoke ``fn(*args, **kwargs)`` with tenacity-based retry.

    Retries on transient HF Hub failures (5xx, 429, connection timeouts) up
    to ``_RETRY_ATTEMPTS`` attempts with exponential backoff. Each retry is
    logged at WARN with the URL hint, status (if available), and delay.
    Non-transient exceptions and the final failure propagate to the caller
    untouched.

    Args:
        fn: Callable to invoke (e.g. ``FastLanguageModel.from_pretrained``).
        *args / **kwargs: Forwarded to ``fn``.
        _label: Short string identifying the call site (used in retry logs).
    """
    from tenacity import (
        before_sleep_log,
        retry,
        retry_if_exception,
        stop_after_attempt,
        wait_exponential,
    )

    transient_excs = _hf_transient_exceptions()

    @retry(
        stop=stop_after_attempt(_RETRY_ATTEMPTS),
        wait=wait_exponential(
            multiplier=_RETRY_MULTIPLIER,
            min=_RETRY_BASE_SECONDS,
            max=_RETRY_MAX_SECONDS,
        ),
        retry=retry_if_exception(_is_transient_hf_exception),
        before_sleep=before_sleep_log(logger, logging.WARNING),
        reraise=True,
    )
    def _call() -> Any:
        return fn(*args, **kwargs)

    try:
        return _call()
    except transient_excs as exc:
        # Last attempt exhausted — log a structured failure line before
        # re-raising so triage doesn't have to scroll back through retries.
        logger.error(
            f"HF transient retry exhausted: label={_label} "
            f"err={type(exc).__name__}: {exc}"
        )
        raise


# =============================================================================
# F-019 ModelLoadError CAUSE CLASSIFICATION
# =============================================================================
# exceptions.py:67 defines ModelLoadCauseCategory =
#     Literal["auth", "not_found", "network", "version", "unknown"]
# and exceptions.py:285 carries a per-category remediation hint table. The
# raise sites below classify the underlying exception so the operator gets
# the right hint instead of the generic "check model name + network" line.
#
# We are defensive about huggingface_hub / requests availability: both
# imports are optional in the trainer's static dep set (the [unsloth] /
# [validation] extras pull them in, but a headless trainer.py import must
# survive without them). The classifier wraps each isinstance check in a
# try/except ImportError and degrades gracefully to "unknown" rather than
# raising at import-time when an upstream dep is missing.


def _classify_model_load_cause(exc: BaseException) -> str:
    """Best-effort classification of a model-load exception.

    Returns one of the ``ModelLoadCauseCategory`` Literal values:
    ``"auth"`` | ``"not_found"`` | ``"network"`` | ``"version"`` | ``"unknown"``.

    Classification rules (in order — first match wins):
    * ``HfHubHTTPError`` with status 401 → ``"auth"``
    * ``HfHubHTTPError`` with status 403 → ``"auth"`` (gated repo)
    * ``HfHubHTTPError`` with status 404 → ``"not_found"``
    * ``requests.ConnectionError`` / ``Timeout`` / builtin
      ``ConnectionError`` / ``TimeoutError`` → ``"network"``
    * ``ImportError`` → ``"version"`` (transformers/peft/unsloth missing
      or version mismatch)
    * anything else → ``"unknown"``
    """
    # 1. HfHubHTTPError with HTTP status carries the most signal.
    try:
        from huggingface_hub.utils import HfHubHTTPError  # type: ignore

        if isinstance(exc, HfHubHTTPError):
            response = getattr(exc, "response", None)
            status = getattr(response, "status_code", None)
            if status == 401:
                return "auth"
            if status == 403:
                # Gated-repo failures (e.g. Llama 3 without acceptance)
                # surface as 403; from the user's POV the remediation is
                # still "fix your HF auth / request access" so we route
                # to the auth hint.
                return "auth"
            if status == 404:
                return "not_found"
            # 5xx and unknown statuses fall through to network/unknown.
            if status is not None and status >= 500:
                return "network"
    except ImportError:
        pass

    # 2. Generic requests-shaped network errors.
    try:
        import requests  # type: ignore

        if isinstance(exc, (requests.ConnectionError, requests.Timeout)):
            return "network"
        # requests.HTTPError carries a response — try to peek at status.
        if isinstance(exc, requests.HTTPError):
            response = getattr(exc, "response", None)
            status = getattr(response, "status_code", None)
            if status == 401 or status == 403:
                return "auth"
            if status == 404:
                return "not_found"
            if status is not None and status >= 500:
                return "network"
    except ImportError:
        pass

    # 3. Builtin connection / timeout (raised by lower-level sockets).
    if isinstance(exc, (ConnectionError, TimeoutError)):
        return "network"

    # 4. ImportError — typically a transformers/peft/unsloth version
    # mismatch surfaced as a missing symbol on a deferred import. The
    # remediation is "upgrade / reinstall the package" so we route to
    # the version hint.
    if isinstance(exc, ImportError):
        return "version"

    # 5. Default fall-through. The generic hint already covers
    # "check the model name and your network" which is the right
    # advice when we genuinely don't know.
    return "unknown"


__all__ = [
    "Trainer",
    "TrainingRun",
    "TrainingCallback",
    "load_model",
    "load_dataset",
    "MultiRunTrainer",
    "SpeedrunTrainer",  # Backwards compatibility
]


def _compute_dataset_hash(dataset: Any) -> str | None:
    """Best-effort sha256-prefix of a dataset, if it's a local file.

    F-003 / F-004: the model card and run-history layer both want a
    stable identifier for the training data. When the dataset is a path
    to a local file we hash the bytes; for HF dataset names / in-memory
    Dataset objects / DatasetLoader instances we return ``None`` and let
    the model card mark the provenance as "remote dataset" rather than
    making up a hash.

    Returns the first 16 hex chars of sha256(file_bytes) on success,
    ``None`` if the dataset is not a hashable local artefact or the hash
    fails for any reason (best-effort — never raises).
    """
    import hashlib

    if not isinstance(dataset, (str, Path)):
        return None
    path = Path(dataset)
    if not path.exists() or not path.is_file():
        return None
    try:
        sha = hashlib.sha256()
        with path.open("rb") as fh:
            for chunk in iter(lambda: fh.read(1 << 20), b""):
                sha.update(chunk)
        return sha.hexdigest()[:16]
    except (OSError, PermissionError) as exc:
        logger.debug(f"_compute_dataset_hash failed for {path}: {exc}")
        return None


@dataclass
class TrainingRun:
    """Container for training run results."""
    run_id: str
    steps: int
    final_loss: float
    loss_history: list[float] = field(default_factory=list)
    output_path: str | None = None
    duration_seconds: float = 0.0
    samples_seen: int = 0
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class TrainingCallback:
    """Callback hooks for training events."""
    on_step: Callable[[int, float], None] | None = None
    on_epoch: Callable[[int], None] | None = None
    on_save: Callable[[str], None] | None = None
    on_complete: Callable[[TrainingRun], None] | None = None
    on_error: Callable[[Exception], None] | None = None


class Trainer:
    """
    Headless LLM fine-tuning trainer with smart defaults.

    Args:
        model: Model name/path (HuggingFace or local)
        lora_r: LoRA rank (default: 16)
        lora_alpha: LoRA alpha (default: 32)
        learning_rate: Learning rate (default: 2e-4)
        batch_size: Batch size per device (default: "auto")
        output_dir: Output directory (default: "./output")
        oom_recovery: If True (default), retry on torch.cuda.OutOfMemoryError
            by halving batch_size and doubling gradient_accumulation_steps
            (preserves effective batch). Aborts with RUNTIME_GPU_OOM after
            3 consecutive failures at batch=1. Set False to hard-fail.
        unsloth_fallback: If True (default), fall back to
            AutoModelForCausalLM + get_peft_model when
            unsloth.FastLanguageModel.from_pretrained fails. Set False to
            hard-fail.

    Production features (Stage B / Stage C, May 2026):
        - Stable error codes via the ERROR_CODES registry; every
          BackpropagateError carries ``code`` / ``message`` / ``hint`` /
          ``cause`` / ``retryable`` for machine-readable triage.
        - Atomic checkpoint writes (B-006): ``save()`` writes into
          ``<path>.partial`` then ``shutil.move()``s into place; crash-safe.
        - HuggingFace Hub transient retry (B-017): from_pretrained calls
          are wrapped with exponential backoff for 5xx / 429 / timeout.
          Auth (401/403) and not-found (404) skip retry.
        - run_id correlation token: every log line, checkpoint manifest,
          and SLAO merge_history entry carries the same UUID4-derived ID
          for cross-surface grep.
        - ModelLoadError carries a ``cause_category`` (auth / not_found /
          network / version / unknown) so the operator gets the right
          remediation hint instead of the generic "check model + network"
          line — see F-019 / the ``_classify_model_load_cause`` helper.

    Example:
        >>> trainer = Trainer("Qwen/Qwen2.5-7B-Instruct")
        >>> trainer.train("data.jsonl", steps=100)
        >>> trainer.save("./my-model")
    """

    # B-002: OOM-recovery tuning constants (Trainer mirror of MultiRunTrainer).
    _OOM_MAX_RETRIES_AT_MIN_BATCH = 3

    def __init__(
        self,
        model: str | None = None,
        lora_r: int | None = None,
        lora_alpha: int | None = None,
        lora_dropout: float | None = None,
        learning_rate: float | None = None,
        batch_size: int | str = "auto",
        gradient_accumulation: int | None = None,
        max_seq_length: int | None = None,
        output_dir: str | None = None,
        use_unsloth: bool = True,
        train_on_responses: bool = True,  # Phase 1.1: Only compute loss on assistant responses
        # B-002: opt out of OOM recovery (default ON for graceful degradation).
        oom_recovery: bool = True,
        # B-010: opt out of the Unsloth -> transformers fallback (default ON
        # so an Unsloth nightly that breaks loading doesn't take a pipeline
        # down; set False to make Unsloth failures hard-fail for operators
        # who insist on Unsloth's speed).
        unsloth_fallback: bool = True,
        # F-005: experiment-tracker wiring. Default "auto" detects installed
        # trackers via feature_flags (wandb / tensorboard / mlflow) and wires
        # them all. Pass "none" or None to disable. Pass a list of strings
        # (e.g. ["wandb"]) to force a specific tracker set; we DO NOT
        # validate that the tracker is installed in that branch — TRL will
        # raise a clear ImportError if it isn't.
        report_to: str | list[str] | None = "auto",
    ) -> None:
        # Use settings as defaults, override with provided values
        # NOTE: Use `is not None` checks instead of falsy `or` to allow
        # legitimate zero values (e.g. lora_dropout=0.0, learning_rate=0.0)
        self.model_name = model if model is not None else settings.model.name
        self.lora_r = lora_r if lora_r is not None else settings.lora.r
        self.lora_alpha = lora_alpha if lora_alpha is not None else settings.lora.lora_alpha
        self.lora_dropout = lora_dropout if lora_dropout is not None else settings.lora.lora_dropout
        self.learning_rate = learning_rate if learning_rate is not None else settings.training.learning_rate
        self.gradient_accumulation = gradient_accumulation if gradient_accumulation is not None else settings.training.gradient_accumulation_steps
        self.max_seq_length = max_seq_length if max_seq_length is not None else settings.model.max_seq_length
        self.output_dir = Path(output_dir if output_dir is not None else settings.training.output_dir)
        self.use_unsloth = use_unsloth and check_feature("unsloth")

        # Auto batch size
        if batch_size == "auto":
            self.batch_size: int = self._detect_batch_size()
        else:
            self.batch_size = int(batch_size)

        # Phase 1.1: Train on responses only
        self._train_on_responses = train_on_responses

        # B-002 / B-010: degradation knobs surfaced as instance attrs so the
        # multi-run trainer (and operator callers) can introspect.
        self.oom_recovery = oom_recovery
        self.unsloth_fallback = unsloth_fallback

        # F-005: store the operator's report_to intent; the resolver is
        # invoked lazily at train()-time so feature detection picks up
        # late-installed trackers (e.g. tracker installed after import).
        self._report_to_intent: str | list[str] | None = report_to

        # Internal state
        self._model: Any = None
        self._tokenizer: Any = None
        self._trainer: Any = None
        self._is_loaded = False
        self._training_runs: list[TrainingRun] = []

        # Apply Windows fixes
        self._apply_windows_fixes()

        logger.info(f"Trainer initialized: {self.model_name}")
        logger.info(f"  LoRA: r={self.lora_r}, alpha={self.lora_alpha}")
        logger.info(f"  Batch: {self.batch_size}, LR: {self.learning_rate}")
        logger.info(
            f"  Degradation knobs: oom_recovery={self.oom_recovery}, "
            f"unsloth_fallback={self.unsloth_fallback}"
        )

    def _resolve_report_to(self) -> str | list[str]:
        """F-005: resolve the user's report_to intent to a TRL-compatible value.

        Returns whatever TRL's :class:`SFTConfig` will accept on the
        ``report_to`` field:

        * ``"none"`` → no tracker (string accepted by SFTConfig).
        * ``["wandb"]`` / ``["tensorboard"]`` / etc — list of tracker names.

        Resolution rules (in order):

        1. ``self._report_to_intent`` is ``None`` or the string ``"none"`` →
           ``"none"`` (explicit opt-out).
        2. The intent is a list → return as-is (operator override; TRL
           will raise a clean error if a name is bogus).
        3. The intent is the string ``"auto"`` (the default) → detect
           installed trackers via feature_flags; return a list of the
           ones present, or ``"none"`` if none are.
        4. Otherwise the intent is a single tracker name as a string
           → wrap it in a list.
        """
        intent = self._report_to_intent
        if intent is None:
            return "none"
        if isinstance(intent, str):
            normalized = intent.strip().lower()
            if normalized in {"none", ""}:
                return "none"
            if normalized != "auto":
                # Single named tracker (e.g. "wandb").
                return [normalized]
            # Auto-resolve: pick up everything that's installed.
            trackers: list[str] = []
            if check_feature("wandb"):
                trackers.append("wandb")
            if check_feature("tensorboard"):
                trackers.append("tensorboard")
            if check_feature("mlflow"):
                trackers.append("mlflow")
            return trackers if trackers else "none"
        if isinstance(intent, list):
            # Operator-supplied list — pass through unchanged. Lower-case
            # names so trivial case mismatches don't make TRL choke.
            return [str(t).strip().lower() for t in intent if t]
        # Unknown type — fall back to "none" defensively.
        logger.warning(
            f"Trainer.report_to has unexpected type {type(intent).__name__}; "
            "falling back to 'none'."
        )
        return "none"

    def _apply_windows_fixes(self) -> None:
        """Apply Windows-specific environment variables."""
        if os.name == "nt":
            os.environ["TOKENIZERS_PARALLELISM"] = "false"
            os.environ["HF_HUB_ENABLE_HF_TRANSFER"] = "0"
            if settings.windows.xformers_disabled:
                os.environ["XFORMERS_DISABLED"] = "1"
            if settings.windows.cuda_launch_blocking:
                os.environ["CUDA_LAUNCH_BLOCKING"] = "1"
            logger.debug("Applied Windows-specific fixes")

    def _detect_batch_size(self) -> int:
        """Auto-detect optimal batch size based on available VRAM."""
        try:
            import torch
            if torch.cuda.is_available():
                vram_gb = torch.cuda.get_device_properties(0).total_memory / (1024**3)
                if vram_gb >= 24:
                    return 4
                elif vram_gb >= 16:
                    return 2
                elif vram_gb >= 12:
                    return 1
                else:
                    return 1
        except ImportError:
            logger.debug("PyTorch not available for batch size detection, using default")
        except RuntimeError as e:
            logger.debug(f"CUDA query failed for batch size detection: {e}")
        except Exception as e:
            logger.warning(f"Unexpected error detecting batch size: {type(e).__name__}: {e}")
        return 2  # Safe default

    def _cleanup_vram(self) -> None:
        """
        Release unused GPU memory.

        Calls gc.collect() to free Python-side references, then
        torch.cuda.empty_cache() to return unreferenced GPU memory to the
        CUDA allocator. Safe to call even when no GPU is present.

        Intended for use between multi_run iterations or after training
        completes to reclaim VRAM before the next operation.
        """
        gc.collect()
        try:
            import torch
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
                logger.debug("VRAM cleanup: gc.collect() + torch.cuda.empty_cache()")
            else:
                logger.debug("VRAM cleanup: gc.collect() (no CUDA available)")
        except ImportError:
            logger.debug("VRAM cleanup: gc.collect() (torch not installed)")

    def load_model(self) -> None:
        """
        Load the model and tokenizer.

        B-010: when ``use_unsloth=True`` and ``unsloth_fallback=True`` (the
        defaults), an Unsloth load failure that is not a CUDA/network issue
        falls through to the plain transformers + PEFT path. The fallback
        produces a functionally equivalent (but slower) training setup so an
        Unsloth nightly that breaks loading no longer takes the entire
        pipeline down.

        Raises:
            ModelLoadError: If the model or tokenizer cannot be loaded
            GPUNotAvailableError: If CUDA is required but not available
        """
        if self._is_loaded:
            return

        logger.info(f"Loading model: {self.model_name}")

        try:
            if self.use_unsloth:
                try:
                    self._load_with_unsloth()
                except (ImportError, RuntimeError):
                    # Don't downgrade ImportError / RuntimeError — those are
                    # the "your env is wrong" / "CUDA is wrong" signals the
                    # surrounding except blocks rely on for accurate error
                    # routing.
                    raise
                except Exception as unsloth_err:
                    if not self.unsloth_fallback:
                        raise
                    # B-010: graceful degradation to plain transformers.
                    logger.warning(
                        f"Unsloth load failed ({type(unsloth_err).__name__}: "
                        f"{unsloth_err}); falling back to transformers + PEFT. "
                        "Set Trainer(unsloth_fallback=False) to disable."
                    )
                    self.use_unsloth = False
                    self._load_with_transformers()
            else:
                self._load_with_transformers()
        except ImportError as e:
            # F-019: ImportError = missing/incompatible upstream package.
            # We keep the explicit "pip install" suggestion (more specific
            # than the generic version-category hint) and pass
            # cause_category="version" so the cause tag still lands in
            # details for downstream log scraping.
            raise ModelLoadError(
                self.model_name,
                f"Missing required package: {e.name if hasattr(e, 'name') else str(e)}",
                suggestion="Install required packages: pip install unsloth transformers peft",
                cause_category="version",
            ) from e
        except RuntimeError as e:
            error_msg = str(e).lower()
            if "cuda" in error_msg or "gpu" in error_msg:
                raise GPUNotAvailableError(
                    suggestion="Ensure CUDA is installed and GPU is available"
                ) from e
            # F-019: classify the underlying failure so the per-category hint
            # table can fire. Dropping the explicit suggestion arg lets the
            # ModelLoadError ctor pick the right line from
            # exceptions._MODEL_LOAD_HINTS for auth / not_found / network /
            # version / unknown. RuntimeErrors that aren't CUDA-shaped are
            # rare here — usually a transformers internal — so most will
            # land in "unknown" with the generic line, which is correct.
            raise ModelLoadError(
                self.model_name,
                str(e),
                cause_category=_classify_model_load_cause(e),
            ) from e
        except Exception as e:
            # F-019: the catchall sees the largest population of
            # interesting cases — HfHubHTTPError 401/403/404, requests
            # connection errors, version-mismatch ImportErrors that slip
            # past the explicit ImportError branch via a deferred import.
            raise ModelLoadError(
                self.model_name,
                str(e),
                cause_category=_classify_model_load_cause(e),
            ) from e

        self._is_loaded = True
        logger.info("Model loaded successfully")

    def _load_with_unsloth(self) -> None:
        """Load model using Unsloth for 2x faster training.

        B-017: ``FastLanguageModel.from_pretrained`` is wrapped with the HF
        Hub transient-retry decorator so a 5xx / 429 / connection timeout
        from the Hub doesn't fail the load on the first blip.
        """
        from unsloth import FastLanguageModel

        try:
            self._model, self._tokenizer = _retry_hf_call(
                FastLanguageModel.from_pretrained,
                model_name=self.model_name,
                max_seq_length=self.max_seq_length,
                dtype=None,  # Auto-detect
                load_in_4bit=True,
                trust_remote_code=settings.model.trust_remote_code,
                _label=f"unsloth_from_pretrained:{self.model_name}",
            )
        except Exception as e:
            # F-019: Unsloth's from_pretrained tunnels through huggingface_hub
            # for the actual weight download, so 401/403/404/connection
            # errors surface here too. Classify so the per-category hint
            # fires instead of the previous generic "check model and
            # network" line (which conflated auth and network failures).
            raise ModelLoadError(
                self.model_name,
                f"Unsloth model loading failed: {e}",
                cause_category=_classify_model_load_cause(e),
            ) from e

        # Apply LoRA
        try:
            self._model = FastLanguageModel.get_peft_model(
                self._model,
                r=self.lora_r,
                target_modules=settings.lora.target_modules,
                lora_alpha=self.lora_alpha,
                lora_dropout=self.lora_dropout,
                bias="none",
                use_gradient_checkpointing=settings.lora.use_gradient_checkpointing,
                random_state=settings.lora.random_state,
            )
        except Exception as e:
            # F-019: post-download LoRA application — usually a PEFT
            # version mismatch (peft renamed a kwarg) or an
            # unsupported-target-module config error. ImportError ⇒
            # "version", everything else ⇒ "unknown" via the classifier.
            raise ModelLoadError(
                self.model_name,
                f"Failed to apply LoRA: {e}",
                cause_category=_classify_model_load_cause(e),
            ) from e

    def _load_with_transformers(self) -> None:
        """Load model using standard transformers + PEFT.

        B-017: model + tokenizer ``from_pretrained`` calls are wrapped in
        the HF Hub transient-retry decorator.
        """
        import torch
        from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training
        from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig

        # Quantization config
        bnb_config = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_compute_dtype=torch.bfloat16,
            bnb_4bit_use_double_quant=True,
        )

        # Load model
        self._model = _retry_hf_call(
            AutoModelForCausalLM.from_pretrained,
            self.model_name,
            quantization_config=bnb_config,
            device_map="auto",
            trust_remote_code=settings.model.trust_remote_code,
            _label=f"transformers_from_pretrained:{self.model_name}",
        )

        # Load tokenizer
        self._tokenizer = _retry_hf_call(
            AutoTokenizer.from_pretrained,
            self.model_name,
            trust_remote_code=settings.model.trust_remote_code,
            _label=f"tokenizer_from_pretrained:{self.model_name}",
        )
        if self._tokenizer.pad_token is None:
            self._tokenizer.pad_token = self._tokenizer.eos_token

        # Prepare for training
        self._model = prepare_model_for_kbit_training(self._model)

        # Apply LoRA
        lora_config = LoraConfig(
            r=self.lora_r,
            lora_alpha=self.lora_alpha,
            target_modules=settings.lora.target_modules,
            lora_dropout=self.lora_dropout,
            bias="none",
            task_type="CAUSAL_LM",
        )
        self._model = get_peft_model(self._model, lora_config)

    def train(
        self,
        dataset: str | Any = None,
        steps: int | None = None,
        samples: int | None = None,
        callback: TrainingCallback | None = None,
        resume_from: str | None = None,
    ) -> TrainingRun:
        """
        Train the model on a dataset.

        Args:
            dataset: Dataset path (JSONL, CSV) or HuggingFace dataset name
            steps: Number of training steps (overrides config)
            samples: Number of samples to use (overrides config)
            callback: Optional callback for training events
            resume_from: F-002 — when set, look up the run_id in the on-disk
                run history and reuse its run_id + last checkpoint path. When
                ``None`` (default), start a fresh run. Multi-run resume lives
                on ``MultiRunTrainer``; the Trainer-level resume hook is a
                lighter "pick up the existing run_id and let the SFTTrainer
                resume from the latest HF checkpoint in output_dir" path.

        Returns:
            TrainingRun with results

        Raises:
            InvalidSettingError: If steps or samples are invalid
            DatasetError: If dataset cannot be loaded
            TrainingError: If training fails
        """
        import time

        from trl import SFTConfig, SFTTrainer

        # Validate inputs
        if steps is not None:
            if not isinstance(steps, int) or steps <= 0:
                raise InvalidSettingError(
                    "steps", steps, "positive integer",
                    suggestion="Use steps=100 or higher"
                )
        if samples is not None:
            if not isinstance(samples, int) or samples <= 0:
                raise InvalidSettingError(
                    "samples", samples, "positive integer",
                    suggestion="Use samples=1000 or higher"
                )

        # Load model if not loaded
        if not self._is_loaded:
            self.load_model()

        # Load dataset
        train_dataset = self._load_dataset(dataset, samples)

        # Pre-tokenize for Windows safety
        if os.name == "nt" and settings.windows.pre_tokenize:
            train_dataset = self._pre_tokenize(train_dataset)

        # F-005: resolve report_to once for this train() call. The auto-mode
        # picks up wandb / tensorboard / mlflow if their packages are installed
        # (which the [monitoring] extra installs by default), so a user who
        # ran ``pip install backpropagate[monitoring]`` AND ``wandb login``
        # gets W&B wiring for free without re-passing it on every call.
        # We pre-mint the run_id so the W&B run_name can correlate with our
        # internal correlation token (see B-001 below).
        report_to = self._resolve_report_to()
        # F-002: reuse the run_id when resuming so the on-disk history record
        # is updated in place rather than producing a duplicate row.
        run_id_for_resume: str | None = None
        if resume_from:
            try:
                resume_manager = RunHistoryManager(str(self.output_dir))
                record = resume_manager.get_run(resume_from)
                if record is not None:
                    run_id_for_resume = str(record.get("run_id"))
                else:
                    logger.warning(
                        f"resume_from={resume_from!r} not found in run history; "
                        "starting fresh."
                    )
            except Exception as exc:
                logger.warning(f"Resume lookup failed: {exc}")
        run_id = run_id_for_resume or uuid.uuid4().hex
        run_name = f"backprop-{run_id[:12]}" if report_to != "none" else None

        # Training arguments (TRL 0.27+ uses SFTConfig)
        training_args = SFTConfig(
            output_dir=str(self.output_dir),
            per_device_train_batch_size=self.batch_size,
            gradient_accumulation_steps=self.gradient_accumulation,
            max_steps=steps or settings.training.max_steps,
            learning_rate=self.learning_rate,
            weight_decay=settings.training.weight_decay,
            warmup_steps=settings.training.warmup_steps,
            optim=settings.training.optim,
            lr_scheduler_type=settings.training.lr_scheduler_type,
            logging_steps=settings.training.logging_steps,
            save_steps=settings.training.save_steps,
            bf16=settings.training.bf16,
            fp16=settings.training.fp16,
            seed=settings.training.seed,
            overwrite_output_dir=True,
            dataloader_num_workers=0 if os.name == "nt" else 4,
            report_to=report_to,  # F-005: dynamic — see _resolve_report_to.
            run_name=run_name,
            # SFT-specific args (moved from SFTTrainer in TRL 0.27+)
            max_length=self.max_seq_length,
            packing=settings.data.packing,
        )

        # Create trainer (TRL 0.27+ uses processing_class instead of tokenizer)
        self._trainer = SFTTrainer(
            model=self._model,
            processing_class=self._tokenizer,
            train_dataset=train_dataset,
            args=training_args,
        )

        # Apply train_on_responses_only if using Unsloth (Phase 1.1 optimization)
        # This focuses loss only on assistant responses, not user prompts
        # NOTE: Disabled on Windows due to multiprocessing issues that can crash the system
        if self.use_unsloth and self._train_on_responses and os.name != "nt":
            try:
                from unsloth.chat_templates import train_on_responses_only
                # Unsloth 2026+ API: train_on_responses_only(trainer, instruction_part, response_part, ...)
                # For ChatML format (Qwen): <|im_start|>user and <|im_start|>assistant
                self._trainer = train_on_responses_only(
                    self._trainer,
                    instruction_part="<|im_start|>user",
                    response_part="<|im_start|>assistant",
                    num_proc=1,  # Single process to avoid Windows issues
                )
                logger.info("Applied train_on_responses_only optimization")
            except ImportError:
                logger.warning("train_on_responses_only not available in this Unsloth version")
            except Exception as e:
                logger.warning(f"Failed to apply train_on_responses_only: {e}")
        elif self._train_on_responses and os.name == "nt":
            logger.warning(
                "train_on_responses_only disabled on Windows (multiprocessing issues) "
                "- training will compute loss on full conversations including user prompts, "
                "which may reduce fine-tuning quality"
            )

        # Train
        # B-001: ``run_id`` (the UUID4 correlation token) was minted above
        # so we could thread it into the SFTConfig.run_name for W&B (F-005).
        # The token is bound into the structured-logger context here,
        # embedded in TrainingRun.metadata, and unbound in the finally
        # block at the end of the method so it doesn't leak into the
        # caller's thread.
        legacy_run_label = f"run_{len(self._training_runs) + 1}"
        bind_run_context(run_id=run_id, session_kind="single_run")
        start_time = time.time()
        loss_history: list[float] = []
        status = "error"  # success path overwrites to "ok"
        run: TrainingRun | None = None

        # F-003: record the run start in the on-disk run history so
        # ``backprop list-runs`` / ``backprop show-run`` can surface it.
        run_history = RunHistoryManager(str(self.output_dir))
        dataset_info = dataset if isinstance(dataset, str) else type(dataset).__name__
        hyperparameters = {
            "lora_r": self.lora_r,
            "lora_alpha": self.lora_alpha,
            "lora_dropout": self.lora_dropout,
            "learning_rate": self.learning_rate,
            "batch_size": self.batch_size,
            "gradient_accumulation": self.gradient_accumulation,
            "max_seq_length": self.max_seq_length,
            "max_steps": steps or settings.training.max_steps,
            "max_samples": samples or settings.data.max_samples,
            "use_unsloth": self.use_unsloth,
            "seed": settings.training.seed,
        }
        try:
            if run_id_for_resume:
                # F-002 resume: flip status back to "running" without
                # clobbering the existing hyperparameters / dataset record.
                run_history.update_run(run_id, status="running")
            else:
                run_history.record_run_started(
                    run_id=run_id,
                    model_name=self.model_name,
                    dataset_info=dataset_info,
                    hyperparameters=hyperparameters,
                    session_kind="single_run",
                    checkpoint_path=str(self.output_dir / "lora"),
                    dataset_hash=_compute_dataset_hash(dataset),
                )
        except Exception as hist_err:
            # Never let history persistence kill a training session.
            logger.warning(f"RunHistoryManager.record_run_started failed: {hist_err}")

        logger.info(f"run_started run_id={run_id} legacy_label={legacy_run_label}")
        logger.info(f"  Steps: {steps or settings.training.max_steps}")
        logger.info(f"  Samples: {len(train_dataset)}")

        try:
            # B-002: OOM-recovery loop. We re-instantiate the SFTTrainer on
            # each retry so it picks up the halved batch / doubled accum.
            oom_consecutive_at_min = 0
            oom_retries = 0
            result: Any = None

            while True:
                try:
                    # Re-create SFTTrainer with current batch / accum on retry.
                    # (The first iteration uses the trainer built above.)
                    if oom_retries > 0:
                        training_args = SFTConfig(
                            output_dir=str(self.output_dir),
                            per_device_train_batch_size=self.batch_size,
                            gradient_accumulation_steps=self.gradient_accumulation,
                            max_steps=steps or settings.training.max_steps,
                            learning_rate=self.learning_rate,
                            weight_decay=settings.training.weight_decay,
                            warmup_steps=settings.training.warmup_steps,
                            optim=settings.training.optim,
                            lr_scheduler_type=settings.training.lr_scheduler_type,
                            logging_steps=settings.training.logging_steps,
                            save_steps=settings.training.save_steps,
                            bf16=settings.training.bf16,
                            fp16=settings.training.fp16,
                            seed=settings.training.seed,
                            overwrite_output_dir=True,
                            dataloader_num_workers=0 if os.name == "nt" else 4,
                            report_to=report_to,  # F-005: same resolution on retry.
                            run_name=run_name,
                            max_length=self.max_seq_length,
                            packing=settings.data.packing,
                        )
                        self._trainer = SFTTrainer(
                            model=self._model,
                            processing_class=self._tokenizer,
                            train_dataset=train_dataset,
                            args=training_args,
                        )

                    result = self._trainer.train()
                    break  # Success — exit retry loop

                except (KeyboardInterrupt, SystemExit):
                    raise
                except Exception as exc:
                    # OOM detection (B-002): torch.cuda.OutOfMemoryError OR
                    # RuntimeError whose message contains "out of memory".
                    is_oom = False
                    try:
                        import torch as _torch

                        if isinstance(exc, _torch.cuda.OutOfMemoryError):  # type: ignore[attr-defined]
                            is_oom = True
                    except (ImportError, AttributeError):
                        pass
                    if not is_oom and isinstance(exc, RuntimeError):
                        is_oom = "out of memory" in str(exc).lower()

                    if not self.oom_recovery or not is_oom:
                        raise

                    # OOM-specific recovery.
                    import torch as _torch

                    current_batch = self.batch_size
                    current_accum = self.gradient_accumulation
                    effective = current_batch * current_accum
                    logger.warning(
                        f"OOM detected (run_id={run_id}) batch={current_batch} "
                        f"grad_accum={current_accum} effective={effective}: {exc}"
                    )

                    gc.collect()
                    try:
                        if _torch.cuda.is_available():
                            _torch.cuda.empty_cache()
                    except Exception:
                        pass

                    if current_batch > 1:
                        new_batch = max(1, current_batch // 2)
                        new_accum = max(1, current_accum * 2)
                        logger.warning(
                            f"OOM recovery: halving batch {current_batch}->{new_batch}, "
                            f"doubling grad_accum {current_accum}->{new_accum}"
                        )
                        self.batch_size = new_batch
                        self.gradient_accumulation = new_accum
                        oom_consecutive_at_min = 0
                        oom_retries += 1
                        continue

                    # Already at floor.
                    oom_consecutive_at_min += 1
                    oom_retries += 1
                    logger.error(
                        f"OOM at batch=1 consecutive="
                        f"{oom_consecutive_at_min}/{self._OOM_MAX_RETRIES_AT_MIN_BATCH}"
                    )
                    if oom_consecutive_at_min >= self._OOM_MAX_RETRIES_AT_MIN_BATCH:
                        # B-002: surface as TrainingError (a BackpropagateError
                        # subclass) so callers that catch TrainingError continue
                        # to work; the code="RUNTIME_GPU_OOM" carries the
                        # structured signal for programmatic handlers.
                        err = TrainingError(
                            f"GPU error during training: persistent CUDA OOM "
                            f"at batch_size=1 ({oom_consecutive_at_min} "
                            f"consecutive attempts); cannot recover automatically.",
                            suggestion=(
                                "Use a smaller model (e.g. 7B -> 3B), reduce "
                                "max_seq_length, enable gradient_checkpointing, "
                                "or apply quantization. Set "
                                "Trainer(oom_recovery=False) to make OOMs "
                                "hard-fail on the first attempt."
                            ),
                        )
                        err.code = "RUNTIME_GPU_OOM"  # type: ignore[attr-defined]
                        err.details = {  # type: ignore[attr-defined]
                            "run_id": run_id,
                            "consecutive_oom_at_min_batch": oom_consecutive_at_min,
                        }
                        raise err from exc

                    # Below the threshold but at floor — retry once more
                    # with the same args (transient OOM may clear after
                    # empty_cache).
                    continue

            duration = time.time() - start_time

            # Validate training result
            if not hasattr(result, 'training_loss'):
                logger.warning("Training result missing 'training_loss' attribute - using 0.0")
            final_loss = getattr(result, 'training_loss', 0.0)

            # Extract loss history from logs
            loss_history = []
            if hasattr(self._trainer, 'state') and self._trainer.state.log_history:
                loss_history = [
                    log.get('loss', 0) for log in self._trainer.state.log_history
                    if 'loss' in log
                ]

            run = TrainingRun(
                run_id=run_id,
                steps=steps or settings.training.max_steps,
                final_loss=final_loss,
                loss_history=loss_history,
                duration_seconds=duration,
                samples_seen=len(train_dataset),
                output_path=str(self.output_dir),
                metadata={
                    "legacy_run_label": legacy_run_label,
                    "oom_retries": oom_retries,
                },
            )

            self._training_runs.append(run)

            if callback and callback.on_complete:
                try:
                    callback.on_complete(run)
                except Exception as cb_error:
                    logger.warning(f"on_complete callback raised error: {cb_error}")

            logger.info(f"Training complete: loss={final_loss:.4f}, time={duration:.1f}s")
            status = "ok"

            # F-003: record successful completion in run history.
            try:
                run_history.record_run_completed(
                    run_id=run_id,
                    final_loss=final_loss,
                    loss_history=loss_history,
                    steps=run.steps,
                    duration_seconds=duration,
                    checkpoint_path=run.output_path,
                )
            except Exception as hist_err:
                logger.warning(
                    f"RunHistoryManager.record_run_completed failed: {hist_err}"
                )
            return run

        except KeyboardInterrupt:
            duration = time.time() - start_time
            # F-003: best-effort failure recording on interrupt.
            try:
                run_history.record_run_failed(
                    run_id=run_id,
                    failure_reason="KeyboardInterrupt: user interrupted training",
                    loss_history=loss_history,
                    duration_seconds=duration,
                )
            except Exception as hist_err:
                logger.warning(
                    f"RunHistoryManager.record_run_failed failed: {hist_err}"
                )
            raise TrainingAbortedError(
                reason="User interrupted training",
                steps_completed=getattr(self._trainer.state, 'global_step', 0) if self._trainer else 0,
            ) from None
        except BackpropagateError as exc:
            # F-003: record failure before re-raising.
            try:
                run_history.record_run_failed(
                    run_id=run_id,
                    failure_reason=f"{type(exc).__name__}: {exc}",
                    loss_history=loss_history,
                    duration_seconds=time.time() - start_time,
                )
            except Exception as hist_err:
                logger.warning(
                    f"RunHistoryManager.record_run_failed failed: {hist_err}"
                )
            # Already structured — propagate without re-wrapping (B-002 path).
            raise
        except RuntimeError as e:
            duration = time.time() - start_time
            try:
                run_history.record_run_failed(
                    run_id=run_id,
                    failure_reason=f"{type(e).__name__}: {e}",
                    loss_history=loss_history,
                    duration_seconds=duration,
                )
            except Exception as hist_err:
                logger.warning(
                    f"RunHistoryManager.record_run_failed failed: {hist_err}"
                )
            error_msg = str(e).lower()
            if "out of memory" in error_msg or "cuda" in error_msg:
                raise TrainingError(
                    f"GPU error during training: {e}",
                    suggestion="Try reducing batch_size or using gradient_checkpointing"
                ) from e
            if callback and callback.on_error:
                callback.on_error(e)
            raise TrainingError(
                f"Training failed: {e}",
                suggestion="Check model/dataset compatibility and package versions (trl, transformers, peft). Run with --verbose for full traceback.",
            ) from e
        except Exception as e:
            duration = time.time() - start_time
            try:
                run_history.record_run_failed(
                    run_id=run_id,
                    failure_reason=f"{type(e).__name__}: {e}",
                    loss_history=loss_history,
                    duration_seconds=duration,
                )
            except Exception as hist_err:
                logger.warning(
                    f"RunHistoryManager.record_run_failed failed: {hist_err}"
                )
            if callback and callback.on_error:
                callback.on_error(e)
            raise TrainingError(f"Training failed: {e}") from e
        finally:
            # B-001: emit run_ended with status and release the context-var
            # binding so the thread doesn't carry our run_id into the next
            # caller. We deliberately do this in `finally` so the log line
            # fires on both happy and error paths.
            logger.info(f"run_ended run_id={run_id} status={status}")
            unbind_run_context("run_id", "session_kind")

    def _load_dataset(
        self,
        dataset: str | Any,
        samples: int | None = None,
    ) -> Any:
        """
        Load dataset from various sources.

        Accepts:
            - None: uses default dataset from config (HuggingFace)
            - str with file extension (.jsonl, .json, .csv, .parquet, .txt, .md):
              routes through DatasetLoader for format detection, validation, and
              ChatML conversion, then returns a HuggingFace Dataset
            - str without file extension: treated as HuggingFace dataset name
            - datasets.Dataset: used directly
            - DatasetLoader: calls .to_hf_dataset() directly

        Raises:
            DatasetNotFoundError: If dataset file doesn't exist
            DatasetParseError: If dataset cannot be parsed
            DatasetError: For other dataset-related errors
        """
        from datasets import Dataset, load_dataset

        max_samples = samples or settings.data.max_samples

        # File extensions that DatasetLoader handles
        _LOCAL_FILE_EXTENSIONS = (
            '.jsonl', '.json', '.csv', '.parquet', '.txt', '.md',
        )

        try:
            if dataset is None:
                # Use default dataset from config (B-017: retry on transient HF Hub failures)
                ds = _retry_hf_call(
                    load_dataset,
                    settings.data.dataset_name,
                    split=settings.data.dataset_split,
                    _label=f"load_dataset:{settings.data.dataset_name}",
                )
            elif isinstance(dataset, DatasetLoader):
                # DatasetLoader passed directly — use its validated output
                validation = dataset.validation_result
                if validation.warnings:
                    for w in validation.warnings[:5]:
                        logger.warning(f"Dataset validation warning: {w}")
                if not validation.is_valid:
                    logger.warning(
                        f"Dataset has {validation.error_count} validation errors "
                        f"({validation.error_rate:.1%} error rate) — proceeding anyway"
                    )
                    for err in validation.errors[:5]:
                        logger.warning(f"  {err}")
                ds = dataset.to_hf_dataset()
            elif isinstance(dataset, str):
                if any(dataset.lower().endswith(ext) for ext in _LOCAL_FILE_EXTENSIONS):
                    # Local file — route through DatasetLoader for format detection,
                    # validation, and ChatML conversion
                    try:
                        loader = DatasetLoader(dataset, validate=True)
                    except FileNotFoundError as e:
                        raise DatasetNotFoundError(
                            dataset,
                            suggestion="Create the file or use a HuggingFace dataset name"
                        ) from e

                    # Log format detection
                    logger.info(f"DatasetLoader detected format: {loader.detected_format.value}")

                    # Log validation warnings/errors
                    validation = loader.validation_result
                    if validation.warnings:
                        for w in validation.warnings[:5]:
                            logger.warning(f"Dataset validation warning: {w}")
                    if not validation.is_valid:
                        logger.warning(
                            f"Dataset has {validation.error_count} validation errors "
                            f"({validation.error_rate:.1%} error rate) — proceeding anyway"
                        )
                        for err in validation.errors[:5]:
                            logger.warning(f"  {err}")

                    ds = loader.to_hf_dataset()
                else:
                    # No file extension — assume HuggingFace dataset name
                    # B-017: retry on transient HF Hub failures (5xx, 429, timeouts).
                    try:
                        ds = _retry_hf_call(
                            load_dataset,
                            dataset,
                            split=settings.data.dataset_split,
                            _label=f"load_dataset:{dataset}",
                        )
                    except Exception as e:
                        raise DatasetError(
                            f"Failed to load HuggingFace dataset '{dataset}': {e}",
                            suggestion="Check dataset name and network connection"
                        ) from e
            elif isinstance(dataset, Dataset):
                ds = dataset
            else:
                raise DatasetError(
                    f"Unsupported dataset type: {type(dataset).__name__}",
                    suggestion="Use a file path (JSONL, CSV, Parquet), HuggingFace dataset name, Dataset object, or DatasetLoader"
                )
        except (DatasetNotFoundError, DatasetParseError, DatasetError):
            raise
        except FileNotFoundError as e:
            raise DatasetNotFoundError(str(e)) from e
        except Exception as e:
            raise DatasetError(f"Failed to load dataset: {e}") from e

        # Limit samples
        if max_samples > 0 and len(ds) > max_samples:
            if settings.data.shuffle:
                ds = ds.shuffle(seed=settings.training.seed)
            ds = ds.select(range(max_samples))

        logger.info(f"Loaded {len(ds)} samples")
        return ds

    def _pre_tokenize(self, dataset: Any) -> Any:
        """Pre-tokenize dataset for Windows safety."""
        logger.info("Pre-tokenizing dataset (Windows-safe mode)")

        def tokenize_fn(examples: dict[str, Any]) -> Any:
            try:
                return self._tokenizer(
                    examples[settings.data.text_column],
                    truncation=True,
                    max_length=self.max_seq_length,
                    padding=False,
                )
            except KeyError:
                raise DatasetError(
                    f"Dataset missing required column '{settings.data.text_column}'",
                    suggestion=f"Available columns: {list(examples.keys()) if hasattr(examples, 'keys') else 'unknown'}"
                )

        try:
            tokenized = dataset.map(
                tokenize_fn,
                batched=True,
                num_proc=None,  # None = run in main process (avoids Windows multiprocessing issues)
                remove_columns=dataset.column_names,
                desc="Tokenizing",
            )
        except DatasetError:
            raise
        except Exception as e:
            raise DatasetError(f"Tokenization failed: {e}") from e

        return tokenized

    def save(
        self,
        path: str | None = None,
        save_merged: bool = False,
        run_id: str | None = None,
    ) -> str:
        """
        Save the trained model atomically.

        B-006: writes flow into ``<path>.partial`` first and ``shutil.move()``
        promotes the directory to the final path on success. The partial
        directory is cleaned up on any failure path so the operator never
        sees a half-written PEFT directory (config.json present, weights
        missing — which raises a cryptic 'state_dict missing keys' on the
        next resume attempt).

        Args:
            path: Output path (default: output_dir/lora)
            save_merged: Whether to save merged weights (larger but standalone)
            run_id: Optional correlation token (B-001) persisted into a
                ``run_id`` file inside the saved checkpoint dir so operators
                can grep by the same identifier across logs + manifests.

        Returns:
            Path to saved model

        Raises:
            TrainingError: If no model loaded or save fails
            CheckpointError: If atomic promotion fails
        """
        import shutil

        from .exceptions import CheckpointError

        if not self._is_loaded:
            raise TrainingError("No model loaded. Call load_model() or train() first.")

        output_path = Path(path or self.output_dir / "lora")
        partial_path = output_path.with_name(output_path.name + ".partial")

        # Ensure parent exists; the atomic promote at the end places the
        # leaf directory.
        try:
            output_path.parent.mkdir(parents=True, exist_ok=True)
        except PermissionError as e:
            raise CheckpointError(
                "save", str(output_path),
                f"Permission denied creating parent directory: {e}"
            ) from e
        except OSError as e:
            raise CheckpointError(
                "save", str(output_path),
                f"Failed to create parent directory: {e}"
            ) from e

        # Wipe any leftover .partial from a previous crash.
        if partial_path.exists():
            shutil.rmtree(partial_path, ignore_errors=True)

        try:
            partial_path.mkdir(parents=True, exist_ok=False)
        except OSError as e:
            raise CheckpointError(
                "save", str(partial_path),
                f"Failed to create partial directory: {e}"
            ) from e

        try:
            if save_merged and self.use_unsloth:
                self._model.save_pretrained_merged(
                    str(partial_path),
                    self._tokenizer,
                    save_method="merged_16bit",
                )
            else:
                self._model.save_pretrained(str(partial_path))
                self._tokenizer.save_pretrained(str(partial_path))

            # B-001: drop run_id into the checkpoint dir so an operator can
            # match the on-disk artefact back to a log session without
            # cross-referencing wall-clock timestamps.
            if run_id is not None:
                try:
                    (partial_path / "run_id").write_text(run_id, encoding="utf-8")
                except OSError as e:
                    logger.warning(f"Failed to write run_id file: {e}")

            # Atomic promote.
            if output_path.exists():
                shutil.rmtree(output_path)
            shutil.move(str(partial_path), str(output_path))
        except CheckpointError:
            raise
        except Exception as e:
            raise CheckpointError(
                "save", str(output_path),
                str(e)
            ) from e
        finally:
            # Belt-and-braces: leave no .partial behind on any path.
            if partial_path.exists():
                shutil.rmtree(partial_path, ignore_errors=True)

        logger.info(f"Model saved to: {output_path}")
        return str(output_path)

    def export(
        self,
        format: str = "lora",
        output_dir: str | None = None,
        quantization: str = "q4_k_m",
        push_to_hub: bool = False,
        repo_id: str | None = None,
        **kwargs: Any,
    ) -> ExportResult:
        """
        Export the trained model.

        Args:
            format: Export format - "lora", "merged", or "gguf"
            output_dir: Output directory (default: self.output_dir/format)
            quantization: GGUF quantization type (q4_k_m, q5_k_m, q8_0, f16)
            push_to_hub: Whether to push to HuggingFace Hub (merged only)
            repo_id: Repository ID for Hub (required if push_to_hub=True)
            **kwargs: Additional arguments passed to export functions

        Returns:
            ExportResult with path, size, and timing info

        Example:
            >>> trainer = Trainer("unsloth/Qwen2.5-7B-Instruct-bnb-4bit")
            >>> trainer.train("data.jsonl", steps=100)
            >>> result = trainer.export("gguf", quantization="q4_k_m")
            >>> print(result.summary())
        """
        from .export import (
            export_gguf,
            export_lora,
            export_merged,
        )

        if not self._is_loaded:
            raise TrainingError("No model loaded. Call load_model() or train() first.")

        output_path = Path(output_dir or self.output_dir / format)

        format_lower = format.lower()

        if format_lower == "lora":
            result = export_lora(
                model=self._model,
                output_dir=output_path,
                **kwargs,
            )
            logger.info(f"Exported LoRA adapter: {result.path}")

        elif format_lower == "merged":
            result = export_merged(
                model=self._model,
                tokenizer=self._tokenizer,
                output_dir=output_path,
                push_to_hub=push_to_hub,
                repo_id=repo_id,
                **kwargs,
            )
            logger.info(f"Exported merged model: {result.path}")

        elif format_lower == "gguf":
            result = export_gguf(
                model=self._model,
                tokenizer=self._tokenizer,
                output_dir=output_path,
                quantization=quantization,
                **kwargs,
            )
            logger.info(f"Exported GGUF ({quantization}): {result.path}")

        else:
            raise ValueError(f"Unsupported format: {format}. Use 'lora', 'merged', or 'gguf'")

        return result

    def push_to_hub(self, repo_id: str, private: bool = True) -> None:
        """Push model to HuggingFace Hub."""
        if not self._is_loaded:
            raise TrainingError("No model loaded. Call load_model() or train() first.")

        self._model.push_to_hub(repo_id, private=private)
        self._tokenizer.push_to_hub(repo_id, private=private)
        logger.info(f"Pushed to HuggingFace Hub: {repo_id}")

    @property
    def model(self) -> Any:
        """Access the underlying model."""
        return self._model

    @property
    def tokenizer(self) -> Any:
        """Access the tokenizer."""
        return self._tokenizer

    @property
    def runs(self) -> list[TrainingRun]:
        """Get all training runs."""
        return self._training_runs

    def multi_run(
        self,
        dataset: str | Any = None,
        num_runs: int = 5,
        steps_per_run: int = 100,
        samples_per_run: int = 1000,
        merge_mode: str = "slao",
        checkpoint_dir: str | None = None,
        on_run_complete: Callable[..., Any] | None = None,
        resume_from: str | None = None,
    ) -> MultiRunResult:
        """
        Execute SLAO Multi-Run training (multiple short runs with LoRA merging).

        This is the recommended approach for fine-tuning as it:
        - Prevents catastrophic forgetting via SLAO merging
        - Exposes the model to diverse data across runs
        - Saves checkpoints after each run for rollback
        - Monitors GPU safety throughout

        Args:
            dataset: Dataset name/path or HuggingFace dataset
            num_runs: Number of training runs (default: 5)
            steps_per_run: Steps per run (default: 100)
            samples_per_run: Fresh samples per run (default: 1000)
            merge_mode: "slao" (recommended) or "simple"
            checkpoint_dir: Where to save checkpoints
            on_run_complete: Callback after each run

        Returns:
            MultiRunResult with aggregate metrics and run history

        Example:
            >>> trainer = Trainer("unsloth/Qwen2.5-7B-Instruct-bnb-4bit")
            >>> result = trainer.multi_run(
            ...     dataset="HuggingFaceH4/ultrachat_200k",
            ...     num_runs=5,
            ...     steps_per_run=100,
            ... )
            >>> print(f"Final loss: {result.final_loss}")
        """
        from .multi_run import MergeMode, MultiRunConfig, MultiRunTrainer

        # Pre-flight GPU check
        if not check_gpu_safe():
            raise GPUNotAvailableError("GPU safety check failed. Check temperature and VRAM.")

        config = MultiRunConfig(
            num_runs=num_runs,
            steps_per_run=steps_per_run,
            samples_per_run=samples_per_run,
            merge_mode=MergeMode(merge_mode.lower()),
            checkpoint_dir=checkpoint_dir or str(self.output_dir / "multi_run"),
            initial_lr=self.learning_rate,
        )

        multi_run_trainer = MultiRunTrainer(
            model=self.model_name,
            config=config,
            on_run_complete=on_run_complete,
            resume_from=resume_from,
        )

        return multi_run_trainer.run(dataset)

    # Backwards compatibility alias
    speedrun = multi_run


# =============================================================================
# CONVENIENCE FUNCTIONS
# =============================================================================

def load_model(
    model_name: str | None = None,
    load_in_4bit: bool = True,
    max_seq_length: int = 2048,
) -> tuple[Any, Any]:
    """
    Load a model and tokenizer.

    Args:
        model_name: Model name/path
        load_in_4bit: Use 4-bit quantization
        max_seq_length: Maximum sequence length

    Returns:
        Tuple of (model, tokenizer)
    """
    trainer = Trainer(model=model_name, max_seq_length=max_seq_length)
    trainer.load_model()
    return trainer.model, trainer.tokenizer


def load_dataset(
    dataset: str | Any,
    max_samples: int | None = None,
    split: str | None = None,
) -> Any:
    """
    Load a dataset.

    Args:
        dataset: Dataset path or name
        max_samples: Maximum samples to load
        split: Dataset split

    Returns:
        HuggingFace Dataset
    """
    from datasets import load_dataset as hf_load_dataset

    if isinstance(dataset, str):
        if dataset.endswith('.jsonl') or dataset.endswith('.json'):
            ds = hf_load_dataset('json', data_files=dataset, split='train')
        elif dataset.endswith('.csv'):
            ds = hf_load_dataset('csv', data_files=dataset, split='train')
        else:
            ds = hf_load_dataset(dataset, split=split or "train")
    else:
        ds = dataset

    if max_samples and len(ds) > max_samples:
        ds = ds.shuffle(seed=42).select(range(max_samples))

    return ds


# Import MultiRunTrainer for re-export (lazy to avoid circular imports)
def __getattr__(name: str) -> Any:
    if name == "MultiRunTrainer":
        from .multi_run import MultiRunTrainer
        return MultiRunTrainer
    if name == "SpeedrunTrainer":  # Backwards compatibility
        from .multi_run import SpeedrunTrainer
        return SpeedrunTrainer
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
