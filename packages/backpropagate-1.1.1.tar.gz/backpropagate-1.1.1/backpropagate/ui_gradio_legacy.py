"""
DEPRECATED — Gradio implementation of the Web UI.

The Web UI migrated from Gradio to Reflex in v1.1.0 (2026-05-21). This module
is preserved as reference for the Stage B/C contract behaviors (event buffer,
output_dir denylist, file-magic validator, auth-shape validation, error
redaction). The framework-agnostic helpers moved to ui_security.py; the new
Reflex implementation lives in ui_app/.

Do not import this module from new code. It will be removed in v1.2.

Original docstring (preserved for context)
==========================================

Backpropagate - Gradio 6 Web Interface — Ocean Mist theme, live training
progress with loss plots, GPU monitoring dashboard, dataset preview, run
history, one-click export.

Security primitives (auth shape validation, file upload validation, rate
limiting, CSRF protection, error sanitization) moved to ui_security.py.

Based on Trail of Bits Gradio 5 Security Audit and OWASP Web Security Best
Practices.
"""

import logging
import re
import secrets
import sys
import threading
import time
from collections import deque
from collections.abc import Generator
from pathlib import Path
from typing import Any

import gradio as gr

from .config import settings
from .datasets import (
    DatasetLoader,
    ValidationResult,
)
from .exceptions import BackpropagateError
from .feature_flags import (
    get_gpu_info,
    get_system_info,
    list_available_features,
)
from .gpu_safety import GPUCondition, get_gpu_status
from .security import PathTraversalError, SecurityWarning, safe_path
from .theme_gradio_legacy import create_backpropagate_theme, get_css

# Import production security utilities
from .ui_security import (
    ALLOWED_DATASET_EXTENSIONS,
    DEFAULT_SECURITY_CONFIG,
    EnhancedRateLimiter,
    FileValidator,
    get_ui_output_dir,
    log_security_event,
    validate_numeric_input,
)

logger = logging.getLogger(__name__)


# =============================================================================
# SECURITY UTILITIES (Enhanced with IP tracking and security logging)
# =============================================================================

# Global rate limiters using enhanced version with IP tracking
_training_limiter = EnhancedRateLimiter(
    max_requests=DEFAULT_SECURITY_CONFIG.training_rate_limit,
    window_seconds=DEFAULT_SECURITY_CONFIG.training_rate_window,
    operation_name="training",
)
_export_limiter = EnhancedRateLimiter(
    max_requests=DEFAULT_SECURITY_CONFIG.export_rate_limit,
    window_seconds=DEFAULT_SECURITY_CONFIG.export_rate_window,
    operation_name="export",
)
_upload_limiter = EnhancedRateLimiter(
    max_requests=DEFAULT_SECURITY_CONFIG.upload_rate_limit,
    window_seconds=DEFAULT_SECURITY_CONFIG.upload_rate_window,
    operation_name="upload",
)

# File validator for dataset uploads (CVE-2024-47872 mitigation)
_file_validator = FileValidator(
    allowed_extensions=ALLOWED_DATASET_EXTENSIONS,
    max_size_mb=DEFAULT_SECURITY_CONFIG.max_upload_size_mb,
)


def validate_path_input(
    path_str: str,
    allowed_base: Path | None = None,
    must_exist: bool = False,
) -> tuple[bool, str, Path | None]:
    """
    Validate a user-provided path input.

    Returns:
        Tuple of (is_valid, error_message, resolved_path)
    """
    if not path_str or not path_str.strip():
        return False, "Path cannot be empty", None

    try:
        resolved = safe_path(
            path_str,
            must_exist=must_exist,
            allowed_base=allowed_base,
        )
        return True, "", resolved
    except PathTraversalError as e:
        logger.warning(f"Path traversal attempt blocked: {e}")
        return False, f"Security error: {e}", None
    except FileNotFoundError:
        return False, f"Path not found: {path_str}", None
    except ValueError as e:
        return False, str(e), None


def sanitize_model_name(name: str) -> str:
    """Sanitize a model name for safe use."""
    if not name:
        return ""
    # Allow alphanumeric, hyphens, underscores, slashes (for HF paths), and dots
    allowed = set("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_./")
    return "".join(c for c in name if c in allowed)


def sanitize_text_input(text: str, max_length: int = 1000) -> str:
    """Sanitize general text input."""
    if not text:
        return ""
    # Truncate to max length
    text = text[:max_length]
    # Remove null bytes and other problematic characters
    text = text.replace("\x00", "")
    return text.strip()


def safe_markdown_fence(content: str, language: str = "") -> str:
    """Wrap user content in a fenced Markdown code block safely (C-UX-005).

    Dataset / Modelfile / Ollama previews wrap user-supplied content in
    triple-backtick fences for display in gr.Markdown. If the content
    itself contains the literal sequence ``` (extremely common — ChatML
    samples literally include code fences as training data, and Modelfile
    bodies read from disk can contain arbitrary characters), the outer
    fence terminates early. The rest renders as raw markdown / creates a
    Markdown injection vector.

    Defense: count the longest backtick run inside the content and use a
    fence one tick longer. CommonMark explicitly allows this. We always
    use at least three backticks so the output renders correctly in
    historical viewers too.
    """
    if content is None:
        content = ""
    # Find the longest run of consecutive backticks in the content.
    longest = 0
    current = 0
    for ch in content:
        if ch == "`":
            current += 1
            if current > longest:
                longest = current
        else:
            current = 0
    fence_len = max(3, longest + 1)
    fence = "`" * fence_len
    lang = language or ""
    return f"{fence}{lang}\n{content}\n{fence}"


# FB-011: user-facing error sanitization.
# Raw exception messages from torch / transformers / huggingface_hub frequently
# embed absolute filesystem paths (home directory, HF cache, internal model
# layout). Surfacing those into the Gradio toast leaks both PII (the operator's
# username) and an internal-map of the deployment that attackers shouldn't get
# from a UI handler. The patterns below redact:
#   - Unix-style absolute paths starting with /home/, /Users/, /root/
#   - Windows-style absolute paths under C:\Users\<name>\, including UNC roots
#   - The HF cache location (~/.cache/huggingface/...)
#   - Whole tempdirs surfaced by tempfile / shutil
# Truncate to a fixed limit so a 10 KB pyarrow traceback can't blow up the
# toast component.
_REDACTED = "<redacted-path>"
_PATH_REDACTION_PATTERNS: tuple[re.Pattern[str], ...] = (
    re.compile(r"/(?:home|Users|root)/[^\s'\":]+"),
    re.compile(r"[A-Za-z]:\\Users\\[^\s'\":]+"),
    re.compile(r"\\\\[^\\\s'\":]+\\[^\s'\":]+"),  # UNC \\server\share\...
    re.compile(r"/tmp/[^\s'\":]+"),
    re.compile(r"[A-Za-z]:\\Windows\\Temp\\[^\s'\":]+"),
    re.compile(r"~?/?\.cache/huggingface/[^\s'\":]*"),
)


def _redact_paths(text: str) -> str:
    """
    Replace absolute filesystem paths with ``<redacted-path>`` for UI display.

    Used by ``sanitize_error_for_user`` so trainer / transformers errors that
    embed the operator's home directory don't leak into the Gradio toast.
    """
    if not text:
        return text
    for pat in _PATH_REDACTION_PATTERNS:
        text = pat.sub(_REDACTED, text)
    return text


def sanitize_error_for_user(
    exc: BaseException,
    operation: str,
    max_length: int = 240,
) -> tuple[str, str | None]:
    """
    Convert a backend exception into a user-safe display message (FB-011).

    Returns a ``(message, suggestion)`` tuple:

    - For ``BackpropagateError`` subclasses, return the structured
      ``{code}: {message}`` plus the suggestion (already user-facing — these
      are authored to be safe to display).
    - For ``KeyboardInterrupt`` / ``RateLimitExceeded`` / other library
      exceptions we let bubble up via ``gr.Error``, redact paths and trim.
    - For any other exception type, return a generic "Internal error
      (RUNTIME_UI). Check server logs for details." — the full traceback is
      still logged server-side via ``logger.exception`` at the call site,
      so operators see the real cause; users see something actionable
      without internal paths leaking.

    The ``operation`` argument is folded into the user-facing message
    ("during training", "during export") so the toast tells the user which
    handler failed even when the underlying exception is hidden.
    """
    # BackpropagateError: structured, user-authored — surface code + message.
    if isinstance(exc, BackpropagateError):
        code = exc.code or "BACKPROPAGATE_ERROR"
        message = _redact_paths(exc.message or str(exc))
        if len(message) > max_length:
            message = message[: max_length - 1] + "…"
        suggestion = exc.suggestion
        if suggestion:
            suggestion = _redact_paths(suggestion)
            if len(suggestion) > max_length:
                suggestion = suggestion[: max_length - 1] + "…"
        return f"{code}: {message}", suggestion

    # Anything else: hide the type + the full message; surface a stable
    # operator-actionable string with the operation name only.
    generic = (
        f"Internal error during {operation} (RUNTIME_UI). "
        "Check the server logs for full details."
    )
    return generic, None


def generate_auth_token() -> str:
    """Generate a secure authentication token."""
    return secrets.token_urlsafe(32)

__all__ = ["create_ui", "launch", "SecurityWarning"]


# =============================================================================
# MODEL PRESETS
# =============================================================================

# C-UX-001: "Custom / Other" sentinel makes the custom-model textbox reachable
# from the dropdown. The start_training / start_multi_run handlers check
# `model_preset in MODEL_PRESETS`; the sentinel maps to "" so the lookup falls
# through to sanitize_model_name(custom_model), which is the documented HF path.
CUSTOM_MODEL_CHOICE = "Custom / Other"
MODEL_PRESETS = {
    "Qwen 2.5 7B (Recommended)": "unsloth/Qwen2.5-7B-Instruct-bnb-4bit",
    "Qwen 2.5 3B (Fast)": "unsloth/Qwen2.5-3B-Instruct-bnb-4bit",
    "Qwen 2.5 1.5B (Tiny)": "unsloth/Qwen2.5-1.5B-Instruct-bnb-4bit",
    "Llama 3.2 3B": "unsloth/Llama-3.2-3B-Instruct-bnb-4bit",
    "Llama 3.2 1B": "unsloth/Llama-3.2-1B-Instruct-bnb-4bit",
    "Mistral 7B v0.3": "unsloth/mistral-7b-instruct-v0.3-bnb-4bit",
    "Phi-3 Mini": "unsloth/Phi-3-mini-4k-instruct-bnb-4bit",
    CUSTOM_MODEL_CHOICE: "",
}

DATASET_PRESETS = {
    "UltraChat 200K (Conversations)": "HuggingFaceH4/ultrachat_200k",
    "OpenAssistant (Helpful)": "OpenAssistant/oasst1",
    "Alpaca (Instructions)": "tatsu-lab/alpaca",
    "Custom JSONL": "custom",
}


# =============================================================================
# UI STATE
# =============================================================================

class UIState:
    """Global UI state container."""

    def __init__(self) -> None:
        self.trainer: Any = None
        self.is_training: bool = False
        self.current_run: Any = None
        self.loss_history: list[float] = []
        self.runs_history: list[Any] = []
        # Multi-run state
        self.multi_run_trainer: Any = None
        self.multi_run_is_running: bool = False
        self.multi_run_results: Any = None
        self.multi_run_current_run: int = 0
        self.multi_run_loss_history: list[float] = []
        self.multi_run_run_boundaries: list[int] = []
        # Dataset state
        self.dataset_loader: DatasetLoader | None = None
        self.dataset_validation: ValidationResult | None = None
        self.train_start_time: float = 0.0
        self.multi_run_start_time: float = 0.0
        # Stop signal for cooperative cancellation
        self.stop_requested: threading.Event = threading.Event()


state = UIState()


# =============================================================================
# EVENT BUFFER (C-UX-002, C-UX-003)
# =============================================================================
#
# Stage B added real backend retry / OOM-shrink / GPU-pause behavior, but those
# events log to the server only. UI users running share=True + auth have no
# access to server logs, so a 90-second cooldown pause looks like a freeze.
#
# Shape: a bounded thread-safe deque of timestamped strings. The training and
# multi-run generators emit events into it via _push_event(); a gr.Timer
# polls _format_event_log() on a 0.5-1s cadence to drive a status banner.
#
# We also attach a custom logging handler that mirrors the "hf_retry",
# "oom_retry", "gpu_paused", "gpu_resumed" loglines from trainer.py /
# multi_run.py / datasets.py into the deque so this works without requiring
# the backend to publish a structured queue. The classifier is keyword-based;
# it errs on the side of surfacing too much rather than too little.

_EVENT_BUFFER_MAX = 100
_event_buffer: deque[tuple[float, str]] = deque(maxlen=_EVENT_BUFFER_MAX)
_event_buffer_lock = threading.Lock()


def _push_event(message: str) -> None:
    """Append a timestamped event to the shared UI event buffer.

    Thread-safe. Used by training generators and the log-mirror handler to
    surface backend events (HF retries, OOM batch-shrink, GPU pause/resume,
    run lifecycle) into the UI status panel.
    """
    if not message:
        return
    # Trim a single very long line so a runaway traceback can't dominate the
    # buffer. 200 chars is enough to convey the event without flooding.
    message = message.replace("\n", " ").replace("\r", " ")[:200]
    with _event_buffer_lock:
        _event_buffer.append((time.time(), message))


def _format_event_log(max_lines: int = 30) -> str:
    """Format the event buffer as a newline-separated string for display."""
    with _event_buffer_lock:
        # Take the most-recent max_lines events
        items = list(_event_buffer)[-max_lines:]
    if not items:
        return "(no events yet — run-time messages will appear here)"
    lines = []
    for ts, msg in items:
        # HH:MM:SS local time
        ts_str = time.strftime("%H:%M:%S", time.localtime(ts))
        lines.append(f"[{ts_str}] {msg}")
    return "\n".join(lines)


# Keyword tokens for the log-mirror handler. Keep narrow so we don't flood
# the user with every routine log line — only the events Stage B made real.
_EVENT_LOG_KEYWORDS = (
    "Retrying",          # trainer.py HF retry
    "retry",             # generic retry signal
    "OOM",               # CUDA OOM
    "out of memory",     # torch OutOfMemoryError text
    "batch_size",        # batch-shrink retry surface
    "GPU at",            # gpu_safety pause line "GPU at 92C, pausing"
    "pausing",           # pause keyword
    "resuming",          # resume keyword
    "cooling",           # gpu cooling
    "loaded model",      # load_model completion
    "Loading model",     # load_model start
    "Downloading",       # HF Hub download
    "Resolving",         # HF Hub resolve
)


class _UIEventLogHandler(logging.Handler):
    """Mirror selected log records into the UI event buffer.

    This bridges the Stage B backend (which logs structured retry / pause /
    resume events) to the Stage C UI (which needs to surface them to users
    who have no access to server logs). Keyword-gated so we don't push
    every INFO line to the UI.
    """

    def emit(self, record: logging.LogRecord) -> None:
        try:
            msg = record.getMessage()
        except Exception:  # pragma: no cover - defensive against bad formatters
            return
        if not any(kw.lower() in msg.lower() for kw in _EVENT_LOG_KEYWORDS):
            return
        # Tag with the level so the user knows whether it's a warning
        level = record.levelname
        _push_event(f"{level}: {_redact_paths(msg)}")


def _install_event_log_handler() -> None:
    """Attach the UI event log handler to the package root logger.

    Idempotent — calling twice doesn't duplicate the handler.
    """
    pkg_logger = logging.getLogger("backpropagate")
    for h in pkg_logger.handlers:
        if isinstance(h, _UIEventLogHandler):
            return
    handler = _UIEventLogHandler(level=logging.INFO)
    handler.setFormatter(logging.Formatter("%(message)s"))
    pkg_logger.addHandler(handler)


def refresh_event_log() -> str:
    """gr.Timer-bound poll function that returns the current event log."""
    return _format_event_log()


# =============================================================================
# UI HELPER FUNCTIONS
# =============================================================================

def get_gpu_status_display() -> str:
    """Get formatted GPU status for display."""
    gpu = get_gpu_info()
    if gpu.get("available"):
        name = gpu.get("device_name", "Unknown GPU")
        total = gpu.get("memory_total", 0) / (1024**3)
        allocated = gpu.get("memory_allocated", 0) / (1024**3)
        return f"**{name}**\n\nVRAM: {allocated:.1f} / {total:.1f} GB"
    return "**No GPU detected**"


def get_system_status() -> str:
    """Get formatted system status."""
    info = get_system_info()
    features = list_available_features()

    lines = [
        f"**Python:** {info.get('python_version', 'Unknown').split()[0]}",
        f"**Platform:** {info.get('platform', 'Unknown')[:30]}",
        "",
        "**Features:**",
    ]
    for name, _desc in features.items():
        lines.append(f"- {name}")

    return "\n".join(lines)


def format_loss_plot(losses: list[float]) -> dict[str, Any]:
    """Format loss history for plotting."""
    if not losses:
        return {"data": [], "layout": {"title": "Training Loss"}}

    return {
        "data": [
            {
                "x": list(range(1, len(losses) + 1)),
                "y": losses,
                "type": "scatter",
                "mode": "lines+markers",
                "name": "Loss",
                "line": {"color": "#7EC8C8", "width": 2},
                "marker": {"size": 4},
            }
        ],
        "layout": {
            "title": "",
            "xaxis": {"title": "Step", "gridcolor": "#3A4554"},
            "yaxis": {"title": "Loss", "gridcolor": "#3A4554"},
            "paper_bgcolor": "#232830",
            "plot_bgcolor": "#232830",
            "font": {"color": "#F0F4F8"},
            "margin": {"l": 50, "r": 20, "t": 20, "b": 50},
        },
    }


def format_multi_run_plot(losses: list[float], run_boundaries: list[int]) -> dict[str, Any]:
    """Format multi-run loss history with run boundaries marked."""
    if not losses:
        return {"data": [], "layout": {"title": "Multi-Run Loss"}}

    data = [
        {
            "x": list(range(1, len(losses) + 1)),
            "y": losses,
            "type": "scatter",
            "mode": "lines",
            "name": "Loss",
            "line": {"color": "#7EC8C8", "width": 2},
        }
    ]

    # Add vertical lines for run boundaries
    shapes = []
    for _i, boundary in enumerate(run_boundaries):
        if boundary > 0:  # Skip first boundary at 0
            shapes.append({
                "type": "line",
                "x0": boundary,
                "x1": boundary,
                "y0": 0,
                "y1": 1,
                "yref": "paper",
                "line": {"color": "#F59E0B", "width": 1, "dash": "dash"},
            })

    return {
        "data": data,
        "layout": {
            "title": "",
            "xaxis": {"title": "Step (aggregate)", "gridcolor": "#3A4554"},
            "yaxis": {"title": "Loss", "gridcolor": "#3A4554"},
            "paper_bgcolor": "#232830",
            "plot_bgcolor": "#232830",
            "font": {"color": "#F0F4F8"},
            "margin": {"l": 50, "r": 20, "t": 20, "b": 50},
            "shapes": shapes,
        },
    }


def get_gpu_safety_status() -> str:
    """Get detailed GPU safety status for display."""
    status = get_gpu_status()  # From gpu_safety module - returns GPUStatus object

    if not status.available:
        return "**No GPU detected**"

    # Build status string
    lines = [f"**{status.device_name}**"]

    if status.temperature_c is not None:
        temp_color = "green"
        if status.temperature_c >= 80:
            temp_color = "orange"
        if status.temperature_c >= 90:
            temp_color = "red"
        lines.append(f"Temp: {status.temperature_c}C")

    lines.append(f"VRAM: {status.vram_used_gb:.1f} / {status.vram_total_gb:.1f} GB ({status.vram_percent:.0f}%)")

    if status.power_draw_w is not None:
        lines.append(f"Power: {status.power_draw_w:.0f}W")

    # Safety condition
    condition_emoji = {
        GPUCondition.SAFE: "OK",
        GPUCondition.WARM: "Warm",
        GPUCondition.WARNING: "Warning",
        GPUCondition.CRITICAL: "CRITICAL",
        GPUCondition.EMERGENCY: "EMERGENCY",
        GPUCondition.UNKNOWN: "Unknown",
    }
    lines.append(f"Status: {condition_emoji.get(status.condition, 'Unknown')}")

    return "\n\n".join(lines)


# =============================================================================
# DATASET FUNCTIONS
# =============================================================================

def load_dataset_file(file_obj: Any, request: gr.Request | None = None) -> tuple[str, str, Any, Any, str]:
    """
    Load and validate a dataset file with security checks.

    Security features:
    - Rate limiting to prevent abuse
    - File extension validation (CVE-2024-47872 mitigation)
    - File size validation
    - Path sanitization
    """
    # Rate limit check
    allowed, wait_time = _upload_limiter.check(request)
    if not allowed:
        raise gr.Error(
            f"Too many uploads. Please wait {wait_time:.0f} seconds.",
            duration=10,
            title="Rate Limited",
        )

    if file_obj is None:
        raise gr.Error("Please select a file to upload.", duration=5)

    # Validate file using security module (CVE-2024-47872 mitigation)
    is_valid, error_msg, validated_path = _file_validator.validate(file_obj, purpose="dataset_upload")
    if not is_valid:
        log_security_event(
            "file_upload_rejected",
            error=error_msg,
            filename=getattr(file_obj, "name", "unknown"),
        )
        raise gr.Error(error_msg, duration=10, title="Invalid File")

    try:
        if validated_path is None:
            raise gr.Error("File validation failed", duration=10, title="Invalid File")

        file_path = str(validated_path)
        loader = DatasetLoader(file_path)
        state.dataset_loader = loader
        state.dataset_validation = loader.validation_result

        # Log successful upload
        log_security_event(
            "file_upload_success",
            filename=validated_path.name,
            format=loader.detected_format.value,
            samples=len(loader),
        )

        # Show info message
        gr.Info(f"Loaded {len(loader)} samples", duration=3)

        # Build status message
        status_lines = [
            f"**Format detected:** {loader.detected_format.value}",
            f"**Total samples:** {len(loader)}",
        ]

        if loader.is_valid:
            status_lines.append("**Validation:** ✅ Passed")
        else:
            status_lines.append(f"**Validation:** ⚠️ {loader.validation_result.error_count} errors")
            # Show warning for validation issues
            gr.Warning(
                f"Dataset has {loader.validation_result.error_count} validation errors. "
                "Check the validation report for details.",
                duration=5,
            )

        # Get stats
        stats = loader.stats()
        status_lines.extend([
            "",
            f"**Approx. tokens:** {stats.total_tokens_approx:,}",
            f"**Avg tokens/sample:** {stats.avg_tokens_per_sample:.0f}",
            f"**Has system prompts:** {'Yes' if stats.has_system_prompts else 'No'}",
            f"**Avg turns/conversation:** {stats.avg_turns_per_conversation:.1f}",
        ])

        status = "\n".join(status_lines)

        # Get validation report
        validation_text = loader.validation_report()

        # Get preview samples
        # C-UX-005: safe_markdown_fence escapes user content so a sample
        # containing ``` doesn't break the outer fence or inject markdown.
        previews = loader.preview(n=3, as_chatml=True)
        preview_text = "\n\n---\n\n".join([
            f"**Sample {i+1}:**\n{safe_markdown_fence(p)}"
            for i, p in enumerate(previews)
        ])

        # Format table data
        table_data = [
            ["Format", loader.detected_format.value],
            ["Samples", str(len(loader))],
            ["Valid", "Yes" if loader.is_valid else "No"],
            ["Errors", str(loader.validation_result.error_count)],
            ["Warnings", str(loader.validation_result.warning_count)],
            ["Approx. Tokens", f"{stats.total_tokens_approx:,}"],
            ["Avg Tokens/Sample", f"{stats.avg_tokens_per_sample:.0f}"],
            ["System Prompts", str(stats.unique_system_prompts)],
        ]

        return (
            status,
            validation_text,
            gr.update(value=table_data),
            gr.update(value=preview_text),
            "✅ Loaded successfully!",
        )

    except gr.Error:
        # Re-raise Gradio errors as-is
        raise
    except FileNotFoundError as e:
        logger.error(f"Dataset file not found: {e}")
        raise gr.Error("File not found (path redacted). Check the server logs for details.", duration=10, title="File Not Found")
    except Exception as e:
        logger.exception("Failed to load dataset")
        log_security_event(
            "file_upload_error",
            error=str(e)[:200],
            filename=getattr(file_obj, "name", "unknown"),
        )
        # FB-011: don't leak the raw exception (may contain HF cache / home
        # directory paths). Sanitize via the central helper.
        user_msg, hint = sanitize_error_for_user(e, operation="dataset load")
        if hint:
            user_msg = f"{user_msg}\n\nHint: {hint}"
        raise gr.Error(user_msg, duration=10, title="Load Error")


def convert_dataset_format(target_format: str) -> tuple:
    """Convert loaded dataset to target format."""
    if state.dataset_loader is None:
        return "No dataset loaded", ""

    try:
        if target_format == "ChatML":
            samples = state.dataset_loader.to_chatml()
            # Show first 3 samples
            # C-UX-005: safe_markdown_fence escapes converted ChatML text.
            preview = "\n\n---\n\n".join([
                f"**Sample {i+1}:**\n{safe_markdown_fence(s['text'])}"
                for i, s in enumerate(samples[:3])
            ])
            return f"Converted {len(samples)} samples to ChatML format", preview

        return "Unsupported format", ""

    except Exception as e:
        logger.exception("Failed to convert dataset")
        # FB-011: sanitize before surfacing to the markdown component.
        user_msg, suggestion = sanitize_error_for_user(e, operation="dataset conversion")
        if suggestion:
            return f"Error: {user_msg}\n\nHint: {suggestion}", ""
        return f"Error: {user_msg}", ""


def export_converted_dataset(output_path: str) -> str:
    """Export the converted dataset to a file."""
    if state.dataset_loader is None:
        return "No dataset loaded"

    # Validate output path — constrained to the UI output base so authenticated
    # remote users (share=True + --auth) can't write the converted dataset to
    # arbitrary filesystem locations. See ui_security.get_ui_output_dir.
    is_valid, error_msg, validated_path = validate_path_input(
        output_path, allowed_base=get_ui_output_dir()
    )
    if not is_valid or validated_path is None:
        return f"Invalid output path: {error_msg}"

    try:
        import json

        validated_path.parent.mkdir(parents=True, exist_ok=True)

        samples = state.dataset_loader.to_chatml()

        with open(validated_path, "w", encoding="utf-8") as f:
            for sample in samples:
                f.write(json.dumps(sample) + "\n")

        return f"Exported {len(samples)} samples to {validated_path}"

    except Exception as e:
        logger.exception("Failed to export dataset")
        # FB-011: sanitize before surfacing to the markdown component.
        user_msg, suggestion = sanitize_error_for_user(e, operation="dataset export")
        if suggestion:
            return f"Error: {user_msg}\n\nHint: {suggestion}"
        return f"Error: {user_msg}"


def refresh_dataset_preview(show_raw: bool) -> str:
    """Refresh the preview with raw or ChatML format."""
    if state.dataset_loader is None:
        return "No dataset loaded"

    try:
        if show_raw:
            import json
            samples = state.dataset_loader.samples[:3]
            # C-UX-005: safe fence for raw JSON dump.
            return "\n\n---\n\n".join([
                f"**Sample {i+1}:**\n{safe_markdown_fence(json.dumps(s, indent=2), language='json')}"
                for i, s in enumerate(samples)
            ])
        else:
            previews = state.dataset_loader.preview(n=3, as_chatml=True)
            # C-UX-005: safe fence for ChatML preview.
            return "\n\n---\n\n".join([
                f"**Sample {i+1}:**\n{safe_markdown_fence(p)}"
                for i, p in enumerate(previews)
            ])

    except Exception as e:
        logger.exception("Failed to refresh dataset preview")
        # FB-011: sanitize before surfacing to the markdown component.
        user_msg, _suggestion = sanitize_error_for_user(e, operation="dataset preview refresh")
        return f"Error: {user_msg}"


# =============================================================================
# TRAINING FUNCTIONS
# =============================================================================

def start_training(
    model_preset: str,
    custom_model: str,
    dataset_preset: str,
    custom_dataset: str,
    max_samples: int,
    max_steps: int,
    learning_rate: float,
    batch_size: int,
    lora_r: int,
    lora_alpha: int,
    progress: Any = gr.Progress(),
    request: gr.Request | None = None,
) -> Generator[tuple[Any, ...], None, None]:
    """
    Start a training run with security checks.

    Security features:
    - Rate limiting with IP tracking
    - Input validation for all parameters
    - Model name sanitization
    - Path validation for custom datasets
    - Security event logging
    """
    from .trainer import Trainer, TrainingCallback

    # Rate limiting check with IP tracking
    allowed, wait_time = _training_limiter.check(request)
    if not allowed:
        log_security_event(
            "training_rate_limited",
            wait_seconds=wait_time,
        )
        raise gr.Error(
            f"Too many training requests. Please wait {wait_time:.0f} seconds.",
            duration=10,
            title="Rate Limited",
        )

    # Validate numeric inputs
    try:
        max_samples = int(validate_numeric_input(max_samples, "Max samples", min_value=1, max_value=1000000) or 0)
        max_steps = int(validate_numeric_input(max_steps, "Max steps", min_value=1, max_value=100000) or 0)
        learning_rate = float(validate_numeric_input(learning_rate, "Learning rate", min_value=1e-8, max_value=1.0) or 0.0)
        batch_size = int(validate_numeric_input(batch_size, "Batch size", min_value=1, max_value=64) or 0)
        lora_r = int(validate_numeric_input(lora_r, "LoRA rank", min_value=1, max_value=256) or 0)
        lora_alpha = int(validate_numeric_input(lora_alpha, "LoRA alpha", min_value=1, max_value=512) or 0)
    except gr.Error:
        raise
    except Exception as e:
        raise gr.Error(f"Invalid parameter: {e}", duration=10)

    # Resolve and sanitize model name
    # C-UX-001: the "Custom / Other" preset (CUSTOM_MODEL_CHOICE) maps to empty
    # string, which signals "use the user's custom_model textbox"; fall through
    # to the sanitize branch for that case.
    if model_preset in MODEL_PRESETS and model_preset != CUSTOM_MODEL_CHOICE:
        model_name = MODEL_PRESETS[model_preset]
    else:
        model_name = sanitize_model_name(custom_model)
        if not model_name:
            raise gr.Error(
                "Invalid model name. Use format: org/model-name",
                duration=10,
                title="Invalid Model",
            )

    # Resolve dataset with path validation for custom datasets
    # UI-002: If the user uploaded a dataset in the Dataset tab, use it directly
    dataset_loader_obj = None
    if dataset_preset == "Custom JSONL":
        if state.dataset_loader is not None:
            # Use the already-loaded DatasetLoader from the Dataset tab
            dataset_loader_obj = state.dataset_loader
            dataset_name = str(state.dataset_loader.source)
        elif custom_dataset and custom_dataset.strip():
            is_valid, error_msg, validated_path = validate_path_input(custom_dataset, must_exist=True)
            if not is_valid:
                raise gr.Error(f"Dataset error: {error_msg}", duration=10, title="Invalid Dataset")
            dataset_name = str(validated_path)
        else:
            raise gr.Error(
                "No custom dataset specified. Upload a file in the Dataset tab or enter a path.",
                duration=10,
                title="Missing Dataset",
            )
    elif dataset_preset in DATASET_PRESETS:
        dataset_name = DATASET_PRESETS[dataset_preset]
    else:
        dataset_name = settings.data.dataset_name

    # Log training start
    log_security_event(
        "training_started",
        model=model_name,
        dataset=dataset_name[:100],
        samples=max_samples,
        steps=max_steps,
    )

    state.is_training = True
    state.loss_history = []
    state.train_start_time = time.time()
    state.stop_requested.clear()

    # C-UX-002/003: surface run lifecycle into the UI event buffer so users
    # see what's happening during the otherwise-silent load + train windows.
    _push_event(f"run_started: model={model_name} samples={max_samples} steps={max_steps}")

    # Show info message
    gr.Info(f"Starting training with {model_name}...", duration=3)

    status = f"🚀 Initializing trainer with {model_name}..."
    yield status, format_loss_plot([]), get_gpu_status_display()

    try:
        # Check for cooperative stop between phases
        if state.stop_requested.is_set():
            yield "⚠️ Training stopped before model load", format_loss_plot([]), get_gpu_status_display()
            return

        # Create trainer
        state.trainer = Trainer(
            model=model_name,
            lora_r=lora_r,
            lora_alpha=lora_alpha,
            learning_rate=learning_rate,
            batch_size=batch_size,
        )

        status = "📦 Loading model (this may take several minutes for large models)..."
        # C-UX-002: gr.Progress feedback during the 30s-5min load window so
        # users don't think the UI is frozen. Granular phases come from
        # the HF Hub log lines mirrored into the event buffer.
        try:
            progress(0.0, desc=f"Downloading and loading {model_name}...")
        except Exception:  # gr.Progress is best-effort
            pass
        _push_event(f"load_model start: {model_name}")
        yield status, format_loss_plot([]), get_gpu_status_display()

        if state.stop_requested.is_set():
            yield "⚠️ Training stopped before model load", format_loss_plot([]), get_gpu_status_display()
            return

        load_start = time.time()
        state.trainer.load_model()
        load_elapsed = time.time() - load_start

        try:
            progress(1.0, desc=f"Model loaded in {load_elapsed:.0f}s")
        except Exception:
            pass
        _push_event(f"load_model complete in {load_elapsed:.0f}s")

        status = f"📦 Model loaded in {load_elapsed:.0f}s"
        yield status, format_loss_plot([]), get_gpu_status_display()

        if state.stop_requested.is_set():
            yield "⚠️ Training stopped before training started", format_loss_plot([]), get_gpu_status_display()
            return

        status = f"🏋️ Training on {max_samples} samples for {max_steps} steps..."
        yield status, format_loss_plot([]), get_gpu_status_display()

        # UI-003: Build a stop-check callback so the stop button works during training
        def _stop_check_on_step(step: int, loss: float) -> None:
            if state.stop_requested.is_set():
                raise KeyboardInterrupt("Training stopped by user")

        stop_callback = TrainingCallback(on_step=_stop_check_on_step)

        # Train — pass DatasetLoader directly when available (UI-002)
        train_dataset_arg = dataset_loader_obj if dataset_loader_obj is not None else (
            dataset_name if dataset_name != "custom" else None
        )
        run = state.trainer.train(
            dataset=train_dataset_arg,
            steps=max_steps,
            samples=max_samples,
            callback=stop_callback,
        )

        state.current_run = run
        state.loss_history = run.loss_history
        state.runs_history.append(run)

        # Log training success
        log_security_event(
            "training_completed",
            model=model_name,
            final_loss=run.final_loss,
            duration_seconds=run.duration_seconds,
        )

        # Show success info
        gr.Info(f"Training complete! Loss: {run.final_loss:.4f}", duration=5)

        _push_event(f"run_completed: final_loss={run.final_loss:.4f} duration={run.duration_seconds:.1f}s")

        status = f"✅ Training complete! Final loss: {run.final_loss:.4f}"
        yield status, format_loss_plot(run.loss_history), get_gpu_status_display()

    except KeyboardInterrupt:
        logger.info("Training interrupted by user")
        gr.Warning("Training interrupted by user", duration=5)
        _push_event("run_interrupted: stopped by user")
        yield "⚠️ Training interrupted", format_loss_plot(state.loss_history), get_gpu_status_display()

    except Exception as e:
        logger.exception(f"Training failed: {e}")
        log_security_event(
            "training_failed",
            model=model_name,
            error=str(e)[:200],
        )
        # FB-011: sanitize through the central helper so raw torch / HF /
        # transformers messages (which embed home directory + HF cache
        # paths) never reach the user toast or the status text. The full
        # exception stays in the server log via logger.exception above.
        user_msg, suggestion = sanitize_error_for_user(e, operation="training")
        if suggestion:
            gr.Warning(f"Training failed: {user_msg}", duration=10)
            status = f"❌ Training failed: {user_msg}\n\n💡 **Suggestion:** {suggestion}"
        else:
            gr.Warning(f"Training failed: {user_msg}", duration=10)
            status = f"❌ Training failed: {user_msg}"
        _push_event(f"run_failed: {user_msg}")
        yield status, format_loss_plot(state.loss_history), get_gpu_status_display()

    finally:
        state.is_training = False


def stop_training() -> str:
    """Stop the current training run cooperatively.

    Sets the stop_requested event so the training generator loop
    breaks after the current step completes.
    """
    state.stop_requested.set()
    state.is_training = False
    gr.Info("Training will stop after the current step completes.", duration=5)
    return "Training stop requested — finishing current step..."


def save_model(output_path: str, save_merged: bool) -> str:
    """Save the trained model."""
    if state.trainer is None:
        raise gr.Error("No model to save. Train a model first.", title="No Model")

    # Validate output path — constrained to the UI output base so authenticated
    # remote users (share=True + --auth) can't write the LoRA adapter or merged
    # weights to arbitrary filesystem locations. See ui_security.get_ui_output_dir.
    is_valid, error_msg, validated_path = validate_path_input(
        output_path, allowed_base=get_ui_output_dir()
    )
    if not is_valid:
        raise gr.Error(f"Invalid output path: {error_msg}", title="Invalid Path")

    try:
        path = state.trainer.save(str(validated_path), save_merged=save_merged)
        return f"Model saved to: {path}"
    except Exception as e:
        logger.exception("Model save failed")
        # FB-011: sanitize before surfacing — save paths can include the
        # operator's home directory and HF cache layout.
        user_msg, suggestion = sanitize_error_for_user(e, operation="save")
        if suggestion:
            user_msg = f"{user_msg}\n\nHint: {suggestion}"
        raise gr.Error(f"Save failed: {user_msg}", title="Save Error") from e


def export_model(
    export_format: str,
    quantization: str,
    output_path: str,
    request: gr.Request | None = None,
) -> str:
    """
    Export the trained model with security checks.

    Security features:
    - Rate limiting with IP tracking
    - Path validation
    - Security event logging
    """
    if state.trainer is None:
        raise gr.Error(
            "No model to export. Train a model first.",
            duration=10,
            title="No Model",
        )

    # Rate limiting for export operations with IP tracking
    allowed, wait_time = _export_limiter.check(request)
    if not allowed:
        log_security_event("export_rate_limited", wait_seconds=wait_time)
        raise gr.Error(
            f"Too many export requests. Please wait {wait_time:.0f} seconds.",
            duration=10,
            title="Rate Limited",
        )

    # Validate output path — constrained to the UI output base so authenticated
    # remote users (share=True + --auth) can't write GGUF/merged exports to
    # arbitrary filesystem locations. See ui_security.get_ui_output_dir.
    is_valid, error_msg, validated_path = validate_path_input(
        output_path, allowed_base=get_ui_output_dir()
    )
    if not is_valid:
        raise gr.Error(f"Invalid output path: {error_msg}", title="Invalid Path")

    try:
        result = state.trainer.export(
            format=export_format.lower(),
            output_dir=str(validated_path),
            quantization=quantization,
        )
        summary: str = result.summary()
        return summary
    except Exception as e:
        logger.exception("Model export failed")
        # FB-011: sanitize export errors — these frequently embed the GGUF
        # writer's internal temp paths and the HF cache layout.
        user_msg, suggestion = sanitize_error_for_user(e, operation="export")
        if suggestion:
            user_msg = f"{user_msg}\n\nHint: {suggestion}"
        raise gr.Error(f"Export failed: {user_msg}", title="Export Error") from e


def register_ollama(gguf_path: str, model_name: str, system_prompt: str) -> str:
    """Register a GGUF model with Ollama."""
    from .export import register_with_ollama

    # Validate GGUF path — constrained to the UI output base so authenticated
    # remote users (share=True + --auth) can only register GGUFs that previously
    # came out of the export pipeline. See ui_security.get_ui_output_dir.
    is_valid, error_msg, validated_path = validate_path_input(
        gguf_path, allowed_base=get_ui_output_dir(), must_exist=True
    )
    if not is_valid or validated_path is None:
        return f"Invalid GGUF path: {error_msg}"

    # Sanitize model name
    safe_model_name = sanitize_model_name(model_name)
    if not safe_model_name:
        return "Invalid model name. Use only alphanumeric characters, hyphens, and underscores."

    # Sanitize system prompt
    safe_system_prompt = sanitize_text_input(system_prompt, max_length=2000) if system_prompt else None

    try:
        success = register_with_ollama(
            gguf_path=validated_path,
            model_name=safe_model_name,
            system_prompt=safe_system_prompt if safe_system_prompt and safe_system_prompt.strip() else None,
        )

        if success:
            # C-UX-005: safe_model_name has been sanitized but still wrap
            # via safe_markdown_fence in case future validation widens.
            run_cmd = f"ollama run {safe_model_name}"
            return (
                f"Successfully registered with Ollama!\n\nRun with:\n"
                f"{safe_markdown_fence(run_cmd)}"
            )
        else:
            return "Failed to register with Ollama. Check that Ollama is running."

    except Exception as e:
        logger.exception("Ollama registration failed")
        # FB-011: sanitize before returning the message to the UI markdown.
        user_msg, suggestion = sanitize_error_for_user(e, operation="Ollama registration")
        if suggestion:
            return f"Ollama registration failed: {user_msg}\n\nHint: {suggestion}"
        return f"Ollama registration failed: {user_msg}"


def list_ollama() -> str:
    """List models registered with Ollama."""
    from .export import list_ollama_models

    try:
        models = list_ollama_models()
        if not models:
            return "No Ollama models found. Is Ollama running?"

        return "**Ollama Models:**\n" + "\n".join([f"- {m}" for m in models])

    except Exception as e:
        logger.exception("Failed to list Ollama models")
        # FB-011: sanitize before surfacing.
        user_msg, _suggestion = sanitize_error_for_user(e, operation="Ollama list")
        return f"Error listing Ollama models: {user_msg}"


def create_ollama_modelfile(gguf_path: str, output_path: str, system_prompt: str, temperature: float) -> str:
    """Create an Ollama Modelfile."""
    from .export import create_modelfile

    # Both the GGUF source and the Modelfile destination are constrained to the
    # UI output base so authenticated remote users (share=True + --auth) can't
    # read arbitrary disk locations or write Modelfiles to system paths.
    # See ui_security.get_ui_output_dir.
    ui_base = get_ui_output_dir()

    # Validate GGUF path
    is_valid, error_msg, validated_gguf = validate_path_input(
        gguf_path, allowed_base=ui_base, must_exist=True
    )
    if not is_valid or validated_gguf is None:
        return f"Invalid GGUF path: {error_msg}"

    # Validate output path if provided
    validated_output = None
    if output_path and output_path.strip():
        is_valid, error_msg, validated_output = validate_path_input(
            output_path, allowed_base=ui_base
        )
        if not is_valid:
            return f"Invalid output path: {error_msg}"

    # Sanitize system prompt
    safe_system_prompt = sanitize_text_input(system_prompt, max_length=2000) if system_prompt else None

    try:
        modelfile = create_modelfile(
            gguf_path=validated_gguf,
            output_path=validated_output,
            system_prompt=safe_system_prompt if safe_system_prompt and safe_system_prompt.strip() else None,
            temperature=temperature,
        )

        content = modelfile.read_text()
        # C-UX-005: Modelfile body is read from disk and may contain
        # arbitrary content (a malicious file could embed ``` markers to
        # inject markdown into the operator's screen). safe_markdown_fence
        # picks a fence longer than any backtick run in the content.
        return f"Modelfile created: {modelfile}\n\n{safe_markdown_fence(content)}"

    except Exception as e:
        logger.exception("Modelfile creation failed")
        # FB-011: sanitize before returning the message to the UI markdown.
        user_msg, suggestion = sanitize_error_for_user(e, operation="Modelfile creation")
        if suggestion:
            return f"Failed to create Modelfile: {user_msg}\n\nHint: {suggestion}"
        return f"Failed to create Modelfile: {user_msg}"


def get_runs_table() -> list[list[Any]]:
    """Get training runs as table data."""
    rows = []
    for run in state.runs_history:
        rows.append([
            run.run_id,
            run.steps,
            f"{run.final_loss:.4f}",
            f"{run.duration_seconds:.1f}s",
            run.samples_seen,
        ])
    return rows


# =============================================================================
# MULTI-RUN FUNCTIONS
# =============================================================================

def start_multi_run(
    model_preset: str,
    custom_model: str,
    dataset_preset: str,
    custom_dataset: str,
    num_runs: int,
    steps_per_run: int,
    samples_per_run: int,
    merge_mode: str,
    initial_lr: float,
    final_lr: float,
    max_temp: float,
    # Phase 4 advanced options
    adaptive_scaling: bool = False,
    layer_scaling: bool = False,
    early_stopping: bool = False,
    early_patience: int = 2,
    val_samples: int = 100,
    # Phase 5.3 checkpoint options
    ckpt_auto_prune: bool = True,
    ckpt_keep_best: int = 3,
    ckpt_max_total: int = 10,
    ckpt_keep_final: bool = True,
    ckpt_keep_boundaries: bool = False,
    _progress: Any = gr.Progress(),
    _request: gr.Request | None = None,
) -> Any:
    """Start SLAO Multi-Run training with input validation."""
    from .multi_run import MergeMode, MultiRunConfig, MultiRunTrainer

    # Rate limiting (same as start_training)
    allowed, wait_time = _training_limiter.check(_request)
    if not allowed:
        log_security_event("multi_run_rate_limited", wait_seconds=wait_time)
        raise gr.Error(
            f"Too many training requests. Please wait {wait_time:.0f} seconds.",
            duration=10,
            title="Rate Limited",
        )

    # Validate numeric inputs (mirrors start_training validation)
    try:
        num_runs = int(validate_numeric_input(num_runs, "Number of runs", min_value=1, max_value=20) or 0)
        steps_per_run = int(validate_numeric_input(steps_per_run, "Steps per run", min_value=1, max_value=100000) or 0)
        if samples_per_run:
            samples_per_run = int(validate_numeric_input(samples_per_run, "Samples per run", min_value=1, max_value=1000000) or 0)
        initial_lr = float(validate_numeric_input(initial_lr, "Initial learning rate", min_value=1e-8, max_value=1.0) or 0.0)
        final_lr = float(validate_numeric_input(final_lr, "Final learning rate", min_value=1e-8, max_value=1.0) or 0.0)
        max_temp = float(validate_numeric_input(max_temp, "Max GPU temperature", min_value=1.0, max_value=100.0) or 85.0)
    except gr.Error:
        raise
    except Exception as e:
        raise gr.Error(f"Invalid parameter: {e}", duration=10) from None

    if final_lr > initial_lr:
        raise gr.Error(
            f"Final LR ({final_lr}) must be <= Initial LR ({initial_lr})",
            duration=10,
            title="Invalid Learning Rate",
        )

    # Resolve and sanitize model name
    # C-UX-001: same custom-preset fall-through as start_training.
    if model_preset in MODEL_PRESETS and model_preset != CUSTOM_MODEL_CHOICE:
        model_name = MODEL_PRESETS[model_preset]
    else:
        model_name = sanitize_model_name(custom_model)
        if not model_name:
            raise gr.Error(
                "Invalid model name. Use format: org/model-name",
                duration=10,
                title="Invalid Model",
            )

    # Resolve dataset with path validation for custom datasets
    # C-UX-010: mirror the Train tab's pattern — if the user uploaded a
    # dataset in the Dataset tab, use that DatasetLoader directly instead of
    # forcing the user to retype a path that the Multi-Run tab has no
    # uploader for. Falls back to the path-validation branch otherwise.
    mr_dataset_loader_obj = None
    if dataset_preset == "Custom JSONL":
        if state.dataset_loader is not None:
            mr_dataset_loader_obj = state.dataset_loader
            dataset_name = str(state.dataset_loader.source)
        elif custom_dataset and custom_dataset.strip():
            is_valid, error_msg, validated_path = validate_path_input(custom_dataset, must_exist=True)
            if not is_valid:
                raise gr.Error(f"Dataset error: {error_msg}", duration=10, title="Invalid Dataset")
            dataset_name = str(validated_path)
        else:
            raise gr.Error(
                "No custom dataset specified. Upload a file in the Dataset tab or enter a path.",
                duration=10,
                title="Missing Dataset",
            )
    elif dataset_preset in DATASET_PRESETS:
        dataset_name = DATASET_PRESETS[dataset_preset]
    else:
        dataset_name = settings.data.dataset_name

    state.multi_run_is_running = True
    state.multi_run_loss_history = []
    state.multi_run_run_boundaries = []
    state.multi_run_current_run = 0
    state.multi_run_start_time = time.time()

    _push_event(
        f"multi_run_started: model={model_name} runs={num_runs} "
        f"steps_per_run={steps_per_run}"
    )

    status = f"Initializing SLAO Multi-Run with {model_name}..."
    yield (
        status,
        format_multi_run_plot([], []),
        get_gpu_safety_status(),
        get_multi_run_progress_table(),
    )

    # C-UX-011: adaptive_scaling and layer_scaling are wired in the UI
    # (mr_adaptive_scaling, mr_layer_scaling checkboxes) but MultiRunConfig
    # does not currently accept these fields. Adding fields is the backend
    # team's responsibility (cross-domain). Until that lands, surface a
    # gr.Warning when the user has enabled either checkbox so they're not
    # silently no-op'd. TODO(backend): plumb adaptive_scaling and
    # layer_scaling into MultiRunConfig + the SLAO merge implementation,
    # then thread the values through the kwargs below.
    if adaptive_scaling or layer_scaling:
        enabled = []
        if adaptive_scaling:
            enabled.append("Adaptive Scaling")
        if layer_scaling:
            enabled.append("Layer Scaling")
        gr.Warning(
            f"{' and '.join(enabled)} not yet implemented in the merge "
            "backend — this run will proceed with the default SLAO "
            "merge. Tracking issue: backend MultiRunConfig field "
            "addition.",
            duration=8,
        )
        _push_event(
            f"WARN: {' and '.join(enabled)} requested but no-op "
            "(backend field missing). Run proceeds with default SLAO."
        )
        logger.warning(
            "Advanced SLAO checkboxes set but MultiRunConfig has no "
            "adaptive_scaling/layer_scaling fields: adaptive=%s layer=%s",
            adaptive_scaling, layer_scaling,
        )

    try:
        config = MultiRunConfig(
            num_runs=int(num_runs),
            steps_per_run=int(steps_per_run),
            samples_per_run=int(samples_per_run),
            merge_mode=MergeMode(merge_mode.lower()),
            initial_lr=initial_lr,
            final_lr=final_lr,
            max_temp_c=max_temp,
            checkpoint_dir="./output/multi_run",
            # Phase 4 options
            validate_every_run=early_stopping,  # Enable validation if early stopping is on
            validation_samples=int(val_samples),
            early_stopping=early_stopping,
            early_stopping_patience=int(early_patience),
            # TODO(backend, C-UX-011): once MultiRunConfig grows
            # adaptive_scaling: bool and layer_scaling: bool fields, pass
            # them here. The UI inputs already exist; only the backend
            # plumbing is missing.
            # Phase 5.3 checkpoint options
            checkpoint_keep_best_n=int(ckpt_keep_best),
            checkpoint_keep_final=ckpt_keep_final,
            checkpoint_keep_run_boundaries=ckpt_keep_boundaries,
            checkpoint_max_total=int(ckpt_max_total),
            checkpoint_auto_prune=ckpt_auto_prune,
        )

        def on_run_complete(run_result: Any) -> None:
            state.multi_run_current_run = run_result.run_index
            state.multi_run_loss_history.extend(run_result.loss_history)
            state.multi_run_run_boundaries.append(len(state.multi_run_loss_history))
            # C-UX-003: surface per-run completion so users see progress
            # without watching the server log.
            try:
                _push_event(
                    f"multi_run progress: run {run_result.run_index} "
                    f"complete, loss={run_result.final_loss:.4f}"
                )
            except Exception:
                # Be tolerant — UI event push should never break training
                pass

        state.multi_run_trainer = MultiRunTrainer(
            model=model_name,
            config=config,
            on_run_complete=on_run_complete,
        )

        status = f"Starting {num_runs} runs..."
        yield (
            status,
            format_multi_run_plot([], []),
            get_gpu_safety_status(),
            get_multi_run_progress_table(),
        )

        # Run the multi-run training
        # C-UX-010: prefer the in-memory DatasetLoader (uploaded via the
        # Dataset tab) when available. If MultiRunTrainer.run() doesn't
        # accept a DatasetLoader, fall back to the source string. This keeps
        # the parity with the Train tab without forcing a backend change.
        mr_dataset_arg: Any
        if mr_dataset_loader_obj is not None:
            try:
                mr_dataset_arg = mr_dataset_loader_obj  # MultiRunTrainer may accept it directly
                result = state.multi_run_trainer.run(mr_dataset_arg)
            except TypeError:
                # Older MultiRunTrainer signature only accepts a string path
                logger.info("MultiRunTrainer.run did not accept DatasetLoader; falling back to source path")
                result = state.multi_run_trainer.run(dataset_name)
        else:
            result = state.multi_run_trainer.run(dataset_name)

        state.multi_run_results = result
        state.multi_run_loss_history = result.aggregate_loss_history
        state.multi_run_run_boundaries = result.run_boundaries

        if result.aborted:
            status = f"Multi-run aborted: {result.abort_reason}"
            _push_event(f"multi_run aborted: {result.abort_reason}")
        else:
            status = (
                f"Multi-run complete! {result.total_runs} runs, "
                f"Final loss: {result.final_loss:.4f}, "
                f"Time: {result.total_duration_seconds/60:.1f}min"
            )
            _push_event(
                f"multi_run_completed: {result.total_runs} runs, "
                f"final_loss={result.final_loss:.4f}"
            )

        yield (
            status,
            format_multi_run_plot(result.aggregate_loss_history, result.run_boundaries),
            get_gpu_safety_status(),
            get_multi_run_progress_table(),
        )

    except Exception as e:
        logger.exception("Multi-run failed")
        # FB-011: sanitize via the central helper. BackpropagateError
        # subclasses still surface their code + suggestion; raw torch /
        # transformers errors are collapsed to the generic message so
        # absolute paths don't leak.
        user_msg, suggestion = sanitize_error_for_user(e, operation="multi-run training")
        if suggestion:
            error_msg = f"{user_msg}\n\nSuggestion: {suggestion}"
            gr.Warning(f"Multi-run failed: {user_msg} — {suggestion}", duration=10)
        else:
            error_msg = user_msg
            gr.Warning(f"Multi-run failed: {user_msg}", duration=10)
        _push_event(f"multi_run_failed: {user_msg}")
        status = f"Multi-run failed: {error_msg}"
        yield (
            status,
            format_multi_run_plot(state.multi_run_loss_history, state.multi_run_run_boundaries),
            get_gpu_safety_status(),
            get_multi_run_progress_table(),
        )

    finally:
        state.multi_run_is_running = False


def stop_multi_run() -> str:
    """Stop the current multi-run training."""
    if state.multi_run_trainer:
        state.multi_run_trainer.abort("User requested stop")
    state.multi_run_is_running = False
    return "Multi-run stop requested..."


def get_multi_run_progress_table() -> list[list[Any]]:
    """Get multi-run progress as table data."""
    if state.multi_run_results is None:
        return []

    rows = []
    for run in state.multi_run_results.runs:
        merge_info = ""
        if run.merge_result:
            merge_info = f"scale={run.merge_result.scale_factor:.3f}"

        rows.append([
            run.run_index,
            run.steps,
            run.samples,
            f"{run.final_loss:.4f}",
            f"{run.learning_rate:.2e}",
            f"{run.duration_seconds:.1f}s",
            merge_info,
        ])
    return rows


# =============================================================================
# PHASE 5: TRAINING DASHBOARD FUNCTIONS
# =============================================================================

def get_dashboard_metrics() -> dict[str, str]:
    """
    Get all dashboard metrics for the training sidebar.

    Phase 5.1: Real-time metrics display.

    Returns:
        Dictionary with all dashboard metric strings
    """
    metrics = {
        # Live Metrics
        "current_run": "**Current Run:** -",
        "current_step": "**Step:** -",
        "current_loss": "**Loss:** -",
        "eta": "**ETA:** -",
        # GPU Status
        "gpu_temp": "**Temperature:** -",
        "gpu_vram": "**VRAM:** -",
        "gpu_power": "**Power:** -",
        "gpu_condition": "**Status:** -",
        # SLAO Merge Stats
        "scale_factor": "**Scale Factor:** -",
        "a_matrices": "**A Matrices Merged:** -",
        "b_matrices": "**B Matrices Merged:** -",
        # Early Stopping
        "val_loss": "**Validation Loss:** -",
        "best_val": "**Best Val Loss:** -",
        "patience": "**Patience:** -",
        "early_stop_status": "**Status:** Not enabled",
        # Run Timeline
        "total_runs": "**Total Runs:** -",
        "completed_runs": "**Completed:** -",
        "total_steps": "**Total Steps:** -",
        "total_samples": "**Total Samples:** -",
        "total_time": "**Elapsed Time:** -",
        # Phase 5.3: Checkpoints
        "ckpt_count": "**Saved:** -",
        "ckpt_size": "**Total Size:** -",
        "ckpt_best": "**Best:** -",
        "ckpt_prunable": "**Prunable:** -",
        "ckpt_policy": "**Policy:** -",
    }

    # Get GPU status
    status = get_gpu_status()
    if status.available:
        if status.temperature_c is not None:
            temp_emoji = "🟢" if status.temperature_c < 70 else "🟡" if status.temperature_c < 85 else "🔴"
            metrics["gpu_temp"] = f"**Temperature:** {temp_emoji} {status.temperature_c}°C"

        metrics["gpu_vram"] = f"**VRAM:** {status.vram_used_gb:.1f} / {status.vram_total_gb:.1f} GB ({status.vram_percent:.0f}%)"

        if status.power_draw_w is not None:
            metrics["gpu_power"] = f"**Power:** {status.power_draw_w:.0f}W"

        condition_map = {
            GPUCondition.SAFE: "🟢 Safe",
            GPUCondition.WARM: "🟡 Warm",
            GPUCondition.WARNING: "🟠 Warning",
            GPUCondition.CRITICAL: "🔴 Critical",
            GPUCondition.EMERGENCY: "🚨 Emergency",
            GPUCondition.UNKNOWN: "⚪ Unknown",
        }
        metrics["gpu_condition"] = f"**Status:** {condition_map.get(status.condition, 'Unknown')}"

    # Get multi-run state
    if state.multi_run_trainer is not None:
        config = state.multi_run_trainer.config
        metrics["total_runs"] = f"**Total Runs:** {config.num_runs}"

        if state.multi_run_is_running:
            metrics["current_run"] = f"**Current Run:** {state.multi_run_current_run} / {config.num_runs}"

            # Calculate completed runs
            completed = len(state.multi_run_results.runs) if state.multi_run_results else 0
            metrics["completed_runs"] = f"**Completed:** {completed}"

            # Compute ETA based on completed runs and elapsed time
            if completed > 0 and state.multi_run_start_time > 0:
                elapsed = time.time() - state.multi_run_start_time
                remaining_runs = config.num_runs - completed
                eta_seconds = (elapsed / completed) * remaining_runs
                if eta_seconds > 3600:
                    metrics["eta"] = f"**ETA:** {eta_seconds/3600:.1f}h"
                elif eta_seconds > 60:
                    metrics["eta"] = f"**ETA:** {eta_seconds/60:.1f}m"
                else:
                    metrics["eta"] = f"**ETA:** {eta_seconds:.0f}s"

            # Current loss from history
            if state.multi_run_loss_history:
                current_loss = state.multi_run_loss_history[-1]
                metrics["current_loss"] = f"**Loss:** {current_loss:.4f}"
                metrics["current_step"] = f"**Step:** {len(state.multi_run_loss_history)}"

    # Get results if available
    if state.multi_run_results is not None:
        results = state.multi_run_results
        metrics["completed_runs"] = f"**Completed:** {results.total_runs}"
        metrics["total_steps"] = f"**Total Steps:** {results.total_steps}"
        metrics["total_samples"] = f"**Total Samples:** {results.total_samples}"

        # Format elapsed time
        elapsed = results.total_duration_seconds
        if elapsed > 3600:
            metrics["total_time"] = f"**Elapsed Time:** {elapsed/3600:.1f}h"
        elif elapsed > 60:
            metrics["total_time"] = f"**Elapsed Time:** {elapsed/60:.1f}m"
        else:
            metrics["total_time"] = f"**Elapsed Time:** {elapsed:.0f}s"

        # Get last merge result stats
        if results.runs:
            last_run = results.runs[-1]
            if last_run.merge_result:
                mr = last_run.merge_result
                metrics["scale_factor"] = f"**Scale Factor:** {mr.scale_factor:.4f}"
                metrics["a_matrices"] = f"**A Matrices Merged:** {mr.a_matrices_merged}"
                metrics["b_matrices"] = f"**B Matrices Merged:** {mr.b_matrices_merged}"

            if last_run.validation_loss is not None:
                metrics["val_loss"] = f"**Validation Loss:** {last_run.validation_loss:.4f}"

    # Early stopping status from trainer
    if state.multi_run_trainer is not None:
        trainer = state.multi_run_trainer
        if hasattr(trainer, '_best_val_loss') and trainer._best_val_loss < float('inf'):
            metrics["best_val"] = f"**Best Val Loss:** {trainer._best_val_loss:.4f}"
        if hasattr(trainer, '_early_stop_counter'):
            patience = trainer.config.early_stopping_patience
            counter = trainer._early_stop_counter
            metrics["patience"] = f"**Patience:** {counter} / {patience}"

        if trainer.config.early_stopping:
            metrics["early_stop_status"] = "**Status:** ✅ Enabled"
        else:
            metrics["early_stop_status"] = "**Status:** ⚪ Disabled"

        # Phase 5.3: Checkpoint stats
        ckpt_stats = trainer.get_checkpoint_stats()
        if ckpt_stats:
            metrics["ckpt_count"] = f"**Saved:** {ckpt_stats.total_count}"
            metrics["ckpt_size"] = f"**Total Size:** {ckpt_stats.total_size_gb:.2f} GB"
            if ckpt_stats.best_checkpoint and ckpt_stats.best_checkpoint.validation_loss is not None:
                metrics["ckpt_best"] = f"**Best:** Run {ckpt_stats.best_checkpoint.run_index} (val_loss={ckpt_stats.best_checkpoint.validation_loss:.4f})"
            else:
                metrics["ckpt_best"] = "**Best:** -"
            metrics["ckpt_prunable"] = f"**Prunable:** {ckpt_stats.prunable_count}"

            # Show policy summary
            policy_parts = []
            if trainer.config.checkpoint_auto_prune:
                policy_parts.append(f"keep_best={trainer.config.checkpoint_keep_best_n}")
            else:
                policy_parts.append("no auto-prune")
            if trainer.config.checkpoint_max_total > 0:
                policy_parts.append(f"max={trainer.config.checkpoint_max_total}")
            metrics["ckpt_policy"] = f"**Policy:** {', '.join(policy_parts)}"

    return metrics


def refresh_dashboard() -> tuple:
    """
    Refresh all dashboard metrics.

    Returns:
        Tuple of all dashboard component values
    """
    m = get_dashboard_metrics()
    return (
        # Live Metrics
        m["current_run"],
        m["current_step"],
        m["current_loss"],
        m["eta"],
        # GPU Status
        m["gpu_temp"],
        m["gpu_vram"],
        m["gpu_power"],
        m["gpu_condition"],
        # SLAO Merge Stats
        m["scale_factor"],
        m["a_matrices"],
        m["b_matrices"],
        # Early Stopping
        m["val_loss"],
        m["best_val"],
        m["patience"],
        m["early_stop_status"],
        # Run Timeline
        m["total_runs"],
        m["completed_runs"],
        m["total_steps"],
        m["total_samples"],
        m["total_time"],
        # Phase 5.3: Checkpoints
        m["ckpt_count"],
        m["ckpt_size"],
        m["ckpt_best"],
        m["ckpt_prunable"],
        m["ckpt_policy"],
    )


def refresh_train_sidebar() -> tuple:
    """
    Refresh the Train tab sidebar with live metrics and GPU status.

    Returns:
        Tuple of (step, loss, speed, temp, vram, power)
    """
    # Get GPU status
    status = get_gpu_status()

    # GPU metrics
    if status.available:
        if status.temperature_c is not None:
            temp_emoji = "🟢" if status.temperature_c < 70 else "🟡" if status.temperature_c < 85 else "🔴"
            temp = f"**Temperature:** {temp_emoji} {status.temperature_c}°C"
        else:
            temp = "**Temperature:** -"

        vram = f"**VRAM:** {status.vram_used_gb:.1f} / {status.vram_total_gb:.1f} GB"

        if status.power_draw_w is not None:
            power = f"**Power:** {status.power_draw_w:.0f}W"
        else:
            power = "**Power:** -"
    else:
        temp = "**Temperature:** No GPU"
        vram = "**VRAM:** -"
        power = "**Power:** -"

    # Training metrics from state
    step = "**Step:** -"
    loss = "**Loss:** -"
    speed = "**Speed:** -"

    if state.is_training and state.loss_history:
        step = f"**Step:** {len(state.loss_history)}"
        loss = f"**Loss:** {state.loss_history[-1]:.4f}"
        # Calculate speed if we have timing info
        if hasattr(state, 'train_start_time') and state.train_start_time:
            import time
            elapsed = time.time() - state.train_start_time
            steps_done = len(state.loss_history)
            if elapsed > 0 and steps_done > 0:
                speed = f"**Speed:** {elapsed / steps_done:.1f}s/step"

    return (step, loss, speed, temp, vram, power)


# =============================================================================
# UI BUILDER
# =============================================================================

def create_ui() -> gr.Blocks:
    """Create the Gradio UI."""
    # C-UX-002/003: install the log-mirror handler so Stage B backend
    # events (HF retry, OOM batch-shrink, GPU pause/resume) end up in the
    # UI event buffer. Idempotent.
    _install_event_log_handler()

    # Note: In Gradio 6.x, theme and css are passed to launch() not Blocks()
    app: gr.Blocks
    with gr.Blocks(
        title="Backpropagate - LLM Fine-Tuning",
    ) as app:

        with gr.Tabs():
            # =================================================================
            # TRAIN TAB
            # =================================================================
            with gr.Tab("Train", id="train"):
                # Lightweight sidebar for Train tab
                with gr.Sidebar(position="right", open=True, elem_id="train-sidebar"):
                    gr.Markdown("## 📊 Training Monitor")

                    # Live Metrics - at the top for visibility
                    with gr.Accordion("📈 Live Metrics", open=True):
                        train_sidebar_step = gr.Markdown("**Step:** -")
                        train_sidebar_loss = gr.Markdown("**Loss:** -")
                        train_sidebar_speed = gr.Markdown("**Speed:** -")

                    # GPU Status
                    with gr.Accordion("🌡️ GPU Status", open=True):
                        train_sidebar_temp = gr.Markdown("**Temperature:** -")
                        train_sidebar_vram = gr.Markdown("**VRAM:** -")
                        train_sidebar_power = gr.Markdown("**Power:** -")

                    # C-UX-002/003: Status log surfaces backend events
                    # (load_model progress, HF retry, OOM batch-shrink,
                    # GPU pause/resume) so the UI user sees what's
                    # happening even without access to the server log.
                    with gr.Accordion("📝 Status log", open=True):
                        train_status_log = gr.Textbox(
                            label="Recent events",
                            value=_format_event_log(),
                            lines=8,
                            interactive=False,
                            max_lines=8,
                        )

                    train_sidebar_refresh = gr.Button("🔄 Refresh Metrics", size="sm")

                    # Quick Start - below metrics for reference
                    with gr.Accordion("🚀 Quick Start", open=False):
                        gr.Markdown(
                            """
**3 steps to fine-tune:**

1. **Pick a model** - Qwen 7B is great for most tasks
2. **Choose dataset** - Start with UltraChat or upload JSONL
3. **Click Start** - Watch the loss drop!

---

**First time?** Use defaults:
- 100 steps, 1000 samples
- Takes ~5 min on RTX 3080+

**Tips:**
- Loss should drop steadily
- If loss spikes, lower learning rate
- For production, use Multi-Run tab
                            """
                        )

                with gr.Row():
                    # Left column - Configuration
                    with gr.Column(scale=1):
                        gr.Markdown("### Model")
                        model_preset = gr.Dropdown(
                            choices=list(MODEL_PRESETS.keys()),
                            value="Qwen 2.5 7B (Recommended)",
                            label="Model Preset",
                        )
                        custom_model = gr.Textbox(
                            label="Custom Model (HuggingFace path)",
                            placeholder="unsloth/Qwen2.5-7B-Instruct-bnb-4bit",
                            info="Format: org/model-name (e.g., unsloth/Qwen2.5-7B)",
                            visible=False,
                        )

                        gr.Markdown("### Dataset")
                        dataset_preset = gr.Dropdown(
                            choices=list(DATASET_PRESETS.keys()),
                            value="UltraChat 200K (Conversations)",
                            label="Dataset Preset",
                        )
                        custom_dataset = gr.Textbox(
                            label="Custom Dataset Path",
                            placeholder="path/to/data.jsonl",
                            visible=False,
                        )
                        max_samples = gr.Slider(
                            minimum=100,
                            maximum=10000,
                            value=1000,
                            step=100,
                            label="Max Samples",
                        )

                        gr.Markdown("### Training")
                        max_steps = gr.Slider(
                            minimum=10,
                            maximum=1000,
                            value=100,
                            step=10,
                            label="Training Steps",
                        )
                        learning_rate = gr.Number(
                            value=2e-4,
                            label="Learning Rate",
                            info="Typical range: 1e-5 to 5e-4. Default 2e-4 works for most tasks.",
                        )
                        batch_size = gr.Slider(
                            minimum=1,
                            maximum=8,
                            value=2,
                            step=1,
                            label="Batch Size",
                        )

                        with gr.Accordion("LoRA Settings", open=False):
                            lora_r = gr.Slider(
                                minimum=4,
                                maximum=64,
                                value=16,
                                step=4,
                                label="LoRA Rank (r)",
                                info="Higher = more capacity but more VRAM. 16 is balanced.",
                            )
                            lora_alpha = gr.Slider(
                                minimum=8,
                                maximum=128,
                                value=32,
                                step=8,
                                label="LoRA Alpha",
                                info="Usually 2x rank. Higher = stronger adaptation.",
                            )

                        with gr.Row():
                            train_btn = gr.Button(
                                "Start Training",
                                variant="primary",
                                elem_classes=["train-btn"],
                            )
                            stop_btn = gr.Button(
                                "Stop",
                                variant="secondary",
                            )

                    # Right column - Progress
                    with gr.Column(scale=1):
                        gr.Markdown("### Progress")
                        status_text = gr.Markdown("Ready to train")

                        loss_plot = gr.Plot(
                            label="Training Loss",
                            elem_classes=["loss-chart"],
                        )

                        gr.Markdown("### System")
                        with gr.Row():
                            gpu_status = gr.Markdown(
                                get_gpu_status_display(),
                                elem_classes=["gpu-stats"],
                            )

                # Event handlers
                dataset_preset.change(
                    fn=lambda x: gr.update(visible=x == "Custom JSONL"),
                    inputs=[dataset_preset],
                    outputs=[custom_dataset],
                )

                # C-UX-001: toggle the custom-model textbox visible when
                # the "Custom / Other" preset is selected. Without this the
                # documented HF-path entry is unreachable from the UI.
                model_preset.change(
                    fn=lambda x: gr.update(visible=x == CUSTOM_MODEL_CHOICE),
                    inputs=[model_preset],
                    outputs=[custom_model],
                )

                train_btn.click(
                    fn=start_training,
                    inputs=[
                        model_preset, custom_model,
                        dataset_preset, custom_dataset, max_samples,
                        max_steps, learning_rate, batch_size,
                        lora_r, lora_alpha,
                    ],
                    outputs=[status_text, loss_plot, gpu_status],
                )

                stop_btn.click(
                    fn=stop_training,
                    outputs=[status_text],
                )

                # Train sidebar refresh handler
                train_sidebar_refresh.click(
                    fn=refresh_train_sidebar,
                    outputs=[
                        train_sidebar_step,
                        train_sidebar_loss,
                        train_sidebar_speed,
                        train_sidebar_temp,
                        train_sidebar_vram,
                        train_sidebar_power,
                    ],
                )

                # C-UX-006: auto-refresh the sidebar so 'Live Metrics' is
                # actually live. 2s cadence is the typical training-dash
                # value. gr.Timer is Gradio 5+; we try/except so an
                # unusually old Gradio install degrades gracefully back to
                # the manual Refresh button.
                try:
                    train_metrics_timer = gr.Timer(value=2.0, active=True)
                    train_metrics_timer.tick(
                        fn=refresh_train_sidebar,
                        outputs=[
                            train_sidebar_step,
                            train_sidebar_loss,
                            train_sidebar_speed,
                            train_sidebar_temp,
                            train_sidebar_vram,
                            train_sidebar_power,
                        ],
                    )
                    # C-UX-002/003: poll the event buffer on a snappier
                    # 0.5s cadence so retry / OOM / pause events appear
                    # near-immediately in the status log.
                    train_status_timer = gr.Timer(value=0.5, active=True)
                    train_status_timer.tick(
                        fn=refresh_event_log,
                        outputs=[train_status_log],
                    )
                except (AttributeError, TypeError) as _timer_err:
                    # gr.Timer not available in this Gradio version — log
                    # and rely on the manual Refresh button. Don't crash.
                    logger.warning(
                        "gr.Timer not available (%s); live metrics will "
                        "require manual refresh.",
                        _timer_err,
                    )

            # =================================================================
            # MULTI-RUN TAB (SLAO Multi-Run Training)
            # =================================================================
            with gr.Tab("Multi-Run", id="multirun"):
                gr.Markdown(
                    """
                    ### SLAO Multi-Run Training
                    **Multiple short runs with intelligent LoRA merging** - Prevents catastrophic forgetting
                    while maximizing learning from diverse data chunks.

                    Based on [SLAO research](https://arxiv.org/abs/2512.23017): orthogonal initialization +
                    time-aware scaling = better retention of previous knowledge.
                    """
                )

                # Phase 5.1: Training Dashboard Sidebar
                with gr.Sidebar(position="right", open=True, elem_id="training-dashboard") as training_sidebar:
                    gr.Markdown("## 📊 Training Dashboard")

                    # Live Metrics Section
                    with gr.Accordion("📈 Live Metrics", open=True):
                        dashboard_current_run = gr.Markdown("**Current Run:** -")
                        dashboard_current_step = gr.Markdown("**Step:** -")
                        dashboard_current_loss = gr.Markdown("**Loss:** -")
                        dashboard_eta = gr.Markdown("**ETA:** -")

                    # GPU Status Section
                    with gr.Accordion("🌡️ GPU Status", open=True):
                        dashboard_gpu_temp = gr.Markdown("**Temperature:** -")
                        dashboard_gpu_vram = gr.Markdown("**VRAM:** -")
                        dashboard_gpu_power = gr.Markdown("**Power:** -")
                        dashboard_gpu_condition = gr.Markdown("**Status:** -")

                    # SLAO Merge Stats Section (Phase 5.2)
                    with gr.Accordion("🔄 SLAO Merge Stats", open=False):
                        dashboard_scale_factor = gr.Markdown("**Scale Factor:** -")
                        dashboard_a_matrices = gr.Markdown("**A Matrices Merged:** -")
                        dashboard_b_matrices = gr.Markdown("**B Matrices Merged:** -")

                    # Early Stopping Section (Phase 4.3)
                    with gr.Accordion("⏹️ Early Stopping", open=False):
                        dashboard_val_loss = gr.Markdown("**Validation Loss:** -")
                        dashboard_best_val = gr.Markdown("**Best Val Loss:** -")
                        dashboard_patience = gr.Markdown("**Patience:** -")
                        dashboard_early_stop_status = gr.Markdown("**Status:** Not enabled")

                    # Run Timeline Section
                    with gr.Accordion("📅 Run Timeline", open=False):
                        dashboard_total_runs = gr.Markdown("**Total Runs:** -")
                        dashboard_completed_runs = gr.Markdown("**Completed:** -")
                        dashboard_total_steps = gr.Markdown("**Total Steps:** -")
                        dashboard_total_samples = gr.Markdown("**Total Samples:** -")
                        dashboard_total_time = gr.Markdown("**Elapsed Time:** -")

                    # Phase 5.3: Checkpoint Management Section
                    with gr.Accordion("💾 Checkpoints", open=False):
                        dashboard_ckpt_count = gr.Markdown("**Saved:** -")
                        dashboard_ckpt_size = gr.Markdown("**Total Size:** -")
                        dashboard_ckpt_best = gr.Markdown("**Best:** -")
                        dashboard_ckpt_prunable = gr.Markdown("**Prunable:** -")
                        dashboard_ckpt_policy = gr.Markdown("**Policy:** -")

                    # C-UX-002/003: Status log mirrored from the same global
                    # event buffer that the Train tab sidebar uses.
                    with gr.Accordion("📝 Status log", open=True):
                        mr_status_log = gr.Textbox(
                            label="Recent events",
                            value=_format_event_log(),
                            lines=8,
                            interactive=False,
                            max_lines=8,
                        )

                    # Refresh button for manual updates
                    dashboard_refresh_btn = gr.Button("🔄 Refresh Dashboard", size="sm")

                with gr.Row():
                    # Left column - Configuration
                    with gr.Column(scale=1):
                        gr.Markdown("### Model & Data")
                        mr_model_preset = gr.Dropdown(
                            choices=list(MODEL_PRESETS.keys()),
                            value="Qwen 2.5 7B (Recommended)",
                            label="Model Preset",
                        )
                        mr_custom_model = gr.Textbox(
                            label="Custom Model",
                            placeholder="unsloth/Qwen2.5-7B-Instruct-bnb-4bit",
                            visible=False,
                        )
                        mr_dataset_preset = gr.Dropdown(
                            choices=list(DATASET_PRESETS.keys()),
                            value="UltraChat 200K (Conversations)",
                            label="Dataset Preset",
                        )
                        mr_custom_dataset = gr.Textbox(
                            label="Custom Dataset Path",
                            placeholder="path/to/data.jsonl",
                            visible=False,
                        )

                        gr.Markdown("### Run Configuration")
                        mr_num_runs = gr.Slider(
                            minimum=2,
                            maximum=20,
                            value=5,
                            step=1,
                            label="Number of Runs",
                        )
                        mr_steps_per_run = gr.Slider(
                            minimum=50,
                            maximum=500,
                            value=100,
                            step=10,
                            label="Steps per Run",
                        )
                        mr_samples_per_run = gr.Slider(
                            minimum=500,
                            maximum=5000,
                            value=1000,
                            step=100,
                            label="Samples per Run (fresh each run)",
                        )

                        gr.Markdown("### Merge Strategy")
                        mr_merge_mode = gr.Radio(
                            choices=["SLAO", "Simple"],
                            value="SLAO",
                            label="Merge Mode",
                            info="SLAO: Orthogonal init + time-aware scaling (recommended). Simple: Continue from previous.",
                        )

                        with gr.Accordion("Learning Rate Schedule", open=False):
                            mr_initial_lr = gr.Number(
                                value=2e-4,
                                label="Initial LR (Run 1)",
                            )
                            mr_final_lr = gr.Number(
                                value=5e-5,
                                label="Final LR (Last Run)",
                            )

                        with gr.Accordion("GPU Safety", open=False):
                            mr_max_temp = gr.Slider(
                                minimum=70,
                                maximum=95,
                                value=85,
                                step=1,
                                label="Max Temperature (C) - Pause if exceeded",
                            )

                        # Phase 4 Advanced Options
                        with gr.Accordion("Advanced SLAO (Phase 4)", open=False):
                            gr.Markdown("**Adaptive Scaling** - Adjust merge strength based on task similarity")
                            mr_adaptive_scaling = gr.Checkbox(
                                label="Enable Adaptive Scaling",
                                value=False,
                                info="Compute task similarity between runs",
                            )
                            mr_adaptive_range = gr.Slider(
                                minimum=0.2,
                                maximum=2.0,
                                value=1.0,
                                label="Scale Range (min, max)",
                                visible=False,
                            )

                            gr.Markdown("**Layer Scaling** - Different merge strength per layer")
                            mr_layer_scaling = gr.Checkbox(
                                label="Enable Layer Scaling",
                                value=False,
                                info="Early layers merge more, late layers preserve more",
                            )

                            gr.Markdown("**Early Stopping** - Stop if validation loss increases")
                            mr_early_stopping = gr.Checkbox(
                                label="Enable Early Stopping",
                                value=False,
                            )
                            with gr.Row():
                                mr_early_patience = gr.Slider(
                                    minimum=1,
                                    maximum=5,
                                    value=2,
                                    step=1,
                                    label="Patience (runs)",
                                )
                                mr_val_samples = gr.Slider(
                                    minimum=50,
                                    maximum=500,
                                    value=100,
                                    step=50,
                                    label="Validation Samples",
                                )

                        # Phase 5.3: Checkpoint Management
                        with gr.Accordion("Checkpoint Management (Phase 5.3)", open=False):
                            gr.Markdown("**Smart Pruning** - Keep best checkpoints, delete the rest")
                            mr_ckpt_auto_prune = gr.Checkbox(
                                label="Enable Auto-Pruning",
                                value=True,
                                info="Automatically prune low-value checkpoints after each run",
                            )
                            with gr.Row():
                                mr_ckpt_keep_best = gr.Slider(
                                    minimum=1,
                                    maximum=10,
                                    value=3,
                                    step=1,
                                    label="Keep Best N",
                                    info="Keep N checkpoints with lowest validation loss",
                                )
                                mr_ckpt_max_total = gr.Slider(
                                    minimum=0,
                                    maximum=20,
                                    value=10,
                                    step=1,
                                    label="Max Total (0=unlimited)",
                                    info="Hard limit on total checkpoints",
                                )
                            mr_ckpt_keep_final = gr.Checkbox(
                                label="Always Keep Final Checkpoint",
                                value=True,
                            )
                            mr_ckpt_keep_boundaries = gr.Checkbox(
                                label="Keep Run Boundary Checkpoints",
                                value=False,
                                info="Keep first checkpoint of each run",
                            )

                        with gr.Row():
                            mr_start_btn = gr.Button(
                                "Start Multi-Run",
                                variant="primary",
                            )
                            mr_stop_btn = gr.Button(
                                "Stop",
                                variant="secondary",
                            )

                    # Right column - Progress
                    with gr.Column(scale=1):
                        gr.Markdown("### Progress")
                        mr_status_text = gr.Markdown("Ready for multi-run training")

                        mr_loss_plot = gr.Plot(
                            label="Aggregate Loss (run boundaries shown)",
                        )

                        gr.Markdown("### GPU Safety Monitor")
                        mr_gpu_status = gr.Markdown(get_gpu_safety_status())

                        gr.Markdown("### Run History")
                        mr_runs_table = gr.Dataframe(
                            headers=["Run", "Steps", "Samples", "Loss", "LR", "Time", "Merge"],
                            datatype=["number", "number", "number", "str", "str", "str", "str"],
                            interactive=False,
                        )

                # Multi-run event handlers
                mr_dataset_preset.change(
                    fn=lambda x: gr.update(visible=x == "Custom JSONL"),
                    inputs=[mr_dataset_preset],
                    outputs=[mr_custom_dataset],
                )

                # C-UX-001: same custom-model toggle for the Multi-Run tab.
                mr_model_preset.change(
                    fn=lambda x: gr.update(visible=x == CUSTOM_MODEL_CHOICE),
                    inputs=[mr_model_preset],
                    outputs=[mr_custom_model],
                )

                mr_start_btn.click(
                    fn=start_multi_run,
                    inputs=[
                        mr_model_preset, mr_custom_model,
                        mr_dataset_preset, mr_custom_dataset,
                        mr_num_runs, mr_steps_per_run, mr_samples_per_run,
                        mr_merge_mode, mr_initial_lr, mr_final_lr, mr_max_temp,
                        # Phase 4 advanced options
                        mr_adaptive_scaling, mr_layer_scaling,
                        mr_early_stopping, mr_early_patience, mr_val_samples,
                        # Phase 5.3 checkpoint options
                        mr_ckpt_auto_prune, mr_ckpt_keep_best, mr_ckpt_max_total,
                        mr_ckpt_keep_final, mr_ckpt_keep_boundaries,
                    ],
                    outputs=[mr_status_text, mr_loss_plot, mr_gpu_status, mr_runs_table],
                )

                mr_stop_btn.click(
                    fn=stop_multi_run,
                    outputs=[mr_status_text],
                )

                # Dashboard refresh event handler
                _dashboard_outputs = [
                    # Live Metrics
                    dashboard_current_run,
                    dashboard_current_step,
                    dashboard_current_loss,
                    dashboard_eta,
                    # GPU Status
                    dashboard_gpu_temp,
                    dashboard_gpu_vram,
                    dashboard_gpu_power,
                    dashboard_gpu_condition,
                    # SLAO Merge Stats
                    dashboard_scale_factor,
                    dashboard_a_matrices,
                    dashboard_b_matrices,
                    # Early Stopping
                    dashboard_val_loss,
                    dashboard_best_val,
                    dashboard_patience,
                    dashboard_early_stop_status,
                    # Run Timeline
                    dashboard_total_runs,
                    dashboard_completed_runs,
                    dashboard_total_steps,
                    dashboard_total_samples,
                    dashboard_total_time,
                    # Phase 5.3: Checkpoints
                    dashboard_ckpt_count,
                    dashboard_ckpt_size,
                    dashboard_ckpt_best,
                    dashboard_ckpt_prunable,
                    dashboard_ckpt_policy,
                ]
                dashboard_refresh_btn.click(
                    fn=refresh_dashboard,
                    outputs=_dashboard_outputs,
                )

                # C-UX-006: auto-refresh dashboard so the 'Live Metrics'
                # panel is actually live mid-training. Same try/except
                # fallback as the Train tab.
                try:
                    mr_dashboard_timer = gr.Timer(value=2.0, active=True)
                    mr_dashboard_timer.tick(
                        fn=refresh_dashboard,
                        outputs=_dashboard_outputs,
                    )
                    mr_status_timer = gr.Timer(value=0.5, active=True)
                    mr_status_timer.tick(
                        fn=refresh_event_log,
                        outputs=[mr_status_log],
                    )
                except (AttributeError, TypeError) as _timer_err:
                    logger.warning(
                        "gr.Timer not available (%s); dashboard will "
                        "require manual refresh.",
                        _timer_err,
                    )

            # =================================================================
            # RUNS TAB
            # =================================================================
            with gr.Tab("Runs", id="runs"):
                gr.Markdown("### Training History")
                gr.Markdown("Training runs will appear here after you start training.")

                runs_table = gr.Dataframe(
                    headers=["Run ID", "Steps", "Final Loss", "Duration", "Samples"],
                    datatype=["str", "number", "str", "str", "number"],
                    interactive=False,
                )

                refresh_runs_btn = gr.Button("Refresh")
                refresh_runs_btn.click(
                    fn=get_runs_table,
                    outputs=[runs_table],
                )

            # =================================================================
            # EXPORT TAB
            # =================================================================
            with gr.Tab("Export", id="export"):
                gr.Markdown(
                    """
                    ### Save & Export Model
                    Export your trained model to various formats for deployment.

                    *Train a model first, then return here to save or export it.*
                    """
                )

                # C-UX-014: defaults must live under get_ui_output_dir()
                # so they pass the safe_path validation that all UI sinks
                # enforce. The old relative paths ('./output/lora' etc.)
                # were theatrical — they showed a plausible filename but
                # were guaranteed to fail validation, leaving the user with
                # "Invalid output path" on a first-time export.
                _ui_base = get_ui_output_dir()
                _default_lora_path = str(_ui_base / "lora")
                _default_gguf_dir = str(_ui_base / "gguf")
                _default_gguf_file = str(_ui_base / "gguf" / "model-q4_k_m.gguf")
                _default_modelfile_path = str(_ui_base / "Modelfile")

                with gr.Row():
                    # Left column - Save and Export
                    with gr.Column(scale=1):
                        gr.Markdown("#### Save LoRA Adapter")
                        save_path = gr.Textbox(
                            label="Output Path",
                            value=_default_lora_path,
                            info="Default is your UI output directory; validated for safety.",
                        )
                        save_merged = gr.Checkbox(
                            label="Save merged weights (larger but standalone)",
                            value=False,
                        )
                        save_btn = gr.Button("Save Model", variant="primary")
                        save_status = gr.Markdown("")

                        gr.Markdown("#### Export to Format")
                        export_format = gr.Dropdown(
                            choices=["GGUF", "Merged", "LoRA"],
                            value="GGUF",
                            label="Format",
                        )
                        quantization = gr.Dropdown(
                            choices=["q4_k_m", "q5_k_m", "q8_0", "f16", "q4_0", "q2_k"],
                            value="q4_k_m",
                            label="Quantization (GGUF only)",
                            info="q4_k_m recommended. f16 for best quality, q2_k for smallest size.",
                        )
                        export_path = gr.Textbox(
                            label="Output Path",
                            value=_default_gguf_dir,
                            info="Default is your UI output directory; validated for safety.",
                        )
                        export_btn = gr.Button("Export Model", variant="primary")
                        export_status = gr.Markdown("")

                    # Right column - Ollama Integration
                    with gr.Column(scale=1):
                        gr.Markdown("#### Ollama Integration")
                        gr.Markdown(
                            """
                            Register your GGUF model with [Ollama](https://ollama.ai) for easy local deployment.
                            """
                        )

                        ollama_gguf_path = gr.Textbox(
                            label="GGUF File Path",
                            value=_default_gguf_file,
                            placeholder="Path to your exported GGUF file",
                        )
                        ollama_model_name = gr.Textbox(
                            label="Ollama Model Name",
                            value="my-finetuned-model",
                            placeholder="Name for the model in Ollama",
                        )
                        ollama_system_prompt = gr.Textbox(
                            label="System Prompt (optional)",
                            placeholder="You are a helpful assistant.",
                            lines=2,
                        )
                        ollama_temperature = gr.Slider(
                            minimum=0.0,
                            maximum=2.0,
                            value=0.7,
                            step=0.1,
                            label="Temperature",
                        )

                        with gr.Row():
                            ollama_register_btn = gr.Button("Register with Ollama", variant="primary")
                            ollama_list_btn = gr.Button("List Models", variant="secondary")

                        ollama_status = gr.Markdown("")

                        with gr.Accordion("Create Modelfile Only", open=False):
                            modelfile_output = gr.Textbox(
                                label="Modelfile Output Path",
                                value=_default_modelfile_path,
                                info="Default is your UI output directory; validated for safety.",
                            )
                            modelfile_btn = gr.Button("Create Modelfile")
                            modelfile_status = gr.Markdown("")

                # Event handlers
                save_btn.click(
                    fn=save_model,
                    inputs=[save_path, save_merged],
                    outputs=[save_status],
                )

                export_btn.click(
                    fn=export_model,
                    inputs=[export_format, quantization, export_path],
                    outputs=[export_status],
                )

                ollama_register_btn.click(
                    fn=register_ollama,
                    inputs=[ollama_gguf_path, ollama_model_name, ollama_system_prompt],
                    outputs=[ollama_status],
                )

                ollama_list_btn.click(
                    fn=list_ollama,
                    outputs=[ollama_status],
                )

                modelfile_btn.click(
                    fn=create_ollama_modelfile,
                    inputs=[ollama_gguf_path, modelfile_output, ollama_system_prompt, ollama_temperature],
                    outputs=[modelfile_status],
                )

            # =================================================================
            # DATASET TAB
            # =================================================================
            with gr.Tab("Dataset", id="dataset"):
                gr.Markdown(
                    """
                    ### Dataset Preparation
                    **Upload, validate, and convert datasets** - Supports ShareGPT, Alpaca, OpenAI, and ChatML formats.
                    """
                )

                with gr.Row():
                    # Left column - Upload and Info
                    with gr.Column(scale=1):
                        gr.Markdown("### Load Dataset")
                        ds_file = gr.File(
                            label="Upload Dataset",
                            file_types=[".jsonl", ".json", ".parquet", ".csv", ".txt"],
                        )
                        ds_load_status = gr.Markdown("")

                        gr.Markdown("### Dataset Info")
                        ds_status = gr.Markdown("Upload a JSONL, JSON, CSV, or Parquet file above to validate and preview your training data.")

                        ds_stats_table = gr.Dataframe(
                            headers=["Property", "Value"],
                            datatype=["str", "str"],
                            interactive=False,
                            label="Statistics",
                        )

                        gr.Markdown("### Validation")
                        ds_validation = gr.Textbox(
                            label="Validation Report",
                            lines=10,
                            interactive=False,
                        )

                    # Right column - Preview and Convert
                    with gr.Column(scale=1):
                        gr.Markdown("### Sample Preview")

                        with gr.Row():
                            ds_show_raw = gr.Checkbox(
                                label="Show raw format",
                                value=False,
                            )
                            ds_refresh_btn = gr.Button("Refresh Preview", size="sm")

                        ds_preview = gr.Markdown("No samples to preview")

                        gr.Markdown("### Convert & Export")
                        with gr.Row():
                            ds_target_format = gr.Dropdown(
                                choices=["ChatML"],
                                value="ChatML",
                                label="Target Format",
                            )
                            ds_convert_btn = gr.Button("Convert", variant="secondary")

                        ds_convert_status = gr.Markdown("")

                        # C-UX-014: default into get_ui_output_dir() so the
                        # path passes validate_path_input(allowed_base=...).
                        ds_export_path = gr.Textbox(
                            label="Export Path",
                            value=str(get_ui_output_dir() / "converted.jsonl"),
                            info="Default is your UI output directory; validated for safety.",
                        )
                        ds_export_btn = gr.Button("Export Converted Dataset", variant="primary")
                        ds_export_status = gr.Markdown("")

                # Event handlers
                ds_file.change(
                    fn=load_dataset_file,
                    inputs=[ds_file],
                    outputs=[ds_status, ds_validation, ds_stats_table, ds_preview, ds_load_status],
                )

                ds_show_raw.change(
                    fn=refresh_dataset_preview,
                    inputs=[ds_show_raw],
                    outputs=[ds_preview],
                )

                ds_refresh_btn.click(
                    fn=refresh_dataset_preview,
                    inputs=[ds_show_raw],
                    outputs=[ds_preview],
                )

                ds_convert_btn.click(
                    fn=convert_dataset_format,
                    inputs=[ds_target_format],
                    outputs=[ds_convert_status, ds_preview],
                )

                ds_export_btn.click(
                    fn=export_converted_dataset,
                    inputs=[ds_export_path],
                    outputs=[ds_export_status],
                )

            # =================================================================
            # SETTINGS TAB
            # =================================================================
            with gr.Tab("Settings", id="settings"):
                with gr.Row():
                    # Left column - System Info
                    with gr.Column(scale=1), gr.Group():
                        gr.Markdown("#### System")
                        gpu_info = get_gpu_info()
                        sys_info = get_system_info()

                        if gpu_info.get("available"):
                            gpu_name = gpu_info.get("device_name", "Unknown GPU")
                            vram_total = gpu_info.get("memory_total", 0) / (1024**3)
                            vram_used = gpu_info.get("memory_allocated", 0) / (1024**3)

                            gr.Markdown(f"**{gpu_name}**")
                            gr.Slider(
                                minimum=0, maximum=vram_total, value=vram_used,
                                label=f"VRAM: {vram_used:.1f} / {vram_total:.1f} GB",
                                interactive=False
                            )
                        else:
                            gr.Markdown("**No GPU detected**")

                        gr.Markdown(f"""
**Python:** {sys_info.get('python_version', 'Unknown').split()[0]}

**Platform:** {sys_info.get('platform', 'Unknown')[:40]}

**PyTorch:** {sys_info.get('torch_version', 'N/A')}
                            """)

                    # Right column - Features
                    with gr.Column(scale=1), gr.Group():
                        gr.Markdown("#### Features")
                        features = list_available_features()
                        feature_md = "\n".join([f"- {name}" for name in features.keys()])
                        gr.Markdown(feature_md if feature_md else "No optional features detected")

                # Model Defaults
                with gr.Accordion("Model Defaults", open=False), gr.Row():
                    settings_model = gr.Textbox(
                        value=settings.model.name,
                        label="Default Model",
                        info="HuggingFace model path",
                        interactive=False,
                    )
                    settings_max_seq = gr.Number(
                        value=settings.model.max_seq_length,
                        label="Max Sequence Length",
                        precision=0,
                        interactive=False,
                    )

                # LoRA Defaults
                with gr.Accordion("LoRA Defaults", open=False), gr.Row():
                    settings_lora_r = gr.Slider(
                        minimum=4, maximum=128, value=settings.lora.r,
                        step=4, label="LoRA Rank (r)",
                        interactive=False,
                    )
                    settings_lora_alpha = gr.Slider(
                        minimum=8, maximum=256, value=settings.lora.lora_alpha,
                        step=8, label="LoRA Alpha",
                        interactive=False,
                    )
                    settings_lora_dropout = gr.Slider(
                        minimum=0, maximum=0.5, value=settings.lora.lora_dropout,
                        step=0.01, label="Dropout",
                        interactive=False,
                    )

                # Training Defaults
                with gr.Accordion("Training Defaults", open=False):
                    with gr.Row():
                        settings_lr = gr.Number(
                            value=settings.training.learning_rate,
                            label="Learning Rate",
                            interactive=False,
                        )
                        settings_batch = gr.Number(
                            value=settings.training.per_device_train_batch_size,
                            label="Batch Size",
                            precision=0,
                            interactive=False,
                        )
                        settings_grad_accum = gr.Number(
                            value=settings.training.gradient_accumulation_steps,
                            label="Gradient Accumulation",
                            precision=0,
                            interactive=False,
                        )
                    with gr.Row():
                        settings_warmup = gr.Number(
                            value=settings.training.warmup_steps,
                            label="Warmup Steps",
                            precision=0,
                            interactive=False,
                        )
                        settings_output = gr.Textbox(
                            value=settings.training.output_dir,
                            label="Output Directory",
                            interactive=False,
                        )

                # Settings guidance
                gr.Markdown("Settings are configured via environment variables or `backpropagate.toml` config file. See the [documentation](https://github.com/mcp-tool-shop-org/backpropagate) for details.")

                with gr.Accordion("Raw Configuration", open=False):
                    gr.Code(
                        value=str(settings.to_dict()),
                        language="json",
                        label="Current Settings"
                    )

            # =================================================================
            # HELP TAB
            # =================================================================
            with gr.Tab("Help", id="help"):
                # Quick Start - Visual Steps
                with gr.Group():
                    gr.Markdown("#### Quick Start")
                    with gr.Row():
                        with gr.Column(scale=1, min_width=150):
                            gr.Markdown("""
**1. Select Model**

Pick a preset or enter a HuggingFace path
                            """)
                        with gr.Column(scale=1, min_width=150):
                            gr.Markdown("""
**2. Load Dataset**

Choose a preset or upload JSONL
                            """)
                        with gr.Column(scale=1, min_width=150):
                            gr.Markdown("""
**3. Train**

Click Start and watch loss drop
                            """)
                        with gr.Column(scale=1, min_width=150):
                            gr.Markdown("""
**4. Export**

Convert to GGUF for Ollama
                            """)

                # Model Selection Guide
                with gr.Accordion("Model Selection Guide", open=False):
                    gr.Markdown("""
| VRAM | Recommended Model | Notes |
|------|------------------|-------|
| 8 GB | Qwen2.5-3B-Instruct | Good for testing |
| 12 GB | Qwen2.5-7B-Instruct | Best balance |
| 16 GB | Qwen2.5-7B-Instruct | Room for larger batches |
| 24 GB+ | Qwen2.5-14B-Instruct | Maximum quality |

**Tips:**
- Use 4-bit quantized models (bnb-4bit) to reduce VRAM by ~75%
- Instruct models are easier to fine-tune than base models
- Start with 7B - it's the sweet spot for most tasks
                    """)

                # Dataset Formats
                with gr.Accordion("Dataset Formats", open=False):
                    with gr.Tabs():
                        with gr.Tab("ChatML"):
                            gr.Code(
                                value='{"text": "<|im_start|>user\\nHello!<|im_end|>\\n<|im_start|>assistant\\nHi there!<|im_end|>"}',
                                language="json",
                                label="ChatML Format (Recommended)"
                            )
                            gr.Markdown("Best for Qwen, Yi, and most modern models.")

                        with gr.Tab("ShareGPT"):
                            gr.Code(
                                value='{"conversations": [{"from": "human", "value": "Hello!"}, {"from": "gpt", "value": "Hi there!"}]}',
                                language="json",
                                label="ShareGPT Format"
                            )
                            gr.Markdown("Common format, auto-converted to ChatML.")

                        with gr.Tab("Alpaca"):
                            gr.Code(
                                value='{"instruction": "Say hello", "input": "", "output": "Hello! How can I help?"}',
                                language="json",
                                label="Alpaca Format"
                            )
                            gr.Markdown("Simple instruction-following format.")

                # Training Tips
                with gr.Accordion("Training Tips", open=False):
                    gr.Markdown("""
**Getting Good Results:**
- **Start small**: 100 steps, 1000 samples to verify setup works
- **Learning rate**: 2e-4 is a safe default, lower (1e-4) for larger models
- **Batch size**: Auto-detected, but 2-4 works for most setups
- **LoRA rank**: 16 is balanced, 32+ for complex tasks, 8 for simple ones

**Watch for Overfitting:**
- Loss dropping too fast? Reduce learning rate
- Loss stuck high? Increase learning rate or check data quality
- Training loss good but output bad? Need more diverse data

**Multi-Run Strategy:**
- Multiple short runs (100 steps each) often beat one long run
- Each run sees fresh data, preventing overfitting
- Use the Multi-Run tab for automated training
                    """)

                # Troubleshooting
                with gr.Accordion("Troubleshooting", open=False):
                    gr.Markdown("""
**Out of Memory (OOM):**
- Reduce batch size to 1
- Use a smaller model (3B instead of 7B)
- Enable gradient checkpointing (default)
- Reduce max sequence length

**Training is Slow:**
- Increase batch size if VRAM allows
- Use gradient accumulation instead of large batches
- Check GPU utilization with `nvidia-smi`

**Loss Not Decreasing:**
- Check dataset format is correct
- Try a higher learning rate (5e-4)
- Verify data quality - garbage in, garbage out

**Export Failed:**
- Ensure model trained successfully first
- Check disk space for GGUF output
- For Ollama: verify Ollama is running (`ollama list`)
                    """)

                # CLI Reference
                with gr.Accordion("CLI Reference", open=False):
                    gr.Code(
                        value="""# Launch UI
backprop ui --port 7862

# Single training run
backprop train --data my_data.jsonl --steps 100 --samples 1000

# Multi-run training
backprop multi-run --data ultrachat --runs 5 --steps 100

# Export to GGUF
backprop export ./output/lora --format gguf -q q4_k_m

# Export and register with Ollama
backprop export ./output/lora --format gguf --ollama --ollama-name mymodel

# Show system info
backprop info

# Show configuration
backprop config""",
                        language="shell",
                        label="CLI Commands"
                    )

                # Links
                gr.Markdown("---")
                with gr.Row():
                    gr.Button(
                        "GitHub",
                        link="https://github.com/mcp-tool-shop-org/backpropagate",
                        variant="secondary",
                        size="sm"
                    )
                    gr.Button(
                        "Documentation",
                        link="https://github.com/mcp-tool-shop-org/backpropagate#readme",
                        variant="secondary",
                        size="sm"
                    )
                    gr.Button(
                        "Report Issue",
                        link="https://github.com/mcp-tool-shop-org/backpropagate/issues",
                        variant="secondary",
                        size="sm"
                    )

    return app


def _validate_auth_shape(auth: Any) -> None:
    """
    FB-012: Validate the shape of the ``auth`` kwarg before passing it to
    Gradio.

    Gradio's own validation is permissive in ways that can grant unintended
    access — e.g. an empty list silently disables auth, a one-element tuple
    raises a confusing internal TypeError, and a list containing a non-tuple
    element gets coerced. Validate at the launch boundary so misconfigured
    auth fails loudly rather than degrading to "no auth" or "auth-but-not-
    in-the-shape-you-think".

    Accepts:
        - ``None`` (caller's responsibility to enforce share+auth)
        - A 2-element tuple ``(username, password)`` — both non-empty strings.
        - A non-empty list of such 2-element tuples (multi-user).
        - A ``callable`` (Gradio supports custom auth functions).

    Rejects everything else with ``BackpropagateError(
    code="INPUT_AUTH_INVALID_SHAPE")`` and a hint enumerating the accepted
    shapes.
    """
    if auth is None:
        return

    if callable(auth):
        # Gradio supports custom auth callables — defer their validation to
        # Gradio itself. Don't introspect the callable's signature; that
        # creates a cross-version-fragile contract.
        return

    def _is_credential_pair(value: Any) -> bool:
        if not isinstance(value, tuple):
            return False
        if len(value) != 2:
            return False
        username, password = value
        if not isinstance(username, str) or not isinstance(password, str):
            return False
        # Empty strings are accepted by Gradio but produce a silently-
        # broken login flow. Reject them at the boundary.
        return bool(username) and bool(password)

    accepted_shapes_hint = (
        "Accepted shapes: (username, password) tuple of non-empty strings; "
        "list of such tuples; or a callable (username, password) -> bool. "
        "Empty strings, empty lists, and non-tuple elements are rejected."
    )

    if isinstance(auth, tuple):
        if not _is_credential_pair(auth):
            raise BackpropagateError(
                message="auth tuple must be (username, password) of non-empty strings.",
                code="INPUT_AUTH_INVALID_SHAPE",
                suggestion=accepted_shapes_hint,
                details={"shape": "tuple", "length": len(auth)},
            )
        return

    if isinstance(auth, list):
        if not auth:
            raise BackpropagateError(
                message="auth list must contain at least one (username, password) tuple — empty lists silently disable auth in Gradio.",
                code="INPUT_AUTH_INVALID_SHAPE",
                suggestion=accepted_shapes_hint,
                details={"shape": "list", "length": 0},
            )
        for index, entry in enumerate(auth):
            if not _is_credential_pair(entry):
                raise BackpropagateError(
                    message=(
                        f"auth[{index}] must be a (username, password) tuple of non-empty strings."
                    ),
                    code="INPUT_AUTH_INVALID_SHAPE",
                    suggestion=accepted_shapes_hint,
                    details={"shape": "list", "bad_index": index},
                )
        return

    # Anything else (dict, str, int, ...) — reject.
    raise BackpropagateError(
        message=(
            f"auth must be None, a (username, password) tuple, a list of such tuples, "
            f"or a callable. Got: {type(auth).__name__}"
        ),
        code="INPUT_AUTH_INVALID_SHAPE",
        suggestion=accepted_shapes_hint,
        details={"shape": type(auth).__name__},
    )


def launch(
    port: int = 7862,
    share: bool = False,
    auth: tuple[str, str] | list[tuple[str, str]] | None = None,
) -> None:
    """
    Launch the Gradio UI.

    Args:
        port: Port to run the server on (default: 7862)
        share: Create a public shareable link (default: False)
        auth: Authentication credentials. Required when share=True for security.
              Can be a tuple (username, password) or list of tuples for multiple users.
              May also be a callable (per Gradio); deferred to Gradio's validation.

    Raises:
        ValueError: If share=True but no auth is provided AND
            BACKPROPAGATE_SECURITY__REQUIRE_AUTH_FOR_SHARE is not explicitly
            set to "false" (the default).
        BackpropagateError(code="INPUT_AUTH_INVALID_SHAPE"):
            If ``auth`` is not None and does not match one of the accepted
            shapes (FB-012). Empty lists, one-element tuples, and tuples
            with empty username/password strings are rejected at the
            launch boundary instead of degrading to silent no-auth /
            broken-login behavior inside Gradio.

    Security notes:
        - The ``require_auth_for_share`` flag (config + env var
          ``BACKPROPAGATE_SECURITY__REQUIRE_AUTH_FOR_SHARE``) gates the
          ValueError above. If you set it to ``false`` AND launch with
          ``share=True`` AND no ``auth``, the UI is publicly exposed with
          no authentication. We emit a loud warning to stderr and the
          structured logger, then sleep 5 seconds so you can Ctrl+C to
          abort. There is no flag to suppress this warning — public
          unauthenticated exposure of training/export controls is always
          worth a five-second pause.
        - UI-initiated filesystem writes (LoRA adapters, GGUF exports,
          converted datasets, Modelfiles) are constrained to
          ``~/.backpropagate/ui-outputs`` (override via
          ``BACKPROPAGATE_UI__OUTPUT_DIR``). See
          ``ui_security.get_ui_output_dir``.

    Examples:
        # Local only (no auth needed)
        launch(port=7862)

        # Public URL with auth
        launch(port=7862, share=True, auth=("admin", "secretpassword"))

        # Multiple users
        launch(share=True, auth=[("user1", "pass1"), ("user2", "pass2")])
    """
    # FB-012: validate auth shape BEFORE the share+auth gate so a malformed
    # auth=([],) or auth=('admin',) fails loudly rather than silently
    # disabling auth or hitting a confusing internal TypeError.
    _validate_auth_shape(auth)

    # Security check: require auth when sharing publicly
    if share and auth is None and DEFAULT_SECURITY_CONFIG.require_auth_for_share:
        raise ValueError(
            "Authentication required when share=True. "
            "Set auth parameter or disable require_auth_for_share in SecurityConfig."
        )

    # Security warning: public share with no auth (the require_auth_for_share
    # gate was disabled by env var or config). This is the ONE case where the
    # validation above let us through but the UI is about to go up with no
    # protection. Be loud — silently launching here was F-003 in the audit.
    if share and auth is None:
        warning_msg = (
            "WARNING: launching public Gradio share with no authentication.\n"
            "    Anyone with the share URL can train models, write files in\n"
            "    ~/.backpropagate/ui-outputs (or BACKPROPAGATE_UI__OUTPUT_DIR),\n"
            "    and call Ollama on this machine.\n"
            "    Set BACKPROPAGATE_SECURITY__REQUIRE_AUTH_FOR_SHARE=true and\n"
            "    pass auth=('user', 'password') to require authentication.\n"
            "    Continuing in 5 seconds — Ctrl+C to abort."
        )
        # stderr first (always visible, even if logging is misconfigured).
        print(f"\n{warning_msg}\n", file=sys.stderr, flush=True)
        # Structured log so ops monitoring picks it up.
        logger.warning(warning_msg)
        log_security_event(
            "public_share_without_auth",
            port=port,
            require_auth_for_share=DEFAULT_SECURITY_CONFIG.require_auth_for_share,
        )
        time.sleep(5)

    app = create_ui()
    theme = create_backpropagate_theme()
    css = get_css()

    # Bind to all interfaces only when sharing publicly; localhost otherwise
    server_name = "0.0.0.0" if share else "127.0.0.1"

    launch_kwargs: dict[str, Any] = {
        "server_name": server_name,
        "server_port": port,
        "share": share,
        "inbrowser": True,
        "theme": theme,
        "css": css,
    }

    if auth is not None:
        launch_kwargs["auth"] = auth

    app.launch(**launch_kwargs)
