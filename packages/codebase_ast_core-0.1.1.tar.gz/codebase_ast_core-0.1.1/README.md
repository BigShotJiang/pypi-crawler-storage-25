# codebase-ast-core

AST extraction, shipper-style loaders, and Neo4j graph + embedding stack.

Used by `codebase-qdrant-sync` (chunk loaders) and `codebase-neo4j-sync` (full graph pipeline).

## Install

```bash
pip install codebase-ast-core
```

## Environment

- `EMBED_MODEL` — local sentence-transformers snapshot path
- `NEO4J_URI`, `NEO4J_USER`, `NEO4J_PASSWORD`, `NEO4J_DATABASE` — for graph backend
- `SUTRAKNOWLEDGE_CONFIG` — optional; neo4j-sync writes a minimal JSON when unset
