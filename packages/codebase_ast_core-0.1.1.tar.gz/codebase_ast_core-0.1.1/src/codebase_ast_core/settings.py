"""Environment-backed settings shared by qdrant-sync and neo4j-sync."""

from __future__ import annotations

import os
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path


def _embed_model_from_env() -> str | None:
    raw = (os.environ.get("EMBED_MODEL") or "").strip()
    if not raw:
        return None
    p = Path(raw).expanduser()
    if not p.is_absolute():
        base = os.environ.get("CODEBASE_SETTINGS_ROOT", "").strip()
        if base:
            p = (Path(base).expanduser().resolve() / p).resolve()
        else:
            p = (Path.cwd() / p).resolve()
    else:
        p = p.resolve()
    return str(p)


def _require_embed_model_path() -> str:
    resolved = _embed_model_from_env()
    if resolved is None:
        raise ValueError(
            "EMBED_MODEL is not set. Set an absolute path or a path relative to "
            "CODEBASE_SETTINGS_ROOT / current working directory."
        )
    return resolved


@dataclass(frozen=True)
class Settings:
    neo4j_uri: str
    neo4j_user: str
    neo4j_password: str
    neo4j_database: str
    embed_model: str
    embedding_batch_size: int
    embedding_dimension: int
    embedding_dry_vector: bool
    sync_base_ref: str | None
    head_ref: str | None
    vector_store_target: str
    qdrant_url: str
    qdrant_api_key: str
    qdrant_tls_verify: bool
    qdrant_collection: str
    qdrant_vector_name: str
    reindex_service_name: str


def _env_bool(name: str, default: bool = False) -> bool:
    v = os.environ.get(name)
    if v is None:
        return default
    return v.strip().lower() in ("1", "true", "yes", "on")


def _env_int(name: str, default: int) -> int:
    v = os.environ.get(name)
    if v is None or not str(v).strip():
        return default
    return int(v)


def _qdrant_write_api_key() -> str:
    for name in ("QDRANT_API_KEY", "QDRANT_ADMIN_KEY"):
        v = (os.environ.get(name) or "").strip().lstrip("\ufeff")
        if v:
            return v
    return ""


@lru_cache
def get_settings() -> Settings:
    dim = _env_int("EMBEDDING_DIMENSION", 384)
    vs = (os.environ.get("VECTOR_STORE_TARGET") or "neo4j").strip().lower()
    return Settings(
        neo4j_uri=os.environ.get("NEO4J_URI", "bolt://localhost:7687"),
        neo4j_user=os.environ.get("NEO4J_USER", "neo4j"),
        neo4j_password=os.environ.get("NEO4J_PASSWORD", ""),
        neo4j_database=(os.environ.get("NEO4J_DATABASE") or "neo4j").strip(),
        embed_model=_require_embed_model_path(),
        embedding_batch_size=_env_int("EMBEDDING_BATCH_SIZE", 16),
        embedding_dimension=dim,
        embedding_dry_vector=_env_bool("EMBEDDING_DRY_VECTOR", False),
        sync_base_ref=os.environ.get("SYNC_BASE_REF") or None,
        head_ref=os.environ.get("SYNC_HEAD_REF") or None,
        vector_store_target=vs,
        qdrant_url=(os.environ.get("QDRANT_URL") or "http://127.0.0.1:6333").rstrip("/"),
        qdrant_api_key=_qdrant_write_api_key(),
        qdrant_tls_verify=_env_bool("QDRANT_TLS_VERIFY", True),
        qdrant_collection=(os.environ.get("QDRANT_COLLECTION") or "codebase").strip(),
        qdrant_vector_name=(os.environ.get("QDRANT_VECTOR_NAME") or "code_vector").strip(),
        reindex_service_name=(os.environ.get("REINDEX_SERVICE_NAME") or "").strip(),
    )
