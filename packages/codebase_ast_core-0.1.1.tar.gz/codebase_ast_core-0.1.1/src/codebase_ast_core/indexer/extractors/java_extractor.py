"""Java extractor for code block extraction (tree-sitter-java)."""

from __future__ import annotations

from typing import Any, List, Set

from tree_sitter_language_pack import SupportedLanguage

from . import BaseExtractor, BlockType, CodeBlock


class JavaExtractor(BaseExtractor):
    """Extract classes, methods, constructors, fields, and imports from Java sources."""

    FUNCTION_NODE_TYPES: Set[str] = {"method_declaration", "constructor_declaration"}
    CLASS_NODE_TYPES: Set[str] = {
        "class_declaration",
        "interface_declaration",
        "enum_declaration",
    }

    def __init__(self, language: SupportedLanguage, file_id: int = 0):
        super().__init__(language, file_id)

    def _replace_nested_functions_with_references(
        self, original_content: str, nested_functions: List[CodeBlock]
    ) -> str:
        if not nested_functions:
            return original_content
        sorted_functions = sorted(
            nested_functions, key=lambda f: f.start_line, reverse=True
        )
        for func in sorted_functions:
            func_content = func.content
            reference = f"    // [BLOCK_REF:{func.id}]"
            func_lines = func_content.split("\n")
            signature_lines: List[str] = []
            for line in func_lines:
                signature_lines.append(line)
                if "{" in line:
                    idx = line.find("{")
                    signature_lines[-1] = line[: idx + 1]
                    signature_lines.append(reference)
                    break
            replacement = "\n".join(signature_lines)
            original_content = original_content.replace(func_content, replacement)
        return original_content

    def _extract_names_from_node(self, node: Any) -> List[str]:
        if node is None:
            return []
        if node.type == "identifier":
            return [self._get_node_text(node)]
        name_node = node.child_by_field_name("name")
        if name_node is not None:
            return [self._get_node_text(name_node)]
        for child in getattr(node, "children", []) or []:
            if child.type == "identifier":
                return [self._get_node_text(child)]
        return []

    def _import_block_name(self, node: Any) -> str:
        t = self._get_node_text(node).strip()
        if t.startswith("import "):
            t = t[7:]
        t = t.split(";", 1)[0].strip()
        if t.startswith("static "):
            t = t[7:].strip()
        if "." in t:
            return t.rsplit(".", 1)[-1].strip()
        return t or "import"

    def _field_variable_names(self, node: Any) -> List[str]:
        names: List[str] = []
        for child in getattr(node, "children", []) or []:
            if child.type == "variable_declarator":
                n = child.child_by_field_name("name")
                if n is not None:
                    names.append(self._get_node_text(n))
        return names

    def extract_imports(self, root_node: Any) -> List[CodeBlock]:
        def processor(n: Any) -> CodeBlock:
            return self._create_code_block(
                n, BlockType.IMPORT, [self._import_block_name(n)]
            )

        return self._generic_traversal(root_node, {"import_declaration"}, processor)

    def extract_exports(self, root_node: Any) -> List[CodeBlock]:
        return []

    def extract_functions(self, root_node: Any) -> List[CodeBlock]:

        def processor(node: Any) -> CodeBlock:
            name_node = node.child_by_field_name("name")
            if name_node is not None:
                names = [self._get_node_text(name_node)]
            else:
                names = ["<init>"]
            return self._create_function_block_with_nested_extraction(
                node,
                BlockType.FUNCTION,
                names,
                self.FUNCTION_NODE_TYPES,
            )

        return self._generic_traversal(
            root_node, self.FUNCTION_NODE_TYPES, processor
        )

    def extract_classes(self, root_node: Any) -> List[CodeBlock]:

        def processor(node: Any) -> CodeBlock:
            name_node = node.child_by_field_name("name")
            if not name_node:
                return None
            name = self._get_node_text(name_node)
            if node.type == "class_declaration":
                btype = BlockType.CLASS
            elif node.type == "interface_declaration":
                btype = BlockType.INTERFACE
            else:
                btype = BlockType.ENUM
            return self._create_code_block(node, btype, [name])

        return self._generic_traversal(root_node, self.CLASS_NODE_TYPES, processor)

    def extract_variables(self, root_node: Any) -> List[CodeBlock]:
        def processor(n: Any) -> CodeBlock:
            names = self._field_variable_names(n)
            if not names:
                return None
            return self._create_code_block(n, BlockType.VARIABLE, names)

        return self._generic_traversal(root_node, {"field_declaration"}, processor)

    def extract_all(self, root_node: Any) -> List[CodeBlock]:
        blocks: List[CodeBlock] = []
        blocks.extend(self.extract_imports(root_node))
        blocks.extend(self.extract_variables(root_node))
        blocks.extend(self.extract_classes(root_node))
        blocks.extend(self.extract_functions(root_node))
        return blocks
