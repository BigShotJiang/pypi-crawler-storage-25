"""
Embeddings module - unified embedding generation and vector storage.
"""

from codebase_ast_core.embeddings.embedding_engine import (
    EmbeddingEngine,
    get_embedding_engine,
    parse_entity_id,
)
from codebase_ast_core.embeddings.vector_store import clear_all_embeddings, get_vector_store

__all__ = [
    "get_vector_store",
    "clear_all_embeddings",
    "EmbeddingEngine",
    "get_embedding_engine",
    "parse_entity_id",
]
