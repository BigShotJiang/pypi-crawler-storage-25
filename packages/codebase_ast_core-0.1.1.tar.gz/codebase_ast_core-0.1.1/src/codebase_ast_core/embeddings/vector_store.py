"""Vector store factory — Neo4j embeddings only (no SQLite backend)."""


def get_vector_store():
    """Return the singleton Neo4j-backed vector store."""
    try:
        from codebase_ast_core.embeddings.vector_store_neo4j import Neo4jVectorStore
    except ImportError:
        from codebase_ast_core.embeddings.vector_store_neo4j import Neo4jVectorStore

    return Neo4jVectorStore()


def clear_all_embeddings() -> int:
    """Delete all embeddings from Neo4j. Returns count cleared."""
    store = get_vector_store()
    return store.clear_all_embeddings()
