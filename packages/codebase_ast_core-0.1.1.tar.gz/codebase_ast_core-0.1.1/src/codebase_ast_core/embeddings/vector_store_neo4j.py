"""
Neo4j-backed vector store for embeddings.
"""

import threading
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
from loguru import logger

from codebase_ast_core.config import config

from .embedding_model import EmbeddingModel, TextChunker

try:
    from neo4j import GraphDatabase
except ImportError:
    GraphDatabase = None  # type: ignore

VECTOR_INDEX_NAME = "embedding_chunk_vector_index"
EMBEDDING_LABEL = "EmbeddingChunk"


class Neo4jVectorStore:
    """Vector store that persists embeddings in Neo4j and uses Neo4j vector index for search."""

    _instance: Optional["Neo4jVectorStore"] = None
    _lock = threading.Lock()

    def __new__(cls, *args: Any, **kwargs: Any) -> "Neo4jVectorStore":
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super(Neo4jVectorStore, cls).__new__(cls)
        return cls._instance  # type: ignore[return-value]

    def __init__(
        self,
        model_path: Optional[str] = None,
    ):
        if getattr(self, "initialized", False):
            return

        if not GraphDatabase:
            raise ImportError(
                "Neo4j vector store requires the neo4j package. Install with: pip install neo4j"
            )
        neo4j_cfg = getattr(config.database, "neo4j", None)
        if not neo4j_cfg:
            raise ValueError(
                "database.neo4j config (uri, user, password) is missing"
            )
        self._driver = GraphDatabase.driver(
            neo4j_cfg.uri,
            auth=(neo4j_cfg.user, neo4j_cfg.password),
        )
        self._database = (getattr(neo4j_cfg, "database", None) or "").strip()
        self.connection = None  # Embeddings live in Neo4j; attribute kept for interface parity

        if model_path is None:
            try:
                import os
                from codebase_ast_core.config.settings import get_config
                config_obj = get_config()
                model_path = os.path.expanduser(config_obj.embedding.model_path)
            except Exception:
                model_path = "models/all-MiniLM-L6-v2"

        self.embedding_model = EmbeddingModel(model_path)
        self.text_chunker = TextChunker(self.embedding_model)
        self._embedding_dim = int(self.embedding_model.embedding_dim)
        self._ensure_vector_index()
        self.initialized = True
        logger.debug("Neo4jVectorStore initialized")

    def _db_session_kw(self, base: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        out: Dict[str, Any] = dict(base or {})
        if self._database:
            out["database"] = self._database
        return out

    def _run(self, cypher: str, parameters: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        parameters = parameters or {}
        session_config = {}
        try:
            from neo4j import NotificationMinimumSeverity
            session_config["notifications_min_severity"] = NotificationMinimumSeverity.OFF
        except (ImportError, AttributeError):
            pass
        with self._driver.session(**self._db_session_kw(session_config)) as session:
            result = session.run(cypher, parameters)
            return [dict(record) for record in result]

    def _ensure_vector_index(self) -> None:
        """Create Neo4j vector index for EmbeddingChunk.embedding if it does not exist."""
        # Neo4j 5.11+ vector index
        cypher = f"""
        CREATE VECTOR INDEX {VECTOR_INDEX_NAME} IF NOT EXISTS
        FOR (n:{EMBEDDING_LABEL}) ON (n.embedding)
        OPTIONS {{
            indexConfig: {{
                `vector.dimensions`: {self._embedding_dim},
                `vector.similarity_function`: 'cosine'
            }}
        }}
        """
        try:
            with self._driver.session(**self._db_session_kw()) as session:
                session.run(cypher)
            logger.debug(f"Vector index {VECTOR_INDEX_NAME} ensured")
        except Exception as e:
            if "EquivalentSchemaRuleAlreadyExists" not in str(e) and "already exists" not in str(e).lower():
                logger.warning(f"Vector index creation: {e}")

    def get_embedding(self, text: str) -> np.ndarray:
        return self.embedding_model.get_embedding(text)

    def chunk_text(
        self,
        text: str,
        max_tokens: int = 240,
        overlap_tokens: int = 30,
        metadata: str = "",
    ) -> List[Dict[str, Any]]:
        return self.text_chunker.chunk_text(text, max_tokens, overlap_tokens, metadata)

    def get_chunked_embeddings(
        self, text: str, max_tokens: int = 240, overlap_tokens: int = 30
    ) -> List[Tuple[np.ndarray, Dict[str, Any]]]:
        return self.text_chunker.get_chunked_embeddings(text, max_tokens, overlap_tokens)

    def get_chunked_embeddings_with_metadata(
        self,
        text: str,
        metadata: str = "",
        max_tokens: int = 240,
        overlap_tokens: int = 30,
    ) -> List[Tuple[np.ndarray, Dict[str, Any]]]:
        chunks = self.chunk_text(text, max_tokens, overlap_tokens, metadata)
        if not chunks:
            return []
        chunk_texts = [c["text"] for c in chunks]
        try:
            embeddings = self.embedding_model.get_embeddings_batch(chunk_texts)
            return list(zip(embeddings, chunks))
        except Exception as e:
            logger.error(f"Batch embeddings failed, falling back to single: {e}")
            return [
                (self.embedding_model.get_embedding(c["text"]), c)
                for c in chunks
            ]

    def _embedding_to_list(self, embedding: np.ndarray) -> List[float]:
        arr = (
            embedding.astype(np.float32)
            if isinstance(embedding, np.ndarray)
            else np.array(embedding, dtype=np.float32)
        )
        if arr.shape != (self._embedding_dim,):
            raise ValueError(
                f"Expected shape ({self._embedding_dim},), got {arr.shape}"
            )
        return arr.tolist()

    def store_embedding(
        self,
        node_id: str,
        project_id: int,
        chunk_index: int,
        embedding: np.ndarray,
        chunk_start_line: int,
        chunk_end_line: int,
    ) -> int:
        emb_list = self._embedding_to_list(embedding)
        cypher = f"""
        CREATE (e:{EMBEDDING_LABEL})
        SET e.node_id = $node_id, e.project_id = $project_id, e.chunk_index = $chunk_index,
            e.chunk_start_line = $chunk_start_line, e.chunk_end_line = $chunk_end_line,
            e.embedding = $embedding
        RETURN elementId(e) AS id
        """
        r = self._run(cypher, {
            "node_id": str(node_id),
            "project_id": project_id,
            "chunk_index": chunk_index,
            "chunk_start_line": chunk_start_line,
            "chunk_end_line": chunk_end_line,
            "embedding": emb_list,
        })
        # Return a stable numeric id for API compatibility (hash of node_id + chunk_index)
        return hash((str(node_id), chunk_index)) % (2 ** 31)

    def store_embeddings_batch(
        self, embedding_data_list: List[Dict[str, Any]]
    ) -> List[int]:
        if not embedding_data_list:
            return []
        ids: List[int] = []
        for data in embedding_data_list:
            emb_list = self._embedding_to_list(data["embedding"])
            cypher = f"""
            CREATE (e:{EMBEDDING_LABEL})
            SET e.node_id = $node_id, e.project_id = $project_id, e.chunk_index = $chunk_index,
                e.chunk_start_line = $chunk_start_line, e.chunk_end_line = $chunk_end_line,
                e.embedding = $embedding
            """
            self._run(cypher, {
                "node_id": str(data["node_id"]),
                "project_id": data["project_id"],
                "chunk_index": data["chunk_index"],
                "chunk_start_line": data["chunk_start_line"],
                "chunk_end_line": data["chunk_end_line"],
                "embedding": emb_list,
            })
            ids.append(hash((str(data["node_id"]), data["chunk_index"])) % (2 ** 31))
        return ids

    def search_similar(
        self,
        query_embedding: np.ndarray,
        limit: int = 30,
        threshold: float = 0.0,
        project_id: Optional[int] = None,
    ) -> List[Dict[str, Any]]:
        query_list = self._embedding_to_list(query_embedding)
        # db.index.vector.queryNodes returns node, score (cosine similarity; higher = more similar)
        if project_id is not None:
            cypher = f"""
            CALL db.index.vector.queryNodes($index_name, $limit, $query_vector)
            YIELD node, score
            WHERE node.project_id = $project_id
            RETURN node, score
            """
            params: Dict[str, Any] = {
                "index_name": VECTOR_INDEX_NAME,
                "limit": limit * 2,
                "query_vector": query_list,
                "project_id": project_id,
            }
        else:
            cypher = f"""
            CALL db.index.vector.queryNodes($index_name, $limit, $query_vector)
            YIELD node, score
            RETURN node, score
            """
            params = {
                "index_name": VECTOR_INDEX_NAME,
                "limit": limit,
                "query_vector": query_list,
            }

        rows = self._run(cypher, params)
        results: List[Dict[str, Any]] = []
        for row in rows[:limit]:
            node = row["node"]
            score = float(row["score"])
            # Node may be neo4j.Node (supports node["key"]) or dict when serialized
            def _get(n, key, default=None):
                try:
                    return n.get(key, default) if hasattr(n, "get") and callable(n.get) else n[key]
                except (KeyError, TypeError):
                    return default
            if project_id is not None and _get(node, "project_id") != project_id:
                continue
            if score < threshold:
                continue
            similarity = max(0.0, min(1.0, score))
            distance = 1.0 - similarity
            results.append({
                "embedding_id": 0,
                "node_id": str(_get(node, "node_id", "")),
                "project_id": int(_get(node, "project_id", 0)),
                "chunk_index": int(_get(node, "chunk_index", 0)),
                "chunk_start_line": int(_get(node, "chunk_start_line", 0)),
                "chunk_end_line": int(_get(node, "chunk_end_line", 0)),
                "similarity": similarity,
                "distance": distance,
            })
        return results

    def search_similar_chunks(
        self,
        query_text: str,
        limit: int = 30,
        threshold: float = 0.0,
        project_id: Optional[int] = None,
    ) -> List[Dict[str, Any]]:
        query_embedding = self.get_embedding(query_text)
        return self.search_similar(query_embedding, limit, threshold, project_id)

    def delete_embeddings_for_nodes(
        self, node_ids: List[str], project_id: int
    ) -> None:
        if not node_ids:
            return
        cypher = f"""
        MATCH (e:{EMBEDDING_LABEL})
        WHERE e.node_id IN $node_ids AND e.project_id = $project_id
        DELETE e
        """
        self._run(cypher, {"node_ids": list(node_ids), "project_id": project_id})

    def clear_all_embeddings(self, batch_size: Optional[int] = None) -> int:
        """Delete all embedding nodes in batches to avoid transaction memory limit. Returns total deleted."""
        if batch_size is None:
            batch_size = getattr(config.database, "clear_batch_size", 500)
        batch_size = max(100, min(5000, int(batch_size)))
        total_deleted = 0
        session_config = {}
        try:
            from neo4j import NotificationMinimumSeverity
            session_config["notifications_min_severity"] = NotificationMinimumSeverity.OFF
        except (ImportError, AttributeError):
            pass
        delete_cypher = f"MATCH (e:{EMBEDDING_LABEL}) WITH e LIMIT $batch_size DELETE e"
        with self._driver.session(**self._db_session_kw(session_config)) as session:
            while True:
                result = session.run(delete_cypher, {"batch_size": batch_size})
                summary = result.consume()
                deleted = summary.counters.nodes_deleted if summary.counters else 0
                total_deleted += deleted
                if deleted == 0:
                    break
                logger.debug(f"Cleared embedding batch: {deleted} (total so far: {total_deleted})")
        logger.info(f"Cleared all embeddings from Neo4j vector store ({total_deleted} nodes deleted)")
        return total_deleted

    def get_stats(self) -> Dict[str, Any]:
        try:
            cypher = f"""
            MATCH (e:{EMBEDDING_LABEL})
            WITH count(e) AS total, count(DISTINCT e.node_id) AS unique_nodes
            RETURN total, unique_nodes
            """
            r = self._run(cypher)
            if not r:
                return {
                    "total_embeddings": 0,
                    "unique_nodes": 0,
                    "average_chunks_per_node": 0,
                    "storage_method": "neo4j-vector",
                    "vector_dimension": self._embedding_dim,
                }
            row = r[0]
            total = int(row.get("total", 0))
            unique = int(row.get("unique_nodes", 0))
            avg = round(total / unique, 2) if unique else 0
            return {
                "total_embeddings": total,
                "unique_nodes": unique,
                "average_chunks_per_node": avg,
                "storage_method": "neo4j-vector",
                "vector_dimension": self._embedding_dim,
            }
        except Exception as e:
            logger.error(f"Failed to get Neo4j vector store stats: {e}")
            return {
                "total_embeddings": 0,
                "unique_nodes": 0,
                "average_chunks_per_node": 0,
                "storage_method": "neo4j-vector",
                "vector_dimension": getattr(self, "_embedding_dim", 0),
                "error": str(e),
            }

    def close(self) -> None:
        if getattr(self, "_driver", None):
            self._driver.close()
            self._driver = None
        logger.debug("Neo4j vector store connection closed")
