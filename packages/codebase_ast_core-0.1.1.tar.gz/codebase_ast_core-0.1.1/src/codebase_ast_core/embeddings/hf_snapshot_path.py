"""
Resolve local sentence-transformers model directories (same HF hub pointer rules as Qdrant).

Materializes snapshot trees that use one-line ``../blobs/...`` pointer files into
``<AST_indexer>/.cache/embed_model_materialized/<key>/`` so ``SentenceTransformer`` can load them.
"""

from __future__ import annotations

import hashlib
import shutil
from pathlib import Path

from loguru import logger


def _is_hf_blob_pointer_file(path: Path) -> bool:
    """HF hub layout: small text file whose sole line is a relative path into ``blobs/``."""
    try:
        raw = path.read_text(encoding="utf-8")
    except OSError:
        return False
    text = raw.strip()
    if not text or "\n" in text or text.startswith("{"):
        return False
    if not (text.startswith("../") or text.startswith("./")):
        return False
    target = (path.parent / text).resolve()
    return target.is_file()


def _materialize_hf_snapshot(snapshot_dir: Path, cache_root: Path) -> str:
    """Copy snapshot files, resolving blob pointers into real files (Windows-friendly)."""
    key = hashlib.sha256(str(snapshot_dir.resolve()).encode()).hexdigest()[:20]
    dest = cache_root / "embed_model_materialized" / key
    done = dest / ".materialized_complete"
    if done.is_file():
        return str(dest.resolve())

    if not snapshot_dir.is_dir():
        raise RuntimeError(f"Embedding model path is not a directory: {snapshot_dir}")

    logger.info(
        "Materializing HF snapshot {} -> {} (one-time copy)", snapshot_dir, dest
    )
    if dest.exists():
        shutil.rmtree(dest)
    dest.mkdir(parents=True, exist_ok=True)

    for src in sorted(snapshot_dir.rglob("*")):
        if not src.is_file():
            continue
        rel = src.relative_to(snapshot_dir)
        out = dest / rel
        out.parent.mkdir(parents=True, exist_ok=True)
        if _is_hf_blob_pointer_file(src):
            blob = (src.parent / src.read_text(encoding="utf-8").strip()).resolve()
            shutil.copy2(blob, out)
        else:
            shutil.copy2(src, out)

    done.write_text(str(snapshot_dir.resolve()), encoding="utf-8")
    return str(dest.resolve())


def resolve_st_snapshot_dir(model_path: Path) -> str:
    """
    Return a directory loadable by ``SentenceTransformer``.

    Plain model folders pass through. HF hub ``snapshots/<rev>/`` trees with pointer
    ``config.json`` are materialized under ``AST_indexer/.cache/``.
    """
    p = model_path.expanduser().resolve()
    cfg = p / "config.json"
    if not cfg.is_file():
        return str(p)
    head = cfg.read_text(encoding="utf-8", errors="ignore").lstrip()
    if head.startswith("{"):
        return str(p)
    if _is_hf_blob_pointer_file(cfg):
        ast_indexer_root = Path(__file__).resolve().parents[2]
        return _materialize_hf_snapshot(p, ast_indexer_root / ".cache")
    return str(p)
