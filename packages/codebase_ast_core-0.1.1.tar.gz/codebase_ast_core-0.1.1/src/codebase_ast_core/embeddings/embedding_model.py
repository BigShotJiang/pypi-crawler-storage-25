"""Sentence-transformers embedding model and text chunking (shared by Neo4j vector store)."""

from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
from loguru import logger
from sentence_transformers import SentenceTransformer

from codebase_ast_core.config import config

from .hf_snapshot_path import resolve_st_snapshot_dir


class EmbeddingModel:
    """Loads a local sentence-transformers snapshot (same layout as Qdrant ``EMBED_MODEL``)."""

    def __init__(self, model_path: str = "models/all-MiniLM-L6-v2"):
        self._raw_model_path = Path(model_path)
        resolved = resolve_st_snapshot_dir(self._raw_model_path)
        self.model_path = Path(resolved)
        self._model: Optional[SentenceTransformer] = None
        self.embedding_dim: int = 0
        self._load_model()

    def _load_model(self) -> None:
        try:
            self._model = SentenceTransformer(str(self.model_path))
            self.embedding_dim = int(self._model.get_sentence_embedding_dimension())
            logger.debug(
                "Loaded SentenceTransformer from %s (dim=%s)",
                self.model_path,
                self.embedding_dim,
            )
        except Exception as e:
            logger.error(f"Failed to load embedding model: {e}")
            raise

    def count_tokens(self, text: str) -> int:
        """Count tokens using the SentenceTransformer tokenizer (truncation aligned with config)."""
        if self._model is None:
            raise RuntimeError("Embedding model is not initialized")
        try:
            enc = self._model.tokenizer(
                text,
                add_special_tokens=True,
                truncation=True,
                max_length=config.embedding.tokenizer_max_length,
            )
            ids = enc["input_ids"]
            if hasattr(ids, "shape"):
                return int(ids.shape[-1])
            return len(ids)
        except Exception as e:
            logger.error(f"Tokenizer failed: {e}")
            raise RuntimeError(f"Tokenizer failed: {e}") from e

    def get_embedding(self, text: str) -> np.ndarray:
        """Generate embedding for text."""
        dim = max(1, self.embedding_dim)
        if not text or not text.strip():
            return np.zeros(dim, dtype=np.float32)
        if self._model is None:
            return np.zeros(dim, dtype=np.float32)
        try:
            vec = self._model.encode(
                text,
                convert_to_numpy=True,
                normalize_embeddings=False,
                show_progress_bar=False,
            )
            out = np.asarray(vec, dtype=np.float32).reshape(-1)
            if out.shape[0] != dim:
                logger.error(
                    "Embedding dim mismatch: expected %s, got %s", dim, out.shape[0]
                )
                return np.zeros(dim, dtype=np.float32)
            return out
        except Exception as e:
            logger.error(f"Failed to generate embedding: {e}")
            return np.zeros(dim, dtype=np.float32)

    def get_embeddings_batch(self, texts: List[str]) -> List[np.ndarray]:
        """Encode multiple texts (sub-batches per ``inference_batch_size``)."""
        if not texts:
            return []

        max_batch = getattr(config.embedding, "inference_batch_size", 32)
        if max_batch <= 0:
            max_batch = 32
        dim = max(1, self.embedding_dim)

        try:
            all_embeddings: List[np.ndarray] = []
            for start in range(0, len(texts), max_batch):
                chunk = texts[start : start + max_batch]
                normalized = [t if (t or "").strip() else " " for t in chunk]
                if self._model is None:
                    all_embeddings.extend(
                        [np.zeros(dim, dtype=np.float32) for _ in chunk]
                    )
                    continue
                mat = self._model.encode(
                    normalized,
                    batch_size=max_batch,
                    convert_to_numpy=True,
                    normalize_embeddings=False,
                    show_progress_bar=False,
                )
                mat = np.asarray(mat, dtype=np.float32)
                if mat.ndim == 1:
                    mat = mat.reshape(1, -1)
                for i in range(mat.shape[0]):
                    row = mat[i].reshape(-1)
                    if row.shape[0] != dim:
                        logger.error(
                            "Batch embedding dim mismatch: expected %s, got %s",
                            dim,
                            row.shape[0],
                        )
                        all_embeddings.append(np.zeros(dim, dtype=np.float32))
                    else:
                        all_embeddings.append(row)
            return all_embeddings
        except Exception as e:
            logger.error(f"Failed to generate batch embeddings: {e}")
            return [self.get_embedding(text) for text in texts]


class TextChunker:
    """Handles text chunking with precise line tracking."""

    def __init__(self, embedding_model: EmbeddingModel):
        self.embedding_model = embedding_model
        self._fallback_logged = False  # Track if we've logged the fallback warning

    def _count_tokens(self, text: str) -> int:
        """Accurately count tokens using the embedding model's tokenizer."""
        return self.embedding_model.count_tokens(text)

    def chunk_text(
        self,
        text: str,
        max_tokens: int = 240,
        overlap_tokens: int = 30,
        metadata: str = "",
    ) -> List[Dict[str, Any]]:
        """Split text into token-based adaptive chunks. First chunk includes metadata prefix once."""
        if not text or not text.strip():
            return []

        lines = text.splitlines(keepends=True)
        if not lines:
            return []

        chunks: List[Dict[str, Any]] = []
        metadata_prefix = (metadata + "\n\n") if metadata else ""

        first_chunk_token_budget = (
            max_tokens - self._count_tokens(metadata_prefix)
            if metadata_prefix
            else max_tokens
        )

        line_index = 0
        overlap_text = ""

        while line_index < len(lines):
            start_line = line_index + 1
            chunk_lines = []
            current_chunk_text = overlap_text

            if len(chunks) == 0 and metadata_prefix:
                current_chunk_text = metadata_prefix + current_chunk_text
                token_budget = first_chunk_token_budget
            else:
                token_budget = max_tokens

            while line_index < len(lines):
                line_to_add = lines[line_index]
                potential_text = current_chunk_text + line_to_add

                if self._count_tokens(potential_text) > token_budget and chunk_lines:
                    break

                chunk_lines.append(line_to_add)
                current_chunk_text = potential_text
                line_index += 1

            if not chunk_lines and line_index < len(lines):
                line_to_add = lines[line_index]
                potential_text = current_chunk_text + line_to_add

                if self._count_tokens(potential_text) > token_budget:
                    truncated_line = self._trim_to_max_tokens(
                        current_chunk_text + line_to_add, token_budget
                    )
                    prefix_len = len(current_chunk_text)
                    if len(truncated_line) > prefix_len:
                        line_to_add = truncated_line[prefix_len:]
                    else:
                        line_to_add = ""

                chunk_lines.append(line_to_add)
                current_chunk_text = current_chunk_text + line_to_add
                line_index += 1

            if not chunk_lines:
                break

            chunk_start_line = start_line
            chunk_end_line = start_line + len(chunk_lines) - 1

            chunk_text_for_offset = "".join(chunk_lines)
            if overlap_text and current_chunk_text.startswith(overlap_text):
                char_start = len("".join(lines[: start_line - 1])) - len(
                    overlap_text.rstrip("\n")
                )
            else:
                char_start = len("".join(lines[: start_line - 1]))

            char_end = len("".join(lines[:chunk_end_line]))

            chunks.append(
                {
                    "text": current_chunk_text,
                    "start": char_start,
                    "end": char_end,
                    "start_line": chunk_start_line,
                    "end_line": chunk_end_line,
                    "token_count": self._count_tokens(current_chunk_text),
                }
            )

            if overlap_tokens > 0 and line_index < len(lines):
                overlap_text = self._get_overlap_text(
                    chunk_text_for_offset, overlap_tokens
                )
                if overlap_text:
                    overlap_text += "\n"
            else:
                overlap_text = ""

        return chunks

    def _trim_to_max_tokens(self, text: str, max_tokens: int) -> str:
        """Trim text to fit within max_tokens."""
        if self._count_tokens(text) <= max_tokens:
            return text

        left, right = 0, len(text)
        best_text = ""

        while left <= right:
            mid = (left + right) // 2
            candidate = text[:mid]

            if self._count_tokens(candidate) <= max_tokens:
                best_text = candidate
                left = mid + 1
            else:
                right = mid - 1

        return best_text

    def _get_overlap_text(self, text: str, overlap_tokens: int) -> str:
        """Get the last overlap_tokens worth of text for overlap."""
        if overlap_tokens <= 0:
            return ""

        words = text.split()
        if not words:
            return ""

        for word_count in range(min(len(words), overlap_tokens * 2), 0, -1):
            candidate = " ".join(words[-word_count:])
            if self._count_tokens(candidate) <= overlap_tokens:
                return candidate

        return ""

    def get_chunked_embeddings(
        self, text: str, max_tokens: int = 240, overlap_tokens: int = 30
    ) -> List[Tuple[np.ndarray, Dict[str, Any]]]:
        """Get embeddings for text chunks with metadata using batch processing."""
        chunks = self.chunk_text(text, max_tokens, overlap_tokens)

        if not chunks:
            return []

        chunk_texts = [chunk["text"] for chunk in chunks]

        try:
            embeddings = self.embedding_model.get_embeddings_batch(chunk_texts)
            embeddings_with_metadata = []
            for embedding, chunk in zip(embeddings, chunks):
                embeddings_with_metadata.append((embedding, chunk))

            return embeddings_with_metadata

        except Exception as e:
            logger.error(
                f"Failed to generate batch embeddings, falling back to individual: {e}"
            )
            import traceback

            logger.error(f"Batch embedding error details: {traceback.format_exc()}")
            embeddings_with_metadata = []
            for chunk in chunks:
                try:
                    embedding = self.embedding_model.get_embedding(chunk["text"])
                    embeddings_with_metadata.append((embedding, chunk))
                except Exception as e2:
                    logger.error(f"Failed to generate embedding for chunk: {e2}")
                    continue
            return embeddings_with_metadata
