"""
Convert codebase_shipper loader chunk dicts into sutra ``parse_and_extract`` result dicts.
"""

from __future__ import annotations

import zlib
from collections import defaultdict
from pathlib import Path
from typing import Any

from codebase_ast_core.models.schema import BlockType, CodeBlock
from codebase_ast_core.utils.hash_utils import compute_file_hash
from codebase_ast_core.utils.incremental_hash import IncrementalHashGenerator

# Shipper chunk_type -> BlockType
_CHUNK_TYPE_MAP: dict[str, BlockType] = {
    "package": BlockType.PACKAGE,
    "import": BlockType.IMPORT,
    "class": BlockType.CLASS,
    "enum": BlockType.ENUM,
    "constructor": BlockType.CONSTRUCTOR,
    "method": BlockType.METHOD,
    "field": BlockType.FIELD,
    "properties": BlockType.CONFIG,
    "json": BlockType.CONFIG,
    "json.schema": BlockType.SCHEMA,
    "css_rule": BlockType.STYLE,
    "media_query": BlockType.STYLE,
    "keyframes": BlockType.STYLE,
    "font_face": BlockType.STYLE,
    "html_element": BlockType.MARKUP,
    "script": BlockType.MARKUP,
    "css": BlockType.MARKUP,
    "route": BlockType.ROUTE,
    "xml": BlockType.XML,
}


def _language_for_path(path: Path) -> str:
    ext = path.suffix.lower()
    mapping = {
        ".py": "python",
        ".java": "java",
        ".ts": "typescript",
        ".tsx": "typescript",
        ".js": "javascript",
        ".jsx": "javascript",
        ".css": "css",
        ".scss": "scss",
        ".html": "html",
        ".htm": "html",
        ".xml": "xml",
        ".properties": "properties",
        ".json": "json",
        ".schema": "json",
    }
    return mapping.get(ext, ext.lstrip(".") or "unknown")


def _block_name(chunk: dict[str, Any]) -> str:
    for key in (
        "name",
        "python_name",
        "config_key",
        "json_path",
        "schema_property",
        "route_id",
        "tag",
    ):
        val = chunk.get(key)
        if val:
            return str(val)[:200]
    ct = chunk.get("chunk_type", "block")
    return str(ct)


def _block_content(chunk: dict[str, Any]) -> str:
    return (
        chunk.get("page_content")
        or chunk.get("raw_code")
        or ""
    ).strip()


def _chunk_to_codeblock(
    chunk: dict[str, Any], gen: IncrementalHashGenerator
) -> CodeBlock:
    ct = chunk.get("chunk_type", "block")
    block_type = _CHUNK_TYPE_MAP.get(str(ct), BlockType.VARIABLE)
    block_id = gen.next_id()
    start_line = int(chunk.get("start_line") or 1)
    end_line = int(chunk.get("end_line") or start_line)
    return CodeBlock(
        type=block_type,
        name=_block_name(chunk),
        content=_block_content(chunk),
        start_line=start_line,
        end_line=end_line,
        start_col=int(chunk.get("start_col") or 0),
        end_col=int(chunk.get("end_col") or 0),
        id=block_id,
        children=[],
    )


def _file_id_for_path(file_path: str) -> int:
    crc = zlib.crc32(file_path.encode())
    return crc if crc >= 0 else crc + (2**32)


def _read_file_content(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return ""


def chunk_dicts_to_extraction_results(
    chunks: list[dict[str, Any]],
    *,
    repo_root: str | Path,
) -> dict[str, dict[str, Any]]:
    """Group shipper chunks by source file into extraction results."""
    repo = Path(repo_root).resolve()
    by_file: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for chunk in chunks:
        src = chunk.get("_source_path")
        if not src:
            continue
        by_file[str(Path(src).resolve())].append(chunk)

    results: dict[str, dict[str, Any]] = {}
    for abs_path, file_chunks in by_file.items():
        path = Path(abs_path)
        file_id = _file_id_for_path(abs_path)
        gen = IncrementalHashGenerator(file_id)
        blocks = [_chunk_to_codeblock(c, gen) for c in file_chunks]
        content = _read_file_content(path)
        results[abs_path] = {
            "ast": None,
            "blocks": blocks,
            "language": _language_for_path(path),
            "id": file_id,
            "file_path": abs_path,
            "content": content,
            "content_hash": compute_file_hash(path) or "",
            "relationships": [],
            "unsupported": False,
        }
    return results


def chunks_for_file_to_parse_result(
    file_path: str | Path,
    chunks: list[dict[str, Any]],
) -> dict[str, Any]:
    """Single-file extraction result (incremental indexing)."""
    path = Path(file_path).resolve()
    abs_path = str(path)
    file_id = _file_id_for_path(abs_path)
    gen = IncrementalHashGenerator(file_id)
    blocks = [_chunk_to_codeblock(c, gen) for c in chunks]
    content = _read_file_content(path)
    return {
        "ast": None,
        "blocks": blocks,
        "language": _language_for_path(path),
        "id": file_id,
        "file_path": abs_path,
        "content": content,
        "content_hash": compute_file_hash(path) or "",
        "relationships": [],
        "unsupported": False if blocks else True,
    }
