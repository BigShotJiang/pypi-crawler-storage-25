"""Adapters between shipper loaders and sutra extraction models."""

from codebase_ast_core.adapters.chunk_adapter import (
    chunk_dicts_to_extraction_results,
    chunks_for_file_to_parse_result,
)

__all__ = ["chunk_dicts_to_extraction_results", "chunks_for_file_to_parse_result"]
