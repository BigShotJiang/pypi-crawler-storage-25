"""Codebase shipper-style file loaders (chunk extraction)."""

from codebase_ast_core.loaders.loader_settings import configure_loaders, settings
from codebase_ast_core.loaders.orchestrator import extract_file, index_codebase

__all__ = ["configure_loaders", "settings", "index_codebase", "extract_file"]
