from lxml import etree
import glob
import os
from typing import Dict, List, Optional
from codebase_ast_core.loaders.loader_settings import settings


class XmlLoader:
    def __init__(self):
        pass

    def extract_common_metadata(self, xml_file: str) -> Dict:
        relative_file_path = xml_file.split(settings.ROOT_ESB_FOLDER_NAME, 1)[1]
        service_name = relative_file_path.strip("/").split("/")[0]

        return {
            "file_name": os.path.basename(xml_file),
            "relative_file_path": f"/{relative_file_path}",
            "service_name": service_name,
        }

    def is_real_element(self, element) -> bool:
        return element is not None and isinstance(element.tag, str)

    def local_tag(self, element) -> str:
        return etree.QName(element.tag).localname

    def get_xml_path(self, element) -> str:
        path = []
        while element is not None and self.is_real_element(element):
            path.append(self.local_tag(element))
            element = element.getparent()
        return "/" + "/".join(reversed(path))

    def element_id(self, element, fallback_index: int) -> Optional[str]:
        if not self.is_real_element(element):
            return None

        return (
            element.attrib.get("id")
            or element.attrib.get("name")
            or f"{self.local_tag(element)}:{fallback_index}"
        )

    def element_children(self, element) -> List:
        return [e for e in element if self.is_real_element(e)]

    def element_siblings(self, element) -> List:
        parent = element.getparent()
        if parent is None:
            return []
        return [e for e in parent if self.is_real_element(e)]

    def find_enclosing_route(self, element):
        parent = element
        while parent is not None:
            if self.is_real_element(parent) and self.local_tag(parent) == "route":
                return parent
            parent = parent.getparent()
        return None

    def derive_route_id(self, route_element, file_path: str) -> str:
        explicit = route_element.attrib.get("id")
        if explicit:
            return explicit
        return f"route::{file_path}::{self.get_xml_path(route_element)}"

    def init_route_aggregate(self, route_id: str, metadata: Dict) -> Dict:
        return {
            **metadata,
            "chunk_type": "route",
            "node_type": "route",
            "route_id": route_id,
            "entry_uris": set(),
            "exit_uris": set(),
            "called_routes": set(),
            "called_java_classes": [],
            "xml_nodes": [],
        }

    def summarize_for_embedding(
        self,
        tag: str,
        attributes: Dict,
        text: Optional[str]
    ) -> str:
        parts = [f"XML element {tag}"]
        if attributes:
            parts.append(f"attributes {', '.join(attributes.keys())}")
        if text:
            parts.append("contains text")
        return " with ".join(parts)

    def load_xml_files(self, base_path: str, file_list: list = None) -> List[Dict]:
        xml_files = file_list if file_list is not None else glob.glob(f"{base_path}/**/src/main/**/*.xml", recursive=True)
        chunks: List[Dict] = []

        for xml_file in xml_files:
            metadata = self.extract_common_metadata(xml_file)

            try:
                tree = etree.parse(xml_file)
                root = tree.getroot()
            except Exception as e:
                raise RuntimeError(f"Failed to parse {xml_file}: {e}")

            routes: Dict[str, Dict] = {}

            for element in root.iter():
                if not self.is_real_element(element):
                    continue

                tag = self.local_tag(element)
                attributes = dict(element.attrib)
                text = (element.text or "").strip() or None
                xml_path = self.get_xml_path(element)

                parent = element.getparent()
                siblings = self.element_siblings(element)
                index = siblings.index(element) if element in siblings else 0

                route_element = self.find_enclosing_route(element)
                route_id = None

                if route_element is not None:
                    route_id = self.derive_route_id(
                        route_element,
                        metadata["relative_file_path"]
                    )
                    if route_id not in routes:
                        routes[route_id] = self.init_route_aggregate(
                            route_id, metadata
                        )

                graph = {
                    "route_id": route_id,
                    "parent": self.element_id(parent, 0),
                    "children": [
                        self.element_id(child, i)
                        for i, child in enumerate(self.element_children(element))
                    ],
                    "prev_sibling": (
                        self.element_id(siblings[index - 1], index - 1)
                        if index > 0 else None
                    ),
                    "next_sibling": (
                        self.element_id(siblings[index + 1], index + 1)
                        if index < len(siblings) - 1 else None
                    ),
                }

                if route_id:
                    if tag == "from" and "uri" in attributes:
                        routes[route_id]["entry_uris"].add(attributes["uri"])

                    if tag in {"to", "recipientList"} and "uri" in attributes:
                        uri = attributes["uri"]
                        routes[route_id]["exit_uris"].add(uri)
                        if uri.startswith(("direct:", "direct-vm:", "seda:")):
                            routes[route_id]["called_routes"].add(uri)

                    if tag == "bean":
                        container = (
                            attributes.get("ref")
                            or attributes.get("beanType")
                        )
                        method = attributes.get("method")

                        if container:
                            routes[route_id]["called_java_classes"].append({
                                "tag": "bean",
                                "container": container,
                                **({"method": method} if method else {})
                            })

                    elif tag == "process":
                        container = attributes.get("ref")

                        if container:
                            routes[route_id]["called_java_classes"].append({
                                "tag": "process",
                                "container": container
                            })

                chunk = {
                    **metadata,
                    "chunk_type": "xml",
                    "node_type": "xml_element",
                    "route_id": route_id,
                    "tag": tag,
                    "attributes": attributes,
                    "text": text,
                    "graph": graph,
                    "position": {
                        "depth": len(xml_path.split("/")) - 1,
                        "index": index,
                    },
                    "xml_path": xml_path,
                    "page_content": self.summarize_for_embedding(
                        tag, attributes, text
                    ),
                }

                chunks.append(chunk)

                if route_id:
                    routes[route_id]["xml_nodes"].append(chunk["xml_path"])

            for route in routes.values():
                route["entry_uris"] = list(route["entry_uris"])
                route["exit_uris"] = list(route["exit_uris"])
                route["called_routes"] = list(route["called_routes"])
                # route["called_java_classes"] = list(route["called_java_classes"])

                route["page_content"] = (
                    f"Camel route {route['route_id']}.\n"
                    f"Entry URIs: {route['entry_uris']}.\n"
                    f"Calls routes: {route['called_routes']}.\n"
                    f"Calls Java classes: {route['called_java_classes']}."
                )

                chunks.append(route)

        return chunks