"""
Environment-backed settings for codebase_shipper-style loaders.

Configured via ``configure_loaders()`` before indexing (repo root from AST sync).
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Set


@dataclass
class LoaderSettings:
    CODEBASE_PATH: str = ""
    UI_APP_ROOT: str = ""
    ROOT_ESB_FOLDER_NAME: str = ""
    LIB_PATH: str = ""
    TS_JS_EXTENSIONS: str = ".ts,.tsx,.js,.jsx"
    JAVA_SUPPORTED_CHUNK_TYPES: str = (
        "class_declaration,interface_declaration,enum_declaration,"
        "method_declaration,constructor_declaration,field_declaration,package,import_declaration"
    )
    HTML_SEMANTIC_TAGS: str = (
        "section,article,form,header,main,footer,nav,aside,div,span"
    )
    HTML_SCRIPT_STYLE_TEMPLATE_TAGS: str = "script,style"
    PY_IMPORTS_TOP_LEVEL_ONLY: bool = False
    PY_ENUM_BASE_NAMES: str = (
        "Enum,IntEnum,StrEnum,Flag,IntFlag,"
        "enum.Enum,enum.IntEnum,enum.StrEnum,enum.Flag,enum.IntFlag"
    )

    @property
    def PY_ENUM_BASE_NAMES_SET(self) -> Set[str]:
        return {x.strip() for x in self.PY_ENUM_BASE_NAMES.split(",") if x.strip()}


settings = LoaderSettings()


def configure_loaders(
    codebase_path: str,
    *,
    ui_app_root: str | None = None,
    root_esb_folder_name: str | None = None,
) -> None:
    """Set loader paths from the git repo being indexed."""
    settings.CODEBASE_PATH = os.fspath(codebase_path)
    settings.UI_APP_ROOT = os.fspath(ui_app_root or codebase_path)
    if root_esb_folder_name is not None:
        settings.ROOT_ESB_FOLDER_NAME = root_esb_folder_name
    elif not settings.ROOT_ESB_FOLDER_NAME:
        settings.ROOT_ESB_FOLDER_NAME = os.environ.get(
            "ROOT_ESB_FOLDER_NAME", ""
        ).strip() or os.path.basename(settings.CODEBASE_PATH.rstrip(os.sep))
    settings.LIB_PATH = os.environ.get("LIB_PATH", "").strip()
    settings.TS_JS_EXTENSIONS = os.environ.get(
        "TS_JS_EXTENSIONS", settings.TS_JS_EXTENSIONS
    )
    settings.JAVA_SUPPORTED_CHUNK_TYPES = os.environ.get(
        "JAVA_SUPPORTED_CHUNK_TYPES", settings.JAVA_SUPPORTED_CHUNK_TYPES
    )
    settings.HTML_SEMANTIC_TAGS = os.environ.get(
        "HTML_SEMANTIC_TAGS", settings.HTML_SEMANTIC_TAGS
    )
    settings.HTML_SCRIPT_STYLE_TEMPLATE_TAGS = os.environ.get(
        "HTML_SCRIPT_STYLE_TEMPLATE_TAGS",
        settings.HTML_SCRIPT_STYLE_TEMPLATE_TAGS,
    )
    flag = os.environ.get("PY_IMPORTS_TOP_LEVEL_ONLY", "").strip().lower()
    settings.PY_IMPORTS_TOP_LEVEL_ONLY = flag in ("1", "true", "yes", "on")
    settings.PY_ENUM_BASE_NAMES = os.environ.get(
        "PY_ENUM_BASE_NAMES", settings.PY_ENUM_BASE_NAMES
    )
