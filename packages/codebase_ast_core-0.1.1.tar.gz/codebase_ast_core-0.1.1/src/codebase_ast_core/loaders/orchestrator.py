"""
Orchestrate all loaders (same order and paths as codebase_shipper ``indexer.py``).
"""

from __future__ import annotations

import glob
import os
from pathlib import Path
from typing import Any

from codebase_ast_core.loaders.css_loader import CssParser
from codebase_ast_core.loaders.fallback_loader import NonJavaFileLoader
from codebase_ast_core.loaders.html_loader import HtmlParser
from codebase_ast_core.loaders.java_loader import JavaParser
from codebase_ast_core.loaders.javascript_loader import JavaScriptParser
from codebase_ast_core.loaders.loader_settings import configure_loaders, settings
from codebase_ast_core.loaders.python_loader import PythonParser
from codebase_ast_core.loaders.scss_loader import ScssParser
from codebase_ast_core.loaders.typescript_loader import TypeScriptParser
from codebase_ast_core.loaders.xml_loader import XmlLoader


def _tag_chunks(chunks: list[dict], source_path: str) -> list[dict]:
    for c in chunks:
        c["_source_path"] = source_path
    return chunks


def index_codebase(codebase_path: str, *, ui_app_root: str | None = None) -> list[dict]:
    """
    Run all shipper loaders; return flat list of chunk dicts with ``_source_path``.
    """
    configure_loaders(codebase_path, ui_app_root=ui_app_root)
    base = settings.CODEBASE_PATH
    ui = settings.UI_APP_ROOT
    all_chunks: list[dict] = []

    js = JavaScriptParser()
    for file_path in js._collect_files(ui):
        tree, code, rel, name = js.parse_file(file_path, ui)
        all_chunks.extend(
            _tag_chunks(
                js.extract_chunks(tree, code, rel, name, file_path),
                file_path,
            )
        )

    ts = TypeScriptParser()
    for file_path in ts._collect_files(ui):
        tree, code, rel, name = ts.parse_file(file_path, ui)
        all_chunks.extend(
            _tag_chunks(
                ts.extract_chunks(tree, code, rel, name, file_path),
                file_path,
            )
        )

    css = CssParser()
    for file_path in css._collect_files(ui):
        code, tree, rel, name = css.parse_file(file_path, ui)
        all_chunks.extend(
            _tag_chunks(css.extract_chunks(code, tree, rel, name), file_path)
        )

    scss = ScssParser()
    for file_path in scss._collect_files(ui):
        code, tree, rel, name = scss.parse_file(file_path, ui)
        all_chunks.extend(
            _tag_chunks(scss.extract_chunks(code, tree, rel, name), file_path)
        )

    html = HtmlParser()
    for file_path in html._collect_files(ui):
        code, tree, rel, name = html.parse_file(file_path, ui)
        all_chunks.extend(
            _tag_chunks(html.extract_chunks(code, tree, rel, name), file_path)
        )

    java_glob = os.path.join(base, "**", "src", "**", "*.java")
    jp = JavaParser()
    for file_path in glob.glob(java_glob, recursive=True):
        norm = file_path.replace("\\", "/")
        if "/test/" in norm or "/tests/" in norm:
            continue
        tree, service_name, rel, name = jp.parse_file(file_path)
        all_chunks.extend(
            _tag_chunks(jp.extract_chunks(tree, service_name, rel, name), file_path)
        )

    all_chunks.extend(NonJavaFileLoader().load(base))

    xml_glob = os.path.join(base, "**", "src", "**", "*.xml")
    xml_files = [
        f
        for f in glob.glob(xml_glob, recursive=True)
        if "/test/" not in f.replace("\\", "/") and "/tests/" not in f.replace("\\", "/")
    ]
    xl = XmlLoader()
    for xml_file in xml_files:
        file_chunks = xl.load_xml_files(base, [xml_file])
        for c in file_chunks:
            c["_source_path"] = xml_file
        all_chunks.extend(file_chunks)

    py = PythonParser(lib_path=settings.LIB_PATH or None)
    all_chunks.extend(py.load(base))

    return all_chunks


def _repo_root(path: Path) -> Path:
    for candidate in (path, *path.parents):
        if (candidate / ".git").is_dir():
            return candidate
    return path.parent


def extract_file(file_path: str | Path, *, repo_root: str | Path | None = None) -> list[dict]:
    """Extract chunks for a single file (incremental sync)."""
    path = Path(file_path).resolve()
    root = Path(repo_root).resolve() if repo_root else _repo_root(path)
    configure_loaders(str(root), ui_app_root=str(root))
    base = settings.CODEBASE_PATH
    ui = settings.UI_APP_ROOT
    ext = path.suffix.lower()
    fp = str(path)

    if ext in (".js", ".jsx"):
        p = JavaScriptParser()
        tree, code, rel, name = p.parse_file(fp, ui)
        return _tag_chunks(p.extract_chunks(tree, code, rel, name, fp), fp)
    if ext in (".ts", ".tsx"):
        p = TypeScriptParser()
        tree, code, rel, name = p.parse_file(fp, ui)
        return _tag_chunks(p.extract_chunks(tree, code, rel, name, fp), fp)
    if ext == ".css":
        p = CssParser()
        code, tree, rel, name = p.parse_file(fp, ui)
        return _tag_chunks(p.extract_chunks(code, tree, rel, name), fp)
    if ext == ".scss":
        p = ScssParser()
        code, tree, rel, name = p.parse_file(fp, ui)
        return _tag_chunks(p.extract_chunks(code, tree, rel, name), fp)
    if ext in (".html", ".htm"):
        p = HtmlParser()
        code, tree, rel, name = p.parse_file(fp, ui)
        return _tag_chunks(p.extract_chunks(code, tree, rel, name), fp)
    if ext == ".java":
        jp = JavaParser()
        tree, svc, rel, name = jp.parse_file(fp)
        return _tag_chunks(jp.extract_chunks(tree, svc, rel, name), fp)
    if ext == ".xml":
        return _tag_chunks(XmlLoader().load_xml_files(base, [fp]), fp)
    if ext == ".py":
        py = PythonParser(lib_path=settings.LIB_PATH or None)
        tree, code, svc, rel, name = py.parse_file(fp)
        return _tag_chunks(py.extract_chunks(tree, code, svc, rel, name), fp)
    if ext == ".properties":
        return _tag_chunks(NonJavaFileLoader().load_properties_file(fp), fp)
    if ext == ".json":
        return _tag_chunks(NonJavaFileLoader().load_json_file(fp), fp)
    if ext == ".schema":
        return _tag_chunks(NonJavaFileLoader().load_json_schema_file(fp), fp)
    return []
