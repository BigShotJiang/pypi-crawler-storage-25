"""TypeScript loader: extract chunks from .ts and .tsx using tree-sitter-typescript."""
from tree_sitter import Parser, Tree, Node, Language
import os
import re

import tree_sitter_typescript as tsts
from codebase_ast_core.loaders.loader_settings import settings


class TypeScriptParser:

    # ---------- Parser initialization ----------
    def __init__(self):
        ts_ptr = tsts.language_typescript()
        tsx_ptr = tsts.language_tsx()
        self._ts_lang = ts_ptr if isinstance(ts_ptr, Language) else Language(ts_ptr)
        self._tsx_lang = tsx_ptr if isinstance(tsx_ptr, Language) else Language(tsx_ptr)
        self._parser = Parser()
        self._extensions = {x.strip().lower() for x in settings.TS_JS_EXTENSIONS.split(",") if x.strip()}
        self._extensions = {e for e in self._extensions if e in (".ts", ".tsx")}
        if not self._extensions:
            self._extensions = {".ts", ".tsx"}

    # ---------- Parse file ----------
    def parse_file(self, file_path: str, app_root: str) -> tuple[Tree | None, str, str, str]:
        with open(file_path, "r", encoding="utf-8", errors="replace") as f:
            code = f.read()
        file_name = os.path.basename(file_path)
        relative_file_path = self._relative_path(file_path, app_root)
        ext = os.path.splitext(file_path)[1].lower()
        if ext not in self._extensions:
            return None, code, relative_file_path, file_name
        lang = self._ts_lang if ext == ".ts" else self._tsx_lang if ext == ".tsx" else None
        if lang is None:
            return None, code, relative_file_path, file_name
        try:
            self._parser.language = lang
            tree = self._parser.parse(code.encode("utf-8"))
            return tree, code, relative_file_path, file_name
        except Exception:
            return None, code, relative_file_path, file_name

    # ---------- Extract chunks ----------
    def extract_chunks(
        self,
        tree: Tree | None,
        code: str,
        relative_file_path: str,
        file_name: str,
        file_path: str,
    ) -> list[dict]:
        if tree is None or tree.root_node is None:
            return []
        return self._walk(tree.root_node, code, relative_file_path, file_name, file_path)

    # ---------- Load files ----------
    def load(self, app_root: str) -> list[dict]:
        all_chunks = []
        for file_path in self._collect_files(app_root):
            tree, code, relative_file_path, file_name = self.parse_file(file_path, app_root)
            all_chunks.extend(
                self.extract_chunks(tree, code, relative_file_path, file_name, file_path)
            )
        return all_chunks

    # ---------- Relative path ----------
    def _relative_path(self, file_path: str, app_root: str) -> str:
        path = os.path.normpath(file_path)
        root = os.path.normpath(app_root)
        if path.startswith(root):
            path = path[len(root) :].lstrip(os.sep)
        return path.replace("\\", "/")

    # ---------- Collect files ----------
    def _collect_files(self, app_root: str) -> list[str]:
        out = []
        for root, _, files in os.walk(app_root):
            for f in files:
                if os.path.splitext(f)[1].lower() in self._extensions:
                    out.append(os.path.join(root, f))
        return out

    # ---------- Node text ----------
    def _node_text(self, code: str, node: Node | None) -> str:
        if not node:
            return ""
        return code[node.start_byte : node.end_byte]

    # ---------- Find child by type ----------
    def _find_child(self, node: Node, type_name: str) -> Node | None:
        for c in node.children:
            if c.type == type_name:
                return c
        return None

    # ---------- Find all nodes ----------
    def _find_all(self, node: Node, type_name: str) -> list[Node]:
        result = []
        if node.type == type_name:
            result.append(node)
        for c in node.children:
            result.extend(self._find_all(c, type_name))
        return result

    # ---------- Chunk ----------
    def _chunk(
        self,
        node: Node,
        chunk_type: str,
        name: str,
        file_name: str,
        relative_file_path: str,
        page_content: str,
        called_methods: list[dict] | None = None,
        called_classes: list[str] | None = None,
    ) -> dict:
        start_line = (node.start_point[0] + 1) if hasattr(node, "start_point") else 1
        end_line = (node.end_point[0] + 1) if hasattr(node, "end_point") else 1
        out = {
            "chunk_type": chunk_type,
            "name": name,
            "file_name": file_name,
            "relative_file_path": relative_file_path,
            "page_content": page_content,
            "start_line": start_line,
            "end_line": end_line,
        }
        if called_methods:
            out["called_methods"] = called_methods
        if called_classes:
            out["called_classes"] = called_classes
        return out

    # ---------- Get name node ----------
    def _name_node(self, node: Node, code: str) -> Node | None:
        if hasattr(node, "child_by_field_name"):
            n = node.child_by_field_name("name")
            if n is not None:
                return n
        return self._find_child(node, "identifier") or self._find_child(node, "type_identifier")

    # ---------- Get declaration name ----------
    def _declaration_name(self, node: Node, code: str) -> str | None:
        name_node = self._name_node(node, code)
        if name_node:
            return self._node_text(code, name_node)
        if node.type in ("lexical_declaration", "variable_declaration"):
            decl = self._find_child(node, "variable_declarator")
            if decl:
                id_node = self._find_child(decl, "identifier")
                if id_node:
                    return self._node_text(code, id_node)
        return None

    # ---------- Call expression info ----------
    def _call_info(self, code: str, node: Node) -> dict | None:
        func = node.child_by_field_name("function") if hasattr(node, "child_by_field_name") else None
        if not func:
            return None
        method_name = None
        class_name = None
        if func.type == "identifier":
            method_name = self._node_text(code, func)
        elif func.type == "member_expression":
            prop = func.child_by_field_name("property")
            obj = func.child_by_field_name("object")
            if prop:
                method_name = self._node_text(code, prop)
            if obj:
                class_name = self._node_text(code, obj)
        if not method_name:
            return None
        return {"method_name": method_name, "class_name": class_name}

    # ---------- Class from new expression ----------
    def _class_from_new(self, code: str, node: Node) -> str | None:
        value = node.child_by_field_name("value") or node.child_by_field_name("constructor")
        if not value:
            return None
        if value.type == "identifier":
            return self._node_text(code, value)
        if value.type == "member_expression":
            return self._node_text(code, value)
        return None

    # ---------- Extract calls ----------
    def _extract_calls(self, code: str, node: Node) -> tuple[list[dict], list[str]]:
        calls = []
        called_classes = set()
        for call_node in self._find_all(node, "call_expression"):
            info = self._call_info(code, call_node)
            if info:
                calls.append(info)
                if info.get("class_name"):
                    cn = info["class_name"].split(".")[-1].strip()
                    if cn and not cn.startswith("'"):
                        called_classes.add(cn)
        for new_node in self._find_all(node, "new_expression"):
            cls = self._class_from_new(code, new_node)
            if cls:
                parts = cls.split(".")
                if parts:
                    called_classes.add(parts[-1].strip())
        return calls, sorted(called_classes)

    # ---------- Contains JSX ----------
    def _has_jsx(self, node: Node, code: str) -> bool:
        text = self._node_text(code, node)
        return bool(re.search(r"<[A-Za-z][\w-]*|</[A-Za-z]|\{[^}]*\s*<", text))

    # ---------- Resolve kind (component / hook) ----------
    def _resolve_kind(
        self,
        base_kind: str,
        name: str,
        node: Node,
        code: str,
        is_jsx_file: bool,
        relative_file_path: str,
    ) -> str:
        if base_kind == "function" and name.startswith("use") and len(name) > 3 and name[3].isupper():
            return "hook"
        if is_jsx_file and base_kind in ("function", "class"):
            if self._has_jsx(node, code):
                return "component"
            if base_kind == "class" and re.match(r"^[A-Z]", name):
                return "component"
            path_lower = relative_file_path.lower()
            if base_kind == "function" and "hooks" in path_lower and name.startswith("use") and len(name) > 3 and name[3].isupper():
                return "hook"
            if "components" in path_lower and re.match(r"^[A-Z]", name):
                return "component"
        return base_kind

    # ---------- Walk AST ----------
    def _walk(
        self,
        node: Node,
        code: str,
        relative_file_path: str,
        file_name: str,
        file_path: str,
    ) -> list[dict]:
        chunks = []
        ext = os.path.splitext(file_path)[1].lower()
        is_jsx_file = ext == ".tsx"
        target_types = {
            "function_declaration": "function",
            "class_declaration": "class",
            "abstract_class_declaration": "class",
            "interface_declaration": "interface",
            "type_alias_declaration": "type",
            "enum_declaration": "enum",
            "lexical_declaration": "constant",
            "variable_declaration": "constant",
        }

        def walk(n: Node):
            if n.type in target_types:
                base_kind = target_types[n.type]
                name = self._declaration_name(n, code)
                if n.type in ("lexical_declaration", "variable_declaration"):
                    for child in n.children:
                        if child.type == "variable_declarator":
                            id_node = self._find_child(child, "identifier")
                            name = self._node_text(code, id_node) if id_node else None
                            if name:
                                page_content = self._node_text(code, child)
                                calls, called_list = self._extract_calls(code, child)
                                chunks.append(
                                    self._chunk(
                                        child, base_kind, name,
                                        file_name, relative_file_path, page_content,
                                        called_methods=calls if calls else None,
                                        called_classes=called_list if called_list else None,
                                    )
                                )
                    return
                if name and base_kind in ("function", "class"):
                    kind = self._resolve_kind(base_kind, name, n, code, is_jsx_file, relative_file_path)
                    page_content = self._node_text(code, n)
                    calls, called_list = self._extract_calls(code, n)
                    chunks.append(
                        self._chunk(
                            n, kind, name,
                            file_name, relative_file_path, page_content,
                            called_methods=calls if calls else None,
                            called_classes=called_list if called_list else None,
                        )
                    )
                    return
                if name and base_kind in ("interface", "type", "enum"):
                    page_content = self._node_text(code, n)
                    chunks.append(
                        self._chunk(n, base_kind, name, file_name, relative_file_path, page_content)
                    )
                    return
            for c in n.children:
                walk(c)

        walk(node)
        return chunks
