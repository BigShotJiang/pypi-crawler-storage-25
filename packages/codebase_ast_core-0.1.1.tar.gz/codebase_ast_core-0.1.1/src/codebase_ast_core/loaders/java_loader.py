from tree_sitter import Parser, Tree, Node, Language
import tree_sitter_java as tsjava
import os
from typing import List, Dict, Optional
from codebase_ast_core.loaders.loader_settings import settings

JAVA_SUPPORTED_CHUNK_TYPES = {
    t.strip()
    for t in settings.JAVA_SUPPORTED_CHUNK_TYPES.split(",")
    if t.strip()
}

class JavaParser:
    def __init__(self):
        JAVA_LANGUAGE = Language(tsjava.language())
        self.parser = Parser(JAVA_LANGUAGE)
    
    def parse_file(self, file_path: str):
        with open(file_path, "r", encoding="utf-8", errors="replace") as f:
            relative_file_path = file_path.split(
                settings.ROOT_ESB_FOLDER_NAME, 1
            )[1]
            service_name = relative_file_path.strip("/").split("/")[0]
            file_name = os.path.basename(file_path)
            relative_file_path = f"/{relative_file_path}"
            code = f.read()

        tree = self.parser.parse(code.encode("utf8"))
        return tree, service_name, relative_file_path, file_name

    def node_text(self, node: Node) -> Optional[str]:
        if not node:
            return None
        return node.text.decode("utf-8", errors="replace") if node.text else None

    def find_child(self, node, type_name: str):
        if not node:
            return None
        for c in node.children:
            if c.type == type_name:
                return c
        return None

    def find_all(self, node: Node, type_name: str):
        result = []
        if node.type == type_name:
            result.append(node)
        for c in node.children:
            result.extend(self.find_all(c, type_name))
        return result

    def extract_fields(self, field_nodes: list[Node]) -> Dict[str, str]:
        fields = {}

        for field_node in field_nodes:
            type_name = None

            for c in field_node.children:
                if c.type == "type_identifier":
                    type_name = self.node_text(c)
                    break

            if not type_name:
                continue

            for c in field_node.children:
                if c.type == "variable_declarator":
                    fields[self.node_text(c)] = type_name

        return fields

    def extract_parameters(self, method_node: Node) -> Dict[str, str]:
        params = {}
        for p in self.find_all(method_node, "formal_parameter"):
            type_node = self.find_child(p, "type_identifier")
            if type_node is None:
                g_node = self.find_child(p, "generic_type")
                type_args = self.find_child(g_node, "type_arguments")
                type_node = self.find_child(type_args, "type_identifier")
            
            type_name = self.node_text(type_node)

            id_node = self.find_child(p, "identifier")
            if type_node and id_node:
                params[self.node_text(id_node)] = type_name

        return params

    def extract_method_call(
        self,
        node,
        field_types: Dict[str, str],
        param_types: Dict[str, str],
        local_types: Dict[str, str],
    ) -> Optional[Dict]:
        class_name: str = None
        method_name: str = None
        arguments: List[str] = []

        for id_node in self.find_all(node, "identifier"):
            name = self.node_text(id_node)
            for fKey, fValue in field_types.items():
                if name == fKey:
                    class_name = fValue
                    continue
            for pKey, pValue in param_types.items():
                if name == pKey:
                    class_name = pValue
                    continue
            for lKey, lValue in local_types.items():
                if name == lKey:
                    class_name = lValue
                    continue
            
            method_name = name
        
        if method_name in ["from", "bean", "to", "toD"]:
            arg_list = self.find_child(node, "argument_list")
            if arg_list:
                for child in arg_list.children:
                    if child.type in ["(", ",", ")"]:
                        continue

                    arg_text = self.node_text(child)
                    if arg_text:
                        arguments.append(arg_text.strip())

        return {
            "method_name": method_name,
            "class_name": class_name,
            "parameters": arguments,
        }
    
    def extract_locals(self, method_node: Node) -> Dict[str, str]:
        locals_map = {}

        for decl in self.find_all(method_node, "local_variable_declaration"):
            type_node = self.find_child(decl, "type_identifier")
            type_name = self.node_text(type_node)

            for d in self.find_all(decl, "variable_declarator"):
                id_node = self.find_child(d, "identifier")
                if id_node and type_name:
                    locals_map[self.node_text(id_node)] = type_name

        return locals_map
    
    def normalize_class_name(self, name: Optional[str]) -> Optional[str]:
        if not name:
            return None

        if "(" in name or ")" in name:
            return None

        if "." in name:
            return name.split(".")[-1]

        return name

    def extract_chunks(
        self,
        tree: Tree,
        service_name: str,
        relative_file_path: str,
        file_name: str,
    ) -> List[Dict]:
        chunks = []
        root: Node = tree.root_node

        current_class = None
        super_class = None
        super_interfaces = None
        field_nodes: list[Node] = []
        field_types: Dict[str, str] = {}
        
        def walk(node: Node):
            nonlocal current_class, super_class, super_interfaces, field_nodes, field_types

            if node.type == "class_declaration" and current_class == None:
                identifier_node_id = self.find_child(node, "identifier")
                superclass_node_id = self.find_child(node, "superclass")
                super_interfaces_node_id = self.find_child(node, "super_interfaces")
                current_class = self.node_text(identifier_node_id)
                super_class = self.node_text(superclass_node_id)
                super_interfaces = self.node_text(super_interfaces_node_id)
                field_nodes = self.find_all(node, "field_declaration")
                field_types = self.extract_fields(field_nodes)
                chunks.append({
                    "chunk_type": "class",
                    "name": current_class,
                    "container": current_class,
                    "file_name": file_name,
                    "service_name": service_name,
                    "relative_file_path": relative_file_path,
                    "super_class": super_class,
                    "super_interfaces": super_interfaces,
                    "page_content": node.type,
                })
            if node.type in JAVA_SUPPORTED_CHUNK_TYPES:
                if node.type in "package_declaration":
                    chunks.append({
                        "chunk_type": "package",
                        "container": file_name.split(".")[0],
                        "file_name": file_name,
                        "service_name": service_name,
                        "relative_file_path": relative_file_path,
                        "page_content": node.text.decode("utf-8", errors="replace") if node.text else None,
                    })

                if node.type in "import_declaration":
                    chunks.append({
                        "chunk_type": "import",
                        "container": file_name.split(".")[0],
                        "file_name": file_name,
                        "service_name": service_name,
                        "relative_file_path": relative_file_path,
                        "page_content": node.text.decode("utf-8", errors="replace") if node.text else None,
                    })

                if node.type in "constructor_declaration":
                    chunks.append({
                        "chunk_type": "constructor",
                        "container": current_class,
                        "file_name": file_name,
                        "service_name": service_name,
                        "relative_file_path": relative_file_path,
                        "page_content": node.text.decode("utf-8", errors="replace") if node.text else None,
                    })
            
            if node.type in "method_declaration":
                identifier_node_id = self.find_child(node, "identifier")
                method_name = self.node_text(identifier_node_id)
                param_types = self.extract_parameters(node)
                local_types = self.extract_locals(node)
                calls: List[Dict] = []
                called_classes: set = set()
                for inv in self.find_all(node, "method_invocation"):
                    info = self.extract_method_call(
                        inv, field_types, param_types, local_types
                    )
                    if info:
                        calls.append(info)
                        if info["class_name"]:
                            normalized = self.normalize_class_name(info["class_name"])
                            if normalized:
                                called_classes.add(normalized)

                chunks.append({
                    "chunk_type": "method",
                    "symbol_id": f"{service_name}:{file_name}:{current_class}:{method_name}",
                    "name": method_name,
                    "container": current_class,
                    "file_name": file_name,
                    "service_name": service_name,
                    "relative_file_path": relative_file_path,
                    "called_methods": calls,
                    "called_classes": sorted(called_classes),
                    "page_content": node.text.decode("utf-8", errors="replace") if node.text else None,
                })
                return
            
            for c in node.children:
                walk(c)

        walk(root)

        if "field_declaration" in JAVA_SUPPORTED_CHUNK_TYPES:
            # field nodes append here
            for f_node in field_nodes:
                chunks.append({
                    "chunk_type": "field",
                    "container": current_class,
                    "file_name": file_name,
                    "service_name": service_name,
                    "relative_file_path": relative_file_path,
                    "page_content": f_node.text.decode("utf-8", errors="replace") if f_node.text else None
                })
        return chunks