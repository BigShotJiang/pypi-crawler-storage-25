import os
import re
from typing import List, Dict
from codebase_ast_core.loaders.loader_settings import settings

MACRO_PATTERN = re.compile(
    r"<#macro\s+(\w+)[^>]*>(.*?)</#macro>",
    re.DOTALL
)

IF_PATTERN = re.compile(
    r"<#if\s+[^>]+>(.*?)</#if>",
    re.DOTALL
)

LIST_PATTERN = re.compile(
    r"<#list\s+[^>]+>(.*?)</#list>",
    re.DOTALL
)

ASSIGN_PATTERN = re.compile(
    r"<#assign\s+([^=]+)=\s*([^/>]+)\s*/?>"
)

class FtlLoader:
    def extract_common_metadata(self, source_path: str) -> Dict:
        relative_file_path = source_path.split(settings.ROOT_ESB_FOLDER_NAME, 1)[1]
        service_name = relative_file_path.strip("/").split("/")[0]

        return {
            "file_name": os.path.basename(source_path),
            "relative_file_path": f"/{relative_file_path}",
            "service_name": service_name,
        }
    
    def summarize_macro(self, name: str, body: str) -> str:
        variables = sorted(set(re.findall(r"\$\{([^}]+)\}", body)))
        var_text = ", ".join(variables) if variables else "no variables"

        return (
            f"FreeMarker macro {name}. "
            f"Uses variables: {var_text}."
        )
    
    def summarize_block(self, block_type: str, body: str) -> str:
        variables = sorted(set(re.findall(r"\$\{([^}]+)\}", body)))
        var_text = ", ".join(variables) if variables else "no variables"

        return (
            f"FreeMarker {block_type} block. "
            f"Uses variables: {var_text}."
        )
    
    def load_ftl_files(self, base_path: str) -> List[Dict]:
        chunks: List[Dict] = []

        for root, _, files in os.walk(base_path):
            for file in files:
                if file.endswith(".ftl"):
                    try:
                        chunks.extend(self.load_ftl_file(os.path.join(root, file)))
                    except Exception:
                        continue

        return chunks
    
    def load_ftl_file(self, path: str) -> List[Dict]:
        chunks: List[Dict] = []
        metadata = self.extract_common_metadata(path)

        with open(path, encoding="utf-8") as f:
            content = f.read()

        for match in MACRO_PATTERN.finditer(content):
            name, body = match.groups()
            chunks.append({
                **metadata,
                "chunk_type": "ftl.macro",
                "ftl_type": "macro",
                "ftl_name": name,
                "page_content": self.summarize_macro(name, body),
            })

        for match in IF_PATTERN.finditer(content):
            body = match.group(0)
            chunks.append({
                **metadata,
                "chunk_type": "ftl.if",
                "ftl_type": "if",
                "page_content": self.summarize_block("if", body),
            })

        for match in LIST_PATTERN.finditer(content):
            body = match.group(0)
            chunks.append({
                **metadata,
                "chunk_type": "ftl.list",
                "ftl_type": "list",
                "page_content": self.summarize_block("list", body),
            })

        for match in ASSIGN_PATTERN.finditer(content):
            key, value = match.groups()
            chunks.append({
                **metadata,
                "chunk_type": "ftl.assign",
                "ftl_type": "assign",
                "ftl_variable": key.strip(),
                "page_content": f"FreeMarker assignment: {key.strip()} is set.",
            })

        if not chunks:
            text = re.sub(r"<#.*?>", "", content).strip()
            if text:
                chunks.append({
                    **metadata,
                    "chunk_type": "ftl.text",
                    "ftl_type": "text",
                    "page_content": "FreeMarker template static content.",
                })

        return chunks

