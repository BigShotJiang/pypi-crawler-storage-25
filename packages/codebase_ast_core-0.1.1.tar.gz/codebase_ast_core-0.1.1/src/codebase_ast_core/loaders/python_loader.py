from tree_sitter import Language, Parser
from ctypes import cdll, c_void_p
import os
from codebase_ast_core.loaders.loader_settings import settings


class PythonParser:
    """
    Extract Python chunks:
      - package (one per file; inferred from relative path)
      - import (import_statement / import_from_statement)
      - class / enum
      - constructor (methods named __init__ or __new__ inside a class)
      - method (other methods inside a class; decorated OK)

    Notes:
      - Enum detection is driven by settings.PY_ENUM_BASE_NAMES_SET
      - Imports can be captured anywhere; set PY_IMPORTS_TOP_LEVEL_ONLY=True in .env
        if you want only module-level imports.
      - All chunks include 'raw_code' and precise positions (line/col/byte).
    """

    def __init__(self, lib_path: str | None = None, chunk_types_str: str = ""):
        """
        :param lib_path: Optional compiled Tree-sitter shared library; if unset uses language-pack.
        :param chunk_types_str: Reserved for future filtering/extensibility.
        """
        self.lib_path = (lib_path or settings.LIB_PATH or "").strip()
        self.chunk_types_str = chunk_types_str

        self.IMPORTS_TOP_LEVEL_ONLY = settings.PY_IMPORTS_TOP_LEVEL_ONLY
        self.ENUM_BASE_NAMES = settings.PY_ENUM_BASE_NAMES_SET

        if self.lib_path:
            self.language = self._load_language("python")
            self.parser = Parser()
            try:
                self.parser.set_language(self.language)
            except Exception:
                self.parser.language = self.language
        else:
            from tree_sitter_language_pack import get_parser

            self.language = None
            self.parser = get_parser("python")

    # ---------- Version-agnostic loader ----------
    def _load_language(self, name: str) -> Language:
        """
        Load the Tree-sitter language from a compiled shared library, supporting multiple
        Python binding versions.

        Try in order:
          1) Language(ptr, name)   (≥ 0.22) where ptr = tree_sitter_{name}()
          2) Language(ptr)         (≈ 0.21)
          3) Language(path, name)  (very old fallback)
        """
        lib = cdll.LoadLibrary(os.fspath(self.lib_path))
        sym = f"tree_sitter_{name}"
        if not hasattr(lib, sym):
            raise RuntimeError(f"Symbol '{sym}' not found in {self.lib_path}")
        fn = getattr(lib, sym)

        # Modern: pointer + name
        try:
            fn.restype = c_void_p
            ptr = fn()
            return Language(ptr, name)
        except TypeError:
            # Mid: pointer only
            try:
                fn.restype = c_void_p
                ptr = fn()
                return Language(ptr)
            except TypeError:
                # Very old: path + name (deprecated, but keep as last resort)
                return Language(self.lib_path, name)

    # ---------- File parsing ----------
    def parse_file(self, file_path: str):
        """
        Parses the given file and returns:
          (tree, code, service_name, relative_file_path, file_name)

        relative_file_path is computed based on settings.ROOT_ESB_FOLDER_NAME.
        If that marker is missing, falls back to '/<file_name>'.
        """
        file_path = os.fspath(file_path)
        with open(file_path, "r", encoding="utf-8") as f:
            code = f.read()

        file_name = os.path.basename(file_path)

        # Normalize for cross-OS
        normalized_path = file_path.replace("\\", "/")
        root = getattr(settings, "ROOT_ESB_FOLDER_NAME", "")

        if root and root in normalized_path:
            after = normalized_path.split(root, 1)[1]
            relative_file_path = "/" + after.lstrip("/")
            trimmed = relative_file_path.strip("/")
            service_name = trimmed.split("/", 1)[0] if trimmed else ""
        else:
            relative_file_path = f"/{file_name}"
            service_name = ""

        tree = self.parser.parse(bytes(code, "utf8"))
        return tree, code, service_name, relative_file_path, file_name

    # ---------- Helpers ----------
    def node_text(self, code: str, node):
        return code[node.start_byte:node.end_byte]

    def find_child_of_type(self, node, type_name):
        for child in node.children:
            if child.type == type_name:
                return child
        return None

    def find_descendant(self, node, predicate):
        """Depth-first search for the first descendant matching a predicate."""
        stack = [node]
        while stack:
            cur = stack.pop()
            if predicate(cur):
                return cur
            stack.extend(reversed(cur.children))
        return None

    def _identifier_text(self, code: str, node):
        """
        Return text for an identifier or a dotted attribute (e.g., enum.Enum).
        Flattens 'attribute' chains to produce 'a.b.c' strings.
        """
        if node is None:
            return None
        if node.type == "identifier":
            return self.node_text(code, node)
        if node.type == "attribute":
            parts = []

            def collect(attr_node):
                if not attr_node.children:
                    return
                # Typically: [object, '.', attribute]
                obj = attr_node.children[0]
                name = attr_node.children[-1]
                if obj.type == "attribute":
                    collect(obj)
                elif obj.type == "identifier":
                    parts.append(self.node_text(code, obj))
                if name.type == "identifier":
                    parts.append(self.node_text(code, name))

            collect(node)
            return ".".join(parts) if parts else self.node_text(code, node)
        return self.node_text(code, node)

    def _dotted_name_text(self, code: str, node):
        """Return dotted_name or identifier text."""
        if node is None:
            return None
        if node.type in ("dotted_name", "identifier"):
            return self.node_text(code, node)
        # fallback
        return self._identifier_text(code, node)

    def _class_is_enum(self, code: str, class_node) -> bool:
        """
        Detect if a class node is an Enum by inspecting its base classes.
        In grammar, bases appear inside an 'argument_list' after '('.
        """
        arg_list = self.find_child_of_type(class_node, "argument_list")
        base_names = []

        def collect_bases(n):
            if n.type in ("identifier", "attribute", "dotted_name"):
                base_names.append(self._identifier_text(code, n))
            for ch in n.children:
                collect_bases(ch)

        if arg_list is not None:
            collect_bases(arg_list)
        else:
            # Heuristic fallback
            for ch in class_node.children:
                if ch.type in ("identifier", "attribute", "dotted_name"):
                    base_names.append(self._identifier_text(code, ch))

        base_names = [bn for bn in (bn.strip() if bn else None for bn in base_names) if bn]

        # NOTE: Keep original behavior: allow simple-name check for common Enum base names.
        # (This matches the original reference implementation.)
        enum_simple = {"Enum", "IntEnum", "StrEnum", "Flag", "IntFlag"}

        for bn in base_names:
            if bn in self.ENUM_BASE_NAMES or (bn.split(".")[-1] in enum_simple):
                return True
        return False

    def _compute_package_and_module(self, relative_file_path: str):
        """
        Infer Python package and module dotted names from the relative file path.

        Examples:
          /services/orders/api.py       -> package='services.orders', module='services.orders.api'
          /services/orders/__init__.py  -> package='services.orders', module='services.orders'
        """
        path = (relative_file_path or "").lstrip("/")
        if not path:
            return None, None
        if path.endswith(".py"):
            path_no_ext = path[:-3]
        else:
            path_no_ext = path

        parts = [p for p in path_no_ext.split("/") if p]
        if not parts:
            return None, None

        if parts[-1] == "__init__":
            package = ".".join(parts[:-1]) if len(parts) > 1 else ""
            module = package
        else:
            module = ".".join(parts)
            package = ".".join(parts[:-1]) if len(parts) > 1 else ""

        return package or None, module or None

    def _collect_import_names(self, node, code):
        """
        Collect import names from an import_list (or node containing one).
        Returns list of dicts: {"name": str, "alias": Optional[str]}
        """
        names = []

        def walk(n):
            if n.type == "aliased_import":
                # Typically: [<dotted_name|identifier>, 'as', <identifier>]
                name_node = None
                alias_node = None
                for ch in n.children:
                    if name_node is None and ch.type in ("dotted_name", "identifier"):
                        name_node = ch
                    elif ch.type == "identifier":
                        alias_node = ch
                names.append({
                    "name": self._dotted_name_text(code, name_node),
                    "alias": self.node_text(code, alias_node) if alias_node else None
                })
                return
            if n.type in ("dotted_name", "identifier"):
                names.append({"name": self._dotted_name_text(code, n), "alias": None})
                return
            for ch in n.children:
                walk(ch)

        if node is not None:
            walk(node)

        # De-duplicate
        dedup = []
        seen = set()
        for item in names:
            key = (item["name"], item["alias"])
            if key not in seen and item["name"]:
                seen.add(key)
                dedup.append(item)
        return dedup

    def _import_wildcard_present(self, node, code) -> bool:
        """
        Detect '*' in a from-import list without relying on a specific named node.
        We scan descendants and check raw token text.
        """
        if node is None:
            return False

        stack = [node]
        while stack:
            cur = stack.pop()
            # Many punctuation tokens are unnamed; check raw text slice
            text = self.node_text(code, cur)
            if text.strip() == "*":
                return True
            stack.extend(cur.children)
        return False

    # ---------- Chunk extraction ----------
    def extract_chunks(self, tree, code, service_name, relative_file_path, file_name):
        """
        Emits chunks for:
          - 'package': inferred from path (one per file)
          - 'import': import_statement / import_from_statement anywhere (configurable)
          - 'class': non-enum class_definition
          - 'enum': class_definition inheriting from Enum/IntEnum/StrEnum/Flag/IntFlag
          - 'constructor': __init__ / __new__ inside a class
          - 'method': other methods inside a class (decorated OK)
        """
        chunks = []
        root_node = tree.root_node

        # ----- PACKAGE CHUNK (once per file) -----
        package_name, module_name = self._compute_package_and_module(relative_file_path)
        if package_name or module_name:
            summary = f"Python package {package_name or '(root)'} (module {module_name})."
            chunks.append({
                "chunk_type": "package",
                "python_name": package_name or module_name,  # show best available
                "python_container": None,
                "file_name": file_name,
                "page_content": summary,
                "raw_code": "",
                "start_line": 1,
                "end_line": 1,
                "start_col": 0,
                "end_col": 0,
                "start_byte": 0,
                "end_byte": 0,
                "service_name": service_name,
                "relative_file_path": relative_file_path,
                "package_name": package_name,
                "module_name": module_name,
            })

        def summarize(chunk_type, name, current_class=None):
            parts = ["Python", chunk_type]
            if name:
                parts.append(name)
            if chunk_type in ("method", "constructor") and current_class:
                parts.append(f"in {current_class}")
            return " ".join(parts) + "."

        def extract_name_from_definition(def_node):
            name_node = self.find_child_of_type(def_node, "identifier")
            return self.node_text(code, name_node) if name_node else None

        # Track "depth" to optionally restrict imports to top-level
        def traverse(node, current_class=None, depth=0):
            # ----- IMPORTS -----
            if node.type in ("import_statement", "import_from_statement"):
                top_level_ok = (depth == 1)  # direct child of root
                if (not self.IMPORTS_TOP_LEVEL_ONLY) or top_level_ok:
                    raw_code = self.node_text(code, node)
                    import_module = None
                    import_names = []

                    if node.type == "import_statement":
                        import_list = self.find_child_of_type(node, "import_list") or node
                        import_names = self._collect_import_names(import_list, code)
                        disp = ", ".join(
                            n["name"] if n["alias"] is None else f"{n['name']} as {n['alias']}"
                            for n in import_names
                        ) or raw_code.strip()
                        pyname = f"import {disp}"
                    else:
                        # import_from_statement
                        module_node = self.find_child_of_type(node, "dotted_name")
                        if module_node is None:
                            # Could be relative import: 'from .. import X'
                            module_node = self.find_child_of_type(node, "relative_import")
                        import_module = (
                            self._dotted_name_text(code, module_node)
                            or (self.node_text(code, module_node) if module_node else None)
                        )

                        import_list = self.find_descendant(node, lambda n: n.type == "import_list")
                        if self._import_wildcard_present(node, code) and import_list is None:
                            # 'from X import *'
                            import_names = [{"name": "*", "alias": None}]
                            pyname = f"from {import_module} import *"
                        else:
                            import_names = self._collect_import_names(import_list or node, code)
                            names_s = ", ".join(
                                n["name"] if n["alias"] is None else f"{n['name']} as {n['alias']}"
                                for n in import_names
                            )
                            pyname = f"from {import_module} import {names_s}" if import_module else raw_code.strip()

                    chunks.append({
                        "chunk_type": "import",
                        "python_name": pyname,
                        "python_container": current_class,  # usually None unless import inside class
                        "file_name": file_name,
                        "page_content": f"Python import {pyname}.\n\n{raw_code}",
                        "raw_code": raw_code,
                        "start_line": node.start_point[0] + 1,
                        "end_line": node.end_point[0] + 1,
                        "start_col": node.start_point[1],
                        "end_col": node.end_point[1],
                        "start_byte": node.start_byte,
                        "end_byte": node.end_byte,
                        "service_name": service_name,
                        "relative_file_path": relative_file_path,
                        "import_module": import_module,
                        "import_names": import_names,
                    })
                # keep walking; nested imports collected too (unless you want to stop)

            # ----- CLASSES (and ENUM detection) -----
            if node.type == "class_definition":
                class_name = extract_name_from_definition(node)
                is_enum = self._class_is_enum(code, node)
                chunk_type = "enum" if is_enum else "class"
                raw_code = self.node_text(code, node)
                summary = summarize(chunk_type, class_name)

                chunks.append({
                    "chunk_type": chunk_type,
                    "python_name": class_name,
                    "python_container": None,
                    "file_name": file_name,
                    "page_content": summary + "\n\n" + raw_code,
                    "raw_code": raw_code,
                    "start_line": node.start_point[0] + 1,
                    "end_line": node.end_point[0] + 1,
                    "start_col": node.start_point[1],
                    "end_col": node.end_point[1],
                    "start_byte": node.start_byte,
                    "end_byte": node.end_byte,
                    "service_name": service_name,
                    "relative_file_path": relative_file_path,
                })

                for child in node.children:
                    traverse(child, current_class=class_name, depth=depth + 1)
                return  # handled class and its children

            # ----- METHODS / CONSTRUCTORS -----
            if node.type in ("function_definition", "async_function_definition"):
                if current_class:
                    func_name = extract_name_from_definition(node)
                    is_ctor = func_name in ("__init__", "__new__")
                    ctype = "constructor" if is_ctor else "method"

                    raw_code = self.node_text(code, node)
                    summary = summarize(ctype, func_name, current_class)

                    chunks.append({
                        "chunk_type": ctype,
                        "python_name": func_name,
                        "python_container": current_class,
                        "file_name": file_name,
                        "page_content": summary + "\n\n" + raw_code,
                        "raw_code": raw_code,
                        "start_line": node.start_point[0] + 1,
                        "end_line": node.end_point[0] + 1,
                        "start_col": node.start_point[1],
                        "end_col": node.end_point[1],
                        "start_byte": node.start_byte,
                        "end_byte": node.end_byte,
                        "service_name": service_name,
                        "relative_file_path": relative_file_path,
                    })
                    # Do not descend inside methods to avoid local function noise
                    return

            # ----- DECORATED METHODS (including constructors) -----
            if node.type == "decorated_definition" and current_class:
                inner = self.find_descendant(
                    node,
                    lambda n: n.type in ("function_definition", "async_function_definition"),
                )
                if inner:
                    func_name = extract_name_from_definition(inner)
                    is_ctor = func_name in ("__init__", "__new__")
                    ctype = "constructor" if is_ctor else "method"

                    raw_code = self.node_text(code, node)  # include decorators
                    summary = summarize(ctype, func_name, current_class)

                    chunks.append({
                        "chunk_type": ctype,
                        "python_name": func_name,
                        "python_container": current_class,
                        "file_name": file_name,
                        "page_content": summary + "\n\n" + raw_code,
                        "raw_code": raw_code,
                        "start_line": node.start_point[0] + 1,
                        "end_line": node.end_point[0] + 1,
                        "start_col": node.start_point[1],
                        "end_col": node.end_point[1],
                        "start_byte": node.start_byte,
                        "end_byte": node.end_byte,
                        "service_name": service_name,
                        "relative_file_path": relative_file_path,
                    })
                    return

            # ----- Default recursion -----
            for child in node.children:
                traverse(child, current_class=current_class, depth=depth + 1)

        # Start traversal. depth=1 means direct children of root are at depth 1.
        traverse(root_node, current_class=None, depth=0)
        return chunks

    def load(self, root_path: str) -> list:
        """Walk tree for ``.py`` files and extract chunks (same as other loaders)."""
        all_chunks: list = []
        for root, _, files in os.walk(root_path):
            for fname in files:
                if not fname.endswith(".py"):
                    continue
                fp = os.path.join(root, fname)
                try:
                    tree, code, service_name, relative_file_path, file_name = (
                        self.parse_file(fp)
                    )
                    file_chunks = self.extract_chunks(
                        tree, code, service_name, relative_file_path, file_name
                    )
                    for c in file_chunks:
                        c["_source_path"] = fp
                    all_chunks.extend(file_chunks)
                except Exception:
                    continue
        return all_chunks
