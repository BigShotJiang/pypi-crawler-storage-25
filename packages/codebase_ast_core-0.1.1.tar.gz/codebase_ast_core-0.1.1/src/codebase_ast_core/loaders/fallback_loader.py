import os
from codebase_ast_core.loaders.loader_settings import settings
import json
from typing import List, Dict
class NonJavaFileLoader:
    def load(self, root_path: str) -> List[Dict]:
        chunks: List[Dict] = []

        for root, _, files in os.walk(root_path):
            for file in files:
                full_path = os.path.join(root, file)

                try:
                    if file.endswith(".properties"):
                        file_chunks = self.load_properties_file(full_path)
                    elif file.endswith(".json"):
                        file_chunks = self.load_json_file(full_path)
                    elif file.endswith(".schema"):
                        file_chunks = self.load_json_schema_file(full_path)
                    else:
                        continue
                    for c in file_chunks:
                        c["_source_path"] = full_path
                    chunks.extend(file_chunks)
                except Exception:
                    continue

        return chunks

    def extract_common_metadata(self, source_path: str) -> Dict:
        relative_file_path = source_path.split(settings.ROOT_ESB_FOLDER_NAME, 1)[1]
        service_name = relative_file_path.strip("/").split("/")[0]

        return {
            "file_name": os.path.basename(source_path),
            "relative_file_path": f"/{relative_file_path}",
            "service_name": service_name,
        }


    def load_properties_file(self, path: str):
        chunks = []
        metadata = self.extract_common_metadata(path)
        with open(path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue

                if "=" not in line:
                    continue

                if "=" in line:
                    key, value = line.split("=", 1)
                    key = key.strip()
                    value = value.strip()
                    chunks.append({
                        **metadata,
                        "chunk_type": "properties",
                        "config_key": key.strip(),
                        "page_content": f"Property {key} is set to {value}.",
                    })
        return chunks
    
    def flatten_json(self, obj, parent_key=""):
        items = []
        if isinstance(obj, dict):
            for k, v in obj.items():
                new_key = f"{parent_key}.{k}" if parent_key else k
                items.extend(self.flatten_json(v, new_key))
        elif isinstance(obj, list):
            for i, v in enumerate(obj):
                items.extend(self.flatten_json(v, f"{parent_key}[{i}]"))
        else:
            items.append((parent_key, obj))
        return items
    
    def load_json_file(self, path: str):
        metadata = self.extract_common_metadata(path)
        chunks = []
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        
        for json_path, value in self.flatten_json(data):
            chunks.append({
                **metadata,
                "chunk_type": "json",
                "json_path": json_path,
                "page_content": f"Json value for {json_path} is {value}."
            })
        return chunks
    
    def load_json_schema_file(self, path: str):
        metadata = self.extract_common_metadata(path)
        chunks = []
        with open(path, encoding="utf-8") as f:
            schema = json.load(f)

        properties = schema.get("properties", {})

        for prop, definition in properties.items():
            description = definition.get("description", "")
            constraints = []

            for k, v in definition.items():
                if k != "description":
                    constraints.append(f"{k}={v}")

            constraint_text = ", ".join(constraints)

            chunks.append({
                **metadata,
                "chunk_type": "json.schema",
                "schema_property": prop,
                "page_content": (
                    f"Schema property {prop}. "
                    f"{description} "
                    f"Constraints: {constraint_text}."
                ).strip()
            })
        return chunks