"""HTML loader: extract chunks from .html/.htm (script, css, html_element)."""
from tree_sitter import Parser, Tree, Node, Language
import tree_sitter_html as tschtml
import os
import re
from typing import Optional
from codebase_ast_core.loaders.loader_settings import settings


class HtmlParser:
    HTML_EXTENSIONS = (".html", ".htm")

    # ---------- Parser initialization ----------
    def __init__(self):
        HTML_LANGUAGE = Language(tschtml.language())
        self.parser = Parser(HTML_LANGUAGE)
        self._semantic_tags = set(x.strip() for x in settings.HTML_SEMANTIC_TAGS.split(",") if x.strip())
        self._script_style_template_tags = {x.strip() for x in settings.HTML_SCRIPT_STYLE_TEMPLATE_TAGS.split(",") if x.strip()} - {"template"}
        self._tag_to_kind = {t: ("css" if t == "style" else t) for t in self._script_style_template_tags}

    # ---------- Parse file ----------
    def parse_file(
        self, file_path: str, app_root: str
    ) -> tuple[str, Optional[Tree], str, str]:
        file_path = os.fspath(file_path)
        with open(file_path, "r", encoding="utf-8", errors="replace") as f:
            code = f.read()
        file_name = os.path.basename(file_path)
        relative_file_path = self._relative_path(file_path, app_root)
        tree = self.parser.parse(code.encode("utf-8"))
        return code, tree, relative_file_path, file_name

    # ---------- Extract chunks ----------
    def extract_chunks(
        self,
        code: str,
        tree: Optional[Tree],
        relative_file_path: str,
        file_name: str,
    ) -> list[dict]:
        if tree is None or tree.root_node is None:
            return []
        return self._traverse(code, tree.root_node, relative_file_path, file_name)

    # ---------- Load files ----------
    def load(self, app_root: str) -> list[dict]:
        all_chunks = []
        for file_path in self._collect_files(app_root):
            code, tree, relative_file_path, file_name = self.parse_file(file_path, app_root)
            all_chunks.extend(
                self.extract_chunks(code, tree, relative_file_path, file_name)
            )
        return all_chunks

    # ---------- Node text ----------
    def _node_text(self, code_bytes: bytes, node: Optional[Node]) -> str:
        if not node:
            return ""
        return code_bytes[node.start_byte : node.end_byte].decode("utf-8", errors="replace")

    # ---------- Find child by type ----------
    def _find_child(self, node: Node, type_name: str) -> Optional[Node]:
        for i in range(node.child_count):
            c = node.child(i)
            if c.type == type_name:
                return c
        return None

    # ---------- Line at position (byte offset) ----------
    def _line_at(self, code_bytes: bytes, pos: int) -> int:
        return code_bytes[:pos].count(b"\n") + 1

    # ---------- Chunk ----------
    def _chunk(
        self,
        code_bytes: bytes,
        relative_file_path: str,
        file_name: str,
        chunk_type: str,
        name: str,
        start_byte: int,
        end_byte: int,
        page_content: str,
    ) -> dict:
        start_line = self._line_at(code_bytes, start_byte)
        end_line = self._line_at(code_bytes, end_byte)
        return {
            "chunk_type": chunk_type,
            "name": name,
            "file_name": file_name,
            "page_content": page_content,
            "start_line": start_line,
            "end_line": end_line,
            "relative_file_path": relative_file_path,
        }

    # ---------- Tag name from start_tag node ----------
    def _tag_name_from_start(self, code_bytes: bytes, start_tag: Node) -> str:
        text = self._node_text(code_bytes, start_tag).strip()
        match = re.match(r"<\s*([a-zA-Z][a-zA-Z0-9-]*)", text, re.IGNORECASE)
        return match.group(1).lower() if match else ""

    # ---------- Id attribute from start_tag text ----------
    def _id_from_start_tag(self, code_bytes: bytes, start_tag: Node) -> Optional[str]:
        text = self._node_text(code_bytes, start_tag)
        m = re.search(r'\bid\s*=\s*["\']([^"\']+)["\']', text, re.IGNORECASE)
        return m.group(1) if m else None

    # ---------- Src attribute from start_tag (for script) ----------
    def _src_from_start_tag(self, code_bytes: bytes, start_tag: Node) -> Optional[str]:
        text = self._node_text(code_bytes, start_tag)
        m = re.search(r'\bsrc\s*=\s*["\']([^"\']+)["\']', text, re.IGNORECASE)
        return m.group(1) if m else None

    # ---------- Collect files ----------
    def _collect_files(self, app_root: str) -> list[str]:
        out = []
        for root, _, files in os.walk(app_root):
            for f in files:
                if os.path.splitext(f)[1].lower() in self.HTML_EXTENSIONS:
                    out.append(os.path.join(root, f))
        return out

    # ---------- Relative path ----------
    def _relative_path(self, file_path: str, app_root: str) -> str:
        path = os.path.normpath(file_path)
        root = os.path.normpath(app_root)
        if path.startswith(root):
            path = path[len(root) :].lstrip(os.sep)
        return path.replace("\\", "/")

    # ---------- Traverse AST ----------
    def _traverse(
        self,
        code: str,
        node: Node,
        relative_file_path: str,
        file_name: str,
    ) -> list[dict]:
        chunks: list[dict] = []
        code_bytes = code.encode("utf-8")

        if node.type == "script_element":
            start_tag = self._find_child(node, "script_start_tag") or self._find_child(node, "start_tag")
            if start_tag:
                content = code_bytes[node.start_byte : node.end_byte].decode("utf-8", errors="replace")
                kind = self._tag_to_kind.get("script", "script")
                src = self._src_from_start_tag(code_bytes, start_tag)
                name = os.path.basename(src) if src else "script"
                chunks.append(
                    self._chunk(
                        code_bytes,
                        relative_file_path,
                        file_name,
                        kind,
                        name,
                        node.start_byte,
                        node.end_byte,
                        content.strip(),
                    )
                )
            return chunks

        if node.type == "style_element":
            content = code_bytes[node.start_byte : node.end_byte].decode("utf-8", errors="replace")
            kind = self._tag_to_kind.get("style", "css")
            chunks.append(
                self._chunk(
                    code_bytes,
                    relative_file_path,
                    file_name,
                    kind,
                    "style",
                    node.start_byte,
                    node.end_byte,
                    content.strip(),
                )
            )
            return chunks

        if node.type == "element":
            start_tag = self._find_child(node, "start_tag")
            if start_tag:
                tag_name = self._tag_name_from_start(code_bytes, start_tag)
                content = code_bytes[node.start_byte : node.end_byte].decode("utf-8", errors="replace")
                if tag_name == "script":
                    src = self._src_from_start_tag(code_bytes, start_tag)
                    name = os.path.basename(src) if src else "script"
                    chunks.append(
                        self._chunk(
                            code_bytes,
                            relative_file_path,
                            file_name,
                            "script",
                            name,
                            node.start_byte,
                            node.end_byte,
                            content.strip(),
                        )
                    )
                elif tag_name == "style":
                    chunks.append(
                        self._chunk(
                            code_bytes,
                            relative_file_path,
                            file_name,
                            "css",
                            "style",
                            node.start_byte,
                            node.end_byte,
                            content.strip(),
                        )
                    )
                elif tag_name in self._semantic_tags:
                    id_val = self._id_from_start_tag(code_bytes, start_tag)
                    if tag_name == "div":
                        name = id_val or "div"
                    elif id_val:
                        name = f"{tag_name}#{id_val}"
                    else:
                        name = tag_name
                    chunks.append(
                        self._chunk(
                            code_bytes,
                            relative_file_path,
                            file_name,
                            "html_element",
                            name,
                            node.start_byte,
                            node.end_byte,
                            content.strip(),
                        )
                    )

        for i in range(node.child_count):
            chunks.extend(
                self._traverse(
                    code,
                    node.child(i),
                    relative_file_path,
                    file_name,
                )
            )
        return chunks
