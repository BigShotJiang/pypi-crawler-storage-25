from tree_sitter import Parser, Tree, Node, Language
import tree_sitter_scss as tsscss
import os
from typing import Optional


class ScssParser:
    def __init__(self):
        SCSS_LANGUAGE = Language(tsscss.language())
        self.parser = Parser(SCSS_LANGUAGE)

    # ---------- Parse file ----------
    def parse_file(
        self, file_path: str, app_root: str
    ) -> tuple[str, Optional[Tree], str, str]:
        file_path = os.fspath(file_path)
        with open(file_path, "r", encoding="utf-8", errors="replace") as f:
            code = f.read()
        file_name = os.path.basename(file_path)
        relative_file_path = self._relative_path(file_path, app_root)
        tree = self.parser.parse(code.encode("utf-8"))
        return code, tree, relative_file_path, file_name

    # ---------- Extract chunks ----------
    def extract_chunks(
        self,
        code: str,
        tree: Optional[Tree],
        relative_file_path: str,
        file_name: str,
    ) -> list[dict]:
        if tree is None or tree.root_node is None:
            return []
        return self._traverse(code, tree.root_node, relative_file_path, file_name)

    # ---------- Load files ----------
    def load(self, app_root: str) -> list[dict]:
        all_chunks = []
        for file_path in self._collect_files(app_root):
            code, tree, relative_file_path, file_name = self.parse_file(file_path, app_root)
            all_chunks.extend(
                self.extract_chunks(code, tree, relative_file_path, file_name)
            )
        return all_chunks

    # ---------- Node text ----------
    def _node_text(self, code_bytes: bytes, node: Optional[Node]) -> str:
        if not node:
            return ""
        return code_bytes[node.start_byte : node.end_byte].decode("utf-8", errors="replace")

    # ---------- Find child by type ----------
    def _find_child(self, node: Node, type_name: str) -> Optional[Node]:
        for i in range(node.child_count):
            c = node.child(i)
            if c.type == type_name:
                return c
        return None

    # ---------- Line at position (byte offset) ----------
    def _line_at(self, code_bytes: bytes, pos: int) -> int:
        return code_bytes[:pos].count(b"\n") + 1

    # ---------- Chunk ----------
    def _chunk(
        self,
        code_bytes: bytes,
        relative_file_path: str,
        file_name: str,
        chunk_type: str,
        name: Optional[str],
        start_byte: int,
        end_byte: int,
        page_content: str,
    ) -> dict:
        start_line = self._line_at(code_bytes, start_byte)
        end_line = self._line_at(code_bytes, end_byte)
        out = {
            "chunk_type": chunk_type,
            "file_name": file_name,
            "page_content": page_content,
            "start_line": start_line,
            "end_line": end_line,
            "relative_file_path": relative_file_path,
        }
        if name is not None:
            out["name"] = name
        return out

    # ---------- Collect files ----------
    def _collect_files(self, app_root: str) -> list[str]:
        out = []
        for root, _, files in os.walk(app_root):
            for f in files:
                if os.path.splitext(f)[1].lower() == ".scss":
                    out.append(os.path.join(root, f))
        return out

    # ---------- Relative path ----------
    def _relative_path(self, file_path: str, app_root: str) -> str:
        path = os.path.normpath(file_path)
        root = os.path.normpath(app_root)
        if path.startswith(root):
            path = path[len(root) :].lstrip(os.sep)
        return path.replace("\\", "/")

    # ---------- Traverse AST ----------
    def _traverse(
        self,
        code: str,
        node: Node,
        relative_file_path: str,
        file_name: str,
    ) -> list[dict]:
        chunks: list[dict] = []
        code_bytes = code.encode("utf-8")

        if node.type == "mixin_statement":
            content = code_bytes[node.start_byte : node.end_byte].decode("utf-8", errors="replace")
            name_node = (node.child_by_field_name("name") if hasattr(node, "child_by_field_name") else None) or self._find_child(node, "identifier")
            name = self._node_text(code_bytes, name_node).strip() if name_node else "mixin"
            chunks.append(
                self._chunk(
                    code_bytes,
                    relative_file_path,
                    file_name,
                    "scss_mixin",
                    name,
                    node.start_byte,
                    node.end_byte,
                    content.strip(),
                )
            )
            return chunks

        if node.type == "include_statement":
            content = code_bytes[node.start_byte : node.end_byte].decode("utf-8", errors="replace")
            id_node = self._find_child(node, "identifier")
            name = self._node_text(code_bytes, id_node).strip() if id_node else "include"
            chunks.append(
                self._chunk(
                    code_bytes,
                    relative_file_path,
                    file_name,
                    "scss_include",
                    name,
                    node.start_byte,
                    node.end_byte,
                    content.strip(),
                )
            )
            return chunks

        if node.type == "function_statement":
            content = code_bytes[node.start_byte : node.end_byte].decode("utf-8", errors="replace")
            name_node = (node.child_by_field_name("name") if hasattr(node, "child_by_field_name") else None) or self._find_child(node, "identifier")
            name = self._node_text(code_bytes, name_node).strip() if name_node else "function"
            chunks.append(
                self._chunk(
                    code_bytes,
                    relative_file_path,
                    file_name,
                    "scss_function",
                    name,
                    node.start_byte,
                    node.end_byte,
                    content.strip(),
                )
            )
            return chunks

        if node.type == "declaration":
            prop = self._find_child(node, "property_name")
            if prop and self._node_text(code_bytes, prop).strip().startswith("$"):
                content = code_bytes[node.start_byte : node.end_byte].decode("utf-8", errors="replace")
                name = self._node_text(code_bytes, prop).strip().lstrip("$")
                chunks.append(
                    self._chunk(
                        code_bytes,
                        relative_file_path,
                        file_name,
                        "scss_variable",
                        name,
                        node.start_byte,
                        node.end_byte,
                        content.strip(),
                    )
                )
            return chunks

        if node.type == "use_statement":
            content = code_bytes[node.start_byte : node.end_byte].decode("utf-8", errors="replace")
            name = content.strip()[:60]
            chunks.append(
                self._chunk(
                    code_bytes,
                    relative_file_path,
                    file_name,
                    "scss_use",
                    name,
                    node.start_byte,
                    node.end_byte,
                    content.strip(),
                )
            )
            return chunks

        if node.type == "import_statement":
            content = code_bytes[node.start_byte : node.end_byte].decode("utf-8", errors="replace")
            name = content.strip()[:60]
            chunks.append(
                self._chunk(
                    code_bytes,
                    relative_file_path,
                    file_name,
                    "scss_import",
                    name,
                    node.start_byte,
                    node.end_byte,
                    content.strip(),
                )
            )
            return chunks

        if node.type == "media_statement":
            content = code_bytes[node.start_byte : node.end_byte].decode("utf-8", errors="replace")
            chunks.append(
                self._chunk(
                    code_bytes,
                    relative_file_path,
                    file_name,
                    "media_query",
                    None,
                    node.start_byte,
                    node.end_byte,
                    content.strip(),
                )
            )
            return chunks

        if node.type == "keyframes_statement":
            content = code_bytes[node.start_byte : node.end_byte].decode("utf-8", errors="replace")
            name = "keyframes"
            for i in range(node.child_count):
                c = node.child(i)
                if c.type in ("identifier", "keyframes_name"):
                    name = self._node_text(code_bytes, c).strip()
                    break
            chunks.append(
                self._chunk(
                    code_bytes,
                    relative_file_path,
                    file_name,
                    "keyframes",
                    name,
                    node.start_byte,
                    node.end_byte,
                    content.strip(),
                )
            )
            return chunks

        if node.type == "at_rule":
            at_keyword = self._find_child(node, "at_keyword")
            if at_keyword:
                kw = self._node_text(code_bytes, at_keyword).strip().lower()
                if kw == "@font-face":
                    content = code_bytes[node.start_byte : node.end_byte].decode(
                        "utf-8", errors="replace"
                    )
                    chunks.append(
                        self._chunk(
                            code_bytes,
                            relative_file_path,
                            file_name,
                            "font_face",
                            None,
                            node.start_byte,
                            node.end_byte,
                            content.strip(),
                        )
                    )
            return chunks

        if node.type == "rule_set":
            content = code_bytes[node.start_byte : node.end_byte].decode("utf-8", errors="replace")
            selectors_node = self._find_child(node, "selectors")
            name = "rule"
            if selectors_node:
                sel_text = self._node_text(code_bytes, selectors_node).strip()
                name = sel_text.split(",")[0].strip()[:80] or "rule"
                if name.startswith("%"):
                    name = name.lstrip("%")
            chunks.append(
                self._chunk(
                    code_bytes,
                    relative_file_path,
                    file_name,
                    "css_rule",
                    name,
                    node.start_byte,
                    node.end_byte,
                    content.strip(),
                )
            )
            return chunks

        for i in range(node.child_count):
            chunks.extend(
                self._traverse(
                    code,
                    node.child(i),
                    relative_file_path,
                    file_name,
                )
            )
        return chunks
