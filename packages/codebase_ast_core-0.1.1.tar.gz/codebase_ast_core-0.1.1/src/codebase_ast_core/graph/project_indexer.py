"""Incremental indexing for efficient database updates when code changes."""

import difflib
import json
from pathlib import Path
from typing import Any, Dict, List, Optional, Set

from loguru import logger

from codebase_ast_core.embeddings import get_embedding_engine
from codebase_ast_core.graph.backend_factory import get_connection, get_converter, get_graph_operations
from codebase_ast_core.indexer.ast_parser import ASTParser
from codebase_ast_core.models.schema import ExtractionData, FileData
from codebase_ast_core.utils.console import console
from codebase_ast_core.utils.file_utils import get_extraction_file_path, get_last_extraction_file_path
from codebase_ast_core.utils.hash_utils import compute_directory_hashes
from codebase_ast_core.utils.helpers import load_json_file
from codebase_ast_core.utils.json_serializer import make_json_serializable


class ProjectIndexer:
    """
    Handles all project indexing operations - both full and incremental.
    Provides unified interface for parsing, storing to SQL, and generating embeddings.
    """

    def __init__(
        self,
        sutra_memory_manager=None,
    ):
        """Initialize with optional shared memory manager."""
        self.connection = get_connection()
        self.converter = get_converter()
        self.graphOperations = get_graph_operations()
        self.graph_ops = get_graph_operations()
        self.embedding_engine = get_embedding_engine()

        # Use provided memory manager or create new one (lazy import to avoid circular imports)
        if sutra_memory_manager:
            self.sutra_memory = sutra_memory_manager
        else:
            try:
                from services.agent.memory_management import SutraMemoryManager
                self.sutra_memory = SutraMemoryManager()
            except ImportError:
                self.sutra_memory = None  # Standalone: no agent memory
        logger.debug("🔄 ProjectIndexer initialized")

    def full_index_project(self, project_name: str, project_path: Path) -> None:
        """Perform complete indexing of a project from scratch.

        This includes:
        1. Parsing the entire repository
        2. Storing all data to SQL tables
        3. Generating embeddings for all files and blocks

        Args:
            project_name: Name of the project
            project_path: Path to the project directory
        """
        try:
            console.print(f"[!] Project '{project_name}' not found in database")
            console.print("[*] Starting automatic indexing...")
            console.print(
                "   This will analyze the codebase and generate embeddings for better responses."
            )
            console.print("   Please wait while the project is being indexed...\n")

            parser_output_path = self._parse_repository(project_name, project_path)

            self._store_to_database(parser_output_path, project_name, project_path)

            # Step 2: Generate embeddings for the stored data
            console.print("   Step 2: Generating embeddings for semantic search...")
            self._generate_embeddings_for_project(parser_output_path, project_name)

            console.print("\n[OK] Project indexing completed successfully!")
            console.print(
                "   The agent is now ready to provide intelligent assistance.\n"
            )

        except Exception as e:
            logger.error(f"Error during full indexing: {e}")
            console.print(f"[X] Full indexing failed: {e}")
            console.print("   Continuing with limited functionality.")
            raise

    def incremental_index_project(self, project_name: str) -> Dict[str, Any]:
        """Perform incremental indexing by updating only changed files.

        This function performs incremental parsing for a project by:
        1. Detecting changes using detect_project_changes (computes hashes and compares)
        2. Fetching old content from database BEFORE updating (for diff generation)
        3. Parsing only changed files using the indexer
        4. Replacing changed files in previous extraction result and saving new file
        5. Recomputing relationships for changed files only
        6. Updating the database by deleting old data and inserting new data

        Args:
            project_name: Name of the project/codebase

        Returns:
            Dictionary with update statistics including changes and diffs
        """
        logger.debug(f"🔄 Starting incremental reindexing for project: {project_name}")

        try:
            # Get project and validate
            project = self.connection.get_project(project_name=project_name)
            if not project:
                logger.error(f"Project not found: {project_name}")
                return {
                    "status": "failed",
                    "error": f"Project not found: {project_name}",
                    "changes": {
                        "changed_files": set(),
                        "new_files": set(),
                        "deleted_files": set(),
                    },
                    "old_content": {},
                }

            project_id = project.id
            project_dir = Path(project.path)
            if not project_dir.exists():
                logger.error(f"Project directory does not exist: {project_dir}")
                return {
                    "status": "failed",
                    "error": f"Project directory does not exist: {project_dir}",
                    "changes": {
                        "changed_files": set(),
                        "new_files": set(),
                        "deleted_files": set(),
                    },
                    "old_content": {},
                }

            # Step 1: Detect changes (computes hashes, compares with DB, identifies changes)
            logger.debug(f"📊 Detecting changes for project: {project_name}")
            changes = self.detect_project_changes(project_dir, project_name)

            # If no changes, return early
            if not any(changes.values()):
                logger.debug("✅ No changes detected, skipping reindexing")
                return {
                    "status": "success",
                    "changes": changes,
                    "old_content": {},
                }

            # Step 2: Fetch old content from database BEFORE updating (for diff generation)
            logger.debug(
                f"📦 Fetching old content from database for changed/deleted files"
            )
            old_content_map = self._fetch_old_content_for_changes(
                changes, project_id, project_dir
            )

            # Step 3: Parse changed files and update extraction results
            logger.debug(f"🔄 Parsing changed files and updating extraction results")
            updated_extraction_file = self._parse_and_update_extraction_results(
                changes, project_name
            )

            # Step 4: Load the updated extraction data and convert to database format
            logger.debug(
                f"📦 Loading updated extraction data from: {updated_extraction_file}"
            )
            json_data = load_json_file(updated_extraction_file)
            extraction_data = ExtractionData(**json_data)

            # Step 5: Process changes in database (delete old, insert new)
            self._process_database_changes(
                changes, extraction_data, project_id, project_name
            )

            # Step 6: Update Sutra memory for file changes
            self._update_sutra_memory_for_changes(changes, project_id)

            logger.debug(f"✅ Incremental reindexing completed successfully!")
            return {
                "status": "success",
                "changes": changes,
                "old_content": old_content_map or {},
                "project_dir": project_dir,
            }

        except Exception as e:
            logger.error(f"Incremental reindexing failed: {e}")
            return {
                "status": "failed",
                "error": str(e),
                "changes": {
                    "changed_files": set(),
                    "new_files": set(),
                    "deleted_files": set(),
                },
                "old_content": {},
            }

    def _get_project_id(self, project_name: str) -> Optional[int]:
        """Get project ID from project name."""
        try:
            result = self.connection.execute_query(
                "SELECT id FROM projects WHERE name = ?", (project_name,)
            )
            return result[0]["id"] if result else None
        except Exception as e:
            logger.error(f"Error getting project ID: {e}")
            return None

    def _compute_current_file_hashes(self, project_dir: Path) -> Dict[Path, str]:
        """
        Compute current file content hashes for all files in the project directory.
        Uses the indexer's compute_directory_hashes function.

        Args:
            project_dir: Path to the project directory

        Returns:
            Dictionary mapping absolute file Path objects to their content hashes
        """
        try:
            file_hashes = compute_directory_hashes(project_dir)
            logger.debug(f"📊 Computed hashes for {len(file_hashes)} files")
            return file_hashes

        except Exception as e:
            logger.error(f"Error computing current file hashes: {e}")
            return {}

    def _identify_file_changes(
        self, current_hashes: Dict[Path, str], db_hashes: Dict[Path, str]
    ) -> Dict[str, Set[Path]]:
        """
        Identify changed, new, and deleted files by comparing file hashes.

        Args:
            current_hashes: Current file hashes from project directory
            db_hashes: File hashes stored in database

        Returns:
            Dictionary with sets of changed_files, new_files, and deleted_files (all Path objects)
        """
        changed_files = set()
        new_files = set()

        # Check each current file
        for file_path, current_hash in current_hashes.items():
            if file_path in db_hashes:
                if db_hashes[file_path] != current_hash:
                    # File exists but hash changed (modified)
                    changed_files.add(file_path)
            else:
                # File doesn't exist in database (new)
                new_files.add(file_path)

        # Identify deleted files (in DB but not in current directory)
        deleted_files = set(db_hashes.keys()) - set(current_hashes.keys())

        return {
            "changed_files": changed_files,
            "new_files": new_files,
            "deleted_files": deleted_files,
        }

    def detect_project_changes(self, project_path: Path, project_name: str):
        """
        Detect changes in a project without running full incremental indexing.
        Args:
            project_path: Path to the project directory
            project_name: Name of the project

        Returns:
            Dictionary with sets of changed_files, new_files, and deleted_files
        """
        try:
            current_hashes = self._compute_current_file_hashes(project_path)

            # Get project from database
            project = self.connection.get_project(project_name)
            if not project:
                logger.warning(f"Project {project_name} not found in database")
                return {
                    "changed_files": set(),
                    "new_files": set(),
                    "deleted_files": set(),
                }

            db_hashes = self._get_db_file_hashes(project.id)
            # Normalize both to resolved paths so path format (slashes, case) does not hide changes
            current_canonical = {p.resolve(): h for p, h in current_hashes.items()}
            db_canonical = {p.resolve(): h for p, h in db_hashes.items()}
            changes = self._identify_file_changes(current_canonical, db_canonical)
            return changes

        except Exception as e:
            logger.error(f"Error detecting changes for project {project_name}: {e}")
            # Return empty changes on error
            return {
                "changed_files": set(),
                "new_files": set(),
                "deleted_files": set(),
            }

    def _parse_and_update_extraction_results(
        self, changes: Dict[str, Set[Path]], project_name: str
    ) -> Path:
        """
        Parse changed files and update extraction results.

        This function:
        1. Loads previous extraction results
        2. Parses only changed/new files
        3. Replaces changed files in previous results
        4. Saves updated results to a new file with timestamp

        Args:
            changes: Dictionary containing changed_files, new_files, deleted_files
            project_dir: Path to the project directory
            project_name: Name of the project

        Returns:
            Path to the updated extraction file
        """
        from datetime import datetime

        try:
            # Get the most recent extraction file
            previous_extraction_file = get_last_extraction_file_path(project_name)

            # Load previous results if available
            previous_extraction_data = None
            if previous_extraction_file and previous_extraction_file.exists():
                logger.debug(
                    f"📦 Loading previous extraction results from: {previous_extraction_file}"
                )
                json_data = load_json_file(previous_extraction_file)
                previous_extraction_data = ExtractionData(**json_data)
                logger.debug(
                    f"📦 Loaded {len(previous_extraction_data.files)} files from previous results"
                )
            else:
                logger.debug("📦 No previous extraction results found, starting fresh")
                # Create empty extraction data
                previous_extraction_data = ExtractionData(
                    metadata={
                        "export_timestamp": datetime.now().isoformat(),
                        "total_files": 0,
                        "extractor_version": "1.0.0",
                    },
                    files={},
                )

            # Start with previous files as base
            updated_files = previous_extraction_data.files.copy()

            # Remove deleted files from results
            for deleted_file in changes["deleted_files"]:
                deleted_file_str = str(deleted_file)
                if deleted_file_str in updated_files:
                    del updated_files[deleted_file_str]
                    logger.debug(
                        f"🗑️  Removed deleted file from results: {deleted_file}"
                    )

            # Get all changed and new files that need parsing
            files_to_parse = list(changes["changed_files"].union(changes["new_files"]))

            if files_to_parse:
                logger.debug(f"🔄 Parsing {len(files_to_parse)} changed/new files")

                # Parse each changed file individually using the existing parse_and_extract method
                parser = ASTParser()
                parsed_results = {}

                for file_path in files_to_parse:
                    try:
                        # file_path is already a Path object from compute_directory_hashes
                        # Parse and extract from this single file
                        result = parser.parse_and_extract(file_path)

                        if result.get("ast") or result.get("error"):
                            # Use string representation for results dict (consistent with existing format)
                            file_path_str = str(file_path)
                            parsed_results[file_path_str] = result
                            # logger.debug(f"✅ Parsed file: {file_path}")
                    except Exception as e:
                        logger.error(f"Error parsing file {file_path}: {e}")
                        continue

                # Extract relationships for the changed files
                if parsed_results:
                    logger.debug(
                        f"🔗 Extracting relationships for {len(files_to_parse)} changed files"
                    )

                    # Create ID to path mapping for all files (needed for relationship resolution)
                    id_to_path = {}
                    for file_path_str, result in parsed_results.items():
                        file_id = result.get("id")
                        if file_id:
                            id_to_path[file_id] = file_path_str

                    # Process relationships only for the changed files
                    parser.process_relationships(parsed_results, id_to_path)

                # Helper function to serialize CodeBlock objects with proper enum handling
                def serialize_block(block):
                    """Convert CodeBlock to dict with proper enum serialization."""
                    if hasattr(block, "model_dump"):
                        # Use model_dump with mode='json' to properly serialize enums
                        return block.model_dump(mode="json")
                    elif hasattr(block, "dict"):
                        block_dict = block.dict()
                        # Manually convert enum to string if needed
                        if hasattr(block_dict.get("type"), "value"):
                            block_dict["type"] = block_dict["type"].value
                        return block_dict
                    else:
                        return block

                # Convert parsed results to FileData objects and update the files dict
                for file_path_str, result in parsed_results.items():
                    file_data = FileData(
                        id=result["id"],
                        file_path=file_path_str,
                        language=result["language"],
                        content=result["content"],
                        content_hash=result["content_hash"],
                        blocks=[serialize_block(block) for block in result["blocks"]],
                        relationships=result.get("relationships", []),
                        unsupported=result.get("unsupported", False),
                    )
                    updated_files[file_path_str] = file_data
                    # logger.debug(f"✅ Updated FileData for: {file_path_str}")

            # Create updated extraction data
            updated_extraction_data = ExtractionData(
                metadata={
                    "export_timestamp": datetime.now().isoformat(),
                    "total_files": len(updated_files),
                    "extractor_version": "1.0.0",
                },
                files=updated_files,
            )

            # Save the complete updated results to a new file
            output_file = get_extraction_file_path(project_name)
            logger.debug(f"💾 Saving updated extraction results to: {output_file}")

            serializable_data = make_json_serializable(updated_extraction_data.dict())

            with open(output_file, "w", encoding="utf-8") as f:
                json.dump(serializable_data, f, indent=2, ensure_ascii=False)

            logger.debug(
                f"✅ Successfully saved {len(updated_files)} files to extraction results"
            )
            return output_file

        except Exception as e:
            logger.error(f"Error parsing and updating extraction results: {e}")
            raise

    def _get_db_file_hashes(self, project_id: int) -> Dict[Path, str]:
        """Get all file hashes from the database for a project. Keys are normalized with resolve() for reliable comparison."""
        try:
            file_hashes_dict = self.graph_ops.get_db_file_hashes(project_id)

            file_hashes = {}
            for file_path_str, content_hash in file_hashes_dict.items():
                if not file_path_str:
                    continue
                # Normalize to resolved path so comparison with current_hashes (also resolved) matches
                try:
                    resolved = Path(file_path_str).resolve()
                    file_hashes[resolved] = content_hash or ""
                except (OSError, RuntimeError):
                    file_hashes[Path(file_path_str)] = content_hash or ""

            logger.debug(f"📊 Retrieved {len(file_hashes)} file hashes from database")
            return file_hashes
        except Exception as e:
            logger.error(f"Error getting file hashes from database: {e}")
            return {}

    def _process_database_changes(
        self,
        changes: Dict[str, Set[Path]],
        extraction_data: ExtractionData,
        project_id: int,
        project_name: str,
    ) -> Dict[str, int]:
        """Process identified changes by deleting and adding nodes and relationships."""
        # Initialize counters
        nodes_deleted = 0
        relationships_deleted = 0
        nodes_added = 0
        relationships_added = 0

        # Process changed and deleted files (delete their nodes and relationships)
        files_to_delete = changes["changed_files"].union(changes["deleted_files"])
        preserved_connections_list = []

        for file_path in files_to_delete:
            # Convert Path to string for database operations
            file_path_str = str(file_path)
            deleted = self._delete_files_and_embeddings(file_path_str, project_id)
            nodes_deleted += deleted["nodes"]
            relationships_deleted += deleted["relationships"]

            # Collect preserved connections for later restoration
            if "preserved_connections" in deleted:
                preserved_connections_list.append(deleted["preserved_connections"])

        # Process changed and new files (add their nodes and relationships)
        files_to_add = changes["changed_files"].union(changes["new_files"])
        if files_to_add:
            logger.debug(
                f"🔄 Processing {len(files_to_add)} changed/new files for database insertion"
            )

            # Create a filtered extraction data with only the changed/new files
            filtered_files = {}
            for file_path in files_to_add:
                # Convert Path to string to match extraction_data.files keys
                file_path_str = str(file_path)
                if file_path_str in extraction_data.files:
                    filtered_files[file_path_str] = extraction_data.files[file_path_str]

            if filtered_files:
                # Create filtered extraction data
                filtered_extraction_data = ExtractionData(
                    metadata=extraction_data.metadata, files=filtered_files
                )

                # Insert the filtered data using graph operations
                logger.debug(f"📦 Inserting {len(filtered_files)} files into database")
                self.graphOperations.insert_extraction_data(
                    filtered_extraction_data, project_id
                )

                # Count nodes and relationships added
                for file_data in filtered_files.values():
                    nodes_added += len(file_data.blocks)
                    relationships_added += len(file_data.relationships)

                # Generate embeddings for changed file nodes
                self._generate_embeddings_for_changed_files(
                    list(filtered_files.values()), project_id, project_name
                )

                # Restore preserved connections after files are recreated
                self._restore_preserved_connections(preserved_connections_list)
        else:
            # Even if no files are being added, we might need to restore connections for deleted files
            if preserved_connections_list:
                logger.debug("Restoring preserved connections for deleted files")
                self._restore_preserved_connections(preserved_connections_list)

        logger.debug(
            f"📊 Processed changes: {nodes_deleted} nodes deleted, {relationships_deleted} relationships deleted"
        )
        logger.debug(
            f"📊 Processed changes: {nodes_added} nodes added, {relationships_added} relationships added"
        )

        return {
            "nodes_deleted": nodes_deleted,
            "relationships_deleted": relationships_deleted,
            "nodes_added": nodes_added,
            "relationships_added": relationships_added,
        }

    def _delete_files_and_embeddings(
        self, file_path: str, project_id: int
    ) -> Dict[str, Any]:
        """Delete all nodes and relationships for a specific file.

        Returns:
            Dictionary with:
                - nodes: Number of nodes deleted
                - relationships: Number of relationships deleted
                - preserved_connections: Optional dict with connection data to restore later
        """
        try:
            # First get the file ID
            file_result = self.connection.execute_query(
                "SELECT id FROM files WHERE project_id = ? AND file_path = ?",
                (project_id, file_path),
            )

            if not file_result:
                logger.warning(f"File not found in database: {file_path}")
                return {"nodes": 0, "relationships": 0}

            # Get the raw integer ID for database operations
            raw_file_id = file_result[0]["id"]

            # Format ID with prefix for embeddings
            prefixed_file_id = f"file_{raw_file_id}"

            # Get all code block IDs for this file
            block_results = self.connection.execute_query(
                "SELECT id FROM code_blocks WHERE file_id = ?",
                (raw_file_id,),
            )
            # Format block IDs with prefix for embeddings
            prefixed_block_ids = [f"block_{row['id']}" for row in block_results]

            # Combine prefixed IDs for embedding deletion
            prefixed_node_ids = [prefixed_file_id] + prefixed_block_ids

            # Delete embeddings first (if they exist)
            if prefixed_node_ids:
                self._delete_embeddings(prefixed_node_ids, project_id)

            # Count relationships before deletion
            rel_count = self.connection.execute_query(
                """SELECT COUNT(*) as count FROM relationships
                   WHERE source_id = ? OR target_id = ?""",
                (raw_file_id, raw_file_id),
            )
            relationships_count = rel_count[0]["count"] if rel_count else 0

            # Preserve connections before deleting the file
            # Get all connections for this file
            incoming_connections = self.connection.execute_query(
                "SELECT * FROM incoming_connections WHERE file_id = ?",
                (raw_file_id,),
            )
            outgoing_connections = self.connection.execute_query(
                "SELECT * FROM outgoing_connections WHERE file_id = ?",
                (raw_file_id,),
            )

            # Preserve relationship rows (imports graph) so impact report stays complete after re-insert.
            # The relationships table has no FK to files, so these rows survive file delete; we still
            # preserve them so we can re-insert with new file_id if the re-inserted file gets a different id.
            relationship_rows = self.connection.execute_query(
                """SELECT source_id, target_id, import_content, symbols, type FROM relationships
                   WHERE source_id = ? OR target_id = ?""",
                (raw_file_id, raw_file_id),
            )

            incoming_count = len(incoming_connections) if incoming_connections else 0
            outgoing_count = len(outgoing_connections) if outgoing_connections else 0
            relationship_count = len(relationship_rows) if relationship_rows else 0

            if incoming_count > 0 or outgoing_count > 0:
                logger.debug(
                    f"🔄 Preserving {incoming_count} incoming and {outgoing_count} outgoing connections "
                    f"for file {file_path} during incremental indexing"
                )
            if relationship_count > 0:
                logger.debug(
                    f"🔄 Preserving {relationship_count} relationship rows for file {file_path} during incremental indexing"
                )

            # Delete relationship rows that reference this file (so we can restore with correct file_id later).
            # Relationship rows are not tied to files with a cascading delete; remove them explicitly.
            self.connection.execute_query(
                "DELETE FROM relationships WHERE source_id = ? OR target_id = ?",
                (raw_file_id, raw_file_id),
            )

            # Delete the file (CASCADE DELETE will clean up code_blocks, incoming_connections, outgoing_connections)
            self.connection.execute_query(
                "DELETE FROM files WHERE id = ?",
                (raw_file_id,),
            )

            # Store preserved connections and relationships for later restoration after file recreation
            preserved_connections = {
                "incoming": incoming_connections or [],
                "outgoing": outgoing_connections or [],
                "relationships": relationship_rows or [],
                "file_id": raw_file_id,
                "file_path": file_path,
                "project_id": project_id,
            }

            # Return deletion counts and preserved connections
            return {
                "nodes": len(prefixed_node_ids),  # File + code blocks
                "relationships": relationships_count,
                "preserved_connections": preserved_connections,
            }

        except Exception as e:
            logger.error(f"Error deleting nodes for file {file_path}: {e}")
            return {"nodes": 0, "relationships": 0}

    def _delete_embeddings(self, node_ids: List[str], project_id: int) -> None:
        """Delete embeddings for specified nodes. Node IDs should already include prefixes (file_ or block_)."""
        self.embedding_engine.delete_embeddings(node_ids, project_id)

    def _restore_preserved_connections(
        self, preserved_connections_list: List[Dict]
    ) -> None:
        """Restore preserved connections and relationships after files are recreated.

        Resolves the new file_id by path and project_id (re-inserted file may have a different id)
        and uses it for all restored rows so the impact report (importers / dependency chain) stays complete.
        """
        try:
            total_restored = 0

            for preserved_data in preserved_connections_list:
                old_file_id = preserved_data["file_id"]
                file_path = preserved_data["file_path"]
                project_id = preserved_data.get("project_id")
                incoming_connections = preserved_data.get("incoming") or []
                outgoing_connections = preserved_data.get("outgoing") or []
                relationship_rows = preserved_data.get("relationships") or []

                # Resolve new file_id (re-inserted file may have same or different id)
                new_file_id = old_file_id
                if project_id is not None:
                    file_result = self.connection.execute_query(
                        "SELECT id FROM files WHERE project_id = ? AND file_path = ?",
                        (project_id, file_path),
                    )
                    if file_result:
                        new_file_id = file_result[0]["id"]

                incoming_count = len(incoming_connections)
                outgoing_count = len(outgoing_connections)
                rel_count = len(relationship_rows)

                if incoming_count > 0 or outgoing_count > 0:
                    logger.debug(
                        f"🔄 Restoring {incoming_count} incoming and {outgoing_count} outgoing connections "
                        f"for file {file_path} (new file_id: {new_file_id})"
                    )

                # Restore incoming connections using new file_id
                for conn in incoming_connections:
                    self.connection.execute_query(
                        """INSERT INTO incoming_connections
                           (description, file_id, start_line, end_line, technology_name, code_snippet, created_at)
                           VALUES (?, ?, ?, ?, ?, ?, ?)""",
                        (
                            conn["description"],
                            new_file_id,
                            conn["start_line"],
                            conn["end_line"],
                            conn["technology_name"],
                            conn["code_snippet"],
                            conn["created_at"],
                        ),
                    )
                    total_restored += 1

                # Restore outgoing connections using new file_id
                for conn in outgoing_connections:
                    self.connection.execute_query(
                        """INSERT INTO outgoing_connections
                           (description, file_id, start_line, end_line, technology_name, code_snippet, created_at)
                           VALUES (?, ?, ?, ?, ?, ?, ?)""",
                        (
                            conn["description"],
                            new_file_id,
                            conn["start_line"],
                            conn["end_line"],
                            conn["technology_name"],
                            conn["code_snippet"],
                            conn["created_at"],
                        ),
                    )
                    total_restored += 1

                # Restore relationship rows (import graph) so get_importers / dependency chain stay complete
                if rel_count > 0:
                    logger.debug(
                        f"🔄 Restoring {rel_count} relationship rows for file {file_path} (old_id={old_file_id} -> new_id={new_file_id})"
                    )
                for rel in relationship_rows:
                    src = rel["source_id"]
                    tgt = rel["target_id"]
                    new_src = new_file_id if src == old_file_id else src
                    new_tgt = new_file_id if tgt == old_file_id else tgt
                    self.connection.execute_query(
                        """INSERT OR IGNORE INTO relationships (source_id, target_id, import_content, symbols, type)
                           VALUES (?, ?, ?, ?, ?)""",
                        (
                            new_src,
                            new_tgt,
                            rel["import_content"],
                            rel["symbols"],
                            rel.get("type") or "import",
                        ),
                    )
                    total_restored += 1

            if total_restored > 0:
                logger.debug(
                    f"✅ Successfully restored {total_restored} connections/relationships after file recreation"
                )

        except Exception as e:
            logger.error(f"Error restoring preserved connections: {e}")
            # Don't raise the exception as this shouldn't fail the entire indexing process

    def _update_sutra_memory_for_changes(
        self, changes: Dict[str, Set[Path]], project_id: int
    ) -> Dict[str, Any]:
        """
        Update Sutra memory when files change during incremental indexing.

        Args:
            changes: Dictionary containing changed_files, new_files, and deleted_files
            project_id: Project ID for database queries

        Returns:
            Dictionary with memory update statistics
        """
        try:
            logger.debug("🧠 Updating Sutra memory for file changes...")

            # Call the memory updater to handle the changes
            memory_updates = self.sutra_memory.update_memory_for_file_changes(
                changed_files=changes["changed_files"],
                deleted_files=changes["deleted_files"],
                project_id=project_id,
            )

            if (
                memory_updates["codes_updated"] > 0
                or memory_updates["codes_removed"] > 0
            ):
                logger.debug(
                    f"🧠 Sutra memory updated: "
                    f"{memory_updates['codes_updated']} codes updated, "
                    f"{memory_updates['codes_removed']} codes removed, "
                    f"{memory_updates['files_processed']} files processed"
                )
            else:
                logger.debug("🧠 No Sutra memory updates required")

            return memory_updates

        except Exception as e:
            logger.error(f"Error updating Sutra memory: {e}")
            return {
                "codes_updated": 0,
                "codes_removed": 0,
                "line_number_updates": 0,
                "content_updates": 0,
                "files_processed": 0,
                "error": str(e),
            }

    def _generate_embeddings_for_changed_files(
        self, changed_file_data: List[FileData], project_id: int, project_name: str
    ) -> None:
        """Generate strategic embeddings for changed file data and their code blocks."""
        try:
            # Use the new strategic embedding engine
            stats = self.embedding_engine.process_multiple_files(
                changed_file_data, project_id
            )
            logger.debug(
                f"Generated embeddings for {len(changed_file_data)} changed files: "
                f"{stats['total_chunks']} total chunks, "
                f"{stats['blocks_processed']} blocks processed"
            )

        except Exception as e:
            logger.error(f"Error generating embeddings for changed files: {e}")

    def _parse_repository(self, project_name: str, project_path: Path) -> Path:
        """Parse the entire repository and return path to extraction file."""
        try:
            console.print(f"[*] Parsing directory: {project_path}")

            from codebase_ast_core.config import config

            output_dir = Path(config.storage.parser_results_dir)
            output_dir.mkdir(parents=True, exist_ok=True)

            import time

            timestamp = time.strftime("%Y%m%d_%H%M%S")
            parser_output_path = Path(
                output_dir / f"{project_name}_{timestamp}.json"
            ).absolute()

            # Use the indexer to extract and export directory data
            from indexer import extract_and_export_directory

            success = extract_and_export_directory(
                dir_path=project_path, output_file=parser_output_path, indent=2
            )

            if not success:
                raise Exception(f"Failed to parse repository: {project_name}")

            console.print("[OK] Repository parsed successfully")
            logger.debug(f"   Generated analysis for project: {project_name}")
            logger.debug(f"   Output file: {parser_output_path}")

            return parser_output_path

        except Exception as e:
            logger.error(f"Parser error: {e}")
            console.print(f"[X] Failed to parse repository: {e}")
            raise

    def _store_to_database(
        self, parser_output_path: Path, project_name: str, project_path: Path
    ) -> Dict[str, Any]:
        """Store parsed data to SQL tables."""
        # Convert to database - returns stats dict or raises exception
        stats = self.converter.convert_json_to_graph(
            json_file_path=parser_output_path,
            project_path=project_path,
            project_name=project_name,
            clear_existing=False,
        )

        return stats

    def _generate_embeddings_for_project(
        self, parser_output_path: Path, project_name: str
    ):
        """Generate embeddings for all files in the project."""
        # Get project from database
        project = self.connection.get_project(project_name)
        if not project:
            raise Exception(
                f"Project '{project_name}' not found in database after SQL storage"
            )
        project_id = project.id

        # Load the parsed data for embedding generation
        from codebase_ast_core.utils import load_json_file

        json_data = load_json_file(parser_output_path)
        # ExtractionData already imported at top

        extraction_data = ExtractionData(**json_data)

        # Generate embeddings using the embedding engine
        # Convert dictionary to list of FileData objects
        file_data_list = list(extraction_data.files.values())
        embedding_stats = self.embedding_engine.process_multiple_files(
            file_data_list, project_id
        )

        console.print("   [OK] Embeddings generated successfully!")
        console.print(f"      Files processed: {embedding_stats['files_processed']}")
        console.print(f"      Total chunks: {embedding_stats['total_chunks']}")
        console.print(f"      Blocks embedded: {embedding_stats['blocks_processed']}")

    def _fetch_old_content_for_changes(
        self, changes: Dict[str, Set[Path]], project_id: int, project_dir: Path
    ) -> Dict[str, str]:
        """
        Fetch old content from database for changed and deleted files.

        Args:
            changes: Dictionary containing changed_files, new_files, and deleted_files
            project_id: Project ID for database queries
            project_dir: Path to the project directory (for computing relative paths)

        Returns:
            Dictionary mapping relative file paths to their old content from database
        """
        old_content_map = {}

        try:
            # Get old content for changed files
            for file_path in changes["changed_files"]:
                try:
                    rel_path = str(file_path.relative_to(project_dir))
                    content = self._get_file_content_from_db(str(file_path))
                    old_content_map[rel_path] = content
                except Exception as e:
                    logger.debug(f"Could not get old content for {file_path}: {e}")
                    old_content_map[str(file_path.relative_to(project_dir))] = ""

            # Get old content for deleted files
            for file_path in changes["deleted_files"]:
                try:
                    rel_path = str(file_path.relative_to(project_dir))
                    content = self._get_file_content_from_db(str(file_path))
                    old_content_map[rel_path] = content
                except Exception as e:
                    logger.debug(f"Could not get old content for {file_path}: {e}")
                    old_content_map[str(file_path.relative_to(project_dir))] = ""

        except Exception as e:
            logger.error(f"Error fetching old content: {e}")

        return old_content_map

    def _get_file_content_from_db(self, file_path: str) -> str:
        """
        Get file content from database.

        Args:
            file_path: Absolute path to the file

        Returns:
            File content from database, or empty string if not found
        """
        try:
            query = """
                SELECT content FROM files
                WHERE file_path = ?
                ORDER BY id DESC
                LIMIT 1
            """
            results = self.connection.execute_query(query, (file_path,))

            if results and len(results) > 0:
                return results[0].get("content", "")

            return ""

        except Exception as e:
            logger.debug(f"Could not get content from database for {file_path}: {e}")
            return ""

    def _build_new_content_map(
        self,
        changes: Dict[str, Set[Path]],
        extraction_data: ExtractionData,
        project_dir: Path,
    ) -> Dict[str, str]:
        """Build a map of new content for changed and new files.

        Args:
            changes: Dictionary containing changed_files, new_files, deleted_files
            extraction_data: Extraction data containing parsed file information
            project_dir: Path to the project directory

        Returns:
            Dictionary mapping relative file paths to their new content
        """
        new_content_map = {}

        try:
            # Process changed and new files (get new content)
            files_to_process = changes["changed_files"].union(changes["new_files"])

            for file_path in files_to_process:
                try:
                    rel_path = str(file_path.relative_to(project_dir))
                    file_path_str = str(file_path)

                    # Try to get content from extraction data first
                    if file_path_str in extraction_data.files:
                        file_data = extraction_data.files[file_path_str]
                        new_content_map[rel_path] = file_data.content
                    else:
                        # Fallback to reading from disk
                        if file_path.exists():
                            new_content = file_path.read_text(
                                encoding="utf-8", errors="replace"
                            )
                            new_content_map[rel_path] = new_content

                except Exception as e:
                    logger.debug(f"Could not get new content for {file_path}: {e}")
                    new_content_map[str(file_path.relative_to(project_dir))] = ""

            # For deleted files, new content is empty string
            for file_path in changes["deleted_files"]:
                try:
                    rel_path = str(file_path.relative_to(project_dir))
                    new_content_map[rel_path] = ""
                except Exception as e:
                    logger.debug(f"Could not process deleted file {file_path}: {e}")

        except Exception as e:
            logger.error(f"Error building new content map: {e}")

        return new_content_map
