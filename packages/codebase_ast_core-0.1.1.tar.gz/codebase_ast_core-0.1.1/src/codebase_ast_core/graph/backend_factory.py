"""
Backend factory: Neo4j connection, graph operations, and AST→graph converter.
"""

from typing import Any, Optional

_connection: Optional[Any] = None
_graph_ops: Optional[Any] = None


def get_connection():
    """Return the Neo4j connection singleton."""
    global _connection
    if _connection is None:
        from .neo4j_client import Neo4jConnection

        _connection = Neo4jConnection()
    return _connection


def get_graph_operations():
    """Return graph operations backed by Neo4j."""
    global _graph_ops
    if _graph_ops is None:
        from .graph_operations_neo4j import GraphOperationsNeo4j

        _graph_ops = GraphOperationsNeo4j(get_connection())
    return _graph_ops


def get_converter():
    """Return the AST → Neo4j converter."""
    from .ast_to_neo4j_converter import ASTToNeo4jConverter

    return ASTToNeo4jConverter()


def reset_factory() -> None:
    """Reset cached connection and graph_ops (e.g. after config change)."""
    global _connection, _graph_ops
    _connection = None
    _graph_ops = None
