"""
Cypher queries for Neo4j backend.
Maps the knowledge graph data model: projects, files, code_blocks, relationships, connections.
"""

# ============================================================================
# SCHEMA / CONSTRAINTS
# ============================================================================

CREATE_CONSTRAINTS = [
    "CREATE CONSTRAINT project_name IF NOT EXISTS FOR (p:Project) REQUIRE p.name IS UNIQUE",
    "CREATE CONSTRAINT file_id IF NOT EXISTS FOR (f:File) REQUIRE f.id IS UNIQUE",
    "CREATE CONSTRAINT code_block_id IF NOT EXISTS FOR (b:CodeBlock) REQUIRE b.id IS UNIQUE",
]

# ============================================================================
# PROJECT
# ============================================================================

MERGE_PROJECT = """
MERGE (p:Project {name: $name})
ON CREATE SET
  p.id = $id,
  p.path = $path,
  p.description = $description,
  p.created_at = $created_at,
  p.updated_at = $updated_at,
  p.cross_indexing_done = $cross_indexing_done
ON MATCH SET
  p.path = $path,
  p.updated_at = $updated_at
RETURN p.id AS id
"""

GET_PROJECT_ID_BY_NAME = "MATCH (p:Project {name: $name}) RETURN p.id AS id"

GET_PROJECT_BY_NAME = """
MATCH (p:Project {name: $name})
RETURN p.id AS id, p.name AS name, p.path AS path, p.description AS description,
       p.created_at AS created_at, p.updated_at AS updated_at, p.cross_indexing_done AS cross_indexing_done
"""

GET_PROJECT_BY_PATH = """
MATCH (p:Project) WHERE p.path = $path
RETURN p.id AS id, p.name AS name, p.path AS path, p.description AS description,
       p.created_at AS created_at, p.updated_at AS updated_at, p.cross_indexing_done AS cross_indexing_done
"""

LIST_PROJECTS = """
MATCH (p:Project) RETURN p.id AS id, p.name AS name, p.path AS path, p.description AS description,
       p.created_at AS created_at, p.updated_at AS updated_at, p.cross_indexing_done AS cross_indexing_done
ORDER BY p.name
"""

DELETE_PROJECT = "MATCH (p:Project {name: $name}) DETACH DELETE p"

# ============================================================================
# FILE
# ============================================================================

MERGE_FILE = """
MATCH (p:Project) WHERE p.id = $project_id
MERGE (f:File {id: $id})
ON CREATE SET
  f.project_id = $project_id,
  f.file_path = $file_path,
  f.language = $language,
  f.content = $content,
  f.content_hash = $content_hash
ON MATCH SET
  f.file_path = $file_path,
  f.language = $language,
  f.content = $content,
  f.content_hash = $content_hash
WITH p, f
MERGE (p)-[:HAS_FILE]->(f)
RETURN f.id AS id
"""

GET_FILE_ID_BY_PATH = "MATCH (f:File) WHERE f.file_path = $file_path RETURN f.id AS id LIMIT 1"

# Match by path ending (e.g. enterprise/app/login/routes.ts) when path format differs after reindex
GET_FILE_ID_BY_PATH_SUFFIX = """
MATCH (f:File) WHERE f.file_path ENDS WITH $path_suffix
RETURN f.id AS id
"""

GET_FILE_ID_BY_PROJECT_AND_PATH = """
MATCH (p:Project {id: $project_id})-[:HAS_FILE]->(f:File)
WHERE f.file_path = $file_path
RETURN f.id AS id LIMIT 1
"""

GET_CODE_BLOCK_IDS_FOR_FILE = """
MATCH (f:File {id: $file_id})-[:HAS_BLOCK]->(b:CodeBlock)
RETURN b.id AS id
"""

DELETE_FILE_BLOCKS = """
MATCH (f:File {id: $file_id})-[:HAS_BLOCK]->(b:CodeBlock)
DETACH DELETE b
"""

# Delete only outgoing IMPORTS from this file (keeps incoming IMPORTS for impact report)
DELETE_OUTGOING_IMPORTS_FOR_FILE = """
MATCH (f:File {id: $file_id})-[r:IMPORTS]->()
DELETE r
"""

DELETE_FILE_NODE = """
MATCH (f:File {id: $file_id})
DETACH DELETE f
"""

# All IMPORTS edges (either direction) touching this file; required before file delete
DELETE_ALL_IMPORTS_FOR_FILE = """
MATCH (a:File)-[r:IMPORTS]-(b:File)
WHERE a.id = $file_id OR b.id = $file_id
DELETE r
"""

GET_PROJECT_FILE_PATHS = """
MATCH (p:Project {name: $project_name})-[:HAS_FILE]->(f:File)
RETURN DISTINCT f.file_path AS file_path
"""

GET_PROJECT_FILE_HASHES = """
MATCH (p:Project {id: $project_id})-[:HAS_FILE]->(f:File)
RETURN f.file_path AS file_path, f.content_hash AS content_hash
"""

GET_FILE_BY_ID = """
MATCH (f:File {id: $file_id})-[:HAS_FILE]-(p:Project)
OPTIONAL MATCH (f)-[:HAS_BLOCK]->(b:CodeBlock)
WITH f, p, count(b) AS block_count
RETURN f.id AS id, f.file_path AS file_path, f.language AS language, f.content AS content,
       f.content_hash AS content_hash, p.name AS project_name, p.id AS project_id, block_count
"""

# ============================================================================
# CODE BLOCK
# ============================================================================

MERGE_CODE_BLOCK = """
MATCH (f:File {id: $file_id})
MERGE (b:CodeBlock {id: $id})
ON CREATE SET
  b.type = $type,
  b.name = $name,
  b.content = $content,
  b.start_line = $start_line,
  b.end_line = $end_line,
  b.start_col = $start_col,
  b.end_col = $end_col,
  b.file_id = $file_id,
  b.parent_block_id = $parent_block_id
ON MATCH SET
  b.type = $type,
  b.name = $name,
  b.content = $content,
  b.start_line = $start_line,
  b.end_line = $end_line,
  b.start_col = $start_col,
  b.end_col = $end_col,
  b.parent_block_id = $parent_block_id
WITH f, b
MERGE (f)-[:HAS_BLOCK]->(b)
RETURN b.id AS id
"""

GET_BLOCK_BY_ID = """
MATCH (b:CodeBlock {id: $block_id})-[:HAS_BLOCK]-(f:File)-[:HAS_FILE]-(p:Project)
RETURN b.id AS id, b.type AS type, b.name AS name, b.content AS content,
       b.start_line AS start_line, b.end_line AS end_line,
       b.start_col AS start_col, b.end_col AS end_col, b.parent_block_id AS parent_block_id,
       f.file_path AS file_path, f.language AS language, f.id AS file_id,
       p.name AS project_name, p.id AS project_id
"""

GET_FILE_BLOCK_SUMMARY = """
MATCH (f:File {id: $file_id})-[:HAS_BLOCK]->(b:CodeBlock)
MATCH (f)<-[:HAS_FILE]-(p:Project)
RETURN b.id AS id, b.type AS type, b.name AS name,
       b.start_line AS start_line, b.end_line AS end_line,
       b.parent_block_id AS parent_block_id, f.file_path AS file_path,
       p.name AS project_name, p.id AS project_id
ORDER BY b.start_line
"""

# ============================================================================
# RELATIONSHIP (IMPORTS)
# ============================================================================

MERGE_IMPORTS = """
MATCH (source:File {id: $source_id}), (target:File {id: $target_id})
MERGE (source)-[r:IMPORTS]->(target)
ON CREATE SET r.import_content = $import_content, r.symbols = $symbols, r.type = $type
ON MATCH SET r.import_content = $import_content, r.symbols = $symbols, r.type = $type
RETURN elementId(r) AS id
"""

GET_IMPORTERS = """
MATCH (source:File)-[r:IMPORTS]->(target:File {id: $file_id})
MATCH (source)-[:HAS_FILE]-(p:Project)
RETURN source.id AS file_id, source.file_path AS file_path, source.language AS language,
       p.name AS project_name, r.import_content AS import_content
"""

GET_IMPORTS = """
MATCH (source:File {id: $file_id})-[r:IMPORTS]->(target:File)
MATCH (target)-[:HAS_FILE]-(p:Project)
RETURN target.id AS file_id, target.file_path AS file_path, target.language AS language,
       p.name AS project_name, r.import_content AS import_content
"""

def get_dependency_chain_cypher(max_depth: int) -> str:
    return f"""
MATCH path = (start:File {{id: $file_id}})-[:IMPORTS*1..{max_depth}]->(target:File)
WITH start, target, length(path) AS depth
RETURN start.id AS file_id, start.file_path AS file_path,
       target.id AS target_id, target.file_path AS target_path,
       depth
ORDER BY depth, start.file_path
LIMIT 25
"""

GET_FILE_IMPACT_SCOPE = """
MATCH (target:File {id: $file_id})<-[:IMPORTS]-(source:File)-[:HAS_FILE]-(p:Project)
RETURN 'importer' AS relationship_type, source.file_path AS file_path, source.language AS language,
       p.name AS project_name, '' AS import_content
UNION ALL
MATCH (source:File {id: $file_id})-[:IMPORTS]->(target:File)-[:HAS_FILE]-(p:Project)
RETURN 'dependency' AS relationship_type, target.file_path AS file_path, target.language AS language,
       p.name AS project_name, '' AS import_content
ORDER BY relationship_type, file_path
LIMIT 25
"""

GET_PARENT_BLOCK = """
MATCH (child:CodeBlock {id: $block_id})
WITH child.parent_block_id AS pid WHERE pid IS NOT NULL
MATCH (parent:CodeBlock {id: pid})-[:HAS_BLOCK]-(f:File)
RETURN parent.id AS id, parent.type AS type, parent.name AS name,
       parent.start_line AS start_line, parent.end_line AS end_line, f.file_path AS file_path
"""

GET_CHILD_BLOCKS = """
MATCH (child:CodeBlock) WHERE child.parent_block_id = $block_id
RETURN child.id AS id, child.type AS type, child.name AS name,
       child.start_line AS start_line, child.end_line AS end_line
ORDER BY child.start_line
"""

# ============================================================================
# CONNECTIONS (cross-indexing)
# ============================================================================

GET_MAX_INCOMING_CONNECTION_ID = "MATCH (n:IncomingConnection) RETURN coalesce(max(n.id), 0) AS max_id"
GET_MAX_OUTGOING_CONNECTION_ID = "MATCH (n:OutgoingConnection) RETURN coalesce(max(n.id), 0) AS max_id"

CREATE_INCOMING_CONNECTION = """
MATCH (f:File {id: $file_id})
CREATE (ic:IncomingConnection {id: $id, description: $description, start_line: $start_line, end_line: $end_line,
        technology_name: $technology_name, code_snippet: $code_snippet})
MERGE (f)-[:HAS_INCOMING]->(ic)
RETURN ic.id AS id
"""

CREATE_OUTGOING_CONNECTION = """
MATCH (f:File {id: $file_id})
CREATE (oc:OutgoingConnection {id: $id, description: $description, start_line: $start_line, end_line: $end_line,
        technology_name: $technology_name, code_snippet: $code_snippet})
MERGE (f)-[:HAS_OUTGOING]->(oc)
RETURN oc.id AS id
"""

CREATE_CONNECTION_MAPPING = """
MATCH (oc:OutgoingConnection {id: $sender_id}), (ic:IncomingConnection {id: $receiver_id})
MERGE (oc)-[r:MAPS_TO]->(ic)
ON CREATE SET r.description = $description, r.match_confidence = $match_confidence
RETURN elementId(r) AS id
"""

GET_CONNECTION_IMPACT = """
MATCH (f:File {id: $file_id})
OPTIONAL MATCH (f)-[:HAS_OUTGOING]->(oc:OutgoingConnection)-[:MAPS_TO]->(ic:IncomingConnection)<-[:HAS_INCOMING]-(otherf:File)-[:HAS_FILE]-(op:Project)
WHERE oc.id IS NOT NULL
WITH 'sends_to' AS impact_type, otherf, op, oc, ic
RETURN oc.technology_name AS technology_name, '' AS description, 0.0 AS match_confidence,
       impact_type, otherf.id AS other_file_id, otherf.file_path AS other_file,
       op.name AS other_project_name, op.id AS other_project_id
UNION ALL
MATCH (f:File {id: $file_id})
OPTIONAL MATCH (f)-[:HAS_INCOMING]->(ic:IncomingConnection)<-[:MAPS_TO]-(oc:OutgoingConnection)<-[:HAS_OUTGOING]-(otherf:File)-[:HAS_FILE]-(op:Project)
WHERE ic.id IS NOT NULL
WITH 'receives_from' AS impact_type, otherf, op, oc, ic
RETURN ic.technology_name AS technology_name, '' AS description, 0.0 AS match_confidence,
       impact_type, otherf.id AS other_file_id, otherf.file_path AS other_file,
       op.name AS other_project_name, op.id AS other_project_id
"""

# ============================================================================
# STATS
# ============================================================================

COUNT_FILES = "MATCH (f:File) RETURN count(f) AS count"
COUNT_BLOCKS = "MATCH (b:CodeBlock) RETURN count(b) AS count"
COUNT_RELATIONSHIPS = "MATCH ()-[r:IMPORTS]->() RETURN count(r) AS count"

GET_BLOCK_STATS = "MATCH (b:CodeBlock) RETURN b.type AS type, count(*) AS count"
GET_REL_STATS = "MATCH ()-[r:IMPORTS]->() RETURN r.type AS type, count(*) AS count"
GET_FILES_BY_LANGUAGE = "MATCH (f:File) RETURN f.language AS language, count(*) AS count"
GET_FILES_BY_PROJECT = """
MATCH (p:Project)-[:HAS_FILE]->(f:File)
RETURN p.name AS project_name, count(f) AS count
"""

# ============================================================================
# CLEAR
# ============================================================================

CLEAR_ALL = """
MATCH (n) DETACH DELETE n
"""

# Batched delete to avoid transaction memory limit on large graphs (use with $batch_size)
CLEAR_BATCH = """
MATCH (n) WITH n LIMIT $batch_size DETACH DELETE n
"""
