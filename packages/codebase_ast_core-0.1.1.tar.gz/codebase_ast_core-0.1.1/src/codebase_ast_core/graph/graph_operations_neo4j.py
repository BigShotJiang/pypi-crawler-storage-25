"""
Graph operations backed by Neo4j (Cypher).
"""

import os
from pathlib import Path
from typing import Any, Dict, List, Optional

from loguru import logger

from codebase_ast_core.models import CodeBlock, ExtractionData, File
from codebase_ast_core.queries import agent_queries  # for reference; we use Cypher

from . import neo4j_queries as q
from .neo4j_client import Neo4jConnection


class GraphOperationsNeo4j:
    """High-level graph operations using Neo4j (Cypher)."""

    def __init__(self, connection=None):
        self.connection = connection or Neo4jConnection()

    def _run(self, cypher: str, params: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        return self.connection._run(cypher, params or {})

    def insert_extraction_data(
        self, extraction_data: ExtractionData, project_id: int
    ) -> None:
        """Insert complete extraction data (files, blocks, relationships) into Neo4j."""
        logger.debug(f"Inserting extraction data for project ID: {project_id} (Neo4j)")
        files_data = extraction_data.files
        for file_path, file_data in files_data.items():
            file_record = File(
                id=file_data.id,
                project_id=project_id,
                file_path=file_path,
                language=file_data.language,
                content=file_data.content,
                content_hash=file_data.content_hash,
            )
            self.connection.insert_file(file_record)
            self._insert_blocks_recursively(file_data.blocks, file_data.id, None)
            for rel in file_data.relationships:
                self.connection.insert_relationship(rel)

    def _insert_blocks_recursively(
        self,
        blocks: List[CodeBlock],
        file_id: int,
        parent_block_id: Optional[int],
    ) -> None:
        for block in blocks:
            if block.file_id is None:
                block.file_id = file_id
            block.parent_block_id = parent_block_id
            self.connection.insert_code_block(block)
            if block.children:
                self._insert_blocks_recursively(block.children, file_id, block.id)

    def get_file_count(self) -> int:
        r = self._run(q.COUNT_FILES)
        return int(r[0]["count"]) if r else 0

    def get_block_count(self) -> int:
        r = self._run(q.COUNT_BLOCKS)
        return int(r[0]["count"]) if r else 0

    def get_relationship_count(self) -> int:
        r = self._run(q.COUNT_RELATIONSHIPS)
        return int(r[0]["count"]) if r else 0

    def get_extraction_stats(self) -> Dict[str, Any]:
        try:
            block_stats = {}
            for row in self._run(q.GET_BLOCK_STATS):
                block_stats[row["type"]] = row["count"]
            rel_stats = {}
            for row in self._run(q.GET_REL_STATS):
                rel_stats[row["type"]] = row["count"]
            files_by_language = {}
            for row in self._run(q.GET_FILES_BY_LANGUAGE):
                files_by_language[row["language"]] = row["count"]
            files_by_project = {}
            for row in self._run(q.GET_FILES_BY_PROJECT):
                files_by_project[row["project_name"]] = row["count"]
            return {
                "total_files": self.get_file_count(),
                "total_blocks": self.get_block_count(),
                "total_relationships": self.get_relationship_count(),
                "block_types": block_stats,
                "relationship_types": rel_stats,
                "files_by_language": files_by_language,
                "files_by_project": files_by_project,
            }
        except Exception as e:
            logger.error(f"Error getting extraction stats: {e}")
            return {
                "total_files": 0,
                "total_blocks": 0,
                "total_relationships": 0,
                "block_types": {},
                "relationship_types": {},
                "files_by_language": {},
                "files_by_project": {},
            }

    def _get_file_id_by_path(self, file_path: str) -> Optional[int]:
        if not file_path:
            return None
        absolute_file_path = (
            str(Path(file_path).resolve()) if not os.path.isabs(file_path) else file_path
        )
        r = self._run(q.GET_FILE_ID_BY_PATH, {"file_path": absolute_file_path})
        if r:
            return r[0]["id"]
        if absolute_file_path != file_path:
            r = self._run(q.GET_FILE_ID_BY_PATH, {"file_path": file_path})
            if r:
                return r[0]["id"]
        # Normalized path (forward slashes) in case DB has different separator
        normalized = absolute_file_path.replace("\\", "/")
        if normalized != absolute_file_path:
            r = self._run(q.GET_FILE_ID_BY_PATH, {"file_path": normalized})
            if r:
                return r[0]["id"]
        # Suffix match: path ending (e.g. enterprise/app/login/routes.ts)
        path_parts = normalized.split("/")
        for length in range(min(6, len(path_parts)), 0, -1):
            suffix = "/".join(path_parts[-length:])
            r = self._run(q.GET_FILE_ID_BY_PATH_SUFFIX, {"path_suffix": suffix})
            if r and len(r) == 1:
                return r[0]["id"]
        # Try with backslash suffix (Windows-style stored in DB)
        path_parts_backslash = absolute_file_path.replace("/", "\\").split("\\")
        for length in range(min(6, len(path_parts_backslash)), 0, -1):
            suffix = "\\".join(path_parts_backslash[-length:])
            r = self._run(q.GET_FILE_ID_BY_PATH_SUFFIX, {"path_suffix": suffix})
            if r and len(r) == 1:
                return r[0]["id"]
        return None

    def resolve_file(self, file_id: int) -> Optional[Dict[str, Any]]:
        r = self._run(q.GET_FILE_BY_ID, {"file_id": file_id})
        if not r:
            return None
        row = r[0]
        return {
            "id": row["id"],
            "file_path": row["file_path"],
            "language": row["language"],
            "content": row.get("content"),
            "content_hash": row.get("content_hash"),
            "project_name": row["project_name"],
            "project_id": row["project_id"],
            "block_count": row.get("block_count", 0),
        }

    def resolve_block(self, block_id: int) -> Optional[Dict[str, Any]]:
        r = self._run(q.GET_BLOCK_BY_ID, {"block_id": block_id})
        if not r:
            return None
        row = r[0]
        return {
            "id": row["id"],
            "type": row["type"],
            "name": row["name"],
            "content": row.get("content"),
            "start_line": row["start_line"],
            "end_line": row["end_line"],
            "start_col": row.get("start_col", 0),
            "end_col": row.get("end_col", 0),
            "parent_block_id": row.get("parent_block_id"),
            "file_path": row["file_path"],
            "language": row["language"],
            "file_id": row["file_id"],
            "project_name": row["project_name"],
            "project_id": row["project_id"],
        }

    def get_db_file_hashes(self, project_id: int) -> Dict[str, str]:
        """Get all file hashes from the database for a project (file_path -> content_hash)."""
        rows = self._run(q.GET_PROJECT_FILE_HASHES, {"project_id": project_id})
        return {
            row["file_path"]: (row.get("content_hash") or "")
            for row in rows
        } if rows else {}

    def get_file_block_summary(self, file_id: int) -> List[Dict[str, Any]]:
        rows = self._run(q.GET_FILE_BLOCK_SUMMARY, {"file_id": file_id})
        result = []
        for row in rows:
            hierarchy_path = self.get_block_hierarchy_path(row["id"])
            result.append({
                "id": row["id"],
                "type": row["type"],
                "name": row["name"],
                "start_line": row["start_line"],
                "end_line": row["end_line"],
                "parent_block_id": row.get("parent_block_id"),
                "file_path": row.get("file_path"),
                "project_name": row.get("project_name"),
                "project_id": row.get("project_id"),
                "hierarchy_path": hierarchy_path,
            })
        return result

    def get_block_hierarchy_path(self, block_id: int) -> List[Dict[str, Any]]:
        path = []
        current_id = block_id
        while current_id:
            block = self.resolve_block(current_id)
            if not block:
                break
            path.insert(0, {
                "id": block["id"],
                "type": block["type"],
                "name": block["name"],
                "start_line": block["start_line"],
                "end_line": block["end_line"],
            })
            current_id = block.get("parent_block_id")
        return path

    def get_block_children(self, block_id: int) -> List[Dict[str, Any]]:
        rows = self._run(q.GET_CHILD_BLOCKS, {"block_id": block_id})
        return [
            {
                "id": row["id"],
                "type": row["type"],
                "name": row["name"],
                "start_line": row["start_line"],
                "end_line": row["end_line"],
            }
            for row in rows
        ]

    def get_imports(self, file_id: int) -> List[Dict[str, Any]]:
        rows = self._run(q.GET_IMPORTS, {"file_id": file_id})
        return [
            {
                "import_content": row.get("import_content", ""),
                "file_path": row["file_path"],
                "language": row["language"],
                "project_name": row["project_name"],
            }
            for row in rows
        ]

    def get_importers(self, file_id: int) -> List[Dict[str, Any]]:
        rows = self._run(q.GET_FILE_IMPACT_SCOPE, {"file_id": file_id})
        return [
            {
                "file_path": row["file_path"],
                "language": row["language"],
                "project_name": row["project_name"],
                "import_content": row.get("import_content", ""),
            }
            for row in rows
            if row.get("relationship_type") == "importer"
        ]

    def get_dependency_chain(
        self, file_id: int, depth: int = 5
    ) -> List[Dict[str, Any]]:
        cypher = q.get_dependency_chain_cypher(depth)
        rows = self._run(cypher, {"file_id": file_id})
        return [
            {
                "file_id": row["file_id"],
                "file_path": row["file_path"],
                "target_id": row["target_id"],
                "target_path": row["target_path"],
                "depth": row["depth"],
                "path": f"{row['file_path']} → {row['target_path']}",
            }
            for row in rows
        ]

    def get_connection_impact(self, file_id: int) -> List[Dict[str, Any]]:
        rows = self._run(q.GET_CONNECTION_IMPACT, {"file_id": file_id})
        return [
            {
                "technology_name": row.get("technology_name", ""),
                "description": row.get("description", ""),
                "match_confidence": row.get("match_confidence", 0),
                "impact_type": row.get("impact_type", ""),
                "other_file_id": row.get("other_file_id"),
                "other_file": row.get("other_file", ""),
                "other_project_id": row.get("other_project_id"),
                "other_project_name": row.get("other_project_name", ""),
                "technology": row.get("technology_name", ""),
                "anchor_code_snippet": row.get("anchor_code_snippet"),
                "other_code_snippet": row.get("other_code_snippet"),
                "anchor_start_line": row.get("anchor_start_line"),
                "anchor_end_line": row.get("anchor_end_line"),
                "other_start_line": row.get("other_start_line"),
                "other_end_line": row.get("other_end_line"),
            }
            for row in rows
        ]

    def get_search_scope_by_import_graph(
        self,
        anchor_file_id: int,
        direction: str = "both",
        max_depth: int = 2,
    ) -> Dict[str, Any]:
        anchor_file = self.resolve_file(anchor_file_id)
        if not anchor_file:
            return {
                "anchor_file_path": None,
                "imports": [],
                "importers": [],
                "dependency_chain": [],
                "connection_impacts": [],
                "max_depth": max_depth,
            }
        connection_impacts = self.get_connection_impact(anchor_file_id)
        imports = self.get_imports(anchor_file_id) if direction in ("both", "dependencies") else []
        importers = self.get_importers(anchor_file_id) if direction in ("both", "importers") else []
        dependency_chain = (
            self.get_dependency_chain(anchor_file_id, max_depth)
            if max_depth > 1
            else []
        )
        return {
            "anchor_file_path": anchor_file["file_path"],
            "imports": imports,
            "importers": importers,
            "dependency_chain": dependency_chain,
            "connection_impacts": connection_impacts,
            "max_depth": max_depth,
        }
