"""
Converter from code extraction JSON to Neo4j knowledge graph.
"""

from pathlib import Path
from typing import Dict, Optional

from loguru import logger

from codebase_ast_core.models.schema import ExtractionData, Project
from codebase_ast_core.utils.console import console

from codebase_ast_core.utils.helpers import load_json_file


class ASTToNeo4jConverter:
    """Converts code extraction JSON to Neo4j knowledge graph."""

    def __init__(self, connection=None, graph_ops=None):
        from .backend_factory import get_connection, get_graph_operations
        self.connection = connection or get_connection()
        self.graph_ops = graph_ops or get_graph_operations()
        logger.debug("ASTToNeo4jConverter initialized")

    def convert_json_to_graph(
        self,
        json_file_path: Path,
        project_path: Path,
        project_name: Optional[str] = None,
        clear_existing: bool = False,
    ) -> Dict[str, str | int | float]:
        """Convert code extraction JSON to Neo4j graph."""
        logger.debug(f"Starting Neo4j conversion of: {json_file_path}")
        try:
            if project_name is None:
                project_name = Path(json_file_path).stem
                console.print(f"Project name: {project_name}")

            console.print("Loading JSON data...")
            json_data = load_json_file(json_file_path)
            extraction_data = ExtractionData(**json_data)

            if clear_existing:
                console.print("Clearing existing Neo4j data...")
                self.connection.clear_database()

            from datetime import datetime
            current_time = datetime.now().isoformat()
            project = Project(
                id=1,
                name=project_name,
                path=str(project_path.absolute()),
                description="",
                created_at=current_time,
                updated_at=current_time,
            )
            project_id = self.connection.insert_project(project)
            logger.debug(f"Created project '{project_name}' with ID: {project_id}")

            logger.debug("Inserting extraction data into Neo4j...")
            self.graph_ops.insert_extraction_data(extraction_data, project_id)
            stats = self.graph_ops.get_extraction_stats()

            console.print("Conversion completed successfully (Neo4j)!")
            console.print(f"Final statistics: {stats}")

            total_files = len(extraction_data.files)
            total_blocks = sum(
                len(fd.blocks) for fd in extraction_data.files.values()
            )
            total_relationships = sum(
                len(fd.relationships) for fd in extraction_data.files.values()
            )
            return {
                "status": "success",
                "input_file": str(json_file_path),
                "project_name": project_name,
                "project_id": project_id,
                "files_processed": total_files,
                "blocks_processed": total_blocks,
                "relationships_processed": total_relationships,
                "total_nodes": stats.get("total_blocks", 0) + stats.get("total_files", 0),
                "total_relationships": stats.get("total_relationships", 0),
            }
        except Exception as e:
            logger.error(f"Neo4j conversion failed: {e}")
            raise

    def close(self):
        if self.connection:
            self.connection.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
