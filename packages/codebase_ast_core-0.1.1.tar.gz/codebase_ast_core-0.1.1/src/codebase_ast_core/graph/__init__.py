"""
Graph module initialization (Neo4j only).
"""

from codebase_ast_core.graph.backend_factory import (
    get_connection,
    get_converter,
    get_graph_operations,
)


def clear_graph_data() -> None:
    """Delete all graph data (projects, files, blocks, relationships) in Neo4j."""
    conn = get_connection()
    conn.clear_database()


__all__ = [
    "get_connection",
    "get_graph_operations",
    "get_converter",
    "clear_graph_data",
]
