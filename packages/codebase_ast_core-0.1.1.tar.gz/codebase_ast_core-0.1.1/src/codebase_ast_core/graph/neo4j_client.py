"""
Neo4j database connection and operations.
Same logical API as the historical SQLite graph client for projects, files, code_blocks, relationships.
"""

import json
from typing import Any, Dict, List, Optional, Union

from loguru import logger

try:
    from neo4j import GraphDatabase
except ImportError:
    GraphDatabase = None  # type: ignore

from codebase_ast_core.config import config
from codebase_ast_core.models import CodeBlock, File, Project, Relationship
from codebase_ast_core.models.schema import BlockType

from . import neo4j_queries as q


class Neo4jConnection:
    """Neo4j connection for indexing and reads."""

    def __init__(self):
        if not GraphDatabase:
            raise ImportError(
                "Neo4j backend requires the neo4j package. Install with: pip install neo4j"
            )
        neo4j_cfg = getattr(config.database, "neo4j", None)
        if not neo4j_cfg:
            raise ValueError(
                "database.neo4j config (uri, user, password) is missing"
            )
        self._driver = GraphDatabase.driver(
            neo4j_cfg.uri,
            auth=(neo4j_cfg.user, neo4j_cfg.password),
        )
        self._database = (getattr(neo4j_cfg, "database", None) or "").strip()
        self._create_constraints()
        logger.debug("Neo4jConnection initialized")

    def _db_session_kw(self, extra: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        out: Dict[str, Any] = dict(extra or {})
        if self._database:
            out["database"] = self._database
        return out

    def _create_constraints(self) -> None:
        with self._driver.session(**self._db_session_kw()) as session:
            for cypher in q.CREATE_CONSTRAINTS:
                try:
                    session.run(cypher)
                except Exception as e:
                    if "EquivalentSchemaRuleAlreadyExists" not in str(e):
                        logger.debug(f"Constraint creation: {e}")

    def close(self) -> None:
        if getattr(self, "_driver", None):
            self._driver.close()
            logger.debug("Neo4j connection closed")

    def _run(self, cypher: str, parameters: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        parameters = parameters or {}
        # Suppress deprecation/WARNING notifications so console is not flooded
        session_config = {}
        try:
            from neo4j import NotificationMinimumSeverity
            session_config["notifications_min_severity"] = NotificationMinimumSeverity.OFF
        except (ImportError, AttributeError):
            pass
        with self._driver.session(**self._db_session_kw(session_config)) as session:
            result = session.run(cypher, parameters)
            return [dict(record) for record in result]

    def execute_query(
        self, query: str, parameters: Optional[tuple] = None
    ) -> List[Dict[str, Any]]:
        """Run Cypher (query is Cypher string, parameters as dict). For compatibility, parameters can be tuple - we convert to dict by position for known queries."""
        if parameters is not None and isinstance(parameters, (list, tuple)):
            # Some callers pass tuple; Cypher uses named params
            return self._run(query, {"params": parameters})
        return self._run(query, parameters if isinstance(parameters, dict) else {})

    def project_exists(self, project_name: str) -> bool:
        r = self._run(q.GET_PROJECT_ID_BY_NAME, {"name": project_name})
        return len(r) > 0 and r[0].get("id") is not None

    def get_project(self, project_name: str) -> Optional[Project]:
        r = self._run(q.GET_PROJECT_BY_NAME, {"name": project_name})
        if not r:
            return None
        row = r[0]
        return Project(
            id=row["id"],
            name=row["name"],
            path=row["path"],
            description=row["description"] or "",
            created_at=row["created_at"] or "",
            updated_at=row["updated_at"] or "",
            cross_indexing_done=bool(row.get("cross_indexing_done", False)),
        )

    def get_project_by_path(self, project_path: str) -> Optional[Project]:
        r = self._run(q.GET_PROJECT_BY_PATH, {"path": project_path})
        if not r:
            return None
        row = r[0]
        return Project(
            id=row["id"],
            name=row["name"],
            path=row["path"],
            description=row["description"] or "",
            created_at=row["created_at"] or "",
            updated_at=row["updated_at"] or "",
            cross_indexing_done=bool(row.get("cross_indexing_done", False)),
        )

    def delete_project(self, project_name: str) -> None:
        self._run(q.DELETE_PROJECT, {"name": project_name})

    def insert_project(self, project: Project) -> int:
        self._run(
            q.MERGE_PROJECT,
            {
                "id": project.id,
                "name": project.name,
                "path": project.path,
                "description": project.description or "",
                "created_at": project.created_at,
                "updated_at": project.updated_at,
                "cross_indexing_done": getattr(project, "cross_indexing_done", False),
            },
        )
        r = self._run(q.GET_PROJECT_ID_BY_NAME, {"name": project.name})
        project_id = r[0]["id"] if r else project.id
        logger.debug(f"Inserted project '{project.name}' with ID: {project_id}")
        return project_id

    def insert_file(self, file: File) -> int:
        self._run(
            q.MERGE_FILE,
            {
                "id": file.id,
                "project_id": file.project_id,
                "file_path": file.file_path,
                "language": file.language,
                "content": file.content,
                "content_hash": file.content_hash,
            },
        )
        return file.id

    def insert_code_block(self, block: CodeBlock) -> int:
        self._run(
            q.MERGE_CODE_BLOCK,
            {
                "id": block.id,
                "type": block.type.value,
                "name": block.name,
                "content": block.content,
                "start_line": block.start_line,
                "end_line": block.end_line,
                "start_col": block.start_col,
                "end_col": block.end_col,
                "file_id": block.file_id,
                "parent_block_id": block.parent_block_id,
            },
        )
        return block.id

    def insert_relationship(self, relationship: Relationship) -> int:
        symbols_json = json.dumps(relationship.symbols)
        self._run(
            q.MERGE_IMPORTS,
            {
                "source_id": relationship.source_id,
                "target_id": relationship.target_id,
                "import_content": relationship.import_content,
                "symbols": symbols_json,
                "type": relationship.type,
            },
        )
        return 1

    def list_all_projects(self) -> List[Project]:
        rows = self._run(q.LIST_PROJECTS)
        return [
            Project(
                id=row["id"],
                name=row["name"],
                path=row["path"],
                description=row["description"] or "",
                created_at=row["created_at"] or "",
                updated_at=row["updated_at"] or "",
                cross_indexing_done=bool(row.get("cross_indexing_done", False)),
            )
            for row in rows
        ]

    def clear_database(self, batch_size: Optional[int] = None) -> None:
        """Delete all nodes and relationships in batches to avoid transaction memory limit."""
        if batch_size is None:
            batch_size = getattr(config.database, "clear_batch_size", 500)
        batch_size = max(100, min(5000, int(batch_size)))
        total_deleted = 0
        session_config = {}
        try:
            from neo4j import NotificationMinimumSeverity
            session_config["notifications_min_severity"] = NotificationMinimumSeverity.OFF
        except (ImportError, AttributeError):
            pass
        with self._driver.session(**self._db_session_kw(session_config)) as session:
            while True:
                result = session.run(q.CLEAR_BATCH, {"batch_size": batch_size})
                summary = result.consume()
                deleted = summary.counters.nodes_deleted if summary.counters else 0
                total_deleted += deleted
                if deleted == 0:
                    break
                logger.debug(f"Cleared batch: {deleted} nodes (total so far: {total_deleted})")
        self._create_constraints()
        logger.debug(f"Neo4j database cleared ({total_deleted} nodes total)")

    def get_file_blocks(
        self, file_path: str, project_name: Optional[str] = None
    ) -> List[CodeBlock]:
        r = self._run(q.GET_FILE_ID_BY_PATH, {"file_path": file_path})
        if not r:
            return []
        file_id = r[0]["id"]
        rows = self._run(q.GET_FILE_BLOCK_SUMMARY, {"file_id": file_id})
        return [
            CodeBlock(
                id=row["id"],
                type=BlockType(row["type"]),
                name=row["name"],
                content="",
                start_line=row["start_line"],
                end_line=row["end_line"],
                start_col=0,
                end_col=0,
                file_id=file_id,
                parent_block_id=None,
                children=[],
            )
            for row in rows
        ]

    def get_project_block_count(self, project_name: str) -> int:
        # Count blocks under files that belong to this project
        cypher = """
        MATCH (p:Project {name: $name})-[:HAS_FILE]->(f:File)-[:HAS_BLOCK]->(b:CodeBlock)
        RETURN count(b) AS count
        """
        r = self._run(cypher, {"name": project_name})
        return r[0]["count"] if r else 0

    def delete_project_data(self, project_name: str) -> int:
        count = self.get_project_block_count(project_name)
        self.delete_project(project_name)
        return count

    def get_project_id_by_name(self) -> Optional[int]:
        from pathlib import Path
        project_name = Path.cwd().absolute().stem
        r = self._run(q.GET_PROJECT_ID_BY_NAME, {"name": project_name})
        return r[0]["id"] if r else None

    @staticmethod
    def _file_path_key_variants(file_path: str) -> List[str]:
        s = (file_path or "").strip()
        if not s:
            return []
        out: List[str] = []
        for c in (s, s.replace("\\", "/"), s.replace("/", "\\")):
            if c and c not in out:
                out.append(c)
        return out

    def resolve_file_id(
        self, project_id: int, file_path: str
    ) -> Optional[int]:
        """Return File id for a path, trying path variants; None if not found."""
        for cand in self._file_path_key_variants(file_path):
            r = self._run(
                q.GET_FILE_ID_BY_PROJECT_AND_PATH,
                {"project_id": project_id, "file_path": cand},
            )
            if r and r[0].get("id") is not None:
                return int(r[0]["id"])
        for cand in self._file_path_key_variants(file_path):
            r = self._run(q.GET_FILE_ID_BY_PATH, {"file_path": cand})
            if r and r[0].get("id") is not None:
                return int(r[0]["id"])
        return None

    def collect_embedding_node_ids_for_file(
        self, file_id: int
    ) -> List[str]:
        r = self._run(q.GET_CODE_BLOCK_IDS_FOR_FILE, {"file_id": file_id})
        bids: List[int] = [int(row["id"]) for row in (r or []) if row.get("id") is not None]
        return [f"file_{file_id}"] + [f"block_{b}" for b in bids]

    def delete_file_subgraph_by_id(self, file_id: int) -> None:
        """Remove one file's :File node and related data; call after deleting EmbeddingChunk nodes."""
        self._run(q.DELETE_ALL_IMPORTS_FOR_FILE, {"file_id": file_id})
        for cy in (
            "MATCH (f:File {id: $id})-[:HAS_INCOMING]->(ic:IncomingConnection) DETACH DELETE ic",
            "MATCH (f:File {id: $id})-[:HAS_OUTGOING]->(oc:OutgoingConnection) DETACH DELETE oc",
        ):
            self._run(cy, {"id": file_id})
        self._run(q.DELETE_FILE_BLOCKS, {"file_id": file_id})
        self._run(q.DELETE_FILE_NODE, {"file_id": file_id})
        logger.debug("Removed :File id=%s and subgraph", file_id)

    def delete_file_subgraph(
        self, project_id: int, file_path: str
    ) -> bool:
        """
        Remove one file's graph data (and blocks) for re-import; caller deletes embeddings first.
        Returns True if a :File was found and removed, False if no file matched the path.
        """
        file_id = self.resolve_file_id(project_id, file_path)
        if file_id is None:
            logger.debug("No :File in Neo4j for project_id=%s path=%r", project_id, file_path)
            return False
        self.delete_file_subgraph_by_id(file_id)
        return True

    @property
    def connection(self) -> Any:
        """Expose driver for code that expects .connection (e.g. execute)."""
        return self._driver
