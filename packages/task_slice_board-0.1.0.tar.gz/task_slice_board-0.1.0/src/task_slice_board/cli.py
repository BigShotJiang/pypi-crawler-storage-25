from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from .core import board_to_dict, build_board, iter_text, render_html, render_markdown


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="task-slice-board",
        description="Turn messy work notes into a small task board.",
    )
    parser.add_argument("paths", nargs="*", help="Text or Markdown files. Reads stdin when omitted.")
    parser.add_argument("--title", default="Task Slice Board", help="Board title.")
    parser.add_argument("--max-items", type=int, default=24, help="Maximum slices to keep.")
    parser.add_argument("--format", choices=("markdown", "json", "html"), default="markdown", help="Output format.")
    parser.add_argument("--output", "-o", help="Write output to this file.")
    parser.add_argument("--fail-on-blocked", action="store_true", help="Exit 2 when blocked slices are found.")
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.max_items < 1:
        parser.error("--max-items must be at least 1")

    text = iter_text(args.paths) if args.paths else sys.stdin.read()
    board = build_board(text, title=args.title, max_items=args.max_items)

    if args.format == "json":
        rendered = json.dumps(board_to_dict(board), indent=2) + "\n"
    elif args.format == "html":
        rendered = render_html(board)
    else:
        rendered = render_markdown(board)

    if args.output:
        Path(args.output).write_text(rendered, encoding="utf-8")
    else:
        sys.stdout.write(rendered)

    if args.fail_on_blocked and board.lane("blocked"):
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
