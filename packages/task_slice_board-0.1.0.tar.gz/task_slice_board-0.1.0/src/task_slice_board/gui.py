from __future__ import annotations

import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from .core import Board, build_board, render_html, render_markdown


SAMPLE = """Fix failing checkout retry test before the release.
Waiting on API token rotation approval from platform.
Update README setup steps with the new env var.
Later: add saved board templates.
Investigate production billing webhook timeout today.
"""


class App(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title("Task Slice Board")
        self.geometry("1040x680")
        self.minsize(820, 520)
        self.board: Board | None = None
        self._build()
        self.input.insert("1.0", SAMPLE)
        self.refresh()

    def _build(self) -> None:
        self.columnconfigure(0, weight=1)
        self.columnconfigure(1, weight=1)
        self.rowconfigure(1, weight=1)

        toolbar = ttk.Frame(self, padding=(10, 8))
        toolbar.grid(row=0, column=0, columnspan=2, sticky="ew")
        toolbar.columnconfigure(1, weight=1)

        ttk.Label(toolbar, text="Title").grid(row=0, column=0, padx=(0, 6))
        self.title_var = tk.StringVar(value="Task Slice Board")
        ttk.Entry(toolbar, textvariable=self.title_var).grid(row=0, column=1, sticky="ew", padx=(0, 8))
        ttk.Button(toolbar, text="Build", command=self.refresh).grid(row=0, column=2, padx=3)
        ttk.Button(toolbar, text="Open", command=self.open_file).grid(row=0, column=3, padx=3)
        ttk.Button(toolbar, text="Save Markdown", command=self.save_markdown).grid(row=0, column=4, padx=3)
        ttk.Button(toolbar, text="Save HTML", command=self.save_html).grid(row=0, column=5, padx=3)

        input_frame = ttk.Frame(self, padding=(10, 0, 5, 10))
        input_frame.grid(row=1, column=0, sticky="nsew")
        input_frame.rowconfigure(1, weight=1)
        input_frame.columnconfigure(0, weight=1)
        ttk.Label(input_frame, text="Notes").grid(row=0, column=0, sticky="w")
        self.input = tk.Text(input_frame, wrap="word", undo=True)
        self.input.grid(row=1, column=0, sticky="nsew")

        output_frame = ttk.Frame(self, padding=(5, 0, 10, 10))
        output_frame.grid(row=1, column=1, sticky="nsew")
        output_frame.rowconfigure(1, weight=1)
        output_frame.columnconfigure(0, weight=1)
        ttk.Label(output_frame, text="Board").grid(row=0, column=0, sticky="w")
        self.output = tk.Text(output_frame, wrap="word", state="disabled")
        self.output.grid(row=1, column=0, sticky="nsew")

    def refresh(self) -> None:
        self.board = build_board(self.input.get("1.0", "end"), title=self.title_var.get().strip() or "Task Slice Board")
        markdown = render_markdown(self.board)
        self.output.configure(state="normal")
        self.output.delete("1.0", "end")
        self.output.insert("1.0", markdown)
        self.output.configure(state="disabled")

    def open_file(self) -> None:
        path = filedialog.askopenfilename(filetypes=[("Text files", "*.txt *.md"), ("All files", "*.*")])
        if not path:
            return
        try:
            with open(path, "r", encoding="utf-8") as handle:
                content = handle.read()
        except OSError as exc:
            messagebox.showerror("Open failed", str(exc))
            return
        self.input.delete("1.0", "end")
        self.input.insert("1.0", content)
        self.refresh()

    def save_markdown(self) -> None:
        self.refresh()
        self._save(render_markdown(self.board), ".md")  # type: ignore[arg-type]

    def save_html(self) -> None:
        self.refresh()
        self._save(render_html(self.board), ".html")  # type: ignore[arg-type]

    def _save(self, content: str, extension: str) -> None:
        path = filedialog.asksaveasfilename(defaultextension=extension)
        if not path:
            return
        try:
            with open(path, "w", encoding="utf-8") as handle:
                handle.write(content)
        except OSError as exc:
            messagebox.showerror("Save failed", str(exc))


def main() -> None:
    App().mainloop()


if __name__ == "__main__":
    main()
