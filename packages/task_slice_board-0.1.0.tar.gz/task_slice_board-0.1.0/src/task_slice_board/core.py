from __future__ import annotations

from dataclasses import dataclass
from html import escape
import re
from typing import Iterable, Literal

Lane = Literal["now", "next", "later", "blocked"]


ACTION_WORDS = {
    "add",
    "adjust",
    "audit",
    "build",
    "change",
    "check",
    "clean",
    "confirm",
    "create",
    "debug",
    "decide",
    "document",
    "draft",
    "fix",
    "follow",
    "handle",
    "implement",
    "investigate",
    "merge",
    "move",
    "open",
    "publish",
    "refactor",
    "release",
    "remove",
    "repair",
    "review",
    "run",
    "ship",
    "split",
    "test",
    "triage",
    "update",
    "verify",
    "write",
}

BLOCKER_HINTS = {
    "blocked",
    "blocker",
    "can't",
    "cannot",
    "depends",
    "dependency",
    "missing",
    "needs access",
    "needs approval",
    "not sure",
    "question",
    "waiting",
}

QUICK_HINTS = {"quick", "small", "tiny", "simple", "copy", "rename", "typo", "docs"}
RISK_HINTS = {"auth", "billing", "database", "migration", "security", "production", "delete", "token"}


@dataclass(frozen=True)
class Slice:
    text: str
    lane: Lane
    score: int
    tags: tuple[str, ...]
    source_line: int
    reason: str


@dataclass(frozen=True)
class Board:
    title: str
    slices: tuple[Slice, ...]
    ignored: tuple[str, ...]

    def lane(self, lane: Lane) -> tuple[Slice, ...]:
        return tuple(item for item in self.slices if item.lane == lane)


def build_board(text: str, *, title: str = "Task Slice Board", max_items: int = 24) -> Board:
    candidates: list[Slice] = []
    ignored: list[str] = []

    for line_no, raw in enumerate(text.splitlines(), start=1):
        candidate = normalize_line(raw)
        if not candidate:
            continue
        if not looks_actionable(candidate):
            if len(ignored) < 12:
                ignored.append(candidate)
            continue
        candidates.append(classify_slice(candidate, line_no))

    ranked = sorted(candidates, key=lambda item: (-item.score, item.source_line))
    return Board(title=title, slices=tuple(ranked[:max_items]), ignored=tuple(ignored))


def normalize_line(raw: str) -> str:
    line = raw.strip()
    if re.match(r"^#{1,6}\s+\S", line):
        return ""
    line = re.sub(r"^[-*+]\s+", "", line)
    line = re.sub(r"^\d+[.)]\s+", "", line)
    line = re.sub(r"^\[[ xX-]\]\s+", "", line)
    line = re.sub(r"\s+", " ", line)
    return line.strip(" \t")


def looks_actionable(line: str) -> bool:
    lowered = line.lower()
    first = re.split(r"\W+", lowered, maxsplit=1)[0]
    if first in ACTION_WORDS:
        return True
    if re.search(r"\b(todo|fixme|next|later|backlog|follow up|action|owner|due|should|must|need to|needs to)\b", lowered):
        return True
    if any(hint in lowered for hint in BLOCKER_HINTS):
        return True
    return False


def classify_slice(line: str, line_no: int) -> Slice:
    lowered = line.lower()
    tags: list[str] = []
    score = 50
    reason = "actionable language"

    if any(hint in lowered for hint in BLOCKER_HINTS):
        lane: Lane = "blocked"
        score += 35
        tags.append("blocked")
        reason = "blocker or dependency"
    elif re.search(r"\b(later|eventually|backlog|nice to have|stretch)\b", lowered):
        lane = "later"
        score -= 10
        tags.append("backlog")
        reason = "deferred wording"
    elif any(hint in lowered for hint in QUICK_HINTS) or len(line) <= 72:
        lane = "now"
        score += 25
        tags.append("quick-win")
        reason = "small or direct task"
    else:
        lane = "next"
        score += 5

    if re.search(r"\b(today|now|urgent|asap|p0|p1)\b", lowered):
        score += 18
        tags.append("urgent")
    if any(hint in lowered for hint in RISK_HINTS):
        score += 12
        tags.append("risk")
    if re.search(r"\b(test|verify|check|qa)\b", lowered):
        tags.append("verification")
    if re.search(r"\b(doc|readme|guide|copy)\b", lowered):
        tags.append("docs")

    return Slice(text=line, lane=lane, score=score, tags=tuple(dict.fromkeys(tags)), source_line=line_no, reason=reason)


def render_markdown(board: Board) -> str:
    lines = [f"# {board.title}", ""]
    for lane, heading in (("now", "Now"), ("blocked", "Blocked"), ("next", "Next"), ("later", "Later")):
        items = board.lane(lane)  # type: ignore[arg-type]
        lines.append(f"## {heading}")
        if not items:
            lines.append("- No slices.")
        for item in items:
            tag_text = f" [{' '.join('#' + tag for tag in item.tags)}]" if item.tags else ""
            lines.append(f"- {item.text}{tag_text}")
            lines.append(f"  - line {item.source_line}; score {item.score}; {item.reason}")
        lines.append("")

    if board.ignored:
        lines.append("## Ignored Notes")
        for item in board.ignored:
            lines.append(f"- {item}")
        lines.append("")

    return "\n".join(lines).rstrip() + "\n"


def render_html(board: Board) -> str:
    lane_cards = []
    for lane, heading in (("now", "Now"), ("blocked", "Blocked"), ("next", "Next"), ("later", "Later")):
        items = board.lane(lane)  # type: ignore[arg-type]
        body = "\n".join(render_html_item(item) for item in items) or '<p class="empty">No slices.</p>'
        lane_cards.append(f'<section class="lane lane-{lane}"><h2>{heading}</h2>{body}</section>')

    ignored = ""
    if board.ignored:
        ignored_items = "".join(f"<li>{escape(item)}</li>" for item in board.ignored)
        ignored = f"<section class=\"ignored\"><h2>Ignored Notes</h2><ul>{ignored_items}</ul></section>"

    return f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{escape(board.title)}</title>
  <style>
    :root {{ color-scheme: light; --ink:#1b1f24; --muted:#667085; --line:#d9dee7; --now:#0f766e; --blocked:#b42318; --next:#334155; --later:#6b7280; }}
    body {{ margin:0; font:15px/1.45 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif; color:var(--ink); background:#f6f7f9; }}
    header {{ padding:28px 32px 12px; }}
    h1 {{ margin:0; font-size:28px; letter-spacing:0; }}
    main {{ display:grid; grid-template-columns:repeat(4,minmax(220px,1fr)); gap:16px; padding:16px 32px 32px; }}
    .lane {{ background:white; border:1px solid var(--line); border-radius:8px; min-height:220px; padding:14px; }}
    h2 {{ margin:0 0 12px; font-size:15px; text-transform:uppercase; letter-spacing:.04em; color:var(--muted); }}
    article {{ border-left:4px solid var(--next); background:#fbfcfe; padding:10px 10px 10px 12px; margin:0 0 10px; border-radius:6px; }}
    .lane-now article {{ border-color:var(--now); }}
    .lane-blocked article {{ border-color:var(--blocked); }}
    .lane-later article {{ border-color:var(--later); }}
    p {{ margin:0; }}
    .meta {{ color:var(--muted); font-size:12px; margin-top:8px; }}
    .tags {{ display:flex; flex-wrap:wrap; gap:4px; margin-top:8px; }}
    .tag {{ border:1px solid var(--line); border-radius:999px; padding:1px 7px; font-size:12px; color:#344054; background:white; }}
    .empty {{ color:var(--muted); }}
    .ignored {{ margin:0 32px 32px; background:white; border:1px solid var(--line); border-radius:8px; padding:14px; }}
    @media (max-width: 980px) {{ main {{ grid-template-columns:1fr 1fr; }} }}
    @media (max-width: 640px) {{ header, main {{ padding-left:16px; padding-right:16px; }} main {{ grid-template-columns:1fr; }} .ignored {{ margin-left:16px; margin-right:16px; }} }}
  </style>
</head>
<body>
  <header><h1>{escape(board.title)}</h1></header>
  <main>
    {''.join(lane_cards)}
  </main>
  {ignored}
</body>
</html>
"""


def render_html_item(item: Slice) -> str:
    tags = "".join(f'<span class="tag">{escape(tag)}</span>' for tag in item.tags)
    tag_block = f'<div class="tags">{tags}</div>' if tags else ""
    return f"""<article>
  <p>{escape(item.text)}</p>
  {tag_block}
  <p class="meta">line {item.source_line} / score {item.score} / {escape(item.reason)}</p>
</article>"""


def board_to_dict(board: Board) -> dict[str, object]:
    return {
        "title": board.title,
        "slices": [
            {
                "text": item.text,
                "lane": item.lane,
                "score": item.score,
                "tags": list(item.tags),
                "source_line": item.source_line,
                "reason": item.reason,
            }
            for item in board.slices
        ],
        "ignored": list(board.ignored),
    }


def iter_text(paths: Iterable[str]) -> str:
    chunks = []
    for path in paths:
        with open(path, "r", encoding="utf-8") as handle:
            chunks.append(handle.read())
    return "\n".join(chunks)
