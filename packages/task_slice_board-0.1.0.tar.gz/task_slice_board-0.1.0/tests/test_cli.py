from pathlib import Path

from task_slice_board.cli import main


def test_cli_writes_html(tmp_path: Path) -> None:
    source = tmp_path / "notes.md"
    output = tmp_path / "board.html"
    source.write_text("- Fix checkout bug.\n- Waiting on credentials.\n", encoding="utf-8")

    code = main([str(source), "--format", "html", "--output", str(output)])

    assert code == 0
    rendered = output.read_text(encoding="utf-8")
    assert "Fix checkout bug." in rendered
    assert "Waiting on credentials." in rendered


def test_cli_fail_on_blocked(tmp_path: Path) -> None:
    source = tmp_path / "notes.md"
    source.write_text("Waiting on approval.\n", encoding="utf-8")

    assert main([str(source), "--fail-on-blocked"]) == 2
