from task_slice_board.core import build_board, render_html, render_markdown


def test_build_board_classifies_lanes() -> None:
    board = build_board(
        """
        Fix failing test today.
        Waiting on approval from security.
        Later: add saved templates.
        The demo went well.
        """
    )

    assert [item.text for item in board.lane("now")] == ["Fix failing test today."]
    assert [item.text for item in board.lane("blocked")] == ["Waiting on approval from security."]
    assert [item.text for item in board.lane("later")] == ["Later: add saved templates."]
    assert board.ignored == ("The demo went well.",)


def test_render_markdown_includes_metadata() -> None:
    board = build_board("Fix docs typo.")
    rendered = render_markdown(board)

    assert "# Task Slice Board" in rendered
    assert "Fix docs typo." in rendered
    assert "score" in rendered


def test_render_html_escapes_input() -> None:
    board = build_board("Fix <script>alert(1)</script> docs.")
    rendered = render_html(board)

    assert "<script>" not in rendered
    assert "&lt;script&gt;" in rendered
