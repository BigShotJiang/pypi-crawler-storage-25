# Task Slice Board

![Task Slice Board desktop app](docs/task-slice-board-gui.png)

Task Slice Board turns messy work notes, issue comments, standup leftovers, and model-written plans into a compact local task board. It is useful when a note has too many bullets and you need to separate quick wins, blockers, next actions, and backlog items before starting work.

It runs fully on your machine. There are no API keys, accounts, or network calls.

## Features

- CLI for Markdown, JSON, and self-contained HTML output.
- Tkinter desktop app for pasting notes and saving boards.
- Heuristic scoring for quick wins, blockers, risky tasks, verification work, and deferred items.
- `--fail-on-blocked` mode for CI or release checklists.
- Standard-library runtime only.

## Install

```bash
python3 -m pip install task-slice-board
```

For local development:

```bash
python3 -m pip install -e .
```

## CLI

```bash
task-slice-board examples/release-notes.md
task-slice-board examples/release-notes.md --format html --output board.html
task-slice-board examples/release-notes.md --format json
task-slice-board release.md --fail-on-blocked
```

Input can also come from stdin:

```bash
pbpaste | task-slice-board --title "Friday handoff"
```

## Desktop App

```bash
task-slice-gui
```

Paste notes on the left, build the board, then save Markdown or HTML.

## Output Example

```markdown
# Task Slice Board

## Now
- Fix failing retry test before publishing. [#quick-win #verification]
  - line 3; score 93; small or direct task

## Blocked
- Waiting on API key rotation approval from platform. [#blocked #risk]
  - line 4; score 97; blocker or dependency
```

## Development

```bash
python3 -m pytest
python3 -m build --no-isolation
python3 -m twine check dist/*
```
