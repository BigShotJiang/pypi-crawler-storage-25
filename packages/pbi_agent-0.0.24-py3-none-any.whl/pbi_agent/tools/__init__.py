"""Tool registry and handlers."""
