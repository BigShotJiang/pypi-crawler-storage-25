from wopee_rf.core.domain.value_objects.wopee_payloads import (
    TrackFullpagePayload,
    TrackPayload,
    TrackViewportPayload,
)
from wopee_rf.core.services.wopee import Wopee
from wopee_rf.infrastructure.adapters.env_configuration.adapter import EnvConfiguration
from wopee_sdk.core.domain.entities.create_integration_scenario_payload import (
    CreateIntegrationScenarioPayload,
)
from wopee_sdk.core.domain.entities.create_integration_suite_payload import (
    CreateIntegrationSuitePayload,
)
from wopee_sdk.core.domain.entities.integration_step import (
    IntegrationStep,
    ValidationStatus,
)
from wopee_sdk.shared.exceptions.wopee_error import WopeeError

# D401 First line of docstring should be in imperative mood

# ruff: noqa: D401


class StandaloneImplementation:
    """Wrapper class hiding implementation detail of Standalone mode."""

    def __init__(self, *, dot_env_path: str | None = None) -> None:
        """Initialize Standalone mode."""
        env_config = EnvConfiguration(
            dot_env_path=dot_env_path,
        )
        self._wopee = Wopee(config=env_config.load_integration_config())

    def create_suite(self, *, payload: CreateIntegrationSuitePayload) -> None:
        """Create suite."""
        self._wopee.create_suite(payload=payload)

    def create_scenario(self, *, payload: CreateIntegrationScenarioPayload) -> None:
        """Create scenario."""
        self._wopee.create_scenario(payload=payload)

    def stop_scenario(self) -> None:
        """Stop scenario."""
        self._wopee.stop_scenario()

    def track(self, *, payload: TrackPayload) -> IntegrationStep:
        """Track visual validation."""
        result = self._wopee.track(payload=payload)
        self._check_hard_assert(result=result)
        return result

    def track_viewport(self, *, payload: TrackViewportPayload) -> IntegrationStep:
        """Track viewport visual validation."""
        result = self._wopee.track_viewport(payload=payload)
        self._check_hard_assert(result=result)
        return result

    def track_fullpage(self, *, payload: TrackFullpagePayload) -> IntegrationStep:
        """Track fullpage visual validation."""
        result = self._wopee.track_fullpage(payload=payload)
        self._check_hard_assert(result=result)
        return result

    def _check_hard_assert(self, *, result: IntegrationStep | None) -> None:
        if not result or self._wopee.config.enable_soft_assert:
            return
        if result.status == ValidationStatus.UNRESOLVED:
            self._wopee.stop_scenario()
            error_message = (
                "Failed due to an unresolved status during visual validation."
            )
            raise WopeeError(error_message)
        return
