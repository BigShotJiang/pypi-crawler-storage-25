import logging

from robot.api.deco import library
from wopee_rf.core.domain.value_objects.wopee_payloads import (
    TrackFullpagePayload,
    TrackPayload,
    TrackViewportPayload,
)
from wopee_sdk.core.domain.entities.create_integration_scenario_payload import (
    CreateIntegrationScenarioPayload,
)
from wopee_sdk.core.domain.entities.create_integration_suite_payload import (
    CreateIntegrationSuitePayload,
)
from wopee_sdk.core.domain.entities.integration_step import IntegrationStep

from .implementation import StandaloneImplementation

# PLR0913 Too many arguments in function definition
# D401 First line of docstring should be in imperative mood
# D400 First line should end with a period
# D415 First line should end with a period, question mark, or exclamation point

# ruff: noqa: PLR0913
# ruff: noqa: D400
# ruff: noqa: D401
# ruff: noqa: D415


logger = logging.getLogger(__name__)


@library(scope="TEST", auto_keywords=True)
class Standalone:
    """<h4>Wopee Standalone Integration for Robot Framework</h4>

    <p>This component provides integration of Wopee platform into Robot Framework,
    enhancing automation capabilities and workflow efficiency.</p>
    """

    def __init__(self, *, dot_env_path: str | None = None) -> None:
        """The configuration is provided either via enviroment variables, or via environment file (.env file).

        The list of all configuration options are listed in table below:
        <table>
            <thead>
                <tr>
                    <th>Envinromental variable</th>
                    <th>Type</th>
                    <th>Description</th>
                    <th>Default value</th>
                    <th>Mandatory</th>
                    <th>Example</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>WOPEE_ENABLE_SOFT_ASSERT</td>
                    <td>boolean</td>
                    <td>A flag to enable or disable soft assertion.</td>
                    <td>True</td>
                    <td>False</td>
                    <td>WOPEE_ENABLE_SOFT_ASSERT=True</td>
                </tr>
                <tr>
                    <td>WOPEE_ENABLE_CONSOLE_LOGS</td>
                    <td>boolean</td>
                    <td>A flag to enable or disable logging of API responses to console.</td>
                    <td>False</td>
                    <td>False</td>
                    <td>WOPEE_ENABLE_CONSOLE_LOGS=True</td>
                </tr>
                <tr>
                    <td>WOPEE_API_KEY</td>
                    <td>string</td>
                    <td>The API key required to authenticate with the Wopee platform.</td>
                    <td>None</td>
                    <td>True</td>
                    <td>WOPEE_API_KEY=12345678901234567890</td>
                </tr>
                <tr>
                    <td>WOPEE_API_URL</td>
                    <td>bool</td>
                    <td>The URL of the Wopee platform API.</td>
                    <td>https://api.wopee.io</td>
                    <td>False</td>
                    <td>WOPEE_API_URL=https://api.wopee.io</td>
                </tr>
                <tr>
                    <td>WOPEE_BRANCH_NAME</td>
                    <td>string</td>
                    <td>The name of the branch associated with the trackered data.</td>
                    <td>None</td>
                    <td>True</td>
                    <td>WOPEE_BRANCH_NAME=master</td>
                </tr>
                <tr>
                    <td>WOPEE_PROJECT_UUID</td>
                    <td>string</td>
                    <td>The UUID of the project being tracked under.</td>
                    <td>None</td>
                    <td>True</td>
                    <td>WOPEE_PROJECT_UUID=12345678901234567890</td>
                </tr>
                <tr>
                    <td>WOPEE_BROWSER</td>
                    <td>string</td>
                    <td>The browser used for tracking.</td>
                    <td>None</td>
                    <td>False</td>
                    <td>WOPEE_BROWSER=Chrome</td>
                </tr>
                <tr>
                    <td>WOPEE_COMMENT</td>
                    <td>string</td>
                    <td>Additional comment for the tracking.</td>
                    <td>None</td>
                    <td>False</td>
                    <td>WOPEE_COMMENT=Execution: https://my-report-portal/run-123</td>
                </tr>
                <tr>
                    <td>WOPEE_CUSTOM_TAGS</td>
                    <td>string</td>
                    <td>Custom tags associated with the tracking.</td>
                    <td>None</td>
                    <td>False</td>
                    <td>WOPEE_CUSTOM_TAGS=Custom tag</td>
                </tr>
                <tr>
                    <td>WOPEE_DEVICE</td>
                    <td>bool</td>
                    <td>The device used for tracking.</td>
                    <td>None</td>
                    <td>False</td>
                    <td>WOPEE_DEVICE=Lenovo T14 Gen 3/Intel</td>
                </tr>
                <tr>
                    <td>WOPEE_OS</td>
                    <td>string</td>
                    <td>The operating system used for tracking.</td>
                    <td>None</td>
                    <td>False</td>
                    <td>WOPEE_OS=GNU/Linux</td>
                </tr>
                <tr>
                    <td>WOPEE_PIXEL_TO_PIXEL_DIFF_TOLERANCE</td>
                    <td>float</td>
                    <td>Tolerance level for pixel-to-pixel differences.</td>
                    <td>None</td>
                    <td>False</td>
                    <td>WOPEE_PIXEL_TO_PIXEL_DIFF_TOLERANCE=12.34</td>
                </tr>
                <tr>
                    <td>WOPEE_VIEWPORT</td>
                    <td>string</td>
                    <td>The viewport dimensions for tracking.</td>
                    <td>None</td>
                    <td>False</td>
                    <td>WOPEE_VIEWPORT=1920x1080</td>
                </tr>
                <tr>
                    <td>WOPEE_DRIVER_LIBRARY</td>
                    <td>
                    BROWSER_LIBRARY - Represents the Browser driver.
                    NO_LIBRARY - Represents the default option (no driver).
                    SELENIUM_LIBRARY - Represents the SeleniumLibrary driver.
                    </td>
                    <td>The driver library to use for screenshot tracking.</td>
                    <td>NO_LIBRARY</td>
                    <td>False</td>
                    <td>WOPEE_DRIVER_LIBRARY=BROWSER_LIBRARY</td>
                </tr>
                <tr>
                    <td>WOPEE_SCREENSHOT_VALIDATION_ENABLED</td>
                    <td>bool</td>
                    <td>Flag indicating if screenshot validation is enabled.</td>
                    <td>False</td>
                    <td>False</td>
                    <td>WOPEE_SCREENSHOT_VALIDATION_ENABLED=True</td>
                </tr>
            </tbody>
        </table>
        """
        self._standalone = StandaloneImplementation(dot_env_path=dot_env_path)

    def start_suite(self, *, suite_name: str) -> None:
        """Create a new test suite."""
        payload = CreateIntegrationSuitePayload(suite_name=suite_name)
        self._standalone.create_suite(payload=payload)

    def start_scenario(
        self,
        *,
        scenario_name: str,
        suite_name: str | None = None,
    ) -> None:
        """Create a new test scenario."""
        payload = CreateIntegrationScenarioPayload(
            scenario_name=scenario_name,
            suite_name=suite_name,
        )
        self._standalone.create_scenario(payload=payload)

    def stop_scenario(self) -> None:
        """Stop the current test scenario."""
        self._standalone.stop_scenario()

    def track(
        self,
        *,
        image_base64: str,
        step_name: str,
        browser: str | None = None,
        comment: str | None = None,
        custom_tags: str | None = None,
        device: str | None = None,
        os: str | None = None,
        pixel_to_pixel_diff_tolerance: float | None = None,
        scenario_name: str | None = None,
        suite_name: str | None = None,
        viewport: str | None = None,
    ) -> IntegrationStep:
        """Track provided png file in base64 format into the Wopee platform without
        the dependency on Driver Library.
        """
        payload = TrackPayload(
            browser=browser,
            comment=comment,
            custom_tags=custom_tags,
            device=device,
            image_base64=image_base64,
            os=os,
            pixel_to_pixel_diff_tolerance=pixel_to_pixel_diff_tolerance,
            scenario_name=scenario_name,
            step_name=step_name,
            suite_name=suite_name,
            viewport=viewport,
        )
        return self._standalone.track(payload=payload)

    def track_viewport(
        self,
        *,
        step_name: str,
        browser: str | None = None,
        comment: str | None = None,
        custom_tags: str | None = None,
        device: str | None = None,
        os: str | None = None,
        pixel_to_pixel_diff_tolerance: float | None = None,
        scenario_name: str | None = None,
        suite_name: str | None = None,
        viewport: str | None = None,
    ) -> IntegrationStep:
        """Track the current viewport screenshot into the Wopee platform with
        aid of chosen Driver Library.
        """
        payload = TrackFullpagePayload(
            browser=browser,
            comment=comment,
            custom_tags=custom_tags,
            device=device,
            os=os,
            pixel_to_pixel_diff_tolerance=pixel_to_pixel_diff_tolerance,
            scenario_name=scenario_name,
            step_name=step_name,
            suite_name=suite_name,
            viewport=viewport,
        )
        return self._standalone.track_viewport(payload=payload)

    def track_fullpage(
        self,
        *,
        step_name: str,
        browser: str | None = None,
        comment: str | None = None,
        custom_tags: str | None = None,
        device: str | None = None,
        os: str | None = None,
        pixel_to_pixel_diff_tolerance: float | None = None,
        scenario_name: str | None = None,
        suite_name: str | None = None,
        viewport: str | None = None,
    ) -> IntegrationStep:
        """Track the current full page screenshot into the Wopee platform with
        aid of chosen Driver Library.
        """
        payload = TrackViewportPayload(
            browser=browser,
            comment=comment,
            custom_tags=custom_tags,
            device=device,
            os=os,
            pixel_to_pixel_diff_tolerance=pixel_to_pixel_diff_tolerance,
            scenario_name=scenario_name,
            step_name=step_name,
            suite_name=suite_name,
            viewport=viewport,
        )
        return self._standalone.track_fullpage(payload=payload)
