from robot.api import logger
from wopee_sdk.core.domain.entities.create_integration_scenario_payload import (
    CreateIntegrationScenarioPayload,
)
from wopee_sdk.core.domain.entities.create_integration_step_payload import (
    CreateIntegrationStepPayload,
)
from wopee_sdk.core.domain.entities.create_integration_suite_payload import (
    CreateIntegrationSuitePayload,
)
from wopee_sdk.core.domain.entities.integration_step import IntegrationStep
from wopee_sdk.infrastructure.adapters.apollo_adapter import ApolloAdapter

from wopee_rf.core.domain.configuration.driver_library import DriverLibrary
from wopee_rf.core.domain.configuration.wopee_robot_integration_config import (
    WopeeRobotIntegrationConfig,
)
from wopee_rf.core.domain.value_objects.wopee_payloads import (
    TrackFullpagePayload,
    TrackPayload,
    TrackViewportPayload,
)
from wopee_rf.core.ports.driver_port import DriverPort
from wopee_rf.infrastructure.adapters.browser_library_adapter.adapter import (
    BrowserLibraryAdapter,
)
from wopee_rf.infrastructure.adapters.no_library_adapter.adapter import NoLibraryAdapter
from wopee_rf.infrastructure.adapters.selenium_library_adapter.adapter import (
    SeleniumLibraryAdapter,
)


class Wopee:
    """Provides integration with Apollo Adapter for screenshot validation
    and tracking and DriverPort for screenshot capturing within Robot Framework tests.
    """

    def __init__(self, config: WopeeRobotIntegrationConfig) -> None:
        """Initialize the Wopee class."""
        self._config = config
        self._apollo_adapter = self._create_apollo_adapter()
        self._driver = self._create_driver()

    @property
    def config(self) -> WopeeRobotIntegrationConfig:
        """Config getter."""
        return self._config

    @property
    def api(self) -> ApolloAdapter:
        """Apollo adapter getter."""
        return self._apollo_adapter

    def _create_apollo_adapter(self) -> ApolloAdapter | None:
        """Create and return an Apollo adapter if tracking is enabled."""
        if self._config.screenshot_validation_enabled:
            return ApolloAdapter(
                config=self._config.apollo_adapter_config,
            )
        return None

    def _create_driver(self) -> DriverPort:
        """Create and return a driver based on the configured driver library."""
        if self._config.driver_library == DriverLibrary.SELENIUM_LIBRARY:
            return SeleniumLibraryAdapter()
        if self._config.driver_library == DriverLibrary.BROWSER_LIBRARY:
            return BrowserLibraryAdapter()
        return NoLibraryAdapter()

    def create_suite(self, payload: CreateIntegrationSuitePayload) -> None:
        """Create a new test suite."""
        if not self._config.screenshot_validation_enabled:
            return
        self._apollo_adapter.create_integration_suite(
            payload=payload,
        )

    def create_scenario(self, payload: CreateIntegrationScenarioPayload) -> None:
        """Create a new test scenario."""
        if not self._config.screenshot_validation_enabled:
            return
        self._apollo_adapter.create_integration_scenario(payload=payload)

    def stop_scenario(self) -> None:
        """Stop the current test scenario."""
        if not self._config.screenshot_validation_enabled:
            return
        self._apollo_adapter.stop_integration_scenario()

    def track(self, payload: TrackPayload) -> IntegrationStep | None:
        """Track an event in Apollo Tracker with the provided payload."""
        if not self._config.screenshot_validation_enabled:
            return None
        apollo_tracker_payload = CreateIntegrationStepPayload(
            **payload.model_dump(exclude_none=True),
        )
        response = self._apollo_adapter.create_integration_step(
            payload=apollo_tracker_payload,
        )
        if self._config.enable_console_logs:
            logger.info(f"\n{response}", also_console=True)
        return response

    def track_viewport(
        self,
        payload: TrackViewportPayload,
    ) -> IntegrationStep | None:
        """Track the current viewport screenshot in Apollo Tracker."""
        if not self._config.screenshot_validation_enabled or isinstance(
            self._driver,
            NoLibraryAdapter,
        ):
            return None
        screenshot = self._driver.screenshot_viewport()
        apollo_tracker_payload = CreateIntegrationStepPayload(
            **payload.model_dump(exclude_none=True),
            image_base64=screenshot.base64_str,
        )
        response = self._apollo_adapter.create_integration_step(
            payload=apollo_tracker_payload,
        )
        if self._config.enable_console_logs:
            logger.info(f"\n{response}", also_console=True)
        return response

    def track_fullpage(
        self,
        payload: TrackFullpagePayload,
    ) -> IntegrationStep | None:
        """Track the full page screenshot in Apollo Tracker."""
        if not self._config.screenshot_validation_enabled or isinstance(
            self._driver,
            NoLibraryAdapter,
        ):
            return None
        screenshot = self._driver.screenshot_fullpage()
        apollo_tracker_payload = CreateIntegrationStepPayload(
            **payload.model_dump(exclude_none=True),
            image_base64=screenshot.base64_str,
        )
        response = self._apollo_adapter.create_integration_step(
            payload=apollo_tracker_payload,
        )
        if self._config.enable_console_logs:
            logger.info(f"\n{response}", also_console=True)
        return response
