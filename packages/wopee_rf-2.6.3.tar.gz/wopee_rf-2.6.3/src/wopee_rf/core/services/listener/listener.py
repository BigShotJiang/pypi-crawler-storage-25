from robot.result.model import Keyword as KeywordResult
from robot.result.model import TestCase as TestCaseResult
from robot.result.model import TestSuite as TestSuiteResult
from robot.running.model import Keyword as KeywordModel
from robot.running.model import TestCase as TestCaseModel
from robot.running.model import TestSuite as TestSuiteModel
from wopee_rf.core.services.listener.implementation import ListenerImplementation

# D401 First line of docstring should be in imperative mood
# D415 First line should end with a period, question mark, or exclamation point
# D400 First line should end with a period

# ruff: noqa: D400
# ruff: noqa: D401
# ruff: noqa: D415


class Listener:
    """<h4>Wopee Listener for Robot Framework</h4>

    <p>This component listens to Robot Framework events and integrates seamlessly with the Wopee platform,
    enhancing automation capabilities and workflow efficiency.</p>
    """

    ROBOT_LISTENER_API_VERSION = 3

    def __init__(self, *, dot_env_path: str | None = None) -> None:
        """The configuration is provided either via enviroment variables, or via environment file (.env file).

        The list of all configuration options are listed in table below:
        <table>
            <thead>
                <tr>
                    <th>Envinromental variable</th>
                    <th>Type</th>
                    <th>Description</th>
                    <th>Default value</th>
                    <th>Mandatory</th>
                    <th>Example</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>WOPEE_ENABLE_SOFT_ASSERT</td>
                    <td>boolean</td>
                    <td>A flag to enable or disable soft assertion.</td>
                    <td>True</td>
                    <td>False</td>
                    <td>WOPEE_ENABLE_SOFT_ASSERT=True</td>
                </tr>
                <tr>
                    <td>WOPEE_ENABLE_CONSOLE_LOGS</td>
                    <td>boolean</td>
                    <td>A flag to enable or disable logging of API responses to console.</td>
                    <td>False</td>
                    <td>False</td>
                    <td>WOPEE_ENABLE_CONSOLE_LOGS=True</td>
                </tr>
                <tr>
                    <td>WOPEE_EXECUTION_NAME</td>
                    <td>string</td>
                    <td>Execution name which links all scenarios from a run.</td>
                    <td>[]</td>
                    <td>False</td>
                    <td>WOPEE_EXECUTION_NAME=Run-123-24-09-2024</td>
                </tr>
                <tr>
                    <td>WOPEE_TRACKED_KEYWORDS</td>
                    <td>string</td>
                    <td>A list of keywords to be tracked by the listener.</td>
                    <td>[]</td>
                    <td>False</td>
                    <td>WOPEE_TRACKED_KEYWORDS=SeleniumLibrary.Open Browser;BuiltIn.Log;</td>
                </tr>
                <tr>
                    <td>WOPEE_API_KEY</td>
                    <td>string</td>
                    <td>The API key required to authenticate with the Wopee platform.</td>
                    <td>None</td>
                    <td>True</td>
                    <td>WOPEE_API_KEY=12345678901234567890</td>
                </tr>
                <tr>
                    <td>WOPEE_API_URL</td>
                    <td>bool</td>
                    <td>The URL of the Wopee platform API.</td>
                    <td>https://api.wopee.io</td>
                    <td>False</td>
                    <td>WOPEE_API_URL=https://api.wopee.io</td>
                </tr>
                <tr>
                    <td>WOPEE_BRANCH_NAME</td>
                    <td>string</td>
                    <td>The name of the branch associated with the trackered data.</td>
                    <td>None</td>
                    <td>True</td>
                    <td>WOPEE_BRANCH_NAME=master</td>
                </tr>
                <tr>
                    <td>WOPEE_PROJECT_UUID</td>
                    <td>string</td>
                    <td>The UUID of the project being tracked under.</td>
                    <td>None</td>
                    <td>True</td>
                    <td>WOPEE_PROJECT_UUID=12345678901234567890</td>
                </tr>
                <tr>
                    <td>WOPEE_BROWSER</td>
                    <td>string</td>
                    <td>The browser used for tracking.</td>
                    <td>None</td>
                    <td>False</td>
                    <td>WOPEE_BROWSER=Chrome</td>
                </tr>
                <tr>
                    <td>WOPEE_COMMENT</td>
                    <td>string</td>
                    <td>Additional comment for the tracking.</td>
                    <td>None</td>
                    <td>False</td>
                    <td>WOPEE_COMMENT=Execution: https://my-report-portal/run-123</td>
                </tr>
                <tr>
                    <td>WOPEE_CUSTOM_TAGS</td>
                    <td>string</td>
                    <td>Custom tags associated with the tracking.</td>
                    <td>None</td>
                    <td>False</td>
                    <td>WOPEE_CUSTOM_TAGS=Custom tag</td>
                </tr>
                <tr>
                    <td>WOPEE_DEVICE</td>
                    <td>bool</td>
                    <td>The device used for tracking.</td>
                    <td>None</td>
                    <td>False</td>
                    <td>WOPEE_DEVICE=Lenovo T14 Gen 3/Intel</td>
                </tr>
                <tr>
                    <td>WOPEE_OS</td>
                    <td>string</td>
                    <td>The operating system used for tracking.</td>
                    <td>None</td>
                    <td>False</td>
                    <td>WOPEE_OS=GNU/Linux</td>
                </tr>
                <tr>
                    <td>WOPEE_PIXEL_TO_PIXEL_DIFF_TOLERANCE</td>
                    <td>float</td>
                    <td>Tolerance level for pixel-to-pixel differences.</td>
                    <td>None</td>
                    <td>False</td>
                    <td>WOPEE_PIXEL_TO_PIXEL_DIFF_TOLERANCE=12.34</td>
                </tr>
                <tr>
                    <td>WOPEE_VIEWPORT</td>
                    <td>string</td>
                    <td>The viewport dimensions for tracking.</td>
                    <td>None</td>
                    <td>False</td>
                    <td>WOPEE_VIEWPORT=1920x1080</td>
                </tr>
                <tr>
                    <td>WOPEE_DRIVER_LIBRARY</td>
                    <td>
                    BROWSER_LIBRARY - Represents the Browser driver.
                    NO_LIBRARY - Represents the default option (no driver).
                    SELENIUM_LIBRARY - Represents the SeleniumLibrary driver.
                    </td>
                    <td>The driver library to use for screenshot tracking.</td>
                    <td>NO_LIBRARY</td>
                    <td>False</td>
                    <td>WOPEE_DRIVER_LIBRARY=BROWSER_LIBRARY</td>
                </tr>
                <tr>
                    <td>WOPEE_SCREENSHOT_VALIDATION_ENABLED</td>
                    <td>bool</td>
                    <td>Flag indicating if screenshot validation is enabled.</td>
                    <td>False</td>
                    <td>False</td>
                    <td>WOPEE_SCREENSHOT_VALIDATION_ENABLED=True</td>
                </tr>
            </tbody>
        </table>
        """
        self._listener = ListenerImplementation(dot_env_path=dot_env_path)

    def start_suite(self, suite: TestSuiteModel, _: TestSuiteResult) -> None:
        """Handle the start of suite event."""
        self._listener.start_suite(suite=suite)

    def start_test(self, test: TestCaseModel, _: TestCaseResult) -> None:
        """Handle the start of the test event."""
        self._listener.start_test(test=test)

    def end_test(self, _: TestCaseModel, result: TestCaseResult) -> None:
        """Handle the end of test event."""
        self._listener.end_test(result=result)

    def start_keyword(self, _: KeywordModel, __: KeywordResult) -> None:
        """Handle the start of keyword event."""
        self._listener.start_keyword()

    def end_keyword(self, _: KeywordModel, result: KeywordResult) -> None:
        """Handle the end of keyword event."""
        self._listener.end_keyword(result=result)
