from typing import TYPE_CHECKING

from robot.result.model import Keyword as KeywordResult
from robot.result.model import TestCase as TestCaseResult
from robot.running.model import TestCase as TestCaseModel
from robot.running.model import TestSuite as TestSuiteModel
from wopee_rf.core.domain.value_objects.wopee_payloads import (
    TrackFullpagePayload,
)
from wopee_rf.core.services.wopee import Wopee
from wopee_rf.infrastructure.adapters.env_configuration.adapter import EnvConfiguration
from wopee_sdk.core.domain.entities.create_integration_scenario_payload import (
    CreateIntegrationScenarioPayload,
)
from wopee_sdk.core.domain.entities.create_integration_suite_payload import (
    CreateIntegrationSuitePayload,
)
from wopee_sdk.core.domain.entities.integration_step import (
    ValidationStatus,
)

if TYPE_CHECKING:
    from wopee_rf.core.domain.configuration.wopee_robot_integration_listener_config import (
        WopeeRobotIntegrationListenerConfig,
    )


class ListenerImplementation:
    """Wrapper class hiding implementation detail of Listener mode."""

    def __init__(
        self: "ListenerImplementation",
        *,
        dot_env_path: str | None = None,
    ) -> None:
        """Initialize Listener mode."""
        self._dot_env_path: str | None = dot_env_path

        self._config: WopeeRobotIntegrationListenerConfig = None
        self._wopee: Wopee = None
        self._tracked_keyword_counter = None
        self._keyword_fail = None

    def start_suite(self: "ListenerImplementation", suite: TestSuiteModel) -> None:
        """Start suite."""
        env_config = EnvConfiguration(
            dot_env_path=self._dot_env_path,
        )
        self._config = env_config.load_listener_config()

        self._wopee = Wopee(config=env_config.load_integration_config())

        if self._wopee.config.screenshot_validation_enabled:
            suite_name = (
                self._config.execution_name
                if self._config.execution_name
                else suite.name
            )
            payload = CreateIntegrationSuitePayload(suite_name=suite_name)
            self._wopee.create_suite(payload=payload)

    def start_test(self: "ListenerImplementation", test: TestCaseModel) -> None:
        """Start test."""
        self._tracked_keyword_counter = 0
        self._keyword_fail = False

        if self._wopee.config.screenshot_validation_enabled:
            payload = CreateIntegrationScenarioPayload(scenario_name=test.name)
            self._wopee.create_scenario(payload=payload)

    def end_test(self: "ListenerImplementation", result: TestCaseResult) -> None:
        """End test."""
        if self._keyword_fail and not self._wopee.config.enable_soft_assert:
            result.status = "FAIL"
            result.message = (
                "Failed due to an unresolved status during visual validation."
            )

        if self._wopee.config.screenshot_validation_enabled:
            self._wopee.stop_scenario()

    def start_keyword(self: "ListenerImplementation") -> None:
        """Start keyword.

        Needs to happen in order to end_keyword is listen for.
        """
        return

    def end_keyword(self: "ListenerImplementation", result: KeywordResult) -> None:
        """End keyword."""
        keyword_full_name = result.full_name
        if (
            keyword_full_name in self._config.tracked_keywords
            and self._wopee.config.screenshot_validation_enabled
        ):
            self._tracked_keyword_counter += 1

            step_name = f"{keyword_full_name}-{self._tracked_keyword_counter}"

            payload = TrackFullpagePayload(step_name=step_name)
            track_result = self._wopee.track_fullpage(payload=payload)

            if not track_result or self._wopee.config.enable_soft_assert:
                return
            if track_result.status == ValidationStatus.UNRESOLVED:
                result.status = "FAIL"
                self._keyword_fail = True
