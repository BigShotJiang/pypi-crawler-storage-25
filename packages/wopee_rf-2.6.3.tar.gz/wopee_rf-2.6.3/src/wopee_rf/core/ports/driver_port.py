from abc import ABC, abstractmethod

from wopee_rf.core.domain.value_objects.screenshot import Screenshot


class DriverPort(ABC):
    """Abstract base class for driver ports that define methods to capture screenshots."""

    def screenshot_viewport(self: "DriverPort") -> Screenshot:
        """Capture a screenshot of the current viewport.

        Returns
        -------
            Screenshot: An object containing the screenshot data.

        """
        return self._screenshot_viewport()

    @abstractmethod
    def _screenshot_viewport(self: "DriverPort") -> Screenshot:
        raise NotImplementedError

    def screenshot_fullpage(self: "DriverPort") -> Screenshot:
        """Capture a full-page screenshot by scrolling through the entire page.

        Returns
        -------
            Screenshot: An object containing the full-page screenshot data.

        """
        return self._screenshot_fullpage()

    @abstractmethod
    def _screenshot_fullpage(self: "DriverPort") -> Screenshot:
        raise NotImplementedError
