from abc import ABC, abstractmethod

from wopee_rf.core.domain.configuration.wopee_robot_integration_config import (
    WopeeRobotIntegrationConfig,
)
from wopee_rf.core.domain.configuration.wopee_robot_integration_listener_config import (
    WopeeRobotIntegrationListenerConfig,
)


class ConfigurationPort(ABC):
    """Abstract base class for configuration ports that define methods to load configurations."""

    def load_integration_config(
        self: "ConfigurationPort",
    ) -> WopeeRobotIntegrationConfig:
        """Load the integration configuration.

        Returns
        -------
            WopeeRobotIntegrationConfig: The loaded configuration object.

        """
        return self._load_integration_config()

    @abstractmethod
    def _load_integration_config(
        self: "ConfigurationPort",
    ) -> WopeeRobotIntegrationConfig:
        raise NotImplementedError

    def load_listener_config(
        self: "ConfigurationPort",
    ) -> WopeeRobotIntegrationListenerConfig:
        """Load the listener configuration.

        Returns
        -------
            WopeeRobotIntegrationListenerConfig: The loaded configuration object.

        """
        return self._load_listener_config()

    @abstractmethod
    def _load_listener_config(
        self: "ConfigurationPort",
    ) -> WopeeRobotIntegrationListenerConfig:
        raise NotImplementedError
