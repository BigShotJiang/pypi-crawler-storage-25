from pydantic import BaseModel, ConfigDict


class TrackPayloadBase(BaseModel):
    """Base payload for tracking various parameters.

    Attributes
    ----------
        browser (str | None): The browser used for the test. Default is None.
        comment (str | None): Any additional comments. Default is None.
        custom_tags (str | None): Custom tags for the test. Default is None.
        device (str | None): The device used for the test. Default is None.
        os (str | None): The operating system used for the test. Default is None.
        pixel_to_pixel_diff_tolerance (float | None): Tolerance for pixel-to-pixel difference. Default is None.
        scenario_name (str | None): The name of the scenario. Default is None.
        step_name (str): The name of the step in the scenario.
        viewport (str | None): The viewport size. Default is None.
        suite_name (str | None): The name of the test suite. Default is None.

    """

    model_config = ConfigDict(extra="forbid")

    browser: str | None = None
    comment: str | None = None
    custom_tags: str | None = None
    device: str | None = None
    os: str | None = None
    pixel_to_pixel_diff_tolerance: float | None = None
    scenario_name: str | None = None
    step_name: str
    viewport: str | None = None
    suite_name: str | None = None


class TrackPayload(TrackPayloadBase):
    """Payload for tracking test steps with an image.

    Attributes
    ----------
        image_base64 (str): The base64-encoded image.

    """

    image_base64: str


class TrackViewportPayload(TrackPayloadBase):
    """Payload for tracking viewport-based test steps."""


class TrackFullpagePayload(TrackPayloadBase):
    """Payload for tracking fullpage-based test steps."""
