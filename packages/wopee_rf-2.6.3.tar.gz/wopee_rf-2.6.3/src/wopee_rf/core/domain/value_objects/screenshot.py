from pydantic import BaseModel, ConfigDict


class Screenshot(BaseModel):
    """Model representing a screenshot.

    Attributes
    ----------
        base64_str (str): Base64 encoded string of the screenshot image.

    """

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

    base64_str: str
