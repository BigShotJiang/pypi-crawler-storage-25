from pydantic import BaseModel, ConfigDict


class WopeeRobotIntegrationListenerConfig(BaseModel):
    """Configuration model for the Wopee Robot Integration Listener.

    Attributes
    ----------
        execution_name (str): A name of execution which overloads default options (suite name).
        tracked_keywords (list[str]): A list of keywords to be tracked by the listener.
            Defaults to an empty list.

    """

    model_config = ConfigDict(
        extra="forbid",
        validate_assignment=True,
        validate_default=True,
        use_enum_values=True,
    )

    execution_name: str | None = None
    tracked_keywords: list[str] = []
