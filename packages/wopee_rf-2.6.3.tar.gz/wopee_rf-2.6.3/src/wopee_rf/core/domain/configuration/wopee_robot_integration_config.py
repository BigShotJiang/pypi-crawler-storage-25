from pydantic import BaseModel, ConfigDict
from wopee_rf.core.domain.configuration.driver_library import DriverLibrary
from wopee_sdk.infrastructure.adapters.apollo_adapter.interface import (
    ApolloAdapterConfig,
)


class WopeeRobotIntegrationConfig(BaseModel):
    """Configuration class for Wopee Robot Integration.

    Attributes
    ----------
        apollo_adapter_config (ApolloAdapterConfig | None): Configuration for Apollo Tracker Adapter.
        driver_library (DriverLibrary): The driver library to use, defaults to SeleniumLibrary.
        screenshot_validation_enabled (bool): Flag indicating if screenshot validation is enabled, defaults to False.
        enable_console_logs (bool): Flag indicating if API responses should be logged to console, defaults to False.

    """

    model_config = ConfigDict(
        extra="forbid",
        validate_assignment=True,
        validate_default=True,
        use_enum_values=True,
    )

    apollo_adapter_config: ApolloAdapterConfig | None = None

    driver_library: DriverLibrary = DriverLibrary.NO_LIBRARY
    enable_soft_assert: bool = True
    screenshot_validation_enabled: bool = False
    enable_console_logs: bool = False
