from enum import StrEnum


class DriverLibrary(StrEnum):
    """Enumeration for different driver libraries.

    Attributes
    ----------
    BROWSER_LIBRARY : str
        Represents the BrowserLibrary driver.
    NO_LIBRARY : str
        Represents the default option (no driver).
    SELENIUM_LIBRARY : str
        Represents the SeleniumLibrary driver.

    """

    BROWSER_LIBRARY = "BrowserLibrary"
    NO_LIBRARY = "NoLibrary"
    SELENIUM_LIBRARY = "SeleniumLibrary"
