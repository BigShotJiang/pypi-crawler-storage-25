from abc import abstractmethod

from wopee_rf.core.ports.driver_port import DriverPort


class WebBrowserAdapter(DriverPort):
    """Abstract base class representing a web browser adapter.

    Provides methods to interact with the web browser for tasks such as
    scrolling and obtaining the current height of the browser window.

    """

    def _current_height(self: "WebBrowserAdapter") -> int:
        """Return the current height of the browser window.

        Returns
        -------
        int
            The current height of the browser window.

        """
        return self._current_height_()

    @abstractmethod
    def _current_height_(self: "WebBrowserAdapter") -> int:
        raise NotImplementedError

    def _scroll_by(self: "WebBrowserAdapter", *, by: int) -> None:
        """Scrolls the browser window by the specified amount.

        Parameters
        ----------
        by : int
            The amount to scroll by.

        """
        return self._scroll_by_(by=by)

    @abstractmethod
    def _scroll_by_(self: "WebBrowserAdapter", *, by: int) -> None:
        raise NotImplementedError

    def _scroll_to_top(self: "WebBrowserAdapter") -> None:
        """Scroll the browser window to the top."""
        return self._scroll_to_top_()

    @abstractmethod
    def _scroll_to_top_(self: "WebBrowserAdapter") -> None:
        raise NotImplementedError

    def _scroll_down_and_up(
        self: "WebBrowserAdapter",
        *,
        delta_y: int = 1000,
    ) -> int:
        """Scrolls down the browser window by increments of `delta_y` until the maximum
        height is reached, then scrolls back to the top.

        Parameters
        ----------
        delta_y : int, optional
            The amount to scroll by each increment, by default 1000.

        Returns
        -------
        int
            The maximum height reached.

        """
        current_height = self._current_height()
        max_height = 0
        max_scroll_downs = 50
        n_scrolls = 0
        while current_height != max_height:
            n_scrolls += 1
            current_height = max_height
            self._scroll_by(by=delta_y)
            max_height = self._current_height()
            if n_scrolls > max_scroll_downs:
                break
        self._scroll_to_top()
        return max_height
