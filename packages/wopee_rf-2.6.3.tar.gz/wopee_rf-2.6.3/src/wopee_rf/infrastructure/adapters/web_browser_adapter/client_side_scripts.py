scroll_height_js_code = """
    const viewPortHeight = Math.max(document.documentElement.clientHeight, window.innerHeight || 0);

    // Get the scroll height of the document's root element (usually the <html> element)
    const scrollHeight = document.documentElement.scrollHeight;

    const bodyScrollHeight = document.body.scrollHeight;

    // In some situations, the default scroll height can be equal to the viewport height,
    // but the body scroll height can be different. In such cases, return the body scroll height.
    if (viewPortHeight === scrollHeight && bodyScrollHeight > scrollHeight) {
        return bodyScrollHeight;
    }

    // In some cases, determining the page height can be challenging,
    // for example, when using a 'vh' property on the body element.
    // If that's the case, we need to traverse all elements and find the tallest one,
    // which is a time-consuming operation.
    let pageHeight = 0;
    let largestNodeElement = document.querySelector('body');

    if (bodyScrollHeight === scrollHeight && bodyScrollHeight === viewPortHeight) {
        findHighestNode(document.documentElement.childNodes);

        // There could be some elements above this largest element;
        // add their heights to the result.
        return pageHeight + largestNodeElement.getBoundingClientRect().top;
    }

    // The scrollHeight is accurate enough, return it.
    return scrollHeight;

    /**
     * This function finds the largest HTML element on the page.
     * @param nodesList - List of nodes to search through.
     */
    function findHighestNode(nodesList) {
        for (let i = nodesList.length - 1; i >= 0; i--) {
            const currentNode = nodesList[i];

            if (currentNode.scrollHeight && currentNode.clientHeight) {
                const elHeight = Math.max(currentNode.scrollHeight, currentNode.clientHeight);
                pageHeight = Math.max(elHeight, pageHeight);
                if (elHeight === pageHeight) {
                    largestNodeElement = currentNode;
                }
            }

            if (currentNode.childNodes.length) {
                findHighestNode(currentNode.childNodes);
            }
        }
    }
"""
