import logging

from wopee_rf.core.domain.value_objects.screenshot import Screenshot
from wopee_rf.core.ports.driver_port import DriverPort

logger = logging.getLogger(__name__)


class NoLibraryAdapter(DriverPort):
    """Adapter class for a web browser without a specific library.

    This class implements the DriverPort interface but does not perform any actions.
    It serves as a placeholder or mock implementation.
    """

    def __init__(self: "NoLibraryAdapter") -> None:
        """Initialize the NoLibraryAdapter. Does nothing."""

    def _current_height_(self: "NoLibraryAdapter") -> int:
        """Retrieve the current height of the web page. Does nothing."""

    def _screenshot_fullpage(self: "NoLibraryAdapter") -> Screenshot:
        """Take a screenshot of the entire web page. Does nothing."""

    def _screenshot_viewport(self: "NoLibraryAdapter") -> Screenshot:
        """Take a screenshot of the current viewport. Does nothing."""

    def _scroll_by_(self: "NoLibraryAdapter", *, _: int) -> None:
        """Scroll the web page by a specified number of pixels. Does nothing."""

    def _scroll_to_top_(self: "NoLibraryAdapter") -> None:
        """Scroll to the top of the web page. Does nothing."""
