import base64
import logging
from pathlib import Path
from typing import TYPE_CHECKING

from robot.libraries.BuiltIn import BuiltIn
from wopee_rf.core.domain.value_objects.screenshot import Screenshot
from wopee_rf.infrastructure.adapters.web_browser_adapter.client_side_scripts import (
    scroll_height_js_code,
)
from wopee_rf.infrastructure.adapters.web_browser_adapter.adapter import (
    WebBrowserAdapter,
)

if TYPE_CHECKING:
    from SeleniumLibrary import SeleniumLibrary

logger = logging.getLogger(__name__)

# ruff: noqa: I001


class SeleniumLibraryAdapter(WebBrowserAdapter):
    """Adapter class to integrate SeleniumLibrary with the WebBrowserAdapter interface.
    Provides methods to interact with the SeleniumLibrary for browser automation tasks.
    """

    def __init__(self: "SeleniumLibraryAdapter") -> None:
        """Initialize the SeleniumLibraryAdapter by getting an instance of SeleniumLibrary.

        Raises
        ------
        RuntimeError
            If SeleniumLibrary is not initialized.

        """
        try:
            self._selenium_library: SeleniumLibrary = BuiltIn().get_library_instance(
                "SeleniumLibrary",
            )
        except:  # noqa: E722
            logger.critical("SeleniumLibrary is not initialized.")

    def _selenium_screenshot(self: "SeleniumLibraryAdapter") -> Screenshot:
        """Capture a screenshot using SeleniumLibrary and encodes it in base64 format.

        Returns
        -------
        Screenshot
            An object containing the base64 encoded screenshot.

        """
        screenshot_root_directory = self._selenium_library.screenshot_root_directory
        self._selenium_library.set_screenshot_directory("screenshots/selenium")
        path_to_screenshot = self._selenium_library.capture_page_screenshot()
        self._selenium_library.set_screenshot_directory(screenshot_root_directory)

        with Path(path_to_screenshot).open(mode="rb") as file:
            image_base64 = base64.b64encode(file.read()).decode("utf-8")
        return Screenshot(base64_str=image_base64)

    def _screenshot_viewport(self: "SeleniumLibraryAdapter") -> Screenshot:
        """Capture a screenshot of the current viewport.

        Returns
        -------
        Screenshot
            An object containing the base64 encoded screenshot of the viewport.

        """
        return self._selenium_screenshot()

    def _get_window_size(self: "SeleniumLibraryAdapter") -> tuple[int, int]:
        """Get the current window size.

        Returns
        -------
        tuple
            A tuple containing the width and height of the window.

        """
        raw_window_size = self._selenium_library.get_window_size()
        return int(raw_window_size[0]), int(raw_window_size[1])

    def _set_window_size(
        self: "SeleniumLibraryAdapter",
        *,
        width: int,
        height: int,
    ) -> None:
        """Set the window size to the specified width and height.

        Parameters
        ----------
        width : int
            The desired width of the window.
        height : int
            The desired height of the window.

        """
        self._selenium_library.set_window_size(width=width, height=height)

    def _current_height_(self: "SeleniumLibraryAdapter") -> int:
        """Get the current height of the web page by executing JavaScript.

        Returns
        -------
        int
            The height of the web page.

        """
        return int(
            self._selenium_library.execute_javascript(
                f"""return (function() {{
                {scroll_height_js_code}
                }})();
                """,
            ),
        )

    def _scroll_by_(self: "SeleniumLibraryAdapter", *, by: int) -> None:
        """Scrolls the window by the specified number of pixels.

        Parameters
        ----------
        by : int
            The number of pixels to scroll by.

        """
        self._selenium_library.execute_javascript(f"window.scrollBy(0, {by})")

    def _scroll_to_top_(self: "SeleniumLibraryAdapter") -> None:
        """Scroll to the top of the web page."""
        self._selenium_library.execute_javascript("window.scrollBy(0, 0)")

    def _screenshot_fullpage(self: "SeleniumLibraryAdapter") -> Screenshot:
        """Capture a full-page screenshot by scrolling through the entire page.

        Returns
        -------
        Screenshot
            An object containing the base64 encoded full-page screenshot.

        """
        test_width, test_height = self._get_window_size()
        max_height = self._scroll_down_and_up()
        self._set_window_size(width=test_width, height=max_height)
        screenshot = self._selenium_screenshot()
        self._set_window_size(width=test_width, height=test_height)
        return screenshot
