import logging
from typing import TYPE_CHECKING

from robot.libraries.BuiltIn import BuiltIn
from wopee_rf.core.domain.value_objects.screenshot import Screenshot
from wopee_rf.infrastructure.adapters.web_browser_adapter.client_side_scripts import (
    scroll_height_js_code,
)
from wopee_rf.infrastructure.adapters.web_browser_adapter.adapter import (
    WebBrowserAdapter,
)

from Browser.utils.data_types import ScreenshotFileTypes, ScreenshotReturnType

if TYPE_CHECKING:
    from Browser import Browser

logger = logging.getLogger(__name__)


# E722 Do not use bare `except`

# ruff: noqa: I001


class BrowserLibraryAdapter(WebBrowserAdapter):
    """Adapter class for the Browser library, providing implementation for web browser operations."""

    def __init__(self: "BrowserLibraryAdapter") -> None:
        """Initialize the BrowserLibraryAdapter and sets up the Browser library instance.

        Raises
        ------
        Exception
            If the Browser library instance cannot be initialized.

        """
        try:
            self._browser_library: Browser = BuiltIn().get_library_instance(
                "Browser",
            )
        except:  # noqa: E722
            logger.critical("SeleniumLibrary is not initialized.")

    def _browser_screenshot(
        self: "BrowserLibraryAdapter",
        *,
        full_page: bool,
    ) -> Screenshot:
        """Take a screenshot of the current browser window.

        Parameters
        ----------
        full_page : bool
            Whether to take a full-page screenshot.

        Returns
        -------
        Screenshot
            The screenshot of the current browser window in base64 format.

        """
        screenshot_base64 = self._browser_library.take_screenshot(
            disableAnimations=True,
            fileType=ScreenshotFileTypes.png,
            fullPage=full_page,
            return_as=ScreenshotReturnType.base64,
        )
        return Screenshot(base64_str=screenshot_base64)

    def _screenshot_viewport(self: "BrowserLibraryAdapter") -> Screenshot:
        """Take a screenshot of the current viewport of the browser window.

        Returns
        -------
        Screenshot
            The screenshot of the current viewport in base64 format.

        """
        return self._browser_screenshot(full_page=False)

    def _current_height_(self: "BrowserLibraryAdapter") -> int:
        """Return the current height of the browser window.

        Returns
        -------
        int
            The current height of the browser window.

        """
        return int(
            self._browser_library.evaluate_javascript(
                None,
                f"""() => {{
            {scroll_height_js_code}
            }}""",
            ),
        )

    def _scroll_by_(self: "BrowserLibraryAdapter", *, by: int) -> None:
        """Scrolls the browser window by the specified amount.

        Parameters
        ----------
        by : int
            The amount to scroll by.

        """
        self._browser_library.evaluate_javascript(None, f"window.scrollBy(0, {by})")

    def _scroll_to_top_(self: "BrowserLibraryAdapter") -> None:
        """Scroll the browser window to the top."""
        self._browser_library.evaluate_javascript(None, "window.scrollTo(0, 0)")

    def _screenshot_fullpage(self: "BrowserLibraryAdapter") -> Screenshot:
        """Take a full-page screenshot of the browser window.

        Returns
        -------
        Screenshot
            The full-page screenshot in base64 format.

        """
        _ = self._scroll_down_and_up()
        return self._browser_screenshot(full_page=True)
