import logging
import sys

from dotenv import load_dotenv
from pydantic import ValidationError
from wopee_rf.core.domain.configuration.wopee_robot_integration_config import (
    WopeeRobotIntegrationConfig,
)
from wopee_rf.core.domain.configuration.wopee_robot_integration_listener_config import (
    WopeeRobotIntegrationListenerConfig,
)
from wopee_rf.core.ports.configuration_port import ConfigurationPort
from wopee_rf.infrastructure.adapters.env_configuration.interface import (
    ENV_PREFIX,
    ApolloAdapterConfigDTO,
    WopeeRobotIntegrationConfigTopLevelDTO,
    WopeeRobotIntegrationListenerConfigDTO,
)
from wopee_sdk.infrastructure.adapters.apollo_adapter.interface import (
    ApolloAdapterConfig,
)

logger = logging.getLogger(__name__)


class EnvConfiguration(ConfigurationPort):
    """Environment configuration class to load settings from a .env file and validate them.
    Implements the ConfigurationPort interface.
    """

    def __init__(self: "EnvConfiguration", *, dot_env_path: str | None = None) -> None:
        """Initialize the EnvConfiguration by loading the .env file.

        Args:
        ----
            dot_env_path (str): Path to the .env file.

        """
        if dot_env_path:
            load_dotenv(dot_env_path)

    def _load_integration_config(
        self: "EnvConfiguration",
    ) -> WopeeRobotIntegrationConfig:
        """Load the integration configuration by combining top level properties and Apollo tracker adapter config.

        Returns
        -------
            WopeeRobotIntegrationConfig: The loaded configuration object.

        """
        top_level_properties = self._load_top_level_properties()

        apollo_adapter_config = None
        if top_level_properties.screenshot_validation_enabled:
            apollo_adapter_config = ApolloAdapterConfig(
                **self._load_apollo_adapter_config().model_dump(
                    exclude_none=True,
                ),
            )

        return WopeeRobotIntegrationConfig(
            apollo_adapter_config=apollo_adapter_config,
            **top_level_properties.model_dump(exclude_none=True),
        )

    def _load_top_level_properties(
        self: "EnvConfiguration",
    ) -> WopeeRobotIntegrationConfigTopLevelDTO:
        """Load the top-level properties from the environment.

        Returns
        -------
            TopLevelPropertiesDTO: The loaded top-level properties.

        Raises
        ------
            ValidationError: If validation of the properties fails.

        """
        try:
            return WopeeRobotIntegrationConfigTopLevelDTO()
        except ValidationError as error:
            self._pretty_print_validation_error(error=error)

    def _load_apollo_adapter_config(
        self: "EnvConfiguration",
    ) -> ApolloAdapterConfigDTO:
        """Load the Apollo tracker adapter configuration from the environment.

        Returns
        -------
            ApolloAdapterConfigDTO: The loaded Apollo tracker adapter configuration.

        Raises
        ------
            ValidationError: If validation of the configuration fails.

        """
        try:
            return ApolloAdapterConfigDTO()
        except ValidationError as error:
            self._pretty_print_validation_error(error=error)

    def _load_listener_config(
        self: "EnvConfiguration",
    ) -> WopeeRobotIntegrationListenerConfig:
        """Load the listener configuration by combining top level properties and Apollo tracker adapter config.

        Returns
        -------
            WopeeRobotIntegrationConfig: The loaded configuration object.

        """
        return WopeeRobotIntegrationListenerConfig(
            **self._load_wopee_robot_integration_listener_config().model_dump(
                exclude_none=True,
            ),
        )

    def _load_wopee_robot_integration_listener_config(
        self: "EnvConfiguration",
    ) -> WopeeRobotIntegrationListenerConfigDTO:
        try:
            return WopeeRobotIntegrationListenerConfigDTO()
        except ValidationError as error:
            self._pretty_print_validation_error(error=error)

    def _pretty_print_validation_error(
        self: "EnvConfiguration",
        *,
        error: ValidationError,
    ) -> None:
        """Log the validation error details and exits the program.

        Args:
        ----
            error (ValidationError): The validation error to log.

        """
        for e in error.errors():
            error_type = e["type"]
            error_loc = e["loc"][0]
            error_msg = e["msg"]
            logger.critical(
                "Environment variable: %s%s (%s: %s)",
                ENV_PREFIX,
                error_loc.upper(),
                error_type,
                error_msg,
            )
        sys.exit(1)
