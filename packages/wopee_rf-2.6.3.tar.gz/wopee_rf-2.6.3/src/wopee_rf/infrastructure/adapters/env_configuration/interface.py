from pydantic import field_validator
from pydantic_settings import (
    BaseSettings,
    SettingsConfigDict,
)
from wopee_rf.core.domain.configuration.driver_library import DriverLibrary
from wopee_sdk.infrastructure.adapters.apollo_adapter.interface import (
    ApolloAdapterConfig,
)

ENV_PREFIX = "WOPEE_"


# D101 Missing docstring in public class
# ANN102 Missing type annotation for `cls` in classmethod
# ruff: noqa: D101
# ruff: noqa: ANN102


class ApolloAdapterConfigDTO(BaseSettings, ApolloAdapterConfig):
    model_config = SettingsConfigDict(extra="ignore", env_prefix=ENV_PREFIX)


class WopeeRobotIntegrationConfigTopLevelDTO(BaseSettings):
    model_config = SettingsConfigDict(extra="ignore", env_prefix=ENV_PREFIX)

    driver_library: DriverLibrary | None = None
    enable_soft_assert: bool | None = None
    screenshot_validation_enabled: bool | None = None
    enable_console_logs: bool | None = None


class WopeeRobotIntegrationListenerConfigDTO(BaseSettings):
    model_config = SettingsConfigDict(extra="ignore", env_prefix=ENV_PREFIX)

    execution_name: str | None = None
    tracked_keywords: list[str] | str | None = None

    @field_validator("tracked_keywords")
    @classmethod
    def _validate_tracked_keywords(
        cls: type["WopeeRobotIntegrationListenerConfigDTO"],
        v: list[str] | str | None,
    ) -> list[str] | None:
        if isinstance(v, str):
            return v.strip(";").split(";")
        return v
