__version__ = "__LOCAL__"
__hash__ = "__LOCAL__"

from wopee_rf.core.services.listener.listener import Listener
from wopee_rf.core.services.standalone.standalone import Standalone

__all__ = ["Standalone", "Listener"]
