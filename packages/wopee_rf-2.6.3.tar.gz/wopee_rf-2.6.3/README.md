# Wopee.io Visual Testing for Robot Framework

Catch visual regressions in your [Robot Framework](https://robotframework.org/) tests with AI-powered autonomous test maintenance by [Wopee.io](https://wopee.io).

## Installation

```bash
pip install wopee_rf
```

## Quick Start

Set your environment variables:

```bash
export WOPEE_API_URL=https://api.wopee.io
export WOPEE_API_KEY=your-api-key
export WOPEE_PROJECT_UUID=your-project-id
```

### Using as a Listener

```robot
*** Settings ***
Library    SeleniumLibrary

*** Test Cases ***
Visual Check Homepage
    Open Browser    https://example.com    chrome
    wopee_rf.Track Full Page
    Close Browser
```

Run with the listener:

```bash
robot --listener wopee_rf.WopeeListener tests/
```

### Using as a Library

```robot
*** Settings ***
Library    wopee_rf.WopeeLibrary
Library    SeleniumLibrary

*** Test Cases ***
Visual Check Homepage
    Open Browser    https://example.com    chrome
    Track Full Page
    Close Browser
```

## Features

- **Visual regression testing** — pixel-level and AI-powered comparison
- **Autonomous test maintenance** — AI updates baselines when intended changes are detected
- **Listener and Library modes** — flexible integration with existing RF suites
- **Selenium and Browser Library support** — works with both
- **CI/CD ready** — integrates into any pipeline

## Links

- [Documentation](https://docs.wopee.io/robot-framework/) — setup guides and API reference
- [Wopee.io Platform](https://cmd.wopee.io) — manage baselines, review results
- [Wopee.io Website](https://wopee.io) — learn more about autonomous testing
