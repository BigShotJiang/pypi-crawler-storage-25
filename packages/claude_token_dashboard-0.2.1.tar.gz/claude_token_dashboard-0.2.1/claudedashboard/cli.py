#!/usr/bin/env python3
"""
claude-dashboard CLI — unified entry point.

Usage:
    claude-dashboard                  # live SSE dashboard (default)
    claude-dashboard live [--port N]  # same, explicit
    claude-dashboard report           # one-shot HTML report
    claude-dashboard burndown         # weekly burndown chart
    claude-dashboard analyze          # text summary to stdout
    claude-dashboard menubar          # macOS menubar app
"""

import argparse
import sys


def main():
    parser = argparse.ArgumentParser(
        prog="claude-dashboard",
        description="Real-time token usage monitor for Claude Code",
    )
    sub = parser.add_subparsers(dest="command")

    # live (default)
    p_live = sub.add_parser("live", help="Start the live SSE dashboard (default)")
    p_live.add_argument("--port", type=int, default=8765)
    p_live.add_argument("--no-browser", action="store_true")

    # report
    sub.add_parser("report", help="Generate a one-shot HTML report")

    # burndown
    p_burn = sub.add_parser("burndown", help="Weekly burndown chart")
    p_burn.add_argument("--cycles", type=int, default=9)
    p_burn.add_argument("--no-browser", action="store_true")

    # analyze
    sub.add_parser("analyze", help="Text-based token usage summary")

    # menubar
    sub.add_parser("menubar", help="macOS menubar app (requires rumps, Pillow)")

    # version
    sub.add_parser("version", help="Show version")

    args = parser.parse_args()
    cmd = args.command

    # Default to live dashboard when no subcommand given
    if cmd is None or cmd == "live":
        from claudedashboard.live import main as live_main
        # Re-parse with live's own argparse if called as default
        if cmd is None:
            sys.argv = [sys.argv[0]]  # reset so live's parser doesn't choke
        else:
            # Pass through --port and --no-browser
            live_args = [sys.argv[0]]
            if hasattr(args, "port") and args.port != 8765:
                live_args += ["--port", str(args.port)]
            if hasattr(args, "no_browser") and args.no_browser:
                live_args += ["--no-browser"]
            sys.argv = live_args
        live_main()

    elif cmd == "report":
        from claudedashboard.report import main as report_main
        report_main()

    elif cmd == "burndown":
        burn_args = [sys.argv[0]]
        if args.cycles != 9:
            burn_args += ["--cycles", str(args.cycles)]
        if args.no_browser:
            burn_args += ["--no-browser"]
        sys.argv = burn_args
        from claudedashboard.burndown import main as burndown_main
        burndown_main()

    elif cmd == "analyze":
        from claudedashboard.analyze import main as analyze_main
        analyze_main()

    elif cmd == "menubar":
        try:
            from claudedashboard.menubar import main as menubar_main
        except ImportError:
            print(
                "Menubar requires extra dependencies. Install with:\n"
                "  pip install claude-dashboard[menubar]",
                file=sys.stderr,
            )
            sys.exit(1)
        menubar_main()

    elif cmd == "version":
        from claudedashboard import __version__
        print(f"claude-dashboard {__version__}")


if __name__ == "__main__":
    main()
