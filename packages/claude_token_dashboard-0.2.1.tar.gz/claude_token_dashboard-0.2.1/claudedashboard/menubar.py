#!/usr/bin/env python3
"""
Claude Max Menu Bar App
Shows real weekly budget in the macOS toolbar with native notifications.

Install:  pip3 install rumps
Run:      python3 claude_menubar.py
"""

import json, subprocess, threading, time, math, tempfile, os
from urllib.request import urlopen
from datetime import datetime
from pathlib import Path

import rumps
from PIL import Image, ImageDraw, ImageFont

DASHBOARD_URL   = "http://localhost:8765/api"   # reads from live dashboard cache
CHECK_INTERVAL  = 65    # slightly offset from dashboard's 60s poll
NOTIFY_WEEKLY   = [75, 90]
NOTIFY_5H       = 80


def fetch():
    """Read full snapshot from the live dashboard API."""
    with urlopen(DASHBOARD_URL, timeout=5) as r:
        return json.loads(r.read())


_icon_file = os.path.join(tempfile.gettempdir(), "claude_budget_icon.png")

def _bar_color(pct):
    if pct is None or pct < 60:  return (63, 185, 80)    # green
    if pct < 75:                  return (240, 136, 62)   # orange
    if pct < 90:                  return (210, 153, 34)   # yellow
    return (248, 81, 73)                                  # red

def _draw_sparkle(draw, cx, cy, size, color):
    """Render a ✦ sparkle, stretched 1.6x horizontally so it's wide, not cross-like."""
    _sparkle_fonts = [
        "/System/Library/Fonts/Supplemental/Arial Unicode.ttf",
        "/System/Library/Fonts/SFNS.ttf",
        "/System/Library/Fonts/LastResort.otf",
    ]
    font = ImageFont.load_default()
    for path in _sparkle_fonts:
        try:
            font = ImageFont.truetype(path, size)
            break
        except Exception:
            continue
    # Render to a temp image, stretch horizontally, paste back
    margin = size
    tmp = Image.new("RGBA", (size + margin * 2, size + margin * 2), (0, 0, 0, 0))
    tmp_draw = ImageDraw.Draw(tmp)
    tmp_draw.text((tmp.width // 2, tmp.height // 2), "✦", fill=color, font=font, anchor="mm")
    # Stretch 1.6x wider
    new_w = int(tmp.width * 1.6)
    tmp = tmp.resize((new_w, tmp.height), Image.LANCZOS)
    # Paste centered at (cx, cy) on the parent image
    paste_x = cx - new_w // 2
    paste_y = cy - tmp.height // 2
    draw._image.paste(tmp, (paste_x, paste_y), tmp)


def _draw_codex_mark(draw, cx, cy, size, color):
    """Simple Codex mark: a ring with a center dot, readable at tiny sizes."""
    stroke = max(2, size // 7)
    r = size // 2
    bbox = [cx - r, cy - r, cx + r, cy + r]
    draw.ellipse(bbox, outline=color, width=stroke)
    dot_r = max(2, size // 7)
    draw.ellipse([cx - dot_r, cy - dot_r, cx + dot_r, cy + dot_r], fill=color)


def make_icon(seven_pct, sonnet_pct, fh_pct, codex_week_pct=None, codex_fh_pct=None):
    """
    Two grouped meters:
    Claude  = sparkle + 7d/5h bars
    Codex   = ring + 7d/5h bars
    Rendered at 2x for retina.
    """
    GROUP_W   = 58
    GAP_X     = 12
    W         = GROUP_W * 2 + GAP_X
    H         = 44
    PAD_Y     = 4
    BAR_GAP   = 5
    BAR_W     = 8
    MAX_H     = H - PAD_Y * 2
    GHOST     = (255, 255, 255, 35)

    img  = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    def draw_group(x0, mark_fn, main_pct, sub_pct, mark_color):
        mark_cx = x0 + 16
        mark_cy = H // 2
        mark_fn(draw, mark_cx, mark_cy, 22, mark_color)

        bars_x = x0 + 30
        bars = [main_pct, sub_pct]
        for i, pct in enumerate(bars):
            x = bars_x + i * (BAR_W + BAR_GAP)
            draw.rounded_rectangle([x, PAD_Y, x + BAR_W, H - PAD_Y],
                                   radius=BAR_W // 2, fill=GHOST)
            fill_h = max(int(MAX_H * min((pct or 0) / 100.0, 1.0)), 0)
            if fill_h >= 2:
                fy = H - PAD_Y - fill_h
                draw.rounded_rectangle([x, fy, x + BAR_W, H - PAD_Y],
                                       radius=BAR_W // 2, fill=_bar_color(pct))

    claude_color = _bar_color(max(seven_pct or 0, fh_pct or 0)) + (220,)
    codex_color = _bar_color(max(codex_week_pct or 0, codex_fh_pct or 0)) + (220,)

    draw_group(0, _draw_sparkle, seven_pct, fh_pct, claude_color)
    draw_group(GROUP_W + GAP_X, _draw_codex_mark, codex_week_pct, codex_fh_pct, codex_color)

    img.save(_icon_file, "PNG")
    return _icon_file


def reset_str(resets_at):
    if not resets_at:
        return "—"
    try:
        if isinstance(resets_at, (int, float)):
            dt = datetime.fromtimestamp(resets_at).astimezone()
        else:
            dt = datetime.fromisoformat(resets_at).astimezone()
        return dt.strftime("%a %b %-d · %-I:%M %p")
    except Exception:
        return str(resets_at)


class ClaudeMenuBar(rumps.App):
    def __init__(self):
        super().__init__(
            name="Claude",
            title=None,
            quit_button="Quit",
        )

        self._notified = set()
        self._last_pct = None

        # Menu items
        self.weekly_item   = rumps.MenuItem("Weekly: —")
        self.sonnet_item   = rumps.MenuItem("Sonnet: —")
        self.fh_item       = rumps.MenuItem("5h window: —")
        self.codex_week_item = rumps.MenuItem("Codex 7d: —")
        self.codex_fh_item   = rumps.MenuItem("Codex 5h: —")
        self.resets_item   = rumps.MenuItem("Resets: —")
        self.codex_resets_item = rumps.MenuItem("Codex resets: —")
        self.pace_item     = rumps.MenuItem("Pace: —")
        self.savings_item  = rumps.MenuItem("API cost: —")
        self.sep_sessions  = rumps.separator
        self.sessions_hdr  = rumps.MenuItem("This week")
        # Session cost items (will be populated dynamically)
        self._session_items = []

        self.sep1          = rumps.separator
        self.dashboard_btn = rumps.MenuItem("Open dashboard", callback=self.open_dashboard)
        self.refresh_btn   = rumps.MenuItem("Refresh now",    callback=self.refresh_now)

        self.menu = [
            self.weekly_item,
            self.sonnet_item,
            self.fh_item,
            self.codex_week_item,
            self.codex_fh_item,
            self.resets_item,
            self.codex_resets_item,
            self.pace_item,
            self.savings_item,
            rumps.separator,
            self.sessions_hdr,
            rumps.separator,
            self.dashboard_btn,
            self.refresh_btn,
        ]

        # Start background polling
        t = threading.Thread(target=self._poll_loop, daemon=True)
        t.start()

    # ── Poll loop ─────────────────────────────────────────────────────────────

    def _poll_loop(self):
        while True:
            self._update()
            time.sleep(CHECK_INTERVAL)

    def _update(self):
        try:
            data   = fetch()
            a      = data.get("anthropic") or {}
            c      = data.get("codex_week") or {}

            pct        = a.get("seven_day_pct")
            sonnet_pct = a.get("sonnet_pct")
            fh_pct     = a.get("five_hour_pct")
            resets_at  = a.get("seven_day_resets")
            fh_resets  = a.get("five_hour_resets")
            codex_week_pct = c.get("seven_day_pct")
            codex_fh_pct   = c.get("five_hour_pct")
            codex_week_reset = c.get("seven_day_resets_at")
            codex_fh_reset   = c.get("five_hour_resets_at")
            codex_plan       = c.get("plan_type")

            burn_rate     = data.get("burn_rate")
            session_costs = data.get("session_costs") or []
            week_api_cost  = data.get("week_api_cost", 0)
            month_api_cost = data.get("month_api_cost", 0)

            self._update_ui(
                pct, sonnet_pct, fh_pct, resets_at,
                codex_week_pct, codex_fh_pct, codex_week_reset, codex_fh_reset, codex_plan,
                burn_rate, session_costs, week_api_cost, month_api_cost
            )
            self._check_notifications(pct, fh_pct, resets_at, fh_resets)

        except Exception as e:
            self.title = ""
            self.weekly_item.title = f"Error: {e}"

    def _update_ui(
        self, pct, sonnet_pct, fh_pct, resets_at,
        codex_week_pct, codex_fh_pct, codex_week_reset, codex_fh_reset, codex_plan,
        burn_rate, session_costs, week_api_cost=0, month_api_cost=0
    ):
        self.icon = None
        claude_txt = f"Claude: {pct:.0f}%" if pct is not None else "Claude: -"
        codex_txt = f"Codex: {codex_week_pct:.0f}%" if codex_week_pct is not None else "Codex: -"
        self.title = f"{claude_txt} | {codex_txt}"

        # Menu items
        self.weekly_item.title  = f"Weekly (all models): {pct:.0f}%"    if pct        is not None else "Weekly: —"
        self.sonnet_item.title  = f"Sonnet only: {sonnet_pct:.0f}%"     if sonnet_pct is not None else "Sonnet: —"
        self.fh_item.title      = f"5h window: {fh_pct:.0f}%"           if fh_pct     is not None else "5h window: —"
        self.codex_week_item.title = f"Codex 7d: {codex_week_pct:.0f}% ({codex_plan or '—'})" if codex_week_pct is not None else "Codex 7d: —"
        self.codex_fh_item.title   = f"Codex 5h: {codex_fh_pct:.0f}%" if codex_fh_pct is not None else "Codex 5h: —"
        self.resets_item.title  = f"Resets: {reset_str(resets_at)}"
        self.codex_resets_item.title = f"Codex resets: 7d {reset_str(codex_week_reset)} · 5h {reset_str(codex_fh_reset)}"

        # Burn rate / pace
        if burn_rate and burn_rate.get("avg_pace") is not None:
            pace = burn_rate["avg_pace"]
            sus = burn_rate.get("sustainable")
            today = burn_rate.get("today_used")
            today_str = f"Today: {today}%" if today is not None else ""
            if sus is not None and pace > sus:
                self.pace_item.title = f"Pace: {pace:.1f}%/day — over budget (max {sus:.1f}%/day) {today_str}"
            elif sus is not None:
                self.pace_item.title = f"Pace: {pace:.1f}%/day — on track (max {sus:.1f}%/day) {today_str}"
            else:
                self.pace_item.title = f"Pace: {pace:.1f}%/day {today_str}"
        else:
            self.pace_item.title = "Pace: gathering data..."

        # API cost savings (last 30 days actual data)
        if month_api_cost > 200:
            self.savings_item.title = f"${week_api_cost:,.0f}/wk · saving ${month_api_cost - 200:,.0f}/mo vs Max 20x"
        elif month_api_cost > 100:
            self.savings_item.title = f"${week_api_cost:,.0f}/wk · saving ${month_api_cost - 100:,.0f}/mo vs Max 5x"
        elif week_api_cost > 0:
            self.savings_item.title = f"${week_api_cost:,.0f}/wk · ${month_api_cost:,.0f} last 30d"

        # Session costs (top 5)
        # Remove old session items
        for item in self._session_items:
            try:
                del self.menu[item.title]
            except Exception:
                pass
        self._session_items = []

        for s in session_costs[:5]:
            title = s.get("title") or s.get("id", "?")
            proj  = s.get("project", "")
            label = f"  {title[:40]} — {s['pct']:.1f}% ({s['model']})"
            item = rumps.MenuItem(label)
            self._session_items.append(item)
            self.menu.insert_after(self.sessions_hdr.title, item)

    # ── Notifications ─────────────────────────────────────────────────────────

    def _check_notifications(self, pct, fh_pct, resets_at, fh_resets):
        # Reset notification state at start of new cycle
        if pct is not None and pct < 40:
            self._notified = set()

        rl = f" Resets {reset_str(resets_at)}." if resets_at else ""

        for threshold in NOTIFY_WEEKLY:
            key = f"7d_{threshold}"
            if pct is not None and pct >= threshold and key not in self._notified:
                if threshold >= 90:
                    rumps.notification(
                        title="🔴 Claude Max — Critical",
                        subtitle=f"Weekly budget at {pct:.0f}%",
                        message=f"Slow down!{rl}",
                        sound=True,
                    )
                else:
                    rumps.notification(
                        title="🟡 Claude Max — Warning",
                        subtitle=f"Weekly budget at {pct:.0f}%",
                        message=rl.strip() or "Monitor your usage.",
                        sound=True,
                    )
                self._notified.add(key)

        key_fh = "5h_warn"
        if fh_pct is not None and fh_pct >= NOTIFY_5H and key_fh not in self._notified:
            rl_fh = f" Resets {reset_str(fh_resets)}." if fh_resets else ""
            rumps.notification(
                title="⚠️ Claude Max — Rate Limit Risk",
                subtitle=f"5h window at {fh_pct:.0f}%",
                message=f"You may get throttled.{rl_fh}",
                sound=True,
            )
            self._notified.add(key_fh)
        elif fh_pct is not None and fh_pct < 50:
            self._notified.discard(key_fh)

    # ── Callbacks ─────────────────────────────────────────────────────────────

    def open_dashboard(self, _):
        import webbrowser
        webbrowser.open("http://localhost:8765")

    def refresh_now(self, _):
        threading.Thread(target=self._update, daemon=True).start()

    @rumps.timer(CHECK_INTERVAL)
    def timer_tick(self, _):
        pass  # polling handled by background thread


def main():
    ClaudeMenuBar().run()


if __name__ == "__main__":
    main()
