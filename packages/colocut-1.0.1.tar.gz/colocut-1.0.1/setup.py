from setuptools import setup, find_packages

setup(
    name="colocut",
    version="1.0.1",
    packages=find_packages(),
)
