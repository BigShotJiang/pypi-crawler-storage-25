# TEXT COLOR
class Color:
    BLACK   = "\033[30m"
    RED     = "\033[31m"
    GREEN   = "\033[32m"
    YELLOW  = "\033[33m"
    BLUE    = "\033[34m"
    MAGENTA = "\033[35m"
    CYAN    = "\033[36m"
    WHITE   = "\033[37m"
    RESET   = "\033[0m" # THIS IS RESET

# BRIGHT COLOR
class Bright:
    BLACK   = "\033[90m"
    RED     = "\033[91m"
    GREEN   = "\033[92m"
    YELLOW  = "\033[93m"
    BLUE    = "\033[94m"
    MAGENTA = "\033[95m"
    CYAN    = "\033[96m"
    WHITE   = "\033[97m"

# BACKGROUND
class Bg:
    RED    = "\033[41m"
    GREEN  = "\033[42m"
    YELLOW = "\033[43m"
    BLUE   = "\033[44m"

# STYLE
class Style:
    BOLD      = "\033[1m"
    DIM       = "\033[2m"
    ITALIC    = "\033[3m"
    UNDERLINE = "\033[4m"
    BLINK     = "\033[5m"
    REVERSE   = "\033[7m"
    HIDDEN    = "\033[8m"
    STRIKE    = "\033[9m"

# ADVANCE COLOR
class RGB:
    @staticmethod
    def color(r, g, b):
        return f"\033[38;2;{r};{g};{b}m"

# ADVANCE BACKGROUND
class BgRGB:
    @staticmethod
    def color(r, g, b):
        return f"\033[48;2;{r};{g};{b}m"

# FULL SHORTCUT NORMAL
class C:
    @staticmethod
    def black(text):
        return f"{Color.BLACK}{text}{Color.RESET}"

    @staticmethod
    def red(text):
        return f"{Color.RED}{text}{Color.RESET}"

    @staticmethod
    def green(text):
        return f"{Color.GREEN}{text}{Color.RESET}"

    @staticmethod
    def yellow(text):
        return f"{Color.YELLOW}{text}{Color.RESET}"

    @staticmethod
    def blue(text):
        return f"{Color.BLUE}{text}{Color.RESET}"

    @staticmethod
    def magenta(text):
        return f"{Color.MAGENTA}{text}{Color.RESET}"

    @staticmethod
    def cyan(text):
        return f"{Color.CYAN}{text}{Color.RESET}"

    @staticmethod
    def white(text):
        return f"{Color.WHITE}{text}{Color.RESET}"

# FULL SHORTCUT BRIGHT
class CB:
    @staticmethod
    def black(text):
        return f"{Bright.BLACK}{text}{Color.RESET}"

    @staticmethod
    def red(text):
        return f"{Bright.RED}{text}{Color.RESET}"

    @staticmethod
    def green(text):
        return f"{Bright.GREEN}{text}{Color.RESET}"

    @staticmethod
    def yellow(text):
        return f"{Bright.YELLOW}{text}{Color.RESET}"

    @staticmethod
    def blue(text):
        return f"{Bright.BLUE}{text}{Color.RESET}"

    @staticmethod
    def magenta(text):
        return f"{Bright.MAGENTA}{text}{Color.RESET}"

    @staticmethod
    def cyan(text):
        return f"{Bright.CYAN}{text}{Color.RESET}"

    @staticmethod
    def white(text):
        return f"{Bright.WHITE}{text}{Color.RESET}"

# FULL SHORTCUT BACKGROUND
class CBG:
    @staticmethod
    def black(text):
        return f"{Bg.BLACK}{text}{Color.RESET}"

    @staticmethod
    def red(text):
        return f"{Bg.RED}{text}{Color.RESET}"

    @staticmethod
    def green(text):
        return f"{Bg.GREEN}{text}{Color.RESET}"

    @staticmethod
    def yellow(text):
        return f"{Bg.YELLOW}{text}{Color.RESET}"
