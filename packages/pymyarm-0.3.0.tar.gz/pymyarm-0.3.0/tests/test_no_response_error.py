"""Verify NoResponseError carries the correct servo ID."""

from unittest.mock import MagicMock, patch

import pytest

from pymyarm.exceptions import CommunicationError, NoResponseError
from pymyarm.protocol import build_ping_frame, build_read_frame, build_sync_read_frame
from pymyarm.servo_controller import ServoController, _frame_target_label


# ---------------------------------------------------------------------------
# Unit: _frame_target_label
# ---------------------------------------------------------------------------


class TestFrameTargetLabel:
    def test_single_servo(self):
        frame = build_ping_frame(servo_id=5)
        assert _frame_target_label(frame) == "5"

    def test_broadcast(self):
        frame = build_sync_read_frame(0x38, 2, [1, 2, 3])
        assert _frame_target_label(frame) == "broadcast(0xFE)"

    def test_short_frame(self):
        assert _frame_target_label(b"\xff\xff") == "unknown"
        assert _frame_target_label(b"") == "unknown"


# ---------------------------------------------------------------------------
# Integration: _txrx raises NoResponseError with servo ID
# ---------------------------------------------------------------------------


def _make_controller() -> ServoController:
    """Build a ServoController with a fake SerialClient (never talks to HW)."""
    import threading

    ctrl = ServoController.__new__(ServoController)
    ctrl._client = MagicMock()
    ctrl._client.is_open = True
    ctrl._client.port = "/dev/fake"
    ctrl._client.calc_poll_timeout = MagicMock(return_value=0.01)
    ctrl._lock = threading.Lock()
    ctrl._stats_lock = threading.Lock()
    ctrl._debug = False
    ctrl._retries = 0
    ctrl._error_cache = {}
    ctrl._no_response_count = 0
    ctrl._connected_since = None
    ctrl._connected_seconds_total = 0.0
    return ctrl


class TestNoResponseError:
    """Simulate empty serial response and verify exception details."""

    def test_single_servo_no_response(self):
        ctrl = _make_controller()
        ctrl._client.read_available = MagicMock(return_value=b"")

        frame = build_read_frame(servo_id=3, start_addr=0x38, read_len=2)
        with pytest.raises(CommunicationError, match=r"servo 3"):
            ctrl._txrx(frame)

    def test_no_response_is_subclass(self):
        ctrl = _make_controller()
        ctrl._client.read_available = MagicMock(return_value=b"")

        frame = build_read_frame(servo_id=7, start_addr=0x38, read_len=2)
        with pytest.raises(NoResponseError):
            ctrl._txrx(frame)

    def test_broadcast_frame_no_response(self):
        ctrl = _make_controller()
        ctrl._client.read_available = MagicMock(return_value=b"")

        frame = build_sync_read_frame(0x38, 2, [1, 2])
        with pytest.raises(CommunicationError, match=r"broadcast\(0xFE\)"):
            ctrl._txrx(frame)

    def test_invalid_response_includes_servo_id(self):
        ctrl = _make_controller()
        # Return garbage bytes that won't parse as a valid frame
        ctrl._client.read_available = MagicMock(return_value=b"\x00\x01\x02\x03")

        frame = build_read_frame(servo_id=9, start_addr=0x38, read_len=2)
        with pytest.raises(CommunicationError, match=r"servo 9"):
            ctrl._txrx(frame)

    def test_record_no_response_called(self):
        """The critical bug fix: _record_no_response must be called."""
        ctrl = _make_controller()
        ctrl._client.read_available = MagicMock(return_value=b"")
        ctrl._record_no_response = MagicMock()

        frame = build_read_frame(servo_id=4, start_addr=0x38, read_len=2)
        with pytest.raises(CommunicationError):
            ctrl._txrx(frame)

        ctrl._record_no_response.assert_called_once_with(1)
