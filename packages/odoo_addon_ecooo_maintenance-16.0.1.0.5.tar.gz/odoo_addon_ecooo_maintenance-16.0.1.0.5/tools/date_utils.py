from odoo import fields
from odoo.tools import date_utils

def get_datetimes_since(last_execution_datetime):
    today = fields.Datetime.now()
    start_date = last_execution_datetime
    while start_date < today:
        start_date = date_utils.add(start_date, days=1)
        # Yield generator pattern -> https://www.geeksforgeeks.org/python/python-yield-keyword/
        # Got the idea here -> https://www.slingacademy.com/article/python-get-a-list-of-all-dates-between-2-dates/
        yield start_date
    
