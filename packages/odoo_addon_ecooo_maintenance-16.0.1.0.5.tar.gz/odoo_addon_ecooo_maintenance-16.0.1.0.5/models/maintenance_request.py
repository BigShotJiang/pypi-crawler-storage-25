from odoo import models, fields, api, _
from odoo.exceptions import ValidationError


class MaintenanceRequest(models.Model):
    _name = 'maintenance.request'
    _inherit = ['maintenance.request', 'base_multi_image.owner']
    _rec_name = 'number'

    number = fields.Char(
         required=True,
         readonly=True,
         default='PM XXXX-XXX'
    )

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            vals['number'] = self.env['ir.sequence'].next_by_code('maintenance.request')
        return super().create(vals_list)

    name = fields.Char(string='Name')

    user_id = fields.Many2one('res.users', string='Officer')

    plant_ids = fields.Many2many(comodel_name='photovoltaic.power.station')
    maintenance_type_ids = fields.Many2many('maintenance.type')

    schedule_date = fields.Date(string="Creation Date", default=lambda self: fields.Date.today()) # change from Datetime
    resolved_date = fields.Date()

    work_order_ids = fields.One2many('maintenance.work.order', 'request_id')

    template_id = fields.Many2one('maintenance.request.template')

    product_ids = fields.Many2many('stock.quant')

    def set_stage(self, name):
        if name == 'Cerrada':
            self.resolved_date = fields.Date.today()
        self.stage_id = self.env['maintenance.stage'].search([('name', '=', name)]).id


    @api.onchange('user_id', 'work_order_ids')
    def _onchange_stage_dependencies(self):
        for record in self:
            if record.user_id:
                if len(record.work_order_ids) == 0:
                    record.set_stage('Asignada')

                else:
                    record.set_stage('En proceso')

            else:
                record.set_stage('Nueva solicitud')


    @api.onchange('stage_id')
    def _onchange_stage_id(self):
        if self.env.context.get('manual'):
            for record in self:
                if record.stage_id.name in ['Asignada', 'En proceso', 'Cerrada']:
                    raise ValidationError(_('Can\'t change manually to this stage!'))

    @api.onchange('plant_ids')
    def onchange_plant_ids(self):
        for record in self:
            return {
                'domain': {
                    'product_ids': [
                        ('location_id', 'in', [p.stock_location.id for p in record.plant_ids])
                    ]
                }
            }
