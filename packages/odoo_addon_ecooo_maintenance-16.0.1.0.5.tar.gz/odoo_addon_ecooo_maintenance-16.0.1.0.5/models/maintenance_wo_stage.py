from odoo import models, fields, _, api


class MaintenanceWOStage(models.Model):
    _name = 'maintenance.wo.stage'
    _sql_constraints = [(
        'uniq_code',
        'unique(code)',
        _('There is already a stage with this code!')
    )]
    _order='sequence'

    name = fields.Char(required=True)
    code = fields.Char(readonly=True, compute='_compute_code', store=True)
    sequence = fields.Integer('Sequence', default=20)

    @api.depends('name')
    def _compute_code(self):
        for record in self:
            if record.name:
                record.code = record.name.lower().replace(' ', '_')
