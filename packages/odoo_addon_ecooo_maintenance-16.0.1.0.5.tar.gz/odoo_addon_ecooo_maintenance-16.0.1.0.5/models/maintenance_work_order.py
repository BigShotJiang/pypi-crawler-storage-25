import logging
from odoo import models, fields, api, _
from odoo.exceptions import ValidationError

_logger = logging.getLogger(__name__)

class MaintenanceWorkOrder(models.Model):
    _name = 'maintenance.work.order'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _rec_name = 'number'
    _description = 'Work Order'

    number = fields.Char(
         required=True,
         readonly=True,
         default='OT XXXX-XXX'
    )

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            vals['number'] = self.env['ir.sequence'].next_by_code('maintenance.work.order')
        return super().create(vals_list)

    name = fields.Char(required=True)

    date = fields.Datetime(string="Scheduled Date")
    duration = fields.Float()

    priority = fields.Selection([
        ('0', 'Very Low'),
        ('1', 'Low'),
        ('2', 'Medium'),
        ('3', 'High')
    ])

    maintenance_type_ids = fields.Many2many('maintenance.type')
    request_type_ids = fields.Many2many(related='request_id.maintenance_type_ids', string="Request maintenance type")

    def get_stage(self, code='en_preparación'):
        return self.env['maintenance.wo.stage'].search([('code', '=', code)]).id

    def set_stage(self, code):
        self.stage_id = self.get_stage(code)

    stage_id = fields.Many2one(
        'maintenance.wo.stage',
        default=get_stage,
        required=True,
        group_expand='_read_group_stages',
        ondelete='restrict',
        tracking=True
    )
    stage_code = fields.Char(related='stage_id.code')

    description = fields.Text()

    request_id = fields.Many2one('maintenance.request')
    request_plant_ids = fields.Many2many(related='request_id.plant_ids')
    plant_ids = fields.Many2many(comodel_name='photovoltaic.power.station')

    account_id = fields.Many2one('account.account', required=True)
    provider_id = fields.Many2one('res.partner', required=True)
    chat_link = fields.Char()

    task_ids = fields.One2many('maintenance.task', 'work_order_id')

    materials_ids = fields.One2many('maintenance.materials', 'work_order_id')

    def write(self, vals):
        res = super().write(vals)

        if all(wo.stage_id.code == 'facturada' for wo in self.request_id.work_order_ids):
            self.request_id.set_stage('Cerrada')

        elif all(wo.stage_id.code == 'anulada' for wo in self.request_id.work_order_ids):
            self.request_id.set_stage('Nueva')

        elif self.request_id.stage_id.name == 'Cerrada':
            self.request_id.set_stage('En proceso')

        return res

    @api.model
    def _read_group_stages(self, record, domain, order):
        """ Read group customization in order to display all the stages in the
            kanban view, even if they are empty
        """
        return self.env['maintenance.wo.stage'].search([])


    def action_notify(self):

        return {
            'name': _('Notify work order'),
            'type': 'ir.actions.act_window',
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': 'mail.compose.message',
            'target': 'new',
            'context': {
                'default_use_template': True,
                'default_template_id': self.env.ref('ecooo_maintenance.installer_email').id
            }
        }

    def action_download_report(self):

        return {
            'name': _('Notify work order'),
            'type': 'ir.actions.report',
            'model': 'maintenance.work.order',
            'report_type': 'qweb-pdf',
            'report_name': 'ecooo_maintenance.template_work_order',
            'print_report_name': "'Work order %s' % (object.number)"
        }

    def action_bill(self):
        if not all(plant.analytic_account.id for plant in self.plant_ids):
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': _('Could not bill work order!'),
                    'message': _('Plant has no analytic account configured'),
                    'type': 'danger',
                    'sticky': False,
                }
            }

        return {
            'name': _('Close work order'),
            'type': 'ir.actions.act_window',
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': 'close.work.order.wizard',
            'view_id': self.env.ref('ecooo_maintenance.close_work_order_wizard_view_form').id,
            'target': 'new',
            'context': {
                'default_work_order_id': self.id,
            }
        }


    @api.onchange('stage_id')
    def _onchange_stage_id(self):
        # hack to detect if its edited manually (manual) or from the maintenance.request view (params)
        if self.env.context.get('manual') or self.env.context.get('params'):
            for record in self:
                if record.stage_id.code in ['facturada']:
                    raise ValidationError(_('Can\'t change manually to this stage!'))
                elif record.stage_id.code == 'ejecutada':
                    if len(self.task_ids) < 1:
                        raise ValidationError(_('There are no tasks in this work order!'))
                    for task in self.task_ids:
                        if task.state == '2active':
                            raise ValidationError(_('There are still active tasks in this work order!'))

    @api.onchange('task_ids')
    def _onchange_task_ids(self):
        wo_index = self._get_wo_index_by_ids(self.ids)
        for record in self:
            for task in record.task_ids:
                # Need to check for origin because, since its an onChange, the Ids are of NewId type => https://github.com/odoo/odoo/blob/16.0/odoo/models.py#L208
                if task.id.origin not in wo_index[record.id.origin].task_ids.ids and task.plant_id.id not in record.plant_ids.ids:
                    return {
                        'value': {},
                        'warning': {
                            'title': _('Mismatch between photovoltaic phower station'),
                            'message': _("You've assigned a task to a work order with a diferent photovoltaic power station. Are you sure that is correct?")
                        }
                    }

    @api.onchange('date')
    def _onchange_date(self):
        for record in self:
            if record.date and record.stage_id.code == 'en_preparación':
                 record.set_stage('agendada')

    def _get_wo_index_by_ids(self, ids):
        wo_index = {}
        stored_tasks = self.env['maintenance.work.order'].search([('id', 'in', ids)])
        for work_order in stored_tasks:
            wo_index[work_order.id] = work_order
        return wo_index
