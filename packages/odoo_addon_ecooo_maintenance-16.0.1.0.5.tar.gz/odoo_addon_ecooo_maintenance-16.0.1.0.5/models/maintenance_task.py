from odoo import models, fields, api, _
import logging

_logger = logging.getLogger(__name__)

class MaintenanceTask(models.Model):
    _name = 'maintenance.task'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _rec_name = 'number'

    number = fields.Char(
         required=True,
         readonly=True,
         default='T-X'
    )

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            vals['number'] = self.env['ir.sequence'].next_by_code('maintenance.task')
        return super().create(vals_list)

    name = fields.Char(required=True)
    description = fields.Text()
    sugested_solution = fields.Text()

    creation_date = fields.Datetime(default= lambda self: fields.Datetime.now())
    resolved_date = fields.Datetime()
    
    priority = fields.Selection([
        ('0', 'Very Low'),
        ('1', 'Low'),
        ('2', 'Medium'),
        ('3', 'High')
    ])

    assigned_id = fields.Many2one(
        'res.partner',
        string="Provider",
    )

    state = fields.Selection([
        ('1pending', 'Pending'),
        ('2active', 'Active'),
        ('3finished', 'Finished')
    ],
        required=True,
        group_expand='_read_group_states',
        default='1pending',
        tracking=True
    )

    plant_id = fields.Many2one('photovoltaic.power.station')
    plant_city = fields.Char(related='plant_id.city', store=True)

    work_order_id = fields.Many2one('maintenance.work.order')
    work_order_number = fields.Char(related='work_order_id.number')

    template_id = fields.Many2one('maintenance.task.template')
    
    image = fields.Binary()

    def write(self, vals):
        res = super().write(vals)
        if ('work_order_id' in vals): # This is a workaround in case the work_order_id is assigned from the work_order form to keep the same behaviour
           self._onchange_work_order_id()
        if all(task.state == '3finished' for task in self.work_order_id.task_ids):
            self.work_order_id.set_stage('ejecutada')
        elif self.work_order_id.stage_id.code == 'ejecutada' and self.work_order_id.date:
            self.work_order_id.set_stage('agendada')
        elif self.work_order_id.stage_id.code == 'ejecutada':
            self.work_order_id.set_stage('en_preparacion')
        
        return res

    @api.onchange('work_order_id')
    def _onchange_work_order_id(self):
        mismatched_power_station = False
        for record in self:
            if record.work_order_id:
                record.state = '2active'
                if record.work_order_id.provider_id:
                    record.assigned_id = record.work_order_id.provider_id
                if record.plant_id not in record.work_order_id.plant_ids:
                    mismatched_power_station = True
            elif record.state == '2active':
                record.state = '1pending'
                record.assigned_id = None
        if (mismatched_power_station):
            return {
                'value': {},
                'warning': {
                    'title': _('Mismatch between photovoltaic phower station'),
                    'message': _("You've assigned a task to a work order with a diferent photovoltaic power station. Are you sure that is correct?")
                }
            }

    @api.onchange('state')
    def _onchange_state(self):
        for record in self:
            if record.state == '1pending':
                record.work_order_id = False
            elif record.state == '3finished':
                record.resolved_date = fields.Datetime.now()

    @api.model
    def _read_group_states(self, record, domain, order):
        """ Read group customization in order to display all the states in the
            kanban view, even if they are empty
        """
        return ['1pending', '2active', '3finished']
