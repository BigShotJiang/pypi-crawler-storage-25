from odoo import models, fields


class PhotovoltaicPowerStation(models.Model):
    _inherit = 'photovoltaic.power.station'

    analytic_account = fields.Many2one('account.analytic.account')

    maintenance_request_ids = fields.Many2many(comodel_name='maintenance.request')
    work_order_ids = fields.Many2many('maintenance.work.order')
    task_ids = fields.One2many('maintenance.task', 'plant_id')
