from odoo import models, fields
from odoo.tools import date_utils
import calendar
import logging
from ..tools.date_utils import get_datetimes_since

_logger = logging.getLogger(__name__)

class MaintenanceTaskTemplate(models.Model):
    _name = 'maintenance.task.template'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(required=True)
    description = fields.Text()
    sugested_solution = fields.Text()


    priority = fields.Selection([
        ('0', 'Very Low'),
        ('1', 'Low'),
        ('2', 'Medium'),
        ('3', 'High')
    ])

    image = fields.Binary()

    plant_id = fields.Many2one('photovoltaic.power.station')
    plant_city = fields.Char(related='plant_id.city', store=True)

    schedule_type = fields.Selection([
        ('calendar', 'Calendar'),
        ('interval', 'Interval'),
    ], default='calendar', required=True)

    calendar_type = fields.Selection([
        ('yearly', 'Yearly'),
        ('monthly', 'Monthly'),
        ('weekly', 'Weekly'),
    ], default='monthly')

    month = fields.Selection([(str(i), calendar.month_name[i]) for i in range(1, 13)])
    day = fields.Selection([(str(i), str(i)) for i in range(1, 32)])
    weekday = fields.Selection([(str(i), calendar.day_name[i]) for i in range(7)])

    interval_number = fields.Float(default=1)
    interval_type = fields.Selection([
        ('days', 'Days'),
        ('weeks', 'Weeks'),
        ('months', 'Months'),
        ('years', 'Years'),
    ], default='days')
    last_checked = fields.Datetime(default=lambda self: fields.Datetime.now())

    def _create_task(self, task_template):
        self.env['maintenance.task'].create({
            'name': task_template.name,
            'description': task_template.description,
            'priority': task_template.priority,
            'image': task_template.image,
            'sugested_solution': task_template.sugested_solution,
            'plant_id': task_template.plant_id.id,
            'template_id': task_template.id
        })


    def cron_create_tasks_calendar(self):
        for task_template in self.env['maintenance.task.template'].search([('schedule_type', '=', 'calendar')]):
            for check_date in get_datetimes_since(task_template.last_checked):
                match task_template.calendar_type:
                    case 'yearly':
                        if int(task_template.month) == check_date.month and int(task_template.day) == check_date.day:
                            self._create_task(task_template)
                    case 'monthly':
                        if int(task_template.day) == check_date.day:
                            self._create_task(task_template)
                    case 'weekly':
                        if int(task_template.weekday) == check_date.weekday():
                            self._create_task(task_template)
                task_template.last_checked = check_date


    def cron_create_tasks_interval(self):
        for task_template in self.env['maintenance.task.template'].search([('schedule_type', '=', 'interval')]):
            next_creation_date = date_utils.add(task_template.last_checked, **{task_template.interval_type: task_template.interval_number})
            for check_date in get_datetimes_since(task_template.last_checked):
                if next_creation_date < check_date:
                    self._create_task(task_template)
                    task_template.last_checked = check_date


    
