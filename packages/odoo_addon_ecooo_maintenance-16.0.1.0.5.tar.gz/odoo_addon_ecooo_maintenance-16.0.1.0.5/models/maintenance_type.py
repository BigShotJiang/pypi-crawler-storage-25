from odoo import models, fields


class MaintenanceType(models.Model):
    _name = 'maintenance.type'

    name = fields.Char(required=True)
