from odoo import models, fields
from odoo.tools import date_utils
import calendar
from ..tools.date_utils import get_datetimes_since

class MaintenanceRequestTemplate(models.Model):
    _inherit = 'maintenance.request'
    _name = 'maintenance.request.template'

    schedule_type = fields.Selection([
        ('calendar', 'Calendar'),
        ('interval', 'Interval'),
    ], default='calendar', required=True)

    calendar_type = fields.Selection([
        ('yearly', 'Yearly'),
        ('monthly', 'Monthly'),
        ('weekly', 'Weekly'),
    ], default='monthly')

    month = fields.Selection([(str(i), calendar.month_name[i]) for i in range(1, 13)])
    day = fields.Selection([(str(i), str(i)) for i in range(1, 32)])
    weekday = fields.Selection([(str(i), calendar.day_name[i]) for i in range(7)])

    interval_number = fields.Float(default=1)
    interval_type = fields.Selection([
        ('days', 'Days'),
        ('weeks', 'Weeks'),
        ('months', 'Months'),
        ('years', 'Years'),
    ], default='days')
    interval_last_checked = fields.Datetime(default=lambda self: fields.Datetime.now())


    def _create_request(self, request_template):
        new_request = self.env['maintenance.request'].create({
            'name': request_template.name,
            'employee_id': request_template.employee_id.id,
            'maintenance_type_ids': [(6, 0, [mt.id for mt in request_template.maintenance_type_ids])],
            'user_id': request_template.user_id.id,
            'duration': request_template.duration,
            'priority': request_template.priority,
            'email_cc': request_template.email_cc,
            'plant_ids': [(6, 0, [p.id for p in request_template.plant_ids])],
            'description': request_template.description,
            'template_id': request_template.id
        })

        for work_order in request_template.work_order_ids:
            new_work_order = self.env['maintenance.work.order'].create({
                'name': work_order.name,
                'date': work_order.date,
                'maintenance_type_ids': [(6,0, work_order.maintenance_type_ids.ids)],
                'plant_id': work_order.plant_id.id,
                'account_id': work_order.account_id.id,
                'provider_id': work_order.provider_id.id,
                'chat_link': work_order.chat_link,
                'materials_ids': [(6, 0, [m.id for m in work_order.materials_ids])],
                'request_id': new_request.id
            })

            for task in work_order.task_ids:
                new_task = self.env['maintenance.task'].create({
                    'name': task.name,
                    'description': task.description,
                    'assigned_id': task.assigned_id.id,
                    'plant_id': task.plant_id.id,
                    'work_order_id': new_work_order.id,
                })


    def cron_create_requests_calendar(self):
        check_date = fields.Date.today()
        for request_template in self.env['maintenance.request.template'].search([('schedule_type', '=', 'calendar')]):
            for check_date in get_datetimes_since(request_template.interval_last_checked):
                match request_template.calendar_type:
                    case 'yearly':
                        if int(request_template.month) == check_date.month and int(request_template.day) == check_date.day:
                            self._create_request(request_template)
                    case 'monthly':
                        if int(request_template.day) == check_date.day:
                            self._create_request(request_template)
                    case 'weekly':
                        if int(request_template.weekday) == check_date.weekday():
                            self._create_request(request_template)
                request_template.interval_last_checked = check_date


    def cron_create_requests_interval(self):
        for request_template in self.env['maintenance.request.template'].search([('schedule_type', '=', 'interval')]):
            next_creation_date = date_utils.add(request_template.interval_last_checked, **{request_template.interval_type: request_template.interval_number})
            for check_date in get_datetimes_since(request_template.interval_last_checked):

                if next_creation_date <= check_date:
                    self._create_request(request_template)
                    request_template.interval_last_checked = check_date
