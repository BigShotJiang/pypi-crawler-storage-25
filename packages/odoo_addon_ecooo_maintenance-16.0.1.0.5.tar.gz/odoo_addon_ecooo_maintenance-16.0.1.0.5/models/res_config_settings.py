from odoo import fields, models


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    work_hours_product_id = fields.Many2one('product.product', config_parameter='maintenance.work_hours_product_id')
    kilometers_product_id = fields.Many2one('product.product', config_parameter='maintenance.kilometers_product_id')
