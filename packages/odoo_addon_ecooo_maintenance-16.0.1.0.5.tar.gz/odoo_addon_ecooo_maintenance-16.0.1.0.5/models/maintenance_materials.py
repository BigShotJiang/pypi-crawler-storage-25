from odoo import models, fields, api


class MaintenanceMaterials(models.Model):
    _name = 'maintenance.materials'

    quantity = fields.Integer(default=1)
    product_id = fields.Many2one('product.product')
    description = fields.Char()

    work_order_id = fields.Many2one('maintenance.work.order')


    @api.onchange('product_id')
    def _onchange_product_id(self):
        for record in self:
            record.description = self.product_id.display_name
