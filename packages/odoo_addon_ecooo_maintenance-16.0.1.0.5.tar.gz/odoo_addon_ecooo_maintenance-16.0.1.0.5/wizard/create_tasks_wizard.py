from odoo import models, fields, _


class CreateTasksWizard(models.TransientModel):
    _inherit = 'maintenance.task'
    _name = 'create.tasks.wizard'

    name = fields.Char()
    description = fields.Char()

    priority = fields.Selection([
        ('0', 'Very Low'),
        ('1', 'Low'),
        ('2', 'Medium'),
        ('3', 'High')
    ])
    assigned_id = fields.Many2one(
        'res.partner',
    )
    image = fields.Binary()

    plant_ids = fields.Many2many('photovoltaic.power.station')

    def action_done(self):
        for plant in self.plant_ids:
            self.env['maintenance.task'].create({
                'name': self.name,
                'description': self.description,
                'priority': self.priority,
                'assigned_id': self.assigned_id.id,
                'image': self.image,
                'plant_id': plant.id
            })
