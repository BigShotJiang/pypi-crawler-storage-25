import logging
from odoo import models, fields, _

_logger = logging.getLogger(__name__)

class CloseWorkOrderWizard(models.TransientModel):
    _name = 'close.work.order.wizard'

    work_order_id = fields.Many2one('maintenance.work.order')

    work_hours = fields.Float()
    kilometers = fields.Float()

    closing_date = fields.Datetime(default=lambda self: fields.Datetime.now())

    def action_done(self):
        all_closed = True
        for wo in self.work_order_id.request_id.work_order_ids:
            if wo.stage_id.code != 'closed':
                all_closed = False
                break

        if all_closed:
            self.work_order_id.request_id.stage_id = self.env['maintenance.stage'].search([('done', '=', 'True')])[0].id

        work_hours_product_id = int(self.env['ir.config_parameter'].sudo().get_param('maintenance.work_hours_product_id'))
        kilometers_product_id = int(self.env['ir.config_parameter'].sudo().get_param('maintenance.kilometers_product_id'))

        work_hours_product = self.env['product.product'].browse(work_hours_product_id)
        kilometers_product = self.env['product.product'].browse(kilometers_product_id)

        work_hours_sellers = [s for s in work_hours_product.seller_ids if s.partner_id == self.work_order_id.provider_id]
        kilometers_sellers = [s for s in kilometers_product.seller_ids if s.partner_id == self.work_order_id.provider_id]

        if len(work_hours_sellers) == 0 or len(kilometers_sellers) == 0:
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': _('Could not bill work order!'),
                    'message': _('The provider %s doesn\'t have some or all the configured products', self.work_order_id.provider_id.name),
                    'type': 'danger',
                    'sticky': False,
                }
            }

        work_hours_price = work_hours_sellers[0].price
        kilometers_price = kilometers_sellers[0].price
        self.work_order_id.set_stage('facturada')

        invoice = self.env['account.move'].create({
            'move_type': 'in_invoice',
            'invoice_date': self.closing_date,
            'ref': self.work_order_id.number,
            'partner_id': self.work_order_id.provider_id.id,
            'line_ids': self._generate_invoice_ids(work_hours_product, work_hours_price, kilometers_product, kilometers_price)
        })

        return {
            'type': 'ir.actions.act_window',
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': 'account.move',
            'target': 'current',
            'res_id': invoice.id
        }

    def _generate_invoice_ids(self, work_hours_product, work_hours_price, kilometers_product, kilometers_price):
        invoice_lines = []
        for plant in self.work_order_id.plant_ids:
            invoice_lines.append((0,0,{
                    'product_id': work_hours_product.id,
                    'name': f'{self.work_order_id.number} - {work_hours_product.name}',
                    'account_id': self.work_order_id.account_id.id,
                    'analytic_distribution': { plant.analytic_account.id: 100 },
                    'quantity': self.work_hours/len(self.work_order_id.plant_ids),
                    'price_unit': work_hours_price,
                    'tax_ids': [work_hours_product.taxes_id.id]
                 }))
            invoice_lines.append((0, 0, {
                    'product_id': kilometers_product.id,
                    'name': f'{self.work_order_id.number} - {kilometers_product.name}',
                    'account_id': self.work_order_id.account_id.id,
                    'analytic_distribution': { plant.analytic_account.id: 100 },
                    'quantity': self.kilometers/len(self.work_order_id.plant_ids),
                    'price_unit': kilometers_price,
                    'tax_ids': [kilometers_product.taxes_id.id]
                }))
        return invoice_lines
