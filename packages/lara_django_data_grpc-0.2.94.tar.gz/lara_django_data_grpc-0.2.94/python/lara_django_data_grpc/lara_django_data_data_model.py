from __future__ import annotations 

import re
import sys
from datetime import (
    date,
    datetime,
    time
)
from decimal import Decimal 
from enum import Enum 
from typing import (
    Any,
    ClassVar,
    Dict,
    List,
    Literal,
    Optional,
    Union
)

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    RootModel,
    field_validator
)


metamodel_version = "None"
version = "None"


class ConfiguredBaseModel(BaseModel):
    model_config = ConfigDict(
        validate_assignment = True,
        validate_default = True,
        extra = "forbid",
        arbitrary_types_allowed = True,
        use_enum_values = True,
        strict = False,
    )
    pass




class LinkMLMeta(RootModel):
    root: Dict[str, Any] = {}
    model_config = ConfigDict(frozen=True)

    def __getattr__(self, key:str):
        return getattr(self.root, key)

    def __getitem__(self, key:str):
        return self.root[key]

    def __setitem__(self, key:str, value):
        self.root[key] = value

    def __contains__(self, key:str) -> bool:
        return key in self.root


linkml_meta = LinkMLMeta({'default_prefix': 'lara',
     'default_range': 'string',
     'id': 'https://w3id.org/lara/lara_django_data',
     'imports': ['linkml:types'],
     'name': 'lara_django_data',
     'prefixes': {'lara': {'prefix_prefix': 'lara',
                           'prefix_reference': 'http://w3id.org/lara/'},
                  'linkml': {'prefix_prefix': 'linkml',
                             'prefix_reference': 'https://w3id.org/linkml/'},
                  'oso': {'prefix_prefix': 'oso',
                          'prefix_reference': 'http://w3id.org/oso/'}},
     'source_file': 'lara_django_data_schema.yaml',
     'types': {'FileField': {'base': 'str',
                             'description': 'A file field',
                             'from_schema': 'https://w3id.org/lara/lara_django_data',
                             'name': 'FileField',
                             'uri': 'https://w3id.org/lara/FileField'},
               'ImageField': {'base': 'str',
                              'description': 'An image field',
                              'from_schema': 'https://w3id.org/lara/lara_django_data',
                              'name': 'ImageField',
                              'uri': 'https://w3id.org/lara/ImageField'},
               'JSON': {'base': 'string',
                        'description': 'A JSON object',
                        'from_schema': 'https://w3id.org/lara/lara_django_data',
                        'name': 'JSON',
                        'repr': 'dict',
                        'uri': 'https://json.org'},
               'UUID': {'base': 'str',
                        'description': 'A UUID',
                        'from_schema': 'https://w3id.org/lara/lara_django_data',
                        'name': 'UUID',
                        'pattern': '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$',
                        'uri': 'https://datatracker.ietf.org/doc/html/rfc9562'}}} )


class ProcedureInstance(ConfiguredBaseModel):
    """
    <class 'lara_django_processes.models.ProcedureInstance'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_data'})

    pass


class Entity(ConfiguredBaseModel):
    """
    <class 'lara_django_people.models.Entity'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_data'})

    pass


class DataType(ConfiguredBaseModel):
    """
    <class 'lara_django_base.models.DataType'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_data'})

    pass


class Namespace(ConfiguredBaseModel):
    """
    <class 'lara_django_base.models.Namespace'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_data'})

    pass


class ExternalResource(ConfiguredBaseModel):
    """
    <class 'lara_django_base.models.ExternalResource'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_data'})

    pass


class MethodInstance(ConfiguredBaseModel):
    """
    <class 'lara_django_processes.models.MethodInstance'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_data'})

    pass


class Tag(ConfiguredBaseModel):
    """
    <class 'lara_django_base.models.Tag'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_data'})

    pass


class ProcessInstance(ConfiguredBaseModel):
    """
    <class 'lara_django_processes.models.ProcessInstance'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_data'})

    pass


class Group(ConfiguredBaseModel):
    """
    <class 'lara_django_people.models.Group'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_data'})

    pass


class MediaType(ConfiguredBaseModel):
    """
    <class 'lara_django_base.models.MediaType'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_data'})

    pass


class ExtraData(ConfiguredBaseModel):
    """
    \" This class can be used to extend data, by extra information,
        e.g. more telephone numbers, customer numbers, ...
    \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:data/ExtraData',
         'from_schema': 'https://w3id.org/lara/lara_django_data'})

    data_type: Optional[str] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'data_type',
         'domain_of': ['ExtraData', 'Visualisation', 'Data'],
         'slot_uri': 'lara:base/DataType'} })
    namespace: str = Field(..., description="""namespace of data""", json_schema_extra = { "linkml_meta": {'alias': 'namespace',
         'domain_of': ['ExtraData',
                       'Visualisation',
                       'Data',
                       'DataSubset',
                       'Evaluation'],
         'slot_uri': 'lara:base/Namespace'} })
    name_display: Optional[str] = Field(None, description="""Human readable display name or title of extra data""", json_schema_extra = { "linkml_meta": {'alias': 'name_display',
         'domain_of': ['ExtraData',
                       'Visualisation',
                       'Data',
                       'DataSubset',
                       'Evaluation'],
         'slot_uri': 'lara:data/ExtraData/name_display'} })
    name: Optional[str] = Field(None, description="""name of extra data""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['ExtraData',
                       'Visualisation',
                       'Data',
                       'DataSubset',
                       'Evaluation'],
         'slot_uri': 'lara:data/ExtraData/name'} })
    name_full: Optional[str] = Field(None, description="""full name of extra data""", json_schema_extra = { "linkml_meta": {'alias': 'name_full',
         'domain_of': ['ExtraData', 'Data'],
         'slot_uri': 'lara:data/ExtraData/name_full'} })
    version: Optional[str] = Field(None, description="""version of extra data""", json_schema_extra = { "linkml_meta": {'alias': 'version',
         'domain_of': ['ExtraData', 'Visualisation', 'Data', 'Evaluation'],
         'slot_uri': 'lara:data/ExtraData/version'} })
    hash_sha256: Optional[str] = Field(None, description="""SHA256 hash of all data (JSON and XML)""", json_schema_extra = { "linkml_meta": {'alias': 'hash_sha256',
         'domain_of': ['ExtraData', 'BlockchainHashes', 'Data', 'Evaluation'],
         'slot_uri': 'lara:data/ExtraData/hash_sha256'} })
    data_json: Optional[dict] = Field(None, description="""generic JSON field""", json_schema_extra = { "linkml_meta": {'alias': 'data_json',
         'domain_of': ['ExtraData', 'Data'],
         'slot_uri': 'lara:data/ExtraData/data_json'} })
    media_type: Optional[str] = Field(None, description="""IANA media type of extra data file""", json_schema_extra = { "linkml_meta": {'alias': 'media_type',
         'domain_of': ['ExtraData', 'Data'],
         'slot_uri': 'lara:base/MediaType'} })
    iri: Optional[str] = Field(None, description="""International Resource Identifier - IRI: is used for semantic representation """, json_schema_extra = { "linkml_meta": {'alias': 'iri',
         'domain_of': ['ExtraData', 'Visualisation', 'Data', 'Evaluation'],
         'slot_uri': 'lara:data/ExtraData/iri'} })
    url: Optional[str] = Field(None, description="""Universal Resource Locator - this can be used to link the data to external locations""", json_schema_extra = { "linkml_meta": {'alias': 'url',
         'domain_of': ['ExtraData'],
         'slot_uri': 'lara:data/ExtraData/url'} })
    datetime_created: Optional[str] = Field(None, description="""date and time when data was created""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_created',
         'domain_of': ['ExtraData', 'Visualisation', 'Data', 'Evaluation'],
         'slot_uri': 'lara:data/ExtraData/datetime_created'} })
    datetime_last_modified: Optional[str] = Field(None, description="""date and time when data was last modified""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['ExtraData',
                       'Visualisation',
                       'Data',
                       'DataSubset',
                       'Evaluation'],
         'slot_uri': 'lara:data/ExtraData/datetime_last_modified'} })
    description: Optional[str] = Field(None, description="""description of extra data""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['ExtraData',
                       'Visualisation',
                       'Data',
                       'DataSubset',
                       'Evaluation'],
         'slot_uri': 'lara:data/ExtraData/description'} })
    extradata_id: Optional[str] = Field(None, description="""ExtraData - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'extradata_id',
         'domain_of': ['ExtraData'],
         'slot_uri': 'lara:data/ExtraData/extradata_id'} })
    file: Optional[str] = Field(None, description="""rel. path/filename""", json_schema_extra = { "linkml_meta": {'alias': 'file',
         'domain_of': ['ExtraData', 'Data'],
         'slot_uri': 'lara:data/ExtraData/file'} })
    image: Optional[str] = Field(None, description="""location room map rel. path/filename to image""", json_schema_extra = { "linkml_meta": {'alias': 'image',
         'domain_of': ['ExtraData', 'Visualisation'],
         'slot_uri': 'lara:data/ExtraData/image'} })


class BlockchainHashes(ConfiguredBaseModel):
    """
    \" This class can be used to store hashes of data, which are stored in a blockchain.
        The hashes can be used to verify the integrity of the data.
        The hashes are stored in a separate table, to avoid circular dependencies.
    \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:data/BlockchainHashes',
         'from_schema': 'https://w3id.org/lara/lara_django_data'})

    blockchainhashes_id: Optional[str] = Field(None, description="""BlockchainHashes - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'blockchainhashes_id',
         'domain_of': ['BlockchainHashes'],
         'slot_uri': 'lara:data/BlockchainHashes/blockchainhashes_id'} })
    block_id: Optional[str] = Field(None, description="""Identifier of the data block for which the blockchain hash was currently calculated,e.g., data of a measurement series.""", json_schema_extra = { "linkml_meta": {'alias': 'block_id',
         'domain_of': ['BlockchainHashes'],
         'slot_uri': 'lara:data/BlockchainHashes/block_id'} })
    hash_sha256: Optional[str] = Field(None, description="""SHA256 hash of all data (JSON and XML)""", json_schema_extra = { "linkml_meta": {'alias': 'hash_sha256',
         'domain_of': ['ExtraData', 'BlockchainHashes', 'Data', 'Evaluation'],
         'slot_uri': 'lara:data/BlockchainHashes/hash_sha256'} })
    hash_sha512: Optional[str] = Field(None, description="""SHA512 hash of all data (JSON and XML)""", json_schema_extra = { "linkml_meta": {'alias': 'hash_sha512',
         'domain_of': ['BlockchainHashes'],
         'slot_uri': 'lara:data/BlockchainHashes/hash_sha512'} })
    timestamp: str = Field(..., description="""date and time when the blockchain hash was last modified""", json_schema_extra = { "linkml_meta": {'alias': 'timestamp',
         'domain_of': ['BlockchainHashes'],
         'slot_uri': 'lara:data/BlockchainHashes/timestamp'} })


class Visualisation(ConfiguredBaseModel):
    """
    \" Information and MetaInformation about visualisation of Data shall be stored here, like the method/procedure of plotting.
        This can be used to specify default visualisation routines for certain data types,
        e.g. bacterial growth data can be plotted with a 2D growth plot or heatmap.
        The name_full should only contain ASCII-alpha-numeric characters, no white-spaces, '-', '_' and '.' .
        For versioning semantic versioning (https://semver.org/lang/en/) shall be used.
    \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:data/Visualisation',
         'from_schema': 'https://w3id.org/lara/lara_django_data'})

    visualisation_id: Optional[str] = Field(None, description="""Visualisation - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'visualisation_id',
         'domain_of': ['Visualisation'],
         'slot_uri': 'lara:data/Visualisation/visualisation_id'} })
    namespace: Optional[str] = Field(None, description="""namespace of visualisation""", json_schema_extra = { "linkml_meta": {'alias': 'namespace',
         'domain_of': ['ExtraData',
                       'Visualisation',
                       'Data',
                       'DataSubset',
                       'Evaluation'],
         'slot_uri': 'lara:base/Namespace'} })
    name_display: Optional[str] = Field(None, description="""human readable name of the visualisation, e.g. for display in figures, tables, ...""", json_schema_extra = { "linkml_meta": {'alias': 'name_display',
         'domain_of': ['ExtraData',
                       'Visualisation',
                       'Data',
                       'DataSubset',
                       'Evaluation'],
         'slot_uri': 'lara:data/Visualisation/name_display'} })
    name: Optional[str] = Field(None, description="""name of the visualisation""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['ExtraData',
                       'Visualisation',
                       'Data',
                       'DataSubset',
                       'Evaluation'],
         'slot_uri': 'lara:data/Visualisation/name'} })
    version: Optional[str] = Field(None, description="""maj.min.patch version of this visualisation, e.g. 0.0.1""", json_schema_extra = { "linkml_meta": {'alias': 'version',
         'domain_of': ['ExtraData', 'Visualisation', 'Data', 'Evaluation'],
         'slot_uri': 'lara:data/Visualisation/version'} })
    data_type: Optional[str] = Field(None, description="""associate a data type to this method""", json_schema_extra = { "linkml_meta": {'alias': 'data_type',
         'domain_of': ['ExtraData', 'Visualisation', 'Data'],
         'slot_uri': 'lara:base/DataType'} })
    plotting_method_instance: Optional[str] = Field(None, description="""plotting method to generate a visualisation""", json_schema_extra = { "linkml_meta": {'alias': 'plotting_method_instance',
         'domain_of': ['Visualisation'],
         'slot_uri': 'lara:processes/MethodInstance'} })
    plotting_procedure_instance: Optional[str] = Field(None, description="""plotting procedure to generate a visualisation""", json_schema_extra = { "linkml_meta": {'alias': 'plotting_procedure_instance',
         'domain_of': ['Visualisation'],
         'slot_uri': 'lara:processes/ProcedureInstance'} })
    rendering_components: Optional[dict] = Field(None, description="""custom html/css/javascript framework components, like Vue.js components or templates for rendering""", json_schema_extra = { "linkml_meta": {'alias': 'rendering_components',
         'domain_of': ['Visualisation'],
         'slot_uri': 'lara:data/Visualisation/rendering_components'} })
    iri: Optional[str] = Field(None, description="""International Resource Identifier - IRI: is used for semantic representation """, json_schema_extra = { "linkml_meta": {'alias': 'iri',
         'domain_of': ['ExtraData', 'Visualisation', 'Data', 'Evaluation'],
         'slot_uri': 'lara:data/Visualisation/iri'} })
    caption: Optional[dict] = Field(None, description="""figure or table caption""", json_schema_extra = { "linkml_meta": {'alias': 'caption',
         'domain_of': ['Visualisation', 'Evaluation'],
         'slot_uri': 'lara:data/Visualisation/caption'} })
    thumbnail: Optional[str] = Field(None, description="""XML/SVG thumbnail / symbolising the data""", json_schema_extra = { "linkml_meta": {'alias': 'thumbnail',
         'domain_of': ['Visualisation', 'Data'],
         'slot_uri': 'lara:data/Visualisation/thumbnail'} })
    image: Optional[str] = Field(None, description="""location path/filename to image""", json_schema_extra = { "linkml_meta": {'alias': 'image',
         'domain_of': ['ExtraData', 'Visualisation'],
         'slot_uri': 'lara:data/Visualisation/image'} })
    description: Optional[str] = Field(None, description="""description of the visualisation""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['ExtraData',
                       'Visualisation',
                       'Data',
                       'DataSubset',
                       'Evaluation'],
         'slot_uri': 'lara:data/Visualisation/description'} })
    datetime_created: Optional[str] = Field(None, description="""date and time when data was created""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_created',
         'domain_of': ['ExtraData', 'Visualisation', 'Data', 'Evaluation'],
         'slot_uri': 'lara:data/Visualisation/datetime_created'} })
    datetime_last_modified: Optional[str] = Field(None, description="""date and time when data was last modified""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['ExtraData',
                       'Visualisation',
                       'Data',
                       'DataSubset',
                       'Evaluation'],
         'slot_uri': 'lara:data/Visualisation/datetime_last_modified'} })
    order: Optional[int] = Field(None, description="""order of visualisation in a list""", json_schema_extra = { "linkml_meta": {'alias': 'order',
         'domain_of': ['Visualisation', 'OrderedDataDataSubset'],
         'slot_uri': 'lara:data/Visualisation/order'} })
    tags: Optional[List[str]] = Field(None, description="""tags to classify the visualisation""", json_schema_extra = { "linkml_meta": {'alias': 'tags',
         'domain_of': ['Visualisation', 'Data', 'DataSubset', 'Evaluation'],
         'slot_uri': 'lara:base/Tag'} })
    resources_external: Optional[List[str]] = Field(None, description="""external resources, like literature, websites, manuals, ...""", json_schema_extra = { "linkml_meta": {'alias': 'resources_external',
         'domain_of': ['Visualisation', 'Data', 'Evaluation'],
         'slot_uri': 'lara:base/ExternalResource'} })


class Data(ConfiguredBaseModel):
    """
    \" Generic data class. All data, like data from experiments, measurements or evaluations will be stored here.
        There are also references to the way, how the data is produced, evaluated and visualised.
        The data contains a reference to the process which generated the data.
        For versioning semantic versioning (https://semver.org/lang/en/) shall be used.
        .. todo:: - check, whether UUID is required, if hash is there...
                  - Blockchain data
    \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:data/Data',
         'from_schema': 'https://w3id.org/lara/lara_django_data'})

    data_id: Optional[str] = Field(None, description="""Data - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'data_id',
         'domain_of': ['Data'],
         'slot_uri': 'lara:data/Data/data_id'} })
    data_type: Optional[str] = Field(None, description="""data type of this data item, e.g.  FASTA, AB1, AnIML, ...""", json_schema_extra = { "linkml_meta": {'alias': 'data_type',
         'domain_of': ['ExtraData', 'Visualisation', 'Data'],
         'slot_uri': 'lara:base/DataType'} })
    media_type: Optional[str] = Field(None, description="""IANA data media type of this data item, e.g. txt/xml, txt/csv, ......""", json_schema_extra = { "linkml_meta": {'alias': 'media_type',
         'domain_of': ['ExtraData', 'Data'],
         'slot_uri': 'lara:base/MediaType'} })
    namespace: str = Field(..., description="""namespace of data""", json_schema_extra = { "linkml_meta": {'alias': 'namespace',
         'domain_of': ['ExtraData',
                       'Visualisation',
                       'Data',
                       'DataSubset',
                       'Evaluation'],
         'slot_uri': 'lara:base/Namespace'} })
    name: Optional[str] = Field(None, description="""name of the data""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['ExtraData',
                       'Visualisation',
                       'Data',
                       'DataSubset',
                       'Evaluation'],
         'slot_uri': 'lara:data/Data/name'} })
    version: Optional[str] = Field(None, description="""maj.min.patch version of this data set, e.g. 0.0.1""", json_schema_extra = { "linkml_meta": {'alias': 'version',
         'domain_of': ['ExtraData', 'Visualisation', 'Data', 'Evaluation'],
         'slot_uri': 'lara:data/Data/version'} })
    name_display: Optional[str] = Field(None, description="""human readable name of the data, e.g. for display in figures, tables, ...""", json_schema_extra = { "linkml_meta": {'alias': 'name_display',
         'domain_of': ['ExtraData',
                       'Visualisation',
                       'Data',
                       'DataSubset',
                       'Evaluation'],
         'slot_uri': 'lara:data/Data/name_display'} })
    name_full: Optional[str] = Field(None, description="""fully qualified name of the data, including namespace and version; the name_full should only contain ASCII-alpha-numeric characters, no white-spaces, '-', '_' and '.' .""", json_schema_extra = { "linkml_meta": {'alias': 'name_full',
         'domain_of': ['ExtraData', 'Data'],
         'slot_uri': 'lara:data/Data/name_full'} })
    hash_sha256: Optional[str] = Field(None, description="""SHA256 hash of all data, to ensure data integrity""", json_schema_extra = { "linkml_meta": {'alias': 'hash_sha256',
         'domain_of': ['ExtraData', 'BlockchainHashes', 'Data', 'Evaluation'],
         'slot_uri': 'lara:data/Data/hash_sha256'} })
    hash_blockchain: Optional[str] = Field(None, description="""SHA256 hash of all data, to ensure data integrity""", json_schema_extra = { "linkml_meta": {'alias': 'hash_blockchain',
         'domain_of': ['Data'],
         'slot_uri': 'lara:data/Data/hash_blockchain'} })
    acl: Optional[dict] = Field(None, description="""access control list - fine grained data access control""", json_schema_extra = { "linkml_meta": {'alias': 'acl', 'domain_of': ['Data'], 'slot_uri': 'lara:data/Data/acl'} })
    licenses: Optional[dict] = Field(None, description="""licenses of this data - with a JSON object, fine grained licenses can be defined, like embargo times, commercial use, academic use, ...""", json_schema_extra = { "linkml_meta": {'alias': 'licenses',
         'domain_of': ['Data'],
         'slot_uri': 'lara:data/Data/licenses'} })
    datetime_created: Optional[str] = Field(None, description="""date and time when data was created""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_created',
         'domain_of': ['ExtraData', 'Visualisation', 'Data', 'Evaluation'],
         'slot_uri': 'lara:data/Data/datetime_created'} })
    datetime_last_modified: Optional[str] = Field(None, description="""date and time when data was last modified""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['ExtraData',
                       'Visualisation',
                       'Data',
                       'DataSubset',
                       'Evaluation'],
         'slot_uri': 'lara:data/Data/datetime_last_modified'} })
    method_instance: Optional[str] = Field(None, description="""measurement or evaluation method, like SeqDNA, SeqProtein, SPabs, ...""", json_schema_extra = { "linkml_meta": {'alias': 'method_instance',
         'domain_of': ['Data'],
         'slot_uri': 'lara:processes/MethodInstance'} })
    procedure_instance: Optional[str] = Field(None, description="""measurement or evaluation procedure, like SeqDNA, SeqProtein, SPabs, ...""", json_schema_extra = { "linkml_meta": {'alias': 'procedure_instance',
         'domain_of': ['Data'],
         'slot_uri': 'lara:processes/ProcedureInstance'} })
    process_instance: Optional[str] = Field(None, description="""process that generated the data, the process contains the procedures.""", json_schema_extra = { "linkml_meta": {'alias': 'process_instance',
         'domain_of': ['Data'],
         'slot_uri': 'lara:processes/MethodInstanceAbstr'} })
    data_json: Optional[dict] = Field(None, description="""JSON representation of the data""", json_schema_extra = { "linkml_meta": {'alias': 'data_json',
         'domain_of': ['ExtraData', 'Data'],
         'slot_uri': 'lara:data/Data/data_json'} })
    metadata: Optional[dict] = Field(None, description="""metadata in JSON-LD format, like units, visualisation factor/unit""", json_schema_extra = { "linkml_meta": {'alias': 'metadata',
         'domain_of': ['Data'],
         'slot_uri': 'lara:data/Data/metadata'} })
    iri: Optional[str] = Field(None, description="""International Resource Identifier to instance of OWL class: is used for semantic representation """, json_schema_extra = { "linkml_meta": {'alias': 'iri',
         'domain_of': ['ExtraData', 'Visualisation', 'Data', 'Evaluation'],
         'slot_uri': 'lara:data/Data/iri'} })
    pid: Optional[str] = Field(None, description="""Persitent Identifier [PID/handle URI](https://www.handle.net/)""", json_schema_extra = { "linkml_meta": {'alias': 'pid',
         'domain_of': ['Data', 'Evaluation'],
         'slot_uri': 'lara:data/Data/pid'} })
    doi: Optional[str] = Field(None, description="""Digital Object Identifier to the data""", json_schema_extra = { "linkml_meta": {'alias': 'doi',
         'domain_of': ['Data', 'Evaluation'],
         'slot_uri': 'lara:data/Data/doi'} })
    pac_id: Optional[str] = Field(None, description="""Publicly Addressable Content IDentifier is a globally unique identifier that operates independently of a central registry.""", json_schema_extra = { "linkml_meta": {'alias': 'pac_id', 'domain_of': ['Data'], 'slot_uri': 'lara:data/Data/pac_id'} })
    file: Optional[str] = Field(None, description="""rel. path/filename of dataset in filesystem or object storage""", json_schema_extra = { "linkml_meta": {'alias': 'file',
         'domain_of': ['ExtraData', 'Data'],
         'slot_uri': 'lara:data/Data/file'} })
    thumbnail: Optional[str] = Field(None, description="""XML/SVG thumbnail / symbolising the data""", json_schema_extra = { "linkml_meta": {'alias': 'thumbnail',
         'domain_of': ['Visualisation', 'Data'],
         'slot_uri': 'lara:data/Data/thumbnail'} })
    description: Optional[str] = Field(None, description="""description of the data""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['ExtraData',
                       'Visualisation',
                       'Data',
                       'DataSubset',
                       'Evaluation'],
         'slot_uri': 'lara:data/Data/description'} })
    remarks: Optional[str] = Field(None, description="""remarks about the data""", json_schema_extra = { "linkml_meta": {'alias': 'remarks',
         'domain_of': ['Data'],
         'slot_uri': 'lara:data/Data/remarks'} })
    users: Optional[List[str]] = Field(None, description="""entities, who can access/use this data - contributors/roles and fine grained access control shall be handled via acl and metadata.""", json_schema_extra = { "linkml_meta": {'alias': 'users', 'domain_of': ['Data'], 'slot_uri': 'lara:people/Entity'} })
    groups: Optional[List[str]] = Field(None, description="""groups accessing/using this data""", json_schema_extra = { "linkml_meta": {'alias': 'groups', 'domain_of': ['Data'], 'slot_uri': 'lara:people/Group'} })
    visualisations: Optional[List[str]] = Field(None, description="""visualisations of the data""", json_schema_extra = { "linkml_meta": {'alias': 'visualisations',
         'domain_of': ['Data', 'Evaluation', 'Container'],
         'slot_uri': 'lara:data/Visualisation'} })
    data_extra: Optional[List[str]] = Field(None, description="""extra data, like additional information about data or the evaluation ...""", json_schema_extra = { "linkml_meta": {'alias': 'data_extra',
         'domain_of': ['Data'],
         'slot_uri': 'lara:data/ExtraData'} })
    resources_external: Optional[List[str]] = Field(None, description="""external resources, like literature, websites, manuals, ...""", json_schema_extra = { "linkml_meta": {'alias': 'resources_external',
         'domain_of': ['Visualisation', 'Data', 'Evaluation'],
         'slot_uri': 'lara:base/ExternalResource'} })
    tags: Optional[List[str]] = Field(None, description="""tags""", json_schema_extra = { "linkml_meta": {'alias': 'tags',
         'domain_of': ['Visualisation', 'Data', 'DataSubset', 'Evaluation'],
         'slot_uri': 'lara:base/Tag'} })


class DataSubset(ConfiguredBaseModel):
    """
    \" User or group defined subset of multi-step reactions \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:data/DataSubset',
         'from_schema': 'https://w3id.org/lara/lara_django_data'})

    namespace: Optional[str] = Field(None, description="""namespace of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'namespace',
         'domain_of': ['ExtraData',
                       'Visualisation',
                       'Data',
                       'DataSubset',
                       'Evaluation'],
         'slot_uri': 'lara:base/Namespace'} })
    name_display: Optional[str] = Field(None, description="""display name of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'name_display',
         'domain_of': ['ExtraData',
                       'Visualisation',
                       'Data',
                       'DataSubset',
                       'Evaluation'],
         'slot_uri': 'lara:data/DataSubset/name_display'} })
    name: Optional[str] = Field(None, description="""name of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['ExtraData',
                       'Visualisation',
                       'Data',
                       'DataSubset',
                       'Evaluation'],
         'slot_uri': 'lara:data/DataSubset/name'} })
    entity: Optional[str] = Field(None, description="""user who created the subset""", json_schema_extra = { "linkml_meta": {'alias': 'entity',
         'domain_of': ['DataSubset'],
         'slot_uri': 'lara:people/Entity'} })
    group: Optional[str] = Field(None, description="""group who created the subset""", json_schema_extra = { "linkml_meta": {'alias': 'group', 'domain_of': ['DataSubset'], 'slot_uri': 'lara:people/Group'} })
    description: Optional[str] = Field(None, description="""description of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['ExtraData',
                       'Visualisation',
                       'Data',
                       'DataSubset',
                       'Evaluation'],
         'slot_uri': 'lara:data/DataSubset/description'} })
    datetime_last_modified: Optional[str] = Field(None, description="""datetime of last modification of the selection""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['ExtraData',
                       'Visualisation',
                       'Data',
                       'DataSubset',
                       'Evaluation'],
         'slot_uri': 'lara:data/DataSubset/datetime_last_modified'} })
    datasubset_id: Optional[str] = Field(None, description="""DataSubset - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'datasubset_id',
         'domain_of': ['DataSubset'],
         'slot_uri': 'lara:data/DataSubset/datasubset_id'} })
    tags: Optional[List[str]] = Field(None, description="""tags""", json_schema_extra = { "linkml_meta": {'alias': 'tags',
         'domain_of': ['Visualisation', 'Data', 'DataSubset', 'Evaluation'],
         'slot_uri': 'lara:base/Tag'} })
    data: Optional[List[str]] = Field(None, description="""data items""", json_schema_extra = { "linkml_meta": {'alias': 'data',
         'domain_of': ['DataSubset', 'OrderedDataDataSubset'],
         'slot_uri': 'lara:data/Data'} })


class OrderedDataDataSubset(ConfiguredBaseModel):
    """
    \" Through model for the many-to-many relationship between DataSubset and Data. 
        This class can be used to store the order of data in a subset
    \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:data/OrderedDataDataSubset',
         'from_schema': 'https://w3id.org/lara/lara_django_data'})

    ordereddatadatasubset_id: Optional[str] = Field(None, description="""OrderedDataDataSubset - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'ordereddatadatasubset_id',
         'domain_of': ['OrderedDataDataSubset'],
         'slot_uri': 'lara:data/OrderedDataDataSubset/ordereddatadatasubset_id'} })
    data: str = Field(..., description="""data in the subset""", json_schema_extra = { "linkml_meta": {'alias': 'data',
         'domain_of': ['DataSubset', 'OrderedDataDataSubset'],
         'slot_uri': 'lara:data/Data'} })
    data_subset: str = Field(..., description="""subset of data""", json_schema_extra = { "linkml_meta": {'alias': 'data_subset',
         'domain_of': ['OrderedDataDataSubset'],
         'slot_uri': 'lara:data/DataSubset'} })
    order: int = Field(..., description="""order of data in subset""", json_schema_extra = { "linkml_meta": {'alias': 'order',
         'domain_of': ['Visualisation', 'OrderedDataDataSubset'],
         'slot_uri': 'lara:data/OrderedDataDataSubset/order'} })


class Evaluation(ConfiguredBaseModel):
    """
    \" This class can be used to describe evaluation information.
        The name_full should only contain ASCII-alpha-numeric characters, no white-spaces, '-', '_' and '.' .
        For versioning semantic versioning (https://semver.org/lang/en/) shall be used.
         .. todo::
             - auto hashing
             - ensure that data and results cannot be modified ? (by hash checking)
             - method versioning
             - due to an unknown reason it is impossible to feedback on experiments (generates circular dependancy error).
               This should be fixed in a later version of the database
    \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:data/Evaluation',
         'from_schema': 'https://w3id.org/lara/lara_django_data'})

    evaluation_id: Optional[str] = Field(None, description="""Evaluation - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'evaluation_id',
         'domain_of': ['Evaluation'],
         'slot_uri': 'lara:data/Evaluation/evaluation_id'} })
    namespace: Optional[str] = Field(None, description="""namespace of evaluation""", json_schema_extra = { "linkml_meta": {'alias': 'namespace',
         'domain_of': ['ExtraData',
                       'Visualisation',
                       'Data',
                       'DataSubset',
                       'Evaluation'],
         'slot_uri': 'lara:base/Namespace'} })
    name_display: Optional[str] = Field(None, description="""human readable name of the evaluation, e.g. for display in figures, tables, ...""", json_schema_extra = { "linkml_meta": {'alias': 'name_display',
         'domain_of': ['ExtraData',
                       'Visualisation',
                       'Data',
                       'DataSubset',
                       'Evaluation'],
         'slot_uri': 'lara:data/Evaluation/name_display'} })
    name: Optional[str] = Field(None, description="""name of the evaluation""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['ExtraData',
                       'Visualisation',
                       'Data',
                       'DataSubset',
                       'Evaluation'],
         'slot_uri': 'lara:data/Evaluation/name'} })
    version: Optional[str] = Field(None, description="""maj.min.patch version of this visualisation, e.g. 0.0.1""", json_schema_extra = { "linkml_meta": {'alias': 'version',
         'domain_of': ['ExtraData', 'Visualisation', 'Data', 'Evaluation'],
         'slot_uri': 'lara:data/Evaluation/version'} })
    hash_sha256: Optional[str] = Field(None, description="""SHA256 hash of all hashes of eval methods and data""", json_schema_extra = { "linkml_meta": {'alias': 'hash_sha256',
         'domain_of': ['ExtraData', 'BlockchainHashes', 'Data', 'Evaluation'],
         'slot_uri': 'lara:data/Evaluation/hash_sha256'} })
    parameters: Optional[dict] = Field(None, description="""parameters used for evaluation, e.g. left and right limits, etc.""", json_schema_extra = { "linkml_meta": {'alias': 'parameters',
         'domain_of': ['Evaluation'],
         'slot_uri': 'lara:data/Evaluation/parameters'} })
    eval_method_instance: Optional[str] = Field(None, description="""evaluation method""", json_schema_extra = { "linkml_meta": {'alias': 'eval_method_instance',
         'domain_of': ['Evaluation'],
         'slot_uri': 'lara:processes/MethodInstance'} })
    eval_procedure_instance: Optional[str] = Field(None, description="""evaluation procedure""", json_schema_extra = { "linkml_meta": {'alias': 'eval_procedure_instance',
         'domain_of': ['Evaluation'],
         'slot_uri': 'lara:processes/ProcedureInstance'} })
    iri: Optional[str] = Field(None, description="""International Resource Identifier - IRI: is used for semantic representation """, json_schema_extra = { "linkml_meta": {'alias': 'iri',
         'domain_of': ['ExtraData', 'Visualisation', 'Data', 'Evaluation'],
         'slot_uri': 'lara:data/Evaluation/iri'} })
    pid: Optional[str] = Field(None, description="""Persitent Identifier [PID/handle URI](https://www.handle.net/)""", json_schema_extra = { "linkml_meta": {'alias': 'pid',
         'domain_of': ['Data', 'Evaluation'],
         'slot_uri': 'lara:data/Evaluation/pid'} })
    doi: Optional[str] = Field(None, description="""Digital Object Identifier to the data""", json_schema_extra = { "linkml_meta": {'alias': 'doi',
         'domain_of': ['Data', 'Evaluation'],
         'slot_uri': 'lara:data/Evaluation/doi'} })
    caption: Optional[dict] = Field(None, description="""can be used as table caption""", json_schema_extra = { "linkml_meta": {'alias': 'caption',
         'domain_of': ['Visualisation', 'Evaluation'],
         'slot_uri': 'lara:data/Evaluation/caption'} })
    description: Optional[str] = Field(None, description="""description""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['ExtraData',
                       'Visualisation',
                       'Data',
                       'DataSubset',
                       'Evaluation'],
         'slot_uri': 'lara:data/Evaluation/description'} })
    datetime_created: Optional[str] = Field(None, description="""date and time when data was created""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_created',
         'domain_of': ['ExtraData', 'Visualisation', 'Data', 'Evaluation'],
         'slot_uri': 'lara:data/Evaluation/datetime_created'} })
    datetime_last_modified: Optional[str] = Field(None, description="""date and time when data was last modified""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['ExtraData',
                       'Visualisation',
                       'Data',
                       'DataSubset',
                       'Evaluation'],
         'slot_uri': 'lara:data/Evaluation/datetime_last_modified'} })
    parent_evals: Optional[List[str]] = Field(None, description="""to define a tree/network of evaluations and to go back in the evaluation process""", json_schema_extra = { "linkml_meta": {'alias': 'parent_evals',
         'domain_of': ['Evaluation'],
         'slot_uri': 'lara:data/Evaluation'} })
    data_eval: Optional[List[str]] = Field(None, description="""all data that is used for this evaluation""", json_schema_extra = { "linkml_meta": {'alias': 'data_eval',
         'domain_of': ['Evaluation'],
         'slot_uri': 'lara:data/Data'} })
    data_results: Optional[List[str]] = Field(None, description="""all data that is generated by this evaluation""", json_schema_extra = { "linkml_meta": {'alias': 'data_results',
         'domain_of': ['Evaluation'],
         'slot_uri': 'lara:data/Data'} })
    visualisations: Optional[List[str]] = Field(None, description="""visualisations of this evaluated data""", json_schema_extra = { "linkml_meta": {'alias': 'visualisations',
         'domain_of': ['Data', 'Evaluation', 'Container'],
         'slot_uri': 'lara:data/Visualisation'} })
    resources_external: Optional[List[str]] = Field(None, description="""external resources, like literature, websites, manuals, ...""", json_schema_extra = { "linkml_meta": {'alias': 'resources_external',
         'domain_of': ['Visualisation', 'Data', 'Evaluation'],
         'slot_uri': 'lara:base/ExternalResource'} })
    tags: Optional[List[str]] = Field(None, description="""tags, characterising the evaluation""", json_schema_extra = { "linkml_meta": {'alias': 'tags',
         'domain_of': ['Visualisation', 'Data', 'DataSubset', 'Evaluation'],
         'slot_uri': 'lara:base/Tag'} })


class Container(ConfiguredBaseModel):
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_data', 'tree_root': True})

    extradatas: Optional[List[ExtraData]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'extradatas', 'domain_of': ['Container']} })
    blockchainhashess: Optional[List[BlockchainHashes]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'blockchainhashess', 'domain_of': ['Container']} })
    visualisations: Optional[List[Visualisation]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'visualisations', 'domain_of': ['Data', 'Evaluation', 'Container']} })
    datas: Optional[List[Data]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'datas', 'domain_of': ['Container']} })
    datasubsets: Optional[List[DataSubset]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'datasubsets', 'domain_of': ['Container']} })
    ordereddatadatasubsets: Optional[List[OrderedDataDataSubset]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'ordereddatadatasubsets', 'domain_of': ['Container']} })
    evaluations: Optional[List[Evaluation]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'evaluations', 'domain_of': ['Container']} })


# Model rebuild
# see https://pydantic-docs.helpmanual.io/usage/models/#rebuilding-a-model
ProcedureInstance.model_rebuild()
Entity.model_rebuild()
DataType.model_rebuild()
Namespace.model_rebuild()
ExternalResource.model_rebuild()
MethodInstance.model_rebuild()
Tag.model_rebuild()
ProcessInstance.model_rebuild()
Group.model_rebuild()
MediaType.model_rebuild()
ExtraData.model_rebuild()
BlockchainHashes.model_rebuild()
Visualisation.model_rebuild()
Data.model_rebuild()
DataSubset.model_rebuild()
OrderedDataDataSubset.model_rebuild()
Evaluation.model_rebuild()
Container.model_rebuild()

