from __future__ import annotations
from datetime import datetime, date
from enum import Enum
from typing import List, Dict, Optional, Any, Union
from pydantic import BaseModel as BaseModel, ConfigDict,  Field, field_validator
import re
import sys
if sys.version_info >= (3, 8):
    from typing import Literal
else:
    from typing_extensions import Literal


metamodel_version = "None"
version = "None"

class ConfiguredBaseModel(BaseModel):
    model_config = ConfigDict(
        validate_assignment=True,
        validate_default=True,
        extra = 'forbid',
        arbitrary_types_allowed=True,
        use_enum_values = True)


class DataType(ConfiguredBaseModel):
    """
    <class 'lara_django_base.models.DataType'>
    """
    None
    
        

class Tag(ConfiguredBaseModel):
    """
    <class 'lara_django_base.models.Tag'>
    """
    None
    
        

class ExternalResource(ConfiguredBaseModel):
    """
    <class 'lara_django_base.models.ExternalResource'>
    """
    None
    
        

class Group(ConfiguredBaseModel):
    """
    <class 'lara_django_people.models.Group'>
    """
    None
    
        

class MediaType(ConfiguredBaseModel):
    """
    <class 'lara_django_base.models.MediaType'>
    """
    None
    
        

class Entity(ConfiguredBaseModel):
    """
    <class 'lara_django_people.models.Entity'>
    """
    None
    
        

class ProcessInstance(ConfiguredBaseModel):
    """
    <class 'lara_django_processes.models.ProcessInstance'>
    """
    None
    
        

class ProcedureInstance(ConfiguredBaseModel):
    """
    <class 'lara_django_processes.models.ProcedureInstance'>
    """
    None
    
        

class MethodInstance(ConfiguredBaseModel):
    """
    <class 'lara_django_processes.models.MethodInstance'>
    """
    None
    
        

class Namespace(ConfiguredBaseModel):
    """
    <class 'lara_django_base.models.Namespace'>
    """
    None
    
        

class ExtraData(ConfiguredBaseModel):
    """
    \" This class can be used to extend data, by extra information,
    e.g. more telephone numbers, customer numbers, ...
\"
    """
    data_type: Optional[DataType] = Field(None)
    namespace: Optional[Namespace] = Field(None, description="""namespace of data""")
    title: Optional[str] = Field(None, description="""Human readable title of extra data""")
    name: Optional[str] = Field(None, description="""name of extra data""")
    name_full: Optional[str] = Field(None, description="""full name of extra data""")
    version: Optional[str] = Field(None, description="""version of extra data""")
    UUID: str = Field(..., description="""data UUID""")
    hash_sha256: Optional[str] = Field(None, description="""SHA256 hash of all data (JSON and XML)""")
    data_json: Optional[str] = Field(None, description="""generic JSON field""")
    media_type: Optional[MediaType] = Field(None, description="""IANA media type of extra data file""")
    iri: Optional[str] = Field(None, description="""International Resource Identifier - IRI: is used for semantic representation """)
    URL: Optional[str] = Field(None, description="""Universal Resource Locator - this can be used to link the data to external locations""")
    datetime_created: date = Field(..., description="""date and time when data was created""")
    datetime_last_modified: date = Field(..., description="""date and time when data was last modified""")
    description: Optional[str] = Field(None, description="""description of extra data""")
    extradata_id: Optional[str] = Field(None, description="""ExtraData - primary key (UUID)""")
    file: Optional[str] = Field(None, description="""rel. path/data_file""")
    image: Optional[str] = Field(None, description="""location room map rel. path/filename to image""")
    
        

class BlockchainHashes(ConfiguredBaseModel):
    """
    \" This class can be used to store hashes of data, which are stored in a blockchain.
    The hashes can be used to verify the integrity of the data.
    The hashes are stored in a separate table, to avoid circular dependencies.
\"
    """
    blockchain_hashes_id: Optional[str] = Field(None, description="""BlockchainHashes - primary key (UUID)""")
    hash_sha256: Optional[str] = Field(None, description="""SHA256 hash of all data (JSON and XML)""")
    hash_sha512: Optional[str] = Field(None, description="""SHA512 hash of all data (JSON and XML)""")
    datetime_last_modified: date = Field(..., description="""date and time when the blockchain hash was last modified""")
    
        

class Visualisation(ConfiguredBaseModel):
    """
    \" Information and MetaInformation about visualisation of Data shall be stored here, like the method/procedure of plotting.
    This can be used to specify default visualisation routines for certain data types,
    e.g. bacterial growth data can be plotted with a 2D growth plot or heatmap.
    The name_full should only contain ASCII-alpha-numeric characters, no white-spaces, '-', '_' and '.' .
    For versioning semantic versioning (https://semver.org/lang/en/) shall be used.
\"
    """
    visualisation_id: Optional[str] = Field(None, description="""Visualisation - primary key (UUID)""")
    namespace: Optional[Namespace] = Field(None, description="""namespace of visualisation""")
    name: Optional[str] = Field(None, description="""name of the visualisation""")
    version: Optional[str] = Field(None, description="""maj.min.patch version of this visualisation, e.g. 0.0.1""")
    name_full: Optional[str] = Field(None, description="""fully qualified name of the visualisation, including namespace and version; the name_full should only contain ASCII-alpha-numeric characters, no white-spaces, '-', '_' and '.' .""")
    data_type: Optional[DataType] = Field(None, description="""associate a data type to this method""")
    plotting_method_instance: Optional[MethodInstance] = Field(None, description="""plotting method to generate a visualisation""")
    plotting_procedure_instance: Optional[ProcedureInstance] = Field(None, description="""plotting procedure to generate a visualisation""")
    rendering_html_template: Optional[str] = Field(None, description="""custom html template e.g. a DJANGO template for rendering""")
    rendering_css_template: Optional[str] = Field(None, description="""custom css of custom html template e.g. a DJANGO template""")
    rendering_component: Optional[str] = Field(None, description="""custom javascript framework components, like Vue.js components for rendering""")
    iri: Optional[str] = Field(None, description="""International Resource Identifier - IRI: is used for semantic representation """)
    caption: Optional[str] = Field(None, description="""figure or table caption""")
    thumbnail: Optional[str] = Field(None, description="""XML/SVG thumbnail / symbolising the data""")
    image: Optional[str] = Field(None, description="""location path/filename to image""")
    description: Optional[str] = Field(None, description="""description of the visualisation""")
    tags: Optional[List[Tag]] = Field(default_factory=list, description="""tags to classify the visualisation""")
    resources_external: Optional[List[ExternalResource]] = Field(default_factory=list, description="""external resources, like literature, websites, manuals, ...""")
    
        

class Data(ConfiguredBaseModel):
    """
    \" Generic data class. All data, like data from experiments, measurements or evaluations will be stored here.
    There are also references to the way, how the data is produced, evaluated and visualised.
    The data contains a reference to the process which generated the data.
    For versioning semantic versioning (https://semver.org/lang/en/) shall be used.
    .. todo:: - check, whether UUID is required, if hash is there...
              - Blockchain data
\"
    """
    data_id: Optional[str] = Field(None, description="""Data - primary key (UUID)""")
    data_type: Optional[DataType] = Field(None, description="""data type of this data item, e.g.  FASTA, AB1, AnIML, ...""")
    media_type: Optional[MediaType] = Field(None, description="""IANA data media type of this data item, e.g. txt/xml, txt/csv, ......""")
    namespace: Namespace = Field(..., description="""namespace of data""")
    name: Optional[str] = Field(None, description="""name of the data""")
    version: str = Field(..., description="""maj.min.patch version of this data set, e.g. 0.0.1""")
    title: Optional[str] = Field(None, description="""human readable name of the data, e.g. for display in figures, tables, ...""")
    name_full: Optional[str] = Field(None, description="""fully qualified name of the data, including namespace and version; the name_full should only contain ASCII-alpha-numeric characters, no white-spaces, '-', '_' and '.' .""")
    UUID: str = Field(..., description="""data UUID""")
    hash_sha256: Optional[str] = Field(None, description="""SHA256 hash of all data (JSON and XML)""")
    acl: Optional[str] = Field(None, description="""access control list - fine grained data access control""")
    licenses: Optional[str] = Field(None, description="""licenses of this data - with a JSON object, fine grained licenses can be defined, like embargo times, commercial use, academic use, ...""")
    datetime_created: date = Field(..., description="""date and time when data was created""")
    datetime_last_modified: date = Field(..., description="""date and time when data was last modified""")
    method_instance: Optional[MethodInstance] = Field(None, description="""measurement or evaluation method, like SeqDNA, SeqProtein, SPabs, ...""")
    procedure_instance: Optional[ProcedureInstance] = Field(None, description="""measurement or evaluation procedure, like SeqDNA, SeqProtein, SPabs, ...""")
    process_instance: Optional[ProcessInstance] = Field(None, description="""process that generated the data, the process contains the procedures.""")
    data_json: Optional[str] = Field(None, description="""JSON representation of the data""")
    metadata: Optional[str] = Field(None, description="""metadata in JSON-LD format, like units, visualisation factor/unit""")
    iri: Optional[str] = Field(None, description="""International Resource Identifier to instance of OWL class: is used for semantic representation """)
    pid: Optional[str] = Field(None, description="""Persitent Identifier [PID/handle URI](https://www.handle.net/)""")
    doi: Optional[str] = Field(None, description="""Digital Object Identifier to the data""")
    file: Optional[str] = Field(None, description="""rel. path/filename of dataset in filesystem or object storage""")
    thumbnail: Optional[str] = Field(None, description="""XML/SVG thumbnail / symbolising the data""")
    description: Optional[str] = Field(None, description="""description of the data""")
    remarks: Optional[str] = Field(None, description="""remarks about the data""")
    users: Optional[List[Entity]] = Field(default_factory=list, description="""users of this data""")
    groups: Optional[List[Group]] = Field(default_factory=list, description="""groups accessing/using this data""")
    visualisations: Optional[List[Visualisation]] = Field(default_factory=list, description="""visualisations of the data""")
    data_extra: Optional[List[ExtraData]] = Field(default_factory=list, description="""extra data, like additional information about data or the evaluation ...""")
    resources_external: Optional[List[ExternalResource]] = Field(default_factory=list, description="""external resources, like literature, websites, manuals, ...""")
    tags: Optional[List[Tag]] = Field(default_factory=list, description="""tags""")
    
        

class Evaluation(ConfiguredBaseModel):
    """
    \" This class can be used to describe evaluation information.
    The name_full should only contain ASCII-alpha-numeric characters, no white-spaces, '-', '_' and '.' .
    For versioning semantic versioning (https://semver.org/lang/en/) shall be used.
     .. todo::
         - auto hashing
         - ensure that data and results cannot be modified ? (by hash checking)
         - method versioning
         - due to an unknown reason it is impossible to feedback on experiments (generates circular dependancy error).
           This should be fixed in a later version of the database
\"
    """
    evaluation_id: Optional[str] = Field(None, description="""Evaluation - primary key (UUID)""")
    namespace: Optional[Namespace] = Field(None, description="""namespace of evaluation""")
    name: Optional[str] = Field(None, description="""name of the evaluation""")
    name_full: Optional[str] = Field(None, description="""fully qualified name of the evaluation, including namespace and version, separated by a period. The name_full should only contain ASCII-alpha-numeric characters, no white-spaces, '-', '_' and '.' .""")
    version: Optional[str] = Field(None, description="""maj.min.patch version of this visualisation, e.g. 0.0.1""")
    UUID: str = Field(..., description="""evaluation UUID""")
    hash_sha256: Optional[str] = Field(None, description="""SHA256 hash of all hashes of eval methods and data""")
    parameters: Optional[str] = Field(None, description="""parameters used for evaluation, e.g. left and right limits, etc.""")
    eval_method_instance: Optional[MethodInstance] = Field(None, description="""evaluation method""")
    eval_procedure_instance: Optional[ProcedureInstance] = Field(None, description="""evaluation procedure""")
    iri: Optional[str] = Field(None, description="""International Resource Identifier - IRI: is used for semantic representation """)
    pid: Optional[str] = Field(None, description="""Persitent Identifier [PID/handle URI](https://www.handle.net/)""")
    doi: Optional[str] = Field(None, description="""Digital Object Identifier to the data""")
    caption: Optional[str] = Field(None, description="""can be used as table caption""")
    description: Optional[str] = Field(None, description="""description""")
    parent_evals: Optional[List[Evaluation]] = Field(default_factory=list, description="""to define a tree/network of evaluations and to go back in the evaluation process""")
    data_eval: Optional[List[Data]] = Field(default_factory=list, description="""all data that is used for this evaluation""")
    data_results: Optional[List[Data]] = Field(default_factory=list, description="""all data that is generated by this evaluation""")
    visualisations: Optional[List[Visualisation]] = Field(default_factory=list, description="""visualisations of this evaluated data""")
    resources_external: Optional[List[ExternalResource]] = Field(default_factory=list, description="""external resources, like literature, websites, manuals, ...""")
    tags: Optional[List[Tag]] = Field(default_factory=list, description="""tags, characterising the evaluation""")
    
        

class Container(ConfiguredBaseModel):
    
    extradatas: Optional[List[ExtraData]] = Field(default_factory=list)
    blockchainhashess: Optional[List[BlockchainHashes]] = Field(default_factory=list)
    visualisations: Optional[List[Visualisation]] = Field(default_factory=list)
    datas: Optional[List[Data]] = Field(default_factory=list)
    evaluations: Optional[List[Evaluation]] = Field(default_factory=list)
    
        


# Model rebuild
# see https://pydantic-docs.helpmanual.io/usage/models/#rebuilding-a-model
DataType.model_rebuild()
Tag.model_rebuild()
ExternalResource.model_rebuild()
Group.model_rebuild()
MediaType.model_rebuild()
Entity.model_rebuild()
ProcessInstance.model_rebuild()
ProcedureInstance.model_rebuild()
MethodInstance.model_rebuild()
Namespace.model_rebuild()
ExtraData.model_rebuild()
BlockchainHashes.model_rebuild()
Visualisation.model_rebuild()
Data.model_rebuild()
Evaluation.model_rebuild()
Container.model_rebuild()

