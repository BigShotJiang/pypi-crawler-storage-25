"""Piilot plugin ``compta_esms`` — verticale compta ESMS.

Entry point of the plugin. The ``Plugin`` class is referenced by
``[project.entry-points."piilot.plugins"]`` in ``pyproject.toml`` and
instantiated once at Piilot backend startup.

v0.1 — hello-world surface
--------------------------

* ``ctx.migrations`` — register the plugin's own SQL migrations.
* ``ctx.i18n`` — merge per-namespace locale catalogs.
* ``ctx.handlers`` — register the module handler.
* :mod:`piilot.sdk.http` — see ``routes.py`` (counter GET + greet POST).
* :mod:`piilot.sdk.modules` — see ``seeds.py`` (idempotent module upsert).

Future roadmap (see CHANGELOG):

* v0.2 — KB templates compta-ESMS (M22 plan comptable, dossier-ESMS, …)
* v0.3 — agent templates compta-ESMS
* v0.4 — agent tools compta-ESMS (``register_tool`` + ``bind_session``)
"""

from __future__ import annotations

from piilot.sdk import Plugin as _Plugin
from piilot.sdk import load_manifest

from .handlers import compta_esms_handler
from .routes import wire_routes
from .seeds import wire_seeds


class Plugin(_Plugin):
    """Plugin entry class — must subclass ``piilot.sdk.Plugin``."""

    manifest = load_manifest(__file__)

    def register(self, ctx) -> None:
        """Wire up everything this plugin provides.

        Called once at backend startup with a boot-time ``Context``
        (``ctx.company`` is None here; runtime contexts are built per
        request later on).
        """
        ctx.migrations.register_schema(
            "compta_esms",
            __file__,
            "migrations",
        )

        ctx.i18n.register_locales(
            "compta_esms",
            __file__,
            "locales",
        )

        ctx.handlers.register("compta_esms.hello", compta_esms_handler)

        wire_routes()
        wire_seeds()
