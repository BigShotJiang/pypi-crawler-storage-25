"""Module seed for the compta_esms plugin.

Demonstrates :func:`piilot.sdk.modules.register_module` — idempotent
upsert on ``modules.modules`` keyed on ``module_slug``. Re-installs
refresh the row's descriptive columns (name, icon, description, …)
while preserving the UUID so user grants / bookmarks stay stable.

Agent templates (``register_template``) and tools come in v0.3+ /
v0.4+. Stays out of v0.1 — KISS.
"""

from __future__ import annotations

from piilot.sdk.modules import register_module


def wire_seeds() -> None:
    """Register the plugin's module(s).

    Called from ``Plugin.register()``. Buffered by the SDK and upserted
    by the plugin loader after ``register()`` returns — safe to call on
    every boot.

    No ``config`` (JSONB) payload is passed: the module is resolved by
    slug on the frontend (``registerModuleView('compta_esms.hello',
    ...)``), which is enough for the ``ModuleViewShell``. AICockpit
    core PR #174 fixed the previous ``_upsert_module`` ``can't adapt
    type 'dict'`` error, so adding a ``config`` payload is now safe
    when v0.5+ surfaces actually need a routing hint.
    """
    register_module(
        {
            "slug": "compta_esms.hello",
            "module_name": "Compta ESMS — Hello",
            "description": (
                "Module hello-world du plugin compta-ESMS — counter de clics "
                "persistant en PG. Sera remplacé par les modules métier (M22, "
                "dossier ESMS, balance) dans les releases v0.5+."
            ),
            "icon": "hand",
            "category": "vertical",
            "status": "published",
        }
    )
