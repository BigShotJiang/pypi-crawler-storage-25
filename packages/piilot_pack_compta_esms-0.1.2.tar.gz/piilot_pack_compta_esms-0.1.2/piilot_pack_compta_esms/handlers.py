"""Module handlers for the ``compta_esms`` plugin.

Each handler is a callable ``(ctx, payload) -> dict`` dispatched by the
Piilot module runtime when a user triggers the module from the UI.
Handlers are registered in ``__init__.py::Plugin.register()``.
"""

from __future__ import annotations

from typing import Any


def compta_esms_handler(ctx: Any, payload: dict) -> dict:
    """Hello-world module handler — echoes a greeting.

    Will be replaced by real compta-ESMS workflow handlers in v0.5+
    (M22 import, balance reconciliation, etc.).
    """
    name = payload.get("name", "world")
    company_label = ctx.company.name if ctx.company else "<no company bound>"
    ctx.logger.info("compta_esms.hello invoked for %s", company_label)
    return {
        "status": "ok",
        "message": f"Hello {name} from compta_esms",
        "company": company_label,
    }
