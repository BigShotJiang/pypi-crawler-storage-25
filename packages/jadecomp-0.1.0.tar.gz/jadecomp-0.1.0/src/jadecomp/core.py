import os
import zipfile
import sys
from pathlib import Path
from tqdm import tqdm
from colorama import init
from .engine import NativeEngine

class Decompiler:
    def __init__(self):
        self.engine = NativeEngine()
        init()

    def _get_files(self, input_path):
        input_path = Path(input_path).resolve()
        if input_path.is_file():
            if input_path.suffix.lower() == ".jar":
                with zipfile.ZipFile(input_path, "r") as jar:
                    return [(input_path, f) for f in jar.namelist() if f.endswith(".class")]
            elif input_path.suffix.lower() == ".class":
                return [(input_path, None)]
        elif input_path.is_dir():
            files = []
            for root, _, filenames in os.walk(input_path):
                for f in filenames:
                    f_path = Path(root) / f
                    if f.endswith(".jar"):
                        with zipfile.ZipFile(f_path, "r") as jar:
                            files.extend([(f_path, jf) for jf in jar.namelist() if jf.endswith(".class")])
                    elif f.endswith(".class"):
                        files.append((f_path, None))
            return files
        return []

    def decompile(self, input_path, output_dir=None):
        input_path = Path(input_path).resolve()
        if not input_path.exists():
            raise FileNotFoundError(f"Input path not found: {input_path}")

        all_tasks = self._get_files(input_path)
        if not all_tasks:
            return True, "No Java files found to decompile."

        if not output_dir:
            output_dir = input_path.parent / f"{input_path.stem}_decompiled"
        output_dir = Path(output_dir).resolve()
        output_dir.mkdir(parents=True, exist_ok=True)

        pbar = tqdm(
            total=len(all_tasks),
            bar_format="{percentage:3.0f}% |{bar}|",
            ncols=80
        )
        sys.stdout.write("\n\033[F")

        for container, member in all_tasks:
            try:
                if member:
                    with zipfile.ZipFile(container, "r") as jar:
                        data = jar.read(member)
                    rel_path = member.replace(".class", ".java")
                    display_name = member.replace("/", ".").replace(".class", "")
                else:
                    with open(container, "rb") as f:
                        data = f.read()
                    rel_path = container.name.replace(".class", ".java")
                    display_name = container.stem

                # Update UI
                sys.stdout.write("\033[F\033[K")
                sys.stdout.write(f"{display_name}\n")
                sys.stdout.flush()

                # Decompile
                source = self.engine.decompile(data)
                
                # Save
                target_path = output_dir / rel_path
                target_path.parent.mkdir(parents=True, exist_ok=True)
                with open(target_path, "w", encoding="utf-8") as f:
                    f.write(source)

                pbar.update(1)
            except Exception as e:
                pbar.write(f"Error decompiling {member or container}: {e}")

        pbar.n = pbar.total
        pbar.refresh()
        pbar.close()
        return True, "Decompilation complete."
