import struct
import io

class ConstantPool:
    UTF8 = 1
    INTEGER = 3
    FLOAT = 4
    LONG = 5
    DOUBLE = 6
    CLASS = 7
    STRING = 8
    FIELDREF = 9
    METHODREF = 10
    INTERFACE_METHODREF = 11
    NAME_AND_TYPE = 12
    METHOD_HANDLE = 15
    METHOD_TYPE = 16
    DYNAMIC = 17
    INVOKE_DYNAMIC = 18
    MODULE = 19
    PACKAGE = 20

    def __init__(self, reader):
        self.count = reader.read_u2()
        self.entries = [None] * self.count
        i = 1
        while i < self.count:
            tag = reader.read_u1()
            if tag == self.UTF8:
                length = reader.read_u2()
                self.entries[i] = (tag, reader.read_bytes(length).decode('utf-8', errors='replace'))
            elif tag in (self.INTEGER, self.FLOAT, self.FIELDREF, self.METHODREF, self.INTERFACE_METHODREF, self.NAME_AND_TYPE, self.DYNAMIC, self.INVOKE_DYNAMIC):
                self.entries[i] = (tag, reader.read_u4())
            elif tag in (self.LONG, self.DOUBLE):
                self.entries[i] = (tag, reader.read_u8())
                i += 1
            elif tag in (self.CLASS, self.STRING, self.METHOD_TYPE, self.MODULE, self.PACKAGE):
                self.entries[i] = (tag, reader.read_u2())
            elif tag == self.METHOD_HANDLE:
                self.entries[i] = (tag, reader.read_u1(), reader.read_u2())
            i += 1

    def get(self, index):
        if 0 < index < self.count:
            return self.entries[index]
        return None

    def get_utf8(self, index):
        entry = self.get(index)
        if entry and entry[0] == self.UTF8: return entry[1]
        return ""

    def get_class_name(self, index):
        entry = self.get(index)
        if entry and entry[0] == self.CLASS: return self.get_utf8(entry[1])
        return ""

    def resolve(self, index):
        entry = self.get(index)
        if not entry: return f"#{index}"
        tag = entry[0]
        if tag == self.UTF8: return entry[1]
        if tag == self.CLASS: return self.get_class_name(index).replace("/", ".")
        if tag == self.STRING: return f"\"{self.get_utf8(entry[1])}\""
        if tag in (self.FIELDREF, self.METHODREF, self.INTERFACE_METHODREF):
            nt_idx = self.get(entry[1])[1] if self.get(entry[1])[0] == self.CLASS else 0
            name_and_type = self.get(entry[1]) # Simplified for brevity
            return f"Ref#{index}"
        return f"CP#{index}"

class NativeEngine:
    OPCODES = {
        0x00: "nop", 0x01: "aconst_null", 0x12: "ldc", 0x19: "aload", 0x2a: "aload_0",
        0x2b: "aload_1", 0x2c: "aload_2", 0x2d: "aload_3", 0xb1: "return", 0xb2: "getstatic",
        0xb4: "getfield", 0xb5: "putfield", 0xb6: "invokevirtual", 0xb7: "invokespecial",
        0xb8: "invokestatic", 0xbb: "new", 0xbf: "athrow"
    }

    def decompile(self, data):
        stream = io.BytesIO(data)
        def read_u1(): return struct.unpack('>B', stream.read(1))[0]
        def read_u2(): return struct.unpack('>H', stream.read(2))[0]
        def read_u4(): return struct.unpack('>I', stream.read(4))[0]

        if read_u4() != 0xCAFEBABE: return "Error: Invalid class."
        read_u4() # minor/major
        cp = ConstantPool(type('Reader', (), {'read_u1': read_u1, 'read_u2': read_u2, 'read_u4': read_u4, 'read_u8': lambda: struct.unpack('>Q', stream.read(8))[0], 'read_bytes': lambda n: stream.read(n)}))
        
        access_flags = read_u2()
        this_class = cp.get_class_name(read_u2())
        super_class = cp.get_class_name(read_u2())
        
        for _ in range(read_u2()): read_u2() # interfaces
        
        output = []
        pkg = ".".join(this_class.split("/")[:-1])
        if pkg: output.extend([f"package {pkg};", ""])
        
        output.append(f"public class {this_class.split('/')[-1]} {{")
        
        for _ in range(read_u2()): # fields
            f_acc, f_name, f_desc = read_u2(), cp.get_utf8(read_u2()), cp.get_utf8(read_u2())
            for _ in range(read_u2()): read_bytes_attr = stream.read(read_u4()) # skip attributes
            output.append(f"    {f_name};")

        for _ in range(read_u2()): # methods
            m_acc, m_name, m_desc = read_u2(), cp.get_utf8(read_u2()), cp.get_utf8(read_u2())
            output.append(f"\n    {m_name}{m_desc} {{")
            for _ in range(read_u2()):
                attr_name = cp.get_utf8(read_u2())
                attr_len = read_u4()
                if attr_name == "Code":
                    stream.read(4) # max stack/locals
                    code_len = read_u4()
                    code = stream.read(code_len)
                    # Simple disassembly
                    pc = 0
                    while pc < code_len:
                        op = code[pc]
                        name = self.OPCODES.get(op, f"0x{op:02x}")
                        output.append(f"        /* {pc:3} */ {name}")
                        pc += 1 # Very basic step
                    stream.read(read_u2() * 8) # exceptions
                    for _ in range(read_u2()): stream.read(6 + read_u4()) # code attributes
                else:
                    stream.read(attr_len)
            output.append("    }")
        
        output.append("}")
        return "\n".join(output)
