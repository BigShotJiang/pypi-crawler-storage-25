from .core import Decompiler

__version__ = "0.1.0"
__all__ = ["Decompiler"]
