import argparse
import sys
from .core import Decompiler

def main():
    parser = argparse.ArgumentParser(
        prog="jad",
        description="Java Archive Decompiler (JADecomp)"
    )
    parser.add_argument(
        "input",
        help="Path to a .jar file, .class file, or a directory containing them"
    )
    parser.add_argument(
        "-o", "--output",
        help="Directory where decompiled source should be saved"
    )

    args = parser.parse_args()

    try:
        decompiler = Decompiler()
        print(f"Analyzing {args.input}...")
        success, message = decompiler.decompile(args.input, args.output)
        if success:
            print(f"\n{message}")
        else:
            print(f"\nError: {message}", file=sys.stderr)
            sys.exit(1)
    except Exception as e:
        print(f"\nFatal error: {e}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()
