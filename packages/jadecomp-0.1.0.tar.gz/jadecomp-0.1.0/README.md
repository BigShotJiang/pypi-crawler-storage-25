# JADecomp

JADecomp (Java Archive Decompiler) is a zero dependency Python tool for stripping apart .jar and .class files. It's built for speed and works entirely without a Java Runtime (JRE). If you need to peek inside a JAR without setting up a full Java environment, this is for you.

## Why use this?

Most Java decompilers are written in Java, which means you need a JRE just to run the tool. JADecomp is pure Python. It parses the JVM binary format directly and reconstructs the class structure and method bytecode.

## Installation

You can install JADecomp directly from PyPI:

```bash
pip install JADecomp
```

## How to use it

The main command is `jad`. It handles single files or entire directories.

### Decompile a single JAR
```bash
jad appserve.jar
```
This creates an `appserve_decompiled` folder with the source.

### Bulk decompile a directory
If you have a folder full of Java libraries or legacy archives:
```bash
jad "C:\path\to\java\libs"
```
It will recursively find every .jar and .class file and decompile them into one output tree.

### Custom output folder
```bash
jad appserve.jar -o ./out
```

## How it works (The Tech)

JADecomp uses a custom native engine (`engine.py`) to map out the constant pool, fields, and methods of a class file. 

Instead of just giving you empty method bodies, it disassembles the JVM bytecode into human readable opcodes (like `invokevirtual`, `getstatic`, `ldc`). This gives you a low level view of what the code is doing without needing the original source.

## License
MIT
