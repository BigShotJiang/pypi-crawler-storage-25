var dt = Object.defineProperty;
var ht = (e, t, n) => t in e ? dt(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n;
var b = (e, t, n) => ht(e, typeof t != "symbol" ? t + "" : t, n);
import * as pt from "vue";
import { unref as G, toRef as F, readonly as pe, customRef as X, ref as E, onBeforeUnmount as De, onMounted as me, nextTick as Be, getCurrentScope as mt, onScopeDispose as yt, getCurrentInstance as Ie, watch as O, isRef as P, shallowRef as re, watchEffect as Le, computed as k, onErrorCaptured as gt, toValue as m, h as C, defineComponent as $, openBlock as D, createElementBlock as j, createElementVNode as Me, renderSlot as Z, toDisplayString as Ve, createCommentVNode as ce, createBlock as We, Teleport as vt, useAttrs as ye, Fragment as L, mergeProps as Ue, useSlots as ge, useTemplateRef as wt, normalizeStyle as ue, cloneVNode as ee, vModelDynamic as bt, vShow as St, withDirectives as ze, toRaw as He, normalizeClass as _e, withKeys as Et, withModifiers as kt, resolveDynamicComponent as _t, provide as Je, inject as Ke, isVNode as Ct, TransitionGroup as Ot, createTextVNode as Tt, createApp as At } from "vue";
function T(e, t) {
  t = t || {};
  const n = [...Object.keys(t), "__Vue"], o = [...Object.values(t), pt];
  try {
    return new Function(...n, `return (${e})`)(...o);
  } catch (r) {
    throw new Error(r + " in function code: " + e);
  }
}
function te(e, t = !0) {
  if (!(typeof e != "object" || e === null)) {
    if (Array.isArray(e)) {
      t && e.forEach((n) => te(n, !0));
      return;
    }
    for (const [n, o] of Object.entries(e))
      if (n.startsWith(":"))
        try {
          e[n.slice(1)] = new Function(`return (${o})`)(), delete e[n];
        } catch (r) {
          console.error(
            `Error while converting ${n} attribute to function:`,
            r
          );
        }
      else
        t && te(o, !0);
  }
}
function $t(e, t) {
  const n = e.startsWith(":");
  return n && (e = e.slice(1), t = T(t)), { name: e, value: t, isFunc: n };
}
let Ge;
function Pt(e) {
  let t = e.serverInfo;
  t && (t = {
    ...t,
    asset_icons_url: `${t.assets_url}/${t.assets_icons_name}`
  }), Ge = {
    ...e,
    serverInfo: t
  };
}
function M() {
  return Ge;
}
function ve(e) {
  return mt() ? (yt(e), !0) : !1;
}
function z(e) {
  return typeof e == "function" ? e() : G(e);
}
const qe = typeof window < "u" && typeof document < "u";
typeof WorkerGlobalScope < "u" && globalThis instanceof WorkerGlobalScope;
const jt = (e) => e != null, xt = Object.prototype.toString, Nt = (e) => xt.call(e) === "[object Object]", we = () => {
};
function Rt(e, t) {
  function n(...o) {
    return new Promise((r, s) => {
      Promise.resolve(e(() => t.apply(this, o), { fn: t, thisArg: this, args: o })).then(r).catch(s);
    });
  }
  return n;
}
const Qe = (e) => e();
function Ft(e = Qe) {
  const t = E(!0);
  function n() {
    t.value = !1;
  }
  function o() {
    t.value = !0;
  }
  const r = (...s) => {
    t.value && e(...s);
  };
  return { isActive: pe(t), pause: n, resume: o, eventFilter: r };
}
function Ye(e) {
  return Ie();
}
function Xe(...e) {
  if (e.length !== 1)
    return F(...e);
  const t = e[0];
  return typeof t == "function" ? pe(X(() => ({ get: t, set: we }))) : E(t);
}
function Dt(e, t, n = {}) {
  const {
    eventFilter: o = Qe,
    ...r
  } = n;
  return O(
    e,
    Rt(
      o,
      t
    ),
    r
  );
}
function Bt(e, t, n = {}) {
  const {
    eventFilter: o,
    ...r
  } = n, { eventFilter: s, pause: i, resume: a, isActive: u } = Ft(o);
  return { stop: Dt(
    e,
    t,
    {
      ...r,
      eventFilter: s
    }
  ), pause: i, resume: a, isActive: u };
}
function It(e, t) {
  Ye() && De(e, t);
}
function Ze(e, t = !0, n) {
  Ye() ? me(e, n) : t ? e() : Be(e);
}
function Lt(e, t, n) {
  let o;
  P(n) ? o = {
    evaluating: n
  } : o = n || {};
  const {
    lazy: r = !1,
    evaluating: s = void 0,
    shallow: i = !0,
    onError: a = we
  } = o, u = E(!r), c = i ? re(t) : E(t);
  let l = 0;
  return Le(async (f) => {
    if (!u.value)
      return;
    l++;
    const d = l;
    let h = !1;
    s && Promise.resolve().then(() => {
      s.value = !0;
    });
    try {
      const p = await e((g) => {
        f(() => {
          s && (s.value = !1), h || g();
        });
      });
      d === l && (c.value = p);
    } catch (p) {
      a(p);
    } finally {
      s && d === l && (s.value = !1), h = !0;
    }
  }), r ? k(() => (u.value = !0, c.value)) : c;
}
const V = qe ? window : void 0, Mt = qe ? window.document : void 0;
function be(e) {
  var t;
  const n = z(e);
  return (t = n == null ? void 0 : n.$el) != null ? t : n;
}
function Ce(...e) {
  let t, n, o, r;
  if (typeof e[0] == "string" || Array.isArray(e[0]) ? ([n, o, r] = e, t = V) : [t, n, o, r] = e, !t)
    return we;
  Array.isArray(n) || (n = [n]), Array.isArray(o) || (o = [o]);
  const s = [], i = () => {
    s.forEach((l) => l()), s.length = 0;
  }, a = (l, f, d, h) => (l.addEventListener(f, d, h), () => l.removeEventListener(f, d, h)), u = O(
    () => [be(t), z(r)],
    ([l, f]) => {
      if (i(), !l)
        return;
      const d = Nt(f) ? { ...f } : f;
      s.push(
        ...n.flatMap((h) => o.map((p) => a(l, h, p, d)))
      );
    },
    { immediate: !0, flush: "post" }
  ), c = () => {
    u(), i();
  };
  return ve(c), c;
}
function Vt() {
  const e = E(!1), t = Ie();
  return t && me(() => {
    e.value = !0;
  }, t), e;
}
function et(e) {
  const t = Vt();
  return k(() => (t.value, !!e()));
}
function Wt(e, t, n = {}) {
  const { window: o = V, ...r } = n;
  let s;
  const i = et(() => o && "MutationObserver" in o), a = () => {
    s && (s.disconnect(), s = void 0);
  }, u = k(() => {
    const d = z(e), h = (Array.isArray(d) ? d : [d]).map(be).filter(jt);
    return new Set(h);
  }), c = O(
    () => u.value,
    (d) => {
      a(), i.value && d.size && (s = new MutationObserver(t), d.forEach((h) => s.observe(h, r)));
    },
    { immediate: !0, flush: "post" }
  ), l = () => s == null ? void 0 : s.takeRecords(), f = () => {
    c(), a();
  };
  return ve(f), {
    isSupported: i,
    stop: f,
    takeRecords: l
  };
}
function Ut(e, t = {}) {
  const { window: n = V } = t, o = et(() => n && "matchMedia" in n && typeof n.matchMedia == "function");
  let r;
  const s = E(!1), i = (c) => {
    s.value = c.matches;
  }, a = () => {
    r && ("removeEventListener" in r ? r.removeEventListener("change", i) : r.removeListener(i));
  }, u = Le(() => {
    o.value && (a(), r = n.matchMedia(z(e)), "addEventListener" in r ? r.addEventListener("change", i) : r.addListener(i), s.value = r.matches);
  });
  return ve(() => {
    u(), a(), r = void 0;
  }), s;
}
const Q = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {}, Y = "__vueuse_ssr_handlers__", zt = /* @__PURE__ */ Ht();
function Ht() {
  return Y in Q || (Q[Y] = Q[Y] || {}), Q[Y];
}
function tt(e, t) {
  return zt[e] || t;
}
function Jt(e) {
  return Ut("(prefers-color-scheme: dark)", e);
}
function Kt(e) {
  return e == null ? "any" : e instanceof Set ? "set" : e instanceof Map ? "map" : e instanceof Date ? "date" : typeof e == "boolean" ? "boolean" : typeof e == "string" ? "string" : typeof e == "object" ? "object" : Number.isNaN(e) ? "any" : "number";
}
const Gt = {
  boolean: {
    read: (e) => e === "true",
    write: (e) => String(e)
  },
  object: {
    read: (e) => JSON.parse(e),
    write: (e) => JSON.stringify(e)
  },
  number: {
    read: (e) => Number.parseFloat(e),
    write: (e) => String(e)
  },
  any: {
    read: (e) => e,
    write: (e) => String(e)
  },
  string: {
    read: (e) => e,
    write: (e) => String(e)
  },
  map: {
    read: (e) => new Map(JSON.parse(e)),
    write: (e) => JSON.stringify(Array.from(e.entries()))
  },
  set: {
    read: (e) => new Set(JSON.parse(e)),
    write: (e) => JSON.stringify(Array.from(e))
  },
  date: {
    read: (e) => new Date(e),
    write: (e) => e.toISOString()
  }
}, Oe = "vueuse-storage";
function le(e, t, n, o = {}) {
  var r;
  const {
    flush: s = "pre",
    deep: i = !0,
    listenToStorageChanges: a = !0,
    writeDefaults: u = !0,
    mergeDefaults: c = !1,
    shallow: l,
    window: f = V,
    eventFilter: d,
    onError: h = (y) => {
      console.error(y);
    },
    initOnMounted: p
  } = o, g = (l ? re : E)(typeof t == "function" ? t() : t);
  if (!n)
    try {
      n = tt("getDefaultStorage", () => {
        var y;
        return (y = V) == null ? void 0 : y.localStorage;
      })();
    } catch (y) {
      h(y);
    }
  if (!n)
    return g;
  const v = z(t), R = Kt(v), A = (r = o.serializer) != null ? r : Gt[R], { pause: se, resume: _ } = Bt(
    g,
    () => q(g.value),
    { flush: s, deep: i, eventFilter: d }
  );
  f && a && Ze(() => {
    n instanceof Storage ? Ce(f, "storage", N) : Ce(f, Oe, H), p && N();
  }), p || N();
  function x(y, w) {
    if (f) {
      const S = {
        key: e,
        oldValue: y,
        newValue: w,
        storageArea: n
      };
      f.dispatchEvent(n instanceof Storage ? new StorageEvent("storage", S) : new CustomEvent(Oe, {
        detail: S
      }));
    }
  }
  function q(y) {
    try {
      const w = n.getItem(e);
      if (y == null)
        x(w, null), n.removeItem(e);
      else {
        const S = A.write(y);
        w !== S && (n.setItem(e, S), x(w, S));
      }
    } catch (w) {
      h(w);
    }
  }
  function B(y) {
    const w = y ? y.newValue : n.getItem(e);
    if (w == null)
      return u && v != null && n.setItem(e, A.write(v)), v;
    if (!y && c) {
      const S = A.read(w);
      return typeof c == "function" ? c(S, v) : R === "object" && !Array.isArray(S) ? { ...v, ...S } : S;
    } else return typeof w != "string" ? w : A.read(w);
  }
  function N(y) {
    if (!(y && y.storageArea !== n)) {
      if (y && y.key == null) {
        g.value = v;
        return;
      }
      if (!(y && y.key !== e)) {
        se();
        try {
          (y == null ? void 0 : y.newValue) !== A.write(g.value) && (g.value = B(y));
        } catch (w) {
          h(w);
        } finally {
          y ? Be(_) : _();
        }
      }
    }
  }
  function H(y) {
    N(y.detail);
  }
  return g;
}
const qt = "*,*::before,*::after{-webkit-transition:none!important;-moz-transition:none!important;-o-transition:none!important;-ms-transition:none!important;transition:none!important}";
function Qt(e = {}) {
  const {
    selector: t = "html",
    attribute: n = "class",
    initialValue: o = "auto",
    window: r = V,
    storage: s,
    storageKey: i = "vueuse-color-scheme",
    listenToStorageChanges: a = !0,
    storageRef: u,
    emitAuto: c,
    disableTransition: l = !0
  } = e, f = {
    auto: "",
    light: "light",
    dark: "dark",
    ...e.modes || {}
  }, d = Jt({ window: r }), h = k(() => d.value ? "dark" : "light"), p = u || (i == null ? Xe(o) : le(i, o, s, { window: r, listenToStorageChanges: a })), g = k(() => p.value === "auto" ? h.value : p.value), v = tt(
    "updateHTMLAttrs",
    (_, x, q) => {
      const B = typeof _ == "string" ? r == null ? void 0 : r.document.querySelector(_) : be(_);
      if (!B)
        return;
      const N = /* @__PURE__ */ new Set(), H = /* @__PURE__ */ new Set();
      let y = null;
      if (x === "class") {
        const S = q.split(/\s/g);
        Object.values(f).flatMap((J) => (J || "").split(/\s/g)).filter(Boolean).forEach((J) => {
          S.includes(J) ? N.add(J) : H.add(J);
        });
      } else
        y = { key: x, value: q };
      if (N.size === 0 && H.size === 0 && y === null)
        return;
      let w;
      l && (w = r.document.createElement("style"), w.appendChild(document.createTextNode(qt)), r.document.head.appendChild(w));
      for (const S of N)
        B.classList.add(S);
      for (const S of H)
        B.classList.remove(S);
      y && B.setAttribute(y.key, y.value), l && (r.getComputedStyle(w).opacity, document.head.removeChild(w));
    }
  );
  function R(_) {
    var x;
    v(t, n, (x = f[_]) != null ? x : _);
  }
  function A(_) {
    e.onChanged ? e.onChanged(_, R) : R(_);
  }
  O(g, A, { flush: "post", immediate: !0 }), Ze(() => A(g.value));
  const se = k({
    get() {
      return c ? p.value : g.value;
    },
    set(_) {
      p.value = _;
    }
  });
  return Object.assign(se, { store: p, system: h, state: g });
}
function Yt(e = {}) {
  const {
    valueDark: t = "dark",
    valueLight: n = ""
  } = e, o = Qt({
    ...e,
    onChanged: (i, a) => {
      var u;
      e.onChanged ? (u = e.onChanged) == null || u.call(e, i === "dark", a, i) : a(i);
    },
    modes: {
      dark: t,
      light: n
    }
  }), r = k(() => o.system.value);
  return k({
    get() {
      return o.value === "dark";
    },
    set(i) {
      const a = i ? "dark" : "light";
      r.value === a ? o.value = "auto" : o.value = a;
    }
  });
}
function Xt(e = null, t = {}) {
  var n, o, r;
  const {
    document: s = Mt,
    restoreOnUnmount: i = (f) => f
  } = t, a = (n = s == null ? void 0 : s.title) != null ? n : "", u = Xe((o = e ?? (s == null ? void 0 : s.title)) != null ? o : null), c = e && typeof e == "function";
  function l(f) {
    if (!("titleTemplate" in t))
      return f;
    const d = t.titleTemplate || "%s";
    return typeof d == "function" ? d(f) : z(d).replace(/%s/g, f);
  }
  return O(
    u,
    (f, d) => {
      f !== d && s && (s.title = l(typeof f == "string" ? f : ""));
    },
    { immediate: !0 }
  ), t.observe && !t.titleTemplate && s && !c && Wt(
    (r = s.head) == null ? void 0 : r.querySelector("title"),
    () => {
      s && s.title !== u.value && (u.value = l(s.title));
    },
    { childList: !0 }
  ), It(() => {
    if (i) {
      const f = i(a, u.value || "");
      f != null && s && (s.title = f);
    }
  }), u;
}
function Zt(e) {
  const t = E(!1), n = E("");
  function o(r, s) {
    let i;
    return s.component ? i = `Error captured from component:tag: ${s.component.tag} ; id: ${s.component.id} ` : i = "Error captured from app init", console.group(i), console.error("Component:", s.component), console.error("Error:", r), console.groupEnd(), e && (t.value = !0, n.value = `${i} ${r.message}`), !1;
  }
  return gt(o), { hasError: t, errorMessage: n };
}
class en {
  async eventSend(t, n) {
    const { fType: o = "sync", hKey: r } = t, s = M().serverInfo, i = o === "sync" ? s.event_url : s.event_async_url, u = await fetch(i, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        bind: n,
        hKey: r,
        ...{}
      })
    });
    if (!u.ok)
      throw new Error(`HTTP error! status: ${u.status}`);
    return await u.json();
  }
  async watchSend(t) {
    const { fType: n, hKey: o, inputs: r } = t.config, s = M().serverInfo, i = n === "sync" ? s.watch_url : s.watch_async_url, a = r ? r.map(m) : [];
    return await (await fetch(i, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        hKey: o,
        input: a
      })
    })).json();
  }
}
class tn {
  async eventSend(t, n) {
    const { fType: o, hKey: r, hKey: s } = t, u = {
      bind: n,
      fType: o,
      hKey: r,
      ...s !== void 0 ? { key: s } : {},
      ...{}
    };
    return await window.pywebview.api.event_call(u);
  }
  async watchSend(t) {
    const { fType: n, hKey: o, inputs: r } = t.config, s = r ? r.map(m) : [], i = {
      hKey: o,
      input: s,
      fType: n
    };
    return await window.pywebview.api.watch_call(i);
  }
}
let fe;
function nn(e) {
  switch (e) {
    case "web":
      fe = new en();
      break;
    case "webview":
      fe = new tn();
      break;
  }
}
function nt() {
  return fe;
}
function rn(e) {
  if (!(e === "web" || e === "webview") && e !== "zero")
    throw new Error(`Unsupported mode: ${e}`);
}
function on(e, t) {
  const n = k(() => {
    const o = e.value;
    if (!o)
      return null;
    const i = new DOMParser().parseFromString(o, "image/svg+xml").querySelector("svg");
    if (!i)
      throw new Error("Invalid svg string");
    const a = {};
    for (const d of i.attributes)
      a[d.name] = d.value;
    const { size: u, color: c, attrs: l } = t;
    c.value !== null && c.value !== void 0 && (i.removeAttribute("fill"), i.querySelectorAll("*").forEach((h) => {
      h.hasAttribute("fill") && h.setAttribute("fill", "currentColor");
    }), a.color = c.value), u.value !== null && u.value !== void 0 && (a.width = u.value.toString(), a.height = u.value.toString());
    const f = i.innerHTML;
    return {
      ...a,
      ...l,
      innerHTML: f
    };
  });
  return () => {
    if (!n.value)
      return null;
    const o = n.value;
    return C("svg", o);
  };
}
async function sn(e) {
  var i;
  if (!e) return;
  const t = (i = M().serverInfo) == null ? void 0 : i.asset_icons_url;
  if (!t)
    throw new Error("Asset path is not set");
  const { names: n, sets: o } = e, r = [];
  if (n) {
    const a = {}, u = [];
    for (const c of n) {
      if (!c.includes(":")) {
        u.push(c);
        continue;
      }
      const [l, f] = c.split(":");
      a[l] || (a[l] = []), a[l].push(f);
    }
    u.length > 0 && console.warn(
      `Invalid icon names (missing file prefix): ${u.join(", ")}`
    );
    for (const c of Object.keys(a)) {
      const l = `${t}/${c}.svg`, f = await fetch(l);
      if (!f.ok) throw new Error(`Failed to load ${l}`);
      const d = await f.text(), p = new DOMParser().parseFromString(d, "image/svg+xml");
      for (const g of a[c]) {
        const v = p.getElementById(g);
        if (!v) {
          console.warn(`Failed to find icon ${g} in ${l}`);
          continue;
        }
        v.setAttribute("id", `${c}:${g}`), r.push(v.outerHTML);
      }
    }
  }
  if (o)
    for (const a of o) {
      const u = `/${t}/${a}.svg`, c = await fetch(u);
      if (!c.ok) throw new Error(`Failed to load ${u}`);
      const l = await c.text(), d = new DOMParser().parseFromString(l, "image/svg+xml"), h = Array.from(d.querySelectorAll("symbol"));
      if (h.length === 0) {
        console.warn(`No <symbol> found in ${u}`);
        continue;
      }
      for (const p of h) {
        const g = p.getAttribute("id");
        g && (p.setAttribute("id", `${a}:${g}`), r.push(p.outerHTML));
      }
    }
  const s = `<svg xmlns="http://www.w3.org/2000/svg" style="display:none">
${r.join(
    `
`
  )}
</svg>`;
  document.body.insertAdjacentHTML("afterbegin", s);
}
const an = {
  class: "app-box insta-theme",
  "data-scaling": "100%"
}, cn = { class: "insta-main" }, un = {
  key: 0,
  style: { color: "red", "font-size": "1.2em", margin: "1rem", border: "1px dashed red", padding: "1rem" }
}, Te = /* @__PURE__ */ $({
  __name: "App",
  props: {
    meta: {}
  },
  setup(e) {
    const t = e, { meta: n } = t, { debug: o = !1 } = n;
    Pt(n), (n.mode === "web" || n.mode === "webview") && (nn(n.mode), sn(n.appIcons)), rn(n.mode);
    const { hasError: r, errorMessage: s } = Zt(o);
    return (i, a) => (D(), j("div", an, [
      Me("div", cn, [
        Z(i.$slots, "default"),
        G(r) ? (D(), j("div", un, Ve(G(s)), 1)) : ce("", !0)
      ])
    ]));
  }
}), ln = /* @__PURE__ */ $({
  __name: "_Teleport",
  props: {
    to: {},
    defer: { type: Boolean, default: !0 },
    disabled: { type: Boolean, default: !1 }
  },
  setup(e) {
    return (t, n) => (D(), We(vt, {
      to: t.to,
      defer: t.defer,
      disabled: t.disabled
    }, [
      Z(t.$slots, "default")
    ], 8, ["to", "defer", "disabled"]));
  }
}), fn = ["width", "height", "color"], dn = ["xlink:href"], hn = /* @__PURE__ */ $({
  __name: "Icon",
  props: {
    size: {},
    icon: {},
    color: {},
    assetPath: {},
    svgName: {},
    rawSvg: {}
  },
  setup(e) {
    const t = e, n = F(() => t.icon ? t.icon.split(":")[1] : ""), o = F(() => t.size || "1em"), r = F(() => t.color || "currentColor"), s = F(() => t.rawSvg || null), i = k(() => `#${t.icon}`), a = ye(), u = on(s, {
      size: F(() => t.size),
      color: F(() => t.color),
      attrs: a
    });
    return (c, l) => (D(), j(L, null, [
      n.value ? (D(), j("svg", Ue({
        key: 0,
        width: o.value,
        height: o.value,
        color: r.value
      }, G(a)), [
        Me("use", { "xlink:href": i.value }, null, 8, dn)
      ], 16, fn)) : ce("", !0),
      s.value ? (D(), We(G(u), { key: 1 })) : ce("", !0)
    ], 64));
  }
});
function pn(e) {
  return Object.fromEntries(Object.entries(e).filter(([t, n]) => n !== void 0));
}
const mn = "insta-Grid", yn = $(bn, {
  props: [
    "as_",
    "display",
    "areas",
    "columns",
    "rows",
    "flow",
    "align",
    "justify",
    "gap",
    "gap_x",
    "gap_y"
  ]
});
function Ae(e) {
  if (e == null) return;
  if (typeof e == "number")
    return `repeat(${e}, 1fr)`;
  const t = Number(e);
  return !isNaN(t) && String(t) === e.trim() ? `repeat(${t}, 1fr)` : e;
}
function gn(e) {
  if (!e || typeof e != "string") return;
  const t = [], n = /(["'])([^"']*?)\1/g;
  let o;
  for (; (o = n.exec(e)) !== null; )
    t.push(o[2]);
  if (t.length !== 0)
    return t.map((r) => `"${r}"`).join(" ");
}
function vn(e) {
  if (!e || typeof e != "string") return;
  const t = /(["'])([^"']*?)\1/g, n = [];
  let o;
  for (; (o = t.exec(e)) !== null; )
    n.push(o[2].trim());
  if (n.length === 0) return;
  const s = n[0].split(/\s+/).length;
  if (n.every((a) => a.split(/\s+/).length === s))
    return `repeat(${s}, 1fr)`;
}
function wn(e) {
  const t = {};
  e.display && (t.display = e.display);
  const n = gn(e.areas);
  n && (t.gridTemplateAreas = n);
  let o = Ae(e.columns);
  !o && e.areas && (o = vn(e.areas)), o && (t.gridTemplateColumns = o);
  const r = Ae(e.rows);
  return r && (t.gridTemplateRows = r), e.flow && (t.gridAutoFlow = e.flow), e.align && (t.alignItems = e.align), e.justify && (t.justifyItems = e.justify), e.gap && (t.gap = e.gap), e.gap_x && (t.columnGap = e.gap_x), e.gap_y && (t.rowGap = e.gap_y), t;
}
function bn(e) {
  const t = ge(), n = k(() => ({
    ...pn(e)
  })), o = k(() => wn(n.value));
  return () => {
    var i;
    const { as_: r } = n.value;
    return C(
      r || "div",
      {
        class: mn,
        style: o.value
      },
      (i = t.default) == null ? void 0 : i.call(t)
    );
  };
}
const Sn = "insta-Text";
function En(e, t) {
  if (!t || t === "normal") return e;
  switch (t) {
    case "start":
      return e.replace(/^\s+/, "");
    case "end":
      return e.replace(/\s+$/, "");
    case "both":
      return e.trim();
    default:
      return e;
  }
}
function kn(e) {
  return e ? {
    light: "300",
    regular: "400",
    medium: "500",
    bold: "700"
  }[e] || e : void 0;
}
const _n = $({
  name: "Text",
  props: {
    /** HTML element to render as */
    as_: {
      type: String,
      default: "span"
    },
    /** Font weight of the text */
    weight: {
      type: String,
      default: void 0
    },
    /** Text alignment */
    align: {
      type: String,
      default: void 0
    },
    /** Whitespace trimming behavior */
    trim: {
      type: String,
      default: void 0
    },
    /** Whether to truncate text with ellipsis */
    truncate: {
      type: Boolean,
      default: !1
    },
    /** Text wrapping behavior */
    text_wrap: {
      type: String,
      default: void 0
    },
    /** Text content as prop (alternative to slot) */
    innerText: {
      type: [String, Number],
      default: void 0
    }
  },
  setup(e, { slots: t }) {
    return () => {
      const n = {}, o = kn(e.weight);
      o && (n.fontWeight = o), e.align && (n.textAlign = e.align), e.text_wrap && (n.textWrap = e.text_wrap), e.truncate && (n.overflow = "hidden", n.textOverflow = "ellipsis", n.whiteSpace = "nowrap");
      let r = e.innerText;
      if (r === void 0 && t.default) {
        const s = t.default();
        s.length === 1 && typeof s[0] == "string" && (r = s[0]);
      }
      return r !== void 0 && typeof r == "string" && (r = En(r, e.trim)), C(
        e.as_,
        Ue({ class: Sn, style: n }, { innerHTML: r }),
        r === void 0 && t.default ? t.default() : void 0
      );
    };
  }
}), $e = "insta-Link", Cn = $(On, {
  props: ["href", "text", "target", "type"]
});
function On(e) {
  const t = ge().default;
  return () => {
    const n = t ? [$e, "has-child"] : [$e], o = {
      href: e.href,
      target: e.target,
      type: e.type,
      class: n
    };
    return C("a", o, t ? t() : e.text);
  };
}
const ie = /* @__PURE__ */ new Map();
function Tn(e, t, n, o) {
  const r = `${e}|${n ?? ""}`;
  if (ie.has(r))
    return ie.get(r);
  const s = /* @__PURE__ */ new WeakMap(), a = { observer: new IntersectionObserver(
    (u) => {
      for (const c of u) {
        const l = s.get(c.target);
        l && l(c.isIntersecting);
      }
    },
    {
      root: o,
      rootMargin: e,
      threshold: t
    }
  ), callbacks: s };
  return ie.set(r, a), a;
}
function An(e, t, n) {
  const o = n.margin ?? "0px", r = n.threshold ?? 0;
  let s = null;
  const i = () => {
    if (!e.value || n.enabled.value === !1) return;
    let c = null;
    n.rootSelector && (c = document.querySelector(n.rootSelector)), s = Tn(
      o,
      r,
      n.rootSelector,
      c
    ), s.callbacks.set(e.value, t), s.observer.observe(e.value);
  }, a = () => {
    s && e.value && (s.observer.unobserve(e.value), s.callbacks.delete(e.value));
  }, u = () => {
    if (e.value) {
      if (!s) {
        i();
        return;
      }
      s.callbacks.set(e.value, t), s.observer.observe(e.value);
    }
  };
  me(() => {
    i();
  }), De(() => {
    s && e.value && (s.observer.unobserve(e.value), s.callbacks.delete(e.value));
  }), O(
    () => n.enabled.value,
    (c, l) => {
      c !== l && (c ? u() : a());
    },
    { immediate: !1 }
  );
}
const $n = /* @__PURE__ */ $({
  __name: "Lazy-Render",
  props: {
    height: {
      type: String,
      default: "200px"
    },
    destroyOnLeave: {
      type: Boolean,
      default: !0
    },
    margin: {
      type: String,
      default: "0px"
    },
    root: {
      type: String,
      default: void 0
    },
    disable: {
      type: Boolean,
      default: !1
    }
  },
  emits: ["visibility"],
  setup(e, { emit: t }) {
    const n = t, o = e, r = wt("container"), s = E(!1), i = k(() => !o.disable);
    return An(
      r,
      (a) => {
        n("visibility", a), a ? s.value = !0 : o.destroyOnLeave && (s.value = !1);
      },
      {
        margin: o.margin,
        rootSelector: o.root,
        enabled: i
      }
    ), (a, u) => (D(), j("div", {
      ref_key: "container",
      ref: r,
      style: ue({ minHeight: e.height, position: "relative" })
    }, [
      s.value ? Z(a.$slots, "default", { key: 0 }) : Z(a.$slots, "hidden", { key: 1 })
    ], 4));
  }
});
function rt(e) {
  var n;
  if (!e) return e;
  const t = (n = M().serverInfo) == null ? void 0 : n.assets_url;
  try {
    return new URL(e), e;
  } catch {
    let o = e;
    return o.startsWith("/assets/") && (o = o.slice(7)), o.startsWith("/") || (o = "/" + o), t.replace(/\/$/, "") + o;
  }
}
const Pn = $(jn, {
  props: ["src"]
});
function jn(e) {
  const t = ye();
  return () => C("img", {
    ...t.value,
    src: rt(e.src)
  });
}
const xn = $(Nn, {
  props: ["src"]
});
function Nn(e) {
  const t = ye();
  return () => C("video", {
    ...t.value,
    src: rt(e.src)
  });
}
function Rn(e, t) {
  if (!t)
    return e;
  const n = [];
  return t.forEach((o) => {
    const { sys: r = 0, name: s, arg: i, mf: a } = o;
    if (s === "vmodel") {
      const u = o.value;
      if (e = ee(e, {
        [`onUpdate:${i}`]: (c) => {
          u.value = c;
        }
      }), r === 1) {
        const c = a ? Object.fromEntries(a.map((l) => [l, !0])) : {};
        n.push([bt, u.value, void 0, c]);
      } else
        e = ee(e, {
          [i]: u.value
        });
    } else if (s === "vshow") {
      const u = m(o.value);
      n.push([St, u]);
    } else
      console.warn(`Directive ${s} is not supported yet`);
  }), n.length > 0 ? ze(e, n) : e;
}
function Pe(e, t) {
  Object.entries(e).forEach(([n, o]) => t(o, n));
}
function de(e, t) {
  return Fn(e, {
    valueFn: t
  });
}
function Fn(e, t) {
  const { valueFn: n, keyFn: o } = t;
  return Object.fromEntries(
    Object.entries(e).map(([r, s], i) => [
      o ? o(r, s) : r,
      n(s, r, i)
    ])
  );
}
const Dn = window.structuredClone || ((e) => JSON.parse(JSON.stringify(e)));
function Se(e) {
  if (typeof e == "function")
    return e;
  try {
    return Dn(He(m(e)));
  } catch {
    return e;
  }
}
class Bn {
  toString() {
    return "";
  }
}
const W = new Bn();
function U(e) {
  return He(e) === W;
}
function In(e) {
  if (!e)
    return null;
  const t = {}, {
    bProps: n = {},
    pProps: o = [],
    sProps: r = {},
    ref: s
  } = e;
  return te(r), Pe(n, (i, a) => {
    const u = m(i);
    U(u) || (te(u), t[a] = Ln(u, a));
  }), o.forEach((i) => {
    const a = m(i);
    typeof a == "object" && Pe(a, (u, c) => {
      const { name: l, value: f } = $t(c, u);
      t[l] = f;
    });
  }), s && (t.ref = s), { ...r, ...t };
}
function Ln(e, t) {
  return t === "innerText" ? Ve(e) : e;
}
function Mn(e) {
  if (!e)
    return;
  if (typeof e == "string")
    return {
      class: _e(e)
    };
  const { sClass: t, mClass: n, bClass: o } = e, r = [];
  return t && r.push(...t), n && r.push(de(n, m)), o && r.push(...o.map(m)), {
    class: _e(r)
  };
}
function Vn(e) {
  if (!e)
    return;
  if (typeof e == "string")
    return {
      style: ue(e)
    };
  const t = [], {
    sStyle: n = {},
    bStyle: o = {},
    pStyle: r = []
  } = e;
  return t.push(de(n, m)), t.push(de(o, m)), t.push(...r.map(m)), {
    style: ue([n, t])
  };
}
class Wn extends Map {
  constructor(t) {
    super(), this.factory = t;
  }
  getOrDefault(t) {
    if (!this.has(t)) {
      const n = this.factory();
      return this.set(t, n), n;
    }
    return super.get(t);
  }
}
function Un(e) {
  return new Wn(e);
}
function zn(e, t, n) {
  const o = Un(() => []);
  for (const [r, s] of Object.entries(t ?? {}))
    (Array.isArray(s) ? s : [s]).forEach((i) => {
      const { handleEvent: a, modifier: u = [], withKeys: c } = i, { eventName: l, handleEvent: f } = Hn({
        eventName: r,
        modifier: u,
        handleEvent: a
      }), d = c ? Et(f, c) : f;
      o.getOrDefault(l).push(d);
    });
  if (e = ee(e, Kn(o.entries())), n) {
    const r = {};
    if (n.mounted) {
      const s = Array.isArray(n.mounted) ? n.mounted : [n.mounted];
      r.mounted = function(i) {
        for (const a of s)
          a.handleEvent(i);
      };
    }
    e = ze(e, [[r]]);
  }
  return e;
}
function Hn(e) {
  const { eventName: t, handleEvent: n, modifier: o = [] } = e;
  if (o.length === 0)
    return {
      eventName: t,
      handleEvent: n
    };
  const r = ["passive", "capture", "once"], s = [], i = [];
  for (const c of o)
    r.includes(c) ? s.push(c[0].toUpperCase() + c.slice(1)) : i.push(c);
  const a = s.length > 0 ? t + s.join("") : t, u = i.length > 0 ? kt(n, i) : n;
  return {
    eventName: a,
    handleEvent: u
  };
}
function Jn(e, t) {
  return (...n) => {
    for (const o of e)
      try {
        const r = o(...n);
        r instanceof Promise && r.catch((s) => {
          console.error(
            "[EventHandler Error]",
            {
              event: t == null ? void 0 : t.eventName,
              component: t == null ? void 0 : t.componentName,
              handler: o
            },
            s
          );
        });
      } catch (r) {
        console.error(
          "[EventHandler Error]",
          {
            event: t == null ? void 0 : t.eventName,
            component: t == null ? void 0 : t.componentName,
            handler: o
          },
          r
        );
      }
  };
}
function Kn(e) {
  const t = {};
  for (const [n, o] of e)
    t[n] = Jn(o, {
      eventName: n
    });
  return t;
}
function Ar(e) {
  const { tag: t, props: n, classes: o, style: r, slots: s, dirs: i, events: a, lifeEvents: u } = e, c = m(t), l = _t(c), f = typeof l == "string", d = {
    ...In(n),
    ...Mn(o),
    ...Vn(r)
  };
  let h = C(l, d, Gn(s, f));
  return h = zn(h, a, u), Rn(h, i);
}
function Gn(e, t) {
  return !e || !t ? e : typeof e == "function" ? e() : e;
}
const ne = Symbol("instaui-scope");
function ot(e) {
  return Object.create(e || null);
}
function st() {
  let e = Ke(ne, null);
  return e || (e = ot(), Je(ne, e), e);
}
function qn(e) {
  const t = st(), n = ot(t);
  return Object.assign(n, e), Je(ne, n), n;
}
function Qn() {
  const e = Ke(ne, null);
  if (!e) throw new Error("Scope not initialized");
  return e;
}
function $r(e, t) {
  return C(Yn, t, () => C(e));
}
const Yn = $(Xn, {
  props: ["vfor", "slot"]
});
function Xn(e) {
  const t = ge().default, { vfor: n, slot: o } = e, r = {};
  if (n) {
    const { value: s, index: i, itemKey: a } = n;
    i && i.forEach(([u, c]) => {
      r[u] = E(c);
    }), s && s.forEach(([u, c]) => {
      r[u] = E(c);
    }), a && a.forEach(([u, c]) => {
      r[u] = E(c);
    });
  }
  if (o) {
    const [s, i] = o;
    r[s] = E(i);
  }
  return Object.keys(r).length > 0 && qn(r), () => {
    if (e.vfor) {
      const { value: s, index: i, itemKey: a } = e.vfor;
      i && i.forEach(([u, c]) => {
        r[u].value = c;
      }), s && s.forEach(([u, c]) => {
        r[u].value = c;
      }), a && a.forEach(([u, c]) => {
        r[u].value = c;
      });
    }
    if (e.slot) {
      const [s, i] = e.slot;
      r[s].value = i;
    }
    return t == null ? void 0 : t();
  };
}
function je(e, t) {
  return !U(e) && JSON.stringify(t) === JSON.stringify(e);
}
function Ee(e) {
  if (P(e)) {
    const t = e;
    return X(() => ({
      get() {
        return m(t);
      },
      set(n) {
        const o = m(t);
        je(o, n) || (t.value = n);
      }
    }));
  }
  return X((t, n) => ({
    get() {
      return t(), e;
    },
    set(o) {
      je(e, o) || (e = o, n());
    }
  }));
}
function it(e) {
  return Ct(e) || e instanceof Element;
}
function Pr(e) {
  const { init: t, deepEqOnInput: n } = e || {};
  return n === void 0 ? re(t ?? W) : Ee(t ?? W);
}
function at(e) {
  const { config: t } = e;
  if (!t)
    return {
      run: () => {
      },
      tryReset: () => {
      }
    };
  const n = t.map((s) => {
    const [i, a, u] = s;
    function c(l, f) {
      const { type: d, value: h } = f;
      if (d === "const") {
        l.value = h;
        return;
      }
      if (d === "action") {
        const p = Zn(h);
        l.value = p;
        return;
      }
    }
    return {
      run: () => c(i, a),
      reset: () => c(i, u)
    };
  });
  return {
    run: () => {
      n.forEach((s) => s.run());
    },
    tryReset: () => {
      n.forEach((s) => s.reset());
    }
  };
}
function Zn(e) {
  const { inputs: t = [], code: n } = e, o = T(n), r = t.map(m);
  return o(...r);
}
function xe(e) {
  return e == null;
}
const K = {
  Ref: 0,
  ElementRefAction: 2,
  JsCode: 3,
  FileDownload: 4
};
class ct extends Error {
  constructor(t) {
    super(t), this.name = "BrowserNotSupportedError";
  }
}
function ut(e, t) {
  switch (t) {
    case "kb":
      return e * 1024;
    case "mb":
      return e * 1024 * 1024;
    case "gb":
      return e * 1024 * 1024 * 1024;
    default:
      return e;
  }
}
class er {
  constructor(t, n) {
    b(this, "filename");
    b(this, "filepath");
    b(this, "chuckedConfig");
    b(this, "onProgress");
    b(this, "onStatus");
    b(this, "controller", null);
    b(this, "receivedBytes", 0);
    b(this, "totalBytes", 0);
    b(this, "chunks", []);
    b(this, "downloading", !1);
    this.url = t, this.filename = n.filename, this.filepath = n.filepath, this.chuckedConfig = n.config, this.onProgress = () => {
    }, this.onStatus = () => {
    };
  }
  async start() {
    this.downloading || (this.downloading = !0, await this.fetchChunk(this.receivedBytes));
  }
  pause() {
    var t;
    this.downloading && (this.downloading = !1, (t = this.controller) == null || t.abort());
  }
  async resume() {
    this.downloading || (this.downloading = !0, await this.fetchChunk(this.receivedBytes));
  }
  async fetchChunk(t) {
    var c;
    this.controller = new AbortController();
    const n = ut(
      this.chuckedConfig.chunk_size,
      this.chuckedConfig.chunk_size_unit
    ), o = new URLSearchParams({
      filepath: this.filepath,
      mode: "chunked",
      chunk_bytes: n.toString()
    }), r = `${this.url}?` + o.toString(), s = t ? { Range: `bytes=${t}-` } : {}, i = await fetch(r, {
      headers: s,
      signal: this.controller.signal
    });
    if (!i.ok && i.status !== 206 && i.status !== 200) {
      this.downloading = !1;
      return;
    }
    const a = i.headers.get("Content-Range");
    this.totalBytes = a && parseInt(a.split("/")[1]) || parseInt(i.headers.get("Content-Length") || "0", 10);
    const u = (c = i.body) == null ? void 0 : c.getReader();
    if (!u)
      throw new ct("Browser does not support streaming download");
    for (; this.downloading; ) {
      const { done: l, value: f } = await u.read();
      if (l) break;
      f && (this.chunks.push(f), this.receivedBytes += f.length, this.updateProgress());
    }
    this.receivedBytes >= this.totalBytes && this.finish();
  }
  updateProgress() {
    if (this.totalBytes > 0) {
      const t = parseFloat(
        (this.receivedBytes / this.totalBytes * 100).toFixed(2)
      );
      this.onProgress(t);
    } else
      (this.receivedBytes / 1024 / 1024).toFixed(2);
  }
  finish() {
    this.downloading = !1;
    const t = this.chunks.reduce(
      (i, a) => i + a.length,
      0
    ), n = new Uint8Array(t);
    let o = 0;
    for (const i of this.chunks)
      n.set(i, o), o += i.length;
    const r = new Blob([n]), s = document.createElement("a");
    s.href = URL.createObjectURL(r), s.download = this.filename, s.click(), URL.revokeObjectURL(s.href), this.chunks = [];
  }
  get progress() {
    return { received: this.receivedBytes, total: this.totalBytes };
  }
  get isDownloading() {
    return this.downloading;
  }
}
class he {
  constructor(t, n) {
    b(this, "filename");
    b(this, "filepath");
    b(this, "onProgress");
    b(this, "onStatus");
    b(this, "controller", null);
    b(this, "receivedBytes", 0);
    b(this, "totalBytes", 0);
    b(this, "downloading", !1);
    this.url = t, this.filename = n.filename, this.filepath = n.filepath, this.onProgress = () => {
    }, this.onStatus = () => {
    };
  }
  async start() {
    this.downloading || (this.downloading = !0, await this.downloadFile());
  }
  pause() {
    var t;
    this.downloading && (this.downloading = !1, (t = this.controller) == null || t.abort());
  }
  async downloadFile() {
    var o;
    this.controller = new AbortController();
    const t = new URLSearchParams({ filepath: this.filepath }), n = `${this.url}?` + t.toString();
    try {
      const r = await fetch(n, {
        signal: this.controller.signal
      });
      if (!r.ok) {
        this.onStatus(`Download failed: ${r.statusText}`), this.downloading = !1;
        return;
      }
      this.totalBytes = parseInt(r.headers.get("Content-Length") || "0", 10);
      const s = (o = r.body) == null ? void 0 : o.getReader();
      if (!s) {
        this.onStatus("Web Browser not support download file"), this.downloading = !1;
        return;
      }
      const i = [];
      for (; this.downloading; ) {
        const { done: a, value: u } = await s.read();
        if (a) break;
        u && (i.push(u), this.receivedBytes += u.length, this.updateProgress());
      }
      this.receivedBytes >= this.totalBytes && this.finishDownload(i);
    } catch (r) {
      this.onStatus(`Download error: ${r instanceof Error ? r.message : String(r)}`), this.downloading = !1;
    }
  }
  updateProgress() {
    if (this.totalBytes > 0) {
      const t = parseFloat(
        (this.receivedBytes / this.totalBytes * 100).toFixed(2)
      );
      this.onProgress(t);
    }
  }
  finishDownload(t) {
    this.downloading = !1;
    const n = t.reduce((a, u) => a + u.length, 0), o = new Uint8Array(n);
    let r = 0;
    for (const a of t)
      o.set(a, r), r += a.length;
    const s = new Blob([o]), i = document.createElement("a");
    i.href = URL.createObjectURL(s), i.download = this.filename, i.click(), URL.revokeObjectURL(i.href);
  }
  get progress() {
    return { received: this.receivedBytes, total: this.totalBytes };
  }
  get isDownloading() {
    return this.downloading;
  }
}
async function tr(e) {
  const t = M().serverInfo.download_url;
  if (e.mode === "auto") {
    if (!e.config)
      throw new Error("Auto mode requires config parameters");
    const n = e.config, o = ut(
      n.threshold_size,
      n.threshold_size_unit
    );
    e.filesize < o ? await new he(t, e).start() : await Ne(t, e);
    return;
  }
  if (e.mode === "chunked") {
    await Ne(t, e);
    return;
  }
  if (e.mode === "standard") {
    await new he(t, e).start();
    return;
  }
}
async function Ne(e, t) {
  try {
    await new er(e, t).start();
  } catch (n) {
    if (n instanceof ct)
      await new he(e, t).start();
    else
      throw n;
  }
}
function nr(e, t, n) {
  if (!t.length)
    return;
  let r = m(e);
  for (let i = 0; i < t.length - 1; i++) {
    const a = t[i];
    if (r[a] === null || r[a] === void 0) {
      const u = t[i + 1];
      r[a] = typeof u == "number" ? [] : {};
    }
    r = r[a];
  }
  const s = t[t.length - 1];
  r[s] = n;
}
function oe(e, t, n) {
  if (xe(t) || xe(e.values))
    return;
  t = t, n = n ?? Array.from({ length: t.length }).fill(
    K.Ref
  );
  const o = e.values, r = e.types ?? Array.from({ length: t.length }).fill(0);
  t.forEach((s, i) => {
    const a = r[i], u = n[i];
    if (a !== 1) {
      if (u === K.Ref) {
        if (a === 2) {
          o[i].forEach(([l, f]) => {
            nr(s, l, f);
          });
          return;
        }
        s.value = o[i];
        return;
      }
      if (u === K.ElementRefAction) {
        const c = s.value, l = o[i], { method: f, args: d = [] } = l;
        c[f](...d);
        return;
      }
      if (u === K.JsCode) {
        const c = o[i];
        if (!c)
          return;
        const l = T(c);
        Promise.resolve(l());
        return;
      }
      if (u === K.FileDownload) {
        const c = o[i];
        tr(c);
        return;
      }
      s.value = o[i];
    }
  });
}
function* rr(e, t) {
  const n = e[Symbol.iterator](), o = t[Symbol.iterator]();
  for (; ; ) {
    const r = n.next(), s = o.next();
    if (r.done || s.done) return;
    yield [r.value, s.value];
  }
}
function or(e) {
  let t = 1;
  const n = [];
  let o = !1, r = !1;
  async function s(l) {
    await sr(l);
  }
  function i() {
    for (const l of n)
      if ([...e.get(l.config)].filter(
        (h) => n.some((p) => p.config === h)
      ).length === 0)
        return n.splice(n.indexOf(l), 1), l;
    return null;
  }
  async function a() {
    if (!o) {
      o = !0;
      try {
        for (; ; ) {
          const l = i();
          if (!l) break;
          await s(l);
        }
      } finally {
        o = !1;
      }
    }
  }
  function u() {
    r || (r = !0, Promise.resolve().then(() => {
      r = !1, a().catch((l) => {
        console.error("flushTasks error", l);
      });
    }));
  }
  function c(l, f, d) {
    const h = n.find((p) => p.config === l);
    if (h) {
      h.payload = { newVals: f, oldVals: d };
      return;
    }
    n.push({
      config: l,
      token: t++,
      payload: { newVals: f, oldVals: d }
    }), u();
  }
  return {
    pushTask: c,
    flushTasks: a
  };
}
function jr(e) {
  const t = e.map(ir), n = /* @__PURE__ */ new Map();
  for (const r of t)
    n.set(r, /* @__PURE__ */ new Set());
  for (const r of t)
    if (!(r.type !== "c" || !r.outputs))
      for (const s of t)
        Array.from(rr(s.inputs, s.slient)).some(
          ([a, u]) => u !== 1 && r.outputs.includes(a)
        ) && n.get(s).add(r);
  const { pushTask: o } = or(n);
  for (const r of t) {
    const {
      immediate: s = !0,
      deep: i = !0,
      once: a,
      flush: u,
      inputs: c = [],
      slient: l = []
    } = r;
    let f = l;
    c.length > 0 && l.length === 0 && (f = Array.from({ length: c.length }).fill(0));
    const d = c.filter(
      (h, p) => f[p] === 0 && P(h)
    );
    O(
      d,
      async (h, p) => {
        h.some(U) || o(r, h, p);
      },
      { immediate: s, deep: i, once: a, flush: u }
    );
  }
}
async function sr(e) {
  const {
    outputs: t,
    opTypes: n,
    preSetup: o
  } = e.config, r = at({
    config: o
  });
  try {
    r.run();
    const s = await nt().watchSend(e);
    if (!s)
      return;
    oe(s, t, n);
  } finally {
    r.tryReset();
  }
}
function ir(e) {
  const {
    inputs: t = [],
    outputs: n = [],
    opTypes: o,
    slient: r = [],
    data: s = [],
    fType: i = "sync"
  } = e;
  let a = r, u = s, c = o;
  return t.length > 0 && (r.length === 0 && (a = Array.from({ length: t.length }).fill(0)), s.length === 0 && (u = Array.from({ length: t.length }).fill(1)), o || (c = Array.from({ length: t.length }).fill(
    0
  ))), {
    ...e,
    inputs: t,
    outputs: n,
    opTypes: c,
    fType: i,
    data: u,
    slient: a
  };
}
const I = {
  Ref: 0,
  EventContext: 1,
  Data: 2,
  JsFn: 3,
  ElementRef: 4,
  EventContextDataset: 5
}, Re = {
  const: "c",
  ref: "r",
  range: "n"
};
function xr(e, t) {
  const { fkey: n, tsGroup: o = {} } = e, r = [];
  for (const [i, a, u] of ar(e))
    r.push(
      ...t({
        i,
        v: a,
        k: u
      }).map((c) => {
        const l = lr(n, { value: a, index: i });
        return ee(c, { key: l });
      })
    );
  const s = j(L, null, r);
  return o && Object.keys(o).length > 0 ? C(Ot, o, {
    default: () => s
  }) : s;
}
function ar(e) {
  const { type: t, value: n } = e.array, o = t === Re.range, r = t === Re.const || o && typeof n == "number";
  if (o) {
    const { start: s = 0, end: i, step: a = 1 } = n, u = m(s), c = m(i), l = m(a);
    return Fe(u, c, l);
  }
  {
    const s = r ? n : m(n);
    if (typeof s == "number")
      return Fe(0, s, 1);
    if (Array.isArray(s)) {
      function* i() {
        for (let a = 0; a < s.length; a++)
          yield [a, s[a], a];
      }
      return i();
    }
    if (typeof s == "object" && s !== null) {
      function* i() {
        let a = 0;
        for (const [u, c] of Object.entries(s))
          yield [a++, c, u];
      }
      return i();
    }
    if (U(s))
      return s;
  }
  throw new Error("Not implemented yet");
}
function* Fe(e, t, n = 1) {
  if (n === 0)
    throw new Error("Step cannot be 0");
  let o = 0;
  if (n > 0)
    for (let r = e; r < t; r += n)
      yield [o++, r, o];
  else
    for (let r = e; r > t; r += n)
      yield [o++, r, o];
}
const cr = (e) => e, ur = (e, t) => t;
function lr(e, t) {
  const { value: n, index: o } = t, r = fr(e ?? "index");
  return typeof r == "function" ? r(n, o) : e === "item" ? cr(n) : ur(n, o);
}
function fr(e) {
  const t = e.trim();
  if (t === "item" || t === "index")
    return;
  if (e.startsWith(":")) {
    e = e.slice(1);
    try {
      return T(e);
    } catch (o) {
      throw new Error(o + " in function code: " + e);
    }
  }
  const n = `(item, index) => { return ${t}; }`;
  try {
    return T(n);
  } catch (o) {
    throw new Error(o + " in function code: " + n);
  }
}
function Nr(e) {
  const { deepCompare: t = !1, value: n } = e;
  return t ? Ee(n) : E(n);
}
function Rr(e, t = []) {
  const n = e === null || typeof e != "object" && typeof e != "function" && !P(e);
  return X((o, r) => {
    function s() {
      let i = e, a, u, c = !0;
      n && (c = !1), P(i) && (i = i.value);
      for (const l of t) {
        if (i == null)
          return { value: void 0, writable: !1 };
        const f = m(l);
        if (typeof f == "string" || typeof f == "number")
          a = i, u = f, i = i[f], P(i) && (i = i.value);
        else if (pr(f))
          i = hr(f.op, i), c = !1;
        else {
          const d = m(f.v);
          i = dr(f.op, i, d), c = !1;
        }
      }
      return { value: i, parent: a, key: u, writable: c };
    }
    return {
      get() {
        return o(), s().value;
      },
      set(i) {
        const a = s();
        if (!a.writable || !a.parent)
          throw new Error("This trackPath result is readonly");
        const u = a.parent, c = a.key;
        P(u[c]) ? u[c].value = i : u[c] = i, r();
      }
    };
  });
}
function dr(e, t, n) {
  switch (e) {
    case ">":
      return t > n;
    case ">=":
      return t >= n;
    case "<":
      return t < n;
    case "<=":
      return t <= n;
    case "==":
      return t == n;
    case "!=":
      return t != n;
    case "+":
      return t + n;
    case "~+":
      return n + t;
    case "-":
      return t - n;
    case "~-":
      return n - t;
    case "*":
      return t * n;
    case "~*":
      return n * t;
    case "/":
      return t / n;
    case "~/":
      return n / t;
    case "&&":
      return t && n;
    case "||":
      return t || n;
    default:
      throw new Error(`Unsupported operator: ${e}`);
  }
}
function hr(e, t) {
  switch (e) {
    case "!":
      return !t;
    case "~":
      return ~t;
    default:
      throw new Error(`Unsupported unary operator: ${e}`);
  }
}
function pr(e) {
  return !("v" in e);
}
function lt(e) {
  return e.constructor.name === "AsyncFunction";
}
function mr(e, t) {
  const n = /* @__PURE__ */ new Map();
  return (...o) => {
    const r = t(...o);
    if (n.has(r))
      return n.get(r);
    const s = e(...o);
    return n.set(r, s), s;
  };
}
function yr(e) {
  if (!e) return null;
  switch (e) {
    case "unwrap_reactive":
      return gr;
    default:
      throw new Error(`Invalid js computed tool ${e}`);
  }
}
function gr(e, t, ...n) {
  const o = Se(e);
  return t.forEach((r, s) => {
    const i = n[s];
    let a = o;
    for (let c = 0; c < r.length - 1; c++) {
      const l = r[c];
      a = a[l];
    }
    const u = r[r.length - 1];
    a[u] = i;
  }), o;
}
function Fr(e) {
  const {
    inputs: t = [],
    code: n,
    asyncInit: o = null,
    deepEqOnInput: r = 0,
    tool: s
  } = e, i = t.filter((f) => P(f));
  function a() {
    return t.map((f) => {
      const d = typeof f == "function", h = d ? f : m(f);
      return it(h) || d ? h : Se(h);
    });
  }
  const u = yr(s) ?? T(n), c = r === 0 ? re(W) : Ee(W), l = { immediate: !0, deep: !0 };
  return lt(u) ? (c.value = o, O(
    i,
    async () => {
      const f = a();
      if (!f.some(U))
        try {
          c.value = await u(...f);
        } catch (d) {
          throw console.error(d, "in computed code: ", n), new Error(d + " in computed code: " + n);
        }
    },
    l
  )) : O(
    i,
    () => {
      const f = a();
      if (!f.some(U))
        try {
          c.value = u(...f);
        } catch (d) {
          throw console.error(d, "in computed code: ", n), new Error(d + " in computed code: " + n);
        }
    },
    l
  ), pe(c);
}
function Dr(e) {
  const t = (e.args || []).map(m), n = Object.fromEntries(
    Object.entries(e.kws || {}).map(([o, r]) => [o, m(r)])
  );
  return vr(m(e.code), ...t, n);
}
function vr(e, ...t) {
  let n = {};
  if (t.length > 0) {
    const o = t[t.length - 1];
    typeof o == "object" && !Array.isArray(o) && (n = o, t = t.slice(0, -1));
  }
  return e = e.replace(/\{\}/g, () => {
    const o = t.shift();
    return o !== void 0 ? ae(o) : "";
  }), e = e.replace(/\{(\d+)\}/g, (o, r) => {
    const s = Number(r);
    return t[s] !== void 0 ? ae(t[s]) : "";
  }), e = e.replace(/\{([^{}\d][^{}]*)\}/g, (o, r) => Object.prototype.hasOwnProperty.call(n, r) ? ae(n[r]) : o), e;
}
function ae(e) {
  if (e === null) return "null";
  if (typeof e == "object")
    try {
      return JSON.stringify(e);
    } catch {
      return String(e);
    }
  return String(e);
}
function ft(e, t, n, o) {
  return [...e.map((s, i) => {
    const a = t[i], u = a === I.EventContextDataset;
    if (a === I.EventContext || u) {
      const c = s(...o);
      return c == null ? c : u ? JSON.parse(c) : c;
    }
    if (a === I.Ref)
      return m(s);
    if (a === I.Data)
      return s;
    if (a === I.ElementRef)
      return m(s);
    if (a === I.JsFn)
      return s;
    throw new Error(`unknown input type ${a}`);
  }), ...n.map(m)];
}
function ke(e, t) {
  return async (...n) => await e(t, ...n);
}
function Br(e) {
  const { inputs: t = [], iptTypes: n = [] } = e;
  async function o(s, ...i) {
    const a = ft(t, n, s, i), u = at({
      config: e.preSetup
    });
    try {
      u.run();
      const c = await nt().eventSend(e, a);
      if (!c)
        return;
      oe(c, e.outputs, e.opTypes);
    } finally {
      u.tryReset();
    }
  }
  function r(s) {
    return {
      handleEvent: ke(o, (s == null ? void 0 : s.params) || []),
      ...s
    };
  }
  return {
    fn: r
  };
}
function Ir(e) {
  const {
    outputs: t = [],
    code: n,
    inputs: o = [],
    iptTypes: r = [],
    opTypes: s = []
  } = e, i = T(n);
  async function a(c, ...l) {
    const f = ft(o, r, c, l), d = await i(...f);
    if (t.length > 0) {
      const p = t.length === 1 ? [d] : d, g = p.map((v) => v === void 0 ? 1 : 0);
      oe(
        { values: p, types: g },
        t,
        s
      );
    }
  }
  function u(c) {
    return {
      handleEvent: ke(a, (c == null ? void 0 : c.params) || []),
      ...c
    };
  }
  return {
    fn: u
  };
}
function Lr(e) {
  const { code: t, bind: n = {} } = e, o = T(t, n);
  async function r(i, ...a) {
    await o(...i, ...a);
  }
  function s(i) {
    return {
      handleEvent: ke(r, (i == null ? void 0 : i.params) || []),
      ...i
    };
  }
  return {
    fn: s
  };
}
function Mr(e, t) {
  return m(e.on) ? j(L, null, t()) : C(L);
}
function Vr(e, t) {
  const { cs: n, df: o } = t;
  if (!n && !o)
    return null;
  const r = m(e);
  return n && n[r] ? j(L, null, n[r]()) : o ? j(L, null, o()) : null;
}
function Wr(e) {
  e.forEach(wr);
}
function wr(e) {
  const {
    inputs: t = [],
    outputs: n,
    opTypes: o,
    slient: r,
    code: s,
    immediate: i = !0,
    deep: a = !0,
    once: u,
    flush: c
  } = e, l = r || Array.from({ length: t.length }).fill(0), f = T(s), d = t.filter(
    (p, g) => l[g] === 0 && P(p)
  );
  function h() {
    return t.map((p) => {
      const g = typeof p == "function", v = g ? p : m(p);
      return it(v) || g ? v : Se(v);
    });
  }
  O(
    d,
    async () => {
      let p = await f(...h());
      if (!n)
        return;
      const v = n.length === 1 ? [p] : p, R = v.map((A) => A === void 0 ? 1 : 0);
      oe(
        {
          values: v,
          types: R
        },
        n,
        o
      );
    },
    { immediate: i, deep: a, once: u, flush: c }
  );
}
function Ur(e) {
  e.forEach(br);
}
function br(e) {
  const {
    on: t,
    code: n,
    immediate: o = !1,
    deep: r = !1,
    once: s,
    flush: i,
    bind: a = {}
  } = e, u = T(n, a), c = t.length === 1 ? t[0] : t.map(
    (l) => () => typeof l == "function" ? l : m(l)
  );
  return O(c, u, { immediate: o, deep: r, once: s, flush: i });
}
function zr(e) {
  return Tt(m(e));
}
function Hr(e) {
  const { type: t, key: n, value: o } = e;
  return t === "local" ? le(n, o) : le(n, o, sessionStorage);
}
const Sr = "insta-color-scheme";
function Jr() {
  return Yt({
    storageKey: Sr,
    onChanged(t) {
      t ? (document.documentElement.setAttribute("theme-mode", "dark"), document.documentElement.classList.add("insta-dark")) : (document.documentElement.setAttribute("theme-mode", "light"), document.documentElement.classList.remove("insta-dark"));
    }
  });
}
const Er = E("en_US");
function Kr() {
  return Er;
}
function Gr(e) {
  return Xt(e);
}
function qr(e) {
  const { bind: t = {}, code: n } = e;
  if (lt(new Function(n)))
    return Lt(
      async () => await T(n, t)(),
      null,
      { lazy: !0 }
    );
  const o = T(n, t);
  return k(o);
}
function Qr(e, t) {
  const n = new URLSearchParams(window.location.search);
  return k(() => n.get(m(e)) ?? m(t));
}
function Yr(e) {
  const t = st();
  for (const n in e)
    t[n] = e[n];
}
function kr() {
  const e = Qn();
  return new Proxy(
    {},
    {
      get(t, n) {
        return e[n];
      }
    }
  );
}
function Xr() {
  function e(t) {
    return kr()[t];
  }
  return {
    getRef: e
  };
}
function Zr(e) {
  const t = m(e);
  if (t !== W)
    return t;
  const n = E();
  return O(
    e,
    (o) => {
      n.value = o;
    },
    { immediate: !1, once: !0 }
  ), n;
}
const _r = mr(
  Cr,
  (e, t, n) => `${e}|${t}|${n}`
);
function eo(e, t) {
  const n = M().route.path;
  return k(
    () => _r(n, m(e)) ?? m(t)
  );
}
function Cr(e, t, n = window.location.pathname) {
  const o = e.split("/").filter(Boolean), r = n.split("/").filter(Boolean);
  if (o.length === r.length)
    for (let s = 0; s < o.length; s++) {
      const i = o[s], a = r[s];
      if (i.startsWith(":")) {
        if (i.slice(1) === t)
          return decodeURIComponent(a);
      } else if (i !== a)
        return;
    }
}
function to(e, t, n) {
  const r = (n ?? At)({
    setup() {
      return () => C(Te, { meta: t }, () => C(e));
    }
  });
  return r.component("insta-ui", Te), r.component("teleport", ln), r.component("icon", hn), r.component("grid", yn), r.component("ui-text", _n), r.component("ui-link", Cn), r.component("lazy-render", $n), r.component("ui-img", Pn), r.component("ui-video", xn), r;
}
export {
  zr as content,
  te as convertDynamicProperties,
  qr as createExprComputed,
  Lr as createExprEvent,
  Fr as createJsComputed,
  Ir as createJsEvent,
  Nr as createRef,
  Pr as createWebComputedRef,
  Br as createWebEvent,
  Ur as exprWatch,
  xr as genVFor,
  sn as generateSvgSpriteEmbedInHtml,
  M as getAppInfo,
  kr as inject,
  to as install,
  Wr as jsWatch,
  Vr as match,
  Yr as provide,
  Ar as renderComponent,
  $r as renderScope,
  Hr as storageRef,
  Dr as strFormat,
  Zr as toValue,
  Rr as trackPath,
  Xr as useBindingGetter,
  Jr as useDark,
  Jr as useDarkRef,
  Kr as useLanguage,
  Kr as useLanguageRef,
  Gr as usePageTitle,
  Gr as usePageTitleRef,
  Qr as useQueryParam,
  eo as useRouteParam,
  Mr as vif,
  jr as webWatchTaskScheduler
};
