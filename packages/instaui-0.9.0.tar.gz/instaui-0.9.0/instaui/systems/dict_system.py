def merge_dicts(*dicts: dict | None):
    return {k: v for d in dicts if d is not None for k, v in d.items()}
