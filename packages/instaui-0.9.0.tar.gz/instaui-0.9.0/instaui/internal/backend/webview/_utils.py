from typing import Any

import orjson


def to_json_compatible(obj: Any) -> Any:
    """
    Convert objects containing date/datetime into JSON-compatible Python objects.
    """

    json_bytes = orjson.dumps(
        obj,
        option=orjson.OPT_SERIALIZE_DATACLASS,
    )
    return orjson.loads(json_bytes)


def to_json_compatible_preserve_tuples(obj: Any) -> Any:
    """
    Like to_json_compatible, but preserves the outermost tuple type if present.

    If the input is a tuple, the result will be a tuple (converted inner elements
    as per to_json_compatible). For other inputs, the behavior is identical to
    to_json_compatible.
    """
    result = to_json_compatible(obj)
    if isinstance(obj, tuple):
        # to_json_compatible converts tuple to list, so convert back to tuple
        return tuple(result)
    return result
