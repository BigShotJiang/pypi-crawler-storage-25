import inspect

from instaui.internal.backend.common.response import response_data
from instaui.internal.runtime.webview.async_executor import AsyncExecutor

from . import _utils
from .event_handler import get_event_handler
from .watch_handler import get_watch_handler


class Api:
    def __init__(self, async_executor: AsyncExecutor) -> None:
        self._async_executor = async_executor

    def watch_call(self, data: dict):
        hkey = data.pop("hKey")
        handler = get_watch_handler(hkey)
        if handler is None:
            return {"error": "watch handler not found"}

        exec_result = handler.fn(*handler.get_handler_args(_get_binds_from_data(data)))

        if inspect.iscoroutinefunction(handler.fn):
            result = self._async_executor.run_and_wait(exec_result)
        else:
            result = exec_result
        return response_data(
            handler.outputs_binding_count,
            _utils.to_json_compatible_preserve_tuples(result),
        )

    def event_call(self, data: dict):
        hkey = data.pop("hKey")
        handler = get_event_handler(hkey)
        if handler is None:
            raise ValueError("event handler not found")

        args = [bind for bind in data.get("bind", [])]

        exec_result = handler.fn(*handler.get_handler_args(args))

        if inspect.iscoroutinefunction(handler.fn):
            result = self._async_executor.run_and_wait(exec_result)
        else:
            result = exec_result

        return response_data(
            handler.outputs_binding_count,
            _utils.to_json_compatible_preserve_tuples(result),
        )


def _get_binds_from_data(data: dict):
    return data.get("input", [])
