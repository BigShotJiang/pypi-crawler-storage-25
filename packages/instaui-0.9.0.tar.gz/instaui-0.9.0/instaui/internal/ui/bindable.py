from __future__ import annotations

from abc import ABC, abstractmethod
from itertools import chain
from typing import (
    TYPE_CHECKING,
    Any,
    Iterable,
    Iterator,
    Sequence,
)

from typing_extensions import TypeIs

if TYPE_CHECKING:
    from instaui.internal.ui._scope import Scope
    from instaui.internal.ui.consumer import Consumer


class BindableMixin(ABC):
    @abstractmethod
    def _try_hoist(self, target_scope: Scope) -> None:
        raise NotImplementedError

    @abstractmethod
    def _apply_binding(self, consumer: Consumer): ...


def is_bindable(obj: Any) -> TypeIs[BindableMixin]:
    return isinstance(obj, BindableMixin)


def try_apply_binding(obj: Any, consumer: Consumer):
    apply_bindings(extract_bindables(obj), consumer)


def apply_bindings(
    bindables: BindableMixin | Iterable[BindableMixin], consumer: Consumer
):
    for var in bindables if isinstance(bindables, Iterable) else [bindables]:
        var._apply_binding(consumer)


def iter_bindables(value: Any) -> Iterator[BindableMixin]:
    """Collect all directly occurring Bindable instances from any value (shallow: recursively traverses containers but only collects Bindable objects)."""
    if is_bindable(value):
        yield value
    elif isinstance(value, (list, tuple, set)):
        for item in value:
            yield from iter_bindables(item)
    elif isinstance(value, dict):
        for v in value.values():
            yield from iter_bindables(v)


def extract_bindables(value: Any) -> Sequence[BindableMixin]:
    return list(iter_bindables(value))


class BindableMarker:
    def __init__(
        self,
        owner: BindableMixin,
        *,
        deps: Iterable[Any],
    ):
        self._owner = owner
        self._deps = set(chain.from_iterable(iter_bindables(dep) for dep in deps))

    def apply_binding(self, consumer: Consumer) -> None:
        for var in self._deps:
            var._apply_binding(consumer)

    def try_hoist(self, target_scope: Scope) -> None:
        for dep in self._deps:
            dep._try_hoist(target_scope)

    def update_dependencies(self, *args: Any) -> None:
        self._deps.update(chain.from_iterable(iter_bindables(arg) for arg in args))
