from __future__ import annotations

from typing import Any

from instaui.internal.ui._scope import Scope
from instaui.internal.ui.bindable import BindableMarker, BindableMixin
from instaui.internal.ui.consumer import Consumer


class UIMaybeRefExpr(BindableMixin):
    def __init__(self, value: Any) -> None:
        self.value = value

        self._bindable_marker = BindableMarker(self, deps=[value])

    def _try_hoist(self, target_scope: Scope) -> None:
        self._bindable_marker.try_hoist(target_scope)

    def _apply_binding(self, consumer: Consumer):
        self._bindable_marker.apply_binding(consumer)
