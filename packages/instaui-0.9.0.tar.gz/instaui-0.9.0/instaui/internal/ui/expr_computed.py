from typing import Any, Iterable, Mapping, Optional, Type, TypeVar, cast, overload

from instaui.debug.api_boundary import user_api
from instaui.debug.source import get_source_span
from instaui.internal.ui._expr.literal_expr import UILiteralExpr
from instaui.internal.ui._scope import Scope
from instaui.internal.ui.app_context import get_current_scope
from instaui.internal.ui.app_index import new_scope_if_needed
from instaui.internal.ui.bindable import BindableMixin
from instaui.internal.ui.consumer import Consumer
from instaui.internal.ui.enums import InputBindingType
from instaui.internal.ui.path_var import PathVar
from instaui.internal.ui.protocol import ObservableProtocol
from instaui.internal.ui.variable import ConsumerVariableMarker, Variable

_R_TYPE = TypeVar("_R_TYPE")


class ExprComputed(Variable, Consumer, PathVar, BindableMixin, ObservableProtocol):
    def __init__(
        self,
        code: str,
        bindings: Optional[Mapping[str, Any]] = None,
    ) -> None:
        super().__init__()
        self._source_span_ = get_source_span()
        new_scope_if_needed()
        self._define_scope = get_current_scope()
        self._define_scope.add_variable(self)

        self.code = code
        self._bindings = UILiteralExpr.try_parse_dict(bindings) if bindings else None

        self._variable_marker = ConsumerVariableMarker(self, deps=[self._bindings])

    @property
    def _scope(self) -> Scope:
        return self._define_scope

    def _reset_scope(self, scope: Scope) -> None:
        self._define_scope = scope

    @property
    def _used(self) -> bool:
        return self._variable_marker.is_used

    def _to_event_input_type(self) -> InputBindingType:
        return InputBindingType.Ref

    def _get_scope(self) -> Scope:
        return self._define_scope

    def _try_hoist(self, target_scope: Scope) -> None:
        self._variable_marker.try_hoist(target_scope)

    def _apply_binding(self, consumer: Consumer):
        self._variable_marker.apply_binding(consumer)

    def _get_consumers(self) -> Iterable[Consumer]:
        return self._variable_marker.get_consumers()

    @property
    def _force_provide(self) -> bool:
        return self._variable_marker.force_provide

    def _set_force_provide(self, value=True):
        self._variable_marker.set_force_provide(value)


TExprComputed = ExprComputed


@overload
def expr_computed(
    code: str,
    *,
    bindings: Optional[Mapping[str, Any]] = None,
) -> Any: ...


@overload
def expr_computed(
    code: str,
    *,
    bindings: Optional[Mapping[str, Any]] = None,
    r_type: Optional[Type[_R_TYPE]] = None,
) -> _R_TYPE: ...


@user_api
def expr_computed(
    code: str,
    *,
    bindings: Optional[Mapping[str, Any]] = None,
    r_type: Optional[Type[_R_TYPE]] = None,
) -> Any | _R_TYPE:
    """
    A client-side computed property that evaluates JavaScript code to derive reactive values.

    Args:
        code (str): JavaScript code to evaluate.
        bindings (Optional[Mapping[str, Any]], optional): Variables to bind to the code. Defaults to None.
        r_type (Optional[Type[_R_TYPE]], optional): Type hint for the return value. Defaults to None.


    """

    computed = ExprComputed(
        code=code,
        bindings=bindings,
    )

    if r_type is None:
        return computed

    return cast(_R_TYPE, computed)
