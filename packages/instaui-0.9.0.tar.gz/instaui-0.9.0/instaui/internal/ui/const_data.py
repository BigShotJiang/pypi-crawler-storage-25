from __future__ import annotations

from typing import (
    Any,
    Iterable,
    TypeVar,
    cast,
)

from instaui.debug.api_boundary import user_api
from instaui.debug.source import get_source_span
from instaui.internal.ui._expr.literal_expr import UILiteralExpr
from instaui.internal.ui._scope import Scope
from instaui.internal.ui.app_context import get_current_scope
from instaui.internal.ui.app_index import new_scope_if_needed
from instaui.internal.ui.consumer import Consumer
from instaui.internal.ui.enums import InputBindingType, OutputSetType
from instaui.internal.ui.path_var import PathVar
from instaui.internal.ui.protocol import CanInputProtocol, CanOutputProtocol
from instaui.internal.ui.variable import ConsumerVariableMarker, Variable

_T = TypeVar("_T")


class ConstData(Variable, PathVar, Consumer, CanInputProtocol, CanOutputProtocol):
    def __init__(self, value: Any = None) -> None:
        super().__init__()
        self._source_span_ = get_source_span()
        new_scope_if_needed()
        self._define_scope = get_current_scope()
        self._define_scope.add_variable(self)
        self._variable_marker = ConsumerVariableMarker(self, deps=[value])

        self.value = UILiteralExpr.try_parse(value)

    @property
    def _scope(self) -> Scope:
        return self._define_scope

    def _reset_scope(self, scope: Scope) -> None:
        self._define_scope = scope

    @property
    def _used(self) -> bool:
        return self._variable_marker.is_used

    def _to_event_output_type(self) -> OutputSetType:
        raise TypeError("ConstData cannot be used as an output")

    def _to_event_input_type(self) -> InputBindingType:
        return InputBindingType.Data

    def _get_scope(self) -> Scope:
        return self._define_scope

    def _try_hoist(self, target_scope: Scope) -> None:
        self._variable_marker.try_hoist(target_scope)

    def _apply_binding(self, consumer: Consumer):
        self._variable_marker.apply_binding(consumer)

    def _get_consumers(self) -> Iterable[Consumer]:
        return self._variable_marker.get_consumers()

    @property
    def _force_provide(self) -> bool:
        return self._variable_marker.force_provide

    def _set_force_provide(self, value=True):
        self._variable_marker.set_force_provide(value)


TConstData = ConstData


@user_api
def const_data(value: _T) -> _T:
    return cast(_T, ConstData(value))
