from __future__ import annotations

from typing import Any

from instaui.internal.ui._scope import Scope
from instaui.internal.ui.app_context import get_current_container, get_current_scope
from instaui.internal.ui.bindable import try_apply_binding
from instaui.internal.ui.consumer import Consumer
from instaui.internal.ui.renderable import Renderable


class Content(Renderable, Consumer):
    def __init__(self, content: Any):
        """Content to be displayed on the page, typically used for pure text content within slots.

        Args:
            content (Any): The textual content to display.

        Examples:
        .. code-block:: python
            with html.div():
                ui.content("Hello, world!")
        """
        try_apply_binding(content, self)
        self._define_scope = get_current_scope()
        self._content = content
        get_current_container().add_child(self)

    def _get_scope(self) -> Scope:
        return self._define_scope
