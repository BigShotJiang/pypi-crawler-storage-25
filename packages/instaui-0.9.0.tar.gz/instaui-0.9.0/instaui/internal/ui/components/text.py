from __future__ import annotations
from typing import Any, Optional, Literal, Union
from instaui.internal.ui.element import Element


TWeightEnum = Literal["light", "regular", "medium", "bold"]
TAlignEnum = Literal["left", "center", "right"]
TTrimEnum = Literal["normal", "start", "end", "both"]
TTextWrapEnum = Literal["wrap", "nowrap", "pretty", "balance"]


class Text(Element):
    def __init__(
        self,
        text: Optional[Any] = None,
        *,
        as_: Optional[Literal["span", "div", "label", "p", "pre"]] = None,
        weight: Optional[Union[TWeightEnum, str]] = None,
        align: Optional[Union[TAlignEnum, str]] = None,
        trim: Optional[Union[TTrimEnum, str]] = None,
        truncate: Optional[bool] = None,
        text_wrap: Optional[Union[TTextWrapEnum, str]] = None,
    ):
        """
        Creates a text element with customizable styling and typography options.

        Args:
            text (Optional[Any]]: The text content to display.
            as_ (Optional[Literal["span", "div", "label", "p", "pre"]]]):
                HTML element type to render as. Defaults to appropriate semantic element.
            weight (Optional[TMaybeResponsive[Union[TWeightEnum, str]]): Font weight.
            align (Optional[TMaybeResponsive[Union[TAlignEnum, str]]): Text alignment.
            trim (Optional[Union[TTrimEnum, str]]): Whitespace trimming behavior.
            truncate (Optional[bool]): Whether to truncate overflowing text.
            text_wrap (Optional[Union[TTextWrapEnum, str]]): Text wrapping behavior.

        Example:
        .. code-block:: python
            # Basic text element
            ui.text("ui.text")

            # Text with specific HTML element and styling
            ui.text(
                "Styled text",
                as_="div",
                weight="bold",
                align="center"
            )
        """
        super().__init__("ui-text")

        self.props(
            {
                "innerText": text,
                "as_": as_,
                "weight": weight,
                "align": align,
                "trim": trim,
                "truncate": truncate,
                "text_wrap": text_wrap,
            }
        )
