from __future__ import annotations

from typing import TYPE_CHECKING, Iterable

from instaui.internal.ui.app_context import get_app

from .container import Container, ScopeGuard
from .renderable import Renderable

if TYPE_CHECKING:
    from instaui.internal.ui.expr_watch import ExprWatch
    from instaui.internal.ui.js_watch import JsWatch
    from instaui.internal.ui.web_watch import WebWatch

    from .variable import Variable


class Scope(Container, Renderable):
    def __init__(self, parent: Scope | None = None) -> None:
        super().__init__()

        self._id = get_app().next_scope_id()
        self._parent = parent

        self._web_watchs: list[WebWatch] = []
        self._js_watchs: list[JsWatch] = []
        self._expr_watchs: list[ExprWatch] = []

        self._variables: dict[int, Variable] = {}
        self._renderables: list[Renderable] = []
        self._scope_guard = ScopeGuard()
        self._injects: set[Variable] = set()
        self._provides: set[Variable] = set()

    @property
    def id(self) -> int:
        return self._id

    def __enter__(self):
        app = get_app()
        app.push_scope(self)
        return super().__enter__()

    def __exit__(self, *_):
        get_app().pop_scope()
        return super().__exit__(*_)

    def is_descendant_of(self, ancestor: Scope) -> bool:
        """Check if the current scope is a strict descendant of the given ancestor scope."""
        cur = self._parent
        while cur is not None:
            if cur is ancestor:
                return True
            cur = cur._parent
        return False

    def iter_variables(self) -> Iterable[Variable]:
        return self._variables.values()

    def add_variable(self, variable: Variable):
        self._variables[id(variable)] = variable

    def transfer_variable(self, var: Variable) -> None:
        """Transfer a variable from its original scope to the current scope."""
        if var._scope is self:
            return

        var._scope._variables.pop(id(var))
        var._reset_scope(self)
        self.add_variable(var)

    def get_defined_variables(self) -> list[Variable]:
        """Return variables that need to be defined in code (definable=True)."""
        return [v for v in self._variables.values() if v._definable and v._used]

    def get_used_variables(self):
        """Return variables that are used in the current scope."""
        return [v for v in self._variables.values() if v._used]

    def all_variables(self) -> Iterable[Variable]:
        return self._variables.values()

    def register_web_watch(self, web_watch: WebWatch):
        self._web_watchs.append(web_watch)

    def register_js_watch(self, js_watch: JsWatch):
        self._js_watchs.append(js_watch)

    def register_expr_watch(self, vue_watch: ExprWatch):
        self._expr_watchs.append(vue_watch)

    def add_child(self, renderable: Renderable):
        self._renderables.append(renderable)

    def _bind_scope(self, scope: Scope):
        self._scope_guard.bind_scope(scope)

    def _release_scope(self):
        self._scope_guard.release_scope()
