from typing import Any

from instaui.internal.ui._scope import Scope
from instaui.internal.ui.bindable import BindableMarker, BindableMixin
from instaui.internal.ui.consumer import Consumer
from instaui.internal.ui.variable import Variable, force_provide, is_variable


class VariableReferenceName(BindableMixin):
    def __init__(self, variable: Variable):
        self.variable = variable
        self._bindable_marker = BindableMarker(self, deps=[self.variable])

    def _try_hoist(self, target_scope: Scope) -> None:
        self._bindable_marker.try_hoist(target_scope)

    def _apply_binding(self, consumer: Consumer):
        force_provide(self.variable)
        self._bindable_marker.apply_binding(consumer)


def convert_reference(binding: Any):
    """
    Allows reactive variable configurations to be passed into custom components, enabling them to obtain their Ref references.

    Args:
        binding (Any): The reactive binding or variable to be converted

    Examples:
    .. code-block:: python

        class CustomElement(custom.element, esm="./custom_element.js"):
            def __init__(self, ref):
                super().__init__()
                self.props({"ref_binding": custom.convert_reference(ref)})
    """
    assert is_variable(binding), "binding should be a Variable"
    return VariableReferenceName(binding)
