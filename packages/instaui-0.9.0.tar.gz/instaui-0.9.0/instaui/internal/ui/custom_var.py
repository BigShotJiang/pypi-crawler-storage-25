from __future__ import annotations

from typing import Any, Iterable, Optional

from instaui.debug.source import get_source_span
from instaui.internal.ui._expr.literal_expr import UILiteralExpr
from instaui.internal.ui._expr.maybe_ref_expr import UIMaybeRefExpr
from instaui.internal.ui._scope import Scope
from instaui.internal.ui.app_context import get_current_scope
from instaui.internal.ui.app_index import new_scope_if_needed
from instaui.internal.ui.bindable import BindableMixin
from instaui.internal.ui.consumer import Consumer
from instaui.internal.ui.enums import InputBindingType, OutputSetType
from instaui.internal.ui.path_var import PathVar
from instaui.internal.ui.protocol import CanOutputProtocol, ObservableProtocol
from instaui.internal.ui.variable import ConsumerVariableMarker, Variable
from instaui.protocol.ui.state import StateReadable
from instaui.systems.dataclass_system import dataclass


@dataclass(frozen=True)
class CustomRefMethod:
    module_name: str
    method_name: str


class CustomVar(
    PathVar,
    Variable,
    Consumer,
    ObservableProtocol,
    CanOutputProtocol,
    BindableMixin,
):
    def __init__(
        self,
        module: str,
        method: str,
        *,
        args: Optional[Any] = None,
        deep_compare: bool = False,
    ) -> None:
        super().__init__()
        self._source_span_ = get_source_span()
        new_scope_if_needed()
        self._define_scope = get_current_scope()
        self._define_scope.add_variable(self)
        self._variable_marker = ConsumerVariableMarker(self, deps=[args])

        self._method = CustomRefMethod(module, method)
        self._deep_compare = deep_compare
        self._args = _build_args(args)

    def __deepcopy__(self, memo):
        memo[id(self)] = self
        return self

    def _to_event_input_type(self) -> InputBindingType:
        return InputBindingType.Ref

    def _to_event_output_type(self) -> OutputSetType:
        return OutputSetType.Ref

    @staticmethod
    def maybe_ref(value: Any):
        return UIMaybeRefExpr(value)

    @staticmethod
    def literal(value: Any):
        return UILiteralExpr(value)

    @property
    def _scope(self) -> Scope:
        return self._define_scope

    def _reset_scope(self, scope: Scope) -> None:
        self._define_scope = scope

    @property
    def _used(self) -> bool:
        return self._variable_marker.is_used

    def _get_scope(self) -> Scope:
        return self._define_scope

    def _try_hoist(self, target_scope: Scope) -> None:
        self._variable_marker.try_hoist(target_scope)

    def _apply_binding(self, consumer: Consumer):
        self._variable_marker.apply_binding(consumer)

    def _get_consumers(self) -> Iterable[Consumer]:
        return self._variable_marker.get_consumers()

    @property
    def _force_provide(self) -> bool:
        return self._variable_marker.force_provide

    def _set_force_provide(self, value=True):
        self._variable_marker.set_force_provide(value)


class StateReadableCustomVar(CustomVar, StateReadable):
    pass


def _build_args(args):
    match args:
        case tuple():
            return tuple(UILiteralExpr.try_parse(arg) for arg in args)

        case list():
            return UILiteralExpr.try_parse_list(args)

        case dict():
            return UILiteralExpr.try_parse_dict(args)
        case None:
            return None
        case _:
            return UILiteralExpr.try_parse(args)
