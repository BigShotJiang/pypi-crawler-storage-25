from typing import Callable

from instaui.internal.ui._scope import Scope
from instaui.internal.ui.bindable import BindableMixin
from instaui.internal.ui.consumer import Consumer


class UploadEndpoint(BindableMixin):
    def __init__(self, handler: Callable) -> None:
        self.handler = handler

    def _try_hoist(self, target_scope: Scope) -> None:
        pass

    def _apply_binding(self, consumer: Consumer):
        pass
