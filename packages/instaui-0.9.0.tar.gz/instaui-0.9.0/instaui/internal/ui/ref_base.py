from typing import Any, Iterable, Optional

from instaui.debug.source import get_source_span
from instaui.internal.ui._expr.codec_expr import DataCodecExpr
from instaui.internal.ui._scope import Scope
from instaui.internal.ui.consumer import Consumer
from instaui.internal.ui.protocol import CanOutputProtocol, ObservableProtocol

from .app_context import get_current_scope
from .app_index import new_scope_if_needed
from .enums import InputBindingType, OutputSetType
from .missing import MISSING
from .path_var import PathVar
from .variable import ConsumerVariableMarker, Variable


class RefBase(PathVar, Consumer, Variable, ObservableProtocol, CanOutputProtocol):
    def __init__(
        self,
        *,
        value: Optional[Any] = MISSING,
        deep_compare: bool = False,
    ) -> None:
        super().__init__()
        self._source_span_ = get_source_span()
        new_scope_if_needed()
        self._define_scope = get_current_scope()
        self._define_scope.add_variable(self)
        self._variable_marker = ConsumerVariableMarker(self, deps=[value])

        self._org_value = value.value if isinstance(value, DataCodecExpr) else value
        self._value = value
        self._deep_compare = deep_compare

    def initial(self) -> Any:
        return self._org_value

    def __deepcopy__(self, memo):
        memo[id(self)] = self
        return self

    def _to_event_input_type(self) -> InputBindingType:
        return InputBindingType.Ref

    def _to_event_output_type(self) -> OutputSetType:
        return OutputSetType.Ref

    @property
    def _scope(self) -> Scope:
        return self._define_scope

    def _reset_scope(self, scope: Scope) -> None:
        self._define_scope = scope

    def _try_hoist(self, target_scope: Scope) -> None:
        self._variable_marker.try_hoist(target_scope)

    def _apply_binding(self, consumer: Consumer):
        self._variable_marker.apply_binding(consumer)

    @property
    def _used(self) -> bool:
        return self._variable_marker.is_used

    def _get_consumers(self) -> Iterable[Consumer]:
        return self._variable_marker.get_consumers()

    def _get_scope(self) -> Scope:
        return self._define_scope

    @property
    def _force_provide(self) -> bool:
        return self._variable_marker.force_provide

    def _set_force_provide(self, value=True):
        self._variable_marker.set_force_provide(value)
