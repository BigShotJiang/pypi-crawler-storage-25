from typing import TypeVar, cast

from instaui.internal.ui._scope import Scope
from instaui.internal.ui.bindable import BindableMarker, BindableMixin
from instaui.internal.ui.consumer import Consumer

_TOutput = TypeVar("_TOutput")


class ToValue(BindableMixin):
    def __init__(self, value) -> None:
        self._bindable_marker = BindableMarker(self, deps=[value])
        self.value = value

    def _try_hoist(self, target_scope: Scope) -> None:
        self._bindable_marker.try_hoist(target_scope)

    def _apply_binding(self, consumer: Consumer):
        self._bindable_marker.apply_binding(consumer)


def to_value(value: _TOutput) -> _TOutput:
    """
    Converts a reactive state or computed value to a static value.

    Args:
        value (_TOutput): A reactive state or computed value to be converted to its static equivalent.

    Example:
    .. code-block:: python
        org = ui.state("foo")

        # The initial value is "foo", but it will not sync with org.
        other = ui.state(ui.to_value(org))
    """
    return cast(_TOutput, ToValue(value))
