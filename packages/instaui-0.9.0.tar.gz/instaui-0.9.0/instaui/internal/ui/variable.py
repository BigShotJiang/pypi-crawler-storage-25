from __future__ import annotations

from abc import abstractmethod
from itertools import chain
from typing import TYPE_CHECKING, Any, Callable, Iterable, cast

from typing_extensions import TypeIs

from instaui.internal.ui._scope import Scope
from instaui.internal.ui.bindable import (
    BindableMixin,
    iter_bindables,
)
from instaui.internal.ui.consumer import Consumer
from instaui.internal.ui.exception import HoistingError

if TYPE_CHECKING:
    from instaui.internal.ui._scope import Scope


class Variable(BindableMixin):
    @property
    @abstractmethod
    def _force_provide(self) -> bool: ...

    @abstractmethod
    def _set_force_provide(self, value=True): ...

    @property
    @abstractmethod
    def _used(self) -> bool: ...

    @property
    @abstractmethod
    def _scope(self) -> Scope: ...

    @abstractmethod
    def _reset_scope(self, scope: Scope) -> None: ...

    @property
    def _providable(self) -> bool:
        """Indicates whether this variable can be provided. Default: True."""
        return True

    @property
    def _hoistable(self) -> bool:
        """Indicates whether this variable can be hoisted. Default: True."""
        return True

    @property
    def _definable(self) -> bool:
        """Indicates whether this variable can be defined. Default: True."""
        return True

    def __deepcopy__(self, memo):
        memo[id(self)] = self
        return self

    @abstractmethod
    def _get_consumers(self) -> Iterable[Consumer]: ...

    @abstractmethod
    def _apply_binding(self, consumer: Consumer): ...

    @abstractmethod
    def _try_hoist(self, target_scope: Scope) -> None: ...


def is_variable(obj: Any) -> TypeIs[Variable]:
    return isinstance(obj, Variable)


def force_provide(obj: Variable) -> Variable:
    obj._set_force_provide()
    return obj


class VariableMarker:
    def __init__(
        self,
        owner: Variable,
        scope_register_fn: Callable[[Any], None] | None = None,
    ):
        self._owner = owner
        self._used = False
        self.__force_provide = False
        self._consumers: set[Consumer] = set()
        self._scope_register_fn = scope_register_fn

    @property
    def force_provide(self) -> bool:
        return self.__force_provide

    def set_force_provide(self, value=True):
        assert self._owner._providable, "Cannot force provide a non-providable variable"
        self.__force_provide = value

    @property
    def is_used(self) -> bool:
        return self._used

    def apply_binding(self, consumer: Consumer) -> None:
        self._consumers.add(consumer)
        if not self._used:
            if self._scope_register_fn is not None:
                try:
                    self._scope_register_fn(self._owner)
                except Exception:
                    raise
        self._used = True

    def try_hoist(self, target_scope: Scope) -> None:
        owner = self._owner

        if owner._scope is not None and owner._scope.is_descendant_of(target_scope):
            if not owner._hoistable:
                raise HoistingError(
                    f"Variable is not hoistable (type {type(owner).__name__})"
                )

            target_scope.transfer_variable(owner)

    def get_consumers(self) -> Iterable[Consumer]:
        return self._consumers


class ConsumerVariableMarker(VariableMarker):
    def __init__(
        self,
        owner: Consumer | Variable,
        scope_register_fn: Callable[[Any], None] | None = None,
        *,
        deps: Iterable[Any],
    ):
        super().__init__(cast(Variable, owner), scope_register_fn)

        self._deps = set(chain.from_iterable(iter_bindables(dep) for dep in deps))

    def update_dependencies(self, *args: Any) -> None:
        self._deps.update(chain.from_iterable(iter_bindables(arg) for arg in args))

    def apply_dependency_binding(self) -> None:
        for dep in self._deps:
            dep._apply_binding(cast(Consumer, self._owner))

    def apply_binding(self, consumer: Consumer) -> None:
        super().apply_binding(consumer)

        self.apply_dependency_binding()

    def try_hoist(self, target_scope: Scope) -> None:
        for dep in self._deps:
            dep._try_hoist(target_scope)
        super().try_hoist(target_scope)
