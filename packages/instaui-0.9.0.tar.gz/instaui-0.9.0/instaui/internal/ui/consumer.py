from typing import Protocol

from instaui.internal.ui._scope import Scope


class Consumer(Protocol):
    def _get_scope(self) -> Scope: ...
