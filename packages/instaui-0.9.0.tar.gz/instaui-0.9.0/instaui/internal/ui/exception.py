class HoistingError(Exception):
    pass
