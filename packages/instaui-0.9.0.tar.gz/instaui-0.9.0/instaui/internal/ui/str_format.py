from typing import cast

from instaui.internal.ui._expr.literal_expr import UILiteralExpr
from instaui.internal.ui._scope import Scope
from instaui.internal.ui.app_context import get_current_scope
from instaui.internal.ui.bindable import BindableMarker, BindableMixin
from instaui.internal.ui.consumer import Consumer
from instaui.internal.ui.path_var import PathVar


class StrFormat(BindableMixin, PathVar):
    def __init__(self, template: str, *args, **kwargs) -> None:
        self._define_scope = get_current_scope()

        self._bindable_marker = BindableMarker(self, deps=[template, args, kwargs])

        self.template = UILiteralExpr.try_parse(template)
        self.args = list(UILiteralExpr.try_parse(arg) for arg in args)
        self.kwargs = {
            key: UILiteralExpr.try_parse(value) for key, value in kwargs.items()
        }

    def _try_hoist(self, target_scope: Scope) -> None:
        self._bindable_marker.try_hoist(target_scope)

    def _apply_binding(self, consumer: Consumer):
        self._bindable_marker.apply_binding(consumer)


def str_format(template: str, *args, **kwargs) -> str:
    """
    Formats a string template with positional and keyword arguments.

    Args:
        template (str): The string template containing {} placeholders for formatting.
        *args: Variable length positional arguments for positional formatting.
        **kwargs: Arbitrary keyword arguments for named formatting.

    Example:
    .. code-block:: python
        # Positional formatting
        ui.str_format("pos:a={},b={}", a, b)

        # Index-based positional formatting
        ui.str_format("num pos:a={0},b={1}", a, b)

        # Named formatting
        ui.str_format("name pos:b={b},a={a}", a=a, b=b)
    """
    return cast(str, StrFormat(template, *args, **kwargs))
