from typing import Any

from instaui.internal.ui._scope import Scope
from instaui.internal.ui.app_context import get_current_container, get_current_scope
from instaui.internal.ui.bindable import try_apply_binding
from instaui.internal.ui.consumer import Consumer
from instaui.internal.ui.container import Container
from instaui.internal.ui.renderable import Renderable


class VIf(Renderable, Container, Consumer):
    def __init__(self, on: bool | int | str | Any):
        """
        A conditional container that renders its children only when the given condition is True.

        Args:
            on (bool | int | str): A boolean or reactive reference that determines whether the container's
                                child elements should be displayed. If True, children are rendered;
                                if False, children are hidden.


        Example:
        .. code-block:: python
            from instaui import ui, html

            value = ui.state(False)

            html.button("toggle").on_click(
                ui.js_event(inputs=[value], outputs=[value], code="(v)=> !v")
            )

            with ui.vif(value):
                ui.text("show")
        """

        super().__init__()
        get_current_container().add_child(self)

        try_apply_binding(on, self)
        self._on = on
        self._renderables: list[Renderable] = []
        self._define_scope = get_current_scope()

    def add_child(self, renderable: Renderable):
        self._renderables.append(renderable)

    def _get_scope(self) -> Scope:
        return self._define_scope
