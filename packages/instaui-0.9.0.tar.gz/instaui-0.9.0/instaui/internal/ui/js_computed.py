from __future__ import annotations

import typing

from instaui.debug.api_boundary import user_api
from instaui.debug.source import get_source_span
from instaui.internal.ui._expr.literal_expr import UILiteralExpr
from instaui.internal.ui._scope import Scope
from instaui.internal.ui.app_context import get_current_scope
from instaui.internal.ui.app_index import new_scope_if_needed
from instaui.internal.ui.consumer import Consumer
from instaui.internal.ui.enums import InputBindingType
from instaui.internal.ui.path_var import PathVar
from instaui.internal.ui.protocol import ObservableProtocol
from instaui.internal.ui.variable import ConsumerVariableMarker, Variable

_R_TYPE = typing.TypeVar("_R_TYPE")


class JsComputed(Variable, PathVar, ObservableProtocol, Consumer):
    def __init__(
        self,
        *,
        inputs: typing.Optional[typing.Sequence] = None,
        code: str,
        async_init_value: typing.Optional[typing.Any] = None,
        deep_compare_on_input: bool = False,
        tool: typing.Optional[typing.Literal["unwrap_reactive"]] = None,
    ) -> None:
        super().__init__()
        self._source_span_ = get_source_span()
        new_scope_if_needed()
        self._define_scope = get_current_scope()
        self._define_scope.add_variable(self)

        self.code = code
        self._inputs = UILiteralExpr.try_parse_list(inputs or [])

        self._async_init_value = UILiteralExpr.try_parse(async_init_value)
        self._deep_compare_on_input = deep_compare_on_input
        self._tool = tool

        self._variable_marker = ConsumerVariableMarker(self, deps=[self._inputs])

    @property
    def _scope(self) -> Scope:
        return self._define_scope

    def _reset_scope(self, scope: Scope) -> None:
        self._define_scope = scope

    def _to_event_input_type(self) -> InputBindingType:
        return InputBindingType.Ref

    def _get_scope(self) -> Scope:
        return self._define_scope

    def _try_hoist(self, target_scope: Scope) -> None:
        self._variable_marker.try_hoist(target_scope)

    def _apply_binding(self, consumer: Consumer):
        self._variable_marker.apply_binding(consumer)

    @property
    def _used(self) -> bool:
        return self._variable_marker.is_used

    def _get_consumers(self) -> typing.Iterable[Consumer]:
        return self._variable_marker.get_consumers()

    @property
    def _force_provide(self) -> bool:
        return self._variable_marker.force_provide

    def _set_force_provide(self, value=True):
        self._variable_marker.set_force_provide(value)


TJsComputed = JsComputed


@typing.overload
def js_computed(
    *,
    inputs: typing.Optional[typing.Sequence] = None,
    code: str,
    async_init_value: typing.Optional[typing.Any] = None,
    deep_compare_on_input: bool = False,
) -> typing.Any: ...


@typing.overload
def js_computed(
    *,
    inputs: typing.Optional[typing.Sequence] = None,
    code: str,
    async_init_value: typing.Optional[typing.Any] = None,
    deep_compare_on_input: bool = False,
    r_type: typing.Optional[typing.Type[_R_TYPE]] = None,
) -> _R_TYPE: ...


@user_api
def js_computed(
    *,
    inputs: typing.Optional[typing.Sequence] = None,
    code: str,
    async_init_value: typing.Optional[typing.Any] = None,
    deep_compare_on_input: bool = False,
    r_type: typing.Optional[typing.Type[_R_TYPE]] = None,
) -> typing.Union[JsComputed, _R_TYPE]:
    """
    A client-side computed property that evaluates JavaScript code to derive reactive values.

    Args:
        inputs (typing.Optional[typing.Sequence], optional): Reactive data sources to monitor.
                                                  Changes to these values trigger re-computation.
        code (str): JavaScript code to execute for computing the value.
        async_init_value (typing.Optional[typing.Any], optional): Initial value to use before first successful async evaluation.

    # Example:
    .. code-block:: python
        a = ui.state(0)

        plus_one = ui.js_computed(inputs=[a], code="a=> a+1")

        html.number(a)
        ui.text(plus_one)
    """

    jc = JsComputed(
        inputs=inputs,
        code=code,
        async_init_value=async_init_value,
        deep_compare_on_input=deep_compare_on_input,
    )

    if r_type is None:
        return jc

    return typing.cast(_R_TYPE, jc)
