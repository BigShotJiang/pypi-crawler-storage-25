from typing import Iterable

from instaui.internal.ui._scope import Scope
from instaui.internal.ui.app_context import get_current_scope
from instaui.internal.ui.consumer import Consumer
from instaui.internal.ui.enums import InputBindingType
from instaui.internal.ui.path_var import PathVar
from instaui.internal.ui.protocol import ObservableProtocol
from instaui.internal.ui.variable import Variable, VariableMarker


class SlotProp(PathVar, Variable, ObservableProtocol):
    def __init__(self) -> None:
        super().__init__()
        self._define_scope = get_current_scope()
        self._define_scope.add_variable(self)
        self._variable_marker = VariableMarker(self)

    def get(self, name: str):
        return self[name]

    def _to_event_input_type(self) -> InputBindingType:
        return InputBindingType.Ref

    @property
    def _providable(self) -> bool:
        return False

    @property
    def _definable(self) -> bool:
        return False

    @property
    def _hoistable(self) -> bool:
        return False

    @property
    def _scope(self) -> Scope:
        return self._define_scope

    def _reset_scope(self, scope: Scope) -> None:
        self._define_scope = scope

    @property
    def _used(self) -> bool:
        return self._variable_marker.is_used

    def _try_hoist(self, target_scope: Scope) -> None:
        self._variable_marker.try_hoist(target_scope)

    def _apply_binding(self, consumer: Consumer):
        self._variable_marker.apply_binding(consumer)

    def _get_consumers(self) -> Iterable[Consumer]:
        return self._variable_marker.get_consumers()

    @property
    def _force_provide(self) -> bool:
        return self._variable_marker.force_provide

    def _set_force_provide(self, value=True):
        self._variable_marker.set_force_provide(value)
