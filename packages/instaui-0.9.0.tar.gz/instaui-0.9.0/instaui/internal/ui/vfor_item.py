from typing import Generic, Iterable, TypeVar

from instaui.internal.ui._scope import Scope
from instaui.internal.ui.app_context import get_current_scope
from instaui.internal.ui.consumer import Consumer
from instaui.internal.ui.enums import InputBindingType, OutputSetType
from instaui.internal.ui.path_var import PathVar
from instaui.internal.ui.protocol import (
    CanOutputProtocol,
    ObservableProtocol,
)
from instaui.internal.ui.variable import Variable, VariableMarker

_T = TypeVar("_T")


class VForItem(
    Variable,
    PathVar,
    CanOutputProtocol,
    ObservableProtocol,
    Generic[_T],
):
    def __init__(self):
        super().__init__()
        self._define_scope = get_current_scope()
        self._define_scope.add_variable(self)
        self._variable_marker = VariableMarker(self)

    def __getattr__(self, name: str):
        return self[name]

    def _to_event_output_type(self) -> OutputSetType:
        return OutputSetType.Ref

    def _to_event_input_type(self) -> InputBindingType:
        return InputBindingType.Ref

    @property
    def _providable(self) -> bool:
        return False

    @property
    def _definable(self) -> bool:
        return False

    @property
    def _hoistable(self) -> bool:
        return False

    @property
    def _used(self) -> bool:
        return self._variable_marker.is_used

    @property
    def _scope(self) -> Scope:
        return self._define_scope

    def _reset_scope(self, scope: Scope) -> None:
        self._define_scope = scope

    def _try_hoist(self, target_scope: Scope) -> None:
        self._variable_marker.try_hoist(target_scope)

    def _apply_binding(self, consumer: Consumer):
        self._variable_marker.apply_binding(consumer)

    def _get_consumers(self) -> Iterable[Consumer]:
        return self._variable_marker.get_consumers()

    @property
    def _force_provide(self) -> bool:
        return self._variable_marker.force_provide

    def _set_force_provide(self, value=True):
        self._variable_marker.set_force_provide(value)


class VForIndex(Variable, PathVar, ObservableProtocol):
    def __init__(self):
        super().__init__()
        self._define_scope = get_current_scope()
        self._define_scope.add_variable(self)
        self._variable_marker = VariableMarker(self)

    @property
    def _used(self) -> bool:
        return self._variable_marker.is_used

    @property
    def _scope(self) -> Scope:
        return self._define_scope

    def _reset_scope(self, scope: Scope) -> None:
        self._define_scope = scope

    def _to_event_input_type(self) -> InputBindingType:
        return InputBindingType.Ref

    @property
    def _providable(self) -> bool:
        return False

    @property
    def _definable(self) -> bool:
        return False

    @property
    def _hoistable(self) -> bool:
        return False

    def _try_hoist(self, target_scope: Scope) -> None:
        self._variable_marker.try_hoist(target_scope)

    def _apply_binding(self, consumer: Consumer):
        self._variable_marker.apply_binding(consumer)

    def _get_consumers(self) -> Iterable[Consumer]:
        return self._variable_marker.get_consumers()

    @property
    def _force_provide(self) -> bool:
        return self._variable_marker.force_provide

    def _set_force_provide(self, value=True):
        self._variable_marker.set_force_provide(value)


class VForItemKey(Variable, PathVar, ObservableProtocol):
    def __init__(self):
        super().__init__()
        self._define_scope = get_current_scope()
        self._define_scope.add_variable(self)
        self._variable_marker = VariableMarker(self)

    @property
    def _used(self) -> bool:
        return self._variable_marker.is_used

    @property
    def _scope(self) -> Scope:
        return self._define_scope

    def _reset_scope(self, scope: Scope) -> None:
        self._define_scope = scope

    def _to_event_input_type(self) -> InputBindingType:
        return InputBindingType.Ref

    @property
    def _providable(self) -> bool:
        return False

    @property
    def _definable(self) -> bool:
        return False

    @property
    def _hoistable(self) -> bool:
        return False

    def _try_hoist(self, target_scope: Scope) -> None:
        self._variable_marker.try_hoist(target_scope)

    def _apply_binding(self, consumer: Consumer):
        self._variable_marker.apply_binding(consumer)

    def _get_consumers(self) -> Iterable[Consumer]:
        return self._variable_marker.get_consumers()

    @property
    def _force_provide(self) -> bool:
        return self._variable_marker.force_provide

    def _set_force_provide(self, value=True):
        self._variable_marker.set_force_provide(value)


TVForItem = VForItem
TVForIndex = VForIndex
