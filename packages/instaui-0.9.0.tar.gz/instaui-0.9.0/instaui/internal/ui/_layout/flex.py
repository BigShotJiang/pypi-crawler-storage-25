from __future__ import annotations
from typing import Literal, cast
from instaui.internal.ui.element import Element


TDirection = Literal["row", "column", "row-reverse", "column-reverse"]
TAs = Literal["div", "span"]
TDisplay = Literal["none", "inline-flex", "flex"]
TAlign = Literal["start", "center", "end", "stretch", "baseline"]
TJustify = Literal["start", "center", "end", "between"]
TWrap = Literal["nowrap", "wrap", "wrap-reverse"]
TGap = str
TGapX = str
TGapY = str


class Flex(Element):
    def __init__(
        self,
        *,
        direction: TDirection | None = None,
        as_: TAs | None = None,
        display: TDisplay | None = None,
        align: TAlign | None = None,
        justify: TJustify | None = None,
        wrap: TWrap | None = None,
        gap: TGap | None = None,
        gap_x: TGapX | None = None,
        gap_y: TGapY | None = None,
    ):
        """
        Creates a flex container with configurable layout and alignment.

        Args:
            **kwargs: Flex container properties
                - as_ (Literal["div", "span"]): HTML tag type for the container, defaults to "div"
                - display (Literal["none", "inline-flex", "flex"]): Display type of the container, defaults to "flex"
                - align (Literal["start", "center", "end", "stretch", "baseline"]): Cross-axis alignment
                    - "start": Align items at the start of the cross axis
                    - "center": Center items along the cross axis
                    - "end": Align items at the end of the cross axis
                    - "stretch": Stretch items to fill the container
                    - "baseline": Align items along their baselines
                - justify (Literal["start", "center", "end", "between"]): Main-axis alignment
                    - "start": Align items at the start of the main axis
                    - "center": Center items along the main axis
                    - "end": Align items at the end of the main axis
                    - "between": Distribute items evenly with space between them
                - wrap (Literal["nowrap", "wrap", "wrap-reverse"]): Wrap behavior for items
                    - "nowrap": All items on one line
                    - "wrap": Wrap items onto multiple lines
                    - "wrap-reverse": Wrap items onto multiple lines in reverse order
                - gap (str): Gap between all items (applies to both axes)
                - gap_x (str): Horizontal gap between items


        Example:
        .. code-block:: python
            # Basic flex container
            with ui.flex():
                ui.text("Item 1")
                ui.text("Item 2")

            # Row flex container
            with ui.row():
                ui.text("Horizontal items")

            # Column flex container
            with ui.column():
                ui.text("Vertical items")

            # Flex with gap and alignment
            with ui.flex(align="center", justify="between"):
                ui.text("Left")
                ui.text("Center")
                ui.text("Right")
        """
        super().__init__(as_ or "div")
        self.classes("insta-Flex")
        self.style(
            {
                key: value
                for key, value in {
                    "flex-direction": direction,
                    "display": display,
                    "align-items": align,
                    "justify-content": justify,
                    "flex-wrap": wrap,
                    "gap": gap,
                    "column-gap": gap_x,
                    "row-gap": gap_y,
                }.items()
                if value is not None
            }
        )


class FlexRow(Flex):
    def __init__(
        self,
        *,
        as_: TAs | None = None,
        display: TDisplay | None = None,
        align: TAlign | None = None,
        justify: TJustify | None = None,
        wrap: TWrap | None = None,
        gap: TGap | None = None,
        gap_x: TGapX | None = None,
        gap_y: TGapY | None = None,
    ):
        """
        Creates a horizontal flex container with row direction.

        Args:
            **kwargs (Unpack[TFlexBaseProps]): Flex container properties including:
                align (TMaybeResponsive[Literal["start", "center", "end", "stretch", "baseline"]]):
                    Vertical alignment of flex items.
                justify (TMaybeResponsive[Literal["start", "center", "end", "between"]]):
                    Horizontal alignment of flex items.
                wrap (TMaybeResponsive[Literal["nowrap", "wrap", "wrap-reverse"]]):
                    Flex wrapping behavior.
                gap (TMaybeResponsive[Union[str, TLevel_0_9]]): Gap between flex items.
                gap_x (TMaybeResponsive[Union[str, TLevel_0_9]]): Horizontal gap between items.
                gap_y (TMaybeResponsive[Union[str, TLevel_0_9]]): Vertical gap between items.
                display (TMaybeResponsive[Literal["none", "inline-flex", "flex"]]): Display type.
                as_ (TMaybeRef[Literal["div", "span"]]): HTML element type.

        Example:
        .. code-block:: python
            # Basic horizontal flex container
            with ui.row():
                ui.text("Item 1")
                ui.text("Item 2")

            # Row with gap and alignment
            with ui.row(align="center", justify="between"):
                ui.text("Left")
                ui.text("Center")
                ui.text("Right")
        """

        super().__init__(
            direction="row",
            **cast(
                dict,
                {
                    "as_": as_,
                    "display": display,
                    "align": align,
                    "justify": justify,
                    "wrap": wrap,
                    "gap": gap,
                    "gap_x": gap_x,
                    "gap_y": gap_y,
                },
            ),
        )


class FlexColumn(Flex):
    def __init__(
        self,
        *,
        as_: TAs | None = None,
        display: TDisplay | None = None,
        align: TAlign | None = None,
        justify: TJustify | None = None,
        wrap: TWrap | None = None,
        gap: TGap | None = None,
        gap_x: TGapX | None = None,
        gap_y: TGapY | None = None,
    ):
        """
        Creates a vertical flex container with column direction.

        Args:
            **kwargs (Unpack[TFlexBaseProps]): Flex container properties including:
                align (TMaybeResponsive[Literal["start", "center", "end", "stretch", "baseline"]]):
                    Horizontal alignment of flex items.
                justify (TMaybeResponsive[Literal["start", "center", "end", "between"]]):
                    Vertical alignment of flex items.
                wrap (TMaybeResponsive[Literal["nowrap", "wrap", "wrap-reverse"]]):
                    Flex wrapping behavior.
                gap (TMaybeResponsive[Union[str, TLevel_0_9]]): Gap between flex items.
                gap_x (TMaybeResponsive[Union[str, TLevel_0_9]]): Horizontal gap between items.
                gap_y (TMaybeResponsive[Union[str, TLevel_0_9]]): Vertical gap between items.
                display (TMaybeResponsive[Literal["none", "inline-flex", "flex"]]): Display type.
                as_ (TMaybeRef[Literal["div", "span"]]): HTML element type.

        Example:
        .. code-block:: python
            # Basic vertical flex container
            with ui.column():
                ui.text("Item 1")
                ui.text("Item 2")

            # Column with gap and alignment
            with ui.column(align="center", justify="between"):
                ui.text("Top")
                ui.text("Middle")
                ui.text("Bottom")
        """
        super().__init__(
            direction="column",
            **cast(
                dict,
                {
                    "as_": as_,
                    "display": display,
                    "align": align,
                    "justify": justify,
                    "wrap": wrap,
                    "gap": gap,
                    "gap_x": gap_x,
                    "gap_y": gap_y,
                },
            ),
        )
