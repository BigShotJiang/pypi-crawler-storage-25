from __future__ import annotations
from typing import Literal
from instaui.internal.ui.js_computed import js_computed
from instaui.internal.ui.element import Element


class Grid(Element):
    def __init__(
        self,
        *,
        as_: Literal["div", "span"] | None = None,
        display: Literal["none", "inline-grid", "grid"] | None = None,
        areas: str | None = None,
        columns: int | str | None = None,
        rows: int | str | None = None,
        flow: Literal["row", "column", "row dense", "column dense", "dense"]
        | None = None,
        align: Literal["start", "center", "end", "baseline", "stretch"] | None = None,
        justify: Literal["start", "center", "end", "between"] | None = None,
        gap: str | None = None,
        gap_x: str | None = None,
        gap_y: str | None = None,
    ):
        '''Grid component

        Args:
            rows (Optional[TMaybeRef[Union[int, str]]], optional): Number of rows or template for rows. Defaults to None.
            columns (Optional[TMaybeRef[Union[int, str]]], optional): Number of columns or template for columns. Defaults to None.

        # Example:
        columns example:
        .. code-block:: python
            border = "border-2 border-gray-200"

            with ui.grid(columns=2).classes(border) as g:

                # a in the first row and first column
                html.paragraph("a value").classes(border)
                # b in the first row and second column
                html.paragraph("b value").classes(border)

                # c in the second row and span over 2 columns
                html.paragraph("c value").use(
                    g.mark_area_position(column_span=2)
                ).classes(border)

        template areas example:
        .. code-block:: python
            border = "border-2 border-gray-200"

            template = r"""
            "a b c"
            "a b ."
            """

            with ui.grid(areas=template).classes(border) as g:
                html.paragraph("a value").use(g.mark_area("a")).classes(border)
                html.paragraph("b value").use(g.mark_area("b")).classes(border)
                html.paragraph("c value").use(g.mark_area("c")).classes(border)
        '''

        super().__init__("grid")

        self.props(
            {
                "as": as_,
                "display": display,
                "areas": areas,
                "columns": columns,
                "rows": rows,
                "flow": flow,
                "align": align,
                "justify": justify,
                "gap": gap,
                "gap_x": gap_x,
                "gap_y": gap_y,
            }
        )

    def mark_area(self, area: str):
        """Marks an area in the grid

        Args:
            area (str): Area name

        """

        def use_fn(element: Element):
            element.style({"grid-area": area})

        return use_fn

    def mark_area_position(
        self,
        *,
        row: int | None = None,
        column: int | None = None,
        row_span: int | None = None,
        column_span: int | None = None,
    ):
        """Marks an area in the grid with position

        Args:
            row (Optional[int], optional): Start position of row, 1-based. Defaults to None.
            column (Optional[int], optional): Start position of column, 1-based. Defaults to None.
            row_span (Optional[int], optional): The span value at the end of the row. Defaults to None.
            column_span (Optional[int], optional): The span value at the end of the column. Defaults to None.
        """
        real_row = "auto" if row is None else row
        real_column = "auto" if column is None else column
        real_row_span = "auto" if row_span is None else f"span {row_span}"
        real_column_span = "auto" if column_span is None else f"span {column_span}"

        area = f"{real_row} / {real_column} / {real_row_span} / {real_column_span}"
        return self.mark_area(area)

    @staticmethod
    def auto_columns(
        *,
        min_width: str,
        mode: Literal["auto-fill", "auto-fit"] = "auto-fit",
    ):
        """
        Generate a dynamic grid column configuration for responsive layout systems.

        Creates a computed layout specification that calculates column dimensions
        based on minimum width requirements and auto-sizing behavior. Retu

        Args:
            min_width (str):
                Minimum width constraint for columns as a CSS length string (e.g., "300px").
                Accepts reactive references for dynamic updates.
            mode (TMaybeRef[Literal[&quot;auto, optional):
                Auto-sizing behavior strategy:
                - "auto-fill": Preserves container space by creating additional columns
                - "auto-fit": Adjusts columns to fit available space.
                Defaults to "auto-fit".

        Example:
        .. code-block:: python

            with ui.grid(columns=ui.grid.auto_columns(min_width="300px")):
                ...
        """
        template = js_computed(
            inputs=[min_width, mode],
            code=r"(min_width, mode)=> `repeat(${mode}, minmax(min(${min_width},100%), 1fr))`",
            r_type=str,
        )

        return template

    @staticmethod
    def auto_rows(
        *,
        min_height: str,
        mode: Literal["auto-fill", "auto-fit"] = "auto-fit",
    ):
        """
        Generate a dynamic grid row configuration for responsive layout systems.

        Creates a computed layout specification that calculates row dimensions
        based on minimum height requirements and auto-sizing behavior.

        Args:
            min_height (str):
                Minimum height constraint for rows as a CSS length string (e.g., "300px").
            mode (TMaybeRef[Literal[&quot;auto, optional):
                Auto-sizing behavior strategy:
                - "auto-fill": Preserves container space by creating additional rows
                - "auto-fit": Adjusts rows to fit available space.
                Defaults to "auto-fit".

        Example:
        .. code-block:: python

            with ui.grid(rows=ui.grid.auto_rows(min_height="300px")):
                ...
        """

        template = js_computed(
            inputs=[min_height, mode],
            code=r"(min_height, mode)=> `repeat(${mode}, minmax(min(${min_height},100%), 1fr))`",
            r_type=str,
        )

        return template
