from typing import Iterable

from instaui.debug.source import get_source_span
from instaui.internal.ui._scope import Scope
from instaui.internal.ui.app_context import get_current_scope
from instaui.internal.ui.app_index import new_scope_if_needed
from instaui.internal.ui.bindable import BindableMixin
from instaui.internal.ui.consumer import Consumer
from instaui.internal.ui.enums import InputBindingType, OutputSetType
from instaui.internal.ui.protocol import CanOutputProtocol, ObservableProtocol
from instaui.internal.ui.variable import Variable, VariableMarker


class ElementRef(
    Variable,
    ObservableProtocol,
    CanOutputProtocol,
    BindableMixin,
):
    def __init__(self) -> None:
        """
        A reference holder for a frontend DOM element, enabling two-way interaction between
        Python and JavaScript. The referenced element can be used as input/output in JS
        events, and methods can be executed dynamically on the element at runtime.

        Args:
            None: The reference is created without initialization parameters. It will be
                bound to an element using ``element_ref(...)`` during UI construction.

        Example:
        .. code-block:: python
            # 1️ Use ElementRef inside ui.event as an output
            cp = ui.element_ref()

            @ui.event(outputs=[cp])
            def on_click():
                return ui.run_element_method("reset")

            Counter("my counter").element_ref(cp)
            html.button("reset").on_click(on_click)


            # 2️⃣ Use ElementRef as input to ui.js_event
            ele = ui.element_ref()
            click_event = ui.js_event(inputs=[ele], code="(ele)=> ele.increment()")

            CounterWithRefInput().element_ref(ele)
            html.button("click").on_click(click_event)


            # 3️⃣ Access DOM element inside JavaScript event using `ele.$el ?? ele`
            ele_dom = ui.element_ref()
            output = ui.state("")

            ui.text("custom").element_ref(ele_dom).on(
                "click",
                ui.js_event(
                    inputs=[ele_dom],
                    outputs=[output],
                    code="ele => (ele.$el ?? ele).tagName"
                ),
            )
            ui.text(output)
        """
        super().__init__()
        self._source_span_ = get_source_span()
        new_scope_if_needed()
        self._define_scope = get_current_scope()
        self._define_scope.add_variable(self)
        self._variable_marker = VariableMarker(self)

    def _to_event_output_type(self) -> OutputSetType:
        return OutputSetType.ElementRefAction

    def _to_event_input_type(self) -> InputBindingType:
        return InputBindingType.ElementRef

    @property
    def _scope(self) -> Scope:
        return self._define_scope

    def _reset_scope(self, scope: Scope) -> None:
        self._define_scope = scope

    @property
    def _used(self) -> bool:
        return self._variable_marker.is_used

    def _try_hoist(self, target_scope: Scope) -> None:
        self._variable_marker.try_hoist(target_scope)

    def _apply_binding(self, consumer: Consumer):
        self._variable_marker.apply_binding(consumer)

    def _get_consumers(self) -> Iterable[Consumer]:
        return self._variable_marker.get_consumers()

    @property
    def _force_provide(self) -> bool:
        return self._variable_marker.force_provide

    def _set_force_provide(self, value=True):
        self._variable_marker.set_force_provide(value)


def run_element_method(method_name: str, *args, **kwargs):
    return {
        "method": method_name,
        "args": args,
    }
