import typing

from instaui.debug.api_boundary import user_api
from instaui.debug.source import get_source_span
from instaui.internal.ui._expr.literal_expr import UILiteralExpr
from instaui.internal.ui._scope import Scope
from instaui.internal.ui.app_context import get_current_scope
from instaui.internal.ui.app_index import new_scope_if_needed
from instaui.internal.ui.bindable import BindableMixin
from instaui.internal.ui.consumer import Consumer
from instaui.internal.ui.event import EventMixin
from instaui.internal.ui.event_modifier import TEventModifier
from instaui.internal.ui.variable import ConsumerVariableMarker, Variable


class ExprEvent(Variable, Consumer, EventMixin, BindableMixin):
    def __init__(
        self,
        *,
        code: str,
        bindings: typing.Optional[dict[str, typing.Any]] = None,
    ):
        super().__init__()
        self._source_span_ = get_source_span()
        new_scope_if_needed()
        self._define_scope = get_current_scope()
        self._define_scope.add_variable(self)

        self._code = code
        self._bindings = UILiteralExpr.try_parse_dict(bindings or {})
        self._variable_marker = ConsumerVariableMarker(self, deps=[self._bindings])

    def _attach_to_element(
        self,
        *,
        params: typing.Optional[typing.Sequence],
        modifier: typing.Optional[typing.Sequence[TEventModifier]] = None,
    ):
        self._variable_marker.update_dependencies(params, modifier)
        self._variable_marker.apply_binding(self)

        return self

    @property
    def _scope(self) -> Scope:
        return self._define_scope

    def _reset_scope(self, scope: Scope) -> None:
        self._define_scope = scope

    @property
    def _used(self) -> bool:
        return self._variable_marker.is_used

    def _get_scope(self) -> Scope:
        return self._define_scope

    def _try_hoist(self, target_scope: Scope) -> None:
        self._variable_marker.try_hoist(target_scope)

    def _apply_binding(self, consumer: Consumer):
        self._variable_marker.apply_binding(consumer)

    def _get_consumers(self) -> typing.Iterable[Consumer]:
        return self._variable_marker.get_consumers()

    @property
    def _force_provide(self) -> bool:
        return self._variable_marker.force_provide

    def _set_force_provide(self, value=True):
        self._variable_marker.set_force_provide(value)


@user_api
def expr_event(
    *,
    code: str,
    bindings: typing.Optional[dict[str, typing.Any]] = None,
):
    """
    Create an event object that can be bound to a UI component's event listener.

    This function generates a callable event handler with optional contextual bindings.
    The event logic is defined via a code string, which can reference bound variables.

    Args:
        code (str): A string containing the executable logic for the event handler.
                    Typically contains a function body or expression that utilizes bound variables.
        bindings (typing.Optional[dict[str, typing.Any]], optional): A dictionary mapping variable names to values that should be available in the
            event handler's context. If None, no additional bindings are created.. Defaults to None.

    Example:
    .. code-block:: python
        a = ui.state(1)

        event = ui.vue_event(bindings={"a": a}, code=r'''()=> { a.value +=1}''')

        html.span(a)
        html.button("plus").on("click", event)
    """
    return ExprEvent(code=code, bindings=bindings)
