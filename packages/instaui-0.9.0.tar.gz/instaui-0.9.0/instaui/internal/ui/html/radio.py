from typing import Any
from instaui.internal.ui.element import Element
from instaui.internal.ui.value_element import ValueElement
from ._mixins import InputEventMixin
from . import _utils

_T_value = str | Any


class Radio(InputEventMixin, ValueElement[_T_value]):
    def __init__(
        self,
        value: _T_value | None = None,
        *,
        model_value: _T_value | None = None,
        id: str | None = None,
        name: str | None = None,
        **kwargs,
    ):
        super().__init__("input", value, is_html_component=True)
        self.props(
            {
                "type": "radio",
                "id": id,
                "name": name,
                "value": model_value,
                **_utils.strip_key_underscores(kwargs),
            }
        )

    def _input_event_mixin_element(self) -> Element:
        return self
