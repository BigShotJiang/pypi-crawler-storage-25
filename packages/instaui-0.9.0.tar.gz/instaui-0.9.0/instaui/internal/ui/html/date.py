from __future__ import annotations
from typing import TYPE_CHECKING
from instaui.internal.ui.value_element import ValueElement
from ._mixins import InputEventMixin
from . import _utils

if TYPE_CHECKING:
    from instaui.internal.ui.element import Element

_T_value = str


class Date(InputEventMixin, ValueElement[_T_value]):
    def __init__(
        self,
        value: _T_value | None = None,
        *,
        model_value: _T_value | None = None,
        **kwargs,
    ):
        super().__init__("input", value, is_html_component=True)
        self.props(
            {
                "type": "date",
                "value": model_value,
                **_utils.strip_key_underscores(kwargs),
            }
        )

    def _input_event_mixin_element(self) -> Element:
        return self  # type: ignore
