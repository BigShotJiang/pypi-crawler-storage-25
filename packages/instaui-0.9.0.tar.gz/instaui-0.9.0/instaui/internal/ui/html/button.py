from instaui.internal.ui.element import Element
from instaui.internal.ui.event import EventMixin
from instaui.internal.ui.event_modifier import TEventModifier
from instaui.internal.ui.disabled_element import DisabledElement
from . import _utils


class Button(Element, DisabledElement):
    def __init__(self, inner_text: str | None = None, **kwargs):
        super().__init__("button")

        self.props(
            {
                "innerText": inner_text,
                **_utils.strip_key_underscores(kwargs),
            }
        )

    def on_click(
        self,
        handler: EventMixin,
        *,
        params: list | None = None,
        modifier: list[TEventModifier] | None = None,
    ):
        self.on("click", handler, params=params, modifier=modifier)
        return self
