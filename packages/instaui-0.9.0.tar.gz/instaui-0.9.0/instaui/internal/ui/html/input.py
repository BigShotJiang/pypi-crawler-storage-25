from typing import Any
from instaui.internal.ui.element import Element
from instaui.internal.ui.value_element import ValueElement
from instaui.internal.ui.disabled_element import DisabledElement
from ._mixins import InputEventMixin
from . import _utils


class Input(InputEventMixin, DisabledElement, ValueElement[str]):
    def __init__(
        self,
        value: str | Any | None = None,
        *,
        model_value: str | Any | None = None,
        disabled: bool | None = None,
        type: str | None = None,
        **kwargs,
    ):
        super().__init__("input", value, is_html_component=True)
        self.props(
            {
                "type": type,
                "disabled": disabled,
                "value": model_value,
                **_utils.strip_key_underscores(kwargs),
            }
        )

    def _input_event_mixin_element(self) -> Element:
        return self
