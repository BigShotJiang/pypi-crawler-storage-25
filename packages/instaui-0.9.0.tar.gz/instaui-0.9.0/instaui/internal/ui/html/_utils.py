def strip_key_underscores(d):
    return {key.strip("_"): value for key, value in d.items()}
