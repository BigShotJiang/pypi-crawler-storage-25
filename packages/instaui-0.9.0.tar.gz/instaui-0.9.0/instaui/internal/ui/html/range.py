from instaui.internal.ui.element import Element
from instaui.internal.ui.value_element import ValueElement
from instaui.internal.ui.bindable import BindableMixin
from instaui.types import TVModelModifier
from ._mixins import InputEventMixin
from . import _utils

_T_value = int | float


class Range(InputEventMixin, ValueElement[_T_value]):
    def __init__(
        self,
        value: _T_value | None = None,
        *,
        min: _T_value | None = None,
        max: _T_value | None = None,
        step: _T_value | None = None,
        **kwargs,
    ):
        super().__init__("input", value, is_html_component=True)
        self.props(
            {
                "type": "range",
                "min": min,
                "max": max,
                "step": step,
                **_utils.strip_key_underscores(kwargs),
            }
        )

    def vmodel(
        self,
        value: BindableMixin,
        modifiers: TVModelModifier | list[TVModelModifier] | None = None,
        *,
        prop_name: str = "value",
    ):
        modifiers = modifiers or []
        if isinstance(modifiers, str):
            modifiers = [modifiers]

        modifiers_with_number = list(set([*modifiers, "number"]))

        return super().vmodel(value, modifiers_with_number, prop_name=prop_name)  # type: ignore

    def _input_event_mixin_element(self) -> Element:
        return self
