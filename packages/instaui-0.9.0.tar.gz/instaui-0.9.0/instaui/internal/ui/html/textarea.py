from instaui.internal.ui.element import Element
from instaui.internal.ui.value_element import ValueElement
from instaui.internal.ui.disabled_element import DisabledElement
from ._mixins import InputEventMixin
from . import _utils


class Textarea(InputEventMixin, DisabledElement, ValueElement[str]):
    def __init__(
        self,
        value: str | None = None,
        *,
        model_value: str | None = None,
        disabled: bool | None = None,
        **kwargs,
    ):
        super().__init__("textarea", value, is_html_component=True)

        self.props(
            {
                "disabled": disabled,
                "value": model_value,
                **_utils.strip_key_underscores(kwargs),
            }
        )

    def _input_event_mixin_element(self) -> Element:
        return self
