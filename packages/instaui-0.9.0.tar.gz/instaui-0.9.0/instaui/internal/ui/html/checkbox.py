from typing import Any
from instaui.internal.ui.element import Element
from instaui.internal.ui.value_element import ValueElement
from ._mixins import InputEventMixin
from . import _utils


class Checkbox(InputEventMixin, ValueElement[bool | str | list]):
    def __init__(
        self,
        value: bool | str | list | None = None,
        *,
        model_value: bool | str | None = None,
        checked: bool | None = None,
        id: Any = None,
        **kwargs,
    ):
        super().__init__("input", value, is_html_component=True)
        self.props(
            {
                "type": "checkbox",
                "id": id,
                "checked": checked,
                "value": model_value,
                **_utils.strip_key_underscores(kwargs),
            }
        )

    def _input_event_mixin_element(self) -> Element:
        return self
