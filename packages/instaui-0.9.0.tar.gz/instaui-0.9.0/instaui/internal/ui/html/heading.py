from typing import Any, Literal
from instaui.internal.ui.element import Element


TText = str | Any | None


class Heading(Element):
    def __init__(
        self,
        inner_text: TText = None,
        *,
        level: Literal[1, 2, 3, 4, 5, 6] = 1,
    ):
        super().__init__(f"h{level}")
        self.props(
            {
                "innerText": inner_text,
            }
        )
