from __future__ import annotations

from typing import TYPE_CHECKING, Iterable

from instaui.internal.ui.bindable import BindableMixin

if TYPE_CHECKING:
    from instaui.internal.ui._scope import Scope


def hoist_variables(variables: Iterable[BindableMixin], target_scope: Scope) -> None:
    """
    Move all variables that need hoisting (along with their dependency chains) to target_scope.

    Hoisting condition: The variable's definition scope is a strict descendant of target_scope.
    """

    for var in variables:
        var._try_hoist(target_scope)
