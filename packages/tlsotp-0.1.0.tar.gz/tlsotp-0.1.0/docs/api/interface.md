# Interface API

This module provides the user-facing interface for TLSOTP.

::: tlsotp.interface
    options:
      show_source: true
      show_root_heading: true
      show_signature: true
      members_order: source