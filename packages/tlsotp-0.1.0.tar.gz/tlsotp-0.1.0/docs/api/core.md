<!-- # Core API

::: tlsotp.core -->

# Core API

This module contains the core OTP generation and validation logic.

::: tlsotp.core
    options:
      show_source: true
      show_root_heading: true
      show_signature: true
      members_order: source