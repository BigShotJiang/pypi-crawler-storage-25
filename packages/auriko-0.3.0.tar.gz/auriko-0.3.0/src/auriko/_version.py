"""Auriko SDK version metadata."""

from __future__ import annotations

import importlib.metadata

__title__: str = "auriko"
__version__: str = "0.3.0"

try:
    if __package__ is not None:
        __version__ = importlib.metadata.version(__package__)
except importlib.metadata.PackageNotFoundError:
    pass
