"""AurikoAsyncOpenAI — AsyncOpenAI subclass with automatic routing metadata capture and error mapping."""

from __future__ import annotations

import asyncio
import json
import logging
import os
from collections.abc import AsyncIterator
from typing import Any, Callable

import httpx
import openai
from openai import AsyncOpenAI, DefaultAsyncHttpxClient

from .errors.openai_bridge import make_bridge_error
from .errors.types import AuthenticationError
from .route_types import RoutingMetadata

logger = logging.getLogger(__name__)


def _resolve_api_key(api_key: str | None) -> str:
    """Resolve API key: explicit arg > AURIKO_API_KEY env > raise.

    Does NOT fall back to OPENAI_API_KEY — consistent with
    _base_client.py:43-53 and SDK_STRATEGY.md.
    """
    resolved = api_key or os.environ.get("AURIKO_API_KEY")
    if not resolved:
        raise AuthenticationError(
            message="API key is missing. Set AURIKO_API_KEY or pass api_key=.",
            status_code=0,
            type="authentication_error",
            code="missing_api_key",
        )
    return resolved


class _MetadataCapturingStream(httpx.AsyncByteStream):
    """Wraps an SSE byte stream to capture routing_metadata during iteration.

    Yields every chunk immediately (zero buffering, no TTFT impact).
    Scans accumulated buffer for the metadata event on natural completion
    or on aclose() (which fires first when the OpenAI SDK breaks on [DONE]).
    """

    def __init__(
        self,
        inner: httpx.AsyncByteStream,
        on_metadata: Callable[[RoutingMetadata], None],
    ) -> None:
        self._inner = inner
        self._on_metadata = on_metadata
        self._buffer = bytearray()
        self._extracted = False

    async def __aiter__(self) -> AsyncIterator[bytes]:
        async for chunk in self._inner:
            self._buffer.extend(chunk)
            yield chunk
        self._extract_metadata()

    async def aclose(self) -> None:
        self._extract_metadata()
        await self._inner.aclose()

    def _extract_metadata(self) -> None:
        """Scan buffer for the last data: event before [DONE], extract routing_metadata."""
        if self._extracted:
            return
        self._extracted = True
        try:
            text = self._buffer.decode("utf-8", errors="replace")
            last_data: str | None = None
            for line in text.splitlines():
                stripped = line.strip()
                if stripped.startswith("data: ") and stripped != "data: [DONE]":
                    last_data = stripped[6:]
            if last_data is None:
                return
            payload = json.loads(last_data)
            raw_metadata = payload.get("routing_metadata")
            if raw_metadata is None:
                return
            metadata = RoutingMetadata.model_validate(raw_metadata)
            self._on_metadata(metadata)
        except Exception:
            logger.debug("Failed to extract routing_metadata from SSE stream", exc_info=True)


class AurikoAsyncOpenAI(AsyncOpenAI):
    """**Experimental.** AsyncOpenAI subclass with automatic routing metadata capture and error mapping.

    Most users should use ``auriko.AsyncClient`` (native SDK) or ``AsyncOpenAI(base_url=...)``
    (plain OpenAI-compatible). Use ``AurikoAsyncOpenAI`` only when passing an OpenAI client to
    a framework that discards routing metadata from responses.

    Usage::

        client = AurikoAsyncOpenAI(api_key="ak-...")
        response = await client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": "Hello"}],
        )
        print(client.last_routing_metadata)
    """

    def __init__(
        self,
        *,
        api_key: str | None = None,
        base_url: str = "https://api.auriko.ai/v1",
        on_response: Callable[[RoutingMetadata], Any] | None = None,
        **kwargs: Any,
    ) -> None:
        if "http_client" in kwargs:
            raise TypeError(
                "AurikoAsyncOpenAI does not accept http_client. "
                "Remove it or use AsyncOpenAI(base_url=...) directly."
            )
        if on_response is not None and asyncio.iscoroutinefunction(on_response):
            raise TypeError("on_response must be a sync callable, not async")

        resolved_key = _resolve_api_key(api_key)

        self._last_metadata: RoutingMetadata | None = None
        self._on_response = on_response

        async def _request_hook(request: httpx.Request) -> None:
            self._last_metadata = None

        def _deliver_metadata(metadata: RoutingMetadata) -> None:
            self._last_metadata = metadata
            if self._on_response is not None:
                try:
                    self._on_response(metadata)
                except Exception:
                    logger.debug("on_response callback raised", exc_info=True)

        async def _response_hook(response: httpx.Response) -> None:
            try:
                if response.status_code >= 400:
                    return

                content_type = response.headers.get("content-type", "")

                if "text/event-stream" in content_type:
                    response.stream = _MetadataCapturingStream(
                        response.stream, _deliver_metadata,
                    )
                else:
                    await response.aread()
                    body = response.json()
                    raw_metadata = body.get("routing_metadata")
                    if raw_metadata is not None:
                        metadata = RoutingMetadata.model_validate(raw_metadata)
                        _deliver_metadata(metadata)
            except Exception:
                logger.debug(
                    "Failed to capture routing_metadata from response",
                    exc_info=True,
                )

        http_client = DefaultAsyncHttpxClient(
            event_hooks={
                "request": [_request_hook],
                "response": [_response_hook],
            },
        )

        super().__init__(
            api_key=resolved_key,
            base_url=base_url,
            http_client=http_client,
            **kwargs,
        )

    def _make_status_error(
        self,
        err_msg: str,
        *,
        body: object,
        response: httpx.Response,
    ) -> openai.APIStatusError:
        openai_error = super()._make_status_error(err_msg, body=body, response=response)
        return make_bridge_error(openai_error, response=response, raw_body=body)

    @property
    def last_routing_metadata(self) -> RoutingMetadata | None:
        """Routing metadata from the most recent successful response.

        Returns None if no metadata is available (before any request, after an error,
        or if the response did not contain routing_metadata).
        """
        return self._last_metadata
