"""Auriko API client — sync and async."""

from __future__ import annotations

import time
from typing import Any, Optional

import httpx

from ._base_client import BaseClient
from .errors.mapping import is_retryable
from .errors.types import APIConnectionError


class Client(BaseClient):
    """Synchronous Auriko API client."""

    _httpx: httpx.Client

    def __init__(
        self,
        *,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: Optional[float] = None,
        max_retries: Optional[int] = None,
    ) -> None:
        super().__init__(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            max_retries=max_retries,
        )
        self._httpx = httpx.Client(
            base_url=self.base_url,
            headers=self._default_headers,
            timeout=self.timeout,
            follow_redirects=True,
        )

        from .resources.chat import Chat
        from .resources.me import Me
        from .resources.models import Models
        from .resources.responses import Responses

        self.chat = Chat(self)
        self.models = Models(self)
        self.me = Me(self)
        self.responses = Responses(self)

    def _request(
        self,
        method: str,
        path: str,
        *,
        body: Optional[dict[str, Any]] = None,
        params: Optional[dict[str, Any]] = None,
        headers: Optional[dict[str, str]] = None,
    ) -> httpx.Response:
        request = self._httpx.build_request(
            method, path, json=body, params=params, headers=headers,
        )
        retries_remaining = self.max_retries

        while True:
            try:
                response = self._httpx.send(request)
            except httpx.TimeoutException as e:
                if retries_remaining > 0:
                    retries_remaining -= 1
                    time.sleep(self._calculate_retry_delay(
                        self.max_retries - retries_remaining - 1,
                    ))
                    continue
                raise APIConnectionError(
                    message="Request timed out before a response was received.",
                    cause=e,
                ) from e
            except httpx.NetworkError as e:
                if retries_remaining > 0:
                    retries_remaining -= 1
                    time.sleep(self._calculate_retry_delay(
                        self.max_retries - retries_remaining - 1,
                    ))
                    continue
                raise APIConnectionError(cause=e) from e
            except httpx.TransportError as e:
                raise APIConnectionError(cause=e) from e

            if response.status_code >= 400:
                try:
                    error_body = response.json()
                except Exception:
                    text = response.text
                    error_body = text[:4096] if text else None

                exc = self._make_error(
                    response.status_code, error_body, headers=response.headers,
                )
                if is_retryable(exc) and retries_remaining > 0:
                    retries_remaining -= 1
                    retry_after = (
                        exc.response_headers.get("Retry-After")
                        if exc.response_headers is not None
                        else None
                    )
                    response.close()
                    time.sleep(self._calculate_retry_delay(
                        self.max_retries - retries_remaining - 1,
                        retry_after,
                    ))
                    continue
                raise exc

            return response

    def _request_stream(
        self,
        method: str,
        path: str,
        *,
        body: Optional[dict[str, Any]] = None,
        params: Optional[dict[str, Any]] = None,
        headers: Optional[dict[str, str]] = None,
    ) -> httpx.Response:
        request = self._httpx.build_request(
            method, path, json=body, params=params, headers=headers,
        )
        retries_remaining = self.max_retries

        while True:
            try:
                response = self._httpx.send(request, stream=True)
            except httpx.TimeoutException as e:
                if retries_remaining > 0:
                    retries_remaining -= 1
                    time.sleep(self._calculate_retry_delay(
                        self.max_retries - retries_remaining - 1,
                    ))
                    continue
                raise APIConnectionError(
                    message="Request timed out before a response was received.",
                    cause=e,
                ) from e
            except httpx.NetworkError as e:
                if retries_remaining > 0:
                    retries_remaining -= 1
                    time.sleep(self._calculate_retry_delay(
                        self.max_retries - retries_remaining - 1,
                    ))
                    continue
                raise APIConnectionError(cause=e) from e
            except httpx.TransportError as e:
                raise APIConnectionError(cause=e) from e

            if response.status_code >= 400:
                response.read()
                try:
                    error_body = response.json()
                except Exception:
                    text = response.text
                    error_body = text[:4096] if text else None

                exc = self._make_error(
                    response.status_code, error_body, headers=response.headers,
                )
                if is_retryable(exc) and retries_remaining > 0:
                    retries_remaining -= 1
                    retry_after = (
                        exc.response_headers.get("Retry-After")
                        if exc.response_headers is not None
                        else None
                    )
                    response.close()
                    time.sleep(self._calculate_retry_delay(
                        self.max_retries - retries_remaining - 1,
                        retry_after,
                    ))
                    continue
                response.close()
                raise exc

            return response

    def close(self) -> None:
        self._httpx.close()

    def __enter__(self) -> Client:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()


class AsyncClient(BaseClient):
    """Asynchronous Auriko API client."""

    _httpx: httpx.AsyncClient

    def __init__(
        self,
        *,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: Optional[float] = None,
        max_retries: Optional[int] = None,
    ) -> None:
        super().__init__(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            max_retries=max_retries,
        )
        self._httpx = httpx.AsyncClient(
            base_url=self.base_url,
            headers=self._default_headers,
            timeout=self.timeout,
            follow_redirects=True,
        )

        from .resources.chat import AsyncChat
        from .resources.me import AsyncMe
        from .resources.models import AsyncModels
        from .resources.responses import AsyncResponses

        self.chat = AsyncChat(self)
        self.models = AsyncModels(self)
        self.me = AsyncMe(self)
        self.responses = AsyncResponses(self)

    async def _request(
        self,
        method: str,
        path: str,
        *,
        body: Optional[dict[str, Any]] = None,
        params: Optional[dict[str, Any]] = None,
        headers: Optional[dict[str, str]] = None,
    ) -> httpx.Response:
        import anyio

        request = self._httpx.build_request(
            method, path, json=body, params=params, headers=headers,
        )
        retries_remaining = self.max_retries

        while True:
            try:
                response = await self._httpx.send(request)
            except httpx.TimeoutException as e:
                if retries_remaining > 0:
                    retries_remaining -= 1
                    await anyio.sleep(self._calculate_retry_delay(
                        self.max_retries - retries_remaining - 1,
                    ))
                    continue
                raise APIConnectionError(
                    message="Request timed out before a response was received.",
                    cause=e,
                ) from e
            except httpx.NetworkError as e:
                if retries_remaining > 0:
                    retries_remaining -= 1
                    await anyio.sleep(self._calculate_retry_delay(
                        self.max_retries - retries_remaining - 1,
                    ))
                    continue
                raise APIConnectionError(cause=e) from e
            except httpx.TransportError as e:
                raise APIConnectionError(cause=e) from e

            if response.status_code >= 400:
                try:
                    error_body = response.json()
                except Exception:
                    text = response.text
                    error_body = text[:4096] if text else None

                exc = self._make_error(
                    response.status_code, error_body, headers=response.headers,
                )
                if is_retryable(exc) and retries_remaining > 0:
                    retries_remaining -= 1
                    retry_after = (
                        exc.response_headers.get("Retry-After")
                        if exc.response_headers is not None
                        else None
                    )
                    await response.aclose()
                    await anyio.sleep(self._calculate_retry_delay(
                        self.max_retries - retries_remaining - 1,
                        retry_after,
                    ))
                    continue
                raise exc

            return response

    async def _request_stream(
        self,
        method: str,
        path: str,
        *,
        body: Optional[dict[str, Any]] = None,
        params: Optional[dict[str, Any]] = None,
        headers: Optional[dict[str, str]] = None,
    ) -> httpx.Response:
        import anyio

        request = self._httpx.build_request(
            method, path, json=body, params=params, headers=headers,
        )
        retries_remaining = self.max_retries

        while True:
            try:
                response = await self._httpx.send(request, stream=True)
            except httpx.TimeoutException as e:
                if retries_remaining > 0:
                    retries_remaining -= 1
                    await anyio.sleep(self._calculate_retry_delay(
                        self.max_retries - retries_remaining - 1,
                    ))
                    continue
                raise APIConnectionError(
                    message="Request timed out before a response was received.",
                    cause=e,
                ) from e
            except httpx.NetworkError as e:
                if retries_remaining > 0:
                    retries_remaining -= 1
                    await anyio.sleep(self._calculate_retry_delay(
                        self.max_retries - retries_remaining - 1,
                    ))
                    continue
                raise APIConnectionError(cause=e) from e
            except httpx.TransportError as e:
                raise APIConnectionError(cause=e) from e

            if response.status_code >= 400:
                await response.aread()
                try:
                    error_body = response.json()
                except Exception:
                    text = response.text
                    error_body = text[:4096] if text else None

                exc = self._make_error(
                    response.status_code, error_body, headers=response.headers,
                )
                if is_retryable(exc) and retries_remaining > 0:
                    retries_remaining -= 1
                    retry_after = (
                        exc.response_headers.get("Retry-After")
                        if exc.response_headers is not None
                        else None
                    )
                    await response.aclose()
                    await anyio.sleep(self._calculate_retry_delay(
                        self.max_retries - retries_remaining - 1,
                        retry_after,
                    ))
                    continue
                await response.aclose()
                raise exc

            return response

    async def close(self) -> None:
        await self._httpx.aclose()

    async def __aenter__(self) -> AsyncClient:
        return self

    async def __aexit__(self, *args: object) -> None:
        await self.close()
