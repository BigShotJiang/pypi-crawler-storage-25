"""Error dispatch: envelope → typed AurikoAPIError subclass."""

from __future__ import annotations

from typing import Any, Optional, Type

from ..response_headers import ResponseHeaders
from ._registry import CODE_TO_ERROR_TYPE, CODE_TO_STATUS
from .types import (
    APIConnectionError,
    APIStatusError,
    AurikoAPIError,
    AuthenticationError,
    BadRequestError,
    ConflictError,
    InternalServerError,
    NotFoundError,
    PermissionDeniedError,
    RateLimitError,
)

_VALID_TYPES = frozenset(
    {
        "invalid_request_error",
        "authentication_error",
        "permission_error",
        "not_found_error",
        "rate_limit_error",
        "api_error",
    }
)

_NON_RETRYABLE_CODES = frozenset({
    "budget_exhausted",
    "duplicate_resource",
    "field_immutable",
    "insufficient_quota",
    "internal_error",
    "method_not_allowed",
    "operation_not_allowed",
    "state_precondition_failed",
})
_RETRYABLE_TYPES = frozenset({"rate_limit_error", "api_error"})


def _dispatch_class(type_: str, status: int) -> Type[AurikoAPIError]:
    if type_ == "invalid_request_error":
        return ConflictError if status == 409 else BadRequestError
    if type_ == "authentication_error":
        return AuthenticationError
    if type_ == "permission_error":
        return PermissionDeniedError
    if type_ == "not_found_error":
        return NotFoundError
    if type_ == "rate_limit_error":
        return RateLimitError
    if type_ == "api_error":
        return InternalServerError if status == 500 else APIStatusError
    return APIStatusError


def _malformed_response_error(
    status_code: int,
    body: Any,
    response_headers: Optional[ResponseHeaders],
) -> APIStatusError:
    return APIStatusError(
        message="Server returned a malformed error response.",
        status_code=status_code,
        type="api_error",
        code="malformed_response",
        body=body,
        response_headers=response_headers,
    )


def _map_error_from_inner(
    status_code: int,
    inner: Any,
    *,
    body: Any = None,
    response_headers: Optional[ResponseHeaders] = None,
) -> AurikoAPIError:
    """Dispatch from an already-unwrapped inner error object.

    Expected shape: {"type": str, "code": str, "message": str, "param"?: str}.
    Returns APIStatusError(malformed_response) on validation failure.
    """
    if not isinstance(inner, dict):
        return _malformed_response_error(
            status_code, body if body is not None else inner, response_headers
        )

    type_ = inner.get("type")
    code = inner.get("code")
    message = inner.get("message")
    param = inner.get("param")

    if (
        not isinstance(type_, str)
        or type_ not in _VALID_TYPES
        or not isinstance(code, str)
        or not code
        or not isinstance(message, str)
        or not message
    ):
        return _malformed_response_error(
            status_code, body if body is not None else inner, response_headers
        )

    cls = _dispatch_class(type_, status_code)
    return cls(
        message=message,
        status_code=status_code,
        type=type_,
        code=code,
        param=param if isinstance(param, str) else None,
        body=body if body is not None else inner,
        response_headers=response_headers,
    )


def _map_error_from_envelope(
    status_code: int,
    body: Any,
    *,
    response_headers: Optional[ResponseHeaders] = None,
) -> AurikoAPIError:
    """Parse a canonical error envelope and return the typed exception.

    Strict: body MUST be {"error": <object>}. Anything else → APIStatusError
    with code='malformed_response'. Used by BaseClient and the SSE mid-stream
    detector.
    """
    if not isinstance(body, dict):
        return _malformed_response_error(status_code, body, response_headers)
    inner = body.get("error")
    if not isinstance(inner, dict):
        return _malformed_response_error(status_code, body, response_headers)
    return _map_error_from_inner(
        status_code, inner, body=body, response_headers=response_headers
    )


def map_error_from_code(
    code: str,
    message: str,
    *,
    param: Optional[str] = None,
    doc_url: Optional[str] = None,
    provider: Optional[str] = None,
    suggestion: Optional[str] = None,
    response_headers: Optional[ResponseHeaders] = None,
) -> AurikoAPIError:
    error_type = CODE_TO_ERROR_TYPE.get(code, "api_error")
    status = CODE_TO_STATUS.get(code, 500)
    inner: dict[str, Any] = {"type": error_type, "code": code, "message": message}
    if param is not None:
        inner["param"] = param
    if doc_url is not None:
        inner["doc_url"] = doc_url
    if provider is not None:
        inner["provider"] = provider
    if suggestion is not None:
        inner["suggestion"] = suggestion
    return _map_error_from_inner(
        status_code=status,
        inner=inner,
        body={"error": inner},
        response_headers=response_headers,
    )


def is_retryable(exc: AurikoAPIError) -> bool:
    """Return True if the error should be retried."""
    if isinstance(exc, APIConnectionError):
        return True
    return exc.type in _RETRYABLE_TYPES and exc.code not in _NON_RETRYABLE_CODES


def map_openai_error(e: Any) -> AurikoAPIError:
    """Convert an openai.APIStatusError into a typed AurikoAPIError."""
    if isinstance(e, AurikoAPIError):
        return e
    response_headers = None
    response = getattr(e, "response", None)
    if response is not None:
        raw_headers = getattr(response, "headers", None)
        if raw_headers is not None:
            response_headers = ResponseHeaders(raw_headers)

    return _map_error_from_inner(
        e.status_code,
        e.body,
        response_headers=response_headers,
    )
