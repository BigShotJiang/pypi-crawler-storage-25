"""Auriko error classes."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Optional

if TYPE_CHECKING:
    from ..response_headers import ResponseHeaders


class AurikoAPIError(Exception):
    """Base class for every Auriko SDK error. Abstract — never raised directly."""

    def __init__(
        self,
        message: str,
        *,
        status_code: int,
        type: str,
        code: str,
        param: Optional[str] = None,
        body: Any = None,
        response_headers: Optional["ResponseHeaders"] = None,
    ) -> None:
        Exception.__init__(self, message)
        self.message = message
        self.status_code = status_code
        self.type = type
        self.code = code
        self.param = param
        self.body = body
        self.response_headers = response_headers
        self.request_id: Optional[str] = (
            response_headers.request_id if response_headers else None
        )

    @property
    def doc_url(self) -> Optional[str]:
        if isinstance(self.body, dict):
            error_obj = self.body.get("error") if "error" in self.body else self.body
            if isinstance(error_obj, dict):
                doc = error_obj.get("doc_url")
                if isinstance(doc, str) and doc:
                    return doc
        from ._registry import DOC_URL_BY_CODE
        return DOC_URL_BY_CODE.get(self.code)

    @property
    def retry_after_seconds(self) -> Optional[float]:
        return self.response_headers.retry_after_seconds if self.response_headers else None

    @property
    def provider(self) -> Optional[str]:
        if isinstance(self.body, dict):
            error_obj = self.body.get("error") if "error" in self.body else self.body
            if isinstance(error_obj, dict):
                val = error_obj.get("provider")
                if isinstance(val, str) and val:
                    return val
        return None

    def __str__(self) -> str:
        provider = self.provider
        if provider:
            return f"[{provider}] {self.message}"
        return self.message

    def __repr__(self) -> str:
        parts = [
            f"message={self.message!r}",
            f"status_code={self.status_code}",
            f"type={self.type!r}",
            f"code={self.code!r}",
        ]
        if self.provider:
            parts.append(f"provider={self.provider!r}")
        return f"{self.__class__.__name__}({', '.join(parts)})"


class APIStatusError(AurikoAPIError):
    """Raised for any HTTP error response with a non-success status code."""


class BadRequestError(APIStatusError):
    """400 / 413 — invalid_request_error."""


class AuthenticationError(APIStatusError):
    """401 — authentication_error."""


class PermissionDeniedError(APIStatusError):
    """403 — permission_error."""


class NotFoundError(APIStatusError):
    """404 — not_found_error."""


class ConflictError(APIStatusError):
    """409 — invalid_request_error with status 409."""


class RateLimitError(APIStatusError):
    """429 — rate_limit_error."""


class InternalServerError(APIStatusError):
    """500 — api_error."""


class APIConnectionError(AurikoAPIError):
    """Raised when the SDK can't reach the server. No response body available."""

    def __init__(
        self,
        message: str = "Unable to connect to Auriko. Check your network and retry.",
        *,
        cause: Optional[BaseException] = None,
    ) -> None:
        super().__init__(
            message,
            status_code=0,
            type="api_error",
            code="api_connection_error",
        )
        if cause is not None:
            self.__cause__ = cause
