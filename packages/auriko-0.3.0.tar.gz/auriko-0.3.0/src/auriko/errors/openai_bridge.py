"""Dual-inheritance bridge errors for AurikoAsyncOpenAI.

Bridge classes inherit from both the matching Auriko subclass and the matching
OpenAI concrete subclass, so errors are catchable by both except hierarchies.

Internal module -- not exported from errors/__init__.py.
"""

from __future__ import annotations

from typing import Optional

import httpx
import openai

from ..response_headers import ResponseHeaders
from . import types as auriko_types
from .mapping import _map_error_from_inner
from .types import AurikoAPIError


class _BridgeInit:
    def __init__(
        self,
        *,
        message: str,
        response: httpx.Response,
        body: object,
        status_code: int,
        type: str,
        code: str,
        param: Optional[str] = None,
        response_headers: Optional[ResponseHeaders] = None,
    ) -> None:
        openai.APIStatusError.__init__(
            self, message, response=response, body=body
        )
        AurikoAPIError.__init__(
            self,
            message=message,
            status_code=status_code,
            type=type,
            code=code,
            param=param,
            body=body,
            response_headers=response_headers,
        )


class BridgeBadRequestError(
    _BridgeInit, auriko_types.BadRequestError, openai.BadRequestError
):
    pass


class BridgeAuthenticationError(
    _BridgeInit, auriko_types.AuthenticationError, openai.AuthenticationError
):
    pass


class BridgePermissionDeniedError(
    _BridgeInit, auriko_types.PermissionDeniedError, openai.PermissionDeniedError
):
    pass


class BridgeNotFoundError(
    _BridgeInit, auriko_types.NotFoundError, openai.NotFoundError
):
    pass


class BridgeConflictError(
    _BridgeInit, auriko_types.ConflictError, openai.ConflictError
):
    pass


class BridgeRateLimitError(
    _BridgeInit, auriko_types.RateLimitError, openai.RateLimitError
):
    pass


class BridgeInternalServerError(
    _BridgeInit, auriko_types.InternalServerError, openai.InternalServerError
):
    pass


class BridgeUnprocessableEntityError(
    _BridgeInit, auriko_types.BadRequestError, openai.UnprocessableEntityError
):
    """422: Auriko folds into BadRequestError, but OpenAI has a dedicated class."""

    pass


class _BridgeGatewayError(
    _BridgeInit, auriko_types.APIStatusError, openai.InternalServerError
):
    """502/503/504: cross-hierarchy (Auriko=APIStatusError, OpenAI=InternalServerError)."""

    pass


class _BridgeRateLimitFallbackError(
    _BridgeInit, auriko_types.APIStatusError, openai.RateLimitError
):
    """429 malformed: Auriko degrades to APIStatusError, OpenAI catch preserved."""

    pass


class BridgeAPIStatusError(
    _BridgeInit, auriko_types.APIStatusError, openai.APIStatusError
):
    pass


_BRIDGE_PAIR_OVERRIDES: dict[tuple[type, type], type[_BridgeInit]] = {
    (openai.UnprocessableEntityError, auriko_types.BadRequestError): BridgeUnprocessableEntityError,
    (openai.RateLimitError, auriko_types.APIStatusError): _BridgeRateLimitFallbackError,
}

_BRIDGE_BY_AURIKO_CLS: dict[type[AurikoAPIError], type[_BridgeInit]] = {
    auriko_types.BadRequestError: BridgeBadRequestError,
    auriko_types.ConflictError: BridgeConflictError,
    auriko_types.AuthenticationError: BridgeAuthenticationError,
    auriko_types.PermissionDeniedError: BridgePermissionDeniedError,
    auriko_types.NotFoundError: BridgeNotFoundError,
    auriko_types.RateLimitError: BridgeRateLimitError,
    auriko_types.InternalServerError: BridgeInternalServerError,
}


def _select_bridge_cls(
    mapped_auriko: AurikoAPIError,
    status_code: int,
    openai_error: openai.APIStatusError,
) -> type[_BridgeInit]:
    pair = (type(openai_error), type(mapped_auriko))
    cls = _BRIDGE_PAIR_OVERRIDES.get(pair)
    if cls is not None:
        return cls
    cls = _BRIDGE_BY_AURIKO_CLS.get(type(mapped_auriko))
    if cls is not None:
        return cls
    if status_code >= 500:
        return _BridgeGatewayError
    return BridgeAPIStatusError


def make_bridge_error(
    openai_error: openai.APIStatusError,
    *,
    response: httpx.Response,
    raw_body: object,
) -> AurikoAPIError:
    """Convert an openai.APIStatusError into a dual-inheritance bridge error."""
    mapped = _map_error_from_inner(openai_error.status_code, openai_error.body)
    response_headers = ResponseHeaders(response.headers)
    bridge_cls = _select_bridge_cls(mapped, openai_error.status_code, openai_error)
    return bridge_cls(
        message=mapped.message,
        response=response,
        body=raw_body,
        status_code=openai_error.status_code,
        type=mapped.type,
        code=mapped.code,
        param=mapped.param,
        response_headers=response_headers,
    )
