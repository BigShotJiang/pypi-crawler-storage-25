"""Auriko error classes and dispatch."""

from .mapping import is_retryable, map_error_from_code, map_openai_error
from .types import (
    APIConnectionError,
    APIStatusError,
    AurikoAPIError,
    AuthenticationError,
    BadRequestError,
    ConflictError,
    InternalServerError,
    NotFoundError,
    PermissionDeniedError,
    RateLimitError,
)

__all__ = [
    "APIConnectionError",
    "APIStatusError",
    "AurikoAPIError",
    "AuthenticationError",
    "BadRequestError",
    "ConflictError",
    "InternalServerError",
    "NotFoundError",
    "PermissionDeniedError",
    "RateLimitError",
    "is_retryable",
    "map_error_from_code",
    "map_openai_error",
]
