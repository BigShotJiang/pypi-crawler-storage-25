"""Responses resource — Response API with streaming support."""

from __future__ import annotations

from typing import (
    TYPE_CHECKING,
    Any,
    Dict,
    Iterable,
    List,
    Literal,
    Optional,
    Union,
    overload,
)

from ..route_types import GatewayOptions, merge_gateway_extra_body
from ..models.responses import Response
from .._response_streaming import AsyncResponseStream, ResponseStream
from ..models.extensions import Extensions
from ..response_headers import ResponseHeaders
from .._validation import validate_model_or_gateway
from ..types.responses_params import (
    ResponseToolParam,
    ResponseInputItemParam,
    ResponseReasoningParam,
)

if TYPE_CHECKING:
    from .._client import AsyncClient, Client


class Responses:
    """Synchronous responses resource."""

    def __init__(self, client: Client) -> None:
        self._client = client

    @overload
    def create(
        self,
        *,
        input: Union[str, Iterable[ResponseInputItemParam]],
        model: Optional[str] = ...,
        stream: Literal[False] = ...,
        instructions: Optional[str] = ...,
        tools: Optional[Iterable[ResponseToolParam]] = ...,
        tool_choice: Optional[Union[str, Dict[str, Any]]] = ...,
        parallel_tool_calls: Optional[bool] = ...,
        max_output_tokens: Optional[int] = ...,
        temperature: Optional[float] = ...,
        top_p: Optional[float] = ...,
        top_k: Optional[int] = ...,
        top_logprobs: Optional[int] = ...,
        reasoning: Optional[ResponseReasoningParam] = ...,
        text: Optional[Dict[str, Any]] = ...,
        user: Optional[str] = ...,
        metadata: Optional[Dict[str, str]] = ...,
        include: Optional[List[str]] = ...,
        prompt_cache_key: Optional[str] = ...,
        safety_identifier: Optional[str] = ...,
        truncation: Optional[str] = ...,
        gateway: Optional[Union[GatewayOptions, Dict[str, Any]]] = ...,
        extensions: Optional[Union[Extensions, Dict[str, Any]]] = ...,
        extra_body: Optional[Dict[str, Any]] = ...,
    ) -> Response: ...

    @overload
    def create(
        self,
        *,
        input: Union[str, Iterable[ResponseInputItemParam]],
        model: Optional[str] = ...,
        stream: Literal[True],
        instructions: Optional[str] = ...,
        tools: Optional[Iterable[ResponseToolParam]] = ...,
        tool_choice: Optional[Union[str, Dict[str, Any]]] = ...,
        parallel_tool_calls: Optional[bool] = ...,
        max_output_tokens: Optional[int] = ...,
        temperature: Optional[float] = ...,
        top_p: Optional[float] = ...,
        top_k: Optional[int] = ...,
        top_logprobs: Optional[int] = ...,
        reasoning: Optional[ResponseReasoningParam] = ...,
        text: Optional[Dict[str, Any]] = ...,
        user: Optional[str] = ...,
        metadata: Optional[Dict[str, str]] = ...,
        include: Optional[List[str]] = ...,
        prompt_cache_key: Optional[str] = ...,
        safety_identifier: Optional[str] = ...,
        truncation: Optional[str] = ...,
        gateway: Optional[Union[GatewayOptions, Dict[str, Any]]] = ...,
        extensions: Optional[Union[Extensions, Dict[str, Any]]] = ...,
        extra_body: Optional[Dict[str, Any]] = ...,
    ) -> ResponseStream: ...

    def create(
        self,
        *,
        input: Union[str, Iterable[ResponseInputItemParam]],
        model: Optional[str] = None,
        stream: bool = False,
        instructions: Optional[str] = None,
        tools: Optional[Iterable[ResponseToolParam]] = None,
        tool_choice: Optional[Union[str, Dict[str, Any]]] = None,
        parallel_tool_calls: Optional[bool] = None,
        max_output_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
        top_p: Optional[float] = None,
        top_k: Optional[int] = None,
        top_logprobs: Optional[int] = None,
        reasoning: Optional[ResponseReasoningParam] = None,
        text: Optional[Dict[str, Any]] = None,
        user: Optional[str] = None,
        metadata: Optional[Dict[str, str]] = None,
        include: Optional[List[str]] = None,
        prompt_cache_key: Optional[str] = None,
        safety_identifier: Optional[str] = None,
        truncation: Optional[str] = None,
        gateway: Optional[Union[GatewayOptions, Dict[str, Any]]] = None,
        extensions: Optional[Union[Extensions, Dict[str, Any]]] = None,
        extra_body: Optional[Dict[str, Any]] = None,
    ) -> Union[Response, ResponseStream]:
        body = _build_responses_body(
            model=model, input=input, stream=stream,
            instructions=instructions, tools=tools,
            tool_choice=tool_choice, parallel_tool_calls=parallel_tool_calls,
            max_output_tokens=max_output_tokens,
            temperature=temperature, top_p=top_p, top_k=top_k, top_logprobs=top_logprobs,
            reasoning=reasoning, text=text, user=user,
            metadata=metadata, include=include,
            prompt_cache_key=prompt_cache_key,
            safety_identifier=safety_identifier,
            truncation=truncation,
            gateway=gateway, extensions=extensions,
            extra_body=extra_body,
        )

        if stream:
            response = self._client._request_stream("POST", "responses", body=body)
            return ResponseStream(response=response)

        response = self._client._request("POST", "responses", body=body)
        result = self._client._parse_response(response, Response)
        result._response_headers = ResponseHeaders(response.headers)
        return result


class AsyncResponses:
    """Asynchronous responses resource."""

    def __init__(self, client: AsyncClient) -> None:
        self._client = client

    @overload
    async def create(
        self,
        *,
        input: Union[str, Iterable[ResponseInputItemParam]],
        model: Optional[str] = ...,
        stream: Literal[False] = ...,
        instructions: Optional[str] = ...,
        tools: Optional[Iterable[ResponseToolParam]] = ...,
        tool_choice: Optional[Union[str, Dict[str, Any]]] = ...,
        parallel_tool_calls: Optional[bool] = ...,
        max_output_tokens: Optional[int] = ...,
        temperature: Optional[float] = ...,
        top_p: Optional[float] = ...,
        top_k: Optional[int] = ...,
        top_logprobs: Optional[int] = ...,
        reasoning: Optional[ResponseReasoningParam] = ...,
        text: Optional[Dict[str, Any]] = ...,
        user: Optional[str] = ...,
        metadata: Optional[Dict[str, str]] = ...,
        include: Optional[List[str]] = ...,
        prompt_cache_key: Optional[str] = ...,
        safety_identifier: Optional[str] = ...,
        truncation: Optional[str] = ...,
        gateway: Optional[Union[GatewayOptions, Dict[str, Any]]] = ...,
        extensions: Optional[Union[Extensions, Dict[str, Any]]] = ...,
        extra_body: Optional[Dict[str, Any]] = ...,
    ) -> Response: ...

    @overload
    async def create(
        self,
        *,
        input: Union[str, Iterable[ResponseInputItemParam]],
        model: Optional[str] = ...,
        stream: Literal[True],
        instructions: Optional[str] = ...,
        tools: Optional[Iterable[ResponseToolParam]] = ...,
        tool_choice: Optional[Union[str, Dict[str, Any]]] = ...,
        parallel_tool_calls: Optional[bool] = ...,
        max_output_tokens: Optional[int] = ...,
        temperature: Optional[float] = ...,
        top_p: Optional[float] = ...,
        top_k: Optional[int] = ...,
        top_logprobs: Optional[int] = ...,
        reasoning: Optional[ResponseReasoningParam] = ...,
        text: Optional[Dict[str, Any]] = ...,
        user: Optional[str] = ...,
        metadata: Optional[Dict[str, str]] = ...,
        include: Optional[List[str]] = ...,
        prompt_cache_key: Optional[str] = ...,
        safety_identifier: Optional[str] = ...,
        truncation: Optional[str] = ...,
        gateway: Optional[Union[GatewayOptions, Dict[str, Any]]] = ...,
        extensions: Optional[Union[Extensions, Dict[str, Any]]] = ...,
        extra_body: Optional[Dict[str, Any]] = ...,
    ) -> AsyncResponseStream: ...

    async def create(
        self,
        *,
        input: Union[str, Iterable[ResponseInputItemParam]],
        model: Optional[str] = None,
        stream: bool = False,
        instructions: Optional[str] = None,
        tools: Optional[Iterable[ResponseToolParam]] = None,
        tool_choice: Optional[Union[str, Dict[str, Any]]] = None,
        parallel_tool_calls: Optional[bool] = None,
        max_output_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
        top_p: Optional[float] = None,
        top_k: Optional[int] = None,
        top_logprobs: Optional[int] = None,
        reasoning: Optional[ResponseReasoningParam] = None,
        text: Optional[Dict[str, Any]] = None,
        user: Optional[str] = None,
        metadata: Optional[Dict[str, str]] = None,
        include: Optional[List[str]] = None,
        prompt_cache_key: Optional[str] = None,
        safety_identifier: Optional[str] = None,
        truncation: Optional[str] = None,
        gateway: Optional[Union[GatewayOptions, Dict[str, Any]]] = None,
        extensions: Optional[Union[Extensions, Dict[str, Any]]] = None,
        extra_body: Optional[Dict[str, Any]] = None,
    ) -> Union[Response, AsyncResponseStream]:
        body = _build_responses_body(
            model=model, input=input, stream=stream,
            instructions=instructions, tools=tools,
            tool_choice=tool_choice, parallel_tool_calls=parallel_tool_calls,
            max_output_tokens=max_output_tokens,
            temperature=temperature, top_p=top_p, top_k=top_k, top_logprobs=top_logprobs,
            reasoning=reasoning, text=text, user=user,
            metadata=metadata, include=include,
            prompt_cache_key=prompt_cache_key,
            safety_identifier=safety_identifier,
            truncation=truncation,
            gateway=gateway, extensions=extensions,
            extra_body=extra_body,
        )

        if stream:
            response = await self._client._request_stream(
                "POST", "responses", body=body,
            )
            return AsyncResponseStream(response=response)

        response = await self._client._request("POST", "responses", body=body)
        result = self._client._parse_response(response, Response)
        result._response_headers = ResponseHeaders(response.headers)
        return result


def _build_responses_body(
    *,
    model: Optional[str],
    input: Union[str, Iterable[ResponseInputItemParam]],
    stream: bool,
    instructions: Optional[str],
    tools: Optional[Iterable[ResponseToolParam]],
    tool_choice: Optional[Union[str, Dict[str, Any]]],
    parallel_tool_calls: Optional[bool],
    max_output_tokens: Optional[int],
    temperature: Optional[float],
    top_p: Optional[float],
    top_k: Optional[int],
    top_logprobs: Optional[int],
    reasoning: Optional[ResponseReasoningParam],
    text: Optional[Dict[str, Any]],
    user: Optional[str],
    metadata: Optional[Dict[str, str]],
    include: Optional[List[str]],
    prompt_cache_key: Optional[str],
    safety_identifier: Optional[str],
    truncation: Optional[str] = None,
    gateway: Optional[Union[GatewayOptions, Dict[str, Any]]],
    extensions: Optional[Union[Extensions, Dict[str, Any]]],
    extra_body: Optional[Dict[str, Any]],
) -> Dict[str, Any]:
    input_value = input if isinstance(input, str) else list(input)
    tools_list = list(tools) if tools is not None else None

    gateway_dict: Optional[Dict[str, Any]] = None
    if gateway is not None:
        if isinstance(gateway, GatewayOptions):
            dumped = gateway.model_dump(exclude_unset=True, exclude_none=True, mode="json")
            gateway_dict = dumped or None
        else:
            gateway_dict = gateway if gateway else None

    validate_model_or_gateway(model, gateway_dict)

    body: Dict[str, Any] = {"input": input_value}
    if model is not None:
        body["model"] = model

    if isinstance(extensions, Extensions):
        extensions = extensions.model_dump(exclude_unset=True, exclude_none=True, mode="json")

    for key, value in [
        ("instructions", instructions),
        ("tools", tools_list),
        ("tool_choice", tool_choice),
        ("parallel_tool_calls", parallel_tool_calls),
        ("max_output_tokens", max_output_tokens),
        ("temperature", temperature),
        ("top_p", top_p),
        ("top_k", top_k),
        ("top_logprobs", top_logprobs),
        ("reasoning", reasoning),
        ("text", text),
        ("user", user),
        ("metadata", metadata),
        ("include", include),
        ("prompt_cache_key", prompt_cache_key),
        ("safety_identifier", safety_identifier),
        ("truncation", truncation),
        ("extensions", extensions),
    ]:
        if value is not None:
            body[key] = value

    if gateway_dict:
        body["gateway"] = gateway_dict

    if extra_body:
        body = merge_gateway_extra_body(body, extra_body)

    if stream:
        body["stream"] = True
    else:
        body.pop("stream", None)

    return body
