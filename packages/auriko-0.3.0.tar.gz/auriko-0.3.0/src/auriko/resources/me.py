"""Me resource — API key introspection."""

from __future__ import annotations

from typing import TYPE_CHECKING

from ..models.common import ApiKeyIdentity

if TYPE_CHECKING:
    from .._client import AsyncClient, Client


class Me:
    def __init__(self, client: Client) -> None:
        self._client = client

    def get(self) -> ApiKeyIdentity:
        response = self._client._request("GET", "me")
        return self._client._parse_response(response, ApiKeyIdentity)


class AsyncMe:
    def __init__(self, client: AsyncClient) -> None:
        self._client = client

    async def get(self) -> ApiKeyIdentity:
        response = await self._client._request("GET", "me")
        return self._client._parse_response(response, ApiKeyIdentity)
