"""Chat resource — chat completions with streaming support."""

from __future__ import annotations

from typing import (
    TYPE_CHECKING,
    Any,
    Dict,
    Iterable,
    List,
    Literal,
    Optional,
    Union,
    overload,
)

from ..route_types import GatewayOptions, merge_gateway_extra_body
from ..models.chat import ChatCompletion, ChatCompletionChunk
from .._streaming import AsyncStream, Stream
from ..models.extensions import Extensions
from ..response_headers import ResponseHeaders
from .._validation import validate_model_or_gateway
from ..types.chat_params import (
    ChatCompletionMessageParam,
    ChatCompletionToolChoiceOptionParam,
    ChatCompletionToolParam,
    ResponseFormatParam,
    StreamOptionsParam,
)

if TYPE_CHECKING:
    from .._client import AsyncClient, Client


class Completions:
    """Synchronous chat completions resource."""

    def __init__(self, client: Client) -> None:
        self._client = client

    @overload
    def create(
        self,
        *,
        messages: Iterable[ChatCompletionMessageParam],
        model: Optional[str] = ...,
        stream: Literal[False] = ...,
        temperature: Optional[float] = ...,
        top_p: Optional[float] = ...,
        max_tokens: Optional[int] = ...,
        max_completion_tokens: Optional[int] = ...,
        reasoning_effort: Optional[Literal['low', 'medium', 'high', 'xhigh', 'max', 'off']] = ...,
        frequency_penalty: Optional[float] = ...,
        presence_penalty: Optional[float] = ...,
        top_k: Optional[int] = ...,
        min_p: Optional[float] = ...,
        top_a: Optional[float] = ...,
        repetition_penalty: Optional[float] = ...,
        stop: Optional[Union[str, List[str]]] = ...,
        seed: Optional[int] = ...,
        n: Optional[int] = ...,
        tools: Optional[Iterable[ChatCompletionToolParam]] = ...,
        tool_choice: Optional[ChatCompletionToolChoiceOptionParam] = ...,
        parallel_tool_calls: Optional[bool] = ...,
        response_format: Optional[ResponseFormatParam] = ...,
        stream_options: Optional[StreamOptionsParam] = ...,
        logprobs: Optional[bool] = ...,
        top_logprobs: Optional[int] = ...,
        logit_bias: Optional[Dict[str, float]] = ...,
        user: Optional[str] = ...,
        web_search_options: Optional[Dict[str, Any]] = ...,
        verbosity: Optional[str] = ...,
        prompt_cache_key: Optional[str] = ...,
        safety_identifier: Optional[str] = ...,
        gateway: Optional[Union[GatewayOptions, Dict[str, Any]]] = ...,
        extensions: Optional[Union[Extensions, Dict[str, Any]]] = ...,
        extra_body: Optional[Dict[str, Any]] = ...,
    ) -> ChatCompletion: ...

    @overload
    def create(
        self,
        *,
        messages: Iterable[ChatCompletionMessageParam],
        model: Optional[str] = ...,
        stream: Literal[True],
        temperature: Optional[float] = ...,
        top_p: Optional[float] = ...,
        max_tokens: Optional[int] = ...,
        max_completion_tokens: Optional[int] = ...,
        reasoning_effort: Optional[Literal['low', 'medium', 'high', 'xhigh', 'max', 'off']] = ...,
        frequency_penalty: Optional[float] = ...,
        presence_penalty: Optional[float] = ...,
        top_k: Optional[int] = ...,
        min_p: Optional[float] = ...,
        top_a: Optional[float] = ...,
        repetition_penalty: Optional[float] = ...,
        stop: Optional[Union[str, List[str]]] = ...,
        seed: Optional[int] = ...,
        n: Optional[int] = ...,
        tools: Optional[Iterable[ChatCompletionToolParam]] = ...,
        tool_choice: Optional[ChatCompletionToolChoiceOptionParam] = ...,
        parallel_tool_calls: Optional[bool] = ...,
        response_format: Optional[ResponseFormatParam] = ...,
        stream_options: Optional[StreamOptionsParam] = ...,
        logprobs: Optional[bool] = ...,
        top_logprobs: Optional[int] = ...,
        logit_bias: Optional[Dict[str, float]] = ...,
        user: Optional[str] = ...,
        web_search_options: Optional[Dict[str, Any]] = ...,
        verbosity: Optional[str] = ...,
        prompt_cache_key: Optional[str] = ...,
        safety_identifier: Optional[str] = ...,
        gateway: Optional[Union[GatewayOptions, Dict[str, Any]]] = ...,
        extensions: Optional[Union[Extensions, Dict[str, Any]]] = ...,
        extra_body: Optional[Dict[str, Any]] = ...,
    ) -> Stream[ChatCompletionChunk]: ...

    def create(
        self,
        *,
        messages: Iterable[ChatCompletionMessageParam],
        model: Optional[str] = None,
        stream: bool = False,
        temperature: Optional[float] = None,
        top_p: Optional[float] = None,
        max_tokens: Optional[int] = None,
        max_completion_tokens: Optional[int] = None,
        reasoning_effort: Optional[Literal['low', 'medium', 'high', 'xhigh', 'max', 'off']] = None,
        frequency_penalty: Optional[float] = None,
        presence_penalty: Optional[float] = None,
        top_k: Optional[int] = None,
        min_p: Optional[float] = None,
        top_a: Optional[float] = None,
        repetition_penalty: Optional[float] = None,
        stop: Optional[Union[str, List[str]]] = None,
        seed: Optional[int] = None,
        n: Optional[int] = None,
        tools: Optional[Iterable[ChatCompletionToolParam]] = None,
        tool_choice: Optional[ChatCompletionToolChoiceOptionParam] = None,
        parallel_tool_calls: Optional[bool] = None,
        response_format: Optional[ResponseFormatParam] = None,
        stream_options: Optional[StreamOptionsParam] = None,
        logprobs: Optional[bool] = None,
        top_logprobs: Optional[int] = None,
        logit_bias: Optional[Dict[str, float]] = None,
        user: Optional[str] = None,
        web_search_options: Optional[Dict[str, Any]] = None,
        verbosity: Optional[str] = None,
        prompt_cache_key: Optional[str] = None,
        safety_identifier: Optional[str] = None,
        gateway: Optional[Union[GatewayOptions, Dict[str, Any]]] = None,
        extensions: Optional[Union[Extensions, Dict[str, Any]]] = None,
        extra_body: Optional[Dict[str, Any]] = None,
    ) -> Union[ChatCompletion, Stream[ChatCompletionChunk]]:
        body = _build_chat_body(
            messages=messages, model=model, stream=stream,
            temperature=temperature, top_p=top_p, max_tokens=max_tokens,
            max_completion_tokens=max_completion_tokens,
            reasoning_effort=reasoning_effort,
            frequency_penalty=frequency_penalty,
            presence_penalty=presence_penalty,
            top_k=top_k, min_p=min_p, top_a=top_a,
            repetition_penalty=repetition_penalty,
            stop=stop, seed=seed, n=n,
            tools=tools, tool_choice=tool_choice,
            parallel_tool_calls=parallel_tool_calls,
            response_format=response_format, stream_options=stream_options,
            logprobs=logprobs, top_logprobs=top_logprobs,
            logit_bias=logit_bias, user=user,
            web_search_options=web_search_options,
            verbosity=verbosity,
            prompt_cache_key=prompt_cache_key,
            safety_identifier=safety_identifier,
            gateway=gateway, extensions=extensions,
            extra_body=extra_body,
        )

        if stream:
            response = self._client._request_stream(
                "POST", "chat/completions", body=body
            )
            return Stream(response=response, cast_to=ChatCompletionChunk)

        response = self._client._request("POST", "chat/completions", body=body)
        result = self._client._parse_response(response, ChatCompletion)
        result._response_headers = ResponseHeaders(response.headers)
        return result


class AsyncCompletions:
    """Asynchronous chat completions resource."""

    def __init__(self, client: AsyncClient) -> None:
        self._client = client

    @overload
    async def create(
        self,
        *,
        messages: Iterable[ChatCompletionMessageParam],
        model: Optional[str] = ...,
        stream: Literal[False] = ...,
        temperature: Optional[float] = ...,
        top_p: Optional[float] = ...,
        max_tokens: Optional[int] = ...,
        max_completion_tokens: Optional[int] = ...,
        reasoning_effort: Optional[Literal['low', 'medium', 'high', 'xhigh', 'max', 'off']] = ...,
        frequency_penalty: Optional[float] = ...,
        presence_penalty: Optional[float] = ...,
        top_k: Optional[int] = ...,
        min_p: Optional[float] = ...,
        top_a: Optional[float] = ...,
        repetition_penalty: Optional[float] = ...,
        stop: Optional[Union[str, List[str]]] = ...,
        seed: Optional[int] = ...,
        n: Optional[int] = ...,
        tools: Optional[Iterable[ChatCompletionToolParam]] = ...,
        tool_choice: Optional[ChatCompletionToolChoiceOptionParam] = ...,
        parallel_tool_calls: Optional[bool] = ...,
        response_format: Optional[ResponseFormatParam] = ...,
        stream_options: Optional[StreamOptionsParam] = ...,
        logprobs: Optional[bool] = ...,
        top_logprobs: Optional[int] = ...,
        logit_bias: Optional[Dict[str, float]] = ...,
        user: Optional[str] = ...,
        web_search_options: Optional[Dict[str, Any]] = ...,
        verbosity: Optional[str] = ...,
        prompt_cache_key: Optional[str] = ...,
        safety_identifier: Optional[str] = ...,
        gateway: Optional[Union[GatewayOptions, Dict[str, Any]]] = ...,
        extensions: Optional[Union[Extensions, Dict[str, Any]]] = ...,
        extra_body: Optional[Dict[str, Any]] = ...,
    ) -> ChatCompletion: ...

    @overload
    async def create(
        self,
        *,
        messages: Iterable[ChatCompletionMessageParam],
        model: Optional[str] = ...,
        stream: Literal[True],
        temperature: Optional[float] = ...,
        top_p: Optional[float] = ...,
        max_tokens: Optional[int] = ...,
        max_completion_tokens: Optional[int] = ...,
        reasoning_effort: Optional[Literal['low', 'medium', 'high', 'xhigh', 'max', 'off']] = ...,
        frequency_penalty: Optional[float] = ...,
        presence_penalty: Optional[float] = ...,
        top_k: Optional[int] = ...,
        min_p: Optional[float] = ...,
        top_a: Optional[float] = ...,
        repetition_penalty: Optional[float] = ...,
        stop: Optional[Union[str, List[str]]] = ...,
        seed: Optional[int] = ...,
        n: Optional[int] = ...,
        tools: Optional[Iterable[ChatCompletionToolParam]] = ...,
        tool_choice: Optional[ChatCompletionToolChoiceOptionParam] = ...,
        parallel_tool_calls: Optional[bool] = ...,
        response_format: Optional[ResponseFormatParam] = ...,
        stream_options: Optional[StreamOptionsParam] = ...,
        logprobs: Optional[bool] = ...,
        top_logprobs: Optional[int] = ...,
        logit_bias: Optional[Dict[str, float]] = ...,
        user: Optional[str] = ...,
        web_search_options: Optional[Dict[str, Any]] = ...,
        verbosity: Optional[str] = ...,
        prompt_cache_key: Optional[str] = ...,
        safety_identifier: Optional[str] = ...,
        gateway: Optional[Union[GatewayOptions, Dict[str, Any]]] = ...,
        extensions: Optional[Union[Extensions, Dict[str, Any]]] = ...,
        extra_body: Optional[Dict[str, Any]] = ...,
    ) -> AsyncStream[ChatCompletionChunk]: ...

    async def create(
        self,
        *,
        messages: Iterable[ChatCompletionMessageParam],
        model: Optional[str] = None,
        stream: bool = False,
        temperature: Optional[float] = None,
        top_p: Optional[float] = None,
        max_tokens: Optional[int] = None,
        max_completion_tokens: Optional[int] = None,
        reasoning_effort: Optional[Literal['low', 'medium', 'high', 'xhigh', 'max', 'off']] = None,
        frequency_penalty: Optional[float] = None,
        presence_penalty: Optional[float] = None,
        top_k: Optional[int] = None,
        min_p: Optional[float] = None,
        top_a: Optional[float] = None,
        repetition_penalty: Optional[float] = None,
        stop: Optional[Union[str, List[str]]] = None,
        seed: Optional[int] = None,
        n: Optional[int] = None,
        tools: Optional[Iterable[ChatCompletionToolParam]] = None,
        tool_choice: Optional[ChatCompletionToolChoiceOptionParam] = None,
        parallel_tool_calls: Optional[bool] = None,
        response_format: Optional[ResponseFormatParam] = None,
        stream_options: Optional[StreamOptionsParam] = None,
        logprobs: Optional[bool] = None,
        top_logprobs: Optional[int] = None,
        logit_bias: Optional[Dict[str, float]] = None,
        user: Optional[str] = None,
        web_search_options: Optional[Dict[str, Any]] = None,
        verbosity: Optional[str] = None,
        prompt_cache_key: Optional[str] = None,
        safety_identifier: Optional[str] = None,
        gateway: Optional[Union[GatewayOptions, Dict[str, Any]]] = None,
        extensions: Optional[Union[Extensions, Dict[str, Any]]] = None,
        extra_body: Optional[Dict[str, Any]] = None,
    ) -> Union[ChatCompletion, AsyncStream[ChatCompletionChunk]]:
        body = _build_chat_body(
            messages=messages, model=model, stream=stream,
            temperature=temperature, top_p=top_p, max_tokens=max_tokens,
            max_completion_tokens=max_completion_tokens,
            reasoning_effort=reasoning_effort,
            frequency_penalty=frequency_penalty,
            presence_penalty=presence_penalty,
            top_k=top_k, min_p=min_p, top_a=top_a,
            repetition_penalty=repetition_penalty,
            stop=stop, seed=seed, n=n,
            tools=tools, tool_choice=tool_choice,
            parallel_tool_calls=parallel_tool_calls,
            response_format=response_format, stream_options=stream_options,
            logprobs=logprobs, top_logprobs=top_logprobs,
            logit_bias=logit_bias, user=user,
            web_search_options=web_search_options,
            verbosity=verbosity,
            prompt_cache_key=prompt_cache_key,
            safety_identifier=safety_identifier,
            gateway=gateway, extensions=extensions,
            extra_body=extra_body,
        )

        if stream:
            response = await self._client._request_stream(
                "POST", "chat/completions", body=body
            )
            return AsyncStream(response=response, cast_to=ChatCompletionChunk)

        response = await self._client._request(
            "POST", "chat/completions", body=body
        )
        result = self._client._parse_response(response, ChatCompletion)
        result._response_headers = ResponseHeaders(response.headers)
        return result


class Chat:
    """Sync chat resource — mirrors OpenAI SDK: client.chat.completions.create()."""

    def __init__(self, client: Client) -> None:
        self.completions = Completions(client)


class AsyncChat:
    """Async chat resource."""

    def __init__(self, client: AsyncClient) -> None:
        self.completions = AsyncCompletions(client)


def _build_chat_body(
    *,
    messages: Iterable[ChatCompletionMessageParam],
    model: Optional[str],
    stream: bool,
    temperature: Optional[float],
    top_p: Optional[float],
    max_tokens: Optional[int],
    max_completion_tokens: Optional[int],
    reasoning_effort: Optional[Literal['low', 'medium', 'high', 'xhigh', 'max', 'off']],
    frequency_penalty: Optional[float],
    presence_penalty: Optional[float],
    top_k: Optional[int],
    min_p: Optional[float],
    top_a: Optional[float],
    repetition_penalty: Optional[float],
    stop: Optional[Union[str, List[str]]],
    seed: Optional[int],
    n: Optional[int],
    tools: Optional[Iterable[ChatCompletionToolParam]],
    tool_choice: Optional[ChatCompletionToolChoiceOptionParam],
    parallel_tool_calls: Optional[bool],
    response_format: Optional[ResponseFormatParam],
    stream_options: Optional[StreamOptionsParam],
    logprobs: Optional[bool],
    top_logprobs: Optional[int],
    logit_bias: Optional[Dict[str, float]],
    user: Optional[str],
    web_search_options: Optional[Dict[str, Any]],
    verbosity: Optional[str],
    prompt_cache_key: Optional[str],
    safety_identifier: Optional[str],
    gateway: Optional[Union[GatewayOptions, Dict[str, Any]]],
    extensions: Optional[Union[Extensions, Dict[str, Any]]],
    extra_body: Optional[Dict[str, Any]],
) -> Dict[str, Any]:
    """Build the request body, only including non-None fields.

    Validation runs before extra_body merge — model/gateway.models cannot be
    supplied via extra_body.
    """
    # Materialize iterables (generators, filter(), etc.) for JSON serialization.
    messages_list = list(messages)
    tools_list = list(tools) if tools is not None else None

    # Normalize gateway to a dict (may be GatewayOptions or raw dict).
    gateway_dict: Optional[Dict[str, Any]] = None
    if gateway is not None:
        if isinstance(gateway, GatewayOptions):
            dumped = gateway.model_dump(exclude_unset=True, exclude_none=True, mode="json")
            gateway_dict = dumped or None
        else:
            gateway_dict = gateway if gateway else None

    validate_model_or_gateway(model, gateway_dict)

    body: Dict[str, Any] = {"messages": messages_list}
    if model is not None:
        body["model"] = model

    if isinstance(extensions, Extensions):
        extensions = extensions.model_dump(exclude_unset=True, exclude_none=True, mode="json")

    for key, value in [
        ("temperature", temperature),
        ("top_p", top_p),
        ("max_tokens", max_tokens),
        ("max_completion_tokens", max_completion_tokens),
        ("reasoning_effort", reasoning_effort),
        ("frequency_penalty", frequency_penalty),
        ("presence_penalty", presence_penalty),
        ("top_k", top_k),
        ("min_p", min_p),
        ("top_a", top_a),
        ("repetition_penalty", repetition_penalty),
        ("stop", stop),
        ("seed", seed),
        ("n", n),
        ("tools", tools_list),
        ("tool_choice", tool_choice),
        ("parallel_tool_calls", parallel_tool_calls),
        ("response_format", response_format),
        ("stream_options", stream_options),
        ("logprobs", logprobs),
        ("top_logprobs", top_logprobs),
        ("logit_bias", logit_bias),
        ("user", user),
        ("web_search_options", web_search_options),
        ("verbosity", verbosity),
        ("prompt_cache_key", prompt_cache_key),
        ("safety_identifier", safety_identifier),
        ("extensions", extensions),
    ]:
        if value is not None:
            body[key] = value

    if gateway_dict:
        body["gateway"] = gateway_dict

    # Gateway-aware extra_body merge — one-level-deep on `gateway` so a caller-
    # supplied extra_body={"gateway": {...}} does not clobber the typed `gateway=`
    # parameter's sibling keys. Shared utility with the framework adapters so
    # conflict policy and non-dict fallback stay in a single source of truth.
    if extra_body:
        body = merge_gateway_extra_body(body, extra_body)

    # stream flag must match transport selection — always set last so
    # extra_body cannot contradict the stream parameter.
    if stream:
        body["stream"] = True
    else:
        body.pop("stream", None)

    return body
