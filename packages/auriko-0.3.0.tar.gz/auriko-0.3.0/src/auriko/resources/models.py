"""Models resource — model discovery and retrieval endpoints."""

from __future__ import annotations

from typing import TYPE_CHECKING

from ..models.providers import DirectoryResponse, Model, ModelList, ModelsListResponse, ProviderList

if TYPE_CHECKING:
    from .._client import AsyncClient, Client


class Models:
    def __init__(self, client: Client) -> None:
        self._client = client

    def list(self) -> ModelList:
        response = self._client._request("GET", "models")
        return self._client._parse_response(response, ModelList)

    def retrieve(self, model_id: str) -> Model:
        response = self._client._request("GET", f"models/{model_id}")
        return self._client._parse_response(response, Model)

    def list_directory(self) -> DirectoryResponse:
        response = self._client._request("GET", "directory/models")
        return self._client._parse_response(response, DirectoryResponse)

    def list_registry(self) -> ModelsListResponse:
        response = self._client._request("GET", "registry/models")
        return self._client._parse_response(response, ModelsListResponse)

    def list_providers(self) -> ProviderList:
        response = self._client._request("GET", "registry/providers")
        return self._client._parse_response(response, ProviderList)


class AsyncModels:
    def __init__(self, client: AsyncClient) -> None:
        self._client = client

    async def list(self) -> ModelList:
        response = await self._client._request("GET", "models")
        return self._client._parse_response(response, ModelList)

    async def retrieve(self, model_id: str) -> Model:
        response = await self._client._request("GET", f"models/{model_id}")
        return self._client._parse_response(response, Model)

    async def list_directory(self) -> DirectoryResponse:
        response = await self._client._request("GET", "directory/models")
        return self._client._parse_response(response, DirectoryResponse)

    async def list_registry(self) -> ModelsListResponse:
        response = await self._client._request("GET", "registry/models")
        return self._client._parse_response(response, ModelsListResponse)

    async def list_providers(self) -> ProviderList:
        response = await self._client._request("GET", "registry/providers")
        return self._client._parse_response(response, ProviderList)
