from __future__ import annotations

from typing import Any, Dict, Optional

from .errors.types import BadRequestError


def validate_model_or_gateway(
    model: Optional[str],
    gateway_dict: Optional[Dict[str, Any]],
) -> None:
    gateway_models = gateway_dict.get("models") if gateway_dict else None
    if model is not None and gateway_models is not None:
        raise BadRequestError(
            message="Cannot specify both 'model' and 'gateway.models'.",
            status_code=400,
            type="invalid_request_error",
            code="invalid_parameter_value",
            param="gateway.models",
        )
    if model is None and gateway_models is None:
        raise BadRequestError(
            message="Must specify either 'model' or 'gateway.models'.",
            status_code=400,
            type="invalid_request_error",
            code="missing_required_parameter",
            param="model",
        )
