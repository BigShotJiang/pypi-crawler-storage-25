"""Shared non-I/O logic for Client and AsyncClient."""

from __future__ import annotations

import os
import random
from typing import Any, Mapping, Optional, TypeVar

import httpx

from ._version import __version__
from .errors.mapping import _map_error_from_envelope
from .errors.types import APIStatusError, AurikoAPIError, AuthenticationError
from .response_headers import ResponseHeaders

T = TypeVar("T")

_DEFAULT_BASE_URL = "https://api.auriko.ai/v1"
_DEFAULT_TIMEOUT = 60.0
_DEFAULT_MAX_RETRIES = 2

_INITIAL_RETRY_DELAY = 0.5
_RETRY_DELAY_MULTIPLIER = 1.5
_MAX_RETRY_DELAY = 30.0


class BaseClient:
    """Shared configuration and pure-logic helpers for sync and async clients."""

    api_key: str
    base_url: str
    timeout: float
    max_retries: int

    def __init__(
        self,
        *,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: Optional[float] = None,
        max_retries: Optional[int] = None,
    ) -> None:
        resolved_key = api_key or os.environ.get("AURIKO_API_KEY")
        if not resolved_key:
            raise AuthenticationError(
                message="API key is missing. Set AURIKO_API_KEY or pass api_key=.",
                status_code=0,
                type="authentication_error",
                code="missing_api_key",
            )
        self.api_key = resolved_key

        url = (base_url or _DEFAULT_BASE_URL).rstrip("/")
        if not url.endswith("/v1"):
            url += "/v1"
        self.base_url = url + "/"

        self.timeout = timeout if timeout is not None else _DEFAULT_TIMEOUT
        self.max_retries = max_retries if max_retries is not None else _DEFAULT_MAX_RETRIES

    @property
    def _default_headers(self) -> dict[str, str]:
        return {
            "Authorization": f"Bearer {self.api_key}",
            "User-Agent": f"auriko-python/{__version__}",
        }

    @staticmethod
    def _calculate_retry_delay(
        attempt: int,
        retry_after_header: Optional[str] = None,
    ) -> float:
        delay = _INITIAL_RETRY_DELAY * (_RETRY_DELAY_MULTIPLIER ** attempt)
        delay = min(delay, _MAX_RETRY_DELAY)
        delay *= 0.8 + random.random() * 0.4

        if retry_after_header is not None:
            try:
                retry_after = float(retry_after_header)
                delay = max(delay, retry_after)
            except (ValueError, OverflowError):
                pass

        return delay

    def _make_error(
        self,
        status_code: int,
        body: Any,
        *,
        headers: Optional[Mapping[str, str]] = None,
    ) -> AurikoAPIError:
        """Create a typed error from an HTTP error response via strict envelope dispatch."""
        response_headers = ResponseHeaders(headers) if headers is not None else None
        return _map_error_from_envelope(
            status_code, body, response_headers=response_headers,
        )

    def _parse_response(self, response: httpx.Response, cast_to: type[T]) -> T:
        """Parse response JSON and validate against a Pydantic model."""
        try:
            data = response.json()
        except Exception as e:
            raise APIStatusError(
                message="Response body is not valid JSON.",
                status_code=response.status_code,
                type="api_error",
                code="invalid_response",
                response_headers=ResponseHeaders(response.headers),
            ) from e
        return cast_to.model_validate(data)  # type: ignore[union-attr]
