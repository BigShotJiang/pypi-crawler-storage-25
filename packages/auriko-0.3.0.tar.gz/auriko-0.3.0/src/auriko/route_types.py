"""Auriko routing models — public API for routing configuration and metadata.

Field names mirror the Auriko API schema.
"""

from __future__ import annotations

import math
from enum import Enum
from typing import Any, Dict, List, Optional, Union

from pydantic import BaseModel, ConfigDict, Field, ValidationError, model_validator

from .models.base import AurikoResponseModel
from .types.chat_params import AurikoMetadataParam


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

class Optimize(str, Enum):
    """Optimization strategy for provider selection."""

    COST = "cost"
    COST_FOCUS = "cost-focus"
    TTFT = "ttft"
    TTFT_FOCUS = "ttft-focus"
    TPS = "tps"
    TPS_FOCUS = "tps-focus"
    BALANCED = "balanced"


class Mode(str, Enum):
    """How to interpret the models array."""

    POOL = "pool"
    FALLBACK = "fallback"


class DataPolicy(str, Enum):
    """Data retention policy requirement."""

    NONE = "none"
    NO_TRAINING = "no_training"
    ZDR = "zdr"


class MetricPercentile(str, Enum):
    """Which percentile to use for TTFT and throughput metrics in scoring."""

    P50 = "p50"
    P95 = "p95"


# ---------------------------------------------------------------------------
# RoutingOptions — 20 fields
# ---------------------------------------------------------------------------

class RoutingOptions(BaseModel):
    """Auriko routing configuration (20 fields).

    All fields default to None. Only explicitly-set fields are serialized
    (via to_dict() or to_extra_body()); unset fields default server-side.

    ``extra='forbid'`` — unknown keys raise ``ValidationError`` at construction,
    so typos (e.g. ``RoutingOptions(optimise=...)``) are loud rather than silently
    dropped. Callers who need to pass unknown keys can use the raw-dict escape
    hatch at the ``gateway=`` kwarg; Pydantic's smart-Union falls through to
    ``Dict[str, Any]`` on failed strict validation, preserving the dict as-is.
    """

    model_config = ConfigDict(extra='forbid')

    optimize: Optional[Optimize] = None
    weights: Optional[Dict[str, float]] = None
    max_cost_per_1m: Optional[float] = Field(default=None, gt=0)
    max_ttft_ms: Optional[int] = Field(default=None, gt=0)
    min_throughput_tps: Optional[float] = Field(default=None, gt=0)
    ttft_percentile: Optional[MetricPercentile] = None
    throughput_percentile: Optional[MetricPercentile] = None
    providers: Optional[List[str]] = None
    exclude_providers: Optional[List[str]] = None
    prefer: Optional[str] = None
    mode: Optional[Mode] = None
    allow_fallbacks: Optional[bool] = None
    max_fallback_attempts: Optional[int] = Field(default=None, ge=1, le=19)
    timeout_ms: Optional[int] = Field(default=None, gt=0)
    deadline_ms: Optional[int] = Field(default=None, gt=0)
    data_policy: Optional[DataPolicy] = None
    only_byok: Optional[bool] = None
    only_platform: Optional[bool] = None
    # When True, only route to providers that accept all optional params sent in the request.
    require_parameters: Optional[bool] = None
    tier: Optional[str] = None

    @model_validator(mode="after")
    def _validate_constraints(self) -> RoutingOptions:
        if self.only_byok and self.only_platform:
            raise ValueError("only_byok and only_platform are mutually exclusive")
        if self.weights is not None:
            valid_keys = {'cost', 'ttft', 'throughput'}
            for key in self.weights:
                if key not in valid_keys:
                    raise ValueError(
                        f"Unknown weight key '{key}'. Valid: {', '.join(sorted(valid_keys))}"
                    )
                if not isinstance(self.weights[key], (int, float)) or not math.isfinite(self.weights[key]) or self.weights[key] < 0:
                    raise ValueError(f"Weight '{key}' must be a non-negative finite number")
            if not any(v > 0 for v in self.weights.values()):
                raise ValueError("At least one weight must be > 0")
        if self.timeout_ms is not None and self.deadline_ms is not None:
            if self.deadline_ms < self.timeout_ms:
                raise ValueError("deadline_ms must be >= timeout_ms")
        return self

    def to_dict(self) -> dict | None:
        """Serialize to flat dict for request body. Returns None if empty."""
        d = self.model_dump(exclude_unset=True, exclude_none=True, mode="json")
        return d or None

    def to_extra_body(self) -> dict:
        """Return dict suitable for OpenAI SDK's extra_body parameter.

        Emits {"gateway": {"routing": ...}}. Only includes
        fields the user explicitly set; excludes None values for clean
        serialization (null values are omitted).
        """
        return {"gateway": {"routing": self.model_dump(exclude_unset=True, exclude_none=True, mode="json")}}


# ---------------------------------------------------------------------------
# GatewayOptions — typed wrapper over the `gateway` body namespace
# ---------------------------------------------------------------------------

class GatewayOptions(BaseModel):
    """Typed gateway directives — represents Auriko-specific request parameters.

    All three fields are optional. Only explicitly-set fields are serialized
    via to_extra_body(); unset fields default server-side.

    ``extra='forbid'`` — unknown keys raise ``ValidationError`` at construction,
    consistent with ``RoutingOptions``. Callers who need to pass unknown keys
    can use the raw-dict escape hatch at the ``gateway=`` kwarg.
    """

    model_config = ConfigDict(extra='forbid')

    routing: Optional[Union[RoutingOptions, Dict[str, Any]]] = None
    metadata: Optional[AurikoMetadataParam] = Field(
        default=None,
        description="Request metadata. Accepts only: tags, user_id, trace_id, custom_fields. Use custom_fields for arbitrary key-value pairs.",
    )
    models: Optional[List[str]] = None

    def to_extra_body(self) -> dict:
        """Return dict suitable for OpenAI SDK's extra_body parameter.

        Emits {"gateway": {...}}. Only includes fields the user explicitly set;
        nested RoutingOptions is likewise dumped with exclude_unset/exclude_none.
        """
        gw = self.model_dump(exclude_unset=True, exclude_none=True, mode="json")
        return {"gateway": gw} if gw else {}


def merge_gateway_extra_body(base: dict, overlay: dict) -> dict:
    """Shallow-merge two dicts, merging the ``gateway`` key one level deep so
    its sibling children (``routing``, ``metadata``, ``models``) survive.

    Contract: if both ``base`` and ``overlay`` contain a ``gateway`` dict, their
    immediate children are merged — so ``base.gateway.routing`` and
    ``overlay.gateway.metadata`` both appear in the result. When a child key
    exists in both (e.g. both have ``routing``), **overlay wins completely**;
    nested dicts are NOT recursively merged. All other top-level keys merge
    shallowly, with ``overlay`` winning on conflicts.

    If either side's ``gateway`` value is not a dict, falls back to shallow
    merge and lets the server validate. ``extra_body`` is an escape hatch; the
    SDK does not assume well-formed values and refuses to crash with a
    ``TypeError`` on malformed input.
    """
    if 'gateway' not in base or 'gateway' not in overlay:
        return {**base, **overlay}
    if not isinstance(base['gateway'], dict) or not isinstance(overlay['gateway'], dict):
        return {**base, **overlay}
    merged_gateway = {**base['gateway'], **overlay['gateway']}
    return {**base, **overlay, 'gateway': merged_gateway}


# ---------------------------------------------------------------------------
# Response metadata models
# ---------------------------------------------------------------------------

class CostInfo(AurikoResponseModel):
    """Cost breakdown for a request."""

    usd: float
    cache_savings_percent: Optional[int] = None
    cache_savings_usd: Optional[float] = None


class StructuredWarningType(str, Enum):
    """Category of a structured warning emitted in routing_metadata.warnings."""

    UNSUPPORTED_PARAMETER = "unsupported_parameter"
    UNSUPPORTED_FEATURE = "unsupported_feature"
    UNSUPPORTED_FIELD = "unsupported_field"
    IGNORED_EXTENSION = "ignored_extension"
    UNKNOWN_PROVIDER = "unknown_provider"
    BLOCKED_FIELD = "blocked_field"
    PROVIDER_TIMEOUT = "provider_timeout"


class StructuredWarning(AurikoResponseModel):
    """Structured warning emitted by the gateway when it modifies or ignores part of a request.

    Represents warnings from the router when it modifies or ignores part of a request.
    """

    type: StructuredWarningType
    code: str
    message: str


class RoutingMetadata(AurikoResponseModel):
    """Routing decision metadata included in successful responses."""

    provider: str
    provider_model_id: str
    model_canonical: str
    routing_strategy: str

    cost: Optional[CostInfo] = None
    ttft_ms: Optional[float] = None
    throughput_tps: Optional[float] = None
    warnings: Optional[List[StructuredWarning]] = None


# ---------------------------------------------------------------------------
# Metadata extraction
# ---------------------------------------------------------------------------

def parse_routing_metadata(response: Any) -> Optional[RoutingMetadata]:
    """Extract routing_metadata from an OpenAI SDK response.

    Returns None if routing_metadata is absent or unparseable.
    Metadata is informational — parsing failures should not crash requests.
    """
    raw = getattr(response, "model_extra", None)
    if not isinstance(raw, dict):
        return None
    metadata = raw.get("routing_metadata")
    if metadata is None:
        return None
    try:
        return RoutingMetadata.model_validate(metadata)
    except ValidationError:
        return None
