"""Auriko SDK — Intelligent LLM routing."""

from ._client import AsyncClient, Client
from ._version import __version__
from .errors import (
    APIConnectionError,
    APIStatusError,
    AurikoAPIError,
    AuthenticationError,
    BadRequestError,
    ConflictError,
    InternalServerError,
    NotFoundError,
    PermissionDeniedError,
    RateLimitError,
    map_openai_error,
)
from .response_headers import ResponseHeaders
from ._streaming import AsyncStream, Stream
from ._response_streaming import AsyncResponseStream, ResponseStream
from .route_types import parse_routing_metadata

try:
    from ._openai_client import AurikoAsyncOpenAI
except ModuleNotFoundError:
    pass  # Available with: pip install auriko[openai-compat]
