"""Common response models shared across resources."""

from __future__ import annotations

from typing import Literal, Optional

from .base import AurikoResponseModel


class PromptTokensDetails(AurikoResponseModel):
    cached_tokens: Optional[int] = None
    text_tokens: Optional[int] = None
    image_tokens: Optional[int] = None
    audio_tokens: Optional[int] = None
    cache_creation_tokens: Optional[int] = None


class CompletionTokensDetails(AurikoResponseModel):
    reasoning_tokens: Optional[int] = None
    text_tokens: Optional[int] = None
    image_tokens: Optional[int] = None
    audio_tokens: Optional[int] = None
    accepted_prediction_tokens: Optional[int] = None
    rejected_prediction_tokens: Optional[int] = None


class Usage(AurikoResponseModel):
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int
    prompt_tokens_details: Optional[PromptTokensDetails] = None
    completion_tokens_details: Optional[CompletionTokensDetails] = None


class ApiKeyIdentity(AurikoResponseModel):
    object: Literal["api_key_identity"] = "api_key_identity"
    user_id: Optional[str] = None
    workspace_id: Optional[str] = None
    tier: Optional[str] = None
    rate_limit_rpm: Optional[int] = None
