"""Response API response models and stream event types."""

from __future__ import annotations

from typing import TYPE_CHECKING, Annotated, Any, Dict, List, Literal, Optional, Union

from pydantic import PrivateAttr, ValidationError
from pydantic.functional_validators import BeforeValidator

from .base import AurikoResponseModel
from ..route_types import RoutingMetadata

if TYPE_CHECKING:
    from ..response_headers import ResponseHeaders



class ResponseInputTokensDetails(AurikoResponseModel):
    cached_tokens: int = 0


class ResponseOutputTokensDetails(AurikoResponseModel):
    reasoning_tokens: int = 0
    image_tokens: int = 0


class ResponseUsage(AurikoResponseModel):
    """Response API usage — input_tokens/output_tokens shape."""

    input_tokens: int
    output_tokens: int
    total_tokens: int
    input_tokens_details: Optional[ResponseInputTokensDetails] = None
    output_tokens_details: Optional[ResponseOutputTokensDetails] = None



class ResponseOutputContentPart(AurikoResponseModel):
    type: Literal["output_text"]
    text: str
    annotations: List[Any] = []
    logprobs: Optional[List[Any]] = None


class ResponseMessageOutputItem(AurikoResponseModel):
    type: Literal["message"]
    id: str
    role: Literal["assistant"]
    status: Literal["in_progress", "completed", "incomplete"]
    content: List[ResponseOutputContentPart]


class ResponseFunctionCallOutputItem(AurikoResponseModel):
    type: Literal["function_call"]
    id: str
    call_id: str
    name: str
    arguments: str
    status: Literal["in_progress", "completed", "incomplete"]


class ResponseReasoningSummary(AurikoResponseModel):
    type: Literal["summary_text"]
    text: str


class ResponseReasoningOutputItem(AurikoResponseModel):
    type: Literal["reasoning"]
    id: str
    summary: List[ResponseReasoningSummary]
    status: Optional[Literal["in_progress", "completed", "incomplete"]] = None


class ResponseImageGenerationCallOutputItem(AurikoResponseModel):
    type: Literal["image_generation_call"]
    id: str
    status: Literal["in_progress", "completed", "generating", "failed"]
    result: Optional[str] = None


class UnknownOutputItem(AurikoResponseModel):
    """Fallback for native hosted-tool output items (e.g., web_search_call, file_search_call)."""

    type: str
    data: Dict[str, Any] = {}


_OUTPUT_ITEM_TYPE_MAP: Dict[str, type] = {
    "message": ResponseMessageOutputItem,
    "function_call": ResponseFunctionCallOutputItem,
    "reasoning": ResponseReasoningOutputItem,
    "image_generation_call": ResponseImageGenerationCallOutputItem,
}


def _parse_output_item(data: Any) -> Any:
    if not isinstance(data, dict):
        return data
    item_type = data.get("type")
    if not isinstance(item_type, str):
        return UnknownOutputItem(type="unknown", data=data)
    model_cls = _OUTPUT_ITEM_TYPE_MAP.get(item_type)
    if model_cls is None:
        return UnknownOutputItem(type=item_type, data=data)
    try:
        return model_cls.model_validate(data)
    except ValidationError:
        return UnknownOutputItem(type=item_type, data=data)


ResponseOutputItem = Annotated[
    Union[ResponseMessageOutputItem, ResponseFunctionCallOutputItem, ResponseReasoningOutputItem, ResponseImageGenerationCallOutputItem, UnknownOutputItem],
    BeforeValidator(_parse_output_item),
]



class ResponseError(AurikoResponseModel):
    code: str
    message: str
    type: Optional[str] = None
    param: Optional[str] = None
    doc_url: Optional[str] = None
    provider: Optional[str] = None
    suggestion: Optional[str] = None


class Response(AurikoResponseModel):
    """Complete non-streaming Response API response."""

    id: str
    object: Literal["response"] = "response"
    created_at: int
    model: str
    status: Literal["completed", "failed", "incomplete", "in_progress"]
    output: List[ResponseOutputItem]
    output_text: str = ""
    parallel_tool_calls: bool = True
    tool_choice: Any = "auto"
    tools: List[Any] = []
    usage: Optional[ResponseUsage] = None
    error: Optional[ResponseError] = None
    incomplete_details: Optional[Dict[str, str]] = None
    metadata: Optional[Dict[str, str]] = None
    routing_metadata: Optional[RoutingMetadata] = None

    _response_headers: Optional[ResponseHeaders] = PrivateAttr(default=None)

    @property
    def response_headers(self) -> Optional[ResponseHeaders]:
        return self._response_headers



class ResponseCreatedEvent(AurikoResponseModel):
    type: Literal["response.created"]
    sequence_number: int
    response: Response


class ResponseInProgressEvent(AurikoResponseModel):
    type: Literal["response.in_progress"]
    sequence_number: int
    response: Response


class ResponseCompletedEvent(AurikoResponseModel):
    type: Literal["response.completed"]
    sequence_number: int
    response: Response


class ResponseIncompleteEvent(AurikoResponseModel):
    type: Literal["response.incomplete"]
    sequence_number: int
    response: Response


class ResponseFailedEvent(AurikoResponseModel):
    type: Literal["response.failed"]
    sequence_number: int
    response: Response


class ResponseOutputItemAddedEvent(AurikoResponseModel):
    type: Literal["response.output_item.added"]
    sequence_number: int
    output_index: int
    item: ResponseOutputItem


class ResponseOutputItemDoneEvent(AurikoResponseModel):
    type: Literal["response.output_item.done"]
    sequence_number: int
    output_index: int
    item: ResponseOutputItem


class ResponseContentPartAddedEvent(AurikoResponseModel):
    type: Literal["response.content_part.added"]
    sequence_number: int
    item_id: str
    output_index: int
    content_index: int
    part: ResponseOutputContentPart


class ResponseContentPartDoneEvent(AurikoResponseModel):
    type: Literal["response.content_part.done"]
    sequence_number: int
    item_id: str
    output_index: int
    content_index: int
    part: ResponseOutputContentPart


class ResponseTextDeltaEvent(AurikoResponseModel):
    type: Literal["response.output_text.delta"]
    sequence_number: int
    item_id: str
    output_index: int
    content_index: int
    delta: str
    logprobs: List[Any] = []


class ResponseTextDoneEvent(AurikoResponseModel):
    type: Literal["response.output_text.done"]
    sequence_number: int
    item_id: str
    output_index: int
    content_index: int
    text: str
    logprobs: List[Any] = []


class ResponseReasoningSummaryPartAddedEvent(AurikoResponseModel):
    type: Literal["response.reasoning_summary_part.added"]
    sequence_number: int
    item_id: str
    output_index: int
    summary_index: int
    part: ResponseReasoningSummary


class ResponseReasoningSummaryPartDoneEvent(AurikoResponseModel):
    type: Literal["response.reasoning_summary_part.done"]
    sequence_number: int
    item_id: str
    output_index: int
    summary_index: int
    part: ResponseReasoningSummary


class ResponseReasoningSummaryTextDeltaEvent(AurikoResponseModel):
    type: Literal["response.reasoning_summary_text.delta"]
    sequence_number: int
    item_id: str
    output_index: int
    summary_index: int
    delta: str


class ResponseReasoningSummaryTextDoneEvent(AurikoResponseModel):
    type: Literal["response.reasoning_summary_text.done"]
    sequence_number: int
    item_id: str
    output_index: int
    summary_index: int
    text: str


class ResponseFunctionCallArgumentsDeltaEvent(AurikoResponseModel):
    type: Literal["response.function_call_arguments.delta"]
    sequence_number: int
    item_id: str
    output_index: int
    delta: str


class ResponseFunctionCallArgumentsDoneEvent(AurikoResponseModel):
    type: Literal["response.function_call_arguments.done"]
    sequence_number: int
    item_id: str
    output_index: int
    arguments: str
    name: Optional[str] = None


class ResponseErrorEvent(AurikoResponseModel):
    """Mid-stream error event — flat format without an envelope wrapper."""

    type: Literal["error"]
    sequence_number: Optional[int] = None
    code: str
    message: str
    param: Optional[str] = None
    doc_url: Optional[str] = None
    provider: Optional[str] = None
    suggestion: Optional[str] = None


class UnknownStreamEvent(AurikoResponseModel):
    """Fallback for native passthrough events or known types with validation failures."""

    type: str
    sequence_number: Optional[int] = None
    data: Dict[str, Any] = {}


ResponseStreamEvent = Union[
    ResponseCreatedEvent,
    ResponseInProgressEvent,
    ResponseCompletedEvent,
    ResponseIncompleteEvent,
    ResponseFailedEvent,
    ResponseOutputItemAddedEvent,
    ResponseOutputItemDoneEvent,
    ResponseContentPartAddedEvent,
    ResponseContentPartDoneEvent,
    ResponseTextDeltaEvent,
    ResponseTextDoneEvent,
    ResponseReasoningSummaryPartAddedEvent,
    ResponseReasoningSummaryPartDoneEvent,
    ResponseReasoningSummaryTextDeltaEvent,
    ResponseReasoningSummaryTextDoneEvent,
    ResponseFunctionCallArgumentsDeltaEvent,
    ResponseFunctionCallArgumentsDoneEvent,
    ResponseErrorEvent,
    UnknownStreamEvent,
]
