"""Chat completion request and response models."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, List, Literal, Optional, Union

from pydantic import PrivateAttr

from .base import AurikoResponseModel

from .common import Usage
from ..route_types import RoutingMetadata

if TYPE_CHECKING:
    from ..response_headers import ResponseHeaders


# --- Non-streaming response types ---


class ToolCallFunction(AurikoResponseModel):
    name: str
    arguments: str


class ToolCall(AurikoResponseModel):
    id: str
    function: ToolCallFunction
    type: Literal["function"] = "function"
    provider_signature: Optional[str] = None


class ThinkingReasoningBlock(AurikoResponseModel):
    """A reasoning block containing the model's visible thinking text."""

    type: Literal["thinking"]
    thinking: str
    signature: str


class RedactedReasoningBlock(AurikoResponseModel):
    """A reasoning block containing redacted (encrypted) thinking data."""

    type: Literal["redacted"]
    data: str


class GeneratedImage(AurikoResponseModel):
    type: Literal["image"]
    mime_type: str
    data: str
    thought_signature: Optional[str] = None


class ChoiceMessage(AurikoResponseModel):
    role: Literal["assistant"] = "assistant"
    content: Optional[str] = None
    tool_calls: Optional[List[ToolCall]] = None
    reasoning_content: Optional[str] = None
    reasoning: Optional[List[Union[ThinkingReasoningBlock, RedactedReasoningBlock]]] = None
    refusal: Optional[str] = None
    images: Optional[List[GeneratedImage]] = None
    annotations: Optional[List[Any]] = None

    def model_dump(self, *, exclude_none: bool = True, **kwargs) -> dict:
        return super().model_dump(exclude_none=exclude_none, **kwargs)

    def model_dump_json(self, *, exclude_none: bool = True, **kwargs) -> str:
        return super().model_dump_json(exclude_none=exclude_none, **kwargs)


class Choice(AurikoResponseModel):
    index: int
    message: ChoiceMessage
    finish_reason: Optional[str] = None
    logprobs: Optional[dict] = None
    native_finish_reason: Optional[str] = None


class ChatCompletion(AurikoResponseModel):
    id: str
    created: int
    model: str
    choices: List[Choice]
    object: Literal["chat.completion"] = "chat.completion"
    usage: Optional[Usage] = None
    system_fingerprint: Optional[str] = None
    routing_metadata: Optional[RoutingMetadata] = None
    service_tier: Optional[str] = None

    _response_headers: Optional[ResponseHeaders] = PrivateAttr(default=None)

    @property
    def response_headers(self) -> Optional[ResponseHeaders]:
        return self._response_headers


# --- Streaming response types ---


class ToolCallDeltaFunction(AurikoResponseModel):
    name: Optional[str] = None
    arguments: Optional[str] = None


class ToolCallDelta(AurikoResponseModel):
    index: int
    id: Optional[str] = None
    type: Literal["function"] = "function"
    function: Optional[ToolCallDeltaFunction] = None
    provider_signature: Optional[str] = None


class Delta(AurikoResponseModel):
    role: Optional[str] = None
    content: Optional[str] = None
    tool_calls: Optional[List[ToolCallDelta]] = None
    reasoning_content: Optional[str] = None
    reasoning_signature: Optional[str] = None
    reasoning_redacted_data: Optional[str] = None
    refusal: Optional[str] = None
    images: Optional[List[GeneratedImage]] = None


class StreamChoice(AurikoResponseModel):
    index: int
    delta: Delta
    finish_reason: Optional[str] = None
    logprobs: Optional[dict] = None
    native_finish_reason: Optional[str] = None


class ChatCompletionChunk(AurikoResponseModel):
    id: str
    created: int
    model: str
    choices: List[StreamChoice]
    object: Literal["chat.completion.chunk"] = "chat.completion.chunk"
    usage: Optional[Usage] = None
    system_fingerprint: Optional[str] = None
    routing_metadata: Optional[RoutingMetadata] = None
    service_tier: Optional[str] = None
