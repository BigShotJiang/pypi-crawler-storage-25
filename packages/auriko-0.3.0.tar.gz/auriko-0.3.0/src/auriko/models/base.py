"""Base model for all Auriko SDK response types."""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict


class AurikoResponseModel(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)
