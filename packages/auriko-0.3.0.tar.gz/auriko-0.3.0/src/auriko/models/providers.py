"""Model and provider response models for discovery endpoints."""

from __future__ import annotations

from typing import Dict, List, Optional

from .base import AurikoResponseModel


# --- /v1/registry/providers ---


class ProviderInfo(AurikoResponseModel):
    id: str
    display_name: str
    description: str
    icon: str
    data_policy: str


class ProviderList(AurikoResponseModel):
    providers: List[ProviderInfo]
    count: int


# --- /v1/directory/models ---


class PriceVariant(AurikoResponseModel):
    role: str
    price: float
    constraints: Dict[str, str]
    description: Optional[str] = None


class TierEntry(AurikoResponseModel):
    name: str
    input_price: Optional[float] = None
    output_price: Optional[float] = None
    cache_read_price: Optional[float] = None
    cache_write_price: Optional[float] = None
    latency_hint: Optional[str] = None
    price_variants: List[PriceVariant] = []


class ProviderEntry(AurikoResponseModel):
    provider: str
    provider_model_id: str
    context_window: Optional[int] = None
    max_output_tokens: Optional[int] = None
    capabilities: Optional[Dict[str, bool]] = None
    input_modalities: Optional[List[str]] = None
    output_modalities: Optional[List[str]] = None
    tools: Optional[List[str]] = None
    tiers: Optional[List[TierEntry]] = None
    updated_at: Optional[str] = None
    data_policy: Optional[str] = None
    accepted_params: Optional[List[str]] = None
    supported_parameters: Optional[List[str]] = None
    supported_endpoints: Optional[List[str]] = None


class DirectoryModel(AurikoResponseModel):
    family: str
    display_name: str
    providers: List[ProviderEntry]
    author: Optional[str] = None
    supported_parameters: Optional[List[str]] = None


class DirectoryResponse(AurikoResponseModel):
    models: Dict[str, DirectoryModel]
    generated_at: str


# --- /v1/registry/models ---


class CanonicalModel(AurikoResponseModel):
    id: str
    family: str
    display_name: str
    capabilities: Dict[str, bool]
    input_modalities: List[str]
    output_modalities: List[str]
    providers: List[str]
    has_free_provider: bool
    author: Optional[str] = None


class ModelsListResponse(AurikoResponseModel):
    models: List[CanonicalModel]
    count: int
    playground_defaults: List[str] = []


# --- /v1/models (OpenAI-compatible) ---


class ModelProvider(AurikoResponseModel):
    name: str
    input_price: float
    output_price: float
    data_policy: Optional[str] = None


class Model(AurikoResponseModel):
    id: str
    object: str
    created: int
    owned_by: str
    providers: Optional[List[ModelProvider]] = None


class ModelList(AurikoResponseModel):
    object: str
    data: List[Model]
    catalog_version: Optional[str] = None
    catalog_age_seconds: Optional[float] = None
