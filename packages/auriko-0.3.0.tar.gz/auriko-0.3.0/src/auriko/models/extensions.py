"""Typed models for the extensions request parameter."""

from __future__ import annotations

from typing import Any, Dict, Optional

from pydantic import BaseModel, ConfigDict, model_validator


class Extensions(BaseModel):
    """
    Auriko extensions for chat completion requests.

    Provider passthrough (arbitrary dicts, forwarded as-is):
      - anthropic, openai, google, deepseek, or any other provider name

    For reasoning control, use ``reasoning_effort`` at the top level
    of the ``create()`` call instead of extensions.
    """
    model_config = ConfigDict(extra="allow")

    anthropic: Optional[Dict[str, Any]] = None
    openai: Optional[Dict[str, Any]] = None
    google: Optional[Dict[str, Any]] = None
    deepseek: Optional[Dict[str, Any]] = None

    @model_validator(mode='before')
    @classmethod
    def _reject_thinking(cls, data: Any) -> Any:
        if isinstance(data, dict) and 'thinking' in data:
            raise ValueError(
                'extensions.thinking is not supported. '
                'Use reasoning_effort at the top level instead.'
            )
        return data
