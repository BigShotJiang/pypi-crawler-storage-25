from __future__ import annotations

from typing import Mapping, Optional


class ResponseHeaders:
    """Typed wrapper for HTTP response headers with case-insensitive access."""

    __slots__ = ("_raw",)

    def __init__(self, raw: Mapping[str, str]) -> None:
        self._raw = raw

    def get(self, name: str) -> Optional[str]:
        """Get a header value by name (case-insensitive)."""
        # Fast path: direct lookup (handles httpx.Headers, which is
        # case-insensitive, and exact-match plain dicts)
        val = self._raw.get(name)
        if val is not None:
            return val
        # Slow path: case-insensitive scan for plain dicts
        key = name.lower()
        for k in self._raw:
            if k.lower() == key:
                return self._raw[k]
        return None

    def _int_header(self, name: str) -> Optional[int]:
        val = self.get(name)
        if val is None:
            return None
        try:
            return int(val)
        except (ValueError, OverflowError):
            return None

    def _float_header(self, name: str) -> Optional[float]:
        val = self.get(name)
        if val is None:
            return None
        try:
            return float(val)
        except (ValueError, OverflowError):
            return None

    @property
    def request_id(self) -> Optional[str]:
        return self.get("x-request-id")

    @property
    def retry_after_seconds(self) -> Optional[float]:
        return self._float_header("Retry-After")

    @property
    def rate_limit_remaining(self) -> Optional[int]:
        return self._int_header("x-ratelimit-remaining-requests")

    @property
    def rate_limit_limit(self) -> Optional[int]:
        return self._int_header("x-ratelimit-limit-requests")

    @property
    def rate_limit_reset(self) -> Optional[str]:
        return self.get("x-ratelimit-reset-requests")

    @property
    def credits_balance_microdollars(self) -> Optional[int]:
        return self._int_header("x-credits-balance-microdollars")

    @property
    def token_count_model(self) -> Optional[str]:
        return self.get("x-token-count-model")
