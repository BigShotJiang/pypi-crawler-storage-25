"""Response API stream wrappers — heterogeneous event dispatch."""

from __future__ import annotations

import json
from typing import Any, AsyncIterator, Dict, Iterator, Optional, Type

import httpx
from pydantic import ValidationError

from ._sse import SSEDecoder
from .errors.mapping import map_error_from_code
from .models.base import AurikoResponseModel
from .models.responses import (
    Response,
    ResponseCompletedEvent,
    ResponseContentPartAddedEvent,
    ResponseContentPartDoneEvent,
    ResponseCreatedEvent,
    ResponseErrorEvent,
    ResponseFailedEvent,
    ResponseFunctionCallArgumentsDeltaEvent,
    ResponseFunctionCallArgumentsDoneEvent,
    ResponseIncompleteEvent,
    ResponseInProgressEvent,
    ResponseOutputItemAddedEvent,
    ResponseOutputItemDoneEvent,
    ResponseReasoningSummaryPartAddedEvent,
    ResponseReasoningSummaryPartDoneEvent,
    ResponseReasoningSummaryTextDeltaEvent,
    ResponseReasoningSummaryTextDoneEvent,
    ResponseStreamEvent,
    ResponseTextDeltaEvent,
    ResponseTextDoneEvent,
    UnknownStreamEvent,
)
from .response_headers import ResponseHeaders


_EVENT_TYPE_MAP: Dict[str, Type[AurikoResponseModel]] = {
    "response.created": ResponseCreatedEvent,
    "response.in_progress": ResponseInProgressEvent,
    "response.completed": ResponseCompletedEvent,
    "response.incomplete": ResponseIncompleteEvent,
    "response.failed": ResponseFailedEvent,
    "response.output_item.added": ResponseOutputItemAddedEvent,
    "response.output_item.done": ResponseOutputItemDoneEvent,
    "response.content_part.added": ResponseContentPartAddedEvent,
    "response.content_part.done": ResponseContentPartDoneEvent,
    "response.output_text.delta": ResponseTextDeltaEvent,
    "response.output_text.done": ResponseTextDoneEvent,
    "response.reasoning_summary_part.added": ResponseReasoningSummaryPartAddedEvent,
    "response.reasoning_summary_part.done": ResponseReasoningSummaryPartDoneEvent,
    "response.reasoning_summary_text.delta": ResponseReasoningSummaryTextDeltaEvent,
    "response.reasoning_summary_text.done": ResponseReasoningSummaryTextDoneEvent,
    "response.function_call_arguments.delta": ResponseFunctionCallArgumentsDeltaEvent,
    "response.function_call_arguments.done": ResponseFunctionCallArgumentsDoneEvent,
    "error": ResponseErrorEvent,
}


def parse_response_stream_event(
    data: Dict[str, Any],
) -> ResponseStreamEvent:
    """Parse SSE data payload into a typed event or UnknownStreamEvent fallback."""
    event_type = data.get("type")
    if not isinstance(event_type, str):
        return UnknownStreamEvent(type="unknown", data=data)

    model_cls = _EVENT_TYPE_MAP.get(event_type)
    if model_cls is None:
        return UnknownStreamEvent(
            type=event_type,
            sequence_number=data.get("sequence_number"),
            data=data,
        )

    try:
        return model_cls.model_validate(data)  # type: ignore[return-value]
    except ValidationError:
        return UnknownStreamEvent(
            type=event_type,
            sequence_number=data.get("sequence_number"),
            data=data,
        )


class ResponseStream:
    """Synchronous Response API SSE stream."""

    def __init__(self, *, response: httpx.Response) -> None:
        self._response = response
        self._decoder = SSEDecoder()
        self._iterated = False
        self._response_headers = ResponseHeaders(response.headers)
        self._completed_response: Optional[Response] = None

    def __iter__(self) -> Iterator[ResponseStreamEvent]:
        if self._iterated:
            raise RuntimeError("Stream can only be iterated once")
        self._iterated = True
        return self._iter_events()

    def _iter_events(self) -> Iterator[ResponseStreamEvent]:
        try:
            for line in self._response.iter_lines():
                sse_event = self._decoder.decode(line)
                if sse_event is None:
                    continue
                if sse_event.data == "[DONE]":
                    return

                data = json.loads(sse_event.data)
                event = parse_response_stream_event(data)

                if isinstance(event, ResponseErrorEvent):
                    raise map_error_from_code(
                        event.code,
                        event.message,
                        param=event.param,
                        doc_url=event.doc_url,
                        provider=event.provider,
                        suggestion=event.suggestion,
                        response_headers=self._response_headers,
                    )

                if isinstance(event, (ResponseCompletedEvent, ResponseIncompleteEvent, ResponseFailedEvent)):
                    self._completed_response = event.response
                    yield event
                    return

                yield event
        finally:
            self._response.close()

    @property
    def response_headers(self) -> ResponseHeaders:
        return self._response_headers

    @property
    def completed_response(self) -> Optional[Response]:
        """Final Response from terminal event. Available after full iteration."""
        return self._completed_response

    def close(self) -> None:
        self._response.close()

    def __enter__(self) -> ResponseStream:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()


class AsyncResponseStream:
    """Asynchronous Response API SSE stream."""

    def __init__(self, *, response: httpx.Response) -> None:
        self._response = response
        self._decoder = SSEDecoder()
        self._iterated = False
        self._response_headers = ResponseHeaders(response.headers)
        self._completed_response: Optional[Response] = None

    def __aiter__(self) -> AsyncIterator[ResponseStreamEvent]:
        if self._iterated:
            raise RuntimeError("Stream can only be iterated once")
        self._iterated = True
        return self._aiter_events()

    async def _aiter_events(self) -> AsyncIterator[ResponseStreamEvent]:
        try:
            async for line in self._response.aiter_lines():
                sse_event = self._decoder.decode(line)
                if sse_event is None:
                    continue
                if sse_event.data == "[DONE]":
                    return

                data = json.loads(sse_event.data)
                event = parse_response_stream_event(data)

                if isinstance(event, ResponseErrorEvent):
                    raise map_error_from_code(
                        event.code,
                        event.message,
                        param=event.param,
                        doc_url=event.doc_url,
                        provider=event.provider,
                        suggestion=event.suggestion,
                        response_headers=self._response_headers,
                    )

                if isinstance(event, (ResponseCompletedEvent, ResponseIncompleteEvent, ResponseFailedEvent)):
                    self._completed_response = event.response
                    yield event
                    return

                yield event
        finally:
            await self._response.aclose()

    @property
    def response_headers(self) -> ResponseHeaders:
        return self._response_headers

    @property
    def completed_response(self) -> Optional[Response]:
        """Final Response from terminal event. Available after full iteration."""
        return self._completed_response

    async def close(self) -> None:
        await self._response.aclose()

    async def __aenter__(self) -> AsyncResponseStream:
        return self

    async def __aexit__(self, *args: object) -> None:
        await self.close()
