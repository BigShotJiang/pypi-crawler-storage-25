"""TypedDict definitions for chat completion request parameters.

These types provide IDE autocomplete and type-checker support for the
``client.chat.completions.create()`` method.  They mirror the OpenAPI spec
schemas at ``api_gateway/openapi/auriko-api.yaml`` and follow the same
``total=False`` + ``Required[...]`` convention used by the OpenAI Python SDK.

**Important:** This module must NOT use ``from __future__ import annotations``.
CPython bug #97727 causes ``Required``/``NotRequired`` markers to be silently
ignored when PEP 563 stringified annotations are active, breaking
``__required_keys__`` introspection.
"""

from typing import Dict, List, Literal, Union

from typing_extensions import Required, TypedDict


# ---------------------------------------------------------------------------
# Message types
# ---------------------------------------------------------------------------


class ChatCompletionSystemMessageParam(TypedDict, total=False):
    """System message — sets behaviour/context for the model."""

    role: Required[Literal["system"]]
    content: Required[str]
    name: str


class CacheControlParam(TypedDict, total=False):
    """Prompt caching control. Only 'ephemeral' is supported."""

    type: Required[Literal["ephemeral"]]


class ChatCompletionContentPartTextParam(TypedDict, total=False):
    """Text content part within a multi-part user message."""

    type: Required[Literal["text"]]
    text: Required[str]
    cache_control: CacheControlParam


class ImageURLParam(TypedDict, total=False):
    """Image URL and optional detail level for vision requests."""

    url: Required[str]
    detail: Literal["auto", "low", "high"]


class ChatCompletionContentPartImageParam(TypedDict, total=False):
    """Image content part within a multi-part user message."""

    type: Required[Literal["image_url"]]
    image_url: Required[ImageURLParam]
    cache_control: CacheControlParam


ChatCompletionContentPartParam = Union[
    ChatCompletionContentPartTextParam,
    ChatCompletionContentPartImageParam,
]
"""Union of content part types for multi-modal user messages."""


class ChatCompletionUserMessageParam(TypedDict, total=False):
    """User message — the end-user's input to the model."""

    role: Required[Literal["user"]]
    content: Required[Union[str, List[ChatCompletionContentPartParam]]]
    name: str


# ---------------------------------------------------------------------------
# Tool-call sub-objects (used inside assistant messages)
# ---------------------------------------------------------------------------


class ChatCompletionMessageToolCallFunctionParam(TypedDict, total=False):
    """Function call details inside a tool call."""

    name: Required[str]
    arguments: Required[str]


class ChatCompletionMessageToolCallParam(TypedDict, total=False):
    """A tool call emitted by the assistant."""

    id: Required[str]
    type: Required[Literal["function"]]
    function: Required[ChatCompletionMessageToolCallFunctionParam]
    provider_signature: str


class FunctionCallParam(TypedDict, total=False):
    """Deprecated. Legacy function_call on assistant messages.

    Wire-identical to ChatCompletionMessageToolCallFunctionParam but kept
    separate: the legacy function_call and modern tool_call.function may
    diverge as the spec evolves.
    """

    name: Required[str]
    arguments: Required[str]


class ThinkingReasoningBlockParam(TypedDict, total=False):
    """Thinking reasoning block with cryptographic signature.

    Request-param counterpart of models.chat.ThinkingReasoningBlock (Pydantic).
    """

    type: Required[Literal["thinking"]]
    thinking: Required[str]
    signature: Required[str]


class RedactedReasoningBlockParam(TypedDict, total=False):
    """Redacted reasoning block (opaque, pass through verbatim).

    Request-param counterpart of models.chat.RedactedReasoningBlock (Pydantic).
    """

    type: Required[Literal["redacted"]]
    data: Required[str]


ReasoningBlockParam = Union[ThinkingReasoningBlockParam, RedactedReasoningBlockParam]
"""Discriminated union of reasoning block types for multi-turn round-trip."""


# ---------------------------------------------------------------------------
# Assistant and tool messages
# ---------------------------------------------------------------------------


class ChatCompletionAssistantMessageParam(TypedDict, total=False):
    """Assistant message — the model's response, optionally with tool calls."""

    role: Required[Literal["assistant"]]
    content: Union[str, None]
    name: str
    tool_calls: Union[List[ChatCompletionMessageToolCallParam], None]
    reasoning: Union[List[ReasoningBlockParam], None]
    reasoning_content: Union[str, None]
    refusal: Union[str, None]
    function_call: FunctionCallParam


class ChatCompletionToolMessageParam(TypedDict, total=False):
    """Tool message — result of a tool call, keyed by ``tool_call_id``."""

    role: Required[Literal["tool"]]
    content: Required[str]
    tool_call_id: Required[str]


class ChatCompletionDeveloperMessageParam(TypedDict, total=False):
    """Developer message — instruction context visible only to the model."""

    role: Required[Literal["developer"]]
    content: Required[str]
    name: str


class ChatCompletionFunctionMessageParam(TypedDict, total=False):
    """Deprecated. Use ToolMessage instead."""

    role: Required[Literal["function"]]
    content: Required[Union[str, None]]
    name: Required[str]


ChatCompletionMessageParam = Union[
    ChatCompletionSystemMessageParam,
    ChatCompletionUserMessageParam,
    ChatCompletionAssistantMessageParam,
    ChatCompletionToolMessageParam,
    ChatCompletionDeveloperMessageParam,
    ChatCompletionFunctionMessageParam,
]
"""Union of all message types accepted by ``create()``."""


# ---------------------------------------------------------------------------
# Tool definitions
# ---------------------------------------------------------------------------


class FunctionDefinitionParam(TypedDict, total=False):
    """Function schema for a tool the model may call."""

    name: Required[str]
    description: str
    parameters: Dict[str, object]
    strict: bool


class ChatCompletionToolParam(TypedDict, total=False):
    """Tool definition — currently only ``type="function"`` is supported."""

    type: Required[Literal["function"]]
    function: Required[FunctionDefinitionParam]


# ---------------------------------------------------------------------------
# Tool choice
# ---------------------------------------------------------------------------


class ChatCompletionNamedToolChoiceFunctionParam(TypedDict, total=False):
    """Identifies a specific function to call."""

    name: Required[str]


class ChatCompletionNamedToolChoiceParam(TypedDict, total=False):
    """Force the model to call a specific function."""

    type: Required[Literal["function"]]
    function: Required[ChatCompletionNamedToolChoiceFunctionParam]


ChatCompletionToolChoiceOptionParam = Union[
    Literal["auto", "required", "none"],
    ChatCompletionNamedToolChoiceParam,
]
"""How the model should choose which tool to call."""


# ---------------------------------------------------------------------------
# Response format
# ---------------------------------------------------------------------------


class ResponseFormatText(TypedDict, total=False):
    """Plain-text response format (default)."""

    type: Required[Literal["text"]]


class ResponseFormatJsonObject(TypedDict, total=False):
    """JSON-object response format — model outputs valid JSON."""

    type: Required[Literal["json_object"]]


class JsonSchemaConfigParam(TypedDict, total=False):
    """JSON Schema configuration for structured output."""

    name: Required[str]
    schema: Required[Dict[str, object]]
    description: str
    strict: bool


class ResponseFormatJsonSchema(TypedDict, total=False):
    """JSON-schema response format — model output conforms to a schema."""

    type: Required[Literal["json_schema"]]
    json_schema: Required[JsonSchemaConfigParam]


ResponseFormatParam = Union[
    ResponseFormatText,
    ResponseFormatJsonObject,
    ResponseFormatJsonSchema,
]
"""Union of response format options."""


# ---------------------------------------------------------------------------
# Stream options and Auriko metadata
# ---------------------------------------------------------------------------


class StreamOptionsParam(TypedDict, total=False):
    """Options for streaming responses."""

    include_usage: bool


class AurikoMetadataParam(TypedDict, total=False):
    """Auriko-specific request metadata.

    Accepted fields: tags, user_id, trace_id, custom_fields.
    Use custom_fields for arbitrary key-value pairs.
    """

    tags: List[str]
    user_id: str
    trace_id: str
    custom_fields: Dict[str, str]


__all__ = [
    "AurikoMetadataParam",
    "CacheControlParam",
    "ChatCompletionAssistantMessageParam",
    "ChatCompletionContentPartImageParam",
    "ChatCompletionContentPartParam",
    "ChatCompletionContentPartTextParam",
    "ChatCompletionDeveloperMessageParam",
    "ChatCompletionFunctionMessageParam",
    "ChatCompletionMessageParam",
    "ChatCompletionMessageToolCallFunctionParam",
    "ChatCompletionMessageToolCallParam",
    "ChatCompletionNamedToolChoiceFunctionParam",
    "ChatCompletionNamedToolChoiceParam",
    "ChatCompletionSystemMessageParam",
    "ChatCompletionToolChoiceOptionParam",
    "ChatCompletionToolMessageParam",
    "ChatCompletionToolParam",
    "ChatCompletionUserMessageParam",
    "FunctionCallParam",
    "FunctionDefinitionParam",
    "ImageURLParam",
    "JsonSchemaConfigParam",
    "ReasoningBlockParam",
    "RedactedReasoningBlockParam",
    "ResponseFormatJsonObject",
    "ResponseFormatJsonSchema",
    "ResponseFormatParam",
    "ResponseFormatText",
    "StreamOptionsParam",
    "ThinkingReasoningBlockParam",
]
