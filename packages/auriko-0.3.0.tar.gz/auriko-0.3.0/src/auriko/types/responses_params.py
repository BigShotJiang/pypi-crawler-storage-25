"""Request parameter types for the Response API."""

from __future__ import annotations

from typing import Any, Dict, List, Literal, Union

from typing_extensions import Required, TypedDict


class ResponseInputTextPart(TypedDict, total=False):
    type: Required[Literal["input_text"]]
    text: Required[str]


class ResponseInputImagePart(TypedDict, total=False):
    type: Required[Literal["input_image"]]
    image_url: str
    detail: str


class ResponseOutputTextPart(TypedDict, total=False):
    type: Required[Literal["output_text"]]
    text: Required[str]
    annotations: List[Any]


ResponseContentPartParam = Union[ResponseInputTextPart, ResponseInputImagePart, ResponseOutputTextPart]


class ResponseInputMessageParam(TypedDict, total=False):
    role: Required[Literal["user", "assistant", "system", "developer"]]
    content: Required[Union[str, List[ResponseContentPartParam]]]
    type: Literal["message"]


class ResponseInputFunctionCallParam(TypedDict, total=False):
    type: Required[Literal["function_call"]]
    call_id: Required[str]
    name: Required[str]
    arguments: Required[str]


class ResponseInputFunctionCallOutputParam(TypedDict, total=False):
    type: Required[Literal["function_call_output"]]
    call_id: Required[str]
    output: Required[str]


class ResponseInputReasoningSummaryPartParam(TypedDict, total=False):
    type: Required[Literal["summary_text"]]
    text: Required[str]


class ResponseInputReasoningParam(TypedDict, total=False):
    type: Required[Literal["reasoning"]]
    id: str
    summary: List[ResponseInputReasoningSummaryPartParam]
    encrypted_content: str


ResponseInputItemParam = Union[
    ResponseInputMessageParam,
    ResponseInputFunctionCallParam,
    ResponseInputFunctionCallOutputParam,
    ResponseInputReasoningParam,
]


class ResponseFunctionToolParam(TypedDict, total=False):
    type: Required[Literal["function"]]
    name: Required[str]
    description: str
    parameters: Dict[str, Any]
    strict: bool


ResponseToolParam = Union[ResponseFunctionToolParam, Dict[str, Any]]


class ResponseTextFormatParam(TypedDict, total=False):
    type: Required[Literal["text", "json_object", "json_schema"]]
    name: str
    schema: Dict[str, Any]
    strict: bool


class ResponseReasoningParam(TypedDict, total=False):
    effort: Literal["none", "minimal", "low", "medium", "high", "xhigh", "max", "off"]
    summary: Literal["auto", "concise", "detailed"]
    generate_summary: Literal["auto", "concise", "detailed"]
