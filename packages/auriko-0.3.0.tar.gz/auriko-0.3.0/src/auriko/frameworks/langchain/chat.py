"""Auriko LangChain adapter — wraps ChatOpenAI with routing and error mapping."""

from __future__ import annotations

import os
from typing import Any, Optional

import openai
from langchain_openai import ChatOpenAI

from auriko.errors import map_openai_error
from auriko.route_types import RoutingOptions, merge_gateway_extra_body


class AurikoChatOpenAI(ChatOpenAI):
    """ChatOpenAI subclass that routes requests through Auriko.

    Injects routing options into every request, extracts routing metadata from
    responses, and maps OpenAI API errors to AurikoAPIError subclasses.
    """

    def __init__(
        self,
        *,
        api_key: str | None = None,
        routing: Optional[RoutingOptions] = None,
        base_url: str = "https://api.auriko.ai/v1",
        **kwargs: Any,
    ) -> None:
        # Resolve API key: explicit param > AURIKO_API_KEY env > parent's OPENAI_API_KEY fallback.
        # Guard on openai_api_key because ChatOpenAI's field uses alias="api_key" —
        # passing both the field name and alias sets the same Pydantic field twice.
        if api_key is None and "openai_api_key" not in kwargs:
            api_key = os.environ.get("AURIKO_API_KEY")
        if api_key is not None:
            kwargs["api_key"] = api_key

        # Ensure LangChain uses /v1/chat/completions (Auriko doesn't serve /v1/responses).
        kwargs.setdefault("use_responses_api", False)

        if routing:
            # Inject routing into extra_body.
            # Use merge_gateway_extra_body so a caller-supplied
            # extra_body={"gateway": {"metadata": ...}} does not clobber our injected
            # routing (or vice versa).
            gw_body = routing.to_extra_body()
            existing = kwargs.get("extra_body") or {}
            kwargs["extra_body"] = merge_gateway_extra_body(gw_body, dict(existing))

        super().__init__(base_url=base_url, **kwargs)

    def _create_chat_result(
        self,
        response: Any,
        generation_info: dict | None = None,
    ) -> Any:
        result = super()._create_chat_result(response, generation_info)

        # Extract routing_metadata from raw response.
        # response is dict | openai.BaseModel. When it's a ChatCompletion
        # (BaseModel with extra="allow"), model_extra holds custom fields.
        metadata = None
        if hasattr(response, "model_extra") and response.model_extra:
            metadata = response.model_extra.get("routing_metadata")
        elif isinstance(response, dict):
            metadata = response.get("routing_metadata")

        if metadata:
            for gen in result.generations:
                gen.generation_info = {**(gen.generation_info or {}), "routing_metadata": metadata}

        return result

    def _generate(self, messages: Any, stop: Any = None, run_manager: Any = None, **kwargs: Any) -> Any:
        try:
            return super()._generate(messages, stop=stop, run_manager=run_manager, **kwargs)
        except openai.APIStatusError as e:
            raise map_openai_error(e) from e

    async def _agenerate(self, messages: Any, stop: Any = None, run_manager: Any = None, **kwargs: Any) -> Any:
        try:
            return await super()._agenerate(messages, stop=stop, run_manager=run_manager, **kwargs)
        except openai.APIStatusError as e:
            raise map_openai_error(e) from e
