try:
    from .chat import AurikoChatOpenAI
except ImportError as e:
    raise ImportError(
        "AurikoChatOpenAI requires langchain-openai. "
        "Install with: pip install auriko[langchain]"
    ) from e

__all__ = ["AurikoChatOpenAI"]
