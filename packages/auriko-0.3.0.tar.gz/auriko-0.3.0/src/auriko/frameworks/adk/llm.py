"""Auriko Google ADK adapter — routes ADK requests through Auriko."""

from __future__ import annotations

import json
import logging
import os
from collections.abc import AsyncGenerator
from typing import Any, Optional

import openai
from google.adk.models.base_llm import BaseLlm
from google.adk.models.llm_request import LlmRequest
from google.adk.models.llm_response import LlmResponse
from google.genai import types
from openai import AsyncOpenAI, NOT_GIVEN
from pydantic import Field, PrivateAttr

from auriko.errors import map_openai_error
from auriko.route_types import RoutingOptions

logger = logging.getLogger(__name__)

_FINISH_REASON_MAP = {
    "stop": types.FinishReason.STOP,
    "length": types.FinishReason.MAX_TOKENS,
    "tool_calls": types.FinishReason.STOP,
    "function_call": types.FinishReason.STOP,
    "content_filter": types.FinishReason.SAFETY,
}


class AurikoLlm(BaseLlm):
    """Google ADK adapter that routes requests through Auriko.

    Converts between ADK (Gemini) types and OpenAI message format.
    Supports text and function calling. Inline data and file data raise
    NotImplementedError.
    """

    model: str
    api_key: str = Field(default="", exclude=True)
    routing: Optional[RoutingOptions] = None
    base_url: str = "https://api.auriko.ai/v1"
    _client: Optional[AsyncOpenAI] = PrivateAttr(default=None)

    def _get_client(self) -> AsyncOpenAI:
        if self._client is None:
            key = self.api_key or os.environ.get("AURIKO_API_KEY", "")
            self._client = AsyncOpenAI(base_url=self.base_url, api_key=key)
        return self._client

    async def generate_content_async(
        self, llm_request: LlmRequest, stream: bool = False
    ) -> AsyncGenerator[LlmResponse, None]:
        messages = self._convert_request(llm_request)
        tools = self._convert_tools(llm_request)
        extra_body = self.routing.to_extra_body() if self.routing else {}

        try:
            if stream:
                async for resp in self._stream(messages, tools, extra_body):
                    yield resp
            else:
                response = await self._get_client().chat.completions.create(
                    model=self.model,
                    messages=messages,
                    tools=tools or NOT_GIVEN,
                    extra_body=extra_body or None,
                )
                llm_response = self._convert_response(response)
                metadata = getattr(response, "model_extra", {}).get("routing_metadata")
                if metadata:
                    llm_response.custom_metadata = {"routing_metadata": metadata}
                yield llm_response
        except openai.APIStatusError as e:
            raise map_openai_error(e) from e

    async def _stream(
        self, messages: list[dict], tools: list[dict] | None, extra_body: dict
    ) -> AsyncGenerator[LlmResponse, None]:
        async_stream = await self._get_client().chat.completions.create(
            model=self.model,
            messages=messages,
            tools=tools or NOT_GIVEN,
            extra_body=extra_body or None,
            stream=True,
            stream_options={"include_usage": True},
        )

        accumulated_text = ""
        accumulated_tool_calls: dict[int, dict] = {}
        last_chunk = None
        stream_usage = None
        routing_metadata = None

        async for chunk in async_stream:
            if chunk.usage:
                stream_usage = chunk.usage
            chunk_meta = getattr(chunk, "model_extra", {}).get("routing_metadata")
            if chunk_meta:
                routing_metadata = chunk_meta
            if not chunk.choices:
                continue
            last_chunk = chunk

            delta = chunk.choices[0].delta

            if delta.content:
                accumulated_text += delta.content
                yield LlmResponse(
                    content=types.Content(
                        role="model",
                        parts=[types.Part.from_text(text=delta.content)],
                    ),
                    partial=True,
                )

            if delta.tool_calls:
                for tc in delta.tool_calls:
                    idx = tc.index
                    if idx not in accumulated_tool_calls:
                        accumulated_tool_calls[idx] = {
                            "id": tc.id or "",
                            "name": tc.function.name if tc.function and tc.function.name else "",
                            "arguments": "",
                        }
                    if tc.function and tc.function.arguments:
                        accumulated_tool_calls[idx]["arguments"] += tc.function.arguments
                    if tc.id:
                        accumulated_tool_calls[idx]["id"] = tc.id
                    if tc.function and tc.function.name:
                        accumulated_tool_calls[idx]["name"] = tc.function.name

        # Final response with partial=False and aggregated content.
        final_parts: list[types.Part] = []
        if accumulated_text:
            final_parts.append(types.Part.from_text(text=accumulated_text))
        for tc_data in accumulated_tool_calls.values():
            try:
                args = json.loads(tc_data["arguments"]) if tc_data["arguments"] else {}
            except json.JSONDecodeError:
                args = {}
            part = types.Part.from_function_call(name=tc_data["name"], args=args)
            if part.function_call:
                part.function_call.id = tc_data["id"]
            final_parts.append(part)

        usage_metadata = None
        if stream_usage:
            usage_metadata = types.GenerateContentResponseUsageMetadata(
                prompt_token_count=stream_usage.prompt_tokens,
                candidates_token_count=stream_usage.completion_tokens,
                total_token_count=stream_usage.total_tokens,
            )

        finish_reason = None
        if last_chunk and last_chunk.choices:
            fr_str = last_chunk.choices[0].finish_reason
            finish_reason = _FINISH_REASON_MAP.get(fr_str, types.FinishReason.FINISH_REASON_UNSPECIFIED)

        final_response = LlmResponse(
            content=types.Content(role="model", parts=final_parts) if final_parts else None,
            partial=False,
            usage_metadata=usage_metadata,
            finish_reason=finish_reason,
            model_version=self.model,
        )
        if routing_metadata:
            final_response.custom_metadata = {"routing_metadata": routing_metadata}
        yield final_response

    # ── Request conversion: ADK → OpenAI ──────────────────────────────────

    def _convert_request(self, llm_request: LlmRequest) -> list[dict]:
        messages: list[dict] = []

        # System instruction
        sys_instr = getattr(llm_request.config, "system_instruction", None)
        if sys_instr:
            if isinstance(sys_instr, str):
                messages.append({"role": "system", "content": sys_instr})
            elif isinstance(sys_instr, types.Content):
                text = "\n".join(
                    p.text for p in (sys_instr.parts or []) if p.text
                )
                if text:
                    messages.append({"role": "system", "content": text})

        # Conversation contents
        for content in llm_request.contents:
            msgs = self._convert_content(content)
            messages.extend(msgs)

        return messages

    def _convert_content(self, content: types.Content) -> list[dict]:
        role = "assistant" if content.role in ("model", "assistant") else "user"
        parts = content.parts or []

        # Separate parts by type
        text_parts: list[str] = []
        function_calls: list[dict] = []
        function_responses: list[dict] = []

        for part in parts:
            if part.inline_data:
                raise NotImplementedError(
                    "inline_data (images, audio) is not supported by AurikoLlm. "
                    "Use text and function calling only."
                )
            if part.file_data:
                raise NotImplementedError(
                    "file_data is not supported by AurikoLlm. "
                    "Use text and function calling only."
                )
            if part.thought:
                logger.warning("Thought/reasoning parts passed through as text.")
            if part.text:
                text_parts.append(part.text)
            if part.function_call:
                fc = part.function_call
                function_calls.append({
                    "type": "function",
                    "id": fc.id or f"call_{fc.name}",
                    "function": {
                        "name": fc.name,
                        "arguments": json.dumps(fc.args) if fc.args else "{}",
                    },
                })
            if part.function_response:
                fr = part.function_response
                resp_str = json.dumps(fr.response) if isinstance(fr.response, dict) else str(fr.response or "")
                function_responses.append({
                    "role": "tool",
                    "tool_call_id": fr.id or f"call_{fr.name}",
                    "content": resp_str,
                })

        messages: list[dict] = []

        # Assistant with tool calls (may also have text content)
        if role == "assistant" and function_calls:
            msg: dict[str, Any] = {"role": "assistant", "tool_calls": function_calls}
            if text_parts:
                msg["content"] = "\n".join(text_parts)
            messages.append(msg)

        # Function responses become separate tool messages
        if function_responses:
            messages.extend(function_responses)

        # Plain text message (skip only when already included in assistant+tool_calls msg)
        if text_parts and not (role == "assistant" and function_calls):
            messages.append({"role": role, "content": "\n".join(text_parts)})

        return messages

    # ── Response conversion: OpenAI → ADK ─────────────────────────────────

    def _convert_response(self, response: Any) -> LlmResponse:
        parts: list[types.Part] = []

        if response.choices:
            message = response.choices[0].message

            if message.content:
                parts.append(types.Part.from_text(text=message.content))

            if message.tool_calls:
                for tc in message.tool_calls:
                    try:
                        args = json.loads(tc.function.arguments) if tc.function.arguments else {}
                    except json.JSONDecodeError:
                        args = {}
                    part = types.Part.from_function_call(name=tc.function.name, args=args)
                    if part.function_call:
                        part.function_call.id = tc.id
                    parts.append(part)

        usage_metadata = None
        if response.usage:
            usage_metadata = types.GenerateContentResponseUsageMetadata(
                prompt_token_count=response.usage.prompt_tokens,
                candidates_token_count=response.usage.completion_tokens,
                total_token_count=response.usage.total_tokens,
            )

        finish_reason = None
        if response.choices:
            fr_str = response.choices[0].finish_reason
            finish_reason = _FINISH_REASON_MAP.get(fr_str, types.FinishReason.FINISH_REASON_UNSPECIFIED)

        return LlmResponse(
            content=types.Content(role="model", parts=parts) if parts else None,
            partial=False,
            usage_metadata=usage_metadata,
            finish_reason=finish_reason,
            model_version=response.model,
        )

    # ── Tool conversion: ADK → OpenAI ─────────────────────────────────────

    def _convert_tools(self, llm_request: LlmRequest) -> list[dict] | None:
        # Tools are stored in config.tools[0].function_declarations by the ADK
        # framework (not in tools_dict, which maps str->BaseTool).
        if (
            not llm_request.config
            or not llm_request.config.tools
            or not llm_request.config.tools[0].function_declarations
        ):
            return None

        tools: list[dict] = []
        for decl in llm_request.config.tools[0].function_declarations:
            tools.append({
                "type": "function",
                "function": {
                    "name": decl.name,
                    "description": decl.description or "",
                    "parameters": _schema_to_dict(decl.parameters) if decl.parameters else {**_EMPTY_OBJECT_SCHEMA},
                },
            })

        return tools if tools else None


_EMPTY_OBJECT_SCHEMA: dict = {"type": "object", "properties": {}}


def _schema_to_dict(schema: Any) -> dict:
    """Convert google.genai.types.Schema to JSON Schema dict.

    Uses model_dump for robustness (preserves all fields like nullable, format,
    min/max constraints) then normalizes type enum values to lowercase at all
    nesting levels (genai uses uppercase 'STRING', OpenAI expects 'string').
    """
    if schema is None:
        return {**_EMPTY_OBJECT_SCHEMA}

    if not hasattr(schema, "model_dump"):
        return {**_EMPTY_OBJECT_SCHEMA}

    result = schema.model_dump(exclude_none=True)
    _normalize_schema_types(result)
    if "type" not in result:
        return {**_EMPTY_OBJECT_SCHEMA, **result}
    return result


def _normalize_schema_types(d: dict) -> None:
    """Recursively lowercase 'type' values in a JSON Schema dict.

    genai enums serialize as uppercase ('STRING'), OpenAI expects lowercase ('string').
    After model_dump(), all nested schemas are already dicts — must walk the full tree.
    """
    if "type" in d and isinstance(d["type"], str):
        d["type"] = d["type"].lower()
    if isinstance(d.get("properties"), dict):
        for v in d["properties"].values():
            if isinstance(v, dict):
                _normalize_schema_types(v)
    if isinstance(d.get("items"), dict):
        _normalize_schema_types(d["items"])
    if isinstance(d.get("any_of"), list):
        for item in d["any_of"]:
            if isinstance(item, dict):
                _normalize_schema_types(item)
