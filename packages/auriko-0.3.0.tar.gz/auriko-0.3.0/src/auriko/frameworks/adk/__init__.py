try:
    from .llm import AurikoLlm
except ImportError as e:
    raise ImportError(
        "AurikoLlm requires google-adk and openai. "
        "Install with: pip install auriko[adk]"
    ) from e

__all__ = ["AurikoLlm"]
