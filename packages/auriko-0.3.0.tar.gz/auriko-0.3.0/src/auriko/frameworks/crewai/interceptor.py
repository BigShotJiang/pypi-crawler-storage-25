"""Auriko CrewAI integration — injects routing and extracts metadata."""

from __future__ import annotations

import json
import logging
from typing import Any, Optional

import httpx
from crewai.llms.hooks.base import BaseInterceptor

from auriko.route_types import RoutingOptions, merge_gateway_extra_body

logger = logging.getLogger(__name__)


class AurikoInterceptor(BaseInterceptor[httpx.Request, httpx.Response]):
    """Injects Auriko routing options into CrewAI requests and extracts routing metadata from responses."""

    def __init__(
        self,
        routing: Optional[RoutingOptions] = None,
        passthrough_params: Optional[dict[str, Any]] = None,
    ) -> None:
        self._routing = routing
        self._routing_extra_body: dict | None = routing.to_extra_body() if routing else None
        self._routing_metadata: dict | None = None
        self._passthrough_params: dict[str, Any] = passthrough_params or {}

    @property
    def last_routing_metadata(self) -> Optional[dict]:
        """Raw routing metadata dict from the last successful non-streaming response."""
        return self._routing_metadata

    def on_outbound(self, request: httpx.Request) -> httpx.Request:
        # Reset metadata before each request — prevents stale reads from
        # previous requests.
        self._routing_metadata = None

        if not self._routing_extra_body and not self._passthrough_params:
            return request

        content_type = request.headers.get("content-type", "")
        if "application/json" not in content_type:
            return request

        try:
            body = json.loads(request.content)

            for key, value in self._passthrough_params.items():
                if key not in body:
                    body[key] = value

            if self._routing_extra_body:
                body = merge_gateway_extra_body(body, self._routing_extra_body)

            content = json.dumps(body).encode("utf-8")

            # Exclude old Content-Length: httpx._prepare() only adds it if NOT
            # already present. Keeping the stale header would cause body length
            # mismatch on the server.
            headers = [
                (k, v) for k, v in request.headers.raw
                if k.lower() != b"content-length"
            ]

            return httpx.Request(
                method=request.method,
                url=request.url,
                headers=headers,
                content=content,
                extensions=request.extensions,
            )
        except (json.JSONDecodeError, UnicodeDecodeError):
            return request

    def on_inbound(self, response: httpx.Response) -> httpx.Response:
        content_type = response.headers.get("content-type", "")

        # SSE/streaming and error responses are passed through unchanged.
        if "text/event-stream" in content_type:
            return response

        if response.status_code >= 400:
            return response

        # Success (2xx): read body, extract routing_metadata.
        response.read()
        try:
            body = response.json()
            self._routing_metadata = body.get("routing_metadata")
        except Exception:
            logger.debug("Failed to parse routing_metadata from response body", exc_info=True)

        return response

    # Async delegates for async transports.
    async def aon_outbound(self, request: httpx.Request) -> httpx.Request:
        # Outbound is pure JSON manipulation — safe to delegate to sync.
        return self.on_outbound(request)

    async def aon_inbound(self, response: httpx.Response) -> httpx.Response:
        # Async-safe response reading.
        content_type = response.headers.get("content-type", "")
        if "text/event-stream" in content_type:
            return response
        if response.status_code >= 400:
            return response
        await response.aread()
        try:
            body = response.json()
            self._routing_metadata = body.get("routing_metadata")
        except Exception:
            logger.debug("Failed to parse routing_metadata from response body", exc_info=True)
        return response
