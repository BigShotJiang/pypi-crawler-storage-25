"""Auriko CrewAI LLM wrapper — ergonomic wrapper around crewai.LLM with routing."""

from __future__ import annotations

import os
from typing import Any, Optional

from crewai import LLM

from auriko.route_types import RoutingMetadata, RoutingOptions

from .interceptor import AurikoInterceptor


class AurikoCrewAILLM:
    """Wrapper that creates a crewai.LLM wired to Auriko with routing.

    Usage::

        auriko_llm = AurikoCrewAILLM(model="gpt-4o", routing=RoutingOptions(optimize="cost"))
        agent = Agent(llm=auriko_llm.llm, ...)
        crew = Crew(agents=[agent])
        result = crew.kickoff()
        metadata = auriko_llm.last_routing_metadata
    """

    def __init__(
        self,
        model: str,
        api_key: str | None = None,
        routing: RoutingOptions | None = None,
        base_url: str = "https://api.auriko.ai/v1",
        **kwargs: Any,
    ) -> None:
        api_key = api_key or os.environ.get("AURIKO_API_KEY", "")

        passthrough: dict[str, Any] = {}
        if "reasoning_effort" in kwargs:
            passthrough["reasoning_effort"] = kwargs["reasoning_effort"]
        if "stop" in kwargs:
            passthrough["stop"] = kwargs["stop"]

        self._interceptor = AurikoInterceptor(
            routing=routing,
            passthrough_params=passthrough or None,
        )

        bare_model = model.removeprefix("openai/")
        kwargs.pop("provider", None)
        self._llm = LLM(
            model=bare_model,
            provider="openai",
            base_url=base_url,
            api_key=api_key,
            interceptor=self._interceptor,
            **kwargs,
        )

    @property
    def last_routing_metadata(self) -> Optional[RoutingMetadata]:
        """Typed routing metadata from the last successful non-streaming response.

        Returns None if no metadata is available or if parsing fails.
        """
        raw = self._interceptor.last_routing_metadata
        if raw is None:
            return None
        try:
            return RoutingMetadata.model_validate(raw)
        except Exception:
            return None

    @property
    def llm(self) -> LLM:
        """The underlying crewai.LLM instance. Pass this to CrewAI Agent/Task."""
        return self._llm
