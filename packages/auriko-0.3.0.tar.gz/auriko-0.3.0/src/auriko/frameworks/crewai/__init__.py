try:
    from .llm import AurikoCrewAILLM
except ImportError as e:
    raise ImportError(
        "AurikoCrewAILLM requires crewai. "
        "Install with: pip install auriko[crewai]"
    ) from e

__all__ = ["AurikoCrewAILLM"]
