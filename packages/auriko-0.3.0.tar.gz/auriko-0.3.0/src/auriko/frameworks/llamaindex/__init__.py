try:
    from .llm import AurikoLlamaIndexLLM
except ImportError as e:
    raise ImportError(
        "AurikoLlamaIndexLLM requires llama-index-llms-openai. "
        "Install with: pip install auriko[llamaindex]"
    ) from e

__all__ = ["AurikoLlamaIndexLLM"]
