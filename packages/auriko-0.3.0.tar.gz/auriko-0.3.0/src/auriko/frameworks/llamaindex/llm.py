"""Auriko LlamaIndex adapter — wraps llama-index OpenAI LLM with routing and error mapping."""

from __future__ import annotations

import os
from typing import Any, Optional, Sequence

import openai
from llama_index.llms.openai import OpenAI as LlamaIndexOpenAI
from pydantic import PrivateAttr

from auriko.errors import map_openai_error
from auriko.route_types import RoutingOptions, merge_gateway_extra_body

try:
    from llama_index.core.base.llms.types import ChatMessage, ChatResponse, LLMMetadata
except ImportError:
    from llama_index.core.llms import ChatMessage, ChatResponse, LLMMetadata


class AurikoLlamaIndexLLM(LlamaIndexOpenAI):
    """LlamaIndex OpenAI subclass that routes requests through Auriko.

    Injects routing options into every request, extracts routing metadata from
    responses, and maps OpenAI API errors to AurikoAPIError subclasses.
    """

    _routing: Optional[RoutingOptions] = PrivateAttr(default=None)
    _routing_extra_body: Optional[dict] = PrivateAttr(default=None)
    _context_window_override: Optional[int] = PrivateAttr(default=None)

    def __init__(
        self,
        *,
        api_key: str | None = None,
        routing: Optional[RoutingOptions] = None,
        api_base: str = "https://api.auriko.ai/v1",
        context_window: int | None = None,
        **kwargs: Any,
    ) -> None:
        # Resolve API key: explicit param > AURIKO_API_KEY env > parent's OPENAI_API_KEY fallback.
        if api_key is None:
            api_key = os.environ.get("AURIKO_API_KEY")
        super().__init__(api_key=api_key, api_base=api_base, **kwargs)
        self._routing = routing
        self._routing_extra_body = routing.to_extra_body() if routing else None
        self._context_window_override = context_window

    @property
    def metadata(self) -> LLMMetadata:
        # Delegate to parent so OpenAI models keep their correct per-model values
        # (e.g. gpt-4o=128k, o1-mini non-function-calling). Parent raises ValueError
        # from openai_modelname_to_contextsize() for non-OpenAI canonical IDs
        # (Claude/Gemini/DeepSeek/…); fall back to synthetic metadata in that case.
        # Auriko validates true context limits per canonical model.
        try:
            meta = super().metadata
        except ValueError:
            meta = LLMMetadata(
                context_window=200_000,
                num_output=self.max_tokens or -1,
                is_chat_model=True,
                is_function_calling_model=True,
                model_name=self.model,
            )
        if self._context_window_override is not None:
            meta = meta.model_copy(update={"context_window": self._context_window_override})
        return meta

    def _get_model_kwargs(self, **kwargs: Any) -> dict[str, Any]:
        # Extract per-call routing override (e.g., llm.chat(messages, routing=...))
        per_call_routing = kwargs.pop("routing", None)
        all_kwargs = super()._get_model_kwargs(**kwargs)

        routing_body = per_call_routing.to_extra_body() if per_call_routing else self._routing_extra_body
        if routing_body:
            # Inject routing into extra_body.
            # One-level-deep merge preserves sibling gateway keys from user extra_body.
            existing_extra = all_kwargs.get("extra_body") or {}
            all_kwargs["extra_body"] = merge_gateway_extra_body(routing_body, existing_extra)

        return all_kwargs

    def _attach_routing_metadata(self, response: ChatResponse) -> ChatResponse:
        if response.raw and hasattr(response.raw, "model_extra"):
            metadata = response.raw.model_extra.get("routing_metadata")
            if metadata:
                response.additional_kwargs = {**response.additional_kwargs, "routing_metadata": metadata}
        return response

    def _chat(self, messages: Sequence[ChatMessage], **kwargs: Any) -> ChatResponse:
        try:
            response = super()._chat(messages, **kwargs)
        except openai.APIStatusError as e:
            raise map_openai_error(e) from e
        return self._attach_routing_metadata(response)

    async def _achat(self, messages: Sequence[ChatMessage], **kwargs: Any) -> ChatResponse:
        try:
            response = await super()._achat(messages, **kwargs)
        except openai.APIStatusError as e:
            raise map_openai_error(e) from e
        return self._attach_routing_metadata(response)
