"""Stream wrappers for SSE responses."""

from __future__ import annotations

import json
from typing import AsyncIterator, Generic, Iterator, Optional, Type, TypeVar

import httpx

from ._sse import SSEDecoder
from .errors.mapping import _map_error_from_envelope
from .models.common import Usage
from .response_headers import ResponseHeaders
from .route_types import RoutingMetadata

T = TypeVar("T")


class Stream(Generic[T]):
    """Synchronous SSE stream wrapper."""

    def __init__(self, *, response: httpx.Response, cast_to: Type[T]) -> None:
        self._response = response
        self._cast_to = cast_to
        self._decoder = SSEDecoder()
        self._iterated = False
        self._routing_metadata: Optional[RoutingMetadata] = None
        self._usage: Optional[Usage] = None
        self._response_headers = ResponseHeaders(response.headers)

    def __iter__(self) -> Iterator[T]:
        if self._iterated:
            raise RuntimeError("Stream can only be iterated once")
        self._iterated = True
        return self._iter_events()

    def _iter_events(self) -> Iterator[T]:
        try:
            for line in self._response.iter_lines():
                event = self._decoder.decode(line)
                if event is None:
                    continue
                if event.data == "[DONE]":
                    return
                data = json.loads(event.data)
                if isinstance(data, dict) and "error" in data:
                    raise _map_error_from_envelope(
                        status_code=200,
                        body=data,
                        response_headers=self._response_headers,
                    )
                chunk = self._cast_to.model_validate(data)  # type: ignore[union-attr]
                if hasattr(chunk, "routing_metadata") and chunk.routing_metadata:
                    self._routing_metadata = chunk.routing_metadata
                if hasattr(chunk, "usage") and chunk.usage:
                    self._usage = chunk.usage
                yield chunk
        finally:
            self._response.close()

    @property
    def routing_metadata(self) -> Optional[RoutingMetadata]:
        return self._routing_metadata

    @property
    def usage(self) -> Optional[Usage]:
        return self._usage

    @property
    def response_headers(self) -> ResponseHeaders:
        return self._response_headers

    def close(self) -> None:
        self._response.close()

    def __enter__(self) -> Stream[T]:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()


class AsyncStream(Generic[T]):
    """Asynchronous SSE stream wrapper."""

    def __init__(self, *, response: httpx.Response, cast_to: Type[T]) -> None:
        self._response = response
        self._cast_to = cast_to
        self._decoder = SSEDecoder()
        self._iterated = False
        self._routing_metadata: Optional[RoutingMetadata] = None
        self._usage: Optional[Usage] = None
        self._response_headers = ResponseHeaders(response.headers)

    def __aiter__(self) -> AsyncIterator[T]:
        if self._iterated:
            raise RuntimeError("Stream can only be iterated once")
        self._iterated = True
        return self._aiter_events()

    async def _aiter_events(self) -> AsyncIterator[T]:
        try:
            async for line in self._response.aiter_lines():
                event = self._decoder.decode(line)
                if event is None:
                    continue
                if event.data == "[DONE]":
                    return
                data = json.loads(event.data)
                if isinstance(data, dict) and "error" in data:
                    raise _map_error_from_envelope(
                        status_code=200,
                        body=data,
                        response_headers=self._response_headers,
                    )
                chunk = self._cast_to.model_validate(data)  # type: ignore[union-attr]
                if hasattr(chunk, "routing_metadata") and chunk.routing_metadata:
                    self._routing_metadata = chunk.routing_metadata
                if hasattr(chunk, "usage") and chunk.usage:
                    self._usage = chunk.usage
                yield chunk
        finally:
            await self._response.aclose()

    @property
    def routing_metadata(self) -> Optional[RoutingMetadata]:
        return self._routing_metadata

    @property
    def usage(self) -> Optional[Usage]:
        return self._usage

    @property
    def response_headers(self) -> ResponseHeaders:
        return self._response_headers

    async def close(self) -> None:
        await self._response.aclose()

    async def __aenter__(self) -> AsyncStream[T]:
        return self

    async def __aexit__(self, *args: object) -> None:
        await self.close()
