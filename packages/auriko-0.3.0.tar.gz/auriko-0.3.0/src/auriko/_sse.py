"""SSE (Server-Sent Events) decoder following W3C EventSource spec."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class ServerSentEvent:
    event: str = "message"
    data: str = ""
    id: str = ""
    retry: int | None = None


class SSEDecoder:
    """Line-based SSE decoder. Feed lines from iter_lines(); get events back."""

    def __init__(self) -> None:
        self._event: str = "message"
        self._data: list[str] = []
        self._id: str = ""
        self._retry: int | None = None

    def decode(self, line: str) -> ServerSentEvent | None:
        """Process one line. Returns ServerSentEvent on message boundary, None otherwise."""
        # Strip trailing \r (iter_lines strips \n but not always \r)
        line = line.rstrip("\r")

        # Empty line = message boundary
        if not line:
            if not self._data:
                return None
            event = ServerSentEvent(
                event=self._event,
                data="\n".join(self._data),
                id=self._id,
                retry=self._retry,
            )
            self._data = []
            self._event = "message"
            self._retry = None
            # id persists across events per W3C spec
            return event

        # Comment
        if line.startswith(":"):
            return None

        # Field: split on first colon
        if ":" in line:
            field, _, value = line.partition(":")
            if value.startswith(" "):
                value = value[1:]  # strip single leading space
        else:
            field = line
            value = ""

        if field == "data":
            self._data.append(value)
        elif field == "event":
            self._event = value
        elif field == "id":
            if "\0" not in value:  # ignore if contains null
                self._id = value
        elif field == "retry":
            try:
                self._retry = int(value)
            except ValueError:
                pass

        return None
