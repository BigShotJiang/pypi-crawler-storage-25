"""TaskFloor Agent — connects local Claude Code to your task board."""
__version__ = "0.2.0"
