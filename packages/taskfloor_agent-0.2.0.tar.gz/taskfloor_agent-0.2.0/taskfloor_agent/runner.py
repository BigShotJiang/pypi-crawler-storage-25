"""Claude Code process manager — spawn, stream stdout, support --continue sessions."""
import asyncio
import logging
from collections.abc import AsyncGenerator
from pathlib import Path

logger = logging.getLogger(__name__)

class ProcessManager:
    """Manages Claude Code subprocesses keyed by task_id."""

    def __init__(self) -> None:
        self.processes: dict[int, asyncio.subprocess.Process] = {}
        # Track tasks that have had at least one run (for --continue)
        self._has_session: set[int] = set()

    async def run(
        self,
        task_id: int,
        worktree_path: str | Path,
        prompt: str,
    ) -> AsyncGenerator[dict, None]:
        """Spawn `claude -p` and stream text output in small chunks.

        On first run for a task: fresh session.
        On subsequent runs: uses --continue to resume the conversation.
        """
        is_continuation = task_id in self._has_session
        cmd = ["claude", "-p", "--output-format", "text", "--enable-auto-mode"]
        if is_continuation:
            cmd.append("--continue")

        logger.info(
            "[task:%d] Starting claude in %s (prompt: %d chars, continue: %s)",
            task_id, worktree_path, len(prompt), is_continuation,
        )

        process = await asyncio.create_subprocess_exec(
            *cmd,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=str(worktree_path),
        )
        self.processes[task_id] = process
        logger.info("[task:%d] Claude process started (PID %s)", task_id, process.pid)

        try:
            assert process.stdin is not None
            process.stdin.write(prompt.encode())
            await process.stdin.drain()
            process.stdin.close()
            logger.info("[task:%d] Prompt sent, waiting for output...", task_id)

            assert process.stdout is not None
            # Read line-by-line to avoid splitting UTF-8 characters
            async for raw_line in process.stdout:
                text = raw_line.decode(errors="replace")
                if text:
                    yield {
                        "type": "chunk",
                        "task_id": task_id,
                        "content": text,
                        "done": False,
                    }

            await process.wait()
            logger.info("[task:%d] Claude process exited (code %s)", task_id, process.returncode)

            assert process.stderr is not None
            stderr_data = await process.stderr.read()
            if stderr_data:
                stderr_text = stderr_data.decode(errors="replace")
                logger.warning("[task:%d] Claude stderr: %s", task_id, stderr_text[:500])

            # Mark this task as having a session for future --continue
            if process.returncode == 0:
                self._has_session.add(task_id)

        except asyncio.CancelledError:
            logger.info("[task:%d] Cancelled — terminating process", task_id)
            process.terminate()
            raise
        finally:
            exit_code = process.returncode if process.returncode is not None else -1
            self.processes.pop(task_id, None)
            yield {
                "type": "chunk",
                "task_id": task_id,
                "content": "",
                "done": True,
                "exit_code": exit_code,
            }

    async def cancel(self, task_id: int) -> None:
        process = self.processes.get(task_id)
        if process is None:
            return
        process.terminate()
        try:
            await asyncio.wait_for(process.wait(), timeout=5)
        except asyncio.TimeoutError:
            process.kill()
            await process.wait()
        self.processes.pop(task_id, None)

    def is_running(self, task_id: int) -> bool:
        return task_id in self.processes

    def has_session(self, task_id: int) -> bool:
        return task_id in self._has_session

    def reset_session(self, task_id: int):
        """Reset session state for a task (e.g., when entering a new workflow phase)."""
        self._has_session.discard(task_id)
