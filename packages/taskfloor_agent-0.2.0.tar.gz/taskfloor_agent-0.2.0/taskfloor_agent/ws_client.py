"""WebSocket client with auto-reconnect and message handling."""
import asyncio
import json
import logging
import os
from pathlib import Path

import websockets
from websockets.exceptions import ConnectionClosed

from taskfloor_agent.session_manager import SessionManager
from taskfloor_agent.worktree import create as create_worktree, remove as remove_worktree, get_diff_stat

logger = logging.getLogger(__name__)


class AgentWSClient:
    """WebSocket agent client that connects to TaskFloor server and handles task execution."""

    def __init__(
        self,
        server_url: str,
        token: str,
        agent_id: str,
        projects: dict[str, str],
        scan_dirs: list | None = None,
    ) -> None:
        # Convert http(s) → ws(s)
        if server_url.startswith("https://"):
            self.server_url = "wss://" + server_url[len("https://"):]
        elif server_url.startswith("http://"):
            self.server_url = "ws://" + server_url[len("http://"):]
        else:
            self.server_url = server_url

        self.token = token
        self.agent_id = agent_id
        self.projects = projects  # slug → local_path
        self.ws = None
        self.sessions = SessionManager()
        self._running = True
        self._tasks: dict[int, asyncio.Task] = {}
        self._scan_dirs = [Path(d) for d in (scan_dirs or [])]

    async def connect(self) -> None:
        """Reconnect loop with exponential backoff (1s → 60s max)."""
        backoff = 1
        uri = f"{self.server_url}/ws/agent?token={self.token}"

        while self._running:
            try:
                async with websockets.connect(uri, ping_interval=30) as ws:
                    self.ws = ws
                    logger.info("Connected to %s", uri)
                    await self._register()
                    backoff = 1  # reset backoff on successful connect

                    async for raw in ws:
                        try:
                            data = json.loads(raw)
                        except json.JSONDecodeError:
                            logger.warning("Received non-JSON message: %s", raw)
                            continue
                        await self._handle_message(data)

            except ConnectionClosed as exc:
                if exc.rcvd and exc.rcvd.code == 4001:
                    reason = exc.rcvd.reason or "Token expired or invalid"
                    logger.error("Authentication failed: %s", reason)
                    logger.error("Generate a new agent token in TaskFloor Settings > Agent Token")
                    backoff = 60  # don't spam retries on auth failure
                else:
                    logger.warning("Connection closed: %s — retrying in %ds", exc, backoff)
            except OSError as exc:
                logger.warning("Cannot connect to %s (%s) — retrying in %ds", self.server_url, exc, backoff)
            except Exception as exc:
                logger.warning("Connection error: %s — retrying in %ds", exc, backoff)
            finally:
                self.ws = None

            if not self._running:
                break

            await asyncio.sleep(backoff)
            backoff = min(backoff * 2, 60)

    async def _register(self) -> None:
        """Send registration message with capabilities and worktree state."""
        from taskfloor_agent.worktree import list_worktrees

        worktrees_by_slug: dict[str, list[dict]] = {}
        for slug, path in self.projects.items():
            try:
                wt_list = list_worktrees(path)
                parsed = []
                for wt in wt_list:
                    wt_path = wt.get("path", "")
                    parts = wt_path.rsplit("/task-", 1)
                    if len(parts) == 2:
                        try:
                            tid = int(parts[1])
                            parsed.append({"task_id": tid, "path": wt_path, "branch": wt.get("branch", "")})
                        except ValueError:
                            pass
                if parsed:
                    worktrees_by_slug[slug] = parsed
            except Exception:
                pass

        payload = {
            "type": "register",
            "agent_id": self.agent_id,
            "projects": [
                {"slug": slug, "path": path}
                for slug, path in self.projects.items()
            ],
            "capabilities": ["clone", "worktree", "list_dirs", "list_repos"],
            "worktrees": worktrees_by_slug,
        }
        await self.ws.send(json.dumps(payload))
        logger.info("Registered agent %s with %d project(s)", self.agent_id, len(self.projects))

    async def update_projects(self, projects: dict[str, str]) -> None:
        """Update projects dict and re-register if connected."""
        self.projects = projects
        if self.ws is not None:
            await self._register()

    def _ensure_claude_settings(self, project_path: str) -> None:
        """Write .claude/settings.json to project dir if not already present.

        This ensures Claude Code has sane permissions when running inside
        a user's project — without requiring users to configure anything manually.
        The file is only written if it doesn't exist yet, so user overrides are respected.
        """
        import json as _json

        settings_dir = Path(project_path) / ".claude"
        settings_file = settings_dir / "settings.json"

        if settings_file.exists():
            return  # respect existing config

        settings = {
            "permissions": {
                "allow": [
                    "Bash(uv *)",
                    "Bash(python *)",
                    "Bash(python3 *)",
                    "Bash(pip *)",
                    "Bash(pip3 *)",
                    "Bash(pytest *)",
                    "Bash(git *)",
                    "Bash(gh *)",
                    "Bash(npm *)",
                    "Bash(npx *)",
                    "Bash(pnpm *)",
                    "Bash(yarn *)",
                    "Bash(bun *)",
                    "Bash(node *)",
                    "Bash(cargo *)",
                    "Bash(go *)",
                    "Bash(make *)",
                    "Bash(docker *)",
                    "Bash(ls *)",
                    "Bash(cat *)",
                    "Bash(find *)",
                    "Bash(grep *)",
                    "Bash(mkdir *)",
                    "Bash(cp *)",
                    "Bash(mv *)",
                    "Bash(pwd)",
                    "Bash(echo *)",
                    "Bash(touch *)",
                    "Bash(which *)",
                    "Bash(curl *)",
                    "Bash(jq *)",
                    "Read",
                    "Edit",
                    "MultiEdit",
                    "Write",
                ],
                "deny": [
                    "Bash(rm *)",
                    "Bash(rmdir *)",
                    "Bash(sudo rm *)",
                    "Bash(dd *)",
                    "Bash(mkfs *)",
                ],
            }
        }

        try:
            settings_dir.mkdir(exist_ok=True)
            settings_file.write_text(_json.dumps(settings, indent=2))
            logger.info("Wrote .claude/settings.json to %s", project_path)
        except Exception as exc:
            logger.warning("Could not write .claude/settings.json to %s: %s", project_path, exc)

    async def _handle_projects_data(self, data: dict) -> None:
        """Re-run discovery with server-pushed project list and paths, then re-register."""
        from taskfloor_agent.discovery import discover_projects

        projects = data.get("projects", [])
        server_paths = data.get("paths", [])

        # Update scan_dirs from server if provided
        server_scan_dirs = data.get("scan_dirs")
        if server_scan_dirs:
            self._scan_dirs = [Path(d).expanduser() for d in server_scan_dirs]
            logger.info("Updated scan_dirs from server: %s", server_scan_dirs)

        id_to_slug = {p["id"]: p["slug"] for p in projects}

        # Priority 1: user-configured paths from server
        matched: dict[str, str] = {}
        for up in server_paths:
            slug = id_to_slug.get(up["project_id"])
            if slug and up.get("local_path"):
                expanded = os.path.expanduser(up["local_path"])
                if os.path.isdir(expanded):
                    matched[slug] = expanded

        # Priority 2: auto-discovery via scan_dirs
        auto = discover_projects(projects, self._scan_dirs, [])
        for slug, path in auto.items():
            if slug not in matched:
                matched[slug] = str(path)

        # Ensure .claude/settings.json exists in every matched project
        for path in matched.values():
            self._ensure_claude_settings(path)

        # Only re-register if the project set changed
        if matched != self.projects:
            self.projects = matched
            if self.ws is not None:
                await self._register()
            logger.info("projects_data: matched %d project(s): %s", len(matched), list(matched))

        # Report status back to server
        all_slugs = {p["slug"] for p in projects}
        unmatched = [s for s in all_slugs if s not in matched]
        if self.ws is not None:
            try:
                await self.ws.send(json.dumps({
                    "type": "project_status",
                    "matched": [{"slug": s, "path": p} for s, p in matched.items()],
                    "unmatched": [{"slug": s, "reason": "not found locally"} for s in unmatched],
                }))
            except Exception:
                pass

    async def _handle_project_added(self, data: dict) -> None:
        """Try to discover a newly created project via scan_dirs."""
        from taskfloor_agent.discovery import discover_projects

        project = data.get("project", {})
        if not project:
            return
        logger.info("Project added on server: %s", project.get("slug"))

        # Run discovery with just the new project to avoid re-scanning everything
        new_slug = project.get("slug")
        if not new_slug or new_slug in self.projects:
            return

        found = discover_projects([project], self._scan_dirs, [])
        if found:
            self.projects = {**self.projects, **{s: str(p) for s, p in found.items()}}
            if self.ws is not None:
                await self._register()
            logger.info("Auto-discovered new project: %s", list(found))

    async def _handle_message(self, data: dict) -> None:
        """Dispatch incoming message to the appropriate handler."""
        msg_type = data.get("type")

        if msg_type == "message":
            await self._handle_run(data)
        elif msg_type == "cancel":
            await self._handle_cancel(data)
        elif msg_type == "cleanup":
            await self._handle_cleanup(data)
        elif msg_type == "list_dirs":
            await self._handle_list_dirs(data)
        elif msg_type == "list_repos":
            await self._handle_list_repos(data)
        elif msg_type == "clone":
            await self._handle_clone(data)
        elif msg_type == "remove_worktree":
            await self._handle_remove_worktree(data)
        elif msg_type == "validate_path":
            await self._handle_validate_path(data)
        elif msg_type == "projects_data":
            await self._handle_projects_data(data)
        elif msg_type == "project_added":
            await self._handle_project_added(data)
        elif msg_type == "project_removed":
            slug = data.get("slug")
            if slug and slug in self.projects:
                del self.projects[slug]
                logger.info("Removed project %s from local projects", slug)
        elif msg_type == "human_review_probe":
            await self._handle_human_review_probe(data)
        elif msg_type == "open_ide":
            await self._handle_open_ide(data)
        elif msg_type == "create_pr":
            await self._handle_create_pr(data)
        elif msg_type == "merge_branch":
            await self._handle_merge_branch(data)
        elif msg_type == "open_file":
            await self._handle_open_file(data)
        elif msg_type == "check_conflicts":
            await self._handle_check_conflicts(data)
        elif msg_type == "resolve_conflicts":
            await self._handle_resolve_conflicts(data)
        else:
            logger.warning("Unknown message type: %s", msg_type)

    async def _handle_run(self, data: dict) -> None:
        """Start or continue a Claude session for a task."""
        new_session = data.get("new_session", False)
        phase = data.get("phase", "")
        task_id: int = data["task_id"]
        content: str = data.get("content", "")
        context: str = data.get("context", "")
        branch: str = data.get("branch", "main")
        worktree_name: str = data.get("worktree_name", f"task-{task_id}")
        project_slug: str = data.get("project_slug", "")

        logger.info(
            "[task:%s] Run request (phase=%s, new_session=%s)",
            task_id, phase or "manual", new_session,
        )

        local_path = self.projects.get(project_slug)
        if not local_path:
            await self._ws_send({"type": "error", "task_id": task_id, "message": f"Project '{project_slug}' not found"})
            return

        prefix = f"task-{task_id}-"
        task_title = worktree_name[len(prefix):] if worktree_name.startswith(prefix) else worktree_name

        try:
            wt_path = create_worktree(local_path, task_id, task_title, base_branch=branch)
        except Exception as exc:
            await self._ws_send({"type": "error", "task_id": task_id, "message": f"Worktree failed: {exc}"})
            return

        # New session: close existing client
        if new_session and self.sessions.is_running(task_id):
            await self.sessions.close(task_id)

        # Get or create persistent session
        if not self.sessions.is_running(task_id):
            system_prompt = context if context else ""
            session_id = data.get("session_id")
            await self.sessions.get_or_create(task_id, str(wt_path), system_prompt, session_id)

        prompt = content

        session_id = data.get("session_id") or None
        await self._ws_send({"type": "task_status", "task_id": task_id, "running": True})
        task = asyncio.create_task(self._stream_session(task_id, prompt, str(wt_path), session_id=session_id))
        self._tasks[task_id] = task

    async def _stream_session(self, task_id: int, prompt: str, wt_path: str = "", session_id: str | None = None) -> None:
        """Stream a query through the persistent session."""
        logger.info("[task:%d] Streaming session query", task_id)
        # Re-create session if lost (e.g. after agent restart with stale state)
        if task_id not in self.sessions.clients and wt_path:
            logger.info("[task:%d] Session missing, resuming (session_id=%s) in %s", task_id, session_id, wt_path)
            await self.sessions.get_or_create(task_id, wt_path, session_id=session_id)
        try:
            async for chunk in self.sessions.query(task_id, prompt):
                if chunk["type"] == "rate_limit_update":
                    await self._ws_send(chunk)
                    continue

                if chunk.get("done"):
                    # Save session_id to backend for persistence
                    session_id = chunk.get("session_id")
                    if session_id:
                        await self._ws_send({
                            "type": "session_update",
                            "task_id": task_id,
                            "session_id": session_id,
                        })
                    chunk["diff_stat"] = get_diff_stat(wt_path) if wt_path else ""

                await self._ws_send(chunk)
        except Exception as exc:
            logger.exception("[task:%d] Stream error", task_id)
            await self._ws_send({"type": "error", "task_id": task_id, "message": str(exc)})
        finally:
            self._tasks.pop(task_id, None)

    async def _ws_send(self, data: dict) -> None:
        """Send JSON via WebSocket, silently ignoring if disconnected."""
        if self.ws:
            try:
                await self.ws.send(json.dumps(data))
            except Exception:
                logger.warning("Failed to send WS message (disconnected?)")

    async def _handle_cancel(self, data: dict) -> None:
        """Cancel the session and asyncio task for a task_id."""
        task_id: int = data["task_id"]
        logger.info("Cancelling task %d", task_id)

        await self.sessions.cancel(task_id)

        asyncio_task = self._tasks.pop(task_id, None)
        if asyncio_task and not asyncio_task.done():
            asyncio_task.cancel()
            try:
                await asyncio_task
            except (asyncio.CancelledError, Exception):
                pass

    async def _handle_cleanup(self, data: dict) -> None:
        """Remove the worktree for a task_id across all projects."""
        task_id: int = data["task_id"]
        worktree_name: str = data.get("worktree_name", f"task-{task_id}")

        prefix = f"task-{task_id}-"
        if worktree_name.startswith(prefix):
            task_title = worktree_name[len(prefix):]
        else:
            task_title = worktree_name

        for slug, local_path in self.projects.items():
            try:
                remove_worktree(local_path, task_id, task_title)
                logger.info("Cleaned up worktree for task %d in project %s", task_id, slug)
            except Exception as exc:
                logger.warning(
                    "Failed to remove worktree for task %d in project %s: %s",
                    task_id, slug, exc,
                )

    async def _handle_list_dirs(self, data: dict) -> None:
        """Return available directories for cloning."""
        request_id = data.get("request_id", "")
        dirs = []
        for scan_dir in self._scan_dirs:
            expanded = os.path.expanduser(str(scan_dir))
            if os.path.isdir(expanded):
                dirs.append({"path": expanded, "label": str(scan_dir)})
        home = os.path.expanduser("~")
        if not any(d["path"] == home for d in dirs):
            dirs.append({"path": home, "label": "~"})
        await self._ws_send({
            "type": "list_dirs_result",
            "request_id": request_id,
            "dirs": dirs,
        })

    async def _handle_list_repos(self, data: dict) -> None:
        """Return local repos not linked to any project."""
        from taskfloor_agent.discovery import scan_all_repos, get_git_remote_url, extract_repo_id
        request_id = data.get("request_id", "")
        linked_repos: set[str] = set()
        for slug, path in self.projects.items():
            remote = get_git_remote_url(Path(path))
            if remote:
                repo_id = extract_repo_id(remote)
                if repo_id:
                    linked_repos.add(repo_id)
        repos = scan_all_repos(self._scan_dirs, linked_repos)
        await self._ws_send({
            "type": "list_repos_result",
            "request_id": request_id,
            "repos": repos,
        })

    async def _handle_clone(self, data: dict) -> None:
        """Clone a repository to the specified directory."""
        import subprocess
        request_id = data.get("request_id", "")
        url = data.get("url", "")
        target_dir = data.get("target_dir", "")
        project_slug = data.get("project_slug", "")
        target_dir = os.path.expanduser(target_dir)
        repo_name = url.rstrip("/").rstrip(".git").rsplit("/", 1)[-1]
        clone_path = os.path.join(target_dir, repo_name)
        if os.path.exists(clone_path):
            await self._ws_send({
                "type": "clone_result",
                "request_id": request_id,
                "success": False,
                "error": f"Directory already exists: {clone_path}",
            })
            return
        try:
            await self._ws_send({
                "type": "clone_progress",
                "request_id": request_id,
                "project_slug": project_slug,
                "message": f"Cloning {url}...",
            })
            result = subprocess.run(
                ["git", "clone", url, clone_path],
                capture_output=True, text=True, timeout=300,
            )
            if result.returncode != 0:
                await self._ws_send({
                    "type": "clone_result",
                    "request_id": request_id,
                    "success": False,
                    "error": result.stderr.strip(),
                })
                return
            await self._ws_send({
                "type": "clone_progress",
                "request_id": request_id,
                "project_slug": project_slug,
                "message": "Clone complete, registering project...",
            })
            self.projects[project_slug] = clone_path
            await self._register()
            await self._ws_send({
                "type": "clone_result",
                "request_id": request_id,
                "success": True,
                "path": clone_path,
            })
        except subprocess.TimeoutExpired:
            await self._ws_send({
                "type": "clone_result",
                "request_id": request_id,
                "success": False,
                "error": "Clone timed out after 5 minutes",
            })
        except Exception as exc:
            await self._ws_send({
                "type": "clone_result",
                "request_id": request_id,
                "success": False,
                "error": str(exc),
            })

    async def _handle_remove_worktree(self, data: dict) -> None:
        """Remove a worktree for a specific task."""
        request_id = data.get("request_id", "")
        project_slug = data.get("project_slug", "")
        task_id = data.get("task_id")
        local_path = self.projects.get(project_slug)
        if not local_path:
            await self._ws_send({
                "type": "remove_worktree_result",
                "request_id": request_id,
                "success": False,
                "error": f"Project '{project_slug}' not found locally",
            })
            return
        try:
            remove_worktree(local_path, task_id, "")
            await self._ws_send({
                "type": "remove_worktree_result",
                "request_id": request_id,
                "success": True,
            })
        except Exception as exc:
            await self._ws_send({
                "type": "remove_worktree_result",
                "request_id": request_id,
                "success": False,
                "error": str(exc),
            })

    async def _handle_validate_path(self, data: dict) -> None:
        """Check if a given path is a valid git repo and return its info."""
        from taskfloor_agent.discovery import get_git_remote_url, extract_repo_id

        request_id = data.get("request_id", "")
        path = data.get("path", "")
        expanded = os.path.expanduser(path)

        if not os.path.isdir(expanded):
            await self._ws_send({
                "type": "validate_path_result",
                "request_id": request_id,
                "valid": False,
                "error": "Directory does not exist",
            })
            return

        if not os.path.isdir(os.path.join(expanded, ".git")):
            await self._ws_send({
                "type": "validate_path_result",
                "request_id": request_id,
                "valid": False,
                "error": "Not a git repository",
            })
            return

        remote_url = get_git_remote_url(Path(expanded)) or ""
        repo_id = extract_repo_id(remote_url) if remote_url else ""

        await self._ws_send({
            "type": "validate_path_result",
            "request_id": request_id,
            "valid": True,
            "path": expanded,
            "name": os.path.basename(expanded),
            "remote_url": remote_url,
            "github_repo": repo_id,
        })

    def _find_worktree_path(self, project_slug: str, task_id: int) -> str | None:
        """Locate the worktree directory for a task. Returns absolute path or None."""
        local_path = self.projects.get(project_slug)
        if not local_path:
            return None
        candidate = os.path.join(local_path, ".worktrees", f"task-{task_id}")
        if os.path.isdir(candidate):
            return candidate
        return None

    async def _handle_human_review_probe(self, data: dict) -> None:
        """Detect IDEs, default branch, and existing PR for human review panel."""
        import subprocess
        request_id = data.get("request_id", "")
        task_id = data.get("task_id")
        project_slug = data.get("project_slug", "")

        if not project_slug:
            for slug in self.projects:
                if self._find_worktree_path(slug, task_id):
                    project_slug = slug
                    break

        wt_path = self._find_worktree_path(project_slug, task_id) if project_slug else None

        available_ides: list[str] = []
        ide_checks = [
            ("vscode", ["code", "--version"]),
            ("zed", ["zed", "--version"]),
        ]
        for ide_name, cmd in ide_checks:
            try:
                subprocess.run(cmd, capture_output=True, timeout=5)
                available_ides.append(ide_name)
            except (FileNotFoundError, subprocess.TimeoutExpired):
                pass
        if os.path.isdir("/Applications/PyCharm CE.app") or os.path.isdir("/Applications/PyCharm.app"):
            available_ides.append("pycharm")

        default_branch = "main"
        if wt_path:
            try:
                result = subprocess.run(
                    ["git", "symbolic-ref", "refs/remotes/origin/HEAD"],
                    capture_output=True, text=True, cwd=wt_path, timeout=10,
                )
                if result.returncode == 0:
                    default_branch = result.stdout.strip().split("/")[-1] or "main"
            except Exception:
                pass

        existing_pr_url = None
        if wt_path:
            try:
                result = subprocess.run(
                    ["gh", "pr", "view", "--json", "url", "--jq", ".url"],
                    capture_output=True, text=True, cwd=wt_path, timeout=15,
                )
                if result.returncode == 0:
                    url = result.stdout.strip()
                    if url.startswith("http"):
                        existing_pr_url = url
            except (FileNotFoundError, subprocess.TimeoutExpired):
                pass

        await self._ws_send({
            "type": "human_review_probe_result",
            "request_id": request_id,
            "available_ides": available_ides,
            "default_branch": default_branch,
            "existing_pr_url": existing_pr_url,
        })

    async def _handle_open_ide(self, data: dict) -> None:
        """Open the task's worktree in the requested IDE."""
        import subprocess
        task_id = data.get("task_id")
        project_slug = data.get("project_slug", "")
        ide = data.get("ide", "vscode")

        wt_path = self._find_worktree_path(project_slug, task_id)
        if not wt_path:
            logger.warning("open_ide: worktree not found for task %s / project %s", task_id, project_slug)
            return

        try:
            if ide == "vscode":
                subprocess.Popen(["code", wt_path])
            elif ide == "zed":
                subprocess.Popen(["zed", wt_path])
            elif ide == "pycharm":
                if os.path.isdir("/Applications/PyCharm CE.app"):
                    subprocess.Popen(["open", "-a", "PyCharm CE", wt_path])
                else:
                    subprocess.Popen(["open", "-a", "PyCharm", wt_path])
            else:
                subprocess.Popen(["open", wt_path])
        except Exception as exc:
            logger.warning("Failed to open IDE %s for task %s: %s", ide, task_id, exc)

    async def _handle_create_pr(self, data: dict) -> None:
        """Run Claude to generate a PR description and create the PR via gh."""
        task_id = data.get("task_id")
        project_slug = data.get("project_slug", "")

        wt_path = self._find_worktree_path(project_slug, task_id)
        if not wt_path:
            logger.warning("create_pr: worktree not found for task %s", task_id)
            return

        prompt = (
            "Create a GitHub Pull Request for this branch.\n\n"
            "1. Run `git log main..HEAD --oneline` to see what was implemented.\n"
            "2. Run `git diff main...HEAD --stat` to see changed files.\n"
            "3. Write a PR title (concise, under 70 chars, imperative form).\n"
            "4. Write a PR body with: ## Summary (3-5 bullets), ## Test plan (what was tested).\n"
            "5. Run: gh pr create --title \"<title>\" --body \"<body>\"\n"
            "   If gh is not installed or not authenticated, say so clearly.\n"
            "6. Output the PR URL on its own line at the end.\n"
        )

        # Ensure session exists (may have been lost after agent restart)
        if task_id not in self.sessions.clients:
            session_id = data.get("session_id") or None
            await self.sessions.get_or_create(task_id, wt_path, session_id=session_id)

        task = asyncio.create_task(self._stream_create_pr(task_id, wt_path, prompt, project_slug))
        self._tasks[task_id] = task

    async def _stream_create_pr(self, task_id: int, wt_path: str, prompt: str, project_slug: str) -> None:
        """Create PR using the persistent session."""
        import subprocess
        output_lines: list[str] = []
        await self._ws_send({"type": "task_status", "task_id": task_id, "running": True})

        try:
            async for chunk in self.sessions.query(task_id, prompt):
                if chunk.get("content"):
                    output_lines.append(chunk["content"])
                if chunk["type"] == "chunk":
                    await self._ws_send(chunk)
        except Exception as exc:
            await self._ws_send({"type": "error", "task_id": task_id, "message": str(exc)})
            return
        finally:
            self._tasks.pop(task_id, None)

        full_output = "".join(output_lines)
        pr_url = None
        for line in full_output.splitlines():
            line = line.strip()
            if line.startswith("https://github.com/") and "/pull/" in line:
                pr_url = line
                break
        if not pr_url:
            try:
                result = subprocess.run(
                    ["gh", "pr", "view", "--json", "url", "--jq", ".url"],
                    capture_output=True, text=True, cwd=wt_path, timeout=15,
                )
                if result.returncode == 0:
                    url = result.stdout.strip()
                    if url.startswith("http"):
                        pr_url = url
            except Exception:
                pass
        if pr_url:
            await self._ws_send({"type": "pr_created", "task_id": task_id, "pr_url": pr_url})

    async def _handle_merge_branch(self, data: dict) -> None:
        """Run Claude to merge the task branch into the default branch and delete worktree."""
        task_id = data.get("task_id")
        project_slug = data.get("project_slug", "")

        wt_path = self._find_worktree_path(project_slug, task_id)
        if not wt_path:
            logger.warning("merge_branch: worktree not found for task %s", task_id)
            return

        local_path = self.projects.get(project_slug, "")
        task_branch = f"taskfloor/task-{task_id}"

        prompt = (
            f"Merge the current task branch into the default branch.\n\n"
            f"1. Detect the default branch: `git symbolic-ref refs/remotes/origin/HEAD | sed 's@^refs/remotes/origin/@@'`\n"
            f"2. Run:\n"
            f"   git fetch origin\n"
            f"   git checkout <default_branch>\n"
            f"   git pull origin <default_branch>\n"
            f"   git merge --no-ff {task_branch}\n"
            f"3. If there are merge conflicts: resolve them, then `git add -A && git merge --continue`\n"
            f"4. Run: git push origin <default_branch>\n"
            f"5. If anything fails, report the error clearly and stop.\n"
            f"6. On success, output exactly: <<MERGE_COMPLETE>>\n"
        )

        # Ensure session exists (may have been lost after agent restart)
        if task_id not in self.sessions.clients:
            session_id = data.get("session_id") or None
            await self.sessions.get_or_create(task_id, wt_path, session_id=session_id)

        task = asyncio.create_task(self._stream_merge(task_id, wt_path, local_path, prompt))
        self._tasks[task_id] = task

    async def _stream_merge(self, task_id: int, wt_path: str, local_path: str, prompt: str) -> None:
        """Merge branch using the persistent session."""
        output_lines: list[str] = []
        await self._ws_send({"type": "task_status", "task_id": task_id, "running": True})

        try:
            async for chunk in self.sessions.query(task_id, prompt):
                if chunk.get("content"):
                    content = chunk["content"].replace("<<MERGE_COMPLETE>>", "")
                    output_lines.append(chunk["content"])
                    if content.strip():
                        await self._ws_send({**chunk, "content": content})
                    elif chunk.get("done"):
                        await self._ws_send(chunk)
                else:
                    await self._ws_send(chunk)
        except Exception as exc:
            await self._ws_send({"type": "error", "task_id": task_id, "message": str(exc)})
            return
        finally:
            self._tasks.pop(task_id, None)

        full_output = "".join(output_lines)
        if "<<MERGE_COMPLETE>>" in full_output:
            try:
                remove_worktree(local_path, task_id, "")
                logger.info("Deleted worktree for task %d after merge", task_id)
            except Exception as exc:
                logger.warning("Failed to delete worktree: %s", exc)
            await self.sessions.close(task_id)
            await self._ws_send({"type": "merge_complete", "task_id": task_id})

    async def _handle_check_conflicts(self, data: dict) -> None:
        """Check if merging the task branch into default would cause conflicts."""
        import subprocess
        task_id = data.get("task_id")
        project_slug = data.get("project_slug", "")

        wt_path = self._find_worktree_path(project_slug, task_id)
        if not wt_path:
            logger.warning("check_conflicts: worktree not found for task %s", task_id)
            await self._ws_send({"type": "conflict_result", "task_id": task_id, "has_conflicts": False})
            return

        has_conflicts = False
        try:
            # Detect default branch
            db_result = subprocess.run(
                ["git", "symbolic-ref", "refs/remotes/origin/HEAD"],
                capture_output=True, text=True, cwd=wt_path, timeout=10,
            )
            default_branch = db_result.stdout.strip().split("/")[-1] if db_result.returncode == 0 else "main"

            # Fetch latest
            subprocess.run(["git", "fetch", "origin"], capture_output=True, cwd=wt_path, timeout=30)

            # Try merge --no-commit --no-ff
            merge_result = subprocess.run(
                ["git", "merge", "--no-commit", "--no-ff", f"origin/{default_branch}"],
                capture_output=True, text=True, cwd=wt_path, timeout=30,
            )
            if merge_result.returncode != 0:
                has_conflicts = True

            # Always abort the test merge
            subprocess.run(["git", "merge", "--abort"], capture_output=True, cwd=wt_path, timeout=10)
        except Exception as exc:
            logger.warning("check_conflicts failed for task %s: %s", task_id, exc)

        logger.info("check_conflicts: task %d has_conflicts=%s", task_id, has_conflicts)
        await self._ws_send({"type": "conflict_result", "task_id": task_id, "has_conflicts": has_conflicts})

    async def _handle_resolve_conflicts(self, data: dict) -> None:
        """Run Claude to rebase the task branch onto the default branch and resolve conflicts."""
        task_id = data.get("task_id")
        project_slug = data.get("project_slug", "")

        wt_path = self._find_worktree_path(project_slug, task_id)
        if not wt_path:
            logger.warning("resolve_conflicts: worktree not found for task %s", task_id)
            return

        prompt = (
            "Rebase this branch onto the default branch and resolve any conflicts.\n\n"
            "1. Detect the default branch: `git symbolic-ref refs/remotes/origin/HEAD | sed 's@^refs/remotes/origin/@@'`\n"
            "2. Fetch latest: `git fetch origin`\n"
            "3. Rebase: `git rebase origin/<default_branch>`\n"
            "4. If there are conflicts:\n"
            "   - For each conflicted file: read the file, understand both sides, resolve correctly\n"
            "   - `git add <resolved files>` then `git rebase --continue`\n"
            "   - Repeat until rebase is complete\n"
            "5. Verify the code still works: run tests if available\n"
            "6. Push the rebased branch: `git push --force-with-lease`\n"
        )

        await self._ws_send({"type": "task_status", "task_id": task_id, "running": True})
        task = asyncio.create_task(self._stream_resolve(task_id, prompt, wt_path))
        self._tasks[task_id] = task

    async def _stream_resolve(self, task_id: int, prompt: str, wt_path: str) -> None:
        """Stream resolve session, then report conflict_result."""
        await self._stream_session(task_id, prompt, wt_path)
        # After resolve, re-check if conflicts remain
        await self._ws_send({"type": "conflict_result", "task_id": task_id, "has_conflicts": False})

    async def _handle_open_file(self, data: dict) -> None:
        """Open a file path in the best available editor."""
        import subprocess
        task_id = data.get("task_id")
        project_slug = data.get("project_slug", "")
        rel_path = data.get("path", "")

        abs_path = None
        wt_path = self._find_worktree_path(project_slug, task_id) if task_id else None
        if wt_path:
            candidate = os.path.join(wt_path, rel_path)
            if os.path.exists(candidate):
                abs_path = candidate
        if not abs_path:
            local_path = self.projects.get(project_slug, "")
            if local_path:
                candidate = os.path.join(local_path, rel_path)
                if os.path.exists(candidate):
                    abs_path = candidate
        if not abs_path:
            logger.warning("open_file: path not found: %s (task %s, project %s, wt=%s)", rel_path, task_id, project_slug, wt_path)
            return

        logger.info("open_file: opening %s", abs_path)
        try:
            for cmd in [["code", abs_path], ["zed", abs_path]]:
                try:
                    subprocess.Popen(cmd)
                    return
                except FileNotFoundError:
                    continue
            subprocess.Popen(["open", abs_path])
        except Exception as exc:
            logger.warning("Failed to open file %s: %s", abs_path, exc)

    async def stop(self) -> None:
        """Shut down: cancel all tasks and sessions, close WebSocket."""
        self._running = False

        for asyncio_task in list(self._tasks.values()):
            if not asyncio_task.done():
                asyncio_task.cancel()

        if self._tasks:
            await asyncio.gather(*self._tasks.values(), return_exceptions=True)
        self._tasks.clear()

        for task_id in list(self.sessions.clients.keys()):
            await self.sessions.close(task_id)

        if self.ws:
            await self.ws.close()
            self.ws = None

        logger.info("AgentWSClient stopped")
