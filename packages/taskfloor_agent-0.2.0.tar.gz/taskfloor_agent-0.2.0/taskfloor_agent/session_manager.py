"""Persistent Claude Code session manager using claude-agent-sdk."""
import asyncio
import logging
from collections.abc import AsyncGenerator
from dataclasses import dataclass, field
from pathlib import Path

from claude_agent_sdk import ClaudeSDKClient, ClaudeAgentOptions
from claude_agent_sdk.types import (
    AssistantMessage,
    ResultMessage,
    RateLimitEvent,
    TextBlock,
    ToolUseBlock,
)

logger = logging.getLogger(__name__)


def _format_tool_label(name: str, inp: dict) -> str:
    """Format a human-readable label for a tool use event."""
    if name == "Read":
        return f"Reading {inp.get('file_path', '').split('/')[-1] or 'file'}..."
    if name == "Edit" or name == "MultiEdit":
        return f"Editing {inp.get('file_path', '').split('/')[-1] or 'file'}..."
    if name == "Write":
        return f"Writing {inp.get('file_path', '').split('/')[-1] or 'file'}..."
    if name == "Bash":
        cmd = inp.get("command", "")
        short = cmd[:60] + "..." if len(cmd) > 60 else cmd
        return f"Running: {short}" if short else "Running command..."
    if name == "Glob":
        return f"Searching {inp.get('pattern', '')}..."
    if name == "Grep":
        return f"Searching for '{inp.get('pattern', '')}'..."
    if name == "Agent":
        return f"Spawning agent: {inp.get('description', inp.get('prompt', '')[:40])}..."
    return f"Using {name}..."


@dataclass
class TokenUsage:
    input_tokens: int = 0
    output_tokens: int = 0
    cache_read_tokens: int = 0
    cache_creation_tokens: int = 0
    total_cost_usd: float = 0.0
    num_turns: int = 0


class SessionManager:
    """Manages persistent ClaudeSDKClient instances keyed by task_id."""

    def __init__(self) -> None:
        self.clients: dict[int, ClaudeSDKClient] = {}
        self.session_ids: dict[int, str] = {}
        self.token_usage: dict[int, TokenUsage] = {}
        self.rate_limit_info: dict | None = None
        self._locks: dict[int, asyncio.Lock] = {}

    def _get_lock(self, task_id: int) -> asyncio.Lock:
        if task_id not in self._locks:
            self._locks[task_id] = asyncio.Lock()
        return self._locks[task_id]

    async def get_or_create(
        self,
        task_id: int,
        worktree_path: str | Path,
        system_prompt: str = "",
        session_id: str | None = None,
    ) -> ClaudeSDKClient:
        """Get existing client or create a new one for the task."""
        if task_id in self.clients:
            return self.clients[task_id]

        options = ClaudeAgentOptions(
            cwd=str(worktree_path),
            system_prompt=system_prompt or None,
            permission_mode="auto",
        )

        # Resume existing session if session_id provided
        if session_id:
            options.resume = session_id
            logger.info("[task:%d] Resuming session %s", task_id, session_id)
        else:
            logger.info("[task:%d] Creating new session in %s", task_id, worktree_path)

        client = ClaudeSDKClient(options=options)
        await client.__aenter__()
        self.clients[task_id] = client
        self.token_usage[task_id] = TokenUsage()
        return client

    async def query(
        self,
        task_id: int,
        prompt: str,
    ) -> AsyncGenerator[dict, None]:
        """Send a query and stream responses as chunk dicts."""
        client = self.clients.get(task_id)
        if client is None:
            raise RuntimeError(f"No session for task {task_id}")

        async with self._get_lock(task_id):
            logger.info("[task:%d] Sending query (%d chars)", task_id, len(prompt))
            await client.query(prompt)

            async for msg in client.receive_response():
                logger.debug("[task:%d] SDK msg: %s", task_id, type(msg).__name__)
                if isinstance(msg, AssistantMessage):
                    for block in msg.content:
                        if isinstance(block, TextBlock) and block.text:
                            yield {
                                "type": "chunk",
                                "task_id": task_id,
                                "content": block.text,
                                "done": False,
                            }
                        elif isinstance(block, ToolUseBlock):
                            # Stream tool activity so UI shows what Claude is doing
                            tool_label = _format_tool_label(block.name, block.input)
                            yield {
                                "type": "tool_use",
                                "task_id": task_id,
                                "tool": block.name,
                                "label": tool_label,
                            }

                elif isinstance(msg, ResultMessage):
                    # Accumulate token usage
                    usage = self.token_usage.get(task_id, TokenUsage())
                    if msg.usage:
                        usage.input_tokens += msg.usage.get("input_tokens", 0)
                        usage.output_tokens += msg.usage.get("output_tokens", 0)
                        usage.cache_read_tokens += msg.usage.get("cache_read_input_tokens", 0)
                        usage.cache_creation_tokens += msg.usage.get("cache_creation_input_tokens", 0)
                    if msg.total_cost_usd:
                        usage.total_cost_usd += msg.total_cost_usd
                    usage.num_turns += msg.num_turns
                    self.token_usage[task_id] = usage

                    # Save session_id for resume
                    if msg.session_id:
                        self.session_ids[task_id] = msg.session_id

                    logger.info(
                        "[task:%d] Result: turns=%d, cost=$%.4f, session=%s",
                        task_id, msg.num_turns, msg.total_cost_usd or 0, msg.session_id,
                    )

                    exit_code = 1 if msg.is_error else 0
                    yield {
                        "type": "chunk",
                        "task_id": task_id,
                        "content": "",
                        "done": True,
                        "exit_code": exit_code,
                        "session_id": msg.session_id,
                        "token_usage": {
                            "input_tokens": usage.input_tokens,
                            "output_tokens": usage.output_tokens,
                            "cache_read_tokens": usage.cache_read_tokens,
                            "total_cost_usd": usage.total_cost_usd,
                        },
                    }

                elif isinstance(msg, RateLimitEvent):
                    info = msg.rate_limit_info
                    logger.info("[task:%d] RateLimitEvent: type=%s, utilization=%.2f, status=%s",
                                task_id, info.rate_limit_type, info.utilization or 0, info.status)
                    self.rate_limit_info = {
                        "utilization": info.utilization,
                        "resets_at": info.resets_at,
                        "rate_limit_type": info.rate_limit_type,
                        "status": info.status,
                    }
                    yield {
                        "type": "rate_limit_update",
                        "task_id": task_id,
                        "rate_limit": self.rate_limit_info,
                    }

    async def cancel(self, task_id: int) -> None:
        """Cancel and close the client for a task."""
        logger.info("[task:%d] Cancelling session", task_id)
        client = self.clients.pop(task_id, None)
        if client:
            try:
                await client.__aexit__(None, None, None)
                logger.info("[task:%d] Session cancelled OK", task_id)
            except Exception as exc:
                logger.warning("[task:%d] Error closing client on cancel: %s", task_id, exc)
        else:
            logger.info("[task:%d] No active session to cancel", task_id)
        self._locks.pop(task_id, None)

    async def close(self, task_id: int) -> None:
        """Gracefully close a session (task done/merged)."""
        await self.cancel(task_id)
        logger.info("[task:%d] Session closed", task_id)

    def get_session_id(self, task_id: int) -> str | None:
        return self.session_ids.get(task_id)

    def get_usage(self, task_id: int) -> TokenUsage | None:
        return self.token_usage.get(task_id)

    def get_rate_limits(self) -> dict | None:
        return self.rate_limit_info

    def is_running(self, task_id: int) -> bool:
        return task_id in self.clients

    def has_session(self, task_id: int) -> bool:
        return task_id in self.clients or task_id in self.session_ids
