"""Click-based CLI entry point for the TaskFloor agent."""

import asyncio
import logging
import os
import sys

import click
import httpx

# Disable system proxy detection — macOS proxy breaks localhost connections
_http = httpx.Client(trust_env=False, timeout=15)
_http_kwargs = {"trust_env": False, "timeout": 15}  # for AsyncClient

from taskfloor_agent.config import (
    load_config,
    save_config,
    get_server,
    get_token,
    get_scan_dirs,
    get_project_paths,
    get_agent_id,
    default_agent_id,
    CONFIG_FILE,
)
from taskfloor_agent.discovery import discover_projects, scan_directory
from taskfloor_agent.ws_client import AgentWSClient
from taskfloor_agent.worktree import list_worktrees, remove as remove_worktree

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger(__name__)


@click.group()
@click.option("--config", "-c", envvar="TASKFLOOR_CONFIG", default=None, help="Path to config file (default: ~/.taskfloor/agent.yaml). Also via TASKFLOOR_CONFIG env var.")
@click.pass_context
def main(ctx, config):
    """TaskFloor Agent — connect your local repos to the task board."""
    if config:
        from taskfloor_agent.config import set_config_path
        set_config_path(config)


# ---------------------------------------------------------------------------
# login
# ---------------------------------------------------------------------------

@main.command()
def login():
    """Configure the agent with a server URL and token from TaskFloor Settings."""
    config = load_config()

    server = click.prompt(
        "Server URL",
        default=get_server(config),
    ).rstrip("/")

    click.echo("\nGenerate an agent token in TaskFloor → Settings → Agent Token")
    token = click.prompt("Paste your agent token").strip()

    # Verify token works
    try:
        check = _http.get(f"{server}/api/auth/me", headers={"Authorization": f"Bearer {token}"})
        check.raise_for_status()
        user_data = check.json()
        click.echo(f"Authenticated as {user_data.get('email', 'unknown')}.")
    except Exception as exc:
        click.echo(f"Token verification failed: {exc}")
        sys.exit(1)

    # Scan dirs
    raw_dirs = click.prompt(
        "Directories to scan for projects (comma-separated)",
        default="~/Projects",
    )
    scan_dirs_raw = [d.strip() for d in raw_dirs.split(",") if d.strip()]

    # Preserve existing project_paths
    existing_project_paths = [str(p) for p in get_project_paths(config)]

    new_config = {
        **config,
        "server": server,
        "token": token,
        "agent_id": get_agent_id(config) or default_agent_id(),
        "scan_dirs": scan_dirs_raw,
        "project_paths": existing_project_paths,
    }
    save_config(new_config)

    # Fetch projects
    headers = {"Authorization": f"Bearer {token}"}
    try:
        proj_resp = _http.get(f"{server}/api/projects", headers=headers)
        proj_resp.raise_for_status()
        projects = proj_resp.json()
    except Exception as exc:
        click.echo(f"Warning: could not fetch projects: {exc}")
        projects = []

    scan_dirs = [
        __import__("pathlib").Path(d).expanduser() for d in scan_dirs_raw
    ]
    project_paths = [
        __import__("pathlib").Path(p).expanduser() for p in existing_project_paths
    ]

    matched = discover_projects(projects, scan_dirs, project_paths)

    click.echo("\nProject discovery results:")
    for proj in projects:
        slug = proj.get("slug", "")
        if slug in matched:
            click.echo(f"  \u2713 {slug}  →  {matched[slug]}")
        else:
            click.echo(f"  \u2717 {slug}  (not found locally)")

    click.echo(f"\nConfig saved to: {CONFIG_FILE}")
    click.echo("Run `taskfloor-agent start` to connect.")


# ---------------------------------------------------------------------------
# start
# ---------------------------------------------------------------------------


@main.command()
@click.option("--foreground", "-f", is_flag=True, help="Run in foreground (default is background daemon).")
def start(foreground):
    """Start the agent. Runs as a background daemon by default."""
    from taskfloor_agent.config import PID_FILE, LOG_FILE

    config = load_config()
    token = get_token(config)
    server = get_server(config)

    if not token or not server:
        click.echo("Not configured. Run `taskfloor-agent login` first.")
        sys.exit(1)

    # Verify token is still valid
    try:
        check = _http.get(f"{server}/api/auth/me", headers={"Authorization": f"Bearer {token}"})
        if check.status_code == 401:
            click.echo("Token expired or invalid.")
            click.echo("Generate a new token in TaskFloor → Settings → Agent Token")
            new_token = click.prompt("Paste your agent token")
            if new_token.strip():
                config["token"] = new_token.strip()
                save_config(config)
                token = new_token.strip()
                click.echo("Token saved.")
            else:
                sys.exit(1)
    except Exception:
        pass  # offline — try connecting anyway

    # Check if already running
    if PID_FILE.exists():
        pid = int(PID_FILE.read_text().strip())
        if _pid_alive(pid):
            click.echo(f"Agent already running (PID {pid}). Use `taskfloor-agent stop` first.")
            sys.exit(1)
        PID_FILE.unlink()  # stale pid file

    if foreground:
        _run_agent(config)
    else:
        _start_daemon(config)


def _start_daemon(config: dict):
    """Fork agent into background, redirect output to log file."""
    import subprocess
    from taskfloor_agent.config import PID_FILE, LOG_FILE, CONFIG_DIR

    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    log_fh = open(LOG_FILE, "a")
    proc = subprocess.Popen(
        [sys.executable, "-m", "taskfloor_agent.cli", "start", "--foreground"],
        stdout=log_fh,
        stderr=log_fh,
        start_new_session=True,
    )
    PID_FILE.write_text(str(proc.pid))
    click.echo(f"Agent started (PID {proc.pid})")
    click.echo(f"Logs: {LOG_FILE}")
    click.echo("Use `taskfloor-agent stop` to stop, `taskfloor-agent logs` to view logs.")


def _run_agent(config: dict):
    """Run agent in foreground (blocking)."""
    from taskfloor_agent.config import PID_FILE

    server = get_server(config)
    token = get_token(config)
    agent_id = get_agent_id(config)
    scan_dirs = get_scan_dirs(config)
    project_paths = get_project_paths(config)

    # Write PID for foreground mode too
    PID_FILE.write_text(str(os.getpid()))

    async def _run():
        headers = {"Authorization": f"Bearer {token}"}
        try:
            async with httpx.AsyncClient(**_http_kwargs) as http:
                resp = await http.get(f"{server}/api/projects", headers=headers)
                resp.raise_for_status()
                projects = resp.json()

                # Fetch user-configured paths (priority over auto-discovery)
                paths_resp = await http.get(f"{server}/api/paths", headers=headers)
                paths_resp.raise_for_status()
                user_paths = paths_resp.json()  # [{"project_id": N, "local_path": "..."}, ...]
        except Exception as exc:
            click.echo(f"Warning: could not fetch projects: {exc}")
            projects = []
            user_paths = []

        # Build project_id → slug lookup
        id_to_slug = {p["id"]: p["slug"] for p in projects}

        # Priority 1: User-configured paths from TaskFloor
        matched: dict[str, str] = {}
        for up in user_paths:
            slug = id_to_slug.get(up["project_id"])
            if slug and up.get("local_path"):
                expanded = os.path.expanduser(up["local_path"])
                if os.path.isdir(expanded):
                    matched[slug] = expanded

        # Priority 2: Auto-discovery by git remote
        auto = discover_projects(projects, scan_dirs, project_paths)
        for slug, path in auto.items():
            if slug not in matched:
                matched[slug] = str(path)

        click.echo("Discovered projects:")
        for slug, path in matched.items():
            click.echo(f"  \u2713 {slug}  \u2192  {path}")
        if not matched:
            click.echo("  (none matched)")

        client = AgentWSClient(
            server_url=server,
            token=token,
            agent_id=agent_id,
            projects={slug: str(path) for slug, path in matched.items()},
            scan_dirs=[str(d) for d in scan_dirs],
        )

        # Ensure .claude/settings.json exists in each discovered project
        for path in matched.values():
            client._ensure_claude_settings(str(path))

        click.echo(f"Connecting to {server} as agent '{agent_id}' ...")
        try:
            await client.connect()
        except asyncio.CancelledError:
            pass
        finally:
            await client.stop()

    try:
        asyncio.run(_run())
    except KeyboardInterrupt:
        click.echo("\nAgent stopped.")
    finally:
        PID_FILE.unlink(missing_ok=True)


def _pid_alive(pid: int) -> bool:
    """Check if a process with given PID is running."""
    import signal
    try:
        os.kill(pid, 0)
        return True
    except (OSError, ProcessLookupError):
        return False


# ---------------------------------------------------------------------------
# stop
# ---------------------------------------------------------------------------

@main.command()
def stop():
    """Stop the background agent."""
    import signal
    from taskfloor_agent.config import PID_FILE

    if not PID_FILE.exists():
        click.echo("Agent is not running (no PID file).")
        return

    pid = int(PID_FILE.read_text().strip())
    if not _pid_alive(pid):
        click.echo("Agent is not running (stale PID file). Cleaning up.")
        PID_FILE.unlink()
        return

    os.kill(pid, signal.SIGTERM)
    click.echo(f"Agent stopped (PID {pid}).")
    PID_FILE.unlink(missing_ok=True)


# ---------------------------------------------------------------------------
# logs
# ---------------------------------------------------------------------------

@main.command()
@click.option("--follow", "-f", is_flag=True, help="Follow log output (like tail -f).")
@click.option("--lines", "-n", default=50, help="Number of lines to show.")
def logs(follow, lines):
    """View agent logs."""
    import subprocess
    from taskfloor_agent.config import LOG_FILE

    if not LOG_FILE.exists():
        click.echo(f"No log file found at {LOG_FILE}")
        return

    cmd = ["tail"]
    if follow:
        cmd.append("-f")
    cmd.extend(["-n", str(lines), str(LOG_FILE)])

    try:
        subprocess.run(cmd)
    except KeyboardInterrupt:
        pass


# ---------------------------------------------------------------------------
# status
# ---------------------------------------------------------------------------

@main.command()
def status():
    """Show agent configuration and current project discovery results."""
    config = load_config()
    server = get_server(config)
    agent_id = get_agent_id(config)
    scan_dirs = get_scan_dirs(config)
    project_paths = get_project_paths(config)
    token = get_token(config)

    # Check if running
    from taskfloor_agent.config import PID_FILE
    running = False
    pid = None
    if PID_FILE.exists():
        pid = int(PID_FILE.read_text().strip())
        running = _pid_alive(pid)

    click.echo(f"Status:       {'running (PID ' + str(pid) + ')' if running else 'stopped'}")
    click.echo(f"Server:       {server}")
    click.echo(f"Agent ID:     {agent_id}")
    click.echo(f"Scan dirs:    {[str(d) for d in scan_dirs] or '(none)'}")
    click.echo(f"Project paths:{[str(p) for p in project_paths] or '(none)'}")

    if not token:
        click.echo("Not logged in.")
        return

    headers = {"Authorization": f"Bearer {token}"}
    try:
        resp = _http.get(f"{server}/api/projects", headers=headers)
        resp.raise_for_status()
        projects = resp.json()
    except Exception as exc:
        click.echo(f"Warning: could not fetch projects: {exc}")
        projects = []

    matched = discover_projects(projects, scan_dirs, project_paths)

    click.echo("\nProject discovery:")
    for proj in projects:
        slug = proj.get("slug", "")
        if slug in matched:
            click.echo(f"  \u2713 {slug}  →  {matched[slug]}")
        else:
            click.echo(f"  \u2717 {slug}  (not found locally)")


# ---------------------------------------------------------------------------
# cleanup
# ---------------------------------------------------------------------------

def _collect_git_repos(scan_dirs, project_paths):
    """Yield Path objects for all known git repos."""
    from pathlib import Path

    seen = set()

    # Explicit project paths first
    for p in project_paths:
        if p.is_dir() and (p / ".git").exists():
            resolved = p.resolve()
            if resolved not in seen:
                seen.add(resolved)
                yield resolved

    # Scan dirs one level deep
    for d in scan_dirs:
        for entry, _repo_id in scan_directory(d):
            resolved = entry.resolve()
            if resolved not in seen:
                seen.add(resolved)
                yield resolved


@main.command()
@click.argument("task_id", required=False, type=int)
def cleanup(task_id):
    """Remove taskfloor worktrees (and branches) from local git repos.

    Optionally restrict to a single TASK_ID.
    """
    config = load_config()
    scan_dirs = get_scan_dirs(config)
    project_paths = get_project_paths(config)

    removed = 0
    for repo_path in _collect_git_repos(scan_dirs, project_paths):
        try:
            worktrees = list_worktrees(repo_path)
        except Exception as exc:
            logger.warning("Could not list worktrees for %s: %s", repo_path, exc)
            continue

        for wt in worktrees:
            branch = wt.get("branch", "")
            # branch refs look like "refs/heads/taskfloor/task-42"
            if "taskfloor/task-" not in branch:
                continue

            # Extract task id from branch name
            branch_short = branch.split("refs/heads/")[-1]  # taskfloor/task-42
            try:
                wt_task_id = int(branch_short.split("taskfloor/task-")[1].split("/")[0])
            except (IndexError, ValueError):
                continue

            if task_id is not None and wt_task_id != task_id:
                continue

            wt_path = wt.get("path", "")
            click.echo(f"Removing worktree: {wt_path}  (branch: {branch_short})")
            try:
                import subprocess
                subprocess.run(
                    ["git", "worktree", "remove", wt_path, "--force"],
                    cwd=repo_path,
                    capture_output=True,
                    timeout=30,
                    check=True,
                )
                subprocess.run(
                    ["git", "branch", "-D", branch_short],
                    cwd=repo_path,
                    capture_output=True,
                    timeout=15,
                )
                removed += 1
                click.echo(f"  Removed.")
            except Exception as exc:
                click.echo(f"  Failed: {exc}")

    if removed == 0:
        click.echo("No taskfloor worktrees found to clean up.")
    else:
        click.echo(f"\nCleaned up {removed} worktree(s).")


# ---------------------------------------------------------------------------
# add
# ---------------------------------------------------------------------------

@main.command()
@click.argument("path")
def add(path):
    """Add a local project directory to the agent's project_paths."""
    from pathlib import Path

    expanded = Path(path).expanduser().resolve()
    if not expanded.is_dir():
        click.echo(f"Error: '{expanded}' is not a directory.")
        sys.exit(1)

    config = load_config()
    project_paths = [str(p) for p in get_project_paths(config)]
    str_path = str(expanded)

    if str_path in project_paths:
        click.echo(f"'{expanded}' is already in project_paths.")
        return

    project_paths.append(str_path)
    config["project_paths"] = project_paths
    save_config(config)
    click.echo(f"Added '{expanded}' to project_paths.")


if __name__ == "__main__":
    main()
