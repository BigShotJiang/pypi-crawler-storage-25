"""Git worktree lifecycle — create, reuse, remove, list."""
import logging
import subprocess
from pathlib import Path

logger = logging.getLogger(__name__)
WORKTREE_DIR = ".worktrees"


def worktree_path(project_path: str | Path, task_id: int, task_title: str = "") -> Path:
    """Return the expected worktree path for a task."""
    return Path(project_path) / WORKTREE_DIR / f"task-{task_id}"


def worktree_branch(task_id: int) -> str:
    """Return the git branch name for a task."""
    return f"taskfloor/task-{task_id}"


def exists(project_path: str | Path, task_id: int, task_title: str) -> bool:
    """Return True if the worktree directory already exists."""
    return worktree_path(project_path, task_id, task_title).exists()


def create(
    project_path: str | Path,
    task_id: int,
    task_title: str,
    base_branch: str = "main",
) -> Path:
    """Create a git worktree for the task, or return the existing path.

    Returns the worktree Path.
    Raises RuntimeError if the worktree cannot be created.
    """
    project_path = Path(project_path)
    wt_path = worktree_path(project_path, task_id, task_title)
    branch = worktree_branch(task_id)

    if wt_path.exists():
        logger.info("Worktree already exists at %s", wt_path)
        return wt_path

    # Ensure the parent .worktrees directory exists
    wt_path.parent.mkdir(parents=True, exist_ok=True)

    # Ensure .worktrees is in the project's .gitignore
    _ensure_gitignore_entry(project_path, WORKTREE_DIR)

    # Fetch latest from origin
    try:
        subprocess.run(
            ["git", "fetch", "origin"],
            cwd=project_path,
            capture_output=True,
            timeout=30,
            check=True,
        )
    except subprocess.CalledProcessError as exc:
        logger.warning("git fetch origin failed (continuing): %s", exc.stderr)

    # Try to create the worktree from origin/<base_branch> (freshly fetched)
    origin_base = f"origin/{base_branch}"
    result = subprocess.run(
        ["git", "worktree", "add", str(wt_path), "-b", branch, origin_base],
        cwd=project_path,
        capture_output=True,
        timeout=30,
    )

    if result.returncode != 0:
        logger.warning(
            "git worktree add with -b failed (%s), retrying without -b",
            result.stderr.decode().strip(),
        )
        # Branch may already exist — try without -b
        result2 = subprocess.run(
            ["git", "worktree", "add", str(wt_path), branch],
            cwd=project_path,
            capture_output=True,
            timeout=30,
        )
        if result2.returncode != 0:
            raise RuntimeError(
                f"Failed to create worktree at {wt_path}: "
                f"{result2.stderr.decode().strip()}"
            )

    logger.info("Created worktree at %s (branch: %s)", wt_path, branch)

    # Copy gitignored config files (.env, etc.) from main repo to worktree
    _copy_gitignored_configs(project_path, wt_path)

    return wt_path


def _ensure_gitignore_entry(project_path: Path, entry: str) -> None:
    """Add an entry to .gitignore if it's not already present."""
    gitignore = project_path / ".gitignore"
    if gitignore.exists():
        content = gitignore.read_text()
        lines = content.splitlines()
        if entry in lines:
            return
        if not content.endswith("\n"):
            content += "\n"
        content += entry + "\n"
    else:
        content = entry + "\n"
    gitignore.write_text(content)
    logger.info("Added '%s' to %s", entry, gitignore)


def _copy_gitignored_configs(project_path: Path, wt_path: Path) -> None:
    """Copy gitignored files (like .env) from main repo to worktree.

    Parses .gitignore for file patterns, checks if they exist in the main repo,
    and copies them to the worktree so tests and builds work.
    """
    import shutil

    gitignore = project_path / ".gitignore"
    if not gitignore.exists():
        return

    # Common config file patterns to look for
    config_patterns = set()
    try:
        for line in gitignore.read_text().splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            # Only copy files, not directories with trailing /
            if line.endswith("/"):
                continue
            # Skip broad patterns like *.pyc, node_modules, etc.
            if line.startswith("*") and not line.startswith("*.env"):
                continue
            config_patterns.add(line)
    except Exception:
        return

    # Known config files worth copying
    known_configs = {".env", ".env.local", ".env.development", ".env.test", ".env.production"}

    # Merge: gitignore patterns that look like config files + known configs
    to_copy = set()
    for pattern in config_patterns:
        # Simple file names (no wildcards)
        if "*" not in pattern and "?" not in pattern:
            src = project_path / pattern
            if src.is_file():
                to_copy.add(pattern)

    for name in known_configs:
        src = project_path / name
        if src.is_file():
            to_copy.add(name)

    copied = []
    for rel_path in to_copy:
        src = project_path / rel_path
        dst = wt_path / rel_path
        try:
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(str(src), str(dst))
            copied.append(rel_path)
        except Exception as exc:
            logger.warning("Failed to copy %s to worktree: %s", rel_path, exc)

    if copied:
        logger.info("Copied config files to worktree: %s", ", ".join(copied))


def remove(
    project_path: str | Path,
    task_id: int,
    task_title: str,
    delete_branch: bool = True,
) -> None:
    """Remove a git worktree and optionally delete its branch."""
    project_path = Path(project_path)
    wt_path = worktree_path(project_path, task_id, task_title)
    branch = worktree_branch(task_id)

    subprocess.run(
        ["git", "worktree", "remove", str(wt_path), "--force"],
        cwd=project_path,
        capture_output=True,
        timeout=30,
        check=True,
    )
    logger.info("Removed worktree at %s", wt_path)

    if delete_branch:
        result = subprocess.run(
            ["git", "branch", "-D", branch],
            cwd=project_path,
            capture_output=True,
            timeout=15,
        )
        if result.returncode != 0:
            logger.warning(
                "Could not delete branch %s: %s",
                branch,
                result.stderr.decode().strip(),
            )
        else:
            logger.info("Deleted branch %s", branch)


def list_worktrees(project_path: str | Path) -> list[dict]:
    """Return a list of taskfloor worktrees in the project.

    Each entry is {"path": str, "branch": str}.
    """
    project_path = Path(project_path)
    result = subprocess.run(
        ["git", "worktree", "list", "--porcelain"],
        cwd=project_path,
        capture_output=True,
        timeout=15,
        check=True,
    )
    output = result.stdout.decode()

    worktrees = []
    current: dict = {}
    for line in output.splitlines():
        if line.startswith("worktree "):
            current = {"path": line[len("worktree "):], "branch": ""}
        elif line.startswith("branch "):
            current["branch"] = line[len("branch "):]
        elif line == "" and current:
            if WORKTREE_DIR in current.get("path", ""):
                worktrees.append(current)
            current = {}

    # Handle last block if no trailing newline
    if current and WORKTREE_DIR in current.get("path", ""):
        worktrees.append(current)

    return worktrees


def get_diff_stat(wt_path: str | Path) -> str:
    """Return the output of `git diff --stat HEAD` for the given worktree."""
    result = subprocess.run(
        ["git", "diff", "--stat", "HEAD"],
        cwd=wt_path,
        capture_output=True,
        timeout=15,
    )
    return result.stdout.decode()
