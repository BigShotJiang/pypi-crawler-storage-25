"""Config management for TaskFloor Agent using ~/.taskfloor/agent.yaml."""

import getpass
import os
import socket
from pathlib import Path
from typing import Any

import yaml

def _resolve_config_path() -> Path:
    """Resolve config path: env var > local .taskfloor/agent.yaml > ~/.taskfloor/agent.yaml."""
    env = os.environ.get("TASKFLOOR_CONFIG")
    if env:
        return Path(env)
    # Check current directory for local dev config
    local = Path.cwd() / ".taskfloor" / "agent.yaml"
    if local.exists():
        return local
    return Path.home() / ".taskfloor" / "agent.yaml"

_resolved = _resolve_config_path()
CONFIG_DIR = _resolved.parent
CONFIG_FILE = _resolved
PID_FILE = CONFIG_DIR / (CONFIG_FILE.stem + ".pid")
LOG_FILE = CONFIG_DIR / (CONFIG_FILE.stem + ".log")


def set_config_path(path: str) -> None:
    """Override config path at runtime (from --config CLI flag)."""
    global CONFIG_DIR, CONFIG_FILE, PID_FILE, LOG_FILE
    CONFIG_FILE = Path(path)
    CONFIG_DIR = CONFIG_FILE.parent
    PID_FILE = CONFIG_DIR / (CONFIG_FILE.stem + ".pid")
    LOG_FILE = CONFIG_DIR / (CONFIG_FILE.stem + ".log")


def default_agent_id() -> str:
    """Return a default agent ID in the form '{username}-{hostname}'."""
    username = getpass.getuser()
    hostname = socket.gethostname().split(".")[0]  # strip domain suffix
    return f"{username}-{hostname}"


def load_config() -> dict[str, Any]:
    """Load config from CONFIG_FILE, returning an empty dict if missing."""
    if not CONFIG_FILE.exists():
        return {}
    with CONFIG_FILE.open() as f:
        data = yaml.safe_load(f)
    return data or {}


def save_config(config: dict[str, Any]) -> None:
    """Persist config dict to CONFIG_FILE, creating directories as needed."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    with CONFIG_FILE.open("w") as f:
        yaml.dump(config, f, default_flow_style=False, allow_unicode=True)


def get_server(config: dict[str, Any]) -> str:
    """Return the server URL, defaulting to https://taskfloor.xyz."""
    return config.get("server", "https://taskfloor.xyz").rstrip("/")


def get_token(config: dict[str, Any]) -> str | None:
    """Return the JWT token, or None if not set."""
    return config.get("token")


def get_scan_dirs(config: dict[str, Any]) -> list[Path]:
    """Return scan_dirs as a list of expanded Paths."""
    raw = config.get("scan_dirs", [])
    return [Path(d).expanduser() for d in raw]


def get_project_paths(config: dict[str, Any]) -> list[Path]:
    """Return project_paths as a list of expanded Paths."""
    raw = config.get("project_paths", [])
    return [Path(p).expanduser() for p in raw]


def get_agent_id(config: dict[str, Any]) -> str:
    """Return agent_id from config, falling back to default_agent_id()."""
    return config.get("agent_id") or default_agent_id()
