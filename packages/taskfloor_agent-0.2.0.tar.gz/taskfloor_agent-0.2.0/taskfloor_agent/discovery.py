"""Auto-detect local projects by matching git remotes to TaskFloor projects."""

import re
import subprocess
from pathlib import Path


def get_git_remote_url(path: Path) -> str | None:
    """Return the 'origin' remote URL for the git repo at *path*, or None."""
    try:
        result = subprocess.run(
            ["git", "remote", "get-url", "origin"],
            cwd=path,
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0:
            return result.stdout.strip() or None
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        pass
    return None


def extract_repo_id(remote_url: str) -> str | None:
    """Extract 'org/repo' from an SSH or HTTPS git remote URL.

    Handles:
      git@github.com:org/repo.git
      https://github.com/org/repo.git
      https://github.com/org/repo
    """
    # SSH format: git@host:org/repo.git
    ssh_match = re.match(r"^git@[^:]+:([^/]+/[^/]+?)(?:\.git)?$", remote_url)
    if ssh_match:
        return ssh_match.group(1)

    # HTTPS format: https://host/org/repo.git
    https_match = re.match(r"^https?://[^/]+/([^/]+/[^/]+?)(?:\.git)?$", remote_url)
    if https_match:
        return https_match.group(1)

    return None


def scan_directory(directory: Path) -> list[tuple[Path, str]]:
    """Scan *directory* one level deep for git repos.

    Returns a list of (path, org/repo) tuples for every subdirectory that
    has a recognisable git remote URL.
    """
    results: list[tuple[Path, str]] = []
    if not directory.is_dir():
        return results

    for entry in sorted(directory.iterdir()):
        if not entry.is_dir():
            continue
        if not (entry / ".git").exists():
            continue
        remote_url = get_git_remote_url(entry)
        if not remote_url:
            continue
        repo_id = extract_repo_id(remote_url)
        if repo_id:
            results.append((entry, repo_id))

    return results


def scan_all_repos(
    scan_dirs: list[Path],
    linked_repos: set[str],
) -> list[dict]:
    """Return all local repos NOT in linked_repos."""
    repos = []
    for directory in scan_dirs:
        for repo_path, repo_id in scan_directory(directory):
            if repo_id not in linked_repos:
                remote_url = get_git_remote_url(repo_path) or ""
                repos.append({
                    "path": str(repo_path),
                    "remote_url": remote_url,
                    "name": repo_path.name,
                })
    return repos


def discover_projects(
    taskfloor_projects: list[dict],
    scan_dirs: list[Path],
    project_paths: list[Path],
) -> dict[str, Path]:
    """Match local git repos to TaskFloor projects.

    Args:
        taskfloor_projects: List of dicts with at least 'slug' and
            'github_repo' keys (e.g. {"slug": "my-app", "github_repo": "org/repo"}).
        scan_dirs: Directories to scan one level deep for git repos.
        project_paths: Explicit paths to check first (exact match by remote).

    Returns:
        Mapping of project_slug → local absolute Path.
    """
    # Build lookup: repo_id → slug
    repo_to_slug: dict[str, str] = {}
    for project in taskfloor_projects:
        github_repo = project.get("github_repo")
        slug = project.get("slug")
        if github_repo and slug:
            repo_to_slug[github_repo] = slug

    matched: dict[str, Path] = {}

    # 1. Check explicit project_paths first
    for path in project_paths:
        if not path.is_dir():
            continue
        remote_url = get_git_remote_url(path)
        if not remote_url:
            continue
        repo_id = extract_repo_id(remote_url)
        if repo_id and repo_id in repo_to_slug:
            slug = repo_to_slug[repo_id]
            if slug not in matched:
                matched[slug] = path.resolve()

    # 2. Scan directories one level deep
    for directory in scan_dirs:
        for repo_path, repo_id in scan_directory(directory):
            if repo_id in repo_to_slug:
                slug = repo_to_slug[repo_id]
                if slug not in matched:
                    matched[slug] = repo_path.resolve()

    return matched
