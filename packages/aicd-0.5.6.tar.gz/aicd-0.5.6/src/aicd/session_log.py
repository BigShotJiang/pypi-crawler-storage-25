"""每次进程启动在 AICD_HOME/logs 下创建一条会话日志（供调试与优化）。"""

from __future__ import annotations

import json
import os
import platform
import sys
import threading
from datetime import datetime
from pathlib import Path
from typing import Any, Mapping

# 工具结果中可能极大的字段（只记长度或省略）
_RESULT_BLOB_KEYS = frozenset(
    {
        "text",
        "content",
        "body",
        "stdout",
        "stderr",
        "data",
        "source",
        "body_html",
        "extra_scripts",
        "extra_head",
        "mermaid_body",
        "matches",
        "lines",
    }
)


def new_session_log_path(logs_dir: Path) -> Path:
    """文件名：年月日_时分秒.log"""
    logs_dir.mkdir(parents=True, exist_ok=True)
    name = datetime.now().strftime("%Y%m%d_%H%M%S.log")
    return logs_dir / name


def _short_json(obj: Any, max_len: int = 4000) -> str:
    try:
        s = json.dumps(obj, ensure_ascii=False, default=str)
    except TypeError:
        s = repr(obj)
    if len(s) > max_len:
        return s[: max_len - 3] + "..."
    return s


def _strip_large_values(
    d: Mapping[str, Any],
    *,
    blob_keys: frozenset[str],
    max_primitive: int = 2000,
) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for k, v in d.items():
        if k in blob_keys:
            if isinstance(v, str):
                out[k] = f"<str len={len(v)}>"
            elif isinstance(v, (bytes, bytearray)):
                out[k] = f"<bytes len={len(v)}>"
            elif isinstance(v, list):
                out[k] = f"<list len={len(v)}>"
            elif isinstance(v, dict):
                out[k] = f"<dict keys={len(v)}>"
            else:
                out[k] = f"<{type(v).__name__}>"
        elif isinstance(v, str) and len(v) > max_primitive:
            out[k] = v[:200] + f"...<len={len(v)}>"
        else:
            out[k] = v
    return out


def summarize_tool_call(name: str, args: dict[str, Any]) -> str:
    """入参摘要；文件写入/大文本只记路径与长度。"""
    if name == "fs_write_file":
        c = args.get("content", "")
        le = len(c) if isinstance(c, str) else 0
        return _short_json({"path": args.get("path"), "content_chars": le})
    if name == "fs_read_file":
        return _short_json(
            {
                "path": args.get("path"),
                "byte_offset": args.get("byte_offset"),
                "max_bytes": args.get("max_bytes"),
                "align_utf8": args.get("align_utf8"),
            }
        )
    if name == "text_regex_replace":
        return _short_json(
            {
                "path": args.get("path"),
                "pattern": args.get("pattern"),
                "replacement_len": len(str(args.get("replacement", ""))),
            }
        )
    if name == "text_patch_bytes_hex":
        hx = str(args.get("hex_data", ""))
        return _short_json(
            {
                "path": args.get("path"),
                "offset": args.get("offset"),
                "hex_chars": len(hx),
            }
        )
    if name == "http_request":
        return _short_json(
            _strip_large_values(
                dict(args),
                blob_keys=frozenset({"json_body", "data", "headers"}),
                max_primitive=1500,
            )
        )
    if name == "web_fetch":
        return _short_json(
            {
                "url": args.get("url"),
                "extract": args.get("extract"),
                "timeout_sec": args.get("timeout_sec"),
            }
        )
    if name == "github_api":
        return _short_json(
            {
                "method": args.get("method"),
                "path": args.get("path"),
                "query_keys": list(args.get("query", {}).keys())
                if isinstance(args.get("query"), dict)
                else None,
            }
        )
    if name == "github_repo_read":
        return _short_json(
            {
                "owner": args.get("owner"),
                "repo": args.get("repo"),
                "path": args.get("path"),
                "ref": args.get("ref"),
                "max_text_chars": args.get("max_text_chars"),
            }
        )
    if name in (
        "site_bookmarks_list",
        "site_bookmarks_get",
        "site_bookmarks_add",
        "site_bookmarks_update",
        "site_bookmarks_remove",
    ):
        return _short_json(
            {
                "tool": name,
                "url": args.get("url"),
                "entry_id": args.get("entry_id"),
                "tag": args.get("tag"),
                "query": args.get("query"),
                "strict_site_root": args.get("strict_site_root"),
            }
        )
    if name in ("script_run",):
        src = args.get("source", "")
        sl = len(src) if isinstance(src, str) else 0
        return _short_json(
            {
                "kind": args.get("kind"),
                "source_chars": sl,
                "related_doc": args.get("related_doc"),
            }
        )
    if name == "run_command":
        av = args.get("argv")
        return _short_json(
            {
                "command_chars": len(str(args.get("command") or "")),
                "argv_len": len(av) if isinstance(av, list) else None,
                "shell": args.get("shell"),
                "cwd": args.get("cwd"),
            }
        )
    if name == "interactive_process":
        t = str(args.get("text", ""))
        av = args.get("argv")
        return _short_json(
            {
                "operation": args.get("operation"),
                "session_id": args.get("session_id"),
                "session_label": args.get("session_label"),
                "session_index": args.get("session_index"),
                "command_chars": len(str(args.get("command") or "")),
                "argv_len": len(av) if isinstance(av, list) else None,
                "text_chars": len(t),
                "cwd": args.get("cwd"),
            }
        )
    if name == "data_text":
        t = str(args.get("text", ""))
        return _short_json(
            {
                "operation": args.get("operation"),
                "text_chars": len(t),
                "pattern": args.get("pattern"),
            }
        )
    if name == "data_crypto":
        return _short_json(
            {
                "operation": args.get("operation"),
                "text_chars": len(str(args.get("text", ""))),
                "hex_chars": len(str(args.get("hex", ""))),
                "has_public_pem": bool(args.get("public_pem")),
                "has_private_pem": bool(args.get("private_pem")),
            }
        )
    if name == "data_format":
        return _short_json(
            {
                "operation": args.get("operation"),
                "text_chars": len(str(args.get("text", ""))),
                "html_chars": len(str(args.get("html", ""))),
                "xml_chars": len(str(args.get("xml", ""))),
                "path": args.get("path"),
            }
        )
    if name == "workspace_metrics":
        pl = args.get("paths")
        return _short_json(
            {
                "operation": args.get("operation"),
                "root": args.get("root"),
                "paths_n": len(pl) if isinstance(pl, list) else None,
                "glob": args.get("glob"),
                "include_html": args.get("include_html", False),
            }
        )
    if name == "viz_spec_validate":
        return _short_json(
            {
                "operation": args.get("operation"),
                "nodes_n": len(args["nodes"])
                if isinstance(args.get("nodes"), list)
                else None,
                "edges_n": len(args["edges"])
                if isinstance(args.get("edges"), list)
                else None,
                "html_chars": len(str(args.get("html", ""))),
                "mermaid_chars": len(str(args.get("mermaid_body", ""))),
            }
        )
    if name == "script_syntax_check":
        return _short_json(
            {
                "kind": args.get("kind") or args.get("language"),
                "path": args.get("path"),
                "source_chars": len(str(args.get("source", ""))),
            }
        )
    if name == "chat_history_get":
        return _short_json({"message_id": args.get("message_id")})
    if name in ("chat_history_list", "chat_summaries_list"):
        return _short_json({"limit": args.get("limit")})
    if name == "chat_history_search":
        return _short_json(
            {
                "query_chars": len(str(args.get("query") or "")),
                "use_regex": args.get("use_regex") or args.get("regex"),
                "limit": args.get("limit"),
                "scan_limit": args.get("scan_limit"),
            }
        )
    if name == "chat_save_summary":
        c = str(args.get("content", ""))
        return _short_json(
            {
                "content_chars": len(c),
                "covers_up_to_message_id": args.get("covers_up_to_message_id"),
            }
        )
    if name == "chat_new_session":
        return _short_json({})
    if name in (
        "task_list",
        "task_result",
        "task_shell",
        "task_ai",
        "task_cancel",
        "task_progress",
        "task_thread_stats",
    ):
        keys = (
            "limit",
            "task_id",
            "command",
            "instruction",
            "step_index",
            "thread_root_id",
            "display_title",
        )
        return _short_json(
            {
                k: args.get(k)
                for k in keys
                if k in args and args.get(k) is not None
            }
        )
    if name == "agent_settings_update":
        p = args.get("patch")
        keys = list(p.keys()) if isinstance(p, dict) else None
        return _short_json(
            {"persist": args.get("persist", True), "patch_top_keys": keys}
        )
    if name in (
        "llm_profiles_list",
        "llm_profile_activate",
        "llm_profile_add",
        "llm_profile_update",
        "llm_profile_delete",
        "llm_profile_duplicate",
    ):
        return _short_json(
            {
                "tool": name,
                "name_or_index": args.get("name_or_index") or args.get("target"),
                "source": args.get("source"),
                "new_name": args.get("new_name"),
                "persist": args.get("persist", True),
                "activate": args.get("activate"),
                "patch_keys": list(args["patch"].keys())
                if isinstance(args.get("patch"), dict)
                else None,
            }
        )
    if name == "runtime_env_refresh":
        return _short_json({})
    if name == "agent_environment_digest":
        return _short_json(
            {
                "refresh_first": args.get("refresh_first", False),
                "include_capabilities_text": args.get(
                    "include_capabilities_text", False
                ),
                "capabilities_max_chars": args.get("capabilities_max_chars", 6000),
            }
        )
    if name == "aicd_session_logs":
        return _short_json(
            {
                "op": args.get("op"),
                "limit": args.get("limit", 30),
                "this_process": args.get("this_process", False),
                "filename": args.get("filename"),
                "latest": args.get("latest", False),
                "line_contains_set": bool(
                    str(args.get("line_contains") or "").strip()
                ),
                "line_regex_set": bool(str(args.get("line_regex") or "").strip()),
                "max_lines": args.get("max_lines", 200),
                "max_bytes": args.get("max_bytes", 120_000),
            }
        )
    if name == "doc_extract":
        return _short_json(
            {
                "source_path": args.get("source_path"),
                "output_dir": args.get("output_dir"),
                "output_format": args.get("output_format", "markdown"),
                "page_start": args.get("page_start"),
                "page_end": args.get("page_end"),
                "use_ocr": args.get("use_ocr", False),
                "docx_engine": args.get("docx_engine"),
                "markdown_engine": args.get("markdown_engine"),
                "markitdown_use_llm": args.get("markitdown_use_llm", False),
            }
        )
    if name == "doc_normalize":
        return _short_json(
            {
                "source_path": args.get("source_path"),
                "output_dir": args.get("output_dir"),
                "use_cache": args.get("use_cache", True),
                "force_refresh": args.get("force_refresh", False),
                "save_outline": args.get("save_outline", False),
                "docx_engine": args.get("docx_engine"),
                "markdown_engine": args.get("markdown_engine"),
                "markitdown_use_llm": args.get("markitdown_use_llm", False),
            }
        )
    if name == "markdown_section_slice":
        return _short_json(
            {
                "path": args.get("path"),
                "outline_path": args.get("outline_path"),
                "heading_index": args.get("heading_index"),
                "start_byte": args.get("start_byte"),
                "end_byte": args.get("end_byte"),
                "max_read_bytes": args.get("max_read_bytes"),
            }
        )
    if name == "markdown_regex_scan":
        return _short_json(
            {
                "path": args.get("path"),
                "pattern_set": bool(str(args.get("pattern") or "").strip()),
                "max_matches": args.get("max_matches", 100),
            }
        )
    if name == "markdown_chunk_split":
        return _short_json(
            {
                "path": args.get("path"),
                "output_dir": args.get("output_dir"),
                "split_max_level": args.get("split_max_level", 3),
                "max_chunk_bytes": args.get("max_chunk_bytes"),
            }
        )
    if name == "document_outline":
        return _short_json(
            {
                "path": args.get("path"),
                "max_heading_level": args.get("max_heading_level", 6),
                "save_to_tmp": args.get("save_to_tmp", True),
            }
        )
    if name == "library_doc_project_init":
        return _short_json(
            {
                "doc_slug": args.get("doc_slug"),
                "title": args.get("title"),
                "overwrite_manifest": args.get("overwrite_manifest", False),
            }
        )
    if name == "library_doc_project_get":
        return _short_json({"doc_slug": args.get("doc_slug")})
    if name == "library_doc_project_patch":
        up = args.get("updates")
        return _short_json(
            {
                "doc_slug": args.get("doc_slug"),
                "replace_resources": args.get("replace_resources", False),
                "updates_keys": sorted(up.keys()) if isinstance(up, dict) else None,
            }
        )
    if name == "library_doc_snapshot":
        return _short_json(
            {
                "doc_slug": args.get("doc_slug"),
                "subpath": args.get("subpath"),
            }
        )
    if name == "doc_manifest_validate":
        return _short_json(
            {
                "doc_slug": args.get("doc_slug"),
                "check_paths_exist": args.get("check_paths_exist", True),
            }
        )
    if name == "doc_manifest_coverage_report":
        return _short_json(
            {
                "doc_slug": args.get("doc_slug"),
                "scan_markdown_dir": args.get("scan_markdown_dir", True),
            }
        )
    if name == "library_resources_scan":
        return _short_json(
            {
                "doc_slug": args.get("doc_slug"),
                "include_snapshots": args.get("include_snapshots", False),
            }
        )
    if name == "doc_text_health_check":
        ps = args.get("paths")
        return _short_json({"paths_n": len(ps) if isinstance(ps, list) else None})
    if name == "doc_project_export":
        fm = args.get("formats")
        return _short_json(
            {
                "doc_slug": args.get("doc_slug"),
                "topic_slug": args.get("topic_slug"),
                "source_markdown_rel": args.get("source_markdown_rel"),
                "formats_n": len(fm) if isinstance(fm, list) else None,
            }
        )
    if name == "doc_revision_diff_summary":
        return _short_json(
            {
                "path_before": args.get("path_before"),
                "path_after": args.get("path_after"),
            }
        )
    if name == "library_doc_batch_quality_pass":
        return _short_json(
            {
                "doc_slug": args.get("doc_slug"),
                "check_paths_exist": args.get("check_paths_exist", True),
                "run_text_health": args.get("run_text_health", True),
                "scan_resources": args.get("scan_resources", True),
            }
        )
    if name == "library_doc_node_resolve":
        return _short_json(
            {
                "doc_slug": args.get("doc_slug"),
                "node_id": args.get("node_id"),
            }
        )
    if name == "vision_analyze_image":
        ips = args.get("image_paths")
        return _short_json(
            {
                "prompt_chars": len(str(args.get("prompt") or "")),
                "image_path": args.get("image_path"),
                "image_paths_n": len(ips) if isinstance(ips, list) else 0,
                "save_report": args.get("save_report", True),
                "report_name": args.get("report_name"),
            }
        )
    if name == "diagram_mermaid_png":
        return _short_json(
            {
                "output_png_path": args.get("output_png_path"),
                "mermaid_chars": len(str(args.get("mermaid_body") or "")),
                "theme": args.get("theme", "neutral"),
                "scale": args.get("scale", 2),
            }
        )
    if name == "docx_compose":
        bl = args.get("blocks")
        return _short_json(
            {
                "path": args.get("path"),
                "append": args.get("append", False),
                "blocks_n": len(bl) if isinstance(bl, list) else None,
                "default_east_asia_font": args.get("default_east_asia_font"),
                "default_color_hex": args.get("default_color_hex"),
                "style_profile_path": args.get("style_profile_path"),
            }
        )
    if name == "style_reference_scan":
        return _short_json(
            {
                "path": args.get("path"),
                "max_files": args.get("max_files", 48),
            }
        )
    if name == "xlsx_write_workbook":
        sh = args.get("sheets")
        return _short_json(
            {
                "path": args.get("path"),
                "append": args.get("append", False),
                "sheets_n": len(sh) if isinstance(sh, list) else None,
            }
        )
    if name == "xlsx_write_xlsxwriter":
        sh = args.get("sheets")
        return _short_json(
            {
                "path": args.get("path"),
                "engine": "xlsxwriter",
                "sheets_n": len(sh) if isinstance(sh, list) else None,
            }
        )
    if name == "xlsx_read_workbook":
        sn = args.get("sheet_names")
        return _short_json(
            {
                "path": args.get("path"),
                "value_mode": args.get("value_mode", "cached"),
                "sheet_names_n": len(sn) if isinstance(sn, list) else None,
                "max_rows_per_sheet": args.get("max_rows_per_sheet"),
            }
        )
    if name == "xlsx_patch_workbook":
        ce = args.get("cells")
        return _short_json(
            {
                "path": args.get("path"),
                "create_sheets": args.get("create_sheets", False),
                "cells_n": len(ce) if isinstance(ce, list) else None,
            }
        )
    if name == "pptx_inspect_template":
        return _short_json({"path": args.get("path")})
    if name == "pptx_compose":
        sl = args.get("slides")
        return _short_json(
            {
                "path": args.get("path"),
                "template_path": args.get("template_path"),
                "slides_n": len(sl) if isinstance(sl, list) else None,
            }
        )
    if name == "pptx_from_html_deck":
        sl = args.get("slides")
        return _short_json(
            {
                "path": args.get("path"),
                "deck_root": args.get("deck_root"),
                "slides_n": len(sl) if isinstance(sl, list) else None,
                "viewport_w": args.get("viewport_width"),
                "viewport_h": args.get("viewport_height"),
            }
        )
    if name == "docx_export_pdf":
        return _short_json(
            {
                "docx_path": args.get("docx_path"),
                "output_pdf_path": args.get("output_pdf_path"),
                "prefer": args.get("prefer"),
            }
        )
    if name == "markdown_to_pdf":
        mt = args.get("markdown_text")
        return _short_json(
            {
                "output_pdf_path": args.get("output_pdf_path"),
                "markdown_path": args.get("markdown_path"),
                "markdown_text_chars": len(mt) if isinstance(mt, str) else None,
                "engine": args.get("engine"),
                "paper": args.get("paper"),
            }
        )
    if name == "pdf_compose":
        bl = args.get("blocks")
        return _short_json(
            {
                "path": args.get("path"),
                "title": args.get("title"),
                "blocks_n": len(bl) if isinstance(bl, list) else None,
                "page_size": args.get("page_size"),
                "cjk_font_path": bool(args.get("cjk_font_path")),
            }
        )
    if name == "diagram_drawio_write":
        ns = args.get("nodes")
        es = args.get("edges")
        return _short_json(
            {
                "path": args.get("path"),
                "nodes_n": len(ns) if isinstance(ns, list) else None,
                "edges_n": len(es) if isinstance(es, list) else None,
                "page_name": args.get("page_name"),
            }
        )
    if name == "diagram_drawio_export_png":
        return _short_json(
            {
                "drawio_path": args.get("drawio_path"),
                "output_png_path": args.get("output_png_path"),
                "scale": args.get("scale", 2),
                "transparent": args.get("transparent", False),
                "timeout_ms": args.get("timeout_ms", 120_000),
            }
        )
    if name == "image_crop":
        return _short_json(
            {
                "input_path": args.get("input_path"),
                "output_path": args.get("output_path"),
                "left": args.get("left"),
                "top": args.get("top"),
                "width": args.get("width"),
                "height": args.get("height"),
            }
        )
    if name == "image_transform":
        pr = args.get("params")
        return _short_json(
            {
                "operation": args.get("operation"),
                "input_path": args.get("input_path"),
                "output_path": args.get("output_path"),
                "params_keys": list(pr.keys()) if isinstance(pr, dict) else None,
            }
        )
    if name == "diagram_drawio_summarize":
        return _short_json(
            {
                "path": args.get("path"),
                "max_vertices": args.get("max_vertices"),
                "max_edges": args.get("max_edges"),
            }
        )
    if name == "visio_flowchart_write":
        ns = args.get("nodes")
        es = args.get("edges")
        return _short_json(
            {
                "path": args.get("path"),
                "nodes_n": len(ns) if isinstance(ns, list) else None,
                "edges_n": len(es) if isinstance(es, list) else None,
                "layout_cols": args.get("layout_cols"),
            }
        )
    if name == "visio_vsdx_summarize":
        return _short_json(
            {
                "path": args.get("path"),
                "max_shapes": args.get("max_shapes"),
            }
        )
    if name in ("db_inspect", "db_query"):
        conn = dict(args.get("connection") or {})
        if "password" in conn:
            conn = {**conn, "password": "<redacted>"}
        payload: dict[str, Any] = {
            "operation": args.get("operation"),
            "connection": conn,
        }
        if name == "db_query":
            payload["read_only"] = args.get("read_only", True)
            payload["sql_chars"] = len(str(args.get("sql") or ""))
        return _short_json(payload)
    if name == "viz_html_to_png":
        return _short_json(
            {
                "html_path": args.get("html_path"),
                "output_png_path": args.get("output_png_path"),
                "selector": args.get("selector"),
                "full_page": args.get("full_page", True),
                "wait_after_load_ms": args.get("wait_after_load_ms", 1200),
            }
        )
    if name == "browser_cdp_automation":
        st = args.get("steps")
        return _short_json(
            {
                "steps_n": len(st) if isinstance(st, list) else None,
                "headless": args.get("headless", True),
                "timeout_ms": args.get("timeout_ms", 60_000),
                "viewport": bool(args.get("viewport")),
            }
        )
    if name == "desktop_gui_automation":
        st = args.get("steps")
        return _short_json(
            {"steps_n": len(st) if isinstance(st, list) else None},
        )
    if name == "desktop_open_url":
        return _short_json({"url": args.get("url")})
    if name == "desktop_reveal_path":
        return _short_json({"path": args.get("path")})
    if name == "viz_export_html":
        bh = args.get("body_html")
        bl = len(bh) if isinstance(bh, str) else 0
        return _short_json(
            {
                "html_path": args.get("html_path"),
                "title": args.get("title"),
                "body_html_chars": bl,
            }
        )
    if name == "static_html_bundle":
        pages = args.get("pages")
        slides = args.get("slides")
        secs = args.get("sections")
        return _short_json(
            {
                "output_dir": args.get("output_dir"),
                "mode": args.get("mode"),
                "site_title": args.get("site_title") or args.get("title"),
                "pages_n": len(pages) if isinstance(pages, list) else None,
                "slides_n": len(slides) if isinstance(slides, list) else None,
                "sections_n": len(secs) if isinstance(secs, list) else None,
                "copy_chart_resources": args.get("copy_chart_resources", True),
                "inject_data_fetch_demo": args.get("inject_data_fetch_demo", True),
                "site_tree_folder_links": args.get("site_tree_folder_links", True),
                "site_tree_collapsible": args.get("site_tree_collapsible", True),
                "subpage_navigation": args.get("subpage_navigation", True),
            }
        )
    if name == "html_bundle_smoke":
        return _short_json(
            {
                "entry_html": args.get("entry_html"),
                "site_root": args.get("site_root"),
                "base_url": args.get("base_url"),
                "capture_deck_slides": args.get("capture_deck_slides", True),
            }
        )
    stripped = _strip_large_values(dict(args), blob_keys=_RESULT_BLOB_KEYS | {"content"})
    return _short_json(stripped)


def summarize_tool_result(name: str, result: dict[str, Any]) -> str:
    """出参摘要；读文件/海量字段不记正文。"""
    if name == "fs_read_file":
        return _short_json(
            {
                "ok": result.get("ok"),
                "path": result.get("path"),
                "size": result.get("size"),
                "truncated": result.get("truncated"),
                "byte_offset": result.get("byte_offset"),
                "bytes_read": result.get("bytes_read"),
                "text_chars": len(result["text"])
                if isinstance(result.get("text"), str)
                else None,
                "error": result.get("error"),
            }
        )
    if name == "fs_write_file":
        return _short_json(
            {
                "ok": result.get("ok"),
                "path": result.get("path"),
                "bytes": result.get("bytes"),
                "error": result.get("error"),
            }
        )
    if name == "http_request":
        d = dict(result)
        b = d.get("body")
        if isinstance(b, str):
            d["body"] = f"<str len={len(b)}>"
        return _short_json(d, max_len=6000)
    if name == "web_fetch":
        d = dict(result)
        t = d.get("text")
        if isinstance(t, str):
            d["text"] = f"<str len={len(t)}>"
        return _short_json(d, max_len=4000)
    if name == "github_api":
        d = dict(result)
        t = d.get("text")
        if isinstance(t, str):
            d["text"] = f"<str len={len(t)}>"
        return _short_json(d, max_len=4000)
    if name == "github_repo_read":
        d = dict(result)
        t = d.get("text")
        if isinstance(t, str):
            d["text"] = f"<str len={len(t)}>"
        if isinstance(d.get("entries"), list):
            d["entries"] = f"<{len(d['entries'])} items>"
        return _short_json(d, max_len=4000)
    if name == "site_bookmarks_list":
        return _short_json(
            {
                "ok": result.get("ok"),
                "count": result.get("count"),
                "path": result.get("path"),
            }
        )
    if name in ("site_bookmarks_get", "site_bookmarks_add", "site_bookmarks_update"):
        d = dict(result)
        ent = d.get("entry")
        if isinstance(ent, dict):
            d["entry"] = {
                "id": ent.get("id"),
                "canonical_url": ent.get("canonical_url"),
                "display_name": ent.get("display_name"),
                "summary_chars": len(str(ent.get("content_summary") or "")),
            }
        return _short_json(d, max_len=2000)
    if name == "site_bookmarks_remove":
        return _short_json(
            {
                "ok": result.get("ok"),
                "removed": result.get("removed"),
                "path": result.get("path"),
                "error": result.get("error"),
            }
        )
    if name == "run_command":
        return _short_json(
            _strip_large_values(dict(result), blob_keys=frozenset({"stdout", "stderr"})),
            max_len=4000,
        )
    if name == "interactive_process":
        return _short_json(
            _strip_large_values(
                dict(result),
                blob_keys=frozenset({"stdout", "stderr", "hint", "sessions"}),
            ),
            max_len=4000,
        )
    if name == "script_run":
        return _short_json(
            _strip_large_values(dict(result), blob_keys=frozenset({"stdout", "stderr"})),
            max_len=4000,
        )
    if name in ("fs_list_dir", "fs_glob", "fs_search_regex"):
        return _short_json(
            {
                "ok": result.get("ok"),
                "path": result.get("path"),
                "error": result.get("error"),
                "entry_count": len(result.get("entries", []))
                if isinstance(result.get("entries"), list)
                else None,
                "match_count": len(result.get("matches", []))
                if isinstance(result.get("matches"), list)
                else None,
            }
        )
    if name in ("db_query", "db_inspect"):
        if not isinstance(result, dict):
            return _short_json(result)
        d = dict(result)
        rows = d.get("rows")
        if isinstance(rows, list):
            d["rows"] = f"<{len(rows)} rows>"
        return _short_json(d, max_len=8000)
    if name == "chat_history_get":
        if not isinstance(result, dict) or not result.get("ok"):
            return _short_json(result)
        m = result.get("message")
        if isinstance(m, dict):
            c = m.get("content")
            cl = len(c) if isinstance(c, str) else None
            tcn = len(m.get("tool_calls") or []) if isinstance(m.get("tool_calls"), list) else None
            return _short_json(
                {
                    "ok": True,
                    "id": m.get("id"),
                    "role": m.get("role"),
                    "content_chars": cl,
                    "tool_calls_n": tcn,
                    "tool_name": m.get("tool_name"),
                }
            )
        return _short_json({"ok": result.get("ok")})
    if name in (
        "chat_history_list",
        "chat_history_search",
        "chat_summaries_list",
        "chat_session_info",
    ):
        if isinstance(result, dict) and result.get("ok"):
            d = dict(result)
            if "messages" in d:
                d["messages"] = f"<{len(d['messages'])} items>"
            if "summaries" in d:
                d["summaries"] = f"<{len(d['summaries'])} items>"
            return _short_json(d, max_len=3000)
        return _short_json(result)
    if name == "chat_new_session":
        return _short_json(
            {
                "ok": result.get("ok"),
                "session_id": result.get("session_id"),
                "in_memory_context_cleared": result.get("in_memory_context_cleared"),
                "error": result.get("error"),
            }
        )
    if name == "task_list":
        if not isinstance(result, dict):
            return _short_json(result)
        tasks = result.get("tasks")
        n_run = (
            sum(
                1
                for t in tasks
                if isinstance(t, dict) and t.get("running_now")
            )
            if isinstance(tasks, list)
            else None
        )
        return _short_json(
            {
                "ok": result.get("ok"),
                "task_count": len(tasks) if isinstance(tasks, list) else None,
                "running_now_count": n_run,
                "error": result.get("error"),
            }
        )
    if name == "task_result":
        if not isinstance(result, dict) or not result.get("ok"):
            return _short_json(result)
        t = result.get("task")
        if not isinstance(t, dict):
            return _short_json(result)
        return _short_json(
            {
                "ok": True,
                "id": t.get("id"),
                "type": t.get("type"),
                "status": t.get("status"),
                "running_now": t.get("running_now"),
                "parent_id": t.get("parent_id"),
                "error": (str(t.get("error") or "")[:300] or None),
            }
        )
    if name == "data_crypto":
        if not isinstance(result, dict):
            return _short_json(result)
        if not result.get("ok"):
            return _short_json(result)
        out: dict[str, Any] = {"ok": True}
        for k in (
            "algorithm",
            "curve",
            "bits",
            "valid",
            "bytes",
            "count",
            "truncated",
            "note",
            "duplicate_keys_overwritten",
            "iterations",
        ):
            if k in result:
                out[k] = result[k]
        if isinstance(result.get("hex"), str):
            out["hex_len"] = len(result["hex"])
        if isinstance(result.get("text"), str):
            out["text_len"] = len(result["text"])
        if result.get("base64") is not None:
            out["base64_len"] = len(str(result["base64"]))
        if isinstance(result.get("entries"), list):
            out["entries_n"] = len(result["entries"])
        if result.get("private_pem") or result.get("public_pem"):
            out["returned_pem_keys"] = True
        if isinstance(result.get("ciphertext_hex"), str):
            out["ciphertext_hex_len"] = len(result["ciphertext_hex"])
        if isinstance(result.get("signature_hex"), str):
            out["signature_hex_len"] = len(result["signature_hex"])
        return _short_json(out, max_len=1500)
    if name == "viz_spec_validate":
        if not isinstance(result, dict):
            return _short_json(result)
        iss = result.get("issues")
        return _short_json(
            {
                "ok": result.get("ok"),
                "issues_n": len(iss) if isinstance(iss, list) else None,
                "node_count": result.get("node_count"),
                "edge_count": result.get("edge_count"),
                "has_normalized": "normalized" in result,
                "error": result.get("error"),
            },
            max_len=2000,
        )
    if name == "viz_html_to_png":
        if not isinstance(result, dict):
            return _short_json(result)
        return _short_json(
            {
                "ok": result.get("ok"),
                "png_path": result.get("png_path"),
                "html_path": result.get("html_path"),
                "source_retained": result.get("source_retained"),
                "error": result.get("error"),
                "hint": result.get("hint"),
            }
        )
    if name == "static_html_bundle":
        if not isinstance(result, dict):
            return _short_json(result)
        wf = result.get("written_files")
        return _short_json(
            {
                "ok": result.get("ok"),
                "main_html": result.get("main_html"),
                "output_dir": result.get("output_dir"),
                "written_files_n": len(wf) if isinstance(wf, list) else None,
                "error": result.get("error"),
            }
        )
    if name == "html_bundle_smoke":
        if not isinstance(result, dict):
            return _short_json(result)
        sp = result.get("screenshot_paths")
        iss = result.get("issues")
        return _short_json(
            {
                "ok": result.get("ok"),
                "url": result.get("url"),
                "screenshots_n": len(sp) if isinstance(sp, list) else None,
                "issues_n": len(iss) if isinstance(iss, list) else None,
                "error": result.get("error"),
                "report_json_path": result.get("report_json_path"),
            }
        )
    if name == "browser_cdp_automation":
        if not isinstance(result, dict):
            return _short_json(result)
        sr = result.get("step_results")
        return _short_json(
            {
                "ok": result.get("ok"),
                "failed_step_index": result.get("failed_step_index"),
                "steps_done_n": len(sr) if isinstance(sr, list) else None,
                "last_url": result.get("last_url"),
                "error": result.get("error"),
                "hint": result.get("hint"),
            }
        )
    if name == "desktop_gui_automation":
        if not isinstance(result, dict):
            return _short_json(result)
        sr = result.get("step_results")
        return _short_json(
            {
                "ok": result.get("ok"),
                "platform": result.get("platform"),
                "failed_step_index": result.get("failed_step_index"),
                "steps_done_n": len(sr) if isinstance(sr, list) else None,
                "error": result.get("error"),
            }
        )
    if name in ("desktop_open_url", "desktop_reveal_path"):
        if not isinstance(result, dict):
            return _short_json(result)
        return _short_json(
            {
                "ok": result.get("ok"),
                "opened": result.get("opened"),
                "revealed": result.get("revealed"),
                "method": result.get("method"),
                "error": result.get("error"),
            }
        )
    if name == "script_syntax_check":
        if not isinstance(result, dict):
            return _short_json(result)
        return _short_json(
            {
                "ok": result.get("ok"),
                "language": result.get("language"),
                "heuristic_only": result.get("heuristic_only"),
                "lineno": result.get("lineno"),
                "error": (str(result.get("error") or "")[:400] or None),
            }
        )
    if name == "data_format":
        if not isinstance(result, dict):
            return _short_json(result)
        if not result.get("ok"):
            return _short_json(result)
        d: dict[str, Any] = {"ok": True}
        if "value" in result:
            d["has_value"] = True
        if isinstance(result.get("text"), str):
            d["text_len"] = len(result["text"])
        if isinstance(result.get("matches"), list):
            d["matches_n"] = len(result["matches"])
        if isinstance(result.get("nodes"), list):
            d["nodes_n"] = len(result["nodes"])
        if isinstance(result.get("dict"), dict):
            d["dict_keys_n"] = len(result["dict"])
        if isinstance(result.get("columns"), list):
            d["columns_n"] = len(result["columns"])
        if "count" in result:
            d["count"] = result["count"]
        return _short_json(d, max_len=1500)
    if name == "workspace_metrics":
        if not isinstance(result, dict):
            return _short_json(result)
        return _short_json(
            {
                "ok": result.get("ok"),
                "mode": result.get("mode"),
                "total_files": result.get("total_files"),
                "total_lines": result.get("total_lines"),
                "total_non_blank_lines": result.get("total_non_blank_lines"),
                "total_chars": result.get("total_chars"),
                "total_chars_no_whitespace": result.get("total_chars_no_whitespace"),
                "total_words_whitespace_units": result.get(
                    "total_words_whitespace_units"
                ),
                "truncated_file_list": result.get("truncated_file_list"),
                "by_extension_keys_n": len(result["by_extension"])
                if isinstance(result.get("by_extension"), dict)
                else None,
                "error": result.get("error"),
            }
        )
    if name == "chat_save_summary":
        return _short_json(
            {
                "ok": result.get("ok"),
                "summary_id": result.get("summary_id"),
                "error": result.get("error"),
            }
        )
    if name == "agent_settings_update":
        summ = result.get("summary")
        slen = len(summ) if isinstance(summ, str) else None
        return _short_json(
            {
                "ok": result.get("ok"),
                "persisted": result.get("persisted"),
                "message": result.get("message"),
                "error": result.get("error"),
                "summary_chars": slen,
            }
        )
    if name == "llm_profiles_list":
        lst = result.get("listing")
        return _short_json(
            {
                "ok": result.get("ok"),
                "active": result.get("activeLlmProfile"),
                "profiles_n": len(result["profiles"])
                if isinstance(result.get("profiles"), list)
                else None,
                "listing_chars": len(lst) if isinstance(lst, str) else None,
            }
        )
    if name in (
        "llm_profile_activate",
        "llm_profile_add",
        "llm_profile_update",
        "llm_profile_delete",
        "llm_profile_duplicate",
    ):
        prof = result.get("profile")
        pk = list(prof.keys()) if isinstance(prof, dict) else None
        return _short_json(
            {
                "ok": result.get("ok"),
                "message": result.get("message"),
                "error": result.get("error"),
                "profile_keys": pk,
            }
        )
    if name == "runtime_env_refresh":
        return _short_json(
            {
                "ok": result.get("ok"),
                "path": result.get("path"),
                "generated_at": result.get("generated_at"),
                "commands_available": result.get("commands_available"),
                "commands_total": result.get("commands_total"),
                "error": result.get("error"),
            }
        )
    if name == "agent_environment_digest":
        ex = result.get("capabilities_summary_excerpt")
        ex_n = len(ex) if isinstance(ex, str) else None
        sid = result.get("active_chat_session_id")
        return _short_json(
            {
                "ok": result.get("ok"),
                "generated_at": result.get("generated_at"),
                "commands_available": result.get("commands_available"),
                "commands_total": result.get("commands_total"),
                "capabilities_excerpt_chars": ex_n,
                "has_active_chat_session_id": bool(
                    isinstance(sid, str) and sid.strip()
                ),
                "error": result.get("error"),
            }
        )
    if name == "aicd_session_logs":
        tx = result.get("text")
        tlen = len(tx) if isinstance(tx, str) else None
        fc = result.get("files")
        files_n = len(fc) if isinstance(fc, list) else None
        return _short_json(
            {
                "ok": result.get("ok"),
                "files_count": files_n,
                "log_path": result.get("path"),
                "tail_line_count": result.get("tail_line_count"),
                "filtered_line_count": result.get("filtered_line_count"),
                "filter_applied": result.get("filter_applied"),
                "text_chars": tlen,
                "error": result.get("error"),
            }
        )
    if name == "doc_extract":
        notes = result.get("notes")
        nlen = len(notes) if isinstance(notes, list) else None
        och = result.get("output_text_chars")
        if och is None and result.get("ok") and result.get("output_path"):
            try:
                from pathlib import Path

                och = Path(str(result["output_path"])).stat().st_size
            except OSError:
                och = None
        return _short_json(
            {
                "ok": result.get("ok"),
                "output_path": result.get("output_path"),
                "output_format": result.get("output_format"),
                "images_dir": result.get("images_dir"),
                "output_text_chars": och,
                "error": result.get("error"),
                "notes_count": nlen,
            }
        )
    if name == "doc_normalize":
        return _short_json(
            {
                "ok": result.get("ok"),
                "cache_hit": result.get("cache_hit"),
                "normalized_path": result.get("normalized_path"),
                "normalized_format": result.get("normalized_format"),
                "outline_path": result.get("outline_path"),
                "error": result.get("error"),
            }
        )
    if name == "markdown_section_slice":
        tx = result.get("text")
        tlen = len(tx) if isinstance(tx, str) else None
        return _short_json(
            {
                "ok": result.get("ok"),
                "title": result.get("title"),
                "heading_index": result.get("heading_index"),
                "start_byte": result.get("start_byte"),
                "text_chars": tlen,
                "truncated": result.get("truncated"),
                "error": result.get("error"),
            }
        )
    if name == "markdown_regex_scan":
        m = result.get("matches")
        mn = len(m) if isinstance(m, list) else None
        return _short_json(
            {
                "ok": result.get("ok"),
                "match_count": result.get("match_count", mn),
                "truncated_by_limit": result.get("truncated_by_limit"),
                "error": result.get("error"),
            }
        )
    if name == "markdown_chunk_split":
        return _short_json(
            {
                "ok": result.get("ok"),
                "chunk_count": result.get("chunk_count"),
                "index_path": result.get("index_path"),
                "error": result.get("error"),
            }
        )
    if name == "document_outline":
        return _short_json(
            {
                "ok": result.get("ok"),
                "heading_count": result.get("heading_count"),
                "saved_path": result.get("saved_path"),
                "format_detected": result.get("format_detected"),
                "error": result.get("error"),
            }
        )
    if name in (
        "library_doc_project_init",
        "library_doc_project_get",
        "library_doc_project_patch",
        "library_doc_snapshot",
    ):
        return _short_json(
            {
                "ok": result.get("ok"),
                "library_path": result.get("library_path"),
                "manifest_path": result.get("manifest_path"),
                "snapshot_dir": result.get("snapshot_dir"),
                "subdirs_created": result.get("subdirs_created"),
                "validation_warnings_n": len(result["validation_warnings"])
                if isinstance(result.get("validation_warnings"), list)
                else None,
                "note": result.get("note"),
                "error": result.get("error"),
            }
        )
    if name == "doc_manifest_validate":
        return _short_json(
            {
                "ok": result.get("ok"),
                "doc_slug": result.get("doc_slug"),
                "errors_n": len(result["errors"])
                if isinstance(result.get("errors"), list)
                else None,
                "warnings_n": len(result["warnings"])
                if isinstance(result.get("warnings"), list)
                else None,
            }
        )
    if name == "doc_manifest_coverage_report":
        return _short_json(
            {
                "ok": result.get("ok"),
                "leaf_node_count": result.get("leaf_node_count"),
                "nodes_without_content_paths_n": len(
                    result["nodes_without_content_paths"]
                )
                if isinstance(result.get("nodes_without_content_paths"), list)
                else None,
                "unreferenced_markdown_n": len(
                    result["unreferenced_markdown_files"]
                )
                if isinstance(result.get("unreferenced_markdown_files"), list)
                else None,
                "error": result.get("error"),
            }
        )
    if name == "library_resources_scan":
        return _short_json(
            {
                "ok": result.get("ok"),
                "entry_count": result.get("entry_count"),
                "index_path": result.get("index_path"),
                "missing_paths_n": len(result["missing_paths"])
                if isinstance(result.get("missing_paths"), list)
                else None,
                "error": result.get("error"),
            }
        )
    if name == "doc_text_health_check":
        fs = result.get("files")
        return _short_json(
            {
                "ok": result.get("ok"),
                "files_n": len(fs) if isinstance(fs, list) else None,
            }
        )
    if name == "doc_project_export":
        return _short_json(
            {
                "ok": result.get("ok"),
                "deliverables_dir": result.get("deliverables_dir"),
                "manifest_path": result.get("manifest_path"),
                "outputs_n": len(result["outputs"])
                if isinstance(result.get("outputs"), list)
                else None,
                "errors_n": len(result["errors"])
                if isinstance(result.get("errors"), list)
                else None,
                "attribution": result.get("attribution"),
            }
        )
    if name == "doc_revision_diff_summary":
        return _short_json(
            {
                "ok": result.get("ok"),
                "sequencer_similarity": result.get("sequencer_similarity"),
                "char_len_before": result.get("char_len_before"),
                "char_len_after": result.get("char_len_after"),
            }
        )
    if name == "library_doc_batch_quality_pass":
        return _short_json(
            {
                "ok": result.get("ok"),
                "generated_at_utc": result.get("generated_at_utc"),
                "attribution": result.get("attribution"),
            }
        )
    if name == "library_doc_node_resolve":
        return _short_json(
            {
                "ok": result.get("ok"),
                "node_id": result.get("node_id"),
                "content_paths_n": len(result["content_paths_resolved"])
                if isinstance(result.get("content_paths_resolved"), list)
                else None,
                "error": result.get("error"),
            }
        )
    if name == "vision_analyze_image":
        a = result.get("analysis")
        return _short_json(
            {
                "ok": result.get("ok"),
                "model_used": result.get("model_used"),
                "report_path": result.get("report_path"),
                "analysis_chars": len(a) if isinstance(a, str) else None,
                "error": result.get("error"),
            }
        )
    if name == "diagram_drawio_write":
        return _short_json(
            {
                "ok": result.get("ok"),
                "path": result.get("path"),
                "node_count": result.get("node_count"),
                "edge_count": result.get("edge_count"),
                "error": result.get("error"),
            }
        )
    if name == "diagram_drawio_summarize":
        return _short_json(
            {
                "ok": result.get("ok"),
                "path": result.get("path"),
                "vertex_count": result.get("vertex_count"),
                "edge_count": result.get("edge_count"),
                "truncated": result.get("truncated"),
                "error": result.get("error"),
            }
        )
    if name == "diagram_drawio_export_png":
        return _short_json(
            {
                "ok": result.get("ok"),
                "png_path": result.get("png_path"),
                "source_drawio": result.get("source_drawio"),
                "error": result.get("error"),
                "hint": result.get("hint"),
            }
        )
    if name == "visio_flowchart_write":
        return _short_json(
            {
                "ok": result.get("ok"),
                "path": result.get("path"),
                "node_count": result.get("node_count"),
                "edge_count": result.get("edge_count"),
                "error": result.get("error"),
                "hint": result.get("hint"),
            }
        )
    if name == "visio_vsdx_summarize":
        return _short_json(
            {
                "ok": result.get("ok"),
                "path": result.get("path"),
                "shape_row_count": result.get("shape_row_count"),
                "connect_count": result.get("connect_count"),
                "truncated": result.get("truncated"),
                "error": result.get("error"),
            }
        )
    if name == "image_crop":
        return _short_json(
            {
                "ok": result.get("ok"),
                "path": result.get("path"),
                "crop": result.get("crop"),
                "error": result.get("error"),
            }
        )
    if name == "image_transform":
        if result.get("operations_help"):
            return _short_json(
                {
                    "ok": result.get("ok"),
                    "help": True,
                    "known_operations_n": len(result.get("known_operations") or []),
                }
            )
        return _short_json(
            {
                "ok": result.get("ok"),
                "path": result.get("path"),
                "operation": result.get("operation"),
                "meta": result.get("meta"),
                "known_operations_n": len(result["known_operations"])
                if isinstance(result.get("known_operations"), list)
                else None,
                "error": result.get("error"),
            }
        )
    if name == "diagram_mermaid_png":
        return _short_json(
            {
                "ok": result.get("ok"),
                "png_path": result.get("png_path"),
                "mermaid_theme": result.get("mermaid_theme"),
                "error": result.get("error"),
                "hint": result.get("hint"),
            }
        )
    if name == "docx_compose":
        return _short_json(
            {
                "ok": result.get("ok"),
                "path": result.get("path"),
                "blocks_applied": result.get("blocks_applied"),
                "images_added": result.get("images_added"),
                "tables_added": result.get("tables_added"),
                "defaults_applied": result.get("defaults_applied"),
                "style_profile_notes_chars": len(str(result.get("style_profile_notes") or "")),
                "error": result.get("error"),
            }
        )
    if name == "style_reference_scan":
        ent = result.get("entries")
        return _short_json(
            {
                "ok": result.get("ok"),
                "root": result.get("root"),
                "entry_count": result.get("entry_count"),
                "style_digest_chars": len(str(result.get("style_digest") or "")),
                "error": result.get("error"),
            }
        )
    if name == "xlsx_write_workbook":
        return _short_json(
            {
                "ok": result.get("ok"),
                "path": result.get("path"),
                "sheet_names_n": len(result["sheet_names"])
                if isinstance(result.get("sheet_names"), list)
                else None,
                "error": result.get("error"),
            }
        )
    if name == "xlsx_write_xlsxwriter":
        return _short_json(
            {
                "ok": result.get("ok"),
                "path": result.get("path"),
                "engine": result.get("engine"),
                "error": result.get("error"),
                "hint": result.get("hint"),
            }
        )
    if name == "xlsx_read_workbook":
        sh = result.get("sheets")
        return _short_json(
            {
                "ok": result.get("ok"),
                "path": result.get("path"),
                "value_mode": result.get("value_mode"),
                "sheets_n": len(sh) if isinstance(sh, list) else None,
                "error": result.get("error"),
            }
        )
    if name == "xlsx_patch_workbook":
        return _short_json(
            {
                "ok": result.get("ok"),
                "path": result.get("path"),
                "sheet_names_n": len(result["sheet_names"])
                if isinstance(result.get("sheet_names"), list)
                else None,
                "error": result.get("error"),
            }
        )
    if name == "pptx_inspect_template":
        lo = result.get("layouts")
        return _short_json(
            {
                "ok": result.get("ok"),
                "path": result.get("path"),
                "layout_count": result.get("layout_count"),
                "layouts_n": len(lo) if isinstance(lo, list) else None,
                "error": result.get("error"),
            }
        )
    if name == "pptx_compose":
        return _short_json(
            {
                "ok": result.get("ok"),
                "path": result.get("path"),
                "slide_count": result.get("slide_count"),
                "error": result.get("error"),
            }
        )
    if name == "pptx_from_html_deck":
        return _short_json(
            {
                "ok": result.get("ok"),
                "path": result.get("path"),
                "slide_count": result.get("slide_count"),
                "manifest_path": result.get("manifest_path"),
                "deck_root": result.get("deck_root"),
                "error": result.get("error"),
            }
        )
    if name == "docx_export_pdf":
        sug = result.get("install_suggestions")
        return _short_json(
            {
                "ok": result.get("ok"),
                "pdf_path": result.get("pdf_path"),
                "via": result.get("via"),
                "source_docx": result.get("source_docx"),
                "error": result.get("error"),
                "hint": result.get("hint"),
                "install_suggestions_n": len(sug) if isinstance(sug, list) else None,
                "next_step_for_agent": bool(result.get("next_step_for_agent")),
            }
        )
    if name == "markdown_to_pdf":
        return _short_json(
            {
                "ok": result.get("ok"),
                "pdf_path": result.get("pdf_path"),
                "engine": result.get("engine"),
                "image_missing_srcs_n": len(result["image_missing_srcs"])
                if isinstance(result.get("image_missing_srcs"), list)
                else None,
                "image_markdown_refs_missing_n": len(
                    result["image_markdown_refs_missing"]
                )
                if isinstance(result.get("image_markdown_refs_missing"), list)
                else None,
                "image_layout_adjusted": result.get("image_layout_adjusted"),
                "error": result.get("error"),
                "hint": result.get("hint"),
            }
        )
    if name == "pdf_compose":
        return _short_json(
            {
                "ok": result.get("ok"),
                "pdf_path": result.get("pdf_path"),
                "engine": result.get("engine"),
                "block_count": result.get("block_count"),
                "error": result.get("error"),
                "hint": result.get("hint"),
            }
        )
    if name == "doc_convert_markdown":
        return _short_json(
            {
                "ok": result.get("ok"),
                "markdown": result.get("markdown"),
                "assets": result.get("assets"),
                "error": result.get("error"),
            }
        )
    cleaned = _strip_large_values(dict(result), blob_keys=_RESULT_BLOB_KEYS)
    return _short_json(cleaned)


class SessionLogger:
    """线程安全追加写 UTF-8 日志。"""

    def __init__(self, path: Path) -> None:
        self._path = path.resolve()
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._fp = open(self._path, "a", encoding="utf-8", buffering=1)
        self._closed = False

    @property
    def path(self) -> Path:
        return self._path

    def close(self) -> None:
        with self._lock:
            if not self._closed:
                self._fp.close()
                self._closed = True

    def write_event(
        self,
        kind: str,
        component: str,
        operation: str,
        input_summary: str,
        output_summary: str,
    ) -> None:
        ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
        line = (
            f"{ts} | {kind} | {component} | {operation} | "
            f"in={input_summary} | out={output_summary}\n"
        )
        with self._lock:
            if self._closed:
                return
            self._fp.write(line)
            self._fp.flush()

    def write_exception(
        self,
        kind: str,
        component: str,
        operation: str,
        exc: BaseException,
        extra: str = "",
    ) -> None:
        msg = f"{type(exc).__name__}: {exc}"
        if extra:
            msg = f"{msg} | {extra}"
        self.write_event(kind, component, operation, "", msg)

    def write_startup(self, info: dict[str, Any]) -> None:
        ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
        block = json.dumps(info, ensure_ascii=False, indent=2, default=str)
        with self._lock:
            if self._closed:
                return
            self._fp.write(f"{ts} | startup | session | banner | in= | out=\n")
            self._fp.write(block + "\n")
            self._fp.flush()


def build_startup_info(
    *,
    home: Path,
    session_log_path: Path,
    session_id: str,
    workspace_cwd: Path,
    cfg_summary: dict[str, Any],
    layout: dict[str, Path] | None = None,
    runtime_env_path: str | None = None,
) -> dict[str, Any]:
    out: dict[str, Any] = {
        "home": str(home),
        "session_log_file": str(session_log_path),
        "session_id": session_id,
        "workspace_cwd": str(workspace_cwd),
        "argv": sys.argv,
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "cwd_process": str(Path.cwd().resolve()),
        "env": {
            "AICD_HOME": os.environ.get("AICD_HOME", ""),
            "USER": os.environ.get("USER", os.environ.get("USERNAME", "")),
        },
        "llm": cfg_summary,
    }
    if layout:
        out["config_path"] = str(layout["config"])
        out["db_path"] = str(layout["db"])
    if runtime_env_path:
        out["runtime_env_path"] = runtime_env_path
    return out


def llm_config_for_log(cfg: Any) -> dict[str, Any]:
    """不写密钥。"""
    return {
        "proto": getattr(cfg, "proto", ""),
        "model": getattr(cfg, "model", ""),
        "base_url": getattr(cfg, "base_url", "") or "",
        "api_key_configured": bool(getattr(cfg, "api_key", None)),
        "timeout_sec": getattr(cfg, "timeout_sec", None),
        "temperature": getattr(cfg, "temperature", None),
        "top_p": getattr(cfg, "top_p", None),
        "frequency_penalty": getattr(cfg, "frequency_penalty", None),
        "presence_penalty": getattr(cfg, "presence_penalty", None),
        "max_output_tokens": getattr(cfg, "max_output_tokens", None),
        "repetition_penalty": getattr(cfg, "repetition_penalty", None),
        "max_retries": getattr(cfg, "max_retries", None),
        "retry_base_delay_sec": getattr(cfg, "retry_base_delay_sec", None),
        "extra_body_keys": list(getattr(cfg, "extra_body", {}) or {}),
    }


def app_config_for_log(cfg: Any) -> dict[str, Any]:
    """启动日志：LLM + Agent 轮次（无密钥）。"""
    out = llm_config_for_log(getattr(cfg, "llm", cfg))
    if hasattr(cfg, "agent"):
        ag = cfg.agent
        out["agent_max_tool_rounds"] = getattr(ag, "max_tool_rounds", None)
        out["agent_sub_max_tool_rounds"] = getattr(ag, "sub_agent_max_tool_rounds", None)
        out["agent_context_budget_tokens"] = getattr(
            ag, "context_budget_tokens", None
        )
        out["agent_chat_history_max_messages"] = getattr(
            ag, "chat_history_max_messages", None
        )
        out["agent_chat_history_recent_full_rows"] = getattr(
            ag, "chat_history_recent_full_rows", None
        )
        out["agent_idle_heartbeat_sec"] = getattr(ag, "idle_heartbeat_sec", None)
        out["agent_sub_idle_heartbeat_sec"] = getattr(
            ag, "sub_agent_idle_heartbeat_sec", None
        )
        out["agent_lifecycle_coalesce_sec"] = getattr(
            ag, "lifecycle_coalesce_sec", None
        )
        out["agent_block_external_network"] = bool(
            getattr(ag, "block_external_network", False)
        )
    if hasattr(cfg, "plugins"):
        pl = cfg.plugins
        out["plugins_boot_plugin_mode"] = getattr(pl, "boot_plugin_mode", None)
        out["plugins_max_invocation_depth"] = getattr(pl, "max_invocation_depth", None)
        out["plugins_allow_nested_aicd_from_plugins"] = getattr(
            pl, "allow_nested_aicd_from_plugins", None
        )
    if hasattr(cfg, "integrations"):
        ing = cfg.integrations
        wf = getattr(ing, "web_fetch", None)
        gh = getattr(ing, "github", None)
        if wf is not None:
            out["web_fetch_default_timeout_sec"] = getattr(
                wf, "default_timeout_sec", None
            )
            out["web_fetch_max_response_bytes"] = getattr(
                wf, "max_response_bytes", None
            )
        if gh is not None:
            out["github_token_configured"] = bool(
                (getattr(gh, "token", None) or "").strip()
            )
            out["github_api_base"] = getattr(gh, "api_base_url", None)
    return out
