from __future__ import annotations

from aicd.ui.tui_chat_render import (
    _is_table_separator_row,
    normalize_markdown_blocks,
    render_assistant_message,
)


def test_is_table_separator_row() -> None:
    assert _is_table_separator_row("| :--- | :--- |")
    assert _is_table_separator_row("| --- | --- |")
    assert _is_table_separator_row("|:---|:---|")
    assert not _is_table_separator_row("| **a** | b |")
    assert not _is_table_separator_row("plain")


def test_normalize_inserts_blank_before_table_after_paragraph() -> None:
    raw = "下面是参数：\n| A | B |\n| --- | --- |\n| 1 | 2 |"
    out = normalize_markdown_blocks(raw)
    lines = out.split("\n")
    pipe_i = next(i for i, ln in enumerate(lines) if ln.startswith("| A |"))
    assert pipe_i >= 1 and lines[pipe_i - 1] == ""


def test_render_assistant_message_empty() -> None:
    r = render_assistant_message("")
    assert r is not None


def test_render_assistant_message_markdown_table() -> None:
    raw = "| K | V |\n| --- | --- |\n| a | b |"
    r = render_assistant_message(raw)
    assert r is not None
