import asyncio
import json
import websockets
from typing import Callable, Coroutine, Any, Dict, Set

class CimeEvents:
    def __init__(self, url: str):
        self.url = url
        self.ws = None
        self.handlers: Dict[str, Set[Callable[[Any], Coroutine]]] = {}
        self.subscriptions: Set[str] = set()
        self._running = False

    def on(self, event_type: str, handler: Callable[[Any], Coroutine]):
        if event_type not in self.handlers:
            self.handlers[event_type] = set()
        self.handlers[event_type].add(handler)

    async def connect(self):
        async with websockets.connect(self.url) as self.ws:
            self._running = True
            await self._resubscribe()
            while self._running:
                try:
                    message_raw = await self.ws.recv()
                    message = json.loads(message_raw)
                    event_type = message.get("type")
                    data = message.get("data")
                    
                    if event_type in self.handlers:
                        for handler in self.handlers[event_type]:
                            asyncio.create_task(handler(data))
                except websockets.exceptions.ConnectionClosed:
                    break
        self._running = False

    async def _resubscribe(self):
        for topic in self.subscriptions:
            await self.ws.send(json.dumps({"type": "SUBSCRIBE", "topic": topic}))

    async def subscribe(self, topic: str):
        self.subscriptions.add(topic)
        if self.ws and not self.ws.closed:
            await self.ws.send(json.dumps({"type": "SUBSCRIBE", "topic": topic}))

    async def unsubscribe(self, topic: str):
        self.subscriptions.remove(topic)
        if self.ws and not self.ws.closed:
            await self.ws.send(json.dumps({"type": "UNSUBSCRIBE", "topic": topic}))

    def disconnect(self):
        self._running = False
