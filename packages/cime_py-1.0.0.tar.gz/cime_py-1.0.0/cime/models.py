from typing import List, Optional, Generic, TypeVar, Literal
from pydantic import BaseModel
from enum import Enum

T = TypeVar('T')

class CimeResponse(BaseModel, Generic[T]):
    code: int
    message: Optional[str] = None
    content: T

class UserChannelInfo(BaseModel):
    channelId: str
    channelName: str
    channelHandle: str

class Channel(BaseModel):
    channelId: str
    channelName: str
    channelHandle: str
    channelImageUrl: Optional[str] = None
    channelDescription: str
    followerCount: int

class BulkChannelResponse(BaseModel):
    data: List[Channel]

class Live(BaseModel):
    liveId: str
    liveTitle: str
    liveThumbnailImageUrl: Optional[str] = None
    concurrentUserCount: int
    openedDate: Optional[str] = None
    adult: bool
    tags: List[str]
    categoryType: Optional[str] = None
    liveCategory: Optional[str] = None
    liveCategoryValue: Optional[str] = None
    channelId: str
    channelName: str
    channelHandle: str
    channelImageUrl: Optional[str] = None

class Page(BaseModel):
    next: Optional[int] = None

class LiveListResponse(BaseModel):
    data: List[Live]
    page: Page

class LiveSetting(BaseModel):
    defaultLiveTitle: str
    categoryType: Optional[str] = None
    liveCategory: Optional[str] = None
    tags: List[str]

class ChatSettings(BaseModel):
    chatAllowedGroup: Literal['ALL', 'FOLLOWER', 'MANAGER']
    minFollowerMinute: int
    followerSubscriberChatAllow: Optional[bool] = None

class MessageResponse(BaseModel):
    messageId: str

class Category(BaseModel):
    categoryId: str
    categoryType: str
    categoryValue: str
    posterImageUrl: Optional[str] = None

class CategorySearchResponse(BaseModel):
    data: List[Category]

class SessionResponse(BaseModel):
    url: str

class EventType(str, Enum):
    CHAT = 'CHAT'
    DONATION = 'DONATION'
    SUBSCRIPTION = 'SUBSCRIPTION'
