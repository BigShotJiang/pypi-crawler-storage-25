# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.13.0] - 2026-04-16

### Added
- **GAN training support.** `GANModel` composite model wrapping generator +
  discriminator with separate D/G scoring steps (`discriminator_step`,
  `generator_step`), IOSpec-validated dict outputs, and `edge_enhanced`
  discriminator input via training hooks.
- **Training hook system.** `TrainingHook` base class with composable
  behaviors injected into the training loop at defined stages. Hooks read
  and modify a mutable `TrainingContext` (or `GANTrainingContext` for GAN).
  Built-in hooks: `StepRatio`, `DWarmup`, `R1GradientPenalty`,
  `GradientClip`, `EdgeEnhancedInput`.
- **Stage registry.** `Stages` / `GANStages` namespace classes with
  auto-registered string constants via metaclass. Hook `on_*` method names
  validated at class creation — typos caught immediately. Custom stages via
  subclassing `Stages`.
- **Runner state protocol.** `training_state()`, `load_training_state()`,
  `zero_grad()` on all runners. Trainer, checkpoint, and events use these
  generically — no runner-specific knowledge needed.
- **Vanilla GAN losses.** `GANDiscriminatorLoss` (BCE real=1, fake=0) and
  `GANGeneratorLoss` (BCE fake=1). Recommended for UNet discriminators —
  more stable than RaGAN.
- **RaGAN losses updated.** Per-sample output (`reduction='none'`) with
  spatial reduction for UNet discriminator compatibility.
- **`GANTrainingRunner`** with dual optimizers, hook dispatch at each
  training stage, and configurable behaviors via `hooks` list.
- **`Model.set_io` validates inputs** against `io_spec` — unknown params
  rejected with `strict=True`, missing required params rejected with
  `require_all=True`.
- **`Model.set_io` auto-populates `io_spec` outputs** from config — the
  spec reflects the full interface after binding.
- **`SequentialModel` populates `io_spec.required_outputs`** from flow
  step outputs.
- **GANModel documentation** — full guide with real-world ProbaV config,
  training hooks, adversarial loss selection, training dynamics monitoring.
- **227 new tests** — coverage from 54% to 63%. Comprehensive tests for
  trainers, runners, stop conditions, observers, utils, hooks, GANModel,
  adversarial losses, IOSpec, io_parsing, IO binding integration.
- `UNetDiscriminatorSN` and `VGGStyleDiscriminator` ported from BasicSR.

### Changed
- **`TrainerEpochFinished` event** carries `runner_state` dict instead of
  individual `optimizer`/`scaler`/`optimizer_D`/`scaler_D` fields.
- **`save_checkpoint`** takes `runner_state` dict instead of individual
  optimizer/scaler params.
- **`resume_from_checkpoint`** takes a runner (with `load_training_state`)
  instead of an optimizer.
- **`CheckpointState`** uses `runner_state` dict instead of individual
  `optimizer_state`/`scaler_state` fields.
- `PyTorchTrainer.sanity_check` runs postprocessor after forward.
- `PyTorchTrainer.sanity_check` uses `runner.zero_grad()` instead of
  hardcoded optimizer checks.
- `WandbTracker.restore_from_run` uses stored entity/project for
  compatibility with disabled mode.

### Deprecated
- `save_checkpoint(optimizer=..., scaler=...)` — use `runner_state` dict.
- `CheckpointState.optimizer_state`, `.scaler_state`, `.optimizer_D_state`,
  `.scaler_D_state` — use `.runner_state` dict.
- `TrainerEpochFinished.optimizer`, `.scaler`, `.optimizer_D`, `.scaler_D`
  — use `.runner_state` dict.
- `resume_from_checkpoint(model, optimizer, ...)` — pass runner instead.
- Legacy checkpoint format (flat optimizer/scaler fields) — auto-converted
  with warning on load.
- `GANTrainingRunner` legacy `__init__` params (`step_ratio`, `r1_weight`,
  `grad_clip_D`, `d_warmup_batches`) — use `hooks` list instead.

### Removed
- `environment.yml`, `install_commands_3090.txt`, `install_commands_5090.txt`
  — `pyproject.toml` is the source of truth for dependencies.

## [0.12.5] - 2026-04-10

### Added
- Rich-based `ProgressBar` observer with adaptive rendering: full rich progress for TTY, plain ANSI for non-TTY (PyCharm).
- Custom `SrForgeHighlighter` for log messages — highlights numbers, paths, devices, booleans (TTY only).
- `WandbTracker` prints styled run info panel on initialization.
- `GlobalSettings.tracker` — framework-wide access to the active experiment tracker.
- SR-Forge startup banner via `init()`.
- Graceful Ctrl+C: `SIGINT`/`SIGBREAK` handlers call `tracker.finish(1)` + `os._exit(1)`.
- `rich>=13.0` dependency.

### Changed
- `configure_logger()` uses `rich.logging.RichHandler` with colorlog fallback.
- TTY vs non-TTY detection for different logging themes.
- `ProgressBar` shows `M/N` iteration count, ETA skips first-batch warmup.
- `GlobalSettings` requires `srforge.init()` before access — raises `RuntimeError` otherwise.
- Scaffold `train.py` uses `logger.info()` instead of `print()`.

## [0.12.4] - 2026-04-10

### Added
- `PyTorchTrainer.sanity_check()` — runs one batch through training and validation runners with observer suppression to catch errors before wandb init.
- `WandbTracker` now accepts `save_code` (default `True`) and `**kwargs` forwarded to `wandb.init()`.

### Changed
- Scaffold `train.py` runs sanity check before tracker init, avoiding orphaned wandb runs on failure.
- Scaffold `train-cfg.yaml` connects validation dataset to `${preprocessing.validation}`.

## [0.12.3] - 2026-03-16

### Fixed
- Scalar tensor handling in loss storage — proper unsqueezing when `ndim == 0`.

### Changed
- Added `${preprocessing.training}` transforms entry to scaffold training config.
- Improved `${ref:}` vs `${}` documentation with warning admonitions and decision guide.
- MagNAt optional import fix (torch-geometric).

## [0.12.1] - 2026-03-05

### Added
- `InferenceRunner` base class for non-training runners, eliminating code duplication between `ValidationEpochRunner` and `BenchmarkRunner`.
- `GaussianBlur` data transform.
- `MultibandToGraphEntry` and `MultiImageToGraphEntry` replace `EntryToGraphEntry`.

### Fixed
- ProgressBar batch_size fallback used batch index instead of actual size, producing wrong running averages.
- ProgressBar timer overflow — durations over 24 hours no longer wrap to `0:00:00`.
- Scaffold configs use fully qualified `_target` names.

### Changed
- Criterion ownership moved from runners to `PyTorchTrainer`; runners receive criterion via `run_epoch(criterion=...)`.
- `_merge_fields` inlined into `Entry.merge_fields()` and `GraphEntry.merge_fields()`; module-level function removed.
- `_unbatch_value` deduplicated; `transform/__init__.py` imports `_index_value` from `entry.py`.
- Scaffold test script renamed to benchmark.
- Shared output-handling logic extracted into `EpochRunner` base class.

### Removed
- `LogitsLogger` observer (buggy batch indexing, unused).
- `EntryToGraphEntry` (replaced by `MultibandToGraphEntry` / `MultiImageToGraphEntry`).

## [0.12.0] - 2026-02-25

### Added
- `srforge.init()` now accepts `log_level` parameter for logger configuration.
- `srforge init` CLI scaffolds `test.py` and `test-cfg.yaml` alongside training files.
- DataTransform supports positional multi-input/output in flow DSL, matching Model syntax.
- DataTransform supports named input mapping on LHS in flow DSL (`(image=x) -> t -> y`).
- Return count validation for DataTransform (mismatch between outputs and return values raises `ValueError`).
- TRMISR per-component learning rate groups (`lr_coder`, `lr_transformer`).
- Image caption support in `ExperimentTracker.log_image()` and `BatchImageLogger`.
- Trainers & Runners documentation page with mermaid flow diagrams.
- IDE support section in Getting Started with JetBrains Marketplace widget for SR-Forge Assistant.
- ConfigResolver caching edge-case warnings in Configuration documentation.
- Model vs DataTransform comparison section in IO Binding documentation.

### Fixed
- `Entry.to()` and `Entry.numpy()` now preserve batch metadata (`_is_batched`, `_batch_size`).
- `RegisterEntry` skips zero-translation shifts and uses configurable interpolation order.

### Changed
- Named input mapping moved from module segment to LHS: `(image=x) -> m -> y` instead of `-> m(image=x) -> y`.
- `scripts/` directory removed; scaffold is the single source of truth for project templates.
- `train` and `test` console script entry points removed from `pyproject.toml`.
- Scaffold package renamed from `srforge.scaffold` to `srforge._scaffold` (internal).

### Removed
- Dict output format in `set_io()` (`outputs: {port: field}`) — use string or list instead.
- Named output mapping in flow DSL (`-> m -> (port=field)`) — use positional outputs.
- IOSpec/port terminology from public API and documentation.
- Pre-binding fallback for DataTransform in SequentialModel (flow DSL is the single source of truth).
- `flat_to_applications()` utility from `io_parsing.py`.

## [0.11.0] - 2026-02-23

### Changed
- `ResizeFieldsToReference` rewritten as tensor-only DataTransform; manual container recursion removed.
- `ChooseImages` rewritten as tensor-only DataTransform with configurable dim.
- `ResizeFieldsToReference`, `ChooseImages` converted from EntryTransform to DataTransform; `CenterOffset` removed.
- IOSpec removed from EntryTransform; field binding uses constructor `_key` params instead.

## [0.10.0] - 2026-02-23

### Added
- `srforge.init()` one-call framework setup for Hydra scripts.
- `resume_from_checkpoint()` utility with standardized checkpoint structure.
- `${ref:path}` syntax for unquoted object references in YAML config.
- `ConfigResolver` for generic config resolution (deprecates `ConfigParser`).
- `ExperimentTracker` abstraction and multi-GPU utility (`setup_device()`).
- Observer subscription is explicit via `event_bus.subscribe()`.

### Changed
- Tracker removed from `GlobalSettings`; passed explicitly to observers.
- `ResumeState` dropped; `trainer.restore(ckpt)` facade added.
- `templates.py` replaced with real scaffold files for `srforge init`.
- Scripts rewritten to use `ConfigResolver` + tracker.

## [0.9.0] - 2026-02-17

### Changed
- README rewritten to match documentation; index code example fixed.

## [0.8.0] - 2026-02-17

### Added
- Automatic versioning via setuptools-scm.
- PyPI publishing CI pipeline.

## [0.7.0] - 2026-02-16

### Added
- `srforge init` CLI for project scaffolding.
- Unified `set_io()` structured format across Model, DataTransform, and Loss.
- Loss inherits `IOModule` with `set_io()` binding.
- Annotation-driven container recursion for DataTransform.
- Dual-path transforms (`transform()` / `transform_unbatched()`).
- Batch indexing, per-sample transforms, and `Entry.__len__`.
- `StackSequence`, `StackTensors`, `FlattenDict` transforms.
- Comprehensive MkDocs documentation site.
- Reusable modules in SequentialModel with `forward()` rename support.
- `LossScheduler` for epoch-aware criterion switching.
- Typed events and auto-wired observer system.

### Changed
- `torch-geometric` made an optional dependency (`srforge[graph]`).
- Dataset caching rewritten with built-in implementation (replaces `torchdatasets`).
- Transform method names unified to `transform()` / `transform_unbatched()`.
- `Preprocessor` and `TransformationSpec` removed; `EntryTransform` is standalone.
- Codebase cleanup: `assert` replaced with proper exceptions, `super()` modernized.

[Unreleased]: https://gitlab.com/tarasiewicztomasz/sr-forge/-/compare/v0.12.3...HEAD
[0.12.3]: https://gitlab.com/tarasiewicztomasz/sr-forge/-/compare/v0.12.1...v0.12.3
[0.12.1]: https://gitlab.com/tarasiewicztomasz/sr-forge/-/compare/v0.12.0...v0.12.1
[0.12.0]: https://gitlab.com/tarasiewicztomasz/sr-forge/-/compare/v0.11.0...v0.12.0
[0.11.0]: https://gitlab.com/tarasiewicztomasz/sr-forge/-/compare/v0.10.0...v0.11.0
[0.10.0]: https://gitlab.com/tarasiewicztomasz/sr-forge/-/compare/v0.9.0...v0.10.0
[0.9.0]: https://gitlab.com/tarasiewicztomasz/sr-forge/-/compare/v0.8.0...v0.9.0
[0.8.0]: https://gitlab.com/tarasiewicztomasz/sr-forge/-/compare/v0.7.0...v0.8.0
[0.7.0]: https://gitlab.com/tarasiewicztomasz/sr-forge/-/releases/v0.7.0
