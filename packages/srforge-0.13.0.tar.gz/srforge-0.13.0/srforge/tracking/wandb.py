"""Weights & Biases experiment tracker."""

from __future__ import annotations

from typing import Any

import numpy as np

from srforge.registry import register_class
from .base import ExperimentTracker


@register_class
class WandbTracker(ExperimentTracker):
    """Experiment tracker backed by Weights & Biases.

    Constructor parameters mirror ``wandb.init()`` arguments.
    """

    def __init__(
        self,
        *,
        project: str,
        entity: str | None = None,
        name: str | None = None,
        run_id: str | None = None,
        group: str | None = None,
        notes: str | None = None,
        tags: list[str] | None = None,
        job_type: str = "training",
        resume: str = "allow",
        mode: str = "online",
        dir: str | None = None,
        settings: Any = None,
        save_code: bool = True,
        **kwargs,
    ):
        import wandb

        self._wandb = wandb
        self._entity = entity
        self._project = project
        self._wandb.init(
            project=project,
            entity=entity,
            name=name,
            id=run_id,
            group=group,
            notes=notes,
            tags=tags,
            job_type=job_type,
            resume=resume,
            mode=mode,
            dir=dir,
            settings=settings,
            save_code=save_code,
            **kwargs,
        )
        # Register as global tracker
        from srforge import GlobalSettings
        GlobalSettings().tracker = self
        self._print_run_info()

    def _print_run_info(self):
        """Print a styled run summary panel."""
        try:
            from rich.console import Console
            from rich.table import Table
            from rich.panel import Panel

            run = self._wandb.run
            if run is None:
                return

            table = Table(show_header=False, box=None, padding=(0, 2))
            table.add_column(style="dim")
            table.add_column(style="bold")
            table.add_row("Run ID", run.id)
            table.add_row("Name", run.name)
            table.add_row("Project", run.project)
            table.add_row("Path", run.path)
            if run.resumed:
                table.add_row("Resumed", "[yellow]yes[/yellow]")

            console = Console(force_terminal=True)
            console.print(Panel(
                table,
                title="[bold color(220)]Tracking[/bold color(220)]",
                border_style="dim",
                expand=False,
            ))
        except ImportError:
            run = self._wandb.run
            if run:
                print(f"Run ID: {run.id}")
                print(f"Name: {run.name}")
                print(f"Path: {run.path}")

    # --- Run info ---
    @property
    def run_id(self) -> str | None:
        run = self._wandb.run
        return run.id if run else None

    @property
    def run_name(self) -> str | None:
        run = self._wandb.run
        return run.name if run else None

    @property
    def run_path(self) -> str | None:
        run = self._wandb.run
        return run.path if run else None

    @property
    def is_resumed(self) -> bool:
        run = self._wandb.run
        return run.resumed if run else False

    # --- Logging ---
    def log_metrics(self, metrics: dict, *, step: int) -> None:
        self._wandb.log(metrics, step=step)

    def log_image(self, key: str, image: np.ndarray, *, step: int, caption: str = None) -> None:
        self._wandb.log({key: self._wandb.Image(image, caption=caption)}, step=step)

    def set_summary(self, key: str, value: Any) -> None:
        self._wandb.run.summary[key] = value

    def commit(self, *, step: int) -> None:
        self._wandb.log({}, step=step, commit=True)

    # --- Config ---
    def log_config(self, config: dict) -> None:
        self._wandb.config.update(config, allow_val_change=True)

    # --- Model monitoring ---
    def watch_model(self, model: Any, **kwargs) -> None:
        self._wandb.watch(model, **kwargs)

    # --- File management ---
    def save_file(self, path: str, *, base_path: str | None = None) -> None:
        self._wandb.save(path, base_path=base_path)

    def restore_file(self, filename: str) -> str:
        restored = self._wandb.run.restore(filename)
        if restored is None:
            raise FileNotFoundError(
                f"Could not restore '{filename}' from run {self.run_id}"
            )
        return restored.name

    def restore_from_run(self, run_id: str, filename: str) -> str:
        entity = self._entity or self._wandb.run.entity
        project = self._project or self._wandb.run.project
        run = self._wandb.Api().run(f"{entity}/{project}/{run_id}")
        downloaded = run.file(filename).download(replace=True)
        return downloaded.name

    # --- Lifecycle ---
    def finish(self, exit_code: int = 0) -> None:
        self._wandb.finish(exit_code)
