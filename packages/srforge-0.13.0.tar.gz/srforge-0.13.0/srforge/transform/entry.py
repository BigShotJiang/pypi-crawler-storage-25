"""
Module with transformations over entries aka :class:`Entry`.

"""
import logging
from skimage.registration import phase_cross_correlation
from scipy.ndimage import shift
from typing import Union, Dict, Iterable, Tuple, List, Any, Optional
import copy

import numpy as np
import torch
from torchvision import transforms
from torchvision.transforms.functional import crop

from srforge.data import Entry, GraphEntry
from srforge.data.multispectral.descriptors import MultiSpectralDescriptor
from srforge.transform import EntryTransform
from srforge.registry import register_class
from srforge.utils.deprecation import deprecated_class

logger = logging.getLogger(__name__)


def _filter_bands_in_entry(
    entry: Entry,
    keep: Optional[set[str]] = None,
    remove: Optional[set[str]] = None,
    bands_var: str = "bands",
) -> Entry:
    if keep is not None and remove is not None:
        raise ValueError("Provide either keep or remove, not both.")
    for key in list(entry.keys()):
        value = entry[key]
        if isinstance(value, dict):
            if keep is not None:
                entry[key] = {k: v for k, v in value.items() if k in keep}
            else:
                entry[key] = {k: v for k, v in value.items() if k not in remove}
    if bands_var in entry:
        bands = entry[bands_var]
        if isinstance(bands, list) and bands and isinstance(bands[0], list):
            if keep is not None:
                entry[bands_var] = [[b for b in inner if b in keep] for inner in bands]
            else:
                entry[bands_var] = [[b for b in inner if b not in remove] for inner in bands]
        elif isinstance(bands, list):
            if keep is not None:
                entry[bands_var] = [b for b in bands if b in keep]
            else:
                entry[bands_var] = [b for b in bands if b not in remove]
    return entry

@register_class
class LeaveBands(EntryTransform):

    def __init__(self, bands_to_leave: Union[str, List[str]], *, bands_key: str):
        """
        Leaves only specified bands in a multispectral Entry (dict-of-bands) and removes all other bands.
        :param bands_to_leave: A single band name or a list of band names to be left.
        :param bands_key: Entry field name holding the list of band names.
        """
        if isinstance(bands_to_leave, str):
            bands_to_leave = [bands_to_leave]
        self.bands_to_leave = bands_to_leave
        self.bands_key = bands_key
        super().__init__()

    def transform(self, entry: Entry):
        return self.transform_unbatched(entry)

    def transform_unbatched(self, entry: Entry):
        keep = set(self.bands_to_leave)
        return _filter_bands_in_entry(entry, keep=keep, bands_var=self.bands_key)


@register_class
class RemoveBands(EntryTransform):

    def __init__(self, bands_to_remove: Union[str, List[str]], *, bands_key: str):
        """
        Removes specified bands from a multispectral Entry (dict-of-bands).
        :param bands_to_remove: A single band name or a list of band names to be removed.
        :param bands_key: Entry field name holding the list of band names.
        """
        if isinstance(bands_to_remove, str):
            bands_to_remove = [bands_to_remove]
        self.bands_to_remove = bands_to_remove
        self.bands_key = bands_key
        super().__init__()

    def transform(self, entry: Entry) -> Entry:
        return self.transform_unbatched(entry)

    def transform_unbatched(self, entry: Entry) -> Entry:
        remove = set(self.bands_to_remove)
        return _filter_bands_in_entry(entry, remove=remove, bands_var=self.bands_key)


@register_class
class SetAttribute(EntryTransform):
    """
    An EntryTransform that sets an attribute in an Entry.
    The attribute is set to the value provided in the constructor.
    """

    def __init__(self, value: Any, *, attr_key: str):
        self.value = value
        self.attr_key = attr_key
        super().__init__()

    def transform(self, entry: Entry) -> Entry:
        return self.transform_unbatched(entry)

    def transform_unbatched(self, entry: Entry) -> Entry:
        entry[self.attr_key] = self.value
        return entry

@register_class
class StackBands(EntryTransform):
    """
    Stacks multispectral bands into a single entry.
    Every attribute in each band-mapped field of the Entry is going to be concatenated. If all the bands have the same
    values for the attribute, the resulting entry will have the same value for that attribute to avoid duplication.
    """

    def __init__(self,
                 bands_descriptor: Optional[MultiSpectralDescriptor] = None,
                 *,
                 bands_list_key: str,
                 field_key: str,
                 output_key: Optional[str] = None):
        self.bands_descriptor = bands_descriptor
        self.bands_list_key = bands_list_key
        self.field_key = field_key
        self.output_key = output_key
        super().__init__()

    def transform(self, entry: Entry):
        return self.transform_unbatched(entry)

    def transform_unbatched(self, entry: Entry):
        field_value = entry[self.field_key]
        entry_bands_raw = entry[self.bands_list_key]

        # Extract canonical band list from batch-wrapped format [["b1", "b2"], ...]
        if isinstance(entry_bands_raw, list) and entry_bands_raw and isinstance(entry_bands_raw[0], list):
            canonical_bands = entry_bands_raw[0]
        elif isinstance(entry_bands_raw, list):
            canonical_bands = entry_bands_raw
        else:
            canonical_bands = entry_bands_raw

        if self.bands_descriptor is None:
            if not isinstance(canonical_bands, list) or not canonical_bands:
                raise ValueError(
                    "No bands descriptor provided and entry has no 'bands' list. "
                    "Please provide a MultiSpectralDescriptor or ensure 'bands' is present."
                )
            bands = canonical_bands
        else:
            descriptor_bands = self.bands_descriptor.bands()
            if isinstance(canonical_bands, list) and canonical_bands:
                bands = [b for b in descriptor_bands if b in canonical_bands]
            else:
                bands = descriptor_bands
        if not bands:
            raise ValueError("No bands available for stacking after applying descriptor ordering.")

        if not isinstance(bands, list):
            raise TypeError(
                f"Expected 'bands' to be a list, got {type(bands)}. Please provide a MultiSpectralDescriptor or "
                "ensure 'bands' is a list of strings."
            )
        if not isinstance(field_value, dict):
            raise TypeError(
                "Expected input field to be a dictionary with band keys, "
                f"but got {type(field_value)}. Please ensure the field contains band-specific data."
            )
        stacked_data = []
        for band in bands:
            if band in field_value:
                stacked_data.append(field_value[band])
            else:
                logger.warning(f"Band '{band}' not found in field. Skipping this band.")
        if not stacked_data:
            raise ValueError(
                f"No data found for bands {bands} in field. "
                "Please ensure the field contains data for the specified bands."
            )
        if isinstance(stacked_data[0], torch.Tensor):
            if stacked_data[0].shape[1] == 1:
                stacked_data = torch.cat(stacked_data, dim=1)
            else:
                stacked_data = torch.stack(stacked_data, dim=1)
        elif isinstance(stacked_data[0], np.ndarray):
            raise NotImplementedError("Not implemented yet.")
        elif isinstance(stacked_data[0], list):
            stacked_data = [x for x in stacked_data if x is not None]
        else:
            raise TypeError(
                f"Unsupported data type {type(stacked_data[0])} for field. "
                "Please ensure the field contains tensors, numpy arrays, or lists."
            )
        target = self.output_key if self.output_key is not None else self.field_key
        entry[target] = stacked_data
        # Preserve batch-wrapped format for bands list
        if isinstance(entry_bands_raw, list) and entry_bands_raw and isinstance(entry_bands_raw[0], list):
            entry[self.bands_list_key] = [bands for _ in entry_bands_raw]
        else:
            entry[self.bands_list_key] = bands
        return entry


StackMultispectralToEntry = register_class("StackMultispectralToEntry")(
    deprecated_class("StackMultispectralToEntry", StackBands)
)



@register_class
class RandomCrop(EntryTransform):
    """
    Randomly crops the images in the entry specified by the keys in the 'apply_to' list. The size of the crop is
    determined by the 'patch_size' parameter. If two specified images have different sizes, the given patch size is applied
    to the first image and the other images are cropped depending on the size ratio between the first image and the
    other images.

    Example: if the first image has size (100, 100) and the second image has size (200, 200), the first
    image will be cropped to (patch_size[0], patch_size[1]) and the second image will be cropped to
    (2 * patch_size[0], 2 * patch_size[1]).
    """

    def __init__(self, patch_size: Union[int, List[int]], *, field_key: str, output_key: Optional[str] = None):
        if isinstance(patch_size, int):
            patch_size = (patch_size, patch_size)
        if not (len(patch_size) == 2):
            raise ValueError(f"Argument 'patch_size' for the RandomCrop transformation must be a list of two"
                             f" integers. Got: {patch_size}")
        self.field_key = field_key
        self.output_key = output_key
        super().__init__()
        self.patch_size = patch_size

    def _extract_tensor(self, value: Any) -> torch.Tensor:
        if isinstance(value, torch.Tensor):
            return value
        if isinstance(value, list) and value:
            return self._extract_tensor(value[0])
        if isinstance(value, tuple) and value:
            return self._extract_tensor(value[0])
        if isinstance(value, dict) and value:
            return self._extract_tensor(next(iter(value.values())))
        raise TypeError(f"Unsupported value type for RandomCrop: {type(value)}")

    def transform(self, entry: Entry) -> Entry:
        samples = entry.unbatch()
        results = [self.transform_unbatched(s) for s in samples]
        return Entry.collate(results)

    def transform_unbatched(self, entry: Entry) -> Entry:
        value = entry[self.field_key]
        tensor = self._extract_tensor(value)
        start_i, start_j, h, w = transforms.RandomCrop.get_params(tensor, output_size=self.patch_size)
        target = self.output_key if self.output_key is not None else self.field_key
        entry[target] = self._crop_image(value, start_i, start_j, h, w)
        return entry

    def _crop_image(self, image: Any, start_i: int, start_j: int, h: int, w: int) -> Any:
        if isinstance(image, torch.Tensor):
            return crop(image, start_i, start_j, h, w)
        if isinstance(image, list):
            return [self._crop_image(x, start_i, start_j, h, w) for x in image]
        if isinstance(image, dict):
            return {key: self._crop_image(value, start_i, start_j, h, w) for key, value in image.items()}


@register_class
class RegisterEntry(EntryTransform): # TODO: Right now it only accepts lists of tensors. It should accept Tensor or list of Tensors. This is because right now multiple images are by default loaded as lists of tensors with no collation even if they are all the same shape.

    def __init__(self,
                 precision: str = 'int', mode: str = 'reflect',
                 adjust_translations_after_registration: bool = False,
                 *,
                 field_key: str,
                 translations_key: str):
        if precision not in ['int', 'float']:
            raise ValueError(f"Wrong registration mode! Selected: {precision}; Available: ['int'. 'float'].")
        self.field_key = field_key
        self.translations_key = translations_key
        super().__init__()
        self.precision = precision
        self.mode = mode
        self.adjust_translations_after_registration = adjust_translations_after_registration

    # def transform(self, entry: Entry) -> Entry:
    #     return self.transform_unbatched(entry)

    def transform_unbatched(self, entry: Entry) -> Entry:
        tr = entry[self.translations_key]
        if tr is None:
            raise ValueError(f"No translations calculated for LR images in {entry.name}!")
        if self.precision == 'int':
            if isinstance(tr, dict):
                tr = {k: np.round(v) for k, v in tr.items()}
            else:
                tr = np.round(tr)
        if self.adjust_translations_after_registration:
            if isinstance(tr, dict):
                entry[self.translations_key] = {k: entry[self.translations_key][k] - v for k, v in tr.items()}
            else:
                entry[self.translations_key] = entry[self.translations_key] - tr
        field_value = entry[self.field_key]
        if field_value is None:
            raise ValueError("Field value is None; cannot register.")
        def _to_numpy_translations(translations: Any, num_images: int) -> np.ndarray:
            if isinstance(translations, torch.Tensor):
                arr = translations.detach().cpu().numpy()
            else:
                arr = np.array(translations)
            if arr.ndim != 2 or arr.shape[0] != num_images or arr.shape[1] != 2:
                raise ValueError(
                    f"Translations must have shape (K, 2); got {arr.shape}."
                )
            return arr

        def _register_tensor(images: torch.Tensor, translations: Any) -> torch.Tensor:
            if images.dim() != 4:
                raise TypeError("Expected unbatched tensor of shape (C, K, H, W).")
            C, K = images.shape[0], images.shape[1]
            tr_np = _to_numpy_translations(translations, K)
            order = 0 if self.precision == 'int' else 3
            out = images.clone()
            for i in range(K):
                t = tr_np[i]
                if np.allclose(t, 0):
                    continue
                for j in range(C):
                    out[j, i] = torch.from_numpy(shift(images[j, i].numpy(), -t, mode=self.mode, order=order))
            return out

        if isinstance(field_value, dict):
            for band, images in field_value.items():
                band_tr = tr[band] if isinstance(tr, dict) else tr
                if isinstance(images, torch.Tensor):
                    field_value[band] = _register_tensor(images, band_tr)
                    continue
                if not all(images[0].shape == images[i].shape for i in range(1, len(images))):
                    raise ValueError(f"Different shapes of field.{band} images in {entry.name}!")
                order = 0 if self.precision == 'int' else 3
                t = band_tr.detach().cpu().numpy() if isinstance(band_tr, torch.Tensor) else np.array(band_tr)
                for i in range(len(images)):
                    if np.allclose(t[i], 0):
                        continue
                    for j in range(images[i].shape[0]):
                        x: torch.Tensor = images[i][j]
                        images[i][j] = torch.from_numpy(shift(x.numpy(), -t[i], mode=self.mode, order=order))
            return entry

        if isinstance(field_value, torch.Tensor):
            entry[self.field_key] = _register_tensor(field_value, tr)
            return entry

        if not all(field_value[0].shape == field_value[i].shape for i in range(1, len(field_value))):
            raise ValueError(f"Different shapes of field images in {entry.name}!")
        order = 0 if self.precision == 'int' else 3
        t = tr.detach().cpu().numpy() if isinstance(tr, torch.Tensor) else np.array(tr)
        for i in range(len(field_value)):
            if np.allclose(t[i], 0):
                continue
            for j in range(field_value[i].shape[0]):
                x: torch.Tensor = field_value[i][j]
                field_value[i][j] = torch.from_numpy(shift(x.numpy(), -t[i], mode=self.mode, order=order))
        return entry


@register_class
class CalculateTranslations(EntryTransform): # TODO: Right now it only accepts lists of tensors. It should accept Tensor or list of Tensors. This is because right now multiple images are by default loaded as lists of tensors with no collation even if they are all the same shape.
    """
    Calculates translations as vectors FROM the reference image TO the target and saves them in a corresponding Entry object.
    Parameters:
    ----------
    upsample_factor : int
        The upsampling factor for subpixel accuracy.
    use_masks : bool
        Whether to use masks for registration. If True, only full-pixel registration can be performed. The default is False.
    ref_index: int
        Reference index for registration. The default is 0.
    """

    def __init__(self,
                 upsample_factor: int = 100, use_masks: bool = False, ref_index: int = 0,
                 *,
                 field_key: str,
                 translations_key: str,
                 masks_key: Optional[str] = None,
                 leading_key: Optional[str] = None):
        self.field_key = field_key
        self.translations_key = translations_key
        self.masks_key = masks_key
        self.leading_key = leading_key
        super().__init__()
        self.upsample_factor = upsample_factor
        self.use_masks = use_masks
        self.ref_index = ref_index

    # def transform(self, entry: Entry):
    #     return self.transform_unbatched(entry)

    def transform_unbatched(self, entry: Entry):
        value = entry[self.field_key]
        masks_value = entry[self.masks_key] if self.use_masks and self.masks_key is not None else None
        leading_raw = entry[self.leading_key] if self.leading_key is not None else None
        leading_value = leading_raw[0] if isinstance(leading_raw, list) else leading_raw
        ref = 0 if leading_value else self.ref_index

        def _calc_for_list(images, masks):
            translations = []
            if self.use_masks:
                if not (masks is not None and all(x is not None for x in masks)):
                    raise ValueError(f"No masks provided for registration in {entry.name}.")
                if not (len(masks) == len(images)):
                    raise ValueError(f'Different number of images and masks in {entry.name}.')
                for i in range(len(images)):
                    shifts, *_ = phase_cross_correlation(
                        images[ref][0],
                        images[i][0],
                        reference_mask=masks[ref][0],
                        moving_mask=masks[i][0],
                        upsample_factor=self.upsample_factor
                    )
                    translations.append(-shifts)
            else:
                for i in range(len(images)):
                    shifts, *_ = phase_cross_correlation(
                        images[ref][0],
                        images[i][0],
                        upsample_factor=self.upsample_factor
                    )
                    translations.append(-shifts)
            return torch.from_numpy(np.stack(translations))

        def _calc_for_tensor(images: torch.Tensor, masks: Optional[torch.Tensor]) -> torch.Tensor:
            if images.dim() != 4:
                raise TypeError("Expected unbatched tensor of shape (C, K, H, W).")
            imgs_list = [images[:, i, ...] for i in range(images.shape[1])]
            masks_list = [masks[:, i, ...] for i in range(masks.shape[1])] if masks is not None else None
            return _calc_for_list(imgs_list, masks_list)

        if isinstance(value, dict):
            translations_dict = {}
            for band, images in value.items():
                band_masks = None
                if self.use_masks:
                    if isinstance(masks_value, dict):
                        band_masks = masks_value.get(band)
                    else:
                        band_masks = masks_value
                if isinstance(images, torch.Tensor):
                    translations_dict[band] = _calc_for_tensor(images, band_masks)
                else:
                    translations_dict[band] = _calc_for_list(images, band_masks)
            entry[self.translations_key] = translations_dict
            return entry

        if isinstance(value, torch.Tensor):
            translations = _calc_for_tensor(value, masks_value)
        else:
            translations = _calc_for_list(value, masks_value)
        entry[self.translations_key] = translations
        return entry




@register_class
class ChooseClearestImages(EntryTransform):
    """
    Chooses the clearest images from the list of low resolution images based on the mean of the clearance masks.
    """

    def __init__(self, num_images: int, *,
                 lrs_key: str,
                 masks_key: Optional[str] = None,
                 translations_key: Optional[str] = None,
                 leading_key: Optional[str] = None):
        self.lrs_key = lrs_key
        self.masks_key = masks_key
        self.translations_key = translations_key
        self.leading_key = leading_key
        super().__init__()
        self._num_images = num_images

    def _select_indices(self, lrs: list, lr_masks: Optional[list], leading_lr: bool) -> List[int]:
        if lr_masks is None:
            if not (len(lrs) == self._num_images):
                raise ValueError("No masks provided for registration, but number of images is different than requested.")
            return list(range(len(lrs)))
        clear_percentages = sorted([(mask.mean(), i) for i, mask in enumerate(lr_masks)],
                                   key=lambda x: x[0], reverse=True)
        num_images = min(self._num_images, len(clear_percentages))
        if not (len(clear_percentages) >= num_images):
            raise ValueError("Not enough images to choose from. {} images requested, but only {} available.".format(
                self._num_images, len(clear_percentages)))
        clear_percentages = clear_percentages[:num_images]
        clear_percentages = sorted(clear_percentages, key=lambda x: x[1])
        clear_indices = [x[1] for x in clear_percentages]
        if leading_lr and 0 not in clear_indices:
            clear_indices = [0] + clear_indices[:-1]
        return clear_indices

    def _select_indices_tensor(
        self,
        masks: Optional[torch.Tensor],
        batch_size: int,
        num_images: int,
        leading_lr: bool,
    ) -> List[List[int]]:
        if masks is None:
            if num_images != self._num_images:
                raise AssertionError(
                    "No masks provided for registration, but number of images is different than requested."
                )
            return [list(range(num_images)) for _ in range(batch_size)]

        dims = [i for i in range(masks.dim()) if i not in (0, 2)]
        means = masks.mean(dim=tuple(dims))  # (B, K)
        indices: List[List[int]] = []
        for b in range(means.shape[0]):
            order = sorted(range(means.shape[1]), key=lambda i: means[b, i].item(), reverse=True)
            chosen = sorted(order[:min(self._num_images, len(order))])
            if leading_lr and 0 not in chosen:
                chosen = [0] + chosen[:-1]
            indices.append(chosen)
        return indices

    @staticmethod
    def _gather_tensor_by_indices(values: torch.Tensor, indices: List[List[int]]) -> torch.Tensor:
        out = []
        for b, idx in enumerate(indices):
            idx_tensor = torch.as_tensor(idx, device=values.device)
            out.append(values[b:b + 1].index_select(2, idx_tensor))
        return torch.cat(out, dim=0)

    @staticmethod
    def _gather_translations(values: torch.Tensor, indices: List[List[int]]) -> torch.Tensor:
        out = []
        for b, idx in enumerate(indices):
            idx_tensor = torch.as_tensor(idx, device=values.device)
            out.append(values[b].index_select(0, idx_tensor))
        return torch.stack(out, dim=0)

    def transform(self, entry: Entry) -> Entry:
        return self.transform_unbatched(entry)

    def transform_unbatched(self, entry: Entry) -> Entry:
        leading_raw = entry[self.leading_key] if self.leading_key is not None else None
        if isinstance(leading_raw, list):
            leading = bool(leading_raw[0]) if leading_raw else False
        else:
            leading = bool(leading_raw) if leading_raw is not None else False
        lrs_val = entry[self.lrs_key]
        masks_val = entry[self.masks_key] if self.masks_key is not None else None
        translations_val = entry[self.translations_key] if self.translations_key is not None else None

        if isinstance(lrs_val, dict):
            new_lrs = {}
            new_masks = {} if isinstance(masks_val, dict) else None
            new_tr = {} if isinstance(translations_val, dict) else None
            for band, lrs in lrs_val.items():
                band_masks = None
                if isinstance(masks_val, dict):
                    band_masks = masks_val.get(band)
                if isinstance(lrs, torch.Tensor):
                    if band_masks is not None and not isinstance(band_masks, torch.Tensor):
                        raise TypeError("Masks must be a tensor when lrs is a tensor.")
                    indices = self._select_indices_tensor(
                        band_masks, lrs.shape[0], lrs.shape[2], leading
                    )
                    new_lrs[band] = self._gather_tensor_by_indices(lrs, indices)
                    if new_masks is not None and band_masks is not None:
                        new_masks[band] = self._gather_tensor_by_indices(band_masks, indices)
                    if new_tr is not None and translations_val is not None:
                        band_tr = translations_val.get(band)
                        if isinstance(band_tr, torch.Tensor):
                            new_tr[band] = self._gather_translations(band_tr, indices)
                        elif band_tr is not None:
                            new_tr[band] = [band_tr[0:1, i] for i in indices[0]]
                else:
                    band_indices = self._select_indices(lrs, band_masks, leading)
                    new_lrs[band] = [lrs[i] for i in band_indices]
                    if new_masks is not None and band_masks is not None:
                        new_masks[band] = [band_masks[i] for i in band_indices]
                    if new_tr is not None and translations_val is not None:
                        band_tr = translations_val.get(band)
                        if band_tr is not None:
                            new_tr[band] = [band_tr[0:1, i] for i in band_indices]
            entry[self.lrs_key] = new_lrs
            if self.masks_key is not None and new_masks is not None:
                entry[self.masks_key] = new_masks
            if self.translations_key is not None and new_tr is not None:
                entry[self.translations_key] = new_tr
            return entry

        if isinstance(lrs_val, torch.Tensor):
            if masks_val is not None and not isinstance(masks_val, torch.Tensor):
                raise TypeError("Masks must be a tensor when lrs is a tensor.")
            indices = self._select_indices_tensor(
                masks_val, lrs_val.shape[0], lrs_val.shape[2], leading
            )
            entry[self.lrs_key] = self._gather_tensor_by_indices(lrs_val, indices)
            if self.masks_key is not None and masks_val is not None:
                entry[self.masks_key] = self._gather_tensor_by_indices(masks_val, indices)
            if self.translations_key is not None and translations_val is not None and isinstance(translations_val, torch.Tensor):
                entry[self.translations_key] = self._gather_translations(translations_val, indices)
            return entry

        clear_indices = self._select_indices(lrs_val, masks_val, leading)
        entry[self.lrs_key] = [lrs_val[i] for i in clear_indices]
        if self.masks_key is not None and masks_val is not None:
            entry[self.masks_key] = [masks_val[i] for i in clear_indices]
        if self.translations_key is not None and translations_val is not None:
            entry[self.translations_key] = [translations_val[0:1, i] for i in clear_indices]
        return entry




@register_class
class RenameFields(EntryTransform):
    """
    An EntryTransform that renames fields in an Entry.
    The mapping is provided as a dictionary {source: target} such that
    Entry.source will be renamed to Entry.target.

    This implementation first collects all the source values and then updates
    the entry so that swapping fields is supported.
    """

    def __init__(self, *, field_key: str, output_key: str):
        self.field_key = field_key
        self.output_key = output_key
        super().__init__()

    def transform(self, entry: Entry) -> Entry:
        return self.transform_unbatched(entry)

    def transform_unbatched(self, entry: Entry) -> Entry:
        if self.field_key not in entry:
            return entry
        value = entry[self.field_key]
        entry[self.output_key] = value
        if self.output_key != self.field_key:
            del entry[self.field_key]

        return entry

@register_class
class RemoveFields(EntryTransform):
    """Remove one or more fields from an Entry.

    Args:
        field_key: A single field name or a list of field names to remove.
            Missing fields are silently skipped.
    """

    def __init__(self, *, field_key: Union[str, List[str]]):
        self.field_keys = [field_key] if isinstance(field_key, str) else list(field_key)
        super().__init__()

    def transform(self, entry: Entry) -> Entry:
        return self.transform_unbatched(entry)

    def transform_unbatched(self, entry: Entry) -> Entry:
        for key in self.field_keys:
            if key in entry:
                del entry[key]
        return entry

@register_class
class CopyFields(EntryTransform):
    """
    An EntryTransform that copies fields in an Entry.
    It creates a deep copy of each source field and writes it under the target name.
    The mapping is a dict { source_name: target_name }.
    """

    def __init__(self, *, field_key: str, output_key: str):
        self.field_key = field_key
        self.output_key = output_key
        super().__init__()

    def transform(self, entry: Entry) -> Entry:
        return self.transform_unbatched(entry)

    def transform_unbatched(self, entry: Entry) -> Entry:
        value = entry[self.field_key]
        entry[self.output_key] = copy.deepcopy(value)
        return entry


def _flatten_dict(d: dict, prefix: str, sep: str) -> dict:
    """Recursively flatten a nested dict, joining keys with *sep*."""
    items = {}
    for key, value in d.items():
        new_key = f"{prefix}{sep}{key}" if prefix else key
        if isinstance(value, dict):
            items.update(_flatten_dict(value, new_key, sep))
        else:
            items[new_key] = value
    return items


@register_class
class FlattenDict(EntryTransform):
    """Recursively unpacks a (nested) dict field into top-level Entry fields.

    Keys at every nesting level are joined with ``sep`` (default ``"_"``)
    to form flat field names. By default the original field name is used as
    the root prefix, so the resulting names read naturally as a path through
    the nested structure.

    Args:
        prefix: If set, replaces the field name as the root prefix.
            Use ``prefix=""`` to omit the root prefix entirely (only inner
            keys are joined).
        sep: Separator between key segments. Default ``"_"``.
        field_key: Entry field name holding the dict to flatten.

    Example — default (field name as prefix)::

        # Entry: {"meta": {"sensor": {"name": "S2", "res": 10}, "date": "2024"}}
        # field_key="meta"
        # Result: {"meta_sensor_name": "S2", "meta_sensor_res": 10, "meta_date": "2024"}

    Example — custom prefix::

        # FlattenDict(prefix="info", field_key="meta")
        # Result: {"info_sensor_name": "S2", "info_sensor_res": 10, "info_date": "2024"}

    Example — no prefix::

        # FlattenDict(prefix="", field_key="meta")
        # Result: {"sensor_name": "S2", "sensor_res": 10, "date": "2024"}
    """

    def __init__(self, prefix: str = None, sep: str = "_", *, field_key: str):
        self.field_key = field_key
        super().__init__()
        self.prefix = prefix
        self.sep = sep

    def transform(self, entry: Entry) -> Entry:
        return self.transform_unbatched(entry)

    def transform_unbatched(self, entry: Entry) -> Entry:
        if self.field_key not in entry:
            return entry
        value = entry[self.field_key]
        if not isinstance(value, dict):
            raise TypeError(
                f"FlattenDict expected a dict for field '{self.field_key}', "
                f"got {type(value).__name__}"
            )
        root = self.prefix if self.prefix is not None else self.field_key
        flat = _flatten_dict(value, root, self.sep)
        for key, val in flat.items():
            entry[key] = val
        del entry[self.field_key]
        return entry


@register_class
class SetLeading(EntryTransform):

    def __init__(self, idx: int, *, lrs_key: str, leading_key: str):
        self.lrs_key = lrs_key
        self.leading_key = leading_key
        super().__init__()
        self.idx = idx

    def transform(self, entry: Entry) -> Entry:
        return self.transform_unbatched(entry)

    def transform_unbatched(self, entry: Entry) -> Entry:
        leading_val = entry.get(self.leading_key, [False])
        is_set = leading_val[0] if isinstance(leading_val, list) else leading_val
        if is_set:
            raise ValueError("Leading LR image already set.")
        entry[self.leading_key] = [True] * len(leading_val) if isinstance(leading_val, list) else [True]
        lrs_val = entry[self.lrs_key]
        if isinstance(lrs_val, torch.Tensor) and lrs_val.dim() >= 5:
            tmp = lrs_val[:, :, 0].clone()
            lrs_val[:, :, 0] = lrs_val[:, :, self.idx]
            lrs_val[:, :, self.idx] = tmp
            entry[self.lrs_key] = lrs_val
        else:
            entry[self.lrs_key][0], entry[self.lrs_key][self.idx] = entry[self.lrs_key][self.idx], entry[self.lrs_key][0]
        return entry


# Backward compatibility — these moved to srforge.transform.data
from srforge.transform.data import ResizeFieldsToReference, ChooseImages

