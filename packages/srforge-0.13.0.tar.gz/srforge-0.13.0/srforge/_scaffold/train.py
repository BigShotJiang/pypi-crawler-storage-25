import os
os.environ["C10D_TCP_STORE_USE_LIBUV"] = "0"
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"

import logging
import hydra
import omegaconf

from srforge import GlobalSettings, init

logger = logging.getLogger(__name__)
from srforge.data.loader import DataLoaderFactory
from srforge.utils.checkpoint import resume_from_checkpoint
from srforge.utils.multigpu import setup_device


@hydra.main(config_path="configs", config_name="train-cfg", version_base=None)
def main(cfg) -> None:
    resolve = init(cfg, log_level=cfg.system.debug_level)
    settings = GlobalSettings()

    # -- Model & training objects -----------------------------------------
    model     = resolve(cfg.model)
    loss      = resolve(cfg.loss)
    optimizer = resolve(cfg.optimizer)
    scheduler = resolve(cfg.lr_scheduler)

    # -- Datasets & device ------------------------------------------------
    train_dataset = resolve(cfg.dataset.training)
    val_dataset   = resolve(cfg.dataset.validation)

    model, device = setup_device(model, cfg.system.device, train_dataset)

    train_loader = DataLoaderFactory(
        train_dataset, batch_size=cfg.training.batch_size, shuffle=True,
        num_workers=cfg.training.num_workers, device=cfg.system.device,
        pin_memory_device=str(device), pin_memory=True,
    ).get_loader()
    val_loader = DataLoaderFactory(
        val_dataset, batch_size=1, shuffle=False,
        num_workers=0, device=cfg.system.device,
        pin_memory_device=str(device), pin_memory=True,
    ).get_loader()

    # -- Trainer & sanity check -------------------------------------------
    trainer = resolve(cfg.trainer)
    trainer.sanity_check(train_loader, val_loader)

    # -- Tracking (only after sanity check passes) ------------------------
    tracker = resolve(cfg.tracker)
    tracker.log_config(omegaconf.OmegaConf.to_container(cfg, resolve=False))

    # -- Resume from checkpoint -------------------------------------------
    ckpt = resume_from_checkpoint(model, optimizer, scheduler, tracker=tracker)
    if ckpt is not None:
        logger.info(f'Resumed from epoch {ckpt.epoch + 1}')
    trainer.restore(ckpt)

    # -- Observers --------------------------------------------------------
    observers = resolve(cfg.observers)
    settings.event_bus.subscribe(observers)

    # -- Train ------------------------------------------------------------
    tracker.watch_model(model, log='all', log_graph=True,
                        log_freq=len(train_loader), criterion=loss)

    trainer.train(cfg.training.epochs, train_loader, val_loader)

    tracker.finish(0)


if __name__ == "__main__":
    main()
