import os
from srforge.registry import ClassRegistry
import logging
from importlib.metadata import version, PackageNotFoundError

try:
    __version__ = version("srforge")
except PackageNotFoundError:
    __version__ = "0+local"

logger = logging.getLogger(__name__)

class Singleton(type):
    """Metaclass implementing the Singleton pattern.

    Ensures only one instance of a class exists throughout the application.

    Attributes:
        _instances: Dictionary mapping classes to their singleton instances.
    """
    _instances = {}
    def __call__(cls, *args, **kwargs):
        if cls not in cls._instances:
            cls._instances[cls] = super().__call__(*args, **kwargs)
        return cls._instances[cls]

class GlobalSettings(metaclass=Singleton):
    """Application-wide settings manager.

    Provides centralized access to global configuration using the Singleton pattern.
    Must be initialized via :func:`srforge.init` before use.

    Attributes:
        debug_mode: Enable verbose debugging output.
        output_directory: Root directory for outputs (models, logs, visualizations).
        config: Reference to the main configuration object.
        tracker: Active experiment tracker (set by tracker init).
        event_bus: Global event bus for observer communication.
    """

    _INTERNAL_ATTRS = {'_initialized', 'debug_mode', 'output_directory',
                       'config', 'tracker', 'event_bus'}

    def __init__(self):
        """Initialize default settings."""
        super().__setattr__('_initialized', False)
        self.debug_mode = False
        self.output_directory = 'output'
        self.config = None
        self.tracker = None
        from srforge.observers.bus import EventBus
        self.event_bus = EventBus()

    def __getattr__(self, key):
        if key.startswith('_'):
            raise AttributeError(key)
        if not self._initialized:
            raise RuntimeError(
                f"GlobalSettings not initialized. Call srforge.init() before "
                f"accessing '{key}'."
            )
        raise AttributeError(f"'{type(self).__name__}' has no attribute '{key}'")

    def __setattr__(self, key, value):
        super().__setattr__(key, value)

ClassRegistry().discover(__name__)


def init(cfg, *, log_level=logging.INFO) -> "ConfigResolver":
    """One-call framework setup for Hydra-based scripts.

    Performs the boilerplate that every script needs:

    1. Configures the global logger with colored output.
    2. Strips internal config keys (``clear_defaults``).
    3. Wires :class:`GlobalSettings` (config, output directory).
    4. Creates and returns a :class:`ConfigResolver`.

    Everything config-structure-dependent (tracker, observers, device)
    is left to the caller.

    Args:
        cfg: An OmegaConf ``DictConfig`` from ``@hydra.main``.
        log_level: Logging level (default: ``logging.INFO``).

    Returns:
        A :class:`~srforge.config.ConfigResolver` bound to *cfg*.
    """
    from hydra.core.hydra_config import HydraConfig

    from srforge.config import ConfigResolver
    from srforge.config.utils import clear_defaults
    from srforge.utils.logging import configure_logger

    configure_logger(log_level)

    # Install signal handlers for hard-kill on Ctrl+C.
    # DataLoader workers and MKL/Fortran threads on Windows don't respond
    # to graceful SIGINT, causing hangs. os._exit bypasses all of them.
    import signal
    import atexit

    def _force_exit(signum=None, frame=None):
        try:
            tracker = GlobalSettings().tracker
            if tracker is not None:
                tracker.finish(1)
        except Exception:
            pass
        try:
            from rich.console import Console
            Console(force_terminal=True).print("\n[bold yellow]⚠ Interrupted[/bold yellow]")
        except Exception:
            print("\nInterrupted")
        os._exit(1)

    signal.signal(signal.SIGINT, _force_exit)
    # Windows also sends SIGBREAK for Ctrl+C in some console configurations
    if hasattr(signal, 'SIGBREAK'):
        signal.signal(signal.SIGBREAK, _force_exit)

    try:
        import sys as _sys
        from rich.console import Console
        from rich.panel import Panel
        from rich.align import Align
        console = Console(force_terminal=True)
        title = "⚡ SR-Forge" if _sys.stdout.isatty() else "SR-Forge"
        console.print(Panel(
            Align.center(f"[bold color(220)]{title}[/bold color(220)]"),
            subtitle="Deep Learning Training Framework",
            style="dim",
            width=42,
        ))
    except ImportError:
        print("=== SR-Forge ===")

    clear_defaults(cfg)
    settings = GlobalSettings()
    settings._initialized = True
    settings.config = cfg
    settings.output_directory = HydraConfig.get().runtime.output_dir
    return ConfigResolver(cfg)