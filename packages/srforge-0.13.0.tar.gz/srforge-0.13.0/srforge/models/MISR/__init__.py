from .TRMISR import TRMISR
from .RAMS import RAMS

try:
    from .MagNAt import MagNAt
except ImportError:
    pass
