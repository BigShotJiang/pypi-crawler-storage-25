"""Standardized checkpoint save/load utilities."""

from __future__ import annotations

import logging
import os
import random
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Callable, Union

import numpy as np
import torch

if TYPE_CHECKING:
    from srforge.models import Model, SequentialModel
    from srforge.tracking.base import ExperimentTracker

logger = logging.getLogger(__name__)

CHECKPOINT_VERSION = 1


@dataclass
class CheckpointState:
    """Contents of a loaded training checkpoint."""

    checkpoint_version: int
    epoch: int
    best_losses: dict | None
    lr_scheduler_state: dict
    rng_states: dict | None
    runner_state: dict | None = None

    _DEPRECATED_FIELDS = {"optimizer_state", "scaler_state",
                          "optimizer_D_state", "scaler_D_state"}

    def __getattr__(self, name: str):
        if name in self._DEPRECATED_FIELDS:
            import warnings
            warnings.warn(
                f"Accessing 'ckpt.{name}' is deprecated. "
                f"Use 'ckpt.runner_state' dict instead.",
                DeprecationWarning,
                stacklevel=2,
            )
            # Map old names to runner_state keys
            key = name.replace("_state", "")  # optimizer_state -> optimizer
            if self.runner_state is not None:
                return self.runner_state.get(key)
            return None
        raise AttributeError(f"'{type(self).__name__}' has no attribute '{name}'")


# ── RNG helpers ───────────────────────────────────────────────────────


def _capture_rng_states() -> dict:
    """Snapshot all RNG states for reproducibility."""
    states = {
        "python": random.getstate(),
        "numpy": np.random.get_state(),
        "torch_cpu": torch.random.get_rng_state(),
        "torch_cuda": [],
    }
    if torch.cuda.is_available():
        states["torch_cuda"] = torch.cuda.get_rng_state_all()
    return states


def _restore_rng_states(rng_states: dict) -> None:
    """Restore all RNG states from a checkpoint."""
    random.setstate(rng_states["python"])
    np.random.set_state(rng_states["numpy"])
    torch.random.set_rng_state(rng_states["torch_cpu"])
    if torch.cuda.is_available() and rng_states.get("torch_cuda"):
        torch.cuda.set_rng_state_all(rng_states["torch_cuda"])


# ── Training checkpoint ──────────────────────────────────────────────

def save_checkpoint(
    path: str,
    *,
    epoch: int,
    runner_state: dict = None,
    lr_scheduler: Any,
    best_loss: float | None,
    # Deprecated params — use runner_state instead:
    optimizer: Any = None,
    scaler: Any = None,
) -> None:
    """Save a standardized training checkpoint to *path*.

    Args:
        path: File path to save.
        epoch: Completed epoch number.
        runner_state: Opaque dict from ``runner.training_state()``.
        lr_scheduler: LR scheduler instance.
        best_loss: Current best validation loss (for summary tracking).
        optimizer: **Deprecated** — pass ``runner_state`` instead.
        scaler: **Deprecated** — pass ``runner_state`` instead.
    """
    if runner_state is None and optimizer is not None:
        import warnings
        warnings.warn(
            "save_checkpoint() 'optimizer'/'scaler' params are deprecated. "
            "Pass 'runner_state' dict instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        runner_state = {"optimizer": optimizer.state_dict()}
        if scaler is not None and getattr(scaler, "_enabled", False):
            runner_state["scaler"] = scaler.state_dict()
    torch.save(
        {
            "checkpoint_version": CHECKPOINT_VERSION,
            "epoch": epoch,
            "best_losses": {"total": best_loss} if best_loss is not None else None,
            "runner_state": runner_state,
            "lr_scheduler": lr_scheduler.state_dict(),
            "rng_states": _capture_rng_states(),
        },
        path,
    )


def load_checkpoint(path: str) -> CheckpointState:
    """Load a training checkpoint from *path*.

    Handles both the current versioned format and legacy checkpoints
    (pre-version) by detecting the ``checkpoint_version`` key.
    """
    data = torch.load(path, map_location="cpu", weights_only=False)

    version = data.get("checkpoint_version", 0)

    # Support both new (runner_state) and legacy (optimizer/scaler) formats.
    if "runner_state" in data:
        runner_state = data["runner_state"]
    else:
        import warnings
        warnings.warn(
            "Loading a legacy checkpoint with flat optimizer/scaler fields. "
            "Future checkpoints use 'runner_state' dict. Re-save to upgrade.",
            DeprecationWarning,
            stacklevel=2,
        )
        runner_state = {"optimizer": data["optimizer"]}
        if data.get("scaler"):
            runner_state["scaler"] = data["scaler"]
        if data.get("optimizer_D"):
            runner_state["optimizer_D"] = data["optimizer_D"]
        if data.get("scaler_D"):
            runner_state["scaler_D"] = data["scaler_D"]

    return CheckpointState(
        checkpoint_version=version,
        epoch=data["epoch"],
        best_losses=data.get("best_losses"),
        lr_scheduler_state=data["lr_scheduler"],
        rng_states=data.get("rng_states"),
        runner_state=runner_state,
    )


def resume_from_checkpoint(
    model: Any,
    runner: Any,
    lr_scheduler: Any,
    tracker: "ExperimentTracker | None" = None,
) -> CheckpointState | None:
    """Restore training state from the last checkpoint if the run was resumed.

    When the *tracker* reports ``is_resumed``, this function:

    1. Loads the training checkpoint (runner state, scheduler, RNG states).
    2. Loads model weights for every sub-model.
    3. Restores runner state via ``runner.load_training_state()``.
    4. Restores RNG states for exact reproducibility.

    When the run is **not** resumed (or *tracker* is ``None``), returns
    ``None``.

    The returned :class:`CheckpointState` is then passed to
    ``trainer.restore(ckpt)`` to finalize epoch/best-loss wiring.

    Args:
        model: The model to load weights into.
        runner: Training runner exposing ``load_training_state(state)``.
        lr_scheduler: LR scheduler whose ``state_dict`` will be restored.
        tracker: Experiment tracker that provides checkpoint files.
            Defaults to :class:`~srforge.tracking.NullTracker` if not provided.

    Returns:
        A :class:`CheckpointState` when resuming, or ``None`` otherwise.
    """
    if tracker is None:
        from srforge.tracking import NullTracker
        tracker = NullTracker()

    # Detect legacy call: optimizer passed instead of runner
    if isinstance(runner, torch.optim.Optimizer):
        import warnings
        warnings.warn(
            "resume_from_checkpoint() now expects a runner (with "
            "load_training_state method) instead of an optimizer. "
            "Pass the training runner instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        # Wrap optimizer in a minimal adapter
        _opt = runner
        class _LegacyAdapter:
            def load_training_state(self, state):
                _opt.load_state_dict(state.get("optimizer", state))
        runner = _LegacyAdapter()

    if not tracker.is_resumed:
        return None

    ckpt = load_checkpoint(tracker.restore_file("checkpoint_last.pth"))
    if ckpt.runner_state is not None:
        runner.load_training_state(ckpt.runner_state)
    lr_scheduler.load_state_dict(ckpt.lr_scheduler_state)

    load_model_weights(model, tracker.restore_file, suffix="_last")

    if ckpt.rng_states is not None:
        _restore_rng_states(ckpt.rng_states)

    logger.info(f"Resumed from epoch {ckpt.epoch} (continuing at {ckpt.epoch + 1}).")
    return ckpt


# ── Model weights ────────────────────────────────────────────────────


def _unwrap_model(model: Any) -> list:
    """Unwrap DataParallel / SequentialModel into a list of plain Models."""
    from srforge.models import Model, SequentialModel

    try:
        from torch_geometric.nn import DataParallel as tgDataParallel
    except ImportError:
        tgDataParallel = None

    dp_types = (torch.nn.DataParallel,)
    if tgDataParallel is not None:
        dp_types = (tgDataParallel, torch.nn.DataParallel)

    if isinstance(model, dp_types):
        model = model.module

    from srforge.models import GANModel
    if isinstance(model, GANModel):
        return [model.generator, model.discriminator]
    elif isinstance(model, SequentialModel):
        return list(model.models.values())
    elif isinstance(model, Model):
        return [model]
    else:
        raise TypeError(f"Unsupported model type: {type(model)}")


def save_model_weights(
    model: Any,
    output_dir: str,
    suffix: str,
) -> list[str]:
    """Save model state dicts to *output_dir*. Returns saved file paths.

    Handles DataParallel wrappers and SequentialModel by saving each
    sub-model individually as ``{name}{suffix}.pth``.
    """
    paths = []
    for m in _unwrap_model(model):
        out_path = os.path.join(output_dir, f"{m.name}{suffix}.pth")
        torch.save(m.state_dict(), out_path)
        paths.append(out_path)
    return paths


def load_model_weights(
    model: Any,
    load_fn: Callable[[str], str],
    suffix: str = "_last",
) -> None:
    """Load model weights using a file-fetching callable.

    Args:
        model: Model or SequentialModel to load weights into.
        load_fn: Callable that takes a filename and returns a local path
                 (e.g. ``tracker.restore_file``).
        suffix: ``"_last"`` or ``"_best"``.
    """
    for m in _unwrap_model(model):
        local_path = load_fn(f"{m.name}{suffix}.pth")
        state = torch.load(local_path, map_location="cpu", weights_only=True)
        m.load_state_dict(state)
        logger.info(f"Loaded weights for '{m.name}' from '{local_path}'.")


# ── Cross-run loading ────────────────────────────────────────────────


def load_weights_from_tracker(
    module: torch.nn.Module,
    tracker: ExperimentTracker,
    run_id: str,
    module_name: str | None = None,
    best: bool = True,
) -> torch.nn.Module:
    """Load weights for a module from a different run via the tracker.

    Args:
        module: Module to load weights into.
        tracker: Tracker instance with ``restore_from_run`` support.
        run_id: Source run identifier.
        module_name: Weight file stem. Defaults to ``module.__class__.__name__``.
        best: If True, load ``_best.pth``; otherwise ``_last.pth``.

    Returns:
        The module with loaded weights.
    """
    if module_name is None:
        module_name = module.__class__.__name__
    suffix = "_best" if best else "_last"
    filename = f"{module_name}{suffix}.pth"

    local_path = tracker.restore_from_run(run_id, filename)
    state = torch.load(local_path, map_location="cpu", weights_only=True)
    os.remove(local_path)
    module.load_state_dict(state)
    logger.info(f"Loaded weights from '{filename}' for run {run_id}.")
    return module


# ── Legacy wandb utilities (deprecated) ──────────────────────────────


def load_weights_from_wandb(
    module: torch.nn.Module,
    project: str,
    entity: str,
    run_id: str,
    module_name: str | None = None,
    load_best_model: bool = True,
) -> torch.nn.Module:
    """Load weights from a W&B run.

    .. deprecated::
        Use :func:`load_weights_from_tracker` with a tracker instance instead.
    """
    import warnings

    import wandb

    warnings.warn(
        "load_weights_from_wandb is deprecated; use load_weights_from_tracker instead.",
        DeprecationWarning,
        stacklevel=2,
    )
    if module_name is None:
        module_name = module.__class__.__name__
    filename = f"{module_name}_best.pth" if load_best_model else f"{module_name}_last.pth"

    run = wandb.Api().run(f"{entity}/{project}/{run_id}")
    file = run.file(filename).download(replace=True).name
    state = torch.load(file, map_location="cpu", weights_only=True)
    os.remove(file)
    module.load_state_dict(state)
    logger.info(f"Loaded weights from '{filename}' for run {run_id}.")
    return module


def get_model_from_wandb(
    model_name: str,
    run_id: str,
    project: str,
    entity: str,
    load_best_model: bool,
    target_class: str | None = None,
) -> torch.nn.Module:
    """Load a model from W&B (config + weights).

    .. deprecated::
        Use :func:`load_weights_from_tracker` with a locally-instantiated model.
    """
    import warnings

    import omegaconf
    import wandb

    from srforge.config import ConfigResolver

    warnings.warn(
        "get_model_from_wandb is deprecated; instantiate the model locally "
        "and use load_weights_from_tracker instead.",
        DeprecationWarning,
        stacklevel=2,
    )

    run = wandb.Api().run(f"{entity}/{project}/{run_id}")
    config = omegaconf.OmegaConf.create(run.config)

    if target_class is not None:
        logger.info(
            f"Instantiating '{target_class}' instead of config's "
            f"{config.model._target}."
        )
        config.model._target = target_class

    resolve = ConfigResolver(config)
    model = resolve(config.model)

    filename = f"{model_name}_best.pth" if load_best_model else f"{model_name}_last.pth"
    file = run.file(filename).download(replace=True).name
    state = torch.load(file, map_location="cpu", weights_only=True)
    os.remove(file)
    model.load_state_dict(state)
    logger.info(f"Loaded weights from '{filename}' for run '{run.name}' (ID: {run_id}).")
    return model
