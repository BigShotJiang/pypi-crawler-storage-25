"""Decorator for marking classes and functions as experimental."""
import warnings
from functools import wraps


class ExperimentalWarning(FutureWarning):
    """Warning for experimental features that may change without notice."""


def experimental(cls_or_func):
    """Mark a class or function as experimental.

    Experimental APIs may change or be removed in future versions without
    following the standard deprecation cycle.

    When applied to a class, a warning is issued on instantiation.
    When applied to a function, a warning is issued on each call.
    """
    if isinstance(cls_or_func, type):
        return _experimental_class(cls_or_func)
    return _experimental_func(cls_or_func)


def _experimental_class(cls):
    original_init = cls.__init__

    @wraps(original_init)
    def new_init(self, *args, **kwargs):
        warnings.warn(
            f"{cls.__name__} is experimental and may change without notice.",
            ExperimentalWarning,
            stacklevel=2,
        )
        original_init(self, *args, **kwargs)

    cls.__init__ = new_init
    tag = "**Experimental** — this API may change or be removed without notice.\n\n"
    if cls.__doc__:
        cls.__doc__ = tag + cls.__doc__
    else:
        cls.__doc__ = tag.strip()
    return cls


def _experimental_func(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        warnings.warn(
            f"{func.__qualname__} is experimental and may change without notice.",
            ExperimentalWarning,
            stacklevel=2,
        )
        return func(*args, **kwargs)

    tag = "**Experimental** — this API may change or be removed without notice.\n\n"
    if wrapper.__doc__:
        wrapper.__doc__ = tag + wrapper.__doc__
    else:
        wrapper.__doc__ = tag.strip()
    return wrapper
