import logging
import sys
from typing import Union


def configure_logger(level: Union[str, int] = logging.INFO):
    """Configure the global logger with rich formatting.

    For INFO and above, uses rich's clean rendering with short format.
    For DEBUG, uses verbose format with module paths and line numbers.
    """
    if isinstance(level, str):
        level = getattr(logging, level.upper(), logging.INFO)

    logger = logging.getLogger()
    logger.setLevel(level)

    if logger.hasHandlers():
        logger.handlers.clear()

    try:
        from rich.logging import RichHandler
        from rich.console import Console

        from rich.highlighter import RegexHighlighter, NullHighlighter
        from rich.theme import Theme

        class SrForgeHighlighter(RegexHighlighter):
            """Highlight numbers, paths, and key-value patterns in log messages."""
            base_style = "srforge."
            highlights = [
                r"(?P<number>\b\d+\.?\d*\b)",           # numbers: 7264, 0.001, 16383.0
                r"(?P<key>\b\w+)(?=\s*[:=])",           # keys before : or =
                r"(?P<path>[A-Z]:[/\\][\w/\\.:-]+)",    # Windows paths
                r"(?P<path>/[\w/\\.:-]+)",               # Unix paths
                r"(?P<device>cuda:\d+|cpu)",             # device strings
                r"(?P<bool>True|False)",                 # booleans
            ]

        is_tty = sys.stdout.isatty()
        if is_tty:
            theme = Theme({
                "srforge.number": "bold cyan",
                "srforge.key": "color(220)",
                "srforge.path": "dim italic",
                "srforge.device": "bold green",
                "srforge.bool": "italic magenta",
                "logging.level.info": "dim cyan",
                "logging.level.warning": "bold yellow",
                "logging.level.error": "bold red",
                "logging.level.debug": "dim",
            })
        else:
            theme = Theme({
                "log.message": "green",
                "logging.level.info": "green",
                "logging.level.warning": "bold yellow",
                "logging.level.error": "bold red",
                "logging.level.debug": "dim",
            })
        console = Console(force_terminal=True, stderr=False, theme=theme)

        highlighter = SrForgeHighlighter() if is_tty else NullHighlighter()

        if level <= logging.DEBUG:
            handler = RichHandler(
                console=console,
                show_time=True,
                show_path=True,
                show_level=True,
                rich_tracebacks=True,
                markup=False,
                highlighter=highlighter,
            )
        else:
            handler = RichHandler(
                console=console,
                show_time=False,
                show_path=False,
                show_level=False,
                rich_tracebacks=True,
                markup=False,
                highlighter=highlighter,
                keywords=[],
            )
        handler.setLevel(level)
        logger.addHandler(handler)

    except ImportError:
        # Fallback to colorlog if rich is not available
        import colorlog

        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setLevel(level)

        if level <= logging.DEBUG:
            fmt = '%(log_color)s%(asctime)s - %(name)s - %(funcName)s - %(levelname)s - %(filename)s:%(lineno)d - %(message)s'
        else:
            fmt = '%(log_color)s%(message)s'

        formatter = colorlog.ColoredFormatter(
            fmt,
            log_colors={
                'DEBUG': 'cyan',
                'INFO': 'green',
                'WARNING': 'yellow',
                'ERROR': 'red',
                'CRITICAL': 'bold_red',
            },
            secondary_log_colors={},
            style='%'
        )
        console_handler.setFormatter(formatter)
        logger.addHandler(console_handler)