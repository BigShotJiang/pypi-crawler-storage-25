import time
from typing import Any

import torch

import srforge.events.trainer
from srforge.loss import MetricScores
from srforge.registry import register_class
from .base import Observer
from srforge.events import runner as runner_events


@register_class
class LossLogger(Observer):
    """Observer that logs training and validation losses after each epoch.

    Args:
        tracker: Experiment tracker for logging metrics.
            Defaults to :class:`~srforge.tracking.NullTracker` if not provided.
    """

    EVENTS = [srforge.events.trainer.TrainerEpochFinished]

    def __init__(self, tracker: "ExperimentTracker | None" = None, **kwargs):
        super().__init__(**kwargs)
        if tracker is None:
            from srforge.tracking import NullTracker
            tracker = NullTracker()
        self.tracker = tracker

    def on_epoch_finished(self, event: srforge.events.trainer.TrainerEpochFinished) -> None:
        val_loss = event.val_loss.as_summary_dict()
        train_loss = event.train_loss.as_summary_dict()
        lr = {i: pg["lr"] for i, pg in enumerate(event.lr_scheduler.optimizer.param_groups)}
        self.tracker.log_metrics(
            {
                "validation_loss": val_loss,
                "training_loss": train_loss,
                "epoch": event.epoch,
                "learning_rate": lr,
            },
            step=event.epoch,
        )
        self.tracker.commit(step=event.epoch)


@register_class
class ProgressBar(Observer):
    """Observer that renders a progress bar using rich, with aggressive
    clearing to handle terminal resize on Windows.

    On each tick, clears up to ``_CLEAR_LINES`` lines above the cursor
    before letting rich re-render at the current terminal width. This
    wipes ghost lines left by OS-level text reflow after resize.
    """

    EVENTS = [runner_events.RunnerEpochStarted, runner_events.RunnerBatchFinished, runner_events.RunnerEpochFinished]

    def __init__(self, name: str, **kwargs):
        super().__init__(**kwargs)
        self._name = name
        self._sig_digits = 5
        self._progress = None
        self._console = None
        self._task_id = None
        self._is_tty = None
        self._started = False
        self._prev_rendered_lines = 1

        self._sum: dict[str, torch.Tensor] = {}
        self._count: int = 0

    @staticmethod
    def _clear_region(n_lines: int):
        """Move cursor up n_lines, clearing each line (TTY only)."""
        import sys
        for _ in range(n_lines):
            sys.stdout.write('\033[A\033[2K')
        sys.stdout.write('\r')
        sys.stdout.flush()

    def on_epoch_started(self, event: runner_events.RunnerEpochStarted):
        import sys
        from rich.progress import Progress, BarColumn, TextColumn, TimeElapsedColumn, TimeRemainingColumn, SpinnerColumn, ProgressColumn, Task
        from rich.text import Text
        from rich.console import Console

        class IterSpeedColumn(ProgressColumn):
            """Show seconds/iteration or iterations/second depending on speed."""
            def render(self, task: Task) -> Text:
                speed = task.finished_speed or task.speed
                if speed is None:
                    return Text("-s/it", style="progress.data.speed")
                if speed >= 1:
                    return Text(f"{speed:.1f}it/s", style="progress.data.speed")
                return Text(f"{1/speed:.2f}s/it", style="progress.data.speed")

        self._is_tty = sys.stdout.isatty()
        prefix = f"{self._name}({str(event.epoch).zfill(4)})"

        self._console = Console(force_terminal=True)
        from rich.progress import MofNCompleteColumn

        self._progress = Progress(
            SpinnerColumn(),
            TextColumn("[bold]{task.description}"),
            BarColumn(bar_width=None),
            MofNCompleteColumn(),
            TextColumn("[progress.percentage]{task.percentage:>3.1f}%"),
            TimeElapsedColumn(),
            TextColumn("ETA"),
            TimeRemainingColumn(),
            IterSpeedColumn(),
            TextColumn("{task.fields[loss]}"),
            console=self._console,
            auto_refresh=False,
            expand=True,
        )
        self._task_id = self._progress.add_task(prefix, total=event.num_batches, loss="")
        self._started = False
        self._sum = {}
        self._count = 0
        self._render()

    def _render(self):
        """Clear previous output and render the progress bar fresh."""
        import sys

        if self._is_tty:
            # Real terminal: use ANSI cursor control for in-place update
            if self._started:
                self._clear_region(self._prev_rendered_lines)
            self._started = True

            with self._console.capture() as capture:
                self._console.print(self._progress.get_renderable())
            text = capture.get()
            self._prev_rendered_lines = max(1, text.count('\n'))
            sys.stdout.write(text)
            sys.stdout.flush()
        else:
            # Non-TTY (e.g. PyCharm console): use \r with ANSI colors
            self._started = True
            task = self._progress.tasks[0]
            pct = f"{task.percentage:.1f}%"
            speed = task.speed
            if speed is None:
                speed_str = ""
            elif speed >= 1:
                speed_str = f"{speed:.1f}it/s"
            else:
                speed_str = f"{1/speed:.2f}s/it"
            elapsed = task.elapsed
            elapsed_str = time.strftime("%H:%M:%S", time.gmtime(elapsed)) if elapsed else "0:00:00"
            remaining = task.time_remaining
            eta_str = time.strftime("%H:%M:%S", time.gmtime(remaining)) if remaining else "-:--:--"
            loss = task.fields.get("loss", "")
            completed = int(task.completed)
            total = int(task.total)

            # ANSI color codes
            BOLD = '\033[1m'
            CYAN = '\033[36m'
            YELLOW = '\033[33m'
            GREEN = '\033[32m'
            DIM = '\033[2m'
            RST = '\033[0m'

            line = (
                f"\r{BOLD}{task.description}{RST} "
                f"{CYAN}{completed}/{total}{RST} "
                f"{GREEN}{pct}{RST} "
                f"{DIM}[{YELLOW}{elapsed_str}{RST}{DIM}<{YELLOW}{eta_str}{RST} "
                f"{CYAN}{speed_str}{RST}{DIM}]{RST} "
                f"{loss}"
            )
            sys.stdout.write(line + '\033[K')
            sys.stdout.flush()

    def on_batch_finished(self, event: runner_events.RunnerBatchFinished):
        if self._progress is None:
            return
        batch_scores: MetricScores = event.batch_scores
        batch_means = batch_scores.mean_weighted()
        batch_total = batch_scores.total_weighted()

        batch_size = int(batch_total.shape[0]) if batch_total.ndim > 0 else 1
        batch_total = batch_total.mean()

        for name, val in batch_means.items():
            if name not in self._sum:
                self._sum[name] = val.detach() * batch_size
            else:
                self._sum[name] += val.detach() * batch_size

        if "Total" not in self._sum:
            self._sum["Total"] = batch_total.detach() * batch_size
        else:
            self._sum["Total"] += batch_total.detach() * batch_size

        self._count += batch_size

        epoch_means = {name: self._sum[name] / self._count for name in self._sum}
        tops = {k: v for k, v in epoch_means.items() if "." not in k}

        order = ["Total"] + sorted(k for k in tops if k != "Total")
        parts = [
            f"{name}: {format(tops[name].item(), f'.{self._sig_digits}g')}"
            for name in order
        ]
        loss_string = ", ".join(parts)
        self._progress.update(self._task_id, advance=1, loss=loss_string)
        self._render()

    def on_epoch_finished(self, event: runner_events.RunnerEpochFinished) -> None:
        if self._progress is not None:
            self._render()
            print()  # newline to preserve final state
            self._progress = None
            self._console = None
            self._task_id = None
            self._started = False
            self._sum = {}
            self._count = 0



