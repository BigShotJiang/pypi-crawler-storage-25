import warnings
from dataclasses import dataclass
from typing import Any

from .base import Event
from srforge.loss import MetricScores
from srforge.models import Model


@dataclass(frozen=True)
class TrainingBegan(Event):
    total_epochs: int
    initial_epoch: int
    train_batches_per_epoch: int
    val_batches_per_epoch: int
    best_losses: dict | None = None


@dataclass(frozen=True)
class TrainerEpochFinished(Event):
    model: Model
    train_loss: MetricScores
    val_loss: MetricScores
    epoch: int
    lr_scheduler: Any
    runner_state: dict

    _DEPRECATED_FIELDS = {"optimizer", "scaler", "optimizer_D", "scaler_D"}

    def __getattr__(self, name: str):
        if name in self._DEPRECATED_FIELDS:
            warnings.warn(
                f"Accessing 'event.{name}' is deprecated. "
                f"Use 'event.runner_state' dict instead.",
                DeprecationWarning,
                stacklevel=2,
            )
            return self.runner_state.get(name)
        raise AttributeError(f"'{type(self).__name__}' has no attribute '{name}'")
