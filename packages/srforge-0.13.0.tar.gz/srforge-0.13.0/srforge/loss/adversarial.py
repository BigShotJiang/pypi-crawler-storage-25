"""Adversarial losses for GAN training.

Provides vanilla and Relativistic average GAN (RaGAN) loss variants.
Both use :class:`~srforge.models.GANModel` score fields from the Entry.

**Vanilla GAN** (recommended for UNet discriminators)::

    d_criterion:
      _target: GANDiscriminatorLoss
      io: {inputs: {real_score: real_score_d, fake_score: fake_score_d}}
    g_criterion:
      _target: GANGeneratorLoss
      io: {inputs: {fake_score: fake_score_g}}

**Relativistic average GAN** (RaGAN)::

    d_criterion:
      _target: RaGANDiscriminatorLoss
      io: {inputs: {real_score: real_score_d, fake_score: fake_score_d}}
    g_criterion:
      _target: RaGANGeneratorLoss
      io: {inputs: {real_score: real_score_g, fake_score: fake_score_g}}

References:
    Goodfellow et al., "Generative Adversarial Networks", NeurIPS 2014.
    Jolicoeur-Martineau, "The relativistic discriminator", ICLR 2019.
"""

import torch
import torch.nn.functional as F

from srforge.loss import Loss
from srforge.registry import register_class


@register_class
class RaGANDiscriminatorLoss(Loss):
    """Relativistic average discriminator loss.

    Judges whether real images are *more realistic than the average fake*
    and vice-versa.  Used during the discriminator update step.

    ``calculate_score`` parameters (``real_score``, ``fake_score``) must
    be bound to the D-step score fields via ``set_io``.
    """

    @property
    def best_min(self) -> bool:
        return True

    def calculate_score(self, real_score: torch.Tensor,
                        fake_score: torch.Tensor) -> torch.Tensor:
        real_mean = real_score.mean()
        fake_mean = fake_score.mean()
        loss_real = F.binary_cross_entropy_with_logits(
            real_score - fake_mean, torch.ones_like(real_score),
            reduction='none')
        loss_fake = F.binary_cross_entropy_with_logits(
            fake_score - real_mean, torch.zeros_like(fake_score),
            reduction='none')
        per_sample = (loss_real + loss_fake) / 2
        # Average over all dims except batch (handles [B], [B,C], [B,C,H,W])
        if per_sample.dim() > 1:
            per_sample = per_sample.mean(dim=list(range(1, per_sample.dim())))
        return per_sample


@register_class
class RaGANGeneratorLoss(Loss):
    """Relativistic average generator adversarial loss.

    Pushes the generator to produce images that the discriminator
    considers *more realistic than real images on average*.  Used during
    the generator update step (targets are flipped compared to
    :class:`RaGANDiscriminatorLoss`).

    ``calculate_score`` parameters (``real_score``, ``fake_score``) must
    be bound to the G-step score fields via ``set_io``.
    """

    @property
    def best_min(self) -> bool:
        return True

    def calculate_score(self, real_score: torch.Tensor,
                        fake_score: torch.Tensor) -> torch.Tensor:
        real_mean = real_score.mean()
        fake_mean = fake_score.mean()
        loss_real = F.binary_cross_entropy_with_logits(
            real_score - fake_mean, torch.zeros_like(real_score),
            reduction='none')
        loss_fake = F.binary_cross_entropy_with_logits(
            fake_score - real_mean, torch.ones_like(fake_score),
            reduction='none')
        per_sample = (loss_real + loss_fake) / 2
        if per_sample.dim() > 1:
            per_sample = per_sample.mean(dim=list(range(1, per_sample.dim())))
        return per_sample


# ── Vanilla GAN losses ──────────────────────────────────────────────


def _reduce_spatial(x: torch.Tensor) -> torch.Tensor:
    """Average over all dims except batch: [B,C,H,W] -> [B]."""
    if x.dim() > 1:
        x = x.mean(dim=list(range(1, x.dim())))
    return x


@register_class
class GANDiscriminatorLoss(Loss):
    """Vanilla GAN discriminator loss.

    Standard BCE: real should score 1, fake should score 0.
    Each image is scored independently — no relativistic coupling.
    Recommended for UNet spatial discriminators.

    ``calculate_score`` parameters (``real_score``, ``fake_score``) must
    be bound to the D-step score fields via ``set_io``.
    """

    @property
    def best_min(self) -> bool:
        return True

    def calculate_score(self, real_score: torch.Tensor,
                        fake_score: torch.Tensor) -> torch.Tensor:
        loss_real = F.binary_cross_entropy_with_logits(
            real_score, torch.ones_like(real_score), reduction='none')
        loss_fake = F.binary_cross_entropy_with_logits(
            fake_score, torch.zeros_like(fake_score), reduction='none')
        return _reduce_spatial((loss_real + loss_fake) / 2)


@register_class
class GANGeneratorLoss(Loss):
    """Vanilla GAN generator loss — fool D into classifying fake as real.

    Only needs the fake score (not real). The generator wants D to
    output 1 (real) for its generated images.

    ``calculate_score`` parameter (``fake_score``) must be bound to
    the G-step fake score field via ``set_io``.
    """

    @property
    def best_min(self) -> bool:
        return True

    def calculate_score(self, fake_score: torch.Tensor) -> torch.Tensor:
        return _reduce_spatial(F.binary_cross_entropy_with_logits(
            fake_score, torch.ones_like(fake_score), reduction='none'))
