"""
Individual runners i.e. classes that execute epochs in a training process.

"""
import os
from typing import Union, Optional

from typing import List

os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"
import abc
import logging

import torch
from torch.utils import data
from torch import optim
from torch import nn
try:
    from torch_geometric.data import Batch
except ImportError:
    Batch = None
from torch.amp import GradScaler
from torch.amp import autocast

from srforge.events import runner as runner_events
from srforge import observers
from srforge.loss import Loss
from srforge.loss.schedule import LossScheduler
from srforge.loss.storage import MetricScores

#: Type alias for anything callable as a loss criterion.
Criterion = Union[Loss, LossScheduler]
from srforge.models import Model
from srforge.data.entry import Entry, GraphEntry
from srforge.registry import register_class

logger = logging.getLogger(__name__)

class EpochRunner(abc.ABC, observers.Observable):
    """
    Base class defining an interface for running a single pass through the whole input dataset
    """
    _scope: str = ""

    @property
    def scope(self) -> str:
        """Scope tag used by :class:`EventBus` for filtering."""
        return self._scope

    def __init__(self, scope: str = None):
        if scope is not None:
            self._scope = scope
        observers.Observable.__init__(self)

    def _forward_and_merge(self, model, entry, device):
        """Run model forward pass and merge output into the entry.

        Handles two execution paths:

        * **Single GPU** — ``Model.forward`` receives an Entry/GraphEntry,
          merges internally, and returns the updated Entry.
        * **Multi-GPU** (``DataParallel`` + ``DataListLoader``) — model
          receives a list, ``DataParallel`` splits across GPUs.  The
          gathered output is a raw dict of tensors.  The runner batches
          the original list post-forward and merges manually.
        """
        if not isinstance(entry, list):
            entry = entry.to(device)
        output = model(entry)
        if isinstance(entry, list):
            entry = Batch.from_data_list(entry).to(device)
        if isinstance(output, (Entry, GraphEntry)):
            return output
        if isinstance(output, dict):
            return entry.merge_fields(output, source="model")
        raise TypeError(f"Unsupported model output type: {type(output)}")

    # -- State protocol for generic checkpoint serialization ----------------

    def training_state(self) -> dict:
        """Return all optimizer/scaler state needed for checkpoint resume.

        Subclasses override to include their specific training state.
        Non-training runners (validation, benchmark) return empty dict.
        """
        return {}

    def load_training_state(self, state: dict) -> None:
        """Restore optimizer/scaler state from a checkpoint dict.

        Subclasses override to restore their specific training state.
        """

    def zero_grad(self) -> None:
        """Zero gradients on all optimizers managed by this runner.

        Subclasses override for their specific optimizers.
        """

    @abc.abstractmethod
    def run_epoch(self, model: nn.Module, data_loader: data.DataLoader, epoch: int) -> MetricScores:
        """
        :param model: Model to run epoch on.
        :param data_loader: Loader return batches of tuples (input, label)
        :param epoch: Current epoch index.
        :return: Epoch loss
        """


@register_class
class TrainingEpochRunner(EpochRunner):
    """Runner that executes one training epoch with backward pass and optimizer steps.

    The criterion is **not** stored on the runner — it is passed to
    :meth:`run_epoch` at call time by the :class:`PyTorchTrainer`.

    Args:
        optimizer: Optimizer instance (e.g. ``torch.optim.AdamW``).
        device: Device to move entries to before the forward pass
            (e.g. ``"cpu"``, ``"cuda:0"``, or a ``torch.device``).
        postprocessor: List of callables applied to the entry after the
            forward pass and before loss computation (e.g. clamping,
            denormalization).  ``None`` means no postprocessing.
        mixed_precision: Enable automatic mixed precision (AMP).  When
            ``True``, the forward pass runs inside ``torch.autocast``
            and a ``GradScaler`` handles loss scaling for the backward pass.
        gradient_accumulation_steps: Number of batches over which to
            accumulate gradients before an optimizer step.  The loss is
            divided by this value before ``.backward()``.  Effective
            batch size = ``batch_size * gradient_accumulation_steps``.
        scope: Event scope tag (default ``"train"``).  Observers
            subscribed with a matching scope receive this runner's events.
    """
    _scope = "train"

    def __init__(self,
                 optimizer: optim.Optimizer,
                 device: Union[torch.device, str] = 'cpu',
                 postprocessor: List = None,
                 mixed_precision: bool = False,
                 gradient_accumulation_steps: int = 1,
                 empty_cache_every: int = 0,
                 scope: str = None,
                 **kwargs):
        super().__init__(scope=scope)
        self.optimizer = optimizer
        self._device = device
        self.postprocessor = postprocessor or []

        self.mixed_precision = mixed_precision
        self.scaler = GradScaler(self._device, enabled=mixed_precision)
        self.gradient_accumulation_steps = max(1, gradient_accumulation_steps)
        self.empty_cache_every = empty_cache_every
        self._kwargs = kwargs

    def training_state(self) -> dict:
        state = {"optimizer": self.optimizer.state_dict()}
        if self.scaler._enabled:
            state["scaler"] = self.scaler.state_dict()
        return state

    def load_training_state(self, state: dict) -> None:
        self.optimizer.load_state_dict(state["optimizer"])
        if "scaler" in state:
            self.scaler.load_state_dict(state["scaler"])

    def zero_grad(self) -> None:
        self.optimizer.zero_grad(set_to_none=True)

    def run_epoch(self, model: Model, data_loader: data.DataLoader, epoch: int,
                  criterion: Criterion = None) -> MetricScores:
        from srforge.models import GANModel
        if isinstance(model, GANModel):
            logger.warning(
                "GANModel passed to TrainingEpochRunner — the discriminator "
                "will NOT be used. Use GANTrainingRunner for adversarial training."
            )
        model.train(True)
        score_accumulator = MetricScores.empty()

        self.notify(runner_events.RunnerEpochStarted(
            epoch=epoch,
            dataset_size=len(data_loader.dataset),
            batch_size=data_loader.batch_size,
            num_batches=len(data_loader)
        ))

        # initialize grads to zero *once*
        self.optimizer.zero_grad(set_to_none=True)
        with torch.autograd.set_detect_anomaly(True):
            for batch_idx, entry in enumerate(data_loader):
                if self.empty_cache_every > 0 and batch_idx % self.empty_cache_every == 0:
                    torch.cuda.empty_cache()
                with autocast('cuda', enabled=self.mixed_precision):
                    entry = self._forward_and_merge(model, entry, self._device)
                    for t in self.postprocessor:
                        entry = t(entry)

                    # compute losses
                    batch_scores = criterion(entry)
                    total_loss = batch_scores.total_weighted()

                # ---- GRADIENT ACCUMULATION LOGIC ----
                # scale down the loss so that over N steps it's equivalent to one big batch
                accum_loss = total_loss / self.gradient_accumulation_steps
                self.scaler.scale(accum_loss.mean()).backward()

                # only step & zero every N batches (or on last batch)
                is_last_batch = (batch_idx == len(data_loader) - 1)
                if ((batch_idx + 1) % self.gradient_accumulation_steps == 0) or is_last_batch:
                    self.scaler.step(self.optimizer)
                    self.scaler.update()
                    self.optimizer.zero_grad(set_to_none=True)
                    logger.debug(f"Optimizer step at batch {batch_idx}.")

                # log & accumulate
                score_accumulator.add_scores(batch_scores.detached())

                self.notify(runner_events.RunnerBatchFinished(
                    epoch=epoch,
                    batch=batch_idx,
                    entry=entry,
                    batch_scores=batch_scores,
                    criterion=criterion,
                    epoch_scores=score_accumulator
                ))

                # free memory
                del entry, batch_scores, total_loss, accum_loss

        # finalize: epoch-level means
        self.notify(runner_events.RunnerEpochFinished(
            epoch=epoch,
            epoch_scores=score_accumulator
        ))

        return score_accumulator

class InferenceRunner(EpochRunner):
    """Base for non-training runners (no backward pass).

    Runs the model under ``torch.no_grad()`` and optionally scores each
    batch with a criterion.  The criterion is passed to :meth:`run_epoch`
    at call time, not stored on the runner.

    Args:
        device: Device to move entries to before the forward pass
            (e.g. ``"cpu"``, ``"cuda:0"``, or a ``torch.device``).
        postprocessor: List of callables applied to the entry after the
            forward pass (e.g. clamping, denormalization).  ``None``
            means no postprocessing.
        mixed_precision: Enable automatic mixed precision (AMP).
        scope: Event scope tag.  Observers subscribed with a matching
            scope receive this runner's events.
    """

    def __init__(self, *,
                 device: Union[str, torch.device] = 'cpu',
                 postprocessor: List = None,
                 mixed_precision: bool = False,
                 empty_cache_every: int = 1,
                 scope: str = None):
        super().__init__(scope=scope)
        self._device = device
        self.postprocessor = postprocessor or []
        self.mixed_precision = mixed_precision
        self.empty_cache_every = empty_cache_every

    def run_epoch(self, model: nn.Module, data_loader: data.DataLoader, epoch: int,
                  criterion: Optional[Criterion] = None) -> MetricScores:
        model.train(False)
        score_accumulator = MetricScores.empty()
        self.notify(runner_events.RunnerEpochStarted(
            epoch=epoch,
            dataset_size=len(data_loader.dataset),
            batch_size=data_loader.batch_size,
            num_batches=len(data_loader)
        ))
        with torch.no_grad():
            with autocast('cuda', enabled=self.mixed_precision):
                for batch_idx, entry in enumerate(data_loader):
                    if self.empty_cache_every > 0 and batch_idx % self.empty_cache_every == 0:
                        torch.cuda.empty_cache()
                    entry = self._forward_and_merge(model, entry, self._device)
                    for t in self.postprocessor:
                        entry = t(entry)
                    if criterion is not None:
                        batch_scores = criterion(entry)
                        score_accumulator.add_scores(batch_scores.detached())
                    else:
                        batch_scores = MetricScores.empty()

                    self.notify(runner_events.RunnerBatchFinished(
                        epoch=epoch,
                        batch=batch_idx,
                        entry=entry,
                        batch_scores=batch_scores,
                        criterion=criterion,
                        epoch_scores=score_accumulator
                    ))

                    del entry, batch_scores
                self.notify(runner_events.RunnerEpochFinished(
                    epoch=epoch,
                    epoch_scores=score_accumulator
                ))
        return score_accumulator


@register_class
class ValidationEpochRunner(InferenceRunner):
    """Inference runner for validation.

    Identical to :class:`InferenceRunner` but enforces that a criterion
    is passed to :meth:`run_epoch` (raises ``ValueError`` otherwise).

    Constructor accepts the same parameters as :class:`InferenceRunner`.
    Default scope is ``"val"``.
    """
    _scope = "val"

    def run_epoch(self, model: nn.Module, data_loader: data.DataLoader, epoch: int,
                  criterion: Criterion = None) -> MetricScores:
        if criterion is None:
            raise ValueError("ValidationEpochRunner requires a criterion.")
        return super().run_epoch(model, data_loader, epoch, criterion=criterion)


@register_class
class BenchmarkRunner(InferenceRunner):
    """Inference runner for benchmarking.

    Criterion is optional — omit it for inference-only runs where only
    model outputs are needed (e.g. saving images).

    Constructor accepts the same parameters as :class:`InferenceRunner`.
    Default scope is ``"benchmark"``.
    """
    _scope = "benchmark"


@register_class
class GANTrainingRunner(EpochRunner):
    """Training runner for GAN with alternating generator/discriminator updates.

    Requires a :class:`~srforge.models.GANModel` (checked at runtime).
    The runner is **field-agnostic** — it never accesses Entry fields
    directly.  Instead :class:`GANModel` handles discriminator scoring
    and gradient control via :meth:`~srforge.models.GANModel.discriminator_step`
    / :meth:`~srforge.models.GANModel.generator_step`, and all
    losses read from the Entry using the standard sr-forge
    :class:`~srforge.loss.Loss` interface.

    Args:
        optimizer_G: Generator optimizer.
        optimizer_D: Discriminator optimizer.
        d_criterion: Discriminator adversarial loss (e.g.
            :class:`~srforge.loss.adversarial.RaGANDiscriminatorLoss`).
        g_criterion: Generator adversarial loss (e.g.
            :class:`~srforge.loss.adversarial.RaGANGeneratorLoss`).
            Its ``weight`` controls the adversarial contribution.
        step_ratio: Target G/D update ratio.  ``1.0`` (default) updates
            both every batch.  ``2.0`` trains G twice as often as D.
            ``0.5`` trains D twice as often as G.  The runner self-balances
            in real time by tracking cumulative update counts and deciding
            each batch which side needs to catch up.
        device: Device for computation.
        postprocessor: Transforms applied after G forward, before loss.
        mixed_precision: Enable AMP.
        empty_cache_every: Clear CUDA cache every N batches (0 = disabled).
        scope: Event scope tag.
    """
    _scope = "train"

    def __init__(self,
                 optimizer_G: optim.Optimizer,
                 optimizer_D: optim.Optimizer,
                 d_criterion: Loss,
                 g_criterion: Loss,
                 hooks: List = None,
                 device: Union[torch.device, str] = 'cpu',
                 postprocessor: List = None,
                 mixed_precision: bool = False,
                 empty_cache_every: int = 0,
                 scope: str = None,
                 # Deprecated — use hooks instead:
                 step_ratio: float = 1.0,
                 grad_clip_D: float = 0,
                 r1_weight: float = 0,
                 d_warmup_batches: int = 0,
                 **kwargs):
        super().__init__(scope=scope)
        from srforge.training.hooks import (
            TrainingHook, StepRatio, DWarmup, R1GradientPenalty, GradientClip,
        )

        self.optimizer_G = optimizer_G
        self.optimizer_D = optimizer_D
        self.d_criterion = d_criterion
        self.g_criterion = g_criterion
        self._device = device
        self.postprocessor = postprocessor or []
        self.mixed_precision = mixed_precision
        self.scaler_G = GradScaler(device, enabled=mixed_precision)
        self.scaler_D = GradScaler(device, enabled=mixed_precision)
        self.empty_cache_every = empty_cache_every
        self._global_batch_count = 0

        # Build hooks list: explicit hooks or legacy params
        if hooks is not None:
            self.hooks: List[TrainingHook] = list(hooks)
        else:
            self.hooks = []
            if step_ratio != 1.0:
                self.hooks.append(StepRatio(ratio=step_ratio))
            if d_warmup_batches > 0:
                self.hooks.append(DWarmup(batches=d_warmup_batches))
            if r1_weight > 0:
                self.hooks.append(R1GradientPenalty(weight=r1_weight))
            if grad_clip_D > 0:
                self.hooks.append(GradientClip(max_norm=grad_clip_D, target="D"))

    def training_state(self) -> dict:
        state = {
            "optimizer_G": self.optimizer_G.state_dict(),
            "optimizer_D": self.optimizer_D.state_dict(),
            "_global_batch_count": self._global_batch_count,
        }
        if self.scaler_G._enabled:
            state["scaler_G"] = self.scaler_G.state_dict()
        if self.scaler_D._enabled:
            state["scaler_D"] = self.scaler_D.state_dict()
        for i, hook in enumerate(self.hooks):
            hstate = hook.state_dict()
            if hstate:
                state[f"hook_{i}"] = hstate
        return state

    def load_training_state(self, state: dict) -> None:
        # Support both new ("optimizer_G") and legacy ("optimizer") key names
        g_state = state.get("optimizer_G", state.get("optimizer"))
        if g_state is not None:
            self.optimizer_G.load_state_dict(g_state)
        d_state = state.get("optimizer_D")
        if d_state is not None:
            self.optimizer_D.load_state_dict(d_state)
        self._global_batch_count = state.get("_global_batch_count", 0)
        if "scaler_G" in state:
            self.scaler_G.load_state_dict(state["scaler_G"])
        if "scaler_D" in state:
            self.scaler_D.load_state_dict(state["scaler_D"])
        for i, hook in enumerate(self.hooks):
            hstate = state.get(f"hook_{i}")
            if hstate:
                hook.load_state_dict(hstate)

    def zero_grad(self) -> None:
        self.optimizer_G.zero_grad(set_to_none=True)
        self.optimizer_D.zero_grad(set_to_none=True)

    def run_epoch(self, model: Model, data_loader: data.DataLoader, epoch: int,
                  criterion: Criterion = None) -> MetricScores:
        from srforge.models import GANModel
        from srforge.training.hooks import (
            GANTrainingContext, GANStages, dispatch_hooks, StepRatio,
        )

        if not isinstance(model, GANModel):
            raise TypeError(
                f"GANTrainingRunner requires a GANModel, got {type(model).__name__}. "
                f"Use TrainingEpochRunner for non-GAN training."
            )

        model.train(True)
        score_accumulator = MetricScores.empty()

        # Default step ratio (both run every batch) if no StepRatio hook
        has_step_hook = any(isinstance(h, StepRatio) for h in self.hooks)

        self.notify(runner_events.RunnerEpochStarted(
            epoch=epoch,
            dataset_size=len(data_loader.dataset),
            batch_size=data_loader.batch_size,
            num_batches=len(data_loader)
        ))

        self.zero_grad()

        ctx = GANTrainingContext(
            entry=None, epoch=epoch, batch_idx=0, model=model,
        )

        num_batches = len(data_loader)

        dispatch_hooks(self.hooks, GANStages.EPOCH_START, ctx)

        for batch_idx, entry in enumerate(data_loader):
            if self.empty_cache_every > 0 and batch_idx % self.empty_cache_every == 0:
                torch.cuda.empty_cache()

            is_last = (batch_idx == num_batches - 1)

            # --- Forward G (always — produces SR for both paths) ---
            with autocast('cuda', enabled=self.mixed_precision):
                entry = self._forward_and_merge(model, entry, self._device)
                for t in self.postprocessor:
                    entry = t(entry)

            # --- Prepare context for hooks ---
            ctx.entry = entry
            ctx.batch_idx = batch_idx
            ctx.run_d = True
            ctx.run_g = True
            ctx.d_extra_losses.clear()
            ctx.g_extra_losses.clear()
            ctx.d_scores = None
            ctx.g_pixel_scores = None
            ctx.g_adv_scores = None

            # Default: both run (unless hooks say otherwise)
            if not has_step_hook:
                ctx.run_d = ctx.run_g = True

            dispatch_hooks(self.hooks, GANStages.PRE_STEP, ctx)

            # Force both on last batch (unless warmup suppresses G)
            if is_last and ctx.run_g is not False:
                ctx.run_d = ctx.run_g = True

            # --- D step ---
            d_scores = MetricScores.empty()
            if ctx.run_d:
                dispatch_hooks(self.hooks, GANStages.PRE_D_FORWARD, ctx)

                with autocast('cuda', enabled=self.mixed_precision):
                    entry = model.discriminator_step(entry)
                    ctx.entry = entry
                    d_scores = self.d_criterion(entry)
                    ctx.d_scores = d_scores
                    d_loss = d_scores.total_weighted().mean()

                dispatch_hooks(self.hooks, GANStages.POST_D_FORWARD, ctx)

                # Add extra losses from hooks (e.g. R1)
                for extra in ctx.d_extra_losses.values():
                    d_loss = d_loss + extra

                self.scaler_D.scale(d_loss).backward()
                dispatch_hooks(self.hooks, GANStages.POST_D_BACKWARD, ctx)
                self.scaler_D.step(self.optimizer_D)
                self.scaler_D.update()
                self.optimizer_D.zero_grad(set_to_none=True)
                ctx.d_steps += 1

            # --- G step ---
            g_pixel_scores = MetricScores.empty()
            g_adv_scores = MetricScores.empty()
            if ctx.run_g:
                dispatch_hooks(self.hooks, GANStages.PRE_G_FORWARD, ctx)

                with autocast('cuda', enabled=self.mixed_precision):
                    entry = model.generator_step(entry)
                    ctx.entry = entry
                    g_pixel_scores = criterion(entry)
                    g_adv_scores = self.g_criterion(entry)
                    ctx.g_pixel_scores = g_pixel_scores
                    ctx.g_adv_scores = g_adv_scores
                    g_total = (g_pixel_scores.total_weighted().mean()
                               + g_adv_scores.total_weighted().mean())

                dispatch_hooks(self.hooks, GANStages.POST_G_FORWARD, ctx)

                for extra in ctx.g_extra_losses.values():
                    g_total = g_total + extra

                self.scaler_G.scale(g_total).backward()
                dispatch_hooks(self.hooks, GANStages.POST_G_BACKWARD, ctx)
                self.scaler_G.step(self.optimizer_G)
                self.scaler_G.update()
                self.optimizer_G.zero_grad(set_to_none=True)
                ctx.g_steps += 1

            ctx.global_batch_count += 1
            self._global_batch_count = ctx.global_batch_count

            # --- Combine metrics for observers ---
            batch_scores = d_scores.merge(g_pixel_scores).merge(g_adv_scores)

            score_accumulator.add_scores(batch_scores.detached())

            dispatch_hooks(self.hooks, GANStages.POST_STEP, ctx)

            self.notify(runner_events.RunnerBatchFinished(
                epoch=epoch,
                batch=batch_idx,
                entry=entry,
                batch_scores=batch_scores,
                criterion=criterion,
                epoch_scores=score_accumulator
            ))

            del entry, batch_scores

        dispatch_hooks(self.hooks, GANStages.EPOCH_END, ctx)

        self.notify(runner_events.RunnerEpochFinished(
            epoch=epoch,
            epoch_scores=score_accumulator
        ))
        return score_accumulator
