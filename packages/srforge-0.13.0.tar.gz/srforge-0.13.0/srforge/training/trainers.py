"""Trainers — orchestrate the epoch loop over training and validation runners."""
import abc
from typing import Union
import logging

import torch.optim.lr_scheduler
from torch.utils import data
from torch import optim

import srforge.events.trainer
from srforge.training import stop, schedule
from srforge.training import runners
from srforge.events import trainer as trainer_events
from srforge import observers
from srforge.observers.bus import EventBus
from srforge.models import Model
from srforge.loss.schedule import LossScheduler, Loss
from srforge.registry import register_class


logger = logging.getLogger(__name__)

class Trainer(abc.ABC, observers.Observable):
    @abc.abstractmethod
    def train(self, epochs: int, training_loader, validation_loader):
        """
        Performs training of a model.
        """


@register_class
class PyTorchTrainer(Trainer):
    """Orchestrates the training loop over training and validation runners.

    The trainer owns the loss criteria and passes them to the runners at
    call time via ``runner.run_epoch(criterion=...)``.  It also manages
    the LR scheduler, early stopping, and checkpoint restoration.

    Args:
        model: The model to train.  Any ``torch.nn.Module`` works;
            :class:`~srforge.models.Model` provides additional
            Entry-based routing.
        training_epoch_runner: Runner that executes one training epoch
            (typically :class:`~srforge.training.runners.TrainingEpochRunner`).
        validation_epoch_runner: Runner that executes one validation
            epoch (typically
            :class:`~srforge.training.runners.ValidationEpochRunner`).
        training_criterion: Loss or :class:`LossScheduler` used during
            the training phase.  Passed to the training runner each epoch.
        validation_criterion: Loss or :class:`LossScheduler` used
            during the validation phase.  Passed to the validation
            runner each epoch.
        lr_scheduler: Any ``torch.optim.lr_scheduler.LRScheduler``.
            Stepped once per epoch after both runners finish.  ``None``
            means constant learning rate.
        stop_condition: A :class:`~srforge.training.stop.StopCondition`
            checked after each epoch.  Defaults to
            :class:`~srforge.training.stop.NoCondition` (train for all
            epochs).
    """

    def __init__(self, model: Union[Model, torch.nn.Module],
                 training_epoch_runner: runners.EpochRunner,
                 validation_epoch_runner: runners.EpochRunner,
                 training_criterion: Union[Loss, LossScheduler],
                 validation_criterion: Union[Loss, LossScheduler],
                 lr_scheduler: torch.optim.lr_scheduler.LRScheduler = None,
                 stop_condition: stop.StopCondition = stop.NoCondition()):
        super().__init__()
        self.model = model
        self.training_runner = training_epoch_runner
        self.validation_runner = validation_epoch_runner
        self.training_criterion = training_criterion
        self.validation_criterion = validation_criterion
        self.stop_condition = stop_condition
        self.initial_epoch = 0
        self.best_losses = None
        self.lr_scheduler = lr_scheduler or schedule.BlankLRScheduler()
    @property
    def event_bus(self) -> EventBus:
        """The shared event bus for this training session."""
        return self._event_bus

    def restore(self, checkpoint: "CheckpointState | None") -> None:
        """Apply a checkpoint to this trainer.

        Sets ``initial_epoch`` and ``best_losses``.
        Runner state (optimizers, scalers) is restored via
        ``resume_from_checkpoint`` before this method is called.

        Args:
            checkpoint: A :class:`~srforge.utils.checkpoint.CheckpointState`
                returned by :func:`~srforge.utils.checkpoint.resume_from_checkpoint`,
                or ``None``.
        """
        if checkpoint is None:
            return
        self.initial_epoch = checkpoint.epoch + 1
        self.best_losses = checkpoint.best_losses

    def sanity_check(self,
                     training_loader: data.DataLoader,
                     validation_loader: data.DataLoader) -> None:
        """Run one batch through training and validation to catch errors early.

        Suppresses observer events (no logging, no checkpoints) and does
        not modify optimizer/scheduler state.  Runs one forward + loss
        pass on each runner.

        Args:
            training_loader: Training data loader.
            validation_loader: Validation data loader.
        """
        self._rich_print("[dim]Running sanity check...[/dim]")

        # Temporarily detach event buses from both runners
        train_bus = self.training_runner._event_bus
        val_bus = self.validation_runner._event_bus
        self.training_runner._event_bus = None
        self.validation_runner._event_bus = None

        try:
            # Use the actual loaders (correct collate_fn for PyG etc.)
            train_iter = iter(training_loader)
            val_iter = iter(validation_loader)

            # One training batch (forward + backward, but don't step optimizer)
            self.model.train(True)
            entry = next(train_iter)
            entry = self.training_runner._forward_and_merge(
                self.model, entry, self.training_runner._device,
            )
            for t in getattr(self.training_runner, 'postprocessor', []):
                entry = t(entry)
            criterion = self.training_criterion
            if isinstance(criterion, LossScheduler):
                criterion = criterion.current
            scores = criterion(entry)
            loss_val = scores.total_weighted().mean()
            loss_val.backward()
            runner = self.training_runner
            runner.zero_grad()
            del entry, scores, loss_val

            # One validation batch (forward only)
            self.model.train(False)
            with torch.no_grad():
                entry = next(val_iter)
                entry = self.validation_runner._forward_and_merge(
                    self.model, entry, self.validation_runner._device,
                )
                criterion = self.validation_criterion
                if isinstance(criterion, LossScheduler):
                    criterion = criterion.current
                scores = criterion(entry)
                del entry, scores
            self._rich_print("[green]✓[/green] Sanity check passed.")
        finally:
            # Restore event buses
            self.training_runner._event_bus = train_bus
            self.validation_runner._event_bus = val_bus

    @staticmethod
    def _rich_print(msg: str):
        """Print a rich-formatted message, falling back to plain print."""
        try:
            from rich.console import Console
            Console(force_terminal=True).print(msg)
        except (ImportError, UnicodeEncodeError):
            import re
            plain = re.sub(r'\[.*?\]', '', msg)
            print(plain.encode('ascii', 'replace').decode('ascii'))

    def train(self, epochs: int,
              training_loader: data.DataLoader,
              validation_loader: data.DataLoader):
        self._rich_print("[bold green]▶ Training started[/bold green]")
        self._rich_print("")
        self.notify(trainer_events.TrainingBegan(
            total_epochs=epochs,
            initial_epoch=self.initial_epoch,
            train_batches_per_epoch=len(training_loader),
            val_batches_per_epoch=len(validation_loader),
            best_losses=self.best_losses,
        ))
        try:
            for epoch in range(self.initial_epoch, epochs):
                if isinstance(self.training_criterion, LossScheduler):
                    self.training_criterion.update(epoch)
                if isinstance(self.validation_criterion, LossScheduler):
                    self.validation_criterion.update(epoch)

                loss = self.training_runner.run_epoch(
                    self.model, training_loader, epoch, criterion=self.training_criterion,
                )
                val_loss = self.validation_runner.run_epoch(
                    self.model, validation_loader, epoch, criterion=self.validation_criterion,
                )

                self.notify(trainer_events.TrainerEpochFinished(
                    model=self.model,
                    train_loss=loss,
                    val_loss=val_loss,
                    epoch=epoch,
                    lr_scheduler=self.lr_scheduler,
                    runner_state=self.training_runner.training_state(),
                ))

                val_loss_total_mean = val_loss.total_weighted().mean()
                if isinstance(self.lr_scheduler, optim.lr_scheduler.ReduceLROnPlateau):
                    self.lr_scheduler.step(val_loss_total_mean)
                else:
                    self.lr_scheduler.step()
                if self.stop_condition.is_condition_satisfied(epoch, loss.total_weighted().mean().item(), val_loss_total_mean.item()):
                    break
        except KeyboardInterrupt:
            self._rich_print("\n[bold yellow]⚠ Training interrupted by user[/bold yellow]")
            try:
                from srforge import GlobalSettings
                tracker = GlobalSettings().tracker
                if tracker is not None:
                    tracker.finish(1)
            except Exception:
                pass
            # Hard exit — kills DataLoader workers and MKL threads that
            # otherwise hang on Windows after Ctrl+C.
            import os
            os._exit(1)