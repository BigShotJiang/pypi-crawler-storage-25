"""Training hooks — composable behaviors injected into the training loop.

A :class:`TrainingHook` is attached to a runner and called at defined
stage points.  Hooks receive a mutable :class:`TrainingContext` (or a
runner-specific subclass like :class:`GANTrainingContext`) and can read
or modify it — controlling which steps run, adding regularization
losses, clipping gradients, etc.

**Stages** are string constants defined on :class:`Stages` subclasses.
They are auto-registered when the class is loaded — no manual
registration needed.  Hook ``on_<stage>`` methods are validated against
the registry at class creation time.

Usage in YAML config::

    training_runner:
      _target: GANTrainingRunner
      params:
        hooks:
          - _target: StepRatio
            params: {ratio: 1.0}
          - _target: R1GradientPenalty
            params: {weight: 0.5}

Custom stages for a new runner::

    class MyStages(Stages):
        PRE_TEACHER = "pre_teacher_forward"
        POST_DISTILL = "post_distillation"
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, TYPE_CHECKING

import torch

from srforge.registry import register_class

if TYPE_CHECKING:
    pass


# ── Stage registry ──────────────────────────────────────────────────

_registered_stages: set[str] = set()


def register_stages(*names: str) -> None:
    """Register stage names in the global registry."""
    _registered_stages.update(names)


def is_registered_stage(name: str) -> bool:
    """Check if a stage name is registered."""
    return name in _registered_stages


class _StagesMeta(type):
    """Metaclass that auto-registers string constants as training stages."""

    def __init__(cls, name, bases, namespace):
        super().__init__(name, bases, namespace)
        for attr, value in namespace.items():
            if not attr.startswith("_") and isinstance(value, str):
                register_stages(value)


class Stages(metaclass=_StagesMeta):
    """Base training stages — dispatched by every training runner.

    Subclass to add stages for custom runners.  String constants are
    auto-registered when the subclass is defined.
    """
    EPOCH_START = "epoch_start"
    PRE_STEP = "pre_step"
    POST_STEP = "post_step"
    EPOCH_END = "epoch_end"


class GANStages(Stages):
    """GAN-specific stages — dispatched by :class:`GANTrainingRunner`."""
    PRE_D_FORWARD = "pre_d_forward"
    POST_D_FORWARD = "post_d_forward"
    POST_D_BACKWARD = "post_d_backward"
    PRE_G_FORWARD = "pre_g_forward"
    POST_G_FORWARD = "post_g_forward"
    POST_G_BACKWARD = "post_g_backward"


# ── Context ─────────────────────────────────────────────────────────


@dataclass
class TrainingContext:
    """Mutable state passed to hooks at each training stage.

    This base class contains only generic fields.  Runner-specific
    subclasses (e.g. :class:`GANTrainingContext`) add their own fields.
    """
    entry: Any  # Entry or GraphEntry
    epoch: int
    batch_idx: int
    model: Any
    global_batch_count: int = 0
    extra_losses: dict[str, torch.Tensor] = field(default_factory=dict)
    scores: Any = None


@dataclass
class GANTrainingContext(TrainingContext):
    """Training context for GAN runners — adds D/G-specific fields."""
    run_d: bool = True
    run_g: bool = True
    d_extra_losses: dict[str, torch.Tensor] = field(default_factory=dict)
    g_extra_losses: dict[str, torch.Tensor] = field(default_factory=dict)
    d_scores: Any = None
    g_pixel_scores: Any = None
    g_adv_scores: Any = None
    d_steps: int = 0
    g_steps: int = 0


# ── Hook base class ─────────────────────────────────────────────────


class TrainingHook:
    """Base class for training hooks.

    Override ``on_<stage_name>`` methods to inject behavior at specific
    points in the training loop.  Method names are validated against
    the stage registry at class creation — typos are caught immediately.

    Hooks with persistent state should implement :meth:`state_dict` /
    :meth:`load_state_dict` for checkpoint support.
    """

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        for name in list(cls.__dict__):
            if name.startswith("on_") and callable(cls.__dict__[name]):
                stage = name[3:]
                if not is_registered_stage(stage):
                    raise ValueError(
                        f"{cls.__name__}.{name}() references unknown "
                        f"training stage '{stage}'. Define it on a "
                        f"Stages subclass: {stage} = \"{stage}\""
                    )

    def state_dict(self) -> dict:
        """Return persistent state for checkpointing (optional)."""
        return {}

    def load_state_dict(self, state: dict) -> None:
        """Restore persistent state from checkpoint (optional)."""
        pass


# ── Dispatch ────────────────────────────────────────────────────────


def dispatch_hooks(hooks: list[TrainingHook], stage: str,
                   ctx: TrainingContext) -> None:
    """Call all hooks that implement ``on_<stage>``."""
    if not is_registered_stage(stage):
        raise ValueError(
            f"Unknown training stage '{stage}'. "
            f"Define it on a Stages subclass."
        )
    method_name = f"on_{stage}"
    for hook in hooks:
        handler = getattr(hook, method_name, None)
        if handler is not None:
            handler(ctx)


# ── Concrete hooks ──────────────────────────────────────────────────


@register_class
class StepRatio(TrainingHook):
    """Control G/D update frequency via a target ratio.

    ``ratio=1.0`` (default) updates both every batch.
    ``ratio=2.0`` trains G twice as often as D.
    ``ratio=0.5`` trains D twice as often as G.
    """

    def __init__(self, ratio: float = 1.0):
        if ratio <= 0:
            raise ValueError(f"step_ratio must be > 0, got {ratio}")
        self.ratio = ratio

    def on_pre_step(self, ctx: GANTrainingContext) -> None:
        if ctx.d_steps == 0 and ctx.g_steps == 0:
            ctx.run_d = ctx.run_g = True
        else:
            current = ctx.g_steps / max(ctx.d_steps, 1)
            ctx.run_d = current >= self.ratio
            ctx.run_g = current <= self.ratio


@register_class
class DWarmup(TrainingHook):
    """Train only D for the first *batches* batches (across epochs).

    During warmup ``ctx.run_g`` is set to ``False``.
    """

    def __init__(self, batches: int = 500):
        self.batches = batches

    def on_pre_step(self, ctx: GANTrainingContext) -> None:
        if ctx.global_batch_count < self.batches:
            ctx.run_d = True
            ctx.run_g = False


@register_class
class R1GradientPenalty(TrainingHook):
    """R1 gradient penalty on the discriminator.

    Penalizes large gradients of D's output w.r.t. real input images,
    preventing discriminator score growth.

    Uses ``mean`` reduction over spatial dims (resolution-independent).
    """

    def __init__(self, weight: float = 0.5):
        self.weight = weight

    def on_post_d_forward(self, ctx: GANTrainingContext) -> None:
        if self.weight <= 0:
            return
        model = ctx.model
        real = ctx.entry[model._real_field].detach().requires_grad_(True)
        real_out = model.discriminator(**{model._disc_param: real})
        grad_real, = torch.autograd.grad(
            outputs=real_out.sum(), inputs=real, create_graph=True,
        )
        r1 = grad_real.pow(2).reshape(grad_real.size(0), -1).mean(1).mean()
        ctx.d_extra_losses["r1"] = self.weight * r1


@register_class
class GradientClip(TrainingHook):
    """Clip gradient norms after backward.

    Args:
        max_norm: Maximum gradient norm.
        target: ``"D"`` for discriminator, ``"G"`` for generator.
    """

    def __init__(self, max_norm: float = 1.0, target: str = "D"):
        self.max_norm = max_norm
        self.target = target.upper()

    def on_post_d_backward(self, ctx: GANTrainingContext) -> None:
        if self.target == "D":
            torch.nn.utils.clip_grad_norm_(
                ctx.model.discriminator.parameters(), self.max_norm)

    def on_post_g_backward(self, ctx: GANTrainingContext) -> None:
        if self.target == "G":
            torch.nn.utils.clip_grad_norm_(
                ctx.model.generator.parameters(), self.max_norm)


@register_class
class EdgeEnhancedInput(TrainingHook):
    """Concatenate a Laplacian edge map to discriminator inputs.

    Amplifies high-frequency differences (blur vs sharp) that the
    discriminator may struggle to detect on raw pixels alone. Useful
    for single-channel or low-contrast images.

    When using this hook, set the discriminator's ``num_in_ch`` to
    ``original_channels * 2`` (e.g. 2 for single-channel images).

    Example config::

        hooks:
          - _target: EdgeEnhancedInput

        discriminator:
          params:
            num_in_ch: 2    # 1 raw + 1 edge
    """

    _LAPLACIAN = torch.tensor(
        [[0, 1, 0], [1, -4, 1], [0, 1, 0]], dtype=torch.float32,
    ).view(1, 1, 3, 3)

    def _enhance(self, x: torch.Tensor) -> torch.Tensor:
        lap = self._LAPLACIAN.to(x.device)
        edges = torch.nn.functional.conv2d(x, lap, padding=1)
        return torch.cat([x, edges], dim=1)

    def on_pre_d_forward(self, ctx: GANTrainingContext) -> None:
        """Replace real/fake fields with edge-enhanced versions."""
        model = ctx.model
        real = self._enhance(ctx.entry[model._real_field])
        fake = self._enhance(ctx.entry[model._fake_field])
        ctx.entry[model._real_field] = real
        ctx.entry[model._fake_field] = fake
