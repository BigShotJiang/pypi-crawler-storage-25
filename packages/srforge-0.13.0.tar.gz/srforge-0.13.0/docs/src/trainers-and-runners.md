# Trainers & Runners

The [Writing Scripts](scripts.md) page shows *how* to wire up a training script. This page explains *what happens inside* once you call `trainer.train()` or `runner.run_epoch()`.

**Trainer** orchestrates the epoch loop — it owns the loss criteria and delegates the actual forward/backward work to **runners**. Runners are stateless execution engines: they iterate over batches, fire events, and return aggregated metrics. The criterion is passed to `run_epoch()` at call time, not stored on the runner. Observers listen for runner events and react (progress bars, checkpoints, logging).

---

## Trainer lifecycle

`PyTorchTrainer.train()` runs the outer epoch loop. Here's the full flow:

```mermaid
flowchart TD
    start([trainer.train#40;epochs, train_loader, val_loader#41;]) --> began

    began["<b>TrainingBegan</b> event<br/><i>total_epochs, initial_epoch, batches per loader</i>"]
    began --> epoch_loop

    epoch_loop{"epoch < epochs?"}
    epoch_loop -- No --> done([Return])
    epoch_loop -- Yes --> loss_sched

    loss_sched["Update LossScheduler<br/><i>if criterion is LossScheduler</i>"]
    loss_sched --> train_run

    train_run["<b>training_runner.run_epoch</b>#40;model, train_loader, epoch, criterion#41;<br/>→ train_scores"]
    train_run --> val_run

    val_run["<b>validation_runner.run_epoch</b>#40;model, val_loader, epoch, criterion#41;<br/>→ val_scores"]
    val_run --> epoch_event

    epoch_event["<b>TrainerEpochFinished</b> event<br/><i>model, optimizer, lr_scheduler,<br/>train_loss, val_loss, epoch, scaler</i>"]
    epoch_event --> lr_step

    lr_step["Step LR scheduler<br/><i>ReduceLROnPlateau uses val_loss;<br/>all others use epoch count</i>"]
    lr_step --> stop_check

    stop_check{"StopCondition<br/>satisfied?"}
    stop_check -- Yes --> done
    stop_check -- No --> epoch_loop
```

### What happens at each step

1. **`TrainingBegan`** — fired once before the loop starts. `PyTorchModelSaver` uses it to initialize `best_loss` from a resumed checkpoint.

2. **LossScheduler update** — if the criterion is a `LossScheduler`, it advances to the current epoch (e.g., switching from L1 to a combined L1+SSIM at epoch 50).

3. **Training runner** — runs one full pass through the training data with gradients enabled. Returns aggregated `MetricScores`.

4. **Validation runner** — runs one full pass through the validation data with `torch.no_grad()`. Returns aggregated `MetricScores`.

5. **`TrainerEpochFinished`** — fired after both runners complete. Observers react:
    - `PyTorchModelSaver` saves `checkpoint_best.pth` if validation loss improved, and always saves `checkpoint_last.pth`.
    - `LossLogger` logs all metrics to the tracker and calls `tracker.commit()`.

6. **LR scheduler step** — the trainer steps the LR scheduler once per epoch. Metric-based schedulers receive the mean validation loss; epoch-based schedulers step by count.

7. **Stop condition** — checked after each epoch. Returns `True` to end training early (e.g., when validation loss plateaus). The default `NoCondition` never stops.

---

## Runner lifecycle

Every runner follows the same pattern in `run_epoch()`. The difference is whether gradients and optimizer steps are involved.

```mermaid
flowchart TD
    start([run_epoch#40;model, data_loader, epoch, criterion#41;]) --> mode

    mode["Set model mode<br/><i>train#40;True#41; or train#40;False#41; + no_grad</i>"]
    mode --> epoch_start

    epoch_start["<b>RunnerEpochStarted</b> event<br/><i>epoch, dataset_size, batch_size, num_batches</i>"]
    epoch_start --> batch_loop

    batch_loop{"Next batch?"}
    batch_loop -- No --> epoch_end
    batch_loop -- Yes --> forward

    forward["<b>Forward pass</b><br/><i>entry.to#40;device#41; → model#40;entry#41;</i><br/>with autocast if mixed_precision"]
    forward --> merge

    merge["Merge output into Entry"]
    merge --> post

    post["Apply postprocessors<br/><i>e.g., clamp, denormalize</i>"]
    post --> loss

    loss["Compute loss<br/><i>batch_scores = criterion#40;entry#41;</i>"]
    loss --> backward

    backward{"Training<br/>runner?"}
    backward -- Yes --> grad
    backward -- No --> accum

    grad["<b>Backward pass</b><br/><i>loss / accumulation_steps → .backward#40;#41;</i>"]
    grad --> optim_check

    optim_check{"Accumulation<br/>step?"}
    optim_check -- Yes --> optim_step
    optim_check -- No --> accum

    optim_step["<b>Optimizer step</b><br/><i>scaler.step#40;optimizer#41;<br/>scaler.update#40;#41;<br/>optimizer.zero_grad#40;#41;</i>"]
    optim_step --> accum

    accum["Accumulate MetricScores"]
    accum --> batch_event

    batch_event["<b>RunnerBatchFinished</b> event<br/><i>epoch, batch, entry, batch_scores,<br/>criterion, epoch_scores</i>"]
    batch_event --> free

    free["Free memory<br/><i>del output, entry, batch_scores</i>"]
    free --> batch_loop

    epoch_end["<b>RunnerEpochFinished</b> event<br/><i>epoch, epoch_scores</i>"]
    epoch_end --> ret([Return epoch_scores])
```

### Key details

- **Model mode** — `TrainingEpochRunner` sets `model.train(True)`; validation and benchmark runners set `model.train(False)` inside `torch.no_grad()`.

- **Forward pass** — the model receives an `Entry` and returns an `Entry`, `GraphEntry`, or `dict`. The runner merges the output back into the original entry so postprocessors and the loss see all fields.

- **Postprocessors** — a list of transforms applied after the model (e.g., clamping pixel values, undoing normalization). Configured per-runner.

- **Accumulation step** — the optimizer steps every `gradient_accumulation_steps` batches, or on the last batch of the epoch. The loss is divided by the accumulation factor before `.backward()`.

- **Events** — `RunnerBatchFinished` carries the full entry, so observers like `BatchImageSaver` can extract and save predictions. `RunnerEpochFinished` carries the aggregated scores for the entire epoch.

---

## Event timeline

This sequence diagram shows one complete epoch — how events flow from the trainer through both runners to the observers:

```mermaid
sequenceDiagram
    participant T as PyTorchTrainer
    participant TR as TrainingRunner
    participant VR as ValidationRunner
    participant O as Observers

    Note over T: Epoch begins

    T->>TR: run_epoch(model, train_loader, epoch, criterion=training_criterion)
    activate TR
    TR->>O: RunnerEpochStarted (scope: train)
    Note over O: ProgressBar initializes

    loop Each training batch
        TR->>TR: forward → postprocess → loss → backward → optimizer step
        TR->>O: RunnerBatchFinished (scope: train)
        Note over O: ProgressBar updates
    end

    TR->>O: RunnerEpochFinished (scope: train)
    TR-->>T: train_scores
    deactivate TR

    T->>VR: run_epoch(model, val_loader, epoch, criterion=validation_criterion)
    activate VR
    VR->>O: RunnerEpochStarted (scope: val)

    loop Each validation batch
        VR->>VR: forward → postprocess → loss
        VR->>O: RunnerBatchFinished (scope: val)
        Note over O: BatchImageSaver saves predictions
    end

    VR->>O: RunnerEpochFinished (scope: val)
    VR-->>T: val_scores
    deactivate VR

    T->>O: TrainerEpochFinished (no scope)
    Note over O: PyTorchModelSaver saves checkpoint<br/>LossLogger logs metrics

    Note over T: Step LR scheduler<br/>Check stop condition
```

### Event scoping

Runner events are **scoped** — `RunnerBatchFinished` from the training runner has scope `"train"`, from the validation runner scope `"val"`. When you subscribe an observer to the event bus, you can filter by scope:

```python
# Receives events from all scopes (default)
settings.event_bus.subscribe(loss_logger)

# Receives only validation-scoped events + unscoped events
settings.event_bus.subscribe(image_saver, scope="val")
```

Trainer-level events (`TrainingBegan`, `TrainerEpochFinished`) have **no scope** — all observers receive them regardless of their subscription scope.

See [Observers & Events](observers.md) for more details on scoping rules.

---

## Runner types

```
EpochRunner (ABC)
├── TrainingEpochRunner    — backward pass, gradient accumulation, optimizer
└── InferenceRunner        — torch.no_grad() loop, optional criterion
    ├── ValidationEpochRunner  (scope="val")
    └── BenchmarkRunner        (scope="benchmark")
```

`ValidationEpochRunner` and `BenchmarkRunner` both inherit from `InferenceRunner` — the same inference loop with no gradients. They differ only in their scope tag and whether `criterion` is enforced.

| | TrainingEpochRunner | ValidationEpochRunner | BenchmarkRunner |
|---|---|---|---|
| **Scope** | `train` | `val` | `benchmark` |
| **Gradients** | Yes | No (`torch.no_grad`) | No |
| **Optimizer** | Yes | No | No |
| **Mixed precision** | Optional | Optional | Optional |
| **Grad accumulation** | Optional | N/A | N/A |
| **Criterion** | Required in `run_epoch` | Required in `run_epoch` | Optional in `run_epoch` |
| **Used in** | `PyTorchTrainer` | `PyTorchTrainer` | Benchmark scripts |

!!! warning "Criterion is not stored on the runner"
    Runners are stateless with respect to criteria. The criterion is always passed as a parameter to `run_epoch(criterion=...)`. The `PyTorchTrainer` owns both criteria and passes them at call time. This keeps runners as pure execution engines and avoids temporal coupling.

**`TrainingEpochRunner`** — the workhorse. Handles forward pass, backward pass, optimizer steps, gradient accumulation, and mixed-precision scaling. Used as the trainer's `training_epoch_runner`.

**`ValidationEpochRunner`** — same forward pass and loss computation, but with gradients disabled. Raises `ValueError` if `criterion` is not provided to `run_epoch()`. Used as the trainer's `validation_epoch_runner`.

**`BenchmarkRunner`** — designed for test/inference scripts. Criterion is optional — if you only need predictions (e.g., saving images), omit it. If provided, it computes and reports metrics. Used standalone, not inside a trainer.

---

## Key features

### Mixed precision

Enable automatic mixed precision (AMP) per-runner:

```yaml
training_runner:
  _target: srforge.training.runners.TrainingEpochRunner
  params:
    mixed_precision: true
    # ...
```

When enabled, the forward pass and loss computation run inside `torch.autocast('cuda')`. A `GradScaler` handles loss scaling for the backward pass to prevent underflow in float16 gradients. The scaler state is saved and restored in checkpoints.

### Gradient accumulation

Simulate larger batch sizes by accumulating gradients over multiple batches:

```yaml
training_runner:
  _target: srforge.training.runners.TrainingEpochRunner
  params:
    gradient_accumulation_steps: 4
    # ...
```

The loss is divided by `gradient_accumulation_steps` before `.backward()`. The optimizer steps every 4 batches (or on the last batch of the epoch, whichever comes first). Effective batch size = `batch_size * gradient_accumulation_steps`.

### LR scheduling

The trainer steps the LR scheduler once per epoch, after both runners finish. Any `torch.optim.lr_scheduler.LRScheduler` subclass works — epoch-based schedulers (e.g., `StepLR`, `CosineAnnealingLR`, `ExponentialLR`) and metric-based schedulers (e.g., `ReduceLROnPlateau`) are both supported. If no scheduler is provided, the trainer uses a no-op `BlankLRScheduler` internally.

### Early stopping

The trainer checks a `StopCondition` after each epoch. The `StopCondition` interface receives the current epoch, training loss, and validation loss, and returns `True` to stop training.

SR-Forge ships two implementations:

- **`NoCondition`** (default) — never stops; training runs for all epochs.
- **`ValidationLossDidNotImprove(patience, min_delta)`** — stops if validation loss hasn't improved by at least `min_delta` for `patience` consecutive epochs.

```yaml
trainer:
  _target: srforge.training.trainers.PyTorchTrainer
  params:
    stop_condition:
      _target: srforge.training.stop.ValidationLossDidNotImprove
      params:
        patience: 10
        min_delta: 0.0001
    # ...
```

You can implement custom stop conditions by subclassing `StopCondition` and overriding `is_condition_satisfied()`.

---

## YAML example

A complete trainer + runners configuration:

```yaml
training_runner:
  _target: srforge.training.runners.TrainingEpochRunner
  params:
    optimizer: ${ref:optimizer}
    device: ${system.device}
    postprocessor: ${postprocessing}
    mixed_precision: true
    gradient_accumulation_steps: 1

validation_runner:
  _target: srforge.training.runners.ValidationEpochRunner
  params:
    device: ${system.device}
    postprocessor: ${postprocessing}
    mixed_precision: true

trainer:
  _target: srforge.training.trainers.PyTorchTrainer
  params:
    model: ${ref:model}
    training_epoch_runner: ${ref:training_runner}
    validation_epoch_runner: ${ref:validation_runner}
    training_criterion: ${ref:loss}
    validation_criterion: ${ref:loss}
    lr_scheduler: ${ref:lr_scheduler}
    stop_condition:
      _target: srforge.training.stop.NoCondition
```

For benchmark scripts, use `BenchmarkRunner` directly — no trainer needed:

```python
runner = BenchmarkRunner(device=device, postprocessor=postprocessor)
runner.run_epoch(model=model, data_loader=test_loader, epoch=0, criterion=metrics)
```

Omit `criterion` for inference-only runs (no scoring):

```python
runner = BenchmarkRunner(device=device, postprocessor=postprocessor)
runner.run_epoch(model=model, data_loader=test_loader, epoch=0)
```

---

**Next:** [Configuration](configuration.md) — Wire everything together in YAML
