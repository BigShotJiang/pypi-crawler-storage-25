# Models

In SR-Forge, a **Model** is a neural network component that participates in the data pipeline. Unlike a plain PyTorch `nn.Module`, an SR-Forge Model knows how to read inputs from Entry fields and write outputs back — thanks to IO binding.

## Which One Do I Need?

```
I want to build a model...
            |
   Is it a single neural network?
            |
     +------+------+-------------+
     |             |              |
    YES           NO — pipeline  GAN training
     |             |              |
     v             v              v
   Model      SequentialModel   GANModel
```

**[Model](model.md)** — for individual neural network components. You define `forward()` with your computation, and the framework handles Entry routing. This is what you use for a single encoder, decoder, super-resolver, etc.

**[GANModel](gan-model.md)** — for adversarial training with a generator and discriminator. Wraps both into a composite model that handles discriminator scoring, gradient control, and field management automatically.

**[SequentialModel](sequential-model.md)** — for multi-stage pipelines that chain multiple models and transforms. You describe the data flow with a simple arrow syntax (`image -> encoder -> features -> decoder -> output`), and the framework wires everything together. No glue code needed.

Read them in order — Model first, then GANModel or SequentialModel depending on your needs.
