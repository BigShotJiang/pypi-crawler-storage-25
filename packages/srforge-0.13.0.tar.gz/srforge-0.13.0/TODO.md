# TODO

## GAN Training Infrastructure — Pluggable Hook Architecture

### The Problem

When GAN training was first added, every GAN-specific behavior (dual
optimizers, R1 penalty, D warmup, step ratio, gradient clipping) was
hardcoded directly into `GANTrainingRunner.__init__` and `run_epoch`.
The trainer, checkpoint system, and event system all grew `getattr`
chains and optional fields to handle the second optimizer/scaler.

This created three concrete problems:

1. **Not extensible.** Adding a new training paradigm (multi-task,
   distillation, curriculum learning) would require the same pattern of
   hardcoding `optimizer_X`, `scaler_X` across the trainer, checkpoint,
   event, and observer code. Each new paradigm adds more special cases.

2. **Not composable.** R1 penalty, gradient clipping, warmup, and step
   scheduling were entangled inside `run_epoch`. You couldn't add R1 to
   a standard training runner, or remove warmup from a GAN runner,
   without editing the runner code.

3. **Not configurable.** Changing training behavior required code changes.
   A researcher trying different GAN stabilization strategies would have
   to modify the runner source for each experiment.

### The Solution

A **pluggable hook system** where:

- The runner is a **thin loop** that dispatches to composable
  `TrainingHook` instances at defined stage points.
- Hooks read and modify a **mutable `TrainingContext`**, controlling
  which steps run, adding regularization losses, clipping gradients, etc.
- **Stages** are auto-registered string constants on namespace classes
  (`Stages`, `GANStages`). Custom runners define new stages by
  subclassing. Hook method names are validated against the registry at
  class creation — typos are caught immediately.
- The **checkpoint system** is runner-agnostic: each runner exposes
  `training_state()` / `load_training_state()`, and the checkpoint
  just saves/loads an opaque dict.
- **Observers eventually become hooks** that only read the context —
  one unified system instead of two parallel ones (observers + hooks).

### What a Hook Looks Like

```python
from srforge.training.hooks import TrainingHook, GANTrainingContext

class R1GradientPenalty(TrainingHook):
    """Added to D loss after discriminator forward pass."""
    def __init__(self, weight=0.5):
        self.weight = weight

    def on_post_d_forward(self, ctx: GANTrainingContext):
        # Compute penalty and add to D's extra losses
        grad = torch.autograd.grad(...)
        ctx.d_extra_losses["r1"] = self.weight * grad.pow(2).mean()
```

```yaml
# Config — no code changes to add/remove/reorder hooks:
training_runner:
  params:
    hooks:
      - _target: StepRatio
        params: {ratio: 1.0}
      - _target: R1GradientPenalty
        params: {weight: 0.5}
      - _target: EdgeEnhancedInput
```

### What's Done

- [x] **Phase 1 — Runner state protocol.**
  Every runner exposes `training_state()`, `load_training_state()`,
  `zero_grad()`. The trainer, checkpoint, and `TrainerEpochFinished`
  event use these generically — no more `getattr(runner, 'optimizer',
  getattr(runner, 'optimizer_G', None))` chains. Legacy APIs still
  work with deprecation warnings.

  *Files: `runners.py`, `trainers.py`, `checkpoint.py`,
  `events/trainer.py`, `observers/checkpoint.py`*

- [x] **Phase 2 — Training hook system.**
  `TrainingHook` base class with `__init_subclass__` validation.
  `TrainingContext` (generic) + `GANTrainingContext` (D/G fields).
  `Stages` / `GANStages` namespace classes with auto-registered string
  constants via metaclass. `dispatch_hooks()` validates stage names at
  runtime. Concrete hooks: `StepRatio`, `DWarmup`, `R1GradientPenalty`,
  `GradientClip`, `EdgeEnhancedInput`. `GANTrainingRunner` accepts a
  `hooks` list and dispatches at each stage. Legacy `__init__` params
  auto-converted to hooks for backward compat.

  *Files: `training/hooks.py` (new), `runners.py`, all GAN tests*

### What's Next

- [ ] **Phase 3 — Remove deprecated legacy params.**

  *Why:* The old `GANTrainingRunner.__init__` still accepts `step_ratio`,
  `r1_weight`, `grad_clip_D`, `d_warmup_batches` and silently converts
  them to hooks. This dual path is confusing — two ways to do the same
  thing, with different behavior if you mix them. Removing the legacy
  params forces a single clear way: the `hooks` list.

  *What changes:*
  - Remove `step_ratio`, `r1_weight`, `grad_clip_D`, `d_warmup_batches`
    from `GANTrainingRunner.__init__`
  - Remove the auto-conversion block that builds hooks from legacy params
  - Remove deprecated `optimizer_D`/`scaler_D` fields from
    `TrainerEpochFinished` event and `CheckpointState.__getattr__`
  - Remove deprecated `optimizer`/`scaler` params from `save_checkpoint()`
  - Remove `_LegacyAdapter` from `resume_from_checkpoint()`

  *Breaking change:* Old configs using `step_ratio: 1.0` in the runner
  must migrate to `hooks: [{_target: StepRatio, params: {ratio: 1.0}}]`.

- [ ] **Phase 4 — Hooks on standard TrainingEpochRunner.**

  *Why:* Currently only `GANTrainingRunner` supports hooks. Standard
  single-model training has useful hook points too — gradient
  accumulation could be a hook, learning rate warmup could be a hook,
  custom logging could be a hook. Without this, users who want pluggable
  behavior on standard training are stuck.

  *What changes:*
  - Add `hooks` param to `TrainingEpochRunner.__init__`
  - Dispatch `Stages.PRE_STEP`, `Stages.POST_STEP`, etc. in its
    `run_epoch`
  - Extract `GradientAccumulation` as a hook (currently hardcoded with
    `gradient_accumulation_steps` param)
  - Both runners share the same hook dispatch mechanism

  *End state:* A single runner base class that dispatches hooks. The
  difference between "standard training" and "GAN training" is just
  which hooks are configured and which stages the `run_epoch` publishes.

- [ ] **Phase 5 — Migrate observers to hooks.**

  *Why:* sr-forge currently has two parallel systems for "things that
  plug into the training loop": observers (passive, EventBus-based,
  `on_epoch_finished` etc.) and hooks (active, runner-based,
  `on_pre_step` etc.). This is confusing — should a new behavior be
  an observer or a hook? Where do I register it? The answer should be:
  one system, hooks.

  *What changes:*
  - `ProgressBar` becomes a hook on `POST_STEP` and `EPOCH_END`
  - `LossLogger` becomes a hook on `EPOCH_END`
  - `PyTorchModelSaver` becomes a hook on `EPOCH_END`
  - `RegistrationShiftLogger` becomes a hook on `POST_STEP`
  - The EventBus and ObserverMeta metaclass are deprecated, then removed
  - Hooks registered via config replace observer registration

  *End state:* One unified hook system. "Observer" is just a hook that
  reads the context without modifying it. No separate EventBus, no
  separate registration mechanism, no confusion about which system to use.

- [ ] **Multi-GPU GAN support.**

  *Why:* `GANModel.discriminator_step` and `generator_step` call
  `self.discriminator(...)` directly, bypassing `DataParallel`. This
  means GAN training only works on a single GPU.

  *What changes:*
  - Discriminator calls need to go through the DataParallel wrapper
  - Either wrap the discriminator in DataParallel separately, or route
    through the same mechanism `_forward_and_merge` uses for the generator

---

## Medium Priority — Usability

- [ ] **Document `${ref:}` vs `${}` distinction** — add a prominent warning
  in `docs/src/configuration.md`. New users will confuse the two.

- [ ] **Make annotation-driven recursion explicit** — DataTransform recurses
  into dicts/lists based on type annotations, defaulting to recurse if
  unannotated. Consider a class attribute or decorator to make this visible.
  `srforge/transform/__init__.py`

- [ ] **Remove or gate IOPort descriptor system** — `_IOPort` and
  `_install_io_ports` are implemented but every main class opts out.
  Either remove or document when it's useful.
  `srforge/utils/iomodule.py`

- [ ] **Warn on ClassRegistry short-name collisions** — second class with the
  same short name is silently ignored. Add a warning.
  `srforge/registry.py`

## Low Priority — Cleanup

- [ ] **Remove redundant transform/transform_unbatched pairs** — ~30% of
  DataTransforms manually delegate one to the other. The base class should
  handle dispatch.
  `srforge/transform/data.py`, `srforge/transform/entry.py`

- [ ] **Simplify `_Args`/`_Kwargs` in ConfigResolver** — internal wrapper
  classes add complexity; replace with a simpler pattern.
  `srforge/config/resolver.py`

- [ ] **Stop using private OmegaConf APIs** — `_key()` and `_get_parent()`
  may break in future versions.
  `srforge/config/resolver.py`
