"""Coverage tests for checkpoint, logging, and image observers."""

from dataclasses import dataclass
from unittest.mock import MagicMock, patch, call
from typing import Any

import numpy as np
import pytest
import torch

from srforge.events.base import Event
from srforge.events import trainer as trainer_events
from srforge.events import runner as runner_events
from srforge.loss.storage import MetricScores, MetricEntry
from srforge.tracking.null import NullTracker


# ── Helpers ─────────────────────────────────────────────────────────────


def _make_metric_scores(value: float = 0.5) -> MetricScores:
    """Build a minimal MetricScores with a single scalar metric."""
    return MetricScores({
        "L1": MetricEntry(
            raw=torch.tensor([value]),
            best_min=True,
            weight=1.0,
        )
    })


def _make_tracker_mock() -> MagicMock:
    """Create a mock that satisfies the ExperimentTracker interface."""
    tracker = MagicMock()
    tracker.log_metrics = MagicMock()
    tracker.set_summary = MagicMock()
    tracker.save_file = MagicMock()
    tracker.commit = MagicMock()
    tracker.log_image = MagicMock()
    return tracker


def _make_lr_scheduler_mock(lr: float = 0.001) -> MagicMock:
    """Create a mock lr_scheduler with optimizer.param_groups."""
    scheduler = MagicMock()
    scheduler.optimizer.param_groups = [{"lr": lr}]
    scheduler.state_dict.return_value = {"step_size": 10}
    return scheduler


def _make_model_mock():
    """Create a mock Model with a name and state_dict."""
    model = MagicMock()
    model.name = "test_model"
    model.state_dict.return_value = {"weight": torch.zeros(4)}
    return model


# ── PyTorchModelSaver ───────────────────────────────────────────────────


class TestPyTorchModelSaver:
    @pytest.fixture(autouse=True)
    def _reset_global_settings(self):
        """Ensure GlobalSettings has a fresh EventBus."""
        from srforge import GlobalSettings
        from srforge.observers.bus import EventBus
        gs = GlobalSettings()
        gs.event_bus = EventBus()
        yield
        gs.event_bus = EventBus()

    def test_defaults_to_null_tracker(self):
        from srforge.observers.checkpoint import PyTorchModelSaver
        saver = PyTorchModelSaver()
        assert isinstance(saver.tracker, NullTracker)
        assert saver.best_loss is None

    def test_accepts_custom_tracker(self):
        from srforge.observers.checkpoint import PyTorchModelSaver
        tracker = _make_tracker_mock()
        saver = PyTorchModelSaver(tracker=tracker)
        assert saver.tracker is tracker

    def test_on_training_began_sets_best_loss_from_event(self):
        from srforge.observers.checkpoint import PyTorchModelSaver
        saver = PyTorchModelSaver()
        event = trainer_events.TrainingBegan(
            total_epochs=10,
            initial_epoch=0,
            train_batches_per_epoch=100,
            val_batches_per_epoch=20,
            best_losses={"total": 0.42},
        )
        saver.on_training_began(event)
        assert saver.best_loss == 0.42

    def test_on_training_began_no_overwrite_when_best_loss_set(self):
        from srforge.observers.checkpoint import PyTorchModelSaver
        saver = PyTorchModelSaver(best_loss=0.1)
        event = trainer_events.TrainingBegan(
            total_epochs=10,
            initial_epoch=0,
            train_batches_per_epoch=100,
            val_batches_per_epoch=20,
            best_losses={"total": 0.42},
        )
        saver.on_training_began(event)
        assert saver.best_loss == 0.1  # not overwritten

    def test_on_training_began_noop_when_no_best_losses(self):
        from srforge.observers.checkpoint import PyTorchModelSaver
        saver = PyTorchModelSaver()
        event = trainer_events.TrainingBegan(
            total_epochs=10,
            initial_epoch=0,
            train_batches_per_epoch=100,
            val_batches_per_epoch=20,
            best_losses=None,
        )
        saver.on_training_began(event)
        assert saver.best_loss is None

    @patch("srforge.observers.checkpoint.save_model_weights", return_value=["/out/model_best.pth"])
    @patch("srforge.observers.checkpoint.save_checkpoint")
    def test_on_epoch_finished_saves_best_and_last(self, mock_save_ckpt, mock_save_wt):
        from srforge.observers.checkpoint import PyTorchModelSaver
        from srforge import GlobalSettings

        gs = GlobalSettings()
        gs.output_directory = "/out"

        tracker = _make_tracker_mock()
        saver = PyTorchModelSaver(tracker=tracker)
        model = _make_model_mock()
        scores = _make_metric_scores(0.3)

        event = trainer_events.TrainerEpochFinished(
            model=model,
            train_loss=scores,
            val_loss=scores,
            epoch=1,
            lr_scheduler=_make_lr_scheduler_mock(),
            runner_state={"optimizer": "state"},
        )

        saver.on_epoch_finished(event)

        # First call with no prior best_loss: should save both _best and _last
        assert saver.best_loss == scores.total_weighted().mean()
        assert mock_save_ckpt.call_count == 2  # _best + _last
        assert mock_save_wt.call_count == 2
        tracker.set_summary.assert_any_call("best_epoch", 1)
        tracker.set_summary.assert_any_call("epoch", 1)

    @patch("srforge.observers.checkpoint.save_model_weights", return_value=[])
    @patch("srforge.observers.checkpoint.save_checkpoint")
    def test_on_epoch_finished_only_last_when_no_improvement(self, mock_save_ckpt, mock_save_wt):
        from srforge.observers.checkpoint import PyTorchModelSaver
        from srforge import GlobalSettings

        gs = GlobalSettings()
        gs.output_directory = "/out"

        tracker = _make_tracker_mock()
        saver = PyTorchModelSaver(best_loss=0.01, tracker=tracker)
        scores = _make_metric_scores(0.5)  # worse than 0.01

        event = trainer_events.TrainerEpochFinished(
            model=_make_model_mock(),
            train_loss=scores,
            val_loss=scores,
            epoch=5,
            lr_scheduler=_make_lr_scheduler_mock(),
            runner_state={},
        )

        saver.on_epoch_finished(event)

        # Only _last checkpoint saved (not _best because 0.5 > 0.01)
        assert mock_save_ckpt.call_count == 1
        assert saver.best_loss == 0.01  # unchanged

    @patch("srforge.observers.checkpoint.save_model_weights", return_value=["/out/model_best.pth"])
    @patch("srforge.observers.checkpoint.save_checkpoint")
    def test_save_states_calls_tracker_save_file(self, mock_save_ckpt, mock_save_wt):
        from srforge.observers.checkpoint import PyTorchModelSaver
        from srforge import GlobalSettings

        gs = GlobalSettings()
        gs.output_directory = "/out"

        tracker = _make_tracker_mock()
        saver = PyTorchModelSaver(tracker=tracker)
        scores = _make_metric_scores(0.2)

        event = trainer_events.TrainerEpochFinished(
            model=_make_model_mock(),
            train_loss=scores,
            val_loss=scores,
            epoch=1,
            lr_scheduler=_make_lr_scheduler_mock(),
            runner_state={},
        )

        saver.on_epoch_finished(event)

        # tracker.save_file called for checkpoint and each model weights file
        save_calls = tracker.save_file.call_args_list
        assert len(save_calls) >= 2  # at least checkpoint + weights for _best, then _last


# ── LossLogger ──────────────────────────────────────────────────────────


class TestLossLogger:
    @pytest.fixture(autouse=True)
    def _reset_global_settings(self):
        from srforge import GlobalSettings
        from srforge.observers.bus import EventBus
        gs = GlobalSettings()
        gs.event_bus = EventBus()
        yield
        gs.event_bus = EventBus()

    def test_defaults_to_null_tracker(self):
        from srforge.observers.logging import LossLogger
        logger = LossLogger()
        assert isinstance(logger.tracker, NullTracker)

    def test_accepts_custom_tracker(self):
        from srforge.observers.logging import LossLogger
        tracker = _make_tracker_mock()
        logger = LossLogger(tracker=tracker)
        assert logger.tracker is tracker

    def test_on_epoch_finished_logs_metrics(self):
        from srforge.observers.logging import LossLogger

        tracker = _make_tracker_mock()
        logger = LossLogger(tracker=tracker)

        val_scores = _make_metric_scores(0.3)
        train_scores = _make_metric_scores(0.5)
        lr_sched = _make_lr_scheduler_mock(lr=0.01)

        event = trainer_events.TrainerEpochFinished(
            model=_make_model_mock(),
            train_loss=train_scores,
            val_loss=val_scores,
            epoch=7,
            lr_scheduler=lr_sched,
            runner_state={},
        )

        logger.on_epoch_finished(event)

        tracker.log_metrics.assert_called_once()
        logged = tracker.log_metrics.call_args
        metrics = logged[0][0]
        assert "validation_loss" in metrics
        assert "training_loss" in metrics
        assert "learning_rate" in metrics
        assert metrics["epoch"] == 7
        assert metrics["learning_rate"] == {0: 0.01}
        assert logged[1]["step"] == 7

        tracker.commit.assert_called_once_with(step=7)

    def test_on_epoch_finished_multiple_param_groups(self):
        from srforge.observers.logging import LossLogger

        tracker = _make_tracker_mock()
        logger = LossLogger(tracker=tracker)

        lr_sched = MagicMock()
        lr_sched.optimizer.param_groups = [
            {"lr": 0.01},
            {"lr": 0.001},
        ]

        scores = _make_metric_scores(0.2)
        event = trainer_events.TrainerEpochFinished(
            model=_make_model_mock(),
            train_loss=scores,
            val_loss=scores,
            epoch=3,
            lr_scheduler=lr_sched,
            runner_state={},
        )

        logger.on_epoch_finished(event)

        metrics = tracker.log_metrics.call_args[0][0]
        assert metrics["learning_rate"] == {0: 0.01, 1: 0.001}


# ── ProgressBar ─────────────────────────────────────────────────────────


class TestProgressBar:
    @pytest.fixture(autouse=True)
    def _reset_global_settings(self):
        from srforge import GlobalSettings
        from srforge.observers.bus import EventBus
        gs = GlobalSettings()
        gs.event_bus = EventBus()
        yield
        gs.event_bus = EventBus()

    def test_init_defaults(self):
        from srforge.observers.logging import ProgressBar
        pb = ProgressBar(name="train")
        assert pb._name == "train"
        assert pb._progress is None
        assert pb._count == 0
        assert pb._sum == {}

    @patch("sys.stdout")
    def test_on_epoch_started_creates_progress(self, mock_stdout):
        from srforge.observers.logging import ProgressBar

        mock_stdout.isatty.return_value = False
        pb = ProgressBar(name="val")

        event = runner_events.RunnerEpochStarted(
            epoch=1,
            dataset_size=100,
            batch_size=10,
            num_batches=10,
        )

        pb.on_epoch_started(event)

        assert pb._progress is not None
        assert pb._started is True  # _render sets it
        assert pb._count == 0
        assert pb._sum == {}

    @patch("sys.stdout")
    def test_on_batch_finished_updates_progress(self, mock_stdout):
        from srforge.observers.logging import ProgressBar

        mock_stdout.isatty.return_value = False
        pb = ProgressBar(name="train")

        # Start epoch first
        start_event = runner_events.RunnerEpochStarted(
            epoch=1,
            dataset_size=32,
            batch_size=8,
            num_batches=4,
        )
        pb.on_epoch_started(start_event)

        batch_scores = _make_metric_scores(0.4)
        batch_event = runner_events.RunnerBatchFinished(
            epoch=1,
            batch=0,
            entry=MagicMock(),
            batch_scores=batch_scores,
            criterion=None,
            epoch_scores=_make_metric_scores(0.4),
        )

        pb.on_batch_finished(batch_event)

        assert pb._count > 0
        assert len(pb._sum) > 0

    @patch("sys.stdout")
    def test_on_batch_finished_noop_without_epoch_start(self, mock_stdout):
        """on_batch_finished returns early if _progress is None."""
        from srforge.observers.logging import ProgressBar

        mock_stdout.isatty.return_value = False
        pb = ProgressBar(name="train")

        batch_scores = _make_metric_scores(0.4)
        batch_event = runner_events.RunnerBatchFinished(
            epoch=1,
            batch=0,
            entry=MagicMock(),
            batch_scores=batch_scores,
            criterion=None,
            epoch_scores=_make_metric_scores(0.4),
        )

        # Should not raise even without prior on_epoch_started
        pb.on_batch_finished(batch_event)
        assert pb._count == 0

    @patch("sys.stdout")
    def test_on_epoch_finished_resets_state(self, mock_stdout):
        from srforge.observers.logging import ProgressBar

        mock_stdout.isatty.return_value = False
        pb = ProgressBar(name="train")

        # Start epoch
        start_event = runner_events.RunnerEpochStarted(
            epoch=1,
            dataset_size=32,
            batch_size=8,
            num_batches=4,
        )
        pb.on_epoch_started(start_event)
        assert pb._progress is not None

        # Finish epoch
        finish_event = runner_events.RunnerEpochFinished(
            epoch=1,
            epoch_scores=_make_metric_scores(0.3),
        )
        pb.on_epoch_finished(finish_event)

        assert pb._progress is None
        assert pb._console is None
        assert pb._task_id is None
        assert pb._started is False
        assert pb._sum == {}
        assert pb._count == 0

    @patch("sys.stdout")
    def test_on_epoch_finished_noop_without_progress(self, mock_stdout):
        """on_epoch_finished is a no-op if _progress is already None."""
        from srforge.observers.logging import ProgressBar

        mock_stdout.isatty.return_value = False
        pb = ProgressBar(name="train")

        finish_event = runner_events.RunnerEpochFinished(
            epoch=1,
            epoch_scores=_make_metric_scores(0.3),
        )
        # Should not raise
        pb.on_epoch_finished(finish_event)

    @patch("sys.stdout")
    def test_multiple_batches_accumulate_scores(self, mock_stdout):
        from srforge.observers.logging import ProgressBar

        mock_stdout.isatty.return_value = False
        pb = ProgressBar(name="train")

        start_event = runner_events.RunnerEpochStarted(
            epoch=1,
            dataset_size=16,
            batch_size=4,
            num_batches=4,
        )
        pb.on_epoch_started(start_event)

        for i in range(3):
            batch_scores = _make_metric_scores(0.1 * (i + 1))
            batch_event = runner_events.RunnerBatchFinished(
                epoch=1,
                batch=i,
                entry=MagicMock(),
                batch_scores=batch_scores,
                criterion=None,
                epoch_scores=_make_metric_scores(0.1),
            )
            pb.on_batch_finished(batch_event)

        assert pb._count == 3  # 3 batches, each size 1

    @patch("sys.stdout")
    def test_tty_render_uses_ansi_clear(self, mock_stdout):
        """When stdout is a TTY, _render uses ANSI escape codes."""
        from srforge.observers.logging import ProgressBar

        mock_stdout.isatty.return_value = True
        mock_stdout.write = MagicMock()
        mock_stdout.flush = MagicMock()

        pb = ProgressBar(name="train")

        start_event = runner_events.RunnerEpochStarted(
            epoch=1,
            dataset_size=8,
            batch_size=4,
            num_batches=2,
        )
        pb.on_epoch_started(start_event)
        assert pb._is_tty is True


# ── BatchImageSaver ─────────────────────────────────────────────────────


class TestBatchImageSaver:
    @pytest.fixture(autouse=True)
    def _reset_global_settings(self):
        from srforge import GlobalSettings
        from srforge.observers.bus import EventBus
        gs = GlobalSettings()
        gs.event_bus = EventBus()
        yield
        gs.event_bus = EventBus()

    def test_init_single_batch_id_becomes_list(self):
        from srforge.observers.image import BatchImageSaver
        saver = BatchImageSaver(batch_id=3)
        assert saver.batch_id == [3]

    def test_init_range_batch_id_becomes_list(self):
        from srforge.observers.image import BatchImageSaver
        saver = BatchImageSaver(batch_id=range(0, 5))
        assert saver.batch_id == [0, 1, 2, 3, 4]

    def test_init_none_batch_id(self):
        from srforge.observers.image import BatchImageSaver
        saver = BatchImageSaver(batch_id=None)
        assert saver.batch_id is None

    def test_init_dtype_parsing(self):
        from srforge.observers.image import BatchImageSaver
        saver = BatchImageSaver(dtype="uint16")
        assert saver.dtype == np.dtype("uint16")

    def test_init_fmt_strips_dot(self):
        from srforge.observers.image import BatchImageSaver
        saver = BatchImageSaver(fmt=".tiff")
        assert saver.fmt == "tiff"

    @patch("cv2.imwrite", return_value=True)
    def test_on_batch_finished_saves_image(self, mock_imwrite, tmp_path):
        from srforge.observers.image import BatchImageSaver

        saver = BatchImageSaver(
            batch_id=[0],
            output_path=str(tmp_path),
            img_key="sr",
            fmt="png",
            dtype="uint8",
        )

        # 1 image of 3 channels
        img_tensor = torch.rand(1, 3, 16, 16)
        entry = MagicMock()
        entry.__getitem__ = MagicMock(return_value=img_tensor)
        entry.name = ["test_img"]

        batch_scores = _make_metric_scores(0.2)
        event = runner_events.RunnerBatchFinished(
            epoch=1,
            batch=0,
            entry=entry,
            batch_scores=batch_scores,
            criterion=None,
            epoch_scores=batch_scores,
        )

        saver.on_batch_finished(event)

        mock_imwrite.assert_called_once()
        call_path = mock_imwrite.call_args[0][0]
        assert "test_img.png" in call_path

    def test_on_batch_finished_skips_non_matching_batch_id(self, tmp_path):
        from srforge.observers.image import BatchImageSaver

        saver = BatchImageSaver(
            batch_id=[5],  # only save batch 5
            output_path=str(tmp_path),
        )

        img_tensor = torch.rand(1, 3, 8, 8)
        entry = MagicMock()
        entry.__getitem__ = MagicMock(return_value=img_tensor)
        entry.name = ["img0"]

        event = runner_events.RunnerBatchFinished(
            epoch=1,
            batch=0,
            entry=entry,
            batch_scores=_make_metric_scores(0.1),
            criterion=None,
            epoch_scores=_make_metric_scores(0.1),
        )

        with patch("cv2.imwrite") as mock_imwrite:
            saver.on_batch_finished(event)
            mock_imwrite.assert_not_called()

    def test_on_runner_epoch_finished_resets_step(self):
        from srforge.observers.image import BatchImageSaver

        saver = BatchImageSaver(batch_id=[0])
        saver.step = 5

        event = runner_events.RunnerEpochFinished(
            epoch=1,
            epoch_scores=_make_metric_scores(0.1),
        )
        saver.on_runner_epoch_finished(event)
        assert saver.step == -1


# ── BatchImageLogger ────────────────────────────────────────────────────


class TestBatchImageLogger:
    @pytest.fixture(autouse=True)
    def _reset_global_settings(self):
        from srforge import GlobalSettings
        from srforge.observers.bus import EventBus
        gs = GlobalSettings()
        gs.event_bus = EventBus()
        yield
        gs.event_bus = EventBus()

    def test_defaults_to_null_tracker(self):
        from srforge.observers.image import BatchImageLogger
        logger = BatchImageLogger()
        assert isinstance(logger.tracker, NullTracker)

    def test_init_batch_id_coercion(self):
        from srforge.observers.image import BatchImageLogger
        assert BatchImageLogger(batch_id=2).batch_id == [2]
        assert BatchImageLogger(batch_id=range(3)).batch_id == [0, 1, 2]
        assert BatchImageLogger(batch_id=None).batch_id is None

    def test_make_channel_grid_shape(self):
        from srforge.observers.image import BatchImageLogger

        logger = BatchImageLogger(max_channels=4)
        img = np.random.rand(10, 10, 4).astype(np.float32)
        grid = logger._make_channel_grid(img)

        # 4 channels -> 2x2 grid
        assert grid.ndim == 2
        assert grid.shape[0] > 10
        assert grid.shape[1] > 10

    def test_make_channel_grid_clips_channels(self):
        from srforge.observers.image import BatchImageLogger

        logger = BatchImageLogger(max_channels=3)
        img = np.random.rand(8, 8, 10).astype(np.float32)
        grid = logger._make_channel_grid(img)

        # Only first 3 channels used, 2x2 grid for 3 channels
        assert grid.ndim == 2

    def test_on_batch_finished_logs_tensor_image(self):
        from srforge.observers.image import BatchImageLogger

        tracker = _make_tracker_mock()
        logger = BatchImageLogger(
            batch_id=[0],
            tracker=tracker,
            img_key="sr",
            step_mode="epoch",
        )

        img_tensor = torch.rand(1, 3, 16, 16)
        entry = MagicMock()
        entry.__getitem__ = MagicMock(return_value=img_tensor)
        entry.name = ["sample"]

        event = runner_events.RunnerBatchFinished(
            epoch=5,
            batch=0,
            entry=entry,
            batch_scores=_make_metric_scores(0.1),
            criterion=None,
            epoch_scores=_make_metric_scores(0.1),
        )

        logger.on_batch_finished(event)

        tracker.log_image.assert_called_once()
        call_args = tracker.log_image.call_args
        assert call_args[0][0] == "val_pred"  # default log_dir
        assert call_args[1]["step"] == 5  # epoch mode
        assert call_args[1]["caption"] == "sample"

    def test_on_batch_finished_dict_image_logs_per_band(self):
        from srforge.observers.image import BatchImageLogger

        tracker = _make_tracker_mock()
        logger = BatchImageLogger(
            batch_id=[0],
            tracker=tracker,
            img_key="sr",
        )

        img_dict = {
            "red": torch.rand(1, 1, 8, 8),
            "green": torch.rand(1, 1, 8, 8),
        }
        entry = MagicMock()
        entry.__getitem__ = MagicMock(return_value=img_dict)
        entry.name = ["multi_band"]

        event = runner_events.RunnerBatchFinished(
            epoch=2,
            batch=0,
            entry=entry,
            batch_scores=_make_metric_scores(0.1),
            criterion=None,
            epoch_scores=_make_metric_scores(0.1),
        )

        logger.on_batch_finished(event)

        assert tracker.log_image.call_count == 2  # one per band

    def test_on_runner_epoch_finished_resets_step(self):
        from srforge.observers.image import BatchImageLogger

        logger = BatchImageLogger()
        logger.step = 10

        event = runner_events.RunnerEpochFinished(
            epoch=1,
            epoch_scores=_make_metric_scores(0.1),
        )
        logger.on_runner_epoch_finished(event)
        assert logger.step == -1


# ── Image module helpers ────────────────────────────────────────────────


class TestImageHelpers:
    def test_to_hwc_numpy(self):
        from srforge.observers.image import _to_hwc_numpy
        tensor = torch.rand(2, 3, 8, 8)
        result = _to_hwc_numpy(tensor)
        assert result.shape == (8, 8, 3)
        assert isinstance(result, np.ndarray)

    def test_apply_transforms(self):
        from srforge.observers.image import _apply_transforms
        transform = MagicMock()
        transform.transform.return_value = torch.rand(1, 3, 8, 8)

        tensor = torch.rand(1, 3, 8, 8)
        result = _apply_transforms(tensor, [transform])
        transform.transform.assert_called_once()
