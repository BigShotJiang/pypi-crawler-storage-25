"""Integration tests verifying that all three IO binding approaches produce equivalent results.

Approaches tested:
1. **Config-based**: ConfigResolver instantiates models with IO from config dicts.
2. **Programmatic**: Direct set_io() calls on model instances.
3. **SequentialModel flow DSL**: Flow string syntax.

All three must produce identical forward outputs and consistent io_spec state.
"""

import pytest
import torch

from omegaconf import OmegaConf

from srforge.config.resolver import ConfigResolver
from srforge.data import Entry
from srforge.models import Model, SequentialModel
from srforge.registry import register_class
from srforge.utils import IOSpec


# ---------------------------------------------------------------------------
# Test models
# ---------------------------------------------------------------------------


@register_class("_DoubleModel")
class _DoubleModel(Model):
    """Doubles its input: output = image * 2."""

    io_spec = IOSpec(required_inputs=("image",), required_outputs=("output",))

    def __init__(self):
        super().__init__()

    def _forward(self, image):
        return image * 2


@register_class("_AddTenModel")
class _AddTenModel(Model):
    """Adds ten to its input: output = image + 10."""

    io_spec = IOSpec(required_inputs=("image",), required_outputs=("output",))

    def __init__(self):
        super().__init__()

    def _forward(self, image):
        return image + 10


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _t(*values):
    """Shorthand for creating a float tensor."""
    return torch.tensor(list(values), dtype=torch.float32)


def _resolver(cfg_dict):
    """Create a ConfigResolver from a plain dict."""
    cfg = OmegaConf.create(cfg_dict)
    return ConfigResolver(cfg)


def _make_input_entry():
    """Canonical input entry used across all tests for equivalence checks."""
    return Entry(x=_t(1, 2, 3))


# ===========================================================================
# Individual binding approach tests
# ===========================================================================


class TestProgrammaticSetIO:
    """Verify programmatic set_io binds correctly and populates io_spec."""

    def test_forward_produces_correct_output(self):
        model = _DoubleModel()
        model.set_io({"inputs": {"image": "x"}, "outputs": "y"})

        result = model(_make_input_entry())
        assert torch.equal(result["y"], _t(2, 4, 6))

    def test_io_spec_populated_after_binding(self):
        model = _DoubleModel()
        model.set_io({"inputs": {"image": "x"}, "outputs": "y"})

        spec = model.io_spec
        assert "image" in spec.all_inputs
        assert "y" in spec.all_outputs

    def test_io_bound_flag_set(self):
        model = _DoubleModel()
        assert not model._io_bound
        model.set_io({"inputs": {"image": "x"}, "outputs": "y"})
        assert model._io_bound


class TestConfigBasedIO:
    """Verify ConfigResolver instantiation with IO from config dicts."""

    def test_forward_produces_correct_output(self):
        resolver = _resolver({
            "model": {
                "_target": "_DoubleModel",
                "params": {},
                "io": {"inputs": {"image": "x"}, "outputs": "y"},
            },
        })
        result = resolver.resolve_all()
        model = result["model"]

        out = model(_make_input_entry())
        assert torch.equal(out["y"], _t(2, 4, 6))

    def test_io_spec_populated_after_binding(self):
        resolver = _resolver({
            "model": {
                "_target": "_DoubleModel",
                "params": {},
                "io": {"inputs": {"image": "x"}, "outputs": "y"},
            },
        })
        model = resolver.resolve_all()["model"]

        spec = model.io_spec
        assert "image" in spec.all_inputs
        assert "y" in spec.all_outputs

    def test_io_bound_flag_set(self):
        resolver = _resolver({
            "model": {
                "_target": "_DoubleModel",
                "params": {},
                "io": {"inputs": {"image": "x"}, "outputs": "y"},
            },
        })
        model = resolver.resolve_all()["model"]
        assert model._io_bound


class TestSequentialModelFlowDSL:
    """Verify SequentialModel flow DSL binds IO correctly."""

    def test_forward_produces_correct_output(self):
        seq = SequentialModel(
            modules={"m": _DoubleModel()},
            flow=["x -> m -> y"],
        )
        result = seq(_make_input_entry())
        assert torch.equal(result["y"], _t(2, 4, 6))

    def test_io_spec_populated_with_inputs_and_outputs(self):
        seq = SequentialModel(
            modules={"m": _DoubleModel()},
            flow=["x -> m -> y"],
        )
        spec = seq.io_spec
        assert "x" in spec.all_inputs
        assert "y" in spec.all_outputs

    def test_named_input_mapping(self):
        """Named LHS mapping (image=x) -> m -> y works identically."""
        seq = SequentialModel(
            modules={"m": _DoubleModel()},
            flow=["(image=x) -> m -> y"],
        )
        result = seq(_make_input_entry())
        assert torch.equal(result["y"], _t(2, 4, 6))


# ===========================================================================
# Cross-approach equivalence
# ===========================================================================


class TestEquivalentResults:
    """All three binding approaches must produce identical output values."""

    def test_same_output_values(self):
        # Approach 1: programmatic
        m1 = _DoubleModel()
        m1.set_io({"inputs": {"image": "x"}, "outputs": "y"})
        out1 = m1(Entry(x=_t(1, 2, 3)))

        # Approach 2: config-based
        resolver = _resolver({
            "model": {
                "_target": "_DoubleModel",
                "params": {},
                "io": {"inputs": {"image": "x"}, "outputs": "y"},
            },
        })
        m2 = resolver.resolve_all()["model"]
        out2 = m2(Entry(x=_t(1, 2, 3)))

        # Approach 3: flow DSL
        seq = SequentialModel(
            modules={"m": _DoubleModel()},
            flow=["x -> m -> y"],
        )
        out3 = seq(Entry(x=_t(1, 2, 3)))

        # All three must produce the same "y" value
        assert torch.equal(out1["y"], out2["y"])
        assert torch.equal(out2["y"], out3["y"])
        assert torch.equal(out1["y"], _t(2, 4, 6))

    def test_original_entry_field_preserved(self):
        """All approaches preserve the original 'x' field in the output Entry."""
        m1 = _DoubleModel()
        m1.set_io({"inputs": {"image": "x"}, "outputs": "y"})
        out1 = m1(Entry(x=_t(1, 2, 3)))

        seq = SequentialModel(
            modules={"m": _DoubleModel()},
            flow=["x -> m -> y"],
        )
        out3 = seq(Entry(x=_t(1, 2, 3)))

        assert torch.equal(out1["x"], _t(1, 2, 3))
        assert torch.equal(out3["x"], _t(1, 2, 3))


# ===========================================================================
# io_spec consistency across approaches
# ===========================================================================


class TestIOSpecConsistency:
    """All three approaches must result in equivalent io_spec content."""

    def test_all_inputs_match(self):
        # Programmatic
        m1 = _DoubleModel()
        m1.set_io({"inputs": {"image": "x"}, "outputs": "y"})

        # Config-based
        resolver = _resolver({
            "model": {
                "_target": "_DoubleModel",
                "params": {},
                "io": {"inputs": {"image": "x"}, "outputs": "y"},
            },
        })
        m2 = resolver.resolve_all()["model"]

        # Both programmatic and config produce the same io_spec inputs
        assert set(m1.io_spec.all_inputs) == set(m2.io_spec.all_inputs)

    def test_all_outputs_match(self):
        # Programmatic
        m1 = _DoubleModel()
        m1.set_io({"inputs": {"image": "x"}, "outputs": "y"})

        # Config-based
        resolver = _resolver({
            "model": {
                "_target": "_DoubleModel",
                "params": {},
                "io": {"inputs": {"image": "x"}, "outputs": "y"},
            },
        })
        m2 = resolver.resolve_all()["model"]

        # Both produce the same io_spec outputs
        assert set(m1.io_spec.all_outputs) == set(m2.io_spec.all_outputs)

    def test_sequential_io_spec_reflects_entry_fields(self):
        """SequentialModel io_spec uses Entry field names (not param names)."""
        seq = SequentialModel(
            modules={"m": _DoubleModel()},
            flow=["x -> m -> y"],
        )
        # SequentialModel io_spec tracks the Entry-level field names
        assert "x" in seq.io_spec.all_inputs
        assert "y" in seq.io_spec.all_outputs

    def test_programmatic_and_config_io_spec_use_param_names(self):
        """Programmatic/config io_spec uses parameter names for inputs."""
        m1 = _DoubleModel()
        m1.set_io({"inputs": {"image": "x"}, "outputs": "y"})

        # Model io_spec tracks the _forward parameter names, not Entry field names
        assert "image" in m1.io_spec.all_inputs
        # Output is the Entry field name from set_io
        assert "y" in m1.io_spec.all_outputs


# ===========================================================================
# Multi-step flow
# ===========================================================================


class TestMultiStepFlow:
    """Chain two models in a SequentialModel flow."""

    def test_two_step_chain_produces_correct_result(self):
        """x -> dbl -> intermediate, intermediate -> add10 -> final."""
        seq = SequentialModel(
            modules={"dbl": _DoubleModel(), "add10": _AddTenModel()},
            flow=[
                "x -> dbl -> intermediate",
                "intermediate -> add10 -> final",
            ],
        )
        result = seq(_make_input_entry())

        # x=[1,2,3] -> dbl -> [2,4,6] -> add10 -> [12,14,16]
        assert torch.equal(result["intermediate"], _t(2, 4, 6))
        assert torch.equal(result["final"], _t(12, 14, 16))

    def test_two_step_chain_preserves_original_input(self):
        seq = SequentialModel(
            modules={"dbl": _DoubleModel(), "add10": _AddTenModel()},
            flow=[
                "x -> dbl -> intermediate",
                "intermediate -> add10 -> final",
            ],
        )
        result = seq(_make_input_entry())
        assert torch.equal(result["x"], _t(1, 2, 3))

    def test_two_step_io_spec_tracks_all_fields(self):
        seq = SequentialModel(
            modules={"dbl": _DoubleModel(), "add10": _AddTenModel()},
            flow=[
                "x -> dbl -> intermediate",
                "intermediate -> add10 -> final",
            ],
        )
        spec = seq.io_spec
        # Only "x" is a true external input; "intermediate" is produced internally
        assert "x" in spec.all_inputs
        # Both outputs should be declared
        assert "intermediate" in spec.all_outputs
        assert "final" in spec.all_outputs

    def test_two_step_chain_with_named_inputs(self):
        """Named input mapping works in multi-step flows."""
        seq = SequentialModel(
            modules={"dbl": _DoubleModel(), "add10": _AddTenModel()},
            flow=[
                "(image=x) -> dbl -> mid",
                "(image=mid) -> add10 -> out",
            ],
        )
        result = seq(_make_input_entry())
        assert torch.equal(result["mid"], _t(2, 4, 6))
        assert torch.equal(result["out"], _t(12, 14, 16))

    def test_same_model_reused_in_two_steps(self):
        """A single model instance can appear in multiple flow lines."""
        dbl = _DoubleModel()
        seq = SequentialModel(
            modules={"dbl": dbl},
            flow=[
                "x -> dbl -> y",
                "y -> dbl -> z",
            ],
        )
        result = seq(_make_input_entry())
        # x=[1,2,3] -> dbl -> [2,4,6] -> dbl -> [4,8,12]
        assert torch.equal(result["y"], _t(2, 4, 6))
        assert torch.equal(result["z"], _t(4, 8, 12))
