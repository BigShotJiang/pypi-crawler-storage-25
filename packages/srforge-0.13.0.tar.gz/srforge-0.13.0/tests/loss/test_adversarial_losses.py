"""Tests for RaGAN adversarial losses — discriminator and generator."""

import pytest
import torch
import torch.nn.functional as F

from srforge.data import Entry
from srforge.loss import Loss
from srforge.loss.adversarial import RaGANDiscriminatorLoss, RaGANGeneratorLoss
from srforge.models import Model, GANModel
from srforge.utils import IOSpec


# ---------------------------------------------------------------------------
# Dummy models for integration tests
# ---------------------------------------------------------------------------


class _Generator(Model):
    def __init__(self):
        super().__init__()
        self.linear = torch.nn.Linear(4, 4, bias=False)
        torch.nn.init.ones_(self.linear.weight)

    def forward(self, x):
        return self.linear(x)


class _Discriminator(Model):
    def __init__(self):
        super().__init__()
        self.linear = torch.nn.Linear(4, 1, bias=False)
        torch.nn.init.ones_(self.linear.weight)

    def forward(self, img):
        return self.linear(img)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _manual_ragan_d_loss(real_score, fake_score):
    """Reference implementation of RaGAN discriminator loss (per-sample)."""
    real_mean = real_score.mean()
    fake_mean = fake_score.mean()
    loss_real = F.binary_cross_entropy_with_logits(
        real_score - fake_mean, torch.ones_like(real_score),
        reduction='none')
    loss_fake = F.binary_cross_entropy_with_logits(
        fake_score - real_mean, torch.zeros_like(fake_score),
        reduction='none')
    return (loss_real + loss_fake) / 2


def _manual_ragan_g_loss(real_score, fake_score):
    """Reference implementation of RaGAN generator loss (per-sample)."""
    real_mean = real_score.mean()
    fake_mean = fake_score.mean()
    loss_real = F.binary_cross_entropy_with_logits(
        real_score - fake_mean, torch.zeros_like(real_score),
        reduction='none')
    loss_fake = F.binary_cross_entropy_with_logits(
        fake_score - real_mean, torch.ones_like(fake_score),
        reduction='none')
    return (loss_real + loss_fake) / 2


# ---------------------------------------------------------------------------
# calculate_score correctness
# ---------------------------------------------------------------------------


def test_discriminator_loss_known_values():
    """Verify RaGAN D loss matches the relativistic average formulation."""
    loss = RaGANDiscriminatorLoss()
    real = torch.tensor([1.0, 2.0, 3.0])
    fake = torch.tensor([-1.0, 0.0, 1.0])
    result = loss.calculate_score(real, fake)
    expected = _manual_ragan_d_loss(real, fake)
    assert torch.allclose(result, expected, atol=1e-6)


def test_generator_loss_known_values():
    """Verify RaGAN G loss matches the relativistic average formulation."""
    loss = RaGANGeneratorLoss()
    real = torch.tensor([1.0, 2.0, 3.0])
    fake = torch.tensor([-1.0, 0.0, 1.0])
    result = loss.calculate_score(real, fake)
    expected = _manual_ragan_g_loss(real, fake)
    assert torch.allclose(result, expected, atol=1e-6)


def test_discriminator_loss_symmetric_inputs():
    """When real == fake, every sample's loss should be log(2) (BCE at logit 0)."""
    loss = RaGANDiscriminatorLoss()
    scores = torch.tensor([1.0, 1.0])
    result = loss.calculate_score(scores, scores)
    # real - fake.mean() == 0, fake - real.mean() == 0
    # BCE(0, 1) = log(2), BCE(0, 0) = log(2) — per sample
    expected = torch.tensor([0.6931471805599453, 0.6931471805599453])
    assert torch.allclose(result, expected, atol=1e-5)


def test_generator_loss_symmetric_inputs():
    """When real == fake, every sample's loss should be log(2)."""
    loss = RaGANGeneratorLoss()
    scores = torch.tensor([1.0, 1.0])
    result = loss.calculate_score(scores, scores)
    expected = torch.tensor([0.6931471805599453, 0.6931471805599453])
    assert torch.allclose(result, expected, atol=1e-5)


def test_discriminator_loss_batch_dimension():
    """Loss should return per-sample values matching input batch size."""
    loss = RaGANDiscriminatorLoss()
    real = torch.randn(8)
    fake = torch.randn(8)
    result = loss.calculate_score(real, fake)
    assert result.shape == (8,)


def test_generator_loss_batch_dimension():
    loss = RaGANGeneratorLoss()
    real = torch.randn(8)
    fake = torch.randn(8)
    result = loss.calculate_score(real, fake)
    assert result.shape == (8,)


# ---------------------------------------------------------------------------
# Entry-based calling
# ---------------------------------------------------------------------------


def test_discriminator_loss_entry_call():
    """loss(entry) reads real_score and fake_score from entry."""
    loss = RaGANDiscriminatorLoss()
    real = torch.tensor([2.0, 3.0])
    fake = torch.tensor([0.5, 1.5])
    entry = Entry(name="test", real_score=real, fake_score=fake)

    scores = loss(entry)
    expected = _manual_ragan_d_loss(real, fake)
    assert torch.allclose(scores.as_raw_dict()["RaGANDiscriminatorLoss"], expected, atol=1e-6)


def test_generator_loss_entry_call():
    loss = RaGANGeneratorLoss()
    real = torch.tensor([2.0, 3.0])
    fake = torch.tensor([0.5, 1.5])
    entry = Entry(name="test", real_score=real, fake_score=fake)

    scores = loss(entry)
    expected = _manual_ragan_g_loss(real, fake)
    assert torch.allclose(scores.as_raw_dict()["RaGANGeneratorLoss"], expected, atol=1e-6)


def test_entry_call_missing_field_raises():
    loss = RaGANDiscriminatorLoss()
    entry = Entry(name="test", real_score=torch.tensor([1.0]))
    with pytest.raises(KeyError, match="fake_score"):
        loss(entry)


# ---------------------------------------------------------------------------
# set_io binding
# ---------------------------------------------------------------------------


def test_discriminator_loss_set_io_remaps_fields():
    loss = RaGANDiscriminatorLoss()
    loss.set_io({"inputs": {"real_score": "real_score_d", "fake_score": "fake_score_d"}})

    real = torch.tensor([2.0])
    fake = torch.tensor([0.5])
    entry = Entry(name="test", real_score_d=real, fake_score_d=fake)

    scores = loss(entry)
    expected = _manual_ragan_d_loss(real, fake)
    assert torch.allclose(scores.as_raw_dict()["RaGANDiscriminatorLoss"], expected, atol=1e-6)


def test_generator_loss_set_io_remaps_fields():
    loss = RaGANGeneratorLoss()
    loss.set_io({"inputs": {"real_score": "real_score_g", "fake_score": "fake_score_g"}})

    real = torch.tensor([2.0])
    fake = torch.tensor([0.5])
    entry = Entry(name="test", real_score_g=real, fake_score_g=fake)

    scores = loss(entry)
    expected = _manual_ragan_g_loss(real, fake)
    assert torch.allclose(scores.as_raw_dict()["RaGANGeneratorLoss"], expected, atol=1e-6)


def test_set_io_rejects_unknown_param():
    loss = RaGANDiscriminatorLoss()
    with pytest.raises(ValueError, match="not found in calculate_score"):
        loss.set_io({"inputs": {"real_score": "a", "fake_score": "b", "bad": "c"}})


def test_set_io_rejects_outputs():
    loss = RaGANDiscriminatorLoss()
    with pytest.raises(TypeError, match="don't produce outputs"):
        loss.set_io({"inputs": {"real_score": "a", "fake_score": "b"}, "outputs": "out"})


def test_set_io_returns_self():
    loss = RaGANDiscriminatorLoss()
    result = loss.set_io({"inputs": {"real_score": "a", "fake_score": "b"}})
    assert result is loss


def test_set_io_chainable():
    loss = (
        RaGANGeneratorLoss()
        .set_io({"inputs": {"real_score": "r", "fake_score": "f"}})
    )
    assert loss._input_map["real_score"] == "r"
    assert loss._input_map["fake_score"] == "f"


# ---------------------------------------------------------------------------
# best_min property
# ---------------------------------------------------------------------------


def test_discriminator_loss_best_min():
    assert RaGANDiscriminatorLoss().best_min is True


def test_generator_loss_best_min():
    assert RaGANGeneratorLoss().best_min is True


# ---------------------------------------------------------------------------
# is a Loss subclass
# ---------------------------------------------------------------------------


def test_discriminator_loss_is_loss():
    assert isinstance(RaGANDiscriminatorLoss(), Loss)


def test_generator_loss_is_loss():
    assert isinstance(RaGANGeneratorLoss(), Loss)


# ---------------------------------------------------------------------------
# Gradient flow
# ---------------------------------------------------------------------------


def test_discriminator_loss_backward_produces_gradients():
    real = torch.randn(4, requires_grad=True)
    fake = torch.randn(4, requires_grad=True)
    loss = RaGANDiscriminatorLoss()
    result = loss.calculate_score(real, fake)
    result.mean().backward()
    assert real.grad is not None
    assert fake.grad is not None


def test_generator_loss_backward_produces_gradients():
    real = torch.randn(4, requires_grad=True)
    fake = torch.randn(4, requires_grad=True)
    loss = RaGANGeneratorLoss()
    result = loss.calculate_score(real, fake)
    result.mean().backward()
    assert real.grad is not None
    assert fake.grad is not None


def test_entry_based_backward():
    """Loss computed from Entry should still support backward."""
    real = torch.randn(4, requires_grad=True)
    fake = torch.randn(4, requires_grad=True)
    loss = RaGANDiscriminatorLoss()
    entry = Entry(name="test", real_score=real, fake_score=fake)

    scores = loss(entry)
    raw = scores.as_raw_dict()["RaGANDiscriminatorLoss"]
    raw.mean().backward()
    assert real.grad is not None
    assert fake.grad is not None


# ---------------------------------------------------------------------------
# Integration with GANModel
# ---------------------------------------------------------------------------


def _build_full_pipeline():
    """Build GANModel + adversarial losses with proper IO binding."""
    gen = _Generator()
    gen.set_io({"inputs": {"x": "lr"}, "outputs": "sr"})
    disc = _Discriminator()
    gan = GANModel(generator=gen, discriminator=disc)
    gan.set_io({"inputs": {"real_field": "hr", "fake_field": "sr"}})

    d_loss = RaGANDiscriminatorLoss()
    d_loss.set_io({"inputs": {"real_score": "real_score_d", "fake_score": "fake_score_d"}})

    g_loss = RaGANGeneratorLoss()
    g_loss.set_io({"inputs": {"real_score": "real_score_g", "fake_score": "fake_score_g"}})

    return gan, d_loss, g_loss


def test_integration_d_loss_reads_gan_scores():
    """D loss reads scores produced by GANModel's discriminator step."""
    gan, d_loss, _ = _build_full_pipeline()
    entry = Entry(name="test", lr=torch.randn(1, 4), hr=torch.randn(1, 4))
    entry = gan(entry)  # produces sr
    entry = gan.discriminator_step(entry)

    scores = d_loss(entry)
    raw = scores.as_raw_dict()["RaGANDiscriminatorLoss"]
    assert isinstance(raw, torch.Tensor)
    assert raw.numel() >= 1


def test_integration_g_loss_reads_gan_scores():
    """G loss reads scores produced by GANModel's generator step."""
    gan, _, g_loss = _build_full_pipeline()
    entry = Entry(name="test", lr=torch.randn(1, 4), hr=torch.randn(1, 4))
    entry = gan(entry)
    entry = gan.discriminator_step(entry)
    entry = gan.generator_step(entry)

    scores = g_loss(entry)
    raw = scores.as_raw_dict()["RaGANGeneratorLoss"]
    assert isinstance(raw, torch.Tensor)
    assert raw.numel() >= 1


def test_integration_g_loss_backward_reaches_generator():
    """Full pipeline: G loss backward should produce gradients on generator."""
    gan, _, g_loss = _build_full_pipeline()
    entry = Entry(name="test", lr=torch.randn(1, 4), hr=torch.randn(1, 4))
    entry = gan(entry)
    entry = gan.discriminator_step(entry)
    entry = gan.generator_step(entry)

    scores = g_loss(entry)
    raw = scores.as_raw_dict()["RaGANGeneratorLoss"]
    raw.mean().backward()

    for p in gan.generator.parameters():
        assert p.grad is not None, "Generator gradient missing after G loss backward"


def test_integration_d_loss_no_generator_grad():
    """D loss backward should NOT produce gradients on generator params."""
    gan, d_loss, _ = _build_full_pipeline()
    entry = Entry(name="test", lr=torch.randn(1, 4), hr=torch.randn(1, 4))
    entry = gan(entry)
    entry = gan.discriminator_step(entry)

    scores = d_loss(entry)
    raw = scores.as_raw_dict()["RaGANDiscriminatorLoss"]
    raw.mean().backward()

    for p in gan.generator.parameters():
        assert p.grad is None, "Generator should have no gradient from D loss"


def test_integration_remapped_fields():
    """Losses work with remapped output field names from GANModel."""
    gen = _Generator()
    gen.set_io({"inputs": {"x": "lr"}, "outputs": "sr"})
    disc = _Discriminator()
    gan = GANModel(generator=gen, discriminator=disc)
    gan.set_io({
        "inputs": {"real_field": "hr", "fake_field": "sr"},
        "outputs": {
            "real_score_d": "d_real",
            "fake_score_d": "d_fake",
            "real_score_g": "g_real",
            "fake_score_g": "g_fake",
        },
    })

    d_loss = RaGANDiscriminatorLoss()
    d_loss.set_io({"inputs": {"real_score": "d_real", "fake_score": "d_fake"}})
    g_loss = RaGANGeneratorLoss()
    g_loss.set_io({"inputs": {"real_score": "g_real", "fake_score": "g_fake"}})

    entry = Entry(name="test", lr=torch.randn(1, 4), hr=torch.randn(1, 4))
    entry = gan(entry)
    entry = gan.discriminator_step(entry)
    entry = gan.generator_step(entry)

    d_scores = d_loss(entry)
    g_scores = g_loss(entry)

    assert isinstance(d_scores.as_raw_dict()["RaGANDiscriminatorLoss"], torch.Tensor)
    assert isinstance(g_scores.as_raw_dict()["RaGANGeneratorLoss"], torch.Tensor)
