"""Tests for IOModule.set_io structured format validation."""

import pytest

from srforge.utils import IOSpec, IOModule


class _DummyModule(IOModule):
    io_spec = IOSpec(
        required_inputs=("image",),
    )


class _InPlaceModule(IOModule):
    io_spec = IOSpec(
        required_inputs=("bands",),
        required_outputs=("bands",),
    )


class TestStructuredSetIo:

    def test_inputs_only(self):
        """IOModule.set_io accepts inputs-only config."""
        module = _DummyModule()
        module.set_io({"inputs": {"image": "x"}})
        assert module.image == "x"

    def test_outputs_rejected(self):
        """IOModule.set_io rejects outputs — port-based binding is inputs-only."""
        module = _DummyModule()
        with pytest.raises(TypeError, match="does not accept 'outputs'"):
            module.set_io({
                "inputs": {"image": "x"},
                "outputs": {"output": "y"},
            })

    def test_dict_outputs_rejected(self):
        """Dict outputs raise TypeError."""
        module = _DummyModule()
        with pytest.raises(TypeError, match="does not accept 'outputs'"):
            module.set_io({
                "inputs": {"image": "x"},
                "outputs": {"output": "y"},
            })

    def test_string_outputs_rejected(self):
        """String outputs also rejected for IOModule."""
        module = _DummyModule()
        with pytest.raises(TypeError, match="does not accept 'outputs'"):
            module.set_io({
                "inputs": {"image": "x"},
                "outputs": "y",
            })
