"""Coverage tests for srforge.utils modules: convert, deprecation, experimental,
model, model_ops, logging, multigpu, io."""

import json
import logging
import pickle
import warnings
from pathlib import Path
from unittest.mock import MagicMock, patch

import numpy as np
import pytest
import torch


# ── convert.py ──────────────────────────────────────────────────────────


class TestToTorchDtype:
    def test_torch_dtype_passthrough(self):
        from srforge.utils.convert import to_torch_dtype
        assert to_torch_dtype(torch.float32) is torch.float32
        assert to_torch_dtype(torch.int64) is torch.int64

    def test_numpy_dtype_branch_key_mismatch(self):
        """The numpy branch dict uses scalar types (np.float32) as keys,
        but np.dtype instances don't match them via dict lookup.
        This documents the current behavior -- np.dtype inputs fall through
        to the unsupported path.  Use string inputs for numpy dtypes instead."""
        from srforge.utils.convert import to_torch_dtype
        # np.dtype('float32') enters the isinstance(data_type, np.dtype) branch
        # but the dict keys are scalar types, so lookup returns None -> ValueError
        with pytest.raises(ValueError, match="Unsupported data type"):
            to_torch_dtype(np.dtype("float32"))

        # Workaround: use string representation
        assert to_torch_dtype("float32") is torch.float32

    def test_string_mapping(self):
        from srforge.utils.convert import to_torch_dtype
        assert to_torch_dtype("float32") is torch.float32
        assert to_torch_dtype("float64") is torch.float64
        assert to_torch_dtype("float16") is torch.float16
        assert to_torch_dtype("float") is torch.float
        assert to_torch_dtype("double") is torch.double
        assert to_torch_dtype("int32") is torch.int32
        assert to_torch_dtype("int64") is torch.int64
        assert to_torch_dtype("int16") is torch.int16
        assert to_torch_dtype("int8") is torch.int8
        assert to_torch_dtype("uint8") is torch.uint8
        assert to_torch_dtype("uint16") is torch.uint16
        assert to_torch_dtype("int") is torch.int
        assert to_torch_dtype("bool") is torch.bool

    def test_string_case_insensitive(self):
        from srforge.utils.convert import to_torch_dtype
        assert to_torch_dtype("FLOAT32") is torch.float32
        assert to_torch_dtype("Float16") is torch.float16
        assert to_torch_dtype("INT64") is torch.int64

    def test_unsupported_dtype_raises(self):
        from srforge.utils.convert import to_torch_dtype
        with pytest.raises(ValueError, match="Unsupported data type"):
            to_torch_dtype("complex128")

    def test_unsupported_type_raises(self):
        from srforge.utils.convert import to_torch_dtype
        with pytest.raises(ValueError, match="Unsupported data type"):
            to_torch_dtype(12345)


class TestToNumpy:
    def test_tensor_to_numpy(self):
        from srforge.utils.convert import to_numpy
        t = torch.tensor([1.0, 2.0, 3.0])
        result = to_numpy(t)
        assert isinstance(result, np.ndarray)
        np.testing.assert_array_almost_equal(result, [1.0, 2.0, 3.0])

    def test_dict_recursion(self):
        from srforge.utils.convert import to_numpy
        d = {"a": torch.tensor([1.0]), "b": torch.tensor([2.0])}
        result = to_numpy(d)
        assert isinstance(result, dict)
        assert isinstance(result["a"], np.ndarray)
        assert isinstance(result["b"], np.ndarray)

    def test_list_recursion(self):
        from srforge.utils.convert import to_numpy
        lst = [torch.tensor([1.0]), torch.tensor([2.0])]
        result = to_numpy(lst)
        assert isinstance(result, list)
        assert all(isinstance(r, np.ndarray) for r in result)

    def test_non_tensor_passthrough(self):
        from srforge.utils.convert import to_numpy
        assert to_numpy(42) == 42
        assert to_numpy("hello") == "hello"
        assert to_numpy(None) is None

    def test_nested_dict_with_non_tensors(self):
        from srforge.utils.convert import to_numpy
        d = {"t": torch.tensor([1.0]), "s": "string", "n": 3}
        result = to_numpy(d)
        assert isinstance(result["t"], np.ndarray)
        assert result["s"] == "string"
        assert result["n"] == 3

    def test_tensor_detaches_from_grad(self):
        from srforge.utils.convert import to_numpy
        t = torch.tensor([1.0, 2.0], requires_grad=True)
        result = to_numpy(t)
        assert isinstance(result, np.ndarray)


# ── deprecation.py ──────────────────────────────────────────────────────


class TestDeprecatedFunction:
    def test_deprecated_wrapper_warns(self):
        from srforge.utils.deprecation import _deprecated

        def new_func(x, y=10):
            return x + y

        @_deprecated(
            old_name="old_func",
            new_name="new_func",
            new_func=new_func,
            name_map={"a": "x", "b": "y"},
        )
        def old_func(a, b=10):
            pass

        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            result = old_func(5, b=20)
            assert result == 25
            assert len(w) == 1
            assert issubclass(w[0].category, DeprecationWarning)
            assert "old_func is deprecated" in str(w[0].message)

    def test_deprecated_positional_args(self):
        from srforge.utils.deprecation import _deprecated

        def new_func(x, y):
            return x * y

        @_deprecated(
            old_name="old_mul",
            new_name="new_mul",
            new_func=new_func,
            name_map={"a": "x", "b": "y"},
        )
        def old_mul(a, b):
            pass

        with warnings.catch_warnings(record=True):
            warnings.simplefilter("always")
            assert old_mul(3, 4) == 12

    def test_deprecated_filters_extra_args(self):
        """Old signature has params not in new function -- they are filtered."""
        from srforge.utils.deprecation import _deprecated

        def new_func(x):
            return x * 2

        @_deprecated(
            old_name="old_fn",
            new_name="new_fn",
            new_func=new_func,
            name_map={"a": "x"},
        )
        def old_fn(a, extra=None):
            pass

        with warnings.catch_warnings(record=True):
            warnings.simplefilter("always")
            assert old_fn(5, extra="unused") == 10

    def test_deprecated_preserves_old_signature(self):
        """The wrapper exposes the old function's signature."""
        import inspect
        from srforge.utils.deprecation import _deprecated

        def new_func(x):
            return x

        @_deprecated(
            old_name="old_fn",
            new_name="new_fn",
            new_func=new_func,
            name_map={},
        )
        def old_fn(x, legacy_param=None):
            pass

        sig = inspect.signature(old_fn)
        assert "legacy_param" in sig.parameters

    def test_deprecated_same_name_mapping(self):
        """When name_map has no entries, parameter names pass through unchanged."""
        from srforge.utils.deprecation import _deprecated

        def new_func(x, y):
            return x - y

        @_deprecated(
            old_name="old_sub",
            new_name="new_sub",
            new_func=new_func,
            name_map={},
        )
        def old_sub(x, y):
            pass

        with warnings.catch_warnings(record=True):
            warnings.simplefilter("always")
            assert old_sub(10, 3) == 7


class TestDeprecatedClass:
    def test_deprecated_class_warns_on_instantiation(self):
        from srforge.utils.deprecation import deprecated_class

        class NewClass:
            def __init__(self, value=0):
                self.value = value

        OldClass = deprecated_class("OldClass", NewClass)

        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            obj = OldClass(value=42)
            assert len(w) == 1
            assert issubclass(w[0].category, DeprecationWarning)
            assert "OldClass is deprecated" in str(w[0].message)
            assert "NewClass" in str(w[0].message)
            assert obj.value == 42

    def test_deprecated_class_name_and_doc(self):
        from srforge.utils.deprecation import deprecated_class

        class NewClass:
            pass

        OldClass = deprecated_class("LegacyName", NewClass)
        assert OldClass.__name__ == "LegacyName"
        assert OldClass.__qualname__ == "LegacyName"
        assert "DEPRECATED" in OldClass.__doc__
        assert "NewClass" in OldClass.__doc__

    def test_deprecated_class_isinstance(self):
        from srforge.utils.deprecation import deprecated_class

        class NewClass:
            def __init__(self):
                pass

        OldClass = deprecated_class("OldClass", NewClass)

        with warnings.catch_warnings(record=True):
            warnings.simplefilter("always")
            obj = OldClass()
            assert isinstance(obj, NewClass)
            assert isinstance(obj, OldClass)


# ── experimental.py ─────────────────────────────────────────────────────


class TestExperimentalDecorator:
    def test_experimental_function_warns(self):
        from srforge.utils.experimental import experimental, ExperimentalWarning

        @experimental
        def my_func(x):
            return x * 2

        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            result = my_func(5)
            assert result == 10
            assert len(w) == 1
            assert issubclass(w[0].category, ExperimentalWarning)
            assert "experimental" in str(w[0].message)

    def test_experimental_function_preserves_name(self):
        from srforge.utils.experimental import experimental

        @experimental
        def my_func():
            """Original doc."""
            pass

        assert my_func.__name__ == "my_func"
        assert "Experimental" in my_func.__doc__
        assert "Original doc." in my_func.__doc__

    def test_experimental_function_no_doc(self):
        from srforge.utils.experimental import experimental

        @experimental
        def no_doc_func():
            pass

        assert "Experimental" in no_doc_func.__doc__

    def test_experimental_class_warns_on_init(self):
        from srforge.utils.experimental import experimental, ExperimentalWarning

        @experimental
        class MyClass:
            """A test class."""
            def __init__(self, x):
                self.x = x

        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            obj = MyClass(42)
            assert obj.x == 42
            assert len(w) == 1
            assert issubclass(w[0].category, ExperimentalWarning)
            assert "MyClass" in str(w[0].message)

    def test_experimental_class_preserves_doc(self):
        from srforge.utils.experimental import experimental

        @experimental
        class DocClass:
            """My fancy class."""
            pass

        assert "Experimental" in DocClass.__doc__
        assert "My fancy class." in DocClass.__doc__

    def test_experimental_class_no_doc(self):
        from srforge.utils.experimental import experimental

        @experimental
        class NoDocClass:
            pass

        assert "Experimental" in NoDocClass.__doc__

    def test_experimental_warning_is_future_warning(self):
        from srforge.utils.experimental import ExperimentalWarning
        assert issubclass(ExperimentalWarning, FutureWarning)


# ── model_ops.py ────────────────────────────────────────────────────────


class TestGetSubmodule:
    def test_get_existing_submodule(self):
        from srforge.utils.model_ops import get_submodule

        model = torch.nn.Sequential(torch.nn.Linear(4, 4))
        # torch.nn.Sequential stores submodules as named '0', '1', etc.
        # but let's use a Module with a named attribute
        parent = torch.nn.Module()
        child = torch.nn.Linear(4, 4)
        parent.my_layer = child

        result = get_submodule(parent, "my_layer")
        assert result is child

    def test_get_missing_submodule_raises(self):
        from srforge.utils.model_ops import get_submodule

        model = torch.nn.Module()
        with pytest.raises(ValueError, match="Module 'nonexistent' not found"):
            get_submodule(model, "nonexistent")


class TestReplaceWithModulesFromAnotherModel:
    def test_replace_single_module(self):
        from srforge.utils.model_ops import replace_with_modules_from_another_model

        target = torch.nn.Module()
        target.layer = torch.nn.Linear(4, 4)

        source = torch.nn.Module()
        source.layer = torch.nn.Linear(4, 8)

        result = replace_with_modules_from_another_model(
            target, "layer", source, "layer"
        )
        assert result.layer.out_features == 8

    def test_replace_multiple_modules(self):
        from srforge.utils.model_ops import replace_with_modules_from_another_model

        target = torch.nn.Module()
        target.a = torch.nn.Linear(4, 4)
        target.b = torch.nn.Linear(4, 4)

        source = torch.nn.Module()
        source.x = torch.nn.Linear(4, 8)
        source.y = torch.nn.Linear(4, 16)

        result = replace_with_modules_from_another_model(
            target, ["a", "b"], source, ["x", "y"]
        )
        assert result.a.out_features == 8
        assert result.b.out_features == 16

    def test_replace_default_source_names(self):
        from srforge.utils.model_ops import replace_with_modules_from_another_model

        target = torch.nn.Module()
        target.layer = torch.nn.Linear(4, 4)

        source = torch.nn.Module()
        source.layer = torch.nn.Linear(4, 8)

        result = replace_with_modules_from_another_model(
            target, "layer", source
        )
        assert result.layer.out_features == 8

    def test_mismatched_lengths_raises(self):
        from srforge.utils.model_ops import replace_with_modules_from_another_model

        target = torch.nn.Module()
        source = torch.nn.Module()

        with pytest.raises(ValueError, match="same length"):
            replace_with_modules_from_another_model(
                target, ["a", "b"], source, ["x"]
            )

    def test_missing_target_module_raises(self):
        from srforge.utils.model_ops import replace_with_modules_from_another_model

        target = torch.nn.Module()
        source = torch.nn.Module()
        source.x = torch.nn.Linear(4, 4)

        with pytest.raises(ValueError, match="not found in target"):
            replace_with_modules_from_another_model(
                target, "nonexistent", source, "x"
            )

    def test_missing_source_module_raises(self):
        from srforge.utils.model_ops import replace_with_modules_from_another_model

        target = torch.nn.Module()
        target.layer = torch.nn.Linear(4, 4)

        source = torch.nn.Module()

        with pytest.raises(ValueError, match="not found in source"):
            replace_with_modules_from_another_model(
                target, "layer", source, "nonexistent"
            )


class TestReplaceModule:
    def test_replace_module_success(self):
        from srforge.utils.model_ops import replace_module

        model = torch.nn.Module()
        model.layer = torch.nn.Linear(4, 4)
        new_layer = torch.nn.Linear(4, 16)

        result = replace_module(model, "layer", new_layer)
        assert result.layer is new_layer
        assert result.layer.out_features == 16

    def test_replace_module_missing_raises(self):
        from srforge.utils.model_ops import replace_module

        model = torch.nn.Module()
        with pytest.raises(ValueError, match="not found in target"):
            replace_module(model, "nonexistent", torch.nn.Linear(4, 4))


# ── model.py (deprecated wrappers) ─────────────────────────────────────


class TestModelDeprecatedWrappers:
    def test_get_module_from_model_deprecated(self):
        """The deprecated get_module_from_model forwards to get_submodule."""
        from srforge.utils.model import get_module_from_model

        parent = torch.nn.Module()
        child = torch.nn.Linear(4, 4)
        parent.my_layer = child

        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            result = get_module_from_model(parent, "my_layer")
            assert result is child
            assert any(issubclass(warning.category, DeprecationWarning) for warning in w)


# ── logging.py ──────────────────────────────────────────────────────────


class TestConfigureLogger:
    def test_configure_logger_default_level(self):
        from srforge.utils.logging import configure_logger

        configure_logger(logging.INFO)
        root = logging.getLogger()
        assert root.level == logging.INFO

    def test_configure_logger_string_level(self):
        from srforge.utils.logging import configure_logger

        configure_logger("DEBUG")
        root = logging.getLogger()
        assert root.level == logging.DEBUG

    def test_configure_logger_clears_existing_handlers(self):
        from srforge.utils.logging import configure_logger

        root = logging.getLogger()
        root.addHandler(logging.StreamHandler())
        initial_count = len(root.handlers)
        assert initial_count >= 1

        configure_logger(logging.INFO)
        # After configure, handlers should be replaced (not accumulated)
        assert len(root.handlers) >= 1

    def test_configure_logger_fallback_to_colorlog(self):
        """When rich is not importable, falls back to colorlog."""
        from srforge.utils.logging import configure_logger

        with patch.dict("sys.modules", {"rich": None, "rich.logging": None,
                                         "rich.console": None, "rich.highlighter": None,
                                         "rich.theme": None}):
            try:
                configure_logger(logging.INFO)
            except ImportError:
                # colorlog may also not be installed in test env; that's fine
                pass


# ── multigpu.py ─────────────────────────────────────────────────────────


class TestSetupDevice:
    def test_single_device_string(self):
        from srforge.utils.multigpu import setup_device

        model = torch.nn.Linear(4, 4)
        returned_model, device = setup_device(model, "cpu")
        assert device == torch.device("cpu")

    def test_single_device_in_list(self):
        from srforge.utils.multigpu import setup_device

        model = torch.nn.Linear(4, 4)
        returned_model, device = setup_device(model, ["cpu"])
        assert device == torch.device("cpu")

    def test_multi_device_requires_dataset(self):
        from srforge.utils.multigpu import setup_device

        model = torch.nn.Linear(4, 4)
        with pytest.raises(ValueError, match="dataset is required"):
            setup_device(model, ["cpu", "cpu"], dataset=None)

    @patch("srforge.utils.multigpu.wrap_data_parallel")
    def test_multi_device_calls_wrap(self, mock_wrap):
        from srforge.utils.multigpu import setup_device

        model = torch.nn.Linear(4, 4)
        dataset = MagicMock()
        mock_wrap.return_value = model

        returned_model, device = setup_device(model, ["cpu", "cpu"], dataset=dataset)
        mock_wrap.assert_called_once_with(model, ["cpu", "cpu"], dataset)

    def test_single_int_device(self):
        from srforge.utils.multigpu import setup_device

        model = torch.nn.Linear(4, 4)
        # cpu is device index -1 for torch, but torch.device(0) needs CUDA
        # We test with "cpu" string equivalent
        returned_model, device = setup_device(model, "cpu")
        assert device == torch.device("cpu")

    def test_listconfig_support(self):
        """If omegaconf is installed, ListConfig is supported."""
        from srforge.utils.multigpu import setup_device
        try:
            from omegaconf import ListConfig
            model = torch.nn.Linear(4, 4)
            returned_model, device = setup_device(model, ListConfig(["cpu"]))
            assert device == torch.device("cpu")
        except ImportError:
            pytest.skip("omegaconf not installed")


# ── io.py ───────────────────────────────────────────────────────────────


class TestLoadImage:
    @patch("cv2.imread")
    def test_load_image_3channel(self, mock_imread):
        from srforge.utils.io import load_image

        fake_img = np.random.randint(0, 255, (10, 10, 3), dtype=np.uint8)
        mock_imread.return_value = fake_img

        result = load_image("/fake/path.png")
        assert isinstance(result, torch.Tensor)
        assert result.shape == (3, 10, 10)
        assert result.dtype == torch.float32

    @patch("cv2.imread")
    def test_load_image_grayscale(self, mock_imread):
        from srforge.utils.io import load_image

        fake_img = np.random.randint(0, 255, (10, 10), dtype=np.uint8)
        mock_imread.return_value = fake_img

        result = load_image("/fake/path.png")
        assert isinstance(result, torch.Tensor)
        assert result.shape == (1, 10, 10)


class TestStandardizeValues:
    def test_list_to_tensor(self):
        from srforge.utils.io import standardize_values
        result = standardize_values([1, 2, 3])
        assert isinstance(result, torch.Tensor)
        assert result.dtype == torch.float32
        assert result.tolist() == [1.0, 2.0, 3.0]

    def test_tuple_to_tensor(self):
        from srforge.utils.io import standardize_values
        result = standardize_values((4.0, 5.0))
        assert isinstance(result, torch.Tensor)

    def test_dict_recursive(self):
        from srforge.utils.io import standardize_values
        result = standardize_values({"a": [1, 2], "b": 42})
        assert isinstance(result, dict)
        assert isinstance(result["a"], torch.Tensor)
        assert result["b"] == 42

    def test_scalar_passthrough(self):
        from srforge.utils.io import standardize_values
        assert standardize_values(42) == 42
        assert standardize_values("hello") == "hello"


class TestLoadFile:
    def test_file_not_found_raises(self, tmp_path):
        from srforge.utils.io import load_file
        with pytest.raises(FileNotFoundError):
            load_file(tmp_path / "nonexistent.txt")

    def test_load_json(self, tmp_path):
        from srforge.utils.io import load_file

        json_path = tmp_path / "data.json"
        json_path.write_text(json.dumps({"key": [1, 2, 3]}))

        result = load_file(json_path)
        assert isinstance(result, dict)
        assert isinstance(result["key"], torch.Tensor)

    def test_load_pickle(self, tmp_path):
        from srforge.utils.io import load_file

        pkl_path = tmp_path / "data.pkl"
        data = {"array": np.array([1, 2, 3])}
        with open(pkl_path, "wb") as f:
            pickle.dump(data, f)

        result = load_file(pkl_path)
        assert isinstance(result, dict)
        np.testing.assert_array_equal(result["array"], [1, 2, 3])

    @patch("cv2.imread")
    def test_load_image_file(self, mock_imread, tmp_path):
        from srforge.utils.io import load_file

        fake_img = np.random.randint(0, 255, (10, 10, 3), dtype=np.uint8)
        mock_imread.return_value = fake_img

        img_path = tmp_path / "img.png"
        img_path.touch()

        result = load_file(img_path)
        assert isinstance(result, torch.Tensor)

    def test_load_unsupported_returns_none(self, tmp_path):
        from srforge.utils.io import load_file

        txt_path = tmp_path / "data.xyz"
        txt_path.write_text("some data")

        result = load_file(txt_path)
        assert result is None

    def test_load_directory(self, tmp_path):
        from srforge.utils.io import load_file

        (tmp_path / "a.json").write_text(json.dumps({"x": 1}))
        (tmp_path / "b.json").write_text(json.dumps({"y": 2}))

        result = load_file(tmp_path)
        assert isinstance(result, list)
        assert len(result) == 2


class TestListSubdirs:
    def test_list_all_subdirs(self, tmp_path):
        from srforge.utils.io import list_subdirs

        (tmp_path / "dir_a").mkdir()
        (tmp_path / "dir_b").mkdir()
        (tmp_path / "file.txt").touch()

        result = list_subdirs(tmp_path)
        names = [p.name for p in result]
        assert "dir_a" in names
        assert "dir_b" in names
        assert "file.txt" not in names

    def test_list_subdirs_with_filter(self, tmp_path):
        from srforge.utils.io import list_subdirs

        (tmp_path / "train").mkdir()
        (tmp_path / "val").mkdir()
        (tmp_path / "test").mkdir()

        result = list_subdirs(tmp_path, allowed_dirs=["train", "val"])
        names = [p.name for p in result]
        assert "train" in names
        assert "val" in names
        assert "test" not in names

    def test_list_subdirs_with_string_filter(self, tmp_path):
        from srforge.utils.io import list_subdirs

        (tmp_path / "train").mkdir()
        (tmp_path / "val").mkdir()

        result = list_subdirs(tmp_path, allowed_dirs="train")
        names = [p.name for p in result]
        assert names == ["train"]


class TestDeepListSubdirs:
    def test_depth_zero(self, tmp_path):
        from srforge.utils.io import deep_list_subdirs

        (tmp_path / "a").mkdir()
        (tmp_path / "b").mkdir()

        result = deep_list_subdirs(tmp_path, depth=0)
        names = [p.name for p in result]
        assert "a" in names
        assert "b" in names

    def test_depth_one(self, tmp_path):
        from srforge.utils.io import deep_list_subdirs

        parent = tmp_path / "top"
        parent.mkdir()
        (parent / "child1").mkdir()
        (parent / "child2").mkdir()

        result = deep_list_subdirs(tmp_path, depth=1)
        names = [p.name for p in result]
        assert "child1" in names
        assert "child2" in names

    def test_negative_depth_raises(self, tmp_path):
        from srforge.utils.io import deep_list_subdirs

        with pytest.raises(ValueError, match="Depth must be >= 0"):
            deep_list_subdirs(tmp_path, depth=-1)

    def test_depth_with_allowed_dirs(self, tmp_path):
        """allowed_dirs filters at every level: at depth=1 the top-level
        filter selects 'train', then at depth=0 the leaf filter also applies.
        So we need matching dir names at both levels for them to appear."""
        from srforge.utils.io import deep_list_subdirs

        (tmp_path / "train").mkdir()
        (tmp_path / "val").mkdir()
        # At depth=0 (leaf level), allowed_dirs=["data"] will match "data"
        (tmp_path / "train" / "data").mkdir()
        (tmp_path / "val" / "data").mkdir()

        # Without allowed_dirs, both top-level and nested dirs are returned
        result_all = deep_list_subdirs(tmp_path, depth=1)
        names_all = [p.name for p in result_all]
        assert "data" in names_all

        # allowed_dirs=["train"] filters at every level:
        # top: only "train" passes -> recurse into train/
        # leaf (depth=0): only dirs named "train" inside train/ pass
        # Since train/data is not named "train", result is empty
        result_filtered = deep_list_subdirs(tmp_path, depth=1, allowed_dirs=["train"])
        assert len(result_filtered) == 0  # no match at leaf level

    def test_depth_one_no_filter(self, tmp_path):
        """Without allowed_dirs, all nested subdirs are returned."""
        from srforge.utils.io import deep_list_subdirs

        (tmp_path / "a").mkdir()
        (tmp_path / "a" / "x").mkdir()
        (tmp_path / "a" / "y").mkdir()
        (tmp_path / "b").mkdir()
        (tmp_path / "b" / "z").mkdir()

        result = deep_list_subdirs(tmp_path, depth=1)
        names = sorted(p.name for p in result)
        assert names == ["x", "y", "z"]
