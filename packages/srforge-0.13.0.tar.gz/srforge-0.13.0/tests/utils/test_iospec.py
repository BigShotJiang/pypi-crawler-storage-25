"""Direct unit tests for IOSpec construction, validation, properties, and replace."""

import pytest

from srforge.utils import IOSpec


# ---------------------------------------------------------------------------
# Construction
# ---------------------------------------------------------------------------


def test_iospec_empty():
    """IOSpec() with no args is valid."""
    spec = IOSpec()
    assert spec.required_inputs == ()
    assert spec.optional_inputs == ()
    assert spec.required_outputs == ()
    assert spec.optional_outputs == ()


def test_iospec_required_inputs_only():
    spec = IOSpec(required_inputs=("a", "b"))
    assert spec.required_inputs == ("a", "b")
    assert spec.optional_inputs == ()
    assert spec.required_outputs == ()
    assert spec.optional_outputs == ()


def test_iospec_optional_inputs_only():
    spec = IOSpec(optional_inputs=("bias",))
    assert spec.optional_inputs == ("bias",)
    assert spec.required_inputs == ()


def test_iospec_required_outputs_only():
    spec = IOSpec(required_outputs=("sr",))
    assert spec.required_outputs == ("sr",)
    assert spec.optional_outputs == ()


def test_iospec_optional_outputs_only():
    spec = IOSpec(optional_outputs=("aux",))
    assert spec.optional_outputs == ("aux",)
    assert spec.required_outputs == ()


def test_iospec_all_fields():
    spec = IOSpec(
        required_inputs=("image",),
        optional_inputs=("guide",),
        required_outputs=("sr",),
        optional_outputs=("aux",),
    )
    assert spec.required_inputs == ("image",)
    assert spec.optional_inputs == ("guide",)
    assert spec.required_outputs == ("sr",)
    assert spec.optional_outputs == ("aux",)


def test_iospec_required_and_optional_inputs():
    spec = IOSpec(required_inputs=("x",), optional_inputs=("bias",))
    assert spec.required_inputs == ("x",)
    assert spec.optional_inputs == ("bias",)


def test_iospec_required_and_optional_outputs():
    spec = IOSpec(required_outputs=("sr",), optional_outputs=("debug",))
    assert spec.required_outputs == ("sr",)
    assert spec.optional_outputs == ("debug",)


def test_iospec_accepts_iterables():
    """Lists and generators are coerced to tuples."""
    spec = IOSpec(
        required_inputs=["a", "b"],
        optional_inputs=iter(["c"]),
        required_outputs={"sr"},
    )
    assert isinstance(spec.required_inputs, tuple)
    assert isinstance(spec.optional_inputs, tuple)
    assert isinstance(spec.required_outputs, tuple)


# ---------------------------------------------------------------------------
# _validate() errors
# ---------------------------------------------------------------------------


def test_validate_non_string_port_name_raises_type_error():
    with pytest.raises(TypeError, match="strings"):
        IOSpec(required_inputs=(123,))


def test_validate_non_string_in_optional_raises_type_error():
    with pytest.raises(TypeError, match="strings"):
        IOSpec(optional_inputs=(None,))


def test_validate_non_string_in_outputs_raises_type_error():
    with pytest.raises(TypeError, match="strings"):
        IOSpec(required_outputs=(42,))


def test_validate_empty_string_port_name_raises_value_error():
    with pytest.raises(ValueError, match="non-empty"):
        IOSpec(required_inputs=("",))


def test_validate_empty_string_in_optional_raises_value_error():
    with pytest.raises(ValueError, match="non-empty"):
        IOSpec(optional_outputs=("",))


def test_validate_overlapping_required_optional_inputs_raises():
    with pytest.raises(ValueError, match="both required and optional"):
        IOSpec(required_inputs=("x",), optional_inputs=("x",))


def test_validate_overlapping_required_optional_outputs_raises():
    with pytest.raises(ValueError, match="both required and optional"):
        IOSpec(required_outputs=("sr",), optional_outputs=("sr",))


def test_validate_duplicate_required_inputs_raises():
    with pytest.raises(ValueError, match="required_inputs must be unique"):
        IOSpec(required_inputs=("x", "x"))


def test_validate_duplicate_optional_inputs_raises():
    with pytest.raises(ValueError, match="optional_inputs must be unique"):
        IOSpec(optional_inputs=("bias", "bias"))


def test_validate_duplicate_required_outputs_raises():
    with pytest.raises(ValueError, match="required_outputs must be unique"):
        IOSpec(required_outputs=("sr", "sr"))


def test_validate_duplicate_optional_outputs_raises():
    with pytest.raises(ValueError, match="optional_outputs must be unique"):
        IOSpec(optional_outputs=("aux", "aux"))


# ---------------------------------------------------------------------------
# Properties: all_inputs, all_outputs
# ---------------------------------------------------------------------------


def test_all_inputs_combines_required_and_optional():
    spec = IOSpec(required_inputs=("x",), optional_inputs=("bias",))
    assert spec.all_inputs == ("x", "bias")


def test_all_inputs_empty_when_no_inputs():
    spec = IOSpec(required_outputs=("sr",))
    assert spec.all_inputs == ()


def test_all_inputs_required_only():
    spec = IOSpec(required_inputs=("a", "b"))
    assert spec.all_inputs == ("a", "b")


def test_all_inputs_optional_only():
    spec = IOSpec(optional_inputs=("c",))
    assert spec.all_inputs == ("c",)


def test_all_outputs_combines_required_and_optional():
    spec = IOSpec(required_outputs=("sr",), optional_outputs=("debug",))
    assert spec.all_outputs == ("sr", "debug")


def test_all_outputs_empty_when_no_outputs():
    spec = IOSpec(required_inputs=("x",))
    assert spec.all_outputs == ()


def test_all_outputs_required_only():
    spec = IOSpec(required_outputs=("sr", "aux"))
    assert spec.all_outputs == ("sr", "aux")


def test_all_outputs_optional_only():
    spec = IOSpec(optional_outputs=("meta",))
    assert spec.all_outputs == ("meta",)


def test_all_inputs_returns_tuple():
    spec = IOSpec(required_inputs=("x",), optional_inputs=("y",))
    assert isinstance(spec.all_inputs, tuple)


def test_all_outputs_returns_tuple():
    spec = IOSpec(required_outputs=("sr",), optional_outputs=("d",))
    assert isinstance(spec.all_outputs, tuple)


# ---------------------------------------------------------------------------
# replace()
# ---------------------------------------------------------------------------


def test_replace_modifies_required_inputs():
    spec = IOSpec(required_inputs=("x",), required_outputs=("sr",))
    new = spec.replace(required_inputs=("a", "b"))
    assert new.required_inputs == ("a", "b")
    assert new.required_outputs == ("sr",)


def test_replace_modifies_optional_inputs():
    spec = IOSpec(required_inputs=("x",), optional_inputs=("bias",))
    new = spec.replace(optional_inputs=("scale",))
    assert new.optional_inputs == ("scale",)
    assert new.required_inputs == ("x",)


def test_replace_modifies_required_outputs():
    spec = IOSpec(required_inputs=("x",), required_outputs=("sr",))
    new = spec.replace(required_outputs=("out1", "out2"))
    assert new.required_outputs == ("out1", "out2")
    assert new.required_inputs == ("x",)


def test_replace_modifies_optional_outputs():
    spec = IOSpec(optional_outputs=("debug",))
    new = spec.replace(optional_outputs=("meta", "aux"))
    assert new.optional_outputs == ("meta", "aux")


def test_replace_preserves_unmodified_fields():
    spec = IOSpec(
        required_inputs=("x",),
        optional_inputs=("bias",),
        required_outputs=("sr",),
        optional_outputs=("aux",),
    )
    new = spec.replace(required_outputs=("out",))
    assert new.required_inputs == ("x",)
    assert new.optional_inputs == ("bias",)
    assert new.required_outputs == ("out",)
    assert new.optional_outputs == ("aux",)


def test_replace_returns_new_instance():
    spec = IOSpec(required_inputs=("x",))
    new = spec.replace(required_inputs=("y",))
    assert new is not spec
    assert spec.required_inputs == ("x",)


def test_replace_with_no_args_returns_equal_copy():
    spec = IOSpec(required_inputs=("x",), required_outputs=("sr",))
    new = spec.replace()
    assert new is not spec
    assert new.required_inputs == spec.required_inputs
    assert new.optional_inputs == spec.optional_inputs
    assert new.required_outputs == spec.required_outputs
    assert new.optional_outputs == spec.optional_outputs


def test_replace_validates_new_spec():
    spec = IOSpec(required_inputs=("x",))
    with pytest.raises(ValueError, match="both required and optional"):
        spec.replace(optional_inputs=("x",))
