"""Direct unit tests for parse_io_config() and build_applications()."""

import pytest

from srforge.utils.io_parsing import parse_io_config, build_applications


# ---------------------------------------------------------------------------
# parse_io_config
# ---------------------------------------------------------------------------


def test_parse_io_config_single_application():
    inputs, outputs = parse_io_config(
        {"inputs": {"x": "lr"}, "outputs": "sr"}
    )
    assert inputs == {"x": "lr"}
    assert outputs == "sr"


def test_parse_io_config_multi_application():
    cfg = {
        "inputs": [{"x": "lr1"}, {"x": "lr2"}],
        "outputs": ["sr1", "sr2"],
    }
    inputs, outputs = parse_io_config(cfg)
    assert isinstance(inputs, list)
    assert len(inputs) == 2
    assert inputs[0] == {"x": "lr1"}
    assert inputs[1] == {"x": "lr2"}
    assert outputs == ["sr1", "sr2"]


def test_parse_io_config_outputs_omitted():
    inputs, outputs = parse_io_config({"inputs": {"x": "lr"}})
    assert inputs == {"x": "lr"}
    assert outputs is None


def test_parse_io_config_none_raises_type_error():
    with pytest.raises(TypeError, match="None"):
        parse_io_config(None)


def test_parse_io_config_missing_inputs_key_raises_type_error():
    with pytest.raises(TypeError, match="inputs"):
        parse_io_config({"outputs": "sr"})


def test_parse_io_config_string_raises_type_error():
    with pytest.raises(TypeError, match="inputs"):
        parse_io_config("not a dict")


def test_parse_io_config_invalid_inputs_type_raises_type_error():
    with pytest.raises(TypeError, match="dict or list"):
        parse_io_config({"inputs": 42})


def test_parse_io_config_multi_app_non_dict_item_raises():
    with pytest.raises(TypeError, match="inputs\\[1\\]"):
        parse_io_config({"inputs": [{"x": "a"}, "bad"]})


# ---------------------------------------------------------------------------
# build_applications
# ---------------------------------------------------------------------------


def test_build_single_dict_inputs_string_output():
    apps = build_applications({"x": "lr"}, "sr")
    assert len(apps) == 1
    assert apps[0] == ({"x": "lr"}, ["sr"])


def test_build_single_dict_inputs_list_outputs():
    apps = build_applications({"x": "lr", "g": "guide"}, ["sr", "aux"])
    assert len(apps) == 1
    assert apps[0] == ({"x": "lr", "g": "guide"}, ["sr", "aux"])


def test_build_single_omitted_outputs_single_input():
    apps = build_applications({"x": "lr"}, None)
    assert len(apps) == 1
    assert apps[0] == ({"x": "lr"}, ["lr"])


def test_build_single_omitted_outputs_multi_input_raises():
    with pytest.raises(ValueError, match="multiple parameters"):
        build_applications({"x": "lr", "g": "guide"}, None)


def test_build_multiple_matching_outputs():
    inputs = [{"x": "lr1"}, {"x": "lr2"}]
    outputs = ["sr1", "sr2"]
    apps = build_applications(inputs, outputs)
    assert len(apps) == 2
    assert apps[0] == ({"x": "lr1"}, ["sr1"])
    assert apps[1] == ({"x": "lr2"}, ["sr2"])


def test_build_multiple_omitted_outputs():
    inputs = [{"x": "lr1"}, {"x": "lr2"}]
    apps = build_applications(inputs, None)
    assert len(apps) == 2
    assert apps[0] == ({"x": "lr1"}, ["lr1"])
    assert apps[1] == ({"x": "lr2"}, ["lr2"])


def test_build_multiple_list_of_list_outputs():
    inputs = [{"x": "lr"}, {"x": "lr2"}]
    outputs = [["sr", "aux"], ["sr2", "aux2"]]
    apps = build_applications(inputs, outputs)
    assert apps[0] == ({"x": "lr"}, ["sr", "aux"])
    assert apps[1] == ({"x": "lr2"}, ["sr2", "aux2"])


def test_build_multiple_mismatched_lengths_raises():
    inputs = [{"x": "lr1"}, {"x": "lr2"}]
    outputs = ["sr1"]
    with pytest.raises(ValueError, match="lengths must match"):
        build_applications(inputs, outputs)


def test_build_multiple_single_string_output_broadcast():
    """A single string output with multiple inputs becomes a 1-element list,
    which mismatches length >1 inputs and raises."""
    inputs = [{"x": "lr1"}, {"x": "lr2"}]
    with pytest.raises(ValueError, match="lengths must match"):
        build_applications(inputs, "sr")
