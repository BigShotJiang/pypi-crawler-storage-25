"""Comprehensive coverage tests for NullTracker — verifying all methods
are proper no-ops and that properties return expected defaults."""

from unittest.mock import MagicMock

import numpy as np
import pytest

from srforge.tracking.null import NullTracker
from srforge.tracking.base import ExperimentTracker


class TestNullTrackerProperties:
    """Test all property accessors return the correct sentinel values."""

    def test_is_subclass_of_experiment_tracker(self):
        assert issubclass(NullTracker, ExperimentTracker)

    def test_is_instance_of_experiment_tracker(self):
        tracker = NullTracker()
        assert isinstance(tracker, ExperimentTracker)

    def test_run_id_is_none(self):
        assert NullTracker().run_id is None

    def test_run_name_is_none(self):
        assert NullTracker().run_name is None

    def test_run_path_is_none(self):
        assert NullTracker().run_path is None

    def test_is_resumed_is_false(self):
        assert NullTracker().is_resumed is False

    def test_is_resumed_type(self):
        assert type(NullTracker().is_resumed) is bool


class TestNullTrackerNoOpMethods:
    """Test that all no-op methods accept the documented arguments
    and return None (i.e., do nothing)."""

    def test_log_metrics_returns_none(self):
        result = NullTracker().log_metrics({"loss": 0.5, "acc": 0.9}, step=1)
        assert result is None

    def test_log_metrics_empty_dict(self):
        result = NullTracker().log_metrics({}, step=0)
        assert result is None

    def test_log_metrics_nested_dict(self):
        result = NullTracker().log_metrics(
            {"train": {"loss": 0.1}, "val": {"loss": 0.2}},
            step=10,
        )
        assert result is None

    def test_log_image_returns_none(self):
        img = np.zeros((32, 32, 3), dtype=np.uint8)
        result = NullTracker().log_image("prediction", img, step=1)
        assert result is None

    def test_log_image_with_caption(self):
        img = np.zeros((10, 10), dtype=np.float32)
        result = NullTracker().log_image("sample", img, step=5, caption="test caption")
        assert result is None

    def test_set_summary_returns_none(self):
        result = NullTracker().set_summary("best_loss", 0.01)
        assert result is None

    def test_set_summary_various_types(self):
        tracker = NullTracker()
        assert tracker.set_summary("int_val", 42) is None
        assert tracker.set_summary("str_val", "hello") is None
        assert tracker.set_summary("dict_val", {"a": 1}) is None
        assert tracker.set_summary("list_val", [1, 2, 3]) is None
        assert tracker.set_summary("none_val", None) is None

    def test_commit_returns_none(self):
        result = NullTracker().commit(step=0)
        assert result is None

    def test_commit_various_steps(self):
        tracker = NullTracker()
        assert tracker.commit(step=0) is None
        assert tracker.commit(step=100) is None
        assert tracker.commit(step=999999) is None

    def test_log_config_returns_none(self):
        result = NullTracker().log_config({"lr": 0.001, "epochs": 100})
        assert result is None

    def test_log_config_empty(self):
        result = NullTracker().log_config({})
        assert result is None

    def test_watch_model_returns_none(self):
        model = MagicMock()
        result = NullTracker().watch_model(model)
        assert result is None

    def test_watch_model_with_kwargs(self):
        model = MagicMock()
        result = NullTracker().watch_model(model, log="all", log_freq=100)
        assert result is None

    def test_save_file_returns_none(self):
        result = NullTracker().save_file("/tmp/model.pth")
        assert result is None

    def test_save_file_with_base_path(self):
        result = NullTracker().save_file("/tmp/model.pth", base_path="/tmp")
        assert result is None

    def test_save_file_none_base_path(self):
        result = NullTracker().save_file("/tmp/checkpoint.pth", base_path=None)
        assert result is None

    def test_finish_returns_none(self):
        result = NullTracker().finish()
        assert result is None

    def test_finish_with_exit_code(self):
        assert NullTracker().finish(exit_code=0) is None
        assert NullTracker().finish(exit_code=1) is None
        assert NullTracker().finish(exit_code=-1) is None


class TestNullTrackerRestoreMethods:
    """Test that restore methods raise FileNotFoundError as expected."""

    def test_restore_file_raises_file_not_found(self):
        with pytest.raises(FileNotFoundError) as exc_info:
            NullTracker().restore_file("checkpoint_best.pth")
        assert "NullTracker cannot restore" in str(exc_info.value)
        assert "checkpoint_best.pth" in str(exc_info.value)

    def test_restore_file_different_filenames(self):
        tracker = NullTracker()
        for filename in ["model.pth", "config.yaml", "weights_best.pth"]:
            with pytest.raises(FileNotFoundError, match=filename):
                tracker.restore_file(filename)

    def test_restore_from_run_raises_file_not_found(self):
        with pytest.raises(FileNotFoundError) as exc_info:
            NullTracker().restore_from_run("run_abc123", "model_best.pth")
        assert "NullTracker cannot restore" in str(exc_info.value)
        assert "from other runs" in str(exc_info.value)
        assert "run_abc123" in str(exc_info.value)
        assert "model_best.pth" in str(exc_info.value)

    def test_restore_from_run_different_runs(self):
        tracker = NullTracker()
        for run_id, filename in [("run1", "a.pth"), ("run2", "b.pth")]:
            with pytest.raises(FileNotFoundError) as exc_info:
                tracker.restore_from_run(run_id, filename)
            assert run_id in str(exc_info.value)
            assert filename in str(exc_info.value)


class TestNullTrackerMultipleInstances:
    """Verify that multiple NullTracker instances are independent."""

    def test_separate_instances(self):
        t1 = NullTracker()
        t2 = NullTracker()
        assert t1 is not t2

    def test_both_instances_functional(self):
        t1 = NullTracker()
        t2 = NullTracker()
        t1.log_metrics({"a": 1}, step=0)
        t2.log_metrics({"b": 2}, step=0)
        t1.set_summary("x", 1)
        t2.set_summary("y", 2)
        # Both should work without side effects on each other


class TestNullTrackerRegistered:
    """Verify NullTracker is in the class registry."""

    def test_registered_in_class_registry(self):
        from srforge.registry import ClassRegistry
        assert ClassRegistry().has("NullTracker")
