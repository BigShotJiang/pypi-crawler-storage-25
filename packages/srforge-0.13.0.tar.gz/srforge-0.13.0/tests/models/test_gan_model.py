"""Tests for GANModel — composite generator/discriminator wrapper."""

import pytest
import torch

from srforge.data import Entry
from srforge.models import Model, GANModel, SequentialModel
from srforge.utils import IOSpec


# ---------------------------------------------------------------------------
# Dummy sub-models
# ---------------------------------------------------------------------------


class _Generator(Model):
    """Minimal generator: linear map from input to output."""

    def __init__(self):
        super().__init__()
        self.linear = torch.nn.Linear(4, 4, bias=False)
        torch.nn.init.ones_(self.linear.weight)

    def forward(self, x):
        return self.linear(x)


class _Discriminator(Model):
    """Minimal discriminator: reduce input to a single scalar score."""

    def __init__(self):
        super().__init__()
        self.linear = torch.nn.Linear(4, 1, bias=False)
        torch.nn.init.ones_(self.linear.weight)

    def forward(self, img):
        return self.linear(img)


def _make_gan(*, outputs=None):
    """Build a GANModel with standard IO binding.

    Args:
        outputs: outputs dict for set_io.  None means identity defaults.
    """
    gen = _Generator()
    gen.set_io({"inputs": {"x": "lr"}, "outputs": "sr"})
    disc = _Discriminator()
    gan = GANModel(generator=gen, discriminator=disc)
    io_cfg = {"inputs": {"real_field": "hr", "fake_field": "sr"}}
    if outputs is not None:
        io_cfg["outputs"] = outputs
    gan.set_io(io_cfg)
    return gan


def _make_entry():
    """Entry with lr, hr, and a generated sr field."""
    lr = torch.randn(1, 4)
    hr = torch.randn(1, 4)
    entry = Entry(name="test", lr=lr, hr=hr)
    # Run generator to produce sr
    gen = _Generator()
    gen.set_io({"inputs": {"x": "lr"}, "outputs": "sr"})
    entry = gen(entry)
    return entry


# ---------------------------------------------------------------------------
# IOSpec declaration
# ---------------------------------------------------------------------------


def test_io_spec_required_inputs():
    assert GANModel.io_spec.required_inputs == ("real_field", "fake_field")


def test_io_spec_required_outputs():
    assert GANModel.io_spec.required_outputs == (
        "real_score_d", "fake_score_d",
        "real_score_g", "fake_score_g",
    )


# ---------------------------------------------------------------------------
# set_io with dict outputs
# ---------------------------------------------------------------------------


def test_set_io_dict_outputs_maps_fields():
    gan = _make_gan(outputs={
        "real_score_d": "d_real",
        "fake_score_d": "d_fake",
        "real_score_g": "g_real",
        "fake_score_g": "g_fake",
    })
    assert gan._real_score_d_field == "d_real"
    assert gan._fake_score_d_field == "d_fake"
    assert gan._real_score_g_field == "g_real"
    assert gan._fake_score_g_field == "g_fake"


def test_set_io_returns_self():
    gen = _Generator()
    gen.set_io({"inputs": {"x": "lr"}, "outputs": "sr"})
    disc = _Discriminator()
    gan = GANModel(generator=gen, discriminator=disc)
    result = gan.set_io({
        "inputs": {"real_field": "hr", "fake_field": "sr"},
    })
    assert result is gan


# ---------------------------------------------------------------------------
# set_io with omitted outputs (identity defaults)
# ---------------------------------------------------------------------------


def test_set_io_identity_defaults():
    gan = _make_gan(outputs=None)
    assert gan._real_score_d_field == "real_score_d"
    assert gan._fake_score_d_field == "fake_score_d"
    assert gan._real_score_g_field == "real_score_g"
    assert gan._fake_score_g_field == "fake_score_g"


# ---------------------------------------------------------------------------
# set_io validation errors
# ---------------------------------------------------------------------------


def test_set_io_unknown_output_port_raises():
    gen = _Generator()
    gen.set_io({"inputs": {"x": "lr"}, "outputs": "sr"})
    disc = _Discriminator()
    gan = GANModel(generator=gen, discriminator=disc)

    with pytest.raises(ValueError, match="unknown port"):
        gan.set_io({
            "inputs": {"real_field": "hr", "fake_field": "sr"},
            "outputs": {
                "real_score_d": "a",
                "fake_score_d": "b",
                "real_score_g": "c",
                "fake_score_g": "d",
                "nonexistent": "e",
            },
        })


def test_set_io_missing_required_output_port_raises():
    gen = _Generator()
    gen.set_io({"inputs": {"x": "lr"}, "outputs": "sr"})
    disc = _Discriminator()
    gan = GANModel(generator=gen, discriminator=disc)

    with pytest.raises(ValueError, match="missing required"):
        gan.set_io({
            "inputs": {"real_field": "hr", "fake_field": "sr"},
            "outputs": {
                "real_score_d": "a",
                # fake_score_d missing
                "real_score_g": "c",
                "fake_score_g": "d",
            },
        })


def test_set_io_outputs_wrong_type_raises():
    gen = _Generator()
    gen.set_io({"inputs": {"x": "lr"}, "outputs": "sr"})
    disc = _Discriminator()
    gan = GANModel(generator=gen, discriminator=disc)

    with pytest.raises(TypeError, match="dict"):
        gan.set_io({
            "inputs": {"real_field": "hr", "fake_field": "sr"},
            "outputs": ["a", "b", "c", "d"],
        })


# ---------------------------------------------------------------------------
# set_io input validation
# ---------------------------------------------------------------------------


def test_set_io_missing_real_field_raises():
    gen = _Generator()
    gen.set_io({"inputs": {"x": "lr"}, "outputs": "sr"})
    disc = _Discriminator()
    gan = GANModel(generator=gen, discriminator=disc)

    with pytest.raises(ValueError, match="real_field"):
        gan.set_io({"inputs": {"fake_field": "sr"}})


def test_set_io_missing_fake_field_raises():
    gen = _Generator()
    gen.set_io({"inputs": {"x": "lr"}, "outputs": "sr"})
    disc = _Discriminator()
    gan = GANModel(generator=gen, discriminator=disc)

    with pytest.raises(ValueError, match="fake_field"):
        gan.set_io({"inputs": {"real_field": "hr"}})


def test_set_io_inputs_must_be_dict():
    gen = _Generator()
    gen.set_io({"inputs": {"x": "lr"}, "outputs": "sr"})
    disc = _Discriminator()
    gan = GANModel(generator=gen, discriminator=disc)

    with pytest.raises(TypeError, match="dict"):
        gan.set_io({"inputs": [{"real_field": "hr", "fake_field": "sr"}]})


# ---------------------------------------------------------------------------
# forward() delegates to generator
# ---------------------------------------------------------------------------


def test_forward_delegates_to_generator():
    gan = _make_gan()
    entry = Entry(name="test", lr=torch.ones(1, 4))
    out = gan(entry)
    assert "sr" in out
    assert torch.allclose(out.sr, gan.generator(torch.ones(1, 4)))


def test_forward_raw_tensor():
    gan = _make_gan()
    x = torch.ones(1, 4)
    result = gan(x)
    expected = gan.generator(x)
    assert torch.allclose(result, expected)


# ---------------------------------------------------------------------------
# trainable_params() returns only generator params
# ---------------------------------------------------------------------------


def test_trainable_params_only_generator():
    gan = _make_gan()
    tp = gan.trainable_params()
    gen_params = list(gan.generator.parameters())
    assert len(tp) == len(gen_params)
    for p, gp in zip(tp, gen_params):
        assert p is gp


def test_trainable_params_excludes_discriminator():
    gan = _make_gan()
    tp_ids = {id(p) for p in gan.trainable_params()}
    for dp in gan.discriminator.parameters():
        assert id(dp) not in tp_ids


# ---------------------------------------------------------------------------
# discriminator_step
# ---------------------------------------------------------------------------


def test_discriminator_step_writes_scores():
    gan = _make_gan()
    entry = _make_entry()
    entry = gan.discriminator_step(entry)
    assert "real_score_d" in entry
    assert "fake_score_d" in entry


def test_discriminator_step_fake_detached():
    """fake_score_d should NOT have grad flowing through generator."""
    gan = _make_gan()
    entry = _make_entry()
    entry = gan.discriminator_step(entry)
    # The fake score was computed from a detached tensor, so its grad_fn
    # graph should not reach the generator weights.
    fake_score = entry["fake_score_d"]
    # Walk the grad_fn tree — no AccumulateGrad from generator should appear
    gen_param_ids = {id(p) for p in gan.generator.parameters()}

    def _find_accum_grad(fn, visited=None):
        if fn is None:
            return False
        if visited is None:
            visited = set()
        if id(fn) in visited:
            return False
        visited.add(id(fn))
        if hasattr(fn, 'variable'):
            return id(fn.variable) in gen_param_ids
        for child, _ in fn.next_functions:
            if _find_accum_grad(child, visited):
                return True
        return False

    assert not _find_accum_grad(fake_score.grad_fn)


def test_discriminator_step_uses_public_call():
    """Discriminator is called via __call__(**kwargs), not _forward directly."""
    gan = _make_gan()
    entry = _make_entry()
    # discriminator_step calls discriminator via __call__ with raw tensors
    entry = gan.discriminator_step(entry)
    assert "real_score_d" in entry
    assert "fake_score_d" in entry


# ---------------------------------------------------------------------------
# generator_step
# ---------------------------------------------------------------------------


def test_generator_step_writes_scores():
    gan = _make_gan()
    entry = _make_entry()
    entry = gan.discriminator_step(entry)
    entry = gan.generator_step(entry)
    assert "real_score_g" in entry
    assert "fake_score_g" in entry


def test_generator_step_real_no_grad():
    """real_score_g should NOT require grad."""
    gan = _make_gan()
    entry = _make_entry()
    entry = gan.discriminator_step(entry)
    entry = gan.generator_step(entry)
    real_g = entry["real_score_g"]
    assert not real_g.requires_grad


def test_generator_step_fake_has_grad():
    """fake_score_g SHOULD require grad and flow back to generator."""
    gan = _make_gan()
    entry = _make_entry()
    entry = gan.discriminator_step(entry)
    entry = gan.generator_step(entry)
    fake_g = entry["fake_score_g"]
    assert fake_g.requires_grad


def test_generator_step_fake_grad_reaches_generator():
    """Gradient from fake_score_g should reach generator parameters."""
    gen = _Generator()
    gen.set_io({"inputs": {"x": "lr"}, "outputs": "sr"})
    disc = _Discriminator()
    gan = GANModel(generator=gen, discriminator=disc)
    gan.set_io({"inputs": {"real_field": "hr", "fake_field": "sr"}})

    lr = torch.randn(1, 4)
    hr = torch.randn(1, 4)
    entry = Entry(name="test", lr=lr, hr=hr)
    entry = gen(entry)

    entry = gan.discriminator_step(entry)
    entry = gan.generator_step(entry)

    fake_g = entry["fake_score_g"]
    fake_g.sum().backward()

    for p in gen.parameters():
        assert p.grad is not None


# ---------------------------------------------------------------------------
# All 4 score fields coexist
# ---------------------------------------------------------------------------


def test_all_four_scores_coexist():
    gan = _make_gan()
    entry = _make_entry()
    entry = gan.discriminator_step(entry)
    entry = gan.generator_step(entry)
    assert "real_score_d" in entry
    assert "fake_score_d" in entry
    assert "real_score_g" in entry
    assert "fake_score_g" in entry


def test_all_four_scores_are_tensors():
    gan = _make_gan()
    entry = _make_entry()
    entry = gan.discriminator_step(entry)
    entry = gan.generator_step(entry)
    for key in ("real_score_d", "fake_score_d", "real_score_g", "fake_score_g"):
        assert isinstance(entry[key], torch.Tensor)


# ---------------------------------------------------------------------------
# IO binding approach 1: Programmatic (direct set_io calls) — covered above
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# IO binding approach 2: Config-based via ConfigResolver
# ---------------------------------------------------------------------------


def test_config_based_instantiation():
    """Simulate config-based construction: _target + params + io dict.

    GANModel is constructed from its config pattern — _target lookup,
    params for generator/discriminator, and io dict for field binding.
    This mirrors what ConfigResolver does, using plain dicts for io_cfg.
    """
    gen = _Generator()
    gen.set_io({"inputs": {"x": "lr"}, "outputs": "sr"})
    disc = _Discriminator()

    # This is the io config that would appear in a YAML config file
    io_cfg = {
        "inputs": {"real_field": "hr", "fake_field": "sr"},
        "outputs": {
            "real_score_d": "real_score_d",
            "fake_score_d": "fake_score_d",
            "real_score_g": "real_score_g",
            "fake_score_g": "fake_score_g",
        },
    }

    model = GANModel(generator=gen, discriminator=disc)
    model.set_io(io_cfg)

    assert isinstance(model, GANModel)
    assert model._real_field == "hr"
    assert model._fake_field == "sr"
    assert model._real_score_d_field == "real_score_d"


def test_config_based_forward():
    """Config-based GANModel can run forward (delegates to generator)."""
    gen = _Generator()
    gen.set_io({"inputs": {"x": "lr"}, "outputs": "sr"})
    disc = _Discriminator()

    model = GANModel(generator=gen, discriminator=disc)
    model.set_io({
        "inputs": {"real_field": "hr", "fake_field": "sr"},
    })

    entry = Entry(name="test", lr=torch.ones(1, 4))
    out = model(entry)
    assert "sr" in out


# ---------------------------------------------------------------------------
# IO binding approach 3: GANModel generator in SequentialModel flow
# ---------------------------------------------------------------------------


def test_generator_works_in_sequential_flow():
    """GANModel.forward delegates to generator, which works in a flow."""
    gen = _Generator()
    seq = SequentialModel(
        modules={"gen": gen},
        flow=["lr -> gen -> sr"],
    )
    entry = Entry(name="test", lr=torch.ones(1, 4))
    out = seq(entry)
    assert "sr" in out
    assert torch.allclose(out.sr, gen(torch.ones(1, 4)))


def test_gan_forward_as_generator_in_flow():
    """GANModel itself can stand in for its generator in a flow context."""
    gan = _make_gan()
    entry = Entry(name="test", lr=torch.ones(1, 4))
    # GANModel.forward(entry) delegates to generator.forward(entry)
    out = gan(entry)
    assert "sr" in out


# ---------------------------------------------------------------------------
# Remapped output fields
# ---------------------------------------------------------------------------


def test_remapped_outputs_in_steps():
    """Remapped output field names appear in the entry after D+G steps."""
    gen = _Generator()
    gen.set_io({"inputs": {"x": "lr"}, "outputs": "sr"})
    disc = _Discriminator()
    gan = GANModel(generator=gen, discriminator=disc)
    gan.set_io({
        "inputs": {"real_field": "hr", "fake_field": "sr"},
        "outputs": {
            "real_score_d": "d_real",
            "fake_score_d": "d_fake",
            "real_score_g": "g_real",
            "fake_score_g": "g_fake",
        },
    })

    entry = _make_entry()
    entry = gan.discriminator_step(entry)
    entry = gan.generator_step(entry)

    assert "d_real" in entry
    assert "d_fake" in entry
    assert "g_real" in entry
    assert "g_fake" in entry


# ---------------------------------------------------------------------------
# OmegaConf DictConfig compatibility
# ---------------------------------------------------------------------------


def test_set_io_accepts_omegaconf_dictconfig():
    """GANModel.set_io works with OmegaConf DictConfig (from ConfigResolver)."""
    from omegaconf import OmegaConf

    gen = _Generator()
    gen.set_io({"inputs": {"x": "lr"}, "outputs": "sr"})
    disc = _Discriminator()
    gan = GANModel(generator=gen, discriminator=disc)

    cfg = OmegaConf.create({
        "inputs": {"real_field": "hr", "fake_field": "sr"},
        "outputs": {
            "real_score_d": "real_score_d",
            "fake_score_d": "fake_score_d",
            "real_score_g": "real_score_g",
            "fake_score_g": "fake_score_g",
        },
    })
    gan.set_io(cfg)

    assert gan._real_field == "hr"
    assert gan._fake_field == "sr"
    assert gan._real_score_d_field == "real_score_d"

    entry = _make_entry()
    entry = gan.discriminator_step(entry)
    entry = gan.generator_step(entry)
    assert "real_score_d" in entry
    assert "fake_score_g" in entry


# ---------------------------------------------------------------------------
# Config ref pattern: top-level generator/discriminator with ${ref:}
# ---------------------------------------------------------------------------


def test_config_ref_pattern_same_instances():
    """Top-level generator/discriminator referenced by GANModel via ${ref:}
    are the same instances, and optimizers get the correct parameters."""
    from omegaconf import OmegaConf
    from srforge.config.resolver import ConfigResolver
    from srforge.registry import register_class

    # Register test models for ConfigResolver
    register_class(_Generator)
    register_class(_Discriminator)

    cfg = OmegaConf.create({
        "generator": {
            "_target": "_Generator",
            "io": {"inputs": {"x": "lr"}, "outputs": ["sr"]},
        },
        "discriminator": {
            "_target": "_Discriminator",
        },
        "model": {
            "_target": "GANModel",
            "params": {
                "generator": "${ref:generator}",
                "discriminator": "${ref:discriminator}",
            },
            "io": {
                "inputs": {"real_field": "hr", "fake_field": "sr"},
            },
        },
        "optimizer_G": {
            "_target": "torch.optim.Adam",
            "params": {
                "params": "${ref:generator}.trainable_params()",
                "lr": 1e-4,
            },
        },
        "optimizer_D": {
            "_target": "torch.optim.Adam",
            "params": {
                "params": "${ref:discriminator}.trainable_params()",
                "lr": 1e-4,
            },
        },
    })

    resolver = ConfigResolver(cfg)
    resolved = resolver.resolve_all()

    model = resolved["model"]
    opt_g = resolved["optimizer_G"]
    opt_d = resolved["optimizer_D"]

    # Same instances
    assert model.generator is resolved["generator"]
    assert model.discriminator is resolved["discriminator"]

    # Optimizers have the right parameters
    g_ids = {id(p) for p in model.generator.parameters()}
    d_ids = {id(p) for p in model.discriminator.parameters()}
    opt_g_ids = {id(p) for g in opt_g.param_groups for p in g["params"]}
    opt_d_ids = {id(p) for g in opt_d.param_groups for p in g["params"]}

    assert opt_g_ids <= g_ids, "Opt G has non-generator params"
    assert opt_d_ids <= d_ids, "Opt D has non-discriminator params"
    assert opt_g_ids.isdisjoint(opt_d_ids), "Optimizers share params"
