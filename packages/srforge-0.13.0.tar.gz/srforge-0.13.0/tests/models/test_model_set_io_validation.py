"""Tests for IOSpec validation in Model.set_io and the three IO binding approaches."""

import pytest
import torch

from srforge.data import Entry
from srforge.models import Model, GANModel, SequentialModel
from srforge.utils import IOSpec
from srforge.utils.io_parsing import parse_io_config, build_applications


# ---------------------------------------------------------------------------
# Helper models
# ---------------------------------------------------------------------------


class _TwoInput(Model):
    """Model with one required and one optional input."""

    def _forward(self, image, guide=None):
        return image + (guide if guide is not None else 0)


class _SingleInput(Model):
    """Simplest possible model — one required input."""

    def _forward(self, x):
        return x + 1


class _Discriminator(Model):
    """Minimal discriminator for GANModel tests."""

    def _forward(self, x):
        return x.mean(dim=(-2, -1), keepdim=True)


# ---------------------------------------------------------------------------
# strict=True (default): unknown input param raises ValueError
# ---------------------------------------------------------------------------


def test_strict_unknown_input_raises():
    model = _TwoInput()
    with pytest.raises(ValueError, match="unknown input") as exc:
        model.set_io({"inputs": {"typo": "lr"}, "outputs": "sr"})
    assert "typo" in str(exc.value)
    assert "image" in str(exc.value)  # valid params listed


def test_strict_unknown_with_valid_params_raises():
    model = _TwoInput()
    with pytest.raises(ValueError, match="Valid"):
        model.set_io(
            {"inputs": {"image": "lr", "bad_param": "extra"}, "outputs": "sr"}
        )


# ---------------------------------------------------------------------------
# require_all=True (default): missing required param raises ValueError
# ---------------------------------------------------------------------------


def test_require_all_missing_required_raises():
    model = _TwoInput()
    # 'image' is required but only 'guide' (optional) is provided
    with pytest.raises(ValueError, match="missing required") as exc:
        model.set_io({"inputs": {"guide": "g"}, "outputs": "sr"})
    assert "image" in str(exc.value)


def test_require_all_only_optional_fails():
    """Providing only optional params fails when require_all=True."""
    model = _TwoInput()
    with pytest.raises(ValueError, match="missing required"):
        model.set_io({"inputs": {"guide": "g"}, "outputs": "sr"})


# ---------------------------------------------------------------------------
# Optional params: passes with require_all=False
# ---------------------------------------------------------------------------


def test_optional_only_passes_with_require_all_false():
    model = _TwoInput()
    model.set_io(
        {"inputs": {"guide": "g"}, "outputs": "sr"},
        require_all=False,
    )
    assert model._applications == [({"guide": "g"}, ["sr"])]


# ---------------------------------------------------------------------------
# strict=False: unknown params accepted silently
# ---------------------------------------------------------------------------


def test_strict_false_accepts_unknown_params():
    model = _TwoInput()
    model.set_io(
        {"inputs": {"image": "lr", "extra": "stuff"}, "outputs": "sr"},
        strict=False,
    )
    assert len(model._applications) == 1
    assert "extra" in model._applications[0][0]


# ---------------------------------------------------------------------------
# require_all=False: missing required params accepted
# ---------------------------------------------------------------------------


def test_require_all_false_accepts_missing_required():
    model = _TwoInput()
    model.set_io(
        {"inputs": {"guide": "g"}, "outputs": "sr"},
        require_all=False,
    )
    assert len(model._applications) == 1


# ---------------------------------------------------------------------------
# Multi-application: validation per application
# ---------------------------------------------------------------------------


def test_multi_app_typo_in_second_app_caught():
    model = _TwoInput()
    with pytest.raises(ValueError, match="unknown input") as exc:
        model.set_io({
            "inputs": [
                {"image": "lr1"},
                {"typo": "lr2"},
            ],
            "outputs": ["sr1", "sr2"],
        })
    assert "typo" in str(exc.value)


def test_multi_app_first_app_valid_second_missing_required():
    model = _TwoInput()
    with pytest.raises(ValueError, match="missing required"):
        model.set_io({
            "inputs": [
                {"image": "lr1"},
                {"guide": "g2"},
            ],
            "outputs": ["sr1", "sr2"],
        })


# ---------------------------------------------------------------------------
# Output auto-population
# ---------------------------------------------------------------------------


def test_set_io_populates_outputs_in_io_spec():
    model = _SingleInput()
    assert model.io_spec.all_outputs == ()
    model.set_io({"inputs": {"x": "lr"}, "outputs": "sr"})
    assert "sr" in model.io_spec.all_outputs


def test_set_io_multi_output_populates_all():
    model = _SingleInput()
    model.set_io({"inputs": {"x": "lr"}, "outputs": ["sr", "extra"]})
    assert "sr" in model.io_spec.all_outputs
    assert "extra" in model.io_spec.all_outputs


def test_set_io_multi_app_populates_all_outputs():
    model = _TwoInput()
    model.set_io({
        "inputs": [{"image": "lr1"}, {"image": "lr2"}],
        "outputs": ["sr1", "sr2"],
    })
    assert "sr1" in model.io_spec.all_outputs
    assert "sr2" in model.io_spec.all_outputs


# ---------------------------------------------------------------------------
# SequentialModel output population from flow steps
# ---------------------------------------------------------------------------


def test_sequential_model_io_spec_outputs_from_flow():
    seq = SequentialModel(
        modules={"m": _SingleInput()},
        flow=["a -> m -> b", "b -> m -> c"],
    )
    assert "b" in seq.io_spec.required_outputs
    assert "c" in seq.io_spec.required_outputs


def test_sequential_model_io_spec_inputs_from_flow():
    seq = SequentialModel(
        modules={"m": _SingleInput()},
        flow=["x -> m -> y"],
    )
    assert "x" in seq.io_spec.required_inputs


# ---------------------------------------------------------------------------
# GANModel: custom set_io with dict outputs
# ---------------------------------------------------------------------------


def test_gan_model_set_io_dict_outputs():
    gen = _SingleInput()
    gen.set_io({"inputs": {"x": "lr"}, "outputs": "sr"})
    disc = _Discriminator()
    gan = GANModel(generator=gen, discriminator=disc)

    gan.set_io({
        "inputs": {"real_field": "hr", "fake_field": "sr"},
        "outputs": {
            "real_score_d": "rsd",
            "fake_score_d": "fsd",
            "real_score_g": "rsg",
            "fake_score_g": "fsg",
        },
    })

    assert gan._real_field == "hr"
    assert gan._fake_field == "sr"
    assert gan._real_score_d_field == "rsd"


def test_gan_model_set_io_omitted_outputs_uses_identity():
    gen = _SingleInput()
    gen.set_io({"inputs": {"x": "lr"}, "outputs": "sr"})
    disc = _Discriminator()
    gan = GANModel(generator=gen, discriminator=disc)

    gan.set_io({
        "inputs": {"real_field": "hr", "fake_field": "sr"},
    })

    # When outputs omitted, port names are used as field names
    assert gan._real_score_d_field == "real_score_d"
    assert gan._fake_score_d_field == "fake_score_d"


def test_gan_model_set_io_unknown_output_port_raises():
    gen = _SingleInput()
    gen.set_io({"inputs": {"x": "lr"}, "outputs": "sr"})
    disc = _Discriminator()
    gan = GANModel(generator=gen, discriminator=disc)

    with pytest.raises(ValueError, match="unknown port"):
        gan.set_io({
            "inputs": {"real_field": "hr", "fake_field": "sr"},
            "outputs": {
                "real_score_d": "rsd",
                "fake_score_d": "fsd",
                "real_score_g": "rsg",
                "fake_score_g": "fsg",
                "bogus": "nope",
            },
        })


# ---------------------------------------------------------------------------
# IO binding approach 1: Programmatic — set_io validates against IOSpec
# ---------------------------------------------------------------------------


def test_programmatic_binding_valid():
    model = _TwoInput()
    model.set_io({"inputs": {"image": "lr", "guide": "g"}, "outputs": "sr"})

    entry = Entry(lr=torch.tensor(1.0), g=torch.tensor(2.0))
    out = model(entry)
    assert torch.allclose(out.sr, torch.tensor(3.0))


def test_programmatic_binding_optional_omitted():
    model = _TwoInput()
    model.set_io({"inputs": {"image": "lr"}, "outputs": "sr"})

    entry = Entry(lr=torch.tensor(5.0))
    out = model(entry)
    assert torch.allclose(out.sr, torch.tensor(5.0))


def test_programmatic_binding_rejects_typo():
    model = _TwoInput()
    with pytest.raises(ValueError, match="unknown input"):
        model.set_io({"inputs": {"img": "lr"}, "outputs": "sr"})


# ---------------------------------------------------------------------------
# IO binding approach 2: Config-based — set_io triggered by config
# ---------------------------------------------------------------------------


def test_config_based_binding_works():
    """Simulates what ConfigResolver does: instantiate model then call set_io."""
    model = _TwoInput()
    io_cfg = {"inputs": {"image": "lr"}, "outputs": "sr"}
    model.set_io(io_cfg)

    entry = Entry(lr=torch.tensor(3.0))
    out = model(entry)
    assert torch.allclose(out.sr, torch.tensor(3.0))


def test_config_based_binding_validates():
    model = _TwoInput()
    io_cfg = {"inputs": {"wrong_name": "lr"}, "outputs": "sr"}
    with pytest.raises(ValueError, match="unknown input"):
        model.set_io(io_cfg)


# ---------------------------------------------------------------------------
# IO binding approach 3: SequentialModel flow — validates via io_spec
# ---------------------------------------------------------------------------


def test_sequential_flow_binding_valid():
    seq = SequentialModel(
        modules={"m": _TwoInput()},
        flow=["(image=lr, guide=g) -> m -> sr"],
    )
    entry = Entry(lr=torch.tensor(1.0), g=torch.tensor(2.0))
    out = seq(entry)
    assert torch.allclose(out.sr, torch.tensor(3.0))


def test_sequential_flow_binding_rejects_unknown_param():
    with pytest.raises(ValueError):
        SequentialModel(
            modules={"m": _TwoInput()},
            flow=["(typo=lr) -> m -> sr"],
        )


def test_sequential_flow_binding_optional_omitted():
    seq = SequentialModel(
        modules={"m": _TwoInput()},
        flow=["(image=lr) -> m -> sr"],
    )
    entry = Entry(lr=torch.tensor(7.0))
    out = seq(entry)
    assert torch.allclose(out.sr, torch.tensor(7.0))
