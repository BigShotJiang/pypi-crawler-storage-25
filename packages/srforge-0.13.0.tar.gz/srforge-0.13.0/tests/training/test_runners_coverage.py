"""Tests for UNTESTED parts of srforge/training/runners.py.

Covers:
- GANTrainingRunner.run_epoch with tiny dummy models
- Hook dispatch integration in run_epoch
- TrainingEpochRunner gradient accumulation path
- DataParallel branch in _forward_and_merge
- Runner state (training_state / load_training_state / zero_grad)
- InferenceRunner / ValidationEpochRunner / BenchmarkRunner edge cases
"""

import pytest
import torch
from torch.utils.data import DataLoader, Dataset

from srforge.data import Entry
from srforge.loss import Loss
from srforge.loss.storage import MetricScores
from srforge.models import Model, GANModel
from srforge.training.runners import (
    EpochRunner,
    TrainingEpochRunner,
    ValidationEpochRunner,
    BenchmarkRunner,
    GANTrainingRunner,
)
from srforge.training.hooks import (
    TrainingHook,
    GANTrainingContext,
    GANStages,
    StepRatio,
    DWarmup,
)


# ---------------------------------------------------------------------------
# Helpers — tiny models, datasets, losses
# ---------------------------------------------------------------------------


class _TinyGenerator(Model):
    """Minimal generator: sr = linear(lr)."""

    def __init__(self):
        super().__init__()
        self.linear = torch.nn.Linear(4, 4, bias=False)
        torch.nn.init.eye_(self.linear.weight)

    def _forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.linear(x)


class _TinyDiscriminator(Model):
    """Minimal discriminator: scalar score per sample."""

    def __init__(self):
        super().__init__()
        self.linear = torch.nn.Linear(4, 1, bias=False)
        torch.nn.init.constant_(self.linear.weight, 0.1)

    def _forward(self, image: torch.Tensor) -> torch.Tensor:
        return self.linear(image)


def _make_gan_model():
    """Build a tiny GANModel with IO binding set up."""
    g = _TinyGenerator()
    d = _TinyDiscriminator()
    g.set_io({"inputs": {"x": "lr"}, "outputs": ["sr"]})
    gan = GANModel(generator=g, discriminator=d)
    gan.set_io({
        "inputs": {"real_field": "hr", "fake_field": "sr"},
        "outputs": {
            "real_score_d": "real_score_d",
            "fake_score_d": "fake_score_d",
            "real_score_g": "real_score_g",
            "fake_score_g": "fake_score_g",
        },
    })
    return gan


class _L1Loss(Loss):
    """Simple L1 loss: |pred - target|."""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.set_io({"inputs": {"pred": "sr", "target": "hr"}})

    @property
    def best_min(self) -> bool:
        return True

    def calculate_score(self, pred: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        return (pred - target).abs().mean(dim=-1)


class _DiscLoss(Loss):
    """Minimal discriminator loss: mean of (real_score - fake_score)."""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.set_io({
            "inputs": {"real_score": "real_score_d", "fake_score": "fake_score_d"},
        })

    @property
    def best_min(self) -> bool:
        return True

    def calculate_score(
        self, real_score: torch.Tensor, fake_score: torch.Tensor
    ) -> torch.Tensor:
        return (fake_score - real_score).squeeze(-1)


class _GenAdvLoss(Loss):
    """Minimal generator adversarial loss: -fake_score."""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.set_io({
            "inputs": {"real_score": "real_score_g", "fake_score": "fake_score_g"},
        })

    @property
    def best_min(self) -> bool:
        return True

    def calculate_score(
        self, real_score: torch.Tensor, fake_score: torch.Tensor
    ) -> torch.Tensor:
        return (-fake_score).squeeze(-1)


class _GANDataset(Dataset):
    """Dataset producing (lr, hr) pairs for GAN training."""

    def __init__(self, n=4):
        self.n = n

    def __len__(self):
        return self.n

    def __getitem__(self, idx):
        return Entry(lr=torch.randn(4), hr=torch.randn(4))


def _make_gan_loader(n=4, batch_size=2):
    return DataLoader(
        _GANDataset(n),
        batch_size=batch_size,
        shuffle=False,
        collate_fn=Entry.collate,
    )


# Model returning dict for _forward_and_merge tests
class _DictModel(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.linear = torch.nn.Linear(1, 1, bias=False)
        torch.nn.init.constant_(self.linear.weight, 1.0)

    def forward(self, entry: Entry):
        x = entry["x"].view(-1, 1)
        y = self.linear(x).view(-1)
        return {"y": y}


class _AbsDiff(Loss):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.set_io({"inputs": {"pred": "y", "target": "t"}})

    @property
    def best_min(self) -> bool:
        return True

    def calculate_score(self, pred: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        return (pred - target).abs()


class _SingleEntryDataset(Dataset):
    def __len__(self):
        return 4

    def __getitem__(self, idx):
        return Entry(x=torch.tensor([float(idx + 1)]), t=torch.tensor([2.0]))


def _make_simple_loader(n=4, batch_size=1):
    return DataLoader(
        _SingleEntryDataset(),
        batch_size=batch_size,
        shuffle=False,
        collate_fn=lambda b: b[0] if len(b) == 1 else Entry.collate(b),
    )


# ---------------------------------------------------------------------------
# GANTrainingRunner.run_epoch
# ---------------------------------------------------------------------------


class TestGANTrainingRunnerRunEpoch:
    def test_run_epoch_basic(self):
        """GANTrainingRunner.run_epoch runs without error on tiny model."""
        gan = _make_gan_model()
        d_loss = _DiscLoss()
        g_loss = _GenAdvLoss()
        pixel_loss = _L1Loss()

        runner = GANTrainingRunner(
            optimizer_G=torch.optim.SGD(gan.generator.parameters(), lr=0.01),
            optimizer_D=torch.optim.SGD(gan.discriminator.parameters(), lr=0.01),
            d_criterion=d_loss,
            g_criterion=g_loss,
            device="cpu",
        )

        loader = _make_gan_loader(n=4, batch_size=2)
        scores = runner.run_epoch(gan, loader, epoch=0, criterion=pixel_loss)

        assert isinstance(scores, MetricScores)
        # Should have D, G pixel, and G adversarial metric entries
        assert len(scores.metrics) > 0

    def test_run_epoch_updates_global_batch_count(self):
        """Global batch count is incremented each batch."""
        gan = _make_gan_model()
        runner = GANTrainingRunner(
            optimizer_G=torch.optim.SGD(gan.generator.parameters(), lr=0.01),
            optimizer_D=torch.optim.SGD(gan.discriminator.parameters(), lr=0.01),
            d_criterion=_DiscLoss(),
            g_criterion=_GenAdvLoss(),
            device="cpu",
        )
        assert runner._global_batch_count == 0

        loader = _make_gan_loader(n=4, batch_size=2)
        runner.run_epoch(gan, loader, epoch=0, criterion=_L1Loss())

        assert runner._global_batch_count == 2  # 4 samples / batch_size 2

    def test_run_epoch_requires_gan_model(self):
        """Raises TypeError if model is not a GANModel."""
        runner = GANTrainingRunner(
            optimizer_G=torch.optim.SGD([torch.nn.Parameter(torch.zeros(1))], lr=0.01),
            optimizer_D=torch.optim.SGD([torch.nn.Parameter(torch.zeros(1))], lr=0.01),
            d_criterion=_DiscLoss(),
            g_criterion=_GenAdvLoss(),
            device="cpu",
        )
        model = _DictModel()
        with pytest.raises(TypeError, match="GANTrainingRunner requires a GANModel"):
            runner.run_epoch(model, _make_gan_loader(), epoch=0, criterion=_L1Loss())

    def test_run_epoch_with_postprocessor(self):
        """Postprocessors are applied after G forward."""
        gan = _make_gan_model()
        post_called = []

        def postproc(entry):
            post_called.append(True)
            return entry

        runner = GANTrainingRunner(
            optimizer_G=torch.optim.SGD(gan.generator.parameters(), lr=0.01),
            optimizer_D=torch.optim.SGD(gan.discriminator.parameters(), lr=0.01),
            d_criterion=_DiscLoss(),
            g_criterion=_GenAdvLoss(),
            postprocessor=[postproc],
            device="cpu",
        )
        runner.run_epoch(gan, _make_gan_loader(n=2, batch_size=2), epoch=0, criterion=_L1Loss())
        assert len(post_called) > 0

    def test_run_epoch_emits_events(self):
        """run_epoch emits RunnerEpochStarted, RunnerBatchFinished, and RunnerEpochFinished."""
        from srforge.events.runner import (
            RunnerEpochStarted,
            RunnerBatchFinished,
            RunnerEpochFinished,
        )

        gan = _make_gan_model()
        runner = GANTrainingRunner(
            optimizer_G=torch.optim.SGD(gan.generator.parameters(), lr=0.01),
            optimizer_D=torch.optim.SGD(gan.discriminator.parameters(), lr=0.01),
            d_criterion=_DiscLoss(),
            g_criterion=_GenAdvLoss(),
            device="cpu",
        )

        events = []
        orig_notify = runner.notify

        def capture(event):
            events.append(event)
            return orig_notify(event)

        runner.notify = capture

        runner.run_epoch(gan, _make_gan_loader(n=2, batch_size=2), epoch=0, criterion=_L1Loss())

        types = [type(e) for e in events]
        assert RunnerEpochStarted in types
        assert RunnerBatchFinished in types
        assert RunnerEpochFinished in types


# ---------------------------------------------------------------------------
# Hook dispatch integration in GANTrainingRunner
# ---------------------------------------------------------------------------


class TestGANRunnerHookIntegration:
    def test_step_ratio_hook_controls_run_flags(self):
        """StepRatio hook integration: controls which steps run."""
        gan = _make_gan_model()
        hook = StepRatio(ratio=2.0)  # G should run twice per D

        runner = GANTrainingRunner(
            optimizer_G=torch.optim.SGD(gan.generator.parameters(), lr=0.01),
            optimizer_D=torch.optim.SGD(gan.discriminator.parameters(), lr=0.01),
            d_criterion=_DiscLoss(),
            g_criterion=_GenAdvLoss(),
            hooks=[hook],
            device="cpu",
        )

        # Should run without error with step ratio hook
        runner.run_epoch(gan, _make_gan_loader(n=4, batch_size=2), epoch=0, criterion=_L1Loss())
        # After epoch, both G and D should have run at least once
        assert runner._global_batch_count > 0

    def test_d_warmup_hook_suppresses_g(self):
        """DWarmup hook suppresses G during warmup batches."""
        gan = _make_gan_model()
        hook = DWarmup(batches=100)  # warmup for 100 batches

        runner = GANTrainingRunner(
            optimizer_G=torch.optim.SGD(gan.generator.parameters(), lr=0.01),
            optimizer_D=torch.optim.SGD(gan.discriminator.parameters(), lr=0.01),
            d_criterion=_DiscLoss(),
            g_criterion=_GenAdvLoss(),
            hooks=[hook],
            device="cpu",
        )

        # With warmup of 100 batches and only 2 batches in loader,
        # G should be suppressed except possibly last batch (forced both on last batch)
        runner.run_epoch(gan, _make_gan_loader(n=4, batch_size=2), epoch=0, criterion=_L1Loss())

    def test_custom_hook_receives_context(self):
        """Custom hook on_pre_step receives a GANTrainingContext."""
        gan = _make_gan_model()
        contexts_seen = []

        class _Spy(TrainingHook):
            def on_pre_step(self, ctx):
                contexts_seen.append(ctx)

        runner = GANTrainingRunner(
            optimizer_G=torch.optim.SGD(gan.generator.parameters(), lr=0.01),
            optimizer_D=torch.optim.SGD(gan.discriminator.parameters(), lr=0.01),
            d_criterion=_DiscLoss(),
            g_criterion=_GenAdvLoss(),
            hooks=[_Spy()],
            device="cpu",
        )

        runner.run_epoch(gan, _make_gan_loader(n=2, batch_size=2), epoch=0, criterion=_L1Loss())
        assert len(contexts_seen) == 1
        assert isinstance(contexts_seen[0], GANTrainingContext)
        assert contexts_seen[0].epoch == 0

    def test_hook_epoch_start_and_end(self):
        """Epoch-level hooks are called once per epoch."""
        gan = _make_gan_model()
        stages_seen = []

        class _StageTracker(TrainingHook):
            def on_epoch_start(self, ctx):
                stages_seen.append("epoch_start")

            def on_epoch_end(self, ctx):
                stages_seen.append("epoch_end")

        runner = GANTrainingRunner(
            optimizer_G=torch.optim.SGD(gan.generator.parameters(), lr=0.01),
            optimizer_D=torch.optim.SGD(gan.discriminator.parameters(), lr=0.01),
            d_criterion=_DiscLoss(),
            g_criterion=_GenAdvLoss(),
            hooks=[_StageTracker()],
            device="cpu",
        )

        runner.run_epoch(gan, _make_gan_loader(n=2, batch_size=2), epoch=0, criterion=_L1Loss())
        assert stages_seen.count("epoch_start") == 1
        assert stages_seen.count("epoch_end") == 1

    def test_hook_extra_d_losses_added(self):
        """Extra D losses from hooks are added to the backward pass."""
        gan = _make_gan_model()

        class _ExtraLoss(TrainingHook):
            def on_post_d_forward(self, ctx):
                ctx.d_extra_losses["penalty"] = torch.tensor(0.1, requires_grad=True)

        runner = GANTrainingRunner(
            optimizer_G=torch.optim.SGD(gan.generator.parameters(), lr=0.01),
            optimizer_D=torch.optim.SGD(gan.discriminator.parameters(), lr=0.01),
            d_criterion=_DiscLoss(),
            g_criterion=_GenAdvLoss(),
            hooks=[_ExtraLoss()],
            device="cpu",
        )
        # Should not error — extra loss is added to D backward
        runner.run_epoch(gan, _make_gan_loader(n=2, batch_size=2), epoch=0, criterion=_L1Loss())

    def test_hook_extra_g_losses_added(self):
        """Extra G losses from hooks are added to the backward pass."""
        gan = _make_gan_model()

        class _GExtraLoss(TrainingHook):
            def on_post_g_forward(self, ctx):
                ctx.g_extra_losses["perceptual"] = torch.tensor(0.05, requires_grad=True)

        runner = GANTrainingRunner(
            optimizer_G=torch.optim.SGD(gan.generator.parameters(), lr=0.01),
            optimizer_D=torch.optim.SGD(gan.discriminator.parameters(), lr=0.01),
            d_criterion=_DiscLoss(),
            g_criterion=_GenAdvLoss(),
            hooks=[_GExtraLoss()],
            device="cpu",
        )
        runner.run_epoch(gan, _make_gan_loader(n=2, batch_size=2), epoch=0, criterion=_L1Loss())

    def test_legacy_params_create_hooks(self):
        """Legacy constructor params (step_ratio, d_warmup_batches, etc.) create hooks."""
        gan = _make_gan_model()
        runner = GANTrainingRunner(
            optimizer_G=torch.optim.SGD(gan.generator.parameters(), lr=0.01),
            optimizer_D=torch.optim.SGD(gan.discriminator.parameters(), lr=0.01),
            d_criterion=_DiscLoss(),
            g_criterion=_GenAdvLoss(),
            step_ratio=2.0,
            d_warmup_batches=10,
            device="cpu",
        )
        hook_types = [type(h).__name__ for h in runner.hooks]
        assert "StepRatio" in hook_types
        assert "DWarmup" in hook_types

    def test_no_hooks_when_defaults(self):
        """No hooks are created when all legacy params are default."""
        gan = _make_gan_model()
        runner = GANTrainingRunner(
            optimizer_G=torch.optim.SGD(gan.generator.parameters(), lr=0.01),
            optimizer_D=torch.optim.SGD(gan.discriminator.parameters(), lr=0.01),
            d_criterion=_DiscLoss(),
            g_criterion=_GenAdvLoss(),
            device="cpu",
        )
        assert runner.hooks == []


# ---------------------------------------------------------------------------
# TrainingEpochRunner gradient accumulation
# ---------------------------------------------------------------------------


class TestGradientAccumulation:
    def test_gradient_accumulation_steps_1(self):
        """With steps=1 (default), optimizer steps every batch."""
        model = _DictModel()
        loss = _AbsDiff()
        optimizer = torch.optim.SGD(model.parameters(), lr=0.1)
        runner = TrainingEpochRunner(
            optimizer=optimizer,
            device="cpu",
            gradient_accumulation_steps=1,
        )

        loader = _make_simple_loader(n=4)
        scores = runner.run_epoch(model, loader, epoch=0, criterion=loss)
        assert isinstance(scores, MetricScores)

    def test_gradient_accumulation_steps_2(self):
        """With steps=2, optimizer steps every 2 batches."""
        model = _DictModel()
        loss = _AbsDiff()
        optimizer = torch.optim.SGD(model.parameters(), lr=0.1)

        runner = TrainingEpochRunner(
            optimizer=optimizer,
            device="cpu",
            gradient_accumulation_steps=2,
        )

        # 4 batches with accum=2 => 2 optimizer steps
        loader = _make_simple_loader(n=4)
        initial_weight = model.linear.weight.data.clone()
        runner.run_epoch(model, loader, epoch=0, criterion=loss)
        # Weight should have changed
        assert not torch.equal(model.linear.weight.data, initial_weight)

    def test_gradient_accumulation_steps_larger_than_batches(self):
        """When accumulation steps > num batches, step happens on last batch."""
        model = _DictModel()
        loss = _AbsDiff()
        optimizer = torch.optim.SGD(model.parameters(), lr=0.1)

        runner = TrainingEpochRunner(
            optimizer=optimizer,
            device="cpu",
            gradient_accumulation_steps=10,  # more than 4 batches
        )

        loader = _make_simple_loader(n=4)
        initial_weight = model.linear.weight.data.clone()
        runner.run_epoch(model, loader, epoch=0, criterion=loss)
        # Should still update on last batch
        assert not torch.equal(model.linear.weight.data, initial_weight)

    def test_gradient_accumulation_scales_loss(self):
        """Loss is divided by accumulation steps before backward."""
        # Run same data with accum=1 and accum=2, compare weight updates
        def run_with_accum(accum_steps):
            model = _DictModel()
            torch.nn.init.constant_(model.linear.weight, 1.0)
            optimizer = torch.optim.SGD(model.parameters(), lr=0.1)
            runner = TrainingEpochRunner(
                optimizer=optimizer,
                device="cpu",
                gradient_accumulation_steps=accum_steps,
            )
            loader = _make_simple_loader(n=2)
            runner.run_epoch(model, loader, epoch=0, criterion=_AbsDiff())
            return model.linear.weight.data.clone()

        w1 = run_with_accum(1)
        w2 = run_with_accum(2)
        # Different accumulation should produce different results
        # (same data, different scaling and step timing)
        # This just verifies the code path runs; exact values depend on loss landscape
        assert w1.shape == w2.shape

    def test_gradient_accumulation_zero_treated_as_one(self):
        """gradient_accumulation_steps=0 is clamped to 1."""
        model = _DictModel()
        runner = TrainingEpochRunner(
            optimizer=torch.optim.SGD(model.parameters(), lr=0.1),
            device="cpu",
            gradient_accumulation_steps=0,
        )
        assert runner.gradient_accumulation_steps == 1

    def test_negative_accumulation_treated_as_one(self):
        """Negative gradient_accumulation_steps is clamped to 1."""
        model = _DictModel()
        runner = TrainingEpochRunner(
            optimizer=torch.optim.SGD(model.parameters(), lr=0.1),
            device="cpu",
            gradient_accumulation_steps=-5,
        )
        assert runner.gradient_accumulation_steps == 1


# ---------------------------------------------------------------------------
# DataParallel branch in _forward_and_merge
# ---------------------------------------------------------------------------


class TestForwardAndMergeDataParallel:
    """Test the list-input (DataParallel) branch of _forward_and_merge.

    The DataParallel path expects a list of entries. The model output
    is a dict (gathered from multiple GPUs). After forward, the runner
    batches the original list and merges the dict output.
    """

    def test_dict_output_merges_into_entry(self):
        """Dict model output is merged into the entry."""

        class _ConcreteRunner(EpochRunner):
            def run_epoch(self, model, data_loader, epoch):
                raise NotImplementedError

        runner = _ConcreteRunner()
        entry = Entry(x=torch.tensor([1.0]), t=torch.tensor([2.0]))
        result = runner._forward_and_merge(_DictModel(), entry, "cpu")
        assert "y" in result
        assert isinstance(result, Entry)

    def test_entry_output_passes_through(self):
        """Model returning Entry passes through without merge."""

        class _EntryModel(torch.nn.Module):
            def forward(self, entry):
                return Entry(x=entry["x"], t=entry["t"], y=entry["x"] * 2)

        class _ConcreteRunner(EpochRunner):
            def run_epoch(self, model, data_loader, epoch):
                raise NotImplementedError

        runner = _ConcreteRunner()
        entry = Entry(x=torch.tensor([1.0]), t=torch.tensor([2.0]))
        result = runner._forward_and_merge(_EntryModel(), entry, "cpu")
        assert isinstance(result, Entry)
        assert "y" in result

    def test_unsupported_output_type_raises(self):
        """Model returning unsupported type raises TypeError."""

        class _BadModel(torch.nn.Module):
            def forward(self, entry):
                return 42

        class _ConcreteRunner(EpochRunner):
            def run_epoch(self, model, data_loader, epoch):
                raise NotImplementedError

        runner = _ConcreteRunner()
        entry = Entry(x=torch.tensor([1.0]))
        with pytest.raises(TypeError, match="Unsupported model output type"):
            runner._forward_and_merge(_BadModel(), entry, "cpu")


# ---------------------------------------------------------------------------
# GANTrainingRunner state management
# ---------------------------------------------------------------------------


class TestGANRunnerState:
    def test_training_state_contains_optimizers(self):
        """training_state() returns G and D optimizer states."""
        gan = _make_gan_model()
        runner = GANTrainingRunner(
            optimizer_G=torch.optim.SGD(gan.generator.parameters(), lr=0.01),
            optimizer_D=torch.optim.SGD(gan.discriminator.parameters(), lr=0.01),
            d_criterion=_DiscLoss(),
            g_criterion=_GenAdvLoss(),
            device="cpu",
        )
        state = runner.training_state()
        assert "optimizer_G" in state
        assert "optimizer_D" in state
        assert "_global_batch_count" in state

    def test_training_state_includes_hook_state(self):
        """Hook state_dict is included in training_state."""
        gan = _make_gan_model()

        class _StatefulHook(TrainingHook):
            def state_dict(self):
                return {"count": 42}

            def load_state_dict(self, state):
                self.count = state["count"]

        runner = GANTrainingRunner(
            optimizer_G=torch.optim.SGD(gan.generator.parameters(), lr=0.01),
            optimizer_D=torch.optim.SGD(gan.discriminator.parameters(), lr=0.01),
            d_criterion=_DiscLoss(),
            g_criterion=_GenAdvLoss(),
            hooks=[_StatefulHook()],
            device="cpu",
        )
        state = runner.training_state()
        assert "hook_0" in state
        assert state["hook_0"]["count"] == 42

    def test_load_training_state_restores(self):
        """load_training_state restores optimizer and hook state."""
        gan = _make_gan_model()

        class _Counter(TrainingHook):
            def __init__(self):
                self.count = 0

            def state_dict(self):
                return {"count": self.count}

            def load_state_dict(self, state):
                self.count = state["count"]

        hook = _Counter()
        runner = GANTrainingRunner(
            optimizer_G=torch.optim.SGD(gan.generator.parameters(), lr=0.01),
            optimizer_D=torch.optim.SGD(gan.discriminator.parameters(), lr=0.01),
            d_criterion=_DiscLoss(),
            g_criterion=_GenAdvLoss(),
            hooks=[hook],
            device="cpu",
        )

        # Run an epoch to change state
        runner.run_epoch(gan, _make_gan_loader(n=2, batch_size=2), epoch=0, criterion=_L1Loss())
        saved = runner.training_state()
        saved["hook_0"]["count"] = 99

        # Build a fresh runner and restore
        hook2 = _Counter()
        runner2 = GANTrainingRunner(
            optimizer_G=torch.optim.SGD(gan.generator.parameters(), lr=0.01),
            optimizer_D=torch.optim.SGD(gan.discriminator.parameters(), lr=0.01),
            d_criterion=_DiscLoss(),
            g_criterion=_GenAdvLoss(),
            hooks=[hook2],
            device="cpu",
        )
        runner2.load_training_state(saved)
        assert hook2.count == 99
        assert runner2._global_batch_count == saved["_global_batch_count"]

    def test_load_training_state_legacy_key(self):
        """load_training_state supports legacy 'optimizer' key for G."""
        gan = _make_gan_model()
        runner = GANTrainingRunner(
            optimizer_G=torch.optim.SGD(gan.generator.parameters(), lr=0.01),
            optimizer_D=torch.optim.SGD(gan.discriminator.parameters(), lr=0.01),
            d_criterion=_DiscLoss(),
            g_criterion=_GenAdvLoss(),
            device="cpu",
        )
        state = runner.training_state()
        # Rename optimizer_G to optimizer (legacy)
        legacy_state = dict(state)
        legacy_state["optimizer"] = legacy_state.pop("optimizer_G")
        # Should not raise
        runner.load_training_state(legacy_state)

    def test_zero_grad_clears_both_optimizers(self):
        """zero_grad clears gradients on both G and D optimizers."""
        gan = _make_gan_model()
        runner = GANTrainingRunner(
            optimizer_G=torch.optim.SGD(gan.generator.parameters(), lr=0.01),
            optimizer_D=torch.optim.SGD(gan.discriminator.parameters(), lr=0.01),
            d_criterion=_DiscLoss(),
            g_criterion=_GenAdvLoss(),
            device="cpu",
        )
        # Simulate gradients
        for p in gan.parameters():
            p.grad = torch.ones_like(p)

        runner.zero_grad()

        for p in gan.parameters():
            assert p.grad is None


# ---------------------------------------------------------------------------
# TrainingEpochRunner state management
# ---------------------------------------------------------------------------


class TestTrainingRunnerState:
    def test_training_state_contains_optimizer(self):
        model = _DictModel()
        opt = torch.optim.SGD(model.parameters(), lr=0.01)
        runner = TrainingEpochRunner(optimizer=opt, device="cpu")
        state = runner.training_state()
        assert "optimizer" in state

    def test_training_state_no_scaler_when_disabled(self):
        model = _DictModel()
        opt = torch.optim.SGD(model.parameters(), lr=0.01)
        runner = TrainingEpochRunner(optimizer=opt, device="cpu", mixed_precision=False)
        state = runner.training_state()
        assert "scaler" not in state

    def test_load_training_state_restores_optimizer(self):
        model = _DictModel()
        opt = torch.optim.SGD(model.parameters(), lr=0.01)
        runner = TrainingEpochRunner(optimizer=opt, device="cpu")
        saved = runner.training_state()

        opt2 = torch.optim.SGD(model.parameters(), lr=0.99)
        runner2 = TrainingEpochRunner(optimizer=opt2, device="cpu")
        runner2.load_training_state(saved)
        # LR should be restored
        assert runner2.optimizer.param_groups[0]["lr"] == 0.01

    def test_zero_grad_clears_grads(self):
        model = _DictModel()
        opt = torch.optim.SGD(model.parameters(), lr=0.01)
        runner = TrainingEpochRunner(optimizer=opt, device="cpu")
        for p in model.parameters():
            p.grad = torch.ones_like(p)

        runner.zero_grad()
        for p in model.parameters():
            assert p.grad is None


# ---------------------------------------------------------------------------
# EpochRunner base class
# ---------------------------------------------------------------------------


class TestEpochRunnerBase:
    def test_training_state_default_empty(self):
        class _Concrete(EpochRunner):
            def run_epoch(self, model, data_loader, epoch):
                pass

        runner = _Concrete()
        assert runner.training_state() == {}

    def test_load_training_state_noop(self):
        class _Concrete(EpochRunner):
            def run_epoch(self, model, data_loader, epoch):
                pass

        runner = _Concrete()
        runner.load_training_state({"anything": 123})  # should not raise

    def test_zero_grad_noop(self):
        class _Concrete(EpochRunner):
            def run_epoch(self, model, data_loader, epoch):
                pass

        runner = _Concrete()
        runner.zero_grad()  # should not raise

    def test_scope_default_empty(self):
        class _Concrete(EpochRunner):
            def run_epoch(self, model, data_loader, epoch):
                pass

        runner = _Concrete()
        assert runner.scope == ""

    def test_scope_from_constructor(self):
        class _Concrete(EpochRunner):
            def run_epoch(self, model, data_loader, epoch):
                pass

        runner = _Concrete(scope="custom")
        assert runner.scope == "custom"


# ---------------------------------------------------------------------------
# ValidationEpochRunner
# ---------------------------------------------------------------------------


class TestValidationEpochRunner:
    def test_scope_is_val(self):
        runner = ValidationEpochRunner(device="cpu")
        assert runner.scope == "val"

    def test_requires_criterion(self):
        model = _DictModel()
        runner = ValidationEpochRunner(device="cpu")
        with pytest.raises(ValueError, match="requires a criterion"):
            runner.run_epoch(model, _make_simple_loader(), epoch=0, criterion=None)


# ---------------------------------------------------------------------------
# BenchmarkRunner
# ---------------------------------------------------------------------------


class TestBenchmarkRunner:
    def test_scope_is_benchmark(self):
        runner = BenchmarkRunner(device="cpu")
        assert runner.scope == "benchmark"

    def test_runs_without_criterion(self):
        model = _DictModel()
        runner = BenchmarkRunner(device="cpu")
        scores = runner.run_epoch(model, _make_simple_loader(), epoch=0)
        assert scores.metrics == {}

    def test_runs_with_criterion(self):
        model = _DictModel()
        loss = _AbsDiff()
        runner = BenchmarkRunner(device="cpu")
        scores = runner.run_epoch(model, _make_simple_loader(), epoch=0, criterion=loss)
        assert len(scores.metrics) > 0


# ---------------------------------------------------------------------------
# TrainingEpochRunner warns on GANModel
# ---------------------------------------------------------------------------


class TestTrainingRunnerGANWarning:
    def test_warns_when_ganmodel_passed(self, caplog):
        """TrainingEpochRunner logs a warning if passed a GANModel."""
        import logging

        gan = _make_gan_model()
        runner = TrainingEpochRunner(
            optimizer=torch.optim.SGD(gan.generator.parameters(), lr=0.01),
            device="cpu",
        )
        with caplog.at_level(logging.WARNING, logger="srforge.training.runners"):
            # run_epoch should log the warning; it may also fail on
            # Entry field conflicts from the second forward pass, but
            # the warning is emitted before the error.
            try:
                runner.run_epoch(gan, _make_gan_loader(), epoch=0, criterion=_L1Loss())
            except Exception:
                pass

        assert any("GANModel passed to TrainingEpochRunner" in msg for msg in caplog.messages)

    def test_training_runner_scope_is_train(self):
        model = _DictModel()
        runner = TrainingEpochRunner(
            optimizer=torch.optim.SGD(model.parameters(), lr=0.01),
            device="cpu",
        )
        assert runner.scope == "train"

    def test_gan_runner_scope_is_train(self):
        gan = _make_gan_model()
        runner = GANTrainingRunner(
            optimizer_G=torch.optim.SGD(gan.generator.parameters(), lr=0.01),
            optimizer_D=torch.optim.SGD(gan.discriminator.parameters(), lr=0.01),
            d_criterion=_DiscLoss(),
            g_criterion=_GenAdvLoss(),
            device="cpu",
        )
        assert runner.scope == "train"


# ---------------------------------------------------------------------------
# GANTrainingRunner with mixed_precision=False (scaler disabled)
# ---------------------------------------------------------------------------


class TestGANRunnerScalerState:
    def test_training_state_no_scaler_when_disabled(self):
        gan = _make_gan_model()
        runner = GANTrainingRunner(
            optimizer_G=torch.optim.SGD(gan.generator.parameters(), lr=0.01),
            optimizer_D=torch.optim.SGD(gan.discriminator.parameters(), lr=0.01),
            d_criterion=_DiscLoss(),
            g_criterion=_GenAdvLoss(),
            device="cpu",
            mixed_precision=False,
        )
        state = runner.training_state()
        assert "scaler_G" not in state
        assert "scaler_D" not in state
