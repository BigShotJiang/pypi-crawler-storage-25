import pytest
import torch

pytest.importorskip("torch_geometric")
from torch_geometric.data import Batch
from torch.utils.data import DataLoader, Dataset

from srforge.data import GraphEntry
from srforge.loss import Loss
from srforge.training.runners import (
    EpochRunner, TrainingEpochRunner, ValidationEpochRunner, BenchmarkRunner,
)


class _GraphDataset(Dataset):
    def __len__(self):
        return 1

    def __getitem__(self, idx):
        return GraphEntry(x=torch.tensor([1.0]), t=torch.tensor([2.0]))


class _GraphModel(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.weight = torch.nn.Parameter(torch.tensor(1.0))

    def forward(self, entry: GraphEntry) -> GraphEntry:
        y = entry.x * self.weight
        return GraphEntry(x=entry.x, t=entry.t, y=y)


class _AbsDiff(Loss):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.set_io({"inputs": {"pred": "y", "target": "t"}})

    @property
    def best_min(self) -> bool:
        return True

    def calculate_score(self, pred: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        return (pred - target).abs()


def _make_loader():
    return DataLoader(_GraphDataset(), batch_size=1, shuffle=False, collate_fn=lambda batch: batch[0])


class TestRunnerGraphEntryOutput:
    def test_training_runner_accepts_graph_entry_output(self):
        model = _GraphModel()
        loss = _AbsDiff()

        def postproc(entry: GraphEntry):
            assert isinstance(entry, GraphEntry)
            assert "y" in entry
            return entry

        runner = TrainingEpochRunner(
            optimizer=torch.optim.SGD(model.parameters(), lr=0.1),
            device="cpu",
            postprocessor=[postproc],
        )

        scores = runner.run_epoch(model, _make_loader(), epoch=0, criterion=loss)

        assert "_AbsDiff" in scores.metrics
        assert torch.allclose(scores.as_raw_dict()["_AbsDiff"], torch.tensor([1.0]))

    def test_validation_runner_accepts_graph_entry_output(self):
        model = _GraphModel()
        loss = _AbsDiff()

        runner = ValidationEpochRunner(device="cpu", postprocessor=[])

        scores = runner.run_epoch(model, _make_loader(), epoch=0, criterion=loss)

        assert "_AbsDiff" in scores.metrics
        assert torch.allclose(scores.as_raw_dict()["_AbsDiff"], torch.tensor([1.0]))

    def test_benchmark_runner_accepts_graph_entry_output(self):
        model = _GraphModel()
        loss = _AbsDiff()

        runner = BenchmarkRunner(device="cpu", postprocessor=[])

        scores = runner.run_epoch(model, _make_loader(), epoch=0, criterion=loss)

        assert "_AbsDiff" in scores.metrics
        assert torch.allclose(scores.as_raw_dict()["_AbsDiff"], torch.tensor([1.0]))


class _DictGraphModel(torch.nn.Module):
    """Simulates DataParallel gathered output — returns dict, not GraphEntry."""
    def forward(self, entry):
        if isinstance(entry, list):
            # DataParallel receives list, gathers raw outputs
            return {"y": torch.tensor([1.0])}
        return {"y": entry.x * 1.0}


class _ConcreteRunner(EpochRunner):
    """Minimal concrete runner to test _forward_and_merge directly."""
    def run_epoch(self, model, data_loader, epoch):
        raise NotImplementedError


class TestForwardAndMergeListInput:
    """Test the list-of-GraphEntry path (DataParallel + DataListLoader)."""

    def test_list_input_batches_and_merges_dict(self):
        """List input → Batch.from_data_list post-forward, dict output merged."""
        runner = _ConcreteRunner()
        entries = [
            GraphEntry(x=torch.tensor([1.0]), t=torch.tensor([2.0])),
            GraphEntry(x=torch.tensor([3.0]), t=torch.tensor([4.0])),
        ]
        result = runner._forward_and_merge(_DictGraphModel(), entries, "cpu")
        assert isinstance(result, GraphEntry)
        assert "y" in result
        # Verify the entry was batched from the original list
        assert result.x.shape[0] == 2  # two graphs batched

    def test_list_input_with_graphentry_output(self):
        """List input with model returning GraphEntry passes through."""

        class _ListToGraphModel(torch.nn.Module):
            def forward(self, entries):
                batch = Batch.from_data_list(entries)
                return GraphEntry(x=batch.x, t=batch.t, y=batch.x * 2)

        runner = _ConcreteRunner()
        entries = [
            GraphEntry(x=torch.tensor([1.0]), t=torch.tensor([2.0])),
            GraphEntry(x=torch.tensor([3.0]), t=torch.tensor([4.0])),
        ]
        result = runner._forward_and_merge(_ListToGraphModel(), entries, "cpu")
        assert isinstance(result, GraphEntry)
        assert "y" in result
