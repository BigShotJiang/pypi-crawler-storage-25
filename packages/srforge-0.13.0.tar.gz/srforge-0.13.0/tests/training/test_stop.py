"""Tests for srforge/training/stop.py — all stop condition classes."""

import pytest

from srforge.training.stop import (
    StopCondition,
    NoCondition,
    ValidationLossDidNotImprove,
)


# ---------------------------------------------------------------------------
# StopCondition base class
# ---------------------------------------------------------------------------


class TestStopConditionABC:
    def test_cannot_instantiate_base(self):
        """StopCondition is abstract and cannot be instantiated."""
        with pytest.raises(TypeError):
            StopCondition()

    def test_subclass_must_implement_is_condition_satisfied(self):
        """Subclass without is_condition_satisfied raises TypeError."""
        with pytest.raises(TypeError):
            class _Incomplete(StopCondition):
                pass

            _Incomplete()


# ---------------------------------------------------------------------------
# NoCondition
# ---------------------------------------------------------------------------


class TestNoCondition:
    def test_never_satisfied(self):
        """NoCondition.is_condition_satisfied always returns False."""
        cond = NoCondition()
        assert cond.is_condition_satisfied(0, 1.0, 1.0) is False
        assert cond.is_condition_satisfied(100, 0.0, 0.0) is False
        assert cond.is_condition_satisfied(999, 999.0, 999.0) is False

    def test_returns_false_for_extreme_values(self):
        cond = NoCondition()
        assert cond.is_condition_satisfied(0, float("inf"), float("-inf")) is False
        assert cond.is_condition_satisfied(0, float("nan"), float("nan")) is False


# ---------------------------------------------------------------------------
# ValidationLossDidNotImprove
# ---------------------------------------------------------------------------


class TestValidationLossDidNotImprove:
    def test_not_satisfied_before_patience(self):
        """Returns False when fewer epochs than patience have been seen."""
        cond = ValidationLossDidNotImprove(patience=5, min_delta=0.01)
        for i in range(4):
            result = cond.is_condition_satisfied(i, 1.0, 1.0)
            assert result is False

    def test_not_satisfied_when_improving(self):
        """Returns False when validation loss is steadily decreasing."""
        cond = ValidationLossDidNotImprove(patience=3, min_delta=0.01)
        losses = [1.0, 0.9, 0.8, 0.7, 0.6]
        for i, val_loss in enumerate(losses):
            result = cond.is_condition_satisfied(i, 1.0, val_loss)
        # Should never trigger because loss is always improving
        assert result is False

    def test_satisfied_when_not_improving(self):
        """Returns True when validation loss stays flat for patience epochs."""
        cond = ValidationLossDidNotImprove(patience=3, min_delta=0.01)
        # Feed 3 epochs with the same loss (no improvement by min_delta)
        losses = [1.0, 1.0, 1.0]
        results = []
        for i, val_loss in enumerate(losses):
            results.append(cond.is_condition_satisfied(i, 1.0, val_loss))
        # Should be satisfied on the last call (patience=3, got 3 values)
        assert results[-1] is True

    def test_satisfied_when_loss_increases(self):
        """Returns True when validation loss is getting worse."""
        cond = ValidationLossDidNotImprove(patience=3, min_delta=0.01)
        losses = [0.5, 0.6, 0.7]
        results = []
        for i, val_loss in enumerate(losses):
            results.append(cond.is_condition_satisfied(i, 1.0, val_loss))
        # Loss is increasing, not improving
        assert results[-1] is True

    def test_barely_improving_below_min_delta(self):
        """Tiny improvements below min_delta still trigger the stop."""
        cond = ValidationLossDidNotImprove(patience=3, min_delta=0.1)
        # Each improvement is only 0.001, below min_delta of 0.1
        losses = [1.0, 0.999, 0.998]
        results = []
        for i, val_loss in enumerate(losses):
            results.append(cond.is_condition_satisfied(i, 1.0, val_loss))
        assert results[-1] is True

    def test_large_improvement_resets(self):
        """A large improvement within the patience window prevents stop."""
        cond = ValidationLossDidNotImprove(patience=3, min_delta=0.01)
        # Flat, then big drop
        losses = [1.0, 1.0, 0.5]
        results = []
        for i, val_loss in enumerate(losses):
            results.append(cond.is_condition_satisfied(i, 1.0, val_loss))
        # 0.5 is a big improvement from 1.0 (delta = 0.5 > min_delta 0.01)
        assert results[-1] is False

    def test_patience_of_one(self):
        """With patience=1, any single epoch without improvement triggers stop."""
        # patience=1 is an edge case: the window is just the most recent
        # epoch, so it immediately checks oldest (= current) - current = 0
        # which is not > min_delta => satisfied
        cond = ValidationLossDidNotImprove(patience=1, min_delta=0.01)
        # First call with patience=1: len >= 1, oldest = current, differences empty
        # The code checks len >= patience (1), oldest = losses[-1], differences = losses[-0:]
        # which is losses[0:] = [] -> improved = map(... , []) -> any([]) = False -> not False = True
        result = cond.is_condition_satisfied(0, 1.0, 1.0)
        assert result is True

    def test_min_delta_zero(self):
        """With min_delta=0, even tiny improvements prevent stop."""
        cond = ValidationLossDidNotImprove(patience=3, min_delta=0.0)
        # Strictly decreasing by tiny amounts
        losses = [1.0, 0.999, 0.998]
        results = []
        for i, val_loss in enumerate(losses):
            results.append(cond.is_condition_satisfied(i, 1.0, val_loss))
        # oldest = 1.0, differences = [1.0 - 0.999, 1.0 - 0.998] = [0.001, 0.002]
        # improved = map(x > 0.0, [0.001, 0.002]) = [True, True]
        # any([True, True]) = True => not True = False
        assert results[-1] is False

    def test_only_uses_validation_loss(self):
        """Train loss has no effect on the stop condition."""
        cond = ValidationLossDidNotImprove(patience=3, min_delta=0.01)
        # Flat validation loss but train loss is improving dramatically
        losses_train = [10.0, 5.0, 1.0]
        losses_val = [1.0, 1.0, 1.0]
        results = []
        for i in range(3):
            results.append(
                cond.is_condition_satisfied(i, losses_train[i], losses_val[i])
            )
        # Should still trigger because only val_loss matters
        assert results[-1] is True

    def test_long_sequence(self):
        """Condition handles a long sequence of calls correctly."""
        cond = ValidationLossDidNotImprove(patience=5, min_delta=0.01)
        # 10 epochs of steady improvement
        for i in range(10):
            result = cond.is_condition_satisfied(i, 1.0, 1.0 - 0.05 * i)
            assert result is False
        # Now 5 epochs of flat loss
        for i in range(10, 15):
            result = cond.is_condition_satisfied(i, 1.0, 0.5)
        assert result is True
