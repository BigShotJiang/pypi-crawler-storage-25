"""Tests for the training hook system — stages, context, dispatch, validation."""

import pytest
import torch

from srforge.training.hooks import (
    Stages,
    GANStages,
    TrainingContext,
    GANTrainingContext,
    TrainingHook,
    dispatch_hooks,
    register_stages,
    is_registered_stage,
    StepRatio,
    DWarmup,
    R1GradientPenalty,
    GradientClip,
)


# ---------------------------------------------------------------------------
# Stage registry
# ---------------------------------------------------------------------------


def test_base_stages_registered():
    """Stages base class constants are auto-registered."""
    for stage in ["epoch_start", "pre_step", "post_step", "epoch_end"]:
        assert is_registered_stage(stage), f"{stage} not registered"


def test_gan_stages_registered():
    """GANStages constants are auto-registered."""
    for stage in [
        "pre_d_forward", "post_d_forward", "post_d_backward",
        "pre_g_forward", "post_g_forward", "post_g_backward",
    ]:
        assert is_registered_stage(stage), f"{stage} not registered"


def test_gan_stages_inherit_base():
    """GANStages has all base stages too."""
    assert GANStages.EPOCH_START == "epoch_start"
    assert GANStages.PRE_D_FORWARD == "pre_d_forward"


def test_custom_stages_auto_registered():
    """User-defined Stages subclass auto-registers its constants."""
    class MyStages(Stages):
        CUSTOM_ONE = "test_custom_one"
        CUSTOM_TWO = "test_custom_two"

    assert is_registered_stage("test_custom_one")
    assert is_registered_stage("test_custom_two")


def test_private_attrs_not_registered():
    """Attributes starting with _ are not registered as stages."""
    class _Internal(Stages):
        _PRIVATE = "should_not_register"
        PUBLIC = "test_should_register"

    assert not is_registered_stage("should_not_register")
    assert is_registered_stage("test_should_register")


# ---------------------------------------------------------------------------
# TrainingContext
# ---------------------------------------------------------------------------


def test_base_context_fields():
    """TrainingContext has only generic fields."""
    ctx = TrainingContext(entry=None, epoch=0, batch_idx=0, model=None)
    assert ctx.global_batch_count == 0
    assert ctx.extra_losses == {}
    assert ctx.scores is None
    assert not hasattr(ctx, "run_d")


def test_gan_context_fields():
    """GANTrainingContext extends base with D/G fields."""
    ctx = GANTrainingContext(entry=None, epoch=0, batch_idx=0, model=None)
    assert ctx.run_d is True
    assert ctx.run_g is True
    assert ctx.d_extra_losses == {}
    assert ctx.g_extra_losses == {}
    assert ctx.d_steps == 0
    assert ctx.g_steps == 0
    # Inherits base fields
    assert ctx.global_batch_count == 0
    assert ctx.extra_losses == {}


def test_gan_context_is_training_context():
    """GANTrainingContext is a subclass of TrainingContext."""
    ctx = GANTrainingContext(entry=None, epoch=0, batch_idx=0, model=None)
    assert isinstance(ctx, TrainingContext)


# ---------------------------------------------------------------------------
# Hook validation
# ---------------------------------------------------------------------------


def test_valid_hook_no_error():
    """Hook with valid on_* methods passes validation."""
    class GoodHook(TrainingHook):
        def on_pre_step(self, ctx):
            pass

        def on_post_d_forward(self, ctx):
            pass


def test_hook_typo_raises():
    """Hook with typo in on_* method raises ValueError at class creation."""
    with pytest.raises(ValueError, match="unknown training stage"):
        class BadHook(TrainingHook):
            def on_post_d_forwrd(self, ctx):
                pass


def test_hook_non_on_methods_ignored():
    """Methods not starting with on_ are not validated."""
    class HelperHook(TrainingHook):
        def compute_penalty(self, ctx):
            pass

        def _internal(self):
            pass


def test_hook_state_dict_default_empty():
    """Base TrainingHook returns empty state_dict."""
    hook = TrainingHook()
    assert hook.state_dict() == {}


# ---------------------------------------------------------------------------
# dispatch_hooks
# ---------------------------------------------------------------------------


def test_dispatch_calls_matching_hooks():
    """dispatch_hooks calls on_<stage> on hooks that implement it."""
    calls = []

    class Hook1(TrainingHook):
        def on_pre_step(self, ctx):
            calls.append("hook1_pre_step")

    class Hook2(TrainingHook):
        def on_pre_step(self, ctx):
            calls.append("hook2_pre_step")

        def on_post_step(self, ctx):
            calls.append("hook2_post_step")

    ctx = TrainingContext(entry=None, epoch=0, batch_idx=0, model=None)
    hooks = [Hook1(), Hook2()]

    dispatch_hooks(hooks, "pre_step", ctx)
    assert calls == ["hook1_pre_step", "hook2_pre_step"]

    calls.clear()
    dispatch_hooks(hooks, "post_step", ctx)
    assert calls == ["hook2_post_step"]


def test_dispatch_skips_hooks_without_method():
    """Hooks that don't implement the stage method are skipped silently."""
    class OnlyPostStep(TrainingHook):
        def on_post_step(self, ctx):
            pass

    ctx = TrainingContext(entry=None, epoch=0, batch_idx=0, model=None)
    dispatch_hooks([OnlyPostStep()], "pre_step", ctx)  # no error


def test_dispatch_unknown_stage_raises():
    """dispatch_hooks raises ValueError for unregistered stage names."""
    ctx = TrainingContext(entry=None, epoch=0, batch_idx=0, model=None)
    with pytest.raises(ValueError, match="Unknown training stage"):
        dispatch_hooks([], "totally_bogus_stage", ctx)


def test_dispatch_modifies_context():
    """Hooks can modify the mutable context."""
    class Modifier(TrainingHook):
        def on_pre_step(self, ctx):
            ctx.extra_losses["test"] = torch.tensor(1.0)

    ctx = TrainingContext(entry=None, epoch=0, batch_idx=0, model=None)
    dispatch_hooks([Modifier()], "pre_step", ctx)
    assert "test" in ctx.extra_losses


def test_dispatch_order_preserved():
    """Hooks are called in registration order."""
    order = []

    class First(TrainingHook):
        def on_pre_step(self, ctx):
            order.append(1)

    class Second(TrainingHook):
        def on_pre_step(self, ctx):
            order.append(2)

    ctx = TrainingContext(entry=None, epoch=0, batch_idx=0, model=None)
    dispatch_hooks([First(), Second()], "pre_step", ctx)
    assert order == [1, 2]


# ---------------------------------------------------------------------------
# StepRatio hook
# ---------------------------------------------------------------------------


def test_step_ratio_first_batch_both_run():
    """First batch: both D and G run regardless of ratio."""
    hook = StepRatio(ratio=2.0)
    ctx = GANTrainingContext(entry=None, epoch=0, batch_idx=0, model=None,
                             d_steps=0, g_steps=0)
    hook.on_pre_step(ctx)
    assert ctx.run_d is True
    assert ctx.run_g is True


def test_step_ratio_balancing():
    """StepRatio sets run_d/run_g based on cumulative counts."""
    hook = StepRatio(ratio=2.0)  # G twice per D

    ctx = GANTrainingContext(entry=None, epoch=0, batch_idx=1, model=None,
                             d_steps=1, g_steps=1)
    hook.on_pre_step(ctx)
    # ratio 1/1 = 1.0 < 2.0 → G needs catching up
    assert ctx.run_g is True

    ctx.d_steps = 1
    ctx.g_steps = 2
    hook.on_pre_step(ctx)
    # ratio 2/1 = 2.0 >= 2.0 → D needs a turn
    assert ctx.run_d is True


def test_step_ratio_invalid():
    """StepRatio rejects non-positive ratio."""
    with pytest.raises(ValueError):
        StepRatio(ratio=0)
    with pytest.raises(ValueError):
        StepRatio(ratio=-1)


# ---------------------------------------------------------------------------
# DWarmup hook
# ---------------------------------------------------------------------------


def test_d_warmup_suppresses_g():
    """During warmup, only D runs."""
    hook = DWarmup(batches=10)
    ctx = GANTrainingContext(entry=None, epoch=0, batch_idx=0, model=None,
                             global_batch_count=5)
    hook.on_pre_step(ctx)
    assert ctx.run_d is True
    assert ctx.run_g is False


def test_d_warmup_after_warmup():
    """After warmup batches, hook doesn't override."""
    hook = DWarmup(batches=10)
    ctx = GANTrainingContext(entry=None, epoch=0, batch_idx=0, model=None,
                             global_batch_count=10)
    hook.on_pre_step(ctx)
    # Should not modify — defaults remain
    assert ctx.run_d is True
    assert ctx.run_g is True


# ---------------------------------------------------------------------------
# GradientClip hook
# ---------------------------------------------------------------------------


def test_gradient_clip_d():
    """GradientClip clips discriminator gradients."""
    from srforge.models import Model, GANModel

    class _G(Model):
        def __init__(self):
            super().__init__()
            self.linear = torch.nn.Linear(4, 4)
        def _forward(self, x):
            return self.linear(x)

    class _D(Model):
        def __init__(self):
            super().__init__()
            self.linear = torch.nn.Linear(4, 1)
        def _forward(self, image):
            return self.linear(image)

    g, d = _G(), _D()
    gan = GANModel(generator=g, discriminator=d)

    # Set large gradients on D
    for p in d.parameters():
        p.grad = torch.ones_like(p) * 100.0

    hook = GradientClip(max_norm=1.0, target="D")
    ctx = GANTrainingContext(entry=None, epoch=0, batch_idx=0, model=gan)
    hook.on_post_d_backward(ctx)

    total_norm = torch.nn.utils.clip_grad_norm_(d.parameters(), float('inf'))
    assert total_norm <= 1.1  # clipped to ~1.0


# ---------------------------------------------------------------------------
# R1GradientPenalty hook (basic structure test)
# ---------------------------------------------------------------------------


def test_r1_adds_to_d_extra_losses():
    """R1 hook adds a loss term to ctx.d_extra_losses."""
    from srforge.models import Model, GANModel
    from srforge.data import Entry

    class _G(Model):
        def __init__(self):
            super().__init__()
            self.linear = torch.nn.Linear(4, 4, bias=False)
        def _forward(self, x):
            return self.linear(x)

    class _D(Model):
        def __init__(self):
            super().__init__()
            self.linear = torch.nn.Linear(4, 1, bias=False)
        def _forward(self, image):
            return self.linear(image)

    g, d = _G(), _D()
    g.set_io({"inputs": {"x": "lr"}, "outputs": ["sr"]})
    gan = GANModel(generator=g, discriminator=d)
    gan.set_io({"inputs": {"real_field": "hr", "fake_field": "sr"}})

    entry = Entry(hr=torch.randn(2, 4), sr=torch.randn(2, 4))

    hook = R1GradientPenalty(weight=1.0)
    ctx = GANTrainingContext(entry=entry, epoch=0, batch_idx=0, model=gan)
    hook.on_post_d_forward(ctx)

    assert "r1" in ctx.d_extra_losses
    assert ctx.d_extra_losses["r1"].requires_grad


def test_r1_zero_weight_noop():
    """R1 with weight=0 does nothing."""
    hook = R1GradientPenalty(weight=0)
    ctx = GANTrainingContext(entry=None, epoch=0, batch_idx=0, model=None)
    hook.on_post_d_forward(ctx)
    assert len(ctx.d_extra_losses) == 0
