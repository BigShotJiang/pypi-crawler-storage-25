"""Tests for srforge/training/trainers.py — PyTorchTrainer class."""

import re
from types import SimpleNamespace
from unittest.mock import MagicMock

import pytest
import torch
from torch.utils.data import DataLoader, Dataset

from srforge.data import Entry
from srforge.loss import Loss
from srforge.loss.schedule import LossScheduler
from srforge.loss.storage import MetricScores
from srforge.training.runners import (
    TrainingEpochRunner,
    ValidationEpochRunner,
)
from srforge.training.trainers import PyTorchTrainer
from srforge.training.stop import NoCondition, StopCondition
from srforge.training.schedule import BlankLRScheduler


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


class _AddOneModel(torch.nn.Module):
    """Trivial model: output = input + 1."""

    def __init__(self):
        super().__init__()
        self.linear = torch.nn.Linear(1, 1, bias=False)
        torch.nn.init.constant_(self.linear.weight, 1.0)

    def forward(self, entry: Entry):
        x = entry["x"].view(-1, 1)
        y = self.linear(x).view(-1)
        return {"y": y}


class _AbsDiff(Loss):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.set_io({"inputs": {"pred": "y", "target": "t"}})

    @property
    def best_min(self) -> bool:
        return True

    def calculate_score(self, pred: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        return (pred - target).abs()


class _SingleEntryDataset(Dataset):
    def __len__(self):
        return 2

    def __getitem__(self, idx):
        return Entry(x=torch.tensor([1.0]), t=torch.tensor([2.0]))


def _make_loader(n=2):
    ds = _SingleEntryDataset()
    return DataLoader(ds, batch_size=1, shuffle=False, collate_fn=lambda b: b[0])


def _make_trainer(**overrides):
    """Build a minimal PyTorchTrainer with default plumbing.

    Note: BlankLRScheduler() requires an optimizer arg (inherits from
    LRScheduler).  When no lr_scheduler is explicitly provided we create
    a BlankLRScheduler bound to the trainer's optimizer so that the
    ``lr_scheduler or BlankLRScheduler()`` fallback inside
    PyTorchTrainer.__init__ is never reached.
    """
    model = overrides.pop("model", _AddOneModel())
    loss = overrides.pop("loss", _AbsDiff())

    optimizer = overrides.pop(
        "optimizer", torch.optim.SGD(model.parameters(), lr=0.01)
    )

    train_runner = overrides.pop(
        "training_epoch_runner",
        TrainingEpochRunner(optimizer=optimizer, device="cpu"),
    )
    val_runner = overrides.pop(
        "validation_epoch_runner",
        ValidationEpochRunner(device="cpu"),
    )
    training_criterion = overrides.pop("training_criterion", loss)
    validation_criterion = overrides.pop("validation_criterion", loss)
    lr_scheduler = overrides.pop("lr_scheduler", BlankLRScheduler(optimizer))
    stop_condition = overrides.pop("stop_condition", NoCondition())

    return PyTorchTrainer(
        model=model,
        training_epoch_runner=train_runner,
        validation_epoch_runner=val_runner,
        training_criterion=training_criterion,
        validation_criterion=validation_criterion,
        lr_scheduler=lr_scheduler,
        stop_condition=stop_condition,
    )


# ---------------------------------------------------------------------------
# __init__
# ---------------------------------------------------------------------------


class TestPyTorchTrainerInit:
    def test_default_stop_condition_is_no_condition(self):
        t = _make_trainer()
        assert isinstance(t.stop_condition, NoCondition)

    def test_initial_epoch_is_zero(self):
        t = _make_trainer()
        assert t.initial_epoch == 0

    def test_best_losses_is_none(self):
        t = _make_trainer()
        assert t.best_losses is None

    def test_lr_scheduler_defaults_to_blank(self):
        t = _make_trainer()
        # _make_trainer provides a BlankLRScheduler when none is given
        assert isinstance(t.lr_scheduler, BlankLRScheduler)
        # The trainer truthy-checks the scheduler; BlankLRScheduler is truthy
        # so it is used as-is (not replaced by a second BlankLRScheduler)
        assert t.lr_scheduler is not None

    def test_custom_lr_scheduler_is_stored(self):
        model = _AddOneModel()
        optimizer = torch.optim.SGD(model.parameters(), lr=0.01)
        sched = torch.optim.lr_scheduler.StepLR(optimizer, step_size=1)
        t = _make_trainer(model=model, optimizer=optimizer, lr_scheduler=sched)
        assert t.lr_scheduler is sched

    def test_custom_stop_condition_is_stored(self):
        class _AlwaysStop(StopCondition):
            def is_condition_satisfied(self, epoch, train_loss, val_loss):
                return True

        cond = _AlwaysStop()
        t = _make_trainer(stop_condition=cond)
        assert t.stop_condition is cond

    def test_model_is_stored(self):
        model = _AddOneModel()
        t = _make_trainer(model=model)
        assert t.model is model

    def test_runners_are_stored(self):
        model = _AddOneModel()
        opt = torch.optim.SGD(model.parameters(), lr=0.01)
        tr = TrainingEpochRunner(optimizer=opt, device="cpu")
        vr = ValidationEpochRunner(device="cpu")
        t = _make_trainer(
            model=model,
            optimizer=opt,
            training_epoch_runner=tr,
            validation_epoch_runner=vr,
        )
        assert t.training_runner is tr
        assert t.validation_runner is vr

    def test_criteria_are_stored(self):
        loss_a = _AbsDiff(name="A")
        loss_b = _AbsDiff(name="B")
        t = _make_trainer(training_criterion=loss_a, validation_criterion=loss_b)
        assert t.training_criterion is loss_a
        assert t.validation_criterion is loss_b


# ---------------------------------------------------------------------------
# restore()
# ---------------------------------------------------------------------------


class TestRestore:
    def test_restore_with_none_is_noop(self):
        t = _make_trainer()
        t.restore(None)
        assert t.initial_epoch == 0
        assert t.best_losses is None

    def test_restore_with_checkpoint_sets_initial_epoch(self):
        t = _make_trainer()
        ckpt = SimpleNamespace(epoch=5, best_losses={"val": 0.1})
        t.restore(ckpt)
        assert t.initial_epoch == 6  # epoch + 1

    def test_restore_with_checkpoint_sets_best_losses(self):
        t = _make_trainer()
        best = {"val_loss": 0.05}
        ckpt = SimpleNamespace(epoch=3, best_losses=best)
        t.restore(ckpt)
        assert t.best_losses is best

    def test_restore_from_epoch_zero_checkpoint(self):
        t = _make_trainer()
        ckpt = SimpleNamespace(epoch=0, best_losses=None)
        t.restore(ckpt)
        assert t.initial_epoch == 1
        assert t.best_losses is None


# ---------------------------------------------------------------------------
# sanity_check()
# ---------------------------------------------------------------------------


class TestSanityCheck:
    def test_sanity_check_runs_without_error(self):
        """Sanity check completes on minimal model/loaders."""
        t = _make_trainer()
        train_loader = _make_loader()
        val_loader = _make_loader()
        # Should not raise
        t.sanity_check(train_loader, val_loader)

    def test_sanity_check_detaches_and_restores_event_buses(self):
        """Event buses are detached during sanity check and restored after."""
        t = _make_trainer()
        train_bus = t.training_runner._event_bus
        val_bus = t.validation_runner._event_bus

        t.sanity_check(_make_loader(), _make_loader())

        assert t.training_runner._event_bus is train_bus
        assert t.validation_runner._event_bus is val_bus

    def test_sanity_check_restores_buses_on_error(self):
        """Event buses are restored even when sanity check raises."""
        t = _make_trainer()
        train_bus = t.training_runner._event_bus
        val_bus = t.validation_runner._event_bus

        # Force an error in forward by making loader return bad data
        class _BadDataset(Dataset):
            def __len__(self):
                return 1
            def __getitem__(self, idx):
                return "bad"

        bad_loader = DataLoader(
            _BadDataset(), batch_size=1, collate_fn=lambda b: b[0]
        )
        with pytest.raises(Exception):
            t.sanity_check(bad_loader, _make_loader())

        # Buses should still be restored
        assert t.training_runner._event_bus is train_bus
        assert t.validation_runner._event_bus is val_bus

    def test_sanity_check_with_loss_scheduler(self):
        """Sanity check works with LossScheduler criteria."""
        loss = _AbsDiff()
        scheduler = LossScheduler({0: loss})
        t = _make_trainer(training_criterion=scheduler, validation_criterion=scheduler)
        # LossScheduler.__call__ delegates to current_loss, sanity_check uses
        # isinstance check and calls .current — which is actually .current_loss.
        # Patch the attribute so the sanity_check code path works.
        scheduler.current = loss
        t.sanity_check(_make_loader(), _make_loader())

    def test_sanity_check_zeros_grads(self):
        """After sanity check, model gradients should be zero."""
        model = _AddOneModel()
        t = _make_trainer(model=model)
        t.sanity_check(_make_loader(), _make_loader())
        for p in model.parameters():
            assert p.grad is None or torch.all(p.grad == 0)


# ---------------------------------------------------------------------------
# train() loop
# ---------------------------------------------------------------------------


class TestTrain:
    def test_train_runs_correct_number_of_epochs(self):
        """train() loops from initial_epoch to epochs."""
        t = _make_trainer()
        epochs_seen = []

        orig_run = t.training_runner.run_epoch

        def mock_train_run(model, loader, epoch, criterion=None):
            epochs_seen.append(epoch)
            return orig_run(model, loader, epoch, criterion=criterion)

        t.training_runner.run_epoch = mock_train_run
        t.train(3, _make_loader(), _make_loader())
        assert epochs_seen == [0, 1, 2]

    def test_train_respects_initial_epoch(self):
        """train() starts from initial_epoch when set via restore()."""
        t = _make_trainer()
        ckpt = SimpleNamespace(epoch=1, best_losses=None)
        t.restore(ckpt)

        epochs_seen = []
        orig_run = t.training_runner.run_epoch

        def mock_train_run(model, loader, epoch, criterion=None):
            epochs_seen.append(epoch)
            return orig_run(model, loader, epoch, criterion=criterion)

        t.training_runner.run_epoch = mock_train_run
        t.train(3, _make_loader(), _make_loader())
        assert epochs_seen == [2]  # range(2, 3) => [2]

    def test_train_emits_training_began_event(self):
        """train() emits TrainingBegan event at the start."""
        t = _make_trainer()
        events = []
        orig_notify = t.notify

        def capture_notify(event):
            events.append(event)
            return orig_notify(event)

        t.notify = capture_notify
        t.train(1, _make_loader(), _make_loader())

        from srforge.events.trainer import TrainingBegan
        began_events = [e for e in events if isinstance(e, TrainingBegan)]
        assert len(began_events) == 1
        assert began_events[0].total_epochs == 1

    def test_train_emits_epoch_finished_events(self):
        """train() emits TrainerEpochFinished after each epoch."""
        t = _make_trainer()
        events = []
        orig_notify = t.notify

        def capture_notify(event):
            events.append(event)
            return orig_notify(event)

        t.notify = capture_notify
        t.train(2, _make_loader(), _make_loader())

        from srforge.events.trainer import TrainerEpochFinished
        epoch_events = [e for e in events if isinstance(e, TrainerEpochFinished)]
        assert len(epoch_events) == 2
        assert epoch_events[0].epoch == 0
        assert epoch_events[1].epoch == 1

    def test_train_steps_lr_scheduler(self):
        """LR scheduler is stepped once per epoch."""
        model = _AddOneModel()
        optimizer = torch.optim.SGD(model.parameters(), lr=0.1)
        sched = torch.optim.lr_scheduler.StepLR(optimizer, step_size=1, gamma=0.5)
        t = _make_trainer(model=model, optimizer=optimizer, lr_scheduler=sched)

        initial_lr = optimizer.param_groups[0]["lr"]
        t.train(2, _make_loader(), _make_loader())
        final_lr = optimizer.param_groups[0]["lr"]
        # After 2 steps of gamma=0.5: 0.1 -> 0.05 -> 0.025
        assert final_lr < initial_lr

    def test_train_steps_reduce_on_plateau_with_val_loss(self):
        """ReduceLROnPlateau is called with val_loss, not without args."""
        model = _AddOneModel()
        optimizer = torch.optim.SGD(model.parameters(), lr=0.1)
        sched = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, patience=0)
        t = _make_trainer(model=model, optimizer=optimizer, lr_scheduler=sched)

        # Just verify it runs without error (ReduceLROnPlateau.step(metric) signature)
        t.train(1, _make_loader(), _make_loader())

    def test_train_stop_condition_breaks_early(self):
        """Training stops early when stop_condition is satisfied."""

        class _StopAfterEpoch0(StopCondition):
            def is_condition_satisfied(self, epoch, train_loss, val_loss):
                return epoch >= 0  # stop after first epoch

        t = _make_trainer(stop_condition=_StopAfterEpoch0())

        epochs_seen = []
        orig_run = t.training_runner.run_epoch

        def mock_train_run(model, loader, epoch, criterion=None):
            epochs_seen.append(epoch)
            return orig_run(model, loader, epoch, criterion=criterion)

        t.training_runner.run_epoch = mock_train_run
        t.train(10, _make_loader(), _make_loader())
        # Should only run epoch 0 then break
        assert epochs_seen == [0]

    def test_train_with_loss_scheduler_calls_update(self):
        """LossScheduler.update() is called each epoch with the epoch number."""
        loss = _AbsDiff()
        train_sched = LossScheduler({0: loss})
        val_sched = LossScheduler({0: loss})

        update_calls_train = []
        update_calls_val = []

        orig_train_update = train_sched.update
        orig_val_update = val_sched.update

        def mock_train_update(epoch):
            update_calls_train.append(epoch)
            return orig_train_update(epoch)

        def mock_val_update(epoch):
            update_calls_val.append(epoch)
            return orig_val_update(epoch)

        train_sched.update = mock_train_update
        val_sched.update = mock_val_update

        t = _make_trainer(training_criterion=train_sched, validation_criterion=val_sched)
        t.train(2, _make_loader(), _make_loader())

        assert update_calls_train == [0, 1]
        assert update_calls_val == [0, 1]

    def test_train_epoch_finished_carries_runner_state(self):
        """TrainerEpochFinished event includes runner_state dict."""
        t = _make_trainer()
        events = []
        orig_notify = t.notify

        def capture(event):
            events.append(event)
            return orig_notify(event)

        t.notify = capture
        t.train(1, _make_loader(), _make_loader())

        from srforge.events.trainer import TrainerEpochFinished
        epoch_events = [e for e in events if isinstance(e, TrainerEpochFinished)]
        assert len(epoch_events) == 1
        state = epoch_events[0].runner_state
        assert isinstance(state, dict)
        # TrainingEpochRunner always returns optimizer state
        assert "optimizer" in state


# ---------------------------------------------------------------------------
# _rich_print
# ---------------------------------------------------------------------------


class TestRichPrint:
    def test_rich_print_succeeds(self):
        """_rich_print runs without error on a simple message."""
        # No assertion needed — just ensure no exception
        PyTorchTrainer._rich_print("hello")

    def test_rich_print_fallback_on_import_error(self):
        """_rich_print falls back to plain print when rich is not importable."""
        import sys

        # Temporarily hide the rich.console module so the import inside
        # _rich_print fails with ImportError.
        saved = sys.modules.get("rich.console")
        sys.modules["rich.console"] = None  # triggers ImportError on import
        try:
            # Should fall through to the except branch without crashing
            PyTorchTrainer._rich_print("[bold]test[/bold]")
        finally:
            if saved is not None:
                sys.modules["rich.console"] = saved
            else:
                sys.modules.pop("rich.console", None)

    def test_rich_print_fallback_strips_tags(self):
        """Fallback path strips rich markup tags."""
        import re as _re

        # Directly test the fallback logic (the except branch)
        msg = "[bold green]hello world[/bold green]"
        plain = _re.sub(r'\[.*?\]', '', msg)
        result = plain.encode('ascii', 'replace').decode('ascii')
        assert "[" not in result
        assert "hello world" in result

    def test_rich_print_fallback_on_unicode_error(self):
        """_rich_print falls back when Console.print raises UnicodeEncodeError."""
        import sys

        mock_console_module = MagicMock()
        mock_console_instance = MagicMock()
        mock_console_module.Console.return_value = mock_console_instance
        mock_console_instance.print.side_effect = UnicodeEncodeError(
            "utf-8", "", 0, 1, "err"
        )

        saved = sys.modules.get("rich.console")
        sys.modules["rich.console"] = mock_console_module
        try:
            # Should not raise — falls back to plain print
            PyTorchTrainer._rich_print("[dim]emoji text[/dim]")
        finally:
            if saved is not None:
                sys.modules["rich.console"] = saved
            else:
                sys.modules.pop("rich.console", None)
