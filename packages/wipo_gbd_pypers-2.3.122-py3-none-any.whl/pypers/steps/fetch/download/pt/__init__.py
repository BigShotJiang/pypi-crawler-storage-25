from os.path import realpath, dirname
from pypers import import_all
import requests
import json

def get_auth_token(config):
    # Encode the client crendentials
    headers = {
        #"Content-Type": "application/x-www-form-urlencoded",
        "Content-Type": "application/json"
    }
    body = {
        "username": config["credentials"]["username"],
        "password": config["credentials"]["password"],
        "client_secret": config["credentials"]["key"]
    }

    auth_end_url = "https://"+config["base_url_update"]+"/api/token"

    response = requests.post(auth_end_url, json=body, headers=headers, verify=False)
    if response.status_code == 200:
        payload = response.json()
    elif response.status_code == 401 or response.status_code == 403:
        raise Exception("invalid crendentials")
    else:
        raise Exception("error from authentication service")

    return payload.get('access_token', None), payload.get('refresh_token', None)


# Import all Steps in this directory.
import_all(namespace=globals(), dir=dirname(realpath(__file__)))
