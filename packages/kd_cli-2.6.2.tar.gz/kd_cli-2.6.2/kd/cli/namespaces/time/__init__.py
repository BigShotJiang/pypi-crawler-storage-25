"""Time namespace: /time

Commands: list, log, update, delete
API layer: YouTrack REST API (/api/issues/{id}/timeTracking/workItems)
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from kd.cli.core.command_base import Command, CommandResult
from kd.cli.core.namespaces import Namespace
from kd.cli.core.option_registry import OptionDeclaration, OptionLayer, ResolvedOptions
from kd.exceptions import ValidationError

_MS_PER_DAY = 86_400_000


def _parse_date(raw: str) -> int:
    """Parse ``YYYY-MM-DD`` into epoch-ms at UTC midnight."""
    try:
        d = datetime.strptime(raw, "%Y-%m-%d").replace(tzinfo=timezone.utc)
    except ValueError:
        raise ValidationError(f"Invalid date '{raw}'. Expected YYYY-MM-DD.") from None
    return int(d.timestamp() * 1000)


def _work_item_to_dict(w: Any) -> dict[str, Any]:
    return {
        "id": w.id,
        "minutes": w.duration.minutes if w.duration else 0,
        "type": w.type.name if w.type else "",
        "author": w.author.name if w.author else "",
        "text": w.text or "",
        "date": w.date,
    }


class TimeListCommand(Command):
    """List work items on an issue."""

    def __init__(self) -> None:
        super().__init__(
            "list",
            "List work items on an issue",
            requires_client=True,
            usage="kd /time list ISSUE_ID [--date DATE] [--from DATE --to DATE]",
            examples=[
                "kd /time list FB-42",
                "kd /time list FB-42 --date 2025-12-31",
                "kd /time list FB-42 --from 2025-12-01 --to 2025-12-31",
            ],
            see_also=["/time log", "/time update", "/time delete"],
        )

    def _register_options(self) -> None:
        self.register_option(
            OptionDeclaration(
                name="date",
                layer=OptionLayer.COMMAND,
                help_text="Filter to a single date (YYYY-MM-DD)",
            )
        )
        self.register_option(
            OptionDeclaration(
                name="from",
                layer=OptionLayer.COMMAND,
                help_text="Start of date range (YYYY-MM-DD, inclusive)",
            )
        )
        self.register_option(
            OptionDeclaration(
                name="to",
                layer=OptionLayer.COMMAND,
                help_text="End of date range (YYYY-MM-DD, inclusive)",
            )
        )

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        if not args:
            raise ValidationError("Usage: kd /time list ISSUE_ID")
        date_opt = options.command.get("date")
        from_opt = options.command.get("from")
        to_opt = options.command.get("to")

        if date_opt and (from_opt or to_opt):
            raise ValidationError("--date is mutually exclusive with --from/--to")
        if (from_opt and not to_opt) or (to_opt and not from_opt):
            raise ValidationError("--from and --to must be supplied together")

        date_from: int | None = None
        date_to: int | None = None
        if date_opt:
            day = _parse_date(date_opt)
            date_from = day
            date_to = day + _MS_PER_DAY - 1
        elif from_opt and to_opt:
            date_from = _parse_date(from_opt)
            date_to = _parse_date(to_opt) + _MS_PER_DAY - 1
            if date_from > date_to:
                raise ValidationError("--from must not be later than --to")

        items = client.time.list(args[0], date_from=date_from, date_to=date_to)
        return [_work_item_to_dict(w) for w in items]


class TimeLogCommand(Command):
    """Log work on an issue."""

    def __init__(self) -> None:
        super().__init__(
            "log",
            "Log work on an issue",
            requires_client=True,
            usage=(
                "kd /time log ISSUE_ID MINUTES [--date DATE] [--type TYPE] [--description DESC]"
            ),
            long_description=(
                "Returns a parseable single-line ack: the last stdout line "
                "is ``ok: <WORK_ITEM_ID> added issue=<ISSUE_ID> "
                "minutes=<N> type=<TYPE> date=<DATE>``. The envelope "
                "``id`` is the new work item's ID (the entity acted on); "
                "the parent issue ID is in ``issue=``. Pass --quiet to "
                "suppress the detail block above the ack."
            ),
            examples=[
                "kd /time log FB-42 30",
                'kd /time log FB-42 60 --type Development --description "SDK work"',
                "kd /time log FB-42 90 --date 2025-12-31 --type Development",
            ],
            see_also=["/time list", "/time update", "/time delete"],
        )
        self.display_hint = "mutation"

    def _register_options(self) -> None:
        self.register_option(
            OptionDeclaration(
                name="type",
                short_name="t",
                layer=OptionLayer.COMMAND,
                help_text="Work item type (Development, Testing, etc.)",
            )
        )
        self.register_option(
            OptionDeclaration(
                name="description",
                short_name="d",
                layer=OptionLayer.COMMAND,
                help_text="Work item description",
            )
        )
        self.register_option(
            OptionDeclaration(
                name="date",
                layer=OptionLayer.COMMAND,
                help_text="Work date (YYYY-MM-DD, defaults to today)",
            )
        )

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        if len(args) < 2:
            raise ValidationError("Usage: kd /time log ISSUE_ID MINUTES")
        issue_id = args[0]
        try:
            minutes = int(args[1])
        except ValueError:
            raise ValidationError(f"MINUTES must be a number, got '{args[1]}'") from None
        work_type = options.command.get("type")
        description = options.command.get("description")
        date_raw = options.command.get("date")
        date_ms = _parse_date(date_raw) if date_raw else None
        item = client.time.log(
            issue_id,
            minutes,
            work_type=work_type,
            description=description,
            date=date_ms,
        )
        return {
            "ok": True,
            "action": "added",
            "id": item.id,
            "issue": issue_id,
            "minutes": item.duration.minutes if item.duration else 0,
            "type": item.type.name if item.type else "",
            "date": item.date,
        }


class TimeUpdateCommand(Command):
    """Update a work item."""

    def __init__(self) -> None:
        super().__init__(
            "update",
            "Update an existing work item",
            requires_client=True,
            usage=(
                "kd /time update ISSUE_ID WORK_ITEM_ID "
                "[--minutes M] [--date DATE] [--type TYPE] [--description DESC]"
            ),
            long_description=(
                "Returns a parseable single-line ack: the last stdout line "
                "is ``ok: <WORK_ITEM_ID> updated issue=<ISSUE_ID> "
                "[<key>=<value> ...]`` listing each field the operator just "
                "changed. The envelope ``id`` is the work item ID (the "
                "entity acted on); the parent issue ID is in ``issue=``. "
                "The structured envelope also carries ``changed: [...]`` "
                "listing every mutated key. Pass --quiet to suppress the "
                "detail block above the ack."
            ),
            examples=[
                "kd /time update FB-42 199-54 --minutes 45",
                'kd /time update FB-42 199-54 --date 2026-01-02 --description "updated"',
            ],
            see_also=["/time log", "/time list", "/time delete"],
        )
        self.display_hint = "mutation"

    def _register_options(self) -> None:
        self.register_option(
            OptionDeclaration(
                name="minutes",
                short_name="m",
                layer=OptionLayer.COMMAND,
                help_text="New duration in minutes",
            )
        )
        self.register_option(
            OptionDeclaration(
                name="date",
                layer=OptionLayer.COMMAND,
                help_text="New work date (YYYY-MM-DD)",
            )
        )
        self.register_option(
            OptionDeclaration(
                name="type",
                short_name="t",
                layer=OptionLayer.COMMAND,
                help_text="New work item type",
            )
        )
        self.register_option(
            OptionDeclaration(
                name="description",
                short_name="d",
                layer=OptionLayer.COMMAND,
                help_text="New description",
            )
        )

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        if len(args) < 2:
            raise ValidationError("Usage: kd /time update ISSUE_ID WORK_ITEM_ID")
        issue_id = args[0]
        work_item_id = args[1]

        minutes_raw = options.command.get("minutes")
        date_raw = options.command.get("date")
        work_type = options.command.get("type")
        description = options.command.get("description")

        if minutes_raw is None and date_raw is None and work_type is None and description is None:
            raise ValidationError(
                "Provide at least one of --minutes, --date, --type, --description"
            )

        minutes: int | None = None
        if minutes_raw is not None:
            try:
                minutes = int(minutes_raw)
            except ValueError:
                raise ValidationError(f"--minutes must be a number, got '{minutes_raw}'") from None

        date_ms = _parse_date(date_raw) if date_raw else None

        item = client.time.update(
            issue_id,
            work_item_id,
            minutes=minutes,
            work_type=work_type,
            description=description,
            date=date_ms,
        )
        envelope: dict[str, Any] = {
            "ok": True,
            "action": "updated",
            "id": item.id,
            "issue": issue_id,
        }
        changed: list[str] = []
        if minutes is not None:
            envelope["minutes"] = item.duration.minutes if item.duration else minutes
            changed.append("minutes")
        if date_ms is not None:
            envelope["date"] = item.date
            changed.append("date")
        if work_type is not None:
            envelope["type"] = item.type.name if item.type else work_type
            changed.append("type")
        if description is not None:
            # Description body is dropped from tail tokens (whitespace);
            # ``changed`` carries the signal for structured consumers.
            changed.append("description")
        envelope["changed"] = changed
        return envelope


class TimeDeleteCommand(Command):
    """Delete a work item."""

    def __init__(self) -> None:
        super().__init__(
            "delete",
            "Delete a work item",
            requires_client=True,
            usage="kd /time delete ISSUE_ID WORK_ITEM_ID",
            long_description=(
                "Returns a parseable single-line ack: the last stdout line "
                "is ``ok: <WORK_ITEM_ID> deleted issue=<ISSUE_ID>``. The "
                "envelope ``id`` is the work item ID (the entity acted "
                "on); the parent issue ID is in ``issue=``. Pass --quiet "
                "to suppress the detail block above the ack."
            ),
            examples=["kd /time delete FB-42 199-54"],
            see_also=["/time list", "/time log", "/time update"],
        )
        self.display_hint = "mutation"

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        if len(args) < 2:
            raise ValidationError("Usage: kd /time delete ISSUE_ID WORK_ITEM_ID")
        client.time.delete(args[0], args[1])
        return {
            "ok": True,
            "action": "deleted",
            "id": args[1],
            "issue": args[0],
        }


def create_time_namespace() -> Namespace:
    """Build the /time namespace tree."""
    ns = Namespace("time", "Time tracking", path="time")
    ns.register_command("list", TimeListCommand())
    ns.register_command("log", TimeLogCommand())
    ns.register_command("update", TimeUpdateCommand())
    ns.register_command("delete", TimeDeleteCommand())
    return ns
