"""User namespace: /user

Commands: list, create, delete
API layer: Hub REST API (/hub/api/rest/users)
"""

from __future__ import annotations

from typing import Any

from kd.cli.core.command_base import Command, CommandResult
from kd.cli.core.confirm import require_confirm
from kd.cli.core.namespaces import Namespace
from kd.cli.core.option_registry import (
    OptionDeclaration,
    OptionLayer,
    ResolvedOptions,
)
from kd.exceptions import ValidationError


class UserListCommand(Command):
    """List users."""

    def __init__(self) -> None:
        super().__init__(
            "list",
            "List users",
            requires_client=True,
            usage="kd /user list",
            examples=["kd /user list"],
            see_also=["/user create"],
        )

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        users = client.users.list()
        return [
            {
                "login": u.login,
                "name": u.name,
                "email": u.email or "",
                "banned": u.banned,
            }
            for u in users
        ]


class UserCreateCommand(Command):
    """Create a user."""

    def __init__(self) -> None:
        super().__init__(
            "create",
            "Create a user",
            requires_client=True,
            usage="kd /user create LOGIN NAME EMAIL",
            long_description=(
                "Returns a parseable single-line ack: the last stdout line "
                "is ``ok: <LOGIN> created`` with ``email=<EMAIL>`` "
                "appended when EMAIL is whitespace-free, and "
                "``name=<NAME>`` appended only when NAME contains no "
                "whitespace (display names typically do — they live in "
                "the structured envelope and the detail block instead). "
                "The envelope ``id`` is the user login (operator-typed "
                "identifier); the internal numeric ID is dropped. Pass "
                "--quiet to suppress the detail block above the ack."
            ),
            examples=['kd /user create testbot "Test Bot" testbot@example.com'],
            see_also=["/user list", "/user delete"],
        )
        self.display_hint = "mutation"

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        if len(args) < 3:
            raise ValidationError("Usage: kd /user create LOGIN NAME EMAIL")
        user = client.users.create(login=args[0], name=args[1], email=args[2])
        return {
            "ok": True,
            "action": "created",
            "id": user.login,
            "name": user.name,
            "email": user.email or "",
        }


class UserDeleteCommand(Command):
    """Delete a user."""

    def __init__(self) -> None:
        super().__init__(
            "delete",
            "Delete a user",
            requires_client=True,
            usage="kd /user delete HUB_USER_ID",
            long_description=(
                "Returns a parseable single-line ack: the last stdout line "
                "is ``ok: <HUB_USER_ID> deleted``. --confirm is required "
                "and is **not** softened by --quiet — the safety gate "
                "fires before any envelope is rendered. Pass --quiet to "
                "suppress the detail block above the ack."
            ),
            examples=["kd /user delete abc-123 --confirm"],
            see_also=["/user list"],
        )
        self.display_hint = "mutation"
        self.register_option(
            OptionDeclaration(
                name="confirm",
                layer=OptionLayer.COMMAND,
                type=bool,
                default=False,
                help_text=(
                    "Required — user delete is not recoverable from Deleted "
                    "Items (consider banning via the Hub UI instead)"
                ),
                hidden_from_reference=True,
            )
        )

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        if not args:
            raise ValidationError("Usage: kd /user delete HUB_USER_ID")
        user_id = args[0]
        require_confirm(
            confirmed=bool(options.command.get("confirm")),
            command="/user delete",
            entity_id=user_id,
            caveat=(
                "Identity references in issue history become detached, and "
                "the account is removed from the Hub. Consider banning the "
                "user in the Hub UI instead; full recovery requires a "
                "database backup restore."
            ),
        )
        client.users.delete(user_id)
        return {"ok": True, "action": "deleted", "id": user_id}


def create_user_namespace() -> Namespace:
    """Build the /user namespace tree."""
    ns = Namespace("user", "User management", path="user")
    ns.register_command("list", UserListCommand())
    ns.register_command("create", UserCreateCommand())
    ns.register_command("delete", UserDeleteCommand())
    return ns
