"""Output formatting.

Renders command results in multiple formats:
- table: human-readable tabular output (unconditional default)
- json: JSON output for piping to jq
- yaml: YAML output
- md: Markdown table

Default is ``table`` regardless of stdout context; TTY state does not
influence format (ADR-006 — TTY detection stays config-first). Consumers
that want JSON or YAML pass ``-o json`` / ``-o yaml`` explicitly.

Value normalization runs before serialization: epoch-ms timestamps become
ISO 8601, enums become their ``.value``, and nested collections render
cleanly in every format.
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any

import yaml
from tabulate import tabulate

from kd.cli.core.command_base import CommandResult
from kd.cli.tree import TreeNode, render_tree

# Fields whose int values are Unix-epoch milliseconds.
TIMESTAMP_FIELDS = frozenset({"created", "updated", "resolved"})

# Fields whose int values are epoch-ms but semantically a date (no time component).
DATE_FIELDS = frozenset({"date"})

# Threshold: timestamps below this are normal ints, not epoch-ms.
# 1_000_000_000_000 ms ≈ 2001-09-09 — all YouTrack timestamps exceed this.
_EPOCH_MS_FLOOR = 1_000_000_000_000

# Detail-table scalars longer than this (or containing newlines) render as
# separate unindented blocks rather than being padded into the key column by
# tabulate. 80 matches the common terminal width; shorter values fit inline
# without padding damage.
_LONG_TEXT_THRESHOLD = 80


def _is_long_text(value: Any) -> bool:
    """Detect scalar strings that should render as their own block."""
    return isinstance(value, str) and ("\n" in value or len(value) > _LONG_TEXT_THRESHOLD)


def emit_warning(code: str, message: str, **context: Any) -> dict[str, Any]:
    """Build a warning entry for the command-result envelope.

    Shape: ``{code, message, context}``.  Callers attach the returned dict
    to a ``warnings: list[...]`` key on the command's result dict.  Table
    and markdown render each warning as ``warning [<code>]: <message>``
    after the normal output block; JSON and YAML pass the list through
    unchanged.  Exit status stays 0 — warnings are advisory, not failures.
    """
    entry: dict[str, Any] = {"code": code, "message": message}
    if context:
        entry["context"] = context
    return entry


def _format_timestamp(epoch_ms: int) -> str:
    """Convert Unix-epoch milliseconds to ``YYYY-MM-DD HH:MM UTC``."""
    dt = datetime.fromtimestamp(epoch_ms / 1000, tz=timezone.utc)
    return dt.strftime("%Y-%m-%d %H:%M UTC")


def _format_date(epoch_ms: int) -> str:
    """Convert Unix-epoch milliseconds to ``YYYY-MM-DD`` (UTC)."""
    dt = datetime.fromtimestamp(epoch_ms / 1000, tz=timezone.utc)
    return dt.strftime("%Y-%m-%d")


class OutputFormatter:
    """Formats CommandResult for display.

    The formatter is pure: every public method returns the rendered string
    for stdout and never writes to any stream itself. ``warnings`` extracted
    from text/md envelopes are exposed via :attr:`last_warnings` so the
    dispatcher can route them to stderr without baking ``sys.stderr.write``
    into a rendering class.
    """

    def __init__(self) -> None:
        # Per-call attribute populated by ``format()`` for text/md modes.
        # Reset on every call. Structured modes (json/yaml) leave warnings
        # in the payload, so ``last_warnings`` stays empty for them.
        self.last_warnings: list[dict[str, Any]] = []

    def format(
        self,
        data: CommandResult,
        fmt: str | None = None,
        fields: str | None = None,
        display_hint: str | None = None,
        quiet: bool = False,
    ) -> str:
        """Format data for output.

        Args:
            data: Structured data from a command.
            fmt: Output format. Defaults to ``"table"`` when None; TTY state
                does not influence the default (ADR-006).
            fields: Comma-separated field names to include.
            display_hint: Rendering hint from the command (e.g. ``"tree"``,
                ``"mutation"``).
            quiet: Suppress the detail block for ``display_hint="mutation"``
                renders. No-op for reads and structured modes.
        """
        self.last_warnings = []
        if data is None:
            return ""
        if isinstance(data, str):
            return data

        normalized: list[dict[str, Any]] | dict[str, Any] = self._normalize(data)

        if fmt is None:
            fmt = "table"

        # Warnings envelope: commands attach a ``warnings`` list to advise
        # the user without failing.  Text/md modes extract them so the
        # dispatcher can render them on stderr (keeping stdout parseable);
        # json/yaml leave them in the payload for structured consumers.
        if (
            isinstance(normalized, dict)
            and isinstance(normalized.get("warnings"), list)
            and fmt in ("table", "md")
        ):
            extracted = normalized.pop("warnings")
            self.last_warnings = [w for w in extracted if isinstance(w, dict)]

        # Mutation envelope: render as a parseable single-line ack with an
        # optional detail block above. ``--quiet`` collapses to the tail
        # line only. Structured modes pass through unchanged so machine
        # readers see the canonical envelope keys.
        if display_hint == "mutation" and isinstance(normalized, dict) and fmt in ("table", "md"):
            return self._render_mutation_result(normalized, quiet=quiet)

        # Tree display: table/md render as pretty tree, json/yaml serialize structure.
        if display_hint == "tree" and isinstance(normalized, dict) and fmt in ("table", "md"):
            return self._render_tree_display(normalized)

        # Primer show: table/md formats drop empty sections so a notes-only
        # primer renders without an empty "articles" row. When both sections
        # are empty, show a populate hint. json/yaml pass through unchanged.
        if (
            display_hint == "primer_show"
            and fmt in ("table", "md")
            and isinstance(normalized, dict)
        ):
            if (
                not normalized.get("notes")
                and not normalized.get("tags")
                and not normalized.get("articles")
            ):
                return (
                    "Primer is empty.\n"
                    '  Populate with: kd /primer/note add "<text>"\n'
                    "                 kd /primer/tag add <TAG_NAME>\n"
                    "                 kd /primer/article add <ARTICLE_ID>"
                )
            normalized = {k: v for k, v in normalized.items() if v}

        # Tag entities: table/md render groups-by-kind with completeness footer;
        # json/yaml return the raw {results, meta} envelope unchanged.
        if (
            display_hint == "tag_entities"
            and fmt in ("table", "md")
            and isinstance(normalized, dict)
        ):
            return self._render_tag_entities_table(normalized)

        field_list = [f.strip() for f in fields.split(",")] if fields else None

        match fmt:
            case "table":
                return self._format_table(normalized, field_list)
            case "json":
                return self._format_json(normalized, field_list)
            case "yaml":
                return self._format_yaml(normalized, field_list)
            case "md":
                return self._format_markdown(normalized, field_list)
            case _:
                return self._format_table(normalized, field_list)

    # ------------------------------------------------------------------
    # Normalization
    # ------------------------------------------------------------------

    def _normalize(self, data: Any) -> Any:
        """Walk *data* and normalize values for safe serialization."""
        if isinstance(data, dict):
            return {k: self._normalize_value(k, v) for k, v in data.items()}
        if isinstance(data, list):
            return [self._normalize(item) for item in data]
        return data

    def _normalize_value(self, key: str, value: Any) -> Any:
        """Normalize a single value based on its key and type."""
        if isinstance(value, int) and key in DATE_FIELDS and value > _EPOCH_MS_FLOOR:
            return _format_date(value)
        if isinstance(value, int) and key in TIMESTAMP_FIELDS and value > _EPOCH_MS_FLOOR:
            return _format_timestamp(value)
        if hasattr(value, "value") and hasattr(value, "name"):  # enum
            return value.value
        if isinstance(value, dict):
            return self._normalize(value)
        if isinstance(value, list):
            return [self._normalize(item) for item in value]
        return value

    # ------------------------------------------------------------------
    # Warnings rendering
    # ------------------------------------------------------------------

    @staticmethod
    def render_warnings(warnings: list[dict[str, Any]]) -> str:
        """Render extracted warnings as ``warning [code]: message`` lines.

        Public so the dispatcher can format ``last_warnings`` for stderr
        without reaching into formatter internals.
        """
        lines: list[str] = []
        for w in warnings:
            if not isinstance(w, dict):
                continue
            code = w.get("code", "warning")
            message = w.get("message", "")
            lines.append(f"warning [{code}]: {message}")
        return "\n".join(lines)

    # ------------------------------------------------------------------
    # Mutation envelope rendering (write-output contract)
    # ------------------------------------------------------------------

    # Keys carried in the tail-line prefix (ok/error + ID + action) or
    # routed to stderr (warnings) — never repeated as ``key=value``
    # context tokens or as detail-block rows.
    _MUTATION_TAIL_RESERVED = frozenset({"ok", "action", "id", "warnings", "error"})

    # Keys excluded from tail tokens but kept in the detail block above.
    # ``project`` is implied by the entity ID prefix (TST-42 → project
    # TST). ``changed`` lists keys mutated this call — already covered by
    # the per-field tokens, so repeating it in the tail would be noise.
    _MUTATION_TAIL_META = frozenset({"project", "changed"})

    def _render_mutation_result(
        self,
        envelope: dict[str, Any],
        quiet: bool = False,
    ) -> str:
        """Render a mutation envelope as a parseable single-line ack.

        Without ``quiet``, prepends a key-value detail block (envelope
        keys minus the tail-line carriers ``ok`` / ``action`` / ``id``;
        ``warnings`` is already extracted by :meth:`format`). The last
        line of the returned string is always the tail-line ack so
        ``tail -1 | awk '{print $2}'`` extracts the entity ID reliably.
        """
        tail = self._format_tail_line(envelope)
        if quiet:
            return tail
        detail_keys = [k for k in envelope if k not in self._MUTATION_TAIL_RESERVED]
        if not detail_keys:
            return tail
        detail = {k: self._mutation_detail_value(envelope[k]) for k in detail_keys}
        block = self._render_detail_table(detail).strip("\n")
        return f"{block}\n{tail}" if block else tail

    @staticmethod
    def _mutation_detail_value(value: Any) -> Any:
        """Coerce envelope values for the mutation detail block.

        List-of-scalars renders as a comma-joined string so the detail
        block reads cleanly (``changed  summary, state``) instead of as
        the Python list repr. Other shapes pass through untouched.
        """
        if isinstance(value, list) and all(not isinstance(v, dict) for v in value):
            return ", ".join(str(v) for v in value)
        return value

    def _format_tail_line(self, envelope: dict[str, Any]) -> str:
        """Build the single-line ack: ``ok: <ID> <action> [key=value ...]``.

        Failure envelopes (``ok=False``) render as ``error: <ID> <code>``.
        Multi-value list fields join with comma (``tags=foo,bar``). String
        values containing whitespace are skipped from the tail tokens —
        the detail block carries them, and structured output stays
        canonical for any value the tail line cannot represent cleanly.

        When ``id`` is None or empty, the head renders ``<none>`` as a
        placeholder so token order stays fixed (``$2`` is always the ID
        slot, ``$3`` is always the action). The placeholder is non-
        ID-extractable by design — scripts that detect ``$2 == "<none>"``
        know to fall back to ``-o yaml``. Today this happens on
        ``/article push --dry-run`` for the create branch (no upstream
        article exists yet).
        """
        ok = envelope.get("ok", True)
        raw_id = envelope.get("id")
        entity_id = "<none>" if raw_id is None or raw_id == "" else str(raw_id)

        if not ok:
            err = envelope.get("error")
            code = "error"
            if isinstance(err, dict):
                code = str(err.get("code", "error"))
            elif isinstance(err, str):
                code = err
            return f"error: {entity_id} {code}"

        action = "" if envelope.get("action") is None else str(envelope.get("action"))
        tokens: list[str] = []
        for key, value in envelope.items():
            if key in self._MUTATION_TAIL_RESERVED or key in self._MUTATION_TAIL_META:
                continue
            rendered = self._render_tail_token(value)
            if rendered is None:
                continue
            tokens.append(f"{key}={rendered}")

        head = ["ok:", entity_id, action]
        return " ".join(p for p in head + tokens if p)

    @staticmethod
    def _render_tail_token(value: Any) -> str | None:
        """Render a single envelope value as a tail-line token side.

        Returns ``None`` when the value cannot be represented as a single
        whitespace-free token — empty values, dicts, and strings that
        would break ``awk -F= '{print $2}'`` extraction. The detail block
        above the tail line still carries them.

        Booleans render lowercase (``true`` / ``false``) so the tail
        grammar is shell- and JSON-friendly. A ``False`` value still
        appears as ``key=false`` rather than being suppressed — commands
        that want to skip a noisy negative should drop the key from the
        envelope rather than rely on bool-falsy suppression.
        """
        if value is None:
            return None
        if value is True:
            return "true"
        if value is False:
            return "false"
        if isinstance(value, list):
            if not value:
                return None
            joined = ",".join(str(v) for v in value)
            return joined if joined and " " not in joined else None
        if isinstance(value, dict):
            return None
        rendered = str(value)
        if rendered == "" or " " in rendered or "\t" in rendered or "\n" in rendered:
            return None
        return rendered

    # ------------------------------------------------------------------
    # Tree rendering
    # ------------------------------------------------------------------

    @staticmethod
    def _render_tree_display(data: dict[str, Any]) -> str:
        """Render nested tree dict as pretty box-drawing output."""

        def _to_node(d: dict[str, Any]) -> TreeNode:
            return TreeNode(
                id=d.get("id", ""),
                label=d.get("summary", d.get("id", "")),
                has_children=bool(d.get("children")),
            )

        def _fetch_children(node_id: str) -> list[TreeNode]:
            # Walk the tree dict to find the node and return its children
            children = _find_children(data, node_id)
            return [_to_node(c) for c in children]

        def _find_children(node: dict[str, Any], target_id: str) -> list[dict[str, Any]]:
            kids: list[dict[str, Any]] = node.get("children", [])
            if node.get("id") == target_id:
                return kids
            for child in kids:
                result = _find_children(child, target_id)
                if result is not None:
                    return result
            return []

        root = _to_node(data)
        return render_tree(root, _fetch_children)

    # ------------------------------------------------------------------
    # Tag entities rendering
    # ------------------------------------------------------------------

    @staticmethod
    def _render_tag_entities_table(data: dict[str, Any]) -> str:
        """Render /tag entities output as grouped-by-kind tables with footer.

        Row columns: id, updated, project, summary.  Tag membership is
        implicit given the query, so the tags column is omitted.

        The footer reports per-kind completeness (``complete`` / ``truncated``)
        and any per-kind errors (``error: <code>``).  Structured consumers
        must still read ``meta`` — exit 0 does not mean every kind succeeded.
        """
        results = data.get("results", [])
        meta = data.get("meta", {})
        if not results and not any(m.get("error") for m in meta.values()):
            return "(no entries)"

        groups: dict[str, list[dict[str, Any]]] = {"article": [], "issue": []}
        for row in results:
            kind = row.get("kind")
            if kind in groups:
                groups[kind].append(row)

        parts: list[str] = []
        for kind in ("article", "issue"):
            rows = groups[kind]
            if not rows:
                continue
            heading = f"{kind}s ({len(rows)})"
            parts.append(heading)
            sub_rows = [
                [
                    r.get("id_readable", ""),
                    r.get("updated", ""),
                    r.get("project", ""),
                    r.get("summary", ""),
                ]
                for r in rows
            ]
            parts.append(
                "  "
                + tabulate(
                    sub_rows,
                    headers=["id", "updated", "project", "summary"],
                    tablefmt="simple",
                ).replace("\n", "\n  ")
            )
            parts.append("")

        footer_bits: list[str] = []
        for kind in ("article", "issue"):
            m = meta.get(kind)
            if m is None:
                continue
            count = m.get("count", 0)
            label = f"{count} {kind}s"
            if m.get("error"):
                err = m["error"]
                code = err.get("code", "error") if isinstance(err, dict) else "error"
                footer_bits.append(f"{label} (error: {code})")
                continue
            if m.get("complete") == "unknown":
                footer_bits.append(f"{label} (completeness unknown)")
            elif m.get("truncated"):
                flag = f"--limit-{kind}s"
                footer_bits.append(f"{label} (truncated — use {flag} K or --kind {kind})")
            else:
                footer_bits.append(f"{label} (complete)")

        if footer_bits:
            parts.append("Showing " + ", ".join(footer_bits) + ".")
        return "\n".join(parts).rstrip()

    # ------------------------------------------------------------------
    # Format dispatchers
    # ------------------------------------------------------------------

    def _format_table(
        self, data: list[dict[str, Any]] | dict[str, Any], fields: list[str] | None
    ) -> str:
        """Format as plain text table."""
        if isinstance(data, dict):
            filtered_dict = self._filter_dict(data, fields)
            return self._render_detail_table(filtered_dict)

        filtered_rows = self._filter_list(data, fields)
        if not filtered_rows:
            return "(no entries)"
        headers = list(filtered_rows[0].keys())
        rows = [list(row.values()) for row in filtered_rows]
        result: str = tabulate(rows, headers=headers, tablefmt="simple")
        return result

    def _render_detail_table(self, data: dict[str, Any]) -> str:
        """Render a single-entity detail view.

        Scalar fields are aligned in a two-column key/value block.
        Nested lists of dicts become indented sub-tables with a header.
        Long-text scalars (newlines or > ``_LONG_TEXT_THRESHOLD`` chars)
        are lifted out of the scalar block and rendered unindented so
        multi-line markdown stays copy-paste clean.
        """
        parts: list[str] = []
        rows: list[list[Any]] = []

        def _flush_rows() -> None:
            if rows:
                parts.append(tabulate(rows, tablefmt="plain"))
                rows.clear()

        for key, value in data.items():
            if isinstance(value, list) and value and isinstance(value[0], dict):
                _flush_rows()
                parts.append(f"\n{key}")
                sub_headers = list(value[0].keys())
                sub_rows = [list(item.values()) for item in value]
                parts.append(
                    "  "
                    + tabulate(sub_rows, headers=sub_headers, tablefmt="simple").replace(
                        "\n", "\n  "
                    )
                )
            elif _is_long_text(value):
                _flush_rows()
                parts.append(f"\n{key}:")
                parts.append(str(value))
            else:
                rows.append([key, value])
        _flush_rows()
        return "\n".join(parts)

    def _format_json(
        self, data: list[dict[str, Any]] | dict[str, Any], fields: list[str] | None
    ) -> str:
        """Format as JSON."""
        filtered = self._filter(data, fields)
        return json.dumps(filtered, indent=2)

    def _format_yaml(
        self, data: list[dict[str, Any]] | dict[str, Any], fields: list[str] | None
    ) -> str:
        """Format as YAML."""
        filtered = self._filter(data, fields)
        result: str = yaml.safe_dump(
            filtered,
            default_flow_style=False,
            sort_keys=False,
            allow_unicode=True,
        )
        return result.rstrip()

    def _format_markdown(
        self, data: list[dict[str, Any]] | dict[str, Any], fields: list[str] | None
    ) -> str:
        """Format as Markdown table."""
        if isinstance(data, dict):
            filtered_dict = self._filter_dict(data, fields)
            rows = [[k, v] for k, v in filtered_dict.items()]
            result: str = tabulate(rows, headers=["Key", "Value"], tablefmt="github")
            return result

        filtered_rows = self._filter_list(data, fields)
        if not filtered_rows:
            return ""
        headers = list(filtered_rows[0].keys())
        rows = [list(row.values()) for row in filtered_rows]
        result = tabulate(rows, headers=headers, tablefmt="github")
        return result

    def _filter(
        self,
        data: list[dict[str, Any]] | dict[str, Any],
        fields: list[str] | None,
    ) -> list[dict[str, Any]] | dict[str, Any]:
        """Apply field filtering to data."""
        if isinstance(data, dict):
            return self._filter_dict(data, fields)
        return self._filter_list(data, fields)

    def _filter_dict(self, data: dict[str, Any], fields: list[str] | None) -> dict[str, Any]:
        """Filter dict keys to only requested fields."""
        if not fields:
            return data
        return {k: v for k, v in data.items() if k in fields}

    def _filter_list(
        self, data: list[dict[str, Any]], fields: list[str] | None
    ) -> list[dict[str, Any]]:
        """Filter list of dicts to only requested fields."""
        if not fields:
            return data
        return [{k: v for k, v in row.items() if k in fields} for row in data]
