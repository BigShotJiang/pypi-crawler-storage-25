"""Named connection configuration and runtime resolution.

A connection represents a complete working context: URL, auth source,
defaults, and compatibility profile for a single YouTrack instance.

Config-level models (:class:`ConnectionConfig`, :class:`CompatibilityConfig`)
map directly to YAML.  :class:`ConnectionContext` is the frozen runtime object
that commands and the SDK receive after token resolution and override merging.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Literal

from pydantic import BaseModel, Field, field_validator, model_validator

from kd.auth import resolve_connection_token
from kd.exceptions import ConfigError

if TYPE_CHECKING:
    from collections.abc import Mapping

    from kd.config import ConnectionOrigin
    from kd.debug import DebugLog


# ---------------------------------------------------------------------------
# Config models (YAML ↔ Pydantic)
# ---------------------------------------------------------------------------


class CompatibilityConfig(BaseModel):
    """Per-connection compatibility settings.

    Only ``pinned`` mode in M031.  ``probe`` mode arrives in M033.
    """

    target: str = Field(
        default="auto",
        description="Compatibility tier label (e.g. 2023.2, 2026.1, auto)",
    )
    mode: Literal["pinned"] = Field(
        default="pinned",
        description="Resolution mode — only 'pinned' is supported",
    )


class ConnectionConfig(BaseModel):
    """One named connection in the ``connections:`` config section."""

    provider: str = Field(
        default="youtrack",
        description="Provider identifier",
    )
    url: str = Field(
        description="YouTrack instance base URL",
    )
    token_cmd: str | None = Field(
        default=None,
        description="Shell command that prints the API token to stdout",
    )
    token_env: str | None = Field(
        default=None,
        description="Environment variable name containing the API token",
    )
    default_project: str | None = Field(
        default=None,
        description="Default project key for commands accepting --project",
    )
    output: str | None = Field(
        default=None,
        description="Connection-level output format override",
    )
    limit: int | None = Field(
        default=None,
        description="Connection-level result limit override",
    )
    defaults: dict[str, dict[str, Any]] = Field(
        default_factory=dict,
        description="Per-command defaults scoped to this connection",
    )
    compatibility: CompatibilityConfig = Field(
        default_factory=CompatibilityConfig,
        description="Version targeting (target + mode)",
    )

    @field_validator("url", mode="after")
    @classmethod
    def _normalize_url(cls, value: str) -> str:
        return value.rstrip("/")

    @model_validator(mode="after")
    def _require_auth_source(self) -> ConnectionConfig:
        if not self.token_cmd and not self.token_env:
            msg = (
                "Connection must specify at least one of 'token_cmd' or 'token_env'. "
                "Secrets are never stored as raw values in config."
            )
            raise ValueError(msg)
        return self


# ---------------------------------------------------------------------------
# Runtime context (frozen, post-resolution)
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ConnectionContext:
    """Resolved runtime state for the active connection.

    Created by :func:`resolve_connection` after token resolution and
    override merging.  Commands receive this — never raw config models.
    """

    name: str
    provider: str
    base_url: str
    token: str
    default_project: str | None
    output: str | None
    limit: int | None
    defaults: dict[str, dict[str, Any]]
    compat_tier: str
    capabilities: frozenset[str]  # empty in M031, populated in M033


# ---------------------------------------------------------------------------
# Connection resolution
# ---------------------------------------------------------------------------


def resolve_connection(
    connections: dict[str, ConnectionConfig],
    default_connection: str | None,
    *,
    connection_origins: Mapping[str, ConnectionOrigin] | None = None,
    debug_log: DebugLog | None = None,
) -> ConnectionContext:
    """Resolve the active connection into a :class:`ConnectionContext`.

    Parameters
    ----------
    connections:
        All parsed ``ConnectionConfig`` objects keyed by name.
    default_connection:
        Name of the connection to resolve (from ``default_connection`` config key).
    connection_origins:
        Per-connection provenance from :class:`ResolvedConfig`, used to
        cite the originating config file in auth-error messages.
    debug_log:
        Optional debug logger.
    """
    if not connections:
        raise ConfigError(
            "No connections configured. Add a 'connections:' section to your config "
            "(run 'kd init' to scaffold one)."
        )

    if not default_connection:
        if len(connections) == 1:
            default_connection = next(iter(connections))
        else:
            names = ", ".join(sorted(connections))
            raise ConfigError(
                f"No default_connection set and multiple connections exist ({names}). "
                "Use -c <name> or set 'default_connection' in your config."
            )

    if default_connection not in connections:
        names = ", ".join(sorted(connections))
        raise ConfigError(
            f"Connection '{default_connection}' not found. Available connections: {names}. "
            "Use -c <name> or set 'default_connection' in your config."
        )

    conn = connections[default_connection]

    if debug_log:
        debug_log.info("connection", f"resolving connection '{default_connection}'")

    origin = connection_origins.get(default_connection) if connection_origins else None
    token = resolve_connection_token(
        conn,
        name=default_connection,
        origin=origin,
        debug_log=debug_log,
    )

    if debug_log:
        debug_log.info("connection", f"url={conn.url}")
        debug_log.info("connection", f"compat_tier={conn.compatibility.target}")

    return ConnectionContext(
        name=default_connection,
        provider=conn.provider,
        base_url=conn.url,
        token=token,
        default_project=conn.default_project,
        output=conn.output,
        limit=conn.limit,
        defaults=conn.defaults,
        compat_tier=conn.compatibility.target,
        capabilities=frozenset(),
    )


def resolve_active_connection_name(
    connections: dict[str, ConnectionConfig],
    default_connection: str | None,
) -> str:
    """Resolve the active connection name without resolving its token.

    Mirrors the auto-select / multi-without-default diagnostic from
    :func:`resolve_connection`, but skips the token-resolution step so
    local-only operations (e.g., ``kd /cache clear``) do not fail when
    ``token_env`` is missing or ``token_cmd`` errors.
    """
    if not connections:
        raise ConfigError(
            "No connections configured. Add a 'connections:' section to your config "
            "(run 'kd init' to scaffold one)."
        )

    if not default_connection:
        if len(connections) == 1:
            return next(iter(connections))
        names = ", ".join(sorted(connections))
        raise ConfigError(
            f"No default_connection set and multiple connections exist ({names}). "
            "Use -c <name> or set 'default_connection' in your config."
        )

    if default_connection not in connections:
        names = ", ".join(sorted(connections))
        raise ConfigError(
            f"Connection '{default_connection}' not found. Available connections: {names}. "
            "Use -c <name> or set 'default_connection' in your config."
        )

    return default_connection
