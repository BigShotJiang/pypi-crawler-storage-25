"""SDLC doctrine loader.

Reads the bundled ``kd/resources/sdlc-doctrine.md`` for ``kd --sdlc``.
The doctrine is the portable, project-agnostic statement of the SDLC
method (layers, cycle variants, verification modes, publication tiers,
reconciliation, repo-doc audit, profile extension point) — a complement
to the kd-specific ``kd --guide``.
"""

from __future__ import annotations

import importlib.resources


def load_sdlc_doctrine() -> str:
    """Read the bundled portable SDLC doctrine as text."""
    return (
        importlib.resources.files("kd.resources")
        .joinpath("sdlc-doctrine.md")
        .read_text(encoding="utf-8")
    )
