"""Models for the ``/tag entities`` cross-entity discovery surface.

`EntityRef` is the unified row type used across issues and articles in
a single result list. `KindMeta` carries per-kind completeness and
failure state. `TagEntitiesResult` is the envelope returned by
``TagOperations.entities()``.
"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field


class EntityRef(BaseModel):
    """Cross-entity reference row for `/tag entities` results."""

    model_config = ConfigDict(populate_by_name=True)

    kind: Literal["issue", "article"]
    id_readable: str
    summary: str | None = None
    project: str | None = None
    updated: int | None = None
    tags: list[str] = Field(default_factory=list)


class KindMeta(BaseModel):
    """Per-kind completeness and failure state."""

    model_config = ConfigDict(populate_by_name=True)

    scanned: bool
    complete: bool | Literal["unknown"]
    truncated: bool
    count: int
    limit_per_kind: int
    error: dict[str, str] | None = None


class TagEntitiesResult(BaseModel):
    """Envelope returned by `TagOperations.entities()`."""

    model_config = ConfigDict(populate_by_name=True)

    results: list[EntityRef] = Field(default_factory=list)
    meta: dict[str, KindMeta] = Field(default_factory=dict)


def tag_entities_result_to_dict(result: TagEntitiesResult) -> dict[str, Any]:
    """Project a `TagEntitiesResult` to its on-the-wire shape.

    Single source of truth for `/tag entities` output and for the
    cached `queries/primer-scope.yaml` payload (M008 S5). Both
    consumers must call this helper so live and cached payloads stay
    structurally identical (the cached file additionally carries the
    cache banner).
    """
    return {
        "results": [r.model_dump() for r in result.results],
        "meta": {k: m.model_dump(exclude_none=True) for k, m in result.meta.items()},
    }
