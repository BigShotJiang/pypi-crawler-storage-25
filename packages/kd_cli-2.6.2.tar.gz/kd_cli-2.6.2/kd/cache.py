"""Disposable upstream-mirror cache for `.kd/cache/`.

Provides the directory contract, self-describing banner renderers, writer
primitives for cached articles / issues / queries, and the `clear_cache`
operation behind ``kd /cache clear``.

Cache content is rehydratable upstream-mirror data — articles pulled by
``kd /cache refresh`` (S5+), issue payloads, query result snapshots.
Files open with a self-describing banner that names the upstream entity
and the fetched timestamp, so an LLM or operator inspecting a cache file
in isolation knows it is not authoritative.

Atomic-write hygiene routes through :func:`kd.history.atomic_write_text`.
Cache files do **not** use ``snapshot_before_write`` — copy-on-write
contradicts the disposable banner and would balloon ``.kd/cache/history/``.
"""

from __future__ import annotations

import dataclasses
import re
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Literal

import yaml

from kd.connection import ConnectionContext
from kd.exceptions import APIError, ConfigError, ValidationError
from kd.history import atomic_write_text
from kd.models.tag_entities import TagEntitiesResult, tag_entities_result_to_dict
from kd.primer import PRIMER_FILENAME, PrimerArticle, PrimerTag, load_primer, require_workspace_dir
from kd.query_parser import youtrack_query_literal

# Public surface: names imported by external callers (CLI, client) and the
# dataclasses that flow back as return types. Underscore-prefixed helpers stay
# internal. Pinned by the boundary test in tests/test_cache.py.
__all__ = [
    # Constants
    "ARTICLES_DIRNAME",
    "ARTICLE_PUSH_REFRESH_COMMAND",
    "BANNER_TEMPLATE_MD",
    "BANNER_TEMPLATE_YAML",
    "CACHE_DIRNAME",
    "CONNECTIONS_DIRNAME",
    "DEFAULT_SEARCH_LIMIT",
    "DEFAULT_STALE_AFTER_DAYS",
    "EPIC_LINK_DIRECTION",
    "EPIC_LINK_TYPE",
    "EPIC_REFRESH_COMMAND",
    "INDEX_FILENAME",
    "ISSUES_DIRNAME",
    "MILESTONE_REFRESH_COMMAND",
    "MILESTONE_SLUG_PREFIX",
    "PRIMER_SCOPE_QUERY_SLUG",
    "PRIMER_SCOPE_REFRESH_COMMAND",
    "QUERIES_DIRNAME",
    "QUERY_NAME_REFRESH_COMMAND",
    "SCOPE_MANIFEST_FILENAME",
    "SCOPE_MANIFEST_KIND",
    "SEARCHABLE_KINDS",
    "SINGLE_ARTICLE_REFRESH_COMMAND",
    "SINGLE_ISSUE_REFRESH_COMMAND",
    # Public dataclasses (return types and configuration carriers)
    "ArticleCacheMeta",
    "ArticleRefreshReport",
    "CacheCounts",
    "CacheScopeEnumeration",
    "CacheScopeManifest",
    "CacheScopeRef",
    "CacheSearchMatch",
    "CacheSearchMeta",
    "CacheSearchReport",
    "CacheSearchScopeRef",
    "CacheSource",
    "CacheStatusInfo",
    "CacheStatusReport",
    "CacheStatusWarning",
    "ClearReport",
    "ClearReportError",
    "EpicRefreshReport",
    "FailedArticle",
    "FailedIssue",
    "FailedQuery",
    "FailedStage",
    "HydratedArticle",
    "HydratedIssue",
    "HydratedMilestoneRun",
    "HydratedQuery",
    "HydratedQueryRun",
    "IssueRefreshReport",
    "MilestoneRefreshReport",
    "QueryNameRefreshReport",
    "QueryRefreshReport",
    "RefreshReport",
    "ScopeHealthReport",
    "SingleArticleRefreshReport",
    "UnscopedCacheReport",
    # Path resolvers
    "cache_dir",
    "connection_cache_dir",
    # Writer primitives
    "article_to_cache_meta",
    "write_cached_article",
    "write_cached_issue",
    "write_cached_query",
    "write_scope_manifest",
    # Readers
    "compute_cache_status",
    "enumerate_cache_scopes",
    "read_cached_article_upstream_updated",
    "scan_scope_health",
    "search_cache",
    # Refresh orchestrators
    "refresh_article",
    "refresh_epic_with_children",
    "refresh_issue",
    "refresh_milestone",
    "refresh_primer_scope",
    "refresh_query",
    # Clear
    "clear_all_scopes",
    "clear_cache",
    # Slug helpers
    "slug_for_connection_name",
    "slug_for_milestone_value",
    "slug_for_query_name",
]

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

CACHE_DIRNAME = "cache"
INDEX_FILENAME = "index.yaml"  # reserved; first written at S8

ARTICLES_DIRNAME = "articles"
ISSUES_DIRNAME = "issues"
QUERIES_DIRNAME = "queries"

CONNECTIONS_DIRNAME = "connections"
SCOPE_MANIFEST_FILENAME = "scope.yaml"
SCOPE_MANIFEST_KIND = "cache_scope"

#: Markdown banner for cached article bodies. Five-space continuation
#: indent matches ``"<!-- "`` width so the banner reads as one logical
#: line. Pinned by tests; aligned with KDCLI-A-18 §Cache contract.
BANNER_TEMPLATE_MD = (
    "<!-- kd-cache: upstream={id} fetched={iso}.\n"
    "     Disposable mirror. Edits lost on refresh. Not authoritative. -->"
)

#: YAML banner for cached issue / query payloads. Two ``# ``-prefixed
#: lines. Pinned by tests.
BANNER_TEMPLATE_YAML = (
    "# kd-cache: upstream={id} fetched={iso}.\n"
    "# Disposable mirror. Edits lost on refresh. Not authoritative."
)


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class CacheSource:
    """Why and how this cache entry was hydrated."""

    command: str
    reason: str


@dataclass
class ArticleCacheMeta:
    """Sidecar metadata for a cached article (`<id>.meta.yaml`).

    Required fields come first (Python dataclasses reject a non-default
    field after a default field). ``kind`` is locked to ``"article"`` via
    ``init=False`` so the writer owns the schema; callers cannot pass it.
    """

    id: str
    project: str | None
    summary: str | None
    tags: list[str]
    upstream_updated: str | None
    fetched_at: str
    source: CacheSource
    kind: str = field(default="article", init=False)


@dataclass(frozen=True)
class CacheScopeManifest:
    """Per-scope identity manifest written at ``scope.yaml``.

    Records the immutable identity tuple that pins a connection-scoped
    cache directory to its upstream. Refresh idempotency compares
    ``(kind, connection, provider, base_url, compat_tier)``; mismatch
    means the scope dir is being aimed at a different upstream and the
    refresh refuses to proceed. ``created_at`` is preserved on full
    identity match.
    """

    connection: str
    provider: str
    base_url: str
    compat_tier: str
    created_at: str
    kind: str = field(default=SCOPE_MANIFEST_KIND, init=False)


@dataclass
class ClearReportError:
    """One per-path failure encountered during ``clear_cache``."""

    path: str
    reason: str


@dataclass
class ClearReport:
    """Result of a single ``clear_cache`` invocation."""

    existed: bool
    articles_removed: int
    issues_removed: int
    queries_removed: int
    other_removed: int
    errors: list[ClearReportError]


@dataclass
class HydratedArticle:
    """One pinned article successfully written to the cache."""

    id: str
    summary: str | None
    upstream_updated: str | None
    path: str


@dataclass
class FailedArticle:
    """One pinned article that failed to hydrate."""

    id: str
    reason: str


@dataclass
class ArticleRefreshReport:
    """Per-article half of :class:`RefreshReport`."""

    skipped_no_pinned: bool
    hydrated: list[HydratedArticle]
    failed: list[FailedArticle]


@dataclass
class HydratedQuery:
    """One query payload successfully written to the cache."""

    slug: str
    path: str
    issue_count: int
    article_count: int


@dataclass
class FailedQuery:
    """One query payload whose whole call failed."""

    slug: str
    reason: str


@dataclass
class QueryRefreshReport:
    """Per-query half of :class:`RefreshReport`."""

    skipped_no_pinned_tags: bool
    hydrated: list[HydratedQuery]
    failed: list[FailedQuery]


@dataclass
class RefreshReport:
    """Result of a single ``refresh_primer_scope`` invocation."""

    articles: ArticleRefreshReport
    queries: QueryRefreshReport


@dataclass
class HydratedIssue:
    """One issue successfully written to the cache.

    ``comments_count`` is ``None`` when ``--include-comments`` is unset,
    distinguishing "not requested" from "requested, zero present" for
    later status reporting (M008 S8).
    """

    id: str
    summary: str | None
    upstream_updated: str | None
    path: str
    comments_count: int | None


@dataclass
class FailedIssue:
    """One issue that failed to hydrate."""

    id: str
    reason: str


@dataclass
class IssueRefreshReport:
    """Result of a single ``refresh_issue`` invocation.

    Drops ``skipped_no_pinned`` because the selector is an id, never the
    primer; list-shaped so S7's ``--epic --include-children`` can return
    the same type with more entries.
    """

    hydrated: list[HydratedIssue]
    failed: list[FailedIssue]


@dataclass
class SingleArticleRefreshReport:
    """Result of a single ``refresh_article`` invocation.

    Reuses :class:`HydratedArticle` / :class:`FailedArticle`. Distinct
    top-level type from :class:`ArticleRefreshReport` because the
    "skipped because primer empty" semantic never applies to single-
    entity selectors.
    """

    hydrated: list[HydratedArticle]
    failed: list[FailedArticle]


@dataclass
class HydratedQueryRun:
    """One saved-query run successfully written to the cache.

    Distinct from :class:`HydratedQuery` (the primer-scope tag-entities
    payload, which carries ``issue_count`` + ``article_count`` because
    that query returns both kinds). A saved-query run is an issue list,
    so the count is unitary; ``truncated`` flags when the upstream
    returned exactly ``limit`` rows and the operator should consider
    raising ``--limit`` or selecting the rows of interest by id.
    """

    query_name: str
    query_id: str
    slug: str
    path: str
    count: int
    truncated: bool


@dataclass
class QueryNameRefreshReport:
    """Result of a single ``refresh_query`` invocation.

    Reuses :class:`FailedQuery` (``slug + reason``) so failure shape
    matches S5's primer-scope query path. Single-call operation, so a
    failure surfaces as a one-element ``failed`` list and the command
    still exits 0 with the structured report.
    """

    hydrated: list[HydratedQueryRun]
    failed: list[FailedQuery]


@dataclass
class HydratedMilestoneRun:
    """One milestone-scoped query successfully written to the cache.

    Captures the field-origin annotation pattern (KDCLI-102 / KDCLI-107):
    ``field_name`` is the *actual upstream field name* discovered from
    project metadata (e.g. ``Milestone`` in KDCLI vs. ``Stage`` in a
    project that aliased ``milestone`` → ``Stage``), so a downstream
    reader can tell which project field produced the row set without
    guessing. ``milestone_value`` is the canonical post-bundle-validation
    value (or the operator's input verbatim for freeform fields).
    """

    milestone_value: str
    project_key: str
    field_name: str
    query_text: str
    slug: str
    path: str
    count: int
    truncated: bool


@dataclass
class MilestoneRefreshReport:
    """Result of a single ``refresh_milestone`` invocation.

    Reuses :class:`FailedQuery` so failure shape stays consistent with
    S5 / S7a. Single-call operation; a failure surfaces as a one-element
    ``failed`` list and the command still exits 0 with the structured
    report.
    """

    hydrated: list[HydratedMilestoneRun]
    failed: list[FailedQuery]


@dataclass
class FailedStage:
    """One staged failure in :class:`EpicRefreshReport`.

    Stage discriminator pins where the run died — epic rich-fetch (no
    epic file, no manifest, no children attempted) vs link enumeration
    (epic file written, manifest deliberately skipped, no children
    attempted). Per-child rich-fetch failures land in ``children_failed``
    instead, so a single bad child does not abort the run.
    """

    stage: Literal["epic_fetch", "link_enumeration"]
    id: str
    reason: str


@dataclass
class EpicRefreshReport:
    """Result of a single ``refresh_epic_with_children`` invocation.

    Invariants pinned by tests:

    - ``failed[stage=="epic_fetch"]`` ⇒ ``epic is None``,
      ``children == []``, ``children_failed == []``,
      ``manifest_path is None``.
    - ``failed[stage=="link_enumeration"]`` ⇒ ``epic is not None``,
      ``children == []``, ``children_failed == []``,
      ``manifest_path is None``.
    - ``failed == []`` ⇒ ``epic is not None`` and
      ``manifest_path is not None`` (the manifest is always written
      when link enumeration succeeded, even with ``child_count: 0``).
    """

    epic: HydratedIssue | None
    children: list[HydratedIssue]
    children_failed: list[FailedIssue]
    failed: list[FailedStage]
    manifest_path: str | None


@dataclass
class CacheStatusWarning:
    """One non-fatal finding raised during a cache status scan.

    ``code`` is a stable machine token (e.g. ``cache_stale``,
    ``banner_unparseable``, ``sidecar_unparseable``,
    ``article_pair_mismatch``). ``message`` is a human-readable detail.
    ``path`` names the offending file when applicable; ``None`` for
    aggregate warnings such as ``cache_stale``.
    """

    code: str
    message: str
    path: str | None = None


@dataclass
class CacheCounts:
    """Per-kind file counts within a single scope or the unscoped block."""

    articles: int
    issues: int
    queries: int


@dataclass
class ScopeHealthReport:
    """Health summary for one connection-scoped cache directory."""

    slug: str
    active: bool
    connection: str
    provider: str
    base_url: str
    compat_tier: str
    counts: CacheCounts
    latest_fetch: str | None
    oldest_fetch: str | None
    stale_count: int
    has_warnings: bool
    warnings: list[CacheStatusWarning]


@dataclass
class UnscopedCacheReport:
    """Counts for any pre-S8a flat ``articles/`` / ``issues/`` / ``queries/``
    content sitting directly under ``.kd/cache/`` (no ``connections/`` parent)."""

    counts: CacheCounts
    latest_fetch: str | None


@dataclass
class CacheStatusInfo:
    """Top-level ``cache:`` block shape for the status report."""

    path: str
    active_scope: str | None
    stale_after_days: int
    totals: CacheCounts
    not_initialized: bool


@dataclass
class CacheStatusReport:
    """Result of a single ``compute_cache_status`` call."""

    cache: CacheStatusInfo
    scopes: list[ScopeHealthReport]
    unscoped: UnscopedCacheReport | None
    orphan_scopes: list[str]


@dataclass
class CacheScopeRef:
    """One enumerated scope: directory slug + parsed manifest + path."""

    slug: str
    path: str
    manifest: CacheScopeManifest


@dataclass
class CacheSearchMatch:
    """One file with a hit returned by :func:`search_cache`."""

    path: str
    connection: str | None
    slug: str
    kind: str
    id: str
    summary: str | None
    matched_field: str
    snippet: str


@dataclass
class CacheSearchScopeRef:
    """A scope (or the unscoped legacy block) included in the search."""

    connection: str | None
    slug: str


@dataclass
class CacheSearchMeta:
    """Diagnostic block for a :class:`CacheSearchReport`."""

    scopes_searched: list[CacheSearchScopeRef]
    unscoped_searched: bool
    kinds_searched: list[str]
    matches_found: int
    truncated: bool
    warnings: list[CacheStatusWarning]


@dataclass
class CacheSearchReport:
    """Result of a single :func:`search_cache` invocation."""

    matches: list[CacheSearchMatch]
    meta: CacheSearchMeta


@dataclass
class CacheScopeEnumeration:
    """Result of :func:`enumerate_cache_scopes`.

    ``orphan_dirs`` lists scope directories that lack a ``scope.yaml`` —
    surfaced as a warning rather than raised, so a hand-deleted manifest
    does not crash status.
    """

    scopes: list[CacheScopeRef]
    orphan_dirs: list[str]


# ---------------------------------------------------------------------------
# Path helpers
# ---------------------------------------------------------------------------


def cache_dir(start: Path | None = None) -> Path:
    """Return the cache directory inside the nearest ``.kd/`` workspace.

    Raises :class:`ConfigError` outside a workspace, mirroring
    :func:`kd.primer._primer_path`.
    """
    return require_workspace_dir(start) / CACHE_DIRNAME


def connection_cache_dir(
    connection: ConnectionContext,
    start: Path | None = None,
) -> Path:
    """Return the per-connection scope directory under ``.kd/cache/connections/``.

    The directory segment is :func:`slug_for_connection_name` of the
    connection's name; the unsanitized name is recorded inside
    ``scope.yaml`` for identity. Raises :class:`ConfigError` outside a
    workspace; raises :class:`ValidationError` when the connection name
    sluggifies to an empty string.
    """
    return cache_dir(start) / CONNECTIONS_DIRNAME / slug_for_connection_name(connection.name)


def _is_flat_cache_root(resolved: Path) -> bool:
    return resolved.name == CACHE_DIRNAME and resolved.parent.name == ".kd"


def _is_scoped_cache_root(resolved: Path) -> bool:
    parent = resolved.parent
    grand = parent.parent
    great = grand.parent
    return (
        parent.name == CONNECTIONS_DIRNAME and grand.name == CACHE_DIRNAME and great.name == ".kd"
    )


def _validate_cache_artifact_root(cache_root: Path | None) -> Path:
    """Validate a cache root that hosts artifact subdirectories.

    Used by writer primitives (``write_cached_article`` /
    ``write_cached_issue`` / ``write_cached_query``). Accepts both the
    legacy flat shape ``<...>/.kd/cache`` (kept so writer-direct unit
    tests stay simple) and the per-connection scoped shape
    ``<...>/.kd/cache/connections/<slug>``.
    """
    if cache_root is None:
        return cache_dir()
    resolved = Path(cache_root).resolve()
    if not (_is_flat_cache_root(resolved) or _is_scoped_cache_root(resolved)):
        raise ConfigError(
            f"Cache root '{resolved}' is not a valid cache artifact directory. "
            "Expected '<...>/.kd/cache' or '<...>/.kd/cache/connections/<slug>'."
        )
    return resolved


def _validate_cache_scope_root(cache_root: Path | None) -> Path:
    """Validate a per-connection cache scope root.

    Used by refresh orchestrators and :func:`write_scope_manifest`.
    Accepts **only** the scoped shape
    ``<...>/.kd/cache/connections/<slug>``. Rejecting a flat root here
    is what prevents an orchestrator caller from silently writing
    identity-bearing flat data and undoing the S8a layout correction.
    """
    if cache_root is None:
        raise ConfigError(
            "Cache scope root is required (no implicit default). "
            "Pass connection_cache_dir(connection) explicitly."
        )
    resolved = Path(cache_root).resolve()
    if not _is_scoped_cache_root(resolved):
        raise ConfigError(
            f"Cache scope root '{resolved}' is not a valid per-connection scope. "
            "Expected '<...>/.kd/cache/connections/<slug>'."
        )
    return resolved


def _validate_connections_root(connections_root: Path | None) -> Path:
    """Validate the ``connections/`` parent directory under ``.kd/cache``."""
    if connections_root is None:
        return cache_dir() / CONNECTIONS_DIRNAME
    resolved = Path(connections_root).resolve()
    if not (
        resolved.name == CONNECTIONS_DIRNAME
        and resolved.parent.name == CACHE_DIRNAME
        and resolved.parent.parent.name == ".kd"
    ):
        raise ConfigError(
            f"Connections root '{resolved}' is not a valid '<...>/.kd/cache/connections' directory."
        )
    return resolved


def _validate_cache_root_for_clear_all(cache_root: Path | None) -> Path:
    """Validate the whole-tree clear root (``<...>/.kd/cache``)."""
    if cache_root is None:
        return cache_dir()
    resolved = Path(cache_root).resolve()
    if not _is_flat_cache_root(resolved):
        raise ConfigError(f"Cache root '{resolved}' is not a valid '<...>/.kd/cache' directory.")
    return resolved


# ---------------------------------------------------------------------------
# Timestamp + banner rendering
# ---------------------------------------------------------------------------


def _format_iso(fetched_at: datetime) -> str:
    """Format *fetched_at* as ISO 8601 second precision with ``Z`` suffix.

    Resolves the proposal-39 internal inconsistency (banner example used
    minute precision; sidecar example used second precision) in favor of
    second precision throughout.
    """
    if fetched_at.tzinfo is None:
        fetched_at = fetched_at.replace(tzinfo=timezone.utc)
    else:
        fetched_at = fetched_at.astimezone(timezone.utc)
    return fetched_at.strftime("%Y-%m-%dT%H:%M:%SZ")


def _parse_iso_z(value: str) -> datetime:
    """Parse a canonical Z-suffix ISO 8601 timestamp to an aware datetime.

    Inverse of :func:`_format_iso`. Accepts the second-precision Z form
    written by the cache writers. Falls back to ``datetime.fromisoformat``
    so values produced by older sidecars (or hand-edits) still parse.
    Raises :class:`ValueError` on malformed input.
    """
    raw = value
    if raw.endswith("Z"):
        raw = raw[:-1] + "+00:00"
    return datetime.fromisoformat(raw)


def _render_banner_md(article_id: str, fetched_at: datetime) -> str:
    """Render the markdown banner for a cached article body."""
    return BANNER_TEMPLATE_MD.format(id=article_id, iso=_format_iso(fetched_at))


def _render_banner_yaml(entity_id: str, fetched_at: datetime) -> str:
    """Render the YAML banner for a cached issue or query payload."""
    return BANNER_TEMPLATE_YAML.format(id=entity_id, iso=_format_iso(fetched_at))


# ---------------------------------------------------------------------------
# Writers
# ---------------------------------------------------------------------------


def _meta_to_dict(meta: ArticleCacheMeta) -> dict[str, Any]:
    """Serialize ``ArticleCacheMeta`` with ``kind`` first.

    The dataclass requires ``kind`` last (Python's no-default-after-default
    rule). The on-disk sidecar reads more naturally with ``kind`` first,
    matching proposal 39's example.
    """
    raw = dataclasses.asdict(meta)
    return {"kind": raw.pop("kind"), **raw}


def _dump_yaml(payload: Any) -> str:
    """Dump *payload* as YAML with stable, readable formatting."""
    return yaml.safe_dump(
        payload,
        sort_keys=False,
        default_flow_style=False,
        allow_unicode=True,
    )


def write_cached_article(
    article_id: str,
    body: str,
    meta: ArticleCacheMeta,
    *,
    cache_root: Path | None = None,
) -> None:
    """Write a cached article body + sidecar pair.

    Writes ``articles/{id}.md`` (banner + body) **first**, then
    ``articles/{id}.meta.yaml`` (sidecar). The sidecar is the commit
    signal: a body without sidecar is recoverable by refresh; a sidecar
    pointing at missing content is the more confusing failure mode.

    Strictly avoids ``kd-meta`` injection — cache files are not claimable
    or pushable per proposal 39.
    """
    root = _validate_cache_artifact_root(cache_root)
    articles_dir = root / ARTICLES_DIRNAME
    articles_dir.mkdir(parents=True, exist_ok=True)

    fetched_at = _parse_meta_fetched(meta)
    banner = _render_banner_md(article_id, fetched_at)
    body_path = articles_dir / f"{article_id}.md"
    sidecar_path = articles_dir / f"{article_id}.meta.yaml"

    atomic_write_text(body_path, f"{banner}\n{body}")
    atomic_write_text(sidecar_path, _dump_yaml(_meta_to_dict(meta)))


def write_cached_issue(
    issue_id: str,
    payload: dict[str, Any],
    *,
    fetched_at: datetime | None = None,
    cache_root: Path | None = None,
) -> None:
    """Write a cached issue payload as ``issues/{id}.yaml`` with banner."""
    root = _validate_cache_artifact_root(cache_root)
    issues_dir = root / ISSUES_DIRNAME
    issues_dir.mkdir(parents=True, exist_ok=True)

    when = fetched_at if fetched_at is not None else datetime.now(timezone.utc)
    banner = _render_banner_yaml(issue_id, when)
    target = issues_dir / f"{issue_id}.yaml"
    atomic_write_text(target, f"{banner}\n{_dump_yaml(payload)}")


def write_cached_query(
    slug: str,
    payload: dict[str, Any],
    *,
    fetched_at: datetime | None = None,
    cache_root: Path | None = None,
) -> None:
    """Write a cached query result as ``queries/{slug}.yaml`` with banner."""
    root = _validate_cache_artifact_root(cache_root)
    queries_dir = root / QUERIES_DIRNAME
    queries_dir.mkdir(parents=True, exist_ok=True)

    when = fetched_at if fetched_at is not None else datetime.now(timezone.utc)
    banner = _render_banner_yaml(slug, when)
    target = queries_dir / f"{slug}.yaml"
    atomic_write_text(target, f"{banner}\n{_dump_yaml(payload)}")


def _parse_meta_fetched(meta: ArticleCacheMeta) -> datetime:
    """Parse ``meta.fetched_at`` for banner stamping.

    Delegates to :func:`_parse_iso_z` so the canonical-Z form here stays
    the single source of truth shared with the status scanner.
    """
    return _parse_iso_z(meta.fetched_at)


def read_cached_article_upstream_updated(
    cache_root: Path,
    article_id: str,
) -> int | None:
    """Return the cached ``upstream_updated`` for *article_id* as epoch ms.

    Reads ``<cache_root>/articles/<article_id>.meta.yaml`` only — the body
    file (``<id>.md``) is not consulted. The sidecar is the contract for
    drift detection; cached body presence is irrelevant for the conflict
    baseline.

    Returns ``None`` when:

    - the sidecar file does not exist (no cache baseline yet); or
    - the sidecar parses cleanly and ``upstream_updated`` is ``null``.

    Raises :class:`ValidationError` on shapes that should never reach a
    push baseline read: malformed YAML, non-mapping document, ``kind``
    other than ``"article"``, ``id`` mismatching *article_id*, or
    ``upstream_updated`` not parseable as canonical Z-ISO. The S2/S12
    contract is fail-closed on the read side: malformed baseline-shaped
    data must not silently downgrade to trust-new.

    Returned epoch is integer **seconds** to match the legacy-marker
    branch of :func:`kd.client._resolve_conflict_baseline`. The push call
    site converts ``Article.updated`` (epoch ms) once before comparing.
    """
    sidecar_path = cache_root / ARTICLES_DIRNAME / f"{article_id}.meta.yaml"
    if not sidecar_path.exists():
        return None

    try:
        with sidecar_path.open("r", encoding="utf-8") as fp:
            loaded = yaml.safe_load(fp)
    except yaml.YAMLError as exc:
        raise ValidationError(
            f"Cache sidecar at '{sidecar_path}' is not valid YAML: {exc}. "
            f"Run `kd /cache refresh --article {article_id}` to rewrite it, "
            f"`kd /cache clear` to remove it, or push with `--force` after "
            "inspection."
        ) from exc

    if not isinstance(loaded, dict):
        raise ValidationError(
            f"Cache sidecar at '{sidecar_path}' is not a YAML mapping. "
            f"Run `kd /cache refresh --article {article_id}` to rewrite it, "
            f"`kd /cache clear` to remove it, or push with `--force` after "
            "inspection."
        )

    kind = loaded.get("kind")
    if kind != "article":
        raise ValidationError(
            f"Cache sidecar at '{sidecar_path}' has wrong kind {kind!r} "
            f"(expected 'article'). Run `kd /cache refresh --article "
            f"{article_id}` to rewrite it, `kd /cache clear` to remove it, "
            "or push with `--force` after inspection."
        )

    sidecar_id = loaded.get("id")
    if sidecar_id != article_id:
        raise ValidationError(
            f"Cache sidecar at '{sidecar_path}' identifies {sidecar_id!r} "
            f"but the article being pushed is {article_id!r}. "
            f"Run `kd /cache refresh --article {article_id}` to rewrite it, "
            f"`kd /cache clear` to remove it, or push with `--force` after "
            "inspection."
        )

    raw = loaded.get("upstream_updated")
    if raw is None:
        return None

    if not isinstance(raw, str):
        raise ValidationError(
            f"Cache sidecar at '{sidecar_path}' has malformed "
            f"`upstream_updated` (got {type(raw).__name__}, expected ISO string). "
            f"Run `kd /cache refresh --article {article_id}` to rewrite it, "
            f"`kd /cache clear` to remove it, or push with `--force` after "
            "inspection."
        )

    try:
        parsed = _parse_iso_z(raw)
    except ValueError as exc:
        raise ValidationError(
            f"Cache sidecar at '{sidecar_path}' has malformed "
            f"`upstream_updated` value {raw!r}: {exc}. "
            f"Run `kd /cache refresh --article {article_id}` to rewrite it, "
            f"`kd /cache clear` to remove it, or push with `--force` after "
            "inspection."
        ) from exc

    return int(parsed.timestamp())


# ---------------------------------------------------------------------------
# Scope manifest
# ---------------------------------------------------------------------------


def _normalize_base_url(url: str) -> str:
    """Trailing-slash-strip a YouTrack base URL for identity comparison."""
    return url.rstrip("/")


def _scope_manifest_to_dict(manifest: CacheScopeManifest) -> dict[str, Any]:
    """Serialize ``CacheScopeManifest`` with ``kind`` first."""
    raw = dataclasses.asdict(manifest)
    return {"kind": raw.pop("kind"), **raw}


def _load_scope_manifest(path: Path) -> dict[str, Any] | None:
    """Read an existing ``scope.yaml`` returning the parsed mapping or None."""
    if not path.exists():
        return None
    with path.open("r", encoding="utf-8") as fp:
        loaded = yaml.safe_load(fp)
    if not isinstance(loaded, dict):
        raise ConfigError(f"Cache scope manifest at '{path}' is not a YAML mapping.")
    return loaded


_SCOPE_MANIFEST_REQUIRED_FIELDS = (
    "kind",
    "connection",
    "provider",
    "base_url",
    "compat_tier",
    "created_at",
)


def _validate_scope_manifest_schema(data: dict[str, Any], path: Path) -> CacheScopeManifest:
    """Validate a parsed ``scope.yaml`` mapping and return a typed manifest.

    Schema-only check — does **not** compare the manifest against any
    active :class:`ConnectionContext`. Status walks every scope offline
    and has no writer identity to compare against; identity-mismatch is
    a write-time concern enforced by :func:`write_scope_manifest`.

    Raises :class:`ConfigError` naming the file and the offending field
    on missing/invalid required keys, wrong ``kind``, non-string
    identity fields, or an unparseable ``created_at`` timestamp.
    """
    for required in _SCOPE_MANIFEST_REQUIRED_FIELDS:
        if required not in data:
            raise ConfigError(
                f"Cache scope manifest at '{path}' is missing required field '{required}'."
            )

    kind = data["kind"]
    if kind != SCOPE_MANIFEST_KIND:
        raise ConfigError(
            f"Cache scope manifest at '{path}' has kind={kind!r}, expected {SCOPE_MANIFEST_KIND!r}."
        )

    for field_name in ("connection", "provider", "base_url", "compat_tier", "created_at"):
        value = data[field_name]
        if not isinstance(value, str) or not value:
            raise ConfigError(
                f"Cache scope manifest at '{path}' has invalid '{field_name}': "
                f"expected a non-empty string, got {value!r}."
            )

    try:
        _parse_iso_z(str(data["created_at"]))
    except ValueError as exc:
        raise ConfigError(
            f"Cache scope manifest at '{path}' has unparseable 'created_at': "
            f"{data['created_at']!r} ({exc})."
        ) from exc

    return CacheScopeManifest(
        connection=str(data["connection"]),
        provider=str(data["provider"]),
        base_url=str(data["base_url"]),
        compat_tier=str(data["compat_tier"]),
        created_at=str(data["created_at"]),
    )


def write_scope_manifest(
    connection: ConnectionContext,
    *,
    cache_root: Path,
    fetched_at: datetime | None = None,
) -> Path:
    """Write or verify the ``scope.yaml`` for *connection* under *cache_root*.

    Compares the full immutable identity tuple ``(kind, connection,
    provider, base_url, compat_tier)`` against any existing manifest.
    On full match, no-op and preserve the existing ``created_at``. On
    any mismatch, raise :class:`ConfigError` listing every divergent
    field so an operator sees both old and new values.

    *cache_root* must be a per-connection scope path (validated via
    :func:`_validate_cache_scope_root`); writing a flat ``cache_root``
    is rejected to prevent silently re-introducing flat scoped data.

    Returns the manifest file path.
    """
    root = _validate_cache_scope_root(cache_root)
    root.mkdir(parents=True, exist_ok=True)
    manifest_path = root / SCOPE_MANIFEST_FILENAME

    when = _format_iso(fetched_at or datetime.now(timezone.utc))
    new_identity = {
        "kind": SCOPE_MANIFEST_KIND,
        "connection": connection.name,
        "provider": connection.provider,
        "base_url": _normalize_base_url(connection.base_url),
        "compat_tier": connection.compat_tier,
    }

    existing = _load_scope_manifest(manifest_path)
    if existing is not None:
        existing_identity = {
            "kind": existing.get("kind"),
            "connection": existing.get("connection"),
            "provider": existing.get("provider"),
            "base_url": _normalize_base_url(str(existing.get("base_url", ""))),
            "compat_tier": existing.get("compat_tier"),
        }
        diffs = [
            (key, existing_identity[key], new_identity[key])
            for key in new_identity
            if existing_identity[key] != new_identity[key]
        ]
        if diffs:
            details = "; ".join(f"{key} {old!r} → {new!r}" for key, old, new in diffs)
            raise ConfigError(
                f"cache scope identity mismatch at '{manifest_path}': {details}. "
                "The scope dir is bound to a different upstream — refusing to "
                "overwrite. Use 'kd /cache clear' or 'kd /cache clear --all' "
                "if this divergence is intended."
            )
        created_at = str(existing.get("created_at", when))
    else:
        created_at = when

    manifest = CacheScopeManifest(
        connection=new_identity["connection"],
        provider=new_identity["provider"],
        base_url=new_identity["base_url"],
        compat_tier=new_identity["compat_tier"],
        created_at=created_at,
    )
    atomic_write_text(manifest_path, _dump_yaml(_scope_manifest_to_dict(manifest)))
    return manifest_path


# ---------------------------------------------------------------------------
# Clear
# ---------------------------------------------------------------------------


def _remove_file(path: Path) -> None:
    """Unlink one path. Indirected so tests can monkeypatch failures."""
    path.unlink()


def _classify(name: str) -> str:
    if name == ARTICLES_DIRNAME:
        return "articles"
    if name == ISSUES_DIRNAME:
        return "issues"
    if name == QUERIES_DIRNAME:
        return "queries"
    return "other"


def _clear_subtree(directory: Path, errors: list[ClearReportError]) -> int:
    """Remove every file/symlink under *directory* recursively.

    Symlinks are unlinked, never followed. Per-path failures are
    collected into *errors* and the walk continues.
    Returns the count of files (and symlinks) removed.
    """
    removed = 0
    for entry in sorted(directory.iterdir()):
        if entry.is_symlink():
            try:
                _remove_file(entry)
                removed += 1
            except OSError as e:
                errors.append(ClearReportError(path=str(entry), reason=str(e)))
        elif entry.is_dir():
            removed += _clear_subtree(entry, errors)
            try:
                entry.rmdir()
            except OSError as e:
                errors.append(ClearReportError(path=str(entry), reason=str(e)))
        else:
            try:
                _remove_file(entry)
                removed += 1
            except OSError as e:
                errors.append(ClearReportError(path=str(entry), reason=str(e)))
    return removed


def clear_cache(*, cache_root: Path | None = None) -> ClearReport:
    """Best-effort recursive removal of one cache artifact root.

    Accepts either a flat ``<...>/.kd/cache`` (legacy / SDK-direct) or a
    per-connection scope ``<...>/.kd/cache/connections/<slug>``. Default
    is the active workspace's flat root for backward compatibility with
    SDK callers; CLI always passes an explicit scope root.

    Idempotent: a missing directory returns ``existed=False`` with zero
    counts. Per-path failures collect into ``ClearReport.errors`` rather
    than raising, so a single permission error does not abort the sweep.
    Refuses to operate on paths the artifact-root validator rejects,
    raising :class:`ConfigError` before any deletion.
    """
    target = _validate_cache_artifact_root(cache_root)
    if not target.exists():
        return ClearReport(
            existed=False,
            articles_removed=0,
            issues_removed=0,
            queries_removed=0,
            other_removed=0,
            errors=[],
        )

    counts = {"articles": 0, "issues": 0, "queries": 0, "other": 0}
    errors: list[ClearReportError] = []

    for entry in sorted(target.iterdir()):
        if entry.is_symlink():
            try:
                _remove_file(entry)
                counts["other"] += 1
            except OSError as e:
                errors.append(ClearReportError(path=str(entry), reason=str(e)))
        elif entry.is_dir():
            kind = _classify(entry.name)
            counts[kind] += _clear_subtree(entry, errors)
            try:
                entry.rmdir()
            except OSError as e:
                errors.append(ClearReportError(path=str(entry), reason=str(e)))
        else:
            try:
                _remove_file(entry)
                counts["other"] += 1
            except OSError as e:
                errors.append(ClearReportError(path=str(entry), reason=str(e)))

    try:
        target.rmdir()
    except OSError as e:
        errors.append(ClearReportError(path=str(target), reason=str(e)))

    return ClearReport(
        existed=True,
        articles_removed=counts["articles"],
        issues_removed=counts["issues"],
        queries_removed=counts["queries"],
        other_removed=counts["other"],
        errors=errors,
    )


def clear_all_scopes(*, cache_root: Path | None = None) -> ClearReport:
    """Wipe the entire ``.kd/cache/`` tree.

    Sweeps every per-connection scope under ``connections/`` plus any
    pre-S8a flat ``articles``/``issues``/``queries`` directories under
    the cache root in one pass. All cache content is disposable by
    contract.

    Idempotent: a missing cache directory returns ``existed=False``.
    Per-path failures collect into ``ClearReport.errors``.
    """
    target = _validate_cache_root_for_clear_all(cache_root)
    if not target.exists():
        return ClearReport(
            existed=False,
            articles_removed=0,
            issues_removed=0,
            queries_removed=0,
            other_removed=0,
            errors=[],
        )

    counts = {"articles": 0, "issues": 0, "queries": 0, "other": 0}
    errors: list[ClearReportError] = []

    def _tally_kind_subdir(entry: Path) -> None:
        kind = _classify(entry.name)
        counts[kind] += _clear_subtree(entry, errors)
        try:
            entry.rmdir()
        except OSError as e:
            errors.append(ClearReportError(path=str(entry), reason=str(e)))

    for entry in sorted(target.iterdir()):
        if entry.is_symlink():
            try:
                _remove_file(entry)
                counts["other"] += 1
            except OSError as e:
                errors.append(ClearReportError(path=str(entry), reason=str(e)))
        elif entry.is_dir():
            if entry.name == CONNECTIONS_DIRNAME:
                for scope in sorted(entry.iterdir()):
                    if scope.is_symlink():
                        try:
                            _remove_file(scope)
                            counts["other"] += 1
                        except OSError as e:
                            errors.append(ClearReportError(path=str(scope), reason=str(e)))
                    elif scope.is_dir():
                        for inner in sorted(scope.iterdir()):
                            if inner.is_dir():
                                _tally_kind_subdir(inner)
                            elif inner.is_symlink() or inner.is_file():
                                try:
                                    _remove_file(inner)
                                    counts["other"] += 1
                                except OSError as e:
                                    errors.append(ClearReportError(path=str(inner), reason=str(e)))
                        try:
                            scope.rmdir()
                        except OSError as e:
                            errors.append(ClearReportError(path=str(scope), reason=str(e)))
                    else:
                        try:
                            _remove_file(scope)
                            counts["other"] += 1
                        except OSError as e:
                            errors.append(ClearReportError(path=str(scope), reason=str(e)))
                try:
                    entry.rmdir()
                except OSError as e:
                    errors.append(ClearReportError(path=str(entry), reason=str(e)))
            else:
                _tally_kind_subdir(entry)
        else:
            try:
                _remove_file(entry)
                counts["other"] += 1
            except OSError as e:
                errors.append(ClearReportError(path=str(entry), reason=str(e)))

    try:
        target.rmdir()
    except OSError as e:
        errors.append(ClearReportError(path=str(target), reason=str(e)))

    return ClearReport(
        existed=True,
        articles_removed=counts["articles"],
        issues_removed=counts["issues"],
        queries_removed=counts["queries"],
        other_removed=counts["other"],
        errors=errors,
    )


# ---------------------------------------------------------------------------
# Status — read-only cache health surface (M008 S8b)
# ---------------------------------------------------------------------------

DEFAULT_STALE_AFTER_DAYS = 7

_BANNER_FETCHED_RE = re.compile(r"\bfetched=([0-9T:\-]+Z)")


def _parse_yaml_banner_fetched(text: str) -> datetime:
    """Extract ``fetched_at`` from a YAML cache banner's first line.

    The banner is rendered by :func:`_render_banner_yaml` as
    ``# kd-cache: upstream={id} fetched={iso}.\\n# Disposable mirror...``.
    Reads the first line, locates ``fetched=<ISO>`` via a regex, and
    parses the captured value via :func:`_parse_iso_z`.

    Raises :class:`ValueError` when the banner is missing or the timestamp
    does not parse — callers (the status scanner) translate this into a
    structured warning rather than aborting the sweep.
    """
    head, _, _ = text.partition("\n")
    match = _BANNER_FETCHED_RE.search(head)
    if match is None:
        raise ValueError(f"banner missing 'fetched=' marker: {head!r}")
    return _parse_iso_z(match.group(1))


def _read_sidecar_fetched(path: Path) -> datetime:
    """Parse ``fetched_at`` from an article sidecar (``<id>.meta.yaml``)."""
    with path.open("r", encoding="utf-8") as fp:
        loaded = yaml.safe_load(fp)
    if not isinstance(loaded, dict):
        raise ValueError(f"sidecar at {path} is not a YAML mapping")
    raw = loaded.get("fetched_at")
    if not isinstance(raw, str) or not raw:
        raise ValueError(f"sidecar at {path} has no string 'fetched_at'")
    return _parse_iso_z(raw)


def _read_yaml_banner_fetched(path: Path) -> datetime:
    """Parse ``fetched_at`` from a YAML cache file's banner first line."""
    with path.open("r", encoding="utf-8") as fp:
        text = fp.read()
    return _parse_yaml_banner_fetched(text)


def enumerate_cache_scopes(cache_root: Path | None = None) -> CacheScopeEnumeration:
    """Walk ``.kd/cache/connections/*`` and return validated scope refs.

    Schema-validates every ``scope.yaml`` via
    :func:`_validate_scope_manifest_schema`. Directories without a
    ``scope.yaml`` are reported under :attr:`CacheScopeEnumeration.orphan_dirs`
    rather than raised — a hand-deleted manifest is recoverable, so
    surfacing it loudly without aborting status is the correct policy.

    Identity is reported as stored in each manifest. This function does
    **not** compare a manifest against the active connection: that is a
    write-time concern enforced by :func:`write_scope_manifest`. For
    non-active scopes there is no writer identity to compare against;
    cross-comparing every manifest to the active connection would be
    wrong.

    Raises :class:`ConfigError` only when ``cache_root`` is set and not a
    valid cache root, or when a present ``scope.yaml`` fails schema
    validation. A missing ``cache_root`` is **not** an error — returns
    an empty enumeration so status can render the not-initialized state.
    """
    if cache_root is None:
        target = cache_dir()
    else:
        target = Path(cache_root).resolve()
        if not _is_flat_cache_root(target):
            raise ConfigError(f"Cache root '{target}' is not a valid '<...>/.kd/cache' directory.")

    scopes: list[CacheScopeRef] = []
    orphans: list[str] = []

    connections_dir = target / CONNECTIONS_DIRNAME
    if not connections_dir.is_dir():
        return CacheScopeEnumeration(scopes=scopes, orphan_dirs=orphans)

    for entry in sorted(connections_dir.iterdir()):
        if not entry.is_dir():
            continue
        manifest_path = entry / SCOPE_MANIFEST_FILENAME
        if not manifest_path.exists():
            orphans.append(entry.name)
            continue
        data = _load_scope_manifest(manifest_path)
        # _load_scope_manifest returned None only when the file does not
        # exist; we just checked existence above, so a None here would be
        # a logic error, not user-recoverable state.
        assert data is not None
        manifest = _validate_scope_manifest_schema(data, manifest_path)
        scopes.append(CacheScopeRef(slug=entry.name, path=str(entry), manifest=manifest))

    return CacheScopeEnumeration(scopes=scopes, orphan_dirs=orphans)


def _stale_cutoff(now: datetime, stale_after_days: int) -> datetime:
    """Compute the inclusive staleness cutoff for the scanner.

    An entry is stale when ``fetched_at <= cutoff`` where
    ``cutoff = now - timedelta(days=stale_after_days)``. The inclusive
    boundary is what makes ``--stale-after-days 0`` mean "treat any
    cached entry as stale" — at zero, ``cutoff == now``, so any entry
    whose ``fetched_at`` is at or before ``now`` is stale.
    """
    return now - timedelta(days=stale_after_days)


def _scan_articles_dir(
    directory: Path,
    *,
    cutoff: datetime,
    warnings: list[CacheStatusWarning],
) -> tuple[int, list[datetime], int]:
    """Scan ``articles/`` returning (count, fetched_times, stale_count).

    Counts matched ``<id>.md`` + ``<id>.meta.yaml`` pairs only. Mismatched
    halves surface as ``article_pair_mismatch`` warnings and are excluded
    from the count and aggregates. Sidecar parse failures count the
    artifact (it exists) but exclude it from ``fetched_times`` and
    ``stale_count``.
    """
    if not directory.is_dir():
        return 0, [], 0

    bodies: dict[str, Path] = {}
    sidecars: dict[str, Path] = {}
    for entry in sorted(directory.iterdir()):
        if not entry.is_file():
            continue
        name = entry.name
        if name.endswith(".meta.yaml"):
            sidecars[name[: -len(".meta.yaml")]] = entry
        elif name.endswith(".md"):
            bodies[name[: -len(".md")]] = entry

    matched_ids = bodies.keys() & sidecars.keys()
    only_body = bodies.keys() - sidecars.keys()
    only_sidecar = sidecars.keys() - bodies.keys()

    for article_id in sorted(only_body):
        warnings.append(
            CacheStatusWarning(
                code="article_pair_mismatch",
                message=f"article body without sidecar: {article_id}.md",
                path=str(bodies[article_id]),
            )
        )
    for article_id in sorted(only_sidecar):
        warnings.append(
            CacheStatusWarning(
                code="article_pair_mismatch",
                message=f"article sidecar without body: {article_id}.meta.yaml",
                path=str(sidecars[article_id]),
            )
        )

    count = len(matched_ids)
    fetched_times: list[datetime] = []
    stale_count = 0
    for article_id in sorted(matched_ids):
        sidecar_path = sidecars[article_id]
        try:
            fetched = _read_sidecar_fetched(sidecar_path)
        except (OSError, ValueError, yaml.YAMLError) as exc:
            warnings.append(
                CacheStatusWarning(
                    code="sidecar_unparseable",
                    message=f"unable to parse fetched_at from {sidecar_path.name}: {exc}",
                    path=str(sidecar_path),
                )
            )
            continue
        fetched_times.append(fetched)
        if fetched <= cutoff:
            stale_count += 1

    return count, fetched_times, stale_count


def _scan_yaml_kind_dir(
    directory: Path,
    *,
    cutoff: datetime,
    code: str,
    warnings: list[CacheStatusWarning],
) -> tuple[int, list[datetime], int]:
    """Scan ``issues/`` or ``queries/`` returning (count, fetched_times, stale_count).

    Files with unparseable banners surface as ``code`` warnings (caller
    sets ``code="banner_unparseable"``); the kind count includes the
    file (artifact exists) but the entry is excluded from
    ``fetched_times`` and ``stale_count``.
    """
    if not directory.is_dir():
        return 0, [], 0

    yaml_files = sorted(p for p in directory.iterdir() if p.is_file() and p.name.endswith(".yaml"))
    fetched_times: list[datetime] = []
    stale_count = 0
    for path in yaml_files:
        try:
            fetched = _read_yaml_banner_fetched(path)
        except (OSError, ValueError) as exc:
            warnings.append(
                CacheStatusWarning(
                    code=code,
                    message=f"unable to parse banner from {path.name}: {exc}",
                    path=str(path),
                )
            )
            continue
        fetched_times.append(fetched)
        if fetched <= cutoff:
            stale_count += 1

    return len(yaml_files), fetched_times, stale_count


def scan_scope_health(
    scope_root: Path,
    *,
    now: datetime,
    stale_after_days: int,
) -> tuple[CacheCounts, str | None, str | None, int, list[CacheStatusWarning]]:
    """Walk one scope directory and return its aggregated health tuple.

    Returns ``(counts, latest_fetch, oldest_fetch, stale_count, warnings)``
    where the timestamps are canonical Z-ISO strings (or ``None`` when
    no parseable entries exist). Per-file failures collect into
    ``warnings`` rather than aborting the sweep — the scanner is
    deliberately tolerant of one broken file in a scope so the operator
    sees the rest of the cache.
    """
    cutoff = _stale_cutoff(now, stale_after_days)
    warnings: list[CacheStatusWarning] = []

    article_count, article_times, article_stale = _scan_articles_dir(
        scope_root / ARTICLES_DIRNAME, cutoff=cutoff, warnings=warnings
    )
    issue_count, issue_times, issue_stale = _scan_yaml_kind_dir(
        scope_root / ISSUES_DIRNAME,
        cutoff=cutoff,
        code="banner_unparseable",
        warnings=warnings,
    )
    query_count, query_times, query_stale = _scan_yaml_kind_dir(
        scope_root / QUERIES_DIRNAME,
        cutoff=cutoff,
        code="banner_unparseable",
        warnings=warnings,
    )

    counts = CacheCounts(articles=article_count, issues=issue_count, queries=query_count)
    all_times = article_times + issue_times + query_times
    latest = _format_iso(max(all_times)) if all_times else None
    oldest = _format_iso(min(all_times)) if all_times else None
    stale_count = article_stale + issue_stale + query_stale

    if stale_count > 0 and oldest is not None:
        warnings.append(
            CacheStatusWarning(
                code="cache_stale",
                message=(
                    f"{stale_count} entries older than {stale_after_days} days (oldest {oldest})."
                ),
            )
        )

    return counts, latest, oldest, stale_count, warnings


def _scan_unscoped(
    cache_root: Path,
    *,
    now: datetime,
    stale_after_days: int,
) -> UnscopedCacheReport | None:
    """Scan pre-S8a flat content directly under ``.kd/cache/`` (no
    ``connections/`` parent). Returns ``None`` when no flat content
    exists. Counts are reported but staleness aggregates are folded in
    with the legacy data — only ``latest_fetch`` surfaces here.
    """
    cutoff = _stale_cutoff(now, stale_after_days)
    discard: list[CacheStatusWarning] = []

    article_count, article_times, _ = _scan_articles_dir(
        cache_root / ARTICLES_DIRNAME, cutoff=cutoff, warnings=discard
    )
    issue_count, issue_times, _ = _scan_yaml_kind_dir(
        cache_root / ISSUES_DIRNAME,
        cutoff=cutoff,
        code="banner_unparseable",
        warnings=discard,
    )
    query_count, query_times, _ = _scan_yaml_kind_dir(
        cache_root / QUERIES_DIRNAME,
        cutoff=cutoff,
        code="banner_unparseable",
        warnings=discard,
    )

    if article_count == 0 and issue_count == 0 and query_count == 0:
        return None

    all_times = article_times + issue_times + query_times
    latest = _format_iso(max(all_times)) if all_times else None
    return UnscopedCacheReport(
        counts=CacheCounts(articles=article_count, issues=issue_count, queries=query_count),
        latest_fetch=latest,
    )


def _resolve_scope_filter(name: str, enumeration: CacheScopeEnumeration) -> CacheScopeRef:
    """Match ``--scope NAME`` against a manifest connection name.

    Connection-name match is the primary contract (manifest identity).
    Slug fallback only fires when no connection matches and exactly one
    directory slug equals NAME. Ambiguous slug → :class:`ValidationError`;
    unknown name → :class:`ValidationError` listing every known
    connection name.
    """
    by_connection = [s for s in enumeration.scopes if s.manifest.connection == name]
    if len(by_connection) == 1:
        return by_connection[0]
    if len(by_connection) > 1:
        slugs = ", ".join(s.slug for s in by_connection)
        raise ValidationError(
            f"--scope {name!r} matches multiple manifests by connection name (slugs: {slugs}). "
            "This indicates a duplicate-connection state in .kd/cache/connections/."
        )

    by_slug = [s for s in enumeration.scopes if s.slug == name]
    if len(by_slug) == 1:
        return by_slug[0]

    if not enumeration.scopes:
        raise ValidationError(
            f"--scope {name!r} cannot match: no cache scopes exist. "
            "Run 'kd /cache refresh' against an active connection first."
        )
    known = ", ".join(sorted(s.manifest.connection for s in enumeration.scopes))
    raise ValidationError(
        f"--scope {name!r} does not match any cached scope. Known connections: {known}."
    )


def _select_scopes(
    enumeration: CacheScopeEnumeration,
    *,
    focus_scope: str | None,
) -> list[CacheScopeRef]:
    """Apply ``--scope NAME`` to an enumeration, or pass the full list through.

    Shared by :func:`compute_cache_status` and :func:`search_cache` so the
    two ``/cache`` walkers select scopes the same way (same matcher, same
    error message on miss, same ordering when no focus is set).
    """
    if focus_scope is None:
        return enumeration.scopes
    return [_resolve_scope_filter(focus_scope, enumeration)]


def compute_cache_status(
    *,
    cache_root: Path | None = None,
    now: datetime | None = None,
    stale_after_days: int = DEFAULT_STALE_AFTER_DAYS,
    active_connection_name: str | None = None,
    focus_scope: str | None = None,
) -> CacheStatusReport:
    """Build a :class:`CacheStatusReport` for the workspace cache.

    Walks every connection-scoped directory (or just *focus_scope* when
    set), aggregates counts / latest-and-oldest fetch / staleness per
    scope, and folds in any pre-S8a flat content under ``unscoped``.

    *active_connection_name* drives the per-scope ``active`` flag and
    the top-level ``cache.active_scope`` field; ``None`` when the
    workspace has no resolvable active connection (the scan still runs).

    Raises :class:`ConfigError` for schema-invalid ``scope.yaml`` files
    and :class:`ValidationError` for unknown / ambiguous *focus_scope*.
    """
    when = now if now is not None else datetime.now(timezone.utc)
    target = cache_dir() if cache_root is None else Path(cache_root).resolve()

    info_path = str(target)
    if not target.exists():
        return CacheStatusReport(
            cache=CacheStatusInfo(
                path=info_path,
                active_scope=active_connection_name,
                stale_after_days=stale_after_days,
                totals=CacheCounts(articles=0, issues=0, queries=0),
                not_initialized=True,
            ),
            scopes=[],
            unscoped=None,
            orphan_scopes=[],
        )

    enumeration = enumerate_cache_scopes(target)

    selected = _select_scopes(enumeration, focus_scope=focus_scope)

    scope_reports: list[ScopeHealthReport] = []
    for ref in selected:
        counts, latest, oldest, stale_count, warnings = scan_scope_health(
            Path(ref.path), now=when, stale_after_days=stale_after_days
        )
        scope_reports.append(
            ScopeHealthReport(
                slug=ref.slug,
                active=(
                    active_connection_name is not None
                    and ref.manifest.connection == active_connection_name
                ),
                connection=ref.manifest.connection,
                provider=ref.manifest.provider,
                base_url=ref.manifest.base_url,
                compat_tier=ref.manifest.compat_tier,
                counts=counts,
                latest_fetch=latest,
                oldest_fetch=oldest,
                stale_count=stale_count,
                has_warnings=bool(warnings),
                warnings=warnings,
            )
        )

    unscoped = (
        _scan_unscoped(target, now=when, stale_after_days=stale_after_days)
        if focus_scope is None
        else None
    )

    totals = CacheCounts(
        articles=sum(s.counts.articles for s in scope_reports)
        + (unscoped.counts.articles if unscoped else 0),
        issues=sum(s.counts.issues for s in scope_reports)
        + (unscoped.counts.issues if unscoped else 0),
        queries=sum(s.counts.queries for s in scope_reports)
        + (unscoped.counts.queries if unscoped else 0),
    )

    orphan_scopes = enumeration.orphan_dirs if focus_scope is None else []

    return CacheStatusReport(
        cache=CacheStatusInfo(
            path=info_path,
            active_scope=active_connection_name,
            stale_after_days=stale_after_days,
            totals=totals,
            not_initialized=False,
        ),
        scopes=scope_reports,
        unscoped=unscoped,
        orphan_scopes=orphan_scopes,
    )


# ---------------------------------------------------------------------------
# Refresh — primer-scope hydration (M008 S5)
# ---------------------------------------------------------------------------

PRIMER_SCOPE_QUERY_SLUG = "primer-scope"
PRIMER_SCOPE_REFRESH_COMMAND = "kd /cache refresh --primer-scope"


def _ms_to_iso(updated_ms: int | None) -> str | None:
    """Convert ``Article.updated`` (epoch ms) to canonical Z-ISO seconds.

    Single source of truth for ``upstream_updated`` formatting on cached
    articles. Returns ``None`` when the upstream value is missing.
    """
    if updated_ms is None:
        return None
    return _format_iso(datetime.fromtimestamp(updated_ms / 1000, tz=timezone.utc))


def article_to_cache_meta(
    article: Any,
    fetched_at: datetime,
    *,
    command: str,
    reason: str,
) -> ArticleCacheMeta:
    """Build :class:`ArticleCacheMeta` from an SDK ``Article`` model.

    Public shape used by both the refresh paths in this module and the
    post-push cache refresh in :mod:`kd.client`.
    """
    return ArticleCacheMeta(
        id=article.id_readable,
        project=article.project.name if article.project else None,
        summary=article.summary,
        tags=[t.name for t in article.tags],
        upstream_updated=_ms_to_iso(article.updated),
        fetched_at=_format_iso(fetched_at),
        source=CacheSource(command=command, reason=reason),
    )


def _refresh_primer_articles(
    client: Any,
    pinned: list[PrimerArticle],
    fetched_at: datetime,
    cache_root: Path,
) -> ArticleRefreshReport:
    """Hydrate each pinned article into ``cache_root/articles/``.

    Per-id ``APIError`` (and subclasses) are isolated into ``failed``;
    ``AuthError`` and ``ConfigError`` propagate as command-level
    failures and abort the run.
    """
    if not pinned:
        return ArticleRefreshReport(skipped_no_pinned=True, hydrated=[], failed=[])

    hydrated: list[HydratedArticle] = []
    failed: list[FailedArticle] = []
    for entry in pinned:
        try:
            article = client.articles.get(entry.id)
            meta = article_to_cache_meta(
                article,
                fetched_at,
                command=PRIMER_SCOPE_REFRESH_COMMAND,
                reason="primer pinned article",
            )
            write_cached_article(
                article.id_readable,
                article.content or "",
                meta,
                cache_root=cache_root,
            )
            hydrated.append(
                HydratedArticle(
                    id=article.id_readable,
                    summary=article.summary,
                    upstream_updated=meta.upstream_updated,
                    path=str(cache_root / ARTICLES_DIRNAME / f"{article.id_readable}.md"),
                )
            )
        except APIError as e:
            failed.append(FailedArticle(id=entry.id, reason=f"{type(e).__name__}: {e}"))
    return ArticleRefreshReport(skipped_no_pinned=False, hydrated=hydrated, failed=failed)


def _refresh_primer_query(
    client: Any,
    pinned_tags: list[PrimerTag],
    fetched_at: datetime,
    cache_root: Path,
) -> QueryRefreshReport:
    """Hydrate the primer-scope tag-entities query into ``cache_root/queries/``.

    A whole-call ``APIError`` lands in ``failed`` so the article half can
    still complete. ``AuthError`` and ``ConfigError`` propagate.
    """
    if not pinned_tags:
        return QueryRefreshReport(skipped_no_pinned_tags=True, hydrated=[], failed=[])

    tag_names = [t.name for t in pinned_tags]
    try:
        result: TagEntitiesResult = client.tags.entities(
            tag_names,
            kinds=("issue", "article"),
            limit_per_kind={"issue": 50, "article": 50},
            match="any",
        )
    except APIError as e:
        return QueryRefreshReport(
            skipped_no_pinned_tags=False,
            hydrated=[],
            failed=[FailedQuery(slug=PRIMER_SCOPE_QUERY_SLUG, reason=f"{type(e).__name__}: {e}")],
        )

    payload = tag_entities_result_to_dict(result)
    write_cached_query(
        PRIMER_SCOPE_QUERY_SLUG,
        payload,
        fetched_at=fetched_at,
        cache_root=cache_root,
    )
    issue_count = sum(1 for r in result.results if r.kind == "issue")
    article_count = sum(1 for r in result.results if r.kind == "article")
    return QueryRefreshReport(
        skipped_no_pinned_tags=False,
        hydrated=[
            HydratedQuery(
                slug=PRIMER_SCOPE_QUERY_SLUG,
                path=str(cache_root / QUERIES_DIRNAME / f"{PRIMER_SCOPE_QUERY_SLUG}.yaml"),
                issue_count=issue_count,
                article_count=article_count,
            )
        ],
        failed=[],
    )


def refresh_primer_scope(
    client: Any,
    *,
    connection: ConnectionContext,
    fetched_at: datetime | None = None,
    cache_root: Path | None = None,
) -> RefreshReport:
    """Hydrate primer-pinned articles and the primer-scope tag query.

    Workspace + primer are resolved up-front so the orchestration owns
    the precondition: outside a workspace, :func:`require_workspace_dir`
    raises :class:`ConfigError` *before* :func:`load_primer` (which
    otherwise returns an empty :class:`PrimerData` and would yield the
    wrong diagnostic). The derived cache root is threaded through every
    writer so workspace lookup happens once per command.

    Read-only by contract: writes only under ``cache_root``; the primer
    is read but never mutated; no upstream mutation.

    See KDCLI-A-18 §Cache contract; M008 proposal 39.
    """
    workspace_dir = require_workspace_dir()
    primer = load_primer(workspace_dir / PRIMER_FILENAME)
    if cache_root is not None:
        root = _validate_cache_scope_root(cache_root)
    else:
        root = connection_cache_dir(connection, workspace_dir.parent)
    when = fetched_at or datetime.now(timezone.utc)

    if not primer.articles and not primer.tags:
        raise ValidationError(
            "--primer-scope set but .kd/primer.yaml has no pinned articles or tags. "
            "Pin a tag with: kd /primer/tag add TAG_NAME, or pin an article with: "
            "kd /primer/article add ARTICLE-ID"
        )

    write_scope_manifest(connection, cache_root=root, fetched_at=when)
    article_report = _refresh_primer_articles(client, primer.articles, when, root)
    query_report = _refresh_primer_query(client, primer.tags, when, root)
    return RefreshReport(articles=article_report, queries=query_report)


# ---------------------------------------------------------------------------
# Refresh — single-entity hydration (M008 S6)
# ---------------------------------------------------------------------------

SINGLE_ISSUE_REFRESH_COMMAND = "kd /cache refresh --issue"
SINGLE_ARTICLE_REFRESH_COMMAND = "kd /cache refresh --article"
ARTICLE_PUSH_REFRESH_COMMAND = "kd /article push"


def _project_key_from_id(id_readable: str) -> str | None:
    """Derive the YouTrack project key from a readable id.

    YouTrack ids are ``<projectShortName>-<seq>`` by construction. The
    rich-fetch field set requests ``project(...,shortName)`` but
    :class:`NamedEntity` only persists ``id`` and ``name`` (display
    name), so pydantic discards the shortName. Same convention as
    ``kd/cli/namespaces/issue/__init__.py:_field_resolution``.
    """
    if "-" not in id_readable:
        return None
    return id_readable.rsplit("-", 1)[0]


def _normalize_custom_field_value(value: Any) -> Any:
    """Normalize a single ``CustomField.value`` for projection.

    Mirrors the rendering in ``_issue_to_detail``: dicts flatten to
    ``value.get("name", "")``; ``None`` becomes ``""``; lists are
    passed through (keeping list-valued multi-enum / multi-user
    fields legible). Primitives are passed through.
    """
    if value is None:
        return ""
    if isinstance(value, dict):
        return value.get("name", "")
    if isinstance(value, list):
        normalized: list[Any] = []
        for item in value:
            if isinstance(item, dict):
                normalized.append(item.get("name", ""))
            else:
                normalized.append(item)
        return normalized
    return value


def _issue_to_cache_payload(
    issue: Any,
    *,
    fetched_at: datetime,
    include_comments: bool,
    command: str,
) -> dict[str, Any]:
    """Build the proposal-39 §Issue Cache Shape dict from an SDK ``Issue``.

    Custom fields project flat at the top level (no ``custom_fields``
    map) — matches the proposal-39 example and the existing
    ``_issue_to_detail`` rendering. Project key derives from
    ``issue.id_readable`` (NOT ``issue.project.name``); see
    :func:`_project_key_from_id`. ``links`` and ``attachments`` are
    deliberately not projected (deferred to S7+).

    Not shared with ``kd/cli/namespaces/issue/__init__.py:_issue_to_detail``
    — that helper truncates comments to the last 5 (display logic),
    while cache projection must include all comments when
    ``include_comments`` is set.
    """
    payload: dict[str, Any] = {
        "kind": "issue",
        "id": issue.id_readable,
        "project": _project_key_from_id(issue.id_readable),
        "summary": issue.summary,
        "description": issue.description or "",
        "tags": [t.name for t in issue.tags],
        "upstream_updated": _ms_to_iso(issue.updated),
        "fetched_at": _format_iso(fetched_at),
        "source": {
            "command": command,
            "reason": "single-entity refresh",
        },
    }
    for cf in issue.custom_fields:
        key = cf.name.lower().replace(" ", "_")
        payload[key] = _normalize_custom_field_value(cf.value)
    if include_comments:
        payload["comments"] = [
            {
                "author": c.author.name if c.author else "",
                "created": c.created,
                "text": c.text,
            }
            for c in (issue.comments or [])
        ]
    return payload


def refresh_issue(
    client: Any,
    issue_id: str,
    *,
    connection: ConnectionContext,
    include_comments: bool = False,
    fetched_at: datetime | None = None,
    cache_root: Path | None = None,
) -> IssueRefreshReport:
    """Hydrate one issue into ``cache_root/issues/<id>.yaml``.

    Always fetches with ``detail="rich"``: the rich field set already
    returns comments, so ``include_comments`` only toggles the cache
    projection, not upstream traffic. ``APIError`` and subclasses are
    isolated into ``failed[]``; ``AuthError`` and ``ConfigError``
    propagate as command-level failures.

    Read-only by contract: writes only under ``cache_root``; no upstream
    mutation.
    """
    workspace_dir = require_workspace_dir()
    if cache_root is not None:
        root = _validate_cache_scope_root(cache_root)
    else:
        root = connection_cache_dir(connection, workspace_dir.parent)
    when = fetched_at or datetime.now(timezone.utc)
    write_scope_manifest(connection, cache_root=root, fetched_at=when)

    try:
        issue = client.issues.get(issue_id, detail="rich")
        payload = _issue_to_cache_payload(
            issue,
            fetched_at=when,
            include_comments=include_comments,
            command=SINGLE_ISSUE_REFRESH_COMMAND,
        )
        write_cached_issue(
            issue.id_readable,
            payload,
            fetched_at=when,
            cache_root=root,
        )
        comments_count = len(issue.comments or []) if include_comments else None
        return IssueRefreshReport(
            hydrated=[
                HydratedIssue(
                    id=issue.id_readable,
                    summary=issue.summary,
                    upstream_updated=_ms_to_iso(issue.updated),
                    path=str(root / ISSUES_DIRNAME / f"{issue.id_readable}.yaml"),
                    comments_count=comments_count,
                )
            ],
            failed=[],
        )
    except APIError as e:
        return IssueRefreshReport(
            hydrated=[],
            failed=[FailedIssue(id=issue_id, reason=f"{type(e).__name__}: {e}")],
        )


# ---------------------------------------------------------------------------
# Refresh — saved-query hydration (M008 S7a)
# ---------------------------------------------------------------------------

QUERY_NAME_REFRESH_COMMAND = "kd /cache refresh --query"
MILESTONE_REFRESH_COMMAND = "kd /cache refresh --milestone"
EPIC_REFRESH_COMMAND = "kd /cache refresh --epic --include-children"
MILESTONE_SLUG_PREFIX = "milestone-"
EPIC_CHILDREN_SLUG_RE = re.compile(r"^epic-.+-children$")

_SLUG_INVALID_RE = re.compile(r"[^a-z0-9_-]")
_SLUG_DASH_RUN_RE = re.compile(r"-+")
_SLUG_WHITESPACE_RE = re.compile(r"\s+")


def _sluggify(value: str) -> str:
    """Lowercase + collapse whitespace + drop non-slug chars + trim ``-``."""
    raw = value.strip().lower()
    raw = _SLUG_WHITESPACE_RE.sub("-", raw)
    raw = _SLUG_INVALID_RE.sub("", raw)
    raw = _SLUG_DASH_RUN_RE.sub("-", raw)
    return raw.strip("-")


def slug_for_query_name(name: str) -> str:
    """Sluggify a saved-query name into a cache filename stem.

    Lowercase, collapse whitespace runs to ``-``, drop characters
    outside ``[a-z0-9_-]``, collapse consecutive ``-`` runs, strip
    bordering ``-``. Rejects empty results, the reserved
    ``primer-scope`` slug (S5's tag-entities payload lives there), and
    any slug starting with ``milestone-`` (S7b's reserved prefix) with
    :class:`ValidationError`. Without the milestone-prefix guard a saved
    query named "Milestone M008" would overwrite a milestone refresh's
    cache file (and vice versa).
    """
    raw = _sluggify(name)
    if not raw:
        raise ValidationError(
            f"Saved-query name {name!r} sluggifies to an empty string; cannot "
            "derive a cache filename. Pick a name with at least one ASCII "
            "letter, digit, or underscore."
        )
    if raw == PRIMER_SCOPE_QUERY_SLUG:
        raise ValidationError(
            f"Saved-query name {name!r} sluggifies to "
            f"{PRIMER_SCOPE_QUERY_SLUG!r}, which is reserved for "
            "kd /cache refresh --primer-scope. Rename the saved query or "
            "refresh via --primer-scope instead."
        )
    if raw.startswith(MILESTONE_SLUG_PREFIX):
        raise ValidationError(
            f"Saved-query name {name!r} sluggifies to {raw!r}, which starts "
            f"with the reserved {MILESTONE_SLUG_PREFIX!r} prefix used by "
            "kd /cache refresh --milestone. Rename the saved query or "
            "refresh via --milestone instead."
        )
    if EPIC_CHILDREN_SLUG_RE.match(raw):
        raise ValidationError(
            f"Saved-query name {name!r} sluggifies to {raw!r}, which matches "
            "the reserved 'epic-<id>-children' pattern used by "
            "kd /cache refresh --epic --include-children. Rename the saved "
            "query or refresh via --epic --include-children instead."
        )
    return raw


def slug_for_milestone_value(value: str) -> str:
    """Sluggify a milestone value into the suffix of ``milestone-<slug>``.

    Same character pipeline as :func:`slug_for_query_name`; rejects
    empty results before any upstream call. Caller composes the final
    filename stem ``f"{MILESTONE_SLUG_PREFIX}{slug}"``.
    """
    raw = _sluggify(value)
    if not raw:
        raise ValidationError(
            f"Milestone value {value!r} sluggifies to an empty string; cannot "
            "derive a cache filename. Pick a value with at least one ASCII "
            "letter, digit, or underscore."
        )
    return raw


def slug_for_connection_name(name: str) -> str:
    """Sluggify a connection name into a cache scope directory segment.

    Same character pipeline as :func:`slug_for_query_name`. Rejects an
    empty result with :class:`ValidationError`. The unsanitized
    connection name is the authoritative identity inside ``scope.yaml``;
    the path segment is the sanitized projection. Two connection names
    that collapse to the same slug (e.g., ``Support`` and ``support``)
    are detected loudly by the manifest's identity-mismatch guard the
    second time the second connection's first refresh runs.
    """
    raw = _sluggify(name)
    if not raw:
        raise ValidationError(
            f"Connection name {name!r} sluggifies to an empty string; cannot "
            "derive a cache scope directory. Pick a name with at least one "
            "ASCII letter, digit, or underscore."
        )
    return raw


def _query_issue_to_cache_payload(issue: Any) -> dict[str, Any]:
    """Project a flat ``list_issues`` row into a query-cache issue entry.

    Distinct from :func:`_issue_to_cache_payload`: ``description``,
    ``comments``, ``links``, and ``attachments`` are absent because
    ``list_issues`` does not fetch them, and S7a explicitly does not
    pay for an N×rich-fetch pass per row. Operators wanting
    description-grade access for any one row run
    ``kd /cache refresh --issue ID`` afterwards.

    Custom fields project flat at the top level via the same
    convention as :func:`_issue_to_cache_payload`. No per-row ``kind``
    or ``source``: the wrapper carries those.
    """
    payload: dict[str, Any] = {
        "id": issue.id_readable,
        "project": _project_key_from_id(issue.id_readable),
        "summary": issue.summary,
        "tags": [t.name for t in issue.tags],
        "upstream_updated": _ms_to_iso(issue.updated),
    }
    for cf in issue.custom_fields:
        key = cf.name.lower().replace(" ", "_")
        payload[key] = _normalize_custom_field_value(cf.value)
    return payload


def refresh_query(
    client: Any,
    query_name: str,
    *,
    connection: ConnectionContext,
    limit: int = 50,
    fetched_at: datetime | None = None,
    cache_root: Path | None = None,
) -> QueryNameRefreshReport:
    """Hydrate a saved-query run into ``cache_root/queries/<slug>.yaml``.

    Calls :meth:`QueryOperations.resolve_and_run_issues` so the saved-
    query metadata (``id``, ``name``, ``query`` text) lands in the
    ``source`` block without a redundant fetch. Wrapped cache schema
    ``{kind: "query", source: {...}, issues: [...]}`` — deliberately
    different from ``/query issues -o yaml`` (which is a flat list of
    display rows). Truncation is observable via ``source.truncated``
    when the upstream returns exactly ``limit`` rows.

    ``APIError`` and subclasses isolate into ``failed[]``; ``AuthError``
    and ``ConfigError`` propagate. Slug collisions and empty slugs raise
    :class:`ValidationError` before any upstream call.

    Read-only by contract: writes only under ``cache_root``; no upstream
    mutation.
    """
    workspace_dir = require_workspace_dir()
    if cache_root is not None:
        root = _validate_cache_scope_root(cache_root)
    else:
        root = connection_cache_dir(connection, workspace_dir.parent)
    when = fetched_at or datetime.now(timezone.utc)
    write_scope_manifest(connection, cache_root=root, fetched_at=when)

    slug = slug_for_query_name(query_name)

    try:
        sq, issues = client.queries.resolve_and_run_issues(query_name, top=limit)
    except APIError as e:
        return QueryNameRefreshReport(
            hydrated=[],
            failed=[FailedQuery(slug=slug, reason=f"{type(e).__name__}: {e}")],
        )

    truncated = len(issues) == limit
    issue_payloads = [_query_issue_to_cache_payload(issue) for issue in issues]
    payload: dict[str, Any] = {
        "kind": "query",
        "source": {
            "command": QUERY_NAME_REFRESH_COMMAND,
            "query_name": sq.name,
            "query_id": sq.id,
            "query_text": sq.query,
            "limit": limit,
            "truncated": truncated,
            "count": len(issues),
            "fetched_at": _format_iso(when),
        },
        "issues": issue_payloads,
    }
    write_cached_query(slug, payload, fetched_at=when, cache_root=root)
    return QueryNameRefreshReport(
        hydrated=[
            HydratedQueryRun(
                query_name=sq.name,
                query_id=sq.id,
                slug=slug,
                path=str(root / QUERIES_DIRNAME / f"{slug}.yaml"),
                count=len(issues),
                truncated=truncated,
            )
        ],
        failed=[],
    )


def refresh_milestone(
    client: Any,
    milestone_value: str,
    *,
    connection: ConnectionContext,
    project_key: str,
    limit: int = 50,
    fetched_at: datetime | None = None,
    cache_root: Path | None = None,
) -> MilestoneRefreshReport:
    """Hydrate a milestone-scoped query into ``cache_root/queries/milestone-<slug>.yaml``.

    Resolves the project's milestone field through the per-project
    ``field_aliases`` map (KDCLI-A-18 §Project tier) — if the project
    aliased ``milestone`` → ``Stage``, the discovered field is ``Stage``
    and the cache file's ``source.field_name`` records that. Without an
    alias, falls back to the literal ``Milestone`` name. The discovery
    happens via the public :meth:`ProjectOperations.list_fields` SDK
    path; matched field is recorded byte-for-byte.

    Bundle validation: when the matched field has bounded values,
    case-corrects the operator's input to the canonical bundle name and
    rejects unknown values with a :class:`ValidationError` listing the
    bundle. Freeform fields pass the input through verbatim. Both the
    project key and the canonical milestone value are routed through
    :func:`youtrack_query_literal` before composition; a
    :class:`QueryLiteralError` propagates as a command-level validation
    failure before any upstream issue-list call.

    The composed query is ``project: {KEY} {field_name}: {value}``.
    Rows project through :func:`_query_issue_to_cache_payload` (the
    flat S7a projector — no rich-fetch pass).

    ``APIError`` and subclasses isolate into ``failed[]``; ``AuthError``
    and ``ConfigError`` propagate. ``ValidationError`` (missing field,
    bundle reject) raises before any cache write.

    Read-only by contract: writes only under ``cache_root``; no upstream
    mutation.
    """
    workspace_dir = require_workspace_dir()
    if cache_root is not None:
        root = _validate_cache_scope_root(cache_root)
    else:
        root = connection_cache_dir(connection, workspace_dir.parent)
    when = fetched_at or datetime.now(timezone.utc)
    write_scope_manifest(connection, cache_root=root, fetched_at=when)

    slug = f"{MILESTONE_SLUG_PREFIX}{slug_for_milestone_value(milestone_value)}"

    aliases = client.config.field_aliases_for(project_key) if client.config else {}
    target_field_name = aliases.get("milestone", "Milestone")

    try:
        project_obj = client.projects.get(project_key)
        roster = client.projects.list_fields(project_obj.id)
    except APIError as e:
        return MilestoneRefreshReport(
            hydrated=[],
            failed=[FailedQuery(slug=slug, reason=f"{type(e).__name__}: {e}")],
        )

    target_lower = target_field_name.lower()
    matched = next((f for f in roster if f.name.lower() == target_lower), None)
    if matched is None:
        roster_names = ", ".join(f.name for f in roster) or "<none>"
        alias_note = (
            f" (alias for 'milestone' from config: {target_field_name!r})"
            if "milestone" in aliases
            else ""
        )
        raise ValidationError(
            f"Project {project_key!r} has no field named "
            f"{target_field_name!r}{alias_note}. Available fields: "
            f"{roster_names}. Configure "
            f"projects.{project_key}.field_aliases.milestone to point at "
            "the actual upstream field name."
        )

    actual_field_name = matched.name

    if matched.bundle_values:
        value_lower = milestone_value.lower()
        canonical = next(
            (bv.name for bv in matched.bundle_values if bv.name.lower() == value_lower),
            None,
        )
        if canonical is None:
            allowed = ", ".join(bv.name for bv in matched.bundle_values)
            raise ValidationError(
                f"Field {actual_field_name!r} on project {project_key!r} "
                f"has no value {milestone_value!r}. Allowed values: {allowed}."
            )
        canonical_value = canonical
    else:
        canonical_value = milestone_value

    project_lit = youtrack_query_literal(project_key)
    value_lit = youtrack_query_literal(canonical_value)
    query_text = f"project: {project_lit} {actual_field_name}: {value_lit}"

    try:
        issues = client.issues.list(query=query_text, top=limit, with_tags=True)
    except APIError as e:
        return MilestoneRefreshReport(
            hydrated=[],
            failed=[FailedQuery(slug=slug, reason=f"{type(e).__name__}: {e}")],
        )

    truncated = len(issues) == limit
    issue_payloads = [_query_issue_to_cache_payload(issue) for issue in issues]
    payload: dict[str, Any] = {
        "kind": "query",
        "source": {
            "command": MILESTONE_REFRESH_COMMAND,
            "project_key": project_key,
            "field_name": actual_field_name,
            "milestone_value": canonical_value,
            "query_text": query_text,
            "limit": limit,
            "truncated": truncated,
            "count": len(issues),
            "fetched_at": _format_iso(when),
        },
        "issues": issue_payloads,
    }
    write_cached_query(slug, payload, fetched_at=when, cache_root=root)
    return MilestoneRefreshReport(
        hydrated=[
            HydratedMilestoneRun(
                milestone_value=canonical_value,
                project_key=project_key,
                field_name=actual_field_name,
                query_text=query_text,
                slug=slug,
                path=str(root / QUERIES_DIRNAME / f"{slug}.yaml"),
                count=len(issues),
                truncated=truncated,
            )
        ],
        failed=[],
    )


# ---------------------------------------------------------------------------
# Refresh — epic + children hydration (M008 S7c)
# ---------------------------------------------------------------------------

EPIC_LINK_TYPE = "Subtask"
EPIC_LINK_DIRECTION = "OUTWARD"


def _extract_epic_children(
    links: list[dict[str, Any]],
) -> tuple[list[str], dict[str, str | None], list[tuple[str, str]], int]:
    """Walk one epic's link list, return ``(child_ids, summaries, observed, skipped)``.

    Filters to ``linkType.name == "Subtask"`` + ``direction == "OUTWARD"``.
    Flattens each matching record's ``issues[]`` list, requires
    ``idReadable`` on each entry (entries missing it count into
    ``skipped``), and deduplicates by ``idReadable`` preserving
    first-seen order so a permission-limited or mis-modelled link record
    does not cause repeat fetches.

    ``observed`` is the deduplicated list of every
    ``(linkType.name, direction)`` pair that actually carries issues —
    the ``source.note`` diagnostic on the manifest when
    ``child_count == 0``. Empty link-type containers are skipped:
    YouTrack returns a record per direction for every link type the
    project schema knows about regardless of population, so reporting
    them all would drown a real configuration divergence in noise.
    """
    child_ids: list[str] = []
    summaries: dict[str, str | None] = {}
    seen: set[str] = set()
    observed_pairs: list[tuple[str, str]] = []
    observed_seen: set[tuple[str, str]] = set()
    skipped = 0

    for link in links:
        link_type_name = (link.get("linkType") or {}).get("name", "")
        direction = link.get("direction", "")
        issues_payload = link.get("issues") or []

        if issues_payload:
            pair = (link_type_name, direction)
            if pair not in observed_seen:
                observed_seen.add(pair)
                observed_pairs.append(pair)

        if link_type_name != EPIC_LINK_TYPE or direction != EPIC_LINK_DIRECTION:
            continue

        for issue in issues_payload:
            child_id = issue.get("idReadable")
            if not child_id:
                skipped += 1
                continue
            if child_id in seen:
                continue
            seen.add(child_id)
            child_ids.append(child_id)
            summaries[child_id] = issue.get("summary")

    return child_ids, summaries, observed_pairs, skipped


def refresh_epic_with_children(
    client: Any,
    epic_id: str,
    *,
    connection: ConnectionContext,
    fetched_at: datetime | None = None,
    cache_root: Path | None = None,
) -> EpicRefreshReport:
    """Hydrate one epic plus its direct Subtask-OUTWARD children.

    Three kinds of cache files in one invocation:

    1. The epic itself → ``cache_root/issues/<EPIC_ID>.yaml`` via the
       S6 ``write_cached_issue`` primitive (rich-fetch projection,
       identical payload shape to ``kd /cache refresh --issue EPIC_ID``).
    2. Each child → ``cache_root/issues/<CHILD_ID>.yaml`` via the same
       S6 primitive (one rich-fetch per child, in epic-link order).
    3. A manifest → ``cache_root/queries/epic-<slug>-children.yaml`` via
       the S7a ``write_cached_query`` primitive. The manifest records
       parent/child metadata plus a flat list of child rows, each with
       ``cached``/``failed``/``reason`` so a downstream reader can
       enumerate the relationship without re-reading upstream.

    Traversal mechanism: link-based via
    :meth:`IssueOperations.list_links`. v1 hardcodes
    ``linkType.name == "Subtask"`` and ``direction == "OUTWARD"``;
    configurable link-type names are deferred until HITL or dogfooding
    surfaces a real divergence.

    Failure semantics:

    - Epic rich-fetch ``APIError`` → ``failed[stage="epic_fetch"]``;
      no manifest, no child fetches.
    - Link enumeration ``APIError`` → epic file written;
      ``failed[stage="link_enumeration"]``; manifest deliberately
      skipped because relationship data is unknown.
    - Per-child rich-fetch ``APIError`` → manifest still written; the
      failed child appears in ``children_failed`` and its manifest row
      carries ``cached: false, failed: true, reason: ...``.
    - ``AuthError`` and ``ConfigError`` propagate as command-level
      failures.

    Empty children (leaf issue, INWARD-only Subtask, or different
    hierarchy convention) is success: manifest written with
    ``child_count: 0`` and ``source.note`` listing every observed
    ``(linkType.name, direction)`` pair verbatim.

    Read-only by contract: writes only under ``cache_root``; no upstream
    mutation.
    """
    workspace_dir = require_workspace_dir()
    if cache_root is not None:
        root = _validate_cache_scope_root(cache_root)
    else:
        root = connection_cache_dir(connection, workspace_dir.parent)
    when = fetched_at or datetime.now(timezone.utc)
    write_scope_manifest(connection, cache_root=root, fetched_at=when)

    try:
        epic = client.issues.get(epic_id, detail="rich")
    except APIError as e:
        return EpicRefreshReport(
            epic=None,
            children=[],
            children_failed=[],
            failed=[
                FailedStage(
                    stage="epic_fetch",
                    id=epic_id,
                    reason=f"{type(e).__name__}: {e}",
                )
            ],
            manifest_path=None,
        )

    epic_payload = _issue_to_cache_payload(
        epic,
        fetched_at=when,
        include_comments=False,
        command=EPIC_REFRESH_COMMAND,
    )
    write_cached_issue(epic.id_readable, epic_payload, fetched_at=when, cache_root=root)
    epic_hydrated = HydratedIssue(
        id=epic.id_readable,
        summary=epic.summary,
        upstream_updated=_ms_to_iso(epic.updated),
        path=str(root / ISSUES_DIRNAME / f"{epic.id_readable}.yaml"),
        comments_count=None,
    )

    try:
        links = client.issues.list_links(epic.id_readable)
    except APIError as e:
        return EpicRefreshReport(
            epic=epic_hydrated,
            children=[],
            children_failed=[],
            failed=[
                FailedStage(
                    stage="link_enumeration",
                    id=epic.id_readable,
                    reason=f"{type(e).__name__}: {e}",
                )
            ],
            manifest_path=None,
        )

    child_ids, link_summaries, observed_pairs, skipped_payloads = _extract_epic_children(links)

    children_hydrated: list[HydratedIssue] = []
    children_failed: list[FailedIssue] = []
    manifest_rows: list[dict[str, Any]] = []
    for child_id in child_ids:
        try:
            child = client.issues.get(child_id, detail="rich")
            child_payload = _issue_to_cache_payload(
                child,
                fetched_at=when,
                include_comments=False,
                command=EPIC_REFRESH_COMMAND,
            )
            write_cached_issue(child.id_readable, child_payload, fetched_at=when, cache_root=root)
            children_hydrated.append(
                HydratedIssue(
                    id=child.id_readable,
                    summary=child.summary,
                    upstream_updated=_ms_to_iso(child.updated),
                    path=str(root / ISSUES_DIRNAME / f"{child.id_readable}.yaml"),
                    comments_count=None,
                )
            )
            manifest_rows.append(
                {
                    "id": child.id_readable,
                    "summary": child.summary,
                    "cached": True,
                    "failed": False,
                }
            )
        except APIError as e:
            reason = f"{type(e).__name__}: {e}"
            children_failed.append(FailedIssue(id=child_id, reason=reason))
            manifest_rows.append(
                {
                    "id": child_id,
                    "summary": link_summaries.get(child_id),
                    "cached": False,
                    "failed": True,
                    "reason": reason,
                }
            )

    slug = _sluggify(f"epic-{epic.id_readable}-children")
    note = [list(pair) for pair in observed_pairs] if not child_ids and observed_pairs else []
    manifest_payload: dict[str, Any] = {
        "kind": "query",
        "source": {
            "command": EPIC_REFRESH_COMMAND,
            "epic_id": epic.id_readable,
            "epic_summary": epic.summary,
            "link_type": EPIC_LINK_TYPE,
            "direction": EPIC_LINK_DIRECTION,
            "child_count": len(child_ids),
            "children_failed_count": len(children_failed),
            "skipped_payloads": skipped_payloads,
            "note": note,
            "fetched_at": _format_iso(when),
        },
        "children": manifest_rows,
    }
    write_cached_query(slug, manifest_payload, fetched_at=when, cache_root=root)
    manifest_path = str(root / QUERIES_DIRNAME / f"{slug}.yaml")

    return EpicRefreshReport(
        epic=epic_hydrated,
        children=children_hydrated,
        children_failed=children_failed,
        failed=[],
        manifest_path=manifest_path,
    )


def refresh_article(
    client: Any,
    article_id: str,
    *,
    connection: ConnectionContext,
    fetched_at: datetime | None = None,
    cache_root: Path | None = None,
) -> SingleArticleRefreshReport:
    """Hydrate one article into ``cache_root/articles/``.

    ``APIError`` and subclasses are isolated into ``failed[]``;
    ``AuthError`` and ``ConfigError`` propagate as command-level
    failures. Read-only by contract: writes only under ``cache_root``.
    """
    workspace_dir = require_workspace_dir()
    if cache_root is not None:
        root = _validate_cache_scope_root(cache_root)
    else:
        root = connection_cache_dir(connection, workspace_dir.parent)
    when = fetched_at or datetime.now(timezone.utc)
    write_scope_manifest(connection, cache_root=root, fetched_at=when)

    try:
        article = client.articles.get(article_id)
        meta = article_to_cache_meta(
            article,
            when,
            command=SINGLE_ARTICLE_REFRESH_COMMAND,
            reason="single-entity refresh",
        )
        write_cached_article(
            article.id_readable,
            article.content or "",
            meta,
            cache_root=root,
        )
        return SingleArticleRefreshReport(
            hydrated=[
                HydratedArticle(
                    id=article.id_readable,
                    summary=article.summary,
                    upstream_updated=meta.upstream_updated,
                    path=str(root / ARTICLES_DIRNAME / f"{article.id_readable}.md"),
                )
            ],
            failed=[],
        )
    except APIError as e:
        return SingleArticleRefreshReport(
            hydrated=[],
            failed=[FailedArticle(id=article_id, reason=f"{type(e).__name__}: {e}")],
        )


# ---------------------------------------------------------------------------
# Search — read-only substring search across hydrated cache (M008 S9)
# ---------------------------------------------------------------------------

DEFAULT_SEARCH_LIMIT = 200
SEARCHABLE_KINDS = ("article", "issue", "query")
_SNIPPET_CONTEXT = 60


_MD_BANNER_OPEN = "<!-- kd-cache:"
_MD_BANNER_CLOSE = "-->"
_YAML_BANNER_PREFIX = "# kd-cache:"


def _strip_cache_banner(text: str, *, kind: Literal["md", "yaml"]) -> tuple[str, str]:
    """Split a cache file's banner from its body. Returns ``(banner, body)``.

    Recognizes the two banner forms rendered by :func:`_render_banner_md`
    and :func:`_render_banner_yaml`. Raises :class:`ValueError` when the
    expected banner shape is missing — :func:`search_cache` translates
    this into a structured ``banner_unparseable`` warning.

    *Markdown* (``kind="md"``): banner is a single ``<!-- kd-cache: ...
    -->`` block that begins at ``text[0]``. The closing ``-->`` is
    located, the trailing newline (if any) is consumed, and everything
    after is the body.

    *YAML* (``kind="yaml"``): banner is exactly two leading lines, each
    starting with ``# `` and the first beginning with ``# kd-cache:``.
    Body is everything from the third line onward.
    """
    if kind == "md":
        if not text.startswith(_MD_BANNER_OPEN):
            raise ValueError("markdown banner missing leading '<!-- kd-cache:' marker")
        close = text.find(_MD_BANNER_CLOSE)
        if close == -1:
            raise ValueError("markdown banner missing closing '-->' marker")
        end = close + len(_MD_BANNER_CLOSE)
        banner = text[:end]
        body = text[end:]
        if body.startswith("\n"):
            body = body[1:]
        return banner, body

    if kind == "yaml":
        lines = text.split("\n")
        if len(lines) < 2:
            raise ValueError("yaml banner requires two leading '# '-prefixed lines")
        if not lines[0].startswith(_YAML_BANNER_PREFIX):
            raise ValueError("yaml banner missing leading '# kd-cache:' marker")
        if not lines[1].startswith("# "):
            raise ValueError("yaml banner missing second '# '-prefixed line")
        banner = "\n".join(lines[:2])
        body = "\n".join(lines[2:])
        return banner, body

    raise ValueError(f"unknown banner kind: {kind!r}")


def _make_snippet(field_text: str, query_lower: str, *, short_field: bool = False) -> str:
    """Carve a context window around the first match of *query_lower*.

    Newlines are collapsed to single spaces. ``short_field=True`` skips
    windowing — returns the field text verbatim with newlines collapsed
    (used for one-line fields like summaries and ids).
    """
    flat = " ".join(field_text.split())
    if short_field:
        return flat
    idx = flat.casefold().find(query_lower)
    if idx == -1:
        return flat
    start = max(0, idx - _SNIPPET_CONTEXT)
    end = min(len(flat), idx + len(query_lower) + _SNIPPET_CONTEXT)
    snippet = flat[start:end]
    if start > 0:
        snippet = "..." + snippet
    if end < len(flat):
        snippet = snippet + "..."
    return snippet


def _field_matches(field: str | None, query_lower: str) -> bool:
    return field is not None and query_lower in field.casefold()


@dataclass(frozen=True)
class _FieldHit:
    matched_field: str
    snippet: str


def _first_match_in_fields(
    fields: list[tuple[str, str | None, bool]],
    query_lower: str,
) -> _FieldHit | None:
    """Walk *fields* in order; return the first matching ``(name, value, short)``.

    ``fields`` is a precedence-ordered list. ``short`` flags one-line
    fields (summary, id) where the snippet is the field text verbatim.
    """
    for name, value, short in fields:
        if _field_matches(value, query_lower):
            assert value is not None  # narrowed by _field_matches
            return _FieldHit(
                matched_field=name, snippet=_make_snippet(value, query_lower, short_field=short)
            )
    return None


def _search_article_dir(
    articles_dir: Path,
    *,
    connection: str | None,
    slug: str,
    query_lower: str,
    matches: list[CacheSearchMatch],
    warnings: list[CacheStatusWarning],
    limit: int,
) -> bool:
    """Search ``articles/`` under one scope. Returns True if *limit* reached."""
    if not articles_dir.is_dir():
        return False
    for body_path in sorted(articles_dir.glob("*.md")):
        if len(matches) >= limit:
            return True
        article_id = body_path.stem
        sidecar_path = articles_dir / f"{article_id}.meta.yaml"
        summary: str | None = None
        if sidecar_path.exists():
            try:
                with sidecar_path.open("r", encoding="utf-8") as fp:
                    sidecar = yaml.safe_load(fp)
                if isinstance(sidecar, dict):
                    raw_summary = sidecar.get("summary")
                    summary = raw_summary if isinstance(raw_summary, str) else None
            except (OSError, yaml.YAMLError) as exc:
                warnings.append(
                    CacheStatusWarning(
                        code="sidecar_unparseable",
                        message=f"unable to parse {sidecar_path.name}: {exc}",
                        path=str(sidecar_path),
                    )
                )
        try:
            raw = body_path.read_text(encoding="utf-8")
        except OSError as exc:
            warnings.append(
                CacheStatusWarning(
                    code="banner_unparseable",
                    message=f"unable to read {body_path.name}: {exc}",
                    path=str(body_path),
                )
            )
            continue
        try:
            _, body = _strip_cache_banner(raw, kind="md")
        except ValueError as exc:
            warnings.append(
                CacheStatusWarning(
                    code="banner_unparseable",
                    message=f"unable to parse banner from {body_path.name}: {exc}",
                    path=str(body_path),
                )
            )
            continue
        hit = _first_match_in_fields(
            [("summary", summary, True), ("body", body, False)],
            query_lower,
        )
        if hit is None:
            continue
        matches.append(
            CacheSearchMatch(
                path=str(body_path),
                connection=connection,
                slug=slug,
                kind="article",
                id=article_id,
                summary=summary,
                matched_field=hit.matched_field,
                snippet=hit.snippet,
            )
        )
    return len(matches) >= limit


def _load_yaml_payload(
    path: Path,
    warnings: list[CacheStatusWarning],
) -> dict[str, Any] | None:
    """Read a YAML cache file's payload, recovering past banner failures.

    On banner-strip failure but successful payload parse, emits a
    ``banner_unparseable`` warning and still returns the payload — the
    banner string is never inside the searchable field set, so search
    can recover. On payload parse failure, emits ``payload_unparseable``
    and returns ``None``.
    """
    try:
        raw = path.read_text(encoding="utf-8")
    except OSError as exc:
        warnings.append(
            CacheStatusWarning(
                code="payload_unparseable",
                message=f"unable to read {path.name}: {exc}",
                path=str(path),
            )
        )
        return None
    try:
        _, body = _strip_cache_banner(raw, kind="yaml")
    except ValueError as exc:
        warnings.append(
            CacheStatusWarning(
                code="banner_unparseable",
                message=f"unable to parse banner from {path.name}: {exc}",
                path=str(path),
            )
        )
        body = raw  # try the full file — payload may parse without banner
    try:
        loaded = yaml.safe_load(body)
    except yaml.YAMLError as exc:
        warnings.append(
            CacheStatusWarning(
                code="payload_unparseable",
                message=f"unable to parse YAML payload from {path.name}: {exc}",
                path=str(path),
            )
        )
        return None
    if not isinstance(loaded, dict):
        warnings.append(
            CacheStatusWarning(
                code="payload_unparseable",
                message=f"YAML payload in {path.name} is not a mapping",
                path=str(path),
            )
        )
        return None
    return loaded


def _search_issue_dir(
    issues_dir: Path,
    *,
    connection: str | None,
    slug: str,
    query_lower: str,
    matches: list[CacheSearchMatch],
    warnings: list[CacheStatusWarning],
    limit: int,
) -> bool:
    """Search ``issues/`` under one scope. Returns True if *limit* reached."""
    if not issues_dir.is_dir():
        return False
    for path in sorted(issues_dir.glob("*.yaml")):
        if len(matches) >= limit:
            return True
        payload = _load_yaml_payload(path, warnings)
        if payload is None:
            continue
        issue_id = payload.get("id")
        if not isinstance(issue_id, str):
            issue_id = path.stem
        summary = payload.get("summary") if isinstance(payload.get("summary"), str) else None
        description = (
            payload.get("description") if isinstance(payload.get("description"), str) else None
        )
        fields: list[tuple[str, str | None, bool]] = [
            ("summary", summary, True),
            ("description", description, False),
        ]
        comments = payload.get("comments")
        if isinstance(comments, list):
            for comment in comments:
                if isinstance(comment, dict):
                    text = comment.get("text")
                    if isinstance(text, str):
                        fields.append(("comment.text", text, False))
        hit = _first_match_in_fields(fields, query_lower)
        if hit is None:
            continue
        matches.append(
            CacheSearchMatch(
                path=str(path),
                connection=connection,
                slug=slug,
                kind="issue",
                id=issue_id,
                summary=summary,
                matched_field=hit.matched_field,
                snippet=hit.snippet,
            )
        )
    return len(matches) >= limit


def _identify_query_shape(payload: dict[str, Any]) -> str:
    """Sniff a query cache file's structural shape.

    Returns one of ``"saved_query"`` (saved-query / milestone),
    ``"primer_scope"`` (S5 tag-entities), ``"epic_children"`` (S7c
    epic+children manifest), or ``"unknown"`` for anything else.
    """
    source = payload.get("source")
    if (
        isinstance(source, dict)
        and "epic_id" in source
        and isinstance(payload.get("children"), list)
    ):
        return "epic_children"
    if isinstance(payload.get("issues"), list):
        return "saved_query"
    if isinstance(payload.get("results"), list) and isinstance(payload.get("meta"), dict):
        return "primer_scope"
    return "unknown"


def _search_query_file_saved(
    payload: dict[str, Any],
    query_lower: str,
) -> tuple[str | None, _FieldHit | None]:
    """Search a saved-query / milestone payload. Returns (file_summary, hit)."""
    source = payload.get("source", {}) if isinstance(payload.get("source"), dict) else {}
    query_name = source.get("query_name") if isinstance(source.get("query_name"), str) else None
    query_text = source.get("query_text") if isinstance(source.get("query_text"), str) else None
    file_summary = query_name or query_text
    fields: list[tuple[str, str | None, bool]] = [
        ("source.query_name", query_name, True),
        ("source.query_text", query_text, False),
    ]
    issues = payload.get("issues")
    if isinstance(issues, list):
        for entry in issues:
            if isinstance(entry, dict):
                row_summary = entry.get("summary")
                if isinstance(row_summary, str):
                    fields.append(("issue.summary", row_summary, True))
    return file_summary, _first_match_in_fields(fields, query_lower)


def _search_query_file_primer_scope(
    payload: dict[str, Any],
    query_lower: str,
) -> tuple[str | None, _FieldHit | None]:
    """Search a primer-scope tag-entities payload."""
    fields: list[tuple[str, str | None, bool]] = []
    results = payload.get("results")
    if isinstance(results, list):
        for entry in results:
            if isinstance(entry, dict):
                row_summary = entry.get("summary")
                if isinstance(row_summary, str):
                    fields.append(("result.summary", row_summary, True))
                row_id = entry.get("id_readable")
                if isinstance(row_id, str):
                    fields.append(("result.id_readable", row_id, True))
    return None, _first_match_in_fields(fields, query_lower)


def _search_query_file_epic_children(
    payload: dict[str, Any],
    query_lower: str,
) -> tuple[str | None, _FieldHit | None]:
    """Search an epic-children manifest payload."""
    source = payload.get("source", {}) if isinstance(payload.get("source"), dict) else {}
    epic_summary = (
        source.get("epic_summary") if isinstance(source.get("epic_summary"), str) else None
    )
    fields: list[tuple[str, str | None, bool]] = [
        ("source.epic_summary", epic_summary, True),
    ]
    children = payload.get("children")
    if isinstance(children, list):
        for entry in children:
            if isinstance(entry, dict):
                row_summary = entry.get("summary")
                if isinstance(row_summary, str):
                    fields.append(("child.summary", row_summary, True))
    return epic_summary, _first_match_in_fields(fields, query_lower)


def _search_query_dir(
    queries_dir: Path,
    *,
    connection: str | None,
    slug: str,
    query_lower: str,
    matches: list[CacheSearchMatch],
    warnings: list[CacheStatusWarning],
    limit: int,
) -> bool:
    """Search ``queries/`` under one scope. Returns True if *limit* reached."""
    if not queries_dir.is_dir():
        return False
    for path in sorted(queries_dir.glob("*.yaml")):
        if len(matches) >= limit:
            return True
        payload = _load_yaml_payload(path, warnings)
        if payload is None:
            continue
        shape = _identify_query_shape(payload)
        if shape == "saved_query":
            file_summary, hit = _search_query_file_saved(payload, query_lower)
        elif shape == "primer_scope":
            file_summary, hit = _search_query_file_primer_scope(payload, query_lower)
        elif shape == "epic_children":
            file_summary, hit = _search_query_file_epic_children(payload, query_lower)
        else:
            warnings.append(
                CacheStatusWarning(
                    code="query_shape_unrecognized",
                    message=f"unknown query cache shape in {path.name}",
                    path=str(path),
                )
            )
            continue
        if hit is None:
            continue
        matches.append(
            CacheSearchMatch(
                path=str(path),
                connection=connection,
                slug=slug,
                kind="query",
                id=path.stem,
                summary=file_summary,
                matched_field=hit.matched_field,
                snippet=hit.snippet,
            )
        )
    return len(matches) >= limit


def _search_one_scope(
    scope_root: Path,
    *,
    connection: str | None,
    slug: str,
    query_lower: str,
    kinds: tuple[str, ...],
    matches: list[CacheSearchMatch],
    warnings: list[CacheStatusWarning],
    limit: int,
) -> bool:
    """Search every requested kind under one scope. Returns True if limit hit."""
    if "article" in kinds:
        if _search_article_dir(
            scope_root / ARTICLES_DIRNAME,
            connection=connection,
            slug=slug,
            query_lower=query_lower,
            matches=matches,
            warnings=warnings,
            limit=limit,
        ):
            return True
    if "issue" in kinds:
        if _search_issue_dir(
            scope_root / ISSUES_DIRNAME,
            connection=connection,
            slug=slug,
            query_lower=query_lower,
            matches=matches,
            warnings=warnings,
            limit=limit,
        ):
            return True
    if "query" in kinds:
        if _search_query_dir(
            scope_root / QUERIES_DIRNAME,
            connection=connection,
            slug=slug,
            query_lower=query_lower,
            matches=matches,
            warnings=warnings,
            limit=limit,
        ):
            return True
    return False


def search_cache(
    query: str,
    *,
    scope_filter: str | None = None,
    kind_filter: str | None = None,
    limit: int = DEFAULT_SEARCH_LIMIT,
    cache_root: Path | None = None,
) -> CacheSearchReport:
    """Search hydrated cache content for *query* (case-insensitive substring).

    Walks every connection-scoped directory by default; ``scope_filter``
    narrows to one scope using the same matcher as
    :func:`compute_cache_status` (manifest connection name with slug
    fallback). ``kind_filter`` restricts to one kind from
    :data:`SEARCHABLE_KINDS`. ``limit`` caps total matches; the walker
    short-circuits the moment the cap is reached and reports
    ``meta.truncated=True``.

    Field precedence per kind is fixed (see the M008 S9 plan); the
    first matching field on a file determines ``matched_field`` and the
    snippet, so every test of a given file produces the same
    deterministic row regardless of further matches inside that file.

    Workspace-wide by contract: this function does **not** accept an
    active-connection name, and ``--scope`` is the only narrowing
    control. The CLI's global ``-c NAME`` selector is informational
    here, exactly as it is for ``kd /cache status``.
    """
    if not query:
        raise ValidationError("Search query must be a non-empty string.")
    if limit < 1:
        raise ValidationError(f"--limit must be >= 1, got {limit}.")
    if kind_filter is not None and kind_filter not in SEARCHABLE_KINDS:
        allowed = ", ".join(SEARCHABLE_KINDS)
        raise ValidationError(f"--kind must be one of {{{allowed}}}, got {kind_filter!r}.")

    target = cache_dir() if cache_root is None else Path(cache_root).resolve()
    kinds: tuple[str, ...] = (kind_filter,) if kind_filter else SEARCHABLE_KINDS
    query_lower = query.casefold()

    matches: list[CacheSearchMatch] = []
    warnings: list[CacheStatusWarning] = []
    scopes_searched: list[CacheSearchScopeRef] = []
    unscoped_searched = False

    if not target.exists():
        return CacheSearchReport(
            matches=[],
            meta=CacheSearchMeta(
                scopes_searched=[],
                unscoped_searched=False,
                kinds_searched=list(kinds),
                matches_found=0,
                truncated=False,
                warnings=[],
            ),
        )

    enumeration = enumerate_cache_scopes(target)
    selected = _select_scopes(enumeration, focus_scope=scope_filter)

    truncated = False
    for ref in selected:
        scopes_searched.append(
            CacheSearchScopeRef(connection=ref.manifest.connection, slug=ref.slug)
        )
        if _search_one_scope(
            Path(ref.path),
            connection=ref.manifest.connection,
            slug=ref.slug,
            query_lower=query_lower,
            kinds=kinds,
            matches=matches,
            warnings=warnings,
            limit=limit,
        ):
            truncated = True
            break

    if not truncated and scope_filter is None:
        # Pre-S8a flat content directly under .kd/cache/.
        if any((target / d).is_dir() for d in (ARTICLES_DIRNAME, ISSUES_DIRNAME, QUERIES_DIRNAME)):
            unscoped_searched = True
            scopes_searched.append(CacheSearchScopeRef(connection=None, slug="unscoped"))
            if _search_one_scope(
                target,
                connection=None,
                slug="unscoped",
                query_lower=query_lower,
                kinds=kinds,
                matches=matches,
                warnings=warnings,
                limit=limit,
            ):
                truncated = True

    return CacheSearchReport(
        matches=matches,
        meta=CacheSearchMeta(
            scopes_searched=scopes_searched,
            unscoped_searched=unscoped_searched,
            kinds_searched=list(kinds),
            matches_found=len(matches),
            truncated=truncated,
            warnings=warnings,
        ),
    )
