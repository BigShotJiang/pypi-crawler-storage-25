# entr-adapter-core

Shared handler framework for ENTR tenant adapters. Provides base handler classes, contract schemas, FastAPI app factory, deployment defaults, and override resolution.

## Quick Start

See the [New Adapter Implementation Guide](docs/new-adapter-guide.md) for a step-by-step walkthrough from repo setup to first test document processed.

## Installation

```bash
pip install entr-adapter-core
```

Or pin a specific version in your `pyproject.toml`:

```toml
[project]
dependencies = [
    "entr-adapter-core==1.0.0",
]
```

## Documentation

- **[New Adapter Guide](docs/new-adapter-guide.md)** — Step-by-step guide to create a new adapter
- **[Use Case Patterns](docs/use-case-patterns.md)** — Common processing patterns with references to production adapters
- **[CLAUDE.md Convention](docs/claude-md-convention.md)** — Three-layer context model for adapter documentation
- **[VERSIONING.md](VERSIONING.md)** — Semantic versioning policy and breaking change contract
- **[CHANGELOG.md](CHANGELOG.md)** — Version history and migration notes
- **Module docs** — Co-located `.md` files in each module directory under `src/entr_adapter_core/`
