function add_prefix(tag, timestamp, record)
    local container = record["container_name"] or tag or "unknown"
    local log_msg = record["log"] or ""

    -- Remove trailing newline if present
    log_msg = log_msg:gsub("\n$", "")

    -- Prepend container name
    record["log"] = container .. " | " .. log_msg

    return 1, timestamp, record
end
