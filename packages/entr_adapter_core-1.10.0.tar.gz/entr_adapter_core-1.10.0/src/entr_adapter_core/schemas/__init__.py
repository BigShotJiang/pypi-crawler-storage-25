"""ENTR Adapter Core contract schemas.

Public API for the Core-Adapter contract types.
"""

from .payload import AppliedMapping, DocumentPayload
from .response import AdapterResponse, ProposedValue, ReviewSuggestion, StatusEnum
from .retrieval import (
    DocumentDownloadPayload,
    DocumentDownloadResponse,
    DocumentIdentifier,
    RetrievalPayload,
    RetrievalResponse,
)

__all__ = [
    "AppliedMapping",
    "DocumentPayload",
    "AdapterResponse",
    "ProposedValue",
    "ReviewSuggestion",
    "StatusEnum",
    "DocumentDownloadPayload",
    "DocumentDownloadResponse",
    "DocumentIdentifier",
    "RetrievalPayload",
    "RetrievalResponse",
]
