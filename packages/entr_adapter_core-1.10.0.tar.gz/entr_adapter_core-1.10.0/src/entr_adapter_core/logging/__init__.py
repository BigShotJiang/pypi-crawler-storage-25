"""ENTR Adapter Core logging infrastructure.

Provides the FlightRecorder for automatic log capture during handler execution.
"""

from .flight_recorder import (
    FlightRecorder,
    FlightRecorderHandler,
    execute_with_flight_recorder,
)

__all__ = [
    "FlightRecorder",
    "FlightRecorderHandler",
    "execute_with_flight_recorder",
]
