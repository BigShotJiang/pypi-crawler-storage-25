"""ENTR Adapter Core - shared handler framework for tenant adapters.

Provides the installable base for ENTR tenant adapters, including
contract schemas, base handler classes, handler registration/dispatch,
FastAPI app factory, and deployment defaults.
"""

# Version is derived from pyproject.toml via importlib.metadata at runtime.
# This avoids manual synchronization — __version__ always reflects the installed version.
try:
    from importlib.metadata import version as _pkg_version
    __version__ = _pkg_version("entr-adapter-core")
except Exception:
    __version__ = "0.0.0"  # fallback for editable installs without metadata

from entr_adapter_core.app import create_adapter_app, create_adapter_router
from entr_adapter_core.config import CoreSettings
from entr_adapter_core.handlers import BaseHandler, RetrievalHandler
from entr_adapter_core.defaults.resolve import (
    DEFAULT_OVERRIDE_DIR,
    ResolvedFile,
    log_resolution_summary,
    resolve_all_files,
    resolve_compose_files,
    resolve_file,
)
from entr_adapter_core.schemas import (
    AdapterResponse,
    AppliedMapping,
    DocumentDownloadPayload,
    DocumentDownloadResponse,
    DocumentIdentifier,
    DocumentPayload,
    RetrievalPayload,
    RetrievalResponse,
    StatusEnum,
)

__all__ = [
    "create_adapter_app",
    "create_adapter_router",
    "CoreSettings",
    "BaseHandler",
    "RetrievalHandler",
    "AdapterResponse",
    "AppliedMapping",
    "DocumentDownloadPayload",
    "DocumentDownloadResponse",
    "DocumentIdentifier",
    "DocumentPayload",
    "RetrievalPayload",
    "RetrievalResponse",
    "StatusEnum",
    "DEFAULT_OVERRIDE_DIR",
    "ResolvedFile",
    "log_resolution_summary",
    "resolve_all_files",
    "resolve_compose_files",
    "resolve_file",
]
