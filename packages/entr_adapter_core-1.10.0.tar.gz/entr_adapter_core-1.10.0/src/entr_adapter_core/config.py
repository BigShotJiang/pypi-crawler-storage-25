"""Base configuration for ENTR adapters.

Provides ``CoreSettings`` — the base Pydantic settings class that all
tenant adapters extend with their own environment variables.
"""

from __future__ import annotations

from pydantic_settings import BaseSettings


class CoreSettings(BaseSettings):
    """Base configuration shared across all ENTR adapters.

    Provides core environment variables that every adapter needs.
    Tenant adapters extend this class with their own fields::

        class TenantSettings(CoreSettings):
            SAP_ENDPOINT: str
            SAP_API_KEY: str
            CUSTOM_TIMEOUT: int = 30

    Use ``@lru_cache()`` in your adapter to create a singleton::

        from functools import lru_cache

        @lru_cache()
        def get_settings() -> TenantSettings:
            return TenantSettings()

    Attributes:
        TENANT_NAME: Name of the tenant (required).
        ENV: Environment name (default: "local").
        IS_TESTING: Whether the adapter is running in test mode (default: True).
    """

    TENANT_NAME: str
    ENV: str = "local"
    IS_TESTING: bool = True

    model_config = {
        "env_file": ".env",
        "env_file_encoding": "utf-8",
    }
