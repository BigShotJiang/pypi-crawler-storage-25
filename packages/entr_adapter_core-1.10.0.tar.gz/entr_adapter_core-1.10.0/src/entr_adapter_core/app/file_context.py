"""Per-request file_id log context.

Restores the ``[File: {file_id}]`` log-line prefix that pre-package
adapters provided via ``app.utils.logger.set_file_context``. The
prefix is what production log search (e.g. ``entr-cli logs lookup
<file_id>``) relies on to locate adapter container stdout/stderr in
CloudWatch by file_id.

This is complementary to the package's flight recorder: the flight
recorder captures handler logs into ``AdapterResponse.execution_logs``
for Core's per-document FileLog UI; this module prefixes the adapter's
own stdout/stderr stream so external CloudWatch search keeps working.

Wiring is automatic when an app is built via
:func:`entr_adapter_core.app.factory.create_adapter_app`. Adapters
that compose their own FastAPI app via ``create_adapter_router()``
should call :func:`install_file_context` explicitly.
"""

from __future__ import annotations

import contextvars
import json
import logging
from typing import Optional

from fastapi import FastAPI
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request

_file_id_var: contextvars.ContextVar[Optional[int]] = contextvars.ContextVar(
    "file_id", default=None
)


def get_file_context() -> Optional[int]:
    """Return the file_id currently associated with this request, or ``None``."""
    return _file_id_var.get()


class _FileContextFilter(logging.Filter):
    """Prepend ``[File: {file_id}]`` to log messages when context is set."""

    def filter(self, record: logging.LogRecord) -> bool:
        file_id = _file_id_var.get()
        if file_id is not None:
            # Mutate the rendered message; safe because a filter runs once
            # per record before the formatter is invoked.
            record.msg = f"[File: {file_id}] {record.msg}"
        return True


class _FileContextMiddleware(BaseHTTPMiddleware):
    """Set the file_id contextvar from the /process payload."""

    async def dispatch(self, request: Request, call_next):
        if request.url.path != "/process" or request.method != "POST":
            return await call_next(request)

        body = await request.body()

        # Re-inject the body so the downstream route handler can re-read it
        async def receive():
            return {"type": "http.request", "body": body, "more_body": False}

        request._receive = receive  # type: ignore[attr-defined]

        token = None
        try:
            payload = json.loads(body)
            file_id = payload.get("document_id")
            if file_id is not None:
                token = _file_id_var.set(file_id)
        except (ValueError, AttributeError):
            pass  # Unparseable body — continue without prefix

        try:
            return await call_next(request)
        finally:
            if token is not None:
                _file_id_var.reset(token)


def install_file_context(app: FastAPI) -> None:
    """Wire the file_id contextvar prefix into the app and root logger.

    Idempotent: calling more than once attaches the filter to any
    handler that doesn't already have it. The middleware itself can
    only be added once per app (FastAPI raises on duplicate).
    """
    app.add_middleware(_FileContextMiddleware)

    log_filter = _FileContextFilter()
    root = logging.getLogger()
    if not any(isinstance(f, _FileContextFilter) for f in root.filters):
        root.addFilter(log_filter)
    for handler in root.handlers:
        if not any(isinstance(f, _FileContextFilter) for f in handler.filters):
            handler.addFilter(log_filter)
