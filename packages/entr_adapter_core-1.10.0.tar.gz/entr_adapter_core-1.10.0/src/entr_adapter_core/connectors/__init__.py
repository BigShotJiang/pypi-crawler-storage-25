"""Shared connectors and retrieval handlers for ENTR adapters.

Connectors provide reusable integrations with common external systems:
- FTPConnector: FTP file operations (list, download, upload, delete)
- SFTPConnector: SFTP file operations with persistent connection and auto-reconnect

Retrieval handlers implement the RetrievalHandler interface for common sources:
- EntrMailboxRetrievalHandler: Gmail mailbox retrieval via OAuth2
- MicrosoftEntraRetrievalHandler: Microsoft Exchange via Graph API

Connectors with optional dependencies use lazy imports. If the required
extra is not installed, importing the connector raises an ``ImportError``
with a clear message directing the user to install the correct extra.
"""

# FTP uses only stdlib — always available
from entr_adapter_core.connectors.ftp import FTPConnector, FTPConnectorConfig

def _missing_extra(name: str, extra: str):
    """Return a placeholder class that raises ImportError when instantiated."""
    class _MissingConnector:
        def __init__(self, *args, **kwargs):
            raise ImportError(
                f"{name} requires the '{extra}' extra. "
                f"Install it with: uv add entr-adapter-core[{extra}]"
            )
        def __repr__(self):
            return f"<{name} — install with: uv add entr-adapter-core[{extra}]>"
    _MissingConnector.__name__ = name
    _MissingConnector.__qualname__ = name
    return _MissingConnector


# SFTP requires the [sftp] extra (paramiko)
try:
    from entr_adapter_core.connectors.sftp import SFTPConnector, SFTPConnectorConfig
except ImportError:
    SFTPConnector = _missing_extra("SFTPConnector", "sftp")  # type: ignore[assignment,misc]
    SFTPConnectorConfig = _missing_extra("SFTPConnectorConfig", "sftp")  # type: ignore[assignment,misc]

# Gmail requires the [gmail] extra (httpx)
try:
    from entr_adapter_core.connectors.gmail import (
        EntrMailboxRetrievalHandler,
        GmailConnectorConfig,
    )
except ImportError:
    EntrMailboxRetrievalHandler = _missing_extra("EntrMailboxRetrievalHandler", "gmail")  # type: ignore[assignment,misc]
    GmailConnectorConfig = _missing_extra("GmailConnectorConfig", "gmail")  # type: ignore[assignment,misc]

# Microsoft requires the [microsoft] extra (httpx)
try:
    from entr_adapter_core.connectors.microsoft import (
        MicrosoftEntraRetrievalHandler,
        MicrosoftConnectorConfig,
    )
except ImportError:
    MicrosoftEntraRetrievalHandler = _missing_extra("MicrosoftEntraRetrievalHandler", "microsoft")  # type: ignore[assignment,misc]
    MicrosoftConnectorConfig = _missing_extra("MicrosoftConnectorConfig", "microsoft")  # type: ignore[assignment,misc]

__all__ = [
    "FTPConnector",
    "FTPConnectorConfig",
    "SFTPConnector",
    "SFTPConnectorConfig",
    "EntrMailboxRetrievalHandler",
    "GmailConnectorConfig",
    "MicrosoftEntraRetrievalHandler",
    "MicrosoftConnectorConfig",
]
