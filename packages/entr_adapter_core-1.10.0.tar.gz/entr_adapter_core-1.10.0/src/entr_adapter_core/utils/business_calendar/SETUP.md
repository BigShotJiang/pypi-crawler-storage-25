# Business Calendar — Setup Guide

## Overview

`BusinessCalendar` is a holiday- and weekend-aware date helper for tenant adapters. Use it whenever an adapter has to decide whether a date extracted from a document is a valid working day, or whether it needs to shift to the next one (typical case: a "deliver date" that lands on a Sunday or public holiday must move forward to the next business day).

It wraps the third-party [`holidays`](https://python-holidays.readthedocs.io/) library — that library answers *"is this date a public holiday in country X?"* and `BusinessCalendar` adds the business-logic layer on top of it (weekends, shift-to-next, business-day arithmetic, per-tenant overrides).

## When to Use This

Use `BusinessCalendar` when your adapter needs to:

- [ ] Validate that an extracted **deliver / due / pickup date** is a real working day, and shift it forward if not.
- [ ] **Add a lead time** of N business days to a start date (e.g. order placed Friday + 7 BD = the following Monday).
- [ ] Check whether a date falls on an **official public holiday** for routing or warning logic.
- [ ] Honour **tenant-specific operating calendars** that diverge from the official public-holiday list (customer is open on Good Friday, has a factory shutdown week, etc.).

Do **not** use it for:
- Currency / time-zone conversions — those are unrelated.
- Approximating "1 month" or "1 week" — use plain `dateutil.relativedelta` for calendar arithmetic that doesn't care about business days.

## Prerequisites

- [ ] The `[business-calendar]` extra installed: `uv add entr-adapter-core[business-calendar]`
- [ ] An ISO-3166 alpha-2 country code for the calendar (e.g. `"NL"`, `"DE"`, `"FR"`, `"BE"`)
- [ ] Optional: a list of holiday names the tenant ignores (e.g. customer is open on Good Friday)
- [ ] Optional: a set of company-specific closure dates (e.g. yearly factory shutdown)

## Configuration

`BusinessCalendar` is a plain dataclass — no env vars, no Pydantic model. Construct it once at adapter startup and reuse it; per-year holiday lookups are cached on the instance:

```python
from datetime import date
from entr_adapter_core.utils.business_calendar import BusinessCalendar

cal = BusinessCalendar(
    country="NL",                            # ISO-3166 alpha-2
    subdiv=None,                             # Optional regional code
    weekend_days=(5, 6),                     # Sat, Sun (Mon=0 .. Sun=6)
    exclude_names={"Good Friday"},           # Holiday names tenant ignores
    extra_holidays={date(2026, 12, 31)},     # Extra company-specific closures
    exclude_predicate=None,                  # Optional callable for conditional rules
)
```

### Configuration Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `country` | `str` | `"NL"` | ISO-3166 alpha-2 country code |
| `subdiv` | `Optional[str]` | `None` | Country subdivision (e.g. `"BY"` for Bavaria, `"CA"` for California) |
| `weekend_days` | `tuple[int, ...]` | `(5, 6)` | Weekday indices treated as weekend (`Mon=0 .. Sun=6`). Empty tuple = no weekends |
| `exclude_names` | `set[str]` | `set()` | Holiday names from the `holidays` library to NOT treat as holidays |
| `extra_holidays` | `set[date]` | `set()` | Extra dates to treat as holidays (company-specific closures) |
| `exclude_predicate` | `Callable[[date, str], bool] \| None` | `None` | Returns `True` for `(date, name)` pairs to exclude. Use for conditional rules `exclude_names` cannot express |

### Common Override Recipes

**Tenant is open on Good Friday** (existing schoonderwolf-galvano case):

```python
cal = BusinessCalendar(country="NL", exclude_names={"Good Friday"})
```

**NL Liberation Day only counts in lustrum years** (years divisible by 5):

```python
cal = BusinessCalendar(
    country="NL",
    exclude_predicate=lambda d, name: (
        "Liberation" in name and d.year % 5 != 0
    ),
)
```

**Annual company closure between Christmas and New Year**:

```python
from datetime import date, timedelta

# Build the set of weekdays (Mon-Fri) in the closure window.
# Listing weekend days as `extra_holidays` is harmless but redundant —
# `is_business_day` already returns False for weekends — so generate
# only the weekdays.
year = date.today().year
window_start = date(year, 12, 27)
window_end = date(year + 1, 1, 1)
closure = {
    window_start + timedelta(days=i)
    for i in range((window_end - window_start).days)
    if (window_start + timedelta(days=i)).weekday() < 5
}
cal = BusinessCalendar(country="NL", extra_holidays=closure)
```

## Public API

Four methods. All accept `date` or `datetime` (datetimes are normalized to their date component).

| Method | Returns | What it does |
|--------|---------|--------------|
| `is_holiday(target)` | `bool` | `True` if `target` is a public holiday (after applying overrides). Weekends are NOT counted as holidays here. |
| `is_business_day(target)` | `bool` | `True` if `target` is neither a weekend (per `weekend_days`) nor a holiday. The everyday "is this date usable?" check. |
| `next_business_day(target, *, inclusive=True, direction=1)` | `date` | First business day at, after, or before `target`. With `direction=1` (default) searches forward; with `direction=-1` searches backward (e.g. "last working day before this holiday"). With `inclusive=False`, always steps by at least one day in the chosen direction. |
| `add_business_days(start, n)` | `date` | Adds `n` business days to `start`. **`start` counts as day 1**, matching tenant lead-time semantics. |

### Forward vs. backward shifting

`next_business_day` covers both directions a delivery/due date may need to be shifted to:

```python
cal = BusinessCalendar(country="NL")

# Forward: holiday → next working day (typical "delivery moves forward")
cal.next_business_day(date(2026, 4, 6))                     # → date(2026, 4, 7)

# Backward: holiday → previous working day (typical "process the day BEFORE")
cal.next_business_day(date(2026, 4, 6), direction=-1)        # → date(2026, 4, 2)

# Backward across a holiday + weekend block (King's Day on Monday)
cal.next_business_day(date(2026, 4, 27), direction=-1)       # → date(2026, 4, 24)
```

## Usage in an Adapter Handler

```python
from datetime import date
from entr_adapter_core.handlers import BaseHandler
from entr_adapter_core.schemas import AdapterResponse, DocumentPayload, StatusEnum
from entr_adapter_core.utils.business_calendar import BusinessCalendar


class MyHandler(BaseHandler):
    def __init__(self, settings, **kwargs):
        super().__init__(settings, **kwargs)
        # Build the calendar once at startup; per-year lookups cache internally.
        self.calendar = BusinessCalendar(
            country="NL",
            exclude_names={"Good Friday"},  # if the customer is open on Good Friday
        )

    async def process(self, payload: DocumentPayload) -> AdapterResponse:
        deliver_date_str = payload.data.get("deliver_date")
        if not deliver_date_str:
            return AdapterResponse(status=StatusEnum.FAILED, message="Missing deliver_date")

        deliver_date = date.fromisoformat(deliver_date_str)

        # Shift weekend / holiday dates to the next valid business day.
        if not self.calendar.is_business_day(deliver_date):
            adjusted = self.calendar.next_business_day(deliver_date)
            payload.data["deliver_date"] = adjusted.isoformat()

        return AdapterResponse(status=StatusEnum.SUCCESS, message="Processed")
```

## Verification

**1. Smoke test in a Python shell:**

```python
from datetime import date
from entr_adapter_core.utils.business_calendar import BusinessCalendar

cal = BusinessCalendar(country="NL")
assert cal.is_holiday(date(2026, 4, 6)) is True       # Easter Monday
assert cal.is_business_day(date(2026, 4, 6)) is False
assert cal.next_business_day(date(2026, 4, 6)) == date(2026, 4, 7)
assert cal.add_business_days(date(2026, 4, 2), 2) == date(2026, 4, 7)
print("ok")
```

**2. Expected output:**

```
ok
```

**3. Common failure modes:**

| Error | Cause | Fix |
|-------|-------|-----|
| `ImportError: BusinessCalendar requires the optional 'holidays' package` | The `[business-calendar]` extra is not installed | Run `uv add entr-adapter-core[business-calendar]` or add `entr-adapter-core[business-calendar]` to your adapter's `pyproject.toml` |
| `ValueError: BusinessCalendar: unknown country/subdivision` | Passed an unsupported country or subdivision code | Use a country supported by the `holidays` package — see https://python-holidays.readthedocs.io/ for the full list |
| `TypeError: BusinessCalendar expected a datetime.date or datetime.datetime` | Passed a `str` or `int` | Parse strings to `date` first: `date.fromisoformat(value)` |
| `ValueError: business_days must be >= 1` | Called `add_business_days(start, 0)` or with negative N | The start date counts as day 1; for "no shift" just use `start` directly |
| `is_holiday` returns `False` for a date you expected to be a holiday | The `holidays` package returns names in English by default — check the actual name | Print `holidays.country_holidays(country, years=[year]).get(date)` to see the real name, then update `exclude_names` accordingly |

## Common Pitfalls

1. **Holiday names are language-dependent.** The `holidays` library defaults to English names (e.g. `"Good Friday"`, not `"Goede Vrijdag"`). When using `exclude_names`, match the names returned by the library's default `language` setting. If you need localized names, pass `language="nl"` etc. to the underlying library — but at the time of writing this guide, `BusinessCalendar` does not yet expose that knob; if you need it, ask for it to be added.
2. **`is_holiday` does NOT include weekends.** A Saturday is not a holiday — it's a weekend. Use `is_business_day` for the combined check. This split exists because some adapters need to flag holidays specifically (e.g. for warnings) while ignoring weekends.
3. **`add_business_days` counts the start as day 1.** This matches the lead-time semantics tenants use ("order placed Friday + 7 BD"). If you want to add N *additional* business days after the start, pass `n + 1` or compute the offset yourself.
4. **`BusinessCalendar` benefits from reuse.** The same instance caches holiday sets across calls. Build once at handler init; do not rebuild per request — that defeats the cache and re-instantiates the upstream `holidays` object.
5. **Subdivision codes vary across libraries.** The `holidays` package uses ISO-3166-2 codes (e.g. `"BY"` for Bavaria, `"CA"` for California). If you don't know the right code, look it up in the `holidays` documentation rather than guessing.
6. **Tenant-specific dates change yearly.** If you use `extra_holidays` for an annual closure, generate it relative to "current year", not as a hard-coded date — otherwise the closure stops applying after one year.

## When to Promote Vs. Keep Local

This module follows the standard `utils/` promotion rule: it lives in `entr-adapter-core` because **two or more adapters need holiday-aware dates**. If your adapter needs an extension that is genuinely tenant-specific (e.g. "skip the third Wednesday of every month for a quarterly maintenance window"), implement it in your adapter's own `utils/` directory — it does not belong in the shared package until a second adapter needs the same behavior.

If a tenant override repeats across multiple adapters (e.g. several Dutch-customer adapters all need to drop Good Friday), add a documented preset at that point — but only after the second occurrence.

## Cross-References

- **Public API:** `entr_adapter_core.utils.business_calendar.BusinessCalendar`
- **Underlying library:** [python-holidays](https://python-holidays.readthedocs.io/) — supports ~150 countries
- **Promotion rule:** see `utils/utils.md` — the same rule applies here as for `[matching]`
- **Reference implementation that motivated this module:** the legacy `_add_business_days` static method inside the schoonderwolf-galvano handler, now superseded by `BusinessCalendar.add_business_days`
