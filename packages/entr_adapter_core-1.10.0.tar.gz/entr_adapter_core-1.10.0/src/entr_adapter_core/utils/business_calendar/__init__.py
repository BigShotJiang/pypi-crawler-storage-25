"""Holiday- and weekend-aware business-day calendar for tenant adapters.

Wraps the third-party ``holidays`` library to add the business logic
adapters need: weekend awareness, "next business day" shifting,
business-day arithmetic, and per-tenant overrides for cases where the
official public-holiday calendar diverges from a customer's real
operating calendar.

Requires the ``[business-calendar]`` optional extra::

    uv add entr-adapter-core[business-calendar]

Public API:
    - ``BusinessCalendar``: Configurable calendar — country, subdivision,
      weekend definition, and tenant-specific overrides. Methods:
      ``is_holiday``, ``is_business_day``, ``next_business_day``,
      ``add_business_days``.

Usage::

    from datetime import date
    from entr_adapter_core.utils.business_calendar import BusinessCalendar

    cal = BusinessCalendar(country="NL")

    cal.is_holiday(date(2026, 4, 6))         # True — Easter Monday
    cal.is_business_day(date(2026, 4, 6))    # False
    cal.next_business_day(date(2026, 4, 6))  # date(2026, 4, 7)
    cal.add_business_days(date(2026, 6, 5), 7)  # date(2026, 6, 15)

    # Tenant override: customer is open on Good Friday
    cal = BusinessCalendar(country="NL", exclude_names={"Good Friday"})

See ``SETUP.md`` for the full developer guide, override recipes, and
common pitfalls.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, datetime, timedelta
from typing import Callable, Dict, Optional, Set, Tuple, Union

try:
    import holidays as _holidays_lib

    _HAS_HOLIDAYS = True
except ImportError:
    _holidays_lib = None  # type: ignore[assignment]
    _HAS_HOLIDAYS = False


__all__ = ["BusinessCalendar"]


DateLike = Union[date, datetime]


def _to_date(value: DateLike) -> date:
    """Normalize a ``date`` or ``datetime`` to a ``date``."""
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    raise TypeError(
        "BusinessCalendar expected a datetime.date or datetime.datetime, "
        f"got {type(value).__name__!r}. Parse strings to a date first "
        "(e.g. datetime.fromisoformat(value).date())."
    )


@dataclass
class BusinessCalendar:
    """Holiday- and weekend-aware calendar for shifting business dates.

    Wraps the ``holidays`` library to add weekend handling, business-day
    arithmetic, and per-tenant overrides. Public-holiday data comes from
    the ``holidays`` package; everything else is layered on top.

    Attributes:
        country: ISO-3166 alpha-2 country code (e.g. ``"NL"``, ``"DE"``,
            ``"FR"``). Passed through to ``holidays.country_holidays``.
        subdiv: Optional country subdivision (e.g. ``"BY"`` for Bavaria,
            ``"CA"`` for California). Forwarded to the ``holidays``
            library when supported.
        weekend_days: Tuple of weekday indices treated as weekend
            (``Monday=0 .. Sunday=6``). Defaults to ``(5, 6)``
            (Saturday + Sunday). Pass an empty tuple to treat every
            weekday as a working day.
        exclude_names: Set of holiday names to drop from the official
            calendar. Use when a tenant operates on what the government
            calls a holiday — e.g. ``{"Good Friday"}`` if the customer
            is open on Good Friday. Names match the strings the
            ``holidays`` library returns, which are language-dependent.
        extra_holidays: Set of additional dates to treat as holidays
            beyond what the official calendar lists. Useful for
            company-specific closures (e.g. annual factory shutdown
            weeks).
        exclude_predicate: Optional callable ``(date, name) -> bool``.
            Returns ``True`` to exclude that ``(date, name)`` pair from
            the holiday set. Use for conditional rules that
            ``exclude_names`` cannot express, e.g. NL Liberation Day
            only counting in lustrum years.

    Per-year holiday lookups are cached internally, so repeated calls
    on the same calendar instance amortize to a single ``holidays``
    library instantiation per year touched. Build the calendar once at
    handler init and reuse it.
    """

    country: str = "NL"
    subdiv: Optional[str] = None
    weekend_days: Tuple[int, ...] = (5, 6)
    exclude_names: Set[str] = field(default_factory=set)
    extra_holidays: Set[date] = field(default_factory=set)
    exclude_predicate: Optional[Callable[[date, str], bool]] = None

    _year_cache: Dict[int, Set[date]] = field(
        default_factory=dict, init=False, repr=False
    )

    def __post_init__(self) -> None:
        if not isinstance(self.country, str) or not self.country.strip():
            raise ValueError(
                "BusinessCalendar: `country` must be a non-empty ISO-3166 "
                f"alpha-2 string (got {self.country!r}). Examples: 'NL', 'DE', 'FR'."
            )
        # Normalize country: the `holidays` library tolerates lowercase in
        # recent versions but historically required uppercase. Be strict here.
        self.country = self.country.strip().upper()

        unique_weekend = set()
        for d in self.weekend_days:
            if not isinstance(d, int) or isinstance(d, bool) or not 0 <= d <= 6:
                raise ValueError(
                    "BusinessCalendar: `weekend_days` entries must be integers "
                    f"in 0..6 (Mon=0 .. Sun=6); got {d!r}."
                )
            unique_weekend.add(d)
        if len(unique_weekend) >= 7:
            raise ValueError(
                "BusinessCalendar: `weekend_days` covers all 7 days of the "
                "week — no business day would ever exist. Drop at least one "
                "weekday from the tuple."
            )

        # Coerce iterable inputs to set; protect against accidental list/tuple
        # arguments that would degrade `name in exclude_names` to O(n).
        self.exclude_names = set(self.exclude_names)
        self.extra_holidays = set(self.extra_holidays)

        for d in self.extra_holidays:
            if not isinstance(d, date) or isinstance(d, datetime):
                # Reject datetimes too — `extra_holidays` is whole-day, not
                # instantaneous; passing a datetime is almost certainly a
                # caller bug.
                raise TypeError(
                    "BusinessCalendar: `extra_holidays` entries must be "
                    f"datetime.date instances (got {type(d).__name__!r} "
                    f"for value {d!r}). Use date(year, month, day) — not "
                    "a string or datetime."
                )

        # Reset the per-instance cache. With `init=False`, `dataclasses.replace`
        # would otherwise carry over a cache built under different config.
        self._year_cache = {}

    def is_holiday(self, target: DateLike) -> bool:
        """Return ``True`` if ``target`` is a public holiday.

        Weekends are NOT considered holidays here — use
        :meth:`is_business_day` for the combined weekend-or-holiday
        check.
        """
        d = _to_date(target)
        return d in self._holidays_for_year(d.year)

    def is_business_day(self, target: DateLike) -> bool:
        """Return ``True`` if ``target`` is a working day.

        A working day is any date that is neither a weekend (per
        :attr:`weekend_days`) nor a public holiday (per the configured
        country/subdivision and tenant overrides).
        """
        d = _to_date(target)
        if d.weekday() in self.weekend_days:
            return False
        return d not in self._holidays_for_year(d.year)

    def next_business_day(
        self,
        target: DateLike,
        *,
        inclusive: bool = True,
        direction: int = 1,
    ) -> date:
        """Return the nearest business day relative to ``target``.

        With ``direction=1`` (default), searches forward — the typical
        "shift this date forward to the next working day" use case
        (e.g. a delivery date that lands on a Sunday or holiday).

        With ``direction=-1``, searches backward — useful when a date
        must land **on or before** ``target`` (e.g. process a delivery
        on the last working day **before** a public holiday so the
        customer is not skipped).

        Args:
            target: The candidate date. Often the deliver/due date
                extracted from a document.
            inclusive: If ``True`` (default) and ``target`` is already
                a business day, return it unchanged. If ``False``,
                always step by at least one day in ``direction``.
            direction: ``1`` to search forward (default) or ``-1`` to
                search backward. Other values raise ``ValueError``.

        Returns:
            The first business day at, after, or before the requested
            point — depending on ``direction``.

        Raises:
            ValueError: If ``direction`` is not ``1`` or ``-1``.
        """
        if direction not in (1, -1):
            raise ValueError(
                "BusinessCalendar.next_business_day: `direction` must be "
                f"1 (forward) or -1 (backward); got {direction!r}."
            )
        d = _to_date(target)
        step = timedelta(days=direction)
        if not inclusive:
            d = d + step
        while not self.is_business_day(d):
            d = d + step
        return d

    def add_business_days(self, start: DateLike, business_days: int) -> date:
        """Span ``business_days`` business days starting from ``start``.

        **Important — non-standard semantics:** ``start`` counts as day 1.
        This matches the lead-time convention tenants use ("order placed
        Friday + 7 BD = …") and the legacy adapter implementations this
        module promotes from. It DIFFERS from the convention used by
        ``numpy.busday_offset``, ``pandas.bdate_range``, and Excel's
        ``WORKDAY`` (which all treat ``+1`` as one business day **after**
        ``start``).

        Worked example (no holidays in span)::

            cal = BusinessCalendar(country="NL")
            cal.add_business_days(date(2026, 6, 5), 7)  # Fri 5 Jun 2026
            # Day 1: Fri 05  Day 2: Mon 08  Day 3: Tue 09  Day 4: Wed 10
            # Day 5: Thu 11  Day 6: Fri 12  Day 7: Mon 15
            # → returns date(2026, 6, 15)

        If you want "n business days strictly *after* ``start``", call
        ``add_business_days(start, n + 1)`` or use
        ``next_business_day(start, inclusive=False)`` repeatedly.

        Args:
            start: The starting date (counts as day 1).
            business_days: Total business days to span, **including**
                ``start``. Must be ``>= 1``.

        Returns:
            The date marking the ``business_days``-th business day of
            the span.

        Raises:
            ValueError: If ``business_days < 1``.
        """
        if business_days < 1:
            raise ValueError(
                f"business_days must be >= 1 (got {business_days}). "
                "The start date counts as day 1, so 1 is the smallest "
                "meaningful value — call sites that want 'no shift' "
                "should skip the call entirely."
            )

        current = _to_date(start)
        remaining = business_days - 1
        while remaining > 0:
            current = current + timedelta(days=1)
            if self.is_business_day(current):
                remaining -= 1
        return current

    # ── Internal ────────────────────────────────────────────────────────

    def _holidays_for_year(self, year: int) -> Set[date]:
        """Return the (cached) set of holiday dates for ``year``.

        Applies ``exclude_names``, ``exclude_predicate``, and merges in
        any ``extra_holidays`` falling within the year.
        """
        cached = self._year_cache.get(year)
        if cached is not None:
            return cached

        if not _HAS_HOLIDAYS:
            raise ImportError(
                "BusinessCalendar requires the optional `holidays` package, "
                "but it is not installed. Add it to your adapter with:\n"
                "    uv add entr-adapter-core[business-calendar]\n"
                "or include `entr-adapter-core[business-calendar]` in pyproject.toml."
            )

        try:
            official = _holidays_lib.country_holidays(  # type: ignore[union-attr]
                self.country, subdiv=self.subdiv, years=[year]
            )
        except NotImplementedError as exc:
            raise ValueError(
                f"BusinessCalendar: unknown country/subdivision "
                f"(country={self.country!r}, subdiv={self.subdiv!r}). "
                "Use an ISO-3166 alpha-2 country code supported by the "
                "`holidays` package — see "
                "https://python-holidays.readthedocs.io/ for the list."
            ) from exc

        result: Set[date] = set()
        for d, name in official.items():
            if name in self.exclude_names:
                continue
            if self.exclude_predicate is not None and self.exclude_predicate(
                d, name
            ):
                continue
            result.add(d)

        result |= {d for d in self.extra_holidays if d.year == year}

        self._year_cache[year] = result
        return result
