"""Sandboxed source-code access for adapter debug endpoints.

Provides ``SourceSandbox`` — a minimal, path-traversal-safe accessor
for files under an adapter's ``src/`` tree. Used by the
``/debug/tree`` and ``/debug/file`` endpoints (registered by
``create_adapter_router`` when ``source_root`` is configured) so that
Core's support AI agent can inspect adapter source remotely.

Sensitive paths (``__pycache__``, ``.env``, ``.git``, files containing
``credentials`` or ``secrets``) are excluded from listings and
forbidden from being read. Path traversal outside the configured root
raises :class:`SandboxError`.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Iterable, List

DEFAULT_EXCLUDE_PATTERNS = frozenset(
    {
        "__pycache__",
        ".pyc",
        ".pyo",
        ".env",
        ".git",
        "secrets",
        "credentials",
    }
)


class SandboxError(Exception):
    """Raised when sandbox access is denied (traversal, excluded file, etc.)."""


class SourceSandbox:
    """Read-only sandbox restricted to a single root directory.

    Args:
        root: Directory the sandbox is rooted at. All paths passed to
            :meth:`list_tree` and :meth:`get_content` are interpreted
            relative to this root and validated to remain inside it.
        exclude_patterns: Iterable of substring/file-suffix patterns
            that mark a name as excluded. Defaults to
            :data:`DEFAULT_EXCLUDE_PATTERNS`.
    """

    def __init__(
        self,
        root: Path,
        exclude_patterns: Iterable[str] | None = None,
    ) -> None:
        self.root = Path(root).resolve()
        self.exclude_patterns = (
            frozenset(exclude_patterns)
            if exclude_patterns is not None
            else DEFAULT_EXCLUDE_PATTERNS
        )

    def _is_excluded(self, name: str) -> bool:
        if name.startswith("."):
            return True
        return any(pattern in name for pattern in self.exclude_patterns)

    def _validate_path(self, path: str) -> Path:
        if not path or path == ".":
            return self.root

        requested = (self.root / path).resolve()
        try:
            requested.relative_to(self.root)
        except ValueError as exc:
            raise SandboxError("Access denied: path outside sandbox") from exc

        return requested

    def list_tree(self, subpath: str = ".") -> List[dict]:
        """Recursively list files under ``subpath`` (default: sandbox root)."""
        base = self._validate_path(subpath)

        if not base.exists():
            raise SandboxError(f"Path not found: {subpath}")
        if not base.is_dir():
            raise SandboxError(f"Not a directory: {subpath}")

        entries: List[dict] = []
        for root, dirs, files in os.walk(base):
            dirs[:] = [d for d in dirs if not self._is_excluded(d)]
            root_path = Path(root)

            for file in files:
                if self._is_excluded(file):
                    continue
                file_path = root_path / file
                relative = file_path.relative_to(self.root)
                entries.append(
                    {
                        "path": str(relative).replace("\\", "/"),
                        "type": "file",
                        "size": file_path.stat().st_size,
                    }
                )

        return sorted(entries, key=lambda x: x["path"])

    def get_content(self, path: str) -> str:
        """Return the UTF-8 contents of the file at ``path`` (relative to root)."""
        file_path = self._validate_path(path)

        if not file_path.exists():
            raise FileNotFoundError(f"File not found: {path}")
        if not file_path.is_file():
            raise SandboxError(f"Not a file: {path}")
        if self._is_excluded(file_path.name):
            raise SandboxError("Access denied: excluded file type")

        return file_path.read_text(encoding="utf-8")
