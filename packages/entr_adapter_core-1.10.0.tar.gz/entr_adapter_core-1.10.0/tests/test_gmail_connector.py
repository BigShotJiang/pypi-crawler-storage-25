"""Tests for the Gmail mailbox retrieval connector.

Tests cover:
- GmailConnectorConfig validation (correct/incorrect inputs)
- EntrMailboxRetrievalHandler interface conformance
- Handler construction with config and legacy settings objects
- Lazy import guard behaviour
- list_documents and get_document with mocked HTTP responses
"""

import logging
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch
from urllib.parse import parse_qs, urlparse

import httpx
import pytest
import pytest_asyncio
from pydantic import ValidationError

from entr_adapter_core.connectors.gmail import (
    EntrMailboxRetrievalHandler,
    GmailConnectorConfig,
)
from entr_adapter_core.handlers import RetrievalHandler
from datetime import date

from entr_adapter_core.schemas import RetrievalPayload


def _extract_url(call):
    """Return the URL from a mock .get() call, whether passed positionally or as url=."""
    args, kwargs = call
    if args:
        return args[0]
    return kwargs.get("url")


def _extract_q(call):
    """Return the URL-decoded q= value from a mock .get() call, or None if missing."""
    url = _extract_url(call)
    if url is None:
        return None
    qs = parse_qs(urlparse(url).query)
    values = qs.get("q")
    if not values:
        return None
    return values[0]


# ── GmailConnectorConfig tests ──────────────────────────────────────────


class TestGmailConnectorConfig:
    """Validate the Pydantic config model for the Gmail connector."""

    def test_valid_config(self):
        config = GmailConnectorConfig(
            tenant_name="Acme",
            gmail_client_id="id-123",
            gmail_client_secret="secret-456",
            gmail_refresh_token="refresh-789",
        )
        assert config.tenant_name == "Acme"
        assert config.TENANT_NAME == "Acme"
        assert config.gmail_client_id == "id-123"
        assert config.GMAIL_CLIENT_ID == "id-123"
        assert config.label_override is None
        assert config.max_results_per_page == 500

    def test_config_with_label_override(self):
        config = GmailConnectorConfig(
            tenant_name="Acme",
            gmail_client_id="id",
            gmail_client_secret="secret",
            gmail_refresh_token="refresh",
            label_override="CUSTOM/Label",
        )
        assert config.label_override == "CUSTOM/Label"

    def test_config_with_custom_max_results(self):
        config = GmailConnectorConfig(
            tenant_name="Acme",
            gmail_client_id="id",
            gmail_client_secret="secret",
            gmail_refresh_token="refresh",
            max_results_per_page=100,
        )
        assert config.max_results_per_page == 100

    def test_config_max_results_upper_bound(self):
        with pytest.raises(Exception):
            GmailConnectorConfig(
                tenant_name="Acme",
                gmail_client_id="id",
                gmail_client_secret="secret",
                gmail_refresh_token="refresh",
                max_results_per_page=501,
            )

    def test_config_max_results_lower_bound(self):
        with pytest.raises(Exception):
            GmailConnectorConfig(
                tenant_name="Acme",
                gmail_client_id="id",
                gmail_client_secret="secret",
                gmail_refresh_token="refresh",
                max_results_per_page=0,
            )

    def test_missing_required_field(self):
        with pytest.raises(Exception):
            GmailConnectorConfig(
                tenant_name="Acme",
                gmail_client_id="id",
                # missing gmail_client_secret and gmail_refresh_token
            )

    def test_uppercase_aliases_match_lowercase(self):
        config = GmailConnectorConfig(
            tenant_name="Test",
            gmail_client_id="cid",
            gmail_client_secret="csec",
            gmail_refresh_token="rtok",
        )
        assert config.TENANT_NAME == config.tenant_name
        assert config.GMAIL_CLIENT_ID == config.gmail_client_id
        assert config.GMAIL_CLIENT_SECRET == config.gmail_client_secret
        assert config.GMAIL_REFRESH_TOKEN == config.gmail_refresh_token

    # ── sender_whitelist field tests ─────────────────────────────────────

    def _base_kwargs(self):
        return dict(
            tenant_name="Acme",
            gmail_client_id="id",
            gmail_client_secret="secret",
            gmail_refresh_token="refresh",
        )

    def test_sender_whitelist_default_none(self):
        config = GmailConnectorConfig(**self._base_kwargs())
        assert config.sender_whitelist is None

    def test_sender_whitelist_domain_wildcards(self):
        # (a) Valid domain-wildcard list
        config = GmailConnectorConfig(
            **self._base_kwargs(),
            sender_whitelist=["@a.com", "@b.com"],
        )
        assert config.sender_whitelist == ["@a.com", "@b.com"]

    def test_sender_whitelist_exact_addresses(self):
        # (b) Valid exact-address list
        config = GmailConnectorConfig(
            **self._base_kwargs(),
            sender_whitelist=["alice@a.com", "bob@b.com"],
        )
        assert config.sender_whitelist == ["alice@a.com", "bob@b.com"]

    def test_sender_whitelist_mixed(self):
        # (c) Mixed list
        config = GmailConnectorConfig(
            **self._base_kwargs(),
            sender_whitelist=["@a.com", "bob@b.com"],
        )
        assert config.sender_whitelist == ["@a.com", "bob@b.com"]

    def test_sender_whitelist_empty_list_preserved(self):
        # (e) [] preserved at config layer (handler normalizes to None)
        config = GmailConnectorConfig(
            **self._base_kwargs(),
            sender_whitelist=[],
        )
        assert config.sender_whitelist == []

    def test_sender_whitelist_whitespace_and_case_normalization(self):
        # (f) Whitespace stripped AND lowercased
        config = GmailConnectorConfig(
            **self._base_kwargs(),
            sender_whitelist=[" @Domain.com "],
        )
        assert config.sender_whitelist == ["@domain.com"]

    def test_sender_whitelist_missing_at_raises(self):
        # (g) Entry missing '@' raises with offending entry quoted
        with pytest.raises(ValidationError) as excinfo:
            GmailConnectorConfig(
                **self._base_kwargs(),
                sender_whitelist=["plaintext"],
            )
        assert "'plaintext'" in str(excinfo.value)

    def test_sender_whitelist_empty_string_entry_raises(self):
        # (h) Empty-string / whitespace-only entry raises, offending entry quoted
        with pytest.raises(ValidationError) as excinfo:
            GmailConnectorConfig(
                **self._base_kwargs(),
                sender_whitelist=["@ok.com", "   "],
            )
        assert "'   '" in str(excinfo.value)

    def test_sender_whitelist_non_string_entry_raises(self):
        # (i) Non-string entry raises — Pydantic rejects None/int at core
        # coercion before our validator runs, so we only assert the field
        # name here. The type-name guarantee from `_validate_sender_whitelist_entries`
        # is pinned separately in TestHandlerInterface.test_legacy_settings_... (AC 20).
        with pytest.raises(ValidationError) as excinfo:
            GmailConnectorConfig(
                **self._base_kwargs(),
                sender_whitelist=[None],
            )
        err = str(excinfo.value)
        assert "sender_whitelist" in err

        with pytest.raises(ValidationError) as excinfo2:
            GmailConnectorConfig(
                **self._base_kwargs(),
                sender_whitelist=[123],
            )
        err2 = str(excinfo2.value)
        assert "sender_whitelist" in err2

    def test_sender_whitelist_bare_at_rejected(self):
        """F2: a bare '@' must not pass validation."""
        with pytest.raises(ValidationError) as excinfo:
            GmailConnectorConfig(
                **self._base_kwargs(),
                sender_whitelist=["@"],
            )
        assert "'@'" in str(excinfo.value)

    def test_sender_whitelist_user_at_no_domain_rejected(self):
        """F2: 'user@' with empty domain must not pass."""
        with pytest.raises(ValidationError) as excinfo:
            GmailConnectorConfig(
                **self._base_kwargs(),
                sender_whitelist=["user@"],
            )
        assert "'user@'" in str(excinfo.value)

    def test_sender_whitelist_localhost_rejected(self):
        """F2: domain without a dot must not pass."""
        with pytest.raises(ValidationError) as excinfo:
            GmailConnectorConfig(
                **self._base_kwargs(),
                sender_whitelist=["@localhost"],
            )
        assert "'@localhost'" in str(excinfo.value)

    def test_sender_whitelist_multiple_at_rejected(self):
        """F2: entries with more than one '@' must not pass."""
        with pytest.raises(ValidationError) as excinfo:
            GmailConnectorConfig(
                **self._base_kwargs(),
                sender_whitelist=["a@b@c.com"],
            )
        assert "'a@b@c.com'" in str(excinfo.value)

    def test_sender_whitelist_internal_whitespace_rejected(self):
        """F3: entries containing whitespace (e.g. embedded 'OR') must not pass."""
        with pytest.raises(ValidationError) as excinfo:
            GmailConnectorConfig(
                **self._base_kwargs(),
                sender_whitelist=["@a.com OR @b.com"],
            )
        err = str(excinfo.value)
        assert "'@a.com OR @b.com'" in err
        assert "whitespace" in err

    def test_sender_whitelist_non_ascii_rejected(self):
        """F7: IDN / non-ASCII must not silently pass — operators pre-encode as Punycode."""
        with pytest.raises(ValidationError) as excinfo:
            GmailConnectorConfig(
                **self._base_kwargs(),
                sender_whitelist=["@müller.de"],
            )
        err = str(excinfo.value)
        assert "'@müller.de'" in err
        assert "ASCII" in err
        assert "Punycode" in err

    def test_sender_whitelist_duplicates_preserved(self):
        """F5: duplicates are intentionally preserved (tech decision #10)."""
        config = GmailConnectorConfig(
            **self._base_kwargs(),
            sender_whitelist=["@a.com", "@a.com"],
        )
        assert config.sender_whitelist == ["@a.com", "@a.com"]

    def test_sender_whitelist_model_validate_normalizes(self):
        # (j) model_validate path triggers the same validator + normalization
        config = GmailConnectorConfig.model_validate({
            "tenant_name": "Acme",
            "gmail_client_id": "id",
            "gmail_client_secret": "s",
            "gmail_refresh_token": "t",
            "sender_whitelist": [" @Domain.com "],
        })
        assert config.sender_whitelist == ["@domain.com"]


# ── Handler interface conformance ────────────────────────────────────────


class TestHandlerInterface:
    """Verify the handler conforms to the RetrievalHandler interface."""

    def _make_config(self, **overrides):
        defaults = dict(
            tenant_name="TestTenant",
            gmail_client_id="id",
            gmail_client_secret="secret",
            gmail_refresh_token="refresh",
        )
        defaults.update(overrides)
        return GmailConnectorConfig(**defaults)

    def test_extends_retrieval_handler(self):
        assert issubclass(EntrMailboxRetrievalHandler, RetrievalHandler)

    def test_instantiation_with_config(self):
        config = self._make_config()
        handler = EntrMailboxRetrievalHandler(config)
        assert handler.settings is config

    def test_instantiation_with_legacy_settings(self):
        settings = SimpleNamespace(
            TENANT_NAME="Legacy",
            GMAIL_CLIENT_ID="id",
            GMAIL_CLIENT_SECRET="secret",
            GMAIL_REFRESH_TOKEN="refresh",
        )
        handler = EntrMailboxRetrievalHandler(settings)
        assert handler.settings.TENANT_NAME == "Legacy"

    def test_label_override_from_config(self):
        config = self._make_config(label_override="CUSTOM/Label")
        handler = EntrMailboxRetrievalHandler(config)
        assert handler._build_label_name() == "CUSTOM/Label"

    def test_label_override_from_constructor(self):
        config = self._make_config()
        handler = EntrMailboxRetrievalHandler(config, label_override="ARG/Label")
        # Config has no label_override, so constructor arg is used
        assert handler._build_label_name() == "ARG/Label"

    def test_config_label_override_takes_precedence(self):
        config = self._make_config(label_override="CONFIG/Label")
        handler = EntrMailboxRetrievalHandler(config, label_override="ARG/Label")
        # Config label_override should win
        assert handler._build_label_name() == "CONFIG/Label"

    def test_default_label_from_tenant_name(self):
        config = self._make_config(tenant_name="Acme")
        handler = EntrMailboxRetrievalHandler(config)
        assert handler._build_label_name() == "TENANT/Acme"

    def test_has_list_documents_method(self):
        assert callable(getattr(EntrMailboxRetrievalHandler, "list_documents", None))

    def test_has_get_document_method(self):
        assert callable(getattr(EntrMailboxRetrievalHandler, "get_document", None))

    def test_no_hardcoded_credentials(self):
        """Verify the handler has no hardcoded tenant credentials in source."""
        import inspect

        source = inspect.getsource(EntrMailboxRetrievalHandler)
        # Should not contain any hardcoded API keys or tokens
        assert "AKIA" not in source  # AWS key prefix
        assert "1//0" not in source  # Google refresh token prefix
        # Note: .apps.googleusercontent.com appears in docstring examples, not as credentials

    # ── sender_whitelist precedence / construction tests ───────────────

    def test_sender_whitelist_from_config(self):
        # (a) Whitelist from config → handler stores config value
        config = self._make_config(sender_whitelist=["@config.com"])
        handler = EntrMailboxRetrievalHandler(config)
        assert handler._sender_whitelist == ["@config.com"]

    def test_sender_whitelist_from_constructor_arg(self):
        # (b) Config has no whitelist → constructor arg is used
        config = self._make_config()
        handler = EntrMailboxRetrievalHandler(config, sender_whitelist=["@arg.com"])
        assert handler._sender_whitelist == ["@arg.com"]

    def test_config_sender_whitelist_takes_precedence(self):
        # (c) Both set → config wins
        config = self._make_config(sender_whitelist=["@config.com"])
        handler = EntrMailboxRetrievalHandler(config, sender_whitelist=["@arg.com"])
        assert handler._sender_whitelist == ["@config.com"]

    def test_config_empty_whitelist_falls_through_to_constructor_arg(self):
        # (d) Config whitelist=[] (falsy) → constructor arg used
        config = self._make_config(sender_whitelist=[])
        handler = EntrMailboxRetrievalHandler(config, sender_whitelist=["@arg.com"])
        assert handler._sender_whitelist == ["@arg.com"]

    def test_sender_whitelist_empty_list_normalized_to_none(self):
        # (e) constructor sender_whitelist=[] → stored as None
        config = self._make_config()
        handler = EntrMailboxRetrievalHandler(config, sender_whitelist=[])
        assert handler._sender_whitelist is None

    def test_legacy_settings_constructor_whitelist_lowercased(self):
        # (f) SimpleNamespace settings + valid constructor arg → lowercased
        settings = SimpleNamespace(
            TENANT_NAME="Legacy",
            GMAIL_CLIENT_ID="id",
            GMAIL_CLIENT_SECRET="secret",
            GMAIL_REFRESH_TOKEN="refresh",
        )
        handler = EntrMailboxRetrievalHandler(settings, sender_whitelist=["@Dom.com"])
        assert handler._sender_whitelist == ["@dom.com"]

    def test_legacy_settings_constructor_malformed_whitelist_raises(self):
        """AC 20 — legacy path exercises the custom helper, which must surface
        the offending entry and its type name in the error message.
        """
        settings = SimpleNamespace(
            TENANT_NAME="Legacy",
            GMAIL_CLIENT_ID="id",
            GMAIL_CLIENT_SECRET="secret",
            GMAIL_REFRESH_TOKEN="refresh",
        )
        with pytest.raises(ValueError, match="'plaintext'"):
            EntrMailboxRetrievalHandler(settings, sender_whitelist=["plaintext"])

        # F4: pin the type-name guarantee — `NoneType` must be in the message.
        with pytest.raises(ValueError) as excinfo:
            EntrMailboxRetrievalHandler(settings, sender_whitelist=[None])
        err = str(excinfo.value)
        assert "None" in err
        assert "NoneType" in err

        # And the int case: value AND type name surfaced.
        with pytest.raises(ValueError) as excinfo_int:
            EntrMailboxRetrievalHandler(settings, sender_whitelist=[123])
        err_int = str(excinfo_int.value)
        assert "123" in err_int
        assert "int" in err_int

        # F3 — whitespace rejection surfaces the offending entry.
        with pytest.raises(ValueError, match="whitespace"):
            EntrMailboxRetrievalHandler(
                settings, sender_whitelist=["@a.com OR @b.com"]
            )

    def test_config_whitelist_mutation_does_not_leak_into_handler(self):
        """F1: handler must hold its own list — mutating the config's list
        after construction must not change the handler's composed query.
        """
        config = self._make_config(sender_whitelist=["@a.com", "@b.com"])
        handler = EntrMailboxRetrievalHandler(config)
        # Mutate the config's list after the handler is built.
        config.sender_whitelist.append("@rogue.com")
        # Handler should be unaffected.
        assert handler._sender_whitelist == ["@a.com", "@b.com"]

    def test_sender_whitelist_is_keyword_only(self):
        # (h) Positional misuse must raise TypeError
        config = self._make_config()
        with pytest.raises(TypeError):
            EntrMailboxRetrievalHandler(config, "TENANT/Label", ["@dom.com"])

    def test_init_logs_whitelist_count_not_pii(self, caplog):
        """AC 13: init log emits pattern count, not the addresses themselves."""
        caplog.set_level(logging.INFO, logger="entr_adapter_core.connectors.gmail")
        config = self._make_config(sender_whitelist=["ceo@example.com"])
        with caplog.at_level(logging.INFO, logger="entr_adapter_core.connectors.gmail"):
            EntrMailboxRetrievalHandler(config)
        # Find the init record (the last INFO for the connector logger)
        init_msgs = [r.getMessage() for r in caplog.records
                     if r.name == "entr_adapter_core.connectors.gmail"]
        assert any("whitelist: 1 pattern" in m for m in init_msgs)
        assert all("ceo@example.com" not in m for m in init_msgs)


# ── Mocked HTTP tests ───────────────────────────────────────────────────


def _make_handler(**overrides):
    defaults = dict(
        tenant_name="TestTenant",
        gmail_client_id="id",
        gmail_client_secret="secret",
        gmail_refresh_token="refresh",
    )
    defaults.update(overrides)
    config = GmailConnectorConfig(**defaults)
    return EntrMailboxRetrievalHandler(config)


class TestListDocuments:
    """Test list_documents with mocked Gmail API responses."""

    @pytest.mark.asyncio
    async def test_list_documents_returns_messages(self):
        handler = _make_handler()

        # Mock token response
        token_resp = httpx.Response(200, json={"access_token": "tok123"})
        # Mock labels response
        labels_resp = httpx.Response(200, json={
            "labels": [{"id": "Label_1", "name": "TENANT/TestTenant"}]
        })
        # Mock messages response
        messages_resp = httpx.Response(200, json={
            "messages": [
                {"id": "msg-1", "threadId": "t1"},
                {"id": "msg-2", "threadId": "t2"},
            ]
        })

        with patch("entr_adapter_core.connectors.gmail.httpx.AsyncClient") as mock_cls:
            mock_client = AsyncMock()
            mock_cls.return_value.__aenter__ = AsyncMock(return_value=mock_client)
            mock_cls.return_value.__aexit__ = AsyncMock(return_value=False)

            mock_client.post.return_value = token_resp
            mock_client.get.side_effect = [labels_resp, messages_resp]

            payload = RetrievalPayload(source_identifier="gmail", date_from=date(2026, 1, 1))
            response = await handler.list_documents(payload)

        assert response.status.value == "success"
        assert len(response.documents) == 2
        assert response.documents[0].document_identifier == "msg-1"
        assert response.documents[0].filename == "msg-1.eml"
        assert response.documents[1].document_identifier == "msg-2"

    @pytest.mark.asyncio
    async def test_list_documents_empty_inbox(self):
        handler = _make_handler()

        token_resp = httpx.Response(200, json={"access_token": "tok"})
        labels_resp = httpx.Response(200, json={
            "labels": [{"id": "Label_1", "name": "TENANT/TestTenant"}]
        })
        messages_resp = httpx.Response(200, json={})

        with patch("entr_adapter_core.connectors.gmail.httpx.AsyncClient") as mock_cls:
            mock_client = AsyncMock()
            mock_cls.return_value.__aenter__ = AsyncMock(return_value=mock_client)
            mock_cls.return_value.__aexit__ = AsyncMock(return_value=False)

            mock_client.post.return_value = token_resp
            mock_client.get.side_effect = [labels_resp, messages_resp]

            payload = RetrievalPayload(source_identifier="gmail", date_from=date(2026, 1, 1))
            response = await handler.list_documents(payload)

        assert response.status.value == "success"
        assert len(response.documents) == 0

    @pytest.mark.asyncio
    async def test_list_documents_label_not_found(self):
        handler = _make_handler()

        token_resp = httpx.Response(200, json={"access_token": "tok"})
        labels_resp = httpx.Response(200, json={
            "labels": [{"id": "Label_1", "name": "TENANT/OtherTenant"}]
        })

        with patch("entr_adapter_core.connectors.gmail.httpx.AsyncClient") as mock_cls:
            mock_client = AsyncMock()
            mock_cls.return_value.__aenter__ = AsyncMock(return_value=mock_client)
            mock_cls.return_value.__aexit__ = AsyncMock(return_value=False)

            mock_client.post.return_value = token_resp
            mock_client.get.return_value = labels_resp

            payload = RetrievalPayload(source_identifier="gmail", date_from=date(2026, 1, 1))
            with pytest.raises(RuntimeError, match="not found"):
                await handler.list_documents(payload)

    @pytest.mark.asyncio
    async def test_list_documents_token_refresh_failure(self):
        handler = _make_handler()

        token_resp = httpx.Response(401, json={"error": "invalid_grant"})

        with patch("entr_adapter_core.connectors.gmail.httpx.AsyncClient") as mock_cls:
            mock_client = AsyncMock()
            mock_cls.return_value.__aenter__ = AsyncMock(return_value=mock_client)
            mock_cls.return_value.__aexit__ = AsyncMock(return_value=False)

            mock_client.post.return_value = token_resp

            payload = RetrievalPayload(source_identifier="gmail", date_from=date(2026, 1, 1))
            with pytest.raises(RuntimeError, match="OAuth token refresh failed"):
                await handler.list_documents(payload)


class TestGetDocument:
    """Test get_document with mocked Gmail API responses."""

    @pytest.mark.asyncio
    async def test_get_document_returns_eml(self):
        handler = _make_handler()

        # Raw RFC822 content, base64url-encoded (Gmail format)
        import base64
        raw_email = b"From: test@example.com\r\nSubject: Test\r\n\r\nHello"
        b64url = base64.urlsafe_b64encode(raw_email).decode().rstrip("=")

        token_resp = httpx.Response(200, json={"access_token": "tok"})
        message_resp = httpx.Response(200, json={"raw": b64url})

        with patch("entr_adapter_core.connectors.gmail.httpx.AsyncClient") as mock_cls:
            mock_client = AsyncMock()
            mock_cls.return_value.__aenter__ = AsyncMock(return_value=mock_client)
            mock_cls.return_value.__aexit__ = AsyncMock(return_value=False)

            mock_client.post.return_value = token_resp
            mock_client.get.return_value = message_resp

            response = await handler.get_document("msg-123")

        assert response.document_identifier == "msg-123.eml"
        assert response.adapter_document_id == "msg-123"
        # Verify the content decodes back to the original email
        decoded = base64.b64decode(response.content_b64)
        assert decoded == raw_email

    @pytest.mark.asyncio
    async def test_get_document_missing_raw_content(self):
        handler = _make_handler()

        token_resp = httpx.Response(200, json={"access_token": "tok"})
        message_resp = httpx.Response(200, json={})  # No "raw" field

        with patch("entr_adapter_core.connectors.gmail.httpx.AsyncClient") as mock_cls:
            mock_client = AsyncMock()
            mock_cls.return_value.__aenter__ = AsyncMock(return_value=mock_client)
            mock_cls.return_value.__aexit__ = AsyncMock(return_value=False)

            mock_client.post.return_value = token_resp
            mock_client.get.return_value = message_resp

            with pytest.raises(RuntimeError, match="No raw content"):
                await handler.get_document("msg-bad")


# ── Pagination test ──────────────────────────────────────────────────────


class TestPagination:
    """Test that list_documents handles multi-page Gmail responses."""

    @pytest.mark.asyncio
    async def test_list_documents_handles_pagination(self):
        handler = _make_handler()

        token_resp = httpx.Response(200, json={"access_token": "tok"})
        labels_resp = httpx.Response(200, json={
            "labels": [{"id": "L1", "name": "TENANT/TestTenant"}]
        })
        # Page 1 with nextPageToken
        page1_resp = httpx.Response(200, json={
            "messages": [{"id": "msg-1", "threadId": "t1"}],
            "nextPageToken": "page2token",
        })
        # Page 2 without nextPageToken (last page)
        page2_resp = httpx.Response(200, json={
            "messages": [{"id": "msg-2", "threadId": "t2"}],
        })

        with patch("entr_adapter_core.connectors.gmail.httpx.AsyncClient") as mock_cls:
            mock_client = AsyncMock()
            mock_cls.return_value.__aenter__ = AsyncMock(return_value=mock_client)
            mock_cls.return_value.__aexit__ = AsyncMock(return_value=False)

            mock_client.post.return_value = token_resp
            mock_client.get.side_effect = [labels_resp, page1_resp, page2_resp]

            payload = RetrievalPayload(source_identifier="gmail", date_from=date(2026, 1, 1))
            response = await handler.list_documents(payload)

        assert len(response.documents) == 2
        assert response.documents[0].document_identifier == "msg-1"
        assert response.documents[1].document_identifier == "msg-2"


# ── Sender whitelist query composition tests ────────────────────────────


class TestSenderWhitelistQueryComposition:
    """Verify sender_whitelist produces the exact Gmail q= clause expected."""

    def _setup_mock(self, mock_cls, token_resp, get_side_effect):
        mock_client = AsyncMock()
        mock_cls.return_value.__aenter__ = AsyncMock(return_value=mock_client)
        mock_cls.return_value.__aexit__ = AsyncMock(return_value=False)
        mock_client.post.return_value = token_resp
        mock_client.get.side_effect = get_side_effect
        return mock_client

    @pytest.mark.asyncio
    async def test_whitelist_only_no_date(self):
        """(a) Whitelist only, no date_from → q = (from:@a.com OR from:@b.com).

        Calls the internal `_list_messages_for_label` directly because the
        public `RetrievalPayload` schema requires a `date_from`.
        """
        handler = _make_handler(sender_whitelist=["@a.com", "@b.com"])

        mock_client = AsyncMock()
        mock_client.get.side_effect = [httpx.Response(200, json={"messages": []})]

        await handler._list_messages_for_label(
            mock_client, "tok", "L1", date_from=None
        )

        q = _extract_q(mock_client.get.call_args_list[0])
        assert q == "(from:@a.com OR from:@b.com)"

    @pytest.mark.asyncio
    async def test_whitelist_plus_date(self):
        """(b) Whitelist + date → exact composed q string, date first."""
        handler = _make_handler(sender_whitelist=["@a.com", "@b.com"])

        token_resp = httpx.Response(200, json={"access_token": "tok"})
        labels_resp = httpx.Response(200, json={
            "labels": [{"id": "L1", "name": "TENANT/TestTenant"}]
        })
        messages_resp = httpx.Response(200, json={"messages": []})

        with patch("entr_adapter_core.connectors.gmail.httpx.AsyncClient") as mock_cls:
            mock_client = self._setup_mock(
                mock_cls, token_resp, [labels_resp, messages_resp]
            )
            payload = RetrievalPayload(
                source_identifier="gmail", date_from=date(2026, 1, 1)
            )
            await handler.list_documents(payload)

        q = _extract_q(mock_client.get.call_args_list[1])
        assert q == "after:2026/01/01 (from:@a.com OR from:@b.com)"

    @pytest.mark.asyncio
    async def test_single_pattern_no_parens(self):
        """(c) Single-pattern whitelist → bare from:pattern, no parens."""
        handler = _make_handler(sender_whitelist=["@one.com"])

        mock_client = AsyncMock()
        mock_client.get.side_effect = [httpx.Response(200, json={"messages": []})]

        await handler._list_messages_for_label(
            mock_client, "tok", "L1", date_from=None
        )

        q = _extract_q(mock_client.get.call_args_list[0])
        assert q == "from:@one.com"

    @pytest.mark.asyncio
    async def test_no_whitelist_no_date_no_q(self):
        """(d) No whitelist, no date → URL must contain no q= substring."""
        handler = _make_handler()  # no whitelist

        mock_client = AsyncMock()
        mock_client.get.side_effect = [httpx.Response(200, json={"messages": []})]

        await handler._list_messages_for_label(
            mock_client, "tok", "L1", date_from=None
        )

        url = _extract_url(mock_client.get.call_args_list[0])
        assert "q=" not in url

    @pytest.mark.asyncio
    async def test_whitelist_plus_date_via_public_api(self):
        """(b2) Whitelist + date via public list_documents call."""
        handler = _make_handler(sender_whitelist=["@a.com", "@b.com"])

        token_resp = httpx.Response(200, json={"access_token": "tok"})
        labels_resp = httpx.Response(200, json={
            "labels": [{"id": "L1", "name": "TENANT/TestTenant"}]
        })
        messages_resp = httpx.Response(200, json={"messages": []})

        with patch("entr_adapter_core.connectors.gmail.httpx.AsyncClient") as mock_cls:
            mock_client = self._setup_mock(
                mock_cls, token_resp, [labels_resp, messages_resp]
            )
            payload = RetrievalPayload(
                source_identifier="gmail", date_from=date(2026, 1, 1)
            )
            await handler.list_documents(payload)

        q = _extract_q(mock_client.get.call_args_list[1])
        assert q == "after:2026/01/01 (from:@a.com OR from:@b.com)"

    @pytest.mark.asyncio
    async def test_pagination_preserves_q_and_logs_once(self, caplog):
        """(e) AC 12: page 2 inherits same q=; log emitted exactly once."""
        caplog.set_level(logging.INFO, logger="entr_adapter_core.connectors.gmail")
        handler = _make_handler(sender_whitelist=["@dom.com"])

        token_resp = httpx.Response(200, json={"access_token": "tok"})
        labels_resp = httpx.Response(200, json={
            "labels": [{"id": "L1", "name": "TENANT/TestTenant"}]
        })
        page1 = httpx.Response(200, json={
            "messages": [{"id": "m1"}],
            "nextPageToken": "p2",
        })
        page2 = httpx.Response(200, json={"messages": [{"id": "m2"}]})

        with patch("entr_adapter_core.connectors.gmail.httpx.AsyncClient") as mock_cls:
            mock_client = self._setup_mock(
                mock_cls, token_resp, [labels_resp, page1, page2]
            )
            with caplog.at_level(logging.INFO, logger="entr_adapter_core.connectors.gmail"):
                payload = RetrievalPayload(
                    source_identifier="gmail", date_from=date(2026, 1, 1)
                )
                await handler.list_documents(payload)

        page2_q = _extract_q(mock_client.get.call_args_list[2])
        # q must carry both the date clause and the whitelist clause
        assert "from:@dom.com" in page2_q
        # Page 1 and page 2 should have the same q= value
        page1_q = _extract_q(mock_client.get.call_args_list[1])
        assert page1_q == page2_q

        filter_records = [
            r for r in caplog.records
            if r.getMessage().startswith("Gmail query filter:")
        ]
        assert len(filter_records) == 1

    @pytest.mark.asyncio
    async def test_whitelist_with_zero_matches_happy_path(self):
        """(f) AC 19: whitelist set + Gmail returns {} → SUCCESS with empty docs."""
        handler = _make_handler(sender_whitelist=["@nomatch.com"])

        token_resp = httpx.Response(200, json={"access_token": "tok"})
        labels_resp = httpx.Response(200, json={
            "labels": [{"id": "L1", "name": "TENANT/TestTenant"}]
        })
        messages_resp = httpx.Response(200, json={})  # no messages key, empty body

        with patch("entr_adapter_core.connectors.gmail.httpx.AsyncClient") as mock_cls:
            mock_client = self._setup_mock(
                mock_cls, token_resp, [labels_resp, messages_resp]
            )
            payload = RetrievalPayload(
                source_identifier="gmail", date_from=date(2026, 1, 1)
            )
            response = await handler.list_documents(payload)

        assert response.status.value == "success"
        assert response.documents == []

        q = _extract_q(mock_client.get.call_args_list[1])
        assert q is not None and "from:@nomatch.com" in q

    @pytest.mark.asyncio
    async def test_large_whitelist_composes_well_formed_query(self):
        """F6: 100-pattern whitelist must produce a well-formed q= clause."""
        whitelist = [f"@dom{i}.example.com" for i in range(100)]
        handler = _make_handler(sender_whitelist=whitelist)

        mock_client = AsyncMock()
        mock_client.get.side_effect = [httpx.Response(200, json={"messages": []})]

        await handler._list_messages_for_label(
            mock_client, "tok", "L1", date_from=None
        )

        q = _extract_q(mock_client.get.call_args_list[0])
        # Outer parens present, no trailing OR, all 100 patterns included.
        assert q.startswith("(from:@dom0.example.com OR ")
        assert q.endswith(" OR from:@dom99.example.com)")
        # Exactly 99 " OR " separators for 100 patterns.
        assert q.count(" OR ") == 99
        # No double-spaces, no malformed operator joins.
        assert "  " not in q
        assert "OR OR" not in q

    @pytest.mark.asyncio
    async def test_duplicate_whitelist_entries_preserved_in_query(self):
        """F5: duplicates must flow through to the composed query unchanged."""
        handler = _make_handler(sender_whitelist=["@a.com", "@a.com"])

        mock_client = AsyncMock()
        mock_client.get.side_effect = [httpx.Response(200, json={"messages": []})]

        await handler._list_messages_for_label(
            mock_client, "tok", "L1", date_from=None
        )

        q = _extract_q(mock_client.get.call_args_list[0])
        assert q == "(from:@a.com OR from:@a.com)"

    @pytest.mark.asyncio
    async def test_http_400_diagnostic(self, caplog):
        """(g) AC 16: HTTP 400 → RuntimeError with status, ERROR log with query."""
        caplog.set_level(logging.ERROR, logger="entr_adapter_core.connectors.gmail")
        handler = _make_handler(sender_whitelist=["@dom.com"])

        token_resp = httpx.Response(200, json={"access_token": "tok"})
        labels_resp = httpx.Response(200, json={
            "labels": [{"id": "L1", "name": "TENANT/TestTenant"}]
        })
        bad_resp = httpx.Response(400, text="Invalid query")

        with patch("entr_adapter_core.connectors.gmail.httpx.AsyncClient") as mock_cls:
            self._setup_mock(mock_cls, token_resp, [labels_resp, bad_resp])
            with caplog.at_level(logging.ERROR, logger="entr_adapter_core.connectors.gmail"):
                payload = RetrievalPayload(
                    source_identifier="gmail", date_from=date(2026, 1, 1)
                )
                with pytest.raises(RuntimeError, match="status=400"):
                    await handler.list_documents(payload)

        error_records = [
            r for r in caplog.records
            if r.levelno == logging.ERROR
            and "Failed to list messages" in r.getMessage()
        ]
        assert error_records, "expected ERROR log for failed list"
        err_msg = error_records[0].getMessage()
        assert "400" in err_msg
        assert "@dom.com" in err_msg
