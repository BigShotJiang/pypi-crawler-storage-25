"""Tests for the BusinessCalendar utility.

Covers:
- ``is_holiday`` — official calendar lookups, exclusions, extras, predicates
- ``is_business_day`` — composite weekend + holiday check
- ``next_business_day`` — inclusive vs exclusive shifting
- ``add_business_days`` — lead-time arithmetic (start counts as day 1)
- Date / datetime input handling
- Per-year caching across year boundaries
- Validation / error messages
"""

from datetime import date, datetime

import pytest

from entr_adapter_core.utils.business_calendar import BusinessCalendar


# ── Fixed reference dates (NL public holidays in 2026) ──────────────────
#
# 2026-01-01  Thu  New Year's Day
# 2026-04-03  Fri  Good Friday  (returned by `holidays` lib for NL)
# 2026-04-06  Mon  Easter Monday
# 2026-04-27  Mon  King's Day
# 2026-05-05  Tue  Liberation Day  (non-lustrum year — see lustrum test)
# 2026-05-14  Thu  Ascension Day
# 2026-05-25  Mon  Whit Monday
# 2026-12-25  Fri  Christmas Day
# 2026-12-26  Sat  Second Day of Christmas


class TestIsHoliday:
    def test_known_nl_holiday(self):
        cal = BusinessCalendar(country="NL")
        assert cal.is_holiday(date(2026, 4, 6)) is True   # Easter Monday
        assert cal.is_holiday(date(2026, 12, 25)) is True  # Christmas

    def test_normal_weekday_is_not_holiday(self):
        cal = BusinessCalendar(country="NL")
        assert cal.is_holiday(date(2026, 4, 7)) is False  # Tuesday after Easter

    def test_weekend_is_not_a_holiday(self):
        # Saturdays/Sundays aren't holidays — they're just weekends.
        cal = BusinessCalendar(country="NL")
        assert cal.is_holiday(date(2026, 4, 4)) is False  # Saturday

    def test_exclude_names_drops_holiday(self):
        cal = BusinessCalendar(country="NL", exclude_names={"Good Friday"})
        assert cal.is_holiday(date(2026, 4, 3)) is False  # Good Friday excluded
        assert cal.is_holiday(date(2026, 4, 6)) is True   # Easter Monday still holiday

    def test_extra_holidays_are_added(self):
        company_closure = date(2026, 12, 31)
        cal = BusinessCalendar(country="NL", extra_holidays={company_closure})
        assert cal.is_holiday(company_closure) is True

    def test_extra_holidays_only_apply_within_year(self):
        # extra_holidays in a year other than the one queried must not bleed in.
        cal = BusinessCalendar(
            country="NL", extra_holidays={date(2027, 3, 15)}
        )
        # Querying 2026 must not see the 2027 extra.
        assert cal.is_holiday(date(2026, 3, 15)) is False

    def test_exclude_predicate_lustrum_logic(self):
        # NL Liberation Day: only counts as a public holiday in lustrum years.
        # 2026 is not a lustrum year (2025 and 2030 are).
        cal = BusinessCalendar(
            country="NL",
            exclude_predicate=lambda d, name: (
                "Liberation" in name and d.year % 5 != 0
            ),
        )
        assert cal.is_holiday(date(2026, 5, 5)) is False
        assert cal.is_holiday(date(2025, 5, 5)) is True

    def test_accepts_datetime_input(self):
        cal = BusinessCalendar(country="NL")
        assert cal.is_holiday(datetime(2026, 4, 6, 14, 30)) is True


class TestIsBusinessDay:
    def test_normal_weekday(self):
        cal = BusinessCalendar(country="NL")
        assert cal.is_business_day(date(2026, 4, 7)) is True  # Tuesday

    def test_saturday_is_not_business_day(self):
        cal = BusinessCalendar(country="NL")
        assert cal.is_business_day(date(2026, 4, 4)) is False  # Saturday

    def test_sunday_is_not_business_day(self):
        cal = BusinessCalendar(country="NL")
        assert cal.is_business_day(date(2026, 4, 5)) is False  # Sunday

    def test_holiday_is_not_business_day(self):
        cal = BusinessCalendar(country="NL")
        assert cal.is_business_day(date(2026, 4, 6)) is False  # Easter Monday

    def test_excluded_holiday_becomes_business_day(self):
        cal = BusinessCalendar(country="NL", exclude_names={"Good Friday"})
        assert cal.is_business_day(date(2026, 4, 3)) is True

    def test_custom_weekend_days(self):
        # Some markets use Friday/Saturday weekends.
        cal = BusinessCalendar(country="NL", weekend_days=(4, 5))
        # 2026-04-09 is a Thursday — should be business day with these settings.
        assert cal.is_business_day(date(2026, 4, 9)) is True
        # Friday 2026-04-10 is a normal Friday — now treated as weekend.
        assert cal.is_business_day(date(2026, 4, 10)) is False


class TestNextBusinessDay:
    def test_inclusive_returns_same_date_when_already_business_day(self):
        cal = BusinessCalendar(country="NL")
        d = date(2026, 4, 7)  # Tuesday
        assert cal.next_business_day(d) == d

    def test_shifts_off_weekend(self):
        cal = BusinessCalendar(country="NL")
        # Saturday 2026-04-04 → next BD must skip Sun (4-5) and Easter Mon (4-6).
        assert cal.next_business_day(date(2026, 4, 4)) == date(2026, 4, 7)

    def test_shifts_off_holiday(self):
        cal = BusinessCalendar(country="NL")
        # Easter Monday → Tuesday
        assert cal.next_business_day(date(2026, 4, 6)) == date(2026, 4, 7)

    def test_exclusive_advances_past_business_day(self):
        cal = BusinessCalendar(country="NL")
        # Tuesday with inclusive=False → next business day = Wednesday
        assert (
            cal.next_business_day(date(2026, 4, 7), inclusive=False)
            == date(2026, 4, 8)
        )

    def test_exclusive_skips_multi_day_holiday_block(self):
        # Easter weekend block: Good Friday (Apr 3) + Sat + Sun + Easter Mon
        # → exclusive starting from Thu Apr 2 must land on Tue Apr 7.
        cal = BusinessCalendar(country="NL")
        assert (
            cal.next_business_day(date(2026, 4, 2), inclusive=False)
            == date(2026, 4, 7)
        )

    def test_shifts_across_year_boundary(self):
        cal = BusinessCalendar(country="NL")
        # 2025-12-31 is Wed; 2026-01-01 is Thu (NYD); next BD = 2026-01-02 (Fri).
        assert (
            cal.next_business_day(date(2025, 12, 31), inclusive=False)
            == date(2026, 1, 2)
        )

    def test_accepts_datetime_input(self):
        cal = BusinessCalendar(country="NL")
        assert (
            cal.next_business_day(datetime(2026, 4, 4, 23, 59))
            == date(2026, 4, 7)
        )

    def test_no_weekends_configuration(self):
        # weekend_days=() → every weekday is a business day, only holidays skip.
        cal = BusinessCalendar(country="NL", weekend_days=())
        # Saturday 2026-04-04 is now a business day.
        assert cal.next_business_day(date(2026, 4, 4)) == date(2026, 4, 4)
        # But Easter Monday 2026-04-06 still shifts to Apr 7.
        assert cal.next_business_day(date(2026, 4, 6)) == date(2026, 4, 7)


class TestNextBusinessDayBackward:
    def test_inclusive_returns_same_date_when_already_business_day(self):
        cal = BusinessCalendar(country="NL")
        d = date(2026, 4, 7)  # Tuesday
        assert cal.next_business_day(d, direction=-1) == d

    def test_holiday_on_monday_shifts_to_friday(self):
        # Easter Monday 2026-04-06 → previous BD is Thursday 2026-04-02
        # (Good Friday Apr 3 + Sat Apr 4 + Sun Apr 5 are all non-business).
        cal = BusinessCalendar(country="NL")
        assert (
            cal.next_business_day(date(2026, 4, 6), direction=-1)
            == date(2026, 4, 2)
        )

    def test_kingsday_monday_shifts_to_previous_friday(self):
        # King's Day 2026-04-27 (Mon) → Fri 2026-04-24
        cal = BusinessCalendar(country="NL")
        assert (
            cal.next_business_day(date(2026, 4, 27), direction=-1)
            == date(2026, 4, 24)
        )

    def test_sunday_shifts_to_friday(self):
        cal = BusinessCalendar(country="NL")
        # Sunday 2026-04-12 → Fri 2026-04-10
        assert (
            cal.next_business_day(date(2026, 4, 12), direction=-1)
            == date(2026, 4, 10)
        )

    def test_exclusive_steps_back_at_least_one_day(self):
        cal = BusinessCalendar(country="NL")
        # Tue 2026-04-07 with inclusive=False, direction=-1 must step past
        # the Easter weekend block (Mon Apr 6 + Sun + Sat + Good Fri Apr 3)
        # to land on Thu 2026-04-02.
        assert (
            cal.next_business_day(
                date(2026, 4, 7), inclusive=False, direction=-1
            )
            == date(2026, 4, 2)
        )

    def test_shifts_across_year_boundary_backward(self):
        cal = BusinessCalendar(country="NL")
        # 2026-01-01 is Thu (NYD); previous BD = Wed 2025-12-31
        assert (
            cal.next_business_day(date(2026, 1, 1), direction=-1)
            == date(2025, 12, 31)
        )

    def test_invalid_direction_raises(self):
        cal = BusinessCalendar(country="NL")
        with pytest.raises(ValueError, match="direction"):
            cal.next_business_day(date(2026, 4, 7), direction=0)
        with pytest.raises(ValueError, match="direction"):
            cal.next_business_day(date(2026, 4, 7), direction=2)
        with pytest.raises(ValueError, match="direction"):
            cal.next_business_day(date(2026, 4, 7), direction=-2)


class TestAddBusinessDays:
    def test_start_counts_as_day_one(self):
        cal = BusinessCalendar(country="NL")
        monday = date(2026, 4, 13)  # plain Monday, no holiday
        assert cal.add_business_days(monday, 1) == monday

    def test_skips_weekends(self):
        cal = BusinessCalendar(country="NL")
        friday = date(2026, 4, 10)
        # Day 1: Fri 10, Day 2: Mon 13
        assert cal.add_business_days(friday, 2) == date(2026, 4, 13)

    def test_skips_holidays(self):
        # Thursday before Good Friday: Day 1 = Thu, Day 2 must skip
        # Good Friday + Easter weekend + Easter Monday → Tuesday.
        cal = BusinessCalendar(country="NL")
        thursday = date(2026, 4, 2)
        assert cal.add_business_days(thursday, 2) == date(2026, 4, 7)

    def test_seven_business_days_span_weekend(self):
        # Fri 5 June 2026 + 7 BD (start counts as day 1, no holidays in span)
        # → Mon 15 June 2026.
        cal = BusinessCalendar(country="NL")
        assert (
            cal.add_business_days(date(2026, 6, 5), 7) == date(2026, 6, 15)
        )

    def test_zero_or_negative_raises(self):
        cal = BusinessCalendar(country="NL")
        with pytest.raises(ValueError, match="business_days must be >= 1"):
            cal.add_business_days(date(2026, 4, 7), 0)
        with pytest.raises(ValueError, match="business_days must be >= 1"):
            cal.add_business_days(date(2026, 4, 7), -1)

    def test_accepts_datetime_input(self):
        cal = BusinessCalendar(country="NL")
        # Day 1: Mon Apr 13, Day 2: Tue Apr 14
        assert (
            cal.add_business_days(datetime(2026, 4, 13, 9, 0), 2)
            == date(2026, 4, 14)
        )

    def test_spans_year_boundary_with_holiday(self):
        # Day 1: Mon 2025-12-29
        # Day 2: Tue 2025-12-30
        # Day 3: Wed 2025-12-31
        # ----   2026-01-01 is Thu, NYD (NL holiday) — skip
        # Day 4: Fri 2026-01-02
        # Day 5: Mon 2026-01-05  (skip Sat 03 + Sun 04)
        cal = BusinessCalendar(country="NL")
        assert (
            cal.add_business_days(date(2025, 12, 29), 5) == date(2026, 1, 5)
        )


class TestCaching:
    def test_year_lookup_cached(self):
        # Hit the same year repeatedly to confirm cache stays consistent.
        cal = BusinessCalendar(country="NL")
        for _ in range(5):
            assert cal.is_holiday(date(2026, 4, 6)) is True
            assert cal.is_business_day(date(2026, 4, 7)) is True

    def test_cross_year_calls(self):
        cal = BusinessCalendar(country="NL")
        # Touch 2025, 2026, 2027 in sequence — must not error.
        assert cal.is_holiday(date(2025, 12, 25)) is True
        assert cal.is_holiday(date(2026, 12, 25)) is True
        assert cal.is_holiday(date(2027, 12, 25)) is True


class TestValidation:
    def test_empty_country_raises(self):
        with pytest.raises(ValueError, match="non-empty ISO-3166"):
            BusinessCalendar(country="")

    def test_non_string_country_raises(self):
        with pytest.raises(ValueError, match="non-empty ISO-3166"):
            BusinessCalendar(country=None)  # type: ignore[arg-type]

    def test_invalid_weekend_day_raises(self):
        with pytest.raises(ValueError, match="weekend_days"):
            BusinessCalendar(country="NL", weekend_days=(7,))
        with pytest.raises(ValueError, match="weekend_days"):
            BusinessCalendar(country="NL", weekend_days=(-1,))

    def test_all_seven_weekend_days_raises(self):
        # All-weekend would make `next_business_day` infinite-loop.
        with pytest.raises(ValueError, match="all 7 days"):
            BusinessCalendar(
                country="NL", weekend_days=(0, 1, 2, 3, 4, 5, 6)
            )

    def test_unknown_country_raises_clear_value_error(self):
        cal = BusinessCalendar(country="ZZ")
        with pytest.raises(ValueError, match="unknown country/subdivision"):
            cal.is_holiday(date(2026, 1, 1))

    def test_bad_date_type_raises(self):
        cal = BusinessCalendar(country="NL")
        with pytest.raises(TypeError, match="datetime.date or datetime.datetime"):
            cal.is_holiday("2026-04-06")  # type: ignore[arg-type]

    def test_bad_extra_holiday_type_raises(self):
        with pytest.raises(TypeError, match="extra_holidays"):
            BusinessCalendar(
                country="NL", extra_holidays={"2026-12-31"}  # type: ignore[arg-type]
            )

    def test_extra_holiday_rejects_datetime(self):
        with pytest.raises(TypeError, match="extra_holidays"):
            BusinessCalendar(
                country="NL",
                extra_holidays={datetime(2026, 12, 31, 0, 0)},  # type: ignore[arg-type]
            )

    def test_country_normalized_to_uppercase(self):
        cal = BusinessCalendar(country="nl")
        assert cal.country == "NL"
        # And it actually works against the holidays library.
        assert cal.is_holiday(date(2026, 12, 25)) is True

    def test_iterable_inputs_coerced_to_set(self):
        # exclude_names passed as a list (linear-scan footgun) must be
        # converted to a set internally.
        cal = BusinessCalendar(
            country="NL", exclude_names=["Good Friday"]  # type: ignore[arg-type]
        )
        assert isinstance(cal.exclude_names, set)
        assert "Good Friday" in cal.exclude_names

    def test_extra_holidays_propagates_to_is_business_day(self):
        # Regression guard: a date in extra_holidays must NOT be a business day,
        # even though it's a normal weekday and not in the official calendar.
        company_closure = date(2026, 7, 1)  # Wednesday, no NL holiday
        cal = BusinessCalendar(country="NL", extra_holidays={company_closure})
        assert cal.is_business_day(company_closure) is False
        assert cal.next_business_day(company_closure) == date(2026, 7, 2)
