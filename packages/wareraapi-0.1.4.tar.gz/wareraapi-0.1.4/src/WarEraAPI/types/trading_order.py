from dataclasses import dataclass, field
from datetime import datetime
from typing import Literal

from WarEraAPI.types.constants import ITEM
from WarEraAPI.utils import edit_types


@dataclass
class TradingOrder:

    _id: str
    user: str
    itemCode: ITEM
    quantity: int
    price: float
    offerAt: datetime
    type: Literal["buy", "sell"]

    # optional
    country: str | None = field(default=None)


    def __post_init__(self):

        edit_types(self)