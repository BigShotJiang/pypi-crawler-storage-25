from _typeshed import Incomplete
from datetime import datetime
from predict_backend.validation.type_validation import validate_types
from virtualitics_sdk.elements.element import ElementType as ElementType, InputElement as InputElement
from virtualitics_sdk.types import PageUpdateCallback as PageUpdateCallback

class DateTimeRange(InputElement):
    '''A DateTimeRange Input element.

    :param min_range: The minimum date in the range.
    :param max_range: The maximum date in the range.
    :param min_selection: The mimumum selected date. Defaults to the min_range value.
    :param max_selection: The maximum selected date. Defaults to max_range value.
    :param include_nulls_visible: whether null values will be visible, defaults to True.
    :param include_nulls_value: whether to include null values, defaults to False.
    :param show_date: whether to show the date selector, defaults to True.
    :param show_time: whether to show the time selector, defaults to True.
    :param show_timezone: whether to show the timezone selector, defaults to True.
    :param is_range: whether to show both start and end date/time (True) or just a single date/time (False),
                     defaults to True.
    :param title: The title of the element, defaults to \'\'.
    :param description: The element\'s description, defaults to \'\'.
    :param show_title: whether to show the title on the page when rendered, defaults to True.
    :param show_description: whether to show the description to the page when rendered, defaults to True.
    :param label: The label of the element, defaults to \'\'.
    :param placeholder: The placeholder of the element, defaults to \'\'.
    :param timezone: The timezone for the element, defaults to \'UTC\'.
    :param page_update: Updater function. Allows for handling dynamic page update on a page.
                        Takes a StoreInterface and optionally client runners as arguments.
                        This update is triggered when the user blurs the input and the value has changed.
                        Defaults to None (no update function).
    :param reference_id: A user-defined reference ID for the unique identification of DataSource element within the
                         Page, defaults to \'\'.
    
    **EXAMPLE:**

       .. code-block:: python

           # Imports 
           from virtualitics_sdk import DateTimeRange
           . . .
           # Example usage
           class LandingStep(Step):
             def run(self, flow_metadata):
               . . . 
               date_range = DateTimeRange(datetime.today().replace(year=2000),
                                          datetime.today().
                                          replace(year=2020), 
                                          title="Date Time Range", 
                                          description= "Here\'s a datetime range 
                                                        from the beginning of the 
                                                        month to now.")

    The above DateTimeRange example will be displayed as: 

       .. image:: ../images/date_time_range_ex.png
          :align: center

    How to use page_update

        .. code-block:: python

            # Imports
            from virtualitics_sdk import DateTimeRange, StoreInterface, Card, Step
            from datetime import datetime
            . . .
            . . .

            # Example page update function
            def datetime_range_updater(store_interface: StoreInterface):
                page = store_interface.get_page()
                datetime_element = page.get_element_by_reference_id(\'My Updatable Datetime Range\')
                new_value = store_interface.get_element_value(
                    store_interface.step_name, "My Updatable Datetime Range"
                )
                datetime_element.description = f\'You updated the date range! New value: {new_value}\'
                store_interface.update_page(page)

            # Example usage of page updater
            class ExStep(Step):
                def run(self, flow_metadata):
                    store_interface = StoreInterface(**flow_metadata)
                    page = store_interface.get_page()
                    . . .
                    datetime_range = DateTimeRange(
            min_range=datetime(2020, 1, 1),
            max_range=datetime(2021, 1, 1),
            title="Title Datetime Range",
            description="This datetime range is updatable.",
            reference_id="My Updatable Datetime Range",
            page_update=datetime_range_updater
                    )

                    card = Card(title="Example Card", content=[datetime_range])
                    page.add_card_to_section(card, "Ex Section")
    '''
    time_format: str
    is_range: Incomplete
    @validate_types
    def __init__(self, min_range: datetime, max_range: datetime, min_selection: datetime | None = None, max_selection: datetime | None = None, include_nulls_visible: bool = True, include_nulls_value: bool = False, show_date: bool = True, show_time: bool = True, show_timezone: bool = True, is_range: bool = True, title: str = '', description: str = '', show_title: bool = True, show_description: bool = True, label: str = '', placeholder: str = '', timezone: str = 'UTC', page_update: PageUpdateCallback | None = None, reference_id: str | None = '') -> None: ...
    def get_value(self) -> dict[str, str] | str:
        """Get the value of an element. If the user has interacted with the value, the default
           will be updated.

        Returns:
            If is_range is True: dict with 'min' and 'max' keys
            If is_range is False: string representing the selected date/time
        """
    def update_range(self, min_date: datetime | None = None, max_date: datetime | None = None) -> None:
        """Update the min/max range values for the DateTimeRange element.

        :param min_date: The new minimum date in the range. If None, current min value is preserved.
        :param max_date: The new maximum date in the range. If None, current max value is preserved.
        :raises ValueError: If both min_date and max_date are provided and min_date > max_date.
        """
    def reset_selection(self) -> None:
        """Reset the selection values to the original min_selection and max_selection provided during initialization."""
    def update_selection(self, min_value: datetime | None = None, max_value: datetime | None = None, value: datetime | None = None) -> None:
        """Update the selected value(s) for the DateTimeRange element.

        :param min_value: The minimum selected date (for range selections).
        :param max_value: The maximum selected date (for range selections).
        :param value: The selected date (for single date selections when is_range=False).
        :raises ValueError: If mixing value with min_value/max_value, or using value when is_range=True.
        """
