from _typeshed import Incomplete
from predict_backend.validation.type_validation import validate_types
from virtualitics_sdk.elements.element import ElementType as ElementType, InputElement as InputElement
from virtualitics_sdk.types.callbacks import PageUpdateCallback as PageUpdateCallback

class DataSource(InputElement):
    '''A Data Source Input Element.

    Allows users to upload files through the platform. Supports tabular formats (csv, xlsx) that are
    automatically converted to pandas DataFrames, as well as raw file formats (json, pdf, docx, txt)
    that can be stored as-is without conversion. Use ``"*"`` to accept any file type.

    :param title: The title of the element, defaults to \'\'.
    :param options: The accepted file types for upload. Supported values: ``"csv"``, ``"xlsx"``, ``"json"``,
                    ``"pdf"``, ``"docx"``, ``"txt"``, ``"s3"``, ``"sql"``, ``"*"`` (any file type).
                    Multiple options can be provided as a list, e.g. ``["csv", "json"]``.
                    Defaults to ``["csv"]``.
    :param value: The file name/pointer to the data source, defaults to \'\'.
    :param description: The element\'s description, defaults to \'\'.
    :param show_title: Whether to show the title on the page when rendered, defaults to True.
    :param show_description: Whether to show the description on the page when rendered, defaults to True.
    :param required: Whether a file needs to be submitted for the step to continue, defaults to True.
    :param label: The label of the element, defaults to \'\'.
    :param placeholder: The placeholder of the element, defaults to \'\'.
    :param on_upload_completion: Page update callback. Allows execution of a function after each file upload completes.
                                 Must be decorated using the ``@page_update_callback`` decorator.
                                 Takes a StoreInterface and optionally client runners as arguments, defaults to None.
    :param on_cancel: Page update callback. Allows execution of a function when a file upload is cancelled.
                                 Must be decorated using the ``@page_update_callback`` decorator.
                                 Takes a StoreInterface and optionally client runners as arguments, defaults to None.
    :param reference_id: A user-defined reference ID for the unique identification of DataSource element within the
                        Page, defaults to \'\'.
    :param downloadable: Whether the currently selected file can be downloaded, defaults to False.
    :param raw_upload: When True, the uploaded file is stored as raw bytes and the default step action
                       skips pandas DataFrame conversion. Use this for non-tabular file types (json, pdf,
                       docx, txt) or when you want to handle file parsing yourself. The raw file can be
                       retrieved in a subsequent step using
                       ``store_interface.get_raw_data_source_data(step_name=..., elem_reference_id=...)``.
                       Defaults to False.


    **EXAMPLES:**

       .. code-block:: python

           # CSV upload (default behavior, converted to DataFrame)
           data_source = DataSource(
               title="Upload data here!",
               options=["csv"],
               description="Example datasource usage",
               required=True,
           )

       .. code-block:: python

           # Raw file upload (stored as bytes, no DataFrame conversion)
           pdf_source = DataSource(
               title="Upload PDF",
               options=["pdf"],
               description="Upload a PDF document",
               raw_upload=True,
           )

       .. code-block:: python

           # Accept any file type
           any_source = DataSource(
               title="Upload Any File",
               options=["*"],
               description="Upload any file type",
               raw_upload=True,
           )
    '''
    on_upload_completion: Incomplete
    on_cancel: Incomplete
    @validate_types
    def __init__(self, title: str = '', options: list[str] | None = None, value: str = '', description: str = '', show_title: bool = True, show_description: bool = True, required: bool = True, label: str = '', placeholder: str = '', on_upload_completion: PageUpdateCallback | None = None, on_cancel: PageUpdateCallback | None = None, reference_id: str | None = '', downloadable: bool = False, raw_upload: bool = False) -> None: ...
    def get_value(self) -> str:
        """Get the value of an element. If the user has interacted with the value, the default
           will be updated.
        """
