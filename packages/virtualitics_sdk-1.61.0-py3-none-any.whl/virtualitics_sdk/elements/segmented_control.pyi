from _typeshed import Incomplete
from virtualitics_sdk.elements.element import Element as Element, ElementHorizontalPosition as ElementHorizontalPosition, ElementType as ElementType
from virtualitics_sdk.page.card import Segment as Segment

class SegmentedControl(Element):
    """A SegmentedControl Element for switching between multiple Card-based views.

    The SegmentedControl allows users to switch between different Segments (Card-based views)
    without triggering a page refresh. Each segment contains arbitrary content like tables,
    plots, and input elements.

    :param title: The title of the segmented control element.
    :param segments: List of Segment objects to display.
    :param active_segment_index: Index of the initially active segment (0-based). Defaults to 0.
    :param controls_position: Horizontal alignment of the segment buttons (LEFT/CENTER/RIGHT). Defaults to LEFT.
    :param max_controls_width: Maximum width of the controls container in pixels. When exceeded,
        horizontal scrolling is enabled. Defaults to None (no limit).
    :param reference_id: A user-defined reference ID for unique identification, defaults to ''.
    :param kwargs: Additional parameters.
    """
    segments: Incomplete
    active_segment_index: Incomplete
    controls_position: Incomplete
    max_controls_width: Incomplete
    def __init__(self, *, title: str, segments: list['Segment'], active_segment_index: int | None = 0, controls_position: ElementHorizontalPosition = ..., max_controls_width: int | None = None, reference_id: str | None = '', **kwargs) -> None: ...
    def set_active_segment(self, index: int): ...
    def to_json(self) -> dict:
        """Convert the element to JSON."""
