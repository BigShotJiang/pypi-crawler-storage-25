import openpyxl
import pandas
import pandas as pd
from _typeshed import Incomplete
from abc import ABC
from enum import Enum
from predict_backend.validation.type_validation import validate_types
from pydantic import BaseModel
from typing import Literal
from virtualitics_sdk.assets.dataset import Dataset as Dataset
from virtualitics_sdk.elements.element import Element as Element, ElementType as ElementType
from virtualitics_sdk.types.callbacks import CallbackType as CallbackType, PageUpdateCallback as PageUpdateCallback

logger: Incomplete
PREDICT_SUCCESS_TEXT_COLOR: str
PREDICT_SUCCESS_CELL_COLOR: str
PREDICT_ERROR_TEXT_COLOR: str
PREDICT_ERROR_CELL_COLOR: str
PREDICT_WARNING_TEXT_COLOR: str
PREDICT_WARNING_CELL_COLOR: str
PREDICT_DEFAULT_TEXT_COLOR: str
PREDICT_DEFAULT_CELL_COLOR: str

class RowActionType(Enum):
    UPDATE: str
    REDIRECT: str
    UPDATE_REDIRECT: str

class TableSelectionType(Enum):
    """Selection mode for table row selection.

    INCLUDE: The selected_rows list contains the indices of selected rows.
    EXCLUDE: The selected_rows list contains the indices of rows that are NOT selected (all others are selected).
    """
    INCLUDE: str
    EXCLUDE: str

class RowAction(ABC):
    title: Incomplete
    description: Incomplete
    action_type: Incomplete
    def __init__(self, title: str, description: str, type: RowActionType) -> None: ...
    def to_json(self): ...

class ColumnField(BaseModel):
    field: str

class ColumnGroup(BaseModel):
    '''
        column_grouping = [
        ColumnGroup(
            group_id="internal data",
            children=[ColumnField(field="id")]
        ),
        ColumnGroup(
            group_id="character",
            children=[
                ColumnGroup(
                    group_id="naming",
                    children=[
                        ColumnField(field="lastName"),
                        ColumnField(field="firstName")
                    ]
                ),
                ColumnField(field="age")
            ]
        )
    ]
    '''
    model_config: Incomplete
    group_id: str
    children: list[ColumnGroup | ColumnField]

class GridColumn(BaseModel):
    """
    Equivalent to a MUI GridColDef

    https://mui.com/x/react-data-grid/column-definition/
    """
    model_config: Incomplete
    field: str
    header_name: str
    dtype: str
    col_spanning: bool
    editable: bool
    pinned: Literal['left', 'right'] | None
    validation_rule: str | None
    value_options: list[str] | None
ColumnGroupingModel = list[ColumnGroup | ColumnField]

class DataGridFeatures(BaseModel):
    """Top-level container for MUI DataGrid feature configurations."""
    model_config: Incomplete
    column_definitions: list[GridColumn] | None
    column_grouping_model: ColumnGroupingModel | None
    col_spanning: bool | None
    aggregation: dict[str, Literal['sum', 'avg', 'min', 'max', 'size']] | None
    column_formatters: dict[str, str] | None
    conditional_formatting_rules: dict[str, str] | None
    cell_editable: bool | None
    table_editable: bool | None
    default_page_size: int | None

class Table(Element):
    '''A Table element.

    :param content: A DataFrame, Pandas series, or Dataset. Dataframes that have  column with the reserved keyword `id` as their name are not supported and will raise an Exception.
    :param downloadable: Whether this table should be downloaded, defaults to False.
    :param filters_active: Whether the filters are active on this table, defaults to False.
    :param title: The title of the element, defaults to \'\'.
    :param description: The element\'s description, defaults to \'\'.
    :param show_title: Whether to show the title on the page when rendered, defaults to True.
    :param show_description: Whether to show the description to the page when rendered, defaults to True.
    :param cell_colors: Dataframe of cell colors as hex strings. Columns should exist inside source dataset, defaults to None, joined to in content dataframe by index. See code example below for usage.
    :param text_colors: Dataframe of text colors as hex strings. Columns should exist inside source dataset, defaults to None, joined to in content dataframe by index. See code example below for usage.
    :param column_descriptions: Dictionary {column_name: column_description} of column descriptions, defaults to None. Presented to user as tooltips and can be fed to agents as additional context
    :param searchable: Toggles the ability to search table values, defaults to True.
    :param missing_values: Set to true if this table contains missing values and you want to flag this to the user.
    :param notes: The popover description that shows upon hovering over a particular row. Each index in the list maps to the corresponding row. Defaults to None.
    :param links: The link to redirect to when hovering over a particular row. Each index in the list maps to the corresponding row. Defaults to None.
    :param show_filter: Whether to show the filter on the page when rendered, defaults to False.
    :param max_table_rows_to_display: Defaults to 2500 rows, this is the number of rows that will be sent to the frontend, however
           the entire table is downloadable from the frontend regardless of this limit. Browsers with more resources may be able to handle
           much larger limits than this default value.
    :param xlsx_config: dictionary of configurable parameters for tables that are backed by an xlsx object
    :param editable: should this table be editable by the user from the frontend. This defaults to true.
    :param max_table_row_height: The maximum height of the table rows. Defaults to 300 characters.
    :param markdown_columns: Controls which columns render their content as markdown. If None or an empty list ([]), no columns will render as markdown. If set to True, all columns will render as markdown. If set to a list of column names, only the specified columns will render as markdown, while others will render as plain text
    :param missing_value_text:  A string used to replace missing values (e.g., None, NaN, or NaT) in the table when rendered. Defaults to None, meaning missing values will remain as-is.
    :param editable_columns: Controls which columns are editable. If None, False, or an empty list ([]), no columns will be editable. If set to True, all columns will be editable. If set to a list of column names, only the specified columns will be editable. Defaults to True. You must turn this to False if editable is also False if you wish to disable table edits.
    :param row_actions: A list of row_action_callbacks that will be attached to the first rows of the table, as determined by the `max_table_rows_to_display` parameter. Defaults to None.
    :param selectable: Enable row selection checkboxes without requiring row_actions. When True, users can select
                       rows and the selections are synced to the backend. Use ``get_selected_data()`` to get a DataFrame of selected rows.
                       Defaults to False.
    :param selected_rows: List of row indices to select by default. Used with ``selection_type`` to specify
                          which rows are initially selected. Defaults to None (no default selection).
    :param selection_type: The selection mode. Use ``TableSelectionType.INCLUDE`` to select the rows in
                           ``selected_rows``, or ``TableSelectionType.EXCLUDE`` to select all rows EXCEPT those
                           in ``selected_rows``. Defaults to ``TableSelectionType.INCLUDE``.
    :param column_formatters: A dictionary of key: Column Name and value: Python format string, that optionally formats the specified numeric columns on the frontend. As an example, \'{total_spending: "$ {:,.2f}"}\' would format the total_spending column as currency, while sorting as an float. Defaults to None.
    :param data_grid_features: MUI DataGrid style and organization options.
    :param on_edit_update: Page update callback. Allows execution of a function after the table\'s contents get saved after an edit.
                           Must be decorated using the ``@page_update_callback`` decorator.
                           Takes a StoreInterface and optionally client runners as arguments, defaults to None.
    :param on_row_select: Page update callback. Allows execution of a function when row selection changes.
                          Must be decorated using the ``@page_update_callback`` decorator.
                          Only triggered when ``selectable=True``. Defaults to None.
    :param reference_id: A user-defined reference ID for the unique identification of Table element within the
                         Page, defaults to \'\'.
    :param info_content: Description to be displayed within the element\'s info button. Use RichText/Markdown for
                         advanced formatting.


    :raises NotImplementedError: When table is created with invalid type.

    **EXAMPLE:**

       .. code-block:: python

            # Imports
            from virtualitics_sdk import Table, PREDICT_ERROR_TEXT_COLOR
            . . .
            . . .
            # Example usage
            class ExampleStep(Step):
                def run(self, flow_metadata):
                    . . .
                    point_per_cluster = 5 # Number of rows we want cell/text color to apply to
                    cell_colors = pandas.DataFrame({"Y Feature": ["#39cd63"] * point_per_cluster})
                    text_colors = pandas.DataFrame({"X Feature": ["#ee2310"] * point_per_cluster})
                    table = Table(example_dataset,
                                  title="Example Table",
                                  description="This is a table showing cells/text color",
                                  downloadable=True,
                                  cell_colors=cell_colors,
                                  text_colors=text_colors)

                from sklearn.datasets import load_iris

            from virtualitics_sdk.elements.table import Table, DataGridFeatures, ColumnGroup, ColumnField, GridColumn

            iris = load_iris(as_frame=True)
            columns = [
                GridColumn(field="sepal_length", header_name="sepal length (cm)", dtype="number"),
                GridColumn(field="sepal_width", header_name="sepal width (cm)", dtype="number", col_spanning=True),
                GridColumn(field="sepal_width_2", header_name="sepal width (cm)", dtype="number", col_spanning=True),
                GridColumn(field="petal_length", header_name="petal length (cm)", dtype="number"),
                GridColumn(field="petal_width", header_name="petal width (cm)", dtype="number"),
                GridColumn(field="target", header_name="target", dtype="text"),
            ]
            iris.frame.columns = ["sepal_length", "sepal_width", "petal_length", "petal_width", "target"]
            column_grouping = [
                ColumnGroup(
                    group_id="flower measurements",
                    children=[
                        ColumnGroup(
                            group_id="sepal",
                            children=[ColumnField(field="sepal_length"),
                                      ColumnField(field="sepal_width"),
                                      ColumnField(field="sepal_width_2")],
                        ),
                        ColumnGroup(
                            group_id="petal",
                            children=[ColumnField(field="petal_length"), ColumnField(field="petal_width")],
                        )
                    ],
                ),
                ColumnGroup(group_id="classification", children=[ColumnField(field="target")]),
            ]

            data_grid_features = DataGridFeatures(columns=columns,
                                                  column_grouping_model=column_grouping)
            df[\'sepal_width_2\'] = df.sepal_width
            table_with_grouping_and_spanning = Table(df,
                                                     title="Iris Dataset with Grouping and Spanning",
                                                     data_grid_features=data_grid_features)

    The above Table examples will be displayed as:

       . image:: ../images/table_color_ex.png
          :align: center
    '''
    persistence: Incomplete
    cell_color_persistence: Incomplete
    text_color_persistence: Incomplete
    row_actions: Incomplete
    on_edit_update: Incomplete
    on_row_select: Incomplete
    buttons: Incomplete
    conditional_formatting_rules: Incomplete
    info_content: Incomplete
    column_info_content: Incomplete
    content: Incomplete
    @validate_types
    def __init__(self, content: pandas.DataFrame | Dataset | openpyxl.Workbook, downloadable: bool = False, filters_active: bool = False, title: str = '', description: str = '', show_title: bool = True, show_description: bool = True, cell_colors: pandas.DataFrame | None = None, text_colors: pandas.DataFrame | None = None, column_descriptions: dict[str, str] | None = None, searchable: bool = True, missing_values: bool = False, notes: list[str] | None = None, links: list[str] | None = None, show_filter: bool = False, max_table_rows_to_display: int = 2500, xlsx_config: dict | None = None, editable: bool = True, max_table_row_height: int = 300, markdown_columns: list[str] | bool | None = None, missing_value_text: str | None = None, editable_columns: list[str] | bool | None = True, row_actions: list[PageUpdateCallback] | None = None, selectable: bool = False, selected_rows: list[int] | None = None, selection_type: TableSelectionType = ..., column_formatters: dict[str, str] | None = None, on_edit_update: PageUpdateCallback | None = None, on_row_select: PageUpdateCallback | None = None, data_grid_features: DataGridFeatures | None = None, reference_id: str | None = '', info_content: str | None = None, column_info_content: dict[str, str] | None = None, persist_as_json: bool = False, **kwargs) -> None: ...
    def to_json(self) -> dict: ...
    def extract_context(self) -> dict: ...
    def get_dtypes(self, _df: pandas.DataFrame) -> dict: ...
    def get_df(self) -> pandas.DataFrame:
        """Returns the Table Element's persisted data as a pandas.Dataframe."""
    def set_selected_rows(self, selected_rows: list[int], selection_type: TableSelectionType = ...) -> None:
        """Set the selected rows programmatically.

        :param selected_rows: List of row indices to select (or exclude, depending on selection_type)
        :param selection_type: Use INCLUDE to select the specified rows, or EXCLUDE to select
                               all rows EXCEPT the specified ones. Defaults to INCLUDE.
        """
    def get_selected_data(self) -> pd.DataFrame:
        """Returns a DataFrame containing only the selected rows.

        :return: DataFrame with only the selected rows
        """
