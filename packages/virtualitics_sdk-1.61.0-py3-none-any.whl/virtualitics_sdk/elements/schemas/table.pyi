from _typeshed import Incomplete
from pydantic import BaseModel
from typing import Literal
from virtualitics_sdk.elements.schemas.element import SerializedComment as SerializedComment, SerializedElement as SerializedElement

class TableCellValue(BaseModel):
    """A single cell in the serialized table content."""
    model_config: Incomplete
    value: object
    cellColor: str | None
    textColor: str | None
    getCellColors: str | None

class TableRowMetadataEntry(BaseModel):
    notes: str
    link: str
    has_link: bool

class TableSelectedRows(BaseModel):
    type: Literal['include', 'exclude']
    ids: list[int]

class TableColumnDtype(BaseModel):
    mui_dtype: str
    dtype: str
    categories: list[str] | None

class SerializedTableColumn(BaseModel):
    """A column definition as serialized to JSON (GridColumn.model_dump(by_alias=True))."""
    model_config: Incomplete
    field: str
    headerName: str
    type: str
    colSpan: bool
    editable: bool
    pinned: Literal['left', 'right'] | None
    validationRule: str | None
    valueOptions: list[str] | None

class SerializedTableParams(BaseModel):
    """The ``params`` dict of a serialized Table element."""
    model_config: Incomplete
    data_type: Literal['json', 'memory', 'pandas', 'asset', 'xlsx']
    data_grid: bool
    dtypes: dict[str, TableColumnDtype]
    columns: list[SerializedTableColumn]
    columnGroupingModel: list[dict]
    max_table_rows_to_display: int
    max_table_row_height: int
    editable: bool
    tableEditable: bool
    searchable: bool
    downloadable: bool
    filters_active: bool
    has_cell_colors: bool
    has_text_colors: bool
    column_descriptions: dict[str, str]
    row_metadata: list[TableRowMetadataEntry]
    missing_values: bool
    table_empty: bool
    defaultPageSize: int
    aggregation: dict[str, Literal['sum', 'avg', 'min', 'max', 'size']] | None
    cellEditable: bool | None
    actions: list[str]
    has_on_edit_update: bool
    has_on_row_select: bool
    selectable: bool
    selected_rows: TableSelectedRows
    hash: str
    show_filter: bool
    markdown_columns: list[str] | bool | None
    missing_value_text: str | None
    column_formatters: dict[str, str] | None

class SerializedTable(SerializedElement):
    """Validates the JSON output of ``table_serialization()``.

    Usage::

        payload = table_serialization(table.to_json())
        validated = SerializedTable.model_validate(payload)
    """
    type: Literal['table']
    params: SerializedTableParams
    content: list[dict[str, TableCellValue]] | str
    comments: list[SerializedComment]
    info_content: str | None
    column_info_content: dict[str, str] | None
    conditional_formatting_rules: dict[str, str] | None
