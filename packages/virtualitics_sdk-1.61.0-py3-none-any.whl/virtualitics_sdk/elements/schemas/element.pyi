from _typeshed import Incomplete
from pydantic import BaseModel

class SerializedComment(BaseModel):
    id: str
    commenter: str
    message: str
    time_created: str
    last_edited: str

class SerializedElement(BaseModel):
    """Base fields shared by every serialized element.

    Subclass this per element type and narrow ``type`` to a ``Literal``.
    """
    model_config: Incomplete
    id: str
    type: str
    card_id: str | None
    title: str
    description: str
    show_title: bool
    show_description: bool
    params: dict
    content: object
    comments: list[SerializedComment]
    vertical_position: str | None
    horizontal_position: str | None
    overflow_behavior: str
    hash_bump: int
    reference_id: str
