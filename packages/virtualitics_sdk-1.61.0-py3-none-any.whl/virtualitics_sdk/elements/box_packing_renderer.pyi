from _typeshed import Incomplete
from pydantic import BaseModel
from typing import Any
from virtualitics_sdk import StoreInterface as StoreInterface
from virtualitics_sdk.elements.element import Element as Element, ElementType as ElementType
from virtualitics_sdk.page.drilldown import DrilldownType as DrilldownType
from virtualitics_sdk.types.callbacks import CallbackType as CallbackType, DrilldownCallback as DrilldownCallback, PageUpdateCallback as PageUpdateCallback, page_update_callback as page_update_callback

class Color3(BaseModel):
    """
    RGB color with values normalized between 0.0 and 1.0.

    Used for opaque colors (no transparency).

    Attributes:
        r: Red component (0.0 to 1.0)
        g: Green component (0.0 to 1.0)
        b: Blue component (0.0 to 1.0)

    Example:
        red = Color3(r=1.0, g=0.0, b=0.0)
        white = Color3(r=1.0, g=1.0, b=1.0)
        gray = Color3(r=0.5, g=0.5, b=0.5)
    """
    r: float
    g: float
    b: float

class Color4(Color3):
    """
    RGBA color with alpha channel for transparency.

    Extends Color3 by adding an alpha channel for transparency control.

    Attributes:
        r: Red component (0.0 to 1.0)
        g: Green component (0.0 to 1.0)
        b: Blue component (0.0 to 1.0)
        a: Alpha/transparency (0.0 = fully transparent, 1.0 = fully opaque)

    Example:
        semi_transparent_red = Color4(r=1.0, g=0.0, b=0.0, a=0.5)
        opaque_white = Color4(r=1.0, g=1.0, b=1.0, a=1.0)
    """
    a: float

class Vector3(BaseModel):
    """
    3D position or rotation vector.

    Used to represent coordinates in 3D space or rotation angles (in degrees).

    Attributes:
        x: X coordinate or rotation around X axis
        y: Y coordinate or rotation around Y axis
        z: Z coordinate or rotation around Z axis

    Example:
        origin = Vector3(x=0.0, y=0.0, z=0.0)
        position = Vector3(x=0.5, y=0.2, z=-0.3)
        rotation_90_deg_x = Vector3(x=1.5708, y=0.0, z=0.0)  # 90 degrees in degrees
    """
    x: float
    y: float
    z: float

class ContainerDimensions(BaseModel):
    """
    Dimensions of the 3D container that holds the boxes.

    Defines the size of the virtual container space. All values must be positive.

    Attributes:
        width: Container width (must be > 0)
        height: Container height (must be > 0)
        depth: Container depth (must be > 0)

    Example:
        cube = ContainerDimensions(width=1.0, height=1.0, depth=1.0)
        wide_box = ContainerDimensions(width=2.0, height=1.0, depth=1.0)
    """
    width: float
    height: float
    depth: float

def random_str(): ...

class Box(BaseModel):
    '''
    A single box in the 3D packing visualization.

    Represents a 3D box with position, size, color, and optional label.

    Attributes:
        id: Optional Box identifier. Generated if not provided
        position: 3D position of the box center
        color: Box color (RGB, always opaque)
        width: Box width (0 to 1.0, relative to container)
        height: Box height (0 to 1.0, relative to container)
        depth: Box depth (0 to 1.0, relative to container)
        text: Optional label/text displayed on the box
        data: Optional extra data to store into the Box

    Example:
        red_box = Box(
            position=Vector3(x=0.0, y=0.0, z=0.0),
            color=Color3(r=1.0, g=0.0, b=0.0),
            width=0.2,
            height=0.15,
            depth=0.1,
            text="Product A"
        )
    '''
    id: str
    position: Vector3
    color: Color3
    width: float
    height: float
    depth: float
    text: str
    data: dict[str, Any] | None

class GridWall(BaseModel):
    """
    A wall/grid plane in the 3D scene.

    Creates a rectangular plane with optional grid lines. Useful for showing
    container boundaries or creating reference planes.

    Attributes:
        position: 3D position of the wall center
        rotation: Rotation angles in degrees (x, y, z)
        width: Wall width
        height: Wall height
        color: Wall color (RGBA, supports transparency)
        horizontal_line_count: Number of horizontal grid lines
        vertical_line_count: Number of vertical grid lines

    Example:
        # Create a semi-transparent red wall at the origin, rotated 90 degrees on X axis
        wall = GridWall(
            position=Vector3(x=0.0, y=0.0, z=0.0),
            rotation=Vector3(x=1.5708, y=0.0, z=0.0),  # 90 degrees
            width=1.0,
            height=1.0,
            color=Color4(r=1.0, g=0.0, b=0.0, a=0.5),
            horizontal_line_count=10,
            vertical_line_count=15
        )
    """
    model_config: Incomplete
    position: Vector3
    rotation: Vector3
    width: float
    height: float
    color: Color4
    horizontal_line_count: int
    vertical_line_count: int

class BoxPackingConfig(BaseModel):
    '''
    Complete configuration for BoxPackingRenderer.

    This is the main configuration class that contains all settings for creating
    a 3D box packing visualization. It includes canvas settings, scene appearance,
    lighting, animation, and the actual data (boxes and walls).

    Attributes:
        canvas_width: Canvas width in pixels
        canvas_height: Canvas height in pixels
        background_color: Background color of the scene (RGB)
        container_dimensions: Dimensions of the 3D container
        light_brightness: Light brightness (0.0 = dark, 1.0 = bright)
        animation_speed: Animation speed in milliseconds (0 = no animation)
        render_walls: Whether to render walls/grids
        render_boxes: Whether to render boxes
        boxes: List of boxes to render
        walls: List of walls/grids to render
        highlighted_boxes: List of highlighted boxes
        continuous_rotation: Enable continuous Y-axis rotation
        rotation_speed: Rotation speed
        rotation_direction: Rotation direction (True=clockwise, False=counter-clockwise)

    Example:
        config = BoxPackingConfig(
            canvas_width=800,
            canvas_height=600,
            background_color=Color3(r=0.1, g=0.1, b=0.1),
            light_brightness=0.8,
            boxes=[
                Box(
                    position=Vector3(x=0.0, y=0.0, z=0.0),
                    color=Color3(r=1.0, g=0.0, b=0.0),
                    width=0.2,
                    height=0.15,
                    depth=0.1,
                    text="Box A"
                )
            ]
        )
    '''
    model_config: Incomplete
    canvas_width: int
    canvas_height: int
    background_color: Color3
    container_dimensions: ContainerDimensions
    light_brightness: float
    animation_speed: float
    render_walls: bool
    render_boxes: bool
    boxes: list[Box]
    walls: list[GridWall]
    highlighted_boxes: list[int] | None
    continuous_rotation: bool
    rotation_speed: float
    rotation_direction: bool

class BoxPackingRenderer(Element):
    '''A 3D interactive box packing visualization element.

    Displays boxes in a 3D container with interactive selection and deletion. Users can click boxes to select them,
    use keyboard shortcuts (ESC to deselect, DEL to delete), and trigger callbacks when selections change.

    :param box_content: Configuration for the 3D scene. Use ``BoxPackingConfig`` to set up boxes, walls, colors,
                        lighting, and animation. See ``BoxPackingConfig`` for details.
    :param title: Title text displayed above the visualization. Defaults to empty string.
    :param description: Description text shown below the title. Defaults to empty string.
    :param show_title: If ``True``, displays the title. Defaults to ``True``.
    :param show_description: If ``True``, displays the description. Defaults to ``True``.
    :param reference_id: Unique identifier for this element. 
    :param allow_box_deletion: If ``True``, users can delete boxes by pressing DEL key. Defaults to ``True``.
    :param on_selection_change: Callback triggered when user selects or deselects boxes by clicking.
                                Can be ``PageUpdateCallback``, ``DrilldownCallback``, or ``None``.
                                The callback receives a list of selected box indices.

                                **Example with page update:**

                                .. code-block:: python

                                    @page_update_callback
                                    async def on_selection_change(store_interface: StoreInterface):
                                        page = store_interface.get_page()
                                        renderer = page.get_element_by_reference_id("my_renderer")
                                        selected = renderer.get_highlighted()

                                **Example with drilldown:**

                                .. code-block:: python

                                    @drilldown_callback(
                                        drilldown_type=DrilldownType.MODAL, drilldown_size=DrilldownSize.SMALL
                                    )
                                    async def on_selection_change(
                                        card: Card,
                                        input_data: dict,
                                        store_interface: DrilldownStoreInterface
                                    ):
                                        selected_indices = input_data["selectedIndices"]
                                        card.add_content([RichText(f"Selected boxes: {selected_indices}")])

    :param on_selection_delete: Callback triggered when user deletes boxes by pressing DEL key.
                                Can be ``PageUpdateCallback``, ``DrilldownCallback``, or ``None``.
                                If ``None`` and ``allow_box_deletion=True``, a default callback that removes
                                the boxes from the scene is used. The callback receives a list of deleted box indices.

                                **Example with page update:**

                                .. code-block:: python

                                    @page_update_callback
                                    async def on_delete(store_interface: StoreInterface, input_data: list):
                                        page = store_interface.get_page()
                                        renderer = page.get_element_by_reference_id("my_renderer")
                                        # input_data contains list of box indices to delete
                                        # Custom logic here (e.g., update database)
                                        renderer.remove_boxes_by_indices(input_data)
                                        store_interface.update_page(page)

    :param show_confirmation: If ``True``, shows a confirmation modal before deleting boxes. Only applies when
                              ``allow_box_deletion=True``. Defaults to ``True``.
    :param confirmation_text: Custom text for the deletion confirmation modal. If ``None``, shows default message
                              with box indices. Only used when ``show_confirmation=True``.

    **Keyboard Shortcuts:**
        - Click: Select/deselect boxes (hold Control/Cmd to select multiple)
        - ESC: Deselect all boxes
        - DEL: Delete selected boxes (shows confirmation if ``show_confirmation=True``)
    '''
    SELECTION_CHANGE_CALLBACK: str
    CANCEL_CALLBACK: str
    HAS_SELECTION_CHANGE_KEY: str
    HAS_CANCEL_KEY: str
    on_selection_change: Incomplete
    on_cancel: Incomplete
    def __init__(self, box_content: BoxPackingConfig, title: str = '', description: str = '', show_title: bool = True, show_description: bool = True, reference_id: str = '', allow_box_deletion: bool = True, on_selection_change: PageUpdateCallback | DrilldownCallback | None = None, on_selection_delete: PageUpdateCallback | DrilldownCallback | None = None, show_confirmation: bool | None = True, confirmation_text: str | None = None) -> None: ...
    def serialize_callbacks(self, func, callback_name) -> dict:
        """Encode Drilldown parameters if applicable. Also validates that POPOVER is not used."""
    def update_highlighted(self, highlighted: list[int]):
        """Set which boxes are selected (highlighted).

        :param highlighted: List of box indices to highlight. Pass empty list to clear selection.
        :raises TypeError: If highlighted is not a list or contains non-integer values.
        :raises ValueError: If any index is negative.
        """
    def get_highlighted(self) -> list[int]:
        """Get the list of currently highlighted box indices.

        :return: List of box indices that are currently selected.
        """
    def set_background_color(self, background: Color3):
        """Change the 3D scene background color.

        :param background: New background color as a Color3 object.
        :raises TypeError: If background is not a Color3 instance.
        """
    def set_light_brightness(self, brightness: float):
        """Adjust the brightness of the scene lighting.

        :param brightness: Light brightness value between 0.0 (dark) and 1.0 (bright).
        :raises ValueError: If brightness is not between 0.0 and 1.0.
        """
    def set_animation_speed(self, speed: float):
        """Change the speed of box animations.

        :param speed: Animation speed in milliseconds. Use 0 for no animation.
        :raises ValueError: If speed is negative.
        """
    def clear_highlighted(self) -> None:
        """Clear all selected boxes. Same as calling update_highlighted([])."""
    def to_json(self): ...
    def get_value(self): ...
    def update_y_axis_rotation(self, direction: bool, speed: float = 0.2):
        """Applies continuous rotation to the plot along the Y axis.

        :param direction: Direction true = Clockwise, false = Counter-clockwise. Default = true.
        :param speed: Rotation speed. Must be non-negative. Default = 0.2
        :raises TypeError: If direction is not a bool or speed is not a float/int.
        :raises ValueError: If speed is negative.
        """
    def add_gridwalls(self, walls: list[GridWall]):
        """Add grid walls to the 3D scene.

        :param walls: List of GridWall objects to add. Walls are useful for showing container boundaries.
        :raises TypeError: If walls is not a list or contains non-GridWall objects.
        """
    def get_gridwalls(self) -> list[dict]:
        """Get all grid walls in the scene.

        :return: List of wall dictionaries currently in the scene.
        """
    def get_box_config(self) -> BoxPackingConfig:
        """Get the complete configuration of the scene.

        :return: BoxPackingConfig object with all current scene settings.
        """
    content: Incomplete
    def update_box_config(self, box_config: BoxPackingConfig):
        """Replace the entire scene configuration.

        :param box_config: New BoxPackingConfig to use. Replaces all boxes, walls, and settings.
        :raises TypeError: If box_config is not a BoxPackingConfig instance.
        """
    def add_box(self, box: Box):
        """Add a single box to the box list.

        :param box: Box object to add to the renderer.
        :raises TypeError: If box is not a Box instance.
        """
    def add_boxes(self, boxes: list[Box]):
        """Add multiple boxes to the box list.

        :param boxes: List of Box objects to add to the renderer.
        :raises TypeError: If boxes is not a list or contains non-Box objects.
        """
    def remove_boxes_by_indices(self, indices: list[int]):
        """Remove boxes at the specified indices.

        :param indices: List of box indices to remove. Indices are sorted in descending order
                       to avoid index shifting issues during removal. Invalid indices are silently ignored.
        :raises TypeError: If indices is not a list or contains non-integer values.
        """
