import aioboto3
from _typeshed import Incomplete
from enum import Enum
from typing import Any
from virtualitics_sdk.triggers import Trigger as Trigger
from virtualitics_sdk.types.callbacks import PageUpdateCallback as PageUpdateCallback

logger: Incomplete

class S3TriggerMode(Enum):
    """
    Modes for S3 trigger behavior.

    EXISTS: Trigger when object exists at path
    CHANGED: Trigger when object content changes (uses ETag)
    NEW: Trigger when new objects appear in prefix
    """
    EXISTS: str
    CHANGED: str
    NEW: str

class S3Trigger(Trigger):
    '''
    Trigger that monitors S3 objects for existence or content changes.

    NOTE: All triggers are checked by APScheduler every N seconds (configurable via
    TRIGGER_CHECK_INTERVAL env var, default 10 seconds). When a trigger\'s condition is met,
    an ARQ job is enqueued to execute the callback.

    Uses shared connection pooling across all S3Trigger instances for better performance.

    Examples:
        # Trigger when file exists
        trigger = S3Trigger(
            name="data_ready",
            bucket="my-bucket",
            key="data/output.csv",
            mode=S3TriggerMode.EXISTS,
            callback=on_data_ready,
        )

        # Trigger when file content changes
        trigger = S3Trigger(
            name="config_updated",
            bucket="my-bucket",
            key="config/settings.json",
            mode=S3TriggerMode.CHANGED,
            callback=on_config_updated,
        )

        # Trigger when new files appear in prefix
        trigger = S3Trigger(
            name="new_uploads",
            bucket="my-bucket",
            prefix="uploads/",
            mode=S3TriggerMode.NEW,
            callback=on_new_upload,
        )
    '''
    def __init__(self, name: str, bucket: str | None = None, key: str | None = None, prefix: str | None = None, mode: S3TriggerMode = ..., app_id: str | None = None, flow_id: str | None = None, user_id: str | None = None, callback: PageUpdateCallback | None = None, region_name: str | None = None, endpoint_url: str | None = None, organization_id: str | None = None, trigger_metadata: dict[str, Any] | None = None, trigger_id: str | None = None, max_retries: int = 3, step_name: str | None = None, dry_run: bool = False, min_size: int | None = None, max_size: int | None = None, file_pattern: str | None = None, content_type: str | None = None, callback_kwargs: dict[str, Any] | None = None, pass_store_interface: bool = True) -> None:
        '''
        Initialize S3 trigger.

        NOTE: All triggers are checked by APScheduler every N seconds (default 10s,
        configurable via TRIGGER_CHECK_INTERVAL env var).

        Runtime parameters (app_id, flow_id, user_id, callback, step_name) can be provided
        at initialization or later via the configure() method.

        :param name: Trigger name
        :param bucket: S3 bucket name
        :param key: S3 object key (for EXISTS/CHANGED modes)
        :param prefix: S3 prefix (for NEW mode)
        :param mode: Trigger mode (EXISTS, CHANGED, or NEW)
        :param app_id: App ID (optional, set at activation)
        :param flow_id: Flow ID (optional, set at activation)
        :param user_id: User ID (optional, set at activation)
        :param callback: Callback to execute (optional, set at activation)
        :param region_name: AWS region (defaults to config)
        :param endpoint_url: S3 endpoint URL (defaults to config)
        :param organization_id: Organization ID (optional, set at activation)
        :param trigger_metadata: Additional metadata
        :param trigger_id: Unique trigger ID
        :param max_retries: Max retry attempts
        :param step_name: Step name to associate with trigger (optional)
        :param dry_run: If True, log what would execute without actually executing callbacks
        :param min_size: Minimum file size in bytes (filter for EXISTS/CHANGED modes)
        :param max_size: Maximum file size in bytes (filter for EXISTS/CHANGED modes)
        :param file_pattern: Regex pattern for filename filtering
        :param content_type: MIME type filter (e.g., "application/json", "text/csv")
        :param callback_kwargs: Additional keyword arguments to pass to callback (will be pickled)
        :param pass_store_interface: If True (default), pass store_interface to callback
        '''
    async def check(self) -> bool:
        """
        Check if trigger condition is met.

        :return: True if condition met, False otherwise
        """
    async def stop(self) -> None:
        """
        Stop the trigger and cleanup resources.

        Closes the aioboto3 session to prevent resource leaks.
        """
    @classmethod
    async def get_shared_session(cls) -> aioboto3.Session:
        """
        Get or create shared S3 session with connection pooling.

        This session is shared across all S3Trigger instances to reduce
        connection overhead and improve performance.

        :return: Shared aioboto3 session
        """
    def to_dict(self) -> dict[str, Any]:
        """
        Serialize trigger to dictionary.

        Overrides base to include S3-specific fields.

        :return: Dictionary representation
        """
