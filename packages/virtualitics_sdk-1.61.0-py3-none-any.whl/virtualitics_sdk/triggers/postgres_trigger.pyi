from _typeshed import Incomplete
from enum import Enum
from sqlalchemy.sql.selectable import Select
from typing import Any
from virtualitics_sdk.triggers import Trigger as Trigger
from virtualitics_sdk.types.callbacks import PageUpdateCallback as PageUpdateCallback

logger: Incomplete

class PostgresTriggerMode(Enum):
    """
    Modes for PostgreSQL trigger behavior.

    EXISTS: Trigger when query returns at least one row
    CHANGED: Trigger when query results change (tracks hash of results)
    NEW: Trigger when new records appear (tracks set of IDs)
    COUNT: Trigger when count meets or exceeds threshold
    """
    EXISTS: str
    CHANGED: str
    NEW: str
    COUNT: str

class PostgresTrigger(Trigger):
    '''
    Trigger that monitors PostgreSQL database records and executes callbacks when conditions are met.

    NOTE: All triggers are checked by APScheduler every N seconds (configurable via
    TRIGGER_CHECK_INTERVAL env var, default 10 seconds). When a trigger\'s condition is met,
    an ARQ job is enqueued to execute the callback.

    Supports both internal store database (predict_configs.store_engine_uri) and external PostgreSQL
    databases (via connection_store connection_id).

    Security features:
    - Only accepts SQLAlchemy Select objects (prevents SQL injection)
    - Uses connection pooling to prevent resource exhaustion
    - Leverages connection_store encryption for credentials
    - Implements query timeouts to prevent long-running queries

    Examples:
        # Trigger when active users exist
        from sqlalchemy import select, table, column

        users_table = table(\'users\', column(\'id\'), column(\'status\'))
        query = select(users_table).where(users_table.c.status == \'active\')

        trigger = PostgresTrigger(
            name="active_users_monitor",
            query=query,
            mode=PostgresTriggerMode.EXISTS,
            connection_id="my_postgres_connection",
            callback=my_callback,
        )

        # Trigger when data changes
        trigger = PostgresTrigger(
            name="data_change_monitor",
            query=select(my_table),
            mode=PostgresTriggerMode.CHANGED,
            use_store_uri=True,
            callback=on_data_changed,
        )

        # Trigger when new records appear
        query = select(events_table.c.id).order_by(events_table.c.created_at)
        trigger = PostgresTrigger(
            name="new_events_monitor",
            query=query,
            mode=PostgresTriggerMode.NEW,
            connection_id="events_db",
            callback=process_new_events,
        )

        # Trigger when count threshold met
        query = select(alerts_table)
        trigger = PostgresTrigger(
            name="alert_threshold_monitor",
            query=query,
            mode=PostgresTriggerMode.COUNT,
            count_threshold=10,  # Trigger when >= 10 alerts
            use_store_uri=True,
            callback=handle_alert_threshold,
        )
    '''
    def __init__(self, name: str, query: Select, mode: PostgresTriggerMode = ..., connection_id: str | None = None, use_store_uri: bool = False, count_threshold: int | None = None, app_id: str | None = None, flow_id: str | None = None, user_id: str | None = None, callback: PageUpdateCallback | None = None, organization_id: str | None = None, trigger_metadata: dict[str, Any] | None = None, trigger_id: str | None = None, max_retries: int = 3, step_name: str | None = None, dry_run: bool = False, callback_kwargs: dict[str, Any] | None = None, pass_store_interface: bool = True, query_timeout: int = 30) -> None:
        """
        Initialize PostgreSQL trigger.

        NOTE: All triggers are checked by APScheduler every N seconds (default 10s,
        configurable via TRIGGER_CHECK_INTERVAL env var).

        Runtime parameters (app_id, flow_id, user_id, callback, step_name) can be provided
        at initialization or later via the configure() method.

        :param name: Trigger name
        :param query: SQLAlchemy Select statement to execute
        :param mode: Trigger mode (EXISTS, CHANGED, NEW, or COUNT)
        :param connection_id: Connection ID from connection_store (optional)
        :param use_store_uri: If True, use predict_configs.store_engine_uri (default False)
        :param count_threshold: Threshold for COUNT mode (required if mode=COUNT)
        :param app_id: App ID (optional, set at activation)
        :param flow_id: Flow ID (optional, set at activation)
        :param user_id: User ID (optional, set at activation)
        :param callback: Callback to execute (optional, set at activation)
        :param organization_id: Organization ID (optional, set at activation)
        :param trigger_metadata: Additional metadata
        :param trigger_id: Unique trigger ID
        :param max_retries: Max retry attempts
        :param step_name: Step name to associate with trigger (optional)
        :param dry_run: If True, log what would execute without actually executing callbacks
        :param callback_kwargs: Additional keyword arguments to pass to callback (will be pickled)
        :param pass_store_interface: If True (default), pass store_interface to callback
        :param query_timeout: Query execution timeout in seconds (default 30)
        """
    async def check(self) -> bool:
        """
        Check if trigger condition is met.

        :return: True if condition met, False otherwise
        """
    async def execute(self) -> None:
        """
        Execute the callback with matched records.

        Overrides parent execute() to pass matched records as a kwarg 'records'.
        """
    async def stop(self) -> None:
        """
        Stop the trigger and cleanup resources.

        Note: We don't dispose of the shared engine pool here since other
        trigger instances may still be using it. Engines will be cleaned up
        when the process exits or during worker shutdown.
        """
    def to_dict(self) -> dict[str, Any]:
        """
        Serialize trigger to dictionary.

        Overrides base to include PostgreSQL-specific fields.

        :return: Dictionary representation
        """
