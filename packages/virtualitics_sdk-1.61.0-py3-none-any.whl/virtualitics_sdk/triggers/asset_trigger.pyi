from _typeshed import Incomplete
from enum import Enum
from typing import Any
from virtualitics_sdk.triggers.postgres_trigger import PostgresTrigger as PostgresTrigger, PostgresTriggerMode as PostgresTriggerMode
from virtualitics_sdk.types.callbacks import PageUpdateCallback as PageUpdateCallback

logger: Incomplete

class AssetTriggerMode(Enum):
    """
    Modes for Asset trigger behavior.

    CREATED: Trigger when a new asset is created matching criteria
    CHANGED: Trigger when an existing asset is updated/modified
    """
    CREATED: str
    CHANGED: str

class AssetTrigger(PostgresTrigger):
    '''
    Specialized trigger for monitoring assets in the asset store.

    NOTE: All triggers are checked by APScheduler every N seconds (configurable via
    TRIGGER_CHECK_INTERVAL env var, default 10 seconds). When a trigger\'s condition is met,
    an ARQ job is enqueued to execute the callback.

    Inherits from PostgresTrigger and provides asset-specific monitoring capabilities.
    Automatically connects to the internal asset store database.

    Key Features:
    - Monitors asset creation (CREATED mode)
    - Monitors asset updates (CHANGED mode)
    - Filters by asset_id, asset_name, asset_type, label, user_id
    - Automatically enforces organization_id from user for multi-tenancy security
    - Tracks state to detect new/changed assets

    Security:
    - AssetTrigger ALWAYS enforces the organization_id of the user who created it
    - Users can ONLY monitor assets within their own organization
    - organization_id is not a configurable parameter and is set automatically

    Examples:
        # Trigger when a specific asset is created
        trigger = AssetTrigger(
            name="dataset_created_monitor",
            mode=AssetTriggerMode.CREATED,
            asset_name="customer_data",
            asset_type="dataset",
            callback=on_asset_created,
        )

        # Trigger when any asset for a user changes
        trigger = AssetTrigger(
            name="user_asset_monitor",
            mode=AssetTriggerMode.CHANGED,
            user_id="user123",
            callback=on_asset_changed,
        )

        # Trigger when assets with specific label are created
        # (organization_id automatically set from user)
        trigger = AssetTrigger(
            name="labeled_assets_monitor",
            mode=AssetTriggerMode.CREATED,
            label="production",
            asset_type="model",
            callback=on_labeled_asset_created,
        )
    '''
    def __init__(self, name: str, mode: AssetTriggerMode = ..., asset_id: str | None = None, asset_name: str | None = None, asset_type: str | None = None, label: str | None = None, user_id: str | None = None, app_id: str | None = None, flow_id: str | None = None, callback: PageUpdateCallback | None = None, trigger_metadata: dict[str, Any] | None = None, trigger_id: str | None = None, max_retries: int = 3, step_name: str | None = None, dry_run: bool = False, callback_kwargs: dict[str, Any] | None = None, pass_store_interface: bool = True, query_timeout: int = 30) -> None:
        '''
        Initialize Asset trigger.

        NOTE: All triggers are checked by APScheduler every N seconds (default 10s,
        configurable via TRIGGER_CHECK_INTERVAL env var).

        NOTE: organization_id is automatically enforced during trigger activation
        (via configure()) to match the user\'s actual organization for security.

        :param name: Trigger name
        :param mode: AssetTriggerMode (CREATED or CHANGED)
        :param asset_id: Specific asset ID to monitor (optional)
        :param asset_name: Asset name pattern to match (optional)
        :param asset_type: Asset type to filter by (e.g., "dataset", "model") (optional)
        :param label: Asset label to filter by (optional)
        :param user_id: User ID to filter assets by (optional, set at activation if not provided)
        :param app_id: App ID (optional, set at activation)
        :param flow_id: Flow ID (optional, set at activation)
        :param callback: Callback to execute (optional, set at activation)
        :param trigger_metadata: Additional metadata
        :param trigger_id: Unique trigger ID
        :param max_retries: Max retry attempts
        :param step_name: Step name to associate with trigger (optional)
        :param dry_run: If True, log what would execute without actually executing callbacks
        :param callback_kwargs: Additional keyword arguments to pass to callback
        :param pass_store_interface: If True (default), pass store_interface to callback
        :param query_timeout: Query execution timeout in seconds (default 30)
        '''
    def configure(self, app_id: str, flow_id: str, user_id: str, callback: PageUpdateCallback, organization_id: str | None = None, trigger_id: str | None = None, step_name: str | None = None, callback_kwargs: dict[str, Any] | None = None, pass_store_interface: bool | None = None) -> None:
        """
        Configure runtime parameters for the AssetTrigger.

        Automatically fetches and enforces organization_id from user_id to ensure
        assets are only monitored within the user's organization

        :param app_id: ID of the app this trigger belongs to
        :param flow_id: ID of the flow instance
        :param user_id: ID of the user who owns this trigger
        :param callback: PageUpdateCallback to execute when trigger conditions are met
        :param organization_id: Organization ID (will be overridden with user's organization)
        :param trigger_id: Optional trigger ID to override the auto-generated one
        :param step_name: Step name to associate with trigger
        :param callback_kwargs: Additional keyword arguments to pass to callback
        :param pass_store_interface: If True, pass store_interface to callback
        """
    async def check(self) -> bool:
        """
        Check if trigger condition is met.

        Rebuilds the query on each check to ensure current user permissions are used.
        This allows the trigger to pick up permission changes without reconfiguration.

        :return: True if condition met, False otherwise
        """
    async def execute(self) -> None:
        """
        Execute the callback with matched asset_ids.

        Overrides parent execute() to pass asset_ids as a kwarg instead of full records.
        """
    def to_dict(self) -> dict[str, Any]:
        """
        Serialize trigger to dictionary.

        Overrides parent to include asset-specific fields.

        :return: Dictionary representation
        """
