from typing import Any, Literal
from virtualitics_sdk.triggers import Trigger as Trigger
from virtualitics_sdk.types.callbacks import PageUpdateCallback as PageUpdateCallback

class CompositeTrigger(Trigger):
    '''
    Trigger that combines multiple triggers with AND/OR logic.

    Example:
        # Trigger when BOTH conditions are met
        trigger = CompositeTrigger(
            name="data_pipeline_ready",
            triggers=[
                S3Trigger(..., key="input/data.csv", mode=S3TriggerMode.EXISTS),
                S3Trigger(..., key="config/settings.json", mode=S3TriggerMode.CHANGED),
            ],
            logic=\'AND\',
            callback=run_pipeline
        )

        # Trigger when ANY condition is met
        trigger = CompositeTrigger(
            name="alert_on_any_change",
            triggers=[
                S3Trigger(..., key="alert1.txt"),
                S3Trigger(..., key="alert2.txt"),
            ],
            logic=\'OR\',
            callback=send_alert
        )
    '''
    def __init__(self, name: str, triggers: list[Trigger], logic: Literal['AND', 'OR'] = 'AND', poll_frequency: int = 60, app_id: str | None = None, flow_id: str | None = None, user_id: str | None = None, callback: PageUpdateCallback | None = None, organization_id: str | None = None, trigger_metadata: dict[str, Any] | None = None, trigger_id: str | None = None, max_retries: int = 3, step_name: str | None = None, dry_run: bool = False, callback_kwargs: dict[str, Any] | None = None, pass_store_interface: bool = True) -> None:
        """
        Initialize composite trigger.

        :param name: Trigger name
        :param triggers: List of sub-triggers to combine
        :param logic: Combination logic - 'AND' (all must be True) or 'OR' (any must be True)
        :param poll_frequency: Check frequency in seconds
        :param app_id: App ID (optional, set at activation)
        :param flow_id: Flow ID (optional, set at activation)
        :param user_id: User ID (optional, set at activation)
        :param callback: Callback to execute (optional, set at activation)
        :param organization_id: Organization ID (optional, set at activation)
        :param trigger_metadata: Additional metadata
        :param trigger_id: Unique trigger ID
        :param max_retries: Max retry attempts
        :param step_name: Step name to associate with trigger (optional)
        :param dry_run: If True, log what would execute without actually executing callbacks
        :param callback_kwargs: Additional keyword arguments to pass to callback (will be pickled)
        :param pass_store_interface: If True (default), pass store_interface to callback
        """
    async def check(self) -> bool:
        """
        Check all sub-triggers and apply logic.

        :return: True if composite condition is met based on logic
        """
    def to_dict(self) -> dict[str, Any]:
        """
        Serialize trigger to dictionary.

        :return: Dictionary representation
        """
