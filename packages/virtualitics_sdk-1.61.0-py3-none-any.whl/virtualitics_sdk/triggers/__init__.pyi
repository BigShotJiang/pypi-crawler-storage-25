from _typeshed import Incomplete
from abc import ABC, abstractmethod
from typing import Any
from virtualitics_sdk.triggers.asset_trigger import AssetTrigger as AssetTrigger, AssetTriggerMode as AssetTriggerMode
from virtualitics_sdk.triggers.postgres_trigger import PostgresTrigger as PostgresTrigger, PostgresTriggerMode as PostgresTriggerMode
from virtualitics_sdk.types.callbacks import PageUpdateCallback as PageUpdateCallback

logger: Incomplete

class Trigger(ABC):
    """
    Base class for all triggers

    Triggers define conditions that, when met, execute a callback to update an app's page.
    Examples include S3 object changes, database record updates, or custom conditions.

    Triggers persist to the database and run as background arq jobs in the worker.
    """
    def __init__(self, name: str, app_id: str | None = None, flow_id: str | None = None, user_id: str | None = None, callback: PageUpdateCallback | None = None, organization_id: str | None = None, trigger_metadata: dict[str, Any] | None = None, trigger_id: str | None = None, max_retries: int = 3, step_name: str | None = None, dry_run: bool = False, callback_kwargs: dict[str, Any] | None = None, pass_store_interface: bool = True) -> None:
        """
        Initialize a trigger instance.

        Runtime parameters (app_id, flow_id, user_id, callback, step_name) can be provided
        at initialization or later via the configure() method.

        All triggers are checked by APScheduler at a configured interval (default: 10s).

        :param name: Human-readable trigger name
        :param app_id: ID of the app this trigger belongs to (optional, set at activation)
        :param flow_id: ID of the flow instance (optional, set at activation)
        :param user_id: ID of the user who owns this trigger (optional, set at activation)
        :param callback: PageUpdateCallback to execute when trigger conditions are met (optional, set at activation)
        :param organization_id: Organization ID for multi-tenancy (optional, set at activation)
        :param trigger_metadata: Additional trigger-specific configuration
        :param trigger_id: Unique trigger ID (auto-generated if not provided)
        :param max_retries: Maximum number of retry attempts on failure
        :param step_name: Step name to associate with trigger (optional, defaults to first step at activation)
        :param dry_run: If True, log what would execute without actually executing callbacks
        :param callback_kwargs: Additional keyword arguments to pass to the callback (will be pickled and stored)
        :param pass_store_interface: If True (default), pass store_interface to callback. If False, only pass callback_kwargs
        """
    def configure(self, app_id: str, flow_id: str, user_id: str, callback: PageUpdateCallback, organization_id: str | None = None, trigger_id: str | None = None, step_name: str | None = None, callback_kwargs: dict[str, Any] | None = None, pass_store_interface: bool | None = None) -> None:
        """
        Configure runtime parameters for the trigger.

        This method should be called when activating an app to set the
        app_id, flow_id, user_id, callback, and step_name that are only known at runtime.

        :param app_id: ID of the app this trigger belongs to
        :param flow_id: ID of the flow instance
        :param user_id: ID of the user who owns this trigger
        :param callback: PageUpdateCallback to execute when trigger conditions are met
        :param organization_id: Organization ID for multi-tenancy
        :param trigger_id: Optional trigger ID to override the auto-generated one
        :param step_name: Step name to associate with trigger (optional)
        :param callback_kwargs: Additional keyword arguments to pass to the callback
        :param pass_store_interface: If True, pass store_interface to callback (overrides initialization value)
        """
    def is_configured(self) -> bool:
        """
        Check if the trigger has been configured with runtime parameters.

        :return: True if all required runtime parameters are set
        """
    @abstractmethod
    async def check(self) -> bool:
        """
        Check if the trigger condition has been met.

        This method should be implemented by subclasses to define the specific
        condition logic (e.g., check if S3 object exists, check DB value, etc.)

        :return: True if the trigger condition is met, False otherwise
        """
    async def execute(self) -> None:
        """
        Execute the trigger callback with proper error handling.

        In dry-run mode, logs what would execute without calling the callback.
        Calls the page update callback with the appropriate context and handles
        any errors that occur during execution.
        """
    async def start(self) -> None:
        """
        Start the trigger, marking it as active.

        This is called when the trigger is first created or reactivated.
        Subclasses can override to perform additional setup.
        """
    async def stop(self) -> None:
        """
        Stop the trigger gracefully.

        This is called when the trigger should be deactivated.
        Subclasses can override to perform cleanup.
        """
    def get_state(self) -> dict[str, Any] | None:
        """
        Get the current trigger state.

        :return: Dictionary containing the last known state, or None if no state
        """
    def set_state(self, state: dict[str, Any]) -> None:
        """
        Set the trigger state.

        This is used to track changes between checks (e.g., last S3 ETag, last DB timestamp).

        :param state: Dictionary containing state to track
        """
    def get_metrics(self) -> dict[str, Any]:
        """
        Get trigger execution metrics.

        :return: Dictionary containing execution statistics
        """
    def to_dict(self) -> dict[str, Any]:
        """
        Serialize trigger to a dictionary for database persistence.

        :return: Dictionary representation of the trigger
        """
    @property
    def id(self) -> str:
        """Get the unique trigger ID"""
    @property
    def name(self) -> str:
        """Get the trigger name"""
    @property
    def is_running(self) -> bool:
        """Check if the trigger is currently active"""
    @property
    def should_retry(self) -> bool:
        """Check if the trigger should retry after a failure"""
