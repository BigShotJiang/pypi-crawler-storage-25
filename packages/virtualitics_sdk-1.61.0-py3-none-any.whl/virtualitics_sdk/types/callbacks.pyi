from _typeshed import Incomplete
from enum import Enum
from typing import Any, Coroutine, Protocol
from virtualitics_sdk.assets.asset import Asset as Asset
from virtualitics_sdk.page.card import Card as Card
from virtualitics_sdk.page.drilldown import DrilldownSize as DrilldownSize, DrilldownType as DrilldownType
from virtualitics_sdk.store.drilldown_store_interface import DrilldownStoreInterface as DrilldownStoreInterface
from virtualitics_sdk.store.store_interface import StoreInterface as StoreInterface

class CallbackType(Enum):
    STANDARD: str
    ASSET_DOWNLOAD: str
    DRILLDOWN: str
    PAGE_UPDATE: str
    CONTAINER_TOGGLE: str

class CallbackReturnType(Enum):
    CARD: str
    PAGE: str
    TEXT: str
    HEADLESS: str

CALLBACK_EXECUTABLE_TYPES: Incomplete

class DrilldownCallback(Protocol):
    """
    Protocol defining the required callback signature.
    Any callable matching this signature can be used as a drilldown callback.
    """
    def __call__(self, card: Card, input_data: dict[str, str | float | int], store_interface: DrilldownStoreInterface) -> Coroutine[Any, Any, None]:
        """
        Process drilldown data and add content to the card.

        :param card: Card object to add content to
        :param input_data: Dictionary containing input parameters related to the element that was engaged to trigger
                           this modal/popover
        :param store_interface: Optimal Interface for accessing persisted objects during modal/popover creation
        """

class PageUpdateCallback(Protocol):
    """Protocol/Type Hint for the CallbackType.PAGE_UPDATE typed callback.

    The callback must be an async function with the following signature::

        async def example_callback(store_interface: StoreInterface,
                                   **step_clients: dict[str, Any] | None) -> None:
    """
    def __call__(self, store_interface: StoreInterface, input_data: dict[str, Any] | None, **step_clients: dict[str, Any] | None) -> Coroutine[Any, Any, None]:
        """
        :param store_interface: StoreInterface for modifying the page object and accessing stored data
        :param input_data: Optional dictionary containing input parameters
        :param step_clients: The pre-initialized clients (pyvip, etc) for the step passed as keyword arguments
        """

class StandardEventCallback(Protocol):
    '''Protocol/Type Hint for the CallbackType.STANDARD typed callback.

    The callback must be an async function with the following signature::

        async def example_callback(store_interface: StoreInterface,
                                   **step_clients: dict[str, Any] | None) -> str:
            return "success message"
    '''
    def __call__(self, store_interface: StoreInterface, **step_clients: dict[str, Any] | None) -> Coroutine[Any, Any, str]:
        """
        :param store_interface: StoreInterface for modifying the page object and accessing stored data
        :param step_clients: The pre-initialized clients (pyvip, etc) for the step passed as keyword arguments
        """

class ContainerToggleCallback:
    container_id: Incomplete
    callback_type: Incomplete
    visibility: Incomplete
    def __init__(self, visible: bool, container_id: str) -> None: ...

class AssetDownloadCallback:
    """
    Configure the asset to be downloaded.

    :param asset: Object with ``id``, ``type``, ``label``, ``name``, ``time_created``.
    :param extension: File extension for the download.
    :param mime_type: Mime type of the download.
    :param label: Optional override for the download label (defaults to ``asset.label``).
    """
    asset: Incomplete
    extension: Incomplete
    mime_type: Incomplete
    label: Incomplete
    callback_type: Incomplete
    def __init__(self, asset: Asset, extension: str = 'csv', mime_type: str | None = None, label: str | None = None) -> None: ...

def page_update_callback(func: PageUpdateCallback): ...
def auto_refresh_callback(refresh_rate_seconds: int = 500): ...
def row_action_callback(title: str): ...
def drilldown_callback(drilldown_type: DrilldownType, drilldown_size: DrilldownSize):
    """
        :param drilldown_type: DrilldownType.MODAL or DrilldownType.POPOVER
        :param drilldown_size: DrilldownSize.SMALL, MEDIUM, LARGE, SHEET
    """
def standard_event_callback(func: StandardEventCallback): ...
Callback = StandardEventCallback | PageUpdateCallback | DrilldownCallback | ContainerToggleCallback | AssetDownloadCallback
CallbackExecutable = StandardEventCallback | PageUpdateCallback | DrilldownCallback
