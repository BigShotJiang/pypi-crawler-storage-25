def build_model(model_uri: str):
    """Resolve a model URI string to a pydantic-ai model instance.

    Supported prefixes:

    **bedrock:** → BedrockConverseModel (AWS)
      - ``bedrock:MODEL``
      - ``bedrock:REGION/MODEL``
      - ``bedrock:REGION/MODEL?endpoint_url=URL&profile=PROFILE``

    **openai:** → OpenAIChatModel (OpenAI-compatible)
      - ``openai:MODEL``
      - ``openai:MODEL?base_url=URL``

    **ollama:** → OpenAIChatModel (OpenAI-compatible)
      - ``ollama:MODEL``
      - ``ollama:MODEL?base_url=URL``

    **anthropic:** → AnthropicModel (direct API)
      - ``anthropic:MODEL``

    **vertex:** → AnthropicModel via Vertex AI
      - ``vertex:MODEL``
      - ``vertex:REGION/MODEL``

    **(no prefix)** → passed through as a bare string for pydantic-ai default resolution

    :param model_uri: The model URI string to resolve.
    :return: A pydantic-ai model instance or a string for default resolution.
    """
def build_default_model_from_llm_host(llm_host: str, model_name: str):
    """Build a default pydantic_ai model from the platform's llm_host and model_name.

    Resolution order:

    1. If ``model_name`` contains a provider prefix (e.g. ``vertex:us-east5/claude-...``),
       ``build_model`` handles resolution directly. Any query parameters on
       ``llm_host`` (e.g. ``?project=X``) are merged into the model URI so
       host-level configuration is not lost.
    2. If ``llm_host`` uses the virt_llm URI format with a provider in the path
       (e.g. ``http://host:11434/ollama``, ``aws://us-gov-west-1/bedrock``,
       ``gcp://us-east5/vertex``), the provider and connection parameters are
       extracted from the URI and used to build the model.
    3. Otherwise ``llm_host`` is treated as a plain base URL and an
       OpenAI-compatible model is constructed pointing at ``{llm_host}/v1``.

    :param llm_host: The LLM host URI (e.g. ``http://ollama:11434/ollama``).
    :param model_name: The model name (e.g. ``llama3``).
    :return: A pydantic-ai model instance.
    """
