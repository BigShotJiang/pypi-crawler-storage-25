from _typeshed import Incomplete
from virtualitics_sdk.llm.types import ModalContentResult as ModalContentResult, RawChatContext as RawChatContext

logger: Incomplete

class ModalContentReader:
    '''Read and extract content from modal/drilldown callbacks.

    This class handles the full lifecycle of discovering modal content:
    1. Validates that the element has a drilldown callback
    2. Executes the callback to generate the modal card
    3. Extracts structured content and preserves live Element objects

    Supports both regular buttons and table buttons (with row context).

    Examples:
        # Regular button
        reader = ModalContentReader(button_id="button/abc-123", context=chat_context)
        formatted_context, elements, element_map = await reader.execute()

        # Table button with row data
        reader = ModalContentReader(
            button_id="button/xyz",
            context=chat_context,
            table_id="table/products",
            row_data={"id": 1, "name": "Widget"},
            row_index=5
        )
        formatted_context, elements, element_map = await reader.execute()
    '''
    SUPPORTED_ELEMENT_TYPES: Incomplete
    button_id: Incomplete
    context: Incomplete
    kwargs: Incomplete
    element_type: Incomplete
    def __init__(self, button_id: str, context: RawChatContext, **kwargs) -> None:
        """Initialize the reader.

        Args:
            button_id: Element ID (e.g., 'button/abc-123')
            context: Chat context with user_id, chat_id (flow_id), step_name
            **kwargs: Additional parameters:
                - table_id (str): For table buttons, the ID of the parent table
                - row_data (dict): For table buttons, the row data as dict
                - row_index (int): For table buttons, the row index
        """
    async def execute(self) -> ModalContentResult:
        """Execute the modal content reader.

        Returns:
            ModalContentResult with:
            - formatted_context: LLM-ready markdown string
            - elements: List of live Element objects (for data access)
            - element_map: Dict mapping element IDs to Element objects
        """
