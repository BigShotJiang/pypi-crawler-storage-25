from types import SimpleNamespace

from typer.testing import CliRunner

from hypercli_cli.cli import app


runner = CliRunner()
FULL_JOB_ID = "123e4567-e89b-12d3-a456-426614174000"


def test_jobs_exec_mock(monkeypatch):
    class FakeJobs:
        def exec(self, job_id, command, timeout=30):
            assert job_id == FULL_JOB_ID
            assert command == "echo hi"
            assert timeout == 9
            return SimpleNamespace(stdout="hi\n", stderr="", exit_code=0)

    fake_client = SimpleNamespace(jobs=FakeJobs())

    monkeypatch.setattr("hypercli_cli.jobs.get_client", lambda: fake_client)
    monkeypatch.setattr("hypercli_cli.jobs._resolve_job_id", lambda client, job_id: job_id)

    result = runner.invoke(app, ["jobs", "exec", FULL_JOB_ID, "echo hi", "--timeout", "9"])

    assert result.exit_code == 0
    assert "hi" in result.stdout


def test_jobs_get_shows_command_and_env(monkeypatch):
    class FakeJobs:
        def list(self):
            return [SimpleNamespace(job_id=FULL_JOB_ID)]

        def get(self, job_id):
            assert job_id == FULL_JOB_ID
            return SimpleNamespace(
                job_id=job_id,
                state="terminated",
                gpu_type="H200",
                gpu_count=8,
                region="oh",
                docker_image="vllm/vllm-openai:glm5",
                command="vllm serve zai-org/GLM-5-FP8 --host 0.0.0.0 --port 8000",
                env_vars={"LD_LIBRARY_PATH": "/usr/local/nvidia/lib64:/usr/local/nvidia/lib:/usr/lib/x86_64-linux-gnu"},
                runtime=3600,
            )

    fake_client = SimpleNamespace(jobs=FakeJobs())

    monkeypatch.setattr("hypercli_cli.jobs.get_client", lambda: fake_client)

    result = runner.invoke(app, ["jobs", "get", FULL_JOB_ID])

    assert result.exit_code == 0
    assert "vllm serve zai-org/GLM-5-FP8" in result.stdout
    assert "LD_LIBRARY_PATH" in result.stdout


def test_instances_launch_dry_run_mock(monkeypatch):
    captured = {}

    class FakeJobs:
        def create(self, **kwargs):
            captured.update(kwargs)
            return SimpleNamespace(
                job_id="job-dryrun",
                state="validated",
                gpu_type="l40s",
                gpu_count=1,
                region="oh",
                price_per_hour=1.23,
                runtime=300,
                cold_boot=False,
                hostname=None,
            )

    fake_client = SimpleNamespace(jobs=FakeJobs())
    monkeypatch.setattr("hypercli_cli.instances.get_client", lambda: fake_client)

    result = runner.invoke(
        app,
        [
            "instances",
            "launch",
            "nvidia/cuda:12.0-base-ubuntu22.04",
            "--dry-run",
            "--command",
            "echo hi",
            "--output",
            "json",
        ],
    )

    assert result.exit_code == 0
    assert captured["dry_run"] is True
    assert "job-dryrun" in result.stdout


def test_instances_launch_dry_run_includes_constraints(monkeypatch):
    captured = {}

    class FakeJobs:
        def create(self, **kwargs):
            captured.update(kwargs)
            return SimpleNamespace(
                job_id="job-dryrun",
                state="validated",
                gpu_type="h200",
                gpu_count=8,
                region="br",
                constraints={"cpu_vendor": "amd"},
                price_per_hour=12.34,
                runtime=300,
                cold_boot=False,
                hostname=None,
            )

    fake_client = SimpleNamespace(jobs=FakeJobs())
    monkeypatch.setattr("hypercli_cli.instances.get_client", lambda: fake_client)

    result = runner.invoke(
        app,
        [
            "instances",
            "launch",
            "nvidia/cuda:12.0-base-ubuntu22.04",
            "--dry-run",
            "--gpu",
            "h200",
            "--count",
            "8",
            "--cpu-vendor",
            "amd",
            "--constraint",
            "stack=prod",
            "--output",
            "json",
        ],
    )

    assert result.exit_code == 0
    assert captured["constraints"] == {"cpu_vendor": "amd", "stack": "prod"}


def test_agent_exec_command(monkeypatch):
    called = {}

    def fake_exec_cmd(agent_id, command, timeout=30):
        called["agent_id"] = agent_id
        called["command"] = command
        called["timeout"] = timeout

    monkeypatch.setattr("hypercli_cli.agents.exec_cmd", fake_exec_cmd)

    result = runner.invoke(app, ["agent", "exec", "agent-1", "echo ok", "--timeout", "7"])

    assert result.exit_code == 0
    assert called == {"agent_id": "agent-1", "command": "echo ok", "timeout": 7}


def test_agent_shell_command(monkeypatch):
    called = {}

    def fake_shell(agent_id):
        called["agent_id"] = agent_id

    monkeypatch.setattr("hypercli_cli.agents.shell", fake_shell)

    result = runner.invoke(app, ["agent", "shell", "agent-xyz"])

    assert result.exit_code == 0
    assert called["agent_id"] == "agent-xyz"


def test_agents_cp_reports_directory_path_error(monkeypatch, tmp_path):
    class FakeDeployments:
        def cp_from(self, _pod, src_path, dst_path):
            assert src_path == ".openclaw"
            assert str(dst_path).endswith("download")
            raise ValueError("Path is a directory: .openclaw. Use files_list(path) instead.")

    monkeypatch.setattr("hypercli_cli.agents._get_deployments_client", lambda: FakeDeployments())
    monkeypatch.setattr("hypercli_cli.agents._get_pod_with_token", lambda agent_id: SimpleNamespace(id=agent_id))

    result = runner.invoke(app, ["agents", "cp", "agent-xyz:.openclaw", str(tmp_path / "download")])

    assert result.exit_code == 1
    assert "Path is a directory: .openclaw." in result.stdout
    assert "Copy expects a file path, not a directory." in result.stdout
