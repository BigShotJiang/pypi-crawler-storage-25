from fastmcp import FastMCP
mcp = FastMCP()

@mcp.tool()
def print_hello():
    print("Hello")

@mcp.tool()
def print_hi():
    print("Hi")
