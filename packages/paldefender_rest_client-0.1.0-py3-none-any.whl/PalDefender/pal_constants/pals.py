from enum import Enum

class PalId(str, Enum):
    Nyafia = "BadCatgirl"
    Prunelia = "BlueberryFairy"
    Gildane = "GoldenHorse"
    Turtacle = "TentacleTurtle"
    TurtacleTerra = "TentacleTurtle_Ground"
    Anubis = "Anubis"
    Incineram = "Baphomet"
    IncineramNoct = "Baphomet_Dark"
    Mau = "Bastet"
    MauCryst = "Bastet_Ice"
    Rushoar = "Boar"
    Lifmunk = "Carbunclo"
    Tocotoco = "ColorfulBird"
    Eikthyrdeer = "Deer"
    EikthyrdeerTerra = "Deer_Ground"
    Digtoise = "DrillGame"
    Galeclaw = "Eagle"
    Grizzbolt = "ElecPanda"
    Teafant = "Ganesha"
    Direhowl = "Garm"
    Gorirat = "Gorilla"
    GoriratTerra = "Gorilla_Ground"
    Jolthog = "Hedgehog"
    JolthogCryst = "Hedgehog_Ice"
    Univolt = "Kirin"
    Foxparks = "Kitsunebi"
    Bristla = "LittleBriarRose"
    Lunaris = "Mutant"
    Pengullet = "Penguin"
    PengulletLux = "Penguin_Electric"
    Dazzi = "RaijinDaughter"
    Gobfin = "SharkKid"
    GobfinIgnis = "SharkKid_Fire"
    Lamball = "SheepBall"
    Jormuntide = "Umihebi"
    JormuntideIgnis = "Umihebi_Fire"
    Loupmoon = "Werewolf"
    Hangyu = "WindChimes"
    HangyuCryst = "WindChimes_Ice"
    Suzaku = "Suzaku"
    SuzakuAqua = "Suzaku_Water"
    Pyrin = "FireKirin"
    PyrinNoct = "FireKirin_Dark"
    Elphidran = "FairyDragon"
    ElphidranAqua = "FairyDragon_Water"
    Woolipop = "SweetsSheep"
    Cryolinx = "WhiteTiger"
    Melpaca = "Alpaca"
    Surfent = "Serpent"
    SurfentTerra = "Serpent_Ground"
    Cawgnito = "DarkCrow"
    Azurobe = "BlueDragon"
    AzurobeCryst = "BlueDragon_Ice"
    Cattiva = "PinkCat"
    Depresso = "NegativeKoala"
    Fenglope = "FengyunDeeper"
    Reptyro = "VolcanicMonster"
    ReptyroCryst = "VolcanicMonster_Ice"
    Maraith = "GhostBeast"
    Robinquill = "RobinHood"
    RobinquillTerra = "RobinHood_Ground"
    Relaxaurus = "LazyDragon"
    RelaxaurusLux = "LazyDragon_Electric"
    Kitsun = "AmaterasuWolf"
    Leezpunk = "LizardMan"
    LeezpunkIgnis = "LizardMan_Fire"
    Fuack = "BluePlatypus"
    FuackIgnis = "BluePlatypus_Fire"
    Vanwyrm = "BirdDragon"
    VanwyrmCryst = "BirdDragon_Ice"
    Chikipi = "ChickenPal"
    Dinossom = "FlowerDinosaur"
    DinossomLux = "FlowerDinosaur_Electric"
    Sparkit = "ElecCat"
    Frostallion = "IceHorse"
    FrostallionNoct = "IceHorse_Dark"
    Mammorest = "GrassMammoth"
    MammorestCryst = "GrassMammoth_Ice"
    Felbat = "CatVampire"
    Broncherry = "SakuraSaurus"
    BroncherryAqua = "SakuraSaurus_Water"
    Faleris = "Horus"
    Blazamut = "KingBahamut"
    BlazamutRyu = "KingBahamut_Dragon"
    Caprity = "BerryGoat"
    Reindrix = "IceDeer"
    Shadowbeak = "BlackGriffon"
    Sibelyx = "WhiteMoth"
    Vixy = "CuteFox"
    Wixen = "FoxMage"
    WixenNoct = "FoxMage_Dark"
    Lovander = "PinkLizard"
    Hoocrates = "WizardOwl"
    Kelpsea = "Kelpie"
    KelpseaIgnis = "Kelpie_Fire"
    Killamari = "NegativeOctopus"
    KillamariPrimo = "NegativeOctopus_Neutral"
    Mozzarina = "CowPal"
    Wumpo = "Yeti"
    WumpoBotan = "Yeti_Grass"
    Vaelet = "VioletFairy"
    Nitewing = "HawkBird"
    Flopie = "FlowerRabbit"
    Lyleen = "LilyQueen"
    LyleenNoct = "LilyQueen_Dark"
    Elizabee = "QueenBee"
    Beegarde = "SoldierBee"
    Tombat = "CatBat"
    Mossanda = "GrassPanda"
    MossandaLux = "GrassPanda_Electric"
    Arsox = "FlameBuffalo"
    Rayhound = "ThunderDog"
    Fuddler = "CuteMole"
    Astegon = "BlackMetalDragon"
    Verdash = "GrassRabbitMan"
    Foxcicle = "IceFox"
    Jetragon = "JetDragon"
    Daedream = "DreamDemon"
    Tanzee = "Monkey"
    Blazehowl = "Manticore"
    BlazehowlNoct = "Manticore_Dark"
    Kingpaca = "KingAlpaca"
    KingpacaCryst = "KingAlpaca_Ice"
    Gumoss = "PlantSlime"
    Swee = "MopBaby"
    Sweepa = "MopKing"
    Katress = "CatMage"
    KatressIgnis = "CatMage_Fire"
    Ribbuny = "PinkRabbit"
    Beakon = "ThunderBird"
    Warsect = "HerculesBeetle"
    WarsectTerra = "HerculesBeetle_Ground"
    Paladius = "SaintCentaur"
    Nox = "NightFox"
    Penking = "CaptainPenguin"
    PenkingLux = "CaptainPenguin_Black"
    Chillet = "WeaselDragon"
    ChilletIgnis = "WeaselDragon_Fire"
    Quivern = "SkyDragon"
    QuivernBotan = "SkyDragon_Grass"
    Helzephyr = "HadesBird"
    HelzephyrLux = "HadesBird_Electric"
    Ragnahawk = "RedArmorBird"
    Bushi = "Ronin"
    BushiNoct = "Ronin_Dark"
    Celaray = "FlyingManta"
    CelarayLux = "FlyingManta_Thunder"
    Necromus = "BlackCentaur"
    Petallia = "FlowerDoll"
    Grintale = "NaughtyCat"
    Cinnamoth = "CuteButterfly"
    Menasting = "DarkScorpion"
    MenastingTerra = "DarkScorpion_Ground"
    Orserk = "ThunderDragonMan"
    Cremis = "WoolFox"
    Dumud = "LazyCatfish"
    DumudGild = "LazyCatfish_Gold"
    Flambelle = "LavaGirl"
    Rooby = "FlameBambi"
    Bellanoir = "NightLady"
    BellanoirLibero = "NightLady_Dark"
    Selyne = "MoonQueen"
    Croajiro = "KendoFrog"
    CroajiroNoct = "KendoFrog_Dark"
    Lullu = "LeafPrincess"
    Shroomer = "MushroomDragon"
    ShroomerNoct = "MushroomDragon_Dark"
    Kikit = "SmallArmadillo"
    Sootseer = "CandleGhost"
    Prixter = "ScorpionMan"
    Knocklem = "WingGolem"
    Yakumo = "GuardianDog"
    Dogen = "SifuDog"
    Dazemu = "FeatherOstrich"
    Mimog = "MimicDog"
    Xenovader = "DarkAlien"
    Xenogard = "WhiteAlienDragon"
    Xenolord = "DarkMechaDragon"
    Nitemary = "GhostRabbit"
    Starryon = "NightBlueHorse"
    Silvegis = "WhiteShieldDragon"
    Smokie = "BlackPuppy"
    Celesdir = "WhiteDeer"
    Omascul = "MysteryMask"
    Splatterina = "GrimGirl"
    Tarantriss = "PurpleSpider"
    Azurmane = "BlueThunderHorse"
    Gloopie = "OctopusGirl"
    Whalaska = "IceNarwhal"
    WhalaskaIgnis = "IceNarwhal_Fire"
    Jelliette = "JellyfishFairy"
    FoxparksCryst = "Kitsunebi_Ice"
    CaprityNoct = "BerryGoat_Dark"
    RibbunyBotan = "PinkRabbit_Grass"
    LoupmoonCryst = "Werewolf_Ice"
    KitsunNoct = "AmaterasuWolf_Dark"
    DazziNoct = "RaijinDaughter_Water"
    CryolinxTerra = "WhiteTiger_Ground"
    FenglopeLux = "FengyunDeeper_Electric"
    FalerisAqua = "Horus_Water"
    Bastigor = "SnowTigerBeastman"
    Ghangler = "GhostAnglerfish"
    GhanglerIgnis = "GhostAnglerfish_Fire"
    Icelyn = "IceWitch"
    Hartalis = "LegendDeer"
    Herbil = "LeafMomonga"
    Munchill = "IceCrocodile"
    Finsider = "StuffedShark"
    FinsiderIgnis = "StuffedShark_Fire"
    Polapup = "IceSeal"
    Braloha = "Plesiosaur"
    Palumba = "TropicalOstrich"
    Frostplume = "SnowPeafowl"
    Jellroy = "JellyfishGhost"
    Neptilius = "PoseidonOrca"

PAL_ID_TO_NAME = {
    PalId.Nyafia: "Nyafia",
    PalId.Prunelia: "Prunelia",
    PalId.Gildane: "Gildane",
    PalId.Turtacle: "Turtacle",
    PalId.TurtacleTerra: "Turtacle Terra",
    PalId.Anubis: "Anubis",
    PalId.Incineram: "Incineram",
    PalId.IncineramNoct: "Incineram Noct",
    PalId.Mau: "Mau",
    PalId.MauCryst: "Mau Cryst",
    PalId.Rushoar: "Rushoar",
    PalId.Lifmunk: "Lifmunk",
    PalId.Tocotoco: "Tocotoco",
    PalId.Eikthyrdeer: "Eikthyrdeer",
    PalId.EikthyrdeerTerra: "Eikthyrdeer Terra",
    PalId.Digtoise: "Digtoise",
    PalId.Galeclaw: "Galeclaw",
    PalId.Grizzbolt: "Grizzbolt",
    PalId.Teafant: "Teafant",
    PalId.Direhowl: "Direhowl",
    PalId.Gorirat: "Gorirat",
    PalId.GoriratTerra: "Gorirat Terra",
    PalId.Jolthog: "Jolthog",
    PalId.JolthogCryst: "Jolthog Cryst",
    PalId.Univolt: "Univolt",
    PalId.Foxparks: "Foxparks",
    PalId.Bristla: "Bristla",
    PalId.Lunaris: "Lunaris",
    PalId.Pengullet: "Pengullet",
    PalId.PengulletLux: "Pengullet Lux",
    PalId.Dazzi: "Dazzi",
    PalId.Gobfin: "Gobfin",
    PalId.GobfinIgnis: "Gobfin Ignis",
    PalId.Lamball: "Lamball",
    PalId.Jormuntide: "Jormuntide",
    PalId.JormuntideIgnis: "Jormuntide Ignis",
    PalId.Loupmoon: "Loupmoon",
    PalId.Hangyu: "Hangyu",
    PalId.HangyuCryst: "Hangyu Cryst",
    PalId.Suzaku: "Suzaku",
    PalId.SuzakuAqua: "Suzaku Aqua",
    PalId.Pyrin: "Pyrin",
    PalId.PyrinNoct: "Pyrin Noct",
    PalId.Elphidran: "Elphidran",
    PalId.ElphidranAqua: "Elphidran Aqua",
    PalId.Woolipop: "Woolipop",
    PalId.Cryolinx: "Cryolinx",
    PalId.Melpaca: "Melpaca",
    PalId.Surfent: "Surfent",
    PalId.SurfentTerra: "Surfent Terra",
    PalId.Cawgnito: "Cawgnito",
    PalId.Azurobe: "Azurobe",
    PalId.AzurobeCryst: "Azurobe Cryst",
    PalId.Cattiva: "Cattiva",
    PalId.Depresso: "Depresso",
    PalId.Fenglope: "Fenglope",
    PalId.Reptyro: "Reptyro",
    PalId.ReptyroCryst: "Reptyro Cryst",
    PalId.Maraith: "Maraith",
    PalId.Robinquill: "Robinquill",
    PalId.RobinquillTerra: "Robinquill Terra",
    PalId.Relaxaurus: "Relaxaurus",
    PalId.RelaxaurusLux: "Relaxaurus Lux",
    PalId.Kitsun: "Kitsun",
    PalId.Leezpunk: "Leezpunk",
    PalId.LeezpunkIgnis: "Leezpunk Ignis",
    PalId.Fuack: "Fuack",
    PalId.FuackIgnis: "Fuack Ignis",
    PalId.Vanwyrm: "Vanwyrm",
    PalId.VanwyrmCryst: "Vanwyrm Cryst",
    PalId.Chikipi: "Chikipi",
    PalId.Dinossom: "Dinossom",
    PalId.DinossomLux: "Dinossom Lux",
    PalId.Sparkit: "Sparkit",
    PalId.Frostallion: "Frostallion",
    PalId.FrostallionNoct: "Frostallion Noct",
    PalId.Mammorest: "Mammorest",
    PalId.MammorestCryst: "Mammorest Cryst",
    PalId.Felbat: "Felbat",
    PalId.Broncherry: "Broncherry",
    PalId.BroncherryAqua: "Broncherry Aqua",
    PalId.Faleris: "Faleris",
    PalId.Blazamut: "Blazamut",
    PalId.BlazamutRyu: "Blazamut Ryu",
    PalId.Caprity: "Caprity",
    PalId.Reindrix: "Reindrix",
    PalId.Shadowbeak: "Shadowbeak",
    PalId.Sibelyx: "Sibelyx",
    PalId.Vixy: "Vixy",
    PalId.Wixen: "Wixen",
    PalId.WixenNoct: "Wixen Noct",
    PalId.Lovander: "Lovander",
    PalId.Hoocrates: "Hoocrates",
    PalId.Kelpsea: "Kelpsea",
    PalId.KelpseaIgnis: "Kelpsea Ignis",
    PalId.Killamari: "Killamari",
    PalId.KillamariPrimo: "Killamari Primo",
    PalId.Mozzarina: "Mozzarina",
    PalId.Wumpo: "Wumpo",
    PalId.WumpoBotan: "Wumpo Botan",
    PalId.Vaelet: "Vaelet",
    PalId.Nitewing: "Nitewing",
    PalId.Flopie: "Flopie",
    PalId.Lyleen: "Lyleen",
    PalId.LyleenNoct: "Lyleen Noct",
    PalId.Elizabee: "Elizabee",
    PalId.Beegarde: "Beegarde",
    PalId.Tombat: "Tombat",
    PalId.Mossanda: "Mossanda",
    PalId.MossandaLux: "Mossanda Lux",
    PalId.Arsox: "Arsox",
    PalId.Rayhound: "Rayhound",
    PalId.Fuddler: "Fuddler",
    PalId.Astegon: "Astegon",
    PalId.Verdash: "Verdash",
    PalId.Foxcicle: "Foxcicle",
    PalId.Jetragon: "Jetragon",
    PalId.Daedream: "Daedream",
    PalId.Tanzee: "Tanzee",
    PalId.Blazehowl: "Blazehowl",
    PalId.BlazehowlNoct: "Blazehowl Noct",
    PalId.Kingpaca: "Kingpaca",
    PalId.KingpacaCryst: "Kingpaca Cryst",
    PalId.Gumoss: "Gumoss",
    PalId.Swee: "Swee",
    PalId.Sweepa: "Sweepa",
    PalId.Katress: "Katress",
    PalId.KatressIgnis: "Katress Ignis",
    PalId.Ribbuny: "Ribbuny",
    PalId.Beakon: "Beakon",
    PalId.Warsect: "Warsect",
    PalId.WarsectTerra: "Warsect Terra",
    PalId.Paladius: "Paladius",
    PalId.Nox: "Nox",
    PalId.Penking: "Penking",
    PalId.PenkingLux: "Penking Lux",
    PalId.Chillet: "Chillet",
    PalId.ChilletIgnis: "Chillet Ignis",
    PalId.Quivern: "Quivern",
    PalId.QuivernBotan: "Quivern Botan",
    PalId.Helzephyr: "Helzephyr",
    PalId.HelzephyrLux: "Helzephyr Lux",
    PalId.Ragnahawk: "Ragnahawk",
    PalId.Bushi: "Bushi",
    PalId.BushiNoct: "Bushi Noct",
    PalId.Celaray: "Celaray",
    PalId.CelarayLux: "Celaray Lux",
    PalId.Necromus: "Necromus",
    PalId.Petallia: "Petallia",
    PalId.Grintale: "Grintale",
    PalId.Cinnamoth: "Cinnamoth",
    PalId.Menasting: "Menasting",
    PalId.MenastingTerra: "Menasting Terra",
    PalId.Orserk: "Orserk",
    PalId.Cremis: "Cremis",
    PalId.Dumud: "Dumud",
    PalId.DumudGild: "Dumud Gild",
    PalId.Flambelle: "Flambelle",
    PalId.Rooby: "Rooby",
    PalId.Bellanoir: "Bellanoir",
    PalId.BellanoirLibero: "Bellanoir Libero",
    PalId.Selyne: "Selyne",
    PalId.Croajiro: "Croajiro",
    PalId.CroajiroNoct: "Croajiro Noct",
    PalId.Lullu: "Lullu",
    PalId.Shroomer: "Shroomer",
    PalId.ShroomerNoct: "Shroomer Noct",
    PalId.Kikit: "Kikit",
    PalId.Sootseer: "Sootseer",
    PalId.Prixter: "Prixter",
    PalId.Knocklem: "Knocklem",
    PalId.Yakumo: "Yakumo",
    PalId.Dogen: "Dogen",
    PalId.Dazemu: "Dazemu",
    PalId.Mimog: "Mimog",
    PalId.Xenovader: "Xenovader",
    PalId.Xenogard: "Xenogard",
    PalId.Xenolord: "Xenolord",
    PalId.Nitemary: "Nitemary",
    PalId.Starryon: "Starryon",
    PalId.Silvegis: "Silvegis",
    PalId.Smokie: "Smokie",
    PalId.Celesdir: "Celesdir",
    PalId.Omascul: "Omascul",
    PalId.Splatterina: "Splatterina",
    PalId.Tarantriss: "Tarantriss",
    PalId.Azurmane: "Azurmane",
    PalId.Gloopie: "Gloopie",
    PalId.Whalaska: "Whalaska",
    PalId.WhalaskaIgnis: "Whalaska Ignis",
    PalId.Jelliette: "Jelliette",
    PalId.FoxparksCryst: "Foxparks Cryst",
    PalId.CaprityNoct: "Caprity Noct",
    PalId.RibbunyBotan: "Ribbuny Botan",
    PalId.LoupmoonCryst: "Loupmoon Cryst",
    PalId.KitsunNoct: "Kitsun Noct",
    PalId.DazziNoct: "Dazzi Noct",
    PalId.CryolinxTerra: "Cryolinx Terra",
    PalId.FenglopeLux: "Fenglope Lux",
    PalId.FalerisAqua: "Faleris Aqua",
    PalId.Bastigor: "Bastigor",
    PalId.Ghangler: "Ghangler",
    PalId.GhanglerIgnis: "Ghangler Ignis",
    PalId.Icelyn: "Icelyn",
    PalId.Hartalis: "Hartalis",
    PalId.Herbil: "Herbil",
    PalId.Munchill: "Munchill",
    PalId.Finsider: "Finsider",
    PalId.FinsiderIgnis: "Finsider Ignis",
    PalId.Polapup: "Polapup",
    PalId.Braloha: "Braloha",
    PalId.Palumba: "Palumba",
    PalId.Frostplume: "Frostplume",
    PalId.Jellroy: "Jellroy",
    PalId.Neptilius: "Neptilius",
}
