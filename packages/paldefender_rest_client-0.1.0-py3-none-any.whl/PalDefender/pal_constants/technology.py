from enum import Enum

class TechnologyId(str, Enum):
    PrimitiveWorkbench = "Workbench"
    StoneAxe = "Product_Axe_Grade_01"
    StonePickaxe = "Product_Pickaxe_Grade_01"
    HandHeldTorch = "HandTorch"
    WoodenClub = "Battle_MeleeWeapon_Bat"
    PalDressingFacility = "SkinChange"
    GlobalPalbox = "GlobalPalStorage"
    Palbox = "PALBOX"
    PalSphere = "Special_PalSphere_Grade_01"
    Campfire = "Product_Cooking_Grade_01"
    WoodenChest = "Infra_ItemChest_Grade_01"
    RepairBench = "RepairBench"
    WoodenStructureSet = "Wooden_houseset"
    OldBow = "Battle_RangeWeapon_Bow1"
    Arrow = "Arrow"
    ShoddyBed = "Infra_PlayerBed_Grade_01"
    StrawPalBed = "Infra_PalBed_Grade_01"
    RepairKit = "RepairKit"
    Cloth = "Battle_Cloth"
    CommonShield = "Shield_01"
    StoneSpear = "Spear"
    ClothOutfit = "Battle_Armor_Grade_01_Cloth"
    FeedBox = "PalFoodBox"
    AlarmBell = "BaseCampBattleDirector"
    HangingTrap = "Trap_Noose"
    BerryPlantation = "Product_Farm_Berries"
    Ranch = "MonsterFarm"
    NormalParachute = "Battle_Glider_Grade_01"
    FireBow = "Battle_RangeWeapon_Bow_Fire"
    FireArrow = "Arrow_Fire"
    WoodenLivingRoomFurnitureSet = "FurnitureSet_1"
    WoodenTavernFurnitureSet = "FurnitureSet_3"
    PalGearWorkbench = "Product_WorkBench_SkillUnlock"
    StatueOfPower = "BuildableGoddessStatue"
    MountedTorch = "Torch"
    RushoarSaddle = "SkillUnlock_Boar"
    FoxparksHarness = "SkillUnlock_Kitsunebi"
    WoodenTavernCabinetFurnitureSet = "FurnitureSet_2"
    HouseplantSet = "FurnitureSet_9"
    LoggingSite = "Product_StationDeforest"
    StonePit = "Product_StonePit"
    Sign = "Signboard"
    Bat = "Battle_MeleeWeapon_Bat2"
    MelpacaSaddle = "SkillUnlock_Alpaca"
    CelaraySGloves = "SkillUnlock_FlyingManta"
    EggIncubator = "Special_HatchingPalEgg"
    WallMountedHouseplantSet = "FurnitureSet_4"
    Crusher = "Crusher"
    PoisonBow = "Battle_RangeWeapon_Bow_Poison"
    PoisonArrow = "Arrow_Poison"
    JolthogSGloves = "SkillUnlock_Hedgehog"
    DaedreamSNecklace = "SkillUnlock_DreamDemon"
    AntiqueStorageSet = "FurnitureSet_21"
    FireplaceSet = "FurnitureSet_28"
    TropicalOutfit = "Battle_Armor_Grade_01_Cloth_Heat"
    TundraOutfit = "Battle_Armor_Grade_01_Cloth_Cold"
    HotSpring = "Spa"
    Sandbag = "DefenseWait"
    DirehowlSSaddledHarness = "SkillUnlock_Garm"
    KillamariSGloves = "SkillUnlock_NegativeOctopus"
    CarpetSet = "FurnitureSet_17"
    ThreeShotBow = "Battle_RangeWeapon_Bow3"
    PrimitiveFurnace = "Product_Ingot_Grade_01_Copper"
    FeatheredHairBand = "Battle_Helm_Grade_02_Fur"
    Ladder = "Wooden_ladder"
    BearTrapSmall = "Trap_LegHold"
    Nail = "Infra_MachineParts"
    SurfentSaddle = "SkillUnlock_Serpent"
    SmallFeedBag = "AutoMealPouch_Tier1"
    MetalAxe = "Product_Axe_Grade_02"
    MetalPickaxe = "Product_Pickaxe_Grade_02"
    HighQualityWorkbench = "Product_Factory_Hard_Grade_01"
    HeavyWeightModule = "SphereModule_Heavy"
    WoodenGate = "Wood_Gate"
    LifmunkSSubmachineGun = "SkillUnlock_Carbunclo"
    JolthogCrystSGloves = "SkillUnlock_Hedgehog_Ice"
    PeltArmor = "Battle_Armor_Grade_02_Fur"
    MeatCleaver = "MeatCutterKnife"
    MedievalMedicineWorkbench = "Product_Medicine_Grade_01"
    TanzeeSAssaultRifle = "SkillUnlock_Monkey"
    EikthyrdeerSaddle = "SkillUnlock_Deer"
    GrintaleSaddle = "SkillUnlock_NaughtyCat"
    GrapplingGun = "GrapplingGun"
    AntiqueChairSet = "FurnitureSet_19"
    Crossbow = "Battle_RangeWeapon_BowGun"
    MetalSpear = "Spear_2"
    HumanPoweredGenerator = "ManualElectricGenerator"
    TrainingDummy = "DamagedScarecrow"
    CoolerBox = "CoolerBox"
    ChilletSaddle = "SkillUnlock_WeaselDragon"
    AntiqueStorageCabinetSet = "FurnitureSet_22"
    MegaSphere = "Special_PalSphere_Grade_02"
    SphereWorkbench = "Special_SphereFactory_Black_Grade_01"
    MonitoringStand = "BaseCampWorkHard"
    WallTorch = "WallTorch"
    SweepaSaddle = "SkillUnlock_MopKing"
    UnivoltSaddle = "SkillUnlock_Kirin"
    PalEssenceCondenser = "Special_PalRankUp"
    AntiqueDeskSet = "FurnitureSet_24"
    BeginnerFishingSet = "FishingSet1"
    FireArrowCrossbow = "Battle_RangeWeapon_BowGun_Fire"
    PalExpeditionStation = "Expedition"
    WheatPlantation = "Product_Farm_wheat"
    Mill = "FlourMill"
    ViewingCage = "DisplayCharacter"
    NitewingSaddle = "SkillUnlock_HawkBird"
    HipLantern = "Lantern"
    MegaShield = "Shield_02"
    HeatResistantPeltArmor = "Battle_Armor_Grade_02_Fur_Heat"
    MetalChest = "Infra_ItemChest_Grade_02"
    WoodenDefensiveWall = "DefenseWall_Wood"
    ArsoxSaddle = "SkillUnlock_FlameBuffalo"
    LockpickingToolV1 = "Unlock_Picking_Tier1"
    AntiqueBathSet = "FurnitureSet_20"
    AntiqueMirrorSet = "FurnitureSet_16"
    PoisonArrowCrossbow = "Battle_RangeWeapon_BowGun_Poison"
    CookingPot = "Product_Cooking_Grade_02"
    Heater = "Heater"
    Tombstone = "Headstone"
    PengulletRocketLauncher = "SkillUnlock_Penguin"
    FlopieSNecklace = "SkillUnlock_FlowerRabbit"
    GrapplingGun2 = "GrapplingGun2"
    PianoFurnitureSet = "FurnitureSet_15"
    MegaGlider = "Battle_Glider_Grade_02"
    ColdResistantPeltArmor = "Battle_Armor_Grade_02_Fur_Cold"
    StoneStructureSet = "Stone_houseset"
    Cooler = "Cooler"
    TocotocoSGloves = "SkillUnlock_ColorfulBird"
    RingOfMercy = "Accessory_Nonkilling"
    MetalShelfSet = "FurnitureSet_30"
    BathroomSet = "FurnitureSet_25"
    BreedingFarm = "BreedFarm"
    Cement = "Cement"
    WallMountedSign = "WallSignboard"
    DinossomSaddle = "SkillUnlock_FlowerDinosaur"
    BroncherrySaddle = "SkillUnlock_SakuraSaurus"
    DigtoiseSHeadband = "SkillUnlock_DrillGame"
    AverageFeedBag = "AutoMealPouch_Tier2"
    AntiqueHighQualityFurnitureSet = "FurnitureSet_32"
    GigaSphere = "Special_PalSphere_Grade_03"
    WeaponWorkbench = "Product_WeaponFactory_Dirty_Grade_01"
    PalLaborResearchLaboratory = "Lab"
    LargeToolbox = "ToolBoxV1"
    HangyuSGloves = "SkillUnlock_WindChimes"
    ElphidranSaddle = "SkillUnlock_FairyDragon"
    DimensionalPalStorage = "DimensionPalStorage"
    AntiqueCouchSet = "FurnitureSet_18"
    Musket = "Musket"
    Gunpowder = "Battle_GunPowder_Grade_02"
    CoarseAmmo = "RoughBullet"
    TomatoPlantation = "Product_Farm_tomato"
    FlameCauldron = "OlympicCauldron"
    VanwyrmSaddle = "SkillUnlock_BirdDragon"
    KingpacaSaddle = "SkillUnlock_KingAlpaca"
    AntiqueDresser = "TableDresser01_Stone"
    StunBaton = "ElecBaton"
    HighQualityBait = "FishingBait_2"
    FleaMarketItems = "ItemBooth"
    FleaMarketPals = "PalBooth"
    BearTrapLarge = "Trap_LegHold_Big"
    DazziSNecklace = "SkillUnlock_RaijinDaughter"
    DazemuSaddle = "SkillUnlock_FeatherOstrich"
    HomewardThundercloud = "Homeward"
    MetalArmor = "Battle_Armor_Grade_03_Copper"
    MetalHelm = "Battle_Helm_Grade_03_Copper"
    CurveModule = "SphereModule_Curve"
    WaterFountain = "Fountain"
    MaraithSaddle = "SkillUnlock_GhostBeast"
    GaleclawSGloves = "SkillUnlock_Eagle"
    KillamariPrimoSGloves = "SkillUnlock_NegativeOctopus_Neutral"
    LargeFeedBag = "AutoMealPouch_Tier3"
    MakeshiftHandgun = "MakeshiftHandgun"
    FluffyPalBed = "Infra_PalBed_Grade_02"
    MedicineRack = "PalMedicineBox"
    FlowerBed = "FlowerBed"
    FoxparksCrystSHarness = "SkillUnlock_Kitsunebi_Ice"
    MossandaSGrenadeLauncher = "SkillUnlock_GrassPanda"
    AzurobeSaddle = "SkillUnlock_BlueDragon"
    OreMiningSite = "Product_CopperPit"
    BoostGun = "PalDopingShot"
    BoostGunAmmo = "PalDopingShotBullet"
    FragGrenade = "FragGrenade"
    HeatResistantMetalArmor = "Battle_Armor_Grade_03_Copper_Heat"
    LettucePlantation = "Product_Farm_Lettuce"
    Silo = "Silo"
    SurfentTerraSaddle = "SkillUnlock_Serpent_Ground"
    EikthyrdeerTerraSaddle = "SkillUnlock_Deer_Ground"
    LockpickingToolV2 = "Unlock_Picking_Tier2"
    MakeshiftSMG = "MakeshiftSubmachineGun"
    PowerGenerator = "Infra_ElectricGenerator_Grade_01"
    Lamp = "Lamp"
    MountedCrossbow = "Battle_Defense_BowGun"
    FenglopeSaddle = "SkillUnlock_FengyunDeeper"
    MossandaLuxSGrenadeLauncher = "SkillUnlock_GrassPanda_Electric"
    CelarayLuxSGloves = "SkillUnlock_FlyingManta_Thunder"
    SingleShotSphereLauncher = "Battle_RangeWeapon_SphereLauncher_Once"
    HyperSphere = "Special_PalSphere_Grade_04"
    SphereAssemblyLine = "Special_SphereFactory_Black_Grade_02"
    ShockGrenade = "FragGrenade_Elec"
    ColdResistantMetalArmor = "Battle_Armor_Grade_03_Copper_Cold"
    CeilingLamp = "CeilingLamp"
    BroncherryAquaSaddle = "SkillUnlock_SakuraSaurus_Water"
    RayhoundSaddle = "SkillUnlock_ThunderDog"
    HerbilSHarness = "SkillUnlock_LeafMomonga"
    SmallPouch = "AdditionalInventory_001"
    Handgun = "Battle_RangeWeapon_HandGun"
    HandgunAmmo = "HandgunBullet"
    GigaShield = "Shield_03"
    ProductionAssemblyLine = "Product_Factory_Hard_Grade_02"
    StumpAndAxe = "Stump"
    StoneDefensiveWall = "DefenseWall"
    ElphidranAquaSaddle = "SkillUnlock_FairyDragon_Water"
    TarantrissSaddle = "SkillUnlock_PurpleSpider"
    AntiGravityBelt = "Accessory_JumpPower_Increase"
    IntermediateFishingRodCattiva = "FishingRod_02_1"
    Sword = "Battle_MeleeWeapon_Sword"
    IceGrenade = "FragGrenade_Ice"
    PotatoPlantation = "Product_Farm_Potato"
    FineBed = "Infra_PlayerBed_Grade_02"
    MammorestSaddle = "SkillUnlock_GrassMammoth"
    ReindrixSaddle = "SkillUnlock_IceDeer"
    AzurobeCrystSaddle = "SkillUnlock_BlueDragon_Ice"
    EnhancedHipLantern = "Lantern_High"
    MakeshiftShotgun = "MakeshiftShotgun"
    Mine = "Trap_MineAttack"
    MetalStructureSet = "Metal_houseset"
    MiningCart = "MiningTool"
    KitsunSaddle = "SkillUnlock_AmaterasuWolf"
    VanwyrmCrystSaddle = "SkillUnlock_BirdDragon_Ice"
    DinossomLuxSaddle = "SkillUnlock_FlowerDinosaur_Electric"
    Meowmere = "YakushimaBlade"
    MakeshiftAssaultRifle = "MakeshiftAssaultRifle"
    IncendiaryGrenade = "FragGrenade_Fire"
    SniperModule = "SphereModule_Sniper"
    FishingPond = "FishingPond1"
    HighQualityHotSpring = "Spa2"
    StoneGate = "Stone_Gate"
    PyrinSaddle = "SkillUnlock_FireKirin"
    HangyuCrystSGlove = "SkillUnlock_WindChimes_Ice"
    GrapplingGun3 = "GrapplingGun3"
    ULTRAKILLCollabSet1 = "OctaviaSet01"
    CompoundBow = "Battle_RangeWeapon_CompoundBow"
    ReinforcedArrow = "ReinforcedArrow"
    PalRecoveryGrenade = "PalHealingGrenade"
    WeaponAssemblyLine = "Product_WeaponFactory_Dirty_Grade_02"
    CarrotPlantation = "Product_Farm_Carrot"
    WitchCauldron = "Cauldron"
    PalboxControlDevice = "BaseCampWorkerExtraStation"
    ReptyroSaddle = "SkillUnlock_VolcanicMonster"
    SummoningAltar = "Altar"
    OldRevolver = "Battle_RangeWeapon_OldRevolver"
    WaterGrenade = "FragGrenade_Water"
    Polymer = "Polymer"
    ElectricMine = "Trap_MineElecShock"
    Snowman = "Snowman"
    HelzephyrSaddle = "SkillUnlock_HadesBird"
    BlazehowlSaddle = "SkillUnlock_Manticore"
    ClockSet = "FurnitureSet_23"
    AbilityGlasses = "Accessory_TalentChecker"
    ImprovedFurnace = "Product_Ingot_Grade_02_Iron"
    RefinedMetalAxe = "Product_Axe_Grade_03"
    RefinedMetalPickaxe = "Product_Pickaxe_Grade_03"
    RefinedMetalSpear = "Spear_3"
    BeakonSaddle = "SkillUnlock_ThunderBird"
    PyrinNoctSaddle = "SkillUnlock_FireKirin_Dark"
    PolapupSaddle = "SkillUnlock_IceSeal"
    StorageContainerSet = "FurnitureSet_6"
    AirDashBoots = "Accessory_AirDash1"
    UltraSphere = "Special_PalSphere_Grade_05"
    SphereAssemblyLineII = "Special_SphereFactory_Black_Grade_03"
    GrassGrenade = "FragGrenade_Leaf"
    CircuitBoard = "Infra_ElectronicCircuit"
    CarbonFiber = "CarbonFiber"
    WhalaskaSaddle = "SkillUnlock_IceNarwhal"
    BlazehowlNoctSaddle = "SkillUnlock_Manticore_Dark"
    MetalChairAndDeskSet = "FurnitureSet_13"
    HugeFeedBag = "AutoMealPouch_Tier4"
    SingleShotRifle = "Battle_RangeWeapon_Rifle"
    RifleAmmo = "RifleBullet"
    PalSurgeryTable = "OperatingTable"
    OnionPlantation = "Product_Farm_Onion"
    HighQualityCloth = "Cloth2"
    LargePalBed = "MedicalPalBed_04"
    QuivernSaddle = "SkillUnlock_SkyDragon"
    AntiqueLampSet = "FurnitureSet_29"
    ElectricEggIncubator = "Special_ElectricHatchingPalEgg"
    SMG = "Battle_RangeWeapon_SubmachineGun"
    RefinedMetalArmor = "Battle_Armor_Grade_03_Iron"
    RefinedMetalHelm = "Battle_Helm_Grade_04_Iron"
    Accumulator = "EnergyStorage_Electric"
    RagnahawkSaddle = "SkillUnlock_RedArmorBird"
    GhanglerSaddle = "SkillUnlock_GhostAnglerfish"
    IronwoodTableSet = "FurnitureSet_14"
    ScatterSphereLauncher = "Battle_RangeWeapon_SphereLauncher"
    MeteorLauncher = "Launcher_Meteor"
    GroundGrenade = "FragGrenade_Ground"
    DeluxeBait = "FishingBait_3"
    Refrigerator = "Refrigerator"
    IceMine = "Trap_MineFreeze"
    ReptyroCrystSaddle = "SkillUnlock_VolcanicMonster_Ice"
    FalerisSaddle = "SkillUnlock_Horus"
    OutdoorFurnitureSet = "FurnitureSet_31"
    OreMiningSiteII = "Product_CopperPit_2"
    DoubleBarreledShotgun = "Battle_RangeWeapon_ShotGun"
    ShotgunShell = "ShotGunBullet"
    SliderModule = "SphereModule_Curve2"
    GlassStructureSet = "Glass_houseset"
    RefinedMetalChest = "Infra_ItemChest_Grade_03"
    PengulletLuxSRocketLauncher = "SkillUnlock_Penguin_Electric"
    JormuntideSaddle = "SkillUnlock_Umihebi"
    MetalBarrelSet = "FurnitureSet_5"
    DoubleJumpBoots = "Accessory_JumpCount_Increase1"
    DarkGrenade = "FragGrenade_Dark"
    HeatResistantRefinedMetalArmor = "Battle_Armor_Grade_03_Iron_Heat"
    GigaGlider = "Battle_Glider_Grade_03"
    MountedMachineGun = "Battle_Defense_MachineGun"
    BlazamutSaddle = "SkillUnlock_KingBahamut"
    GrizzboltSMinigun = "SkillUnlock_ElecPanda"
    LeatherChairSet = "FurnitureSet_7"
    GuildChest = "GuildChest"
    SemiAutoRifle = "Battle_RangeWeapon_SemiAutoRifle"
    ColdResistantRefinedMetalArmor = "Battle_Armor_Grade_03_Iron_Cold"
    ElectricKitchen = "Product_Cooking_Grade_03"
    AlphaWaveGenerator = "SanityDecrease1"
    ElectricHeater = "ElectricHeater"
    SuzakuSaddle = "SkillUnlock_Suzaku"
    StreetLampSet = "FurnitureSet_27"
    CoalMine = "Product_CoalPit"
    DragonGrenade = "FragGrenade_Dragon"
    ProductionAssemblyLineII = "Product_Factory_Hard_Grade_03"
    ElectricCooler = "ElectricCooler"
    IronGate = "Metal_Gate"
    KingpacaCrystSaddle = "SkillUnlock_KingAlpaca_Ice"
    PalumbaSaddle = "SkillUnlock_TropicalOstrich"
    AmusementFurnitureSet = "FurnitureSet_26"
    EmergencyExitSignSet = "FurnitureSet_8"
    MediumPouch = "AdditionalInventory_002"
    PumpActionShotgun = "Battle_RangeWeapon_ShotGun_Multi"
    HyperShield = "Shield_04"
    ElectricMedicineWorkbench = "Product_Medicine_Grade_02"
    MetalDefensiveWall = "DefenseWall_Metal"
    SuzakuAquaSaddle = "SkillUnlock_Suzaku_Water"
    JormuntideIgnisSaddle = "SkillUnlock_Umihebi_Fire"
    YakumoSaddle = "SkillUnlock_GuardianDog"
    LilySSpear = "Spear_ForestBoss"
    LegendarySphere = "Special_PalSphere_Grade_06"
    ElectricFurnace = "Product_Ingot_Grade_03_Steal"
    Katana = "Katana"
    PalMetalPickaxe = "Battle_MeleeWeapon_Pickaxe_Steal"
    PalMetalAxe = "Battle_MeleeWeapon_Axe_Steal"
    RelaxaurusMissileLauncher = "SkillUnlock_LazyDragon"
    WumpoSaddle = "SkillUnlock_Yeti"
    DecalGunSet = "DecalGunSet"
    AssaultRifle = "Battle_RangeWeapon_AssaultRifle"
    AssaultRifleAmmo = "AssaultRifleBullet"
    AdvancedFishingRodPengullet = "FishingRod_03_1"
    DraftingTable = "CompositeDesk"
    WumpoBotanSaddle = "SkillUnlock_Yeti_Grass"
    MammorestCrystSaddle = "SkillUnlock_GrassMammoth_Ice"
    ChilletIgnisSaddle = "SkillUnlock_WeaselDragon_Fire"
    TrafficControlSet = "FurnitureSet_11"
    SulfurMine = "Product_SulfurPit"
    PalMetalArmor = "Battle_Armor_Grade_04_Steal"
    PalMetalHelm = "Battle_Helm_Grade_05_Steal"
    BetaWaveGenerator = "WorkSpeedIncrease1"
    LargeMountedLamp = "LargeLamp"
    RelaxaurusLuxSMissileLauncher = "SkillUnlock_LazyDragon_Electric"
    ShroomerSaddle = "SkillUnlock_MushroomDragon"
    BralohaSaddle = "SkillUnlock_Plesiosaur"
    RoadSignSet = "FurnitureSet_12"
    GiantFeedBag = "AutoMealPouch_Tier5"
    SemiAutoShotgun = "Battle_RangeWeapon_SemiAutoShotgun"
    WeaponAssemblyLineII = "Product_WeaponFactory_Dirty_Grade_03"
    SniperModuleSphereModuleSniper2 = "SphereModule_Sniper2"
    LargeCeilingLamp = "LargeCeilingLamp"
    AstegonSaddle = "SkillUnlock_BlackMetalDragon"
    ShadowbeakSaddle = "SkillUnlock_BlackGriffon"
    ShroomerNoctSaddle = "SkillUnlock_MushroomDragon_Dark"
    LargeIncubator = "MultiHatchingPalEgg"
    HeatResistantPalMetalArmor = "Battle_Armor_Grade_04_Steal_Heat"
    SkillfruitOrchard = "Farm_SkillFruits"
    GoldCoinAssemblyLine = "Factory_Money"
    ElectricPylon = "TransmissionTower"
    FrostallionSaddle = "SkillUnlock_IceHorse"
    FrostallionNoctSaddle = "SkillUnlock_IceHorse_Dark"
    BarricadeSet = "FurnitureSet_10"
    GrapplingGun4 = "GrapplingGun4"
    RocketLauncher = "Battle_RangeWeapon_RocketLauncher"
    RocketAmmo = "LauncherBullet"
    ItemRetrievalMachine = "BaseCampItemDispenser"
    LargeScaleStoneOven = "HugeKitchen"
    PaladiusSaddle = "SkillUnlock_SaintCentaur"
    NecromusSaddle = "SkillUnlock_BlackCentaur"
    QuivernBotanSaddle = "SkillUnlock_SkyDragon_Grass"
    LargePowerGenerator = "ElectricGenerator_Large"
    ColdResistantPalMetalArmor = "Battle_Armor_Grade_04_Steal_Cold"
    MountedMissileLauncher = "Battle_Defense_Missile"
    Plasteel = "Plastic"
    CrudeOilExtractor = "OilPump"
    JapaneseStyleStructureSet = "JapaneseStyle_houseset"
    JetragonSMissileLauncher = "SkillUnlock_JetDragon"
    XenogardSaddle = "SkillUnlock_WhiteAlienDragon"
    PureQuartzMine = "Product_QuartzPit"
    UltimateSphere = "Special_PalSphere_Grade_07"
    PlasteelArmor = "Battle_Armor_Grade_05_Plastic"
    PlasteelHelmet = "Battle_Helm_Grade_06_Plastic"
    LaserRifle = "Battle_RangeWeapon_LaserRifle"
    EnergyCartridge = "LaserBullet"
    ColdFoodBox = "CoolerPalFoodBox"
    DazziNoctSNecklace = "SkillUnlock_RaijinDaughter_Water"
    LockpickingToolV3 = "Unlock_Picking_Tier3"
    GliderTera = "Battle_Glider_Grade_04"
    Flamethrower = "Battle_RangeWeapon_FlameThrower"
    FlamethrowerFuel = "FlamethrowerBullet"
    AlluringBait = "FishingBait_3_A"
    RefrigeratedCrusher = "IceCrusher"
    HelzephyrLuxSaddle = "SkillUnlock_HadesBird_Electric"
    FenglopeLuxSaddle = "SkillUnlock_FengyunDeeper_Electric"
    LargePouch = "AdditionalInventory_003"
    HeatResistantPlasteelArmor = "Battle_Armor_Grade_05_Plastic_Heat"
    GrenadeLauncher = "Battle_RangeWeapon_GrenadeLauncher"
    GrenadeAmmo = "GrenadeBullet"
    FragGrenadeMk2 = "FragGrenade_Super"
    SelyneSaddle = "SkillUnlock_MoonQueen"
    NyafiaSShotgun = "SkillUnlock_BadCatgirl"
    KitsunNoctSaddle = "SkillUnlock_AmaterasuWolf_Dark"
    ColdResistantPlasteelArmor = "Battle_Armor_Grade_05_Plastic_Cold"
    GatlingGun = "Battle_RangeWeapon_GatlingGun"
    GatlingGunAmmo = "GatlingBullet"
    PalDisassemblyConveyor = "DismantlingConveyor"
    DoubleAirDashBoots = "Accessory_AirDash2"
    GildaneSaddle = "SkillUnlock_GoldenHorse"
    JapaneseStyleFurnitureSet = "FurnitureSet_Japanese"
    LargeFishingPond = "FishingPond2"
    ShieldUltra = "Shield_05"
    LightweightPlasteelArmor = "Battle_Armor_Grade_05_Plastic_Weight"
    GuidedMissileLauncher = "Battle_RangeWeapon_GuidedMissileLauncher"
    MissileAmmo = "MissileBullet"
    BlazamutRyuSaddle = "SkillUnlock_KingBahamut_Dragon"
    FalerisAquaSaddle = "SkillUnlock_Horus_Water"
    HomingSphereLauncher = "Battle_RangeWeapon_HomingSphereLauncher"
    ExoticSphere = "PalSphere_Exotic"
    AdvancedSphereAssemblyLine = "SphereFactory_Black_04"
    Hexolite = "StainlessSteel"
    GiganticFurnace = "BlastFurnace4"
    MetalDetector = "MetalDetector"
    AzurmaneSaddle = "SkillUnlock_BlueThunderHorse"
    SmokieSHarness = "SkillUnlock_BlackPuppy"
    ULTRAKILLCollabSet2 = "OctaviaSet02"
    AdvancedBow = "SFBow"
    AdvancedArrow = "SFArrow"
    HexoliteArmor = "SFArmor"
    BeamSword = "BeamSword"
    HomingModule = "SphereModule_Homing"
    PalPod = "MedicalPalBed_05"
    StarryonSaddle = "SkillUnlock_NightBlueHorse"
    GiantPouch = "AdditionalInventory_004"
    AdvancedChest = "ItemChest_04"
    LaserGatlingGun = "LaserGatlingGun"
    LaserGatlingCartridge = "LaserGatlingBullet"
    HexoliteHelmet = "SFHelmet"
    SilvegisSaddle = "SkillUnlock_WhiteShieldDragon"
    CelesdirSaddle = "SkillUnlock_WhiteDeer"
    TripleJumpBoots = "Accessory_JumpCount_Increase2"
    AdvancedRecoveryMeds = "Potion_Extreme"
    RevivalPotion = "PalRevive"
    AdvancedMedicineWorkbench = "MedicineFacility_03"
    HeatResistantHexoliteArmor = "SFArmorHeat"
    ColdResistantHexoliteArmor = "SFArmorCold"
    BastigorSHammer = "SkillUnlock_SnowTigerBeastman"
    PlasmaCannon = "EnergyRocketLauncher"
    PlasmaCartridge = "EnergyLauncherBullet"
    AdvancedShield = "Shield_SF"
    LightweightHexoliteArmor = "SFArmorWeight"
    XenolordSaddle = "SkillUnlock_DarkMechaDragon"
    LargeScaleElectricEggIncubator = "MultiElectricHatchingPalEgg"
    PowerfulFishingMagnet = "Salvage_TreasureBoxKey02"
    CoralumIngot = "ManganeseIngot"
    AdvancedWorkshop = "Factory_Hard_04"
    FuturisticStructureSet = "SF_houseset"
    GhanglerIgnisSaddle = "SkillUnlock_GhostAnglerfish_Fire"
    HexoliteQuartzMine = "CrystalPit"
    EnergyShotgun = "EnergyShotgun"
    EnergyShotgunAmmo = "EnergyShotgunBullet"
    AdvancedWeaponAssemblyLine = "WeaponFactory_Dirty_04"
    JapaneseStyleHotSpring = "Spa3"
    WhalaskaIgnisSaddle = "SkillUnlock_IceNarwhal_Fire"
    TripleAirDashBoots = "Accessory_AirDash3"
    MegaboostGun = "PalDopingShot_2"
    RayneSyndicateFlagSet = "HunterFlagSet"
    FreePalAllianceFlagSet = "BelieverFlagSet"
    NeptiliusSaddle = "SkillUnlock_PoseidonOrca"
    GrapplingGun5 = "GrapplingGun5"
    OverheatRifle = "OverheatRifle"
    OverheatRifleAmmo = "OverheatRifleBullet"
    BrothersOfTheEternalPyreFlagSet = "FireCultFlagSet"
    PIDFFlagSet = "PoliceFlagSet"
    ChargeRifle = "ChargeLaserRifle"
    ChargeRifleAmmo = "ChargeLaserRifleBullet"
    PALGeneticResearchUnitFlagSet = "ScientistFlagSet"
    MoonflowerFlagSet = "NinjaFlagSet"
    HartalisSaddle = "SkillUnlock_LegendDeer"

TECHNOLOGY_ID_TO_NAME = {
    TechnologyId.PrimitiveWorkbench: "Primitive Workbench",
    TechnologyId.StoneAxe: "Stone Axe",
    TechnologyId.StonePickaxe: "Stone Pickaxe",
    TechnologyId.HandHeldTorch: "Hand-Held Torch",
    TechnologyId.WoodenClub: "Wooden Club",
    TechnologyId.PalDressingFacility: "Pal Dressing Facility",
    TechnologyId.GlobalPalbox: "Global Palbox",
    TechnologyId.Palbox: "Palbox",
    TechnologyId.PalSphere: "Pal Sphere",
    TechnologyId.Campfire: "Campfire",
    TechnologyId.WoodenChest: "Wooden Chest",
    TechnologyId.RepairBench: "Repair Bench",
    TechnologyId.WoodenStructureSet: "Wooden Structure Set",
    TechnologyId.OldBow: "Old Bow",
    TechnologyId.Arrow: "Arrow",
    TechnologyId.ShoddyBed: "Shoddy Bed",
    TechnologyId.StrawPalBed: "Straw Pal Bed",
    TechnologyId.RepairKit: "Repair Kit",
    TechnologyId.Cloth: "Cloth",
    TechnologyId.CommonShield: "Common Shield",
    TechnologyId.StoneSpear: "Stone Spear",
    TechnologyId.ClothOutfit: "Cloth Outfit",
    TechnologyId.FeedBox: "Feed Box",
    TechnologyId.AlarmBell: "Alarm Bell",
    TechnologyId.HangingTrap: "Hanging Trap",
    TechnologyId.BerryPlantation: "Berry Plantation",
    TechnologyId.Ranch: "Ranch",
    TechnologyId.NormalParachute: "Normal Parachute",
    TechnologyId.FireBow: "Fire Bow",
    TechnologyId.FireArrow: "Fire Arrow",
    TechnologyId.WoodenLivingRoomFurnitureSet: "Wooden Living Room Furniture Set",
    TechnologyId.WoodenTavernFurnitureSet: "Wooden Tavern Furniture Set",
    TechnologyId.PalGearWorkbench: "Pal Gear Workbench",
    TechnologyId.StatueOfPower: "Statue of Power",
    TechnologyId.MountedTorch: "Mounted Torch",
    TechnologyId.RushoarSaddle: "Rushoar Saddle",
    TechnologyId.FoxparksHarness: "Foxparks' Harness",
    TechnologyId.WoodenTavernCabinetFurnitureSet: "Wooden Tavern Cabinet Furniture Set",
    TechnologyId.HouseplantSet: "Houseplant Set",
    TechnologyId.LoggingSite: "Logging Site",
    TechnologyId.StonePit: "Stone Pit",
    TechnologyId.Sign: "Sign",
    TechnologyId.Bat: "Bat",
    TechnologyId.MelpacaSaddle: "Melpaca Saddle",
    TechnologyId.CelaraySGloves: "Celaray's Gloves",
    TechnologyId.EggIncubator: "Egg Incubator",
    TechnologyId.WallMountedHouseplantSet: "Wall-Mounted Houseplant Set",
    TechnologyId.Crusher: "Crusher",
    TechnologyId.PoisonBow: "Poison Bow",
    TechnologyId.PoisonArrow: "Poison Arrow",
    TechnologyId.JolthogSGloves: "Jolthog's Gloves",
    TechnologyId.DaedreamSNecklace: "Daedream's Necklace",
    TechnologyId.AntiqueStorageSet: "Antique Storage Set",
    TechnologyId.FireplaceSet: "Fireplace Set",
    TechnologyId.TropicalOutfit: "Tropical Outfit",
    TechnologyId.TundraOutfit: "Tundra Outfit",
    TechnologyId.HotSpring: "Hot Spring",
    TechnologyId.Sandbag: "Sandbag",
    TechnologyId.DirehowlSSaddledHarness: "Direhowl's Saddled Harness",
    TechnologyId.KillamariSGloves: "Killamari's Gloves",
    TechnologyId.CarpetSet: "Carpet Set",
    TechnologyId.ThreeShotBow: "Three Shot Bow",
    TechnologyId.PrimitiveFurnace: "Primitive Furnace",
    TechnologyId.FeatheredHairBand: "Feathered Hair Band",
    TechnologyId.Ladder: "Ladder",
    TechnologyId.BearTrapSmall: "Bear Trap (Small)",
    TechnologyId.Nail: "Nail",
    TechnologyId.SurfentSaddle: "Surfent Saddle",
    TechnologyId.SmallFeedBag: "Small Feed Bag",
    TechnologyId.MetalAxe: "Metal Axe",
    TechnologyId.MetalPickaxe: "Metal Pickaxe",
    TechnologyId.HighQualityWorkbench: "High-Quality Workbench",
    TechnologyId.HeavyWeightModule: "Heavy Weight Module",
    TechnologyId.WoodenGate: "Wooden Gate",
    TechnologyId.LifmunkSSubmachineGun: "Lifmunk's Submachine Gun",
    TechnologyId.JolthogCrystSGloves: "Jolthog Cryst's Gloves",
    TechnologyId.PeltArmor: "Pelt Armor",
    TechnologyId.MeatCleaver: "Meat Cleaver",
    TechnologyId.MedievalMedicineWorkbench: "Medieval Medicine Workbench",
    TechnologyId.TanzeeSAssaultRifle: "Tanzee's Assault Rifle",
    TechnologyId.EikthyrdeerSaddle: "Eikthyrdeer Saddle",
    TechnologyId.GrintaleSaddle: "Grintale Saddle",
    TechnologyId.GrapplingGun: "GrapplingGun",
    TechnologyId.AntiqueChairSet: "Antique Chair Set",
    TechnologyId.Crossbow: "Crossbow",
    TechnologyId.MetalSpear: "Metal Spear",
    TechnologyId.HumanPoweredGenerator: "Human-Powered Generator",
    TechnologyId.TrainingDummy: "Training Dummy",
    TechnologyId.CoolerBox: "Cooler Box",
    TechnologyId.ChilletSaddle: "Chillet Saddle",
    TechnologyId.AntiqueStorageCabinetSet: "Antique Storage Cabinet Set",
    TechnologyId.MegaSphere: "Mega Sphere",
    TechnologyId.SphereWorkbench: "Sphere Workbench",
    TechnologyId.MonitoringStand: "Monitoring Stand",
    TechnologyId.WallTorch: "Wall Torch",
    TechnologyId.SweepaSaddle: "Sweepa Saddle",
    TechnologyId.UnivoltSaddle: "Univolt Saddle",
    TechnologyId.PalEssenceCondenser: "Pal Essence Condenser",
    TechnologyId.AntiqueDeskSet: "Antique Desk Set",
    TechnologyId.BeginnerFishingSet: "Beginner Fishing Set",
    TechnologyId.FireArrowCrossbow: "Fire Arrow Crossbow",
    TechnologyId.PalExpeditionStation: "Pal Expedition Station",
    TechnologyId.WheatPlantation: "Wheat Plantation",
    TechnologyId.Mill: "Mill",
    TechnologyId.ViewingCage: "Viewing Cage",
    TechnologyId.NitewingSaddle: "Nitewing Saddle",
    TechnologyId.HipLantern: "Hip Lantern",
    TechnologyId.MegaShield: "Mega Shield",
    TechnologyId.HeatResistantPeltArmor: "Heat Resistant Pelt Armor",
    TechnologyId.MetalChest: "Metal Chest",
    TechnologyId.WoodenDefensiveWall: "Wooden Defensive Wall",
    TechnologyId.ArsoxSaddle: "Arsox Saddle",
    TechnologyId.LockpickingToolV1: "Lockpicking Tool v1",
    TechnologyId.AntiqueBathSet: "Antique Bath Set",
    TechnologyId.AntiqueMirrorSet: "Antique Mirror Set",
    TechnologyId.PoisonArrowCrossbow: "Poison Arrow Crossbow",
    TechnologyId.CookingPot: "Cooking Pot",
    TechnologyId.Heater: "Heater",
    TechnologyId.Tombstone: "Tombstone",
    TechnologyId.PengulletRocketLauncher: "Pengullet Rocket Launcher",
    TechnologyId.FlopieSNecklace: "Flopie's Necklace",
    TechnologyId.GrapplingGun2: "GrapplingGun2",
    TechnologyId.PianoFurnitureSet: "Piano Furniture Set",
    TechnologyId.MegaGlider: "Mega Glider",
    TechnologyId.ColdResistantPeltArmor: "Cold Resistant Pelt Armor",
    TechnologyId.StoneStructureSet: "Stone Structure Set",
    TechnologyId.Cooler: "Cooler",
    TechnologyId.TocotocoSGloves: "Tocotoco's Gloves",
    TechnologyId.RingOfMercy: "Ring of Mercy",
    TechnologyId.MetalShelfSet: "Metal Shelf Set",
    TechnologyId.BathroomSet: "Bathroom Set",
    TechnologyId.BreedingFarm: "Breeding Farm",
    TechnologyId.Cement: "Cement",
    TechnologyId.WallMountedSign: "Wall-Mounted Sign",
    TechnologyId.DinossomSaddle: "Dinossom Saddle",
    TechnologyId.BroncherrySaddle: "Broncherry Saddle",
    TechnologyId.DigtoiseSHeadband: "Digtoise's Headband",
    TechnologyId.AverageFeedBag: "Average Feed Bag",
    TechnologyId.AntiqueHighQualityFurnitureSet: "Antique High Quality Furniture Set",
    TechnologyId.GigaSphere: "Giga Sphere",
    TechnologyId.WeaponWorkbench: "Weapon Workbench",
    TechnologyId.PalLaborResearchLaboratory: "Pal Labor Research Laboratory",
    TechnologyId.LargeToolbox: "Large Toolbox",
    TechnologyId.HangyuSGloves: "Hangyu's Gloves",
    TechnologyId.ElphidranSaddle: "Elphidran Saddle",
    TechnologyId.DimensionalPalStorage: "Dimensional Pal Storage",
    TechnologyId.AntiqueCouchSet: "Antique Couch Set",
    TechnologyId.Musket: "Musket",
    TechnologyId.Gunpowder: "Gunpowder",
    TechnologyId.CoarseAmmo: "Coarse Ammo",
    TechnologyId.TomatoPlantation: "Tomato Plantation",
    TechnologyId.FlameCauldron: "Flame Cauldron",
    TechnologyId.VanwyrmSaddle: "Vanwyrm Saddle",
    TechnologyId.KingpacaSaddle: "Kingpaca Saddle",
    TechnologyId.AntiqueDresser: "Antique Dresser",
    TechnologyId.StunBaton: "Stun Baton",
    TechnologyId.HighQualityBait: "High Quality Bait",
    TechnologyId.FleaMarketItems: "Flea Market (Items)",
    TechnologyId.FleaMarketPals: "Flea Market (Pals)",
    TechnologyId.BearTrapLarge: "Bear Trap (Large)",
    TechnologyId.DazziSNecklace: "Dazzi's Necklace",
    TechnologyId.DazemuSaddle: "Dazemu Saddle",
    TechnologyId.HomewardThundercloud: "Homeward Thundercloud",
    TechnologyId.MetalArmor: "Metal Armor",
    TechnologyId.MetalHelm: "Metal Helm",
    TechnologyId.CurveModule: "Curve Module",
    TechnologyId.WaterFountain: "Water Fountain",
    TechnologyId.MaraithSaddle: "Maraith Saddle",
    TechnologyId.GaleclawSGloves: "Galeclaw's Gloves",
    TechnologyId.KillamariPrimoSGloves: "Killamari Primo's Gloves",
    TechnologyId.LargeFeedBag: "Large Feed Bag",
    TechnologyId.MakeshiftHandgun: "Makeshift Handgun",
    TechnologyId.FluffyPalBed: "Fluffy Pal Bed",
    TechnologyId.MedicineRack: "Medicine Rack",
    TechnologyId.FlowerBed: "Flower Bed",
    TechnologyId.FoxparksCrystSHarness: "Foxparks Cryst's Harness",
    TechnologyId.MossandaSGrenadeLauncher: "Mossanda's Grenade Launcher",
    TechnologyId.AzurobeSaddle: "Azurobe Saddle",
    TechnologyId.OreMiningSite: "Ore Mining Site",
    TechnologyId.BoostGun: "Boost Gun",
    TechnologyId.BoostGunAmmo: "Boost Gun Ammo",
    TechnologyId.FragGrenade: "Frag Grenade",
    TechnologyId.HeatResistantMetalArmor: "Heat Resistant Metal Armor",
    TechnologyId.LettucePlantation: "Lettuce Plantation",
    TechnologyId.Silo: "Silo",
    TechnologyId.SurfentTerraSaddle: "Surfent Terra Saddle",
    TechnologyId.EikthyrdeerTerraSaddle: "Eikthyrdeer Terra Saddle",
    TechnologyId.LockpickingToolV2: "Lockpicking Tool v2",
    TechnologyId.MakeshiftSMG: "Makeshift SMG",
    TechnologyId.PowerGenerator: "Power Generator",
    TechnologyId.Lamp: "Lamp",
    TechnologyId.MountedCrossbow: "Mounted Crossbow",
    TechnologyId.FenglopeSaddle: "Fenglope Saddle",
    TechnologyId.MossandaLuxSGrenadeLauncher: "Mossanda Lux's Grenade Launcher",
    TechnologyId.CelarayLuxSGloves: "Celaray Lux's Gloves",
    TechnologyId.SingleShotSphereLauncher: "Single-Shot Sphere Launcher",
    TechnologyId.HyperSphere: "Hyper Sphere",
    TechnologyId.SphereAssemblyLine: "Sphere Assembly Line",
    TechnologyId.ShockGrenade: "Shock Grenade",
    TechnologyId.ColdResistantMetalArmor: "Cold Resistant Metal Armor",
    TechnologyId.CeilingLamp: "Ceiling Lamp",
    TechnologyId.BroncherryAquaSaddle: "Broncherry Aqua Saddle",
    TechnologyId.RayhoundSaddle: "Rayhound Saddle",
    TechnologyId.HerbilSHarness: "Herbil's Harness",
    TechnologyId.SmallPouch: "Small Pouch",
    TechnologyId.Handgun: "Handgun",
    TechnologyId.HandgunAmmo: "Handgun Ammo",
    TechnologyId.GigaShield: "Giga Shield",
    TechnologyId.ProductionAssemblyLine: "Production Assembly Line",
    TechnologyId.StumpAndAxe: "Stump and Axe",
    TechnologyId.StoneDefensiveWall: "Stone Defensive Wall",
    TechnologyId.ElphidranAquaSaddle: "Elphidran Aqua Saddle",
    TechnologyId.TarantrissSaddle: "Tarantriss Saddle",
    TechnologyId.AntiGravityBelt: "Anti-Gravity Belt",
    TechnologyId.IntermediateFishingRodCattiva: "Intermediate Fishing Rod (Cattiva)",
    TechnologyId.Sword: "Sword",
    TechnologyId.IceGrenade: "Ice Grenade",
    TechnologyId.PotatoPlantation: "Potato Plantation",
    TechnologyId.FineBed: "Fine Bed",
    TechnologyId.MammorestSaddle: "Mammorest Saddle",
    TechnologyId.ReindrixSaddle: "Reindrix Saddle",
    TechnologyId.AzurobeCrystSaddle: "Azurobe Cryst Saddle",
    TechnologyId.EnhancedHipLantern: "Enhanced Hip Lantern",
    TechnologyId.MakeshiftShotgun: "Makeshift Shotgun",
    TechnologyId.Mine: "Mine",
    TechnologyId.MetalStructureSet: "Metal Structure Set",
    TechnologyId.MiningCart: "Mining Cart",
    TechnologyId.KitsunSaddle: "Kitsun Saddle",
    TechnologyId.VanwyrmCrystSaddle: "Vanwyrm Cryst Saddle",
    TechnologyId.DinossomLuxSaddle: "Dinossom Lux Saddle",
    TechnologyId.Meowmere: "Meowmere",
    TechnologyId.MakeshiftAssaultRifle: "Makeshift Assault Rifle",
    TechnologyId.IncendiaryGrenade: "Incendiary Grenade",
    TechnologyId.SniperModule: "Sniper Module",
    TechnologyId.FishingPond: "Fishing Pond",
    TechnologyId.HighQualityHotSpring: "High Quality Hot Spring",
    TechnologyId.StoneGate: "Stone Gate",
    TechnologyId.PyrinSaddle: "Pyrin Saddle",
    TechnologyId.HangyuCrystSGlove: "Hangyu Cryst's Glove",
    TechnologyId.GrapplingGun3: "GrapplingGun3",
    TechnologyId.ULTRAKILLCollabSet1: "ULTRAKILL Collab Set 1",
    TechnologyId.CompoundBow: "Compound Bow",
    TechnologyId.ReinforcedArrow: "Reinforced Arrow",
    TechnologyId.PalRecoveryGrenade: "Pal Recovery Grenade",
    TechnologyId.WeaponAssemblyLine: "Weapon Assembly Line",
    TechnologyId.CarrotPlantation: "Carrot Plantation",
    TechnologyId.WitchCauldron: "Witch Cauldron",
    TechnologyId.PalboxControlDevice: "Palbox Control Device",
    TechnologyId.ReptyroSaddle: "Reptyro Saddle",
    TechnologyId.SummoningAltar: "Summoning Altar",
    TechnologyId.OldRevolver: "Old Revolver",
    TechnologyId.WaterGrenade: "Water Grenade",
    TechnologyId.Polymer: "Polymer",
    TechnologyId.ElectricMine: "Electric Mine",
    TechnologyId.Snowman: "Snowman",
    TechnologyId.HelzephyrSaddle: "Helzephyr Saddle",
    TechnologyId.BlazehowlSaddle: "Blazehowl Saddle",
    TechnologyId.ClockSet: "Clock Set",
    TechnologyId.AbilityGlasses: "Ability Glasses",
    TechnologyId.ImprovedFurnace: "Improved Furnace",
    TechnologyId.RefinedMetalAxe: "Refined Metal Axe",
    TechnologyId.RefinedMetalPickaxe: "Refined Metal Pickaxe",
    TechnologyId.RefinedMetalSpear: "Refined Metal Spear",
    TechnologyId.BeakonSaddle: "Beakon Saddle",
    TechnologyId.PyrinNoctSaddle: "Pyrin Noct Saddle",
    TechnologyId.PolapupSaddle: "Polapup Saddle",
    TechnologyId.StorageContainerSet: "Storage Container Set",
    TechnologyId.AirDashBoots: "Air Dash Boots",
    TechnologyId.UltraSphere: "Ultra Sphere",
    TechnologyId.SphereAssemblyLineII: "Sphere Assembly Line II",
    TechnologyId.GrassGrenade: "Grass Grenade",
    TechnologyId.CircuitBoard: "Circuit Board",
    TechnologyId.CarbonFiber: "Carbon Fiber",
    TechnologyId.WhalaskaSaddle: "Whalaska Saddle",
    TechnologyId.BlazehowlNoctSaddle: "Blazehowl Noct Saddle",
    TechnologyId.MetalChairAndDeskSet: "Metal Chair and Desk Set",
    TechnologyId.HugeFeedBag: "Huge Feed Bag",
    TechnologyId.SingleShotRifle: "Single-Shot Rifle",
    TechnologyId.RifleAmmo: "Rifle Ammo",
    TechnologyId.PalSurgeryTable: "Pal Surgery Table",
    TechnologyId.OnionPlantation: "Onion Plantation",
    TechnologyId.HighQualityCloth: "High Quality Cloth",
    TechnologyId.LargePalBed: "Large Pal Bed",
    TechnologyId.QuivernSaddle: "Quivern Saddle",
    TechnologyId.AntiqueLampSet: "Antique Lamp Set",
    TechnologyId.ElectricEggIncubator: "Electric Egg Incubator",
    TechnologyId.SMG: "SMG",
    TechnologyId.RefinedMetalArmor: "Refined Metal Armor",
    TechnologyId.RefinedMetalHelm: "Refined Metal Helm",
    TechnologyId.Accumulator: "Accumulator",
    TechnologyId.RagnahawkSaddle: "Ragnahawk Saddle",
    TechnologyId.GhanglerSaddle: "Ghangler Saddle",
    TechnologyId.IronwoodTableSet: "Ironwood Table Set",
    TechnologyId.ScatterSphereLauncher: "Scatter Sphere Launcher",
    TechnologyId.MeteorLauncher: "Meteor Launcher",
    TechnologyId.GroundGrenade: "Ground Grenade",
    TechnologyId.DeluxeBait: "Deluxe Bait",
    TechnologyId.Refrigerator: "Refrigerator",
    TechnologyId.IceMine: "Ice Mine",
    TechnologyId.ReptyroCrystSaddle: "Reptyro Cryst Saddle",
    TechnologyId.FalerisSaddle: "Faleris Saddle",
    TechnologyId.OutdoorFurnitureSet: "Outdoor Furniture Set",
    TechnologyId.OreMiningSiteII: "Ore Mining Site II",
    TechnologyId.DoubleBarreledShotgun: "Double-Barreled Shotgun",
    TechnologyId.ShotgunShell: "Shotgun Shell",
    TechnologyId.SliderModule: "Slider Module",
    TechnologyId.GlassStructureSet: "Glass Structure Set",
    TechnologyId.RefinedMetalChest: "Refined Metal Chest",
    TechnologyId.PengulletLuxSRocketLauncher: "Pengullet Lux's Rocket Launcher",
    TechnologyId.JormuntideSaddle: "Jormuntide Saddle",
    TechnologyId.MetalBarrelSet: "Metal Barrel Set",
    TechnologyId.DoubleJumpBoots: "Double Jump Boots",
    TechnologyId.DarkGrenade: "Dark Grenade",
    TechnologyId.HeatResistantRefinedMetalArmor: "Heat Resistant Refined Metal Armor",
    TechnologyId.GigaGlider: "Giga Glider",
    TechnologyId.MountedMachineGun: "Mounted Machine Gun",
    TechnologyId.BlazamutSaddle: "Blazamut Saddle",
    TechnologyId.GrizzboltSMinigun: "Grizzbolt's Minigun",
    TechnologyId.LeatherChairSet: "Leather Chair Set",
    TechnologyId.GuildChest: "Guild Chest",
    TechnologyId.SemiAutoRifle: "Semi-Auto Rifle",
    TechnologyId.ColdResistantRefinedMetalArmor: "Cold Resistant Refined Metal Armor",
    TechnologyId.ElectricKitchen: "Electric Kitchen",
    TechnologyId.AlphaWaveGenerator: "Alpha Wave Generator",
    TechnologyId.ElectricHeater: "Electric Heater",
    TechnologyId.SuzakuSaddle: "Suzaku Saddle",
    TechnologyId.StreetLampSet: "Street Lamp Set",
    TechnologyId.CoalMine: "Coal Mine",
    TechnologyId.DragonGrenade: "Dragon Grenade",
    TechnologyId.ProductionAssemblyLineII: "Production Assembly Line II",
    TechnologyId.ElectricCooler: "Electric Cooler",
    TechnologyId.IronGate: "Iron Gate",
    TechnologyId.KingpacaCrystSaddle: "Kingpaca Cryst Saddle",
    TechnologyId.PalumbaSaddle: "Palumba Saddle",
    TechnologyId.AmusementFurnitureSet: "Amusement Furniture Set",
    TechnologyId.EmergencyExitSignSet: "Emergency Exit Sign Set",
    TechnologyId.MediumPouch: "Medium Pouch",
    TechnologyId.PumpActionShotgun: "Pump-Action Shotgun",
    TechnologyId.HyperShield: "Hyper Shield",
    TechnologyId.ElectricMedicineWorkbench: "Electric Medicine Workbench",
    TechnologyId.MetalDefensiveWall: "Metal Defensive Wall",
    TechnologyId.SuzakuAquaSaddle: "Suzaku Aqua Saddle",
    TechnologyId.JormuntideIgnisSaddle: "Jormuntide Ignis Saddle",
    TechnologyId.YakumoSaddle: "Yakumo Saddle",
    TechnologyId.LilySSpear: "Lily's Spear",
    TechnologyId.LegendarySphere: "Legendary Sphere",
    TechnologyId.ElectricFurnace: "Electric Furnace",
    TechnologyId.Katana: "Katana",
    TechnologyId.PalMetalPickaxe: "Pal Metal Pickaxe",
    TechnologyId.PalMetalAxe: "Pal Metal Axe",
    TechnologyId.RelaxaurusMissileLauncher: "Relaxaurus' Missile Launcher",
    TechnologyId.WumpoSaddle: "Wumpo Saddle",
    TechnologyId.DecalGunSet: "Decal Gun Set",
    TechnologyId.AssaultRifle: "Assault Rifle",
    TechnologyId.AssaultRifleAmmo: "Assault Rifle Ammo",
    TechnologyId.AdvancedFishingRodPengullet: "Advanced Fishing Rod (Pengullet)",
    TechnologyId.DraftingTable: "Drafting Table",
    TechnologyId.WumpoBotanSaddle: "Wumpo Botan Saddle",
    TechnologyId.MammorestCrystSaddle: "Mammorest Cryst Saddle",
    TechnologyId.ChilletIgnisSaddle: "Chillet Ignis Saddle",
    TechnologyId.TrafficControlSet: "Traffic Control Set",
    TechnologyId.SulfurMine: "Sulfur Mine",
    TechnologyId.PalMetalArmor: "Pal Metal Armor",
    TechnologyId.PalMetalHelm: "Pal Metal Helm",
    TechnologyId.BetaWaveGenerator: "Beta Wave Generator",
    TechnologyId.LargeMountedLamp: "Large Mounted Lamp",
    TechnologyId.RelaxaurusLuxSMissileLauncher: "Relaxaurus Lux's Missile Launcher",
    TechnologyId.ShroomerSaddle: "Shroomer Saddle",
    TechnologyId.BralohaSaddle: "Braloha Saddle",
    TechnologyId.RoadSignSet: "Road Sign Set",
    TechnologyId.GiantFeedBag: "Giant Feed Bag",
    TechnologyId.SemiAutoShotgun: "Semi-Auto Shotgun",
    TechnologyId.WeaponAssemblyLineII: "Weapon Assembly Line II",
    TechnologyId.SniperModuleSphereModuleSniper2: "Sniper Module Ⅱ",
    TechnologyId.LargeCeilingLamp: "Large Ceiling Lamp",
    TechnologyId.AstegonSaddle: "Astegon Saddle",
    TechnologyId.ShadowbeakSaddle: "Shadowbeak Saddle",
    TechnologyId.ShroomerNoctSaddle: "Shroomer Noct Saddle",
    TechnologyId.LargeIncubator: "Large Incubator",
    TechnologyId.HeatResistantPalMetalArmor: "Heat Resistant Pal Metal Armor",
    TechnologyId.SkillfruitOrchard: "Skillfruit Orchard",
    TechnologyId.GoldCoinAssemblyLine: "Gold Coin Assembly Line",
    TechnologyId.ElectricPylon: "Electric Pylon",
    TechnologyId.FrostallionSaddle: "Frostallion Saddle",
    TechnologyId.FrostallionNoctSaddle: "Frostallion Noct Saddle",
    TechnologyId.BarricadeSet: "Barricade Set",
    TechnologyId.GrapplingGun4: "GrapplingGun4",
    TechnologyId.RocketLauncher: "Rocket Launcher",
    TechnologyId.RocketAmmo: "Rocket Ammo",
    TechnologyId.ItemRetrievalMachine: "Item Retrieval Machine",
    TechnologyId.LargeScaleStoneOven: "Large-Scale Stone Oven",
    TechnologyId.PaladiusSaddle: "Paladius Saddle",
    TechnologyId.NecromusSaddle: "Necromus Saddle",
    TechnologyId.QuivernBotanSaddle: "Quivern Botan Saddle",
    TechnologyId.LargePowerGenerator: "Large Power Generator",
    TechnologyId.ColdResistantPalMetalArmor: "Cold Resistant Pal Metal Armor",
    TechnologyId.MountedMissileLauncher: "Mounted Missile Launcher",
    TechnologyId.Plasteel: "Plasteel",
    TechnologyId.CrudeOilExtractor: "Crude Oil Extractor",
    TechnologyId.JapaneseStyleStructureSet: "Japanese-Style Structure Set",
    TechnologyId.JetragonSMissileLauncher: "Jetragon's Missile Launcher",
    TechnologyId.XenogardSaddle: "Xenogard Saddle",
    TechnologyId.PureQuartzMine: "Pure Quartz Mine",
    TechnologyId.UltimateSphere: "Ultimate Sphere",
    TechnologyId.PlasteelArmor: "Plasteel Armor",
    TechnologyId.PlasteelHelmet: "Plasteel Helmet",
    TechnologyId.LaserRifle: "Laser Rifle",
    TechnologyId.EnergyCartridge: "Energy Cartridge",
    TechnologyId.ColdFoodBox: "Cold Food Box",
    TechnologyId.DazziNoctSNecklace: "Dazzi Noct's Necklace",
    TechnologyId.LockpickingToolV3: "Lockpicking Tool v3",
    TechnologyId.GliderTera: "Glider_Tera",
    TechnologyId.Flamethrower: "Flamethrower",
    TechnologyId.FlamethrowerFuel: "Flamethrower Fuel",
    TechnologyId.AlluringBait: "Alluring Bait",
    TechnologyId.RefrigeratedCrusher: "Refrigerated Crusher",
    TechnologyId.HelzephyrLuxSaddle: "Helzephyr Lux Saddle",
    TechnologyId.FenglopeLuxSaddle: "Fenglope Lux Saddle",
    TechnologyId.LargePouch: "Large Pouch",
    TechnologyId.HeatResistantPlasteelArmor: "Heat Resistant Plasteel Armor",
    TechnologyId.GrenadeLauncher: "Grenade Launcher",
    TechnologyId.GrenadeAmmo: "Grenade Ammo",
    TechnologyId.FragGrenadeMk2: "Frag Grenade Mk2",
    TechnologyId.SelyneSaddle: "Selyne Saddle",
    TechnologyId.NyafiaSShotgun: "Nyafia's Shotgun",
    TechnologyId.KitsunNoctSaddle: "Kitsun Noct Saddle",
    TechnologyId.ColdResistantPlasteelArmor: "Cold Resistant Plasteel Armor",
    TechnologyId.GatlingGun: "Gatling Gun",
    TechnologyId.GatlingGunAmmo: "Gatling Gun Ammo",
    TechnologyId.PalDisassemblyConveyor: "Pal Disassembly Conveyor",
    TechnologyId.DoubleAirDashBoots: "Double Air Dash Boots",
    TechnologyId.GildaneSaddle: "Gildane Saddle",
    TechnologyId.JapaneseStyleFurnitureSet: "Japanese-Style Furniture Set",
    TechnologyId.LargeFishingPond: "Large Fishing Pond",
    TechnologyId.ShieldUltra: "Shield_Ultra",
    TechnologyId.LightweightPlasteelArmor: "Lightweight Plasteel Armor",
    TechnologyId.GuidedMissileLauncher: "Guided Missile Launcher",
    TechnologyId.MissileAmmo: "Missile Ammo",
    TechnologyId.BlazamutRyuSaddle: "Blazamut Ryu Saddle",
    TechnologyId.FalerisAquaSaddle: "Faleris Aqua Saddle",
    TechnologyId.HomingSphereLauncher: "Homing Sphere Launcher",
    TechnologyId.ExoticSphere: "Exotic Sphere",
    TechnologyId.AdvancedSphereAssemblyLine: "Advanced Sphere Assembly Line",
    TechnologyId.Hexolite: "Hexolite",
    TechnologyId.GiganticFurnace: "Gigantic Furnace",
    TechnologyId.MetalDetector: "Metal Detector",
    TechnologyId.AzurmaneSaddle: "Azurmane Saddle",
    TechnologyId.SmokieSHarness: "Smokie's Harness",
    TechnologyId.ULTRAKILLCollabSet2: "ULTRAKILL Collab Set 2",
    TechnologyId.AdvancedBow: "Advanced Bow",
    TechnologyId.AdvancedArrow: "Advanced Arrow",
    TechnologyId.HexoliteArmor: "Hexolite Armor",
    TechnologyId.BeamSword: "Beam Sword",
    TechnologyId.HomingModule: "Homing Module",
    TechnologyId.PalPod: "Pal Pod",
    TechnologyId.StarryonSaddle: "Starryon Saddle",
    TechnologyId.GiantPouch: "Giant Pouch",
    TechnologyId.AdvancedChest: "Advanced Chest",
    TechnologyId.LaserGatlingGun: "Laser Gatling Gun",
    TechnologyId.LaserGatlingCartridge: "Laser Gatling Cartridge",
    TechnologyId.HexoliteHelmet: "Hexolite Helmet",
    TechnologyId.SilvegisSaddle: "Silvegis Saddle",
    TechnologyId.CelesdirSaddle: "Celesdir Saddle",
    TechnologyId.TripleJumpBoots: "Triple Jump Boots",
    TechnologyId.AdvancedRecoveryMeds: "Advanced Recovery Meds",
    TechnologyId.RevivalPotion: "Revival Potion",
    TechnologyId.AdvancedMedicineWorkbench: "Advanced Medicine Workbench",
    TechnologyId.HeatResistantHexoliteArmor: "Heat Resistant Hexolite Armor",
    TechnologyId.ColdResistantHexoliteArmor: "Cold Resistant Hexolite Armor",
    TechnologyId.BastigorSHammer: "Bastigor's Hammer",
    TechnologyId.PlasmaCannon: "Plasma Cannon",
    TechnologyId.PlasmaCartridge: "Plasma Cartridge",
    TechnologyId.AdvancedShield: "Advanced Shield",
    TechnologyId.LightweightHexoliteArmor: "Lightweight Hexolite Armor",
    TechnologyId.XenolordSaddle: "Xenolord Saddle",
    TechnologyId.LargeScaleElectricEggIncubator: "Large-Scale Electric Egg Incubator",
    TechnologyId.PowerfulFishingMagnet: "Powerful Fishing Magnet",
    TechnologyId.CoralumIngot: "Coralum Ingot",
    TechnologyId.AdvancedWorkshop: "Advanced Workshop",
    TechnologyId.FuturisticStructureSet: "Futuristic Structure Set",
    TechnologyId.GhanglerIgnisSaddle: "Ghangler Ignis Saddle",
    TechnologyId.HexoliteQuartzMine: "Hexolite Quartz Mine",
    TechnologyId.EnergyShotgun: "Energy Shotgun",
    TechnologyId.EnergyShotgunAmmo: "Energy Shotgun Ammo",
    TechnologyId.AdvancedWeaponAssemblyLine: "Advanced Weapon Assembly Line",
    TechnologyId.JapaneseStyleHotSpring: "Japanese-Style Hot Spring",
    TechnologyId.WhalaskaIgnisSaddle: "Whalaska Ignis Saddle",
    TechnologyId.TripleAirDashBoots: "Triple Air Dash Boots",
    TechnologyId.MegaboostGun: "Megaboost Gun",
    TechnologyId.RayneSyndicateFlagSet: "Rayne Syndicate Flag Set",
    TechnologyId.FreePalAllianceFlagSet: "Free Pal Alliance Flag Set",
    TechnologyId.NeptiliusSaddle: "Neptilius Saddle",
    TechnologyId.GrapplingGun5: "GrapplingGun5",
    TechnologyId.OverheatRifle: "Overheat Rifle",
    TechnologyId.OverheatRifleAmmo: "Overheat Rifle Ammo",
    TechnologyId.BrothersOfTheEternalPyreFlagSet: "Brothers of the Eternal Pyre Flag Set",
    TechnologyId.PIDFFlagSet: "PIDF Flag Set",
    TechnologyId.ChargeRifle: "Charge Rifle",
    TechnologyId.ChargeRifleAmmo: "Charge Rifle Ammo",
    TechnologyId.PALGeneticResearchUnitFlagSet: "PAL Genetic Research Unit Flag Set",
    TechnologyId.MoonflowerFlagSet: "Moonflower Flag Set",
    TechnologyId.HartalisSaddle: "Hartalis Saddle",
}
