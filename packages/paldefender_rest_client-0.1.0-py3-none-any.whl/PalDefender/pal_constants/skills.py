from enum import Enum

class SkillId(str, Enum):
    EnTextTidalWave = "TidalWave"
    UnknownSkillWaterWave = "WaterWave"
    HydroJet = "AquaJet"
    AquaGun = "WaterGun"
    BubbleBlast = "BubbleShot"
    AcidRain = "AcidRain"
    AquaBurst = "WaterBall"
    SurfingSlam = "Unique_BluePlatypus_Toboggan"
    HydroLaser = "HydroPump"
    Intimidate = "Intimidate"
    Punch = "Human_Punch"
    AirCannon = "AirCanon"
    ChickenRush = "Unique_ChickenPal_ChickenPeck"
    PowerShot = "PowerShot"
    RolyPoly = "Unique_SheepBall_Roll"
    PunchFlurry = "Unique_PinkCat_CatPunch"
    FluffyTackle = "Unique_Alpaca_Tackle"
    FierceFang = "Unique_Garm_Bite"
    AntlerUppercut = "Unique_Deer_PushupHorn"
    RecklessCharge = "Unique_Boar_Tackle"
    GaleClaw = "Unique_Eagle_GlidingNail"
    CatPress = "Unique_NaughtyCat_CatPress"
    EnTextThrow = "Throw"
    TornadoAttack = "Unique_HawkBird_Storm"
    PowerBomb = "PowerBall"
    MuscleSlam = "Unique_SakuraSaurus_SideTackle"
    GroundPound = "Unique_Gorilla_GroundPunch"
    CloudTempest = "Unique_FengyunDeeper_CloudTempest"
    EnTextScratch = "Scratch"
    UnknownSkillWorkAttack = "WorkAttack"
    KinglySlam = "Unique_KingAlpaca_BodyPress"
    SpearThrust = "Unique_SaintCentaur_OneSpearRushes"
    PalBlast = "HyperBeam"
    Implode = "SelfDestruct"
    BeeQuiet = "SelfDestruct_Bee"
    MegatonImplode = "SelfExplosion"
    WindCutter = "WindCutter"
    SeedMachineGun = "SeedMachinegun"
    BotanicalSmash = "Unique_FlowerDinosaur_Whip"
    Multicutter = "SpecialCutter"
    SeedMine = "SeedMine"
    FocusShot = "Unique_RobinHood_BowSnipe"
    SpinningStaff = "Unique_QueenBee_SpinLance"
    GrassTornado = "GrassTornado"
    CrushingPunch = "Unique_GrassPanda_MusclePunch"
    SpineVine = "RootAttack"
    SolarBlast = "SolarBeam"
    EnTextSnowStorm = "SnowStorm"
    IceMissile = "EnergyShot"
    IceMissileIceMissile = "IceMissile"
    IcicleCutter = "IceBlade"
    FreezingCharge = "Unique_IceDeer_IceHorn"
    Iceberg = "BlizzardLance"
    EmperorSlide = "Unique_CaptainPenguin_BodySlide"
    CrystalBreath = "FrostBreath"
    FrostBurst = "Unique_VolcanicMonster_Ice_IceAttack"
    CrystalWing = "Unique_IceHorse_IceBladeAttack"
    BlizzardSpike = "IcicleThrow"
    IgnisBlast = "FireBlast"
    SpiritFire = "FireSeed"
    BlazingHorn = "Unique_FlameBuffalo_FlameHorn"
    FlareArrow = "FlareArrow"
    Iaigiri = "Unique_Ronin_Iai"
    IgnisBreath = "Flamethrower"
    HellfireClaw = "Unique_Baphomet_SwallowKite"
    DaringFlames = "Unique_AmaterasuWolf_FireCharge"
    FlareStorm = "FlareTornado"
    IgnisCharge = "Unique_FireKirin_Tackle"
    VolcanicBurst = "Unique_VolcanicMonster_MagmaAttack"
    IgnisRage = "Inferno"
    PhoenixFlare = "Unique_Horus_FlareBird"
    FireBall = "FireBall"
    CrossLightning = "CrossThunder"
    ThunderRain = "ThunderRain"
    SparkBlast = "SpreadPulse"
    UnknownSkillFunnelRaijinDaughter = "Funnel_RaijinDaughter"
    Shockwave = "ElecWave"
    ElectricBall = "ThunderBall"
    PlasmaFunnel = "ThunderFunnel"
    LockOnLaser = "LockonLaser"
    LightningClaw = "Unique_ElecPanda_ElecScratch"
    LightningStreak = "LineThunder"
    BlastPunch = "Unique_GrassPanda_Electric_ElectricPunch"
    TriLightning = "ThreeThunder"
    LightningGale = "Unique_Kirin_LightningTackle"
    Kerauno = "Unique_ThunderDragonMan_ThunderSwordAttack"
    LightningStrike = "LightningStrike"
    LightningBolt = "Thunderbolt"
    BogBlast = "MudShot"
    StoneBlast = "StoneShotgun"
    ShellSpin = "Unique_DrillGame_ShellAttack"
    StoneCannon = "ThrowRock"
    GigaHorn = "Unique_HerculesBeetle_BeetleTackle"
    SandTornado = "SandTornado"
    SpinningRoundhouse = "Unique_Anubis_LowRoundKick"
    EarthImpact = "Unique_Grassmammoth_Earthquake"
    ForcefulCharge = "Unique_Anubis_Tackle"
    GroundSmash = "Unique_Anubis_GroundPunch"
    RockLance = "RockLance"
    DragonCannon = "DragonCanon"
    DragonBurst = "DragonWave"
    DraconicBreath = "DragonBreath"
    MysticWhirlwind = "Unique_FairyDragon_FairyTornado"
    BeamComet = "Unique_JetDragon_JumpBeam"
    DragonMeteor = "DragonMeteor"
    PoisonFog = "PoisonFog"
    UnknownSkillFunnelDreamDemon = "Funnel_DreamDemon"
    PoisonBlast = "PoisonShot"
    DarkBall = "DarkBall"
    ShadowBurst = "DarkWave"
    PhantomPeck = "Unique_DarkCrow_TelePoke"
    JumpingClaw = "Unique_Werewolf_Scratch"
    SpiritFlame = "GhostFlame"
    DarkCharge = "Unique_FireKirin_Dark_DarkTossin"
    NightmareBall = "ShadowBall"
    PsychoGravity = "Psychokinesis"
    TwinSpears = "Unique_BlackCentaur_TwoSpearRushes"
    DarkLaser = "DarkLaser"
    DivineDisaster = "Unique_BlackGriffon_TackleLaser"
    DarkWhisp = "DarkLegion"
    RocketSlam = "Unique_WeaselDragon_FlyingTackle"
    Rockburst = "Tremor"
    DiamondRain = "DiamondFall"
    BeamSlicer = "BeamSlicer"
    NightmareBloom = "Unique_NightLady_WarpBeam"
    FlameWaltz = "Unique_NightLady_FlameNightmare"
    CometStrike = "Commet"
    UmbralSurge = "DarkPulse"
    DarkCannon = "DarkCanon"
    DarkArrow = "DarkArrow"
    Apocalypse = "Apocalypse"
    NightmareRay = "Unique_NightLady_WarpBeam_Straight"
    JumpingStinger = "Unique_DarkScorpion_Pierce"
    StarMine = "StarMine"
    EarthDash = "Unique_FeatherOstrich_Tossin"
    CircleVine = "RootLance"
    Polykeraunos = "Unique_ThunderDragonMan_NumerousSwordAttack"
    MagnaCrush = "Unique_KingBahamut_AirCrash"
    Splash = "LineGeyser"
    ChargeCannon = "ChargeCanon"
    BrawnImpact = "Unique_KingBahamut_ArmSmash"
    GroundCutter = "Unique_WingGolem_RoundCutter"
    BlastCannon = "BlastCanon"
    CometBarrage = "ThreeCommet"
    Meteorain = "CommetRain"
    VolcanicRain = "Eruption"
    HeavyThunderTank = "Unique_ElecPanda_GatlingAttack"
    BountifulProtection = "Unique_LilyQueen_LilyHealing"
    HolyBurst = "HolyBlast"
    EvilSlash = "Unique_DarkAlien_JumpScractch"
    MoonlightBeam = "Unique_MoonQueen_MoonBeam"
    FlameWall = "FlameWall"
    AirBlade = "AirBlade"
    SeigetsuBlade = "Unique_MoonQueen_MoonBlade"
    WholeheartedStance = "Unique_SifuDog_Counter"
    CurtainSplash = "WallSplash"
    TriSpark = "TriSpark"
    Thunderstorm = "ThunderStorm"
    UpperSmash = "Unique_ScorpionMan_Uppercut"
    FlameFunnel = "FlameFunnel"
    SandTwister = "SandTwister"
    AllRangeThunder = "RangeThunder"
    ThunderRail = "Railbolt"
    LethalLaser = "ShokeiLaser"
    PoisonShower = "BubbleShower"
    UnknownSkillWaterBalloon = "WaterBalloon"
    IcicleBullet = "IciclePierce"
    DoubleBlizzardSpike = "DoubleIcicleThrow"
    AbsoluteFrost = "IceAge"
    RaidCutter = "RaidCutter"
    WindEdge = "WindEdge"
    FlareTwister = "FlareTwister"
    RagingFlameWave = "Unique_Horus_PerfectStorm"
    DivineDisasterII = "Unique_BlackGriffon_TackleLaser2"
    SeigetsuFlash = "Unique_MoonQueen_IceMoonBlade"
    IcicleLine = "IcicleLine"
    VolcanicFang = "Unique_Manticore_InfernoStrike"
    LightningDive = "Unique_ThunderBird_ThunderStorm"
    WindBarrier = "Unique_LilyQueen_WindBarrier"
    FirefistBreathstorm = "Unique_BlackMetalDragon_FirePunch"
    LeapingRoundhouse = "Unique_GrassRabbitMan_GrassRoundKick"
    SnowBowling = "Unique_Yeti_SnowBall"
    SlitherSlam = "Unique_Umihebi_WindingTackle"
    NeedleSpear = "Unique_SoldierBee_NeedleLance"
    RushBeak = "Unique_RedArmorBird_TriplePeck"
    BeckonLightning = "Unique_ThunderDog_InazumaShorai"
    SpiritDash = "Unique_GhostBeast_Tossin"
    FlameBreath = "Unique_BirdDragon_FireBreath"
    BlizzardClaw = "Unique_WhiteTiger_IceScratch"
    SatelliteBit = "Unique_DarkMechaDragon_SetFunnel"
    OmegaLaser = "Unique_DarkMechaDragon_FunnelLaser"
    AstralRay = "Unique_DarkMechaDragon_ConvergentBeam"
    BeamSlash = "Unique_DarkMechaDragon_BeamSlash"
    CosmicMeteor = "Unique_DarkMechaDragon_WarpComet"
    TempestBlizzard = "Unique_BirdDragon_Ice_IceBreath"
    MagmaSerpent = "Unique_Umihebi_Fire_FireWindingTackle"
    PredatorSurge = "PredatorWave"
    PredatorBlast = "PredatorBeam"
    PredatorMark = "PredatorLockon"
    StoneClaw = "Unique_WhiteTiger_Ground_IronScratch"
    ThunderTempest = "Unique_FengyunDeeper_Electric_ThunderTempest"
    SnowClaw = "Unique_Werewolf_Ice_SnowScratch"
    PhoenixTide = "Unique_Horus_Water_AquaStorm"
    DaringShadowstorm = "Unique_AmaterasuWolf_Dark_DarkCharge"
    StoneBeat = "RockBeat"
    LawnBowling = "Unique_Yeti_Grass_GrassBall"
    GlacialImpact = "Unique_SnowTigerBeastman_SnowImpact"
    WebstrikeImpact = "Unique_PurpleSpider_SpiderRaid"
    FrostTalon = "Unique_SnowTigerBeastman_TrampleSlash"
    SoulDrain = "Unique_MysteryMask_LifeSteal"
    GrudgeBarrage = "Unique_GrimGirl_BrutalMachete"
    AegisCharge = "Unique_WhiteShieldDragon_ShieldTackle"
    BoltBlink = "Unique_BlueThunderHorse_FlashDash"
    HolyNova = "Unique_WhiteDeer_HolyPillar"
    LethalStep = "Unique_NightBlueHorse_DeathStep"
    CrashDash = "Unique_GoldenHorse_StoneDash"
    UnknownSkillFunnelRaijinDaughterWater = "Funnel_RaijinDaughter_Water"
    PlasmaDash = "PARTNERSKILL_BlueThunderHorse"
    GeyserGush = "SeaGush"
    AquaSurge = "RipTide"
    HydroSlicer = "HydroSlicer"
    TorrentialBlast = "DiversionLaser"
    Crosswind = "CrossWind"
    FreezeWall = "IceWall"
    SmokeJet = "Unique_OctopursGirl_InkJet"
    HydroSpin = "Unique_TentacleTurtle_HydroSpin"
    KonohaFlip = "Unique_LeafMomonga_SomerSault"
    HighBreach = "Unique_IceNarwhal_JumpingHorn"
    LanternSweep = "Unique_GhostAnglerfish_SweepBait"
    TriggerHappy = "Unique_StuffedShark_HiddenWeapon"
    DarkShot = "GravityShot"
    ThunderSpear = "ThunderSpear"
    ReflectLeaf = "ReflectiveShuriken"
    UnknownSkillHealingTree = "HealingTree"
    ChaoticSpray = "Unique_IceCrocodile_SpitAttack"
    UnknownSkillUniqueYakushimaBoss002PhantasmalDeathray = "Unique_YakushimaBoss002_PhantasmalDeathray"
    UnknownSkillUniqueYakushimaBoss002PhantasmalEye = "Unique_YakushimaBoss002_PhantasmalEye"
    UnknownSkillUniqueYakushimaBoss002PhantasmalBolt = "Unique_YakushimaBoss002_PhantasmalBolt"
    UnknownSkillUniqueYakushimaBoss002PhantasmalSphere = "Unique_YakushimaBoss002_PhantasmalSphere"
    LockOnLunge = "Unique_Yakushima_EyeTossin"
    ServantCall = "Unique_Yakushima_SummonServant"
    ScorchingLanternSweep = "Unique_GhostAnglerfish_Fire_SweepBait_Fire"
    Thunderslide = "Unique_CaptainPenguin_Black_BodySlide_Electric"
    DeepBreath = "Unique_Plesiosaur_LongBreath"
    DashKick = "Unique_TropicalOstrich_DashKick"
    FrenziedCharge = "Unique_Yakushima_MouthTossin"
    UnknownSkillUniqueYakushimaBoss001GreenPhantasmalBolt = "Unique_YakushimaBoss001_Green_PhantasmalBolt"
    UnknownSkillUniqueYakushimaBoss001GreenPhantasmalEye = "Unique_YakushimaBoss001_Green_PhantasmalEye"
    UnknownSkillUniqueYakushimaBoss001GreenPhantasmalSphere = "Unique_YakushimaBoss001_Green_PhantasmalSphere"
    UnknownSkillUniqueYakushimaBoss001GreenPhantasmalDeathray = "Unique_YakushimaBoss001_Green_PhantasmalDeathray"
    ThalassonicLaser = "Unique_PoseidonOrca_TorrentLaser"
    SlimePressNeutral = "Unique_YakushimaMonster001_SlimePress_Normal"
    SlimePressGrass = "Unique_YakushimaMonster001_SlimePress_Leaf"
    SlimePressWater = "Unique_YakushimaMonster001_SlimePress_Water"
    SlimePressFire = "Unique_YakushimaMonster001_SlimePress_Fire"
    SlimePressDark = "Unique_YakushimaMonster001_SlimePress_Dark"
    SlimePressRainbow = "Unique_YakushimaMonster001_SlimePress_Rainbow"
    OcularRush = "Unique_YakushimaBoss001_Small_DemonEyeCharge"
    SwordCharge = "Unique_YakushimaMonster002_SwordCharge"
    WingedAssault = "Unique_YakushimaMonster003_BatCharge"
    FireTackle = "Unique_BluePlatypus_Toboggan_Fire"
    SentinelOfTheGreatSea = "PARTNERSKILL_PoseidonOrca"
    UnknownSkillPoseidonOrcaPartnerSkillSpearBullet = "PoseidonOrca_PartnerSkill_SpearBullet"
    UnknownSkillHumanRolling = "Human_Rolling"
    UseWeapon = "Weapon_Use"
    UnknownSkillUniqueFlowerDinosaurElectricThunderWhip = "Unique_FlowerDinosaur_Electric_ThunderWhip"
    UnknownSkillUniqueKingAlpacaIceIcePress = "Unique_KingAlpaca_Ice_IcePress"
    UnknownSkillUniqueBaphometDarkDarkKite = "Unique_Baphomet_Dark_DarkKite"
    UnknownSkillUniqueSakuraSaurusWaterSplashTackle = "Unique_SakuraSaurus_Water_SplashTackle"
    UnknownSkillUniqueDeerGroundDirtyHorn = "Unique_Deer_Ground_DirtyHorn"
    UnknownSkillUniqueGorillaGroundEarthPunch = "Unique_Gorilla_Ground_EarthPunch"
    UnknownSkillUniqueIceHorseDarkDarkBladeAttack = "Unique_IceHorse_Dark_DarkBladeAttack"
    UnknownSkillUniqueYakushimaBoss0022PhantasmalDeathray = "Unique_YakushimaBoss002_2_PhantasmalDeathray"
    UnknownSkillUniqueYakushimaBoss0022PhantasmalEye = "Unique_YakushimaBoss002_2_PhantasmalEye"
    UnknownSkillUniqueYakushimaBoss0022PhantasmalBolt = "Unique_YakushimaBoss002_2_PhantasmalBolt"
    UnknownSkillUniqueYakushimaBoss0022PhantasmalSphere = "Unique_YakushimaBoss002_2_PhantasmalSphere"
    UnknownSkillUniqueYakushimaBoss001Green2PhantasmalBolt = "Unique_YakushimaBoss001_Green_2_PhantasmalBolt"
    UnknownSkillUniqueYakushimaBoss001Green2PhantasmalEye = "Unique_YakushimaBoss001_Green_2_PhantasmalEye"
    UnknownSkillUniqueYakushimaBoss001Green2PhantasmalSphere = "Unique_YakushimaBoss001_Green_2_PhantasmalSphere"
    UnknownSkillUniqueYakushimaBoss001Green2PhantasmalDeathray = "Unique_YakushimaBoss001_Green_2_PhantasmalDeathray"
    UnknownSkillUniqueGarmBiteV2 = "Unique_Garm_BiteV2"
    UnknownSkillUniqueThunderDogBiteV2 = "Unique_ThunderDog_BiteV2"
    UnknownSkillUniqueThunderDogBite = "Unique_ThunderDog_Bite"
    UnknownSkillUniqueGuardianDogBite = "Unique_GuardianDog_Bite"
    UnknownSkillUniqueGuardianDogBiteV2 = "Unique_GuardianDog_BiteV2"
    UnknownSkillUniqueGoldenHorseBite = "Unique_GoldenHorse_Bite"
    UnknownSkillUniqueGoldenHorseBiteV2 = "Unique_GoldenHorse_BiteV2"
    UnknownSkillUniqueAmaterasuWolfBite = "Unique_AmaterasuWolf_Bite"
    UnknownSkillUniqueAmaterasuWolfBiteV2 = "Unique_AmaterasuWolf_BiteV2"
    UnknownSkillUniqueAmaterasuWolfDarkBite = "Unique_AmaterasuWolf_Dark_Bite"
    UnknownSkillUniqueAmaterasuWolfDarkBiteV2 = "Unique_AmaterasuWolf_Dark_BiteV2"
    UnknownSkillUniqueBlackPuppyBite = "Unique_BlackPuppy_Bite"
    UnknownSkillUniqueBlackPuppyBiteV2 = "Unique_BlackPuppy_BiteV2"
    UnknownSkillUniqueVolcanoDragonVolcanicLaser = "Unique_VolcanoDragon_VolcanicLaser"
    UnknownSkillUniqueVolcanoDragonMagmaSpit = "Unique_VolcanoDragon_MagmaSpit"
    UnknownSkillUniqueSekhmetSomersaultScratch = "Unique_Sekhmet_SomersaultScratch"
    UnknownSkillUniqueSekhmetRollingScratch = "Unique_Sekhmet_RollingScratch"
    UnknownSkillUniqueNightBlueHorseTossin = "Unique_NightBlueHorse_Tossin"
    UnknownSkillUniqueBlueThunderHorseTossin = "Unique_BlueThunderHorse_Tossin"
    SacredRain = "Unique_LegendDeer_WarpPillarBurst"
    DivineWing = "Unique_LegendDeer_RadiantWingRush"
    UnknownSkillUniqueLegendDeerBarrierReleaseNormal = "Unique_LegendDeer_BarrierRelease_Normal"
    UnknownSkillUniqueLegendDeerBarrierReleaseGrass = "Unique_LegendDeer_BarrierRelease_Grass"
    UnknownSkillUniqueLegendDeerBarrierReleaseWater = "Unique_LegendDeer_BarrierRelease_Water"
    PurifyingLight = "Unique_LegendDeer_RadiantPurge_Otomo"
    RadiantBarrage = "RadiantBarrage"

SKILL_ID_TO_NAME = {
    SkillId.EnTextTidalWave: "en Text (TidalWave)",
    SkillId.UnknownSkillWaterWave: "Unknown Skill (WaterWave)",
    SkillId.HydroJet: "Hydro Jet",
    SkillId.AquaGun: "Aqua Gun",
    SkillId.BubbleBlast: "Bubble Blast",
    SkillId.AcidRain: "Acid Rain",
    SkillId.AquaBurst: "Aqua Burst",
    SkillId.SurfingSlam: "Surfing Slam",
    SkillId.HydroLaser: "Hydro Laser",
    SkillId.Intimidate: "Intimidate",
    SkillId.Punch: "Punch",
    SkillId.AirCannon: "Air Cannon",
    SkillId.ChickenRush: "Chicken Rush",
    SkillId.PowerShot: "Power Shot",
    SkillId.RolyPoly: "Roly Poly",
    SkillId.PunchFlurry: "Punch Flurry",
    SkillId.FluffyTackle: "Fluffy Tackle",
    SkillId.FierceFang: "Fierce Fang",
    SkillId.AntlerUppercut: "Antler Uppercut",
    SkillId.RecklessCharge: "Reckless Charge",
    SkillId.GaleClaw: "Gale Claw",
    SkillId.CatPress: "Cat Press",
    SkillId.EnTextThrow: "en Text (Throw)",
    SkillId.TornadoAttack: "Tornado Attack",
    SkillId.PowerBomb: "Power Bomb",
    SkillId.MuscleSlam: "Muscle Slam",
    SkillId.GroundPound: "Ground Pound",
    SkillId.CloudTempest: "Cloud Tempest",
    SkillId.EnTextScratch: "en Text (Scratch)",
    SkillId.UnknownSkillWorkAttack: "Unknown Skill (WorkAttack)",
    SkillId.KinglySlam: "Kingly Slam",
    SkillId.SpearThrust: "Spear Thrust",
    SkillId.PalBlast: "Pal Blast",
    SkillId.Implode: "Implode",
    SkillId.BeeQuiet: "Bee Quiet",
    SkillId.MegatonImplode: "Megaton Implode",
    SkillId.WindCutter: "Wind Cutter",
    SkillId.SeedMachineGun: "Seed Machine Gun",
    SkillId.BotanicalSmash: "Botanical Smash",
    SkillId.Multicutter: "Multicutter",
    SkillId.SeedMine: "Seed Mine",
    SkillId.FocusShot: "Focus Shot",
    SkillId.SpinningStaff: "Spinning Staff",
    SkillId.GrassTornado: "Grass Tornado",
    SkillId.CrushingPunch: "Crushing Punch",
    SkillId.SpineVine: "Spine Vine",
    SkillId.SolarBlast: "Solar Blast",
    SkillId.EnTextSnowStorm: "en Text (SnowStorm)",
    SkillId.IceMissile: "Ice Missile",
    SkillId.IceMissileIceMissile: "Ice Missile",
    SkillId.IcicleCutter: "Icicle Cutter",
    SkillId.FreezingCharge: "Freezing Charge",
    SkillId.Iceberg: "Iceberg",
    SkillId.EmperorSlide: "Emperor Slide",
    SkillId.CrystalBreath: "Crystal Breath",
    SkillId.FrostBurst: "Frost Burst",
    SkillId.CrystalWing: "Crystal Wing",
    SkillId.BlizzardSpike: "Blizzard Spike",
    SkillId.IgnisBlast: "Ignis Blast",
    SkillId.SpiritFire: "Spirit Fire",
    SkillId.BlazingHorn: "Blazing Horn",
    SkillId.FlareArrow: "Flare Arrow",
    SkillId.Iaigiri: "Iaigiri",
    SkillId.IgnisBreath: "Ignis Breath",
    SkillId.HellfireClaw: "Hellfire Claw",
    SkillId.DaringFlames: "Daring Flames",
    SkillId.FlareStorm: "Flare Storm",
    SkillId.IgnisCharge: "Ignis Charge",
    SkillId.VolcanicBurst: "Volcanic Burst",
    SkillId.IgnisRage: "Ignis Rage",
    SkillId.PhoenixFlare: "Phoenix Flare",
    SkillId.FireBall: "Fire Ball",
    SkillId.CrossLightning: "Cross Lightning",
    SkillId.ThunderRain: "Thunder Rain",
    SkillId.SparkBlast: "Spark Blast",
    SkillId.UnknownSkillFunnelRaijinDaughter: "Unknown Skill (Funnel_RaijinDaughter)",
    SkillId.Shockwave: "Shockwave",
    SkillId.ElectricBall: "Electric Ball",
    SkillId.PlasmaFunnel: "Plasma Funnel",
    SkillId.LockOnLaser: "Lock-on Laser",
    SkillId.LightningClaw: "Lightning Claw",
    SkillId.LightningStreak: "Lightning Streak",
    SkillId.BlastPunch: "Blast Punch",
    SkillId.TriLightning: "Tri-Lightning",
    SkillId.LightningGale: "Lightning Gale",
    SkillId.Kerauno: "Kerauno",
    SkillId.LightningStrike: "Lightning Strike",
    SkillId.LightningBolt: "Lightning Bolt",
    SkillId.BogBlast: "Bog Blast",
    SkillId.StoneBlast: "Stone Blast",
    SkillId.ShellSpin: "Shell Spin",
    SkillId.StoneCannon: "Stone Cannon",
    SkillId.GigaHorn: "Giga Horn",
    SkillId.SandTornado: "Sand Tornado",
    SkillId.SpinningRoundhouse: "Spinning Roundhouse",
    SkillId.EarthImpact: "Earth Impact",
    SkillId.ForcefulCharge: "Forceful Charge",
    SkillId.GroundSmash: "Ground Smash",
    SkillId.RockLance: "Rock Lance",
    SkillId.DragonCannon: "Dragon Cannon",
    SkillId.DragonBurst: "Dragon Burst",
    SkillId.DraconicBreath: "Draconic Breath",
    SkillId.MysticWhirlwind: "Mystic Whirlwind",
    SkillId.BeamComet: "Beam Comet",
    SkillId.DragonMeteor: "Dragon Meteor",
    SkillId.PoisonFog: "Poison Fog",
    SkillId.UnknownSkillFunnelDreamDemon: "Unknown Skill (Funnel_DreamDemon)",
    SkillId.PoisonBlast: "Poison Blast",
    SkillId.DarkBall: "Dark Ball",
    SkillId.ShadowBurst: "Shadow Burst",
    SkillId.PhantomPeck: "Phantom Peck",
    SkillId.JumpingClaw: "Jumping Claw",
    SkillId.SpiritFlame: "Spirit Flame",
    SkillId.DarkCharge: "Dark Charge",
    SkillId.NightmareBall: "Nightmare Ball",
    SkillId.PsychoGravity: "Psycho Gravity",
    SkillId.TwinSpears: "Twin Spears",
    SkillId.DarkLaser: "Dark Laser",
    SkillId.DivineDisaster: "Divine Disaster",
    SkillId.DarkWhisp: "Dark Whisp",
    SkillId.RocketSlam: "Rocket Slam",
    SkillId.Rockburst: "Rockburst",
    SkillId.DiamondRain: "Diamond Rain",
    SkillId.BeamSlicer: "Beam Slicer",
    SkillId.NightmareBloom: "Nightmare Bloom",
    SkillId.FlameWaltz: "Flame Waltz",
    SkillId.CometStrike: "Comet Strike",
    SkillId.UmbralSurge: "Umbral Surge",
    SkillId.DarkCannon: "Dark Cannon",
    SkillId.DarkArrow: "Dark Arrow",
    SkillId.Apocalypse: "Apocalypse",
    SkillId.NightmareRay: "Nightmare Ray",
    SkillId.JumpingStinger: "Jumping Stinger",
    SkillId.StarMine: "Star Mine",
    SkillId.EarthDash: "Earth Dash",
    SkillId.CircleVine: "Circle Vine",
    SkillId.Polykeraunos: "Polykeraunos",
    SkillId.MagnaCrush: "Magna Crush",
    SkillId.Splash: "Splash",
    SkillId.ChargeCannon: "Charge Cannon",
    SkillId.BrawnImpact: "Brawn Impact",
    SkillId.GroundCutter: "Ground Cutter",
    SkillId.BlastCannon: "Blast Cannon",
    SkillId.CometBarrage: "Comet Barrage",
    SkillId.Meteorain: "Meteorain",
    SkillId.VolcanicRain: "Volcanic Rain",
    SkillId.HeavyThunderTank: "Heavy Thunder Tank",
    SkillId.BountifulProtection: "Bountiful Protection",
    SkillId.HolyBurst: "Holy Burst",
    SkillId.EvilSlash: "Evil Slash",
    SkillId.MoonlightBeam: "Moonlight Beam",
    SkillId.FlameWall: "Flame Wall",
    SkillId.AirBlade: "Air Blade",
    SkillId.SeigetsuBlade: "Seigetsu Blade",
    SkillId.WholeheartedStance: "Wholehearted Stance",
    SkillId.CurtainSplash: "Curtain Splash",
    SkillId.TriSpark: "TriSpark",
    SkillId.Thunderstorm: "Thunderstorm",
    SkillId.UpperSmash: "Upper Smash",
    SkillId.FlameFunnel: "Flame Funnel",
    SkillId.SandTwister: "Sand Twister",
    SkillId.AllRangeThunder: "All Range Thunder",
    SkillId.ThunderRail: "Thunder Rail",
    SkillId.LethalLaser: "Lethal Laser",
    SkillId.PoisonShower: "Poison Shower",
    SkillId.UnknownSkillWaterBalloon: "Unknown Skill (WaterBalloon)",
    SkillId.IcicleBullet: "Icicle Bullet",
    SkillId.DoubleBlizzardSpike: "Double Blizzard Spike",
    SkillId.AbsoluteFrost: "Absolute Frost",
    SkillId.RaidCutter: "Raid Cutter",
    SkillId.WindEdge: "Wind Edge",
    SkillId.FlareTwister: "Flare Twister",
    SkillId.RagingFlameWave: "Raging Flame Wave",
    SkillId.DivineDisasterII: "Divine Disaster II",
    SkillId.SeigetsuFlash: "Seigetsu Flash",
    SkillId.IcicleLine: "Icicle Line",
    SkillId.VolcanicFang: "Volcanic Fang",
    SkillId.LightningDive: "Lightning Dive",
    SkillId.WindBarrier: "Wind Barrier",
    SkillId.FirefistBreathstorm: "Firefist Breathstorm",
    SkillId.LeapingRoundhouse: "Leaping Roundhouse",
    SkillId.SnowBowling: "Snow Bowling",
    SkillId.SlitherSlam: "Slither Slam",
    SkillId.NeedleSpear: "Needle Spear",
    SkillId.RushBeak: "Rush Beak",
    SkillId.BeckonLightning: "Beckon Lightning",
    SkillId.SpiritDash: "Spirit Dash",
    SkillId.FlameBreath: "Flame Breath",
    SkillId.BlizzardClaw: "Blizzard Claw",
    SkillId.SatelliteBit: "Satellite Bit",
    SkillId.OmegaLaser: "Omega Laser",
    SkillId.AstralRay: "Astral Ray",
    SkillId.BeamSlash: "Beam Slash",
    SkillId.CosmicMeteor: "Cosmic Meteor",
    SkillId.TempestBlizzard: "Tempest Blizzard",
    SkillId.MagmaSerpent: "Magma Serpent",
    SkillId.PredatorSurge: "Predator Surge",
    SkillId.PredatorBlast: "Predator Blast",
    SkillId.PredatorMark: "Predator Mark",
    SkillId.StoneClaw: "Stone Claw",
    SkillId.ThunderTempest: "Thunder Tempest",
    SkillId.SnowClaw: "Snow Claw",
    SkillId.PhoenixTide: "Phoenix Tide",
    SkillId.DaringShadowstorm: "Daring Shadowstorm",
    SkillId.StoneBeat: "Stone Beat",
    SkillId.LawnBowling: "Lawn Bowling",
    SkillId.GlacialImpact: "Glacial Impact",
    SkillId.WebstrikeImpact: "Webstrike Impact",
    SkillId.FrostTalon: "Frost Talon",
    SkillId.SoulDrain: "Soul Drain",
    SkillId.GrudgeBarrage: "Grudge Barrage",
    SkillId.AegisCharge: "Aegis Charge",
    SkillId.BoltBlink: "Bolt Blink",
    SkillId.HolyNova: "Holy Nova",
    SkillId.LethalStep: "Lethal Step",
    SkillId.CrashDash: "Crash Dash",
    SkillId.UnknownSkillFunnelRaijinDaughterWater: "Unknown Skill (Funnel_RaijinDaughter_Water)",
    SkillId.PlasmaDash: "Plasma Dash",
    SkillId.GeyserGush: "Geyser Gush",
    SkillId.AquaSurge: "Aqua Surge",
    SkillId.HydroSlicer: "Hydro Slicer",
    SkillId.TorrentialBlast: "Torrential Blast",
    SkillId.Crosswind: "Crosswind",
    SkillId.FreezeWall: "Freeze Wall",
    SkillId.SmokeJet: "Smoke Jet",
    SkillId.HydroSpin: "Hydro Spin",
    SkillId.KonohaFlip: "Konoha Flip",
    SkillId.HighBreach: "High Breach",
    SkillId.LanternSweep: "Lantern Sweep",
    SkillId.TriggerHappy: "Trigger Happy",
    SkillId.DarkShot: "Dark Shot",
    SkillId.ThunderSpear: "Thunder Spear",
    SkillId.ReflectLeaf: "Reflect Leaf",
    SkillId.UnknownSkillHealingTree: "Unknown Skill (HealingTree)",
    SkillId.ChaoticSpray: "Chaotic Spray",
    SkillId.UnknownSkillUniqueYakushimaBoss002PhantasmalDeathray: "Unknown Skill (Unique_YakushimaBoss002_PhantasmalDeathray)",
    SkillId.UnknownSkillUniqueYakushimaBoss002PhantasmalEye: "Unknown Skill (Unique_YakushimaBoss002_PhantasmalEye)",
    SkillId.UnknownSkillUniqueYakushimaBoss002PhantasmalBolt: "Unknown Skill (Unique_YakushimaBoss002_PhantasmalBolt)",
    SkillId.UnknownSkillUniqueYakushimaBoss002PhantasmalSphere: "Unknown Skill (Unique_YakushimaBoss002_PhantasmalSphere)",
    SkillId.LockOnLunge: "Lock-On Lunge",
    SkillId.ServantCall: "Servant Call",
    SkillId.ScorchingLanternSweep: "Scorching Lantern Sweep",
    SkillId.Thunderslide: "Thunderslide",
    SkillId.DeepBreath: "Deep Breath",
    SkillId.DashKick: "Dash Kick",
    SkillId.FrenziedCharge: "Frenzied Charge",
    SkillId.UnknownSkillUniqueYakushimaBoss001GreenPhantasmalBolt: "Unknown Skill (Unique_YakushimaBoss001_Green_PhantasmalBolt)",
    SkillId.UnknownSkillUniqueYakushimaBoss001GreenPhantasmalEye: "Unknown Skill (Unique_YakushimaBoss001_Green_PhantasmalEye)",
    SkillId.UnknownSkillUniqueYakushimaBoss001GreenPhantasmalSphere: "Unknown Skill (Unique_YakushimaBoss001_Green_PhantasmalSphere)",
    SkillId.UnknownSkillUniqueYakushimaBoss001GreenPhantasmalDeathray: "Unknown Skill (Unique_YakushimaBoss001_Green_PhantasmalDeathray)",
    SkillId.ThalassonicLaser: "Thalassonic Laser",
    SkillId.SlimePressNeutral: "Slime Press (Neutral)",
    SkillId.SlimePressGrass: "Slime Press (Grass)",
    SkillId.SlimePressWater: "Slime Press (Water)",
    SkillId.SlimePressFire: "Slime Press (Fire)",
    SkillId.SlimePressDark: "Slime Press (Dark)",
    SkillId.SlimePressRainbow: "Slime Press (Rainbow)",
    SkillId.OcularRush: "Ocular Rush",
    SkillId.SwordCharge: "Sword Charge",
    SkillId.WingedAssault: "Winged Assault",
    SkillId.FireTackle: "Fire Tackle",
    SkillId.SentinelOfTheGreatSea: "Sentinel of the Great Sea",
    SkillId.UnknownSkillPoseidonOrcaPartnerSkillSpearBullet: "Unknown Skill (PoseidonOrca_PartnerSkill_SpearBullet)",
    SkillId.UnknownSkillHumanRolling: "Unknown Skill (Human_Rolling)",
    SkillId.UseWeapon: "Use Weapon",
    SkillId.UnknownSkillUniqueFlowerDinosaurElectricThunderWhip: "Unknown Skill (Unique_FlowerDinosaur_Electric_ThunderWhip)",
    SkillId.UnknownSkillUniqueKingAlpacaIceIcePress: "Unknown Skill (Unique_KingAlpaca_Ice_IcePress)",
    SkillId.UnknownSkillUniqueBaphometDarkDarkKite: "Unknown Skill (Unique_Baphomet_Dark_DarkKite)",
    SkillId.UnknownSkillUniqueSakuraSaurusWaterSplashTackle: "Unknown Skill (Unique_SakuraSaurus_Water_SplashTackle)",
    SkillId.UnknownSkillUniqueDeerGroundDirtyHorn: "Unknown Skill (Unique_Deer_Ground_DirtyHorn)",
    SkillId.UnknownSkillUniqueGorillaGroundEarthPunch: "Unknown Skill (Unique_Gorilla_Ground_EarthPunch)",
    SkillId.UnknownSkillUniqueIceHorseDarkDarkBladeAttack: "Unknown Skill (Unique_IceHorse_Dark_DarkBladeAttack)",
    SkillId.UnknownSkillUniqueYakushimaBoss0022PhantasmalDeathray: "Unknown Skill (Unique_YakushimaBoss002_2_PhantasmalDeathray)",
    SkillId.UnknownSkillUniqueYakushimaBoss0022PhantasmalEye: "Unknown Skill (Unique_YakushimaBoss002_2_PhantasmalEye)",
    SkillId.UnknownSkillUniqueYakushimaBoss0022PhantasmalBolt: "Unknown Skill (Unique_YakushimaBoss002_2_PhantasmalBolt)",
    SkillId.UnknownSkillUniqueYakushimaBoss0022PhantasmalSphere: "Unknown Skill (Unique_YakushimaBoss002_2_PhantasmalSphere)",
    SkillId.UnknownSkillUniqueYakushimaBoss001Green2PhantasmalBolt: "Unknown Skill (Unique_YakushimaBoss001_Green_2_PhantasmalBolt)",
    SkillId.UnknownSkillUniqueYakushimaBoss001Green2PhantasmalEye: "Unknown Skill (Unique_YakushimaBoss001_Green_2_PhantasmalEye)",
    SkillId.UnknownSkillUniqueYakushimaBoss001Green2PhantasmalSphere: "Unknown Skill (Unique_YakushimaBoss001_Green_2_PhantasmalSphere)",
    SkillId.UnknownSkillUniqueYakushimaBoss001Green2PhantasmalDeathray: "Unknown Skill (Unique_YakushimaBoss001_Green_2_PhantasmalDeathray)",
    SkillId.UnknownSkillUniqueGarmBiteV2: "Unknown Skill (Unique_Garm_BiteV2)",
    SkillId.UnknownSkillUniqueThunderDogBiteV2: "Unknown Skill (Unique_ThunderDog_BiteV2)",
    SkillId.UnknownSkillUniqueThunderDogBite: "Unknown Skill (Unique_ThunderDog_Bite)",
    SkillId.UnknownSkillUniqueGuardianDogBite: "Unknown Skill (Unique_GuardianDog_Bite)",
    SkillId.UnknownSkillUniqueGuardianDogBiteV2: "Unknown Skill (Unique_GuardianDog_BiteV2)",
    SkillId.UnknownSkillUniqueGoldenHorseBite: "Unknown Skill (Unique_GoldenHorse_Bite)",
    SkillId.UnknownSkillUniqueGoldenHorseBiteV2: "Unknown Skill (Unique_GoldenHorse_BiteV2)",
    SkillId.UnknownSkillUniqueAmaterasuWolfBite: "Unknown Skill (Unique_AmaterasuWolf_Bite)",
    SkillId.UnknownSkillUniqueAmaterasuWolfBiteV2: "Unknown Skill (Unique_AmaterasuWolf_BiteV2)",
    SkillId.UnknownSkillUniqueAmaterasuWolfDarkBite: "Unknown Skill (Unique_AmaterasuWolf_Dark_Bite)",
    SkillId.UnknownSkillUniqueAmaterasuWolfDarkBiteV2: "Unknown Skill (Unique_AmaterasuWolf_Dark_BiteV2)",
    SkillId.UnknownSkillUniqueBlackPuppyBite: "Unknown Skill (Unique_BlackPuppy_Bite)",
    SkillId.UnknownSkillUniqueBlackPuppyBiteV2: "Unknown Skill (Unique_BlackPuppy_BiteV2)",
    SkillId.UnknownSkillUniqueVolcanoDragonVolcanicLaser: "Unknown Skill (Unique_VolcanoDragon_VolcanicLaser)",
    SkillId.UnknownSkillUniqueVolcanoDragonMagmaSpit: "Unknown Skill (Unique_VolcanoDragon_MagmaSpit)",
    SkillId.UnknownSkillUniqueSekhmetSomersaultScratch: "Unknown Skill (Unique_Sekhmet_SomersaultScratch)",
    SkillId.UnknownSkillUniqueSekhmetRollingScratch: "Unknown Skill (Unique_Sekhmet_RollingScratch)",
    SkillId.UnknownSkillUniqueNightBlueHorseTossin: "Unknown Skill (Unique_NightBlueHorse_Tossin)",
    SkillId.UnknownSkillUniqueBlueThunderHorseTossin: "Unknown Skill (Unique_BlueThunderHorse_Tossin)",
    SkillId.SacredRain: "Sacred Rain",
    SkillId.DivineWing: "Divine Wing",
    SkillId.UnknownSkillUniqueLegendDeerBarrierReleaseNormal: "Unknown Skill (Unique_LegendDeer_BarrierRelease_Normal)",
    SkillId.UnknownSkillUniqueLegendDeerBarrierReleaseGrass: "Unknown Skill (Unique_LegendDeer_BarrierRelease_Grass)",
    SkillId.UnknownSkillUniqueLegendDeerBarrierReleaseWater: "Unknown Skill (Unique_LegendDeer_BarrierRelease_Water)",
    SkillId.PurifyingLight: "Purifying Light",
    SkillId.RadiantBarrage: "Radiant Barrage",
}
