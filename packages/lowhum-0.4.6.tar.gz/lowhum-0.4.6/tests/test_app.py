"""App module: config persistence, version helpers, notification safety."""

from unittest.mock import patch


from lowhum.app import (
    _load_config,
    _notify,
    _save_config,
    _version_tuple,
)
from lowhum.noise_colors import NoiseColor


class TestVersionTuple:
    """Version string parsing for update comparison."""

    def test_simple_version(self):
        assert _version_tuple("1.2.3") == (1, 2, 3)

    def test_pre_release(self):
        assert _version_tuple("0.4.0a1") == (0, 4, 0)

    def test_comparison(self):
        assert _version_tuple("1.3.0") > _version_tuple("1.2.9")
        assert _version_tuple("0.4.0") < _version_tuple("1.0.0")


class TestConfig:
    """Config save/load round-trips correctly."""

    def test_roundtrip(self, tmp_path):
        cfg_file = tmp_path / "config.toml"
        with patch("lowhum.app._CONFIG_FILE", cfg_file):
            _save_config(
                device=3,
                color=NoiseColor.PINK,
                block_speakers=True,
            )
            cfg = _load_config()

        audio = cfg["audio"]
        assert audio["device"] == 3
        assert audio["noise_color"] == "pink"
        assert "volume" not in audio
        assert "sound_mode" not in audio
        assert audio["block_speakers"] is True

    def test_default_device_none(self, tmp_path):
        cfg_file = tmp_path / "config.toml"
        with patch("lowhum.app._CONFIG_FILE", cfg_file):
            _save_config(device=None, color=NoiseColor.BROWN)
            cfg = _load_config()
        assert "device" not in cfg.get("audio", {})

    def test_missing_file_returns_empty(self, tmp_path):
        with patch("lowhum.app._CONFIG_FILE", tmp_path / "nope.toml"):
            assert _load_config() == {}


class TestNotify:
    """_notify wrapper catches RuntimeError from missing Info.plist."""

    def test_notify_suppresses_runtime_error(self):
        with patch("lowhum.app.rumps") as mock_rumps:
            mock_rumps.notification.side_effect = RuntimeError("no plist")
            _notify("LowHum", "", "test")  # should not raise

    def test_notify_passes_through_on_success(self):
        with patch("lowhum.app.rumps") as mock_rumps:
            _notify("LowHum", "sub", "msg")
            mock_rumps.notification.assert_called_once_with(
                "LowHum", "sub", "msg"
            )
