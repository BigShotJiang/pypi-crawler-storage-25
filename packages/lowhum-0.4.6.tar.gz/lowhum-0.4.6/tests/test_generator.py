"""Noise generation: spectral shape, normalization, and file integrity."""

import numpy as np
import pytest

from lowhum.noise_colors import (
    SAMPLE_RATE,
    NoiseColor,
    audio_file,
    generate_noise,
)


@pytest.fixture
def tmp_wav(tmp_path):
    return tmp_path / "test.wav"


class TestNoiseGeneration:
    """Core noise generation produces valid, correctly shaped audio."""

    @pytest.mark.parametrize("color", list(NoiseColor))
    def test_generates_valid_wav(self, color, tmp_wav):
        """Each color produces a RIFF/WAV with a non-empty data chunk."""
        generate_noise(color, output_path=tmp_wav, duration=5)
        assert tmp_wav.exists()
        with open(tmp_wav, "rb") as f:
            assert f.read(4) == b"RIFF"
            f.read(4)
            assert f.read(4) == b"WAVE"

    @pytest.mark.parametrize("color", list(NoiseColor))
    def test_output_not_silent(self, color, tmp_wav):
        """Generated audio has non-trivial energy (not all zeros)."""
        generate_noise(color, output_path=tmp_wav, duration=3)
        from lowhum.audio import parse_wav_header

        info = parse_wav_header(tmp_wav)
        data = np.memmap(
            tmp_wav,
            dtype=np.int16,
            mode="r",
            offset=info.data_offset,
            shape=(info.data_size // 2,),
        )
        rms = np.sqrt(np.mean(data.astype(np.float64) ** 2))
        assert rms > 100, f"RMS too low ({rms:.1f}), audio may be silent"

    def test_brown_has_low_frequency_bias(self, tmp_wav):
        """Brown noise should have more energy below 200 Hz than above 1 kHz."""
        generate_noise(NoiseColor.BROWN, output_path=tmp_wav, duration=5)
        from lowhum.audio import parse_wav_header

        info = parse_wav_header(tmp_wav)
        data = np.memmap(
            tmp_wav,
            dtype=np.int16,
            mode="r",
            offset=info.data_offset,
            shape=(info.data_size // 2,),
        )
        spectrum = np.abs(np.fft.rfft(data.astype(np.float64)))
        freqs = np.fft.rfftfreq(len(data), 1 / SAMPLE_RATE)
        low = spectrum[freqs < 200].sum()
        high = spectrum[freqs > 1000].sum()
        assert low > high, "Brown noise should be bass-heavy"

    def test_duration_matches_request(self, tmp_wav):
        """Output length matches the requested duration within 1 second."""
        dur = 7
        generate_noise(NoiseColor.WHITE, output_path=tmp_wav, duration=dur)
        from lowhum.audio import parse_wav_header

        info = parse_wav_header(tmp_wav)
        n_frames = info.data_size // (info.channels * info.bits_per_sample // 8)
        actual_secs = n_frames / info.sample_rate
        assert abs(actual_secs - dur) < 1.0

    def test_output_clipped_to_int16_range(self, tmp_wav):
        """All samples fit within int16 bounds (no wrap-around clipping)."""
        generate_noise(NoiseColor.BROWN, output_path=tmp_wav, duration=3)
        from lowhum.audio import parse_wav_header

        info = parse_wav_header(tmp_wav)
        data = np.memmap(
            tmp_wav,
            dtype=np.int16,
            mode="r",
            offset=info.data_offset,
            shape=(info.data_size // 2,),
        )
        # hard clipping = long consecutive runs pinned at the rail
        at_rail = np.abs(data) == 32_767
        longest_run = 0
        run = 0
        for v in at_rail:
            run = run + 1 if v else 0
            longest_run = max(longest_run, run)
        assert longest_run < 500, f"Sustained clipping detected ({longest_run} samples)"


class TestFilePaths:
    """Audio file path helpers return consistent locations."""

    def test_audio_file_in_data_dir(self):
        path = audio_file(NoiseColor.BROWN)
        assert path.parent.name == ".lowhum"
        assert "brown" in path.name
