"""WAV parser and device enumeration tests."""

import struct

import numpy as np
import pytest
from scipy.io.wavfile import write as wav_write

from lowhum.audio import (
    AudioPlayer,
    get_default_output_device,
    is_builtin_speaker,
    list_output_devices,
    parse_wav_header,
)


@pytest.fixture
def sine_wav(tmp_path):
    """Generate a short mono 44100 Hz sine wave WAV for testing."""
    path = tmp_path / "sine.wav"
    sr = 44_100
    t = np.linspace(0, 1, sr, endpoint=False)
    tone = (np.sin(2 * np.pi * 440 * t) * 16_000).astype(np.int16)
    wav_write(str(path), sr, tone)
    return path


@pytest.fixture
def stereo_wav(tmp_path):
    """Generate a short stereo WAV."""
    path = tmp_path / "stereo.wav"
    sr = 44_100
    t = np.linspace(0, 0.5, sr // 2, endpoint=False)
    left = (np.sin(2 * np.pi * 440 * t) * 16_000).astype(np.int16)
    right = (np.sin(2 * np.pi * 880 * t) * 16_000).astype(np.int16)
    wav_write(str(path), sr, np.column_stack([left, right]))
    return path


class TestParseWavHeader:
    """Custom RIFF parser returns correct metadata."""

    def test_mono_header(self, sine_wav):
        info = parse_wav_header(sine_wav)
        assert info.sample_rate == 44_100
        assert info.channels == 1
        assert info.bits_per_sample == 16
        assert info.data_offset > 0
        assert info.data_size == 44_100 * 2  # 1s mono int16

    def test_stereo_header(self, stereo_wav):
        info = parse_wav_header(stereo_wav)
        assert info.channels == 2
        assert info.data_size == (44_100 // 2) * 2 * 2  # 0.5s stereo int16

    def test_rejects_non_riff(self, tmp_path):
        bad = tmp_path / "bad.wav"
        bad.write_bytes(b"NOT_RIFF" + b"\x00" * 100)
        with pytest.raises(ValueError, match="Not a RIFF"):
            parse_wav_header(bad)

    def test_data_offset_points_to_samples(self, sine_wav):
        """The data_offset should point directly at PCM sample bytes."""
        info = parse_wav_header(sine_wav)
        with open(sine_wav, "rb") as f:
            f.seek(info.data_offset)
            raw = f.read(4)
        # first two bytes should decode as a valid int16 sample
        sample = struct.unpack("<h", raw[:2])[0]
        assert -32_768 <= sample <= 32_767


class TestDeviceEnumeration:
    """Device listing and default detection (requires PortAudio)."""

    def test_list_returns_tuples(self):
        devices = list_output_devices()
        assert isinstance(devices, list)
        if devices:
            idx, name = devices[0]
            assert isinstance(idx, int)
            assert isinstance(name, str)

    def test_default_device_is_int(self):
        idx = get_default_output_device()
        assert isinstance(idx, (int, np.integer))

    def test_builtin_speaker_none_uses_default(self):
        """Passing None should check the default device without crashing."""
        result = is_builtin_speaker(None)
        assert isinstance(result, bool)


class TestAudioPlayer:
    """AudioPlayer lifecycle without actually playing audio."""

    def test_initial_state(self):
        player = AudioPlayer()
        assert not player.playing
        assert not player.paused
        assert player.volume == 1.0

    def test_volume_clamping(self):
        player = AudioPlayer()
        player.volume = 1.5
        assert player.volume == 1.0
        player.volume = -0.3
        assert player.volume == 0.0

    def test_stop_when_idle_is_noop(self):
        """Stopping without ever playing should not raise."""
        player = AudioPlayer()
        player.stop()
        assert not player.playing

    def test_pause_when_idle_is_noop(self):
        player = AudioPlayer()
        player.pause()
        assert not player.paused

    def test_resume_when_idle_is_noop(self):
        player = AudioPlayer()
        player.resume()
        assert not player.playing
