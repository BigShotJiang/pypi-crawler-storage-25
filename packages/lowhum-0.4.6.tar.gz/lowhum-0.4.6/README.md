# LowHum

[![PyPI](https://img.shields.io/pypi/v/lowhum)](https://pypi.org/project/lowhum/)
[![Python](https://img.shields.io/pypi/pyversions/lowhum)](https://pypi.org/project/lowhum/)
[![License: MIT](https://img.shields.io/badge/license-MIT-blue)](LICENSE)
[![Downloads](https://img.shields.io/pypi/dm/lowhum)](https://pypi.org/project/lowhum/)

Deep brown noise for focus, as a macOS menu bar app. Requires macOS and Python 3.12+. [Website](https://lmarkmann.github.io/lowhum/)

Brown noise is the default: cumulative-sum white noise through a 1 to 500 Hz Butterworth bandpass with a 20 Hz sub-bass highpass. Pink and white are low-passed at 8 kHz and 4 kHz so they don't hurt your ears. Files live in `~/.lowhum/` and stream through PortAudio via memory-mapped files. They're generated on first play, not at startup.

## Install

```bash
uv tool install lowhum
```

## Usage

```bash
lhm                  # launch the menu-bar app
lhm devices          # list output devices
lhm generate         # pre-generate the audio files
```

### Menu bar

- Play / Stop
- Noise Color (brown, pink, white)
- Output Device
- Block Built-in Speakers
- Launch at Login

Playback stops when headphones disconnect and resumes when they come back. If a newer version is on PyPI, you get a notification at startup.

## Development

```bash
just run       # run the app locally
just fmt       # format and lint
just check     # pyright + pytest
just build     # build wheel
just clean     # remove caches and build artifacts
```
