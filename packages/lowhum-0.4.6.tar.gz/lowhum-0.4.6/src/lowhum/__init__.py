"""LowHum: deep brown noise for focus."""

__version__ = "0.4.6"
