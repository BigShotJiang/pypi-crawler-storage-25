"""Shared DSP primitives for noise generation."""

import math
from enum import Enum
from pathlib import Path
from typing import Any

import numpy as np

SAMPLE_RATE = 44_100
DURATION = 600  # 10 minutes
DATA_DIR = Path.home() / ".lowhum"

_AUDIO_VERSION = 2  # bump when DSP changes to invalidate cached WAVs
_MANIFEST = DATA_DIR / ".audio_version"


class NoiseColor(str, Enum):
    BROWN = "brown"
    PINK = "pink"
    WHITE = "white"


def audio_file(color: NoiseColor) -> Path:
    return DATA_DIR / f"{color.value}_noise.wav"


# Cache management


def _cache_is_current() -> bool:
    try:
        return _MANIFEST.read_text().strip() == str(_AUDIO_VERSION)
    except Exception:
        return False


def _stamp_cache():
    _MANIFEST.parent.mkdir(parents=True, exist_ok=True)
    _MANIFEST.write_text(str(_AUDIO_VERSION))


def _invalidate_cache():
    """Remove all generated WAVs so they get rebuilt."""
    if not DATA_DIR.exists():
        return
    for wav in DATA_DIR.glob("*.wav"):
        wav.unlink(missing_ok=True)
    _MANIFEST.unlink(missing_ok=True)


# WAV validation


def _wav_looks_valid(path: Path) -> bool:
    """Cheap integrity check for cached WAVs (guards against partial/corrupt files)."""
    try:
        with open(path, "rb") as f:
            if f.read(4) != b"RIFF":
                return False
            f.read(4)  # size
            if f.read(4) != b"WAVE":
                return False
            max_header = 64 * 1024
            read = 0
            while read < max_header:
                chunk_id = f.read(4)
                if len(chunk_id) < 4:
                    return False
                size_bytes = f.read(4)
                if len(size_bytes) < 4:
                    return False
                size = int.from_bytes(size_bytes, "little", signed=False)
                if chunk_id == b"data":
                    return size > 0
                skip = size + (size & 1)
                read += 8 + skip
                f.seek(skip, 1)
            return False
    except Exception:
        return False


# Shared DSP building blocks


def _raw_noise(color: NoiseColor, n: int) -> np.ndarray:
    white = np.random.randn(n)
    if color == NoiseColor.WHITE:
        return white
    elif color == NoiseColor.PINK:
        f = np.fft.rfftfreq(n)
        f[0] = 1.0  # avoid divide-by-zero at DC
        return np.fft.irfft(np.fft.rfft(white) / np.sqrt(f), n=n)
    else:  # BROWN
        return np.cumsum(white)


def noise_filters(color: NoiseColor) -> dict[str, Any]:
    from scipy.signal import butter

    filters = {
        "sub_sos": butter(1, 20, btype="high", fs=SAMPLE_RATE, output="sos"),
    }
    if color == NoiseColor.BROWN:
        filters["hp_sos"] = butter(
            2, 1.0, btype="high", fs=SAMPLE_RATE, output="sos"
        )
        filters["lp_sos"] = butter(
            2, 500, btype="low", fs=SAMPLE_RATE, output="sos"
        )
    elif color == NoiseColor.WHITE:
        # Tame painful highs; raw white is ear-piercing above ~4 kHz.
        filters["lp_sos"] = butter(
            2, 4000, btype="low", fs=SAMPLE_RATE, output="sos"
        )
    elif color == NoiseColor.PINK:
        filters["lp_sos"] = butter(
            2, 8000, btype="low", fs=SAMPLE_RATE, output="sos"
        )
    return filters


def noise_bed(
    color: NoiseColor, n: int, filters: dict[str, Any]
) -> np.ndarray:
    """Generate a filtered noise bed, RMS-normalized to 0.3."""
    from scipy.signal import sosfilt

    bed = _raw_noise(color, n)
    if color == NoiseColor.BROWN:
        bed = sosfilt(filters["hp_sos"], bed)
    if "lp_sos" in filters:
        bed = sosfilt(filters["lp_sos"], bed)
    bed = sosfilt(filters["sub_sos"], bed)
    rms = np.sqrt(np.mean(bed**2))  # pyright: ignore[reportOperatorIssue]
    if rms > 0:
        bed *= 0.3 / rms
    return bed  # pyright: ignore[reportReturnType]


def crossfade(chunks: list[np.ndarray]) -> np.ndarray:
    """Overlap-add crossfade across chunk boundaries (1 s)."""
    if len(chunks) == 1:
        return chunks[0]
    xfade = SAMPLE_RATE
    fade_out = np.linspace(1, 0, xfade)
    fade_in = np.linspace(0, 1, xfade)
    if chunks[0].ndim == 2:
        fade_out = fade_out[:, np.newaxis]
        fade_in = fade_in[:, np.newaxis]
    parts: list[np.ndarray] = [chunks[0][:-xfade]]
    for i in range(1, len(chunks)):
        blend = chunks[i - 1][-xfade:] * fade_out + chunks[i][:xfade] * fade_in
        parts.append(blend)
        last = i == len(chunks) - 1
        tail = chunks[i][xfade:] if last else chunks[i][xfade:-xfade]
        parts.append(tail)
    return np.concatenate(parts)


def chunk_count(duration: int, chunk_seconds: int = 300) -> int:
    chunk_samples = SAMPLE_RATE * chunk_seconds
    total_needed = duration * SAMPLE_RATE
    xfade = SAMPLE_RATE
    return max(1, math.ceil((total_needed - xfade) / (chunk_samples - xfade)))


def ensure_parent(path: Path):
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
    except OSError as e:
        raise OSError(
            f"Failed to create directory for {path}: {e}. "
            "Check disk space and permissions."
        ) from e


def finalize(
    chunks: list[np.ndarray], duration: int, output_path: Path
) -> Path:
    """Crossfade chunks, normalize to int16, write WAV."""
    from scipy.io.wavfile import write as wav_write

    final = crossfade(chunks)[: duration * SAMPLE_RATE]
    audio_data = (final * 32_767).astype(np.int16)
    try:
        wav_write(str(output_path), SAMPLE_RATE, audio_data)
    except OSError as e:
        raise OSError(
            f"Failed to write audio to {output_path}: {e}. "
            "Check disk space and permissions."
        ) from e
    return output_path
