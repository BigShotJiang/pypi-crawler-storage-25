"""Noise generators with WAV caching."""

from lowhum.noise_colors._core import (
    DATA_DIR,
    DURATION,
    SAMPLE_RATE,
    NoiseColor,
    audio_file,
)
from lowhum.noise_colors.noise import generate_noise

__all__ = [
    "DATA_DIR",
    "DURATION",
    "SAMPLE_RATE",
    "NoiseColor",
    "audio_file",
    "ensure_all_audio",
    "ensure_audio",
    "generate_noise",
]


def ensure_audio(color: NoiseColor = NoiseColor.BROWN):
    """Return the path to the audio file for *color*, generating if needed."""
    from lowhum.noise_colors._core import _cache_is_current, _wav_looks_valid

    path = audio_file(color)
    if path.exists() and _wav_looks_valid(path) and _cache_is_current():
        return path
    print(f"Generating {color.value} noise audio (first run, takes ~5 s)...")
    return generate_noise(color)


def ensure_all_audio():
    """Pre-generate every noise variant."""
    from lowhum.noise_colors._core import (
        _cache_is_current,
        _invalidate_cache,
        _stamp_cache,
        _wav_looks_valid,
    )

    if not _cache_is_current():
        print("Audio generation changed; rebuilding cache...")
        _invalidate_cache()

    for color in NoiseColor:
        path = audio_file(color)
        if not path.exists() or not _wav_looks_valid(path):
            print(f"Generating {color.value} noise...")
            generate_noise(color)

    _stamp_cache()
