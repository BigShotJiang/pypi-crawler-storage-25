"""Pure noise generation: brown, pink, white."""

from pathlib import Path

import numpy as np

from lowhum.noise_colors._core import (
    DURATION,
    SAMPLE_RATE,
    NoiseColor,
    audio_file,
    chunk_count,
    ensure_parent,
    finalize,
    noise_bed,
    noise_filters,
)


def generate_noise(
    color: NoiseColor = NoiseColor.BROWN,
    output_path: Path | None = None,
    duration: int = DURATION,
) -> Path:
    """Generate noise of the requested color and write as WAV.

    Brown: cumsum white noise, Butterworth bandpass (1-500 Hz) + HP 20 Hz.
    Pink: 1/f spectral shaping via FFT, HP 20 Hz.
    White: gaussian noise, HP 20 Hz.
    """
    if output_path is None:
        output_path = audio_file(color)
    ensure_parent(output_path)

    chunk_samples = SAMPLE_RATE * 300
    n_chunks = chunk_count(duration)
    filters = noise_filters(color)

    chunks: list[np.ndarray] = []
    for _ in range(n_chunks):
        chunk = noise_bed(color, chunk_samples, filters)
        chunk = np.clip(chunk, -1.0, 1.0)
        chunks.append(chunk)

    return finalize(chunks, duration, output_path)
