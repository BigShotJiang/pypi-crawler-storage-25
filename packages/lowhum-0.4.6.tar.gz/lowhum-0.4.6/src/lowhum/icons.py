import shutil
from pathlib import Path

from .noise_colors import DATA_DIR
from .resources import menubar_icon_path

_TEMPLATE_ICON = DATA_DIR / "icon_template.png"


def ensure_template_icon() -> Path:
    """Return path to the cached template icon, copying from resources if needed."""
    if _TEMPLATE_ICON.exists():
        return _TEMPLATE_ICON

    DATA_DIR.mkdir(parents=True, exist_ok=True)

    icon_path = menubar_icon_path(dark_mode=True)
    if not icon_path.exists():
        icon_path = menubar_icon_path(dark_mode=False)

    if icon_path.exists():
        shutil.copy2(icon_path, _TEMPLATE_ICON)

    return _TEMPLATE_ICON
