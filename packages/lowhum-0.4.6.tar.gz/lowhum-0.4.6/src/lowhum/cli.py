"""CLI entry point for LowHum; ``lhm`` and ``lowhum`` resolve here."""

import os
import subprocess
import sys

import typer

from lowhum import __version__

_DETACHED_ENV = "_LHM_DETACHED"
_AUTOPLAY_ENV = "_LHM_AUTOPLAY"
_LOG_PATH = os.path.expanduser("~/.lowhum/lowhum.log")


def _ensure_log_dir() -> None:
    os.makedirs(os.path.dirname(_LOG_PATH), exist_ok=True)


def _open_detached_log():
    """
    Open the log file for the detached app.

    Returns a file object or None if logging can't be set up.
    """
    try:
        _ensure_log_dir()
        return open(_LOG_PATH, "a", encoding="utf-8", errors="replace")
    except OSError:
        return None


app = typer.Typer(
    name="lowhum",
    help="LowHum: deep brown noise for focus.",
    invoke_without_command=True,
    no_args_is_help=False,
)


def _load_bison() -> str:
    from importlib import resources

    return resources.files("lowhum.resources").joinpath("bison.txt").read_text()


_BISON: str | None = None


def _banner() -> None:
    global _BISON
    if _BISON is None:
        _BISON = _load_bison()
    typer.echo(f"\n{_BISON}")
    typer.echo(f"  ~  LowHum  {__version__}  |  deep brown noise for focus\n")


@app.callback(invoke_without_command=True)
def _default(
    ctx: typer.Context,
    quiet: bool = typer.Option(
        False, "--quiet", "-q", help="Suppress the banner"
    ),
    start: bool = typer.Option(
        False, "--start", "-s", help="Start playback immediately"
    ),
) -> None:
    """Launch the menu-bar app (default when no subcommand given)."""
    if ctx.invoked_subcommand is not None:
        return

    if os.environ.get("_LHM_COMPLETE"):
        return

    if os.environ.get(_DETACHED_ENV):
        from lowhum.app import LowHumApp

        autoplay = bool(os.environ.get(_AUTOPLAY_ENV))
        LowHumApp(autoplay=autoplay).run()
        return

    if not quiet:
        _banner()
    typer.echo("  Starting in background...\n")

    env = {**os.environ, _DETACHED_ENV: "1"}
    if start:
        env[_AUTOPLAY_ENV] = "1"

    # Resolve to absolute path so the detached process works even when
    # launched from Spotlight or contexts with a minimal PATH.
    binary = os.path.abspath(sys.argv[0])

    log_fh = _open_detached_log()
    try:
        subprocess.Popen(
            [binary],
            start_new_session=True,
            stdout=log_fh or subprocess.DEVNULL,
            stderr=log_fh or subprocess.DEVNULL,
            env=env,
        )
    except OSError as e:
        typer.echo(
            f"  Failed to launch background app: {e}\n  Log file: {_LOG_PATH}\n"
        )
        raise typer.Exit(1) from None
    finally:
        # Child inherits the file descriptor; parent can close its handle.
        if log_fh is not None:
            try:
                log_fh.close()
            except OSError:
                pass
    raise SystemExit(0)


@app.command()
def devices() -> None:
    """List available audio output devices."""
    from lowhum.audio import get_default_output_device, list_output_devices

    _banner()
    default_idx = get_default_output_device()
    for idx, name in list_output_devices():
        marker = "  <- default" if idx == default_idx else ""
        typer.echo(f"  [{idx}]  {name}{marker}")


@app.command()
def generate(
    color: str = typer.Option(
        "brown", "--color", "-c", help="brown, pink, or white"
    ),
    duration: int = typer.Option(
        600, "--duration", "-d", help="Duration in seconds"
    ),
    all_: bool = typer.Option(
        False,
        "--all",
        "-a",
        help="Regenerate all audio (noise + soundscapes)",
    ),
) -> None:
    """Pre-generate audio files (noise + soundscapes)."""
    from lowhum.noise_colors import (
        NoiseColor,
        audio_file,
        generate_noise,
    )

    try:
        noise_color = NoiseColor(color)
    except ValueError:
        typer.echo(f"  Unknown color '{color}'. Choose: brown, pink, white.")
        raise typer.Exit(1) from None

    _banner()

    if all_:
        for c in NoiseColor:
            typer.echo(f"  Generating {c.value} noise...")
            generate_noise(c, duration=duration)
        typer.echo("  All noise files regenerated.")
        return

    path = audio_file(noise_color)
    if path.exists():
        typer.echo(f"  Audio file already exists at {path}")
        if not typer.confirm("  Regenerate?"):
            raise typer.Abort()

    generate_noise(noise_color, duration=duration)
    typer.echo(f"  Saved to {path}")


if __name__ == "__main__":
    app()
