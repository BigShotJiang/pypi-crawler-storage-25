"""LowHum macOS menu-bar application for brown noise playback."""

import atexit
import contextlib
import fcntl
import json
import os
import shutil
import subprocess
import sys
import tempfile
import threading
import tomllib
import urllib.request
from collections.abc import Callable
from pathlib import Path

import rumps
import rumps.events
import sounddevice as sd

from lowhum import __version__

from .audio import AudioPlayer, is_builtin_speaker, list_output_devices
from .icons import ensure_template_icon
from .noise_colors import (
    DATA_DIR,
    NoiseColor,
    ensure_audio,
)

_CONFIG_FILE = DATA_DIR / "config.toml"
_LOCK_FILE = DATA_DIR / "lowhum.lock"
_LAUNCH_AGENTS = Path.home() / "Library" / "LaunchAgents"
_PLIST = _LAUNCH_AGENTS / "com.lowhum.app.plist"

_PLIST_TEMPLATE = """\
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
  "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key>
  <string>com.lowhum.app</string>
  <key>ProgramArguments</key>
  <array>
    <string>{binary}</string>
  </array>
  <key>RunAtLoad</key>
  <true/>
  <key>StandardErrorPath</key>
  <string>{log}</string>
  <key>StandardOutPath</key>
  <string>{log}</string>
</dict>
</plist>
"""


def _notify(title: str, subtitle: str, message: str) -> None:
    """Best-effort macOS notification; silently fails outside .app bundles."""
    try:
        rumps.notification(title, subtitle, message)
    except RuntimeError:
        pass


def _find_binary() -> str:
    """Resolve the executable path for LaunchAgent plist.

    Prefer the path we were invoked with (reliable at login when PATH is minimal).
    Fall back to which() when argv[0] is a bare command name.
    """
    argv0 = sys.argv[0]
    if os.path.sep in argv0 or (os.path.isabs(argv0) if argv0 else False):
        return os.path.abspath(argv0)
    for name in ("lhm", "lowhum"):
        found = shutil.which(name)
        if found:
            return found
    return os.path.abspath(argv0) if argv0 else shutil.which("lhm") or "lhm"


def _load_config() -> dict:
    if not _CONFIG_FILE.exists():
        return {}
    try:
        with open(_CONFIG_FILE, "rb") as f:
            return tomllib.load(f)
    except Exception:
        return {}


def _save_config(
    device: int | None,
    color: NoiseColor,
    block_speakers: bool = False,
) -> None:
    _CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
    lines = ["[audio]\n"]
    if device is not None:
        lines.append(f"device = {device}\n")
    lines.append(f'noise_color = "{color.value}"\n')
    lines.append(f"block_speakers = {'true' if block_speakers else 'false'}\n")
    fd, tmp = tempfile.mkstemp(dir=_CONFIG_FILE.parent, suffix=".tmp")
    closed = False
    try:
        os.write(fd, "".join(lines).encode())
        os.close(fd)
        closed = True
        os.replace(tmp, _CONFIG_FILE)
    except BaseException:
        if not closed:
            with contextlib.suppress(OSError):
                os.close(fd)
        with contextlib.suppress(OSError):
            os.unlink(tmp)
        raise


def _login_item_active() -> bool:
    return _PLIST.exists()


_LAUNCH_LOG = Path.home() / "Library" / "Logs" / "lowhum.log"


def _set_login_item(enabled: bool) -> None:
    uid = f"gui/{os.getuid()}"
    if enabled:
        _LAUNCH_AGENTS.mkdir(parents=True, exist_ok=True)
        _LAUNCH_LOG.parent.mkdir(parents=True, exist_ok=True)
        log = str(_LAUNCH_LOG)
        _PLIST.write_text(
            _PLIST_TEMPLATE.format(binary=_find_binary(), log=log)
        )
        subprocess.run(
            ["launchctl", "bootout", uid, str(_PLIST)],
            capture_output=True,
        )
        subprocess.run(
            ["launchctl", "bootstrap", uid, str(_PLIST)],
            capture_output=True,
        )
    else:
        subprocess.run(
            ["launchctl", "bootout", uid, str(_PLIST)],
            capture_output=True,
        )
        _PLIST.unlink(missing_ok=True)


def _check_pypi_version() -> tuple[str | None, str]:
    """Query PyPI for the latest non-yanked version. Returns (new_ver, msg)."""
    try:
        installed = __version__
        req = urllib.request.Request(
            "https://pypi.org/pypi/lowhum/json",
            headers={"Accept": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=5) as resp:
            data = json.loads(resp.read())
        # filter out yanked releases; each value is a list of file dicts
        versions = [
            v
            for v, files in data.get("releases", {}).items()
            if files and not all(f.get("yanked", False) for f in files)
        ]
        if not versions:
            return None, f"Up to date ({installed})"
        latest = max(versions, key=_version_tuple)
        if _version_tuple(latest) > _version_tuple(installed):
            return latest, f"Update: {latest} (you have {installed})"
        return None, f"Up to date ({installed})"
    except Exception as exc:
        return None, f"Check failed: {exc}"


def _version_tuple(v: str) -> tuple[int, ...]:
    import re

    return tuple(
        int(m.group()) for x in v.split(".") if (m := re.match(r"\d+", x))
    )


_lock_fd = None


def _pid_is_running(pid: int) -> bool:
    """Best-effort check whether *pid* exists (macOS/Linux)."""
    if pid <= 0:
        return False
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        # Exists but we can't signal it.
        return True


def _acquire_lock(_retried: bool = False) -> bool:
    """Try to grab an exclusive lock. Returns False if already running."""
    global _lock_fd
    _LOCK_FILE.parent.mkdir(parents=True, exist_ok=True)
    # Use a+ so we can read an existing PID without truncating first.
    _lock_fd = open(_LOCK_FILE, "a+")  # noqa: SIM115 - must stay open
    try:
        fcntl.flock(_lock_fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        _lock_fd.seek(0)
        _lock_fd.truncate()
        _lock_fd.write(str(os.getpid()))
        _lock_fd.flush()
        atexit.register(_release_lock)
        return True
    except OSError:
        # If we couldn't lock, try to detect a stale PID and recover once.
        try:
            _lock_fd.seek(0)
            raw = _lock_fd.read().strip()
            pid = int(raw) if raw else 0
        except (ValueError, OSError):
            pid = 0

        if not _retried and pid and not _pid_is_running(pid):
            _lock_fd.close()
            _lock_fd = None
            with contextlib.suppress(Exception):
                _LOCK_FILE.unlink(missing_ok=True)
            return _acquire_lock(_retried=True)

        # Lock held by live process or retry already failed.
        _lock_fd.close()
        _lock_fd = None
        return False


def _release_lock() -> None:
    global _lock_fd
    if _lock_fd is not None:
        fcntl.flock(_lock_fd, fcntl.LOCK_UN)
        _lock_fd.close()
        _lock_fd = None
        _LOCK_FILE.unlink(missing_ok=True)


_current_app_ref: "LowHumApp | None" = None
_before_quit_registered = False


def _dispatch_before_quit(sender: object = None) -> None:
    """Single before_quit handler; avoids duplicate registration in tests."""
    if _current_app_ref is not None:
        _current_app_ref._on_before_quit(sender)


class LowHumApp(rumps.App):
    def __init__(
        self,
        autoplay: bool = False,
    ) -> None:
        if not _acquire_lock():
            print("LowHum is already running.")
            raise SystemExit(0)

        self._autoplay = autoplay

        icon_path = str(ensure_template_icon())
        super().__init__(
            "LowHum", icon=icon_path, template=True, quit_button=None  # pyright: ignore[reportArgumentType]
        )
        self._player = AudioPlayer()
        self._known_device_names: set[str] = set()

        cfg = _load_config()
        audio_cfg = cfg.get("audio", {})

        raw_device = audio_cfg.get("device")
        selected_device: int | None = (
            int(raw_device) if raw_device is not None else None
        )
        try:
            valid_ids = {idx for idx, _ in list_output_devices()}
            if selected_device is not None and selected_device not in valid_ids:
                selected_device = None
        except Exception:
            # If PortAudio is temporarily unavailable, don't crash on startup.
            selected_device = None
        self._selected_device = selected_device
        try:
            self._noise_color = NoiseColor(
                audio_cfg.get("noise_color", "brown")
            )
        except ValueError:
            self._noise_color = NoiseColor.BROWN

        self._volume = 1.0
        self._player.volume = self._volume
        self._block_speakers: bool = bool(
            audio_cfg.get("block_speakers", False)
        )

        self._play_pause_item = rumps.MenuItem(
            "Play", callback=self._on_play_pause
        )
        self._stop_item = rumps.MenuItem("Stop", callback=self._on_stop)
        self._color_menu = rumps.MenuItem("Noise Color")
        self._device_menu = rumps.MenuItem("Output Device")
        self._block_speakers_item = rumps.MenuItem(
            "Block Built-in Speakers", callback=self._on_toggle_block_speakers
        )
        self._login_item = rumps.MenuItem(
            "Launch at Login", callback=self._on_toggle_login
        )

        self.menu = [
            self._play_pause_item,
            self._stop_item,
            None,
            self._color_menu,
            None,
            self._device_menu,
            self._block_speakers_item,
            None,
            self._login_item,
            None,
            rumps.MenuItem("Quit", callback=self._on_quit),
        ]

        self._refresh_color_menu()
        self._refresh_devices()
        self._login_item.state = _login_item_active()
        self._block_speakers_item.state = self._block_speakers

        # CoreAudio push listener for device connect/disconnect.
        # The callback fires on an arbitrary thread, so it just sets a flag
        # that a slow fallback timer picks up on the main thread.
        self._devices_changed = threading.Event()
        self._stop_device_watcher: Callable[[], None] | None = None
        try:
            from .coreaudio import watch_devices

            self._stop_device_watcher = watch_devices(self._devices_changed.set)
        except Exception:
            pass

        # Fallback timer: 10s when CoreAudio listener is active, 2s without
        poll_interval = 10 if self._stop_device_watcher else 2
        self._device_timer = rumps.Timer(self._check_devices, poll_interval)
        self._device_timer.start()
        self._device_removal_misses: int = 0
        self._stopped_for_device_removal: bool = False
        self._pending_notification: tuple[str, str] | None = None

        global _current_app_ref, _before_quit_registered
        _current_app_ref = self
        if not _before_quit_registered:
            rumps.events.before_quit.register(_dispatch_before_quit)
            _before_quit_registered = True

        if self._autoplay:
            self._play_active()

        threading.Thread(target=self._startup_update_check, daemon=True).start()

    def _halt(self, reason: str) -> None:
        self._player.stop()
        self._play_pause_item.title = "Play"
        _notify("LowHum", "", reason)

    # Noise color
    def _refresh_color_menu(self) -> None:
        for key in list(self._color_menu.keys()):
            del self._color_menu[key]
        for color in NoiseColor:
            item = rumps.MenuItem(
                color.value.capitalize(),
                callback=lambda _, c=color: self._select_color(c),
            )
            item.state = color == self._noise_color
            self._color_menu[color.value] = item

    def _select_color(self, color: NoiseColor) -> None:
        was_playing = self._player.playing
        if was_playing:
            self._player.stop()
            self._play_pause_item.title = "Play"
        self._noise_color = color
        self._refresh_color_menu()
        self._persist()
        if was_playing:
            self._play_active()

    def _play_active(self) -> None:
        if self._block_speakers and is_builtin_speaker(self._selected_device):
            _notify(
                "LowHum",
                "",
                "Playback blocked; built-in speakers are disabled.",
            )
            return
        self._player.play(
            ensure_audio(self._noise_color),
            device=self._selected_device,
            loop=True,
        )
        self._play_pause_item.title = "Pause"

    # Device management

    def _refresh_devices(self) -> None:
        try:
            devices = list_output_devices()
        except sd.PortAudioError:
            return
        self._known_device_names = {name for _, name in devices}

        for key in list(self._device_menu.keys()):
            del self._device_menu[key]

        sys_item = rumps.MenuItem(
            "System Default",
            callback=lambda _: self._select_device(None),
        )
        sys_item.state = self._selected_device is None
        self._device_menu["System Default"] = sys_item

        for idx, name in devices:
            item = rumps.MenuItem(
                name,
                callback=lambda _, d=idx: self._select_device(d),
            )
            item.state = self._selected_device == idx
            # Use idx in key to avoid collisions when devices share names
            self._device_menu[f"_{idx}"] = item

    def _select_device(self, device_id: int | None) -> None:
        was_playing = self._player.playing
        self._player.stop()
        self._play_pause_item.title = "Play"

        self._selected_device = device_id
        self._persist()
        self._refresh_devices()

        if was_playing:
            self._play_active()

    def _check_devices(self, _: rumps.Timer) -> None:
        # Show any pending update notification (from background thread) on main
        if self._pending_notification is not None:
            title, msg = self._pending_notification
            self._pending_notification = None
            _notify("LowHum", title, msg)

        # catches silent default-device fallback to speakers
        # (e.g. Bluetooth dies but the device entry lingers in PortAudio)
        if (
            self._block_speakers
            and self._player.playing
            and is_builtin_speaker(self._selected_device)
        ):
            self._halt("Stopped; output fell back to built-in speakers.")

        # Skip the device-list query if CoreAudio hasn't signaled a change
        if self._stop_device_watcher and not self._devices_changed.is_set():
            return
        self._devices_changed.clear()

        try:
            current = {name for _, name in list_output_devices()}
        except sd.PortAudioError:
            return

        if current != self._known_device_names:
            removed = self._known_device_names - current
            added = current - self._known_device_names
            if removed and (self._player.playing or self._player.paused):
                self._device_removal_misses += 1
                if self._device_removal_misses >= 2:
                    self._device_removal_misses = 0
                    self._stopped_for_device_removal = True
                    self._halt("Audio stopped; output device disconnected.")
                    self._refresh_devices()
            elif added and self._stopped_for_device_removal:
                self._device_removal_misses = 0
                self._stopped_for_device_removal = False
                self._refresh_devices()
                self._play_active()
            else:
                self._device_removal_misses = 0
                self._refresh_devices()
        else:
            self._device_removal_misses = 0

    def _on_toggle_block_speakers(self, _: rumps.MenuItem) -> None:
        self._block_speakers = not self._block_speakers
        self._block_speakers_item.state = self._block_speakers
        if self._block_speakers and self._player.playing:
            if is_builtin_speaker(self._selected_device):
                self._halt("Stopped; built-in speakers are now blocked.")
        self._persist()

    def _on_toggle_login(self, _: rumps.MenuItem) -> None:
        enabled = not _login_item_active()
        _set_login_item(enabled)
        self._login_item.state = enabled

    def _startup_update_check(self) -> None:
        new_ver, msg = _check_pypi_version()
        if new_ver:
            self._pending_notification = ("Update available", msg)

    # Playback

    def _on_play_pause(self, _: rumps.MenuItem) -> None:
        if self._player.playing:
            self._player.pause()
            self._play_pause_item.title = "Resume"
        elif self._player.paused:
            self._player.resume()
            self._play_pause_item.title = "Pause"
        else:
            self._play_active()

    def _on_stop(self, _: rumps.MenuItem) -> None:
        self._stopped_for_device_removal = False
        self._player.stop()
        self._play_pause_item.title = "Play"

    def _on_before_quit(self, _: object) -> None:
        """Cleanup before app terminates."""
        if self._stop_device_watcher:
            self._stop_device_watcher()
            self._stop_device_watcher = None
        self._device_timer.stop()
        self._persist()
        self._player.stop(hard=True)

    def _on_quit(self, _: rumps.MenuItem) -> None:
        rumps.quit_application()

    def _persist(self) -> None:
        _save_config(
            self._selected_device,
            self._noise_color,
            block_speakers=self._block_speakers,
        )
