"""Icon resources for LowHum macOS application."""

from importlib import resources
from pathlib import Path


_ICONS_PACKAGE = resources.files("lowhum.resources") / "icons"


def menubar_icon_path(dark_mode: bool = True) -> Path:
    """Return path to the menubar icon for the specified theme."""
    name = "menubar_dark.png" if dark_mode else "menubar_light.png"
    return Path(str(_ICONS_PACKAGE / name))
