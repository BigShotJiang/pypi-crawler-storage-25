"""CoreAudio device-change listener via ctypes.

Registers a property listener on kAudioHardwarePropertyDevices so we get
push notifications when audio devices connect or disconnect, instead of
polling sd.query_devices() every few seconds.
"""

import ctypes
import ctypes.util
import logging
import threading
from collections.abc import Callable

log = logging.getLogger(__name__)

# CoreAudio types
AudioObjectID = ctypes.c_uint32
AudioObjectPropertySelector = ctypes.c_uint32
AudioObjectPropertyScope = ctypes.c_uint32
AudioObjectPropertyElement = ctypes.c_uint32
OSStatus = ctypes.c_int32


class AudioObjectPropertyAddress(ctypes.Structure):
    _fields_ = [
        ("mSelector", AudioObjectPropertySelector),
        ("mScope", AudioObjectPropertyScope),
        ("mElement", AudioObjectPropertyElement),
    ]


# AudioObjectPropertyListenerProc signature:
#   OSStatus (*)(AudioObjectID, UInt32, const AudioObjectPropertyAddress*, void*)
ListenerProc = ctypes.CFUNCTYPE(
    OSStatus,
    AudioObjectID,
    ctypes.c_uint32,
    ctypes.POINTER(AudioObjectPropertyAddress),
    ctypes.c_void_p,
)

# well-known constants
_kAudioObjectSystemObject = 1
_kAudioHardwarePropertyDevices = 0x64657623  # 'dev#'
_kAudioObjectPropertyScopeGlobal = 0x676C6F62  # 'glob'
_kAudioObjectPropertyElementMain = 0


def _load_coreaudio():
    path = ctypes.util.find_library("CoreAudio")
    if not path:
        # fallback to framework path directly
        path = "/System/Library/Frameworks/CoreAudio.framework/CoreAudio"
    lib = ctypes.cdll.LoadLibrary(path)

    lib.AudioObjectAddPropertyListener.argtypes = [
        AudioObjectID,
        ctypes.POINTER(AudioObjectPropertyAddress),
        ListenerProc,
        ctypes.c_void_p,
    ]
    lib.AudioObjectAddPropertyListener.restype = OSStatus

    lib.AudioObjectRemovePropertyListener.argtypes = [
        AudioObjectID,
        ctypes.POINTER(AudioObjectPropertyAddress),
        ListenerProc,
        ctypes.c_void_p,
    ]
    lib.AudioObjectRemovePropertyListener.restype = OSStatus

    return lib


def watch_devices(callback: Callable[[], None]) -> Callable[[], None]:
    """Register a CoreAudio listener for device connect/disconnect events.

    The *callback* is invoked from an arbitrary CoreAudio thread whenever
    the system device list changes. Keep it lightweight (e.g. set a flag).

    Returns a cleanup function that removes the listener.
    """
    lib = _load_coreaudio()

    @ListenerProc
    def _on_devices_changed(_obj_id, _count, _addresses, _client_data):
        try:
            callback()
        except Exception:
            log.exception("device-change callback failed")
        return 0  # noErr

    addr = AudioObjectPropertyAddress(
        _kAudioHardwarePropertyDevices,
        _kAudioObjectPropertyScopeGlobal,
        _kAudioObjectPropertyElementMain,
    )

    status = lib.AudioObjectAddPropertyListener(
        _kAudioObjectSystemObject,
        ctypes.byref(addr),
        _on_devices_changed,
        None,
    )
    if status != 0:
        raise OSError(f"AudioObjectAddPropertyListener failed: {status}")

    removed = threading.Event()

    def stop():
        if removed.is_set():
            return
        removed.set()
        lib.AudioObjectRemovePropertyListener(
            _kAudioObjectSystemObject,
            ctypes.byref(addr),
            _on_devices_changed,
            None,
        )

    # prevent the callback cfunctype from being garbage collected
    stop._prevent_gc = _on_devices_changed  # pyright: ignore[reportFunctionMemberAccess]

    return stop
