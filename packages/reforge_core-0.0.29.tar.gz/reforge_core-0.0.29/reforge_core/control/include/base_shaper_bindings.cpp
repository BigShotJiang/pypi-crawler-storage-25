#include <pybind11/pybind11.h>
#include <pybind11/eigen.h>
#include <pybind11/numpy.h>
#include <pybind11/stl.h>
#include "base_shaper.hpp"

namespace py = pybind11;

namespace {

py::dict shape_shared_axes_lifted(
    const Eigen::MatrixXd& command,
    const std::vector<Eigen::MatrixXd>& params_sequence,
    const Eigen::MatrixXd& initial_input_history,
    const Eigen::MatrixXd& initial_y_history,
    const Eigen::MatrixXd& initial_v_history,
    const Eigen::MatrixXd& initial_a_history,
    int initial_M,
    bool initial_buffers_seeded,
    double sample_time
) {
    control::SharedLiftedShaperResult native_result = control::shapeSharedAxesLifted(
        command,
        params_sequence,
        initial_input_history,
        initial_y_history,
        initial_v_history,
        initial_a_history,
        initial_M,
        initial_buffers_seeded,
        sample_time
    );

    py::dict result;
    result["positions"] = native_result.positions;
    result["velocities"] = native_result.velocities;
    result["accelerations"] = native_result.accelerations;
    result["final_input_history"] = native_result.final_input_history;
    result["final_y_history"] = native_result.final_y_history;
    result["final_v_history"] = native_result.final_v_history;
    result["final_a_history"] = native_result.final_a_history;
    result["final_impulse"] = native_result.final_impulse;
    result["final_M"] = native_result.final_M;
    result["M_sequence"] = native_result.M_sequence;
    result["buffers_seeded"] = native_result.buffers_seeded;
    result["profile_impulse_seconds"] = native_result.impulse_seconds;
    result["profile_schedule_seconds"] = native_result.schedule_seconds;
    result["profile_tap_seconds"] = native_result.tap_seconds;
    result["profile_history_seconds"] = native_result.history_seconds;
    result["profile_finalize_seconds"] = native_result.finalize_seconds;
    return result;
}

}  // namespace

/*
Summary:
  Register Python bindings for the `control::BaseShaper` API.
Args:
  m: Pybind11 module object provided by `PYBIND11_MODULE`.
Returns:
  None.
Side Effects:
  Defines Python-visible shaper methods in module `base_shaper`.
Raises:
  None.
Preconditions:
  `control::BaseShaper` and pybind11 are linked and loadable.
*/
PYBIND11_MODULE(base_shaper, m) {
    m.doc() = "Python bindings for BaseShaper C++ class"; // Optional module docstring

    py::class_<control::BaseShaper>(m, "BaseShaper")
        .def(py::init<double>(), py::arg("Ts"),
             "Initialize BaseShaper with sampling time Ts")
        .def("shape_sample", &control::BaseShaper::shape_sample,
             py::arg("x_i"), py::arg("frf_params"),
             "Shape a single input sample using current dynamics parameters")
        .def("shape_trajectory", &control::BaseShaper::shape_trajectory,
             py::arg("x"), py::arg("varying_params"),
             "Shape a complete trajectory using varying dynamics parameters")
        .def("finalize", &control::BaseShaper::finalize,
             py::arg("sample_count") = -1,
             "Append hold samples for the shaper delay and return them")
        .def("delay_samples", &control::BaseShaper::delaySamples,
             "Current shaper delay (M) in samples")
        .def("compute_zvd_shaper", &control::BaseShaper::compute_zvd_shaper,
             py::arg("params_array"),
             "Compute ZVD shaper impulse response for given dynamics parameters");

    m.def(
        "shape_shared_axes_lifted",
        &shape_shared_axes_lifted,
        py::arg("command"),
        py::arg("params_sequence"),
        py::arg("initial_input_history"),
        py::arg("initial_y_history"),
        py::arg("initial_v_history"),
        py::arg("initial_a_history"),
        py::arg("initial_M"),
        py::arg("initial_buffers_seeded"),
        py::arg("sample_time"),
        "Shape a shared-impulse multi-axis command block with lifted native loops"
    );
}
