#include "base_shaper.hpp"

#include <algorithm>
#include <array>
#include <chrono>
#include <deque>
#include <iostream>
#include <thread>

namespace control {

namespace {
constexpr std::size_t kMinDerivativeWindow = 3;
using HistoryMatrix =
    Eigen::Matrix<double, Eigen::Dynamic, Eigen::Dynamic, Eigen::RowMajor>;
using RowMajorMatrix =
    Eigen::Matrix<double, Eigen::Dynamic, Eigen::Dynamic, Eigen::RowMajor>;
using SteadyClock = std::chrono::steady_clock;

/**
 * @brief Convert a steady-clock interval to seconds.
 */
double elapsedSeconds(SteadyClock::time_point start, SteadyClock::time_point stop) {
    return std::chrono::duration<double>(stop - start).count();
}

/**
 * @brief One nonzero impulse tap used while composing multi-mode shapers sparsely.
 */
struct SparseTap {
    int index;        ///< Tap index in samples.
    double amplitude; ///< Tap amplitude contribution.
};

/**
 * @brief Fixed-size tap container for one fractional-sample ZVD mode.
 */
struct ModeTaps {
    std::array<SparseTap, 6> taps; ///< Nonzero taps after linear sample splitting.
    int size = 0;                  ///< Number of valid entries in `taps`.
    int max_index = 0;             ///< Largest valid tap index.
};

/**
 * @brief Compute sparse ZVD taps for one vibration mode.
 *
 * Args:
 *   sample_time: Controller sample period [s].
 *   wn: Natural frequency [rad/s].
 *   zeta: Damping ratio [-].
 * Returns:
 *   Sparse taps for the one-mode impulse train.
 * Side Effects:
 *   None.
 * Raises:
 *   std::invalid_argument: If `sample_time <= 0`, `wn <= 0`, or `zeta` is not in `(0, 1)`.
 * Preconditions:
 *   None.
 */
ModeTaps computeSingleModeTaps(double sample_time, double wn, double zeta) {
    if (sample_time <= 0.0) {
        throw std::invalid_argument("sample_time must be positive");
    }
    if (wn <= 0.0) {
        throw std::invalid_argument("Natural frequency must be positive");
    }
    if (!(0.0 < zeta && zeta < 1.0)) {
        throw std::invalid_argument("Damping ratio must be between 0 and 1");
    }

    const double root = std::sqrt(1.0 - zeta * zeta);
    const double wd = wn * root;
    const double k = std::exp(-zeta * M_PI / root);
    const double norm = 1.0 + 2.0 * k + k * k;
    const double amplitudes[3] = {1.0 / norm, 2.0 * k / norm, (k * k) / norm};
    const double times[3] = {0.0, M_PI / wd, 2.0 * M_PI / wd};

    ModeTaps mode_taps;
    for (int i = 0; i < 3; ++i) {
        const double n = times[i] / sample_time;
        const int index = static_cast<int>(std::floor(n));
        const double frac = n - static_cast<double>(index);
        mode_taps.taps[mode_taps.size++] = {
            index,
            (1.0 - frac) * amplitudes[i],
        };
        mode_taps.max_index = std::max(mode_taps.max_index, index);
        if (frac > 0.0) {
            mode_taps.taps[mode_taps.size++] = {index + 1, frac * amplitudes[i]};
            mode_taps.max_index = std::max(mode_taps.max_index, index + 1);
        }
    }

    return mode_taps;
}

/**
 * @brief Build a dense multi-mode ZVD impulse into reusable scratch storage.
 *
 * Args:
 *   sample_time: Controller sample period [s].
 *   params: Modal parameter matrix [m x 2] with rows [wn rad/s, zeta].
 *   impulse: Scratch buffer that receives the active impulse values.
 *   next: Scratch buffer used as the convolution target.
 * Returns:
 *   Active impulse length [samples].
 * Side Effects:
 *   Mutates `impulse` and `next`.
 * Raises:
 *   std::invalid_argument: If the parameter matrix is empty, malformed, or
 *       contains invalid modal values.
 * Preconditions:
 *   None.
 */
int computeZvdImpulseScratch(
    double sample_time,
    const Eigen::MatrixXd& params,
    std::vector<double>& impulse,
    std::vector<double>& next
) {
    if (params.cols() != 2) {
        throw std::invalid_argument("params_array must have exactly 2 columns");
    }
    if (params.rows() == 0) {
        throw std::invalid_argument("params_array cannot be empty");
    }

    if (impulse.empty()) {
        impulse.resize(1);
    }
    impulse[0] = 1.0;
    int active_len = 1;

    for (int row = 0; row < params.rows(); ++row) {
        const ModeTaps mode_taps =
            computeSingleModeTaps(sample_time, params(row, 0), params(row, 1));
        const int next_len = active_len + mode_taps.max_index;
        if (static_cast<int>(next.size()) < next_len) {
            next.resize(static_cast<std::size_t>(next_len));
        }
        std::fill(next.begin(), next.begin() + next_len, 0.0);

        // Developer note (Codex): this is the same convolution as sparse tap
        // composition, but it accumulates directly into the final dense index
        // range. That avoids exponential intermediate tap products and sorting
        // while preserving every fractional-sample contribution exactly.
        for (int source_index = 0; source_index < active_len; ++source_index) {
            const double source_value = impulse[static_cast<std::size_t>(source_index)];
            if (source_value == 0.0) {
                continue;
            }
            for (int tap_index = 0; tap_index < mode_taps.size; ++tap_index) {
                const SparseTap& tap = mode_taps.taps[static_cast<std::size_t>(tap_index)];
                next[static_cast<std::size_t>(source_index + tap.index)] +=
                    source_value * tap.amplitude;
            }
        }

        impulse.swap(next);
        active_len = next_len;
    }

    return active_len;
}

/**
 * @brief Build a dense multi-mode ZVD impulse.
 *
 * Args:
 *   sample_time: Controller sample period [s].
 *   params: Modal parameter matrix [m x 2] with rows [wn rad/s, zeta].
 * Returns:
 *   Dense impulse vector [M+1].
 * Side Effects:
 *   None.
 * Raises:
 *   std::invalid_argument: If the parameter matrix is empty, malformed, or
 *       contains invalid modal values.
 * Preconditions:
 *   None.
 */
Eigen::VectorXd computeZvdImpulse(double sample_time, const Eigen::MatrixXd& params) {
    std::vector<double> impulse;
    std::vector<double> next;
    const int active_len = computeZvdImpulseScratch(
        sample_time,
        params,
        impulse,
        next
    );

    Eigen::VectorXd dense(active_len);
    for (int i = 0; i < active_len; ++i) {
        dense(i) = impulse[static_cast<std::size_t>(i)];
    }
    return dense;
}

/**
 * @brief Resize a multi-axis signal history ring.
 *
 * Args:
 *   history: Signal history [history x axes] to resize.
 *   head: Row index containing the newest sample.
 *   target_len: Required history length.
 *   fill_row: Fill row used before buffers have been seeded.
 *   buffers_seeded: Whether `history` contains real streamed samples.
 * Returns:
 *   None.
 * Side Effects:
 *   Mutates `history` and resets `head` to 0 when the matrix is reallocated.
 * Raises:
 *   None.
 * Preconditions:
 *   `target_len > 0` and `fill_row.cols() == history.cols()`.
 */
void resizeHistoryRing(
    HistoryMatrix& history,
    Eigen::Index& head,
    Eigen::Index target_len,
    const Eigen::RowVectorXd& fill_row,
    bool buffers_seeded
) {
    if (!buffers_seeded) {
        history = fill_row.replicate(target_len, 1);
        head = 0;
        return;
    }

    if (history.rows() == target_len) {
        return;
    }

    HistoryMatrix resized(target_len, history.cols());
    const Eigen::Index copy_len = std::min(history.rows(), target_len);
    if (copy_len > 0) {
        for (Eigen::Index offset = 0; offset < copy_len; ++offset) {
            resized.row(offset) =
                history.row((head + offset) % history.rows());
        }
    }

    const Eigen::RowVectorXd tail =
        copy_len > 0 ? resized.row(copy_len - 1) : fill_row;
    for (Eigen::Index row = copy_len; row < target_len; ++row) {
        resized.row(row) = tail;
    }
    history.swap(resized);
    head = 0;
}
}

SharedLiftedShaperResult shapeSharedAxesLifted(
    const Eigen::MatrixXd& command,
    const std::vector<Eigen::MatrixXd>& params_sequence,
    const Eigen::MatrixXd& initial_input_history,
    const Eigen::MatrixXd& initial_y_history,
    const Eigen::MatrixXd& initial_v_history,
    const Eigen::MatrixXd& initial_a_history,
    int initial_M,
    bool initial_buffers_seeded,
    double sample_time
) {
    if (sample_time <= 0.0) {
        throw std::invalid_argument("sample_time must be positive");
    }
    if (initial_M < 0) {
        throw std::invalid_argument("initial_M must be non-negative");
    }

    const Eigen::Index samples = command.rows();
    const Eigen::Index axes = command.cols();
    const Eigen::Index initial_len = initial_input_history.rows();
    if (axes <= 0 || samples < 0 || initial_len <= 0) {
        throw std::invalid_argument("command and initial histories must be non-empty 2D arrays");
    }
    if (static_cast<std::size_t>(samples) != params_sequence.size()) {
        throw std::invalid_argument("params_sequence length must match command samples");
    }
    if (
        initial_input_history.cols() != axes ||
        initial_y_history.cols() != axes ||
        initial_v_history.cols() != axes ||
        initial_a_history.cols() != axes
    ) {
        throw std::invalid_argument("history axis counts must match command axis count");
    }
    if (
        initial_y_history.rows() <= 0 ||
        initial_v_history.rows() <= 0 ||
        initial_a_history.rows() <= 0
    ) {
        throw std::invalid_argument("output histories must be non-empty");
    }
    if (
        initial_y_history.rows() != initial_v_history.rows() ||
        initial_y_history.rows() != initial_a_history.rows()
    ) {
        throw std::invalid_argument("output history lengths must match");
    }

    SharedLiftedShaperResult result;
    result.positions = Eigen::MatrixXd::Zero(samples, axes);
    result.velocities = Eigen::MatrixXd::Zero(samples, axes);
    result.accelerations = Eigen::MatrixXd::Zero(samples, axes);
    result.M_sequence = Eigen::VectorXi::Zero(samples);
    result.impulse_seconds = 0.0;
    result.schedule_seconds = 0.0;
    result.tap_seconds = 0.0;
    result.history_seconds = 0.0;
    result.finalize_seconds = 0.0;

    const RowMajorMatrix command_rows = command;
    const RowMajorMatrix initial_input_rows = initial_input_history;
    std::vector<Eigen::Index> symbolic_buf(static_cast<std::size_t>(initial_len));
    for (Eigen::Index i = 0; i < initial_len; ++i) {
        symbolic_buf[static_cast<std::size_t>(i)] = i;
    }

    HistoryMatrix y_history = initial_y_history;
    HistoryMatrix v_history = initial_v_history;
    HistoryMatrix a_history = initial_a_history;
    Eigen::Index history_head = 0;

    int current_M = initial_M;
    int final_M = initial_M;
    bool input_buffers_seeded = initial_buffers_seeded;
    bool output_buffers_seeded = initial_buffers_seeded;
    std::vector<double> impulse_scratch{1.0};
    std::vector<double> next_impulse_scratch;
    std::vector<int> active_tap_indices;
    std::vector<double> active_tap_values;
    int final_impulse_len = 1;
    const Eigen::RowVectorXd zero_row = Eigen::RowVectorXd::Zero(axes);

    for (Eigen::Index sample_index = 0; sample_index < samples; ++sample_index) {
        const auto impulse_start = SteadyClock::now();
        const int impulse_len = computeZvdImpulseScratch(
            sample_time,
            params_sequence[static_cast<std::size_t>(sample_index)],
            impulse_scratch,
            next_impulse_scratch
        );
        const int M_new = impulse_len - 1;
        result.impulse_seconds += elapsedSeconds(impulse_start, SteadyClock::now());

        const auto schedule_start = SteadyClock::now();
        if (M_new != current_M) {
            const std::size_t new_len = static_cast<std::size_t>(M_new + 1);
            std::vector<Eigen::Index> resized(new_len);
            const std::size_t copy_len = std::min(symbolic_buf.size(), new_len);
            for (std::size_t i = 0; i < copy_len; ++i) {
                resized[i] = symbolic_buf[i];
            }
            const Eigen::Index tail = copy_len > 0 ? resized[copy_len - 1] : 0;
            for (std::size_t i = copy_len; i < new_len; ++i) {
                resized[i] = tail;
            }
            symbolic_buf.swap(resized);
            current_M = M_new;
        }

        if (!input_buffers_seeded) {
            std::fill(
                symbolic_buf.begin(),
                symbolic_buf.end(),
                initial_len + sample_index
            );
            input_buffers_seeded = true;
        } else if (!symbolic_buf.empty()) {
            for (std::size_t i = symbolic_buf.size() - 1; i > 0; --i) {
                symbolic_buf[i] = symbolic_buf[i - 1];
            }
            symbolic_buf[0] = initial_len + sample_index;
        }
        result.schedule_seconds += elapsedSeconds(schedule_start, SteadyClock::now());

        const auto tap_start = SteadyClock::now();
        active_tap_indices.clear();
        active_tap_values.clear();
        active_tap_indices.reserve(static_cast<std::size_t>(impulse_len));
        active_tap_values.reserve(static_cast<std::size_t>(impulse_len));
        for (int tap = 0; tap < impulse_len; ++tap) {
            const double impulse_value = impulse_scratch[static_cast<std::size_t>(tap)];
            if (impulse_value != 0.0) {
                active_tap_indices.push_back(tap);
                active_tap_values.push_back(impulse_value);
            }
        }

        Eigen::RowVectorXd shaped_row = Eigen::RowVectorXd::Zero(axes);
        for (std::size_t active_index = 0; active_index < active_tap_indices.size(); ++active_index) {
            const int tap = active_tap_indices[active_index];
            const Eigen::Index source_index = symbolic_buf[static_cast<std::size_t>(tap)];
            const double impulse_value = active_tap_values[active_index];
            if (source_index < initial_len) {
                shaped_row.noalias() += impulse_value * initial_input_rows.row(source_index);
            } else {
                shaped_row.noalias() +=
                    impulse_value * command_rows.row(source_index - initial_len);
            }
        }
        result.tap_seconds += elapsedSeconds(tap_start, SteadyClock::now());

        const auto history_start = SteadyClock::now();
        const Eigen::Index history_len = static_cast<Eigen::Index>(
            std::max(M_new + 1, static_cast<int>(kMinDerivativeWindow))
        );
        if (y_history.rows() != history_len) {
            const Eigen::Index old_history_head = history_head;
            Eigen::Index v_history_head = old_history_head;
            Eigen::Index a_history_head = old_history_head;
            resizeHistoryRing(
                y_history,
                history_head,
                history_len,
                command_rows.row(sample_index),
                output_buffers_seeded
            );
            resizeHistoryRing(
                v_history,
                v_history_head,
                history_len,
                zero_row,
                output_buffers_seeded
            );
            resizeHistoryRing(
                a_history,
                a_history_head,
                history_len,
                zero_row,
                output_buffers_seeded
            );
        }

        if (!output_buffers_seeded) {
            y_history = shaped_row.replicate(history_len, 1);
            v_history = HistoryMatrix::Zero(history_len, axes);
            a_history = HistoryMatrix::Zero(history_len, axes);
            history_head = 0;
            output_buffers_seeded = true;
        } else {
            history_head = (history_head + history_len - 1) % history_len;
            y_history.row(history_head) = shaped_row;
            v_history.row(history_head) = zero_row;
            a_history.row(history_head) = zero_row;

            if (history_len >= 2) {
                const Eigen::Index prev_index = (history_head + 1) % history_len;
                v_history.row(history_head) =
                    (y_history.row(history_head) - y_history.row(prev_index)) /
                    sample_time;
            }
            if (history_len >= 3) {
                const Eigen::Index prev_index = (history_head + 1) % history_len;
                const Eigen::Index prev2_index = (history_head + 2) % history_len;
                v_history.row(prev_index) =
                    (y_history.row(history_head) - y_history.row(prev2_index)) /
                    (2.0 * sample_time);
                a_history.row(prev_index) =
                    (
                        y_history.row(history_head) -
                        2.0 * y_history.row(prev_index) +
                        y_history.row(prev2_index)
                    ) /
                    (sample_time * sample_time);
            }
            if (history_len >= 2) {
                const Eigen::Index prev_index = (history_head + 1) % history_len;
                a_history.row(history_head) =
                    (v_history.row(history_head) - v_history.row(prev_index)) /
                    sample_time;
            }
        }

        result.positions.row(sample_index) = y_history.row(history_head);
        result.velocities.row(sample_index) = v_history.row(history_head);
        result.accelerations.row(sample_index) = a_history.row(history_head);
        result.history_seconds += elapsedSeconds(history_start, SteadyClock::now());
        result.M_sequence(sample_index) = M_new;
        final_M = M_new;
        final_impulse_len = impulse_len;
    }

    const auto finalize_start = SteadyClock::now();
    result.final_input_history = Eigen::MatrixXd::Zero(
        static_cast<Eigen::Index>(symbolic_buf.size()),
        axes
    );
    for (std::size_t i = 0; i < symbolic_buf.size(); ++i) {
        const Eigen::Index row = static_cast<Eigen::Index>(i);
        const Eigen::Index source_index = symbolic_buf[i];
        if (source_index < initial_len) {
            result.final_input_history.row(row) = initial_input_rows.row(source_index);
        } else {
            result.final_input_history.row(row) = command_rows.row(source_index - initial_len);
        }
    }

    const Eigen::Index final_history_len = static_cast<Eigen::Index>(
        std::max(final_M + 1, static_cast<int>(kMinDerivativeWindow))
    );
    result.final_y_history = Eigen::MatrixXd::Zero(final_history_len, axes);
    result.final_v_history = Eigen::MatrixXd::Zero(final_history_len, axes);
    result.final_a_history = Eigen::MatrixXd::Zero(final_history_len, axes);
    if (y_history.rows() < final_history_len) {
        const Eigen::Index old_history_head = history_head;
        Eigen::Index v_history_head = old_history_head;
        Eigen::Index a_history_head = old_history_head;
        resizeHistoryRing(
            y_history,
            history_head,
            final_history_len,
            zero_row,
            output_buffers_seeded
        );
        resizeHistoryRing(
            v_history,
            v_history_head,
            final_history_len,
            zero_row,
            output_buffers_seeded
        );
        resizeHistoryRing(
            a_history,
            a_history_head,
            final_history_len,
            zero_row,
            output_buffers_seeded
        );
    }
    for (Eigen::Index offset = 0; offset < final_history_len; ++offset) {
        const Eigen::Index source_row = (history_head + offset) % y_history.rows();
        result.final_y_history.row(offset) = y_history.row(source_row);
        result.final_v_history.row(offset) = v_history.row(source_row);
        result.final_a_history.row(offset) = a_history.row(source_row);
    }

    result.final_impulse = Eigen::VectorXd::Zero(final_impulse_len);
    for (int i = 0; i < final_impulse_len; ++i) {
        result.final_impulse(i) = impulse_scratch[static_cast<std::size_t>(i)];
    }
    result.final_M = final_M;
    result.buffers_seeded = input_buffers_seeded && output_buffers_seeded;
    result.finalize_seconds = elapsedSeconds(finalize_start, SteadyClock::now());
    return result;
}

BaseShaper::BaseShaper(double Ts)
: Ts_(Ts), M_(0), I_(Eigen::VectorXd::Ones(1)), x_buf_(1, 0.0), x_head_(0),
  y_buf_(kMinDerivativeWindow, 0.0), v_buf_(kMinDerivativeWindow, 0.0),
  a_buf_(kMinDerivativeWindow, 0.0), buffers_seeded_(false) {
    if (Ts <= 0.0) throw std::invalid_argument("Sampling time must be positive");
}

/*
Summary:
  Reset internal buffers so the next call starts a fresh shaping stream.
Args:
  None.
Returns:
  None.
Side Effects:
  Clears and reinitializes `M_`, `I_`, circular input buffer, and derivative history buffers.
Raises:
  None.
Preconditions:
  The object has been constructed.
*/
void BaseShaper::resetState() {
    M_ = 0;
    I_.resize(1);
    I_(0) = 1.0;
    x_buf_.assign(1, 0.0);
    x_head_ = 0;
    y_buf_.clear();
    y_buf_.assign(kMinDerivativeWindow, 0.0);
    v_buf_.clear();
    v_buf_.assign(kMinDerivativeWindow, 0.0);
    a_buf_.clear();
    a_buf_.assign(kMinDerivativeWindow, 0.0);
    buffers_seeded_ = false;
}

/*
Summary:
  Resize input and history buffers when the active impulse length changes.
Args:
  M_new: New shaper delay in samples (impulse length is `M_new + 1`).
  seed: Fill value used when new entries must be created.
Returns:
  None.
Side Effects:
  Updates `M_`, input circular buffer layout, and derivative history buffer lengths.
  Preserves existing samples in time order to avoid a phase jump.
Raises:
  None.
Preconditions:
  `M_new` is derived from a valid impulse response for the current sample period.
*/
void BaseShaper::ensureInputBufferSizeOnChange(int M_new, double seed) {
    if (M_new == M_) return;

    const std::size_t new_len = static_cast<std::size_t>(M_new + 1);
    const std::size_t old_len = x_buf_.size();

    if (old_len == 0) {
        x_buf_.assign(new_len, seed);
        x_head_ = 0;
    } else {
        std::vector<double> resized(new_len);
        const std::size_t copy_len = std::min(old_len, new_len);
        for (std::size_t i = 0; i < copy_len; ++i) {
            resized[i] = x_buf_[(x_head_ + i) % old_len];
        }

        const double tail = copy_len ? resized[copy_len - 1]
                                     : x_buf_[(x_head_) % old_len];
        for (std::size_t i = copy_len; i < new_len; ++i) {
            resized[i] = tail;
        }

        x_buf_.swap(resized);
        x_head_ = 0;
    }

    M_ = M_new;

    const std::size_t history_len =
        std::max<std::size_t>(static_cast<std::size_t>(M_ + 1), kMinDerivativeWindow);

    auto resizeHistory = [&](std::deque<double>& buf, double fill_value) {
        if (!buffers_seeded_) {
            buf.assign(history_len, fill_value);
            return;
        }
        while (buf.size() > history_len) {
            buf.pop_back();
        }
        while (buf.size() < history_len) {
            const double tail = buf.empty() ? fill_value : buf.back();
            buf.push_back(tail);
        }
    };

    resizeHistory(y_buf_, seed);
    resizeHistory(v_buf_, 0.0);
    resizeHistory(a_buf_, 0.0);
}

/*
Summary:
  Insert the newest shaped position and compute aligned velocity/acceleration estimates.
Args:
  y: Current shaped position sample.
Returns:
  `std::tuple<double,double,double>` containing `(position, velocity, acceleration)`.
Side Effects:
  Mutates `y_buf_`, `v_buf_`, `a_buf_`, and may set `buffers_seeded_` on first call.
Raises:
  None.
Preconditions:
  `Ts_` is positive and buffer sizes are consistent with `M_`.
*/
std::tuple<double,double,double>
BaseShaper::updateOutputHistory(double y) {
    const std::size_t history_len =
        std::max<std::size_t>(static_cast<std::size_t>(M_ + 1), kMinDerivativeWindow);

    if (!buffers_seeded_) {
        y_buf_.assign(history_len, y);
        v_buf_.assign(history_len, 0.0);
        a_buf_.assign(history_len, 0.0);
        buffers_seeded_ = true;
        return {y, 0.0, 0.0};
    }

    y_buf_.push_front(y);
    if (y_buf_.size() > history_len) {
        y_buf_.pop_back();
    }
    while (y_buf_.size() < history_len) {
        const double tail = y_buf_.empty() ? y : y_buf_.back();
        y_buf_.push_back(tail);
    }

    v_buf_.push_front(0.0);
    if (v_buf_.size() > history_len) {
        v_buf_.pop_back();
    }
    while (v_buf_.size() < history_len) {
        const double tail = v_buf_.empty() ? 0.0 : v_buf_.back();
        v_buf_.push_back(tail);
    }

    a_buf_.push_front(0.0);
    if (a_buf_.size() > history_len) {
        a_buf_.pop_back();
    }
    while (a_buf_.size() < history_len) {
        const double tail = a_buf_.empty() ? 0.0 : a_buf_.back();
        a_buf_.push_back(tail);
    }

    if (y_buf_.size() >= 2) {
        v_buf_[0] = (y_buf_[0] - y_buf_[1]) / Ts_;
    } else {
        v_buf_[0] = 0.0;
    }

    if (y_buf_.size() >= 3) {
        v_buf_[1] = (y_buf_[0] - y_buf_[2]) / (2.0 * Ts_);
        a_buf_[1] = (y_buf_[0] - 2.0 * y_buf_[1] + y_buf_[2]) / (Ts_ * Ts_);
    }

    if (v_buf_.size() >= 2) {
        a_buf_[0] = (v_buf_[0] - v_buf_[1]) / Ts_;
    } else {
        a_buf_[0] = 0.0;
    }

    return {y, v_buf_[0], a_buf_[0]};
}

/*
Summary:
  Shape one command sample using the current modal parameters and return y/v/a.
Args:
  x_i: Raw command sample for one shaped joint axis.
  frf_params: Modal parameter matrix `[m x 2]` with columns `(wn [rad/s], zeta [-])`.
Returns:
  `std::tuple<double,double,double>` containing shaped `(position, velocity, acceleration)`.
Side Effects:
  Updates impulse cache usage, input/history buffers, and internal shaping state.
Raises:
  std::invalid_argument: If `frf_params` is empty or does not have exactly 2 columns.
Preconditions:
  `Ts_ > 0` and each modal row has physically valid parameters.
*/
std::tuple<double,double,double>
BaseShaper::shapeSample(double x_i, const Eigen::MatrixXd& frf_params) {
    // Validate params: (m,2), m>0
    if (frf_params.cols() != 2) {
        throw std::invalid_argument("frf_params must have shape (m,2)");
    }
    if (frf_params.rows() == 0) {
        throw std::invalid_argument("frf_params cannot be empty");
    }

    // Compute shaper & apply buffer resize if needed
    auto [I_new, M_new] = compute_zvd_shaper(frf_params);
    ensureInputBufferSizeOnChange(M_new, x_i);
    I_ = std::move(I_new);

    // Push newest raw sample to the front (newest-first)
    if (!buffers_seeded_) {
        std::fill(x_buf_.begin(), x_buf_.end(), x_i);
        x_head_ = 0;
    } else if (!x_buf_.empty()) {
        const std::size_t len = x_buf_.size();
        x_head_ = (x_head_ + len - 1) % len;
        x_buf_[x_head_] = x_i;
    }

    // OSA FIR: y = I · x_buf
    Eigen::VectorXd x_arr(M_ + 1);
    for (int i = 0; i <= M_; ++i) {
        x_arr(i) = xAtOffset(static_cast<std::size_t>(i));
    }
    double y = I_.dot(x_arr);

    return updateOutputHistory(y);
}

/*
Summary:
  Flush the FIR tail by replaying the held final input for bounded samples.
Args:
  sample_count: Maximum number of hold-input samples to emit, or a negative
    value to flush all `M_` delayed samples.
Returns:
  `std::vector<std::tuple<double,double,double>>` tail samples of `(position, velocity, acceleration)`.
Side Effects:
  Advances input/history buffers as if additional samples were processed.
Raises:
  std::invalid_argument: If `sample_count < -1`.
Preconditions:
  Streaming state has been seeded by at least one prior `shapeSample` call.
*/
std::vector<std::tuple<double,double,double>>
BaseShaper::finalize(int sample_count) {
    std::vector<std::tuple<double,double,double>> tail;
    if (sample_count < -1) {
        throw std::invalid_argument("sample_count must be non-negative or -1");
    }

    const int samples_to_emit = sample_count < 0 ? M_ : sample_count;
    if (
        samples_to_emit == 0 ||
        !buffers_seeded_ ||
        M_ <= 0 ||
        x_buf_.empty() ||
        I_.size() == 0
    ) {
        return tail;
    }

    const double hold_input = xAtOffset(0);

    tail.reserve(static_cast<std::size_t>(samples_to_emit));
    for (int i = 0; i < samples_to_emit; ++i) {
        if (!x_buf_.empty()) {
            const std::size_t len = x_buf_.size();
            x_head_ = (x_head_ + len - 1) % len;
            x_buf_[x_head_] = hold_input;
        }

        Eigen::VectorXd x_arr(M_ + 1);
        for (int k = 0; k <= M_; ++k) {
            x_arr(k) = xAtOffset(static_cast<std::size_t>(k));
        }
        double y = I_.dot(x_arr);
        tail.emplace_back(updateOutputHistory(y));
    }

    return tail;
}

std::tuple<Eigen::VectorXd, Eigen::VectorXd, Eigen::VectorXd>
BaseShaper::shapeTrajectory(const Eigen::VectorXd& x,
                            const std::vector<Eigen::MatrixXd>& varying_params,
                            bool reset) {
    if (x.size() <= 0) throw std::invalid_argument("x must be non-empty");
    if (varying_params.size() != static_cast<size_t>(x.size())) {
        throw std::invalid_argument("varying_params must have length N");
    }
    if (varying_params[0].cols() != 2) {
        throw std::invalid_argument("each params must have 2 columns");
    }

    if (reset) resetState();

    const int N = static_cast<int>(x.size());

    const unsigned int hw_threads = std::thread::hardware_concurrency();
    const unsigned int thread_cap = hw_threads == 0 ? 1u : hw_threads;
    constexpr unsigned int kMinChunk = 64;
    const unsigned int possible_threads =
        std::min<unsigned int>(thread_cap, static_cast<unsigned int>((N + kMinChunk - 1) / kMinChunk));
    const unsigned int thread_count = std::max(1u, possible_threads);
    if (reset && thread_count > 1) {
        std::cout << "[BaseShaper] Parallel shaping across " << thread_count
                  << " threads (chunk threshold=" << kMinChunk << " samples)."
                  << std::endl;
        std::vector<CachedImpulse> impulses;
        impulses.reserve(static_cast<std::size_t>(N));
        int max_M = 0;
        for (int i = 0; i < N; ++i) {
            CachedImpulse cached = compute_zvd_shaper(varying_params[static_cast<std::size_t>(i)]);
            max_M = std::max(max_M, cached.second);
            impulses.emplace_back(std::move(cached));
        }

        const std::size_t max_history_len =
            std::max<std::size_t>(static_cast<std::size_t>(max_M + 1), kMinDerivativeWindow);

        Eigen::VectorXd y = Eigen::VectorXd::Zero(N);
        const auto first_sample = x(0);
        const int block = (N + static_cast<int>(thread_count) - 1) / static_cast<int>(thread_count);
        std::vector<std::thread> workers;
        workers.reserve(thread_count);
        // Each worker computes an independent output block using convolution
        // against the precomputed per-sample impulse response.
        for (unsigned int t = 0; t < thread_count; ++t) {
            const int start = static_cast<int>(t) * block;
            const int end = std::min(N, start + block);
            if (start >= end) break;
            workers.emplace_back([&, start, end]() {
                for (int idx = start; idx < end; ++idx) {
                    const auto& impulse = impulses[static_cast<std::size_t>(idx)];
                    const Eigen::VectorXd& I = impulse.first;
                    const int M_local = impulse.second;
                    double y_val = 0.0;
                    for (int k = 0; k <= M_local; ++k) {
                        int sample_index = idx - k;
                        double x_val = sample_index >= 0 ? x(static_cast<Eigen::Index>(sample_index)) : first_sample;
                        y_val += I(k) * x_val;
                    }
                    y(static_cast<Eigen::Index>(idx)) = y_val;
                }
            });
        }
        for (auto& worker : workers) {
            worker.join();
        }

        Eigen::VectorXd v = Eigen::VectorXd::Zero(N);
        Eigen::VectorXd a = Eigen::VectorXd::Zero(N);

        std::deque<double> y_hist(max_history_len, y(0));
        std::deque<double> v_hist(max_history_len, 0.0);
        std::deque<double> a_hist(max_history_len, 0.0);

        if (N > 0) {
            v(0) = 0.0;
            a(0) = 0.0;
        }

        // Derivatives are evaluated in one serial pass to keep boundary
        // handling identical to the streaming path.
        for (int i = 1; i < N; ++i) {
            const double y_i = y(i);

            y_hist.push_front(y_i);
            if (y_hist.size() > max_history_len) {
                y_hist.pop_back();
            }
            while (y_hist.size() < max_history_len) {
                const double tail = y_hist.empty() ? y_i : y_hist.back();
                y_hist.push_back(tail);
            }

            v_hist.push_front(0.0);
            if (v_hist.size() > max_history_len) {
                v_hist.pop_back();
            }
            while (v_hist.size() < max_history_len) {
                const double tail = v_hist.empty() ? 0.0 : v_hist.back();
                v_hist.push_back(tail);
            }

            a_hist.push_front(0.0);
            if (a_hist.size() > max_history_len) {
                a_hist.pop_back();
            }
            while (a_hist.size() < max_history_len) {
                const double tail = a_hist.empty() ? 0.0 : a_hist.back();
                a_hist.push_back(tail);
            }

            if (y_hist.size() >= 2) {
                v_hist[0] = (y_hist[0] - y_hist[1]) / Ts_;
            } else {
                v_hist[0] = 0.0;
            }

            if (y_hist.size() >= 3) {
                v_hist[1] = (y_hist[0] - y_hist[2]) / (2.0 * Ts_);
                a_hist[1] = (y_hist[0] - 2.0 * y_hist[1] + y_hist[2]) / (Ts_ * Ts_);
            }

            if (v_hist.size() >= 2) {
                a_hist[0] = (v_hist[0] - v_hist[1]) / Ts_;
            } else {
                a_hist[0] = 0.0;
            }

            v(i) = v_hist[0];
            a(i) = a_hist[0];
        }

        if (N > 0) {
            const CachedImpulse& last_impulse = impulses.back();
            M_ = last_impulse.second;
            I_ = last_impulse.first;

            const std::size_t len = static_cast<std::size_t>(M_ + 1);
            x_buf_.assign(len, first_sample);
            x_head_ = 0;
            for (std::size_t k = 0; k < len; ++k) {
                int sample_index = N - 1 - static_cast<int>(k);
                double value = sample_index >= 0 ? x(static_cast<Eigen::Index>(sample_index)) : first_sample;
                x_buf_[k] = value;
            }

            const std::size_t final_history_len =
                std::max<std::size_t>(static_cast<std::size_t>(M_ + 1), kMinDerivativeWindow);

            while (y_hist.size() > final_history_len) {
                y_hist.pop_back();
            }
            while (y_hist.size() < final_history_len) {
                const double tail = y_hist.empty() ? y(N - 1) : y_hist.back();
                y_hist.push_back(tail);
            }

            while (v_hist.size() > final_history_len) {
                v_hist.pop_back();
            }
            while (v_hist.size() < final_history_len) {
                const double tail = v_hist.empty() ? 0.0 : v_hist.back();
                v_hist.push_back(tail);
            }

            while (a_hist.size() > final_history_len) {
                a_hist.pop_back();
            }
            while (a_hist.size() < final_history_len) {
                const double tail = a_hist.empty() ? 0.0 : a_hist.back();
                a_hist.push_back(tail);
            }

            y_buf_ = y_hist;
            v_buf_ = v_hist;
            a_buf_ = a_hist;
            buffers_seeded_ = true;
        }

        auto tail = finalize();
        if (!tail.empty()) {
            const Eigen::Index extra = static_cast<Eigen::Index>(tail.size());
            y.conservativeResize(N + extra);
            v.conservativeResize(N + extra);
            a.conservativeResize(N + extra);
            for (Eigen::Index i = 0; i < extra; ++i) {
                const auto& [y_i, v_i, a_i] = tail[static_cast<std::size_t>(i)];
                const Eigen::Index row = N + i;
                y(row) = y_i;
                v(row) = v_i;
                a(row) = a_i;
            }
        }

        return {y, v, a};
    }

    Eigen::VectorXd y(N), v(N), a(N);

    for (int i = 0; i < N; ++i) {
        auto [yi, vi, ai] = shapeSample(x(i), varying_params[static_cast<std::size_t>(i)]);
        y(i) = yi; v(i) = vi; a(i) = ai;
    }

    auto tail = finalize();
    if (!tail.empty()) {
        const Eigen::Index extra = static_cast<Eigen::Index>(tail.size());
        y.conservativeResize(N + extra);
        v.conservativeResize(N + extra);
        a.conservativeResize(N + extra);
        for (Eigen::Index i = 0; i < extra; ++i) {
            const auto& [y_i, v_i, a_i] = tail[static_cast<std::size_t>(i)];
            const Eigen::Index row = N + i;
            y(row) = y_i;
            v(row) = v_i;
            a(row) = a_i;
        }
    }

    return {y, v, a};
}

std::tuple<Eigen::VectorXd, Eigen::VectorXd, Eigen::VectorXd>
BaseShaper::shapeTrajectory(const Eigen::VectorXd& x,
                            const Eigen::MatrixXd& fixed_params,
                            bool reset) {
    if (x.size() <= 0) throw std::invalid_argument("x must be non-empty");
    if (fixed_params.cols() != 2 || fixed_params.rows() == 0) {
        throw std::invalid_argument("fixed_params must be non-empty (m,2)");
    }

    if (reset) resetState();

    const int N = static_cast<int>(x.size());
    Eigen::VectorXd y(N), v(N), a(N);

    for (int i = 0; i < N; ++i) {
        auto [yi, vi, ai] = shapeSample(x(i), fixed_params);
        y(i) = yi; v(i) = vi; a(i) = ai;
    }

    auto tail = finalize();
    if (!tail.empty()) {
        const Eigen::Index extra = static_cast<Eigen::Index>(tail.size());
        y.conservativeResize(N + extra);
        v.conservativeResize(N + extra);
        a.conservativeResize(N + extra);
        for (Eigen::Index i = 0; i < extra; ++i) {
            const auto& [y_i, v_i, a_i] = tail[static_cast<std::size_t>(i)];
            const Eigen::Index row = N + i;
            y(row) = y_i;
            v(row) = v_i;
            a(row) = a_i;
        }
    }

    return {y, v, a};
}

std::pair<Eigen::VectorXd, int>
/*
Summary:
  Build (and cache) a combined ZVD impulse response for one or more vibration modes.
Args:
  params_array: Modal parameter matrix `[m x 2]` with `(wn [rad/s], zeta [-])` rows.
Returns:
  `std::pair<Eigen::VectorXd,int>` containing `(impulse, delay_samples)`.
Side Effects:
  Inserts computed responses into `impulse_cache_`.
Raises:
  std::invalid_argument: If parameter matrix shape is invalid.
Preconditions:
  Each row has physically valid modal parameters.
*/
BaseShaper::compute_zvd_shaper(const Eigen::MatrixXd& params_array) {
    if (params_array.cols() != 2) {
        throw std::invalid_argument("params_array must have exactly 2 columns");
    }
    if (params_array.rows() == 0) {
        throw std::invalid_argument("params_array cannot be empty");
    }

    ModalKey key;
    key.data.reserve(static_cast<std::size_t>(params_array.rows() * 2));
    for (int r = 0; r < params_array.rows(); ++r) {
        key.data.push_back(params_array(r, 0));
        key.data.push_back(params_array(r, 1));
    }

    if (auto it = impulse_cache_.find(key); it != impulse_cache_.end()) {
        return it->second;
    }

    Eigen::VectorXd I = computeZvdImpulse(Ts_, params_array);
    int M = static_cast<int>(I.size()) - 1;

    CachedImpulse cached{I, M};
    impulse_cache_.emplace(std::move(key), cached);
    return cached;
}

std::pair<Eigen::VectorXd, int>
/*
Summary:
  Compute a single-mode ZVD impulse response using continuous-time impulses and
  linear impulse splitting.
Args:
  wn: Natural frequency [rad/s].
  zeta: Damping ratio [-].
Returns:
  `std::pair<Eigen::VectorXd,int>` containing `(impulse, half-period delay in samples)`.
Side Effects:
  None.
Raises:
  std::invalid_argument: If `wn <= 0` or `zeta` is outside `(0,1)`.
Preconditions:
  Sample time `Ts_` is positive.
*/
BaseShaper::compute_single_mode(double wn, double zeta) {
    if (wn <= 0.0)  throw std::invalid_argument("Natural frequency must be positive");
    if (zeta <= 0.0 || zeta >= 1.0) throw std::invalid_argument("Damping ratio must be between 0 and 1");

    const double wd       = wn * std::sqrt(1.0 - zeta * zeta);
    const double k        = std::exp(-zeta * M_PI / std::sqrt(1.0 - zeta * zeta));

    const double norm = 1.0 + 2.0 * k + k * k;
    // Impulse amplitudes
    const double A0 = 1.0 / norm;
    const double A1 = 2.0 * k / norm;
    const double A2 = (k * k) / norm;

    // Continuous-time impulse times
    const double t0 = 0.0;
    const double t1 = M_PI / wd;
    const double t2 = 2.0 * M_PI / wd;

    // Real-valued sample indices
    const double n0 = t0 / Ts_;
    const double n1 = t1 / Ts_;
    const double n2 = t2 / Ts_;

    // Determine needed length (account for split into k+1)
    auto max_n = std::max(n0, std::max(n1, n2));
    int M = static_cast<int>(std::ceil(max_n)); // last nonzero may land at floor(n)+1

    Eigen::VectorXd impulse = Eigen::VectorXd::Zero(M + 1);

    auto add_split = [&](double n, double A) {
        const int k_i = static_cast<int>(std::floor(n));
        const double D = n - static_cast<double>(k_i); // [0,1)

        // Ensure array is long enough for k_i+1
        const int need_M = k_i + (D > 0.0 ? 1 : 0);
        if (need_M > M) {
            Eigen::VectorXd grown = Eigen::VectorXd::Zero(need_M + 1);
            grown.head(impulse.size()) = impulse;
            impulse.swap(grown);
            M = need_M;
        }

        // Construct impulse train
        impulse(k_i) += (1.0 - D) * A;
        if (D > 0.0) {
            impulse(k_i + 1) += D * A;
        }
    };

    add_split(n0, A0);
    add_split(n1, A1);
    add_split(n2, A2);

    return {impulse, M};
}

/*
Summary:
  Read a sample from the circular input buffer at a fixed offset from newest.
Args:
  offset: Offset in samples where `0` is the newest input.
Returns:
  `double` buffered input value.
Side Effects:
  None.
Raises:
  None.
Preconditions:
  None.
*/
double BaseShaper::xAtOffset(std::size_t offset) const {
    if (x_buf_.empty()) return 0.0;
    const std::size_t len = x_buf_.size();
    return x_buf_[(x_head_ + offset) % len];
}

} // namespace control
