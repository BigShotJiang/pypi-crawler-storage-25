"""Python interface that mirrors the covalent shaping pipeline used in C++."""

import importlib
import math
import os
import sys
import time
from collections import deque
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np

from reforge_core.control.python.base_shaper import BaseShaper
from reforge_core.control.python.map_loader import ModelLoader
from reforge_core.util.robot_dynamics import Dynamics

# TODO: Remove hard-coded values and read from CSV/config.
ROBOT_NUM_JOINTS = 6
ROBOT_NUM_SHAPED_AXES = 3
ROBOT_SIDE_LENGTH = 0.0007
ROBOT_BASE_HEIGHT = 0.364
DEFAULT_PROB_THRESH = 0.5
DEFAULT_SHARED_IMPULSE_POLICY = "combine_all_modes"
DEFAULT_LIFTED_SHAPER_CORE = "native"
DEFAULT_WINDOW_CANDIDATE_SECONDS = (0.050, 0.100, 0.150, 0.200, 0.300, 0.500)
DEFAULT_WINDOW_COMPUTE_FRACTION_LIMIT = 0.50
DEFAULT_WINDOW_PREFILL_COUNT = 1
FALLBACK_NATURAL_FREQUENCY_RAD_PER_S = 2.0 * math.pi * 5.0
FALLBACK_DAMPING_RATIO = 0.05
MIN_VALID_NATURAL_FREQUENCY_RAD_PER_S = 1.0e-6
MIN_VALID_DAMPING_RATIO = 1.0e-6
MAX_VALID_DAMPING_RATIO = 1.0 - 1.0e-6
SHARED_IMPULSE_POLICIES = {
    "combine_all_modes",
    "max_delay_axis",
    "axis0",
    "per_axis",
}
LIFTED_SHAPER_CORES = {"python", "native", "auto"}


@dataclass
class RobotState:
    """Represent robot state required for shaper inference.

    Args:
        joint_angles: Joint angles `[num_joints]` in radians.
        tcp_position: Optional tool center point position `[x, y, z]` in meters.
    Side Effects:
        None.
    Raises:
        None.
    Preconditions:
        Arrays are finite and ordered to match model joint/axis conventions.
    """

    joint_angles: np.ndarray
    tcp_position: np.ndarray | None = None


@dataclass
class ShapedSample:
    """Hold shaped command values for a single control sample.

    Args:
        positions: Shaped joint positions `[num_joints]` in radians.
        velocities: Shaped joint velocities `[num_joints]` in radians/s.
        accelerations: Shaped joint accelerations `[num_joints]` in radians/s^2.
    Side Effects:
        None.
    Raises:
        None.
    Preconditions:
        Arrays align with the same joint ordering.
    """

    positions: np.ndarray
    velocities: np.ndarray
    accelerations: np.ndarray


@dataclass
class ShapedTrajectory:
    """Store shaped trajectory arrays and time stamps.

    Args:
        positions: Shaped positions `[N, num_joints]` in radians.
        velocities: Shaped velocities `[N, num_joints]` in radians/s.
        accelerations: Shaped accelerations `[N, num_joints]` in radians/s^2.
        time: Time vector `[N]` in seconds.
    Side Effects:
        None.
    Raises:
        None.
    Preconditions:
        All arrays share the same sample count `N`.
    """

    positions: np.ndarray
    velocities: np.ndarray
    accelerations: np.ndarray
    time: np.ndarray


@dataclass
class TrajectoryWindow:
    """Store one raw trajectory slice queued for windowed shaping.

    Args:
        command: Raw joint positions `[N, num_joints]` in radians.
        states: Robot states length `N`, or an empty list for command-only shaping.
        command_dot: Joint velocities `[N, num_joints]` in radians/s.
        command_ddot: Joint accelerations `[N, num_joints]` in radians/s^2.
        time: Time vector `[N]` in seconds.
        start_index: Inclusive source trajectory start index.
        stop_index: Exclusive source trajectory stop index.
        should_shape: Whether this window should be shaped instead of passed through.
    Side Effects:
        None.
    Raises:
        None.
    Preconditions:
        Arrays share the same row count `N` and joint ordering.
    """

    command: np.ndarray
    states: list[RobotState]
    command_dot: np.ndarray
    command_ddot: np.ndarray
    time: np.ndarray
    start_index: int
    stop_index: int
    should_shape: bool = True


@dataclass
class ShapedTrajectoryWindow:
    """Store one shaped trajectory slice ready for controller consumption.

    Args:
        positions: Shaped joint positions `[N, num_joints]` in radians.
        velocities: Shaped joint velocities `[N, num_joints]` in radians/s.
        accelerations: Shaped joint accelerations `[N, num_joints]` in radians/s^2.
        time: Time vector `[N]` in seconds.
        start_index: Inclusive source trajectory start index, or the first tail
            index after the source trajectory for tail windows.
        stop_index: Exclusive source trajectory stop index, or tail stop index.
        is_tail: Whether this window was produced by final shaper flushing.
        compute_time_s: Wall-clock time spent producing this shaped window [s].
    Side Effects:
        None.
    Raises:
        None.
    Preconditions:
        Arrays share the same row count `N` and joint ordering.
    """

    positions: np.ndarray
    velocities: np.ndarray
    accelerations: np.ndarray
    time: np.ndarray
    start_index: int
    stop_index: int
    is_tail: bool
    compute_time_s: float


@dataclass
class WindowQualificationResult:
    """Describe the timing qualification result for one candidate window size.

    Args:
        window_s: Candidate window duration [s].
        passed: Whether every measured window satisfied the timing gate.
        compute_fraction_limit: Maximum allowed compute/execute-time ratio.
        prefill_windows: Number of startup windows assumed by the margin model.
        max_window_s: Maximum measured compute time [s].
        p99_window_s: 99th percentile measured compute time [s].
        min_buffer_margin_s: Minimum simulated producer margin [s].
        underruns: Count of simulated producer underruns.
        measured_windows: Number of windows measured.
        qualification_elapsed_s: Wall-clock time spent to reach this result [s].
    Side Effects:
        None.
    Raises:
        None.
    Preconditions:
        `window_s > 0` and `compute_fraction_limit > 0`.
    """

    window_s: float
    passed: bool
    compute_fraction_limit: float
    prefill_windows: int
    max_window_s: float
    p99_window_s: float
    min_buffer_margin_s: float
    underruns: int
    measured_windows: int
    qualification_elapsed_s: float


class WindowedTrajectoryBuffer:
    """Shape trajectory windows into a FIFO buffer for controller consumption.

    Args:
        shaper: Persistent shaper instance used for all queued windows.
        raw_windows: Raw windows to shape or pass through in source order.
        prefill_windows: Number of shaped windows to produce before consumption.
        finalize_tail: Whether to append one delayed shaper tail window after
            all raw windows have been processed.
        enable_vibration_control: Whether shaping is enabled for shaped windows.
    Side Effects:
        Mutates `shaper` state as windows are filled.
    Raises:
        ValueError: If `prefill_windows < 0`.
    Preconditions:
        Raw windows are ordered by increasing source indices and use the same
        sample time as `shaper`.
    """

    def __init__(
        self,
        shaper: "ShaperInterface",
        raw_windows: list[TrajectoryWindow],
        prefill_windows: int,
        finalize_tail: bool,
        enable_vibration_control: bool,
        selected_window_s: float,
        qualification: WindowQualificationResult | None = None,
    ) -> None:
        """Initialize raw and shaped FIFO queues for windowed shaping.

        Args:
            shaper: Persistent shaper instance used for all queued windows.
            raw_windows: Raw windows to shape or pass through in source order.
            prefill_windows: Number of shaped windows to produce before consumption.
            finalize_tail: Whether to append one delayed shaper tail window.
            enable_vibration_control: Whether vibration control is active.
            selected_window_s: Window duration selected for this buffer [s].
            qualification: Automatic qualification result, if one was run.
        Returns:
            `None`.
        Side Effects:
            Stores references to `shaper` and copies raw window queue metadata.
        Raises:
            ValueError: If `prefill_windows < 0`.
        Preconditions:
            `raw_windows` are ordered by increasing source index.
        """

        if prefill_windows < 0:
            raise ValueError("prefill_windows must be non-negative")

        self._shaper = shaper
        self._raw_windows: deque[TrajectoryWindow] = deque(raw_windows)
        self._shaped_windows: deque[ShapedTrajectoryWindow] = deque()
        self._total_windows = len(raw_windows)
        self._prefill_windows = prefill_windows
        self._should_finalize_tail = finalize_tail and enable_vibration_control
        self._enable_vibration_control = enable_vibration_control
        self._selected_window_s = selected_window_s
        self._qualification = qualification
        self._tail_finalized = False
        self._tail_remaining_by_axis: list[int] | None = None
        self._consumed_windows = 0
        self._last_produced_window: ShapedTrajectoryWindow | None = None
        self._window_times: list[float] = []
        self._window_durations: list[float] = []
        self._startup_latency_s = 0.0
        self._window_samples = max(1, int(round(selected_window_s / shaper.Ts)))

    def prefill(self) -> int:
        """Fill the configured number of startup windows.

        Args:
            None.
        Returns:
            `int` number of shaped windows produced by this call.
        Side Effects:
            Mutates internal queues and shaper state.
        Raises:
            ValueError: If a queued window is malformed.
        Preconditions:
            The buffer has not been concurrently consumed or filled.
        """

        before = len(self._window_times)
        produced = self.fill_available(max_windows=self._prefill_windows)
        prefilled_times = self._window_times[before : before + produced]
        self._startup_latency_s = float(sum(prefilled_times))
        return produced

    def fill_available(self, max_windows: int | None = None) -> int:
        """Produce shaped windows from queued raw windows.

        Args:
            max_windows: Maximum number of raw windows to produce, or `None`
                to fill all remaining raw windows and the final tail.
        Returns:
            `int` number of shaped windows appended to the output buffer.
        Side Effects:
            Mutates raw/output queues and shaper state.
        Raises:
            ValueError: If `max_windows < 0` or a queued window is malformed.
        Preconditions:
            The buffer has not been concurrently consumed or filled.
        """

        if max_windows is not None and max_windows < 0:
            raise ValueError("max_windows must be non-negative")

        produced = 0
        while self._raw_windows and (max_windows is None or produced < max_windows):
            window = self._raw_windows.popleft()
            shaped_window = self._shape_or_pass_window(window)
            self._shaped_windows.append(shaped_window)
            self._last_produced_window = shaped_window
            self._window_times.append(shaped_window.compute_time_s)
            self._window_durations.append(window.command.shape[0] * self._shaper.Ts)
            produced += 1

        can_append_tail = max_windows is None or produced < max_windows
        while (
            can_append_tail
            and not self._raw_windows
            and self._should_finalize_tail
            and not self._tail_finalized
        ):
            tail_window = self.finalize_tail()
            if tail_window is not None:
                produced += 1
                can_append_tail = max_windows is None or produced < max_windows
            else:
                break

        return produced

    def pop_window(self) -> ShapedTrajectoryWindow | None:
        """Pop the next shaped window for controller consumption.

        Args:
            None.
        Returns:
            `ShapedTrajectoryWindow | None` next ready window, or `None` if the
            shaped output buffer is empty.
        Side Effects:
            Removes one shaped window and increments the consumed-window count.
        Raises:
            None.
        Preconditions:
            None.
        """

        if not self._shaped_windows:
            return None
        self._consumed_windows += 1
        return self._shaped_windows.popleft()

    def has_next(self) -> bool:
        """Return whether any raw or shaped window remains.

        Args:
            None.
        Returns:
            `bool` true if shaped data is ready or more raw windows can be filled.
        Side Effects:
            None.
        Raises:
            None.
        Preconditions:
            None.
        """

        tail_pending = self._should_finalize_tail and not self._tail_finalized
        return bool(self._shaped_windows or self._raw_windows or tail_pending)

    def finalize_tail(self) -> ShapedTrajectoryWindow | None:
        """Append the final delayed shaper tail as one shaped window.

        Args:
            None.
        Returns:
            `ShapedTrajectoryWindow | None` tail window if tail samples were
            produced, otherwise `None`.
        Side Effects:
            Mutates the shaped output queue and finalizes internal shaper state.
        Raises:
            None.
        Preconditions:
            All raw windows that should affect the tail have already been filled.
        """

        if self._tail_finalized:
            return None

        if not self._should_finalize_tail:
            self._tail_finalized = True
            return None

        last_window = self._last_ready_or_consumed_window()
        if last_window is None:
            self._tail_finalized = True
            return None

        if self._tail_remaining_by_axis is None:
            self._tail_remaining_by_axis = [shaper.M for shaper in self._shaper.shapers]
        remaining_samples = max(self._tail_remaining_by_axis, default=0)
        if remaining_samples <= 0:
            self._tail_finalized = True
            return None
        
        chunk_samples = min(self._window_samples, remaining_samples)

        begin = time.perf_counter()
        tail = self._shaper._shape_tail_chunk(
            last_position=last_window.positions[-1],
            last_time=float(last_window.time[-1]),
            start_index=last_window.stop_index,
            sample_count=chunk_samples,
            tail_remaining_by_axis=self._tail_remaining_by_axis,
        )
        compute_time_s = time.perf_counter() - begin
        if tail.positions.shape[0] == 0:
            self._tail_finalized = True
            return None
        
        emitted_samples = int(tail.positions.shape[0])
        self._tail_remaining_by_axis = [
            max(0, remaining - emitted_samples)
            for remaining in self._tail_remaining_by_axis
        ]
        self._tail_finalized = max(self._tail_remaining_by_axis, default=0) == 0

        tail_window = ShapedTrajectoryWindow(
            positions=tail.positions,
            velocities=tail.velocities,
            accelerations=tail.accelerations,
            time=tail.time,
            start_index=last_window.stop_index,
            stop_index=last_window.stop_index + emitted_samples,
            is_tail=True,
            compute_time_s=compute_time_s,
        )
        self._shaped_windows.append(tail_window)
        self._last_produced_window = tail_window
        self._window_times.append(compute_time_s)
        self._window_durations.append(tail.positions.shape[0] * self._shaper.Ts)
        return tail_window

    def _shape_or_pass_window(self, window: TrajectoryWindow) -> ShapedTrajectoryWindow:
        """Produce one output window from one queued raw window.

        Args:
            window: Raw trajectory window to shape or pass through.
        Returns:
            `ShapedTrajectoryWindow` output window with source indices.
        Side Effects:
            May mutate shaper state when `window.should_shape` is true.
        Raises:
            ValueError: If the shaper rejects the window inputs.
        Preconditions:
            `window` arrays share the same sample count.
        """

        begin = time.perf_counter()
        if window.should_shape:
            shaped = self._shaper.process_trajectory(
                command=window.command,
                command_dot=window.command_dot,
                command_ddot=window.command_ddot,
                time_vector=window.time.tolist(),
                enable_vibration_control=self._enable_vibration_control,
                finalize_tail=False,
                reset_on_discontinuity=False,
            )
        else:
            shaped = ShapedTrajectory(
                positions=window.command.copy(),
                velocities=window.command_dot.copy(),
                accelerations=window.command_ddot.copy(),
                time=window.time.copy(),
            )

        return ShapedTrajectoryWindow(
            positions=shaped.positions,
            velocities=shaped.velocities,
            accelerations=shaped.accelerations,
            time=shaped.time,
            start_index=window.start_index,
            stop_index=window.stop_index,
            is_tail=False,
            compute_time_s=time.perf_counter() - begin,
        )

    def _last_ready_or_consumed_window(self) -> ShapedTrajectoryWindow | None:
        """Return the latest produced window needed to anchor final tail timing.

        Args:
            None.
        Returns:
            `ShapedTrajectoryWindow | None` most recent available shaped window.
        Side Effects:
            None.
        Raises:
            None.
        Preconditions:
            Tail finalization is requested after raw windows are filled.
        """

        if self._shaped_windows:
            return self._shaped_windows[-1]
        return self._last_produced_window


def _percentile_or_none(values: list[float], percentile: float) -> float | None:
    """Compute a percentile when at least one value is available.

    Args:
        values: Numeric samples.
        percentile: Percentile in `[0, 100]`.
    Returns:
        `float | None` percentile value, or `None` when `values` is empty.
    Side Effects:
        None.
    Raises:
        ValueError: If NumPy rejects `percentile`.
    Preconditions:
        `percentile` is in `[0, 100]`.
    """

    if not values:
        return None
    return float(np.percentile(values, percentile))


def _import_torch_cpu_first() -> Any:
    """Import torch from the active environment before any system libtorch.

    Args:
        None.
    Returns:
        `module` torch module loaded from the active Python environment.
    Side Effects:
        May prepend to `LD_LIBRARY_PATH` in the current process.
    Raises:
        ImportError: If torch is not installed.
    Preconditions:
        None.
    """

    torch_lib_dir = (
        Path(sys.prefix)
        / "lib"
        / f"python{sys.version_info.major}.{sys.version_info.minor}"
        / "site-packages"
        / "torch"
        / "lib"
    )
    if torch_lib_dir.exists():
        ld_library_path = os.environ.get("LD_LIBRARY_PATH", "")
        if str(torch_lib_dir) not in ld_library_path.split(os.pathsep):
            os.environ["LD_LIBRARY_PATH"] = str(torch_lib_dir) + (
                os.pathsep + ld_library_path if ld_library_path else ""
            )

    import torch  # type: ignore

    return torch


torch = _import_torch_cpu_first()


def _gradient(samples: np.ndarray, sample_time: float) -> np.ndarray:
    """Compute first derivative of one 1D sample stream.

    Args:
        samples: Signal values `[N]`.
        sample_time: Sample period [s].
    Returns:
        `np.ndarray` derivative `[N]` in units per second.
    Side Effects:
        None.
    Raises:
        ValueError: If `sample_time <= 0`.
    Preconditions:
        `samples` is a one-dimensional numeric array.
    """

    if sample_time <= 0.0:
        raise ValueError("sample_time must be positive")

    n_samples = samples.size
    gradient = np.zeros_like(samples)

    if n_samples <= 1:
        return gradient
    if n_samples == 2:
        diff = (samples[1] - samples[0]) / sample_time
        gradient[:] = diff
        return gradient

    gradient[0] = (samples[1] - samples[0]) / sample_time
    for idx in range(1, n_samples - 1):
        gradient[idx] = (samples[idx + 1] - samples[idx - 1]) / (2.0 * sample_time)
    gradient[-1] = (samples[-1] - samples[-2]) / sample_time
    return gradient


class ShaperInterface:
    """Run map-based modal inference and apply per-axis input shaping.

    Args:
        sample_time: Controller sample period [s].
        model_directory: Directory containing per-axis map models.
        urdf_filepath: URDF file used by dynamics calculations.
        num_axes: Number of axes that are shaped.
        side_length: Kinematic side-length parameter [m].
        base_height: Kinematic base-height parameter [m].
        num_joints: Number of robot joints.
        prob_thresh: Probability threshold for selecting two-mode shaping.
        shared_impulse_policy: Policy for reusing or combining impulse trains
            across shaped axes.
        lifted_shaper_core: Implementation used for shared lifted trajectory
            shaping. Valid values are `python`, `native`, and `auto`.
        shared_impulse_shapes_all_joints: Whether non-`per_axis` policies apply
            the selected shared impulse to every joint command instead of only
            the model-backed axes.
    Side Effects:
        Loads model files, the optional native shaper module, and URDF dynamics
        model into memory.
    Raises:
        ValueError: If scalar constructor inputs are out of range.
        FileNotFoundError: If model files or URDF are missing.
        ImportError: If `lifted_shaper_core="native"` and the native shaper
            module is unavailable.
    Preconditions:
        `model_directory` contains model files matching configured axes. If
        `shared_impulse_shapes_all_joints` is true, `shared_impulse_policy` is
        not `per_axis`.
    """

    def __init__(
        self,
        sample_time: float,
        model_directory: str,
        urdf_filepath: str,
        num_axes: int = ROBOT_NUM_SHAPED_AXES,
        side_length: float = ROBOT_SIDE_LENGTH,
        base_height: float = ROBOT_BASE_HEIGHT,
        num_joints: int = ROBOT_NUM_JOINTS,
        prob_thresh: float = DEFAULT_PROB_THRESH,
        shared_impulse_policy: str = DEFAULT_SHARED_IMPULSE_POLICY,
        lifted_shaper_core: str = DEFAULT_LIFTED_SHAPER_CORE,
        shared_impulse_shapes_all_joints: bool = True,
    ) -> None:
        """Initialize model inference and per-axis shapers.

        Args:
            sample_time: Controller sample period [s].
            model_directory: Directory containing `axis*_model.pt` files.
            urdf_filepath: URDF path for robot dynamics.
            num_axes: Number of shaped axes.
            side_length: Side-length geometry parameter [m].
            base_height: Base-height geometry parameter [m].
            num_joints: Number of robot joints.
            prob_thresh: Threshold for two-mode shaper selection.
            shared_impulse_policy: Policy for selecting one impulse train to apply
                to shaped axes.
            lifted_shaper_core: Implementation used for shared lifted trajectory
                shaping: `python`, `native`, or `auto`.
            shared_impulse_shapes_all_joints: Whether shared-impulse trajectory
                paths shape all `num_joints` command columns using the same
                impulse selected from the model-backed axes.
        Returns:
            `None`.
        Side Effects:
            Loads model/dynamics resources.
        Raises:
            ValueError: If dimensions or sample time are invalid.
            ImportError: If `lifted_shaper_core="native"` and the native shaper
                module is unavailable.
        Preconditions:
            `urdf_filepath` and model files exist and are readable. If
            `shared_impulse_shapes_all_joints` is true, the policy is shared
            rather than `per_axis`.
        """

        if sample_time <= 0.0:
            raise ValueError("Sample time must be positive")
        if num_joints <= 0:
            raise ValueError("Number of joints must be positive")
        if num_axes <= 0 or num_axes > num_joints:
            raise ValueError("Number of shaped axes must be in (0, num_joints]")
        if shared_impulse_policy not in SHARED_IMPULSE_POLICIES:
            raise ValueError(
                "shared_impulse_policy must be one of "
                f"{sorted(SHARED_IMPULSE_POLICIES)}"
            )
        if lifted_shaper_core not in LIFTED_SHAPER_CORES:
            raise ValueError(
                "lifted_shaper_core must be one of " f"{sorted(LIFTED_SHAPER_CORES)}"
            )
        if shared_impulse_shapes_all_joints and shared_impulse_policy == "per_axis":
            raise ValueError(
                "shared_impulse_shapes_all_joints requires a non-per_axis policy"
            )

        self.Ts = sample_time
        self.num_axes = num_axes
        self.num_joints = num_joints
        self.side_length = side_length
        self.base_height = base_height
        self.prob_thresh = prob_thresh
        self.shared_impulse_policy = shared_impulse_policy
        self.lifted_shaper_core = lifted_shaper_core
        self.shared_impulse_shapes_all_joints = shared_impulse_shapes_all_joints
        self.num_shaped_joints = (
            self.num_joints if shared_impulse_shapes_all_joints else self.num_axes
        )
        self._native_base_shaper: Any | None = None
        self._native_lifted_unavailable_logged = False  ##
        self.native_profile_seconds: dict[str, float] = {  ##
            "calls": 0.0,
            "impulse": 0.0,
            "schedule": 0.0,
            "tap": 0.0,
            "history": 0.0,
            "finalize": 0.0,
        }
        self.model_directory = model_directory
        self.store_buffer: list[list[int]] = [[] for _ in range(self.num_shaped_joints)]

        self._torch = torch
        self.robot_dynamics = Dynamics(urdf_file=urdf_filepath, initialize=True)
        self.map_fitter = ModelLoader.load(model_directory, num_axes, 3, [64, 64])

        self.shapers = [BaseShaper(self.Ts) for _ in range(self.num_shaped_joints)]
        self.last_input_position: np.ndarray | None = None
        self.last_input_velocity: np.ndarray | None = None
        self.last_input_acceleration: np.ndarray | None = None
        self._last_valid_axis_params: list[np.ndarray | None] = [None] * self.num_axes
        self._last_valid_shared_params: np.ndarray | None = None
        self._invalid_modal_param_warning_count = 0
        self._logged_once: list[bool] = [False] * max(1, self.num_shaped_joints)
        self._last_vibration_control_enabled: bool | None = None

        if self.lifted_shaper_core in {"native", "auto"}:
            self._native_base_shaper = self._load_native_lifted_core(required=False)
            if self.lifted_shaper_core == "native" and self._native_base_shaper is None:
                raise ImportError("native base_shaper module is not available")

    def reset(self) -> None:
        """Reset internal shaper states and stream continuity markers.

        Args:
            None.
        Returns:
            `None`.
        Side Effects:
            Replaces per-axis shaper objects and clears stream cache.
        Raises:
            None.
        Preconditions:
            None.
        """

        self.shapers = [BaseShaper(self.Ts) for _ in range(self.num_shaped_joints)]
        self.last_input_position = None
        self.last_input_velocity = None
        self.last_input_acceleration = None

    def _reset_native_profile_seconds(self) -> None:
        """Clear accumulated native lifted-shaper profiling counters.

        Args:
            None.
        Returns:
            `None`.
        Side Effects:
            Mutates `self.native_profile_seconds`.
        Raises:
            None.
        Preconditions:
            `self.native_profile_seconds` has the standard profile-key layout.
        """

        profile = getattr(self, "native_profile_seconds", None)
        if profile is None:
            return
        for key in profile:
            profile[key] = 0.0

    def _handle_vibration_mode_transition(self, enable_vibration_control: bool) -> bool:
        """Reset stale shaper history on `disabled -> enabled` transitions.

        Args:
            enable_vibration_control: Requested mode for the next processing call.
        Returns:
            `bool` true if this call triggered an internal reset.
        Side Effects:
            May reset shaper state and updates mode-tracking metadata.
        Raises:
            None.
        Preconditions:
            None.
        """

        toggled_disabled_to_enabled = (
            enable_vibration_control and self._last_vibration_control_enabled is False
        )
        if toggled_disabled_to_enabled:
            # While pass-through mode is active we do not advance shaper buffers.
            # Reset before re-enabling to avoid shaping against stale history.
            self.reset()
        self._last_vibration_control_enabled = enable_vibration_control
        return toggled_disabled_to_enabled

    def compute_forward_kinematics(self, joint_angles: np.ndarray) -> np.ndarray:
        """Compute TCP position from joint angles.

        Args:
            joint_angles: Joint angles `[num_joints]` in radians.
        Returns:
            `np.ndarray` TCP position `[x, y, z]` in meters.
        Side Effects:
            None.
        Raises:
            RuntimeError: If dynamics backend forward kinematics fails.
        Preconditions:
            `joint_angles` matches model joint count.
        """

        position, _ = self.robot_dynamics.get_forward_kinematics(joint_angles)
        return np.asarray(position)

    def compute_inertia(self, joint_angles: np.ndarray) -> np.ndarray:
        """Compute diagonal joint inertia terms from mass matrix.

        Args:
            joint_angles: Joint angles `[num_joints]` in radians.
        Returns:
            `np.ndarray` diagonal inertia terms `[num_joints]`.
        Side Effects:
            None.
        Raises:
            RuntimeError: If dynamics backend mass matrix calculation fails.
        Preconditions:
            `joint_angles` matches model joint count.
        """

        mass_matrix = self.robot_dynamics.get_mass_matrix(joint_angles)
        return np.asarray(np.diag(mass_matrix))

    def cartesian_to_polar(self, xyz: np.ndarray) -> tuple[float, float]:
        """Convert Cartesian TCP position into `(v, r)` map features.

        Args:
            xyz: Cartesian TCP coordinates `[x, y, z]` in meters.
        Returns:
            `tuple[float, float]` as `(v, r)` where `v` is angle [rad] and `r` is radius [m].
        Side Effects:
            None.
        Raises:
            ValueError: If `xyz` is not a 3-vector.
        Preconditions:
            `xyz` is finite.
        """

        xyz = np.asarray(xyz, dtype=float)
        if xyz.shape != (3,):
            raise ValueError("xyz must have shape (3,)")

        # `compute_nn_inputs()` first rotates the TCP position into the zero-base
        # frame, so the map features should use fixed coordinates in that frame:
        # x -> long, y -> width, z -> height. Choosing axes sample-by-sample
        # creates branch discontinuities when component magnitudes cross.
        long_axis_value = float(xyz[0])
        width_value = float(xyz[1])
        height_value = float(xyz[2])

        dx = math.sqrt(
            long_axis_value * long_axis_value + (self.side_length - width_value) ** 2
        )
        dz = height_value - self.base_height
        radius = math.hypot(dx, dz)
        angle = math.atan2(dz, dx)
        return angle, radius

    def _finite_difference_axes(self, samples: np.ndarray) -> np.ndarray:
        """Compute per-axis finite differences for an `(N, D)` sample matrix.

        Args:
            samples: Input samples shaped `(N, D)`.
        Returns:
            `np.ndarray` finite differences shaped `(N, D)`.
        Side Effects:
            None.
        Raises:
            ValueError: If `samples` is not 2D.
        Preconditions:
            `samples` is numeric and finite.
        """

        if samples.ndim != 2:
            raise ValueError("samples must be a 2D array")

        _, num_cols = samples.shape
        diff = np.zeros_like(samples)
        for col in range(num_cols):
            diff[:, col] = _gradient(samples[:, col], self.Ts)
        return diff

    def finite_difference_first(self, samples: np.ndarray) -> np.ndarray:
        """Compute first derivative for each trajectory axis.

        Args:
            samples: Position samples `[N, D]`.
        Returns:
            `np.ndarray` velocity samples `[N, D]`.
        Side Effects:
            None.
        Raises:
            ValueError: If `samples` is not 2D.
        Preconditions:
            `self.Ts > 0`.
        """

        return self._finite_difference_axes(samples)

    def finite_difference_second(self, first: np.ndarray) -> np.ndarray:
        """Compute second derivative for each trajectory axis.

        Args:
            first: Velocity samples `[N, D]`.
        Returns:
            `np.ndarray` acceleration samples `[N, D]`.
        Side Effects:
            None.
        Raises:
            ValueError: If `first` is not 2D.
        Preconditions:
            `self.Ts > 0`.
        """

        return self._finite_difference_axes(first)

    def _generate_states(self, command: np.ndarray) -> list[RobotState]:
        """Build one robot state per trajectory command sample.

        Args:
            command: Command trajectory `[N, num_joints]` in radians.
        Returns:
            `list[RobotState]` containing copied joint-angle vectors, one per
            command sample.
        Side Effects:
            None.
        Raises:
            ValueError: If `command` is not shaped `[N, num_joints]`.
        Preconditions:
            `command` is numeric and ordered by controller sample time.
        """

        command = np.asarray(command, dtype=float)
        if command.ndim != 2 or command.shape[1] != self.num_joints:
            raise ValueError("command must be (N, num_joints)")
        return [
            RobotState(joint_angles=np.array(command_sample, copy=True))
            for command_sample in command
        ]

    def _rotate_xyz_to_zero_base(
        self, joint_angles: np.ndarray, xyz: np.ndarray
    ) -> tuple[np.ndarray, bool]:
        """Rotate TCP position into a base-zero frame.

        Args:
            joint_angles: Joint angles `[num_joints]` in radians.
            xyz: TCP coordinates `[x, y, z]` in meters.
        Returns:
            `tuple[np.ndarray, bool]` with rotated vector and fallback-used flag.
        Side Effects:
            None.
        Raises:
            None.
        Preconditions:
            `xyz` is shape `(3,)`.
        """

        if joint_angles.size == 0:
            return xyz, False

        try:
            current_rot = self.robot_dynamics.get_individual_rotation_matrix(
                0, joint_angles
            )
            joint_angles_zero = np.asarray(joint_angles, dtype=float).copy()
            joint_angles_zero[0] = 0.0
            zero_rot = self.robot_dynamics.get_individual_rotation_matrix(
                0, joint_angles_zero
            )
            base_rotation = current_rot @ zero_rot.T
            rotated = base_rotation.T @ xyz
            return rotated, False
        except Exception:
            # Developer: Codex (2026-02-10)
            # Keep a deterministic fallback so calibration can proceed when detailed
            # per-link rotation matrices are unavailable from the dynamics backend.
            base_angle = float(joint_angles[0])
            c = math.cos(-base_angle)
            s = math.sin(-base_angle)
            rot = np.array([[c, -s, 0.0], [s, c, 0.0], [0.0, 0.0, 1.0]], dtype=float)
            return rot @ xyz, True

    def compute_nn_inputs(self, state: RobotState) -> tuple[float, float, np.ndarray]:
        """Build map-network inputs from current robot state.

        Args:
            state: Current robot state.
        Returns:
            `tuple[float, float, np.ndarray]` as `(v_rad, r_m, inertia_vector)`.
        Side Effects:
            Prints one warning line when fallback base-rotation logic is used.
        Raises:
            RuntimeError: If dynamics calls fail and no fallback path can recover.
        Preconditions:
            `state.joint_angles` matches configured `num_joints`.
        """

        inertia = self.compute_inertia(state.joint_angles)
        xyz = (
            state.tcp_position
            if state.tcp_position is not None
            else self.compute_forward_kinematics(state.joint_angles)
        )

        rotated_xyz, used_fallback = self._rotate_xyz_to_zero_base(
            state.joint_angles,
            np.asarray(xyz, dtype=float),
        )
        if used_fallback:
            print(
                "Warning: Robot dynamics model returned no joint rotations; "
                "falling back to Z-axis base rotation assumption."
            )

        v_rad, r_m = self.cartesian_to_polar(rotated_xyz)
        return v_rad, r_m, inertia

    def _axis_params_from_model_outputs(
        self,
        order_probs: np.ndarray,
        mode_params: np.ndarray,
    ) -> list[np.ndarray]:
        """Convert model output rows into physically valid modal parameters.

        Args:
            order_probs: Per-axis probability of using the second mode.
            mode_params: Per-axis network outputs `[wn1, log_z1, wn2, log_z2]`.
        Returns:
            `list[np.ndarray]` modal parameter arrays with rows `[wn rad/s, zeta]`.
        Side Effects:
            Updates the last valid modal parameters used for invalid-output fallback.
        Raises:
            None.
        Preconditions:
            `order_probs` and `mode_params` contain rows for every configured axis.
        """

        axis_params: list[np.ndarray] = []
        for axis in range(self.num_axes):
            prob_second = float(order_probs[axis])
            wn1 = float(mode_params[axis, 0])
            z1 = self._safe_exp(float(mode_params[axis, 1]))
            wn2 = float(mode_params[axis, 2])
            z2 = self._safe_exp(float(mode_params[axis, 3]))
            if prob_second > self.prob_thresh:
                proposed = np.array([[wn1, z1], [wn2, z2]], dtype=float)
            else:
                proposed = np.array([[wn1, z1]], dtype=float)
            axis_params.append(self._validated_axis_params(axis, proposed))
        return axis_params
    
    def _safe_exp(self, value: float) -> float:
        """Return `exp(value)` or infinity when the exponent overflows.

        Args:
            value: Exponent value.
        Returns:
            `float` exponential result.
        Side Effects:
            None.
        Raises:
            None.
        Preconditions:
            None.
        """
        try:
            return math.exp(value)
        except OverflowError:
            return math.inf
        
    def _validated_axis_params(
        self,
        axis: int,
        proposed_params: np.ndarray,
    ) -> np.ndarray:
        """Return valid modal parameters, reusing the previous valid value when needed.

        Args:
            axis: Model axis index.
            proposed_params: Candidate modal rows `[wn rad/s, zeta]`.
        Returns:
            `np.ndarray` valid modal rows for the axis.
        Side Effects:
            Mutates `_last_valid_axis_params` when a valid or bounded fallback
            value is selected.
        Raises:
            None.
        Preconditions:
            `0 <= axis < num_axes`.
        """
        if not hasattr(self, "_last_valid_axis_params"):
            self._last_valid_axis_params = [None] * self.num_axes

        if self._modal_params_are_valid(proposed_params):
            valid_params = proposed_params.copy()
            self._last_valid_axis_params[axis] = valid_params
            return valid_params

        previous_params = self._last_valid_axis_params[axis]
        if previous_params is not None:
            self._print_modal_param_fallback_warning(
                axis=axis,
                proposed_params=proposed_params,
                fallback_params=previous_params,
                fallback_reason="reusing the most recent valid shaper parameters",
            )
            return previous_params.copy()

        bounded_params = self._bounded_initial_axis_params(proposed_params)
        self._print_modal_param_fallback_warning(
            axis=axis,
            proposed_params=proposed_params,
            fallback_params=bounded_params,
            fallback_reason="using bounded initial fallback parameters",
        )
        self._last_valid_axis_params[axis] = bounded_params
        return bounded_params

    def _print_modal_param_fallback_warning(
        self,
        axis: int,
        proposed_params: np.ndarray,
        fallback_params: np.ndarray,
        fallback_reason: str,
    ) -> None:
        """Print a warning when invalid modal parameters trigger fallback.

        Args:
            axis: Model axis index.
            proposed_params: Invalid modal rows `[wn rad/s, zeta]`.
            fallback_params: Modal rows used instead of `proposed_params`.
            fallback_reason: Human-readable fallback action.
        Returns:
            `None`.
        Side Effects:
            Prints a warning and increments `_invalid_modal_param_warning_count`.
        Raises:
            None.
        Preconditions:
            None.
        """
        if not hasattr(self, "_invalid_modal_param_warning_count"):
            self._invalid_modal_param_warning_count = 0

        self._invalid_modal_param_warning_count += 1
        invalid_details = self._invalid_modal_param_details(proposed_params)
        print(
            "[ShaperInterfacePy] Warning: invalid modal parameters on "
            f"axis {axis}; {invalid_details}. "
            f"Fallback: {fallback_reason}. "
            f"Fallback params={np.asarray(fallback_params, dtype=float).tolist()}"
        )

    def _invalid_modal_param_details(self, params: np.ndarray) -> str:
        """Describe which modal parameter bounds were violated.

        Args:
            params: Candidate modal rows `[wn rad/s, zeta]`.
        Returns:
            `str` detailed invalid-parameter description.
        Side Effects:
            None.
        Raises:
            None.
        Preconditions:
            None.
        """
        params = np.asarray(params, dtype=float)
        if params.ndim != 2 or params.shape[1] != 2 or params.shape[0] == 0:
            return f"expected non-empty shape (m, 2), got shape {params.shape}"

        invalid_rows = []
        for row_index, (wn_rad_per_s, damping_ratio) in enumerate(params):
            violations = []
            if not np.isfinite(wn_rad_per_s):
                violations.append("wn is not finite")
            elif wn_rad_per_s <= 0.0:
                violations.append("wn must be > 0 rad/s")
            if not np.isfinite(damping_ratio):
                violations.append("zeta is not finite")
            elif not (0.0 < damping_ratio < 1.0):
                violations.append("zeta must satisfy 0 < zeta < 1")

            if violations:
                invalid_rows.append(
                    f"row {row_index}: wn={wn_rad_per_s}, "
                    f"zeta={damping_ratio}, violations={violations}"
                )

        if not invalid_rows:
            return f"params={params.tolist()} failed validation"
        return "; ".join(invalid_rows)

    def _modal_params_are_valid(self, params: np.ndarray) -> bool:
        """Return whether modal rows satisfy shaper parameter bounds.

        Args:
            params: Modal rows `[wn rad/s, zeta]`.
        Returns:
            `bool` true when every row is finite with `wn > 0` and `0 < zeta < 1`.
        Side Effects:
            None.
        Raises:
            None.
        Preconditions:
            None.
        """
        params = np.asarray(params, dtype=float)
        if params.ndim != 2 or params.shape[1] != 2 or params.shape[0] == 0:
            return False
        wn = params[:, 0]
        zeta = params[:, 1]
        return bool(
            np.all(np.isfinite(params))
            and np.all(wn > 0.0)
            and np.all((zeta > 0.0) & (zeta < 1.0))
        )

    def _bounded_initial_axis_params(self, proposed_params: np.ndarray) -> np.ndarray:
        """Create a valid first-use fallback from invalid modal parameters.

        Args:
            proposed_params: Candidate modal rows `[wn rad/s, zeta]`.
        Returns:
            `np.ndarray` modal rows with finite values inside shaper bounds.
        Side Effects:
            None.
        Raises:
            None.
        Preconditions:
            None.
        """
        params = np.asarray(proposed_params, dtype=float)
        if params.ndim != 2 or params.shape[1] != 2 or params.shape[0] == 0:
            params = np.array(
                [[FALLBACK_NATURAL_FREQUENCY_RAD_PER_S, FALLBACK_DAMPING_RATIO]],
                dtype=float,
            )
        bounded = params.copy()
        bounded[:, 0] = np.where(
            np.isfinite(bounded[:, 0]) & (bounded[:, 0] > 0.0),
            bounded[:, 0],
            FALLBACK_NATURAL_FREQUENCY_RAD_PER_S,
        )
        bounded[:, 1] = np.where(
            np.isfinite(bounded[:, 1]),
            bounded[:, 1],
            FALLBACK_DAMPING_RATIO,
        )
        bounded[:, 0] = np.maximum(
            bounded[:, 0],
            MIN_VALID_NATURAL_FREQUENCY_RAD_PER_S,
        )
        bounded[:, 1] = np.clip(
            bounded[:, 1],
            MIN_VALID_DAMPING_RATIO,
            MAX_VALID_DAMPING_RATIO,
        )
        return bounded

    def _shared_params_for_axes(
        self,
        axis_params: list[np.ndarray],
    ) -> list[np.ndarray]:
        """Return the modal params actually applied to each shaped axis."""
        if len(axis_params) != self.num_axes:
            raise ValueError("axis_params length must match num_axes")

        if self.shared_impulse_policy == "per_axis":
            return axis_params
        if self.shared_impulse_policy == "axis0":
            shared = axis_params[0]
        elif self.shared_impulse_policy == "max_delay_axis":
            shared = max(
                axis_params,
                key=lambda params: self.shapers[0].compute_zvd_shaper(params)[1],
            )
        elif self.shared_impulse_policy == "combine_all_modes":
            shared = np.vstack(axis_params)
        else:
            raise ValueError(
                "shared_impulse_policy must be one of "
                f"{sorted(SHARED_IMPULSE_POLICIES)}"
            )

        self._last_valid_shared_params = shared.copy()
        return [shared] * self.num_axes

    def _log_axis_inference_once(
        self,
        axis: int,
        prob_second: float,
        params: np.ndarray,
    ) -> None:
        """Print the first inference summary for one model-backed axis.

        Args:
            axis: Model-backed axis index.
            prob_second: Predicted second-mode probability [unitless].
            params: Valid modal parameters shaped `(m, 2)` as `[wn, zeta]`
                rows.
        Returns:
            `None`.
        Side Effects:
            Prints to stdout and marks `axis` as logged.
        Raises:
            None.
        Preconditions:
            `0 <= axis < len(self._logged_once)`.
        """

        if self._logged_once[axis]:
            return
        if params.shape[0] == 0:
            print(
                f"[ShaperInterfacePy] Axis {axis} inference: "
                f"no valid modes prob_second={prob_second}"
            )
        else:
            print(
                f"[ShaperInterfacePy] Axis {axis} inference: "
                f"wn1={params[0, 0]} z1={params[0, 1]} "
                f"prob_second={prob_second}"
            )
            if params.shape[0] > 1:
                print(
                    f"[ShaperInterfacePy] Axis {axis} second mode "
                    f"wn2={params[1, 0]} z2={params[1, 1]}"
                )
        self._logged_once[axis] = True

    def _load_native_lifted_core(self, *, required: bool) -> Any | None:
        """Load the optional native implementation for lifted shared-axis shaping.
        Args:
            required: Whether missing native support should be raised instead
                of converted to `None`.
        Returns:
            Native shaper module if it exposes `shape_shared_axes_lifted`,
            otherwise `None`.
        Side Effects:
            Imports a packaged or top-level `base_shaper` Python extension
            module if available.
        Raises:
            ImportError: If `required` is true and the module or required
                function is unavailable.
            Exception: If `required` is true and importing the extension fails
                for another reason, such as a dynamic-library load error.
        Preconditions:
            The active Python environment is allowed to import extension modules.
        """
        module_names = ("base_shaper", "reforge_core.control.base_shaper")
        last_error: Exception | None = None
        for module_name in module_names:
            try:
                module = importlib.import_module(module_name)
            except Exception as exc:
                last_error = exc
                continue

            if hasattr(module, "shape_shared_axes_lifted"):
                return module
            last_error = ImportError(
                f"{module_name}.shape_shared_axes_lifted is unavailable"
            )

        if required:
            if last_error is not None:
                raise last_error
            raise ImportError("native base_shaper module is not available")
        return None

    def _shape_shared_axes_lifted_native(
        self,
        command: np.ndarray,
        shared_params_sequence: list[np.ndarray],
        out_pos: np.ndarray,
        out_vel: np.ndarray,
        out_acc: np.ndarray,
    ) -> bool:
        """Shape one command block using the native lifted shaper when available.
        Args:
            command: Raw command trajectory `[N, num_joints]` in radians.
            shared_params_sequence: Modal parameters length `N`, each element
                shaped `(m_i, 2)` with `[wn, zeta]` rows.
            out_pos: Output position buffer `[N, num_joints]` in radians.
            out_vel: Output velocity buffer `[N, num_joints]` in radians/s.
            out_acc: Output acceleration buffer `[N, num_joints]` in
                radians/s^2.
        Returns:
            `bool` true when the native core produced outputs, false when the
            caller should use the Python fallback.
        Side Effects:
            Mutates `out_pos`, `out_vel`, `out_acc`, `self.shapers`, and
            `self.store_buffer` when native shaping succeeds. May print one
            warning when `lifted_shaper_core="auto"` falls back to Python.
        Raises:
            ValueError: If shared-axis shaper states are misaligned.
            ImportError: If `lifted_shaper_core="native"` and native support is
                unavailable.
            Exception: If `lifted_shaper_core="native"` and importing the native
                extension fails for a non-import reason.
        Preconditions:
            `command`, `out_pos`, `out_vel`, and `out_acc` share the same sample
            count, and `shared_params_sequence` has one entry per sample.
            `self.shapers` contains one state object for each shaped joint.
        """
        if self.lifted_shaper_core == "python":
            return False

        native = self._native_base_shaper
        if native is None:
            native = self._load_native_lifted_core(
                required=self.lifted_shaper_core == "native"
            )
            self._native_base_shaper = native
        if native is None:
            if (
                self.lifted_shaper_core == "auto"
                and not self._native_lifted_unavailable_logged
            ):
                print(
                    "[ShaperInterfacePy] Native lifted shaper unavailable; "
                    "using Python implementation."
                )
                self._native_lifted_unavailable_logged = True
            return False

        shaped_joints = self.num_shaped_joints
        template = self.shapers[0]
        initial_len = int(template._x_buf.size)
        initial_input_history = np.zeros((initial_len, shaped_joints), dtype=float)
        initial_y_history = np.column_stack(
            [
                np.asarray(list(self.shapers[axis]._y_buf), dtype=float)
                for axis in range(shaped_joints)
            ]
        )
        initial_v_history = np.column_stack(
            [
                np.asarray(list(self.shapers[axis]._v_buf), dtype=float)
                for axis in range(shaped_joints)
            ]
        )
        initial_a_history = np.column_stack(
            [
                np.asarray(list(self.shapers[axis]._a_buf), dtype=float)
                for axis in range(shaped_joints)
            ]
        )

        for axis in range(shaped_joints):
            shaper = self.shapers[axis]
            if shaper.M != template.M or int(shaper._x_buf.size) != initial_len:
                raise ValueError("shared-axis shaper states are not aligned")
            initial_input_history[:, axis] = shaper._x_buf

        native_result = native.shape_shared_axes_lifted(
            np.ascontiguousarray(command[:, :shaped_joints], dtype=float),
            shared_params_sequence,
            initial_input_history,
            initial_y_history,
            initial_v_history,
            initial_a_history,
            int(template.M),
            bool(template._buffers_seeded),
            float(self.Ts),
        )

        out_pos[:, :shaped_joints] = np.asarray(native_result["positions"], dtype=float)
        out_vel[:, :shaped_joints] = np.asarray(
            native_result["velocities"], dtype=float
        )
        out_acc[:, :shaped_joints] = np.asarray(
            native_result["accelerations"],
            dtype=float,
        )

        final_input_history = np.asarray(
            native_result["final_input_history"],
            dtype=float,
        )
        final_y_history = np.asarray(native_result["final_y_history"], dtype=float)
        final_v_history = np.asarray(native_result["final_v_history"], dtype=float)
        final_a_history = np.asarray(native_result["final_a_history"], dtype=float)
        final_impulse = np.asarray(native_result["final_impulse"], dtype=float)
        final_M = int(native_result["final_M"])
        buffers_seeded = bool(native_result["buffers_seeded"])
        M_sequence = np.asarray(native_result["M_sequence"], dtype=int)
        self.native_profile_seconds["calls"] += 1.0
        self.native_profile_seconds["impulse"] += float(
            native_result.get("profile_impulse_seconds", 0.0)
        )
        self.native_profile_seconds["schedule"] += float(
            native_result.get("profile_schedule_seconds", 0.0)
        )
        self.native_profile_seconds["tap"] += float(
            native_result.get("profile_tap_seconds", 0.0)
        )
        self.native_profile_seconds["history"] += float(
            native_result.get("profile_history_seconds", 0.0)
        )
        self.native_profile_seconds["finalize"] += float(
            native_result.get("profile_finalize_seconds", 0.0)
        )

        for axis in range(shaped_joints):
            shaper = self.shapers[axis]
            shaper._x_buf = final_input_history[:, axis].copy()
            shaper._x_head = 0
            shaper._y_buf = deque(
                final_y_history[:, axis].tolist(),
                maxlen=final_y_history.shape[0],
            )
            shaper._v_buf = deque(
                final_v_history[:, axis].tolist(),
                maxlen=final_v_history.shape[0],
            )
            shaper._a_buf = deque(
                final_a_history[:, axis].tolist(),
                maxlen=final_a_history.shape[0],
            )
            shaper.M = final_M
            shaper.impulse = final_impulse.copy()
            shaper._buffers_seeded = buffers_seeded
            self.store_buffer[axis].extend((M_sequence + 1).tolist())

        return True

    def _shape_shared_axes_lifted(
        self,
        command: np.ndarray,
        shared_params_sequence: list[np.ndarray],
        out_pos: np.ndarray,
        out_vel: np.ndarray,
        out_acc: np.ndarray,
    ) -> None:
        """Shape configured outputs with one shared lifted impulse system.
        Args:
            command: Raw command trajectory `[N, num_joints]` in radians.
            shared_params_sequence: Shared modal parameters length `N`, each
                element shaped `(m_i, 2)` with `[wn, zeta]` rows.
            out_pos: Output position buffer `[N, num_joints]` in radians.
            out_vel: Output velocity buffer `[N, num_joints]` in radians/s.
            out_acc: Output acceleration buffer `[N, num_joints]` in
                radians/s^2.
        Returns:
            `None`.
        Side Effects:
            Mutates output buffers, per-axis shaper histories, and
            `self.store_buffer`.
        Raises:
            ValueError: If `shared_params_sequence` length differs from `N` or
                shared-axis shaper states are misaligned.
            ImportError: If `lifted_shaper_core="native"` and native support is
                unavailable.
        Preconditions:
            `out_pos`, `out_vel`, and `out_acc` have the same row count as
            `command`, and all shaped joints use the same shaper state length.
        """
        samples = command.shape[0]
        if samples == 0:
            return
        if len(shared_params_sequence) != samples:
            raise ValueError("shared_params_sequence length must match samples")

        shaped_joints = self.num_shaped_joints
        template = self.shapers[0]
        if self._shape_shared_axes_lifted_native(
            command,
            shared_params_sequence,
            out_pos,
            out_vel,
            out_acc,
        ):
            return

        initial_len = int(template._x_buf.size)
        initial_history = np.zeros((initial_len, shaped_joints), dtype=float)
        for axis in range(shaped_joints):
            shaper = self.shapers[axis]
            if shaper.M != template.M or int(shaper._x_buf.size) != initial_len:
                raise ValueError("shared-axis shaper states are not aligned")
            initial_history[:, axis] = shaper._x_buf

        x_ext = np.vstack([initial_history, command[:, :shaped_joints]])
        symbolic_buf = np.arange(initial_len, dtype=int)
        current_M = template.M
        final_impulse = template.impulse
        final_M = current_M
        M_sequence = np.zeros(samples, dtype=int)
        impulse_sequence: list[np.ndarray] = []
        source_index_sequence: list[np.ndarray] = []
        input_buffers_seeded = template._buffers_seeded
        max_impulse_len = 0

        for sample_index, params in enumerate(shared_params_sequence):
            impulse, M_new = template.compute_zvd_shaper(params)
            if M_new != current_M:
                new_len = M_new + 1
                resized = np.empty(new_len, dtype=int)
                copy_len = min(symbolic_buf.size, new_len)
                resized[:copy_len] = symbolic_buf[:copy_len]
                tail = resized[copy_len - 1] if copy_len > 0 else 0
                if copy_len < new_len:
                    resized[copy_len:] = tail
                symbolic_buf = resized
                current_M = M_new

            if not input_buffers_seeded:
                symbolic_buf[:] = initial_len + sample_index
                input_buffers_seeded = True
            elif symbolic_buf.size > 0:
                symbolic_buf[1:] = symbolic_buf[:-1]
                symbolic_buf[0] = initial_len + sample_index

            final_impulse = impulse
            final_M = M_new
            M_sequence[sample_index] = M_new
            impulse_sequence.append(impulse)
            source_index_sequence.append(symbolic_buf.copy())
            max_impulse_len = max(max_impulse_len, impulse.size)

        impulse_matrix = np.zeros((samples, max_impulse_len), dtype=float)
        source_index_matrix = np.zeros((samples, max_impulse_len), dtype=int)
        for sample_index, impulse in enumerate(impulse_sequence):
            impulse_len = impulse.size
            impulse_matrix[sample_index, :impulse_len] = impulse
            source_index_matrix[sample_index, :impulse_len] = source_index_sequence[
                sample_index
            ][:impulse_len]

        shaped = np.zeros((samples, shaped_joints), dtype=float)
        for tap in range(max_impulse_len):
            shaped += (
                impulse_matrix[:, tap : tap + 1] * x_ext[source_index_matrix[:, tap], :]
            )
        out_pos[:, :shaped_joints] = shaped

        for axis in range(shaped_joints):
            shaper = self.shapers[axis]
            for sample_index in range(samples):
                M_i = int(M_sequence[sample_index])
                shaper._ensure_output_history_size_on_change(
                    M_i,
                    seed=float(command[sample_index, axis]),
                )
                y, v, a = shaper._update_output_history(
                    float(shaped[sample_index, axis])
                )
                out_pos[sample_index, axis] = y
                out_vel[sample_index, axis] = v
                out_acc[sample_index, axis] = a
                self.store_buffer[axis].append(M_i + 1)

            shaper._x_buf = x_ext[symbolic_buf, axis].copy()
            shaper._x_head = 0
            shaper.M = final_M
            shaper.impulse = final_impulse

    def process_sample(
        self,
        command: np.ndarray,
        command_dot: np.ndarray | None = None,
        command_ddot: np.ndarray | None = None,
        enable_vibration_control: bool = True,
    ) -> ShapedSample:
        """Process one command sample with optional vibration shaping.

        Args:
            command: Joint command `[num_joints]` in radians.
            state: Robot state for feature calculation.
            command_dot: Optional command velocity `[num_joints]` in radians/s.
            command_ddot: Optional command acceleration `[num_joints]` in radians/s^2.
            enable_vibration_control: Whether to apply shaping.
        Returns:
            `ShapedSample` containing position/velocity/acceleration vectors.
        Side Effects:
            Updates per-axis shaper state and stream cache.
        Raises:
            ValueError: If command vector shapes are invalid.
        Preconditions:
            Model inference backend is initialized.
        """
        self._handle_vibration_mode_transition(enable_vibration_control)
        dot_from_fd = command_dot is None
        ddot_from_fd = command_ddot is None

        command = np.asarray(command, dtype=float)
        if command.shape != (self.num_joints,):
            raise ValueError("Command length mismatch")

        if command_dot is None:
            command_dot = np.zeros(self.num_joints, dtype=float)
        else:
            command_dot = np.asarray(command_dot, dtype=float)
            if command_dot.shape != (self.num_joints,):
                raise ValueError("command_dot length mismatch")

        if command_ddot is None:
            command_ddot = np.zeros(self.num_joints, dtype=float)
        else:
            command_ddot = np.asarray(command_ddot, dtype=float)
            if command_ddot.shape != (self.num_joints,):
                raise ValueError("command_ddot length mismatch")

        if not enable_vibration_control:
            out_pos = command.copy()
            if self.last_input_position is not None and dot_from_fd:
                out_vel = (out_pos - self.last_input_position) / self.Ts
            else:
                out_vel = command_dot.copy()

            if self.last_input_velocity is not None and ddot_from_fd:
                out_acc = (out_vel - self.last_input_velocity) / self.Ts
            else:
                out_acc = command_ddot.copy()

            self.last_input_position = out_pos
            self.last_input_velocity = out_vel
            self.last_input_acceleration = out_acc
            return ShapedSample(out_pos, out_vel, out_acc)

        joint_angles = np.array(command, copy=True, dtype=float)
        state = RobotState(
            joint_angles=joint_angles,
            tcp_position=self.compute_forward_kinematics(joint_angles),
        )

        v_rad, r_m, inertia = self.compute_nn_inputs(state)

        out_pos = command.copy()
        out_vel = command_dot.copy()
        out_acc = command_ddot.copy()

        with torch.no_grad():
            features = torch.zeros((self.num_axes, 3), dtype=torch.float32)
            v_deg = float(v_rad * 180.0 / math.pi)
            r_mm = float(r_m * 1000.0)
            for axis in range(self.num_axes):
                features[axis, 0] = v_deg
                features[axis, 1] = r_mm
                features[axis, 2] = float(inertia[axis])

            order_probs, mode_params = self.map_fitter.infer_batch(features)
            order_np = order_probs.squeeze(-1).double().cpu().numpy()
            mode_np = mode_params.double().cpu().numpy()

        axis_params = self._axis_params_from_model_outputs(order_np, mode_np)
        params_by_axis = self._shared_params_for_axes(axis_params)
        shaped_joints = (
            self.num_shaped_joints
            if self.shared_impulse_policy != "per_axis"
            else self.num_axes
        )
        for axis in range(shaped_joints):
            if not self._logged_once[axis]:
                if axis < self.num_axes:
                    prob_second = float(order_np[axis])
                    params = axis_params[axis]
                    self._log_axis_inference_once(
                        axis,
                        prob_second,
                        params,
                    )
                else:
                    self._logged_once[axis] = True

            try:
                params = (
                    params_by_axis[axis] if axis < self.num_axes else params_by_axis[0]
                )
                y, v, a = self.shapers[axis].shape_sample(
                    float(command[axis]),
                    params,
                )
                self.store_buffer[axis].append(len(self.shapers[axis]._x_buf))
                out_pos[axis] = y
                out_vel[axis] = v
                out_acc[axis] = a
            except ValueError:
                out_pos[axis] = command[axis]
                out_vel[axis] = command_dot[axis]
                out_acc[axis] = command_ddot[axis]

        self.last_input_position = out_pos
        self.last_input_velocity = out_vel
        self.last_input_acceleration = out_acc
        return ShapedSample(out_pos, out_vel, out_acc)

    def shape_sample(
        self,
        command: np.ndarray,
        command_dot: np.ndarray | None = None,
        command_ddot: np.ndarray | None = None,
    ) -> ShapedSample:
        """Backward-compatible alias for `process_sample(..., enable_vibration_control=True)`.

        Args:
            command: Joint command `[num_joints]` in radians.
            state: Robot state for feature calculation.
            command_dot: Optional command velocity `[num_joints]` in radians/s.
            command_ddot: Optional command acceleration `[num_joints]` in radians/s^2.
        Returns:
            `ShapedSample` with vibration control enabled.
        Side Effects:
            Same as `process_sample`.
        Raises:
            ValueError: If command vector shapes are invalid.
        Preconditions:
            Model inference backend is initialized.
        """

        return self.process_sample(
            command=command,
            command_dot=command_dot,
            command_ddot=command_ddot,
            enable_vibration_control=True,
        )

    def process_trajectory(
        self,
        command: np.ndarray,
        command_dot: np.ndarray | None = None,
        command_ddot: np.ndarray | None = None,
        time_vector: list[float] | None = None,
        enable_vibration_control: bool = True,
        finalize_tail: bool = True,
        reset_on_discontinuity: bool = True,
    ) -> ShapedTrajectory:
        """Process a full trajectory with optional vibration shaping.

        Args:
            command: Command trajectory `[N, num_joints]` in radians.
            command_dot: Optional velocity trajectory `[N, num_joints]` in radians/s.
            command_ddot: Optional acceleration trajectory `[N, num_joints]` in radians/s^2.
            time_vector: Optional sample times `[N]` in seconds.
            enable_vibration_control: Whether to apply shaping.
            finalize_tail: Whether to append delayed shaper tail samples at the end.
            reset_on_discontinuity: Whether to reset if this block does not begin
                at the previously processed raw position/velocity/acceleration.
        Returns:
            `ShapedTrajectory` containing processed trajectory fields.
        Side Effects:
            Mutates shaper internal history and stream continuity cache.
        Raises:
            ValueError: If command/state/derivative shapes are inconsistent.
        Preconditions:
            Dynamics backend and map models are initialized.
        """
        reset_for_mode_change = self._handle_vibration_mode_transition(
            enable_vibration_control
        )

        command = np.asarray(command, dtype=float)
        if command.ndim != 2 or command.shape[1] != self.num_joints:
            raise ValueError("command must be (N, num_joints)")

        samples = command.shape[0]
        states = self._generate_states(command)

        if states and len(states) != samples:
            raise ValueError("states length must match samples")

        if command_dot is None:
            command_dot = self.finite_difference_first(command)
        else:
            command_dot = np.asarray(command_dot, dtype=float)
            if command_dot.shape != command.shape:
                raise ValueError("command_dot shape mismatch")

        if command_ddot is None:
            command_ddot = self.finite_difference_second(command_dot)
        else:
            command_ddot = np.asarray(command_ddot, dtype=float)
            if command_ddot.shape != command.shape:
                raise ValueError("command_ddot shape mismatch")

        times = (
            list(time_vector)
            if time_vector is not None
            else [float(i) * self.Ts for i in range(samples)]
        )
        if len(times) != samples:
            raise ValueError("time_vector length mismatch")

        first_position = command[0]
        first_velocity = command_dot[0]
        first_acceleration = command_ddot[0]

        if not enable_vibration_control:
            self.last_input_position = command[-1].copy()
            self.last_input_velocity = command_dot[-1].copy()
            self.last_input_acceleration = command_ddot[-1].copy()
            return ShapedTrajectory(
                command.copy(),
                command_dot.copy(),
                command_ddot.copy(),
                np.asarray(times, dtype=float),
            )

        continue_stream = False
        if (
            self.last_input_position is not None
            and self.last_input_velocity is not None
            and self.last_input_acceleration is not None
        ):
            position_match = np.allclose(
                self.last_input_position, first_position, rtol=1e-8, atol=1e-10
            )
            velocity_match = np.allclose(
                self.last_input_velocity, first_velocity, rtol=1e-8, atol=1e-10
            )
            acceleration_match = np.allclose(
                self.last_input_acceleration,
                first_acceleration,
                rtol=1e-8,
                atol=1e-10,
            )
            continue_stream = position_match and velocity_match and acceleration_match

        if reset_on_discontinuity and not continue_stream and not reset_for_mode_change:
            self.reset()

        traj_pos = np.zeros((samples, self.num_joints), dtype=float)
        traj_vel = np.zeros_like(traj_pos)
        traj_acc = np.zeros_like(traj_pos)
        traj_time = np.asarray(times, dtype=float)

        traj_pos[:, :] = command
        traj_vel[:, :] = command_dot
        traj_acc[:, :] = command_ddot

        features_np = np.zeros((samples, self.num_axes, 3), dtype=np.float32)
        for sample_index in range(samples):
            state_i = (
                states[sample_index]
                if states
                else RobotState(
                    joint_angles=command[sample_index],
                    tcp_position=self.compute_forward_kinematics(command[sample_index]),
                )
            )

            v_rad, r_m, inertia = self.compute_nn_inputs(state_i)
            v_deg = float(v_rad * 180.0 / math.pi)
            r_mm = float(r_m * 1000.0)
            for axis in range(self.num_axes):
                features_np[sample_index, axis, 0] = v_deg
                features_np[sample_index, axis, 1] = r_mm
                features_np[sample_index, axis, 2] = float(inertia[axis])

        with torch.no_grad():
            features = torch.as_tensor(features_np, dtype=torch.float32)
            if hasattr(self.map_fitter, "infer_sequence"):
                order_probs, mode_params = self.map_fitter.infer_sequence(features)
            else:
                orders = []
                modes = []
                for sample_index in range(samples):
                    order, mode = self.map_fitter.infer_batch(features[sample_index])
                    orders.append(order.unsqueeze(0))
                    modes.append(mode.unsqueeze(0))
                order_probs = torch.cat(orders, dim=0)
                mode_params = torch.cat(modes, dim=0)
            order_np = order_probs.squeeze(-1).double().cpu().numpy()
            mode_np = mode_params.double().cpu().numpy()

        axis_params_sequence = [
            self._axis_params_from_model_outputs(
                order_np[sample_index],
                mode_np[sample_index],
            )
            for sample_index in range(samples)
        ]

        if self.shared_impulse_policy != "per_axis":
            shared_params_sequence = [
                self._shared_params_for_axes(axis_params)[0]
                for axis_params in axis_params_sequence
            ]
            for axis in range(self.num_axes):
                if not self._logged_once[axis]:
                    params = axis_params_sequence[0][axis]
                    prob_second = float(order_np[0, axis])
                    self._log_axis_inference_once(
                        axis,
                        prob_second,
                        params,
                    )

            self._shape_shared_axes_lifted(
                command,
                shared_params_sequence,
                traj_pos,
                traj_vel,
                traj_acc,
            )
        else:
            for sample_index, axis_params in enumerate(axis_params_sequence):
                params_by_axis = self._shared_params_for_axes(axis_params)
                for axis in range(self.num_axes):
                    if not self._logged_once[axis]:
                        prob_second = float(order_np[sample_index, axis])
                        params = axis_params[axis]
                        self._log_axis_inference_once(
                            axis,
                            prob_second,
                            params,
                        )

                    try:
                        y, v, a = self.shapers[axis].shape_sample(
                            float(command[sample_index, axis]),
                            params_by_axis[axis],
                        )
                        self.store_buffer[axis].append(len(self.shapers[axis]._x_buf))
                        traj_pos[sample_index, axis] = y
                        traj_vel[sample_index, axis] = v
                        traj_acc[sample_index, axis] = a
                    except ValueError:
                        traj_pos[sample_index, axis] = command[sample_index, axis]
                        traj_vel[sample_index, axis] = command_dot[sample_index, axis]
                        traj_acc[sample_index, axis] = command_ddot[
                            sample_index,
                            axis,
                        ]

        if finalize_tail:
            tail = self._finalize_tail_trajectory(
                last_position=traj_pos[-1],
                last_time=float(traj_time[-1]),
                start_index=samples,
            )

            if tail.positions.shape[0] > 0:
                traj_pos = np.vstack([traj_pos, tail.positions])
                traj_vel = np.vstack([traj_vel, tail.velocities])
                traj_acc = np.vstack([traj_acc, tail.accelerations])
                traj_time = np.concatenate([traj_time, tail.time])

        self.last_input_position = command[-1]
        self.last_input_velocity = command_dot[-1]
        self.last_input_acceleration = command_ddot[-1]

        return ShapedTrajectory(traj_pos, traj_vel, traj_acc, traj_time)

    def _finalize_tail_trajectory(
        self,
        last_position: np.ndarray,
        last_time: float,
        start_index: int,
    ) -> ShapedTrajectory:
        """Flush delayed shaper samples into a trajectory tail.

        Args:
            last_position: Last shaped joint position `[num_joints]` in radians.
            last_time: Last shaped sample time [s].
            start_index: Source index assigned to the first tail sample.
        Returns:
            `ShapedTrajectory` containing only tail samples. Arrays have zero
            rows when no delayed samples are available.
        Side Effects:
            Advances per-joint shaper histories through the delayed tail.
        Raises:
            None.
        Preconditions:
            `last_position` has shape `[num_joints]` and shaper histories have
            been advanced through the final source trajectory sample.
        """

        last_position = np.asarray(last_position, dtype=float)
        if last_position.shape != (self.num_joints,):
            raise ValueError("last_position length mismatch")
        if start_index < 0:
            raise ValueError("start_index must be non-negative")

        tail_remaining_by_axis = [shaper.M for shaper in self.shapers]
        max_tail = max(tail_remaining_by_axis, default=0)

        if max_tail == 0:
            return self._empty_tail_trajectory()

        return self._shape_tail_chunk(
            last_position=last_position,
            last_time=last_time,
            start_index=start_index,
            sample_count=max_tail,
            tail_remaining_by_axis=tail_remaining_by_axis,
        )

    def _empty_tail_trajectory(self) -> ShapedTrajectory:
        """Create an empty final-tail trajectory.

        Args:
            None.
        Returns:
            `ShapedTrajectory` with zero rows.
        Side Effects:
            None.
        Raises:
            None.
        Preconditions:
            None.
        """
        return ShapedTrajectory(
            positions=np.zeros((0, self.num_joints), dtype=float),
            velocities=np.zeros((0, self.num_joints), dtype=float),
            accelerations=np.zeros((0, self.num_joints), dtype=float),
            time=np.zeros(0, dtype=float),
        )

    def _shape_tail_chunk(
        self,
        last_position: np.ndarray,
        last_time: float,
        start_index: int,
        sample_count: int,
        tail_remaining_by_axis: list[int],
    ) -> ShapedTrajectory:
        """Flush one bounded final-tail chunk.

        Args:
            last_position: Last shaped joint position `[num_joints]` in radians.
            last_time: Last shaped sample time [s].
            start_index: Source index assigned to the first tail sample.
            sample_count: Maximum number of tail samples to produce.
            tail_remaining_by_axis: Remaining tail samples per shaped joint.
        Returns:
            `ShapedTrajectory` containing one tail chunk.
        Side Effects:
            Advances shaper histories by the emitted tail samples.
        Raises:
            ValueError: If dimensions or counts are invalid.
        Preconditions:
            `tail_remaining_by_axis` aligns with `self.shapers`.
        """
        if sample_count < 0:
            raise ValueError("sample_count must be non-negative")
        if len(tail_remaining_by_axis) != self.num_shaped_joints:
            raise ValueError("tail_remaining_by_axis length mismatch")
        if sample_count == 0 or max(tail_remaining_by_axis, default=0) <= 0:
            return self._empty_tail_trajectory()

        chunk_samples = min(sample_count, max(tail_remaining_by_axis))
        if (
            self.shared_impulse_policy != "per_axis"
            and getattr(self, "_last_valid_shared_params", None) is not None
        ):
            return self._shape_shared_tail_chunk_lifted(
                last_position=last_position,
                last_time=last_time,
                start_index=start_index,
                sample_count=chunk_samples,
            )

        return self._shape_per_axis_tail_chunk(
            last_position=last_position,
            last_time=last_time,
            start_index=start_index,
            sample_count=chunk_samples,
            tail_remaining_by_axis=tail_remaining_by_axis,
        )

    def _shape_shared_tail_chunk_lifted(
        self,
        last_position: np.ndarray,
        last_time: float,
        start_index: int,
        sample_count: int,
    ) -> ShapedTrajectory:
        """Flush a shared-impulse tail chunk through the lifted shaper path.

        Args:
            last_position: Last shaped joint position `[num_joints]` in radians.
            last_time: Last shaped sample time [s].
            start_index: Source index assigned to the first tail sample.
            sample_count: Number of hold-input samples to emit.
        Returns:
            `ShapedTrajectory` containing shaped tail samples.
        Side Effects:
            Mutates shared shaper histories and native profile counters.
        Raises:
            ValueError: If shared modal parameters are unavailable.
        Preconditions:
            Shared-axis shaper states are aligned.
        """
        if self._last_valid_shared_params is None:
            raise ValueError("shared tail requires last valid shared parameters")

        hold_command = np.asarray(last_position, dtype=float).copy()
        for axis in range(self.num_shaped_joints):
            hold_command[axis] = float(self.shapers[axis]._x_buf[0])

        command = np.tile(hold_command, (sample_count, 1))
        tail_pos = np.tile(np.asarray(last_position, dtype=float), (sample_count, 1))
        tail_vel = np.zeros_like(tail_pos)
        tail_acc = np.zeros_like(tail_pos)
        tail_time = np.array(
            [last_time + (step + 1) * self.Ts for step in range(sample_count)],
            dtype=float,
        )

        shared_params_sequence = [
            self._last_valid_shared_params.copy() for _ in range(sample_count)
        ]

        self._shape_shared_axes_lifted(
            command,
            shared_params_sequence,
            tail_pos,
            tail_vel,
            tail_acc,
        )

        return ShapedTrajectory(tail_pos, tail_vel, tail_acc, tail_time)

    def _shape_per_axis_tail_chunk(
        self,
        last_position: np.ndarray,
        last_time: float,
        start_index: int,
        sample_count: int,
        tail_remaining_by_axis: list[int],
    ) -> ShapedTrajectory:
        """Flush a bounded tail chunk for independent per-axis shapers.

        Args:
            last_position: Last shaped joint position `[num_joints]` in radians.
            last_time: Last shaped sample time [s].
            start_index: Source index assigned to the first tail sample.
            sample_count: Maximum number of tail samples to emit.
            tail_remaining_by_axis: Remaining tail samples per shaped joint.
        Returns:
            `ShapedTrajectory` containing one tail chunk.
        Side Effects:
            Calls `BaseShaper.finalize()` for shaped joints.
        Raises:
            None.
        Preconditions:
            `tail_remaining_by_axis` aligns with `self.shapers`.
        """
        del start_index
        tail_pos = np.zeros((sample_count, self.num_joints), dtype=float)
        tail_vel = np.zeros_like(tail_pos)
        tail_acc = np.zeros_like(tail_pos)
        tail_time = np.array(
            [last_time + (step + 1) * self.Ts for step in range(sample_count)],
            dtype=float,
        )

        tails: list[list[tuple[float, float, float]]] = []
        for axis, remaining in enumerate(tail_remaining_by_axis):
            axis_samples = min(sample_count, max(0, remaining))
            tails.append(self.shapers[axis].finalize(axis_samples))

        for tail_index in range(sample_count):
            pos = last_position.copy()
            vel = np.zeros(self.num_joints, dtype=float)
            acc = np.zeros(self.num_joints, dtype=float)
            for axis in range(self.num_shaped_joints):
                if tail_index < len(tails[axis]):
                    y, v, a = tails[axis][tail_index]
                    pos[axis] = y
                    vel[axis] = v
                    acc[axis] = a

            tail_pos[tail_index, :] = pos
            tail_vel[tail_index, :] = vel
            tail_acc[tail_index, :] = acc

        return ShapedTrajectory(tail_pos, tail_vel, tail_acc, tail_time)

    def qualify_windowed_buffer(
        self,
        command: np.ndarray,
        command_dot: np.ndarray | None = None,
        command_ddot: np.ndarray | None = None,
        time_vector: list[float] | None = None,
        enable_vibration_control: bool = True,
        window_s: float | None = None,
        prefill_windows: int = DEFAULT_WINDOW_PREFILL_COUNT,
        tail_only_s: float | None = None,
        window_compute_fraction_limit: float = DEFAULT_WINDOW_COMPUTE_FRACTION_LIMIT,
        window_candidates_s: list[float] | None = None,
    ) -> WindowQualificationResult:
        """Run on-machine timing qualification for windowed trajectory shaping.

        Args:
            command: Command trajectory `[N, num_joints]` in radians.
            command_dot: Optional velocity trajectory `[N, num_joints]` in radians/s.
            command_ddot: Optional acceleration trajectory `[N, num_joints]` in radians/s^2.
            time_vector: Optional sample times `[N]` in seconds.
            enable_vibration_control: Whether trial windows apply vibration control.
            window_s: Optional fixed candidate duration [s]. If `None`, the
                first passing value from `window_candidates_s` is returned.
            prefill_windows: Number of startup windows assumed by the margin model.
            tail_only_s: Optional experimental shaped tail duration [s].
            window_compute_fraction_limit: Maximum allowed compute/execute-time ratio.
            window_candidates_s: Optional candidate durations [s] tested when
                `window_s is None`.
        Returns:
            `WindowQualificationResult` for the fixed candidate or first
            automatically selected passing candidate.
        Side Effects:
            Runs trial shaping and resets shaper/native profile state afterward.
        Raises:
            RuntimeError: If `window_s is None` and no candidate passes.
            ValueError: If input dimensions or timing parameters are invalid.
        Preconditions:
            The trajectory is representative of the motion that will be sent to
            the robot on this machine.
        """

        if prefill_windows < 0:
            raise ValueError("prefill_windows must be non-negative")
        if window_compute_fraction_limit <= 0.0:
            raise ValueError("window_compute_fraction_limit must be positive")

        self.reset()
        if window_s is None:
            _, result = self._select_qualified_window_s(
                command=command,
                command_dot=command_dot,
                command_ddot=command_ddot,
                time_vector=time_vector,
                enable_vibration_control=enable_vibration_control,
                prefill_windows=prefill_windows,
                tail_only_s=tail_only_s,
                compute_fraction_limit=window_compute_fraction_limit,
                window_candidates_s=window_candidates_s,
            )
        else:
            if window_s <= 0.0:
                raise ValueError("window_s must be positive")
            result = self._qualify_window_s(
                command=command,
                command_dot=command_dot,
                command_ddot=command_ddot,
                time_vector=time_vector,
                enable_vibration_control=enable_vibration_control,
                window_s=window_s,
                prefill_windows=prefill_windows,
                tail_only_s=tail_only_s,
                compute_fraction_limit=window_compute_fraction_limit,
            )

        self.reset()
        self._reset_native_profile_seconds()
        return result

    def create_windowed_buffer(
        self,
        command: np.ndarray,
        command_dot: np.ndarray | None = None,
        command_ddot: np.ndarray | None = None,
        time_vector: list[float] | None = None,
        enable_vibration_control: bool = True,
        window_s: float | None = None,
        prefill_windows: int = DEFAULT_WINDOW_PREFILL_COUNT,
        finalize_tail: bool = True,
        reset_on_start: bool = True,
        tail_only_s: float | None = None,
        auto_qualify_window: bool = True,
        window_compute_fraction_limit: float = DEFAULT_WINDOW_COMPUTE_FRACTION_LIMIT,
        window_candidates_s: list[float] | None = None,
    ) -> WindowedTrajectoryBuffer:
        """Create a FIFO buffer that shapes a full trajectory in windows.

        Args:
            command: Command trajectory `[N, num_joints]` in radians.
            command_dot: Optional velocity trajectory `[N, num_joints]` in radians/s.
            command_ddot: Optional acceleration trajectory `[N, num_joints]` in radians/s^2.
            time_vector: Optional sample times `[N]` in seconds.
            enable_vibration_control: Whether shaped windows apply vibration control.
            window_s: Optional fixed window duration [s]. If `None`, the shaper
                tests candidate window durations and selects the first one that
                satisfies the timing gate.
            prefill_windows: Number of windows to produce before consumption.
            finalize_tail: Whether to append one delayed shaper tail window.
            reset_on_start: Whether to reset shaper state before creating the buffer.
            tail_only_s: Experimental duration [s] at the end of the trajectory
                to shape. Earlier samples are passed through without advancing
                shaper state when this value is not `None`.
            auto_qualify_window: Whether `window_s=None` should run automatic
                on-machine timing qualification.
            window_compute_fraction_limit: Maximum allowed ratio between a
                window's compute time and its execution duration.
            window_candidates_s: Optional candidate durations [s] tested when
                `window_s is None`.
        Returns:
            `WindowedTrajectoryBuffer` containing queued raw windows.
        Side Effects:
            May reset shaper state when `reset_on_start` is true.
        Raises:
            ValueError: If dimensions, window duration, prefill count, or
                `tail_only_s` are invalid.
        Preconditions:
            Dynamics backend and map models are initialized.
        """

        if window_s is not None and window_s <= 0.0:
            raise ValueError("window_s must be positive")
        if prefill_windows < 0:
            raise ValueError("prefill_windows must be non-negative")
        if tail_only_s is not None and tail_only_s < 0.0:
            raise ValueError("tail_only_s must be non-negative")
        if window_compute_fraction_limit <= 0.0:
            raise ValueError("window_compute_fraction_limit must be positive")
        if reset_on_start:
            self.reset()

        qualification: WindowQualificationResult | None = None
        selected_window_s = window_s
        if selected_window_s is None:
            if not auto_qualify_window:
                raise ValueError(
                    "window_s is required when auto_qualify_window is false"
                )
            selected_window_s, qualification = self._select_qualified_window_s(
                command=command,
                command_dot=command_dot,
                command_ddot=command_ddot,
                time_vector=time_vector,
                enable_vibration_control=enable_vibration_control,
                prefill_windows=prefill_windows,
                tail_only_s=tail_only_s,
                compute_fraction_limit=window_compute_fraction_limit,
                window_candidates_s=window_candidates_s,
            )
            self.reset()
            self._reset_native_profile_seconds()

        windows = self._make_trajectory_windows(
            command=command,
            command_dot=command_dot,
            command_ddot=command_ddot,
            time_vector=time_vector,
            window_s=selected_window_s,
            tail_only_s=tail_only_s,
        )
        return WindowedTrajectoryBuffer(
            shaper=self,
            raw_windows=windows,
            prefill_windows=prefill_windows,
            finalize_tail=finalize_tail,
            enable_vibration_control=enable_vibration_control,
            selected_window_s=selected_window_s,
            qualification=qualification,
        )

    def _select_qualified_window_s(
        self,
        command: np.ndarray,
        command_dot: np.ndarray | None,
        command_ddot: np.ndarray | None,
        time_vector: list[float] | None,
        enable_vibration_control: bool,
        prefill_windows: int,
        tail_only_s: float | None,
        compute_fraction_limit: float,
        window_candidates_s: list[float] | None,
    ) -> tuple[float, WindowQualificationResult]:
        """Select the first candidate window size that passes timing qualification.

        Args:
            command: Command trajectory `[N, num_joints]` in radians.
            command_dot: Optional velocity trajectory `[N, num_joints]` in radians/s.
            command_ddot: Optional acceleration trajectory `[N, num_joints]` in radians/s^2.
            time_vector: Optional sample times `[N]` in seconds.
            enable_vibration_control: Whether the tested windows apply shaping.
            prefill_windows: Number of startup windows assumed by the margin model.
            tail_only_s: Optional experimental shaped tail duration [s].
            compute_fraction_limit: Maximum allowed compute/execute-time ratio.
            window_candidates_s: Optional candidate durations [s].
        Returns:
            `tuple[float, WindowQualificationResult]` selected window duration
            [s] and its qualification metrics.
        Side Effects:
            Runs trial shaping over candidate windows and resets shaper state
            between candidates.
        Raises:
            RuntimeError: If no candidate satisfies the timing gate.
            ValueError: If a candidate duration is invalid.
        Preconditions:
            Candidate trajectories are representative of the motion that will
            be sent to the robot.
        """

        candidates = (
            list(window_candidates_s)
            if window_candidates_s is not None
            else list(DEFAULT_WINDOW_CANDIDATE_SECONDS)
        )
        if not candidates:
            raise ValueError("window_candidates_s must contain at least one value")

        selection_begin = time.perf_counter()
        failures: list[WindowQualificationResult] = []
        for candidate_s in candidates:
            if candidate_s <= 0.0:
                raise ValueError("window candidate durations must be positive")
            self.reset()
            result = self._qualify_window_s(
                command=command,
                command_dot=command_dot,
                command_ddot=command_ddot,
                time_vector=time_vector,
                enable_vibration_control=enable_vibration_control,
                window_s=candidate_s,
                prefill_windows=prefill_windows,
                tail_only_s=tail_only_s,
                compute_fraction_limit=compute_fraction_limit,
            )
            if result.passed:
                result.qualification_elapsed_s = time.perf_counter() - selection_begin
                return candidate_s, result
            failures.append(result)

        summary = ", ".join(
            f"{failure.window_s:.3f}s max={failure.max_window_s:.6f}s "
            f"p99={failure.p99_window_s:.6f}s underruns={failure.underruns}"
            for failure in failures
        )
        raise RuntimeError(
            "No window candidate passed real-time qualification: " + summary
        )

    def _qualify_window_s(
        self,
        command: np.ndarray,
        command_dot: np.ndarray | None,
        command_ddot: np.ndarray | None,
        time_vector: list[float] | None,
        enable_vibration_control: bool,
        window_s: float,
        prefill_windows: int,
        tail_only_s: float | None,
        compute_fraction_limit: float,
    ) -> WindowQualificationResult:
        """Measure whether one candidate window size can stay ahead of execution.

        Args:
            command: Command trajectory `[N, num_joints]` in radians.
            command_dot: Optional velocity trajectory `[N, num_joints]` in radians/s.
            command_ddot: Optional acceleration trajectory `[N, num_joints]` in radians/s^2.
            time_vector: Optional sample times `[N]` in seconds.
            enable_vibration_control: Whether the trial windows apply shaping.
            window_s: Candidate window duration [s].
            prefill_windows: Number of startup windows assumed by the margin model.
            tail_only_s: Optional experimental shaped tail duration [s].
            compute_fraction_limit: Maximum allowed compute/execute-time ratio.
        Returns:
            `WindowQualificationResult` containing pass/fail and timing metrics.
        Side Effects:
            Advances shaper state while timing trial windows.
        Raises:
            ValueError: If input slicing fails.
        Preconditions:
            `window_s > 0`, `prefill_windows >= 0`, and
            `compute_fraction_limit > 0`.
        """

        windows = self._make_trajectory_windows(
            command=command,
            command_dot=command_dot,
            command_ddot=command_ddot,
            time_vector=time_vector,
            window_s=window_s,
            tail_only_s=tail_only_s,
        )
        if not windows:
            return WindowQualificationResult(
                window_s=window_s,
                passed=True,
                compute_fraction_limit=compute_fraction_limit,
                prefill_windows=prefill_windows,
                max_window_s=0.0,
                p99_window_s=0.0,
                min_buffer_margin_s=0.0,
                underruns=0,
                measured_windows=0,
                qualification_elapsed_s=0.0,
            )

        buffer = WindowedTrajectoryBuffer(
            shaper=self,
            raw_windows=windows,
            prefill_windows=prefill_windows,
            finalize_tail=True,
            enable_vibration_control=enable_vibration_control,
            selected_window_s=window_s,
            qualification=None,
        )
        buffer.fill_available()
        compute_times = list(buffer._window_times)
        durations = list(buffer._window_durations)
        ratios = [
            compute_s / duration_s if duration_s > 0.0 else math.inf
            for compute_s, duration_s in zip(compute_times, durations)
        ]

        startup_latency = float(sum(compute_times[:prefill_windows]))
        produced_time = 0.0
        produced_duration = 0.0
        underruns = 0
        min_margin = math.inf
        for compute_s, duration_s in zip(compute_times, durations):
            produced_time += compute_s
            produced_duration += duration_s
            margin = startup_latency + produced_duration - produced_time
            min_margin = min(min_margin, margin)
            if margin < 0.0:
                underruns += 1

        max_ratio = max(ratios) if ratios else 0.0
        passed = max_ratio <= compute_fraction_limit and underruns == 0
        return WindowQualificationResult(
            window_s=window_s,
            passed=passed,
            compute_fraction_limit=compute_fraction_limit,
            prefill_windows=prefill_windows,
            max_window_s=max(compute_times),
            p99_window_s=_percentile_or_none(compute_times, 99.0) or 0.0,
            min_buffer_margin_s=float(min_margin),
            underruns=underruns,
            measured_windows=len(compute_times),
            qualification_elapsed_s=float(sum(compute_times)),
        )

    def _make_trajectory_windows(
        self,
        command: np.ndarray,
        command_dot: np.ndarray | None,
        command_ddot: np.ndarray | None,
        time_vector: list[float] | None,
        window_s: float,
        tail_only_s: float | None,
    ) -> list[TrajectoryWindow]:
        """Slice a full trajectory into raw windows for buffered shaping.

        Args:
            command: Command trajectory `[N, num_joints]` in radians.
            command_dot: Optional velocity trajectory `[N, num_joints]` in radians/s.
            command_ddot: Optional acceleration trajectory `[N, num_joints]` in radians/s^2.
            time_vector: Optional sample times `[N]` in seconds.
            window_s: Window duration [s].
            tail_only_s: Optional experimental shaped tail duration [s].
        Returns:
            `list[TrajectoryWindow]` raw windows in source order.
        Side Effects:
            None.
        Raises:
            ValueError: If input dimensions are inconsistent.
        Preconditions:
            `window_s > 0` and `tail_only_s` is `None` or non-negative.
        """

        command = np.asarray(command, dtype=float)
        if command.ndim != 2 or command.shape[1] != self.num_joints:
            raise ValueError("command must be (N, num_joints)")
        samples = command.shape[0]
        if samples == 0:
            return []
        states = self._generate_states(command)
        if states and len(states) != samples:
            raise ValueError("states length must match samples")

        if command_dot is None:
            command_dot = self.finite_difference_first(command)
        else:
            command_dot = np.asarray(command_dot, dtype=float)
            if command_dot.shape != command.shape:
                raise ValueError("command_dot shape mismatch")

        if command_ddot is None:
            command_ddot = self.finite_difference_second(command_dot)
        else:
            command_ddot = np.asarray(command_ddot, dtype=float)
            if command_ddot.shape != command.shape:
                raise ValueError("command_ddot shape mismatch")

        times = (
            np.asarray(time_vector, dtype=float)
            if time_vector is not None
            else np.arange(samples, dtype=float) * self.Ts
        )
        if times.shape != (samples,):
            raise ValueError("time_vector length mismatch")

        window_samples = max(1, int(round(window_s / self.Ts)))
        tail_start = 0
        if tail_only_s is not None:
            tail_samples = int(round(tail_only_s / self.Ts))
            tail_start = max(0, samples - tail_samples)

        boundaries = set(range(0, samples, window_samples))
        boundaries.add(samples)
        if tail_only_s is not None:
            boundaries.add(tail_start)
        ordered = sorted(boundaries)

        windows: list[TrajectoryWindow] = []
        for start, stop in zip(ordered[:-1], ordered[1:]):
            if start == stop:
                continue
            should_shape = tail_only_s is None or start >= tail_start
            window_states = states[start:stop] if states else []
            windows.append(
                TrajectoryWindow(
                    command=command[start:stop].copy(),
                    states=window_states,
                    command_dot=command_dot[start:stop].copy(),
                    command_ddot=command_ddot[start:stop].copy(),
                    time=times[start:stop].copy(),
                    start_index=start,
                    stop_index=stop,
                    should_shape=should_shape,
                )
            )
        return windows

    def shape_trajectory(
        self,
        command: np.ndarray,
        command_dot: np.ndarray | None = None,
        command_ddot: np.ndarray | None = None,
        time_vector: list[float] | None = None,
    ) -> ShapedTrajectory:
        """Backward-compatible alias for `process_trajectory(..., enable_vibration_control=True)`.

        Args:
            command: Command trajectory `[N, num_joints]` in radians.
            command_dot: Optional velocity trajectory `[N, num_joints]` in radians/s.
            command_ddot: Optional acceleration trajectory `[N, num_joints]` in radians/s^2.
            time_vector: Optional sample times `[N]` in seconds.
        Returns:
            `ShapedTrajectory` with vibration control enabled.
        Side Effects:
            Same as `process_trajectory`.
        Raises:
            ValueError: If command/state/derivative shapes are inconsistent.
        Preconditions:
            Dynamics backend and map models are initialized.
        """

        return self.process_trajectory(
            command=command,
            command_dot=command_dot,
            command_ddot=command_ddot,
            time_vector=time_vector,
            enable_vibration_control=True,
        )
