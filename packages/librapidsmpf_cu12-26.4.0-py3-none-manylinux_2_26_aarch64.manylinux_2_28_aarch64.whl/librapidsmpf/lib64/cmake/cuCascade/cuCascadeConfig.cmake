
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was cuCascadeConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################

include(CMakeFindDependencyMacro)

# Find required dependencies
find_dependency(CUDAToolkit REQUIRED)
find_dependency(Threads REQUIRED)
find_dependency(rmm REQUIRED CONFIG)
find_dependency(cudf REQUIRED CONFIG)

# Include the targets file
include("${CMAKE_CURRENT_LIST_DIR}/cuCascadeTargets.cmake")

# Provide a default target alias for convenience
# Users can link to cuCascade::cucascade, cuCascade::cucascade_static, or cuCascade::cucascade_shared
if(TARGET cuCascade::cucascade_shared)
  if(NOT TARGET cuCascade::cucascade)
    add_library(cuCascade::cucascade ALIAS cuCascade::cucascade_shared)
  endif()
elseif(TARGET cuCascade::cucascade_static)
  if(NOT TARGET cuCascade::cucascade)
    add_library(cuCascade::cucascade ALIAS cuCascade::cucascade_static)
  endif()
endif()

check_required_components(cuCascade)
