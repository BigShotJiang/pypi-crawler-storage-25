#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "cuCascade::cucascade_static" for configuration "Release"
set_property(TARGET cuCascade::cucascade_static APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(cuCascade::cucascade_static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib64/libcucascade.a"
  )

list(APPEND _cmake_import_check_targets cuCascade::cucascade_static )
list(APPEND _cmake_import_check_files_for_cuCascade::cucascade_static "${_IMPORT_PREFIX}/lib64/libcucascade.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
