#=============================================================================
# SPDX-FileCopyrightText: Copyright (c) 2026, NVIDIA CORPORATION.
# SPDX-License-Identifier: Apache-2.0
#=============================================================================

include(CMakeFindDependencyMacro)

find_dependency(CUDAToolkit)

find_dependency(Threads)

find_package(nvtx3 3.2.0 QUIET)
find_dependency(nvtx3)

find_package(rmm 26.04 QUIET)
find_dependency(rmm)

find_package(cudf 26.04.00 QUIET)
find_dependency(cudf)

find_package(cuco 0.0.1 QUIET)
find_dependency(cuco)

find_dependency(ucxx)


set(rapids_global_targets nvtx3-c;nvtx3-cpp;rmm::rmm;rmm::rmm_logger;rmm::rmm_logger_impl;cudf::cudf;cuco::cuco)


foreach(target IN LISTS rapids_global_targets)
  if(TARGET ${target})
    get_target_property(_is_imported ${target} IMPORTED)
    get_target_property(_already_global ${target} IMPORTED_GLOBAL)
    if(_is_imported AND NOT _already_global)
        set_target_properties(${target} PROPERTIES IMPORTED_GLOBAL TRUE)
    endif()
  endif()
endforeach()

unset(rapids_global_targets)
unset(rapids_clear_cpm_cache)
