from sortedcontainers import SortedSet;


def regionGraph(object):
  def __init__(self):
    self.RG = SortedSet() #nx.DiGraph()
    self.count = {}
    self.maximal = Set()
  def addRegion( r, add_intersections=True):
    if len(r)==0 or r in self.RG.nodes or len(self.contains(vs))==1: return 0
    self.RG.add(r)
    if not add_intersections: return 1
    added = 1;
    add_max=True
    for m in self.maximal:
      if m < r: self.maximal.remove(m)
      elif m > r: add_max=False 
    if add_max: self.maximal.add(r)
    for n in self.intersects(r): added+=addRegion( r&n, False );
    self.updateCount(r)
    return added



  # comparison operator lhs < rhs

  ## Graph of regions
  ##   Regions have (varset, count, children, parents)
  ##   Maximal regions (have no parents?); Minimal regions?
  ##   Accessors: contains(vs), intersects(vs), containedBy(vs)
  ##   Recalculate counting numbers (after addition/removal?)
  ##   Keeps list of Xi -> {regions containing Xi}
  
  ## insert( region ): if size 0, already in, or unique parent, don't add
  ##    ow: add node; update var adj; add to max set if maximal; remove any subsumed sets
  ## add (region): if size 0 skip; ow: insert self, then any intersections with existing regions
  ##   nbrs = intersects(new); for n in nbrs insert( new&n); update counts from new downward
  ## calcCount(r): an=contains(r); count = 1-sum_an( count(an)); update descendants by size

