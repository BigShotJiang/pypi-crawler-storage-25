# -*- coding: utf-8 -*-
import wx

from .. import ui
from ..lib.utils import ustr

daboNames = dir(ui)

dabo_to_wx = {}
wx_to_dabo = {}

for daboName in daboNames:
    daboClass = getattr(ui, daboName)
    if hasattr(daboClass, "__mro__"):
        for mro in daboClass.__mro__:
            if "<class 'wx." in ustr(mro):
                if "wx._" in ustr(mro):
                    # normal wx class: don't include the wx._controls. cruft
                    dabo_to_wx[daboName] = f"wx.{ustr(mro).split('.')[-1][:-2]}"
                else:
                    # extra class: give the full story:
                    dabo_to_wx[daboName] = ustr(mro)[8:-2]
                break

daboNames = list(dabo_to_wx.items())
daboNames.sort()

for k, v in dabo_to_wx.items():
    wxClasses = wx_to_dabo.setdefault(v, [])
    wxClasses.append(k)

wxNames = list(wx_to_dabo.items())
wxNames.sort()

for eachItem in daboNames:
    print(f"{eachItem[0]} = {eachItem[1]}")

print("\n\n")

for eachItem in wxNames:
    print(f"{eachItem[0]} = {', '.join(eachItem[1])}")
