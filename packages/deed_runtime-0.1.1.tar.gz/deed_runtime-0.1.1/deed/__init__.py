"""
DEED — Contractual runtime for AI agents.

Pre/post contracts. Policy enforcement. Credits metering.
Checkpoint & replay. Dead letter queue.

Quick start:

    from deed import DeedRuntime, ContractViolation, PolicyViolation

    runtime = DeedRuntime(".")
    runtime.register("score_company", my_scorer, charge=1)
    result = runtime.run("my_pipeline", "input/state.json")

Docs: https://docs.deed.dev
"""

from deed.runtime import DeedRuntime
from deed.errors import ContractViolation, PolicyViolation, DeedError
from deed.x402 import X402Client

__version__ = "0.1.0"
__all__ = [
    "DeedRuntime",
    "ContractViolation",
    "PolicyViolation",
    "DeedError",
    "X402Client",
]
