"""
DEED .dd file parser.

Parses agent, pipeline, contract, policy, observe blocks
into a JSON-serialisable AST list.

Each node has:
    _type: 'agent' | 'pipeline' | 'contract'
    _name: str
    _stages: list   (sub-blocks)
    ...fields

Usage:
    from deed.parser import parse_dd
    ast = parse_dd(Path("my_agent.dd").read_text())
"""

from __future__ import annotations


def _scalar(raw: str):
    """Convert a raw string value to a Python scalar."""
    raw = raw.strip()
    if raw.startswith('"') and raw.endswith('"'):
        return raw[1:-1]
    if raw == 'true':
        return True
    if raw == 'false':
        return False
    if raw.startswith('[') and raw.endswith(']'):
        items = [x.strip().strip('"') for x in raw[1:-1].split(',') if x.strip()]
        return items
    try:
        return float(raw) if '.' in raw else int(raw)
    except ValueError:
        return raw


def parse_dd(text: str) -> list:
    """
    Parse a .dd source string into an AST node list.

    Returns:
        List of dicts, each with _type, _name, and block-specific fields.
    """
    lines = [
        (len(r) - len(r.lstrip(' ')), r.strip())
        for r in text.splitlines()
        if r.strip() and not r.strip().startswith('#')
    ]
    ast_nodes: list = []
    i = 0

    while i < len(lines):
        indent, line = lines[i]

        # ── agent block ───────────────────────────────────────────────
        if line.startswith('agent '):
            node = {
                '_type': 'agent', '_name': line.split(' ', 1)[1],
                'policy': [], 'contracts': [], 'observe': {}, '_stages': [],
            }
            i += 1
            while i < len(lines) and lines[i][0] > indent:
                ind2, line2 = lines[i]

                if line2.startswith('description '):
                    node['description'] = _scalar(line2[len('description '):])

                elif line2.startswith('capabilities '):
                    node['capabilities'] = _scalar(line2[len('capabilities '):])

                elif line2 == 'policy':
                    i += 1
                    while i < len(lines) and lines[i][0] > ind2:
                        _, pl = lines[i]
                        if pl.startswith('cap '):
                            rest = pl[4:]
                            for op in ('<=', '>=', '==', '<', '>'):
                                if op in rest:
                                    left, right = rest.split(op, 1)
                                    node['policy'].append({
                                        'kind': 'cap',
                                        'expr': left.strip(),
                                        'op': op,
                                        'value': _scalar(right.strip()),
                                    })
                                    break
                        elif pl.startswith('allow '):
                            if ' if ' in pl:
                                action, cond = pl[6:].split(' if ', 1)
                                node['policy'].append({
                                    'kind': 'allow',
                                    'action': action.strip(),
                                    'if': cond.strip(),
                                })
                        elif pl.startswith('deny '):
                            if ' if ' in pl:
                                action, cond = pl[5:].split(' if ', 1)
                                node['policy'].append({
                                    'kind': 'deny',
                                    'action': action.strip(),
                                    'if': cond.strip(),
                                })
                        i += 1
                    continue

                elif line2.startswith('contract '):
                    c = {'_type': 'contract', '_name': line2.split(' ', 1)[1]}
                    i += 1
                    while i < len(lines) and lines[i][0] > ind2:
                        _, cl = lines[i]
                        key, value = cl.split(' ', 1)
                        c[key] = value.strip()
                        i += 1
                    node['contracts'].append(c)
                    continue

                elif line2 == 'observe':
                    i += 1
                    while i < len(lines) and lines[i][0] > ind2:
                        _, ol = lines[i]
                        key, value = ol.split(' ', 1)
                        node['observe'][key] = _scalar(value)
                        i += 1
                    continue

                i += 1
            ast_nodes.append(node)
            continue

        # ── pipeline block ────────────────────────────────────────────
        if line.startswith('pipeline '):
            node = {
                '_type': 'pipeline', '_name': line.split(' ', 1)[1],
                '_stages': [], 'observe': {},
            }
            i += 1
            while i < len(lines) and lines[i][0] > indent:
                ind2, line2 = lines[i]

                if line2.startswith('description '):
                    node['description'] = _scalar(line2[len('description '):])

                elif line2.startswith('input '):
                    node['input'] = _scalar(line2[len('input '):])

                elif line2.startswith('stage '):
                    st = {
                        '_type': 'stage',
                        '_name': line2.split(' ', 1)[1],
                        'steps': [],
                    }
                    i += 1
                    while i < len(lines) and lines[i][0] > ind2:
                        _, sl = lines[i]
                        if sl.startswith('agent '):
                            st['agent'] = sl[len('agent '):].strip()
                        elif sl.startswith('-> '):
                            st['steps'].append({'action': sl[3:].strip().rstrip('()')})
                        elif sl.startswith('checkpoint '):
                            st['checkpoint'] = sl[len('checkpoint '):].strip()
                        elif sl.startswith('on_error '):
                            st['on_error'] = sl[len('on_error '):].strip()
                        i += 1
                    node['_stages'].append(st)
                    continue

                elif line2 == 'observe':
                    i += 1
                    while i < len(lines) and lines[i][0] > ind2:
                        _, ol = lines[i]
                        key, value = ol.split(' ', 1)
                        node['observe'][key] = _scalar(value)
                        i += 1
                    continue

                i += 1
            ast_nodes.append(node)
            continue

        i += 1

    return ast_nodes
