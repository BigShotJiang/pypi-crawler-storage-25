"""
DEED Credits client.

Interface is forward-compatible with the x402 payment protocol.
When x402 matures, swap X402Client for a real on-chain client
without changing any other code.

Units:
    1 credit = 1 deed execution
    Credits are integers to avoid floating-point drift.

Cloud:
    In the managed DEED cloud, credits are injected automatically
    per workspace balance. Self-hosted: pass initial_credits manually.
"""

from deed.errors import InsufficientCredits


class X402Client:
    """
    DEED Credits metering client.

    Usage:
        x402 = X402Client(initial_credits=1000)
        x402.charge(1)          # deduct 1 credit
        print(x402.credits)     # 999
        print(x402.spent)       # 1
    """

    def __init__(self, initial_credits: int = 100):
        if initial_credits < 0:
            raise ValueError("initial_credits must be >= 0")
        self.credits: int = initial_credits
        self.spent:   int = 0

    def charge(self, amount: int = 1) -> int:
        """
        Deduct credits. Raises InsufficientCredits if balance is too low.
        Returns remaining balance.
        """
        if amount <= 0:
            raise ValueError("charge amount must be > 0")
        if self.credits < amount:
            raise InsufficientCredits(
                f"insufficient DEED credits: need {amount}, have {self.credits}. "
                f"Top up at https://deed.dev/credits"
            )
        self.credits -= amount
        self.spent   += amount
        return self.credits

    def refund(self, amount: int = 1) -> int:
        """Refund credits on post-condition failure."""
        self.credits += amount
        self.spent   = max(0, self.spent - amount)
        return self.credits

    @property
    def total_used(self) -> int:
        return self.spent

    def __repr__(self) -> str:
        return f"X402Client(credits={self.credits}, spent={self.spent})"
