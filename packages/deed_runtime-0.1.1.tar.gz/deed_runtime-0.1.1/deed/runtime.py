"""
DEED Runtime — core execution engine.

Lifecycle per deed:
    1. PolicyEngine.check()      — cap / allow / deny
    2. check_contracts(pre)      — pre-condition
    3. executor(context)         — your function
    4. check_contracts(post)     — post-condition
    5. CheckpointStore.save()    — persist state

Usage:

    from deed import DeedRuntime

    def score_company(context: dict) -> dict:
        context['score'] = 0.82
        context['score_generated'] = True
        return context

    runtime = DeedRuntime(".")
    runtime.register("score_company", score_company, charge=1)
    result = runtime.run("my_pipeline", "input/state.json")
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Callable

from deed.parser import parse_dd
from deed.policy import PolicyEngine
from deed.contracts import check_contracts
from deed.checkpoint import CheckpointStore
from deed.x402 import X402Client
from deed.errors import ContractViolation, PolicyViolation, InsufficientCredits


class DeedRuntime:
    """
    DEED contractual runtime.

    Args:
        project_root:           path to your project (must contain deeds/)
        replay:                 resume from last checkpoint if True
        initial_credits:        starting credit balance (default 100)
        named_predicates_fn:    optional callable(context) → dict[str, bool]
                                for domain-specific named predicates
        output_dir:             where to write trace, checkpoint, dlq
                                (default: <project_root>/output)
    """

    def __init__(
        self,
        project_root: str = '.',
        replay: bool = False,
        initial_credits: int = 100,
        named_predicates_fn: Callable | None = None,
        output_dir: str | None = None,
    ):
        self.project_root = Path(project_root).resolve()
        self.replay       = replay

        # Output directory
        out = Path(output_dir) if output_dir else self.project_root / 'output'
        out.mkdir(parents=True, exist_ok=True)
        self._output_dir = out

        # Credits
        self.x402 = X402Client(initial_credits=initial_credits)

        # Executor registry — populated via register()
        self._executor: dict[str, Callable] = {}
        self._deed_meta: dict[str, dict]    = {}  # charge, retry, idempotency_key

        # Load and parse all .dd files from deeds/
        self._ast: list = []
        deeds_dir = self.project_root / 'deeds'
        if deeds_dir.exists():
            for dd_file in sorted(deeds_dir.rglob('*.dd')):
                self._ast.extend(
                    parse_dd(dd_file.read_text(encoding='utf-8'))
                )

        # Build maps
        self._agent_map    = {n['_name']: n for n in self._ast if n.get('_type') == 'agent'}
        self._pipeline_map = {n['_name']: n for n in self._ast if n.get('_type') == 'pipeline'}

        # Policy engine
        self._policy = PolicyEngine(self._ast, named_predicates_fn)
        self._named_fn = named_predicates_fn

        # Internal state
        self._trace:  list = []
        self._checkpoints = CheckpointStore(str(self._output_dir / 'checkpoint.json'))

    # ── Public API ────────────────────────────────────────────────────────────

    def register(
        self,
        action: str,
        fn: Callable,
        charge: int = 1,
        retry: int = 0,
        idempotency_key: str | None = None,
    ) -> 'DeedRuntime':
        """
        Register an executor function for an action name.

        Args:
            action:           action name as used in .dd pipeline stages
            fn:               callable(context: dict) -> dict
                              Must return the updated context dict.
            charge:           credits to charge per execution (default 1)
            retry:            max retry attempts on transient failure (default 0)
            idempotency_key:  context key used to deduplicate executions

        Returns:
            self (for chaining)

        Example:
            runtime.register("score_company", my_scorer, charge=1, retry=2)
            runtime.register("send_alert",    alerter,   charge=1)
        """
        self._executor[action]  = fn
        self._deed_meta[action] = {
            'charge':           charge,
            'retry':            retry,
            'idempotency_key':  idempotency_key,
        }
        return self

    def run(self, pipeline_name: str, input_path: str) -> dict:
        """
        Execute a pipeline end-to-end.

        Args:
            pipeline_name:  name of pipeline block in .dd file
            input_path:     path to JSON input (relative to project_root)

        Returns:
            Final context dict with 'run_status': 'completed' | 'failed'

        Raises:
            KeyError if pipeline_name not found in .dd files
        """
        if pipeline_name not in self._pipeline_map:
            available = list(self._pipeline_map.keys())
            raise KeyError(
                f"pipeline '{pipeline_name}' not found. "
                f"Available: {available}"
            )

        pipeline = self._pipeline_map[pipeline_name]
        input_file = self.project_root / input_path
        context = json.loads(input_file.read_text(encoding='utf-8'))
        context['run_status'] = 'running'

        # Replay: restore from last checkpoint
        checkpoint_data = self._checkpoints.load()
        if self.replay and checkpoint_data.get('context'):
            context.update(checkpoint_data['context'])

        named = self._named_fn(context) if self._named_fn else {}

        for stage in pipeline.get('_stages', []):
            stage_name = stage['_name']
            agent_name = stage.get('agent', '')
            agent_node = self._agent_map.get(agent_name, {})

            print(f'[DEED] stage: {stage_name}')
            self._trace.append({'event': 'stage_started', 'stage': stage_name})

            try:
                # Pre-condition check
                check_contracts(agent_node, context, 'pre', named)

                for step in stage.get('steps', []):
                    action  = step['action']
                    step_id = f'{stage_name}::{action}'

                    # Replay skip
                    if self.replay and step_id in checkpoint_data.get('completed_steps', []):
                        print(f'[DEED] replay skip: {step_id}')
                        continue

                    # Refresh named predicates
                    named = self._named_fn(context) if self._named_fn else {}

                    # Policy gate
                    self._policy.check(context, agent_name, action)

                    # Executor lookup
                    fn = self._executor.get(action)
                    if fn is None:
                        raise KeyError(
                            f"no executor registered for action '{action}'. "
                            f"Call runtime.register('{action}', your_fn) before run()."
                        )

                    # Credits charge
                    meta   = self._deed_meta.get(action, {'charge': 1, 'retry': 0})
                    charge = meta['charge']
                    self.x402.charge(charge)
                    print(f'[DEED] charged: {charge} credit(s) | balance: {self.x402.credits}')

                    # Execute with retry
                    max_attempts = meta.get('retry', 0) + 1
                    on_error     = stage.get('on_error', 'deadletter')
                    last_exc     = None

                    for attempt in range(1, max_attempts + 1):
                        try:
                            context = fn(context)
                            if not isinstance(context, dict):
                                raise TypeError(
                                    f"executor '{action}' must return a dict, "
                                    f"got {type(context).__name__}"
                                )
                            # Refresh named predicates after execution
                            named = self._named_fn(context) if self._named_fn else {}
                            self._trace.append({'event': 'step_ok', 'stage': stage_name, 'action': action})
                            self._checkpoints.save(step_id, context)
                            print(f'[DEED] checkpoint: {step_id}')
                            last_exc = None
                            break
                        except (ContractViolation, PolicyViolation, InsufficientCredits):
                            raise  # don't retry typed DEED errors
                        except Exception as exc:
                            last_exc = exc
                            if attempt < max_attempts:
                                self._trace.append({
                                    'event': 'retry', 'stage': stage_name,
                                    'action': action, 'attempt': attempt,
                                })
                            continue

                    if last_exc is not None:
                        self._write_dlq(stage_name, action, str(last_exc), context)
                        raise last_exc

                # Post-condition check
                named = self._named_fn(context) if self._named_fn else {}
                check_contracts(agent_node, context, 'post', named)

            except (ContractViolation, PolicyViolation, InsufficientCredits) as exc:
                context['run_status'] = 'failed'
                self._write_dlq(stage_name, action if 'action' in dir() else 'pre_check', str(exc), context)
                self._trace.append({'event': 'stage_failed', 'stage': stage_name, 'error': str(exc)})
                print(f'[DEED] DLQ: {stage_name} | {type(exc).__name__}: {exc}')
                break

            except Exception as exc:
                context['run_status'] = 'failed'
                self._write_dlq(stage_name, 'unknown', str(exc), context)
                self._trace.append({'event': 'stage_error', 'stage': stage_name, 'error': str(exc)})
                print(f'[DEED] error: {stage_name} | {exc}')
                break
        else:
            context['run_status'] = 'completed'

        self._flush(context)
        return context

    # ── Internals ─────────────────────────────────────────────────────────────

    def _write_dlq(self, stage: str, action: str, error: str, context: dict) -> None:
        path = self._output_dir / 'deed.dlq'
        entry = {
            'stage':   stage,
            'action':  action,
            'error':   error,
            'context': context,
        }
        with open(path, 'a', encoding='utf-8') as f:
            f.write(json.dumps(entry, ensure_ascii=False) + '\n')

    def _flush(self, context: dict) -> None:
        (self._output_dir / 'trace.json').write_text(
            json.dumps(self._trace, indent=2, ensure_ascii=False),
            encoding='utf-8',
        )
        (self._output_dir / 'final_result.json').write_text(
            json.dumps(context, indent=2, ensure_ascii=False),
            encoding='utf-8',
        )
