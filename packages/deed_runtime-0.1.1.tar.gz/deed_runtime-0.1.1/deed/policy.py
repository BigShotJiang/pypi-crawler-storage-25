"""
DEED Policy Engine.

Evaluates cap / allow / deny rules against runtime context.
Rules are checked BEFORE execution — no side effects on violation.

Semantics (v0.1):
    - cap:   context[field] must satisfy the operator constraint
    - deny:  if condition is true → blocked immediately
    - allow: if at least one allow rule matches → permitted
             if NO allow rules exist for this action → permitted (fail-open)
             if allow rules exist but NONE match → PolicyViolation

Note: v0.2 changes to fail-closed (no allow rules → violation).
"""

from __future__ import annotations
import re
from deed.errors import PolicyViolation


# ── Expression evaluator ──────────────────────────────────────────────────────

_CMP_RE = re.compile(
    r'^(.+?)\s*(==|!=|<=|>=|<|>)\s*(.+)$'
)


def _resolve(token: str, context: dict):
    """Resolve a token to a Python value from context or as a literal."""
    token = token.strip()
    # String literal
    if token.startswith('"') and token.endswith('"'):
        return token[1:-1]
    # Bool literal
    if token == 'true':
        return True
    if token == 'false':
        return False
    # Null literal
    if token == 'null':
        return None
    # Numeric literal
    try:
        return float(token) if '.' in token else int(token)
    except ValueError:
        pass
    # Dotted path: input.balance → context.get('balance') or context.get('input', {}).get('balance')
    if '.' in token:
        parts = token.split('.', 1)
        root = context.get(parts[0])
        if isinstance(root, dict):
            return root.get(parts[1])
        # Try stripping the prefix (input.x → x)
        return context.get(parts[1])
    return context.get(token)


def eval_expr(expr: str, context: dict, named: dict | None = None) -> bool:
    """
    Evaluate a boolean expression against context.

    Supports:
        named predicates:   observation_present
        comparisons:        input.balance > 0, score == 0.9
        logical:            a and b, a or b, not a
        compound:           enriched and score >= 0.7
    """
    expr = expr.strip()

    # Named predicate lookup (highest priority)
    if named and expr in named:
        return bool(named[expr])

    # not <expr>
    if expr.startswith('not '):
        return not eval_expr(expr[4:].strip(), context, named)

    # <left> and <right>  (split on last ' and ')
    if ' and ' in expr:
        parts = expr.split(' and ', 1)
        return eval_expr(parts[0], context, named) and eval_expr(parts[1], context, named)

    # <left> or <right>
    if ' or ' in expr:
        parts = expr.split(' or ', 1)
        return eval_expr(parts[0], context, named) or eval_expr(parts[1], context, named)

    # Comparison: left OP right
    m = _CMP_RE.match(expr)
    if m:
        left_raw, op, right_raw = m.groups()
        # Re-check named predicates for left side
        left_key = left_raw.strip()
        if named and left_key in named:
            left = named[left_key]
        else:
            left = _resolve(left_raw, context)
        right = _resolve(right_raw, context)
        if left is None or right is None:
            return False
        ops = {'==': lambda a, b: a == b, '!=': lambda a, b: a != b,
               '<':  lambda a, b: a < b,  '>':  lambda a, b: a > b,
               '<=': lambda a, b: a <= b, '>=': lambda a, b: a >= b}
        return ops[op](left, right)

    # Plain context key or named predicate
    if named and expr in named:
        return bool(named[expr])
    val = context.get(expr)
    if val is None:
        return False
    return bool(val)


# ── Policy Engine ─────────────────────────────────────────────────────────────

class PolicyEngine:
    """
    Evaluates policy rules for an agent action.

    Usage:
        engine = PolicyEngine(ast_nodes)
        engine.check(context, agent_name='score_agent', action='score_company')
        # raises PolicyViolation if blocked
    """

    def __init__(self, ast_nodes: list, named_predicates_fn=None):
        """
        Args:
            ast_nodes: parsed AST from parse_dd()
            named_predicates_fn: optional callable(context) → dict[str, bool]
                                 for domain-specific named predicates
        """
        self._ast = ast_nodes
        self._named_fn = named_predicates_fn
        self._agent_map = {
            n['_name']: n for n in ast_nodes if n.get('_type') == 'agent'
        }

    def _named(self, context: dict) -> dict:
        if self._named_fn:
            return self._named_fn(context)
        return {}

    def check(self, context: dict, agent_name: str, action: str) -> None:
        """
        Check all policy rules for agent_name::action against context.

        Raises PolicyViolation if any rule blocks the action.
        Returns None if all rules pass.
        """
        agent = self._agent_map.get(agent_name)
        if not agent:
            return  # unknown agent → no policy → allow
        rules  = agent.get('policy', [])
        named  = self._named(context)

        # 1. Cap rules (resource limits)
        for rule in rules:
            if rule['kind'] != 'cap':
                continue
            field = rule['expr']
            op    = rule['op']
            limit = rule['value']
            val   = context.get(field)
            if val is None:
                continue
            ops = {'<=': lambda a, b: a <= b, '>=': lambda a, b: a >= b,
                   '==': lambda a, b: a == b, '<':  lambda a, b: a < b,
                   '>':  lambda a, b: a > b}
            if not ops[op](val, limit):
                raise PolicyViolation(
                    f"cap violated: {field} {op} {limit} "
                    f"(actual: {val}) for agent '{agent_name}'"
                )

        # 2. Deny rules
        for rule in rules:
            if rule['kind'] != 'deny' or rule.get('action') != action:
                continue
            if eval_expr(rule['if'], context, named):
                raise PolicyViolation(
                    f"deny rule blocked '{action}' for agent '{agent_name}': "
                    f"condition '{rule['if']}' is true"
                )

        # 3. Allow rules (fail-open in v0.1 if no allow rules defined)
        allow_rules = [r for r in rules if r['kind'] == 'allow' and r.get('action') == action]
        if not allow_rules:
            return  # no allow rules → permitted (v0.1 semantics)

        for rule in allow_rules:
            if eval_expr(rule['if'], context, named):
                return  # at least one allow matched

        raise PolicyViolation(
            f"no allow rule matched for action '{action}' "
            f"in agent '{agent_name}'. "
            f"Add 'allow {action} if <predicate>' to the policy block, "
            f"or 'allow {action} if true' to permit unconditionally."
        )
