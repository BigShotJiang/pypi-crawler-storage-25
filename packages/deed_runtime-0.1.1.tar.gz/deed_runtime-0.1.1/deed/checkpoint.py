"""
DEED Checkpoint store.

Persists completed steps and context to disk.
Enables replay: resume from last known good state
without re-executing completed steps or re-charging credits.
"""

from __future__ import annotations
import json
from pathlib import Path


class CheckpointStore:
    """
    JSON-backed checkpoint store.

    Format:
        {
            "completed_steps": ["stage::action", ...],
            "context": {...}
        }

    Usage:
        store = CheckpointStore("output/checkpoint.json")
        store.save("intake::normalize", context)
        data = store.load()
        if "intake::normalize" in data["completed_steps"]:
            # skip
    """

    def __init__(self, path: str):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if not self.path.exists():
            self._write({'completed_steps': [], 'context': {}})

    def _write(self, data: dict) -> None:
        self.path.write_text(
            json.dumps(data, indent=2, ensure_ascii=False),
            encoding='utf-8',
        )

    def load(self) -> dict:
        """Load checkpoint data. Returns empty structure if file missing."""
        try:
            return json.loads(self.path.read_text(encoding='utf-8'))
        except (FileNotFoundError, json.JSONDecodeError):
            return {'completed_steps': [], 'context': {}}

    def save(self, step_id: str, context: dict) -> None:
        """Mark step as completed and persist context."""
        data = self.load()
        if step_id not in data['completed_steps']:
            data['completed_steps'].append(step_id)
        data['context'] = context
        self._write(data)

    def clear(self) -> None:
        """Reset checkpoint — use before a fresh run."""
        self._write({'completed_steps': [], 'context': {}})
