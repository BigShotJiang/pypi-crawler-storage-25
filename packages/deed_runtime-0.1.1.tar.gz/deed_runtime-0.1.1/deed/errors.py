"""
Typed exceptions for DEED runtime.

Hierarchy:
    DeedError
    ├── ContractViolation   — pre/post condition failed
    ├── PolicyViolation     — cap / allow / deny blocked action
    └── InsufficientCredits — x402 balance too low
"""


class DeedError(Exception):
    """Base class for all DEED runtime errors."""


class ContractViolation(DeedError):
    """
    A pre-condition or post-condition check failed.

    Raised before execution (pre) — no side effects occurred.
    Raised after execution (post) — action ran but outcome invalid.
    """


class PolicyViolation(DeedError):
    """
    A policy rule blocked the action.

    Possible causes:
    - cap:   context field exceeded limit
    - deny:  deny rule matched
    - allow: no allow rule matched for this action

    The action was NOT executed. No credits were charged.
    """


class InsufficientCredits(DeedError):
    """
    DEED Credits balance too low to execute this action.

    Top up at https://deed.dev/credits
    """
