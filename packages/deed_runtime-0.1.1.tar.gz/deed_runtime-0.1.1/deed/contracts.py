"""
DEED Contract checker.

Verifies pre and post conditions on agent nodes.
Uses the policy eval_expr engine for expression evaluation.
"""

from __future__ import annotations
from deed.errors import ContractViolation
from deed.policy import eval_expr


def check_contracts(
    agent_node: dict,
    context: dict,
    phase: str,                        # 'pre' | 'post'
    named_predicates: dict | None = None,
) -> None:
    """
    Evaluate all contracts on an agent for the given phase.

    Args:
        agent_node:         AST node with _type='agent'
        context:            current runtime context dict
        phase:              'pre' (before execution) or 'post' (after)
        named_predicates:   optional dict of bool values for named predicates

    Raises:
        ContractViolation if any contract condition fails.
    """
    named = named_predicates or {}
    contracts = agent_node.get('contracts', [])

    for contract in contracts:
        condition = contract.get(phase)
        if not condition:
            continue

        if not eval_expr(condition, context, named):
            raise ContractViolation(
                f"agent '{agent_node['_name']}' "
                f"contract '{contract['_name']}' "
                f"failed {phase}: {condition}"
            )
