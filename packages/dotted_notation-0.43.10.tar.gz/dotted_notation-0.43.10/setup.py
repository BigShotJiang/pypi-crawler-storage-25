import setuptools

with open("README.md", "rt") as f:
    long_description = f.read()

setuptools.setup(
    name="dotted_notation",
    version="0.43.10",
    author="Frey Waid",
    author_email="logophage1@gmail.com",
    description="Dotted notation for safe nested data traversal with optional chaining, pattern matching, and transforms",
    license="MIT",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/freywaid/dotted",
    project_urls={
        "Changelog": "https://github.com/freywaid/dotted/blob/master/CHANGELOG.md",
        "Source":    "https://github.com/freywaid/dotted",
    },
    packages=setuptools.find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
    install_requires=['pyparsing>=3.0'],
    entry_points={
        'console_scripts': [
            'dq=dotted.cli.main:main',
        ],
    },
    extras_require={
        'yaml': ['PyYAML>=5.0'],
        'toml': ['tomli>=1.0;python_version<"3.11"', 'tomli_w>=1.0'],
        'all': [
            'PyYAML>=5.0',
            'tomli>=1.0;python_version<"3.11"',
            'tomli_w>=1.0',
        ],
    },
)
