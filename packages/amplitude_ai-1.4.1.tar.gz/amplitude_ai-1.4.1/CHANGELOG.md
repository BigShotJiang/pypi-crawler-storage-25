# Changelog

## 1.4.1 (2026-04-17)

### Features

- **Auto-generated `trace_id` on session entry.** `Session.__enter__` and
  `__aenter__` now generate a UUID v4 `trace_id` when none has been set,
  ensuring all events within the session are grouped by trace without
  requiring an explicit `new_trace()` call.
- **`track_session_end` option.** `Session` (and `BoundAgent.session()`)
  accepts `track_session_end=False` to suppress the automatic
  `[Agent] Session End` event on exit. Useful for middleware or delegation
  contexts where session lifecycle is managed externally.

## Unreleased

### Breaking

- **`PrivacyConfig(redact_pii=...)` now defaults to `True`.** Calls that
  relied on the previous default of `False` will now have common PII
  patterns (emails, phone numbers, credit cards, SSNs) redacted from
  tracked content. Pass `redact_pii=False` explicitly to opt back in to
  raw content. `privacy_mode` is unaffected.

### Features

- **Auto parent-agent inheritance.** When a new `SessionContext` is
  constructed inside an enclosing session and no explicit
  `parent_agent_id` is provided, it is inherited from the enclosing
  session's `agent_id`. Makes nested / sibling-agent flows surface the
  correct caller-chain identity without extra boilerplate.
- **User-message tracking in the streaming path.** `SimpleStreamingTracker`
  now emits `track_user_message` for each new user-role message in the
  input list when the stream is finalized, matching the existing
  behavior of the non-streaming `track_completion()` path. Pass
  `_skip_auto_user_tracking=True` to suppress.
- **Real tool-call latency.** The auto tool-call extractor now reports
  the wall-clock delta between a completion's tool_use block and the
  next completion's matching tool_result, instead of always reporting
  zero. Bounded in-process registry caps memory at 10,000 pending entries
  with a 10-minute TTL.
- **`expected_providers` drift warning.** `patch(amplitude, expected_providers=[...])`
  now logs a one-time warning if the set of providers actually patched at
  runtime doesn't match what the caller declared. Warn-only: never raises,
  never blocks instrumentation.

### Fixes

- `redact_pii_patterns()` silently skips non-string inputs instead of
  raising a `TypeError`. This makes callers that forward partially-typed
  content (e.g. tool outputs that may be objects) safe to run with PII
  redaction enabled.

## 1.2.6 (2026-04-06)

### Improvements

- **Agent / MCP documentation**: `amplitude-ai.md` content-shaping section is excerpted into `llms-full.txt`; MCP `search_docs` includes the shipped guide; `instrument_app` prompt directs agents to read `amplitude-ai://instrument-guide` and use `track_user_message` vs `context=` for structured payloads. Contract tests cover markers and doc paths.

### Dependencies

- Refreshed the package-local `uv.lock` (required for `uv lock --check` in CI); bumped transitive **grpcio** to **1.80.0** to avoid yanked **1.70.x** / **1.78.x** releases pulled in by optional stacks.

## 1.2.5 (2026-04-03)

### Improvements

- **Coding agent guide (`amplitude-ai.md`)**: Document OpenAI-compatible proxies/gateways, user message text vs `context=` for structured payloads, spans vs turn-level `[Agent] User Message` / `[Agent] AI Response`, and manual `usage` + real model id for genai-prices.
- **Developer testing**: Optional `dev` extra (`pytest`, `pytest-asyncio`) and `[tool.pytest.ini_options]` for async tests.
- **Repository CI**: GitHub Actions for PR and scheduled runs (OpenAI minor matrix, optional-extras smoke, `uv lock --check`); Dependabot grouped updates for this package.

## 1.2.4 (2026-03-31)

### Bug Fixes

- **Finalize guard ordering**: `_finalized` flag in `SimpleStreamingTracker.finalize()` is now set *after* event emission, so `finalize_on_abandon()` can retry if event construction fails.
- **Patch kwargs forwarding**: `PatchedOpenAI`, `PatchedAsyncOpenAI`, `PatchedAnthropic`, and `PatchedAzureOpenAI` now correctly forward all non-Amplitude kwargs (e.g. `base_url`, `headers`) to the underlying provider wrapper.
- **AsyncAzureOpenAI error message**: `wrap()` rejection message now accurately recommends sync `AzureOpenAI` with `wrap()` or `patch_azure_openai()` instead of incorrectly suggesting `patch()`.
- **Abandoned stream model resolution**: `finalize_on_abandon()` now prefers the response-resolved model name (captured from chunks) over the caller-supplied fallback, matching normal-path behavior.

## 1.2.3 (2026-03-31)

### Bug Fixes

- **P1 — Streaming `GeneratorExit` finalization**: All streaming generators (OpenAI, Anthropic, Gemini — sync and async) now use `finalize_on_abandon()` with an idempotent `finalize()`. If a consumer breaks early or closes the generator, tracking data is still emitted with `[Agent] Stream Abandoned = true`.
- **P2 — Gemini provider normalization**: `_normalize_provider_for_genai_prices("gemini")` now correctly returns `"google"`, enabling accurate cost calculation for Gemini models.
- **`wrap()` rejects `AsyncAzureOpenAI`**: `wrap()` now raises `AmplitudeAIWrapError` for `openai.AsyncAzureOpenAI` instances instead of silently misrouting them through the `AsyncOpenAI` path.

### Improvements

- **`SimpleStreamingTracker.finalize()` is idempotent**: Second and subsequent calls are silent no-ops, eliminating the risk of double-tracking.
- **`finalize_on_abandon()` helper**: New method on `SimpleStreamingTracker` encapsulates the abandoned-stream finalization pattern, reducing code duplication across all 6 streaming methods.
- **`[Agent] Stream Abandoned` event property**: When a streaming response is abandoned (consumer broke early or generator closed), the tracking event includes this property for analytics visibility.

## 1.2.2 (2026-03-30)

### Features

- **CLI `--print-guide` flag**: `amplitude-ai --print-guide` prints the full instrumentation guide to stdout.
- **Opinionated documentation**: README now recommends full-instrumentation golden path for both coding-agent and manual workflows.
- **Session lifecycle clarification**: Documented that `track_session_end()` is optional and that the server auto-closes sessions after 30 minutes of inactivity.
- **`tiktoken` made optional**: Token counting gracefully degrades when `tiktoken` is not installed.
- **`AsyncOpenAI` support**: Full async OpenAI client wrapper with streaming support.
