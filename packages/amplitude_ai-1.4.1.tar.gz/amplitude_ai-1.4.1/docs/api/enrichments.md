# Enrichments

Session enrichment types for attaching structured classifications and quality scores to Agent sessions.

## SessionEnrichments

::: amplitude_ai.core.enrichments.SessionEnrichments

## TopicClassification

::: amplitude_ai.core.enrichments.TopicClassification

## RubricScore

::: amplitude_ai.core.enrichments.RubricScore
