# Testing

The `MockAmplitudeAI` utility provides a drop-in replacement for `AmplitudeAI` in unit tests. It captures all tracked events in memory without making network calls.

## Quick Start

```python
from amplitude_ai import MockAmplitudeAI

def test_my_feature():
    ai = MockAmplitudeAI()

    # Exercise code that calls ai.track_user_message(), ai.score(), etc.
    ai.track_user_message(
        user_id="user-1",
        content="test message",
        session_id="sess-1",
    )

    # Assert on captured events
    assert len(ai.events) == 1
    assert ai.events[0].event_type == "[Agent] User Message"
```

## API Reference

::: amplitude_ai.testing.MockAmplitudeAI
