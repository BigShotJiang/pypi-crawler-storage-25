"""Tests for the Claude Agent SDK integration tracker."""

from __future__ import annotations

import asyncio
import time
from typing import Any
from unittest.mock import MagicMock, patch

import pytest

from amplitude_ai.integrations.claude_agent_sdk import ClaudeAgentSDKTracker


def _make_session() -> MagicMock:
    """Create a mock session with the standard tracking methods."""
    session = MagicMock()
    session.track_tool_call.return_value = "tool-1"
    session.track_ai_message.return_value = "ai-1"
    session.track_user_message.return_value = "user-1"
    return session


def _run(coro: Any) -> Any:
    """Run an async function synchronously for testing."""
    return asyncio.get_event_loop().run_until_complete(coro)


class TestHooks:
    def test_returns_pre_and_post_tool_use_hooks(self) -> None:
        tracker = ClaudeAgentSDKTracker()
        session = _make_session()
        hooks = tracker.hooks(session)

        assert "PreToolUse" in hooks
        assert "PostToolUse" in hooks
        assert len(hooks["PreToolUse"]) == 1
        assert len(hooks["PostToolUse"]) == 1
        assert hooks["PreToolUse"][0]["matcher"] is None
        assert hooks["PostToolUse"][0]["matcher"] is None

    def test_tracks_tool_call_with_latency(self) -> None:
        tracker = ClaudeAgentSDKTracker()
        session = _make_session()
        hooks = tracker.hooks(session)

        pre_hook = hooks["PreToolUse"][0]["hooks"][0]
        post_hook = hooks["PostToolUse"][0]["hooks"][0]

        # Manually inject a known timer value instead of mocking time.monotonic
        # (which interferes with asyncio's event loop).
        _run(pre_hook({"tool_name": "search"}, "tu_abc", {}))
        # Override the stored timer to a known value
        tracker._tool_timers["tu_abc"] = time.monotonic() - 0.35

        _run(post_hook(
            {
                "tool_name": "search",
                "tool_input": {"query": "shoes"},
                "tool_response": "3 results found",
            },
            "tu_abc",
            {},
        ))

        session.track_tool_call.assert_called_once()
        kwargs = session.track_tool_call.call_args.kwargs
        assert kwargs["tool_name"] == "search"
        assert kwargs["success"] is True
        assert kwargs["latency_ms"] >= 300  # ~350ms, with some tolerance
        assert kwargs["input"] == {"query": "shoes"}
        assert kwargs["output"] == "3 results found"

    def test_tracks_failed_tool_call(self) -> None:
        tracker = ClaudeAgentSDKTracker()
        session = _make_session()
        hooks = tracker.hooks(session)

        pre_hook = hooks["PreToolUse"][0]["hooks"][0]
        post_hook = hooks["PostToolUse"][0]["hooks"][0]

        _run(pre_hook({}, "tu_err", {}))
        tracker._tool_timers["tu_err"] = time.monotonic() - 0.1

        _run(post_hook(
            {
                "tool_name": "api_call",
                "tool_input": {"url": "https://example.com"},
                "tool_response": "Connection refused",
                "is_error": True,
            },
            "tu_err",
            {},
        ))

        kwargs = session.track_tool_call.call_args.kwargs
        assert kwargs["success"] is False
        assert kwargs["error_message"] == "Connection refused"

    def test_zero_latency_without_pre_hook(self) -> None:
        tracker = ClaudeAgentSDKTracker()
        session = _make_session()
        hooks = tracker.hooks(session)
        post_hook = hooks["PostToolUse"][0]["hooks"][0]

        _run(post_hook({"tool_name": "read"}, None, {}))

        kwargs = session.track_tool_call.call_args.kwargs
        assert kwargs["latency_ms"] == 0.0

    def test_hooks_return_empty_dict(self) -> None:
        tracker = ClaudeAgentSDKTracker()
        session = _make_session()
        hooks = tracker.hooks(session)

        pre_result = _run(hooks["PreToolUse"][0]["hooks"][0]({}, "tu_1", {}))
        post_result = _run(
            hooks["PostToolUse"][0]["hooks"][0]({"tool_name": "test"}, "tu_1", {})
        )

        assert pre_result == {}
        assert post_result == {}


class TestProcess:
    def test_tracks_assistant_message_with_content_blocks(self) -> None:
        tracker = ClaudeAgentSDKTracker()
        session = _make_session()

        tracker.process(session, {
            "role": "assistant",
            "content": [
                {"type": "text", "text": "Hello!"},
                {"type": "text", "text": " How can I help?"},
            ],
            "model": "claude-sonnet-4-20250514",
            "usage": {"input_tokens": 100, "output_tokens": 20},
        })

        session.track_ai_message.assert_called_once()
        kwargs = session.track_ai_message.call_args.kwargs
        assert kwargs["content"] == "Hello!\n How can I help?"
        assert kwargs["model"] == "claude-sonnet-4-20250514"
        assert kwargs["provider"] == "anthropic"
        assert kwargs["input_tokens"] == 100
        assert kwargs["output_tokens"] == 20

    def test_tracks_assistant_message_with_string_content(self) -> None:
        tracker = ClaudeAgentSDKTracker()
        session = _make_session()

        tracker.process(session, {
            "role": "assistant",
            "content": "Simple text",
            "model": "claude-sonnet-4-20250514",
        })

        kwargs = session.track_ai_message.call_args.kwargs
        assert kwargs["content"] == "Simple text"

    def test_tracks_reasoning_content(self) -> None:
        tracker = ClaudeAgentSDKTracker()
        session = _make_session()

        tracker.process(session, {
            "role": "assistant",
            "content": [
                {"type": "thinking", "thinking": "Let me consider..."},
                {"type": "text", "text": "The answer is 42"},
            ],
            "model": "claude-sonnet-4-20250514",
        })

        kwargs = session.track_ai_message.call_args.kwargs
        assert kwargs["reasoning_content"] == "Let me consider..."

    def test_tracks_user_message(self) -> None:
        tracker = ClaudeAgentSDKTracker()
        session = _make_session()

        tracker.process(session, {
            "role": "user",
            "content": "What is the weather?",
        })

        session.track_user_message.assert_called_once_with("What is the weather?")

    def test_uses_default_model(self) -> None:
        tracker = ClaudeAgentSDKTracker(default_model="claude-opus-4-20250514")
        session = _make_session()

        tracker.process(session, {"role": "assistant", "content": "response"})

        kwargs = session.track_ai_message.call_args.kwargs
        assert kwargs["model"] == "claude-opus-4-20250514"

    def test_uses_custom_provider(self) -> None:
        tracker = ClaudeAgentSDKTracker(default_provider="custom-gateway")
        session = _make_session()

        tracker.process(session, {
            "role": "assistant",
            "content": "response",
            "model": "gpt-4o",
        })

        kwargs = session.track_ai_message.call_args.kwargs
        assert kwargs["provider"] == "custom-gateway"

    def test_ignores_none_messages(self) -> None:
        tracker = ClaudeAgentSDKTracker()
        session = _make_session()

        tracker.process(session, None)

        session.track_ai_message.assert_not_called()
        session.track_user_message.assert_not_called()
        session.track_tool_call.assert_not_called()

    def test_skips_empty_user_messages(self) -> None:
        tracker = ClaudeAgentSDKTracker()
        session = _make_session()

        tracker.process(session, {"role": "user", "content": ""})

        session.track_user_message.assert_not_called()
