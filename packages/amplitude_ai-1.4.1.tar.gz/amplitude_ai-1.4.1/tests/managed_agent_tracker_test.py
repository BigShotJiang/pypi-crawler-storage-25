"""Tests for ManagedAgentTracker (Anthropic Managed Agents integration)."""

from __future__ import annotations

from types import SimpleNamespace
from unittest.mock import MagicMock

import pytest

from amplitude_ai.integrations.anthropic_managed import (
    ManagedAgentTracker,
    _extract_text_content,
)


def _make_session() -> MagicMock:
    session = MagicMock()
    session.track_user_message.return_value = "user-msg-1"
    session.track_ai_message.return_value = "ai-msg-1"
    session.track_tool_call.return_value = "tool-1"
    return session


class TestManagedAgentTracker:
    def test_processes_assistant_message_with_usage(self) -> None:
        tracker = ManagedAgentTracker()
        session = _make_session()

        events = [
            SimpleNamespace(
                type="message",
                role="assistant",
                content=[SimpleNamespace(type="text", text="Hello!")],
                model="claude-sonnet-4-20250514",
                usage=SimpleNamespace(input_tokens=100, output_tokens=50, cost=0.003),
                latency_ms=1200.0,
            ),
        ]

        count = tracker.process_events(session, events)

        assert count == 1
        session.track_ai_message.assert_called_once_with(
            content="Hello!",
            model="claude-sonnet-4-20250514",
            provider="anthropic",
            latency_ms=1200.0,
            input_tokens=100,
            output_tokens=50,
            total_cost_usd=0.003,
        )

    def test_processes_user_message(self) -> None:
        tracker = ManagedAgentTracker()
        session = _make_session()

        events = [
            SimpleNamespace(
                type="message",
                role="user",
                content="What is the weather?",
            ),
        ]

        count = tracker.process_events(session, events)

        assert count == 1
        session.track_user_message.assert_called_once_with("What is the weather?")

    def test_processes_tool_use_event(self) -> None:
        tracker = ManagedAgentTracker()
        session = _make_session()

        events = [
            SimpleNamespace(
                type="tool_use",
                name="search_products",
                duration_ms=350.0,
                is_error=False,
                input={"query": "shoes"},
                output={"results": [{"name": "Sneaker"}]},
            ),
        ]

        count = tracker.process_events(session, events)

        assert count == 1
        session.track_tool_call.assert_called_once_with(
            tool_name="search_products",
            success=True,
            latency_ms=350.0,
            input={"query": "shoes"},
            output={"results": [{"name": "Sneaker"}]},
        )

    def test_processes_failed_tool_call(self) -> None:
        tracker = ManagedAgentTracker()
        session = _make_session()

        events = [
            SimpleNamespace(
                type="tool_use",
                name="api_call",
                duration_ms=100.0,
                is_error=True,
                input={"url": "https://example.com"},
                output=None,
            ),
        ]

        count = tracker.process_events(session, events)

        assert count == 1
        session.track_tool_call.assert_called_once_with(
            tool_name="api_call",
            success=False,
            latency_ms=100.0,
            input={"url": "https://example.com"},
            output=None,
        )

    def test_mixed_event_stream(self) -> None:
        tracker = ManagedAgentTracker()
        session = _make_session()

        events = [
            SimpleNamespace(type="message", role="user", content="Hello"),
            SimpleNamespace(
                type="message",
                role="assistant",
                content=[SimpleNamespace(type="text", text="Hi there!")],
                model="claude-sonnet-4-20250514",
                usage=SimpleNamespace(input_tokens=10, output_tokens=5, cost=None),
                latency_ms=800.0,
            ),
            SimpleNamespace(
                type="tool_use",
                name="lookup",
                duration_ms=200.0,
                is_error=False,
                input={"id": "123"},
                output={"found": True},
            ),
        ]

        count = tracker.process_events(session, events)

        assert count == 3
        session.track_user_message.assert_called_once()
        session.track_ai_message.assert_called_once()
        session.track_tool_call.assert_called_once()

    def test_uses_poll_latency_when_event_has_no_latency(self) -> None:
        tracker = ManagedAgentTracker()
        session = _make_session()

        events = [
            SimpleNamespace(
                type="message",
                role="assistant",
                content="Response text",
                model="claude-sonnet-4-20250514",
                usage=SimpleNamespace(input_tokens=10, output_tokens=5),
            ),
        ]

        tracker.process_events(session, events, poll_latency_ms=500.0)

        call_kwargs = session.track_ai_message.call_args.kwargs
        assert call_kwargs["latency_ms"] == 500.0

    def test_preserves_zero_latency_from_event(self) -> None:
        tracker = ManagedAgentTracker()
        session = _make_session()

        events = [
            SimpleNamespace(
                type="message",
                role="assistant",
                content="Instant response",
                model="claude-sonnet-4-20250514",
                usage=SimpleNamespace(input_tokens=5, output_tokens=3),
                latency_ms=0.0,
            ),
        ]

        tracker.process_events(session, events, poll_latency_ms=999.0)

        call_kwargs = session.track_ai_message.call_args.kwargs
        assert call_kwargs["latency_ms"] == 0.0

    def test_uses_default_model_when_event_has_none(self) -> None:
        tracker = ManagedAgentTracker(default_model="claude-opus-4-20250514")
        session = _make_session()

        events = [
            SimpleNamespace(
                type="message",
                role="assistant",
                content="Response",
                usage=SimpleNamespace(input_tokens=10, output_tokens=5),
            ),
        ]

        tracker.process_events(session, events, poll_latency_ms=100.0)

        call_kwargs = session.track_ai_message.call_args.kwargs
        assert call_kwargs["model"] == "claude-opus-4-20250514"

    def test_skips_tool_result_events(self) -> None:
        tracker = ManagedAgentTracker()
        session = _make_session()

        events = [
            SimpleNamespace(type="tool_result", is_error=False, tool_use_id="tu-1"),
        ]

        count = tracker.process_events(session, events)

        assert count == 1
        session.track_user_message.assert_not_called()
        session.track_ai_message.assert_not_called()
        session.track_tool_call.assert_not_called()

    def test_handles_dict_events(self) -> None:
        tracker = ManagedAgentTracker()
        session = _make_session()

        events = [
            {
                "type": "message",
                "role": "assistant",
                "content": "Dict response",
                "model": "claude-sonnet-4-20250514",
                "usage": {"input_tokens": 10, "output_tokens": 5},
                "latency_ms": 300.0,
            },
        ]

        count = tracker.process_events(session, events)

        assert count == 1
        session.track_ai_message.assert_called_once()

    def test_continues_on_error_in_single_event(self) -> None:
        tracker = ManagedAgentTracker()
        session = _make_session()
        session.track_user_message.side_effect = RuntimeError("tracking failed")

        events = [
            SimpleNamespace(type="message", role="user", content="Hello"),
            SimpleNamespace(
                type="message",
                role="assistant",
                content="Hi",
                model="claude-sonnet-4-20250514",
                usage=SimpleNamespace(input_tokens=10, output_tokens=5),
                latency_ms=100.0,
            ),
        ]

        count = tracker.process_events(session, events)

        # First event fails, second succeeds
        assert count == 1
        session.track_ai_message.assert_called_once()

    def test_empty_events_returns_zero(self) -> None:
        tracker = ManagedAgentTracker()
        session = _make_session()

        count = tracker.process_events(session, [])

        assert count == 0

    def test_custom_provider(self) -> None:
        tracker = ManagedAgentTracker(default_provider="custom-gateway")
        session = _make_session()

        events = [
            SimpleNamespace(
                type="message",
                role="assistant",
                content="Hi",
                model="gpt-4o",
                usage=SimpleNamespace(input_tokens=10, output_tokens=5),
                latency_ms=100.0,
            ),
        ]

        tracker.process_events(session, events)

        call_kwargs = session.track_ai_message.call_args.kwargs
        assert call_kwargs["provider"] == "custom-gateway"


class TestExtractTextContent:
    def test_string_content(self) -> None:
        event = SimpleNamespace(content="Hello world")
        assert _extract_text_content(event) == "Hello world"

    def test_list_content_blocks(self) -> None:
        event = SimpleNamespace(
            content=[
                SimpleNamespace(type="text", text="Part 1"),
                SimpleNamespace(type="text", text="Part 2"),
            ]
        )
        assert _extract_text_content(event) == "Part 1\nPart 2"

    def test_none_content(self) -> None:
        event = SimpleNamespace(content=None)
        assert _extract_text_content(event) == ""

    def test_mixed_content_blocks(self) -> None:
        event = SimpleNamespace(
            content=[
                SimpleNamespace(type="text", text="Hello"),
                SimpleNamespace(type="image", url="http://example.com/img.png"),
            ]
        )
        assert _extract_text_content(event) == "Hello"
