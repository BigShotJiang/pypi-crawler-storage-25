"""Tests for automatic tool call extraction from message arrays."""

from __future__ import annotations

from typing import Any
from unittest.mock import MagicMock, call, patch

import pytest

from amplitude_ai.providers.base import _extract_and_track_tool_calls


def _make_kwargs(**overrides: Any) -> dict[str, Any]:
    """Build the required kwargs for _extract_and_track_tool_calls."""
    defaults: dict[str, Any] = {
        "amplitude": MagicMock(),
        "user_id": "u1",
        "session_id": "s1",
        "trace_id": "t1",
        "turn_id": 1,
        "agent_id": None,
        "parent_agent_id": None,
        "env": None,
        "customer_org_id": None,
        "agent_version": None,
        "description": None,
        "context": None,
        "event_properties": None,
        "user_properties": None,
        "groups": None,
        "privacy_config": None,
    }
    defaults.update(overrides)
    return defaults


class TestOpenAIChatToolExtraction:
    """Tests for OpenAI Chat Completions format extraction."""

    @patch("amplitude_ai.providers.base.track_tool_call")
    def test_extracts_tool_calls_from_assistant_tool_exchange(
        self, mock_track: MagicMock
    ) -> None:
        messages = [
            {"role": "user", "content": "Calculate 2+2"},
            {
                "role": "assistant",
                "content": None,
                "tool_calls": [
                    {
                        "id": "tc_1",
                        "type": "function",
                        "function": {"name": "calculator", "arguments": '{"expr":"2+2"}'},
                    }
                ],
            },
            {"role": "tool", "tool_call_id": "tc_1", "content": "4"},
        ]
        kwargs = _make_kwargs()
        _extract_and_track_tool_calls(messages, **kwargs)

        mock_track.assert_called_once()
        kw = mock_track.call_args.kwargs
        assert kw["tool_name"] == "calculator"
        assert kw["success"] is True
        assert kw["latency_ms"] == 0
        assert kw["tool_input"] == '{"expr":"2+2"}'
        assert kw["tool_output"] == "4"

    @patch("amplitude_ai.providers.base.track_tool_call")
    def test_handles_multiple_tool_calls(self, mock_track: MagicMock) -> None:
        messages = [
            {"role": "user", "content": "search and calculate"},
            {
                "role": "assistant",
                "content": None,
                "tool_calls": [
                    {"id": "tc_1", "type": "function", "function": {"name": "search", "arguments": '{"q":"test"}'}},
                    {"id": "tc_2", "type": "function", "function": {"name": "calc", "arguments": '{"x":1}'}},
                ],
            },
            {"role": "tool", "tool_call_id": "tc_1", "content": "found it"},
            {"role": "tool", "tool_call_id": "tc_2", "content": "42"},
        ]
        kwargs = _make_kwargs()
        _extract_and_track_tool_calls(messages, **kwargs)

        assert mock_track.call_count == 2
        names = [c.kwargs["tool_name"] for c in mock_track.call_args_list]
        assert names == ["search", "calc"]

    @patch("amplitude_ai.providers.base.track_tool_call")
    def test_does_not_extract_when_no_tool_calls(self, mock_track: MagicMock) -> None:
        messages = [
            {"role": "user", "content": "hello"},
            {"role": "assistant", "content": "hi there"},
        ]
        kwargs = _make_kwargs()
        _extract_and_track_tool_calls(messages, **kwargs)
        mock_track.assert_not_called()

    @patch("amplitude_ai.providers.base.track_tool_call")
    def test_does_not_extract_with_empty_messages(self, mock_track: MagicMock) -> None:
        _extract_and_track_tool_calls([], **_make_kwargs())
        mock_track.assert_not_called()

    @patch("amplitude_ai.providers.base.track_tool_call")
    def test_does_not_extract_without_user_id(self, mock_track: MagicMock) -> None:
        messages = [
            {"role": "assistant", "content": None, "tool_calls": [{"id": "tc_1", "type": "function", "function": {"name": "test", "arguments": ""}}]},
            {"role": "tool", "tool_call_id": "tc_1", "content": "ok"},
        ]
        _extract_and_track_tool_calls(messages, **_make_kwargs(user_id=""))
        mock_track.assert_not_called()


class TestAnthropicToolExtraction:
    """Tests for Anthropic format extraction."""

    @patch("amplitude_ai.providers.base.track_tool_call")
    def test_extracts_anthropic_tool_result(self, mock_track: MagicMock) -> None:
        messages = [
            {"role": "user", "content": "search for shoes"},
            {
                "role": "assistant",
                "content": [
                    {"type": "tool_use", "id": "tu_1", "name": "search", "input": {"query": "shoes"}},
                ],
            },
            {
                "role": "user",
                "content": [
                    {"type": "tool_result", "tool_use_id": "tu_1", "content": "3 results"},
                ],
            },
        ]
        _extract_and_track_tool_calls(messages, **_make_kwargs())

        mock_track.assert_called_once()
        kw = mock_track.call_args.kwargs
        assert kw["tool_name"] == "search"
        assert kw["success"] is True
        assert kw["tool_output"] == "3 results"

    @patch("amplitude_ai.providers.base.track_tool_call")
    def test_handles_anthropic_error_result(self, mock_track: MagicMock) -> None:
        messages = [
            {
                "role": "assistant",
                "content": [
                    {"type": "tool_use", "id": "tu_1", "name": "api_call", "input": {"url": "https://example.com"}},
                ],
            },
            {
                "role": "user",
                "content": [
                    {"type": "tool_result", "tool_use_id": "tu_1", "content": "timeout", "is_error": True},
                ],
            },
        ]
        _extract_and_track_tool_calls(messages, **_make_kwargs())

        kw = mock_track.call_args.kwargs
        assert kw["success"] is False
        assert kw["error_message"] == "timeout"

    @patch("amplitude_ai.providers.base.track_tool_call")
    def test_handles_anthropic_content_block_list(self, mock_track: MagicMock) -> None:
        messages = [
            {
                "role": "assistant",
                "content": [
                    {"type": "tool_use", "id": "tu_1", "name": "read", "input": "file.py"},
                ],
            },
            {
                "role": "user",
                "content": [
                    {
                        "type": "tool_result",
                        "tool_use_id": "tu_1",
                        "content": [{"type": "text", "text": "file contents here"}],
                    },
                ],
            },
        ]
        _extract_and_track_tool_calls(messages, **_make_kwargs())

        kw = mock_track.call_args.kwargs
        assert kw["tool_output"] == "file contents here"


class TestResponsesAPIToolExtraction:
    """Tests for OpenAI Responses API format extraction."""

    @patch("amplitude_ai.providers.base.track_tool_call")
    def test_extracts_function_call_output(self, mock_track: MagicMock) -> None:
        messages = [
            {"role": "user", "content": "find files"},
            {"type": "function_call", "call_id": "fc_1", "name": "search", "arguments": '{"q":"test"}'},
            {"type": "function_call_output", "call_id": "fc_1", "output": "5 results"},
        ]
        _extract_and_track_tool_calls(messages, **_make_kwargs())

        mock_track.assert_called_once()
        kw = mock_track.call_args.kwargs
        assert kw["tool_name"] == "search"
        assert kw["tool_output"] == "5 results"
