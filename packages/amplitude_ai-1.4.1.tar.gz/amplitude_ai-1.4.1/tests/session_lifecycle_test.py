"""Tests for Session auto-traceId and track_session_end option (v1.4.1)."""
from __future__ import annotations

import asyncio
from typing import Any

from amplitude_ai import (
    EVENT_SESSION_END,
    EVENT_USER_MESSAGE,
    PROP_AGENT_ID,
    PROP_TRACE_ID,
    MockAmplitudeAI,
)
from amplitude_ai.context import get_active_context

Props = dict[str, Any]


class TestAutoTraceId:
    def test_auto_generates_trace_id_on_enter(self) -> None:
        mock = MockAmplitudeAI()
        agent = mock.agent("bot", user_id="u1")
        session = agent.session(session_id="s1")
        assert session.trace_id is None

        with session as s:
            assert s.trace_id is not None
            ctx = get_active_context()
            assert ctx is not None
            assert ctx.trace_id == s.trace_id

    def test_preserves_explicit_trace_id(self) -> None:
        mock = MockAmplitudeAI()
        agent = mock.agent("bot", user_id="u1")
        session = agent.session(session_id="s1")
        session.trace_id = "custom-trace"

        with session as s:
            assert s.trace_id == "custom-trace"
            ctx = get_active_context()
            assert ctx is not None
            assert ctx.trace_id == "custom-trace"

    def test_preserves_new_trace_called_before_enter(self) -> None:
        mock = MockAmplitudeAI()
        agent = mock.agent("bot", user_id="u1")
        session = agent.session(session_id="s1")
        explicit_id = session.new_trace()

        with session as s:
            assert s.trace_id == explicit_id

    def test_auto_trace_id_propagates_to_events(self) -> None:
        mock = MockAmplitudeAI()
        agent = mock.agent("bot", user_id="u1")

        with agent.session(session_id="s1") as s:
            s.track_user_message(content="hello")
            auto_trace = s.trace_id

        user_msgs = mock.get_events(EVENT_USER_MESSAGE)
        assert len(user_msgs) == 1
        props: Props = user_msgs[0].event_properties or {}
        assert props.get(PROP_TRACE_ID) == auto_trace

    def test_auto_trace_id_unique_per_session(self) -> None:
        mock = MockAmplitudeAI()
        agent = mock.agent("bot", user_id="u1")

        trace_ids: list[str | None] = []
        for _ in range(3):
            with agent.session(session_id="s1") as s:
                trace_ids.append(s.trace_id)

        assert all(t is not None for t in trace_ids)
        assert len(set(trace_ids)) == 3

    def test_async_auto_generates_trace_id(self) -> None:
        mock = MockAmplitudeAI()
        agent = mock.agent("bot", user_id="u1")

        captured_trace: str | None = None

        async def _run() -> None:
            nonlocal captured_trace
            async with agent.session(session_id="s1") as s:
                captured_trace = s.trace_id
                assert captured_trace is not None
                ctx = get_active_context()
                assert ctx is not None
                assert ctx.trace_id == captured_trace

        asyncio.get_event_loop().run_until_complete(_run())
        assert captured_trace is not None


class TestTrackSessionEnd:
    def test_default_emits_session_end(self) -> None:
        mock = MockAmplitudeAI()
        agent = mock.agent("bot", user_id="u1")

        with agent.session(session_id="s1") as s:
            s.track_user_message(content="hi")

        end_events = mock.get_events(EVENT_SESSION_END)
        assert len(end_events) == 1

    def test_false_suppresses_session_end(self) -> None:
        mock = MockAmplitudeAI()
        agent = mock.agent("bot", user_id="u1")

        with agent.session(session_id="s1", track_session_end=False) as s:
            s.track_user_message(content="hi")

        end_events = mock.get_events(EVENT_SESSION_END)
        assert len(end_events) == 0

        user_msgs = mock.get_events(EVENT_USER_MESSAGE)
        assert len(user_msgs) == 1

    def test_false_still_flushes_when_auto_flush_is_on(self) -> None:
        mock = MockAmplitudeAI()
        agent = mock.agent("bot", user_id="u1")

        with agent.session(
            session_id="s1",
            track_session_end=False,
            auto_flush=True,
        ) as s:
            s.track_user_message(content="hi")

        user_msgs = mock.get_events(EVENT_USER_MESSAGE)
        assert len(user_msgs) == 1
        end_events = mock.get_events(EVENT_SESSION_END)
        assert len(end_events) == 0

    def test_run_as_still_skips_session_end(self) -> None:
        mock = MockAmplitudeAI()
        parent = mock.agent("orchestrator", user_id="u1")
        child = parent.child("researcher")

        with parent.session(session_id="s1") as s, s.run_as(child) as cs:
            cs.track_user_message(content="child task")

        end_events = mock.get_events(EVENT_SESSION_END)
        assert len(end_events) == 1
        props: Props = end_events[0].event_properties or {}
        assert props.get(PROP_AGENT_ID) == "orchestrator"

    def test_async_false_suppresses_session_end(self) -> None:
        mock = MockAmplitudeAI()
        agent = mock.agent("bot", user_id="u1")

        async def _run() -> None:
            async with agent.session(
                session_id="s1",
                track_session_end=False,
            ) as s:
                s.track_user_message(content="hi")

        asyncio.get_event_loop().run_until_complete(_run())

        end_events = mock.get_events(EVENT_SESSION_END)
        assert len(end_events) == 0

    def test_session_end_includes_enrichments_when_enabled(self) -> None:
        mock = MockAmplitudeAI()
        agent = mock.agent("bot", user_id="u1")

        with agent.session(session_id="s1") as s:
            s.set_enrichments({"summary": "test conversation"})  # type: ignore[arg-type]

        end_events = mock.get_events(EVENT_SESSION_END)
        assert len(end_events) == 1
