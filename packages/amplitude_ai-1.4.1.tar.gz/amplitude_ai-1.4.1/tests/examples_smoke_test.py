from __future__ import annotations

from amplitude_ai.core.tracking import EVENT_AI_RESPONSE, EVENT_USER_MESSAGE
from examples.framework_integration_example import run_framework_integration_example
from examples.multi_agent_example import run_multi_agent_example
from examples.wrap_openai_example import run_wrap_openai_example
from examples.zero_code_example import run_zero_code_example


def _assert_user_and_ai_events(mock: object) -> None:
    get_events = getattr(mock, "get_events")
    assert len(get_events(EVENT_USER_MESSAGE)) > 0
    assert len(get_events(EVENT_AI_RESPONSE)) > 0


def test_zero_code_example_smoke() -> None:
    _assert_user_and_ai_events(run_zero_code_example())


def test_wrap_openai_example_smoke() -> None:
    _assert_user_and_ai_events(run_wrap_openai_example())


def test_multi_agent_example_smoke() -> None:
    _assert_user_and_ai_events(run_multi_agent_example())


def test_framework_integration_example_smoke() -> None:
    _assert_user_and_ai_events(run_framework_integration_example())
