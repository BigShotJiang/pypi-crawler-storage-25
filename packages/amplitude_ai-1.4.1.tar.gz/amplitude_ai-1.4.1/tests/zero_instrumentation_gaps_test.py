"""Tests for the zero-instrumentation gap fixes.

Covers:
- Gap C: SessionContext auto-inherits parent_agent_id from enclosing context
- Gap D: SimpleStreamingTracker auto-emits track_user_message in finalize()
- Gap E: Tool-call extraction reports real latency from the timestamp registry
- Gap F: PrivacyConfig defaults redact_pii=True
- Gap G: patch() warns once when expected_providers differs from patched set
"""

from __future__ import annotations

import logging
import time
from typing import Any
from unittest.mock import MagicMock, patch as mock_patch

import pytest

from amplitude_ai import MockAmplitudeAI
from amplitude_ai.context import SessionContext, _current_session, get_active_context
from amplitude_ai.core.privacy import PrivacyConfig
from amplitude_ai.providers.base import (
    SimpleStreamingTracker,
    _extract_and_track_tool_calls,
)
from amplitude_ai.utils.provider_detect import (
    _reset_for_tests as _reset_warn_dedup,
    warn_if_provider_mismatch,
)
from amplitude_ai.utils.tool_latency import (
    _reset_for_tests as _reset_latency_registry,
    consume_tool_use_latency_ms,
    record_tool_use,
)


class TestGapCParentAgentInheritance:
    def test_top_level_context_has_no_parent(self) -> None:
        ctx = SessionContext(session_id="s1", agent_id="orch")
        assert ctx.parent_agent_id is None

    def test_nested_context_inherits_parent_agent_id(self) -> None:
        outer = SessionContext(session_id="s1", agent_id="orch")
        token = _current_session.set(outer)
        try:
            inner = SessionContext(session_id="s1", agent_id="worker")
            assert inner.parent_agent_id == "orch"
        finally:
            _current_session.reset(token)

    def test_nested_context_honors_explicit_parent_override(self) -> None:
        outer = SessionContext(session_id="s1", agent_id="orch")
        token = _current_session.set(outer)
        try:
            inner = SessionContext(
                session_id="s1", agent_id="worker", parent_agent_id="custom"
            )
            assert inner.parent_agent_id == "custom"
        finally:
            _current_session.reset(token)

    def test_run_as_sibling_agent_inherits_enclosing_agent_id(self) -> None:
        """Sibling agents (not created via .child()) should still inherit
        the enclosing session's agent_id as parent_agent_id when the new
        SessionContext is built inside the enclosing session."""
        mock = MockAmplitudeAI()
        orchestrator = mock.agent("orchestrator", user_id="u1")
        sibling = mock.agent("sibling-worker", user_id="u1")

        captured_parent: str | None = None
        with orchestrator.session(session_id="s1") as s:
            with s.run_as(sibling):
                ctx = get_active_context()
                captured_parent = ctx.parent_agent_id if ctx else None

        assert captured_parent == "orchestrator"


class TestGapDStreamingAutoUserMessage:
    def _build_tracker(self, messages: list[dict[str, Any]], **extra: Any) -> SimpleStreamingTracker:
        return SimpleStreamingTracker(
            amplitude_client=MagicMock(),
            privacy_config=PrivacyConfig(),
            provider_name="openai",
            user_id="u1",
            session_id="s1",
            trace_id="t1",
            turn_id=1,
            messages=messages,
            **extra,
        )

    @mock_patch("amplitude_ai.providers.base.track_user_message")
    @mock_patch("amplitude_ai.providers.base.track_ai_message")
    def test_emits_user_message_for_new_user_in_input(
        self, _mock_ai: MagicMock, mock_user: MagicMock
    ) -> None:
        tracker = self._build_tracker([{"role": "user", "content": "hello"}])
        tracker.finalize("gpt-4o")
        mock_user.assert_called_once()
        assert mock_user.call_args.kwargs["message_content"] == "hello"

    @mock_patch("amplitude_ai.providers.base.track_user_message")
    @mock_patch("amplitude_ai.providers.base.track_ai_message")
    def test_only_tracks_messages_after_last_assistant_reply(
        self, _mock_ai: MagicMock, mock_user: MagicMock
    ) -> None:
        messages = [
            {"role": "user", "content": "first"},
            {"role": "assistant", "content": "reply"},
            {"role": "user", "content": "follow-up"},
        ]
        tracker = self._build_tracker(messages)
        tracker.finalize("gpt-4o")
        mock_user.assert_called_once()
        assert mock_user.call_args.kwargs["message_content"] == "follow-up"

    @mock_patch("amplitude_ai.providers.base.track_user_message")
    @mock_patch("amplitude_ai.providers.base.track_ai_message")
    def test_finalize_is_idempotent_for_user_messages(
        self, _mock_ai: MagicMock, mock_user: MagicMock
    ) -> None:
        tracker = self._build_tracker([{"role": "user", "content": "hello"}])
        tracker.finalize("gpt-4o")
        # finalize is normally idempotent via _finalized, but even if we force
        # a re-run the auto-user tracking must not double-emit.
        tracker._finalized = False
        tracker.finalize("gpt-4o")
        assert mock_user.call_count == 1

    @mock_patch("amplitude_ai.providers.base.track_user_message")
    @mock_patch("amplitude_ai.providers.base.track_ai_message")
    def test_skip_flag_disables_auto_user_tracking(
        self, _mock_ai: MagicMock, mock_user: MagicMock
    ) -> None:
        tracker = self._build_tracker(
            [{"role": "user", "content": "hello"}],
            _skip_auto_user_tracking=True,
        )
        tracker.finalize("gpt-4o")
        mock_user.assert_not_called()

    @mock_patch("amplitude_ai.providers.base.track_user_message")
    @mock_patch("amplitude_ai.providers.base.track_ai_message")
    def test_ai_response_turn_id_bumps_past_auto_user_messages(
        self, mock_ai: MagicMock, mock_user: MagicMock
    ) -> None:
        """Streaming finalize() must bump the AI turn past each auto-tracked
        user message, matching track_completion's non-streaming behaviour:
        user messages on turn N, AI response on turn N + <new user count>.
        """
        messages = [
            {"role": "user", "content": "part one"},
            {"role": "user", "content": "part two"},
        ]
        tracker = self._build_tracker(messages)
        tracker.finalize("gpt-4o")
        assert mock_user.call_count == 2
        assert [c.kwargs["turn_id"] for c in mock_user.call_args_list] == [1, 2]
        assert mock_ai.call_args.kwargs["turn_id"] == 3

    @mock_patch("amplitude_ai.providers.base.track_user_message")
    @mock_patch("amplitude_ai.providers.base.track_ai_message")
    def test_skips_user_tool_result_messages(
        self, _mock_ai: MagicMock, mock_user: MagicMock
    ) -> None:
        """Anthropic user-role tool_result messages should not fire
        track_user_message — they're tool calls, not user prompts."""
        messages = [
            {"role": "user", "content": "run this"},
            {
                "role": "assistant",
                "content": [{"type": "tool_use", "id": "tu1", "name": "calc", "input": {}}],
            },
            {
                "role": "user",
                "content": [{"type": "tool_result", "tool_use_id": "tu1", "content": "42"}],
            },
        ]
        tracker = self._build_tracker(messages)
        tracker.finalize("claude-3-5-sonnet")
        mock_user.assert_not_called()


class TestGapEToolCallLatency:
    def setup_method(self, _method: Any) -> None:
        _reset_latency_registry()

    @mock_patch("amplitude_ai.providers.base.track_tool_call")
    def test_records_and_consumes_latency_for_openai_chat(
        self, mock_track: MagicMock
    ) -> None:
        record_tool_use(session_id="s1", tool_use_id="tc_1", agent_id=None)
        time.sleep(0.02)  # 20ms

        messages = [
            {"role": "user", "content": "calc"},
            {
                "role": "assistant",
                "content": None,
                "tool_calls": [
                    {"id": "tc_1", "type": "function",
                     "function": {"name": "calc", "arguments": "{}"}},
                ],
            },
            {"role": "tool", "tool_call_id": "tc_1", "content": "4"},
        ]
        _extract_and_track_tool_calls(
            messages,
            amplitude=MagicMock(),
            user_id="u1",
            session_id="s1",
            trace_id="t1",
            turn_id=1,
            agent_id=None,
            parent_agent_id=None,
            env=None,
            customer_org_id=None,
            agent_version=None,
            description=None,
            context=None,
            event_properties=None,
            user_properties=None,
            groups=None,
            privacy_config=None,
        )
        latency = mock_track.call_args.kwargs["latency_ms"]
        assert latency > 0.0
        assert latency < 5000.0  # sanity

    @mock_patch("amplitude_ai.providers.base.track_tool_call")
    def test_missing_record_falls_back_to_zero(
        self, mock_track: MagicMock
    ) -> None:
        # No record_tool_use() call.
        messages = [
            {"role": "user", "content": "calc"},
            {
                "role": "assistant",
                "content": None,
                "tool_calls": [
                    {"id": "tc_missing", "type": "function",
                     "function": {"name": "calc", "arguments": "{}"}},
                ],
            },
            {"role": "tool", "tool_call_id": "tc_missing", "content": "4"},
        ]
        _extract_and_track_tool_calls(
            messages,
            amplitude=MagicMock(),
            user_id="u1",
            session_id="s1",
            trace_id="t1",
            turn_id=1,
            agent_id=None,
            parent_agent_id=None,
            env=None,
            customer_org_id=None,
            agent_version=None,
            description=None,
            context=None,
            event_properties=None,
            user_properties=None,
            groups=None,
            privacy_config=None,
        )
        assert mock_track.call_args.kwargs["latency_ms"] == 0.0

    def test_consume_is_single_shot(self) -> None:
        record_tool_use(session_id="s1", tool_use_id="tc_x", agent_id=None)
        first = consume_tool_use_latency_ms(
            session_id="s1", tool_use_id="tc_x", agent_id=None
        )
        second = consume_tool_use_latency_ms(
            session_id="s1", tool_use_id="tc_x", agent_id=None
        )
        assert first >= 0.0
        assert second == 0.0

    def test_consume_without_tool_use_id_returns_zero(self) -> None:
        assert consume_tool_use_latency_ms(
            session_id="s1", tool_use_id=None, agent_id=None
        ) == 0.0


class TestGapFPrivacyDefaults:
    def test_redact_pii_defaults_to_true(self) -> None:
        config = PrivacyConfig()
        assert config.redact_pii is True

    def test_redact_pii_respects_explicit_false(self) -> None:
        config = PrivacyConfig(redact_pii=False)
        assert config.redact_pii is False

    def test_privacy_mode_unaffected_by_flip(self) -> None:
        config = PrivacyConfig()
        assert config.privacy_mode is False


class TestGapGProviderMismatchWarn:
    def setup_method(self, _method: Any) -> None:
        _reset_warn_dedup()

    def test_matching_sets_do_not_warn(
        self, caplog: pytest.LogCaptureFixture
    ) -> None:
        caplog.set_level(logging.WARNING, logger="amplitude_ai")
        warn_if_provider_mismatch(
            expected_providers=["openai"],
            patched_providers=["openai"],
            app_key="app1",
        )
        assert not any(
            "declared providers" in r.message for r in caplog.records
        )

    def test_mismatched_sets_warn_once(
        self, caplog: pytest.LogCaptureFixture
    ) -> None:
        caplog.set_level(logging.WARNING, logger="amplitude_ai")
        warn_if_provider_mismatch(
            expected_providers=["openai"],
            patched_providers=["anthropic"],
            app_key="app1",
        )
        warn_if_provider_mismatch(
            expected_providers=["openai"],
            patched_providers=["anthropic"],
            app_key="app1",
        )
        warnings = [r for r in caplog.records if "declared providers" in r.message]
        assert len(warnings) == 1
        assert "'app1'" in warnings[0].message
        assert "['openai']" in warnings[0].message
        assert "['anthropic']" in warnings[0].message

    def test_none_expected_does_not_warn(
        self, caplog: pytest.LogCaptureFixture
    ) -> None:
        caplog.set_level(logging.WARNING, logger="amplitude_ai")
        warn_if_provider_mismatch(
            expected_providers=None,
            patched_providers=["anthropic"],
        )
        assert not caplog.records

    def test_async_openai_is_aliased_to_openai(
        self, caplog: pytest.LogCaptureFixture
    ) -> None:
        """async_openai and openai are the same provider SDK — don't warn."""
        caplog.set_level(logging.WARNING, logger="amplitude_ai")
        warn_if_provider_mismatch(
            expected_providers=["openai"],
            patched_providers=["async_openai"],
            app_key="app2",
        )
        assert not any(
            "declared providers" in r.message for r in caplog.records
        )
