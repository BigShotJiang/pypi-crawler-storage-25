"""
Anthropic Managed Agents integration example.

Demonstrates manual tracking with amplitude-ai when using Anthropic's
Managed Agents API (client.beta.sessions / client.beta.agents), where
LLM calls happen in Anthropic's cloud and you observe results via polling.

Requires ANTHROPIC_API_KEY and AMPLITUDE_AI_API_KEY environment variables.

Run: ANTHROPIC_API_KEY=sk-ant-... AMPLITUDE_AI_API_KEY=... python examples/anthropic_managed_agents_example.py
"""
from __future__ import annotations

import os
import time


def run_managed_agents_example() -> None:
    api_key = os.environ.get("AMPLITUDE_AI_API_KEY")
    anthropic_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key or not anthropic_key:
        print("Skipping: AMPLITUDE_AI_API_KEY and ANTHROPIC_API_KEY required.")
        return

    import anthropic
    from amplitude import Amplitude
    from amplitude_ai import AmplitudeAI

    amplitude = Amplitude(api_key)
    ai = AmplitudeAI(amplitude=amplitude, content_mode="full", redact_pii=True)
    agent = ai.agent(
        "design-agent",
        description="Anthropic managed design agent for UI prototyping",
    )
    client = anthropic.Anthropic(api_key=anthropic_key)

    user_id = "demo-user"
    session_id = f"managed-session-{int(time.time())}"
    user_input = "Create a simple landing page with a hero section and CTA button"

    # Create a managed agent session in Anthropic's cloud
    managed_session = client.beta.sessions.create(
        agent_id="your-anthropic-agent-id",
        messages=[{"role": "user", "content": user_input}],
    )

    with agent.session(user_id=user_id, session_id=session_id) as s:
        s.track_user_message(user_input)

        # Poll for events from the managed session
        start_time = time.monotonic()
        events = client.beta.sessions.messages.list(
            session_id=managed_session.id,
        )
        poll_latency_ms = (time.monotonic() - start_time) * 1000

        for event in events:
            if event.type == "message" and event.role == "assistant":
                text = event.content[0].text if event.content else ""
                s.track_ai_message(
                    content=text,
                    model=getattr(event, "model", "claude-sonnet-4-20250514"),
                    provider="anthropic",
                    latency_ms=poll_latency_ms,
                    input_tokens=getattr(event.usage, "input_tokens", None),
                    output_tokens=getattr(event.usage, "output_tokens", None),
                )
                print(f"AI Response: {text[:200]}...")
            elif event.type == "tool_use":
                s.track_tool_call(
                    tool_name=event.name,
                    success=True,
                    latency_ms=getattr(event, "duration_ms", 0),
                    input=getattr(event, "input", None),
                    output=getattr(event, "output", None),
                )
                print(f"Tool Call: {event.name}")

    ai.flush()
    print("Events flushed successfully.")


if __name__ == "__main__":
    run_managed_agents_example()
