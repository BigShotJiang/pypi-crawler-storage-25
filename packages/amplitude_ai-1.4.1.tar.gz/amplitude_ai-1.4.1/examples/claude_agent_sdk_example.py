"""
Example: Claude Agent SDK integration with amplitude_ai.

Demonstrates how to use ClaudeAgentSDKTracker to automatically
track tool calls (with execution latency) and AI messages from
the Claude Agent SDK.

Prerequisites:
    pip install amplitude-ai claude-code-sdk

Usage:
    AMPLITUDE_API_KEY=your-key python examples/claude_agent_sdk_example.py
"""

from __future__ import annotations

import os

from amplitude import Amplitude

from amplitude_ai import AmplitudeAI
from amplitude_ai.integrations.claude_agent_sdk import ClaudeAgentSDKTracker

# In a real app, import from claude-code-sdk:
# from claude_code_sdk import query, ClaudeAgentOptions


def main() -> None:
    api_key = os.environ.get("AMPLITUDE_API_KEY", "your-api-key")
    ai = AmplitudeAI(amplitude=Amplitude(api_key))

    agent = ai.agent("code-reviewer")
    tracker = ClaudeAgentSDKTracker()

    with agent.session(user_id="user-123", session_id="review-session-1") as session:
        prompt = "Review the latest commit for security issues"
        session.track_user_message(prompt)

        # In a real app, you would call query() from the Claude Agent SDK:
        #
        # for message in query(
        #     prompt=prompt,
        #     options=ClaudeAgentOptions(
        #         allowed_tools=["Read", "Bash", "Glob"],
        #         hooks=tracker.hooks(session),
        #     ),
        # ):
        #     tracker.process(session, message)

        # Simulated messages for demonstration:
        tracker.process(session, {
            "role": "assistant",
            "content": [
                {"type": "text", "text": "I found a potential SQL injection vulnerability."},
            ],
            "model": "claude-sonnet-4-20250514",
            "usage": {"input_tokens": 500, "output_tokens": 120},
        })

        print("Tracked AI response and tool calls via Claude Agent SDK integration")

    ai.flush()


if __name__ == "__main__":
    main()
