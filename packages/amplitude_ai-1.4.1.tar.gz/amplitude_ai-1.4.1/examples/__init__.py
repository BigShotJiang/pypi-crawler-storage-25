"""Runnable amplitude-ai examples used as smoke tests."""
