# Examples

These examples demonstrate the `amplitude-ai` event model using `MockAmplitudeAI`
(no API keys or LLM provider SDKs required). They are also used as smoke tests in CI.

| File | Pattern demonstrated |
| --- | --- |
| `zero_code_example.py` | Event model for zero-code patching |
| `wrap_openai_example.py` | Event model for wrapping a provider client |
| `multi_agent_example.py` | Multi-agent hierarchy with parent/child agents |
| `framework_integration_example.py` | BoundAgent + Session lifecycle |

## Running

```bash
uv run pytest tests/examples_smoke_test.py
```

## Real integration examples

For runnable examples that call real LLM APIs, see the code blocks in the
[README](../README.md) under each integration tier (Zero-code, Wrap, Full Control).
Those require `OPENAI_API_KEY` or the relevant provider credentials.
