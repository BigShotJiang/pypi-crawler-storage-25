"""
Claude Agent SDK integration for Amplitude AI SDK.

Provides :class:`ClaudeAgentSDKTracker` — a convenience adapter that
hooks into the Claude Agent SDK (``@anthropic-ai/claude-agent-sdk``) and
automatically emits the correct Amplitude ``[Agent] *`` events.

No runtime dependency on ``claude-code-sdk`` or the Claude Agent SDK —
all types are structural (optional peer dependency pattern).

Usage::

    from amplitude import Amplitude
    from amplitude_ai import AmplitudeAI
    from amplitude_ai.integrations.claude_agent_sdk import ClaudeAgentSDKTracker

    ai = AmplitudeAI(amplitude=Amplitude("YOUR_API_KEY"))
    agent = ai.agent("my-agent")
    tracker = ClaudeAgentSDKTracker()

    with agent.session(user_id="u1", session_id="s1") as session:
        # Pass hooks to ClaudeAgentOptions
        agent_options = {"hooks": tracker.hooks(session)}
        for message in query(agent_options):
            tracker.process(session, message)
"""

from __future__ import annotations

import time
from typing import Any, Callable, Awaitable

from ..utils.logger import get_logger

logger = get_logger(__name__)

HookFn = Callable[
    [dict[str, Any], str | None, dict[str, Any]],
    Awaitable[dict[str, Any]],
]


class ClaudeAgentSDKTracker:
    """Processes Claude Agent SDK hooks and messages to emit Amplitude events.

    Provides two integration points:

    * :meth:`hooks` — returns ``PreToolUse``/``PostToolUse`` hooks for
      ``ClaudeAgentOptions`` that track tool execution with precise latency.
    * :meth:`process` — dispatches on message type from the ``query()``
      stream and emits the appropriate ``[Agent] *`` events.
    """

    def __init__(
        self,
        *,
        default_provider: str = "anthropic",
        default_model: str | None = None,
    ) -> None:
        self._default_provider = default_provider
        self._default_model = default_model
        self._tool_timers: dict[str, float] = {}

    def hooks(
        self,
        session: Any,
    ) -> dict[str, list[dict[str, Any]]]:
        """Return hooks dict ready to pass to ``ClaudeAgentOptions``.

        Args:
            session: An active ``amplitude_ai`` Session (from ``agent.session()``).

        Returns:
            A dict with ``PreToolUse`` and ``PostToolUse`` hook matchers.
        """
        return {
            "PreToolUse": [
                {"matcher": None, "hooks": [self._make_pre_tool_hook()]},
            ],
            "PostToolUse": [
                {"matcher": None, "hooks": [self._make_post_tool_hook(session)]},
            ],
        }

    def process(self, session: Any, message: Any) -> None:
        """Process a message from the Claude Agent SDK ``query()`` stream.

        Dispatches based on the message's constructor name or ``role`` field
        and emits the appropriate Amplitude event via the session.

        Args:
            session: An active ``amplitude_ai`` Session.
            message: A message yielded by ``query()``.
        """
        if message is None:
            return

        type_name = type(message).__name__
        role = _get_attr(message, "role", "")

        try:
            if type_name == "AssistantMessage" or role == "assistant":
                self._process_assistant_message(session, message)
            elif type_name == "UserMessage" or role == "user":
                self._process_user_message(session, message)
        except Exception:
            logger.warning(
                "Failed to process Claude Agent SDK message (%s)",
                type_name,
                exc_info=True,
            )

    def _make_pre_tool_hook(self) -> HookFn:
        async def pre_tool_hook(
            input_data: dict[str, Any],
            tool_use_id: str | None,
            context: dict[str, Any],
        ) -> dict[str, Any]:
            if tool_use_id:
                self._tool_timers[tool_use_id] = time.monotonic()
            return {}

        return pre_tool_hook

    def _make_post_tool_hook(self, session: Any) -> HookFn:
        async def post_tool_hook(
            input_data: dict[str, Any],
            tool_use_id: str | None,
            context: dict[str, Any],
        ) -> dict[str, Any]:
            tool_name = str(input_data.get("tool_name", "unknown"))
            tool_input = input_data.get("tool_input")
            tool_response = input_data.get("tool_response")
            is_error = input_data.get("is_error", False) is True

            latency_ms = 0.0
            if tool_use_id and tool_use_id in self._tool_timers:
                start = self._tool_timers.pop(tool_use_id)
                latency_ms = (time.monotonic() - start) * 1000

            kwargs: dict[str, Any] = {}
            if tool_input is not None:
                kwargs["input"] = tool_input
            if tool_response is not None:
                kwargs["output"] = str(tool_response)
            if is_error and tool_response:
                kwargs["error_message"] = str(tool_response)

            session.track_tool_call(
                tool_name=tool_name,
                success=not is_error,
                latency_ms=latency_ms,
                **kwargs,
            )

            return {}

        return post_tool_hook

    def _process_assistant_message(self, session: Any, message: Any) -> None:
        content = _get_attr(message, "content", None)
        text = ""
        kwargs: dict[str, Any] = {}

        if isinstance(content, list):
            parts: list[str] = []
            for block in content:
                block_type = _get_attr(block, "type", "")
                if block_type == "text":
                    t = _get_attr(block, "text", "")
                    if t:
                        parts.append(t)
                elif block_type == "thinking":
                    thinking = _get_attr(block, "thinking", "")
                    if thinking:
                        kwargs["reasoning_content"] = thinking
            text = "\n".join(parts)
        elif isinstance(content, str):
            text = content
        elif content is not None:
            text = str(content)

        model = str(
            _get_attr(message, "model", None)
            or self._default_model
            or "unknown"
        )
        usage = _get_attr(message, "usage", None)
        if usage is not None:
            input_tokens = _get_attr(usage, "input_tokens", None)
            output_tokens = _get_attr(usage, "output_tokens", None)
            if input_tokens is not None:
                kwargs["input_tokens"] = input_tokens
            if output_tokens is not None:
                kwargs["output_tokens"] = output_tokens

        session.track_ai_message(
            content=text,
            model=model,
            provider=self._default_provider,
            latency_ms=0,
            **kwargs,
        )

    def _process_user_message(self, session: Any, message: Any) -> None:
        content = _get_attr(message, "content", None)
        text = ""

        if isinstance(content, str):
            text = content
        elif isinstance(content, list):
            parts: list[str] = []
            for block in content:
                block_type = _get_attr(block, "type", "")
                if block_type == "text":
                    t = _get_attr(block, "text", "")
                    if t:
                        parts.append(t)
            text = "\n".join(parts)
        elif content is not None:
            text = str(content)

        if text:
            session.track_user_message(text)


def _get_attr(obj: Any, name: str, default: Any = None) -> Any:
    """Retrieve an attribute from an object or dict."""
    if isinstance(obj, dict):
        return obj.get(name, default)
    return getattr(obj, name, default)
