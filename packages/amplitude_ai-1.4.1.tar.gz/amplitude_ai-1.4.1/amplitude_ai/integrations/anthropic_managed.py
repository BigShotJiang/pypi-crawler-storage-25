"""
Anthropic Managed Agents integration for Amplitude AI SDK.

Provides :class:`ManagedAgentTracker` — a convenience adapter that
processes events from Anthropic's Managed Agents API
(``client.beta.sessions``) and automatically emits the correct
Amplitude ``[Agent] *`` events.

Usage::

    from amplitude import Amplitude
    from amplitude_ai import AmplitudeAI
    from amplitude_ai.integrations.anthropic_managed import ManagedAgentTracker

    ai = AmplitudeAI(amplitude=Amplitude("YOUR_API_KEY"))
    agent = ai.agent("my-agent")

    tracker = ManagedAgentTracker(amplitude_ai=ai, agent=agent)

    with agent.session(user_id="u1", session_id="s1") as session:
        tracker.process_events(session, events_from_polling)
"""

from __future__ import annotations

import time
from typing import Any, Sequence

from ..utils.logger import get_logger

logger = get_logger(__name__)


class ManagedAgentTracker:
    """Processes Anthropic Managed Agent events and emits Amplitude tracking calls.

    Handles ``message``, ``tool_use``, and other event types from
    ``client.beta.sessions.messages.list()`` or SSE streams.
    """

    def __init__(
        self,
        *,
        default_provider: str = "anthropic",
        default_model: str | None = None,
    ) -> None:
        self._default_provider = default_provider
        self._default_model = default_model

    def process_events(
        self,
        session: Any,
        events: Sequence[Any],
        *,
        poll_latency_ms: float | None = None,
    ) -> int:
        """Process a sequence of Anthropic managed agent events.

        Args:
            session: An active ``amplitude_ai`` Session (from ``agent.session()``).
            events: Events from ``client.beta.sessions.messages.list()`` or similar.
            poll_latency_ms: Optional latency of the poll request. Used as
                ``latency_ms`` for AI response events when the event itself
                doesn't carry timing info.

        Returns:
            Number of events processed.
        """
        count = 0
        for event in events:
            try:
                self._process_single(session, event, poll_latency_ms)
                count += 1
            except Exception:
                logger.warning(
                    "Failed to process managed agent event: %s",
                    getattr(event, "type", "unknown"),
                    exc_info=True,
                )
        return count

    def _process_single(
        self,
        session: Any,
        event: Any,
        poll_latency_ms: float | None,
    ) -> None:
        event_type = _get_attr(event, "type", "")
        role = _get_attr(event, "role", "")

        if event_type == "message" and role == "user":
            content = _extract_text_content(event)
            if content:
                session.track_user_message(content)

        elif event_type == "message" and role == "assistant":
            content = _extract_text_content(event)
            model = (
                _get_attr(event, "model", None)
                or self._default_model
                or "unknown"
            )
            usage = _get_attr(event, "usage", None)
            event_latency = _get_attr(event, "latency_ms", None)
            latency = (
                event_latency if event_latency is not None
                else poll_latency_ms if poll_latency_ms is not None
                else 0.0
            )

            kwargs: dict[str, Any] = {
                "content": content,
                "model": model,
                "provider": self._default_provider,
                "latency_ms": latency,
            }

            if usage is not None:
                input_tokens = _get_attr(usage, "input_tokens", None)
                output_tokens = _get_attr(usage, "output_tokens", None)
                if input_tokens is not None:
                    kwargs["input_tokens"] = input_tokens
                if output_tokens is not None:
                    kwargs["output_tokens"] = output_tokens
                total_cost = _get_attr(usage, "cost", None)
                if total_cost is not None:
                    kwargs["total_cost_usd"] = total_cost

            session.track_ai_message(**kwargs)

        elif event_type == "tool_use":
            tool_name = _get_attr(event, "name", "unknown_tool")
            latency = _get_attr(event, "duration_ms", 0.0)
            is_error = _get_attr(event, "is_error", False)

            session.track_tool_call(
                tool_name=tool_name,
                success=not is_error,
                latency_ms=latency,
                input=_get_attr(event, "input", None),
                output=_get_attr(event, "output", None),
            )

        elif event_type == "tool_result":
            # tool_result events are paired with tool_use; skip to avoid
            # double-tracking unless the result carries error info
            is_error = _get_attr(event, "is_error", False)
            if is_error:
                logger.debug(
                    "Tool result error for %s",
                    _get_attr(event, "tool_use_id", "unknown"),
                )

        else:
            logger.debug("Skipping unhandled event type: %s", event_type)


def _get_attr(obj: Any, name: str, default: Any = None) -> Any:
    """Retrieve an attribute from an object or dict."""
    if isinstance(obj, dict):
        return obj.get(name, default)
    return getattr(obj, name, default)


def _extract_text_content(event: Any) -> str:
    """Extract text content from a message event."""
    content = _get_attr(event, "content", None)
    if content is None:
        return ""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: list[str] = []
        for block in content:
            block_type = _get_attr(block, "type", "")
            if block_type == "text":
                text = _get_attr(block, "text", "")
                if text:
                    parts.append(text)
        return "\n".join(parts)
    return str(content)
