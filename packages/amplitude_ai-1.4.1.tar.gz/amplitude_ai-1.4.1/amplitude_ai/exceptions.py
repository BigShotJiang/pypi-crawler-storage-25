"""
Custom exception hierarchy for the Amplitude AI SDK.

All SDK-specific exceptions inherit from :class:`AmplitudeAIError` so
callers can catch the base class for broad error handling.
"""


class AmplitudeAIError(Exception):
    """Base exception for all Amplitude AI SDK errors."""


class ConfigurationError(AmplitudeAIError):
    """Raised when the SDK is misconfigured.

    Examples: no ``amplitude`` instance or ``api_key`` provided,
    invalid ``content_mode`` value, etc.
    """


class TrackingError(AmplitudeAIError):
    """Raised when an event fails to track.

    Wraps underlying transport or serialization failures so callers
    don't need to catch low-level exceptions.
    """


class ProviderError(AmplitudeAIError):
    """Raised for provider-specific issues.

    Examples: required provider SDK not installed, provider returned
    an unexpected response format, etc.
    """


class ValidationError(AmplitudeAIError):
    """Raised when ``validate=True`` and a ``track_*`` call receives invalid arguments.

    Only raised when :attr:`AIConfig.validate` is *True*.  In production
    (default ``validate=False``), bad inputs are silently logged and the
    event is still sent.
    """
