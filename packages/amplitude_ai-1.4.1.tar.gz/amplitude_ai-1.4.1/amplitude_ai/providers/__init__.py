"""Provider integrations for Amplitude AI SDK."""

from typing import Any

from .base import BaseAIProvider


# Import providers only if their dependencies are available
def _import_openai() -> Any:
    try:
        from .openai import OpenAI as _OpenAI

        return _OpenAI
    except (ImportError, NameError):
        return None


def _import_anthropic() -> Any:
    try:
        from .anthropic import Anthropic as _Anthropic

        return _Anthropic
    except (ImportError, NameError):
        return None


def _import_gemini() -> Any:
    try:
        from .gemini import Gemini as _Gemini

        return _Gemini
    except (ImportError, NameError):
        return None


def _import_azure_openai() -> Any:
    try:
        from .azure_openai import AzureOpenAI as _AzureOpenAI

        return _AzureOpenAI
    except (ImportError, NameError):
        return None


def _import_bedrock() -> Any:
    try:
        from .bedrock import Bedrock as _Bedrock

        return _Bedrock
    except (ImportError, NameError):
        return None


def _import_mistral() -> Any:
    try:
        from .mistral import Mistral as _Mistral

        return _Mistral
    except (ImportError, NameError):
        return None


# Lazy imports to avoid requiring all dependencies
OpenAI: Any = _import_openai()
Anthropic: Any = _import_anthropic()
Gemini: Any = _import_gemini()
AzureOpenAI: Any = _import_azure_openai()
Bedrock: Any = _import_bedrock()
Mistral: Any = _import_mistral()

__all__ = [
    "Anthropic",
    "AzureOpenAI",
    "BaseAIProvider",
    "Bedrock",
    "Gemini",
    "Mistral",
    "OpenAI",
]
