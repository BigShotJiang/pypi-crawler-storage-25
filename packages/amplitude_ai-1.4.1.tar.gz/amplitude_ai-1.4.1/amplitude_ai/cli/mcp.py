from __future__ import annotations

from amplitude_ai.mcp.server import run_stdio_server


def main() -> None:
    run_stdio_server()
