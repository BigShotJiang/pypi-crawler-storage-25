from __future__ import annotations

from typing import TypedDict


class IntegrationPattern(TypedDict):
    id: str
    title: str
    when_to_use: str
    snippet: str


INTEGRATION_PATTERNS: list[IntegrationPattern] = [
    {
        "id": "wrap-openai",
        "title": "Recommended production default: wrap provider + session context",
        "when_to_use": "Best balance of implementation effort and customer-value analytics.",
        "snippet": (
            "wrapped = amplitude_ai.wrap(client, amplitude=amp, user_id='u1')\n"
            "agent = amp.agent('assistant', user_id='u1')\n"
            "with agent.session(session_id='s1'):\n"
            "    wrapped.chat.completions.create(model='gpt-4o', messages=[])"
        ),
    },
    {
        "id": "bound-agent-session",
        "title": "Bound agent + session lifecycle",
        "when_to_use": "Need explicit session lineage, multi-agent orchestration, and session analytics.",
        "snippet": "agent = ai.agent('assistant', user_id='u1')\nwith agent.session(session_id='s1') as session:\n    ...",
    },
    {
        "id": "zero-code",
        "title": "Zero-code patching (migration fallback)",
        "when_to_use": "Existing codebase; immediate coverage before upgrading to wrapper + session context.",
        "snippet": "import amplitude_ai\namplitude_ai.patch(amplitude=amp)",
    },
    {
        "id": "tool-decorator",
        "title": "Tool instrumentation",
        "when_to_use": "Need explicit visibility into tool calls and outcomes.",
        "snippet": "@tool\ndef search_products(query: str) -> dict[str, object]:\n    return {'items': []}",
    },
    {
        "id": "fastapi-middleware",
        "title": "FastAPI middleware",
        "when_to_use": "Web app with per-request identity and context propagation.",
        "snippet": "app.add_middleware(AmplitudeAIMiddleware, ai=ai)",
    },
    {
        "id": "multi-agent-run-as",
        "title": "Multi-agent orchestration with session.run_as()",
        "when_to_use": "Parent agent delegates sub-tasks to child agents. Provider wrappers automatically pick up the child agent identity.",
        "snippet": (
            'orchestrator = ai.agent("orchestrator", user_id="u1")\n'
            'researcher = orchestrator.child("researcher")\n'
            'with orchestrator.session(session_id="s1") as s:\n'
            "    with s.run_as(researcher) as cs:\n"
            '        response = client.chat.completions.create(model="gpt-4o", messages=[...])'
        ),
    },
]


def get_integration_patterns() -> list[IntegrationPattern]:
    return [dict(pattern) for pattern in INTEGRATION_PATTERNS]
