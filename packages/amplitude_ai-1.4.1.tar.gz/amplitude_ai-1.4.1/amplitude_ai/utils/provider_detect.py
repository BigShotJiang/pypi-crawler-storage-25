"""Detect drift between declared and actually-patched LLM providers.

If an application declares the providers it uses (e.g. ``["openai"]``) but
``patch()`` ends up instrumenting a different set (e.g. ``["anthropic"]``),
the SDK logs a one-time warning so drift between config and runtime is
visible. Declared set is taken from the ``expected_providers`` kwarg on
:func:`amplitude_ai.patching.patch`.

Warn-only: never raises, never blocks ``patch()``, never interferes with
event emission. The warning fires once per unique (expected, patched)
combination to avoid log spam when the check is exercised repeatedly.
"""

from __future__ import annotations

import threading
from typing import Iterable, Optional, Set

from .logger import get_logger

# Aliases map provider names that are variants of one another to a single
# canonical name for comparison. "async_openai" is the async client of
# the same SDK as "openai"; we don't want a declared "openai" + patched
# "async_openai" to fire a false-positive warning.
_CANONICAL_ALIASES = {
    "async_openai": "openai",
}

_warned_combinations: Set[tuple] = set()
_warned_lock = threading.Lock()


def _canonicalize(providers: Iterable[str]) -> Set[str]:
    return {_CANONICAL_ALIASES.get(p, p) for p in providers}


def warn_if_provider_mismatch(
    *,
    expected_providers: Optional[Iterable[str]],
    patched_providers: Iterable[str],
    app_key: Optional[str] = None,
) -> None:
    """Log a one-time warning if declared providers differ from what patched.

    Args:
        expected_providers: Providers the caller declared via ``patch()``'s
            ``expected_providers`` kwarg. ``None`` or empty => no check.
        patched_providers: The return value of ``patch()``.
        app_key: Optional application key used to deduplicate warnings per
            app. When ``None``, dedup falls back to (expected, patched) sets.
    """
    if not expected_providers:
        return

    expected_set = _canonicalize(str(p) for p in expected_providers if p)
    patched_set = _canonicalize(str(p) for p in patched_providers if p)
    if not expected_set:
        return

    missing = expected_set - patched_set
    unexpected = patched_set - expected_set
    if not missing and not unexpected:
        return

    dedup_key = (
        app_key,
        tuple(sorted(expected_set)),
        tuple(sorted(patched_set)),
    )
    with _warned_lock:
        if dedup_key in _warned_combinations:
            return
        _warned_combinations.add(dedup_key)

    parts: list[str] = []
    if app_key:
        parts.append(f"application {app_key!r}")
    parts.append(
        f"declared providers {sorted(expected_set)} do not match providers "
        f"patched at runtime {sorted(patched_set)}"
    )
    if missing:
        parts.append(f"missing: {sorted(missing)}")
    if unexpected:
        parts.append(f"unexpected: {sorted(unexpected)}")
    message = (
        "amplitude-ai: "
        + "; ".join(parts)
        + ". Events will still be emitted; consider aligning your declared "
        "providers with what your code actually uses."
    )

    logger = get_logger(None)
    logger.warning(message)


def _reset_for_tests() -> None:
    """Clear the dedup set. Intended for use by tests only."""
    with _warned_lock:
        _warned_combinations.clear()
