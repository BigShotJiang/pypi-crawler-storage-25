"""
Logging utility for the Amplitude AI SDK.

Per SDK team guidance, we use ``amplitude.configuration.logger`` when an
``Amplitude`` instance is available.  For module-level logging where no
client is in scope, we fall back to a standard Python logger under the
``amplitude_ai`` namespace.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, cast

if TYPE_CHECKING:
    from amplitude import Amplitude

# Fallback logger for code paths that don't have an Amplitude instance
_fallback_logger = logging.getLogger("amplitude_ai")


def get_logger(amplitude: "Amplitude | None" = None) -> logging.Logger:
    """Return the appropriate logger.

    When an ``Amplitude`` instance is provided, returns its
    ``configuration.logger``.  Otherwise returns the ``amplitude_ai``
    fallback logger.
    """
    if amplitude is not None:
        try:
            logger = amplitude.configuration.logger
            if logger is not None:
                return cast(logging.Logger, logger)
        except AttributeError:
            pass
    return _fallback_logger
