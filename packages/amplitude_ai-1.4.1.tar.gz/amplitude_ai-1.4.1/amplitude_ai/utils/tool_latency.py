"""Bounded, TTL-aware registry for tool-call latency measurement.

When a completion response contains tool-use blocks (``tool_calls`` in
OpenAI Chat/Responses format, ``type=tool_use`` content blocks in
Anthropic format), we record a timestamp keyed by
``(session_id, tool_use_id, agent_id)``. When the next completion in the
same conversation includes the corresponding tool result, the extractor
consumes the timestamp and reports ``latency_ms`` as the wall-clock delta.

Without this, auto-extracted tool call events always reported
``latency_ms=0`` because the extractor had no way to know when the
tool_use was emitted.

Bounded: ``_MAX_ENTRIES`` entries cap prevents unbounded growth if a
caller never sends a matching tool result. LRU-dropped on overflow.
TTL: ``_TTL_SECONDS`` expires stale entries on any access. Thread-safe
via a module-level lock.
"""

from __future__ import annotations

import threading
import time
from collections import OrderedDict
from typing import Optional, Tuple

_MAX_ENTRIES = 10_000
_TTL_SECONDS = 600.0  # 10 minutes

# key -> (recorded_monotonic_seconds, wall_time_at_record_seconds)
_ToolLatencyKey = Tuple[str, str, str]
_registry: "OrderedDict[_ToolLatencyKey, float]" = OrderedDict()
_lock = threading.Lock()


def _make_key(
    session_id: Optional[str],
    tool_use_id: Optional[str],
    agent_id: Optional[str],
) -> Optional[_ToolLatencyKey]:
    if not tool_use_id:
        return None
    return (session_id or "", tool_use_id, agent_id or "")


def record_tool_use(
    *,
    session_id: Optional[str],
    tool_use_id: Optional[str],
    agent_id: Optional[str] = None,
) -> None:
    """Record the moment a tool_use block was emitted by an assistant.

    Called from the completion-tracking path when the response contains
    tool_use blocks. Silently no-ops if ``tool_use_id`` is missing.
    """
    key = _make_key(session_id, tool_use_id, agent_id)
    if key is None:
        return
    now = time.monotonic()
    with _lock:
        _evict_expired_locked(now)
        _registry[key] = now
        _registry.move_to_end(key)
        while len(_registry) > _MAX_ENTRIES:
            _registry.popitem(last=False)


def consume_tool_use_latency_ms(
    *,
    session_id: Optional[str],
    tool_use_id: Optional[str],
    agent_id: Optional[str] = None,
) -> float:
    """Return wall-clock ms since the matching tool_use was recorded.

    Pops the entry on hit. Returns ``0.0`` if no matching record exists
    or the record has expired. Callers should fall back to ``0.0`` as a
    signal that latency was unavailable.
    """
    key = _make_key(session_id, tool_use_id, agent_id)
    if key is None:
        return 0.0
    now = time.monotonic()
    with _lock:
        _evict_expired_locked(now)
        recorded = _registry.pop(key, None)
    if recorded is None:
        return 0.0
    return max(0.0, (now - recorded) * 1000.0)


def _evict_expired_locked(now: float) -> None:
    """Drop entries older than ``_TTL_SECONDS``. Caller must hold ``_lock``."""
    # OrderedDict preserves insertion order; oldest entries are at the head.
    while _registry:
        oldest_key = next(iter(_registry))
        oldest_ts = _registry[oldest_key]
        if (now - oldest_ts) < _TTL_SECONDS:
            return
        _registry.popitem(last=False)


def _reset_for_tests() -> None:
    """Clear the registry. Intended for use by tests only."""
    with _lock:
        _registry.clear()
