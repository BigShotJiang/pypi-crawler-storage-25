"""Provider inference utilities for Amplitude AI SDK."""

from __future__ import annotations


def infer_provider_from_model(model_name: str) -> str:
    """Best-effort provider inference from a model name string.

    Uses substring matching on well-known model families. Falls back to
    ``"openai"`` when no known pattern matches (OpenAI Agents SDK default).

    This is distinct from :func:`amplitude_ai.utils.costs.infer_provider`,
    which extracts an explicit ``"provider:model"`` prefix.
    """
    lower = model_name.lower()
    if any(p in lower for p in ("gpt", "o1", "o3", "o4")):
        return "openai"
    if "claude" in lower:
        return "anthropic"
    if "gemini" in lower:
        return "google"
    if any(p in lower for p in ("mistral", "mixtral")):
        return "mistral"
    return "openai"
