# Releasing amplitude-ai

## Automated Release (recommended)

1. **Bump the version** in `pyproject.toml`:
   ```toml
   version = "1.2.0"
   ```

2. **Regenerate the PyPI README**:
   ```bash
   cd langley/amplitude_ai && python3 generate_pypi_readme.py
   ```

3. **Update the lockfile**:
   ```bash
   cd langley && uv lock
   ```

4. **Commit and push** to master:
   ```bash
   git add langley/amplitude_ai/README.md langley/amplitude_ai/PYPI_README.md langley/amplitude_ai/generate_pypi_readme.py langley/amplitude_ai/pyproject.toml langley/uv.lock langley/amplitude_ai/uv.lock
   git commit -m "AMP-XXXXX [langley] Bump amplitude-ai to vX.Y.Z"
   git push origin master
   ```

5. **Tag the release** and push the tag:
   ```bash
   git tag amplitude-ai-v1.2.0
   git push origin amplitude-ai-v1.2.0
   ```

6. The GitHub Actions workflow (`.github/workflows/amplitude-ai-publish.yml`) triggers automatically and publishes to PyPI.

## Manual Release (fallback)

If the GitHub Action isn't set up yet or you need to publish manually:

```bash
cd langley/amplitude_ai
rm -rf dist
python3 generate_pypi_readme.py
uv build
cd ..
TWINE_USERNAME=__token__ TWINE_PASSWORD='<pypi-token>' uv run twine upload amplitude_ai/dist/*
```

The PyPI API token is stored in the team's 1Password vault. Ask the SDK team for access.

## GitHub Actions Setup

The workflow requires a repository secret named `AMPLITUDE_AI_PYPI_TOKEN`. To set it up:

1. Obtain a **project-scoped** API token from https://pypi.org/manage/project/amplitude-ai/settings/
2. In the amplitude GitHub repo, go to **Settings > Secrets and variables > Actions**
3. Add a new secret: name = `AMPLITUDE_AI_PYPI_TOKEN`, value = the token

## Versioning

- Use [semantic versioning](https://semver.org/): `MAJOR.MINOR.PATCH`
- Use `.postN` suffixes for metadata-only fixes (README, docs) that don't change code
- The version in `pyproject.toml` is the single source of truth; `SDK_VERSION` is read from it at runtime

## PyPI Package

- **Package name**: `amplitude-ai`
- **PyPI URL**: https://pypi.org/project/amplitude-ai/
- **Install**: `pip install amplitude-ai`
