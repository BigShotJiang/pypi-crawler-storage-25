# github.piy_sdlc_security_gates

Detects whether IaC-declared SDLC security gates are configured in
`.github/workflows/*.yml`. Evidences KSI-PIY-RSD "Reviewing Security
in the SDLC" at the configured-gate half of its `partial`
classification — the procedural review cadence ("persistently review
the effectiveness") is Evidence Manifest territory.

## What it detects

For each workflow file in `.github/workflows/`, the detector inspects
every step's `uses:` field and `run:` command for the canonical SDLC
security-gate patterns:

| Gate | Recognition pattern |
|---|---|
| **`codeql`** | `uses: github/codeql-action/(init\|analyze\|autobuild)@...` |
| **`dependency_review`** | `uses: actions/dependency-review-action@...` |
| **`secret_scanning`** | `uses: trufflesecurity/trufflehog@...` OR `uses: gitleaks/gitleaks-action@...` OR `uses: zricethezav/gitleaks-action@...` |

Emits one Evidence per workflow:

- **`gate_state = "configured"`** when ≥1 gate is present, with
  `gates_present` listing which subset.
- **`gate_state = "absent"`** with a gap message when no gate is
  present.

## What it proves

- **KSI-PIY-RSD (Reviewing Security in the SDLC).** Configured SDLC
  security gates in `.github/workflows/`. The configured-state half
  of the KSI's `partial` classification.
- **SA-3 (System Development Life Cycle).** Security gates IN the
  SDLC are the canonical SA-3 evidence at the IaC layer.
- **SA-8 (Security and Privacy Engineering Principles).** CodeQL +
  dependency review + secret scanning in CI is direct Secure-by-Design
  alignment.

## What it does NOT prove

- **Procedural review cadence.** The KSI's "persistently review the
  effectiveness" half is manifest territory.
- **Branch protection rules** (required reviewers, signed commits,
  required status checks). Those are typically declared via
  `github_branch_protection` (Terraform GitHub provider). A separate
  detector candidate.
- **Whether the gate's findings are actually triaged.** Detector
  evidences workflow presence; human-process review of findings is
  procedural.
- **Whether the gate runs on every PR.** A workflow may be configured
  to run only on schedule or only on main branch — the detector treats
  any presence as positive. The Gap Agent reasons about trigger scope.

## KSI mapping

`KSI-PIY-RSD` → `SA-3`, `SA-8`. Per DECISIONS 2026-05-07 "Tier 1 #4
design", KSI-PIY-RSD classified `partial`.

## Fixtures

- `fixtures/should_match/` — workflow YAML files with one or more
  security gates.
- `fixtures/should_not_match/` — workflow YAML files with no security
  gates (CI-only, deploy-only, etc.).
