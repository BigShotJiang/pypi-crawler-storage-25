# Repo-scoped slash commands

Repo-scoped slash commands for Efterlev's recurring multi-file
workflows. Each is a prompt template that compresses a known ritual
into one invocation.

These were added per DECISIONS 2026-05-07 "Process improvements
from v0.1.22-v0.1.27 cascade" follow-up + the Anthropic internal
"How teams use Claude Code" report (Security Engineering's
50%-of-monorepo-slash-commands pattern).

## Available commands

| Command | When to use |
|---|---|
| `/ship-detector <slug> <KSI-ID>` | Ship a new detector PR end-to-end (folder scaffold → tests → register → bump counts → version → docs → CHANGELOG → commit → push → PR). Compresses the 15-file ritual we did 6 times across v0.1.28–v0.1.34. |
| `/release-housekeeping <new-version>` | Bump `__version__` + sweep all version refs across CLAUDE.md / README.md / LIMITATIONS.md / docs / scripts. For hotfix patches and follow-on releases that DON'T add a detector. |
| `/check-state` | Quick repo-state snapshot — version, tests, detector count, KSI coverage, recent releases, latest auto-triage status. Useful at session start. |
| `/decisions-entry <title>` | Draft a DECISIONS.md entry in Efterlev's standard shape. Surfaces the entry as its own PR per the working agreement (design surfaces BEFORE implementation). |

## Scope notes

- These are **repo-scoped** (`.claude/commands/`), not user-scoped
  (`~/.claude/commands/`), so contributors get them automatically
  on `git clone`. No per-developer install required.
- Each command's prompt explicitly references CLAUDE.md sections
  + the working agreement so a future Claude Code session uses the
  same conventions even if the agent hasn't loaded the full
  context yet.
- They are **templates, not automation** — every step is a real
  human decision the agent walks through. The compression is in
  the recipe knowledge, not in skipping verification gates.

## When to add a new command

Add one when:
1. You've done the same multi-step workflow ≥3 times.
2. The recipe has stable shape across invocations (only a few
   parameters change).
3. The cost of forgetting a step is high (e.g. silent doc drift,
   broken release matrix).

Don't add one when:
1. The work is exploratory (every invocation needs different shape).
2. The work is a single-file edit (no compression value).
3. There's already a script for it (e.g. `scripts/triage.sh`).

## Conventions

- File name = command name (e.g. `ship-detector.md` → `/ship-detector`).
- Frontmatter `description:` shows in the slash-command picker.
- `$ARGUMENTS` placeholder receives the user-typed args.
- Reference CLAUDE.md sections by header so contributors can
  navigate to the canonical text.
