# ExternalNetwork

A network external to the system to which ingress components, such as connectors doing SNI forwarding, can send. This is conceptually similar to an ApplicationService, except it is located externally to Agilicus. The collection of External Networks synthesizes endpoints collected from other, persistent collections. It is ephemeral. Its ID is the ID of the object which created i.t 

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | [**ExternalNetworkStatus**](ExternalNetworkStatus.md) |  | 
**metadata** | [**MetadataWithId**](MetadataWithId.md) |  | [optional] 
**any string name** | **bool, date, datetime, dict, float, int, list, str, none_type** | any string name can be used but the value must be the correct type | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


