# ExternalNetworkStatus

The details of an ExternalNetwork as synthesized from another source. `source_object_type` helps to identify where the network originates. 

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**org_id** | **str** | Unique identifier | 
**source_object_type** | [**ObjectType**](ObjectType.md) |  | 
**name** | **str** | A somewhat descriptive name of the original source object, if one is available. Otherwise just the ID. This is not guaranteed to be unique.  | 
**config** | [**NetworkServiceConfig**](NetworkServiceConfig.md) |  | 
**domains** | **[str]** | A list of domains identifying this external network. Domains can be wildcarded, in which case any subdomain of that wildcard may be matched. For ingress components, these domains help to select which ExternalNetwork to send to. For egress components, they help to authorize whether a given request to that external network is allowed.  | 
**routing** | [**ExternalNetworkRouting**](ExternalNetworkRouting.md) |  | 
**connection_uri_template** | **str** | A template for the URI by which this service can be directly accessed. Depending on the type of connector associated with this service, the URI could be public or internal to the Agilicus infrastructure. In both cases, valid credentials proving permission to access this service are necessary to access the service. If this field is empty, then it cannot be accessed directly. In order to build the url, you must provide the following information to the template:   - org_id: the organisation which owns the resource   - resource_id: the id of the resource   - port: the port to connect to   - domain: the domain to contact  Note that if port or domain are invalid for the external service, the request will be rejected.  | [optional] [readonly] 
**any string name** | **bool, date, datetime, dict, float, int, list, str, none_type** | any string name can be used but the value must be the correct type | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


