# ExternalNetworkRouting

How an external network is routed 

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sni_proxy** | **bool** | If true, then ingress components will sni proxy requests for the external network&#39;s hosts. For example, a connector configured to route will forward tls requests whose Server Name Indication (SNI) matches one of the external network&#39;s domains to that external network.  | [optional] 
**any string name** | **bool, date, datetime, dict, float, int, list, str, none_type** | any string name can be used but the value must be the correct type | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


