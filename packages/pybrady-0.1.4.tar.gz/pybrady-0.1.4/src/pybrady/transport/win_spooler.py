# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Windows print-spooler transport (pywin32).

Alternative to :class:`pybrady.transport.UsbTransport` on Windows that
routes bytes through the Windows spooler API instead of reaching for
libusb directly. The practical payoff is that pybrady coexists with
Brady Workstation: the BMP51's existing `usbprint.sys`-backed print
queue stays installed, Workstation can keep using it, and pybrady
talks to the same queue via `WritePrinter`.

Without this transport, using pybrady on Windows requires swapping the
printer's driver to WinUSB via Zadig, which hides the device from the
Windows printer subsystem and breaks Brady Workstation until the user
reverts the swap (see `docs/ideas.md` for the full rationale).

One `async with` block maps to exactly one print job:

    ``OpenPrinter`` -> ``StartDocPrinter`` (datatype=RAW) ->
    ``StartPagePrinter`` -> ``WritePrinter`` (N times) -> ``EndPagePrinter`` ->
    ``EndDocPrinter`` -> ``ClosePrinter``

``read()`` is implemented via ``ReadPrinter``, which surfaces the
printer's bulk-IN bytes through the spooler's port monitor on USB
printer-class devices (``usbmon.dll``). This mirrors how Brady
Workstation reads the 168-byte status response the BMP51 produces in
reply to an ``ESC I`` subscribe.

**Validation status.** Implemented against the documented spooler API
on the assumption that ``ReadPrinter`` surfaces bulk-IN the same way
libusb does; the current unit tests exercise the state machine with a
mocked ``win32print``. Real-hardware validation on Windows with a
BMP51 is pending — see the README's platform-support matrix.
"""

from __future__ import annotations

import asyncio
import contextlib
from collections.abc import Callable
from types import ModuleType
from typing import Any

from pybrady.exceptions import TransportError
from pybrady.transport.base import AsyncTransport


def _read_printer_via_ctypes(hprinter: int, size: int) -> bytes:
    """Call `winspool.drv!ReadPrinter` directly via ctypes.

    pywin32's `win32print` module wraps `WritePrinter` but not
    `ReadPrinter`, so we go straight to `winspool.drv` ourselves. The
    handle is the integer `OpenPrinter` returns — on Windows, Python
    ints convert cleanly to Win32 `HANDLE` via `ctypes.wintypes.HANDLE`.
    Raises `TransportError` with the Win32 error code on failure.
    """
    # Import inside the function so this module still imports cleanly on
    # non-Windows hosts (ctypes.WinDLL only exists on win32). The Windows
    # spooler library's filename is `winspool.drv`, not `winspool.dll` —
    # `ctypes.windll.winspool` would auto-append `.dll` and fail to load,
    # so we go through `WinDLL` with the full filename instead.
    import ctypes
    from ctypes import wintypes

    winspool = ctypes.WinDLL("winspool.drv", use_last_error=True)  # type: ignore[attr-defined]
    read_fn = winspool.ReadPrinter
    read_fn.argtypes = [
        wintypes.HANDLE,
        ctypes.c_void_p,
        wintypes.DWORD,
        ctypes.POINTER(wintypes.DWORD),
    ]
    read_fn.restype = wintypes.BOOL

    buf = ctypes.create_string_buffer(size)
    bytes_read = wintypes.DWORD(0)
    # pywin32's OpenPrinter returns a PyHANDLE wrapper rather than a
    # plain int — ctypes' HANDLE constructor rejects it with "cannot be
    # converted to pointer". Explicit int() coerces through PyHANDLE's
    # __int__ which yields the raw handle value.
    ok = read_fn(int(hprinter), buf, size, ctypes.byref(bytes_read))
    if not ok:
        err = ctypes.get_last_error()  # type: ignore[attr-defined]
        raise TransportError(f"ReadPrinter failed (Win32 error {err})")
    return bytes(buf.raw[: bytes_read.value])


def _import_win32print() -> ModuleType:
    """Import `win32print` or raise `TransportError` with install guidance.

    Factored into a helper so tests can monkeypatch a fake module in its
    place without having pywin32 installed on the host.
    """
    try:
        import win32print
    except ImportError as e:
        raise TransportError(
            "pywin32 is not installed; install pybrady with the 'windows' "
            "extra on Windows: pip install 'pybrady[windows]'"
        ) from e
    module: ModuleType = win32print
    return module


class WindowsSpoolerTransport(AsyncTransport):
    """Async Windows-spooler transport for a Brady printer queue.

    Binds to an existing Windows print queue by name. Unlike
    :class:`UsbTransport`, no driver swap is required — the queue's
    installed driver (typically `usbprint.sys` on a default Brady
    Workstation install) keeps talking to the device and we simply
    hand raw bytes to the spooler via ``WritePrinter``.
    """

    def __init__(
        self,
        *,
        printer_name: str,
        job_title: str = "pybrady",
        datatype: str = "RAW",
    ) -> None:
        self._printer_name = printer_name
        self._job_title = job_title
        self._datatype = datatype
        self._hprinter: Any = None
        self._job_id: int | None = None
        self._page_open = False
        self._win32print: ModuleType | None = None

    @classmethod
    def _enum_all(cls, win32print: ModuleType) -> list[dict[str, Any]]:
        """Return all local+connected printer queues at info level 2."""
        # PRINTER_ENUM_LOCAL (0x02) + PRINTER_ENUM_CONNECTIONS (0x04) covers
        # both directly-attached queues and ones shared over the network —
        # same set the user sees in Settings > Printers & scanners.
        flags = 0x02 | 0x04
        return list(win32print.EnumPrinters(flags, None, 2))

    @classmethod
    def list_printers(cls) -> list[str]:
        """Return the names of every print queue visible to this host.

        Small helper for users who don't know the exact queue name —
        mirrors what `wmic printer get name` would return.
        """
        win32print = _import_win32print()
        return [q["pPrinterName"] for q in cls._enum_all(win32print)]

    @classmethod
    def find_matching(cls, predicate: Callable[[dict[str, Any]], bool]) -> WindowsSpoolerTransport:
        """Return a transport bound to the first queue for which `predicate` is true.

        `predicate` receives an ``EnumPrinters`` level-2 dict with keys
        like ``pPrinterName``, ``pDriverName``, ``pPortName``,
        ``pDescription``. Raises `TransportError` with the list of
        available queues if nothing matches.
        """
        win32print = _import_win32print()
        queues = cls._enum_all(win32print)
        for q in queues:
            if predicate(q):
                return cls(printer_name=q["pPrinterName"])
        names = ", ".join(q["pPrinterName"] for q in queues) or "(none)"
        raise TransportError(f"no matching Windows print queue found; queues on this host: {names}")

    @classmethod
    def find_bmp51(cls) -> WindowsSpoolerTransport:
        """Return a transport bound to the first BMP51 print queue on this host."""
        return cls.find_matching(
            lambda q: (
                "bmp51" in q.get("pPrinterName", "").lower()
                or "bmp51" in q.get("pDriverName", "").lower()
            )
        )

    async def open(self) -> None:
        if self._hprinter is not None:
            return
        await asyncio.get_running_loop().run_in_executor(None, self._open_sync)

    async def close(self) -> None:
        if self._hprinter is None:
            return
        await asyncio.get_running_loop().run_in_executor(None, self._close_sync)

    async def write(self, data: bytes) -> None:
        if self._hprinter is None:
            raise TransportError("transport is not open")
        win32print = self._win32print
        hprinter = self._hprinter
        assert win32print is not None  # populated by _open_sync alongside _hprinter

        def _write() -> int:
            written: int = win32print.WritePrinter(hprinter, data)
            return written

        written = await asyncio.get_running_loop().run_in_executor(None, _write)
        # WritePrinter is documented to always flush the full buffer before
        # returning; a short write indicates a spooler-level problem worth
        # surfacing rather than silently looping here.
        if written != len(data):
            raise TransportError(f"WritePrinter short write: wrote {written} of {len(data)} bytes")

    async def read(self, size: int, timeout: float = 1.0) -> bytes:
        if self._hprinter is None:
            raise TransportError("transport is not open")
        hprinter = self._hprinter

        def _read() -> bytes:
            return _read_printer_via_ctypes(hprinter, size)

        # The spooler ReadPrinter call is blocking with no explicit
        # timeout parameter, so we bound it with asyncio.wait_for — the
        # run_in_executor future will finish when the underlying call
        # returns, and timing out on the asyncio side simply reports a
        # TransportError while the background read stays orphaned. This
        # matches the UsbTransport.read contract callers already rely
        # on; refining it to actually cancel the spooler call would need
        # platform-specific plumbing we don't have a user need for yet.
        future = asyncio.get_running_loop().run_in_executor(None, _read)
        try:
            return await asyncio.wait_for(future, timeout=timeout)
        except TimeoutError as e:
            raise TransportError(f"ReadPrinter timed out after {timeout:.1f}s") from e

    def _open_sync(self) -> None:
        win32print = _import_win32print()
        try:
            hprinter = win32print.OpenPrinter(self._printer_name)
        except Exception as e:  # pywin32 raises pywintypes.error, not OSError
            raise TransportError(
                f"failed to open Windows print queue {self._printer_name!r}: {e}"
            ) from e

        try:
            # StartDocPrinter level 1: (title, pOutputFile, datatype). RAW
            # tells the spooler to pass bytes straight through without the
            # driver's rendering pipeline — what we want for a print job
            # that's already been serialised by pybrady.protocol.
            job_info = (self._job_title, None, self._datatype)
            job_id = win32print.StartDocPrinter(hprinter, 1, job_info)
            win32print.StartPagePrinter(hprinter)
        except Exception as e:
            with contextlib.suppress(Exception):
                win32print.ClosePrinter(hprinter)
            raise TransportError(f"failed to start print job on {self._printer_name!r}: {e}") from e

        self._hprinter = hprinter
        self._job_id = job_id
        self._page_open = True
        self._win32print = win32print

    def _close_sync(self) -> None:
        win32print = self._win32print
        hprinter = self._hprinter
        self._hprinter = None
        self._job_id = None
        self._win32print = None
        page_was_open = self._page_open
        self._page_open = False
        if win32print is None or hprinter is None:
            return
        # Close the job down in the reverse order of _open_sync. Each
        # step is wrapped in suppress so a failure partway through still
        # releases the handle — a leaked hprinter is a permanent spooler
        # leak until the process exits.
        if page_was_open:
            with contextlib.suppress(Exception):
                win32print.EndPagePrinter(hprinter)
        with contextlib.suppress(Exception):
            win32print.EndDocPrinter(hprinter)
        with contextlib.suppress(Exception):
            win32print.ClosePrinter(hprinter)
