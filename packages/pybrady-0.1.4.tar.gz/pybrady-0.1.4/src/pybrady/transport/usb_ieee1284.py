# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""IEEE 1284 Device ID parsing helpers.

USB printer-class devices expose their identity via a standard control
request (`GET_DEVICE_ID`, bmRequestType=0xA1, bRequest=0x00). The response
is a 2-byte big-endian length prefix followed by a set of `KEY:VALUE;`
pairs in ASCII.

Common keys (IEEE 1284.4): MFG, MDL, CMD, DES, CLS, COMMAND SET.
Brady BMP51 at firmware 01.12 returns: `MFG:Brady;CMD:BIDI-VGL;MDL:BMP51;`.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class DeviceId:
    """Parsed IEEE 1284 Device ID."""

    raw: str
    manufacturer: str | None
    model: str | None
    command_set: str | None
    description: str | None
    all_fields: dict[str, str]


def parse(raw_bytes: bytes) -> DeviceId:
    """Parse an IEEE 1284 Device ID from the raw control-transfer response.

    The response starts with a 2-byte big-endian length (including the
    length bytes themselves). The remainder is ASCII `KEY:VALUE;` pairs.
    """
    if len(raw_bytes) < 2:
        raise ValueError(f"Device ID response too short: {raw_bytes!r}")
    length = (raw_bytes[0] << 8) | raw_bytes[1]
    body = raw_bytes[2 : 2 + length - 2] if length >= 2 else raw_bytes[2:]
    text = body.decode("ascii", errors="replace")
    fields: dict[str, str] = {}
    for pair in text.split(";"):
        if ":" not in pair:
            continue
        key, _, value = pair.partition(":")
        k = key.strip().upper()
        if k:
            fields[k] = value.strip()

    # IEEE 1284 allows both "MANUFACTURER" and "MFG", "MODEL"/"MDL", etc.
    def _pick(*keys: str) -> str | None:
        for k in keys:
            if fields.get(k):
                return fields[k]
        return None

    return DeviceId(
        raw=text,
        manufacturer=_pick("MFG", "MANUFACTURER"),
        model=_pick("MDL", "MODEL"),
        command_set=_pick("CMD", "COMMAND SET"),
        description=_pick("DES", "DESCRIPTION"),
        all_fields=fields,
    )
