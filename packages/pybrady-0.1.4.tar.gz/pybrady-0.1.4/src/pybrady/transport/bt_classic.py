# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Bluetooth Classic SPP transport.

Standard SPP RFCOMM UUID: 00001101-0000-1000-8000-00805f9b34fb.
All data is wrapped in a 10-byte segment header (docs/brady_specification.md §2.2).

Cross-platform RFCOMM is awkward in Python — pybluez2 on Linux/Windows,
IOBluetooth/PyObjC on macOS. Implementation deferred until after BLE is working.
"""

from __future__ import annotations

from pybrady.transport.base import AsyncTransport

SPP_UUID = "00001101-0000-1000-8000-00805f9b34fb"


class BtClassicTransport(AsyncTransport):
    def __init__(self, address: str) -> None:
        self._address = address
        raise NotImplementedError("BtClassicTransport is not yet implemented")

    async def open(self) -> None:  # pragma: no cover
        raise NotImplementedError

    async def close(self) -> None:  # pragma: no cover
        raise NotImplementedError

    async def write(self, data: bytes) -> None:  # pragma: no cover
        raise NotImplementedError
