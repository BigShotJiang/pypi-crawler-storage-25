# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""BLE GATT transport (Apollo protocol).

Service UUID: 0000fd1c-0000-1000-8000-00805f9b34fb (used as scan filter).
Characteristics and chunk protocol: docs/brady_specification.md §2.3.

Not yet implemented. Will wrap `bleak` for cross-platform BLE (Linux BlueZ,
macOS CoreBluetooth, Windows WinRT).
"""

from __future__ import annotations

from pybrady.transport.base import AsyncTransport

APOLLO_SERVICE_UUID = "0000fd1c-0000-1000-8000-00805f9b34fb"
SESSION_ID_CHAR_UUID = "fc0018d8-cf12-46be-87b1-cce29b1e6c34"
PRINT_JOB_CHAR_UUID = "7d9d9a4d-b530-4d13-8d61-e0ff445add19"
PICL_REQUEST_CHAR_UUID = "a61ae408-3273-420c-a9db-0669f4f23b69"
PICL_RESPONSE_CHAR_UUID = "786af345-1b68-c594-c643-e2867da117e3"


class BleTransport(AsyncTransport):
    def __init__(self, address: str) -> None:
        self._address = address
        raise NotImplementedError("BleTransport is not yet implemented")

    async def open(self) -> None:  # pragma: no cover
        raise NotImplementedError

    async def close(self) -> None:  # pragma: no cover
        raise NotImplementedError

    async def write(self, data: bytes) -> None:  # pragma: no cover
        raise NotImplementedError
