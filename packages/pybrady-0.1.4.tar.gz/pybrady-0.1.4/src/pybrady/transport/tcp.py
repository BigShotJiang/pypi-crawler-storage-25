# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""TCP transport — Wi-Fi and Ethernet.

Print port assignments (docs/brady_specification.md §2.1):
  9100 — JSON/PICL printers (M611, i5300, S3700, i7500, i4311, C1-30, MJ811)
  9101 — ESC/BMP printers (BMP51/53/61, M610, M710) — print data and session share
  9102 — PICL session port (bidirectional status for JSON/PICL printers)

Not yet implemented.
"""

from __future__ import annotations

from pybrady.transport.base import AsyncTransport


class TcpTransport(AsyncTransport):
    """Placeholder — will wrap asyncio.open_connection with NoDelay/KeepAlive."""

    def __init__(self, host: str, port: int) -> None:
        self._host = host
        self._port = port
        raise NotImplementedError("TcpTransport is not yet implemented")

    async def open(self) -> None:  # pragma: no cover
        raise NotImplementedError

    async def close(self) -> None:  # pragma: no cover
        raise NotImplementedError

    async def write(self, data: bytes) -> None:  # pragma: no cover
        raise NotImplementedError
