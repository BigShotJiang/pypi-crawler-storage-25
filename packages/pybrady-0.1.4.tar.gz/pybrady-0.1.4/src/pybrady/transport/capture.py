# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Capture transports — record byte streams without touching hardware.

`CaptureTransport` records everything `.write()` would have sent to a printer.
Use it for unit tests, golden-byte comparisons, and `--dry-run` modes where
the cost of a real print (label media) outweighs the value of the round-trip.
"""

from __future__ import annotations

from pathlib import Path

from pybrady.transport.base import AsyncTransport


class CaptureTransport(AsyncTransport):
    """In-memory byte sink. Writes append to `.buffer`.

    Implements the full AsyncTransport contract so it drops in anywhere a
    real transport is expected — the printer facade can't tell the difference.
    """

    def __init__(self) -> None:
        self.buffer = bytearray()
        self._opened = False

    @property
    def data(self) -> bytes:
        return bytes(self.buffer)

    async def open(self) -> None:
        self._opened = True

    async def close(self) -> None:
        self._opened = False

    async def write(self, data: bytes) -> None:
        self.buffer.extend(data)

    def save(self, path: str | Path) -> None:
        """Write the captured stream to a file for later inspection or replay."""
        Path(path).write_bytes(self.data)

    def reset(self) -> None:
        self.buffer.clear()
