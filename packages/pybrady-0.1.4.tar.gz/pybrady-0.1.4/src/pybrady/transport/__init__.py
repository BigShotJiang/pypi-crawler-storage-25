# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Transport layer — async I/O to a Brady printer over any supported link."""

from __future__ import annotations

from pybrady.transport.base import AsyncTransport
from pybrady.transport.capture import CaptureTransport

__all__ = [
    "AsyncTransport",
    "BleTransport",
    "BtClassicTransport",
    "CaptureTransport",
    "LinuxUsblpTransport",
    "TcpTransport",
    "UsbTransport",
    "WindowsSpoolerTransport",
]


def __getattr__(name: str) -> type[AsyncTransport]:
    if name == "UsbTransport":
        from pybrady.transport.usb import UsbTransport

        return UsbTransport
    if name == "TcpTransport":
        from pybrady.transport.tcp import TcpTransport

        return TcpTransport
    if name == "BtClassicTransport":
        from pybrady.transport.bt_classic import BtClassicTransport

        return BtClassicTransport
    if name == "BleTransport":
        from pybrady.transport.ble import BleTransport

        return BleTransport
    if name == "WindowsSpoolerTransport":
        from pybrady.transport.win_spooler import WindowsSpoolerTransport

        return WindowsSpoolerTransport
    if name == "LinuxUsblpTransport":
        from pybrady.transport.linux_usblp import LinuxUsblpTransport

        return LinuxUsblpTransport
    raise AttributeError(f"module 'pybrady.transport' has no attribute {name!r}")
