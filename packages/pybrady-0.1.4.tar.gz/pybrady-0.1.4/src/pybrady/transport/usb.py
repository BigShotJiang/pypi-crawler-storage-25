# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""USB transport (libusb via pyusb).

Brady printers enumerate as standard USB-printer-class devices (class 7,
subclass 1). The transport binds to interface 0, bulk-OUT endpoint, and
optionally reads from the bulk-IN endpoint for status.

On Linux the kernel's `usblp` driver claims the device by default; we detach
it at open time and reattach at close. On macOS no driver claims the device.
On Windows WinUSB must be bound to the device first (e.g. with Zadig), or
the `USBPRINT.SYS` driver will block libusb.
"""

from __future__ import annotations

import asyncio
import contextlib
import sys
from typing import Any

from pybrady.exceptions import TransportError
from pybrady.transport.base import AsyncTransport
from pybrady.transport.usb_ieee1284 import DeviceId
from pybrady.transport.usb_ieee1284 import parse as parse_device_id

BRADY_VID = 0x0E2E
BMP51_PID = 0x000B


class UsbTransport(AsyncTransport):
    """Async USB transport over pyusb.

    pyusb is synchronous; all blocking calls are dispatched to the default
    asyncio executor so the transport integrates cleanly with async callers.
    """

    def __init__(
        self,
        *,
        vid: int = BRADY_VID,
        pid: int = BMP51_PID,
        interface: int = 0,
        ep_out: int = 0x01,
        ep_in: int = 0x82,
        write_timeout_ms: int = 10_000,
        init_bidi: bool = True,
    ) -> None:
        self._vid = vid
        self._pid = pid
        self._interface = interface
        self._ep_out = ep_out
        self._ep_in = ep_in
        self._write_timeout_ms = write_timeout_ms
        self._init_bidi = init_bidi
        self._dev: Any = None
        self._detached_kernel_driver = False

    @classmethod
    def find_bmp51(cls) -> UsbTransport:
        """Convenience: a transport bound to Brady BMP51/53 (VID 0e2e:000b)."""
        return cls(vid=BRADY_VID, pid=BMP51_PID)

    async def open(self) -> None:
        if self._dev is not None:
            return
        await asyncio.get_running_loop().run_in_executor(None, self._open_sync)
        # After detaching usblp and claiming the interface raw, the printer's
        # bidirectional status channel stays uninitialised until a GET_DEVICE_ID
        # is issued — matching what usblp does on attach. Without this, BMP51
        # ignores `ESC I` (subscribe) and any other bulk read. Validated on
        # BMP51 FW 01.12; behaviour reproduced from Windows driver (bmp51-4.pcapng).
        if self._init_bidi:
            with contextlib.suppress(Exception):
                await self.get_device_id()

    async def close(self) -> None:
        if self._dev is None:
            return
        await asyncio.get_running_loop().run_in_executor(None, self._close_sync)

    async def write(self, data: bytes) -> None:
        if self._dev is None:
            raise TransportError("transport is not open")
        await asyncio.get_running_loop().run_in_executor(
            None, self._dev.write, self._ep_out, data, self._write_timeout_ms
        )

    async def read(self, size: int, timeout: float = 1.0) -> bytes:
        if self._dev is None:
            raise TransportError("transport is not open")
        dev = self._dev
        ep_in = self._ep_in
        timeout_ms = int(timeout * 1000)

        def _read() -> bytes:
            return bytes(dev.read(ep_in, size, timeout_ms))

        return await asyncio.get_running_loop().run_in_executor(None, _read)

    async def get_device_id(self, timeout: float = 2.0) -> DeviceId:
        """Query the printer's IEEE 1284 Device ID.

        This is a standard USB printer-class control transfer and works on
        any class-compliant printer — safe, unlike vendor-specific status
        probes. On Brady BMP51 firmware 01.12 it returns
        `MFG:Brady;CMD:BIDI-VGL;MDL:BMP51;`.
        """
        if self._dev is None:
            raise TransportError("transport is not open")
        dev = self._dev
        interface = self._interface
        timeout_ms = int(timeout * 1000)

        def _get_id() -> bytes:
            raw = dev.ctrl_transfer(
                bmRequestType=0xA1,
                bRequest=0x00,  # GET_DEVICE_ID
                wValue=1,  # configuration index
                wIndex=interface,
                data_or_wLength=1024,
                timeout=timeout_ms,
            )
            return bytes(raw)

        raw = await asyncio.get_running_loop().run_in_executor(None, _get_id)
        return parse_device_id(raw)

    def _open_sync(self) -> None:
        try:
            import usb.core
            import usb.util
        except ImportError as e:
            raise TransportError(
                "pyusb is not installed; install pybrady with the 'usb' extra: "
                "pip install 'pybrady[usb]'"
            ) from e

        # Windows ships no system libusb, so pyusb's `find()` fails with
        # NoBackendError unless we point it at one. The `[usb]` extra
        # pulls in `libusb-package` on Windows, which bundles a prebuilt
        # libusb-1.0.dll; use its backend explicitly when available.
        # On Linux/macOS the system libusb is reachable via the default
        # search and we pass `backend=None` to let pyusb find it itself.
        backend = None
        if sys.platform == "win32":
            try:
                import libusb_package

                backend = libusb_package.get_libusb1_backend()
            except ImportError:
                # libusb-package is in the [usb] extra on Windows but not
                # listed as required, so we don't hard-fail here — the
                # NoBackendError from pyusb below carries a useful enough
                # message for the user to know what to install.
                pass

        dev = usb.core.find(backend=backend, idVendor=self._vid, idProduct=self._pid)
        if dev is None:
            raise TransportError(f"Brady printer {self._vid:04x}:{self._pid:04x} not found")

        # Detach kernel driver on Linux; no-op/unavailable elsewhere.
        with contextlib.suppress(NotImplementedError, usb.core.USBError):
            if dev.is_kernel_driver_active(self._interface):
                dev.detach_kernel_driver(self._interface)
                self._detached_kernel_driver = True

        # Already-configured or permission-denied will surface on claim_interface below.
        with contextlib.suppress(usb.core.USBError):
            dev.set_configuration()

        try:
            usb.util.claim_interface(dev, self._interface)
        except usb.core.USBError as e:
            raise TransportError(f"failed to claim USB interface: {e}") from e

        self._dev = dev

    def _close_sync(self) -> None:
        import usb.util

        dev = self._dev
        self._dev = None
        with contextlib.suppress(Exception):
            usb.util.release_interface(dev, self._interface)
        if self._detached_kernel_driver:
            with contextlib.suppress(Exception):
                dev.attach_kernel_driver(self._interface)
            self._detached_kernel_driver = False
        with contextlib.suppress(Exception):
            usb.util.dispose_resources(dev)
