# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Abstract async transport interface.

All transports present the same narrow contract: open/close, write arbitrary
bytes, optionally read a response. Protocol generators produce the bytes; the
transport moves them.
"""

from __future__ import annotations

import sys
from abc import ABC, abstractmethod
from types import TracebackType

if sys.version_info >= (3, 11):
    from typing import Self
else:
    from typing_extensions import Self


class AsyncTransport(ABC):
    @abstractmethod
    async def open(self) -> None:
        """Acquire the link. Idempotent."""

    @abstractmethod
    async def close(self) -> None:
        """Release the link. Idempotent."""

    @abstractmethod
    async def write(self, data: bytes) -> None:
        """Send all bytes, blocking until flushed to the transport layer."""

    async def read(self, size: int, timeout: float = 1.0) -> bytes:
        """Read up to `size` bytes. Not all transports support reads."""
        raise NotImplementedError(f"{type(self).__name__} does not support reads")

    async def __aenter__(self) -> Self:
        await self.open()
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        await self.close()
