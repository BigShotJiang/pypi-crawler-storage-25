# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Linux direct-character-device transport (usblp kernel driver).

Alternative to :class:`pybrady.transport.UsbTransport` on Linux that
talks to the printer through the kernel's `usblp` character device
(`/dev/usb/lp*`) instead of bypassing `usblp` via libusb. Practical
benefits:

* **No kernel-driver detach/reattach dance.** `UsbTransport` has to
  call `detach_kernel_driver` on every open and `attach_kernel_driver`
  on close — a sequence that can leave `usblp` detached if the
  process dies between the two. `LinuxUsblpTransport` is a consumer
  of `usblp`, so the driver stays bound throughout.
* **Standard permissions.** `/dev/usb/lp*` is controlled by ordinary
  character-device permissions (usually `lp`-group or `uaccess`-ACL).
  No special udev rule on `/dev/bus/usb/...` is required — the same
  `TAG+="uaccess"` rule pybrady ships covers both paths.
* **Coexistence with CUPS.** `usblp` serialises access, so CUPS
  (or any other client) queuing a job will block us, and vice versa.
  Fair queueing — same model as Brady Workstation coexistence on
  Windows. Not a regression; `UsbTransport` had the same constraint
  via kernel-driver detach.

Uses only stdlib (`os`, `fcntl`, `select`, `glob`) — no pyusb, no
libusb, no extra dependency. Works on Linux only; the module imports
fail on Windows or macOS because `fcntl` and the usblp ioctls are
Linux-specific.

IOCTL numbers come from `include/uapi/linux/usbdevice_fs.h` and the
`usblp` driver's own `include/uapi/linux/lp.h`. See ``man 4 lp`` for
the userspace perspective. Validated against:

* Linux 5.15 (WSL2) — ioctl encoding matches.
* Linux 6.x (Debian 12, Fedora 40, Ubuntu 24.04) — same encoding.
"""

from __future__ import annotations

import asyncio
import contextlib
import struct
from pathlib import Path

from pybrady.exceptions import TransportError
from pybrady.transport.base import AsyncTransport
from pybrady.transport.usb_ieee1284 import DeviceId
from pybrady.transport.usb_ieee1284 import parse as parse_device_id

BRADY_VID = 0x0E2E
BMP51_PID = 0x000B


# ioctl encoding. Matches the standard Linux `_IOC` macro:
#     (dir << 30) | (size << 16) | (type << 8) | nr
_IOC_NONE = 0
_IOC_READ = 2


def _IOC(direction: int, type_char: str, nr: int, size: int) -> int:
    return (direction << 30) | (size << 16) | (ord(type_char) << 8) | nr


# From `include/uapi/linux/lp.h` — the `usblp` driver ioctl family.
# Type char is 'P' (0x50). nr numbers come from `IOCNR_*` in the same
# header; values below match the kernel source as of 6.x and have not
# changed since at least 2.6.
_LP_TYPE = "P"
_IOCNR_GET_DEVICE_ID = 1
_IOCNR_GET_VID_PID = 6
_IOCNR_SOFT_RESET = 7

# LPIOC_GET_DEVICE_ID returns the IEEE 1284 Device ID string preceded
# by its standard 2-byte big-endian length prefix. 1024 bytes is more
# than every Brady printer needs — BMP51 returns ~35 bytes of payload.
_GET_DEVICE_ID_BUFLEN = 1024

# LPIOC_GET_VID_PID returns `struct { unsigned int vid; unsigned int pid; }`
# i.e. 8 bytes of native-endian data.
_GET_VID_PID_BUFLEN = 8


def _LPIOC_GET_DEVICE_ID(buflen: int = _GET_DEVICE_ID_BUFLEN) -> int:
    return _IOC(_IOC_READ, _LP_TYPE, _IOCNR_GET_DEVICE_ID, buflen)


def _LPIOC_GET_VID_PID(buflen: int = _GET_VID_PID_BUFLEN) -> int:
    return _IOC(_IOC_READ, _LP_TYPE, _IOCNR_GET_VID_PID, buflen)


def _LPIOC_SOFT_RESET() -> int:
    return _IOC(_IOC_NONE, _LP_TYPE, _IOCNR_SOFT_RESET, 0)


# Default glob for usblp device nodes. Matches what the kernel creates
# under `/dev/usb/lpN`, indexed from 0.
_USBLP_GLOB = "/dev/usb/lp*"


class _LinuxBackend:
    """Thin wrapper around os/fcntl/select. Lets tests inject a fake.

    Implementations kept tiny on purpose — the real work is in the
    transport class, the backend just isolates the stdlib syscalls so
    unit tests can run on macOS / Windows without Linux-specific
    fixtures.
    """

    def enumerate_paths(self) -> list[str]:
        # `/dev/usb/lp*` — paired Path.glob of the parent directory.
        parent = Path("/dev/usb")
        if not parent.is_dir():
            return []
        return sorted(str(p) for p in parent.glob("lp*"))

    def query_vid_pid(self, path: str) -> tuple[int, int] | None:
        """Return `(vid, pid)` for a usblp node, or `None` on any failure.

        Opens read-only long enough to do the ioctl, then closes.
        Non-fatal failures (permission denied, device disappeared
        between enumerate and query) are swallowed — we just skip the
        node and let discovery continue.
        """
        import fcntl
        import os

        try:
            fd = os.open(path, os.O_RDONLY | os.O_NONBLOCK)
        except OSError:
            return None
        try:
            buf = bytearray(_GET_VID_PID_BUFLEN)
            try:
                fcntl.ioctl(fd, _LPIOC_GET_VID_PID(), buf, True)
            except OSError:
                return None
            vid, pid = struct.unpack("II", bytes(buf))
            return (vid & 0xFFFF, pid & 0xFFFF)
        finally:
            os.close(fd)

    def open_device(self, path: str) -> int:
        import os

        return os.open(path, os.O_RDWR)

    def close_device(self, fd: int) -> None:
        import os

        with contextlib.suppress(OSError):
            os.close(fd)

    def write_device(self, fd: int, data: bytes) -> int:
        import os

        return os.write(fd, data)

    def read_device(self, fd: int, size: int, timeout_s: float) -> bytes:
        """Poll for readability then read. Raises TransportError on timeout."""
        import os
        import select

        rlist, _, _ = select.select([fd], [], [], timeout_s)
        if not rlist:
            raise TransportError(f"usblp read timed out after {timeout_s:.1f}s")
        return os.read(fd, size)

    def get_device_id(self, fd: int) -> bytes:
        import fcntl

        buf = bytearray(_GET_DEVICE_ID_BUFLEN)
        fcntl.ioctl(fd, _LPIOC_GET_DEVICE_ID(), buf, True)
        # usblp writes `(2-byte BE length)(string)` — same shape as the
        # USB class-specific GET_DEVICE_ID control transfer, so we can
        # share `parse_device_id` with `UsbTransport`.
        length_bytes = bytes(buf[:2])
        declared = int.from_bytes(length_bytes, "big")
        # Clamp to buffer size in case the kernel reports garbage.
        declared = max(2, min(declared, len(buf)))
        return bytes(buf[:declared])

    def soft_reset(self, fd: int) -> None:
        import fcntl

        fcntl.ioctl(fd, _LPIOC_SOFT_RESET(), 0)


class LinuxUsblpTransport(AsyncTransport):
    """Async transport over Linux's `usblp` character device."""

    def __init__(
        self,
        *,
        device_path: str,
        init_bidi: bool = True,
        _backend: _LinuxBackend | None = None,
    ) -> None:
        self._device_path = device_path
        self._init_bidi = init_bidi
        self._backend = _backend or _LinuxBackend()
        self._fd: int | None = None

    # --- discovery helpers --------------------------------------------

    @classmethod
    def list_devices(cls, *, _backend: _LinuxBackend | None = None) -> list[tuple[str, int, int]]:
        """Return `(path, vid, pid)` for every usblp node we can query."""
        backend = _backend or _LinuxBackend()
        results: list[tuple[str, int, int]] = []
        for path in backend.enumerate_paths():
            ids = backend.query_vid_pid(path)
            if ids is None:
                continue
            results.append((path, ids[0], ids[1]))
        return results

    @classmethod
    def find_by_vid_pid(
        cls,
        vid: int,
        pid: int,
        *,
        _backend: _LinuxBackend | None = None,
    ) -> LinuxUsblpTransport:
        backend = _backend or _LinuxBackend()
        for path, v, p in cls.list_devices(_backend=backend):
            if v == vid and p == pid:
                return cls(device_path=path, _backend=backend)
        listing = (
            ", ".join(
                f"{Path(p).name}(vid={v:04x},pid={pp:04x})"
                for p, v, pp in cls.list_devices(_backend=backend)
            )
            or "(none)"
        )
        raise TransportError(
            f"no /dev/usb/lp* device matched VID={vid:04x} PID={pid:04x}; available: {listing}"
        )

    @classmethod
    def find_bmp51(cls, *, _backend: _LinuxBackend | None = None) -> LinuxUsblpTransport:
        return cls.find_by_vid_pid(BRADY_VID, BMP51_PID, _backend=_backend)

    # --- async lifecycle ----------------------------------------------

    async def open(self) -> None:
        if self._fd is not None:
            return
        await asyncio.get_running_loop().run_in_executor(None, self._open_sync)
        if self._init_bidi:
            # Same rationale as UsbTransport: BMP51 firmware requires
            # GET_DEVICE_ID as a priming step before `ESC I` subscribes
            # are honoured on the bulk-IN channel. usblp does this
            # itself on attach, but we repeat it to match the libusb
            # path's behaviour exactly — harmless no-op otherwise.
            with contextlib.suppress(Exception):
                await self.get_device_id()

    async def close(self) -> None:
        if self._fd is None:
            return
        await asyncio.get_running_loop().run_in_executor(None, self._close_sync)

    async def write(self, data: bytes) -> None:
        if self._fd is None:
            raise TransportError("transport is not open")
        fd = self._fd
        backend = self._backend

        def _write() -> int:
            return backend.write_device(fd, data)

        written = await asyncio.get_running_loop().run_in_executor(None, _write)
        if written != len(data):
            raise TransportError(f"usblp short write: wrote {written} of {len(data)} bytes")

    async def read(self, size: int, timeout: float = 1.0) -> bytes:
        if self._fd is None:
            raise TransportError("transport is not open")
        fd = self._fd
        backend = self._backend

        def _read() -> bytes:
            return backend.read_device(fd, size, timeout)

        return await asyncio.get_running_loop().run_in_executor(None, _read)

    async def get_device_id(self, timeout: float = 2.0) -> DeviceId:
        """Return the IEEE 1284 Device ID via `LPIOC_GET_DEVICE_ID`."""
        if self._fd is None:
            raise TransportError("transport is not open")
        fd = self._fd
        backend = self._backend

        def _ioctl() -> bytes:
            return backend.get_device_id(fd)

        future = asyncio.get_running_loop().run_in_executor(None, _ioctl)
        raw = await asyncio.wait_for(future, timeout=timeout)
        return parse_device_id(raw)

    async def soft_reset(self) -> None:
        """Issue `LPIOC_SOFT_RESET` to clear a wedged print state.

        Safe to call any time the transport is open. Some Brady
        firmwares require this after a malformed print job before
        subsequent writes are honoured.
        """
        if self._fd is None:
            raise TransportError("transport is not open")
        fd = self._fd
        backend = self._backend

        def _reset() -> None:
            backend.soft_reset(fd)

        await asyncio.get_running_loop().run_in_executor(None, _reset)

    # --- private ------------------------------------------------------

    def _open_sync(self) -> None:
        try:
            self._fd = self._backend.open_device(self._device_path)
        except OSError as e:
            raise TransportError(
                f"failed to open {self._device_path}: {e}. "
                f"Usually a permissions issue — install the udev rule from "
                f"packaging/99-brady.rules or run the command as root."
            ) from e

    def _close_sync(self) -> None:
        fd = self._fd
        self._fd = None
        if fd is not None:
            self._backend.close_device(fd)
