# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Convert a PIL image into raster rows suitable for the ESC/BMP generator.

ESC/BMP convention (docs/brady_specification.md §3.2): MSB-first within each byte,
bit=1 is black, bit=0 is white. PIL's `1` mode is MSB-first but uses the
opposite polarity (1=white, 0=black), so bytes are inverted here.
"""

from __future__ import annotations

from PIL import Image


def image_to_rows(image: Image.Image) -> list[bytes]:
    """Return one row-bytes buffer per raster line, top to bottom.

    Non-`1` mode images are converted with default thresholding. The final byte
    of each row is masked so padding bits outside the image width stay white
    (bit=0) after inversion.
    """
    if image.mode != "1":
        image = image.convert("1")

    width, height = image.size
    stride = (width + 7) // 8
    raw = image.tobytes()
    if len(raw) != stride * height:
        raise ValueError(
            f"PIL row stride mismatch: expected {stride * height} bytes, got {len(raw)}"
        )

    tail_bits = width % 8
    tail_mask = (0xFF << (8 - tail_bits)) & 0xFF if tail_bits else 0xFF

    rows: list[bytes] = []
    for y in range(height):
        row = bytearray(raw[y * stride : (y + 1) * stride])
        for i in range(stride):
            row[i] = ~row[i] & 0xFF
        row[-1] &= tail_mask
        rows.append(bytes(row))
    return rows
