# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Text-to-image rendering with Brady (or system) fonts.

Returns 1-bit PIL images ready to drop into a `Label` compositor or pass
directly to `BradyPrinter.print`.
"""

from __future__ import annotations

from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

# Names Pillow's `truetype()` can resolve via its built-in font search
# paths on each platform. Pillow on Windows looks up fonts by the actual
# on-disk filename in `C:\Windows\Fonts\`, which uses the legacy short
# names like `arialbd.ttf`, not the human-readable `Arial Bold.ttf` that
# Explorer shows. macOS exposes the human-readable names. Linux distros
# ship one or both of DejaVu / Liberation. We list bold variants first
# (labels read better with weight) and fall back to regular weight if
# nothing bold is available.
DEFAULT_FONT_CANDIDATES = (
    # Linux
    "DejaVuSans-Bold.ttf",
    "LiberationSans-Bold.ttf",
    # Windows (file basenames, not display names)
    "arialbd.ttf",
    "calibrib.ttf",
    # macOS
    "Arial Bold.ttf",
    # Regular-weight fallbacks if no bold variant is around
    "DejaVuSans.ttf",
    "LiberationSans-Regular.ttf",
    "arial.ttf",
    "calibri.ttf",
    "Arial.ttf",
)


def load_font(
    size: int,
    *,
    font: str | Path | None = None,
) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
    """Load a TrueType font at the given pixel size.

    `font` may be a file path or a font name resolvable by Pillow. If None,
    tries `DEFAULT_FONT_CANDIDATES` in order, falling back to Pillow's
    built-in bitmap font (which ignores `size`).
    """
    if font is not None:
        return ImageFont.truetype(str(font), size)
    for name in DEFAULT_FONT_CANDIDATES:
        try:
            return ImageFont.truetype(name, size)
        except OSError:
            continue
    return ImageFont.load_default()


def text_block(
    text: str,
    *,
    size: int = 60,
    font: str | Path | None = None,
    padding: int = 0,
) -> Image.Image:
    """Render `text` to a 1-bit image sized exactly to the glyph bounding box.

    Use `Label.paste` to position it; don't use this for full-label layout.
    """
    loaded = load_font(size, font=font)
    # Measure first using a throwaway canvas.
    probe = Image.new("1", (1, 1), 1)
    x0, y0, x1, y1 = (int(v) for v in ImageDraw.Draw(probe).textbbox((0, 0), text, font=loaded))
    w = x1 - x0 + 2 * padding
    h = y1 - y0 + 2 * padding
    img = Image.new("1", (max(1, w), max(1, h)), 1)
    ImageDraw.Draw(img).text((padding - x0, padding - y0), text, fill=0, font=loaded)
    return img


def text_label(
    text: str,
    *,
    width_px: int,
    height_px: int,
    size: int = 60,
    font: str | Path | None = None,
    align: str = "center",
    padding_px: int = 0,
) -> Image.Image:
    """Render `text` on a fixed-size 1-bit canvas with the given horizontal alignment.

    `align` is one of "left", "center", or "right". Vertical position is
    always centered. `padding_px` insets the text from the left or right
    edge when aligned to that side; ignored for center alignment.
    """
    if align not in ("left", "center", "right"):
        raise ValueError(f"invalid align: {align!r}")
    img = Image.new("1", (max(1, width_px), max(1, height_px)), 1)
    loaded = load_font(size, font=font)
    draw = ImageDraw.Draw(img)
    x0, y0, x1, y1 = (int(v) for v in draw.textbbox((0, 0), text, font=loaded))
    tw, th = x1 - x0, y1 - y0
    if align == "left":
        x = padding_px - x0
    elif align == "right":
        x = width_px - tw - padding_px - x0
    else:  # center
        x = (width_px - tw) // 2 - x0
    y = (height_px - th) // 2 - y0
    draw.text((x, y), text, fill=0, font=loaded)
    return img
