# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""QR code rendering via segno.

Install with `pip install 'pybrady[qr]'` or `'pybrady[render]'`.
"""

from __future__ import annotations

import io

from PIL import Image


def qr(
    data: str,
    *,
    size_px: int = 200,
    error: str = "M",
    border: int = 0,
) -> Image.Image:
    """Return a 1-bit PIL image of `data` as a QR code, exactly `size_px` square.

    `error` correction levels: L (7%), M (15%), Q (25%), H (30%).
    `border` is the quiet-zone in modules. 0 is fine for labels since the
    label edge provides the quiet zone; bump to 2 if scanners struggle.
    """
    try:
        import segno
    except ImportError as e:
        raise ImportError(
            "segno is not installed; install pybrady with the 'qr' extra: pip install 'pybrady[qr]'"
        ) from e

    q = segno.make(data, error=error.upper())
    buf = io.BytesIO()
    q.save(buf, kind="png", scale=1, border=border)
    buf.seek(0)
    img = Image.open(buf).convert("1")
    # Nearest-neighbour upscale so module edges stay crisp.
    return img.resize((size_px, size_px), Image.Resampling.NEAREST)
