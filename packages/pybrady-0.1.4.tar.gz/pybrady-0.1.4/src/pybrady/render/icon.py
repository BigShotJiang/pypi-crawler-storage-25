# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Icon / raster-image loading and preparation.

Any PIL-readable format (PNG, JPEG, BMP, TIFF, GIF, etc.) works. For SVGs,
rasterize them first with a tool like `rsvg-convert` or `cairosvg`.
"""

from __future__ import annotations

from pathlib import Path

from PIL import Image


def icon(
    source: str | Path | Image.Image,
    *,
    size_px: int | tuple[int, int] | None = None,
    invert: bool = False,
    threshold: int = 128,
) -> Image.Image:
    """Load an icon, scale it, and threshold to 1-bit monochrome.

    `size_px` may be a single int (square) or (width, height). `None` keeps
    the source size. `invert` swaps black and white — useful for white-on-
    coloured-media icons whose artwork is white on a dark background.
    `threshold` (0-255) sets the grey cutoff before thresholding; lower
    values preserve more detail but risk bleeding ink.
    """
    img = source if isinstance(source, Image.Image) else Image.open(source)

    if size_px is not None:
        target = (size_px, size_px) if isinstance(size_px, int) else size_px
        img = img.resize(target, Image.Resampling.LANCZOS)

    # Convert to greyscale first so thresholding is well-defined regardless
    # of the source mode (RGB, RGBA, palette, etc.).
    grey = img.convert("L")
    if invert:
        grey = grey.point(lambda v: 255 - v)
    return grey.point(lambda v: 0 if v < threshold else 255, mode="1")
