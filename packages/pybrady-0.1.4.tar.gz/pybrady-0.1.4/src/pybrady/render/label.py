# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Label compositor — place rendered elements onto a fixed-size canvas.

`Label` is deliberately thin: it's a positioned-paste wrapper around a PIL
image, not a layout engine. Use it to assemble pre-rendered blocks (text,
QR, barcodes, icons) at explicit coordinates. For complex flows, compose
`Label`s or render your own PIL image and skip this class entirely.
"""

from __future__ import annotations

import sys

from PIL import Image

if sys.version_info >= (3, 11):
    from typing import Self
else:
    from typing_extensions import Self


class Label:
    """A 1-bit PIL canvas with fluent paste operations.

    All coordinates are in pixels from the top-left corner. The canvas starts
    white (bit=1 for PIL's '1' mode); black elements drawn onto it become
    ink when printed via the ESC/BMP / JSON-PICL / VGL generators.
    """

    def __init__(self, width_px: int, height_px: int) -> None:
        if width_px < 1 or height_px < 1:
            raise ValueError(f"label dimensions must be positive, got {width_px}x{height_px}")
        self._image = Image.new("1", (width_px, height_px), 1)

    @property
    def image(self) -> Image.Image:
        return self._image

    @property
    def size(self) -> tuple[int, int]:
        return self._image.size

    def paste(
        self,
        element: Image.Image,
        *,
        at: tuple[int, int] = (0, 0),
    ) -> Self:
        """Paste `element` at pixel position `at`. Returns self for chaining."""
        if element.mode != "1":
            element = element.convert("1")
        self._image.paste(element, at)
        return self

    def paste_centered(self, element: Image.Image, *, y: int | None = None) -> Self:
        """Paste `element` horizontally centered. If `y` is None, also vertically centered."""
        if element.mode != "1":
            element = element.convert("1")
        w, h = self._image.size
        ew, eh = element.size
        x = (w - ew) // 2
        y_ = (h - eh) // 2 if y is None else y
        self._image.paste(element, (x, y_))
        return self
