# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""PDF417 2D barcode rendering via `pdf417gen`.

Install with `pip install 'pybrady[pdf417]'` or `'pybrady[render]'`.

PDF417 is the "stacked 1D" symbology used on US driver's licenses,
shipping labels, and AAMVA-style ID cards. Unlike QR/DataMatrix it
has a distinctly wide aspect ratio and scales best when its natural
proportions are preserved; the renderer therefore accepts a height
and computes width to match, rather than stretching to an arbitrary
rectangle.
"""

from __future__ import annotations

from PIL import Image


def pdf417(
    data: str,
    *,
    width_px: int = 400,
    height_px: int = 100,
    columns: int = 6,
    security_level: int = 2,
) -> Image.Image:
    """Return a 1-bit PIL image of `data` as a PDF417 symbol.

    The encoder picks module geometry from `columns` (data columns;
    more columns => shorter, wider symbol) and `security_level`
    (0-8; higher levels add error-correction codewords at the cost
    of bigger symbols). The resulting native-resolution image is
    then resized to `(width_px, height_px)` with nearest-neighbour
    resampling.

    Raises `ImportError` with a helpful message if `pdf417gen` isn't
    installed.
    """
    try:
        from pdf417gen import encode, render_image
    except ImportError as e:  # pragma: no cover — optional dep
        raise ImportError(
            "PDF417 rendering requires 'pdf417gen'. Install with: pip install 'pybrady[pdf417]'"
        ) from e

    codes = encode(data, columns=columns, security_level=security_level)
    native: Image.Image = render_image(codes, scale=3, ratio=3, padding=0)
    # pdf417gen hands back an RGB image; downsample to the requested
    # bounds and flatten to 1-bit so the output matches the rest of
    # pybrady.render (everything downstream expects `mode == "1"`).
    resized = native.resize((max(1, width_px), max(1, height_px)), Image.Resampling.NEAREST)
    converted: Image.Image = resized.convert("1")
    return converted
