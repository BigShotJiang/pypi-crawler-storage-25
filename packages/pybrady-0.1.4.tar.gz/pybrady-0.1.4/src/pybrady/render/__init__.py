# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Rendering helpers — PIL image primitives for Brady labels.

Core (no extra dependencies):
    image_to_rows    — PIL image → ESC/BMP raster rows
    text_block       — render text sized to its glyph box
    text_label       — render text centered on a fixed-size canvas
    icon             — load a raster image, resize, threshold to 1-bit
    Label            — composer for multi-element labels

Optional (install with the `qr` / `barcode` / `render` extras):
    pybrady.render.qr:qr           — QR code (via segno)
    pybrady.render.barcode:barcode — 1D barcode (via python-barcode)

The optional helpers are not re-exported here so that `import pybrady.render`
doesn't fail when segno/python-barcode aren't installed. Import them from
their submodules: `from pybrady.render.qr import qr`.
"""

from pybrady.render.bitmap import image_to_rows
from pybrady.render.icon import icon
from pybrady.render.label import Label
from pybrady.render.text import load_font, text_block, text_label

__all__ = [
    "Label",
    "icon",
    "image_to_rows",
    "load_font",
    "text_block",
    "text_label",
]
