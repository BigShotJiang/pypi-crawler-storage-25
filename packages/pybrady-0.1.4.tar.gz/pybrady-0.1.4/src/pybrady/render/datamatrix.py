# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""DataMatrix 2D barcode rendering via `ppf-datamatrix`.

Install with `pip install 'pybrady[datamatrix]'` or `'pybrady[render]'`.

DataMatrix is the dominant 2D symbology for manufacturing part marking,
medical device UDI (Unique Device Identification), and anywhere a small,
high-density code with built-in error correction is needed — it's what
you see etched on semiconductor chips and stamped into machined parts.
"""

from __future__ import annotations

from PIL import Image


def datamatrix(
    data: str,
    *,
    size_px: int = 200,
) -> Image.Image:
    """Return a 1-bit PIL image of `data` as a DataMatrix symbol.

    The symbol itself is square; `size_px` is the side length in pixels.
    The module count is picked automatically from the data length by the
    encoder (small messages get a 10x10 matrix, longer messages step up
    through standard DataMatrix sizes). We then scale to `size_px` with
    nearest-neighbour resampling so individual modules stay crisp.

    Raises `ImportError` with a helpful message if the optional
    `ppf-datamatrix` dependency isn't installed.
    """
    try:
        from ppf.datamatrix import DataMatrix
    except ImportError as e:  # pragma: no cover — optional dep
        raise ImportError(
            "DataMatrix rendering requires 'ppf-datamatrix'. "
            "Install with: pip install 'pybrady[datamatrix]'"
        ) from e

    matrix = DataMatrix(data).matrix
    rows = len(matrix)
    cols = len(matrix[0]) if rows else 0
    if rows == 0 or cols == 0:
        raise ValueError(f"DataMatrix encoder produced an empty matrix for {data!r}")

    # Build at native module resolution in mode "L" (8-bit grey) first so
    # pixel writes preserve 0/255 values consistently; then convert to
    # "1" for the final 1-bit output that matches the rest of
    # pybrady.render. Pillow's putpixel on mode "1" has inconsistent
    # internal storage that leaks through get_flattened_data as 0/1
    # instead of 0/255 — building in "L" and converting avoids that.
    base = Image.new("L", (cols, rows), 255)
    pixels = base.load()
    assert pixels is not None  # Image.new always returns a loadable image
    for y, row in enumerate(matrix):
        for x, module in enumerate(row):
            if module:
                pixels[x, y] = 0

    side = max(1, size_px)
    return base.resize((side, side), Image.Resampling.NEAREST).convert("1")
