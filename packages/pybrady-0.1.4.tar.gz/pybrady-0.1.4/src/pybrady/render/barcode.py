# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""1D barcode rendering via python-barcode.

Install with `pip install 'pybrady[barcode]'` or `'pybrady[render]'`.
"""

from __future__ import annotations

import io
from typing import TYPE_CHECKING

from PIL import Image

if TYPE_CHECKING:
    pass

# Symbologies python-barcode ships: code128, code39, ean13, ean8, upca, isbn13,
# isbn10, issn, jan, pzn, codabar, nw-7, itf, gs1, ean14, gs1_128
SUPPORTED_SYMBOLOGIES = (
    "code128",
    "code39",
    "ean13",
    "ean8",
    "upca",
    "isbn13",
    "isbn10",
    "issn",
    "jan",
    "pzn",
    "codabar",
    "nw-7",
    "itf",
    "gs1",
    "ean14",
    "gs1_128",
)


def barcode(
    data: str,
    *,
    symbology: str = "code128",
    height_px: int = 100,
    module_width_px: int = 2,
    write_text: bool = False,
) -> Image.Image:
    """Return a 1-bit PIL image of `data` as a 1D barcode.

    `height_px` is the bar height; total image width depends on the symbology
    and data length. `module_width_px` is the narrow-bar width; wider values
    improve scanner reliability on low-DPI printers or damaged labels.
    `write_text` adds the human-readable numeral underneath the bars.
    """
    try:
        import barcode as _barcode
        from barcode.writer import ImageWriter
    except ImportError as e:
        raise ImportError(
            "python-barcode is not installed; install pybrady with the 'barcode' extra: "
            "pip install 'pybrady[barcode]'"
        ) from e

    cls = _barcode.get_barcode_class(symbology)
    writer = ImageWriter()
    # python-barcode takes all writer options in mm. Convert from pixels
    # assuming 300 DPI (the BMP51 / BMP61 / M6xx native resolution). Callers
    # printing on the 203-DPI M211 can pass adjusted pixel counts; the final
    # raster will be re-scaled by the label compositor anyway.
    mm_per_px = 25.4 / 300
    options = {
        "module_height": height_px * mm_per_px,
        "module_width": module_width_px * mm_per_px,
        "write_text": write_text,
        "quiet_zone": 0,
    }
    buf = io.BytesIO()
    cls(data, writer=writer).write(buf, options=options)
    buf.seek(0)
    return Image.open(buf).convert("1")
