# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Exception hierarchy for pybrady."""


class BradyError(Exception):
    """Base class for all pybrady errors."""


class TransportError(BradyError):
    """I/O failure on a transport (USB, TCP, Bluetooth, BLE)."""


class ProtocolError(BradyError):
    """Malformed or unsupported protocol data."""


class UnsupportedModelError(BradyError):
    """Operation is not supported for the given printer model."""
