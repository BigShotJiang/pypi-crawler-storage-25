# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Locate a Brady Workstation install and export its `.BWT` templates.

Brady Workstation ships thousands of ready-made label templates under
`ProgramData\\Brady Corp\\Brady Workstation\\Addins\\<app>\\Templates\\`.
These are Brady's copyrighted material and can't be redistributed with
pybrady, but a user with a Workstation install can run this tool to
copy them into a portable directory that pybrady (and etiket) can
consume offline.

The tool:

* auto-discovers a Workstation install at the standard paths (Windows
  native and WSL), or takes an explicit `--source` path;
* recursively finds every `.BWT` file and copies it to the `--target`
  directory, preserving the relative `Addins/.../Templates/...` tree;
* produces a `manifest.json` summarising what was exported (per-addin
  counts plus each template's header metadata);
* supports `--dry-run` to preview the action without writing anything.

Run as: `brady-export-templates --target PATH` after `pip install pybrady`,
or directly with `python -m pybrady.tools.export_brady_templates`.
"""

from __future__ import annotations

import argparse
import json
import os
import shutil
import sys
from dataclasses import asdict, dataclass
from pathlib import Path

from pybrady import paths
from pybrady.templates import InvalidBwsFileError, read_header

# Canonical locations Brady Workstation installs its template directory.
# First match wins; users can override with `--source`.
_CANDIDATE_DATA_DIRS: tuple[str, ...] = (
    # WSL path onto a Windows host's C: drive
    "/mnt/c/ProgramData/Brady Corp/Brady Workstation",
    # Native Windows ProgramData (Python resolves this correctly via Path)
    "C:/ProgramData/Brady Corp/Brady Workstation",
)

_ADDINS_SUBDIR = paths.TEMPLATES_SUBDIR
_TEMPLATES_SUBDIR = "Templates"

# Where the Brady-branded TrueType fonts typically land when Brady
# Workstation is installed. The installer copies them into the Windows
# Fonts directory rather than keeping them under ProgramData.
_CANDIDATE_FONT_DIRS: tuple[str, ...] = (
    "/mnt/c/Windows/Fonts",
    "C:/Windows/Fonts",
)
# Name prefixes used to identify Brady's own fonts among the system's
# installed TTFs. Case-insensitive match.
_BRADY_FONT_PREFIXES: tuple[str, ...] = ("brady ",)
_FONTS_SUBDIR = paths.FONTS_SUBDIR

# Brady Workstation ships its icon library (arrows, safety pictograms, GHS /
# ANSI / ISO-regulated symbology, etc.) under Components/ImageLibrary. A
# single `graphicMetadata.xml` catalogues every SVG with category, keywords,
# and regulatory tags. Users who've extracted the library can feed it to
# `pybrady.icons.IconLibrary` for search + rasterisation on top of a label.
_ICONS_SUBDIR = paths.ICONS_SUBDIR
_BRADY_IMAGE_LIBRARY_SUBPATH = Path("Components") / "ImageLibrary"


def default_target_dir() -> Path:
    """Where to drop exported templates when the user doesn't specify a target.

    Delegates to :func:`pybrady.paths.data_dir`, which honours
    `$PYBRADY_DATA_DIR` and otherwise resolves to
    `~/pybrady/brady-templates` — findable on every platform, not
    hidden, and cheap to delete.
    """
    return paths.data_dir()


@dataclass(frozen=True)
class TemplateRecord:
    """One template exported to the target directory."""

    addin: str
    relative_path: str  # path relative to the exported root, using forward slashes
    name: str  # BwsHeader.name (e.g. "1 x 2 inch Barcode 128")
    category: str
    app_name: str
    size_bytes: int


@dataclass(frozen=True)
class FontRecord:
    """One Brady-branded TrueType font copied alongside the templates."""

    relative_path: str  # e.g. "Fonts/Brady Alpine.ttf"
    family_name: str  # derived from the filename (without extension)
    size_bytes: int


@dataclass(frozen=True)
class IconLibrarySummary:
    """Brady's ImageLibrary copied to the target (if the user owns it)."""

    relative_path: str  # e.g. "Icons"
    file_count: int  # total files copied (SVG + PNG + XML + thumbnails)
    has_metadata_index: bool  # graphicMetadata.xml present — required for search


@dataclass(frozen=True)
class ExportSummary:
    source: str
    target: str
    total_templates: int
    per_addin: dict[str, int]
    templates: list[TemplateRecord]
    fonts: list[FontRecord]
    icon_library: IconLibrarySummary | None


def discover_workstation_data_dir(explicit: str | os.PathLike[str] | None = None) -> Path:
    """Return the ProgramData root of a Brady Workstation install.

    Raises `FileNotFoundError` if no install can be found and no
    explicit path was supplied.
    """
    if explicit is not None:
        root = Path(explicit)
        if not (root / _ADDINS_SUBDIR).is_dir():
            raise FileNotFoundError(
                f"{root} doesn't look like a Brady Workstation data dir "
                f"(expected a '{_ADDINS_SUBDIR}' subdirectory)"
            )
        return root

    for candidate in _CANDIDATE_DATA_DIRS:
        root = Path(candidate)
        if (root / _ADDINS_SUBDIR).is_dir():
            return root

    raise FileNotFoundError(
        "could not auto-discover a Brady Workstation install; pass --source explicitly. "
        f"Looked in: {', '.join(_CANDIDATE_DATA_DIRS)}"
    )


def discover_brady_fonts() -> list[Path]:
    """Return TTF paths of every Brady-branded font installed on this system.

    Brady Workstation's installer drops its fonts into the Windows Fonts
    directory (`C:\\Windows\\Fonts\\`) under names like
    `Brady Alpine Bold.ttf`. Fonts are TrueType and therefore
    cross-platform — the exporter copies the bytes into the target and
    `pybrady.templates.render_bws` then loads them on whatever OS the
    user is rendering on.
    """
    found: dict[str, Path] = {}
    for candidate in _CANDIDATE_FONT_DIRS:
        root = Path(candidate)
        if not root.is_dir():
            continue
        for path in root.iterdir():
            if path.suffix.lower() not in (".ttf", ".otf"):
                continue
            lname = path.name.lower()
            if any(lname.startswith(prefix) for prefix in _BRADY_FONT_PREFIXES):
                # First hit wins; users with multiple font locations occasionally
                # end up with duplicates and we just pick the first.
                found.setdefault(path.name, path)
    return sorted(found.values(), key=lambda p: p.name)


def discover_image_library(workstation_root: Path) -> Path | None:
    """Return the path of Brady Workstation's ImageLibrary if present."""
    candidate = workstation_root / _BRADY_IMAGE_LIBRARY_SUBPATH
    if candidate.is_dir():
        return candidate
    return None


def iter_template_files(workstation_root: Path) -> list[tuple[str, Path]]:
    """Return `(addin, path)` for every `.BWT` under each addin's Templates tree.

    `addin` is the directory name under `Addins/`. Results are returned
    sorted by path for deterministic output.
    """
    addins_root = workstation_root / _ADDINS_SUBDIR
    if not addins_root.is_dir():
        return []
    results: list[tuple[str, Path]] = []
    for addin_dir in sorted(p for p in addins_root.iterdir() if p.is_dir()):
        templates_dir = addin_dir / _TEMPLATES_SUBDIR
        if not templates_dir.is_dir():
            continue
        for bwt in sorted(templates_dir.rglob("*.[Bb][Ww][Tt]")):
            results.append((addin_dir.name, bwt))
    return results


def export(
    *,
    source: Path,
    target: Path,
    dry_run: bool = False,
    copy_fonts: bool = True,
    copy_icons: bool = True,
) -> ExportSummary:
    """Copy every `.BWT` from `source` into `target`, preserving structure.

    `copy_fonts` also snapshots Brady's TrueType fonts from the system
    Fonts folder into `<target>/Fonts/` so `render_bws` can find them.

    `copy_icons` also snapshots Brady's `Components/ImageLibrary/` into
    `<target>/Icons/` (about 5,000 SVG files plus the
    `graphicMetadata.xml` index used by `pybrady.icons`).
    """
    files = iter_template_files(source)
    per_addin: dict[str, int] = {}
    records: list[TemplateRecord] = []

    for addin, bwt_path in files:
        rel = bwt_path.relative_to(source)
        dest = target / rel
        try:
            header = read_header(bwt_path)
        except (InvalidBwsFileError, OSError) as e:
            print(f"warning: skipping {rel}: {e}", file=sys.stderr)
            continue

        if not dry_run:
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(bwt_path, dest)

        records.append(
            TemplateRecord(
                addin=addin,
                relative_path=rel.as_posix(),
                name=header.name,
                category=header.category,
                app_name=header.app,
                size_bytes=bwt_path.stat().st_size,
            )
        )
        per_addin[addin] = per_addin.get(addin, 0) + 1

    font_records: list[FontRecord] = []
    if copy_fonts:
        for font_path in discover_brady_fonts():
            rel = Path(_FONTS_SUBDIR) / font_path.name
            dest = target / rel
            if not dry_run:
                dest.parent.mkdir(parents=True, exist_ok=True)
                try:
                    shutil.copy2(font_path, dest)
                except OSError as e:
                    print(f"warning: skipping font {font_path.name}: {e}", file=sys.stderr)
                    continue
            font_records.append(
                FontRecord(
                    relative_path=rel.as_posix(),
                    family_name=font_path.stem,
                    size_bytes=font_path.stat().st_size,
                )
            )

    icon_library: IconLibrarySummary | None = None
    if copy_icons:
        image_library = discover_image_library(source)
        if image_library is not None:
            dest_dir = target / _ICONS_SUBDIR
            file_count = 0
            has_index = (image_library / "graphicMetadata.xml").is_file()
            if not dry_run:
                # Wholesale recursive copy — the ImageLibrary is ~5000 files
                # but relatively small in bytes (SVGs + thumbnails). We
                # never rename or filter: the graphicMetadata.xml index
                # references files by their original names, so any filter
                # would break search.
                if dest_dir.exists():
                    shutil.rmtree(dest_dir)
                shutil.copytree(image_library, dest_dir)
                file_count = sum(1 for _ in dest_dir.rglob("*") if _.is_file())
            else:
                file_count = sum(1 for _ in image_library.rglob("*") if _.is_file())
            icon_library = IconLibrarySummary(
                relative_path=_ICONS_SUBDIR,
                file_count=file_count,
                has_metadata_index=has_index,
            )

    summary = ExportSummary(
        source=str(source),
        target=str(target),
        total_templates=len(records),
        per_addin=per_addin,
        templates=records,
        fonts=font_records,
        icon_library=icon_library,
    )

    if not dry_run:
        target.mkdir(parents=True, exist_ok=True)
        manifest = target / "manifest.json"
        manifest.write_text(
            json.dumps(
                {
                    "source": summary.source,
                    "total_templates": summary.total_templates,
                    "per_addin": summary.per_addin,
                    "templates": [asdict(r) for r in summary.templates],
                    "fonts": [asdict(f) for f in summary.fonts],
                    "icon_library": asdict(summary.icon_library) if summary.icon_library else None,
                },
                indent=2,
            )
            + "\n",
            encoding="utf-8",
        )

    return summary


def _build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="brady-export-templates",
        description=(
            "Export Brady Workstation's bundled .BWT label templates into a "
            "portable directory, preserving the Addins/.../Templates/ structure. "
            "Intended for users who own Brady Workstation and want pybrady / "
            "etiket to see the same template library."
        ),
    )
    p.add_argument(
        "--source",
        type=Path,
        metavar="PATH",
        help=(
            "Brady Workstation ProgramData directory (contains an 'Addins' "
            "subdirectory). Auto-detected at standard Windows and WSL paths if omitted."
        ),
    )
    p.add_argument(
        "--target",
        type=Path,
        default=None,
        metavar="PATH",
        help=(
            "Directory to write templates into (created if needed). "
            f"Defaults to {default_target_dir()}."
        ),
    )
    p.add_argument(
        "--dry-run",
        action="store_true",
        help="List what would be exported without writing any files.",
    )
    p.add_argument(
        "--skip-fonts",
        action="store_true",
        help=(
            "Skip copying Brady-branded TTF fonts from the system Fonts "
            "directory. By default any font whose filename starts with "
            "'Brady ' is copied into a Fonts/ subdirectory of the target."
        ),
    )
    p.add_argument(
        "--skip-icons",
        action="store_true",
        help=(
            "Skip copying Brady's icon library (Components/ImageLibrary). "
            "By default the whole library (~5000 SVG files plus the "
            "graphicMetadata.xml index) is copied to an Icons/ subdirectory "
            "of the target so pybrady.icons can search and rasterise them."
        ),
    )
    p.add_argument(
        "--bundle",
        type=Path,
        metavar="ARCHIVE",
        help=(
            "After exporting, also pack the target directory into a single "
            "archive at ARCHIVE for transport to other hosts. Format is "
            "inferred from the extension: .zip (default if unrecognised; "
            "handled natively by Windows PowerShell and File Explorer), "
            ".tar.gz / .tgz / .tar.bz2 / .tar.xz / .tar."
        ),
    )
    p.add_argument(
        "--from-bundle",
        type=Path,
        metavar="ARCHIVE",
        help=(
            "Skip Brady Workstation discovery and instead extract an "
            "archive produced by --bundle into the target directory. "
            "Mutually exclusive with --source."
        ),
    )
    return p


def main(argv: list[str] | None = None) -> int:
    args = _build_parser().parse_args(argv)

    if args.from_bundle is not None and args.source is not None:
        print("error: --from-bundle and --source are mutually exclusive", file=sys.stderr)
        return 2

    target = args.target if args.target is not None else default_target_dir()

    if args.from_bundle is not None:
        if args.dry_run:
            print(f"would extract {args.from_bundle} into {target.parent} (dry-run)")
            return 0
        try:
            paths.extract_bundle(args.from_bundle, target.parent)
        except (FileNotFoundError, shutil.ReadError) as e:
            print(f"error: {e}", file=sys.stderr)
            return 2
        print(f"extracted {args.from_bundle} into {target.parent}")
        print(f"target: {target}")
        return 0

    try:
        source = discover_workstation_data_dir(args.source)
    except FileNotFoundError as e:
        print(f"error: {e}", file=sys.stderr)
        return 2

    print(f"source: {source}")
    print(f"target: {target}{' (dry-run)' if args.dry_run else ''}")
    summary = export(
        source=source,
        target=target,
        dry_run=args.dry_run,
        copy_fonts=not args.skip_fonts,
        copy_icons=not args.skip_icons,
    )

    if summary.total_templates == 0:
        print("no .BWT templates found; is the Addins directory populated?", file=sys.stderr)
        return 1

    print(f"\n{summary.total_templates} templates found:")
    for addin, count in sorted(summary.per_addin.items()):
        print(f"  {addin:<20s} {count:>5d}")
    if summary.fonts:
        print(f"\n{len(summary.fonts)} Brady fonts copied:")
        for font in summary.fonts:
            print(f"  {font.family_name}")
    if summary.icon_library:
        status = "with" if summary.icon_library.has_metadata_index else "WITHOUT"
        print(
            f"\nIcon library: {summary.icon_library.file_count} files "
            f"({status} graphicMetadata.xml)"
        )
    if not args.dry_run:
        print(f"\nwrote manifest.json to {target}")

    if args.bundle is not None and not args.dry_run:
        try:
            written = paths.create_bundle(target, args.bundle)
        except FileNotFoundError as e:
            print(f"error: {e}", file=sys.stderr)
            return 2
        print(f"bundled target into {written}")
    elif args.bundle is not None:
        print(f"would bundle target into {args.bundle} (dry-run)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
