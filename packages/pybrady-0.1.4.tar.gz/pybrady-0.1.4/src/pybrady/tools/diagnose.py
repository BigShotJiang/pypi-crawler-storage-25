# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Report which pybrady transports will work with the current environment.

Most useful on Windows — the combination of driver binding (stock Brady
driver vs. Zadig-installed WinUSB) and transport (`UsbTransport` via
libusb vs. `WindowsSpoolerTransport` via the print spooler) is where
users get stuck. This tool inspects the current state and explains what
will and won't work, so users don't have to puzzle it out from
`Get-PnpDevice` output.

Run as: `brady-diagnose` after `pip install pybrady`, or directly with
`python -m pybrady.tools.diagnose`.
"""

from __future__ import annotations

import argparse
import json
import platform
import subprocess
import sys
from dataclasses import dataclass

_BMP51_VID = 0x0E2E
_BMP51_PID = 0x000B


@dataclass(frozen=True)
class WindowsDeviceState:
    """One Windows PnP device instance that matched a Brady VID/PID."""

    friendly_name: str
    # e.g. "USBDevice" (WinUSB), "Printer" (stock Brady), "USB" (no function driver)
    device_class: str
    status: str  # "OK", "Unknown", "Error"
    inf_path: str | None  # "oem47.inf", or None if unknown / in-box driver
    instance_id: str


def _run_powershell(script: str) -> str:
    """Run a PowerShell snippet and return its stdout. Empty on failure."""
    try:
        result = subprocess.run(
            ["powershell.exe", "-NoProfile", "-Command", script],
            capture_output=True,
            text=True,
            check=False,
            timeout=15,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return ""
    return result.stdout


def query_windows_devices() -> list[WindowsDeviceState]:
    """Return every BMP51 PnP instance visible on this Windows host.

    Uses `Get-PnpDevice` + `Get-PnpDeviceProperty` to pull the currently-
    bound driver INF per instance. Empty list if nothing matches or if
    PowerShell isn't reachable.
    """
    script = r"""
    $ErrorActionPreference = 'SilentlyContinue'
    $pat = 'USB\VID_0E2E&PID_000B*'
    $devs = Get-PnpDevice | Where-Object { $_.InstanceId -like $pat }
    $rows = foreach ($d in $devs) {
        $key = 'DEVPKEY_Device_DriverInfPath'
        $inf = (Get-PnpDeviceProperty -InstanceId $d.InstanceId -KeyName $key).Data
        [PSCustomObject]@{
            FriendlyName = $d.FriendlyName
            Class        = $d.Class
            Status       = [string]$d.Status
            InfPath      = $inf
            InstanceId   = $d.InstanceId
        }
    }
    # Wrap in array so ConvertTo-Json emits a JSON array even for 1 element.
    ConvertTo-Json -InputObject @($rows) -Compress
    """
    raw = _run_powershell(script).strip()
    if not raw:
        return []
    try:
        data = json.loads(raw)
    except json.JSONDecodeError:
        return []
    states: list[WindowsDeviceState] = []
    for row in data:
        states.append(
            WindowsDeviceState(
                friendly_name=str(row.get("FriendlyName") or ""),
                device_class=str(row.get("Class") or ""),
                status=str(row.get("Status") or ""),
                inf_path=(row["InfPath"] if row.get("InfPath") else None),
                instance_id=str(row.get("InstanceId") or ""),
            )
        )
    return states


def query_windows_print_queues() -> list[str]:
    """Return the names of Windows print queues whose driver names a BMP51."""
    script = (
        "Get-Printer | Where-Object { $_.Name -match 'BMP51' -or "
        "$_.DriverName -match 'Brady' } | Select-Object -ExpandProperty Name"
    )
    raw = _run_powershell(script).strip()
    return [line.strip() for line in raw.splitlines() if line.strip()]


def _classify_windows_state(
    devices: list[WindowsDeviceState],
) -> tuple[str, dict[str, bool]]:
    """Summarise Windows driver state into a verdict + transport-fitness map.

    Verdict is one of:
      - "winusb"   — a WinUSB-style driver is bound (Zadig was run)
      - "stock"    — Brady's stock driver is bound (Workstation works)
      - "absent"   — no matching device is present
      - "mixed"    — conflicting signals; usually means stale PnP entries

    Returns `(verdict, {transport_name: works?})`.
    """
    if not devices:
        return ("absent", {"UsbTransport": False, "WindowsSpoolerTransport": False})

    # Prefer non-"Unknown" entries — Windows keeps stale entries around after
    # port changes or driver swaps. Active enumeration always has Status OK.
    active = [d for d in devices if d.status.upper() == "OK"] or devices

    classes = {d.device_class.lower() for d in active}
    has_winusb = "usbdevice" in classes
    has_printer = "printer" in classes

    if has_winusb and not has_printer:
        return ("winusb", {"UsbTransport": True, "WindowsSpoolerTransport": False})
    if has_printer and not has_winusb:
        return ("stock", {"UsbTransport": False, "WindowsSpoolerTransport": True})
    if has_winusb and has_printer:
        # Both classes present on live entries is weird but can happen with
        # a partial revert or a multi-function device. Call it mixed and let
        # the user decide.
        return ("mixed", {"UsbTransport": True, "WindowsSpoolerTransport": True})
    return ("absent", {"UsbTransport": False, "WindowsSpoolerTransport": False})


def _print_windows_report(devices: list[WindowsDeviceState], print_queues: list[str]) -> int:
    """Render the Windows report to stdout. Returns a shell exit code."""
    if not devices:
        print("No Brady BMP51 detected (VID 0e2e / PID 000b).")
        print("  - Is the printer plugged in and powered on?")
        print("  - Is the USB cable data-capable (not a charge-only cable)?")
        return 1

    print(f"Found {len(devices)} BMP51 PnP instance(s):\n")
    for d in devices:
        stale = " (stale, ignored)" if d.status.upper() != "OK" else ""
        inf = d.inf_path or "(in-box or unresolved)"
        print(f"  {d.friendly_name}{stale}")
        print(f"    class:  {d.device_class}")
        print(f"    status: {d.status}")
        print(f"    driver: {inf}")
        print(f"    id:     {d.instance_id}")
        print()

    verdict, fits = _classify_windows_state(devices)
    print(f"Driver state:  {verdict}")
    if print_queues:
        print(f"Print queues:  {', '.join(print_queues)}")
    else:
        print("Print queues:  (none)")
    print()

    print("Transport suitability:")
    usb_mark = "✅" if fits.get("UsbTransport") else "❌"
    spool_mark = "✅" if fits.get("WindowsSpoolerTransport") and print_queues else "❌"
    print(f"  UsbTransport (full bidi):             {usb_mark}")
    print(f"  WindowsSpoolerTransport (print only): {spool_mark}")
    print()

    if verdict == "winusb":
        print("Brady Workstation: ❌ cannot reach the printer while WinUSB is bound.")
        print("To revert: run `tools\\Revert-BradyWinUSB.ps1` as admin, then replug.")
    elif verdict == "stock":
        print("Brady Workstation: ✅ can reach the printer.")
        print("To enable UsbTransport: run Zadig → WinUSB (see README, Windows → Option A).")
    elif verdict == "mixed":
        print("State is mixed; stale PnP entries may be confusing things.")
        print("Reverting and replugging usually cleans this up.")

    return 0


def _print_linux_report() -> int:
    """Summarise the Linux situation (much simpler than Windows)."""
    try:
        import usb.core
    except ImportError:
        print("pyusb is not installed; this tool uses it to confirm the printer is visible.")
        print("Install: pip install 'pybrady[usb]'")
        return 2

    try:
        dev = usb.core.find(idVendor=_BMP51_VID, idProduct=_BMP51_PID)
    except Exception as e:
        print(f"libusb query failed: {e}")
        return 2

    if dev is None:
        print("No Brady BMP51 detected (VID 0e2e / PID 000b).")
        print("  - Is the printer plugged in and powered on?")
        print("  - Check `lsusb | grep 0e2e` to confirm the kernel sees it.")
        return 1

    print("Brady BMP51 visible to libusb. UsbTransport should work.")
    print("If you hit permission errors, install the udev rule:")
    print("  sudo cp packaging/99-brady.rules /etc/udev/rules.d/")
    print("  sudo udevadm control --reload && sudo udevadm trigger")
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="brady-diagnose",
        description=(
            "Inspect the local environment and report which pybrady transports "
            "will work with the currently-connected Brady printer(s)."
        ),
    )
    parser.parse_args(argv)  # no flags yet; future: --vid / --pid / --json

    system = platform.system()
    if system == "Windows":
        devices = query_windows_devices()
        queues = query_windows_print_queues()
        return _print_windows_report(devices, queues)
    if system == "Linux":
        return _print_linux_report()
    print(f"Platform {system!r} is not yet supported by brady-diagnose.", file=sys.stderr)
    print("Currently detailed output is implemented for Linux and Windows only.")
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
