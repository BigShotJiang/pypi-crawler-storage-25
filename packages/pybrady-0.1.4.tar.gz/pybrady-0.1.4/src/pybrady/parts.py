# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Brady label parts database — look up part numbers, Y-numbers, and
M21-series physical dimensions.

The bulk database (13,426 parts covering 8,000+ unique part numbers across
80+ Brady product families) is sourced from the Brady Express Labels
Android APK's `BradyParts.bin`. It provides part-name → Y-number mapping
and per-record flag bits, but does NOT include physical dimensions for
most parts.

For the M21 series (used by the M211 printer), 24 parts have explicit
dimensions preserved from the APK's `IdentifiedParts` table in
`PE.Ble.Full.dll`. Dimensions for other printers' media are retrievable
**live** from the printer via `BradyPrinter.query_status()`.

Typical usage:

    from pybrady.parts import find

    p = find("MC-1500-595-WT-BK")
    if p is not None:
        print(p.ynumber)   # e.g. "Y5024711"
"""

from __future__ import annotations

import gzip
import json
from dataclasses import dataclass
from functools import lru_cache
from importlib.resources import files


@dataclass(frozen=True)
class PartInfo:
    """A Brady label part record from the BradyParts database."""

    name: str
    ynumber: str
    flags: int


@dataclass(frozen=True)
class M21Dimensions:
    """Physical dimensions for M21-series labels, in dots at 203 DPI.

    Values mirror the APK's `IdentifiedParts` table (spec §8.3).
    `height == 0` means continuous media (no die-cut; user sets length).
    """

    width: int
    height: int
    left_offset: int
    vertical_offset: int
    die_cut: bool
    self_lam: bool
    permasleeve: bool


# M21-series dimensions from docs/brady_specification.md §8.3. These are the only
# parts with offline dimension data; everything else queries live via PICL
# or (for BMP51-style printers) the ESC I status response.
# Indexed by Y-number. Multiple part names can map to the same Y-number.
M21_DIMENSIONS: dict[str, M21Dimensions] = {
    "Y4918675": M21Dimensions(37, 50, 9, 0, True, True, False),  # M21-11-427
    "Y4918682": M21Dimensions(50, 75, 7, 0, True, False, False),  # M21-11-499
    "Y4918687": M21Dimensions(50, 75, 7, 0, True, False, False),  # M21-7-423
    "Y4900592": M21Dimensions(21, 0, 0, 0, False, False, True),  # M21-125-C-342
    "Y4900578": M21Dimensions(21, 0, 0, 0, False, False, True),  # M21-125-C-YL
    "Y4900577": M21Dimensions(50, 0, 0, 0, False, True, False),  # M21-1250-427
    "Y5027106": M21Dimensions(50, 100, 7, 0, True, False, False),  # M21-131-461
    "Y4918683": M21Dimensions(50, 100, 7, 0, True, False, False),  # M21-131-499
    "Y4918688": M21Dimensions(50, 100, 7, 0, True, False, False),  # M21-17-423
    "Y4918676": M21Dimensions(37, 100, 9, 0, True, True, False),  # M21-18-427
    "Y4918685": M21Dimensions(75, 150, 0, 0, True, False, False),  # M21-136-499
    "Y4918690": M21Dimensions(75, 150, 0, 0, True, False, False),  # M21-30-423
    "Y4918691": M21Dimensions(75, 200, 0, 0, True, False, False),  # M21-137-423
    "Y4918686": M21Dimensions(75, 200, 0, 0, True, False, False),  # M21-137-499
    "Y4900579": M21Dimensions(50, 0, 23, 0, False, True, False),  # M21-1500-427
    "Y4918689": M21Dimensions(75, 100, 0, 0, True, False, False),  # M21-18-423
    "Y4918684": M21Dimensions(75, 100, 0, 0, True, False, False),  # M21-18-499
    "Y4900580": M21Dimensions(31, 0, 0, 0, False, False, True),  # M21-187-C-342
    "Y4900581": M21Dimensions(31, 0, 0, 0, False, False, True),  # M21-187-C-YL
    "Y4900607": M21Dimensions(41, 0, 0, 0, False, False, True),  # M21-250-C-342
    "Y4900608": M21Dimensions(41, 0, 0, 0, False, False, True),  # M21-250-C-YL
    "Y4900615": M21Dimensions(37, 0, 8, 0, False, False, False),  # M21-375-499-TB
    "Y4900627": M21Dimensions(60, 0, 0, 0, False, False, True),  # M21-375-C-342
    "Y4900628": M21Dimensions(60, 0, 0, 0, False, False, True),  # M21-375-C-YL
    "Y4900635": M21Dimensions(50, 0, 9, 0, False, False, False),  # M21-500-499-TB
    "Y4900649": M21Dimensions(37, 0, 37, 0, False, True, False),  # M21-750-427
    "Y4918678": M21Dimensions(50, 50, 7, 0, True, False, False),  # M21-89-427
    "Y4918680": M21Dimensions(50, 70, 7, 70, True, False, False),  # M21R0-206-427
    "Y4918681": M21Dimensions(50, 110, 7, 110, True, False, False),  # M21RO-207-427
}


@lru_cache(maxsize=1)
def _load_index() -> tuple[dict[str, PartInfo], dict[str, list[PartInfo]]]:
    """Load and index the parts database (by name and by Y-number).

    Cached for the process lifetime; the file is only read once.
    """
    raw = files("pybrady.data").joinpath("brady_parts.json.gz").read_bytes()
    records = json.loads(gzip.decompress(raw))

    by_name: dict[str, PartInfo] = {}
    by_ynum: dict[str, list[PartInfo]] = {}
    for rec in records:
        info = PartInfo(
            name=rec["name"],
            ynumber=rec["ynumber"],
            flags=int(rec["flags"], 16),
        )
        by_name[info.name] = info
        by_ynum.setdefault(info.ynumber, []).append(info)
    return by_name, by_ynum


def find(name: str) -> PartInfo | None:
    """Look up a part by exact name. Returns None if not in the database."""
    return _load_index()[0].get(name)


def find_by_ynumber(ynumber: str) -> list[PartInfo]:
    """Return every part record sharing this Y-number. Empty list if unknown."""
    return list(_load_index()[1].get(ynumber, ()))


def dimensions_for_m21(name: str) -> M21Dimensions | None:
    """Return M21-series dimensions for `name`, or None if unavailable.

    M21 is the only product family with offline dimension data; for other
    families, query the printer live via `BradyPrinter.query_status()`.
    """
    info = find(name)
    if info is None:
        return None
    return M21_DIMENSIONS.get(info.ynumber)


def all_parts() -> list[PartInfo]:
    """Return the full parts list (13,000+ entries). Copies the cache."""
    return list(_load_index()[0].values())
