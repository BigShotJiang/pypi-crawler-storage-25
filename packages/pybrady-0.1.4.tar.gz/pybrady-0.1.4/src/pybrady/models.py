# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Brady printer model metadata.

Values sourced from `docs/brady_specification.md` §7 (PrinterData.xml extract).
Only models exercised by the current codebase are present; extend as support lands.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class Protocol(Enum):
    ESC_BMP = "esc_bmp"
    JSON_PICL = "json_picl"
    VGL_STX = "vgl_stx"


class CutMode(Enum):
    """Post-print cut behaviour.

    Values match the ESC/BMP page-start cut-mode byte.
    """

    END_OF_JOB = 0
    END_OF_LABEL = 1
    NEVER = 2


@dataclass(frozen=True)
class PrinterModel:
    name: str
    protocol: Protocol
    x_dpi: int
    y_dpi: int
    usb_vid: int | None = None
    usb_pid: int | None = None
    tcp_print_port: int | None = None
    supports_bt_classic: bool = False
    supports_ble: bool = False
    cut_modes: tuple[CutMode, ...] = field(default_factory=tuple)


PRINTER_MODELS: dict[str, PrinterModel] = {
    "BMP51": PrinterModel(
        name="BMP51",
        protocol=Protocol.ESC_BMP,
        x_dpi=300,
        y_dpi=300,
        usb_vid=0x0E2E,
        usb_pid=0x000B,
        tcp_print_port=9101,
        supports_bt_classic=True,
        cut_modes=(CutMode.END_OF_JOB, CutMode.END_OF_LABEL),
    ),
    "BMP53": PrinterModel(
        name="BMP53",
        protocol=Protocol.ESC_BMP,
        x_dpi=300,
        y_dpi=300,
        usb_vid=0x0E2E,
        usb_pid=0x000B,
        tcp_print_port=9101,
        supports_bt_classic=True,
        cut_modes=(CutMode.END_OF_JOB, CutMode.END_OF_LABEL),
    ),
    "BMP61": PrinterModel(
        name="BMP61",
        protocol=Protocol.ESC_BMP,
        x_dpi=300,
        y_dpi=300,
        tcp_print_port=9101,
        cut_modes=(CutMode.END_OF_JOB, CutMode.END_OF_LABEL, CutMode.NEVER),
    ),
}
