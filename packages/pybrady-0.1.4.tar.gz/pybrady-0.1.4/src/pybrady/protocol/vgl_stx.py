# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""VGL/STX print protocol — M211, M511, MM100BT.

Byte-level spec: docs/brady_specification.md §5.
Not yet implemented. Tracked for parity with the ESC/BMP and JSON/PICL generators.
"""

from __future__ import annotations

COMPACT_PICL_GUID = bytes.fromhex("96C2F74A1D214232867820EFE97BC2D3")
