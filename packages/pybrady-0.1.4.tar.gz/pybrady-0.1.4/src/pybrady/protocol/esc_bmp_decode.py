# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""ESC/BMP stream decoder — inspect captured bytes before (or after) printing.

This is the dry-run counterpart to `esc_bmp.py`. It walks a byte stream and
yields one event per command, letting callers count commands, check for
malformed streams, or render a human-readable summary.

Used by `BradyPrinter.dry_run()` and the example's `--dry-run` flag.
"""

from __future__ import annotations

from collections.abc import Iterator
from dataclasses import dataclass
from enum import Enum

from pybrady.exceptions import ProtocolError


def rle_decode(payload: bytes) -> list[tuple[int, int]]:
    """Decode a Brady ESC/BMP RLE payload into `(color, count)` runs.

    Inverse of `esc_bmp.rle_encode`. Bit 7 = colour (0=white, 1=black),
    bits 6-0 = count-1 (so 1-128 pixels per byte).
    """
    return [((b >> 7) & 1, (b & 0x7F) + 1) for b in payload]


class EscOp(Enum):
    JOB_START = "job_start"  # 1B 58 00
    JOB_END = "job_end"  # 1B 44
    PAGE_START = "page_start"  # 1B 4D <cut> 00
    PAGE_END = "page_end"  # 1B 45
    GRAPHICS_LINE = "graphics_line"  # 1B 67 <len16> <data>
    RLE_LINE = "rle_line"  # 1B 68 <len16> <data>
    EMPTY_LINES = "empty_lines"  # 1B 5A <count16>
    SUBSCRIBE = "subscribe"  # 1B 49
    BMP51_LOCK = "bmp51_lock"  # 1B 42 02 00 00 00 17 10
    UNKNOWN = "unknown"  # ESC followed by an unrecognised byte


@dataclass(frozen=True)
class EscEvent:
    op: EscOp
    offset: int
    length: int
    detail: str = ""


def _u16_le(data: bytes, i: int) -> int:
    return data[i] | (data[i + 1] << 8)


def decode(data: bytes) -> Iterator[EscEvent]:
    """Yield `EscEvent`s for each command found in `data`.

    Raises `ProtocolError` only for truncated commands (stream ends mid-command).
    Unrecognised ESC sequences yield an UNKNOWN event and decoding continues
    one byte later — this keeps decode usable on partial captures.
    """
    i = 0
    n = len(data)
    while i < n:
        start = i
        b = data[i]
        if b != 0x1B:
            raise ProtocolError(f"unexpected non-ESC byte 0x{b:02x} at offset {i}")
        if i + 1 >= n:
            raise ProtocolError(f"truncated ESC command at offset {start}")
        cmd = data[i + 1]

        if cmd == 0x58:  # Job Start: 1B 58 00
            if i + 2 >= n:
                raise ProtocolError(f"truncated job-start at {start}")
            if data[i + 2] != 0x00:
                yield EscEvent(
                    EscOp.UNKNOWN, start, 3, f"job-start with non-zero suffix 0x{data[i + 2]:02x}"
                )
            else:
                yield EscEvent(EscOp.JOB_START, start, 3)
            i += 3

        elif cmd == 0x44:  # Job End
            yield EscEvent(EscOp.JOB_END, start, 2)
            i += 2

        elif cmd == 0x4D:  # Page Start: 1B 4D <cut> 00
            if i + 3 >= n:
                raise ProtocolError(f"truncated page-start at {start}")
            cut = data[i + 2]
            if data[i + 3] != 0x00:
                yield EscEvent(
                    EscOp.UNKNOWN, start, 4, f"page-start with non-zero suffix 0x{data[i + 3]:02x}"
                )
            else:
                cut_name = {0: "EndOfJob", 1: "EndOfLabel", 2: "Never"}.get(cut, f"0x{cut:02x}")
                yield EscEvent(EscOp.PAGE_START, start, 4, f"cut={cut_name}")
            i += 4

        elif cmd == 0x45:  # Page End
            yield EscEvent(EscOp.PAGE_END, start, 2)
            i += 2

        elif cmd == 0x67 or cmd == 0x68:  # Graphics / RLE line
            if i + 3 >= n:
                raise ProtocolError(f"truncated raster line at {start}")
            row_len = _u16_le(data, i + 2)
            if i + 4 + row_len > n:
                raise ProtocolError(
                    f"raster line at {start} declares {row_len} bytes but only {n - (i + 4)} remain"
                )
            op = EscOp.GRAPHICS_LINE if cmd == 0x67 else EscOp.RLE_LINE
            yield EscEvent(op, start, 4 + row_len, f"{row_len}B")
            i += 4 + row_len

        elif cmd == 0x5A:  # Empty Lines: 1B 5A <count16>
            if i + 3 >= n:
                raise ProtocolError(f"truncated empty-lines at {start}")
            count = _u16_le(data, i + 2)
            yield EscEvent(EscOp.EMPTY_LINES, start, 4, f"count={count}")
            i += 4

        elif cmd == 0x49:  # Subscribe
            yield EscEvent(EscOp.SUBSCRIBE, start, 2)
            i += 2

        elif cmd == 0x42:  # BMP51 Lock: 1B 42 02 00 00 00 17 10
            if i + 8 <= n and data[i : i + 8] == b"\x1b\x42\x02\x00\x00\x00\x17\x10":
                yield EscEvent(EscOp.BMP51_LOCK, start, 8)
                i += 8
            else:
                yield EscEvent(EscOp.UNKNOWN, start, 2, "ESC B (truncated?)")
                i += 2

        else:
            yield EscEvent(EscOp.UNKNOWN, start, 2, f"ESC 0x{cmd:02x}")
            i += 2


def summary(data: bytes) -> str:
    """Human-readable summary of an ESC/BMP byte stream.

    Intended for `--dry-run` output — counts commands, sums raster bytes,
    and flags anything unrecognised. Does not reproduce the image.
    """
    counts: dict[EscOp, int] = {}
    raster_bytes = 0
    blank_rows = 0
    first_unknown: EscEvent | None = None
    total = 0

    try:
        for ev in decode(data):
            counts[ev.op] = counts.get(ev.op, 0) + 1
            total += 1
            if ev.op in (EscOp.GRAPHICS_LINE, EscOp.RLE_LINE):
                raster_bytes += ev.length - 4
            elif ev.op is EscOp.EMPTY_LINES:
                n = int(ev.detail.split("=")[1])
                blank_rows += n
            elif ev.op is EscOp.UNKNOWN and first_unknown is None:
                first_unknown = ev
    except ProtocolError as e:
        return f"decode error: {e}\n({total} events, {len(data)} bytes)"

    lines = [f"{len(data)} bytes, {total} commands"]
    order = [
        EscOp.JOB_START,
        EscOp.PAGE_START,
        EscOp.GRAPHICS_LINE,
        EscOp.RLE_LINE,
        EscOp.EMPTY_LINES,
        EscOp.PAGE_END,
        EscOp.JOB_END,
        EscOp.SUBSCRIBE,
        EscOp.BMP51_LOCK,
        EscOp.UNKNOWN,
    ]
    for op in order:
        if op in counts:
            lines.append(f"  {op.value}: {counts[op]}")
    if raster_bytes:
        lines.append(f"  raster payload: {raster_bytes} bytes")
    if blank_rows:
        lines.append(f"  blank rows compressed: {blank_rows}")
    if first_unknown is not None:
        lines.append(f"  ⚠ first unknown at offset {first_unknown.offset}: {first_unknown.detail}")
    return "\n".join(lines)
