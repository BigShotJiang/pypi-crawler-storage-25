# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""ESC/BMP command generator for BMP51, BMP53, BMP61, M610, M710.

Byte-level spec: docs/brady_specification.md §3.
All multi-byte length fields are little-endian.
Raster convention: MSB-first within each byte, bit=1 is black, bit=0 is white.
"""

from __future__ import annotations

from collections.abc import Iterable, Sequence

from pybrady.models import CutMode

JOB_START = b"\x1b\x58\x00"
JOB_END = b"\x1b\x44"
PAGE_END = b"\x1b\x45"
SUBSCRIBE = b"\x1b\x49"
BMP51_LOCK = b"\x1b\x42\x02\x00\x00\x00\x17\x10"

_GRAPHICS_LINE = b"\x1b\x67"
_RLE_LINE = b"\x1b\x68"
_EMPTY_LINES = b"\x1b\x5a"


def page_start_bmp51(cut_mode: CutMode = CutMode.END_OF_JOB) -> bytes:
    """`1B 4D <cut_mode> 00` — page start for BMP51/BMP53."""
    return b"\x1b\x4d" + bytes([cut_mode.value, 0x00])


def graphics_line(row: bytes) -> bytes:
    """`1B 67 <len_lo> <len_hi> <raw_data>` — uncompressed raster line."""
    if len(row) > 0xFFFF:
        raise ValueError(f"raster row too long: {len(row)} bytes")
    return _GRAPHICS_LINE + len(row).to_bytes(2, "little") + row


def rle_encode(row: bytes, width_pixels: int | None = None) -> bytes:
    """Encode a row of pixels as Brady ESC/BMP RLE.

    Each output byte carries one run: bit 7 is the colour (0=white, 1=black),
    bits 6-0 are `count - 1` so the representable range is 1-128 pixels per
    byte. Runs longer than 128 are split. Reverse-engineered from a Brady
    Workstation USB capture on 2026-04-12.

    `width_pixels` limits the scan to exactly that many leading pixels of
    `row` — useful when the row is MSB-padded to a full byte boundary.
    If omitted, scans all bits of `row` (width = len(row) * 8).
    """
    if width_pixels is None:
        width_pixels = len(row) * 8
    if width_pixels > len(row) * 8:
        raise ValueError(f"width_pixels ({width_pixels}) exceeds row bit length ({len(row) * 8})")

    out = bytearray()
    current_color: int | None = None
    current_count = 0
    for i in range(width_pixels):
        pixel = (row[i >> 3] >> (7 - (i & 7))) & 1
        if pixel == current_color and current_count < 128:
            current_count += 1
        else:
            if current_count:
                out.append(((current_color or 0) << 7) | (current_count - 1))
            current_color = pixel
            current_count = 1
    if current_count:
        out.append(((current_color or 0) << 7) | (current_count - 1))
    return bytes(out)


def rle_line(row: bytes, width_pixels: int | None = None) -> bytes:
    """`1B 68 <len_lo> <len_hi> <rle_data>` — RLE-compressed raster line."""
    encoded = rle_encode(row, width_pixels)
    if len(encoded) > 0xFFFF:
        raise ValueError(f"RLE row too long: {len(encoded)} bytes")
    return _RLE_LINE + len(encoded).to_bytes(2, "little") + encoded


def empty_lines(count: int) -> bytes:
    """`1B 5A <count_lo> <count_hi>` — skip N blank lines."""
    if not 0 <= count <= 0xFFFF:
        raise ValueError(f"empty line count out of range: {count}")
    return _EMPTY_LINES + count.to_bytes(2, "little")


def build_page(
    rows: Sequence[bytes],
    cut_mode: CutMode = CutMode.END_OF_JOB,
    *,
    compress: bool = True,
    width_pixels: int | None = None,
) -> bytes:
    """Build a single page: page-start, raster lines (with blank-run compression), page-end.

    `rows` is an iterable of equal-length row-byte buffers, one per raster line.
    A row consisting entirely of 0x00 bytes (all white) is collapsed into a
    `1B 5A` empty-line run — this is always safe and saves bandwidth.

    `compress` (default True) emits each non-blank row as RLE if that's
    strictly smaller than the uncompressed form; otherwise it falls back
    to `1B 67`. Set False to force uncompressed output (useful for
    debugging or firmware that doesn't accept `1B 68`).

    `width_pixels` tells the RLE encoder how many leading pixels of each
    row are real (the rest are padding up to the row's byte boundary).
    If None, assumes the full byte-length worth of pixels.
    """
    out = bytearray(page_start_bmp51(cut_mode))
    blank_run = 0
    for row in rows:
        if not any(row):
            blank_run += 1
            if blank_run == 0xFFFF:
                out += empty_lines(0xFFFF)
                blank_run = 0
            continue
        if blank_run:
            out += empty_lines(blank_run)
            blank_run = 0
        if compress:
            rle = rle_line(row, width_pixels)
            raw = graphics_line(row)
            out += rle if len(rle) < len(raw) else raw
        else:
            out += graphics_line(row)
    if blank_run:
        out += empty_lines(blank_run)
    out += PAGE_END
    return bytes(out)


def build_job(
    pages: Iterable[Sequence[bytes]],
    cut_mode: CutMode = CutMode.END_OF_JOB,
    *,
    compress: bool = True,
    width_pixels: int | None = None,
) -> bytes:
    """Wrap one or more pages in a complete ESC/BMP job."""
    out = bytearray(JOB_START)
    for rows in pages:
        out += build_page(rows, cut_mode=cut_mode, compress=compress, width_pixels=width_pixels)
    out += JOB_END
    return bytes(out)
