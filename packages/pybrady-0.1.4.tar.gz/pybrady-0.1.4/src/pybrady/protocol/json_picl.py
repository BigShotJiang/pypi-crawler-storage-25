# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""JSON/PICL print protocol — M611, i5300, S3700, i7500, i4311, C1-30, MJ811.

Byte-level spec: docs/brady_specification.md §4.
Not yet implemented. Tracked for parity with the ESC/BMP and VGL/STX generators.
"""

from __future__ import annotations

PRINT_MAGIC = bytes.fromhex("7F42EE41A91D40909BECFF7A6614CC22")
PICL_JSON_IDENTIFIER_GUID = bytes.fromhex("B3EC099A229248FA83D006840BC99102")
PICL_FILE_TRANSFER_GUID = bytes.fromhex("CDB469807FD54CEB8632591362618B90")
