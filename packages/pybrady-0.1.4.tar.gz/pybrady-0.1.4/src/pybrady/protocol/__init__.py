# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Protocol byte generators — pure, no I/O.

The same byte stream produced here works unchanged over any transport
(USB, TCP, Bluetooth Classic, BLE). Only the transport changes.
"""

from pybrady.protocol import esc_bmp, esc_bmp_decode

__all__ = ["esc_bmp", "esc_bmp_decode"]
