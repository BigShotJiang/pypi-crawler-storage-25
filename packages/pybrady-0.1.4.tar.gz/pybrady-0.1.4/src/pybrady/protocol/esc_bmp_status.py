# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Parser for the BMP51/53/61 ESC/BMP subscribe response.

The `ESC I` (subscribe) command returns a 168-byte structured packet
containing the loaded substrate part number, ribbon part number, and
numeric fields covering media dimensions, counters, and printer state.

Byte layout (all multi-byte fields are little-endian):

    offset  size  field
    ------  ----  -----
    0x00    4     header — byte[1] = total length (0xA8 = 168), rest unknown
    0x04    4     flags (observed `05 00 01 01` — meaning undocumented)
    0x08    24    substrate part number, ASCII, null-padded
    0x20    24    ribbon part number, ASCII, null-padded
    0x58    2     media width (thou), LE u16
    0x5A    2     printable width (thou), LE u16
    0x98    4     media capacity — original total, LE u32
    0x9C    4     media remaining — runtime counter, LE u32 — ticks
                  down per print. Units are **media-specific**: the
                  per-label decrement varies by cartridge type.
    0xA0    4     media capacity — duplicate of 0x98
    0xA4    4     media remaining — last read from the cartridge chip.
                  Updates only on media-cover close. Matches 0x9C
                  immediately after close, then diverges as 0x9C
                  decrements on prints.
    rest    -     unknown; likely lifetime counters + sensor calibration

**Important:** the absolute unit of the remaining/capacity fields is
NOT a fixed length (inches, thou, dots). It differs per media type —
the raw counter on MC-1500-595-WT-BK has values in the hundreds of
thousands, while on M4-143-427 it's in the hundreds. A BMP51 LCD
showing ~50% for a cartridge corresponds to remaining/capacity ≈ 0.5,
which is the only cross-media-stable metric. Until we decode the unit
system, expose raw ticks and a derived percentage.

Spec origin: reverse-engineered from USBPcap capture `bmp51-4.pcapng`
(Brady Workstation on Windows, 2026-04-12) and refined on Linux via
controlled experiments across two media types (MC-1500, M4-143).
"""

from __future__ import annotations

import struct
from dataclasses import dataclass

from pybrady.exceptions import ProtocolError

STATUS_LENGTH = 168
SUBSTRATE_OFFSET = 0x08
SUBSTRATE_LENGTH = 24
RIBBON_OFFSET = 0x20
RIBBON_LENGTH = 24


@dataclass(frozen=True)
class BmpStatus:
    """Decoded BMP51 subscribe response.

    `raw` is always the full 168 bytes. String and numeric fields are the
    fields we've decoded so far; unrecognised bytes stay in `raw` for
    future parsing.
    """

    raw: bytes
    substrate_part: str | None
    ribbon_part: str | None
    # Validated on MC-1500-595-WT-BK and M4-143-427.
    media_width_thou: int | None
    printable_width_thou: int | None
    # Media-capacity + remaining counters (LE u32). Absolute units are
    # media-specific and undecoded; use `media_remaining_fraction` for a
    # stable cross-media metric.
    media_capacity_units: int | None
    media_remaining_units: int | None
    media_remaining_chip_units: int | None

    @property
    def media_remaining_fraction(self) -> float | None:
        """Fraction of cartridge remaining (0.0-1.0), based on runtime counter.

        This is the only cross-media-stable metric we can derive from the
        status struct. Multiply by 100 for a "% remaining" display.
        """
        if self.media_remaining_units is None or not self.media_capacity_units:
            return None
        return self.media_remaining_units / self.media_capacity_units


def _read_ascii_nullpadded(data: bytes, offset: int, length: int) -> str | None:
    field = data[offset : offset + length].rstrip(b"\x00")
    if not field:
        return None
    try:
        return field.decode("ascii")
    except UnicodeDecodeError:
        return field.decode("ascii", errors="replace")


def parse(data: bytes) -> BmpStatus:
    """Parse a 168-byte BMP51 subscribe response.

    Raises `ProtocolError` if the buffer is too short or the declared
    length byte doesn't match. Unknown fields are preserved in `raw`.
    """
    if len(data) < STATUS_LENGTH:
        raise ProtocolError(f"BMP status too short: got {len(data)} bytes, need {STATUS_LENGTH}")
    if data[1] != STATUS_LENGTH:
        raise ProtocolError(
            f"BMP status length-byte mismatch: header says 0x{data[1]:02x}, "
            f"expected 0x{STATUS_LENGTH:02x}"
        )
    buf = data[:STATUS_LENGTH]

    # Numeric fields: see module docstring for positional rationale.
    media_width = struct.unpack_from("<H", buf, 0x58)[0]
    printable_width = struct.unpack_from("<H", buf, 0x5A)[0]
    capacity = struct.unpack_from("<I", buf, 0x98)[0]
    remaining = struct.unpack_from("<I", buf, 0x9C)[0]
    remaining_chip = struct.unpack_from("<I", buf, 0xA4)[0]

    return BmpStatus(
        raw=bytes(buf),
        substrate_part=_read_ascii_nullpadded(buf, SUBSTRATE_OFFSET, SUBSTRATE_LENGTH),
        ribbon_part=_read_ascii_nullpadded(buf, RIBBON_OFFSET, RIBBON_LENGTH),
        media_width_thou=media_width or None,
        printable_width_thou=printable_width or None,
        media_capacity_units=capacity or None,
        media_remaining_units=remaining or None,
        media_remaining_chip_units=remaining_chip or None,
    )
