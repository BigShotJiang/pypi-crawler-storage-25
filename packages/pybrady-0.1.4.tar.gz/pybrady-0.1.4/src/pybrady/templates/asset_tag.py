# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Asset-tag template — identifier, optional description, optional barcode/QR.

Typical shape for tracking inventory: a short identifier (serial,
asset number, room number) in large type, often with a smaller
description line and a machine-readable code (1D barcode and/or QR)
so handhelds can scan the same tag a human reads.

Layouts the renderer handles:

* **text only** — identifier ± description, centred on the canvas.
* **text + QR** — QR square carved off the right edge, text left.
* **text + barcode** — 1D barcode strip along the bottom, text above.
* **text + QR + barcode** — QR right, barcode bottom, text top-left.

`barcode` and `qr` each accept `False` (off), `True` (encode the
identifier), or an explicit string (e.g. a URL for the QR). The
1D symbology defaults to Code 128; see `barcode_symbology` for
alternatives supported by `pybrady.render.barcode`.

Combines cleanly with the sequence parser for generating ranges:

    >>> from pybrady.templates.asset_tag import asset_tag
    >>> from pybrady.templates.sequence import expand
    >>> labels = [asset_tag(i, qr=True) for i in expand("ACME-001..ACME-100")]
"""

from __future__ import annotations

from pathlib import Path

from PIL import Image, ImageDraw

from pybrady.render.text import load_font


def _draw_text_block(
    canvas: Image.Image,
    *,
    region: tuple[int, int, int, int],
    identifier: str,
    description: str,
    identifier_font_size: int,
    description_font_size: int,
    font: str | Path | None,
) -> None:
    """Draw identifier (+ optional description) centred inside `region`.

    `region` is `(x0, y0, x1, y1)` in canvas-pixel coordinates.
    """
    x0, y0, x1, y1 = region
    region_w = max(1, x1 - x0)
    region_h = max(1, y1 - y0)

    draw = ImageDraw.Draw(canvas)
    id_font = load_font(identifier_font_size, font=font)
    id_bx0, id_by0, id_bx1, id_by1 = draw.textbbox((0, 0), identifier, font=id_font)
    id_w, id_h = int(id_bx1 - id_bx0), int(id_by1 - id_by0)

    if not description:
        x = x0 + (region_w - id_w) // 2 - int(id_bx0)
        y = y0 + (region_h - id_h) // 2 - int(id_by0)
        draw.text((x, y), identifier, fill=0, font=id_font)
        return

    desc_font = load_font(description_font_size, font=font)
    desc_bx0, desc_by0, desc_bx1, desc_by1 = draw.textbbox((0, 0), description, font=desc_font)
    desc_w, desc_h = int(desc_bx1 - desc_bx0), int(desc_by1 - desc_by0)

    # Stack two lines with a tenth-of-identifier-height gap, centred
    # vertically within the region.
    gap = max(2, id_h // 10)
    stack_h = id_h + gap + desc_h
    stack_top = y0 + max(0, (region_h - stack_h) // 2)

    id_x = x0 + (region_w - id_w) // 2 - int(id_bx0)
    id_y = stack_top - int(id_by0)
    draw.text((id_x, id_y), identifier, fill=0, font=id_font)

    desc_x = x0 + (region_w - desc_w) // 2 - int(desc_bx0)
    desc_y = stack_top + id_h + gap - int(desc_by0)
    draw.text((desc_x, desc_y), description, fill=0, font=desc_font)


def _render_qr_block(data: str, size_px: int, error: str) -> Image.Image:
    from pybrady.render.qr import qr as render_qr

    return render_qr(data, size_px=size_px, error=error)


def _render_barcode_block(data: str, symbology: str, width_px: int, height_px: int) -> Image.Image:
    from pybrady.render.barcode import barcode as render_barcode

    img = render_barcode(data, symbology=symbology, height_px=height_px)
    if img.size != (width_px, height_px):
        img = img.resize((width_px, height_px), Image.Resampling.NEAREST)
    return img


def asset_tag(
    identifier: str,
    *,
    description: str = "",
    barcode: bool | str = False,
    qr: bool | str = False,
    barcode_symbology: str = "code128",
    qr_error: str = "M",
    width_in: float = 1.5,
    height_in: float = 0.5,
    dpi: int = 300,
    identifier_font_size: int = 48,
    description_font_size: int = 20,
    font: str | Path | None = None,
) -> Image.Image:
    """Render an asset tag with identifier, optional description, and optional codes.

    `barcode` and `qr` accept `False` (off), `True` (encode the
    identifier), or an explicit string to encode something different
    (e.g. a URL for QR).

    Layout:

    * QR carves a square of side `height_in` from the right edge.
    * Barcode carves a strip of height `height_in / 3` from the bottom
      of the remaining area.
    * Text (identifier + optional description) fills the rectangle
      that's left after those carves.

    `barcode_symbology` picks the 1D symbology (default `"code128"`);
    see `pybrady.render.barcode.SUPPORTED_SYMBOLOGIES` for the list.
    `qr_error` is the QR error-correction level: `"L"`, `"M"`, `"Q"`,
    or `"H"` (default `"M"`).

    `identifier_font_size` / `description_font_size` are pixels at the
    output DPI. `font` is an optional TTF path or Pillow-resolvable
    family name.
    """
    if width_in <= 0 or height_in <= 0:
        raise ValueError(f"width_in and height_in must be positive ({width_in}, {height_in})")
    if not identifier:
        raise ValueError("identifier must be non-empty")

    width_px = max(1, round(width_in * dpi))
    height_px = max(1, round(height_in * dpi))

    qr_data = identifier if qr is True else (qr if isinstance(qr, str) else None)
    barcode_data = (
        identifier if barcode is True else (barcode if isinstance(barcode, str) else None)
    )

    qr_size_px = height_px if qr_data is not None else 0
    # Barcode gets the bottom third — enough height to stay scannable on
    # a 0.5" label without starving the text of vertical room.
    barcode_h_px = height_px // 3 if barcode_data is not None else 0

    text_w = width_px - qr_size_px
    text_h = height_px - barcode_h_px
    if text_w < 8 or text_h < 8:
        raise ValueError(
            f"label too small for the requested codes: text region {text_w}x{text_h} px"
        )

    canvas = Image.new("1", (width_px, height_px), 1)

    _draw_text_block(
        canvas,
        region=(0, 0, text_w, text_h),
        identifier=identifier,
        description=description,
        identifier_font_size=identifier_font_size,
        description_font_size=description_font_size,
        font=font,
    )

    if qr_data is not None:
        qr_img = _render_qr_block(qr_data, size_px=qr_size_px, error=qr_error)
        canvas.paste(qr_img, (width_px - qr_size_px, 0))

    if barcode_data is not None:
        bc_img = _render_barcode_block(
            barcode_data,
            symbology=barcode_symbology,
            width_px=text_w,
            height_px=barcode_h_px,
        )
        canvas.paste(bc_img, (0, height_px - barcode_h_px))

    return canvas
