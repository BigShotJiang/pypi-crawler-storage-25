# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Patch-panel template — grid of port-label cells on one strip.

A 1U patch panel typically has 24 or 48 ports across, sometimes in
two rows; the matching label sits as a single strip in front of or
below the ports with one small cell per port. `patch_panel` renders
that strip in one go:

    >>> patch_panel("1..24", width_in=7.0, height_in=0.375)     # single row
    >>> patch_panel("A1..A24,B1..B24", width_in=7.0, rows=2)    # two rows
    >>> patch_panel(["eth0", "eth1", ...], width_in=7.0)        # explicit list

`ports` accepts either a sequence expression (which the
`pybrady.templates.sequence.expand` parser handles — see its module
docstring for the full range of shapes) or an explicit list of
strings, so anything from a DCIM query to a hand-rolled map drops in.

Font size auto-fits by default: the renderer picks the largest size
where the longest port name still fits inside one cell with a small
padding. Pass `font_size` explicitly to pin it.
"""

from __future__ import annotations

from collections.abc import Sequence
from pathlib import Path

from PIL import Image, ImageDraw

from pybrady.render.text import load_font, text_label
from pybrady.templates.sequence import expand


def _measure_width(text: str, size: int, font: str | Path | None) -> int:
    loaded = load_font(size, font=font)
    probe = Image.new("1", (1, 1), 1)
    x0, _, x1, _ = ImageDraw.Draw(probe).textbbox((0, 0), text, font=loaded)
    return max(0, int(x1 - x0))


def _auto_font_size(
    ports: Sequence[str],
    cell_w: int,
    cell_h: int,
    padding_px: int,
    font: str | Path | None,
) -> int:
    """Largest integer font size such that every port name fits in a cell.

    Searches downward from `cell_h - 2*padding_px` (an upper bound set
    by the cell height) until the longest port name fits within the
    cell width minus padding. Floors at 8 px so even pathological
    inputs still render legibly rather than returning zero.
    """
    longest = max(ports, key=len) if ports else ""
    max_w = max(1, cell_w - 2 * padding_px)
    start = max(8, cell_h - 2 * padding_px)
    for size in range(start, 7, -1):
        if _measure_width(longest, size, font) <= max_w:
            return size
    return 8


def patch_panel(
    ports: str | Sequence[str],
    *,
    width_in: float = 7.0,
    height_in: float = 0.5,
    dpi: int = 300,
    rows: int = 1,
    font_size: int | None = None,
    font: str | Path | None = None,
    padding_in: float = 0.02,
    dividers: bool = False,
) -> Image.Image:
    """Render a patch-panel strip with one small cell per port.

    `ports` is either a sequence expression like ``"1..24"`` (passed
    through `pybrady.templates.sequence.expand`) or an explicit list
    of strings. When `rows > 1`, cells are laid out left-to-right,
    top-to-bottom, so a 48-port two-row panel is ``[P1..P24]`` on the
    top row and ``[P25..P48]`` on the bottom.

    `font_size=None` auto-fits the largest size where every port name
    fits in one cell; pass an integer to pin it.

    `dividers=True` draws thin black lines between cells. Useful when
    the printed label is stuck to a panel that itself doesn't have
    visible port divisions.

    The total port count must divide evenly by `rows`. If it doesn't,
    pad the input list with empty strings to signal the intentional
    gap rather than silently dropping or repeating cells.
    """
    ports = expand(ports) if isinstance(ports, str) else list(ports)

    if not ports:
        raise ValueError("ports must be non-empty")
    if width_in <= 0 or height_in <= 0:
        raise ValueError(f"width_in and height_in must be positive ({width_in}, {height_in})")
    if rows < 1:
        raise ValueError(f"rows must be >= 1 (got {rows})")
    if len(ports) % rows != 0:
        raise ValueError(
            f"ports count ({len(ports)}) must be divisible by rows ({rows}); "
            "pad with empty strings if the gap is intentional"
        )
    if padding_in < 0:
        raise ValueError(f"padding_in must be non-negative ({padding_in})")

    cols = len(ports) // rows
    width_px = max(cols, round(width_in * dpi))
    height_px = max(rows, round(height_in * dpi))
    padding_px = max(0, round(padding_in * dpi))

    # Integer-divide the canvas; the final row/column absorbs any remainder
    # so the grid covers the full canvas with no gaps.
    base_cell_w = width_px // cols
    base_cell_h = height_px // rows

    # Auto-size the font against the *base* cell dimensions (worst case —
    # the bonus pixels given to the last row/column only add slack).
    resolved_font_size = (
        font_size
        if font_size is not None
        else _auto_font_size(ports, base_cell_w, base_cell_h, padding_px, font)
    )

    canvas = Image.new("1", (width_px, height_px), 1)

    for index, port in enumerate(ports):
        row = index // cols
        col = index % cols
        x = col * base_cell_w
        y = row * base_cell_h
        cell_w = width_px - x if col == cols - 1 else base_cell_w
        cell_h = height_px - y if row == rows - 1 else base_cell_h
        if not port:
            continue
        cell_img = text_label(
            port,
            width_px=cell_w,
            height_px=cell_h,
            size=resolved_font_size,
            font=font,
        )
        canvas.paste(cell_img, (x, y))

    if dividers:
        draw = ImageDraw.Draw(canvas)
        for c in range(1, cols):
            x = c * base_cell_w
            draw.line([(x, 0), (x, height_px - 1)], fill=0)
        for r in range(1, rows):
            y = r * base_cell_h
            draw.line([(0, y), (width_px - 1, y)], fill=0)

    return canvas
