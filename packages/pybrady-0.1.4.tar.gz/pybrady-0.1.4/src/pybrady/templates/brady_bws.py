# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Reader for Brady UDF v2 Binary label files (`.BWS` and `.BWT`).

Brady Workstation stores labels in a proprietary binary container produced
by the `UdfSerializer` class in `PrintEngine.UDF.dll`. Two extensions use
the same wire format:

* `.BWS` — a label the user saved (an "instance" of a template with concrete
  values filled in).
* `.BWT` — a Brady-shipped template (the starting point for a new label).

The file layout is:

    <string "brcudf2bin">             # magic (.NET BinaryWriter string)
    <int32 N>                          # number of header entries, little-endian
    N x (<string key>, <string value>) # metadata dictionary
    FileIndex                          # length-prefixed Store with offsets
    DesignStore                        # design metadata + thumbnail PNG
    RegionStore, LabelStore, ...       # actual label content
    AppDataStore                       # template-variable metadata (schema >= 38)

Every Store begins with a `uint32 LE` total-length prefix (the Store's
own length, including the prefix itself). FileIndex is itself a Store
whose payload is 10 or 11 `uint32 LE` offsets — one per possible Store
type, with the first value being the FileIndex length marker.

Five offset fields (DesignStore, RegionStore, LabelStore,
PagePropertiesStore, ObjectStore, AppDataStore) get rebased by a delta
when read, computed as `actual_design_offset - recorded_design_offset`.
This lets Brady safely edit a file's header size (e.g. adding metadata
fields) without having to rewrite every subsequent offset.

Strings in the header follow the .NET `BinaryWriter.Write(string)`
convention: a 7-bit LEB128-encoded byte length prefix followed by UTF-8
bytes. Numeric values are little-endian.

This module currently covers the header dictionary, FileIndex, Store
boundary discovery, and thumbnail extraction. Full design parsing
(text positions, fonts, QR codes, etc.) is a follow-on.
"""

from __future__ import annotations

import struct
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, BinaryIO

_MAGIC = "brcudf2bin"

# A FileIndex Store is always exactly 11 uint32 entries (44 bytes) in modern
# schemas: a length marker followed by 10 Store offsets.
_FILE_INDEX_LENGTH = 44
_FILE_INDEX_ENTRY_COUNT = 11

# PNG signature, used only as a sanity check on the bytes we pull out of
# DesignStore's length-prefixed thumbnail field.
_PNG_SIGNATURE = b"\x89PNG\r\n\x1a\n"

# DesignStore payload layout (after the 4-byte StoreBase length prefix):
#   [i32 LE] UdfSchemaVersion       at payload offset 0
#   [i64 LE] thumbnail byte length  at payload offset 4
#   [N bytes] thumbnail PNG         at payload offset 12
# Further fields (data schemes, images) follow for schema >=37 / >=50 and are
# not yet decoded here.
_DESIGN_SCHEMA_OFFSET = 4  # in Store.data, accounting for the length prefix
_DESIGN_THUMB_LEN_OFFSET = 8
_DESIGN_THUMB_BYTES_OFFSET = 16

# Brady's own minimum schema version for including a thumbnail in DesignStore.
# (See `Design.Deserialize`; schema <= 12 has no thumbnail field at all.)
_MIN_SCHEMA_WITH_THUMBNAIL = 13


class InvalidBwsFileError(ValueError):
    """Raised when a file is not a Brady UDF v2 binary."""


@dataclass(frozen=True)
class BwsHeader:
    """Metadata dictionary from the top of a `.bws` file.

    Keys are whatever Brady Workstation chose to write; they're exposed
    as a raw dict plus convenience accessors for the fields we currently
    care about.
    """

    fields: dict[str, str]

    def get(self, key: str, default: str = "") -> str:
        return self.fields.get(key, default)

    @property
    def name(self) -> str:
        return self.fields.get("Name", "")

    @property
    def app(self) -> str:
        """Brady Workstation addin that created the label (e.g. `AssetApp`, `FlipFlop`)."""
        return self.fields.get("AppName", "")

    @property
    def category(self) -> str:
        return self.fields.get("Category", "")

    @property
    def file_format(self) -> str:
        """Brady container version tag (e.g. `MW4`)."""
        return self.fields.get("FileFormat", "")

    @property
    def printer_name(self) -> str:
        return self.fields.get("PrinterName", "")

    @property
    def printer_driver(self) -> str:
        return self.fields.get("PrinterDriverName", "")


def _read_7bit_int(f: BinaryIO) -> int:
    """Read a .NET-style 7-bit LEB128 integer (used as string length prefix)."""
    value = 0
    shift = 0
    while True:
        chunk = f.read(1)
        if not chunk:
            raise EOFError("Truncated 7-bit integer")
        b = chunk[0]
        value |= (b & 0x7F) << shift
        if b < 0x80:
            return value
        shift += 7
        if shift > 35:
            raise InvalidBwsFileError("7-bit integer exceeds 5 bytes (likely corrupt)")


def _read_binary_string(f: BinaryIO) -> str:
    """Read a .NET `BinaryWriter.Write(string)`: 7-bit length prefix + UTF-8 bytes."""
    length = _read_7bit_int(f)
    data = f.read(length)
    if len(data) != length:
        raise EOFError(f"Expected {length} string bytes, got {len(data)}")
    return data.decode("utf-8")


def _read_int32_le(f: BinaryIO) -> int:
    data = f.read(4)
    if len(data) != 4:
        raise EOFError("Truncated Int32")
    return int(struct.unpack("<i", data)[0])


def read_header(path: Path | str) -> BwsHeader:
    """Parse the metadata header of a `.bws` file."""
    with Path(path).open("rb") as f:
        return read_header_from_stream(f)


def read_header_from_stream(f: BinaryIO) -> BwsHeader:
    """Parse the metadata header from an open binary stream.

    The stream is left positioned just after the header, ready for
    `FileIndex` parsing by a future caller.
    """
    magic = _read_binary_string(f)
    if magic != _MAGIC:
        raise InvalidBwsFileError(
            f"not a Brady UDF v2 binary file: magic={magic!r}, expected {_MAGIC!r}"
        )
    count = _read_int32_le(f)
    if count < 0:
        raise InvalidBwsFileError(f"negative header entry count ({count})")
    fields: dict[str, str] = {}
    for _ in range(count):
        key = _read_binary_string(f)
        value = _read_binary_string(f)
        fields[key] = value
    return BwsHeader(fields=fields)


@dataclass(frozen=True)
class BwsFileIndex:
    """Absolute file offsets of each Store in a `.bws`/`.bwt` file.

    Every `*_store` value is either:

    * `0` — the Store is not present (common for the four obsolete Store
      types and for AppDataStore in pre-schema-38 files), or
    * a positive byte offset into the file pointing at the Store's
      length-prefix header.

    The five modern stores (DesignStore, RegionStore, LabelStore,
    PagePropertiesStore, ObjectStore, AppDataStore) are delta-adjusted to
    their real file positions; the four obsolete stores are stored as
    recorded with no adjustment.
    """

    design_store: int
    region_store: int
    label_store: int
    group_store: int
    wiremark_store: int
    page_properties_store: int
    label_info_for_110_block_store: int
    object_store: int
    data_store: int
    app_data_store: int


# Entity-type GUIDs observed in real BWS/BWT ObjectStores. Each maps to an
# `EntityBase` subclass in `PrintEngine.UDF.dll`; Brady's code resolves these
# dynamically via `EntityFactory.GetLabelObject(toolTypeId)`, so the values
# here come from empirical cross-referencing of payload content against the
# decompiled class layouts rather than from a static registry in the DLL.
RICH_TEXT_ENTITY_TYPE_ID = "cfbe4eb0-037b-11de-8c30-0800200c9a66"
BARCODE_ENTITY_TYPE_ID = "9ca4bbbe-7cf5-441b-984d-bf378f122262"


@dataclass(frozen=True)
class BwsStore:
    """A single Store blob read out of a `.bws`/`.bwt` file.

    `data` is the full Store including the four-byte length prefix, so
    `len(data) == length`. Parsers for specific Store types consume the
    payload starting at byte 4.
    """

    name: str
    file_offset: int
    length: int
    data: bytes


def read_file_index(path: Path | str) -> BwsFileIndex:
    """Parse the header and FileIndex of a `.bws`/`.bwt` file.

    Returns absolute, delta-adjusted file offsets for every Store.
    """
    with Path(path).open("rb") as f:
        read_header_from_stream(f)
        return _read_file_index_from_stream(f)


def _read_file_index_from_stream(f: BinaryIO) -> BwsFileIndex:
    fi_start = f.tell()
    # FileIndex is itself a Store: first uint32 is its total length.
    length = _read_int32_le(f)
    if length != _FILE_INDEX_LENGTH:
        raise InvalidBwsFileError(
            f"unexpected FileIndex length {length} (expected {_FILE_INDEX_LENGTH})"
        )
    # The remaining 10 entries are the per-Store raw offsets. The writer
    # always uses `num = 44` as the first written value and stores it
    # again in the DesignStore slot, so `raw_design == 44` for modern files.
    raw = [_read_int32_le(f) for _ in range(_FILE_INDEX_ENTRY_COUNT - 1)]
    (
        raw_design,
        raw_region,
        raw_label,
        raw_group,
        raw_wiremark,
        raw_page_props,
        raw_label_info_110,
        raw_object,
        raw_data,
        raw_app_data,
    ) = raw

    # DesignStore *always* sits immediately after FileIndex. If the recorded
    # offset differs, the other delta-adjusted stores were saved relative to
    # a different header size and need to be shifted by the same delta.
    expected_design = fi_start + _FILE_INDEX_LENGTH
    delta = expected_design - raw_design

    def adjusted(raw_value: int) -> int:
        return raw_value + delta if raw_value > 0 else raw_value

    return BwsFileIndex(
        design_store=expected_design,
        region_store=adjusted(raw_region),
        label_store=adjusted(raw_label),
        group_store=raw_group,
        wiremark_store=raw_wiremark,
        page_properties_store=adjusted(raw_page_props),
        label_info_for_110_block_store=raw_label_info_110,
        object_store=adjusted(raw_object),
        data_store=raw_data,
        app_data_store=adjusted(raw_app_data),
    )


def read_store(path: Path | str, offset: int, name: str = "") -> BwsStore:
    """Read a single Store blob at `offset` in a `.bws`/`.bwt` file.

    Offsets typically come from a `BwsFileIndex`. `name` is optional
    metadata used purely for debugging/error messages.
    """
    with Path(path).open("rb") as f:
        f.seek(offset)
        length_bytes = f.read(4)
        if len(length_bytes) != 4:
            raise EOFError(f"Store at offset {offset} ({name!r}): truncated length prefix")
        length = int(struct.unpack("<I", length_bytes)[0])
        # Brady's StoreBase pads sub-four-byte stores up to a minimum of four
        # bytes (just the length prefix). An empty store writes `length == 0`
        # and the store occupies exactly those four header bytes; preserve
        # that contract rather than raising.
        effective_length = max(length, 4)
        f.seek(offset)
        data = f.read(effective_length)
        if len(data) != effective_length:
            raise EOFError(
                f"Store at offset {offset} ({name!r}): "
                f"wanted {effective_length} bytes, got {len(data)}"
            )
    return BwsStore(name=name, file_offset=offset, length=length, data=data)


def read_design_store(path: Path | str) -> BwsStore:
    """Convenience: read just the raw DesignStore blob."""
    index = read_file_index(path)
    return read_store(path, index.design_store, name="DesignStore")


def read_object_store(path: Path | str) -> BwsStore:
    """Convenience: read just the raw ObjectStore blob."""
    index = read_file_index(path)
    return read_store(path, index.object_store, name="ObjectStore")


@dataclass(frozen=True)
class BwsEntity:
    """One entity record extracted from the ObjectStore framing.

    `tool_type_id` is the entity's type GUID (see `RICH_TEXT_ENTITY_TYPE_ID`,
    `BARCODE_ENTITY_TYPE_ID`). `payload` is the opaque length-prefixed byte
    blob written by the entity's own `Serialize` method; decoders for each
    entity type parse it further.
    """

    region_id: bytes  # 16-byte GUID the entity belongs to
    region_index: int
    label_number: int
    is_label_entity: bool  # False = child entity reused by reference
    tool_type_id: str  # canonical "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx" form
    entity_id: str  # same format as tool_type_id
    payload: bytes


def _format_guid(raw: bytes) -> str:
    """Render a .NET-serialized GUID as the canonical dashed hex string.

    .NET stores a GUID on-wire as `Data1(u32 LE) Data2(u16 LE) Data3(u16 LE)
    Data4(8 bytes)`. The textual form reverses the endianness of the first
    three fields.
    """
    if len(raw) != 16:
        raise InvalidBwsFileError(f"GUID must be 16 bytes, got {len(raw)}")
    return (
        f"{raw[3]:02x}{raw[2]:02x}{raw[1]:02x}{raw[0]:02x}-"
        f"{raw[5]:02x}{raw[4]:02x}-"
        f"{raw[7]:02x}{raw[6]:02x}-"
        f"{raw[8]:02x}{raw[9]:02x}-"
        f"{raw[10]:02x}{raw[11]:02x}{raw[12]:02x}{raw[13]:02x}{raw[14]:02x}{raw[15]:02x}"
    )


def _read_length_prefixed_guid(data: bytes, offset: int) -> tuple[bytes, int]:
    """Read a `UdfBinaryReader.ReadGuid()`-format GUID: 1 length byte + bytes."""
    if offset >= len(data):
        raise InvalidBwsFileError(f"truncated GUID at offset {offset}")
    length = data[offset]
    end = offset + 1 + length
    if end > len(data):
        raise InvalidBwsFileError(
            f"GUID at offset {offset} claims {length} bytes but only "
            f"{len(data) - offset - 1} available"
        )
    return data[offset + 1 : end], end


# ---------------------------------------------------------------------------
# Entity-payload parsing
# ---------------------------------------------------------------------------
#
# Beyond the framing layer, each entity's `payload` is a densely-packed
# sequence of .NET `BinaryReader`-style reads. The class hierarchy Brady's
# code uses is `EntityBase` <- `EntityWithDynamicProperties` <-
# `RichTextEntity` / `BarcodeEntity`, and every `Deserialize` calls into its
# base before reading its own fields. The helpers below mirror that layering.


class _UdfReader:
    """Streaming reader over an entity payload.

    Mirrors the relevant methods of .NET's `UdfBinaryReader` so decode code
    can follow the decompiled source almost line-for-line. Raises
    `InvalidBwsFileError` on any truncation; we never silently stop.
    """

    __slots__ = ("_data", "_pos")

    def __init__(self, data: bytes, start: int = 0):
        self._data = data
        self._pos = start

    @property
    def pos(self) -> int:
        return self._pos

    @property
    def remaining(self) -> int:
        return len(self._data) - self._pos

    def _take(self, n: int, what: str) -> bytes:
        if self._pos + n > len(self._data):
            raise InvalidBwsFileError(
                f"truncated {what} at offset {self._pos}: need {n} bytes, have {self.remaining}"
            )
        chunk = self._data[self._pos : self._pos + n]
        self._pos += n
        return chunk

    def read_byte(self) -> int:
        return self._take(1, "byte")[0]

    def read_boolean(self) -> bool:
        return self.read_byte() != 0

    def read_int32(self) -> int:
        return int(struct.unpack("<i", self._take(4, "Int32"))[0])

    def read_int64(self) -> int:
        return int(struct.unpack("<q", self._take(8, "Int64"))[0])

    def read_uint32(self) -> int:
        return int(struct.unpack("<I", self._take(4, "UInt32"))[0])

    def read_bytes(self, n: int, what: str = "bytes") -> bytes:
        return self._take(n, what)

    def read_double(self) -> float:
        return float(struct.unpack("<d", self._take(8, "Double"))[0])

    def read_7bit_int(self) -> int:
        value = 0
        shift = 0
        while True:
            b = self.read_byte()
            value |= (b & 0x7F) << shift
            if b < 0x80:
                return value
            shift += 7
            if shift > 35:
                raise InvalidBwsFileError("7-bit integer exceeds 5 bytes (likely corrupt)")

    def read_string(self) -> str:
        length = self.read_7bit_int()
        return self._take(length, "string").decode("utf-8")

    def read_guid(self) -> str:
        length = self.read_byte()
        raw = self._take(length, "Guid")
        return _format_guid(raw)

    def read_color(self) -> tuple[int, int, int, int]:
        """Return `(A, R, G, B)` — Brady's on-wire order."""
        chunk = self._take(4, "Color")
        return (chunk[0], chunk[1], chunk[2], chunk[3])

    def read_point(self) -> tuple[float, float]:
        return (self.read_double(), self.read_double())

    def read_rect(self) -> tuple[float, float, float, float] | None:
        """Matches `UdfBinaryReader.ReadRect`: bool empty-flag + 4 doubles."""
        is_empty = self.read_boolean()
        if is_empty:
            return None
        return (self.read_double(), self.read_double(), self.read_double(), self.read_double())


@dataclass(frozen=True)
class BwsFont:
    """A single UdfFont record: family + size + style flags."""

    family: str
    size: float
    bold: bool
    italic: bool
    strike_out: bool
    underline: bool
    all_caps: bool
    baseline_alignment: int
    color: tuple[int, int, int, int] | None  # (A, R, G, B), None for schema < 22


@dataclass(frozen=True)
class BwsEntityCommon:
    """Fields shared by every entity type (decoded from `EntityBase`).

    These tell us where the entity sits on the label and what its surrounding
    metadata is; the entity-type-specific fields come next in the payload.
    """

    id: str
    type_id: str
    shape_type_id: str
    name: str
    back_color: tuple[int, int, int, int]
    border_color: tuple[int, int, int, int]
    fore_color: tuple[int, int, int, int]
    border_width: float
    can_move: bool
    can_resize: bool
    can_print: bool
    can_select: bool
    draw_border: bool
    is_locked: bool
    is_template: bool
    is_in_group: bool
    can_show_on_screen: bool
    height: float
    width: float
    position: tuple[float, float]
    rotation: float
    z_order: float
    template_object_id: str
    can_cut: bool
    resize_pattern: int
    rotation_anchor_point: int | None
    # Dynamic-property dicts from `EntityWithDynamicProperties`. Keyed by
    # property name; the most interesting ones for us are the strings
    # (`TEMPLATE_PROMPT`, `HAS_PICKLIST`, `Placeholder`).
    int_properties: dict[str, int] = field(default_factory=dict)
    string_properties: dict[str, str] = field(default_factory=dict)
    double_properties: dict[str, float] = field(default_factory=dict)
    bool_properties: dict[str, bool] = field(default_factory=dict)
    color_properties: dict[str, tuple[int, int, int, int]] = field(default_factory=dict)
    point_properties: dict[str, tuple[float, float]] = field(default_factory=dict)


@dataclass(frozen=True)
class BwsTextRun:
    """One formatted run within a paragraph — text plus its own font."""

    text: str
    font: BwsFont


@dataclass(frozen=True)
class BwsTextParagraph:
    """One paragraph of runs, with paragraph-level alignment and spacing."""

    runs: tuple[BwsTextRun, ...]
    text_alignment: int
    line_spacing: float
    paragraph_font: BwsFont  # default font for runs that inherit


@dataclass(frozen=True)
class BwsTextEntity:
    """A RichTextEntity decoded far enough to render.

    `paragraphs` preserves the full paragraph/run tree for callers who
    need per-run formatting (mixed bold/italic on one line, per-run
    colour, etc.). `text`, `font`, and `text_alignment` are flattened
    convenience views for the common case of uniform formatting; `text`
    concatenates every run with `\\n` between paragraphs, and `font` is
    the first run's font (Brady Workstation's template editor writes
    uniform runs in practice, so this matches reality for most files).
    """

    common: BwsEntityCommon
    text: str
    font: BwsFont
    text_alignment: int
    paragraphs: tuple[BwsTextParagraph, ...]
    # When a template prompt is set, the field is meant to be filled in by
    # the user (e.g. `Text 1`, `Text 2`). None means this is literal text.
    template_prompt: str | None
    placeholder: str | None


def _parse_udf_font(reader: _UdfReader, schema_version: int) -> BwsFont:
    family = reader.read_string()
    size = reader.read_double()
    bold = reader.read_boolean()
    italic = reader.read_boolean()
    strike_out = reader.read_boolean()
    underline = reader.read_boolean()
    all_caps = reader.read_boolean()
    baseline_alignment = reader.read_int32()
    color = reader.read_color() if schema_version >= 22 else None
    return BwsFont(
        family=family,
        size=size,
        bold=bold,
        italic=italic,
        strike_out=strike_out,
        underline=underline,
        all_caps=all_caps,
        baseline_alignment=baseline_alignment,
        color=color,
    )


def _parse_entity_base(reader: _UdfReader, schema_version: int) -> dict[str, Any]:
    """Parse the EntityBase prefix. Returns a plain dict; the caller wraps."""
    result: dict[str, Any] = {}
    result["id"] = reader.read_guid()
    result["type_id"] = reader.read_guid()
    result["shape_type_id"] = reader.read_guid()
    result["name"] = reader.read_string()
    result["back_color"] = reader.read_color()
    result["border_color"] = reader.read_color()
    result["fore_color"] = reader.read_color()
    result["border_width"] = reader.read_double()
    result["can_move"] = reader.read_boolean()
    result["can_resize"] = reader.read_boolean() if schema_version >= 47 else True
    result["can_print"] = reader.read_boolean()
    result["can_select"] = reader.read_boolean()
    result["draw_border"] = reader.read_boolean()
    result["is_locked"] = reader.read_boolean()
    result["is_template"] = reader.read_boolean()
    result["is_in_group"] = reader.read_boolean() if schema_version >= 49 else False
    result["can_show_on_screen"] = reader.read_boolean()
    result["height"] = reader.read_double()
    result["width"] = reader.read_double()
    result["position"] = reader.read_point()
    result["rotation"] = reader.read_double()
    result["z_order"] = reader.read_double()
    result["template_object_id"] = reader.read_guid()
    result["can_cut"] = reader.read_boolean()
    result["resize_pattern"] = reader.read_int32()
    if schema_version < 37:
        reader.read_guid()  # legacy_databound_column_id, unused
    if schema_version >= 20:
        has_anchor = reader.read_boolean()
        anchor_value = reader.read_int32()
        result["rotation_anchor_point"] = anchor_value if has_anchor else None
    else:
        result["rotation_anchor_point"] = None
    return result


def _parse_dynamic_properties(reader: _UdfReader) -> dict[str, dict[str, Any]]:
    def _read_dict(read_value: Any) -> dict[str, Any]:
        count = reader.read_byte()
        return {reader.read_string(): read_value() for _ in range(count)}

    return {
        "int": _read_dict(reader.read_int32),
        "string": _read_dict(reader.read_string),
        "double": _read_dict(reader.read_double),
        "bool": _read_dict(reader.read_boolean),
        "color": _read_dict(reader.read_color),
        "point": _read_dict(reader.read_point),
    }


def _parse_entity_common(reader: _UdfReader, schema_version: int) -> BwsEntityCommon:
    base = _parse_entity_base(reader, schema_version)
    props = _parse_dynamic_properties(reader)
    return BwsEntityCommon(
        int_properties=props["int"],
        string_properties=props["string"],
        double_properties=props["double"],
        bool_properties=props["bool"],
        color_properties=props["color"],
        point_properties=props["point"],
        **base,
    )


def _parse_rich_text_document(
    reader: _UdfReader, schema_version: int
) -> tuple[str, BwsFont, int, tuple[BwsTextParagraph, ...]]:
    """Parse a RichTextDocument.

    Returns `(flat_text, first_run_font, text_alignment, paragraphs)`.

    `paragraphs` preserves the full per-run formatting tree. `flat_text`
    is the paragraphs' text concatenated with `\\n` between them, and
    `first_run_font` is convenience for callers who don't need per-run
    detail — in practice Brady Workstation writes uniform runs, so
    picking the first one matches what the user sees on a real label.
    """
    reader.read_double()  # AutoSizeDelta
    text_alignment = reader.read_int32()
    document_font = _parse_udf_font(reader, schema_version)

    num_paragraphs = reader.read_int32()
    text_parts: list[str] = []
    first_run_font: BwsFont | None = None
    paragraphs: list[BwsTextParagraph] = []
    for pi in range(num_paragraphs):
        if pi > 0:
            text_parts.append("\n")
        paragraph_alignment = reader.read_int32()
        line_spacing = reader.read_double()
        paragraph_font = _parse_udf_font(reader, schema_version)
        num_runs = reader.read_int32()
        runs: list[BwsTextRun] = []
        for _ in range(num_runs):
            run_font = _parse_udf_font(reader, schema_version)
            run_text = reader.read_string()
            if first_run_font is None:
                first_run_font = run_font
            text_parts.append(run_text)
            runs.append(BwsTextRun(text=run_text, font=run_font))
        if schema_version >= 61:
            num_line_metrics = reader.read_int32()
            for _ in range(num_line_metrics):
                # RichTextLineMetrics = 3 doubles (Width, Height, BaseLine)
                # + 2 Int32s (Length, Position) + 1 bool (HasCollapsed).
                for _ in range(3):
                    reader.read_double()
                reader.read_int32()
                reader.read_int32()
                reader.read_boolean()
        paragraphs.append(
            BwsTextParagraph(
                runs=tuple(runs),
                text_alignment=paragraph_alignment,
                line_spacing=line_spacing,
                paragraph_font=paragraph_font,
            )
        )

    font = first_run_font if first_run_font is not None else document_font
    return "".join(text_parts), font, text_alignment, tuple(paragraphs)


def decode_rich_text_entity(payload: bytes, schema_version: int) -> BwsTextEntity:
    """Decode a RichTextEntity payload (bytes from `BwsEntity.payload`).

    `schema_version` comes from `read_design(path).schema_version` — the
    same version governs every entity in the file.
    """
    reader = _UdfReader(payload)
    common = _parse_entity_common(reader, schema_version)
    text, font, text_alignment, paragraphs = _parse_rich_text_document(reader, schema_version)
    template_prompt = common.string_properties.get("TEMPLATE_PROMPT")
    placeholder = common.string_properties.get("Placeholder")
    return BwsTextEntity(
        common=common,
        text=text,
        font=font,
        text_alignment=text_alignment,
        paragraphs=paragraphs,
        template_prompt=template_prompt,
        placeholder=placeholder,
    )


def read_text_entities(path: Path | str) -> list[BwsTextEntity]:
    """Parse every RichTextEntity out of a `.bws`/`.bwt` file."""
    schema_version = read_design(path).schema_version
    results: list[BwsTextEntity] = []
    for entity in read_entities(path):
        if entity.tool_type_id != RICH_TEXT_ENTITY_TYPE_ID:
            continue
        results.append(decode_rich_text_entity(entity.payload, schema_version))
    return results


# BarcodeType values (from `PrintEngine.UDF.BarcodeType`). Kept as plain
# string constants rather than an enum so consumers can match on the name
# without pybrady having to grow a domain enum.
_BARCODE_TYPE_NAMES = {
    0: "None",
    1: "MSI",
    2: "ITF14",
    3: "Ext2",
    4: "Ext5",
    5: "EAN8",
    6: "EAN8Ext2",
    7: "EAN8Ext5",
    8: "EAN13",
    9: "EAN13Ext2",
    10: "EAN13Ext5",
    11: "UPCA",
    12: "UPCAExt2",
    13: "UPCAExt5",
    14: "UPCE",
    15: "UPCEExt2",
    16: "UPCEExt5",
    17: "Interleaved2of5",
    18: "Code128",
    19: "Code128A",
    20: "Code128B",
    21: "Code128C",
    22: "GS1128",
    23: "Code39",
    24: "Code39FullASCII",
    25: "Code93",
    26: "Code93FullASCII",
    27: "Postnet",
    28: "IntelligentMail",
    29: "DataMatrix",
    30: "PDF417",
    31: "CodablockF",
    32: "HIBC",
    33: "QR",
    34: "JAN13",
    1000: "UPCE1",
    1001: "UPCE1Ext2",
    1002: "UPCE1Ext5",
}


def barcode_type_name(value: int) -> str:
    """Return the `BarcodeType` enum name for a raw integer, or `Unknown(n)`."""
    return _BARCODE_TYPE_NAMES.get(value, f"Unknown({value})")


@dataclass(frozen=True)
class BwsBarcodeEntity:
    """A BarcodeEntity decoded far enough to render.

    `value` is the barcode's encoded data; `template` is an optional
    formatting pattern (Brady uses it for databound labels). `rows`,
    `columns`, `ratio`, `xy_ratio`, `density` drive the on-printer
    rendering geometry; `check_digit_algorithm` / `dmx_error_correction`
    / `dmx_shape` are symbology-specific knobs the pybrady renderer can
    pass through to `python-barcode` / `segno` later.
    """

    common: BwsEntityCommon
    font: BwsFont
    value: str
    barcode_type: int
    barcode_type_name: str
    density: float
    ratio: float
    xy_ratio: float
    check_digit_algorithm: int
    human_readable_location: int
    dmx_error_correction: int
    dmx_shape: int
    rows: int
    columns: int
    pdf_security: int
    truncated: bool
    template: str
    # Empty values for pre-schema-37 files.
    data_scheme_id: str = ""
    data_column: int = 0
    data_row: int = 0
    column_format_index: int = 0
    is_unique: bool = False
    human_readable_entity_ids: tuple[str, ...] = ()


def decode_barcode_entity(payload: bytes, schema_version: int) -> BwsBarcodeEntity:
    """Decode a BarcodeEntity payload (bytes from `BwsEntity.payload`)."""
    reader = _UdfReader(payload)
    common = _parse_entity_common(reader, schema_version)
    font = _parse_udf_font(reader, schema_version)
    value = reader.read_string()
    barcode_type = reader.read_int32()
    density = reader.read_double()
    ratio = reader.read_double()
    xy_ratio = reader.read_double()
    check_digit_algorithm = reader.read_int32()
    human_readable_location = reader.read_int32()
    dmx_error_correction = reader.read_int32()
    dmx_shape = reader.read_int32()
    rows = reader.read_int32()
    columns = reader.read_int32()
    pdf_security = reader.read_int32()
    truncated = reader.read_boolean()
    template = reader.read_string()

    data_scheme_id = ""
    data_column = 0
    data_row = 0
    if schema_version >= 37:
        data_scheme_id = reader.read_guid()
        data_column = reader.read_int32()
        data_row = reader.read_int32()
    column_format_index = 0
    if schema_version >= 42:
        column_format_index = reader.read_int32()
    is_unique = False
    if schema_version >= 53:
        is_unique = reader.read_boolean()
    hr_ids: tuple[str, ...] = ()
    if schema_version >= 60:
        count = reader.read_int32()
        hr_ids = tuple(reader.read_guid() for _ in range(count))

    return BwsBarcodeEntity(
        common=common,
        font=font,
        value=value,
        barcode_type=barcode_type,
        barcode_type_name=barcode_type_name(barcode_type),
        density=density,
        ratio=ratio,
        xy_ratio=xy_ratio,
        check_digit_algorithm=check_digit_algorithm,
        human_readable_location=human_readable_location,
        dmx_error_correction=dmx_error_correction,
        dmx_shape=dmx_shape,
        rows=rows,
        columns=columns,
        pdf_security=pdf_security,
        truncated=truncated,
        template=template,
        data_scheme_id=data_scheme_id,
        data_column=data_column,
        data_row=data_row,
        column_format_index=column_format_index,
        is_unique=is_unique,
        human_readable_entity_ids=hr_ids,
    )


def read_barcode_entities(path: Path | str) -> list[BwsBarcodeEntity]:
    """Parse every BarcodeEntity out of a `.bws`/`.bwt` file."""
    schema_version = read_design(path).schema_version
    results: list[BwsBarcodeEntity] = []
    for entity in read_entities(path):
        if entity.tool_type_id != BARCODE_ENTITY_TYPE_ID:
            continue
        results.append(decode_barcode_entity(entity.payload, schema_version))
    return results


# ---------------------------------------------------------------------------
# AppDataStore (schema >= 38)
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class BwsAppDataEntry:
    """One ApplicationData record from the AppDataStore.

    Brady's addins register their own `ApplicationDataFactory` classes
    and write an opaque binary blob under a well-known GUID key; the
    meaning of `payload` depends entirely on `type_information`. pybrady
    surfaces the framing so callers can dispatch on `data_id` /
    `type_information` to decode the payloads they care about.
    """

    data_id: str  # GUID identifying the addin's data type
    type_information: str  # free-form tag the addin chose (often a class name)
    payload: bytes


def read_app_data_store(path: Path | str) -> BwsStore:
    """Convenience: read just the raw AppDataStore blob."""
    index = read_file_index(path)
    return read_store(path, index.app_data_store, name="AppDataStore")


def read_app_data(path: Path | str) -> list[BwsAppDataEntry]:
    """Parse the AppDataStore into a flat list of `BwsAppDataEntry` records.

    Returns an empty list if the store is absent (e.g. the file's schema
    predates 38) or written without any entries (the common case).
    """
    index = read_file_index(path)
    if index.app_data_store == 0:
        return []
    store = read_app_data_store(path)
    if len(store.data) < 4:
        return []
    store_length = int(struct.unpack("<I", store.data[:4])[0])
    if store_length <= 4:
        # Writer pads empty stores to four zero bytes.
        return []

    reader = _UdfReader(store.data, start=4)
    entries: list[BwsAppDataEntry] = []
    while reader.pos < store_length:
        # The outer framing writes the entry's Guid once as a dispatch
        # key, and `ApplicationData.Serialize` writes the exact same Guid
        # again as the first field of its own payload. We read both and
        # flag a mismatch so a corrupt file raises instead of returning
        # nonsense.
        outer_id = reader.read_guid()
        inner_id = reader.read_guid()
        if outer_id != inner_id:
            raise InvalidBwsFileError(
                f"AppDataStore entry at payload offset {reader.pos}: "
                f"outer id {outer_id} != inner id {inner_id}"
            )
        type_information = reader.read_string()
        # ApplicationData.Deserialize reads an Int64 declared-size; if >0,
        # it then reads a ReadMemoryStream (another Int64 length + bytes).
        declared = reader.read_int64()
        if declared > 0:
            mem_length = reader.read_int64()
            if mem_length < 0:
                raise InvalidBwsFileError(
                    f"AppDataStore entry '{outer_id}' has negative payload length ({mem_length})"
                )
            payload = reader.read_bytes(mem_length, f"AppData payload ('{outer_id}')")
        else:
            payload = b""
        entries.append(
            BwsAppDataEntry(data_id=outer_id, type_information=type_information, payload=payload)
        )
    return entries


def read_entities(path: Path | str) -> list[BwsEntity]:
    """Parse the ObjectStore framing into a flat list of entity records.

    The payloads are returned opaque — decoders for specific entity types
    (text, barcodes, etc.) parse them further. Entity-type dispatch goes
    through `tool_type_id`; see the `*_ENTITY_TYPE_ID` constants.
    """
    store = read_object_store(path)
    data = store.data
    if len(data) < 8:
        raise InvalidBwsFileError(f"ObjectStore too small to frame ({len(data)} bytes)")

    store_length = int(struct.unpack("<I", data[:4])[0])
    if store_length != len(data):
        raise InvalidBwsFileError(
            f"ObjectStore length prefix {store_length} != actual length {len(data)}"
        )
    num_regions = int(struct.unpack("<i", data[4:8])[0])
    if num_regions < 0:
        raise InvalidBwsFileError(f"ObjectStore has negative region count ({num_regions})")

    pos = 8
    regions: list[bytes] = []
    for _ in range(num_regions):
        region_id, pos = _read_length_prefixed_guid(data, pos)
        regions.append(region_id)

    entities: list[BwsEntity] = []
    while pos < store_length:
        if pos + 6 > store_length:  # u8 region_idx + i32 label + u8 bool = 6 bytes minimum
            raise InvalidBwsFileError(
                f"truncated ObjectStore entry at offset {pos} "
                f"(need 6 fixed-header bytes, have {store_length - pos})"
            )
        region_idx = data[pos]
        pos += 1
        label_number = int(struct.unpack("<i", data[pos : pos + 4])[0])
        pos += 4
        is_label_entity = bool(data[pos])
        pos += 1
        if region_idx >= len(regions):
            raise InvalidBwsFileError(
                f"ObjectStore entry at offset {pos - 6} references region "
                f"{region_idx} but only {len(regions)} are defined"
            )

        tool_type_raw, pos = _read_length_prefixed_guid(data, pos)
        entity_id_raw, pos = _read_length_prefixed_guid(data, pos)
        if pos + 4 > store_length:
            raise InvalidBwsFileError(f"truncated payload length at offset {pos} in ObjectStore")
        payload_length = int(struct.unpack("<I", data[pos : pos + 4])[0])
        pos += 4
        end = pos + payload_length
        if end > store_length:
            raise InvalidBwsFileError(
                f"ObjectStore entry at offset {pos - 4} claims {payload_length}-byte "
                f"payload but only {store_length - pos} bytes remain"
            )
        payload = data[pos:end]
        pos = end

        entities.append(
            BwsEntity(
                region_id=regions[region_idx],
                region_index=region_idx,
                label_number=label_number,
                is_label_entity=is_label_entity,
                tool_type_id=_format_guid(tool_type_raw),
                entity_id=_format_guid(entity_id_raw),
                payload=payload,
            )
        )

    return entities


@dataclass(frozen=True)
class BwsDesign:
    """Structured view of a `.bws`/`.bwt` file's DesignStore payload.

    Only the prefix fields are parsed here — schema version and the
    embedded preview thumbnail. The remaining bytes (data schemes,
    images, etc.) are held in `remainder` for future decoders that want
    to continue parsing without re-reading the file.
    """

    schema_version: int
    thumbnail_png: bytes | None
    remainder: bytes


def read_design(path: Path | str) -> BwsDesign:
    """Parse the header-level fields of the DesignStore.

    The schema version is the primary dispatch key for every subsequent
    optional field Brady added over time; the thumbnail is the preview
    PNG rendered by Brady Workstation.
    """
    store = read_design_store(path)
    if len(store.data) < _DESIGN_THUMB_LEN_OFFSET:
        raise InvalidBwsFileError(
            f"DesignStore too small to contain schema version ({len(store.data)} bytes)"
        )

    schema_version = int(
        struct.unpack("<i", store.data[_DESIGN_SCHEMA_OFFSET:_DESIGN_THUMB_LEN_OFFSET])[0]
    )
    thumbnail: bytes | None
    if schema_version < _MIN_SCHEMA_WITH_THUMBNAIL:
        thumbnail = None
        next_offset = _DESIGN_THUMB_LEN_OFFSET
    else:
        if len(store.data) < _DESIGN_THUMB_BYTES_OFFSET:
            raise InvalidBwsFileError(
                f"DesignStore too small to contain thumbnail header "
                f"({len(store.data)} bytes, need {_DESIGN_THUMB_BYTES_OFFSET})"
            )
        thumb_len = int(
            struct.unpack("<q", store.data[_DESIGN_THUMB_LEN_OFFSET:_DESIGN_THUMB_BYTES_OFFSET])[0]
        )
        if thumb_len < 0:
            raise InvalidBwsFileError(f"DesignStore thumbnail has negative length ({thumb_len})")
        end = _DESIGN_THUMB_BYTES_OFFSET + thumb_len
        if end > len(store.data):
            raise InvalidBwsFileError(
                f"DesignStore thumbnail claims {thumb_len} bytes but Store only has "
                f"{len(store.data) - _DESIGN_THUMB_BYTES_OFFSET} past the header"
            )
        if thumb_len == 0:
            thumbnail = None
        else:
            candidate = store.data[_DESIGN_THUMB_BYTES_OFFSET:end]
            if not candidate.startswith(_PNG_SIGNATURE):
                raise InvalidBwsFileError(
                    f"DesignStore thumbnail is not a PNG (first bytes: {candidate[:8].hex()})"
                )
            thumbnail = candidate
        next_offset = end

    return BwsDesign(
        schema_version=schema_version,
        thumbnail_png=thumbnail,
        remainder=store.data[next_offset:],
    )


def read_thumbnail(path: Path | str) -> bytes | None:
    """Return the PNG thumbnail embedded in a `.bws`/`.bwt` file, or `None`.

    Delegates to `read_design` so the thumbnail is pulled from its
    length-prefixed slot in the DesignStore payload rather than via
    signature scanning.
    """
    try:
        return read_design(path).thumbnail_png
    except InvalidBwsFileError:
        return None
