# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Generic data-row plumbing for pybrady's parametric templates.

Every parametric template (`cable_wrap`, `cable_flag`, `asset_tag`,
`generic`, ...) is a plain Python function whose keyword parameters
describe the fields the label cares about. The helpers in this module
let callers feed those functions from data they already have —
`dict`s, CSV rows, Nautobot query results, a pandas DataFrame, a
Slack webhook payload — without pybrady having to grow a client for
each integration.

The contract:

* `from_row(template, row)` calls `template(**row)` after dropping
  keys the template doesn't accept. Unknown columns are ignored, so
  the same CSV can drive several templates.
* `from_row(template, row, mapping={"csv_col": "template_kwarg"})`
  renames columns on the way in so the CSV's vocabulary doesn't have
  to match the template's.
* `from_rows(template, iterable_of_rows)` batches.
* `render_from_csv(path, template)` reads a CSV with a header row
  and delegates to `from_rows`.

CSV values are always strings — if a template parameter is typed
(e.g. `copies: int`), pre-convert in the caller. pybrady doesn't
magic types from function annotations because the edge cases (`bool`
from `"true"/"false"/"1"/"0"`) cause more bugs than they solve.
"""

from __future__ import annotations

import csv
import inspect
from collections.abc import Callable, Iterable
from pathlib import Path
from typing import Any, TypeVar

from PIL import Image

_T = TypeVar("_T")


def _accepted_kwargs(template: Callable[..., Any]) -> set[str] | None:
    """Return the set of parameter names the template accepts, or None if it takes **kwargs."""
    sig = inspect.signature(template)
    names: set[str] = set()
    for param in sig.parameters.values():
        if param.kind is inspect.Parameter.VAR_KEYWORD:
            # Function accepts arbitrary **kwargs — don't filter.
            return None
        if param.kind is inspect.Parameter.VAR_POSITIONAL:
            continue
        names.add(param.name)
    return names


def _translate_row(row: dict[str, Any], mapping: dict[str, str] | None) -> dict[str, Any]:
    if not mapping:
        return dict(row)
    return {mapping.get(key, key): value for key, value in row.items()}


def from_row(
    template: Callable[..., _T],
    row: dict[str, Any],
    *,
    mapping: dict[str, str] | None = None,
) -> _T:
    """Call `template(**row)`, optionally renaming columns, skipping unknown keys.

    Unknown keys are dropped silently so a single CSV can feed several
    templates without preparing per-template projections of the data.
    If a required template parameter is missing from `row`, Python
    raises `TypeError` at call time — that's the right failure mode
    since it surfaces the mismatch at the first label rather than
    silently rendering something wrong.
    """
    translated = _translate_row(row, mapping)
    accepted = _accepted_kwargs(template)
    if accepted is not None:
        translated = {k: v for k, v in translated.items() if k in accepted}
    return template(**translated)


def from_rows(
    template: Callable[..., _T],
    rows: Iterable[dict[str, Any]],
    *,
    mapping: dict[str, str] | None = None,
) -> list[_T]:
    """Batch variant of `from_row`; one rendered result per input row."""
    return [from_row(template, row, mapping=mapping) for row in rows]


def render_from_csv(
    csv_path: Path | str,
    template: Callable[..., Image.Image],
    *,
    mapping: dict[str, str] | None = None,
    encoding: str = "utf-8",
) -> list[Image.Image]:
    """Read a CSV file with a header row and render each row via `template`.

    Returns a list of PIL images, one per row. `mapping` renames CSV
    column names to template keyword names.
    """
    with Path(csv_path).open("r", encoding=encoding, newline="") as f:
        reader = csv.DictReader(f)
        return from_rows(template, reader, mapping=mapping)
