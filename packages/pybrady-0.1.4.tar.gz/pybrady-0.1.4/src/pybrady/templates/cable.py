# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Cable-labelling templates — wrap-around and fold-over flags.

A cable label is a strip of tape that wraps around a cable. Two common
shapes are worth distinguishing, and Brady Workstation exposes neither
as a first-class template — users have to design them manually each
time:

* **Wrap-around** (`cable_wrap`): the tape wraps around the cable
  forming a cylinder. The identifier repeats along the length of the
  strip so it's readable no matter where on the cable you look. By
  default the renderer measures the text and fits as many copies as
  the label width allows; pass `copies=N` for an explicit count.

* **Flag** (`cable_flag`): the tape wraps with part of it sticking out
  as a little flag. The two halves of the flag sit back-to-back, and
  because the flag folds over itself the second half is rotated 180
  degrees so both sides read left-to-right when viewed from either
  face. Always exactly two copies — the fold-over geometry is
  inherently paired.

Both shapes combine cleanly with `pybrady.templates.sequence.expand`
for batches:

    >>> from pybrady.templates.sequence import expand
    >>> from pybrady.templates.cable import cable_wrap
    >>> labels = [cable_wrap(t) for t in expand("eth0..eth47")]
"""

from __future__ import annotations

from pathlib import Path

from PIL import Image, ImageDraw

from pybrady.render.text import load_font, text_label


def _measure_text_width(text: str, size: int, font: str | Path | None) -> int:
    """Return the rendered text's bounding-box width in pixels."""
    loaded = load_font(size, font=font)
    probe = Image.new("1", (1, 1), 1)
    x0, _, x1, _ = ImageDraw.Draw(probe).textbbox((0, 0), text, font=loaded)
    return max(0, int(x1 - x0))


def _auto_copies(text_width_px: int, total_width_px: int, min_gap_px: int) -> int:
    """How many copies of `text_width_px` fit into `total_width_px`.

    At least `min_gap_px` of whitespace between adjacent copies, and
    always at least one copy (even if the text overflows — caller
    renders it clipped rather than raising).
    """
    slot = text_width_px + min_gap_px
    if slot <= 0:
        return 1
    return max(1, total_width_px // slot)


def cable_wrap(
    text: str,
    *,
    width_in: float = 2.0,
    height_in: float = 0.5,
    dpi: int = 300,
    font_size: int = 48,
    copies: int | None = None,
    min_gap_in: float = 0.1,
    font: str | Path | None = None,
) -> Image.Image:
    """Render a wrap-around cable label with repeating identifiers.

    The label is divided into equal-width slots and `text` is centred
    in each one, all in the same orientation. When the tape wraps
    around the cable to form a cylinder, one copy is visible from each
    viewing angle so the identifier stays readable no matter how the
    cable is rotated.

    `copies` controls how many copies to render:

    * `None` (default): auto-fit. The renderer measures the text at
      the current font size and fits as many copies as will fit with
      at least `min_gap_in` of whitespace between adjacent copies. A
      short string on a long self-lam label will produce many copies;
      a short 2" patch-cable label typically yields two.
    * `int`: render exactly that many copies. `min_gap_in` is ignored.

    `font_size` is in pixels at the output DPI; `font` is an optional
    TTF path or Pillow-resolvable family name (see
    `pybrady.render.text.load_font`).
    """
    if width_in <= 0 or height_in <= 0:
        raise ValueError(f"width_in and height_in must be positive ({width_in}, {height_in})")
    if copies is not None and copies < 1:
        raise ValueError(f"copies must be >= 1 (got {copies})")
    if min_gap_in < 0:
        raise ValueError(f"min_gap_in must be non-negative ({min_gap_in})")

    total_width_px = max(1, round(width_in * dpi))
    total_height_px = max(1, round(height_in * dpi))

    if copies is None:
        text_width_px = _measure_text_width(text, font_size, font)
        min_gap_px = max(0, round(min_gap_in * dpi))
        copies = _auto_copies(text_width_px, total_width_px, min_gap_px)

    canvas = Image.new("1", (total_width_px, total_height_px), 1)

    # Distribute slots evenly; any pixel remainder from integer division
    # goes to the final slot so every slot has at least `base` pixels and
    # nothing overflows the canvas.
    base_slot_width = total_width_px // copies
    for i in range(copies):
        x = i * base_slot_width
        slot_width = total_width_px - x if i == copies - 1 else base_slot_width
        copy = text_label(
            text,
            width_px=slot_width,
            height_px=total_height_px,
            size=font_size,
            font=font,
        )
        canvas.paste(copy, (x, 0))

    return canvas


def cable_flag(
    text: str,
    *,
    width_in: float = 2.0,
    height_in: float = 0.5,
    dpi: int = 300,
    font_size: int = 48,
    gap_in: float = 0.0,
    font: str | Path | None = None,
) -> Image.Image:
    """Render a fold-over cable-flag label.

    Exactly two copies of the identifier: the right one is rotated 180
    degrees so that when the tape folds back on itself to form the
    flag, both faces read left-to-right. `gap_in` is the portion of
    tape that wraps the cable itself between the two faces of the
    flag — leave it at zero for a cable thin enough that the tape
    folds flat against itself.

    Unlike `cable_wrap`, a flag label is inherently a two-copy shape
    (the two faces of the flag); there's no meaningful way to repeat
    it further.

    `font_size` is in pixels at the output DPI; `font` is an optional
    TTF path or Pillow-resolvable family name (see
    `pybrady.render.text.load_font`).
    """
    if width_in <= 0 or height_in <= 0:
        raise ValueError(f"width_in and height_in must be positive ({width_in}, {height_in})")
    if gap_in < 0:
        raise ValueError(f"gap_in must be non-negative ({gap_in})")
    if gap_in >= width_in:
        raise ValueError(f"gap_in ({gap_in}) must be less than width_in ({width_in})")

    total_width_px = max(1, round(width_in * dpi))
    total_height_px = max(1, round(height_in * dpi))
    gap_px = round(gap_in * dpi)
    # Split the remaining width equally; odd pixels go to the left half so
    # the two halves cover the full canvas without gaps.
    half_width_px = max(1, (total_width_px - gap_px) // 2)

    canvas = Image.new("1", (total_width_px, total_height_px), 1)

    half = text_label(
        text,
        width_px=half_width_px,
        height_px=total_height_px,
        size=font_size,
        font=font,
    )
    canvas.paste(half, (0, 0))
    # Right half starts after the gap; for odd total_width_px the extra
    # pixel was given to the left half so we compute the right origin
    # explicitly rather than symmetrising.
    right_origin_x = total_width_px - half_width_px
    canvas.paste(half.rotate(180), (right_origin_x, 0))

    return canvas
