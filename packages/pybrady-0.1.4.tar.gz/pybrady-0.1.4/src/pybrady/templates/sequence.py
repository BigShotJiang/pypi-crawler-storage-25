# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Sequence-expression expansion for batch label generation.

Network and datacentre labelling workflows are dominated by "stamp out
a strip of consecutive identifiers" tasks — 48 patch-panel ports,
cable runs, rack unit numbers, inventory tags, MAC-suffix sleeves.
`expand()` turns a short, human-friendly expression into the concrete
list of strings those labels should carry.

Supported expression forms:

* Literals: `eth0` -> `["eth0"]`
* Integer ranges: `eth0..eth3` -> `["eth0", "eth1", "eth2", "eth3"]`
* Zero-padded ranges: `HOST-001..HOST-004` -> `["HOST-001", ...]`
* Reverse ranges: `eth3..eth0` -> `["eth3", "eth2", "eth1", "eth0"]`
* Hex ranges: `0x00..0x03` -> `["0x00", "0x01", "0x02", "0x03"]`.
  Trigger on an explicit `0x` / `0X` prefix on either endpoint.
  Case of the output follows the start endpoint's case (`0xff` vs.
  `0xFF`). Works with any prefix: `MAC-0x00..MAC-0xff`, `PORT-0xA..PORT-0xC`.
* Step: `1..10:2` -> `[1, 3, 5, 7, 9]`. Step is a decimal (or hex)
  integer appended after a colon; a negative step is legal for
  explicit reverse. Omitting the step picks `1` when start <= end,
  `-1` otherwise.
* Comma concatenation: `A1..A4,B1..B4` splices the two expansions
  end to end.
* Hyphens or digits in the prefix don't confuse the digit anchor:
  `rack-12-eth0..rack-12-eth3` picks up only the trailing `0..3`.

Out of scope for this pass (easy to add if someone asks): explicit
step on literal lists, character ranges (`A..Z` as letters rather
than digits), decimal-to-hex / hex-to-decimal crosses.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

# Two patterns, one per radix. The hex one runs first so `0x00..0xff` is
# treated as hex even though `00` is also a valid decimal literal.
# `[^0-9a-fA-F]*` for the hex suffix stops greedy matching from eating a
# subsequent letter that could itself be a hex digit.
_HEX_SIDE_RE = re.compile(
    r"""
    \A
    (?P<prefix>.*?)                 # anything up to the marker
    (?P<marker>0[xX])               # 0x or 0X trigger
    (?P<digits>[0-9a-fA-F]+)        # hex digit run
    (?P<suffix>[^0-9a-fA-F]*)       # non-hex-digit tail
    \Z
    """,
    re.VERBOSE,
)
_DEC_SIDE_RE = re.compile(r"\A(?P<prefix>.*?)(?P<digits>\d+)(?P<suffix>\D*)\Z")


@dataclass(frozen=True)
class _Side:
    prefix: str
    digits: str
    suffix: str
    radix: int


class InvalidSequenceError(ValueError):
    """Raised when an expression can't be parsed as a sequence."""


def _split_side(side: str, *, segment: str) -> _Side:
    """Parse one endpoint into (prefix, digits, suffix, radix).

    Hex is matched first so `0x0A..0x0F` is treated as hex even though
    `0` and `0x0A` both look like valid decimal prefixes. The `0x`
    marker is rolled into `prefix` so the output format string can
    render it back verbatim.
    """
    hex_match = _HEX_SIDE_RE.match(side)
    if hex_match is not None:
        return _Side(
            prefix=hex_match["prefix"] + hex_match["marker"],
            digits=hex_match["digits"],
            suffix=hex_match["suffix"],
            radix=16,
        )
    dec_match = _DEC_SIDE_RE.match(side)
    if dec_match is not None:
        return _Side(
            prefix=dec_match["prefix"],
            digits=dec_match["digits"],
            suffix=dec_match["suffix"],
            radix=10,
        )
    raise InvalidSequenceError(f"sequence {segment!r}: {side!r} has no trailing digit group")


def _has_trailing_digit_group(side: str) -> bool:
    """Would this string parse as a valid endpoint?"""
    return _HEX_SIDE_RE.match(side) is not None or _DEC_SIDE_RE.match(side) is not None


def _parse_step(tail: str) -> tuple[str, int | None]:
    """Pull an optional `:<step>` off the end of `tail`, or return `None`.

    Returns `(trimmed_tail, step)`. `step` is `None` when the tail
    doesn't end in a valid step; `trimmed_tail` equals `tail` in that
    case. Hex steps (`:0x10`) are supported.

    An endpoint is allowed to contain colons in its suffix
    (`port:3..port:5`). We only treat a trailing `:N` as a step if
    stripping it still leaves a parseable endpoint — otherwise the
    colon belongs to the suffix.
    """
    if ":" not in tail:
        return tail, None
    head, _, step_str = tail.rpartition(":")
    step_str = step_str.strip()
    if not step_str:
        return tail, None
    try:
        # int(_, 0) auto-detects 0x prefix for hex; accepts optional sign.
        step = int(step_str, 0)
    except ValueError:
        return tail, None
    if not _has_trailing_digit_group(head):
        # Colon belongs to the endpoint's suffix, not a step marker.
        return tail, None
    return head, step


def _format_value(side: _Side, value: int, width: int) -> str:
    if side.radix == 16:
        upper = any(c.isupper() for c in side.digits)
        spec = f"{{:0{width}{'X' if upper else 'x'}}}"
    else:
        spec = f"{{:0{width}d}}"
    return f"{side.prefix}{spec.format(value)}{side.suffix}"


def _expand_single(segment: str) -> list[str]:
    segment = segment.strip()
    if not segment:
        return []
    if ".." not in segment:
        return [segment]

    left, _, right = segment.partition("..")
    # Step lives after the END endpoint, never the start. Strip it before
    # parsing the endpoint itself so `Gi0/1:primary..Gi0/10:primary:2`
    # works (last colon group is the step, earlier colons belong to the
    # endpoint suffix).
    right_trimmed, step = _parse_step(right)

    start_side = _split_side(left, segment=segment)
    end_side = _split_side(right_trimmed, segment=segment)

    if start_side.radix != end_side.radix:
        raise InvalidSequenceError(
            f"sequence {segment!r}: start and end have different radices "
            f"({start_side.radix} vs {end_side.radix})"
        )
    if start_side.prefix != end_side.prefix:
        raise InvalidSequenceError(
            f"sequence {segment!r}: start prefix {start_side.prefix!r} != "
            f"end prefix {end_side.prefix!r}"
        )
    if start_side.suffix != end_side.suffix:
        raise InvalidSequenceError(
            f"sequence {segment!r}: start suffix {start_side.suffix!r} != "
            f"end suffix {end_side.suffix!r}"
        )

    start = int(start_side.digits, start_side.radix)
    end = int(end_side.digits, end_side.radix)
    # Only zero-pad when the user deliberately wrote leading zeros on the
    # start endpoint. `00..10` gets width 2 (`00, 01, ..., 10`); `10..1`
    # gets no padding (so `10, 9, ..., 1`, not `10, 09, ..., 01`).
    width = len(start_side.digits) if start_side.digits.startswith("0") else 0

    if step is None:
        step = 1 if start <= end else -1
    elif step == 0:
        raise InvalidSequenceError(f"sequence {segment!r}: step must be non-zero")
    elif (start < end and step < 0) or (start > end and step > 0):
        raise InvalidSequenceError(
            f"sequence {segment!r}: step {step} would never reach end from start (wrong direction)"
        )

    values: list[str] = []
    n = start
    while (step > 0 and n <= end) or (step < 0 and n >= end):
        values.append(_format_value(start_side, n, width))
        n += step
    return values


def expand(expression: str) -> list[str]:
    """Expand `expression` to a list of strings.

    Empty segments inside a comma-separated expression are dropped
    silently so users can tolerate trailing commas. The whole expression
    being empty returns an empty list.
    """
    result: list[str] = []
    for segment in expression.split(","):
        result.extend(_expand_single(segment))
    return result
