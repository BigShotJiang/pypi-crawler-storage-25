# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Render a `.bws`/`.bwt` label file to a PIL image.

Ties together everything in `brady_bws`: header parsing gives us the
label's physical dimensions (from the embedded PartInfo XML), the
Design+Object parsers give us the text and barcode entities with
positions, sizes, fonts and values. This module turns those into a
1-bit PIL image the caller can preview, print via `pybrady.printer`,
or save to disk.

The renderer is deliberately best-effort for v1:

* Text layers use pybrady's `text_label` helper which falls back to
  DejaVu/Liberation since pybrady doesn't (and shouldn't) redistribute
  Brady's proprietary Arial. Glyph metrics therefore won't match
  Brady Workstation pixel-for-pixel; the layout will be close but not
  identical.
* Barcodes are rasterised via `pybrady.render.barcode` / `qr` and then
  stretched to the entity's bounding box.
* Rich-text per-run formatting collapses to a single font (the first
  run's). Brady Workstation's template editor writes uniform
  formatting across all runs in practice; labels that mix styles in
  one field will lose that nuance until the renderer grows a full
  run-by-run path.
"""

from __future__ import annotations

import xml.etree.ElementTree as ET
from collections.abc import Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from PIL import Image, ImageDraw

from pybrady.paths import fonts_dir as _default_fonts_dir
from pybrady.render import Label
from pybrady.render.text import load_font, text_label
from pybrady.templates.brady_bws import (
    BwsBarcodeEntity,
    BwsFont,
    BwsTextEntity,
    BwsTextParagraph,
    read_barcode_entities,
    read_header,
    read_text_entities,
)

# PartInfo XML stores dimensions in ten-thousandths of an inch
# (`<Width>10000</Width>` = 1.0 inch).
_PART_INFO_UNITS_PER_INCH = 10_000

# Brady Workstation stores entity positions/sizes as inches (doubles) and
# font sizes in WPF device-independent pixels (1/96 inch). When rendering
# to a printer at some DPI, font sizes scale by DPI/96 to keep glyphs at
# their intended physical height.
_WPF_DIP_PER_INCH = 96

_DEFAULT_DPI = 300


@dataclass(frozen=True)
class RenderedLabel:
    """A rendered label plus the physical dimensions it was rendered at."""

    image: Image.Image
    width_in: float
    height_in: float
    dpi: int


def _label_dimensions_from_part_info(
    part_info_xml: str, *, landscape: bool
) -> tuple[float, float] | None:
    """Return `(width_in, height_in)` from the embedded PartInfo XML, or None."""
    try:
        root = ET.fromstring(part_info_xml)
    except ET.ParseError:
        return None
    part = root.find(".//Part")
    if part is None:
        return None
    w_raw = part.findtext("Width")
    h_raw = part.findtext("Height")
    if not w_raw or not h_raw:
        return None
    try:
        w = int(w_raw) / _PART_INFO_UNITS_PER_INCH
        h = int(h_raw) / _PART_INFO_UNITS_PER_INCH
    except ValueError:
        return None
    if w <= 0 or h <= 0:
        return None
    if landscape:
        # PartInfo stores media dimensions in the cartridge's native
        # orientation; Brady Workstation's editor and entity coordinates
        # are in landscape (label-length x tape-width).
        return (max(w, h), min(w, h))
    return (w, h)


def _bounds_from_entities(
    texts: list[BwsTextEntity], barcodes: list[BwsBarcodeEntity]
) -> tuple[float, float]:
    max_x = 0.0
    max_y = 0.0
    for t in texts:
        max_x = max(max_x, t.common.position[0] + t.common.width)
        max_y = max(max_y, t.common.position[1] + t.common.height)
    for b in barcodes:
        max_x = max(max_x, b.common.position[0] + b.common.width)
        max_y = max(max_y, b.common.position[1] + b.common.height)
    return (max_x, max_y)


def _index_fonts(fonts_dir: Path) -> dict[str, Path]:
    """Build a lowercase-family-name -> TTF-path map for every font in `fonts_dir`."""
    index: dict[str, Path] = {}
    if not fonts_dir.is_dir():
        return index
    for path in fonts_dir.iterdir():
        if path.suffix.lower() not in (".ttf", ".otf"):
            continue
        index[path.stem.lower()] = path
    return index


def _resolve_font_file(font: BwsFont, font_index: dict[str, Path]) -> Path | None:
    """Pick the best TTF from the font index for a given entity font, or None.

    Family matching is case-insensitive. If `bold` or `italic` is set on
    the entity we prefer a variant file whose name reflects that (e.g.
    `Brady Alpine Bold.ttf`); otherwise we fall back to the plain family.
    """
    if not font_index:
        return None
    family = font.family.strip().lower()
    if not family:
        return None
    # Collect candidate keys in decreasing order of preference.
    suffixes = []
    if font.bold and font.italic:
        suffixes.append(" bold italic")
    if font.bold:
        suffixes.append(" bold")
    if font.italic:
        suffixes.append(" italic")
    suffixes.append("")
    for suffix in suffixes:
        key = (family + suffix).strip()
        if key in font_index:
            return font_index[key]
    return None


def _resolve_text(entity: BwsTextEntity, values: dict[str, str] | None) -> str:
    """Pick the text string to render for a RichTextEntity.

    If the user supplied a value under the entity's `template_prompt`
    key, that wins. Otherwise the entity's own `text` (from a saved
    `.bws`) is used; for an unfilled template `.bwt`, that's empty.
    """
    if values and entity.template_prompt and entity.template_prompt in values:
        return values[entity.template_prompt]
    return entity.text


# Brady's TextAlignment enum (matches WPF): 0 = Left, 1 = Right, 2 = Center,
# 3 = Justify. We fold Justify into Left since proper justified text is rarely
# worth the complexity on label-sized canvases.
_ALIGN_LEFT = 0
_ALIGN_RIGHT = 1
_ALIGN_CENTER = 2


def _paragraph_has_text(paragraph: BwsTextParagraph) -> bool:
    return any(run.text for run in paragraph.runs)


def _load_run_font(font: BwsFont, dpi: int, font_index: dict[str, Path]) -> Any:
    """Load the Pillow ImageFont for a single run at the target DPI."""
    font_file = _resolve_font_file(font, font_index)
    font_px = max(1, round(font.size * dpi / _WPF_DIP_PER_INCH))
    return load_font(font_px, font=font_file)


def _render_paragraph_line(
    paragraph: BwsTextParagraph,
    *,
    width_px: int,
    dpi: int,
    font_index: dict[str, Path],
) -> tuple[Image.Image, int] | None:
    """Render one paragraph on one line, each run in its own font.

    Returns `(line_image, baseline_offset)` where `baseline_offset` is
    the distance from the image's top to the shared text baseline. The
    caller stacks line images and uses the baseline to space
    consecutive paragraphs. Returns `None` if the paragraph has no
    printable text.
    """
    if not _paragraph_has_text(paragraph):
        return None

    # Measure every run at its own font; collect widths and the tallest
    # ascent/descent so runs of different sizes share a common baseline.
    fonts = [_load_run_font(run.font, dpi, font_index) for run in paragraph.runs]
    probe = Image.new("1", (1, 1), 1)
    probe_draw = ImageDraw.Draw(probe)
    run_widths: list[int] = []
    max_ascent = 0
    max_descent = 0
    for run, f in zip(paragraph.runs, fonts, strict=True):
        x0, _, x1, _ = probe_draw.textbbox((0, 0), run.text, font=f, anchor="ls")
        run_widths.append(max(0, int(x1 - x0)))
        ascent, descent = f.getmetrics()
        max_ascent = max(max_ascent, int(ascent))
        max_descent = max(max_descent, int(descent))

    total_w = sum(run_widths)
    line_h = max(1, max_ascent + max_descent)

    img = Image.new("1", (max(1, width_px), line_h), 1)
    draw = ImageDraw.Draw(img)

    if paragraph.text_alignment == _ALIGN_LEFT:
        x = 0
    elif paragraph.text_alignment == _ALIGN_RIGHT:
        x = width_px - total_w
    else:  # Center (and unknown-fold-to-center)
        x = (width_px - total_w) // 2

    baseline_y = max_ascent
    for run, f, w in zip(paragraph.runs, fonts, run_widths, strict=True):
        if run.text:
            draw.text((x, baseline_y), run.text, font=f, fill=0, anchor="ls")
        x += w

    return img, max_ascent


def _render_paragraphs_block(
    paragraphs: Sequence[BwsTextParagraph],
    *,
    width_px: int,
    height_px: int,
    dpi: int,
    font_index: dict[str, Path],
) -> Image.Image | None:
    """Stack paragraph lines into a single fixed-size canvas, vertically centred.

    Returns `None` if nothing was printable.
    """
    lines: list[Image.Image] = []
    for paragraph in paragraphs:
        rendered = _render_paragraph_line(
            paragraph, width_px=width_px, dpi=dpi, font_index=font_index
        )
        if rendered is None:
            # Keep vertical spacing for blank paragraphs by inserting a
            # short spacer sized to the paragraph-level font so a blank
            # line doesn't collapse.
            spacer_font = _load_run_font(paragraph.paragraph_font, dpi, font_index)
            ascent, descent = spacer_font.getmetrics()
            spacer_h = max(1, int(ascent + descent))
            lines.append(Image.new("1", (width_px, spacer_h), 1))
        else:
            lines.append(rendered[0])

    if not lines:
        return None

    stack_h = sum(line.size[1] for line in lines)
    canvas = Image.new("1", (max(1, width_px), max(1, height_px)), 1)
    y = max(0, (height_px - stack_h) // 2)
    for line in lines:
        canvas.paste(line, (0, y))
        y += line.size[1]
    return canvas


def _render_text_entity(
    entity: BwsTextEntity,
    *,
    dpi: int,
    values: dict[str, str] | None,
    font_index: dict[str, Path],
) -> tuple[Image.Image, tuple[int, int]] | None:
    width_px = max(1, round(entity.common.width * dpi))
    height_px = max(1, round(entity.common.height * dpi))

    substituted = bool(values and entity.template_prompt and entity.template_prompt in values)

    if substituted:
        # A caller-provided string replaces the entity's own text; there
        # are no runs in this case, so render as a single-font line using
        # the entity-level font.
        assert values is not None and entity.template_prompt is not None  # for mypy
        text = values[entity.template_prompt]
        if not text:
            return None
        font_px = max(1, round(entity.font.size * dpi / _WPF_DIP_PER_INCH))
        font_file = _resolve_font_file(entity.font, font_index)
        img = text_label(
            text,
            width_px=width_px,
            height_px=height_px,
            size=font_px,
            font=font_file,
        )
    else:
        # Render what the file actually stores, preserving per-run
        # formatting (mixed bold/italic/size within one paragraph).
        rendered = _render_paragraphs_block(
            entity.paragraphs,
            width_px=width_px,
            height_px=height_px,
            dpi=dpi,
            font_index=font_index,
        )
        if rendered is None:
            return None
        img = rendered

    x_px = round(entity.common.position[0] * dpi)
    y_px = round(entity.common.position[1] * dpi)
    return img, (x_px, y_px)


def _barcode_symbology_for(entity: BwsBarcodeEntity) -> str | None:
    """Map Brady's BarcodeType name to a pybrady symbology identifier.

    Returns None for symbologies pybrady's barcode/qr helpers don't yet
    support; the renderer skips those rather than crashing.
    """
    mapping = {
        "Code128": "code128",
        "Code128A": "code128",
        "Code128B": "code128",
        "Code128C": "code128",
        "GS1128": "code128",
        "Code39": "code39",
        "Code39FullASCII": "code39",
        "EAN13": "ean13",
        "EAN8": "ean8",
        "UPCA": "upca",
        "ITF14": "itf",
        "Interleaved2of5": "itf",
        "QR": "qr",
        "DataMatrix": "datamatrix",
        "PDF417": "pdf417",
    }
    return mapping.get(entity.barcode_type_name)


def _render_barcode_entity(
    entity: BwsBarcodeEntity, *, dpi: int
) -> tuple[Image.Image, tuple[int, int]] | None:
    sym = _barcode_symbology_for(entity)
    if sym is None or not entity.value:
        return None
    width_px = max(1, round(entity.common.width * dpi))
    height_px = max(1, round(entity.common.height * dpi))

    if sym == "qr":
        from pybrady.render.qr import qr as render_qr

        side = min(width_px, height_px)
        raw = render_qr(entity.value, size_px=side)
    elif sym == "datamatrix":
        from pybrady.render.datamatrix import datamatrix as render_dm

        side = min(width_px, height_px)
        raw = render_dm(entity.value, size_px=side)
    elif sym == "pdf417":
        from pybrady.render.pdf417 import pdf417 as render_pdf417

        raw = render_pdf417(entity.value, width_px=width_px, height_px=height_px)
    else:
        from pybrady.render.barcode import barcode as render_barcode

        raw = render_barcode(entity.value, symbology=sym, height_px=height_px)

    # Stretch/shrink to the entity's bounding box; Brady Workstation's
    # density/ratio controls have subtle effects on thermal print
    # quality that pybrady's rasteriser doesn't replicate yet.
    if raw.size != (width_px, height_px):
        raw = raw.resize((width_px, height_px), Image.Resampling.NEAREST)
    x_px = round(entity.common.position[0] * dpi)
    y_px = round(entity.common.position[1] * dpi)
    return raw, (x_px, y_px)


def render_bws(
    path: Path | str,
    *,
    dpi: int = _DEFAULT_DPI,
    values: dict[str, str] | None = None,
    size_inches: tuple[float, float] | None = None,
    fonts_dir: Path | str | None = None,
) -> RenderedLabel:
    """Render a `.bws`/`.bwt` file to a 1-bit PIL image at the given DPI.

    `values` is an optional mapping from template-prompt name (e.g.
    `"Text 1"`) to the concrete string to render in that field. This is
    how an `.bwt` template gets filled in without modifying the file on
    disk.

    `size_inches` forces a specific canvas size; omit it to derive the
    canvas from the file's PartInfo XML (landscape orientation) with a
    fallback to the bounding box of the file's entities.

    `fonts_dir` points at a directory of TTF files (typically the output
    of `brady-export-templates`). When omitted, the renderer asks
    :func:`pybrady.paths.fonts_dir` — which resolves to
    `$PYBRADY_DATA_DIR/Fonts` if set, otherwise
    `~/pybrady/brady-templates/Fonts`. Matched families are rendered
    with the actual Brady font; unmatched ones fall back to Pillow's
    built-in DejaVu chain.
    """
    header = read_header(path)
    texts = read_text_entities(path)
    barcodes = read_barcode_entities(path)

    resolved_fonts_dir = Path(fonts_dir) if fonts_dir is not None else _default_fonts_dir()
    font_index = _index_fonts(resolved_fonts_dir)

    if size_inches is not None:
        label_w_in, label_h_in = size_inches
    else:
        dims = _label_dimensions_from_part_info(header.get("PartInfo", ""), landscape=True)
        if dims is not None:
            label_w_in, label_h_in = dims
        else:
            bx, by = _bounds_from_entities(texts, barcodes)
            # 0.1" of padding so text doesn't sit flush against the edge
            label_w_in = max(0.5, bx + 0.1)
            label_h_in = max(0.5, by + 0.1)

    canvas = Label(
        max(1, round(label_w_in * dpi)),
        max(1, round(label_h_in * dpi)),
    )

    for text_entity in texts:
        text_rendered = _render_text_entity(
            text_entity, dpi=dpi, values=values, font_index=font_index
        )
        if text_rendered is None:
            continue
        img, at = text_rendered
        canvas.paste(img, at=at)

    for barcode_entity in barcodes:
        bc_rendered = _render_barcode_entity(barcode_entity, dpi=dpi)
        if bc_rendered is None:
            continue
        img, at = bc_rendered
        canvas.paste(img, at=at)

    return RenderedLabel(
        image=canvas.image,
        width_in=label_w_in,
        height_in=label_h_in,
        dpi=dpi,
    )
