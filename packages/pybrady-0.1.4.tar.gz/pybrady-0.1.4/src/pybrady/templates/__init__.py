# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Template I/O — read (and eventually write) Brady label template files.

The immediate goal is to make Brady's own `.bws` (Brady UDF v2 binary)
files usable from Python without going through Brady Workstation.
"""

from pybrady.templates.brady_bws import (
    BARCODE_ENTITY_TYPE_ID,
    RICH_TEXT_ENTITY_TYPE_ID,
    BwsAppDataEntry,
    BwsBarcodeEntity,
    BwsDesign,
    BwsEntity,
    BwsEntityCommon,
    BwsFileIndex,
    BwsFont,
    BwsHeader,
    BwsStore,
    BwsTextEntity,
    BwsTextParagraph,
    BwsTextRun,
    InvalidBwsFileError,
    barcode_type_name,
    decode_barcode_entity,
    decode_rich_text_entity,
    read_app_data,
    read_app_data_store,
    read_barcode_entities,
    read_design,
    read_design_store,
    read_entities,
    read_file_index,
    read_header,
    read_object_store,
    read_store,
    read_text_entities,
    read_thumbnail,
)
from pybrady.templates.brady_bws_render import RenderedLabel, render_bws

__all__ = [
    "BARCODE_ENTITY_TYPE_ID",
    "RICH_TEXT_ENTITY_TYPE_ID",
    "BwsAppDataEntry",
    "BwsBarcodeEntity",
    "BwsDesign",
    "BwsEntity",
    "BwsEntityCommon",
    "BwsFileIndex",
    "BwsFont",
    "BwsHeader",
    "BwsStore",
    "BwsTextEntity",
    "BwsTextParagraph",
    "BwsTextRun",
    "InvalidBwsFileError",
    "RenderedLabel",
    "barcode_type_name",
    "decode_barcode_entity",
    "decode_rich_text_entity",
    "read_app_data",
    "read_app_data_store",
    "read_barcode_entities",
    "read_design",
    "read_design_store",
    "read_entities",
    "read_file_index",
    "read_header",
    "read_object_store",
    "read_store",
    "read_text_entities",
    "read_thumbnail",
    "render_bws",
]
