# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Generic single-block text label.

`generic(text)` is the "just put this text on a label" template —
nothing structural, no repeat/mirror/sequence. Use it when the four
other parametric templates (`cable_wrap`, `cable_flag`, `asset_tag`,
`patch_panel`) don't fit the situation. Supports multi-line text via
embedded newlines and left / center / right alignment.

Batches and CSV feeds work through the generic contract:

    >>> from pybrady.templates.generic import generic
    >>> from pybrady.templates.parametric import render_from_csv
    >>> labels = render_from_csv("labels.csv", generic)
"""

from __future__ import annotations

from pathlib import Path

from PIL import Image, ImageDraw

from pybrady.render.text import load_font


def generic(
    text: str,
    *,
    width_in: float = 2.0,
    height_in: float = 0.5,
    dpi: int = 300,
    font_size: int = 48,
    align: str = "center",
    font: str | Path | None = None,
    padding_in: float = 0.0,
) -> Image.Image:
    """Render `text` centred vertically on a fixed-size label.

    Multi-line text is supported — embed `\\n` in the string. Pillow's
    multi-line renderer handles layout with `align` controlling the
    horizontal alignment of the whole text block within the canvas.

    `align` is one of `"left"`, `"center"`, `"right"`. `padding_in`
    inserts a margin from the left or right edge when aligned to that
    side (ignored for center alignment).

    `font_size` is in pixels at the output DPI; `font` is an optional
    TTF path or Pillow-resolvable family name.
    """
    if width_in <= 0 or height_in <= 0:
        raise ValueError(f"width_in and height_in must be positive ({width_in}, {height_in})")
    if padding_in < 0:
        raise ValueError(f"padding_in must be non-negative ({padding_in})")
    if align not in ("left", "center", "right"):
        raise ValueError(f"invalid align: {align!r}")

    width_px = max(1, round(width_in * dpi))
    height_px = max(1, round(height_in * dpi))
    padding_px = max(0, round(padding_in * dpi))

    img = Image.new("1", (width_px, height_px), 1)
    loaded = load_font(font_size, font=font)
    draw = ImageDraw.Draw(img)
    x0, y0, x1, y1 = draw.multiline_textbbox((0, 0), text, font=loaded, align=align)
    tw = int(x1 - x0)
    th = int(y1 - y0)

    if align == "left":
        x = padding_px - int(x0)
    elif align == "right":
        x = width_px - tw - padding_px - int(x0)
    else:  # center
        x = (width_px - tw) // 2 - int(x0)
    y = (height_px - th) // 2 - int(y0)

    draw.multiline_text((x, y), text, fill=0, font=loaded, align=align)
    return img
