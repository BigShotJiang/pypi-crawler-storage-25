# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Standard filesystem locations pybrady uses for bundled Brady assets.

Brady Workstation ships label templates (.BWT), TrueType fonts, and an
SVG icon library that pybrady can consume once they've been copied out
of the Workstation install by `brady-export-templates`. This module
centralises where those copies live so the exporter (write side) and
the renderer (read side) stay in sync.

Resolution order for the data directory:

* ``$PYBRADY_DATA_DIR`` if set (absolute or relative to CWD)
* ``~/pybrady/brady-templates`` otherwise

The data directory layout mirrors what the exporter writes:

    <data_dir>/
        manifest.json
        Addins/<app>/Templates/...       # .BWT templates
        Fonts/Brady *.ttf                # Brady-branded TrueType fonts
        Icons/                           # Components/ImageLibrary snapshot
            graphicMetadata.xml
            *.svg
            Thumbnails/*.png

The same layout round-trips cleanly through :func:`create_bundle` /
:func:`extract_bundle` so a data dir exported on one host can be moved
to another without re-discovering a Brady Workstation install.
"""

from __future__ import annotations

import os
import shutil
from pathlib import Path

_ENV_VAR = "PYBRADY_DATA_DIR"
_DEFAULT_SUBPATH = ("pybrady", "brady-templates")

FONTS_SUBDIR = "Fonts"
ICONS_SUBDIR = "Icons"
TEMPLATES_SUBDIR = "Addins"
MANIFEST_FILENAME = "manifest.json"


def data_dir() -> Path:
    """Return the directory pybrady reads bundled Brady assets from."""
    env = os.environ.get(_ENV_VAR)
    if env:
        return Path(env)
    return Path.home().joinpath(*_DEFAULT_SUBPATH)


def fonts_dir() -> Path:
    """Return the directory where Brady TrueType fonts are expected."""
    return data_dir() / FONTS_SUBDIR


def icons_dir() -> Path:
    """Return the directory where the Brady icon library is expected."""
    return data_dir() / ICONS_SUBDIR


def templates_dir() -> Path:
    """Return the directory where Brady `.BWT` templates are expected."""
    return data_dir() / TEMPLATES_SUBDIR


# Map archive suffixes to the `shutil.make_archive` format name. Order
# matters — compound suffixes (`.tar.gz`) must be checked before their
# single-suffix shorthand (`.gz`) wouldn't appear alone here anyway.
_ARCHIVE_FORMATS: tuple[tuple[tuple[str, ...], str], ...] = (
    ((".tar.gz", ".tgz"), "gztar"),
    ((".tar.bz2", ".tbz2"), "bztar"),
    ((".tar.xz", ".txz"), "xztar"),
    ((".tar",), "tar"),
    ((".zip",), "zip"),
)


def _is_recognised_archive_name(name: str) -> bool:
    """True if `name` ends with one of our recognised archive suffixes."""
    lowered = name.lower()
    return any(lowered.endswith(s) for suffixes, _ in _ARCHIVE_FORMATS for s in suffixes)


def _archive_format_for(path: Path) -> tuple[str, str]:
    """Return `(shutil-format, base-path)` for `path`.

    `base-path` is `path` with its archive extension stripped — what
    `shutil.make_archive` actually wants as its `base_name`.

    Falls back to `zip` format when the path has no recognised archive
    extension. Zip is the Windows-friendliest format (natively handled
    by PowerShell's `Expand-Archive` / `Compress-Archive` and File
    Explorer without any extra tooling) and universally available on
    macOS and Linux, so it's the safest default for cross-platform
    transport.
    """
    name = path.name.lower()
    for suffixes, fmt in _ARCHIVE_FORMATS:
        for suffix in suffixes:
            if name.endswith(suffix):
                base = path.parent / path.name[: -len(suffix)]
                return fmt, str(base)
    # Unrecognised (or absent) extension — treat the whole name as the
    # base and let shutil append `.zip`.
    return "zip", str(path)


def create_bundle(source: Path | str, dest: Path | str) -> Path:
    """Pack `source` (a data dir) into an archive at `dest`.

    The archive format is picked from `dest`'s suffix (`.tar.gz`,
    `.tgz`, `.tar.bz2`, `.tar.xz`, `.tar`, or `.zip`). Paths without a
    recognised archive extension default to `.zip` — the format every
    Windows host can open end-to-end without extra tooling — and
    `shutil` appends `.zip` to the written file.

    The returned path is the archive actually written, which may
    differ from `dest` when `.zip` is appended.
    """
    src = Path(source)
    if not src.is_dir():
        raise FileNotFoundError(f"bundle source {src} is not a directory")
    dst = Path(dest)
    fmt, base_name = _archive_format_for(dst)
    dst.parent.mkdir(parents=True, exist_ok=True)
    # `shutil.make_archive` chdirs into `root_dir` and packs `base_dir`
    # relative to it — so we get a single top-level directory in the
    # archive matching the source's name.
    written = Path(
        shutil.make_archive(
            base_name=base_name,
            format=fmt,
            root_dir=str(src.parent),
            base_dir=src.name,
        )
    )
    # `shutil.make_archive` re-appends its canonical suffix (e.g.
    # `.tar.gz`) regardless of the shorthand the user asked for
    # (`.tgz`). When the user's requested extension was a recognised
    # shorthand, rename back so the path on disk matches their
    # request. When the extension was unrecognised we deliberately
    # keep the `.zip` shutil appended — it's how the user learns
    # they ended up with a zip.
    if written != dst and _is_recognised_archive_name(dst.name):
        written.replace(dst)
        return dst
    return written


def extract_bundle(archive: Path | str, dest: Path | str) -> Path:
    """Extract `archive` into `dest` and return the resulting directory.

    If `archive` was produced by :func:`create_bundle`, it contains a
    single top-level directory (the original source's name). That
    directory is extracted verbatim under `dest` — callers typically
    pass `dest.parent` of where they want the data dir to land.
    """
    src = Path(archive)
    if not src.is_file():
        raise FileNotFoundError(f"bundle archive {src} does not exist")
    dst = Path(dest)
    dst.mkdir(parents=True, exist_ok=True)
    shutil.unpack_archive(str(src), str(dst))
    return dst
