# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""High-level Brady printer facade.

Chooses the correct protocol generator for the given model and hands bytes to
the transport. This is the surface most library users should need.
"""

from __future__ import annotations

from collections.abc import Iterable
from typing import TYPE_CHECKING

from pybrady.exceptions import UnsupportedModelError
from pybrady.models import PRINTER_MODELS, CutMode, PrinterModel, Protocol
from pybrady.protocol import esc_bmp
from pybrady.protocol.esc_bmp_status import STATUS_LENGTH, BmpStatus
from pybrady.protocol.esc_bmp_status import parse as parse_bmp_status
from pybrady.render import image_to_rows

if TYPE_CHECKING:
    from PIL import Image

    from pybrady.transport.base import AsyncTransport
    from pybrady.transport.usb_ieee1284 import DeviceId

SUBSCRIBE = esc_bmp.SUBSCRIBE
STATUS_READ_TIMEOUT = 5.0


class BradyPrinter:
    def __init__(self, transport: AsyncTransport, model: str | PrinterModel) -> None:
        if isinstance(model, str):
            try:
                model = PRINTER_MODELS[model]
            except KeyError as e:
                raise UnsupportedModelError(f"unknown Brady model: {model!r}") from e
        self._transport = transport
        self._model = model

    @property
    def model(self) -> PrinterModel:
        return self._model

    async def query_status(self) -> BmpStatus:
        """Query live printer status: substrate, ribbon, dimensions, counters.

        Sends the ESC/BMP `1B 49` subscribe command and decodes the 168-byte
        response. Works on BMP51/53/61 over any transport that supports
        bidirectional I/O (USB today; TCP later).

        The USB transport initialises the bidi channel automatically at
        connection time, so callers don't need to do anything special.
        """
        if self._model.protocol is not Protocol.ESC_BMP:
            raise UnsupportedModelError(
                f"{self._model.name}: live status query is ESC/BMP-specific"
            )
        await self._transport.write(SUBSCRIBE)
        data = await self._transport.read(STATUS_LENGTH * 2, timeout=STATUS_READ_TIMEOUT)
        return parse_bmp_status(data)

    async def query_identity(self) -> DeviceId | None:
        """Query the printer's IEEE 1284 Device ID, if the transport supports it.

        Returns None if the underlying transport doesn't implement device
        identity queries (currently only `UsbTransport` does).

        Note: this returns IDENTITY (manufacturer/model/command-set), not
        live status (media type, errors, battery). BMP51 does not expose
        live status over USB in practice — use TCP for that once the
        `TcpTransport` ships.
        """
        from pybrady.transport.usb import UsbTransport

        if isinstance(self._transport, UsbTransport):
            return await self._transport.get_device_id()
        return None

    async def print(
        self,
        image: Image.Image | Iterable[Image.Image],
        *,
        copies: int = 1,
        cut_mode: CutMode = CutMode.END_OF_JOB,
        compress: bool = True,
    ) -> None:
        """Render one or more images as label pages and print them.

        A single PIL Image produces a one-page job. An iterable of images
        produces a multi-page job, one image per page.

        `copies` repeats the full page set N times in the byte stream — the
        ESC/BMP protocol has no wire-level copy count, so copies are
        realised by repetition. `copies=3` of a 2-page job sends 6 pages
        in order: [p1, p2, p1, p2, p1, p2].

        `compress` (default True) emits each non-blank row as RLE when that's
        smaller than the uncompressed form. Typical labels (text, line art)
        see 5-20x compression; pass False to force uncompressed output for
        debugging.
        """
        if self._model.protocol is not Protocol.ESC_BMP:
            raise UnsupportedModelError(
                f"{self._model.name}: protocol {self._model.protocol.value} is not yet implemented"
            )
        if cut_mode not in self._model.cut_modes:
            raise UnsupportedModelError(
                f"{self._model.name} does not support cut mode {cut_mode.name}"
            )
        if copies < 1:
            raise ValueError(f"copies must be >= 1, got {copies}")

        # Image is iterable at the pixel level but PIL.Image.Image itself is
        # not a Sequence of images, so isinstance check is the right dispatch.
        from PIL import Image as _PILImage

        images: list[Image.Image] = [image] if isinstance(image, _PILImage.Image) else list(image)
        if not images:
            raise ValueError("at least one image is required")

        # All pages must have the same pixel width (true today; could be
        # relaxed later if multi-size jobs become a thing).
        pages = [image_to_rows(img) for img in images] * copies
        width_pixels = images[0].size[0]
        data = esc_bmp.build_job(
            pages, cut_mode=cut_mode, compress=compress, width_pixels=width_pixels
        )
        await self._transport.write(data)
