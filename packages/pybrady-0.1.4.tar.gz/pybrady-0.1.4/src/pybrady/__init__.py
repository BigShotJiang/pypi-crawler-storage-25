# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""pybrady — Python library for Brady label printers."""

from importlib.metadata import PackageNotFoundError
from importlib.metadata import version as _pkg_version

from pybrady.exceptions import (
    BradyError,
    ProtocolError,
    TransportError,
    UnsupportedModelError,
)
from pybrady.models import PRINTER_MODELS, CutMode, PrinterModel, Protocol
from pybrady.printer import BradyPrinter

try:
    __version__ = _pkg_version("pybrady")
except PackageNotFoundError:  # source checkout without an installed dist
    __version__ = "0.0.0+unknown"

__all__ = [
    "PRINTER_MODELS",
    "BradyError",
    "BradyPrinter",
    "CutMode",
    "PrinterModel",
    "Protocol",
    "ProtocolError",
    "TransportError",
    "UnsupportedModelError",
    "__version__",
]
