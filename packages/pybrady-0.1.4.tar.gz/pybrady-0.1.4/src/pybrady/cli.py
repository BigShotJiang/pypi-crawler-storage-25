# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""pybrady command-line interface — `brady-print`.

Minimal by design: produce a label from text, image, QR, barcode, or icon,
and either print it or dry-run to stdout/file. Matches the Python API
one-to-one so anything the CLI does is reproducible in code.
"""

from __future__ import annotations

import argparse
import asyncio
import sys
from pathlib import Path

from PIL import Image

from pybrady import PRINTER_MODELS, BradyPrinter, CutMode
from pybrady.protocol.esc_bmp_decode import summary
from pybrady.render import Label, icon, text_label
from pybrady.transport.base import AsyncTransport
from pybrady.transport.capture import CaptureTransport
from pybrady.transport.usb import UsbTransport

CUT_MODES: dict[str, CutMode] = {
    "end-of-job": CutMode.END_OF_JOB,
    "end-of-label": CutMode.END_OF_LABEL,
    "never": CutMode.NEVER,
}


def load_image(path: Path) -> Image.Image:
    img = Image.open(path)
    return img if img.mode == "1" else img.convert("1")


def hex_dump(data: bytes, width: int = 16) -> str:
    lines = []
    for i in range(0, len(data), width):
        chunk = data[i : i + width]
        hexed = " ".join(f"{b:02x}" for b in chunk)
        ascii_ = "".join(chr(b) if 0x20 <= b < 0x7F else "." for b in chunk)
        lines.append(f"{i:08x}  {hexed:<{width * 3}}  {ascii_}")
    return "\n".join(lines)


def _parse_barcode_spec(spec: str) -> tuple[str, str]:
    """Split `SYMBOLOGY:DATA` into (symbology, data). Default symbology: code128."""
    if ":" in spec:
        sym, _, data = spec.partition(":")
        return sym.lower(), data
    return "code128", spec


def _build_source_image(args: argparse.Namespace, dpi: int) -> Image.Image:
    width_px = max(1, round(args.width_in * dpi))
    height_px = max(1, round(args.height_in * dpi))

    if args.image:
        return load_image(args.image)

    if args.text:
        return text_label(
            args.text,
            width_px=width_px,
            height_px=height_px,
            size=args.font_size,
            align=args.align,
        )

    if args.qr:
        from pybrady.render.qr import qr as qr_render

        side = min(width_px, height_px)
        code = qr_render(args.qr, size_px=side)
        return Label(width_px, height_px).paste_centered(code).image

    if args.barcode:
        from pybrady.render.barcode import barcode as barcode_render

        sym, data = _parse_barcode_spec(args.barcode)
        code = barcode_render(data, symbology=sym, height_px=height_px)
        # barcode natural width may exceed canvas; scale down if needed.
        if code.width > width_px:
            scale = width_px / code.width
            code = code.resize(
                (width_px, max(1, int(code.height * scale))),
                Image.Resampling.NEAREST,
            )
        return Label(width_px, height_px).paste_centered(code).image

    if args.icon:
        side = min(width_px, height_px)
        art = icon(args.icon, size_px=side)
        return Label(width_px, height_px).paste_centered(art).image

    raise AssertionError("argparse should guarantee at least one source flag")


async def _print_async(
    transport: AsyncTransport,
    image: Image.Image,
    model: str,
    cut_mode: CutMode,
    copies: int,
    compress: bool,
) -> None:
    async with transport:
        printer = BradyPrinter(transport, model=model)
        await printer.print(image, copies=copies, cut_mode=cut_mode, compress=compress)


def _build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="brady-print",
        description="Print a label on a Brady printer, or dry-run to validate first.",
    )
    src = p.add_mutually_exclusive_group(required=True)
    src.add_argument("--text", metavar="STRING", help="Render this text centered on a label")
    src.add_argument(
        "--image", type=Path, metavar="PATH", help="Print this image file (PNG/BMP/etc.)"
    )
    src.add_argument("--qr", metavar="DATA", help="Render a QR code for this data")
    src.add_argument(
        "--barcode",
        metavar="[SYM:]DATA",
        help="Render a 1D barcode. Default symbology code128; prefix with e.g. "
        "'ean13:5901234123457' for others.",
    )
    src.add_argument(
        "--icon",
        type=Path,
        metavar="PATH",
        help="Render an icon (PNG/BMP/etc.) centered on the label, thresholded to 1-bit",
    )
    src.add_argument(
        "--list-models", action="store_true", help="List supported printer models and exit"
    )
    src.add_argument(
        "--part-info",
        metavar="PART",
        help="Look up a Brady label part number in the offline parts database and exit",
    )
    src.add_argument(
        "--identify",
        action="store_true",
        help="Query the printer's IEEE 1284 Device ID over USB and exit (no printing)",
    )
    src.add_argument(
        "--status",
        action="store_true",
        help="Query live printer status (substrate, ribbon, dimensions) and exit",
    )

    p.add_argument(
        "--model",
        default="BMP51",
        choices=sorted(PRINTER_MODELS),
        help="Printer model (default: BMP51)",
    )
    p.add_argument(
        "--transport",
        default="usb",
        choices=["usb"],
        help="Transport (default: usb; tcp/ble coming later)",
    )
    p.add_argument(
        "--cut",
        default="end-of-job",
        choices=sorted(CUT_MODES),
        help="Post-print cut behaviour (default: end-of-job)",
    )

    p.add_argument(
        "--width-in",
        type=float,
        default=None,
        help="Label width in inches. If omitted, auto-detects from loaded media via "
        "live status query (USB); falls back to 2.0 when no hardware is available.",
    )
    p.add_argument(
        "--height-in",
        type=float,
        default=0.5,
        help="Label height in inches (default: 0.5)",
    )
    p.add_argument(
        "--font-size",
        type=int,
        default=72,
        help="Font size in pixels for --text (default: 72)",
    )
    p.add_argument(
        "--align",
        choices=["left", "center", "right"],
        default="center",
        help="Horizontal text alignment for --text (default: center)",
    )
    p.add_argument(
        "--copies",
        type=int,
        default=1,
        metavar="N",
        help="Number of copies to print (default: 1). "
        "ESC/BMP has no wire-level copy count, so copies repeat the page(s) in the byte stream.",
    )
    p.add_argument(
        "--no-compress",
        dest="compress",
        action="store_false",
        default=True,
        help="Force uncompressed 1B 67 raster lines instead of RLE (debugging)",
    )

    p.add_argument(
        "--dry-run", action="store_true", help="Capture bytes instead of sending to the printer"
    )
    p.add_argument(
        "--hex-dump", action="store_true", help="With --dry-run: print a full hex+ASCII dump"
    )
    p.add_argument("--save", metavar="PATH", help="With --dry-run: write raw bytes to this file")
    p.add_argument(
        "--preview",
        action="store_true",
        help="Show the rendered label image in the system default viewer "
        "(implies --dry-run; nothing is sent to the printer)",
    )
    return p


def main(argv: list[str] | None = None) -> int:
    args = _build_parser().parse_args(argv)

    if args.list_models:
        for name in sorted(PRINTER_MODELS):
            m = PRINTER_MODELS[name]
            cut_names = ", ".join(c.name for c in m.cut_modes) or "—"
            print(f"{name:<8} {m.protocol.value:<10} {m.x_dpi}x{m.y_dpi} DPI   cut: {cut_names}")
        return 0

    if args.part_info:
        from pybrady.parts import dimensions_for_m21, find

        p = find(args.part_info)
        if p is None:
            print(f"part '{args.part_info}' not found in Brady parts database", file=sys.stderr)
            return 4
        print(f"name:      {p.name}")
        print(f"Y-number:  {p.ynumber}")
        print(f"flags:     0x{p.flags:08x}")
        dims = dimensions_for_m21(args.part_info)
        if dims is not None:
            print(f"width:     {dims.width} dots ({dims.width / 203:.3f} in @ 203 DPI)")
            h = "continuous" if dims.height == 0 else f"{dims.height} dots"
            print(f"height:    {h}")
            print(f"die-cut:   {dims.die_cut}")
            print(f"self-lam:  {dims.self_lam}")
            print(f"permasleeve: {dims.permasleeve}")
        return 0

    model = PRINTER_MODELS[args.model]

    if args.identify:
        if model.usb_vid is None or model.usb_pid is None:
            print(f"{args.model} has no known USB VID/PID", file=sys.stderr)
            return 2
        vid, pid = model.usb_vid, model.usb_pid

        async def _identify() -> None:
            async with UsbTransport(vid=vid, pid=pid) as t:
                d = await t.get_device_id()
                print(f"manufacturer:  {d.manufacturer}")
                print(f"model:         {d.model}")
                print(f"command-set:   {d.command_set}")
                if d.description:
                    print(f"description:   {d.description}")
                print(f"raw 1284 ID:   {d.raw}")

        asyncio.run(_identify())
        return 0

    if args.status:
        if model.usb_vid is None or model.usb_pid is None:
            print(f"{args.model} has no known USB VID/PID", file=sys.stderr)
            return 2
        vid, pid = model.usb_vid, model.usb_pid

        async def _status() -> None:
            async with UsbTransport(vid=vid, pid=pid) as t:
                printer = BradyPrinter(t, model=args.model)
                s = await printer.query_status()
                print(f"substrate:        {s.substrate_part or '(none)'}")
                print(f"ribbon:           {s.ribbon_part or '(none)'}")
                if s.media_width_thou:
                    print(f"media width:      {s.media_width_thou / 1000:.3f} in")
                if s.printable_width_thou:
                    print(f"printable width:  {s.printable_width_thou / 1000:.3f} in")
                if s.media_remaining_fraction is not None:
                    pct = s.media_remaining_fraction * 100
                    print(
                        f"media remaining:  {pct:.1f}% "
                        f"({s.media_remaining_units}/{s.media_capacity_units} ticks, runtime)"
                    )
                if s.media_remaining_chip_units is not None and s.media_capacity_units:
                    chip_pct = s.media_remaining_chip_units / s.media_capacity_units * 100
                    print(
                        f"chip last-read:   {chip_pct:.1f}% "
                        f"({s.media_remaining_chip_units}/{s.media_capacity_units} ticks)"
                    )

        asyncio.run(_status())
        return 0

    cut_mode = CUT_MODES[args.cut]

    if args.copies < 1:
        print(f"--copies must be >= 1 (got {args.copies})", file=sys.stderr)
        return 2

    # --preview implies --dry-run (we don't want to hit the printer).
    if args.preview:
        args.dry_run = True

    # Resolve label width. If the user didn't pass --width-in, try to auto-
    # detect from the loaded media via the bidi status query (USB only). If
    # that's unavailable or fails, fall back to 2.0" so dry-runs still work.
    if (
        args.width_in is None
        and not args.dry_run
        and args.transport == "usb"
        and model.usb_vid is not None
        and model.usb_pid is not None
    ):
        vid, pid = model.usb_vid, model.usb_pid

        async def _probe_width() -> float | None:
            async with UsbTransport(vid=vid, pid=pid) as t:
                printer = BradyPrinter(t, model=args.model)
                s = await printer.query_status()
                if s.printable_width_thou:
                    return s.printable_width_thou / 1000
                return None

        try:
            detected = asyncio.run(_probe_width())
        except Exception as e:
            print(f"warning: could not auto-detect label width: {e}", file=sys.stderr)
            detected = None
        if detected is not None:
            args.width_in = detected
            print(f"auto-detected printable width: {detected:.3f} in")
    if args.width_in is None:
        args.width_in = 2.0

    try:
        image = _build_source_image(args, dpi=model.x_dpi)
    except ImportError as e:
        print(f"{e}", file=sys.stderr)
        return 3

    if args.preview:
        image.show(title="pybrady preview")

    if args.dry_run:
        transport: AsyncTransport = CaptureTransport()
        asyncio.run(
            _print_async(transport, image, args.model, cut_mode, args.copies, args.compress)
        )
        assert isinstance(transport, CaptureTransport)
        print(summary(transport.data))
        if args.hex_dump:
            print()
            print(hex_dump(transport.data))
        if args.save:
            transport.save(args.save)
            print(f"\nsaved {len(transport.data)} bytes to {args.save}")
        return 0

    if args.transport != "usb":
        print(f"transport '{args.transport}' not yet implemented", file=sys.stderr)
        return 2

    if model.usb_vid is None or model.usb_pid is None:
        print(f"{args.model} has no known USB VID/PID", file=sys.stderr)
        return 2

    asyncio.run(
        _print_async(
            UsbTransport(vid=model.usb_vid, pid=model.usb_pid),
            image,
            args.model,
            cut_mode,
            args.copies,
            args.compress,
        )
    )
    print(f"printed{f' ({args.copies} copies)' if args.copies > 1 else ''}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
