# Ideas backlog

Short notes on features that came up in design discussions but aren't
worth building speculatively. The test for landing here is "we thought
about it, decided not yet, and want to remember the reasoning." When
a real user need surfaces, the note becomes a starting point rather
than a rediscovery exercise.

---

## Self-laminating cable wrap with alternating text direction

**Shape.** A long self-laminating cable label wraps around the cable
several times as the tape spirals. The text block repeats along the
length, and every other copy is rotated 180° so that *some* readable
copy of the text faces the viewer regardless of how the cable is
rotated (particularly useful for vertical cable runs you might walk
around).

**Implementation sketch.** A `cable_wrap_spiral(text, *, revolutions, alternate=True)`
variant of `cable_wrap`. Internally it's N halves instead of two, with
every-other half run through `.rotate(180)`. Roughly 20 lines on top
of the existing `_two_halves` helper in `pybrady/templates/cable.py`.

**Why not yet.**

| Cable OD           | Circumference | Visible band / rev |
|--------------------|---------------|---------------------|
| 0.25" (patch)      | 0.79"         | 0.79"               |
| 0.5" (trunk)       | 1.57"         | 1.57"               |
| 1.0" (bundle)      | 3.14"         | 3.14"               |

A two-line label like `sw1 e1/32` / `Zayo NNI` at a legible 10 pt font
needs ~1" of readable width per copy. Workable on trunk and bundle
cables where the self-lam printable zone typically runs 1.5"–2.5";
tight to pointless on patch cables. And for the common horizontal
cable run, the existing `cable_wrap` (same-direction duplicate) is
already readable from either side.

**Signals that would make this worth building.** A user describing a
real vertical-run use case (e.g. rack jumpers running up a rack side,
a dangling drop) where same-direction duplicate isn't enough, and
working with a cable wide enough to justify the extra copies.

---

## CUPS transport (multi-client Linux spooler)

**Shape.** On hosts where the printer is already configured as a
CUPS queue (desktop installs, shared office printers), a
higher-level transport that submits print data through CUPS rather
than talking to the device directly. Analogous to the Windows
spooler transport: queue-mediated, multi-client safe, coexists
with any other software using the same queue.

**Implementation sketch.** A `pybrady.transport.cups.CupsTransport`
using the `pycups` binding to libcups. Print path:
`cups.Connection().createJob(queue, title, options)` +
`startDocument` + `writeRequestData` + `finishDocument` with
`MimeType: "application/vnd.cups-raw"`. Bidirectional path for
status: `cupsSideChannelDoRequest` / `cupsBackChannelRead`
from within a job (same primitives CUPS backends use).

`pycups` is the only new dep and would live in a `cups` extra so
non-CUPS users don't pull it in.

**Caveat.** Bidirectional over CUPS is more awkward than over
`/dev/usb/lp*` — side-channel requests have their own message
format, and the queue mediation adds latency. Fine for print jobs,
less fun for interactive `query_status` use.

**Why not yet / signals.** The `/dev/usb/lp*` transport above
covers the "don't detach `usblp`" gap cleanly for the common
single-user desktop case. CUPS-specific coexistence is a narrower
need; worth building when a user has an actual queue-sharing
requirement that the char-device path can't satisfy.

---
