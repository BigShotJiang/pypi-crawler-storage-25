# Brady Printer Protocol — Complete Reverse Engineering Specification

## Purpose

This document is a self-contained specification for building a driver or library for Brady label printers. Brady has not published wire-level documentation for any of their products; everything here was reverse-engineered from Brady's own software.

**Primary source: the Brady Express Labels Android app** (`com.bradycorp.expresslabels`, .NET MAUI/Xamarin, tested against v3.1.0). Its managed assemblies ship packed inside `libassemblies.armeabi-v7a.blob.so` — a XABA store of XALZ-compressed DLLs — and were decompiled with `ilspycmd`. Protocol details for TCP/IP, Bluetooth Classic, and BLE come from this source.

**Secondary source: USBPcap traces of Windows Brady Workstation.** The Android app ships no USB transport, so the USB details in §2.4 were recovered by packet-capturing the Windows desktop software printing to real hardware (Brady BMP51).

§8 describes how to re-run the extraction end-to-end; §9 catalogues the artefacts it produces. Treat anything derived from Brady's software as their copyrighted material and do not redistribute it.

---

## 1. Architecture Overview

Brady printers use three distinct print protocols. Each printer model uses exactly one. All three are raster-only — the host renders the label to a monochrome bitmap and sends it as pixel data.

| Protocol | Generator Class | Models | Print Port (TCP) |
|----------|----------------|--------|-----------------|
| ESC/BMP | `PrinterLanguageGenerator_BMP51`, `_BMP61` | BMP51, BMP53, BMP61, M610, M710 | 9101 |
| JSON/PICL | `JSONPrintDataGenerator1` | M611, i5300, S3700, i7500, i4311, C1-30, MJ811 | 9100 |
| VGL/STX | `VglRlePrintDataGenerator5` (v5), `VglRlePrintDataGenerator6` (v6/Apollo) | M211, M511, MM100BT | BLE only |

Internal codenames: Edison (mobile app), Apollo (BLE chipset), PICL (bidirectional comms protocol), VGL (legacy command language).

---

## 2. Transport Layers

### 2.1 TCP/IP (Wi-Fi + Ethernet)

Standard TCP sockets. Settings: `NoDelay=true`, `KeepAlive=true`, 10-second connect timeout.

**Port assignments (from `DroidTcpConnectionClient`):**

| Printer | Print Data Port | PICL/BMP Session Port | Notes |
|---------|----------------|----------------------|-------|
| M611, i5300, S3700, i7500, i4311, C1-30, MJ811 | **9100** | 9102 | Print data goes on a NEW connection to 9100 |
| BMP61, BMP51/53, M710, M610 | **9101** | 9101 (same) | Print data and session share the connection |

**Critical finding:** For JSON/PICL printers, `DroidTcpConnectionClient.SendPrintData()` opens a brand new TCP connection to port 9100 to send the raw print job, then closes it. The PICL session on port 9102 is only for bidirectional property exchange (substrate info, ribbon colour, printer status). Fire-and-forget printing does NOT require a PICL session.

**Minimal TCP print sequence (PICL printers):**
```
1. TCP connect to printer_ip:9100
2. Write raw print job bytes (JSON envelope with magic header)
3. Optionally read 1-byte result (1 = success)
4. Close connection
```

**Minimal TCP print sequence (BMP printers):**
```
1. TCP connect to printer_ip:9101
2. Optionally send lock packet (BMP51/53 only): 1B 42 02 00 00 00 17 10
3. Write raw ESC print data
4. Close connection
```

### 2.2 Bluetooth Classic SPP

Uses standard SPP RFCOMM UUID: `00001101-0000-1000-8000-00805f9b34fb`

All data is wrapped in a 10-byte segment header (from `BluetoothProtocolHelper`):

```
Offset  Size  Field
0       1     Command: 0=OPEN, 1=CLOSE, 2=WRITE
1       1     Port: 1=PRINT, 2=PICL
2       2     Session ID (LE uint16)
4       4     Payload Length (LE uint32)
8       2     Checksum (LE uint16) — simple additive sum of all payload bytes mod 65536
```

**Print sequence over Bluetooth Classic:**
```
1. OPEN port 1 (PRINT): [00 01 00 00 00 00 00 00 00 00]
2. WRITE port 1: [02 01 <session_id_2LE> <payload_len_4LE> <checksum_2LE>] + print data
3. CLOSE port 1: [01 01 00 00 00 00 00 00 00 00]
```

**PICL session over Bluetooth Classic:**
```
1. OPEN port 2 (PICL): [00 02 <session_id_2LE> 00 00 00 00 00 00]
2. WRITE port 2: [02 02 <session_id_2LE> <payload_len_4LE> <checksum_2LE>] + PICL JSON data
```

### 2.3 BLE GATT (Apollo)

**GATT Service and Characteristics:**

| Name | UUID | Direction | Purpose |
|------|------|-----------|---------|
| Apollo Service | `0000fd1c-0000-1000-8000-00805f9b34fb` | — | Primary service; used as BLE scan filter |
| Session ID | `fc0018d8-cf12-46be-87b1-cce29b1e6c34` | Write | Session ownership (17 bytes) |
| Print Job | `7d9d9a4d-b530-4d13-8d61-e0ff445add19` | Write | Print data stream |
| PICL Request | `a61ae408-3273-420c-a9db-0669f4f23b69` | Write | PICL JSON requests, subscribe, set commands |
| PICL Response | `786af345-1b68-c594-c643-e2867da117e3` | Indicate | PICL JSON responses (incoming) |
| Response CCCD | `00002902-0000-1000-8000-00805f9b34fb` | Write | Standard CCCD — write ENABLE_INDICATION |

**BLE Connection Sequence:**
```
1. Scan with service UUID filter: 0000fd1c-0000-1000-8000-00805f9b34fb
2. Connect GATT (transport=LE, autoConnect=false)
3. Discover services
4. Get all 4 characteristics from Apollo service
5. Enable indications on PICL Response characteristic:
   - Write EnableIndicationValue (0x02 0x00) to CCCD descriptor (00002902-...)
6. Request MTU 517
   - Printer negotiates actual MTU (must be >= 50)
7. Write session ownership to Session ID characteristic:
   - M211, M610, MM100BT: [16-byte random GUID][0x01 on first connect, 0x00 otherwise]
   - C1-30 (password-protected): [password bytes][0x01]
   - M511, M611, S3700, i7500, i4311, MJ811: skip (ownership assumed)
8. Check write response:
   - GattStatus 0 = success (you own the printer)
   - GattStatus 19 = ownership taken away by another device
```

**BLE Data Chunking Protocol:**

All data written to any characteristic uses this 3-byte chunk header:

```
[1 byte] Flags:
    1 = continuation (more data follows)
    2 = flush staged data (intermediate checkpoint)
    3 = last chunk (final)
[2 bytes LE] Sequence number (starts at 0, increments per chunk)
[N bytes] Payload
```

Rules:
- Chunk payload size = MTU - 5 (ATT overhead) - 3 (header) = MTU - 8
- First chunk (seq=0) always uses write-with-response
- Flush and last chunks use write-with-response
- All other chunks use write-without-response (for throughput)
- Flush trigger: every 16 chunks (if printer's `FlushStagedData` flag is set) OR every 4096 bytes of cumulative data
- After flush, insert 10ms delay
- On write failure: retry up to 10 times with 100ms delay
- On GattStatus 17: retry with 5000ms delay
- On retry: reset sequence number and data position back to last successful flush point

**What goes to which characteristic:**

| Operation | Characteristic | Data Format |
|-----------|---------------|-------------|
| Print (M211/M511/MM100BT) | Print Job (`7d9d9a4d-...`) | Raw VGL6 framed data |
| Print (M611/S3700/i5300/i7500/i4311/MJ811) | Print Job (`7d9d9a4d-...`) | JSON/PICL print envelope |
| Print (M610/M710 via BLE) | Print Job (`7d9d9a4d-...`) | ESC/BMP data |
| Store-to-printer | PICL Request (`a61ae408-...`) | Store header + print data |
| PICL subscribe/get/set | PICL Request (`a61ae408-...`) | Compact or Full PICL JSON |
| Cut label | PICL Request | `{"PropertySetRequests":[{"ID":"0004","Value":"True"}]}` |
| Feed label | PICL Request | `{"PropertySetRequests":[{"ID":"0007","Value":"True"}]}` |
| Clear errors | PICL Request | `{"PropertySetRequests":[{"ID":"0025","Value":"False"}]}` |
| Set shutdown timeout | PICL Request | `{"PropertySetRequests":[{"ID":"0026","Value":"<minutes>"}]}` |

### 2.4 USB

Not implemented in the Android APK — the mobile app only ships Wi-Fi, Bluetooth Classic, and BLE transports. Windows Brady Workstation does support USB, and USBPcap captures from it were used to validate the details below against real hardware (Brady BMP51).

**Device class.** Brady printers enumerate as standard USB Printer Class (interface class `07`, subclass `01`, protocol `02` = bidirectional). The interface exposes one bulk-OUT endpoint (print-data sink) and one bulk-IN endpoint (status channel). The protocol bytes on the bulk-OUT endpoint are byte-for-byte identical to the TCP port 9101 stream, so for plain printing USB really is a dumb pipe. On Linux this means writing ESC/BMP to `/dev/usb/lp*` prints correctly with no special handling.

**Known VID/PIDs.**

| Model  | VID    | PID    |
|--------|--------|--------|
| BMP51  | `0e2e` | `000b` |

Other models are not yet confirmed; contributions welcome.

**IEEE 1284 GET_DEVICE_ID + bidirectional status.** The USB Printer Class requires a `GET_DEVICE_ID` class-specific control transfer (`bmRequestType=0xA1`, `bRequest=0x00`, `wValue=0`, `wIndex=<interface_number> << 8`, up to 1024 bytes) that returns an IEEE 1284 identification string of the form `MFG:Brady;MDL:BMP51-USB;CMD:BMP;...`. Beyond identification this request has a second, critical side-effect on BMP51 firmware: **it primes the bidirectional status channel.** Without issuing `GET_DEVICE_ID` at least once after claiming the interface, subsequent ESC/BMP subscribe commands (`1B 49`) are accepted silently and the bulk-IN endpoint returns nothing — the printer looks broken. Windows Brady Workstation always issues `GET_DEVICE_ID` immediately after opening the interface, which is why nobody notices; pybrady replicates that order (see `UsbTransport(init_bidi=True)`).

**Linux `usblp` kernel driver.** The in-kernel `usblp` driver auto-binds to any printer-class device and blocks libusb access. For pyusb-based transports, detach `usblp` on open (`dev.detach_kernel_driver(interface)`) and reattach on close. Leaving it detached across process exits is fine but unfriendly — `lp`/CUPS won't work again until it's reattached or the device is replugged.

**Linux udev permissions.** By default `/dev/bus/usb/...` is owned by root. Two standard options:

1. Ship a udev rule that tags the VID/PID with `TAG+="uaccess"`, granting ACL to the currently logged-in seat user (what `packaging/99-brady.rules` in this repo does). This is the right fit for desktop use — no group membership needed, permissions follow the session.
2. Assign the node to a group (`plugdev`, `lp`, etc.) and add the user to it. Works in headless contexts where `uaccess`/logind isn't available.

**Probe safety.** Several undocumented command bytes send the BMP51 into a hung state that requires a battery pull (remove AC, pop the battery, reinsert) to recover. One confirmed example: `1B 42 02 00 00 00 18 10` sent in isolation (i.e. without the preceding `17 10` lock) hangs the printer. When experimenting with unknown commands, always keep a reset path handy and prefer sequences captured from Brady's own software rather than synthesising new ones.

### 2.5 Windows driver architecture (open question; transports evaluated)

Validated against Brady Workstation 7.x on Windows 11 with a real BMP51
(VID `0e2e` / PID `000b`, FW 01.12) on 2026-04-13 using a combination of
USBPcap (URB-level wire capture), Sysinternals Procmon (user-mode syscall
trace), and static inspection of Brady Workstation's install tree.

**Partially-characterised finding (open question).** Brady Workstation
talks to the BMP51 bidirectionally without going through the Windows
print spooler, but the exact Win32-level path it uses is not yet fully
identified. What we know for sure:

1. `spoolsv.exe` issues zero syscalls during Workstation's
   bidi-traffic window — Procmon confirms the spooler is not on the
   hot path.
2. `BradyWorkstation.exe` loads `WinUSBNet.dll` (Thomas Bleeker's
   .NET wrapper around the WinUSB API, v1.0.23.204) from the GAC.
3. Brady's config at
   `C:\ProgramData\Brady Corp\Brady Workstation\Components\BNC\BradyInstalledDirectPrinters.xml`
   references the BMP51 by the usbprint-class device-interface path:
   ```xml
   <Enumed_PrinterName>PrintersDiscovery.USBPrintPrinters+SpDeviceInterfaceData</Enumed_PrinterName>
   <Enumed_DevicePath>\\?\usb#vid_0e2e&pid_000b#...#{28d78fad-5a12-11d1-ae5b-0000f803a8c2}</Enumed_DevicePath>
   ```
   The `PrintersDiscovery.USBPrintPrinters+SpDeviceInterfaceData`
   class name indicates the enumeration uses SetupAPI
   (`SP_DEVICE_INTERFACE_DATA`) against GUID
   `{28d78fad-5a12-11D1-ae5b-0000f803a8c2}` —
   `GUID_DEVINTERFACE_USBPRINT`.
4. USBPcap on the same session shows the BMP51's bulk-OUT endpoint
   `0x01` receiving a 2-byte `1B 49` (ESC I) subscribe, with a
   168-byte response on bulk-IN endpoint `0x82` about 300µs later.
   Polling cadence: ~500ms while the Workstation UI is focused. This
   is byte-identical to the protocol pybrady's `UsbTransport`
   implements.

**What we could not confirm.** Whether `WinUSBNet.dll` was loaded
*for the BMP51 specifically* or as a cross-model dependency used by
other Brady printers Workstation supports (e.g. M611, i5300). Static
inspection of `PrintersDiscovery.dll` and
`PrintEngine.PrinterServices.BradyVGLPrinters.dll` would be needed
to tell for certain which DLL drives the BMP51's bidi traffic.

**Validated failure modes** (tried 2026-04-13, all against a default
Brady-driver-bound BMP51 — i.e. the state the Brady installer leaves
the device in, not Zadig-swapped):

| Approach | Outcome | Why we think it failed |
|---|---|---|
| libusb (pyusb) without Zadig | `libusb_open` → `Operation not supported` | The default Brady driver is not WinUSB-compatible from libusb's perspective. libusb's Windows backend can only claim devices bound to WinUSB / libusb-win32 / libusbK. Zadig-bound WinUSB is the minimum requirement for `UsbTransport`. |
| libusb (pyusb) after Zadig → WinUSB | ✅ works, full bidi | Zadig swap replaces Brady's driver with generic WinUSB, which libusb happily claims. Cost: Brady Workstation can no longer see the printer until Zadig is reverted. |
| Windows print spooler: `WritePrinter` via pywin32 | ✅ prints successfully | Queue-based write works through the standard spooler. Useful for shared-printer / auditable scenarios. Coexists with Brady Workstation (no driver swap). |
| Windows print spooler: `ReadPrinter` for bidi (via ctypes → `winspool.drv`) | ❌ Win32 error 6 (`ERROR_INVALID_HANDLE`) | Brady's driver doesn't plumb a bidirectional channel through the spooler's port monitor. Workstation itself doesn't use this path. |
| Raw `CreateFile` + `WriteFile` on the usbprint device-interface path | ❌ `WriteFile` hangs indefinitely | The default Brady driver likely expects `FILE_FLAG_OVERLAPPED` + proper async completion (as WinUSB does), or a vendor-specific priming IOCTL before bulk I/O. Synchronous `WriteFile` blocks waiting for completion semantics that never arrive. |
| `DeviceIoControl` with `IOCTL_USBPRINT_GET_1284_ID` (0x220050) | ❌ `ERROR_INVALID_PARAMETER` (Win32 error 87) | The IOCTL number may be wrong, or Brady's driver doesn't implement it. The IEEE 1284 device ID is reachable via libusb's standard control transfer instead once Zadig is in place (`bmRequestType=0xA1, bRequest=0x00`). |

**What works today, pragmatic summary:**

- **`UsbTransport` (libusb) on Windows — requires one-time Zadig
  swap to WinUSB.** Full bidi, full print. Workstation becomes
  unusable until the swap is reverted via Device Manager.
- **`WindowsSpoolerTransport` on Windows — zero driver swap, print
  only.** Jobs go through the queue, coexists with Workstation. No
  status queries.
- **Bidi + no-Zadig + coexist-with-Workstation is still an open
  problem.** Reconstructing Workstation's exact I/O pattern requires
  a second pass of Procmon (this time not just filtered by process
  name, but also capturing all CreateFile/DeviceIoControl on paths
  starting with `\\?\usb` or `\Device\USB`), plus likely static
  decompilation of `PrintEngine.PrinterServices.BradyVGLPrinters.dll`
  to find the actual syscall sequence.

**168-byte subscribe-response byte layout (BMP51 FW 01.12).** Verified
byte-for-byte from a USBPcap capture of Workstation polling the
printer. Decoded fields match pybrady's
`BmpStatus`/`parse_bmp_status` in `protocol/esc_bmp_status.py`:

```
offset  size  field                        example value
0       2     length (big-endian)          00 a8          (168)
2       6     header / flags (undecoded)   0a 00 05 00 01 01
8       16   substrate part number        "MC-1500-595-WT-BK" + NUL pad
24      16   ribbon part number           "R6000" + NUL pad
40..    ...  (other fields; see parser)
```

**Reproducing these findings.** Tools used, all free:

- **USBPcap** (<https://desowin.org/usbpcap/>) — kernel-mode USB filter
  driver; captures URBs on a specific root hub to `.pcapng`. Reboot
  required after install.
- **Wireshark** (<https://www.wireshark.org/>) — opens the pcapng;
  also has CLI companion `tshark.exe` that works well from
  non-Windows scripts (e.g. WSL).
- **Sysinternals Procmon**
  (<https://learn.microsoft.com/en-us/sysinternals/downloads/procmon>)
  — captures user-mode syscalls + registry I/O. Exports to PML (native)
  or CSV (readable anywhere). Run elevated. Default filter excludes
  "Process Profiling" events, which is fine; don't add other
  exclusions that might hide the target process.

Minimum capture recipe for reproducing the Windows driver analysis:

1. Fully quit Brady Workstation (check the system tray; stop any
   Brady service from Task Manager).
2. Start Wireshark as Administrator, pick the USBPcap hub the BMP51
   is on (look at `USBPcapCMD.exe -l` output to find which hub
   lists the BMP51 as a child), start capture.
3. Start Procmon (elevated), filter by `Process Name = BradyWorkstation.exe`,
   start capture.
4. Launch Brady Workstation. Let it finish loading (~5s); open the
   print dialog once to trigger a status poll.
5. Stop both captures, save: Wireshark → pcapng, Procmon → PML + CSV.

Analysis hooks that save time:

- In the pcapng, filter `usb.endpoint_address == 0x01` (bulk OUT) and
  `usb.endpoint_address == 0x82` (bulk IN) — those are the two
  endpoints that carry all the interesting traffic.
- In the Procmon CSV, grep `BradyWorkstation.exe.*WinUSB` — confirms
  the WinUSB DLL load.
- Check `spoolsv.exe` operations other than `Process Profiling`. If
  there are none during the USBPcap activity window, the spooler is
  not on the hot path.

---

## 3. Protocol 1: ESC/BMP

Used by: BMP51, BMP53, BMP61, M610, M710

Source: `PrinterLanguageGenerator_BMP51`, `PrinterLanguageGenerator_BMP61` in `PE.Printing.dll`

### 3.1 Command Bytes

| Command | Bytes | Description |
|---------|-------|-------------|
| Job Start | `1B 58 00` | Begin print job |
| Page Start (BMP51) | `1B 4D <cut_mode> 00` | cut_mode: 0=EndOfJob, 1=EndOfLabel, 2=Never |
| Graphics Line | `1B 67 <len_lo> <len_hi> <raw_data>` | One raster line, uncompressed |
| RLE Line | `1B 68 <len_lo> <len_hi> <rle_data>` | One raster line, RLE compressed |
| Empty Lines | `1B 5A <count_lo> <count_hi>` | Skip N blank lines |
| Page End | `1B 45` | End of page |
| Job End | `1B 44` | End of print job |
| Subscribe | `1B 49` | Request status data (BMP protocol) |
| Lock (BMP51 TCP) | `1B 42 02 00 00 00 17 10` | Acquire exclusive access |
| Version Query (M710) | `71 56` ("qV") | Query firmware version; response is CSV |

### 3.2 Print Data Format

The bitmap is rendered at printer DPI (300×300 for all ESC printers). Each raster line is `ceil(width_pixels / 8)` bytes, MSB first (bit 7 = leftmost pixel), 1 = black, 0 = white.

**RLE encoding (for `1B 68` lines):** Bit-level run-length encoding, not byte-level. Each RLE byte encodes a run of pixels: bit 7 is the pixel colour (`1` = black, `0` = white), bits 6..0 are `count - 1` (so a single RLE byte encodes a run of 1–128 pixels). The decoded line has the same width as an uncompressed `1B 67` line — `ceil(width_pixels / 8)` bytes, MSB first — and the two forms are interchangeable on a per-line basis. Typical line-art labels compress ~4×. Empty lines can be further collapsed into a single `1B 5A` run.

### 3.3 Job Structure

```
[1B 58 00]                          -- job start
For each page:
  [1B 4D <cut_mode> 00]            -- page start (BMP51 variant)
  For each raster line:
    [1B 67 <len_lo> <len_hi> <data>] -- graphics line
    OR [1B 68 <len_lo> <len_hi> <rle>] -- RLE line
    OR [1B 5A <count_lo> <count_hi>]   -- empty lines
  [1B 45]                           -- page end
[1B 44]                             -- job end
```

### 3.4 BMP Protocol Handshake (Optional)

For bidirectional status (not required for fire-and-forget printing):

**M710/M610 boot sequence:**
```
1. Send: 71 56 ("qV")
2. Read response: CSV string "SN:xxx,FW:xxx,BT:xxx,WiFi:xxx,Y:xxx"
3. Send: 1B 49 (subscribe)
4. Read BMP status data response
5. Poll: re-send version query + subscribe every 3-60 seconds
```

**BMP51/53 boot sequence (TCP only):**
```
1. Send lock: 1B 42 02 00 00 00 17 10
2. Read 8-byte response
3. Send: 1B 42 02 00 00 00 18 10 1B 49 (lock + subscribe)
4. Read BMP status data response
```

**BMP51/53 status over USB.** The lock packet is not needed on USB. The required sequence is:

```
1. Control transfer: GET_DEVICE_ID (once per session — see §2.4)
2. Bulk-OUT: 1B 49
3. Bulk-IN: 168-byte status response
```

**168-byte BMP51 status response layout.** Little-endian throughout. Offsets given in hex.

| Offset | Size | Field | Notes |
|--------|------|-------|-------|
| `0x00` | 32 B | Substrate part (ASCII, NUL-padded) | e.g. `MC-1500-595-WT-BK`. Empty when no media. |
| `0x20` | 32 B | Ribbon part (ASCII, NUL-padded)    | e.g. `M61-R6200`. Empty when no ribbon. |
| `0x40` | 4 B  | Media width (thousandths of an inch) | Physical width of the loaded stock. |
| `0x44` | 4 B  | Printable width (thousandths of an inch) | Width actually imageable; ≤ media width. |
| `0x98` | 4 B  | Media capacity (ticks)             | Total units the cartridge holds when new. |
| `0x9C` | 4 B  | Media remaining (ticks, runtime)   | Decrements as labels print between capture events. |
| `0xA4` | 4 B  | Media remaining (ticks, chip last-read) | Value last written back to the cartridge chip; lags the runtime counter. |

Units are model-dependent; the stable cross-media metric is the fraction `remaining / capacity`. The BMP51 LCD's media-remaining bar matches the runtime counter to within one tick. AC-vs-battery, cover state, and clock/date were **not** found in this struct across six captures on two cartridges — clock is assumed host-side and Brady Workstation does not sync it.

Other offsets inside the 168 bytes are reserved / not-yet-decoded. See `src/pybrady/protocol/esc_bmp_status.py` for the authoritative parser.

---

## 4. Protocol 2: JSON/PICL

Used by: M611, i5300, S3700, i7500, i4311, C1-30, MJ811

Source: `JSONPrintDataGenerator1` in `PE.Printing.dll`

### 4.1 Print Job Wire Format

```
[16 bytes] Magic: 7F 42 EE 41 A9 1D 40 90 9B EC FF 7A 66 14 CC 22
[4 bytes LE] Payload length (of following JSON)
[JSON payload]
```

A print job consists of one **Job Header** packet followed by one **Page** packet per page.

### 4.2 Job Header JSON

```json
{
  "JobID": "<GUID-no-dashes-32-hex-chars>",
  "JobName": "<user-visible-name>",
  "JobCreator": "ExpressLabels",
  "JobTime": "<yyyyMMddHHmmss>",
  "NumberOfPages": <int>,
  "SubstratePart": "<part-number-string>",
  "JobType": "Print",
  "JobSource": "Mobile",
  "JobClientId": "<GUID-no-dashes>",
  "UserPostPrintOperation": "<cut-mode>"
}
```

`UserPostPrintOperation` values:
- `"SetByPrinter"` — printer decides
- `"Cut;0"` — cut after end of job
- `"Cut;1"` — cut after each label
- `"Cut;4"` — cut after every 4th label (etc.)

`JobType` can also be `"Store"` for store-to-printer operations.

### 4.3 Page JSON

```json
{
  "PrintFileName": "Page<n>.prn",
  "JobID": "<same-GUID-as-header>",
  "PageNumber": <0-based-int>,
  "LabelWidth": <thousandths-of-inch>,
  "LabelHeight": <thousandths-of-inch>,
  "Pages": {
    "Layers": [
      {
        "Bitmap": "<base64-of-LZ4-compressed-BMP>",
        "Compression": "lz4",
        "Color": null
      }
    ],
    "PrePrintOperations": [],
    "PostPrintOperations": [
      {"Cut": "Shear"}
    ]
  }
}
```

`PostPrintOperations` options:
- `{"Cut": "Shear"}` — standard cut
- `{"Separator": "DrawCutMarks"}` — print cut marks instead of cutting
- `{"SetByPrinter": "SetByPrinter"}` — printer decides

### 4.4 Bitmap Format

The bitmap in the `"Bitmap"` field is: **Standard Windows BMP → LZ4 compressed → base64 encoded**.

BMP specifications:
- 14-byte BMP file header (`BM` magic)
- 40-byte BITMAPINFOHEADER (Windows V3)
- 1-bit per pixel (monochrome)
- Top-down orientation (negative `biHeight` value)
- 2-colour palette: index 0 = black (0x000000), index 1 = white (0xFFFFFF)
- Row stride: DWORD-aligned (padded to multiple of 4 bytes)
- Resolution: printer DPI (typically 300×300)

**Encoding pipeline:**
```
1. Render label at printer DPI → PIL/Pillow 1-bit image
2. Create Windows BMP in memory:
   - File header (14 bytes)
   - Info header (40 bytes, biHeight = -height for top-down)
   - Palette (8 bytes: black + white)
   - Pixel data (DWORD-aligned rows)
3. LZ4 compress the ENTIRE BMP file (from offset 0)
   - Uses LZ4 block format (not frame format)
   - Specifically: the code calls LZ4Codec.Encode32() which uses the LZ4 block API
4. Base64 encode the compressed bytes
5. Place in the "Bitmap" field of the page JSON
```

**Note:** The LZ4 compression starts at byte 0 of the BMP, not at the pixel data. The entire BMP file (headers + palette + pixels) is compressed as one block.

### 4.5 PICL Session Protocol (Optional — for bidirectional status)

PICL uses a different GUID-based packet format on TCP port 9102:

```
[16 bytes] PICL GUID (see below)
[4 bytes LE] Payload length
[JSON payload]
```

**PICL GUIDs:**
- `B3 EC 09 9A 22 92 48 FA 83 D0 06 84 0B C9 91 02` — JSONIdentifierGUID (property exchange)
- `CD B4 69 80 7F D5 4C EB 86 32 59 13 62 61 8B 90` — JSONFileTransferGUID (file operations)

These are different from the print job magic (`7F 42 EE 41...`).

**PICL Boot Properties (queried at connection time):**

| PropertyName | PropertyId (GUID) |
|-------------|-------------------|
| Firmware Driver Name | F2EF2A72-D816-4D36-8F0D-905C3528A5D6 |
| Firmware Version | ACEB1224-1DAF-42A2-BBAA-4678D5D3C8DA |
| Printer Serial Number | AE2955D7-1AE3-4520-BB1C-1DC0C2B5A58B |
| Dots Per Inch | 890AF444-4F6B-44E9-B3F6-EA0239DE6317 |
| Post Print Accessory Type | 1CC7C409-31A2-4A09-B864-FCE3A6D15FE2 |

**PICL Session Flow (TCP port 9102):**
```
1. Connect TCP to port 9102
2. Send boot packet: [PICL GUID][4-byte len][JSON PropertyGetRequests]
3. Read response: [20-byte header][JSON PropertyGetResponses]
4. Parse: extract FirmwareVersion, DriverName, SerialNumber, DotsPerInch
5. Build subscribe request based on driver model
6. Send subscribe: [PICL GUID][4-byte len][JSON with SubscribeAllCurrentAndNewProperties:true]
7. Read initial property response
8. Enter read/write loop for ongoing monitoring
```

**PICL over BLE (Full PICL — M611, i5300, S3700, i7500, i4311, C1-30, MJ811):**

Outbound packets are LZ4-compressed before sending:
```
[1 byte] 0x8F
[1 byte] 0x99
[4 bytes LE] compressed_length + 4
[4 bytes LE] uncompressed_length
[LZ4 compressed data]
```

The uncompressed data is the standard PICL packet (16-byte GUID + 4-byte length + JSON), but with the first 20 bytes (GUID + length) stripped before compression. So `LZ4Codec.Encode32(origPacket, 20, origPacket.Length - 20)` — the JSON payload only is compressed.

---

## 5. Protocol 3: VGL/STX (Apollo)

Used by: M211, MM100BT (variant 6), M511 (variant 6)

Source: `VglRlePrintDataGenerator5`, `VglRlePrintDataGenerator6` in `PE.Printing.dll`

### 5.1 VGL/STX Command Map

| Command | Bytes | Description |
|---------|-------|-------------|
| SendPrintJobName | `02 4B 00 0A` + ASCII name + `0D` | Job name string |
| SendPrintJobNameEnd | `02 4B 00 0B` | End job name block |
| SendLabelPartName | `02 4B 00 09` + ASCII(max 10) + `0D` | Label part number |
| SendLabelPageSize | `02 4B 00 0C` + 4-digit W + 4-digit H | Label dimensions (ASCII decimal, dots) |
| SendLabelPrintableAreaSize | `02 4B 00 0D` + 4-digit W + 4-digit H | Printable area (ASCII decimal, dots) |
| SendLabelPrintableRegionOffset | `02 4B 00 0E` + 4-digit X + 4-digit Y | Offset (ASCII decimal) |
| SendSTXp | `02 70` + signed 3-byte ASCII | Always `+00` |
| SendSTXo | `02 6F` + signed 3-byte ASCII | Always `+00` |
| SendSTXO | `02 4F` + signed 3-byte ASCII | Always `+00` |
| SendSTXb | `02 62` + signed 3-byte ASCII | Always `+00` |
| SendSTXA | `02 41` | Control: used at page start and end |
| SendSTXQ | `02 51` | Control: used at page start |
| SendSTXa | `02 61` | Control: used at page start and end |
| SendSTXG | `02 47` | Control: used at page end |
| SendSTXI | `02 49 42 55 6C 62 6C` + page# ASCII + `0D` | Image data start ("IBUlbl" + page) |
| SendSTXITerminator | `FF FF 0D` | Image data end |
| SendStxM | `02 4D` + 1 byte | Cut mode: 0=EndOfJob, 1=EndOfLabel, 2=Never |
| SendStxW | `02 57` + 1 byte | Trailing whitespace: 0=no, 1=yes |
| SendStxD | `02 44` + signed ASCII | Document count |
| SendStxC | `02 43` + signed ASCII | Copy count |
| SendStxc | `02 63` + 1 byte | Collate: 0=no, 1=yes |
| SendXCURS | `58` + 2-byte LE | X cursor position (pixels) |
| SendYCURS | `59` + 2-byte LE | Y cursor position (line number) |
| SendDotRow | `80` + 1-byte count + raw data | Uncompressed raster line |
| SendRleRow | `81` + 1-byte count | RLE raster line header |
| SendLineRepeat | `00 00 FF` + 1-byte count | Repeat previous line (max 255) |

### 5.2 Number Encoding (ConvertNum)

Numbers are encoded as ASCII decimal digits, big-endian, optionally sign-prefixed (`+` or `-`), zero-padded to the field width.

Examples:
- 4-digit width: `0150` for 150 dots
- Signed 3-byte: `+00` for zero

### 5.3 RLE Compression (VGL)

Bit-level run-length encoding. Each byte encodes one run:
- Bit 7 (0x80): colour — 0=white, 1=black
- Bits 6-0 (0x7F): run length minus 1 (so 0x00 = 1 pixel, 0x7F = 128 pixels)

Runs longer than 128 pixels are split into multiple bytes.

### 5.4 VGL6 Binary Framing (Apollo/BLE)

VGL variant 6 adds a binary frame around the VGL command stream:

```
[4 bytes LE] Total page count (written once at the start of the entire job)
Per job:
  [4 bytes LE] Total payload size (backfilled after all commands generated)
  [4 bytes LE] Offset to job name within the payload (backfilled)
  ... VGL STX command stream ...
```

The "backfilled" values mean the generator writes placeholder zeros, generates all commands, then seeks back to fill in the actual sizes/offsets.

### 5.5 VGL Page Structure

```
Per page:
  STXa (02 61)
  STXp +00 (02 70 2B 30 30)
  STXo +00 (02 6F 2B 30 30)
  STXO +00 (02 4F 2B 30 30)
  STXb +00 (02 62 2B 30 30)
  STXA (02 41)
  STXa (02 61)
  STXQ (02 51)
  SendLabelPageSize (02 4B 00 0C + 4-digit W + 4-digit H)
  SendLabelPrintableAreaSize (02 4B 00 0D + 4-digit W + 4-digit H)
  SendLabelPrintableRegionOffset (02 4B 00 0E + 4-digit X + 4-digit Y)
  SendLabelPartName (02 4B 00 09 + ASCII + 0D)
  STXa (02 61)
  StxM <cut_mode> (02 4D <mode>)
  StxW 01 (02 57 01)
  StxD +01 (02 44 2B 30 31)
  StxC +01 (02 43 2B 30 31)
  SendPrintJobName (02 4B 00 0A + name + 0D)
  SendPrintJobNameEnd (02 4B 00 0B)
  STXa (02 61)
  STXa (02 61)
  SendSTXI (02 49 42 55 6C 62 6C + page# + 0D)
  XCURS 0 (58 00 00)
  YCURS 0 (59 00 00)

  For each raster line:
    If line is identical to previous: SendLineRepeat (00 00 FF <count>)
    Else if RLE is smaller: SendRleRow (81 <rle_byte_count>) + RLE data
    Else: SendDotRow (80 <raw_byte_count>) + raw data

  SendSTXITerminator (FF FF 0D)
  STXA (02 41)
  STXG (02 47)
```

### 5.6 Compact PICL (BLE — M211, M511, MM100BT)

These printers don't use the full GUID-based PICL protocol. Instead they use a "compact" format with short hex string property IDs.

**Compact PICL GUID:** `96 C2 F7 4A 1D 21 42 32 86 78 20 EF E9 7B C2 D3`

**Packet format:** `[16-byte GUID][4-byte LE length][JSON]`

**Subscribe request (M211):**
```json
{"PropertySubscribeRequests":[
  {"ID":"0006"},{"ID":"0005"},{"ID":"000A"},{"ID":"001C"},
  {"ID":"0021"},{"ID":"0027"},{"ID":"0025"},{"ID":"0009"},
  {"ID":"0029"},{"ID":"0001"},{"ID":"0024"},{"ID":"0026"},
  {"ID":"000C"},{"ID":"000D"},{"ID":"000E"},{"ID":"000F"},
  {"ID":"0012"},{"ID":"0013"},{"ID":"0014"},{"ID":"0015"},
  {"ID":"002A"},{"ID":"0016"},{"ID":"001F"},{"ID":"0020"},
  {"ID":"009D"}
]}
```

**Subscribe request (M511):**
```json
{"PropertySubscribeRequests":[
  {"ID":"0006"},{"ID":"0005"},{"ID":"000A"},{"ID":"001C"},
  {"ID":"0021"},{"ID":"0027"},{"ID":"0025"},{"ID":"0009"},
  {"ID":"0029"},{"ID":"0001"},{"ID":"0024"},{"ID":"0026"},
  {"ID":"000C"},{"ID":"000D"},{"ID":"000E"},{"ID":"000F"},
  {"ID":"0016"},{"ID":"0066"},{"ID":"0061"},{"ID":"005A"},
  {"ID":"004D"},{"ID":"001F"},{"ID":"0020"},{"ID":"0085"}
]}
```

**Response format:**
```json
{"PropertyGetResponses":[
  {"ID":"0006","Value":"False","Status":"Successful"},
  {"ID":"000C","Value":"50","Status":"Successful"}
]}
```

**Set command format:**
```json
{"PropertySetRequests":[{"ID":"0004","Value":"True"}]}
```

---

## 6. Compact PICL Property ID Map

| ID | Property Name | Type | Description |
|----|--------------|------|-------------|
| 0001 | BatteryChargeStatus | string | Battery level |
| 0004 | CutButton | set-only | Trigger manual cut |
| 0005 | CutError | bool | Cutter jam/error |
| 0006 | FatalError | bool | Unrecoverable error |
| 0007 | FeedButton | set-only | Trigger media feed |
| 0009 | PrintJobError | bool | Current job failed |
| 000A | MediaIsInvalid | bool | Unrecognized media |
| 000C | SubstratePrintableWidth | int | Printable width in dots |
| 000D | SubstrateLabelLinerLeftOffset | int | Left offset in dots |
| 000E | SubstratePrintableHeight | int | Printable height in dots (0 = continuous) |
| 000F | SubstrateVerticalOffset | int | Vertical offset in dots |
| 0012 | SubstrateIsBlackStriped | int | Black mark sensing |
| 0013 | SubstrateIsDieCut | bool | Die-cut labels |
| 0014 | SubstrateIsPermasleeve | bool | Permasleeve media |
| 0015 | SubstrateIsSelfLam | bool | Self-laminating |
| 0016 | SubstrateRemainingPercent | int | Media remaining % |
| 001C | SubstrateRemainingOut | bool | Very low media |
| 001F | JobPrintingComplete | bool | Last job done |
| 0020 | FirmwareVersion | string | Firmware version string |
| 0021 | LowPowerError | bool | Low battery |
| 0024 | BatteryACConnected | bool | Charging |
| 0025 | SubstrateOutError | bool | Media exhausted |
| 0026 | ShutdownTimeoutInMins | int | Auto-off timer (settable) |
| 0027 | DismissibleError | bool | User-clearable error |
| 0029 | PrintJobIdAndStatus | string | Format: `"<jobid>:<status>"` where status = `Successful` or `Failed` |
| 002A | SubstrateUniqueId | int | Unique substrate ID chip value |
| 004D | MediaYNumber | int | Y-number of installed media |
| 005A | LeadingEdgeError | bool | M511 only |
| 0061 | SubstrateStallError | bool | M511 only |
| 0066 | HeadOpenError | bool | M511 only |
| 0085 | PrinterAnalyticsSupported | bool | M511 only |
| 0099 | PrinterAnalyticsLifetime | int | Lifetime stats |
| 009A | PrinterAnalyticsSnapshot | int | Snapshot stats |
| 009D | KnockoffCount | int | Counterfeit media detections |

---

## 7. Printer Specifications

From `PrinterData.xml` (embedded resource in `PE.Ble.dll`).

### 7.1 DPI and Dimensions

| Model | xDPI | yDPI | MinLength (in) | MaxMonoLength (in) | MaxWidth (in) | PrintableWidth (in) | Header (in) | Trailer (in) | Datum |
|-------|------|------|---------------|-------------------|--------------|--------------------|-----------|-----------| ------|
| M211 | 203 | 203 | 1.0 | 36 | 0.75 | 0.63 | 0.435 | 0.435 | Left |
| BMP51/53 | 300 | 300 | 0.375 | 39 | 0 | 0 | 0 | 0 | Left |
| BMP61 | 300 | 300 | 0.375 | 40 | 0 | 0 | 0 | 0 | Left |
| M610 | 300 | 300 | 0.375 | 40 | 0 | 0 | 0 | 0 | Left |
| M710 | 300 | 300 | 0.375 | 40 | 0 | 0 | 0 | 0 | Left |
| M611 | 300 | 300 | 0.375 | 40 | 0 | 0 | 0 | 0 | Left |
| M511 | 300 | 300 | 0.375 | 36 | 1.5 | 1.44 | 0 | 0 | Left |
| S3700 | 300 | 300 | 0.25 | 100 | 0 | 0 | 0 | 0 | Left |
| i5300-300 | 300 | 300 | 0.25 | 60 | 0 | 0 | 0 | 0 | Left |
| i5300-600 | 600 | 600 | 0.25 | 60 | 0 | 0 | 0 | 0 | Left |
| i7500 | 300 | 300 | 0.25 | 60 | 0 | 0 | 0 | 0 | Centre |
| i4311 | 300 | 300 | 0.25 | 60 | 4.25 | 4.15 | 0 | 0 | Left |
| C1-30 | 300 | 300 | 0 | 0 | 0 | 0 | 0 | 0 | Left |
| MJ811 | 600 | 1200 | 0.5 | 40 | 0 | 0 | 0 | 0 | Left |

Note: values of 0 for MaxWidth/PrintableWidth mean the printer determines these from the installed media (queried via PICL at runtime).

### 7.2 Model → Protocol → Transport Map

| Printer | Protocol | Print Port (TCP) | Session Port (TCP) | BT Classic | BLE | BLE PICL Type |
|---------|----------|-----------------|-------------------|-----------|-----|---------------|
| BMP61 | ESC/BMP | 9101 | 9101 | No | No | — |
| BMP51/53 | ESC/BMP | 9101 | 9101 | Yes (SPP) | No | — |
| M710 | ESC/BMP | 9101 | 9101 | No | Yes | BMP |
| M610 | ESC/BMP | 9101 | 9101 | No | Yes | BMP |
| M611 | JSON/PICL | 9100 | 9102 | Yes (SPP) | Yes | Full PICL |
| i5300 | JSON/PICL | 9100 | 9102 | Yes (SPP) | Yes | Full PICL |
| S3700 | JSON/PICL | 9100 | 9102 | No | Yes | Full PICL |
| i7500 | JSON/PICL | 9100 | 9102 | No | Yes | Full PICL |
| i4311 | JSON/PICL | 9100 | 9102 | No | Yes | Full PICL |
| C1-30 | JSON/PICL | 9100 | 9102 | No | Yes | Full PICL (password) |
| MJ811 | JSON/PICL | 9100 | 9102 | No | Yes | Full PICL |
| M211 | VGL/STX v6 | — | — | No | Yes | Compact PICL |
| M511 | VGL/STX v6 | — | — | No | Yes | Compact PICL |
| MM100BT | VGL/STX v6 | — | — | No | Yes | Compact PICL |

### 7.3 Printer Type Capabilities

| Model | Cut Options | Store | Analytics | XY Cutter | Full Colour | 180° Rotate |
|-------|-------------|-------|-----------|-----------|-------------|-------------|
| BMP61 | EOL, EOJ, Never | No | No | No | No | No |
| BMP51/53 | EOL, EOJ | No | No | No | No | No |
| M611 | EOL, EOJ, Never | Yes (FW≥1.3.809354) | Yes | No | No | No |
| i5300 | EOL, EOJ, Never | Yes | No | No | No | No |
| M211 | EOL only | No | No | No | No | No |
| M710 | EOL, EOJ, Never | Yes | No | No | No | No |
| M610 | EOL, EOJ, Never | Yes | No | No | No | No |
| M511 | None | No | Yes | No | No | No |
| S3700 | EOL, EOJ, Never | No | Yes | Yes | No | No |
| i7500 | EOL, EOJ, Never | Yes | Yes | No | No | No |
| C1-30 | Never only | No | Yes | No | No | No |
| MJ811 | EOL, EOJ, Never | No | No | No | Yes (inkjet) | No |
| i4311 | EOL, EOJ, Never | Yes | Yes | No | No | Yes |

### 7.4 BLE Discovery

BLE scan filter: service UUID `0000fd1c-0000-1000-8000-00805f9b34fb`

Model is determined from the BLE device name (from `BleDiscoveryProvider.BleScanCallback`):

| Device Name Contains | DriverName | IsPiclEnabled | IsBmpProtocol | Session Ownership |
|---------------------|-----------|---------------|---------------|-------------------|
| M211 | M211 | false | false | GUID + flag |
| MM100BT | MM100BT | false | false | GUID + flag |
| M511 | M511 | false | false | Not needed |
| M611 | M611 | true | false | Not needed |
| M710 | M710 | false | true | Not needed |
| M610 | M610 | false | true | GUID + flag |
| S3700 | S3700 | true | false | Not needed |
| i7500 | i7500 | true | false | Not needed |
| MJ811 | MJ811 | true | false | Not needed |
| i4311 | i4311 | true | false | Not needed |
| C1-30 | C1-30 | true | false | Password + flag |

Active BLE connection count is extracted from manufacturer-specific data byte[2] bits 2-5 (for M611 and i4311).

C1-30 ownership flag is at manufacturer-specific data byte[2] bit 1.

---

## 8. APK Data Extraction Pipeline

The following pipeline extracts all variable data (printer models, consumable part numbers, fonts, templates) from a Brady Express Labels APK. This should be automated as a Python script for re-running when Brady releases updates.

### 8.1 Pipeline Steps

```
Input: Brady Express Labels XAPK (from APKPure, APKMirror, etc.)

Step 1: XAPK → APK
  - XAPK is a ZIP; extract the largest .apk file inside

Step 2: APK → Assets
  - Unzip APK
  - Copy assets/Fonts/*.ttf → output/fonts/
  - Copy assets/Data/LayoutLibrary/ → output/layouts/

Step 3: APK → .NET Assembly Blob
  - Extract lib/armeabi-v7a/libassemblies.armeabi-v7a.blob.so
  - This is an ELF file containing the XABA assembly store

Step 4: XABA Blob → .NET DLLs
  - Parse ELF to find .payload_N sections (N=0,1,2...)
  - Each payload section is an XABA store with:
    - 4-byte magic: "XABA"
    - 4-byte version, 4-byte count, 4-byte padding
    - For each assembly: name hash (u64), data offset (u32),
      data size (u32), debug data offset (u32), debug data size (u32),
      config data offset (u32), config data size (u32)
    - Assembly data is XALZ-compressed (magic "XALZ", 4-byte index,
      4-byte uncompressed size, then LZ4 block data)
  - Decompress each assembly → output/assemblies/

Step 5: Extract Embedded Resources from DLLs
  - Target DLLs and resources:
    a. PE.Ble.dll (also named "EdisonMobile.Full"):
       - EdisonMobile.Full.Data.PrinterData.xml → output/PrinterData.xml
       - EdisonMobile.Full.Data.BradyParts.bin → output/BradyParts.bin
    b. PE.MonitoringEngine.dll:
       - PE.MonitoringEngine.PropertyDBs.PICLBootProperties.json
       - PE.MonitoringEngine.PropertyDBs.MainEditor.PICLBidiProperties.json
       - PE.MonitoringEngine.PropertyDBs.PerMainAndApps.PICLBidiProperties.json
  - Extraction method: use pefile + dnfile Python libraries
    - Read ManifestResource table for resource names and offsets
    - Calculate absolute offset = CLR resources RVA file offset + row offset
    - Read 4-byte LE length prefix, then read that many bytes of data

Step 6: Parse PrinterData.xml
  - Extract per-model: DPI (xUPI/yUPI), page size extents, discovery
    prefixes, capabilities, MaxPortWriteByteCount, etc.
  - Output: output/printer_models.json

Step 7: Parse BradyParts.bin
  - Header: ">Brady-PartsDb-Optimized-01.01-" (64 bytes + 0x04)
  - Part records: [1-byte name length][name string][1-byte Y-number length]
    [Y-number string (digits only)][4-byte LE flags]
  - Scan entire file for records matching part name pattern
  - Output: output/parts_database.json (part name → Y-number mapping)

Step 8: Diff Against Previous Version (optional)
  - Compare new printer_models.json against previous to detect:
    - New printer models added
    - DPI or capability changes
    - New part numbers in parts_database.json
  - Output: output/changelog.txt
```

### 8.2 Dependencies

```
pefile          # PE header parsing
dnfile          # .NET metadata parsing
lz4             # XALZ decompression
```

### 8.3 Key Files to Monitor for Changes

| File | What changes | Impact |
|------|-------------|--------|
| PrinterData.xml | New printer models, DPI values, capabilities | Add to driver's model database |
| BradyParts.bin | New label SKUs, Y-number assignments | Update parts lookup table |
| PICL property JSONs | New status/control properties | Add to PICL session handler |
| PE.Printing.dll | Protocol changes, new commands | Must decompile and review |
| PE.Ble.Full.dll | New BLE models, GATT changes | Must decompile and review |
| assets/Fonts/ | New or updated Brady fonts | Copy to driver's font directory |

### 8.4 Versioning and Monitoring

The APK version is in `AndroidManifest.xml` → `android:versionName`. Compare against the last extracted version to decide whether re-extraction is needed.

For automated monitoring: APKPure and APKMirror have RSS feeds and APIs for version tracking. Check `com.bradycorp.expresslabels` periodically.

---

## 9. Extracted Data Files

These are the artefacts §8's pipeline produces. They are not shipped with pybrady — they are Brady's copyrighted material and must not be redistributed. The subsections below describe what each artefact *contains* so pybrady (and other re-implementations) can derive compact summary forms from it — for example the gzipped `brady_parts.json.gz` bundled with this package is a re-encoding of the relevant subset of `BradyParts.bin`.

### 9.1 PrinterData.xml (34 KB)

Complete printer model database. Contains all DPI values, page size extents, discovery prefixes (for Wi-Fi/BT auto-detection), and capability flags.

### 9.2 BradyParts.bin (900 KB) → BradyParts_extracted.json (1.5 MB)

Binary parts database. Header: `>Brady-PartsDb-Optimized-01.01-`. Contains 13,426 part-to-Y-number records covering 8,257 unique Brady label part numbers across 80+ product families.

The JSON extraction contains records of the form:
```json
{"name": "M21-500-403", "ynumber": "Y4939593", "flags": "0x00000000", "offset": 646025}
```

The binary also contains physical dimensions per part group (width, height, printable area, offsets) but those are in a complex section that would require further parsing. For M21-series parts, see the IdentifiedParts table below. For all other printers, dimensions are queryable via PICL at runtime (properties 000C, 000D, 000E, 000F).

### 9.3 M21-Series IdentifiedParts Table (from PE.Ble.Full.dll)

24 M21-series part definitions with exact dimensions (in dots at 203 DPI). These are used for offline part identification when PICL substrate query returns no unique ID.

| Part Name(s) | Y-Number(s) | Width | Height | LeftOffset | VertOffset | DieCut | SelfLam | PermaSleeve |
|-------------|-------------|-------|--------|-----------|-----------|--------|---------|-------------|
| M21-11-427 | Y4918675 | 37 | 50 | 9 | 0 | Yes | Yes | No |
| M21-11-499, M21-7-423 | Y4918682, Y4918687 | 50 | 75 | 7 | 0 | Yes | No | No |
| M21-125-C-342, -YL | Y4900592, Y4900578 | 21 | 0 | 0 | 0 | No | No | Yes |
| M21-1250-427 | Y4900577 | 50 | 0 | 0 | 0 | No | Yes | No |
| M21-131-461, -499, M21-17-423 | Y5027106, Y4918683, Y4918688 | 50 | 100 | 7 | 0 | Yes | No | No |
| M21-18-427 | Y4918676 | 37 | 100 | 9 | 0 | Yes | Yes | No |
| M21-136-499, M21-30-423 | Y4918685, Y4918690 | 75 | 150 | 0 | 0 | Yes | No | No |
| M21-137-423, -499 | Y4918691, Y4918686 | 75 | 200 | 0 | 0 | Yes | No | No |
| M21-1500-427 | Y4900579 | 50 | 0 | 23 | 0 | No | Yes | No |
| M21-18-423, -499 | Y4918689, Y4918684 | 75 | 100 | 0 | 0 | Yes | No | No |
| M21-187-C-342, -YL | Y4900580, Y4900581 | 31 | 0 | 0 | 0 | No | No | Yes |
| M21-250-414, -423, -430, -430-WT-CL, -595-WT, -595-YL | 6 Y-numbers | 25 | 0 | 0 | 0 | No | No | No |
| M21-250-C-342, -YL | Y4900607, Y4900608 | 41 | 0 | 0 | 0 | No | No | Yes |
| M21-375-423 thru -7425 (17 parts) | 17 Y-numbers | 37 | 0 | 8 | 0 | No | No | No |
| M21-375-499-TB | Y4900615 | 37 | 0 | 8 | 0 | No | No | No |
| M21-375-C-342, -YL | Y4900627, Y4900628 | 60 | 0 | 0 | 0 | No | No | Yes |
| M21-500-403 thru -7425 (20 parts) | 20 Y-numbers | 50 | 0 | 9 | 0 | No | No | No |
| M21-500-499-TB | Y4900635 | 50 | 0 | 9 | 0 | No | No | No |
| M21-750-499 thru -7425 (20 parts) | 20 Y-numbers | 75 | 0 | 0 | 0 | No | No | No |
| M21-750-427 | Y4900649 | 37 | 0 | 37 | 0 | No | Yes | No |
| M21-89-427 | Y4918678 | 50 | 50 | 7 | 0 | Yes | No | No |
| M21R0-206-427 | Y4918680 | 50 | 70 | 7 | 70 | Yes | No | No |
| M21RO-207-427 | Y4918681 | 50 | 110 | 7 | 110 | Yes | No | No |

Height=0 means continuous media (no die-cut; user specifies length). All dimension values are in dots at 203 DPI.

### 9.4 PICL Property Files

Three JSON files define every GUID-based property used in full PICL sessions:

- `PICL_BootProperties.json` — 5 boot query properties
- `PICL_MainEditor_BidiProperties.json` — 22 subscribable properties (S3700 variant)
- `PICL_PerMainAndApps_BidiProperties.json` — 33 subscribable properties (all other PICL printers)

Each entry has: ComponentId, GroupId, PropertyId (GUID), PropertyName, IsBidiProperty.

### 9.5 Brady Fonts (8 TTF files)

- Brady Alpine.ttf, Brady Alpine Bold.ttf
- Brady Fixed Width.ttf, Brady Fixed Width Bold.ttf
- Brady Fixed Width Condensed.ttf, Brady Fixed Width Condensed Bold.ttf
- Brady Fixed Width Condensed Italic.ttf, Brady Fixed Width Condensed Bold Italic.ttf

These are the fonts used by the Brady Express Labels app for label rendering. Install on the Linux system for matching output.

### 9.6 LayoutLibrary.xml

An index — not the templates themselves — of 150+ pre-built label designs: pipe markers, ANSI safety signs, IIAR ammonia labels, wire markers, etc. Each entry is a GUID + filename + region size + localisation tags pointing at a `.BWS` file that is delivered separately (either downloaded on demand by the Android app, or shipped with Brady Workstation's add-ins). The `.BWS` container itself is documented in §11.

---

## 10. Key Warnings and Edge Cases

1. **LZ4 block format, not frame format.** The Brady code uses `LZ4Codec.Encode32()` which is the LZ4 block API. In Python, use `lz4.block.compress(data, store_size=False)` — NOT `lz4.frame.compress()`. The frame format adds a different header that the printer will not understand.

2. **BMP top-down orientation.** The bitmap MUST use negative `biHeight` for top-down row order. If you use positive height (bottom-up), the label will print upside down.

3. **BMP palette order.** Index 0 = black (0x000000), index 1 = white (0xFFFFFF). This is the opposite of what some imaging libraries default to. Verify: a "1" bit should mean white (paper), a "0" bit should mean black (print).

4. **Label dimensions in JSON are thousandths of an inch.** A 2" × 1" label → `"LabelWidth": 2000, "LabelHeight": 1000`.

5. **The i7500 uses Centre datum.** All other printers use Left datum. This affects how the printable area is positioned on the label.

6. **PICL compact property IDs are 4-character hex strings**, not integers. They are transmitted as JSON string values: `"ID": "000C"`, not `"ID": 12`.

7. **BLE MTU negotiation.** Request MTU 517 but accept what the printer gives. Minimum usable MTU is 50. Chunk size = MTU - 8. If MTU is too small, connection fails.

8. **BLE session ownership for M211/M610/MM100BT.** If another phone/device has the printer, your ownership write will fail with GattStatus != 0. The printer is single-owner. You must wait for the other device to disconnect or clear session.

9. **BMP51/53 lock packet.** On TCP, BMP51/53 require a lock packet (`1B 42 02 00 00 00 17 10`) before printing. Over Bluetooth, the lock is not needed.

10. **MaxPortWriteByteCount.** For i5300-300 (65355), i5300-600 (65535), i7500 (65535), and MJ811 (600), TCP writes should be chunked to this size. Other printers have 0 (unlimited).

11. **The S3700 PICL subscribe list is different** from all other PICL printers. The code uses `GetMainEditorPiclBidiProperties()` for S3700 and `GetPerMainAndAppsPiclBidiProperties()` for everything else.


---

## 11. Brady UDF v2 Label Format (`.BWS` / `.BWT`)

Brady Workstation stores label designs in a proprietary binary container produced by the `UdfSerializer` class in `PrintEngine.UDF.dll`. The container is shared by two extensions:

| Extension | Meaning | Typical location |
|-----------|---------|------------------|
| `.BWS` | A label the user saved — a filled-in "instance" of a template. | `C:\Users\Public\Documents\Brady Corp\Brady Workstation\` or `C:\Users\<user>\Documents\...` |
| `.BWT` | A Brady-shipped template — the starting point for a new label. | `C:\ProgramData\Brady Corp\Brady Workstation\Addins\<app>\Templates\<printer>\<category>\...` |

Both extensions share the same wire format. The authoritative parser in pybrady is `pybrady.templates.brady_bws`; this section documents what that parser knows, recovered from the decompiled `UdfSerializer`, `StoreBase`, `Design`, and `UdfBinaryReader` classes.

### 11.1 Wire-format conventions

All binary fields use standard .NET `BinaryWriter` / `BinaryReader` conventions:

* **Strings**: 7-bit LEB128 byte-length prefix followed by UTF-8 bytes. (Both `<128 B` single-byte prefixes and multi-byte prefixes occur — the `PartInfo` XML blob in the header routinely trips the multi-byte path.)
* **Integers**: little-endian. Widths that appear include `Int32` (schema version, counters), `Int64` (thumbnail length), and `UInt32` (Store length prefixes and FileIndex offsets).
* **GUIDs**: 1 byte of length followed by that many bytes (always 16 in practice).
* **Streams**: `Int64` byte length followed by that many bytes (used for the embedded thumbnail PNG).

### 11.2 File layout

```
<string "brcudf2bin">              magic
<int32 N>                           header entry count
N x (<string key>, <string value>)  metadata dictionary (see §11.3)
FileIndex                           length-prefixed Store (44 bytes)
DesignStore                         length-prefixed Store (§11.4)
RegionStore                         length-prefixed Store
LabelStore                          length-prefixed Store
[GroupStore]                        present only if FileIndex.GroupStore != 0
[WiremarkStore]                     present only if FileIndex.WiremarkStore != 0
PagePropertiesStore                 length-prefixed Store
[LabelInfoFor110BlockStore]         obsolete; present only if != 0
ObjectStore                         length-prefixed Store; holds text/QR/barcode/image elements
[DataStore]                         obsolete; present only if != 0
[AppDataStore]                      present only if UdfSchemaVersion >= 38 (template variables)
```

Every `Store` begins with a `UInt32` total-length prefix that counts itself, so parsers can skip past any Store without understanding its interior.

### 11.3 Header dictionary

The top-level metadata dict after the magic has changed slightly over Brady Workstation versions; the following keys have been observed in files produced by recent builds (not an exhaustive list):

| Key | Type | Notes |
|-----|------|-------|
| `FileFormat` | string | Container version tag; current files are `MW4`. |
| `Name` | string | User-visible label/template name. |
| `Author`, `Keywords`, `Site`, `Area`, `Equipment`, `SubCategory`, `Description` | string | Free-form metadata, typically empty. |
| `Category` | string | Used to group templates in Brady Workstation's UI (e.g. `My Asset Tags`). |
| `AppName` | string | Workstation addin that created the file (`AssetApp`, `FlipFlop`, `TerminalBlock`, `Custom`, ...). |
| `TargetApplication` | string | Usually echoes `AppName`. |
| `ViewRotation` | string | Editor view state. |
| `AllowFreeFormText` | string (`true`/`false`) | Whether users can type anything or are confined to picklists. |
| `IsAutoSizeLabel`, `UseRowCopies`, `BradyWorks` | string | Addin-specific flags. |
| `PartInfo` | string | Embedded `<PartsDatabase>` XML with the selected media's dimensions, Y-numbers, colours, and related parts. |
| `CreateDate`, `LastSaveDate` | string | Human-readable dates, culture-formatted. |
| `LastSavedUser` | string | Windows account name. |
| `PrinterName`, `PrinterDriverName` | string | Last printer the file was bound to (e.g. `BMP51 (USB005) - direct` / `BMP51(53)`). |
| `PrintOptions` | string | Embedded `<Options>` XML: copies, cut mode, tiling, mirror, etc. |
| `LabelDesignFileId` | string | Per-design GUID, not per-file-save. |

### 11.4 FileIndex

FileIndex is itself a Store. Its payload is 11 `UInt32` entries totalling 44 bytes: a length marker (always 44) followed by 10 per-Store offsets in this order:

```
DesignStore, RegionStore, LabelStore,
GroupStore, WiremarkStore,
PagePropertiesStore, LabelInfoFor110BlockStore,
ObjectStore, DataStore, AppDataStore
```

Brady writes the `DesignStore` entry as the literal value `44` (the FileIndex's own length) rather than an absolute offset. On read, five of the entries (DesignStore, RegionStore, LabelStore, PagePropertiesStore, ObjectStore, AppDataStore) are shifted by `delta = actual_design_position - recorded_design_offset` so that a change in header size doesn't invalidate every subsequent offset. The four obsolete entries (GroupStore, WiremarkStore, LabelInfoFor110BlockStore, DataStore) are taken verbatim and are zero in modern files.

### 11.5 DesignStore

After the `UInt32` length prefix, DesignStore's payload is:

```
<int32 LE> UdfSchemaVersion         dispatch key for every following optional field
[schema >= 13]
    <int64 LE> thumbnail_length
    <thumbnail_length bytes> PNG    128x128 RGBA preview render
[schema >= 37]
    <int32 LE> num_data_schemes
    For each: <GUID typeId>, [schema >= 57: <int64 LE> length], <UdfDataScheme payload>
[schema >= 50]
    <int32 LE> num_images
    For each: <string name>, <int64 length + bytes>
```

The latest Brady Workstation writes **schema 62**; `.BWT` templates in ProgramData are commonly **schema 59**. The maximum schema recognised by the decompiled sources is **61**, and `Design.UpdateHeaderUDFVersion` (the constant controlling when the app rewrites the header on save) is **54**.

Schema version 38 is the cutoff where `AppDataStore` became part of the write set — older files will have `FileIndex.AppDataStore == 0` and no AppDataStore bytes.

### 11.6 ObjectStore

After the `UInt32` length prefix, ObjectStore is a flat framing of drawable entities. Payload layout:

```
<u32 LE> store_length               same value as the length prefix; used as the
                                    loop terminator when reading entity records
<i32 LE> num_regions
num_regions x (
    <u8> guid_length (always 16)
    <16 bytes> region_id
)
While position < store_length:      one record per entity on any region/label
    <u8> region_index               into the regions array
    <i32 LE> label_number
    <u8 bool> is_label_entity       1 = attach to labelContent.LabelEntities;
                                    0 = child entity reused by reference
    <u8> guid_length (16)
    <16 bytes> tool_type_id         dispatches to EntityFactory.GetLabelObject
    <u8> guid_length (16)
    <16 bytes> entity_id            unique identifier for deduplication
    <u32 LE> payload_length
    <payload_length bytes> payload  written by the entity's own Serialize
```

Entity-type GUIDs observed empirically (Brady's registry is dynamic, so these values were recovered by correlating real payloads against the decompiled class layouts):

| `tool_type_id` | Class | Role |
|---------------|-------|------|
| `cfbe4eb0-037b-11de-8c30-0800200c9a66` | `RichTextEntity` | Text element — positions, font runs, template prompts |
| `9ca4bbbe-7cf5-441b-984d-bf378f122262` | `BarcodeEntity` | 1D barcode or QR code — symbology, data, bearer box |

Payloads are opaque to the framing layer — the entity's own `Serialize`/`Deserialize` reads/writes the bytes between the `payload_length` marker and the next record. `pybrady.templates.read_entities(path)` returns a list of `BwsEntity` records with these fields plus the raw payload; type-specific decoders build on top.

.NET GUIDs are serialised with the first three fields in little-endian byte order (`Data1` as `UInt32 LE`, `Data2` and `Data3` as `UInt16 LE`); the last two fields are written raw. When rendering a GUID as the canonical `xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx` form the three little-endian fields need to be reversed.

### 11.7 Entity payload internals

Every entity payload starts with the same `EntityBase` prefix before branching to type-specific fields. Parser order and field list (as of schema 62):

```
EntityBase:
    <Guid>      id                     entity-unique GUID (matches entity_id in framing)
    <Guid>      type_id                duplicate of tool_type_id from framing
    <Guid>      shape_type_id          additional shape category
    <string>    name                   editor-assigned entity name
    <Color x3>  back_color, border_color, fore_color
    <Double>    border_width
    <Bool x7>   can_move, [can_resize if schema>=47], can_print, can_select,
                draw_border, is_locked, is_template
    <Bool>      [is_in_group if schema>=49]
    <Bool>      can_show_on_screen
    <Double x2> height, width
    <Point>     position                (x, y)
    <Double x2> rotation, z_order
    <Guid>      template_object_id
    <Bool>      can_cut
    <Int32>     resize_pattern          (ResizeHandleType enum)
    <Guid>      [legacy_databound_column_id if schema<37; skipped otherwise]
    <Bool>      has_rotation_anchor     (schema>=20)
    <Int32>     rotation_anchor_value   (schema>=20)

EntityWithDynamicProperties (base for RichText, Barcode, ...):
    Six property dictionaries keyed by value type. Each dict:
        <Byte>   count
        count x (<string> key, <value>)
    In order: Int32, String, Double, Boolean, Color, Point. The `String`
    dict carries the `TEMPLATE_PROMPT` / `HAS_PICKLIST` / `Placeholder`
    slots that mark a field as template-editable.

RichTextEntity (inherits the above, then):
    RichTextDocument (m_value):
        <Double> AutoSizeDelta
        <Int32>  TextAlignment              (TextAlignment enum)
        UdfFont (see below)                   document-level font
        <Int32>  num_paragraphs
        num_paragraphs x RichTextParagraph:
            <Int32>  TextAlignment
            <Double> LineSpacing
            UdfFont                           paragraph-level font
            <Int32>  num_runs
            num_runs x RichTextRun:
                UdfFont                        run-level font
                <string> Text                  actual printable text
            <Int32>  num_line_metrics          (schema>=61)
            num_line_metrics x RichTextLineMetrics:
                <Double x3> Width, Height, BaseLine
                <Int32 x2>  Length, Position
                <Bool>      HasCollapsed
    <Bool>      has_hint_text
    [RichTextDocument] hint_text if has_hint_text
    <Double>    expand_condense_percentage
    <Int32>     line_number
    <Bool x3>   is_wrap_text, can_vertically_auto_size_with_wrap
    <Double x2> min/max_auto_sized_height_with_wrap (schema>16)
    <Bool x3>   auto_fit, underline_6_and_9, disable_multi_line
    <Rect>      text_justification_bounds
    <Int32>     vertical_alignment
    <Int32>     max_font_size
    <Bool x3>   is_fixed_size, auto_numbered, preserve_on_empty_text
    <Bool>      trim_vertical_margins (schema>29)

UdfFont:
    <string> family
    <Double> size
    <Bool>   bold
    <Bool>   italic
    <Bool>   strike_out
    <Bool>   underline
    <Bool>   all_caps
    <Int32>  baseline_alignment
    <Color>  color (schema>=22)
```

`pybrady.templates.decode_rich_text_entity(payload, schema_version)` parses the stream up through the RichTextDocument and returns a `BwsTextEntity` that carries both a flattened convenience view (`text`, `font`, `text_alignment` — concatenated text with the first run's font, matching what Brady Workstation writes in practice) and the full structural tree (`paragraphs: tuple[BwsTextParagraph, ...]`, each with its own runs, alignment, line spacing, and paragraph-level font). Callers needing per-run formatting (mixed bold/italic, per-run colour) can walk the tree; the simple 80% case still reads cleanly through the flat fields. `read_text_entities(path)` does it for every text entity in a file in one call.

BarcodeEntity shares the same `EntityBase` + `EntityWithDynamicProperties` prefix, then adds:

```
BarcodeEntity:
    UdfFont      font                           for the human-readable caption
    <string>     value                          barcode data (the bits to encode)
    <Int32>      barcode_type                   BarcodeType enum (0..34, 1000..1002)
    <Double x3>  density, ratio, xy_ratio       geometry knobs
    <Int32>      check_digit_algorithm          CheckDigitAlgorithm enum
    <Int32>      human_readable_location        PositionPoint enum (above/below/none)
    <Int32 x2>   dmx_error_correction, dmx_shape   DataMatrix-specific
    <Int32 x3>   rows, columns, pdf_security    stacked-symbology geometry
    <Bool>       truncated
    <string>     template                       format template for databound values
    [schema>=37]
        <Guid>   data_scheme_id
        <Int32>  data_column, data_row
    [schema>=42]
        <Int32>  column_format_index
    [schema>=53]
        <Bool>   is_unique
    [schema>=60]
        <Int32>  num_human_readable_entities
        <Guid x num>  human_readable_entity_ids
```

The `BarcodeType` enum covers 40+ symbologies: `Code128`, `Code39`, `QR`, `DataMatrix`, `PDF417`, `EAN13`, `UPCA`, `Interleaved2of5`, `Postnet`, `IntelligentMail`, `CodablockF`, `HIBC`, and several EAN/UPC extensions. `pybrady.templates.barcode_type_name(int)` maps an enum value to its canonical name; unknown values return `Unknown(n)` rather than raising so that a Brady schema bump doesn't break decoding.

`decode_barcode_entity(payload, schema_version)` returns a `BwsBarcodeEntity`; `read_barcode_entities(path)` iterates over every barcode in a file in one call. Both reuse the same `EntityBase` / `EntityWithDynamicProperties` parser as the text decoder.

### 11.8 AppDataStore (schema >= 38)

AppDataStore is an addin-extension mechanism: each record is keyed by a GUID that identifies an addin's data type, with an opaque payload whose meaning depends entirely on the registered `ApplicationDataFactory`. Brady Workstation's addins (AssetApp, FlipFlop, TerminalBlock, etc.) register their own factories under well-known GUIDs; for addins that don't use this extension, the store is empty (length prefix = 0, total four bytes on disk).

After the `UInt32` length prefix, each entry is:

```
<Guid> data_id_outer        dispatch key; Brady's BuildFromStore reads this
                            first and picks a factory for it
<Guid> data_id_inner        same value as the outer id; written by
                            ApplicationData.Serialize as the first field of
                            the inner record
<string> type_information   free-form tag the addin chose (typically a .NET
                            class name, e.g. "AssetApp.TemplatePromptData")
<Int64> declared_size       if 0 there is no further payload; otherwise the
                            ReadMemoryStream format follows
[declared_size > 0]
    <Int64> mem_length      MemoryStream header
    <mem_length bytes>      addin-defined payload
```

Note that `TEMPLATE_PROMPT`, `TemplateValueText`, `HAS_PICKLIST`, `Placeholder` — the template-editable-field markers — are **not** in AppDataStore. They live in each entity's `EntityWithDynamicProperties` string dictionary alongside other entity-level metadata (see §11.7). AppDataStore is reserved for whole-design-scope extension data.

All currently-available sample `.bws`/`.bwt` files have an empty AppDataStore, so the pybrady decoder (`pybrady.templates.read_app_data`) surfaces the framing — returning a list of `BwsAppDataEntry` records with `data_id`, `type_information`, `payload` — without attempting to decode any specific addin's payload format. Per-addin payload decoders can be layered on top as needed.

### 11.9 Remaining Stores (not yet decoded)

* `RegionStore`, `LabelStore`, `PagePropertiesStore` — page and label geometry; pybrady currently takes canvas dimensions from the header's `PartInfo` XML rather than parsing these.
* `GroupStore`, `WiremarkStore`, `LabelInfoFor110BlockStore`, `DataStore` — obsolete Store types retained for back-compat. Only appear when their FileIndex offset is non-zero.

### 11.10 Source code references

| C# class | File | Role |
|----------|------|------|
| `UdfSerializer` | `PrintEngine.UDF.dll` | Top-level read/write orchestrator; writes the magic + header, reads FileIndex first, then each Store. |
| `StoreBase` | same | Abstract Store wire format (`UInt32` length prefix + payload). |
| `_0023hk` (`FileIndex`) | `PrintEngine.UDF.dll`, obfuscated namespace | Offset table; its `BuildFromStore` contains the delta-adjust logic. |
| `_0023Kj` (`DesignStore`) | same | Thin wrapper that calls `Design.Deserialize` on its payload. |
| `_0023uk` (`ObjectStore`) | same | Entity framing parser; `BuildFromStore` is the authoritative loop and `WriteToStream` / `_0023sk` write the per-entity record format. |
| `Design` | `PrintEngine.UDF.dll` | The actual label data model; `Deserialize` handles the schema-version-keyed field list. |
| `EntityBase`, `RichTextEntity`, `BarcodeEntity` | same | Per-entity data model and payload serialisation. |
| `EntityFactory` | same | Dispatcher from `tool_type_id` to the concrete entity class (via `ConfigUtility` — resolved at runtime, not from a static table). |
| `UdfBinaryReader` | same | `.NET BinaryReader` subclass with `ReadGuid`, `ReadColor`, `ReadPoint`, `ReadRect`, `ReadMemoryStream` helpers. |

---
