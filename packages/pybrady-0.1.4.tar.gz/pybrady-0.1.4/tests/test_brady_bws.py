# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Tests for the Brady UDF v2 binary reader.

Unit tests construct minimal valid (and invalid) byte streams in-process
so they don't depend on shipping any Brady-copyrighted fixtures.
Integration tests run against a real Brady Workstation install if one is
present, exercising both a user-saved `.BWS` file (created locally) and a
Brady-shipped `.BWT` template from the AssetApp addin.
"""

from __future__ import annotations

import dataclasses
import io
import struct
from pathlib import Path

import pytest
from PIL import Image

from pybrady.templates import (
    BARCODE_ENTITY_TYPE_ID,
    RICH_TEXT_ENTITY_TYPE_ID,
    BwsAppDataEntry,
    BwsBarcodeEntity,
    BwsDesign,
    BwsEntity,
    BwsFileIndex,
    BwsFont,
    BwsHeader,
    BwsStore,
    BwsTextEntity,
    BwsTextParagraph,
    BwsTextRun,
    InvalidBwsFileError,
    barcode_type_name,
    read_app_data,
    read_barcode_entities,
    read_design,
    read_design_store,
    read_entities,
    read_file_index,
    read_header,
    read_store,
    read_text_entities,
    read_thumbnail,
)

_MAGIC = "brcudf2bin"
_FILE_INDEX_LENGTH = 44

_USER_BWS_SAMPLE = Path("/mnt/c/Users/Public/Documents/Brady Corp/Brady Workstation/Hello.BWS")
# One representative Brady-shipped template out of the ~2,288 in the
# AssetApp addin. Any would do — this one is picked because it's small
# and exercises both a text field and a barcode placeholder.
_BRADY_TEMPLATE = Path(
    "/mnt/c/ProgramData/Brady Corp/Brady Workstation/Addins/AssetApp/"
    "Templates/BBP11/Continuous/1/1 x 2 inch Barcode 128 - My Asset Tags.BWT"
)


def _write_7bit_int(n: int) -> bytes:
    out = bytearray()
    while n >= 0x80:
        out.append((n & 0x7F) | 0x80)
        n >>= 7
    out.append(n)
    return bytes(out)


def _bw_string(s: str) -> bytes:
    data = s.encode("utf-8")
    return _write_7bit_int(len(data)) + data


def _build_header_bytes(fields: dict[str, str], *, magic: str = _MAGIC) -> bytes:
    parts = [_bw_string(magic), struct.pack("<i", len(fields))]
    for key, value in fields.items():
        parts.append(_bw_string(key))
        parts.append(_bw_string(value))
    return b"".join(parts)


def _build_store(payload: bytes) -> bytes:
    """Wrap a payload in a Store length prefix (`length` counts itself)."""
    return struct.pack("<I", 4 + len(payload)) + payload


def _build_file_index(
    *,
    design: int,
    region: int,
    label: int,
    page_props: int,
    object_: int,
    app_data: int,
    group: int = 0,
    wiremark: int = 0,
    label_info_110: int = 0,
    data: int = 0,
) -> bytes:
    return struct.pack(
        "<IIIIIIIIIII",
        _FILE_INDEX_LENGTH,
        design,
        region,
        label,
        group,
        wiremark,
        page_props,
        label_info_110,
        object_,
        data,
        app_data,
    )


def _minimal_png() -> bytes:
    buf = io.BytesIO()
    Image.new("RGBA", (1, 1)).save(buf, format="PNG")
    return buf.getvalue()


def _guid_bytes(text_form: str) -> bytes:
    """Convert canonical `xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx` to on-wire bytes.

    .NET stores GUIDs with the first three fields little-endian; the last
    two are written as-is.
    """
    parts = text_form.split("-")
    return (
        bytes.fromhex(parts[0])[::-1]
        + bytes.fromhex(parts[1])[::-1]
        + bytes.fromhex(parts[2])[::-1]
        + bytes.fromhex(parts[3])
        + bytes.fromhex(parts[4])
    )


def _lp_guid(text_form: str) -> bytes:
    """A length-prefixed (1 byte) GUID as `UdfBinaryReader.ReadGuid` expects."""
    g = _guid_bytes(text_form)
    return bytes([len(g)]) + g


def _build_object_store_body(
    regions: list[str],
    entries: list[tuple[int, int, bool, str, str, bytes]],
) -> bytes:
    """Build an ObjectStore payload body (without the outer Store length prefix).

    The body matches what `read_entities` parses: `num_regions` + GUIDs +
    entity records. `_build_store` wraps this to add the length prefix when
    it's assembled into a full file by `_synthesise_bws`.
    """
    body = bytearray()
    body += struct.pack("<i", len(regions))
    for r in regions:
        body += _lp_guid(r)
    for region_idx, label_num, is_label, tt, eid, payload in entries:
        body.append(region_idx)
        body += struct.pack("<i", label_num)
        body.append(1 if is_label else 0)
        body += _lp_guid(tt)
        body += _lp_guid(eid)
        body += struct.pack("<I", len(payload))
        body += payload
    return bytes(body)


def _build_design_payload(*, schema_version: int = 62, thumbnail: bytes | None = None) -> bytes:
    """Build a DesignStore payload (without the outer Store length prefix).

    The prefix fields that pybrady parses are laid out as:
        [i32 LE] UdfSchemaVersion
        [i64 LE] thumbnail length (0 if absent)
        [N bytes] thumbnail PNG
        [...remainder (unused by this layer)]
    """
    parts = [struct.pack("<i", schema_version)]
    if thumbnail is None:
        parts.append(struct.pack("<q", 0))
    else:
        parts.append(struct.pack("<q", len(thumbnail)))
        parts.append(thumbnail)
    return b"".join(parts)


def _build_app_data_body(entries: list[tuple[str, str, bytes]]) -> bytes:
    """Build an AppDataStore payload body matching Brady's on-wire format.

    Each tuple is `(data_id_guid, type_information, payload_bytes)`.
    """
    body = bytearray()
    for data_id, type_info, payload in entries:
        body += _lp_guid(data_id)  # outer dispatch key
        body += _lp_guid(data_id)  # inner id (ApplicationData.Serialize writes it again)
        body += _bw_string(type_info)
        if payload:
            body += struct.pack("<q", len(payload))  # declared size (non-zero)
            body += struct.pack("<q", len(payload))  # MemoryStream length
            body += payload
        else:
            body += struct.pack("<q", 0)  # declared size = 0, no further bytes
    return bytes(body)


def _synthesise_bws(
    header: dict[str, str],
    *,
    design_payload: bytes | None = None,
    design_schema: int = 62,
    design_thumbnail: bytes | None = None,
    region_payload: bytes = b"",
    label_payload: bytes = b"",
    page_props_payload: bytes = b"",
    object_payload: bytes = b"",
    app_data_payload: bytes = b"",
) -> bytes:
    """Build a complete, valid `.bws` file end-to-end.

    Offsets inside the FileIndex use Brady's convention — DesignStore
    stored as 44 (the FileIndex's own length) and everything else offset
    relative to the FileIndex start. The reader's delta-adjust step
    converts that back to absolute file offsets.
    """
    header_bytes = _build_header_bytes(header)
    if design_payload is None:
        design_payload = _build_design_payload(
            schema_version=design_schema, thumbnail=design_thumbnail
        )
    design_store = _build_store(design_payload)
    region_store = _build_store(region_payload)
    label_store = _build_store(label_payload)
    page_props_store = _build_store(page_props_payload)
    object_store = _build_store(object_payload)
    app_data_store = _build_store(app_data_payload)

    # Positions relative to fi_start (Brady's raw-offset convention).
    rel_design = _FILE_INDEX_LENGTH
    rel_region = rel_design + len(design_store)
    rel_label = rel_region + len(region_store)
    rel_page_props = rel_label + len(label_store)
    rel_object = rel_page_props + len(page_props_store)
    rel_app_data = rel_object + len(object_store)

    fi = _build_file_index(
        design=rel_design,
        region=rel_region,
        label=rel_label,
        page_props=rel_page_props,
        object_=rel_object,
        app_data=rel_app_data,
    )

    return (
        header_bytes
        + fi
        + design_store
        + region_store
        + label_store
        + page_props_store
        + object_store
        + app_data_store
    )


# ---------------------------------------------------------------------------
# Header tests
# ---------------------------------------------------------------------------


def test_read_header_parses_fields(tmp_path: Path) -> None:
    fixture = tmp_path / "label.bws"
    fixture.write_bytes(
        _build_header_bytes({"FileFormat": "MW4", "Name": "TestLabel", "AppName": "AssetApp"})
    )

    header = read_header(fixture)

    assert isinstance(header, BwsHeader)
    assert header.name == "TestLabel"
    assert header.app == "AssetApp"
    assert header.file_format == "MW4"
    assert header.fields == {"FileFormat": "MW4", "Name": "TestLabel", "AppName": "AssetApp"}


def test_read_header_handles_empty_values(tmp_path: Path) -> None:
    # .NET's BinaryWriter writes empty strings as a zero-length prefix,
    # which is how Brady Workstation encodes optional fields like Author.
    fixture = tmp_path / "label.bws"
    fixture.write_bytes(_build_header_bytes({"Author": "", "Site": "", "Name": "x"}))

    header = read_header(fixture)

    assert header.get("Author") == ""
    assert header.get("Site") == ""
    assert header.name == "x"


def test_read_header_handles_long_strings(tmp_path: Path) -> None:
    # Strings >= 128 bytes exercise the 2-byte LEB128 encoding path — the
    # embedded <PartsDatabase> XML blob in real files routinely hits this.
    long_value = "A" * 500
    fixture = tmp_path / "label.bws"
    fixture.write_bytes(_build_header_bytes({"Description": long_value}))

    assert read_header(fixture).get("Description") == long_value


def test_read_header_rejects_wrong_magic(tmp_path: Path) -> None:
    fixture = tmp_path / "not_a_bws.bin"
    fixture.write_bytes(_build_header_bytes({"x": "y"}, magic="NOT-UDF"))

    with pytest.raises(InvalidBwsFileError, match="not a Brady UDF v2 binary file"):
        read_header(fixture)


def test_read_header_rejects_truncated_file(tmp_path: Path) -> None:
    fixture = tmp_path / "truncated.bws"
    # Valid magic + count promising two entries, but no entries follow.
    fixture.write_bytes(_bw_string(_MAGIC) + struct.pack("<i", 2))

    with pytest.raises(EOFError):
        read_header(fixture)


# ---------------------------------------------------------------------------
# FileIndex + Store tests
# ---------------------------------------------------------------------------


def test_read_file_index_resolves_absolute_offsets(tmp_path: Path) -> None:
    fixture = tmp_path / "indexed.bws"
    fixture.write_bytes(
        _synthesise_bws(
            {"Name": "Indexed"},
            design_payload=b"DESIGN",
            region_payload=b"REGION",
            label_payload=b"LABEL",
            page_props_payload=b"PP",
            object_payload=b"OBJ",
            app_data_payload=b"ADP",
        )
    )

    index = read_file_index(fixture)

    # DesignStore is always right after the FileIndex and its length
    # prefix tells us where the next Store starts.
    assert index.design_store > 0
    with fixture.open("rb") as f:
        f.seek(index.design_store)
        ds_length = struct.unpack("<I", f.read(4))[0]
    assert index.region_store == index.design_store + ds_length

    # Everything appears in the expected strictly-increasing order.
    ordered = [
        index.design_store,
        index.region_store,
        index.label_store,
        index.page_properties_store,
        index.object_store,
        index.app_data_store,
    ]
    assert ordered == sorted(ordered)

    # Obsolete stores are absent in synthesised files.
    assert index.group_store == 0
    assert index.wiremark_store == 0
    assert index.label_info_for_110_block_store == 0
    assert index.data_store == 0


def test_read_file_index_rejects_wrong_length(tmp_path: Path) -> None:
    fixture = tmp_path / "bad_fi.bws"
    # Header OK, but FileIndex claims a non-canonical length (48 instead of 44).
    fixture.write_bytes(
        _build_header_bytes({"Name": "x"})
        + struct.pack("<IIIIIIIIIIII", 48, 44, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    )

    with pytest.raises(InvalidBwsFileError, match="unexpected FileIndex length 48"):
        read_file_index(fixture)


def test_read_store_returns_correct_bytes(tmp_path: Path) -> None:
    fixture = tmp_path / "roundtrip.bws"
    payload = b"design-bytes-here"
    fixture.write_bytes(_synthesise_bws({"Name": "rt"}, design_payload=payload))
    index = read_file_index(fixture)

    store = read_store(fixture, index.design_store, name="DesignStore")

    assert isinstance(store, BwsStore)
    assert store.name == "DesignStore"
    assert store.file_offset == index.design_store
    # Store.data includes the 4-byte length prefix itself.
    assert store.length == 4 + len(payload)
    assert store.data[4:] == payload


def test_read_design_store_convenience(tmp_path: Path) -> None:
    payload = b"design-convenience"
    fixture = tmp_path / "conv.bws"
    fixture.write_bytes(_synthesise_bws({"Name": "c"}, design_payload=payload))

    store = read_design_store(fixture)

    assert store.name == "DesignStore"
    assert store.data[4:] == payload


def test_file_index_is_frozen() -> None:
    index = BwsFileIndex(
        design_store=1,
        region_store=2,
        label_store=3,
        group_store=0,
        wiremark_store=0,
        page_properties_store=4,
        label_info_for_110_block_store=0,
        object_store=5,
        data_store=0,
        app_data_store=6,
    )
    with pytest.raises(dataclasses.FrozenInstanceError):
        index.design_store = 999  # type: ignore[misc]


# ---------------------------------------------------------------------------
# Thumbnail tests
# ---------------------------------------------------------------------------


def test_read_thumbnail_returns_png_from_design_store(tmp_path: Path) -> None:
    png = _minimal_png()
    fixture = tmp_path / "thumb.bws"
    fixture.write_bytes(_synthesise_bws({"Name": "thumb"}, design_thumbnail=png))

    extracted = read_thumbnail(fixture)

    assert extracted == png
    Image.open(io.BytesIO(extracted)).verify()


def test_read_thumbnail_returns_none_when_design_store_has_none(tmp_path: Path) -> None:
    fixture = tmp_path / "bare.bws"
    fixture.write_bytes(_synthesise_bws({"Name": "bare"}))  # default: no thumbnail

    assert read_thumbnail(fixture) is None


def test_read_thumbnail_ignores_png_outside_design_store(tmp_path: Path) -> None:
    # A PNG embedded in ObjectStore (not DesignStore) must not leak out as
    # the "thumbnail" — the thumbnail is specifically DesignStore's preview
    # render, read from its length-prefixed slot.
    png = _minimal_png()
    fixture = tmp_path / "misplaced.bws"
    fixture.write_bytes(_synthesise_bws({"Name": "x"}, object_payload=png))

    assert read_thumbnail(fixture) is None


# ---------------------------------------------------------------------------
# DesignStore (schema_version + thumbnail) tests
# ---------------------------------------------------------------------------


def test_read_design_returns_schema_version_and_thumbnail(tmp_path: Path) -> None:
    png = _minimal_png()
    fixture = tmp_path / "d.bws"
    fixture.write_bytes(_synthesise_bws({"Name": "d"}, design_schema=62, design_thumbnail=png))

    design = read_design(fixture)

    assert isinstance(design, BwsDesign)
    assert design.schema_version == 62
    assert design.thumbnail_png == png


def test_read_design_handles_no_thumbnail(tmp_path: Path) -> None:
    fixture = tmp_path / "nothumb.bws"
    fixture.write_bytes(_synthesise_bws({"Name": "x"}, design_schema=62))

    design = read_design(fixture)

    assert design.schema_version == 62
    assert design.thumbnail_png is None


def test_read_design_skips_thumbnail_field_for_pre_schema_13(tmp_path: Path) -> None:
    # Schemas <= 12 don't have a thumbnail field at all; the reader must
    # not try to read one.
    fixture = tmp_path / "old.bws"
    # Build a DesignStore payload that's just the schema version, nothing else.
    design_payload = struct.pack("<i", 10)
    fixture.write_bytes(_synthesise_bws({"Name": "old"}, design_payload=design_payload))

    design = read_design(fixture)

    assert design.schema_version == 10
    assert design.thumbnail_png is None


def test_read_design_rejects_non_png_thumbnail_bytes(tmp_path: Path) -> None:
    # A length-prefixed blob that claims to be a thumbnail but doesn't
    # start with the PNG signature — guards against us returning garbage
    # that PIL would later choke on.
    non_png = b"NOT_A_PNG" + b"\x00" * 20
    design_payload = struct.pack("<i", 62) + struct.pack("<q", len(non_png)) + non_png
    fixture = tmp_path / "bad_thumb.bws"
    fixture.write_bytes(_synthesise_bws({"Name": "x"}, design_payload=design_payload))

    with pytest.raises(InvalidBwsFileError, match="not a PNG"):
        read_design(fixture)


def test_read_design_rejects_truncated_thumbnail(tmp_path: Path) -> None:
    # Claims a 1 KiB thumbnail but actually has 5 bytes.
    design_payload = struct.pack("<i", 62) + struct.pack("<q", 1024) + b"short"
    fixture = tmp_path / "trunc.bws"
    fixture.write_bytes(_synthesise_bws({"Name": "x"}, design_payload=design_payload))

    with pytest.raises(InvalidBwsFileError, match="claims 1024 bytes"):
        read_design(fixture)


# ---------------------------------------------------------------------------
# ObjectStore framing tests
# ---------------------------------------------------------------------------


_REGION_A = "11111111-2222-3333-4444-555555555555"
_REGION_B = "66666666-7777-8888-9999-aaaaaaaaaaaa"
_ENTITY_A = "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee"
_ENTITY_B = "00000000-1111-2222-3333-444444444444"


def test_read_entities_returns_structured_records(tmp_path: Path) -> None:
    body = _build_object_store_body(
        regions=[_REGION_A, _REGION_B],
        entries=[
            (0, 0, True, RICH_TEXT_ENTITY_TYPE_ID, _ENTITY_A, b"text-blob"),
            (1, 3, False, BARCODE_ENTITY_TYPE_ID, _ENTITY_B, b"barcode-blob"),
        ],
    )
    fixture = tmp_path / "multi.bws"
    fixture.write_bytes(_synthesise_bws({"Name": "multi"}, object_payload=body))

    entities = read_entities(fixture)

    assert len(entities) == 2
    first, second = entities
    assert isinstance(first, BwsEntity)
    assert first.tool_type_id == RICH_TEXT_ENTITY_TYPE_ID
    assert first.entity_id == _ENTITY_A
    assert first.region_id == _guid_bytes(_REGION_A)
    assert first.region_index == 0
    assert first.label_number == 0
    assert first.is_label_entity is True
    assert first.payload == b"text-blob"

    assert second.tool_type_id == BARCODE_ENTITY_TYPE_ID
    assert second.entity_id == _ENTITY_B
    assert second.region_index == 1
    assert second.label_number == 3
    assert second.is_label_entity is False
    assert second.payload == b"barcode-blob"


def test_read_entities_handles_empty_store(tmp_path: Path) -> None:
    fixture = tmp_path / "empty.bws"
    body = _build_object_store_body(regions=[_REGION_A], entries=[])
    fixture.write_bytes(_synthesise_bws({"Name": "e"}, object_payload=body))

    assert read_entities(fixture) == []


def test_read_entities_rejects_region_index_out_of_range(tmp_path: Path) -> None:
    # region_idx = 5 with only one region defined is a data-integrity error
    body = _build_object_store_body(
        regions=[_REGION_A],
        entries=[(5, 0, True, RICH_TEXT_ENTITY_TYPE_ID, _ENTITY_A, b"x")],
    )
    fixture = tmp_path / "bad_region.bws"
    fixture.write_bytes(_synthesise_bws({"Name": "b"}, object_payload=body))

    with pytest.raises(InvalidBwsFileError, match="references region 5"):
        read_entities(fixture)


def test_read_entities_rejects_truncated_payload(tmp_path: Path) -> None:
    # Manually mangle the ObjectStore payload so it claims a 1 KB entity
    # payload but has no bytes for it.
    body = bytearray()
    body += struct.pack("<i", 1)  # 1 region
    body += _lp_guid(_REGION_A)
    body.append(0)  # region_idx
    body += struct.pack("<i", 0)  # label_number
    body.append(1)  # is_label
    body += _lp_guid(RICH_TEXT_ENTITY_TYPE_ID)
    body += _lp_guid(_ENTITY_A)
    body += struct.pack("<I", 1024)  # claims 1024 bytes, none follow

    fixture = tmp_path / "trunc.bws"
    fixture.write_bytes(_synthesise_bws({"Name": "t"}, object_payload=bytes(body)))

    with pytest.raises(InvalidBwsFileError, match="1024-byte payload"):
        read_entities(fixture)


def test_format_guid_round_trips_known_type_ids() -> None:
    # Round-trip every constant we ship through both directions to lock down
    # the .NET GUID endianness handling once and for all.
    from pybrady.templates.brady_bws import _format_guid

    for canonical in (RICH_TEXT_ENTITY_TYPE_ID, BARCODE_ENTITY_TYPE_ID):
        assert _format_guid(_guid_bytes(canonical)) == canonical


# ---------------------------------------------------------------------------
# _UdfReader primitive tests
# ---------------------------------------------------------------------------


def test_udf_reader_reads_dotnet_primitives() -> None:
    from pybrady.templates.brady_bws import _UdfReader

    # Hand-build a byte stream exercising every primitive the decoder uses.
    payload = (
        struct.pack("<i", 12345)  # Int32
        + struct.pack("<I", 0xDEADBEEF)  # UInt32
        + struct.pack("<d", 3.14159)  # Double
        + b"\x01"  # Boolean true
        + b"\x00"  # Boolean false
        + b"\x2a"  # byte = 42
        + b"\x81\x01"  # 7-bit int = 129
        + b"\x05hello"  # string of length 5
        + b"\x10"
        + bytes.fromhex("ffeeddccbbaa99887766554433221100")  # Guid
        + b"\xaa\xbb\xcc\xdd"  # Color (A, R, G, B)
        + struct.pack("<dd", 1.5, 2.5)  # Point
        + b"\x00"
        + struct.pack("<dddd", 1.0, 2.0, 3.0, 4.0)  # Rect non-empty
        + b"\x01"  # Rect empty
    )

    reader = _UdfReader(payload)
    assert reader.read_int32() == 12345
    assert reader.read_uint32() == 0xDEADBEEF
    assert abs(reader.read_double() - 3.14159) < 1e-9
    assert reader.read_boolean() is True
    assert reader.read_boolean() is False
    assert reader.read_byte() == 42
    assert reader.read_7bit_int() == 129
    assert reader.read_string() == "hello"
    assert reader.read_guid() == "ccddeeff-aabb-8899-7766-554433221100"
    assert reader.read_color() == (0xAA, 0xBB, 0xCC, 0xDD)
    assert reader.read_point() == (1.5, 2.5)
    assert reader.read_rect() == (1.0, 2.0, 3.0, 4.0)
    assert reader.read_rect() is None
    assert reader.remaining == 0


def test_udf_reader_raises_on_truncation() -> None:
    from pybrady.templates.brady_bws import _UdfReader

    reader = _UdfReader(b"\x00\x01")  # only 2 bytes
    with pytest.raises(InvalidBwsFileError, match="truncated"):
        reader.read_int32()  # wants 4 bytes


# ---------------------------------------------------------------------------
# BarcodeType enum helper
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# AppDataStore tests
# ---------------------------------------------------------------------------


_APP_DATA_ID_1 = "11112222-3333-4444-5555-666666666666"
_APP_DATA_ID_2 = "aaaabbbb-cccc-dddd-eeee-ffffffffffff"


def test_read_app_data_returns_empty_for_unpopulated_store(tmp_path: Path) -> None:
    # Passing `app_data_payload=b""` models a file where Brady wrote a
    # zero-length AppDataStore — the common case for templates that don't
    # use the addin-data extension mechanism.
    fixture = tmp_path / "no_app.bws"
    fixture.write_bytes(_synthesise_bws({"Name": "x"}, app_data_payload=b""))

    assert read_app_data(fixture) == []


def test_read_app_data_decodes_entries(tmp_path: Path) -> None:
    entries = [
        (_APP_DATA_ID_1, "AssetApp.TemplatePromptData", b"asset-binary-blob"),
        (_APP_DATA_ID_2, "FlipFlop.CableTagConfig", b""),  # empty payload is valid
    ]
    fixture = tmp_path / "app.bws"
    fixture.write_bytes(
        _synthesise_bws({"Name": "app"}, app_data_payload=_build_app_data_body(entries))
    )

    parsed = read_app_data(fixture)

    assert len(parsed) == 2
    assert all(isinstance(e, BwsAppDataEntry) for e in parsed)
    assert parsed[0].data_id == _APP_DATA_ID_1
    assert parsed[0].type_information == "AssetApp.TemplatePromptData"
    assert parsed[0].payload == b"asset-binary-blob"
    assert parsed[1].data_id == _APP_DATA_ID_2
    assert parsed[1].type_information == "FlipFlop.CableTagConfig"
    assert parsed[1].payload == b""


def test_read_app_data_rejects_mismatched_inner_id(tmp_path: Path) -> None:
    # Manually build a body where the outer id and inner id disagree — that
    # shouldn't happen in real files but should raise clearly if it does.
    body = (
        _lp_guid(_APP_DATA_ID_1)  # outer
        + _lp_guid(_APP_DATA_ID_2)  # inner — wrong!
        + _bw_string("Some.Type")
        + struct.pack("<q", 0)
    )
    fixture = tmp_path / "mismatch.bws"
    fixture.write_bytes(_synthesise_bws({"Name": "m"}, app_data_payload=body))

    with pytest.raises(InvalidBwsFileError, match=r"outer id.*!= inner id"):
        read_app_data(fixture)


def test_barcode_type_name_resolves_known_values() -> None:
    # Spot-check a few from PrintEngine.UDF.BarcodeType — enough to catch a
    # typo'd mapping but not so many that the test has to mirror the full enum.
    assert barcode_type_name(0) == "None"
    assert barcode_type_name(18) == "Code128"
    assert barcode_type_name(23) == "Code39"
    assert barcode_type_name(29) == "DataMatrix"
    assert barcode_type_name(30) == "PDF417"
    assert barcode_type_name(33) == "QR"
    # Unknown values surface with their numeric value rather than silently
    # masking a future Brady schema change.
    assert barcode_type_name(9999) == "Unknown(9999)"


# ---------------------------------------------------------------------------
# Integration tests against a real Brady Workstation install
# ---------------------------------------------------------------------------


@pytest.mark.skipif(
    not _USER_BWS_SAMPLE.exists(),
    reason="requires a locally-saved .BWS file at the expected Public Documents path",
)
def test_reads_user_saved_bws_file() -> None:
    # Hello.BWS is a label the user created locally with Brady Workstation;
    # this exercises every layer (header, FileIndex, DesignStore) on a real
    # file rather than a synthesised fixture.
    header = read_header(_USER_BWS_SAMPLE)
    assert header.file_format == "MW4"
    assert header.app == "AssetApp"

    index = read_file_index(_USER_BWS_SAMPLE)
    assert index.design_store > 0
    assert index.region_store > index.design_store
    assert index.object_store > index.label_store

    design = read_design(_USER_BWS_SAMPLE)
    # Current Brady Workstation writes schema 62.
    assert design.schema_version >= 37
    assert design.thumbnail_png is not None
    # Brady Workstation renders label previews at 128x128.
    assert Image.open(io.BytesIO(design.thumbnail_png)).size == (128, 128)

    # Hello.BWS was saved through the AssetApp flow with two Text slots per
    # label across two regions and two labels. The framing parser should see
    # multiple text entities and nothing else.
    entities = read_entities(_USER_BWS_SAMPLE)
    assert len(entities) > 0
    assert all(e.tool_type_id == RICH_TEXT_ENTITY_TYPE_ID for e in entities)

    # Full RichTextEntity decode: Hello.BWS has two template prompts called
    # "Text 1" and "Text 2" that stand in for user input, and uses Arial.
    text_entities = read_text_entities(_USER_BWS_SAMPLE)
    assert len(text_entities) > 0
    assert all(isinstance(te, BwsTextEntity) for te in text_entities)
    assert all(isinstance(te.font, BwsFont) for te in text_entities)
    assert all(te.font.family == "Arial" for te in text_entities)
    prompts = {te.template_prompt for te in text_entities if te.template_prompt}
    assert prompts == {"Text 1", "Text 2"}
    # Each entity has a position and size on the label.
    for te in text_entities:
        assert te.common.width > 0
        assert te.common.height > 0
        assert te.font.size > 0

    # Paragraphs/runs tree is populated for every text entity. In practice
    # Brady Workstation writes one paragraph, one run — confirm that shape
    # matches what the flattened `text` / `font` surface says.
    for te in text_entities:
        assert len(te.paragraphs) >= 1
        first_para = te.paragraphs[0]
        assert isinstance(first_para, BwsTextParagraph)
        assert len(first_para.runs) >= 1
        first_run = first_para.runs[0]
        assert isinstance(first_run, BwsTextRun)
        # The flattened `font` is the first run's font.
        assert first_run.font.family == te.font.family
        assert first_run.font.size == te.font.size


@pytest.mark.skipif(
    not _BRADY_TEMPLATE.exists(),
    reason="requires Brady Workstation with the AssetApp addin installed",
)
def test_reads_brady_shipped_bwt_template() -> None:
    # A real Brady-shipped template (`.BWT`). These share the `brcudf2bin`
    # wire format with user-saved `.BWS` files; this test asserts that.
    header = read_header(_BRADY_TEMPLATE)
    assert header.file_format == "MW4"
    assert header.name == "1 x 2 inch Barcode 128"

    index = read_file_index(_BRADY_TEMPLATE)
    assert index.design_store > 0
    assert index.app_data_store > index.object_store

    design = read_design(_BRADY_TEMPLATE)
    # BWT templates at time of sampling were written with schema 59;
    # stay generous here so a re-save at a newer schema doesn't break the test.
    assert design.schema_version >= 37
    assert design.thumbnail_png is not None
    assert Image.open(io.BytesIO(design.thumbnail_png)).size == (128, 128)

    # "1 x 2 inch Barcode 128" is a barcode-only template.
    entities = read_entities(_BRADY_TEMPLATE)
    assert len(entities) > 0
    assert all(e.tool_type_id == BARCODE_ENTITY_TYPE_ID for e in entities)

    # Full BarcodeEntity decode: the template is for Code128 and ships with a
    # placeholder string 'BARCODE 128' that users are expected to overwrite.
    barcodes = read_barcode_entities(_BRADY_TEMPLATE)
    assert len(barcodes) > 0
    first = barcodes[0]
    assert isinstance(first, BwsBarcodeEntity)
    assert first.barcode_type_name == "Code128"
    assert first.value == "BARCODE 128"
    assert first.common.width > 0
    assert first.common.height > 0
    # Every BarcodeEntity carries its own human-readable-font record.
    assert isinstance(first.font, BwsFont)
    assert first.font.family == "Arial"

    # AppDataStore is present but empty in current Brady-shipped templates;
    # the decoder should return an empty list, not raise.
    assert read_app_data(_BRADY_TEMPLATE) == []
