# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Tests for the render helpers — text, QR, barcode, icon, Label."""

from __future__ import annotations

import io

import pytest
from PIL import Image

from pybrady.render import Label, icon, image_to_rows, text_block, text_label


def _pixels(image: Image.Image) -> list[int]:
    """Flat pixel list; shims around Pillow 14's `getdata` deprecation."""
    getter = getattr(image, "get_flattened_data", image.getdata)
    return list(getter())


def test_datamatrix_returns_1bit_square_with_ink() -> None:
    from pybrady.render.datamatrix import datamatrix

    img = datamatrix("ACME-00042", size_px=128)
    assert img.size == (128, 128)
    assert img.mode == "1"
    pixels = _pixels(img)
    # Real DataMatrix has both modules (0) and quiet-zone/white (255).
    assert 0 in pixels
    assert 255 in pixels


def test_datamatrix_different_data_produces_different_pixels() -> None:
    from pybrady.render.datamatrix import datamatrix

    a = datamatrix("asset-A", size_px=128)
    b = datamatrix("asset-B", size_px=128)
    assert _pixels(a) != _pixels(b)


def test_pdf417_returns_1bit_image_with_ink() -> None:
    from pybrady.render.pdf417 import pdf417

    img = pdf417("DL12345 AAMVA sample", width_px=400, height_px=100)
    assert img.size == (400, 100)
    assert img.mode == "1"
    pixels = _pixels(img)
    assert 0 in pixels
    assert 255 in pixels


def test_pdf417_different_data_produces_different_pixels() -> None:
    from pybrady.render.pdf417 import pdf417

    a = pdf417("card-A", width_px=400, height_px=100)
    b = pdf417("card-B", width_px=400, height_px=100)
    assert _pixels(a) != _pixels(b)


def test_text_block_returns_1bit_image_containing_pixels() -> None:
    img = text_block("X", size=40)
    assert img.mode == "1"
    assert img.size[0] > 0 and img.size[1] > 0
    # Has at least one black pixel (ink).
    assert 0 in _pixels(img)


def test_text_label_centers_on_fixed_canvas() -> None:
    img = text_label("HI", width_px=200, height_px=100, size=40)
    assert img.mode == "1"
    assert img.size == (200, 100)


def test_text_label_alignment_shifts_ink_position() -> None:
    # Column-sum of black pixels on each side tells us where the ink landed.
    def black_ink_in_cols(img: Image.Image, cols: range) -> int:
        pixels = img.load()
        return sum(1 for x in cols for y in range(img.height) if pixels[x, y] == 0)

    for align, expected_side in [("left", "left"), ("right", "right"), ("center", "center")]:
        img = text_label("HI", width_px=300, height_px=100, size=60, align=align)
        left_ink = black_ink_in_cols(img, range(0, 80))
        right_ink = black_ink_in_cols(img, range(220, 300))
        mid_ink = black_ink_in_cols(img, range(110, 190))
        if expected_side == "left":
            assert left_ink > 0 and right_ink == 0
        elif expected_side == "right":
            assert right_ink > 0 and left_ink == 0
        else:  # center
            assert mid_ink > 0


def test_text_label_rejects_invalid_align() -> None:
    with pytest.raises(ValueError, match="invalid align"):
        text_label("X", width_px=100, height_px=50, align="justify")


def test_label_paste_at_coordinates() -> None:
    lbl = Label(100, 50)
    blob = Image.new("1", (10, 10), 0)  # all black
    lbl.paste(blob, at=(5, 5))
    pixel_at_center = lbl.image.getpixel((10, 10))
    pixel_at_corner = lbl.image.getpixel((99, 49))
    assert pixel_at_center == 0  # black — from pasted blob
    assert pixel_at_corner == 1  # white — untouched canvas


def test_label_paste_centered_horizontally_and_vertically() -> None:
    lbl = Label(100, 100)
    blob = Image.new("1", (20, 20), 0)
    lbl.paste_centered(blob)
    # Center of canvas should be black.
    assert lbl.image.getpixel((50, 50)) == 0
    # Just outside the pasted region should be white.
    assert lbl.image.getpixel((39, 50)) == 1
    assert lbl.image.getpixel((61, 50)) == 1


def test_label_rejects_invalid_size() -> None:
    with pytest.raises(ValueError):
        Label(0, 10)


def test_icon_from_pil_image_thresholds_to_1bit() -> None:
    # Grey square at 200 → above threshold → white, plus a black dot at (5, 5).
    src = Image.new("L", (20, 20), 200)
    src.putpixel((5, 5), 0)
    out = icon(src, size_px=20)
    assert out.mode == "1"
    assert out.getpixel((5, 5)) == 0
    assert out.getpixel((10, 10)) == 255


def test_icon_invert_swaps_polarity() -> None:
    src = Image.new("L", (4, 4), 0)  # all black
    out = icon(src, size_px=4, invert=True)
    assert out.getpixel((0, 0)) == 255  # inverted → white


def test_image_to_rows_integrates_with_label() -> None:
    # End-to-end: build a label, rasterise it, assert row count == height.
    lbl = Label(32, 8)
    lbl.paste_centered(Image.new("1", (16, 4), 0))
    rows = image_to_rows(lbl.image)
    assert len(rows) == 8
    assert all(len(r) == 4 for r in rows)  # 32 px / 8 = 4 bytes per row


# Optional-dep helpers — skip cleanly if the library isn't available.
segno = pytest.importorskip("segno")
python_barcode = pytest.importorskip("barcode")


def test_qr_returns_expected_size() -> None:
    from pybrady.render.qr import qr

    img = qr("https://example.com", size_px=128)
    assert img.size == (128, 128)
    assert img.mode == "1"
    pixels = _pixels(img)
    assert 0 in pixels
    assert 255 in pixels


def test_barcode_returns_1bit_image_of_expected_height() -> None:
    from pybrady.render.barcode import barcode

    img = barcode("12345", symbology="code128", height_px=60)
    assert img.mode == "1"
    assert img.size[0] > 0
    # Height may include quiet zones; allow some slop.
    assert 40 <= img.size[1] <= 120


def test_barcode_roundtrips_through_bytesio_without_exception() -> None:
    # Guards against PIL pipeline regressions in python-barcode's ImageWriter.
    from pybrady.render.barcode import barcode

    img = barcode("HELLO", symbology="code128")
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    assert buf.getvalue().startswith(b"\x89PNG")
