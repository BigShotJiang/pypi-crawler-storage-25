# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Tests for `pybrady.paths` — data-dir resolution and bundle round-trip."""

from __future__ import annotations

from pathlib import Path

import pytest

from pybrady import paths


def test_data_dir_defaults_to_home(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    monkeypatch.delenv("PYBRADY_DATA_DIR", raising=False)
    monkeypatch.setattr(Path, "home", classmethod(lambda _cls: tmp_path))

    assert paths.data_dir() == tmp_path / "pybrady" / "brady-templates"
    assert paths.fonts_dir() == tmp_path / "pybrady" / "brady-templates" / "Fonts"
    assert paths.icons_dir() == tmp_path / "pybrady" / "brady-templates" / "Icons"
    assert paths.templates_dir() == tmp_path / "pybrady" / "brady-templates" / "Addins"


def test_data_dir_respects_env_override(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    override = tmp_path / "custom" / "brady-data"
    monkeypatch.setenv("PYBRADY_DATA_DIR", str(override))

    assert paths.data_dir() == override
    assert paths.fonts_dir() == override / "Fonts"
    assert paths.icons_dir() == override / "Icons"


def _seed_data_dir(root: Path) -> None:
    """Build a minimal data dir that looks like what the exporter writes."""
    (root / "Fonts").mkdir(parents=True)
    (root / "Fonts" / "Brady Alpine.ttf").write_bytes(b"fake-ttf")
    (root / "Icons").mkdir()
    (root / "Icons" / "AA001.svg").write_bytes(b"<svg/>")
    (root / "Addins" / "AssetApp" / "Templates").mkdir(parents=True)
    (root / "Addins" / "AssetApp" / "Templates" / "x.BWT").write_bytes(b"fake-bwt")
    (root / "manifest.json").write_text('{"total_templates": 1}\n')


@pytest.mark.parametrize("ext", [".tar.gz", ".tgz", ".zip", ".tar"])
def test_bundle_roundtrip(tmp_path: Path, ext: str) -> None:
    source = tmp_path / "brady-templates"
    _seed_data_dir(source)
    archive = tmp_path / f"bundle{ext}"

    written = paths.create_bundle(source, archive)
    assert written == archive
    assert archive.is_file()
    assert archive.stat().st_size > 0

    # Extract into a clean directory; the archive should contain a single
    # top-level dir matching the source name, so the expected data dir
    # lands at <dest>/brady-templates/.
    extract_to = tmp_path / "restored"
    result = paths.extract_bundle(archive, extract_to)
    assert result == extract_to

    restored = extract_to / "brady-templates"
    assert (restored / "Fonts" / "Brady Alpine.ttf").read_bytes() == b"fake-ttf"
    assert (restored / "Icons" / "AA001.svg").read_bytes() == b"<svg/>"
    assert (restored / "Addins" / "AssetApp" / "Templates" / "x.BWT").is_file()
    assert (restored / "manifest.json").is_file()


def test_create_bundle_defaults_to_zip_for_unknown_extension(tmp_path: Path) -> None:
    """Unrecognised extensions fall back to .zip — the Windows-friendly default."""
    source = tmp_path / "brady-templates"
    _seed_data_dir(source)

    # No extension at all → shutil appends .zip to the name we gave.
    written = paths.create_bundle(source, tmp_path / "bundle")
    assert written == tmp_path / "bundle.zip"
    assert written.is_file()
    # It is a real zip (PK signature) rather than a tarball.
    assert written.read_bytes()[:2] == b"PK"

    # A weird extension like .rar is preserved but .zip gets appended,
    # so there's no confusion about what format it actually is.
    written2 = paths.create_bundle(source, tmp_path / "bundle.rar")
    assert written2 == tmp_path / "bundle.rar.zip"
    assert written2.read_bytes()[:2] == b"PK"


def test_create_bundle_rejects_missing_source(tmp_path: Path) -> None:
    with pytest.raises(FileNotFoundError):
        paths.create_bundle(tmp_path / "does-not-exist", tmp_path / "b.tar.gz")


def test_extract_bundle_rejects_missing_archive(tmp_path: Path) -> None:
    with pytest.raises(FileNotFoundError):
        paths.extract_bundle(tmp_path / "missing.tar.gz", tmp_path / "out")
