# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Byte-level tests for the ESC/BMP protocol generator.

Expected bytes come straight from docs/brady_specification.md §3.
"""

from __future__ import annotations

from pybrady.models import CutMode
from pybrady.protocol import esc_bmp


def test_job_framing_constants() -> None:
    assert esc_bmp.JOB_START == b"\x1b\x58\x00"
    assert esc_bmp.JOB_END == b"\x1b\x44"
    assert esc_bmp.PAGE_END == b"\x1b\x45"
    assert esc_bmp.SUBSCRIBE == b"\x1b\x49"
    assert esc_bmp.BMP51_LOCK == b"\x1b\x42\x02\x00\x00\x00\x17\x10"


def test_page_start_cut_modes() -> None:
    assert esc_bmp.page_start_bmp51(CutMode.END_OF_JOB) == b"\x1b\x4d\x00\x00"
    assert esc_bmp.page_start_bmp51(CutMode.END_OF_LABEL) == b"\x1b\x4d\x01\x00"
    assert esc_bmp.page_start_bmp51(CutMode.NEVER) == b"\x1b\x4d\x02\x00"


def test_graphics_line_little_endian_length() -> None:
    row = b"\xff" * 300
    out = esc_bmp.graphics_line(row)
    assert out[:2] == b"\x1b\x67"
    # length = 300 = 0x012C → 2C 01 LE
    assert out[2:4] == b"\x2c\x01"
    assert out[4:] == row


def test_empty_lines_encoding() -> None:
    assert esc_bmp.empty_lines(1) == b"\x1b\x5a\x01\x00"
    assert esc_bmp.empty_lines(0x1234) == b"\x1b\x5a\x34\x12"


def test_build_page_collapses_blank_rows() -> None:
    blank = b"\x00" * 4
    inked = b"\xff" + b"\x00" * 3
    rows = [blank, blank, inked, blank]
    out = esc_bmp.build_page(rows, cut_mode=CutMode.END_OF_JOB, compress=False)

    expected = (
        b"\x1b\x4d\x00\x00"
        + b"\x1b\x5a\x02\x00"
        + b"\x1b\x67\x04\x00"
        + inked
        + b"\x1b\x5a\x01\x00"
        + b"\x1b\x45"
    )
    assert out == expected


def test_build_job_wraps_pages() -> None:
    out = esc_bmp.build_job([[b"\xff\x00"]], cut_mode=CutMode.END_OF_JOB, compress=False)
    assert out.startswith(esc_bmp.JOB_START)
    assert out.endswith(esc_bmp.JOB_END)
    assert b"\x1b\x4d\x00\x00" in out
    assert b"\x1b\x67\x02\x00\xff\x00" in out


def test_graphics_line_rejects_oversize() -> None:
    import pytest

    with pytest.raises(ValueError):
        esc_bmp.graphics_line(b"\x00" * 0x10000)


# --- RLE encoder -------------------------------------------------------


def test_rle_all_white_row_encodes_to_single_byte() -> None:
    # 8 white pixels = one byte 0x07 (color=0, count-1=7)
    assert esc_bmp.rle_encode(b"\x00", 8) == b"\x07"


def test_rle_all_black_row_encodes_to_single_byte() -> None:
    # 8 black pixels = one byte 0x87 (color=1, count-1=7)
    assert esc_bmp.rle_encode(b"\xff", 8) == b"\x87"


def test_rle_splits_runs_longer_than_128() -> None:
    # 200 consecutive white pixels = 128 + 72 split
    row = b"\x00" * 25  # 200 bits
    encoded = esc_bmp.rle_encode(row, 200)
    assert encoded == b"\x7f\x47"  # 128 white + 72 white


def test_rle_matches_captured_hello_patterns() -> None:
    # Golden from bmp51-4.pcapng: `3a ff af` = 59w + 128b + 48b = 235 pixels.
    # Construct the 235-bit row: 59 white, 176 black, then exactly width=235.
    row = bytearray(30)  # 30 * 8 = 240 bits, we use 235
    for px in range(59, 235):
        row[px >> 3] |= 1 << (7 - (px & 7))
    encoded = esc_bmp.rle_encode(bytes(row), 235)
    assert encoded == b"\x3a\xff\xaf"


def test_rle_triple_stroke_pattern_matches_capture() -> None:
    # `3a 94 35 94 3b 93` = 59w + 21b + 54w + 21b + 60w + 20b
    spans = [(0, 59), (1, 21), (0, 54), (1, 21), (0, 60), (1, 20)]
    row = bytearray(30)
    pos = 0
    for color, count in spans:
        for _ in range(count):
            if color:
                row[pos >> 3] |= 1 << (7 - (pos & 7))
            pos += 1
    assert esc_bmp.rle_encode(bytes(row), 235) == b"\x3a\x94\x35\x94\x3b\x93"


def test_rle_line_framing() -> None:
    out = esc_bmp.rle_line(b"\xff", 8)
    assert out[:2] == b"\x1b\x68"
    assert out[2:4] == b"\x01\x00"  # 1-byte payload, little-endian
    assert out[4:] == b"\x87"


def test_build_page_uses_rle_when_smaller() -> None:
    # Uniform black row: 54 bytes raw would need `1B 67 36 00` + 54 bytes
    # = 58 bytes of framing/data. RLE needs 4 bytes of framing + `\x7f\x9b`
    # or similar — clearly smaller.
    rows = [b"\xff" * 54]
    out = esc_bmp.build_page(rows, compress=True, width_pixels=432)
    assert b"\x1b\x68" in out  # RLE chosen
    assert b"\x1b\x67" not in out  # raw not used


def test_build_page_compress_false_forces_raw() -> None:
    rows = [b"\xff" * 54]
    out = esc_bmp.build_page(rows, compress=False, width_pixels=432)
    assert b"\x1b\x67" in out
    assert b"\x1b\x68" not in out


def test_rle_decode_inverse_of_encode() -> None:
    from pybrady.protocol.esc_bmp_decode import rle_decode

    for hex_pat in ("3affaf", "7f5693", "3a9435943b93", "38937f0c93"):
        payload = bytes.fromhex(hex_pat)
        runs = rle_decode(payload)
        # Rebuild the bit pattern from runs, then re-encode, expecting the same bytes.
        row = bytearray((sum(c for _, c in runs) + 7) // 8)
        pos = 0
        for color, count in runs:
            for _ in range(count):
                if color:
                    row[pos >> 3] |= 1 << (7 - (pos & 7))
                pos += 1
        assert esc_bmp.rle_encode(bytes(row), sum(c for _, c in runs)) == payload
