# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Tests for the sequence-expression parser."""

from __future__ import annotations

import pytest

from pybrady.templates.sequence import InvalidSequenceError, expand


def test_literal_passes_through() -> None:
    assert expand("eth0") == ["eth0"]


def test_empty_expression_is_empty_list() -> None:
    assert expand("") == []
    assert expand(" ") == []


def test_simple_integer_range() -> None:
    assert expand("eth0..eth3") == ["eth0", "eth1", "eth2", "eth3"]


def test_zero_padded_range() -> None:
    # Width follows the start endpoint, so the result consistently has
    # three-digit port numbers.
    assert expand("HOST-001..HOST-004") == ["HOST-001", "HOST-002", "HOST-003", "HOST-004"]


def test_range_where_end_exceeds_start_width_grows_naturally() -> None:
    # eth0..eth10 uses width 1 (from "0"); formatting at width 1 is a
    # no-op once numbers exceed that width.
    assert expand("eth0..eth10")[:3] == ["eth0", "eth1", "eth2"]
    assert expand("eth0..eth10")[-1] == "eth10"


def test_single_element_range_yields_one_item() -> None:
    assert expand("eth5..eth5") == ["eth5"]


def test_reverse_range() -> None:
    assert expand("eth3..eth0") == ["eth3", "eth2", "eth1", "eth0"]


def test_hyphen_in_prefix_not_mistaken_for_digits() -> None:
    # The parser should anchor on the *trailing* digit group so it
    # doesn't get confused by hyphens or numbers inside the prefix.
    assert expand("rack-12-eth0..rack-12-eth2") == [
        "rack-12-eth0",
        "rack-12-eth1",
        "rack-12-eth2",
    ]


def test_comma_splices_two_expansions() -> None:
    # Common patch-panel pattern: two 24-port halves A and B.
    assert expand("A1..A3,B1..B3") == ["A1", "A2", "A3", "B1", "B2", "B3"]


def test_literal_and_range_mix_via_comma() -> None:
    assert expand("CORE,eth0..eth2,MGMT") == ["CORE", "eth0", "eth1", "eth2", "MGMT"]


def test_trailing_comma_is_tolerated() -> None:
    assert expand("eth0..eth2,") == ["eth0", "eth1", "eth2"]
    assert expand("eth0..eth2, ,") == ["eth0", "eth1", "eth2"]


def test_whitespace_around_segments_is_stripped() -> None:
    assert expand("  eth0..eth2  ,  A1..A2  ") == ["eth0", "eth1", "eth2", "A1", "A2"]


def test_rejects_mismatched_prefix() -> None:
    with pytest.raises(InvalidSequenceError, match="prefix"):
        expand("eth0..ser3")


def test_rejects_segment_with_no_digits() -> None:
    # ".." must have integer endpoints on both sides.
    with pytest.raises(InvalidSequenceError):
        expand("eth..eth")


def test_rejects_only_one_side_numeric() -> None:
    with pytest.raises(InvalidSequenceError):
        expand("eth..eth3")


# ---------------------------------------------------------------------------
# Hex ranges
# ---------------------------------------------------------------------------


def test_hex_lowercase_range() -> None:
    assert expand("0x0a..0x0d") == ["0x0a", "0x0b", "0x0c", "0x0d"]


def test_hex_uppercase_range_preserves_case() -> None:
    # Case follows the start endpoint so MAC-style labelling stays consistent.
    assert expand("0xFC..0xFF") == ["0xFC", "0xFD", "0xFE", "0xFF"]


def test_hex_zero_padded_range() -> None:
    # Width follows the start side's digits, minus the 0x marker.
    assert expand("0x00..0x02") == ["0x00", "0x01", "0x02"]


def test_hex_range_with_prefix() -> None:
    # MAC-suffix sleeve layout: identifier prefix plus hex tail.
    assert expand("MAC-0xFE..MAC-0xFF") == ["MAC-0xFE", "MAC-0xFF"]


def test_hex_range_spanning_width_boundary() -> None:
    # `0x0..0x10` uses the start width of 1; values grow past naturally.
    assert expand("0x0..0x10") == [f"0x{n:x}" for n in range(0x11)]


def test_hex_rejects_mismatched_radix() -> None:
    with pytest.raises(InvalidSequenceError, match="radices"):
        expand("0x10..16")


# ---------------------------------------------------------------------------
# Step
# ---------------------------------------------------------------------------


def test_step_every_other() -> None:
    assert expand("1..10:2") == ["1", "3", "5", "7", "9"]


def test_step_that_does_not_reach_end() -> None:
    # Step 4 goes 1,5,9 — stops before overshooting 10.
    assert expand("1..10:4") == ["1", "5", "9"]


def test_explicit_negative_step_reverses() -> None:
    assert expand("10..1:-3") == ["10", "7", "4", "1"]


def test_step_on_hex_range() -> None:
    # Hex step with decimal literal.
    assert expand("0x00..0x0F:2") == [f"0x{n:02x}" for n in range(0, 16, 2)]


def test_hex_step_in_hex_range() -> None:
    # Step itself can be hex for consistency with the endpoints.
    assert expand("0x00..0x20:0x10") == ["0x00", "0x10", "0x20"]


def test_step_after_colon_suffix_in_endpoint() -> None:
    # A prior colon in the suffix shouldn't be eaten by the step parser —
    # rpartition only pulls off the last `:<int>`.
    assert expand("port:1..port:3") == ["port:1", "port:2", "port:3"]


def test_step_rejects_zero() -> None:
    with pytest.raises(InvalidSequenceError, match="non-zero"):
        expand("1..10:0")


def test_step_rejects_wrong_direction() -> None:
    # Positive step with start > end would loop forever.
    with pytest.raises(InvalidSequenceError, match="wrong direction"):
        expand("10..1:2")
    with pytest.raises(InvalidSequenceError, match="wrong direction"):
        expand("1..10:-2")
