# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Tests for `pybrady.transport.win_spooler.WindowsSpoolerTransport`.

We mock out `win32print` entirely so these run on any platform — pywin32
isn't installable on Linux/macOS anyway. The transport imports via a
helper `_import_win32print` which tests patch to return a `FakeWin32Print`.
"""

from __future__ import annotations

import asyncio
import types
from typing import Any

import pytest

from pybrady.exceptions import TransportError
from pybrady.transport import win_spooler
from pybrady.transport.win_spooler import WindowsSpoolerTransport


class FakeWin32Print:
    """Minimal stand-in for the real `win32print` module.

    Records every call into `self.calls` as `(name, args)` so tests can
    assert on the exact spooler lifecycle the transport drove.
    """

    def __init__(
        self,
        *,
        queues: list[dict[str, Any]] | None = None,
        read_response: bytes = b"",
        open_raises: Exception | None = None,
        startdoc_raises: Exception | None = None,
    ) -> None:
        self.calls: list[tuple[str, tuple[Any, ...]]] = []
        self._queues = queues or []
        self._read_response = read_response
        self._open_raises = open_raises
        self._startdoc_raises = startdoc_raises
        self._next_handle = 0x1000
        self._next_job = 42

    def _record(self, name: str, *args: Any) -> None:
        self.calls.append((name, args))

    def EnumPrinters(self, flags: int, name: str | None, level: int) -> list[dict[str, Any]]:
        self._record("EnumPrinters", flags, name, level)
        return self._queues

    def OpenPrinter(self, name: str) -> int:
        self._record("OpenPrinter", name)
        if self._open_raises is not None:
            raise self._open_raises
        self._next_handle += 1
        return self._next_handle

    def StartDocPrinter(self, hprinter: int, level: int, info: tuple[Any, ...]) -> int:
        self._record("StartDocPrinter", hprinter, level, info)
        if self._startdoc_raises is not None:
            raise self._startdoc_raises
        job = self._next_job
        self._next_job += 1
        return job

    def StartPagePrinter(self, hprinter: int) -> None:
        self._record("StartPagePrinter", hprinter)

    def WritePrinter(self, hprinter: int, data: bytes) -> int:
        self._record("WritePrinter", hprinter, data)
        return len(data)

    # ReadPrinter is NOT exposed by pywin32; the real transport calls
    # winspool.drv!ReadPrinter via ctypes. Tests patch
    # `_read_printer_via_ctypes` directly — FakeWin32Print has no read method.

    def EndPagePrinter(self, hprinter: int) -> None:
        self._record("EndPagePrinter", hprinter)

    def EndDocPrinter(self, hprinter: int) -> None:
        self._record("EndDocPrinter", hprinter)

    def ClosePrinter(self, hprinter: int) -> None:
        self._record("ClosePrinter", hprinter)


def _patch(monkeypatch: pytest.MonkeyPatch, fake: FakeWin32Print) -> None:
    monkeypatch.setattr(win_spooler, "_import_win32print", lambda: fake)


def test_missing_pywin32_raises_transport_error(monkeypatch: pytest.MonkeyPatch) -> None:
    """The install-hint error is surfaced when win32print can't be imported."""

    def explode() -> types.ModuleType:
        raise TransportError(
            "pywin32 is not installed; install pybrady with the 'windows' "
            "extra on Windows: pip install 'pybrady[windows]'"
        )

    monkeypatch.setattr(win_spooler, "_import_win32print", explode)

    t = WindowsSpoolerTransport(printer_name="BMP51")
    with pytest.raises(TransportError, match="pywin32 is not installed"):
        asyncio.run(t.open())


def test_open_write_close_drives_full_spooler_lifecycle(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    fake = FakeWin32Print()
    _patch(monkeypatch, fake)

    async def _run() -> None:
        async with WindowsSpoolerTransport(printer_name="BMP51 (USB005)") as t:
            await t.write(b"\x1bE")  # ESC E — ESC/BMP print start
            await t.write(b"payload")

    asyncio.run(_run())

    names = [c[0] for c in fake.calls]
    assert names == [
        "OpenPrinter",
        "StartDocPrinter",
        "StartPagePrinter",
        "WritePrinter",
        "WritePrinter",
        "EndPagePrinter",
        "EndDocPrinter",
        "ClosePrinter",
    ]

    # Job-start used the caller's title and RAW datatype
    _, (hprinter, level, info) = fake.calls[1]
    assert level == 1
    assert info[0] == "pybrady"  # default job_title
    assert info[1] is None  # no output file
    assert info[2] == "RAW"

    # Both writes targeted the same hprinter returned by OpenPrinter
    assert fake.calls[3][1][0] == hprinter
    assert fake.calls[4][1][0] == hprinter
    assert fake.calls[3][1][1] == b"\x1bE"
    assert fake.calls[4][1][1] == b"payload"


def test_custom_job_title_and_datatype(monkeypatch: pytest.MonkeyPatch) -> None:
    fake = FakeWin32Print()
    _patch(monkeypatch, fake)

    async def _run() -> None:
        async with WindowsSpoolerTransport(
            printer_name="BMP51", job_title="label-batch-17", datatype="RAW"
        ) as t:
            await t.write(b"x")

    asyncio.run(_run())

    _, (_, _level, info) = fake.calls[1]
    assert info == ("label-batch-17", None, "RAW")


def test_read_returns_bytes_from_ctypes_readprinter(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """read() round-trips bytes through the ctypes ReadPrinter helper."""
    fake = FakeWin32Print()
    _patch(monkeypatch, fake)

    ctypes_calls: list[tuple[int, int]] = []
    payload = b"\x1bS" + b"\x00" * 166  # 168-byte status block

    def fake_read(hprinter: int, size: int) -> bytes:
        ctypes_calls.append((hprinter, size))
        return payload[:size]

    monkeypatch.setattr(win_spooler, "_read_printer_via_ctypes", fake_read)

    async def _run() -> bytes:
        async with WindowsSpoolerTransport(printer_name="BMP51") as t:
            await t.write(b"\x1bI\x01")  # subscribe
            return await t.read(168, timeout=2.0)

    result = asyncio.run(_run())
    assert result == payload
    assert len(ctypes_calls) == 1
    assert ctypes_calls[0][1] == 168


def test_write_before_open_raises(monkeypatch: pytest.MonkeyPatch) -> None:
    fake = FakeWin32Print()
    _patch(monkeypatch, fake)
    t = WindowsSpoolerTransport(printer_name="BMP51")
    with pytest.raises(TransportError, match="not open"):
        asyncio.run(t.write(b"x"))


def test_open_failure_releases_nothing_and_surfaces_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    fake = FakeWin32Print(open_raises=OSError("access denied"))
    _patch(monkeypatch, fake)
    t = WindowsSpoolerTransport(printer_name="BMP51")
    with pytest.raises(TransportError, match="failed to open"):
        asyncio.run(t.open())
    # OpenPrinter was attempted; nothing downstream was touched.
    assert [c[0] for c in fake.calls] == ["OpenPrinter"]


def test_startdoc_failure_still_closes_printer_handle(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    fake = FakeWin32Print(startdoc_raises=OSError("spooler busy"))
    _patch(monkeypatch, fake)
    t = WindowsSpoolerTransport(printer_name="BMP51")
    with pytest.raises(TransportError, match="failed to start print job"):
        asyncio.run(t.open())
    # OpenPrinter -> StartDocPrinter (raises) -> ClosePrinter to avoid leak
    assert [c[0] for c in fake.calls] == [
        "OpenPrinter",
        "StartDocPrinter",
        "ClosePrinter",
    ]


def test_close_is_idempotent(monkeypatch: pytest.MonkeyPatch) -> None:
    fake = FakeWin32Print()
    _patch(monkeypatch, fake)

    async def _run() -> None:
        t = WindowsSpoolerTransport(printer_name="BMP51")
        await t.open()
        await t.close()
        await t.close()  # second call is a no-op

    asyncio.run(_run())

    # Only one EndDocPrinter / ClosePrinter pair regardless of extra close() calls
    assert [c[0] for c in fake.calls].count("ClosePrinter") == 1


def test_list_printers_returns_names(monkeypatch: pytest.MonkeyPatch) -> None:
    queues = [
        {"pPrinterName": "Microsoft Print to PDF", "pDriverName": "MS Print to PDF"},
        {"pPrinterName": "BMP51 (USB005) - direct", "pDriverName": "Brady BMP51"},
    ]
    fake = FakeWin32Print(queues=queues)
    _patch(monkeypatch, fake)

    assert WindowsSpoolerTransport.list_printers() == [
        "Microsoft Print to PDF",
        "BMP51 (USB005) - direct",
    ]


def test_find_bmp51_picks_bmp51_queue(monkeypatch: pytest.MonkeyPatch) -> None:
    queues = [
        {"pPrinterName": "Microsoft Print to PDF", "pDriverName": "MS Print to PDF"},
        {"pPrinterName": "BMP51 (USB005) - direct", "pDriverName": "Brady BMP51"},
        {"pPrinterName": "OneNote", "pDriverName": "Send To OneNote"},
    ]
    fake = FakeWin32Print(queues=queues)
    _patch(monkeypatch, fake)

    t = WindowsSpoolerTransport.find_bmp51()
    assert t._printer_name == "BMP51 (USB005) - direct"


def test_find_bmp51_matches_driver_name_when_queue_is_generic(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    queues = [
        # Queue named arbitrarily by the user but driver identifies the model.
        {"pPrinterName": "Label Printer", "pDriverName": "Brady BMP51 v1.0"},
    ]
    _patch(monkeypatch, FakeWin32Print(queues=queues))
    assert WindowsSpoolerTransport.find_bmp51()._printer_name == "Label Printer"


def test_find_bmp51_raises_with_available_queues_listed(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    queues = [
        {"pPrinterName": "OneNote", "pDriverName": "Send To OneNote"},
        {"pPrinterName": "Microsoft Print to PDF", "pDriverName": "MS Print to PDF"},
    ]
    _patch(monkeypatch, FakeWin32Print(queues=queues))

    with pytest.raises(TransportError, match="OneNote, Microsoft Print to PDF"):
        WindowsSpoolerTransport.find_bmp51()


def test_find_bmp51_raises_cleanly_when_no_queues_exist(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _patch(monkeypatch, FakeWin32Print(queues=[]))
    with pytest.raises(TransportError, match=r"\(none\)"):
        WindowsSpoolerTransport.find_bmp51()
