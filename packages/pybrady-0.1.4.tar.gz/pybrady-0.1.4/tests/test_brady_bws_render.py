# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Tests for the `.bws`/`.bwt` render pipeline."""

from __future__ import annotations

from pathlib import Path

import pytest
from PIL import Image

from pybrady.templates.brady_bws import BwsFont
from pybrady.templates.brady_bws_render import (
    RenderedLabel,
    _barcode_symbology_for,
    _bounds_from_entities,
    _index_fonts,
    _label_dimensions_from_part_info,
    _resolve_font_file,
    render_bws,
)

_USER_BWS_SAMPLE = Path("/mnt/c/Users/Public/Documents/Brady Corp/Brady Workstation/Hello.BWS")
# MixedLabel.BWS exercises the per-run formatting path — paragraph 0 has a
# regular-weight run followed by a bold-italic run (same font family, same
# size). Saved locally, not redistributed.
_MIXED_SAMPLE = Path("/mnt/c/Users/Public/Documents/Brady Corp/Brady Workstation/MixedLabel.BWS")
_BARCODE_TEMPLATE = Path(
    "/mnt/c/ProgramData/Brady Corp/Brady Workstation/Addins/AssetApp/"
    "Templates/BBP11/Continuous/1/1 x 2 inch Barcode 128 - My Asset Tags.BWT"
)
_QR_TEMPLATE = Path(
    "/mnt/c/ProgramData/Brady Corp/Brady Workstation/Addins/AssetApp/"
    "Templates/BBP11/Continuous/1/1 x 3 inch QR Barcode with Text - My Asset Tags.BWT"
)


_PART_INFO_1X3 = """<?xml version="1.0" encoding="utf-16"?>
<PartsDatabase FileSchemaVersion="1.0">
  <Parts>
    <Part ID="{dummy}">
      <Name>MC1-1000</Name>
      <Width>10000</Width>
      <Height>30000</Height>
    </Part>
  </Parts>
</PartsDatabase>"""


def test_part_info_parses_dimensions_portrait() -> None:
    # Portrait mode: return the raw (W, H) as-is.
    assert _label_dimensions_from_part_info(_PART_INFO_1X3, landscape=False) == (1.0, 3.0)


def test_part_info_parses_dimensions_landscape() -> None:
    # Landscape mode swaps so the wider dimension is reported as width.
    assert _label_dimensions_from_part_info(_PART_INFO_1X3, landscape=True) == (3.0, 1.0)


def test_part_info_returns_none_for_malformed_xml() -> None:
    assert _label_dimensions_from_part_info("<not xml", landscape=True) is None
    assert _label_dimensions_from_part_info("", landscape=True) is None
    assert _label_dimensions_from_part_info("<Unrelated/>", landscape=True) is None


def test_part_info_returns_none_for_zero_dimensions() -> None:
    xml = _PART_INFO_1X3.replace("<Width>10000</Width>", "<Width>0</Width>")
    assert _label_dimensions_from_part_info(xml, landscape=True) is None


def test_bounds_from_entities_uses_max_corner() -> None:
    class _Common:
        def __init__(self, pos: tuple[float, float], w: float, h: float) -> None:
            self.position = pos
            self.width = w
            self.height = h

    class _Text:
        def __init__(self, c: _Common) -> None:
            self.common = c

    class _Barcode:
        def __init__(self, c: _Common) -> None:
            self.common = c

    texts = [_Text(_Common((0.5, 0.25), 1.0, 0.5))]  # extends to (1.5, 0.75)
    barcodes = [_Barcode(_Common((0.1, 0.1), 2.0, 0.8))]  # extends to (2.1, 0.9)

    assert _bounds_from_entities(texts, barcodes) == (2.1, 0.9)  # type: ignore[arg-type]


def _make_font(family: str, *, bold: bool = False, italic: bool = False) -> BwsFont:
    return BwsFont(
        family=family,
        size=12.0,
        bold=bold,
        italic=italic,
        strike_out=False,
        underline=False,
        all_caps=False,
        baseline_alignment=0,
        color=None,
    )


def test_index_fonts_only_picks_up_truetype_files(tmp_path: Path) -> None:
    (tmp_path / "Brady Alpine.ttf").write_bytes(b"")
    (tmp_path / "Some Other.otf").write_bytes(b"")
    (tmp_path / "ignore-me.txt").write_bytes(b"")

    index = _index_fonts(tmp_path)

    # Keys are the lowercased stem so lookup is case-insensitive.
    assert set(index.keys()) == {"brady alpine", "some other"}
    assert index["brady alpine"].name == "Brady Alpine.ttf"


def test_index_fonts_returns_empty_for_missing_dir(tmp_path: Path) -> None:
    assert _index_fonts(tmp_path / "does-not-exist") == {}


def test_resolve_font_file_picks_matching_family(tmp_path: Path) -> None:
    (tmp_path / "Brady Alpine.ttf").write_bytes(b"")
    (tmp_path / "Brady Alpine Bold.ttf").write_bytes(b"")
    index = _index_fonts(tmp_path)

    plain = _resolve_font_file(_make_font("Brady Alpine"), index)
    bold = _resolve_font_file(_make_font("Brady Alpine", bold=True), index)

    assert plain is not None and plain.name == "Brady Alpine.ttf"
    assert bold is not None and bold.name == "Brady Alpine Bold.ttf"


def test_resolve_font_file_falls_back_to_plain_when_no_variant(tmp_path: Path) -> None:
    # Only the plain variant exists; a bold/italic request should fall back
    # rather than returning None (that would lose the font substitution).
    (tmp_path / "Brady Alpine.ttf").write_bytes(b"")
    index = _index_fonts(tmp_path)

    resolved = _resolve_font_file(_make_font("Brady Alpine", bold=True), index)

    assert resolved is not None and resolved.name == "Brady Alpine.ttf"


def test_resolve_font_file_returns_none_when_unknown_family(tmp_path: Path) -> None:
    (tmp_path / "Brady Alpine.ttf").write_bytes(b"")
    index = _index_fonts(tmp_path)

    assert _resolve_font_file(_make_font("Arial"), index) is None
    assert _resolve_font_file(_make_font(""), index) is None


def test_barcode_symbology_map_covers_common_types() -> None:
    class _B:
        def __init__(self, name: str) -> None:
            self.barcode_type_name = name

    assert _barcode_symbology_for(_B("Code128")) == "code128"  # type: ignore[arg-type]
    assert _barcode_symbology_for(_B("Code39")) == "code39"  # type: ignore[arg-type]
    assert _barcode_symbology_for(_B("QR")) == "qr"  # type: ignore[arg-type]
    assert _barcode_symbology_for(_B("EAN13")) == "ean13"  # type: ignore[arg-type]
    assert _barcode_symbology_for(_B("DataMatrix")) == "datamatrix"  # type: ignore[arg-type]
    assert _barcode_symbology_for(_B("PDF417")) == "pdf417"  # type: ignore[arg-type]
    # Symbologies pybrady can't yet render still return None so the
    # BWS renderer skips them gracefully (none in the current set).
    assert _barcode_symbology_for(_B("CodablockF")) is None  # type: ignore[arg-type]


# ---------------------------------------------------------------------------
# Integration tests against real Brady Workstation files
# ---------------------------------------------------------------------------


def _count_ink(image: Image.Image) -> int:
    # Pillow 14 will drop getdata(); the replacement is get_flattened_data.
    getter = getattr(image, "get_flattened_data", image.getdata)
    return sum(1 for v in getter() if v == 0)


@pytest.mark.skipif(not _USER_BWS_SAMPLE.exists(), reason="requires local Brady Workstation")
def test_render_user_label_with_substituted_values() -> None:
    rendered = render_bws(_USER_BWS_SAMPLE, values={"Text 1": "HELLO", "Text 2": "WORLD"})

    assert isinstance(rendered, RenderedLabel)
    # Hello.BWS is on 1"x3" media in portrait; renders landscape at 3"x1".
    assert rendered.width_in == pytest.approx(3.0)
    assert rendered.height_in == pytest.approx(1.0)
    assert rendered.dpi == 300
    assert rendered.image.size == (900, 300)
    assert rendered.image.mode == "1"

    ink_filled = _count_ink(rendered.image)
    # With text, there must be some ink on the label.
    assert ink_filled > 0

    # Rendering without values: the same template-prompt slots stay empty,
    # so the label should have strictly less ink.
    empty = render_bws(_USER_BWS_SAMPLE)
    assert _count_ink(empty.image) < ink_filled


@pytest.mark.skipif(not _BARCODE_TEMPLATE.exists(), reason="requires the AssetApp BBP11 templates")
def test_render_barcode_template_produces_ink() -> None:
    rendered = render_bws(_BARCODE_TEMPLATE)

    # BBP11 "1 x 2 inch" template is 2"x1" landscape at 300 DPI.
    assert rendered.image.size == (600, 300)
    # A Code128 of "BARCODE 128" fills a large fraction of the label.
    assert _count_ink(rendered.image) > 10_000


@pytest.mark.skipif(not _QR_TEMPLATE.exists(), reason="requires the AssetApp BBP11 templates")
def test_render_qr_template_produces_a_square_region_of_ink() -> None:
    rendered = render_bws(_QR_TEMPLATE, values={"Text": "ASSET-00042"})

    # 1"x3" media in landscape.
    assert rendered.image.size == (900, 300)
    # QR + text should have meaningful ink density.
    assert _count_ink(rendered.image) > 5_000


@pytest.mark.skipif(
    not _MIXED_SAMPLE.exists(), reason="requires MixedLabel.BWS in Public Documents"
)
def test_render_preserves_mixed_run_formatting() -> None:
    # MixedLabel.BWS has two runs in one paragraph: "BORK" regular, then
    # "BORKBORK" bold italic. Rendering without value substitution must
    # go through the per-run path; the canvas size matches the file's
    # PartInfo geometry and the output carries real ink.
    #
    # We don't compare pixel-for-pixel against the substituted-value path
    # because font fallbacks (no Arial locally) can make bold-italic
    # collapse to the same file as regular, hiding the style difference.
    # On a host with proper Arial Bold Italic installed the two paths
    # would diverge visibly — that's tested manually by eye, not here.
    from pybrady.templates import read_text_entities

    as_stored = render_bws(_MIXED_SAMPLE)
    assert as_stored.image.mode == "1"
    assert _count_ink(as_stored.image) > 0

    # Confirm that the per-run path is actually what produced the output —
    # i.e. the entity genuinely has multiple runs, not just one flattened.
    entities = read_text_entities(_MIXED_SAMPLE)
    assert entities
    assert any(len(p.runs) > 1 for te in entities for p in te.paragraphs)


def test_size_inches_override_is_respected(tmp_path: Path) -> None:
    # Use the real template since the renderer needs actual entity data to
    # produce meaningful output; but force a non-default canvas size.
    if not _BARCODE_TEMPLATE.exists():
        pytest.skip("requires the AssetApp BBP11 templates")
    rendered = render_bws(_BARCODE_TEMPLATE, size_inches=(4.0, 1.5), dpi=200)

    assert rendered.width_in == 4.0
    assert rendered.height_in == 1.5
    assert rendered.dpi == 200
    assert rendered.image.size == (800, 300)
