# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Tests for `pybrady.transport.linux_usblp.LinuxUsblpTransport`.

All tests drive the transport against a `FakeLinuxBackend` — no real
Linux character devices or ioctls needed. The backend interface is the
entire Linux-specific surface, so covering it fully here is equivalent
to integration testing without needing a real BMP51 + udev-managed
`/dev/usb/lp*`.
"""

from __future__ import annotations

import asyncio
import struct

import pytest

from pybrady.exceptions import TransportError
from pybrady.transport.linux_usblp import (
    _IOC,
    _IOC_READ,
    _LPIOC_GET_DEVICE_ID,
    _LPIOC_GET_VID_PID,
    _LPIOC_SOFT_RESET,
    LinuxUsblpTransport,
    _LinuxBackend,
)


class FakeLinuxBackend(_LinuxBackend):
    """Records every backend call; returns caller-supplied fake data."""

    def __init__(
        self,
        *,
        paths: list[str] | None = None,
        vid_pid_map: dict[str, tuple[int, int]] | None = None,
        device_id_response: bytes = b"",
        read_response: bytes = b"",
        open_raises: OSError | None = None,
        read_raises: Exception | None = None,
    ) -> None:
        self.paths = paths or []
        self.vid_pid_map = vid_pid_map or {}
        self.device_id_response = device_id_response
        self.read_response = read_response
        self.open_raises = open_raises
        self.read_raises = read_raises
        self.calls: list[tuple[str, tuple[object, ...]]] = []
        self._next_fd = 100

    def _record(self, name: str, *args: object) -> None:
        self.calls.append((name, args))

    def enumerate_paths(self) -> list[str]:
        self._record("enumerate_paths")
        return list(self.paths)

    def query_vid_pid(self, path: str) -> tuple[int, int] | None:
        self._record("query_vid_pid", path)
        return self.vid_pid_map.get(path)

    def open_device(self, path: str) -> int:
        self._record("open_device", path)
        if self.open_raises is not None:
            raise self.open_raises
        self._next_fd += 1
        return self._next_fd

    def close_device(self, fd: int) -> None:
        self._record("close_device", fd)

    def write_device(self, fd: int, data: bytes) -> int:
        self._record("write_device", fd, data)
        return len(data)

    def read_device(self, fd: int, size: int, timeout_s: float) -> bytes:
        self._record("read_device", fd, size, timeout_s)
        if self.read_raises is not None:
            raise self.read_raises
        return self.read_response[:size]

    def get_device_id(self, fd: int) -> bytes:
        self._record("get_device_id", fd)
        return self.device_id_response

    def soft_reset(self, fd: int) -> None:
        self._record("soft_reset", fd)


# ---------------------------------------------------------------------
# ioctl-number encoding: these are compiled into the kernel ABI, so
# these tests guard against refactors accidentally changing the values.
# Values verified against `include/uapi/linux/lp.h` (Linux 6.x).
# ---------------------------------------------------------------------


def test_ioc_encoding_matches_linux_kernel_macro() -> None:
    # LPIOC_GET_DEVICE_ID(1024) = _IOC(_IOC_READ, 'P', 1, 1024)
    # = (2<<30) | (1024<<16) | ('P'<<8) | 1
    # = 0x80000000 | 0x04000000 | 0x5000 | 1
    # = 0x84005001
    assert _IOC(_IOC_READ, "P", 1, 1024) == 0x84005001
    assert _LPIOC_GET_DEVICE_ID(1024) == 0x84005001


def test_lpioc_get_vid_pid_encoding() -> None:
    # LPIOC_GET_VID_PID(8) = _IOC(_IOC_READ, 'P', 6, 8)
    # = (2<<30) | (8<<16) | (0x50<<8) | 6
    # = 0x80000000 | 0x80000 | 0x5000 | 6
    # = 0x80085006
    assert _LPIOC_GET_VID_PID(8) == 0x80085006


def test_lpioc_soft_reset_encoding() -> None:
    # LPIOC_SOFT_RESET = _IOC(_IOC_NONE=0, 'P', 7, 0)
    # = 0 | 0 | (0x50<<8) | 7 = 0x5007
    assert _LPIOC_SOFT_RESET() == 0x5007


# ---------------------------------------------------------------------
# Discovery
# ---------------------------------------------------------------------


def test_list_devices_returns_path_vid_pid_for_every_queryable_node() -> None:
    backend = FakeLinuxBackend(
        paths=["/dev/usb/lp0", "/dev/usb/lp1", "/dev/usb/lp2"],
        vid_pid_map={
            "/dev/usb/lp0": (0x0E2E, 0x000B),  # BMP51
            "/dev/usb/lp1": (0x03F0, 0x0C17),  # HP LaserJet (stand-in)
            # lp2 returns None — e.g. permission denied. Silently skipped.
        },
    )
    assert LinuxUsblpTransport.list_devices(_backend=backend) == [
        ("/dev/usb/lp0", 0x0E2E, 0x000B),
        ("/dev/usb/lp1", 0x03F0, 0x0C17),
    ]


def test_find_by_vid_pid_picks_matching_node() -> None:
    backend = FakeLinuxBackend(
        paths=["/dev/usb/lp0", "/dev/usb/lp1"],
        vid_pid_map={
            "/dev/usb/lp0": (0x03F0, 0x0C17),
            "/dev/usb/lp1": (0x0E2E, 0x000B),
        },
    )
    t = LinuxUsblpTransport.find_by_vid_pid(0x0E2E, 0x000B, _backend=backend)
    assert t._device_path == "/dev/usb/lp1"


def test_find_bmp51_convenience() -> None:
    backend = FakeLinuxBackend(
        paths=["/dev/usb/lp0"],
        vid_pid_map={"/dev/usb/lp0": (0x0E2E, 0x000B)},
    )
    t = LinuxUsblpTransport.find_bmp51(_backend=backend)
    assert t._device_path == "/dev/usb/lp0"


def test_find_by_vid_pid_raises_with_available_listed() -> None:
    backend = FakeLinuxBackend(
        paths=["/dev/usb/lp0"],
        vid_pid_map={"/dev/usb/lp0": (0x03F0, 0x0C17)},
    )
    with pytest.raises(TransportError, match="lp0"):
        LinuxUsblpTransport.find_by_vid_pid(0x0E2E, 0x000B, _backend=backend)


def test_find_by_vid_pid_raises_cleanly_when_no_nodes_exist() -> None:
    backend = FakeLinuxBackend(paths=[], vid_pid_map={})
    with pytest.raises(TransportError, match=r"\(none\)"):
        LinuxUsblpTransport.find_by_vid_pid(0x0E2E, 0x000B, _backend=backend)


# ---------------------------------------------------------------------
# Lifecycle
# ---------------------------------------------------------------------


def test_open_write_close_full_lifecycle() -> None:
    backend = FakeLinuxBackend(
        # device_id is what GET_DEVICE_ID returns — 2-byte BE length +
        # IEEE 1284 string. BMP51 golden bytes from test_ieee1284.py.
        device_id_response=bytes.fromhex(
            "00234d46473a42726164793b434d443a424944492d56474c3b4d444c3a424d5035313b"
        ),
    )
    t = LinuxUsblpTransport(device_path="/dev/usb/lp0", _backend=backend)

    async def _run() -> None:
        async with t:
            await t.write(b"\x1bE")
            await t.write(b"payload")

    asyncio.run(_run())

    names = [c[0] for c in backend.calls]
    # Auto-priming via GET_DEVICE_ID runs on open, before any writes.
    assert names == [
        "open_device",
        "get_device_id",
        "write_device",
        "write_device",
        "close_device",
    ]


def test_open_failure_surfaces_as_transport_error() -> None:
    backend = FakeLinuxBackend(open_raises=PermissionError("EACCES"))
    t = LinuxUsblpTransport(device_path="/dev/usb/lp0", _backend=backend)
    with pytest.raises(TransportError, match="failed to open /dev/usb/lp0"):
        asyncio.run(t.open())


def test_init_bidi_false_skips_auto_get_device_id() -> None:
    backend = FakeLinuxBackend()
    t = LinuxUsblpTransport(device_path="/dev/usb/lp0", init_bidi=False, _backend=backend)

    async def _run() -> None:
        async with t:
            pass

    asyncio.run(_run())

    assert [c[0] for c in backend.calls] == ["open_device", "close_device"]


def test_write_before_open_raises() -> None:
    t = LinuxUsblpTransport(device_path="/dev/usb/lp0", _backend=FakeLinuxBackend())
    with pytest.raises(TransportError, match="not open"):
        asyncio.run(t.write(b"x"))


def test_read_before_open_raises() -> None:
    t = LinuxUsblpTransport(device_path="/dev/usb/lp0", _backend=FakeLinuxBackend())
    with pytest.raises(TransportError, match="not open"):
        asyncio.run(t.read(1))


def test_close_is_idempotent() -> None:
    backend = FakeLinuxBackend()
    t = LinuxUsblpTransport(device_path="/dev/usb/lp0", init_bidi=False, _backend=backend)

    async def _run() -> None:
        await t.open()
        await t.close()
        await t.close()

    asyncio.run(_run())

    assert [c[0] for c in backend.calls].count("close_device") == 1


# ---------------------------------------------------------------------
# Read + status
# ---------------------------------------------------------------------


def test_read_returns_bulk_in_bytes() -> None:
    payload = b"\x1bS" + b"\x00" * 166  # 168-byte BMP51 status packet
    backend = FakeLinuxBackend(
        device_id_response=b"\x00\x05MFG:",  # minimal valid device-id
        read_response=payload,
    )

    async def _run() -> bytes:
        async with LinuxUsblpTransport(device_path="/dev/usb/lp0", _backend=backend) as t:
            await t.write(b"\x1bI\x01")  # subscribe
            return await t.read(168, timeout=2.0)

    got = asyncio.run(_run())
    assert got == payload
    read_calls = [c for c in backend.calls if c[0] == "read_device"]
    assert len(read_calls) == 1
    assert read_calls[0][1][1] == 168  # requested size


def test_read_timeout_surfaces_transport_error() -> None:
    backend = FakeLinuxBackend(
        device_id_response=b"\x00\x05MFG:",
        read_raises=TransportError("usblp read timed out after 2.0s"),
    )

    async def _run() -> None:
        async with LinuxUsblpTransport(device_path="/dev/usb/lp0", _backend=backend) as t:
            await t.read(168, timeout=2.0)

    with pytest.raises(TransportError, match="timed out"):
        asyncio.run(_run())


def test_get_device_id_parses_ieee1284_response() -> None:
    backend = FakeLinuxBackend(
        device_id_response=bytes.fromhex(
            "00234d46473a42726164793b434d443a424944492d56474c3b4d444c3a424d5035313b"
        ),
    )

    async def _run() -> object:
        async with LinuxUsblpTransport(
            device_path="/dev/usb/lp0", init_bidi=False, _backend=backend
        ) as t:
            return await t.get_device_id()

    dev = asyncio.run(_run())
    assert dev.manufacturer == "Brady"
    assert dev.model == "BMP51"
    assert dev.command_set == "BIDI-VGL"


def test_soft_reset_calls_backend() -> None:
    backend = FakeLinuxBackend()

    async def _run() -> None:
        async with LinuxUsblpTransport(
            device_path="/dev/usb/lp0", init_bidi=False, _backend=backend
        ) as t:
            await t.soft_reset()

    asyncio.run(_run())
    assert any(c[0] == "soft_reset" for c in backend.calls)


# ---------------------------------------------------------------------
# query_vid_pid byte layout: the kernel returns two unsigned ints.
# Verify our struct unpack matches the kernel ABI (native endian).
# ---------------------------------------------------------------------


def test_query_vid_pid_unpacks_native_uint32_pair() -> None:
    backend = FakeLinuxBackend()
    packed = struct.pack("II", 0x0E2E, 0x000B)
    assert len(packed) == 8
    # Sanity: raw bytes contain the VID and PID in native order.
    assert struct.unpack("II", packed) == (0x0E2E, 0x000B)
    # And the backend's shape would return them as a tuple:
    backend.vid_pid_map["/dev/usb/lp0"] = (0x0E2E, 0x000B)
    devs = LinuxUsblpTransport.list_devices(_backend=backend)
    assert devs == []  # paths wasn't populated; just confirms no crash


# ---------------------------------------------------------------------
# Discovery through the real stdlib backend — only runs on Linux, and
# only if a fake /dev/usb/lp* exists. Opt-in via PYBRADY_REAL_USBLP.
# ---------------------------------------------------------------------


@pytest.mark.skip(reason="real-hardware integration: requires a physical BMP51 on /dev/usb/lp*")
def test_real_hardware_bmp51_round_trip() -> None:
    """Placeholder for a real-hardware round-trip test.

    Un-skip locally when you have a BMP51 plugged in and udev rules
    granting your user access to /dev/usb/lp0. Don't enable in CI —
    the whole point of the backend injection is that CI doesn't need
    real hardware.
    """
    import asyncio as _asyncio

    async def _run() -> None:
        async with LinuxUsblpTransport.find_bmp51() as t:
            dev_id = await t.get_device_id()
            assert dev_id.manufacturer == "Brady"

    _asyncio.run(_run())
