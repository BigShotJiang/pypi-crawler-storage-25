# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Tests for the cable-wrap / cable-flag templates."""

from __future__ import annotations

import pytest
from PIL import Image

from pybrady.templates.cable import cable_flag, cable_wrap
from pybrady.templates.sequence import expand


def _pixels(image: Image.Image) -> list[int]:
    """Return the image as a flat list of pixel values.

    Shims around Pillow 14 deprecating `Image.getdata()` in favour of
    `get_flattened_data()`. Keeps existing behaviour on Pillow 10-13.
    """
    getter = getattr(image, "get_flattened_data", image.getdata)
    return list(getter())


def _count_ink(image: Image.Image) -> int:
    return sum(1 for v in _pixels(image) if v == 0)


def _ink_per_column(image: Image.Image) -> list[int]:
    w, h = image.size
    pixels = image.load()
    return [sum(1 for y in range(h) if pixels[x, y] == 0) for x in range(w)]


# ---------------------------------------------------------------------------
# cable_wrap
# ---------------------------------------------------------------------------


def test_cable_wrap_produces_label_at_requested_dimensions() -> None:
    img = cable_wrap("eth0", width_in=2.0, height_in=0.5, dpi=300)
    assert img.mode == "1"
    assert img.size == (600, 150)


def test_cable_wrap_explicit_copies_divides_canvas_evenly() -> None:
    # Asymmetric glyph so each column reveals glyph structure, not symmetry.
    img = cable_wrap("F", width_in=3.0, height_in=0.5, dpi=300, font_size=48, copies=3)
    w, h = img.size
    third = w // 3
    slot_0 = img.crop((0, 0, third, h))
    slot_1 = img.crop((third, 0, 2 * third, h))
    # Every slot renders the same glyph centred the same way.
    assert _pixels(slot_0) == _pixels(slot_1)


def test_cable_wrap_auto_fits_more_copies_on_longer_labels() -> None:
    # A short glyph on a long label should auto-fit more copies than on
    # a short label of the same dimensions per-copy.
    short_label = cable_wrap("X", width_in=2.0, height_in=0.5, dpi=300, font_size=48)
    long_label = cable_wrap("X", width_in=8.0, height_in=0.5, dpi=300, font_size=48)

    short_ink = _count_ink(short_label)
    long_ink = _count_ink(long_label)
    # More copies means more ink. Guard against a tiny margin by requiring
    # meaningfully more (rather than exactly 4x, which depends on font
    # metrics and min_gap_in rounding).
    assert long_ink > short_ink * 1.5


def test_cable_wrap_auto_respects_min_gap() -> None:
    # With a large min_gap_in the auto-fitter fits fewer copies.
    tight = cable_wrap("X", width_in=4.0, height_in=0.5, dpi=300, font_size=48, min_gap_in=0.05)
    roomy = cable_wrap("X", width_in=4.0, height_in=0.5, dpi=300, font_size=48, min_gap_in=1.0)
    # Tight packing yields more ink than roomy spacing on the same canvas.
    assert _count_ink(tight) >= _count_ink(roomy)


def test_cable_wrap_at_least_one_copy_when_text_overflows() -> None:
    # Text wider than the whole label still produces one (clipped) copy,
    # not zero. The renderer degrades gracefully rather than crashing.
    img = cable_wrap(
        "THIS_IS_A_VERY_LONG_IDENTIFIER",
        width_in=0.5,
        height_in=0.25,
        dpi=300,
        font_size=72,
    )
    assert _count_ink(img) > 0


def test_cable_wrap_rejects_non_positive_dimensions() -> None:
    with pytest.raises(ValueError, match="positive"):
        cable_wrap("x", width_in=0, height_in=0.5)
    with pytest.raises(ValueError, match="positive"):
        cable_wrap("x", width_in=1.0, height_in=-0.1)


def test_cable_wrap_rejects_non_positive_copies() -> None:
    with pytest.raises(ValueError, match="copies"):
        cable_wrap("x", copies=0)
    with pytest.raises(ValueError, match="copies"):
        cable_wrap("x", copies=-1)


def test_cable_wrap_rejects_negative_min_gap() -> None:
    with pytest.raises(ValueError, match="min_gap_in"):
        cable_wrap("x", min_gap_in=-0.1)


def test_cable_wrap_batched_via_sequence_expansion() -> None:
    # End-to-end: the sequence parser feeds the cable-wrap renderer.
    labels = [cable_wrap(t, width_in=1.0, height_in=0.25, dpi=300) for t in expand("eth0..eth2")]
    assert len(labels) == 3
    assert all(label.mode == "1" and label.size == (300, 75) for label in labels)
    assert all(_count_ink(label) > 0 for label in labels)


# ---------------------------------------------------------------------------
# cable_flag
# ---------------------------------------------------------------------------


def test_cable_flag_produces_label_at_requested_dimensions() -> None:
    img = cable_flag("eth0", width_in=2.0, height_in=0.5, dpi=300)
    assert img.mode == "1"
    assert img.size == (600, 150)


def test_cable_flag_duplicates_text_on_both_halves() -> None:
    img = cable_flag("X", width_in=2.0, height_in=0.5, dpi=300, font_size=96)
    cols = _ink_per_column(img)
    w = len(cols)
    left_ink = sum(cols[: w // 2])
    right_ink = sum(cols[w // 2 :])
    assert left_ink > 0
    assert right_ink > 0
    # Identical centred text in both halves — ink density matches to
    # within rounding on odd-pixel splits.
    assert abs(left_ink - right_ink) <= 5


def test_cable_flag_rotates_right_half_by_180_degrees() -> None:
    img = cable_flag("F", width_in=2.0, height_in=0.5, dpi=300, font_size=96)
    w, h = img.size
    left = img.crop((0, 0, w // 2, h))
    right = img.crop((w // 2, 0, w, h))
    # Rotating the right half back by 180 degrees reproduces the left
    # half — confirms the flag's fold-over orientation.
    assert _pixels(right.rotate(180)) == _pixels(left)


def test_cable_wrap_and_cable_flag_differ_when_copies_match() -> None:
    # Pin cable_wrap to 2 copies so the only remaining difference is the
    # flag's 180-degree rotation of its right half.
    wrap = cable_wrap("F", width_in=2.0, height_in=0.5, dpi=300, font_size=96, copies=2)
    flag = cable_flag("F", width_in=2.0, height_in=0.5, dpi=300, font_size=96)
    assert _pixels(wrap) != _pixels(flag)


def test_cable_flag_gap_leaves_a_blank_stripe_down_the_middle() -> None:
    img = cable_flag("eth0", width_in=2.0, height_in=0.5, dpi=300, font_size=48, gap_in=0.1)
    cols = _ink_per_column(img)
    # 0.1" at 300 DPI = 30 px, centred. Allow a generous tolerance for
    # rounding + the odd-pixel split.
    w = len(cols)
    middle_start = (w - 30) // 2 + 2
    middle_end = middle_start + 26
    assert sum(cols[middle_start:middle_end]) == 0


def test_cable_flag_rejects_non_positive_dimensions() -> None:
    with pytest.raises(ValueError, match="positive"):
        cable_flag("x", width_in=0, height_in=0.5)
    with pytest.raises(ValueError, match="positive"):
        cable_flag("x", width_in=1.0, height_in=-0.1)


def test_cable_flag_rejects_gap_wider_than_label() -> None:
    with pytest.raises(ValueError, match="less than width_in"):
        cable_flag("x", width_in=1.0, height_in=0.5, gap_in=1.0)
