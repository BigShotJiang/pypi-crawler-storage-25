# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Smoke tests for the brady-print CLI — dry-run paths only, no hardware."""

from __future__ import annotations

from pathlib import Path

import pytest

from pybrady.cli import main
from pybrady.exceptions import UnsupportedModelError


def test_list_models(capsys: pytest.CaptureFixture[str]) -> None:
    rc = main(["--list-models"])
    out = capsys.readouterr().out
    assert rc == 0
    assert "BMP51" in out
    assert "esc_bmp" in out


def test_dry_run_text(capsys: pytest.CaptureFixture[str]) -> None:
    rc = main(["--text", "HELLO", "--dry-run"])
    out = capsys.readouterr().out
    assert rc == 0
    assert "job_start: 1" in out
    assert "job_end: 1" in out
    # RLE is on by default for text labels; check either the RLE or the
    # raw-graphics counter is reported (both are valid raster lines).
    assert "rle_line:" in out or "graphics_line:" in out


def test_dry_run_save_roundtrip(tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
    out_file = tmp_path / "hello.prn"
    rc = main(["--text", "HI", "--dry-run", "--save", str(out_file)])
    assert rc == 0
    data = out_file.read_bytes()
    assert data.startswith(b"\x1b\x58\x00")  # JOB_START
    assert data.endswith(b"\x1b\x44")  # JOB_END
    assert str(out_file) in capsys.readouterr().out


def test_rejects_unknown_cut_for_bmp51() -> None:
    # BMP51 declares only END_OF_JOB/END_OF_LABEL; `never` must be refused.
    with pytest.raises(UnsupportedModelError, match="NEVER"):
        main(["--text", "X", "--cut", "never", "--dry-run"])
