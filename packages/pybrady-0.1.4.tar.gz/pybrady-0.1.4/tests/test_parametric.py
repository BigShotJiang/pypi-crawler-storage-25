# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Tests for the generic from_row / from_rows / render_from_csv helpers."""

from __future__ import annotations

import csv
from pathlib import Path

import pytest

from pybrady.templates.parametric import from_row, from_rows, render_from_csv


def _sink(**kwargs: object) -> dict[str, object]:
    """Stand-in 'template' that just returns whatever kwargs reach it."""
    return kwargs


def _typed_sink(text: str, *, copies: int = 1, font: str = "Arial") -> dict[str, object]:
    """Typed signature so we can exercise unknown-key filtering."""
    return {"text": text, "copies": copies, "font": font}


def _var_kwargs_sink(**kwargs: object) -> dict[str, object]:
    """Variant that takes **kwargs so the filter must pass everything through."""
    return kwargs


def test_from_row_passes_matching_keys_through() -> None:
    assert from_row(_typed_sink, {"text": "hello", "copies": 3}) == {
        "text": "hello",
        "copies": 3,
        "font": "Arial",
    }


def test_from_row_drops_unknown_keys() -> None:
    # 'extra' isn't a parameter of _typed_sink; must be silently dropped
    # so the same CSV can feed several templates with non-overlapping
    # columns.
    result = from_row(_typed_sink, {"text": "hi", "extra": "junk"})
    assert result == {"text": "hi", "copies": 1, "font": "Arial"}


def test_from_row_renames_via_mapping() -> None:
    # Source CSV uses "port" but the template expects "text".
    result = from_row(_typed_sink, {"port": "eth0"}, mapping={"port": "text"})
    assert result == {"text": "eth0", "copies": 1, "font": "Arial"}


def test_from_row_mapping_leaves_unmapped_keys_alone() -> None:
    result = from_row(
        _typed_sink,
        {"port": "eth0", "copies": 4},
        mapping={"port": "text"},
    )
    assert result == {"text": "eth0", "copies": 4, "font": "Arial"}


def test_from_row_passes_all_keys_when_template_has_var_kwargs() -> None:
    # A template declared with **kwargs must receive every key — there's
    # no principled way to filter against an open parameter list.
    result = from_row(_var_kwargs_sink, {"a": 1, "b": 2, "c": 3})
    assert result == {"a": 1, "b": 2, "c": 3}


def test_from_row_raises_when_required_parameter_missing() -> None:
    # _typed_sink requires `text`. Surface the mismatch rather than
    # silently succeeding with an unintended default.
    with pytest.raises(TypeError, match="text"):
        from_row(_typed_sink, {"copies": 3})


def test_from_rows_batches_correctly() -> None:
    rows = [{"text": "eth0"}, {"text": "eth1"}, {"text": "eth2"}]

    results = from_rows(_typed_sink, rows)

    assert [r["text"] for r in results] == ["eth0", "eth1", "eth2"]
    assert len(results) == 3


def test_from_rows_accepts_any_iterable() -> None:
    def _gen():
        yield {"text": "a"}
        yield {"text": "b"}

    results = from_rows(_typed_sink, _gen())
    assert [r["text"] for r in results] == ["a", "b"]


def test_render_from_csv_reads_header_row_and_delegates(tmp_path: Path) -> None:
    csv_path = tmp_path / "labels.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["text", "department"])  # 'department' is unknown; must be dropped
        writer.writerow(["eth0", "networking"])
        writer.writerow(["eth1", "networking"])

    results = render_from_csv(csv_path, _typed_sink)  # type: ignore[arg-type]

    assert [r["text"] for r in results] == ["eth0", "eth1"]
    assert all(r["copies"] == 1 for r in results)


def test_render_from_csv_applies_mapping(tmp_path: Path) -> None:
    csv_path = tmp_path / "nautobot_export.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["port_name", "rack"])  # source system's names
        writer.writerow(["eth0", "rack-12"])
        writer.writerow(["eth1", "rack-12"])

    results = render_from_csv(
        csv_path,
        _typed_sink,
        mapping={"port_name": "text"},  # type: ignore[arg-type]
    )

    assert [r["text"] for r in results] == ["eth0", "eth1"]


def test_render_from_csv_handles_utf8_without_bom(tmp_path: Path) -> None:
    csv_path = tmp_path / "utf8.csv"
    csv_path.write_text("text\nétage-1\nπport\n", encoding="utf-8")

    results = render_from_csv(csv_path, _typed_sink)  # type: ignore[arg-type]

    assert [r["text"] for r in results] == ["étage-1", "πport"]
