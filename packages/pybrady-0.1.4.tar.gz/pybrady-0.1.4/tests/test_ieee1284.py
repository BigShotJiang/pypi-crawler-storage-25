# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Tests for the IEEE 1284 Device ID parser.

Golden bytes captured from a Brady BMP51 at firmware 01.12 on 2026-04-12:
    00 23 4d 46 47 3a 42 72 61 64 79 3b 43 4d 44 3a
    42 49 44 49 2d 56 47 4c 3b 4d 44 4c 3a 42 4d 50
    35 31 3b
"""

from __future__ import annotations

import pytest

from pybrady.transport.usb_ieee1284 import parse

BMP51_GOLDEN = bytes.fromhex(
    "00234d46473a42726164793b434d443a424944492d56474c3b4d444c3a424d5035313b"
)


def test_bmp51_golden_parses() -> None:
    d = parse(BMP51_GOLDEN)
    assert d.manufacturer == "Brady"
    assert d.model == "BMP51"
    assert d.command_set == "BIDI-VGL"
    assert d.description is None
    assert d.raw == "MFG:Brady;CMD:BIDI-VGL;MDL:BMP51;"


def test_long_keys_normalise_to_short_equivalents() -> None:
    raw = b"\x00\x1fMANUFACTURER:Foo;MODEL:Bar;"
    d = parse(raw)
    assert d.manufacturer == "Foo"
    assert d.model == "Bar"


def test_empty_values_and_malformed_pairs_are_tolerated() -> None:
    body = b"MFG:Brady;;badpair;MDL:"
    raw = bytes([0x00, len(body) + 2]) + body
    d = parse(raw)
    assert d.manufacturer == "Brady"
    # MDL is present with an empty value; treated as absent for the canonical
    # accessor so callers can use a simple `if identity.model is not None` check.
    assert d.model is None
    assert d.all_fields["MDL"] == ""
    assert "BADPAIR" not in d.all_fields  # no colon → skipped


def test_rejects_too_short_response() -> None:
    with pytest.raises(ValueError, match="too short"):
        parse(b"\x00")
