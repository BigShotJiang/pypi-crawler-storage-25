# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Tests for the Brady parts database loader."""

from __future__ import annotations

from pybrady.parts import (
    M21_DIMENSIONS,
    PartInfo,
    all_parts,
    dimensions_for_m21,
    find,
    find_by_ynumber,
)


def test_find_returns_known_part() -> None:
    # MC-1500-595-WT-BK is the user's validated media and appears in the
    # database. Assert the dataclass shape; don't hardcode the exact
    # Y-number since it could theoretically be refreshed.
    p = find("MC-1500-595-WT-BK")
    assert p is not None
    assert isinstance(p, PartInfo)
    assert p.name == "MC-1500-595-WT-BK"
    assert p.ynumber.startswith("Y")
    assert isinstance(p.flags, int)


def test_find_returns_none_for_unknown_part() -> None:
    assert find("NOT-A-REAL-PART-NUMBER-12345") is None


def test_find_by_ynumber_returns_all_aliases() -> None:
    # Y4918675 in the M21 dimensions table; the API-wide lookup should
    # return at least one record with that Y-number.
    matches = find_by_ynumber("Y4918675")
    assert len(matches) >= 1
    assert all(m.ynumber == "Y4918675" for m in matches)


def test_find_by_ynumber_unknown_returns_empty() -> None:
    assert find_by_ynumber("Y9999999") == []


def test_all_parts_returns_full_catalog() -> None:
    parts = all_parts()
    # Spec §8.2 says 13,426 raw records but only 8,257 unique part names
    # across 80+ product families. `all_parts()` is keyed by name so
    # duplicates collapse.
    assert len(parts) >= 8_000
    assert any(p.name == "MC-1500-595-WT-BK" for p in parts)


def test_m21_dimensions_lookup() -> None:
    # M21-11-427 maps to Y4918675 per spec §8.3 — 37 dots by 50 dots die-cut.
    dims = dimensions_for_m21("M21-11-427")
    assert dims is not None
    assert dims.width == 37
    assert dims.height == 50
    assert dims.die_cut is True


def test_m21_dimensions_none_for_unknown_part() -> None:
    assert dimensions_for_m21("NOT-A-PART") is None


def test_m21_dimensions_none_for_non_m21_part() -> None:
    # MC-1500-595-WT-BK exists in the database but has no M21 dimensions.
    assert dimensions_for_m21("MC-1500-595-WT-BK") is None


def test_m21_dimensions_table_has_expected_record_count() -> None:
    # Spec §8.3 lists 29 Y-numbers across 24 unique part names. Table uses
    # Y-number as the key.
    assert len(M21_DIMENSIONS) == 29
