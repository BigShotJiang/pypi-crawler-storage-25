# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Tests for the ESC/BMP stream decoder.

Round-trip property: any byte stream produced by `esc_bmp.build_job` must
decode without errors and reproduce the same command count structure.
"""

from __future__ import annotations

import pytest

from pybrady.exceptions import ProtocolError
from pybrady.models import CutMode
from pybrady.protocol import esc_bmp
from pybrady.protocol.esc_bmp_decode import EscOp, decode, summary


def test_decodes_empty_job() -> None:
    data = esc_bmp.build_job([], cut_mode=CutMode.END_OF_JOB)
    events = list(decode(data))
    ops = [e.op for e in events]
    assert ops == [EscOp.JOB_START, EscOp.JOB_END]


def test_decodes_single_page_with_raster() -> None:
    rows = [b"\xff\x00", b"\x00\x00", b"\xaa\xaa"]
    data = esc_bmp.build_job([rows], cut_mode=CutMode.END_OF_JOB)
    events = list(decode(data))
    ops = [e.op for e in events]
    assert ops == [
        EscOp.JOB_START,
        EscOp.PAGE_START,
        EscOp.GRAPHICS_LINE,
        EscOp.EMPTY_LINES,
        EscOp.GRAPHICS_LINE,
        EscOp.PAGE_END,
        EscOp.JOB_END,
    ]


def test_page_start_detail_names_cut_mode() -> None:
    data = esc_bmp.build_job([[b"\xff"]], cut_mode=CutMode.END_OF_LABEL)
    ps = next(e for e in decode(data) if e.op is EscOp.PAGE_START)
    assert ps.detail == "cut=EndOfLabel"


def test_decode_rejects_non_esc_byte() -> None:
    with pytest.raises(ProtocolError, match="non-ESC"):
        list(decode(b"\x00\x01\x02"))


def test_decode_rejects_truncated_raster() -> None:
    # 1B 67 0A 00  <only 2 bytes of promised 10>
    with pytest.raises(ProtocolError, match="declares 10 bytes"):
        list(decode(b"\x1b\x67\x0a\x00\xff\x00"))


def test_summary_reports_counts_and_raster_total() -> None:
    rows = [b"\xff\xff"] * 3 + [b"\x00\x00"] * 5 + [b"\xaa\xaa"]
    data = esc_bmp.build_job([rows], compress=False)
    text = summary(data)
    assert "graphics_line: 4" in text
    assert "empty_lines: 1" in text
    assert "blank rows compressed: 5" in text
    assert "raster payload: 8 bytes" in text  # 4 rows * 2 bytes
    assert "unknown" not in text


def test_summary_flags_unknown_command() -> None:
    data = b"\x1b\x58\x00" + b"\x1b\x99" + b"\x1b\x44"
    text = summary(data)
    assert "unknown: 1" in text
    assert "⚠" in text
