# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Tests for CaptureTransport — the dry-run byte sink."""

from __future__ import annotations

from pathlib import Path

import pytest

from pybrady.transport import CaptureTransport


async def test_write_appends_to_buffer() -> None:
    t = CaptureTransport()
    async with t:
        await t.write(b"\x1b\x58\x00")
        await t.write(b"\x1b\x44")
    assert t.data == b"\x1b\x58\x00\x1b\x44"


async def test_reset_clears_buffer() -> None:
    t = CaptureTransport()
    await t.write(b"abc")
    t.reset()
    assert t.data == b""


async def test_save_writes_bytes_to_disk(tmp_path: Path) -> None:
    t = CaptureTransport()
    await t.write(b"raw-bytes")
    out = tmp_path / "job.prn"
    t.save(out)
    assert out.read_bytes() == b"raw-bytes"


async def test_read_not_supported() -> None:
    t = CaptureTransport()
    with pytest.raises(NotImplementedError):
        await t.read(1)
