# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Tests for the `brady-export-templates` tool."""

from __future__ import annotations

import json
import struct
from pathlib import Path

import pytest

from pybrady.tools.export_brady_templates import (
    default_target_dir,
    discover_workstation_data_dir,
    export,
    iter_template_files,
    main,
)


def _write_7bit_int(n: int) -> bytes:
    out = bytearray()
    while n >= 0x80:
        out.append((n & 0x7F) | 0x80)
        n >>= 7
    out.append(n)
    return bytes(out)


def _bw_string(s: str) -> bytes:
    data = s.encode("utf-8")
    return _write_7bit_int(len(data)) + data


def _minimal_bwt(name: str, category: str = "") -> bytes:
    """Smallest valid `.BWT` that `read_header` will accept.

    We don't need FileIndex/Stores here — the exporter only reads the
    header dictionary to populate the manifest.
    """
    fields = {"FileFormat": "MW4", "Name": name, "Category": category, "AppName": "Custom"}
    parts = [_bw_string("brcudf2bin"), struct.pack("<i", len(fields))]
    for k, v in fields.items():
        parts.append(_bw_string(k))
        parts.append(_bw_string(v))
    return b"".join(parts)


def _seed_workstation(root: Path) -> None:
    """Build a fake Brady Workstation data directory under `root`."""
    addins = root / "Addins"
    asset_tpl = addins / "AssetApp" / "Templates" / "BBP11" / "Continuous" / "1"
    asset_tpl.mkdir(parents=True)
    (asset_tpl / "1 x 2 inch Text.BWT").write_bytes(
        _minimal_bwt("1 x 2 inch Text", "My Asset Tags")
    )
    (asset_tpl / "1 x 3 inch Barcode.BWT").write_bytes(
        _minimal_bwt("1 x 3 inch Barcode", "My Asset Tags")
    )
    # A second addin with a single template in a differently-structured path
    flip_tpl = addins / "FlipFlop" / "Templates" / "BMP51" / "Standard"
    flip_tpl.mkdir(parents=True)
    (flip_tpl / "Cable Flag.BWT").write_bytes(_minimal_bwt("Cable Flag", "Wire Markers"))
    # An addin with no Templates subdirectory — should be silently skipped.
    (addins / "DataAutomation").mkdir()


def test_discover_raises_when_source_is_not_brady_layout(tmp_path: Path) -> None:
    with pytest.raises(FileNotFoundError, match="doesn't look like"):
        discover_workstation_data_dir(tmp_path)


def test_discover_accepts_explicit_valid_path(tmp_path: Path) -> None:
    _seed_workstation(tmp_path)
    assert discover_workstation_data_dir(tmp_path) == tmp_path


def test_iter_template_files_groups_by_addin(tmp_path: Path) -> None:
    _seed_workstation(tmp_path)

    results = iter_template_files(tmp_path)

    addins = {addin for addin, _ in results}
    assert addins == {"AssetApp", "FlipFlop"}
    assert all(p.suffix.upper() == ".BWT" for _, p in results)
    # Deterministic sort: AssetApp entries come before FlipFlop in a sorted listing.
    assert [addin for addin, _ in results] == sorted(addin for addin, _ in results)


def test_export_copies_templates_and_writes_manifest(tmp_path: Path) -> None:
    source = tmp_path / "brady"
    target = tmp_path / "exported"
    _seed_workstation(source)

    # copy_fonts=False avoids pulling in actual Brady fonts from the host
    # during unit-testing; a dedicated font-export test exercises that path.
    summary = export(
        source=source, target=target, dry_run=False, copy_fonts=False, copy_icons=False
    )

    # Three .BWT files across two addins
    assert summary.total_templates == 3
    assert summary.per_addin == {"AssetApp": 2, "FlipFlop": 1}

    # Files land at the expected relative paths
    assert (target / "Addins/AssetApp/Templates/BBP11/Continuous/1/1 x 2 inch Text.BWT").is_file()
    assert (target / "Addins/FlipFlop/Templates/BMP51/Standard/Cable Flag.BWT").is_file()

    # Manifest records each template's header metadata
    manifest = json.loads((target / "manifest.json").read_text())
    assert manifest["total_templates"] == 3
    assert manifest["per_addin"] == {"AssetApp": 2, "FlipFlop": 1}
    names = {t["name"] for t in manifest["templates"]}
    assert names == {"1 x 2 inch Text", "1 x 3 inch Barcode", "Cable Flag"}
    # Category flows through from header
    asset_entries = [t for t in manifest["templates"] if t["addin"] == "AssetApp"]
    assert all(t["category"] == "My Asset Tags" for t in asset_entries)
    # With fonts disabled, the manifest still carries an explicit empty list.
    assert manifest["fonts"] == []


def test_export_dry_run_writes_nothing(tmp_path: Path) -> None:
    source = tmp_path / "brady"
    target = tmp_path / "exported"
    _seed_workstation(source)

    summary = export(source=source, target=target, dry_run=True, copy_fonts=False, copy_icons=False)

    # Summary is still accurate
    assert summary.total_templates == 3
    # But no files were created
    assert not target.exists()


def test_export_copies_fonts_when_available(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    source = tmp_path / "brady"
    target = tmp_path / "exported"
    _seed_workstation(source)

    # Stand in a fake Windows Fonts directory populated with TTF-named
    # dummies so the exporter picks them up.
    fake_fonts = tmp_path / "fake-windows-fonts"
    fake_fonts.mkdir()
    (fake_fonts / "Brady Alpine.ttf").write_bytes(b"fake-ttf-alpine")
    (fake_fonts / "Brady Fixed Width Bold.ttf").write_bytes(b"fake-ttf-fw-bold")
    # Non-Brady fonts must not be copied.
    (fake_fonts / "Arial.ttf").write_bytes(b"not-brady")

    from pybrady.tools import export_brady_templates as etm

    monkeypatch.setattr(etm, "_CANDIDATE_FONT_DIRS", (str(fake_fonts),))

    summary = export(source=source, target=target, dry_run=False, copy_fonts=True, copy_icons=False)

    assert {f.family_name for f in summary.fonts} == {"Brady Alpine", "Brady Fixed Width Bold"}
    assert (target / "Fonts/Brady Alpine.ttf").is_file()
    assert (target / "Fonts/Brady Fixed Width Bold.ttf").is_file()
    assert not (target / "Fonts/Arial.ttf").exists()

    manifest = json.loads((target / "manifest.json").read_text())
    manifest_families = {f["family_name"] for f in manifest["fonts"]}
    assert manifest_families == {"Brady Alpine", "Brady Fixed Width Bold"}


def test_default_target_dir_lives_under_home() -> None:
    default = default_target_dir()
    assert default.is_absolute()
    # Must be inside the user's home so deletion is obvious and unprivileged.
    assert Path.home() in default.parents
    assert default.name == "brady-templates"


def test_main_uses_default_target_when_omitted(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    source = tmp_path / "brady"
    _seed_workstation(source)
    fake_home = tmp_path / "home"
    fake_home.mkdir()
    monkeypatch.setattr(Path, "home", classmethod(lambda _cls: fake_home))

    exit_code = main(["--source", str(source), "--skip-icons"])

    assert exit_code == 0
    expected_target = fake_home / "pybrady" / "brady-templates"
    assert expected_target.is_dir()
    assert (expected_target / "manifest.json").is_file()
    # Confirm the target shows up in the tool's stdout so the user knows where files went.
    captured = capsys.readouterr()
    assert str(expected_target) in captured.out


def _seed_image_library(brady_root: Path) -> None:
    """Stand in a Components/ImageLibrary tree with the bits the exporter looks at."""
    img = brady_root / "Components" / "ImageLibrary"
    img.mkdir(parents=True)
    (img / "AA001 Color.svg").write_bytes(b"<svg></svg>")
    (img / "AA002 Color.svg").write_bytes(b"<svg></svg>")
    thumbs = img / "Thumbnails"
    thumbs.mkdir()
    (thumbs / "1.png").write_bytes(b"\x89PNG fake")
    (img / "graphicMetadata.xml").write_bytes(b'<?xml version="1.0"?><GraphicFileBase/>')


def test_export_copies_icon_library_when_available(tmp_path: Path) -> None:
    source = tmp_path / "brady"
    target = tmp_path / "exported"
    _seed_workstation(source)
    _seed_image_library(source)

    summary = export(source=source, target=target, dry_run=False, copy_fonts=False, copy_icons=True)

    assert summary.icon_library is not None
    assert summary.icon_library.relative_path == "Icons"
    # SVG + SVG + XML + PNG thumbnail = 4 files
    assert summary.icon_library.file_count == 4
    assert summary.icon_library.has_metadata_index is True

    # Copied to <target>/Icons/ preserving subtree.
    assert (target / "Icons" / "AA001 Color.svg").is_file()
    assert (target / "Icons" / "Thumbnails" / "1.png").is_file()
    assert (target / "Icons" / "graphicMetadata.xml").is_file()

    # Manifest records the icon library summary.
    manifest = json.loads((target / "manifest.json").read_text())
    assert manifest["icon_library"] == {
        "relative_path": "Icons",
        "file_count": 4,
        "has_metadata_index": True,
    }


def test_export_skips_icon_library_when_opted_out(tmp_path: Path) -> None:
    source = tmp_path / "brady"
    target = tmp_path / "exported"
    _seed_workstation(source)
    _seed_image_library(source)

    summary = export(
        source=source, target=target, dry_run=False, copy_fonts=False, copy_icons=False
    )

    assert summary.icon_library is None
    assert not (target / "Icons").exists()


def test_export_handles_missing_icon_library_gracefully(tmp_path: Path) -> None:
    source = tmp_path / "brady"
    target = tmp_path / "exported"
    _seed_workstation(source)
    # No Components/ImageLibrary at all — older/lighter Workstation installs.

    summary = export(source=source, target=target, dry_run=False, copy_fonts=False, copy_icons=True)

    assert summary.icon_library is None
    manifest = json.loads((target / "manifest.json").read_text())
    assert manifest["icon_library"] is None
