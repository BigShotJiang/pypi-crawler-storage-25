# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Tests for the generic and asset_tag parametric templates."""

from __future__ import annotations

import pytest
from PIL import Image

from pybrady.templates.asset_tag import asset_tag
from pybrady.templates.generic import generic
from pybrady.templates.parametric import from_row, from_rows


def _pixels(image: Image.Image) -> list[int]:
    """Flat pixel list; shims around Pillow 14's `getdata` deprecation."""
    getter = getattr(image, "get_flattened_data", image.getdata)
    return list(getter())


def _count_ink(image: Image.Image) -> int:
    return sum(1 for v in _pixels(image) if v == 0)


def _ink_per_column(image: Image.Image) -> list[int]:
    w, h = image.size
    pixels = image.load()
    return [sum(1 for y in range(h) if pixels[x, y] == 0) for x in range(w)]


# ---------------------------------------------------------------------------
# generic
# ---------------------------------------------------------------------------


def test_generic_produces_label_at_requested_dimensions() -> None:
    img = generic("hello", width_in=2.0, height_in=0.5, dpi=300)
    assert img.mode == "1"
    assert img.size == (600, 150)
    assert _count_ink(img) > 0


def test_generic_renders_multiline_text() -> None:
    one_line = generic("eth0", width_in=2.0, height_in=0.75, dpi=300, font_size=36)
    two_lines = generic("eth0\nrack-42", width_in=2.0, height_in=0.75, dpi=300, font_size=36)
    # Two lines worth of glyphs have strictly more ink than one line.
    assert _count_ink(two_lines) > _count_ink(one_line)


def test_generic_left_and_right_alignment_shift_ink_sideways() -> None:
    left = generic("X", width_in=2.0, height_in=0.5, dpi=300, font_size=48, align="left")
    right = generic("X", width_in=2.0, height_in=0.5, dpi=300, font_size=48, align="right")

    left_cols = _ink_per_column(left)
    right_cols = _ink_per_column(right)
    w = len(left_cols)
    # Left alignment puts more ink in the left half, right alignment the
    # other way round.
    assert sum(left_cols[: w // 2]) > sum(left_cols[w // 2 :])
    assert sum(right_cols[w // 2 :]) > sum(right_cols[: w // 2])


def test_generic_rejects_bad_align() -> None:
    with pytest.raises(ValueError, match="align"):
        generic("x", align="justify")


def test_generic_rejects_non_positive_dimensions() -> None:
    with pytest.raises(ValueError, match="positive"):
        generic("x", width_in=0, height_in=0.5)


# ---------------------------------------------------------------------------
# asset_tag
# ---------------------------------------------------------------------------


def test_asset_tag_with_identifier_only_is_centered() -> None:
    img = asset_tag("ACME-00042", width_in=1.5, height_in=0.5, dpi=300)
    assert img.size == (450, 150)
    assert img.mode == "1"
    cols = _ink_per_column(img)
    # Ink concentrated around the centre column when identifier is alone.
    w = len(cols)
    centre_third = sum(cols[w // 3 : 2 * w // 3])
    assert centre_third > 0


def test_asset_tag_with_description_has_more_ink_than_identifier_alone() -> None:
    no_desc = asset_tag("ACME-00042", width_in=2.0, height_in=0.75, dpi=300)
    with_desc = asset_tag(
        "ACME-00042",
        description="Laptop, Dell XPS",
        width_in=2.0,
        height_in=0.75,
        dpi=300,
    )
    assert _count_ink(with_desc) > _count_ink(no_desc)


def test_asset_tag_description_rendered_smaller_than_identifier() -> None:
    # Same string in both slots; the smaller font should produce strictly
    # less ink than the larger one, even though the character count matches.
    img = asset_tag(
        "SAMPLE",
        description="SAMPLE",
        width_in=2.0,
        height_in=1.0,
        dpi=300,
        identifier_font_size=60,
        description_font_size=20,
    )
    h = img.size[1]
    upper_half = img.crop((0, 0, img.size[0], h // 2))
    lower_half = img.crop((0, h // 2, img.size[0], h))
    # Larger font is on top, so more ink up there than below.
    assert _count_ink(upper_half) > _count_ink(lower_half) > 0


def test_asset_tag_rejects_empty_identifier() -> None:
    with pytest.raises(ValueError, match="identifier"):
        asset_tag("")


def test_asset_tag_rejects_non_positive_dimensions() -> None:
    with pytest.raises(ValueError, match="positive"):
        asset_tag("x", width_in=0, height_in=0.5)


# ---------------------------------------------------------------------------
# asset_tag barcode / QR variants
# ---------------------------------------------------------------------------


def _ink_in_region(img: Image.Image, box: tuple[int, int, int, int]) -> int:
    return _count_ink(img.crop(box))


def test_asset_tag_with_qr_adds_ink_on_the_right() -> None:
    plain = asset_tag("ACME-00042", width_in=2.0, height_in=0.5, dpi=300)
    with_qr = asset_tag("ACME-00042", qr=True, width_in=2.0, height_in=0.5, dpi=300)

    w, h = with_qr.size
    # QR carves a square on the right whose width equals the label
    # height. The rightmost strip of the canvas must gain substantial
    # ink vs. the plain tag.
    qr_region = (w - h, 0, w, h)
    assert _ink_in_region(with_qr, qr_region) > _ink_in_region(plain, qr_region) + 100


def test_asset_tag_with_barcode_adds_ink_at_the_bottom() -> None:
    # Taller label so the bottom third (barcode region) has room.
    plain = asset_tag("ACME-00042", width_in=2.5, height_in=0.75, dpi=300)
    with_bc = asset_tag("ACME-00042", barcode=True, width_in=2.5, height_in=0.75, dpi=300)

    w, h = with_bc.size
    # Barcode occupies the bottom third of the text area. Focus on the
    # strictly-bottom 20% so the comparison isn't polluted by descender
    # pixels from the text above.
    bottom_band = (0, int(h * 0.8), w, h)
    assert _ink_in_region(with_bc, bottom_band) > _ink_in_region(plain, bottom_band) + 100


def test_asset_tag_with_qr_and_barcode_populates_both_regions() -> None:
    # Needs a canvas roomy enough for all three regions.
    img = asset_tag(
        "ACME-00042",
        description="Dell XPS",
        qr=True,
        barcode=True,
        width_in=3.0,
        height_in=1.0,
        dpi=300,
    )
    w, h = img.size
    # Upper-right corner → QR.
    assert _ink_in_region(img, (w - h, 0, w, h)) > 500
    # Bottom strip → barcode.
    assert _ink_in_region(img, (0, int(h * 0.8), w, h)) > 500
    # Upper-left corner → text (identifier + description).
    assert _ink_in_region(img, (0, 0, w - h, int(h * 0.6))) > 100


def test_asset_tag_qr_accepts_explicit_string_for_url_encoding() -> None:
    # Passing a string means "encode this instead of the identifier"
    # — useful for URL-encoded QR codes. The rendered pixels must
    # differ from the bare-identifier variant.
    id_qr = asset_tag("ACME-42", qr=True, width_in=2.0, height_in=0.5)
    url_qr = asset_tag(
        "ACME-42",
        qr="https://inv.example.com/assets/ACME-42",
        width_in=2.0,
        height_in=0.5,
    )
    assert _pixels(id_qr) != _pixels(url_qr)


def test_asset_tag_rejects_sizes_too_small_for_codes() -> None:
    # Asking for QR+barcode on a postage-stamp label leaves no text
    # region — surface that as a clear error rather than rendering
    # garbage.
    with pytest.raises(ValueError, match="too small"):
        asset_tag("ACME", qr=True, barcode=True, width_in=0.5, height_in=0.5)


# ---------------------------------------------------------------------------
# from_row contract integration
# ---------------------------------------------------------------------------


def test_asset_tag_from_row_with_mapping() -> None:
    # Simulating a CSV export from a DCIM / CMDB that uses different
    # column names than the template's kwargs.
    row = {"asset_id": "ACME-00042", "name": "Dell XPS 13", "owner": "ops"}
    img = from_row(asset_tag, row, mapping={"asset_id": "identifier", "name": "description"})

    # Unknown column ("owner") is dropped; identifier + description make
    # it through.
    assert img.mode == "1"
    assert _count_ink(img) > 0


def test_generic_from_rows_batches_text_labels() -> None:
    rows = [{"text": "eth0"}, {"text": "eth1"}, {"text": "eth2"}]
    labels = from_rows(generic, rows)
    assert len(labels) == 3
    assert all(label.mode == "1" and _count_ink(label) > 0 for label in labels)
