# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Tests for the patch_panel template."""

from __future__ import annotations

import pytest
from PIL import Image

from pybrady.templates.parametric import from_row
from pybrady.templates.patch_panel import patch_panel


def _count_ink(image: Image.Image) -> int:
    getter = getattr(image, "get_flattened_data", image.getdata)
    return sum(1 for v in getter() if v == 0)


def _ink_per_column(image: Image.Image) -> list[int]:
    w, h = image.size
    pixels = image.load()
    return [sum(1 for y in range(h) if pixels[x, y] == 0) for x in range(w)]


def _ink_per_row(image: Image.Image) -> list[int]:
    w, h = image.size
    pixels = image.load()
    return [sum(1 for x in range(w) if pixels[x, y] == 0) for y in range(h)]


def test_patch_panel_accepts_sequence_expression() -> None:
    # Driving the template with the shorthand users actually type.
    img = patch_panel("1..4", width_in=4.0, height_in=0.5, dpi=300)
    assert img.mode == "1"
    assert img.size == (1200, 150)
    assert _count_ink(img) > 0


def test_patch_panel_accepts_explicit_list() -> None:
    img = patch_panel(["A", "B", "C", "D"], width_in=4.0, height_in=0.5, dpi=300)
    assert img.size == (1200, 150)
    assert _count_ink(img) > 0


def test_patch_panel_distributes_ink_across_cells() -> None:
    # Four cells across a 4" canvas — each quarter should carry ink.
    img = patch_panel("1..4", width_in=4.0, height_in=0.5, dpi=300, font_size=48)
    cols = _ink_per_column(img)
    w = len(cols)
    quarters = [sum(cols[i * w // 4 : (i + 1) * w // 4]) for i in range(4)]
    assert all(q > 0 for q in quarters)


def test_patch_panel_two_rows_lays_out_left_to_right_then_top_to_bottom() -> None:
    # 24 ports across 2 rows: first 12 on top, next 12 on bottom. Pick
    # asymmetric identifiers so the two rows have a detectable ink-row
    # split.
    ports = [f"P{i}" for i in range(1, 25)]
    img = patch_panel(ports, width_in=6.0, height_in=1.0, dpi=300, rows=2)
    assert img.size == (1800, 300)
    rows_ink = _ink_per_row(img)
    h = len(rows_ink)
    upper = sum(rows_ink[: h // 2])
    lower = sum(rows_ink[h // 2 :])
    # Both rows must carry ink.
    assert upper > 0
    assert lower > 0


def test_patch_panel_auto_sizes_font_to_the_longest_port_name() -> None:
    # A mix of short and long names forces the auto-sizer to pick a
    # smaller font than short-only input would. More ink per label with
    # the short-only variant confirms it got a larger font.
    short_only = patch_panel(["A", "B", "C", "D"], width_in=4.0, height_in=0.5, dpi=300)
    with_long = patch_panel(
        ["A", "B", "C", "REALLYLONGPORTNAME"], width_in=4.0, height_in=0.5, dpi=300
    )
    # short_only has more total ink because its glyphs are bigger; the
    # long name in with_long forced every cell to shrink.
    assert _count_ink(short_only) > _count_ink(with_long)


def test_patch_panel_explicit_font_size_overrides_auto() -> None:
    small = patch_panel("1..4", width_in=4.0, height_in=0.5, dpi=300, font_size=12)
    large = patch_panel("1..4", width_in=4.0, height_in=0.5, dpi=300, font_size=48)
    assert _count_ink(large) > _count_ink(small)


def test_patch_panel_dividers_add_ink_at_cell_boundaries() -> None:
    plain = patch_panel("1..4", width_in=4.0, height_in=0.5, dpi=300, font_size=36)
    with_div = patch_panel(
        "1..4", width_in=4.0, height_in=0.5, dpi=300, font_size=36, dividers=True
    )
    # Dividers add 3 vertical lines between the 4 cells.
    assert _count_ink(with_div) > _count_ink(plain)


def test_patch_panel_skips_empty_strings_without_filling_cell() -> None:
    img = patch_panel(["eth0", "", "eth2", ""], width_in=4.0, height_in=0.5, dpi=300)
    cols = _ink_per_column(img)
    w = len(cols)
    # Second and fourth quarters should be blank because their port
    # strings were empty.
    second = sum(cols[w // 4 : 2 * w // 4])
    fourth = sum(cols[3 * w // 4 :])
    assert second == 0
    assert fourth == 0


def test_patch_panel_rejects_empty_ports() -> None:
    with pytest.raises(ValueError, match="non-empty"):
        patch_panel([])


def test_patch_panel_rejects_indivisible_row_count() -> None:
    with pytest.raises(ValueError, match="divisible by rows"):
        patch_panel("1..23", rows=2)


def test_patch_panel_rejects_rows_less_than_one() -> None:
    with pytest.raises(ValueError, match="rows"):
        patch_panel("1..4", rows=0)


def test_patch_panel_rejects_non_positive_dimensions() -> None:
    with pytest.raises(ValueError, match="positive"):
        patch_panel("1..4", width_in=0, height_in=0.5)


def test_patch_panel_from_row_contract() -> None:
    # A DCIM export might give us a row with a 'ports' list already
    # expanded; from_row spreads it into the template kwargs.
    row = {"ports": ["eth0", "eth1", "eth2", "eth3"], "width_in": 3.0, "height_in": 0.5}
    img = from_row(patch_panel, row)
    assert img.size == (900, 150)
    assert _count_ink(img) > 0
