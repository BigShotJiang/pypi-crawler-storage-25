# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Tests for the BradyPrinter facade — multi-page + multi-copy."""

from __future__ import annotations

import pytest
from PIL import Image

from pybrady import BradyPrinter
from pybrady.protocol.esc_bmp_decode import EscOp, decode
from pybrady.transport import CaptureTransport


def _make_image(shade: int = 1) -> Image.Image:
    return Image.new("1", (16, 4), shade)


def _count_ops(data: bytes) -> dict[EscOp, int]:
    counts: dict[EscOp, int] = {}
    for ev in decode(data):
        counts[ev.op] = counts.get(ev.op, 0) + 1
    return counts


async def _capture(image, **kwargs) -> bytes:
    t = CaptureTransport()
    async with t:
        p = BradyPrinter(t, model="BMP51")
        await p.print(image, **kwargs)
    return t.data


async def test_single_image_is_single_page() -> None:
    data = await _capture(_make_image())
    ops = _count_ops(data)
    assert ops[EscOp.JOB_START] == 1
    assert ops[EscOp.JOB_END] == 1
    assert ops[EscOp.PAGE_START] == 1


async def test_list_of_images_produces_multiple_pages() -> None:
    data = await _capture([_make_image(), _make_image(), _make_image()])
    ops = _count_ops(data)
    assert ops[EscOp.JOB_START] == 1
    assert ops[EscOp.JOB_END] == 1
    assert ops[EscOp.PAGE_START] == 3
    assert ops[EscOp.PAGE_END] == 3


async def test_copies_repeat_pages() -> None:
    data = await _capture(_make_image(), copies=4)
    ops = _count_ops(data)
    assert ops[EscOp.PAGE_START] == 4
    assert ops[EscOp.PAGE_END] == 4


async def test_copies_multiply_with_pages() -> None:
    # 2 pages * 3 copies = 6 pages total
    data = await _capture([_make_image(), _make_image()], copies=3)
    ops = _count_ops(data)
    assert ops[EscOp.PAGE_START] == 6


async def test_copies_zero_is_rejected() -> None:
    with pytest.raises(ValueError, match="copies must be >= 1"):
        await _capture(_make_image(), copies=0)


async def test_empty_images_iterable_is_rejected() -> None:
    with pytest.raises(ValueError, match="at least one image"):
        await _capture([])
