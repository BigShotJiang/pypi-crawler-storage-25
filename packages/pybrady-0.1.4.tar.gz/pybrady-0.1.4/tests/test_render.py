# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Tests for the PIL → raster row renderer."""

from __future__ import annotations

from PIL import Image

from pybrady.render import image_to_rows


def test_all_white_image_produces_zero_bytes() -> None:
    img = Image.new("1", (16, 3), 1)  # white
    rows = image_to_rows(img)
    assert rows == [b"\x00\x00"] * 3


def test_all_black_image_produces_ff_bytes() -> None:
    img = Image.new("1", (16, 2), 0)  # black
    rows = image_to_rows(img)
    assert rows == [b"\xff\xff"] * 2


def test_tail_padding_is_masked_white() -> None:
    # width 4 → 1 byte per row, only top nibble is real pixels.
    img = Image.new("1", (4, 1), 0)  # black
    rows = image_to_rows(img)
    # Four black pixels = 0xF0 (upper nibble set, lower masked off).
    assert rows == [b"\xf0"]


def test_non_1_mode_image_is_converted() -> None:
    img = Image.new("L", (8, 1), 255)  # white greyscale
    rows = image_to_rows(img)
    assert rows == [b"\x00"]
