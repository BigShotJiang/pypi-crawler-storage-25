# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Tests for the ESC/BMP subscribe-response parser.

Golden bytes captured from BMP51 FW 01.12.u on 2026-04-12 with loaded
media MC-1500-595-WT-BK (substrate) and R6000 (ribbon).
"""

from __future__ import annotations

import pytest

from pybrady.exceptions import ProtocolError
from pybrady.protocol.esc_bmp_status import STATUS_LENGTH, parse

_GOLDEN_ROWS = [
    "00 a8 0a 00 05 00 01 01 4d 43 2d 31 35 30 30 2d",
    "35 39 35 2d 57 54 2d 42 4b 00 00 00 00 00 00 00",
    "52 36 30 30 30 00 00 00 00 00 00 00 00 00 00 00",
    "00 00 00 00 00 00 00 00 8c 1a 16 00 00 00 00 00",
    "00 00 00 00 02 00 32 00 64 00 15 07 ce 00 00 00",
    "f4 01 50 00 01 00 00 00 dc 05 a0 05 f4 01 f4 01",
    "00 00 00 00 01 00 a0 05 00 00 00 00 00 00 f4 01",
    "00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00",
    "00 00 00 00 00 00 00 00 00 00 00 00 00 00 01 00",
    "00 00 ff ff ff 00 00 00 10 09 05 00 a4 e9 02 00",
    "10 09 05 00 a4 e9 02 00",
]
BMP51_GOLDEN = bytes.fromhex("".join(_GOLDEN_ROWS).replace(" ", ""))


def test_golden_parses_cleanly() -> None:
    assert len(BMP51_GOLDEN) == STATUS_LENGTH
    s = parse(BMP51_GOLDEN)
    assert s.substrate_part == "MC-1500-595-WT-BK"
    assert s.ribbon_part == "R6000"
    assert s.media_width_thou == 1500  # 1.5"
    assert s.printable_width_thou == 1440  # 1.44"
    # Capacity and remaining are u32 LE at 0x98 and 0x9C/0xA4.
    # In the golden: 0x98..9B = `10 09 05 00` = 330000
    #                0x9C..9F = 0xA4..A7 = `a4 e9 02 00` = 190884
    assert s.media_capacity_units == 330000
    assert s.media_remaining_units == 190884
    assert s.media_remaining_chip_units == 190884
    assert s.media_remaining_fraction is not None
    # About 57.8% remaining in this sample.
    assert abs(s.media_remaining_fraction - (190884 / 330000)) < 1e-6
    assert s.raw == BMP51_GOLDEN


def test_tolerates_extra_trailing_bytes() -> None:
    padded = BMP51_GOLDEN + b"\xff\xff\xff"
    s = parse(padded)
    assert s.substrate_part == "MC-1500-595-WT-BK"
    # raw is truncated to STATUS_LENGTH — trailing bytes are not our concern.
    assert len(s.raw) == STATUS_LENGTH


def test_rejects_too_short() -> None:
    with pytest.raises(ProtocolError, match="too short"):
        parse(BMP51_GOLDEN[:100])


def test_rejects_bad_length_byte() -> None:
    mangled = bytearray(BMP51_GOLDEN)
    mangled[1] = 0xFF
    with pytest.raises(ProtocolError, match="length-byte mismatch"):
        parse(bytes(mangled))


def test_null_substrate_returns_none() -> None:
    empty_media = bytearray(BMP51_GOLDEN)
    empty_media[0x08 : 0x08 + 24] = b"\x00" * 24
    s = parse(bytes(empty_media))
    assert s.substrate_part is None
    assert s.ribbon_part == "R6000"
