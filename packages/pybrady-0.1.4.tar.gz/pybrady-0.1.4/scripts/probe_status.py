# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Exploratory: probe BMP51 for status responses over USB.

We have no ground truth for BMP51's bidirectional protocol over USB — the
Android APK only implements it over TCP. This script writes candidate
probe sequences to EP 0x01 and reads EP 0x82 with a short timeout,
dumping whatever comes back. No labels are printed.

Run with the BMP51 connected and idle:
    uv run python scripts/probe_status.py
"""

from __future__ import annotations

import asyncio
import sys

from pybrady.transport.usb import UsbTransport

# Candidate probe sequences. Each is (name, bytes_to_write).
# Ordered from least-intrusive to most.
PROBES: list[tuple[str, bytes]] = [
    # Exploring whether the printer needs a print-flow prefix to enable its
    # bidi status channel. Each probe is a candidate "wake" sequence.
    ("ESC X 00 (job start only)", b"\x1b\x58\x00"),
    ("ESC I after job-start", b"\x1b\x49"),
    ("ESC X 00 + ESC D (empty job) + ESC I", b"\x1b\x58\x00\x1b\x44\x1b\x49"),
]

READ_CHUNK = 4096
READ_TIMEOUT = 0.8
DRAIN_TIMEOUT = 0.2  # short timeout for follow-up reads after first chunk


def hex_dump(data: bytes, width: int = 16) -> str:
    lines = []
    for i in range(0, len(data), width):
        chunk = data[i : i + width]
        hexed = " ".join(f"{b:02x}" for b in chunk)
        ascii_ = "".join(chr(b) if 0x20 <= b < 0x7F else "." for b in chunk)
        lines.append(f"  {i:04x}  {hexed:<{width * 3}}  {ascii_}")
    return "\n".join(lines)


async def drain(transport: UsbTransport, initial_timeout: float) -> bytes:
    """Read until nothing more comes. Returns total bytes received."""
    got = bytearray()
    timeout = initial_timeout
    while True:
        try:
            chunk = await transport.read(READ_CHUNK, timeout=timeout)
        except Exception as e:
            name_ = type(e).__name__
            if "timeout" in name_.lower() or "timeout" in str(e).lower():
                break
            print(f"  read error: {name_}: {e}")
            break
        if not chunk:
            break
        got.extend(chunk)
        # Subsequent reads use a shorter timeout — if the printer sends more,
        # it'll be right after the first chunk.
        timeout = DRAIN_TIMEOUT
    return bytes(got)


async def try_probe(transport: UsbTransport, name: str, payload: bytes) -> None:
    print(f"\n=== {name} ===")
    print(f"write ({len(payload)}B):")
    print(hex_dump(payload))

    await transport.write(payload)
    got = await drain(transport, initial_timeout=READ_TIMEOUT)

    if not got:
        print("  (no response)")
        return
    print(f"response ({len(got)}B):")
    print(hex_dump(got))


async def main() -> int:
    async with UsbTransport.find_bmp51() as transport:
        # Settle briefly — the printer can be sluggish immediately after the
        # kernel-driver detach/reattach cycle that UsbTransport performs.
        await asyncio.sleep(0.5)

        # Read BEFORE any write — is there anything queued by the printer
        # that we should drain or that would reveal its default behaviour?
        pre = await drain(transport, initial_timeout=0.5)
        if pre:
            print(f"(unsolicited {len(pre)}B before any write)")
            print(hex_dump(pre))
        else:
            print("(no unsolicited data on EP 0x82)")

        # Drain any stale data from a previous session that wasn't fully read.
        stale = await drain(transport, initial_timeout=0.5)
        if stale:
            print(f"(drained {len(stale)}B of stale data before probing)")
            print(hex_dump(stale))
        for name, payload in PROBES:
            try:
                await try_probe(transport, name, payload)
            except Exception as e:
                print(f"  fatal during probe {name!r}: {type(e).__name__}: {e}")
                # Best-effort: try to drain and continue so later probes
                # aren't starved by a stuck pipe.
                try:
                    rest = await drain(transport, initial_timeout=0.3)
                    if rest:
                        print(f"  (drained {len(rest)}B after error)")
                        print(hex_dump(rest))
                except Exception:
                    pass
            await asyncio.sleep(0.3)
    return 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
