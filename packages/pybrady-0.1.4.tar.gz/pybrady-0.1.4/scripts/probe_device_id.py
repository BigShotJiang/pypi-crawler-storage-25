# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Ask the BMP51 for its IEEE 1284 Device ID via the standard USB Printer Class
GET_DEVICE_ID control request.

This is a standard USB-printer-class request (Class 7, Subclass 1). The
printer MUST respond regardless of any vendor-specific state — unlike the
Brady `ESC I` subscribe which appears to be TCP-only on BMP51.

No labels are printed.
"""

from __future__ import annotations

import contextlib
import sys

import usb.core
import usb.util

VID = 0x0E2E
PID = 0x000B
INTERFACE = 0
CONFIGURATION = 1
ALT_SETTING = 0

# USB Printer Class Request: GET_DEVICE_ID
# bmRequestType: 0b10100001 = 0xA1 (device-to-host, class, interface)
# bRequest:      0x00
# wValue:        configuration
# wIndex:        (alt_setting << 8) | interface
# wLength:       read buffer length
GET_DEVICE_ID = 0x00


def main() -> int:
    dev = usb.core.find(idVendor=VID, idProduct=PID)
    if dev is None:
        print("BMP51 not found", file=sys.stderr)
        return 1

    detached = False
    try:
        if dev.is_kernel_driver_active(INTERFACE):
            dev.detach_kernel_driver(INTERFACE)
            detached = True
        with contextlib.suppress(usb.core.USBError):
            dev.set_configuration()
        usb.util.claim_interface(dev, INTERFACE)

        w_index = (ALT_SETTING << 8) | INTERFACE
        raw = dev.ctrl_transfer(
            bmRequestType=0xA1,
            bRequest=GET_DEVICE_ID,
            wValue=CONFIGURATION,
            wIndex=w_index,
            data_or_wLength=1024,
            timeout=2000,
        )
        raw = bytes(raw)
    finally:
        with contextlib.suppress(Exception):
            usb.util.release_interface(dev, INTERFACE)
        if detached:
            with contextlib.suppress(Exception):
                dev.attach_kernel_driver(INTERFACE)
        with contextlib.suppress(Exception):
            usb.util.dispose_resources(dev)

    if len(raw) < 2:
        print(f"short response: {raw.hex()}")
        return 2

    # First 2 bytes are big-endian length prefix per IEEE 1284.
    length = (raw[0] << 8) | raw[1]
    payload = raw[2 : 2 + length - 2] if length >= 2 else raw[2:]
    print(f"raw bytes ({len(raw)}):")
    print(raw.hex(" "))
    print()
    print(f"declared length: {length}")
    try:
        text = payload.decode("ascii")
        print("device id string:")
        print(text)
    except UnicodeDecodeError:
        print(f"non-ASCII payload ({len(payload)}B): {payload.hex(' ')}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
