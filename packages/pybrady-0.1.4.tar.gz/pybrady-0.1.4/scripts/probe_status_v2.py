# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Test: call GET_DEVICE_ID right after claim_interface, then subscribe.

Hypothesis (from bmp51-4.pcapng analysis): Brady's Windows driver polls
`1B 49` and reliably receives 168 bytes of status. We tried the same and
get nothing. The only visible difference is that the kernel's `usblp`
driver always issues GET_DEVICE_ID during its own init; when we detach
usblp and claim raw, we may be skipping that init.

This script:
  1. Opens the printer (detach usblp, claim interface 0)
  2. Calls GET_DEVICE_ID via control transfer (same request usblp issues)
  3. Writes `1B 49` to bulk OUT
  4. Reads bulk IN with a generous timeout
  5. Prints whatever came back

Safe — no writes that can put the printer into a weird state. Just the
standard 1284 query plus a subscribe.
"""

from __future__ import annotations

import asyncio
import sys

from pybrady.transport.usb import UsbTransport


def hex_dump(data: bytes, width: int = 16) -> str:
    lines = []
    for i in range(0, len(data), width):
        chunk = data[i : i + width]
        hexed = " ".join(f"{b:02x}" for b in chunk)
        ascii_ = "".join(chr(b) if 0x20 <= b < 0x7F else "." for b in chunk)
        lines.append(f"  {i:04x}  {hexed:<{width * 3}}  {ascii_}")
    return "\n".join(lines)


async def main() -> int:
    async with UsbTransport.find_bmp51() as t:
        await asyncio.sleep(0.5)

        # Step 1: issue GET_DEVICE_ID. This is what usblp does at attach.
        d = await t.get_device_id()
        print(f"device id: {d.raw}\n")

        await asyncio.sleep(0.2)

        # Step 2: subscribe.
        print("writing ESC I (0x1b 0x49)...")
        await t.write(b"\x1b\x49")

        # Step 3: read response with 5s timeout — Windows gets a response
        # in ~6ms, so 5s is safely generous.
        try:
            got = await t.read(4096, timeout=5.0)
        except Exception as e:
            print(f"read error: {type(e).__name__}: {e}")
            return 1

        if not got:
            print("NO RESPONSE — hypothesis disproved.")
            return 2

        print(f"response ({len(got)} bytes):")
        print(hex_dump(got))

        # Decode substrate and ribbon strings if present.
        if len(got) >= 56:
            substrate = got[8:32].rstrip(b"\x00").decode("ascii", errors="replace")
            ribbon = got[32:56].rstrip(b"\x00").decode("ascii", errors="replace")
            print(f"\nsubstrate: {substrate!r}")
            print(f"ribbon:    {ribbon!r}")
    return 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
