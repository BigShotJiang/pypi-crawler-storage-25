# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Capture BMP51 status samples under varying conditions and diff them.

Usage:
    uv run python scripts/status_experiment.py capture <label>
        — poll status NOW, append hex dump to the log with the given label

    uv run python scripts/status_experiment.py diff
        — show byte-by-byte differences across all logged samples

    uv run python scripts/status_experiment.py reset
        — wipe the log

The point is to learn what the numeric region of the 168-byte status
struct means by correlating byte positions to real-world state changes:
counters tick on print, flags toggle on head-open, media-specific fields
change on media swap, etc.

Log path defaults to ~/Brady/status_samples.log (outside the repo).
"""

from __future__ import annotations

import asyncio
import sys
from pathlib import Path

from pybrady import BradyPrinter
from pybrady.transport.usb import UsbTransport

LOG_PATH = Path.home() / "Brady" / "status_samples.log"


async def grab_status() -> bytes:
    async with UsbTransport.find_bmp51() as t:
        printer = BradyPrinter(t, model="BMP51")
        s = await printer.query_status()
    return s.raw


def capture(label: str) -> None:
    raw = asyncio.run(grab_status())
    LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
    with LOG_PATH.open("a") as f:
        f.write(f"# {label}\n{raw.hex()}\n")
    print(f"captured {len(raw)}B → {LOG_PATH} (label={label!r})")


def load_samples() -> list[tuple[str, bytes]]:
    if not LOG_PATH.exists():
        return []
    samples: list[tuple[str, bytes]] = []
    label = ""
    for line in LOG_PATH.read_text().splitlines():
        if line.startswith("# "):
            label = line[2:].strip()
        elif line.strip():
            samples.append((label, bytes.fromhex(line.strip())))
    return samples


def _col(bs: list[bytes], i: int) -> list[int]:
    return [b[i] for b in bs]


def diff() -> None:
    samples = load_samples()
    if len(samples) < 2:
        print(f"need at least 2 samples in {LOG_PATH}; have {len(samples)}")
        return

    labels = [lbl for lbl, _ in samples]
    blobs = [blob for _, blob in samples]
    width = min(len(b) for b in blobs)

    # Headers
    header = "offset | " + " | ".join(f"{lbl[:12]:>12}" for lbl in labels)
    print(header)
    print("-" * len(header))

    changing_offsets = []
    for i in range(width):
        col = _col(blobs, i)
        if len(set(col)) > 1:
            changing_offsets.append(i)

    if not changing_offsets:
        print("(no bytes differ across samples)")
        return

    # Group consecutive offsets so we show runs as LE words when plausible.
    print(f"{len(changing_offsets)} bytes differ across {len(samples)} samples:\n")
    for i in changing_offsets:
        col = _col(blobs, i)
        cells = " | ".join(f"{b:>12x}" for b in col)
        print(f"  0x{i:04x} | {cells}")

    # Heuristic: for runs of 2 or 4 changing bytes on even offsets, also
    # show the LE interpretation — likely u16 / u32 counters.
    print("\nLE u32 views for aligned 4-byte runs:")
    for start in range(0, width - 3, 4):
        run = [start + k in changing_offsets for k in range(4)]
        if all(run):
            vals = [int.from_bytes(b[start : start + 4], "little") for b in blobs]
            cells = " | ".join(f"{v:>12d}" for v in vals)
            print(f"  0x{start:04x} | {cells}")


def reset() -> None:
    if LOG_PATH.exists():
        LOG_PATH.unlink()
    print(f"cleared {LOG_PATH}")


def main() -> int:
    if len(sys.argv) < 2:
        print(__doc__)
        return 1
    cmd = sys.argv[1]
    if cmd == "capture":
        if len(sys.argv) < 3:
            print("capture requires a label argument")
            return 1
        capture(" ".join(sys.argv[2:]))
    elif cmd == "diff":
        diff()
    elif cmd == "reset":
        reset()
    else:
        print(f"unknown command: {cmd}")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
