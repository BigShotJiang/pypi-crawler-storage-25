# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Reverse-engineer Brady ESC/BMP RLE encoding from a captured print stream.

Walks an ESC/BMP byte stream, lists each `1B 68` RLE line with its
encoded bytes, and tries candidate decoders to find one that produces
consistent row widths.
"""

from __future__ import annotations

import sys
from collections import Counter
from pathlib import Path


def parse_stream(data: bytes) -> list[bytes]:
    """Return a list of RLE payloads (the bytes between `1B 68 <len>` and the next command)."""
    rle_payloads: list[bytes] = []
    i = 0
    while i < len(data):
        if data[i] != 0x1B:
            i += 1
            continue
        cmd = data[i + 1]
        if cmd in (0x58, 0x44):  # job start / end
            i += 2 if cmd == 0x44 else 3
        elif cmd == 0x4D:  # page start
            i += 4
        elif cmd == 0x45:  # page end
            i += 2
        elif cmd == 0x5A:  # empty lines
            i += 4
        elif cmd == 0x67:  # raw graphics line
            ln = data[i + 2] | (data[i + 3] << 8)
            i += 4 + ln
        elif cmd == 0x68:  # RLE line
            ln = data[i + 2] | (data[i + 3] << 8)
            rle_payloads.append(data[i + 4 : i + 4 + ln])
            i += 4 + ln
        elif cmd == 0x49:  # subscribe (shouldn't appear in print stream but skip safely)
            i += 2
        else:
            i += 2
    return rle_payloads


# --- candidate decoders --------------------------------------------------


def decode_hi_bit_color(payload: bytes) -> tuple[int, list[tuple[int, int]]]:
    """Bit 7 = colour, bits 6-0 = count-1 (VGL-style, from spec §5.3)."""
    runs = []
    for b in payload:
        color = (b >> 7) & 1
        count = (b & 0x7F) + 1
        runs.append((color, count))
    return sum(c for _, c in runs), runs


def decode_hi_bit_color_zero(payload: bytes) -> tuple[int, list[tuple[int, int]]]:
    """Bit 7 = colour, bits 6-0 = count (allowing 0)."""
    runs = []
    for b in payload:
        color = (b >> 7) & 1
        count = b & 0x7F
        runs.append((color, count))
    return sum(c for _, c in runs), runs


def decode_packbits_pixel(payload: bytes) -> tuple[int, list[tuple[str, int]]] | None:
    """PackBits-style over pixels.

    Byte 0..127  = `n` literal bytes follow (expanded to 8 pixels each).
    Byte 128..255 = repeat next byte (signed count).
    """
    runs = []
    total_pixels = 0
    i = 0
    while i < len(payload):
        n = payload[i]
        i += 1
        if n < 0x80:
            run_len = n + 1
            # Would consume run_len bytes of literals
            if i + run_len > len(payload):
                return None
            i += run_len
            total_pixels += run_len * 8
            runs.append(("lit", run_len))
        else:
            run_len = 256 - n + 1  # signed-byte interpretation
            if i >= len(payload):
                return None
            i += 1
            total_pixels += run_len * 8
            runs.append(("rep", run_len))
    return total_pixels, runs


# --- analysis ------------------------------------------------------------


def main() -> int:
    data = bytes.fromhex(Path("/tmp/hello.hex").read_text())
    rle_lines = parse_stream(data)
    print(f"{len(rle_lines)} RLE lines in stream\n")

    # Frequency of payloads — repeated lines = blank/solid bands.
    freq = Counter(rle_lines)
    top = freq.most_common(5)
    print("top 5 most common RLE payloads:")
    for p, n in top:
        print(f"  {n:4d}x  {p.hex()}")
    print()

    # For each unique short payload, show all candidate decodings.
    uniques = list(freq.keys())
    uniques.sort(key=lambda b: (len(b), b))
    print(f"{len(uniques)} unique payloads. Showing first 8:\n")

    for payload in uniques[:8]:
        print(f"payload: {payload.hex()}  (len {len(payload)})  count={freq[payload]}")
        total1, runs1 = decode_hi_bit_color(payload)
        total2, runs2 = decode_hi_bit_color_zero(payload)
        pk = decode_packbits_pixel(payload)
        print(f"  hi-bit-colour count+1:  {total1} px  runs={runs1}")
        print(f"  hi-bit-colour count:    {total2} px  runs={runs2}")
        if pk is not None:
            print(f"  packbits-bytes:         {pk[0]} px  {pk[1]}")
        else:
            print("  packbits-bytes:         malformed")
        print()

    # Look at row-width consistency across all unique lines.
    print("Row-width distribution per decoder:")
    widths_v1 = Counter()
    widths_v2 = Counter()
    for payload in rle_lines:
        t1, _ = decode_hi_bit_color(payload)
        t2, _ = decode_hi_bit_color_zero(payload)
        widths_v1[t1] += 1
        widths_v2[t2] += 1
    print(f"  hi-bit-colour count+1:  {dict(widths_v1.most_common(5))}")
    print(f"  hi-bit-colour count:    {dict(widths_v2.most_common(5))}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
