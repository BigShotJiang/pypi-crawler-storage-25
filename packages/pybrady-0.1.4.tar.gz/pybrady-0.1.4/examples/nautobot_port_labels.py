# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Integration pattern: pull port assignments from a DCIM and print labels.

This example demonstrates how pybrady's generic input contract replaces
what Brady Workstation ships as a zoo of paid connectors (AdvancedImport,
ExcelImport, DataAutomation, ...). A real deployment would:

1. Query your source of truth — Nautobot / Netbox / AWX / a CMDB / even
   a Google Sheet — for the rows you want to label.
2. Map each row into the template's kwargs (with column-rename if the
   source's vocabulary differs from the template's).
3. Feed into `from_rows(template, rows, mapping=...)`.
4. Send the resulting images to a printer (or save them to disk first
   for a visual sanity check).

The `fetch_ports_*` functions below show two real paths:

  * `fetch_ports_nautobot(...)` — uses `pynautobot` if installed. Pass
    `--nautobot URL --token TOKEN --device DEVICE` to use it.
  * `fetch_ports_stub()` — returns hard-coded sample data so the example
    runs on any machine. This is what most users would replace first.

Typical runs:

    # Stub data, render to PNGs for inspection
    uv run python examples/nautobot_port_labels.py --out /tmp/ports

    # Stub data, dry-run to see the ESC/BMP byte-count per label
    uv run python examples/nautobot_port_labels.py --dry-run

    # Real Nautobot query (requires: pip install pynautobot)
    uv run python examples/nautobot_port_labels.py \\
        --nautobot https://nautobot.example.com \\
        --token $NAUTOBOT_TOKEN \\
        --device rack42-sw1 \\
        --print
"""

from __future__ import annotations

import argparse
import asyncio
from collections.abc import Iterable
from pathlib import Path
from typing import Any

from pybrady import PRINTER_MODELS, BradyPrinter, CutMode
from pybrady.protocol.esc_bmp_decode import summary
from pybrady.templates.cable import cable_wrap
from pybrady.templates.parametric import from_rows
from pybrady.transport import CaptureTransport, UsbTransport


def fetch_ports_stub() -> list[dict[str, Any]]:
    """Stand-in data source.

    Shape deliberately mirrors what a typical DCIM query returns —
    a list of dicts, one per port, with some columns the template
    uses and others it doesn't. pybrady's `from_rows` drops the
    unused columns automatically.
    """
    return [
        {"name": "eth0", "device": "rack42-sw1", "description": "uplink to core"},
        {"name": "eth1", "device": "rack42-sw1", "description": "uplink to core"},
        {"name": "eth2", "device": "rack42-sw1", "description": "server1 primary"},
        {"name": "eth3", "device": "rack42-sw1", "description": "server2 primary"},
    ]


def fetch_ports_nautobot(url: str, token: str, device: str) -> list[dict[str, Any]]:
    """Real Nautobot query using pynautobot.

    Imports are lazy so the example still runs when pynautobot isn't
    installed. In a real project you'd factor this out into whatever
    integration module fits your stack.
    """
    try:
        import pynautobot  # type: ignore[import-not-found]
    except ImportError as e:  # pragma: no cover — optional integration
        raise SystemExit(
            "this flag requires 'pip install pynautobot'; "
            "use the stub data path by omitting --nautobot"
        ) from e

    nb = pynautobot.api(url, token=token)
    interfaces = nb.dcim.interfaces.filter(device=device)
    return [
        {"name": iface.name, "device": device, "description": iface.description or ""}
        for iface in interfaces
    ]


async def _print_labels(model: str, images: Iterable, dry_run: bool) -> None:
    printer_model = PRINTER_MODELS[model]
    if dry_run:
        transport = CaptureTransport()
    else:
        if printer_model.usb_vid is None or printer_model.usb_pid is None:
            raise SystemExit(f"{model} has no known USB VID/PID")
        transport = UsbTransport(vid=printer_model.usb_vid, pid=printer_model.usb_pid)

    async with transport:
        printer = BradyPrinter(transport, model=model)
        for img in images:
            await printer.print(img, cut_mode=CutMode.END_OF_LABEL)

    if dry_run and isinstance(transport, CaptureTransport):
        print(summary(transport.data))


def _build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="nautobot_port_labels", description=__doc__)
    p.add_argument("--nautobot", help="Nautobot base URL (omit to use stub data)")
    p.add_argument("--token", help="Nautobot API token (required with --nautobot)")
    p.add_argument("--device", help="Device name to pull interfaces for")
    p.add_argument("--out", type=Path, help="Directory to write per-label PNGs to")
    p.add_argument("--dry-run", action="store_true", help="Capture bytes instead of printing")
    p.add_argument("--print", action="store_true", dest="do_print", help="Send to BMP51 over USB")
    p.add_argument("--model", default="BMP51", choices=sorted(PRINTER_MODELS))
    return p


def main(argv: list[str] | None = None) -> int:
    args = _build_parser().parse_args(argv)

    if args.nautobot:
        if not (args.token and args.device):
            raise SystemExit("--nautobot also requires --token and --device")
        rows = fetch_ports_nautobot(args.nautobot, args.token, args.device)
    else:
        rows = fetch_ports_stub()

    print(f"fetched {len(rows)} ports")

    # cable_wrap expects a 'text' kwarg; the source uses 'name'. One-line
    # column rename — this is the whole integration interface.
    labels = from_rows(cable_wrap, rows, mapping={"name": "text"})

    if args.out:
        args.out.mkdir(parents=True, exist_ok=True)
        for row, img in zip(rows, labels, strict=True):
            safe_name = row["name"].replace("/", "_").replace(" ", "_")
            img.save(args.out / f"{safe_name}.png")
        print(f"wrote {len(labels)} PNGs to {args.out}")

    if args.do_print or args.dry_run:
        asyncio.run(_print_labels(args.model, labels, args.dry_run))

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
