# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Generate a batch of cable labels from a sequence expression.

Typical network-engineer rack-build workflow:

    # Print 48 wrap labels for a patch panel
    uv run python examples/sequence_cable_labels.py "eth0..eth47" --print

    # Fold-over flag labels for a two-row 24-port panel (A+B halves)
    uv run python examples/sequence_cable_labels.py "A1..A24,B1..B24" --flag

    # Render to PNGs first to visually sanity-check before burning media
    uv run python examples/sequence_cable_labels.py "eth0..eth3" --out /tmp/cables

    # Dry-run so you can inspect the ESC/BMP byte stream
    uv run python examples/sequence_cable_labels.py "eth0..eth3" --dry-run

The sequence-expression language (see `pybrady.templates.sequence`)
covers the patterns real racks use: `eth0..eth47`, `HOST-001..HOST-048`,
`A1..A24,B1..B24`, rack-12-port0..rack-12-port7, etc.
"""

from __future__ import annotations

import argparse
import asyncio
from pathlib import Path

from pybrady import PRINTER_MODELS, BradyPrinter, CutMode
from pybrady.protocol.esc_bmp_decode import summary
from pybrady.templates.cable import cable_flag, cable_wrap
from pybrady.templates.sequence import expand
from pybrady.transport import CaptureTransport, UsbTransport


def _build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="sequence_cable_labels", description=__doc__)
    p.add_argument("expression", help="Sequence expression, e.g. 'eth0..eth47'.")
    p.add_argument(
        "--flag", action="store_true", help="Use cable_flag (fold-over) instead of cable_wrap."
    )
    p.add_argument("--width-in", type=float, default=2.0)
    p.add_argument("--height-in", type=float, default=0.5)
    p.add_argument(
        "--copies", type=int, help="Pass an explicit copy count to cable_wrap (auto-fit otherwise)."
    )
    p.add_argument("--out", type=Path, help="Directory to write per-label PNGs to.")
    p.add_argument("--dry-run", action="store_true", help="Capture bytes instead of printing.")
    p.add_argument("--print", action="store_true", dest="do_print", help="Send to BMP51 over USB.")
    p.add_argument("--model", default="BMP51", choices=sorted(PRINTER_MODELS))
    return p


async def _print_labels(model: str, images: list, dry_run: bool) -> None:
    printer_model = PRINTER_MODELS[model]
    if dry_run:
        transport = CaptureTransport()
    else:
        if printer_model.usb_vid is None or printer_model.usb_pid is None:
            raise SystemExit(f"{model} has no known USB VID/PID")
        transport = UsbTransport(vid=printer_model.usb_vid, pid=printer_model.usb_pid)

    async with transport:
        printer = BradyPrinter(transport, model=model)
        for img in images:
            await printer.print(img, cut_mode=CutMode.END_OF_LABEL)

    if dry_run and isinstance(transport, CaptureTransport):
        print(summary(transport.data))


def main(argv: list[str] | None = None) -> int:
    args = _build_parser().parse_args(argv)

    identifiers = expand(args.expression)
    print(f"expanded {args.expression!r} into {len(identifiers)} identifiers")

    render = cable_flag if args.flag else cable_wrap
    kwargs: dict = {"width_in": args.width_in, "height_in": args.height_in}
    if not args.flag and args.copies is not None:
        kwargs["copies"] = args.copies

    labels = [render(ident, **kwargs) for ident in identifiers]

    if args.out:
        args.out.mkdir(parents=True, exist_ok=True)
        for ident, img in zip(identifiers, labels, strict=True):
            # Use the identifier in the filename so users can spot-check
            # a specific label without opening every file.
            safe_name = ident.replace("/", "_").replace(" ", "_")
            img.save(args.out / f"{safe_name}.png")
        print(f"wrote {len(labels)} PNGs to {args.out}")

    if args.do_print or args.dry_run:
        asyncio.run(_print_labels(args.model, labels, args.dry_run))

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
