# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Render and (optionally) print a batch of asset tags from a CSV file.

The CSV format this example expects is minimal:

    asset_id,description
    ACME-00001,Laptop Dell XPS 13
    ACME-00002,Laptop Dell XPS 13
    ACME-00003,Monitor 27"

If your CSV already uses 'identifier' and 'description' as column
names, drop `--mapping`. The column-rename argument exists to show
how the generic `from_row` contract adapts a template to whatever
vocabulary your upstream source of truth (DCIM, CMDB, ops
spreadsheet) already uses.

Typical runs:

    # Render every row to a PNG under /tmp/asset-tags/
    uv run python examples/csv_asset_tags.py assets.csv --out /tmp/asset-tags

    # Dry-run: print byte-count summary per label without touching the printer
    uv run python examples/csv_asset_tags.py assets.csv --dry-run

    # Print the first 5 rows to a BMP51 over USB
    uv run python examples/csv_asset_tags.py assets.csv --print --limit 5
"""

from __future__ import annotations

import argparse
import asyncio
from pathlib import Path

from pybrady import PRINTER_MODELS, BradyPrinter, CutMode
from pybrady.protocol.esc_bmp_decode import summary
from pybrady.templates.asset_tag import asset_tag
from pybrady.templates.parametric import render_from_csv
from pybrady.transport import CaptureTransport, UsbTransport


def _build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="csv_asset_tags", description=__doc__)
    p.add_argument("csv", type=Path, help="CSV file with a header row")
    p.add_argument(
        "--mapping",
        nargs="*",
        default=["asset_id=identifier", "name=description"],
        metavar="CSV_COL=TEMPLATE_KW",
        help=(
            "Rename CSV columns to asset_tag kwargs. Default handles a "
            "typical CMDB export ('asset_id', 'name')."
        ),
    )
    p.add_argument("--out", type=Path, help="Directory to write per-label PNGs to.")
    p.add_argument("--limit", type=int, help="Only process the first N rows.")
    p.add_argument("--dry-run", action="store_true", help="Capture bytes instead of printing.")
    p.add_argument(
        "--print", action="store_true", dest="do_print", help="Send to a BMP51 over USB."
    )
    p.add_argument("--model", default="BMP51", choices=sorted(PRINTER_MODELS))
    return p


async def _print_labels(model: str, images: list, dry_run: bool) -> None:
    printer_model = PRINTER_MODELS[model]
    if dry_run:
        transport = CaptureTransport()
    else:
        if printer_model.usb_vid is None or printer_model.usb_pid is None:
            raise SystemExit(f"{model} has no known USB VID/PID")
        transport = UsbTransport(vid=printer_model.usb_vid, pid=printer_model.usb_pid)

    async with transport:
        printer = BradyPrinter(transport, model=model)
        for img in images:
            await printer.print(img, cut_mode=CutMode.END_OF_LABEL)

    if dry_run and isinstance(transport, CaptureTransport):
        print(summary(transport.data))


def main(argv: list[str] | None = None) -> int:
    args = _build_parser().parse_args(argv)

    mapping = dict(kv.split("=", 1) for kv in args.mapping) if args.mapping else {}

    labels = render_from_csv(args.csv, asset_tag, mapping=mapping)
    if args.limit is not None:
        labels = labels[: args.limit]
    print(f"rendered {len(labels)} labels from {args.csv}")

    if args.out:
        args.out.mkdir(parents=True, exist_ok=True)
        for i, img in enumerate(labels):
            img.save(args.out / f"label-{i:04d}.png")
        print(f"wrote {len(labels)} PNGs to {args.out}")

    if args.do_print or args.dry_run:
        asyncio.run(_print_labels(args.model, labels, args.dry_run))

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
