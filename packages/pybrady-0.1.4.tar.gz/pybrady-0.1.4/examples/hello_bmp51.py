# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Print a small 'HELLO' label on a BMP51 over USB — or dry-run it first.

# Validate what we'd send without burning any media:
uv run python examples/hello_bmp51.py --dry-run

# Save the byte stream for offline inspection:
uv run python examples/hello_bmp51.py --dry-run --save hello.prn

# Dump the full hex of the byte stream:
uv run python examples/hello_bmp51.py --dry-run --hex-dump

# Actually print:
uv run python examples/hello_bmp51.py
"""

from __future__ import annotations

import argparse
import asyncio

from PIL import Image, ImageDraw, ImageFont

from pybrady import BradyPrinter, CutMode
from pybrady.protocol.esc_bmp_decode import summary
from pybrady.transport import CaptureTransport, UsbTransport
from pybrady.transport.base import AsyncTransport


def render_hello() -> Image.Image:
    # BMP51 is 300 DPI. This is roughly 1" x 0.5" of printable area.
    width, height = 300, 150
    img = Image.new("1", (width, height), 1)  # white background
    draw = ImageDraw.Draw(img)
    try:
        font = ImageFont.truetype("DejaVuSans-Bold.ttf", 72)
    except OSError:
        font = ImageFont.load_default()
    draw.text((20, 30), "HELLO", fill=0, font=font)  # black text
    return img


def hex_dump(data: bytes, width: int = 16) -> str:
    lines = []
    for i in range(0, len(data), width):
        chunk = data[i : i + width]
        hexed = " ".join(f"{b:02x}" for b in chunk)
        ascii_ = "".join(chr(b) if 0x20 <= b < 0x7F else "." for b in chunk)
        lines.append(f"{i:08x}  {hexed:<{width * 3}}  {ascii_}")
    return "\n".join(lines)


async def run(transport: AsyncTransport, image: Image.Image, cut_mode: CutMode) -> None:
    async with transport:
        printer = BradyPrinter(transport, model="BMP51")
        await printer.print(image, cut_mode=cut_mode)


def main() -> None:
    ap = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    ap.add_argument(
        "--dry-run",
        action="store_true",
        help="Capture bytes instead of sending to the printer",
    )
    ap.add_argument(
        "--hex-dump",
        action="store_true",
        help="With --dry-run: print a full hex dump of the byte stream",
    )
    ap.add_argument(
        "--save",
        metavar="PATH",
        help="With --dry-run: write raw bytes to this file (for later inspection/replay)",
    )
    ap.add_argument(
        "--cut",
        choices=["end-of-job", "end-of-label"],
        default="end-of-job",
        help="Cut behaviour (default: end-of-job)",
    )
    args = ap.parse_args()

    cut_mode = CutMode.END_OF_JOB if args.cut == "end-of-job" else CutMode.END_OF_LABEL
    image = render_hello()

    if args.dry_run:
        transport = CaptureTransport()
        asyncio.run(run(transport, image, cut_mode))
        print(summary(transport.data))
        if args.hex_dump:
            print()
            print(hex_dump(transport.data))
        if args.save:
            transport.save(args.save)
            print(f"\nsaved {len(transport.data)} bytes to {args.save}")
        return

    asyncio.run(run(UsbTransport.find_bmp51(), image, cut_mode))
    print("printed")


if __name__ == "__main__":
    main()
