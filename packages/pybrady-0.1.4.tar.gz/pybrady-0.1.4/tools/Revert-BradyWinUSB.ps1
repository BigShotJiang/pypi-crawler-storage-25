# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

<#
.SYNOPSIS
    Undo a Zadig WinUSB driver swap on a Brady BMP51 and restore the stock
    Brady driver so Brady Workstation can see the printer again.

.DESCRIPTION
    When pybrady's UsbTransport is used on Windows, Zadig rebinds the BMP51
    to WinUSB. That's reversible via Device Manager (Uninstall device → tick
    "Delete the driver software for this device" → replug), but people find
    the Device Manager flow fiddly because the BMP51 can live under either
    "Universal Serial Bus devices" or "Printers" depending on the current
    binding.

    This script does the same thing non-interactively via `pnputil`:

    1. Finds the BMP51 PnP instance (VID 0e2e / PID 000b).
    2. Looks up the INF file Windows currently has bound.
    3. If that INF looks like a WinUSB replacement (class USBDevice), deletes
       the driver package from the driver store with `pnputil /delete-driver
       /uninstall /force`. Windows automatically re-enumerates the device
       with whatever stock driver it has cached (or re-downloads from
       Windows Update if missing).
    4. Verifies the device comes back under the Printer class.

    Requires administrator privileges — `pnputil /delete-driver` is
    privileged. Run from an elevated PowerShell session.

.PARAMETER Vid
    USB Vendor ID to target. Defaults to 0e2e (Brady).

.PARAMETER Pid
    USB Product ID to target. Defaults to 000b (BMP51/53).

.PARAMETER Force
    Skip the confirmation prompt and just do it.

.EXAMPLE
    # From an elevated PowerShell, from the pybrady repo root:
    .\tools\Revert-BradyWinUSB.ps1

.EXAMPLE
    .\tools\Revert-BradyWinUSB.ps1 -Force
#>

[CmdletBinding(SupportsShouldProcess = $true)]
param(
    [string]$Vid = '0E2E',
    [string]$Pid = '000B',
    [switch]$Force
)

$ErrorActionPreference = 'Stop'

function Test-IsAdmin {
    $user = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal $user
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

if (-not (Test-IsAdmin)) {
    Write-Error "This script must be run from an elevated PowerShell session (pnputil requires admin)."
    exit 2
}

$idPattern = "USB\VID_$Vid&PID_$Pid*"
Write-Host "Looking for PnP devices matching $idPattern ..."

$devices = Get-PnpDevice | Where-Object { $_.InstanceId -like $idPattern }
if (-not $devices) {
    Write-Warning "No devices matched $idPattern. Is the printer plugged in?"
    exit 1
}

Write-Host ""
Write-Host "Current state:"
foreach ($d in $devices) {
    $inf = (Get-PnpDeviceProperty -InstanceId $d.InstanceId -KeyName 'DEVPKEY_Device_DriverInfPath' -ErrorAction SilentlyContinue).Data
    Write-Host ("  {0,-30} class={1,-12} status={2,-8} inf={3}" -f $d.FriendlyName, $d.Class, $d.Status, $inf)
}
Write-Host ""

# Filter to "live" entries only (status OK). Stale entries are leftover from
# previous port changes and Windows cleans them up on its own.
$live = $devices | Where-Object { [string]$_.Status -eq 'OK' }
if (-not $live) {
    Write-Warning "No live (Status=OK) BMP51 entries. The printer may be unplugged."
    exit 1
}

# Find INFs that look like Zadig-installed WinUSB replacements (Class: USBDevice
# + an oem*.inf path). Stock Brady drivers show Class: Printer; in-box drivers
# typically have no oem*.inf name.
$targets = $live | Where-Object {
    $_.Class -eq 'USBDevice'
} | ForEach-Object {
    $inf = (Get-PnpDeviceProperty -InstanceId $_.InstanceId -KeyName 'DEVPKEY_Device_DriverInfPath' -ErrorAction SilentlyContinue).Data
    if ($inf -and $inf -like 'oem*.inf') {
        [PSCustomObject]@{
            InstanceId = $_.InstanceId
            Inf        = $inf
        }
    }
}

if (-not $targets) {
    Write-Host "No Zadig-style WinUSB binding found on any live BMP51 entry."
    Write-Host "Nothing to revert — the stock Brady driver is already in charge."
    exit 0
}

Write-Host "Will delete these WinUSB driver package(s) from the driver store:"
foreach ($t in $targets) {
    Write-Host "  $($t.Inf)  (bound to $($t.InstanceId))"
}
Write-Host ""

if (-not $Force -and -not $PSCmdlet.ShouldProcess("WinUSB drivers above", "Uninstall via pnputil")) {
    Write-Host "Dry-run: pass -Force (or run without -WhatIf) to actually uninstall."
    exit 0
}

foreach ($t in ($targets | Select-Object -ExpandProperty Inf -Unique)) {
    Write-Host "Running: pnputil /delete-driver $t /uninstall /force"
    & pnputil.exe /delete-driver $t /uninstall /force
    if ($LASTEXITCODE -ne 0) {
        Write-Warning "pnputil exited with code $LASTEXITCODE for $t; continuing."
    }
}

Write-Host ""
Write-Host "Waiting 3 seconds for Windows to re-enumerate the device ..."
Start-Sleep -Seconds 3

$after = Get-PnpDevice | Where-Object { $_.InstanceId -like $idPattern }
Write-Host ""
Write-Host "New state:"
foreach ($d in $after) {
    $inf = (Get-PnpDeviceProperty -InstanceId $d.InstanceId -KeyName 'DEVPKEY_Device_DriverInfPath' -ErrorAction SilentlyContinue).Data
    Write-Host ("  {0,-30} class={1,-12} status={2,-8} inf={3}" -f $d.FriendlyName, $d.Class, $d.Status, $inf)
}
Write-Host ""

$printerLive = $after | Where-Object { $_.Class -eq 'Printer' -and [string]$_.Status -eq 'OK' }
if ($printerLive) {
    Write-Host "Done — the BMP51 is back under the Printer class. Brady Workstation should now see it."
    exit 0
}

Write-Warning "Driver uninstall completed but the BMP51 did not come back as Class=Printer."
Write-Warning "Unplug and replug the USB cable; Windows will re-detect the stock Brady driver."
exit 0
