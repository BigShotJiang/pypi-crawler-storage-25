# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

<#
.SYNOPSIS
    Copies Brady Workstation's bundled label templates (*.BWT), fonts, and
    icon library to a portable directory. Pure-PowerShell equivalent of
    the `brady-export-templates` Python tool.

.DESCRIPTION
    Brady Workstation installs its template library under
    C:\ProgramData\Brady Corp\Brady Workstation\Addins\<app>\Templates\,
    its branded TTF fonts under C:\Windows\Fonts\Brady*.ttf, and its
    SVG icon library under Components\ImageLibrary\. Those files are
    Brady's copyrighted material and can't be redistributed with
    pybrady, but a user who owns Brady Workstation can run this script
    to pull them into a directory that pybrady and etiket can consume
    offline.

    This is the zero-dependency version of `brady-export-templates` —
    pure PowerShell, so a Windows user without Python installed can
    still produce the exported library. It does NOT write a manifest.
    For per-template metadata, use the Python tool instead.

.PARAMETER Source
    The Brady Workstation ProgramData directory containing an 'Addins'
    subdirectory. Auto-detected from $env:ProgramData if omitted.

.PARAMETER Target
    Directory to copy templates into. Created if it does not exist.
    Defaults to $env:PYBRADY_DATA_DIR if set, otherwise
    $HOME\pybrady\brady-templates.

.PARAMETER SkipFonts
    Skip copying Brady-branded TTF fonts. By default any font under the
    system Fonts folder whose filename starts with 'Brady ' is copied
    into a Fonts\ subdirectory of the target so downstream renderers
    can load them.

.PARAMETER SkipIcons
    Skip copying Brady's icon library (Components\ImageLibrary). By
    default the whole library is copied to an Icons\ subdirectory of
    the target so pybrady.icons can search and rasterise them.

.PARAMETER Bundle
    After exporting, also pack the target directory into a single
    archive at this path for transport to other hosts. Format is
    inferred from the extension: .zip (default for unrecognised
    extensions; handled natively by PowerShell and File Explorer),
    .tar.gz / .tgz / .tar.bz2 / .tar.xz / .tar. Tar variants shell out
    to tar.exe (bundled with Windows 10 1803+).

.PARAMETER FromBundle
    Skip Brady Workstation discovery and instead extract an archive
    produced by -Bundle into the target directory. Mutually exclusive
    with -Source.

.PARAMETER WhatIf
    Standard PowerShell support; preview what would be copied without
    writing any files.

.EXAMPLE
    .\Export-BradyTemplates.ps1

.EXAMPLE
    .\Export-BradyTemplates.ps1 -Target C:\Users\me\brady-templates

.EXAMPLE
    .\Export-BradyTemplates.ps1 -Bundle C:\Temp\brady.zip

.EXAMPLE
    .\Export-BradyTemplates.ps1 -FromBundle C:\Temp\brady.zip -Target D:\restored
#>

[CmdletBinding(SupportsShouldProcess = $true)]
param(
    [string]$Source,
    [string]$Target,
    [switch]$SkipFonts,
    [switch]$SkipIcons,
    [string]$Bundle,
    [string]$FromBundle
)

$ErrorActionPreference = 'Stop'

if (-not $Target) {
    if ($env:PYBRADY_DATA_DIR) {
        $Target = $env:PYBRADY_DATA_DIR
    } else {
        $Target = Join-Path $HOME 'pybrady\brady-templates'
    }
}

if ($FromBundle -and $Source) {
    Write-Error "-FromBundle and -Source are mutually exclusive."
    exit 2
}

$knownArchiveSuffixes = @('.tar.gz', '.tgz', '.tar.bz2', '.tbz2', '.tar.xz', '.txz', '.tar', '.zip')

function Test-IsRecognisedArchiveName {
    param([string]$Name)
    $lower = $Name.ToLowerInvariant()
    foreach ($suffix in $knownArchiveSuffixes) {
        if ($lower.EndsWith($suffix)) { return $true }
    }
    return $false
}

function Get-ArchiveFormat {
    # Returns one of: 'zip', 'tar', 'tar.gz', 'tar.bz2', 'tar.xz'.
    # Falls back to 'zip' for unrecognised extensions — matches the
    # Python tool's Windows-friendly default.
    param([string]$Path)
    $lower = (Split-Path -Leaf $Path).ToLowerInvariant()
    if ($lower.EndsWith('.zip')) { return 'zip' }
    if ($lower.EndsWith('.tar.gz') -or $lower.EndsWith('.tgz')) { return 'tar.gz' }
    if ($lower.EndsWith('.tar.bz2') -or $lower.EndsWith('.tbz2')) { return 'tar.bz2' }
    if ($lower.EndsWith('.tar.xz') -or $lower.EndsWith('.txz')) { return 'tar.xz' }
    if ($lower.EndsWith('.tar')) { return 'tar' }
    return 'zip'
}

function New-BradyBundle {
    # Pack $SourceDir into $DestPath. If $DestPath has no recognised
    # archive extension, .zip is appended to avoid confusion about the
    # actual format. Returns the path actually written.
    param(
        [string]$SourceDir,
        [string]$DestPath
    )
    $format = Get-ArchiveFormat -Path $DestPath
    $final = $DestPath
    if (-not (Test-IsRecognisedArchiveName -Name $DestPath)) {
        $final = "$DestPath.zip"
    }
    $destDir = Split-Path -Parent $final
    if ($destDir -and -not (Test-Path -LiteralPath $destDir)) {
        New-Item -ItemType Directory -Path $destDir -Force | Out-Null
    }
    if (Test-Path -LiteralPath $final) {
        Remove-Item -LiteralPath $final -Force
    }

    switch ($format) {
        'zip' {
            # Compress-Archive is natively available, no extra tooling needed.
            # Using wildcard path packs the contents plus a top-level dir
            # matching the source's name — same layout as shutil.make_archive.
            $parent = Split-Path -Parent $SourceDir
            $leaf = Split-Path -Leaf $SourceDir
            Push-Location $parent
            try {
                Compress-Archive -Path $leaf -DestinationPath $final -Force
            } finally {
                Pop-Location
            }
        }
        default {
            # Tar variants: shell out to tar.exe (ships with Windows 10
            # 1803+ / Windows 11). tar's -C + relative base_dir argument
            # gives us the same single-top-level-directory layout as the
            # zip path above.
            $tar = Get-Command tar.exe -ErrorAction SilentlyContinue
            if (-not $tar) {
                throw "tar.exe not found on PATH. Use -Bundle path.zip (no extra tools required) or install Windows 10 1803+ / Windows 11 which bundles tar."
            }
            $parent = Split-Path -Parent $SourceDir
            $leaf = Split-Path -Leaf $SourceDir
            $flag = switch ($format) {
                'tar' { '-cf' }
                'tar.gz' { '-czf' }
                'tar.bz2' { '-cjf' }
                'tar.xz' { '-cJf' }
            }
            & tar.exe $flag $final -C $parent $leaf
            if ($LASTEXITCODE -ne 0) {
                throw "tar.exe exited with code $LASTEXITCODE while packing $final"
            }
        }
    }
    return $final
}

function Expand-BradyBundle {
    # Extract $ArchivePath into $DestDir. Handles both zip (native
    # Expand-Archive) and tar variants (tar.exe). $DestDir receives the
    # archive's single top-level directory verbatim, so callers pass the
    # *parent* of where the data dir should end up.
    param(
        [string]$ArchivePath,
        [string]$DestDir
    )
    if (-not (Test-Path -LiteralPath $ArchivePath -PathType Leaf)) {
        throw "Archive $ArchivePath does not exist."
    }
    if (-not (Test-Path -LiteralPath $DestDir)) {
        New-Item -ItemType Directory -Path $DestDir -Force | Out-Null
    }
    $format = Get-ArchiveFormat -Path $ArchivePath
    if ($format -eq 'zip') {
        Expand-Archive -LiteralPath $ArchivePath -DestinationPath $DestDir -Force
    } else {
        $tar = Get-Command tar.exe -ErrorAction SilentlyContinue
        if (-not $tar) {
            throw "tar.exe not found on PATH. Re-bundle as .zip, or install Windows 10 1803+ / Windows 11."
        }
        & tar.exe -xf $ArchivePath -C $DestDir
        if ($LASTEXITCODE -ne 0) {
            throw "tar.exe exited with code $LASTEXITCODE while extracting $ArchivePath"
        }
    }
}

function Find-WorkstationDataDir {
    param([string]$Explicit)

    if ($Explicit) {
        if (-not (Test-Path (Join-Path $Explicit 'Addins') -PathType Container)) {
            throw "$Explicit doesn't look like a Brady Workstation data directory (no 'Addins' subdirectory)."
        }
        return $Explicit
    }

    $candidates = @()
    if ($env:ProgramData) {
        $candidates += (Join-Path $env:ProgramData 'Brady Corp\Brady Workstation')
    }
    $candidates += 'C:\ProgramData\Brady Corp\Brady Workstation'

    foreach ($candidate in $candidates) {
        if (Test-Path (Join-Path $candidate 'Addins') -PathType Container) {
            return $candidate
        }
    }

    throw "Could not auto-discover a Brady Workstation install. Pass -Source explicitly. Looked in: $($candidates -join ', ')"
}

# -------- Extract-only mode: skip Workstation discovery entirely. --------
if ($FromBundle) {
    $parent = Split-Path -Parent $Target
    if (-not $parent) { $parent = '.' }
    Write-Host "target: $Target"
    if ($PSCmdlet.ShouldProcess($parent, "Extract $FromBundle")) {
        Expand-BradyBundle -ArchivePath $FromBundle -DestDir $parent
        Write-Host "extracted $FromBundle into $parent"
    } else {
        Write-Host "would extract $FromBundle into $parent (WhatIf)"
    }
    exit 0
}

# -------- Export mode: discover Brady Workstation install and copy. --------
$sourceDir = Find-WorkstationDataDir -Explicit $Source
Write-Host "source: $sourceDir"
Write-Host "target: $Target"

$addinsDir = Join-Path $sourceDir 'Addins'
$addins = Get-ChildItem -LiteralPath $addinsDir -Directory -ErrorAction SilentlyContinue
if (-not $addins) {
    Write-Error "No addins found under $addinsDir"
    exit 1
}

$totalCopied = 0
$perAddin = [ordered]@{}

foreach ($addin in $addins) {
    $templatesDir = Join-Path $addin.FullName 'Templates'
    if (-not (Test-Path -LiteralPath $templatesDir -PathType Container)) {
        continue
    }

    $bwtFiles = Get-ChildItem -LiteralPath $templatesDir -Recurse -Filter '*.BWT' -File
    if (-not $bwtFiles) { continue }

    foreach ($bwt in $bwtFiles) {
        # Preserve the Addins/<app>/Templates/... relative path under the target
        $relative = $bwt.FullName.Substring($sourceDir.Length).TrimStart('\', '/')
        $dest = Join-Path $Target $relative
        $destDir = Split-Path -Parent $dest

        if ($PSCmdlet.ShouldProcess($dest, "Copy $($bwt.FullName)")) {
            if (-not (Test-Path -LiteralPath $destDir)) {
                New-Item -ItemType Directory -Path $destDir -Force | Out-Null
            }
            Copy-Item -LiteralPath $bwt.FullName -Destination $dest -Force
        }
        $totalCopied++
    }
    $perAddin[$addin.Name] = $bwtFiles.Count
}

if ($totalCopied -eq 0) {
    Write-Warning "No .BWT templates found under $addinsDir. Is the addin library populated?"
    exit 1
}

$fontCopied = @()
if (-not $SkipFonts) {
    # Brady Workstation installs its branded TTFs (Brady Alpine*, Brady Fixed Width*)
    # into the Windows Fonts directory. They're TrueType and therefore
    # cross-platform — copying them into Fonts\ lets render_bws render labels
    # with the correct glyphs regardless of where the user runs the renderer.
    $systemFonts = Join-Path $env:WINDIR 'Fonts'
    if (Test-Path -LiteralPath $systemFonts -PathType Container) {
        $fontDest = Join-Path $Target 'Fonts'
        foreach ($font in Get-ChildItem -LiteralPath $systemFonts -Filter 'Brady *.ttf' -File) {
            $dest = Join-Path $fontDest $font.Name
            if ($PSCmdlet.ShouldProcess($dest, "Copy $($font.FullName)")) {
                if (-not (Test-Path -LiteralPath $fontDest)) {
                    New-Item -ItemType Directory -Path $fontDest -Force | Out-Null
                }
                Copy-Item -LiteralPath $font.FullName -Destination $dest -Force
            }
            $fontCopied += $font.Name
        }
    }
}

$iconCopied = 0
$iconHasIndex = $false
if (-not $SkipIcons) {
    # Brady Workstation's icon library (arrows, GHS / ANSI / ISO symbology,
    # thousands of SVGs plus a graphicMetadata.xml index) ships under
    # Components\ImageLibrary. The XML indexes files by exact filename, so
    # we never filter — wholesale recursive copy into Icons\.
    $imageLibrary = Join-Path $sourceDir 'Components\ImageLibrary'
    if (Test-Path -LiteralPath $imageLibrary -PathType Container) {
        $iconDest = Join-Path $Target 'Icons'
        if ($PSCmdlet.ShouldProcess($iconDest, "Copy icon library from $imageLibrary")) {
            if (Test-Path -LiteralPath $iconDest) {
                Remove-Item -LiteralPath $iconDest -Recurse -Force
            }
            Copy-Item -LiteralPath $imageLibrary -Destination $iconDest -Recurse -Force
            $iconCopied = (Get-ChildItem -LiteralPath $iconDest -Recurse -File).Count
            $iconHasIndex = Test-Path -LiteralPath (Join-Path $iconDest 'graphicMetadata.xml') -PathType Leaf
        } else {
            # In WhatIf mode we still report what would have been copied.
            $iconCopied = (Get-ChildItem -LiteralPath $imageLibrary -Recurse -File).Count
            $iconHasIndex = Test-Path -LiteralPath (Join-Path $imageLibrary 'graphicMetadata.xml') -PathType Leaf
        }
    }
}

Write-Host ""
Write-Host "$totalCopied templates processed:"
foreach ($name in $perAddin.Keys) {
    $count = $perAddin[$name]
    Write-Host ("  {0,-20} {1,5}" -f $name, $count)
}
if ($fontCopied.Count -gt 0) {
    Write-Host ""
    Write-Host "$($fontCopied.Count) Brady fonts copied:"
    foreach ($f in $fontCopied) {
        Write-Host ("  " + [System.IO.Path]::GetFileNameWithoutExtension($f))
    }
}
if ($iconCopied -gt 0) {
    $status = if ($iconHasIndex) { 'with' } else { 'WITHOUT' }
    Write-Host ""
    Write-Host "Icon library: $iconCopied files ($status graphicMetadata.xml)"
}

if ($Bundle) {
    if ($PSCmdlet.ShouldProcess($Bundle, "Bundle target into archive")) {
        $written = New-BradyBundle -SourceDir $Target -DestPath $Bundle
        Write-Host ""
        Write-Host "bundled target into $written"
    } else {
        Write-Host ""
        Write-Host "would bundle target into $Bundle (WhatIf)"
    }
}
