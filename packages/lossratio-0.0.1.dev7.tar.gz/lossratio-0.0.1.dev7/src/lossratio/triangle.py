"""Triangle: cohort x dev aggregated experience data."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import polars as pl

from ._io import detect_input_type, mirror_output, to_polars
from .experience import REQUIRED_COLS

if TYPE_CHECKING:
    from .link import Link
    from .regime import Regime


_VALID_DEV_VARS = {"elap_m", "elap_q", "elap_h", "elap_y"}
_DEV_VAR_TO_TYPE = {
    "elap_m": "month",
    "elap_q": "quarter",
    "elap_h": "half",
    "elap_y": "year",
}


def _compute_dev(
    df: pl.DataFrame,
    cohort_var: str,
    cym_var: str,
    dev_var: str,
) -> pl.DataFrame:
    """Add a numeric dev column derived from cohort_var and cym_var."""
    dev_type = _DEV_VAR_TO_TYPE.get(dev_var)
    if dev_type == "month":
        elap = (
            (pl.col(cym_var).dt.year() - pl.col(cohort_var).dt.year()) * 12
            + (pl.col(cym_var).dt.month() - pl.col(cohort_var).dt.month())
            + 1
        )
    elif dev_type == "quarter":
        elap = (
            (pl.col(cym_var).dt.year() - pl.col(cohort_var).dt.year()) * 4
            + ((pl.col(cym_var).dt.month() - 1) // 3
               - (pl.col(cohort_var).dt.month() - 1) // 3)
            + 1
        )
    elif dev_type == "half":
        elap = (
            (pl.col(cym_var).dt.year() - pl.col(cohort_var).dt.year()) * 2
            + ((pl.col(cym_var).dt.month() - 1) // 6
               - (pl.col(cohort_var).dt.month() - 1) // 6)
            + 1
        )
    elif dev_type == "year":
        elap = pl.col(cym_var).dt.year() - pl.col(cohort_var).dt.year() + 1
    else:
        raise ValueError(
            f"dev_var must be one of {sorted(_VALID_DEV_VARS)}, got {dev_var!r}"
        )

    return df.with_columns(elap.cast(pl.Int64).alias("_dev_temp"))


class Triangle:
    """Cohort x development period aggregated experience data.

    A Triangle is built by aggregating a raw experience DataFrame
    (polars or pandas) over ``group_var`` (optional), cohort, and
    development period. Validation and type coercion of the required
    experience columns are performed inline -- there is no separate
    ``Experience`` wrapper class. Users who want an explicit validation
    step can call :func:`validate_experience` first.

    The resulting frame has columns:

    * ``group_var`` -- present only if supplied
    * ``cohort`` -- the underwriting period (renamed from cohort_var)
    * ``dev`` -- the development index (1, 2, ...) within each cohort
    * ``loss``, ``premium`` -- cumulative sums within each (group, cohort)
    * ``loss_incr``, ``premium_incr`` -- per-period sums per cell
    * ``lr`` -- cumulative loss ratio (``loss / premium``)
    * ``lr_incr`` -- per-period loss ratio (``loss_incr / premium_incr``)

    Cumulative is the unmarked default; per-period values carry an
    ``_incr`` (incremental) suffix.

    Original column names (e.g. ``"uym"`` for cohort_var) are kept
    as instance attributes for downstream plotting.
    """

    def __init__(
        self,
        df: "pl.DataFrame | Any",
        group_var: str | None = None,
        cohort_var: str = "uym",
        dev_var: str = "elap_m",
        cym_var: str = "cym",
    ) -> None:
        if dev_var not in _VALID_DEV_VARS:
            raise ValueError(
                f"dev_var must be one of {sorted(_VALID_DEV_VARS)}, got {dev_var!r}"
            )

        self._output_type = detect_input_type(df)
        df_pl = to_polars(df)

        # Validate required columns (experience schema + cohort/cym/group).
        required = set(REQUIRED_COLS) | {cohort_var, cym_var}
        if group_var is not None:
            required.add(group_var)
        missing = required - set(df_pl.columns)
        if missing:
            raise ValueError(
                f"Missing required columns: {sorted(missing)}. "
                f"Required: {sorted(required)}"
            )

        # Coerce required experience types inline.
        df_pl = df_pl.with_columns(
            pl.col(cohort_var).cast(pl.Date),
            pl.col(cym_var).cast(pl.Date),
            pl.col("loss_incr").cast(pl.Float64),
            pl.col("premium_incr").cast(pl.Float64),
        )

        # Compute dev index (1, 2, ...) per cohort
        df_pl = _compute_dev(df_pl, cohort_var, cym_var, dev_var)

        # Aggregate per-period values by (group_var, cohort, dev)
        agg_keys: list[str] = []
        if group_var is not None:
            agg_keys.append(group_var)
        agg_keys.extend([cohort_var, "_dev_temp"])

        agg = (
            df_pl.group_by(agg_keys)
            .agg(
                pl.col("loss_incr").sum(),
                pl.col("premium_incr").sum(),
            )
            .sort(agg_keys)
        )

        # Cumulative sums within (group, cohort) — cumulative is default name
        cum_keys: list[str] = []
        if group_var is not None:
            cum_keys.append(group_var)
        cum_keys.append(cohort_var)

        agg = agg.with_columns(
            pl.col("loss_incr").cum_sum().over(cum_keys).alias("loss"),
            pl.col("premium_incr").cum_sum().over(cum_keys).alias("premium"),
        ).with_columns(
            (pl.col("loss") / pl.col("premium")).alias("lr"),
            (pl.col("loss_incr") / pl.col("premium_incr")).alias("lr_incr"),
        )

        # Rename to standard column names: cohort_var -> cohort, _dev_temp -> dev
        agg = agg.rename({cohort_var: "cohort", "_dev_temp": "dev"})

        # Reorder columns: cum-first paired
        ordered = []
        if group_var is not None:
            ordered.append(group_var)
        ordered.extend([
            "cohort", "dev",
            "loss", "loss_incr",
            "premium", "premium_incr",
            "lr", "lr_incr",
        ])
        agg = agg.select(ordered)

        self._df = agg
        self._group_var = group_var
        self._cohort_var = cohort_var
        self._dev_var = dev_var

    @property
    def df(self):
        """Return the triangle data in the original input format."""
        return mirror_output(self._df, self._output_type)

    def to_polars(self) -> pl.DataFrame:
        """Return the triangle data as a polars DataFrame."""
        return self._df

    def to_pandas(self):
        """Return the triangle data as a pandas DataFrame."""
        return self._df.to_pandas()

    @property
    def n_rows(self) -> int:
        return self._df.height

    @property
    def columns(self) -> list[str]:
        return self._df.columns

    @property
    def group_var(self) -> str | None:
        """Original group variable name (or None if no grouping)."""
        return self._group_var

    @property
    def cohort_var(self) -> str:
        """Original cohort variable name (e.g. 'uym')."""
        return self._cohort_var

    @property
    def dev_var(self) -> str:
        """Development variable name (e.g. 'elap_m')."""
        return self._dev_var

    @property
    def dev_type(self) -> str:
        """Development granularity ('month', 'quarter', 'half', 'year').

        Derived from ``dev_var`` on each access — not stored.
        """
        return _DEV_VAR_TO_TYPE[self._dev_var]

    @classmethod
    def _from_masked(cls, original: "Triangle", masked_df: pl.DataFrame) -> "Triangle":
        """Build a Triangle from a pre-built (masked) DataFrame.

        Used internally by Backtest. ``masked_df`` must already have
        all the standard Triangle columns; this constructor just wraps
        it and copies metadata from ``original``.
        """
        tri = cls.__new__(cls)
        tri._df = masked_df
        tri._output_type = original._output_type
        tri._group_var = original._group_var
        tri._cohort_var = original._cohort_var
        tri._dev_var = original._dev_var
        return tri

    def link(self) -> "Link":
        """Build the long-format link table.

        Returns a :class:`Link` data class — one row per (cohort,
        adjacent dev pair) — that exposes the per-cell ATA factor
        and (when the source Triangle has a premium column) the
        per-cell ED intensity. Diagnostic methods :meth:`Link.ata`
        and :meth:`Link.intensity` aggregate across cohorts to
        per-link summaries.

        ``tri.link()`` is the single canonical entry point for
        factor-level diagnostics. The chains:

        - ``tri.link().ata()``                    → :class:`ATA`
        - ``tri.link().intensity()``              → :class:`Intensity`
        - ``tri.link().ata().maturity(...)``      → :class:`Maturity`

        Examples
        --------
        >>> tri = lr.Triangle(df, group_var="coverage")
        >>> link = tri.link()
        >>> link.ata()                            # multiplicative
        >>> link.intensity()                      # additive
        >>> link.ata().maturity(max_cv=0.15)      # stability detection
        """
        from .link import Link

        return Link._from_triangle(self)

    def detect_regime(
        self,
        loss_var: str = "lr",
        K: int = 12,
        method: str = "e_divisive",
        n_regimes: int | None = None,
        sig_level: float = 0.05,
        R: int = 999,
        min_size: int = 3,
        seed: int | None = None,
    ) -> "Regime":
        """Detect structural regime shifts across underwriting cohorts.

        Each cohort is treated as a feature vector (the chosen
        ``loss_var`` over development periods 1, ..., K). The ordered
        sequence is tested for structural shifts using one of two
        methods:

        * ``"e_divisive"`` — E-Divisive (Matteson & James 2014).
          Multivariate non-parametric divisive change-point detection
          with permutation significance. Number of regimes is
          determined by ``sig_level``.
        * ``"hclust"`` — Ward hierarchical clustering on the
          standardised cohort matrix, cut at ``n_regimes`` clusters.
          Ignores time ordering — useful as a sanity check.

        Parameters
        ----------
        loss_var
            Trajectory variable. Default ``"lr"`` (cumulative loss
            ratio).
        K
            Common development-period window. Cohorts with fewer than
            ``K`` observed periods are dropped.
        method
            ``"e_divisive"`` (default) or ``"hclust"``.
        n_regimes
            Required for ``method="hclust"``. Ignored for
            ``method="e_divisive"`` (auto-detected via permutation
            testing).
        sig_level
            Significance threshold for E-Divisive. Default ``0.05``.
        R
            Number of permutations per significance test. Default
            ``999``.
        min_size
            Minimum cohort count on either side of any candidate split.
            Default ``3``.
        seed
            Optional integer seed for reproducible permutations.

        Returns
        -------
        Regime
            Result with per-cohort regime labels, breakpoints, and
            metadata.
        """
        from .regime import Regime

        return Regime._from_triangle(
            self,
            loss_var=loss_var,
            K=K,
            method=method,
            n_regimes=n_regimes,
            sig_level=sig_level,
            R=R,
            min_size=min_size,
            seed=seed,
        )

    def __repr__(self) -> str:
        bits = [f"{self._df.height:,} rows"]
        if self._group_var is not None:
            n_groups = self._df[self._group_var].n_unique()
            bits.append(f"{n_groups} groups")
        n_cohorts = self._df["cohort"].n_unique()
        n_devs = self._df["dev"].n_unique()
        bits.append(f"{n_cohorts} cohorts x {n_devs} devs")
        return f"<Triangle: {', '.join(bits)}>"

    def __len__(self) -> int:
        return self._df.height
