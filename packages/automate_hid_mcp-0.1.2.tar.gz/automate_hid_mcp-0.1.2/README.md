# automate-hid-mcp

MCP server for ESP32 AutoMate — control keyboard, mouse, actions, WiFi, files, and OTA from LLMs.

## Install

```bash
pip install uv  # if not installed
uvx automate-hid-mcp
```

## Configure

Add to your MCP client config (`claude_desktop_config.json`, `.cursor/mcp.json`, etc.):

```json
{
  "mcpServers": {
    "automate": {
      "command": "uvx",
      "args": ["automate-mcp"]
    }
  }
}
```

## Usage

1. Flash your ESP32-S3 device with the latest AutoMate firmware
2. Power on the device and connect it to WiFi
3. Start your MCP-compatible client (Claude Desktop, Cursor, Codex, Trae, OpenCode) with the above config
4. Ask: "scan for AutoMate devices"
5. Ask: "type hello world on the keyboard"

## Tool Reference

### Discovery
- `scan_devices` — Find all AutoMate devices on the LAN

### Keyboard & Mouse
- `keyboard_type(text)` — Type a text string
- `keyboard_combo(modifiers, key)` — Press a key combination
- `mouse_move(x, y)` — Move mouse to absolute position
- `mouse_click(button)` — Click left/right/middle button
- `mouse_scroll(delta)` — Scroll mouse wheel
- `wait(ms)` — Wait for milliseconds

### Device Status
- `device_status()` — Get device status (WiFi, HID, runner)

### Action Editor
- `action_get_config()`, `action_save_group(json)`, `action_delete_group(id)`
- `action_save_global_settings(json)`, `action_export_group(id)`, `action_export_config()`
- `action_import_group_preview(json)`, `action_import_config_preview(json)`
- `action_import_group_commit(json)`, `action_import_config_commit(json)`
- `action_switch_work_mode(work_mode)`

### Run Control
- `run_start(group_id, loop)` — Start running an action
- `run_stop()` — Stop running action

### Logs, Files, OTA, WiFi
- `log_get(after)`, `fs_list(path)`, `fs_read_file(path)`, `fs_delete_file(path)`
- `fs_storage_info()`, `ota_status()`, `ota_check()`, `ota_start()`
- `wifi_scan()`, `wifi_connect(ssid, password)`
