# MCP 安装指南 (for LLM agents)

当用户请求安装 automate-hid-mcp 时，按以下步骤引导。

## 前置条件

用户主机需已安装 Python 3.10+ 和 `uv`：

```bash
pip install uv
```

## 各客户端配置

**每个 MCP 客户端的配置格式不同。不要假设 JSON 结构——去该客户端的官方文档查找实际格式。**

你只需要记住以下信息：

| 字段 | 值 |
|------|-----|
| server 名称 | `automate`（可自定义） |
| 启动命令 | `uvx` |
| 命令参数 | `["automate-hid-mcp"]` |
| 传输协议 | stdio |

将这些信息填入客户端要求的配置结构中。

### 已知客户端官方文档

| 客户端 | MCP 配置文档 |
|--------|------------|
| Claude Code | [platform.claude.com/docs/en/agents-and-tools/mcp-connector](https://platform.claude.com/docs/en/agents-and-tools/mcp-connector) |
| Cursor | [cursor.com/docs/mcp](https://cursor.com/docs/mcp) |
| Codex (OpenAI) | [developers.openai.com/api/docs/guides/tools-connectors-mcp](https://developers.openai.com/api/docs/guides/tools-connectors-mcp) |
| OpenCode | [opencode.ai/docs/en/mcp-servers](https://opencode.ai/docs/en/mcp-servers/) |

**始终以官方文档中的配置结构和注册方式为准。** 本文档不提供具体的 JSON 配置块——它们会过时。

## 用户对话示例

**不要给用户 JSON 配置。** 按以下模式引导：

> 我需要在你的 {客户端名} 中添加一个 MCP server：
> - 服务器名称：`automate`
> - 命令：`uvx automate-hid-mcp`
> - 传输：stdio
>
> 请根据 {客户端名} 官方文档中的 MCP 配置格式，创建对应的配置项。文档入口在 {对应的官方文档链接}。

## 验证

配置后重启客户端。对话中输入：

> scan for AutoMate devices

若返回设备列表则安装成功。

## 故障排查

| 现象 | 排查 |
|------|------|
| `uvx: command not found` | 先执行 `pip install uv` |
| `automate-hid-mcp: command not found` | 检查 PyPI 包是否已发布，或尝试 `uvx --from git+https://github.com/xxx automate-hid-mcp` |
| `no devices found` | 确认 ESP32 设备已上电且联网；mDNS 需要设备和 MCP Server 在同一局域网 |
| MCP 客户端看不到 automate tool | 确认 JSON 语法正确；重启客户端 |
