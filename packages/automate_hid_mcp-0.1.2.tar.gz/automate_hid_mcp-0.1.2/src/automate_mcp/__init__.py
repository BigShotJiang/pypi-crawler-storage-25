"""automate-hid-mcp: MCP server for ESP32 AutoMate device control."""
