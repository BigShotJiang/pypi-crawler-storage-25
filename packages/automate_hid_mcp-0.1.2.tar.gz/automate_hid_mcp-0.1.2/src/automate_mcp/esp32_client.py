"""Device communication layer: mDNS discovery + HTTP JSON-RPC 2.0 client."""

import time
import requests
from zeroconf import ServiceBrowser, Zeroconf, ServiceListener


class ESP32Error(Exception):
    """Raised when a JSON-RPC call fails."""

    def __init__(self, code: int, message: str, data=None):
        self.code = code
        self.message = message
        self.data = data
        super().__init__(f"[{code}] {message}")


class ESP32Client:
    SERVICE_TYPE = "_automate._tcp.local"

    def __init__(self, timeout: float = 5.0):
        self._default_ip = None
        self._timeout = timeout
        self._rpc_id = 0

    def scan_devices(self, scan_duration: float = 2.0) -> list[dict]:
        """Discover AutoMate devices on the LAN via mDNS.

        Returns:
            list of {"hostname": str, "ip": str, "port": int, "version": str}
        """
        discovered = []

        class Listener(ServiceListener):
            def add_service(self, zc, service_type, name):
                info = zc.get_service_info(service_type, name)
                if info is None:
                    return
                hostname = name.split(".")[0]
                ip_str = ".".join(str(b) for b in info.addresses[0]) if info.addresses else ""
                txt = {}
                if info.properties:
                    for k, v in info.properties.items():
                        key = k.decode() if isinstance(k, bytes) else k
                        txt[key] = v.decode() if isinstance(v, bytes) else v
                discovered.append({
                    "hostname": hostname,
                    "ip": ip_str,
                    "port": info.port,
                    "version": txt.get("version", "unknown"),
                })

            def update_service(self, zc, service_type, name):
                pass

            def remove_service(self, zc, service_type, name):
                pass

        zc = Zeroconf()
        try:
            listener = Listener()
            browser = ServiceBrowser(zc, self.SERVICE_TYPE, listener)
            time.sleep(scan_duration)
        finally:
            zc.close()

        if discovered and self._default_ip is None:
            self._default_ip = discovered[0]["ip"]

        return discovered

    def call(self, method: str, params: dict | None = None, device_ip: str | None = None) -> dict:
        """Execute a JSON-RPC 2.0 call against an ESP32 device.

        Args:
            method: JSON-RPC method name (e.g. "system.status").
            params: Method parameters dict.
            device_ip: Target device IP. Falls back to default device if None.

        Returns:
            Parsed JSON-RPC result dict.

        Raises:
            ESP32Error: On JSON-RPC error response.
            ConnectionError: If device is unreachable.
        """
        ip = device_ip or self._default_ip
        if ip is None:
            raise ESP32Error(-1, "no device configured; run scan_devices first")

        self._rpc_id += 1
        payload = {
            "jsonrpc": "2.0",
            "id": self._rpc_id,
            "method": method,
            "params": params or {},
        }

        try:
            resp = requests.post(
                f"http://{ip}/rpc",
                json=payload,
                timeout=self._timeout,
            )
            resp.raise_for_status()
        except requests.Timeout:
            raise ConnectionError(f"device {ip} unreachable: timeout")
        except requests.ConnectionError:
            raise ConnectionError(f"device {ip} unreachable: connection refused")
        except requests.HTTPError as e:
            raise ConnectionError(f"device {ip} returned HTTP {e.response.status_code}")

        try:
            data = resp.json()
        except requests.exceptions.JSONDecodeError:
            raise ESP32Error(-1, f"device {ip} returned invalid JSON response")

        if "error" in data:
            err = data["error"]
            raise ESP32Error(
                code=err.get("code", -1),
                message=err.get("message", "unknown error"),
                data=err.get("data"),
            )

        if "result" not in data:
            raise ESP32Error(-1, "invalid JSON-RPC response: missing 'result' field")
        return data["result"]
