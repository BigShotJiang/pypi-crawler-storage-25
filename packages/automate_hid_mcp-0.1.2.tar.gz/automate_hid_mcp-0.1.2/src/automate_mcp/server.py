"""MCP server for ESP32 AutoMate — bridge LLMs to keyboard/mouse automation."""

import asyncio
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent

from .esp32_client import ESP32Client, ESP32Error

_client = ESP32Client()

CHAR_TO_KEY = {
    "a": "a", "b": "b", "c": "c", "d": "d", "e": "e", "f": "f",
    "g": "g", "h": "h", "i": "i", "j": "j", "k": "k", "l": "l",
    "m": "m", "n": "n", "o": "o", "p": "p", "q": "q", "r": "r",
    "s": "s", "t": "t", "u": "u", "v": "v", "w": "w", "x": "x",
    "y": "y", "z": "z",
    "0": "0", "1": "1", "2": "2", "3": "3", "4": "4",
    "5": "5", "6": "6", "7": "7", "8": "8", "9": "9",
    " ": "space", "\n": "enter", "\t": "tab",
    ",": "comma", ".": "period", "-": "minus", "=": "equal",
    "/": "slash", "\\": "backslash", ";": "semicolon", "'": "quote",
    "[": "left_bracket", "]": "right_bracket", "`": "grave",
}

SHIFT_MAP = {
    "A": "a", "B": "b", "C": "c", "D": "d", "E": "e", "F": "f",
    "G": "g", "H": "h", "I": "i", "J": "j", "K": "k", "L": "l",
    "M": "m", "N": "n", "O": "o", "P": "p", "Q": "q", "R": "r",
    "S": "s", "T": "t", "U": "u", "V": "v", "W": "w", "X": "x",
    "Y": "y", "Z": "z",
    "!": "1", "@": "2", "#": "3", "$": "4", "%": "5", "^": "6",
    "&": "7", "*": "8", "(": "9", ")": "0",
    "_": "minus", "+": "equal",
    "{": "left_bracket", "}": "right_bracket",
    ":": "semicolon", '"': "quote",
    "<": "comma", ">": "period",
    "?": "slash", "|": "backslash", "~": "grave",
}


def _rpc(method: str, params: dict | None = None, device_ip: str | None = None) -> dict:
    """Convenience: call RPC and return result (or raise)."""
    return _client.call(method, params or {}, device_ip=device_ip)


async def serve():
    server = Server("automate")

    @server.tool()
    async def scan_devices() -> list[TextContent]:
        """Scan LAN for all AutoMate devices via mDNS. Returns hostname, IP, port, version."""
        try:
            devices = await asyncio.to_thread(_client.scan_devices)
            return [TextContent(type="text", text=str(devices))]
        except Exception as e:
            return [TextContent(type="text", text=f"Error: {e}")]

    @server.tool()
    async def device_status(device_ip: str | None = None) -> list[TextContent]:
        """Get device status: WiFi info, USB/HID state, runner state, work mode."""
        try:
            result = await asyncio.to_thread(_rpc, "system.status", {}, device_ip)
            return [TextContent(type="text", text=str(result))]
        except Exception as e:
            return [TextContent(type="text", text=f"Error: {e}")]

    @server.tool()
    async def keyboard_type(text: str, device_ip: str | None = None) -> list[TextContent]:
        """Type a text string. Handles uppercase, digits, punctuation, spaces, newlines."""
        try:
            batch = []
            for ch in text:
                if ch in SHIFT_MAP:
                    if batch:
                        await asyncio.to_thread(_rpc, "hid.keyboard_batch", {"keys": batch}, device_ip)
                        batch = []
                    await asyncio.to_thread(_rpc, "hid.keytap", {
                        "key": SHIFT_MAP[ch],
                        "modifiers": ["shift"],
                    }, device_ip)
                    await asyncio.to_thread(_rpc, "hid.wait", {"ms": 50}, device_ip)
                elif ch in CHAR_TO_KEY:
                    batch.append(CHAR_TO_KEY[ch])
                else:
                    continue

            if batch:
                await asyncio.to_thread(_rpc, "hid.keyboard_batch", {"keys": batch}, device_ip)

            return [TextContent(type="text", text=str({"typed": len(text)}))]
        except Exception as e:
            return [TextContent(type="text", text=f"Error: {e}")]

    @server.tool()
    async def keyboard_combo(
        modifiers: list[str], key: str, device_ip: str | None = None
    ) -> list[TextContent]:
        """Press a key combination. e.g. modifiers=["ctrl"], key="c" for Ctrl+C."""
        try:
            await asyncio.to_thread(_rpc, "hid.keytap", {
                "key": key,
                "modifiers": modifiers,
            }, device_ip)
            return [TextContent(type="text", text=str({"ok": True}))]
        except Exception as e:
            return [TextContent(type="text", text=f"Error: {e}")]

    @server.tool()
    async def mouse_move(
        x: int, y: int, device_ip: str | None = None
    ) -> list[TextContent]:
        """Move mouse to absolute position (x, y)."""
        try:
            await asyncio.to_thread(_rpc, "hid.mouse_move", {"x": x, "y": y}, device_ip)
            return [TextContent(type="text", text=str({"ok": True}))]
        except Exception as e:
            return [TextContent(type="text", text=f"Error: {e}")]

    @server.tool()
    async def mouse_click(
        button: str = "left", device_ip: str | None = None
    ) -> list[TextContent]:
        """Click mouse button. button: 'left', 'right', or 'middle'."""
        try:
            await asyncio.to_thread(_rpc, "hid.mouse_click", {"button": button}, device_ip)
            return [TextContent(type="text", text=str({"ok": True}))]
        except Exception as e:
            return [TextContent(type="text", text=f"Error: {e}")]

    @server.tool()
    async def mouse_scroll(
        delta: int, device_ip: str | None = None
    ) -> list[TextContent]:
        """Scroll mouse wheel. Positive = up, negative = down."""
        try:
            await asyncio.to_thread(_rpc, "hid.mouse_wheel", {"delta": delta}, device_ip)
            return [TextContent(type="text", text=str({"ok": True}))]
        except Exception as e:
            return [TextContent(type="text", text=f"Error: {e}")]

    @server.tool()
    async def wait(ms: int, device_ip: str | None = None) -> list[TextContent]:
        """Wait for the specified number of milliseconds."""
        try:
            await asyncio.to_thread(_rpc, "hid.wait", {"ms": ms}, device_ip)
            return [TextContent(type="text", text=str({"ok": True}))]
        except Exception as e:
            return [TextContent(type="text", text=f"Error: {e}")]

    # ===== action tools (11) =====

    @server.tool()
    async def action_get_config(device_ip: str | None = None) -> list[TextContent]:
        """Get the entire action editor config."""
        try:
            r = await asyncio.to_thread(_rpc, "action.get_config", {}, device_ip)
            return [TextContent(type="text", text=str(r))]
        except Exception as e:
            return [TextContent(type="text", text=f"Error: {e}")]

    @server.tool()
    async def action_save_group(json: str, device_ip: str | None = None) -> list[TextContent]:
        """Save a single action group. json is the group JSON string."""
        try:
            r = await asyncio.to_thread(_rpc, "action.save_group", {"json": json}, device_ip)
            return [TextContent(type="text", text=str(r))]
        except Exception as e:
            return [TextContent(type="text", text=f"Error: {e}")]

    @server.tool()
    async def action_delete_group(id: str, device_ip: str | None = None) -> list[TextContent]:
        """Delete an action group by ID."""
        try:
            r = await asyncio.to_thread(_rpc, "action.delete_group", {"id": id}, device_ip)
            return [TextContent(type="text", text=str(r))]
        except Exception as e:
            return [TextContent(type="text", text=f"Error: {e}")]

    @server.tool()
    async def action_save_global_settings(json: str, device_ip: str | None = None) -> list[TextContent]:
        """Save global editor settings (work_mode, defaults)."""
        try:
            r = await asyncio.to_thread(_rpc, "action.save_global_settings", {"json": json}, device_ip)
            return [TextContent(type="text", text=str(r))]
        except Exception as e:
            return [TextContent(type="text", text=f"Error: {e}")]

    @server.tool()
    async def action_export_group(id: str, device_ip: str | None = None) -> list[TextContent]:
        """Export a single action group as a document."""
        try:
            r = await asyncio.to_thread(_rpc, "action.export_group", {"id": id}, device_ip)
            return [TextContent(type="text", text=str(r))]
        except Exception as e:
            return [TextContent(type="text", text=f"Error: {e}")]

    @server.tool()
    async def action_export_config(device_ip: str | None = None) -> list[TextContent]:
        """Export the entire config as a document."""
        try:
            r = await asyncio.to_thread(_rpc, "action.export_config", {}, device_ip)
            return [TextContent(type="text", text=str(r))]
        except Exception as e:
            return [TextContent(type="text", text=f"Error: {e}")]

    @server.tool()
    async def action_import_group_preview(json: str, device_ip: str | None = None) -> list[TextContent]:
        """Preview importing a group document."""
        try:
            r = await asyncio.to_thread(_rpc, "action.import_group_preview", {"json": json}, device_ip)
            return [TextContent(type="text", text=str(r))]
        except Exception as e:
            return [TextContent(type="text", text=f"Error: {e}")]

    @server.tool()
    async def action_import_config_preview(json: str, device_ip: str | None = None) -> list[TextContent]:
        """Preview importing a config document."""
        try:
            r = await asyncio.to_thread(_rpc, "action.import_config_preview", {"json": json}, device_ip)
            return [TextContent(type="text", text=str(r))]
        except Exception as e:
            return [TextContent(type="text", text=f"Error: {e}")]

    @server.tool()
    async def action_import_group_commit(json: str, device_ip: str | None = None) -> list[TextContent]:
        """Commit a group import."""
        try:
            r = await asyncio.to_thread(_rpc, "action.import_group_commit", {"json": json}, device_ip)
            return [TextContent(type="text", text=str(r))]
        except Exception as e:
            return [TextContent(type="text", text=f"Error: {e}")]

    @server.tool()
    async def action_import_config_commit(json: str, device_ip: str | None = None) -> list[TextContent]:
        """Commit a config import."""
        try:
            r = await asyncio.to_thread(_rpc, "action.import_config_commit", {"json": json}, device_ip)
            return [TextContent(type="text", text=str(r))]
        except Exception as e:
            return [TextContent(type="text", text=f"Error: {e}")]

    @server.tool()
    async def action_switch_work_mode(work_mode: str, device_ip: str | None = None) -> list[TextContent]:
        """Switch work mode. Valid values: 'local_run', 'host_bridge'."""
        try:
            r = await asyncio.to_thread(_rpc, "action.switch_work_mode", {"work_mode": work_mode}, device_ip)
            return [TextContent(type="text", text=str(r))]
        except Exception as e:
            return [TextContent(type="text", text=f"Error: {e}")]

    # ===== run tools (2) =====

    @server.tool()
    async def run_start(group_id: str, loop: bool = False, device_ip: str | None = None) -> list[TextContent]:
        """Start running an action group."""
        try:
            params = {"group_id": group_id}
            if loop:
                params["loop"] = True
            r = await asyncio.to_thread(_rpc, "run.start", params, device_ip)
            return [TextContent(type="text", text=str(r))]
        except Exception as e:
            return [TextContent(type="text", text=f"Error: {e}")]

    @server.tool()
    async def run_stop(device_ip: str | None = None) -> list[TextContent]:
        """Stop the currently running action."""
        try:
            r = await asyncio.to_thread(_rpc, "run.stop", {}, device_ip)
            return [TextContent(type="text", text=str(r))]
        except Exception as e:
            return [TextContent(type="text", text=f"Error: {e}")]

    # ===== log tool (1) =====

    @server.tool()
    async def log_get(after: int = 0, device_ip: str | None = None) -> list[TextContent]:
        """Get log entries starting after the specified index."""
        try:
            r = await asyncio.to_thread(_rpc, "log.get", {"after": after}, device_ip)
            return [TextContent(type="text", text=str(r))]
        except Exception as e:
            return [TextContent(type="text", text=f"Error: {e}")]

    # ===== fs tools (4) =====

    @server.tool()
    async def fs_list(path: str = "/storage", device_ip: str | None = None) -> list[TextContent]:
        """List files in a directory on the device."""
        try:
            r = await asyncio.to_thread(_rpc, "fs.list", {"path": path}, device_ip)
            return [TextContent(type="text", text=str(r))]
        except Exception as e:
            return [TextContent(type="text", text=f"Error: {e}")]

    @server.tool()
    async def fs_read_file(path: str, device_ip: str | None = None) -> list[TextContent]:
        """Read a file's contents from the device (max 64KB)."""
        try:
            r = await asyncio.to_thread(_rpc, "fs.read_file", {"path": path}, device_ip)
            return [TextContent(type="text", text=str(r))]
        except Exception as e:
            return [TextContent(type="text", text=f"Error: {e}")]

    @server.tool()
    async def fs_delete_file(path: str, device_ip: str | None = None) -> list[TextContent]:
        """Delete a file from the device."""
        try:
            r = await asyncio.to_thread(_rpc, "fs.delete_file", {"path": path}, device_ip)
            return [TextContent(type="text", text=str(r))]
        except Exception as e:
            return [TextContent(type="text", text=f"Error: {e}")]

    @server.tool()
    async def fs_storage_info(device_ip: str | None = None) -> list[TextContent]:
        """Get storage usage info from the device."""
        try:
            r = await asyncio.to_thread(_rpc, "fs.storage_info", {}, device_ip)
            return [TextContent(type="text", text=str(r))]
        except Exception as e:
            return [TextContent(type="text", text=f"Error: {e}")]

    # ===== ota tools (3) =====

    @server.tool()
    async def ota_status(device_ip: str | None = None) -> list[TextContent]:
        """Get OTA update status from the device."""
        try:
            r = await asyncio.to_thread(_rpc, "ota.status", {}, device_ip)
            return [TextContent(type="text", text=str(r))]
        except Exception as e:
            return [TextContent(type="text", text=f"Error: {e}")]

    @server.tool()
    async def ota_check(device_ip: str | None = None) -> list[TextContent]:
        """Check for remote OTA update availability."""
        try:
            r = await asyncio.to_thread(_rpc, "ota.check", {}, device_ip)
            return [TextContent(type="text", text=str(r))]
        except Exception as e:
            return [TextContent(type="text", text=f"Error: {e}")]

    @server.tool()
    async def ota_start(device_ip: str | None = None) -> list[TextContent]:
        """Start remote OTA download and update."""
        try:
            r = await asyncio.to_thread(_rpc, "ota.start", {}, device_ip)
            return [TextContent(type="text", text=str(r))]
        except Exception as e:
            return [TextContent(type="text", text=f"Error: {e}")]

    # ===== wifi tools (2) =====

    @server.tool()
    async def wifi_scan(device_ip: str | None = None) -> list[TextContent]:
        """Scan for nearby WiFi networks."""
        try:
            r = await asyncio.to_thread(_rpc, "wifi.scan", {}, device_ip)
            return [TextContent(type="text", text=str(r))]
        except Exception as e:
            return [TextContent(type="text", text=f"Error: {e}")]

    @server.tool()
    async def wifi_connect(ssid: str, password: str | None = None, device_ip: str | None = None) -> list[TextContent]:
        """Connect device to a WiFi network."""
        try:
            params = {"ssid": ssid}
            if password:
                params["password"] = password
            r = await asyncio.to_thread(_rpc, "wifi.connect", params, device_ip)
            return [TextContent(type="text", text=str(r))]
        except Exception as e:
            return [TextContent(type="text", text=f"Error: {e}")]

    async with stdio_server() as (reader, writer):
        await server.run(reader, writer, server.create_initialization_options())


def main():
    """Console script entry point."""
    asyncio.run(serve())


if __name__ == "__main__":
    main()
