# Gemini Web UI Automation Library - Comprehensive Documentation

## Overview

The **Gemini Web UI Automation Library** provides programmatic access to Google Gemini via web UI automation using Playwright. It allows you to send prompts and receive responses from Gemini without using the official API, enabling free access to Gemini's capabilities.

**Key Features:**
- **Free Access**: No API costs or rate limits beyond Google's web UI limits
- **Async & Sync APIs**: Both `GeminiClient` (async) and `GeminiClientSync` (sync) interfaces
- **Session Persistence**: Save authentication sessions for reuse
- **Anti-Detection Measures**: Uses system Chrome with stealth arguments to avoid Google's "browser not secure" detection
- **Model Selection**: Switch between Fast, Thinking, and Pro models
- **Multi-Turn Conversations**: Maintain conversation context
- **Cookie-Based Authentication**: Extract cookies from your regular browser
- **REST API Backend**: FastAPI server for programmatic access from any project
- **Shadow DOM Handling**: JS evaluation and Playwright semantic locators pierce shadow DOM
- **Web Chat App**: Built-in web interface with WebSocket support

## Table of Contents

1. [Installation](#installation)
2. [Quick Start](#quick-start)
3. [Authentication Methods](#authentication-methods)
4. [API Reference](#api-reference)
   - [GeminiClient (Async)](#geminiclient-async)
   - [GeminiClientSync (Sync)](#geminiclientsync-sync)
   - [GeminiResponse](#geminiresponse)
   - [Exceptions](#exceptions)
5. [Model Selection](#model-selection)
6. [Configuration Options](#configuration-options)
7. [Anti-Detection System](#anti-detection-system)
8. [REST API Backend](#rest-api-backend)
9. [Web Chat Application](#web-chat-application)
10. [Examples](#examples)
11. [Troubleshooting](#troubleshooting)
12. [Architecture](#architecture)
13. [Limitations](#limitations)

## Installation

### Prerequisites
- Python 3.10 or higher
- Playwright browsers installed (`playwright install`)

### Basic Installation
```bash
# Clone the repository
git clone https://github.com/yourusername/gemini-webui.git
cd gemini-webui

# Install the package
pip install -e .

# Install Playwright browsers
playwright install chromium
```

### Optional Dependencies
```bash
# For cookie extraction from browsers
pip install gemini-webui[cookies]

# For the REST API backend
pip install gemini-webui[api]

# For development
pip install gemini-webui[dev]

# Multiple extras
pip install gemini-webui[cookies,api]
```

## Quick Start

### Async API
```python
import asyncio
from gemini_webui import GeminiClient

async def main():
    async with GeminiClient(headless=True) as client:
        await client.login(session_path="sessions/default.json")
        response = await client.send_prompt("Explain quantum computing")
        print(response.text)

asyncio.run(main())
```

### Sync API
```python
from gemini_webui import GeminiClientSync

with GeminiClientSync(headless=True) as client:
    client.login(session_path="sessions/default.json")
    response = client.send_prompt("Explain quantum computing")
    print(response.text)
```

## Authentication Methods

### Method 1: Manual Login (First-Time Setup)
```python
# Run with headless=False first time
async with GeminiClient(headless=False) as client:
    await client.login(session_path="sessions/default.json")
    # A browser window will open for you to sign in manually
    # Session is saved for future headless use
```

> **Note:** Gemini works **without login** for basic usage (Flash model). Login is only required to access **Pro mode**. If you don't need Pro, you can skip authentication entirely.

### Method 2: Cookie Extraction (Recommended)
```python
# Install cookies extra first: pip install gemini-webui[cookies]
async with GeminiClient(headless=True) as client:
    # Extract cookies from your Chrome browser
    await client.login_from_browser(browser_name="chrome")
    # No manual sign-in required
```

### Method 3: Pre-Saved Session
```python
# Use a previously saved session
async with GeminiClient(headless=True) as client:
    await client.login(session_path="sessions/existing_session.json")
    # No authentication needed if session is valid
```

## API Reference

### GeminiClient (Async)

The primary async client for Gemini automation.

#### Constructor
```python
GeminiClient(
    headless: bool = True,
    timeout: float = 120.0,
    session_path: str | Path | None = None,
    browser_type: str = "chromium",
    slow_mo: int = 0,
    request_delay: float = 1.0,
    use_system_chrome: bool = True,
    user_data_dir: str | Path | None = None,
) -> None
```

**Parameters:**
- `headless`: Run browser in headless mode (True) or visible mode (False)
- `timeout`: Maximum seconds to wait for a response (default: 120)
- `session_path`: Path to save/load authentication session state
- `browser_type`: Browser engine: "chromium", "firefox", or "webkit"
- `slow_mo`: Slow down browser actions by N milliseconds (debugging)
- `request_delay`: Minimum seconds between consecutive prompts
- `use_system_chrome`: Use system Chrome to avoid detection (default: True)
- `user_data_dir`: Path to persistent browser profile directory

#### Properties
- `is_authenticated: bool` - Whether the client is currently authenticated
- `page: Page` - The current Playwright Page instance

#### Methods

##### `async start() -> None`
Start the browser and create a new page. Called automatically when using context manager.

##### `async close() -> None`
Close the browser and save session if configured.

##### `async login(session_path: str | Path | None = None, login_timeout: float = 120.0) -> None`
Authenticate with Google using manual login or saved session.

##### `async login_from_browser(browser_name: str = "chrome", session_path: str | Path | None = None) -> None`
Authenticate by extracting cookies from your regular browser.

**Parameters:**
- `browser_name`: "chrome", "chromium", "firefox", "opera", or "edge"
- `session_path`: Path to save the session for future use

##### `async send_prompt(prompt: str, *, new_chat: bool = False) -> GeminiResponse`
Send a prompt to Gemini and wait for the response.

**Parameters:**
- `prompt`: The text prompt to send
- `new_chat`: If True, start a new conversation before sending

**Returns:** `GeminiResponse` object

##### `async new_chat() -> None`
Start a new conversation in the Gemini UI.

##### `async get_current_model() -> str`
Get the name of the currently selected model.

**Returns:** Model name as string (e.g., "Fast", "Thinking", "Pro")

##### `async list_models() -> list[str]`
List the available model names in the Gemini UI.

**Returns:** List of model name strings

##### `async set_model(model: str) -> None`
Switch the Gemini model.

**Parameters:**
- `model`: Model to switch to: "fast", "thinking", "pro" (or "flash" for fast)

### GeminiClientSync (Sync)

Synchronous wrapper around the async GeminiClient.

#### Constructor
```python
GeminiClientSync(
    headless: bool = True,
    timeout: float = 120.0,
    session_path: str | Path | None = None,
    browser_type: str = "chromium",
    slow_mo: int = 0,
    request_delay: float = 1.0,
    use_system_chrome: bool = True,
    user_data_dir: str | Path | None = None,
) -> None
```

Same parameters as `GeminiClient`.

#### Methods
All methods have the same signatures as their async counterparts but are synchronous:
- `start() -> None`
- `close() -> None`
- `login(session_path=None, login_timeout=120.0) -> None`
- `login_from_browser(browser_name="chrome", session_path=None) -> None`
- `send_prompt(prompt, new_chat=False) -> GeminiResponse`
- `new_chat() -> None`
- `get_current_model() -> str`
- `list_models() -> list[str]`
- `set_model(model) -> None`

### GeminiResponse

Data class representing a response from Gemini.

#### Attributes
- `text: str` - The full response text from the model
- `prompt: str` - The original prompt that was sent
- `conversation_id: str | None` - Conversation identifier, if detectable
- `model: str | None` - Model name used for the response, if detectable
- `timestamp: datetime` - When the response was received

#### Methods
- `__str__() -> str`: Returns the response text
- `__repr__() -> str`: Returns a formatted representation

### Exceptions

All exceptions inherit from `GeminiWebUIError`:

1. **AuthenticationError**: Authentication fails or session expired
2. **CaptchaError**: CAPTCHA challenge detected during authentication
3. **RateLimitError**: Google's rate limiting detected
4. **ResponseTimeoutError**: Response not received within timeout
5. **SelectorNotFoundError**: Required UI element cannot be found
6. **BrowserError**: Browser-related error (Playwright not installed, etc.)

```python
from gemini_webui import (
    AuthenticationError,
    CaptchaError,
    RateLimitError,
    ResponseTimeoutError,
    SelectorNotFoundError,
    BrowserError,
)
```

## Model Selection

Gemini offers three models through the web UI:

1. **Fast** (Gemini Flash): Fastest response time
2. **Thinking**: Balanced speed and capability
3. **Pro** (Gemini Pro): Most capable model

### Switching Models
```python
# List available models
models = await client.list_models()
print(f"Available: {models}")

# Get current model
current = await client.get_current_model()
print(f"Current: {current}")

# Switch to Pro model
await client.set_model("pro")

# Switch to Fast model (alias: "flash")
await client.set_model("fast")
```

### Model Detection
The library detects models by:
1. Opening the model picker dropdown
2. Reading `data-test-id` attributes: `bard-mode-option-fast`, `bard-mode-option-thinking`, `bard-mode-option-pro`
3. Matching against known model names

## Configuration Options

### Browser Configuration
```python
client = GeminiClient(
    headless=True,           # Run without visible browser
    timeout=180.0,           # Longer timeout for complex queries
    request_delay=2.0,       # Wait 2 seconds between prompts
    use_system_chrome=True,  # Use system Chrome (recommended)
    user_data_dir="sessions/browser_profile",  # Persistent profile
    slow_mo=100,             # Slow down for debugging
)
```

### Session Management
```python
# Save session for future use
async with GeminiClient(
    session_path="sessions/my_session.json"
) as client:
    await client.login()
    # Session automatically saved on close

# Load saved session
async with GeminiClient(
    session_path="sessions/my_session.json"
) as client:
    await client.login()  # Uses saved session
```

## Anti-Detection System

Google detects automated browsers and shows "This browser or app may not be secure." The library includes multiple anti-detection measures:

### 1. System Chrome
Uses system-installed Chrome instead of Playwright's bundled Chromium.

### 2. Persistent Context
Uses `launch_persistent_context()` with a real browser profile directory.

### 3. Stealth Arguments
```python
STEALTH_ARGS = [
    "--disable-blink-features=AutomationControlled",  # Remove navigator.webdriver
    "--no-first-run",
    "--no-default-browser-check",
    "--disable-infobars",
    "--window-size=1280,800",
]
```

### 4. JavaScript Injection
Removes `navigator.webdriver` flag via JavaScript:
```javascript
Object.defineProperty(navigator, 'webdriver', {
    get: () => undefined
});
```

### 5. Realistic User Agent
Sets a realistic Chrome user agent string.

### 6. Network Idle Workaround
Replaces `wait_for_load_state("networkidle")` with `asyncio.sleep()` since Gemini's SPA never reaches network idle.

## REST API Backend

The library includes a FastAPI-based REST API server that wraps `GeminiClient`, enabling any external project to consume Gemini as an API.

### Installation

```bash
pip install gemini-webui[api]
```

### Running the Server

```bash
# First time: headed mode for manual Google login
python3 -m api --headed --session sessions/my_account.json

# After authentication: headless with saved session
python3 -m api --session sessions/my_account.json --api-key my-secret-key

# Or use the installed entry point
gemini-api --session sessions/my_account.json
```

### Command Line Arguments

| Argument | Default | Description |
|----------|---------|-------------|
| `--host` | `0.0.0.0` | Host to bind to |
| `--port` | `8000` | Port to run on |
| `--session` | `sessions/api_server.json` | Session file path |
| `--headed` | `False` | Run browser in headed mode (for first-time login) |
| `--browser-cookies` | `False` | Extract cookies from browser |
| `--browser-name` | `chrome` | Browser for cookie extraction |
| `--api-key` | `None` | API key for authentication (or set `GEMINI_API_KEY` env var) |
| `--lock-timeout` | `30.0` | Max seconds to wait for client lock |
| `--log-level` | `info` | Logging level |

### REST Endpoints

| Method | Path | Description |
|--------|------|-------------|
| `POST` | `/api/chat` | Send a prompt, get a response |
| `POST` | `/api/chat/new` | Start a new conversation |
| `GET` | `/api/models` | List available models |
| `GET` | `/api/models/current` | Get currently active model |
| `PUT` | `/api/models` | Switch model |
| `GET` | `/api/status` | Server health and auth status |
| `WS` | `/api/ws` | WebSocket for interactive chat |

### API Authentication

Optional API key protection via `--api-key` flag or `GEMINI_API_KEY` environment variable:

```bash
# REST: X-API-Key header
curl -X POST http://localhost:8000/api/chat \
  -H "X-API-Key: my-secret-key" \
  -H "Content-Type: application/json" \
  -d '{"prompt": "Hello"}'

# REST: api_key query parameter
curl "http://localhost:8000/api/status?api_key=my-secret-key"

# WebSocket: api_key query parameter
ws://localhost:8000/api/ws?api_key=my-secret-key
```

### Request/Response Examples

**Send a prompt:**
```bash
curl -X POST http://localhost:8000/api/chat \
  -H "Content-Type: application/json" \
  -d '{"prompt": "Explain quantum computing", "new_chat": false}'
```
```json
{
  "text": "Quantum computing is...",
  "prompt": "Explain quantum computing",
  "conversation_id": "abc123",
  "model": null,
  "timestamp": "2026-05-09T12:30:00Z"
}
```

**Switch model:**
```bash
curl -X PUT http://localhost:8000/api/models \
  -H "Content-Type: application/json" \
  -d '{"model": "pro"}'
```
```json
{
  "model": "Pro",
  "message": "Model switched successfully"
}
```

**Check status:**
```bash
curl http://localhost:8000/api/status
```
```json
{
  "status": "ready",
  "authenticated": true,
  "current_model": "Pro",
  "available_models": ["Fast", "Thinking", "Pro"]
}
```

### Error Handling

| Exception | HTTP Status |
|-----------|-------------|
| `AuthenticationError` | 401 |
| `CaptchaError` | 403 |
| `RateLimitError` | 429 |
| `ResponseTimeoutError` | 504 |
| `SelectorNotFoundError` | 503 |
| `BrowserError` | 503 |
| Server busy (lock timeout) | 503 |

### Concurrency

The API server uses a single `asyncio.Lock` to serialize all GeminiClient operations (one browser = one operation at a time). If the lock cannot be acquired within `--lock-timeout` seconds, the server returns 503.

### Deployment on CLI Linux

For headless Linux servers without a display:

1. **Authenticate locally** on a machine with a display, then copy the session:
   ```bash
   # Local machine
   python3 -m api --headed --session sessions/my_account.json
   # Copy to server
   scp -r sessions/ user@vps:/path/to/project/sessions/
   ```

2. **Run headless on the server** (no display needed):
   ```bash
   python3 -m api --session sessions/my_account.json --api-key my-secret --host 0.0.0.0
   ```

3. **System dependencies** for headless Chrome on Ubuntu/Debian:
   ```bash
   sudo apt-get install -y libnss3 libatk-bridge2.0-0 libdrm2 libxkbcommon0 libgbm1 libasound2
   ```

### Interactive Docs

- Swagger UI: `http://localhost:8000/docs`
- ReDoc: `http://localhost:8000/redoc`

## Web Chat Application

The library includes a web chat application with WebSocket support.

### Running the Server
```bash
# Basic usage
python app/server.py

# With options
python app/server.py --port 8080 --headed --browser-cookies
```

### Command Line Arguments
- `--port`: Port to run server on (default: 8080)
- `--host`: Host to bind to (default: 0.0.0.0)
- `--session`: Session file path (default: sessions/default.json)
- `--headed`: Run browser in headed mode
- `--browser-cookies`: Authenticate with browser cookies
- `--browser-name`: Browser to extract cookies from (chrome, firefox, etc.)

### Features
- Dark-themed UI with responsive design
- Real-time WebSocket communication
- Model selector dropdown
- New chat button
- Typing indicators
- Error handling

### API Endpoints
- `GET /`: HTML chat interface
- `GET /ws`: WebSocket endpoint for chat

### WebSocket Message Format

**Client to Server:**
```json
{
  "type": "prompt",
  "text": "Your message here"
}
```

```json
{
  "type": "set_model",
  "model": "pro"
}
```

```json
{
  "type": "new_chat"
}
```

```json
{
  "type": "list_models"
}
```

**Server to Client:**
```json
{
  "type": "response",
  "text": "Gemini's response"
}
```

```json
{
  "type": "models",
  "models": ["Fast", "Thinking", "Pro"],
  "current": "Fast"
}
```

```json
{
  "type": "error",
  "text": "Error message"
}
```

## Examples

### Basic Usage
```python
# examples/basic_usage.py
import asyncio
from gemini_webui import GeminiClient

async def main():
    async with GeminiClient(headless=True) as client:
        await client.login(session_path="sessions/default.json")
        response = await client.send_prompt("Explain quantum computing")
        print(f"Response: {response.text}")

asyncio.run(main())
```

### Multi-Turn Conversation
```python
# examples/conversation.py
async with GeminiClient(headless=True) as client:
    await client.login()
    
    # First message
    response1 = await client.send_prompt("Tell me about Python")
    print(f"Gemini: {response1.text}")
    
    # Follow-up in same conversation
    response2 = await client.send_prompt("What are its advantages?")
    print(f"Gemini: {response2.text}")
```

### Headless Server
```python
# examples/headless_server.py
from gemini_webui import GeminiClientSync

with GeminiClientSync(headless=True) as client:
    client.login()
    
    while True:
        prompt = input("You: ")
        if prompt.lower() in ("quit", "exit"):
            break
        response = client.send_prompt(prompt)
        print(f"Gemini: {response.text}")
```

### Cookie Authentication
```python
# examples/login_from_browser.py
async with GeminiClient(headless=True) as client:
    await client.login_from_browser(browser_name="chrome")
    response = await client.send_prompt("Hello from browser cookies!")
    print(response.text)
```

## Troubleshooting

### Common Issues

#### 1. "This browser or app may not be secure"
**Solution:** Enable anti-detection measures:
```python
client = GeminiClient(
    use_system_chrome=True,  # Use system Chrome
    user_data_dir="sessions/browser_profile",  # Persistent profile
)
```

#### 2. Network idle timeout
**Solution:** The library already handles this by replacing `networkidle` waits with `asyncio.sleep()`.

#### 3. Login detection fails
**Solution:** The library uses JavaScript evaluation to detect the "Sign in" button in the Gemini UI (piercing shadow DOM). If detection fails:
- Run with `headless=False` to see what's happening
- Ensure the page has fully loaded before checking login status
- Note: Gemini works without login for basic usage — login only enables Pro mode

#### 4. Rate limiting
**Solution:** Increase `request_delay`:
```python
client = GeminiClient(request_delay=3.0)  # Wait 3 seconds between prompts
```

#### 5. Selector not found
**Solution:** The Gemini UI may have changed. Update selectors in `src/gemini_webui/selectors.py`.

### Debug Mode
```python
import logging
logging.basicConfig(level=logging.DEBUG)

client = GeminiClient(slow_mo=100)  # Slow down for observation
```

### Checking Browser State
```python
# Check if authenticated
if client.is_authenticated:
    print("Logged in")
else:
    print("Not logged in")

# Get current URL
print(f"Current page: {client.page.url}")
```

## Architecture

### Module Structure
```
src/gemini_webui/
├── __init__.py          # Public API exports
├── client.py            # Core async GeminiClient
├── sync_client.py       # Sync wrapper
├── auth.py              # Authentication management
├── selectors.py         # CSS/XPath selectors
├── utils.py             # Utility functions
├── response.py          # Response data model
└── exceptions.py        # Custom exceptions
```

### Key Components

#### 1. Selector System
Centralized selectors with primary/fallback patterns. **Important:** Gemini uses web components with shadow DOM, so CSS selectors often cannot reach elements directly. The library uses multiple strategies:

- **CSS selectors** — primary approach for standard DOM elements
- **JavaScript evaluation** (`page.evaluate()`, `page.evaluate_handle()`) — recursive shadow DOM traversal for elements like prompt input and response text
- **Playwright semantic locators** (`get_by_label()`, `get_by_role()`, `get_by_text()`) — automatically pierce shadow DOM, used for model picker

```python
PROMPT_INPUT = {
    "primary": 'div.ql-editor[contenteditable="true"]',
    "fallback": [
        'rich-textarea div[contenteditable="true"]',
        'textarea[aria-label="Enter a prompt"]',
        'rich-textarea',           # Shadow DOM host
        '[contenteditable="true"]', # Broad fallback
    ],
}
```

#### 2. Authentication Manager
Handles:
- Session loading/saving
- Login status detection via **JavaScript evaluation** (searches shadow DOM for "Sign in" button)
- Cookie extraction
- CAPTCHA detection

> **Note:** Gemini works without login for basic usage. Login detection checks for the absence of a "Sign in" button rather than the presence of user-specific UI elements.

#### 3. Response Detection
Uses multiple strategies with shadow DOM fallbacks:
- Wait for "Stop generating" button to disappear
- Check response text stability via CSS selectors
- **JS fallback**: `page.evaluate()` with recursive shadow DOM traversal to find `model-response` elements
- Keyboard input (`page.keyboard.press("Enter")`) instead of clicking send button

#### 4. Model Picker Integration
Uses **Playwright semantic locators** as the primary strategy (they auto-pierce shadow DOM):
- Opens dropdown via `page.get_by_label("mode picker")` or `page.get_by_role("button", name=/Gemini/)`
- Selects model via `page.get_by_role("menuitem", name=model_pattern)` or `page.get_by_text()`
- Falls back to `data-test-id` attributes and CSS selectors
- Final fallback: JavaScript evaluation with shadow DOM traversal

### Flow Diagram
```mermaid
graph TD
    A[Start Client] --> B[Start Browser with Stealth Args]
    B --> C{Navigate to gemini.google.com/app}
    C --> D{Logged In?}
    D -- No --> E[Authenticate]
    E --> F[Save Session]
    D -- Yes --> G[Ready for Prompts]
    F --> G
    G --> H[Send Prompt]
    H --> I[Wait for Response Completion]
    I --> J[Extract Response Text]
    J --> K[Return GeminiResponse]
    K --> H
    H --> L[Switch Model]
    L --> H
```

### Data Flow
1. **Client Initialization** → Browser starts with anti-detection measures
2. **Authentication** → Manual login or cookie extraction (optional for basic usage)
3. **Session Persistence** → Cookies/localStorage saved to JSON
4. **Prompt Submission** → Find input via CSS or JS shadow DOM search, type text, press Enter
5. **Response Detection** → Wait for "Stop generating" button to disappear, with JS shadow DOM fallback
6. **Text Extraction** → Parse response from DOM, with JS shadow DOM fallback for `model-response` elements
7. **Model Switching** → Open dropdown via semantic locators (auto-pierce shadow DOM), select target model

## Limitations

### Technical Limitations
1. **UI Dependency**: Relies on Gemini web UI structure; Google may change it
2. **Rate Limiting**: Subject to Google's web UI rate limits
3. **CAPTCHA Challenges**: May require manual intervention
4. **Browser Automation**: Requires Playwright and browser installation
5. **No Streaming**: Responses are received as complete text, not streamed
6. **Single Conversation**: One conversation at a time per client instance

### Stability Considerations
- **Selector Stability**: CSS selectors may break with UI updates
- **Network Reliability**: Dependent on Google's web service availability
- **Session Expiry**: Google sessions may expire, requiring re-authentication
- **Browser Updates**: Playwright/Chrome compatibility may change

### Performance
- **Startup Time**: Browser launch adds ~2-5 seconds overhead
- **Memory Usage**: Each client instance runs a browser process
- **Response Time**: Similar to manual web usage (depends on model)

## Best Practices

### 1. Session Management
```python
# Save sessions for reuse
SESSION_PATH = "sessions/my_session.json"

# First run: create session
async with GeminiClient(headless=False) as client:
    await client.login(session_path=SESSION_PATH)
    # Session saved automatically on close

# Subsequent runs: use saved session
async with GeminiClient(headless=True) as client:
    await client.login(session_path=SESSION_PATH)  # Loads saved session
```

### 2. Error Handling
```python
from gemini_webui import (
    AuthenticationError,
    RateLimitError,
    ResponseTimeoutError,
    SelectorNotFoundError,
)

try:
    response = await client.send_prompt("Your prompt")
except AuthenticationError:
    print("Authentication failed. Please log in again.")
    await client.login(headless=False)
except RateLimitError:
    print("Rate limited. Waiting before retry...")
    await asyncio.sleep(30)
except ResponseTimeoutError:
    print("Response timed out. The model may be slow.")
except SelectorNotFoundError:
    print("Gemini UI may have changed. Update selectors.")
```

### 3. Request Throttling
```python
# Add delay between requests to avoid rate limiting
client = GeminiClient(request_delay=2.0)  # 2 seconds between prompts

# Or implement your own throttling
import asyncio
async def send_with_backoff(client, prompt, max_retries=3):
    for attempt in range(max_retries):
        try:
            return await client.send_prompt(prompt)
        except RateLimitError:
            wait = 2 ** attempt  # Exponential backoff
            print(f"Rate limited. Waiting {wait} seconds...")
            await asyncio.sleep(wait)
    raise Exception("Max retries exceeded")
```

### 4. Monitoring and Logging
```python
import logging

# Enable debug logging
logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s"
)

# Monitor performance
import time
start = time.time()
response = await client.send_prompt("Test")
elapsed = time.time() - start
print(f"Response time: {elapsed:.2f}s, length: {len(response.text)} chars")
```

### 5. Resource Cleanup
```python
# Always use context manager for proper cleanup
async with GeminiClient() as client:
    # Your code here
    pass  # Browser automatically closed

# Or manually close
client = GeminiClient()
try:
    await client.start()
    # Your code
finally:
    await client.close()  # Important!
```

## Advanced Usage

### Custom Selectors
If Gemini UI changes, update `src/gemini_webui/selectors.py`:
```python
# Example: Update prompt input selector
PROMPT_INPUT = {
    "primary": 'div.ql-editor[contenteditable="true"]',
    "fallback": [
        'new-selector-if-changed',
        'textarea[aria-label="Enter a prompt"]',
    ],
}
```

### Multiple Client Instances
```python
import asyncio
from gemini_webui import GeminiClient

async def parallel_queries():
    # Create multiple clients for parallel queries
    clients = []
    for i in range(3):
        client = GeminiClient(
            headless=True,
            session_path=f"sessions/client_{i}.json",
            user_data_dir=f"sessions/profile_{i}"
        )
        await client.start()
        await client.login()
        clients.append(client)
    
    # Send queries in parallel
    tasks = []
    for client in clients:
        task = client.send_prompt("What is 2+2?")
        tasks.append(task)
    
    responses = await asyncio.gather(*tasks)
    
    # Cleanup
    for client in clients:
        await client.close()
```

### Integration with Other Systems
```python
# Integration with FastAPI
from fastapi import FastAPI
from gemini_webui import GeminiClientSync

app = FastAPI()
client = GeminiClientSync(headless=True)

@app.on_event("startup")
async def startup():
    client.start()
    client.login()

@app.on_event("shutdown")
async def shutdown():
    client.close()

@app.post("/chat")
async def chat(prompt: str):
    response = client.send_prompt(prompt)
    return {"response": response.text}

# Integration with Discord bot
import discord
from discord.ext import commands

bot = commands.Bot(command_prefix="!")
gemini_client = None

@bot.event
async def on_ready():
    global gemini_client
    gemini_client = GeminiClientSync(headless=True)
    gemini_client.start()
    gemini_client.login()

@bot.command()
async def ask(ctx, *, question):
    response = gemini_client.send_prompt(question)
    await ctx.send(f"**Gemini:** {response.text[:1900]}")  # Discord limit
```

## Development

### Project Structure
```
gemini-webui/
├── pyproject.toml           # Package configuration
├── README.md                # Quick start guide
├── LICENSE                  # MIT License
├── documentation.md         # This comprehensive documentation
├── plans/
│   ├── architecture.md     # Architecture design
│   └── backend-api.md      # REST API backend design
├── src/
│   └── gemini_webui/       # Main library package
│       ├── __init__.py     # Public API
│       ├── client.py       # Async GeminiClient (shadow DOM handling)
│       ├── sync_client.py  # Sync wrapper
│       ├── auth.py         # Authentication (JS-based login detection)
│       ├── selectors.py    # UI selectors (with shadow DOM fallbacks)
│       ├── utils.py        # Utilities (JS fallback for response detection)
│       ├── response.py     # Response model
│       └── exceptions.py   # Custom exceptions
├── api/                    # REST API backend (uses the library)
│   ├── __init__.py         # Package init
│   ├── __main__.py         # python -m api entrypoint
│   ├── main.py             # FastAPI app, lifecycle, CLI
│   ├── routes.py           # REST + WebSocket handlers
│   ├── models.py           # Pydantic schemas
│   └── dependencies.py     # Client singleton, lock, API key auth
├── examples/               # Usage examples
│   ├── basic_usage.py
│   ├── conversation.py
│   ├── headless_server.py
│   └── login_from_browser.py
└── sessions/               # Saved session files (gitignored)
```

### Running Tests
```bash
# Install development dependencies
pip install gemini-webui[dev]

# Run tests
pytest

# Check code quality
ruff check src/
```

### Contributing
1. **Selector Updates**: If Gemini UI changes, update `selectors.py`
2. **Bug Fixes**: Test with both async and sync clients
3. **New Features**: Maintain backward compatibility
4. **Documentation**: Update this file and README.md

### Version Compatibility
- **Python**: 3.10+
- **Playwright**: 1.40.0+
- **Browser**: Chrome/Chromium 100+

## FAQ

### Q: Is this against Google's Terms of Service?
A: This library automates the web UI similarly to how a human would use it. However, users should review Google's Terms of Service and use responsibly.

### Q: How reliable is this compared to the official API?
A: Less reliable than the official API. The web UI can change without notice, breaking selectors. The official API is recommended for production use.

### Q: Can I use this commercially?
A: The library is MIT licensed, but Google's terms may restrict commercial automation of their web UI.

### Q: Why use this instead of the official Gemini API?
A: This is free (no API costs), while the official API has usage fees. Useful for personal projects, testing, or when API access isn't available.

### Q: How do I handle CAPTCHAs?
A: Run with `headless=False` to solve CAPTCHAs manually, then save the session for headless use.

### Q: Can I run this on a headless server?
A: Yes, but you'll need to create a session first on a machine with a display, then copy the session file to the server.

### Q: Why does it use system Chrome instead of Playwright's Chromium?
A: Google detects Playwright's bundled Chromium as automated. System Chrome with a persistent profile appears more legitimate.

### Q: How do I update the selectors if Gemini changes?
A: Inspect the Gemini web UI using browser developer tools and update `src/gemini_webui/selectors.py` with new CSS selectors.

## Changelog

### v0.1.0
- Initial release with async and sync clients
- Session persistence and cookie-based authentication
- Model selection (Fast, Thinking, Pro)
- Web chat application
- Anti-detection measures for Google's security
- Comprehensive error handling

### v0.2.0 (unreleased)
- **Shadow DOM handling**: JS evaluation (`page.evaluate()`, `page.evaluate_handle()`) with recursive shadow DOM traversal for prompt input, response text extraction, and login detection
- **Playwright semantic locators**: `get_by_label()`, `get_by_role()`, `get_by_text()` for model picker (auto-pierce shadow DOM)
- **JS-based login detection**: Replaces CSS selector approach — searches shadow DOM for "Sign in" button
- **Keyboard input**: Replaced SEND_BUTTON click with `page.keyboard.press("Enter")` for reliability
- **REST API backend**: FastAPI server with REST endpoints, WebSocket support, API key auth, and async lock serialization
- **`pip install gemini-webui[api]`**: Optional dependency group for the API backend
- **`gemini-api` CLI entry point**: Run the API server after pip install
- **MIT License**: Added LICENSE file
- **Updated documentation**: REST API backend docs, shadow DOM architecture, deployment guide

## Support

### Issues
1. Check the [Troubleshooting](#troubleshooting) section
2. Verify you're using the latest version
3. Run with `headless=False` to see what's happening
4. Enable debug logging: `logging.basicConfig(level=logging.DEBUG)`

### Getting Help
- Report issues on GitHub
- Check existing issues for similar problems
- Update selectors if Gemini UI has changed

### Known Issues
- **Google UI Changes**: Selectors may break with Gemini updates
- **Rate Limiting**: Heavy usage may trigger Google's rate limits
- **Session Expiry**: Google sessions expire periodically
- **Browser Detection**: Anti-detection measures may need updates

## License

MIT License - See LICENSE file for details.

---

*This documentation covers version 0.1.0 of the Gemini Web UI Automation Library. For updates and changes, refer to the GitHub repository.*
