"""Multi-turn conversation example for the Gemini Web UI automation library.

Demonstrates how to have a back-and-forth conversation by sending
multiple prompts within the same chat session.

Usage:
    python conversation.py
"""

import asyncio
import logging

from gemini_webui import GeminiClient

logging.basicConfig(level=logging.INFO)


async def main():
    async with GeminiClient(
        headless=True,
        session_path="sessions/default.json",
    ) as client:
        await client.login()

        # Start a new chat explicitly
        await client.new_chat()

        # First message in the conversation
        response1 = await client.send_prompt(
            "Tell me about the Python programming language in 2 sentences."
        )
        print(f"\n[User]: Tell me about the Python programming language in 2 sentences.")
        print(f"[Gemini]: {response1.text}\n")

        # Follow-up — continues in the same conversation (new_chat=False by default)
        response2 = await client.send_prompt(
            "What are its main advantages over other languages?"
        )
        print(f"[User]: What are its main advantages over other languages?")
        print(f"[Gemini]: {response2.text}\n")

        # Another follow-up
        response3 = await client.send_prompt(
            "Give me a simple code example."
        )
        print(f"[User]: Give me a simple code example.")
        print(f"[Gemini]: {response3.text}\n")

        print(f"Conversation ID: {response3.conversation_id}")


if __name__ == "__main__":
    asyncio.run(main())
