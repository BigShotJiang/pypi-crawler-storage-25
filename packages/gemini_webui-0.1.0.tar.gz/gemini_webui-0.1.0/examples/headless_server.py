"""Headless server example for the Gemini Web UI automation library.

Demonstrates using the sync client in a simple REPL-style loop,
suitable for running on a headless server with a pre-saved session.

First-time setup (on a machine with a display):
    1. Run basic_usage.py with headless=False to create a session
    2. Copy the session file to your server

Usage:
    python headless_server.py
"""

from gemini_webui import GeminiClientSync, RateLimitError, ResponseTimeoutError

SESSION_PATH = "sessions/default.json"


def main():
    print("Gemini Web UI — Headless Server Mode")
    print(f"Session: {SESSION_PATH}")
    print("Type 'quit' or 'exit' to stop. Type 'new' to start a new chat.")
    print("-" * 60)

    with GeminiClientSync(
        headless=True,
        session_path=SESSION_PATH,
        timeout=180.0,
        request_delay=2.0,
    ) as client:
        client.login()

        while True:
            try:
                prompt = input("\nYou: ").strip()
            except (EOFError, KeyboardInterrupt):
                print("\nGoodbye!")
                break

            if not prompt:
                continue

            if prompt.lower() in ("quit", "exit"):
                print("Goodbye!")
                break

            if prompt.lower() == "new":
                client.new_chat()
                print("Started a new chat.")
                continue

            try:
                response = client.send_prompt(prompt)
                print(f"\nGemini: {response.text}")
            except RateLimitError:
                print("\n⚠️  Rate limited. Please wait a moment before trying again.")
            except ResponseTimeoutError:
                print("\n⚠️  Response timed out. The model may be slow. Try again.")
            except Exception as e:
                print(f"\n❌ Error: {e}")


if __name__ == "__main__":
    main()
