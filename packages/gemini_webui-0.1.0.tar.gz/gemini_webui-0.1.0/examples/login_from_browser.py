"""Login from browser example for the Gemini Web UI automation library.

This demonstrates how to authenticate by extracting cookies from your
regular browser — no need to sign in through the Playwright window.

Prerequisites:
    1. Install the cookies extra: pip install gemini-webui[cookies]
    2. Make sure you've logged into gemini.google.com in your browser

Usage:
    python login_from_browser.py
"""

import asyncio
import logging

from gemini_webui import GeminiClient

logging.basicConfig(level=logging.INFO)


async def main():
    # login_from_browser() works in headless mode since it doesn't need
    # a visible browser window for manual sign-in
    async with GeminiClient(
        headless=True,
        session_path="sessions/from_browser.json",
    ) as client:
        # Extract cookies from your Chrome browser
        # Supported: "chrome", "chromium", "firefox", "opera", "edge"
        await client.login_from_browser(browser_name="chrome")

        # Now you can send prompts as usual
        response = await client.send_prompt("Say hello in 5 different languages")
        print(f"\nResponse:\n{response.text}")


if __name__ == "__main__":
    asyncio.run(main())
