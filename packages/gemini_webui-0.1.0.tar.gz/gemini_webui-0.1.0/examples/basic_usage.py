"""Basic usage example for the Gemini Web UI automation library.

This script demonstrates the simplest way to send a prompt and get a response.

First-time setup:
    1. Run this script with headless=False to log in manually
    2. After login, the session is saved for future headless use

Usage:
    python basic_usage.py
"""

import asyncio
import logging

from gemini_webui import GeminiClient

# Configure logging to see what's happening
logging.basicConfig(level=logging.INFO)


async def main():
    # First-time: use headless=False to log in manually
    # After that: headless=True works with the saved session
    async with GeminiClient(
        headless=False,
        session_path="sessions/default.json",
    ) as client:
        # Login — uses saved session if available, otherwise opens browser for manual login
        await client.login()

        # Send a prompt and get a response
        response = await client.send_prompt("Explain quantum computing in 3 sentences.")

        print(f"\n{'='*60}")
        print(f"Prompt: {response.prompt}")
        print(f"{'='*60}")
        print(f"Response: {response.text}")
        print(f"{'='*60}")
        print(f"Conversation ID: {response.conversation_id}")
        print(f"Timestamp: {response.timestamp}")


if __name__ == "__main__":
    asyncio.run(main())
