"""Pydantic request/response schemas for the Gemini API server."""

from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, Field


# ── Request schemas ─────────────────────────────────────────────────────


class ChatRequest(BaseModel):
    """Request body for sending a prompt to Gemini."""

    prompt: str = Field(..., min_length=1, description="The prompt text to send to Gemini")
    new_chat: bool = Field(False, description="Start a new conversation before sending")


class SetModelRequest(BaseModel):
    """Request body for switching the Gemini model."""

    model: str = Field(..., min_length=1, description="Model name or alias (e.g. 'pro', 'flash')")


# ── Response schemas ────────────────────────────────────────────────────


class ChatResponse(BaseModel):
    """Response from a chat prompt."""

    text: str = Field(..., description="The full response text from the model")
    prompt: str = Field(..., description="The original prompt that was sent")
    conversation_id: str | None = Field(None, description="Conversation identifier, if detectable")
    model: str | None = Field(None, description="Model name used for the response, if detectable")
    timestamp: datetime = Field(..., description="When the response was received")


class ModelResponse(BaseModel):
    """Response after switching models."""

    model: str = Field(..., description="The currently active model name")
    message: str = Field(..., description="Status message")


class ModelsListResponse(BaseModel):
    """Response listing available models."""

    models: list[str] = Field(..., description="List of available model names")
    current: str = Field(..., description="Currently active model name")


class StatusResponse(BaseModel):
    """Server health and authentication status."""

    status: str = Field(..., description="Server status: 'ready', 'not_authenticated', 'error'")
    authenticated: bool = Field(..., description="Whether the Gemini client is authenticated")
    current_model: str | None = Field(None, description="Currently active model, if authenticated")
    available_models: list[str] = Field(
        default_factory=list, description="Available models, if authenticated"
    )


class ErrorResponse(BaseModel):
    """Error response."""

    detail: str = Field(..., description="Human-readable error message")
    error_type: str = Field(..., description="Exception class name for programmatic handling")
