"""Gemini API Server — FastAPI backend that wraps GeminiClient as a REST API.

Run:
    python -m api.main

Options:
    python -m api.main --headed --session sessions/my_session.json
    python -m api.main --api-key my-secret-key

Then open http://localhost:8000/docs for Swagger UI.
"""

from __future__ import annotations

import argparse
import asyncio
import logging
import os
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI

from gemini_webui import GeminiClient

from .routes import router

logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Manage GeminiClient lifecycle: start on startup, close on shutdown."""
    session_path: str = app.state.session_path
    headless: bool = app.state.headless
    use_browser_cookies: bool = app.state.use_browser_cookies
    browser_name: str = app.state.browser_name

    client = GeminiClient(
        headless=headless,
        session_path=session_path,
        timeout=180.0,
        request_delay=1.5,
    )

    await client.start()

    try:
        if use_browser_cookies:
            await client.login_from_browser(browser_name=browser_name, session_path=session_path)
        else:
            await client.login(session_path=session_path)
    except Exception as e:
        logger.error("Authentication failed: %s", e)
        app.state.gemini_client = None
        # Keep running — user can check /api/status and restart with valid session
    else:
        app.state.gemini_client = client
        logger.info("Gemini client authenticated and ready")

    yield  # Server is running

    # Shutdown
    if app.state.gemini_client is not None:
        await app.state.gemini_client.close()
        logger.info("Gemini client closed")


def create_app(
    session_path: str = "sessions/api_server.json",
    headless: bool = True,
    use_browser_cookies: bool = False,
    browser_name: str = "chrome",
    api_key: str | None = None,
    lock_timeout: float = 30.0,
) -> FastAPI:
    """Create and configure the FastAPI application.

    Args:
        session_path: Path to save/load browser session state.
        headless: Run browser in headless mode.
        use_browser_cookies: Extract cookies from user's browser.
        browser_name: Browser to extract cookies from.
        api_key: Optional API key for authentication. If None, checks
            the GEMINI_API_KEY environment variable.
        lock_timeout: Max seconds to wait for the client lock.
    """
    # Resolve API key: CLI arg > env var > None
    resolved_api_key = api_key or os.environ.get("GEMINI_API_KEY") or None

    app = FastAPI(
        title="Gemini API",
        description=(
            "REST API backend for Google Gemini via web UI automation. "
            "Send prompts, switch models, and manage conversations programmatically."
        ),
        version="0.1.0",
        lifespan=lifespan,
    )

    # Store configuration in app state
    app.state.session_path = session_path
    app.state.headless = headless
    app.state.use_browser_cookies = use_browser_cookies
    app.state.browser_name = browser_name
    app.state.api_key = resolved_api_key
    app.state.lock_timeout = lock_timeout
    app.state.gemini_client: GeminiClient | None = None
    app.state.client_lock = asyncio.Lock()

    # Include routes
    app.include_router(router)

    return app


def main() -> None:
    """CLI entrypoint for the API server."""
    parser = argparse.ArgumentParser(
        description="Gemini API Server — REST API backend for Google Gemini",
    )
    parser.add_argument(
        "--host", default="0.0.0.0", help="Host to bind to (default: 0.0.0.0)"
    )
    parser.add_argument(
        "--port", type=int, default=8000, help="Port to run on (default: 8000)"
    )
    parser.add_argument(
        "--session", default="sessions/api_server.json",
        help="Session file path (default: sessions/api_server.json)",
    )
    parser.add_argument(
        "--headed", action="store_true",
        help="Run browser in headed mode (for first-time login)",
    )
    parser.add_argument(
        "--browser-cookies", action="store_true",
        help="Authenticate by extracting cookies from your browser",
    )
    parser.add_argument(
        "--browser-name", default="chrome",
        choices=["chrome", "chromium", "firefox", "opera", "edge"],
        help="Browser to extract cookies from (default: chrome)",
    )
    parser.add_argument(
        "--api-key", default=None,
        help="API key for authentication (or set GEMINI_API_KEY env var)",
    )
    parser.add_argument(
        "--lock-timeout", type=float, default=30.0,
        help="Max seconds to wait for client lock (default: 30)",
    )
    parser.add_argument(
        "--log-level", default="info",
        choices=["debug", "info", "warning", "error"],
        help="Logging level (default: info)",
    )
    args = parser.parse_args()

    logging.basicConfig(
        level=getattr(logging, args.log_level.upper()),
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )

    # Ensure sessions directory exists
    session_dir = Path(args.session).parent
    if session_dir and session_dir != Path("."):
        session_dir.mkdir(parents=True, exist_ok=True)

    app = create_app(
        session_path=args.session,
        headless=not args.headed,
        use_browser_cookies=args.browser_cookies,
        browser_name=args.browser_name,
        api_key=args.api_key,
        lock_timeout=args.lock_timeout,
    )

    import uvicorn

    uvicorn.run(app, host=args.host, port=args.port)


if __name__ == "__main__":
    main()
