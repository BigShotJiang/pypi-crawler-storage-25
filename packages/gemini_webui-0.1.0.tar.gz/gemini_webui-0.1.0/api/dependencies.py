"""Shared state, client singleton, lock, and API key dependency."""

from __future__ import annotations

import asyncio
import os
from typing import Annotated

from fastapi import Depends, HTTPException, Query, Request, Security, status
from fastapi.security import APIKeyHeader

from gemini_webui import GeminiClient

# ── API Key authentication ──────────────────────────────────────────────

_api_key_header = APIKeyHeader(name="X-API-Key", auto_error=False)


def get_configured_api_key(request: Request) -> str | None:
    """Get the API key configured on the app (from CLI arg or env var)."""
    return request.app.state.api_key


async def verify_api_key(
    request: Request,
    header_key: Annotated[str | None, Security(_api_key_header)] = None,
    query_key: Annotated[str | None, Query(alias="api_key")] = None,
) -> str | None:
    """Verify the API key if one is configured.

    Returns the key if valid, or None if no key is configured on the server.
    Raises HTTPException if a key is configured but not provided / incorrect.
    """
    configured_key = get_configured_api_key(request)

    # No API key configured on server — open access
    if not configured_key:
        return None

    # API key is configured — check the request
    provided_key = header_key or query_key

    if not provided_key:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="API key required. Pass X-API-Key header or api_key query parameter.",
        )

    if provided_key != configured_key:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid API key.",
        )

    return provided_key


# ── GeminiClient singleton ──────────────────────────────────────────────


def get_client(request: Request) -> GeminiClient:
    """Get the GeminiClient singleton from app state.

    Raises HTTPException 503 if the client is not authenticated.
    """
    client: GeminiClient | None = getattr(request.app.state, "gemini_client", None)

    if client is None or not client.is_authenticated:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Gemini client is not authenticated. Restart the server with a valid session.",
        )

    return client


def get_lock(request: Request) -> asyncio.Lock:
    """Get the asyncio.Lock from app state."""
    return request.app.state.client_lock


def get_lock_timeout(request: Request) -> float:
    """Get the lock acquisition timeout from app state."""
    return request.app.state.lock_timeout


# ── Type aliases for dependency injection ───────────────────────────────

APIKeyDep = Annotated[str | None, Depends(verify_api_key)]
ClientDep = Annotated[GeminiClient, Depends(get_client)]
LockDep = Annotated[asyncio.Lock, Depends(get_lock)]
LockTimeoutDep = Annotated[float, Depends(get_lock_timeout)]
