"""Allow running the API server with `python -m api`."""

from .main import main

if __name__ == "__main__":
    main()
