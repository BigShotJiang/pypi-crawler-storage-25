"""REST and WebSocket route handlers for the Gemini API server."""

from __future__ import annotations

import asyncio
import json
import logging
from datetime import datetime

from fastapi import APIRouter, HTTPException, WebSocket, WebSocketDisconnect, status
from gemini_webui import GeminiClient, GeminiResponse
from gemini_webui.exceptions import (
    AuthenticationError,
    BrowserError,
    CaptchaError,
    GeminiWebUIError,
    RateLimitError,
    ResponseTimeoutError,
    SelectorNotFoundError,
)

from .dependencies import APIKeyDep, ClientDep, LockDep, LockTimeoutDep
from .models import (
    ChatRequest,
    ChatResponse,
    ErrorResponse,
    ModelResponse,
    ModelsListResponse,
    SetModelRequest,
    StatusResponse,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api", tags=["Gemini"])


# ── Exception → HTTP status mapping ─────────────────────────────────────

_EXCEPTION_STATUS_MAP: dict[type, int] = {
    AuthenticationError: status.HTTP_401_UNAUTHORIZED,
    CaptchaError: status.HTTP_403_FORBIDDEN,
    RateLimitError: status.HTTP_429_TOO_MANY_REQUESTS,
    ResponseTimeoutError: status.HTTP_504_GATEWAY_TIMEOUT,
    SelectorNotFoundError: status.HTTP_503_SERVICE_UNAVAILABLE,
    BrowserError: status.HTTP_503_SERVICE_UNAVAILABLE,
}


def _error_status(exc: Exception) -> int:
    """Map a GeminiWebUIError subclass to an HTTP status code."""
    for exc_type, http_status in _EXCEPTION_STATUS_MAP.items():
        if isinstance(exc, exc_type):
            return http_status
    if isinstance(exc, GeminiWebUIError):
        return status.HTTP_500_INTERNAL_SERVER_ERROR
    return status.HTTP_500_INTERNAL_SERVER_ERROR


class BusyError(HTTPException):
    """Raised when the server lock cannot be acquired."""

    def __init__(self) -> None:
        super().__init__(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Server is busy processing another request. Try again later.",
        )


# ── REST endpoints ──────────────────────────────────────────────────────


@router.post(
    "/chat",
    response_model=ChatResponse,
    responses={
        429: {"model": ErrorResponse},
        503: {"model": ErrorResponse},
        504: {"model": ErrorResponse},
    },
    summary="Send a prompt to Gemini",
    description="Send a prompt and receive the full response. Optionally start a new conversation first.",
)
async def chat(
    body: ChatRequest,
    _api_key: APIKeyDep,
    client: ClientDep,
    lock: LockDep,
    lock_timeout: LockTimeoutDep,
) -> ChatResponse:
    """Send a prompt to Gemini and return the response."""
    try:
        acquired = await asyncio.wait_for(lock.acquire(), timeout=lock_timeout)
    except TimeoutError:
        raise BusyError() from None

    if not acquired:
        raise BusyError()

    try:
        if body.new_chat:
            await client.new_chat()

        response: GeminiResponse = await client.send_prompt(body.prompt)
        return ChatResponse(
            text=response.text,
            prompt=response.prompt,
            conversation_id=response.conversation_id,
            model=response.model,
            timestamp=response.timestamp,
        )
    except GeminiWebUIError as exc:
        logger.error("Chat error: %s", exc)
        raise HTTPException(status_code=_error_status(exc), detail=str(exc)) from exc
    except Exception as exc:
        logger.error("Unexpected chat error: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(exc)
        ) from exc
    finally:
        lock.release()


@router.post(
    "/chat/new",
    response_model=ChatResponse,
    summary="Start a new conversation",
    description="Start a new conversation in the Gemini UI. Clears the current chat history.",
)
async def new_chat(
    _api_key: APIKeyDep,
    client: ClientDep,
    lock: LockDep,
    lock_timeout: LockTimeoutDep,
) -> ChatResponse:
    """Start a new conversation."""
    try:
        acquired = await asyncio.wait_for(lock.acquire(), timeout=lock_timeout)
    except TimeoutError:
        raise BusyError() from None

    if not acquired:
        raise BusyError()

    try:
        await client.new_chat()
        return ChatResponse(
            text="",
            prompt="",
            conversation_id=None,
            model=None,
            timestamp=datetime.now(),
        )
    except GeminiWebUIError as exc:
        logger.error("New chat error: %s", exc)
        raise HTTPException(status_code=_error_status(exc), detail=str(exc)) from exc
    finally:
        lock.release()


@router.get(
    "/models",
    response_model=ModelsListResponse,
    summary="List available models",
    description="Get all available Gemini models and the currently active one.",
)
async def list_models(
    _api_key: APIKeyDep,
    client: ClientDep,
    lock: LockDep,
    lock_timeout: LockTimeoutDep,
) -> ModelsListResponse:
    """List available models and the current one."""
    try:
        acquired = await asyncio.wait_for(lock.acquire(), timeout=lock_timeout)
    except TimeoutError:
        raise BusyError() from None

    if not acquired:
        raise BusyError()

    try:
        models = await client.list_models()
        current = await client.get_current_model()
        return ModelsListResponse(models=models, current=current)
    except GeminiWebUIError as exc:
        logger.error("List models error: %s", exc)
        raise HTTPException(status_code=_error_status(exc), detail=str(exc)) from exc
    finally:
        lock.release()


@router.get(
    "/models/current",
    response_model=ModelResponse,
    summary="Get current model",
    description="Get the currently active Gemini model name.",
)
async def get_current_model(
    _api_key: APIKeyDep,
    client: ClientDep,
    lock: LockDep,
    lock_timeout: LockTimeoutDep,
) -> ModelResponse:
    """Get the currently active model."""
    try:
        acquired = await asyncio.wait_for(lock.acquire(), timeout=lock_timeout)
    except TimeoutError:
        raise BusyError() from None

    if not acquired:
        raise BusyError()

    try:
        current = await client.get_current_model()
        return ModelResponse(model=current, message="Current model retrieved")
    except GeminiWebUIError as exc:
        logger.error("Get current model error: %s", exc)
        raise HTTPException(status_code=_error_status(exc), detail=str(exc)) from exc
    finally:
        lock.release()


@router.put(
    "/models",
    response_model=ModelResponse,
    responses={503: {"model": ErrorResponse}},
    summary="Switch model",
    description="Switch to a different Gemini model. Accepts model name or alias (e.g. 'pro', 'flash').",
)
async def set_model(
    body: SetModelRequest,
    _api_key: APIKeyDep,
    client: ClientDep,
    lock: LockDep,
    lock_timeout: LockTimeoutDep,
) -> ModelResponse:
    """Switch the active Gemini model."""
    try:
        acquired = await asyncio.wait_for(lock.acquire(), timeout=lock_timeout)
    except TimeoutError:
        raise BusyError() from None

    if not acquired:
        raise BusyError()

    try:
        await client.set_model(body.model)
        current = await client.get_current_model()
        return ModelResponse(model=current, message="Model switched successfully")
    except GeminiWebUIError as exc:
        logger.error("Set model error: %s", exc)
        raise HTTPException(status_code=_error_status(exc), detail=str(exc)) from exc
    finally:
        lock.release()


@router.get(
    "/status",
    response_model=StatusResponse,
    summary="Server status",
    description="Check the server health, authentication status, and current model.",
)
async def get_status(
    _api_key: APIKeyDep,
    client: ClientDep,
) -> StatusResponse:
    """Get server status and authentication info."""
    try:
        current_model = await client.get_current_model()
    except Exception:
        current_model = None

    try:
        models = await client.list_models()
    except Exception:
        models = []

    return StatusResponse(
        status="ready",
        authenticated=True,
        current_model=current_model,
        available_models=models,
    )


# ── WebSocket endpoint ──────────────────────────────────────────────────


def _ws_check_api_key(websocket: WebSocket) -> None:
    """Verify API key for WebSocket connections.

    Checks the `api_key` query parameter against the configured key.
    Raises an exception if the key is required but missing or incorrect.
    """
    configured_key: str | None = websocket.app.state.api_key

    # No API key configured — open access
    if not configured_key:
        return

    provided_key = websocket.query_params.get("api_key")

    if not provided_key:
        raise ValueError("API key required. Pass api_key query parameter.")
    if provided_key != configured_key:
        raise ValueError("Invalid API key.")


@router.websocket("/ws")
async def ws_chat(websocket: WebSocket) -> None:
    """WebSocket endpoint for interactive chat sessions.

    Client → Server messages:
        {"type": "prompt", "text": "..."}
        {"type": "new_chat"}
        {"type": "set_model", "model": "pro"}
        {"type": "list_models"}

    Server → Client messages:
        {"type": "response", "text": "..."}
        {"type": "error", "text": "..."}
        {"type": "status", "status": "ready"}
        {"type": "models", "models": [...], "current": "..."}
        {"type": "model_changed", "model": "..."}
        {"type": "new_chat"}
    """
    # Verify API key if configured
    try:
        _ws_check_api_key(websocket)
    except ValueError as exc:
        await websocket.close(code=4001, reason=str(exc))
        return

    await websocket.accept()

    client: GeminiClient | None = websocket.app.state.gemini_client
    lock: asyncio.Lock = websocket.app.state.client_lock
    lock_timeout: float = websocket.app.state.lock_timeout

    if client is None or not client.is_authenticated:
        await websocket.send_json({"type": "error", "text": "Not authenticated. Restart the server."})
        await websocket.close()
        return

    await websocket.send_json({"type": "status", "status": "ready"})

    try:
        while True:
            raw = await websocket.receive_text()

            try:
                data = json.loads(raw)
            except json.JSONDecodeError:
                await websocket.send_json({"type": "error", "text": "Invalid message format"})
                continue

            msg_type = data.get("type", "")

            if msg_type == "prompt":
                prompt = data.get("text", "").strip()
                if not prompt:
                    continue

                try:
                    acquired = await asyncio.wait_for(lock.acquire(), timeout=lock_timeout)
                except TimeoutError:
                    await websocket.send_json({"type": "error", "text": "Server is busy. Try again."})
                    continue

                if not acquired:
                    await websocket.send_json({"type": "error", "text": "Server is busy. Try again."})
                    continue

                try:
                    response: GeminiResponse = await client.send_prompt(prompt)
                    await websocket.send_json({"type": "response", "text": response.text})
                except Exception as exc:
                    logger.error("WS chat error: %s", exc)
                    await websocket.send_json({"type": "error", "text": str(exc)})
                finally:
                    lock.release()

            elif msg_type == "new_chat":
                try:
                    acquired = await asyncio.wait_for(lock.acquire(), timeout=lock_timeout)
                except TimeoutError:
                    await websocket.send_json({"type": "error", "text": "Server is busy. Try again."})
                    continue

                if not acquired:
                    await websocket.send_json({"type": "error", "text": "Server is busy. Try again."})
                    continue

                try:
                    await client.new_chat()
                    await websocket.send_json({"type": "new_chat"})
                except Exception as exc:
                    logger.error("WS new chat error: %s", exc)
                    await websocket.send_json({"type": "error", "text": str(exc)})
                finally:
                    lock.release()

            elif msg_type == "list_models":
                try:
                    acquired = await asyncio.wait_for(lock.acquire(), timeout=lock_timeout)
                except TimeoutError:
                    await websocket.send_json({"type": "error", "text": "Server is busy. Try again."})
                    continue

                if not acquired:
                    await websocket.send_json({"type": "error", "text": "Server is busy. Try again."})
                    continue

                try:
                    models = await client.list_models()
                    current = await client.get_current_model()
                    await websocket.send_json({
                        "type": "models",
                        "models": models,
                        "current": current,
                    })
                except Exception as exc:
                    logger.error("WS list models error: %s", exc)
                    await websocket.send_json({"type": "error", "text": str(exc)})
                finally:
                    lock.release()

            elif msg_type == "set_model":
                model = data.get("model", "").strip()
                if not model:
                    continue

                try:
                    acquired = await asyncio.wait_for(lock.acquire(), timeout=lock_timeout)
                except TimeoutError:
                    await websocket.send_json({"type": "error", "text": "Server is busy. Try again."})
                    continue

                if not acquired:
                    await websocket.send_json({"type": "error", "text": "Server is busy. Try again."})
                    continue

                try:
                    await client.set_model(model)
                    current = await client.get_current_model()
                    await websocket.send_json({"type": "model_changed", "model": current})
                except Exception as exc:
                    logger.error("WS set model error: %s", exc)
                    await websocket.send_json({"type": "error", "text": str(exc)})
                finally:
                    lock.release()

    except WebSocketDisconnect:
        logger.info("WebSocket client disconnected")
    except Exception as exc:
        logger.error("WebSocket error: %s", exc)
