# Gemini Web UI Automation — Architecture Plan

## Overview

A Python library that automates the Gemini web UI (`gemini.google.com`) using Playwright, enabling programmatic access to send prompts and receive text responses for free — without using the paid Gemini API.

## Technology Stack

| Component | Choice | Rationale |
|-----------|--------|-----------|
| Language | Python 3.10+ | Most popular for automation, async support |
| Browser Automation | Playwright (Python) | Auto-wait, network interception, headless, modern SPA support |
| Package Manager | uv + pyproject.toml | Fast, modern Python packaging |
| Async Runtime | asyncio | Standard library, Playwright is async-native |

## Project Structure

```
gemini-web-ui/
├── pyproject.toml
├── README.md
├── src/
│   └── gemini_webui/
│       ├── __init__.py          # Public API exports
│       ├── client.py            # Main GeminiClient class (async)
│       ├── sync_client.py       # Sync wrapper
│       ├── auth.py              # Authentication & session management
│       ├── selectors.py         # Centralized CSS/XPath selectors
│       ├── response.py          # Response parsing & data models
│       ├── exceptions.py        # Custom exceptions
│       └── utils.py             # Helpers (wait strategies, etc.)
├── examples/
│   ├── basic_usage.py
│   ├── conversation.py
│   └── headless_server.py
├── sessions/                    # Gitignored — persisted auth sessions
│   └── .gitkeep
├── .gitignore
└── plans/
    └── architecture.md
```

## Architecture Diagram

```mermaid
graph TD
    A[User Code] -->|import| B[GeminiClient / GeminiClientSync]
    B --> C[AuthManager]
    C -->|load/save| D[Session File - JSON]
    C -->|login check| E[Playwright Browser]
    B -->|send_prompt| F[Page Interaction Layer]
    F -->|selectors from| G[selectors.py]
    F -->|wait via| H[utils.py]
    F -->|parse via| I[response.py]
    I --> J[GeminiResponse]
    B -->|errors| K[exceptions.py]
```

## Authentication Flow

```mermaid
flowchart TD
    A[Start] --> B{Session file exists?}
    B -->|Yes| C[Load storageState into browser context]
    B -->|No| D[Create fresh browser context]
    C --> E[Navigate to gemini.google.com]
    D --> E
    E --> F{Logged in?}
    F -->|Yes| G[Save session if new]
    F -->|No| H{Headless mode?}
    H -->|Yes| I[Raise AuthenticationError - suggest headed mode]
    H -->|No| J[Wait for manual login]
    J --> K[Save storageState to session file]
    K --> G
    G --> L[Ready to send prompts]
```

**Key points:**
- First login requires **headed mode** — user logs in manually in the browser window
- After login, `storageState` (cookies + localStorage) is saved to a JSON file
- Subsequent runs can use **headless mode** by loading the saved session
- Session expiry is detected automatically — raises `AuthenticationError` with clear message

## Core API Design

### Async Client

```python
class GeminiClient:
    def __init__(
        self,
        headless: bool = True,
        timeout: int = 120,
        session_path: str | None = None,
        browser_type: str = "chromium",
    ): ...

    async def __aenter__(self) -> GeminiClient: ...
    async def __aexit__(self, *args): ...

    async def login(self, session_path: str | None = None) -> None:
        """Authenticate with Google. Opens headed browser if no session exists."""

    async def send_prompt(
        self,
        prompt: str,
        *,
        new_chat: bool = True,
    ) -> GeminiResponse: ...

    async def new_chat(self) -> None:
        """Start a new conversation."""

    async def close(self) -> None:
        """Close browser and save session."""

    @property
    def is_authenticated(self) -> bool: ...
```

### Sync Client

```python
class GeminiClientSync:
    """Synchronous wrapper around GeminiClient using asyncio.run()."""
    # Same API as GeminiClient but without async/await
```

### Response Model

```python
@dataclass
class GeminiResponse:
    text: str                    # The full response text
    conversation_id: str | None  # Extracted conversation identifier
    model: str | None            # Model name if detectable
    timestamp: datetime          # When the response was received
    prompt: str                  # The original prompt sent
```

## Selector Strategy

Gemini's UI uses dynamically generated class names that change frequently. The selector strategy uses a **fallback chain** for resilience:

1. **`data-testid`** attributes (most stable, if available)
2. **`aria-label`** attributes (semantic, less likely to change)
3. **`role`** attributes (accessibility-based)
4. **Text content matching** (e.g., button with specific text)
5. **CSS class** (last resort, most brittle)

All selectors are centralized in `selectors.py` as constants:

```python
# selectors.py

PROMPT_INPUT = {
    "primary": 'div[aria-label="Enter a prompt"]',
    "fallback": 'rich-textarea textarea',
}

SEND_BUTTON = {
    "primary": 'button[aria-label="Send prompt"]',
    "fallback": 'button:has(mat-icon:has-text("send"))',
}

RESPONSE_CONTAINER = {
    "primary": 'message-content.model-response',
    "fallback": 'model-response message-content',
}

STOP_BUTTON = {
    "primary": 'button[aria-label="Stop generating"]',
    "fallback": 'button:has-text("Stop")',
}

NEW_CHAT_BUTTON = {
    "primary": 'button[aria-label="New chat"]',
    "fallback": 'a[href="/"]',
}
```

## Response Completion Detection

After sending a prompt, the library must detect when the streaming response is complete:

```mermaid
flowchart TD
    A[Send prompt] --> B[Wait for response container to appear]
    B --> C{Stop generating button visible?}
    C -->|Yes| D[Wait and poll again]
    C -->|No| E{Response container has stable content?}
    E -->|No| D
    E -->|Yes| F[Extract response text]
    F --> G[Return GeminiResponse]
    D --> C
```

**Detection strategy:**
1. After sending, wait for the response container element to appear
2. Monitor the "Stop generating" button — when it disappears, streaming is done
3. As a secondary check, poll the response text content — if it hasn't changed for 2 seconds, consider it complete
4. Timeout after configurable duration (default 120s)

## Error Handling

| Exception | Trigger |
|-----------|---------|
| `AuthenticationError` | Not logged in, session expired, or CAPTCHA required |
| `RateLimitError` | Google rate limiting detected in UI |
| `ResponseTimeoutError` | Response not received within timeout |
| `SelectorNotFoundError` | UI changed, selector broken |
| `CaptchaError` | CAPTCHA challenge detected |
| `BrowserError` | Playwright/browser launch failures |

## Configuration Options

```python
@dataclass
class GeminiConfig:
    headless: bool = True              # Run browser in headless mode
    timeout: int = 120                 # Response wait timeout in seconds
    session_path: str | None = None    # Path to persisted auth session
    browser_type: str = "chromium"     # chromium, firefox, or webkit
    slow_mo: int = 0                   # Slow down actions by N ms (debugging)
    user_data_dir: str | None = None   # Persistent browser profile directory
    request_delay: float = 1.0         # Delay between requests in seconds
```

## Key Risk Mitigations

| Risk | Mitigation |
|------|------------|
| Google changes UI | Centralized selectors with fallback chains; easy to update |
| CAPTCHA challenges | Detect and raise `CaptchaError`; suggest headed mode for manual solve |
| Rate limiting | Configurable `request_delay`; detect rate limit UI and raise `RateLimitError` |
| Session expiry | Auto-detect logged-out state; raise `AuthenticationError` with clear message |
| Response streaming | Robust completion detection with stop-button monitoring + content stability check |
| Google TOS | Library is for personal use; user assumes responsibility |

## Implementation Order

1. **Project scaffolding** — `pyproject.toml`, directory structure, `.gitignore`
2. **`exceptions.py`** — Custom exception classes (no dependencies)
3. **`selectors.py`** — Selector constants (no dependencies)
4. **`response.py`** — `GeminiResponse` dataclass (no dependencies)
5. **`utils.py`** — Wait strategies, selector fallback resolution
6. **`auth.py`** — `AuthManager` class for login/session persistence
7. **`client.py`** — Core `GeminiClient` with `send_prompt`, `new_chat`, `close`
8. **`sync_client.py`** — Sync wrapper using `asyncio.run()`
9. **`__init__.py`** — Public API exports
10. **Example scripts** — Basic usage, conversation, headless server
11. **README** — Installation, authentication guide, API reference
12. **Manual testing** — End-to-end verification
