"""Gemini Web UI Automation Library.

Programmatic access to Google Gemini via web UI automation using Playwright.

Usage (async)::

    from gemini_webui import GeminiClient

    async with GeminiClient(headless=True) as client:
        await client.login(session_path="sessions/my_session.json")
        response = await client.send_prompt("Explain quantum computing")
        print(response.text)

Usage (sync)::

    from gemini_webui import GeminiClientSync

    with GeminiClientSync(headless=True) as client:
        client.login(session_path="sessions/my_session.json")
        response = client.send_prompt("Explain quantum computing")
        print(response.text)
"""

from .client import GeminiClient
from .exceptions import (
    AuthenticationError,
    BrowserError,
    CaptchaError,
    GeminiWebUIError,
    RateLimitError,
    ResponseTimeoutError,
    SelectorNotFoundError,
)
from .response import GeminiResponse
from .sync_client import GeminiClientSync

__all__ = [
    # Clients
    "GeminiClient",
    "GeminiClientSync",
    # Response
    "GeminiResponse",
    # Exceptions
    "GeminiWebUIError",
    "AuthenticationError",
    "BrowserError",
    "CaptchaError",
    "RateLimitError",
    "ResponseTimeoutError",
    "SelectorNotFoundError",
]

__version__ = "0.1.0"
