"""Centralized CSS/XPath selectors for the Gemini web UI.

Each selector is a dict with a "primary" key (most stable) and optional
"fallback" keys. The utility function `resolve_selector` in utils.py
tries each in order until one matches.

These selectors target gemini.google.com and may need updating when
Google changes the UI.
"""

# ── URL ────────────────────────────────────────────────────────────────
GEMINI_URL = "https://gemini.google.com/app"

# ── Prompt Input ───────────────────────────────────────────────────────
PROMPT_INPUT = {
    "primary": 'div.ql-editor[contenteditable="true"]',
    "fallback": [
        'rich-textarea div[contenteditable="true"]',
        'textarea[aria-label="Enter a prompt"]',
        'div[aria-label="Enter a prompt"]',
        '.input-area textarea',
        'rich-textarea',
        '[contenteditable="true"]', # Most generic fallback
    ],
}

# ── Send Button ────────────────────────────────────────────────────────
SEND_BUTTON = {
    "primary": 'button[aria-label="Send prompt"]',
    "fallback": [
        'button.send-button',
        'button[aria-label*="Send"]',
        'button:has(mat-icon:has-text("send"))',
    ],
}

# ── Response Container ─────────────────────────────────────────────────
# The container holding the model's response text
RESPONSE_CONTAINER = {
    "primary": "model-response message-content",
    "fallback": [
        "message-content.model-response",
        '.model-response .message-content',
        '[data-response-role="model"]',
    ],
}

# ── Individual Response Turn ───────────────────────────────────────────
# Selector for the last (most recent) response turn in the conversation
LAST_RESPONSE_TURN = {
    "primary": "model-response:last-of-type",
    "fallback": [
        ".conversation-container model-response:last-child",
    ],
}

# ── Response Text Content ──────────────────────────────────────────────
# The element within a response that holds the actual markdown/text
RESPONSE_TEXT = {
    "primary": "message-content .markdown",
    "fallback": [
        "message-content .model-response-text",
        "model-response .markdown",
        "model-response .response-container-content",
    ],
}

# ── Stop Generating Button ─────────────────────────────────────────────
# Visible while the model is still streaming its response
STOP_BUTTON = {
    "primary": 'button[aria-label="Stop generating"]',
    "fallback": [
        'button[aria-label*="Stop"]',
        'button.stop-generating',
        'button:has(mat-icon:has-text("stop"))',
    ],
}

# ── New Chat Button ────────────────────────────────────────────────────
NEW_CHAT_BUTTON = {
    "primary": 'a[aria-label="New chat"]',
    "fallback": [
        'button[aria-label="New chat"]',
        'a[href="/app"]',
        'a.new-chat-button',
    ],
}

# ── Authentication Indicators ──────────────────────────────────────────
# Element that indicates the user is logged in
LOGGED_IN_INDICATOR = {
    "primary": 'img[data-auto-src]',
    "fallback": [
        '[aria-label="Account"]',
        'img.account-avatar',
        '.user-avatar',
    ],
}

# Element that indicates the user needs to sign in
SIGN_IN_BUTTON = {
    "primary": 'button:has-text("Sign in")',
    "fallback": [
        'a:has-text("Sign in")',
        'a[href*="accounts.google.com"]',
    ],
}

# ── Rate Limit / Error Indicators ──────────────────────────────────────
RATE_LIMIT_INDICATOR = {
    "primary": ':has-text("Try again later")',
    "fallback": [
        ':has-text("rate limit")',
        ':has-text("too many requests")',
        ':has-text("Something went wrong")',
    ],
}

CAPTCHA_INDICATOR = {
    "primary": 'iframe[src*="recaptcha"]',
    "fallback": [
        'iframe[src*="captcha"]',
        '.captcha-container',
        '#captcha',
    ],
}

# ── Model Picker ───────────────────────────────────────────────────────
# Button that opens the model picker dropdown
MODEL_PICKER_BUTTON = {
    "primary": 'button[aria-label="Open mode picker"]',
    "fallback": [
        "button.mat-mdc-menu-trigger.input-area-switch",
        "bard-mode-switcher button.mat-mdc-menu-trigger",
        ".model-picker-container button",
    ],
}

# The dropdown menu panel that appears when the picker is opened
MODEL_PICKER_MENU = {
    "primary": ".mat-mdc-menu-panel.gds-mode-switch-menu",
    "fallback": [
        ".mat-mdc-menu-panel",
        ".cdk-overlay-pane [role='menu']",
    ],
}

# Individual model option buttons inside the dropdown
# Each has a data-test-id like "bard-mode-option-fast", "bard-mode-option-pro", etc.
MODEL_OPTION = {
    "primary": "button[role='menuitem'].bard-mode-list-button",
    "fallback": [
        "button[role='menuitem'].mat-mdc-menu-item",
        ".gds-mode-switch-menu button[role='menuitem']",
    ],
}

# Known model option data-test-id suffixes (appended to "bard-mode-option-")
# These are used to build specific selectors for each model
MODEL_IDS = {
    "fast": "bard-mode-option-fast",
    "thinking": "bard-mode-option-thinking",
    "pro": "bard-mode-option-pro",
}

# ── Sidebar / Conversation List ────────────────────────────────────────
CONVERSATION_LIST_ITEM = {
    "primary": "conversation-list-item",
    "fallback": [
        ".conversation-list a",
        '[role="listitem"]',
    ],
}
