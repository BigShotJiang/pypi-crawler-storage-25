"""Synchronous wrapper around the async GeminiClient.

Provides GeminiClientSync — a drop-in sync version of GeminiClient
that internally uses asyncio.run() for users who don't need async.
"""

from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Any

from .client import GeminiClient
from .response import GeminiResponse


class GeminiClientSync:
    """Synchronous client for automating the Gemini web UI.

    This is a convenience wrapper around the async GeminiClient that
    handles the asyncio event loop internally. For async usage, use
    GeminiClient directly.

    Usage::

        client = GeminiClientSync(headless=True)
        client.start()
        try:
            client.login(session_path="sessions/my_session.json")
            response = client.send_prompt("Explain quantum computing")
            print(response.text)
        finally:
            client.close()

    Or as a context manager::

        with GeminiClientSync(headless=True) as client:
            client.login(session_path="sessions/my_session.json")
            response = client.send_prompt("Explain quantum computing")
            print(response.text)
    """

    def __init__(
        self,
        headless: bool = True,
        timeout: float = 120.0,
        session_path: str | Path | None = None,
        browser_type: str = "chromium",
        slow_mo: int = 0,
        request_delay: float = 1.0,
        use_system_chrome: bool = True,
        user_data_dir: str | Path | None = None,
    ) -> None:
        """Initialize the GeminiClientSync.

        Args:
            headless: Run the browser in headless mode.
            timeout: Maximum seconds to wait for a response.
            session_path: Path to save/load authentication session state.
            browser_type: Browser engine: "chromium", "firefox", or "webkit".
            slow_mo: Slow down browser actions by N ms (debugging).
            request_delay: Minimum seconds between consecutive prompts.
            use_system_chrome: Use system-installed Chrome to avoid
                Google's "browser not secure" detection. Defaults to True.
            user_data_dir: Path to a persistent browser profile directory.
        """
        self._async_client = GeminiClient(
            headless=headless,
            timeout=timeout,
            session_path=session_path,
            browser_type=browser_type,
            slow_mo=slow_mo,
            request_delay=request_delay,
            use_system_chrome=use_system_chrome,
            user_data_dir=user_data_dir,
        )

    @property
    def is_authenticated(self) -> bool:
        """Whether the client is currently authenticated."""
        return self._async_client.is_authenticated

    def start(self) -> None:
        """Start the browser and create a new page."""
        asyncio.run(self._async_client.start())

    def close(self) -> None:
        """Close the browser and save the session."""
        asyncio.run(self._async_client.close())

    def login(
        self,
        session_path: str | Path | None = None,
        login_timeout: float = 120.0,
    ) -> None:
        """Authenticate with Google.

        Args:
            session_path: Override the session path set in __init__.
            login_timeout: Seconds to wait for manual login in headed mode.
        """
        asyncio.run(self._async_client.login(session_path=session_path, login_timeout=login_timeout))

    def login_from_browser(
        self,
        browser_name: str = "chrome",
        session_path: str | Path | None = None,
    ) -> None:
        """Authenticate by extracting cookies from your regular browser.

        Requires the optional ``browser-cookie3`` package::

            pip install gemini-webui[cookies]

        Args:
            browser_name: Which browser to extract cookies from.
                Options: "chrome", "chromium", "firefox", "opera", "edge".
            session_path: Override the session path set in __init__.
        """
        asyncio.run(
            self._async_client.login_from_browser(
                browser_name=browser_name, session_path=session_path
            )
        )

    def send_prompt(
        self,
        prompt: str,
        *,
        new_chat: bool = False,
    ) -> GeminiResponse:
        """Send a prompt to Gemini and wait for the response.

        Args:
            prompt: The text prompt to send.
            new_chat: If True, start a new conversation before sending.

        Returns:
            A GeminiResponse containing the model's response text.
        """
        return asyncio.run(self._async_client.send_prompt(prompt, new_chat=new_chat))

    def new_chat(self) -> None:
        """Start a new conversation in the Gemini UI."""
        asyncio.run(self._async_client.new_chat())

    def get_current_model(self) -> str:
        """Get the name of the currently selected model.

        Returns:
            The model name as a string (e.g. "Fast", "Thinking", "Pro").
        """
        return asyncio.run(self._async_client.get_current_model())

    def list_models(self) -> list[str]:
        """List the available model names in the Gemini UI.

        Returns:
            A list of model name strings (e.g. ["Fast", "Thinking", "Pro"]).
        """
        return asyncio.run(self._async_client.list_models())

    def set_model(self, model: str) -> None:
        """Switch the Gemini model.

        Args:
            model: The model to switch to. Supported values:
                - "fast" or "flash" — Fast model (Gemini Flash)
                - "thinking" — Thinking model
                - "pro" — Pro model (Gemini Pro)
        """
        asyncio.run(self._async_client.set_model(model))

    def __enter__(self) -> GeminiClientSync:
        """Start the browser when entering the context manager."""
        self.start()
        return self

    def __exit__(self, *args: Any) -> None:
        """Close the browser when exiting the context manager."""
        self.close()
