"""Authentication and session management for the Gemini Web UI.

Handles Google login flow, session persistence via Playwright's storageState,
and session validation.
"""

from __future__ import annotations

import asyncio
import json
import logging
from pathlib import Path

from playwright.async_api import BrowserContext, Page

from .exceptions import AuthenticationError, CaptchaError
from .selectors import GEMINI_URL, PROMPT_INPUT, SIGN_IN_BUTTON
from .utils import check_for_captcha

logger = logging.getLogger(__name__)

# Default directory for persisted sessions
DEFAULT_SESSIONS_DIR = Path("sessions")


class AuthManager:
    """Manages authentication state for the Gemini web UI.

    Handles:
    - Loading and saving browser session state (cookies, localStorage)
    - Detecting whether the user is logged in
    - Guiding the user through manual login in headed mode
    - Detecting CAPTCHA challenges and session expiry
    """

    def __init__(self, context: BrowserContext) -> None:
        """Initialize the AuthManager.

        Args:
            context: The Playwright BrowserContext to manage auth for.
        """
        self._context = context
        self._is_authenticated = False

    @property
    def is_authenticated(self) -> bool:
        """Whether the user is currently authenticated."""
        return self._is_authenticated

    async def check_login_status(self, page: Page) -> bool:
        """Check if the user is currently logged in on the page.

        Uses JavaScript evaluation to inspect the DOM directly, which is far
        more reliable than CSS selector matching against Google's changing UI.

        Logic:
        1. If redirected to accounts.google.com → NOT logged in
        2. If "Sign in" text is visible on the page → NOT logged in
        3. If the page has loaded AND no "Sign in" text → logged in
        """
        # Check for CAPTCHA first
        if await check_for_captcha(page):
            raise CaptchaError(
                "CAPTCHA challenge detected. "
                "Run in headed mode (headless=False) to solve it manually."
            )

        logger.debug("Waiting for page to settle to determine login status...")
        
        for attempt in range(20):
            # 0. Check URL redirect
            if "accounts.google.com" in page.url:
                logger.debug("Redirected to accounts.google.com - definitely not logged in.")
                self._is_authenticated = False
                return False

            # Use JavaScript to inspect the page directly — much more reliable
            # than CSS selectors which break every time Google changes class names
            try:
                result = await page.evaluate("""() => {
                    // Check 1: Is there a visible "Sign in" button/link?
                    // This is the most reliable indicator of NOT being logged in
                    const allElements = document.querySelectorAll('a, button');
                    for (const el of allElements) {
                        const text = (el.textContent || '').trim();
                        const href = el.getAttribute('href') || '';
                        const ariaLabel = el.getAttribute('aria-label') || '';
                        if (
                            (text === 'Sign in' || text === 'Sign In') ||
                            href.includes('accounts.google.com/ServiceLogin') ||
                            ariaLabel.toLowerCase().includes('sign in')
                        ) {
                            // Make sure it's actually visible
                            const rect = el.getBoundingClientRect();
                            if (rect.width > 0 && rect.height > 0) {
                                return { loggedIn: false, reason: 'sign-in-button', detail: text || href || ariaLabel };
                            }
                        }
                    }
                    
                    // Check 2: Is the page loaded? Look for ANY interactive element
                    // that proves the Gemini UI has rendered
                    const pageLoaded = !!(
                        document.querySelector('[contenteditable="true"]') ||
                        document.querySelector('textarea') ||
                        document.querySelector('rich-textarea') ||
                        document.querySelector('mat-sidenav') ||
                        document.querySelector('conversation-list-item') ||
                        document.querySelector('[role="navigation"]') ||
                        document.querySelector('nav') ||
                        // Check for any image that could be a profile picture
                        document.querySelector('img[alt*="Profile"]') ||
                        document.querySelector('img[alt*="Account"]') ||
                        // Check for any element with Account/Profile in aria-label
                        document.querySelector('[aria-label*="Account"]') ||
                        document.querySelector('[aria-label*="Profile"]') ||
                        document.querySelector('[aria-label*="Google Account"]') ||
                        // Check for the model picker / sidebar menu
                        document.querySelector('[aria-label="Open mode picker"]') ||
                        document.querySelector('[aria-label="Main menu"]') ||
                        document.querySelector('[aria-label="New chat"]') ||
                        // Check for any button with "New chat" text
                        Array.from(document.querySelectorAll('button')).find(b => b.textContent?.trim().startsWith('New chat')) ||
                        // Check for the prompt area placeholder
                        document.querySelector('[data-placeholder]') ||
                        // Very broad: any contenteditable or input area
                        document.querySelector('[contenteditable]') ||
                        // Check for conversation items in sidebar
                        document.querySelector('[data-test-id*="conversation"]')
                    );
                    
                    if (pageLoaded) {
                        return { loggedIn: true, reason: 'page-loaded-no-signin' };
                    }
                    
                    return { loggedIn: null, reason: 'page-not-loaded-yet' };
                }""")

                if result.get("loggedIn") is False:
                    logger.debug("Not logged in: %s (%s)", result["reason"], result.get("detail", ""))
                    self._is_authenticated = False
                    return False
                elif result.get("loggedIn") is True:
                    logger.debug("Logged in: %s", result["reason"])
                    self._is_authenticated = True
                    return True
                # else: page not loaded yet, keep polling
                
            except Exception as e:
                logger.debug("JS evaluation failed (page may not be ready): %s", e)
            
            await asyncio.sleep(0.5)

        # If we reach here, the page never clearly loaded
        logger.warning("Could not definitively determine login status after 10 seconds, assuming not logged in.")
        self._is_authenticated = False
        return False

    async def login(
        self,
        page: Page,
        session_path: str | Path | None = None,
        headless: bool = True,
        login_timeout: float = 120.0,
    ) -> None:
        """Perform login, using a saved session if available.

        Args:
            page: The Playwright Page to use for login.
            session_path: Path to a session JSON file. If it exists, the session
                will be loaded. If not, a new session will be created and saved here.
            headless: Whether the browser is running in headless mode.
            login_timeout: Seconds to wait for manual login in headed mode.

        Raises:
            AuthenticationError: If login fails or is not possible.
            CaptchaError: If a CAPTCHA challenge is detected.
        """
        # Navigate to Gemini
        logger.info("Navigating to %s", GEMINI_URL)
        await page.goto(GEMINI_URL, wait_until="domcontentloaded")

        # Check if already logged in
        # We don't need a hardcoded 5s sleep anymore because check_login_status 
        # now internally waits for the page to settle up to 10 seconds.
        if await self.check_login_status(page):
            logger.info("Already logged in")
            # Save session if a path was provided
            if session_path:
                await self.save_session(session_path)
            return

        # Still not logged in
        if headless:
            raise AuthenticationError(
                "Not logged in and running in headless mode. "
                "Cannot perform manual login. "
                "Run with headless=False first to log in and save a session, "
                "then use headless=True with the saved session."
            )

        # Headed mode — wait for user to log in manually
        logger.info(
            "Waiting for manual login (timeout: %d seconds). "
            "Please log in using the browser window.",
            int(login_timeout),
        )

        try:
            # Poll for login status instead of waiting for a specific selector
            # This is more resilient to UI changes
            elapsed = 0.0
            poll_interval = 2.0

            while elapsed < login_timeout:
                await asyncio.sleep(poll_interval)
                elapsed += poll_interval

                if await self.check_login_status(page):
                    break
            else:
                raise AuthenticationError(
                    f"Login did not complete within {login_timeout} seconds."
                )

        except AuthenticationError:
            raise
        except Exception as e:
            raise AuthenticationError(f"Login failed: {e}") from e

        if self._is_authenticated:
            logger.info("Login successful")
            # Save the session for future use
            if session_path:
                await self.save_session(session_path)

    async def login_from_browser(
        self,
        page: Page,
        browser_name: str = "chrome",
        session_path: str | Path | None = None,
    ) -> None:
        """Authenticate by extracting cookies from the user's regular browser.

        This allows you to log in using your existing browser session without
        needing to sign in through the Playwright window. It reads cookies from
        your installed browser (Chrome, Firefox, etc.) and injects them into
        the Playwright context.

        Requires the optional ``browser-cookie3`` package::

            pip install gemini-webui[cookies]

        Args:
            page: The Playwright Page to use.
            browser_name: Which browser to extract cookies from.
                Options: "chrome", "chromium", "firefox", "opera", "edge".
                Defaults to "chrome".
            session_path: Path to save the session JSON file for future use.

        Raises:
            AuthenticationError: If cookie extraction fails or login is not detected.
            ImportError: If browser-cookie3 is not installed.
        """
        try:
            import browser_cookie3
        except ImportError:
            raise ImportError(
                "browser-cookie3 is required for login_from_browser(). "
                "Install it with: pip install gemini-webui[cookies]"
            )

        # Get the cookie extraction function for the specified browser
        cookie_getters = {
            "chrome": browser_cookie3.chrome,
            "chromium": browser_cookie3.chromium,
            "firefox": browser_cookie3.firefox,
            "opera": browser_cookie3.opera,
            "edge": browser_cookie3.edge,
        }

        getter = cookie_getters.get(browser_name)
        if getter is None:
            raise AuthenticationError(
                f"Unsupported browser: {browser_name}. "
                f"Supported: {', '.join(cookie_getters.keys())}"
            )

        # Extract cookies for Google domains
        logger.info("Extracting cookies from %s browser...", browser_name)
        try:
            cj = getter(domain_name=".google.com")
        except Exception as e:
            raise AuthenticationError(
                f"Failed to extract cookies from {browser_name}. "
                f"Make sure {browser_name} is installed and you've logged into Google with it. "
                f"Error: {e}"
            ) from e

        # Convert cookies to Playwright format and add to context
        cookie_count = 0
        for cookie in cj:
            cookie_dict = {
                "name": cookie.name,
                "value": cookie.value,
                "domain": cookie.domain,
                "path": cookie.path,
                "secure": cookie.secure,
                "httpOnly": cookie.has_nonstandard_attr("HttpOnly")
                or cookie.has_nonstandard_attr("httponly"),
            }

            # Handle expiry
            if cookie.expires and cookie.expires > 0:
                cookie_dict["expires"] = cookie.expires

            # SameSite attribute
            same_site = None
            if cookie.has_nonstandard_attr("SameSite"):
                same_site = cookie.get_nonstandard_attr("SameSite")
            if same_site in ("Strict", "Lax", "None"):
                cookie_dict["sameSite"] = same_site
            else:
                cookie_dict["sameSite"] = "Lax"

            await self._context.add_cookies([cookie_dict])
            cookie_count += 1

        logger.info("Injected %d cookies from %s", cookie_count, browser_name)

        if cookie_count == 0:
            raise AuthenticationError(
                f"No Google cookies found in {browser_name}. "
                f"Make sure you've logged into Google (gemini.google.com) in {browser_name}."
            )

        # Navigate to Gemini to verify the cookies work
        logger.info("Navigating to %s to verify cookies...", GEMINI_URL)
        await page.goto(GEMINI_URL, wait_until="domcontentloaded")
        await asyncio.sleep(5)

        # Check if login was successful
        if await self.check_login_status(page):
            logger.info("Login from browser cookies successful!")
            if session_path:
                await self.save_session(session_path)
        else:
            raise AuthenticationError(
                f"Login from {browser_name} cookies failed. "
                f"The cookies may be expired or insufficient. "
                f"Try logging into gemini.google.com in your {browser_name} browser first, "
                f"then try again."
            )

    async def save_session(self, session_path: str | Path) -> None:
        """Save the current browser context state to a file.

        This saves cookies and localStorage, which can be used to
        restore the session in future runs.

        Args:
            session_path: Path to save the session JSON file.
        """
        path = Path(session_path)
        path.parent.mkdir(parents=True, exist_ok=True)

        state = await self._context.storage_state()
        path.write_text(json.dumps(state, indent=2))
        logger.info("Session saved to %s", path)

    @staticmethod
    async def load_session(context_factory, session_path: str | Path) -> BrowserContext:
        """Create a browser context with a saved session loaded.

        Args:
            context_factory: A callable that creates a new BrowserContext.
                Accepts a `storage_state` keyword argument.
            session_path: Path to the session JSON file.

        Returns:
            A BrowserContext with the saved session state loaded.

        Raises:
            FileNotFoundError: If the session file doesn't exist.
        """
        path = Path(session_path)
        if not path.exists():
            raise FileNotFoundError(f"Session file not found: {path}")

        logger.info("Loading session from %s", path)
        context = await context_factory(storage_state=str(path))
        return context
