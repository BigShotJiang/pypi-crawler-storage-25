"""Utility helpers for the Gemini Web UI automation library."""

from __future__ import annotations

import asyncio
import logging
from typing import Any

from playwright.async_api import Page, Locator

from .exceptions import SelectorNotFoundError
from .selectors import CAPTCHA_INDICATOR, RATE_LIMIT_INDICATOR

logger = logging.getLogger(__name__)


def _get_selector_list(selector_dict: dict[str, Any]) -> list[str]:
    """Extract an ordered list of CSS selectors from a selector dictionary.

    Args:
        selector_dict: A dict with "primary" and optional "fallback" keys.

    Returns:
        A list of CSS selector strings, primary first, then fallbacks.
    """
    selectors: list[str] = []
    if "primary" in selector_dict:
        selectors.append(selector_dict["primary"])
    if "fallback" in selector_dict:
        fallbacks = selector_dict["fallback"]
        if isinstance(fallbacks, str):
            selectors.append(fallbacks)
        elif isinstance(fallbacks, list):
            selectors.extend(fallbacks)
    return selectors


async def resolve_selector(
    page: Page, selector_dict: dict[str, Any], *, timeout: float | None = None
) -> Locator:
    """Try selectors in priority order and return the first matching locator.

    Args:
        page: The Playwright Page to search on.
        selector_dict: A dict with "primary" and optional "fallback" keys.
        timeout: If provided, wait up to this many milliseconds for at least
            one selector to match. If None (default), check immediately without
            waiting.

    Returns:
        A Playwright Locator for the first matching element.

    Raises:
        SelectorNotFoundError: If none of the selectors match any element.
    """
    selectors = _get_selector_list(selector_dict)

    if timeout is not None:
        # Try waiting for each selector with the given timeout
        for sel in selectors:
            try:
                await page.wait_for_selector(sel, timeout=timeout)
                locator = page.locator(sel)
                count = await locator.count()
                if count > 0:
                    logger.debug("Selector matched after wait: %s (%d elements)", sel, count)
                    return locator
            except Exception:
                continue

    # Immediate check (no waiting)
    for sel in selectors:
        try:
            locator = page.locator(sel)
            # Use a short timeout — we're just probing for existence
            count = await locator.count()
            if count > 0:
                logger.debug("Selector matched: %s (%d elements)", sel, count)
                return locator
        except Exception:
            continue

    raise SelectorNotFoundError(
        f"No element found for any selector in {selector_dict}. "
        f"The Gemini UI may have changed. Try updating selectors."
    )


async def resolve_selector_first(
    page: Page, selector_dict: dict[str, Any], *, timeout: float | None = None
) -> Locator:
    """Like resolve_selector, but returns only the first matching element.

    Args:
        page: The Playwright Page to search on.
        selector_dict: A dict with "primary" and optional "fallback" keys.
        timeout: If provided, wait up to this many milliseconds for at least
            one selector to match. If None (default), check immediately without
            waiting.

    Returns:
        A Playwright Locator for the first matching element.

    Raises:
        SelectorNotFoundError: If none of the selectors match any element.
    """
    locator = await resolve_selector(page, selector_dict, timeout=timeout)
    return locator.first


async def wait_for_response_completion(
    page: Page,
    timeout: float = 120.0,
    stability_interval: float = 2.0,
) -> None:
    """Wait for the Gemini model to finish generating its response.

    Uses two strategies:
    1. Wait for the "Stop generating" button to disappear (streaming done).
    2. Verify response text content is stable (not changing).

    Args:
        page: The Playwright Page to monitor.
        timeout: Maximum seconds to wait for response completion.
        stability_interval: Seconds to wait between content checks for stability.

    Raises:
        ResponseTimeoutError: If the response doesn't complete within timeout.
    """
    from .exceptions import ResponseTimeoutError

    # Strategy 1: Wait for the stop button to disappear
    # The stop button is visible while streaming; when it disappears, streaming is done
    stop_selectors = _get_selector_list(
        {
            "primary": 'button[aria-label="Stop generating"]',
            "fallback": [
                'button[aria-label*="Stop"]',
                'button.stop-generating',
            ],
        }
    )

    try:
        # First check if stop button exists (means streaming started)
        stop_visible = False
        for sel in stop_selectors:
            try:
                locator = page.locator(sel)
                if await locator.count() > 0 and await locator.first.is_visible():
                    stop_visible = True
                    break
            except Exception:
                continue

        if stop_visible:
            # Wait for the stop button to become hidden/detached
            try:
                await page.wait_for_selector(
                    stop_selectors[0], state="hidden", timeout=timeout * 1000
                )
            except Exception:
                # Try waiting for any stop button to disappear
                for sel in stop_selectors:
                    try:
                        await page.locator(sel).first.wait_for(
                            state="hidden", timeout=5000
                        )
                    except Exception:
                        continue
    except Exception:
        logger.debug("Stop button detection inconclusive, falling back to stability check")

    # Strategy 2: Content stability check
    # Poll the last response text and confirm it hasn't changed
    prev_text = ""
    stable_count = 0
    required_stable_checks = 2  # Need 2 consecutive identical reads

    elapsed = 0.0
    poll_interval = 1.0

    while elapsed < timeout:
        await asyncio.sleep(poll_interval)
        elapsed += poll_interval

        try:
            # Try to get the latest response text
            response_selectors = _get_selector_list(
                {
                    "primary": "model-response:last-of-type message-content .markdown",
                    "fallback": [
                        "model-response:last-of-type .markdown",
                        "model-response:last-of-type message-content",
                    ],
                }
            )

            current_text = ""
            for sel in response_selectors:
                try:
                    locator = page.locator(sel)
                    if await locator.count() > 0:
                        current_text = await locator.first.inner_text()
                        break
                except Exception:
                    continue

            # JS fallback: pierce shadow DOM if CSS selectors found nothing
            if not current_text:
                try:
                    current_text = await page.evaluate("""() => {
                        function findInShadowRoots(root) {
                            const responses = root.querySelectorAll('model-response');
                            if (responses.length > 0) {
                                const last = responses[responses.length - 1];
                                const markdown = last.querySelector('.markdown');
                                if (markdown) return markdown.textContent;
                                const content = last.querySelector('message-content');
                                if (content) return content.textContent;
                                return last.textContent;
                            }
                            const modelEls = root.querySelectorAll('[data-response-role="model"]');
                            if (modelEls.length > 0) {
                                return modelEls[modelEls.length - 1].textContent;
                            }
                            const allElements = root.querySelectorAll('*');
                            for (const el of allElements) {
                                if (el.shadowRoot) {
                                    const found = findInShadowRoots(el.shadowRoot);
                                    if (found) return found;
                                }
                            }
                            return null;
                        }
                        return findInShadowRoots(document);
                    }""") or ""
                except Exception:
                    pass

            if current_text and current_text == prev_text:
                stable_count += 1
                if stable_count >= required_stable_checks:
                    logger.debug("Response content stable for %d checks", stable_count)
                    return
            else:
                stable_count = 0
                prev_text = current_text

        except Exception as e:
            logger.debug("Error during stability check: %s", e)

    raise ResponseTimeoutError(
        f"Response did not complete within {timeout} seconds. "
        f"The model may still be generating, or the UI may have changed."
    )


async def check_for_captcha(page: Page) -> bool:
    """Check if a CAPTCHA challenge is present on the page.

    Args:
        page: The Playwright Page to check.

    Returns:
        True if a CAPTCHA is detected, False otherwise.
    """
    selectors = _get_selector_list(CAPTCHA_INDICATOR)
    for sel in selectors:
        try:
            locator = page.locator(sel)
            if await locator.count() > 0:
                return True
        except Exception:
            continue
    return False


async def check_for_rate_limit(page: Page) -> bool:
    """Check if a rate limit message is present on the page.

    Args:
        page: The Playwright Page to check.

    Returns:
        True if rate limiting is detected, False otherwise.
    """
    selectors = _get_selector_list(RATE_LIMIT_INDICATOR)
    for sel in selectors:
        try:
            locator = page.locator(sel)
            if await locator.count() > 0:
                return True
        except Exception:
            continue
    return False


async def type_in_contenteditable(
    locator: Locator,
    text: str,
    delay: int = 50,
) -> None:
    """Type text into a contenteditable div (Gemini's prompt input).

    Uses Playwright's fill + keyboard type for reliable input into
    contenteditable elements.

    Args:
        locator: The Playwright Locator for the contenteditable element.
        text: The text to type.
        delay: Milliseconds between keystrokes.
    """
    # Click to focus the contenteditable element
    await locator.click()

    # Clear any existing content
    await locator.fill("")

    # Type the new text character by character for realistic input
    await locator.type(text, delay=delay)
