"""Response data models for the Gemini Web UI automation library."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime


@dataclass
class GeminiResponse:
    """Represents a response from the Gemini web UI.

    Attributes:
        text: The full response text from the model.
        prompt: The original prompt that was sent.
        conversation_id: An identifier for the conversation, if detectable.
        model: The model name used for the response, if detectable.
        timestamp: When the response was received.
    """

    text: str
    prompt: str
    conversation_id: str | None = None
    model: str | None = None
    timestamp: datetime = field(default_factory=datetime.now)

    def __str__(self) -> str:
        return self.text

    def __repr__(self) -> str:
        text_preview = self.text[:80] + "..." if len(self.text) > 80 else self.text
        return (
            f"GeminiResponse(text={text_preview!r}, model={self.model!r}, "
            f"conversation_id={self.conversation_id!r})"
        )
