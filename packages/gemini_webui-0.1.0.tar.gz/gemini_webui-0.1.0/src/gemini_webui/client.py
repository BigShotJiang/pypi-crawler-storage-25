"""Core async GeminiClient for the Gemini Web UI automation library.

This module provides the main `GeminiClient` class that manages the browser
lifecycle, authentication, and prompt/response interaction with the Gemini
web UI at gemini.google.com.
"""

from __future__ import annotations

import asyncio
import logging
import shutil
from datetime import datetime
from pathlib import Path
from typing import Any

from playwright.async_api import (
    BrowserContext,
    ElementHandle,
    Page,
    Playwright,
    async_playwright,
)

from .auth import AuthManager
from .exceptions import (
    AuthenticationError,
    BrowserError,
    RateLimitError,
    ResponseTimeoutError,
    SelectorNotFoundError,
)
from .response import GeminiResponse
from .selectors import (
    GEMINI_URL,
    MODEL_IDS,
    MODEL_OPTION,
    MODEL_PICKER_BUTTON,
    MODEL_PICKER_MENU,
    NEW_CHAT_BUTTON,
    PROMPT_INPUT,
    SEND_BUTTON,
)
from .utils import (
    check_for_rate_limit,
    resolve_selector_first,
    type_in_contenteditable,
    wait_for_response_completion,
)

logger = logging.getLogger(__name__)

# Browser arguments to avoid automation detection by Google
STEALTH_ARGS = [
    "--disable-blink-features=AutomationControlled",  # Remove navigator.webdriver flag
    "--no-first-run",
    "--no-default-browser-check",
    "--disable-infobars",
    "--window-size=1280,800",
]


def _find_chrome_path() -> str | None:
    """Find the system-installed Chrome or Chromium binary.

    Returns:
        Path to the Chrome executable, or None if not found.
    """
    # Common Chrome/Chromium paths on Linux
    linux_paths = [
        "/usr/bin/google-chrome",
        "/usr/bin/google-chrome-stable",
        "/usr/bin/chromium-browser",
        "/usr/bin/chromium",
        "/snap/bin/chromium",
    ]
    for path in linux_paths:
        if shutil.which(path) or Path(path).exists():
            return path

    return None


class GeminiClient:
    """Async client for automating the Gemini web UI.

    Usage::

        async with GeminiClient(headless=True) as client:
            await client.login(session_path="sessions/my_session.json")
            response = await client.send_prompt("Explain quantum computing")
            print(response.text)

    Or without the context manager::

        client = GeminiClient(headless=True)
        await client.start()
        try:
            await client.login(session_path="sessions/my_session.json")
            response = await client.send_prompt("Explain quantum computing")
            print(response.text)
        finally:
            await client.close()
    """

    def __init__(
        self,
        headless: bool = True,
        timeout: float = 120.0,
        session_path: str | Path | None = None,
        browser_type: str = "chromium",
        slow_mo: int = 0,
        request_delay: float = 1.0,
        use_system_chrome: bool = True,
        user_data_dir: str | Path | None = None,
    ) -> None:
        """Initialize the GeminiClient.

        Args:
            headless: Run the browser in headless mode. Set to False for
                first-time login to allow manual Google authentication.
            timeout: Maximum seconds to wait for a response after sending
                a prompt.
            session_path: Path to save/load authentication session state.
                If None, sessions won't be persisted.
            browser_type: Browser engine to use: "chromium", "firefox",
                or "webkit". Ignored when use_system_chrome=True.
            slow_mo: Slow down browser actions by this many milliseconds.
                Useful for debugging.
            request_delay: Minimum seconds to wait between consecutive
                prompts to avoid rate limiting.
            use_system_chrome: Use the system-installed Chrome instead of
                Playwright's bundled Chromium. This helps avoid Google's
                "browser not secure" detection. Defaults to True.
            user_data_dir: Path to a persistent browser profile directory.
                Using a persistent profile makes the browser appear more
                legitimate to Google. If None, a temp directory is used
                for non-persistent contexts.
        """
        self._headless = headless
        self._timeout = timeout
        self._session_path = Path(session_path) if session_path else None
        self._browser_type = browser_type
        self._slow_mo = slow_mo
        self._request_delay = request_delay
        self._use_system_chrome = use_system_chrome
        self._user_data_dir = Path(user_data_dir) if user_data_dir else None

        self._playwright: Playwright | None = None
        self._context: BrowserContext | None = None
        self._page: Page | None = None
        self._auth_manager: AuthManager | None = None
        self._last_request_time: float = 0.0
        self._owns_user_data_dir = False

    @property
    def is_authenticated(self) -> bool:
        """Whether the client is currently authenticated."""
        return self._auth_manager.is_authenticated if self._auth_manager else False

    @property
    def page(self) -> Page:
        """The current Playwright Page.

        Returns:
            The active Page instance.

        Raises:
            BrowserError: If the browser hasn't been started.
        """
        if self._page is None:
            raise BrowserError("Browser not started. Call start() or use as context manager.")
        return self._page

    async def start(self) -> None:
        """Start the browser and create a new page.

        Uses a persistent browser context with anti-detection measures
        to avoid Google's "browser not secure" error.

        Raises:
            BrowserError: If the browser fails to launch.
        """
        try:
            self._playwright = await async_playwright().start()

            # Determine the user data directory for persistent profile
            if self._user_data_dir is None:
                # Use session_path's parent or a default directory
                if self._session_path:
                    self._user_data_dir = self._session_path.parent / "browser_profile"
                else:
                    self._user_data_dir = Path("sessions/browser_profile")
                self._owns_user_data_dir = True

            self._user_data_dir.mkdir(parents=True, exist_ok=True)

            # Build launch options
            launch_args = list(STEALTH_ARGS)

            # Try to use system Chrome first (avoids Google's automation detection)
            chrome_path = None
            if self._use_system_chrome:
                chrome_path = _find_chrome_path()
                if chrome_path:
                    logger.info("Using system Chrome at %s", chrome_path)
                else:
                    logger.info("System Chrome not found, falling back to Playwright Chromium")

            # Launch persistent context — this is key for avoiding detection
            # Persistent contexts use a real profile directory like a normal browser
            if chrome_path:
                self._context = await self._playwright.chromium.launch_persistent_context(
                    user_data_dir=str(self._user_data_dir),
                    executable_path=chrome_path,
                    headless=self._headless,
                    slow_mo=self._slow_mo,
                    args=launch_args,
                    # Set a realistic user agent
                    user_agent=(
                        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
                        "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
                    ),
                    viewport={"width": 1280, "height": 800},
                    locale="en-US",
                )
            else:
                # Fallback to Playwright's bundled Chromium
                browser_launcher = {
                    "chromium": self._playwright.chromium,
                    "firefox": self._playwright.firefox,
                    "webkit": self._playwright.webkit,
                }.get(self._browser_type)

                if browser_launcher is None:
                    raise BrowserError(
                        f"Unsupported browser type: {self._browser_type}. "
                        f"Use 'chromium', 'firefox', or 'webkit'."
                    )

                self._context = await browser_launcher.launch_persistent_context(
                    user_data_dir=str(self._user_data_dir),
                    headless=self._headless,
                    slow_mo=self._slow_mo,
                    args=launch_args if self._browser_type == "chromium" else [],
                    user_agent=(
                        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
                        "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
                    )
                    if self._browser_type == "chromium"
                    else None,
                    viewport={"width": 1280, "height": 800},
                    locale="en-US",
                )

            # Get or create a page
            if self._context.pages:
                self._page = self._context.pages[0]
            else:
                self._page = await self._context.new_page()

            # Remove navigator.webdriver flag via JavaScript
            # This is a critical anti-detection measure
            await self._page.add_init_script("""
                Object.defineProperty(navigator, 'webdriver', {
                    get: () => undefined
                });
            """)

            # Initialize auth manager
            self._auth_manager = AuthManager(self._context)

            logger.info(
                "Browser started (chrome_path=%s, headless=%s, profile=%s)",
                chrome_path or "bundled",
                self._headless,
                self._user_data_dir,
            )

        except BrowserError:
            raise
        except Exception as e:
            raise BrowserError(f"Failed to start browser: {e}") from e

    async def close(self) -> None:
        """Close the browser and save the session if a path is configured."""
        if self._context and self._session_path and self._auth_manager:
            try:
                await self._auth_manager.save_session(self._session_path)
            except Exception as e:
                logger.warning("Failed to save session: %s", e)

        if self._context:
            await self._context.close()

        if self._playwright:
            await self._playwright.stop()

        self._playwright = None
        self._context = None
        self._page = None
        self._auth_manager = None

        logger.info("Browser closed")

    async def __aenter__(self) -> GeminiClient:
        """Start the browser when entering the async context manager."""
        await self.start()
        return self

    async def __aexit__(self, *args: Any) -> None:
        """Close the browser when exiting the async context manager."""
        await self.close()

    async def login(
        self,
        session_path: str | Path | None = None,
        login_timeout: float = 120.0,
    ) -> None:
        """Authenticate with Google.

        If a valid saved session exists, it will be used automatically.
        Otherwise, a manual login will be required (headed mode only).

        Note: With persistent browser contexts, the login state is also
        preserved in the browser profile directory, so you may already
        be logged in from a previous session.

        Args:
            session_path: Override the session path set in __init__.
                If None, uses the path from __init__.
            login_timeout: Seconds to wait for manual login in headed mode.

        Raises:
            AuthenticationError: If login fails or is not possible.
            CaptchaError: If a CAPTCHA challenge is detected.
            BrowserError: If the browser hasn't been started.
        """
        if not self._auth_manager or not self._page:
            raise BrowserError("Browser not started. Call start() or use as context manager.")

        path = Path(session_path) if session_path else self._session_path
        await self._auth_manager.login(
            page=self._page,
            session_path=path,
            headless=self._headless,
            login_timeout=login_timeout,
        )

    async def login_from_browser(
        self,
        browser_name: str = "chrome",
        session_path: str | Path | None = None,
    ) -> None:
        """Authenticate by extracting cookies from your regular browser.

        This lets you log in using your existing browser session — no need
        to sign in through the Playwright window. It reads cookies from your
        installed browser (Chrome, Firefox, etc.) and injects them into the
        Playwright context.

        Requires the optional ``browser-cookie3`` package::

            pip install gemini-webui[cookies]

        Make sure you've logged into gemini.google.com in your browser first.

        Args:
            browser_name: Which browser to extract cookies from.
                Options: "chrome", "chromium", "firefox", "opera", "edge".
                Defaults to "chrome".
            session_path: Override the session path set in __init__.
                If None, uses the path from __init__.

        Raises:
            AuthenticationError: If cookie extraction fails or login is not detected.
            ImportError: If browser-cookie3 is not installed.
            BrowserError: If the browser hasn't been started.
        """
        if not self._auth_manager or not self._page:
            raise BrowserError("Browser not started. Call start() or use as context manager.")

        path = Path(session_path) if session_path else self._session_path
        await self._auth_manager.login_from_browser(
            page=self._page,
            browser_name=browser_name,
            session_path=path,
        )

    async def send_prompt(
        self,
        prompt: str,
        *,
        new_chat: bool = False,
    ) -> GeminiResponse:
        """Send a prompt to Gemini and wait for the response.

        Args:
            prompt: The text prompt to send.
            new_chat: If True, start a new conversation before sending.
                If False (default), continue in the current conversation.

        Returns:
            A GeminiResponse containing the model's response text.

        Raises:
            AuthenticationError: If not logged in.
            RateLimitError: If rate limiting is detected.
            ResponseTimeoutError: If the response doesn't arrive in time.
            SelectorNotFoundError: If required UI elements can't be found.
            BrowserError: If the browser hasn't been started.
        """
        if not self._auth_manager or not self._page:
            raise BrowserError("Browser not started. Call start() or use as context manager.")

        if not self._auth_manager.is_authenticated:
            raise AuthenticationError(
                "Not authenticated. Call login() before sending prompts."
            )

        page = self._page

        # Enforce request delay
        await self._enforce_request_delay()

        # Start a new chat if requested
        if new_chat:
            await self.new_chat()

        # Make sure we're on the Gemini page
        if "/app" not in page.url:
            await page.goto(GEMINI_URL, wait_until="domcontentloaded")
            # Gemini's SPA keeps making background requests (analytics, WebSocket)
            # so networkidle never triggers — use a simple delay instead
            await asyncio.sleep(3)

        # Check for rate limiting before sending
        if await check_for_rate_limit(page):
            raise RateLimitError("Rate limit detected. Wait before sending more prompts.")

        # Find and fill the prompt input
        logger.info("Sending prompt: %s", prompt[:100] + "..." if len(prompt) > 100 else prompt)

        # Try CSS selectors first with a timeout, then fall back to JS evaluation
        # (JS evaluation can pierce shadow DOM which CSS selectors cannot)
        try:
            prompt_input = await resolve_selector_first(page, PROMPT_INPUT, timeout=5000)
            await type_in_contenteditable(prompt_input, prompt)
        except SelectorNotFoundError:
            logger.debug("CSS selectors for PROMPT_INPUT failed, trying JS evaluation")
            prompt_element = await self._find_prompt_input(page)
            if prompt_element is None:
                raise SelectorNotFoundError(
                    "Could not find the prompt input element. "
                    "The Gemini UI may have changed."
                )
            # Use keyboard input for JS-found elements (handles shadow DOM reliably)
            await prompt_element.click()
            await asyncio.sleep(0.1)
            await page.keyboard.press("Control+a")
            await page.keyboard.press("Backspace")
            await page.keyboard.type(prompt, delay=30)

        # Small delay before sending (more realistic behavior)
        await asyncio.sleep(0.3)

        # Send the prompt using Enter key (most reliable for Gemini's UI)
        # Gemini sends on Enter; Shift+Enter adds a newline
        await page.keyboard.press("Enter")

        # Wait for the response to complete
        await wait_for_response_completion(page, timeout=self._timeout)

        # Extract the response text
        response_text = await self._extract_response_text(page)

        # Try to extract conversation ID from URL
        conversation_id = self._extract_conversation_id(page.url)

        self._last_request_time = asyncio.get_event_loop().time()

        return GeminiResponse(
            text=response_text,
            prompt=prompt,
            conversation_id=conversation_id,
            model=None,  # Model detection is not reliably available in the UI
            timestamp=datetime.now(),
        )

    async def new_chat(self) -> None:
        """Start a new conversation in the Gemini UI.

        Raises:
            AuthenticationError: If not logged in.
            SelectorNotFoundError: If the new chat button can't be found.
            BrowserError: If the browser hasn't been started.
        """
        if not self._auth_manager or not self._page:
            raise BrowserError("Browser not started. Call start() or use as context manager.")

        if not self._auth_manager.is_authenticated:
            raise AuthenticationError("Not authenticated. Call login() first.")

        page = self._page

        # Try clicking the new chat button
        try:
            new_chat_btn = await resolve_selector_first(page, NEW_CHAT_BUTTON)
            await new_chat_btn.click()
            # Wait for navigation to settle (networkidle unreliable on Gemini SPA)
            await asyncio.sleep(2)
            logger.info("Started new chat")
        except SelectorNotFoundError:
            # Fallback: navigate directly to the Gemini URL
            logger.info("New chat button not found, navigating to %s", GEMINI_URL)
            await page.goto(GEMINI_URL, wait_until="domcontentloaded")
            await asyncio.sleep(3)

    async def get_current_model(self) -> str:
        """Get the name of the currently selected model.

        Returns:
            The model name as a string (e.g. "Fast", "Thinking", "Pro").

        Raises:
            SelectorNotFoundError: If the model picker button can't be found.
            BrowserError: If the browser hasn't been started.
        """
        if not self._page:
            raise BrowserError("Browser not started. Call start() or use as context manager.")

        page = self._page

        # Make sure we're on the Gemini page
        if "/app" not in page.url:
            await page.goto(GEMINI_URL, wait_until="domcontentloaded")
            await asyncio.sleep(3)

        picker_btn = await resolve_selector_first(page, MODEL_PICKER_BUTTON)
        text = await picker_btn.evaluate("e => e.textContent?.trim()")
        logger.debug("Current model from picker button: %s", text)
        return text

    async def list_models(self) -> list[str]:
        """List the available model names in the Gemini UI.

        Opens the model picker dropdown, reads the available options,
        then closes the dropdown.

        Returns:
            A list of model name strings (e.g. ["Fast", "Thinking", "Pro"]).

        Raises:
            SelectorNotFoundError: If the model picker can't be found.
            BrowserError: If the browser hasn't been started.
        """
        if not self._page:
            raise BrowserError("Browser not started. Call start() or use as context manager.")

        page = self._page

        # Make sure we're on the Gemini page
        if "/app" not in page.url:
            await page.goto(GEMINI_URL, wait_until="domcontentloaded")
            await asyncio.sleep(3)

        # Open the model picker dropdown
        picker_btn = await resolve_selector_first(page, MODEL_PICKER_BUTTON)
        await picker_btn.click()
        await asyncio.sleep(0.5)

        try:
            # Wait for the menu to appear
            menu = await resolve_selector_first(page, MODEL_PICKER_MENU, timeout=3000)

            # Read all model option buttons
            options = menu.locator("button[role='menuitem']")
            count = await options.count()
            models = []
            for i in range(count):
                el = options.nth(i)
                # Extract just the model title (first text content in the button)
                title = await el.evaluate(
                    "e => e.querySelector('.mode-title')?.textContent?.trim() "
                    "|| e.textContent?.trim().split(/\\s{2,}/)[0]"
                )
                if title:
                    models.append(title)

            logger.info("Available models: %s", models)
            return models

        finally:
            # Close the dropdown by pressing Escape
            await page.keyboard.press("Escape")
            await asyncio.sleep(0.3)

    async def set_model(self, model: str) -> None:
        """Switch the Gemini model.

        Opens the model picker dropdown and selects the specified model.
        The model name is matched case-insensitively against the available
        options. You can use short names like "fast", "thinking", "pro" or
        the full display names like "Gemini 2.5 Flash".

        Uses Playwright's semantic locators (``get_by_label``, ``get_by_text``,
        ``get_by_role``) which automatically pierce shadow DOM — unlike CSS
        selectors that are blocked by shadow-root boundaries.

        Args:
            model: The model to switch to. Supported values:
                - "fast" or "flash" — Fast model (Gemini Flash)
                - "thinking" — Thinking model
                - "pro" — Pro model (Gemini Pro)

        Raises:
            AuthenticationError: If not logged in.
            SelectorNotFoundError: If the model picker or option can't be found.
            ValueError: If the model name is not recognized.
            BrowserError: If the browser hasn't been started.
        """
        import re

        if not self._auth_manager or not self._page:
            raise BrowserError("Browser not started. Call start() or use as context manager.")

        if not self._auth_manager.is_authenticated:
            raise AuthenticationError("Not authenticated. Call login() first.")

        page = self._page

        # Make sure we're on the Gemini page
        if "/app" not in page.url:
            await page.goto(GEMINI_URL, wait_until="domcontentloaded")
            await asyncio.sleep(3)

        # Normalize the model name
        model_lower = model.lower().strip()

        # Map common aliases to the data-test-id suffix
        model_key = None
        for key in MODEL_IDS:
            if key in model_lower:
                model_key = key
                break

        # Also accept "flash" as alias for "fast"
        if model_key is None and "flash" in model_lower:
            model_key = "fast"

        if model_key is None:
            available = ", ".join(MODEL_IDS.keys())
            raise ValueError(
                f"Unknown model: {model!r}. Available models: {available}. "
                f"You can also use aliases like 'flash' for 'fast'."
            )

        # ── Step 1: Open the model picker dropdown ─────────────────────
        # Playwright semantic locators (get_by_label, get_by_role, etc.)
        # automatically pierce shadow DOM, unlike CSS selectors.
        picker_clicked = False

        # Strategy 1a: Try aria-label based locators (pierces shadow DOM)
        for label_pattern in ["mode picker", "model picker", "Open mode picker"]:
            try:
                locator = page.get_by_label(label_pattern, exact=False)
                if await locator.count() > 0:
                    await locator.first.click()
                    picker_clicked = True
                    logger.debug("Opened picker via aria-label: %s", label_pattern)
                    break
            except Exception:
                continue

        # Strategy 1b: Try by role=button with name containing "Gemini"
        if not picker_clicked:
            try:
                locator = page.get_by_role("button", name=re.compile(r"Gemini", re.I))
                if await locator.count() > 0:
                    # The model picker button typically shows the current model name
                    # (e.g. "Gemini 2.5 Flash"). Click the first visible one.
                    await locator.first.click()
                    picker_clicked = True
                    logger.debug("Opened picker via role button with 'Gemini' name")
            except Exception:
                pass

        # Strategy 1c: Try CSS selectors (may not pierce shadow DOM)
        if not picker_clicked:
            try:
                picker_btn = await resolve_selector_first(page, MODEL_PICKER_BUTTON, timeout=3000)
                await picker_btn.click()
                picker_clicked = True
                logger.debug("Opened picker via CSS selector")
            except SelectorNotFoundError:
                pass

        # Strategy 1d: JS fallback with shadow DOM traversal
        if not picker_clicked:
            clicked = await page.evaluate("""() => {
                function findPicker(root) {
                    const buttons = root.querySelectorAll('button');
                    for (const btn of buttons) {
                        const label = (btn.getAttribute('aria-label') || '').toLowerCase();
                        const text = (btn.textContent || '').trim().toLowerCase();
                        const cls = (btn.className || '').toLowerCase();
                        const rect = btn.getBoundingClientRect();
                        if (rect.width > 0 && rect.height > 0) {
                            if (label.includes('mode picker') || label.includes('model picker')
                                || label.includes('open mode')) {
                                btn.click();
                                return true;
                            }
                        }
                    }
                    const allElements = root.querySelectorAll('*');
                    for (const el of allElements) {
                        if (el.shadowRoot) {
                            if (findPicker(el.shadowRoot)) return true;
                        }
                    }
                    return false;
                }
                return findPicker(document);
            }""")
            if clicked:
                picker_clicked = True
                logger.debug("Opened picker via JS shadow DOM search")

        if not picker_clicked:
            raise SelectorNotFoundError(
                "Could not find the model picker button. "
                "The Gemini UI may have changed."
            )

        # Wait for the dropdown menu to appear
        await asyncio.sleep(1.0)

        # ── Step 2: Select the model option from the dropdown ──────────
        try:
            option_clicked = False

            # Strategy 2a: Use data-test-id if available
            try:
                test_id = MODEL_IDS[model_key]
                option = page.locator(f'button[data-test-id="{test_id}"]')
                if await option.count() > 0:
                    is_selected = await option.evaluate(
                        "e => e.classList.contains('is-selected')"
                    )
                    if is_selected:
                        logger.info("Model '%s' is already selected", model_key)
                        await page.keyboard.press("Escape")
                        await asyncio.sleep(0.3)
                        return
                    await option.click()
                    option_clicked = True
                    logger.debug("Selected model via data-test-id: %s", test_id)
            except Exception:
                pass

            # Strategy 2b: Playwright semantic locators (pierces shadow DOM)
            if not option_clicked:
                # Build regex that matches the model name
                # "pro" should match "Pro" or "Gemini Pro" etc.
                model_pattern = re.compile(rf"\b{re.escape(model_key)}\b", re.I)

                # Try menuitem role with model name
                try:
                    locator = page.get_by_role("menuitem", name=model_pattern)
                    if await locator.count() > 0:
                        await locator.first.click()
                        option_clicked = True
                        logger.debug("Selected model via role menuitem: %s", model_key)
                except Exception:
                    pass

                # Try option role with model name
                if not option_clicked:
                    try:
                        locator = page.get_by_role("option", name=model_pattern)
                        if await locator.count() > 0:
                            await locator.first.click()
                            option_clicked = True
                            logger.debug("Selected model via role option: %s", model_key)
                    except Exception:
                        pass

                # Try get_by_text for the model name (within a menu context)
                if not option_clicked:
                    try:
                        locator = page.get_by_text(model_pattern, exact=False)
                        if await locator.count() > 0:
                            await locator.first.click()
                            option_clicked = True
                            logger.debug("Selected model via get_by_text: %s", model_key)
                    except Exception:
                        pass

            # Strategy 2c: CSS selector text-based matching
            if not option_clicked:
                try:
                    options = page.locator("button[role='menuitem']")
                    count = await options.count()
                    for i in range(count):
                        el = options.nth(i)
                        title = await el.evaluate(
                            "e => e.querySelector('.mode-title')?.textContent?.trim() "
                            "|| e.textContent?.trim().split(/\\s{2,}/)[0]"
                        )
                        if title and title.lower() == model_key:
                            await el.click()
                            option_clicked = True
                            logger.debug("Selected model via CSS text match: %s", model_key)
                            break
                except Exception:
                    pass

            # Strategy 2d: JS fallback with shadow DOM traversal
            if not option_clicked:
                clicked = await page.evaluate("""(modelKey) => {
                    function findOption(root) {
                        // Look for menu items containing the model name
                        const items = root.querySelectorAll(
                            'button[role="menuitem"], button[role="option"], [role="menu"] button, li button'
                        );
                        for (const item of items) {
                            const text = (item.textContent || '').trim().toLowerCase();
                            const testId = item.getAttribute('data-test-id') || '';
                            const rect = item.getBoundingClientRect();
                            // Must be visible and contain the model key as a whole word
                            if (rect.width > 0 && rect.height > 0
                                && (text.includes(modelKey) || testId.includes(modelKey))) {
                                // Avoid matching the prompt input area
                                if (!text.includes('enter a prompt')) {
                                    item.click();
                                    return true;
                                }
                            }
                        }
                        const allElements = root.querySelectorAll('*');
                        for (const el of allElements) {
                            if (el.shadowRoot) {
                                if (findOption(el.shadowRoot)) return true;
                            }
                        }
                        return false;
                    }
                    return findOption(document);
                }""", model_key)

                if clicked:
                    option_clicked = True
                    logger.debug("Selected model via JS shadow DOM search: %s", model_key)

            if not option_clicked:
                raise SelectorNotFoundError(
                    f"Model option '{model}' not found in the dropdown. "
                    f"Available models may differ for your account."
                )

            await asyncio.sleep(1)
            logger.info("Switched to model: %s", model_key)

        except SelectorNotFoundError:
            # Close the dropdown if something went wrong
            await page.keyboard.press("Escape")
            raise

    async def _find_prompt_input(self, page: Page) -> ElementHandle | None:
        """Find the prompt input element using JS evaluation (pierces shadow DOM).

        CSS selectors cannot pierce shadow DOM boundaries, which is why
        ``resolve_selector_first`` may fail on Gemini's web-component-based UI.
        This method uses ``page.evaluate_handle`` to search the full DOM tree
        including shadow roots.

        Args:
            page: The Playwright Page to search on.

        Returns:
            An ElementHandle for the prompt input, or None if not found.
        """
        js_code = """() => {
            // Recursive search through document and shadow roots
            function findInShadowRoots(root) {
                // 1. Look for contenteditable elements (Gemini's rich-textarea)
                const contenteditables = root.querySelectorAll(
                    '[contenteditable="true"], [contenteditable=""]'
                );
                for (const el of contenteditables) {
                    // Make sure it's visible and looks like a prompt input
                    const rect = el.getBoundingClientRect();
                    if (rect.width > 0 && rect.height > 0) {
                        // Prefer elements inside rich-textarea or with aria-label
                        const parent = el.closest('rich-textarea');
                        const ariaLabel = el.getAttribute('aria-label') || '';
                        const placeholder = el.getAttribute('data-placeholder')
                            || el.getAttribute('placeholder') || '';
                        if (parent || ariaLabel.toLowerCase().includes('prompt')
                            || placeholder.toLowerCase().includes('prompt')) {
                            return el;
                        }
                    }
                }

                // 2. If no preferred match, return first visible contenteditable
                for (const el of contenteditables) {
                    const rect = el.getBoundingClientRect();
                    if (rect.width > 0 && rect.height > 0) {
                        return el;
                    }
                }

                // 3. Look for textarea elements
                const textareas = root.querySelectorAll('textarea');
                for (const el of textareas) {
                    const rect = el.getBoundingClientRect();
                    if (rect.width > 0 && rect.height > 0) {
                        return el;
                    }
                }

                // 4. Recurse into shadow roots
                const allElements = root.querySelectorAll('*');
                for (const el of allElements) {
                    if (el.shadowRoot) {
                        const found = findInShadowRoots(el.shadowRoot);
                        if (found) return found;
                    }
                }

                return null;
            }

            return findInShadowRoots(document);
        }"""

        try:
            handle = await page.evaluate_handle(js_code)
            # evaluate_handle returns a JSHandle; as_element() converts to
            # ElementHandle (or None if the JS value was null/undefined)
            element = handle.as_element()
            return element  # None if JS returned null
        except Exception as e:
            logger.debug("JS prompt-input search failed: %s", e)
            return None

    async def _extract_response_text_js(self, page: Page) -> str | None:
        """Extract response text using JS evaluation (pierces shadow DOM).

        CSS selectors cannot pierce shadow DOM boundaries, so this method
        uses ``page.evaluate`` to search the full DOM tree including shadow
        roots for the model's response text.

        Args:
            page: The Playwright Page to extract from.

        Returns:
            The response text as a string, or None if not found.
        """
        js_code = """() => {
            function findInShadowRoots(root) {
                // 1. Look for model-response elements
                const responses = root.querySelectorAll('model-response');
                if (responses.length > 0) {
                    const last = responses[responses.length - 1];
                    // Try to find markdown or message-content inside
                    const markdown = last.querySelector('.markdown');
                    if (markdown) return markdown.textContent;
                    const content = last.querySelector('message-content');
                    if (content) return content.textContent;
                    return last.textContent;
                }

                // 2. Look for any element with data-response-role="model"
                const modelEls = root.querySelectorAll('[data-response-role="model"]');
                if (modelEls.length > 0) {
                    return modelEls[modelEls.length - 1].textContent;
                }

                // 3. Recurse into shadow roots
                const allElements = root.querySelectorAll('*');
                for (const el of allElements) {
                    if (el.shadowRoot) {
                        const found = findInShadowRoots(el.shadowRoot);
                        if (found) return found;
                    }
                }

                return null;
            }

            return findInShadowRoots(document);
        }"""

        try:
            text = await page.evaluate(js_code)
            return text
        except Exception as e:
            logger.debug("JS response-text extraction failed: %s", e)
            return None

    async def _extract_response_text(self, page: Page) -> str:
        """Extract the text of the latest model response from the page.

        Args:
            page: The Playwright Page to extract from.

        Returns:
            The response text as a string.

        Raises:
            SelectorNotFoundError: If the response element can't be found.
        """
        from .selectors import LAST_RESPONSE_TURN, RESPONSE_TEXT

        # Try to get text from the last response turn
        try:
            # First try the combined selector for last response text
            last_turn_selectors = [
                "model-response:last-of-type message-content .markdown",
                "model-response:last-of-type .markdown",
                "model-response:last-of-type message-content",
            ]

            for sel in last_turn_selectors:
                try:
                    locator = page.locator(sel)
                    if await locator.count() > 0:
                        text = await locator.first.inner_text()
                        if text.strip():
                            return text.strip()
                except Exception:
                    continue

            # Fallback: try the selector dictionaries
            try:
                response_locator = await resolve_selector_first(page, LAST_RESPONSE_TURN)
                text = await response_locator.inner_text()
                if text.strip():
                    return text.strip()
            except Exception:
                pass

            try:
                text_locator = await resolve_selector_first(page, RESPONSE_TEXT)
                text = await text_locator.inner_text()
                if text.strip():
                    return text.strip()
            except Exception:
                pass

            # JS-based fallback: pierce shadow DOM to find response text
            logger.debug("CSS selectors for response text failed, trying JS evaluation")
            js_text = await self._extract_response_text_js(page)
            if js_text and js_text.strip():
                return js_text.strip()

            raise SelectorNotFoundError(
                "Could not find the response text on the page. "
                "The Gemini UI may have changed."
            )

        except SelectorNotFoundError:
            raise
        except Exception as e:
            raise SelectorNotFoundError(f"Failed to extract response text: {e}") from e

    @staticmethod
    def _extract_conversation_id(url: str) -> str | None:
        """Extract the conversation ID from the page URL.

        Gemini URLs look like:
        https://gemini.google.com/app/CONVERSATION_ID

        Args:
            url: The current page URL.

        Returns:
            The conversation ID string, or None if not found.
        """
        try:
            # URL format: https://gemini.google.com/app/CONVERSATION_ID
            if "/app/" in url:
                parts = url.split("/app/")
                if len(parts) > 1:
                    conversation_id = parts[1].split("?")[0].split("#")[0]
                    if conversation_id:
                        return conversation_id
        except Exception:
            pass
        return None

    async def _enforce_request_delay(self) -> None:
        """Enforce the minimum delay between consecutive requests."""
        if self._last_request_time > 0:
            elapsed = asyncio.get_event_loop().time() - self._last_request_time
            if elapsed < self._request_delay:
                wait_time = self._request_delay - elapsed
                logger.debug("Rate limit delay: %.1f seconds", wait_time)
                await asyncio.sleep(wait_time)
