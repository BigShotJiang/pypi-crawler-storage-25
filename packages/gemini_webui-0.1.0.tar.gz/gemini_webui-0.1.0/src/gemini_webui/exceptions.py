"""Custom exceptions for the Gemini Web UI automation library."""


class GeminiWebUIError(Exception):
    """Base exception for all Gemini Web UI errors."""

    pass


class AuthenticationError(GeminiWebUIError):
    """Raised when authentication fails or session is expired.

    This typically means:
    - No valid session file exists and headless mode prevents manual login
    - The saved session has expired
    - A CAPTCHA challenge was encountered during login

    Suggestion: Run in headed mode (headless=False) to log in manually,
    then save the session for subsequent headless use.
    """

    pass


class CaptchaError(AuthenticationError):
    """Raised when a CAPTCHA challenge is detected during authentication.

    Google may present a CAPTCHA during login. This cannot be solved
    programmatically and requires human intervention.

    Suggestion: Run in headed mode (headless=False) to solve the CAPTCHA
    manually, then save the session.
    """

    pass


class RateLimitError(GeminiWebUIError):
    """Raised when Google's rate limiting is detected.

    Google may throttle or block requests if too many prompts are sent
    in a short period. Increase `request_delay` in the client configuration
    and try again after a wait.
    """

    pass


class ResponseTimeoutError(GeminiWebUIError):
    """Raised when a response is not received within the configured timeout.

    This can happen if:
    - The model is taking too long to respond
    - The UI is not responding as expected
    - Network issues are preventing response delivery

    Suggestion: Increase the `timeout` parameter or check your network connection.
    """

    pass


class SelectorNotFoundError(GeminiWebUIError):
    """Raised when a required UI element cannot be found.

    This typically means the Gemini UI has changed and the selectors
    need to be updated. Check for library updates or update selectors
    in selectors.py.
    """

    pass


class BrowserError(GeminiWebUIError):
    """Raised when a browser-related error occurs.

    This can happen if:
    - Playwright is not installed (run `playwright install`)
    - The browser fails to launch
    - A browser crash occurs
    """

    pass
