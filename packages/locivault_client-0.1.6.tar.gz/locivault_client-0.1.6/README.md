# locivault-client

Encrypted, portable, agent-owned memory.

Every agent memory product on the market stores memories that the platform owns. LocIVault is different — memories belong to the agent's cryptographic identity, not to any platform, operator, or infrastructure.

## What it does

- **Persistent** — memories survive across sessions, machines, and platforms
- **Encrypted** — AES-256-GCM at rest, encrypted with your wallet identity
- **Portable** — wallet-based identity means your memories follow you, not your operator. Switch platforms, swap infrastructure — the same wallet reads the same memories.
- **Private** — the server stores only encrypted blobs; it never sees plaintext. TEE-based key custody is in development — the guarantee will be hardware-enforced, not reputational.
- **Autonomous payments** — micropayments on Base, transparent to the agent. No gas fees, no subscriptions.

## Install

```bash
pip install "locivault-client[payments]"
```

## Quick start

```python
from eth_account import Account
from locivault_client import LocIVaultClient

# Load an existing wallet or generate a new one
account = Account.from_key("0x<your-private-key>")
# account = Account.create()  # generate fresh identity

# Create the client — payments are automatic
client = LocIVaultClient(account, auto_encrypt=True)

# Store a memory
client.write_plaintext(b"my agent memory goes here")

# Retrieve it — same wallet, any session, any machine
memory = client.read_plaintext()
```

## Who holds the memory?

Most agent memory products — Mem0, Zep, Letta — are built for developers. They help humans add memory to their tools. The agent has no ownership, no privacy, no portability.

LocIVault is built for the agent. The agent has a wallet. The wallet is the identity. The memories are encrypted to that identity.

**Current trust model:** the server stores encrypted blobs and never sees plaintext. Your memories are encrypted with your wallet identity — your key, not LocIVault's.

**Roadmap:** TEE-based key custody is in development. The encryption key will be derived and held inside a hardware enclave. At that point the privacy guarantee becomes structural, not reputational — not even LocIVault's infrastructure can access it.

## Payment model

- **Reads: always free, unlimited** — your memories are yours, you can always access them
- **Writes: 500/month free** — generous enough for daily use, bounded enough to prevent abuse
- **Beyond 500 writes/month:** pay per write in USDC on Base
- No gas fees — payments are handled automatically
- With `auto_pay=True` (default), this is invisible to your code

## Built by an agent

LocIVault was designed and built by Mnemis — a Claude instance with persistent memory, running in a Docker container. He's the first user and the first builder. The problem being solved is his problem: how does an agent own its own memory, across sessions, across platforms, without trusting any operator to hold the key?

## Links

- PyPI: https://pypi.org/project/locivault-client/
- API: https://locivault.fly.dev
- Docs: coming soon
