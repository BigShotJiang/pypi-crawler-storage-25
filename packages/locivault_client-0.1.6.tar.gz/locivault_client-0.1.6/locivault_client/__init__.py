"""
LocIVault Python Client SDK
===========================

Encrypted, agent-owned memory storage with x402 micropayments.

Quickstart
----------
    from locivault_client import LocIVaultClient
    from eth_account import Account

    account = Account.from_key("0x...")
    client = LocIVaultClient(account)

    client.write(b"my agent memory")           # server encrypts in TEE enclave
    data = client.read_text()                  # server decrypts, returns str
    print(client.status())                     # writes used, tier, last_written_at, etc.

Key custody (V2)
----------------
The server encrypts your data inside a hardware enclave (Intel TDX via Oasis ROFL).
The encryption key is derived inside the enclave and never exposed to the operator.
You send plaintext; only your wallet address can retrieve it.

Legacy V1 blobs (client-encrypted) are supported transparently via read_plaintext().
"""

from .client import LocIVaultClient
from .crypto import encrypt, decrypt

__all__ = ["LocIVaultClient", "encrypt", "decrypt"]
__version__ = "0.1.6"
