"""Tests for super-admin API routes."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest
from httpx import ASGITransport, AsyncClient

from canon.admin.middleware import require_super_admin
from canon.auth.models import CurrentUser
from canon.auth.permissions import Permission
from canon.main import app
from canon.settings import Settings


def _super_admin_user() -> CurrentUser:
    return CurrentUser(
        sub="admin-1",
        email="admin@canonhq.co",
        name="Admin User",
        org_login="canonhq",
        permissions=frozenset(Permission),
        auth_method="session",
    )


@pytest.fixture(autouse=True)
def _setup_app_state():
    """Attach mock stores and settings to app.state for each test."""
    user = _super_admin_user()
    app.dependency_overrides[require_super_admin] = lambda: user

    app.state.settings = Settings(deployment_mode="cloud")
    app.state.admin_store = AsyncMock()
    app.state.audit_store = AsyncMock()
    app.state.db_pool = None
    app.state.registry = None
    app.state.user_store = None
    app.state.cache = MagicMock()
    app.state.github_client = MagicMock()
    yield
    app.dependency_overrides.pop(require_super_admin, None)
    app.state.admin_store = None
    app.state.audit_store = None


@pytest.fixture
def client():
    return AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test", follow_redirects=False
    )


class TestAdminConfig:
    async def test_config_returns_cloud_features(self, client: AsyncClient):
        app.state.settings = Settings(deployment_mode="cloud")
        resp = await client.get("/api/admin/config")

        assert resp.status_code == 200
        data = resp.json()
        assert data["mode"] == "cloud"
        assert data["features"]["billing"] is True
        assert data["features"]["cross_org"] is True
        assert data["features"]["impersonation"] is True

    async def test_config_self_hosted_features_disabled(self, client: AsyncClient):
        app.state.settings = Settings(deployment_mode="self_hosted")
        resp = await client.get("/api/admin/config")

        assert resp.status_code == 200
        data = resp.json()
        assert data["mode"] == "self_hosted"
        assert data["features"]["billing"] is False
        assert data["features"]["cross_org"] is False
        assert data["features"]["impersonation"] is False

    async def test_config_requires_auth(self):
        """Without the override, require_super_admin should block the request."""
        app.dependency_overrides.pop(require_super_admin, None)
        transport = ASGITransport(app=app, raise_app_exceptions=False)
        async with AsyncClient(transport=transport, base_url="http://test") as client:
            resp = await client.get("/api/admin/config")
        # Restore override so autouse fixture teardown doesn't fail
        app.dependency_overrides[require_super_admin] = lambda: _super_admin_user()
        # 404 or 403 depending on auth state — never 200
        assert resp.status_code in (403, 404)


class TestAdminDashboard:
    async def test_dashboard_returns_kpis_and_health(self, client: AsyncClient):
        app.state.admin_store.get_kpis = AsyncMock(
            return_value={
                "org_count": 5,
                "user_count": 25,
                "spec_count": 50,
                "avg_coverage_pct": 60.0,
            }
        )
        app.state.admin_store.get_health_summary = AsyncMock(
            return_value=[{"name": "indexing", "healthy": True, "detail": ""}]
        )
        app.state.audit_store.list = AsyncMock(return_value=[])

        resp = await client.get("/api/admin/dashboard")

        assert resp.status_code == 200
        data = resp.json()
        assert "kpis" in data
        assert "health" in data
        assert data["kpis"]["org_count"] == 5
        assert data["kpis"]["user_count"] == 25
        assert len(data["health"]) == 1
        assert data["health"][0]["name"] == "indexing"

    async def test_dashboard_returns_empty_when_no_stores(self, client: AsyncClient):
        app.state.admin_store = None
        app.state.audit_store = None

        resp = await client.get("/api/admin/dashboard")

        assert resp.status_code == 200
        data = resp.json()
        assert data["kpis"]["org_count"] == 0
        assert data["health"] == []


class TestAdminOrgs:
    async def test_list_returns_orgs(self, client: AsyncClient):
        app.state.admin_store.list_orgs = AsyncMock(
            return_value=[
                {
                    "login": "acme",
                    "installation_id": "1",
                    "user_count": 3,
                    "created_at": None,
                }
            ]
        )

        resp = await client.get("/api/admin/orgs")

        assert resp.status_code == 200
        data = resp.json()
        assert len(data) == 1
        assert data[0]["login"] == "acme"

    async def test_list_returns_empty_when_no_store(self, client: AsyncClient):
        app.state.admin_store = None

        resp = await client.get("/api/admin/orgs")

        assert resp.status_code == 200
        assert resp.json() == []

    async def test_get_org_returns_detail(self, client: AsyncClient):
        app.state.admin_store.get_org = AsyncMock(
            return_value={
                "login": "acme",
                "installation_id": "42",
                "user_count": 5,
                "created_at": None,
            }
        )

        resp = await client.get("/api/admin/orgs/acme")

        assert resp.status_code == 200
        assert resp.json()["login"] == "acme"

    async def test_get_org_returns_404_when_not_found(self, client: AsyncClient):
        app.state.admin_store.get_org = AsyncMock(return_value=None)

        resp = await client.get("/api/admin/orgs/nonexistent")

        assert resp.status_code == 404


class TestAdminUsers:
    async def test_list_returns_users(self, client: AsyncClient):
        app.state.admin_store.list_users = AsyncMock(
            return_value=[
                {
                    "id": 1,
                    "login": "alice",
                    "email": "alice@example.com",
                    "role": "editor",
                    "org_login": "acme",
                    "created_at": None,
                }
            ]
        )

        resp = await client.get("/api/admin/users")

        assert resp.status_code == 200
        data = resp.json()
        assert len(data) == 1
        assert data[0]["login"] == "alice"

    async def test_role_change_emits_audit_event(self, client: AsyncClient):
        existing_user = {
            "id": 1,
            "login": "alice",
            "email": "alice@example.com",
            "role": "editor",
            "org_login": "acme",
            "created_at": None,
        }
        updated_user = {**existing_user, "role": "admin"}
        app.state.admin_store.get_user = AsyncMock(return_value=existing_user)
        app.state.admin_store.update_user_role = AsyncMock(return_value=updated_user)
        app.state.audit_store.log = AsyncMock()

        resp = await client.patch("/api/admin/users/1", json={"role": "admin"})

        assert resp.status_code == 200
        assert resp.json()["role"] == "admin"
        app.state.audit_store.log.assert_awaited_once()
        call_kwargs = app.state.audit_store.log.call_args.kwargs
        assert call_kwargs["event_type"] == "user.role_changed"
        assert call_kwargs["detail"]["new_role"] == "admin"
        assert call_kwargs["detail"]["old_role"] == "editor"

    async def test_role_change_returns_404_when_user_missing(self, client: AsyncClient):
        app.state.admin_store.get_user = AsyncMock(return_value=None)

        resp = await client.patch("/api/admin/users/999", json={"role": "admin"})

        assert resp.status_code == 404


class TestAdminAudit:
    async def test_list_returns_events(self, client: AsyncClient):
        app.state.audit_store.list = AsyncMock(
            return_value=[
                {
                    "id": "uuid-1",
                    "event_type": "user.role_changed",
                    "resource_type": "user",
                    "resource_id": "1",
                    "actor_id": None,
                    "org": "acme",
                    "detail": None,
                    "ip_address": None,
                    "created_at": None,
                }
            ]
        )

        resp = await client.get("/api/admin/audit")

        assert resp.status_code == 200
        data = resp.json()
        assert len(data) == 1
        assert data[0]["event_type"] == "user.role_changed"

    async def test_list_returns_empty_when_no_store(self, client: AsyncClient):
        app.state.audit_store = None

        resp = await client.get("/api/admin/audit")

        assert resp.status_code == 200
        assert resp.json() == []


class TestAdminBilling:
    async def test_billing_returns_200_on_cloud(self, client: AsyncClient):
        app.state.settings = Settings(deployment_mode="cloud")

        resp = await client.get("/api/admin/billing")

        assert resp.status_code == 200

    async def test_billing_returns_404_on_self_hosted(self, client: AsyncClient):
        app.state.settings = Settings(deployment_mode="self_hosted")

        resp = await client.get("/api/admin/billing")

        assert resp.status_code == 404

    async def test_billing_org_returns_404_on_self_hosted(self, client: AsyncClient):
        app.state.settings = Settings(deployment_mode="self_hosted")

        resp = await client.get("/api/admin/billing/acme")

        assert resp.status_code == 404


class TestAdminOrgReindex:
    async def test_reindex_returns_ok(self, client: AsyncClient):
        app.state.audit_store.log = AsyncMock()

        resp = await client.post("/api/admin/orgs/acme/reindex")

        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "ok" or data.get("org") == "acme"

    async def test_reindex_emits_audit_event(self, client: AsyncClient):
        app.state.audit_store.log = AsyncMock()

        await client.post("/api/admin/orgs/acme/reindex")

        app.state.audit_store.log.assert_awaited_once()
        call_kwargs = app.state.audit_store.log.call_args.kwargs
        assert call_kwargs["event_type"] == "org.reindex_triggered"
        assert call_kwargs["org"] == "acme"


class TestAdminUserDetail:
    async def test_get_user_returns_detail(self, client: AsyncClient):
        app.state.admin_store.get_user = AsyncMock(
            return_value={
                "id": 1,
                "login": "alice",
                "email": "alice@example.com",
                "role": "editor",
                "org_login": "acme",
                "created_at": None,
            }
        )

        resp = await client.get("/api/admin/users/1")

        assert resp.status_code == 200
        assert resp.json()["login"] == "alice"

    async def test_get_user_returns_404(self, client: AsyncClient):
        app.state.admin_store.get_user = AsyncMock(return_value=None)

        resp = await client.get("/api/admin/users/999")

        assert resp.status_code == 404

    async def test_get_user_returns_503_when_no_store(self, client: AsyncClient):
        app.state.admin_store = None

        resp = await client.get("/api/admin/users/1")

        assert resp.status_code == 503


class TestAdminHealth:
    async def test_health_returns_subsystems(self, client: AsyncClient):
        app.state.admin_store.get_health_summary = AsyncMock(
            return_value=[{"name": "indexing", "healthy": True, "detail": "OK"}]
        )

        resp = await client.get("/api/admin/health")

        assert resp.status_code == 200
        data = resp.json()
        assert len(data) == 1
        assert data[0]["name"] == "indexing"

    async def test_health_returns_empty_when_no_store(self, client: AsyncClient):
        app.state.admin_store = None

        resp = await client.get("/api/admin/health")

        assert resp.status_code == 200
        assert resp.json() == []


class TestAdminIntegrations:
    async def test_integrations_returns_list(self, client: AsyncClient):
        resp = await client.get("/api/admin/integrations")

        assert resp.status_code == 200
        assert isinstance(resp.json(), list)


class TestAdminAIOps:
    async def test_ai_returns_overview(self, client: AsyncClient):
        resp = await client.get("/api/admin/ai")

        assert resp.status_code == 200
        data = resp.json()
        assert "total_ops_today" in data or "orgs" in data

    async def test_ai_org_returns_detail(self, client: AsyncClient):
        resp = await client.get("/api/admin/ai/acme")

        assert resp.status_code == 200
        data = resp.json()
        assert data["org"] == "acme"
