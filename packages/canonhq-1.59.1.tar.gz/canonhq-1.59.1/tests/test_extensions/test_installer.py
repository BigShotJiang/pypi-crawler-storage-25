"""Tests for canon.extensions.installer."""

from __future__ import annotations

from pathlib import Path

import pytest
from pydantic import ValidationError

from canon.extensions.installer import install_extension, uninstall_extension
from canon.extensions.registry import load_registry

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _create_extension(
    base: Path,
    ext_id: str = "test-ext",
    *,
    with_skill: bool = True,
    with_command: bool = True,
    canon_version: str = ">=0.1.0",
) -> Path:
    """Create a minimal extension directory for testing."""
    ext_dir = base / ext_id
    ext_dir.mkdir(parents=True)

    # Manifest
    provides_lines = []
    if with_skill:
        skill_dir = ext_dir / "skills" / ext_id
        skill_dir.mkdir(parents=True)
        (skill_dir / "SKILL.md").write_text(f"---\nname: {ext_id}\n---\n# {ext_id}\n")
        provides_lines.append(
            f'  skills:\n    - name: "{ext_id}"\n'
            f'      file: "skills/{ext_id}/SKILL.md"\n'
            f'      description: "Test skill"'
        )
    if with_command:
        cmd_dir = ext_dir / "commands"
        cmd_dir.mkdir(parents=True)
        (cmd_dir / f"{ext_id}.md").write_text(f"# {ext_id} command\n")
        provides_lines.append(
            f'  commands:\n    - name: "{ext_id}"\n'
            f'      file: "commands/{ext_id}.md"\n'
            f'      description: "Test command"'
        )

    provides_block = "\n".join(provides_lines) if provides_lines else "  skills: []"

    manifest = f"""\
schema_version: "1"
extension:
  id: "{ext_id}"
  name: "Test Extension"
  version: "0.1.0"
requires:
  canon_version: "{canon_version}"
provides:
{provides_block}
"""
    (ext_dir / "canon-extension.yml").write_text(manifest)
    return ext_dir


# ---------------------------------------------------------------------------
# Install tests
# ---------------------------------------------------------------------------


class TestInstallExtension:
    def test_install_skill_extension(self, tmp_path):
        ext_dir = _create_extension(tmp_path / "source", with_command=False)
        project = tmp_path / "project"
        project.mkdir()

        result = install_extension(project, ext_dir)

        assert result.ext_id == "test-ext"
        assert result.version == "0.1.0"
        assert len(result.installed_files) == 1
        assert (project / ".canon" / "skills" / "test-ext" / "SKILL.md").exists()

    def test_install_command_extension(self, tmp_path):
        ext_dir = _create_extension(tmp_path / "source", with_skill=False)
        project = tmp_path / "project"
        project.mkdir()

        result = install_extension(project, ext_dir)

        assert len(result.installed_files) == 1
        assert (project / ".claude" / "commands" / "test-ext.md").exists()

    def test_install_both_skill_and_command(self, tmp_path):
        ext_dir = _create_extension(tmp_path / "source")
        project = tmp_path / "project"
        project.mkdir()

        result = install_extension(project, ext_dir)

        assert len(result.installed_files) == 2
        assert (project / ".canon" / "skills" / "test-ext" / "SKILL.md").exists()
        assert (project / ".claude" / "commands" / "test-ext.md").exists()

    def test_install_creates_registry(self, tmp_path):
        ext_dir = _create_extension(tmp_path / "source")
        project = tmp_path / "project"
        project.mkdir()

        install_extension(project, ext_dir)

        registry = load_registry(project)
        assert "test-ext" in registry.extensions
        entry = registry.extensions["test-ext"]
        assert entry.version == "0.1.0"
        assert entry.source == "local"
        assert entry.dev_mode is False

    def test_install_dev_mode_symlinks(self, tmp_path):
        ext_dir = _create_extension(tmp_path / "source")
        project = tmp_path / "project"
        project.mkdir()

        install_extension(project, ext_dir, dev_mode=True)

        # Extension dir should be a symlink
        ext_installed = project / ".canon" / "extensions" / "test-ext"
        assert ext_installed.is_symlink()

        # Skill file should be a symlink
        skill_file = project / ".canon" / "skills" / "test-ext" / "SKILL.md"
        assert skill_file.is_symlink()

        # Command file should be a symlink
        cmd_file = project / ".claude" / "commands" / "test-ext.md"
        assert cmd_file.is_symlink()

        # Registry should show dev mode
        registry = load_registry(project)
        assert registry.extensions["test-ext"].dev_mode is True
        assert registry.extensions["test-ext"].source == "dev"

    def test_install_already_installed_raises(self, tmp_path):
        ext_dir = _create_extension(tmp_path / "source")
        project = tmp_path / "project"
        project.mkdir()

        install_extension(project, ext_dir)
        with pytest.raises(ValueError, match="already installed"):
            install_extension(project, ext_dir)

    def test_install_invalid_manifest_raises(self, tmp_path):
        ext_dir = tmp_path / "bad-ext"
        ext_dir.mkdir()
        (ext_dir / "canon-extension.yml").write_text("not valid\n")
        project = tmp_path / "project"
        project.mkdir()

        with pytest.raises((ValueError, ValidationError)):
            install_extension(project, ext_dir)

    def test_install_missing_file_raises(self, tmp_path):
        ext_dir = tmp_path / "source" / "bad-ext"
        ext_dir.mkdir(parents=True)
        manifest = """\
schema_version: "1"
extension:
  id: "bad-ext"
  name: "Bad Extension"
  version: "0.1.0"
provides:
  skills:
    - name: "missing"
      file: "skills/missing/SKILL.md"
"""
        (ext_dir / "canon-extension.yml").write_text(manifest)
        project = tmp_path / "project"
        project.mkdir()

        with pytest.raises(ValueError, match="invalid file references"):
            install_extension(project, ext_dir)

    def test_install_incompatible_version_raises(self, tmp_path):
        ext_dir = _create_extension(tmp_path / "source", canon_version=">=999.0.0")
        project = tmp_path / "project"
        project.mkdir()

        with pytest.raises(ValueError, match="requires canon"):
            install_extension(project, ext_dir)


# ---------------------------------------------------------------------------
# Uninstall tests
# ---------------------------------------------------------------------------


class TestUninstallExtension:
    def test_uninstall_removes_files(self, tmp_path):
        ext_dir = _create_extension(tmp_path / "source")
        project = tmp_path / "project"
        project.mkdir()

        install_extension(project, ext_dir)

        # Verify installed
        assert (project / ".canon" / "skills" / "test-ext" / "SKILL.md").exists()
        assert (project / ".claude" / "commands" / "test-ext.md").exists()

        # Uninstall
        removed = uninstall_extension(project, "test-ext")

        assert len(removed) == 2
        assert not (project / ".canon" / "skills" / "test-ext").exists()
        assert not (project / ".claude" / "commands" / "test-ext.md").exists()

        # Registry should be empty
        registry = load_registry(project)
        assert "test-ext" not in registry.extensions

    def test_uninstall_removes_symlinks(self, tmp_path):
        ext_dir = _create_extension(tmp_path / "source")
        project = tmp_path / "project"
        project.mkdir()

        install_extension(project, ext_dir, dev_mode=True)
        removed = uninstall_extension(project, "test-ext")

        assert len(removed) == 2
        assert not (project / ".canon" / "extensions" / "test-ext").exists()

    def test_uninstall_not_installed_raises(self, tmp_path):
        project = tmp_path / "project"
        project.mkdir()

        with pytest.raises(KeyError, match="not installed"):
            uninstall_extension(project, "nonexistent")


# ---------------------------------------------------------------------------
# Dev mode edit propagation
# ---------------------------------------------------------------------------


class TestDevModeEdits:
    def test_skill_edit_propagates(self, tmp_path):
        ext_dir = _create_extension(tmp_path / "source", with_command=False)
        project = tmp_path / "project"
        project.mkdir()

        install_extension(project, ext_dir, dev_mode=True)

        # Edit source file
        source_skill = ext_dir / "skills" / "test-ext" / "SKILL.md"
        source_skill.write_text("# UPDATED CONTENT\n")

        # Read through installed path
        installed_skill = project / ".canon" / "skills" / "test-ext" / "SKILL.md"
        assert installed_skill.read_text() == "# UPDATED CONTENT\n"

    def test_command_edit_propagates(self, tmp_path):
        ext_dir = _create_extension(tmp_path / "source", with_skill=False)
        project = tmp_path / "project"
        project.mkdir()

        install_extension(project, ext_dir, dev_mode=True)

        # Edit source file
        source_cmd = ext_dir / "commands" / "test-ext.md"
        source_cmd.write_text("# UPDATED COMMAND\n")

        # Read through installed path
        installed_cmd = project / ".claude" / "commands" / "test-ext.md"
        assert installed_cmd.read_text() == "# UPDATED COMMAND\n"
