"""Tests for canon.extensions.registry."""

from __future__ import annotations

import pytest

from canon.extensions.registry import (
    InstalledExtension,
    Registry,
    add_extension,
    get_extension,
    load_registry,
    remove_extension,
    save_registry,
)


def _make_entry(**overrides) -> InstalledExtension:
    defaults = {
        "version": "1.0.0",
        "installed_at": "2026-04-15T10:00:00+00:00",
        "source": "local",
        "dev_mode": False,
        "enabled": True,
        "source_path": "/tmp/test-ext",
        "installed_files": [".canon/skills/test-ext/SKILL.md"],
    }
    defaults.update(overrides)
    return InstalledExtension(**defaults)


class TestRegistryLoadSave:
    def test_load_missing_returns_empty(self, tmp_path):
        reg = load_registry(tmp_path)
        assert reg.extensions == {}
        assert reg.schema_version == "1"

    def test_save_and_load_roundtrip(self, tmp_path):
        reg = Registry()
        entry = _make_entry()
        reg.extensions["test-ext"] = entry

        save_registry(tmp_path, reg)
        loaded = load_registry(tmp_path)

        assert "test-ext" in loaded.extensions
        loaded_entry = loaded.extensions["test-ext"]
        assert loaded_entry.version == "1.0.0"
        assert loaded_entry.dev_mode is False
        assert loaded_entry.installed_files == [".canon/skills/test-ext/SKILL.md"]

    def test_save_creates_parent_dirs(self, tmp_path):
        reg = Registry()
        save_registry(tmp_path, reg)
        assert (tmp_path / ".canon" / "extensions" / ".registry.json").exists()


class TestRegistryCrud:
    def test_add_extension(self):
        reg = Registry()
        entry = _make_entry()
        add_extension(reg, "test-ext", entry)
        assert "test-ext" in reg.extensions

    def test_add_duplicate_raises(self):
        reg = Registry()
        entry = _make_entry()
        add_extension(reg, "test-ext", entry)
        with pytest.raises(ValueError, match="already installed"):
            add_extension(reg, "test-ext", entry)

    def test_remove_extension(self):
        reg = Registry()
        entry = _make_entry()
        reg.extensions["test-ext"] = entry

        removed = remove_extension(reg, "test-ext")
        assert removed.version == "1.0.0"
        assert "test-ext" not in reg.extensions

    def test_remove_missing_raises(self):
        reg = Registry()
        with pytest.raises(KeyError, match="not installed"):
            remove_extension(reg, "nonexistent")

    def test_get_extension_found(self):
        reg = Registry()
        entry = _make_entry()
        reg.extensions["test-ext"] = entry

        result = get_extension(reg, "test-ext")
        assert result is not None
        assert result.version == "1.0.0"

    def test_get_extension_not_found(self):
        reg = Registry()
        assert get_extension(reg, "nonexistent") is None
