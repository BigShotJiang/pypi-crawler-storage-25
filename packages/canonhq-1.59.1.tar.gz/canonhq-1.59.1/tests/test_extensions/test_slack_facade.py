"""Tests for the Slack facade bridge (src/canon/slack/__init__.py)."""

from __future__ import annotations

import importlib
import sys


class TestSlackFacadeAvailable:
    """When canon_slack is importable (extension installed), facade exports real objects."""

    def test_slack_available_is_true(self):
        from canon.slack import SLACK_AVAILABLE

        assert SLACK_AVAILABLE is True

    def test_create_slack_app_is_callable(self):
        from canon.slack import create_slack_app

        assert callable(create_slack_app)

    def test_identity_store_is_class(self):
        from canon.slack import IdentityStore

        assert IdentityStore is not None
        assert isinstance(IdentityStore, type)

    def test_spec_loader_is_class(self):
        from canon.slack import SpecLoader

        assert SpecLoader is not None
        assert isinstance(SpecLoader, type)

    def test_notification_dispatcher_is_class(self):
        from canon.slack import NotificationDispatcher

        assert NotificationDispatcher is not None
        assert isinstance(NotificationDispatcher, type)

    def test_invalidate_spec_cache_is_callable(self):
        from canon.slack import invalidate_spec_cache

        assert callable(invalidate_spec_cache)

    def test_build_digest_blocks_is_callable(self):
        from canon.slack import build_digest_blocks

        assert callable(build_digest_blocks)


class TestSlackFacadeUnavailable:
    """When canon_slack is NOT importable, facade provides no-op stubs."""

    def test_stubs_when_extension_missing(self):
        # Temporarily hide canon_slack from imports
        saved_modules = {}
        to_remove = [k for k in sys.modules if k == "canon_slack" or k.startswith("canon_slack.")]
        for k in to_remove:
            saved_modules[k] = sys.modules.pop(k)
        # Also hide the canon.slack facade so it re-imports
        if "canon.slack" in sys.modules:
            saved_modules["canon.slack"] = sys.modules.pop("canon.slack")

        # Block canon_slack from being imported
        import builtins

        _real_import = builtins.__import__

        def _blocking_import(name, *args, **kwargs):
            if name == "canon_slack" or name.startswith("canon_slack."):
                raise ImportError("blocked for test")
            return _real_import(name, *args, **kwargs)

        builtins.__import__ = _blocking_import
        try:
            # Re-import the facade
            import canon.slack as slack_mod

            importlib.reload(slack_mod)

            assert slack_mod.SLACK_AVAILABLE is False
            # Function stubs should be callable no-ops
            assert callable(slack_mod.create_slack_app)
            assert slack_mod.create_slack_app() is None
            assert callable(slack_mod.invalidate_spec_cache)
            assert slack_mod.invalidate_spec_cache("a", "b") is None
            assert callable(slack_mod.build_digest_blocks)
            assert slack_mod.build_digest_blocks() == []
            # Class stubs should be None
            assert slack_mod.IdentityStore is None
            assert slack_mod.NotificationConfig is None
            assert slack_mod.NotificationDispatcher is None
            assert slack_mod.SpecLoader is None
        finally:
            builtins.__import__ = _real_import
            # Restore original modules
            sys.modules.update(saved_modules)
            # Reload facade to restore real state
            importlib.reload(sys.modules["canon.slack"])
