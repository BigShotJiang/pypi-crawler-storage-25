"""Tests for canon.extensions.template."""

from __future__ import annotations

import pytest

from canon.extensions.manifest import load_manifest, validate_file_references
from canon.extensions.template import scaffold_extension


class TestScaffoldExtension:
    def test_creates_manifest_and_readme(self, tmp_path):
        target = tmp_path / "my-ext"
        created = scaffold_extension(target, "my-ext")
        assert "canon-extension.yml" in created
        assert "README.md" in created
        assert (target / "canon-extension.yml").exists()
        assert (target / "README.md").exists()

    def test_manifest_is_valid(self, tmp_path):
        """Scaffolded manifest should pass load_manifest validation."""
        target = tmp_path / "my-ext"
        scaffold_extension(target, "my-ext", with_skill=True, with_command=True)
        manifest = load_manifest(target)
        assert manifest.extension.id == "my-ext"
        assert manifest.extension.version == "0.1.0"

    def test_file_references_valid(self, tmp_path):
        """All file paths in scaffolded manifest should exist on disk."""
        target = tmp_path / "my-ext"
        scaffold_extension(target, "my-ext", with_skill=True, with_command=True)
        manifest = load_manifest(target)
        errors = validate_file_references(manifest, target)
        assert errors == []

    def test_with_skill(self, tmp_path):
        target = tmp_path / "my-ext"
        created = scaffold_extension(target, "my-ext", with_skill=True)
        assert "skills/my-ext/SKILL.md" in created
        assert (target / "skills" / "my-ext" / "SKILL.md").exists()
        manifest = load_manifest(target)
        assert len(manifest.provides.skills) == 1
        assert manifest.provides.skills[0].name == "my-ext"

    def test_with_command(self, tmp_path):
        target = tmp_path / "my-ext"
        created = scaffold_extension(target, "my-ext", with_command=True)
        assert "commands/my-ext.md" in created
        assert (target / "commands" / "my-ext.md").exists()
        manifest = load_manifest(target)
        assert len(manifest.provides.commands) == 1
        assert manifest.provides.commands[0].name == "my-ext"

    def test_with_hook(self, tmp_path):
        target = tmp_path / "my-ext"
        created = scaffold_extension(target, "my-ext", with_hook=True)
        assert "hooks/.gitkeep" in created
        manifest = load_manifest(target)
        assert len(manifest.provides.hooks) == 1

    def test_with_adapter(self, tmp_path):
        target = tmp_path / "my-ext"
        scaffold_extension(target, "my-ext", with_adapter=True)
        manifest = load_manifest(target)
        assert len(manifest.provides.adapters) == 1
        assert manifest.provides.adapters[0].id == "my-ext"

    def test_with_author(self, tmp_path):
        target = tmp_path / "my-ext"
        scaffold_extension(target, "my-ext", author="Test Author")
        manifest = load_manifest(target)
        assert manifest.extension.author == "Test Author"

    def test_file_exists_error(self, tmp_path):
        target = tmp_path / "my-ext"
        target.mkdir()
        with pytest.raises(FileExistsError):
            scaffold_extension(target, "my-ext")

    def test_no_components(self, tmp_path):
        """Extension with no skill/command/hook/adapter should still be valid."""
        target = tmp_path / "my-ext"
        scaffold_extension(target, "my-ext")
        manifest = load_manifest(target)
        assert manifest.provides.skills == []
        assert manifest.provides.commands == []

    def test_author_with_quotes(self, tmp_path):
        """Author containing double quotes should produce valid YAML."""
        target = tmp_path / "my-ext"
        scaffold_extension(target, "my-ext", author='John "JD" Doe')
        manifest = load_manifest(target)
        assert manifest.extension.author == 'John "JD" Doe'
