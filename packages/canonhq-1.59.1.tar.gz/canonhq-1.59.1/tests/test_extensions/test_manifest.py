"""Tests for canon.extensions.manifest."""

from __future__ import annotations

import pytest
import yaml
from pydantic import ValidationError

from canon.extensions.manifest import (
    ExtensionManifest,
    check_canon_version_compat,
    load_manifest,
    validate_file_references,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

MINIMAL_MANIFEST = """\
schema_version: "1"
extension:
  id: "test-ext"
  name: "Test Extension"
  version: "0.1.0"
"""

FULL_MANIFEST = """\
schema_version: "1"
extension:
  id: "my-ext"
  name: "My Extension"
  version: "1.0.0"
  description: "A test extension"
  author: "Test Author"
  repository: "https://github.com/test/my-ext"
  license: "MIT"
requires:
  canon_version: ">=1.0.0,<3.0.0"
provides:
  skills:
    - name: "my-skill"
      file: "skills/my-skill/SKILL.md"
      description: "A test skill"
  commands:
    - name: "my-cmd"
      file: "commands/my-cmd.md"
      description: "A test command"
  adapters:
    - id: "my-adapter"
      entry_point: "my_package:MyAdapter"
tags:
  - "test"
  - "example"
"""


# ---------------------------------------------------------------------------
# ExtensionMeta.id validation
# ---------------------------------------------------------------------------


class TestExtensionId:
    def test_valid_id(self):
        m = ExtensionManifest.model_validate(
            {"extension": {"id": "my-ext", "name": "X", "version": "1.0.0"}}
        )
        assert m.extension.id == "my-ext"

    def test_valid_id_no_hyphens(self):
        m = ExtensionManifest.model_validate(
            {"extension": {"id": "myext", "name": "X", "version": "1.0.0"}}
        )
        assert m.extension.id == "myext"

    @pytest.mark.parametrize("reserved", ["canon", "core", "builtin"])
    def test_reserved_id_rejected(self, reserved: str):
        with pytest.raises(ValidationError, match="Reserved extension ID"):
            ExtensionManifest.model_validate(
                {"extension": {"id": reserved, "name": "X", "version": "1.0.0"}}
            )

    @pytest.mark.parametrize(
        "bad_id",
        [
            "A",  # uppercase
            "my ext",  # space
            "x",  # too short (min 3 chars)
            "-bad",  # starts with hyphen
            "bad-",  # ends with hyphen
            "123bad",  # starts with digit
            "a" * 52,  # too long
        ],
    )
    def test_invalid_pattern_rejected(self, bad_id: str):
        with pytest.raises(ValidationError):
            ExtensionManifest.model_validate(
                {"extension": {"id": bad_id, "name": "X", "version": "1.0.0"}}
            )

    def test_min_length_valid(self):
        """3-char ID should be valid."""
        m = ExtensionManifest.model_validate(
            {"extension": {"id": "abc", "name": "X", "version": "1.0.0"}}
        )
        assert m.extension.id == "abc"


# ---------------------------------------------------------------------------
# Name validation (path traversal prevention)
# ---------------------------------------------------------------------------


class TestNameValidation:
    @pytest.mark.parametrize(
        "bad_name",
        [
            "../commands/evil",
            "foo/bar",
            "foo\\bar",
            "..\\evil",
        ],
    )
    def test_skill_name_rejects_traversal(self, bad_name: str):
        with pytest.raises(ValidationError):
            ExtensionManifest.model_validate(
                {
                    "extension": {"id": "test-ext", "name": "X", "version": "1.0.0"},
                    "provides": {"skills": [{"name": bad_name, "file": "skills/x/SKILL.md"}]},
                }
            )

    @pytest.mark.parametrize(
        "bad_name",
        [
            "../skills/evil",
            "foo/bar",
            "foo\\bar",
        ],
    )
    def test_command_name_rejects_traversal(self, bad_name: str):
        with pytest.raises(ValidationError):
            ExtensionManifest.model_validate(
                {
                    "extension": {"id": "test-ext", "name": "X", "version": "1.0.0"},
                    "provides": {"commands": [{"name": bad_name, "file": "commands/x.md"}]},
                }
            )

    def test_valid_names_accepted(self):
        m = ExtensionManifest.model_validate(
            {
                "extension": {"id": "test-ext", "name": "X", "version": "1.0.0"},
                "provides": {
                    "skills": [{"name": "my-skill", "file": "skills/x/SKILL.md"}],
                    "commands": [{"name": "my-cmd", "file": "commands/x.md"}],
                },
            }
        )
        assert m.provides.skills[0].name == "my-skill"
        assert m.provides.commands[0].name == "my-cmd"


# ---------------------------------------------------------------------------
# Manifest loading
# ---------------------------------------------------------------------------


class TestManifestLoading:
    def test_load_valid_minimal(self, tmp_path):
        (tmp_path / "canon-extension.yml").write_text(MINIMAL_MANIFEST)
        m = load_manifest(tmp_path)
        assert m.extension.id == "test-ext"
        assert m.extension.version == "0.1.0"
        assert m.schema_version == "1"

    def test_load_valid_full(self, tmp_path):
        (tmp_path / "canon-extension.yml").write_text(FULL_MANIFEST)
        # Create referenced files so validate_file_references would pass
        (tmp_path / "skills" / "my-skill").mkdir(parents=True)
        (tmp_path / "skills" / "my-skill" / "SKILL.md").touch()
        (tmp_path / "commands").mkdir()
        (tmp_path / "commands" / "my-cmd.md").touch()

        m = load_manifest(tmp_path)
        assert m.extension.id == "my-ext"
        assert len(m.provides.skills) == 1
        assert len(m.provides.commands) == 1
        assert len(m.provides.adapters) == 1
        assert m.tags == ["test", "example"]

    def test_missing_manifest_file(self, tmp_path):
        with pytest.raises(FileNotFoundError, match="Extension manifest not found"):
            load_manifest(tmp_path)

    def test_invalid_yaml(self, tmp_path):
        (tmp_path / "canon-extension.yml").write_text("{{invalid yaml")
        with pytest.raises((yaml.YAMLError, ValueError)):
            load_manifest(tmp_path)

    def test_missing_required_fields(self, tmp_path):
        (tmp_path / "canon-extension.yml").write_text("schema_version: '1'\n")
        with pytest.raises(ValidationError):
            load_manifest(tmp_path)


# ---------------------------------------------------------------------------
# File reference validation
# ---------------------------------------------------------------------------


class TestFileReferenceValidation:
    def test_valid_references(self, tmp_path):
        (tmp_path / "canon-extension.yml").write_text(FULL_MANIFEST)
        (tmp_path / "skills" / "my-skill").mkdir(parents=True)
        (tmp_path / "skills" / "my-skill" / "SKILL.md").touch()
        (tmp_path / "commands").mkdir()
        (tmp_path / "commands" / "my-cmd.md").touch()

        m = load_manifest(tmp_path)
        errors = validate_file_references(m, tmp_path)
        assert errors == []

    def test_missing_skill_file(self, tmp_path):
        (tmp_path / "canon-extension.yml").write_text(FULL_MANIFEST)
        # Don't create skills dir
        (tmp_path / "commands").mkdir()
        (tmp_path / "commands" / "my-cmd.md").touch()

        m = load_manifest(tmp_path)
        errors = validate_file_references(m, tmp_path)
        assert len(errors) == 1
        assert "Skill file not found" in errors[0]

    def test_missing_command_file(self, tmp_path):
        (tmp_path / "canon-extension.yml").write_text(FULL_MANIFEST)
        (tmp_path / "skills" / "my-skill").mkdir(parents=True)
        (tmp_path / "skills" / "my-skill" / "SKILL.md").touch()
        # Don't create commands dir

        m = load_manifest(tmp_path)
        errors = validate_file_references(m, tmp_path)
        assert len(errors) == 1
        assert "Command file not found" in errors[0]


# ---------------------------------------------------------------------------
# Version compatibility
# ---------------------------------------------------------------------------


class TestVersionCompatibility:
    def test_compatible_version(self):
        assert check_canon_version_compat(">=1.0.0", "1.52.3") is True

    def test_incompatible_version(self):
        assert check_canon_version_compat(">=2.0.0", "1.52.3") is False

    def test_exact_boundary(self):
        assert check_canon_version_compat(">=1.52.3", "1.52.3") is True

    def test_compatible_release_operator(self):
        """~= is valid PEP 440 (compatible release)."""
        assert check_canon_version_compat("~=1.0", "1.52.3") is True
        assert check_canon_version_compat("~=2.0", "1.52.3") is False

    def test_upper_bound(self):
        """Upper bounds should be respected."""
        assert check_canon_version_compat(">=1.0.0,<2.0.0", "1.52.3") is True
        assert check_canon_version_compat(">=0.3.0,<0.4.0", "1.0.0") is False

    def test_exclusion(self):
        assert check_canon_version_compat(">=1.0.0,!=1.52.3", "1.52.3") is False
        assert check_canon_version_compat(">=1.0.0,!=1.52.3", "1.52.4") is True

    def test_invalid_specifier_fails_closed(self):
        """Garbage specifier strings should reject (fail-closed)."""
        assert check_canon_version_compat("not a version", "1.52.3") is False

    def test_older_version(self):
        assert check_canon_version_compat(">=1.52.3", "1.0.0") is False
