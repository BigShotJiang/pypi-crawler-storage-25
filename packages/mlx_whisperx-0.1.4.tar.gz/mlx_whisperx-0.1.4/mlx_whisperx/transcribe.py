"""Public Python API for running the complete transcription pipeline."""

from typing import Optional, Sequence

import numpy as np

from ._language import normalize_language_settings
from .pipeline import MLXWhisperXPipeline, PipelineOptions


def transcribe(
    audio: str | np.ndarray,
    *,
    model: str = "mlx-community/whisper-turbo",
    task: str = "transcribe",
    language: Optional[str] = None,
    temperature: float | Sequence[float] = 0.0,
    best_of: Optional[int] = 5,
    beam_size: Optional[int] = 5,
    patience: Optional[float] = 1.0,
    length_penalty: Optional[float] = 1.0,
    suppress_tokens: str = "-1",
    suppress_numerals: bool = False,
    initial_prompt: Optional[str] = None,
    hotwords: Optional[str] = None,
    condition_on_previous_text: bool = False,
    fp16: bool = True,
    compression_ratio_threshold: Optional[float] = 2.4,
    logprob_threshold: Optional[float] = -1.0,
    no_speech_threshold: Optional[float] = 0.6,
    vad_method: str = "silero",
    vad_onset: float = 0.500,
    vad_offset: float = 0.363,
    vad_model: Optional[str] = None,
    chunk_size: int = 30,
    no_vad: bool = False,
    vad_cut_only: bool = False,
    vad_dump_path: Optional[str] = None,
    align_model: Optional[str] = None,
    no_align: bool = False,
    allow_missing_alignment_deps: bool = False,
    interpolate_method: str = "nearest",
    return_char_alignments: bool = False,
    diarize: bool = False,
    diarize_model: str = "pyannote/speaker-diarization-community-1",
    min_speakers: Optional[int] = None,
    max_speakers: Optional[int] = None,
    speaker_embeddings: bool = False,
    hf_token: Optional[str] = None,
    model_dir: Optional[str] = None,
    model_cache_only: bool = False,
    clip_timestamps: str | Sequence[float] | None = None,
    device: str = "cpu",
    verbose: bool = False,
    print_progress: bool = False,
) -> dict:
    """Transcribe audio and optionally run alignment and diarization.

    The signature mirrors the CLI option names so users can move settings between
    shell commands and Python with minimal translation. Internally, the arguments are
    packed into `PipelineOptions` and executed by `MLXWhisperXPipeline`.
    """
    kwargs = locals().copy()
    audio_obj = kwargs.pop("audio")
    kwargs["language"], kwargs["task"] = normalize_language_settings(
        kwargs["model"], kwargs.get("language"), kwargs.get("task")
    )
    options = PipelineOptions(**kwargs)
    return MLXWhisperXPipeline(options).transcribe(audio_obj)
