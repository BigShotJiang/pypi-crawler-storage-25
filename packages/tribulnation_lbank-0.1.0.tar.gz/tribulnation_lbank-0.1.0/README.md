# Tribulnation Lbank SDK

> An SDK to connect Lbank with the Tribulnation ecosystem.

🚧 Under construction.