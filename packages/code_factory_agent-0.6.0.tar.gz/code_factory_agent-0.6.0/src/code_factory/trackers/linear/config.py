from __future__ import annotations

"""Configuration helpers tailored to the Linear tracker integration."""

import os
from collections.abc import Mapping
from typing import Any

from ...config.models import Settings, TrackerSettings
from ...config.utils import (
    configured_active_states,
    optional_string,
    require_mapping,
    resolve_secret_setting,
    string_with_default,
)
from ...errors import ConfigValidationError
from .project_resolution import validate_config_project, validate_project_name


def supports_tracker_kind(kind: str | None) -> bool:
    """Linear is the only kind this module understands."""
    return kind == "linear"


def validate_tracker_settings(settings: Settings) -> None:
    if not settings.tracker.api_key:
        raise ConfigValidationError(
            "LINEAR_API_KEY is required", code="missing_linear_api_token"
        )
    if not settings.tracker.project:
        raise ConfigValidationError(
            "tracker.project is required", code="missing_linear_project"
        )
    validate_project_name(settings.tracker.project, config_error=True)


def parse_tracker_settings(config: Mapping[str, Any] | Any) -> TrackerSettings:
    # Keep parsing tautologically simple so we can trust defaults.
    tracker_raw = (
        require_mapping(config.get("tracker"), "tracker")
        if isinstance(config, Mapping)
        else {}
    )
    validate_config_project({"tracker": tracker_raw})
    return TrackerSettings(
        kind=optional_string(tracker_raw.get("kind"), "tracker.kind"),
        endpoint=string_with_default(
            tracker_raw.get("endpoint"),
            "tracker.endpoint",
            "https://api.linear.app/graphql",
        ),
        api_key=resolve_secret_setting(
            tracker_raw.get("api_key"),
            os.getenv("LINEAR_API_KEY"),
            "tracker.api_key",
        ),
        project=optional_string(tracker_raw.get("project"), "tracker.project"),
        assignee=resolve_secret_setting(
            tracker_raw.get("assignee"),
            os.getenv("LINEAR_ASSIGNEE"),
            "tracker.assignee",
        ),
        active_states=configured_active_states(config, tracker_raw),
    )
