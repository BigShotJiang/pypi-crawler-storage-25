from __future__ import annotations

import asyncio
from collections.abc import AsyncIterator
from typing import Any

from datablue._http import AsyncHTTP, SyncHTTP, raise_for_status
from datablue.models.scrape import ScrapeResult


def batch_scrape_sync(
    http: SyncHTTP,
    urls: list[str],
    *,
    concurrency: int = 5,
    scrape_options: dict[str, Any] | None = None,
) -> list[ScrapeResult]:
    """Scrape multiple URLs sequentially (sync). Returns list of results."""
    results: list[ScrapeResult] = []
    opts = scrape_options or {}
    for url in urls:
        resp = http.post("/v1/scrape", json={"url": url, **opts})
        try:
            raise_for_status(resp)
            results.append(ScrapeResult.model_validate(resp.json()))
        except Exception as exc:
            results.append(ScrapeResult(success=False, error=str(exc)))
    return results


async def batch_scrape_async_iter(
    http: AsyncHTTP,
    urls: list[str],
    *,
    concurrency: int = 5,
    scrape_options: dict[str, Any] | None = None,
) -> AsyncIterator[ScrapeResult]:
    """Scrape multiple URLs concurrently, yielding results as they complete.

    Usage::

        async for result in client.batch_scrape_iter(urls, concurrency=10):
            print(result.data.url, result.success)
    """
    semaphore = asyncio.Semaphore(concurrency)
    opts = scrape_options or {}

    async def _scrape_one(url: str) -> ScrapeResult:
        async with semaphore:
            resp = await http.post("/v1/scrape", json={"url": url, **opts})
            try:
                raise_for_status(resp)
                return ScrapeResult.model_validate(resp.json())
            except Exception as exc:
                return ScrapeResult(success=False, error=str(exc))

    # Launch all tasks, yield as they complete
    tasks = [asyncio.create_task(_scrape_one(url)) for url in urls]
    for coro in asyncio.as_completed(tasks):
        yield await coro
