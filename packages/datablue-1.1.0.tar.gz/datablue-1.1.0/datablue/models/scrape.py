from __future__ import annotations

from pydantic import BaseModel

from datablue.models.common import PageData


class ScrapeResult(BaseModel):
    """Response from POST /v1/scrape."""

    success: bool = True
    data: PageData | None = None
    error: str | None = None
    error_code: str | None = None
    job_id: str | None = None
