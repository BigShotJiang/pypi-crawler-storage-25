from __future__ import annotations

from pydantic import BaseModel, Field


class LinkResult(BaseModel):
    """A link discovered by the map endpoint."""

    url: str = ""
    title: str | None = None
    description: str | None = None
    lastmod: str | None = None
    priority: float | None = None


class MapResult(BaseModel):
    """Response from POST /v1/map."""

    success: bool = True
    total: int = 0
    links: list[LinkResult] = Field(default_factory=list)
    error: str | None = None
    job_id: str | None = None

    @property
    def urls(self) -> list[str]:
        return [link.url for link in self.links]
