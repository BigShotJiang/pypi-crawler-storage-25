from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field

_TERMINAL = {"completed", "failed", "cancelled"}


class SearchResultItem(BaseModel):
    """A single search result with optional scraped content."""

    id: str | None = None
    url: str = ""
    title: str | None = None
    snippet: str | None = None
    success: bool = True
    markdown: str | None = None
    html: str | None = None
    links: list[str] | None = None
    links_detail: list[dict[str, Any]] | None = None
    screenshot: str | None = None
    structured_data: dict[str, Any] | None = None
    headings: list[dict[str, Any]] | None = None
    images: list[dict[str, Any]] | None = None
    extract: dict[str, Any] | None = None
    metadata: dict[str, Any] | None = None
    error: str | None = None


class SearchJob(BaseModel):
    """Response from POST /v1/search (job submission)."""

    success: bool = True
    job_id: str = ""
    status: str = ""
    message: str | None = None


class SearchStatus(BaseModel):
    """Response from GET /v1/search/{job_id}."""

    job_id: str = ""
    status: str = ""
    query: str | None = None
    total_results: int = 0
    completed_results: int = 0
    data: list[SearchResultItem] = Field(default_factory=list)
    error: str | None = None

    @property
    def is_complete(self) -> bool:
        return self.status in _TERMINAL

    @property
    def progress(self) -> float:
        if self.total_results == 0:
            return 0.0
        return self.completed_results / self.total_results


class SearchResult(SearchStatus):
    """Alias for SearchStatus (Firecrawl compat)."""

    pass
