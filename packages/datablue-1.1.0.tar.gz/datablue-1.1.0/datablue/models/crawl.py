from __future__ import annotations

from pydantic import BaseModel, Field

from datablue.models.common import CrawlPageData

_TERMINAL = {"completed", "failed", "cancelled"}


class CrawlJob(BaseModel):
    """Response from POST /v1/crawl (job submission)."""

    success: bool = True
    job_id: str = ""
    status: str = ""
    message: str | None = None


class CrawlStatus(BaseModel):
    """Response from GET /v1/crawl/{job_id}."""

    success: bool = True
    job_id: str = ""
    status: str = ""
    total_pages: int = 0
    completed_pages: int = 0
    data: list[CrawlPageData] = Field(default_factory=list)
    total_results: int = 0
    page: int = 1
    per_page: int = 20
    error: str | None = None

    @property
    def is_complete(self) -> bool:
        return self.status in _TERMINAL

    @property
    def progress(self) -> float:
        if self.total_pages == 0:
            return 0.0
        return self.completed_pages / self.total_pages
