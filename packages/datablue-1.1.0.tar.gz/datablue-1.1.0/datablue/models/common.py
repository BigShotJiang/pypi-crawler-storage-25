from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


class PageMetadata(BaseModel):
    """Metadata extracted from a scraped page."""

    title: str | None = None
    description: str | None = None
    language: str | None = None
    source_url: str | None = None
    status_code: int | None = None
    word_count: int = 0
    reading_time_seconds: int = 0
    content_length: int = 0
    og_image: str | None = None
    canonical_url: str | None = None
    favicon: str | None = None
    robots: str | None = None
    response_headers: dict[str, str] | None = None


class PageData(BaseModel):
    """Content and metadata for a single scraped page."""

    url: str | None = None
    markdown: str | None = None
    fit_markdown: str | None = None
    html: str | None = None
    raw_html: str | None = None
    links: list[str] | None = None
    links_detail: dict[str, Any] | list[dict[str, Any]] | None = None
    screenshot: str | None = None
    structured_data: dict[str, Any] | None = None
    headings: list[dict[str, Any]] | None = None
    images: list[dict[str, Any]] | None = None
    extract: dict[str, Any] | None = None
    citations: list[dict[str, Any]] | None = None
    markdown_with_citations: str | None = None
    content_hash: str | None = None
    metadata: PageMetadata | None = None


class CrawlPageData(BaseModel):
    """Page data within a crawl job result."""

    id: str | None = None
    url: str | None = None
    markdown: str | None = None
    fit_markdown: str | None = None
    html: str | None = None
    raw_html: str | None = None
    links: list[str] | None = None
    links_detail: dict[str, Any] | list[dict[str, Any]] | None = None
    screenshot: str | None = None
    structured_data: dict[str, Any] | None = None
    headings: list[dict[str, Any]] | None = None
    images: list[dict[str, Any]] | None = None
    extract: dict[str, Any] | None = None
    content_hash: str | None = None
    citations: list[dict[str, Any]] | None = None
    markdown_with_citations: str | None = None
    metadata: PageMetadata | None = None
    error: str | None = None
    success: bool = True


class ActionStep(BaseModel):
    """A browser action to execute during scraping."""
    type: str
    selector: str | None = None
    milliseconds: int | None = None
    direction: str | None = None
    amount: int | None = None
    text: str | None = None
    key: str | None = None
    value: str | None = None
    script: str | None = None
    fields: dict[str, str] | None = None
    button: str | None = None
    click_count: int | None = None
    modifiers: list[str] | None = None


class ExtractConfig(BaseModel):
    """LLM extraction configuration."""
    prompt: str
    schema_: dict[str, Any] | None = Field(None, alias="schema")
