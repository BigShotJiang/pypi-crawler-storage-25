from __future__ import annotations

import asyncio
import json
import logging
import time
from collections.abc import AsyncIterator
from typing import Any

from datablue._http import AsyncHTTP, raise_for_status
from datablue.config import ClientConfig
from datablue.exceptions import JobFailedError, TimeoutError
from datablue.models.common import CrawlPageData
from datablue.models.crawl import CrawlJob, CrawlStatus
from datablue.models.map import MapResult
from datablue.models.scrape import ScrapeResult
from datablue.models.search import SearchJob, SearchStatus

logger = logging.getLogger("datablue")

_TERMINAL = {"completed", "failed", "cancelled"}


class AsyncDataBlue:
    """Asynchronous client for the DataBlue API.

    Example::

        async with AsyncDataBlue(api_key="wh_...") as client:
            result = await client.scrape("https://example.com")
            print(result.data.markdown)
    """

    def __init__(
        self,
        api_url: str = "http://localhost:8000",
        api_key: str | None = None,
        *,
        timeout: float = 60.0,
        max_retries: int = 3,
        config: ClientConfig | None = None,
    ) -> None:
        if config:
            self._config = config
        else:
            self._config = ClientConfig(
                api_url=api_url,
                api_key=api_key,
                timeout=timeout,
                max_retries=max_retries,
            )
        self._http = AsyncHTTP(self._config)

    @classmethod
    def from_env(cls) -> AsyncDataBlue:
        """Create client from DATABLUE_* environment variables."""
        return cls(config=ClientConfig.from_env())

    # -- Auth ------------------------------------------------------------------

    async def login(self, email: str, password: str) -> dict[str, Any]:
        """Authenticate with email/password and store the token."""
        resp = await self._http.post("/v1/auth/login", json={"email": email, "password": password})
        raise_for_status(resp)
        data = resp.json()
        self._http.set_token(data["access_token"])
        return data

    # -- Scrape ----------------------------------------------------------------

    async def scrape(
        self,
        url: str,
        *,
        formats: list[str] | None = None,
        only_main_content: bool = True,
        wait_for: int = 0,
        timeout: int = 30000,
        include_tags: list[str] | None = None,
        exclude_tags: list[str] | None = None,
        headers: dict[str, str] | None = None,
        cookies: dict[str, str] | None = None,
        mobile: bool = False,
        mobile_device: str | None = None,
        css_selector: str | None = None,
        xpath: str | None = None,
        extract: dict[str, Any] | None = None,
        use_proxy: bool = False,
        actions: list[dict[str, Any]] | None = None,
        selectors: dict[str, Any] | None = None,
        capture_network: bool = False,
        webhook_url: str | None = None,
        webhook_secret: str | None = None,
    ) -> ScrapeResult:
        """Scrape a single URL and return structured content."""
        payload: dict[str, Any] = {
            "url": url,
            "formats": formats,
            "only_main_content": only_main_content,
            "wait_for": wait_for,
            "timeout": timeout,
            "include_tags": include_tags,
            "exclude_tags": exclude_tags,
            "extract": extract,
            "use_proxy": use_proxy,
        }
        if headers is not None:
            payload["headers"] = headers
        if cookies is not None:
            payload["cookies"] = cookies
        if mobile:
            payload["mobile"] = mobile
        if mobile_device is not None:
            payload["mobile_device"] = mobile_device
        if css_selector is not None:
            payload["css_selector"] = css_selector
        if xpath is not None:
            payload["xpath"] = xpath
        if actions is not None:
            payload["actions"] = actions
        if selectors is not None:
            payload["selectors"] = selectors
        if capture_network:
            payload["capture_network"] = capture_network
        if webhook_url is not None:
            payload["webhook_url"] = webhook_url
        if webhook_secret is not None:
            payload["webhook_secret"] = webhook_secret
        resp = await self._http.post("/v1/scrape", json=payload)
        raise_for_status(resp)
        return ScrapeResult.model_validate(resp.json())

    # -- Crawl -----------------------------------------------------------------

    async def start_crawl(
        self,
        url: str,
        *,
        max_pages: int = 100,
        max_depth: int = 3,
        concurrency: int = 3,
        include_paths: list[str] | None = None,
        exclude_paths: list[str] | None = None,
        allow_external_links: bool = False,
        respect_robots_txt: bool = True,
        crawl_strategy: str | None = None,
        scrape_options: dict[str, Any] | None = None,
        use_proxy: bool = False,
        webhook_url: str | None = None,
        webhook_secret: str | None = None,
        filter_faceted_urls: bool = True,
    ) -> CrawlJob:
        """Start a crawl job (non-blocking). Returns job ID for polling."""
        payload: dict[str, Any] = {
            "url": url,
            "max_pages": max_pages,
            "max_depth": max_depth,
            "concurrency": concurrency,
            "include_paths": include_paths,
            "exclude_paths": exclude_paths,
            "allow_external_links": allow_external_links,
            "respect_robots_txt": respect_robots_txt,
            "scrape_options": scrape_options,
            "use_proxy": use_proxy,
            "webhook_url": webhook_url,
            "webhook_secret": webhook_secret,
            "filter_faceted_urls": filter_faceted_urls,
        }
        if crawl_strategy is not None:
            payload["crawl_strategy"] = crawl_strategy
        resp = await self._http.post("/v1/crawl", json=payload)
        raise_for_status(resp)
        return CrawlJob.model_validate(resp.json())

    async def get_crawl_status(self, job_id: str) -> CrawlStatus:
        """Get current status and results of a crawl job."""
        resp = await self._http.get(f"/v1/crawl/{job_id}")
        raise_for_status(resp)
        return CrawlStatus.model_validate(resp.json())

    async def cancel_crawl(self, job_id: str) -> dict[str, Any]:
        """Cancel an in-progress crawl."""
        resp = await self._http.delete(f"/v1/crawl/{job_id}")
        raise_for_status(resp)
        return resp.json()

    async def crawl(
        self,
        url: str,
        *,
        poll_interval: float = 2.0,
        timeout: float = 300.0,
        on_progress: Any = None,  # Callable[[CrawlStatus], None] | None
        **kwargs: Any,
    ) -> CrawlStatus:
        """Start a crawl and block until completion (convenience wrapper).

        Raises TimeoutError if the job doesn't complete within ``timeout`` seconds.
        Raises JobFailedError if the job fails.
        """
        job = await self.start_crawl(url, **kwargs)
        return await self._poll_job(
            f"/v1/crawl/{job.job_id}",
            job.job_id,
            CrawlStatus,
            poll_interval=poll_interval,
            timeout=timeout,
            on_progress=on_progress,
        )

    async def crawl_stream(
        self,
        url: str,
        *,
        on_document: Any = None,  # Callable[[CrawlPageData], None] | None
        **kwargs: Any,
    ) -> AsyncIterator[CrawlPageData]:
        """Start a crawl and yield pages as they're discovered.

        Opens a streaming NDJSON connection and yields each page in real time,
        without polling. This is faster and more efficient than Firecrawl's
        WebSocket-based watcher because it uses a single HTTP stream with
        back-pressure — no reconnection logic, no missed events.

        Example::

            async for page in client.crawl_stream("https://example.com", max_pages=50):
                print(page.url, len(page.markdown or ""))

            # Or with a callback:
            await client.crawl_stream_with_callback(
                "https://example.com",
                on_document=lambda page: print(page.url),
                max_pages=50,
            )
        """
        logger.debug("Starting crawl stream for %s", url)
        job = await self.start_crawl(url, **kwargs)
        count = 0
        async with self._http._client.stream(
            "GET",
            f"/v1/crawl/{job.job_id}/stream",
            headers=self._http._headers,
        ) as response:
            async for line in response.aiter_lines():
                if not line.strip():
                    continue
                data = json.loads(line)
                if "status" in data:
                    if data["status"] == "error":
                        raise JobFailedError(
                            data.get("error", "Stream error"),
                            job_id=job.job_id,
                        )
                    # completed / cancelled — end of stream
                    logger.info("Crawl stream completed: %d pages", count)
                    return
                page = CrawlPageData.model_validate(data)
                count += 1
                logger.debug(
                    "Stream page: %s (%d chars)",
                    page.url,
                    len(page.markdown or ""),
                )
                if on_document:
                    on_document(page)
                yield page
        logger.info("Crawl stream completed: %d pages", count)

    async def crawl_stream_with_callback(
        self,
        url: str,
        *,
        on_document: Any,  # Callable[[CrawlPageData], None] — required
        on_complete: Any = None,  # Callable[[], None] | None
        on_error: Any = None,  # Callable[[Exception], None] | None
        **kwargs: Any,
    ) -> None:
        """Start a crawl with real-time callbacks for each page.

        Similar to Firecrawl's Watcher but simpler and more Pythonic —
        no WebSocket, no reconnection, just callbacks fired as pages arrive.

        Args:
            url: The URL to start crawling from.
            on_document: Called with each ``CrawlPageData`` as it arrives.
            on_complete: Called (with no arguments) when the crawl finishes.
            on_error: Called with the exception if an error occurs.
                If not provided, the exception is re-raised.
            **kwargs: Passed through to ``start_crawl()``.
        """
        try:
            async for page in self.crawl_stream(url, **kwargs):
                on_document(page)
            if on_complete:
                on_complete()
        except Exception as e:
            if on_error:
                on_error(e)
            else:
                raise

    # -- Search ----------------------------------------------------------------

    async def start_search(
        self,
        query: str,
        *,
        num_results: int = 5,
        engine: str = "google",
        google_api_key: str | None = None,
        google_cx: str | None = None,
        brave_api_key: str | None = None,
        formats: list[str] | None = None,
        use_proxy: bool = False,
        webhook_url: str | None = None,
        webhook_secret: str | None = None,
        only_main_content: bool = False,
        headers: dict[str, str] | None = None,
        cookies: dict[str, str] | None = None,
        mobile: bool = False,
        mobile_device: str | None = None,
        extract: dict[str, Any] | None = None,
    ) -> SearchJob:
        """Start a search job (non-blocking)."""
        payload: dict[str, Any] = {
            "query": query,
            "num_results": num_results,
            "engine": engine,
            "google_api_key": google_api_key,
            "google_cx": google_cx,
            "brave_api_key": brave_api_key,
            "formats": formats,
            "use_proxy": use_proxy,
            "webhook_url": webhook_url,
            "webhook_secret": webhook_secret,
            "only_main_content": only_main_content,
        }
        if headers is not None:
            payload["headers"] = headers
        if cookies is not None:
            payload["cookies"] = cookies
        if mobile:
            payload["mobile"] = mobile
        if mobile_device is not None:
            payload["mobile_device"] = mobile_device
        if extract is not None:
            payload["extract"] = extract
        resp = await self._http.post("/v1/search", json=payload)
        raise_for_status(resp)
        return SearchJob.model_validate(resp.json())

    async def get_search_status(self, job_id: str) -> SearchStatus:
        """Get current status and results of a search job."""
        resp = await self._http.get(f"/v1/search/{job_id}")
        raise_for_status(resp)
        return SearchStatus.model_validate(resp.json())

    async def search(
        self,
        query: str,
        *,
        poll_interval: float = 2.0,
        timeout: float = 300.0,
        on_progress: Any = None,  # Callable[[SearchStatus], None] | None
        **kwargs: Any,
    ) -> SearchStatus:
        """Search and block until completion."""
        job = await self.start_search(query, **kwargs)
        return await self._poll_job(
            f"/v1/search/{job.job_id}",
            job.job_id,
            SearchStatus,
            poll_interval=poll_interval,
            timeout=timeout,
            on_progress=on_progress,
        )

    # -- Map -------------------------------------------------------------------

    async def map(
        self,
        url: str,
        *,
        search: str | None = None,
        limit: int = 100,
        include_subdomains: bool = True,
        use_sitemap: bool = True,
    ) -> MapResult:
        """Discover URLs on a website."""
        resp = await self._http.post("/v1/map", json={
            "url": url,
            "search": search,
            "limit": limit,
            "include_subdomains": include_subdomains,
            "use_sitemap": use_sitemap,
        })
        raise_for_status(resp)
        return MapResult.model_validate(resp.json())

    # -- Batch -----------------------------------------------------------------

    async def batch_scrape(
        self,
        urls: list[str],
        *,
        concurrency: int = 5,
        scrape_options: dict[str, Any] | None = None,
    ) -> list[ScrapeResult]:
        """Scrape multiple URLs concurrently. Returns all results."""
        from datablue._batch import batch_scrape_async_iter
        results = []
        async for result in batch_scrape_async_iter(self._http, urls, concurrency=concurrency, scrape_options=scrape_options):
            results.append(result)
        return results

    def batch_scrape_iter(
        self,
        urls: list[str],
        *,
        concurrency: int = 5,
        scrape_options: dict[str, Any] | None = None,
    ) -> AsyncIterator[ScrapeResult]:
        """Scrape multiple URLs, yielding results as they complete.

        Usage::

            async for result in client.batch_scrape_iter(urls, concurrency=10):
                print(result.data.url)
        """
        from datablue._batch import batch_scrape_async_iter
        return batch_scrape_async_iter(self._http, urls, concurrency=concurrency, scrape_options=scrape_options)

    # -- Polling Helper --------------------------------------------------------

    async def _poll_job(
        self,
        path: str,
        job_id: str,
        model: type,
        *,
        poll_interval: float,
        timeout: float,
        on_progress: Any = None,
    ) -> Any:
        """Poll a job endpoint until terminal status."""
        start = time.monotonic()
        while True:
            elapsed = time.monotonic() - start
            if elapsed > timeout:
                raise TimeoutError(
                    f"Job {job_id} did not complete within {timeout}s",
                    job_id=job_id,
                    elapsed=elapsed,
                )
            resp = await self._http.get(path)
            raise_for_status(resp)
            status = model.model_validate(resp.json())
            logger.debug("Poll %s: status=%s", job_id[:8], status.status)
            if on_progress is not None:
                on_progress(status)
            if status.status in _TERMINAL:
                if status.status == "failed":
                    raise JobFailedError(
                        f"Job {job_id} failed: {getattr(status, 'error', 'unknown')}",
                        job_id=job_id,
                        response_body=resp.json(),
                    )
                return status
            await asyncio.sleep(poll_interval)

    # -- Lifecycle -------------------------------------------------------------

    async def close(self) -> None:
        """Close the underlying HTTP connection pool."""
        await self._http.close()

    async def __aenter__(self) -> AsyncDataBlue:
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()
