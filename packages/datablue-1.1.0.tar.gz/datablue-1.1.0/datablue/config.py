from __future__ import annotations

import os
from dataclasses import dataclass


@dataclass(frozen=True)
class ClientConfig:
    """Immutable SDK configuration. Use `.clone()` to create modified copies.

    Example::

        config = ClientConfig(api_url="https://api.datablue.dev", api_key="wh_...")
        staging = config.clone(api_url="https://staging.datablue.dev")
    """

    api_url: str = "http://localhost:8000"
    api_key: str | None = None
    timeout: float = 60.0
    max_retries: int = 3
    backoff_factor: float = 0.5

    def __post_init__(self) -> None:
        # Strip trailing slash from api_url
        if self.api_url.endswith("/"):
            object.__setattr__(self, "api_url", self.api_url.rstrip("/"))

    def clone(self, **overrides: object) -> ClientConfig:
        """Return a new config with selected fields overridden.

        Example::

            fast = config.clone(timeout=10.0, max_retries=1)
        """
        from dataclasses import asdict

        merged = {**asdict(self), **overrides}
        return ClientConfig(**merged)

    @classmethod
    def from_env(cls) -> ClientConfig:
        """Build config from DATABLUE_* environment variables.

        Reads:
            DATABLUE_API_URL — Base URL (default: http://localhost:8000)
            DATABLUE_API_KEY — API key
            DATABLUE_TIMEOUT — Request timeout in seconds
            DATABLUE_MAX_RETRIES — Max retry count
        """
        kwargs: dict[str, object] = {}
        if url := os.environ.get("DATABLUE_API_URL"):
            kwargs["api_url"] = url
        if key := os.environ.get("DATABLUE_API_KEY"):
            kwargs["api_key"] = key
        if timeout := os.environ.get("DATABLUE_TIMEOUT"):
            kwargs["timeout"] = float(timeout)
        if retries := os.environ.get("DATABLUE_MAX_RETRIES"):
            kwargs["max_retries"] = int(retries)
        return cls(**kwargs)
