"""DataBlue Python SDK — scrape, crawl, search, and map the web.

Quick start::

    from datablue import DataBlue

    with DataBlue(api_key="db_...") as client:
        result = client.scrape("https://example.com")
        print(result.data.markdown)

Async::

    from datablue import AsyncDataBlue

    async with AsyncDataBlue(api_key="db_...") as client:
        result = await client.scrape("https://example.com")

Batch scrape::

    results = client.batch_scrape(["https://a.com", "https://b.com"])
"""

from datablue._version import __version__
from datablue.async_client import AsyncDataBlue
from datablue.client import DataBlue
from datablue.config import ClientConfig
from datablue.exceptions import (
    AuthenticationError,
    DataBlueError,
    JobFailedError,
    NotFoundError,
    RateLimitError,
    ServerError,
    TimeoutError,
)
from datablue.models import (
    ActionStep,
    CrawlJob,
    CrawlPageData,
    CrawlStatus,
    ExtractConfig,
    LinkResult,
    MapResult,
    PageData,
    PageMetadata,
    ScrapeResult,
    SearchJob,
    SearchResult,
    SearchResultItem,
    SearchStatus,
)

__all__ = [
    "__version__",
    "DataBlue",
    "AsyncDataBlue",
    "ClientConfig",
    "DataBlueError",
    "AuthenticationError",
    "NotFoundError",
    "RateLimitError",
    "ServerError",
    "JobFailedError",
    "TimeoutError",
    "PageMetadata",
    "PageData",
    "CrawlPageData",
    "ActionStep",
    "ExtractConfig",
    "ScrapeResult",
    "CrawlJob",
    "CrawlStatus",
    "SearchJob",
    "SearchStatus",
    "SearchResult",
    "SearchResultItem",
    "MapResult",
    "LinkResult",
]
