from __future__ import annotations

from typing import Any


def strip_none(d: dict[str, Any]) -> dict[str, Any]:
    """Remove keys with None values from a dictionary."""
    return {k: v for k, v in d.items() if v is not None}


def build_headers(
    token: str | None = None,
    api_key: str | None = None,
) -> dict[str, str]:
    """Build request headers with authentication."""
    headers: dict[str, str] = {"Content-Type": "application/json"}
    bearer = api_key or token
    if bearer:
        headers["Authorization"] = f"Bearer {bearer}"
    return headers
