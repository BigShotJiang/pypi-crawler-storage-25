from __future__ import annotations

from typing import Any

# Docs base URL for linking errors to documentation
_DOCS_BASE = "https://docs.datablue.dev/errors"

# Map exception types to docs slugs
_DOCS_SLUGS: dict[str, str] = {
    "AuthenticationError": "authentication",
    "NotFoundError": "not-found",
    "RateLimitError": "rate-limit",
    "ServerError": "server-error",
    "JobFailedError": "job-failed",
    "TimeoutError": "timeout",
}


class DataBlueError(Exception):
    """Base exception for all DataBlue SDK errors.

    Attributes:
        message: Human-readable error description.
        status_code: HTTP status code (if from an API response).
        response_body: Raw API response body (if available).
        is_retryable: Whether the request can be safely retried.
        retry_after: Seconds to wait before retrying (if applicable).
        docs_url: Link to documentation about this error type.
    """

    def __init__(
        self,
        message: str,
        *,
        status_code: int | None = None,
        response_body: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.response_body = response_body

    @property
    def is_retryable(self) -> bool:
        return False

    @property
    def retry_after(self) -> float | None:
        return None

    @property
    def docs_url(self) -> str | None:
        slug = _DOCS_SLUGS.get(type(self).__name__)
        return f"{_DOCS_BASE}/{slug}" if slug else None


class AuthenticationError(DataBlueError):
    """Raised on 401 Unauthorized — bad or missing API key / token."""

    def __init__(
        self,
        message: str = "Authentication failed",
        **kwargs: Any,
    ) -> None:
        super().__init__(message, status_code=401, **kwargs)


class NotFoundError(DataBlueError):
    """Raised on 404 Not Found — resource does not exist."""

    def __init__(
        self,
        message: str = "Resource not found",
        **kwargs: Any,
    ) -> None:
        super().__init__(message, status_code=404, **kwargs)


class RateLimitError(DataBlueError):
    """Raised on 429 Too Many Requests.

    Check `retry_after` for how long to wait before retrying.
    """

    def __init__(
        self,
        message: str = "Rate limit exceeded",
        *,
        retry_after: float | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(message, status_code=429, **kwargs)
        self._retry_after = retry_after

    @property
    def is_retryable(self) -> bool:
        return True

    @property
    def retry_after(self) -> float | None:
        return self._retry_after


class ServerError(DataBlueError):
    """Raised on 5xx server errors. These are always retryable."""

    def __init__(
        self,
        message: str = "Server error",
        *,
        status_code: int = 500,
        **kwargs: Any,
    ) -> None:
        super().__init__(message, status_code=status_code, **kwargs)

    @property
    def is_retryable(self) -> bool:
        return True


class JobFailedError(DataBlueError):
    """Raised when a polled job completes with 'failed' status."""

    def __init__(
        self,
        message: str = "Job failed",
        *,
        job_id: str | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(message, **kwargs)
        self.job_id = job_id


class TimeoutError(DataBlueError):
    """Raised when polling a job exceeds the timeout."""

    def __init__(
        self,
        message: str = "Job timed out",
        *,
        job_id: str | None = None,
        elapsed: float | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(message, **kwargs)
        self.job_id = job_id
        self.elapsed = elapsed
