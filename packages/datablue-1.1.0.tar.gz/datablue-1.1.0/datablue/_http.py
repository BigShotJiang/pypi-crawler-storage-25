from __future__ import annotations

import logging
import time
from typing import Any

import httpx

logger = logging.getLogger("datablue")

from datablue._utils import build_headers, strip_none
from datablue.config import ClientConfig
from datablue.exceptions import (
    AuthenticationError,
    DataBlueError,
    NotFoundError,
    RateLimitError,
    ServerError,
)


def raise_for_status(response: httpx.Response) -> None:
    """Map HTTP error status codes to typed exceptions."""
    if response.is_success:
        return

    try:
        body = response.json()
    except Exception:
        body = {"detail": response.text}

    message = body.get("detail") or body.get("error") or body.get("message") or response.text
    kwargs: dict[str, Any] = {"response_body": body}

    match response.status_code:
        case 401:
            raise AuthenticationError(str(message), **kwargs)
        case 404:
            raise NotFoundError(str(message), **kwargs)
        case 429:
            retry_after = response.headers.get("retry-after")
            raise RateLimitError(
                str(message),
                retry_after=float(retry_after) if retry_after else None,
                **kwargs,
            )
        case code if code >= 500:
            raise ServerError(str(message), status_code=code, **kwargs)
        case _:
            raise DataBlueError(str(message), status_code=response.status_code, **kwargs)


class SyncHTTP:
    """Synchronous HTTP client with retry and auth."""

    def __init__(self, config: ClientConfig) -> None:
        self._config = config
        self._token: str | None = None
        self._client = httpx.Client(
            base_url=config.api_url,
            timeout=config.timeout,
        )

    def set_token(self, token: str) -> None:
        self._token = token

    @property
    def _headers(self) -> dict[str, str]:
        return build_headers(token=self._token, api_key=self._config.api_key)

    def request(
        self,
        method: str,
        path: str,
        *,
        json: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ) -> httpx.Response:
        """Make an HTTP request with automatic retry on transient errors."""
        last_exc: Exception | None = None

        for attempt in range(self._config.max_retries + 1):
            try:
                logger.debug("→ %s %s", method, path)
                t0 = time.monotonic()
                response = self._client.request(
                    method,
                    path,
                    headers=self._headers,
                    json=strip_none(json) if json else None,
                    params=strip_none(params) if params else None,
                )
                elapsed = time.monotonic() - t0
                logger.debug("← %s %s → %d (%.1fs)", method, path, response.status_code, elapsed)
                # Retry on 5xx
                if response.status_code >= 500 and attempt < self._config.max_retries:
                    delay = self._config.backoff_factor * (2 ** attempt)
                    logger.info("Server error %d, retrying in %.1fs (attempt %d/%d)", response.status_code, delay, attempt + 1, self._config.max_retries)
                    time.sleep(min(delay, 10.0))
                    continue
                # Retry on 429
                if response.status_code == 429 and attempt < self._config.max_retries:
                    retry_after = response.headers.get("retry-after")
                    delay = float(retry_after) if retry_after else self._config.backoff_factor * (2 ** attempt)
                    logger.info("Rate limited (429), retrying in %.1fs (attempt %d/%d)", delay, attempt + 1, self._config.max_retries)
                    time.sleep(min(delay, 30.0))
                    continue
                return response
            except (httpx.TimeoutException, httpx.ConnectError) as exc:
                last_exc = exc
                if attempt < self._config.max_retries:
                    delay = self._config.backoff_factor * (2 ** attempt)
                    logger.warning("Connection error: %s, retrying in %.1fs", exc, delay)
                    time.sleep(min(delay, 10.0))
                    continue
                raise DataBlueError(f"Connection failed after {attempt + 1} attempts: {exc}") from exc

        # Should not reach here, but just in case
        raise DataBlueError(f"Request failed: {last_exc}") from last_exc

    def get(self, path: str, **kwargs: Any) -> httpx.Response:
        return self.request("GET", path, **kwargs)

    def post(self, path: str, **kwargs: Any) -> httpx.Response:
        return self.request("POST", path, **kwargs)

    def put(self, path: str, **kwargs: Any) -> httpx.Response:
        return self.request("PUT", path, **kwargs)

    def delete(self, path: str, **kwargs: Any) -> httpx.Response:
        return self.request("DELETE", path, **kwargs)

    def close(self) -> None:
        self._client.close()


class AsyncHTTP:
    """Asynchronous HTTP client with retry and auth."""

    def __init__(self, config: ClientConfig) -> None:
        self._config = config
        self._token: str | None = None
        self._client = httpx.AsyncClient(
            base_url=config.api_url,
            timeout=config.timeout,
        )

    def set_token(self, token: str) -> None:
        self._token = token

    @property
    def _headers(self) -> dict[str, str]:
        return build_headers(token=self._token, api_key=self._config.api_key)

    async def request(
        self,
        method: str,
        path: str,
        *,
        json: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ) -> httpx.Response:
        """Make an async HTTP request with automatic retry on transient errors."""
        import asyncio

        last_exc: Exception | None = None

        for attempt in range(self._config.max_retries + 1):
            try:
                logger.debug("→ %s %s", method, path)
                t0 = time.monotonic()
                response = await self._client.request(
                    method,
                    path,
                    headers=self._headers,
                    json=strip_none(json) if json else None,
                    params=strip_none(params) if params else None,
                )
                elapsed = time.monotonic() - t0
                logger.debug("← %s %s → %d (%.1fs)", method, path, response.status_code, elapsed)
                if response.status_code >= 500 and attempt < self._config.max_retries:
                    delay = self._config.backoff_factor * (2 ** attempt)
                    logger.info("Server error %d, retrying in %.1fs (attempt %d/%d)", response.status_code, delay, attempt + 1, self._config.max_retries)
                    await asyncio.sleep(min(delay, 10.0))
                    continue
                # Retry on 429
                if response.status_code == 429 and attempt < self._config.max_retries:
                    retry_after = response.headers.get("retry-after")
                    delay = float(retry_after) if retry_after else self._config.backoff_factor * (2 ** attempt)
                    logger.info("Rate limited (429), retrying in %.1fs (attempt %d/%d)", delay, attempt + 1, self._config.max_retries)
                    await asyncio.sleep(min(delay, 30.0))
                    continue
                return response
            except (httpx.TimeoutException, httpx.ConnectError) as exc:
                last_exc = exc
                if attempt < self._config.max_retries:
                    delay = self._config.backoff_factor * (2 ** attempt)
                    logger.warning("Connection error: %s, retrying in %.1fs", exc, delay)
                    await asyncio.sleep(min(delay, 10.0))
                    continue
                raise DataBlueError(f"Connection failed after {attempt + 1} attempts: {exc}") from exc

        raise DataBlueError(f"Request failed: {last_exc}") from last_exc

    async def get(self, path: str, **kwargs: Any) -> httpx.Response:
        return await self.request("GET", path, **kwargs)

    async def post(self, path: str, **kwargs: Any) -> httpx.Response:
        return await self.request("POST", path, **kwargs)

    async def put(self, path: str, **kwargs: Any) -> httpx.Response:
        return await self.request("PUT", path, **kwargs)

    async def delete(self, path: str, **kwargs: Any) -> httpx.Response:
        return await self.request("DELETE", path, **kwargs)

    async def close(self) -> None:
        await self._client.aclose()
