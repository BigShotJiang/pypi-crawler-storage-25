from __future__ import annotations

import httpx
import respx

from datablue import DataBlue


class TestSearch:
    def test_start_search(self):
        with respx.mock:
            respx.post("http://test:8000/v1/search").mock(
                return_value=httpx.Response(200, json={
                    "success": True,
                    "job_id": "search-xyz",
                    "status": "started",
                })
            )
            with DataBlue(api_url="http://test:8000", api_key="wh_test") as client:
                job = client.start_search("python web scraping")
                assert job.job_id == "search-xyz"

    def test_get_search_status(self):
        with respx.mock:
            respx.get("http://test:8000/v1/search/search-xyz").mock(
                return_value=httpx.Response(200, json={
                    "job_id": "search-xyz",
                    "status": "completed",
                    "query": "python web scraping",
                    "total_results": 3,
                    "completed_results": 3,
                    "data": [
                        {"url": "https://a.com", "title": "Result A", "markdown": "content a"},
                        {"url": "https://b.com", "title": "Result B", "markdown": "content b"},
                        {"url": "https://c.com", "title": "Result C", "markdown": "content c"},
                    ],
                })
            )
            with DataBlue(api_url="http://test:8000", api_key="wh_test") as client:
                status = client.get_search_status("search-xyz")
                assert status.is_complete is True
                assert len(status.data) == 3

    def test_map(self):
        with respx.mock:
            respx.post("http://test:8000/v1/map").mock(
                return_value=httpx.Response(200, json={
                    "success": True,
                    "total": 2,
                    "links": [
                        {"url": "https://example.com/about"},
                        {"url": "https://example.com/contact"},
                    ],
                })
            )
            with DataBlue(api_url="http://test:8000", api_key="wh_test") as client:
                result = client.map("https://example.com")
                assert result.total == 2
                assert result.urls == ["https://example.com/about", "https://example.com/contact"]
