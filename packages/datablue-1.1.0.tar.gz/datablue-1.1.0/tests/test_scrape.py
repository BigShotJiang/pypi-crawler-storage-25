from __future__ import annotations

import json

import httpx
import pytest
import respx

from datablue import DataBlue
from datablue.exceptions import AuthenticationError


class TestScrape:
    def test_scrape_basic(self):
        with respx.mock:
            respx.post("http://test:8000/v1/scrape").mock(
                return_value=httpx.Response(200, json={
                    "success": True,
                    "data": {
                        "url": "https://example.com",
                        "markdown": "# Hello World",
                        "metadata": {"title": "Example", "word_count": 2},
                    },
                })
            )
            client = DataBlue(api_url="http://test:8000", api_key="wh_test")
            result = client.scrape("https://example.com")
            assert result.success is True
            assert result.data.markdown == "# Hello World"
            assert result.data.metadata.title == "Example"
            client.close()

    def test_scrape_with_options(self):
        with respx.mock:
            route = respx.post("http://test:8000/v1/scrape").mock(
                return_value=httpx.Response(200, json={"success": True, "data": {"markdown": "content"}})
            )
            client = DataBlue(api_url="http://test:8000", api_key="wh_test")
            client.scrape(
                "https://example.com",
                formats=["markdown", "html"],
                only_main_content=False,
                wait_for=2000,
                include_tags=["article"],
                exclude_tags=["nav", "footer"],
            )
            body = route.calls[0].request.content
            payload = json.loads(body)
            assert payload["url"] == "https://example.com"
            assert payload["formats"] == ["markdown", "html"]
            assert payload["only_main_content"] is False
            assert payload["wait_for"] == 2000
            client.close()

    def test_scrape_auth_error(self):
        with respx.mock:
            respx.post("http://test:8000/v1/scrape").mock(
                return_value=httpx.Response(401, json={"detail": "Invalid token"})
            )
            client = DataBlue(api_url="http://test:8000", api_key="bad_key")
            with pytest.raises(AuthenticationError):
                client.scrape("https://example.com")
            client.close()

    def test_context_manager(self):
        with respx.mock:
            respx.post("http://test:8000/v1/scrape").mock(
                return_value=httpx.Response(200, json={"success": True, "data": {"markdown": "ok"}})
            )
            with DataBlue(api_url="http://test:8000", api_key="wh_test") as client:
                result = client.scrape("https://example.com")
                assert result.success is True
