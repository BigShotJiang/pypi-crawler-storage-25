from __future__ import annotations

import httpx
import pytest
import respx

from datablue import DataBlue
from datablue.exceptions import JobFailedError, TimeoutError


class TestCrawl:
    def test_start_crawl(self):
        with respx.mock:
            respx.post("http://test:8000/v1/crawl").mock(
                return_value=httpx.Response(200, json={
                    "success": True,
                    "job_id": "crawl-abc",
                    "status": "started",
                })
            )
            with DataBlue(api_url="http://test:8000", api_key="wh_test") as client:
                job = client.start_crawl("https://example.com", max_pages=50)
                assert job.job_id == "crawl-abc"
                assert job.status == "started"

    def test_get_crawl_status(self):
        with respx.mock:
            respx.get("http://test:8000/v1/crawl/crawl-abc").mock(
                return_value=httpx.Response(200, json={
                    "job_id": "crawl-abc",
                    "status": "completed",
                    "total_pages": 10,
                    "completed_pages": 10,
                    "data": [
                        {"url": "https://example.com/1", "markdown": "page 1"},
                        {"url": "https://example.com/2", "markdown": "page 2"},
                    ],
                })
            )
            with DataBlue(api_url="http://test:8000", api_key="wh_test") as client:
                status = client.get_crawl_status("crawl-abc")
                assert status.is_complete is True
                assert len(status.data) == 2
                assert status.progress == 1.0

    def test_cancel_crawl(self):
        with respx.mock:
            respx.delete("http://test:8000/v1/crawl/crawl-abc").mock(
                return_value=httpx.Response(200, json={"success": True})
            )
            with DataBlue(api_url="http://test:8000", api_key="wh_test") as client:
                result = client.cancel_crawl("crawl-abc")
                assert result["success"] is True

    def test_crawl_blocking_polls(self):
        """Test that crawl() polls until completion."""
        call_count = 0

        def status_side_effect(request: httpx.Request) -> httpx.Response:
            nonlocal call_count
            call_count += 1
            if call_count < 3:
                return httpx.Response(200, json={
                    "job_id": "crawl-abc",
                    "status": "running",
                    "total_pages": 5,
                    "completed_pages": call_count,
                })
            return httpx.Response(200, json={
                "job_id": "crawl-abc",
                "status": "completed",
                "total_pages": 5,
                "completed_pages": 5,
                "data": [{"url": "https://example.com", "markdown": "done"}],
            })

        with respx.mock:
            respx.post("http://test:8000/v1/crawl").mock(
                return_value=httpx.Response(200, json={
                    "success": True, "job_id": "crawl-abc", "status": "started",
                })
            )
            respx.get("http://test:8000/v1/crawl/crawl-abc").mock(side_effect=status_side_effect)

            with DataBlue(api_url="http://test:8000", api_key="wh_test") as client:
                status = client.crawl("https://example.com", poll_interval=0.01, timeout=5)
                assert status.is_complete is True
                assert call_count == 3
