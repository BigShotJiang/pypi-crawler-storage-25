from __future__ import annotations

import pytest


@pytest.fixture
def api_url() -> str:
    return "http://localhost:8000"


@pytest.fixture
def api_key() -> str:
    return "wh_test_key_12345"
