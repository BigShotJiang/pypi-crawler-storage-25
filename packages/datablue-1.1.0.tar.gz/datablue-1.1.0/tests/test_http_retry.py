import httpx
import respx
from datablue._http import SyncHTTP
from datablue.config import ClientConfig


@respx.mock
def test_retries_on_429_with_retry_after():
    config = ClientConfig(api_url="https://test.api", api_key="test", max_retries=3, backoff_factor=0.01)
    http = SyncHTTP(config)
    route = respx.get("https://test.api/v1/test")
    route.side_effect = [
        httpx.Response(429, headers={"Retry-After": "0.01"}, json={"detail": "rate limited"}),
        httpx.Response(200, json={"success": True}),
    ]
    resp = http.get("/v1/test")
    assert resp.status_code == 200
    assert resp.json() == {"success": True}
    assert route.call_count == 2


@respx.mock
def test_raises_after_max_429_retries():
    config = ClientConfig(api_url="https://test.api", api_key="test", max_retries=2, backoff_factor=0.01)
    http = SyncHTTP(config)
    route = respx.get("https://test.api/v1/test")
    route.side_effect = [
        httpx.Response(429, json={"detail": "rate limited"}),
        httpx.Response(429, json={"detail": "rate limited"}),
        httpx.Response(429, json={"detail": "rate limited"}),
    ]
    resp = http.get("/v1/test")
    assert resp.status_code == 429
