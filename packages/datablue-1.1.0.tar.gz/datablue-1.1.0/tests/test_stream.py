"""Test crawl streaming (sync and async)."""
from __future__ import annotations

import json

import httpx
import pytest
import respx

from datablue import AsyncDataBlue, DataBlue
from datablue.exceptions import JobFailedError
from datablue.models.common import CrawlPageData

_API = "http://test:8000"
_CONFIG = dict(api_url=_API, api_key="wh_test")


def _mock_start_crawl(job_id: str = "j-1") -> None:
    """Register a respx mock for POST /v1/crawl."""
    respx.post(f"{_API}/v1/crawl").mock(
        return_value=httpx.Response(
            200,
            json={"success": True, "job_id": job_id, "status": "started"},
        )
    )


def _mock_stream(job_id: str, ndjson_lines: list[dict]) -> None:
    """Register a respx mock for GET /v1/crawl/{job_id}/stream."""
    body = "".join(json.dumps(line) + "\n" for line in ndjson_lines)
    respx.get(f"{_API}/v1/crawl/{job_id}/stream").mock(
        return_value=httpx.Response(
            200,
            content=body.encode(),
            headers={"content-type": "application/x-ndjson"},
        )
    )


# ---------------------------------------------------------------------------
# Sync tests
# ---------------------------------------------------------------------------


class TestSyncCrawlStream:
    def test_basic_stream(self):
        """crawl_stream yields CrawlPageData objects from NDJSON."""
        with respx.mock:
            _mock_start_crawl("j-1")
            _mock_stream("j-1", [
                {"url": "https://a.com", "markdown": "# Page A"},
                {"url": "https://b.com", "markdown": "# Page B"},
                {"status": "completed"},
            ])

            with DataBlue(**_CONFIG) as client:
                pages = list(client.crawl_stream("https://example.com", max_pages=5))

            assert len(pages) == 2
            assert all(isinstance(p, CrawlPageData) for p in pages)
            assert pages[0].url == "https://a.com"
            assert pages[0].markdown == "# Page A"
            assert pages[1].url == "https://b.com"
            assert pages[1].markdown == "# Page B"

    def test_stream_with_on_document(self):
        """on_document callback is called for each page while still yielding."""
        with respx.mock:
            _mock_start_crawl("j-2")
            _mock_stream("j-2", [
                {"url": "https://c.com", "markdown": "content c"},
                {"url": "https://d.com", "markdown": "content d"},
                {"status": "completed"},
            ])

            received: list[str] = []
            with DataBlue(**_CONFIG) as client:
                pages = list(
                    client.crawl_stream(
                        "https://example.com",
                        on_document=lambda p: received.append(p.url),
                        max_pages=10,
                    )
                )

            assert len(pages) == 2
            assert received == ["https://c.com", "https://d.com"]

    def test_stream_error_raises(self):
        """Error terminal line raises JobFailedError."""
        with respx.mock:
            _mock_start_crawl("j-3")
            _mock_stream("j-3", [
                {"url": "https://ok.com", "markdown": "ok"},
                {"status": "error", "error": "Crawl quota exceeded"},
            ])

            with DataBlue(**_CONFIG) as client:
                with pytest.raises(JobFailedError, match="Crawl quota exceeded"):
                    list(client.crawl_stream("https://example.com"))

    def test_stream_empty_lines_skipped(self):
        """Blank lines in the NDJSON stream are ignored."""
        with respx.mock:
            _mock_start_crawl("j-4")
            # Inject blank lines between data
            body = (
                "\n"
                + json.dumps({"url": "https://x.com", "markdown": "x"}) + "\n"
                + "\n"
                + json.dumps({"status": "completed"}) + "\n"
            )
            respx.get(f"{_API}/v1/crawl/j-4/stream").mock(
                return_value=httpx.Response(
                    200,
                    content=body.encode(),
                    headers={"content-type": "application/x-ndjson"},
                )
            )

            with DataBlue(**_CONFIG) as client:
                pages = list(client.crawl_stream("https://example.com"))

            assert len(pages) == 1
            assert pages[0].url == "https://x.com"

    def test_crawl_stream_with_callback(self):
        """crawl_stream_with_callback fires on_document and on_complete."""
        with respx.mock:
            _mock_start_crawl("j-5")
            _mock_stream("j-5", [
                {"url": "https://e.com", "markdown": "content"},
                {"status": "completed"},
            ])

            received: list[str] = []
            completed = []
            with DataBlue(**_CONFIG) as client:
                client.crawl_stream_with_callback(
                    "https://example.com",
                    on_document=lambda p: received.append(p.url),
                    on_complete=lambda: completed.append(True),
                    max_pages=5,
                )

            assert received == ["https://e.com"]
            assert completed == [True]

    def test_crawl_stream_with_callback_error_handler(self):
        """on_error callback catches exceptions instead of raising."""
        with respx.mock:
            _mock_start_crawl("j-6")
            _mock_stream("j-6", [
                {"status": "error", "error": "boom"},
            ])

            errors: list[Exception] = []
            with DataBlue(**_CONFIG) as client:
                client.crawl_stream_with_callback(
                    "https://example.com",
                    on_document=lambda p: None,
                    on_error=lambda e: errors.append(e),
                )

            assert len(errors) == 1
            assert isinstance(errors[0], JobFailedError)
            assert "boom" in str(errors[0])

    def test_crawl_stream_with_callback_reraises_without_on_error(self):
        """Without on_error, exceptions propagate."""
        with respx.mock:
            _mock_start_crawl("j-7")
            _mock_stream("j-7", [
                {"status": "error", "error": "fatal"},
            ])

            with DataBlue(**_CONFIG) as client:
                with pytest.raises(JobFailedError, match="fatal"):
                    client.crawl_stream_with_callback(
                        "https://example.com",
                        on_document=lambda p: None,
                    )

    def test_stream_passes_crawl_kwargs(self):
        """crawl_stream forwards kwargs to start_crawl."""
        with respx.mock:
            route = respx.post(f"{_API}/v1/crawl").mock(
                return_value=httpx.Response(
                    200,
                    json={"success": True, "job_id": "j-8", "status": "started"},
                )
            )
            _mock_stream("j-8", [{"status": "completed"}])

            with DataBlue(**_CONFIG) as client:
                list(client.crawl_stream(
                    "https://example.com",
                    max_pages=42,
                    max_depth=5,
                    include_paths=["/blog/*"],
                ))

            # Verify kwargs were sent in the POST body
            body = json.loads(route.calls[0].request.content)
            assert body["max_pages"] == 42
            assert body["max_depth"] == 5
            assert body["include_paths"] == ["/blog/*"]


# ---------------------------------------------------------------------------
# Async tests
# ---------------------------------------------------------------------------


class TestAsyncCrawlStream:
    @pytest.mark.asyncio
    async def test_basic_stream(self):
        """Async crawl_stream yields CrawlPageData objects."""
        with respx.mock:
            _mock_start_crawl("aj-1")
            _mock_stream("aj-1", [
                {"url": "https://async-a.com", "markdown": "# Async A"},
                {"url": "https://async-b.com", "markdown": "# Async B"},
                {"status": "completed"},
            ])

            async with AsyncDataBlue(**_CONFIG) as client:
                pages = [page async for page in client.crawl_stream("https://example.com")]

            assert len(pages) == 2
            assert pages[0].url == "https://async-a.com"
            assert pages[1].markdown == "# Async B"

    @pytest.mark.asyncio
    async def test_stream_error_raises(self):
        """Async error terminal raises JobFailedError."""
        with respx.mock:
            _mock_start_crawl("aj-2")
            _mock_stream("aj-2", [
                {"status": "error", "error": "Async failure"},
            ])

            async with AsyncDataBlue(**_CONFIG) as client:
                with pytest.raises(JobFailedError, match="Async failure"):
                    async for _ in client.crawl_stream("https://example.com"):
                        pass

    @pytest.mark.asyncio
    async def test_crawl_stream_with_callback(self):
        """Async callback variant fires per page."""
        with respx.mock:
            _mock_start_crawl("aj-3")
            _mock_stream("aj-3", [
                {"url": "https://cb.com", "markdown": "callback"},
                {"status": "completed"},
            ])

            received: list[str] = []
            completed = []
            async with AsyncDataBlue(**_CONFIG) as client:
                await client.crawl_stream_with_callback(
                    "https://example.com",
                    on_document=lambda p: received.append(p.url),
                    on_complete=lambda: completed.append(True),
                )

            assert received == ["https://cb.com"]
            assert completed == [True]

    @pytest.mark.asyncio
    async def test_callback_error_handler(self):
        """Async on_error catches exceptions."""
        with respx.mock:
            _mock_start_crawl("aj-4")
            _mock_stream("aj-4", [
                {"status": "error", "error": "async boom"},
            ])

            errors: list[Exception] = []
            async with AsyncDataBlue(**_CONFIG) as client:
                await client.crawl_stream_with_callback(
                    "https://example.com",
                    on_document=lambda p: None,
                    on_error=lambda e: errors.append(e),
                )

            assert len(errors) == 1
            assert isinstance(errors[0], JobFailedError)
