from __future__ import annotations

import pytest

from datablue.models import (
    ActionStep,
    CrawlJob,
    CrawlStatus,
    ExtractConfig,
    LinkResult,
    MapResult,
    PageData,
    PageMetadata,
    ScrapeResult,
    SearchResult,
    SearchResultItem,
    SearchStatus,
)


class TestPageMetadata:
    def test_minimal(self):
        m = PageMetadata()
        assert m.title is None
        assert m.word_count == 0

    def test_full(self):
        m = PageMetadata(
            title="Test",
            description="A page",
            language="en",
            status_code=200,
            word_count=500,
            reading_time_seconds=120,
        )
        assert m.title == "Test"
        assert m.status_code == 200


class TestPageData:
    def test_markdown_output(self):
        p = PageData(url="https://example.com", markdown="# Hello")
        assert p.markdown == "# Hello"
        assert p.url == "https://example.com"

    def test_to_dict(self):
        p = PageData(url="https://example.com", markdown="# Hello")
        d = p.model_dump()
        assert d["url"] == "https://example.com"
        assert d["markdown"] == "# Hello"


class TestScrapeResult:
    def test_from_api_response(self):
        r = ScrapeResult(
            success=True,
            data=PageData(url="https://example.com", markdown="content"),
        )
        assert r.success is True
        assert r.data.markdown == "content"

    def test_error_code(self):
        r = ScrapeResult(success=False, error="blocked", error_code="BLOCKED_BY_WAF")
        assert r.error_code == "BLOCKED_BY_WAF"

    def test_job_id(self):
        r = ScrapeResult(success=True, job_id="j-123")
        assert r.job_id == "j-123"


class TestCrawlStatus:
    def test_completed(self):
        s = CrawlStatus(
            job_id="j-123",
            status="completed",
            total_pages=10,
            completed_pages=10,
            data=[],
        )
        assert s.is_complete is True
        assert s.progress == 1.0

    def test_in_progress(self):
        s = CrawlStatus(
            job_id="j-123",
            status="running",
            total_pages=10,
            completed_pages=3,
        )
        assert s.is_complete is False
        assert s.progress == pytest.approx(0.3)

    def test_zero_total_pages(self):
        s = CrawlStatus(job_id="j-123", status="started", total_pages=0, completed_pages=0)
        assert s.progress == 0.0

    def test_pagination_fields(self):
        s = CrawlStatus(job_id="j-123", status="completed", total_results=50, page=2, per_page=20)
        assert s.total_results == 50
        assert s.page == 2
        assert s.per_page == 20


class TestSearchStatus:
    def test_completed(self):
        s = SearchStatus(
            job_id="s-123",
            status="completed",
            query="test",
            total_results=5,
            completed_results=5,
            data=[],
        )
        assert s.is_complete is True


class TestSearchResultItem:
    def test_full_fields(self):
        item = SearchResultItem(
            id="r-1",
            url="https://example.com",
            title="Example",
            snippet="A snippet",
            markdown="# Example",
            success=True,
        )
        assert item.id == "r-1"
        assert item.markdown == "# Example"


class TestMapResult:
    def test_links(self):
        r = MapResult(success=True, total=2, links=[
            LinkResult(url="https://a.com"),
            LinkResult(url="https://b.com"),
        ])
        assert len(r.links) == 2
        assert r.urls == ["https://a.com", "https://b.com"]

    def test_job_id(self):
        r = MapResult(success=True, total=0, job_id="m-123")
        assert r.job_id == "m-123"


class TestActionStep:
    def test_click(self):
        a = ActionStep(type="click", selector="#btn")
        assert a.type == "click"
        assert a.selector == "#btn"

    def test_wait(self):
        a = ActionStep(type="wait", milliseconds=2000)
        assert a.milliseconds == 2000


class TestExtractConfig:
    def test_with_schema(self):
        e = ExtractConfig(prompt="Extract data", schema={"type": "object"})
        assert e.prompt == "Extract data"
