from __future__ import annotations

import pytest

from datablue.exceptions import (
    AuthenticationError,
    DataBlueError,
    JobFailedError,
    NotFoundError,
    RateLimitError,
    ServerError,
    TimeoutError,
)


class TestExceptionHierarchy:
    def test_all_exceptions_inherit_from_base(self):
        for exc_cls in [
            AuthenticationError,
            NotFoundError,
            RateLimitError,
            ServerError,
            JobFailedError,
            TimeoutError,
        ]:
            assert issubclass(exc_cls, DataBlueError)

    def test_base_error_attributes(self):
        err = DataBlueError("something broke", status_code=500, response_body={"error": "oops"})
        assert str(err) == "something broke"
        assert err.status_code == 500
        assert err.response_body == {"error": "oops"}

    def test_base_error_defaults(self):
        err = DataBlueError("bare error")
        assert err.status_code is None
        assert err.response_body is None
        assert err.is_retryable is False
        assert err.retry_after is None
        assert err.docs_url is None


class TestRateLimitError:
    def test_retry_after(self):
        err = RateLimitError("slow down", retry_after=30)
        assert err.retry_after == 30
        assert err.is_retryable is True
        assert err.status_code == 429

    def test_docs_url(self):
        err = RateLimitError("slow down", retry_after=10)
        assert err.docs_url == "https://docs.datablue.dev/errors/rate-limit"


class TestServerError:
    def test_is_retryable(self):
        err = ServerError("internal error", status_code=502)
        assert err.is_retryable is True


class TestJobFailedError:
    def test_job_id_attribute(self):
        err = JobFailedError("job failed", job_id="abc-123")
        assert err.job_id == "abc-123"


class TestTimeoutError:
    def test_elapsed_attribute(self):
        err = TimeoutError("timed out", job_id="abc-123", elapsed=300.5)
        assert err.job_id == "abc-123"
        assert err.elapsed == 300.5
