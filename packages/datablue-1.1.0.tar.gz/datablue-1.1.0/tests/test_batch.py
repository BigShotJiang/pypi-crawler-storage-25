from __future__ import annotations

import httpx
import pytest
import respx

from datablue import AsyncDataBlue, DataBlue


class TestBatchScrapeSync:
    def test_batch_scrape_returns_results(self):
        with respx.mock:
            respx.post("http://test:8000/v1/scrape").mock(
                side_effect=[
                    httpx.Response(200, json={
                        "success": True,
                        "data": {"url": "https://a.com", "markdown": "content 0"},
                    }),
                    httpx.Response(200, json={
                        "success": True,
                        "data": {"url": "https://b.com", "markdown": "content 1"},
                    }),
                    httpx.Response(200, json={
                        "success": True,
                        "data": {"url": "https://c.com", "markdown": "content 2"},
                    }),
                ]
            )
            with DataBlue(api_url="http://test:8000", api_key="wh_test") as client:
                results = client.batch_scrape([
                    "https://a.com", "https://b.com", "https://c.com",
                ])
                assert len(results) == 3
                assert all(r.success for r in results)

    def test_batch_scrape_handles_errors(self):
        with respx.mock:
            respx.post("http://test:8000/v1/scrape").mock(
                side_effect=[
                    httpx.Response(200, json={
                        "success": True,
                        "data": {"url": "https://a.com", "markdown": "ok"},
                    }),
                    httpx.Response(500, json={"detail": "Server error"}),
                ]
            )
            with DataBlue(api_url="http://test:8000", api_key="wh_test", max_retries=0) as client:
                results = client.batch_scrape(["https://a.com", "https://b.com"])
                assert len(results) == 2
                assert results[0].success is True
                assert results[1].success is False
                assert results[1].error is not None

    def test_batch_scrape_empty_urls(self):
        with respx.mock:
            with DataBlue(api_url="http://test:8000", api_key="wh_test") as client:
                results = client.batch_scrape([])
                assert results == []


class TestBatchScrapeAsync:
    @pytest.mark.asyncio
    async def test_batch_scrape_returns_all(self):
        with respx.mock:
            respx.post("http://test:8000/v1/scrape").mock(
                side_effect=[
                    httpx.Response(200, json={
                        "success": True,
                        "data": {"url": "https://a.com", "markdown": "content"},
                    }),
                    httpx.Response(200, json={
                        "success": True,
                        "data": {"url": "https://b.com", "markdown": "content"},
                    }),
                ]
            )
            async with AsyncDataBlue(api_url="http://test:8000", api_key="wh_test") as client:
                results = await client.batch_scrape(["https://a.com", "https://b.com"], concurrency=2)
                assert len(results) == 2
                assert all(r.success for r in results)

    @pytest.mark.asyncio
    async def test_batch_scrape_iter(self):
        with respx.mock:
            respx.post("http://test:8000/v1/scrape").mock(
                side_effect=[
                    httpx.Response(200, json={
                        "success": True,
                        "data": {"url": "https://a.com", "markdown": "content"},
                    }),
                    httpx.Response(200, json={
                        "success": True,
                        "data": {"url": "https://b.com", "markdown": "content"},
                    }),
                ]
            )
            results = []
            async with AsyncDataBlue(api_url="http://test:8000", api_key="wh_test") as client:
                async for result in client.batch_scrape_iter(["https://a.com", "https://b.com"], concurrency=2):
                    results.append(result)
            assert len(results) == 2
