from __future__ import annotations

import os

import pytest

from datablue.config import ClientConfig


class TestClientConfig:
    def test_defaults(self):
        cfg = ClientConfig()
        assert cfg.api_url == "http://localhost:8000"
        assert cfg.api_key is None
        assert cfg.timeout == 60.0
        assert cfg.max_retries == 3
        assert cfg.backoff_factor == 0.5

    def test_custom_values(self):
        cfg = ClientConfig(
            api_url="https://api.datablue.dev",
            api_key="wh_abc123",
            timeout=30.0,
            max_retries=5,
        )
        assert cfg.api_url == "https://api.datablue.dev"
        assert cfg.api_key == "wh_abc123"
        assert cfg.timeout == 30.0
        assert cfg.max_retries == 5

    def test_immutable(self):
        cfg = ClientConfig()
        with pytest.raises(Exception):
            cfg.api_url = "http://other"  # type: ignore[misc]

    def test_clone_override(self):
        cfg = ClientConfig(api_url="http://a", timeout=10.0)
        cfg2 = cfg.clone(timeout=30.0)
        assert cfg.timeout == 10.0  # original unchanged
        assert cfg2.timeout == 30.0
        assert cfg2.api_url == "http://a"  # inherited

    def test_clone_no_changes(self):
        cfg = ClientConfig(api_key="wh_key")
        cfg2 = cfg.clone()
        assert cfg2.api_key == "wh_key"
        assert cfg is not cfg2  # different objects

    def test_from_env(self, monkeypatch: pytest.MonkeyPatch):
        monkeypatch.setenv("DATABLUE_API_URL", "https://custom.api")
        monkeypatch.setenv("DATABLUE_API_KEY", "wh_env_key")
        cfg = ClientConfig.from_env()
        assert cfg.api_url == "https://custom.api"
        assert cfg.api_key == "wh_env_key"

    def test_from_env_defaults(self, monkeypatch: pytest.MonkeyPatch):
        monkeypatch.delenv("DATABLUE_API_URL", raising=False)
        monkeypatch.delenv("DATABLUE_API_KEY", raising=False)
        cfg = ClientConfig.from_env()
        assert cfg.api_url == "http://localhost:8000"
        assert cfg.api_key is None

    def test_trailing_slash_stripped(self):
        cfg = ClientConfig(api_url="http://localhost:8000/")
        assert cfg.api_url == "http://localhost:8000"
