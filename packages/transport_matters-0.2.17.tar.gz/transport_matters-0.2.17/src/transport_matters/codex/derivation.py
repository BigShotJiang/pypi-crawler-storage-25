"""Compatibility exports for Codex turn derivation."""

from __future__ import annotations

from transport_matters.codex.derivation_codec import (
    serialize_codex_events_jsonl,
    serialize_codex_turn_json,
)
from transport_matters.codex.derivation_contract import (
    CODEX_DERIVATION_VERSION,
    CODEX_EVENT_ID_PREFIX,
    CODEX_EVENT_ID_WIDTH,
    CODEX_INITIAL_EVENT_SEQ,
    SUPPORTED_CODEX_DERIVATION_VERSIONS,
    CodexDerivationOperatorFact,
    CodexDerivationOperatorFactKind,
    CodexDerivationVersion,
    CodexDerivedTurnArtifacts,
    CodexIncrementalAdvanceRequest,
    CodexReplayRequest,
    CodexTransportCloseFact,
    CodexTransportDirection,
    CodexTransportMessageFact,
    CodexTurnDerivationContext,
    UnsupportedCodexDerivationVersionError,
    codex_event_id_for_seq,
    codex_event_ts,
    codex_next_event_seq,
    is_supported_codex_derivation_version,
    require_supported_codex_derivation_version,
)
from transport_matters.codex.derivation_engine import (
    derive_codex_turn_incremental,
    derive_codex_turn_replay,
)

__all__ = [
    "CODEX_DERIVATION_VERSION",
    "CODEX_EVENT_ID_PREFIX",
    "CODEX_EVENT_ID_WIDTH",
    "CODEX_INITIAL_EVENT_SEQ",
    "SUPPORTED_CODEX_DERIVATION_VERSIONS",
    "CodexDerivationOperatorFact",
    "CodexDerivationOperatorFactKind",
    "CodexDerivationVersion",
    "CodexDerivedTurnArtifacts",
    "CodexIncrementalAdvanceRequest",
    "CodexReplayRequest",
    "CodexTransportDirection",
    "CodexTransportCloseFact",
    "CodexTransportMessageFact",
    "CodexTurnDerivationContext",
    "UnsupportedCodexDerivationVersionError",
    "codex_event_id_for_seq",
    "codex_event_ts",
    "codex_next_event_seq",
    "derive_codex_turn_incremental",
    "derive_codex_turn_replay",
    "is_supported_codex_derivation_version",
    "require_supported_codex_derivation_version",
    "serialize_codex_events_jsonl",
    "serialize_codex_turn_json",
]
