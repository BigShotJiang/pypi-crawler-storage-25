"""
PyActionNet - Python implementation of ActionNet P2P.

1:1 with the JavaScript ActionNet library:
- DataConnection: RTCPeerConnection wrapper
- ActionNetPeer: wraps DataConnection, handles signaling
- ActionNetTrackerClient: tracker WebSocket, peer discovery
"""
import asyncio
import hashlib
import json
import logging
import uuid
from typing import Any, Callable, Optional

import websockets

log = logging.getLogger("pyactionnet")

ICE_SERVERS = [
    {"urls": "stun:stun.l.google.com:19302"},
    {"urls": "stun:stun1.l.google.com:19302"},
]

TRACKER_URLS = [
    "wss://tracker.openwebtorrent.com/",
    "wss://tracker.btorrent.xyz/",
    "wss://tracker.fastcast.nz/",
]


class DataConnection:
    """
    DataConnection - App Data Layer (1:1 with JS DataConnection.js)
    """
    
    def __init__(
        self,
        local_peer_id: str = "local",
        remote_peer_id: str = "remote",
        initiator: Optional[bool] = None,
        ice_servers: list = None,
    ):
        self.local_peer_id = local_peer_id
        self.remote_peer_id = remote_peer_id
        self.ice_servers = ice_servers or ICE_SERVERS
        
        if initiator is not None:
            self.is_initiator = initiator
        else:
            self.is_initiator = local_peer_id > remote_peer_id
        
        self.pc = None
        self.data_channel = None
        self.connected = False
        self.ready = False
        
        self._handlers = {}
        self._pending_signal = None
        
        self._setup()
    
    def _setup(self):
        from aiortc import RTCPeerConnection, RTCConfiguration, RTCIceServer
        
        config = RTCConfiguration(
            iceServers=[RTCIceServer(urls=s["urls"]) for s in self.ice_servers]
        )
        self.pc = RTCPeerConnection(config)
        
        @self.pc.on("icecandidate")
        def on_ice_candidate(candidate):
            if candidate:
                self._emit("signal", {
                    "type": "ice-candidate",
                    "candidate": {
                        "candidate": candidate.candidate,
                        "sdpMid": candidate.sdpMid,
                        "sdpMLineIndex": candidate.sdpMLineIndex,
                    }
                })
        
        @self.pc.on("datachannel")
        def on_datachannel(channel):
            self.data_channel = channel
            self._setup_data_channel()
        
        if self.is_initiator:
            asyncio.create_task(self._create_offer())
    
    async def _create_offer(self):
        try:
            self.data_channel = self.pc.createDataChannel("app", ordered=True)
            self._setup_data_channel()
            
            offer = await self.pc.createOffer()
            await self.pc.setLocalDescription(offer)
            
            await self._wait_for_ice()
            
            self._emit("signal", {
                "type": "offer",
                "sdp": self.pc.localDescription.sdp
            })
            
            self.ready = True
        except Exception as e:
            self._emit("error", e)
    
    async def _wait_for_ice(self):
        for _ in range(30):
            if self.pc.iceGatheringState == "complete":
                return
            await asyncio.sleep(0.1)
    
    def _setup_data_channel(self):
        @self.data_channel.on("open")
        def on_open():
            self.connected = True
            self._emit("connect")
        
        @self.data_channel.on("close")
        def on_close():
            self.connected = False
            self._emit("close")
        
        @self.data_channel.on("error")
        def on_error(err):
            self._emit("error", err)
        
        @self.data_channel.on("message")
        def on_message(message):
            try:
                data = json.loads(message)
                self._emit("data", data)
            except json.JSONDecodeError:
                pass
    
    def signal(self, data: dict):
        """Handle incoming offer/answer/ICE."""
        if not self.pc:
            return
        
        if data["type"] == "offer":
            asyncio.create_task(self._handle_offer(data))
        elif data["type"] == "answer":
            from aiortc import RTCSessionDescription
            sdp = RTCSessionDescription(type="answer", sdp=data["sdp"])
            asyncio.create_task(self.pc.setRemoteDescription(sdp))
        elif "candidate" in data:
            from aiortc import RTCIceCandidate
            cand = RTCIceCandidate(
                candidate=data["candidate"]["candidate"],
                sdpMid=data["candidate"].get("sdpMid"),
                sdpMLineIndex=data["candidate"].get("sdpMLineIndex"),
            )
            asyncio.create_task(self.pc.addIceCandidate(cand))
    
    async def _handle_offer(self, data: dict):
        try:
            from aiortc import RTCSessionDescription
            remote_sdp = RTCSessionDescription(type="offer", sdp=data["sdp"])
            await self.pc.setRemoteDescription(remote_sdp)
            
            answer = await self.pc.createAnswer()
            await self.pc.setLocalDescription(answer)
            
            await self._wait_for_ice()
            
            self._emit("signal", {
                "type": "answer",
                "sdp": self.pc.localDescription.sdp
            })
            
            self.ready = True
        except Exception as e:
            self._emit("error", e)
    
    def send(self, message: Any) -> bool:
        """Send a message through the data channel."""
        if not self.connected or not self.data_channel:
            return False
        
        try:
            if isinstance(message, str):
                self.data_channel.send(message)
            else:
                self.data_channel.send(json.dumps(message))
            return True
        except Exception:
            return False
    
    def on(self, event: str, handler: Callable):
        self._handlers.setdefault(event, []).append(handler)
    
    def _emit(self, event: str, *args):
        for cb in self._handlers.get(event, []):
            try:
                cb(*args)
            except Exception as e:
                log.error(f"Handler error on {event}: {e}")
    
    def close(self):
        if self.data_channel:
            self.data_channel.close()
        if self.pc:
            self.pc.close()
        self.connected = False


class ActionNetPeer:
    """
    ActionNetPeer - Wrapper around DataConnection (1:1 with JS ActionNetPeer.js)
    """
    
    def __init__(
        self,
        initiator: bool = False,
        local_peer_id: str = "local",
        remote_peer_id: str = "remote",
        ice_servers: list = None,
    ):
        self.local_peer_id = local_peer_id
        self.remote_peer_id = remote_peer_id
        
        self.connection = DataConnection(
            local_peer_id=local_peer_id,
            remote_peer_id=remote_peer_id,
            initiator=initiator,
            ice_servers=ice_servers,
        )
        
        self.pc = self.connection.pc
        self.data_channel = self.connection.data_channel
        
        self.destroyed = False
        self.handlers = {}
        
        self.connection.on("connect", lambda: self._handle_connect())
        self.connection.on("error", lambda e: self._emit("error", e))
        self.connection.on("close", lambda: self._emit("close"))
        self.connection.on("data", lambda d: self._emit("data", d))
        self.connection.on("signal", lambda s: self._emit("signal", s))
    
    def _handle_connect(self):
        self.connected = True
        self._emit("connect")
    
    def signal(self, data: dict):
        if self.destroyed:
            return
        self.connection.signal(data)
    
    def send(self, data: Any) -> bool:
        if self.destroyed:
            return False
        return self.connection.send(data)
    
    def on(self, event: str, handler: Callable):
        self.handlers.setdefault(event, []).append(handler)
    
    def once(self, event: str, handler: Callable):
        def wrapper(*args):
            handler(*args)
            self.off(event, wrapper)
        self.on(event, wrapper)
    
    def off(self, event: str, handler: Callable):
        if event not in self.handlers:
            return
        self.handlers[event].remove(handler)
    
    def _emit(self, event: str, *args):
        for cb in self.handlers.get(event, []):
            try:
                cb(*args)
            except Exception as e:
                log.error(f"Handler error on {event}: {e}")
    
    def destroy(self):
        if self.destroyed:
            return
        self.destroyed = True
        self.connected = False
        self.connection.close()
        self.pc = None
        self.data_channel = None
        self.handlers.clear()


class ActionNetTrackerClient:
    """
    ActionNetTrackerClient - WebSocket Tracker for Peer Discovery (1:1 with JS)
    """
    
    def __init__(
        self,
        tracker_urls: list = None,
        infohash: str = None,
        peer_id: str = None,
        numwant: int = 50,
        announce_interval: int = 5000,
        ice_servers: list = None,
        debug: bool = False,
    ):
        self.tracker_urls = tracker_urls or TRACKER_URLS
        self.infohash = infohash
        self.peer_id = peer_id or f"peer_{uuid.uuid4().hex[:9]}"
        
        self.numwant = numwant
        self.announce_interval = announce_interval
        self.ice_servers = ice_servers or ICE_SERVERS
        self.debug = debug
        
        self.trackers = {}
        self.outgoing_peers = {}
        self.pending_offers = set()
        self.connected_peer_ids = set()
        
        self.handlers = {}
        self._running = False
    
    async def connect(self):
        self._running = True
        
        tasks = []
        for url in self.tracker_urls:
            tasks.append(self._connect_to_tracker(url))
        
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        connected = sum(1 for r in results if not isinstance(r, Exception))
        if connected == 0:
            raise RuntimeError("Failed to connect to any trackers")
        
        self._log(f"Connected to {connected}/{len(self.tracker_urls)} trackers")
    
    async def _connect_to_tracker(self, tracker_url: str):
        ws = await websockets.connect(tracker_url)
        self.trackers[tracker_url] = {"ws": ws}
        
        self._log(f"Connected to tracker: {tracker_url}")
        
        await self._prepare_first_peer(tracker_url, ws)
        
        self._log("First peer ready, starting announces")
        self.emit("ready")
        
        asyncio.create_task(self._listen_to_tracker(tracker_url, ws))
        self.start_announcing(tracker_url, ws)
    
    async def _prepare_first_peer(self, tracker_url: str, ws):
        offer_id = self._generate_offer_id()
        
        peer = ActionNetPeer(
            initiator=True,
            local_peer_id=self.peer_id,
            remote_peer_id="tracker",
            ice_servers=self.ice_servers,
        )
        
        def on_signal(data):
            if data.get("type") == "offer":
                self.outgoing_peers[offer_id] = {
                    "peer": peer,
                    "peer_id": self.peer_id,
                    "offer_id": offer_id,
                }
                asyncio.create_task(self._announce_with_offer(tracker_url, ws, offer_id, data))
        
        peer.on("signal", on_signal)
    
    async def _announce_with_offer(self, tracker_url: str, ws, offer_id: str, offer: dict):
        self.pending_offers.add(offer_id)
        
        request = {
            "action": "announce",
            "info_hash": self.infohash,
            "peer_id": self.peer_id,
            "numwant": self.numwant,
            "offers": [{"offer_id": offer_id, "offer": offer}],
        }
        
        try:
            await ws.send(json.dumps(request))
            self._log(f"Announced with offer {offer_id}")
        except Exception as e:
            self._log(f"Announce error: {e}")
        
        self.pending_offers.discard(offer_id)
        
        asyncio.create_task(self._schedule_announce(tracker_url, ws))
    
    async def _schedule_announce(self, tracker_url: str, ws):
        await asyncio.sleep(self.announce_interval / 1000)
        if self._running:
            asyncio.create_task(self._do_announce(tracker_url, ws))
    
    def start_announcing(self, tracker_url: str, ws):
        asyncio.create_task(self._schedule_announce(tracker_url, ws))
    
    async def _do_announce(self, tracker_url: str, ws):
        if ws.closed:
            return
        
        try:
            if self.pending_offers:
                request = {
                    "action": "announce",
                    "info_hash": self.infohash,
                    "peer_id": self.peer_id,
                    "numwant": self.numwant,
                }
                await ws.send(json.dumps(request))
                self._log("Announced (re-using offer)")
            else:
                offer_id = self._generate_offer_id()
                peer = ActionNetPeer(
                    initiator=True,
                    local_peer_id=self.peer_id,
                    remote_peer_id="tracker",
                    ice_servers=self.ice_servers,
                )
                
                offer = await self._wait_for_signal(peer, "offer")
                self.outgoing_peers[offer_id] = {
                    "peer": peer,
                    "peer_id": self.peer_id,
                    "offer_id": offer_id,
                }
                await self._announce_with_offer(tracker_url, ws, offer_id, offer)
        except Exception as e:
            self._log(f"Announce error: {e}")
    
    async def _wait_for_signal(self, peer: ActionNetPeer, expected_type: str):
        future = asyncio.Future()
        
        def handler(data):
            if data.get("type") == expected_type and not future.done():
                future.set_result(data)
        
        peer.on("signal", handler)
        
        try:
            return await asyncio.wait_for(future, timeout=10)
        except asyncio.TimeoutError:
            peer.destroy()
            raise RuntimeError(f"Timeout waiting for {expected_type}")
    
    async def _listen_to_tracker(self, tracker_url: str, ws):
        try:
            async for raw in ws:
                msg = json.loads(raw)
                self._handle_tracker_message(msg)
        except websockets.exceptions.ConnectionClosed:
            self._log(f"Tracker disconnected: {tracker_url}")
            if tracker_url in self.trackers:
                del self.trackers[tracker_url]
            if not self.trackers:
                self.emit("close")
                self.stop()
        except Exception as e:
            self._log(f"Tracker error: {e}")
            self.emit("error", e)
    
    def _handle_tracker_message(self, msg: dict):
        self._log(f"Tracker message: {msg.get('action', 'unknown')}")
        
        if msg.get("offer") and msg.get("peer_id"):
            self._handle_peer_offer(msg)
        elif msg.get("answer") and msg.get("peer_id"):
            self._handle_peer_answer(msg)
        elif msg.get("failure reason"):
            self._log(f"Tracker failure: {msg['failure reason']}")
        elif msg.get("action") == "announce":
            complete = msg.get("complete", 0)
            incomplete = msg.get("incomplete", 0)
            self.emit("update", {"complete": complete, "incomplete": incomplete})
    
    def _handle_peer_offer(self, msg: dict):
        peer_id = msg["peer_id"]
        offer_id = msg.get("offer_id", "unknown")
        offer = msg["offer"]
        
        if peer_id in self.connected_peer_ids:
            self._log(f"Already connected to peer: {peer_id}")
            return
        
        peer = ActionNetPeer(
            initiator=False,
            local_peer_id=self.peer_id,
            remote_peer_id=peer_id,
            ice_servers=self.ice_servers,
        )
        
        self.outgoing_peers[offer_id] = {
            "peer": peer,
            "peer_id": peer_id,
            "offer_id": offer_id,
        }
        
        def on_signal(data):
            if data.get("type") == "answer":
                self._send_answer(offer_id, peer_id, data)
        
        peer.on("signal", on_signal)
        
        @peer.on("connect")
        def on_connect():
            self.connected_peer_ids.add(peer_id)
            self.emit("connection", peer.connection)
        
        @peer.on("close")
        def on_close():
            if offer_id in self.outgoing_peers:
                del self.outgoing_peers[offer_id]
            self.connected_peer_ids.discard(peer_id)
            self.emit("peer-disconnected", {"id": peer_id})
        
        peer.signal(offer)
    
    def _handle_peer_answer(self, msg: dict):
        peer_id = msg["peer_id"]
        offer_id = msg.get("offer_id")
        answer = msg["answer"]
        
        if not offer_id or offer_id not in self.outgoing_peers:
            self._log(f"Got answer for unknown offer: {offer_id}")
            return
        
        peer_data = self.outgoing_peers[offer_id]
        peer = peer_data["peer"]
        
        self.pending_offers.discard(offer_id)
        
        peer.signal(answer)
        
        @peer.on("connect")
        def on_connect():
            self.connected_peer_ids.add(peer_id)
            self.emit("connection", peer.connection)
        
        @peer.on("close")
        def on_close():
            if offer_id in self.outgoing_peers:
                del self.outgoing_peers[offer_id]
            self.connected_peer_ids.discard(peer_id)
            self.emit("peer-disconnected", {"id": peer_id})
    
    def _send_answer(self, offer_id: str, peer_id: str, answer: dict):
        response = {
            "action": "announce",
            "info_hash": self.infohash,
            "peer_id": self.peer_id,
            "to_peer_id": peer_id,
            "offer_id": offer_id,
            "answer": answer,
        }
        
        for tracker_data in self.trackers.values():
            ws = tracker_data["ws"]
            if not ws.closed:
                asyncio.create_task(ws.send(json.dumps(response)))
    
    def _generate_offer_id(self):
        return uuid.uuid4().hex[:20]
    
    def on(self, event: str, handler: Callable):
        self.handlers.setdefault(event, []).append(handler)
    
    def emit(self, event: str, *args):
        for cb in self.handlers.get(event, []):
            try:
                cb(*args)
            except Exception as e:
                log.error(f"Handler error on {event}: {e}")
    
    def stop(self):
        self._running = False
    
    def disconnect(self):
        self.stop()
        for tracker_data in self.trackers.values():
            ws = tracker_data.get("ws")
            if ws:
                asyncio.create_task(ws.close())
        self.trackers.clear()
    
    def _log(self, msg: str):
        if self.debug:
            log.info(f"[TrackerClient] {msg}")


