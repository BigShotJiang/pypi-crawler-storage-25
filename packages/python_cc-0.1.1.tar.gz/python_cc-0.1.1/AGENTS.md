# AGENTS.md

This file is for humans and AI agents working in this repository.

## Project Summary

`pcc` is primarily a C compiler implemented in Python on top of
`pycparser`, LLVM (`llvmlite` and now `pcc/llvm_capi`), and a
lightweight fake-libc layer. The C path is still the most mature part of
the repository, but the repo now also contains an experimental Python
frontend (`pcc/py_frontend/` + `pcc/py_runtime/`) and an active
self-host/bootstrap track. Most fixes in this repository are not parser
bugs; they are semantic bugs that only show up when expressions are
combined, lowered to LLVM IR, and then exercised by real programs.

The fastest way to get useful results is:

1. Reproduce with a tiny C program when possible.
2. Compare against a native compiler built from the same source.
3. Add one small regression test and one realistic integration confirmation.
4. Do not consider a real-project bug "fixed" until the minimized regression
   exists in `tests/` and passes without the project harness.

The fastest way to create expensive regressions is the opposite:

1. touch `c_codegen.py` or parser code with a broad speculative change
2. skip the smallest reproducer
3. delay regression checks until after several edits have stacked up

Do not do that here.


## Environment Rules

- Use `uv run ...` for Python entrypoints. Do not rely on bare `python`; local `pyenv` state may not match the repository.
- **Codex-specific**: Codex sets `LC_ALL=C` which can break Python locale handling. Unset it with `env -u LC_ALL` before running commands. See https://github.com/openai/codex/issues/14723. Not needed for Claude Code or other agents.

```bash
# Codex only:
env -u LC_ALL uv run pytest -q
env -u LC_ALL uv run pcc hello.c
# Claude Code / others:
uv run pytest -q
uv run pcc hello.c
```

- While debugging one failure, prefer `-n0` so xdist does not hide ordering or temp-file problems.
- Use ripgrep (`rg`), or your agent's built-in code search tools (e.g. Grep/Glob in Claude Code) for source discovery.
- Do not leave temporary `.c` files inside real project directories. Directory-based source collection can accidentally compile them.
- **Always cap probe / experimental binaries with a hard timeout.** When you compile a one-shot `/tmp/<name>` probe and run it (especially a self-host stage binary that might infinite-loop), wrap the run with `timeout 30s ./tmp_probe` or equivalent. Found 2026-04-26: 4 zombie `pq_probe_stage_*_self` processes from a codex session pegged 100% CPU each for 33 hours (~120 CPU-hours wasted) — they were started without a timeout and the agent moved on without verifying termination. Before ending a session, always `ps aux | grep <your-probe-name>` and `kill` any leftover children. Probe binaries that hang are *expected* during compiler bring-up; the leak is not.


## Repository Map

- `pcc/pcc.py`
  Command-line entrypoint.
- `pcc/project.py`
  Directory collection, `--sources-from-make`, and translation-unit selection.
- `pcc/evaluater/c_evaluator.py`
  Preprocessing, parsing, IR generation, LLVM parsing, optimization, and execution.
- `pcc/codegen/c_codegen.py`
  Main semantic lowering logic. Most tricky C correctness bugs land here.
- `pcc/py_frontend/`
  Experimental Python frontend. Type inference, Python lowering, and most
  self-host blockers live here.
- `pcc/py_runtime/`
  Native runtime support for the Python frontend.
- `pcc/llvm_capi/`
  In-repo LLVM builder/binding replacement path. Useful both for
  self-host work and for isolating `llvmlite` vs native LLVM-C behavior.
- `utils/fake_libc_include/`
  Fake libc headers. Bugs here usually look like host ABI or declaration mismatches.
- `tests/`
  Fast regression coverage. Add small tests here for every semantic fix.
- `tests/py_corpus/`
  End-to-end Python frontend corpus. Use this when validating Python-path
  behavior beyond a minimized unit test.
- `scripts/pcc_multi.py`
  Experimental multi-file Python entrypoint used by the bootstrap track.
- `projects/lua-5.5.0/`
  Real-program stress target. Very effective for catching interactions missed by unit tests.


## Python Frontend / Bootstrap Notes

The Python frontend is a separate subsystem from the mature C path. Do
not assume a C-side debugging rule automatically covers Python lowering,
runtime fallback, or bootstrap behavior.

- Single-file Python entry:
  `env -u LC_ALL uv run pcc foo.py`
- Multi-file/bootstrap entry:
  `env -u LC_ALL uv run python scripts/pcc_multi.py --entry pkg.main --out out_bin pkg/main.py ...`
- `pcc/llvm_capi/` is the active in-repo LLVM replacement path; `llvmlite`
  is still available as a fallback/comparison path for regression
  isolation.
- Current verified Issue 1 metric: the stage1 tight multi-file closure
  in `--ir-scaffold=on` has zero `py_cpy_*` call instructions, guarded
  by `tests/fallback_baseline.json`. This is necessary but not sufficient
  for closing Issue 1.
- The remaining Issue 1 close criterion is a real link gate: build the
  stage1 bootstrap binary with libpython disabled and verify there are
  no unresolved `Py*` / `py_cpy_*` symbols. Do not describe the current
  path as pure self-host until that link-without-libpython property has
  been re-verified in the current tree.
- Some bootstrap host queries intentionally use host-tool subprocess
  boundaries (`PCC_HOST_PYTHON` or `python3`) instead of in-process
  libpython calls. In particular, `_link_with_self_backend` must not
  reintroduce compiled-stage imports/calls of `pcc.backend.*`; doing so
  brings `py_cpy_*` back into the stage1 closure. The long-term target
  is to compile those backend modules natively, not to grow in-process
  CPython fallback again.
- When touching Python frontend or bootstrap-shared code, run the narrow
  dedicated gates first:

```bash
env -u LC_ALL uv run pytest tests/test_py_multi_file_compile.py tests/test_py_multi_file_bootstrap_shim.py -q -n0
env -u LC_ALL uv run pytest tests/test_llvm_capi_ir_parity.py tests/test_llvm_capi_end_to_end.py -q -n0
env -u LC_ALL uv run pytest tests/test_fallback_baseline.py tests/test_ir_py_fallback_baseline.py -q -n0
```


## Source Collection Modes

The repository has multiple ways to compile projects. Be explicit about which one you are debugging.

- Single-file mode:
  Compile exactly one `.c` file.
- Merged directory mode:
  The default directory path behavior. It concatenates selected `.c` files into one large translation unit.
- `--separate-tus`:
  Compile each `.c` as its own translation unit, then link at the LLVM/module layer.
- `--sources-from-make GOAL`:
  Use `make -nB GOAL` to discover which `.c` files belong to a target.
  It can also recover common preprocessor flags from real compile commands, but
  only if the build system actually emits them. It cannot infer compatibility
  flags that exist only in documentation, headers, or repository conventions.

For Lua, these are the most useful entrypoints:

```bash
env -u LC_ALL uv run pcc --cpp-arg=-DLUA_USE_JUMPTABLE=0 --cpp-arg=-DLUA_NOBUILTIN projects/lua-5.5.0/onelua.c -- projects/lua-5.5.0/testes/math.lua
env -u LC_ALL uv run pcc --cpp-arg=-DLUA_USE_JUMPTABLE=0 --cpp-arg=-DLUA_NOBUILTIN --sources-from-make lua projects/lua-5.5.0 -- projects/lua-5.5.0/testes/math.lua
env -u LC_ALL uv run pcc --cpp-arg=-DLUA_USE_JUMPTABLE=0 --cpp-arg=-DLUA_NOBUILTIN --separate-tus --sources-from-make lua projects/lua-5.5.0 -- projects/lua-5.5.0/testes/math.lua
```


## Debugging Playbook

### 1. Make the failure deterministic

Do not start by reading all of `c_codegen.py`. First make the failure repeatable.

Examples:

- fix the random seed
- replace filesystem/time input with constants
- run with `-n0`
- isolate one test file instead of a whole suite

If the failure is random, your first job is to remove randomness from the reproduction, not to guess the cause.


### 2. Compare `pcc` against native from the same source

When the bug appears in a real program:

1. Compile the same source with `pcc`
2. Compile the same source with the system C compiler
3. Compare behavior, not assumptions

This separates "the program is odd" from "the compiler lowered it incorrectly".


### 2a. Use `llvmlite` as an oracle for `llvm_capi` parity

If the failure looks like a codegen / IR-builder regression in
`pcc/llvm_capi/`, do not guess blindly. Re-run the same minimized repro with
the `llvmlite` backend and use that as the oracle.

The switch is:

```bash
PCC_USE_LLVMLITE_C=1 env -u LC_ALL uv run pytest 'tests/test_clang_compat.py::test_unsigned_int_to_float_conversion_uses_unsigned_semantics' -q -n0
```

Use this workflow:

1. shrink the failure to the smallest C repro or single pytest node
2. run it under the default `llvm_capi` path
3. run the exact same repro with `PCC_USE_LLVMLITE_C=1`
4. compare compile result, runtime result, and when needed the emitted IR
5. patch only the smallest semantic gap in `pcc/llvm_capi` or codegen
6. add one focused regression test before moving on

This is especially effective for:

- missing `IRBuilder` ops such as `uitofp`, `fptoui`, `fpext`, or `fneg`
- constant `gep` / `bitcast` expression lowering
- typed-pointer semantics hidden by opaque `ptr`
- function-type / function-pointer decay mismatches

Do **not** assume `llvmlite` is the oracle for everything. It is a good oracle
for backend parity bugs, but not for:

- system preprocessor behavior
- fake-libc or header rewrite policy
- compile-only diagnostics policy
- parser acceptance / rejection mismatches

If both backends fail the same minimized repro, the bug is probably above the
backend layer and you should move back to parser, preprocessor, headers, or
semantic lowering.


### 3. Shrink the reproducer in stages

A productive sequence is:

1. failing integration test
2. smaller script or input
3. small C harness that calls the same internal code path
4. pure C expression or arithmetic reproducer

Do not stop at step 1 if the failure is deep in semantics. The time you spend shrinking the reproducer is usually returned many times over during diagnosis.


### 4. Test hypotheses by substitution, not only by inspection

If a large function is suspect:

- copy it into a temporary harness
- replace one helper at a time with the real implementation
- reintroduce branches incrementally

This is often faster than staring at 500 lines of codegen or IR.


### 4a. Do not waste time on avoidable harness mistakes

Some failures in this repository come from the test harness or shell usage, not
from `pcc` itself.

Rules:

- When running a single pytest node id that contains `[` or `]`, always quote
  it. `zsh` will treat it as a glob otherwise.
- Do not use `uv run python - <<'PY' ...` or other stdin-backed Python entry
  points when the code path uses `multiprocessing` with spawn. On macOS this can
  fail with `FileNotFoundError` for `<stdin>` and produce fake compiler
  failures. Use a real file path or drive the behavior through pytest.
- If a manifest says "native passes, pcc fails" or similar, rerun the case
  through the current harness before debugging `pcc`. These manifests drift.
  A stale bucket is a test-data bug, not a compiler bug.
- If you change parser grammar or lexer token sets, bump the default PLY cache
  version in [`pcc/parse/c_parser.py`](/Users/jiamo/my/pcc/pcc/parse/c_parser.py).
  Otherwise the repository can silently keep using an old `yacctab`/`lextab`
  and make the parser look "still broken" after the source fix.
- Treat this as mandatory, not optional cleanup. A parser/lexer fix is not
  complete until the default PLY cache name has been bumped in the same
  change whenever the grammar or token set changed.
- After any parser or lexer grammar change, run a focused parser regression
  first, then one representative compile/runtime case. Do not jump straight to
  a large project suite.
- Do not declare a run "done" until the command has produced its final summary.
  Partial progress output is not a result.


### 5. Do not stack unverified edits in shared codegen

`pcc/codegen/c_codegen.py` is shared by almost every meaningful path in the
repository. A "small local cleanup" there can easily break:

- Lua startup
- SQLite or zstd/lz4 integration
- GCC torture baselines
- parser-driven constant folding in unrelated code

Rules:

- Do not land a broad speculative patch in `c_codegen.py`.
- If the change is not backed by a minimized reproducer, keep it in a scratch
  probe, not the repository.
- Every real-project fix must end with at least one minimized regression test
  in `tests/`. Large-project-only validation is not enough.
- After every shared-path edit, run focused regression checks immediately
  before making the next edit.
- If the first fix attempt does not clearly improve the minimized reproducer,
  stop expanding the patch and go back to reduction.

### 6. Separate data-layout bugs from expression-semantics bugs

When a real program fails, two common classes are:

- ABI/layout bugs
  `sizeof`, `offsetof`, fake libc declarations, struct or union layout
- expression-semantics bugs
  signedness, promotions, comparisons, shifts, division/remainder, aggregate copy, control flow

If layout is suspicious, build a dedicated probe with `sizeof` and `offsetof` and compare native vs `pcc`. Once layout matches, move on.


### 7. Prefer downstream-sensitive regression tests

A good regression test does not just check "the bits look right right now". It checks an expression in a context where the next operation would be wrong if semantic metadata were lost.

Good examples:

- unsigned expression followed by `%` with a signed constant
- unsigned expression followed by `>>`
- unsigned expression used in `<`, `>`, `/`, `%`

This matters because LLVM uses the same integer types for signed and unsigned values. The compiler must preserve signedness intent itself.


### 8. Treat compile-time constant folding as a semantic subsystem

This repository has two different places where integer semantics matter:

- runtime lowering in LLVM IR
- compile-time evaluation in `_eval_const_expr()`

It is not enough to fix only the runtime path.

Typical failure mode:

- runtime unsigned comparisons are correct
- but compile-time casts or ternary folding ignore width/signedness
- macros such as `((size_t)(~(size_t)0))` fold to `-1`
- a real project then compiles with the wrong constant and fails far away

If a real program fails on a "simple constant", inspect `_eval_const_expr()` and
macro-expanded source before assuming the runtime IR is wrong.


## Signedness Model

This repository lowers both `int` and `unsigned int` to LLVM `i32`. Therefore signedness is tracked separately in `pcc/codegen/c_codegen.py`.

Important helpers:

- `_tag_unsigned`
- `_clear_unsigned`
- `_is_unsigned_val`
- `_convert_int_value`
- `_usual_arithmetic_conversion`
- `_shift_operand_conversion`

When you add or change an expression form, ask:

1. Does this produce an integer result?
2. If yes, should the result remain unsigned?
3. Will that result later feed `%`, `/`, `>>`, comparisons, or another arithmetic conversion?

The classic failure mode in this repository is:

- the immediate value bits are correct
- but the returned IR value is no longer marked unsigned
- so a later operator uses `sdiv`, `srem`, `ashr`, or signed comparison

This class of bug is easy to miss with toy tests and shows up quickly in Lua, libc-heavy code, and control-flow-heavy programs.


## Common Pitfalls

- Prefix operators on unsigned values:
  `++x` / `--x` must preserve unsignedness on the expression result.
- Bitwise operators on unsigned values:
  `&`, `|`, `^`, `~`, shifts, and compound assignments must preserve unsignedness where C requires it.
- Function-scope static arrays:
  `static const code lenfix[512] = { ... };` must become an internal global, not a stack allocation. If a returned pointer or cached table looks correct inside one helper but turns to garbage after the function returns, inspect block-scope `static` lowering first.
- Function-scope static incomplete arrays:
  `static const char my_version[] = "1.3.1";` must infer its top-level size from the initializer before the internal global is created. A zero-length `[0 x i8]` static local is a codegen bug, not a source quirk.
- Function-scope aggregate init-lists:
  `struct S s = {0};` and nested aggregate initializers must really zero and initialize the local object. If a real program shows impossible garbage in supposedly zero-initialized local state, inspect recursive local aggregate lowering before looking at the program logic.
- File-scope incomplete arrays:
  `extern int table[]; int table[] = { ... };` must end up as one real symbol. If IR contains both `@"table"` and `@"table.1"`, the compiler created a zero-length placeholder and then lost the real definition behind a renamed symbol.
- Standalone tag definitions:
  `struct S { ... };`, `union U { ... };`, and `enum E { ... };` with no declarator are type definitions, not object declarations. If a recursive type graph keeps one side opaque in IR, inspect `codegen_Decl()` before blaming the source program.
- Forward-declared named structs with bitfields:
  if `struct A` and `struct B` reference each other and one side contains bitfields, the final definition must reuse the existing identified tag type instead of inventing a fresh layout-only type. If `p->db == db` fails on obviously valid nested pointers, inspect named-struct finalization and tag reuse.
- Casted function-pointer globals:
  `static const entry table[] = { {(fnptr)target} };` must preserve the function address through the cast. Null-filled dispatch tables in VFS/syscall layers are usually constant-initializer bugs, not parser bugs.
- Assignment expressions:
  The stored value and the expression result are both semantically meaningful.
- Temporary probe files:
  Putting `foo_tmp.c` inside a project directory can accidentally change project collection behavior.
- Build configuration vs compiler compatibility:
  `--sources-from-make` can only recover flags that appear in real compile
  commands. If a project still needs explicit `--cpp-arg` values after make
  inference, first decide whether they are true build-configuration results
  that should come from configured build metadata, or temporary compiler
  compatibility flags that should remain explicit.
- Fake libc changes:
  These can fix or break real programs without touching parser or codegen.
- Darwin multi-TU MCJIT teardown:
  A large program can run correctly and still die later during llvmlite/LLVM cleanup. If the runtime output is correct but the host Python process crashes during GC or teardown, treat that as a lifecycle/isolation problem, not automatically a codegen bug.


## Testing Policy

For every semantic bug fix:

1. Add a focused regression test in `tests/`.
2. Confirm the original realistic reproducer is fixed.
3. Run the full suite before finishing.

For changes in shared parser/codegen paths, add a stricter gate:

1. Run the smallest reproducer first.
2. Run one existing sensitive integration check for the same bug class before
   making another edit.
3. Only then continue or broaden the patch.

Recommended focused gates for high-risk changes:

```bash
env -u LC_ALL uv run pytest tests/test_c_parser.py -q -n0
env -u LC_ALL uv run pytest 'tests/test_lua.py::test_onelua_compile_and_link' -q -n0
env -u LC_ALL uv run pytest 'tests/test_lua.py::test_pcc_runtime_matches_native[math.lua]' -q -n0
env -u LC_ALL uv run pytest tests/test_lz4.py -q -n0
env -u LC_ALL uv run pytest tests/test_sqlite.py -q -n0
```

Useful commands:

```bash
env -u LC_ALL uv run pytest tests/test_unsigned_loads.py -q -n0
env -u LC_ALL uv run pytest tests/test_lua.py -q -n0
env -u LC_ALL uv run pytest -q
```


## Definition of Done

Before you stop, confirm all of the following:

- the smallest reproducer passes
- the original integration scenario passes
- any temporary debug edits and probe files are removed
- a regression test exists
- the full suite is green


## Platform-Specific Gotchas (macOS)

- No `/dev/full` — Lua's `files.lua` tests `/dev/full` for write failure. On macOS this device doesn't exist. The test harness patches it out in a temporary copy.
- Makefile flags — Lua's Makefile uses `-DLUA_USE_LINUX` and `-Wl,-E`. On macOS, override with `MYCFLAGS=-std=c99 -DLUA_USE_MACOSX`, `MYLDFLAGS=`, `MYLIBS=`.
- `-ldl` — Not needed on macOS (dlopen is in libc), but harmless. The linker warns but still works.


## LLVM Version Mismatch

`llvmlite` bundles its own LLVM version, which may be newer than the
system `clang`. The repository also has an in-repo LLVM-C replacement
path under `pcc/llvm_capi`, so treat "LLVM behavior" and "llvmlite
behavior" as related but not identical questions when debugging.

- Older repository paths wrote LLVM IR text to disk and then asked the system compiler to compile that IR. In that setup, LLVM O2 could emit attributes the system `clang` did not understand, such as `nuw`, `nneg`, `range()`, `initializes()`, and `dead_on_unwind`.
- The current system-link path does **not** rely on the system compiler parsing LLVM IR text. `run_translation_units_with_system_cc()` optimizes each module with repository-managed LLVM and emits native object files directly, then links those objects with `cc`.
- The remaining limitation is not "no optimization". It is "no cross-translation-unit optimization" in the separate-TU path. Each TU gets optimized on its own before linking, but there is no LTO-style whole-program pass over the linked module set.
- If you ever reintroduce a text-IR handoff to the system compiler, keep the attribute-stripping warning in mind and centralize those rewrites in `postprocess_ir_text()`.


## IR Fix Policy

Do not put new semantic fixes into `postprocess_ir_text()` unless llvmlite
cannot directly express the required LLVM instruction.

Current policy:

- semantic bugs belong in parser/codegen source logic
- `postprocess_ir_text()` is only acceptable for narrow lowering gaps
- do not hide CFG, type, or signedness bugs with text rewrites

At the moment, the only acceptable remaining text-level lowering is the
`va_arg` path. Anything else should be treated as a source-level compiler bug
and fixed before the IR string is serialized.


## Packaging

- The wheel must include `utils/fake_libc_include/`. Without it, preprocessing fails on install.
- PyPI package name is `python-cc` (not `pcc`, which is taken).
- GitHub Actions uses Trusted Publisher (OIDC). The PyPI project name must match `pyproject.toml`'s `name` field exactly.

## Release Process

To publish a new version:

1. Update `version` in `pyproject.toml`.
2. Commit and push to `master`.
3. Create and push a git tag: `git tag v0.0.X && git push origin v0.0.X`
4. Create a GitHub Release: `gh release create v0.0.X --title "v0.0.X" --notes "Release notes here"`

GitHub Actions will automatically build and publish to PyPI via Trusted Publisher when the tag is pushed.


## Additional Reading

- `docs/investigations/lua-sort-random-pivot-signedness.md`
  Detailed report for a representative real-world debugging session that started as a flaky Lua `sort.lua` failure and ended as an unsigned-expression codegen fix.
- `docs/investigations/pcre-op-lengths-incomplete-array-binding.md`
  Detailed report for a PCRE failure that first looked like an MCJIT/link bottleneck and turned out to be a file-scope incomplete-array binding bug in global initializer lowering.
- `docs/investigations/zlib-integration-static-local-arrays-and-layout.md`
  Detailed report for a zlib integration session that exposed three different bug classes in sequence: enum layout, block-scope static arrays, and function-scope static incomplete arrays.
- `docs/investigations/sqlite-integration-vfs-init-and-mcjit-lifecycle.md`
  Detailed report for a SQLite integration session that exposed three different layers in sequence: casted syscall-table pointers, broken local aggregate zero-initialization, and Darwin MCJIT teardown instability.
- `docs/investigations/sqlite-forward-declared-bitfield-struct-tags.md`
  Detailed report for a later SQLite integration failure that first looked like a runtime logic bug and turned out to be incorrect handling of standalone tag definitions and forward-declared named bitfield structs in the type system.
- `docs/investigations/make-derived-cpp-flags-vs-explicit-project-config.md`
  Detailed report on why make-derived preprocessor inference covered PCRE but not Lua, zlib, or SQLite, and when explicit `--cpp-arg` values are the right interface instead of compiler-side project detection.
- `docs/investigations/nbody-shootout-fp-contract-and-vectorization.md`
  Detailed report on why `nbody_shootout` was not just a "missing vectorization" issue, how LLVM `contract` flags fixed the catastrophic regression, and which follow-up optimization directions were ruled in or out.
