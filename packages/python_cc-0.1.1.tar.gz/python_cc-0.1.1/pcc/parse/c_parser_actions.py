"""pcc.parse.c_parser_actions — AUTO-GENERATED action layer.

Extracted from ``pcc/parse/c_parser.py`` by
``scripts/extract_c_parser_actions.py``. Contains grammar-rule
action methods + helpers, with PLY-specific glue removed.

Consumed by ``pcc.parse.c_parse_driver`` (P6C.5 α1 step 3).

**Do not hand-edit.** If you need to change a grammar rule,
edit ``c_parser.py`` and re-run the extractor.
"""
from __future__ import annotations

from ..ast import c_ast
# ``Coord`` originally lived on ``pcc.parse.plyparser``; we
# re-use its location here because the legacy ``CParser`` and
# the new driver must produce ``Coord`` instances that compare
# equal (they're used in AST nodes). The import is data-only:
# ``Coord`` is a small dataclass-style container, no PLY.
from .plyparser import Coord, ParseError, PLYParser
from ..ast.ast_transforms import fix_switch_cases


class CParserActions(PLYParser):
    """Grammar-rule action layer + scope/typedef helpers,
    minus PLY-specific lexer/parser coupling. Instantiated by
    the native LR driver (``pcc.parse.c_parse_driver``).

    Inherits ``PLYParser`` purely for its ``_coord`` /
    ``_parse_error`` helpers — ``plyparser.py`` itself is
    pure Python with no PLY runtime imports (audit-clean).

    Instances track per-parse state:
      - ``_scope_stack``: typedef/name disambiguation scope
      - ``_last_yielded_token``: most-recent token from the
        lexer (replaces PLY's ``_get_yacc_lookahead_token``
        which probed the yacc runtime directly)
      - ``filename``: source file for diagnostics
    """

    def __init__(self, filename: str = "<input>") -> None:
        self.filename = filename
        self._scope_stack = [{}]
        self._last_yielded_token = None

    # -------- lexer-coordination surface (driver supplies these) --------

    def _get_yacc_lookahead_token(self):
        """Return the current lookahead token. The driver
        stashes the lookahead into ``_last_yielded_token``
        before each reduce (parser uses it for error messages
        and for lookahead-sensitive rules)."""
        return self._last_yielded_token

    def _coord(self, lineno, column=None):
        """Build a Coord from lineno/column. Overrides the
        PLYParser version which reads ``self.clex.filename``;
        the native driver stores filename directly."""
        return Coord(
            file=self.filename, line=lineno, column=column,
        )

    def _push_scope(self):
        self._scope_stack.append(dict())

    def _pop_scope(self):
        if len(self._scope_stack) <= 1:
            raise RuntimeError('internal error: cannot pop the global scope')
        self._scope_stack.pop()

    def _add_typedef_name(self, name, coord):
        """ Add a new typedef name (ie a TYPEID) to the current scope
            """
        if not self._scope_stack[-1].get(name, True):
            self._parse_error('Typedef %r previously declared as non-typedef in this scope' % name, coord)
        self._scope_stack[-1][name] = True

    def _add_identifier(self, name, coord):
        """ Add a new object, function, or enum member name (ie an ID) to the
                current scope
            """
        if self._scope_stack[-1].get(name, False):
            self._parse_error('Non-typedef %r previously declared as typedef in this scope' % name, coord)
        self._scope_stack[-1][name] = False

    def _is_type_in_scope(self, name):
        """ Is *name* a typedef-name in the current scope?
            """
        for scope in reversed(self._scope_stack):
            in_scope = scope.get(name)
            if in_scope is not None:
                return in_scope
        return False

    def _type_modify_decl(self, decl, modifier):
        """ Tacks a type modifier on a declarator, and returns
                the modified declarator.

                Note: the declarator and modifier may be modified
            """
        modifier_head = modifier
        modifier_tail = modifier
        while modifier_tail.type:
            modifier_tail = modifier_tail.type
        if isinstance(decl, c_ast.TypeDecl):
            modifier_tail.type = decl
            return modifier
        else:
            decl_tail = decl
            while not isinstance(decl_tail.type, c_ast.TypeDecl):
                decl_tail = decl_tail.type
            modifier_tail.type = decl_tail.type
            decl_tail.type = modifier_head
            return decl

    def _fix_decl_name_type(self, decl, typename):
        """ Fixes a declaration. Modifies decl.
            """
        type = decl
        while not isinstance(type, c_ast.TypeDecl):
            type = type.type
        decl.name = type.declname
        type.quals = decl.quals
        for tn in typename:
            if not isinstance(tn, c_ast.IdentifierType):
                if len(typename) > 1:
                    self._parse_error('Invalid multiple types specified', tn.coord)
                else:
                    type.type = tn
                    return decl
        if not typename:
            if not isinstance(decl.type, c_ast.FuncDecl):
                self._parse_error('Missing type in declaration', decl.coord)
            type.type = c_ast.IdentifierType(['int'], coord=decl.coord)
        else:
            type.type = c_ast.IdentifierType([name for id in typename for name in id.names], coord=typename[0].coord)
        return decl

    def _add_declaration_specifier(self, declspec, newspec, kind):
        """ Declaration specifiers are represented by a dictionary
                with the entries:
                * qual: a list of type qualifiers
                * storage: a list of storage type qualifiers
                * type: a list of type specifiers
                * function: a list of function specifiers

                This method is given a declaration specifier, and a
                new specifier of a given kind.
                Returns the declaration specifier, with the new
                specifier incorporated.
            """
        spec = declspec or dict(qual=[], storage=[], type=[], function=[], alignment=[])
        if kind not in spec:
            spec[kind] = []
        spec[kind].insert(0, newspec)
        return spec

    def _build_declarations(self, spec, decls, typedef_namespace=False):
        """ Builds a list of declarations all sharing the given specifiers.
                If typedef_namespace is true, each declared name is added
                to the "typedef namespace", which also includes objects,
                functions, and enum constants.
            """
        is_typedef = 'typedef' in spec['storage']
        declarations = []
        if decls[0].get('bitsize') is not None:
            pass
        elif decls[0]['decl'] is None:
            if len(spec['type']) < 2 or len(spec['type'][-1].names) != 1 or (not self._is_type_in_scope(spec['type'][-1].names[0])):
                coord = '?'
                for t in spec['type']:
                    if hasattr(t, 'coord'):
                        coord = t.coord
                        break
                self._parse_error('Invalid declaration', coord)
            decls[0]['decl'] = c_ast.TypeDecl(declname=spec['type'][-1].names[0], type=None, quals=None, coord=spec['type'][-1].coord)
            del spec['type'][-1]
        elif not isinstance(decls[0]['decl'], (c_ast.Struct, c_ast.Union, c_ast.IdentifierType)):
            decls_0_tail = decls[0]['decl']
            while not isinstance(decls_0_tail, c_ast.TypeDecl):
                decls_0_tail = decls_0_tail.type
            if decls_0_tail.declname is None:
                decls_0_tail.declname = spec['type'][-1].names[0]
                del spec['type'][-1]
        for decl in decls:
            if decl['decl'] is None:
                raise RuntimeError('internal error: declarator missing in declaration')
            if is_typedef:
                declaration = c_ast.Typedef(name=None, quals=spec['qual'], storage=spec['storage'], type=decl['decl'], coord=decl['decl'].coord)
            else:
                declaration = c_ast.Decl(name=None, quals=spec['qual'], storage=spec['storage'], funcspec=spec['function'], type=decl['decl'], init=decl.get('init'), bitsize=decl.get('bitsize'), coord=decl['decl'].coord)
            if isinstance(declaration.type, (c_ast.Struct, c_ast.Union, c_ast.IdentifierType)):
                fixed_decl = declaration
            else:
                fixed_decl = self._fix_decl_name_type(declaration, spec['type'])
            if typedef_namespace:
                if is_typedef:
                    self._add_typedef_name(fixed_decl.name, fixed_decl.coord)
                else:
                    self._add_identifier(fixed_decl.name, fixed_decl.coord)
            declarations.append(fixed_decl)
        return declarations

    def _build_function_definition(self, spec, decl, param_decls, body):
        """ Builds a function definition.
            """
        if 'typedef' in spec['storage']:
            raise RuntimeError('internal error: typedef in function definition')
        declaration = self._build_declarations(spec=spec, decls=[dict(decl=decl, init=None)], typedef_namespace=True)[0]
        return c_ast.FuncDef(decl=declaration, param_decls=param_decls, body=body, coord=decl.coord)

    def _select_struct_union_class(self, token):
        """ Given a token (either STRUCT or UNION), selects the
                appropriate AST class.
            """
        if token == 'struct':
            return c_ast.Struct
        else:
            return c_ast.Union

    precedence = (('left', 'LOR'), ('left', 'LAND'), ('left', 'OR'), ('left', 'XOR'), ('left', 'AND'), ('left', 'EQ', 'NE'), ('left', 'GT', 'GE', 'LT', 'LE'), ('left', 'RSHIFT', 'LSHIFT'), ('left', 'PLUS', 'MINUS'), ('left', 'TIMES', 'DIVIDE', 'MOD'))

    def p_translation_unit_or_empty(self, p):
        """ translation_unit_or_empty   : translation_unit
                                            | empty
            """
        if p[1] is None:
            p[0] = c_ast.FileAST([])
        else:
            p[0] = c_ast.FileAST(p[1])

    def p_translation_unit_1(self, p):
        """ translation_unit    : external_declaration
            """
        p[0] = p[1]

    def p_translation_unit_2(self, p):
        """ translation_unit    : translation_unit external_declaration
            """
        if p[1] is None:
            p[1] = []
        if p[2] is not None:
            p[1].extend(p[2])
        p[0] = p[1]

    def p_external_declaration_1(self, p):
        """ external_declaration    : function_definition
            """
        p[0] = [p[1]]

    def p_external_declaration_2(self, p):
        """ external_declaration    : declaration
            """
        p[0] = p[1]

    def p_external_declaration_3(self, p):
        """ external_declaration    : pp_directive
            """
        p[0] = p[1]

    def p_external_declaration_4(self, p):
        """ external_declaration    : SEMI
            """
        p[0] = None

    def p_external_declaration_5(self, p):
        """ external_declaration    : static_assert
            """
        p[0] = [p[1]]

    def p_pp_directive(self, p):
        """ pp_directive  : PPHASH
            """
        self._parse_error('Directives not supported yet', self._coord(p.lineno(1)))

    def p_function_definition_1(self, p):
        """ function_definition : declarator declaration_list_opt compound_statement
            """
        spec = dict(qual=[], storage=[], type=[c_ast.IdentifierType(['int'], coord=self._coord(p.lineno(1)))], function=[])
        p[0] = self._build_function_definition(spec=spec, decl=p[1], param_decls=p[2], body=p[3])

    def p_function_definition_2(self, p):
        """ function_definition : declaration_specifiers declarator declaration_list_opt compound_statement
            """
        spec = p[1]
        p[0] = self._build_function_definition(spec=spec, decl=p[2], param_decls=p[3], body=p[4])

    def p_statement(self, p):
        """ statement   : labeled_statement
                            | expression_statement
                            | compound_statement
                            | selection_statement
                            | iteration_statement
                            | jump_statement
            """
        p[0] = p[1]

    def p_decl_body(self, p):
        """ decl_body : declaration_specifiers init_declarator_list_opt
            """
        spec = p[1]
        if p[2] is None:
            ty = spec['type']
            s_u_or_e = (c_ast.Struct, c_ast.Union, c_ast.Enum)
            if len(ty) == 1 and isinstance(ty[0], s_u_or_e):
                decls = [c_ast.Decl(name=None, quals=spec['qual'], storage=spec['storage'], funcspec=spec['function'], type=ty[0], init=None, bitsize=None, coord=ty[0].coord)]
            else:
                decls = self._build_declarations(spec=spec, decls=[dict(decl=None, init=None)], typedef_namespace=True)
        else:
            decls = self._build_declarations(spec=spec, decls=p[2], typedef_namespace=True)
        p[0] = decls

    def p_declaration(self, p):
        """ declaration : decl_body SEMI
            """
        p[0] = p[1]

    def p_static_assert(self, p):
        """ static_assert : _STATIC_ASSERT LPAREN constant_expression COMMA unified_string_literal RPAREN SEMI
                              | _STATIC_ASSERT LPAREN constant_expression RPAREN SEMI
            """
        if len(p) == 8:
            p[0] = c_ast.StaticAssert(p[3], p[5], self._coord(p.lineno(1)))
        else:
            p[0] = c_ast.StaticAssert(p[3], None, self._coord(p.lineno(1)))

    def p_declaration_list(self, p):
        """ declaration_list    : declaration
                                    | declaration_list declaration
            """
        p[0] = p[1] if len(p) == 2 else p[1] + p[2]

    def p_declaration_specifiers_1(self, p):
        """ declaration_specifiers  : type_qualifier declaration_specifiers_opt
            """
        p[0] = self._add_declaration_specifier(p[2], p[1], 'qual')

    def p_declaration_specifiers_2(self, p):
        """ declaration_specifiers  : type_specifier declaration_specifiers_opt
            """
        p[0] = self._add_declaration_specifier(p[2], p[1], 'type')

    def p_declaration_specifiers_3(self, p):
        """ declaration_specifiers  : storage_class_specifier declaration_specifiers_opt
            """
        p[0] = self._add_declaration_specifier(p[2], p[1], 'storage')

    def p_declaration_specifiers_4(self, p):
        """ declaration_specifiers  : function_specifier declaration_specifiers_opt
            """
        p[0] = self._add_declaration_specifier(p[2], p[1], 'function')

    def p_declaration_specifiers_5(self, p):
        """ declaration_specifiers  : alignment_specifier declaration_specifiers_opt
            """
        p[0] = self._add_declaration_specifier(p[2], p[1], 'alignment')

    def p_alignment_specifier(self, p):
        """ alignment_specifier : _ALIGNAS LPAREN type_name RPAREN
                                    | _ALIGNAS LPAREN constant_expression RPAREN
            """
        p[0] = c_ast.Alignas(p[3], self._coord(p.lineno(1)))

    def p_storage_class_specifier(self, p):
        """ storage_class_specifier : AUTO
                                        | REGISTER
                                        | STATIC
                                        | EXTERN
                                        | TYPEDEF
                                        | _THREAD_LOCAL
            """
        p[0] = p[1]

    def p_function_specifier(self, p):
        """ function_specifier  : INLINE
                                    | _NORETURN
            """
        p[0] = p[1]

    def p_type_specifier_1(self, p):
        """ type_specifier  : VOID
                                | _BOOL
                                | CHAR
                                | SHORT
                                | INT
                                | INT128
                                | LONG
                                | FLOAT
                                | DOUBLE
                                | _FLOAT16
                                | _COMPLEX
                                | SIGNED
                                | UNSIGNED
            """
        p[0] = c_ast.IdentifierType([p[1]], coord=self._coord(p.lineno(1)))

    def p_type_specifier_2(self, p):
        """ type_specifier  : typedef_name
                                | enum_specifier
                                | struct_or_union_specifier
            """
        p[0] = p[1]

    def p_type_qualifier(self, p):
        """ type_qualifier  : CONST
                                | RESTRICT
                                | VOLATILE
            """
        p[0] = p[1]

    def p_init_declarator_list_1(self, p):
        """ init_declarator_list    : init_declarator
                                        | init_declarator_list COMMA init_declarator
            """
        p[0] = p[1] + [p[3]] if len(p) == 4 else [p[1]]

    def p_init_declarator_list_2(self, p):
        """ init_declarator_list    : EQUALS initializer
            """
        p[0] = [dict(decl=None, init=p[2])]

    def p_init_declarator_list_3(self, p):
        """ init_declarator_list    : abstract_declarator
            """
        p[0] = [dict(decl=p[1], init=None)]

    def p_init_declarator(self, p):
        """ init_declarator : declarator
                                | declarator EQUALS initializer
            """
        p[0] = dict(decl=p[1], init=p[3] if len(p) > 2 else None)

    def p_specifier_qualifier_list_1(self, p):
        """ specifier_qualifier_list    : type_qualifier specifier_qualifier_list_opt
            """
        p[0] = self._add_declaration_specifier(p[2], p[1], 'qual')

    def p_specifier_qualifier_list_2(self, p):
        """ specifier_qualifier_list    : type_specifier specifier_qualifier_list_opt
            """
        p[0] = self._add_declaration_specifier(p[2], p[1], 'type')

    def p_struct_or_union_specifier_1(self, p):
        """ struct_or_union_specifier   : struct_or_union ID
                                            | struct_or_union TYPEID
            """
        klass = self._select_struct_union_class(p[1])
        p[0] = klass(name=p[2], decls=None, coord=self._coord(p.lineno(2)))

    def p_struct_or_union_specifier_2(self, p):
        """ struct_or_union_specifier : struct_or_union brace_open brace_close
                                          | struct_or_union brace_open struct_declaration_list brace_close
            """
        klass = self._select_struct_union_class(p[1])
        p[0] = klass(name=None, decls=[] if len(p) == 4 else p[3], coord=self._coord(p.lineno(2)))

    def p_struct_or_union_specifier_3(self, p):
        """ struct_or_union_specifier   : struct_or_union ID brace_open brace_close
                                            | struct_or_union TYPEID brace_open brace_close
                                            | struct_or_union ID brace_open struct_declaration_list brace_close
                                            | struct_or_union TYPEID brace_open struct_declaration_list brace_close
            """
        klass = self._select_struct_union_class(p[1])
        p[0] = klass(name=p[2], decls=[] if len(p) == 5 else p[4], coord=self._coord(p.lineno(2)))

    def p_struct_or_union(self, p):
        """ struct_or_union : STRUCT
                                | UNION
            """
        p[0] = p[1]

    def p_struct_declaration_list(self, p):
        """ struct_declaration_list     : struct_declaration
                                            | struct_declaration_list struct_declaration
            """
        p[0] = p[1] if len(p) == 2 else p[1] + p[2]

    def p_struct_declaration_1(self, p):
        """ struct_declaration : specifier_qualifier_list struct_declarator_list_opt SEMI
            """
        spec = p[1]
        if 'typedef' in spec['storage']:
            raise RuntimeError('internal error: typedef in struct declaration')
        if p[2] is not None:
            decls = self._build_declarations(spec=spec, decls=p[2])
        elif len(spec['type']) == 1:
            node = spec['type'][0]
            if isinstance(node, c_ast.Node):
                decl_type = node
            else:
                decl_type = c_ast.IdentifierType(node)
            decls = self._build_declarations(spec=spec, decls=[dict(decl=decl_type)])
        else:
            decls = self._build_declarations(spec=spec, decls=[dict(decl=None, init=None)])
        p[0] = decls

    def p_struct_declaration_2(self, p):
        """ struct_declaration : specifier_qualifier_list abstract_declarator SEMI
            """
        p[0] = self._build_declarations(spec=p[1], decls=[dict(decl=p[2], init=None)])

    def p_struct_declarator_list(self, p):
        """ struct_declarator_list  : struct_declarator
                                        | struct_declarator_list COMMA struct_declarator
            """
        p[0] = p[1] + [p[3]] if len(p) == 4 else [p[1]]

    def p_struct_declarator_1(self, p):
        """ struct_declarator : declarator
            """
        p[0] = {'decl': p[1], 'bitsize': None}

    def p_struct_declarator_2(self, p):
        """ struct_declarator   : declarator COLON constant_expression
                                    | COLON constant_expression
            """
        if len(p) > 3:
            p[0] = {'decl': p[1], 'bitsize': p[3]}
        else:
            p[0] = {'decl': c_ast.TypeDecl(None, None, None), 'bitsize': p[2]}

    def p_enum_specifier_1(self, p):
        """ enum_specifier  : ENUM ID
                                | ENUM TYPEID
            """
        p[0] = c_ast.Enum(p[2], None, self._coord(p.lineno(1)))

    def p_enum_specifier_2(self, p):
        """ enum_specifier  : ENUM brace_open enumerator_list brace_close
            """
        p[0] = c_ast.Enum(None, p[3], self._coord(p.lineno(1)))

    def p_enum_specifier_3(self, p):
        """ enum_specifier  : ENUM ID brace_open enumerator_list brace_close
                                | ENUM TYPEID brace_open enumerator_list brace_close
            """
        p[0] = c_ast.Enum(p[2], p[4], self._coord(p.lineno(1)))

    def p_enumerator_list(self, p):
        """ enumerator_list : enumerator
                                | enumerator_list COMMA
                                | enumerator_list COMMA enumerator
            """
        if len(p) == 2:
            p[0] = c_ast.EnumeratorList([p[1]], p[1].coord)
        elif len(p) == 3:
            p[0] = p[1]
        else:
            p[1].enumerators.append(p[3])
            p[0] = p[1]

    def p_enumerator(self, p):
        """ enumerator  : ID
                            | ID EQUALS constant_expression
            """
        if len(p) == 2:
            enumerator = c_ast.Enumerator(p[1], None, self._coord(p.lineno(1)))
        else:
            enumerator = c_ast.Enumerator(p[1], p[3], self._coord(p.lineno(1)))
        self._add_identifier(enumerator.name, enumerator.coord)
        p[0] = enumerator

    def p_declarator_1(self, p):
        """ declarator  : direct_declarator
            """
        p[0] = p[1]

    def p_declarator_2(self, p):
        """ declarator  : pointer direct_declarator
            """
        p[0] = self._type_modify_decl(p[2], p[1])

    def p_declarator_3(self, p):
        """ declarator  : pointer TYPEID
            """
        decl = c_ast.TypeDecl(declname=p[2], type=None, quals=None, coord=self._coord(p.lineno(2)))
        p[0] = self._type_modify_decl(decl, p[1])

    def p_direct_declarator_1(self, p):
        """ direct_declarator   : ID
                                    | TYPEID
            """
        p[0] = c_ast.TypeDecl(declname=p[1], type=None, quals=None, coord=self._coord(p.lineno(1)))

    def p_direct_declarator_2(self, p):
        """ direct_declarator   : LPAREN declarator RPAREN
            """
        p[0] = p[2]

    def p_direct_declarator_3(self, p):
        """ direct_declarator   : direct_declarator LBRACKET type_qualifier_list_opt assignment_expression_opt RBRACKET
            """
        quals = (p[3] if len(p) > 5 else []) or []
        arr = c_ast.ArrayDecl(type=None, dim=p[4] if len(p) > 5 else p[3], dim_quals=quals, coord=p[1].coord)
        p[0] = self._type_modify_decl(decl=p[1], modifier=arr)

    def p_direct_declarator_4(self, p):
        """ direct_declarator   : direct_declarator LBRACKET STATIC type_qualifier_list_opt assignment_expression RBRACKET
                                    | direct_declarator LBRACKET type_qualifier_list STATIC assignment_expression RBRACKET
            """
        listed_quals = [item if isinstance(item, list) else [item] for item in [p[3], p[4]]]
        dim_quals = [qual for sublist in listed_quals for qual in sublist if qual is not None]
        arr = c_ast.ArrayDecl(type=None, dim=p[5], dim_quals=dim_quals, coord=p[1].coord)
        p[0] = self._type_modify_decl(decl=p[1], modifier=arr)

    def p_direct_declarator_5(self, p):
        """ direct_declarator   : direct_declarator LBRACKET type_qualifier_list_opt TIMES RBRACKET
            """
        arr = c_ast.ArrayDecl(type=None, dim=c_ast.ID(p[4], self._coord(p.lineno(4))), dim_quals=p[3] if p[3] != None else [], coord=p[1].coord)
        p[0] = self._type_modify_decl(decl=p[1], modifier=arr)

    def p_direct_declarator_6(self, p):
        """ direct_declarator   : direct_declarator LPAREN parameter_type_list RPAREN
                                    | direct_declarator LPAREN identifier_list_opt RPAREN
            """
        func = c_ast.FuncDecl(args=p[3], type=None, coord=p[1].coord)
        if self._get_yacc_lookahead_token().type == 'LBRACE':
            if func.args is not None:
                for param in func.args.params:
                    if isinstance(param, c_ast.EllipsisParam):
                        break
                    self._add_identifier(param.name, param.coord)
        p[0] = self._type_modify_decl(decl=p[1], modifier=func)

    def p_pointer(self, p):
        """ pointer : TIMES type_qualifier_list_opt
                        | TIMES type_qualifier_list_opt pointer
            """
        coord = self._coord(p.lineno(1))
        nested_type = c_ast.PtrDecl(quals=p[2] or [], type=None, coord=coord)
        if len(p) > 3:
            tail_type = p[3]
            while tail_type.type is not None:
                tail_type = tail_type.type
            tail_type.type = nested_type
            p[0] = p[3]
        else:
            p[0] = nested_type

    def p_type_qualifier_list(self, p):
        """ type_qualifier_list : type_qualifier
                                    | type_qualifier_list type_qualifier
            """
        p[0] = [p[1]] if len(p) == 2 else p[1] + [p[2]]

    def p_parameter_type_list(self, p):
        """ parameter_type_list : parameter_list
                                    | parameter_list COMMA ELLIPSIS
            """
        if len(p) > 2:
            p[1].params.append(c_ast.EllipsisParam(self._coord(p.lineno(3))))
        p[0] = p[1]

    def p_parameter_list(self, p):
        """ parameter_list  : parameter_declaration
                                | parameter_list COMMA parameter_declaration
            """
        if len(p) == 2:
            p[0] = c_ast.ParamList([p[1]], p[1].coord)
        else:
            p[1].params.append(p[3])
            p[0] = p[1]

    def p_parameter_declaration_1(self, p):
        """ parameter_declaration   : declaration_specifiers declarator
            """
        spec = p[1]
        if not spec['type']:
            spec['type'] = [c_ast.IdentifierType(['int'], coord=self._coord(p.lineno(1)))]
        p[0] = self._build_declarations(spec=spec, decls=[dict(decl=p[2])])[0]

    def p_parameter_declaration_2(self, p):
        """ parameter_declaration   : declaration_specifiers abstract_declarator_opt
            """
        spec = p[1]
        if not spec['type']:
            spec['type'] = [c_ast.IdentifierType(['int'], coord=self._coord(p.lineno(1)))]
        if len(spec['type']) > 1 and len(spec['type'][-1].names) == 1 and self._is_type_in_scope(spec['type'][-1].names[0]):
            decl = self._build_declarations(spec=spec, decls=[dict(decl=p[2], init=None)])[0]
        else:
            decl = c_ast.Typename(name='', quals=spec['qual'], type=p[2] or c_ast.TypeDecl(None, None, None), coord=self._coord(p.lineno(2)))
            typename = spec['type']
            decl = self._fix_decl_name_type(decl, typename)
        p[0] = decl

    def p_parameter_declaration_3(self, p):
        """ parameter_declaration   : declaration_specifiers LBRACKET type_qualifier_list assignment_expression_opt RBRACKET
                                        | declaration_specifiers LBRACKET STATIC type_qualifier_list_opt assignment_expression RBRACKET
                                        | declaration_specifiers LBRACKET type_qualifier_list STATIC assignment_expression RBRACKET
                                        | declaration_specifiers LBRACKET type_qualifier_list TIMES RBRACKET
            """
        spec = p[1]
        if not spec['type']:
            spec['type'] = [c_ast.IdentifierType(['int'], coord=self._coord(p.lineno(1)))]
        if p.slice[-2].type == 'TIMES':
            dim = c_ast.ID(p[4], self._coord(p.lineno(4)))
            dim_quals = p[3] if p[3] is not None else []
        elif p.slice[3].type == 'STATIC' or p.slice[4].type == 'STATIC':
            listed_quals = [item if isinstance(item, list) else [item] for item in [p[3], p[4]]]
            dim_quals = [qual for sublist in listed_quals for qual in sublist if qual is not None]
            dim = p[5]
        else:
            dim_quals = p[3] if p[3] is not None else []
            dim = p[4]
        decl = c_ast.ArrayDecl(type=c_ast.TypeDecl(None, None, None), dim=dim, dim_quals=dim_quals, coord=self._coord(p.lineno(2)))
        typename = c_ast.Typename(name='', quals=spec['qual'], type=decl, coord=self._coord(p.lineno(2)))
        p[0] = self._fix_decl_name_type(typename, spec['type'])

    def p_identifier_list(self, p):
        """ identifier_list : identifier
                                | identifier_list COMMA identifier
            """
        if len(p) == 2:
            p[0] = c_ast.ParamList([p[1]], p[1].coord)
        else:
            p[1].params.append(p[3])
            p[0] = p[1]

    def p_initializer_1(self, p):
        """ initializer : assignment_expression
            """
        p[0] = p[1]

    def p_initializer_2(self, p):
        """ initializer : brace_open initializer_list_opt brace_close
                            | brace_open initializer_list COMMA brace_close
            """
        if p[2] is None:
            p[0] = c_ast.InitList([], self._coord(p.lineno(1)))
        else:
            p[0] = p[2]

    def p_initializer_list(self, p):
        """ initializer_list    : initializer_item
                                    | initializer_list COMMA initializer_item
            """
        if len(p) == 2:
            p[0] = c_ast.InitList([p[1]], p[1].coord)
        else:
            p[1].exprs.append(p[3])
            p[0] = p[1]

    def p_initializer_item(self, p):
        """ initializer_item    : initializer
                                     | designator_list EQUALS initializer
                                     | identifier COLON initializer
            """
        if len(p) == 2:
            p[0] = p[1]
        elif p.slice[2].type == 'EQUALS':
            p[0] = c_ast.NamedInitializer(p[1], p[3])
        else:
            p[0] = c_ast.NamedInitializer([p[1]], p[3])

    def p_designator_list(self, p):
        """ designator_list : designator
                                | designator_list designator
            """
        p[0] = [p[1]] if len(p) == 2 else p[1] + [p[2]]

    def p_designator(self, p):
        """ designator  : LBRACKET constant_expression RBRACKET
                            | LBRACKET constant_expression ELLIPSIS constant_expression RBRACKET
                            | PERIOD identifier
            """
        if len(p) == 4:
            p[0] = p[2]
        elif len(p) == 6:
            p[0] = c_ast.RangeDesignator(p[2], p[4], self._coord(p.lineno(1)))
        else:
            p[0] = p[2]

    def p_type_name(self, p):
        """ type_name   : specifier_qualifier_list abstract_declarator_opt
            """
        typename = c_ast.Typename(name='', quals=p[1]['qual'], type=p[2] or c_ast.TypeDecl(None, None, None), coord=self._coord(p.lineno(2)))
        p[0] = self._fix_decl_name_type(typename, p[1]['type'])

    def p_abstract_declarator_1(self, p):
        """ abstract_declarator     : pointer
            """
        dummytype = c_ast.TypeDecl(None, None, None)
        p[0] = self._type_modify_decl(decl=dummytype, modifier=p[1])

    def p_abstract_declarator_2(self, p):
        """ abstract_declarator     : pointer direct_abstract_declarator
            """
        p[0] = self._type_modify_decl(p[2], p[1])

    def p_abstract_declarator_3(self, p):
        """ abstract_declarator     : direct_abstract_declarator
            """
        p[0] = p[1]

    def p_direct_abstract_declarator_1(self, p):
        """ direct_abstract_declarator  : LPAREN abstract_declarator RPAREN """
        p[0] = p[2]

    def p_direct_abstract_declarator_2(self, p):
        """ direct_abstract_declarator  : direct_abstract_declarator LBRACKET type_qualifier_list_opt assignment_expression_opt RBRACKET
            """
        arr = c_ast.ArrayDecl(type=None, dim=p[4] if len(p) > 5 else p[3], dim_quals=(p[3] if len(p) > 5 else []) or [], coord=p[1].coord)
        p[0] = self._type_modify_decl(decl=p[1], modifier=arr)

    def p_direct_abstract_declarator_3(self, p):
        """ direct_abstract_declarator  : LBRACKET type_qualifier_list_opt assignment_expression_opt RBRACKET
            """
        p[0] = c_ast.ArrayDecl(type=c_ast.TypeDecl(None, None, None), dim=p[3] if len(p) > 4 else p[2], dim_quals=(p[2] if len(p) > 4 else []) or [], coord=self._coord(p.lineno(1)))

    def p_direct_abstract_declarator_4(self, p):
        """ direct_abstract_declarator  : direct_abstract_declarator LBRACKET STATIC type_qualifier_list_opt assignment_expression RBRACKET
                                            | direct_abstract_declarator LBRACKET type_qualifier_list STATIC assignment_expression RBRACKET
            """
        listed_quals = [item if isinstance(item, list) else [item] for item in [p[3], p[4]]]
        dim_quals = [qual for sublist in listed_quals for qual in sublist if qual is not None]
        arr = c_ast.ArrayDecl(type=None, dim=p[5], dim_quals=dim_quals, coord=p[1].coord)
        p[0] = self._type_modify_decl(decl=p[1], modifier=arr)

    def p_direct_abstract_declarator_5(self, p):
        """ direct_abstract_declarator  : LBRACKET STATIC type_qualifier_list_opt assignment_expression RBRACKET
                                            | LBRACKET type_qualifier_list STATIC assignment_expression RBRACKET
            """
        listed_quals = [item if isinstance(item, list) else [item] for item in [p[2], p[3]]]
        dim_quals = [qual for sublist in listed_quals for qual in sublist if qual is not None]
        p[0] = c_ast.ArrayDecl(type=c_ast.TypeDecl(None, None, None), dim=p[4], dim_quals=dim_quals, coord=self._coord(p.lineno(1)))

    def p_direct_abstract_declarator_6(self, p):
        """ direct_abstract_declarator  : direct_abstract_declarator LBRACKET type_qualifier_list_opt TIMES RBRACKET
            """
        arr = c_ast.ArrayDecl(type=None, dim=c_ast.ID(p[4], self._coord(p.lineno(4))), dim_quals=p[3] if p[3] is not None else [], coord=p[1].coord)
        p[0] = self._type_modify_decl(decl=p[1], modifier=arr)

    def p_direct_abstract_declarator_7(self, p):
        """ direct_abstract_declarator  : LBRACKET type_qualifier_list_opt TIMES RBRACKET
            """
        p[0] = c_ast.ArrayDecl(type=c_ast.TypeDecl(None, None, None), dim=c_ast.ID(p[3], self._coord(p.lineno(3))), dim_quals=p[2] if p[2] is not None else [], coord=self._coord(p.lineno(1)))

    def p_direct_abstract_declarator_8(self, p):
        """ direct_abstract_declarator  : direct_abstract_declarator LPAREN parameter_type_list_opt RPAREN
            """
        func = c_ast.FuncDecl(args=p[3], type=None, coord=p[1].coord)
        p[0] = self._type_modify_decl(decl=p[1], modifier=func)

    def p_direct_abstract_declarator_9(self, p):
        """ direct_abstract_declarator  : LPAREN parameter_type_list_opt RPAREN
            """
        p[0] = c_ast.FuncDecl(args=p[2], type=c_ast.TypeDecl(None, None, None), coord=self._coord(p.lineno(1)))

    def p_block_item(self, p):
        """ block_item  : declaration
                            | statement
                            | static_assert
            """
        p[0] = p[1] if isinstance(p[1], list) else [p[1]]

    def p_block_item_list(self, p):
        """ block_item_list : block_item
                                | block_item_list block_item
            """
        p[0] = p[1] if len(p) == 2 or p[2] == [None] else p[1] + p[2]

    def p_compound_statement_1(self, p):
        """ compound_statement : brace_open block_item_list_opt brace_close """
        p[0] = c_ast.Compound(block_items=p[2], coord=self._coord(p.lineno(1)))

    def p_labeled_statement_1(self, p):
        """ labeled_statement : ID COLON statement
                                  | TYPEID COLON statement
            """
        p[0] = c_ast.Label(p[1], p[3], self._coord(p.lineno(1)))

    def p_labeled_statement_2(self, p):
        """ labeled_statement : CASE constant_expression COLON statement """
        p[0] = c_ast.Case(p[2], [p[4]], self._coord(p.lineno(1)))

    def p_labeled_statement_3(self, p):
        """ labeled_statement : DEFAULT COLON statement """
        p[0] = c_ast.Default([p[3]], self._coord(p.lineno(1)))

    def p_selection_statement_1(self, p):
        """ selection_statement : IF LPAREN expression RPAREN statement """
        p[0] = c_ast.If(p[3], p[5], None, self._coord(p.lineno(1)))

    def p_selection_statement_2(self, p):
        """ selection_statement : IF LPAREN expression RPAREN statement ELSE statement """
        p[0] = c_ast.If(p[3], p[5], p[7], self._coord(p.lineno(1)))

    def p_selection_statement_3(self, p):
        """ selection_statement : SWITCH LPAREN expression RPAREN statement """
        p[0] = fix_switch_cases(c_ast.Switch(p[3], p[5], self._coord(p.lineno(1))))

    def p_iteration_statement_1(self, p):
        """ iteration_statement : WHILE LPAREN expression RPAREN statement """
        p[0] = c_ast.While(p[3], p[5], self._coord(p.lineno(1)))

    def p_iteration_statement_2(self, p):
        """ iteration_statement : DO statement WHILE LPAREN expression RPAREN SEMI """
        p[0] = c_ast.DoWhile(p[5], p[2], self._coord(p.lineno(1)))

    def p_iteration_statement_3(self, p):
        """ iteration_statement : FOR LPAREN expression_opt SEMI expression_opt SEMI expression_opt RPAREN statement """
        p[0] = c_ast.For(p[3], p[5], p[7], p[9], self._coord(p.lineno(1)))

    def p_iteration_statement_4(self, p):
        """ iteration_statement : FOR LPAREN declaration expression_opt SEMI expression_opt RPAREN statement """
        p[0] = c_ast.For(c_ast.DeclList(p[3], self._coord(p.lineno(1))), p[4], p[6], p[8], self._coord(p.lineno(1)))

    def p_jump_statement_1(self, p):
        """ jump_statement  : GOTO ID SEMI
                                | GOTO TYPEID SEMI
            """
        p[0] = c_ast.Goto(p[2], self._coord(p.lineno(1)))

    def p_jump_statement_1b(self, p):
        """ jump_statement  : GOTO TIMES expression SEMI """
        p[0] = c_ast.ComputedGoto(p[3], self._coord(p.lineno(1)))

    def p_jump_statement_2(self, p):
        """ jump_statement  : BREAK SEMI """
        p[0] = c_ast.Break(self._coord(p.lineno(1)))

    def p_jump_statement_3(self, p):
        """ jump_statement  : CONTINUE SEMI """
        p[0] = c_ast.Continue(self._coord(p.lineno(1)))

    def p_jump_statement_4(self, p):
        """ jump_statement  : RETURN expression SEMI
                                | RETURN SEMI
            """
        p[0] = c_ast.Return(p[2] if len(p) == 4 else None, self._coord(p.lineno(1)))

    def p_expression_statement(self, p):
        """ expression_statement : expression_opt SEMI """
        if p[1] is None:
            p[0] = c_ast.EmptyStatement(self._coord(p.lineno(1)))
        else:
            p[0] = p[1]

    def p_expression(self, p):
        """ expression  : assignment_expression
                            | expression COMMA assignment_expression
            """
        if len(p) == 2:
            p[0] = p[1]
        else:
            if not isinstance(p[1], c_ast.ExprList):
                p[1] = c_ast.ExprList([p[1]], p[1].coord)
            p[1].exprs.append(p[3])
            p[0] = p[1]

    def p_typedef_name(self, p):
        """ typedef_name : TYPEID """
        p[0] = c_ast.IdentifierType([p[1]], coord=self._coord(p.lineno(1)))

    def p_assignment_expression(self, p):
        """ assignment_expression   : conditional_expression
                                        | unary_expression assignment_operator assignment_expression
            """
        if len(p) == 2:
            p[0] = p[1]
        else:
            p[0] = c_ast.Assignment(p[2], p[1], p[3], p[1].coord)

    def p_assignment_operator(self, p):
        """ assignment_operator : EQUALS
                                    | XOREQUAL
                                    | TIMESEQUAL
                                    | DIVEQUAL
                                    | MODEQUAL
                                    | PLUSEQUAL
                                    | MINUSEQUAL
                                    | LSHIFTEQUAL
                                    | RSHIFTEQUAL
                                    | ANDEQUAL
                                    | OREQUAL
            """
        p[0] = p[1]

    def p_constant_expression(self, p):
        """ constant_expression : conditional_expression """
        p[0] = p[1]

    def p_conditional_expression(self, p):
        """ conditional_expression  : binary_expression
                                        | binary_expression CONDOP expression COLON conditional_expression
                                        | binary_expression CONDOP COLON conditional_expression
            """
        if len(p) == 2:
            p[0] = p[1]
        elif len(p) == 5:
            p[0] = c_ast.TernaryOp(p[1], None, p[4], p[1].coord)
        else:
            p[0] = c_ast.TernaryOp(p[1], p[3], p[5], p[1].coord)

    def p_binary_expression(self, p):
        """ binary_expression   : cast_expression
                                    | binary_expression TIMES binary_expression
                                    | binary_expression DIVIDE binary_expression
                                    | binary_expression MOD binary_expression
                                    | binary_expression PLUS binary_expression
                                    | binary_expression MINUS binary_expression
                                    | binary_expression RSHIFT binary_expression
                                    | binary_expression LSHIFT binary_expression
                                    | binary_expression LT binary_expression
                                    | binary_expression LE binary_expression
                                    | binary_expression GE binary_expression
                                    | binary_expression GT binary_expression
                                    | binary_expression EQ binary_expression
                                    | binary_expression NE binary_expression
                                    | binary_expression AND binary_expression
                                    | binary_expression OR binary_expression
                                    | binary_expression XOR binary_expression
                                    | binary_expression LAND binary_expression
                                    | binary_expression LOR binary_expression
            """
        if len(p) == 2:
            p[0] = p[1]
        else:
            p[0] = c_ast.BinaryOp(p[2], p[1], p[3], p[1].coord)

    def p_cast_expression_1(self, p):
        """ cast_expression : unary_expression """
        p[0] = p[1]

    def p_cast_expression_2(self, p):
        """ cast_expression : LPAREN type_name RPAREN cast_expression """
        p[0] = c_ast.Cast(p[2], p[4], self._coord(p.lineno(1)))

    def p_unary_expression_1(self, p):
        """ unary_expression    : postfix_expression """
        p[0] = p[1]

    def p_unary_expression_2(self, p):
        """ unary_expression    : PLUSPLUS unary_expression
                                    | MINUSMINUS unary_expression
                                    | unary_operator cast_expression
            """
        p[0] = c_ast.UnaryOp(p[1], p[2], p[2].coord)

    def p_unary_expression_3(self, p):
        """ unary_expression    : SIZEOF unary_expression
                                    | SIZEOF LPAREN type_name RPAREN
                                    | _ALIGNOF unary_expression
                                    | _ALIGNOF LPAREN type_name RPAREN
            """
        p[0] = c_ast.UnaryOp(p[1], p[2] if len(p) == 3 else p[3], self._coord(p.lineno(1)))

    def p_unary_expression_4(self, p):
        """ unary_expression    : LAND ID
                                    | LAND TYPEID
            """
        p[0] = c_ast.UnaryOp('&&', c_ast.ID(p[2], self._coord(p.lineno(2))), self._coord(p.lineno(1)))

    def p_unary_operator(self, p):
        """ unary_operator  : AND
                                | TIMES
                                | PLUS
                                | MINUS
                                | NOT
                                | LNOT
            """
        p[0] = p[1]

    def p_postfix_expression_1(self, p):
        """ postfix_expression  : primary_expression """
        p[0] = p[1]

    def p_postfix_expression_2(self, p):
        """ postfix_expression  : postfix_expression LBRACKET expression RBRACKET """
        p[0] = c_ast.ArrayRef(p[1], p[3], p[1].coord)

    def p_postfix_expression_3(self, p):
        """ postfix_expression  : postfix_expression LPAREN argument_expression_list RPAREN
                                    | postfix_expression LPAREN RPAREN
            """
        p[0] = c_ast.FuncCall(p[1], p[3] if len(p) == 5 else None, p[1].coord)

    def p_postfix_expression_4(self, p):
        """ postfix_expression  : postfix_expression PERIOD ID
                                    | postfix_expression PERIOD TYPEID
                                    | postfix_expression ARROW ID
                                    | postfix_expression ARROW TYPEID
            """
        field = c_ast.ID(p[3], self._coord(p.lineno(3)))
        p[0] = c_ast.StructRef(p[1], p[2], field, p[1].coord)

    def p_postfix_expression_5(self, p):
        """ postfix_expression  : postfix_expression PLUSPLUS
                                    | postfix_expression MINUSMINUS
            """
        p[0] = c_ast.UnaryOp('p' + p[2], p[1], p[1].coord)

    def p_postfix_expression_6(self, p):
        """ postfix_expression  : LPAREN type_name RPAREN brace_open brace_close
                                    | LPAREN type_name RPAREN brace_open initializer_list COMMA brace_close
                                    | LPAREN type_name RPAREN brace_open initializer_list brace_close
            """
        if len(p) == 6:
            init = c_ast.InitList([], self._coord(p.lineno(4)))
        else:
            init = p[5]
        p[0] = c_ast.CompoundLiteral(p[2], init)

    def p_postfix_expression_7(self, p):
        """ postfix_expression  : BUILTIN_VA_ARG LPAREN assignment_expression COMMA type_name RPAREN """
        coord = self._coord(p.lineno(1))
        ptr_type = c_ast.Typename(None, getattr(p[5], 'quals', None), c_ast.PtrDecl([], p[5].type, coord), coord)
        call = c_ast.FuncCall(c_ast.ID('__builtin_va_arg', coord), c_ast.ExprList([p[3]], coord), coord)
        p[0] = c_ast.UnaryOp('*', c_ast.Cast(ptr_type, call, coord), coord)

    def p_postfix_expression_8(self, p):
        """ postfix_expression  : BUILTIN_VA_ARG LPAREN assignment_expression COMMA assignment_expression RPAREN """
        coord = self._coord(p.lineno(1))
        p[0] = c_ast.FuncCall(c_ast.ID('__builtin_va_arg', coord), c_ast.ExprList([p[3], p[5]], coord), coord)

    def p_primary_expression_1(self, p):
        """ primary_expression  : identifier """
        p[0] = p[1]

    def p_primary_expression_2(self, p):
        """ primary_expression  : constant """
        p[0] = p[1]

    def p_primary_expression_3(self, p):
        """ primary_expression  : unified_string_literal
                                    | unified_wstring_literal
            """
        p[0] = p[1]

    def p_primary_expression_4(self, p):
        """ primary_expression  : LPAREN expression RPAREN """
        p[0] = p[2]

    def p_primary_expression_5(self, p):
        """ primary_expression  : LPAREN compound_statement RPAREN """
        p[0] = c_ast.StmtExpr(p[2], self._coord(p.lineno(1)))

    def p_primary_expression_6(self, p):
        """ primary_expression  : _GENERIC LPAREN assignment_expression COMMA generic_assoc_list RPAREN
            """
        p[0] = c_ast.GenericSelection(p[3], p[5], self._coord(p.lineno(1)))

    def p_primary_expression_7(self, p):
        """ primary_expression  : OFFSETOF LPAREN type_name COMMA identifier RPAREN
            """
        coord = self._coord(p.lineno(1))
        p[0] = c_ast.FuncCall(c_ast.ID(p[1], coord), c_ast.ExprList([p[3], p[5]], coord), coord)

    def p_primary_expression_nullptr(self, p):
        """ primary_expression  : NULLPTR
            """
        p[0] = c_ast.Constant('nullptr_t', 'nullptr', self._coord(p.lineno(1)))

    def p_generic_assoc_list(self, p):
        """ generic_assoc_list : generic_association
                                   | generic_assoc_list COMMA generic_association
            """
        if len(p) == 2:
            p[0] = [p[1]]
        else:
            p[1].append(p[3])
            p[0] = p[1]

    def p_generic_association(self, p):
        """ generic_association : type_name COLON assignment_expression
                                    | DEFAULT COLON assignment_expression
            """
        assoc_type = None if p.slice[1].type == 'DEFAULT' else p[1]
        p[0] = c_ast.GenericAssociation(assoc_type, p[3], self._coord(p.lineno(1)))

    def p_argument_expression_list(self, p):
        """ argument_expression_list    : assignment_expression
                                            | argument_expression_list COMMA assignment_expression
            """
        if len(p) == 2:
            p[0] = c_ast.ExprList([p[1]], p[1].coord)
        else:
            p[1].exprs.append(p[3])
            p[0] = p[1]

    def p_identifier(self, p):
        """ identifier  : ID """
        p[0] = c_ast.ID(p[1], self._coord(p.lineno(1)))

    def p_constant_1(self, p):
        """ constant    : INT_CONST_DEC
                            | INT_CONST_OCT
                            | INT_CONST_HEX
                            | INT_CONST_BIN
            """
        p[0] = c_ast.Constant('int', p[1], self._coord(p.lineno(1)))

    def p_constant_2(self, p):
        """ constant    : FLOAT_CONST
                            | HEX_FLOAT_CONST
            """
        p[0] = c_ast.Constant('float', p[1], self._coord(p.lineno(1)))

    def p_constant_3(self, p):
        """ constant    : CHAR_CONST
                            | WCHAR_CONST
            """
        p[0] = c_ast.Constant('char', p[1], self._coord(p.lineno(1)))

    def p_unified_string_literal(self, p):
        """ unified_string_literal  : STRING_LITERAL
                                        | unified_string_literal STRING_LITERAL
            """
        if len(p) == 2:
            p[0] = c_ast.Constant('string', p[1], self._coord(p.lineno(1)))
        else:
            p[1].value = p[1].value[:-1] + p[2][1:]
            p[0] = p[1]

    def p_unified_wstring_literal(self, p):
        """ unified_wstring_literal : WSTRING_LITERAL
                                        | unified_wstring_literal WSTRING_LITERAL
                                        | unified_wstring_literal STRING_LITERAL
                                        | STRING_LITERAL WSTRING_LITERAL
            """
        if len(p) == 2:
            p[0] = c_ast.Constant('wstring', p[1], self._coord(p.lineno(1)))
        elif isinstance(p[1], c_ast.Constant):
            p[1].value = p[1].value.rstrip()[:-1] + p[2][1 + (p[2][0] == 'L'):]
            p[0] = p[1]
        else:
            p[0] = c_ast.Constant('wstring', 'L' + p[1][:-1] + p[2][2:], self._coord(p.lineno(1)))

    def p_brace_open(self, p):
        """ brace_open  :   LBRACE
            """
        p[0] = p[1]

    def p_brace_close(self, p):
        """ brace_close :   RBRACE
            """
        p[0] = p[1]

    def p_empty(self, p):
        """empty : """
        p[0] = None

    def p_error(self, p):
        if p:
            self._parse_error('before: %s' % p.value, self._coord(lineno=p.lineno, column=self.clex.find_tok_column(p)))
        else:
            self._parse_error('At end of input', '')
