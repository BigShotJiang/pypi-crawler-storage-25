"""Signal definitions and transformations."""
