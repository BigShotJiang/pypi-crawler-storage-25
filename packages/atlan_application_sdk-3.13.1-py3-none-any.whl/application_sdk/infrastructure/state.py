"""State store abstraction."""

import warnings
from typing import Any, ClassVar, Protocol

from application_sdk.errors import STATE_STORE_ERROR, ErrorCode
from application_sdk.errors.leaves import DependencyUnavailableError


class StateStoreError(DependencyUnavailableError):
    """Deprecated: use ``application_sdk.errors.DependencyUnavailableError`` — removed in v4.0."""

    DEFAULT_ERROR_CODE: ClassVar[ErrorCode] = STATE_STORE_ERROR
    code: ClassVar[str] = "STATE_STORE"

    def __init__(
        self,
        message: str,
        *,
        key: str | None = None,
        operation: str | None = None,
        cause: Exception | None = None,
        error_code: ErrorCode | None = None,
    ) -> None:
        warnings.warn(
            "StateStoreError is deprecated; use application_sdk.errors.DependencyUnavailableError "
            "— will be removed in v4.0",
            DeprecationWarning,
            stacklevel=2,
        )
        DependencyUnavailableError.__init__(self, message=message, cause=cause)
        self.key = key
        self.operation = operation
        self._error_code = error_code

    @property
    def error_code(self) -> ErrorCode:
        return (
            self._error_code
            if self._error_code is not None
            else self.DEFAULT_ERROR_CODE
        )

    def __str__(self) -> str:
        parts = [f"[{self.error_code.code}] {self.message}"]
        if self.key:
            parts.append(f"key={self.key}")
        if self.operation:
            parts.append(f"operation={self.operation}")
        if self.cause:
            parts.append(f"caused_by={type(self.cause).__name__}: {self.cause}")
        return " | ".join(parts)


class StateStore(Protocol):
    """Protocol for state storage.

    State stores provide key-value storage for Apps.
    The underlying implementation (DAPR, Redis, etc.) is hidden.
    """

    async def save(self, key: str, value: dict[str, Any]) -> None: ...
    async def load(self, key: str) -> dict[str, Any] | None: ...
    async def delete(self, key: str) -> bool: ...
    async def list_keys(self, prefix: str = "") -> list[str]: ...
