# llm-pentest-benchmark

CTF evaluation platform for AI pentest agents. Provides the server, nodes,
challenge library, and API surface that external agents / evaluation harnesses
consume over REST or MCP.

## Install

```bash
uv sync
cp .env.example .env
```

## Platform

The deployment has two services: **platform** (API + Web UI + scheduling) and
**node** (runs challenge containers via Docker). They communicate over HTTP
with a shared cluster token (`LPB_NODE_TOKEN`).

```bash
# Single-host default: one platform + one node
docker compose up -d

# Locally without Docker
uv run lpb server start      # terminal 1
uv run lpb node join         # terminal 2 (needs LPB_PLATFORM_URL + LPB_NODE_TOKEN)
```

### Scale out / add a node

```bash
# Ask the running platform for a ready-to-paste command
uv run lpb server invite --role node --capacity 4 --label zone=us
# → prints a `docker run -d ... ghcr.io/.../llm-pentest-benchmark-node:latest`
# Append `--output compose` to get a docker-compose snippet instead.
```

On another host: run that `docker run` command with `LPB_NODE_PUBLIC_URL` set
to a URL the platform can reach (e.g. `http://<host-ip>:8101`).

## Using the platform

Once the server is up, clients (agents, MCP sessions, CI harnesses) register a
team and drive challenges over REST:

```bash
# Register and capture the returned team token
curl -X POST http://localhost:8100/api/v1/teams \
  -H 'Content-Type: application/json' \
  -d '{"name":"my-team","agent":"claude-code"}'

# Start a challenge, submit the flag, check the scoreboard
curl -X POST http://localhost:8100/api/v1/instances \
  -H "Authorization: Bearer $LPB_TEAM_TOKEN" \
  -d '{"challenge_id":"XBOW-009"}'
```

The same surface is also available via the bundled MCP server (`lpb mcp`) and
the Python SDK (`PlatformClient`).

## Development

```bash
uv sync --extra dev
uv run pytest tests/ --ignore=tests/test_e2e_docker.py
```
