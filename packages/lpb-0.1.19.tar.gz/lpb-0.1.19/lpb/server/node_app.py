"""Node-side FastAPI application factory.

Stands up a worker process that exposes the node HTTP contract (see
``server/routes/node_instances.py``), registers itself with the platform,
and runs a heartbeat loop so the platform can mark it unhealthy on loss.
"""

from __future__ import annotations

import asyncio
import hmac
import socket
from contextlib import asynccontextmanager
from dataclasses import dataclass, field
from typing import Any

import httpx
from fastapi import Depends, FastAPI, HTTPException
from fastapi.security import HTTPAuthorizationCredentials

from lpb.core.challenge import ChallengeManager
from lpb.core.config import LpbConfig
from lpb.core.enums import InstanceStatus
from lpb.core.log import log, setup_logging
from lpb.core.ports import PortAllocator
from lpb.server.auth import bearer_optional
from lpb.server.node_state import NodeInstanceStore

DEFAULT_HEARTBEAT_INTERVAL = 30  # seconds
DEFAULT_REGISTER_RETRIES = 6
DEFAULT_REGISTER_BACKOFF = 2.0  # seconds (doubled each retry)


def _default_public_host() -> str:
    """Best-effort external host; only used if LPB_NODE_PUBLIC_URL unset."""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("8.8.8.8", 80))
            return s.getsockname()[0]
    except OSError:
        return socket.gethostname()


@dataclass
class NodeAppState:
    """Shared state for the node process. Kept deliberately small."""

    cluster_token: str
    public_url: str
    capacity: int
    labels: dict[str, str] = field(default_factory=dict)
    node_id: str = ""
    platform_url: str = ""
    store: NodeInstanceStore | None = None
    challenge_manager: Any = field(default=None, repr=False)
    # Auth dep; injected into routes.
    require_cluster: Any = field(default=None, repr=False)


def make_require_cluster_fixed(expected: str):
    """Cluster-token auth for node side — compares against a fixed env value
    rather than a DB-backed config, because the node has no state backend."""

    async def _dep(
        credentials: HTTPAuthorizationCredentials | None = Depends(bearer_optional),
    ):
        if not expected:
            raise HTTPException(403, "LPB_NODE_TOKEN not configured; node API disabled")
        if not credentials:
            raise HTTPException(401, "Missing bearer token")
        if not hmac.compare_digest(credentials.credentials, expected):
            raise HTTPException(403, "Invalid cluster token")

    return _dep


# ---------------------------------------------------------------------------
# Self-registration + heartbeat
# ---------------------------------------------------------------------------


def _parse_labels(raw: str) -> dict[str, str]:
    """Parse ``k=v,k=v`` form."""
    out: dict[str, str] = {}
    for chunk in raw.split(","):
        chunk = chunk.strip()
        if not chunk:
            continue
        if "=" in chunk:
            k, v = chunk.split("=", 1)
            out[k.strip()] = v.strip()
        else:
            out[chunk] = "true"
    return out


async def _register_with_platform(state: NodeAppState) -> bool:
    """POST to ``/nodes/register`` with exponential backoff. Returns True on
    success; False after all retries exhausted."""
    if not state.platform_url:
        log.warning("LPB_PLATFORM_URL not set; skipping node registration")
        return False
    url = f"{state.platform_url.rstrip('/')}/api/v1/nodes/register"
    headers = {"Authorization": f"Bearer {state.cluster_token}"}
    body = {
        "url": state.public_url,
        "capacity": state.capacity,
        "labels": state.labels,
    }
    delay = DEFAULT_REGISTER_BACKOFF
    for attempt in range(DEFAULT_REGISTER_RETRIES):
        try:
            async with httpx.AsyncClient(timeout=10) as c:
                resp = await c.post(url, json=body, headers=headers)
            if resp.status_code == 200:
                node = resp.json()
                state.node_id = node.get("node_id", "")
                log.info(
                    "Node registered with platform",
                    node_id=state.node_id,
                    public_url=state.public_url,
                )
                return True
            log.warning(
                "Node registration rejected; retrying",
                status=resp.status_code,
                body=resp.text[:200],
            )
        except Exception as exc:
            log.warning("Node registration failed; retrying", error=str(exc))
        await asyncio.sleep(delay)
        delay *= 2
    log.error("Node registration exhausted retries")
    return False


async def _heartbeat_once(state: NodeAppState) -> None:
    if not state.platform_url or not state.node_id:
        return
    url = f"{state.platform_url.rstrip('/')}/api/v1/nodes/heartbeat"
    headers = {"Authorization": f"Bearer {state.cluster_token}"}
    params = {
        "node_id": state.node_id,
        "running": state.store.count() if state.store else 0,
        "capacity": state.capacity,
    }
    try:
        async with httpx.AsyncClient(timeout=5) as c:
            await c.post(url, params=params, headers=headers)
    except Exception as exc:
        log.debug("Heartbeat failed", error=str(exc))


async def _heartbeat_loop(state: NodeAppState, interval: int) -> None:
    while True:
        await asyncio.sleep(interval)
        await _heartbeat_once(state)


async def _deregister(state: NodeAppState) -> None:
    if not state.platform_url or not state.node_id:
        return
    url = f"{state.platform_url.rstrip('/')}/api/v1/nodes/{state.node_id}"
    headers = {"Authorization": f"Bearer {state.cluster_token}"}
    try:
        async with httpx.AsyncClient(timeout=5) as c:
            await c.delete(url, headers=headers)
    except Exception as exc:
        log.debug("Node deregister failed (platform will time out heartbeat)", error=str(exc))


def _reconcile_store_on_start(state: NodeAppState) -> None:
    """Mark pre-existing records ERROR: their containers were killed by the
    orphan-cleanup sweep, so the instance can no longer serve traffic even
    though we still know its flag."""
    if not state.store:
        return
    for rec in state.store.list_all():
        if rec.status not in (InstanceStatus.ERROR, InstanceStatus.STOPPED):
            state.store.set_status(
                rec.instance_id,
                InstanceStatus.ERROR,
                error="Node restarted; container no longer running",
            )


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------


def create_node_app(
    config: LpbConfig | None = None,
    *,
    public_url: str = "",
    capacity: int = 10,
    labels: dict[str, str] | None = None,
    platform_url: str = "",
    store: NodeInstanceStore | None = None,
    db_path: str = "",
    heartbeat_interval: int = DEFAULT_HEARTBEAT_INTERVAL,
    auto_register: bool = True,
) -> FastAPI:
    setup_logging()
    if config is None:
        config = LpbConfig()

    cluster_token = config.node_token.get_secret_value()
    if not cluster_token:
        log.warning(
            "LPB_NODE_TOKEN not configured; node API will reject all requests. "
            "Set LPB_NODE_TOKEN to the same value as on the platform."
        )

    public_url = public_url or f"http://{_default_public_host()}:{config.server_port}"
    platform_url = platform_url or config.platform_url
    labels = labels if labels is not None else {}

    if store is None:
        store = NodeInstanceStore(db_path or str(config.project_root / "data" / "node.sqlite3"))

    challenge_manager = ChallengeManager(
        config,
        PortAllocator(config.port_range_start, config.port_range_end),
    )

    state = NodeAppState(
        cluster_token=cluster_token,
        public_url=public_url,
        platform_url=platform_url,
        capacity=capacity,
        labels=labels,
        store=store,
        challenge_manager=challenge_manager,
    )
    state.require_cluster = make_require_cluster_fixed(cluster_token)

    @asynccontextmanager
    async def lifespan(_app: FastAPI):
        # Clean up any stale Docker containers from before this process started.
        try:
            from lpb.providers.docker_provider.utils import cleanup_orphans

            await asyncio.get_running_loop().run_in_executor(
                None, lambda: cleanup_orphans(instances_dir=config.instances_dir)
            )
        except Exception as exc:
            log.warning("Orphan cleanup skipped", error=str(exc))

        # Mark surviving records as ERROR (container is gone after cleanup).
        _reconcile_store_on_start(state)

        tasks: list[asyncio.Task] = []
        if auto_register and platform_url:
            registered = await _register_with_platform(state)
            if registered:
                tasks.append(asyncio.create_task(_heartbeat_loop(state, heartbeat_interval)))

        try:
            yield
        finally:
            for t in tasks:
                t.cancel()
                try:
                    await t
                except (asyncio.CancelledError, Exception):
                    pass
            await _deregister(state)

    app = FastAPI(
        title="LLM Pentest Benchmark — Node",
        description="Worker node HTTP API. Authenticates with cluster token.",
        lifespan=lifespan,
    )

    # Routes are mounted under /api/v1 — matches the platform SDK's base path.
    from lpb.server.routes import node_instances

    app.include_router(node_instances.create_router(state), prefix="/api/v1")

    @app.get("/api/v1/health")
    def health():
        return {
            "status": "ok",
            "public_url": state.public_url,
            "capacity": state.capacity,
            "running": state.store.count() if state.store else 0,
            "labels": state.labels,
        }

    # Expose state for tests / debugging.
    app.state.node = state
    return app
