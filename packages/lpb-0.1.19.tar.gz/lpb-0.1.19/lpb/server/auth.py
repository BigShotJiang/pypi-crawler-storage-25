"""Authentication and ownership dependencies for the platform server.

Three token identities are supported:

- **admin** (DB key ``admin_key``, env ``LPB_ADMIN_TOKEN``): human operator;
  manage teams, list/remove nodes, stop-all.
- **cluster** (DB key ``cluster_key``, env ``LPB_NODE_TOKEN``): platform<->node
  machine calls. Not exposed to end users.
- **team** (stored per-team in ``teams`` table): end users calling the platform
  for their own resources.

Ownership helpers (:func:`get_team_id`, :func:`check_ownership`) live here
because "who is this team and what may they touch" is one concern.
"""

from __future__ import annotations

import hashlib
import hmac

from fastapi import Depends, HTTPException
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from lpb.core.exceptions import ForbiddenError
from lpb.core.state import StateBackend
from lpb.core.state.models import InstanceState, TeamState

# Shared security schemes — HTTPBearer handles "Bearer " parsing automatically
bearer_required = HTTPBearer()  # no token → 403
bearer_optional = HTTPBearer(auto_error=False)  # no token → None


def hash_token(token: str) -> str:
    """SHA-256 hash of a plaintext bearer token. Used for storage and lookup."""
    return hashlib.sha256(token.encode()).hexdigest()


def _resolve_team(
    state_backend: StateBackend, credentials: HTTPAuthorizationCredentials
) -> TeamState:
    """Shared: resolve credentials to team model, or raise 403."""
    team = state_backend.get_team_by_token(hash_token(credentials.credentials))
    if not team:
        raise HTTPException(403, "Invalid team token")
    return team


def token_dependency(
    state_backend: StateBackend,
    *,
    config_keys: tuple[str, ...],
    permissive: bool = False,
    unconfigured_msg: str = "",
    invalid_msg: str = "Invalid token",
):
    """FastAPI dependency factory for shared-secret token auth.

    Loads each ``config_keys`` value from the state backend at request time.
    Authentication succeeds if the bearer token matches **any** configured
    value. Behavior when none of the keys are configured is controlled by
    *permissive* / *unconfigured_msg* (mutually exclusive — use whichever
    fits the route's policy):

    - ``permissive=True``  → return ``None`` (no auth enforced)
    - ``unconfigured_msg`` → raise 403 with that message (explicit refusal)
    - both unset           → fall through and 403 with *invalid_msg*
    """

    async def dep(
        credentials: HTTPAuthorizationCredentials | None = Depends(bearer_optional),
    ):
        expected = [v for k in config_keys if (v := state_backend.get_config(k))]
        if not expected:
            if permissive:
                return None
            if unconfigured_msg:
                raise HTTPException(403, unconfigured_msg)
        if not credentials:
            raise HTTPException(401, "Missing bearer token")
        if any(hmac.compare_digest(credentials.credentials, e) for e in expected):
            return None
        raise HTTPException(403, invalid_msg)

    return dep


def make_require_admin(state_backend: StateBackend):
    """Strict admin auth: rejects if no admin_key is configured."""
    return token_dependency(
        state_backend,
        config_keys=("admin_key",),
        unconfigured_msg="Admin key not configured; node management disabled",
        invalid_msg="Invalid admin API key",
    )


def make_require_cluster(state_backend: StateBackend):
    """Strict cluster-token auth: authenticates platform<->node machine calls.

    Rejects if no cluster_key is configured in the DB. Used on node-side
    endpoints (every node API) and on platform-side endpoints intended to be
    called by nodes only (``/nodes/register``, ``/nodes/heartbeat``, node
    self-deletion).
    """
    return token_dependency(
        state_backend,
        config_keys=("cluster_key",),
        unconfigured_msg="Cluster token not configured; cluster endpoints disabled",
        invalid_msg="Invalid cluster token",
    )


def make_require_admin_or_cluster(state_backend: StateBackend):
    """Either admin or cluster token is acceptable.

    Used on platform endpoints that can be called both by humans (admin) and
    by node processes (cluster) — e.g. ``DELETE /nodes/{id}``.
    """
    return token_dependency(
        state_backend,
        config_keys=("admin_key", "cluster_key"),
        invalid_msg="Invalid admin or cluster token",
    )


def make_get_current_team(state_backend: StateBackend):
    """Strict team auth: resolves Bearer token -> team model. 403 if missing."""

    async def get_current_team(
        credentials: HTTPAuthorizationCredentials = Depends(bearer_required),
    ) -> TeamState:
        return _resolve_team(state_backend, credentials)

    return get_current_team


def make_get_current_team_or_none(state_backend: StateBackend):
    """Optional team auth: returns team model if token provided and valid, None otherwise."""

    async def get_current_team_or_none(
        credentials: HTTPAuthorizationCredentials | None = Depends(bearer_optional),
    ) -> TeamState | None:
        if not credentials:
            return None
        team = state_backend.get_team_by_token(hash_token(credentials.credentials))
        return team  # None if token doesn't match any team (e.g. admin key)

    return get_current_team_or_none


# ---------------------------------------------------------------------------
# Ownership helpers — used by routes to guard per-team resource access.
# ---------------------------------------------------------------------------


def get_team_id(team: TeamState | None) -> str:
    """Extract ``team_id`` from an optional team model (empty when anonymous)."""
    return team.team_id if team else ""


def check_ownership(
    resource: TeamState | InstanceState,
    team: TeamState | None,
    resource_name: str = "resource",
) -> None:
    """Raise :class:`ForbiddenError` if the authenticated team doesn't own *resource*."""
    if team and resource.team_id and resource.team_id != team.team_id:
        raise ForbiddenError(f"Not your {resource_name}")
