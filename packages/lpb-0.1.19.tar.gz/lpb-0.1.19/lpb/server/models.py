"""Data models for the CTF platform API surface."""

from __future__ import annotations

from fastapi import Query
from fastapi_pagination import LimitOffsetPage
from fastapi_pagination.customization import CustomizedPage, UseParamsFields
from fastapi_pagination.utils import disable_installed_extensions_check
from pydantic import Field

from lpb.core.activity import ActivityDetail
from lpb.core.constants import DEFAULT_INSTANCE_TTL, DEFAULT_NODE_CAPACITY
from lpb.core.enums import ExposeType, InstanceStatus
from lpb.core.models import LpbModel
from lpb.core.target import AttackSurface, ServiceEndpoint

# fastapi-pagination logs a warning when SQLAlchemy etc. aren't installed;
# we don't use those integrations, so silence the notice.
disable_installed_extensions_check()

# Custom pagination page with a higher max limit (default 50, up to 10000).
# Used by endpoints that may legitimately page through large result sets
# (scoreboard, submissions, challenges).
BigLimitOffsetPage = CustomizedPage[
    LimitOffsetPage,
    UseParamsFields(limit=Query(50, ge=1, le=10000)),
]

# ---------------------------------------------------------------------------
# Team
# ---------------------------------------------------------------------------


class TeamCreate(LpbModel):
    name: str
    agent: str = ""
    description: str = ""


class TeamResponse(LpbModel):
    team_id: str
    name: str
    agent: str
    description: str = ""
    token: str
    created_at: str


class TeamInfo(LpbModel):
    team_id: str
    name: str
    agent: str
    description: str = ""
    created_at: str
    solves: int = 0
    attempts: int = 0


# ---------------------------------------------------------------------------
# Challenge
# ---------------------------------------------------------------------------


class ChallengeInfo(LpbModel):
    id: str
    name: str
    category: str
    difficulty: int = 1
    description: str = ""
    solves_count: int = 0
    environment: str = ""
    tags: list[str] = Field(default_factory=list)
    # See core.enums.ExposeType. Controls how a running instance is
    # surfaced to end users.
    expose_type: str = ExposeType.TCP_PORT


# ---------------------------------------------------------------------------
# Submission
# ---------------------------------------------------------------------------


class SubmissionCreate(LpbModel):
    challenge_id: str
    flag: str


class SubmissionResponse(LpbModel):
    submission_id: str
    correct: bool
    solve_time_s: float = 0  # seconds from instance start to correct submission


# ---------------------------------------------------------------------------
# Scoreboard
# ---------------------------------------------------------------------------


class ScoreboardEntry(LpbModel):
    rank: int = 0
    team_id: str
    team_name: str
    agent: str = ""
    solved: int = 0
    attempts: int = 0
    last_solve_at: str = ""


class ChallengeStats(LpbModel):
    challenge_id: str
    name: str = ""
    category: str = ""
    difficulty: int = 1
    solves_count: int = 0
    total_attempts: int = 0
    success_rate: float = 0.0


# ---------------------------------------------------------------------------
# Activity Log
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Nodes (multi-node cluster)
# ---------------------------------------------------------------------------


class NodeRegister(LpbModel):
    url: str  # e.g. "http://node1:8100"
    capacity: int = DEFAULT_NODE_CAPACITY
    labels: dict[str, str] = Field(default_factory=dict)  # optional metadata


class NodeInfo(LpbModel):
    node_id: str
    url: str
    capacity: int = 0
    running: int = 0
    healthy: bool = True
    last_heartbeat: str = ""
    labels: dict[str, str] = Field(default_factory=dict)


class ClusterInfo(LpbModel):
    """Returned by ``GET /cluster-info`` — feeds ``lpb server invite``."""

    platform_url: str
    cluster_token: str
    node_image: str


# ---------------------------------------------------------------------------
# Activity Log
# ---------------------------------------------------------------------------


class Activity(LpbModel):
    """A single activity event in the platform log."""

    id: str = ""
    timestamp: str = ""
    event: str  # See PlatformEvent enum for valid values
    team_id: str = ""
    team_name: str = ""
    challenge_id: str = ""
    detail: ActivityDetail = Field(default_factory=ActivityDetail)


# ---------------------------------------------------------------------------
# Instance
# ---------------------------------------------------------------------------


class InstanceInfo(LpbModel):
    instance_id: str
    challenge_id: str = ""
    team_id: str = ""
    name: str = ""
    category: str = ""
    difficulty: int = 1
    status: str = InstanceStatus.STARTING
    started_at: float = 0.0
    ttl: int = 0
    expires_at: float = 0.0
    services: list[ServiceEndpoint] = Field(default_factory=list)


class InstanceStatusResponse(LpbModel):
    instance_id: str
    status: str = InstanceStatus.STARTING
    attack_surface: AttackSurface | None = None
    error: str | None = None
    sandbox_network: str = ""
    proxy_gateway: str = ""
    cert_volume: str = ""
    # Exposure strategy echoed from the challenge spec. See ExposeType
    # for the semantics; for HTTP_DOMAIN the runtime Traefik rule puts
    # the reachable URL in ``public_url``.
    expose_type: str = ExposeType.TCP_PORT
    public_url: str = ""


class StartResponse(LpbModel):
    instance_id: str
    status: str = InstanceStatus.STARTING


class StopResponse(LpbModel):
    status: str = InstanceStatus.STOPPED
    instance_id: str


class RenewResponse(LpbModel):
    status: str = "renewed"
    instance_id: str
    expires_at: float


class VerifyFlagRequest(LpbModel):
    claimed_flag: str


class VerifyFlagResponse(LpbModel):
    correct: bool
    flag_expected: str = ""


# ---------------------------------------------------------------------------
# Health
# ---------------------------------------------------------------------------


class HealthResponse(LpbModel):
    status: str = "ok"
    hostname: str = ""
    running_instances: int = 0
    capacity: int = 0


# ---------------------------------------------------------------------------
# Error envelope
# ---------------------------------------------------------------------------


class ErrorResponse(LpbModel):
    """Unified shape for every HTTP 4xx/5xx body produced by platform routes.

    ``detail`` mirrors the pre-existing field (so SDK / CLI / frontend code
    that reads ``data.detail`` keeps working); ``code`` adds a stable
    machine-readable identifier derived from the raising exception class,
    and ``timestamp`` is server-side UTC in ISO 8601 — useful when
    correlating client-side and server-side logs.
    """

    code: str
    detail: str
    timestamp: str


# ---------------------------------------------------------------------------
# Start Request
# ---------------------------------------------------------------------------


class StartRequest(LpbModel):
    challenge_id: str
    proxy_output_dir: str | None = None
    ttl: int = DEFAULT_INSTANCE_TTL
