"""Per-node persistent instance store.

A node owns (a) the generated flag for every instance it hosts and (b) all
Docker-specific metadata. The flag cannot live on the platform — losing it
on node restart would silently break submissions — so we persist it here
in a small SQLite file beside the node process.

Pydantic provider handles (``StartResult`` etc.) are *not* persisted: they
live in an in-memory hot cache keyed by ``instance_id`` and are rebuilt or
cleaned up by the node's orphan-cleanup pass on startup.
"""

from __future__ import annotations

import json
import sqlite3
import threading
import time
from pathlib import Path
from typing import Any

from pydantic import BaseModel

from lpb.core.target import AttackSurface


class NodeInstanceRecord(BaseModel):
    """Persisted view of an instance on this node.

    Post-step-18 the flag lives on the platform; the node only keeps
    operational metadata so it can keep serving /status and /health
    across a restart.
    """

    instance_id: str
    challenge_id: str
    proxy_output: str = ""
    status: str = ""
    error: str = ""
    surface: AttackSurface | None = None
    started_at: float = 0.0
    ttl: int = 0

    @property
    def expires_at(self) -> float:
        return self.started_at + self.ttl if self.ttl > 0 else 0.0

    def is_expired(self, now: float | None = None) -> bool:
        if self.ttl <= 0:
            return False
        return (now or time.time()) >= self.expires_at


class NodeInstanceStore:
    """SQLite-backed store; one file per node process.

    Safe for concurrent use from multiple threads via a single shared
    connection with check_same_thread=False + an internal lock.
    """

    def __init__(self, db_path: str | Path) -> None:
        path = Path(db_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(path), check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._lock = threading.Lock()
        self._init_tables()

    def _init_tables(self) -> None:
        with self._conn:
            self._conn.execute(
                """
                CREATE TABLE IF NOT EXISTS instances (
                    instance_id TEXT PRIMARY KEY,
                    data TEXT NOT NULL
                )
                """
            )

    # -- CRUD ---------------------------------------------------------------

    def put(self, rec: NodeInstanceRecord) -> None:
        with self._lock, self._conn:
            self._conn.execute(
                "INSERT OR REPLACE INTO instances (instance_id, data) VALUES (?, ?)",
                (rec.instance_id, rec.model_dump_json()),
            )

    def get(self, instance_id: str) -> NodeInstanceRecord | None:
        with self._lock:
            row = self._conn.execute(
                "SELECT data FROM instances WHERE instance_id = ?", (instance_id,)
            ).fetchone()
        return NodeInstanceRecord.model_validate_json(row[0]) if row else None

    def delete(self, instance_id: str) -> None:
        with self._lock, self._conn:
            self._conn.execute("DELETE FROM instances WHERE instance_id = ?", (instance_id,))

    def list_all(self) -> list[NodeInstanceRecord]:
        with self._lock:
            rows = self._conn.execute("SELECT data FROM instances").fetchall()
        return [NodeInstanceRecord.model_validate_json(r[0]) for r in rows]

    def count(self) -> int:
        with self._lock:
            row = self._conn.execute("SELECT COUNT(*) FROM instances").fetchone()
        return int(row[0]) if row else 0

    # -- convenience updates ------------------------------------------------

    def set_status(
        self,
        instance_id: str,
        status: str,
        *,
        error: str = "",
        surface: AttackSurface | None = None,
    ) -> NodeInstanceRecord | None:
        rec = self.get(instance_id)
        if not rec:
            return None
        updated = rec.model_copy(
            update={
                "status": status,
                "error": error or rec.error,
                "surface": surface if surface is not None else rec.surface,
            }
        )
        self.put(updated)
        return updated

    def pop_expired(self, now: float | None = None) -> list[NodeInstanceRecord]:
        """Remove and return any records past their TTL."""
        t = now or time.time()
        expired = [r for r in self.list_all() if r.is_expired(t)]
        for r in expired:
            self.delete(r.instance_id)
        return expired

    # -- raw escape hatch (useful for tests) --------------------------------

    def _raw(self, instance_id: str) -> dict[str, Any] | None:
        with self._lock:
            row = self._conn.execute(
                "SELECT data FROM instances WHERE instance_id = ?", (instance_id,)
            ).fetchone()
        return json.loads(row[0]) if row else None

    def close(self) -> None:
        self._conn.close()
