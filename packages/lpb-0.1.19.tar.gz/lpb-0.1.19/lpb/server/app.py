"""Instance server — FastAPI application factory.

All state is stored in a ``StateBackend`` (Redis or in-memory). The flag
is **never** returned to clients; use ``POST /instances/{id}/verify-flag``
to check a candidate flag.
"""

from __future__ import annotations

import asyncio
import socket
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import Depends, FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi_pagination import add_pagination
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded
from slowapi.util import get_remote_address

from lpb.core.challenge import ChallengeManager
from lpb.core.config import LpbConfig
from lpb.core.constants import DEFAULT_MAX_INSTANCES
from lpb.core.exceptions import (
    CapacityExceededError,
    ChallengeNotFoundError,
    FlagNotFoundError,
    ForbiddenError,
    InstanceAlreadyRunningError,
    InstanceNotFoundError,
    RateLimitError,
    TeamNotFoundError,
)
from lpb.core.log import log, setup_logging
from lpb.core.ports import PortAllocator
from lpb.core.state import InMemoryBackend, StateBackend, create_backend
from lpb.core.state.models import InstanceState, TeamState
from lpb.server.app_state import AppState
from lpb.server.auth import (
    check_ownership,
    make_get_current_team,
    make_get_current_team_or_none,
    make_require_admin,
    make_require_admin_or_cluster,
    make_require_cluster,
)
from lpb.server.background import (
    make_health_check_loop,
    make_reaper_loop,
    make_reconciler_loop,
)
from lpb.server.error_handlers import register_platform_error_handlers
from lpb.server.routes import (
    activities,
    challenges,
    cluster_info,
    events,
    health,
    instances,
    nodes,
    scoreboard,
    submissions,
    teams,
)
from lpb.server.sse import SSEHub

_ROUTE_MODULES = (
    health,
    events,
    instances,
    teams,
    challenges,
    submissions,
    scoreboard,
    nodes,
    cluster_info,
    activities,
)


def _get_external_host() -> str:
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("8.8.8.8", 80))
            return s.getsockname()[0]
    except OSError:
        return socket.gethostname()


def create_platform_app(
    config: LpbConfig | None = None,
    *,
    external_host: str | None = None,
    max_instances: int = DEFAULT_MAX_INSTANCES,
    backend: StateBackend | None = None,
) -> FastAPI:
    """Build the platform FastAPI app (orchestration + API + web UI).

    The platform delegates container lifecycle to one or more worker
    nodes via ``NodeClient``. A ``ChallengeManager`` is still attached so
    the platform can read ``benchmarks/`` metadata (``iter_specs``); its
    provider methods are only used as a fallback for single-process
    setups that do not register a node.

    *config* defaults to :class:`LpbConfig` with library defaults — handy
    for tests and uvicorn factory-string use.
    """
    setup_logging()
    if config is None:
        config = LpbConfig()
    host = external_host or _get_external_host()
    state_backend = backend or create_backend(
        config.redis_url, config.db_path, project_root=config.project_root
    )
    # Metadata-only reader: ChallengeManager is reused for iter_specs only.
    # The PortAllocator is handed a no-op range because the platform never
    # allocates ports — that's the node's job.
    spec_reader = ChallengeManager(
        config,
        PortAllocator(config.port_range_start, config.port_range_end),
    )
    sse_hub = SSEHub()
    from lpb.server.traefik_router import TraefikRouter

    traefik_router = TraefikRouter(
        config.traefik_rules_path,
        base_domain=config.base_domain,
    )
    app_state = AppState(
        config=config,
        state_backend=state_backend,
        spec_reader=spec_reader,
        sse_hub=sse_hub,
        host=host,
        max_instances=max_instances,
        traefik_router=traefik_router,
    )

    # --- Auth dependencies (created once, shared by all route modules) ------
    app_state.get_current_team = make_get_current_team(state_backend)
    app_state.get_current_team_or_none = make_get_current_team_or_none(state_backend)
    app_state.require_admin = make_require_admin(state_backend)
    app_state.require_cluster = make_require_cluster(state_backend)
    app_state.require_admin_or_cluster = make_require_admin_or_cluster(state_backend)

    # --- Resource+ownership dependency: lookup instance by id + guard team ---
    # Inlined (rather than hidden in a dedicated dependencies module) so the
    # auth wiring flows top-to-bottom in one file.
    async def _require_instance(
        instance_id: str,
        team: TeamState | None = Depends(app_state.get_current_team_or_none),
    ) -> InstanceState:
        inst = state_backend.get_instance(instance_id)
        if not inst:
            raise InstanceNotFoundError(instance_id)
        check_ownership(inst, team, "instance")
        if inst.instance_id != instance_id:
            inst = inst.model_copy(update={"instance_id": instance_id})
        return inst

    app_state.require_instance = _require_instance

    # Admin token (persisted in DB if set)
    env_key = config.admin_token.get_secret_value()
    db_key = state_backend.get_config("admin_key") or ""
    if env_key and env_key != db_key:
        state_backend.set_config("admin_key", env_key)
        log.info("Admin token stored in database")
    elif db_key:
        log.info("Admin token loaded from database")
    else:
        log.warning(
            "No admin token configured (LPB_ADMIN_TOKEN). "
            "Node management and admin endpoints are disabled."
        )
    # Cluster token (platform<->node machine auth) — persisted in DB if set
    env_cluster = config.node_token.get_secret_value()
    db_cluster = state_backend.get_config("cluster_key") or ""
    if env_cluster and env_cluster != db_cluster:
        state_backend.set_config("cluster_key", env_cluster)
        log.info("Cluster token stored in database")
    elif db_cluster:
        log.info("Cluster token loaded from database")
    else:
        log.warning(
            "No cluster token configured (LPB_NODE_TOKEN). "
            "Node registration and platform<->node calls will be rejected."
        )

    # --- Rate limiter (slowapi, per-app to avoid shared state across tests) --
    limiter = Limiter(key_func=get_remote_address)
    app_state.limiter = limiter

    # Background task factories
    _reaper = make_reaper_loop(app_state)
    _health_chk = make_health_check_loop(app_state)
    _reconciler = make_reconciler_loop(app_state)

    @asynccontextmanager
    async def lifespan(_app: FastAPI):
        sse_hub.set_loop(asyncio.get_running_loop())
        # Docker lifecycle is owned by nodes, not the platform. Orphan
        # cleanup and stop-all live in the node's lifespan.
        reaper = (
            asyncio.create_task(_reaper()) if isinstance(state_backend, InMemoryBackend) else None
        )
        reconciler = asyncio.create_task(_reconciler())
        health_checker = asyncio.create_task(_health_chk())
        yield
        for task in (health_checker, reconciler, reaper):
            if task:
                task.cancel()
                try:
                    await task
                except asyncio.CancelledError:
                    pass
        app_state.bg_executor.shutdown(wait=True, cancel_futures=False)

    app = FastAPI(
        title="LLM Pentest Benchmark",
        description="CTF evaluation platform for AI agents and humans.",
        version="1.0.0",
        lifespan=lifespan,
    )

    # Attach limiter to app.state for slowapi
    app.state.limiter = limiter

    # CORS — allow_credentials=False when allow_origins=["*"] (per CORS spec)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=False,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Domain exception -> HTTP status mapping — emits ErrorResponse envelopes
    # (``{code, detail, timestamp}``). Pre-refactor responses were bare
    # ``{"detail": ...}``; callers reading that field keep working.
    register_platform_error_handlers(
        app,
        {
            InstanceNotFoundError: 404,
            FlagNotFoundError: 404,
            ChallengeNotFoundError: 404,
            TeamNotFoundError: 404,
            CapacityExceededError: 503,
            RateLimitError: 429,
            ForbiddenError: 403,
            InstanceAlreadyRunningError: 409,
        },
    )

    # slowapi rate-limit exceeded handler
    app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

    # Include route modules
    for mod in _ROUTE_MODULES:
        app.include_router(mod.create_router(app_state), prefix="/api/v1")

    # Enable fastapi-pagination
    add_pagination(app)

    # Static files & SPA fallback
    _static = Path(__file__).resolve().parent / "static"
    if _static.exists() and (_static / "index.html").exists():
        _assets = _static / "assets"
        if _assets.exists():
            app.mount("/assets", StaticFiles(directory=str(_assets)), name="assets")

        @app.get("/{path:path}")
        def spa_fallback(path: str):
            f = _static / path
            return FileResponse(f if f.exists() and f.is_file() else _static / "index.html")
    else:
        log.warning(
            "Frontend static files not found. Web UI will not be available. "
            "To build: cd frontend && npm install && npm run build",
            path=str(_static),
        )

    return app


# Back-compat alias: legacy callers + uvicorn factory strings import
# ``create_app``. Tests, docs, and the docker-compose CMD use this name.
create_app = create_platform_app
