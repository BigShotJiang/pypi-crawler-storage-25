"""Background tasks: reaper, health checker, reconciler."""

from __future__ import annotations

import asyncio
import time

from lpb.core.constants import HEALTH_CHECK_INTERVAL, HEARTBEAT_TIMEOUT
from lpb.core.enums import InstanceStatus, PlatformEvent
from lpb.core.log import log
from lpb.server.app_state import AppState
from lpb.server.events import emit_event
from lpb.server.node_ops import get_node_client, stop_instance_on_node


def make_reaper_loop(app: AppState):
    """Create the TTL reaper coroutine (InMemoryBackend only)."""

    async def _reaper_loop():
        while True:
            await asyncio.sleep(HEALTH_CHECK_INTERVAL)
            expired = app.state_backend.pop_expired_instances()
            loop = asyncio.get_running_loop()
            for inst_data in expired:
                instance_id = inst_data.instance_id
                log.info("TTL expired, stopping instance", instance=instance_id)
                if app.traefik_router is not None:
                    app.traefik_router.remove(instance_id)
                try:
                    if inst_data.node_id:
                        node = app.state_backend.get_node(inst_data.node_id)
                        if node:
                            await loop.run_in_executor(
                                None, stop_instance_on_node, app, node, instance_id
                            )
                    emit_event(
                        app,
                        PlatformEvent.INSTANCE_STOPPED,
                        team_id=inst_data.team_id,
                        challenge_id=inst_data.challenge_id,
                        instance_id=instance_id,
                        reason="ttl_expired",
                    )
                except Exception as e:
                    log.error("Failed to stop expired instance", instance=instance_id, error=str(e))

    return _reaper_loop


def make_health_check_loop(app: AppState):
    """Create the health checker coroutine."""

    async def _health_check_loop():
        while True:
            await asyncio.sleep(HEALTH_CHECK_INTERVAL)
            loop = asyncio.get_running_loop()
            for inst_data in app.state_backend.list_instances():
                if inst_data.status != InstanceStatus.READY:
                    continue
                if not inst_data.node_id:
                    continue  # without a node there is no container to check
                instance_id = inst_data.instance_id
                node = app.state_backend.get_node(inst_data.node_id)
                if not node:
                    continue
                try:

                    def _chk(n=node, i=instance_id) -> bool:
                        with get_node_client(app, n) as nc:
                            return nc.check_health(i)

                    healthy = await loop.run_in_executor(None, _chk)
                except Exception as e:
                    log.warning("Health check error", instance=instance_id, error=str(e))
                    continue
                if not healthy:
                    inst = app.state_backend.get_instance(instance_id)
                    if inst and inst.status == InstanceStatus.READY:
                        inst = inst.model_copy(
                            update={
                                "status": InstanceStatus.ERROR,
                                "error": "Container(s) no longer running",
                            }
                        )
                        app.state_backend.put_instance(instance_id, inst)
                        log.warning("Instance marked unhealthy", instance=instance_id)
                        emit_event(
                            app,
                            PlatformEvent.INSTANCE_ERROR,
                            team_id=inst.team_id,
                            challenge_id=inst.challenge_id,
                            instance_id=instance_id,
                            error="Container health check failed",
                        )

    return _health_check_loop


def make_reconciler_loop(app: AppState):
    """Create the reconciler coroutine."""

    async def _reconciler_loop():
        while True:
            await asyncio.sleep(HEALTH_CHECK_INTERVAL)
            try:
                now = time.time()
                for node in app.state_backend.list_nodes():
                    lb = node.last_heartbeat_ts
                    was_healthy = node.healthy
                    is_healthy = bool(lb and (now - lb) < HEARTBEAT_TIMEOUT)
                    if was_healthy and not is_healthy:
                        node = node.model_copy(update={"healthy": False})
                        app.state_backend.put_node(node.node_id, node)
                        emit_event(
                            app,
                            PlatformEvent.NODE_UNHEALTHY,
                            node_id=node.node_id,
                            url=node.url,
                        )
                        log.warning("Node unhealthy (heartbeat timeout)", node=node.node_id)

                for inst in app.state_backend.list_instances():
                    node_id = inst.node_id
                    if not node_id:
                        continue
                    node = app.state_backend.get_node(node_id)
                    if node and not node.healthy:
                        if inst.status in (
                            InstanceStatus.STARTING,
                            InstanceStatus.READY,
                        ):
                            inst = inst.model_copy(
                                update={
                                    "status": InstanceStatus.ERROR,
                                    "error": f"Node {node_id} unhealthy",
                                }
                            )
                            app.state_backend.put_instance(inst.instance_id, inst)
                            emit_event(
                                app,
                                PlatformEvent.INSTANCE_ERROR,
                                team_id=inst.team_id,
                                challenge_id=inst.challenge_id,
                                instance_id=inst.instance_id,
                                error=f"Node {node_id} unhealthy",
                            )
                            log.warning(
                                "Instance marked error (node unhealthy)",
                                instance=inst.instance_id,
                                node=node_id,
                            )
            except Exception as e:
                log.error("Reconciler error", error=str(e))

    return _reconciler_loop
