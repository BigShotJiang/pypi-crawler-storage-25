"""Traefik dynamic-router for http_domain challenges.

When a challenge declares ``expose_type: http_domain``, the platform writes
a per-instance routing rule into a shared YAML file that Traefik's file
provider watches. On instance stop, the rule is removed.

This is *opt-in* — if ``LPB_TRAEFIK_RULES_PATH`` is empty the router is a
no-op. Compose setups that want it point Traefik at the file via
``--providers.file.filename=<path>``.

The rule shape (minimal, HTTP only):

    http:
      routers:
        inst-<short>:
          rule: "Host(`inst-<short>.<base_domain>`)"
          entrypoints: [web]
          service: inst-<short>
      services:
        inst-<short>:
          loadBalancer:
            servers:
              - url: "http://<node_public_host>:<port>"

Concurrency: file writes are guarded by a process-local lock. We read-
modify-write the full file each time; at CTF scales (hundreds of
simultaneous instances) this is cheap and avoids the complexity of
dedicated per-rule fragments.
"""

from __future__ import annotations

import threading
from pathlib import Path
from typing import Any

import yaml

from lpb.core.exceptions import TraefikRouteError
from lpb.core.log import log


class TraefikRouter:
    """File-provider backed Traefik dynamic-route writer.

    When ``rules_path`` is unset (empty string or None) every operation is
    a silent no-op — feature stays behind a deploy-time flag.
    """

    def __init__(self, rules_path: str | Path, *, base_domain: str = "") -> None:
        # Accept only real str/Path; MagicMock sneaking in from test fixtures
        # would otherwise trigger mkdirs against the mock's string repr.
        if isinstance(rules_path, (str, Path)) and rules_path:
            self._path = Path(rules_path)
        else:
            self._path = None
        self._base_domain = str(base_domain or "").strip(".")
        self._lock = threading.Lock()
        if self._path:
            self._path.parent.mkdir(parents=True, exist_ok=True)
            if not self._path.exists():
                self._write({})

    @property
    def enabled(self) -> bool:
        return self._path is not None and bool(self._base_domain)

    # -- rule shape helpers --------------------------------------------------

    @staticmethod
    def _router_name(instance_id: str) -> str:
        return f"inst-{instance_id[:12]}"

    def public_url(self, instance_id: str) -> str:
        if not self.enabled:
            return ""
        return f"http://{self._router_name(instance_id)}.{self._base_domain}"

    # -- read/write ---------------------------------------------------------

    def _read(self) -> dict[str, Any]:
        try:
            raw = self._path.read_text()
        except FileNotFoundError:
            return {}
        except OSError as exc:
            # Other disk-layer failures (permission, EIO, stale mount) are
            # unusual enough that we want them loud and typed — operators
            # reading the log need to know Traefik routing is broken.
            log.error("traefik rule read failed", path=str(self._path), error=str(exc))
            raise TraefikRouteError(f"read failed: {exc}") from exc
        return yaml.safe_load(raw) or {}

    def _write(self, doc: dict[str, Any]) -> None:
        try:
            self._path.write_text(yaml.safe_dump(doc, sort_keys=True))
        except OSError as exc:
            log.error("traefik rule write failed", path=str(self._path), error=str(exc))
            raise TraefikRouteError(f"write failed: {exc}") from exc

    # -- public API ---------------------------------------------------------

    def upsert(self, instance_id: str, target_url: str) -> str:
        """Write a route for ``instance_id`` pointing at ``target_url``.

        Returns the instance's public URL (or "" if disabled).
        """
        if not self.enabled:
            return ""
        name = self._router_name(instance_id)
        with self._lock:
            doc = self._read()
            http = doc.setdefault("http", {})
            routers = http.setdefault("routers", {})
            services = http.setdefault("services", {})
            routers[name] = {
                "rule": f"Host(`{name}.{self._base_domain}`)",
                "entrypoints": ["web"],
                "service": name,
            }
            services[name] = {
                "loadBalancer": {
                    "servers": [{"url": target_url.rstrip("/")}],
                }
            }
            self._write(doc)
        log.info("traefik rule upserted", router=name, target=target_url)
        return self.public_url(instance_id)

    def remove(self, instance_id: str) -> None:
        """Remove the rule for *instance_id*. Best-effort: a write failure
        leaves a stale rule pointing at a dead node (Traefik will just 502),
        which is strictly better than failing the instance-stop path. The
        error is logged but not raised."""
        if not self.enabled:
            return
        name = self._router_name(instance_id)
        try:
            with self._lock:
                doc = self._read()
                http = doc.get("http") or {}
                for section in ("routers", "services"):
                    table = http.get(section) or {}
                    if name in table:
                        table.pop(name)
                self._write(doc)
        except TraefikRouteError as exc:
            log.warning(
                "traefik rule remove failed, stale entry left behind",
                router=name,
                error=str(exc),
            )
            return
        log.info("traefik rule removed", router=name)
