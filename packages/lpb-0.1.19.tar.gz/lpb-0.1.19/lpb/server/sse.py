"""Server-Sent Events hub for broadcasting platform events to connected clients."""

from __future__ import annotations

import asyncio
from uuid import uuid4


class SSEHub:
    """In-process pub/sub hub for SSE connections.

    Each connected client gets an asyncio.Queue. When ``broadcast()`` is called
    (potentially from a non-asyncio thread), messages are enqueued to all
    matching clients via ``loop.call_soon_threadsafe``.
    """

    def __init__(self) -> None:
        # client_id -> (queue, team_id)
        self._clients: dict[str, tuple[asyncio.Queue[dict], str]] = {}
        self._loop: asyncio.AbstractEventLoop | None = None

    def set_loop(self, loop: asyncio.AbstractEventLoop) -> None:
        """Capture the running event loop (call once during lifespan startup)."""
        self._loop = loop

    def connect(self, team_id: str = "") -> tuple[str, asyncio.Queue[dict]]:
        """Register a new SSE client. Returns (client_id, queue)."""
        client_id = uuid4().hex
        q: asyncio.Queue[dict] = asyncio.Queue(maxsize=64)
        self._clients[client_id] = (q, team_id)
        return client_id, q

    def disconnect(self, client_id: str) -> None:
        """Remove a client on disconnect."""
        self._clients.pop(client_id, None)

    def broadcast(self, event: str, *, team_id: str = "", data: dict | None = None) -> None:
        """Send *event* to all matching clients. Thread-safe."""
        msg = {"event": event, **(data or {})}
        for cid, (q, client_team) in list(self._clients.items()):
            # Team-scoped client only sees its own team's events (or global)
            if client_team and team_id and client_team != team_id:
                continue
            if self._loop and self._loop.is_running():
                self._loop.call_soon_threadsafe(self._put_nowait, q, cid, msg)
            else:
                self._put_nowait(q, cid, msg)

    def _put_nowait(self, q: asyncio.Queue[dict], cid: str, msg: dict) -> None:
        try:
            q.put_nowait(msg)
        except asyncio.QueueFull:
            # Drop oldest message for slow clients
            try:
                q.get_nowait()
            except asyncio.QueueEmpty:
                pass
            try:
                q.put_nowait(msg)
            except asyncio.QueueFull:
                pass
