"""Activity event emission: record in state backend + broadcast to SSE clients."""

from __future__ import annotations

from lpb.core.activity import ActivityDetail
from lpb.core.state.models import ActivityState
from lpb.server.app_state import AppState, now_iso

__all__ = ["emit_event"]


def emit_event(
    app: AppState,
    event: str,
    *,
    team_id: str = "",
    challenge_id: str = "",
    team_name: str = "",
    **detail_kwargs: object,
) -> None:
    """Record an activity event and broadcast to SSE clients.

    ``**detail_kwargs`` must use field names declared on
    :class:`lpb.core.activity.ActivityDetail`; unknown keys are dropped on
    validation. The SSE payload mirrors what lands on ``ActivityState``.
    """
    # Pydantic enum serialization: coerce PlatformEvent → its string value.
    event = event.value if hasattr(event, "value") else event
    detail = ActivityDetail.model_validate(detail_kwargs)
    app.state_backend.add_activity(
        ActivityState(
            timestamp=now_iso(),
            event=event,
            team_id=team_id,
            team_name=team_name,
            challenge_id=challenge_id,
            detail=detail,
        )
    )
    app.sse_hub.broadcast(
        event,
        team_id=team_id,
        data={
            "challenge_id": challenge_id,
            **detail.model_dump(exclude_none=True),
        },
    )
