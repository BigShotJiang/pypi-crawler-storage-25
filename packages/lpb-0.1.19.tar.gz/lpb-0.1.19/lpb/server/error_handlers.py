"""Unified exception-to-response mapping for platform domain errors.

Emits the :class:`lpb.server.models.ErrorResponse` envelope — pre-refactor
the handlers returned bare ``{"detail": ...}`` dicts. ``detail`` is
preserved so existing SDK / CLI / frontend code that reads
``data.detail`` keeps working; ``code`` is a snake-case identifier
derived from the exception class (e.g. ``InstanceNotFoundError`` →
``instance_not_found``) and ``timestamp`` is server-side UTC ISO 8601.
"""

from __future__ import annotations

import re

from fastapi import FastAPI
from fastapi.responses import JSONResponse

from lpb.core.exceptions import PlatformError
from lpb.server.app_state import now_iso
from lpb.server.models import ErrorResponse

__all__ = ["exception_code", "register_platform_error_handlers"]

# CamelCase → snake_case: insert "_" before each uppercase letter that
# follows a lowercase letter or digit. Strips a trailing ``_error`` so
# ``InstanceNotFoundError`` becomes ``instance_not_found`` (shorter and
# matches how client code tends to write these codes).
_CAMEL_BOUNDARY = re.compile(r"(?<=[a-z0-9])(?=[A-Z])")


def exception_code(exc: BaseException) -> str:
    """Derive the ``ErrorResponse.code`` for *exc*.

    Example: ``InstanceNotFoundError`` → ``"instance_not_found"``.
    """
    name = exc.__class__.__name__
    snake = _CAMEL_BOUNDARY.sub("_", name).lower()
    return snake.removesuffix("_error")


def _handler_for(status: int):
    async def _handle(_request, exc):
        body = ErrorResponse(
            code=exception_code(exc),
            detail=str(exc),
            timestamp=now_iso(),
        )
        return JSONResponse(status_code=status, content=body.model_dump())

    return _handle


def register_platform_error_handlers(app: FastAPI, mapping: dict[type[PlatformError], int]) -> None:
    """Register an ``ErrorResponse``-emitting handler for each ``PlatformError``
    subclass in *mapping*.
    """
    for exc_cls, status in mapping.items():
        app.add_exception_handler(exc_cls, _handler_for(status))
