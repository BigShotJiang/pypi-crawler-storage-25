"""Shared application state container for the platform server.

``AppState`` bundles long-lived server dependencies (state backend, SSE hub,
challenge metadata reader, pre-built FastAPI auth dependencies, etc.) so
route modules can accept a single argument rather than wiring each
dependency individually.
"""

from __future__ import annotations

import threading
from collections.abc import Awaitable, Callable
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import TYPE_CHECKING

from lpb.core.challenge import ChallengeManager
from lpb.core.config import LpbConfig
from lpb.core.state import StateBackend
from lpb.core.state.models import InstanceState, TeamState
from lpb.server.sse import SSEHub

if TYPE_CHECKING:  # avoid import cycles at runtime for dataclass annotations
    from slowapi import Limiter

    from lpb.server.traefik_router import TraefikRouter

__all__ = [
    "AppState",
    "AdminAuthDep",
    "InstanceDep",
    "OptionalTeamAuthDep",
    "TeamAuthDep",
    "now_iso",
]

# Type aliases for FastAPI dependency callables attached to AppState.
# FastAPI invokes these with kwargs it resolves from ``Depends()``; the
# signature is effectively variadic from the caller's perspective, so
# ``Callable[..., ...]`` is the right level of precision.
TeamAuthDep = Callable[..., Awaitable[TeamState]]
OptionalTeamAuthDep = Callable[..., Awaitable[TeamState | None]]
AdminAuthDep = Callable[..., Awaitable[None]]
InstanceDep = Callable[..., Awaitable[InstanceState]]


@dataclass
class AppState:
    """Immutable container for shared application dependencies."""

    config: LpbConfig
    state_backend: StateBackend
    # ``spec_reader`` on the platform side is just a metadata reader — it
    # exposes ``iter_specs`` over ``benchmarks/``. The full ChallengeManager
    # class is reused for convenience, but its provider registry is never
    # triggered on the platform (no Docker, no ports). Container lifecycle
    # goes to worker nodes via NodeClient.
    spec_reader: ChallengeManager
    sse_hub: SSEHub
    host: str
    max_instances: int
    instance_start_lock: threading.Lock = field(default_factory=threading.Lock)
    bg_executor: ThreadPoolExecutor = field(
        default_factory=lambda: ThreadPoolExecutor(max_workers=8, thread_name_prefix="lpb-bg")
    )
    # Dynamic-route writer for http_domain challenges. When the rules-path
    # setting is empty, this is a no-op instance.
    traefik_router: "TraefikRouter | None" = field(default=None, repr=False)

    # Pre-built auth dependencies (created once in app.py, reused by all route modules)
    get_current_team: TeamAuthDep | None = field(default=None, repr=False)
    get_current_team_or_none: OptionalTeamAuthDep | None = field(default=None, repr=False)
    require_admin: AdminAuthDep | None = field(default=None, repr=False)
    require_cluster: AdminAuthDep | None = field(default=None, repr=False)
    require_admin_or_cluster: AdminAuthDep | None = field(default=None, repr=False)

    # Pre-built resource+ownership dependencies
    require_instance: InstanceDep | None = field(default=None, repr=False)

    # Rate limiter (created per-app to avoid shared state across tests)
    limiter: "Limiter | None" = field(default=None, repr=False)

    # Discarded on purpose: ``Any`` for fields above would have hidden
    # signature drift between routes and the dependency factories that
    # build these callables. With concrete aliases, IDEs flag mismatches
    # (e.g. passing ``get_current_team`` where ``require_admin`` is
    # expected).


def now_iso() -> str:
    """Return current UTC time as ISO 8601 string."""
    return datetime.now(timezone.utc).isoformat()
