"""Background instance lifecycle — platform-side polling after a node-side start.

Extracted from ``routes/instances.py`` so the route layer stays thin (route
declaration + validation) while the multi-step "dispatch, poll, reconcile,
emit" flow lives in one focused module.

Invariant expected by :func:`start_instance_async`: the caller must have
already written an :class:`InstanceState` with ``status=STARTING`` and a
non-empty ``node_id``. All other inputs (challenge, team, flag, ttl, spec)
are read back from state.
"""

from __future__ import annotations

import time

from lpb.core.constants import REMOTE_INSTANCE_POLL_MAX
from lpb.core.enums import ExposeType, InstanceStatus, PlatformEvent
from lpb.core.log import log
from lpb.core.target import AttackSurface, first_http_endpoint_url
from lpb.server.app_state import AppState
from lpb.server.events import emit_event
from lpb.server.node_ops import get_node_client


def start_instance_async(
    app: AppState,
    instance_id: str,
    *,
    proxy_output_dir: str | None = None,
) -> None:
    """Dispatch start to the assigned node and poll until READY / ERROR.

    Run on ``app.bg_executor``. Catches every exception and reconciles state
    so the HTTP client always sees an eventually-consistent record.
    """
    inst = app.state_backend.get_instance(instance_id)
    if inst is None or not inst.node_id:
        log.error("start_instance_async: missing instance or node", instance=instance_id)
        return
    node = app.state_backend.get_node(inst.node_id)
    if node is None:
        _reconcile_error(app, inst, RuntimeError(f"node {inst.node_id} gone"))
        return

    try:
        _dispatch_and_poll(app, inst, node, proxy_output_dir=proxy_output_dir)
    except Exception as e:
        log.error("Instance start failed", instance=instance_id, error=str(e))
        _reconcile_error(app, inst, e)


def _dispatch_and_poll(app: AppState, inst, node, *, proxy_output_dir: str | None) -> None:
    instance_id = inst.instance_id
    with get_node_client(app, node) as nc:
        nc.start_instance(
            challenge_id=inst.challenge_id,
            instance_id=instance_id,
            ttl=inst.ttl,
            flag=inst.flag,
            proxy_output_dir=proxy_output_dir,
        )
        for _ in range(REMOTE_INSTANCE_POLL_MAX):
            sd = nc.get_status(instance_id)
            status = sd.get("status")
            if status == InstanceStatus.READY:
                raw = sd.get("attack_surface") or None
                surface = AttackSurface.model_validate(raw) if raw else None
                _reconcile_ready(app, inst, node, surface)
                return
            if status == InstanceStatus.ERROR:
                raise RuntimeError(sd.get("error", "unknown"))
            time.sleep(2)
    raise TimeoutError("Remote instance not ready after poll timeout")


def _reconcile_ready(app: AppState, inst, node, surface: AttackSurface | None) -> None:
    """Flip state to READY, wire Traefik if the challenge opts in, and emit event."""
    instance_id = inst.instance_id
    expose_type = (inst.spec or {}).get("expose_type", ExposeType.TCP_PORT)
    if (
        surface
        and app.traefik_router is not None
        and expose_type == ExposeType.HTTP_DOMAIN
        and app.traefik_router.enabled
    ):
        target = first_http_endpoint_url(surface)
        if target:
            app.traefik_router.upsert(instance_id, target)

    current = app.state_backend.get_instance(instance_id)
    if current:
        updated = current.model_copy(update={"status": InstanceStatus.READY, "surface": surface})
        app.state_backend.put_instance(instance_id, updated, ttl=current.ttl)

    emit_event(
        app,
        PlatformEvent.INSTANCE_READY,
        team_id=inst.team_id,
        challenge_id=inst.challenge_id,
        instance_id=instance_id,
        node_id=node.node_id,
    )


def _reconcile_error(app: AppState, inst, exc: Exception) -> None:
    """Persist ERROR status and emit event. Tolerates disappearing instance rows."""
    instance_id = inst.instance_id
    current = app.state_backend.get_instance(instance_id)
    if current:
        updated = current.model_copy(update={"status": InstanceStatus.ERROR, "error": str(exc)})
        app.state_backend.put_instance(instance_id, updated, ttl=current.ttl)
    emit_event(
        app,
        PlatformEvent.INSTANCE_ERROR,
        team_id=inst.team_id,
        challenge_id=inst.challenge_id,
        instance_id=instance_id,
        error=str(exc),
    )
