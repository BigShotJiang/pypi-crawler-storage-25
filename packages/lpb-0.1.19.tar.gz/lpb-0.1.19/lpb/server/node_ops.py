"""Node-side RPC helpers used by route modules.

Wraps :class:`lpb.sdk.node_client.NodeClient` with the cluster token
pulled from the state backend, and exposes high-level convenience calls
(``stop_instance_on_node``, ``stop_all_instances_on_node``) so route
handlers don't repeat the context-manager boilerplate.
"""

from __future__ import annotations

from lpb.core.state.models import NodeState
from lpb.sdk.node_client import NodeClient
from lpb.server.app_state import AppState

__all__ = [
    "get_node_client",
    "stop_instance_on_node",
    "stop_all_instances_on_node",
]


def get_node_client(app: AppState, node: NodeState) -> NodeClient:
    """Build a ``NodeClient`` authenticated with the cluster token from config."""
    token = app.state_backend.get_config("cluster_key") or ""
    return NodeClient(node.url, token)


def stop_instance_on_node(app: AppState, node: NodeState, instance_id: str) -> None:
    """Synchronous helper for ``run_in_executor``: stop a single instance on *node*."""
    with get_node_client(app, node) as nc:
        nc.stop_instance(instance_id)


def stop_all_instances_on_node(app: AppState, node: NodeState) -> None:
    """Synchronous helper for ``run_in_executor``: stop all instances on *node*."""
    with get_node_client(app, node) as nc:
        nc.stop_all()
