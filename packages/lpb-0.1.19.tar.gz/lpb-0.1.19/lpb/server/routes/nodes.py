"""Multi-node cluster management endpoints."""

from __future__ import annotations

import time

from fastapi import APIRouter, Depends, HTTPException
from fastapi_pagination import paginate as list_paginate

from lpb.core.constants import HEARTBEAT_TIMEOUT
from lpb.core.enums import PlatformEvent
from lpb.core.log import log
from lpb.core.state.models import NodeState
from lpb.server.app_state import AppState, now_iso
from lpb.server.events import emit_event
from lpb.server.models import (
    BigLimitOffsetPage,
    NodeInfo,
    NodeRegister,
)


def create_router(app: AppState) -> APIRouter:
    router = APIRouter()

    @router.post(
        "/nodes/register",
        response_model=NodeInfo,
        dependencies=[Depends(app.require_admin_or_cluster)],
    )
    def register_node(req: NodeRegister):
        """Register a worker node. Accepts admin token (human bootstrap) or
        cluster token (node process itself)."""
        node_id = req.url.rstrip("/").split("//")[-1].replace(":", "_").replace("/", "_")
        now = now_iso()
        data = NodeState(
            node_id=node_id,
            url=req.url.rstrip("/"),
            capacity=req.capacity,
            running=0,
            healthy=True,
            last_heartbeat=now,
            last_heartbeat_ts=time.time(),
            labels=req.labels,
        )
        app.state_backend.put_node(node_id, data)
        emit_event(app, PlatformEvent.NODE_REGISTERED, node_id=node_id, url=req.url)
        log.info("Node registered", node_id=node_id, url=req.url, capacity=req.capacity)
        return NodeInfo(**data.model_dump())

    @router.post("/nodes/heartbeat", dependencies=[Depends(app.require_admin_or_cluster)])
    def node_heartbeat(node_id: str, running: int = 0, capacity: int = 50):
        """Heartbeat from a worker node. Updates running count + timestamp."""
        node = app.state_backend.get_node(node_id)
        if not node:
            raise HTTPException(404, "Node not registered")
        node = node.model_copy(
            update={
                "running": running,
                "capacity": capacity,
                "healthy": True,
                "last_heartbeat": now_iso(),
                "last_heartbeat_ts": time.time(),
            }
        )
        app.state_backend.put_node(node_id, node)
        return {"status": "ok"}

    @router.get("/nodes", response_model=BigLimitOffsetPage[NodeInfo])
    def list_nodes():
        """List all registered worker nodes."""
        now = time.time()
        result = []
        for n in app.state_backend.list_nodes():
            lb = n.last_heartbeat_ts
            healthy = bool(lb and (now - lb) < HEARTBEAT_TIMEOUT)
            n = n.model_copy(update={"healthy": healthy})
            result.append(NodeInfo(**n.model_dump()))
        return list_paginate(result)

    @router.delete("/nodes/{node_id}", dependencies=[Depends(app.require_admin_or_cluster)])
    def remove_node(node_id: str):
        app.state_backend.remove_node(node_id)
        emit_event(app, PlatformEvent.NODE_REMOVED, node_id=node_id)
        return {"status": "removed", "node_id": node_id}

    return router
