"""Activity log endpoint."""

from __future__ import annotations

from fastapi import APIRouter, Depends

from lpb.core.state.models import TeamState
from lpb.server.app_state import AppState
from lpb.server.auth import get_team_id
from lpb.server.models import Activity, BigLimitOffsetPage


def create_router(app: AppState) -> APIRouter:
    router = APIRouter()

    @router.get("/activities", response_model=BigLimitOffsetPage[Activity])
    def list_activities(
        team: TeamState | None = Depends(app.get_current_team_or_none),
        team_id: str = "",
        challenge_id: str = "",
        event: str = "",
        offset: int = 0,
        limit: int = 100,
    ):
        """Get platform activity log (most recent first).

        Authenticated teams see only their own activities unless a team_id
        filter is explicitly provided.
        """
        effective_team_id = team_id or get_team_id(team)
        total = app.state_backend.count_activities(
            team_id=effective_team_id, challenge_id=challenge_id, event=event
        )
        rows = app.state_backend.list_activities(
            team_id=effective_team_id,
            challenge_id=challenge_id,
            event=event,
            offset=offset,
            limit=limit,
        )
        items = [Activity(**a.model_dump()) for a in rows]
        return {"items": items, "total": total, "offset": offset, "limit": limit}

    return router
