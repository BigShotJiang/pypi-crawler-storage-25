"""Cluster info endpoint — feeds the onboarding CLI (``lpb server invite``).

Returns the pieces an operator needs to stand up a new node container:
platform URL, the current cluster token, and the recommended node image.
Admin-only: this response contains the cluster token in plaintext.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, Request

from lpb.server.app_state import AppState
from lpb.server.models import ClusterInfo


def create_router(app: AppState) -> APIRouter:
    router = APIRouter()

    @router.get(
        "/cluster-info",
        response_model=ClusterInfo,
        dependencies=[Depends(app.require_admin)],
    )
    def cluster_info(request: Request) -> ClusterInfo:
        return ClusterInfo(
            platform_url=str(request.base_url).rstrip("/"),
            cluster_token=app.state_backend.get_config("cluster_key") or "",
            node_image=app.config.node_image,
        )

    return router
