"""Flag submission endpoints."""

from __future__ import annotations

import time
import uuid

from fastapi import APIRouter, Depends, Request
from fastapi_pagination import paginate as list_paginate

from lpb.core.constants import SUBMISSION_RATE_LIMIT, SUBMISSION_RATE_WINDOW
from lpb.core.enums import PlatformEvent
from lpb.core.exceptions import InstanceNotFoundError
from lpb.core.flag import verify_flag
from lpb.core.log import log
from lpb.core.state.models import SolveState, SubmissionState, TeamState
from lpb.server.app_state import AppState, now_iso
from lpb.server.events import emit_event
from lpb.server.models import (
    BigLimitOffsetPage,
    SubmissionCreate,
    SubmissionResponse,
)
from lpb.server.node_ops import get_node_client

# Rate limit string for slowapi (e.g. "10/minute")
_RATE_LIMIT = f"{SUBMISSION_RATE_LIMIT}/{int(SUBMISSION_RATE_WINDOW)} seconds"


def create_router(app: AppState) -> APIRouter:
    router = APIRouter()

    @router.post("/submissions", response_model=SubmissionResponse)
    @app.limiter.limit(_RATE_LIMIT)
    def submit_flag(
        request: Request,
        req: SubmissionCreate,
        team: TeamState = Depends(app.get_current_team),
    ):
        team_id = team.team_id
        challenge_id = req.challenge_id

        # Look up the team's instance for this challenge
        inst_data = app.state_backend.get_instance_by_team_challenge(team_id, challenge_id)
        if not inst_data:
            raise InstanceNotFoundError(challenge_id)
        instance_id = inst_data.instance_id
        correct = verify_flag(app.state_backend, instance_id, req.flag)

        # Compute solve time (from instance start to now)
        solve_time_s = 0.0
        if correct:
            inst = app.state_backend.get_instance(instance_id)
            started_at = inst.started_at if inst else 0
            if started_at:
                solve_time_s = round(time.time() - float(started_at), 1)

        # Record submission
        sub_id = str(uuid.uuid4())
        ts = now_iso()
        app.state_backend.add_submission(
            SubmissionState(
                submission_id=sub_id,
                team_id=team_id,
                challenge_id=challenge_id,
                claimed_flag=req.flag,
                correct=correct,
                submitted_at=ts,
                solve_time_s=solve_time_s,
            )
        )

        # Record solve if correct and first time for this team
        existing = None
        if correct:
            existing = app.state_backend.get_solve(team_id, challenge_id)
            if not existing:
                attempts = len(
                    app.state_backend.list_submissions(team_id=team_id, challenge_id=challenge_id)
                )
                app.state_backend.add_solve(
                    team_id,
                    challenge_id,
                    SolveState(
                        team_id=team_id,
                        challenge_id=challenge_id,
                        solved_at=ts,
                        solve_time_s=solve_time_s,
                        attempts=attempts,
                    ),
                )
                log.info(
                    "Challenge solved",
                    team=team_id,
                    challenge=challenge_id,
                    solve_time=f"{solve_time_s}s",
                )

        emit_event(
            app,
            PlatformEvent.FLAG_CORRECT if correct else PlatformEvent.FLAG_WRONG,
            team_id=team_id,
            team_name=team.name,
            challenge_id=challenge_id,
            instance_id=instance_id,
            solve_time_s=solve_time_s if correct else 0,
        )

        # Auto-destroy instance after first successful solve
        if correct and not existing:
            node_id = inst_data.node_id

            if node_id:

                def _auto_stop():
                    try:
                        app.state_backend.remove_instance(instance_id)
                        node = app.state_backend.get_node(node_id)
                        if node:
                            with get_node_client(app, node) as nc:
                                nc.stop_instance(instance_id)
                        log.info(
                            "Auto-stopped instance after solve",
                            instance=instance_id,
                            challenge=challenge_id,
                        )
                        emit_event(
                            app,
                            PlatformEvent.INSTANCE_STOPPED,
                            team_id=team_id,
                            challenge_id=challenge_id,
                            instance_id=instance_id,
                            reason="auto_stop_after_solve",
                        )
                    except Exception as e:
                        log.error(
                            "Auto-stop failed after solve", instance=instance_id, error=str(e)
                        )

                app.bg_executor.submit(_auto_stop)

        return SubmissionResponse(submission_id=sub_id, correct=correct, solve_time_s=solve_time_s)

    @router.get("/submissions", response_model=BigLimitOffsetPage[SubmissionState])
    def list_my_submissions(
        team: TeamState = Depends(app.get_current_team),
        challenge_id: str = "",
    ):
        """List current team's submissions."""
        all_subs = app.state_backend.list_submissions(
            team_id=team.team_id, challenge_id=challenge_id
        )
        return list_paginate(all_subs)

    return router
