"""Team management endpoints."""

from __future__ import annotations

import secrets
import uuid

from fastapi import APIRouter, Depends
from fastapi_pagination import paginate as list_paginate

from lpb.core.enums import PlatformEvent
from lpb.core.exceptions import TeamNotFoundError
from lpb.core.log import log
from lpb.core.state.models import TeamState
from lpb.server.app_state import AppState, now_iso
from lpb.server.auth import hash_token
from lpb.server.events import emit_event
from lpb.server.models import (
    BigLimitOffsetPage,
    TeamCreate,
    TeamInfo,
    TeamResponse,
)


def _team_info(app: AppState, t: TeamState) -> TeamInfo:
    tid = t.team_id
    return TeamInfo(
        team_id=tid,
        name=t.name,
        agent=t.agent,
        description=t.description,
        created_at=t.created_at,
        solves=len(app.state_backend.list_solves(tid)),
        attempts=len(app.state_backend.list_submissions(team_id=tid)),
    )


def create_router(app: AppState) -> APIRouter:
    router = APIRouter()

    @router.post("/teams", response_model=TeamResponse)
    def create_team(req: TeamCreate):
        team_id = str(uuid.uuid4())
        token = f"pt_{secrets.token_urlsafe(32)}"
        token_hash = hash_token(token)
        now = now_iso()
        data = TeamState(
            team_id=team_id,
            name=req.name,
            agent=req.agent,
            description=req.description,
            token=token_hash,  # store hash, not plaintext
            created_at=now,
        )
        app.state_backend.put_team(team_id, data)
        log.info("Team registered", team_id=team_id, name=req.name)
        emit_event(
            app,
            PlatformEvent.TEAM_REGISTERED,
            team_id=team_id,
            team_name=req.name,
            agent=req.agent,
        )
        # Return plaintext token ONCE (never stored)
        return TeamResponse(**{**data.model_dump(), "token": token})

    @router.get("/teams", response_model=BigLimitOffsetPage[TeamInfo])
    def list_teams():
        all_teams = [_team_info(app, t) for t in app.state_backend.list_teams()]
        return list_paginate(all_teams)

    @router.get("/teams/{team_id}", response_model=TeamInfo)
    def get_team(team_id: str):
        t = app.state_backend.get_team(team_id)
        if not t:
            raise TeamNotFoundError(team_id)
        return _team_info(app, t)

    @router.get("/me", response_model=TeamInfo)
    def get_me(team: TeamState = Depends(app.get_current_team)):
        """Get current team info (requires team auth)."""
        return _team_info(app, team)

    return router
