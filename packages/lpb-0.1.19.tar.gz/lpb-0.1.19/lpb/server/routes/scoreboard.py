"""Scoreboard endpoints."""

from __future__ import annotations

from fastapi import APIRouter, Request
from fastapi_pagination import paginate as list_paginate

from lpb.core.constants import SCOREBOARD_RATE_LIMIT
from lpb.server.app_state import AppState
from lpb.server.models import (
    BigLimitOffsetPage,
    ChallengeStats,
    ScoreboardEntry,
)


def create_router(app: AppState) -> APIRouter:
    router = APIRouter()

    @router.get("/scoreboard", response_model=BigLimitOffsetPage[ScoreboardEntry])
    @app.limiter.limit(SCOREBOARD_RATE_LIMIT)
    def get_scoreboard(request: Request, category: str = ""):
        teams = app.state_backend.list_teams()
        entries = []
        for t in teams:
            tid = t.team_id
            solves = app.state_backend.list_solves(tid)
            if category:
                # Filter solves by challenge category
                valid_ids = {spec.id for spec in app.spec_reader.iter_specs(category=category)}
                solves = [s for s in solves if s.challenge_id in valid_ids]
            if not solves:
                entries.append(
                    ScoreboardEntry(
                        team_id=tid,
                        team_name=t.name,
                        agent=t.agent,
                        solved=0,
                        attempts=0,
                    )
                )
                continue
            last = max(s.solved_at for s in solves)
            all_subs = app.state_backend.list_submissions(team_id=tid)
            if category:
                all_subs = [s for s in all_subs if s.challenge_id in valid_ids]
            attempts = len(all_subs)
            entries.append(
                ScoreboardEntry(
                    team_id=tid,
                    team_name=t.name,
                    agent=t.agent,
                    solved=len(solves),
                    attempts=attempts,
                    last_solve_at=last,
                )
            )
        # Sort: most solves first, then earliest last_solve
        entries.sort(key=lambda e: (-e.solved, e.last_solve_at))
        for i, e in enumerate(entries):
            e.rank = i + 1
        return list_paginate(entries)

    @router.get("/scoreboard/challenges", response_model=BigLimitOffsetPage[ChallengeStats])
    @app.limiter.limit(SCOREBOARD_RATE_LIMIT)
    def get_challenge_stats(request: Request):
        result = []
        for spec in app.spec_reader.iter_specs():
            cid = spec.id
            solves = [s for s in app.state_backend.list_solves() if s.challenge_id == cid]
            all_subs = app.state_backend.list_submissions(challenge_id=cid)
            correct_subs = [s for s in all_subs if s.correct]
            success_rate = len(correct_subs) / len(all_subs) * 100 if all_subs else 0
            result.append(
                ChallengeStats(
                    challenge_id=cid,
                    name=spec.name,
                    category=spec.category,
                    difficulty=spec.difficulty,
                    solves_count=len(solves),
                    total_attempts=len(all_subs),
                    success_rate=round(success_rate, 1),
                )
            )
        return list_paginate(result)

    return router
