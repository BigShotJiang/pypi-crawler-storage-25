"""SSE event stream endpoint."""

from __future__ import annotations

import asyncio

from fastapi import APIRouter
from starlette.responses import StreamingResponse

from lpb.core.constants import SSE_KEEPALIVE_INTERVAL
from lpb.server.app_state import AppState
from lpb.server.auth import hash_token


def create_router(app: AppState) -> APIRouter:
    router = APIRouter()

    @router.get("/events")
    async def stream_events(token: str = ""):
        """SSE stream of platform events, filtered by team."""
        import json as _json

        team_id = ""
        if token:
            team = app.state_backend.get_team_by_token(hash_token(token))
            if team:
                team_id = team.team_id

        client_id, queue = app.sse_hub.connect(team_id=team_id)

        async def generate():
            try:
                yield ": connected\n\n"
                while True:
                    try:
                        msg = await asyncio.wait_for(queue.get(), timeout=SSE_KEEPALIVE_INTERVAL)
                        event_type = msg.pop("event", "message")
                        yield f"event: {event_type}\ndata: {_json.dumps(msg)}\n\n"
                    except asyncio.TimeoutError:
                        yield ": keepalive\n\n"
            except asyncio.CancelledError:
                pass
            finally:
                app.sse_hub.disconnect(client_id)

        return StreamingResponse(
            generate(),
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "X-Accel-Buffering": "no",
                "Connection": "keep-alive",
            },
        )

    return router
