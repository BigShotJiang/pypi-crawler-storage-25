"""Instance lifecycle endpoints."""

from __future__ import annotations

import asyncio
import uuid

from fastapi import APIRouter, Depends
from fastapi.responses import JSONResponse
from fastapi_pagination import paginate as list_paginate

from lpb.core.constants import MAX_INSTANCES_PER_TEAM
from lpb.core.enums import ExposeType, InstanceStatus, PlatformEvent
from lpb.core.exceptions import (
    CapacityExceededError,
    ChallengeNotFoundError,
    InstanceNotFoundError,
)
from lpb.core.flag import generate_flag, verify_flag
from lpb.core.log import log
from lpb.core.state.models import InstanceState, NodeState, TeamState
from lpb.server.app_state import AppState
from lpb.server.auth import get_team_id
from lpb.server.events import emit_event
from lpb.server.instance_lifecycle import start_instance_async
from lpb.server.models import (
    BigLimitOffsetPage,
    InstanceInfo,
    InstanceStatusResponse,
    RenewResponse,
    StartRequest,
    StartResponse,
    StopResponse,
    VerifyFlagRequest,
    VerifyFlagResponse,
)
from lpb.server.node_ops import (
    get_node_client,
    stop_all_instances_on_node,
    stop_instance_on_node,
)
from lpb.server.scheduling import pick_node


def _matches_instance(
    inst: InstanceState, *, team_id: str, challenge_id: str, status: str, q: str
) -> bool:
    """Filter predicate for ``GET /instances``.

    A non-empty ``team_id`` matches owned + anonymous instances (the latter so
    admin-style surfaces stay visible after auth).
    """
    if team_id and inst.team_id and inst.team_id != team_id:
        return False
    if challenge_id and inst.challenge_id != challenge_id:
        return False
    if status and inst.status != status:
        return False
    if q and q.lower() not in (inst.challenge_id + inst.name).lower():
        return False
    return True


def _to_info(inst: InstanceState) -> InstanceInfo:
    return InstanceInfo(
        instance_id=inst.instance_id,
        challenge_id=inst.challenge_id or inst.instance_id,
        team_id=inst.team_id,
        name=inst.name,
        category=inst.category,
        difficulty=inst.difficulty,
        status=inst.status or InstanceStatus.READY,
        started_at=inst.started_at,
        ttl=inst.ttl,
        expires_at=inst.expires_at,
        services=list(inst.surface.services) if inst.surface else [],
    )


def create_router(app: AppState) -> APIRouter:
    router = APIRouter()

    @router.get("/instances", response_model=BigLimitOffsetPage[InstanceInfo])
    def list_instances(
        team: TeamState | None = Depends(app.get_current_team_or_none),
        challenge_id: str = "",
        status: str = "",
        q: str = "",
    ):
        team_id = get_team_id(team)
        return list_paginate(
            [
                _to_info(inst)
                for inst in app.state_backend.list_instances()
                if _matches_instance(
                    inst, team_id=team_id, challenge_id=challenge_id, status=status, q=q
                )
            ]
        )

    @router.post("/instances", response_model=StartResponse, status_code=202)
    def start_instance(
        req: StartRequest, team: TeamState | None = Depends(app.get_current_team_or_none)
    ):
        challenge_id = req.challenge_id

        # Resolve team
        team_id = get_team_id(team)

        # Serialize capacity/duplicate checks and state write to prevent TOCTOU races
        with app.instance_start_lock:
            if team_id:
                team_envs = sum(
                    1 for e in app.state_backend.list_instances() if e.team_id == team_id
                )
                if team_envs >= MAX_INSTANCES_PER_TEAM:
                    raise CapacityExceededError(
                        f"Max {MAX_INSTANCES_PER_TEAM} concurrent instances per team"
                    )

            # Generate random instance_id
            instance_id = str(uuid.uuid4())

            if app.state_backend.count_instances() >= app.max_instances:
                raise CapacityExceededError("Node at capacity")

            # Check for duplicate: same team + same challenge
            if team_id:
                existing = app.state_backend.get_instance_by_team_challenge(team_id, challenge_id)
            else:
                existing = app.state_backend.get_instance_by_team_challenge("", challenge_id)
            if existing:
                return JSONResponse(
                    status_code=409,
                    content=StartResponse(
                        instance_id=existing.instance_id,
                        status=existing.status or InstanceStatus.READY,
                    ).model_dump(),
                )

            # Look up the full challenge spec from metadata.yaml
            spec = None
            for canonical in app.spec_reader.iter_specs(challenge_id=challenge_id):
                if canonical.id == challenge_id:
                    spec = canonical.model_copy(update={"instance_id": instance_id})
                    break
            if spec is None:
                raise ChallengeNotFoundError(challenge_id)

            # Pick a healthy worker node. No node = no challenge.
            target_node = pick_node(app)
            if target_node is None:
                raise CapacityExceededError(
                    "No healthy node available. Register a node first: "
                    "`lpb node join` or `lpb server invite`."
                )

            # Generate the flag here, on the platform. The node only gets
            # a copy to inject into $FLAG; it never persists or verifies
            # (step 18). Constant-time comparison happens later, locally,
            # inside verify_flag_internal.
            flag = generate_flag()

            # Write initial state (starting), return immediately
            app.state_backend.put_instance(
                instance_id,
                InstanceState(
                    instance_id=instance_id,
                    spec=spec.model_dump(),
                    challenge_id=challenge_id,
                    status=InstanceStatus.STARTING,
                    team_id=team_id,
                    node_id=target_node.node_id,
                    surface=None,
                    flag=flag,
                    error="",
                    name=spec.name,
                    category=spec.category,
                    difficulty=spec.difficulty,
                ),
                ttl=req.ttl,
            )

        app.bg_executor.submit(
            start_instance_async,
            app,
            instance_id,
            proxy_output_dir=req.proxy_output_dir,
        )

        log.info("Instance starting (async)", instance=instance_id, ttl=req.ttl)
        emit_event(
            app,
            PlatformEvent.INSTANCE_STARTED,
            team_id=team_id,
            challenge_id=challenge_id,
            instance_id=instance_id,
        )
        return StartResponse(instance_id=instance_id, status=InstanceStatus.STARTING)

    # -- resolve endpoint (must be before {instance_id:path} routes) ---------------

    @router.get("/instances/resolve")
    def resolve_instance(challenge_id: str, team: TeamState = Depends(app.get_current_team)):
        """Resolve a challenge_id to its instance_id for the current team."""
        inst_data = app.state_backend.get_instance_by_team_challenge(team.team_id, challenge_id)
        if not inst_data:
            raise InstanceNotFoundError(challenge_id)
        return {"instance_id": inst_data.instance_id}

    # -- instance operation endpoints (with ownership via require_instance) -----

    @router.get("/instances/{instance_id:path}/status", response_model=InstanceStatusResponse)
    def get_instance_status(inst: InstanceState = Depends(app.require_instance)):
        instance_id = inst.instance_id
        status = inst.status or InstanceStatus.READY
        surface = inst.surface if status == InstanceStatus.READY else None

        sandbox_net = ""
        proxy_gw = ""
        cert_vol = ""
        if status == InstanceStatus.READY and inst.node_id:
            node = app.state_backend.get_node(inst.node_id)
            if node:
                try:
                    with get_node_client(app, node) as nc:
                        rt = nc.get_agent_runtime(instance_id)
                    sandbox_net = rt.get("network", "") or ""
                    proxy_gw = rt.get("proxy_gateway_ip", "") or ""
                    cert_vol = rt.get("ca_volume", "") or ""
                except Exception as exc:
                    log.debug(
                        "agent-runtime lookup failed",
                        instance=instance_id,
                        error=str(exc),
                    )

        # Echo the challenge's exposure strategy from its stored spec.
        # tcp_port (default) => users connect to surface host:port directly.
        # http_domain => public_url holds the Traefik-routed URL when the
        # router is enabled; otherwise "".
        expose_type = (inst.spec or {}).get("expose_type", ExposeType.TCP_PORT)
        public_url = ""
        if (
            expose_type == ExposeType.HTTP_DOMAIN
            and app.traefik_router is not None
            and app.traefik_router.enabled
        ):
            public_url = app.traefik_router.public_url(instance_id)

        return InstanceStatusResponse(
            instance_id=instance_id,
            status=status,
            attack_surface=surface,
            error=inst.error or None,
            sandbox_network=sandbox_net,
            proxy_gateway=proxy_gw,
            cert_volume=cert_vol,
            expose_type=expose_type,
            public_url=public_url,
        )

    @router.post("/instances/{instance_id:path}/verify-flag", response_model=VerifyFlagResponse)
    def verify_flag_route(
        req: VerifyFlagRequest, inst: InstanceState = Depends(app.require_instance)
    ):
        instance_id = inst.instance_id
        correct = verify_flag(app.state_backend, instance_id, req.claimed_flag)
        # Echo the canonical flag on correct submissions (platform is the
        # holder; step 18).
        return VerifyFlagResponse(
            correct=correct,
            flag_expected=inst.flag if correct else "",
        )

    @router.post("/instances/{instance_id:path}/renew", response_model=RenewResponse)
    def renew_instance(ttl: int = 3600, inst: InstanceState = Depends(app.require_instance)):
        instance_id = inst.instance_id
        try:
            expires_at = app.state_backend.renew_instance(instance_id, ttl)
        except KeyError:
            raise InstanceNotFoundError(instance_id)
        team_id = inst.team_id
        challenge_id = inst.challenge_id or instance_id
        log.info("TTL renewed", instance=instance_id, ttl=ttl)
        emit_event(
            app,
            PlatformEvent.INSTANCE_RENEWED,
            team_id=team_id,
            challenge_id=challenge_id,
            instance_id=instance_id,
            ttl=ttl,
        )
        return RenewResponse(instance_id=instance_id, expires_at=expires_at)

    @router.delete("/instances/{instance_id:path}", response_model=StopResponse)
    async def stop_instance(inst: InstanceState = Depends(app.require_instance)):
        instance_id = inst.instance_id
        node_id = inst.node_id
        app.state_backend.remove_instance(instance_id)
        if app.traefik_router is not None:
            app.traefik_router.remove(instance_id)
        if node_id:
            node = app.state_backend.get_node(node_id)
            if node:
                loop = asyncio.get_running_loop()
                try:
                    await loop.run_in_executor(
                        None,
                        lambda: stop_instance_on_node(app, node, instance_id),
                    )
                except Exception as e:
                    log.error(
                        "Remote stop failed", instance=instance_id, node=node_id, error=str(e)
                    )
                    # Fall through: the platform record is already gone; the
                    # node will eventually reap or it has already.
        challenge_id = inst.challenge_id or instance_id
        stop_team_id = inst.team_id
        log.info("Instance stopped", instance=instance_id)
        emit_event(
            app,
            PlatformEvent.INSTANCE_STOPPED,
            team_id=stop_team_id,
            challenge_id=challenge_id,
            instance_id=instance_id,
        )
        return StopResponse(instance_id=instance_id)

    @router.delete(
        "/instances",
        response_model=list[StopResponse],
        dependencies=[Depends(app.require_admin)],
    )
    async def stop_all_instances():
        """Stop all running instances across every node (admin only)."""
        loop = asyncio.get_running_loop()
        results = []
        nodes_to_wipe: dict[str, NodeState] = {}
        for inst in app.state_backend.list_instances():
            instance_id = inst.instance_id
            app.state_backend.remove_instance(instance_id)
            if app.traefik_router is not None:
                app.traefik_router.remove(instance_id)
            if inst.node_id:
                node = app.state_backend.get_node(inst.node_id)
                if node:
                    nodes_to_wipe.setdefault(inst.node_id, node)
            emit_event(
                app,
                PlatformEvent.INSTANCE_STOPPED,
                team_id=inst.team_id,
                challenge_id=inst.challenge_id,
                instance_id=instance_id,
            )
            results.append(StopResponse(instance_id=instance_id))

        for node in nodes_to_wipe.values():
            try:
                await loop.run_in_executor(None, lambda n=node: stop_all_instances_on_node(app, n))
            except Exception as e:
                log.error("stop-all on node failed", node=node.node_id, error=str(e))

        return results

    # -- instance traffic ------------------------------------------------

    @router.get("/instances/{instance_id:path}/traffic")
    def get_instance_traffic(inst: InstanceState = Depends(app.require_instance)):
        """Parsed mitmproxy traffic — the flow file lives on the node."""
        instance_id = inst.instance_id
        if not inst.node_id:
            return []
        node = app.state_backend.get_node(inst.node_id)
        if not node:
            return []
        try:
            with get_node_client(app, node) as nc:
                return nc.get_traffic(instance_id)
        except Exception as e:
            log.warning(
                "Remote traffic fetch failed",
                instance=instance_id,
                node=inst.node_id,
                error=str(e),
            )
            return []

    return router
