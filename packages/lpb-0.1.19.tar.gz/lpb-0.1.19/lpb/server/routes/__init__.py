"""Route modules for the platform server."""
