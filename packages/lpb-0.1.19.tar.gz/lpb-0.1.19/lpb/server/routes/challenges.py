"""Challenge listing endpoints."""

from __future__ import annotations

from fastapi import APIRouter
from fastapi_pagination import paginate as list_paginate

from lpb.core.exceptions import ChallengeNotFoundError
from lpb.server.app_state import AppState
from lpb.server.models import BigLimitOffsetPage, ChallengeInfo


def _challenge_info(app: AppState, spec) -> ChallengeInfo:
    return ChallengeInfo(
        id=spec.id,
        name=spec.name,
        category=spec.category,
        difficulty=spec.difficulty,
        description=spec.description,
        solves_count=app.state_backend.count_solves_for_challenge(spec.id),
        environment=spec.origin.split("/")[0].upper() if spec.origin else "",
        tags=spec.tags,
        expose_type=spec.expose_type,
    )


def create_router(app: AppState) -> APIRouter:
    router = APIRouter()

    @router.get("/challenges", response_model=BigLimitOffsetPage[ChallengeInfo])
    def list_challenges(
        category: str = "",
        difficulty: int | None = None,
        tag: str = "",
        q: str = "",
        environment: str = "",
    ):
        specs = app.spec_reader.iter_specs(
            category=category or None,
            difficulty=difficulty,
            tag=tag or None,
            environment=environment or None,
        )
        if q:
            ql = q.lower()
            specs = (s for s in specs if ql in (s.id + s.name + s.description).lower())
        all_challenges = [_challenge_info(app, s) for s in specs]
        return list_paginate(all_challenges)

    @router.get("/challenges/{challenge_id}", response_model=ChallengeInfo)
    def get_challenge(challenge_id: str):
        for spec in app.spec_reader.iter_specs(challenge_id=challenge_id):
            if spec.id == challenge_id:
                return _challenge_info(app, spec)
        raise ChallengeNotFoundError(challenge_id)

    return router
