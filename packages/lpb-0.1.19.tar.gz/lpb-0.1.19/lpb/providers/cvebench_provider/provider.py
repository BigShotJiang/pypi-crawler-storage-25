"""CVEBench challenge provider — docker compose based orchestration."""

from __future__ import annotations

import re
import shutil
import subprocess
import time
from pathlib import Path
from typing import ClassVar

from pydantic import BaseModel, Field

from lpb.core.challenge import ChallengeSpec
from lpb.core.config import LpbConfig
from lpb.core.log import log
from lpb.core.ports import PortAllocator
from lpb.core.provider import ChallengeProvider, StartResult
from lpb.core.target import AttackSurface, ServiceEndpoint, ServiceType
from lpb.providers.docker_provider.utils import (
    PREFIX,
    ProxySidecarState,
    start_proxy_sidecar,
)


class CVEBenchConfig(BaseModel):
    """Typed configuration for CVEBench instances."""

    services: dict[str, dict] = Field(default_factory=dict)
    compose_file: str = ""
    vendor_dir: str = ""
    flag_path: str | None = None
    sandboxed: bool = True

    @classmethod
    def from_provider_config(cls, raw: dict) -> CVEBenchConfig:
        return cls(
            services=raw.get("services", {}),
            compose_file=raw.get("compose_file", ""),
            vendor_dir=raw.get("vendor_dir", ""),
            flag_path=raw.get("secret_file_path") or raw.get("flag_path"),
            sandboxed=raw.get("sandboxed", True),
        )


class _RunningInstance(BaseModel):
    challenge_dir: str
    project_name: str
    flag: str = ""
    proxy_state: ProxySidecarState | None = None
    host_ports: dict[str, int] = Field(default_factory=dict)
    socat_pids: list[int] = Field(default_factory=list)


class CVEBenchProvider(ChallengeProvider):
    """Manages CVEBench instances using docker compose."""

    name: ClassVar[str] = "cvebench"

    def __init__(self, config: LpbConfig, port_alloc: PortAllocator):
        self.config = config
        self.challenges_dir = config.challenges_dir
        self.ports = port_alloc
        self._running: dict[str, _RunningInstance] = {}

    @staticmethod
    def _validate_docker_name(name: str) -> str:
        """Validate that a name is safe for use in Docker commands and Go templates."""
        if not re.fullmatch(r"[a-zA-Z0-9][a-zA-Z0-9._-]*", name):
            raise ValueError(f"Invalid Docker resource name: {name!r}")
        return name

    def _get_target_network_name(self, challenge_dir: Path, project_name: str) -> str:
        """Get the target network name from compose config."""
        cmd = self._compose_cmd(challenge_dir, project_name) + ["config", "--format", "json"]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        if result.returncode == 0:
            import json

            try:
                data = json.loads(result.stdout)
                for net_key, net_val in data.get("networks", {}).items():
                    if "target" in net_key:
                        raw = net_val.get("name", f"{project_name}_{net_key}")
                        return self._validate_docker_name(raw)
            except (json.JSONDecodeError, KeyError):
                pass
        return self._validate_docker_name(f"{project_name}_target_network")

    def _compose_cmd(self, challenge_dir: Path, project_name: str) -> list[str]:
        compose_file = challenge_dir / "docker-compose.yml"
        return [
            "docker",
            "compose",
            "-f",
            str(compose_file),
            "-p",
            project_name,
        ]

    def start(self, spec: ChallengeSpec, *, proxy_output_dir: Path | None = None) -> StartResult:
        config = CVEBenchConfig.from_provider_config(spec.provider_config)
        challenge_dir = self.challenges_dir / spec.id
        project_name = self._validate_docker_name(f"{PREFIX}_{spec.id}".lower().replace("-", "_"))

        compose_file = challenge_dir / "docker-compose.yml"
        if not compose_file.exists():
            raise FileNotFoundError(
                f"docker-compose.yml not found in {challenge_dir}. "
                f"Run scripts/generate_cvebench_envs.sh first."
            )

        # Pull images
        log.info("Pulling CVEBench images", challenge=spec.id)
        pull_cmd = self._compose_cmd(challenge_dir, project_name) + ["pull"]
        result = subprocess.run(pull_cmd, capture_output=True, text=True, timeout=600)
        if result.returncode != 0:
            log.warning("Pull may have issues", stderr=result.stderr[:500])

        # Start services
        log.info("Starting CVEBench instance", challenge=spec.id)
        up_cmd = self._compose_cmd(challenge_dir, project_name) + [
            "up",
            "-d",
            "--wait",
            "--wait-timeout",
            "180",
        ]
        result = subprocess.run(up_cmd, capture_output=True, text=True, timeout=300)
        if result.returncode != 0:
            log.error(
                "Failed to start CVEBench instance", challenge=spec.id, stderr=result.stderr[:1000]
            )
            raise RuntimeError(f"docker compose up failed for {spec.id}: {result.stderr[:500]}")

        # Parse expose specs and allocate host ports
        endpoints: list[ServiceEndpoint] = []
        host_ports: dict[str, int] = {}
        socat_pids: list[int] = []

        for sname, sdata in config.services.items():
            for exp in sdata.get("expose", []):
                stype = ServiceType(exp["type"])
                container_port = exp["container_port"]
                port_key = f"{spec.id}/{sname}/{stype.value}/{container_port}"
                host_port = self.ports.allocate(port_key)
                host_ports[port_key] = host_port

                # Set up port forwarding via socat in background
                # Get the container's internal IP on the target_network
                container_name = f"{project_name}-{sname}-1"
                # Get the actual target network name from compose config
                target_net_name = self._get_target_network_name(challenge_dir, project_name)
                ip_cmd = [
                    "docker",
                    "inspect",
                    "-f",
                    '{{(index .NetworkSettings.Networks "' + target_net_name + '").IPAddress}}',
                    container_name,
                ]
                ip_result = subprocess.run(ip_cmd, capture_output=True, text=True)
                container_ip = ip_result.stdout.strip()
                # Fallback: try first network IP
                if not container_ip or "<no value>" in container_ip:
                    ip_cmd2 = [
                        "docker",
                        "inspect",
                        "-f",
                        "{{range .NetworkSettings.Networks}}{{.IPAddress}} {{end}}",
                        container_name,
                    ]
                    ip_result2 = subprocess.run(ip_cmd2, capture_output=True, text=True)
                    ips = ip_result2.stdout.strip().split()
                    container_ip = ips[0] if ips else ""

                if container_ip:
                    # Use socat for port forwarding; track PID for cleanup
                    pid = _start_port_forward(host_port, container_ip, container_port)
                    if pid:
                        socat_pids.append(pid)
                    log.info(
                        "Port forward",
                        host_port=host_port,
                        target=f"{container_ip}:{container_port}",
                    )
                else:
                    log.warning("Could not get container IP", container=container_name)

                if config.sandboxed:
                    endpoints.append(
                        ServiceEndpoint(
                            service_type=stype,
                            host=sname,
                            port=container_port,
                            label=sname,
                            path=exp.get("path", "/"),
                        )
                    )
                else:
                    endpoints.append(
                        ServiceEndpoint(
                            service_type=stype,
                            host="127.0.0.1",
                            port=host_port,
                            label=sname,
                            path=exp.get("path", "/"),
                        )
                    )

        # Read the flag/secret from the target container
        flag = ""
        secret_path = config.flag_path or "/tmp/secret"
        target_container = f"{project_name}-target-1"
        time.sleep(2)  # Wait for secrets to be written
        for attempt in range(5):
            flag_cmd = ["docker", "exec", target_container, "cat", secret_path]
            flag_result = subprocess.run(flag_cmd, capture_output=True, text=True)
            if flag_result.returncode == 0 and flag_result.stdout.strip():
                flag = flag_result.stdout.strip()
                break
            time.sleep(2)

        if not flag:
            log.warning(
                "Could not read flag/secret from container",
                container=target_container,
                path=secret_path,
            )

        # Set up proxy if sandboxed
        proxy_state = None
        if config.sandboxed:
            target_net = self._get_target_network_name(challenge_dir, project_name)
            log.info("Using target network", network=target_net)

            import docker as docker_lib

            docker_client = docker_lib.from_env()

            try:
                proxy_state = start_proxy_sidecar(
                    docker_client,
                    spec.id,
                    target_net,
                    list(config.services.keys()),
                    config=self.config,
                    proxy_output_dir=proxy_output_dir,
                )
            except Exception as e:
                log.warning("Failed to set up proxy for CVEBench", error=str(e))

        self._running[spec.id] = _RunningInstance(
            challenge_dir=str(challenge_dir),
            project_name=project_name,
            proxy_state=proxy_state,
            host_ports=host_ports,
            socat_pids=socat_pids,
        )

        self._running[spec.id].flag = flag
        return StartResult(
            surface=AttackSurface(services=endpoints, flag_path=config.flag_path),
            flag=flag,
        )

    def verify_flag(self, instance_id: str, claimed_flag: str) -> bool:
        import hmac

        running = self._running.get(instance_id)
        if not running or not running.flag:
            return False
        return hmac.compare_digest(running.flag, claimed_flag)

    def stop(self, spec: ChallengeSpec) -> None:
        self.stop_by_id(spec.id)

    def stop_by_id(self, instance_id: str) -> None:
        running = self._running.pop(instance_id, None)
        if not running:
            return

        challenge_dir = Path(running.challenge_dir)
        cmd = self._compose_cmd(challenge_dir, running.project_name) + [
            "down",
            "-v",
            "--remove-orphans",
            "--timeout",
            "10",
        ]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
        if result.returncode != 0:
            log.warning("compose down may have issues", stderr=result.stderr[:300])

        if running.proxy_state:
            import docker as docker_lib

            docker_client = docker_lib.from_env()

            from lpb.providers.docker_provider.utils import (
                cleanup_containers,
                cleanup_networks,
                cleanup_volumes,
            )

            cleanup_containers(docker_client, [running.proxy_state.container_name])
            cleanup_networks(docker_client, [running.proxy_state.attacker_network_name])
            cleanup_volumes(docker_client, [running.proxy_state.cert_volume])

            if running.proxy_state.proxy_output and not running.proxy_state.proxy_output_external:
                shutil.rmtree(running.proxy_state.proxy_output, ignore_errors=True)

        for port_key in running.host_ports:
            self.ports.release(port_key)

        # Kill tracked socat port-forward processes by PID
        import os
        import signal

        for pid in running.socat_pids:
            try:
                os.kill(pid, signal.SIGTERM)
            except ProcessLookupError:
                pass

    def get_sandbox_network(self, instance_id: str) -> tuple[str, str] | None:
        running = self._running.get(instance_id)
        if running and running.proxy_state and running.proxy_state.attacker_network_name:
            return running.proxy_state.attacker_network_name, running.proxy_state.proxy_gateway
        return None

    def get_cert_volume(self, instance_id: str) -> str:
        running = self._running.get(instance_id)
        if running and running.proxy_state and running.proxy_state.cert_volume:
            return running.proxy_state.cert_volume
        return ""

    def get_proxy_output(self, instance_id: str) -> Path | None:
        running = self._running.get(instance_id)
        if running and running.proxy_state and running.proxy_state.proxy_output:
            return Path(running.proxy_state.proxy_output)
        return None

    def stop_all(self) -> None:
        for instance_id in list(self._running):
            self.stop_by_id(instance_id)
        self.ports.release_all()


def _start_port_forward(host_port: int, target_ip: str, target_port: int) -> int | None:
    """Start a socat port forward in the background. Returns the PID or None."""
    try:
        proc = subprocess.Popen(
            ["socat", f"TCP-LISTEN:{host_port},fork,reuseaddr", f"TCP:{target_ip}:{target_port}"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        return proc.pid
    except FileNotFoundError:
        log.warning("socat not found, port forwarding unavailable")
        return None
