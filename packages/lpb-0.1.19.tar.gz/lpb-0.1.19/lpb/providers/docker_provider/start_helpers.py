"""Helper functions extracted from DockerProvider._do_start()."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

import docker
import docker.errors

from lpb.core.config import LpbConfig
from lpb.core.flag import generate_flag
from lpb.core.log import log
from lpb.core.target import Credential, ServiceEndpoint, ServiceType
from lpb.providers.docker_provider.paths import to_host_path
from lpb.providers.docker_provider.provider import (
    DockerConfig,
    ServiceSpec,
    _port_key,
)

if TYPE_CHECKING:
    from lpb.core.ports import PortAllocator


def prepare_flag(workdir: Path, flag: str | None = None) -> tuple[str, Path]:
    """Write a flag to the instance workdir.

    When ``flag`` is provided (the platform-centralized path post-step-18),
    use it verbatim; otherwise fall back to generating one locally — kept
    for in-process provider usage outside the node contract (tests,
    evaluator direct mode). Returns ``(flag, flag_file)``.
    """
    if not flag:
        flag = generate_flag()
    flag_file = workdir / "flag"
    flag_file.write_text(flag)
    return flag, flag_file


def create_or_get_network(docker_client, network_name: str):
    """Create a Docker bridge network, or get it if it already exists."""
    try:
        return docker_client.networks.create(network_name, driver="bridge")
    except docker.errors.APIError:
        return docker_client.networks.get(network_name)


def allocate_ports_and_endpoints(
    svc: ServiceSpec,
    sname: str,
    eid: str,
    port_alloc: PortAllocator,
    traefik_token: str,
    sandboxed: bool,
    *,
    base_domain: str = "",
) -> tuple[dict[int, int], list[ServiceEndpoint], list[ServiceEndpoint]]:
    """Allocate host ports and build endpoint lists for a single service.

    Returns (port_bindings, host_endpoints, sandboxed_endpoints).
    """
    port_bindings: dict[int, int] = {}
    host_endpoints: list[ServiceEndpoint] = []
    sandboxed_endpoints: list[ServiceEndpoint] = []

    for exp in svc.expose:
        key = _port_key(eid, sname, exp.type, exp.container_port)
        host_port = port_alloc.allocate(key)
        port_bindings[exp.container_port] = host_port

        cred = None
        if exp.credentials:
            cred = Credential(
                username=exp.credentials.get("username", ""),
                password=exp.credentials.get("password"),
            )

        sub_url = ""
        if traefik_token and exp.type in (ServiceType.HTTP, ServiceType.HTTPS):
            subdomain = f"{eid}-{sname}".replace("_", "-").lower()
            sub_url = f"http://{subdomain}-{traefik_token}.{base_domain}{exp.path}"

        host_ep = ServiceEndpoint(
            service_type=exp.type,
            host="127.0.0.1",
            port=host_port,
            credentials=cred,
            path=exp.path,
            label=sname,
            subdomain_url=sub_url,
        )
        host_endpoints.append(host_ep)

        if sandboxed:
            sandboxed_endpoints.append(
                ServiceEndpoint(
                    service_type=exp.type,
                    host=sname,
                    port=exp.container_port,
                    credentials=cred,
                    path=exp.path,
                    label=sname,
                )
            )
        else:
            sandboxed_endpoints.append(host_ep)

    return port_bindings, host_endpoints, sandboxed_endpoints


def build_volumes(
    svc: ServiceSpec,
    config: DockerConfig,
    flag_file: Path,
    challenge_dir: Path,
    *,
    lpb_config: LpbConfig,
) -> dict[str, dict]:
    """Build the volumes dict for a container."""
    vols: dict[str, dict] = {}
    host_kwargs = {
        "host_project_root": lpb_config.host_project_root,
        "project_root": lpb_config.project_root,
    }
    if config.flag_path:
        vols[to_host_path(flag_file, **host_kwargs)] = {"bind": config.flag_path, "mode": "ro"}
    for vol in svc.volumes:
        if ":" in vol:
            host_part, cont_part = vol.split(":", 1)
            vols[to_host_path((challenge_dir / host_part).resolve(), **host_kwargs)] = {
                "bind": cont_part,
                "mode": "rw",
            }
    return vols


def build_flag_inject(
    svc: ServiceSpec,
    sname: str,
    image_tag: str,
    workdir: Path,
    docker_client,
    vols: dict[str, dict],
    *,
    lpb_config: LpbConfig,
) -> tuple[list[str] | None, list[str]]:
    """Build flag-injection entrypoint override if flag_inject rules exist.

    Mutates *vols* to mount the entrypoint script.
    Returns (entrypoint_override, orig_cmd).
    """
    if not svc.flag_inject:
        return None, []

    img = docker_client.images.get(image_tag)
    img_cfg = img.attrs.get("Config", {})
    orig_ep = img_cfg.get("Entrypoint") or []
    orig_cmd = img_cfg.get("Cmd") or []

    script_lines = ["#!/bin/sh"]
    for fi in svc.flag_inject:
        if fi.pattern:
            script_lines.append(f'sed -i "s/{fi.pattern}/$FLAG/g" {fi.path}')
        else:
            script_lines.append(f'echo "$FLAG" > {fi.path}')
    script_lines.append('exec "$@"')
    script_content = "\n".join(script_lines) + "\n"
    ep_file = workdir / f"flag-entrypoint-{sname}.sh"
    ep_file.write_text(script_content)
    ep_file.chmod(0o755)
    vols[
        to_host_path(
            ep_file,
            host_project_root=lpb_config.host_project_root,
            project_root=lpb_config.project_root,
        )
    ] = {"bind": "/flag-entrypoint.sh", "mode": "ro"}
    entrypoint_override = ["/flag-entrypoint.sh"] + orig_ep
    return entrypoint_override, orig_cmd


def run_container(
    docker_client,
    image_tag: str,
    cname: str,
    network_name: str,
    sname: str,
    svc: ServiceSpec,
    port_bindings: dict[int, int],
    env: dict[str, str],
    vols: dict[str, dict],
    entrypoint_override: list[str] | None,
    orig_cmd: list[str],
    traefik_labels: dict[str, str],
):
    """Create and start a single service container, wiring it into the network."""
    # Remove stale container with same name
    try:
        old = docker_client.containers.get(cname)
        old.remove(force=True)
    except docker.errors.NotFound:
        pass

    container = docker_client.containers.run(
        image_tag,
        name=cname,
        detach=True,
        network=network_name,
        ports=port_bindings,
        environment=env,
        volumes=vols or None,
        # Container hardening: drop all caps by default; re-add only what
        # the service explicitly needs. Defense-in-depth for CTF payloads.
        cap_drop=svc.cap_drop or None,
        cap_add=svc.cap_add or None,
        privileged=False,  # belt-and-braces; providers never need this
        security_opt=svc.security_opt or None,
        pids_limit=svc.pids_limit or None,
        read_only=svc.read_only,
        working_dir=svc.working_dir,
        command=svc.command or (orig_cmd if entrypoint_override else None),
        entrypoint=entrypoint_override,
        mem_limit=svc.mem_limit,
        nano_cpus=svc.nano_cpus,
        labels=traefik_labels or None,
    )
    return container


def connect_container_networks(
    docker_client,
    container,
    network,
    sname: str,
    eid: str,
    traefik_labels: dict[str, str],
    *,
    traefik_network: str = "",
):
    """Reconnect the container with proper aliases and optionally attach to Traefik."""
    network.disconnect(container)
    network.connect(container, aliases=[sname])

    if traefik_labels and traefik_network:
        try:
            traefik_net = docker_client.networks.get(traefik_network)
            traefik_net.connect(container, aliases=[f"{eid}-{sname}"])
        except docker.errors.NotFound:
            log.warning(
                "Traefik network not found, skipping subdomain routing",
                network=traefik_network,
            )
