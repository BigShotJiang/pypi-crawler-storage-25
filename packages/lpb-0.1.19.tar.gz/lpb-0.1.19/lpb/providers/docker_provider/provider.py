"""Docker-based challenge provider — local container orchestration."""

from __future__ import annotations

import secrets
import shutil
import socket
import time
from graphlib import TopologicalSorter
from pathlib import Path
from typing import ClassVar

import docker
import docker.errors
from pydantic import BaseModel, Field

from lpb.core.challenge import ChallengeSpec
from lpb.core.config import LpbConfig
from lpb.core.constants import STARTUP_TIMEOUT
from lpb.core.exceptions import HealthCheckError
from lpb.core.log import log
from lpb.core.ports import PortAllocator
from lpb.core.provider import ChallengeProvider, StartResult
from lpb.core.target import AttackSurface, ServiceEndpoint, ServiceType
from lpb.providers.docker_provider.utils import (
    PREFIX,
    ProxySidecarState,
    start_proxy_sidecar,
)


def _build_traefik_labels(
    eid: str,
    sname: str,
    expose_specs: list["ExposeSpec"],
    base_domain: str,
    traefik_network: str,
    token: str,
) -> dict[str, str]:
    """Generate Traefik Docker labels for auto-discovery of HTTP services."""
    labels: dict[str, str] = {"traefik.enable": "true"}
    router_base = f"{eid}-{sname}".replace("_", "-").lower()

    for i, exp in enumerate(expose_specs):
        if exp.type not in (ServiceType.HTTP, ServiceType.HTTPS):
            continue
        suffix = f"-{i}" if len(expose_specs) > 1 else ""
        rname = f"{router_base}{suffix}"
        subdomain = f"{router_base}-{token}"
        labels[f"traefik.http.routers.{rname}.rule"] = f"Host(`{subdomain}.{base_domain}`)"
        labels[f"traefik.http.routers.{rname}.entrypoints"] = "web"
        labels[f"traefik.http.services.{rname}.loadbalancer.server.port"] = str(exp.container_port)

    labels["traefik.docker.network"] = traefik_network
    return labels


# ---------------------------------------------------------------------------
# Typed config — validated from provider_config dict
# ---------------------------------------------------------------------------


class ExposeSpec(BaseModel):
    type: ServiceType
    container_port: int
    credentials: dict[str, str] | None = None
    path: str = "/"


class FlagInjectSpec(BaseModel):
    """Describes how to inject the flag into a container at runtime.

    - *path* – absolute path inside the container to the target file.
    - *pattern* – if set, ``sed -i "s/<pattern>/$FLAG/g" <path>`` is executed
      at container start.  If *None*, the flag value is written directly to
      *path* (``echo "$FLAG" > <path>``).
    """

    path: str
    pattern: str | None = None


class ServiceSpec(BaseModel):
    build: str | None = None
    image: str | None = None
    expose: list[ExposeSpec] = Field(default_factory=list)
    environment: dict[str, str] = Field(default_factory=dict)
    build_args: dict[str, str] = Field(default_factory=dict)
    command: str | None = None
    working_dir: str | None = None
    # --- Container hardening (secure-by-default) ---
    # Drop all Linux capabilities; cap_add grants back only what the
    # challenge explicitly requires. This is a strong mitigation against
    # container-escape primitives that require e.g. CAP_SYS_ADMIN.
    cap_drop: list[str] = Field(default_factory=lambda: ["ALL"])
    cap_add: list[str] = Field(default_factory=list)
    # Resource caps. Defaults are sensible for CTF challenges; per-
    # challenge metadata can raise them when the problem legitimately
    # needs more (e.g. brute-force workloads).
    mem_limit: str = "512m"
    nano_cpus: int = 1_000_000_000  # 1 CPU core
    pids_limit: int = 512  # fork-bomb mitigation
    # Extra security options. no-new-privileges closes off setuid
    # escalation. Challenges that need it can clear this list.
    security_opt: list[str] = Field(default_factory=lambda: ["no-new-privileges:true"])
    # Opt-in read-only root FS. Most challenges write to /tmp etc, so
    # this is disabled by default; set true in metadata.yaml for hardened
    # challenges where you know the container image tolerates it.
    read_only: bool = False
    # --- Other ---
    volumes: list[str] = Field(default_factory=list)
    depends_on: list[str] = Field(default_factory=list)
    flag_inject: list[FlagInjectSpec] = Field(default_factory=list)


class DockerConfig(BaseModel):
    """Typed configuration for Docker-based instances."""

    services: dict[str, ServiceSpec] = Field(default_factory=dict)
    flag_path: str | None = None
    sandboxed: bool = True
    startup_timeout: int = STARTUP_TIMEOUT
    startup_retries: int = 2  # max retry attempts when health check fails

    @classmethod
    def from_provider_config(cls, raw: dict) -> DockerConfig:
        """Parse the provider_config dict into a typed DockerConfig."""
        raw_services = raw.get("services", {})
        services = {}
        for sname, sdata in raw_services.items():
            sdata = dict(sdata)  # shallow copy
            expose_list = [ExposeSpec(**e) for e in sdata.pop("expose", [])]
            inject_list = [FlagInjectSpec(**fi) for fi in sdata.pop("flag_inject", [])]
            services[sname] = ServiceSpec(expose=expose_list, flag_inject=inject_list, **sdata)
        return cls(
            services=services,
            flag_path=raw.get("flag_path"),
            sandboxed=raw.get("sandboxed", True),
            startup_timeout=raw.get("startup_timeout", 120),
            startup_retries=raw.get("startup_retries", 2),
        )


# ---------------------------------------------------------------------------
# Provider
# ---------------------------------------------------------------------------


def _port_key(instance_id: str, sname: str, stype: ServiceType, port: int) -> str:
    return f"{instance_id}/{sname}/{stype.value}/{port}"


class DockerProvider(ChallengeProvider):
    """Manages local Docker instances (vulhub, custom Dockerfiles, etc.)."""

    name: ClassVar[str] = "docker"

    def __init__(self, config: LpbConfig, port_alloc: PortAllocator):
        self.config = config
        self.challenges_dir = config.challenges_dir
        self.ports = port_alloc
        self._docker = docker.from_env()
        self._running: dict[str, _RunningInstance] = {}

    def start(
        self,
        spec: ChallengeSpec,
        *,
        proxy_output_dir: Path | None = None,
        flag: str | None = None,
    ) -> StartResult:
        config = DockerConfig.from_provider_config(spec.provider_config)
        max_attempts = config.startup_retries + 1
        last_err: Exception | None = None

        for attempt in range(1, max_attempts + 1):
            try:
                return self._do_start(spec, config, proxy_output_dir=proxy_output_dir, flag=flag)
            except HealthCheckError as e:
                last_err = e
                log.warning(
                    "Startup health check failed",
                    challenge=spec.effective_id,
                    attempt=attempt,
                    max_attempts=max_attempts,
                    error=str(e),
                )
                # cleanup before retry (stop clears _running entry)
                self.stop(spec)
                if attempt < max_attempts:
                    log.info(
                        "Retrying instance start", challenge=spec.effective_id, attempt=attempt + 1
                    )

        raise last_err  # type: ignore[misc]

    def _do_start(
        self,
        spec: ChallengeSpec,
        config: DockerConfig,
        *,
        proxy_output_dir: Path | None = None,
        flag: str | None = None,
    ) -> StartResult:
        from .start_helpers import (
            allocate_ports_and_endpoints,
            build_flag_inject,
            build_volumes,
            connect_container_networks,
            create_or_get_network,
            prepare_flag,
            run_container,
        )

        eid = spec.effective_id
        challenge_dir = self.challenges_dir / spec.id
        network_name = f"{PREFIX}_{eid}"
        containers: dict[str, docker.models.containers.Container] = {}
        endpoints: list[ServiceEndpoint] = []
        host_endpoints: list[ServiceEndpoint] = []

        workdir = self.config.instances_dir / eid
        workdir.mkdir(parents=True, exist_ok=True)
        flag, flag_file = prepare_flag(workdir, flag=flag)

        self._running[eid] = _RunningInstance(
            config=config,
            network_name=network_name,
            container_names=[],
            workdir=str(workdir),
        )

        try:
            network = create_or_get_network(self._docker, network_name)

            ordered = _topo_sort(config.services)
            for sname in ordered:
                svc = config.services[sname]
                cname = f"{PREFIX}_{eid}_{sname}"
                image_tag = self._resolve_image(svc, sname, challenge_dir, spec, flag)

                traefik_token = ""
                if self.config.traefik_enabled and self.config.base_domain and svc.expose:
                    traefik_token = secrets.token_hex(3)

                port_bindings, svc_host_eps, svc_eps = allocate_ports_and_endpoints(
                    svc,
                    sname,
                    eid,
                    self.ports,
                    traefik_token,
                    config.sandboxed,
                    base_domain=self.config.base_domain,
                )
                host_endpoints.extend(svc_host_eps)
                endpoints.extend(svc_eps)

                env = {"FLAG": flag, **svc.environment}
                vols = build_volumes(svc, config, flag_file, challenge_dir, lpb_config=self.config)
                entrypoint_override, orig_cmd = build_flag_inject(
                    svc,
                    sname,
                    image_tag,
                    workdir,
                    self._docker,
                    vols,
                    lpb_config=self.config,
                )

                for dep in svc.depends_on:
                    if dep in containers:
                        _wait_container_ready(containers[dep], timeout=config.startup_timeout)

                traefik_labels: dict[str, str] = {}
                if traefik_token:
                    traefik_labels = _build_traefik_labels(
                        eid,
                        sname,
                        svc.expose,
                        self.config.base_domain,
                        self.config.traefik_network,
                        traefik_token,
                    )

                container = run_container(
                    self._docker,
                    image_tag,
                    cname,
                    network_name,
                    sname,
                    svc,
                    port_bindings,
                    env,
                    vols,
                    entrypoint_override,
                    orig_cmd,
                    traefik_labels,
                )
                connect_container_networks(
                    self._docker,
                    container,
                    network,
                    sname,
                    eid,
                    traefik_labels,
                    traefik_network=self.config.traefik_network,
                )
                containers[sname] = container
                self._running[eid].container_names.append(cname)

            if config.sandboxed:
                proxy = start_proxy_sidecar(
                    self._docker,
                    eid,
                    network_name,
                    list(config.services.keys()),
                    config=self.config,
                    proxy_output_dir=proxy_output_dir or workdir / "proxy",
                )
                self._running[eid].proxy_state = proxy
                self._running[eid].container_names.append(proxy.container_name)

            _wait_healthy(host_endpoints, timeout=config.startup_timeout)

        except Exception:
            self.stop(spec)
            raise

        self._running[eid].flag = flag
        surface_eps = host_endpoints if host_endpoints else endpoints
        return StartResult(
            surface=AttackSurface(services=surface_eps, flag_path=config.flag_path),
            flag=flag,
        )

    def verify_flag(self, instance_id: str, claimed_flag: str) -> bool:
        import hmac

        running = self._running.get(instance_id)
        if not running or not running.flag:
            return False
        return hmac.compare_digest(running.flag, claimed_flag)

    def stop(self, spec: ChallengeSpec) -> None:
        self.stop_by_id(spec.effective_id)

    def stop_by_id(self, instance_id: str) -> None:
        running = self._running.pop(instance_id, None)
        if not running:
            return

        from .utils import cleanup_containers, cleanup_networks, cleanup_volumes

        cleanup_containers(self._docker, running.container_names)

        net_names = [running.network_name]
        vol_names: list[str] = []
        if running.proxy_state:
            net_names.append(running.proxy_state.attacker_network_name)
            vol_names.append(running.proxy_state.cert_volume)
            if running.proxy_state.proxy_output and not running.proxy_state.proxy_output_external:
                try:
                    shutil.rmtree(running.proxy_state.proxy_output)
                except Exception as e:
                    log.warning(
                        "Failed to remove proxy output",
                        path=running.proxy_state.proxy_output,
                        error=str(e),
                    )

        cleanup_networks(self._docker, net_names)
        cleanup_volumes(self._docker, vol_names)

        if running.workdir:
            try:
                shutil.rmtree(running.workdir)
            except Exception as e:
                log.warning("Failed to remove workdir", path=str(running.workdir), error=str(e))

        for sname, svc in running.config.services.items():
            for exp in svc.expose:
                self.ports.release(_port_key(instance_id, sname, exp.type, exp.container_port))

    def get_sandbox_network(self, instance_id: str) -> tuple[str, str] | None:
        """Return (attacker_network_name, proxy_gateway_ip) for sandbox."""
        running = self._running.get(instance_id)
        if running and running.proxy_state and running.proxy_state.attacker_network_name:
            return running.proxy_state.attacker_network_name, running.proxy_state.proxy_gateway
        return None

    def get_cert_volume(self, instance_id: str) -> str:
        """Return the Docker volume name containing mitmproxy CA certs."""
        running = self._running.get(instance_id)
        if running and running.proxy_state and running.proxy_state.cert_volume:
            return running.proxy_state.cert_volume
        return ""

    def get_proxy_output(self, instance_id: str) -> Path | None:
        """Return path to mitmproxy traffic output directory, if available."""
        running = self._running.get(instance_id)
        if running and running.proxy_state and running.proxy_state.proxy_output:
            return Path(running.proxy_state.proxy_output)
        return None

    def check_health(self, instance_id: str) -> bool:
        """Return True if all containers for the instance are running."""
        running = self._running.get(instance_id)
        if not running:
            return False
        for cname in running.container_names:
            try:
                container = self._docker.containers.get(cname)
                container.reload()
                if container.status != "running":
                    return False
            except docker.errors.NotFound:
                return False
        return True

    def stop_all(self) -> None:
        for instance_id in list(self._running):
            self.stop_by_id(instance_id)
        self.ports.release_all()

    def _resolve_image(
        self, svc: ServiceSpec, sname: str, challenge_dir: Path, spec: ChallengeSpec, flag: str = ""
    ) -> str:
        if svc.image:
            return svc.image

        # If build_args reference $FLAG, the flag is baked into the image
        # so each instance needs a unique tag. Otherwise use the stable
        # challenge id so the image is built once and reused.
        flag_in_build = any("$FLAG" in v for v in svc.build_args.values())
        base_id = spec.effective_id if flag_in_build else spec.id
        tag = f"{PREFIX}_{base_id}_{sname}:latest".lower()

        # Skip build if image already exists (only for stable tags)
        if not flag_in_build:
            try:
                self._docker.images.get(tag)
                log.info("Image already exists, skipping build", tag=tag)
                return tag
            except docker.errors.ImageNotFound:
                pass

        build_ctx = str(challenge_dir / svc.build) if svc.build else str(challenge_dir / sname)
        buildargs = {}
        for k, v in svc.build_args.items():
            resolved = v.replace("$FLAG", flag) if flag else v
            buildargs[k] = resolved
        log.info("Building image", tag=tag)
        # Use subprocess for docker build to ensure --network=host works
        # (the Python Docker SDK doesn't reliably pass network_mode with BuildKit)
        import subprocess

        cmd = ["docker", "build", "--network=host", "-t", tag]
        for k, v in buildargs.items():
            cmd.extend(["--build-arg", f"{k}={v}"])
        cmd.append(build_ctx)
        result = subprocess.run(cmd, capture_output=True, text=True)
        if result.returncode != 0:
            raise RuntimeError(f"Docker build failed for {tag}: {result.stderr[-2000:]}")
        return tag


class _RunningInstance(BaseModel):
    model_config = {"arbitrary_types_allowed": True}
    config: DockerConfig
    network_name: str
    container_names: list[str] = Field(default_factory=list)
    workdir: str = ""
    flag: str = ""
    proxy_state: ProxySidecarState | None = None


def _topo_sort(services: dict[str, ServiceSpec]) -> list[str]:
    graph = {name: set(svc.depends_on) for name, svc in services.items()}
    return list(TopologicalSorter(graph).static_order())


def _wait_container_ready(container, timeout: int = 60) -> None:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        container.reload()
        state = container.attrs.get("State", {})
        health = state.get("Health", {}).get("Status")
        if health:
            if health == "healthy":
                return
        elif state.get("Status") == "running":
            time.sleep(2)
            return
        time.sleep(1)
    log.warning("Container not ready", name=container.name, timeout=timeout)


def _wait_healthy(endpoints: list[ServiceEndpoint], timeout: int = 30) -> None:
    import urllib.error
    import urllib.request

    for ep in endpoints:
        deadline = time.monotonic() + timeout
        connected = False
        while time.monotonic() < deadline:
            try:
                with socket.create_connection((ep.host, ep.port), timeout=2):
                    connected = True
                    break
            except OSError:
                time.sleep(0.5)
        if not connected:
            raise HealthCheckError(ep.label, f"TCP port {ep.port} not ready after {timeout}s")
        # For HTTP endpoints, also wait until non-503 response
        if ep.service_type == ServiceType.HTTP:
            url = f"http://{ep.host}:{ep.port}/"
            http_ready = False
            while time.monotonic() < deadline:
                try:
                    resp = urllib.request.urlopen(url, timeout=3)
                    log.info(
                        "Service ready (HTTP)", label=ep.label, port=ep.port, status=resp.status
                    )
                    http_ready = True
                    break
                except urllib.error.HTTPError as e:
                    if e.code != 503:
                        http_ready = True
                        break  # non-503 means app is up (e.g. 403 = ready)
                    time.sleep(2)
                except Exception:
                    time.sleep(2)
            if not http_ready:
                raise HealthCheckError(ep.label, f"HTTP port {ep.port} not ready after {timeout}s")
