"""Translate container-local paths to host-resolvable paths for Docker bind mounts.

When the platform runs inside a Docker container and manages challenge
containers via the host Docker socket, bind-mount source paths must be
host-resolvable. This module rewrites in-container project-root paths to
the actual host project root.

Lives under ``docker_provider`` because this concern is Docker-specific —
bare-metal deployments leave ``host_project_root`` empty and this is a no-op.
"""

from __future__ import annotations

from pathlib import Path


def to_host_path(container_path: Path | str, *, host_project_root: str, project_root: Path) -> str:
    """Convert an in-process path to one the Docker daemon can resolve on the host.

    With ``host_project_root`` empty (bare-metal default) the input is
    returned unchanged. Otherwise paths under ``project_root`` are rewritten
    to start with ``host_project_root``.
    """
    if not host_project_root:
        return str(container_path)

    p = str(container_path)
    prefix = str(project_root)
    if p.startswith(prefix):
        return host_project_root.rstrip("/") + p[len(prefix) :]
    return p
