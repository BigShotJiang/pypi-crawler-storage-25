"""Shared Docker utilities for instance providers."""

from __future__ import annotations

import tempfile
import time
from pathlib import Path

import docker
import docker.errors
from pydantic import BaseModel

from lpb.core.config import LpbConfig
from lpb.core.log import log
from lpb.providers.docker_provider.paths import to_host_path

# ---------------------------------------------------------------------------
# Prefix used for all pentest Docker resources
# ---------------------------------------------------------------------------
PREFIX: str = "pentest"


# ---------------------------------------------------------------------------
# ProxySidecar — encapsulates attacker-net + mitmproxy proxy container
# ---------------------------------------------------------------------------


class ProxySidecarState(BaseModel):
    """Tracks proxy sidecar resources for cleanup."""

    container_name: str = ""
    attacker_network_name: str = ""
    proxy_gateway: str = ""
    cert_volume: str = ""
    proxy_output: str = ""
    proxy_output_external: bool = False


def compute_attacker_subnet(instance_id: str) -> tuple[str, str, str, str]:
    """Deterministic /28 subnet from instance_id hash.

    Returns (subnet, gateway, proxy_ip, atk_net_name).
    """
    slot = abs(hash(instance_id)) % 4000
    third_octet = slot // 16
    fourth_base = (slot % 16) * 16
    subnet = f"172.30.{third_octet}.{fourth_base}/28"
    gateway = f"172.30.{third_octet}.{fourth_base + 1}"
    proxy_ip = f"172.30.{third_octet}.{fourth_base + 2}"
    atk_net_name = f"{PREFIX}_{instance_id}_atk"
    return subnet, gateway, proxy_ip, atk_net_name


def start_proxy_sidecar(
    docker_client: docker.DockerClient,
    instance_id: str,
    target_network_name: str,
    service_names: list[str],
    *,
    config: LpbConfig,
    proxy_output_dir: Path | None = None,
) -> ProxySidecarState:
    """Start mitmproxy sidecar on target-net + create attacker-net.

    Returns a ProxySidecarState for later cleanup.
    """
    cert_vol = f"{PREFIX}_{instance_id}_certs"
    proxy_cname = f"{PREFIX}_{instance_id}_proxy"

    # Remove stale proxy container
    try:
        docker_client.containers.get(proxy_cname).remove(force=True)
    except docker.errors.NotFound:
        pass

    # Proxy output directory
    if proxy_output_dir:
        output_path = proxy_output_dir
        output_path.mkdir(parents=True, exist_ok=True)
        external = True
    else:
        output_path = Path(tempfile.mkdtemp(prefix="pentest_proxy_"))
        external = False
    output_path.chmod(0o777)

    # Create attacker network
    atk_subnet, atk_gateway, proxy_ip, atk_net_name = compute_attacker_subnet(instance_id)

    try:
        docker_client.networks.get(atk_net_name).remove()
    except docker.errors.NotFound:
        pass
    except Exception as e:
        log.warning("Failed to remove old atk network", network=atk_net_name, error=str(e))

    ipam = docker.types.IPAMConfig(
        pool_configs=[docker.types.IPAMPool(subnet=atk_subnet, gateway=atk_gateway)]
    )
    atk_net = docker_client.networks.create(atk_net_name, driver="bridge", ipam=ipam)

    # Start proxy container on target network
    proxy_container = docker_client.containers.run(
        config.image_mitmproxy,
        name=proxy_cname,
        detach=True,
        privileged=True,
        network=target_network_name,
        volumes={
            cert_vol: {"bind": "/home/mitmproxy/.mitmproxy", "mode": "rw"},
            to_host_path(
                output_path,
                host_project_root=config.host_project_root,
                project_root=config.project_root,
            ): {"bind": "/output", "mode": "rw"},
        },
    )

    # Reconnect with alias on target-net
    target_net = docker_client.networks.get(target_network_name)
    target_net.disconnect(proxy_container)
    target_net.connect(proxy_container, aliases=["proxy"])

    # Connect proxy to attacker-net with all target aliases
    target_aliases = list(service_names) + ["proxy"]
    atk_net.connect(proxy_container, ipv4_address=proxy_ip, aliases=target_aliases)

    # Wait for mitmproxy CA cert
    for _ in range(30):
        time.sleep(1)
        try:
            exit_code, _ = proxy_container.exec_run(
                "test -f /home/mitmproxy/.mitmproxy/mitmproxy-ca-cert.pem"
            )
            if exit_code == 0:
                break
        except Exception:
            pass

    return ProxySidecarState(
        container_name=proxy_cname,
        attacker_network_name=atk_net_name,
        proxy_gateway=proxy_ip,
        cert_volume=cert_vol,
        proxy_output=str(output_path),
        proxy_output_external=external,
    )


def cleanup_orphans(*, instances_dir: Path, client=None) -> int:
    """Remove all pentest_* containers, networks, and instance dirs from a previous run.

    Called on server startup to clean up instances that outlived the process.
    Returns the number of resources cleaned up.
    """
    import shutil

    if client is None:
        try:
            client = docker.from_env()
        except Exception:
            return 0

    cleaned = 0
    # Containers
    for c in client.containers.list(all=True, filters={"name": f"{PREFIX}_"}):
        try:
            log.info("Cleaning orphan container", name=c.name)
            c.remove(force=True)
            cleaned += 1
        except Exception as e:
            log.warning("Failed to remove orphan", name=c.name, error=str(e))

    # Networks
    for n in client.networks.list(names=[f"{PREFIX}_"]):
        if n.name in ("bridge", "host", "none"):
            continue
        try:
            log.info("Cleaning orphan network", name=n.name)
            for cid in list(n.attrs.get("Containers", {}).keys()):
                try:
                    n.disconnect(cid, force=True)
                except Exception:
                    pass
            n.remove()
            cleaned += 1
        except Exception as e:
            log.warning("Failed to remove orphan network", name=n.name, error=str(e))

    # Volumes
    for v in client.volumes.list(filters={"name": f"{PREFIX}_"}):
        try:
            log.info("Cleaning orphan volume", name=v.name)
            v.remove(force=True)
            cleaned += 1
        except Exception as e:
            log.warning("Failed to remove orphan volume", name=v.name, error=str(e))

    # Instance workdirs
    if instances_dir.is_dir():
        for d in instances_dir.iterdir():
            if d.is_dir():
                log.info("Cleaning orphan instance dir", path=str(d))
                try:
                    shutil.rmtree(d)
                except Exception as e:
                    log.warning("Failed to remove instance dir", path=str(d), error=str(e))
                cleaned += 1

    if cleaned:
        log.info("Orphan cleanup complete", cleaned=cleaned)
    return cleaned


def cleanup_containers(client, container_names: list[str]) -> None:
    """Force-remove containers, ignoring NotFound."""
    for name in container_names:
        try:
            client.containers.get(name).remove(force=True)
        except docker.errors.NotFound:
            pass
        except Exception as e:
            log.warning("Failed to remove container", container=name, error=str(e))


def cleanup_networks(client, network_names: list[str]) -> None:
    """Disconnect all endpoints and remove networks, ignoring NotFound."""
    for net_name in network_names:
        if not net_name:
            continue
        try:
            net = client.networks.get(net_name)
            net.reload()
            for cid in list(net.attrs.get("Containers", {}).keys()):
                try:
                    net.disconnect(cid, force=True)
                except Exception as e:
                    log.warning(
                        "Failed to disconnect container from network",
                        container=cid,
                        network=net_name,
                        error=str(e),
                    )
            net.remove()
        except docker.errors.NotFound:
            pass
        except Exception as e:
            log.warning("Failed to remove network", network=net_name, error=str(e))


def cleanup_volumes(client, volume_names: list[str]) -> None:
    """Remove volumes, ignoring NotFound."""
    for name in volume_names:
        if not name:
            continue
        try:
            client.volumes.get(name).remove()
        except docker.errors.NotFound:
            pass
        except Exception as e:
            log.warning("Failed to remove volume", volume=name, error=str(e))
