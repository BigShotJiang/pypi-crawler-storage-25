"""Shared HTTP client base for :mod:`lpb.sdk` clients.

Both :class:`~lpb.sdk.PlatformClient` and :class:`~lpb.sdk.NodeClient` open a
synchronous ``httpx.Client`` against a versioned base URL and want the same
retry-on-network-error behaviour. This module owns that surface so we don't
maintain it in two places.
"""

from __future__ import annotations

import time

import httpx

from lpb.core.constants import DEFAULT_CLIENT_TIMEOUT


class BaseHttpClient:
    """Sync httpx wrapper with bearer auth and exponential retry on transient errors."""

    def __init__(
        self,
        base_url: str,
        token: str = "",
        *,
        timeout: int = DEFAULT_CLIENT_TIMEOUT,
        max_retries: int = 3,
    ) -> None:
        headers = {"Authorization": f"Bearer {token}"} if token else {}
        self._client = httpx.Client(base_url=base_url, timeout=timeout, headers=headers)
        self._max_retries = max_retries

    def _request(self, method: str, path: str, **kwargs) -> httpx.Response:
        """Issue a request with exponential backoff on connect/timeout failures."""
        last_err: Exception | None = None
        for attempt in range(self._max_retries):
            try:
                return self._client.request(method, path, **kwargs)
            except (httpx.ConnectError, httpx.TimeoutException) as e:
                last_err = e
                if attempt < self._max_retries - 1:
                    time.sleep(1.0 * (2**attempt))
        assert last_err is not None
        raise last_err

    def close(self) -> None:
        self._client.close()

    def __enter__(self):
        return self

    def __exit__(self, *exc) -> None:
        self.close()
