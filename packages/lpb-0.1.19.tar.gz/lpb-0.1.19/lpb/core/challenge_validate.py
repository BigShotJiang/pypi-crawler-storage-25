"""Validation for challenge metadata shipped under benchmarks/.

This is the single source of truth for what counts as a well-formed
challenge. ``lpb challenge validate`` and the ``challenges.yml`` CI
workflow both dispatch here.

Rules, ordered from cheapest to strictest:

1. Directory is readable and contains ``metadata.yaml``.
2. The YAML parses.
3. It type-checks against :class:`lpb.core.challenge.ChallengeSpec`.
4. ``id`` matches the containing directory name.
5. The ID prefix (everything before the first ``-``) is in the registry
   of known benchmark origins.
6. ``provider`` is a known value (:class:`ProviderType`).
7. When ``strict=True`` and the provider is ``docker`` or ``cvebench``,
   the challenge directory contains a ``docker-compose.yml``. Off by
   default because ~70% of the current corpus ships without one; a
   follow-up cleanup PR will flip strict on globally.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import yaml
from pydantic import ValidationError

from lpb.core.challenge import ChallengeSpec
from lpb.core.enums import ProviderType

# Known challenge ID prefixes. Anything else fails validation.
# Add new benchmarks here in the same PR that imports them.
KNOWN_PREFIXES: frozenset[str] = frozenset(
    {
        "AUTOPENBENCH",
        "CVEBENCH",
        "CYBENCH",
        "DYNAMIC",
        "SNIPEROJ",
        "VULHUB",
        "XBOW",
    }
)


@dataclass(frozen=True)
class Finding:
    """One validation result."""

    challenge: str
    ok: bool
    reason: str = ""

    @property
    def status(self) -> str:
        return "OK" if self.ok else "FAIL"


def _prefix(challenge_id: str) -> str:
    return challenge_id.split("-", 1)[0] if "-" in challenge_id else challenge_id


def _validate_one(path: Path, *, strict: bool) -> Finding:
    name = path.name
    yml = path / "metadata.yaml"
    if not yml.exists():
        return Finding(name, False, "missing metadata.yaml")

    try:
        raw = yaml.safe_load(yml.read_text())
    except yaml.YAMLError as e:
        return Finding(name, False, f"YAML parse error: {e}")
    if not isinstance(raw, dict):
        return Finding(name, False, "metadata.yaml must be a mapping")

    try:
        spec = ChallengeSpec(**raw)
    except ValidationError as e:
        # First-line summary keeps reports scannable; operators can open
        # the file for full context if needed.
        msg = str(e).splitlines()[0]
        return Finding(name, False, f"schema: {msg}")

    if spec.id != name:
        return Finding(name, False, f"id {spec.id!r} != directory name {name!r}")

    prefix = _prefix(spec.id)
    if prefix not in KNOWN_PREFIXES:
        return Finding(
            name,
            False,
            f"unknown prefix {prefix!r} (allowed: {', '.join(sorted(KNOWN_PREFIXES))})",
        )

    try:
        ProviderType(spec.provider)
    except ValueError:
        return Finding(name, False, f"unknown provider {spec.provider!r}")

    # ``offline`` is declared in :class:`ProviderType` for metadata-load
    # compatibility (25 CYBENCH tasks ship with it) but has no runtime
    # factory in :class:`lpb.core.challenge.ChallengeManager`. Starting
    # such an instance through the node today raises ``ValueError:
    # Unknown provider: 'offline'`` deep inside the RPC, which surfaces
    # to the team as an opaque 500. Flagged under ``strict`` so the
    # default validate (which the ``challenges.yml`` CI workflow runs on
    # every PR) keeps passing for the legacy corpus while the ``--strict``
    # mode surfaces the broken challenges — operators opt into the
    # stricter gate when they're ready to migrate.
    if strict and spec.provider == ProviderType.OFFLINE:
        return Finding(
            name,
            False,
            "provider 'offline' has no runtime implementation — instance starts will fail. "
            "Either convert the challenge to a docker provider (add services + a Dockerfile) "
            "or register an OfflineProvider before re-enabling this spec.",
        )

    if strict and spec.provider in {ProviderType.DOCKER, ProviderType.CVEBENCH}:
        compose = path / "docker-compose.yml"
        if not compose.exists():
            return Finding(name, False, "missing docker-compose.yml (strict)")

    return Finding(name, True)


def validate_dir(
    challenges_dir: Path,
    *,
    challenge_id: str | None = None,
    strict: bool = False,
) -> list[Finding]:
    """Scan ``challenges_dir`` and return a :class:`Finding` per challenge.

    When ``challenge_id`` is set, only that challenge (by exact directory
    match) is validated. ``strict`` enables the docker-compose presence
    check.
    """
    if not challenges_dir.exists():
        return []

    findings: list[Finding] = []
    for d in sorted(challenges_dir.iterdir()):
        if not d.is_dir():
            continue
        if challenge_id and d.name != challenge_id:
            continue
        # Skip bookkeeping files like CLAUDE.md that share the parent dir.
        if not (d / "metadata.yaml").exists():
            continue
        findings.append(_validate_one(d, strict=strict))
    return findings
