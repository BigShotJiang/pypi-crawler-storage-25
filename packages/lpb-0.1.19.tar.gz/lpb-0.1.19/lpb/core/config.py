"""Framework configuration as a plain pydantic model.

Every knob is declared with a default + description so the CLI can mirror the
schema (``lpb server start --help``) and operators see the full surface in
one place. Validation runs at instantiation; filesystem existence is *not*
enforced so tests can build a config inside a tmpdir without scaffolding.

This module is pure data + validation. The CLI layer is responsible for
reading values from environment variables (via typer's ``envvar=``) and from
``.env`` files (via ``python-dotenv``); :class:`LpbConfig` itself never
touches ``os.environ`` or the filesystem.
"""

from __future__ import annotations

from pathlib import Path

from pydantic import BaseModel, Field, SecretStr, model_validator

from lpb.core.exceptions import ConfigError

_PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent

# Ephemeral port floor. Anything below 1024 would require root and is
# almost always a misconfiguration for a multi-tenant CTF platform.
_PORT_MIN = 1024
_PORT_MAX = 65535


class LpbConfig(BaseModel):
    """Single source of truth for runtime configuration.

    Constructed explicitly with keyword arguments — the CLI reads values from
    env / ``.env`` via typer's ``envvar=`` and hands them to this constructor.
    Field defaults double as the typer ``--xxx`` defaults, so changing a
    default here propagates to ``lpb server start --help`` automatically.
    """

    # --- Paths ---
    project_root: Path = Field(
        default=_PROJECT_ROOT,
        description="Repository root. Derived from the package location; rarely overridden.",
    )
    challenges_dir: Path = Field(
        default=_PROJECT_ROOT / "benchmarks",
        description="Directory containing challenge metadata.yaml files.",
    )
    instances_dir: Path = Field(
        default=_PROJECT_ROOT / "data" / "instances",
        description="Working directory for per-instance artefacts (flags, proxy output).",
    )

    # --- Host path translation (set when platform runs inside Docker) ---
    host_project_root: str = Field(
        default="",
        description=(
            "Host path that maps to the container's project root. Used to rewrite "
            "bind-mount sources when the node runs inside Docker. Leave empty on "
            "bare-metal deployments."
        ),
    )

    # --- Docker ---
    port_range_start: int = Field(
        default=30000,
        ge=_PORT_MIN,
        le=_PORT_MAX,
        description="Lowest host port the node may allocate for challenge services.",
    )
    port_range_end: int = Field(
        default=39999,
        ge=_PORT_MIN,
        le=_PORT_MAX,
        description="Highest host port (inclusive) the node may allocate.",
    )

    # --- Docker images ---
    image_mitmproxy: str = Field(
        default="pentest-mitmproxy",
        description="Image tag used for the per-instance mitmproxy sidecar.",
    )
    node_image: str = Field(
        default="ghcr.io/wangyihang/llm-pentest-benchmark-node:latest",
        description=(
            "Node Docker image advertised by ``lpb server invite``. Forks should "
            "override via ``--node-image`` / ``LPB_NODE_IMAGE`` to point at their own GHCR."
        ),
    )

    # --- Platform server ---
    platform_url: str = Field(
        default="",
        description=(
            "Platform base URL (e.g. http://server:8100) used by SDK/CLI/MCP "
            "clients and by nodes finding the platform."
        ),
    )
    server_host: str = Field(
        default="0.0.0.0",
        description="Bind address for ``lpb server start``.",
    )
    server_port: int = Field(
        default=8100,
        ge=1,
        le=_PORT_MAX,
        description="Bind port for ``lpb server start``.",
    )
    admin_token: SecretStr = Field(
        default=SecretStr(""),
        description=(
            "Admin bearer token. ``LPB_SERVER_API_KEY`` is accepted as a backward-compatible alias."
        ),
    )
    node_token: SecretStr = Field(
        default=SecretStr(""),
        description="Cluster token for platform↔node authentication.",
    )
    team_token: SecretStr = Field(
        default=SecretStr(""),
        description=(
            "Single-team CLI/MCP convenience token. Teams created via "
            "``POST /teams`` each receive their own token stored in the state "
            "backend — this setting is only used by ``lpb`` commands run as a "
            "team client."
        ),
    )

    # --- Traefik / subdomain routing ---
    traefik_enabled: bool = Field(
        default=False,
        description="Opt into HTTP_DOMAIN exposure (Docker-label legacy path).",
    )
    base_domain: str = Field(
        default="",
        description=(
            "Wildcard DNS base for http_domain challenges, e.g. ``bench.example.com`` "
            "or ``10.0.0.5.sslip.io``. Required when ``traefik_rules_path`` is set."
        ),
    )
    traefik_network: str = Field(
        default="pentest_traefik",
        description="Docker network that Traefik joins for label-based routing.",
    )
    traefik_rules_path: str = Field(
        default="",
        description=(
            "Path to a Traefik file-provider YAML the platform maintains for "
            "http_domain challenges. Empty disables the runtime integration; "
            "the Docker-label legacy path is unaffected."
        ),
    )

    # --- State backend ---
    redis_url: str = Field(
        default="",
        description="Redis connection URL, e.g. ``redis://localhost:6379/0``. Overrides SQLite.",
    )
    db_path: str = Field(
        default="",
        description="SQLite file path (default: ``{project_root}/data/platform.sqlite3``).",
    )

    @model_validator(mode="after")
    def _check_invariants(self) -> "LpbConfig":
        if self.port_range_start >= self.port_range_end:
            raise ConfigError(
                f"port_range_start ({self.port_range_start}) must be < "
                f"port_range_end ({self.port_range_end})"
            )
        if self.traefik_rules_path and not self.base_domain:
            raise ConfigError(
                "traefik_rules_path is set but base_domain is empty — "
                "http_domain routing needs a wildcard DNS base."
            )
        if self.platform_url and not self.platform_url.startswith(("http://", "https://")):
            raise ConfigError(
                f"platform_url must start with http:// or https:// (got: {self.platform_url!r})"
            )
        if self.redis_url and not self.redis_url.startswith(("redis://", "rediss://")):
            raise ConfigError(
                f"redis_url must start with redis:// or rediss:// (got: {self.redis_url!r})"
            )
        return self
