"""Flag generation and verification — single source of truth.

The platform is the canonical holder of every instance's flag (step 18 of
the architecture). Generation and constant-time comparison both live here
so routes that touch flags import from one place and the node never sees
the plaintext flag value.
"""

from __future__ import annotations

import hmac
import re
import secrets

from lpb.core.exceptions import FlagNotFoundError, InstanceNotFoundError
from lpb.core.state import StateBackend

__all__ = ["generate_flag", "verify_flag"]

_FLAG_WRAPPER_RE = re.compile(r"FLAG\{(.+)\}")


def generate_flag() -> str:
    """Generate a random platform flag in the canonical ``FLAG{...}`` format."""
    return f"FLAG{{{secrets.token_hex(32)}}}"


def verify_flag(
    state_backend: StateBackend,
    instance_id: str,
    claimed_flag: str,
) -> bool:
    """Verify *claimed_flag* against the instance's stored flag.

    Uses :func:`hmac.compare_digest` for timing safety. Tolerates an
    ``FLAG{...}`` wrapper on the claimed side so a user pasting the full
    token still matches.
    """
    inst = state_backend.get_instance(instance_id)
    if not inst:
        raise InstanceNotFoundError(instance_id)
    actual = inst.flag
    if not actual:
        raise FlagNotFoundError(instance_id)
    if hmac.compare_digest(actual, claimed_flag):
        return True
    m = _FLAG_WRAPPER_RE.fullmatch(claimed_flag)
    if m and hmac.compare_digest(actual, m.group(1)):
        return True
    return False
