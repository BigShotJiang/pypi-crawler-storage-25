"""Challenge manager — spec registry and provider dispatch.

ChallengeSpec is provider-agnostic: it carries universal metadata
(id, name, tags, hints, …) plus an opaque ``provider_config`` dict
that only the named provider knows how to interpret.
"""

from __future__ import annotations

import atexit
from pathlib import Path
from typing import Any, Callable, Iterator

import yaml
from pydantic import BaseModel, Field, ValidationError

from lpb.core.config import LpbConfig
from lpb.core.enums import ExposeType, ProviderType
from lpb.core.log import log
from lpb.core.models import HintLevel
from lpb.core.ports import PortAllocator
from lpb.core.provider import ChallengeProvider, StartResult


class ChallengeSpec(BaseModel):
    """Provider-agnostic challenge descriptor, parsed from metadata.yaml."""

    id: str
    name: str
    origin: str = ""
    category: str = ""
    difficulty: int = 1
    tags: list[str] = Field(default_factory=list)
    description: str = ""
    hint_levels: dict[str, HintLevel] = Field(default_factory=dict)

    # --- Provider routing ---
    provider: str = ProviderType.DOCKER
    provider_config: dict[str, Any] = Field(default_factory=dict)

    # --- Exposure strategy ---
    # tcp_port (default): users connect to <node_public_host>:<port> directly.
    # http_domain: platform routes traffic via Traefik subdomain (step 16
    # wires the runtime side; this field just declares intent).
    expose_type: str = ExposeType.TCP_PORT

    # --- Multi-instance support ---
    # When set, providers use this for container/network naming instead of id.
    # id is still used for build context directory lookup.
    instance_id: str = ""

    @property
    def effective_id(self) -> str:
        """ID used for container/network naming (unique per team+challenge)."""
        return self.instance_id or self.id

    @classmethod
    def from_yaml(cls, path: Path) -> ChallengeSpec:
        data = yaml.safe_load(path.read_text())
        return cls(**data)


class ChallengeManager:
    """Scans metadata.yaml specs and dispatches lifecycle to the right provider."""

    def __init__(self, config: LpbConfig, port_alloc: PortAllocator):
        self.config = config
        self.challenges_dir = config.challenges_dir
        self._port_alloc = port_alloc
        self._providers: dict[str, ChallengeProvider] = {}
        atexit.register(self.stop_all)

    # -- provider registry --------------------------------------------------

    def _get_provider(self, spec: ChallengeSpec) -> ChallengeProvider:
        ptype = spec.provider
        if ptype not in self._providers:
            self._providers[ptype] = self._create_provider(ptype)
        return self._providers[ptype]

    # Provider factory: factory_fn(config, port_alloc) -> ChallengeProvider
    _PROVIDER_FACTORIES: dict[str, Callable[[LpbConfig, PortAllocator], ChallengeProvider]] = {}

    @classmethod
    def register_provider(
        cls,
        name: str,
        factory: Callable[[LpbConfig, PortAllocator], ChallengeProvider],
    ) -> None:
        """Register a provider factory: ``factory(config, port_alloc) -> ChallengeProvider``."""
        cls._PROVIDER_FACTORIES[name] = factory

    def _create_provider(self, ptype: str) -> ChallengeProvider:
        """Create a backend provider. Only used inside the server.

        CLI/agents never call this directly — they go through HTTP.
        """
        if ptype not in self._PROVIDER_FACTORIES:
            self._register_builtin_providers()

        if ptype in self._PROVIDER_FACTORIES:
            return self._PROVIDER_FACTORIES[ptype](self.config, self._port_alloc)

        raise ValueError(f"Unknown provider: {ptype!r}")

    @classmethod
    def _register_builtin_providers(cls) -> None:
        """Register built-in providers lazily (breaks circular import)."""
        if ProviderType.DOCKER not in cls._PROVIDER_FACTORIES:
            from lpb.providers.docker_provider.provider import DockerProvider

            cls.register_provider(ProviderType.DOCKER, DockerProvider)

        if ProviderType.CVEBENCH not in cls._PROVIDER_FACTORIES:
            from lpb.providers.cvebench_provider.provider import CVEBenchProvider

            cls.register_provider(ProviderType.CVEBENCH, CVEBenchProvider)

    # -- enumeration --------------------------------------------------------

    def iter_specs(
        self,
        *,
        challenge_id: str | None = None,
        category: str | None = None,
        difficulty: int | None = None,
        tag: str | None = None,
        environment: str | None = None,
    ) -> Iterator[ChallengeSpec]:
        if not self.challenges_dir.exists():
            return
        for d in sorted(self.challenges_dir.iterdir()):
            yml = d / "metadata.yaml"
            if not d.is_dir() or not yml.exists():
                continue
            try:
                spec = ChallengeSpec.from_yaml(yml)
            except (ValidationError, yaml.YAMLError, OSError) as exc:
                # Schema / YAML / file-read failures only. Any other error
                # type is a bug and should surface, not get swallowed.
                log.warning("Skipping invalid challenge", challenge=d.name, error=str(exc))
                continue
            if challenge_id:
                patterns = [e.strip() for e in challenge_id.split(",")]
                if not any(spec.id == p or spec.id.startswith(p + "-") for p in patterns):
                    continue
            if category and spec.category != category:
                continue
            if difficulty is not None and spec.difficulty != difficulty:
                continue
            if tag and tag not in spec.tags:
                continue
            if environment:
                spec_env = spec.origin.split("/")[0].upper() if spec.origin else ""
                if spec_env != environment.upper():
                    continue
            yield spec

    # -- lifecycle (delegates to provider) ----------------------------------

    def start(self, spec: ChallengeSpec, *, proxy_output_dir: Path | None = None) -> StartResult:
        """Start instance. Returns StartResult (surface + flag, server-side only)."""
        return self._get_provider(spec).start(spec, proxy_output_dir=proxy_output_dir)

    def verify_flag(self, spec: ChallengeSpec, claimed_flag: str) -> bool:
        """Verify a candidate flag against the real flag. Never exposes the flag."""
        return self._get_provider(spec).verify_flag(spec.id, claimed_flag)

    def stop(self, spec: ChallengeSpec) -> None:
        self._get_provider(spec).stop(spec)

    def check_health(self, instance_id: str) -> bool:
        """Check if an instance's containers are all running."""
        for provider in self._providers.values():
            if provider.check_health(instance_id):
                return True
        return False

    def get_sandbox_network(self, instance_id: str) -> tuple[str, str] | None:
        """Return (attacker_network_name, proxy_gateway_ip) for sandbox."""
        for provider in self._providers.values():
            result = provider.get_sandbox_network(instance_id)
            if result:
                return result
        return None

    def get_cert_volume(self, instance_id: str) -> str:
        """Return the Docker volume name containing mitmproxy CA certs."""
        for provider in self._providers.values():
            result = provider.get_cert_volume(instance_id)
            if result:
                return result
        return ""

    def get_proxy_output(self, instance_id: str) -> Path | None:
        """Return path to mitmproxy traffic output directory, if available."""
        for provider in self._providers.values():
            result = provider.get_proxy_output(instance_id)
            if result:
                return result
        return None

    def stop_all(self) -> None:
        for provider in self._providers.values():
            provider.stop_all()
