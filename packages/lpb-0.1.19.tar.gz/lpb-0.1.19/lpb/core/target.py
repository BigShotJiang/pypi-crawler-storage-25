"""Standardized target description for AI pentest agents."""

from __future__ import annotations

from enum import Enum

from pydantic import Field

from lpb.core.models import LpbModel


class ServiceType(str, Enum):
    SSH = "ssh"
    HTTP = "http"
    HTTPS = "https"
    TCP = "tcp"


class Credential(LpbModel):
    username: str
    password: str | None = None
    key_file: str | None = None


class ServiceEndpoint(LpbModel):
    """One reachable service on the target."""

    service_type: ServiceType
    host: str
    port: int
    credentials: Credential | None = None
    path: str = "/"
    label: str = ""
    subdomain_url: str = ""

    @property
    def url(self) -> str:
        if self.service_type == ServiceType.TCP:
            return f"{self.host}:{self.port}"
        base = f"{self.service_type.value}://{self.host}:{self.port}"
        if self.path and self.path != "/":
            return f"{base}{self.path}"
        return base

    @property
    def display_url(self) -> str:
        """Prefer subdomain URL when available, fall back to host:port."""
        return self.subdomain_url or self.url


class AttackSurface(LpbModel):
    """Agent-agnostic description of what can be attacked.

    Every agent receives this; each agent picks the services it needs.
    """

    services: list[ServiceEndpoint] = Field(default_factory=list)
    provided_files: list[str] = Field(default_factory=list)
    flag_path: str | None = None

    def get_service(self, stype: ServiceType, label: str = "") -> ServiceEndpoint | None:
        for s in self.services:
            if s.service_type == stype and (not label or s.label == label):
                return s
        return None

    def get_ssh(self) -> ServiceEndpoint | None:
        return self.get_service(ServiceType.SSH)

    def get_http(self) -> ServiceEndpoint | None:
        return self.get_service(ServiceType.HTTP) or self.get_service(ServiceType.HTTPS)

    @classmethod
    def from_dict(cls, raw: dict) -> "AttackSurface":
        """Parse an attack_surface dict (e.g. from JSON API response)."""
        services = [ServiceEndpoint(**s) for s in raw.get("services", [])]
        return cls(
            services=services,
            provided_files=raw.get("provided_files", []),
            flag_path=raw.get("flag_path"),
        )


def first_http_endpoint_url(surface: AttackSurface) -> str:
    """Return the base URL of the first HTTP(S) service in *surface*.

    Path is intentionally omitted so callers (e.g. Traefik upserts) always
    get a Host-style target URL. Returns an empty string when no HTTP
    service is present.
    """
    for svc in surface.services:
        if svc.service_type in (ServiceType.HTTP, ServiceType.HTTPS) and svc.host and svc.port:
            return f"{svc.service_type.value}://{svc.host}:{svc.port}"
    return ""
