"""Shared data models used across server, SDK, and MCP."""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field

__all__ = ["HintLevel", "LpbModel"]


class LpbModel(BaseModel):
    """Project-wide Pydantic base.

    The one config tweak: ``json_schema_serialization_defaults_required=True``.

    By default Pydantic treats "has a default" as "optional in the JSON
    Schema", which makes every frontend type generated from our OpenAPI
    doc become ``field?: T``. But at serialization time these fields are
    always present (the default fills in), so the client never legitimately
    sees ``undefined``. Marking them ``required`` in the schema gives the
    frontend accurate non-optional types without forcing the backend to
    drop sensible defaults.
    """

    model_config = ConfigDict(json_schema_serialization_defaults_required=True)


class HintLevel(LpbModel):
    """Structured hint at a specific verbosity level."""

    description: str = ""
    show_flag_path: bool = False
    target_service: str = ""
    vulnerability_type: str = ""
    exploitation_steps: list[str] = Field(default_factory=list)
