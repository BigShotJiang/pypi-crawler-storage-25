"""Domain-specific exceptions for the LLM Pentest Benchmark platform.

These exceptions decouple business logic from HTTP status codes.
Map them to HTTP errors at the API layer via FastAPI exception handlers.
"""

from __future__ import annotations


class PlatformError(Exception):
    """Base exception for all platform errors.

    Direct subclasses carve the failure space along the subsystem that
    produced the error (config / state / provider / challenge / auth /
    …). Concrete errors inherit from one of those so catchers can pick
    the right granularity::

        try:
            ...
        except StateError:     # any backend issue
            ...
        except PlatformError:  # anything else platform-level
            ...

    Never catch bare ``Exception`` inside lpb — extend this tree instead
    (see ``ruff`` rule ``BLE001``, planned to flip on in a follow-up).
    """


class ConfigError(PlatformError):
    """Raised when the effective configuration is unusable.

    Use this for missing credentials, unparseable env values, or paths
    that cannot be reached. The CLI surfaces these with exit code 2.
    """


class StateError(PlatformError):
    """Raised when a state backend (SQLite / Redis / in-memory) fails.

    Applies to connect / read / write / schema-migration failures. Fallback
    to InMemoryBackend is an explicit decision logged at the call site,
    not a silent ``except Exception``.
    """


class ChallengeError(PlatformError):
    """Raised when a challenge asset in ``benchmarks/`` is malformed.

    Covers unreadable metadata.yaml, schema violations, and missing
    supporting files (compose, services). ``lpb challenge validate``
    is the canonical producer.
    """


# ---------------------------------------------------------------------------
# Instance lifecycle
# ---------------------------------------------------------------------------


class InstanceNotFoundError(PlatformError):
    """Raised when an instance lookup fails."""

    def __init__(self, instance_id: str) -> None:
        self.instance_id = instance_id
        super().__init__(f"Instance {instance_id} not found")


class InstanceStartError(PlatformError):
    """Raised when an instance fails to start."""

    def __init__(self, instance_id: str, reason: str) -> None:
        self.instance_id = instance_id
        self.reason = reason
        super().__init__(f"Instance {instance_id} failed to start: {reason}")


# ---------------------------------------------------------------------------
# Challenge / Team lookup
# ---------------------------------------------------------------------------


class ChallengeNotFoundError(PlatformError):
    """Raised when a challenge lookup fails."""

    def __init__(self, challenge_id: str) -> None:
        self.challenge_id = challenge_id
        super().__init__(f"Challenge {challenge_id} not found")


class InstanceAlreadyRunningError(PlatformError):
    """Raised when trying to start a challenge that already has a running instance."""

    def __init__(self, challenge_id: str, team_id: str = "") -> None:
        self.challenge_id = challenge_id
        self.team_id = team_id
        super().__init__(f"Instance for challenge {challenge_id} already running")


class TeamNotFoundError(PlatformError):
    """Raised when a team lookup fails."""

    def __init__(self, team_id: str) -> None:
        self.team_id = team_id
        super().__init__(f"Team {team_id} not found")


# ---------------------------------------------------------------------------
# Capacity & rate limiting
# ---------------------------------------------------------------------------


class CapacityExceededError(PlatformError):
    """Raised when the platform or team has hit a resource limit."""

    def __init__(self, message: str) -> None:
        super().__init__(message)


class RateLimitError(PlatformError):
    """Raised when a client exceeds the submission rate limit."""

    def __init__(self, message: str) -> None:
        super().__init__(message)


# ---------------------------------------------------------------------------
# Flag verification
# ---------------------------------------------------------------------------


class FlagNotFoundError(PlatformError):
    """Raised when no flag is stored for an instance."""

    def __init__(self, instance_id: str) -> None:
        self.instance_id = instance_id
        super().__init__(f"No flag stored for instance {instance_id}")


# ---------------------------------------------------------------------------
# Provider
# ---------------------------------------------------------------------------


class ProviderError(PlatformError):
    """Raised when a provider operation fails."""


class HealthCheckError(ProviderError):
    """Raised when a Docker health check fails."""

    def __init__(self, service: str, reason: str) -> None:
        self.service = service
        self.reason = reason
        super().__init__(f"Health check failed for {service}: {reason}")


class TraefikRouteError(ProviderError):
    """Raised when the Traefik file-provider rule file can't be updated.

    Distinct from generic ``OSError`` so the platform-level exception
    handler can decide whether to mark an instance as ERROR vs. retry vs.
    tear down the node-side container.
    """


# ---------------------------------------------------------------------------
# Auth
# ---------------------------------------------------------------------------


class NotAuthorizedError(PlatformError):
    """Raised when a request lacks valid credentials."""

    def __init__(self, message: str = "Not authorized") -> None:
        super().__init__(message)


class ForbiddenError(PlatformError):
    """Raised when a request is authenticated but not permitted."""

    def __init__(self, message: str = "Forbidden") -> None:
        super().__init__(message)
