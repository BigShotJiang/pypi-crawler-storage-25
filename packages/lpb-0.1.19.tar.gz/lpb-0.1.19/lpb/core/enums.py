"""Shared enums — single source of truth for status values, event types, and constants."""

from __future__ import annotations

from enum import Enum


class InstanceStatus(str, Enum):
    """Lifecycle status of a challenge instance."""

    STARTING = "starting"
    READY = "ready"
    ERROR = "error"
    STOPPED = "stopped"


class PlatformEvent(str, Enum):
    """Events emitted by the platform (SSE broadcast + activity log)."""

    INSTANCE_STARTED = "instance_started"
    INSTANCE_READY = "instance_ready"
    INSTANCE_ERROR = "instance_error"
    INSTANCE_STOPPED = "instance_stopped"
    FLAG_CORRECT = "flag_correct"
    FLAG_WRONG = "flag_wrong"
    TEAM_REGISTERED = "team_registered"
    INSTANCE_RENEWED = "instance_renewed"
    NODE_REGISTERED = "node_registered"
    NODE_UNHEALTHY = "node_unhealthy"
    NODE_REMOVED = "node_removed"


class ProviderType(str, Enum):
    """Challenge provider types."""

    DOCKER = "docker"
    CVEBENCH = "cvebench"
    # `offline` means "no runtime container — the agent only needs the
    # files shipped under the challenge directory." Used by 25 CYBENCH
    # tasks today. Accepted by validate + stored in metadata; the runtime
    # rejects instance starts until a provider is registered for it.
    OFFLINE = "offline"


class ExposeType(str, Enum):
    """How a challenge instance is exposed to end users.

    - ``TCP_PORT`` (default): return the node's public host and the port
      Docker mapped. Safest default — no HTTP rewriting, works for nc/pwn,
      HTTP-smuggling Web challenges, UDP, TLS with custom SNI, etc.
    - ``HTTP_DOMAIN``: route through the platform's Traefik gateway using
      a per-instance subdomain. Opt-in; only valid for "normal" HTTP Web
      challenges that don't rely on exotic HTTP parsing.
    """

    TCP_PORT = "tcp_port"
    HTTP_DOMAIN = "http_domain"
