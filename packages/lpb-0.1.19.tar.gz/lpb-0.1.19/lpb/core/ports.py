"""Port allocation using google/portpicker — safe for parallel use."""

from __future__ import annotations

import portpicker


class PortAllocator:
    """Allocates unique host ports using portpicker (OS-level atomic allocation)."""

    def __init__(self, start: int = 30000, end: int = 39999):
        # start/end kept for API compat but portpicker picks from OS free ports
        self._allocated: dict[str, int] = {}

    def allocate(self, key: str) -> int:
        if key in self._allocated:
            return self._allocated[key]
        port = portpicker.pick_unused_port()
        self._allocated[key] = port
        return port

    def release(self, key: str) -> None:
        port = self._allocated.pop(key, None)
        if port is not None:
            portpicker.return_port(port)

    def release_all(self) -> None:
        for port in self._allocated.values():
            portpicker.return_port(port)
        self._allocated.clear()
