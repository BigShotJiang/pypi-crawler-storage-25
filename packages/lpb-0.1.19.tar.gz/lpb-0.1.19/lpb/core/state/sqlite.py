"""SQLiteBackend — SQLite-backed state backend."""

from __future__ import annotations

import json
import threading
import time

from lpb.core.state.models import (
    ActivityState,
    InstanceState,
    NodeState,
    SolveState,
    SubmissionState,
    TeamState,
)


class SQLiteBackend:
    """SQLite-backed state. Persistent across restarts.

    Instances (ephemeral) are kept in memory. Everything else
    (teams, submissions, solves, activities) is stored in SQLite.
    """

    def __init__(self, db_path: str) -> None:
        import sqlite3

        self._db_path = db_path
        self._conn = sqlite3.connect(db_path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._lock = threading.Lock()
        self._instances: dict[str, InstanceState] = {}
        self._init_tables()
        self._migrate()

    def _init_tables(self) -> None:
        with self._conn:
            self._conn.executescript("""
                CREATE TABLE IF NOT EXISTS config (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS nodes (
                    node_id TEXT PRIMARY KEY,
                    data TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS teams (
                    team_id TEXT PRIMARY KEY,
                    token TEXT NOT NULL DEFAULT '',
                    data TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS submissions (
                    submission_id TEXT PRIMARY KEY,
                    team_id TEXT NOT NULL,
                    challenge_id TEXT NOT NULL,
                    data TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_sub_team
                    ON submissions(team_id);
                CREATE INDEX IF NOT EXISTS idx_sub_challenge
                    ON submissions(challenge_id);
                CREATE TABLE IF NOT EXISTS solves (
                    team_id TEXT NOT NULL,
                    challenge_id TEXT NOT NULL,
                    data TEXT NOT NULL,
                    PRIMARY KEY (team_id, challenge_id)
                );
                CREATE TABLE IF NOT EXISTS activities (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT NOT NULL,
                    event TEXT NOT NULL,
                    team_id TEXT NOT NULL DEFAULT '',
                    challenge_id TEXT NOT NULL DEFAULT '',
                    data TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_act_team
                    ON activities(team_id);
                CREATE INDEX IF NOT EXISTS idx_act_event
                    ON activities(event);
            """)

    def _migrate(self) -> None:
        """Apply in-place schema migrations for older DB files."""
        cols = {r[1] for r in self._conn.execute("PRAGMA table_info(teams)")}
        # Old DBs may have an `api_key` column with no `token` — rename.
        if "api_key" in cols and "token" not in cols:
            with self._conn:
                self._conn.execute("ALTER TABLE teams RENAME COLUMN api_key TO token")
            cols = {r[1] for r in self._conn.execute("PRAGMA table_info(teams)")}
        # Very old DBs may have neither — add token, backfill from JSON data.
        if "token" not in cols:
            with self._conn:
                self._conn.execute("ALTER TABLE teams ADD COLUMN token TEXT NOT NULL DEFAULT ''")
                for row in self._conn.execute("SELECT team_id, data FROM teams"):
                    if row[1]:
                        team = json.loads(row[1])
                        tok = team.get("token") or team.get("api_key") or ""
                        if tok:
                            self._conn.execute(
                                "UPDATE teams SET token = ? WHERE team_id = ?", (tok, row[0])
                            )
        # Drop any legacy index; create the canonical one.
        with self._conn:
            self._conn.execute("DROP INDEX IF EXISTS idx_team_api_key")
            self._conn.execute("CREATE INDEX IF NOT EXISTS idx_team_token ON teams(token)")

    # -- instance (in-memory, ephemeral) ------------------------------------

    def put_instance(self, instance_id: str, data: InstanceState, ttl: int = 0) -> None:
        now = time.time()
        data = data.model_copy(
            update={
                "started_at": data.started_at or now,
                "ttl": ttl,
                "expires_at": (now + ttl) if ttl > 0 else 0.0,
            }
        )
        with self._lock:
            self._instances[instance_id] = data

    def get_instance(self, instance_id: str) -> InstanceState | None:
        with self._lock:
            return self._instances.get(instance_id)

    def remove_instance(self, instance_id: str) -> InstanceState | None:
        with self._lock:
            return self._instances.pop(instance_id, None)

    def list_instances(self) -> list[InstanceState]:
        with self._lock:
            return [v.model_copy(update={"instance_id": k}) for k, v in self._instances.items()]

    def count_instances(self) -> int:
        with self._lock:
            return len(self._instances)

    def renew_instance(self, instance_id: str, ttl: int) -> float:
        now = time.time()
        expires_at = (now + ttl) if ttl > 0 else 0.0
        with self._lock:
            inst = self._instances.get(instance_id)
            if inst is None:
                raise KeyError(instance_id)
            self._instances[instance_id] = inst.model_copy(
                update={"ttl": ttl, "expires_at": expires_at}
            )
        return expires_at

    def pop_expired_instances(self) -> list[InstanceState]:
        now = time.time()
        expired = []
        with self._lock:
            for sid in list(self._instances):
                inst = self._instances[sid]
                if inst.expires_at and now >= inst.expires_at:
                    expired.append(self._instances.pop(sid).model_copy(update={"instance_id": sid}))
        return expired

    def get_instance_by_team_challenge(
        self, team_id: str, challenge_id: str
    ) -> InstanceState | None:
        with self._lock:
            for instance_id, inst in self._instances.items():
                if inst.team_id == team_id and inst.challenge_id == challenge_id:
                    return inst.model_copy(update={"instance_id": instance_id})
        return None

    # -- config (SQLite) ----------------------------------------------------

    def get_config(self, key: str) -> str | None:
        row = self._conn.execute("SELECT value FROM config WHERE key = ?", (key,)).fetchone()
        return row[0] if row else None

    def set_config(self, key: str, value: str) -> None:
        with self._conn:
            self._conn.execute(
                "INSERT OR REPLACE INTO config (key, value) VALUES (?, ?)", (key, value)
            )

    # -- nodes (SQLite) -----------------------------------------------------

    def put_node(self, node_id: str, data: NodeState) -> None:
        data = data.model_copy(update={"node_id": node_id})
        with self._conn:
            self._conn.execute(
                "INSERT OR REPLACE INTO nodes (node_id, data) VALUES (?, ?)",
                (node_id, data.model_dump_json()),
            )

    def get_node(self, node_id: str) -> NodeState | None:
        row = self._conn.execute("SELECT data FROM nodes WHERE node_id = ?", (node_id,)).fetchone()
        return NodeState.model_validate_json(row[0]) if row else None

    def list_nodes(self) -> list[NodeState]:
        return [
            NodeState.model_validate_json(row[0])
            for row in self._conn.execute("SELECT data FROM nodes")
        ]

    def remove_node(self, node_id: str) -> None:
        with self._conn:
            self._conn.execute("DELETE FROM nodes WHERE node_id = ?", (node_id,))

    # -- teams (SQLite) -----------------------------------------------------

    def put_team(self, team_id: str, data: TeamState) -> None:
        data = data.model_copy(update={"team_id": team_id})
        with self._conn:
            self._conn.execute(
                "INSERT OR REPLACE INTO teams (team_id, token, data) VALUES (?, ?, ?)",
                (team_id, data.token, data.model_dump_json()),
            )

    def get_team(self, team_id: str) -> TeamState | None:
        row = self._conn.execute("SELECT data FROM teams WHERE team_id = ?", (team_id,)).fetchone()
        return TeamState.model_validate_json(row[0]) if row else None

    def get_team_by_token(self, token: str) -> TeamState | None:
        row = self._conn.execute("SELECT data FROM teams WHERE token = ?", (token,)).fetchone()
        return TeamState.model_validate_json(row[0]) if row and row[0] else None

    def list_teams(self) -> list[TeamState]:
        return [
            TeamState.model_validate_json(row[0])
            for row in self._conn.execute("SELECT data FROM teams")
        ]

    # -- submissions (SQLite) -----------------------------------------------

    def add_submission(self, data: SubmissionState) -> None:
        with self._conn:
            self._conn.execute(
                "INSERT INTO submissions (submission_id, team_id, challenge_id, data) "
                "VALUES (?, ?, ?, ?)",
                (data.submission_id, data.team_id, data.challenge_id, data.model_dump_json()),
            )

    def list_submissions(self, team_id: str = "", challenge_id: str = "") -> list[SubmissionState]:
        sql = "SELECT data FROM submissions WHERE 1=1"
        params: list = []
        if team_id:
            sql += " AND team_id = ?"
            params.append(team_id)
        if challenge_id:
            sql += " AND challenge_id = ?"
            params.append(challenge_id)
        return [
            SubmissionState.model_validate_json(row[0]) for row in self._conn.execute(sql, params)
        ]

    # -- solves (SQLite) ----------------------------------------------------

    def add_solve(self, team_id: str, challenge_id: str, data: SolveState) -> None:
        data = data.model_copy(update={"team_id": team_id, "challenge_id": challenge_id})
        with self._conn:
            self._conn.execute(
                "INSERT OR IGNORE INTO solves (team_id, challenge_id, data) VALUES (?, ?, ?)",
                (team_id, challenge_id, data.model_dump_json()),
            )

    def get_solve(self, team_id: str, challenge_id: str) -> SolveState | None:
        row = self._conn.execute(
            "SELECT data FROM solves WHERE team_id = ? AND challenge_id = ?",
            (team_id, challenge_id),
        ).fetchone()
        return SolveState.model_validate_json(row[0]) if row else None

    def list_solves(self, team_id: str = "") -> list[SolveState]:
        if team_id:
            rows = self._conn.execute("SELECT data FROM solves WHERE team_id = ?", (team_id,))
        else:
            rows = self._conn.execute("SELECT data FROM solves")
        return [SolveState.model_validate_json(row[0]) for row in rows]

    def count_solves_for_challenge(self, challenge_id: str) -> int:
        row = self._conn.execute(
            "SELECT COUNT(*) FROM solves WHERE challenge_id = ?", (challenge_id,)
        ).fetchone()
        return row[0] if row else 0

    # -- activity log (SQLite) ----------------------------------------------

    def add_activity(self, data: ActivityState) -> None:
        with self._conn:
            self._conn.execute(
                "INSERT INTO activities (timestamp, event, team_id, challenge_id, data) "
                "VALUES (?, ?, ?, ?, ?)",
                (
                    data.timestamp,
                    data.event,
                    data.team_id,
                    data.challenge_id,
                    data.model_dump_json(),
                ),
            )

    def _activity_where(
        self, *, team_id: str = "", challenge_id: str = "", event: str = ""
    ) -> tuple[str, list]:
        clauses = "WHERE 1=1"
        params: list = []
        if team_id:
            clauses += " AND team_id = ?"
            params.append(team_id)
        if challenge_id:
            clauses += " AND challenge_id = ?"
            params.append(challenge_id)
        if event:
            clauses += " AND event = ?"
            params.append(event)
        return clauses, params

    def list_activities(
        self,
        *,
        team_id: str = "",
        challenge_id: str = "",
        event: str = "",
        offset: int = 0,
        limit: int = 100,
    ) -> list[ActivityState]:
        where, params = self._activity_where(
            team_id=team_id, challenge_id=challenge_id, event=event
        )
        sql = f"SELECT data FROM activities {where} ORDER BY id DESC LIMIT ? OFFSET ?"
        params += [limit, offset]
        return [
            ActivityState.model_validate_json(row[0]) for row in self._conn.execute(sql, params)
        ]

    def count_activities(
        self, *, team_id: str = "", challenge_id: str = "", event: str = ""
    ) -> int:
        where, params = self._activity_where(
            team_id=team_id, challenge_id=challenge_id, event=event
        )
        sql = f"SELECT COUNT(*) FROM activities {where}"
        return self._conn.execute(sql, params).fetchone()[0]
