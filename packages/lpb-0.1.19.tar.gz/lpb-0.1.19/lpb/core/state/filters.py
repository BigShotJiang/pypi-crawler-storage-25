"""Pure predicates used by in-memory state backends.

Memory and Redis backends fetch records into Python lists and filter them
client-side, so they share these predicates. SQLite expresses the same
filters as ``WHERE`` clauses and does not import this module.
"""

from __future__ import annotations

from lpb.core.state.models import ActivityState, SubmissionState


def match_activity(
    a: ActivityState, *, team_id: str = "", challenge_id: str = "", event: str = ""
) -> bool:
    """True if *a* satisfies every non-empty filter."""
    if team_id and a.team_id != team_id:
        return False
    if challenge_id and a.challenge_id != challenge_id:
        return False
    if event and a.event != event:
        return False
    return True


def match_submission(s: SubmissionState, *, team_id: str = "", challenge_id: str = "") -> bool:
    """True if *s* satisfies every non-empty filter."""
    if team_id and s.team_id != team_id:
        return False
    if challenge_id and s.challenge_id != challenge_id:
        return False
    return True
