"""InMemoryBackend — thread-safe in-memory state backend."""

from __future__ import annotations

import threading
import time

from lpb.core.enums import InstanceStatus
from lpb.core.state.filters import match_activity, match_submission
from lpb.core.state.models import (
    ActivityState,
    InstanceState,
    NodeState,
    SolveState,
    SubmissionState,
    TeamState,
)


class InMemoryBackend:
    """Thread-safe in-memory backend. Suitable for single-process use."""

    def __init__(self) -> None:
        self._instances: dict[str, InstanceState] = {}
        self._nodes: dict[str, NodeState] = {}
        self._teams: dict[str, TeamState] = {}
        self._team_tokens: dict[str, str] = {}
        self._submissions: list[SubmissionState] = []
        self._solves: dict[tuple[str, str], SolveState] = {}
        self._activities: list[ActivityState] = []
        self._config: dict[str, str] = {}
        self._lock = threading.Lock()

    # -- instance -----------------------------------------------------------

    def put_instance(self, instance_id: str, data: InstanceState, ttl: int = 0) -> None:
        now = time.time()
        status = data.status
        if status == InstanceStatus.READY:
            started_at = now
            expires_at = (now + ttl) if ttl > 0 else 0.0
        elif status == InstanceStatus.STARTING:
            started_at = 0.0
            expires_at = 0.0
        else:
            started_at = data.started_at
            expires_at = data.expires_at
        data = data.model_copy(
            update={"started_at": started_at, "ttl": ttl, "expires_at": expires_at}
        )
        with self._lock:
            self._instances[instance_id] = data

    def get_instance(self, instance_id: str) -> InstanceState | None:
        with self._lock:
            inst = self._instances.get(instance_id)
            return inst.model_copy() if inst is not None else None

    def remove_instance(self, instance_id: str) -> InstanceState | None:
        with self._lock:
            return self._instances.pop(instance_id, None)

    def list_instances(self) -> list[InstanceState]:
        with self._lock:
            return [v.model_copy(update={"instance_id": k}) for k, v in self._instances.items()]

    def count_instances(self) -> int:
        with self._lock:
            return len(self._instances)

    def renew_instance(self, instance_id: str, ttl: int) -> float:
        now = time.time()
        expires_at = (now + ttl) if ttl > 0 else 0.0
        with self._lock:
            inst = self._instances.get(instance_id)
            if inst is None:
                raise KeyError(instance_id)
            self._instances[instance_id] = inst.model_copy(
                update={"ttl": ttl, "expires_at": expires_at}
            )
        return expires_at

    def pop_expired_instances(self) -> list[InstanceState]:
        now = time.time()
        expired = []
        with self._lock:
            for sid in list(self._instances):
                inst = self._instances[sid]
                if inst.expires_at and now >= inst.expires_at:
                    expired.append(self._instances.pop(sid).model_copy(update={"instance_id": sid}))
        return expired

    def get_instance_by_team_challenge(
        self, team_id: str, challenge_id: str
    ) -> InstanceState | None:
        with self._lock:
            for instance_id, inst in self._instances.items():
                if inst.team_id == team_id and inst.challenge_id == challenge_id:
                    return inst.model_copy(update={"instance_id": instance_id})
        return None

    # -- config --------------------------------------------------------------

    def get_config(self, key: str) -> str | None:
        with self._lock:
            return self._config.get(key)

    def set_config(self, key: str, value: str) -> None:
        with self._lock:
            self._config[key] = value

    # -- nodes ---------------------------------------------------------------

    def put_node(self, node_id: str, data: NodeState) -> None:
        with self._lock:
            self._nodes[node_id] = data.model_copy(update={"node_id": node_id})

    def get_node(self, node_id: str) -> NodeState | None:
        with self._lock:
            node = self._nodes.get(node_id)
            return node.model_copy() if node is not None else None

    def list_nodes(self) -> list[NodeState]:
        with self._lock:
            return [v.model_copy() for v in self._nodes.values()]

    def remove_node(self, node_id: str) -> None:
        with self._lock:
            self._nodes.pop(node_id, None)

    # -- teams ---------------------------------------------------------------

    def put_team(self, team_id: str, data: TeamState) -> None:
        with self._lock:
            data = data.model_copy(update={"team_id": team_id})
            self._teams[team_id] = data
            if data.token:
                self._team_tokens[data.token] = team_id

    def get_team(self, team_id: str) -> TeamState | None:
        with self._lock:
            team = self._teams.get(team_id)
            return team.model_copy() if team is not None else None

    def get_team_by_token(self, token: str) -> TeamState | None:
        with self._lock:
            team_id = self._team_tokens.get(token)
            if team_id:
                team = self._teams.get(team_id)
                return team.model_copy() if team is not None else None
            return None

    def list_teams(self) -> list[TeamState]:
        with self._lock:
            return [v.model_copy() for v in self._teams.values()]

    # -- submissions ---------------------------------------------------------

    def add_submission(self, data: SubmissionState) -> None:
        with self._lock:
            self._submissions.append(data)

    def list_submissions(self, team_id: str = "", challenge_id: str = "") -> list[SubmissionState]:
        with self._lock:
            return [
                s.model_copy()
                for s in self._submissions
                if match_submission(s, team_id=team_id, challenge_id=challenge_id)
            ]

    # -- solves --------------------------------------------------------------

    def add_solve(self, team_id: str, challenge_id: str, data: SolveState) -> None:
        key = (team_id, challenge_id)
        with self._lock:
            if key not in self._solves:
                self._solves[key] = data.model_copy(
                    update={"team_id": team_id, "challenge_id": challenge_id}
                )

    def get_solve(self, team_id: str, challenge_id: str) -> SolveState | None:
        with self._lock:
            solve = self._solves.get((team_id, challenge_id))
            return solve.model_copy() if solve is not None else None

    def list_solves(self, team_id: str = "") -> list[SolveState]:
        with self._lock:
            if team_id:
                return [v.model_copy() for k, v in self._solves.items() if k[0] == team_id]
            return [v.model_copy() for v in self._solves.values()]

    def count_solves_for_challenge(self, challenge_id: str) -> int:
        with self._lock:
            return sum(1 for k in self._solves if k[1] == challenge_id)

    # -- activity log -------------------------------------------------------

    def add_activity(self, data: ActivityState) -> None:
        with self._lock:
            self._activities.append(data)

    def _filter_activities(
        self, *, team_id: str = "", challenge_id: str = "", event: str = ""
    ) -> list[ActivityState]:
        return [
            a
            for a in reversed(self._activities)
            if match_activity(a, team_id=team_id, challenge_id=challenge_id, event=event)
        ]

    def list_activities(
        self,
        *,
        team_id: str = "",
        challenge_id: str = "",
        event: str = "",
        offset: int = 0,
        limit: int = 100,
    ) -> list[ActivityState]:
        with self._lock:
            filtered = self._filter_activities(
                team_id=team_id, challenge_id=challenge_id, event=event
            )
            return filtered[offset : offset + limit]

    def count_activities(
        self, *, team_id: str = "", challenge_id: str = "", event: str = ""
    ) -> int:
        with self._lock:
            return len(
                self._filter_activities(team_id=team_id, challenge_id=challenge_id, event=event)
            )
