"""Pluggable state backend — shared state for server, pool, and dashboard.

Implementations:
- ``InMemoryBackend``: zero-dependency, single-process (default)
- ``RedisBackend``:    multi-process shared state with TTL auto-expiry
- ``SQLiteBackend``:   persistent single-process state

Factory::

    from lpb.core.state import create_backend
    backend = create_backend(redis_url="redis://localhost:6379/0")
"""

from __future__ import annotations

import sqlite3
from pathlib import Path

from lpb.core.state.memory import InMemoryBackend
from lpb.core.state.models import (
    ActivityState,
    InstanceState,
    NodeState,
    SolveState,
    SubmissionState,
    TeamState,
)
from lpb.core.state.protocol import StateBackend
from lpb.core.state.redis import RedisBackend
from lpb.core.state.sqlite import SQLiteBackend


def create_backend(
    redis_url: str = "", db_path: str = "", *, project_root: Path | None = None
) -> StateBackend:
    """Create a state backend.

    Priority: Redis > SQLite > InMemory.
    Default when neither ``redis_url`` nor ``db_path`` is given: SQLite at
    ``{project_root}/data/platform.sqlite3`` (requires ``project_root``).

    When a requested backend is misconfigured or unreachable, we log the
    reason and fall through to ``InMemoryBackend`` so a dev machine
    without Redis/SQLite still boots. Production deployments should
    catch this via the warning log, not by hoping the in-memory fallback
    survives a restart.
    """
    from lpb.core.log import log

    if not redis_url and not db_path:
        if project_root is None:
            log.info("No backend configured and no project_root given; using in-memory")
            return InMemoryBackend()
        db_dir = project_root / "data"
        db_dir.mkdir(parents=True, exist_ok=True)
        db_path = str(db_dir / "platform.sqlite3")

    if redis_url:
        pass  # fall through to Redis logic below
    elif db_path:
        try:
            be = SQLiteBackend(db_path)
            log.info("Using SQLite state backend", path=db_path)
            return be
        except (sqlite3.Error, OSError) as e:
            log.warning("SQLite unavailable, falling back to in-memory", error=str(e))
            return InMemoryBackend()
    else:
        log.info("Using in-memory state backend")
        return InMemoryBackend()

    # Redis path: the import is optional because `redis` is in [redis]
    # extras. Connection failures (auth, DNS, refused) surface as
    # ``redis.RedisError``; the bare Exception catch is gone.
    try:
        from redis import Redis
        from redis.exceptions import RedisError
    except ImportError:
        log.warning("redis package not installed, falling back to in-memory")
        return InMemoryBackend()

    try:
        client = Redis.from_url(redis_url, decode_responses=True)
        client.ping()
        log.info("Connected to Redis", url=redis_url)
        return RedisBackend(client)
    except (RedisError, OSError) as e:
        log.warning("Redis unavailable, falling back to in-memory", error=str(e))
        return InMemoryBackend()


__all__ = [
    "StateBackend",
    "InMemoryBackend",
    "RedisBackend",
    "SQLiteBackend",
    "create_backend",
    "ActivityState",
    "InstanceState",
    "NodeState",
    "SolveState",
    "SubmissionState",
    "TeamState",
]
