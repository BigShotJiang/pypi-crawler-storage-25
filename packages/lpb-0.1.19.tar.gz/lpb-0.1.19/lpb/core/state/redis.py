"""RedisBackend — Redis-backed state backend."""

from __future__ import annotations

import json
import time
from typing import TypeVar

from lpb.core.enums import InstanceStatus
from lpb.core.state.filters import match_activity, match_submission
from lpb.core.state.models import (
    ActivityState,
    InstanceState,
    NodeState,
    SolveState,
    SubmissionState,
    TeamState,
)


class RedisKey:
    """All Redis key prefixes used by :class:`RedisBackend`. Single source of truth."""

    INSTANCE = "pentest:instance:"
    CONFIG = "pentest:config:"
    NODE = "pentest:node:"
    TEAM = "pentest:team:"
    TEAM_TOKEN = "pentest:team_token:"
    SUBMISSION = "pentest:sub:"
    SUBMISSION_LIST = "pentest:subs:"
    SOLVE = "pentest:solve:"
    ACTIVITIES = "pentest:activities"


M = TypeVar("M")


def _to_hash(model) -> dict[str, str]:
    """Serialize a Pydantic model to a Redis hash mapping (field → JSON string)."""
    return {k: json.dumps(v) for k, v in model.model_dump(mode="json").items()}


def _from_hash(cls, raw: dict[str, str]):
    """Reconstruct a Pydantic model from a Redis hash mapping."""
    return cls.model_validate({k: json.loads(v) for k, v in raw.items()})


class RedisBackend:
    """Redis-backed state. Supports multi-process, survives restarts.

    Key prefixes are centralized in :class:`RedisKey`.
    """

    def __init__(self, client) -> None:
        self._r = client

    # -- shared internals ---------------------------------------------------

    def _scan_models(self, pattern: str, model_cls: type[M]) -> list[M]:
        """Scan keys matching *pattern* and rehydrate each non-empty hash into *model_cls*."""
        out: list[M] = []
        for key in self._r.scan_iter(match=pattern):
            raw = self._r.hgetall(key)
            if raw:
                out.append(_from_hash(model_cls, raw))
        return out

    # -- instance -----------------------------------------------------------

    def put_instance(self, instance_id: str, data: InstanceState, ttl: int = 0) -> None:
        now = time.time()
        status = data.status
        if status == InstanceStatus.READY:
            started_at = now
            expires_at = (now + ttl) if ttl > 0 else 0.0
        elif status == InstanceStatus.STARTING:
            started_at = 0.0
            expires_at = 0.0
        else:
            started_at = data.started_at
            expires_at = data.expires_at
        data = data.model_copy(
            update={"started_at": started_at, "ttl": ttl, "expires_at": expires_at}
        )
        key = f"{RedisKey.INSTANCE}{instance_id}"
        self._r.hset(key, mapping=_to_hash(data))
        if status == InstanceStatus.READY and ttl > 0:
            self._r.expire(key, ttl)
        elif status == InstanceStatus.STARTING:
            self._r.persist(key)  # no TTL during startup

    def get_instance(self, instance_id: str) -> InstanceState | None:
        raw = self._r.hgetall(f"{RedisKey.INSTANCE}{instance_id}")
        if not raw:
            return None
        return _from_hash(InstanceState, raw)

    def remove_instance(self, instance_id: str) -> InstanceState | None:
        key = f"{RedisKey.INSTANCE}{instance_id}"
        raw = self._r.hgetall(key)
        if not raw:
            return None
        self._r.delete(key)
        return _from_hash(InstanceState, raw)

    def list_instances(self) -> list[InstanceState]:
        result = []
        for key in self._r.scan_iter(match=f"{RedisKey.INSTANCE}*"):
            instance_id = key.removeprefix(RedisKey.INSTANCE)
            raw = self._r.hgetall(key)
            if raw:
                inst = _from_hash(InstanceState, raw)
                result.append(inst.model_copy(update={"instance_id": instance_id}))
        return result

    def count_instances(self) -> int:
        return sum(1 for _ in self._r.scan_iter(match=f"{RedisKey.INSTANCE}*"))

    def renew_instance(self, instance_id: str, ttl: int) -> float:
        key = f"{RedisKey.INSTANCE}{instance_id}"
        if not self._r.exists(key):
            raise KeyError(instance_id)
        now = time.time()
        expires_at = (now + ttl) if ttl > 0 else 0.0
        self._r.hset(
            key,
            mapping={
                "ttl": json.dumps(ttl),
                "expires_at": json.dumps(expires_at),
            },
        )
        if ttl > 0:
            self._r.expire(key, ttl)
        else:
            self._r.persist(key)
        return expires_at

    def pop_expired_instances(self) -> list[InstanceState]:
        # Redis handles expiry via EXPIRE; this is a no-op for Redis.
        return []

    def get_instance_by_team_challenge(
        self, team_id: str, challenge_id: str
    ) -> InstanceState | None:
        for key in self._r.scan_iter(match=f"{RedisKey.INSTANCE}*"):
            raw = self._r.hgetall(key)
            if not raw:
                continue
            inst = _from_hash(InstanceState, raw)
            if inst.team_id == team_id and inst.challenge_id == challenge_id:
                instance_id = key.removeprefix(RedisKey.INSTANCE)
                return inst.model_copy(update={"instance_id": instance_id})
        return None

    # -- config --------------------------------------------------------------

    def get_config(self, key: str) -> str | None:
        return self._r.get(f"{RedisKey.CONFIG}{key}")

    def set_config(self, key: str, value: str) -> None:
        self._r.set(f"{RedisKey.CONFIG}{key}", value)

    # -- nodes ---------------------------------------------------------------

    def put_node(self, node_id: str, data: NodeState) -> None:
        self._r.hset(f"{RedisKey.NODE}{node_id}", mapping=_to_hash(data))

    def get_node(self, node_id: str) -> NodeState | None:
        raw = self._r.hgetall(f"{RedisKey.NODE}{node_id}")
        if not raw:
            return None
        return _from_hash(NodeState, raw)

    def list_nodes(self) -> list[NodeState]:
        return self._scan_models(f"{RedisKey.NODE}*", NodeState)

    def remove_node(self, node_id: str) -> None:
        self._r.delete(f"{RedisKey.NODE}{node_id}")

    # -- teams ---------------------------------------------------------------

    def put_team(self, team_id: str, data: TeamState) -> None:
        self._r.hset(f"{RedisKey.TEAM}{team_id}", mapping=_to_hash(data))
        if data.token:
            self._r.set(f"{RedisKey.TEAM_TOKEN}{data.token}", team_id)

    def get_team(self, team_id: str) -> TeamState | None:
        raw = self._r.hgetall(f"{RedisKey.TEAM}{team_id}")
        if not raw:
            return None
        return _from_hash(TeamState, raw)

    def get_team_by_token(self, token: str) -> TeamState | None:
        team_id = self._r.get(f"{RedisKey.TEAM_TOKEN}{token}")
        if not team_id:
            return None
        return self.get_team(team_id)

    def list_teams(self) -> list[TeamState]:
        return self._scan_models(f"{RedisKey.TEAM}*", TeamState)

    # -- submissions ---------------------------------------------------------

    def add_submission(self, data: SubmissionState) -> None:
        sub_id = data.submission_id
        self._r.hset(f"{RedisKey.SUBMISSION}{sub_id}", mapping=_to_hash(data))
        if data.team_id:
            self._r.rpush(f"{RedisKey.SUBMISSION_LIST}{data.team_id}", sub_id)
        if data.challenge_id:
            self._r.rpush(f"{RedisKey.SUBMISSION_LIST}c:{data.challenge_id}", sub_id)

    def list_submissions(self, team_id: str = "", challenge_id: str = "") -> list[SubmissionState]:
        # Pick the narrowest secondary index available; the loop re-checks both
        # filters because a team's list can include cross-challenge entries.
        if team_id:
            ids = self._r.lrange(f"{RedisKey.SUBMISSION_LIST}{team_id}", 0, -1) or []
        elif challenge_id:
            ids = self._r.lrange(f"{RedisKey.SUBMISSION_LIST}c:{challenge_id}", 0, -1) or []
        else:
            ids = [
                k.removeprefix(RedisKey.SUBMISSION)
                for k in self._r.scan_iter(match=f"{RedisKey.SUBMISSION}*")
            ]
        result = []
        for sid in ids:
            raw = self._r.hgetall(f"{RedisKey.SUBMISSION}{sid}")
            if not raw:
                continue
            sub = _from_hash(SubmissionState, raw)
            if match_submission(sub, team_id=team_id, challenge_id=challenge_id):
                result.append(sub)
        return result

    # -- solves --------------------------------------------------------------

    def add_solve(self, team_id: str, challenge_id: str, data: SolveState) -> None:
        key = f"{RedisKey.SOLVE}{team_id}:{challenge_id}"
        if self._r.exists(key):
            return  # already solved
        self._r.hset(key, mapping=_to_hash(data))

    def get_solve(self, team_id: str, challenge_id: str) -> SolveState | None:
        raw = self._r.hgetall(f"{RedisKey.SOLVE}{team_id}:{challenge_id}")
        if not raw:
            return None
        return _from_hash(SolveState, raw)

    def list_solves(self, team_id: str = "") -> list[SolveState]:
        pattern = f"{RedisKey.SOLVE}{team_id}:*" if team_id else f"{RedisKey.SOLVE}*"
        return self._scan_models(pattern, SolveState)

    def count_solves_for_challenge(self, challenge_id: str) -> int:
        return sum(1 for _ in self._r.scan_iter(match=f"{RedisKey.SOLVE}*:{challenge_id}"))

    # -- activity log -------------------------------------------------------

    def add_activity(self, data: ActivityState) -> None:
        self._r.lpush(RedisKey.ACTIVITIES, data.model_dump_json())
        self._r.ltrim(RedisKey.ACTIVITIES, 0, 9999)  # keep last 10k

    def _iter_filtered_activities(
        self, *, team_id: str = "", challenge_id: str = "", event: str = ""
    ):
        """Yield activities matching filters (most recent first)."""
        raw = self._r.lrange(RedisKey.ACTIVITIES, 0, -1) or []
        for item in raw:
            a = ActivityState.model_validate_json(item)
            if match_activity(a, team_id=team_id, challenge_id=challenge_id, event=event):
                yield a

    def list_activities(
        self,
        *,
        team_id: str = "",
        challenge_id: str = "",
        event: str = "",
        offset: int = 0,
        limit: int = 100,
    ) -> list[ActivityState]:
        result = []
        for i, a in enumerate(
            self._iter_filtered_activities(team_id=team_id, challenge_id=challenge_id, event=event)
        ):
            if i < offset:
                continue
            result.append(a)
            if len(result) >= limit:
                break
        return result

    def count_activities(
        self, *, team_id: str = "", challenge_id: str = "", event: str = ""
    ) -> int:
        return sum(
            1
            for _ in self._iter_filtered_activities(
                team_id=team_id, challenge_id=challenge_id, event=event
            )
        )
