"""Challenge provider interface — the shared contract for all benchmark backends.

Providers are ONLY used inside the server. CLI/agents never instantiate
providers directly; they always go through the server HTTP API.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from pathlib import Path
from typing import ClassVar

from lpb.core.target import AttackSurface


@dataclass
class StartResult:
    """Result of starting an instance. Flag is kept server-side."""

    surface: AttackSurface
    flag: str


class ChallengeProvider(ABC):
    """Lifecycle manager for challenge instances.

    Used exclusively inside the server. External clients use the HTTP API.
    """

    name: ClassVar[str]

    def __enter__(self):
        return self

    def __exit__(self, *exc_info):
        self.stop_all()

    @abstractmethod
    def start(self, spec, *, proxy_output_dir: Path | None = None) -> StartResult:
        """Start the instance. Returns surface + flag (kept server-side)."""
        ...

    @abstractmethod
    def verify_flag(self, instance_id: str, claimed_flag: str) -> bool:
        """Constant-time flag verification."""
        ...

    @abstractmethod
    def stop(self, spec) -> None: ...

    @abstractmethod
    def stop_all(self) -> None: ...

    def check_health(self, instance_id: str) -> bool:
        """Return True if the instance's containers are all healthy/running."""
        return True

    def get_sandbox_network(self, instance_id: str) -> tuple[str, str] | None:
        return None

    def get_cert_volume(self, instance_id: str) -> str:
        return ""

    def get_proxy_output(self, instance_id: str) -> Path | None:
        return None
