"""lpb — unified CLI entrypoint.

Command groups:
  lpb server …       platform server lifecycle + invitations
  lpb node …         worker-node cluster membership
  lpb instance …     running challenge instances
  lpb challenge …    static challenge assets in benchmarks/
  lpb mcp            start the MCP server
  lpb config …       inspect active configuration
"""

from __future__ import annotations

import typer
from dotenv import load_dotenv

from lpb.cli.challenge import challenge_app
from lpb.cli.config import config_app
from lpb.cli.instance import instance_app
from lpb.cli.node import node_app
from lpb.cli.server import server_app

app = typer.Typer(help="LLM Pentest Bench (lpb)", no_args_is_help=True)
app.add_typer(server_app, name="server")
app.add_typer(node_app, name="node")
app.add_typer(instance_app, name="instance")
app.add_typer(challenge_app, name="challenge")
app.add_typer(config_app, name="config")


@app.callback()
def root(
    ctx: typer.Context,
    platform_url: str = typer.Option(
        "http://localhost:8100",
        "--platform-url",
        envvar="LPB_PLATFORM_URL",
        help="Platform URL used by client subcommands (instance/challenge/mcp).",
    ),
    team_token: str = typer.Option(
        "",
        "--team-token",
        envvar="LPB_TEAM_TOKEN",
        help="Team bearer token for subcommands that authenticate as a team.",
    ),
    admin_token: str = typer.Option(
        "",
        "--admin-token",
        envvar="LPB_ADMIN_TOKEN",
        help="Admin bearer token for admin-only subcommands.",
    ),
):
    """Populate ctx.obj with shared client settings for every subcommand."""
    ctx.ensure_object(dict)
    ctx.obj["platform_url"] = platform_url.rstrip("/")
    ctx.obj["team_token"] = team_token
    ctx.obj["admin_token"] = admin_token


@app.command()
def mcp(
    ctx: typer.Context,
):
    """Start the MCP server."""
    from lpb.mcp.server import main as mcp_main

    mcp_main(platform_url=ctx.obj["platform_url"], team_key=ctx.obj["team_token"])


def main() -> None:
    # Load .env before typer parses args so envvar= options pick up .env values.
    load_dotenv(override=False)
    app()


if __name__ == "__main__":
    main()
