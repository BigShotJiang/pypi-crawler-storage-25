"""`lpb node …` — worker-node lifecycle + cluster membership."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import typer
from pydantic import SecretStr
from rich.table import Table

from lpb.cli.runtime import console, err_console, get_client
from lpb.cli.uvicorn_runner import import_uvicorn_or_exit
from lpb.core.config import LpbConfig
from lpb.core.log import setup_logging

node_app = typer.Typer(help="Worker-node cluster membership", no_args_is_help=True)


def _d(field: str) -> Any:
    default = LpbConfig.model_fields[field].default
    if isinstance(default, SecretStr):
        return default.get_secret_value()
    return default


@node_app.command("join")
def node_join(
    ctx: typer.Context,
    host: str = typer.Option("0.0.0.0", "--host", help="Bind address"),
    port: int = typer.Option(8101, "--port", help="Bind port"),
    public_url: str = typer.Option(
        "",
        "--public-url",
        envvar="LPB_NODE_PUBLIC_URL",
        help="URL the platform/agents use to reach this node",
    ),
    capacity: int = typer.Option(
        10, "--capacity", envvar="LPB_NODE_CAPACITY", help="Max concurrent instances"
    ),
    label: list[str] = typer.Option([], "--label", help="Node label (k=v), repeatable"),
    labels_csv: str = typer.Option(
        "",
        "--labels",
        envvar="LPB_NODE_LABELS",
        help="Labels as `k1=v1,k2=v2` CSV (merged with --label).",
    ),
    no_register: bool = typer.Option(
        False, "--no-register", help="Skip platform self-registration (debug)"
    ),
    # --- node-side LpbConfig fields ---------------------------------------
    node_token: str = typer.Option(
        "",
        "--node-token",
        envvar="LPB_NODE_TOKEN",
        help="Cluster token (must match the platform's value).",
    ),
    challenges_dir: Path = typer.Option(
        _d("challenges_dir"),
        "--challenges-dir",
        envvar="LPB_CHALLENGES_DIR",
        help="Directory containing challenge metadata.yaml files.",
    ),
    instances_dir: Path = typer.Option(
        _d("instances_dir"),
        "--instances-dir",
        envvar="LPB_INSTANCES_DIR",
    ),
    host_project_root: str = typer.Option(
        _d("host_project_root"),
        "--host-project-root",
        envvar="LPB_HOST_PROJECT_ROOT",
    ),
    port_range_start: int = typer.Option(
        _d("port_range_start"),
        "--port-range-start",
        envvar="LPB_PORT_RANGE_START",
    ),
    port_range_end: int = typer.Option(
        _d("port_range_end"),
        "--port-range-end",
        envvar="LPB_PORT_RANGE_END",
    ),
    image_mitmproxy: str = typer.Option(
        _d("image_mitmproxy"),
        "--image-mitmproxy",
        envvar="LPB_IMAGE_MITMPROXY",
    ),
    base_domain: str = typer.Option(
        _d("base_domain"),
        "--base-domain",
        envvar="LPB_BASE_DOMAIN",
    ),
    traefik_network: str = typer.Option(
        _d("traefik_network"),
        "--traefik-network",
        envvar="LPB_TRAEFIK_NETWORK",
    ),
):
    """Start this worker and join the platform cluster.

    Authenticates to the platform with the cluster token and self-registers
    via the normal node lifespan. Runs in the foreground; stop with Ctrl-C
    (which triggers a clean deregister).
    """
    setup_logging()
    uvicorn = import_uvicorn_or_exit()

    labels: dict[str, str] = {}
    items = list(label) + [x for x in labels_csv.split(",") if x.strip()]
    for item in items:
        if "=" in item:
            k, v = item.split("=", 1)
            labels[k.strip()] = v.strip()
        else:
            labels[item.strip()] = "true"

    config = LpbConfig(
        node_token=SecretStr(node_token),
        platform_url=ctx.obj["platform_url"],
        server_port=port,
        challenges_dir=challenges_dir,
        instances_dir=instances_dir,
        host_project_root=host_project_root,
        port_range_start=port_range_start,
        port_range_end=port_range_end,
        image_mitmproxy=image_mitmproxy,
        base_domain=base_domain,
        traefik_network=traefik_network,
    )

    from lpb.server.node_app import create_node_app

    app_ = create_node_app(
        config,
        public_url=public_url,
        capacity=capacity,
        labels=labels or None,
        platform_url=ctx.obj["platform_url"],
        auto_register=not no_register,
    )
    console.print(f"Starting node on [bold]{host}:{port}[/bold]")
    uvicorn.run(app_, host=host, port=port)


@node_app.command("leave")
def node_leave():
    """Deregister this node from the platform and stop it."""
    err_console.print(
        "[yellow]`lpb node join` runs in the foreground and deregisters on Ctrl-C. "
        "Stop it there, or use `lpb node rm <node_id>` from the platform host to "
        "force a removal.[/yellow]"
    )
    raise typer.Exit(2)


@node_app.command("ls")
def node_ls(
    ctx: typer.Context,
    json_output: bool = typer.Option(False, "--json", help="Emit JSON instead of a table"),
):
    """List nodes registered with the platform."""
    setup_logging()
    client = get_client(ctx, require_auth=False)
    nodes = client.list_nodes()

    if json_output:
        console.print_json(data=nodes)
        return

    table = Table(title="Compute Nodes")
    table.add_column("ID", style="cyan")
    table.add_column("URL")
    table.add_column("Capacity", justify="right")
    table.add_column("Running", justify="right")
    table.add_column("Health")
    table.add_column("Labels", style="dim")

    for n in nodes:
        healthy = n.get("healthy") if isinstance(n, dict) else getattr(n, "healthy", False)
        health = "[green]healthy[/]" if healthy else "[red]unhealthy[/]"
        node_id = n.get("node_id", "") if isinstance(n, dict) else getattr(n, "node_id", "")
        url = n.get("url", "") if isinstance(n, dict) else getattr(n, "url", "")
        capacity = n.get("capacity", "") if isinstance(n, dict) else getattr(n, "capacity", "")
        running = n.get("running", "") if isinstance(n, dict) else getattr(n, "running", "")
        labels = n.get("labels", {}) if isinstance(n, dict) else getattr(n, "labels", {})
        labels_csv = ", ".join(f"{k}={v}" for k, v in labels.items()) if labels else ""
        table.add_row(node_id, url, str(capacity), str(running), health, labels_csv)
    console.print(table)
    console.print(f"\n[bold]{len(nodes)}[/bold] node(s)")


@node_app.command("rm")
def node_rm(
    ctx: typer.Context,
    node_id: str = typer.Argument(help="Node ID to deregister"),
):
    """Force-remove a node from the platform (admin)."""
    setup_logging()
    client = get_client(ctx, require_auth=False)
    try:
        client.remove_node(node_id)
    except Exception as e:
        err_console.print(f"[red]Failed: {e}[/red]")
        raise typer.Exit(1)
    console.print(f"[green]Node removed: {node_id}[/green]")
