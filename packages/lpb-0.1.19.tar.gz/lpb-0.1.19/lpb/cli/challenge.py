"""`lpb challenge …` — static challenge assets in benchmarks/."""

from __future__ import annotations

from collections.abc import Iterable
from pathlib import Path

import typer
import yaml
from pydantic import ValidationError
from rich.table import Table

from lpb.cli.runtime import console, err_console
from lpb.core.challenge import ChallengeSpec
from lpb.core.challenge_validate import validate_dir
from lpb.core.config import LpbConfig
from lpb.core.log import log, setup_logging

challenge_app = typer.Typer(help="Static challenge assets in benchmarks/", no_args_is_help=True)


def _default_challenges_dir() -> Path:
    return LpbConfig.model_fields["challenges_dir"].default


CHALLENGES_DIR_OPTION = typer.Option(
    _default_challenges_dir(),
    "--challenges-dir",
    envvar="LPB_CHALLENGES_DIR",
    help="Directory containing challenge metadata.yaml files.",
)


def _iter_specs(
    challenges_dir: Path,
    *,
    challenge_id: str | None = None,
    category: str | None = None,
    difficulty: int | None = None,
) -> Iterable[ChallengeSpec]:
    if not challenges_dir.exists():
        return
    for d in sorted(challenges_dir.iterdir()):
        yml = d / "metadata.yaml"
        if not d.is_dir() or not yml.exists():
            continue
        try:
            spec = ChallengeSpec.from_yaml(yml)
        except (ValidationError, yaml.YAMLError) as e:
            log.warning("Skipping invalid challenge spec", path=str(yml), error=str(e))
            continue
        if challenge_id:
            patterns = [p.strip() for p in challenge_id.split(",")]
            if not any(spec.id == p or spec.id.startswith(p + "-") for p in patterns):
                continue
        if category and spec.category != category:
            continue
        if difficulty is not None and spec.difficulty != difficulty:
            continue
        yield spec


@challenge_app.command("ls")
def challenge_ls(
    challenge: str | None = typer.Option(
        None, "--challenge", help="Filter by challenge ID (comma-separated, prefix-match)"
    ),
    category: str | None = typer.Option(None, "--category", help="Filter by category"),
    difficulty: int | None = typer.Option(
        None, "--difficulty", help="Filter by difficulty (1=easy, 2=medium, 3=hard)"
    ),
    json_output: bool = typer.Option(False, "--json", help="Emit JSON instead of a table"),
    challenges_dir: Path = CHALLENGES_DIR_OPTION,
):
    """List challenge definitions in benchmarks/."""
    setup_logging()
    specs = list(
        _iter_specs(
            challenges_dir, challenge_id=challenge, category=category, difficulty=difficulty
        )
    )

    if json_output:
        console.print_json(data=[s.model_dump(mode="json") for s in specs])
        return

    table = Table(title="Challenge Definitions")
    table.add_column("ID", style="cyan")
    table.add_column("Name")
    table.add_column("Category", style="magenta")
    table.add_column("Diff", justify="right")
    table.add_column("Provider", style="dim")
    table.add_column("Origin", style="dim")
    for spec in specs:
        table.add_row(
            spec.id, spec.name, spec.category, str(spec.difficulty), spec.provider, spec.origin
        )
    console.print(table)
    console.print(f"\n[bold]{len(specs)}[/bold] challenge(s)")


@challenge_app.command("show")
def challenge_show(
    challenge_id: str = typer.Argument(help="Challenge ID"),
    json_output: bool = typer.Option(False, "--json", help="Emit JSON instead of a summary"),
    challenges_dir: Path = CHALLENGES_DIR_OPTION,
):
    """Show full metadata for a single challenge."""
    setup_logging()
    for spec in _iter_specs(challenges_dir, challenge_id=challenge_id):
        if spec.id == challenge_id:
            if json_output:
                console.print_json(data=spec.model_dump(mode="json"))
            else:
                console.print(spec.model_dump(mode="json"))
            return
    err_console.print(f"[red]Challenge not found: {challenge_id}[/red]")
    raise typer.Exit(1)


@challenge_app.command("validate")
def challenge_validate(
    challenge_id: str | None = typer.Argument(
        None, help="Challenge ID to validate (omit with --all to scan every challenge)"
    ),
    all_: bool = typer.Option(False, "--all", help="Validate every metadata.yaml in benchmarks/"),
    strict: bool = typer.Option(
        False,
        "--strict",
        help="Also require docker-compose.yml for docker / cvebench providers",
    ),
    json_output: bool = typer.Option(False, "--json", help="Emit one JSON object per finding"),
    challenges_dir: Path = CHALLENGES_DIR_OPTION,
):
    """Validate metadata.yaml against the schema + prefix/id/provider rules."""
    setup_logging()
    if not all_ and not challenge_id:
        err_console.print("[red]Pass a challenge ID or --all.[/red]")
        raise typer.Exit(2)

    findings = validate_dir(
        challenges_dir,
        challenge_id=None if all_ else challenge_id,
        strict=strict,
    )

    if not findings:
        err_console.print("[red]No challenges matched.[/red]")
        raise typer.Exit(2)

    failed = [f for f in findings if not f.ok]

    if json_output:
        import json

        for f in findings:
            console.print(
                json.dumps(
                    {"challenge": f.challenge, "status": f.status, "reason": f.reason},
                    ensure_ascii=False,
                )
            )
    else:
        for f in findings:
            if f.ok:
                console.print(f"[green]OK[/green]    {f.challenge}")
            else:
                console.print(f"[red]FAIL[/red]  {f.challenge}: {f.reason}")
        console.print(
            f"\n[bold]{len(findings) - len(failed)}[/bold] ok, [bold]{len(failed)}[/bold] failed"
        )

    if failed:
        raise typer.Exit(1)
