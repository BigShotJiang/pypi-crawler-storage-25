"""`lpb config …` — inspect active configuration.

The CLI has no global ``settings`` singleton any more. ``lpb config show``
reconstructs an :class:`LpbConfig` purely from the current ``os.environ`` so
the operator sees what ``lpb server start`` would resolve at this moment.
"""

from __future__ import annotations

import os

import typer
from pydantic import SecretStr

from lpb.cli.runtime import console
from lpb.core.config import LpbConfig

config_app = typer.Typer(help="Inspect active configuration", no_args_is_help=True)


def _redact(value) -> str:
    if isinstance(value, SecretStr):
        return "<set>" if value.get_secret_value() else "<unset>"
    return str(value)


def _config_from_environ() -> LpbConfig:
    """Build an LpbConfig from ``LPB_*`` env vars, mirroring typer envvar reads."""
    raw: dict[str, str] = {}
    for name in LpbConfig.model_fields:
        value = os.environ.get(f"LPB_{name.upper()}")
        if value:
            raw[name] = value
    # Honour the legacy alias the same way ``lpb server start`` does.
    if "admin_token" not in raw and os.environ.get("LPB_SERVER_API_KEY"):
        raw["admin_token"] = os.environ["LPB_SERVER_API_KEY"]
    return LpbConfig(**raw)


@config_app.command("show")
def config_show(
    json_output: bool = typer.Option(False, "--json", help="Emit JSON instead of a table"),
):
    """Print the effective settings (secrets redacted)."""
    cfg = _config_from_environ()
    data = {k: _redact(v) for k, v in cfg.model_dump().items()}
    for field in ("admin_token", "node_token", "team_token"):
        data[field] = _redact(getattr(cfg, field))

    if json_output:
        console.print_json(data=data)
        return

    from rich.table import Table

    table = Table(title="lpb configuration")
    table.add_column("Setting", style="cyan")
    table.add_column("Value")
    for k in sorted(data):
        table.add_row(k, data[k])
    console.print(table)
