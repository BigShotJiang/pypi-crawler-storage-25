"""`lpb instance …` — running challenge instances."""

from __future__ import annotations

import typer
from rich.table import Table

from lpb.cli.runtime import console, err_console, get_client
from lpb.core.enums import InstanceStatus
from lpb.core.log import setup_logging

instance_app = typer.Typer(help="Running challenge instances", no_args_is_help=True)


@instance_app.command("ls")
def instance_ls(
    ctx: typer.Context,
    challenge: str | None = typer.Option(None, "--challenge", help="Filter by challenge ID"),
    status: str | None = typer.Option(None, "--status", help="Filter by status"),
    json_output: bool = typer.Option(False, "--json", help="Emit JSON instead of a table"),
):
    """List instances currently running on the platform."""
    setup_logging()
    client = get_client(ctx)
    instances = client.list_instances(challenge_id=challenge or "", status=status or "")

    if json_output:
        console.print_json(data=[i.model_dump() for i in instances])
        return

    table = Table(title="Running Instances")
    table.add_column("Instance ID", style="cyan")
    table.add_column("Challenge")
    table.add_column("Status")
    table.add_column("Started", style="dim")
    table.add_column("TTL", justify="right")

    for inst in instances:
        status_style = "green" if inst.status == InstanceStatus.READY else "yellow"
        table.add_row(
            inst.instance_id,
            inst.challenge_id or inst.name,
            f"[{status_style}]{inst.status}[/]",
            str(int(inst.started_at)) if inst.started_at else "",
            str(inst.ttl) if inst.ttl else "",
        )
    console.print(table)
    console.print(f"\n[bold]{len(instances)}[/bold] running")


@instance_app.command("start")
def instance_start(
    ctx: typer.Context,
    challenge_id: str = typer.Argument(help="Challenge ID to start"),
    ttl: int = typer.Option(3600, "--ttl", help="Time-to-live in seconds"),
    json_output: bool = typer.Option(False, "--json", help="Emit JSON instead of a table"),
):
    """Start an instance of a challenge and wait until it is ready."""
    setup_logging()
    client = get_client(ctx)
    console.print(f"Starting [bold]{challenge_id}[/bold]...")
    try:
        ready = client.start_instance(challenge_id, ttl=ttl)
    except Exception as e:
        err_console.print(f"[red]Failed: {e}[/red]")
        raise typer.Exit(1)

    if json_output:
        console.print_json(data=ready.surface.model_dump())
        return

    console.print("[green]Ready![/green]")
    for svc in ready.surface.services:
        suffix = f"  ({svc.label})" if svc.label else ""
        console.print(f"  {svc.service_type.value}://{svc.host}:{svc.port}{suffix}")


@instance_app.command("stop")
def instance_stop(
    ctx: typer.Context,
    instance_id: str = typer.Argument(help="Instance ID (or challenge ID) to stop"),
):
    """Stop a running instance."""
    setup_logging()
    client = get_client(ctx)
    try:
        client.stop_instance(instance_id)
    except Exception as e:
        err_console.print(f"[red]Failed: {e}[/red]")
        raise typer.Exit(1)
    console.print(f"[green]Stopped {instance_id}[/green]")
