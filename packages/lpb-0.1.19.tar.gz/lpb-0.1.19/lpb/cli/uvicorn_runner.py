"""Shared `uvicorn` lookup for CLI commands that bind a server.

Both ``lpb server start`` and ``lpb node join`` boot a uvicorn server, and both
need to fail with the same actionable error when the optional dependency is
missing. Centralising the import keeps the message consistent and the call
site one line.
"""

from __future__ import annotations

from types import ModuleType

import typer

from lpb.cli.runtime import err_console


def import_uvicorn_or_exit() -> ModuleType:
    """Return the ``uvicorn`` module or print install hint and exit(1)."""
    try:
        import uvicorn

        return uvicorn
    except ImportError:
        err_console.print("[red]uvicorn is required (install with: uv sync).[/red]")
        raise typer.Exit(1)
