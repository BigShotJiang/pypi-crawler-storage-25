"""`lpb server …` — platform server lifecycle + invitations."""

from __future__ import annotations

import os
import secrets
from pathlib import Path
from typing import Any

import httpx
import typer
from pydantic import SecretStr

from lpb.cli.runtime import admin_headers, console, err_console
from lpb.cli.runtime import platform_url as resolve_platform_url
from lpb.cli.uvicorn_runner import import_uvicorn_or_exit
from lpb.core.config import LpbConfig
from lpb.core.log import setup_logging

server_app = typer.Typer(help="Platform server lifecycle + invitations", no_args_is_help=True)


def _d(field: str) -> Any:
    """Read a LpbConfig field's default, unwrapping SecretStr for CLI display."""
    default = LpbConfig.model_fields[field].default
    if isinstance(default, SecretStr):
        return default.get_secret_value()
    return default


# ---------------------------------------------------------------------------
# Shared helpers — snippet rendering and first-run bootstrap
# ---------------------------------------------------------------------------


def _node_env(
    *,
    platform_url: str,
    node_token: str,
    public_url: str,
    capacity: int,
    labels_csv: str,
) -> dict[str, str]:
    """Env var dict shared by every node-join snippet renderer."""
    return {
        "LPB_PLATFORM_URL": platform_url,
        "LPB_NODE_PUBLIC_URL": public_url,
        "LPB_NODE_TOKEN": node_token,
        "LPB_NODE_CAPACITY": str(capacity),
        "LPB_NODE_LABELS": labels_csv,
    }


def _render_docker_run(
    *,
    platform_url: str,
    node_token: str,
    capacity: int = 10,
    labels_csv: str = "",
    node_image: str = "lpb-node:latest",
) -> str:
    """Ready-to-run ``docker run`` snippet for joining a node to the platform."""
    env = _node_env(
        platform_url=platform_url,
        node_token=node_token,
        public_url="\"http://$(hostname -I | awk '{print $1}'):8101\"",
        capacity=capacity,
        labels_csv=labels_csv,
    )
    env_lines = "".join(f"  -e {k}={v} \\\n" for k, v in env.items())
    return (
        f"docker run -d --name lpb-node \\\n"
        f"{env_lines}"
        f"  -v /var/run/docker.sock:/var/run/docker.sock \\\n"
        f"  -v /path/to/benchmarks:/app/benchmarks:ro \\\n"
        f"  -v lpb-node-data:/app/data \\\n"
        f"  -p 8101:8101 \\\n"
        f"  {node_image}\n"
    )


def _render_compose_service(
    *,
    platform_url: str,
    node_token: str,
    capacity: int = 10,
    labels_csv: str = "",
    node_image: str = "lpb-node:latest",
) -> str:
    """Compose service block for appending to an existing ``docker-compose.yml``."""
    env = _node_env(
        platform_url=platform_url,
        node_token=node_token,
        public_url="http://node2:8101",
        capacity=capacity,
        labels_csv=labels_csv,
    )
    env_lines = "".join(f"      - {k}={v}\n" for k, v in env.items())
    return (
        "# Append this service to your docker-compose.yml\n"
        "  node2:\n"
        f"    image: {node_image}\n"
        "    volumes:\n"
        "      - /var/run/docker.sock:/var/run/docker.sock\n"
        "      - ./benchmarks:/app/benchmarks:ro\n"
        "      - ./data/node2:/app/data\n"
        "    environment:\n"
        f"{env_lines}"
        '    ports:\n      - "8102:8101"\n'
    )


def _render_uv_run(
    *,
    platform_url: str,
    node_token: str,
    capacity: int = 10,
    labels_csv: str = "",
    node_image: str = "lpb-node:latest",  # noqa: ARG001  (unused; kept for signature parity)
) -> str:
    """Bare-metal ``uv run lpb node join`` snippet — clone repo + launch with env."""
    env = _node_env(
        platform_url=platform_url,
        node_token=node_token,
        public_url="\"http://$(hostname -I | awk '{print $1}'):8101\"",
        capacity=capacity,
        labels_csv=labels_csv,
    )
    env_lines = "".join(f"  {k}={v} \\\n" for k, v in env.items())
    return (
        "# Requires: uv (https://docs.astral.sh/uv/), git, docker CLI, python>=3.11\n"
        "git clone https://github.com/wangyihang/llm-pentest-benchmarks.git \\\n"
        "  && cd llm-pentest-benchmarks \\\n"
        "  && uv sync\n"
        "\n"
        "env \\\n"
        f"{env_lines}"
        "  uv run lpb node join --host 0.0.0.0 --port 8101\n"
    )


def _bootstrap_env_if_missing(env_path: Path, admin: str, node: str) -> dict[str, str] | None:
    """Auto-generate ``.env`` with fresh secrets on first run.

    Does nothing when ``.env`` already exists OR when both ``admin`` and
    ``node`` are already supplied (from ``--admin-token`` / ``--node-token``
    or their env vars). Returns the generated values dict on success, or
    ``None`` when no file was written.

    File is written mode ``0600`` — secrets are sensitive.
    """
    if env_path.exists():
        return None
    if admin or node:
        return None

    admin = secrets.token_hex(32)
    node = secrets.token_hex(32)
    url = "http://localhost:8100"
    env_path.write_text(
        "# Auto-generated on first `lpb server start`. Edit as needed.\n"
        f"LPB_ADMIN_TOKEN={admin}\n"
        f"LPB_NODE_TOKEN={node}\n"
        f"LPB_PLATFORM_URL={url}\n"
    )
    env_path.chmod(0o600)

    # Propagate to the current process so create_app picks them up.
    os.environ["LPB_ADMIN_TOKEN"] = admin
    os.environ["LPB_NODE_TOKEN"] = node
    os.environ["LPB_PLATFORM_URL"] = url

    return {"admin_token": admin, "node_token": node, "platform_url": url, "path": str(env_path)}


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------


@server_app.command("start")
def server_start(
    # --- bind address (process-level) -------------------------------------
    host: str = typer.Option(_d("server_host"), "--host", envvar="LPB_SERVER_HOST"),
    port: int = typer.Option(_d("server_port"), "--port", envvar="LPB_SERVER_PORT"),
    external_host: str = typer.Option(
        "", "--external-host", help="External hostname/IP (auto-detected if empty)"
    ),
    # --- secrets ----------------------------------------------------------
    admin_token: str = typer.Option(
        "",
        "--admin-token",
        envvar=["LPB_ADMIN_TOKEN", "LPB_SERVER_API_KEY"],
        help="Admin bearer token. Generated on first run if empty.",
    ),
    node_token: str = typer.Option(
        "",
        "--node-token",
        envvar="LPB_NODE_TOKEN",
        help="Cluster token for platform↔node auth. Generated on first run if empty.",
    ),
    platform_url: str = typer.Option(
        _d("platform_url"),
        "--platform-url",
        envvar="LPB_PLATFORM_URL",
        help="URL the platform advertises to nodes (e.g. http://platform:8100).",
    ),
    # --- paths ------------------------------------------------------------
    challenges_dir: Path = typer.Option(
        _d("challenges_dir"),
        "--challenges-dir",
        envvar="LPB_CHALLENGES_DIR",
        help="Directory containing challenge metadata.yaml files.",
    ),
    instances_dir: Path = typer.Option(
        _d("instances_dir"),
        "--instances-dir",
        envvar="LPB_INSTANCES_DIR",
        help="Working directory for per-instance artefacts.",
    ),
    host_project_root: str = typer.Option(
        _d("host_project_root"),
        "--host-project-root",
        envvar="LPB_HOST_PROJECT_ROOT",
        help="Host path mapped to the container's project root (Docker-in-Docker).",
    ),
    # --- Docker -----------------------------------------------------------
    port_range_start: int = typer.Option(
        _d("port_range_start"),
        "--port-range-start",
        envvar="LPB_PORT_RANGE_START",
        help="Lowest host port for challenge services.",
    ),
    port_range_end: int = typer.Option(
        _d("port_range_end"),
        "--port-range-end",
        envvar="LPB_PORT_RANGE_END",
        help="Highest host port for challenge services.",
    ),
    image_mitmproxy: str = typer.Option(
        _d("image_mitmproxy"),
        "--image-mitmproxy",
        envvar="LPB_IMAGE_MITMPROXY",
        help="Image tag for the per-instance mitmproxy sidecar.",
    ),
    node_image: str = typer.Option(
        _d("node_image"),
        "--node-image",
        envvar="LPB_NODE_IMAGE",
        help="Node Docker image advertised by `lpb server invite`.",
    ),
    # --- state backend ----------------------------------------------------
    redis_url: str = typer.Option(
        _d("redis_url"),
        "--redis-url",
        envvar="LPB_REDIS_URL",
        help="Redis URL (redis:// or rediss://). Overrides SQLite when set.",
    ),
    db_path: str = typer.Option(
        _d("db_path"),
        "--db-path",
        envvar="LPB_DB_PATH",
        help="SQLite path (default: {project_root}/data/platform.sqlite3).",
    ),
    # --- Traefik / http_domain --------------------------------------------
    traefik_enabled: bool = typer.Option(
        _d("traefik_enabled"),
        "--traefik-enabled/--no-traefik-enabled",
        envvar="LPB_TRAEFIK_ENABLED",
        help="Opt into Docker-label HTTP_DOMAIN exposure.",
    ),
    traefik_rules_path: str = typer.Option(
        _d("traefik_rules_path"),
        "--traefik-rules-path",
        envvar="LPB_TRAEFIK_RULES_PATH",
        help="Path to Traefik file-provider YAML the platform maintains.",
    ),
    base_domain: str = typer.Option(
        _d("base_domain"),
        "--base-domain",
        envvar="LPB_BASE_DOMAIN",
        help="Wildcard DNS base for http_domain challenges (required with traefik_rules_path).",
    ),
    traefik_network: str = typer.Option(
        _d("traefik_network"),
        "--traefik-network",
        envvar="LPB_TRAEFIK_NETWORK",
        help="Docker network Traefik joins for label-based routing.",
    ),
):
    """Start the platform server in the foreground.

    On first run (no ``.env`` and no tokens set), auto-generates fresh
    secrets into ``./.env`` (mode 0600) and prints them. Subsequent runs
    respect the existing configuration.

    Backgrounding is delegated to systemd / docker compose / tmux.
    """
    setup_logging()
    uvicorn = import_uvicorn_or_exit()

    project_root = LpbConfig.model_fields["project_root"].default
    generated = _bootstrap_env_if_missing(project_root / ".env", admin_token, node_token)
    if generated:
        console.print(
            f"[green]✓ Generated [bold]{generated['path']}[/bold] with fresh secrets "
            "(mode 0600).[/green]"
        )
        console.print("  [dim]These apply to this process and are persisted for later runs.[/dim]")
        console.print(f"    LPB_ADMIN_TOKEN = [bold]{generated['admin_token']}[/bold]")
        console.print(f"    LPB_NODE_TOKEN  = [bold]{generated['node_token']}[/bold]")
        console.print(f"    LPB_PLATFORM_URL = {generated['platform_url']}")
        console.print()
        admin_token = generated["admin_token"]
        node_token = generated["node_token"]
        platform_url = generated["platform_url"]

    config = LpbConfig(
        server_host=host,
        server_port=port,
        admin_token=SecretStr(admin_token),
        node_token=SecretStr(node_token),
        platform_url=platform_url,
        challenges_dir=challenges_dir,
        instances_dir=instances_dir,
        host_project_root=host_project_root,
        port_range_start=port_range_start,
        port_range_end=port_range_end,
        image_mitmproxy=image_mitmproxy,
        node_image=node_image,
        redis_url=redis_url,
        db_path=db_path,
        traefik_enabled=traefik_enabled,
        traefik_rules_path=traefik_rules_path,
        base_domain=base_domain,
        traefik_network=traefik_network,
    )

    from lpb.server.app import create_app

    app_ = create_app(config, external_host=external_host or None)
    console.print(f"Starting platform on [bold]{host}:{port}[/bold]")

    try:
        from lpb.core.state import create_backend

        backend = create_backend(config.redis_url, config.db_path, project_root=config.project_root)
        if not backend.list_nodes():
            public_host = external_host or host
            reachable_url = (
                config.platform_url
                if config.platform_url and "localhost" not in config.platform_url
                else f"http://{public_host}:{port}"
            )
            snippet = _render_docker_run(
                platform_url=reachable_url,
                node_token=node_token or "<LPB_NODE_TOKEN>",
            )
            console.print(
                "[yellow]No worker nodes registered yet. POST /instances will 503 "
                "until one joins. Run this on a worker host to join:[/yellow]"
            )
            console.print()
            console.print(snippet)
    except Exception:
        # Non-fatal: the hint is best-effort.
        pass
    uvicorn.run(app_, host=host, port=port)


@server_app.command("status")
def server_status(
    ctx: typer.Context,
    json_output: bool = typer.Option(False, "--json", help="Emit JSON instead of a table"),
):
    """Probe the platform's /health endpoint."""
    url = resolve_platform_url(ctx)
    try:
        resp = httpx.get(f"{url}/api/v1/health", timeout=5)
        resp.raise_for_status()
    except httpx.HTTPError as e:
        err_console.print(f"[red]No platform at {url}: {e}[/red]")
        raise typer.Exit(2)
    data = resp.json()
    if json_output:
        console.print_json(data=data)
        return
    console.print(f"[bold]{url}[/bold]")
    for k, v in data.items():
        console.print(f"  {k}: {v}")


@server_app.command("stop")
def server_stop():
    """Stop a platform server managed by your process supervisor."""
    err_console.print(
        "[yellow]`lpb server start` runs in the foreground; stop it with Ctrl-C "
        "or your process supervisor (systemd, docker compose, tmux).[/yellow]"
    )
    raise typer.Exit(2)


@server_app.command("invite")
def server_invite(
    ctx: typer.Context,
    role: str = typer.Option("node", "--role", help="Role for the credential: node"),
    capacity: int = typer.Option(10, "--capacity", help="Max concurrent instances on the new node"),
    label: list[str] = typer.Option([], "--label", help="Node label (k=v), repeatable"),
    output: str = typer.Option(
        "docker", "--output", "-o", help="Output format: docker | compose | uv | json"
    ),
):
    """Issue a joining credential for a new worker node.

    Fetches the cluster token + platform URL from the admin-only
    ``/cluster-info`` endpoint (requires admin token) and prints a
    ready-to-run docker / compose snippet.
    """
    setup_logging()
    if role != "node":
        err_console.print(f"[red]Unknown role: {role} (only 'node' is supported today)[/red]")
        raise typer.Exit(2)

    url = resolve_platform_url(ctx)
    headers = admin_headers(ctx)
    if not headers:
        err_console.print(
            "[red]No admin token configured.[/red]\n"
            "  Pass --admin-token or set LPB_ADMIN_TOKEN and retry."
        )
        raise typer.Exit(2)

    try:
        resp = httpx.get(f"{url}/api/v1/cluster-info", headers=headers, timeout=10)
        resp.raise_for_status()
        info = resp.json()
    except httpx.HTTPError as e:
        err_console.print(f"[red]cluster-info failed: {e}[/red]")
        raise typer.Exit(1)

    cluster_token = info.get("cluster_token") or "<set LPB_NODE_TOKEN>"
    node_image = info.get("node_image") or "lpb-node:latest"
    platform_url = info.get("platform_url") or url
    labels_csv = ",".join(label) if label else ""

    if output == "json":
        console.print_json(
            data={
                "platform_url": platform_url,
                "node_token": cluster_token,
                "node_image": node_image,
                "capacity": capacity,
                "labels": labels_csv,
            }
        )
        return

    kwargs = {
        "platform_url": platform_url,
        "node_token": cluster_token,
        "node_image": node_image,
        "capacity": capacity,
        "labels_csv": labels_csv,
    }
    if output == "compose":
        console.print(_render_compose_service(**kwargs))
        return
    if output == "uv":
        console.print(_render_uv_run(**kwargs))
        return
    console.print(_render_docker_run(**kwargs))
