"""
Chart Library MCP Server — expose chart pattern search tools for Claude Desktop / Claude Code.

19 tools:
  Core Search:
    1. search_charts       — text query → similar patterns
    2. get_follow_through  — results → forward returns
    3. get_pattern_summary — results → English summary
    4. get_status          — DB stats
    5. analyze_pattern     — combined search + follow-through + summary
    6. get_discover_picks  — top daily picks by interest score
    7. search_batch        — batch multi-symbol search

  Market Intelligence:
    8. detect_anomaly       — check if a stock's pattern is unusual vs history
    9. get_volume_profile   — intraday volume breakdown vs historical average
   10. get_sector_rotation  — which sectors are leading/lagging
   11. get_crowding         — are too many stocks signaling the same direction?
   12. get_earnings_reaction— historical earnings gap reactions
   13. get_correlation_shift— stocks breaking from usual market correlation
   14. run_scenario         — what happens to a stock when market moves X%?

  Trading Intelligence:
   15. get_regime_win_rates  — pattern win rates filtered by current market regime
   16. get_pattern_degradation — are signals degrading vs historical accuracy?
   17. get_exit_signal       — pattern-based exit recommendations for open positions
   18. get_risk_adjusted_picks — picks scored by Sharpe-like risk/reward ratio

  Utility:
   19. report_feedback      — report errors or suggestions

Dual mode:
  - If CHART_LIBRARY_API_KEY is set → HTTP API calls (cloud users)
  - Otherwise → direct Python imports (self-hosted / local dev)

Install:
  claude mcp add chart-library -- python mcp_server.py
"""

import json
import logging
import os
import sys

# Ensure project root is on path for direct imports
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from mcp.server.fastmcp import FastMCP

log = logging.getLogger("mcp_server")

_API_KEY = os.getenv("CHART_LIBRARY_API_KEY")
_API_BASE = os.getenv("CHART_LIBRARY_API_URL", "https://chartlibrary.io")

mcp = FastMCP("chart-library")


# ── Transport layer ──────────────────────────────────────────

def _use_http() -> bool:
    """Whether to use HTTP API calls (vs direct Python imports)."""
    return bool(_API_KEY)


def _http_post(path: str, body: dict) -> dict:
    """Make an authenticated POST to the Chart Library API."""
    import requests
    url = f"{_API_BASE}{path}"
    headers = {"Authorization": f"Bearer {_API_KEY}", "Content-Type": "application/json"}
    resp = requests.post(url, json=body, headers=headers, timeout=30)
    resp.raise_for_status()
    return resp.json()


def _http_get(path: str) -> dict:
    """Make an authenticated GET to the Chart Library API."""
    import requests
    url = f"{_API_BASE}{path}"
    headers = {"Authorization": f"Bearer {_API_KEY}"}
    resp = requests.get(url, headers=headers, timeout=30)
    resp.raise_for_status()
    return resp.json()


# ── Direct Python imports (local mode) ──────────────────────

def _direct_search(query: str, timeframe: str = "auto", top_n: int = 10) -> dict:
    """Run search directly via Python imports."""
    from dotenv import load_dotenv
    load_dotenv()

    from services.query_parser import parse_text_query, validate_text_query
    from db.embeddings import search_similar_to_day, search_similar_to_window, MULTI_DAY_SCALES

    parsed = parse_text_query(query)
    if parsed is None:
        return {"error": "Could not parse query. Use format: AAPL 2024-06-15"}

    if len(parsed) == 3:
        symbol, date_str, scale = parsed
        timeframe = scale
    else:
        symbol, date_str = parsed
        if timeframe == "auto":
            timeframe = "rth"

    error = validate_text_query(symbol, date_str, timeframe)
    if error:
        return {"error": error}

    if timeframe in MULTI_DAY_SCALES:
        results = search_similar_to_window(symbol, date_str, top_n=top_n, scale=timeframe)
    else:
        results = search_similar_to_day(symbol, date_str, top_n=top_n, timeframe=timeframe)

    return {
        "query": {"symbol": symbol, "date": date_str},
        "results": results[:top_n],
        "count": len(results[:top_n]),
        "timeframe": timeframe,
    }


def _direct_follow_through(results: list[dict]) -> dict:
    """Compute follow-through directly."""
    from dotenv import load_dotenv
    load_dotenv()

    from services.follow_through import compute_follow_through
    return compute_follow_through(results)


def _direct_summary(query_label: str, n_matches: int, horizon_returns: dict) -> dict:
    """Generate summary directly."""
    from dotenv import load_dotenv
    load_dotenv()

    from services.summary_service import generate_pattern_summary
    text = generate_pattern_summary(query_label, n_matches, horizon_returns)
    return {"summary": text}


def _direct_status() -> dict:
    """Get embedding status directly."""
    from dotenv import load_dotenv
    load_dotenv()

    from db.embeddings import embedding_status
    return embedding_status()


def _direct_analyze(query: str, timeframe: str = "auto", top_n: int = 10, include_summary: bool = True) -> dict:
    """Run combined analysis directly via Python imports."""
    from dotenv import load_dotenv
    load_dotenv()

    # Search
    search_result = _direct_search(query, timeframe, top_n)
    if "error" in search_result:
        return search_result

    results = search_result.get("results", [])
    if not results:
        return {**search_result, "follow_through": None, "outcome_distribution": None, "summary": None}

    # Follow-through
    ft = _direct_follow_through(results)

    # Outcome distribution
    rets_5d = ft.get("horizon_returns", {}).get(5, [])
    outcome_dist = None
    if rets_5d:
        clean = [r for r in rets_5d if r is not None]
        if clean:
            up = sum(1 for r in clean if r > 0)
            outcome_dist = {
                "up_count": up,
                "down_count": len(clean) - up,
                "total": len(clean),
                "median_return": round(sorted(clean)[len(clean) // 2], 2),
            }

    # Summary
    summary_text = None
    if include_summary:
        try:
            q = search_result["query"]
            label = f"{q['symbol']} {q['date']}"
            summary_result = _direct_summary(label, len(results), ft.get("horizon_returns", {}))
            summary_text = summary_result.get("summary")
        except Exception:
            pass

    return {
        **search_result,
        "follow_through": ft,
        "outcome_distribution": outcome_dist,
        "summary": summary_text,
    }


# ── Tool implementations ─────────────────────────────────────

@mcp.tool()
async def search_charts(query: str, timeframe: str = "auto", top_n: int = 10) -> str:
    """Search for historically similar chart patterns.

    Input a symbol and date (e.g. 'AAPL 2024-06-15') to find the top 10
    most similar historical charts from 800M+ minute bars.
    Results include match scores and similarity distances.

    Args:
        query: Symbol + date, e.g. 'AAPL 2024-06-15' or 'TSLA 6/15/24 3d'
        timeframe: Session: rth (regular hours), premarket, rth_3d, rth_5d, or auto
        top_n: Number of results (1-50)
    """
    try:
        if _use_http():
            result = _http_post("/api/v1/search/text", {
                "query": query, "timeframe": timeframe, "top_n": top_n,
            })
        else:
            result = _direct_search(query, timeframe, top_n)
        return json.dumps(result, default=str, indent=2)
    except Exception as e:
        return json.dumps({"error": str(e)})


@mcp.tool()
async def get_follow_through(results: list[dict]) -> str:
    """Get forward return analysis for search results.

    Pass the results from search_charts to see what happened 1, 3, 5, and 10
    days later in each historical match. Returns % returns and cumulative paths.

    Args:
        results: Search results from search_charts (list of {symbol, date, timeframe, metadata})
    """
    try:
        if _use_http():
            result = _http_post("/api/v1/follow-through", {"results": results})
        else:
            result = _direct_follow_through(results)
        return json.dumps(result, default=str, indent=2)
    except Exception as e:
        return json.dumps({"error": str(e)})


@mcp.tool()
async def get_pattern_summary(query_label: str, n_matches: int, horizon_returns: dict) -> str:
    """Generate an AI-written plain English summary of pattern search results.

    Returns a concise 2-3 sentence summary suitable for retail traders.

    Args:
        query_label: Human-readable query label (e.g. 'AAPL 2024-06-15')
        n_matches: Number of matches found
        horizon_returns: Forward returns dict {1: [...], 3: [...], 5: [...], 10: [...]}
    """
    try:
        if _use_http():
            result = _http_post("/api/v1/summary", {
                "query_label": query_label,
                "n_matches": n_matches,
                "horizon_returns": horizon_returns,
            })
        else:
            result = _direct_summary(query_label, n_matches, horizon_returns)
        return json.dumps(result, default=str, indent=2)
    except Exception as e:
        return json.dumps({"error": str(e)})


@mcp.tool()
async def get_status() -> str:
    """Get Chart Library database statistics.

    Returns total embeddings, coverage percentage, date range, and distinct symbols.
    """
    try:
        if _use_http():
            result = _http_get("/api/v1/status")
        else:
            result = _direct_status()
        return json.dumps(result, default=str, indent=2)
    except Exception as e:
        return json.dumps({"error": str(e)})


@mcp.tool()
async def analyze_pattern(query: str, timeframe: str = "auto", top_n: int = 10, include_summary: bool = True) -> str:
    """Complete pattern analysis in one call: search + follow-through + AI summary.

    This is the recommended tool for most use cases. It combines search_charts,
    get_follow_through, and get_pattern_summary into a single call.

    Returns matching patterns, forward return statistics (1/3/5/10 day),
    outcome distribution, and an AI-written summary.

    Args:
        query: Symbol + date, e.g. 'AAPL 2024-06-15' or 'TSLA 6/15/24 3d'
        timeframe: Session: rth (regular hours), premarket, rth_3d, rth_5d, or auto
        top_n: Number of results (1-50)
        include_summary: Whether to include AI-generated summary (default True)
    """
    try:
        if _use_http():
            result = _http_post("/api/v1/analyze", {
                "query": query, "timeframe": timeframe,
                "top_n": top_n, "include_summary": include_summary,
            })
        else:
            result = _direct_analyze(query, timeframe, top_n, include_summary)
        return json.dumps(result, default=str, indent=2)
    except Exception as e:
        return json.dumps({"error": str(e)})


@mcp.tool()
async def get_discover_picks(date: str = "", limit: int = 20) -> str:
    """Get top daily chart pattern picks ranked by interest score.

    Returns the most interesting patterns from the automated nightly scan,
    with AI summaries, predicted returns, and confidence scores.

    Args:
        date: Date in YYYY-MM-DD format (defaults to latest available)
        limit: Max picks to return (1-50, default 20)
    """
    try:
        if _use_http():
            params = f"?limit={limit}"
            if date:
                params += f"&date={date}"
            result = _http_get(f"/api/v1/discover/picks{params}")
        else:
            # Direct DB access for local mode
            from dotenv import load_dotenv
            load_dotenv()
            from db.connection import get_conn, put_conn
            conn = get_conn()
            try:
                with conn.cursor() as cur:
                    if date:
                        pick_date = date
                    else:
                        cur.execute("SELECT MAX(test_date)::text FROM forward_tests WHERE interest_score IS NOT NULL")
                        row = cur.fetchone()
                        pick_date = row[0] if row and row[0] else None

                    if not pick_date:
                        return json.dumps({"date": "", "picks": [], "count": 0})

                    cur.execute("""
                        SELECT symbol, test_date::text, direction, interest_score,
                               wpred_1d, wpred_5d, wpred_10d, n_matches, summary_text
                        FROM forward_tests
                        WHERE test_date = %s AND interest_score IS NOT NULL
                        ORDER BY interest_score DESC LIMIT %s
                    """, (pick_date, limit))
                    rows = cur.fetchall()
                    picks = [{
                        "symbol": r[0], "date": r[1], "direction": r[2],
                        "interest_score": r[3], "wpred_1d": r[4], "wpred_5d": r[5],
                        "wpred_10d": r[6], "n_matches": r[7], "summary_text": r[8],
                    } for r in rows]
            finally:
                put_conn(conn)
            result = {"date": pick_date, "picks": picks, "count": len(picks)}
        return json.dumps(result, default=str, indent=2)
    except Exception as e:
        return json.dumps({"error": str(e)})


@mcp.tool()
async def search_batch(symbols: list[str], date: str, timeframe: str = "rth", top_n: int = 10) -> str:
    """Search for similar patterns across multiple symbols at once.

    Batch version of search_charts — runs parallel searches for up to 20 symbols
    on the same date and returns forward return statistics for each.

    Args:
        symbols: List of ticker symbols (max 20), e.g. ['AAPL', 'MSFT', 'NVDA']
        date: Date in YYYY-MM-DD format
        timeframe: Session: rth, premarket, rth_3d, rth_5d (default rth)
        top_n: Number of results per symbol (1-50)
    """
    try:
        if _use_http():
            result = _http_post("/api/v1/search/batch", {
                "symbols": symbols, "date": date,
                "timeframe": timeframe, "top_n": top_n,
            })
        else:
            # Direct mode: run searches sequentially
            from dotenv import load_dotenv
            load_dotenv()
            from services.follow_through import compute_follow_through
            from services.stats_service import compute_stats

            batch_results = []
            for sym in symbols[:20]:
                try:
                    sr = _direct_search(f"{sym} {date}", timeframe, top_n)
                    results = sr.get("results", [])
                    if results:
                        ft = compute_follow_through(results, max_workers=1)
                        stats = compute_stats(ft["horizon_returns"])
                        batch_results.append({
                            "symbol": sym.upper(), "date": date,
                            "count": len(results),
                            "horizon_returns": ft["horizon_returns"],
                            "stats": stats,
                        })
                    else:
                        batch_results.append({
                            "symbol": sym.upper(), "date": date,
                            "count": 0, "horizon_returns": {}, "stats": {},
                        })
                except Exception as e:
                    batch_results.append({
                        "symbol": sym.upper(), "date": date,
                        "count": 0, "horizon_returns": {}, "stats": {},
                        "error": str(e),
                    })
            result = {"date": date, "timeframe": timeframe, "results": batch_results}
        return json.dumps(result, default=str, indent=2)
    except Exception as e:
        return json.dumps({"error": str(e)})


@mcp.tool()
async def report_feedback(message: str, endpoint: str = "", symbol: str = "", severity: str = "low") -> str:
    """Report an error, unexpected result, or suggestion to the Chart Library team.

    Use this when you encounter bad data, missing results, or have ideas for improvement.
    This helps the team improve the API for all agents.

    Args:
        message: What happened? (e.g., "NVDA returned 0 matches, expected data")
        endpoint: Which endpoint had the issue (e.g., "/api/v1/intelligence/NVDA")
        symbol: Ticker symbol if relevant
        severity: "low", "medium", or "high"
    """
    try:
        if _use_http():
            import requests
            url = f"{_API_BASE}/api/v1/feedback"
            headers = {"Content-Type": "application/json"}
            if _API_KEY:
                headers["Authorization"] = f"Bearer {_API_KEY}"
            resp = requests.post(url, json={
                "message": message,
                "endpoint": endpoint,
                "symbol": symbol,
                "severity": severity,
                "agent_name": "mcp-server",
            }, headers=headers, timeout=10)
            return json.dumps(resp.json())
        else:
            return json.dumps({"status": "ok", "message": "Feedback logged locally (no API key set)"})
    except Exception as e:
        return json.dumps({"error": str(e)})


# ── Market Intelligence tools ─────────────────────────────────

@mcp.tool()
async def detect_anomaly(symbol: str, date: str = "") -> str:
    """Check if a stock's current chart pattern is unusual compared to its history.

    Compares today's pattern embedding against the stock's historical distribution.
    A high anomaly score means the chart is behaving in a way rarely seen before —
    useful for flagging unusual moves, regime changes, or breakout setups.

    Args:
        symbol: Ticker symbol (e.g. 'AAPL')
        date: Date in YYYY-MM-DD format (defaults to most recent trading day)
    """
    try:
        params = f"?date={date}" if date else ""
        result = _http_get(f"/api/v1/anomaly/{symbol}{params}")
        return json.dumps(result, default=str, indent=2)
    except Exception as e:
        return json.dumps({"error": str(e)})


@mcp.tool()
async def get_volume_profile(symbol: str, date: str = "") -> str:
    """Get intraday volume breakdown by 30-minute intervals vs historical average.

    Shows how today's volume compares to the stock's typical trading pattern
    throughout the day. Useful for detecting unusual accumulation/distribution,
    front-loaded selling, or late-day surges that may signal institutional activity.

    Args:
        symbol: Ticker symbol (e.g. 'AAPL')
        date: Date in YYYY-MM-DD format (defaults to most recent trading day)
    """
    try:
        params = f"?date={date}" if date else ""
        result = _http_get(f"/api/v1/volume-profile/{symbol}{params}")
        return json.dumps(result, default=str, indent=2)
    except Exception as e:
        return json.dumps({"error": str(e)})


@mcp.tool()
async def get_sector_rotation(lookback: int = 5) -> str:
    """See which sectors are leading or lagging over recent trading days.

    Ranks the 11 S&P 500 sectors (XLK, XLF, XLE, XLV, etc.) by recent
    performance and momentum. Helps identify sector rotation trends —
    where institutional money is flowing to and from.

    Args:
        lookback: Number of trading days to analyze (default 5)
    """
    try:
        result = _http_get(f"/api/v1/sector-rotation?lookback={lookback}")
        return json.dumps(result, default=str, indent=2)
    except Exception as e:
        return json.dumps({"error": str(e)})


@mcp.tool()
async def get_crowding(date: str = "") -> str:
    """Check if too many stocks have the same bullish or bearish signal today.

    When the majority of pattern matches point the same direction, it can signal
    crowded positioning. Historically, extreme crowding readings (>80% one-sided)
    have preceded mean-reversion moves. Useful as a contrarian indicator.

    Args:
        date: Date in YYYY-MM-DD format (defaults to most recent trading day)
    """
    try:
        params = f"?date={date}" if date else ""
        result = _http_get(f"/api/v1/crowding{params}")
        return json.dumps(result, default=str, indent=2)
    except Exception as e:
        return json.dumps({"error": str(e)})


@mcp.tool()
async def get_earnings_reaction(symbol: str, min_gap: float = 3.0) -> str:
    """Historical analysis of how a stock reacts to earnings gaps.

    Looks at past instances where the stock gapped up or down by at least
    min_gap% on earnings, then shows what happened over the following days.
    Useful for earnings season preparation and gap-fade analysis.

    Args:
        symbol: Ticker symbol (e.g. 'AAPL')
        min_gap: Minimum gap size in percent to include (default 3.0)
    """
    try:
        result = _http_get(f"/api/v1/earnings-reaction/{symbol}?min_gap={min_gap}")
        return json.dumps(result, default=str, indent=2)
    except Exception as e:
        return json.dumps({"error": str(e)})


@mcp.tool()
async def get_correlation_shift(symbols: str = "", lookback: int = 0, window: int = 0) -> str:
    """Find stocks breaking away from their usual market correlation.

    Detects decorrelation events — when a stock's recent behavior diverges from
    its historical relationship with the broader market (SPY). Decorrelation
    can signal stock-specific catalysts, sector rotation, or regime shifts.

    Args:
        symbols: Comma-separated tickers to check (e.g. 'AAPL,MSFT,NVDA'). Defaults to top movers.
        lookback: Historical lookback period in days for baseline correlation
        window: Recent window in days to compare against baseline
    """
    try:
        params = []
        if symbols:
            params.append(f"symbols={symbols}")
        if lookback:
            params.append(f"lookback={lookback}")
        if window:
            params.append(f"window={window}")
        qs = f"?{'&'.join(params)}" if params else ""
        result = _http_get(f"/api/v1/correlation-shift{qs}")
        return json.dumps(result, default=str, indent=2)
    except Exception as e:
        return json.dumps({"error": str(e)})


@mcp.tool()
async def run_scenario(symbol: str, market_move_pct: float, horizon_days: int = 5) -> str:
    """What historically happens to a stock when the market moves X%?

    Finds historical days where SPY moved by a similar percentage, then shows
    how this specific stock performed over the following days. Useful for
    stress-testing positions — e.g., "What happens to NVDA if the market drops 3%?"

    Args:
        symbol: Ticker symbol (e.g. 'NVDA')
        market_move_pct: Hypothetical SPY move in percent (e.g. -3.0 for a 3% drop)
        horizon_days: How many days forward to analyze (default 5)
    """
    try:
        result = _http_post("/api/v1/scenario", {
            "symbol": symbol,
            "market_move_pct": market_move_pct,
            "horizon_days": horizon_days,
        })
        return json.dumps(result, default=str, indent=2)
    except Exception as e:
        return json.dumps({"error": str(e)})


# ── Trading Intelligence tools ────────────────────────────────

@mcp.tool()
async def get_regime_win_rates(symbol: str, date: str = "") -> str:
    """Get pattern win rates FILTERED BY CURRENT MARKET REGIME.

    Raw up_count (e.g. "8 of 10 went up") ignores market conditions.
    This tool shows how those same patterns performed specifically in the
    current regime (bull/bear x calm/volatile). Critical for avoiding
    bullish trades in bear markets where historical win rates collapse.

    Example: "8/10 went up overall, but in bear+calm regimes only 4/10 went up"

    Args:
        symbol: Ticker symbol (e.g. 'NVDA')
        date: Date in YYYY-MM-DD format (defaults to most recent)
    """
    try:
        params = f"?date={date}" if date else ""
        result = _http_get(f"/api/v1/regime-win-rates/{symbol}{params}")
        return json.dumps(result, default=str, indent=2)
    except Exception as e:
        return json.dumps({"error": str(e)})


@mcp.tool()
async def get_pattern_degradation(symbol: str = "", lookback_days: int = 30) -> str:
    """Check if pattern signals are degrading — are recent predictions less accurate than historical?

    Compares win rates from the last N days against the full historical average.
    If bullish patterns that used to work 60% of the time are now only working 40%,
    that's a degradation signal — the market regime may have shifted.

    Args:
        symbol: Optional ticker to check specific symbol (empty = all symbols)
        lookback_days: Number of recent days to compare against history (default 30)
    """
    try:
        params = [f"lookback_days={lookback_days}"]
        if symbol:
            params.append(f"symbol={symbol}")
        qs = f"?{'&'.join(params)}"
        result = _http_get(f"/api/v1/pattern-degradation{qs}")
        return json.dumps(result, default=str, indent=2)
    except Exception as e:
        return json.dumps({"error": str(e)})


@mcp.tool()
async def get_exit_signal(symbol: str, entry_date: str, side: str = "long", days_held: int = 0) -> str:
    """Pattern-based exit signal — should you take profits or hold?

    After entering a position, this tool checks what historically happened
    to similar patterns at this point in the trade. If most similar setups
    had already peaked by this holding period, it's time to exit.

    Args:
        symbol: Ticker symbol you're holding (e.g. 'NVDA')
        entry_date: Date you entered the trade (YYYY-MM-DD)
        side: 'long' or 'short'
        days_held: How many trading days you've held so far (default 0 = entry day)
    """
    try:
        result = _http_post("/api/v1/exit-signal", {
            "symbol": symbol,
            "entry_date": entry_date,
            "side": side,
            "days_held": days_held,
        })
        return json.dumps(result, default=str, indent=2)
    except Exception as e:
        return json.dumps({"error": str(e)})


@mcp.tool()
async def get_risk_adjusted_picks(date: str = "", min_sharpe: float = 0.3) -> str:
    """Get today's picks scored by risk-adjusted return instead of raw interest score.

    Replaces simple win-count with a Sharpe-like metric: predicted_return / volatility.
    A stock predicted to return +2% with tight return range (low vol) scores higher
    than one predicted +5% with wild dispersion. Helps avoid high-variance traps.

    Args:
        date: Date in YYYY-MM-DD format (defaults to most recent)
        min_sharpe: Minimum risk-adjusted score to include (default 0.3)
    """
    try:
        params = [f"min_sharpe={min_sharpe}"]
        if date:
            params.append(f"date={date}")
        qs = f"?{'&'.join(params)}"
        result = _http_get(f"/api/v1/risk-adjusted-picks{qs}")
        return json.dumps(result, default=str, indent=2)
    except Exception as e:
        return json.dumps({"error": str(e)})


# ── Entry point ──────────────────────────────────────────────

def main():
    """Entry point for console script and direct execution."""
    transport = os.getenv("MCP_TRANSPORT", "stdio")
    mcp.run(transport=transport)


if __name__ == "__main__":
    main()
