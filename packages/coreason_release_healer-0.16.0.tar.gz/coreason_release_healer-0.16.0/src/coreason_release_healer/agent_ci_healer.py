#!/usr/bin/env python3
"""
CoReason CI/CD Self-Healing Assistant
Queries GitHub Actions, downloads failure logs via GitHub CLI, and monitors release runs.
"""

import os
import sys
import json
import subprocess
import argparse
import time
import re
import ast
from datetime import datetime, timezone
from loguru import logger

def get_workspace_dir(file_path):
    # Try finding based on cwd
    cwd = os.getcwd()
    if os.path.exists(os.path.join(cwd, "coreason-release-healer")) or os.path.exists(os.path.join(cwd, "coreason-infrastructure")):
        return cwd
    if os.path.basename(cwd) in ("coreason-release-healer", "coreason-infrastructure"):
        return os.path.dirname(cwd)
        
    # Fallback to file path traversal
    path = os.path.abspath(file_path)
    curr = os.path.dirname(path)
    while True:
        parent = os.path.dirname(curr)
        if parent == curr:  # reached root
            break
        if os.path.exists(os.path.join(curr, "coreason-release-healer")) or os.path.exists(os.path.join(curr, "coreason-infrastructure")):
            return curr
        if os.path.basename(curr) in ("coreason-release-healer", "coreason-infrastructure"):
            return parent
        curr = parent
        
    # Final fallback
    return os.getcwd()

# Resolve workspace directory
WORKSPACE_DIR = get_workspace_dir(__file__)

# Setup environment variables for logging and reporting
COREASON_LOG_PATH = os.environ.get("COREASON_LOG_PATH")
COREASON_REPORT_PATH = os.environ.get("COREASON_REPORT_PATH") or os.path.join(WORKSPACE_DIR, "coreason_release_report.md")

def configure_logging(log_path=None):
    # Configure Loguru logging
    logger.remove()  # Remove default handler
    log_format = (
        "<green>{time:YYYY-MM-DD HH:mm:ss.SSS}</green> | "
        "<level>{level: <8}</level> | "
        "<cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> - "
        "<level>{message}</level>"
    )

    # Add colorized console handler
    logger.add(sys.stderr, format=log_format, colorize=True, level="INFO")

    # Add detailed file logging
    target_log_path = log_path or COREASON_LOG_PATH
    if target_log_path:
        try:
            log_dir = os.path.dirname(os.path.abspath(target_log_path))
            if log_dir:
                os.makedirs(log_dir, exist_ok=True)
            logger.add(target_log_path, format=log_format, level="DEBUG", rotation="10 MB", encoding="utf-8")
        except Exception as e:
            # Fallback if custom path fails
            print(f"Warning: Failed to configure logger for custom path '{target_log_path}': {e}", file=sys.stderr)
            target_log_path = None

    if not target_log_path:
        default_log_dir = os.path.join(WORKSPACE_DIR, ".coreason")
        os.makedirs(default_log_dir, exist_ok=True)
        default_log_path = os.path.join(default_log_dir, "healer_detailed.log")
        logger.add(default_log_path, format=log_format, level="DEBUG", rotation="10 MB", encoding="utf-8")

# Initialize default logging
configure_logging()

# ANSI color codes for premium CLI output
COLOR_GREEN = "\033[92m"
COLOR_YELLOW = "\033[93m"
COLOR_RED = "\033[91m"
COLOR_CYAN = "\033[96m"
COLOR_MAGENTA = "\033[95m"
COLOR_BOLD = "\033[1m"
COLOR_RESET = "\033[0m"

REPOS = [
    "coreason-manifest",
    "coreason-sensory-core",
    "coreason-urn-authority",
    "coreason-ecosystem",
    "coreason-isv-admin",
    "coreason-sensory-app",
    "coreason-sensory-embed",
    "coreason-runtime",
    "coreason-meta-engineering",
    "coreason-documentation",
    "coreason-release-healer"
]

def log_info(msg):
    logger.info(msg)

def log_success(msg):
    logger.success(msg)

def log_warning(msg):
    logger.warning(msg)

def log_error(msg):
    logger.error(msg)


class ReleaseTracker:
    def __init__(self, repos):
        self.repos = repos
        self.start_time = datetime.now(timezone.utc)
        # Map of repo -> state dict
        self.states = {repo: {
            "run_id": None,
            "initial_status": "Unknown",
            "initial_conclusion": "Unknown",
            "healing_applied": [],
            "final_status": "Unknown",
            "final_conclusion": "Unknown",
            "tag": None,
            "last_checked": None
        } for repo in repos}

    def update_run(self, repo, run_id, status, conclusion, tag):
        if repo not in self.states:
            return
        state = self.states[repo]
        state["run_id"] = run_id
        state["tag"] = tag
        state["last_checked"] = datetime.now(timezone.utc).isoformat()
        
        # Capture initial state if unset
        if state["initial_status"] == "Unknown":
            state["initial_status"] = status
            state["initial_conclusion"] = conclusion or "pending"
            
        state["final_status"] = status
        state["final_conclusion"] = conclusion or "pending"

    def add_healing(self, repo, action):
        if repo not in self.states:
            return
        if action not in self.states[repo]["healing_applied"]:
            self.states[repo]["healing_applied"].append(action)

    def generate_report_markdown(self):
        duration = datetime.now(timezone.utc) - self.start_time
        duration_str = format_duration(duration.total_seconds())
        
        total = len(self.repos)
        succeeded = sum(1 for r in self.repos if self.states[r]["final_conclusion"] == "success")
        failed = sum(1 for r in self.repos if self.states[r]["final_conclusion"] == "failure")
        pending = total - succeeded - failed
        healed_repos = [r for r in self.repos if self.states[r]["healing_applied"]]
        
        md = []
        md.append("# CoReason CI/CD Release & Self-Healing Report")
        md.append(f"\nGenerated at: `{datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC')}`")
        md.append(f"Monitoring Duration: `{duration_str}`")
        
        md.append("\n## Release Summary Metrics")
        md.append(f"- **Total Repositories Monitored**: {total}")
        md.append(f"- **Succeeded**: {succeeded} / {total} ({(succeeded/total)*100:.1f}%)" if total > 0 else f"- **Succeeded**: {succeeded}")
        md.append(f"- **Failed**: {failed} / {total}")
        md.append(f"- **In Progress / Pending**: {pending}")
        md.append(f"- **Repositories Healed**: {len(healed_repos)} ({', '.join(healed_repos) if healed_repos else 'None'})")
        
        md.append("\n## Repository Status Details")
        md.append("| Repository | Run ID | Tag | Initial State | Final State | Healing Applied |")
        md.append("| :--- | :--- | :--- | :--- | :--- | :--- |")
        for repo in self.repos:
            state = self.states[repo]
            run_id_val = f"[{state['run_id']}](https://github.com/CoReason-AI/{repo}/actions/runs/{state['run_id']})" if state['run_id'] else "N/A"
            tag_val = f"`{state['tag']}`" if state['tag'] else "N/A"
            initial = f"`{state['initial_status'].upper()}` / `{state['initial_conclusion'].upper()}`"
            final = f"`{state['final_status'].upper()}` / `{state['final_conclusion'].upper()}`"
            
            if state["healing_applied"]:
                healing = ", ".join(f"`{h}`" for h in state["healing_applied"])
            else:
                healing = "_None_"
                
            md.append(f"| [{repo}](https://github.com/CoReason-AI/{repo}) | {run_id_val} | {tag_val} | {initial} | {final} | {healing} |")
            
        md.append("\n## Healing Log & Diagnoses")
        has_diagnoses = False
        for repo in self.repos:
            state = self.states[repo]
            if state["healing_applied"]:
                has_diagnoses = True
                md.append(f"\n### {repo}")
                md.append(f"- **Tag**: `{state['tag']}`")
                md.append(f"- **Initial Conclusion**: `{state['initial_conclusion']}`")
                md.append("- **Applied Modifications**:")
                for action in state["healing_applied"]:
                    md.append(f"  - {action}")
        if not has_diagnoses:
            md.append("\n_No healing operations were triggered._")
            
        return "\n".join(md) + "\n"

    def write_report(self, report_path):
        try:
            os.makedirs(os.path.dirname(report_path), exist_ok=True)
            content = self.generate_report_markdown()
            with open(report_path, "w", encoding="utf-8") as f:
                f.write(content)
            logger.info(f"Release report successfully written/updated at: {report_path}")
        except Exception as e:
            logger.error(f"Failed to write release report to {report_path}: {e}")


def run_cmd(cmd, cwd=None):
    try:
        res = subprocess.run(cmd, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, encoding="utf-8", errors="replace", check=True)
        return res.stdout.strip()
    except subprocess.CalledProcessError as e:
        err_msg = (e.stderr or "").strip() or (e.stdout or "").strip()
        return f"ERROR: {err_msg}"
    except Exception as e:
        return f"ERROR: {str(e)}"

def check_gh_cli():
    if "GITHUB_TOKEN" in os.environ:
        status = run_cmd(["gh", "auth", "status"])
        if "ERROR" in status or "Failed to log in" in status:
            log_warning("GITHUB_TOKEN in environment is invalid. Popping GITHUB_TOKEN to fall back to keyring/gh auth.")
            del os.environ["GITHUB_TOKEN"]
            
    status = run_cmd(["gh", "auth", "status"])
    if "ERROR" in status:
        log_error("GitHub CLI ('gh') is either not installed or not authenticated.")
        log_error("Please authenticate first by running: gh auth login")
        return False
    log_info("GitHub CLI ('gh') is authenticated successfully.")
    return True

def ensure_uv_updated():
    log_info("Ensuring uv is up-to-date...")
    
    # 1. Try standalone update via "uv self update"
    res = run_cmd(["uv", "self", "update"])
    if "ERROR" not in res and "Self-update is only available" not in res:
        log_success(f"uv successfully updated: {res}")
        return
        
    # 2. Try upgrading via pip
    log_info("uv self update is not supported for this installation. Attempting upgrade via pip...")
    pip_cmd = [sys.executable, "-m", "pip", "install", "--upgrade", "uv"]
    pip_res = run_cmd(pip_cmd)
    if "ERROR" not in pip_res:
        ver_res = run_cmd(["uv", "--version"])
        log_success(f"uv successfully updated via pip. Current version: {ver_res}")
    else:
        log_warning(f"Could not update uv automatically: {pip_res}. Please ensure uv is up-to-date manually.")

def get_failed_repo_from_file(failure_path):
    if not os.path.exists(failure_path):
        return None
    try:
        with open(failure_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data.get("repo")
    except Exception as e:
        log_warning(f"Could not read failure file {failure_path}: {e}")
        return None

def get_latest_runs(repo, limit=1):
    # Retrieve runs for CoReason-AI/<repo>
    cmd = [
        "gh", "run", "list",
        "--repo", f"CoReason-AI/{repo}",
        "--limit", str(limit),
        "--json", "databaseId,status,conclusion,name,headBranch,createdAt"
    ]
    out = run_cmd(cmd)
    if "ERROR" in out:
        log_warning(f"Failed to fetch runs for {repo}: {out}")
        return []
    try:
        return json.loads(out)
    except json.JSONDecodeError:
        return []

STATUS_COLORS = {
    "success": COLOR_GREEN,
    "failure": COLOR_RED,
    "failed": COLOR_RED,
    "skipped": "\033[90m", # Gray / Dimmed
    "cancelled": "\033[90m",
    "in_progress": COLOR_YELLOW,
    "queued": COLOR_YELLOW,
    "waiting": COLOR_YELLOW,
    "pending": COLOR_YELLOW,
}

def parse_iso_datetime(dt_str):
    if not dt_str:
        return None
    # Handle Zulu time zone
    if dt_str.endswith('Z'):
        dt_str = dt_str[:-1] + '+00:00'
    try:
        return datetime.fromisoformat(dt_str)
    except Exception:
        return None

def format_duration(seconds):
    if seconds < 0:
        seconds = 0
    minutes, secs = divmod(int(seconds), 60)
    hours, minutes = divmod(minutes, 60)
    if hours > 0:
        return f"{hours}h {minutes}m {secs}s"
    elif minutes > 0:
        return f"{minutes}m {secs}s"
    else:
        return f"{secs}s"

def get_duration_str(started_at, completed_at, status):
    start = parse_iso_datetime(started_at)
    if not start:
        return ""
    
    end = parse_iso_datetime(completed_at)
    if not end:
        if status in ["in_progress", "queued", "waiting", "requested", "active"]:
            if start.tzinfo is not None:
                end = datetime.now(timezone.utc)
            else:
                end = datetime.utcnow()
        else:
            return ""
            
    # Normalize tzinfo to prevent offset-naive/offset-aware subtraction TypeError
    if start.tzinfo is not None and end.tzinfo is None:
        start = start.replace(tzinfo=None)
    elif start.tzinfo is None and end.tzinfo is not None:
        end = end.replace(tzinfo=None)
        
    diff = end - start
    return format_duration(diff.total_seconds())

def get_status_info(status, conclusion):
    state = conclusion or status or "unknown"
    state = state.lower()
    color = STATUS_COLORS.get(state, COLOR_RESET)
    label = state.upper()
    return label, color

def get_run_jobs(repo, run_id):
    cmd = [
        "gh", "run", "view", str(run_id),
        "--repo", f"CoReason-AI/{repo}",
        "--json", "jobs"
    ]
    out = run_cmd(cmd)
    if "ERROR" in out:
        log_warning(f"Failed to fetch jobs/steps for {repo} (Run ID: {run_id}): {out}")
        return []
    try:
        data = json.loads(out)
        if isinstance(data, dict):
            return data.get("jobs", [])
        elif isinstance(data, list):
            return data
        return []
    except json.JSONDecodeError:
        log_warning(f"Failed to parse jobs JSON for {repo} (Run ID: {run_id})")
        return []

def safe_print_text(text):
    try:
        print(text)
    except UnicodeEncodeError:
        try:
            enc = sys.stdout.encoding or 'utf-8'
            print(text.encode(enc, errors='replace').decode(enc))
        except Exception:
            sys.stdout.buffer.write(text.encode('utf-8', errors='replace') + b'\n')

def print_tree_line(prefix, step_color, step_state_label, step_name, duration_part):
    line = f"  {prefix}{step_color}[{step_state_label}]{COLOR_RESET} {step_name}{duration_part}"
    try:
        print(line)
    except UnicodeEncodeError:
        # Fallback to pure ASCII representation if terminal doesn't support box-drawing chars
        ascii_prefix = prefix.replace("├──", "|--").replace("└──", "`--").replace("─", "-")
        ascii_line = f"  {ascii_prefix}{step_color}[{step_state_label}]{COLOR_RESET} {step_name}{duration_part}"
        try:
            print(ascii_line)
        except Exception:
            sys.stdout.buffer.write(line.encode('utf-8', errors='replace') + b'\n')

def print_run_telemetry(repo, run_id):
    logger.info(f"Retrieving telemetry for {repo} (Run ID: {run_id})...")
    jobs = get_run_jobs(repo, run_id)
    if not jobs:
        log_info(f"No telemetry jobs retrieved for run {run_id}.")
        return
        
    print(f"\n{COLOR_CYAN}{COLOR_BOLD}=== RUN TELEMETRY FOR {repo} (Run: {run_id}) ==={COLOR_RESET}")
    logger.debug(f"=== RUN TELEMETRY FOR {repo} (Run: {run_id}) ===")
    for job in jobs:
        job_name = job.get("name", "Unnamed Job")
        job_status = job.get("status", "unknown")
        job_conclusion = job.get("conclusion")
        
        job_state_label, job_color = get_status_info(job_status, job_conclusion)
        job_duration = get_duration_str(job.get("startedAt"), job.get("completedAt"), job_status)
        duration_part = f" [{job_duration}]" if job_duration else ""
        
        print(f"\nJob: {COLOR_BOLD}{job_name}{COLOR_RESET} - {job_color}{job_state_label}{COLOR_RESET}{duration_part}")
        logger.debug(f"Job: {job_name} - {job_state_label}{duration_part}")
        
        steps = job.get("steps", [])
        num_steps = len(steps)
        for idx, step in enumerate(steps):
            step_name = step.get("name", "Unnamed Step")
            step_status = step.get("status", "unknown")
            step_conclusion = step.get("conclusion")
            
            step_state_label, step_color = get_status_info(step_status, step_conclusion)
            step_duration = get_duration_str(step.get("startedAt"), step.get("completedAt"), step_status)
            duration_part = f" ({step_duration})" if step_duration else ""
            
            prefix = "└── " if idx == num_steps - 1 else "├── "
            print_tree_line(prefix, step_color, step_state_label, step_name, duration_part)
            logger.debug(f"  Step: {step_name} - {step_state_label}{duration_part}")
    print("=" * 80)

def get_run_failure_logs(repo, run_id):
    log_info(f"Retrieving logs for CoReason-AI/{repo} (Run ID: {run_id})...")
    cmd = [
        "gh", "run", "view", str(run_id),
        "--repo", f"CoReason-AI/{repo}",
        "--log"
    ]
    logs = run_cmd(cmd)
    if "ERROR" in logs:
        return f"Could not retrieve logs: {logs}"
        
    # Parse logs and extract lines containing error signals
    error_patterns = [
        re.compile(r'error', re.IGNORECASE),
        re.compile(r'fail', re.IGNORECASE),
        re.compile(r'exception', re.IGNORECASE),
        re.compile(r'traceback', re.IGNORECASE),
        re.compile(r'assert', re.IGNORECASE),
        re.compile(r'npm ERR!'),
        re.compile(r'exit status \d+')
    ]
    
    extracted_lines = []
    lines = logs.splitlines()
    for idx, line in enumerate(lines):
        for pattern in error_patterns:
            if pattern.search(line):
                # Include context (previous 2 lines and next line) if helpful
                context = []
                start = max(0, idx - 2)
                end = min(len(lines), idx + 2)
                for c_idx in range(start, end):
                    prefix = "--> " if c_idx == idx else "    "
                    context.append(f"{prefix}{lines[c_idx]}")
                extracted_lines.append("\n".join(context))
                break
                
    if not extracted_lines:
        logger.debug(f"No explicit error patterns matched in logs for {repo} (Run ID: {run_id})")
        return "No explicit error lines identified. Full logs might be required."
        
    # Cap the results to avoid flooding output
    max_errors = 10
    if len(extracted_lines) > max_errors:
        summary = extracted_lines[:max_errors]
        summary.append(f"\n... (truncated {len(extracted_lines) - max_errors} more error occurrences)")
        summary_text = "\n\n".join(summary)
    else:
        summary_text = "\n\n".join(extracted_lines)
        
    logger.debug(f"Extracted failures for {repo} (Run ID: {run_id}):\n{summary_text}")
    return summary_text

def add_skip_existing_to_workflow(file_path):
    with open(file_path, "r", encoding="utf-8") as f:
        content = f.read()
    
    lines = content.splitlines()
    modified = False
    i = 0
    while i < len(lines):
        line = lines[i]
        if "uses: pypa/gh-action-pypi-publish" in line:
            indent = len(line) - len(line.lstrip())
            
            has_with = False
            with_idx = -1
            j = i + 1
            while j < len(lines) and (not lines[j].strip() or len(lines[j]) - len(lines[j].lstrip()) > indent):
                if "with:" in lines[j]:
                    has_with = True
                    with_idx = j
                    break
                j += 1
            
            if has_with:
                has_skip = False
                k = with_idx + 1
                with_indent = len(lines[with_idx]) - len(lines[with_idx].lstrip())
                while k < len(lines) and (not lines[k].strip() or len(lines[k]) - len(lines[k].lstrip()) > with_indent):
                    if "skip-existing" in lines[k]:
                        has_skip = True
                        break
                    k += 1
                
                if not has_skip:
                    sub_indent = " " * (with_indent + 2)
                    lines.insert(with_idx + 1, f"{sub_indent}skip-existing: true")
                    modified = True
            else:
                sub_indent = " " * indent
                lines.insert(i + 1, f"{sub_indent}with:")
                lines.insert(i + 2, f"{sub_indent}  skip-existing: true")
                modified = True
                i += 2
        i += 1
        
    if modified:
        with open(file_path, "w", encoding="utf-8", newline="\n") as f:
            f.write("\n".join(lines) + "\n")
        return True
    return False

def add_packages_write_to_workflow(file_path):
    with open(file_path, "r", encoding="utf-8") as f:
        content = f.read()
        
    lines = content.splitlines()
    modified = False
    
    runs_on_indices = []
    for idx, line in enumerate(lines):
        if "runs-on:" in line and not line.strip().startswith("#"):
            runs_on_indices.append(idx)
            
    for r_idx in reversed(runs_on_indices):
        runs_on_line = lines[r_idx]
        
        # Find job indentation by walking upwards to the job name
        job_indent = 0
        for m in range(r_idx - 1, -1, -1):
            strip_m = lines[m].strip()
            if strip_m and not strip_m.startswith("#"):
                job_indent = len(lines[m]) - len(lines[m].lstrip())
                break
                
        # Find where this job ends
        end_idx = len(lines)
        for j in range(r_idx + 1, len(lines)):
            strip_j = lines[j].strip()
            if not strip_j or strip_j.startswith("#"):
                continue
            curr_indent = len(lines[j]) - len(lines[j].lstrip())
            if curr_indent <= job_indent:
                end_idx = j
                break
                
        job_lines = lines[r_idx:end_idx]
        job_text = "\n".join(job_lines)
        
        is_container_job = any(pat in job_text for pat in ["docker/build-push-action", "docker/login-action", "ghcr.io", "helm push"])
        if not is_container_job:
            continue
            
        has_permissions = False
        permissions_idx = -1
        has_packages_write = False
        
        for k in range(r_idx + 1, end_idx):
            line_k = lines[k]
            if "permissions:" in line_k and not line_k.strip().startswith("#"):
                has_permissions = True
                permissions_idx = k
                p_indent = len(line_k) - len(line_k.lstrip())
                for m in range(k + 1, end_idx):
                    strip_m = lines[m].strip()
                    if not strip_m or strip_m.startswith("#"):
                        continue
                    m_indent = len(lines[m]) - len(lines[m].lstrip())
                    if m_indent <= p_indent:
                        break
                    if "packages: write" in lines[m]:
                        has_packages_write = True
                        break
                break
                
        if has_permissions:
            if not has_packages_write:
                p_line = lines[permissions_idx]
                p_indent_val = len(p_line) - len(p_line.lstrip())
                sub_indent = " " * (p_indent_val + 2)
                lines.insert(permissions_idx + 1, f"{sub_indent}packages: write")
                modified = True
        else:
            r_line = lines[r_idx]
            r_indent_val = len(r_line) - len(r_line.lstrip())
            sub_indent = " " * (r_indent_val + 2)
            lines.insert(r_idx + 1, f"{' ' * r_indent_val}permissions:")
            lines.insert(r_idx + 2, f"{sub_indent}packages: write")
            lines.insert(r_idx + 3, f"{sub_indent}contents: read")
            modified = True
            
    if modified:
        with open(file_path, "w", encoding="utf-8", newline="\n") as f:
            f.write("\n".join(lines) + "\n")
        return True
    return False

def add_pages_write_to_workflow(file_path):
    with open(file_path, "r", encoding="utf-8") as f:
        content = f.read()
        
    lines = content.splitlines()
    modified = False
    
    runs_on_indices = []
    for idx, line in enumerate(lines):
        if "runs-on:" in line and not line.strip().startswith("#"):
            runs_on_indices.append(idx)
            
    for r_idx in reversed(runs_on_indices):
        runs_on_line = lines[r_idx]
        
        job_indent = 0
        for m in range(r_idx - 1, -1, -1):
            strip_m = lines[m].strip()
            if strip_m and not strip_m.startswith("#"):
                job_indent = len(lines[m]) - len(lines[m].lstrip())
                break
                
        end_idx = len(lines)
        for j in range(r_idx + 1, len(lines)):
            strip_j = lines[j].strip()
            if not strip_j or strip_j.startswith("#"):
                continue
            curr_indent = len(lines[j]) - len(lines[j].lstrip())
            if curr_indent <= job_indent:
                end_idx = j
                break
                
        job_lines = lines[r_idx:end_idx]
        job_text = "\n".join(job_lines)
        
        is_pages_job = any(pat in job_text for pat in ["actions/deploy-pages", "actions/upload-pages-artifact"])
        if not is_pages_job:
            continue
            
        has_permissions = False
        permissions_idx = -1
        has_pages_write = False
        has_id_token_write = False
        
        for k in range(r_idx + 1, end_idx):
            line_k = lines[k]
            if "permissions:" in line_k and not line_k.strip().startswith("#"):
                has_permissions = True
                permissions_idx = k
                p_indent = len(line_k) - len(line_k.lstrip())
                for m in range(k + 1, end_idx):
                    strip_m = lines[m].strip()
                    if not strip_m or strip_m.startswith("#"):
                        continue
                    m_indent = len(lines[m]) - len(lines[m].lstrip())
                    if m_indent <= p_indent:
                        break
                    if "pages: write" in lines[m]:
                        has_pages_write = True
                    if "id-token: write" in lines[m]:
                        has_id_token_write = True
                break
                
        if has_permissions:
            p_line = lines[permissions_idx]
            p_indent_val = len(p_line) - len(p_line.lstrip())
            sub_indent = " " * (p_indent_val + 2)
            if not has_pages_write:
                lines.insert(permissions_idx + 1, f"{sub_indent}pages: write")
                permissions_idx += 1
                modified = True
            if not has_id_token_write:
                lines.insert(permissions_idx + 1, f"{sub_indent}id-token: write")
                modified = True
        else:
            r_line = lines[r_idx]
            r_indent_val = len(r_line) - len(r_line.lstrip())
            sub_indent = " " * (r_indent_val + 2)
            lines.insert(r_idx + 1, f"{' ' * r_indent_val}permissions:")
            lines.insert(r_idx + 2, f"{sub_indent}pages: write")
            lines.insert(r_idx + 3, f"{sub_indent}id-token: write")
            lines.insert(r_idx + 4, f"{sub_indent}contents: read")
            modified = True
            
    if modified:
        with open(file_path, "w", encoding="utf-8", newline="\n") as f:
            f.write("\n".join(lines) + "\n")
        return True
    return False

def configure_github_pages_api(repo):
    log_info(f"Configuring GitHub Pages build source to 'workflow' via API for {repo}...")
    cmd = [
        "gh", "api",
        "--method", "PATCH",
        f"/repos/CoReason-AI/{repo}/pages",
        "-f", "build_type=workflow"
    ]
    res = run_cmd(cmd)
    if "ERROR" in res:
        log_warning(f"Could not update Pages config: {res}. Attempting to enable Pages first...")
        cmd_enable = [
            "gh", "api",
            "--method", "POST",
            f"/repos/CoReason-AI/{repo}/pages",
            "-f", "source[branch]=main",
            "-f", "source[path]=/"
        ]
        res_enable = run_cmd(cmd_enable)
        if "ERROR" in res_enable:
            log_error(f"Failed to enable GitHub Pages: {res_enable}")
            return False
            
        res_patch = run_cmd(cmd)
        if "ERROR" in res_patch:
            log_error(f"Failed to update Pages build_type to workflow: {res_patch}")
            return False
            
    log_success(f"Successfully configured GitHub Pages to workflow build source for {repo}.")
    return True

def commit_and_push_workflow_changes(repo_dir, commit_message):
    run_cmd(["git", "add", ".github/workflows"], cwd=repo_dir)
    res_commit = run_cmd(["git", "commit", "-m", commit_message], cwd=repo_dir)
    if "ERROR" in res_commit and "nothing to commit" not in res_commit.lower():
        log_error(f"Failed to commit workflow changes in {repo_dir}: {res_commit}")
        return False
        
    # Pull with rebase to ensure we are up-to-date with remote commits
    res_pull = run_cmd(["git", "pull", "--rebase", "origin", "main"], cwd=repo_dir)
    if "ERROR" in res_pull:
        log_error(f"Failed to pull remote changes in {repo_dir}: {res_pull}")
        return False
        
    res_push = run_cmd(["git", "push", "origin", "main"], cwd=repo_dir)
    if "ERROR" in res_push:
        log_error(f"Failed to push workflow changes in {repo_dir}: {res_push}")
        return False
        
    log_success(f"Committed, pulled/rebased, and pushed workflow changes for {os.path.basename(repo_dir)}.")
    return True

def re_tag_release(repo_dir, tag_name):
    log_info(f"Re-tagging version {tag_name} in {os.path.basename(repo_dir)}...")
    res_del_local = run_cmd(["git", "tag", "-d", tag_name], cwd=repo_dir)
    if "ERROR" in res_del_local and "not found" not in res_del_local.lower():
        log_warning(f"Could not delete local tag {tag_name}: {res_del_local}")
        
    res_del_remote = run_cmd(["git", "push", "origin", f":refs/tags/{tag_name}"], cwd=repo_dir)
    if "ERROR" in res_del_remote:
        log_warning(f"Could not delete remote tag {tag_name}: {res_del_remote}")
        
    time.sleep(2)
    
    res_add_local = run_cmd(["git", "tag", tag_name], cwd=repo_dir)
    if "ERROR" in res_add_local:
        log_error(f"Failed to create local tag {tag_name}: {res_add_local}")
        return False
        
    res_push_tag = run_cmd(["git", "push", "origin", tag_name], cwd=repo_dir)
    if "ERROR" in res_push_tag:
        log_error(f"Failed to push tag {tag_name}: {res_push_tag}")
        return False
        
    log_success(f"Successfully re-tagged {tag_name} in {os.path.basename(repo_dir)}.")
    return True

def rewrite_code_via_ast(file_content, violations):
    """
    Parses Python file content, applies AST-based analysis to locate the exact nodes
    representing the violations, and performs precise code rewriting.
    """
    try:
        tree = ast.parse(file_content)
    except Exception as e:
        logger.error(f"Failed to parse AST: {e}")
        return file_content, False, []

    # First pass: analyze imports to find aliases for 'random'
    random_aliases = set()
    from_random_imports = {} # name -> alias/name
    
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                if alias.name == "random":
                    random_aliases.add(alias.asname or "random")
        elif isinstance(node, ast.ImportFrom):
            if node.module == "random":
                for alias in node.names:
                    from_random_imports[alias.name] = alias.asname or alias.name

    lines = file_content.splitlines()
    modified = False
    need_import_random = False
    edits_applied = []
    
    # Sort violations descending by line number to handle any potential multi-line shifts safely
    violations = sorted(violations, key=lambda x: x["line"], reverse=True)
    
    for viol in violations:
        code = viol["code"]
        line_num = viol["line"]
        target_name = viol.get("name")
        
        idx = line_num - 1
        if idx < 0 or idx >= len(lines):
            continue
            
        # Find AST nodes on this specific line
        nodes_on_line = []
        for node in ast.walk(tree):
            if hasattr(node, "lineno") and node.lineno == line_num:
                nodes_on_line.append(node)
                
        if code in ["S311", "B311"]:
            # Look for Calls to random functions on this line
            healed_call = False
            for node in nodes_on_line:
                if isinstance(node, ast.Call):
                    # Case A: random.choice(...) -> random.SystemRandom().choice(...)
                    if isinstance(node.func, ast.Attribute):
                        if isinstance(node.func.value, ast.Name) and node.func.value.id in random_aliases:
                            col_start = node.func.value.col_offset
                            col_end = node.func.value.end_col_offset
                            line_str = lines[idx]
                            
                            if line_str[col_start:col_end] in random_aliases:
                                new_line = line_str[:col_start] + "random.SystemRandom()" + line_str[col_end:]
                                lines[idx] = new_line
                                modified = True
                                healed_call = True
                                edits_applied.append(f"Rewrote insecure random call on line {line_num} to use SystemRandom")
                                break
                    # Case B: choice(...) where choice was imported from random
                    elif isinstance(node.func, ast.Name) and node.func.id in from_random_imports.values():
                        col_start = node.func.col_offset
                        col_end = node.func.end_col_offset
                        line_str = lines[idx]
                        name_used = node.func.id
                        
                        new_line = line_str[:col_start] + "random.SystemRandom()." + name_used + line_str[col_end:]
                        lines[idx] = new_line
                        modified = True
                        healed_call = True
                        if not random_aliases:
                            need_import_random = True
                        edits_applied.append(f"Rewrote imported random call '{name_used}' on line {line_num} to use SystemRandom")
                        break
            
            if not healed_call:
                # Fallback to appending noqa comment
                line_str = lines[idx]
                if "# noqa: S311" not in line_str and "# nosec" not in line_str:
                    lines[idx] = f"{line_str}  # noqa: S311  # nosec"
                    modified = True
                    edits_applied.append(f"Added noqa: S311 to line {line_num}")
                    
        elif code == "ARG001":
            healed_arg = False
            for node in ast.walk(tree):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    for arg in node.args.args + node.args.kwonlyargs:
                        if arg.lineno == line_num and (not target_name or arg.arg == target_name):
                            line_str = lines[idx]
                            if "# noqa: ARG001" not in line_str:
                                lines[idx] = f"{line_str}  # noqa: ARG001"
                                modified = True
                                healed_arg = True
                                edits_applied.append(f"Added noqa: ARG001 to unused argument '{arg.arg}' on line {line_num}")
                                break
                    if healed_arg:
                        break
            
            if not healed_arg:
                line_str = lines[idx]
                if "# noqa: ARG001" not in line_str:
                    lines[idx] = f"{line_str}  # noqa: ARG001"
                    modified = True
                    edits_applied.append(f"Added noqa: ARG001 to line {line_num}")

    if need_import_random and "random" not in random_aliases:
        # Find docstrings or futures to insert after
        insert_line_idx = 0
        for node in tree.body:
            if isinstance(node, ast.Expr) and isinstance(node.value, ast.Constant) and isinstance(node.value.value, str):
                insert_line_idx = node.end_lineno
            elif isinstance(node, ast.ImportFrom) and node.module == "__future__":
                insert_line_idx = node.end_lineno
            else:
                break
        lines.insert(insert_line_idx, "import random")
        modified = True
        edits_applied.append(f"Added 'import random' statement at line {insert_line_idx + 1}")

    return "\n".join(lines) + "\n", modified, edits_applied

def heal_code_violations(repo, repo_dir, logs_content, tracker=None):
    # Pattern 1 (multiline Ruff):
    ruff_pattern_multiline = re.compile(
        r'^\s*(?P<code>[A-Z]{1,3}\d{3})\s+(?P<msg>[^\n]+)\n\s+-->\s+(?P<file>[^\s:]+):(?P<line>\d+)',
        re.MULTILINE
    )
    
    # Pattern 2 (singleline Ruff):
    ruff_pattern_singleline = re.compile(
        r'^(?:\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d+Z\s+)?(?P<file>[^\s:]+):(?P<line>\d+):(?:\d+:)?\s*(?P<code>[A-Z]{1,3}\d{3})\s+(?P<msg>[^\n]+)',
        re.MULTILINE
    )
    
    # Bandit pattern:
    bandit_pattern = re.compile(
        r'Issue:\s*\[(?P<code>B\d{3}):[^\]]+\][\s\S]*?Location:\s*(?P<file>[^\s:]+):(?P<line>\d+)',
        re.MULTILINE
    )
    
    violations = []
    
    # Process ruff multiline
    for m in ruff_pattern_multiline.finditer(logs_content):
        code = m.group('code')
        msg = m.group('msg')
        rel_path = m.group('file').strip()
        line_num = int(m.group('line'))
        
        arg_name = None
        if code == "ARG001":
            arg_match = re.search(r"Unused function argument:\s*`?([a-zA-Z_][a-zA-Z0-9_]*)`?", msg)
            if arg_match:
                arg_name = arg_match.group(1)
        violations.append((code, rel_path, line_num, arg_name))
        
    # Process ruff singleline
    for m in ruff_pattern_singleline.finditer(logs_content):
        code = m.group('code')
        msg = m.group('msg')
        rel_path = m.group('file').strip()
        line_num = int(m.group('line'))
        
        arg_name = None
        if code == "ARG001":
            arg_match = re.search(r"Unused function argument:\s*`?([a-zA-Z_][a-zA-Z0-9_]*)`?", msg)
            if arg_match:
                arg_name = arg_match.group(1)
        violations.append((code, rel_path, line_num, arg_name))
        
    # Process bandit
    for m in bandit_pattern.finditer(logs_content):
        code = m.group('code')
        rel_path = m.group('file').strip()
        line_num = int(m.group('line'))
        violations.append((code, rel_path, line_num, None))
        
    if not violations:
        return False
        
    log_info(f"Detected {len(violations)} Ruff/Bandit code violations in {repo}.")
    edits_applied = []
    
    # Auto-fix import sorting
    has_i001 = any(code == "I001" for code, _, _, _ in violations)
    if has_i001:
        log_info(f"Auto-fixing import sorting in {repo}...")
        res = run_cmd(["uv", "run", "ruff", "check", "--fix"], cwd=repo_dir)
        edits_applied.append("Ran 'ruff check --fix' to auto-sort imports")
        
    # Group errors by file
    file_errors = {}
    for code, rel_path, line_num, arg_name in violations:
        if code in ["ARG001", "S311", "B311"]:
            rel_path_norm = os.path.normpath(rel_path)
            file_errors.setdefault(rel_path_norm, []).append({
                "code": code,
                "line": line_num,
                "name": arg_name
            })
            
    for rel_path, errors in file_errors.items():
        abs_path = os.path.normpath(os.path.join(repo_dir, rel_path))
        if not os.path.exists(abs_path):
            parts = rel_path.replace("\\", "/").split("/")
            if len(parts) > 1 and parts[0] == repo:
                stripped_rel = "/".join(parts[1:])
                abs_path = os.path.normpath(os.path.join(repo_dir, stripped_rel))
                
        if not os.path.exists(abs_path):
            log_warning(f"File not found during code healing: {abs_path} (rel_path={rel_path})")
            continue
            
        try:
            with open(abs_path, "r", encoding="utf-8") as f:
                content = f.read()
                
            new_content, modified, file_edits = rewrite_code_via_ast(content, errors)
            
            if modified:
                with open(abs_path, "w", encoding="utf-8", newline="\n") as f:
                    f.write(new_content)
                for edit in file_edits:
                    edits_applied.append(f"{edit} in {rel_path}")
        except Exception as e:
            log_error(f"Error patching file {rel_path} via AST: {e}")
            
    if edits_applied:
        # Run ruff check to verify compilation
        run_cmd(["uv", "run", "ruff", "check"], cwd=repo_dir)
        
        # Commit and push
        commit_msg = "ci: self-heal lint/security errors [skip ci]"
        run_cmd(["git", "add", "."], cwd=repo_dir)
        res_commit = run_cmd(["git", "commit", "-m", commit_msg], cwd=repo_dir)
        if "ERROR" in res_commit and "nothing to commit" not in res_commit.lower():
            log_error(f"Failed to commit code-level fixes in {repo}: {res_commit}")
            return False
            
        res_pull = run_cmd(["git", "pull", "--rebase", "origin", "main"], cwd=repo_dir)
        if "ERROR" in res_pull:
            log_error(f"Failed to rebase code-level fixes in {repo}: {res_pull}")
            return False
            
        res_push = run_cmd(["git", "push", "origin", "main"], cwd=repo_dir)
        if "ERROR" in res_push:
            log_error(f"Failed to push code-level fixes in {repo}: {res_push}")
            return False
            
        for edit in edits_applied:
            if tracker:
                tracker.add_healing(repo, edit)
        return True
    return False

def heal_failed_run(repo, run_id, run_name, tag_name, logs_content, workspace_dir, tracker=None):
    repo_dir = os.path.join(workspace_dir, repo)
    if not os.path.exists(repo_dir):
        log_error(f"Local repository directory not found: {repo_dir}")
        return False
        
    # Check if there are code violations first and try to heal them
    code_healed = heal_code_violations(repo, repo_dir, logs_content, tracker=tracker)
    if code_healed:
        if tag_name and tag_name.startswith("v"):
            ret = re_tag_release(repo_dir, tag_name)
            if ret and tracker:
                tracker.add_healing(repo, f"Re-tagged release with tag {tag_name}")
            return ret
        else:
            log_warning(f"No valid release tag name found ('{tag_name}'). Skipping re-tagging.")
            return False
            
    logs_lower = logs_content.lower()
    
    pypi_already_exists = "file already exists" in logs_lower or "400 bad request" in logs_lower and "already exists" in logs_lower
    pypi_failure = "pypi" in logs_lower or "twine upload" in logs_lower
    
    ghcr_permission_denied = any(pat in logs_lower for pat in ["unauthorized", "denied: permission to write to this repository has been denied", "permission denied", "forbidden", "403 forbidden", "resource not accessible by integration"])
    ghcr_failure = any(pat in logs_lower for pat in ["ghcr.io", "docker/build-push-action", "docker/login-action", "helm push"])
    
    pages_failure = "failed to create deployment" in logs_lower or "pages is not enabled" in logs_lower or ("pages" in logs_lower and "resource not accessible by integration" in logs_lower)
    
    transient_failure = any(pat in logs_lower for pat in ["connectionrefusederror", "502 bad gateway", "503 service unavailable", "timeouterror", "connection refused"])

    log_info(f"Diagnosing failure in {repo} (Run {run_id}): tag={tag_name}")
    log_info(f"Signatures matched: PyPI-Exists={pypi_already_exists}, PyPI-Fail={pypi_failure}, GHCR-Auth={ghcr_permission_denied}, GHCR-Fail={ghcr_failure}, Pages-Fail={pages_failure}, Transient={transient_failure}")
    
    workflows_dir = os.path.join(repo_dir, ".github", "workflows")
    if not os.path.exists(workflows_dir):
        log_warning(f"No .github/workflows directory found in {repo}")
        return False
        
    workflow_files = [os.path.join(workflows_dir, f) for f in os.listdir(workflows_dir) if f.endswith((".yml", ".yaml"))]
    
    workflow_edited = False
    
    if pypi_already_exists or (pypi_failure and not transient_failure):
        log_warning(f"PyPI upload failure detected in {repo}. Scanning workflows to inject 'skip-existing: true'...")
        for w_file in workflow_files:
            if add_skip_existing_to_workflow(w_file):
                action_str = f"Injected 'skip-existing: true' into workflow ({os.path.basename(w_file)})"
                log_success(action_str)
                if tracker:
                    tracker.add_healing(repo, action_str)
                workflow_edited = True
                
    if ghcr_permission_denied or (ghcr_failure and not transient_failure):
        log_warning(f"GHCR/Container publish failure detected in {repo}. Scanning workflows to inject 'packages: write' permission...")
        for w_file in workflow_files:
            if add_packages_write_to_workflow(w_file):
                action_str = f"Injected 'packages: write' permission into workflow ({os.path.basename(w_file)})"
                log_success(action_str)
                if tracker:
                    tracker.add_healing(repo, action_str)
                workflow_edited = True
                
    if pages_failure:
        log_warning(f"GitHub Pages deployment failure detected in {repo}. Scanning workflows to inject 'pages: write' / 'id-token: write'...")
        for w_file in workflow_files:
            if add_pages_write_to_workflow(w_file):
                action_str = f"Injected 'pages: write' / 'id-token: write' permissions into workflow ({os.path.basename(w_file)})"
                log_success(action_str)
                if tracker:
                    tracker.add_healing(repo, action_str)
                workflow_edited = True
        configure_github_pages_api(repo)
        if tracker:
            tracker.add_healing(repo, "Configured GitHub Pages via REST API to build from workflow")
        
    if transient_failure and not workflow_edited:
        action_str = "Identified transient error (connection/timeout); triggering rerun"
        log_warning(f"Transient failure detected in {repo}. Retrying run...")
        if tracker:
            tracker.add_healing(repo, action_str)
        
    if workflow_edited:
        commit_msg = "ci: self-heal workflow release configuration [skip ci]"
        if not commit_and_push_workflow_changes(repo_dir, commit_msg):
            return False
            
    if tag_name and tag_name.startswith("v"):
        ret = re_tag_release(repo_dir, tag_name)
        if ret and tracker:
            tracker.add_healing(repo, f"Re-tagged release with tag {tag_name}")
        return ret
    else:
        log_warning(f"No valid release tag name found ('{tag_name}'). Skipping re-tagging.")
        return False

def monitor_all_runs(repos, workspace_dir, interval=20, timeout=1200, tracker=None):
    log_info(f"Starting continuous CI/CD monitor for repositories: {repos}")
    log_info(f"Polling interval: {interval}s, Timeout: {timeout}s")
    
    start_time = time.time()
    
    while True:
        elapsed = time.time() - start_time
        if elapsed > timeout:
            log_error(f"Monitoring timed out after {timeout} seconds.")
            sys.exit(1)
            
        all_completed = True
        any_failed = False
        failed_runs_detected = []
        all_runs_cache = {}
        
        print("\n" + "="*80)
        print(f"| {'Repository':<30} | {'Run ID':<12} | {'Status':<15} | {'Conclusion':<12} |")
        print("-"*80)
        
        for repo in repos:
            runs = get_latest_runs(repo, limit=1)
            if not runs:
                print(f"| {repo:<30} | {'N/A':<12} | {'No Runs':<15} | {'N/A':<12} |")
                continue
                
            run = runs[0]
            run_id = run.get("databaseId")
            status = run.get("status")
            conclusion = run.get("conclusion") or "pending"
            tag_name = run.get("headBranch")
            
            print(f"| {repo:<30} | {run_id:<12} | {status:<15} | {conclusion:<12} |")
            all_runs_cache[repo] = run
            
            if tracker:
                tracker.update_run(repo, run_id, status, conclusion, tag_name)
            
            if status != "completed":
                all_completed = False
            elif conclusion == "failure":
                any_failed = True
                failed_runs_detected.append((repo, run_id))
                
        print("="*80)
        
        if tracker:
            tracker.write_report(COREASON_REPORT_PATH)
        
        if any_failed:
            log_error("Failing CI/CD runs detected! Fetching failure logs...")
            for repo, run_id in failed_runs_detected:
                print_run_telemetry(repo, run_id)
                print(f"\n{COLOR_RED}{COLOR_BOLD}=== FAILURE LOGS FOR {repo} (Run: {run_id}) ==={COLOR_RESET}")
                log_content = get_run_failure_logs(repo, run_id)
                safe_print_text(log_content)
                print("="*80)
                
                # Fetch tag name (headBranch) from the runs we matched
                run_obj = all_runs_cache.get(repo, {})
                tag_name = run_obj.get("headBranch")
                        
                # Perform self-healing
                heal_failed_run(repo, run_id, "Release", tag_name, log_content, workspace_dir, tracker=tracker)
                
            log_error("Self-healing action applied. Monitoring continues...")
            all_completed = False
            
            if tracker:
                tracker.write_report(COREASON_REPORT_PATH)
            
        if all_completed and not any_failed:
            log_success("All repository CI/CD runs have passed successfully!")
            sys.exit(0)
            
        time.sleep(interval)

def main():
    global COREASON_REPORT_PATH, COREASON_LOG_PATH
    parser = argparse.ArgumentParser(description="CoReason CI/CD Self-Healing Assistant")
    parser.add_argument("--repo", help="Target repository to inspect specifically")
    parser.add_argument("--monitor", action="store_true", help="Monitor all repositories continuously until they pass")
    parser.add_argument("--failure-file", help="Path to release_failure.json to auto-detect failing repo")
    parser.add_argument("--report-path", help="Path to save the custom markdown report (overrides COREASON_REPORT_PATH env var)")
    parser.add_argument("--log-path", help="Path to save the detailed execution log (overrides COREASON_LOG_PATH env var)")
    parser.add_argument("--no-uv-update", dest="uv_update", action="store_false", help="Disable automatic updating of uv tool")
    parser.set_defaults(uv_update=True)
    
    args = parser.parse_args()
    
    # Override log path and report path if supplied by arguments
    if args.log_path:
        COREASON_LOG_PATH = args.log_path
        configure_logging(args.log_path)
        
    if args.report_path:
        COREASON_REPORT_PATH = args.report_path

    if args.uv_update:
        ensure_uv_updated()

    if not check_gh_cli():
        sys.exit(1)
        
    workspace_dir = get_workspace_dir(__file__)
    
    failure_path = args.failure_file or os.path.join(workspace_dir, ".coreason", "release_failure.json")
    
    target_repo = args.repo
    if not target_repo and os.path.exists(failure_path):
        target_repo = get_failed_repo_from_file(failure_path)
        if target_repo:
            log_info(f"Auto-detected failing repository from failure file: {target_repo}")
            
    if args.monitor:
        repos_to_monitor = [target_repo] if target_repo else REPOS
        tracker = ReleaseTracker(repos_to_monitor)
        try:
            monitor_all_runs(repos_to_monitor, workspace_dir, tracker=tracker)
        except KeyboardInterrupt:
            log_info("Monitoring stopped by user.")
            sys.exit(0)
    else:
        if not target_repo:
            log_error("Please specify a target repository with --repo, enable --monitor, or ensure a failure file exists.")
            sys.exit(1)
            
        tracker = ReleaseTracker([target_repo])
        runs = get_latest_runs(target_repo, limit=1)
        if not runs:
            log_error(f"No recent runs found for repository {target_repo}")
            sys.exit(1)
            
        run = runs[0]
        run_id = run.get("databaseId")
        status = run.get("status")
        conclusion = run.get("conclusion") or "pending"
        tag_name = run.get("headBranch")
        
        tracker.update_run(target_repo, run_id, status, conclusion, tag_name)
        
        log_info(f"Latest run for {target_repo}: ID={run_id}, Status={status}, Conclusion={conclusion}")
        
        print_run_telemetry(target_repo, run_id)
        
        if conclusion == "failure" or status != "completed":
            logs = get_run_failure_logs(target_repo, run_id)
            print(f"\n{COLOR_RED}{COLOR_BOLD}=== FAILURE LOGS SUMMARY FOR {target_repo} ==={COLOR_RESET}")
            safe_print_text(logs)
            print("="*80)
            heal_failed_run(target_repo, run_id, "Release", tag_name, logs, workspace_dir, tracker=tracker)
            tracker.write_report(COREASON_REPORT_PATH)
        else:
            log_success(f"Latest run for {target_repo} succeeded.")
            tracker.write_report(COREASON_REPORT_PATH)

if __name__ == "__main__":
    main()
