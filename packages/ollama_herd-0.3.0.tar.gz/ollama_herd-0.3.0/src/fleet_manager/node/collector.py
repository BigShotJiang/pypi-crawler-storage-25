"""Assembles heartbeat payloads from system metrics and Ollama state."""

from __future__ import annotations

import logging
import shutil
from urllib.parse import urlparse

from fleet_manager import __version__
from fleet_manager.common.ollama_client import OllamaClient
from fleet_manager.common.system_metrics import (
    get_cpu_metrics,
    get_disk_metrics,
    get_local_ip,
    get_memory_metrics,
)
from fleet_manager.models.node import (
    CapacityMetrics,
    HeartbeatPayload,
    ImageMetrics,
    ImageModel,
    OllamaMetrics,
    TranscriptionMetrics,
    TranscriptionModel,
)

logger = logging.getLogger(__name__)


def _make_lan_reachable_url(ollama_host: str, lan_ip: str) -> str:
    """Replace localhost in ollama_host with the LAN IP so the router can reach us."""
    parsed = urlparse(ollama_host)
    if parsed.hostname in ("localhost", "127.0.0.1", "::1") and lan_ip and lan_ip != "127.0.0.1":
        port = parsed.port or 11434
        return f"http://{lan_ip}:{port}"
    return ollama_host


# Known mflux binaries and their model names
_MFLUX_BINARIES = [
    ("mflux-generate-z-image-turbo", "z-image-turbo"),
    ("mflux-generate", "flux-dev"),
]

# DiffusionKit binary and models it provides
_DIFFUSIONKIT_BINARY = "diffusionkit-cli"
_DIFFUSIONKIT_MODELS = [
    "sd3-medium",
    "sd3.5-large",
]


def _detect_image_models() -> ImageMetrics | None:
    """Detect available image generation models on this system (mflux + DiffusionKit)."""
    models: list[ImageModel] = []

    # Detect mflux models
    for binary, name in _MFLUX_BINARIES:
        if shutil.which(binary):
            models.append(ImageModel(name=name, binary=binary))

    # Detect DiffusionKit models
    if shutil.which(_DIFFUSIONKIT_BINARY):
        for name in _DIFFUSIONKIT_MODELS:
            models.append(ImageModel(name=name, binary=_DIFFUSIONKIT_BINARY))

    if not models:
        return None

    # Check if any image generation process is currently running
    generating = False
    try:
        import psutil

        for proc in psutil.process_iter(["name"]):
            proc_name = proc.info.get("name", "") or ""
            if "mflux" in proc_name.lower() or "diffusionkit" in proc_name.lower():
                generating = True
                break
    except Exception:
        pass

    return ImageMetrics(models_available=models, generating=generating)


def _detect_transcription_models() -> TranscriptionMetrics | None:
    """Detect available speech-to-text models on this system."""
    models: list[TranscriptionModel] = []
    if shutil.which("mlx-qwen3-asr"):
        models.append(TranscriptionModel(name="qwen3-asr", binary="mlx-qwen3-asr"))
    if not models:
        return None

    # Check if a transcription is currently running
    transcribing = False
    try:
        import psutil

        for proc in psutil.process_iter(["name"]):
            proc_name = proc.info.get("name", "") or ""
            if "qwen3-asr" in proc_name.lower() or "mlx-qwen3-asr" in proc_name.lower():
                transcribing = True
                break
    except Exception:
        pass

    return TranscriptionMetrics(models_available=models, transcribing=transcribing)


async def collect_heartbeat(
    node_id: str,
    ollama: OllamaClient,
    ollama_host: str = "http://localhost:11434",
    capacity_learner=None,
) -> HeartbeatPayload:
    """Assemble a complete heartbeat payload from local system state."""
    cpu = get_cpu_metrics()
    memory = get_memory_metrics()
    disk = get_disk_metrics()

    try:
        models_loaded = await ollama.get_running_models()
        models_available = await ollama.get_available_models()
        requests_active = sum(m.requests_active for m in models_loaded)
        logger.debug(
            f"Ollama state: {len(models_loaded)} loaded, "
            f"{len(models_available)} available, "
            f"{requests_active} active requests"
        )
    except Exception as e:
        logger.warning(f"Ollama not reachable at {ollama_host}: {type(e).__name__}: {e}")
        models_loaded = []
        models_available = []
        requests_active = 0

    # Run capacity learner observation if enabled
    capacity = None
    if capacity_learner is not None:
        cap_info = capacity_learner.observe(
            cpu.utilization_pct,
            memory.used_gb / memory.total_gb * 100 if memory.total_gb > 0 else 0,
        )
        capacity = CapacityMetrics(
            mode=cap_info.mode.value,
            ceiling_gb=cap_info.ceiling_gb,
            availability_score=cap_info.availability_score,
            reason=cap_info.reason,
            override_active=cap_info.override_active,
            learning_confidence=cap_info.learning_confidence,
            days_observed=cap_info.days_observed,
        )

    lan_ip = get_local_ip()
    image = _detect_image_models()
    transcription = _detect_transcription_models()

    return HeartbeatPayload(
        node_id=node_id,
        cpu=cpu,
        memory=memory,
        disk=disk,
        ollama=OllamaMetrics(
            models_loaded=models_loaded,
            models_available=models_available,
            requests_active=requests_active,
        ),
        ollama_host=_make_lan_reachable_url(ollama_host, lan_ip),
        lan_ip=lan_ip,
        capacity=capacity,
        agent_version=__version__,
        image=image,
        transcription=transcription,
    )
