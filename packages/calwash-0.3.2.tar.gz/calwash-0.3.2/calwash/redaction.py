"""
Redaction levels for calendar cleaning.

Provides different levels of privacy protection:
- COARSE: Complete event redaction if any sensitive data detected
- MEDIUM: Pattern-based replacement (default, current behavior)
- FINE: Partial masking (future implementation)
"""

from enum import Enum
import logging
from typing import Optional

logger = logging.getLogger(__name__)


class RedactionLevel(Enum):
    """Enumeration of available redaction levels."""
    
    COARSE = "coarse"  # Complete event redaction
    MEDIUM = "medium"  # Current pattern-based cleaning
    FINE = "fine"      # Future: Partial masking
    
    @classmethod
    def from_string(cls, level_str: Optional[str]) -> 'RedactionLevel':
        """
        Convert string to RedactionLevel.
        
        Args:
            level_str: String representation of redaction level
            
        Returns:
            RedactionLevel enum value (defaults to MEDIUM if invalid)
        """
        if not level_str:
            return cls.MEDIUM
            
        try:
            return cls(level_str.lower())
        except ValueError:
            logger.warning(f"Invalid redaction level '{level_str}', using MEDIUM")
            return cls.MEDIUM
    
    def get_description(self) -> str:
        """Get human-readable description of the redaction level."""
        descriptions = {
            RedactionLevel.COARSE: "Complete redaction - Entire events with sensitive data are replaced",
            RedactionLevel.MEDIUM: "Pattern replacement - Individual sensitive patterns are replaced", 
            RedactionLevel.FINE: "Partial masking - Sensitive data is partially obscured (not yet implemented)"
        }
        return descriptions.get(self, "Unknown redaction level")
    
    def is_implemented(self) -> bool:
        """Check if this redaction level is currently implemented."""
        return self in [RedactionLevel.COARSE, RedactionLevel.MEDIUM]


# Redacted event templates for coarse redaction
REDACTED_EVENT_TEMPLATES = {
    'summary': 'Redacted Event',
    'description': 'This event has been redacted for privacy',
    'location': 'Redacted',
    'attendees_message': 'Attendee information redacted'
}


def get_redacted_summary(original_summary: Optional[str] = None) -> str:
    """Get redacted summary for coarse redaction."""
    return REDACTED_EVENT_TEMPLATES['summary']


def get_redacted_description(original_description: Optional[str] = None) -> str:
    """Get redacted description for coarse redaction."""
    return REDACTED_EVENT_TEMPLATES['description']


def get_redacted_location(original_location: Optional[str] = None) -> str:
    """Get redacted location for coarse redaction."""
    return REDACTED_EVENT_TEMPLATES['location']