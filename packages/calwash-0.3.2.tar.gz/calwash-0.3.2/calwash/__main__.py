"""Entry point for python -m calwash."""

from calwash.cli import main

if __name__ == "__main__":
    main()
