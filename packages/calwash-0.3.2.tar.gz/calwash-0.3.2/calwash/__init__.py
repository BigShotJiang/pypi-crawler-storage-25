"""calwash - Google Calendar sensitive data cleaner.

A tool to detect and remove sensitive information (SSNs, phone numbers,
emails, credit cards, medical terms, etc.) from Google Calendar events.

Install: pipx install calwash
Usage:   calwash clean --dry-run
"""

__version__ = "0.3.2"

from calwash.redaction import RedactionLevel
from calwash.dates import DateRange, DateParsingError
from calwash.patterns import (
    get_patterns_for_cleaning,
    get_validated_patterns_for_cleaning,
    clean_text_with_validation,
    SensitivePattern,
)
from calwash.auth import setup_service
from calwash.cleaner import clean_event_data

__all__ = [
    "__version__",
    "RedactionLevel",
    "DateRange",
    "DateParsingError",
    "get_patterns_for_cleaning",
    "get_validated_patterns_for_cleaning",
    "clean_text_with_validation",
    "SensitivePattern",
    "setup_service",
    "clean_event_data",
]
