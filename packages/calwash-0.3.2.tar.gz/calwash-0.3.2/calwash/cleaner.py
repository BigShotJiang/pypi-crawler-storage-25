"""Calendar event cleaning logic for calwash."""

import json
import argparse
import logging
from datetime import datetime, timezone
from pathlib import Path
import copy

from calwash.patterns import get_patterns_for_cleaning, get_validated_patterns_for_cleaning
from calwash.auth import (
    create_user_filename,
    get_env_backup_dir,
    get_env_organize_by_user,
    setup_service,
    get_output_directory
)
from calwash.redaction import (
    RedactionLevel,
    get_redacted_summary,
    get_redacted_description,
    get_redacted_location
)
from calwash.dates import (
    DateRange,
    create_date_range_from_args,
    generate_backup_filename,
    create_backup_metadata,
    DateParsingError,
    get_valid_date_shortcuts
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def _get_version():
    """Get package version, avoiding circular import."""
    from calwash import __version__
    return __version__

# Validated patterns are always available in the package
USE_VALIDATED_PATTERNS = True



def fetch_and_backup_events(service, user_email: str, 
                           backup_dir: str = None, 
                           organize_by_user: bool = False,
                           date_range: DateRange = None):
    """Fetch events and create a backup file with user identification and date filtering
    
    Args:
        service: Google Calendar service object
        user_email: Authenticated user's email address
        backup_dir: Custom backup directory (optional)
        organize_by_user: Create user-specific subdirectories
        date_range: Optional date range for filtering events
        
    Returns:
        tuple: (events, backup_filename) - Events list and backup file path
    """
    logger.info("Fetching calendar events...")
    if date_range:
        logger.info(f"Filtering events by date range: {date_range}")
    
    try:
        # Build API request parameters
        params = {
            'calendarId': 'primary',
            'maxResults': 2500,
            'singleEvents': True,
            'orderBy': 'startTime'
        }
        
        # Add date range filters if specified
        if date_range:
            if date_range.from_date:
                # Ensure timezone info is present for API
                from_dt = date_range.from_date.replace(hour=0, minute=0, second=0, microsecond=0)
                if from_dt.tzinfo is None:
                    from_dt = from_dt.replace(tzinfo=timezone.utc)
                params['timeMin'] = from_dt.isoformat()
                logger.info(f"Filtering events from: {from_dt.isoformat()}")
            if date_range.to_date:
                # Ensure timezone info is present for API
                to_dt = date_range.to_date.replace(hour=23, minute=59, second=59, microsecond=0)
                if to_dt.tzinfo is None:
                    to_dt = to_dt.replace(tzinfo=timezone.utc)
                params['timeMax'] = to_dt.isoformat()
                logger.info(f"Filtering events to: {to_dt.isoformat()}")
        
        # Fetch events from API
        events_result = service.events().list(**params).execute()
        all_events = events_result.get('items', [])
        
        logger.info(f"Found {len(all_events)} events from API")
        
        # Apply additional client-side filtering if needed
        if date_range:
            filtered_events = date_range.filter_events(all_events)
            logger.info(f"Filtered to {len(filtered_events)} events in date range")
            events = filtered_events
        else:
            events = all_events
        
        # Generate new-format filename with date range
        backup_filename = generate_backup_filename(
            user_email=user_email,
            date_range=date_range,
            operation='backup'
        )
        
        # Handle custom output directory
        if backup_dir or organize_by_user:
            output_path = get_output_directory(backup_dir, user_email, organize_by_user)
            backup_filepath = output_path / backup_filename
        else:
            backup_filepath = backup_filename
        
        # Create backup with metadata
        backup_data = create_backup_metadata(
            events=events,
            user_email=user_email,
            date_range=date_range,
            operation='backup',
            version=_get_version()
        )
        
        with open(backup_filepath, 'w', encoding='utf-8') as backup_file:
            json.dump(backup_data, backup_file, indent=2)
        logger.info(f"Backup saved to {backup_filepath}")
        
        return events, str(backup_filepath)
        
    except Exception as e:
        logger.error(f"Failed to fetch and backup events: {e}")
        raise


def contains_sensitive_data(event):
    """
    Check if an event contains any sensitive data.
    
    Args:
        event: Calendar event to check
        
    Returns:
        bool: True if event contains sensitive patterns, False otherwise
    """
    # Get patterns to check
    if USE_VALIDATED_PATTERNS:
        patterns = get_validated_patterns_for_cleaning()
    else:
        patterns = get_patterns_for_cleaning()
    
    # Check summary
    if 'summary' in event and event['summary']:
        summary = str(event['summary'])
        for pattern_regex, _ in patterns:
            try:
                if pattern_regex.search(summary):
                    return True
            except Exception:
                continue
    
    # Check description
    if 'description' in event and event['description']:
        description = str(event['description'])
        for pattern_regex, _ in patterns:
            try:
                if pattern_regex.search(description):
                    return True
            except Exception:
                continue
    
    # Check location
    if 'location' in event and event['location']:
        location = str(event['location'])
        for pattern_regex, _ in patterns:
            try:
                if pattern_regex.search(location):
                    return True
            except Exception:
                continue
    
    return False


def apply_coarse_redaction(event):
    """
    Apply coarse redaction to completely redact an event.
    
    Args:
        event: Original calendar event
        
    Returns:
        dict: Redacted event with all sensitive fields replaced
    """
    # Create redacted event preserving only non-sensitive fields
    redacted_event = {
        'id': event.get('id'),
        'summary': get_redacted_summary(),
        'description': get_redacted_description(),
        # Preserve timing information
        'start': event.get('start'),
        'end': event.get('end'),
        # Keep other non-sensitive structural fields
        'status': event.get('status'),
        'reminders': event.get('reminders'),
        'recurringEventId': event.get('recurringEventId'),
        'originalStartTime': event.get('originalStartTime')
    }
    
    # Redact location if present
    if 'location' in event:
        redacted_event['location'] = get_redacted_location()
    
    # Remove None values to keep event clean
    redacted_event = {k: v for k, v in redacted_event.items() if v is not None}
    
    return redacted_event


# Phase 3: Clean Sensitive Information
def clean_event_data(events, redaction_level=RedactionLevel.MEDIUM):
    """
    Clean sensitive information from calendar events.
    
    Args:
        events: List of calendar events to clean
        redaction_level: RedactionLevel enum specifying how aggressively to redact
        
    Returns:
        tuple: (cleaned_events, changes) - Cleaned events and list of changes made
    """
    # Track changes for reporting
    changes = []
    
    # Validate input
    if not events:
        logger.warning("No events provided to clean_event_data")
        return events, changes
    
    if not isinstance(events, list):
        logger.error("Events must be a list")
        return events, changes
    
    # Log redaction level being used
    logger.info(f"Using redaction level: {redaction_level.value} - {redaction_level.get_description()}")
    
    # Process events one by one to minimize memory usage
    cleaned_events = []
    
    # Anonymize event summaries and descriptions
    for original_event in events:
        try:
            # Validate event structure
            if not isinstance(original_event, dict):
                logger.warning(f"Skipping non-dict event: {type(original_event)}")
                cleaned_events.append(original_event)  # Keep as-is
                continue
            
            # COARSE REDACTION: Check if event contains sensitive data
            if redaction_level == RedactionLevel.COARSE:
                if contains_sensitive_data(original_event):
                    # Apply complete redaction
                    redacted_event = apply_coarse_redaction(original_event)
                    
                    # Track all changes for coarse redaction
                    event_changes = {
                        'event_id': original_event.get('id', 'unknown'),
                        'event_date': original_event.get('start', {}).get('dateTime', 
                                     original_event.get('start', {}).get('date', 'Unknown')),
                        'modifications': []
                    }
                    
                    # Track summary change if it existed
                    if 'summary' in original_event and original_event['summary']:
                        event_changes['modifications'].append({
                            'field': 'summary',
                            'original': original_event['summary'],
                            'cleaned': redacted_event['summary']
                        })
                    
                    # Track description change if it existed
                    if 'description' in original_event and original_event['description']:
                        event_changes['modifications'].append({
                            'field': 'description',
                            'original': original_event['description'][:100] + '...' if len(original_event['description']) > 100 else original_event['description'],
                            'cleaned': redacted_event['description']
                        })
                    
                    # Track location change if it existed
                    if 'location' in original_event and original_event['location']:
                        event_changes['modifications'].append({
                            'field': 'location',
                            'original': original_event['location'],
                            'cleaned': redacted_event.get('location', '')
                        })
                    
                    if event_changes['modifications']:
                        changes.append(event_changes)
                    
                    cleaned_events.append(redacted_event)
                    continue
                else:
                    # No sensitive data found, keep event as-is
                    cleaned_events.append(original_event)
                    continue
            
            # MEDIUM REDACTION: Apply pattern-based cleaning (existing logic)
            # Create a shallow copy for this event only
            event = original_event.copy()
                
            event_changes = {
                'event_id': event.get('id', 'unknown'),
                'event_date': event.get('start', {}).get('dateTime', event.get('start', {}).get('date', 'Unknown')),
                'modifications': []
            }
            
            # Clean summary - only clean if it contains sensitive information
            if 'summary' in event and event['summary']:
                original_summary = str(event['summary'])  # Ensure it's a string
                
                try:
                    # Get centralized patterns for cleaning
                    if USE_VALIDATED_PATTERNS:
                        patterns = get_validated_patterns_for_cleaning()
                    else:
                        patterns = get_patterns_for_cleaning()
                    
                    cleaned_summary = original_summary
                    summary_modified = False
                    
                    # Apply cleaning patterns to summary
                    for pattern_regex, replacement in patterns:
                        try:
                            if pattern_regex.search(cleaned_summary):
                                cleaned_summary = pattern_regex.sub(replacement, cleaned_summary)
                                summary_modified = True
                        except Exception as e:
                            logger.error(f"Regex error with pattern on summary: {e}")
                            continue
                    
                    # Only update if patterns were found and replaced
                    if summary_modified:
                        event['summary'] = cleaned_summary
                        event_changes['modifications'].append({
                            'field': 'summary',
                            'original': original_summary,
                            'cleaned': event['summary']
                        })
                    
                except Exception as e:
                    event_info = f"ID: {event.get('id', 'unknown')}, Date: {event.get('start', {}).get('dateTime', event.get('start', {}).get('date', 'Unknown'))}"
                    logger.error(f"Error cleaning summary for event ({event_info}): {e}")
                    # Fall back to blanket replacement only if there's an error
                    event['summary'] = "Private Event"
                    event_changes['modifications'].append({
                        'field': 'summary',
                        'original': original_summary,
                        'cleaned': event['summary']
                    })
            
            # Clean description
            if 'description' in event and event['description']:
                original_description = str(event['description'])  # Ensure it's a string
                
                try:
                    # Get centralized patterns for cleaning
                    if USE_VALIDATED_PATTERNS:
                        patterns = get_validated_patterns_for_cleaning()
                    else:
                        patterns = get_patterns_for_cleaning()
                    
                    cleaned_description = original_description
                    for pattern_regex, replacement in patterns:
                        try:
                            # pattern_regex is now a compiled regex object
                            cleaned_description = pattern_regex.sub(replacement, cleaned_description)
                        except Exception as e:
                            logger.error(f"Regex error with pattern: {e}")
                            continue
                    
                    event['description'] = cleaned_description
                    
                    if original_description != event['description']:
                        event_changes['modifications'].append({
                            'field': 'description',
                            'original': original_description[:100] + '...' if len(original_description) > 100 else original_description,
                            'cleaned': event['description'][:100] + '...' if len(event['description']) > 100 else event['description']
                        })
                except Exception as e:
                    event_info = f"ID: {event.get('id', 'unknown')}, Date: {event.get('start', {}).get('dateTime', event.get('start', {}).get('date', 'Unknown'))}"
                    logger.error(f"Error cleaning description for event ({event_info}): {e}")
            
            # Only track if there were actual changes
            if event_changes['modifications']:
                changes.append(event_changes)
            
            # Add the cleaned event to results
            cleaned_events.append(event)
                
        except Exception as e:
            event_info = f"ID: {original_event.get('id', 'unknown') if isinstance(original_event, dict) else 'N/A'}"
            logger.error(f"Error processing event ({event_info}): {e}")
            logger.debug(f"Event data that caused error: {original_event}")
            # Keep original event if processing fails
            cleaned_events.append(original_event)
            continue
    
    return cleaned_events, changes


def generate_dry_run_report(changes, user_email: str, report_dir: str = None, 
                           organize_by_user: bool = False, date_range: DateRange = None):
    """Generate a detailed report of cleaning changes with user identification"""
    report = create_backup_metadata(
        events=changes,
        user_email=user_email,
        date_range=date_range,
        operation='dry_run_preview',
        version=_get_version()
    )
    
    # Update metadata to reflect this is a preview
    report['metadata']['total_events_to_modify'] = len(changes)
    
    # Generate new-format filename
    report_filename = generate_backup_filename(
        user_email=user_email,
        date_range=date_range,
        operation='dry_run_preview'
    )
    
    # Handle custom output directory
    if report_dir or organize_by_user:
        output_path = get_output_directory(report_dir, user_email, organize_by_user)
        report_filepath = output_path / report_filename
    else:
        report_filepath = report_filename
    
    # Save to file
    with open(report_filepath, 'w', encoding='utf-8') as f:
        json.dump(report, f, indent=2)
    
    # Print summary to console
    logger.info("\n" + "="*60)
    logger.info("DRY RUN PREVIEW - No changes have been made to your calendar")
    logger.info("="*60)
    logger.info(f"User: {user_email}")
    logger.info(f"Total events that would be modified: {len(changes)}")
    
    # Show first few changes as examples
    for i, change in enumerate(changes[:5]):
        logger.info(f"\nEvent {i+1}:")
        logger.info(f"  Date: {change['event_date']}")
        logger.info(f"  Event ID: {change['event_id']}")
        for mod in change['modifications']:
            logger.info(f"  {mod['field'].capitalize()}:")
            logger.info(f"    Original: {mod['original']}")
            logger.info(f"    Would change to: {mod['cleaned']}")
    
    if len(changes) > 5:
        logger.info(f"\n... and {len(changes) - 5} more events")
    
    logger.info(f"\nFull preview saved to: {report_filepath}")
    logger.info("To apply these changes, run without --dry-run flag")
    
    return report


def update_calendar_events(service, cleaned_events, changes, user_email: str,
                          dry_run=False, report_dir: str = None, 
                          organize_by_user: bool = False, date_range: DateRange = None):
    """Update calendar events with cleaned data
    
    Args:
        service: Google Calendar service object
        cleaned_events: List of cleaned events
        changes: List of changes made
        user_email: Authenticated user's email address
        dry_run: Whether to run in dry-run mode
        report_dir: Custom report directory (optional)
        organize_by_user: Create user-specific subdirectories
    """
    if dry_run:
        logger.info("\n[DRY RUN MODE] No changes will be made to your calendar")
        report_file = generate_dry_run_report(changes, user_email, report_dir, organize_by_user, date_range)
        logger.info(f"\nDry-run report saved to: {report_file}")
        logger.info("\nTo apply these changes, run without --dry-run flag")
        return report_file
    else:
        logger.info("\nUpdating calendar events...")
        updated_count = 0
        failed_count = 0
        
        # Only update events that have changes
        events_to_update = {change['event_id']: change for change in changes}
        
        for event in cleaned_events:
            if event['id'] in events_to_update:
                try:
                    service.events().update(
                        calendarId='primary', 
                        eventId=event['id'], 
                        body=event
                    ).execute()
                    updated_count += 1
                    if updated_count % 10 == 0:
                        logger.info(f"Updated {updated_count} events...")
                except Exception as e:
                    logger.error(f"Failed to update event {event['id']}: {e}")
                    failed_count += 1
        
        logger.info(f"\n" + "="*60)
        logger.info("CLEANING COMPLETE")
        logger.info("="*60)
        logger.info(f"Successfully updated: {updated_count} events")
        if failed_count > 0:
            logger.warning(f"Failed to update: {failed_count} events")


def parse_arguments():
    valid_shortcuts = get_valid_date_shortcuts()
    shortcuts_help = ', '.join(valid_shortcuts[:8]) + ', etc.'
    
    parser = argparse.ArgumentParser(
        description='Clean sensitive information from Google Calendar events',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=f'''
Examples:
  %(prog)s --dry-run                           # Preview changes without modifying calendar
  %(prog)s --profile work                      # Clean using work profile  
  %(prog)s --output-dir ~/backups              # Save to custom directory
  %(prog)s --organize-by-user                  # Organize files by user
  %(prog)s --from-date 2025-01-01 --to-date 2025-01-31  # Clean only January 2025 events
  %(prog)s --days-back 30                      # Clean events from last 30 days
  %(prog)s --year 2025                         # Clean all events in 2025
  %(prog)s --month 2025-08                     # Clean all events in August 2025
  %(prog)s --from-date today --to-date next-month  # Clean from today to end of next month
  %(prog)s                                     # Apply changes to calendar (default profile)

Date Shortcuts:
  {shortcuts_help}
        '''
    )
    
    parser.add_argument(
        '--dry-run',
        action='store_true',
        help='Preview changes without modifying the calendar'
    )
    
    parser.add_argument(
        '--verbose',
        action='store_true',
        help='Show detailed output'
    )
    
    parser.add_argument(
        '--profile', 
        type=str, 
        default='default',
        help='Profile name to use for authentication (default: default)'
    )
    
    parser.add_argument(
        '--output-dir', 
        type=str,
        help='Directory to save output files (default: current directory)'
    )
    
    parser.add_argument(
        '--organize-by-user', 
        action='store_true',
        help='Create user-specific subdirectories for output files'
    )
    
    parser.add_argument(
        '--redaction-level',
        type=str,
        choices=['coarse', 'medium', 'fine'],
        default='medium',
        help='Level of redaction to apply: coarse (complete redaction), medium (pattern replacement), fine (not yet implemented)'
    )
    
    # Date range arguments
    date_group = parser.add_argument_group('Date Filtering Options')
    date_group.add_argument(
        '--from-date',
        type=str,
        help='Start date for filtering events (YYYY-MM-DD or shortcut like "today", "last-month")'
    )
    date_group.add_argument(
        '--to-date',
        type=str,
        help='End date for filtering events (YYYY-MM-DD or shortcut like "tomorrow", "next-week")'
    )
    date_group.add_argument(
        '--days-back',
        type=int,
        help='Clean events from N days ago to today'
    )
    date_group.add_argument(
        '--days-forward',
        type=int,
        help='Clean events from today to N days in the future'
    )
    date_group.add_argument(
        '--year',
        type=str,
        help='Clean all events in specified year (YYYY)'
    )
    date_group.add_argument(
        '--month',
        type=str,
        help='Clean all events in specified month (YYYY-MM)'
    )
    
    return parser.parse_args()


def main():
    # Parse command line arguments
    args = parse_arguments()
    
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)
    
    # Parse date range arguments
    date_range = None
    try:
        date_range = create_date_range_from_args(args)
        if date_range:
            logger.info(f"Date filtering enabled: {date_range}")
    except DateParsingError as e:
        logger.error(f"Date parsing error: {e}")
        return
    
    # Get configuration from arguments and environment
    profile_name = args.profile
    output_dir = args.output_dir or get_env_backup_dir()
    organize_by_user = args.organize_by_user or get_env_organize_by_user()
    
    if args.dry_run:
        logger.info("Starting in DRY RUN mode - no changes will be made to your calendar")
    else:
        logger.warning("Starting in LIVE mode - your calendar will be updated")
        logger.warning("This will replace event titles with 'Private Event' and clean descriptions")
        response = input("Are you sure you want to continue? (yes/no): ")
        if response.lower() not in ['yes', 'y', 'true', '1']:
            logger.info("Operation cancelled")
            return
    
    # Set up service and authenticate
    try:
        service, user_email = setup_service(profile_name)
        logger.info(f"Authenticated as: {user_email} (profile: {profile_name})")
    except Exception as e:
        logger.error(f"Failed to authenticate with profile '{profile_name}': {e}")
        return
    
    # Run all phases in sequence
    events, backup_file = fetch_and_backup_events(service, user_email, output_dir, organize_by_user, date_range)
    
    if not events:
        logger.warning("No events found to process")
        return
    
    logger.info(f"Created backup: {backup_file}")
    
    # Get redaction level
    redaction_level = RedactionLevel.from_string(args.redaction_level)
    if not redaction_level.is_implemented():
        logger.error(f"Redaction level '{redaction_level.value}' is not yet implemented")
        return
    
    cleaned_events, changes = clean_event_data(events, redaction_level)
    
    if not changes:
        logger.info("No events require cleaning - your calendar is already private")
        return
    
    update_calendar_events(service, cleaned_events, changes, user_email, 
                          dry_run=args.dry_run, report_dir=output_dir, 
                          organize_by_user=organize_by_user, date_range=date_range)

if __name__ == '__main__':
    main()