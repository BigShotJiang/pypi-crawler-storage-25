#!/usr/bin/env python3
"""
Restore Google Calendar events from backup files created by calendar_cleaner.py
"""

from googleapiclient.discovery import build
import json
import os
import sys
import argparse
import logging
from pathlib import Path
from datetime import datetime
import glob
import time
from calwash.auth import (
    setup_service,
    list_accounts,
    CalendarCleanerError,
    AccountNotFoundError,
)
from calwash.dates import (
    DateRange,
    create_date_range_from_args,
    load_backup_file,
    get_valid_date_shortcuts
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def setup_service_legacy(account='default'):
    """Legacy setup function — use setup_service() instead."""
    service, user_email = setup_service(account)
    return service


def list_backup_files():
    """List all available backup files"""
    patterns = [
        'calendar_backup_*.json',  # Old pattern
        'calendar_backup_*_at_*.json'  # New pattern with email
    ]
    
    backup_files = []
    for pattern in patterns:
        backup_files.extend(glob.glob(pattern))
    
    # Remove duplicates and sort by modification time (newest first)
    backup_files = list(set(backup_files))
    backup_files.sort(key=lambda x: os.path.getmtime(x), reverse=True)
    
    return backup_files


def select_backup_file(backup_files):
    """Let user select which backup file to restore from"""
    if not backup_files:
        logger.error("No backup files found!")
        logger.error("Backup files should be named 'calendar_backup_*.json'")
        return None
    
    if len(backup_files) == 1:
        logger.info(f"Found one backup file: {backup_files[0]}")
        return backup_files[0]
    
    logger.info("\nAvailable backup files:")
    for i, file in enumerate(backup_files, 1):
        # Get file size and modification time
        size = os.path.getsize(file) / 1024  # Convert to KB
        mtime = datetime.fromtimestamp(os.path.getmtime(file))
        logger.info(f"{i}. {file} ({size:.1f} KB, created {mtime.strftime('%Y-%m-%d %H:%M:%S')})")
    
    while True:
        try:
            choice = input(f"\nSelect backup to restore from (1-{len(backup_files)}): ")
            index = int(choice) - 1
            if 0 <= index < len(backup_files):
                return backup_files[index]
            else:
                logger.error(f"Please enter a number between 1 and {len(backup_files)}")
        except (ValueError, KeyboardInterrupt):
            logger.info("\nRestore cancelled")
            return None


def load_backup(backup_file, date_range=None):
    """Load events from backup file with optional date filtering"""
    logger.info(f"Loading backup from {backup_file}...")
    try:
        events, metadata = load_backup_file(backup_file)
        original_count = len(events)
        logger.info(f"Loaded {original_count} events from backup")
        
        # Apply date filtering if specified
        if date_range:
            logger.info(f"Applying date filter: {date_range}")
            events = date_range.filter_events(events)
            logger.info(f"Filtered from {original_count} to {len(events)} events")
        
        return events, metadata
    except Exception as e:
        logger.error(f"Failed to load backup file: {e}")
        return None, None


def restore_events(service, events, dry_run=False, date_range=None):
    """Restore events to calendar"""
    if dry_run:
        logger.info("\n" + "="*60)
        logger.info("DRY RUN MODE - No changes will be made")
        logger.info("="*60)
        if date_range:
            logger.info(f"Would restore {len(events)} events to calendar (filtered by {date_range})")
        else:
            logger.info(f"Would restore {len(events)} events to calendar")
        
        # Show preview of first few events
        for i, event in enumerate(events[:3]):
            logger.info(f"\nEvent {i+1}:")
            logger.info(f"  Summary: {event.get('summary', 'No title')}")
            logger.info(f"  Date: {event.get('start', {}).get('dateTime', event.get('start', {}).get('date', 'Unknown'))}")
            if 'description' in event:
                desc_preview = event['description'][:100] + '...' if len(event['description']) > 100 else event['description']
                logger.info(f"  Description: {desc_preview}")
        
        if len(events) > 3:
            logger.info(f"\n... and {len(events) - 3} more events")
        
        logger.info("\nTo actually restore, run without --dry-run flag")
        return
    
    logger.info("\nRestoring events to calendar...")
    restored_count = 0
    failed_count = 0
    
    for i, event in enumerate(events, 1):
        try:
            # Update the existing event
            service.events().update(
                calendarId='primary',
                eventId=event['id'],
                body=event
            ).execute()
            restored_count += 1
            
            if restored_count % 10 == 0:
                logger.info(f"Restored {restored_count} events...")
                # Add small delay every 10 events to avoid rate limits
                time.sleep(0.5)
                
        except Exception as e:
            error_msg = str(e)
            if 'rateLimitExceeded' in error_msg:
                logger.warning(f"Rate limit hit at event {i}. Waiting 2 seconds...")
                time.sleep(2)
                # Retry this event once after delay
                try:
                    service.events().update(
                        calendarId='primary',
                        eventId=event['id'],
                        body=event
                    ).execute()
                    restored_count += 1
                    logger.info(f"Successfully restored event after retry: {event.get('summary', 'No title')}")
                except Exception as retry_error:
                    logger.error(f"Failed to restore event {event.get('id', 'unknown')} after retry: {retry_error}")
                    failed_count += 1
            else:
                logger.error(f"Failed to restore event {event.get('id', 'unknown')}: {e}")
                failed_count += 1
    
    logger.info("\n" + "="*60)
    logger.info("RESTORE COMPLETE")
    logger.info("="*60)
    logger.info(f"Successfully restored: {restored_count} events")
    if failed_count > 0:
        logger.warning(f"Failed to restore: {failed_count} events")


def parse_arguments():
    # Get valid date shortcuts for help text
    valid_shortcuts = get_valid_date_shortcuts()
    shortcuts_help = ', '.join(valid_shortcuts[:8]) + ', etc.'
    
    parser = argparse.ArgumentParser(
        description='Restore Google Calendar events from backup with optional date filtering',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=f'''
Examples:
  %(prog)s --dry-run                                    # Preview what would be restored
  %(prog)s --file backup.json                          # Restore from specific backup file
  %(prog)s --from-date 2025-08-01 --to-date 2025-08-15 --dry-run  # Preview restore for date range
  %(prog)s --days-back 30 --dry-run                    # Preview restore for last 30 days
  %(prog)s --year 2024                                 # Restore all events from 2024
  %(prog)s --month 2025-08                             # Restore all events from August 2025
  
Date shortcuts: {shortcuts_help}
        '''
    )
    
    parser.add_argument(
        '--dry-run',
        action='store_true',
        help='Preview restore without making changes'
    )
    
    parser.add_argument(
        '--file',
        type=str,
        help='Specific backup file to restore from'
    )
    
    parser.add_argument(
        '--account',
        type=str,
        default='default',
        help='Account to use for authentication (default: default)'
    )
    
    # Date range arguments (matching calendar_cleaner.py)
    date_group = parser.add_argument_group('Date Filtering Options')
    date_group.add_argument(
        '--from-date',
        type=str,
        help='Start date for filtering events (YYYY-MM-DD or shortcut like "today", "last-month")'
    )
    date_group.add_argument(
        '--to-date',
        type=str,
        help='End date for filtering events (YYYY-MM-DD or shortcut like "tomorrow", "next-week")'
    )
    date_group.add_argument(
        '--days-back',
        type=int,
        help='Restore events from N days ago to today'
    )
    date_group.add_argument(
        '--days-forward',
        type=int,
        help='Restore events from today to N days in the future'
    )
    date_group.add_argument(
        '--year',
        type=str,
        help='Restore all events in specified year (YYYY)'
    )
    date_group.add_argument(
        '--month',
        type=str,
        help='Restore all events in specified month (YYYY-MM)'
    )
    
    return parser.parse_args()


def main():
    args = parse_arguments()
    
    # Create date range from arguments
    try:
        date_range = create_date_range_from_args(args)
    except Exception as e:
        logger.error(f"Error parsing date arguments: {e}")
        return
    
    if args.dry_run:
        logger.info("Starting in DRY RUN mode - no changes will be made")
        if date_range:
            logger.info(f"Date filtering: {date_range}")
    else:
        logger.warning("Starting in RESTORE mode - this will restore your calendar events")
        if date_range:
            logger.warning(f"Date filtering: {date_range}")
        logger.warning("Make sure you want to restore from backup!")
        response = input("Continue with restore? (yes/no): ")
        if response.lower() != 'yes':
            logger.info("Restore cancelled")
            return
    
    # Select backup file
    if args.file:
        if not os.path.exists(args.file):
            logger.error(f"Backup file not found: {args.file}")
            return
        backup_file = args.file
    else:
        backup_files = list_backup_files()
        backup_file = select_backup_file(backup_files)
        if not backup_file:
            return
    
    # Load backup with optional date filtering
    events, metadata = load_backup(backup_file, date_range)
    if events is None:
        return
    
    if len(events) == 0:
        logger.info("No events to restore after filtering")
        return
    
    # Set up service and restore
    try:
        service, user_email = setup_service(getattr(args, 'account', 'default') or 'default')
        logger.info(f"Authenticated as: {user_email}")

        if not args.dry_run and date_range:
            msg = f"This will restore {len(events)} events (filtered by date range: {date_range})"
            response = input(f"\n{msg}. Continue? (yes/no): ")
            if response.lower() not in ['yes', 'y']:
                logger.info("Restoration cancelled")
                return

        restore_events(service, events, dry_run=args.dry_run, date_range=date_range)
    except AccountNotFoundError as e:
        logger.error(f"Account error: {e}")
        accounts = list_accounts()
        if accounts:
            logger.info(f"Available accounts: {', '.join(name for name, _ in accounts)}")
        else:
            logger.info("No accounts found. Run: calwash login")
        return
    except CalendarCleanerError as e:
        logger.error(f"Authentication error: {e}")
        return
    except Exception as e:
        logger.error(f"Failed to set up service: {e}")
        return


if __name__ == '__main__':
    main()