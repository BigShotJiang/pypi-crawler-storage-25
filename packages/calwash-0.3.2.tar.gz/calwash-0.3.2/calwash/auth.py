"""
Account management and utilities for calwash.

Provider-agnostic account directory management, token storage paths,
filename utilities, and migration logic. Google-specific authentication
lives in calwash.providers.google.

Storage: ~/.calwash/accounts/{account_name}/
"""

import os
import re
import logging
import shutil
from pathlib import Path
from datetime import datetime
from typing import Optional, List, Tuple


# Base directory for all calwash data
CALWASH_HOME = Path.home() / ".calwash"


# Custom Exception Classes
class CalendarCleanerError(Exception):
    """Base exception class for calwash"""
    pass


class UserEmailNotFoundError(CalendarCleanerError):
    """Raised when user email cannot be retrieved"""
    pass


class AuthenticationError(CalendarCleanerError):
    """Raised when authentication fails"""
    pass


class AccountNotFoundError(CalendarCleanerError):
    """Raised when specified account doesn't exist"""
    pass


# Backward compat alias
ProfileNotFoundError = AccountNotFoundError


# =============================================================================
# Filename and output directory utilities
# =============================================================================

def sanitize_email_for_filename(email: str) -> str:
    """Convert email to filesystem-safe format."""
    if not email:
        return '_at_'
    safe_email = email.replace('@', '_at_')
    safe_email = safe_email.replace('.', '_')
    safe_email = safe_email.replace('+', '_plus_')
    safe_email = safe_email.replace('-', '_dash_')
    safe_email = re.sub(r'[^\w_]', '_', safe_email)
    return safe_email


def get_output_directory(output_dir: Optional[str] = None,
                        user_email: Optional[str] = None,
                        organize_by_user: bool = False) -> Path:
    """Get output directory with user organization options."""
    if output_dir:
        base_dir = Path(output_dir).expanduser().resolve()
    else:
        base_dir = Path.cwd()

    if organize_by_user and user_email:
        safe_email = sanitize_email_for_filename(user_email)
        user_dir = base_dir / f"user_{safe_email}"
        try:
            user_dir.mkdir(parents=True, exist_ok=True)
            return user_dir
        except OSError as e:
            raise OSError(f"Failed to create user directory {user_dir}: {e}") from e
    else:
        try:
            base_dir.mkdir(parents=True, exist_ok=True)
            return base_dir
        except OSError as e:
            raise OSError(f"Failed to create output directory {base_dir}: {e}") from e


def create_user_filename(user_email: str,
                        file_type: str,
                        extension: str = 'json',
                        output_dir: Optional[str] = None,
                        organize_by_user: bool = False,
                        timestamp_format: str = "%Y%m%d_%H%M%S") -> Path:
    """Create filename with user email and flexible directory options."""
    if not user_email:
        raise ValueError("user_email is required")
    if not file_type:
        raise ValueError("file_type is required")

    safe_email = sanitize_email_for_filename(user_email)
    timestamp = datetime.now().strftime(timestamp_format)
    filename = f'{file_type}_{safe_email}_{timestamp}.{extension}'
    output_path = get_output_directory(output_dir, user_email, organize_by_user)
    return output_path / filename


# Environment variable support
def get_env_output_dir() -> Optional[str]:
    return os.getenv('CALWASH_OUTPUT_DIR') or os.getenv('CALENDAR_CLEANER_OUTPUT_DIR')


def get_env_backup_dir() -> Optional[str]:
    return os.getenv('CALWASH_BACKUP_DIR') or os.getenv('CALENDAR_CLEANER_BACKUP_DIR')


def get_env_organize_by_user() -> bool:
    val = os.getenv('CALWASH_ORGANIZE_BY_USER', '') or os.getenv('CALENDAR_CLEANER_ORGANIZE_BY_USER', '')
    return val.lower() in ('true', '1', 'yes')


# =============================================================================
# Account management
# =============================================================================

def get_account_directory(account: str = 'default') -> Path:
    """Get account directory path under ~/.calwash/ and ensure it exists."""
    account_dir = CALWASH_HOME / "accounts" / account
    try:
        account_dir.mkdir(parents=True, exist_ok=True)
        return account_dir
    except OSError as e:
        raise OSError(f"Failed to create account directory {account_dir}: {e}") from e


def get_account_token_path(account: str = 'default') -> Path:
    """Get path to token.pickle for a specific account."""
    return get_account_directory(account) / 'token.pickle'


def list_accounts() -> List[Tuple[str, str]]:
    """List all available accounts with their email addresses.

    Returns:
        List of (account_name, email) tuples.
    """
    accounts_dir = CALWASH_HOME / "accounts"
    if not accounts_dir.exists():
        return []

    result = []
    for item in sorted(accounts_dir.iterdir()):
        if item.is_dir():
            token_path = item / 'token.pickle'
            email_path = item / 'email.txt'

            if token_path.exists():
                if email_path.exists():
                    email = email_path.read_text().strip()
                else:
                    email = "(authenticated)"
                result.append((item.name, email))

    return result


def account_exists(account: str) -> bool:
    """Check if an account has a saved token."""
    return get_account_token_path(account).exists()


def _migrate_profiles_if_needed():
    """One-time migration from old profiles/ or ~/.calcleaner/ to ~/.calwash/accounts/."""
    logger = logging.getLogger(__name__)
    accounts_dir = CALWASH_HOME / "accounts"

    # Skip if already has accounts
    if accounts_dir.exists() and any(accounts_dir.iterdir()):
        return

    # Try old locations
    old_locations = [
        Path('profiles'),                          # CWD profiles/
        Path.home() / '.calcleaner' / 'accounts',  # old package name
    ]

    for old_dir in old_locations:
        if not old_dir.exists():
            continue

        migrated = 0
        for item in old_dir.iterdir():
            if item.is_dir():
                token_path = item / 'token.pickle'
                if token_path.exists():
                    dest = accounts_dir / item.name
                    dest.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(token_path, dest / 'token.pickle')
                    # Also copy email.txt if it exists
                    email_path = item / 'email.txt'
                    if email_path.exists():
                        shutil.copy2(email_path, dest / 'email.txt')
                    migrated += 1

        if migrated > 0:
            logger.info(f"Migrated {migrated} account(s) from {old_dir} to {accounts_dir}")
            break  # Only migrate from one source


# =============================================================================
# Backward compatibility aliases (deprecated)
# =============================================================================

def get_profile_directory(profile_name: str = 'default') -> Path:
    return get_account_directory(profile_name)

def get_profile_credentials_path(profile_name: str = 'default') -> Path:
    return CALWASH_HOME / "credentials.json"

def get_profile_token_path(profile_name: str = 'default') -> Path:
    return get_account_token_path(profile_name)

def list_available_profiles() -> List[str]:
    return [name for name, _ in list_accounts()]

def validate_profile_exists(profile_name: str) -> bool:
    return account_exists(profile_name)

def setup_service(account: str = 'default'):
    """Convenience wrapper that uses the Google provider."""
    from calwash.providers.google import GoogleProvider
    provider = GoogleProvider()
    email = provider.authenticate(account)
    return provider._service, email
