"""
Pattern detector factory for creating detectors from existing patterns.

This factory provides backward compatibility by creating new-style detectors
from the existing pattern definitions in the legacy codebase.
"""

import logging
from typing import List, Dict, Any

from ..base import PatternType
from ..detectors.base_detector import BasePatternDetector
from ..detectors.email_detector import EmailDetector
from ..detectors.phone_detector import PhoneDetector
from ..detectors.ssn_detector import SSNDetector
from ..validators.base_validators import (
    LuhnValidator, SSNValidator, PhoneValidator, 
    TimestampValidator, WhitelistValidator
)
from ..validators.credit_card_validator import CreditCardValidator
from ..validators.email_validator import EmailValidator
from ..validators.bank_account_validator import BankAccountValidator

logger = logging.getLogger(__name__)


class PatternDetectorFactory:
    """
    Factory for creating pattern detectors from existing code.
    
    This factory provides methods to create new-style detectors from
    the existing legacy patterns, ensuring backward compatibility.
    """
    
    @staticmethod
    def create_from_legacy_patterns() -> List[BasePatternDetector]:
        """
        Create pattern detectors from legacy pattern definitions.
        
        This method extracts patterns from the existing sensitive_patterns.py
        and creates new-style detectors for backward compatibility.
        
        Returns:
            List[BasePatternDetector]: List of created detectors
        """
        detectors = []
        
        try:
            # Import the legacy patterns
            from sensitive_patterns import get_all_sensitive_patterns
            
            legacy_patterns = get_all_sensitive_patterns()
            
            for pattern in legacy_patterns:
                detector = PatternDetectorFactory._convert_legacy_pattern(pattern)
                if detector:
                    detectors.append(detector)
                    
        except ImportError:
            logger.warning("Could not import legacy patterns, using default detectors")
            detectors = PatternDetectorFactory.create_default_detectors()
        except Exception as e:
            logger.error(f"Error creating detectors from legacy patterns: {e}")
            detectors = PatternDetectorFactory.create_default_detectors()
        
        return detectors
    
    @staticmethod
    def create_default_detectors() -> List[BasePatternDetector]:
        """
        Create a default set of pattern detectors.
        
        Returns:
            List[BasePatternDetector]: List of default detectors
        """
        detectors = []
        
        # Email detectors
        detectors.append(EmailDetector.create_default())
        
        # Phone detectors
        detectors.extend(PhoneDetector.create_all_phone_detectors())
        
        # SSN detectors
        detectors.extend(SSNDetector.create_all_ssn_detectors())
        
        # Credit card detectors
        detectors.extend(PatternDetectorFactory._create_credit_card_detectors())
        
        # URL detectors
        detectors.extend(PatternDetectorFactory._create_url_detectors())
        
        # Medical detectors
        detectors.extend(PatternDetectorFactory._create_medical_detectors())
        
        # Bank account detectors
        detectors.extend(PatternDetectorFactory._create_bank_account_detectors())
        
        return detectors
    
    @staticmethod
    def _convert_legacy_pattern(legacy_pattern) -> BasePatternDetector:
        """
        Convert a legacy SensitivePattern to a new BasePatternDetector.
        
        Args:
            legacy_pattern: Legacy SensitivePattern instance
            
        Returns:
            BasePatternDetector: Converted detector, or None if conversion fails
        """
        try:
            # Map legacy patterns to pattern types based on replacement text
            pattern_type_mapping = {
                '[EMAIL REMOVED]': PatternType.EMAIL,
                '[PHONE REMOVED]': PatternType.PHONE,
                '[SSN REMOVED]': PatternType.SSN,
                '[CARD REMOVED]': PatternType.CREDIT_CARD,
                '[ACCOUNT REMOVED]': PatternType.BANK_ACCOUNT,
                '[ROUTING REMOVED]': PatternType.BANK_ACCOUNT,
                '[LICENSE REMOVED]': PatternType.DRIVER_LICENSE,
                '[URL REMOVED]': PatternType.URL,
                'Private': PatternType.MEDICAL,
            }
            
            pattern_type = pattern_type_mapping.get(legacy_pattern.replacement)
            if not pattern_type:
                logger.warning(f"Unknown replacement pattern: {legacy_pattern.replacement}")
                return None
            
            # Create appropriate validator
            validator = None
            if legacy_pattern.validator:
                validator = PatternDetectorFactory._create_validator_from_legacy(
                    legacy_pattern.validator, pattern_type
                )
            
            # Create detector
            detector = BasePatternDetector(
                pattern_type=pattern_type,
                regex_pattern=legacy_pattern.pattern,
                replacement=legacy_pattern.replacement,
                validator=validator,
                description=legacy_pattern.description or f"Legacy {pattern_type.value} detector",
                case_sensitive=legacy_pattern.case_sensitive,
                enabled=True,
                priority=100  # Default priority for legacy patterns
            )
            
            return detector
            
        except Exception as e:
            logger.error(f"Failed to convert legacy pattern: {e}")
            return None
    
    @staticmethod
    def _create_validator_from_legacy(legacy_validator_func, pattern_type: PatternType):
        """
        Create a new-style validator from a legacy validator function.
        
        Args:
            legacy_validator_func: Legacy validator function
            pattern_type: Pattern type for the validator
            
        Returns:
            PatternValidator: New-style validator instance
        """
        if pattern_type == PatternType.EMAIL:
            return EmailValidator()
        elif pattern_type == PatternType.PHONE:
            return PhoneValidator()
        elif pattern_type == PatternType.SSN:
            return SSNValidator()
        elif pattern_type == PatternType.CREDIT_CARD:
            return CreditCardValidator()
        elif pattern_type == PatternType.BANK_ACCOUNT:
            return BankAccountValidator()
        else:
            # Create a generic validator wrapper
            class LegacyValidatorWrapper:
                def __init__(self, validator_func):
                    self.validator_func = validator_func
                
                def validate(self, text: str, context=None) -> bool:
                    return self.validator_func(text)
                
                def get_confidence(self, text: str, context=None) -> float:
                    return 1.0 if self.validate(text, context) else 0.0
            
            return LegacyValidatorWrapper(legacy_validator_func)
    
    @staticmethod
    def _create_credit_card_detectors() -> List[BasePatternDetector]:
        """Create credit card detectors."""
        validator = CreditCardValidator()
        
        return [
            # Visa
            BasePatternDetector(
                pattern_type=PatternType.CREDIT_CARD,
                regex_pattern=r'\b4[0-9]{3}[\s-]?[0-9]{4}[\s-]?[0-9]{4}[\s-]?[0-9]{1,4}\b',
                replacement='[CARD REMOVED]',
                validator=validator,
                description='Visa card format',
                priority=20
            ),
            # MasterCard
            BasePatternDetector(
                pattern_type=PatternType.CREDIT_CARD,
                regex_pattern=r'\b5[1-5][0-9]{2}[\s-]?[0-9]{4}[\s-]?[0-9]{4}[\s-]?[0-9]{4}\b',
                replacement='[CARD REMOVED]',
                validator=validator,
                description='MasterCard format',
                priority=21
            ),
            # American Express
            BasePatternDetector(
                pattern_type=PatternType.CREDIT_CARD,
                regex_pattern=r'\b3[47][0-9]{2}[\s-]?[0-9]{6}[\s-]?[0-9]{5}\b',
                replacement='[CARD REMOVED]',
                validator=validator,
                description='American Express format',
                priority=22
            ),
            # Discover
            BasePatternDetector(
                pattern_type=PatternType.CREDIT_CARD,
                regex_pattern=r'\b(?:6011|65[0-9]{2})[\s-]?[0-9]{4}[\s-]?[0-9]{4}[\s-]?[0-9]{4}\b',
                replacement='[CARD REMOVED]',
                validator=validator,
                description='Discover card format',
                priority=23
            ),
        ]
    
    @staticmethod
    def _create_url_detectors() -> List[BasePatternDetector]:
        """Create URL detectors."""
        return [
            BasePatternDetector(
                pattern_type=PatternType.URL,
                regex_pattern=r'https?://[^\s]+',
                replacement='[URL REMOVED]',
                description='HTTP/HTTPS URLs',
                priority=10
            ),
            BasePatternDetector(
                pattern_type=PatternType.URL,
                regex_pattern=r'www\.[^\s]+',
                replacement='[URL REMOVED]',
                description='www URLs',
                priority=11
            ),
        ]
    
    @staticmethod
    def _create_medical_detectors() -> List[BasePatternDetector]:
        """Create medical term detectors."""
        return [
            BasePatternDetector(
                pattern_type=PatternType.MEDICAL,
                regex_pattern=r'\b(?:doctor|dr\.?|physician|md|appointment|medical|health|hospital|clinic|surgery|procedure|prescription|medication|therapy|treatment|diagnosis|patient|checkup|exam|consultation|visit)\b',
                replacement='Private',
                description='Medical and health terms',
                case_sensitive=False,
                priority=30
            ),
        ]
    
    @staticmethod
    def _create_bank_account_detectors() -> List[BasePatternDetector]:
        """Create bank account detectors."""
        validator = BankAccountValidator()
        
        return [
            # Bank account numbers
            BasePatternDetector(
                pattern_type=PatternType.BANK_ACCOUNT,
                regex_pattern=r'\b\d{8,12}\b',
                replacement='[ACCOUNT REMOVED]',
                validator=validator,
                description='Bank account number',
                priority=35
            ),
            # Routing numbers
            BasePatternDetector(
                pattern_type=PatternType.BANK_ACCOUNT,
                regex_pattern=r'\b\d{9}\b',
                replacement='[ROUTING REMOVED]',
                validator=validator,
                description='Bank routing number',
                priority=34
            ),
        ]
    
    @staticmethod
    def populate_registry_with_defaults():
        """
        Populate the global registry with default detectors.
        
        This method is used to initialize the registry with a comprehensive
        set of pattern detectors.
        """
        from ..registry.pattern_registry import get_global_registry
        
        registry = get_global_registry()
        detectors = PatternDetectorFactory.create_default_detectors()
        
        for detector in detectors:
            registry.register_detector(detector)
        
        logger.info(f"Populated registry with {len(detectors)} default detectors")
    
    @staticmethod
    def populate_registry_with_legacy_patterns():
        """
        Populate the global registry with patterns from legacy code.
        
        This method provides backward compatibility by loading patterns
        from the existing sensitive_patterns.py file.
        """
        from ..registry.pattern_registry import get_global_registry
        
        registry = get_global_registry()
        detectors = PatternDetectorFactory.create_from_legacy_patterns()
        
        for detector in detectors:
            registry.register_detector(detector)
        
        logger.info(f"Populated registry with {len(detectors)} legacy detectors")