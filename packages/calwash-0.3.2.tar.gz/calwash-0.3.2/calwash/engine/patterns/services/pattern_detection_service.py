"""
Pattern detection service that orchestrates all pattern detection operations.

This service provides a high-level interface for pattern detection and cleaning,
managing the pattern registry and coordinating between different detectors.
"""

import logging
from typing import List, Dict, Optional, Any, Set
from collections import defaultdict
import time

from ..base import PatternType, PatternMatch, CleaningContext
from ..registry.pattern_registry import PatternRegistry, get_global_registry
from ..registry.config_loader import ConfigLoader

logger = logging.getLogger(__name__)


class PatternDetectionService:
    """
    High-level service for pattern detection and text cleaning.
    
    This service orchestrates all pattern detection operations, manages
    the pattern registry, and provides convenient methods for cleaning text.
    """
    
    def __init__(self, registry: Optional[PatternRegistry] = None):
        """
        Initialize the pattern detection service.
        
        Args:
            registry: Optional pattern registry (uses global registry if None)
        """
        self.registry = registry or get_global_registry()
        self.config_loader = ConfigLoader()
        self._stats = defaultdict(int)
        self._last_cleanup = time.time()
    
    def detect_patterns(
        self,
        text: str,
        context: Optional[CleaningContext] = None,
        pattern_types: Optional[Set[PatternType]] = None
    ) -> List[PatternMatch]:
        """
        Detect all enabled patterns in the given text.
        
        Args:
            text: Text to scan for patterns
            context: Additional context for detection
            pattern_types: Optional set of pattern types to detect (all enabled if None)
            
        Returns:
            List[PatternMatch]: List of all detected pattern matches
        """
        if not text.strip():
            return []
        
        start_time = time.time()
        all_matches = []
        
        try:
            # Get enabled pattern types
            enabled_types = self.registry.get_enabled_pattern_types()
            if pattern_types:
                enabled_types &= pattern_types
            
            # Detect patterns for each enabled type
            for pattern_type in enabled_types:
                composite_detector = self.registry.get_composite_detector(pattern_type)
                if composite_detector:
                    matches = composite_detector.detect(text, context)
                    all_matches.extend(matches)
                    self._stats[f'detections_{pattern_type.value}'] += len(matches)
            
            # Remove overlapping matches
            non_overlapping_matches = self._remove_overlapping_matches(all_matches)
            
            # Update statistics
            self._stats['total_detections'] += len(non_overlapping_matches)
            self._stats['detection_calls'] += 1
            self._stats['total_detection_time'] += time.time() - start_time
            
            return non_overlapping_matches
            
        except Exception as e:
            logger.error(f"Error detecting patterns: {e}")
            self._stats['detection_errors'] += 1
            return []
    
    def clean_text(
        self,
        text: str,
        context: Optional[CleaningContext] = None,
        pattern_types: Optional[Set[PatternType]] = None
    ) -> str:
        """
        Clean text by replacing detected patterns.
        
        Args:
            text: Text to clean
            context: Additional context for cleaning
            pattern_types: Optional set of pattern types to clean (all enabled if None)
            
        Returns:
            str: Cleaned text with sensitive information replaced
        """
        if not text.strip():
            return text
        
        start_time = time.time()
        
        try:
            # Detect patterns
            matches = self.detect_patterns(text, context, pattern_types)
            if not matches:
                return text
            
            # Sort matches by position (reverse order to maintain positions)
            matches.sort(key=lambda x: x.start, reverse=True)
            
            # Apply replacements
            result = text
            replacements_made = 0
            
            for match in matches:
                if match.is_validated:
                    result = result[:match.start] + match.replacement + result[match.end:]
                    replacements_made += 1
            
            # Update statistics
            self._stats['cleaning_calls'] += 1
            self._stats['total_cleaning_time'] += time.time() - start_time
            self._stats['total_replacements'] += replacements_made
            
            return result
            
        except Exception as e:
            logger.error(f"Error cleaning text: {e}")
            self._stats['cleaning_errors'] += 1
            return text
    
    def clean_event_data(self, event_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Clean an event data dictionary.
        
        Args:
            event_data: Event data dictionary to clean
            
        Returns:
            Dict[str, Any]: Cleaned event data
        """
        if not event_data:
            return event_data
        
        cleaned_data = event_data.copy()
        
        # Fields to clean
        cleanable_fields = ['summary', 'description', 'location']
        
        for field in cleanable_fields:
            if field in cleaned_data and isinstance(cleaned_data[field], str):
                # Create context for this field
                context = CleaningContext(
                    field_name=field,
                    event_data=event_data
                )
                
                # Clean the field
                cleaned_data[field] = self.clean_text(
                    cleaned_data[field],
                    context
                )
        
        return cleaned_data
    
    def batch_clean_events(self, events: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Clean a batch of events efficiently.
        
        Args:
            events: List of event data dictionaries
            
        Returns:
            List[Dict[str, Any]]: List of cleaned event data
        """
        if not events:
            return events
        
        start_time = time.time()
        cleaned_events = []
        
        try:
            for event in events:
                cleaned_event = self.clean_event_data(event)
                cleaned_events.append(cleaned_event)
            
            # Update statistics
            self._stats['batch_cleaning_calls'] += 1
            self._stats['total_batch_cleaning_time'] += time.time() - start_time
            self._stats['events_processed'] += len(events)
            
            return cleaned_events
            
        except Exception as e:
            logger.error(f"Error in batch cleaning: {e}")
            self._stats['batch_cleaning_errors'] += 1
            return events
    
    def get_detection_preview(
        self,
        text: str,
        context: Optional[CleaningContext] = None,
        pattern_types: Optional[Set[PatternType]] = None
    ) -> Dict[str, Any]:
        """
        Get a preview of what would be detected/cleaned without actually cleaning.
        
        Args:
            text: Text to analyze
            context: Additional context
            pattern_types: Optional set of pattern types to analyze
            
        Returns:
            Dict[str, Any]: Preview information including matches and cleaned text
        """
        matches = self.detect_patterns(text, context, pattern_types)
        
        # Group matches by type
        matches_by_type = defaultdict(list)
        for match in matches:
            matches_by_type[match.pattern_type.value].append(match.to_dict())
        
        # Create cleaned text preview
        cleaned_text = self.clean_text(text, context, pattern_types)
        
        return {
            'original_text': text,
            'cleaned_text': cleaned_text,
            'total_matches': len(matches),
            'matches_by_type': dict(matches_by_type),
            'enabled_pattern_types': [pt.value for pt in self.registry.get_enabled_pattern_types()],
            'changes_made': text != cleaned_text
        }
    
    def configure_from_file(self, config_file_path: str) -> None:
        """
        Configure the service from a configuration file.
        
        Args:
            config_file_path: Path to the configuration file
        """
        from pathlib import Path
        
        try:
            config = self.config_loader.load_from_file(Path(config_file_path))
            self.registry.update_configuration(config)
            logger.info(f"Configured service from {config_file_path}")
        except Exception as e:
            logger.error(f"Failed to load configuration from {config_file_path}: {e}")
            raise
    
    def configure_from_dict(self, config: Dict[str, Any]) -> None:
        """
        Configure the service from a configuration dictionary.
        
        Args:
            config: Configuration dictionary
        """
        try:
            validated_config = self.config_loader.load_from_dict(config)
            self.registry.update_configuration(validated_config)
            logger.info("Configured service from dictionary")
        except Exception as e:
            logger.error(f"Failed to load configuration from dictionary: {e}")
            raise
    
    def get_service_stats(self) -> Dict[str, Any]:
        """
        Get service statistics.
        
        Returns:
            Dict[str, Any]: Service statistics
        """
        stats = dict(self._stats)
        
        # Add registry stats
        registry_stats = self.registry.get_stats()
        stats.update(registry_stats)
        
        # Calculate derived statistics
        if stats.get('detection_calls', 0) > 0:
            stats['avg_detection_time'] = stats.get('total_detection_time', 0) / stats['detection_calls']
        
        if stats.get('cleaning_calls', 0) > 0:
            stats['avg_cleaning_time'] = stats.get('total_cleaning_time', 0) / stats['cleaning_calls']
        
        if stats.get('total_detections', 0) > 0:
            stats['avg_replacements_per_detection'] = stats.get('total_replacements', 0) / stats['total_detections']
        
        stats['service_uptime'] = time.time() - (self._stats.get('service_start_time', time.time()))
        
        return stats
    
    def reset_stats(self) -> None:
        """Reset service statistics."""
        self._stats.clear()
        self._stats['service_start_time'] = time.time()
    
    def _remove_overlapping_matches(self, matches: List[PatternMatch]) -> List[PatternMatch]:
        """
        Remove overlapping matches, keeping the highest confidence match.
        
        Args:
            matches: List of pattern matches
            
        Returns:
            List[PatternMatch]: Non-overlapping matches
        """
        if not matches:
            return []
        
        # Sort by start position
        sorted_matches = sorted(matches, key=lambda x: x.start)
        
        result = []
        last_end = -1
        
        for match in sorted_matches:
            # Skip overlapping matches (keep the first one with higher confidence)
            if match.start < last_end:
                # Check if current match has higher confidence than the last added
                if result and match.confidence > result[-1].confidence:
                    result[-1] = match  # Replace with higher confidence match
                continue
            
            result.append(match)
            last_end = match.end
        
        return result
    
    def __str__(self) -> str:
        """String representation of the service."""
        registry_stats = self.registry.get_stats()
        return (
            f"PatternDetectionService("
            f"enabled_types={registry_stats['enabled_pattern_types']}, "
            f"detectors={registry_stats['enabled_detectors']}, "
            f"calls={self._stats.get('detection_calls', 0)})"
        )


# Global service instance
_global_service: Optional[PatternDetectionService] = None

def get_global_service() -> PatternDetectionService:
    """
    Get the global pattern detection service instance.
    
    Returns:
        PatternDetectionService: The global service instance
    """
    global _global_service
    if _global_service is None:
        _global_service = PatternDetectionService()
    return _global_service


def reset_global_service() -> None:
    """Reset the global pattern detection service (useful for testing)."""
    global _global_service
    _global_service = None