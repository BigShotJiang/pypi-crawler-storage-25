"""
Core pattern detection module for calendar cleaning.

This module provides the foundational classes and interfaces for pattern detection,
validation, and cleaning operations in the calendar cleaning system.
"""

from .base import (
    PatternDetector,
    PatternValidator,
    PatternMatch,
    PatternType,
    CleaningContext,
    CompositePatternDetector,
    PatternDetectorFactory,
)

from .registry.pattern_registry import PatternRegistry, get_global_registry
from .registry.config_loader import ConfigLoader
from .services.pattern_detection_service import PatternDetectionService, get_global_service
from .services.pattern_factory import PatternDetectorFactory as PatternFactory

# Backward compatibility imports
from .compatibility import (
    clean_text_with_validation,
    SensitivePattern,
    get_all_sensitive_patterns,
    clean_text_validated,
)

__all__ = [
    # Core abstractions
    'PatternDetector',
    'PatternValidator', 
    'PatternMatch',
    'PatternType',
    'CleaningContext',
    'CompositePatternDetector',
    'PatternDetectorFactory',
    
    # Registry and configuration
    'PatternRegistry',
    'get_global_registry',
    'ConfigLoader',
    
    # Services
    'PatternDetectionService',
    'get_global_service',
    'PatternFactory',
    
    # Backward compatibility
    'clean_text_with_validation',
    'SensitivePattern',
    'get_all_sensitive_patterns', 
    'clean_text_validated',
]