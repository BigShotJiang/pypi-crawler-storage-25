"""
Configuration loader for pattern registry.

This module provides utilities to load pattern configurations from various sources
including JSON files, YAML files, and environment variables.
"""

import json
import logging
import os
import threading
from pathlib import Path
from typing import Dict, Any, Optional, List
from functools import lru_cache
from collections import OrderedDict
import yaml

from ..base import PatternType

logger = logging.getLogger(__name__)


class LRUCache:
    """
    Thread-safe LRU (Least Recently Used) cache implementation.
    
    This cache automatically removes the least recently used items when
    the maximum size is reached, preventing memory leaks.
    """
    
    def __init__(self, max_size: int = 100):
        """
        Initialize LRU cache.
        
        Args:
            max_size: Maximum number of items to cache
        """
        self.max_size = max_size
        self.cache = OrderedDict()
        self._lock = threading.RLock()
    
    def get(self, key: str) -> Optional[Any]:
        """
        Get item from cache.
        
        Args:
            key: Cache key
            
        Returns:
            Cached value or None if not found
        """
        with self._lock:
            if key in self.cache:
                # Move to end (mark as recently used)
                self.cache.move_to_end(key)
                return self.cache[key]
            return None
    
    def put(self, key: str, value: Any) -> None:
        """
        Put item in cache.
        
        Args:
            key: Cache key
            value: Value to cache
        """
        with self._lock:
            if key in self.cache:
                # Update existing item
                self.cache.move_to_end(key)
                self.cache[key] = value
            else:
                # Add new item
                self.cache[key] = value
                
                # Remove oldest item if cache is full
                if len(self.cache) > self.max_size:
                    oldest = next(iter(self.cache))
                    del self.cache[oldest]
                    logger.debug(f"Evicted cache entry: {oldest}")
    
    def clear(self) -> None:
        """Clear all cached items."""
        with self._lock:
            self.cache.clear()
    
    def size(self) -> int:
        """Get current cache size."""
        with self._lock:
            return len(self.cache)
    
    def stats(self) -> Dict[str, Any]:
        """Get cache statistics."""
        with self._lock:
            return {
                "size": len(self.cache),
                "max_size": self.max_size,
                "keys": list(self.cache.keys())
            }


class ConfigLoader:
    """
    Utility class for loading pattern configuration from various sources.
    
    Supports loading from JSON files, YAML files, environment variables,
    and direct configuration dictionaries.
    """
    
    def __init__(self, cache_size: int = 50):
        """
        Initialize the configuration loader.
        
        Args:
            cache_size: Maximum number of configurations to cache
        """
        self._config_cache = LRUCache(max_size=cache_size)
        self._default_config = self._get_default_config()
        logger.debug(f"ConfigLoader initialized with cache size: {cache_size}")
    
    def load_from_file(self, file_path: Path) -> Dict[str, Any]:
        """
        Load configuration from a file.
        
        Args:
            file_path: Path to the configuration file (JSON or YAML)
            
        Returns:
            Dict[str, Any]: Loaded configuration
            
        Raises:
            FileNotFoundError: If the file doesn't exist
            ValueError: If the file format is not supported or invalid
        """
        if not file_path.exists():
            raise FileNotFoundError(f"Configuration file not found: {file_path}")
        
        file_key = str(file_path)
        cached_config = self._config_cache.get(file_key)
        if cached_config is not None:
            logger.debug(f"Using cached configuration for {file_path}")
            return cached_config
        
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                if file_path.suffix.lower() in ['.yaml', '.yml']:
                    config = yaml.safe_load(f)
                elif file_path.suffix.lower() == '.json':
                    config = json.load(f)
                else:
                    raise ValueError(f"Unsupported file format: {file_path.suffix}")
            
            # Validate and normalize the configuration
            config = self._validate_and_normalize_config(config)
            
            # Cache the configuration
            self._config_cache.put(file_key, config)
            
            logger.info(f"Loaded configuration from {file_path}")
            return config
            
        except (json.JSONDecodeError, yaml.YAMLError) as e:
            raise ValueError(f"Invalid configuration file format: {e}")
        except Exception as e:
            logger.error(f"Failed to load configuration from {file_path}: {e}")
            raise
    
    def load_from_dict(self, config_dict: Dict[str, Any]) -> Dict[str, Any]:
        """
        Load configuration from a dictionary.
        
        Args:
            config_dict: Configuration dictionary
            
        Returns:
            Dict[str, Any]: Validated and normalized configuration
        """
        return self._validate_and_normalize_config(config_dict)
    
    def load_from_env(self, prefix: str = "CALCLEANER_") -> Dict[str, Any]:
        """
        Load configuration from environment variables.
        
        Args:
            prefix: Prefix for environment variables
            
        Returns:
            Dict[str, Any]: Configuration loaded from environment
        """
        config = {}
        
        # Load enabled patterns
        enabled_patterns_env = os.getenv(f"{prefix}ENABLED_PATTERNS")
        if enabled_patterns_env:
            config['enabled_patterns'] = enabled_patterns_env.split(',')
        
        # Load disabled patterns
        disabled_patterns_env = os.getenv(f"{prefix}DISABLED_PATTERNS")
        if disabled_patterns_env:
            config['disabled_patterns'] = disabled_patterns_env.split(',')
        
        # Load other configuration options
        options = {
            'validation_enabled': f"{prefix}VALIDATION_ENABLED",
            'max_confidence_threshold': f"{prefix}MAX_CONFIDENCE_THRESHOLD",
            'min_confidence_threshold': f"{prefix}MIN_CONFIDENCE_THRESHOLD",
            'case_sensitive': f"{prefix}CASE_SENSITIVE",
            'debug_mode': f"{prefix}DEBUG_MODE"
        }
        
        for key, env_var in options.items():
            value = os.getenv(env_var)
            if value is not None:
                # Convert string values to appropriate types
                if key in ['validation_enabled', 'case_sensitive', 'debug_mode']:
                    config[key] = value.lower() in ['true', '1', 'yes', 'on']
                elif key in ['max_confidence_threshold', 'min_confidence_threshold']:
                    try:
                        config[key] = float(value)
                    except ValueError:
                        logger.warning(f"Invalid float value for {env_var}: {value}")
                else:
                    config[key] = value
        
        logger.info(f"Loaded configuration from environment variables with prefix {prefix}")
        return self._validate_and_normalize_config(config)
    
    def load_combined_config(
        self,
        file_path: Optional[Path] = None,
        env_prefix: str = "CALCLEANER_",
        override_dict: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Load configuration from multiple sources with precedence.
        
        Order of precedence (highest to lowest):
        1. override_dict
        2. environment variables
        3. configuration file
        4. default configuration
        
        Args:
            file_path: Optional path to configuration file
            env_prefix: Prefix for environment variables
            override_dict: Optional override configuration
            
        Returns:
            Dict[str, Any]: Combined configuration
        """
        config = self._default_config.copy()
        
        # Load from file if provided
        if file_path:
            try:
                file_config = self.load_from_file(file_path)
                config.update(file_config)
            except Exception as e:
                logger.warning(f"Failed to load file configuration: {e}")
        
        # Load from environment variables
        try:
            env_config = self.load_from_env(env_prefix)
            config.update(env_config)
        except Exception as e:
            logger.warning(f"Failed to load environment configuration: {e}")
        
        # Apply override dictionary
        if override_dict:
            config.update(override_dict)
        
        return self._validate_and_normalize_config(config)
    
    def get_default_config(self) -> Dict[str, Any]:
        """
        Get the default configuration.
        
        Returns:
            Dict[str, Any]: Default configuration
        """
        return self._default_config.copy()
    
    def clear_cache(self) -> None:
        """Clear the configuration cache."""
        self._config_cache.clear()
        logger.debug("Cleared configuration cache")
    
    def _get_default_config(self) -> Dict[str, Any]:
        """
        Get the default configuration.
        
        Returns:
            Dict[str, Any]: Default configuration
        """
        return {
            'enabled_patterns': [
                PatternType.EMAIL.value,
                PatternType.PHONE.value,
                PatternType.SSN.value,
                PatternType.CREDIT_CARD.value,
                PatternType.URL.value,
                PatternType.MEDICAL.value
            ],
            'disabled_patterns': [
                PatternType.DRIVER_LICENSE.value  # Disabled by default due to high false positive rate
            ],
            'validation_enabled': True,
            'max_confidence_threshold': 1.0,
            'min_confidence_threshold': 0.7,
            'case_sensitive': False,
            'debug_mode': False,
            'replacement_templates': {
                PatternType.EMAIL.value: '[EMAIL REMOVED]',
                PatternType.PHONE.value: '[PHONE REMOVED]',
                PatternType.SSN.value: '[SSN REMOVED]',
                PatternType.CREDIT_CARD.value: '[CARD REMOVED]',
                PatternType.BANK_ACCOUNT.value: '[ACCOUNT REMOVED]',
                PatternType.DRIVER_LICENSE.value: '[LICENSE REMOVED]',
                PatternType.URL.value: '[URL REMOVED]',
                PatternType.MEDICAL.value: 'Private',
                PatternType.ADDRESS.value: '[ADDRESS REMOVED]',
                PatternType.FINANCIAL.value: '[FINANCIAL REMOVED]',
                PatternType.PERSONAL_ID.value: '[ID REMOVED]'
            }
        }
    
    def _validate_and_normalize_config(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """
        Validate and normalize a configuration dictionary.
        
        Args:
            config: Configuration to validate
            
        Returns:
            Dict[str, Any]: Validated and normalized configuration
            
        Raises:
            ValueError: If the configuration is invalid
        """
        if not isinstance(config, dict):
            raise ValueError("Configuration must be a dictionary")
        
        normalized_config = {}
        
        # Validate enabled patterns
        if 'enabled_patterns' in config:
            enabled = config['enabled_patterns']
            if not isinstance(enabled, list):
                raise ValueError("enabled_patterns must be a list")
            
            normalized_enabled = []
            for pattern in enabled:
                try:
                    pattern_type = PatternType(pattern)
                    normalized_enabled.append(pattern_type.value)
                except ValueError:
                    logger.warning(f"Unknown pattern type: {pattern}")
            
            normalized_config['enabled_patterns'] = normalized_enabled
        
        # Validate disabled patterns
        if 'disabled_patterns' in config:
            disabled = config['disabled_patterns']
            if not isinstance(disabled, list):
                raise ValueError("disabled_patterns must be a list")
            
            normalized_disabled = []
            for pattern in disabled:
                try:
                    pattern_type = PatternType(pattern)
                    normalized_disabled.append(pattern_type.value)
                except ValueError:
                    logger.warning(f"Unknown pattern type: {pattern}")
            
            normalized_config['disabled_patterns'] = normalized_disabled
        
        # Validate boolean options
        bool_options = ['validation_enabled', 'case_sensitive', 'debug_mode']
        for option in bool_options:
            if option in config:
                value = config[option]
                if isinstance(value, bool):
                    normalized_config[option] = value
                elif isinstance(value, str):
                    normalized_config[option] = value.lower() in ['true', '1', 'yes', 'on']
                else:
                    logger.warning(f"Invalid boolean value for {option}: {value}")
        
        # Validate float options
        float_options = ['max_confidence_threshold', 'min_confidence_threshold']
        for option in float_options:
            if option in config:
                value = config[option]
                try:
                    float_value = float(value)
                    if 0.0 <= float_value <= 1.0:
                        normalized_config[option] = float_value
                    else:
                        logger.warning(f"Confidence threshold must be between 0.0 and 1.0: {value}")
                except (ValueError, TypeError):
                    logger.warning(f"Invalid float value for {option}: {value}")
        
        # Validate replacement templates
        if 'replacement_templates' in config:
            templates = config['replacement_templates']
            if isinstance(templates, dict):
                normalized_templates = {}
                for pattern_type_str, replacement in templates.items():
                    try:
                        pattern_type = PatternType(pattern_type_str)
                        if isinstance(replacement, str):
                            normalized_templates[pattern_type.value] = replacement
                        else:
                            logger.warning(f"Replacement must be a string for {pattern_type_str}")
                    except ValueError:
                        logger.warning(f"Unknown pattern type in replacement templates: {pattern_type_str}")
                
                normalized_config['replacement_templates'] = normalized_templates
        
        # Copy over any other valid configuration options
        other_options = set(config.keys()) - {
            'enabled_patterns', 'disabled_patterns', 'validation_enabled',
            'max_confidence_threshold', 'min_confidence_threshold',
            'case_sensitive', 'debug_mode', 'replacement_templates'
        }
        
        for option in other_options:
            normalized_config[option] = config[option]
        
        return normalized_config
    
    def clear_cache(self) -> None:
        """Clear all cached configurations."""
        self._config_cache.clear()
        logger.info("Configuration cache cleared")
    
    def get_cache_stats(self) -> Dict[str, Any]:
        """
        Get cache statistics.
        
        Returns:
            Dict[str, Any]: Cache statistics including size and hit rate
        """
        return self._config_cache.stats()
    
    def evict_from_cache(self, file_path: Path) -> None:
        """
        Remove a specific configuration from cache.
        
        Args:
            file_path: Path to the configuration file to evict
        """
        file_key = str(file_path)
        # We can't directly remove from OrderedDict in our LRU cache implementation,
        # but we can overwrite with None and let it be evicted naturally
        if self._config_cache.get(file_key) is not None:
            # The cache will naturally evict this when space is needed
            logger.debug(f"Marked configuration for eviction: {file_path}")
    
    def reload_from_file(self, file_path: Path, force: bool = True) -> Dict[str, Any]:
        """
        Reload configuration from file, optionally bypassing cache.
        
        Args:
            file_path: Path to the configuration file
            force: Whether to bypass cache and force reload
            
        Returns:
            Dict[str, Any]: Reloaded configuration
        """
        if force:
            self.evict_from_cache(file_path)
        
        return self.load_from_file(file_path)