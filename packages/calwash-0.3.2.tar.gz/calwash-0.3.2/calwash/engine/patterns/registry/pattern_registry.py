"""
Pattern registry for managing pattern detectors and validators.

This module provides a centralized registry system for pattern detectors,
allowing for dynamic loading, configuration, and management of patterns.
"""

import logging
from typing import Dict, List, Optional, Set, Type, Any
from collections import defaultdict
import threading

from ..base import (
    PatternDetector,
    PatternValidator,
    PatternType,
    PatternDetectorFactory,
    CompositePatternDetector
)

logger = logging.getLogger(__name__)


class PatternRegistry:
    """
    Centralized registry for pattern detectors and validators.
    
    This registry manages all pattern detectors in the system, providing
    methods to register, retrieve, and configure detectors dynamically.
    """
    
    _instance: Optional['PatternRegistry'] = None
    _creation_lock = threading.Lock()
    
    def __new__(cls) -> 'PatternRegistry':
        """Singleton pattern implementation with double-checked locking."""
        if cls._instance is None:
            with cls._creation_lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
        return cls._instance
    
    def __init__(self):
        """Initialize the registry."""
        if not hasattr(self, '_initialized'):
            self._detectors: Dict[PatternType, List[PatternDetector]] = defaultdict(list)
            self._validators: Dict[PatternType, PatternValidator] = {}
            self._factories: Dict[PatternType, PatternDetectorFactory] = {}
            self._enabled_types: Set[PatternType] = set()
            self._configuration: Dict[str, Any] = {}
            self._operations_lock = threading.RLock()  # For thread-safe operations
            self._initialized = True
    
    def register_detector(self, detector: PatternDetector) -> None:
        """
        Register a pattern detector.
        
        Args:
            detector: The pattern detector to register
        """
        with self._operations_lock:
            self._detectors[detector.pattern_type].append(detector)
            if detector.enabled:
                self._enabled_types.add(detector.pattern_type)
            
            # Sort detectors by priority (lower number = higher priority)
            self._detectors[detector.pattern_type].sort(key=lambda d: d.priority)
            
            logger.debug(f"Registered detector for {detector.pattern_type.value}: {detector.description}")
    
    def register_validator(self, pattern_type: PatternType, validator: PatternValidator) -> None:
        """
        Register a pattern validator.
        
        Args:
            pattern_type: The pattern type this validator handles
            validator: The validator to register
        """
        with self._operations_lock:
            self._validators[pattern_type] = validator
            logger.debug(f"Registered validator for {pattern_type.value}")
    
    def register_factory(self, pattern_type: PatternType, factory: PatternDetectorFactory) -> None:
        """
        Register a pattern detector factory.
        
        Args:
            pattern_type: The pattern type this factory handles
            factory: The factory to register
        """
        with self._operations_lock:
            self._factories[pattern_type] = factory
            logger.debug(f"Registered factory for {pattern_type.value}")
    
    def get_detectors(self, pattern_type: PatternType) -> List[PatternDetector]:
        """
        Get all detectors for a specific pattern type.
        
        Args:
            pattern_type: The pattern type to get detectors for
            
        Returns:
            List[PatternDetector]: List of detectors for the pattern type
        """
        with self._operations_lock:
            return self._detectors.get(pattern_type, []).copy()
    
    def get_enabled_detectors(self, pattern_type: PatternType) -> List[PatternDetector]:
        """
        Get all enabled detectors for a specific pattern type.
        
        Args:
            pattern_type: The pattern type to get detectors for
            
        Returns:
            List[PatternDetector]: List of enabled detectors for the pattern type
        """
        with self._operations_lock:
            return [d for d in self._detectors.get(pattern_type, []) if d.enabled]
    
    def get_all_detectors(self) -> Dict[PatternType, List[PatternDetector]]:
        """
        Get all registered detectors.
        
        Returns:
            Dict[PatternType, List[PatternDetector]]: All registered detectors
        """
        with self._operations_lock:
            return {k: v.copy() for k, v in self._detectors.items()}
    
    def get_all_enabled_detectors(self) -> Dict[PatternType, List[PatternDetector]]:
        """
        Get all enabled detectors.
        
        Returns:
            Dict[PatternType, List[PatternDetector]]: All enabled detectors
        """
        with self._operations_lock:
            return {
                k: [d for d in v if d.enabled] 
                for k, v in self._detectors.items()
            }
    
    def get_validator(self, pattern_type: PatternType) -> Optional[PatternValidator]:
        """
        Get the validator for a specific pattern type.
        
        Args:
            pattern_type: The pattern type to get validator for
            
        Returns:
            Optional[PatternValidator]: The validator if registered
        """
        with self._operations_lock:
            return self._validators.get(pattern_type)
    
    def get_composite_detector(self, pattern_type: PatternType) -> Optional[CompositePatternDetector]:
        """
        Get a composite detector for a pattern type.
        
        Args:
            pattern_type: The pattern type to create composite detector for
            
        Returns:
            Optional[CompositePatternDetector]: Composite detector if detectors exist
        """
        detectors = self.get_enabled_detectors(pattern_type)
        if not detectors:
            return None
        
        return CompositePatternDetector(pattern_type, detectors)
    
    def enable_pattern_type(self, pattern_type: PatternType) -> None:
        """
        Enable all detectors for a pattern type.
        
        Args:
            pattern_type: The pattern type to enable
        """
        with self._operations_lock:
            for detector in self._detectors.get(pattern_type, []):
                detector.enabled = True
            self._enabled_types.add(pattern_type)
            logger.info(f"Enabled pattern type: {pattern_type.value}")
    
    def disable_pattern_type(self, pattern_type: PatternType) -> None:
        """
        Disable all detectors for a pattern type.
        
        Args:
            pattern_type: The pattern type to disable
        """
        with self._operations_lock:
            for detector in self._detectors.get(pattern_type, []):
                detector.enabled = False
            self._enabled_types.discard(pattern_type)
            logger.info(f"Disabled pattern type: {pattern_type.value}")
    
    def is_pattern_type_enabled(self, pattern_type: PatternType) -> bool:
        """
        Check if a pattern type is enabled.
        
        Args:
            pattern_type: The pattern type to check
            
        Returns:
            bool: True if the pattern type is enabled
        """
        with self._operations_lock:
            return pattern_type in self._enabled_types
    
    def get_enabled_pattern_types(self) -> Set[PatternType]:
        """
        Get all enabled pattern types.
        
        Returns:
            Set[PatternType]: Set of enabled pattern types
        """
        with self._operations_lock:
            return self._enabled_types.copy()
    
    def clear(self) -> None:
        """Clear all registered detectors and validators."""
        with self._operations_lock:
            self._detectors.clear()
            self._validators.clear()
            self._factories.clear()
            self._enabled_types.clear()
            self._configuration.clear()
            logger.info("Cleared all patterns from registry")
    
    def remove_detector(self, detector: PatternDetector) -> bool:
        """
        Remove a specific detector from the registry.
        
        Args:
            detector: The detector to remove
            
        Returns:
            bool: True if the detector was found and removed
        """
        with self._operations_lock:
            detectors = self._detectors.get(detector.pattern_type, [])
            if detector in detectors:
                detectors.remove(detector)
                logger.debug(f"Removed detector for {detector.pattern_type.value}")
                return True
            return False
    
    def update_configuration(self, config: Dict[str, Any]) -> None:
        """
        Update the registry configuration.
        
        Args:
            config: Configuration dictionary
        """
        with self._operations_lock:
            self._configuration.update(config)
            self._apply_configuration()
    
    def get_configuration(self) -> Dict[str, Any]:
        """
        Get the current configuration.
        
        Returns:
            Dict[str, Any]: Current configuration
        """
        with self._operations_lock:
            return self._configuration.copy()
    
    def _apply_configuration(self) -> None:
        """Apply configuration changes to registered detectors."""
        # Enable/disable pattern types based on configuration
        enabled_types = self._configuration.get('enabled_patterns', [])
        disabled_types = self._configuration.get('disabled_patterns', [])
        
        for pattern_type_str in enabled_types:
            try:
                pattern_type = PatternType(pattern_type_str)
                self.enable_pattern_type(pattern_type)
            except ValueError:
                logger.warning(f"Unknown pattern type in configuration: {pattern_type_str}")
        
        for pattern_type_str in disabled_types:
            try:
                pattern_type = PatternType(pattern_type_str)
                self.disable_pattern_type(pattern_type)
            except ValueError:
                logger.warning(f"Unknown pattern type in configuration: {pattern_type_str}")
    
    def get_stats(self) -> Dict[str, Any]:
        """
        Get registry statistics.
        
        Returns:
            Dict[str, Any]: Statistics about the registry
        """
        with self._operations_lock:
            stats = {
                'total_pattern_types': len(self._detectors),
                'enabled_pattern_types': len(self._enabled_types),
                'total_detectors': sum(len(detectors) for detectors in self._detectors.values()),
                'enabled_detectors': sum(
                    len([d for d in detectors if d.enabled]) 
                    for detectors in self._detectors.values()
                ),
                'registered_validators': len(self._validators),
                'registered_factories': len(self._factories),
                'pattern_type_counts': {
                    pt.value: len(detectors) 
                    for pt, detectors in self._detectors.items()
                },
                'enabled_pattern_types_list': [pt.value for pt in self._enabled_types]
            }
        
        return stats
    
    def __str__(self) -> str:
        """String representation of the registry."""
        stats = self.get_stats()
        return (
            f"PatternRegistry("
            f"types={stats['total_pattern_types']}, "
            f"detectors={stats['total_detectors']}, "
            f"enabled={stats['enabled_detectors']})"
        )
    
    def __repr__(self) -> str:
        """Detailed representation of the registry."""
        return self.__str__()


# Global registry instance
_global_registry = PatternRegistry()

def get_global_registry() -> PatternRegistry:
    """
    Get the global pattern registry instance.
    
    Returns:
        PatternRegistry: The global registry instance
    """
    return _global_registry


def reset_global_registry() -> None:
    """Reset the global pattern registry (useful for testing)."""
    global _global_registry
    _global_registry.clear()
    PatternRegistry._instance = None
    _global_registry = PatternRegistry()