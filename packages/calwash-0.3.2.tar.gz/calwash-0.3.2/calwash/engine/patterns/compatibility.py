"""
Backward compatibility layer for existing code.

This module provides compatibility functions that maintain the same API
as the existing pattern system while using the new modular architecture.
"""

import logging
from typing import List, Tuple, Optional

from .base import CleaningContext
from .services.pattern_detection_service import get_global_service
from .services.pattern_factory import PatternDetectorFactory

logger = logging.getLogger(__name__)

# Global flag to track if the service has been initialized
_service_initialized = False


def _ensure_service_initialized():
    """Ensure the global service is initialized with patterns."""
    global _service_initialized
    
    if not _service_initialized:
        try:
            # Try to populate with legacy patterns first
            PatternDetectorFactory.populate_registry_with_legacy_patterns()
        except Exception as e:
            logger.warning(f"Failed to load legacy patterns, using defaults: {e}")
            # Fall back to default patterns
            PatternDetectorFactory.populate_registry_with_defaults()
        
        _service_initialized = True


def clean_text_with_validation(text: str, context: str = "") -> str:
    """
    Clean text using validated patterns (backward compatibility function).
    
    This function maintains compatibility with the existing API while
    using the new pattern detection service under the hood.
    
    Args:
        text: Text to clean
        context: Additional context for validation
        
    Returns:
        Cleaned text with sensitive information removed
    """
    _ensure_service_initialized()
    
    try:
        service = get_global_service()
        
        # Convert context string to CleaningContext object
        cleaning_context = None
        if context:
            cleaning_context = CleaningContext(surrounding_text=context)
        
        return service.clean_text(text, cleaning_context)
        
    except Exception as e:
        logger.error(f"Error in clean_text_with_validation: {e}")
        # Fall back to original text on error
        return text


class SensitivePattern:
    """
    Backward compatibility wrapper for the original SensitivePattern class.
    
    This class provides the same interface as the original SensitivePattern
    but delegates to the new pattern detection system.
    """
    
    def __init__(self, pattern: str, replacement: str, validator=None,
                 description: str = "", case_sensitive: bool = False):
        """
        Initialize a SensitivePattern wrapper.
        
        Args:
            pattern: Regex pattern string
            replacement: Replacement text
            validator: Validation function (legacy format)
            description: Pattern description
            case_sensitive: Whether matching is case-sensitive
        """
        self.pattern = pattern
        self.replacement = replacement
        self.validator = validator
        self.description = description
        self.case_sensitive = case_sensitive
        
        # For compatibility, compile the regex
        import re
        flags = 0 if case_sensitive else re.IGNORECASE
        self.regex = re.compile(pattern, flags)
    
    def find_and_validate(self, text: str, context: str = "") -> List[Tuple[str, int, int]]:
        """
        Find matches and validate them (backward compatibility method).
        
        Args:
            text: Text to search
            context: Additional context
            
        Returns:
            List of (match_text, start_pos, end_pos) for valid matches
        """
        _ensure_service_initialized()
        
        try:
            service = get_global_service()
            
            # Convert context to CleaningContext
            cleaning_context = None
            if context:
                cleaning_context = CleaningContext(surrounding_text=context)
            
            # Detect patterns
            matches = service.detect_patterns(text, cleaning_context)
            
            # Filter matches for this specific pattern and return legacy format
            result = []
            for match in matches:
                # Check if this match corresponds to our pattern
                if self.regex.search(match.text) and match.is_validated:
                    result.append((match.text, match.start, match.end))
            
            return result
            
        except Exception as e:
            logger.error(f"Error in find_and_validate: {e}")
            return []
    
    def clean_text(self, text: str, context: str = "") -> str:
        """
        Clean text by replacing validated matches (backward compatibility method).
        
        Args:
            text: Text to clean
            context: Additional context
            
        Returns:
            Cleaned text
        """
        return clean_text_with_validation(text, context)


# Legacy pattern getter functions for backward compatibility
def get_all_sensitive_patterns() -> List[SensitivePattern]:
    """
    Get all sensitive data patterns (backward compatibility function).
    
    Returns:
        List[SensitivePattern]: List of pattern wrappers
    """
    _ensure_service_initialized()
    
    try:
        # Import the actual legacy patterns if available
        from sensitive_patterns import get_all_sensitive_patterns as legacy_get_patterns
        return legacy_get_patterns()
    except ImportError:
        logger.warning("Legacy patterns not available, returning empty list")
        return []


def get_email_patterns() -> List[SensitivePattern]:
    """Get email patterns (backward compatibility)."""
    return [
        SensitivePattern(
            pattern=r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
            replacement='[EMAIL REMOVED]',
            description='Email address'
        )
    ]


def get_phone_patterns() -> List[SensitivePattern]:
    """Get phone patterns (backward compatibility)."""
    # Return a subset of the most common phone patterns
    return [
        SensitivePattern(
            pattern=r'\b\d{3}[-.\s]\d{3}[-.\s]\d{4}\b',
            replacement='[PHONE REMOVED]',
            description='Standard US phone format'
        ),
        SensitivePattern(
            pattern=r'\(\d{3}\)\s?\d{3}[-.\s]?\d{4}\b',
            replacement='[PHONE REMOVED]',
            description='Phone with parentheses format'
        ),
    ]


def get_ssn_patterns() -> List[SensitivePattern]:
    """Get SSN patterns (backward compatibility)."""
    return [
        SensitivePattern(
            pattern=r'\b\d{3}-\d{2}-\d{4}\b',
            replacement='[SSN REMOVED]',
            description='SSN with dashes (XXX-XX-XXXX)'
        ),
        SensitivePattern(
            pattern=r'\b\d{3}\s\d{2}\s\d{4}\b',
            replacement='[SSN REMOVED]',
            description='SSN with spaces (XXX XX XXXX)'
        ),
    ]


def get_url_patterns() -> List[SensitivePattern]:
    """Get URL patterns (backward compatibility)."""
    return [
        SensitivePattern(
            pattern=r'https?://[^\s]+',
            replacement='[URL REMOVED]',
            description='HTTP/HTTPS URLs'
        ),
        SensitivePattern(
            pattern=r'www\.[^\s]+',
            replacement='[URL REMOVED]',
            description='www URLs'
        )
    ]


def get_medical_patterns() -> List[SensitivePattern]:
    """Get medical patterns (backward compatibility)."""
    return [
        SensitivePattern(
            pattern=r'\b(?:doctor|dr\.?|physician|md|appointment|medical|health|hospital|clinic|surgery|procedure|prescription|medication|therapy|treatment|diagnosis|patient|checkup|exam|consultation|visit)\b',
            replacement='Private',
            description='Medical and health terms'
        )
    ]


# Legacy cleaning pattern functions for compatibility with cleaning_patterns.py
def get_patterns_for_cleaning():
    """
    Get patterns for cleaning (backward compatibility function).
    
    Returns:
        List of compiled regex patterns with replacements
    """
    _ensure_service_initialized()
    
    patterns = []
    service = get_global_service()
    
    # Get all enabled detectors from the registry
    all_detectors = service.registry.get_all_enabled_detectors()
    
    for pattern_type, detectors in all_detectors.items():
        for detector in detectors:
            # For medical terms, use 'Private' as replacement
            replacement = 'Private' if detector.replacement == 'Private' else detector.replacement
            patterns.append((detector.compiled_regex, replacement))
    
    return patterns


def clean_text_validated(text: str, context: str = "") -> str:
    """
    Clean text using validated patterns (alias for compatibility).
    
    Args:
        text: Text to clean
        context: Additional context
        
    Returns:
        Cleaned text
    """
    return clean_text_with_validation(text, context)