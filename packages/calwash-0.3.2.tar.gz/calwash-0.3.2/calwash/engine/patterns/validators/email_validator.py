"""
Email address validator with comprehensive format checking.
"""

import re
from typing import Optional

from ..base import PatternValidator, CleaningContext


class EmailValidator(PatternValidator):
    """
    Email address validator with RFC-compliant format checking.
    
    Provides validation for email addresses with various levels of strictness
    and confidence scoring based on format quality.
    """
    
    def __init__(self, strict_mode: bool = False):
        """
        Initialize the email validator.
        
        Args:
            strict_mode: If True, applies stricter validation rules
        """
        self.strict_mode = strict_mode
        
        # Basic email pattern (less strict)
        self.basic_pattern = re.compile(
            r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
        )
        
        # More comprehensive email pattern (stricter)
        self.strict_pattern = re.compile(
            r'^[A-Za-z0-9]([A-Za-z0-9._%-]*[A-Za-z0-9])?@'
            r'[A-Za-z0-9]([A-Za-z0-9.-]*[A-Za-z0-9])?\.[A-Za-z]{2,}$'
        )
        
        # Common valid TLDs for additional validation
        self.common_tlds = {
            'com', 'org', 'net', 'edu', 'gov', 'mil', 'int',
            'co', 'uk', 'ca', 'au', 'de', 'fr', 'jp', 'br',
            'io', 'ai', 'me', 'biz', 'info', 'name', 'tv'
        }
        
        # Common email domains for higher confidence
        self.trusted_domains = {
            'gmail.com', 'yahoo.com', 'hotmail.com', 'outlook.com',
            'icloud.com', 'aol.com', 'protonmail.com', 'live.com',
            'msn.com', 'yandex.com', 'mail.com', 'zoho.com'
        }
    
    def validate(self, text: str, context: Optional[CleaningContext] = None) -> bool:
        """
        Validate email address format.
        
        Args:
            text: Email address string to validate
            context: Additional context (unused for email validation)
            
        Returns:
            bool: True if valid email format
        """
        text = text.strip()
        
        # Basic format check
        if not self.basic_pattern.match(text):
            return False
        
        # Apply strict validation if enabled
        if self.strict_mode and not self.strict_pattern.match(text):
            return False
        
        # Additional validation checks
        return self._additional_validation(text)
    
    def get_confidence(self, text: str, context: Optional[CleaningContext] = None) -> float:
        """
        Get confidence score for email validation.
        
        Args:
            text: The email text to validate
            context: Additional context
            
        Returns:
            float: Confidence score between 0.0 and 1.0
        """
        if not self.validate(text, context):
            return 0.0
        
        confidence = 0.7  # Base confidence for valid email
        
        # Extract domain for additional scoring
        try:
            _, domain = text.rsplit('@', 1)
            domain = domain.lower()
            
            # Higher confidence for trusted domains
            if domain in self.trusted_domains:
                confidence += 0.2
            
            # Check TLD validity
            if '.' in domain:
                tld = domain.split('.')[-1]
                if tld in self.common_tlds:
                    confidence += 0.1
            
            # Penalize suspicious patterns
            if self._has_suspicious_patterns(text):
                confidence -= 0.2
            
            # Bonus for well-formed structure
            if self.strict_pattern.match(text):
                confidence += 0.1
            
        except ValueError:
            # Shouldn't happen if basic validation passed, but just in case
            confidence = 0.5
        
        return min(1.0, max(0.0, confidence))
    
    def _additional_validation(self, email: str) -> bool:
        """
        Perform additional validation checks.
        
        Args:
            email: Email address to validate
            
        Returns:
            bool: True if passes additional validation
        """
        # Check length constraints
        if len(email) > 254:  # RFC 5321 limit
            return False
        
        # Split local and domain parts
        try:
            local, domain = email.rsplit('@', 1)
        except ValueError:
            return False
        
        # Check local part constraints
        if len(local) > 64:  # RFC 5321 limit
            return False
        
        if not local or not domain:
            return False
        
        # Domain must have at least one dot
        if '.' not in domain:
            return False
        
        # Check for consecutive dots
        if '..' in email:
            return False
        
        # Check for leading/trailing dots
        if local.startswith('.') or local.endswith('.'):
            return False
        
        if domain.startswith('.') or domain.endswith('.'):
            return False
        
        # Check for valid characters in domain
        if not re.match(r'^[A-Za-z0-9.-]+$', domain):
            return False
        
        return True
    
    def _has_suspicious_patterns(self, email: str) -> bool:
        """
        Check for suspicious patterns that might indicate false positives.
        
        Args:
            email: Email address to check
            
        Returns:
            bool: True if suspicious patterns are found
        """
        suspicious_patterns = [
            # Too many consecutive numbers
            r'\d{5,}',
            # Suspicious character combinations
            r'[._-]{3,}',
            # Very long local part with mostly numbers
            r'^[^@]*\d{10,}[^@]*@',
            # Suspicious TLDs (very short or very long)
            r'\.[a-z]{1}$|\.a[a-z]{10,}$'
        ]
        
        return any(re.search(pattern, email, re.IGNORECASE) for pattern in suspicious_patterns)
    
    def get_email_info(self, text: str) -> dict:
        """
        Get detailed information about the email address.
        
        Args:
            text: Email address string
            
        Returns:
            dict: Email information including domain, validation details, etc.
        """
        info = {
            'original_text': text.strip(),
            'is_valid': False,
            'confidence': 0.0,
            'local_part': None,
            'domain': None,
            'tld': None,
            'is_trusted_domain': False,
            'has_suspicious_patterns': False,
            'passes_strict_validation': False
        }
        
        email = text.strip()
        info['is_valid'] = self.validate(email)
        info['confidence'] = self.get_confidence(email)
        info['has_suspicious_patterns'] = self._has_suspicious_patterns(email)
        info['passes_strict_validation'] = bool(self.strict_pattern.match(email))
        
        try:
            local, domain = email.rsplit('@', 1)
            info['local_part'] = local
            info['domain'] = domain.lower()
            info['is_trusted_domain'] = info['domain'] in self.trusted_domains
            
            if '.' in domain:
                info['tld'] = domain.split('.')[-1].lower()
        except ValueError:
            pass
        
        return info