"""
Credit card validator using Luhn algorithm and format validation.
"""

import re
from typing import Optional

from ..base import PatternValidator, CleaningContext
from .base_validators import LuhnValidator


class CreditCardValidator(PatternValidator):
    """
    Comprehensive credit card validator.
    
    Validates credit card numbers using:
    1. Format validation for major card types
    2. Luhn algorithm checksum
    3. Length validation
    """
    
    def __init__(self):
        """Initialize the credit card validator."""
        self.luhn_validator = LuhnValidator()
        
        # Major card type patterns with their specific rules
        self.card_patterns = [
            (r'^4[0-9]{12,18}$', 'Visa', (13, 16, 19)),           # Visa: 4xxx, 13-19 digits
            (r'^5[1-5][0-9]{14}$', 'MasterCard', (16,)),          # MasterCard: 51-55, 16 digits
            (r'^3[47][0-9]{13}$', 'Amex', (15,)),                # Amex: 34/37, 15 digits
            (r'^6(?:011|5[0-9]{2})[0-9]{12}$', 'Discover', (16,)), # Discover: 6011 or 65xx, 16 digits
            (r'^(?:2131|1800|35\d{3})\d{11}$', 'JCB', (15, 16)), # JCB
            (r'^3[0-9]{13}$', 'Diners', (14,)),                  # Diners Club
        ]
        
        # Compile patterns for performance
        self.compiled_patterns = []
        for pattern, name, lengths in self.card_patterns:
            try:
                self.compiled_patterns.append((re.compile(pattern), name, lengths))
            except re.error:
                continue
    
    def validate(self, text: str, context: Optional[CleaningContext] = None) -> bool:
        """
        Validate credit card number format and checksum.
        
        Args:
            text: Credit card number string
            context: Additional context (unused for credit card validation)
            
        Returns:
            bool: True if valid credit card format and passes Luhn
        """
        # Remove spaces and dashes
        clean_number = re.sub(r'[\s-]', '', text)
        
        # Must be all digits
        if not clean_number.isdigit():
            return False
        
        # Check common card lengths
        if len(clean_number) < 13 or len(clean_number) > 19:
            return False
        
        # Check if it matches a known card format
        matches_format = self._matches_card_format(clean_number)
        if not matches_format:
            return False
        
        # Apply Luhn algorithm
        return self.luhn_validator.validate(clean_number, context)
    
    def get_confidence(self, text: str, context: Optional[CleaningContext] = None) -> float:
        """
        Get confidence score for credit card validation.
        
        Args:
            text: The text to validate
            context: Additional context
            
        Returns:
            float: Confidence score between 0.0 and 1.0
        """
        if not self.validate(text, context):
            return 0.0
        
        clean_number = re.sub(r'[\s-]', '', text)
        
        # Higher confidence for well-known formats
        card_type = self._get_card_type(clean_number)
        if card_type:
            # Different confidence levels based on card type recognition
            confidence_map = {
                'Visa': 0.95,
                'MasterCard': 0.95,
                'Amex': 0.95,
                'Discover': 0.90,
                'JCB': 0.85,
                'Diners': 0.85,
            }
            return confidence_map.get(card_type, 0.80)
        
        return 0.70  # Generic confidence for valid but unrecognized format
    
    def _matches_card_format(self, clean_number: str) -> bool:
        """
        Check if the number matches any known card format.
        
        Args:
            clean_number: Clean credit card number (digits only)
            
        Returns:
            bool: True if matches a known format
        """
        return any(pattern.match(clean_number) for pattern, _, _ in self.compiled_patterns)
    
    def _get_card_type(self, clean_number: str) -> Optional[str]:
        """
        Get the card type for a valid card number.
        
        Args:
            clean_number: Clean credit card number (digits only)
            
        Returns:
            Optional[str]: Card type name if recognized, None otherwise
        """
        for pattern, name, _ in self.compiled_patterns:
            if pattern.match(clean_number):
                return name
        return None
    
    def get_card_info(self, text: str) -> dict:
        """
        Get detailed information about the credit card.
        
        Args:
            text: Credit card number string
            
        Returns:
            dict: Card information including type, valid status, etc.
        """
        clean_number = re.sub(r'[\s-]', '', text)
        
        info = {
            'original_text': text,
            'clean_number': clean_number,
            'is_valid': False,
            'card_type': None,
            'confidence': 0.0,
            'length': len(clean_number),
            'passes_luhn': False,
            'matches_format': False
        }
        
        if clean_number.isdigit():
            info['passes_luhn'] = self.luhn_validator.validate(clean_number)
            info['matches_format'] = self._matches_card_format(clean_number)
            info['card_type'] = self._get_card_type(clean_number)
            info['is_valid'] = self.validate(text)
            info['confidence'] = self.get_confidence(text)
        
        return info