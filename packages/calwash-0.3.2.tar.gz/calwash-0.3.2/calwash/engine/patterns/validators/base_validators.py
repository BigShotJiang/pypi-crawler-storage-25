"""
Base validators extracted from pattern_validators.py.

This module provides fundamental validation classes for various types of
sensitive information patterns.
"""

import re
import logging
from typing import Optional, List
from datetime import datetime

from ..base import PatternValidator, CleaningContext

logger = logging.getLogger(__name__)


class LuhnValidator(PatternValidator):
    """
    Validator for credit card numbers using the Luhn algorithm.
    
    The Luhn algorithm is a simple checksum formula used to validate various
    identification numbers including credit card numbers.
    """
    
    def validate(self, text: str, context: Optional[CleaningContext] = None) -> bool:
        """
        Validate credit card number using Luhn algorithm.
        
        Args:
            text: The text to validate (should be a credit card number)
            context: Additional context (unused for Luhn validation)
            
        Returns:
            bool: True if the number passes Luhn validation
        """
        return self._luhn_checksum(text)
    
    def get_confidence(self, text: str, context: Optional[CleaningContext] = None) -> float:
        """
        Get confidence score for Luhn validation.
        
        Args:
            text: The text to validate
            context: Additional context
            
        Returns:
            float: 1.0 if valid, 0.0 if invalid
        """
        return 1.0 if self.validate(text, context) else 0.0
    
    def _luhn_checksum(self, card_number: str) -> bool:
        """
        Validate a credit card number using the Luhn algorithm.
        
        Args:
            card_number: String of digits representing a credit card number
            
        Returns:
            bool: True if the card number passes Luhn validation
        """
        # Remove any non-digit characters
        digits = [int(d) for d in card_number if d.isdigit()]
        
        if len(digits) < 13 or len(digits) > 19:
            return False
        
        # Reject obvious invalid patterns
        if all(d == 0 for d in digits):  # All zeros
            return False
        if all(d == digits[0] for d in digits):  # All same digit
            return False
        
        # Apply Luhn algorithm
        checksum = 0
        reverse_digits = digits[::-1]
        
        for i, digit in enumerate(reverse_digits):
            if i % 2 == 1:  # Every second digit from right
                digit *= 2
                if digit > 9:
                    digit = digit // 10 + digit % 10
            checksum += digit
        
        return checksum % 10 == 0


class SSNValidator(PatternValidator):
    """
    Validator for Social Security Numbers following SSA rules.
    
    Validates SSN format and applies basic SSA rules to reduce false positives.
    """
    
    def validate(self, text: str, context: Optional[CleaningContext] = None) -> bool:
        """
        Validate Social Security Number format and basic rules.
        
        Args:
            text: SSN string in various formats
            context: Additional context (unused for SSN validation)
            
        Returns:
            bool: True if valid SSN format
        """
        # Extract digits only
        digits = re.sub(r'\D', '', text)
        
        if len(digits) != 9:
            return False
        
        # SSA rules (simplified):
        # - First 3 digits (area number): 001-899 (but not 666), 900-999 are invalid
        # - Middle 2 digits (group number): 01-99
        # - Last 4 digits (serial number): 0001-9999
        
        try:
            area = int(digits[:3])
            group = int(digits[3:5])
            serial = int(digits[5:9])
        except ValueError:
            return False
        
        # Invalid area numbers
        if area == 0 or area == 666 or area >= 900:
            return False
        
        # Invalid group number
        if group == 0:
            return False
        
        # Invalid serial number
        if serial == 0:
            return False
        
        return True
    
    def get_confidence(self, text: str, context: Optional[CleaningContext] = None) -> float:
        """
        Get confidence score for SSN validation.
        
        Args:
            text: The text to validate
            context: Additional context
            
        Returns:
            float: 1.0 if valid, 0.0 if invalid
        """
        return 1.0 if self.validate(text, context) else 0.0


class PhoneValidator(PatternValidator):
    """
    Validator for phone numbers with context awareness.
    
    Validates phone number format while avoiding false positives from
    timestamps, IDs, and other numeric sequences.
    """
    
    def validate(self, text: str, context: Optional[CleaningContext] = None) -> bool:
        """
        Check if number is likely a phone number (not timestamp/ID).
        
        Args:
            text: The text to validate
            context: Additional context for validation
            
        Returns:
            bool: True if likely a phone number
        """
        clean = re.sub(r'[\s\-\(\)\+\.]', '', text)
        
        # Too long for phone number
        if len(clean) > 15:
            return False
        
        # Check for timestamp patterns
        timestamp_validator = TimestampValidator()
        if timestamp_validator.validate(clean, context):
            return False
        
        # Check whitelist patterns
        whitelist_validator = WhitelistValidator()
        if whitelist_validator.validate(text, context):
            return False
        
        # US phone number should be 10-11 digits
        if len(clean) == 10 or (len(clean) == 11 and clean.startswith('1')):
            return True
        
        # International format validation
        return len(clean) >= 7  # Minimum for local numbers
    
    def get_confidence(self, text: str, context: Optional[CleaningContext] = None) -> float:
        """
        Get confidence score for phone validation.
        
        Args:
            text: The text to validate
            context: Additional context
            
        Returns:
            float: Confidence score between 0.0 and 1.0
        """
        if not self.validate(text, context):
            return 0.0
        
        clean = re.sub(r'[\s\-\(\)\+\.]', '', text)
        
        # Higher confidence for standard formats
        if len(clean) == 10:  # US format
            return 0.9
        elif len(clean) == 11 and clean.startswith('1'):  # US with country code
            return 0.9
        elif 7 <= len(clean) <= 15:  # International format
            return 0.7
        else:
            return 0.5


class TimestampValidator(PatternValidator):
    """
    Validator for timestamp patterns to avoid false positives.
    
    Identifies numeric sequences that are likely timestamps or date formats.
    """
    
    def validate(self, text: str, context: Optional[CleaningContext] = None) -> bool:
        """
        Check if a numeric string is likely a timestamp.
        
        Args:
            text: Numeric string to check
            context: Additional context (unused for timestamp validation)
            
        Returns:
            bool: True if likely a timestamp
        """
        if not text.isdigit():
            return False
        
        # Common timestamp patterns
        length = len(text)
        
        # Unix timestamp (10 digits) - 1970 to ~2038
        if length == 10:
            try:
                timestamp = int(text)
                # Reasonable range for Unix timestamps
                return 946684800 <= timestamp <= 2147483647  # 2000-01-01 to 2038-01-19
            except ValueError:
                return False
        
        # Millisecond timestamp (13 digits)
        if length == 13:
            try:
                timestamp = int(text)
                # Reasonable range for millisecond timestamps
                return 946684800000 <= timestamp <= 2147483647000
            except ValueError:
                return False
        
        # Date format YYYYMMDD (8 digits)
        if length == 8:
            try:
                year = int(text[:4])
                month = int(text[4:6])
                day = int(text[6:8])
                return 1900 <= year <= 2100 and 1 <= month <= 12 and 1 <= day <= 31
            except ValueError:
                return False
        
        # Date + time format YYYYMMDDHHMMSS (14 digits)
        if length == 14:
            try:
                year = int(text[:4])
                month = int(text[4:6])
                day = int(text[6:8])
                hour = int(text[8:10])
                minute = int(text[10:12])
                second = int(text[12:14])
                return (1900 <= year <= 2100 and 1 <= month <= 12 and 1 <= day <= 31 and
                       0 <= hour <= 23 and 0 <= minute <= 59 and 0 <= second <= 59)
            except ValueError:
                return False
        
        return False
    
    def get_confidence(self, text: str, context: Optional[CleaningContext] = None) -> float:
        """
        Get confidence score for timestamp validation.
        
        Args:
            text: The text to validate
            context: Additional context
            
        Returns:
            float: 1.0 if valid timestamp, 0.0 if not
        """
        return 1.0 if self.validate(text, context) else 0.0


class WhitelistValidator(PatternValidator):
    """
    Validator for whitelisted patterns that should not be cleaned.
    
    Maintains a list of patterns that represent legitimate numeric sequences
    that should be preserved (years, times, measurements, etc.).
    """
    
    def __init__(self):
        """Initialize the whitelist validator with common patterns."""
        self.whitelist_patterns = [
            r'\b(?:19|20)\d{2}\b',              # Years 1900-2099
            r'\b\d{1,4}\s*(?:am|pm|AM|PM)\b',   # Time with AM/PM
            r'\b\d{1,2}:\d{2}(?::\d{2})?\b',    # Time format
            r'\b\d{1,2}/\d{1,2}/\d{2,4}\b',     # Date formats
            r'\b\d{1,2}-\d{1,2}-\d{2,4}\b',     # Date formats
            r'\bv?\d{1,3}\.\d{1,3}\.\d{1,3}\b', # Version numbers
            r'\broom\s+\d+\b',                  # Room numbers
            r'\bfloor\s+\d+\b',                 # Floor numbers
            r'\bsuite\s+\d+\b',                 # Suite numbers
            r'\bapt\s+\d+\b',                   # Apartment numbers
            r'\bunit\s+\d+\b',                  # Unit numbers
            r'\b\d+(?:\.\d+)?\s*(?:mb|gb|tb|kb|bytes?)\b',  # File sizes
            r'\b\d+(?:\.\d+)?\s*(?:mm|cm|m|km|in|ft|yd|mi|px|dpi)\b',  # Measurements
            r'\$\d+(?:\.\d{2})?\b',             # Currency
            r'\b\d+%\b',                        # Percentages
        ]
        
        # Compile patterns for performance
        self.compiled_patterns = []
        for pattern in self.whitelist_patterns:
            try:
                self.compiled_patterns.append(re.compile(pattern, re.IGNORECASE))
            except re.error as e:
                logger.warning(f"Invalid whitelist pattern '{pattern}': {e}")
    
    def validate(self, text: str, context: Optional[CleaningContext] = None) -> bool:
        """
        Check if a numeric sequence should be whitelisted (not cleaned).
        
        Args:
            text: The numeric text to check
            context: Additional context for better decision making
            
        Returns:
            bool: True if the text should be preserved
        """
        # Build full text for context checking
        full_text = text
        if context and context.surrounding_text:
            full_text = f"{context.surrounding_text} {text}"
        
        # Check whitelist patterns
        for pattern in self.compiled_patterns:
            if pattern.search(full_text):
                return True
        
        # Additional checks
        if self._is_product_code_pattern(text):
            return True
        
        if self._is_measurement_pattern(full_text):
            return True
        
        if self._is_version_number(text):
            return True
        
        return False
    
    def get_confidence(self, text: str, context: Optional[CleaningContext] = None) -> float:
        """
        Get confidence score for whitelist validation.
        
        Args:
            text: The text to validate
            context: Additional context
            
        Returns:
            float: 1.0 if whitelisted, 0.0 if not
        """
        return 1.0 if self.validate(text, context) else 0.0
    
    def _is_product_code_pattern(self, text: str) -> bool:
        """Check if text matches common product code patterns."""
        product_patterns = [
            r'^[A-Z]{2,4}\d{6,12}$',     # ABC123456789
            r'^[A-Z]\d{8,12}$',          # A12345678
            r'^\d{12,13}$',              # UPC/EAN codes
            r'^[A-Z]{3}-\d{6}-[A-Z]{2}$', # ABC-123456-XY
        ]
        
        return any(re.match(pattern, text.upper()) for pattern in product_patterns)
    
    def _is_measurement_pattern(self, text: str) -> bool:
        """Check if text is likely a measurement or technical specification."""
        measurement_patterns = [
            r'\d+(?:\.\d+)?\s*(?:mm|cm|m|km|in|ft|yd|mi)',  # Length
            r'\d+(?:\.\d+)?\s*(?:g|kg|lb|oz|ton)',          # Weight
            r'\d+(?:\.\d+)?\s*(?:ml|l|gal|qt|pt|cup)',      # Volume
            r'\d+(?:\.\d+)?\s*(?:°[CF]|K)',                 # Temperature
            r'\d+(?:\.\d+)?\s*(?:hz|khz|mhz|ghz)',          # Frequency
            r'\d+(?:\.\d+)?\s*(?:v|mv|kv)',                 # Voltage
            r'\d+(?:\.\d+)?\s*(?:w|kw|mw)',                 # Power
            r'\d+(?:\.\d+)?\s*(?:px|dpi|ppi)',              # Resolution
        ]
        
        return any(re.search(pattern, text.lower()) for pattern in measurement_patterns)
    
    def _is_version_number(self, text: str) -> bool:
        """Check if text is likely a version number."""
        version_patterns = [
            r'^\d+\.\d+(?:\.\d+)*$',     # 1.2.3, 10.15.7
            r'^v?\d+\.\d+(?:\.\d+)*$',   # v1.2.3
            r'^\d+\.\d+\.\d+\.\d+$',     # 1.2.3.4
        ]
        
        return any(re.match(pattern, text.lower()) for pattern in version_patterns)