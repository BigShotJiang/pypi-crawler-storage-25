"""
Bank account and routing number validator.
"""

import re
from typing import Optional, Set

from ..base import PatternValidator, CleaningContext
from .base_validators import TimestampValidator, WhitelistValidator


class BankAccountValidator(PatternValidator):
    """
    Validator for bank account numbers and routing numbers.
    
    Provides context-aware validation to distinguish bank account numbers
    from other numeric sequences like timestamps, IDs, etc.
    """
    
    def __init__(self):
        """Initialize the bank account validator."""
        self.timestamp_validator = TimestampValidator()
        self.whitelist_validator = WhitelistValidator()
        
        # Keywords that suggest banking context
        self.banking_keywords = {
            'account', 'routing', 'bank', 'deposit', 'checking', 'savings',
            'aba', 'wire', 'transfer', 'ach', 'swift', 'routing number',
            'account number', 'bank account', 'direct deposit'
        }
    
    def validate(self, text: str, context: Optional[CleaningContext] = None) -> bool:
        """
        Validate bank account or routing number.
        
        Args:
            text: Numeric string to validate
            context: Additional context for validation
            
        Returns:
            bool: True if likely a bank account or routing number
        """
        # Must be all digits
        if not text.isdigit():
            return False
        
        # Check if it should be whitelisted (not a bank account)
        if self.whitelist_validator.validate(text, context):
            return False
        
        # Check if it's a timestamp pattern
        if self.timestamp_validator.validate(text, context):
            return False
        
        # Length-based validation
        length = len(text)
        
        # Routing numbers are exactly 9 digits
        if length == 9:
            return self._validate_routing_number(text, context)
        
        # Account numbers are typically 8-12 digits
        elif 8 <= length <= 12:
            return self._validate_account_number(text, context)
        
        return False
    
    def get_confidence(self, text: str, context: Optional[CleaningContext] = None) -> float:
        """
        Get confidence score for bank account validation.
        
        Args:
            text: The text to validate
            context: Additional context
            
        Returns:
            float: Confidence score between 0.0 and 1.0
        """
        if not self.validate(text, context):
            return 0.0
        
        confidence = 0.5  # Base confidence
        
        # Check for banking context
        if self._has_banking_context(text, context):
            confidence += 0.3
        
        # Length-specific confidence
        length = len(text)
        if length == 9:  # Routing number length
            confidence += 0.2
        elif 8 <= length <= 12:  # Account number length
            confidence += 0.1
        
        return min(1.0, confidence)
    
    def _validate_routing_number(self, text: str, context: Optional[CleaningContext] = None) -> bool:
        """
        Validate a 9-digit routing number.
        
        Args:
            text: 9-digit string to validate
            context: Additional context
            
        Returns:
            bool: True if likely a routing number
        """
        if len(text) != 9:
            return False
        
        # Basic checksum validation for routing numbers
        # Routing number checksum algorithm
        try:
            digits = [int(d) for d in text]
            checksum = (
                3 * (digits[0] + digits[3] + digits[6]) +
                7 * (digits[1] + digits[4] + digits[7]) +
                1 * (digits[2] + digits[5] + digits[8])
            ) % 10
            
            # Valid if checksum is 0 OR if there's strong banking context
            return checksum == 0 or self._has_banking_context(text, context)
            
        except (ValueError, IndexError):
            return False
    
    def _validate_account_number(self, text: str, context: Optional[CleaningContext] = None) -> bool:
        """
        Validate an account number.
        
        Args:
            text: Account number string to validate
            context: Additional context
            
        Returns:
            bool: True if likely an account number
        """
        length = len(text)
        
        # Must be in reasonable range
        if not (8 <= length <= 12):
            return False
        
        # Should not be all zeros or all same digit
        if all(d == '0' for d in text) or all(d == text[0] for d in text):
            return False
        
        # Prefer numbers with banking context
        if self._has_banking_context(text, context):
            return True
        
        # Without explicit banking context, be more conservative
        # Only accept if it's in the most common range (9-11 digits)
        return 9 <= length <= 11
    
    def _has_banking_context(self, text: str, context: Optional[CleaningContext] = None) -> bool:
        """
        Check if context suggests this is a bank account/routing number.
        
        Args:
            text: The numeric text
            context: Additional context for validation
            
        Returns:
            bool: True if banking context is detected
        """
        if not context:
            return False
        
        # Build combined text for keyword search
        search_text = ""
        if context.surrounding_text:
            search_text += context.surrounding_text
        
        if context.field_name:
            search_text += f" {context.field_name}"
        
        if context.event_data:
            # Check common event fields for banking keywords
            for field in ['summary', 'description', 'location']:
                if field in context.event_data:
                    search_text += f" {context.event_data[field]}"
        
        search_text = search_text.lower()
        
        # Check for banking keywords
        return any(keyword in search_text for keyword in self.banking_keywords)
    
    def get_account_info(self, text: str, context: Optional[CleaningContext] = None) -> dict:
        """
        Get detailed information about the bank account number.
        
        Args:
            text: Account number string
            context: Additional context
            
        Returns:
            dict: Account information including type, validation details, etc.
        """
        info = {
            'original_text': text,
            'is_valid': False,
            'confidence': 0.0,
            'length': len(text),
            'account_type': None,
            'has_banking_context': False,
            'passes_checksum': False,
            'is_timestamp': False,
            'is_whitelisted': False
        }
        
        if text.isdigit():
            info['is_valid'] = self.validate(text, context)
            info['confidence'] = self.get_confidence(text, context)
            info['has_banking_context'] = self._has_banking_context(text, context)
            info['is_timestamp'] = self.timestamp_validator.validate(text, context)
            info['is_whitelisted'] = self.whitelist_validator.validate(text, context)
            
            # Determine account type
            length = len(text)
            if length == 9:
                info['account_type'] = 'routing_number'
                info['passes_checksum'] = self._validate_routing_number(text, context)
            elif 8 <= length <= 12:
                info['account_type'] = 'account_number'
        
        return info