"""
Email pattern detector.

Detects email addresses in text using regex patterns and validation.
"""

from typing import List, Optional

from ..base import PatternType
from ..validators.email_validator import EmailValidator
from .base_detector import BasePatternDetector


class EmailDetector(BasePatternDetector):
    """
    Detector for email addresses.
    
    Uses a comprehensive email pattern with RFC-compliant validation
    to detect and validate email addresses in text.
    """
    
    def __init__(
        self,
        replacement: str = '[EMAIL REMOVED]',
        description: str = 'Email address detector',
        enabled: bool = True,
        priority: int = 10,
        strict_mode: bool = False
    ):
        """
        Initialize the email detector.
        
        Args:
            replacement: Replacement text for detected emails
            description: Human-readable description
            enabled: Whether the detector is enabled
            priority: Priority (lower = higher priority)
            strict_mode: Whether to use strict email validation
        """
        # Email pattern - comprehensive but not overly restrictive
        email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
        
        # Create validator
        validator = EmailValidator(strict_mode=strict_mode)
        
        super().__init__(
            pattern_type=PatternType.EMAIL,
            regex_pattern=email_pattern,
            replacement=replacement,
            validator=validator,
            description=description,
            case_sensitive=False,
            enabled=enabled,
            priority=priority
        )
        
        self.strict_mode = strict_mode
    
    @classmethod
    def create_default(cls) -> 'EmailDetector':
        """
        Create a default email detector with standard settings.
        
        Returns:
            EmailDetector: Default email detector instance
        """
        return cls()
    
    @classmethod
    def create_strict(cls) -> 'EmailDetector':
        """
        Create a strict email detector with enhanced validation.
        
        Returns:
            EmailDetector: Strict email detector instance
        """
        return cls(
            description='Strict email address detector',
            strict_mode=True,
            priority=5  # Higher priority for strict mode
        )