"""
Social Security Number pattern detector.

Detects SSNs in various formats with validation to reduce false positives.
"""

from typing import List

from ..base import PatternType
from ..validators.base_validators import SSNValidator, WhitelistValidator, TimestampValidator
from .base_detector import BasePatternDetector


class SSNValidator(SSNValidator):
    """Enhanced SSN validator with additional checks."""
    
    def __init__(self):
        """Initialize with additional validators."""
        super().__init__()
        self.whitelist_validator = WhitelistValidator()
        self.timestamp_validator = TimestampValidator()
    
    def validate(self, text: str, context=None) -> bool:
        """
        Enhanced SSN validation with whitelist and timestamp checks.
        
        Args:
            text: Text to validate
            context: Additional context
            
        Returns:
            bool: True if valid SSN
        """
        # Check whitelist first
        if self.whitelist_validator.validate(text, context):
            return False
        
        # Check if it's a timestamp pattern
        clean_text = text.replace('-', '').replace(' ', '')
        if self.timestamp_validator.validate(clean_text, context):
            return False
        
        # Apply standard SSN validation
        return super().validate(text, context)


class SSNDetector:
    """
    Multi-format SSN detector factory.
    
    Creates detectors for SSNs in various formats with appropriate validation.
    """
    
    @staticmethod
    def create_dashed_ssn_detector(
        replacement: str = '[SSN REMOVED]',
        enabled: bool = True,
        priority: int = 15
    ) -> BasePatternDetector:
        """
        Create detector for SSN with dashes (XXX-XX-XXXX).
        
        Args:
            replacement: Replacement text
            enabled: Whether detector is enabled
            priority: Detection priority
            
        Returns:
            BasePatternDetector: Dashed SSN detector
        """
        # More permissive validator for formatted SSNs
        def is_permissive_ssn(ssn_text: str) -> bool:
            """More permissive SSN validation for clear formats."""
            import re
            # For formatted SSNs (with dashes/spaces), be more permissive
            digits = re.sub(r'\D', '', ssn_text)
            if len(digits) != 9:
                return False
            # Don't allow all zeros or all same digit
            if all(d == '0' for d in digits) or all(d == digits[0] for d in digits):
                return False
            return True
        
        class PermissiveSSNValidator(SSNValidator):
            def validate(self, text: str, context=None) -> bool:
                return is_permissive_ssn(text) and not self.whitelist_validator.validate(text, context)
        
        return BasePatternDetector(
            pattern_type=PatternType.SSN,
            regex_pattern=r'\b\d{3}-\d{2}-\d{4}\b',
            replacement=replacement,
            validator=PermissiveSSNValidator(),
            description='SSN with dashes (XXX-XX-XXXX)',
            case_sensitive=False,
            enabled=enabled,
            priority=priority
        )
    
    @staticmethod
    def create_spaced_ssn_detector(
        replacement: str = '[SSN REMOVED]',
        enabled: bool = True,
        priority: int = 16
    ) -> BasePatternDetector:
        """
        Create detector for SSN with spaces (XXX XX XXXX).
        
        Args:
            replacement: Replacement text
            enabled: Whether detector is enabled
            priority: Detection priority
            
        Returns:
            BasePatternDetector: Spaced SSN detector
        """
        # More permissive validator for formatted SSNs
        def is_permissive_ssn(ssn_text: str) -> bool:
            """More permissive SSN validation for clear formats."""
            import re
            digits = re.sub(r'\D', '', ssn_text)
            if len(digits) != 9:
                return False
            if all(d == '0' for d in digits) or all(d == digits[0] for d in digits):
                return False
            return True
        
        class PermissiveSSNValidator(SSNValidator):
            def validate(self, text: str, context=None) -> bool:
                return is_permissive_ssn(text) and not self.whitelist_validator.validate(text, context)
        
        return BasePatternDetector(
            pattern_type=PatternType.SSN,
            regex_pattern=r'\b\d{3}\s\d{2}\s\d{4}\b',
            replacement=replacement,
            validator=PermissiveSSNValidator(),
            description='SSN with spaces (XXX XX XXXX)',
            case_sensitive=False,
            enabled=enabled,
            priority=priority
        )
    
    @staticmethod
    def create_unformatted_ssn_detector(
        replacement: str = '[SSN REMOVED]',
        enabled: bool = True,
        priority: int = 25  # Lower priority due to higher false positive risk
    ) -> BasePatternDetector:
        """
        Create detector for unformatted SSN (XXXXXXXXX).
        
        Args:
            replacement: Replacement text
            enabled: Whether detector is enabled
            priority: Detection priority
            
        Returns:
            BasePatternDetector: Unformatted SSN detector
        """
        return BasePatternDetector(
            pattern_type=PatternType.SSN,
            regex_pattern=r'\b\d{9}\b',
            replacement=replacement,
            validator=SSNValidator(),
            description='SSN without separators (XXXXXXXXX)',
            case_sensitive=False,
            enabled=enabled,
            priority=priority
        )
    
    @classmethod
    def create_all_ssn_detectors(cls, replacement: str = '[SSN REMOVED]') -> List[BasePatternDetector]:
        """
        Create all SSN detectors for comprehensive SSN detection.
        
        Args:
            replacement: Replacement text for all detectors
            
        Returns:
            List[BasePatternDetector]: List of all SSN detectors
        """
        return [
            cls.create_dashed_ssn_detector(replacement),
            cls.create_spaced_ssn_detector(replacement),
            cls.create_unformatted_ssn_detector(replacement),
        ]


# Convenience class for single-instance usage
class DefaultSSNDetector(BasePatternDetector):
    """
    Default SSN detector for the most common format (XXX-XX-XXXX).
    
    This is a convenience class for cases where only a single SSN
    detector is needed.
    """
    
    def __init__(
        self,
        replacement: str = '[SSN REMOVED]',
        description: str = 'Default SSN detector',
        enabled: bool = True,
        priority: int = 15
    ):
        """
        Initialize the default SSN detector.
        
        Args:
            replacement: Replacement text
            description: Human-readable description
            enabled: Whether detector is enabled
            priority: Detection priority
        """
        super().__init__(
            pattern_type=PatternType.SSN,
            regex_pattern=r'\b\d{3}-\d{2}-\d{4}\b',
            replacement=replacement,
            validator=SSNValidator(),
            description=description,
            case_sensitive=False,
            enabled=enabled,
            priority=priority
        )