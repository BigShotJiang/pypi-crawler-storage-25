"""
Base pattern detector implementation.

This module provides the concrete implementation of the PatternDetector
abstract base class, handling common functionality like validation and matching.
"""

from typing import List, Optional
import logging

from ..base import PatternDetector, PatternMatch, PatternType, CleaningContext

logger = logging.getLogger(__name__)


class BasePatternDetector(PatternDetector):
    """
    Concrete implementation of PatternDetector with common functionality.
    
    This class provides the standard implementation for pattern detection,
    including validation, confidence scoring, and match creation.
    """
    
    def detect(self, text: str, context: Optional[CleaningContext] = None) -> List[PatternMatch]:
        """
        Detect patterns in the given text.
        
        Args:
            text: The text to scan for patterns
            context: Additional context for detection and validation
            
        Returns:
            List[PatternMatch]: List of validated pattern matches
        """
        if not self.enabled:
            return []
        
        matches = []
        
        try:
            # Find all raw regex matches
            raw_matches = self.find_raw_matches(text)
            
            for match_text, start, end in raw_matches:
                # Create a pattern match
                pattern_match = PatternMatch(
                    text=match_text,
                    start=start,
                    end=end,
                    pattern_type=self.pattern_type,
                    confidence=0.0,
                    is_validated=False,
                    replacement=self.replacement,
                    context=context
                )
                
                # Apply validation if validator is provided
                if self.validator:
                    is_valid = self.validator.validate(match_text, context)
                    confidence = self.validator.get_confidence(match_text, context)
                    
                    pattern_match.is_validated = is_valid
                    pattern_match.confidence = confidence
                    
                    # Only include validated matches
                    if is_valid:
                        matches.append(pattern_match)
                else:
                    # No validator - include all matches with default confidence
                    pattern_match.is_validated = True
                    pattern_match.confidence = 0.8  # Default confidence
                    matches.append(pattern_match)
                    
        except Exception as e:
            logger.error(f"Error detecting patterns in text: {e}")
            # Return empty list on error to avoid breaking the cleaning process
            return []
        
        return matches
    
    def clean_text(self, text: str, context: Optional[CleaningContext] = None) -> str:
        """
        Clean text by replacing detected patterns with replacement text.
        
        Args:
            text: The text to clean
            context: Additional context for cleaning
            
        Returns:
            str: The cleaned text
        """
        if not self.enabled:
            return text
            
        try:
            matches = self.detect(text, context)
            if not matches:
                return text
            
            # Sort matches by position (reverse order to maintain positions)
            matches.sort(key=lambda x: x.start, reverse=True)
            
            result = text
            for match in matches:
                if match.is_validated:
                    result = result[:match.start] + match.replacement + result[match.end:]
            
            return result
            
        except Exception as e:
            logger.error(f"Error cleaning text: {e}")
            # Return original text on error
            return text
    
    def get_detection_stats(self, text: str, context: Optional[CleaningContext] = None) -> dict:
        """
        Get detailed statistics about pattern detection in text.
        
        Args:
            text: The text to analyze
            context: Additional context
            
        Returns:
            dict: Detection statistics
        """
        stats = {
            'pattern_type': self.pattern_type.value,
            'enabled': self.enabled,
            'total_matches': 0,
            'validated_matches': 0,
            'avg_confidence': 0.0,
            'matches': []
        }
        
        if not self.enabled:
            return stats
        
        try:
            matches = self.detect(text, context)
            stats['total_matches'] = len(matches)
            stats['validated_matches'] = sum(1 for m in matches if m.is_validated)
            
            if matches:
                confidences = [m.confidence for m in matches if m.is_validated]
                stats['avg_confidence'] = sum(confidences) / len(confidences) if confidences else 0.0
                stats['matches'] = [m.to_dict() for m in matches[:5]]  # Limit to first 5 for brevity
            
        except Exception as e:
            logger.error(f"Error getting detection stats: {e}")
            stats['error'] = str(e)
        
        return stats