"""
Phone number pattern detector with multiple format support.

Detects phone numbers in various formats while avoiding false positives
from timestamps and other numeric sequences.
"""

from typing import List

from ..base import PatternType
from ..validators.base_validators import PhoneValidator
from .base_detector import BasePatternDetector


class PhoneDetector(BasePatternDetector):
    """
    Multi-format phone number detector.
    
    Detects phone numbers in various formats including international,
    US domestic, and numbers with extensions.
    """
    
    @staticmethod
    def create_international_detector(
        replacement: str = '[PHONE REMOVED]',
        enabled: bool = True,
        priority: int = 20
    ) -> BasePatternDetector:
        """
        Create detector for international phone format.
        
        Args:
            replacement: Replacement text
            enabled: Whether detector is enabled
            priority: Detection priority
            
        Returns:
            BasePatternDetector: International phone detector
        """
        return BasePatternDetector(
            pattern_type=PatternType.PHONE,
            regex_pattern=r'\+\d{1,3}[\s.-]?\(?\d{1,4}\)?[\s.-]?\d{1,4}[\s.-]?\d{1,9}',
            replacement=replacement,
            validator=PhoneValidator(),
            description='International phone format (+1 555-123-4567)',
            case_sensitive=False,
            enabled=enabled,
            priority=priority
        )
    
    @staticmethod
    def create_us_with_country_code_detector(
        replacement: str = '[PHONE REMOVED]',
        enabled: bool = True,
        priority: int = 21
    ) -> BasePatternDetector:
        """
        Create detector for US phone with country code.
        
        Args:
            replacement: Replacement text
            enabled: Whether detector is enabled
            priority: Detection priority
            
        Returns:
            BasePatternDetector: US phone with country code detector
        """
        return BasePatternDetector(
            pattern_type=PatternType.PHONE,
            regex_pattern=r'\b1[-.\s]?\d{3}[-.\s]?\d{3}[-.\s]?\d{4}\b',
            replacement=replacement,
            validator=PhoneValidator(),
            description='US phone with country code (1-555-123-4567)',
            case_sensitive=False,
            enabled=enabled,
            priority=priority
        )
    
    @staticmethod
    def create_parentheses_detector(
        replacement: str = '[PHONE REMOVED]',
        enabled: bool = True,
        priority: int = 22
    ) -> BasePatternDetector:
        """
        Create detector for phone with parentheses.
        
        Args:
            replacement: Replacement text
            enabled: Whether detector is enabled
            priority: Detection priority
            
        Returns:
            BasePatternDetector: Phone with parentheses detector
        """
        return BasePatternDetector(
            pattern_type=PatternType.PHONE,
            regex_pattern=r'\(\d{3}\)\s?\d{3}[-.\s]?\d{4}\b',
            replacement=replacement,
            validator=PhoneValidator(),
            description='Phone with parentheses ((555) 123-4567)',
            case_sensitive=False,
            enabled=enabled,
            priority=priority
        )
    
    @staticmethod
    def create_standard_us_detector(
        replacement: str = '[PHONE REMOVED]',
        enabled: bool = True,
        priority: int = 23
    ) -> BasePatternDetector:
        """
        Create detector for standard US phone format.
        
        Args:
            replacement: Replacement text
            enabled: Whether detector is enabled
            priority: Detection priority
            
        Returns:
            BasePatternDetector: Standard US phone detector
        """
        # Custom validator to be more permissive for clear phone patterns
        validator = PhoneValidator()
        
        return BasePatternDetector(
            pattern_type=PatternType.PHONE,
            regex_pattern=r'\b\d{3}[-.\s]\d{3}[-.\s]\d{4}\b',
            replacement=replacement,
            validator=validator,
            description='Standard US phone format (555-123-4567)',
            case_sensitive=False,
            enabled=enabled,
            priority=priority
        )
    
    @staticmethod
    def create_extension_detector(
        replacement: str = '[PHONE REMOVED]',
        enabled: bool = True,
        priority: int = 19  # Higher priority than basic patterns
    ) -> BasePatternDetector:
        """
        Create detector for phone with extension.
        
        Args:
            replacement: Replacement text
            enabled: Whether detector is enabled
            priority: Detection priority
            
        Returns:
            BasePatternDetector: Phone with extension detector
        """
        return BasePatternDetector(
            pattern_type=PatternType.PHONE,
            regex_pattern=r'\b\d{3}[-.\s]?\d{3}[-.\s]?\d{4}\s*(?:ext\.?|x|extension)\s*\d+',
            replacement=replacement,
            validator=PhoneValidator(),
            description='Phone with extension (555-123-4567 ext 123)',
            case_sensitive=False,
            enabled=enabled,
            priority=priority
        )
    
    @staticmethod
    def create_ten_digit_detector(
        replacement: str = '[PHONE REMOVED]',
        enabled: bool = True,
        priority: int = 30  # Lower priority due to higher false positive risk
    ) -> BasePatternDetector:
        """
        Create detector for 10-digit phone without separators.
        
        Args:
            replacement: Replacement text
            enabled: Whether detector is enabled
            priority: Detection priority
            
        Returns:
            BasePatternDetector: 10-digit phone detector
        """
        return BasePatternDetector(
            pattern_type=PatternType.PHONE,
            regex_pattern=r'\b\d{10}\b',
            replacement=replacement,
            validator=PhoneValidator(),
            description='10-digit phone without separators (5551234567)',
            case_sensitive=False,
            enabled=enabled,
            priority=priority
        )
    
    @classmethod
    def create_all_phone_detectors(cls, replacement: str = '[PHONE REMOVED]') -> List[BasePatternDetector]:
        """
        Create all phone detectors for comprehensive phone number detection.
        
        Args:
            replacement: Replacement text for all detectors
            
        Returns:
            List[BasePatternDetector]: List of all phone detectors
        """
        return [
            cls.create_extension_detector(replacement),  # Highest priority
            cls.create_international_detector(replacement),
            cls.create_us_with_country_code_detector(replacement),
            cls.create_parentheses_detector(replacement),
            cls.create_standard_us_detector(replacement),
            cls.create_ten_digit_detector(replacement),  # Lowest priority
        ]


# Convenience class for single-instance usage
class DefaultPhoneDetector(BasePatternDetector):
    """
    Default phone detector using the most common US format.
    
    This is a convenience class for cases where only a single phone
    detector is needed rather than the full suite.
    """
    
    def __init__(
        self,
        replacement: str = '[PHONE REMOVED]',
        description: str = 'Default phone number detector',
        enabled: bool = True,
        priority: int = 25
    ):
        """
        Initialize the default phone detector.
        
        Args:
            replacement: Replacement text
            description: Human-readable description
            enabled: Whether detector is enabled
            priority: Detection priority
        """
        super().__init__(
            pattern_type=PatternType.PHONE,
            regex_pattern=r'\b\d{3}[-.\s]\d{3}[-.\s]\d{4}\b',
            replacement=replacement,
            validator=PhoneValidator(),
            description=description,
            case_sensitive=False,
            enabled=enabled,
            priority=priority
        )