"""
Base classes and interfaces for the pattern detection system.

This module defines the foundational abstractions for pattern detection,
validation, and cleaning operations throughout the calendar cleaning system.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from enum import Enum
from typing import List, Optional, Dict, Any, Callable, Union
import re


class PatternType(Enum):
    """Enumeration of different types of sensitive patterns."""
    EMAIL = "email"
    PHONE = "phone"
    SSN = "ssn"
    CREDIT_CARD = "credit_card"
    BANK_ACCOUNT = "bank_account"
    DRIVER_LICENSE = "driver_license"
    URL = "url"
    MEDICAL = "medical"
    ADDRESS = "address"
    FINANCIAL = "financial"
    PERSONAL_ID = "personal_id"


@dataclass
class CleaningContext:
    """
    Context information for pattern detection and cleaning operations.
    
    Provides additional context that can improve pattern validation
    and reduce false positives.
    """
    field_name: str = ""  # The field being cleaned (e.g., 'summary', 'description')
    surrounding_text: str = ""  # Text around the potential match
    event_data: Optional[Dict[str, Any]] = None  # Full event data if available
    metadata: Optional[Dict[str, Any]] = None  # Additional metadata


@dataclass
class PatternMatch:
    """
    Represents a detected pattern match with its context and validation status.
    
    This class encapsulates all information about a pattern match, including
    its location, confidence, and validation status.
    """
    text: str  # The matched text
    start: int  # Start position in the original text
    end: int  # End position in the original text
    pattern_type: PatternType  # Type of pattern matched
    confidence: float  # Confidence score (0.0 to 1.0)
    is_validated: bool  # Whether the match has been validated
    replacement: str  # The replacement text for this match
    context: Optional[CleaningContext] = None  # Context information
    metadata: Optional[Dict[str, Any]] = None  # Additional metadata
    
    @property
    def length(self) -> int:
        """Return the length of the matched text."""
        return self.end - self.start
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert the match to a dictionary for serialization."""
        return {
            'text': self.text,
            'start': self.start,
            'end': self.end,
            'pattern_type': self.pattern_type.value,
            'confidence': self.confidence,
            'is_validated': self.is_validated,
            'replacement': self.replacement,
            'metadata': self.metadata or {}
        }


class PatternValidator(ABC):
    """
    Abstract base class for pattern validators.
    
    Pattern validators provide additional validation logic beyond regex matching
    to reduce false positives and improve accuracy.
    """
    
    @abstractmethod
    def validate(self, text: str, context: Optional[CleaningContext] = None) -> bool:
        """
        Validate whether a matched text is actually the type of sensitive data expected.
        
        Args:
            text: The matched text to validate
            context: Additional context for validation
            
        Returns:
            bool: True if the text is valid for this pattern type
        """
        pass
    
    @abstractmethod
    def get_confidence(self, text: str, context: Optional[CleaningContext] = None) -> float:
        """
        Get confidence score for the validation.
        
        Args:
            text: The matched text
            context: Additional context
            
        Returns:
            float: Confidence score between 0.0 and 1.0
        """
        pass


class PatternDetector(ABC):
    """
    Abstract base class for pattern detectors.
    
    Pattern detectors are responsible for finding potential sensitive information
    in text using regex patterns and other detection methods.
    """
    
    def __init__(
        self,
        pattern_type: PatternType,
        regex_pattern: str,
        replacement: str,
        validator: Optional[PatternValidator] = None,
        description: str = "",
        case_sensitive: bool = False,
        enabled: bool = True,
        priority: int = 100
    ):
        """
        Initialize a pattern detector.
        
        Args:
            pattern_type: The type of pattern this detector handles
            regex_pattern: The regex pattern to use for detection
            replacement: The replacement text for matches
            validator: Optional validator for additional validation
            description: Human-readable description of the pattern
            case_sensitive: Whether the pattern matching is case-sensitive
            enabled: Whether this detector is enabled
            priority: Priority of this detector (lower = higher priority)
        """
        self.pattern_type = pattern_type
        self.regex_pattern = regex_pattern
        self.replacement = replacement
        self.validator = validator
        self.description = description
        self.case_sensitive = case_sensitive
        self.enabled = enabled
        self.priority = priority
        
        # Compile the regex pattern
        flags = 0 if case_sensitive else re.IGNORECASE
        try:
            self.compiled_regex = re.compile(regex_pattern, flags)
        except re.error as e:
            raise ValueError(f"Invalid regex pattern '{regex_pattern}': {e}")
    
    @abstractmethod
    def detect(self, text: str, context: Optional[CleaningContext] = None) -> List[PatternMatch]:
        """
        Detect patterns in the given text.
        
        Args:
            text: The text to scan for patterns
            context: Additional context for detection
            
        Returns:
            List[PatternMatch]: List of detected pattern matches
        """
        pass
    
    def find_raw_matches(self, text: str) -> List[tuple]:
        """
        Find raw regex matches without validation.
        
        Args:
            text: The text to scan
            
        Returns:
            List of (match_text, start_pos, end_pos) tuples
        """
        matches = []
        for match in self.compiled_regex.finditer(text):
            matches.append((match.group(), match.start(), match.end()))
        return matches
    
    def clean_text(self, text: str, context: Optional[CleaningContext] = None) -> str:
        """
        Clean text by replacing detected patterns with replacement text.
        
        Args:
            text: The text to clean
            context: Additional context for cleaning
            
        Returns:
            str: The cleaned text
        """
        if not self.enabled:
            return text
            
        matches = self.detect(text, context)
        if not matches:
            return text
        
        # Sort matches by position (reverse order to maintain positions)
        matches.sort(key=lambda x: x.start, reverse=True)
        
        result = text
        for match in matches:
            if match.is_validated:
                result = result[:match.start] + match.replacement + result[match.end:]
        
        return result
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert the detector to a dictionary for serialization."""
        return {
            'pattern_type': self.pattern_type.value,
            'regex_pattern': self.regex_pattern,
            'replacement': self.replacement,
            'description': self.description,
            'case_sensitive': self.case_sensitive,
            'enabled': self.enabled,
            'priority': self.priority
        }


class CompositePatternDetector:
    """
    A detector that combines multiple pattern detectors for a single pattern type.
    
    This allows for multiple regex patterns to be used for the same type of
    sensitive information (e.g., different phone number formats).
    """
    
    def __init__(self, pattern_type: PatternType, detectors: List[PatternDetector]):
        """
        Initialize a composite detector.
        
        Args:
            pattern_type: The pattern type for all contained detectors
            detectors: List of individual pattern detectors
        """
        self.pattern_type = pattern_type
        self.detectors = detectors
        
        # Validate that all detectors have the same pattern type
        for detector in detectors:
            if detector.pattern_type != pattern_type:
                raise ValueError(
                    f"All detectors must have pattern_type {pattern_type.value}, "
                    f"found {detector.pattern_type.value}"
                )
    
    def detect(self, text: str, context: Optional[CleaningContext] = None) -> List[PatternMatch]:
        """
        Detect patterns using all contained detectors.
        
        Args:
            text: The text to scan
            context: Additional context
            
        Returns:
            List[PatternMatch]: Combined matches from all detectors
        """
        all_matches = []
        for detector in self.detectors:
            if detector.enabled:
                matches = detector.detect(text, context)
                all_matches.extend(matches)
        
        # Sort by position and remove duplicates/overlaps
        return self._remove_overlapping_matches(all_matches)
    
    def clean_text(self, text: str, context: Optional[CleaningContext] = None) -> str:
        """
        Clean text using all enabled detectors.
        
        Args:
            text: The text to clean
            context: Additional context
            
        Returns:
            str: The cleaned text
        """
        matches = self.detect(text, context)
        if not matches:
            return text
        
        # Sort matches by position (reverse order to maintain positions)
        matches.sort(key=lambda x: x.start, reverse=True)
        
        result = text
        for match in matches:
            if match.is_validated:
                result = result[:match.start] + match.replacement + result[match.end:]
        
        return result
    
    def _remove_overlapping_matches(self, matches: List[PatternMatch]) -> List[PatternMatch]:
        """
        Remove overlapping matches, keeping the highest confidence match.
        
        Args:
            matches: List of pattern matches
            
        Returns:
            List[PatternMatch]: Non-overlapping matches
        """
        if not matches:
            return []
        
        # Sort by start position
        sorted_matches = sorted(matches, key=lambda x: x.start)
        
        result = []
        last_end = -1
        
        for match in sorted_matches:
            # Skip overlapping matches (keep the first one with higher confidence)
            if match.start < last_end:
                # Check if current match has higher confidence than the last added
                if result and match.confidence > result[-1].confidence:
                    result[-1] = match  # Replace with higher confidence match
                continue
            
            result.append(match)
            last_end = match.end
        
        return result


class PatternDetectorFactory(ABC):
    """
    Abstract factory for creating pattern detectors.
    
    This allows for dynamic creation of detectors based on configuration
    or runtime requirements.
    """
    
    @abstractmethod
    def create_detector(self, config: Dict[str, Any]) -> PatternDetector:
        """
        Create a pattern detector from configuration.
        
        Args:
            config: Configuration dictionary
            
        Returns:
            PatternDetector: The created detector
        """
        pass
    
    @abstractmethod
    def get_supported_types(self) -> List[PatternType]:
        """
        Get the list of pattern types this factory can create.
        
        Returns:
            List[PatternType]: Supported pattern types
        """
        pass