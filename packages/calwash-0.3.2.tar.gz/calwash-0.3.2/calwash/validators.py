"""
Validation functions for sensitive data patterns.
Provides validation logic to minimize false positives when detecting sensitive information.
"""

import re
from typing import List, Tuple, Optional


def luhn_checksum(card_number: str) -> bool:
    """
    Validate a credit card number using the Luhn algorithm.
    
    Args:
        card_number: String of digits representing a credit card number
        
    Returns:
        bool: True if the card number passes Luhn validation
    """
    # Remove any non-digit characters
    digits = [int(d) for d in card_number if d.isdigit()]
    
    if len(digits) < 13 or len(digits) > 19:
        return False
    
    # Reject obvious invalid patterns
    if all(d == 0 for d in digits):  # All zeros
        return False
    if all(d == digits[0] for d in digits):  # All same digit
        return False
    
    # Apply Luhn algorithm
    checksum = 0
    reverse_digits = digits[::-1]
    
    for i, digit in enumerate(reverse_digits):
        if i % 2 == 1:  # Every second digit from right
            digit *= 2
            if digit > 9:
                digit = digit // 10 + digit % 10
        checksum += digit
    
    return checksum % 10 == 0


def is_valid_credit_card(number: str) -> bool:
    """
    Validate credit card number format and checksum.
    
    Args:
        number: Credit card number string
        
    Returns:
        bool: True if valid credit card format and passes Luhn
    """
    # Remove spaces and dashes
    clean_number = re.sub(r'[\s-]', '', number)
    
    # Must be all digits
    if not clean_number.isdigit():
        return False
    
    # Check common card lengths and prefixes
    if len(clean_number) < 13 or len(clean_number) > 19:
        return False
    
    # Major card type patterns
    card_patterns = [
        (r'^4[0-9]{12,18}$', 'Visa'),           # Visa: 4xxx, 13-19 digits
        (r'^5[1-5][0-9]{14}$', 'MasterCard'),   # MasterCard: 51-55, 16 digits
        (r'^3[47][0-9]{13}$', 'Amex'),          # Amex: 34/37, 15 digits
        (r'^6(?:011|5[0-9]{2})[0-9]{12}$', 'Discover'),  # Discover: 6011 or 65xx, 16 digits
    ]
    
    # Check if it matches a known card format
    matches_format = any(re.match(pattern, clean_number) for pattern, _ in card_patterns)
    
    return matches_format and luhn_checksum(clean_number)


def is_valid_ssn(ssn: str) -> bool:
    """
    Validate Social Security Number format and basic rules.
    
    Args:
        ssn: SSN string in various formats
        
    Returns:
        bool: True if valid SSN format
    """
    # Extract digits only
    digits = re.sub(r'\D', '', ssn)
    
    if len(digits) != 9:
        return False
    
    # SSA rules (simplified):
    # - First 3 digits (area number): 001-899 (but not 666), 900-999 are invalid
    # - Middle 2 digits (group number): 01-99
    # - Last 4 digits (serial number): 0001-9999
    
    area = int(digits[:3])
    group = int(digits[3:5])
    serial = int(digits[5:9])
    
    # Invalid area numbers
    if area == 0 or area == 666 or area >= 900:
        return False
    
    # Invalid group number
    if group == 0:
        return False
    
    # Invalid serial number
    if serial == 0:
        return False
    
    return True


def is_timestamp_pattern(text: str) -> bool:
    """
    Check if a numeric string is likely a timestamp.
    
    Args:
        text: Numeric string to check
        
    Returns:
        bool: True if likely a timestamp
    """
    if not text.isdigit():
        return False
    
    # Common timestamp patterns
    length = len(text)
    
    # Unix timestamp (10 digits) - 1970 to ~2038
    if length == 10:
        try:
            timestamp = int(text)
            # Reasonable range for Unix timestamps
            return 946684800 <= timestamp <= 2147483647  # 2000-01-01 to 2038-01-19
        except ValueError:
            return False
    
    # Millisecond timestamp (13 digits)
    if length == 13:
        try:
            timestamp = int(text)
            # Reasonable range for millisecond timestamps
            return 946684800000 <= timestamp <= 2147483647000
        except ValueError:
            return False
    
    # Date format YYYYMMDD (8 digits)
    if length == 8:
        try:
            year = int(text[:4])
            month = int(text[4:6])
            day = int(text[6:8])
            return 1900 <= year <= 2100 and 1 <= month <= 12 and 1 <= day <= 31
        except ValueError:
            return False
    
    # Date + time format YYYYMMDDHHMMSS (14 digits)
    if length == 14:
        try:
            year = int(text[:4])
            month = int(text[4:6])
            day = int(text[6:8])
            hour = int(text[8:10])
            minute = int(text[10:12])
            second = int(text[12:14])
            return (1900 <= year <= 2100 and 1 <= month <= 12 and 1 <= day <= 31 and
                   0 <= hour <= 23 and 0 <= minute <= 59 and 0 <= second <= 59)
        except ValueError:
            return False
    
    return False


def is_product_code_pattern(text: str) -> bool:
    """
    Check if text matches common product code patterns.
    
    Args:
        text: Text to check
        
    Returns:
        bool: True if likely a product code
    """
    # Common product code patterns
    product_patterns = [
        r'^[A-Z]{2,4}\d{6,12}$',     # ABC123456789
        r'^[A-Z]\d{8,12}$',          # A12345678
        r'^\d{12,13}$',              # UPC/EAN codes
        r'^[A-Z]{3}-\d{6}-[A-Z]{2}$', # ABC-123456-XY
    ]
    
    return any(re.match(pattern, text.upper()) for pattern in product_patterns)


def is_measurement_pattern(text: str) -> bool:
    """
    Check if text is likely a measurement or technical specification.
    
    Args:
        text: Text to check
        
    Returns:
        bool: True if likely a measurement
    """
    # Look for measurement context indicators
    measurement_context = [
        r'\d+(?:\.\d+)?\s*(?:mm|cm|m|km|in|ft|yd|mi)',  # Length
        r'\d+(?:\.\d+)?\s*(?:g|kg|lb|oz|ton)',          # Weight
        r'\d+(?:\.\d+)?\s*(?:ml|l|gal|qt|pt|cup)',      # Volume
        r'\d+(?:\.\d+)?\s*(?:°[CF]|K)',                 # Temperature
        r'\d+(?:\.\d+)?\s*(?:hz|khz|mhz|ghz)',          # Frequency
        r'\d+(?:\.\d+)?\s*(?:v|mv|kv)',                 # Voltage
        r'\d+(?:\.\d+)?\s*(?:w|kw|mw)',                 # Power
        r'\d+(?:\.\d+)?\s*(?:px|dpi|ppi)',              # Resolution
    ]
    
    return any(re.search(pattern, text.lower()) for pattern in measurement_context)


def is_version_number(text: str) -> bool:
    """
    Check if text is likely a version number.
    
    Args:
        text: Text to check
        
    Returns:
        bool: True if likely a version number
    """
    version_patterns = [
        r'^\d+\.\d+(?:\.\d+)*$',     # 1.2.3, 10.15.7
        r'^v?\d+\.\d+(?:\.\d+)*$',   # v1.2.3
        r'^\d+\.\d+\.\d+\.\d+$',     # 1.2.3.4
    ]
    
    return any(re.match(pattern, text.lower()) for pattern in version_patterns)


def get_whitelist_patterns() -> List[str]:
    """
    Get list of regex patterns that should NOT be cleaned.
    These represent common legitimate numeric sequences.
    
    Returns:
        List of regex patterns to whitelist
    """
    return [
        r'\b(?:19|20)\d{2}\b',              # Years 1900-2099
        r'\b\d{1,4}\s*(?:am|pm|AM|PM)\b',   # Time with AM/PM
        r'\b\d{1,2}:\d{2}(?::\d{2})?\b',    # Time format
        r'\b\d{1,2}/\d{1,2}/\d{2,4}\b',     # Date formats
        r'\b\d{1,2}-\d{1,2}-\d{2,4}\b',     # Date formats
        r'\bv?\d{1,3}\.\d{1,3}\.\d{1,3}\b', # Version numbers (use dots, not dashes)
        r'\broom\s+\d+\b',                  # Room numbers
        r'\bfloor\s+\d+\b',                 # Floor numbers
        r'\bsuite\s+\d+\b',                 # Suite numbers
        r'\bapt\s+\d+\b',                   # Apartment numbers
        r'\bunit\s+\d+\b',                  # Unit numbers
        r'\b\d+(?:\.\d+)?\s*(?:mb|gb|tb|kb|bytes?)\b',  # File sizes
        r'\b\d+(?:\.\d+)?\s*(?:mm|cm|m|km|in|ft|yd|mi|px|dpi)\b',  # Measurements
        r'\$\d+(?:\.\d{2})?\b',             # Currency
        r'\b\d+%\b',                        # Percentages
    ]


def should_whitelist(text: str, context: str = "") -> bool:
    """
    Check if a numeric sequence should be whitelisted (not cleaned).
    
    Args:
        text: The numeric text to check
        context: Surrounding context for better decision making
        
    Returns:
        bool: True if the text should be preserved
    """
    full_text = f"{context} {text}".lower()
    
    # Check whitelist patterns
    for pattern in get_whitelist_patterns():
        if re.search(pattern, full_text, re.IGNORECASE):
            return True
    
    # Additional checks
    if is_timestamp_pattern(text):
        return True
    
    if is_product_code_pattern(text):
        return True
    
    if is_measurement_pattern(full_text):
        return True
    
    if is_version_number(text):
        return True
    
    return False