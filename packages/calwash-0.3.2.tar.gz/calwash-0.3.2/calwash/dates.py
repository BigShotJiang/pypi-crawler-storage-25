#!/usr/bin/env python3
"""
Date utilities for Google Calendar cleaning tool.
Provides date range parsing, filtering, and filename generation capabilities.
"""

import re
import json
from datetime import datetime, timedelta, timezone
from typing import Optional, List, Dict, Any, Union, Tuple
import logging
from dataclasses import dataclass
import calendar


logger = logging.getLogger(__name__)


class DateParsingError(Exception):
    """Exception raised when date parsing fails"""
    pass


@dataclass
class DateRange:
    """
    Represents a date range for filtering calendar events.
    
    Attributes:
        from_date: Start date (inclusive), None means no start limit
        to_date: End date (inclusive), None means no end limit
        timezone_info: Timezone to use for date operations
    """
    from_date: Optional[datetime] = None
    to_date: Optional[datetime] = None
    timezone_info: Optional[timezone] = None
    
    def __post_init__(self):
        """Validate and normalize date range after initialization"""
        # Ensure dates are timezone-aware if timezone is specified
        if self.timezone_info:
            if self.from_date and self.from_date.tzinfo is None:
                self.from_date = self.from_date.replace(tzinfo=self.timezone_info)
            if self.to_date and self.to_date.tzinfo is None:
                self.to_date = self.to_date.replace(tzinfo=self.timezone_info)
        
        # Auto-swap dates if end is before start
        if (self.from_date and self.to_date and 
            self.from_date > self.to_date):
            logger.warning(f"End date {self.to_date} is before start date {self.from_date}. Swapping dates.")
            self.from_date, self.to_date = self.to_date, self.from_date
    
    def is_in_range(self, event_date: datetime) -> bool:
        """
        Check if an event date falls within this date range.
        
        Args:
            event_date: The event date to check
            
        Returns:
            True if the event date is within range, False otherwise
        """
        if not event_date:
            return False
        
        # Normalize timezones for comparison
        from_date_cmp = self.from_date
        to_date_cmp = self.to_date
        event_date_cmp = event_date
        
        # If one has timezone and other doesn't, make them compatible
        if event_date_cmp.tzinfo is None and (
            (from_date_cmp and from_date_cmp.tzinfo) or 
            (to_date_cmp and to_date_cmp.tzinfo)
        ):
            # Event date is naive, assume UTC
            event_date_cmp = event_date_cmp.replace(tzinfo=timezone.utc)
        elif event_date_cmp.tzinfo and (
            (from_date_cmp and from_date_cmp.tzinfo is None) or 
            (to_date_cmp and to_date_cmp.tzinfo is None)
        ):
            # Range dates are naive, make them UTC
            if from_date_cmp and from_date_cmp.tzinfo is None:
                from_date_cmp = from_date_cmp.replace(tzinfo=timezone.utc)
            if to_date_cmp and to_date_cmp.tzinfo is None:
                to_date_cmp = to_date_cmp.replace(tzinfo=timezone.utc)
        
        # Check lower bound
        if from_date_cmp and event_date_cmp < from_date_cmp:
            return False
        
        # Check upper bound (inclusive)
        if to_date_cmp and event_date_cmp > to_date_cmp:
            return False
        
        return True
    
    def filter_events(self, events: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Filter events within this date range.
        
        Args:
            events: List of Google Calendar event dictionaries
            
        Returns:
            Filtered list of events within the date range
        """
        if not self.from_date and not self.to_date:
            return events
        
        filtered = []
        for event in events:
            event_date = self.parse_event_date(event)
            if event_date and self.is_in_range(event_date):
                filtered.append(event)
        
        logger.info(f"Filtered {len(events)} events to {len(filtered)} events in date range")
        return filtered
    
    def parse_event_date(self, event: Dict[str, Any]) -> Optional[datetime]:
        """
        Extract datetime from a Google Calendar event.
        
        Args:
            event: Google Calendar event dictionary
            
        Returns:
            Event datetime or None if parsing fails
        """
        try:
            # Try to get start time first
            start = event.get('start', {})
            
            # Handle datetime events (with time)
            if 'dateTime' in start:
                date_str = start['dateTime']
                return datetime.fromisoformat(date_str.replace('Z', '+00:00'))
            
            # Handle all-day events (date only)
            elif 'date' in start:
                date_str = start['date']
                parsed_date = datetime.fromisoformat(date_str)
                # For all-day events, use the timezone if available
                if self.timezone_info:
                    parsed_date = parsed_date.replace(tzinfo=self.timezone_info)
                return parsed_date
            
            # Fallback: try end time
            end = event.get('end', {})
            if 'dateTime' in end:
                date_str = end['dateTime']
                return datetime.fromisoformat(date_str.replace('Z', '+00:00'))
            elif 'date' in end:
                date_str = end['date']
                parsed_date = datetime.fromisoformat(date_str)
                if self.timezone_info:
                    parsed_date = parsed_date.replace(tzinfo=self.timezone_info)
                return parsed_date
            
            logger.warning(f"Could not parse date from event: {event.get('id', 'unknown')}")
            return None
            
        except Exception as e:
            logger.warning(f"Error parsing event date: {e}")
            return None
    
    def to_filename_string(self) -> str:
        """
        Convert date range to filename-safe string.
        
        Returns:
            String representation suitable for filenames
        """
        if not self.from_date and not self.to_date:
            return "all_dates"
        
        # Format dates for filename
        from_str = self.from_date.strftime("%Y%m%d") if self.from_date else "beginning"
        to_str = self.to_date.strftime("%Y%m%d") if self.to_date else "end"
        
        return f"{from_str}_to_{to_str}"
    
    def to_dict(self) -> Dict[str, Optional[str]]:
        """
        Convert date range to dictionary format for metadata.
        
        Returns:
            Dictionary with ISO format date strings
        """
        return {
            'from': self.from_date.isoformat() if self.from_date else None,
            'to': self.to_date.isoformat() if self.to_date else None,
            'timezone': str(self.timezone_info) if self.timezone_info else None
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'DateRange':
        """
        Create DateRange from dictionary metadata.
        
        Args:
            data: Dictionary with date range information
            
        Returns:
            DateRange object
        """
        from_date = None
        to_date = None
        tz = None
        
        if data.get('from'):
            from_date = datetime.fromisoformat(data['from'])
        
        if data.get('to'):
            to_date = datetime.fromisoformat(data['to'])
        
        if data.get('timezone'):
            try:
                # Simple timezone handling - could be expanded
                tz_str = data['timezone']
                if 'UTC' in tz_str:
                    tz = timezone.utc
            except Exception as e:
                logger.warning(f"Could not parse timezone {data.get('timezone')}: {e}")
        
        return cls(from_date=from_date, to_date=to_date, timezone_info=tz)
    
    def __str__(self) -> str:
        """String representation of the date range"""
        from_str = self.from_date.strftime("%Y-%m-%d") if self.from_date else "beginning"
        to_str = self.to_date.strftime("%Y-%m-%d") if self.to_date else "end"
        return f"DateRange(from={from_str}, to={to_str})"


def parse_date_argument(date_arg: Union[str, None]) -> Optional[datetime]:
    """
    Parse various date argument formats including shortcuts.
    
    Args:
        date_arg: Date string or shortcut
        
    Returns:
        Parsed datetime or None if empty
        
    Raises:
        DateParsingError: If parsing fails
    """
    if not date_arg:
        return None
    
    date_arg = date_arg.lower().strip()
    now = datetime.now()
    
    # Date shortcuts
    shortcuts = {
        'today': now.replace(hour=0, minute=0, second=0, microsecond=0),
        'yesterday': (now - timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0),
        'tomorrow': (now + timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0),
    }
    
    # Week shortcuts
    days_since_monday = now.weekday()
    week_start = (now - timedelta(days=days_since_monday)).replace(hour=0, minute=0, second=0, microsecond=0)
    shortcuts.update({
        'this-week': week_start,
        'last-week': week_start - timedelta(weeks=1),
        'next-week': week_start + timedelta(weeks=1),
    })
    
    # Month shortcuts
    month_start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    shortcuts.update({
        'this-month': month_start,
        'next-month': _get_next_month_start(month_start),
    })
    
    # Last month calculation
    if now.month == 1:
        last_month_start = now.replace(year=now.year-1, month=12, day=1, hour=0, minute=0, second=0, microsecond=0)
    else:
        last_month_start = now.replace(month=now.month-1, day=1, hour=0, minute=0, second=0, microsecond=0)
    shortcuts['last-month'] = last_month_start
    
    # Year shortcuts
    year_start = now.replace(month=1, day=1, hour=0, minute=0, second=0, microsecond=0)
    shortcuts.update({
        'this-year': year_start,
        'last-year': year_start.replace(year=year_start.year-1),
        'next-year': year_start.replace(year=year_start.year+1),
    })
    
    # Relative day shortcuts
    if date_arg.startswith('next-') and date_arg.endswith('-days'):
        try:
            days = int(date_arg.replace('next-', '').replace('-days', ''))
            return now + timedelta(days=days)
        except ValueError:
            pass
    
    if date_arg.startswith('last-') and date_arg.endswith('-days'):
        try:
            days = int(date_arg.replace('last-', '').replace('-days', ''))
            return now - timedelta(days=days)
        except ValueError:
            pass
    
    # Check shortcuts first
    if date_arg in shortcuts:
        return shortcuts[date_arg]
    
    # Try to parse as ISO date
    iso_patterns = [
        r'^\d{4}-\d{2}-\d{2}$',  # YYYY-MM-DD
        r'^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}$',  # YYYY-MM-DDTHH:MM:SS
        r'^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$',  # YYYY-MM-DDTHH:MM:SSZ
        r'^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}[+-]\d{2}:\d{2}$',  # With timezone
    ]
    
    for pattern in iso_patterns:
        if re.match(pattern, date_arg):
            try:
                if date_arg.endswith('Z'):
                    return datetime.fromisoformat(date_arg.replace('Z', '+00:00'))
                else:
                    return datetime.fromisoformat(date_arg)
            except ValueError:
                continue
    
    # Try common US date formats
    us_patterns = [
        ('%m/%d/%Y', r'^\d{1,2}/\d{1,2}/\d{4}$'),  # MM/DD/YYYY
        ('%m-%d-%Y', r'^\d{1,2}-\d{1,2}-\d{4}$'),  # MM-DD-YYYY
    ]
    
    for fmt, pattern in us_patterns:
        if re.match(pattern, date_arg):
            try:
                return datetime.strptime(date_arg, fmt)
            except ValueError:
                continue
    
    # Try European date formats
    eu_patterns = [
        ('%d/%m/%Y', r'^\d{1,2}/\d{1,2}/\d{4}$'),  # DD/MM/YYYY
        ('%d-%m-%Y', r'^\d{1,2}-\d{1,2}-\d{4}$'),  # DD-MM-YYYY
        ('%d.%m.%Y', r'^\d{1,2}\.\d{1,2}\.\d{4}$'),  # DD.MM.YYYY
    ]
    
    for fmt, pattern in eu_patterns:
        if re.match(pattern, date_arg):
            try:
                return datetime.strptime(date_arg, fmt)
            except ValueError:
                continue
    
    # Raise error with helpful message
    shortcuts_list = ', '.join(sorted(shortcuts.keys()))
    raise DateParsingError(
        f"Could not parse date '{date_arg}'. "
        f"Supported formats: YYYY-MM-DD, MM/DD/YYYY, DD/MM/YYYY, "
        f"or shortcuts: {shortcuts_list}, next-N-days, last-N-days"
    )


def _get_next_month_start(current_month_start: datetime) -> datetime:
    """Get the first day of the next month"""
    if current_month_start.month == 12:
        return current_month_start.replace(year=current_month_start.year + 1, month=1)
    else:
        return current_month_start.replace(month=current_month_start.month + 1)


def create_date_range_from_args(args) -> Optional[DateRange]:
    """
    Create DateRange object from CLI arguments.
    
    Args:
        args: Parsed CLI arguments containing date-related parameters
        
    Returns:
        DateRange object or None if no date filtering requested
        
    Raises:
        DateParsingError: If date parsing fails
    """
    from_date = None
    to_date = None
    
    # Handle explicit from/to dates
    if hasattr(args, 'from_date') and args.from_date:
        from_date = parse_date_argument(args.from_date)
    
    if hasattr(args, 'to_date') and args.to_date:
        to_date = parse_date_argument(args.to_date)
        # If to_date is a date-only shortcut (time is 00:00:00), adjust to end of day
        if to_date and to_date.hour == 0 and to_date.minute == 0 and to_date.second == 0:
            to_date = to_date.replace(hour=23, minute=59, second=59)
    
    # Handle days_back argument
    if hasattr(args, 'days_back') and args.days_back:
        now = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
        from_date = now - timedelta(days=args.days_back)
        if not to_date:
            to_date = now.replace(hour=23, minute=59, second=59)
    
    # Handle days_forward argument
    if hasattr(args, 'days_forward') and args.days_forward:
        now = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
        if not from_date:
            from_date = now
        to_date = (now + timedelta(days=args.days_forward)).replace(hour=23, minute=59, second=59)
    
    # Handle year argument
    if hasattr(args, 'year') and args.year:
        try:
            year = int(args.year)
            from_date = datetime(year, 1, 1)
            to_date = datetime(year, 12, 31, 23, 59, 59)
        except ValueError:
            raise DateParsingError(f"Invalid year: {args.year}")
    
    # Handle month argument (YYYY-MM format)
    if hasattr(args, 'month') and args.month:
        try:
            year, month = map(int, args.month.split('-'))
            from_date = datetime(year, month, 1)
            # Get last day of month
            last_day = calendar.monthrange(year, month)[1]
            to_date = datetime(year, month, last_day, 23, 59, 59)
        except (ValueError, IndexError):
            raise DateParsingError(f"Invalid month format: {args.month}. Use YYYY-MM")
    
    # Return DateRange if we have any dates, otherwise None
    if from_date or to_date:
        return DateRange(from_date=from_date, to_date=to_date)
    
    return None


def generate_backup_filename(user_email: str, 
                           date_range: Optional[DateRange] = None, 
                           operation: str = 'backup') -> str:
    """
    Generate filename with user email, date range, and timestamp.
    
    Args:
        user_email: User's email address
        date_range: Optional date range for filtering
        operation: Operation type (backup, clean, restore)
        
    Returns:
        Generated filename following the new format specification
    """
    # Sanitize email for filename (replace special characters)
    email_safe = user_email.replace('@', '_at_').replace('.', '_')
    
    # Get date range string
    date_range_str = date_range.to_filename_string() if date_range else "all_dates"
    
    # Current timestamp
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    
    # Construct filename following format:
    # calendar_backup_user_at_domain_com_YYYYMMDD_to_YYYYMMDD_at_TIMESTAMP.json
    return f"calendar_{operation}_{email_safe}_{date_range_str}_at_{timestamp}.json"


def create_backup_metadata(events: List[Dict[str, Any]], 
                          user_email: str, 
                          date_range: Optional[DateRange] = None,
                          operation: str = 'backup',
                          redaction_level: Optional[str] = None,
                          version: str = '2.1.0') -> Dict[str, Any]:
    """
    Create backup file with comprehensive metadata.
    
    Args:
        events: List of calendar events
        user_email: User's email address
        date_range: Optional date range used for filtering
        operation: Type of operation (backup, clean, restore)
        redaction_level: Redaction level applied (if any)
        version: Tool version
        
    Returns:
        Dictionary with metadata and events
    """
    # Count events in range if date filtering was applied
    events_in_range = len(events)
    if date_range:
        # If date_range was used, events list is already filtered
        total_events = events_in_range  # This would need to be passed separately for accuracy
    else:
        total_events = len(events)
    
    metadata = {
        'backup_timestamp': datetime.now().isoformat(),
        'user_email': user_email,
        'date_range': date_range.to_dict() if date_range else None,
        'total_events': total_events,
        'events_in_range': events_in_range,
        'operation': operation,
        'redaction_level': redaction_level,
        'version': version
    }
    
    return {
        'metadata': metadata,
        'events': events
    }


def load_backup_file(filename: str) -> Tuple[List[Dict[str, Any]], Optional[Dict[str, Any]]]:
    """
    Load backup file with backward compatibility.
    
    Args:
        filename: Path to backup file
        
    Returns:
        Tuple of (events_list, metadata_dict)
        metadata_dict is None for old format files
        
    Raises:
        FileNotFoundError: If backup file doesn't exist
        ValueError: If backup file is malformed
    """
    try:
        with open(filename, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        # New format with metadata
        if isinstance(data, dict) and 'metadata' in data:
            return data['events'], data['metadata']
        
        # Old format - just events array
        elif isinstance(data, list):
            return data, None
        
        # Very old format - events might be at root level of dict
        elif isinstance(data, dict) and 'events' not in data:
            logger.warning(f"Unusual backup format in {filename}, treating as events list")
            return [data], None
        
        else:
            raise ValueError(f"Unrecognized backup file format in {filename}")
            
    except json.JSONDecodeError as e:
        raise ValueError(f"Invalid JSON in backup file {filename}: {e}")
    except Exception as e:
        raise ValueError(f"Error loading backup file {filename}: {e}")


def get_valid_date_shortcuts() -> List[str]:
    """
    Get list of all valid date shortcuts for help text.
    
    Returns:
        List of valid shortcut strings
    """
    base_shortcuts = [
        'today', 'yesterday', 'tomorrow',
        'this-week', 'last-week', 'next-week',
        'this-month', 'last-month', 'next-month',
        'this-year', 'last-year', 'next-year'
    ]
    
    relative_examples = ['last-30-days', 'next-7-days', 'last-N-days', 'next-N-days']
    
    return base_shortcuts + relative_examples


if __name__ == '__main__':
    # Simple test cases
    print("Testing date_utils module...")
    
    # Test date parsing
    test_dates = ['today', '2025-01-01', 'last-month', 'next-7-days']
    for date_str in test_dates:
        try:
            parsed = parse_date_argument(date_str)
            print(f"'{date_str}' -> {parsed}")
        except DateParsingError as e:
            print(f"Error parsing '{date_str}': {e}")
    
    # Test DateRange
    dr = DateRange(
        from_date=parse_date_argument('2025-01-01'),
        to_date=parse_date_argument('2025-01-31')
    )
    print(f"DateRange: {dr}")
    print(f"Filename string: {dr.to_filename_string()}")
    
    # Test filename generation
    filename = generate_backup_filename(
        'kwameaistudio@gmail.com', 
        dr, 
        'backup'
    )
    print(f"Generated filename: {filename}")