"""Package data for calwash (bundled credentials, etc.)."""
