"""
Local LLM-based sensitive content detection for calwash.

Uses ollama for local inference to classify calendar event content
that regex patterns miss — context-dependent sensitivity like medical
appointments, legal meetings, substance use references, etc.

Requires ollama installed separately: https://ollama.ai
"""

import json
import logging
import urllib.request
import urllib.error
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

logger = logging.getLogger(__name__)

OLLAMA_BASE_URL = "http://localhost:11434"
DEFAULT_MODEL = "llama3.2"
REQUEST_TIMEOUT = 60  # seconds per batch


class SensitiveCategory(Enum):
    MEDICAL = "medical"
    LEGAL = "legal"
    FINANCIAL = "financial"
    SUBSTANCE_USE = "substance_use"
    CAREER = "career"
    RELATIONSHIP = "relationship"
    POLITICAL = "political"
    RELIGIOUS = "religious"


DEFAULT_CATEGORIES = [
    SensitiveCategory.MEDICAL,
    SensitiveCategory.LEGAL,
    SensitiveCategory.FINANCIAL,
    SensitiveCategory.SUBSTANCE_USE,
]

CATEGORY_DESCRIPTIONS = {
    SensitiveCategory.MEDICAL: "doctor visits, prescriptions, diagnoses, therapy, procedures, medications, health conditions, mental health",
    SensitiveCategory.LEGAL: "lawyer meetings, court dates, legal proceedings, divorce filings, custody hearings, lawsuits",
    SensitiveCategory.FINANCIAL: "salary discussions, debt, bankruptcy, loan meetings, financial advisor, tax issues, account balances",
    SensitiveCategory.SUBSTANCE_USE: "AA/NA meetings, rehab, recovery groups, prescription pickups for controlled substances, drug/alcohol references",
    SensitiveCategory.CAREER: "job interviews at other companies, resignation planning, salary negotiation, recruiter calls",
    SensitiveCategory.RELATIONSHIP: "couples counseling, dating, divorce proceedings, family therapy",
    SensitiveCategory.POLITICAL: "political party meetings, campaign events, political fundraisers, activist gatherings",
    SensitiveCategory.RELIGIOUS: "worship services, religious counseling, faith-based support groups, prayer meetings",
}

RECOMMENDED_MODELS = [
    {"name": "phi4-mini", "size": "2.5 GB", "params": "3.8B", "note": "Fast, good accuracy", "recommended": True},
    {"name": "llama3.2", "size": "2.0 GB", "params": "3B", "note": "Lightweight default", "recommended": True},
    {"name": "llama3.1", "size": "4.7 GB", "params": "8B", "note": "Best accuracy", "recommended": True},
    {"name": "gemma3n", "size": "5.6 GB", "params": "~2B (e2b)", "note": "Google, efficient on-device", "recommended": False},
    {"name": "nemotron-mini", "size": "~4.7 GB", "params": "8B", "note": "Nvidia, strong reasoning", "recommended": False},
    {"name": "phi4", "size": "9.1 GB", "params": "14B", "note": "Most capable, heavier", "recommended": False},
    {"name": "gemma3n:e4b", "size": "7.5 GB", "params": "~4B", "note": "Google, better accuracy", "recommended": False},
    {"name": "gemma4", "size": "~5.0 GB", "params": "~4B", "note": "Google latest", "recommended": False},
]


@dataclass
class AISensitiveFinding:
    """A single sensitive content finding from the LLM."""
    field: str  # "summary", "description", or "location"
    sensitive_text: str
    category: str
    reason: str


@dataclass
class AISensitiveResult:
    """LLM classification result for one event."""
    event_index: int
    is_sensitive: bool
    findings: list[AISensitiveFinding] = field(default_factory=list)


# =============================================================================
# Category parsing
# =============================================================================

def parse_categories(categories_str: Optional[str]) -> list[SensitiveCategory]:
    """Parse comma-separated category string into list of SensitiveCategory."""
    if not categories_str:
        return list(DEFAULT_CATEGORIES)

    result = []
    valid_names = [c.value for c in SensitiveCategory]
    for name in categories_str.split(','):
        name = name.strip().lower()
        try:
            result.append(SensitiveCategory(name))
        except ValueError:
            logger.warning(f"Unknown category '{name}', skipping. Valid: {valid_names}")

    return result if result else list(DEFAULT_CATEGORIES)


# =============================================================================
# Ollama communication
# =============================================================================

def check_ollama_available(model: str = DEFAULT_MODEL) -> tuple[bool, str]:
    """Check if ollama is running and the requested model is available."""
    try:
        req = urllib.request.Request(f"{OLLAMA_BASE_URL}/api/tags")
        with urllib.request.urlopen(req, timeout=5) as resp:
            data = json.loads(resp.read().decode())
    except urllib.error.URLError:
        return False, (
            "Ollama is not running. Install from https://ollama.ai "
            "and run 'ollama serve'"
        )
    except Exception as e:
        return False, f"Cannot connect to ollama: {e}"

    available_models = [m.get("name", "").split(":")[0] for m in data.get("models", [])]
    model_base = model.split(":")[0]
    if model_base not in available_models and model not in [m.get("name", "") for m in data.get("models", [])]:
        return False, (
            f"Model '{model}' not found. Run 'ollama pull {model}' first. "
            f"Available: {', '.join(available_models) or 'none'}"
        )

    return True, ""


def _build_system_prompt(categories: list[SensitiveCategory]) -> str:
    """Build the system prompt for the LLM classifier."""
    cat_lines = "\n".join(
        f"- {cat.value}: {CATEGORY_DESCRIPTIONS[cat]}"
        for cat in categories
    )

    return f"""You are a privacy classifier for calendar events. For each event, determine if the content reveals sensitive personal information in these categories:

{cat_lines}

You MUST respond with ONLY valid JSON using this exact format:
{{
  "results": [
    {{
      "event_index": 0,
      "is_sensitive": true,
      "findings": [
        {{
          "field": "summary",
          "sensitive_text": "the exact text that is sensitive",
          "category": "medical",
          "reason": "brief reason"
        }}
      ]
    }}
  ]
}}

If an event has no sensitive content, return {{"event_index": N, "is_sensitive": false, "findings": []}}.

IMPORTANT rules:
- Only flag content that genuinely reveals private information someone would want hidden.
- Generic terms like "meeting", "lunch", "sync", "standup" are NOT sensitive.
- Do NOT flag email addresses, phone numbers, or URLs — regex already handles those.
- Focus on the MEANING and CONTEXT, not surface-level keywords.
- The "sensitive_text" must be the EXACT text from the event, not paraphrased."""


def _build_user_prompt(events: list[dict], batch_start: int, batch_end: int) -> str:
    """Build the user prompt for a batch of events."""
    lines = ["Classify these calendar events:\n"]

    for i, event in enumerate(events[batch_start:batch_end]):
        idx = batch_start + i
        summary = event.get("summary", "")
        description = event.get("description", "")
        location = event.get("location", "")

        lines.append(f"Event {idx}:")
        if summary:
            lines.append(f"  Summary: {summary}")
        if description:
            desc = description[:500] + "..." if len(description) > 500 else description
            lines.append(f"  Description: {desc}")
        if location:
            lines.append(f"  Location: {location}")
        lines.append("")

    lines.append("Respond with JSON only.")
    return "\n".join(lines)


def _call_ollama(system_prompt: str, user_prompt: str, model: str) -> Optional[dict]:
    """Call ollama API and return parsed JSON response."""
    payload = json.dumps({
        "model": model,
        "system": system_prompt,
        "prompt": user_prompt,
        "stream": False,
        "format": "json",
    }).encode()

    req = urllib.request.Request(
        f"{OLLAMA_BASE_URL}/api/generate",
        data=payload,
        headers={"Content-Type": "application/json"},
    )

    try:
        with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT) as resp:
            data = json.loads(resp.read().decode())
    except urllib.error.URLError as e:
        logger.warning(f"Ollama request failed: {e}")
        return None
    except TimeoutError:
        logger.warning("Ollama request timed out")
        return None

    response_text = data.get("response", "")
    try:
        return json.loads(response_text)
    except json.JSONDecodeError:
        logger.warning(f"LLM returned invalid JSON: {response_text[:200]}")
        return None


def _parse_batch_results(
    raw: dict, batch_start: int, batch_end: int
) -> list[AISensitiveResult]:
    """Parse raw LLM JSON into structured results with validation."""
    results = []
    valid_indices = set(range(batch_start, batch_end))
    valid_fields = {"summary", "description", "location"}

    for item in raw.get("results", []):
        try:
            idx = item.get("event_index")
            if idx not in valid_indices:
                continue

            is_sensitive = bool(item.get("is_sensitive", False))
            findings = []

            if is_sensitive:
                for f in item.get("findings", []):
                    field_name = f.get("field", "").lower()
                    if field_name not in valid_fields:
                        continue
                    if not f.get("sensitive_text"):
                        continue

                    findings.append(AISensitiveFinding(
                        field=field_name,
                        sensitive_text=str(f["sensitive_text"]),
                        category=str(f.get("category", "unknown")),
                        reason=str(f.get("reason", "")),
                    ))

            results.append(AISensitiveResult(
                event_index=idx,
                is_sensitive=is_sensitive and len(findings) > 0,
                findings=findings,
            ))
        except (KeyError, TypeError, ValueError) as e:
            logger.debug(f"Skipping malformed result entry: {e}")
            continue

    return results


# =============================================================================
# Main classification entry point
# =============================================================================

def classify_events_batch(
    events: list[dict],
    categories: list[SensitiveCategory],
    model: str = DEFAULT_MODEL,
    batch_size: int = 5,
) -> list[AISensitiveResult]:
    """Classify events for sensitive content using a local LLM via ollama.

    Args:
        events: List of calendar event dicts (original, pre-regex)
        categories: Which sensitivity categories to check
        model: Ollama model name
        batch_size: Number of events per LLM call

    Returns:
        List of AISensitiveResult for events the LLM flagged
    """
    system_prompt = _build_system_prompt(categories)
    all_results: list[AISensitiveResult] = []
    total = len(events)
    cat_names = ", ".join(c.value for c in categories)
    logger.info(f"AI scanning {total} events with model={model}, categories=[{cat_names}]")

    for batch_start in range(0, total, batch_size):
        batch_end = min(batch_start + batch_size, total)
        logger.info(f"  AI scanning events {batch_start + 1}-{batch_end} of {total}...")

        user_prompt = _build_user_prompt(events, batch_start, batch_end)
        raw = _call_ollama(system_prompt, user_prompt, model)

        if raw is None:
            logger.debug("Retrying batch with simplified prompt...")
            raw = _call_ollama(system_prompt, user_prompt, model)

        if raw is None:
            logger.warning(f"  Skipping batch {batch_start + 1}-{batch_end} (LLM failure)")
            continue

        batch_results = _parse_batch_results(raw, batch_start, batch_end)
        all_results.extend(batch_results)

    sensitive_count = sum(1 for r in all_results if r.is_sensitive)
    logger.info(f"AI detection complete: {sensitive_count} events flagged as sensitive")
    return all_results


# =============================================================================
# Merge AI findings into existing regex results
# =============================================================================

def merge_ai_findings(
    ai_results: list[AISensitiveResult],
    existing_changes: list[dict],
    cleaned_events: list[dict],
    original_events: list[dict],
) -> tuple[list[dict], list[dict]]:
    """Merge AI-detected sensitive content into existing regex results.

    For each AI finding, checks if regex already handled it (text already
    replaced in cleaned version). If not, replaces the sensitive text with
    [SENSITIVE: CATEGORY] in the cleaned event and adds to the changes list.

    Args:
        ai_results: LLM classification results
        existing_changes: Changes from regex pass
        cleaned_events: Events after regex cleaning
        original_events: Original events (pre-regex)

    Returns:
        Tuple of (updated_cleaned_events, updated_changes)
    """
    changes_by_id: dict[str, dict] = {}
    for change in existing_changes:
        changes_by_id[change["event_id"]] = change

    ai_additions = 0

    for result in ai_results:
        if not result.is_sensitive:
            continue

        idx = result.event_index
        if idx >= len(cleaned_events) or idx >= len(original_events):
            continue

        event = cleaned_events[idx]
        original = original_events[idx]
        event_id = event.get("id", "unknown")

        for finding in result.findings:
            current_text = str(event.get(finding.field, ""))
            original_text = str(original.get(finding.field, ""))

            if finding.sensitive_text not in current_text:
                continue

            category_tag = finding.category.upper().replace(" ", "_")
            replacement = f"[SENSITIVE: {category_tag}]"
            new_text = current_text.replace(finding.sensitive_text, replacement)
            event[finding.field] = new_text
            ai_additions += 1

            if event_id not in changes_by_id:
                changes_by_id[event_id] = {
                    "event_id": event_id,
                    "event_date": event.get("start", {}).get(
                        "dateTime", event.get("start", {}).get("date", "Unknown")
                    ),
                    "modifications": [],
                }
                existing_changes.append(changes_by_id[event_id])

            orig_display = original_text[:100] + "..." if len(original_text) > 100 else original_text
            new_display = new_text[:100] + "..." if len(new_text) > 100 else new_text

            changes_by_id[event_id]["modifications"].append({
                "field": finding.field,
                "original": orig_display,
                "cleaned": new_display,
                "source": "ai",
                "category": finding.category,
                "reason": finding.reason,
            })

    if ai_additions > 0:
        logger.info(f"AI added {ai_additions} additional redactions")

    return cleaned_events, existing_changes


# =============================================================================
# AI Setup, Status, and Model Management
# =============================================================================

def _detect_platform() -> dict:
    """Detect OS and provide install instructions."""
    import platform
    system = platform.system().lower()

    if system == "darwin":
        return {
            "os": "macOS",
            "install_cmd": "brew install ollama",
            "install_alt": "Or download from https://ollama.ai/download/mac",
        }
    elif system == "linux":
        return {
            "os": "Linux",
            "install_cmd": "curl -fsSL https://ollama.ai/install.sh | sh",
            "install_alt": "Or see https://ollama.ai/download/linux",
        }
    elif system == "windows":
        return {
            "os": "Windows",
            "install_cmd": "Download from https://ollama.ai/download/windows",
            "install_alt": "Or use: winget install Ollama.Ollama",
        }
    else:
        return {
            "os": system,
            "install_cmd": "See https://ollama.ai/download",
            "install_alt": "",
        }


def _is_ollama_installed() -> bool:
    """Check if ollama binary is on PATH."""
    import shutil
    return shutil.which("ollama") is not None


def _is_ollama_running() -> bool:
    """Check if ollama server is responding."""
    try:
        req = urllib.request.Request(f"{OLLAMA_BASE_URL}/api/tags")
        with urllib.request.urlopen(req, timeout=3) as resp:
            return resp.status == 200
    except Exception:
        return False


def _get_pulled_models() -> list[str]:
    """Get list of models already pulled in ollama."""
    try:
        req = urllib.request.Request(f"{OLLAMA_BASE_URL}/api/tags")
        with urllib.request.urlopen(req, timeout=5) as resp:
            data = json.loads(resp.read().decode())
        return [m.get("name", "") for m in data.get("models", [])]
    except Exception:
        return []


def _pull_model(model: str) -> bool:
    """Pull a model via ollama CLI with progress feedback."""
    import subprocess
    logger.info(f"Pulling model '{model}'... (this may take a few minutes)")
    try:
        result = subprocess.run(
            ["ollama", "pull", model],
            capture_output=False,
            timeout=600,
        )
        return result.returncode == 0
    except FileNotFoundError:
        logger.error("ollama command not found. Please install ollama first.")
        return False
    except subprocess.TimeoutExpired:
        logger.error("Model pull timed out after 10 minutes.")
        return False
    except Exception as e:
        logger.error(f"Failed to pull model: {e}")
        return False


def _run_test_classification(model: str) -> Optional[str]:
    """Run a quick test classification to verify the model works."""
    test_system = """You are a privacy classifier. Respond with ONLY valid JSON.
{"results": [{"event_index": 0, "is_sensitive": true/false, "findings": [{"field": "summary", "sensitive_text": "text", "category": "category", "reason": "reason"}]}]}"""

    test_prompt = """Classify this calendar event:

Event 0:
  Summary: AA meeting at St. Mark's Church
  Description: Weekly recovery group meeting

Respond with JSON only."""

    raw = _call_ollama(test_system, test_prompt, model)
    if raw is None:
        return None

    results = raw.get("results", [])
    if not results:
        return None

    r = results[0]
    if r.get("is_sensitive"):
        findings = r.get("findings", [])
        if findings:
            cat = findings[0].get("category", "unknown")
            text = findings[0].get("sensitive_text", "")
            return f'"{text}" -> {cat}'
        return "flagged as sensitive"
    return "not flagged (model may need tuning)"


def handle_ai_setup(model: Optional[str] = None, interactive: bool = True):
    """Guide user through ollama + model setup."""
    platform_info = _detect_platform()

    print("\n" + "=" * 60)
    print("  calwash AI Setup")
    print("=" * 60)

    # Step 1: Check ollama installation
    print(f"\n[1/4] Checking ollama installation ({platform_info['os']})...")

    if _is_ollama_installed():
        print("  ollama is installed")
    else:
        print("  ollama is NOT installed.\n")
        print(f"  Install with:")
        print(f"    {platform_info['install_cmd']}")
        if platform_info.get("install_alt"):
            print(f"    {platform_info['install_alt']}")
        print(f"\n  After installing, run this command again.")
        return False

    # Step 2: Check ollama is running
    print("\n[2/4] Checking ollama server...")

    if _is_ollama_running():
        print("  ollama is running")
    else:
        print("  ollama is NOT running.")
        print("  Start it with: ollama serve")
        print("  (or it may start automatically after install)")
        print(f"\n  After starting, run this command again.")
        return False

    # Step 3: Select and pull model
    print("\n[3/4] Setting up model...")

    pulled = _get_pulled_models()

    if model:
        selected = model
        model_base = model.split(":")[0]
        if any(model_base in m or model in m for m in pulled):
            print(f"  Model '{model}' is already available")
        else:
            print(f"  Model '{model}' needs to be downloaded.")
            if interactive:
                resp = input(f"  Download '{model}' now? (yes/no): ")
                if resp.strip().lower() not in ("yes", "y"):
                    print("  Skipped. Pull it manually: ollama pull " + model)
                    return False
            if not _pull_model(model):
                return False
            print(f"  Model '{model}' is ready")
    elif interactive:
        print("\n  Available models for calwash:\n")
        print("  Recommended:")
        rec_models = [m for m in RECOMMENDED_MODELS if m["recommended"]]
        other_models = [m for m in RECOMMENDED_MODELS if not m["recommended"]]

        for i, m in enumerate(rec_models, 1):
            pulled_tag = " [INSTALLED]" if any(m["name"] in p for p in pulled) else ""
            print(f"    {i}. {m['name']:16s} ({m['size']:>7s}, {m['params']:>5s})  {m['note']}{pulled_tag}")

        print("\n  Also supported:")
        for i, m in enumerate(other_models, len(rec_models) + 1):
            pulled_tag = " [INSTALLED]" if any(m["name"] in p for p in pulled) else ""
            print(f"    {i}. {m['name']:16s} ({m['size']:>7s}, {m['params']:>5s})  {m['note']}{pulled_tag}")

        print(f"\n    Or enter any ollama model name.")
        choice = input(f"\n  Choose [1-{len(RECOMMENDED_MODELS)} or model name] (default: 1): ").strip()

        if not choice:
            choice = "1"

        all_models = rec_models + other_models
        try:
            idx = int(choice) - 1
            if 0 <= idx < len(all_models):
                selected = all_models[idx]["name"]
            else:
                print(f"  Invalid choice. Using default: phi4-mini")
                selected = "phi4-mini"
        except ValueError:
            selected = choice

        if any(selected in m for m in pulled):
            print(f"  Model '{selected}' is already available")
        else:
            print(f"\n  Downloading '{selected}'...")
            if not _pull_model(selected):
                return False
            print(f"  Model '{selected}' is ready")
    else:
        selected = DEFAULT_MODEL
        if not any(selected in m for m in pulled):
            if not _pull_model(selected):
                return False

    # Step 4: Test classification
    print(f"\n[4/4] Testing model '{selected}'...")

    test_result = _run_test_classification(selected)
    if test_result:
        print(f"  Test: \"AA meeting at St. Mark's Church\" -> {test_result}")
        print("\n  Setup complete! Use --ai to enable AI detection:")
        print(f"    calwash clean --dry-run --ai --ai-model {selected}")
    else:
        print("  Test produced no result. The model may need a different prompt format.")
        print("  You can still try using --ai, results may vary with this model.")

    print()
    return True


def handle_ai_status():
    """Show current AI detection readiness."""
    print("\n" + "=" * 60)
    print("  calwash AI Status")
    print("=" * 60)

    installed = _is_ollama_installed()
    print(f"\n  Ollama installed: {'yes' if installed else 'no'}")

    if not installed:
        platform_info = _detect_platform()
        print(f"  Install: {platform_info['install_cmd']}")
        print()
        return

    running = _is_ollama_running()
    print(f"  Ollama running:   {'yes' if running else 'no'}")

    if not running:
        print(f"  Start with: ollama serve")
        print()
        return

    pulled = _get_pulled_models()
    if pulled:
        print(f"  Models installed:  {len(pulled)}")
        for m in pulled:
            print(f"    - {m}")
    else:
        print(f"  Models installed:  none")
        print(f"  Pull one with: calwash ai setup")

    if pulled:
        print(f"\n  Quick test with '{pulled[0]}'...")
        test_result = _run_test_classification(pulled[0])
        if test_result:
            print(f"  \"AA meeting at St. Mark's Church\" -> {test_result}")
        else:
            print(f"  Test inconclusive")

    print()


def handle_ai_models():
    """List recommended models with sizes."""
    print("\n" + "=" * 60)
    print("  Recommended Models for calwash")
    print("=" * 60)

    pulled = []
    if _is_ollama_running():
        pulled = _get_pulled_models()

    print(f"\n  {'Model':<18s} {'Size':>7s}  {'Params':>6s}  {'Status':<12s} Notes")
    print(f"  {'-'*18} {'-'*7}  {'-'*6}  {'-'*12} {'-'*30}")

    for m in RECOMMENDED_MODELS:
        is_pulled = any(m["name"] in p for p in pulled)
        status = "INSTALLED" if is_pulled else ""
        rec = " [RECOMMENDED]" if m["recommended"] else ""
        print(f"  {m['name']:<18s} {m['size']:>7s}  {m['params']:>6s}  {status:<12s} {m['note']}{rec}")

    print(f"\n  Any ollama-compatible model works. See: https://ollama.com/library")
    print(f"\n  Install a model:")
    print(f"    calwash ai setup --model <name>")
    print(f"    ollama pull <name>")
    print()
