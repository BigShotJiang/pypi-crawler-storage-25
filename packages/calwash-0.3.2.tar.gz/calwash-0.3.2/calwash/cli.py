#!/usr/bin/env python3
"""
calwash — Redact sensitive data from your calendar events.
Supports Google Calendar and Apple Calendar (CalDAV).
"""

import json
import argparse
import logging
from datetime import datetime, date, timezone
from pathlib import Path
import os
import sys
import glob
from calwash import __version__
from calwash.cleaner import clean_event_data as clean_events_impl
from calwash.auth import (
    create_user_filename,
    get_account_directory,
    get_output_directory,
    list_accounts,
    get_env_backup_dir,
    get_env_organize_by_user,
    CALWASH_HOME,
)
from calwash.providers import get_provider
from calwash.redaction import RedactionLevel
from calwash.dates import (
    DateRange,
    create_date_range_from_args,
    generate_backup_filename,
    create_backup_metadata,
    load_backup_file,
    DateParsingError,
    get_valid_date_shortcuts
)

def _get_version():
    """Get package version, avoiding circular import."""
    from calwash import __version__
    return __version__

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)



# ============================================================================
# CLEANING FUNCTIONS
# ============================================================================

def fetch_and_backup_events(service, user_email: str, 
                           backup_dir: str = None, 
                           organize_by_user: bool = False,
                           date_range: DateRange = None):
    """Fetch events and create a backup file with user identification and date filtering
    
    Args:
        service: Google Calendar service object
        user_email: Authenticated user's email address
        backup_dir: Custom backup directory (optional)
        organize_by_user: Create user-specific subdirectories
        date_range: Optional date range for filtering events
        
    Returns:
        tuple: (events, backup_filename) - Events list and backup file path
    """
    logger.info("Fetching calendar events...")
    if date_range:
        logger.info(f"Filtering events by date range: {date_range}")
    
    try:
        # Build API request parameters
        params = {
            'calendarId': 'primary',
            'maxResults': 2500,
            'singleEvents': True,
            'orderBy': 'startTime'
        }
        
        # Add date range filters if specified
        if date_range:
            if date_range.from_date:
                # Ensure timezone info is present for API
                from_dt = date_range.from_date.replace(hour=0, minute=0, second=0, microsecond=0)
                if from_dt.tzinfo is None:
                    from_dt = from_dt.replace(tzinfo=timezone.utc)
                params['timeMin'] = from_dt.isoformat()
            if date_range.to_date:
                # Ensure timezone info is present for API
                to_dt = date_range.to_date.replace(hour=23, minute=59, second=59, microsecond=0)
                if to_dt.tzinfo is None:
                    to_dt = to_dt.replace(tzinfo=timezone.utc)
                params['timeMax'] = to_dt.isoformat()
        
        # Fetch events from API
        events_result = service.events().list(**params).execute()
        all_events = events_result.get('items', [])
        
        logger.info(f"Found {len(all_events)} events from API")
        
        # Apply additional client-side filtering if needed
        if date_range:
            filtered_events = date_range.filter_events(all_events)
            logger.info(f"Filtered to {len(filtered_events)} events in date range")
            events = filtered_events
        else:
            events = all_events
        
        # Generate new-format filename with date range
        backup_filename = generate_backup_filename(
            user_email=user_email,
            date_range=date_range,
            operation='backup'
        )
        
        # Handle custom output directory
        if backup_dir or organize_by_user:
            from calwash.auth import get_output_directory
            output_path = get_output_directory(backup_dir, user_email, organize_by_user)
            backup_filepath = output_path / backup_filename
        else:
            backup_filepath = backup_filename
        
        # Create backup with metadata
        backup_data = create_backup_metadata(
            events=events,
            user_email=user_email,
            date_range=date_range,
            operation='backup',
            version=_get_version()
        )
        
        with open(backup_filepath, 'w', encoding='utf-8') as backup_file:
            json.dump(backup_data, backup_file, indent=2)
        logger.info(f"Backup saved to {backup_filepath}")
        
        return events, str(backup_filepath)
        
    except Exception as e:
        logger.error(f"Failed to fetch and backup events: {e}")
        raise


def clean_event_data(events, redaction_level=RedactionLevel.MEDIUM):
    """Clean sensitive information from events - delegates to calendar_cleaner implementation"""
    return clean_events_impl(events, redaction_level)


def generate_clean_report(changes, user_email: str, report_dir: str = None, 
                         organize_by_user: bool = False):
    """Generate a detailed report of cleaning changes with user identification"""
    report = {
        'timestamp': datetime.now().isoformat(),
        'user_email': user_email,
        'total_events_to_modify': len(changes),
        'changes': changes
    }
    
    # Create user-identified report filename
    report_filename = create_user_filename(
        user_email=user_email,
        file_type='dry_run_preview',
        output_dir=report_dir,
        organize_by_user=organize_by_user
    )
    
    # Save to file
    with open(report_filename, 'w') as f:
        json.dump(report, f, indent=2)
    
    # Print summary to console
    logger.info("\n" + "="*60)
    logger.info("CLEANING PREVIEW")
    logger.info("="*60)
    logger.info(f"User: {user_email}")
    logger.info(f"Total events that would be modified: {len(changes)}")
    
    # Show first few changes as examples
    for i, change in enumerate(changes[:5]):
        logger.info(f"\nEvent {i+1}:")
        logger.info(f"  Date: {change['event_date']}")
        logger.info(f"  Event ID: {change['event_id']}")
        for mod in change['modifications']:
            logger.info(f"  {mod['field'].capitalize()}:")
            logger.info(f"    Original: {mod['original']}")
            logger.info(f"    Would change to: {mod['cleaned']}")
    
    if len(changes) > 5:
        logger.info(f"\n... and {len(changes) - 5} more events")
    
    logger.info(f"\nFull preview saved to: {report_filename}")
    
    return str(report_filename)


def update_calendar_events(service, cleaned_events, changes, user_email: str,
                          dry_run=False, report_dir: str = None, 
                          organize_by_user: bool = False):
    """Update calendar events with cleaned data
    
    Args:
        service: Google Calendar service object
        cleaned_events: List of cleaned events
        changes: List of changes made
        user_email: Authenticated user's email address
        dry_run: Whether to run in dry-run mode
        report_dir: Custom report directory (optional)
        organize_by_user: Create user-specific subdirectories
    """
    if dry_run:
        logger.info("\n[DRY RUN MODE] No changes will be made to your calendar")
        report_file = generate_clean_report(changes, user_email, report_dir, organize_by_user)
        logger.info(f"\nDry-run report saved to: {report_file}")
        logger.info("\nTo apply these changes, run: calendar_manager.py clean")
        return report_file
    else:
        logger.info("\nUpdating calendar events...")
        updated_count = 0
        failed_count = 0
        
        # Only update events that have changes
        events_to_update = {change['event_id']: change for change in changes}
        
        for event in cleaned_events:
            if event['id'] in events_to_update:
                try:
                    service.events().update(
                        calendarId='primary', 
                        eventId=event['id'], 
                        body=event
                    ).execute()
                    updated_count += 1
                    if updated_count % 10 == 0:
                        logger.info(f"Updated {updated_count} events...")
                except Exception as e:
                    logger.error(f"Failed to update event {event['id']}: {e}")
                    failed_count += 1
        
        logger.info(f"\n" + "="*60)
        logger.info("CLEANING COMPLETE")
        logger.info("="*60)
        logger.info(f"Successfully updated: {updated_count} events")
        if failed_count > 0:
            logger.warning(f"Failed to update: {failed_count} events")


# ============================================================================
# RESTORE FUNCTIONS
# ============================================================================

def list_backup_files(backup_dir: str = None):
    """List all available backup files
    
    Args:
        backup_dir: Directory to search for backup files (optional)
    
    Returns:
        list: Sorted list of backup file paths (newest first)
    """
    # Support both old and new naming patterns
    patterns = [
        'calendar_backup_*.json',  # Old pattern: calendar_backup_20240101_120000.json
        'calendar_backup_*_at_*.json'  # New pattern: calendar_backup_user_at_domain_com_20240101_120000.json
    ]
    
    backup_files = []
    search_dir = Path(backup_dir) if backup_dir else Path.cwd()
    
    for pattern in patterns:
        backup_files.extend(glob.glob(str(search_dir / pattern)))
    
    # Remove duplicates and sort by modification time (newest first)
    backup_files = list(set(backup_files))
    backup_files.sort(key=lambda x: os.path.getmtime(x), reverse=True)
    
    return backup_files


def select_backup_file(backup_files, latest=False):
    """Select which backup file to restore from"""
    if not backup_files:
        logger.error("No backup files found!")
        logger.error("Backup files should match patterns:")
        logger.error("  - calendar_backup_*.json (old format)")
        logger.error("  - calendar_backup_*_at_*.json (new multi-account format)")
        return None
    
    if latest or len(backup_files) == 1:
        selected = backup_files[0]
        logger.info(f"Using backup file: {selected}")
        return selected
    
    logger.info("\nAvailable backup files:")
    for i, file in enumerate(backup_files, 1):
        size = os.path.getsize(file) / 1024  # Convert to KB
        mtime = datetime.fromtimestamp(os.path.getmtime(file))
        logger.info(f"{i}. {file} ({size:.1f} KB, created {mtime.strftime('%Y-%m-%d %H:%M:%S')})")
    
    while True:
        try:
            choice = input(f"\nSelect backup to restore from (1-{len(backup_files)}) or 'q' to quit: ")
            if choice.lower() == 'q':
                logger.info("Restore cancelled")
                return None
            index = int(choice) - 1
            if 0 <= index < len(backup_files):
                return backup_files[index]
            else:
                logger.error(f"Please enter a number between 1 and {len(backup_files)}")
        except ValueError:
            logger.error("Please enter a valid number or 'q' to quit")
        except KeyboardInterrupt:
            logger.info("\nRestore cancelled")
            return None


# Note: load_backup function removed - now using load_backup_file from date_utils


def restore_events(service, events, dry_run=False, date_range=None):
    """Restore events to calendar"""
    if dry_run:
        logger.info("\n" + "="*60)
        logger.info("RESTORE PREVIEW - No changes will be made")
        logger.info("="*60)
        logger.info(f"Would restore {len(events)} events to calendar")
        
        # Show preview of first few events
        for i, event in enumerate(events[:5]):
            logger.info(f"\nEvent {i+1}:")
            logger.info(f"  Summary: {event.get('summary', 'No title')}")
            logger.info(f"  Date: {event.get('start', {}).get('dateTime', event.get('start', {}).get('date', 'Unknown'))}")
            if 'description' in event:
                desc_preview = event['description'][:100] + '...' if len(event['description']) > 100 else event['description']
                logger.info(f"  Description: {desc_preview}")
        
        if len(events) > 5:
            logger.info(f"\n... and {len(events) - 5} more events")
        
        logger.info("\nTo actually restore, run: calendar_manager.py restore")
        return
    
    logger.info("\nRestoring events to calendar...")
    restored_count = 0
    failed_count = 0
    
    for event in events:
        try:
            service.events().update(
                calendarId='primary',
                eventId=event['id'],
                body=event
            ).execute()
            restored_count += 1
            
            if restored_count % 10 == 0:
                logger.info(f"Restored {restored_count} events...")
                
        except Exception as e:
            logger.error(f"Failed to restore event {event.get('id', 'unknown')}: {e}")
            failed_count += 1
    
    logger.info("\n" + "="*60)
    logger.info("RESTORE COMPLETE")
    logger.info("="*60)
    logger.info(f"Successfully restored: {restored_count} events")
    if failed_count > 0:
        logger.warning(f"Failed to restore: {failed_count} events")
    if date_range:
        logger.info(f"Events were filtered by date range: {date_range}")


# ============================================================================
# EVENT SCOPE FILTERING
# ============================================================================

def _parse_event_start(event: dict) -> datetime | None:
    """Return the event start as a timezone-aware datetime, or None."""
    start = event.get('start', {})
    start_str = start.get('dateTime') or start.get('date')
    if not start_str:
        return None
    try:
        if 'T' in start_str:
            dt = datetime.fromisoformat(start_str.replace('Z', '+00:00'))
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return dt
        else:
            # All-day event — treat midnight UTC
            d = date.fromisoformat(start_str)
            return datetime(d.year, d.month, d.day, tzinfo=timezone.utc)
    except (ValueError, AttributeError):
        return None


def filter_events_by_scope(
    events: list[dict],
    skip_future: bool = False,
    skip_organized: bool = False,
) -> tuple[list[dict], int, int]:
    """Filter events based on future/organizer scope flags.

    Returns:
        (kept_events, skipped_future_count, skipped_organized_count)
    """
    now = datetime.now(timezone.utc)
    kept = []
    skipped_future = 0
    skipped_organized = 0

    for event in events:
        dt = _parse_event_start(event)
        is_future = (dt is not None) and (dt > now)
        is_organizer = event.get('organizer', {}).get('self', False)

        if skip_future and is_future:
            skipped_future += 1
            continue
        if skip_organized and is_organizer:
            skipped_organized += 1
            continue

        kept.append(event)

    return kept, skipped_future, skipped_organized


def _warn_future_organized(events: list[dict], changes: list[dict]) -> int:
    """Warn about future events where user is organizer and will be modified.

    Returns the count of such events.
    """
    now = datetime.now(timezone.utc)
    changed_ids = {c['event_id'] for c in changes}
    warned = 0

    for event in events:
        if event.get('id') not in changed_ids:
            continue
        if not event.get('organizer', {}).get('self', False):
            continue
        dt = _parse_event_start(event)
        if dt is None or dt <= now:
            continue
        # Future + organizer + has changes
        warned += 1

    if warned:
        logger.warning(
            f"\n  WARNING: {warned} future event(s) where you are the organizer will be modified."
        )
        logger.warning(
            "  Edits to organized events are visible to all participants."
        )
        logger.warning(
            "  Use --skip-future or --skip-organized to exclude these events.\n"
        )

    return warned


# ============================================================================
# MAIN COMMAND HANDLERS
# ============================================================================

def handle_clean(args):
    """Handle the clean command with date range support"""
    account = getattr(args, 'account', None) or 'default'
    provider_name = getattr(args, 'provider', 'google')
    backup_dir = getattr(args, 'backup_dir', None) or getattr(args, 'output_dir', None) or get_env_backup_dir()
    organize_by_user = getattr(args, 'organize_by_user', False) or get_env_organize_by_user()

    # Parse date range arguments
    date_range = create_date_range_from_args(args)
    if date_range:
        logger.info(f"Date filtering enabled: {date_range}")

    # Get redaction level
    redaction_level_str = getattr(args, 'redaction_level', 'medium')
    redaction_level = RedactionLevel.from_string(redaction_level_str)

    if not redaction_level.is_implemented():
        logger.error(f"Redaction level '{redaction_level.value}' is not yet implemented")
        logger.info("Available levels: coarse, medium")
        return

    if args.dry_run:
        logger.info("Starting in DRY RUN mode - no changes will be made to your calendar")
    else:
        logger.warning("Starting in LIVE mode - your calendar will be updated")
        response = input("Are you sure you want to continue? (yes/no): ")
        if response.lower() not in ['yes', 'y', 'true', '1']:
            logger.info("Operation cancelled")
            return

    # Authenticate via provider
    try:
        provider = get_provider(provider_name)
        user_email = provider.authenticate(account)
        logger.info(f"Authenticated as: {user_email} (account: {account}, provider: {provider.provider_name})")
    except Exception as e:
        logger.error(f"Failed to authenticate: {e}")
        return

    # Fetch events via provider
    try:
        events = provider.list_events(date_range=date_range)
    except Exception as e:
        logger.error(f"Failed to fetch events: {e}")
        return

    if not events:
        logger.warning("No events found to process")
        return

    # Apply scope filters (--skip-future, --skip-organized)
    skip_future = getattr(args, 'skip_future', False)
    skip_organized = getattr(args, 'skip_organized', False)
    if skip_future or skip_organized:
        events, n_future, n_organized = filter_events_by_scope(
            events, skip_future=skip_future, skip_organized=skip_organized
        )
        if n_future:
            logger.info(f"Skipped {n_future} future event(s) (--skip-future)")
        if n_organized:
            logger.info(f"Skipped {n_organized} event(s) where you are the organizer (--skip-organized)")
        if not events:
            logger.warning("No events remain after scope filtering")
            return

    # Create backup
    backup_filename = generate_backup_filename(
        user_email=user_email, date_range=date_range, operation='backup'
    )
    if backup_dir or organize_by_user:
        output_path = get_output_directory(backup_dir, user_email, organize_by_user)
        backup_filepath = output_path / backup_filename
    else:
        backup_filepath = backup_filename

    backup_data = create_backup_metadata(
        events=events, user_email=user_email, date_range=date_range,
        operation='backup', version=_get_version()
    )
    with open(backup_filepath, 'w', encoding='utf-8') as f:
        json.dump(backup_data, f, indent=2)
    logger.info(f"Backup saved to {backup_filepath}")

    # Clean events
    logger.info(f"Using redaction level: {redaction_level.value} - {redaction_level.get_description()}")
    cleaned_events, changes = clean_event_data(events, redaction_level)

    # AI second pass (opt-in)
    if getattr(args, 'ai', False):
        from calwash.ai import (
            check_ollama_available, classify_events_batch,
            merge_ai_findings, parse_categories,
        )
        model = getattr(args, 'ai_model', 'llama3.2')
        ok, err = check_ollama_available(model)
        if not ok:
            logger.warning(f"AI detection skipped: {err}")
        else:
            categories = parse_categories(getattr(args, 'ai_categories', None))
            batch_size = getattr(args, 'ai_batch_size', 5)
            ai_results = classify_events_batch(events, categories, model, batch_size)
            cleaned_events, changes = merge_ai_findings(
                ai_results, changes, cleaned_events, events
            )

    if not changes:
        logger.info("No events require cleaning - your calendar is already private")
        return

    # Warn about future events where user is organizer (edits affect all participants)
    if args.dry_run and not skip_future and not skip_organized:
        _warn_future_organized(events, changes)

    # Update or dry-run report
    report_dir = getattr(args, 'report_dir', None) or backup_dir
    if args.dry_run:
        logger.info("\n[DRY RUN MODE] No changes will be made to your calendar")
        report_file = generate_clean_report(changes, user_email, report_dir, organize_by_user)
        logger.info(f"\nDry-run report saved to: {report_file}")
        logger.info("\nTo apply these changes, run without --dry-run")
    else:
        logger.info("\nUpdating calendar events...")
        updated, failed = provider.update_events_batch(cleaned_events, changes)
        logger.info(f"\n" + "=" * 60)
        logger.info("CLEANING COMPLETE")
        logger.info("=" * 60)
        logger.info(f"Successfully updated: {updated} events")
        if failed > 0:
            logger.warning(f"Failed to update: {failed} events")


def handle_restore(args):
    """Handle the restore command with date range support"""
    account = getattr(args, 'account', None) or 'default'
    provider_name = getattr(args, 'provider', 'google')
    backup_dir = getattr(args, 'backup_dir', None) or getattr(args, 'output_dir', None) or get_env_backup_dir()
    
    # Parse date range arguments
    date_range = create_date_range_from_args(args)
    if date_range:
        logger.info(f"Date filtering enabled for restoration: {date_range}")
    
    if args.dry_run:
        logger.info("Starting in DRY RUN mode - no changes will be made")
    else:
        logger.warning("Starting in RESTORE mode - this will restore your calendar events")
        logger.warning("Make sure you want to restore from backup!")
        response = input("Continue with restore? (yes/no): ")
        if response.lower() != 'yes':
            logger.info("Restore cancelled")
            return
    
    # Select backup file
    if args.file:
        if not os.path.exists(args.file):
            logger.error(f"Backup file not found: {args.file}")
            return
        backup_file = args.file
    else:
        backup_files = list_backup_files(backup_dir)
        backup_file = select_backup_file(backup_files, latest=args.latest)
        if not backup_file:
            return
    
    # Load backup with date filtering
    events, metadata = load_backup_file(backup_file)
    if not events:
        return
    
    # Log backup information
    if metadata:
        logger.info(f"Backup metadata: {metadata.get('total_events', len(events))} events, "
                   f"created {metadata.get('backup_timestamp', 'unknown time')}")
    
    # Apply date range filtering if requested
    if date_range:
        original_count = len(events)
        events = date_range.filter_events(events)
        logger.info(f"Filtered from {original_count} to {len(events)} events for restoration")
    
    # Authenticate and restore
    try:
        provider = get_provider(provider_name)
        user_email = provider.authenticate(account)
        logger.info(f"Authenticated as: {user_email}")

        if not args.dry_run and date_range:
            msg = f"This will restore {len(events)} events (filtered by date range: {date_range})"
            response = input(f"\n{msg}. Continue? (yes/no): ")
            if response.lower() not in ['yes', 'y']:
                logger.info("Restoration cancelled")
                return

        provider.restore_events(events, dry_run=args.dry_run, date_range=date_range)
    except Exception as e:
        logger.error(f"Failed: {e}")
        return


def handle_login(args):
    """Handle the login command — authenticate with a calendar provider."""
    account = getattr(args, 'account', None) or 'default'
    provider_name = getattr(args, 'provider', 'google')

    print(f"\nLogging in to account '{account}' ({provider_name})...")
    try:
        provider = get_provider(provider_name)
        user_email = provider.authenticate(account)
        print(f"\nAuthenticated as: {user_email}")
        print(f"Account '{account}' saved to: {get_account_directory(account)}")
        print(f"\nYou can now run:")
        if account == 'default':
            print(f"  calwash clean --dry-run")
        else:
            print(f"  calwash clean --dry-run --account {account}")
    except Exception as e:
        logger.error(f"Login failed: {e}")


def handle_accounts(args):
    """Handle the accounts command — list all saved accounts."""
    accounts = list_accounts()

    if not accounts:
        print("\nNo accounts found.")
        print("Run 'calwash login' to authenticate.\n")
        return

    print(f"\n  {'Account':<20s} {'Email'}")
    print(f"  {'-'*20} {'-'*30}")
    for name, email in accounts:
        print(f"  {name:<20s} {email}")
    print(f"\n  {len(accounts)} account(s) stored in {CALWASH_HOME / 'accounts'}")
    print()


def handle_list_backups(args):
    """Handle the list-backups command"""
    backup_dir = getattr(args, 'backup_dir', None) or getattr(args, 'output_dir', None) or get_env_backup_dir()
    backup_files = list_backup_files(backup_dir)
    
    if not backup_files:
        logger.info("No backup files found")
        return
    
    logger.info("\n" + "="*60)
    logger.info("AVAILABLE BACKUPS")
    logger.info("="*60)
    
    total_size = 0
    for file in backup_files:
        size = os.path.getsize(file)
        total_size += size
        mtime = datetime.fromtimestamp(os.path.getmtime(file))
        
        # Load file to get event count
        try:
            with open(file, 'r') as f:
                events = json.load(f)
                event_count = len(events)
        except (json.JSONDecodeError, FileNotFoundError, PermissionError) as e:
            logger.warning(f"Could not analyze backup file {file}: {e}")
            event_count = "Unknown"
        except Exception as e:
            logger.error(f"Unexpected error analyzing backup file {file}: {e}")
            event_count = "Unknown"
        
        logger.info(f"\n{file}")
        logger.info(f"  Created: {mtime.strftime('%Y-%m-%d %H:%M:%S')}")
        logger.info(f"  Size: {size/1024:.1f} KB")
        logger.info(f"  Events: {event_count}")
    
    logger.info(f"\nTotal backups: {len(backup_files)}")
    logger.info(f"Total size: {total_size/1024:.1f} KB")


# ============================================================================
# MAIN ENTRY POINT
# ============================================================================

def main():
    valid_shortcuts = get_valid_date_shortcuts()
    shortcuts_help = ', '.join(valid_shortcuts[:8]) + ', etc.'
    
    parser = argparse.ArgumentParser(
        prog='calwash',
        description='Google Calendar Manager - Clean or Restore your calendar events with date range support',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=f'''
Examples:
  %(prog)s clean --dry-run                           # Preview cleaning changes
  %(prog)s clean --dry-run --account work             # Clean using work account
  %(prog)s --output-dir ~/backups clean              # Save to custom directory
  %(prog)s --organize-by-user clean                  # Organize files by user
  %(prog)s clean --from-date 2025-01-01 --to-date 2025-01-31  # Clean only January events
  %(prog)s clean --days-back 30 --redaction-level coarse     # Clean last 30 days with coarse redaction
  %(prog)s restore --dry-run                         # Preview restore
  %(prog)s restore --dry-run --account work           # Restore using work account
  %(prog)s restore --latest --backup-dir ~/backups   # Restore from custom backup dir
  %(prog)s restore --file backup.json --year 2025    # Restore only 2025 events from backup
  %(prog)s list-backups                              # Show all available backups
  %(prog)s login                                     # Authenticate with Google
  %(prog)s login --account work                      # Add a second Google account
  %(prog)s accounts                                  # List all saved accounts
  %(prog)s ai setup                                  # Set up AI detection (ollama + model)
  %(prog)s ai models                                 # List recommended models
  %(prog)s clean --dry-run --ai                      # Clean with AI second pass
  %(prog)s clean --dry-run --ai --ai-model phi4-mini # Use a specific model
  %(prog)s clean --dry-run --skip-future             # Only clean past events
  %(prog)s clean --dry-run --skip-organized          # Only clean events where you are attendee

Date Shortcuts:
  {shortcuts_help}
        '''
    )
    
    # Global arguments for all commands
    parser.add_argument('--version', action='version', version=f'%(prog)s {__version__}')
    parser.add_argument('--account', type=str, default=None,
                       help='Account to use (default: default). Set up with: calwash login')
    parser.add_argument('--provider', type=str, default='google',
                       choices=['google', 'apple'],
                       help='Calendar provider (default: google)')
    parser.add_argument('--output-dir', type=str,
                       help='Directory to save output files (default: current directory)')
    parser.add_argument('--organize-by-user', action='store_true',
                       help='Create user-specific subdirectories for output files')
    
    subparsers = parser.add_subparsers(dest='command', help='Command to execute')
    
    # Clean command
    clean_parser = subparsers.add_parser('clean', help='Clean sensitive information from calendar')
    clean_parser.add_argument('--dry-run', action='store_true', 
                             help='Preview changes without modifying calendar')
    clean_parser.add_argument('--verbose', action='store_true',
                             help='Show detailed output')
    clean_parser.add_argument('--backup-dir', type=str,
                             help='Directory to save backup files (overrides --output-dir for backups)')
    clean_parser.add_argument('--report-dir', type=str, 
                             help='Directory to save reports (overrides --output-dir for reports)')
    clean_parser.add_argument('--redaction-level', type=str,
                             choices=['coarse', 'medium', 'fine'],
                             default='medium',
                             help='Level of redaction: coarse (complete redaction), medium (pattern replacement, default)')
    
    # Date range arguments for clean command
    clean_date_group = clean_parser.add_argument_group('Date Filtering Options')
    clean_date_group.add_argument('--from-date', type=str,
                                 help='Start date for filtering events (YYYY-MM-DD or shortcut like "today", "last-month")')
    clean_date_group.add_argument('--to-date', type=str,
                                 help='End date for filtering events (YYYY-MM-DD or shortcut like "tomorrow", "next-week")')
    clean_date_group.add_argument('--days-back', type=int,
                                 help='Clean events from N days ago to today')
    clean_date_group.add_argument('--days-forward', type=int,
                                 help='Clean events from today to N days in the future')
    clean_date_group.add_argument('--year', type=str,
                                 help='Clean all events in specified year (YYYY)')
    clean_date_group.add_argument('--month', type=str,
                                 help='Clean all events in specified month (YYYY-MM)')

    # Event scope arguments for clean command
    scope_group = clean_parser.add_argument_group('Event Scope Options')
    scope_group.add_argument('--skip-future', action='store_true',
                             help='Skip events that have not started yet')
    scope_group.add_argument('--skip-organized', action='store_true',
                             help='Skip events where you are the organizer (only clean attendee events)')

    # AI detection arguments for clean command
    ai_group = clean_parser.add_argument_group('AI Detection Options (requires ollama)')
    ai_group.add_argument('--ai', action='store_true',
                          help='Enable LLM-based second-pass detection for sensitive content')
    ai_group.add_argument('--ai-model', type=str, default='llama3.2',
                          help='Ollama model to use (default: llama3.2)')
    ai_group.add_argument('--ai-categories', type=str, default=None,
                          help='Comma-separated categories: medical,legal,financial,substance_use,career,relationship,political,religious')
    ai_group.add_argument('--ai-batch-size', type=int, default=5,
                          help='Events per LLM batch (default: 5)')

    # Restore command
    restore_parser = subparsers.add_parser('restore', help='Restore calendar from backup')
    restore_parser.add_argument('--dry-run', action='store_true',
                               help='Preview restore without making changes')
    restore_parser.add_argument('--file', type=str,
                               help='Specific backup file to restore from')
    restore_parser.add_argument('--latest', action='store_true',
                               help='Automatically use the most recent backup')
    restore_parser.add_argument('--backup-dir', type=str,
                               help='Directory to search for backup files')
    
    # Date range arguments for restore command
    restore_date_group = restore_parser.add_argument_group('Date Filtering Options')
    restore_date_group.add_argument('--from-date', type=str,
                                   help='Start date for filtering events to restore (YYYY-MM-DD or shortcut)')
    restore_date_group.add_argument('--to-date', type=str,
                                   help='End date for filtering events to restore (YYYY-MM-DD or shortcut)')
    restore_date_group.add_argument('--days-back', type=int,
                                   help='Restore events from N days ago to today only')
    restore_date_group.add_argument('--days-forward', type=int,
                                   help='Restore events from today to N days in the future only')
    restore_date_group.add_argument('--year', type=str,
                                   help='Restore only events from specified year (YYYY)')
    restore_date_group.add_argument('--month', type=str,
                                   help='Restore only events from specified month (YYYY-MM)')
    
    # List backups command
    list_parser = subparsers.add_parser('list-backups', help='List all available backup files')

    # Account management commands
    login_parser = subparsers.add_parser('login', help='Authenticate with Google')
    login_parser.add_argument('--account', type=str, default=None,
                             help='Account name (default: default)')

    accounts_parser = subparsers.add_parser('accounts', help='List all saved accounts')

    # AI management command
    ai_parser = subparsers.add_parser('ai', help='Manage AI detection (ollama setup, models)')
    ai_subparsers = ai_parser.add_subparsers(dest='ai_command', help='AI management command')

    ai_setup_parser = ai_subparsers.add_parser('setup', help='Install ollama and download a model')
    ai_setup_parser.add_argument('--model', type=str, default=None,
                                help='Model to install (interactive selection if omitted)')

    ai_subparsers.add_parser('status', help='Show AI detection readiness')
    ai_subparsers.add_parser('models', help='List recommended models with sizes')

    args = parser.parse_args()
    
    # Set verbose logging if requested
    if hasattr(args, 'verbose') and args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)
    
    # Handle commands
    try:
        if args.command == 'clean':
            handle_clean(args)
        elif args.command == 'restore':
            handle_restore(args)
        elif args.command == 'list-backups':
            handle_list_backups(args)
        elif args.command == 'login':
            handle_login(args)
        elif args.command == 'accounts':
            handle_accounts(args)
        elif args.command == 'ai':
            from calwash.ai import handle_ai_setup, handle_ai_status, handle_ai_models
            if args.ai_command == 'setup':
                handle_ai_setup(model=getattr(args, 'model', None))
            elif args.ai_command == 'status':
                handle_ai_status()
            elif args.ai_command == 'models':
                handle_ai_models()
            else:
                ai_parser.print_help()
        else:
            parser.print_help()
            sys.exit(1)
    except DateParsingError as e:
        logger.error(f"Date parsing error: {e}")
        sys.exit(1)


if __name__ == '__main__':
    main()