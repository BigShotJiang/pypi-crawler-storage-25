"""
Centralized regex patterns for cleaning sensitive information from calendar events.

This module combines pattern definitions, validation-aware patterns, and the
cleaning interface used across the application.
"""

import re
import threading
import logging
from typing import List, Tuple, Optional, Callable

from .validators import (
    is_valid_credit_card,
    is_valid_ssn,
    should_whitelist,
    is_timestamp_pattern,
    luhn_checksum
)


# =============================================================================
# SensitivePattern class and validated pattern definitions
# =============================================================================

class SensitivePattern:
    """Represents a pattern with validation logic."""

    def __init__(self, pattern: str, replacement: str, validator: Optional[Callable] = None,
                 description: str = "", case_sensitive: bool = False):
        self.pattern = pattern
        self.replacement = replacement
        self.validator = validator
        self.description = description
        self.case_sensitive = case_sensitive
        self.regex = re.compile(pattern, 0 if case_sensitive else re.IGNORECASE)

    def find_and_validate(self, text: str, context: str = "") -> List[Tuple[str, int, int]]:
        """
        Find matches and validate them.

        Returns:
            List of (match_text, start_pos, end_pos) for valid matches
        """
        matches = []
        for match in self.regex.finditer(text):
            match_text = match.group()

            # Check whitelist first
            if should_whitelist(match_text, context):
                continue

            # Apply specific validator if provided
            if self.validator and not self.validator(match_text):
                continue

            matches.append((match_text, match.start(), match.end()))

        return matches

    def clean_text(self, text: str, context: str = "") -> str:
        """Clean text by replacing validated matches."""
        result = text

        # Get matches in reverse order to maintain positions
        matches = self.find_and_validate(text, context)
        matches.sort(key=lambda x: x[1], reverse=True)

        for match_text, start, end in matches:
            result = result[:start] + self.replacement + result[end:]

        return result


def get_ssn_patterns() -> List[SensitivePattern]:
    """Social Security Number patterns with validation."""

    def is_permissive_ssn(ssn_text: str) -> bool:
        """More permissive SSN validation for clear formats."""
        digits = re.sub(r'\D', '', ssn_text)
        if len(digits) != 9:
            return False
        if all(d == '0' for d in digits) or all(d == digits[0] for d in digits):
            return False
        return True

    return [
        SensitivePattern(
            pattern=r'\b\d{3}-\d{2}-\d{4}\b',
            replacement='[SSN REMOVED]',
            validator=is_permissive_ssn,
            description='SSN with dashes (XXX-XX-XXXX)'
        ),
        SensitivePattern(
            pattern=r'\b\d{3}\s\d{2}\s\d{4}\b',
            replacement='[SSN REMOVED]',
            validator=is_permissive_ssn,
            description='SSN with spaces (XXX XX XXXX)'
        ),
        SensitivePattern(
            pattern=r'\b\d{9}\b',
            replacement='[SSN REMOVED]',
            validator=lambda x: (is_valid_ssn(x) and
                               not should_whitelist(x) and
                               not is_timestamp_pattern(x)),
            description='SSN without separators (XXXXXXXXX)'
        )
    ]


def get_credit_card_patterns() -> List[SensitivePattern]:
    """Credit card patterns with Luhn validation."""
    return [
        SensitivePattern(
            pattern=r'\b4[0-9]{3}[\s-]?[0-9]{4}[\s-]?[0-9]{4}[\s-]?[0-9]{1,4}\b',
            replacement='[CARD REMOVED]',
            validator=is_valid_credit_card,
            description='Visa card format'
        ),
        SensitivePattern(
            pattern=r'\b5[1-5][0-9]{2}[\s-]?[0-9]{4}[\s-]?[0-9]{4}[\s-]?[0-9]{4}\b',
            replacement='[CARD REMOVED]',
            validator=is_valid_credit_card,
            description='MasterCard format'
        ),
        SensitivePattern(
            pattern=r'\b3[47][0-9]{2}[\s-]?[0-9]{6}[\s-]?[0-9]{5}\b',
            replacement='[CARD REMOVED]',
            validator=is_valid_credit_card,
            description='American Express format'
        ),
        SensitivePattern(
            pattern=r'\b(?:6011|65[0-9]{2})[\s-]?[0-9]{4}[\s-]?[0-9]{4}[\s-]?[0-9]{4}\b',
            replacement='[CARD REMOVED]',
            validator=is_valid_credit_card,
            description='Discover card format'
        ),
        SensitivePattern(
            pattern=r'\b[0-9]{4}[\s-]?[0-9]{4}[\s-]?[0-9]{4}[\s-]?[0-9]{3,4}\b',
            replacement='[CARD REMOVED]',
            validator=is_valid_credit_card,
            description='Generic credit card format'
        )
    ]


def get_phone_patterns() -> List[SensitivePattern]:
    """Phone number patterns with context validation."""

    def is_likely_phone(text: str) -> bool:
        """Check if number is likely a phone number (not timestamp/ID)."""
        clean = re.sub(r'[\s\-\(\)\+\.]', '', text)

        if len(clean) > 15:
            return False

        if is_timestamp_pattern(clean):
            return False

        if should_whitelist(text, ""):
            return False

        if len(clean) == 10 or (len(clean) == 11 and clean.startswith('1')):
            return True

        return len(clean) >= 7

    return [
        SensitivePattern(
            pattern=r'\+\d{1,3}[\s.-]?\(?\d{1,4}\)?[\s.-]?\d{1,4}[\s.-]?\d{1,9}',
            replacement='[PHONE REMOVED]',
            validator=is_likely_phone,
            description='International phone format'
        ),
        SensitivePattern(
            pattern=r'\b1[-.\s]?\d{3}[-.\s]?\d{3}[-.\s]?\d{4}\b',
            replacement='[PHONE REMOVED]',
            validator=is_likely_phone,
            description='US phone with country code'
        ),
        SensitivePattern(
            pattern=r'\(\d{3}\)\s?\d{3}[-.\s]?\d{4}\b',
            replacement='[PHONE REMOVED]',
            validator=is_likely_phone,
            description='Phone with parentheses format'
        ),
        SensitivePattern(
            pattern=r'\b\d{3}[-.\s]\d{3}[-.\s]\d{4}\b',
            replacement='[PHONE REMOVED]',
            validator=lambda x: not should_whitelist(x, "") and not is_timestamp_pattern(re.sub(r'[\s\-\.]', '', x)),
            description='Standard US phone format'
        ),
        SensitivePattern(
            pattern=r'\b\d{3}[-.\s]?\d{3}[-.\s]?\d{4}\s*(?:ext\.?|x|extension)\s*\d+',
            replacement='[PHONE REMOVED]',
            validator=is_likely_phone,
            description='Phone with extension'
        ),
        SensitivePattern(
            pattern=r'\b\d{10}\b',
            replacement='[PHONE REMOVED]',
            validator=lambda x: is_likely_phone(x) and not should_whitelist(x, ""),
            description='10-digit phone without separators'
        )
    ]


def get_bank_account_patterns() -> List[SensitivePattern]:
    """Bank account number patterns with context validation."""
    return [
        SensitivePattern(
            pattern=r'\b\d{8,12}\b',
            replacement='[ACCOUNT REMOVED]',
            validator=lambda x: not should_whitelist(x) and not is_timestamp_pattern(x),
            description='Potential bank account number'
        ),
        SensitivePattern(
            pattern=r'\b\d{9}\b',
            replacement='[ROUTING REMOVED]',
            validator=lambda x: (not should_whitelist(x) and
                               not is_timestamp_pattern(x) and
                               not is_valid_ssn(x)),
            description='Bank routing number'
        )
    ]


def get_driver_license_patterns() -> List[SensitivePattern]:
    """Driver license patterns for common US state formats."""
    return []


def get_email_patterns() -> List[SensitivePattern]:
    """Email patterns."""
    return [
        SensitivePattern(
            pattern=r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
            replacement='[EMAIL REMOVED]',
            description='Email address'
        )
    ]


def get_url_patterns() -> List[SensitivePattern]:
    """URL patterns."""
    return [
        SensitivePattern(
            pattern=r'https?://[^\s]+',
            replacement='[URL REMOVED]',
            description='HTTP/HTTPS URLs'
        ),
        SensitivePattern(
            pattern=r'www\.[^\s]+',
            replacement='[URL REMOVED]',
            description='www URLs'
        )
    ]


def get_medical_patterns() -> List[SensitivePattern]:
    """Medical term patterns."""
    return [
        SensitivePattern(
            pattern=r'\b(?:doctor|dr\.?|physician|md|appointment|medical|health|hospital|clinic|surgery|procedure|prescription|medication|therapy|treatment|diagnosis|patient|checkup|exam|consultation|visit)\b',
            replacement='Private',
            description='Medical and health terms'
        )
    ]


def get_all_sensitive_patterns() -> List[SensitivePattern]:
    """Get all sensitive data patterns in order of specificity."""
    patterns = []
    patterns.extend(get_email_patterns())
    patterns.extend(get_url_patterns())
    patterns.extend(get_ssn_patterns())
    patterns.extend(get_credit_card_patterns())
    patterns.extend(get_phone_patterns())
    patterns.extend(get_bank_account_patterns())
    patterns.extend(get_driver_license_patterns())
    patterns.extend(get_medical_patterns())
    return patterns


def clean_text_with_validation(text: str, context: str = "") -> str:
    """
    Clean text using validated patterns.

    Args:
        text: Text to clean
        context: Additional context for validation

    Returns:
        Cleaned text with sensitive information removed
    """
    result = text
    patterns = get_all_sensitive_patterns()
    for pattern in patterns:
        result = pattern.clean_text(result, context)
    return result


# =============================================================================
# Legacy pattern definitions and cleaning interface
# =============================================================================

# Legacy pattern definitions for cleaning sensitive information
# DEPRECATED: Use get_validated_patterns() for new implementations
LEGACY_CLEANING_PATTERNS = [
    (r'(doctor|appointment|medical|health|hospital|clinic)', '[MEDICAL]'),
    (r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b', '[EMAIL REMOVED]'),
    (r'\b\d{3}-\d{2}-\d{4}\b', '[SSN REMOVED]'),
    (r'\+\d{1,3}[\s.-]?\(?\d{1,4}\)?[\s.-]?\d{1,4}[\s.-]?\d{1,4}[\s.-]?\d{0,4}', '[PHONE REMOVED]'),
    (r'\b\d{3}[-.\s]?\d{3}[-.\s]?\d{4}\s*(?:ext\.?|x)\s*\d+', '[PHONE REMOVED]'),
    (r'\b1[-.\s]?\d{3}[-.\s]?\d{3}[-.\s]?\d{4}\b', '[PHONE REMOVED]'),
    (r'\(\d{3}\)\s?\d{3}[-.\s]?\d{4}\b', '[PHONE REMOVED]'),
    (r'\b\d{3}[-.\s]\d{3}[-.\s]\d{4}\b', '[PHONE REMOVED]'),
    (r'\b\d{10}\b', '[PHONE REMOVED]'),
    (r'\b(?!(?:19|20)\d{2}\b)\d{8,}\b', '[ACCOUNT/ID REMOVED]'),
    (r'https?://[^\s]+', '[URL REMOVED]'),
]

# For backward compatibility
CLEANING_PATTERNS = LEGACY_CLEANING_PATTERNS

# Special replacement for medical terms
MEDICAL_REPLACEMENT = 'Private'

# Cache compiled patterns for performance
_COMPILED_PATTERNS = None
_PATTERN_LOCK = threading.Lock()


def get_validated_patterns() -> List[Tuple[str, str]]:
    """
    Get validated patterns that minimize false positives.

    Returns:
        List of (pattern, replacement) tuples with validation
    """
    try:
        patterns = []
        for sensitive_pattern in get_all_sensitive_patterns():
            patterns.append((sensitive_pattern.pattern, sensitive_pattern.replacement))
        return patterns
    except Exception:
        return LEGACY_CLEANING_PATTERNS


def get_patterns_for_cleaning():
    """
    Get patterns for the main cleaning functionality.
    Medical terms get replaced with 'Private' instead of '[MEDICAL]'.
    Patterns are compiled and cached for performance with thread safety.
    """
    global _COMPILED_PATTERNS

    if _COMPILED_PATTERNS is None:
        with _PATTERN_LOCK:
            if _COMPILED_PATTERNS is None:
                logger = logging.getLogger(__name__)
                try:
                    _COMPILED_PATTERNS = []
                    for pattern, replacement in CLEANING_PATTERNS:
                        try:
                            if replacement == '[MEDICAL]':
                                compiled = (re.compile(pattern, re.IGNORECASE), MEDICAL_REPLACEMENT)
                            else:
                                compiled = (re.compile(pattern, re.IGNORECASE), replacement)
                            _COMPILED_PATTERNS.append(compiled)
                        except re.error as e:
                            logger.warning(f"Failed to compile pattern '{pattern}': {e}")
                            continue
                except Exception as e:
                    logger.error(f"Error initializing patterns: {e}")
                    _COMPILED_PATTERNS = []

    return _COMPILED_PATTERNS


def get_patterns_for_testing():
    """
    Get patterns for testing.
    Uses the original replacements including '[MEDICAL]' for clarity in tests.
    """
    return CLEANING_PATTERNS.copy()


def get_validated_compiled_patterns():
    """
    Get validated patterns compiled for performance with thread safety.
    """
    global _COMPILED_PATTERNS

    if _COMPILED_PATTERNS is None:
        with _PATTERN_LOCK:
            if _COMPILED_PATTERNS is None:
                logger = logging.getLogger(__name__)
                try:
                    _COMPILED_PATTERNS = []
                    for sensitive_pattern in get_all_sensitive_patterns():
                        try:
                            replacement = (MEDICAL_REPLACEMENT
                                         if sensitive_pattern.replacement == 'Private'
                                         else sensitive_pattern.replacement)
                            compiled = (sensitive_pattern, replacement)
                            _COMPILED_PATTERNS.append(compiled)
                        except Exception as e:
                            logger.warning(f"Failed to compile pattern '{sensitive_pattern.pattern}': {e}")
                            continue
                except Exception as e:
                    logger.error(f"Error initializing validated patterns: {e}")
                    return get_patterns_for_cleaning()

    return _COMPILED_PATTERNS


def get_validated_patterns_for_cleaning():
    """
    Get validated patterns for the main cleaning functionality.

    Returns:
        List of compiled regex patterns with validation and appropriate replacements
        Format: [(compiled_regex, replacement), ...]
    """
    logger = logging.getLogger(__name__)
    try:
        validated_patterns = []
        for sensitive_pattern in get_all_sensitive_patterns():
            try:
                replacement = (MEDICAL_REPLACEMENT
                             if sensitive_pattern.replacement == 'Private'
                             else sensitive_pattern.replacement)
                validated_patterns.append((sensitive_pattern.regex, replacement))
            except Exception as e:
                logger.warning(f"Failed to process validated pattern '{sensitive_pattern.pattern}': {e}")
                continue
        return validated_patterns
    except Exception as e:
        logger.error(f"Error loading validated patterns: {e}")
        return get_patterns_for_cleaning()


def clean_text_validated(text: str, context: str = "") -> str:
    """
    Clean text using validated patterns to minimize false positives.

    Args:
        text: Text to clean
        context: Additional context for better validation decisions

    Returns:
        Cleaned text with sensitive information removed
    """
    try:
        return clean_text_with_validation(text, context)
    except Exception:
        patterns = get_patterns_for_cleaning()
        result = text
        for pattern_regex, replacement in patterns:
            result = pattern_regex.sub(replacement, result)
        return result
