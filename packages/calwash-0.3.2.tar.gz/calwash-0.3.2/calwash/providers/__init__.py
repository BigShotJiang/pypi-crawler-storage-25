"""Calendar provider factory for calwash."""

from .base import CalendarProvider


def get_provider(name: str = 'google') -> CalendarProvider:
    """Get a calendar provider by name.

    Args:
        name: Provider name ('google' or 'apple')

    Returns:
        CalendarProvider instance

    Raises:
        ValueError: If provider name is unknown
        ImportError: If provider dependencies are missing
    """
    if name == 'google':
        from .google import GoogleProvider
        return GoogleProvider()
    elif name == 'apple':
        from .apple import AppleProvider
        return AppleProvider()
    else:
        raise ValueError(
            f"Unknown provider: '{name}'. Available: google, apple"
        )
