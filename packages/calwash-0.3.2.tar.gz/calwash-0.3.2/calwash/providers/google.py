"""Google Calendar provider for calwash.

Implements the CalendarProvider interface using the Google Calendar API
with OAuth2 authentication.
"""

import json
import pickle
import logging
import time
from datetime import timezone
from pathlib import Path
from typing import Optional

from .base import CalendarProvider
from calwash.auth import (
    get_account_directory,
    get_account_token_path,
    _migrate_profiles_if_needed,
    CALWASH_HOME,
    AuthenticationError,
    UserEmailNotFoundError,
)

logger = logging.getLogger(__name__)


def _find_google_credentials() -> Path:
    """Find Google OAuth credentials.json using 2-tier lookup.

    1. ~/.calwash/credentials.json (user override)
    2. Bundled calwash/data/credentials.json (package default)
    """
    user_creds = CALWASH_HOME / "credentials.json"
    if user_creds.exists():
        return user_creds

    try:
        from importlib.resources import files
        bundled = files("calwash.data").joinpath("credentials.json")
        bundled_path = Path(str(bundled))
        if bundled_path.exists():
            return bundled_path
    except Exception:
        pass

    raise FileNotFoundError(
        "No Google OAuth credentials found.\n"
        f"  Place your credentials.json at: {user_creds}\n"
        "  Or the bundled credentials are missing from the package.\n"
        "  Get credentials from: https://console.cloud.google.com/"
    )


def _get_user_email_from_google(credentials) -> str:
    """Get user email from Google OAuth2 credentials."""
    from googleapiclient.discovery import build

    oauth2_service = build('oauth2', 'v2', credentials=credentials)
    user_info = oauth2_service.userinfo().get().execute()
    email = user_info.get('email')
    if not email:
        raise UserEmailNotFoundError("User email not found in OAuth2 response")
    return email


class GoogleProvider(CalendarProvider):
    """Google Calendar API provider."""

    def __init__(self):
        self._service = None
        self._user_email = None
        self._creds = None

    @property
    def provider_name(self) -> str:
        return "Google Calendar"

    def authenticate(self, account: str = 'default') -> str:
        """Authenticate via Google OAuth2.

        Opens browser for consent on first run, then reuses saved token.
        """
        from google_auth_oauthlib.flow import InstalledAppFlow
        from google.auth.transport.requests import Request
        from googleapiclient.discovery import build

        SCOPES = [
            'https://www.googleapis.com/auth/calendar',
            'https://www.googleapis.com/auth/userinfo.email',
        ]

        _migrate_profiles_if_needed()

        credentials_file = _find_google_credentials()
        logger.info(f"Using credentials from: {credentials_file}")

        token_file = get_account_token_path(account)
        creds = None

        # Load existing token
        if token_file.exists():
            logger.info(f"Loading authentication token for account '{account}'...")
            try:
                with open(token_file, 'rb') as f:
                    creds = pickle.load(f)
            except Exception as e:
                logger.warning(f"Failed to load token: {e}")
                creds = None

        # Refresh or re-authenticate
        if not creds or not creds.valid:
            if creds and creds.expired and creds.refresh_token:
                logger.info(f"Refreshing expired token for account '{account}'...")
                try:
                    creds.refresh(Request())
                except Exception as e:
                    logger.warning(f"Token refresh failed: {e}. Requesting new authorization...")
                    creds = None

            if not creds or not creds.valid:
                logger.info("Opening browser for Google sign-in...")
                extended_scopes = SCOPES + ['openid']
                flow = InstalledAppFlow.from_client_secrets_file(
                    str(credentials_file), extended_scopes
                )
                try:
                    creds = flow.run_local_server(port=0)
                    logger.info("OAuth authentication successful")
                except Exception as e:
                    logger.warning(f"Initial auth failed: {e}")
                    logger.info("Retrying with basic scopes...")
                    flow = InstalledAppFlow.from_client_secrets_file(
                        str(credentials_file), SCOPES
                    )
                    creds = flow.run_local_server(port=0)

            # Save token
            try:
                with open(token_file, 'wb') as f:
                    pickle.dump(creds, f)
                logger.info(f"Token saved to {token_file}")
            except Exception as e:
                logger.error(f"Failed to save token: {e}")
        else:
            logger.info(f"Using saved token for account '{account}'")

        self._creds = creds
        self._service = build('calendar', 'v3', credentials=creds)

        try:
            self._user_email = _get_user_email_from_google(creds)
            logger.info(f"Authenticated as: {self._user_email}")

            # Cache email for list_accounts()
            email_file = get_account_directory(account) / 'email.txt'
            try:
                email_file.write_text(self._user_email)
            except Exception:
                pass

            return self._user_email
        except Exception as e:
            raise AuthenticationError(f"Failed to retrieve user info: {e}") from e

    def list_events(self, date_range=None, max_results: int = 2500) -> list[dict]:
        """Fetch events from Google Calendar API."""
        if not self._service:
            raise RuntimeError("Not authenticated. Call authenticate() first.")

        logger.info("Fetching calendar events...")
        if date_range:
            logger.info(f"Filtering events by date range: {date_range}")

        params = {
            'calendarId': 'primary',
            'maxResults': max_results,
            'singleEvents': True,
            'orderBy': 'startTime',
        }

        if date_range:
            if date_range.from_date:
                from_dt = date_range.from_date.replace(
                    hour=0, minute=0, second=0, microsecond=0
                )
                if from_dt.tzinfo is None:
                    from_dt = from_dt.replace(tzinfo=timezone.utc)
                params['timeMin'] = from_dt.isoformat()
            if date_range.to_date:
                to_dt = date_range.to_date.replace(
                    hour=23, minute=59, second=59, microsecond=0
                )
                if to_dt.tzinfo is None:
                    to_dt = to_dt.replace(tzinfo=timezone.utc)
                params['timeMax'] = to_dt.isoformat()

        events_result = self._service.events().list(**params).execute()
        all_events = events_result.get('items', [])
        logger.info(f"Found {len(all_events)} events from API")

        if date_range:
            filtered = date_range.filter_events(all_events)
            logger.info(f"Filtered to {len(filtered)} events in date range")
            return filtered

        return all_events

    def update_event(self, event_id: str, event: dict) -> None:
        """Update a single event via Google Calendar API."""
        if not self._service:
            raise RuntimeError("Not authenticated. Call authenticate() first.")

        self._service.events().update(
            calendarId='primary',
            eventId=event_id,
            body=event,
        ).execute()

    def update_events_batch(
        self, cleaned_events: list[dict], changes: list[dict]
    ) -> tuple[int, int]:
        """Update multiple events. Returns (success_count, fail_count)."""
        events_to_update = {c['event_id'] for c in changes}
        updated = 0
        failed = 0

        for event in cleaned_events:
            if event['id'] in events_to_update:
                try:
                    self.update_event(event['id'], event)
                    updated += 1
                    if updated % 10 == 0:
                        logger.info(f"Updated {updated} events...")
                except Exception as e:
                    logger.error(f"Failed to update event {event['id']}: {e}")
                    failed += 1

        return updated, failed

    def restore_events(
        self, events: list[dict], dry_run: bool = False, date_range=None
    ) -> None:
        """Restore events to Google Calendar."""
        if dry_run:
            logger.info("\n" + "=" * 60)
            logger.info("RESTORE PREVIEW - No changes will be made")
            logger.info("=" * 60)
            logger.info(f"Would restore {len(events)} events to calendar")

            for i, event in enumerate(events[:5]):
                logger.info(f"\nEvent {i + 1}:")
                logger.info(f"  Summary: {event.get('summary', 'No title')}")
                logger.info(
                    f"  Date: {event.get('start', {}).get('dateTime', event.get('start', {}).get('date', 'Unknown'))}"
                )
                if 'description' in event:
                    desc = event['description']
                    preview = desc[:100] + '...' if len(desc) > 100 else desc
                    logger.info(f"  Description: {preview}")

            if len(events) > 5:
                logger.info(f"\n... and {len(events) - 5} more events")

            logger.info("\nTo actually restore, run without --dry-run")
            return

        logger.info("\nRestoring events to calendar...")
        restored = 0
        failed = 0

        for event in events:
            try:
                self.update_event(event['id'], event)
                restored += 1
                if restored % 10 == 0:
                    logger.info(f"Restored {restored} events...")
                    time.sleep(0.5)  # Rate limit protection
            except Exception as e:
                logger.error(f"Failed to restore event {event.get('id', 'unknown')}: {e}")
                failed += 1

        logger.info("\n" + "=" * 60)
        logger.info("RESTORE COMPLETE")
        logger.info("=" * 60)
        logger.info(f"Successfully restored: {restored} events")
        if failed > 0:
            logger.warning(f"Failed to restore: {failed} events")
        if date_range:
            logger.info(f"Events were filtered by date range: {date_range}")
