"""Abstract base class for calendar providers."""

from abc import ABC, abstractmethod
from typing import Optional


class CalendarProvider(ABC):
    """Interface that all calendar providers must implement.

    Providers handle authentication, event fetching, and event updating
    for a specific calendar service (Google, Apple, etc.). The cleaning
    logic in calwash is provider-agnostic and works on normalized event dicts.

    Normalized event format:
        {
            "id": str,
            "summary": str,
            "description": str,
            "location": str,
            "start": {"dateTime": str} or {"date": str},
            "end": {"dateTime": str} or {"date": str},
            ...extra provider-specific fields preserved...
        }
    """

    @abstractmethod
    def authenticate(self, account: str = 'default') -> str:
        """Authenticate with the calendar service.

        Args:
            account: Account name for credential storage.

        Returns:
            The authenticated user's email address.
        """

    @abstractmethod
    def list_events(self, date_range=None, max_results: int = 2500) -> list[dict]:
        """Fetch events from the calendar.

        Args:
            date_range: Optional DateRange for filtering.
            max_results: Maximum number of events to return.

        Returns:
            List of event dicts in normalized format.
        """

    @abstractmethod
    def update_event(self, event_id: str, event: dict) -> None:
        """Update a single event on the calendar.

        Args:
            event_id: The event's unique identifier.
            event: The updated event dict.
        """

    @property
    @abstractmethod
    def provider_name(self) -> str:
        """Human-readable provider name (e.g., 'Google Calendar')."""

    @property
    def user_email(self) -> Optional[str]:
        """The authenticated user's email, or None if not authenticated."""
        return getattr(self, '_user_email', None)
