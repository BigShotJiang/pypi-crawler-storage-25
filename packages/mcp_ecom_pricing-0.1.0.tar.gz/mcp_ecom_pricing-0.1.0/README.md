# 💰 mcp-ecom-pricing

**电商定价 MCP Server** — 基于成本计算建议售价、基于售价核算净利润率，一个 Server 全搞定。

基于扣子技能 e-commerce-pricing-calculator 重写为 MCP Server。

纯计算逻辑，无需外部 API、无需环境变量。

---

## 🛠 工具列表

| 工具 | 功能 | 典型场景 |
|------|------|---------|
| `pricing` | 基于成本和目标利润率计算建议售价 | "成本30元，目标利润15%，该卖多少？" |
| `valuation` | 基于售价核算实际净利润率 | "卖49元，净利润率多少？" |

---

## 📦 安装

```bash
pip install mcp-ecom-pricing
```

或从源码安装：

```bash
git clone https://github.com/yourname/mcp-ecom-pricing.git
cd mcp-ecom-pricing
pip install -e .
```

## ⚙️ 配置

无需任何环境变量，纯计算逻辑。

## 🚀 使用

### 命令行

```bash
# STDIO 模式 (默认)
mcp-ecom-pricing

# 或
python -m mcp_ecom_pricing
```

### MCP 客户端配置

在 Claude Desktop / Cherry Studio / ChatBox 等 MCP 客户端中添加：

```json
{
  "mcpServers": {
    "ecom-pricing": {
      "command": "mcp-ecom-pricing"
    }
  }
}
```

### 开发测试

```bash
# 安装 FastMCP CLI
pip install "mcp[cli]"

# 交互式测试
mcp dev src/mcp_ecom_pricing/server.py
```

---

## 💡 工具详细说明

### pricing — 定价计算

基于成本和目标利润率计算建议售价。

```python
# 基本定价
pricing(
    cost=30.0,            # 商品成本 30元
    platform_fee=0.05,    # 平台扣点 5%
    shipping_insurance=1.0,  # 运费险 1元/单
    express_fee=3.0,      # 快递费 3元/单
    ad_ratio=0.10,        # 广告费占比 10%
    return_rate=0.05,     # 退货率 5%
    target_profit=0.15,   # 目标利润率 15%
)
# → suggested_price: 48.86元
```

**参数**：
- `cost` (必填): 商品成本（元），必须大于0
- `platform_fee` (必填): 平台扣点率（小数，如0.05表示5%）
- `shipping_insurance` (必填): 运费险（元/单）
- `express_fee` (必填): 快递费（元/单）
- `ad_ratio` (必填): 广告费占比（小数，如0.1表示10%）
- `return_rate` (必填): 退货率（小数，如0.05表示5%）
- `target_profit` (必填): 目标利润率（小数，如0.15表示15%）

**返回**：建议售价、各项成本明细（成本/运费险/快递费/退货损失/平台扣点/广告费/目标利润）、各项费率、利润分析

**计算公式**：

退货时商品可二次销售，仅损失快递费+运费险：

```
有效成本 = 商品成本 + 运费险 + 快递费
退货每单额外损失 = (运费险 + 快递费) × 退货率
售价 = (有效成本 + 退货每单额外损失) / (1 - 平台扣点率 - 广告占比 - 目标利润率)
```

### valuation — 利润核算

基于售价核算实际净利润率。

```python
# 利润核算
valuation(
    cost=30.0,            # 商品成本 30元
    price=49.0,           # 售价 49元
    platform_fee=0.05,    # 平台扣点 5%
    shipping_insurance=1.0,  # 运费险 1元/单
    express_fee=3.0,      # 快递费 3元/单
    ad_ratio=0.10,        # 广告费占比 10%
    return_rate=0.05,     # 退货率 5%
)
# → 净利润: 7.45元, 净利润率: 15.20%, 盈利
```

**参数**：
- `cost` (必填): 商品成本（元），必须大于0
- `price` (必填): 售价（元），必须大于0
- `platform_fee` (必填): 平台扣点率（小数）
- `shipping_insurance` (必填): 运费险（元/单）
- `express_fee` (必填): 快递费（元/单）
- `ad_ratio` (必填): 广告费占比（小数）
- `return_rate` (必填): 退货率（小数）

**返回**：净利润金额、净利润率、各项成本明细、各项成本占比、盈亏判定

**计算公式**：

```
平台扣点 = 售价 × 平台扣点率
广告费 = 售价 × 广告占比
退货损失 = (运费险 + 快递费) × 退货率
总成本 = 商品成本 + 运费险 + 快递费 + 平台扣点 + 广告费 + 退货损失
净利润 = 售价 - 总成本
净利润率 = 净利润 / 售价
```

---

## 📜 License

MIT
