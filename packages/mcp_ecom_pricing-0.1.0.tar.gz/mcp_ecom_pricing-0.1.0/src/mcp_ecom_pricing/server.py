"""
电商定价 MCP Server
基于扣子技能 e-commerce-pricing-calculator 重写
2个工具: pricing / valuation
纯计算逻辑，无外部API依赖
"""

from typing import Annotated

from mcp.server.fastmcp import FastMCP
from pydantic import Field

mcp = FastMCP(
    "ecom-pricing",
    instructions="电商定价工具：基于成本和目标利润率计算建议售价(pricing)，基于售价核算实际净利润率(valuation)。纯计算，无需外部API。",
)


def _validate_ratio(value: float, name: str) -> None:
    """验证百分比参数在 0-1 范围内"""
    if not (0 <= value <= 1):
        raise ValueError(f"{name} 必须在 0~1 之间（当前值: {value}）")


# ============================================================
# 工具1: pricing — 基于成本和目标利润率计算建议售价
# ============================================================
@mcp.tool()
def pricing(
    cost: Annotated[float, Field(
        description="商品成本（元），必须大于0"
    )],
    platform_fee: Annotated[float, Field(
        description="平台扣点率（小数，如0.05表示5%）"
    )],
    shipping_insurance: Annotated[float, Field(
        description="运费险（元/单）"
    )],
    express_fee: Annotated[float, Field(
        description="快递费（元/单）"
    )],
    ad_ratio: Annotated[float, Field(
        description="广告费占比（小数，如0.1表示10%）"
    )],
    return_rate: Annotated[float, Field(
        description="退货率（小数，如0.05表示5%）"
    )],
    target_profit: Annotated[float, Field(
        description="目标利润率（小数，如0.15表示15%）"
    )],
) -> dict:
    """基于成本和目标利润率计算建议售价，返回售价、各项成本明细和利润分析。退货时商品可二次销售，仅损失快递费+运费险。"""
    # 参数验证
    if cost <= 0:
        return {"ok": False, "err": "商品成本(cost)必须大于0"}
    try:
        _validate_ratio(platform_fee, "平台扣点率(platform_fee)")
        _validate_ratio(ad_ratio, "广告费占比(ad_ratio)")
        _validate_ratio(return_rate, "退货率(return_rate)")
        _validate_ratio(target_profit, "目标利润率(target_profit)")
    except ValueError as e:
        return {"ok": False, "err": str(e)}
    if shipping_insurance < 0:
        return {"ok": False, "err": "运费险(shipping_insurance)不能为负"}
    if express_fee < 0:
        return {"ok": False, "err": "快递费(express_fee)不能为负"}

    # 计算定价
    # 有效成本 = 商品成本 + 运费险 + 快递费
    effective_cost = cost + shipping_insurance + express_fee
    # 退货每单额外损失 = (运费险 + 快递费) × 退货率（退货只损失运费险+快递费，商品可二次销售）
    return_loss_per_order = (shipping_insurance + express_fee) * return_rate

    # 分母 = 1 - 平台扣点率 - 广告占比 - 目标利润率
    denominator = 1 - platform_fee - ad_ratio - target_profit
    if denominator <= 0:
        return {
            "ok": False,
            "err": "费用占比过高（平台扣点+广告占比+目标利润率 ≥ 100%），无法实现目标利润",
            "detail": {
                "platform_fee_pct": f"{platform_fee:.1%}",
                "ad_ratio_pct": f"{ad_ratio:.1%}",
                "target_profit_pct": f"{target_profit:.1%}",
                "total_rate_pct": f"{platform_fee + ad_ratio + target_profit:.1%}",
            },
        }

    # 售价 = (有效成本 + 退货每单额外损失) / 分母
    suggested_price = (effective_cost + return_loss_per_order) / denominator

    # 明细计算
    platform_fee_amount = suggested_price * platform_fee
    ad_fee = suggested_price * ad_ratio
    target_profit_amount = suggested_price * target_profit

    return {
        "ok": True,
        "suggested_price": round(suggested_price, 2),
        "breakdown": {
            "cost": round(cost, 2),
            "shipping_insurance": round(shipping_insurance, 2),
            "express_fee": round(express_fee, 2),
            "return_loss_per_order": round(return_loss_per_order, 2),
            "platform_fee_amount": round(platform_fee_amount, 2),
            "ad_fee": round(ad_fee, 2),
            "target_profit_amount": round(target_profit_amount, 2),
        },
        "rates": {
            "platform_fee": f"{platform_fee:.1%}",
            "ad_ratio": f"{ad_ratio:.1%}",
            "return_rate": f"{return_rate:.1%}",
            "target_profit": f"{target_profit:.1%}",
        },
        "analysis": {
            "total_cost_per_order": round(
                cost + shipping_insurance + express_fee + return_loss_per_order,
                2,
            ),
            "total_deduction_per_order": round(
                platform_fee_amount + ad_fee,
                2,
            ),
            "gross_per_order": round(target_profit_amount, 2),
        },
    }


# ============================================================
# 工具2: valuation — 基于售价核算实际净利润率
# ============================================================
@mcp.tool()
def valuation(
    cost: Annotated[float, Field(
        description="商品成本（元），必须大于0"
    )],
    price: Annotated[float, Field(
        description="售价（元），必须大于0"
    )],
    platform_fee: Annotated[float, Field(
        description="平台扣点率（小数，如0.05表示5%）"
    )],
    shipping_insurance: Annotated[float, Field(
        description="运费险（元/单）"
    )],
    express_fee: Annotated[float, Field(
        description="快递费（元/单）"
    )],
    ad_ratio: Annotated[float, Field(
        description="广告费占比（小数，如0.1表示10%）"
    )],
    return_rate: Annotated[float, Field(
        description="退货率（小数，如0.05表示5%）"
    )],
) -> dict:
    """基于售价核算实际净利润率，返回净利润率、实际利润金额和各项成本占比。退货时商品可二次销售，仅损失快递费+运费险。"""
    # 参数验证
    if cost <= 0:
        return {"ok": False, "err": "商品成本(cost)必须大于0"}
    if price <= 0:
        return {"ok": False, "err": "售价(price)必须大于0"}
    try:
        _validate_ratio(platform_fee, "平台扣点率(platform_fee)")
        _validate_ratio(ad_ratio, "广告费占比(ad_ratio)")
        _validate_ratio(return_rate, "退货率(return_rate)")
    except ValueError as e:
        return {"ok": False, "err": str(e)}
    if shipping_insurance < 0:
        return {"ok": False, "err": "运费险(shipping_insurance)不能为负"}
    if express_fee < 0:
        return {"ok": False, "err": "快递费(express_fee)不能为负"}

    # 计算利润
    # 平台扣点 = 售价 × 平台扣点率
    platform_fee_amount = price * platform_fee
    # 广告费 = 售价 × 广告占比
    ad_fee = price * ad_ratio
    # 退货损失 = (运费险 + 快递费) × 退货率
    return_loss = (shipping_insurance + express_fee) * return_rate

    # 总成本 = 商品成本 + 运费险 + 快递费 + 平台扣点 + 广告费 + 退货损失
    total_cost = cost + shipping_insurance + express_fee + platform_fee_amount + ad_fee + return_loss

    # 净利润 = 售价 - 总成本
    net_profit = price - total_cost
    # 净利润率 = 净利润 / 售价
    net_profit_rate = net_profit / price

    return {
        "ok": True,
        "price": round(price, 2),
        "net_profit": round(net_profit, 2),
        "net_profit_rate": f"{net_profit_rate:.2%}",
        "net_profit_rate_raw": round(net_profit_rate, 6),
        "breakdown": {
            "cost": round(cost, 2),
            "shipping_insurance": round(shipping_insurance, 2),
            "express_fee": round(express_fee, 2),
            "platform_fee_amount": round(platform_fee_amount, 2),
            "ad_fee": round(ad_fee, 2),
            "return_loss": round(return_loss, 2),
            "total_cost": round(total_cost, 2),
        },
        "cost_ratios": {
            "cost_ratio": f"{cost / price:.2%}",
            "platform_fee_ratio": f"{platform_fee:.2%}",
            "ad_ratio": f"{ad_ratio:.2%}",
            "shipping_insurance_ratio": f"{shipping_insurance / price:.2%}",
            "express_fee_ratio": f"{express_fee / price:.2%}",
            "return_loss_ratio": f"{return_loss / price:.2%}",
        },
        "verdict": "盈利" if net_profit > 0 else "亏损",
    }
