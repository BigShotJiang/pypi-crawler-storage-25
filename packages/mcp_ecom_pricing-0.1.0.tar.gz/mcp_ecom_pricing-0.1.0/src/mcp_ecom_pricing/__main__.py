"""电商定价 MCP Server — python -m mcp_ecom_pricing 入口"""
from mcp_ecom_pricing import main

main()
