"""电商定价 MCP Server — 入口"""
from .server import mcp


def main():
    mcp.run()


__all__ = ["main", "mcp"]
