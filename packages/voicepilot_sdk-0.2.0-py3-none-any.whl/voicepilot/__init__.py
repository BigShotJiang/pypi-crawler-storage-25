from .client import VoicePilotClient
from .vad import VoiceActivityDetector
from .exceptions import (
    VoicePilotError, AuthenticationError, ValidationError, 
    RateLimitError, APIError, NetworkError
)
from .types import SessionToken, WSMessage

__version__ = "0.2.0"

__all__ = [
    "VoicePilotClient",
    "VoiceActivityDetector",
    "VoicePilotError",
    "AuthenticationError",
    "ValidationError",
    "RateLimitError",
    "APIError",
    "NetworkError",
    "SessionToken",
    "WSMessage",
]
