"""Built-in health checks. Importing this module triggers registration."""

from . import broken_ci, coverage, open_issues, open_prs, renovate, renovate_prs, stale_prs

__all__ = [
    "broken_ci",
    "coverage",
    "open_issues",
    "open_prs",
    "renovate",
    "renovate_prs",
    "stale_prs",
]
