from .base import SqlErrorRequirements
from ..constraints import query as query_constraints
from ..difficulty_level import DifficultyLevel
from ..translatable_text import TranslatableText

class Err083_UnnecessaryDistinctInSelectClause(SqlErrorRequirements):
    def exercise_constraints(self, difficulty: DifficultyLevel) -> list[query_constraints.QueryConstraint]:
        constraints = super().exercise_constraints(difficulty)

        if difficulty == DifficultyLevel.EASY:
            return [
                *constraints,
                query_constraints.clause_where.Condition(2),
                query_constraints.clause_from.TableReferences(1, 2),
                query_constraints.rows.Duplicates(),
                query_constraints.subquery.NoSubquery(),
                query_constraints.clause_having.NoHaving(),
                
            ]
        if difficulty == DifficultyLevel.MEDIUM:
            return [
                query_constraints.clause_where.Condition(3),
                query_constraints.aggregation.Aggregation(2),
                query_constraints.rows.Duplicates(),
                query_constraints.subquery.NoSubquery(), 
            ]
        
        # HARD
        return [
            query_constraints.clause_where.Condition(4),
            query_constraints.aggregation.Aggregation(3),
            query_constraints.subquery.Subqueries(),
            query_constraints.rows.Duplicates(),
        ]

    def exercise_extra_details(self) -> TranslatableText:
        return TranslatableText(
            "In the solution there must be no DISTINCT.",
            it="Nella soluzione non deve essere presente DISTINCT."
        )
