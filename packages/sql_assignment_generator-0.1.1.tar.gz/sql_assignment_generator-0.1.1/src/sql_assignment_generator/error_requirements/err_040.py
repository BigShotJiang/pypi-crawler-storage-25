from .base import SqlErrorRequirements
from ..constraints import schema as schema_constraints, query as query_constraints
from ..difficulty_level import DifficultyLevel
from ..translatable_text import TranslatableText

class Err040_ImpliedTautologicalOrInconsistentExpressions(SqlErrorRequirements):
    def dataset_constraints(self, difficulty: DifficultyLevel) -> list[schema_constraints.SchemaConstraint]:
        constraints = super().dataset_constraints(difficulty)

        if difficulty == DifficultyLevel.EASY:
            return [
                *constraints,
                schema_constraints.tables.MinChecks(1)
            ]
        if difficulty == DifficultyLevel.MEDIUM:
            return[
                *constraints,
                schema_constraints.tables.MinChecks(2)
            ]
        
        # HARD
        return [
            *constraints,
            schema_constraints.tables.MinChecks(3)
        ]

    def exercise_constraints(self, difficulty: DifficultyLevel) -> list[query_constraints.QueryConstraint]:
        constraints = super().exercise_constraints(difficulty)
        
        if difficulty == DifficultyLevel.EASY:
            return [
                *constraints,
                query_constraints.clause_where.MultipleConditionsOnSameColumn(1),
                query_constraints.clause_from.TableReferences(0, 1),
                query_constraints.subquery.NoSubquery(),
                query_constraints.clause_having.NoHaving()
            ]
        if difficulty == DifficultyLevel.MEDIUM:
            return [
                *constraints,
                query_constraints.clause_where.MultipleConditionsOnSameColumn(1),
                query_constraints.aggregation.Aggregation(2),
                query_constraints.subquery.NoSubquery()
            ]
        
        # HARD
        return [
            *constraints,
            query_constraints.clause_where.MultipleConditionsOnSameColumn(2),
            query_constraints.aggregation.Aggregation(2),
            query_constraints.subquery.Subqueries()
        ]

    def exercise_extra_details(self) -> TranslatableText:
        return TranslatableText(
            "Exercise should require multiple conditions on the same column " \
            "(e.g. p.age < 18 AND p.age >= 0 this represent one column with multiple conditions).",
            it="L'esercizio deve richiedere condizioni multiple sulla stessa colonna " \
               "(es. p.età < 18 AND p.età >= 0 questo rappresenta una colonna con più condizioni)."
        )
