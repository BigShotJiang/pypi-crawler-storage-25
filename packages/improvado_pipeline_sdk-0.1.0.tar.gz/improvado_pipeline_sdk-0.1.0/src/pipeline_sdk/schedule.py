"""@scheduled decorator for auto-creating Temporal Schedules.

Usage::

    from pipeline_sdk.schedule import scheduled

    @scheduled(
        every=timedelta(minutes=30),
        tenant=TenantID('agency-uuid', 26),
        args=MyParams(connection_id=65518),
    )
    @workflow.defn(sandboxed=False, name='MyWorkflow')
    class MyWorkflow:
        ...
"""

from __future__ import annotations

import dataclasses
from datetime import timedelta
from typing import Any, Optional

from pipeline_sdk.types import Cluster, TenantID


@dataclasses.dataclass(frozen=True)
class ScheduleConfig:
    every: Optional[timedelta] = None
    cron: Optional[str] = None
    tenant: Optional[TenantID] = None
    args: Any = None
    task_queue: Optional[str] = None
    cluster: Optional[Cluster] = None


def scheduled(
    every: Optional[timedelta] = None,
    cron: Optional[str] = None,
    tenant: Optional[TenantID] = None,
    args: Any = None,
    task_queue: Optional[str] = None,
    cluster: Optional[Cluster] = None,
) -> Any:
    """Attach schedule config to a workflow class."""
    config = ScheduleConfig(
        every=every,
        cron=cron,
        tenant=tenant,
        args=args,
        task_queue=task_queue,
        cluster=cluster,
    )

    def decorator(cls: type) -> type:
        cls._schedule_config = config  # type: ignore[attr-defined]
        return cls

    return decorator
