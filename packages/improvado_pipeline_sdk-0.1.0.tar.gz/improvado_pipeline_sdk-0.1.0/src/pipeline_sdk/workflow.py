"""Public API for pipeline workflow code.

Import from here in @workflow.defn classes. All symbols are safe
for Temporal's deterministic sandbox (no I/O, no side effects).

Usage::

    with workflow.unsafe.imports_passed_through():
        from pipeline_sdk.workflow import (
            les_extract, DataRef, DateRangeRequest,
            prepare_credentials, cleanup_credentials,
            CUSTOM_ACTIVITY_QUEUE,
        )
"""

from __future__ import annotations

from datetime import timedelta
from typing import Any

from temporalio import workflow
from temporalio.common import RetryPolicy

from pipeline_sdk.credentials import (
    PipelineCredentials as PipelineCredentials,
    cleanup_credentials as cleanup_credentials,
    prepare_credentials as prepare_credentials,
)
from pipeline_sdk.types import (
    Cluster as Cluster,
    DataRef as DataRef,
    DateRangeRequest as DateRangeRequest,
    DateRangeType as DateRangeType,
    ExtractParams as ExtractParams,
    ExtractResult as ExtractResult,
    LesActivityWithS3Result,
    LesS3UploadActivityParams,
    StorageType as StorageType,
    TenantID as TenantID,
)

# ── Constants ──────────────────────────────────────────────────

CUSTOM_ACTIVITY_QUEUE = 'tenant-pipeline-activities'

EXTRACT_ACTIVITY = 'pipeline_extract'

LES_ACTIVITY_WITH_S3 = 'run_les_activity_with_s3_upload'
LES_QUEUE = 'les-activities-queue'

# ── Default LES retry / timeouts ──────────────────────────────

LES_DEFAULT_RETRY = RetryPolicy(
    initial_interval=timedelta(minutes=5),
    backoff_coefficient=2.0,
    maximum_interval=timedelta(minutes=15),
    maximum_attempts=34,
    non_retryable_error_types=['ApplicationError'],
)

LES_DEFAULT_SCHEDULE_TO_CLOSE = timedelta(hours=48)
LES_DEFAULT_HEARTBEAT = timedelta(minutes=15)


# ── High-level helpers ─────────────────────────────────────────


async def les_extract(
    connector_id: int,
    data_source: str,
    report_type: str,
    date_range: DateRangeRequest | None = None,
    fields: list[str] | None = None,
    args: dict[str, Any] | None = None,
    hashed_fields: list[str] | None = None,
    save_raw_data: bool = False,
    raw_responses_exclude_request: bool = False,
    *,
    schedule_to_close_timeout: timedelta = (LES_DEFAULT_SCHEDULE_TO_CLOSE),
    heartbeat_timeout: timedelta = LES_DEFAULT_HEARTBEAT,
    retry_policy: RetryPolicy = LES_DEFAULT_RETRY,
) -> LesActivityWithS3Result:
    """Extract data via LES.

    Returns result with ``.data_ref`` and
    ``.result_stage_has_data``.

    Must be called from workflow context
    (uses ``workflow.execute_activity``).
    """
    return await workflow.execute_activity(
        LES_ACTIVITY_WITH_S3,
        LesS3UploadActivityParams(
            connector_id=connector_id,
            data_source=data_source,
            report_type=report_type,
            fields=fields or [],
            date_range_request=date_range,
            args=args or {},
            hashed_fields=hashed_fields or [],
            save_raw_data=save_raw_data,
            raw_responses_exclude_request=(raw_responses_exclude_request),
        ),
        task_queue=LES_QUEUE,
        schedule_to_close_timeout=schedule_to_close_timeout,
        heartbeat_timeout=heartbeat_timeout,
        retry_policy=retry_policy,
        result_type=LesActivityWithS3Result,
    )


__all__ = [
    # High-level helpers
    'les_extract',
    # Constants
    'CUSTOM_ACTIVITY_QUEUE',
    'EXTRACT_ACTIVITY',
    'LES_DEFAULT_RETRY',
    'LES_DEFAULT_SCHEDULE_TO_CLOSE',
    'LES_DEFAULT_HEARTBEAT',
    # Data references
    'DataRef',
    'StorageType',
    # Tenant / cluster
    'Cluster',
    'TenantID',
    # Credentials (workflow-level)
    'PipelineCredentials',
    'prepare_credentials',
    'cleanup_credentials',
    # Extract types
    'DateRangeRequest',
    'DateRangeType',
    'ExtractParams',
    'ExtractResult',
]
