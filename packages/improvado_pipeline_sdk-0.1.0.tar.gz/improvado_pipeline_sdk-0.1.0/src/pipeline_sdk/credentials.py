"""Pipeline credentials: Vault pointers, secret types, helpers.

Workflow code calls prepare_credentials() / cleanup_credentials().
Activity code calls read_pipeline_secret().
"""

from __future__ import annotations

import dataclasses
import os
from datetime import timedelta

import aiohttp
from temporalio import workflow
from temporalio.common import RetryPolicy

DTS_ACTIVITY_QUEUE = 'dts-les-activities-queue'

VAULT_ADDR = os.getenv('VAULT_ADDR', 'http://vault:8200')
VAULT_MOUNT_POINT = os.getenv(
    'VAULT_AI_AGENT_MOUNT_POINT',
    'ai_agent',
)

PREPARE_CREDS_RETRY = RetryPolicy(
    initial_interval=timedelta(seconds=5),
    backoff_coefficient=2.0,
    maximum_interval=timedelta(seconds=30),
    maximum_attempts=3,
    non_retryable_error_types=['ApplicationError'],
)


# ── Vault secret structure ─────────────────────────────────────


@dataclasses.dataclass(frozen=True)
class S3Credentials:
    access_key: str
    secret_key: str
    session_token: str
    bucket: str
    prefix: str  # "{agency_uuid}/{workspace_id}/{run_id}"


@dataclasses.dataclass(frozen=True)
class StorageCredentials:
    host: str  # "http://ch-host:8123"
    database: str
    user: str
    password: str


@dataclasses.dataclass(frozen=True)
class PipelineSecret:
    """Full contents of the Vault secret for a pipeline run."""

    connections: dict[str, dict]  # alias -> credential dict
    storage: StorageCredentials
    dts_session_id: str
    s3: S3Credentials


# ── Workflow-level: prepare / cleanup ──────────────────────────


@dataclasses.dataclass(frozen=True)
class PipelineCredentials:
    """Returned by prepare_credentials(). Vault pointer + S3."""

    secret_path: str  # "custom-pipelines/{run_id}"
    vault_token: str  # scoped read-only Vault token
    s3_bucket: str
    s3_prefix: str  # "{agency_uuid}/{workspace_id}/{run_id}"


async def prepare_credentials(
    run_id: str,
    connection_aliases: list[dict],
    agency_chief_id: int | None = None,
) -> PipelineCredentials:
    """Call DTS prepare_pipeline_credentials_v2_activity.

    Must be called from workflow context
    (uses workflow.execute_activity). TenantID is propagated
    automatically via Temporal headers.
    """
    result = await workflow.execute_activity(
        'prepare_pipeline_credentials_v2_activity',
        {
            'run_id': run_id,
            'connection_aliases': connection_aliases,
            'created_by_user_id': agency_chief_id or 0,
        },
        task_queue=DTS_ACTIVITY_QUEUE,
        start_to_close_timeout=timedelta(minutes=2),
        retry_policy=PREPARE_CREDS_RETRY,
    )

    return PipelineCredentials(
        secret_path=result['secret_path'],
        vault_token=result['vault_token'],
        s3_bucket=result['s3_bucket'],
        s3_prefix=result['s3_prefix'],
    )


async def cleanup_credentials(
    run_id: str,
    vault_token: str = '',
) -> None:
    """Call DTS cleanup_pipeline_secret_activity."""
    await workflow.execute_activity(
        'cleanup_pipeline_secret_activity',
        {
            'run_id': run_id,
            'vault_token': vault_token,
        },
        task_queue=DTS_ACTIVITY_QUEUE,
        start_to_close_timeout=timedelta(minutes=1),
        retry_policy=PREPARE_CREDS_RETRY,
    )


# ── Activity-level: read full secret from Vault ───────────────


async def read_pipeline_secret(
    creds: PipelineCredentials,
) -> PipelineSecret:
    """Read the full pipeline secret from Vault.

    Call from activity code only (performs I/O).
    """
    url = f'{VAULT_ADDR}/v1/{VAULT_MOUNT_POINT}/data/{creds.secret_path}'
    headers = {'X-Vault-Token': creds.vault_token}

    timeout = aiohttp.ClientTimeout(total=30)
    async with aiohttp.ClientSession(timeout=timeout) as session:
        async with session.get(url, headers=headers) as resp:
            resp.raise_for_status()
            body = await resp.json()

    data = body['data']['data']

    return PipelineSecret(
        connections=data['connections'],
        storage=StorageCredentials(**data['storage']),
        dts_session_id=data['dts_session_id'],
        s3=S3Credentials(**data['s3']),
    )
