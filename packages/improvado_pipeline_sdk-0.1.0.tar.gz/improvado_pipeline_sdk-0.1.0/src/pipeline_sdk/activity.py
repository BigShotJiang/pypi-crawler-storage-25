"""Public API for pipeline activity code.

Import from here in @activity.defn functions. These symbols
perform I/O and must NOT be used in workflow (deterministic)
context.

Usage::

    from pipeline_sdk.activity import (
        read_pipeline_secret, get_current_tenant,
    )
"""

from __future__ import annotations

import contextvars

from temporalio.exceptions import ApplicationError

from pipeline_sdk.credentials import (
    PipelineSecret as PipelineSecret,
    S3Credentials as S3Credentials,
    StorageCredentials as StorageCredentials,
    read_pipeline_secret as read_pipeline_secret,
)
from pipeline_sdk.types import TenantID

# ── Tenant context ─────────────────────────────────────────────

_current_tenant: contextvars.ContextVar[TenantID | None] = (
    contextvars.ContextVar('current_tenant', default=None)
)


def get_current_tenant() -> TenantID:
    """Return the TenantID for the current activity execution.

    Raises ApplicationError if no tenant is set (workflow was
    started without the x-tenant-id header).
    """
    tenant = _current_tenant.get()
    if tenant is None:
        raise ApplicationError(
            'No TenantID in context. '
            'Was the workflow started with the '
            'x-tenant-id header?',
            non_retryable=True,
        )
    return tenant


__all__ = [
    'read_pipeline_secret',
    'get_current_tenant',
    'PipelineSecret',
    'S3Credentials',
    'StorageCredentials',
]
