"""Shared type definitions for custom pipeline SDK.

All dataclasses here are Temporal-serializable (frozen, simple fields).
No I/O, no side effects — safe for both workflow and activity code.
"""

from __future__ import annotations

import dataclasses
import datetime
import enum
from typing import Any


# ── Storage & Data References ───────────────────────────────────


class StorageType(str, enum.Enum):
    S3 = 's3'
    NFS = 'nfs'


@dataclasses.dataclass(frozen=True)
class DataRef:
    """Pointer to data in S3 or NFS.

    Large data never flows through Temporal payloads — only refs.

    Examples::

        DataRef.s3("bucket", "key/path.parquet", "parquet")
        DataRef.nfs("/media/les_efs/store/run1/result.json",
                     "json_each_row")
    """

    storage: str  # StorageType value: "s3" | "nfs"
    path: str  # s3: "bucket/key", nfs: absolute path
    data_format: str  # "parquet" | "json" | "csv" | "json_each_row"

    @staticmethod
    def s3(bucket: str, key: str, fmt: str) -> DataRef:
        return DataRef(
            storage=StorageType.S3,
            path=f'{bucket}/{key}',
            data_format=fmt,
        )

    @staticmethod
    def nfs(path: str, fmt: str) -> DataRef:
        return DataRef(
            storage=StorageType.NFS,
            path=path,
            data_format=fmt,
        )

    @property
    def uri(self) -> str:
        if self.storage == StorageType.S3:
            return f's3://{self.path}'
        return self.path

    @property
    def s3_bucket(self) -> str:
        if self.storage != StorageType.S3:
            raise ValueError(f'Not an S3 ref: {self.storage}')
        return self.path.split('/', 1)[0]

    @property
    def s3_key(self) -> str:
        if self.storage != StorageType.S3:
            raise ValueError(f'Not an S3 ref: {self.storage}')
        return self.path.split('/', 1)[1]

    @property
    def is_s3(self) -> bool:
        return self.storage == StorageType.S3

    @property
    def is_nfs(self) -> bool:
        return self.storage == StorageType.NFS


# ── Tenant & Cluster ───────────────────────────────────────────


@dataclasses.dataclass(frozen=True)
class TenantID:
    agency_uuid: str
    workspace_id: int

    @property
    def path_prefix(self) -> str:
        """S3/NFS path segment: '{agency_uuid}/{workspace_id}'."""
        return f'{self.agency_uuid}/{self.workspace_id}'


class Cluster(str, enum.Enum):
    LISBON = 'lisbon'
    TOKYO = 'tokyo'
    MONTANA = 'montana'


# ── LES Enums ──────────────────────────────────────────────────


class DateRangeType(str, enum.Enum):
    LIVE = 'live'
    AUTO = 'auto'
    MANUAL = 'manual'
    MAX = 'max'
    SYNC_HISTORICAL = 'sync_historical'
    CUSTOM = 'custom'
    CUSTOM_REFRESH_WINDOW = 'custom_refresh_window'
    LIFETIME = 'lifetime'


class LesFieldType(str, enum.Enum):
    STRING = 'string'
    DATE = 'date'
    BOOL = 'boolean'
    NUMBER = 'number'
    OBJECT = 'object'


class LesFieldKind(str, enum.Enum):
    METRIC = 'metric'
    DIMENSION = 'dimension'
    PROPERTY = 'property'
    DATE_KEY = 'date_key'


class ReportTypeClass(str, enum.Enum):
    DAILY = 'daily'
    MONTHLY = 'monthly'
    WEEKLY = 'weekly'
    LAST_DAY = 'last_day'
    LAST_DAY_INCREMENTAL = 'last_day_incremental'
    DEFAULT = 'default'


class WriteMethod(str, enum.Enum):
    OVERWRITE = 'overwrite'
    UPSERT = 'upsert'


class WriteScope(str, enum.Enum):
    BY_DATE_RANGE = 'by_date_range'
    WHOLE_DATA = 'whole_data'


class DuplicatesStatus(str, enum.Enum):
    NO_DUPLICATES = 'no_duplicates'
    VALID_DUPLICATES = 'valid_duplicates'
    INVALID_DUPLICATES = 'invalid_duplicates'


# ── Extract Types ──────────────────────────────────────────────

TCursorValue = datetime.date | datetime.datetime | int


@dataclasses.dataclass(frozen=True)
class DateRangeRequest:
    """Date range for LES extraction."""

    date_range_type: DateRangeType
    params: dict[str, Any]

    def __init__(self, **kwargs: Any) -> None:
        ttype = kwargs.get('date_range_type') or kwargs.get('type')
        object.__setattr__(
            self,
            'date_range_type',
            DateRangeType(ttype),
        )
        object.__setattr__(
            self,
            'params',
            kwargs.get('params') or kwargs.get('param'),
        )


@dataclasses.dataclass(frozen=True)
class SchemaField:
    type: LesFieldType  # noqa: A003
    name: str
    sql_name: str
    kind: LesFieldKind
    title: str
    required: bool = False
    dynamic: bool = False


@dataclasses.dataclass(frozen=True)
class CursorRange:
    min_value: TCursorValue
    max_value: TCursorValue


@dataclasses.dataclass(frozen=True)
class StageResult:
    name: str
    path: str
    raw_storage_path: str = ''
    cursor_range: CursorRange | None = None
    fields: list[SchemaField] | None = None


@dataclasses.dataclass(frozen=True)
class ReportTypeMeta:
    report_type_class: ReportTypeClass
    write_method: WriteMethod
    write_scope: WriteScope
    duplicates_status: DuplicatesStatus


@dataclasses.dataclass(frozen=True)
class LesActivityResult:
    stages: list[StageResult]
    result_stage_name: str
    report_type_meta: ReportTypeMeta
    result_stage_has_data: bool | None = None
    raw_responses_path: str = ''


@dataclasses.dataclass(frozen=True)
class LesS3UploadActivityParams:
    """Params for run_les_activity_with_s3_upload."""

    connector_id: int
    data_source: str
    report_type: str
    fields: list[str] = dataclasses.field(default_factory=list)
    date_range_request: DateRangeRequest | None = None
    args: dict[str, Any] = dataclasses.field(default_factory=dict)
    hashed_fields: list[str] = dataclasses.field(
        default_factory=list,
    )
    save_raw_data: bool = False
    raw_responses_exclude_request: bool = False


@dataclasses.dataclass(frozen=True)
class LesActivityWithS3Result:
    """Result of LES extraction with S3 upload."""

    executor_result: LesActivityResult
    s3_bucket: str = ''
    s3_key: str = ''
    data_format: str = 'json_each_row'

    @property
    def result_stage_has_data(self) -> bool | None:
        return self.executor_result.result_stage_has_data

    @property
    def data_ref(self) -> DataRef:
        if not self.s3_bucket:
            return DataRef.nfs(path='', fmt=self.data_format)
        return DataRef.s3(
            bucket=self.s3_bucket,
            key=self.s3_key,
            fmt=self.data_format,
        )


# ── Clean pipeline extract types ──────────────────────────────


@dataclasses.dataclass(frozen=True)
class ExtractParams:
    """Extract params for stub / lightweight extraction."""

    data_source: str
    report_type: str
    credentials_secret_key: str
    account_id: str
    date_from: str
    date_to: str
    fields: list[str] = dataclasses.field(default_factory=list)


@dataclasses.dataclass(frozen=True)
class ExtractResult:
    """Unified extraction result."""

    data_ref: DataRef
    rows_count: int
    date_from: str = ''
    date_to: str = ''
