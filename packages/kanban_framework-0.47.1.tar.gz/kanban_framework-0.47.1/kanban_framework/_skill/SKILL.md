---
name: kanban
description: "使用 /kanban 命令管理看板任务的全生命周期：初始化看板、创建 TASK-NNN 任务、执行阶段（plan/execute/evaluate）、归档完成、查看状态/进度、恢复中断任务、多迭代工作流。当用户提到 kanban、看板、TASK-NNN、/kanban 命令、任务创建/归档/恢复、或任何看板任务管理意图时使用此技能。"
---

# Kanban 多 Agent 编排系统

基于 FSM 的任务编排框架。编排器不直接管理流程，全部由状态机驱动。

## 命令约定

优先检测 `kanban` CLI（pip 安装），不可用时回退 `<py> -m kanban_framework`（`<py>` 为 config.json 中的 python_bin，默认 venv/bin/python）。

## 命令路由

**精确命令** 直接匹配，**自然语言** 通过 `kanban nlp` 解析后路由。

| 意图 | 条件 | 路由 |
|------|------|------|
| `work` | 有 task_id | `run` |
| `work` | 无 task_id 且无活跃任务 | 先 `create` 再 `run` |
| `work` | 无 task_id 但有活跃任务 | `run <active_task_id>`（关联到已有任务） |
| `query` | 含查询动词 | `status` / `show` |

**工作意图路由步骤：**
1. `kanban nlp "<用户输入>"` → 获取 intent / task_id / needs_active_task_check
2. 如果 `needs_active_task_check` 为 true → `kanban status` 检查是否有活跃任务
3. 有活跃任务 → 展示当前任务给用户确认，用户同意后 `kanban run <id>`
4. 无活跃任务或用户明确要新建：
   a. `kanban create "<title>" --json`（必须加 --json 才能读取 mode_confirmation_pending）
   b. 检查返回值 `mode_confirmation_pending`：
      - 为 true → **必须**用 AskUserQuestion 展示推荐模式给用户确认
      - 展示 `assessment.recommended_mode` 和 `assessment.reason` 作为说明
      - 用户确认后如需切换模式 → `kanban task edit <id> --mode full`
      - 用户无需切换 → 直接下一步
   c. `kanban run <id>`

**硬性约束：**
- `intent == "work"` 时禁止跳过 FSM 直接调用 skill。所有工作必须通过 `kanban create`/`kanban run` 进入框架
- **禁止跳过 `plan.knowledge_search` 步骤**。Full 和 Lightweight 模式的 Plan 阶段第一步都是知识库检索，编排器必须按 `next_step` 返回的 step 顺序执行，不得跳过

### 常用命令

```
# 项目初始化与维护
/kanban init                        # 初始化（首次必须执行：询问工号 → task_id_base）
/kanban hook install                # 安装 SessionStart hook（每次会话自动注入任务上下文）
/kanban update                      # 升级到最新稳定版 + 同步 skill 文件
/kanban update 0.27.0               # 安装指定版本
/kanban update --channel dev        # 升级到最新开发版（pre-release）
/kanban update --list               # 列出所有可用版本
/kanban update --channels           # 查看稳定版/开发版列表
/kanban check-env                   # 检查环境配置（python / agent sync / gitignore）

# 任务生命周期
/kanban create "<title>" --json [--mode full]  # 创建任务（必须 --json，检查 mode_confirmation_pending）
/kanban task edit <id> --mode full  # 切换为 full 模式
/kanban task edit <id> --auto-mode all  # 开启全自动模式
/kanban run <id>                    # 执行当前阶段
/kanban status                      # 看板状态（所有活跃任务）
/kanban show <id>                   # 任务详情
/kanban decide <id> --action <act>  # 用户决策（approve_and_archive 等）
/kanban clean <id>|--all            # 清理归档任务
/kanban recover [<id>]              # 崩溃恢复

# FSM 编排
/kanban workflow next-step <id>     # 获取下一步指令（状态机驱动，所有决策的权威来源）
/kanban workflow mark-step <id> <step_id>  # 标记步骤完成
/kanban workflow progress <id>      # 查看子步骤进度
/kanban workflow replan <id>        # 重置到 plan 阶段重生制品（用户主动要求时使用）

# 步骤控制（手动模式）
/kanban workflow steps <id>            # 查看所有步骤及状态
/kanban workflow run-step <id> <step>  # 执行指定步骤
/kanban workflow skip-step <id> <step> # 跳过步骤
/kanban workflow rollback <id> [step]  # 回退到指定步骤

# Inbox 反馈管理（独立于任务归档）
/kanban inbox add <id> "<text>"     # 添加反馈到任务 inbox.md
/kanban inbox process <id>          # 只读分析（scope 分类 + 冲突检测），不修改文件
/kanban inbox archive <id>          # 归档已验证的 [x] 条目到 inbox-archive.md
/kanban inbox add-subtasks <id>     # 从 inbox 分析结果生成补充 subtask

# 多窗口 subtask 协作
/kanban subtask claim <id> <st_id>  # 原子抢占 subtask（已 claim 的拒绝重复抢占）
/kanban subtask unclaim <id> <st_id>  # 释放 subtask 回 pending
/kanban subtask start <id> <st_id>  # claim + 标记 in_progress
/kanban subtask done <id> <st_id>   # 标记完成（可选 --commit-hash --files）
/kanban subtask status <id>         # 查看所有 subtask 状态（含 claimant 信息）

# Subtask 分工
/kanban subtask assign <id> <st_id> --owner ai|human
/kanban subtask assign-batch <id> --owner human --subtask ST-001,ST-003

# Dashboard 可视化管理
/kanban dashboard start             # 一键启动 Dashboard（自动 deploy + npm install）
/kanban dashboard stop              # 停止 Dashboard
/kanban dashboard status            # 查看运行状态

# 知识库
/kanban knowledge help                  # 查看所有子命令
/kanban knowledge help <sub>            # 查看单个命令详细帮助
/kanban knowledge hybrid <kw> --json    # 混合搜索（先看 summary，再用 get 取详情）
/kanban knowledge search <kw> --json    # 通用搜索
/kanban knowledge search <kw> --intent pitfall_check --json  # 意图驱动搜索
/kanban knowledge get <id>              # 获取单条完整详情
/kanban knowledge list                  # 列出知识条目
/kanban knowledge add ...               # 添加知识条目
/kanban knowledge backup                # 手动备份知识库

**完整参数参考**: [knowledge-cli-reference.md](references/knowledge-cli-reference.md)

**Token 控制**：`search/hybrid --json` 返回的 `results[]` 包含完整 content（可达数千字符/条）。
必须先用 `.data.summary`（仅 id + title + relevance）筛选出 2-3 条，再用 `get <id>` 取详情。
禁止直接消费 `.data.results[]` 的 content 字段。

# 其他
/kanban guard check-inbox <id>      # 检查 inbox 待处理 + 未验证项
/kanban guard check-pending-subtasks <id>  # 检查阻塞归档的 subtask 状态
```

---

## 核心编排循环（唯一流程控制方式）

编排器不做任何流程决策。所有决策由状态机 `next-step` 返回。

**上下文恢复：** 压缩后或新会话，先调用 `kanban workflow next-step <task_id>` 恢复状态，不凭记忆。

```
循环开始:
  1. result = kanban workflow next-step <task_id>
  2. 根据 result.step_type 执行（#314：显式路由信号，优先于其他字段）:
     - step_type == "spawn"
       → 必须用 Agent tool 启动 subagent
       → subagent_type = result.agent_type
       → prompt = result.spawn_prompt（保持原样，不修改）
       → 禁止编排器自行执行 spawn_prompt 中的 CLI 命令
     - step_type == "interactive"
       → 编排器直接处理，参考 result.interactive_prompt
     - step_type == "action"
       → 按顺序执行 result.actions 中的 CLI 命令
     - user_action == true → 展示信息，等待用户操作
  3. kanban workflow mark-step <task_id> result.step_id completed --session <subagent_id>
  4. 如 result.phase_complete → kanban workflow complete-phase <task_id>
  5. 如 result.all_complete → 结束
  6. 否则 → 回到 1
```

**编排器禁止行为：**
- 禁止跳过 next-step 自行决定下一步
- 禁止修改 subagent 的 spawn_prompt 内容
- 禁止在 subagent 完成后跟随其建议的后续步骤（subagent 只负责产出发配的文件）
- 禁止直接修改 task.json 的 phase 字段
- **禁止跳过 plan.knowledge_search** — Full/Light 模式 Plan 阶段第一步，必须执行知识库检索

**流程调度自检：** 每次 subagent 完成后，不要凭记忆判断下一步。先调用 `kanban workflow next-step <task_id>` 获取状态机的权威指令，再行动。长对话中模型容易遗忘当前阶段 — next-step 是恢复上下文的唯一可靠方式。

**next-step 返回的第一个步骤即当前阶段起点**，编排器必须从该步骤开始执行。例如 Plan 阶段返回 `plan.knowledge_search`，就必须先 spawn knowledge-capture agent，再进入 brainstorming。

**轻量模式说明：** 任务创建时自动检测模式。full 模式走完整阶段（含 Plan Review/QA Spec/Spec Review），lightweight 模式跳过这些阶段直接 Plan → Execute → Evaluate(QA only) → Archive。模式由 `next-step` 自动适配，编排器无需关注。

**FSM 校验：** `run`/`transition`/`complete-phase` 命令执行前会自动验证 FSM 状态，检测跳步。如果状态不一致会返回错误和修正指令，按修正指令操作即可。

## 模式说明

### Full vs Lightweight

| | Full | Lightweight |
|---|------|-------------|
| 触发 | 检测到重度信号自动启用 | **默认模式** |
| 阶段 | Plan → Plan Review → QA Spec → Spec Review → Execute → Evaluate → Self-Improve → Retrospective → User Decision → Archive | Plan → Execute → Evaluate(QA only) → User Decision → Archive |
| Plan 确认 | 需要 `user_confirm_spec` | **跳过**（brainstorming 已交互） |
| 适用 | 复杂功能、新模块、架构变更 | Bug 修复、小改动、脚本、配置 |

创建任务时自动推荐模式。用户可手动 `--mode full` 或 `--lightweight`。

`kanban create` 不指定 `--mode` 时，返回 `mode_confirmation_pending: true`。编排器应展示推荐模式给用户确认后再 `kanban run`。

### 人工决策点

不同模式下需要用户介入的步骤：

| 阶段 | 步骤 | 类型 | Full | Light |
|------|------|------|------|-------|
| 创建 | `mode_confirmation` | 确认推荐模式 | ✅ | ✅ |
| Plan | `plan.plan_A` | interactive — 多轮需求澄清 | ✅ | ✅ |
| Plan | `plan.user_confirm_spec` | user_action — 确认 spec.md | ✅ | — |
| Spec Review | `spec_review.user_confirm` | user_action — 确认测试用例 | ✅ | — |
| User Decision | `user_decision.wait` | user_action — approve/restart/abort | ✅ | ✅ |

**全自动模式**（`--auto-mode all`）：上述所有交互点由 kanban-auto-decider subagent 替代，无需人工介入。置信度 < 0.7 时降级回人工确认。

### 全自动模式 (Auto Mode)

人工决策点由 **kanban-auto-decider subagent** 替代，不跳过。flags: `brainstorm / iteration / lightweight / archive / worktree / all`。

```
/kanban create "title" --auto-mode all     # 全部自动
/kanban task edit <id> --auto-mode all      # 事后开启
```

auto-decider 置信度 < 0.7 时降级回人工确认。

### 全手动模式 (Manual Mode)

每次步骤完成后询问用户选择下一步。用户可随时回退或跳过步骤。

```
/kanban create "title" --control-mode manual
/kanban task edit <id> --control-mode manual
```

手动模式下，编排循环与半自动不同：

```
循环开始:
  1. kanban workflow next-step <task_id>
     → 返回 available_steps（依赖已满足 + 未完成的步骤列表）

  2. 展示可用步骤给用户选择

  3. 用户选择步骤后 kanban workflow run-step <task_id> <step_id>
     → 根据返回的 spawn_prompt / interactive / user_action 执行

  4. 步骤完成后 kanban workflow mark-step <task_id> <step_id>
  5. 用户可随时回退或跳过步骤
  6. 回到 1
```

步骤状态：`pending` → `completed` / `skipped`

## Inbox 反馈闭环

**inbox 反馈归档 ≠ 任务归档**。inbox archive 只操作 inbox.md → inbox-archive.md，不影响任务状态。

```
用户反馈 → inbox add → inbox process（只读分析）
  ├─ scope:current → 需实现 → 补充 subtask 或纳入 plan
  ├─ scope:conflict → 暂停，等用户决策
  └─ scope:next-task → 标记 migrated:TASK-NNN → 可归档

实现完成 → [x] 标注 done:<path> → inbox archive → inbox-archive.md
```

**归档必须带标签**：`done:<path>` / `migrated:<TASK-NNN>` / `wontfix:<reason>`。无标签的 `[x]` 被拒绝。

## 多窗口 subtask 协作

```powershell
# 窗口 1                             # 窗口 2
kanban subtask claim TASK-001 ST-001  kanban subtask claim TASK-001 ST-002
# → 原子抢占，ST-002 已被窗口 1 抢占则返回 claimed:false
# ... 编码 ...                        # ... 编码 ...
kanban subtask done TASK-001 ST-001   kanban subtask done TASK-001 ST-002

# 查看全局状态
kanban subtask status TASK-001
# → ST-001: completed | ST-002: in_progress (user2) | ST-003: pending
```

**无 worktree 隔离** — 用户自行判断文件冲突。同一个 subtask 不可被两个窗口同时 claim。

## Git 阶段检查点

每个阶段完成时自动 `git add -f` + `git commit`，task 数据不会因误删丢失。commit 格式: `checkpoint: <phase> (TASK-NNN)`。

`.kanban/` 不应全局 gitignore —— 只排除运行时目录（`.kanban/dashboard/`, `.kanban/reports/`, `.kanban/skills/`），保留 `tasks/` 和 `archive/` 可追踪。

## spawn_prompt 变量

`next-step` 返回的 `spawn_prompt` 中可能包含以下变量，编排器无需替换（已由状态机处理）：

| 变量 | 含义 |
|------|------|
| `$task_id` | 任务 ID |
| `$task_dir` | 任务目录路径 |
| `$report_dir` | 当前迭代报告目录路径 |
| `$iteration` | 当前迭代编号 |

## 结构化交接（summary + metadata）

Agent 在完成阶段任务后，必须产出结构化交接信息，供下游阶段和重试 agent 使用。

### 完成时写 summary + metadata

Agent 在 execution_summary.md 或评审报告中写入以下字段：

```json
{
  "summary": "一句话描述本阶段完成了什么",
  "metadata": {
    "changed_files": ["修改的文件列表"],
    "decisions": ["关键决策列表"],
    "tests_run": 11,
    "errors": ["遇到的问题和解决方式"]
  }
}
```

### Worker Context（自动注入）

状态机在生成 spawn_prompt 时，自动读取以下上下文并注入到 prompt 末尾：

1. **历史执行记录** — 当前任务之前的所有 run（含失败原因、决策）
2. **上游阶段交接** — 已完成阶段的 summary + metadata

Agent 在 spawn 后应先阅读 Worker Context 章节，在上一次工作的基础上继续，避免重复已失败的路径。

### 重试时的工作方式

当 evaluate 评分不通过导致回退重做时：
- 新 agent 的 prompt 自动包含上一轮的 error + summary
- Agent 应针对性修复上一轮指出的问题，而非从头重做
- 在 metadata.decisions 中记录本轮相比上一轮的变更

## 阶段交接记录

编排器在 `complete-phase` 后调用 `kanban workflow record-handoff` 记录结构化交接。
写入 task.json 的 history 数组，包含 summary、metadata、completed_at。

详见 `rules/workflow-json-reference.md` 中的 handoff 字段说明。

## References 路由

SKILL.md 是操作手册。以下 reference 文档按需加载，遇到对应场景时 Read 获取完整信息：

| 场景 | 文档 | 触发条件 |
|------|------|----------|
| 命令实现细节 | `references/commands.md` | 实现 CLI 命令、修改命令行为、调试命令参数解析 |
| 配置字段含义 | `references/config-json-reference.md` | 修改 config.json、调整超时/预算/调度/并行参数 |
| 工作流字段含义 | `references/workflow-json-reference.md` | 修改 workflow.json、增减 phase/agent、调整 quality_gate |
| 知识库在 FSM 中使用规范 | `references/knowledge-usage-in-fsm.md` | 各阶段检索/引用/评估/缺口分析的完整流程和产出格式 |
| 知识库在 FSM 中的角色 | `references/knowledge-role-in-fsm.md` | 理解知识库在各阶段的作用、何时自动注入、何时 agent 主动搜索 |
| 知识库积累策略 | `references/knowledge-accumulation-guide.md` | 实现知识条目自动提取、平衡积累与噪音、避免知识污染 |
| 模式对比 (Full/Light/Custom) | `references/mode-comparison.md` | 理解三种模式的流程差异、步骤对比、Guard 检查、选择依据 |
| 语言约定 | `references/language-convention.md` | 不确定产物应使用中文还是英文 |
| 版本命名规范 | `references/version-naming-convention.md` | 创建版本记录文件、检查命名格式合法性 |
| 对接外部知识库 | `references/external-knowledge-backend-integration.md` | 接入新的开源知识库后端（txtai/LanceDB/Qdrant等）、实现 KnowledgeBackend 适配器 |
| **用户上手文档** | **`references/user-guide.md`** | **框架所有可自定义配置、命令速查、模式选择、知识库/统计后端切换** |
| 踩坑经验与迭代心得 | `references/lessons-learned.md` | 开发过程中发现的关键问题和解决方案，避免重复踩坑 |
| Dashboard 统计算法 | `references/dashboard-stats-algorithm.md` | 理解全局/单任务统计的数据源、采集算法、渲染逻辑、后端切换 |

**使用方式**：agent 在执行任务前，先检查此表 —— 若任务涉及上述任一场景，Read 对应文档后再动手。不要凭记忆猜测字段名或默认值。

## 知识库备份

知识库启动时自动备份 `knowledge.db`（最多 1 次/小时），保留最近 5 个版本：

```
.kanban/knowledge/
├── knowledge.db           # 当前
├── knowledge.db.bak.1    # 最新备份
├── knowledge.db.bak.2    # 上一轮
├── ...
└── knowledge.db.bak.5    # 最旧（满 5 个后滚动删除）
```

手动备份：`kanban knowledge backup`

## 知识库后端切换

知识库通过中间层抽象支持可插拔后端。默认使用 BuiltinBackend（SQLite FTS5 + chroma 向量），可通过 `config.json` 切换：

```json
{
  "knowledge": {
    "backend": "builtin"
  }
}
```

切换后端后，agent prompt 和 CLI 命令不变，旧知识数据保留在 builtin 后端不丢失。

新后端只需实现 `KnowledgeBackend` Protocol 的 6 个方法即可接入。详见 `references/knowledge-accumulation-guide.md`。

## 知识检索意图（--intent）

Agent 调用知识库时应指定检索意图，中间层根据意图选择最优策略：

| Intent | 策略 | 场景 |
|--------|------|------|
| `pitfall_check` | 加权 severity=high + category=踩坑 | 编码前查已知问题 |
| `constraint_lookup` | 精确匹配 tags + source.file | 设计阶段约束检查 |
| `experience_reuse` | 语义相似度 + domain 加权 + 引用热度 | 新任务复用历史经验 |
| `general` | 标准 hybrid search（默认） | 通用查询 |

用法：`kanban knowledge search "auth" --intent pitfall_check`

## 步骤提示词注入（prompt_hooks）

通过 `config.json` 向特定阶段/步骤注入项目定制化提示词：

```json
{
  "prompt_hooks": {
    "qa_spec": "本项目用 Playwright E2E，测试文件放 tests/e2e/",
    "execute": "所有代码须通过 ruff check 和 mypy --strict",
    "execute.spawn": "数据库操作用 SQLAlchemy 2.0 async 模式",
    "plan.plan_A": "优先评估 FastAPI + Redis 方案"
  }
}
```

- **phase 级别**：对 `plan`/`execute`/`evaluate` 等阶段的所有步骤生效
- **step 级别**：对 `qa_spec.spawn`/`execute.spawn` 等具体步骤生效（优先）
- agent spawn_prompt 末尾自动追加
