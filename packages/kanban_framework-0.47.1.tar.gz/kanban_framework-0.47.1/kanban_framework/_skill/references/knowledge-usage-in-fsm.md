# 知识库在流程步骤中的使用规范

本文档详细说明知识库在 FSM 各阶段的检索、引用、评估和缺口分析机制。

> 最后更新: v0.39.0, 2026-05-24

---

## 一、知识库使用全景图

```
创建任务 → 自动搜索建议
    ↓
Plan A → 强制检索 → 产出 knowledge_used.json
Plan B → subtask 文件引用知识条目
    ↓
Plan Review → 知识引用交叉验证
    ↓
Execute → 踩坑预警 + 实时知识贡献
    ↓
Retrospective → 知识提取 + 审计
    ↓
Archive → 知识入库 + 缺口分析
```

---

## 二、各阶段详解

### 1. 创建任务（create）

`kanban create` 自动搜索知识库，返回 `knowledge_hints`。

**产出**: 无文件，仅展示给用户参考。

### 2. Plan A — 需求澄清

`plan.knowledge_search` 步骤 (Full + Light)：

1. spawn kanban-knowledge-capture agent
2. 执行 `kanban knowledge hybrid "<任务标题>" --json`，只看 `.data.summary` 筛选相关条目
3. 对筛选出的条目执行 `kanban knowledge get <id>` 取完整详情
4. 无结果时 `kanban knowledge search "<关键词>" --intent experience_reuse --json`
5. 产出 `plan/knowledge_used.json`

Token 控制：**禁止直接消费 --json 返回的 .data.results[] 的 content 字段**，必须通过 summary → get 两步走。

**产出文件格式**:
```json
{
  "matched": [
    {
      "id": "K001",
      "title": "JWT 认证模式",
      "relevance": "high",
      "how_to_apply": "当前任务实现 token 刷新时应参考此模式，避免 token 过期未处理问题"
    }
  ],
  "search_queries": ["hybrid: JWT 认证模块 token 刷新"],
  "no_match_reason": null
}
```

**Guard 检查**: `plan/knowledge_used.json` 存在且非空，否则无法进入下一阶段。

### 3. Plan B — 任务拆解

Subtasks 文件 (`plan/ST-NNN_*.md`) 必须引用知识条目：

```markdown
# ST-001: JWT Token 刷新实现

知识库参考:
  [K001] JWT 认证模式 — 避免 token 过期未处理
  [K005] refresh token 单次使用 — 防重放攻击
```

### 4. Plan Review — 知识引用验证

`plan_review.knowledge_cross_validate` 步骤评分：

| 维度 | 检查内容 |
|------|---------|
| 检索完整性 | knowledge_used.json 是否存在且非空 |
| 引用到位率 | plan/*.md 中引用的 K-NNN 条目是否覆盖了 high+medium |
| 应用合理性 | 引用是否体现在 subtask 内容中（非形式化引用） |

### 5. Execute — 编码前预警 + 实时贡献

- 自动注入: `_auto_knowledge_retrieval()` → 搜索踩坑/反模式 → 注入 spawn_prompt
- 实时贡献: 发现通用模式时 `kanban knowledge add` 立即写入

### 6. Retrospective — 知识提取

- 审计 execute 实时写入的条目
- 从 execution_pitfalls.md / execution_decisions.md 提取新知识

### 7. Archive — 入库 + 缺口分析

- `knowledge_extracted.json` → 导入 `knowledge.db`
- 去重检查 (同 title + domain)
- 记录 knowledge health gaps

---

## 三、知识缺口分析

### 当前机制

`KnowledgeManager.get_knowledge_gap_report()` 检查每个 domain 的知识条目密度。

### 期望增强

1. **从 spec.md 提取领域关键词** → 对比知识库现有 domain
2. **从 plan 知识引用分析** → 统计哪些 knowledge ID 被引用但标记为 low 关联度 → 可能缺少该领域的深度知识
3. **从 knowledge_used.json 的 no_match_reason** → 识别"全新领域、无相关经验" → 提示补充

### 实现优先级

1. `archive` 阶段自动读取 `knowledge_used.json` 的 `no_match_reason`
2. `knowledge gaps` 命令增加 "uncovered_domains" 维度
3. Dashboard 展示知识缺口面板
