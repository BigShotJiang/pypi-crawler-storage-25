# 踩坑经验与迭代心得

> 记录框架迭代过程中发现的关键问题和解决方案，避免重复踩坑。
> 最后更新: v0.46.1, 2026-05-25

---

## 1. Dashboard 部署与版本同步

### 问题

`pip install kanban-framework` 后 dashboard 文件不会自动更新到 `.kanban/dashboard/`。`kanban dashboard start` 检测到 `.framework_version` 与包版本不一致时才强制 redeploy，但如果 dashboard 从未部署过，`kanban update` 会跳过 deploy。

### 解决

- `kanban update` 必须无条件调用 `DashboardManager.deploy()`，不做前置检查
- `.framework_version` marker 记录部署版本，版本不匹配时 `_sync()` 强制覆盖
- editable install 环境与 pip 安装环境行为不同，测试时需注意

### 影响版本

v0.33.0 ~ v0.36.1

---

## 2. API 调用统计：主 Session vs Subagent Session

### 问题

使用 `CLAUDE_CODE_SESSION_ID` 追踪任务 API 调用时，该 session ID 是整个 Claude Code 进程的 ID，跨多个任务，甚至跨天。统计结果严重偏高（全天数万次调用全归给一个 task）。

### 解决

改用 subagent session ID。kanban 每次 spawn agent 都是独立 session，该 session 的全部 JSONL 条目完全属于该 task 的该 step。
- `kanban track --session <subagent_id> --step <step_id>`
- `countSubagentEntries()` 直接数 subagent JSONL 文件行数
- 无需时间窗口匹配

### 关键代码

`dashboard/server.js`: `countSubagentEntries()`, `session_steps` 映射

---

## 3. JSONL 时间窗口统计的陷阱

### 问题

当 `kanban track` 没有记录时，从 JSONL 时间窗口估算 API 调用看似合理，但有几个致命缺陷：

1. **并行任务重叠**：两个 task 同时运行，同一时间窗口的调用被算两次
2. **History 时间戳分离**：`started_at` 和 `completed_at` 在不同 history 条目中，需要跨条目配对
3. **JSONL 扫描性能**：每次请求都扫描全部 JSONL 文件（5 万行），导致 API 超时

### 解决

- 优先使用 subagent session 直接计数（方案 2），JSONL 窗口仅作为 fallback
- 跨条目配对用 phase 级别的 `min/max` 窗口
- 启动时建立 JSONL 时间戳索引缓存，每 5 分钟刷新

### 关键代码

`dashboard/server.js`: `getJSONLIndex()`, `countLLMCallsInWindow()`

---

## 4. Context Rot：知识注入越多，质量越差

### 问题

Plan/Execute 阶段注入 8 条知识条目（~1000 tokens），反而导致编码质量下降。根因：
- 注意力稀释（LLM 的 U 形注意力曲线）
- 噪声条目干扰（低相关、过时、重复条目）
- 知识条目与模型预训练模式冲突

### 解决

- 注入量从 8 条降到 3 条
- 按阶段分类过滤（plan: 架构/接口, execute: 踩坑/优化）
- 同 domain 去重，只保留最高分
- score threshold 过滤低相关条目
- category/severity 标准化以支持精确过滤

### 参考

- Chroma Research: Context Rot
- Liu et al.: Lost in the Middle (arXiv 2307.03172)

---

## 5. 知识库分类自由文本的危害

### 问题

`category` 和 `severity` 是自由文本，agent 随意填写导致：
- 分类不一致（同一概念用不同名称）
- 检索加权失效（不同 category 无法区别对待）
- 知识条目质量难以控制

### 解决

- `VALID_CATEGORIES`：8 种标准分类（架构/踩坑/反模式/最佳实践/优化/流程/接口/工具）
- `VALID_SEVERITIES`：3 种标准严重度（high/medium/low）
- `add_entry()` 写入时强制校验，拒绝非法值
- `kanban knowledge categories` CLI 查看合法选项

### 影响

修改了核心 API 行为，agent prompt 需同步更新引用标准分类名。

---

## 6. 中间层设计：Protocol > 猜测

### 经验

为知识库后端设计 `KnowledgeBackend Protocol` 是正确的决策。它使：
1. 本地/共享知识库共存（`MultiBackend`）
2. 不同存储引擎透明切换（`BuiltinBackend`, `MemoryBackend`, `ShareBackend`）
3. 新后端独立验证（写出 23 行 MemoryBackend 就验证了协议可用性）

### 向后端适配的限制

- LightRAG 等依赖外部 LLM 的后端不适用于零依赖场景
- 文档→图谱（LightRAG）与结构化条目→搜索（Builtin）的 API 语义不同，适配层需要额外翻译

---

## 7. BDD 场景与回归测试

### 经验

每次 issue 修复必须同步：
1. BDD 场景到 `.kanban/acceptance/07-knowledge-base.md`（或对应模块）
2. 单元测试到 `test/test_domain/test_knowledge.py`
3. 更新 `INDEX.md` 场景总数

否则后续改动容易让已修复的 issue 回归。

### 当前状态

- BDD: 170 场景
- 测试: 477+ 回归测试
- 模块 7 知识库覆盖最全（57 场景）

---

## 8. GitHub Actions 发布延迟

### 问题

PyPI 发布偶尔在 GitHub Actions 中排队数小时（v0.34.0 ~ v0.36.0 均有此现象）。

### 缓解

- `gh run list` 查看状态，complete 即表示已发布
- 如果一直 queued，可能是 GitHub 公共 runner 资源紧张
- 未找到根本解决方案，属于外部依赖问题

---

## 9. 版本迭代节奏

### 经验

- 每修复 2-3 个问题就发一个版本，不攒 batch
- 开发版用 `0.x.0a1`（alpha）打 tag，`kanban update --channel dev` 安装
- 当前节奏：v0.27.0 → v0.37.1（24 小时内 10 个大版本）

---

## 10. 包名 vs CLI 命令名 vs 模块名：三者的区别

### 问题

用户/开发者在另一台设备通过 `pip install kanban-framework` 安装后，发现 `.claude/skills/kanban/kanban_framework/` 目录不存在，误以为被移除。同时 CLI 实际命令是 `kanban`（Windows 为 `kanban.exe`），而非 `kanban-framework`，容易混淆。

### 根因

框架涉及三个不同的名称，容易混淆：

| 概念 | 值 | 定义位置 | 作用 |
|------|-----|---------|------|
| PyPI 包名 | `kanban-framework` | `pyproject.toml [project].name` | `pip install kanban-framework` |
| CLI 命令名 | `kanban` | `pyproject.toml [project.scripts]` | `kanban init` / `kanban status` |
| Python 模块名 | `kanban_framework` | 包目录名 | `python -m kanban_framework` |

**另一台设备 `kanban_framework/` 目录"消失"的原因：**

pip 安装将包放在 `site-packages/kanban_framework/`，**不会**在 `.claude/skills/kanban/` 下创建该目录。`kanban init` 只同步 `_skill/` 子目录的文件（SKILL.md、agents、rules）到 `.claude/skills/kanban/`，不同步整个 Python 包。

开发者机器（源码 clone + `pip install -e .`）有 `.claude/skills/kanban/kanban_framework/` 是因为那是源码目录本身；用户机器（纯 pip 安装）不存在这个路径是**正常的**。

### 验证方法

```bash
# 构建 wheel 检查打包内容
python -m build --wheel -o /tmp/test .
unzip -l /tmp/test/kanban_framework-*.whl | grep -E "_skill|dashboard"

# 确认安装位置
pip show -f kanban-framework | head -5
```

构建产物确认：`_skill/`（32 个文件）和 `dashboard/`（28 个文件）全部包含在 wheel 中，`pip install` 后完整存在于 `site-packages/kanban_framework/`。

### SKILL.md 的 CLI 回退机制

```
优先: kanban CLI（pip 生成的 entry point）
回退: <py> -m kanban_framework（<py> 来自 config.json 的 python_bin）
```

回退存在的原因：`kanban` 命令依赖 PATH（venv 未激活时找不到），而 `<py> -m kanban_framework` 使用 config.json 中配死的 Python 绝对路径，不依赖 PATH。这是 PATH 依赖 vs 绝对路径的兜底设计。

### 影响

无需代码修改。仅作为排查参考——当用户报告"目录不存在"或"命令找不到"时，先区分安装方式（源码 vs pip）和预期目录位置。

---

## 11. editable install (-e) 导致的文件同步差异

### 问题

开发者在本地使用 `pip install -e .`（editable 模式）安装后一切正常，但另一台设备用 `pip install kanban-framework`（正常模式）安装后，`kanban init` 同步的 `references/` 文件数量不一致。

### 根因

`find_skill_dir()` 在两种安装模式下返回不同路径：

| 安装方式 | `find_skill_dir()` 返回 | `references/` 文件数 |
|---------|------------------------|---------------------|
| `pip install -e .` (editable) | `pkg_dir.parent` = `.claude/skills/kanban/` | 14 个（完整） |
| `pip install kanban-framework` (normal) | `pkg_dir / "_skill"` = `site-packages/.../kanban_framework/_skill/` | 7 个（缺失） |

`_skill/references/` 是 `references/` 的子集——有 7 个文件只在源码的 `references/` 中存在，没有同步到 `_skill/references/`：

```
缺失文件：
- dashboard-stats-algorithm.md
- external-knowledge-backend-integration.md
- knowledge-cli-reference.md
- knowledge-role-in-fsm.md
- knowledge-usage-in-fsm.md
- mode-comparison.md
- user-guide.md
```

### 根本原因

`_skill/` 目录是手动维护的"打包镜像"——每次新增 `references/` 文件时，需要手动同步到 `_skill/references/`，但这个过程没有自动化检查，容易遗漏。

### 解决方案

**方案 A（推荐）：发布前自动校验**
- 在 CI 或 `kanban update` 中增加校验步骤：比较 `references/` 和 `_skill/references/` 的文件列表，有差异则报错

**方案 B：消除双份维护**
- 将 `references/` 的源文件直接放在 `_skill/references/`，`.claude/skills/kanban/references/` 改为 symlink 指向 `_skill/references/`
- 这样只有一份源文件，不可能不同步

### 影响

当前已发布的 v0.46.1 及之前版本，正常 pip 安装的用户缺少 7 个 reference 文件。需要补充同步并在下个版本发布。
