# Dashboard 统计算法

完整记录 Dashboard 所有统计数据的采集、计算、展示算法。随代码迭代同步更新。

> 最后更新: v0.37.1, 2026-05-23

---

## 数据层级总览

```
Dashboard 页面
├─ 左侧 Stats 面板（全局统计）
│   ├─ 数据源: ~/.claude/projects/<hash>/*.jsonl
│   ├─ 后端: NativeBackend / CodeBurnBackend
│   └─ API:  GET /api/token-stats → 数字卡片 + 时序图
│
├─ 右侧任务详情（单任务统计）
│   ├─ 精确路径:  kanban track CLI → token_tracking.json → subagent JSONL 计数
│   ├─ 估算路径:  无 track 数据 → JSONL 索引缓存 → 时间窗口估算
│   └─ API:  GET /api/tasks/:id/stats → Phase 表格 + Steps 列表
│
└─ 时序图表（左侧趋势图）
    ├─ 数据源: tokenStats.daily
    └─ 渲染: useTokenChart composable (Canvas 2D × 2)
```

---

## 一、全局统计

### 1.1 数据采集 — NativeBackend

文件: `infra/stats_backend.py`

```
1. 项目匹配
   - 项目根路径 → 转换 / → -、_ → -
   - 在 ~/.claude/projects/ 下找包含路径名的目录
   - 多匹配时选 JSONL 文件最多的目录

2. Session 文件扫描
   - 遍历匹配目录下 *.jsonl（排除 subagents/、node_modules/）
   - 每个 sessionId 只计数一次
   - 每行 JSONL = 一次 Claude Code 操作调用

3. 每日聚合
   - 提取 timestamp → 判断是否在 days 范围内
   - 按日期分组累计 daily[{date, calls}]

4. 模型分布（来自 stats-cache.json）
   - 全局数据，反映所有项目使用的模型比例
   - modelUsage → by_model{model: {tokens, calls}}
```

### 1.2 API 响应

```
GET /api/token-stats → {
  total_prompt_calls, sessions,
  by_model, daily, source
}
```

### 1.3 前端渲染

| 组件 | 文件 | 内容 |
|------|------|------|
| StatsOverview | `StatsOverview.js` | 数字卡片（Tasks/Plan/Execute/Evaluate/Avg Score/Prompt Calls/Tokens） |
| TokenChart ×2 | `useTokenChart.js` | 分离的 Token 消耗图和 Prompt 次数图 |

---

## 二、单任务统计

单任务有两种数据来源，优先级递减：

| 优先级 | 来源 | 精确度 | 何时生效 |
|--------|------|--------|---------|
| 1 | `kanban track` CLI + Subagent JSONL | 精确 | 编排器调用了 `kanban track` |
| 2 | JSONL 索引缓存 + 时间窗口 | 估算 | `token_tracking.json` 无该 task 数据 |

Dashboard `/api/tasks/:id/stats` 自动判断：有 tracked 数据用方案 1，无则 fallback 方案 2。

---

### 2.1 精确路径：kanban track + Subagent 计数

#### 数据写入

编排器每次 spawn agent 完成后调用：

```bash
kanban track <task_id> <phase> <tokens> \
  --agent <agent_type> --model <model> --duration <seconds> \
  --step <step_id> --session <subagent_id>
```

#### TokenTracker 存储

文件: `.kanban/reports/token_tracking.json`

```json
{
  "TASK-NNN": {
    "by_phase": {"plan": 120000, "execute": 650000},
    "total_tokens": 792000,
    "agent_totals": {"kanban-planner": 120000, "kanban-executor": 650000},
    "by_model": {"deepseek-v4-pro": 770000},
    "prompt_count": {"plan": 1, "execute": 1},
    "total_prompts": 7,
    "phase_duration": {"plan": 245, "execute": 1020},
    "sessions": ["agent-a084e62785879e644"],
    "session_steps": {"execute.spawn": ["agent-a084e62785879e644"]},
    "session_phases": {"execute": ["agent-a084e62785879e644"]}
  }
}
```

#### API 调用计数

`countSubagentEntries(subagent_id)`:
1. 在 `projects/<hash>/*/subagents/` 下搜索 `agent-{subagent_id}.jsonl`
2. 统计该 JSONL 文件的全部行数
3. 归入对应 step 的 `step_api_calls` 和对应 phase 的 `phase_api_calls`

**为什么用 subagent 而非主 session**:

| 方式 | 问题 |
|------|------|
| 主 session (`CLAUDE_CODE_SESSION_ID`) | 跨 task、跨天，把全天调用全算给一个 task |
| 时间窗口匹配 | 并行 task 重叠时无法区分 |
| Subagent session ✅ | 一个 subagent = 一个 step，完全隔离 |

---

### 2.2 估算路径：JSONL 索引缓存 + 时间窗口

当 `token_tracking.json` 中没有该 task 的数据时，自动启用估算。

#### JSONL 索引缓存

`getJSONLIndex()`:
- Dashboard 启动时首次调用，扫描项目所有 JSONL 文件
- 提取全部 `timestamp` → 排序存入数组
- 每 5 分钟自动刷新
- 后续查询都是内存操作，无需再读文件

#### 时间窗口估算

```
1. 读取 task history:
   - 每个 phase 取所有 timestamp（started_at + completed_at）→ 建立 [min, max] 窗口
   - 跨条目配对: started_at 和 completed_at 在不同 history 条目中也能正确成对

2. 统计 API 调用:
   - real_api_calls = 全窗口内匹配的 JSONL 条目数
   - phase_api_calls[ph] = 该 phase 窗口内匹配数
   - step_api_calls[sid] = progress.json 步骤完成时间前 5 分钟内匹配数

3. Token 估算:
   - total_tokens = real_api_calls × 800（每 API 调用约 800 tokens）
   - phases[ph] = phase_api_calls[ph] × 800
   - 标注 _source = "jsonl_estimate"
```

#### 估算的限制

| 能估算 | 不能估算 |
|--------|---------|
| API 调用次数（± 精度） | 实际 token 消耗（仅粗略比例） |
| Per-phase API 分布 | Per-phase 耗时（无数据源） |
| Per-step API 分布 | 模型分布（全局才有） |

---

### 2.3 API 响应

```
GET /api/tasks/:id/stats → {
  tokens: {
    total_tokens,           // 总计 token（精确 or 估算×800）
    phases: {ph: tokens},   // per-phase token（精确 or 估算）
    agents: {ag: tokens},   // per-agent token（仅精确路径有）
    models: {m: tokens},    // per-model token（仅精确路径有）
    total_prompts,          // agent spawn 总数
    prompt_count: {ph: n},  // per-phase spawn 数
    phase_duration: {ph: s},// per-phase 耗时（仅精确路径有）
    phase_api_calls: {ph: n}, // per-phase API 调用
    step_api_calls: {sid: n}, // per-step API 调用
    real_api_calls,         // 总计 API 调用
    _source,                // "subagent_tracked" | "jsonl_estimate"
    _note                   // 说明文字
  },
  timing: { phases, agents, total_seconds },
  steps: { sid: { status, description, agent_type } },
  subtasks: [...],
  totalPromptCalls, stepTokens
}
```

---

### 2.4 前端渲染

#### Phase Breakdown 表格

四列: Phase | Tokens | Duration | API Calls + 汇总行

- 精确模式: 显示 `kanban track` 记录的 token + duration + API calls
- 估算模式: 显示 JSONL 估算的 token + API calls，duration 为 0s
- 底部标注来源: "Tracked via kanban track" 或 "ⓘ Estimated from JSONL"

#### Steps 列表

每步显示: 状态 ✓/↻/· + step 短名 + agent_type badge + 状态文本 + token + API calls (📞)

---

## 三、时序图表

文件: `useTokenChart.js`

- **Token 消耗图**: 橙色面积图，单位 K，数据来自 `daily[].tokens`
- **Prompt 次数图**: 蓝色面积图，单位次，数据来自 `daily[].calls`
- 自动跟随页面明暗主题 (`data-theme`)
- X 轴日期标签自动疏密（每 N 个显示一个）

---

## 四、StatsBackend 中间层

文件: `infra/stats_backend.py`

```json
// config.json
{ "stats": { "backend": "native", "days": 30 } }
```

| Backend | 数据源 | 依赖 |
|---------|--------|------|
| `native` | JSONL + stats-cache.json | 零依赖 |
| `codeburn` | codeburn CLI | 需安装 codeburn |

Dashboard 通过 `kanban stats --json` CLI → `resolve_stats_backend()` 选择后端。

---

## 五、配置文件位置

| 文件 | 用途 |
|------|------|
| `~/.claude/stats-cache.json` | Claude Code 全局聚合统计（模型分布） |
| `~/.claude/projects/<hash>/*.jsonl` | 本项目 session 操作日志 |
| `~/.claude/projects/<hash>/*/subagents/agent-*.jsonl` | 子 agent session 日志 |
| `.kanban/reports/token_tracking.json` | kanban per-task 精确追踪数据 |
| `.kanban/dashboard/.framework_version` | 仪表板部署版本标记 |

---

## 六、更新记录

| 日期 | 变更 |
|------|------|
| 2026-05-22 | 初始版本 |
| 2026-05-22 | model + prompt_count + phase_duration |
| 2026-05-22 | 项目范围过滤 |
| 2026-05-22 | subagent session 直接计数（替代时间窗口） |
| 2026-05-22 | per-step 粒度 |
| 2026-05-23 | JSONL 索引缓存（性能优化） |
| 2026-05-23 | phase 窗口跨条目配对修复 |
| 2026-05-23 | 估算路径 per-phase token 填充（对齐总行） |
| 2026-05-23 | 精确/估算双路径文档化 |
