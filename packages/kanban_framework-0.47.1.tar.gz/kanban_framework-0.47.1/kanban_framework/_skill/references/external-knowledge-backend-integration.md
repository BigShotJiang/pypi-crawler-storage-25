# 外部知识库后端接入指南

kanban 知识库通过中间层抽象支持可插拔后端。本文档指导如何将外部开源知识库项目接入 kanban。

## 架构

```
CLI / Agent prompt（不变）
    kanban knowledge search "auth 踩坑" --intent pitfall_check
        ↓
KnowledgeManager（API 层 + intent 路由）
        ↓
KnowledgeBackend（Protocol，6 个方法）
    ├─ BuiltinBackend    → SQLite FTS5 + chroma（默认）
    ├─ MemoryBackend     → 纯 dict（测试用）
    ├─ ChromaDBBackend   → 纯向量检索
    └─ CustomBackend     → 你的适配器（见下文）
```

## 快速开始

### 1. 实现 KnowledgeBackend Protocol

新建文件 `kanban_framework/domain/my_backend.py`，实现 6 个方法：

```python
from kanban_framework.domain.knowledge_backend import KnowledgeBackend

class MyBackend:
    """接入 XXX 知识库的后端适配器。"""

    def __init__(self, knowledge_manager=None):
        # 初始化你的后端客户端
        ...

    def search(self, keyword: str, limit: int = 20) -> list[dict]:
        """关键词搜索。返回 [{id, title, content, score, domain, category, ...}]"""
        ...

    def search_semantic(self, query: str, limit: int = 20) -> list[dict]:
        """语义搜索。"""
        ...

    def search_hybrid(self, keyword: str, limit: int = 20) -> list[dict]:
        """混合搜索（关键词 + 语义融合）。"""
        ...

    def add_entry(self, **kwargs) -> dict:
        """添加条目。kwargs 包含 id, title, content, domain, category, severity, tags, code_example 等。"""
        ...

    def list_entries(self, domain=None, category=None, status="active",
                     limit=50, offset=0) -> list[dict]:
        """列出条目，支持过滤。"""
        ...

    def get_entry(self, entry_id: str) -> dict | None:
        """获取单条。"""
        ...
```

### 2. 注册到 BACKEND_REGISTRY

编辑 `kanban_framework/domain/knowledge_backend.py`：

```python
from kanban_framework.domain.my_backend import MyBackend

BACKEND_REGISTRY = {
    "builtin": BuiltinBackend,
    "memory": MemoryBackend,
    "chromadb": ChromaDBBackend,
    "my_backend": MyBackend,   # 新增
}
```

### 3. config.json 切换

```json
{
  "knowledge": {
    "backend": "my_backend"
  }
}
```

重启后生效，agent 无感知。

## 已验证的后端

| 后端 | 行数 | 特点 | 验证状态 |
|------|------|------|---------|
| **BuiltinBackend** | ~30 | SQLite FTS5 + chroma 混合检索，默认 | 生产使用 |
| **MemoryBackend** | 23 | 纯 dict 存储，零依赖 | 协议验证通过 |
| **ChromaDBBackend** | 25 | 纯 chroma 向量优先检索 | 检索对比通过 |

## 候选开源项目对接评估

| 项目 | Stars | pip install | 对接难度 | 增量价值 | 建议 |
|------|-------|------------|---------|---------|------|
| **txtai** | 12.6k | `pip install txtai` | 低 (30行) | 端侧 embedding + 图索引 | ✅ 推荐 |
| **ChromaDB** | 已依赖 | 已安装 | 极低 (25行，已完成) | 纯向量检索对比 | ✅ 已验证 |
| **LanceDB** | 4k | `pip install lancedb` | 低 (30行) | 列式存储 + SQL 过滤 | ✅ 推荐 |
| **Qdrant** | 16k | `pip install qdrant-client` | 中 (50行) | payload 过滤混合搜索 | 可尝试 |
| **UltraRAG** | 5.5k | 需 pip install | 中 (50行，MCP协议) | MCP 原生 + YAML 编排 | 可尝试 |
| **LightRAG** | 8k | `pip install lightrag-hku` | 高 (需要 LLM + Python 3.10+) | 图检索增强 | 待环境成熟 |
| **RAGFlow** | 81k | Docker 部署 | 高 (HTTP API) | 深度文档理解 | 待评估 |
| **KAG** | 新星 | Java 引擎 | 高 | 逻辑引导推理 | 暂不推荐 |

## 设计原则

1. **返回 list[dict]，不用 ORM 对象** — 后端用什么存储无关
2. **6 个方法即可** — 不要求实现 delete/record_usage 等管理方法（走 builtin）
3. **fallback 到 builtin** — 后端不可用时自动降级，不阻塞任务
4. **CLI/agent prompt 不变** — 切换后端对使用者完全透明
