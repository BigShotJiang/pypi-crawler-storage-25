# 工作模式对比：Full / Lightweight / Custom

kanban 框架提供三种任务执行模式，通过自动检测推荐 + 用户确认选择。

> 最后更新: v0.39.1, 2026-05-24

---

## 快速对比

| 维度 | Full | Lightweight | Custom |
|------|------|-------------|--------|
| 阶段数 | 9 | 5 | 自定义 |
| 步骤数 | 37 | 20 | 自定义 |
| Plan 确认 | ✅ user_confirm_spec | ❌ 跳过（brainstorming 已交互）| 自定义 |
| Plan Review | ✅ 6 维并行评审 | ❌ 跳过 | 自定义 |
| QA Spec | ✅ 生成 test_spec.md | ❌ 跳过 | 自定义 |
| Spec Review | ✅ 评审测试规格 | ❌ 跳过 | 自定义 |
| Evaluate | ✅ 4 角色并行评估 | ✅ QA 单角色 | 自定义 |
| 知识库检索 | ✅ 强制 | ✅ 强制 | 自定义 |
| 适用场景 | 复杂功能、架构变更 | Bug 修复、小改动 | 特殊流程需求 |
| 创建方式 | `--mode full` 或自动检测 | 默认模式 或 `--lightweight` | `--mode custom` + workflow.json |

---

## Full 模式

### 阶段流转

```
Plan → Plan Review → QA Spec → Spec Review → Execute → Evaluate → Retrospective → User Decision → Archive
```

### 各阶段步骤

| 阶段 | 步骤 ID | 说明 | Agent |
|------|---------|------|-------|
| **Plan** | `plan.knowledge_search` | 知识库检索 | kanban-knowledge-capture |
| | `plan.plan_A` | brainstorming 需求澄清 | interactive |
| | `plan.check_constraints` | 知识库约束检查 | kanban-planner |
| | `plan.user_confirm_spec` | 用户确认 spec | user_action |
| | `plan.plan_B` | 任务拆解 (writing-plans) | kanban-planner |
| | `plan.complete` | Plan 完成 | — |
| **Plan Review** | `plan_review.spawn` | 6 维并行评审 | kanban-plan-reviewer |
| | `plan_review.collect` | 收集评审报告 | — |
| | `plan_review.knowledge_cross_validate` | 知识引用验证 | kanban-plan-reviewer |
| | `plan_review.check` | 评分检查 | — |
| | `plan_review.complete` | Plan Review 完成 | — |
| **QA Spec** | `qa_spec.spawn` | 生成 test_spec.md | kanban-qa |
| | `qa_spec.complete` | QA Spec 完成 | — |
| **Spec Review** | `spec_review.spawn` | 测试规格评审 | kanban-test-spec-reviewer |
| | `spec_review.check` | 评分检查 | — |
| | `spec_review.user_confirm` | 用户确认测试用例 | user_action |
| | `spec_review.complete` | Spec Review 完成 | — |
| **Execute** | `execute.pitfall_check` | 踩坑预警 | kanban-planner |
| | `execute.spawn` | TDD 编码 | kanban-executor |
| | `execute.verify` | 验证执行产物 | — |
| | `execute.commit` | Git 提交 | — |
| | `execute.complete` | Execute 完成 | — |
| **Evaluate** | `evaluate.spawn` | 4 角色并行评估 | kanban-code-reviewer |
| | `evaluate.e2e_run` | E2E 测试 | kanban-e2e-runner |
| | `evaluate.collect_scores` | 收集评分 | — |
| | `evaluate.check_score` | 自迭代决策 | — |
| | `evaluate.commit` | Git 提交评估 | — |
| | `evaluate.complete` | Evaluate 完成 | — |
| **Retrospective** | `retrospective.spawn` | 复盘总结 | kanban-knowledge-manager |
| | `retrospective.audit_realtime_knowledge` | 审计实时知识 | kanban-knowledge-manager |
| | `retrospective.knowledge_import` | 导入提取的知识 | — |
| | `retrospective.complete` | Retrospective 完成 | — |
| **User Decision** | `user_decision.present` | 展示变更摘要 | user_action |
| | `user_decision.wait` | 等待用户决策 | user_action |
| **Archive** | `archive.merge` | 合并 worktree | — |
| | `archive.guard` | 归档 Guards | — |
| | `archive.cleanup` | 清理 worktree | — |

### Guard 检查

- Plan: spec.md + task_breakdown.json + plan/index.md + plan/knowledge_used.json + 知识引用检查
- Execute: execution_summary.md + execution_pitfalls.md + execution_decisions.md + TDD 证据 + 踩坑产物
- Evaluate: 4 角色报告 (code_reviewer / qa / pm / designer)
- Retrospective: retrospective.md + acceptance.md + knowledge_extracted.json

---

## Lightweight 模式

### 阶段流转

```
Plan → Execute → Evaluate → User Decision → Archive
```

### 各阶段步骤

| 阶段 | 步骤 ID | 说明 | Agent |
|------|---------|------|-------|
| **Plan** | `plan.knowledge_search` | 知识库检索 | kanban-knowledge-capture |
| | `plan.plan_A` | brainstorming 需求澄清 | interactive |
| | `plan.check_constraints` | 知识库约束检查 | kanban-planner |
| | `plan.plan_B` | 任务拆解 | kanban-planner |
| | `plan.complete` | Plan 完成 | — |
| **Execute** | `execute.pitfall_check` | 踩坑预警 | kanban-planner |
| | `execute.spawn` | TDD 编码 | kanban-executor |
| | `execute.verify` | 验证执行产物 | — |
| | `execute.commit` | Git 提交 | — |
| | `execute.complete` | Execute 完成 | — |
| **Evaluate** | `evaluate.spawn_qa` | QA 单角色评估 | kanban-qa |
| | `evaluate.e2e_run` | E2E 测试 | kanban-e2e-runner |
| | `evaluate.collect_score` | 收集评分 | — |
| | `evaluate.check_score` | 评分检查 | — |
| | `evaluate.complete` | Evaluate 完成 | — |
| **User Decision** | `user_decision.present` | 展示变更摘要 | user_action |
| | `user_decision.wait` | 等待用户决策 | user_action |
| **Archive** | `archive.merge` | 合并 worktree | — |
| | `archive.guard` | 归档 Guards | — |
| | `archive.cleanup` | 清理 worktree | — |

### 跳过的内容

- Plan Review（6 维评审）→ 不需要
- QA Spec（test_spec.md 生成）→ 不需要
- Spec Review（测试规格评审）→ 不需要
- 4 角色并行评估 → QA 单角色即可
- Self-Improve 自迭代 → 不适用
- Retrospective 复盘 → 不适用

### 依然保留的

- 知识库检索 → 强制（与 Full 相同）
- TDD 编码 → 强制（允许 relaxed 模式）
- E2E 测试 → 按项目配置自动推荐

---

## Custom 模式

### 使用方式

```bash
kanban create "title" --mode custom
```

通过 `workflow.json` 自定义阶段和步骤：

```json
{
  "phases": [
    {"id": "plan", "required_artifacts": ["spec.md"]},
    {"id": "execute", "required_artifacts": ["execution_summary.md"]},
    {"id": "archive", "required_artifacts": []}
  ]
}
```

- 可自定义: 阶段顺序、每阶段的 Agent、required_artifacts、quality_gate
- 不可跳过: plan.knowledge_search（框架强制）
- 参考模板: `.claude/skills/kanban/templates/workflow.json`

---

## 模式自动检测

`assess_task(title, description)` 分析任务标题和描述中的关键词：

| 检测到 | 推荐 | 关键词示例 |
|--------|------|-----------|
| 重度信号 | Full | 游戏、重构、数据库、认证、实时、微服务 |
| 轻量信号 | Lightweight | 修复、脚本、配置、文档、拼写、格式化 |
| 无信号 | Lightweight (默认) | — |

创建任务时 `mode_confirmation_pending: true` → 编排器展示推荐 → 用户确认。

---

## 人工决策点对比

| 决策点 | Full | Light | Custom |
|--------|------|-------|--------|
| 创建时确认模式 | ✅ | ✅ | ✅ |
| brainstorming 需求澄清 | ✅ | ✅ | 自定义 |
| 确认 spec.md | ✅ | — | 自定义 |
| 确认测试用例 | ✅ | — | 自定义 |
| 最终 approve/restart/abort | ✅ | ✅ | 自定义 |
