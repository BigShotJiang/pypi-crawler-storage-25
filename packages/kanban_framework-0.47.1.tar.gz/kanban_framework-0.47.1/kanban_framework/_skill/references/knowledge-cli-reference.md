# Knowledge CLI 命令参考

`kanban knowledge` 命令的完整参数和用法说明。

> 最后更新: v0.39.8, 2026-05-24

## 快速查看

```bash
kanban knowledge help            # 列出所有子命令
kanban knowledge help <sub>      # 查看单个命令详细帮助
```

## Token 高效检索模式

**所有 search/hybrid/semantic 命令建议加 `--json`**，用三步模式避免 token 浪费：

```
1. kanban knowledge hybrid "<查询>" --json → 只看 .data.summary（id+title+relevance）
2. 从 summary 筛选 2-3 条最相关条目
3. kanban knowledge get <id> → 取完整详情
```

`--json` 返回的 `results[]` 包含完整 content，直接消费会爆 token。详见 [knowledge-role-in-fsm.md](knowledge-role-in-fsm.md)。

---

## 查询命令

### search — 多模式搜索

```bash
kanban knowledge search [keyword] [options]
```

| 参数 | 说明 |
|------|------|
| `keyword` | 搜索关键词（位置参数） |
| `--domain D` | 限定领域 |
| `--tag T` | 按标签过滤 |
| `--task ID` | 按关联任务过滤 |
| `--intent I` | 意图驱动：`pitfall_check` / `constraint_lookup` / `experience_reuse` / `general` |

**行为**：
- 只有 `--tag` → `search_by_tag()`
- 只有 `--task` → `search_by_task()`
- `--intent` + keyword → `search_by_intent()`
- `--domain` + keyword → domain 过滤 + 子串匹配
- `--domain` only → `search_by_domain()`
- **默认**（仅 keyword）→ `search_hybrid()`（FTS5 + 语义 RRF 融合）

**示例**：
```bash
kanban knowledge search 架构
kanban knowledge search --domain python 性能优化
kanban knowledge search --intent pitfall_check auth
kanban knowledge search --tag biz:rpg
kanban knowledge search --task TASK-001
```

### hybrid — 混合搜索

```bash
kanban knowledge hybrid <query> [--json]
```

FTS5 关键词匹配 + 语义向量 ANN 检索，RRF（Reciprocal Rank Fusion）融合排序。对中文查询有 jieba 分词 + AND→OR 降级。

**示例**：
```bash
kanban knowledge hybrid Python PyQt 任务管理界面 --json
```

### semantic — 语义搜索

```bash
kanban knowledge semantic <query> [--json]
```

基于 Chroma 向量数据库的 ANN 语义检索。即使关键词完全不同，只要语义相近即可召回。依赖 fastembed/BGE-small-zh-v1.5 生成 512-dim 向量。

**示例**：
```bash
kanban knowledge semantic 组件化架构设计 --json
```

### match — 精确 FTS5 匹配

```bash
kanban knowledge match <text>
```

跳过缩写展开，直接对原始文本做 FTS5 分词查询。返回匹配的领域列表。

**示例**：
```bash
kanban knowledge match combat module
```

### list — 过滤列表

```bash
kanban knowledge list [--domain D] [--category C] [--status S]
```

| 参数 | 说明 | 默认值 |
|------|------|--------|
| `--domain D` | 领域过滤 | 无（全部） |
| `--category C` | 分类过滤 | 无 |
| `--status S` | 状态过滤：`active` / `draft` / `stale` | `active` |

最多返回 50 条。返回值含 `summary` 字段（id+title+relevance，最多 10 条）。

**示例**：
```bash
kanban knowledge list
kanban knowledge list --domain python --category 架构
kanban knowledge list --status draft
```

### get — 单条详情

```bash
kanban knowledge get <id>
```

返回完整字段：`id` / `domain` / `category` / `title` / `content` / `code_example` / `tags` / `source` / `severity` / `status` / `created_at` / `updated_at` / `stale_at` / `referenced_count`。

**示例**：
```bash
kanban knowledge get K001
```

---

## 写入命令

### add — 添加条目

```bash
kanban knowledge add [options]
```

| 参数 | 说明 | 默认值 |
|------|------|--------|
| `--domain D` | 领域 | `infra` |
| `--category C` | 分类 | `工具` |
| `--title T` | 标题（必填） | — |
| `--content C` | 内容（必填） | — |
| `--tags T1,T2` | 逗号分隔标签 | `[]` |
| `--severity S` | 严重度：`high` / `medium` / `low` | `medium` |
| `--status S` | 状态：`active` / `draft` | `active` |
| `--ttl N` | 有效期天数 | 无（永不过期） |
| `--code-example E` | 代码示例 | `""` |
| `--source JSON` | 来源信息（JSON 字符串） | `{}` |

自动执行 FTS5 分词 + embedding 生成 + 去重检查。同 title+domain 的条目默认跳过（`upsert` 模式除外）。

**示例**：
```bash
kanban knowledge add \
  --domain python --category 踩坑 --severity high --ttl 90 \
  --title "GIL 死锁问题" \
  --content "多线程共享状态时注意 GIL 不保证原子性..."

kanban knowledge add \
  --title "SQL 优化技巧" \
  --content "EXPLAIN 分析执行计划..." \
  --tags sql,performance,database
```

### import — 批量导入

```bash
kanban knowledge import <file.json>
```

JSON 格式：`[{"domain": "...", "title": "...", "content": "..."}, ...]`。每条条目执行与 `add` 相同的验证和去重。

### learn — 从文档提取

```bash
kanban knowledge learn <path> --task-id TASK-NNN
```

从复盘文档或代码文件提取结构化知识条目。自动识别模块结构、代码模式、踩坑经验。

### teach — 创建教程条目

```bash
kanban knowledge teach --title T --domain D --category C --step S1 --step S2 ...
```

创建 `type=procedure` 的步骤化知识条目。

### delete — 删除条目

```bash
kanban knowledge delete <id>
```

---

## 管理命令

### domains — 领域列表

```bash
kanban knowledge domains
```

返回所有已注册领域：`{"name": "python", "label": "Python", "keywords": ["python", "pip"]}`。

### categories — 分类列表

```bash
kanban knowledge categories
```

标准分类：`架构` / `踩坑` / `工具` / `最佳实践` / `流程` / `安全` / `测试` / `性能` / `部署` / `文档`。

### health — 健康检查

```bash
kanban knowledge health
```

返回：
- `category_distribution` — 各分类条目分布
- `expired` — 已过期条目（stale_at < now）
- `expiring_soon` — 7 天内即将过期
- `duplicates` — 疑似重复（title 相似度 > 0.6）
- `low_quality` — 低质量条目（content < 20 字符）
- `knowledge_gaps` — 领域缺口分析

### stale — 标记过期

```bash
kanban knowledge stale
```

标记 `stale_at < now` 的条目为 `stale` 状态。stale 条目在检索中降权（×0.7）。

### gaps — 缺口报告

```bash
kanban knowledge gaps
```

各 domain 的知识条目密度分析，帮助识别知识薄弱领域。

### backup — 备份

```bash
kanban knowledge backup
```

备份 `knowledge.db` → `knowledge.db.bak.1` ~ `.bak.5`（轮转，最多 5 个）。自动备份每小时最多执行一次。

### migrate — 数据迁移

```bash
kanban knowledge migrate
```

将旧格式日志迁移为 knowledge.db 条目。

---

## 协作命令

### share — 团队共享

```bash
kanban knowledge share [--push] [--pull] [--list]
```

推送到或拉取自团队共享知识库（通过 config.json `knowledge.share` 配置）。

### conflicts / choose — 冲突解决

```bash
kanban knowledge conflicts --task-id TASK-NNN
kanban knowledge choose --task-id TASK-NNN --choice-id C --selected K001 --rationale "..."
```

检测和解决多源知识条目合并冲突。

### similar — 相似检测

```bash
kanban knowledge similar --title T --content C
```

去重参考。返回与给定标题/内容相似的已有条目。

### usage — 引用查询

```bash
kanban knowledge usage <id>
```

查询哪些任务引用过指定知识条目。

---

## 返回值格式

### 默认输出（无 --json）

简洁摘要：每字段一行，列表显示 `[N items]`，字典显示 `{N keys}`。**编排器不可用此模式**——看不到实际条目内容。

### JSON 输出（加 --json）

```json
{
  "success": true,
  "data": {
    "keyword": "架构",
    "mode": "hybrid",
    "count": 20,
    "results": [{...}, ...],
    "summary": [
      {"id": "K012", "title": "MCP Server 架构：纯JSON-RPC无SDK", "relevance": 0.5496},
      ...
    ]
  }
}
```

| 字段 | 说明 |
|------|------|
| `results` | 全量结果，含完整 content（可达千字符/条） |
| `summary` | 精简摘要（id+title+relevance），最多 10 条 |
| `count` | 总命中数 |

## 相关文档

- [知识库在 FSM 各阶段的作用](knowledge-role-in-fsm.md) — agent 检索指南 + Token 高效模式
- [知识库在流程步骤中的使用规范](knowledge-usage-in-fsm.md) — FSM 各阶段知识交互
- [知识积累指南](knowledge-accumulation-guide.md) — 如何添加/提取知识条目
- [知识后端接入指南](external-knowledge-backend-integration.md) — KnowledgeBackend 适配器开发
