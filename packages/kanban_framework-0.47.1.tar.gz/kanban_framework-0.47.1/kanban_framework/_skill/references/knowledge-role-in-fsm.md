# 知识库在 FSM 各阶段的作用

知识库不是独立模块，而是嵌入到 FSM 每个阶段的"项目记忆层"。本文档说明知识库在各阶段的注入时机、检索策略、以及 agent 该如何使用。

## 核心原则

1. **自动注入优先** — create 和 Plan A 自动检索，agent 不需要记得搜
2. **意图驱动检索** — agent 搜索时应该带上 `--intent`，告诉系统为什么查
3. **结构化交接** — 每个阶段完成时产出 summary + metadata，下游自动可见
4. **后端透明** — agent 永远只调 `kanban knowledge search`，不关心底层是什么

## Token 高效检索模式

`--json` 返回的 `results[]` 包含完整 `content`（每条可达数千字符），直接消费会爆 token。
**所有 agent 和编排器必须使用三步模式：**

```
1. kanban knowledge hybrid "<查询>" --json
   → 只看 .data.summary（仅 id + title + relevance，最多 10 条）

2. 从 summary 中筛选 2-3 条最相关的条目（按 relevance 降序）

3. kanban knowledge get <id>
   → 取单条完整详情（content + code_example + tags + source）
```

**反模式**：直接消费 `--json` 返回的 `.data.results[]` 的 `content` 字段。
**例外**：`--intent pitfall_check` 返回结果通常 ≤5 条，可直接消费 results。

---

## FSM 各阶段知识库作用地图

```
create ─── 自动搜索知识库，展示相关知识条目（#227）
  ↓
plan ─── Plan A: agent 强制先检索知识库，产出 knowledge_used.json
  │       Plan B: subtask 文件必须引用知识条目
  ↓
plan_review ─── 知识引用交叉验证（检索完整性/引用到位率/应用合理性）
  ↓
qa_spec ─── （无直接知识库交互）
  ↓
spec_review ─── （无直接知识库交互）
  ↓
execute ─── 执行前搜索踩坑记录（pitfall_check intent）
  │         执行中新发现的模式 → 写入 execution_pitfalls.md
  ↓
evaluate ─── 评估结果作为知识反馈（score_history）
  ↓
retrospective ─── 知识提取 agent 从产物中提取新知识条目
  │               → knowledge_extracted.json
  ↓
archive ─── 自动导入 knowledge_extracted.json 到 knowledge.db
```

---

## 阶段详解

### 1. create — 任务创建时自动展示知识

`kanban create` 命令创建任务后，自动执行两次搜索：

- `search_hybrid(title + desc)` — 通用相关性检索
- `search_by_intent("pitfall_check", title + desc)` — 踩坑预警

结果返回到 `knowledge_hints` 字段，编排器应展示给用户：
"以下知识条目可能与当前任务相关，建议参考："

**跳过检索**: `kanban create --no-knowledge "title"`

### 2. plan — 知识驱动的需求澄清

#### Plan A（brainstorming）

Agent 必须先执行知识库检索，再开始需求澄清：

```bash
kanban knowledge hybrid "<任务标题>" --json                    # 通用检索（只看 summary）
kanban knowledge search "<关键词>" --intent pitfall_check --json  # 踩坑
kanban knowledge search "<关键词>" --intent experience_reuse --json # 经验复用
```

检索后：从 `summary` 筛选相关条目 → `kanban knowledge get <id>` 取详情 → 写入 `plan/knowledge_used.json`。

产出 `plan/knowledge_used.json`，记录匹配的知识条目和 how_to_apply。
spec.md 必须包含「知识库参考」章节。

#### Plan B（任务拆解）

每个 subtask plan 文件（`plan/ST-NNN_*.md`）必须在开头引用相关条目：
```
知识库参考: [K001] JWT 认证模式 — 避免 token 过期未刷新问题
```

### 3. plan_review — 知识引用验证

spawn 6 维评审 agent。其中 `knowledge_cross_validate` 验证：
- 检索完整性：是否找到了所有相关条目
- 引用到位率：plan 文件引用了多少 high/medium 条目
- 应用合理性：引用是否体现在 subtask 中（非形式化引用）

总分 < 6.0 → 回退到 plan.knowledge_search 重做。

### 4. execute — 编码前踩坑预警 + 编码中新知识捕获

#### 执行前

`execute.pitfall_check` 步骤要求 agent 先搜索踩坑：
```bash
kanban knowledge search "<领域关键词>" --intent pitfall_check --json
```
结果通常 ≤5 条，可直接消费 results。其他检索仍遵循三步模式。

#### 执行中

**实时知识库贡献** — agent 发现通用模式或踩坑时应立即写入知识库，不等归档：

```bash
kanban knowledge add \
  --domain database --category 踩坑 --severity high --ttl 90 \
  --title "MySQL 8.0 FOR UPDATE SKIP LOCKED 语法差异" \
  --content "在 MySQL 8.0 子查询中使用 FOR UPDATE 需要加 SKIP LOCKED，否则会锁全表"
```

**何时写**：通用技术模式、框架 API 的坑、跨项目可复用的方案。
**何时不写**：本项目特有的业务逻辑、一次性的配置值。用 `--ttl` 设有效期。

同时写入 `execution_pitfalls.md` 作为补充记录。

### 5. evaluate — 评分作为知识反馈

四角色评估的 score_history 写入 task.json，后续任务可通过 `experience_reuse` intent 检索到高评分任务的模式。

### 6. retrospective — 知识提取与质量审计

#### audit_realtime_knowledge（v0.32+ 新增）

审计 execute 阶段实时写入的知识条目：
- 查找 `source.type=executor_realtime` 且 `source.task_id=<当前任务>` 的条目
- 验证条目的通用性（非项目特有业务逻辑）和准确性
- 标记低质量条目为 `deprecated`，高质量条目保持 `active`

#### knowledge_import

1. 读取 `execution_pitfalls.md`、`execution_decisions.md`
2. spawn knowledge agent 提取为结构化条目
3. 产出 `knowledge_extracted.json`

### 7. archive — 知识入库

`complete-phase archive` 自动调用：
- 导入 `knowledge_extracted.json` 到 `knowledge.db`
- 去重检查（同 title + domain 跳过）
- 记录 knowledge health（gaps detected）

---

## 检索意图选择指南

Agent 在调用 `kanban knowledge search` 时应根据场景选择 intent：

| 场景 | Intent | 策略 | 示例 |
|------|--------|------|------|
| 编码前查已知问题 | `pitfall_check` | 加权 severity=high + category=踩坑 | `kanban knowledge search "auth" --intent pitfall_check` |
| 设计阶段约束检查 | `constraint_lookup` | 精确匹配 tags + source.file | `kanban knowledge search "" --intent constraint_lookup --domain security` |
| 新任务复用历史经验 | `experience_reuse` | 语义相似度 + domain 加权 + 引用热度 | `kanban knowledge search "支付" --intent experience_reuse` |
| 通用查询 | `general`（默认） | 标准 hybrid search | `kanban knowledge search "workflow"` |

---

## 知识条目生命周期

```
创建（knowledge add --ttl 30）
  → active（正常参与检索）
  → stale（超过 TTL，检索降权 ×0.7）
  → 90天未更新 → 降权 ×0.4
  → 长期未引用 → deprecated（建议归档）
  → archived（不再参与检索）
```

---

## 后端切换

默认使用 BuiltinBackend（SQLite FTS5 + chroma 向量）。可通过 `config.json` 切换：

```json
{
  "knowledge": {
    "backend": "builtin"
  }
}
```

可选后端：`builtin` | `memory` | `chromadb`。
切换后端后 agent 无感知，所有 CLI 命令不变。

详见 [external-knowledge-backend-integration.md](external-knowledge-backend-integration.md)。

---

## 相关文档

- [知识积累指南](knowledge-accumulation-guide.md) — 如何添加/提取知识条目，避免噪音
- [外部后端接入指南](external-knowledge-backend-integration.md) — 如何实现 KnowledgeBackend 适配器
- [commands.md](commands.md) — knowledge CLI 命令完整参考
- [workflow-json-reference.md](workflow-json-reference.md) — workflow.json 知识相关配置
