# 用户上手文档

本文档涵盖 kanban 框架所有用户可自定义的配置和行为。

> 最后更新: v0.39.1, 2026-05-24

---

## 一、项目初始化

```bash
/kanban init          # 初始化项目，设置 task_id_base（工号）
/kanban hook install  # 安装 SessionStart hook，每次会话自动注入任务上下文
/kanban check-env     # 检查环境配置
```

---

## 二、config.json 完整配置

文件: `.kanban/config.json`，所有字段可选。

```json
{
  "project": "my-project",
  "output_dir": "src",
  "trunk": "main",
  "python_bin": "venv/bin/python",
  "task_id_base": 6696,

  "engine": { "default": "claude-code" },

  "timeout": {
    "plan_seconds": 300,
    "execute_seconds": 600,
    "evaluate_seconds": 300,
    "single_agent_seconds": 180
  },

  "retry": {
    "max_retries": 2,
    "backoff_seconds": [30, 60]
  },

  "budget": {
    "per_task": 500000,
    "per_phase": { "plan": 50000, "execute": 200000, "evaluate": 150000 },
    "warning_threshold": 0.8,
    "hard_limit": true
  },

  "scheduler": {
    "max_parallel": 3,
    "poll_interval_seconds": 30,
    "conflict_strategy": "serialize"
  },

  "framework_assessment": { "enabled": true },

  "knowledge": {
    "backend": "builtin",
    "share": {
      "enabled": true,
      "path": "~/.kanban/knowledge_share/knowledge.db"
    }
  },

  "stats": {
    "backend": "native",
    "days": 30
  },

  "prompt_hooks": {
    "plan.plan_A": "优先评估 FastAPI + Redis 方案",
    "qa_spec": "使用 Playwright E2E 测试",
    "execute": "所有代码须通过 ruff check 和 mypy --strict"
  }
}
```

### 配置字段说明

| 分类 | 字段 | 类型 | 默认值 | 说明 |
|------|------|------|--------|------|
| **基础** | `project` | string | `""` | 项目名 |
| | `output_dir` | string | `"src"` | 代码输出目录 |
| | `trunk` | string | `"main"` | 主干分支 |
| | `python_bin` | string | `"venv/bin/python"` | Python 路径 |
| | `task_id_base` | int | `0` | 任务编号基数 |
| **超时** | `timeout.plan_seconds` | int | `300` | Plan 阶段超时 |
| | `timeout.execute_seconds` | int | `600` | Execute 阶段超时 |
| | `timeout.evaluate_seconds` | int | `300` | Evaluate 阶段超时 |
| | `timeout.single_agent_seconds` | int | `180` | 单个 Agent 超时 |
| **重试** | `retry.max_retries` | int | `2` | 最大重试次数 |
| | `retry.backoff_seconds` | int[] | `[30, 60]` | 重试间隔 |
| **预算** | `budget.per_task` | int | `500000` | 任务总 token 预算 |
| | `budget.per_phase` | dict | 见上 | 各阶段预算 |
| | `budget.warning_threshold` | float | `0.8` | 告警阈值 |
| | `budget.hard_limit` | bool | `true` | 超预算强制阻断 |
| **调度** | `scheduler.max_parallel` | int | `3` | 最大并行 Agent 数 |
| | `scheduler.poll_interval_seconds` | int | `30` | 轮询间隔 |
| **知识库** | `knowledge.backend` | string | `"builtin"` | 知识库后端 |
| | `knowledge.share.enabled` | bool | `false` | 团队共享 |
| | `knowledge.share.path` | string | — | 共享库路径 |
| **统计** | `stats.backend` | string | `"native"` | 统计后端 |
| | `stats.days` | int | `30` | 统计天数 |
| **提示词** | `prompt_hooks` | dict | `{}` | 步骤级提示词注入 |

---

## 三、workflow.json 自定义流程

文件: `.kanban/workflow.json`

### 全局配置

```json
{
  "pass_threshold": 8.5,
  "max_iterations": 6,
  "phases": [...]
}
```

### 自定义 Phase

```json
{
  "id": "execute",
  "name": "编码实现",
  "required_artifacts": ["execution_summary.md"],
  "required_checks": ["tests_run"],
  "agents": [
    {
      "role": "executor",
      "required": true,
      "parallel": true,
      "agent_type": "kanban-executor",
      "mode": "tdd"
    }
  ],
  "quality_gate": {
    "enabled": true,
    "pass_threshold": 8.5,
    "dimensions": [
      {"id": "code_quality", "name": "代码质量", "weight": 0.5},
      {"id": "test_coverage", "name": "测试覆盖", "weight": 0.5}
    ]
  }
}
```

### 添加自定义评估角色

```json
{
  "role": "security_auditor",
  "required": true,
  "parallel": true,
  "agent_type": "kanban-code-reviewer",
  "mode": "security"
}
```

### 条件调度 Agent（按需触发）

```json
{
  "role": "researcher",
  "required": false,
  "agent_type": "kanban-researcher",
  "trigger_condition": {
    "keywords": ["调研", "选型", "对比", "analysis"],
    "match_field": "description"
  }
}
```

---

## 四、提示词注入（prompt_hooks）

向特定阶段/步骤注入项目定制化提示词。

```json
{
  "prompt_hooks": {
    "plan.plan_A": "优先评估 FastAPI + Redis 方案",
    "qa_spec": "使用 Playwright E2E 测试，测试放在 tests/e2e/ 下",
    "execute.spawn": "数据库操作用 SQLAlchemy 2.0 async 模式",
    "execute": "所有代码须通过 ruff check 和 mypy --strict"
  }
}
```

Hook 键名规则：
- `"plan"` — 对 plan 阶段所有步骤生效
- `"execute.spawn"` — 仅对 execute 阶段的 spawn 步骤生效（更精确）
- 步骤级 hook 优先于阶段级，同样内容的 hook 自动去重

---

## 五、知识库自定义

### 切换后端

```json
{ "knowledge": { "backend": "builtin" } }
```

可选: `"builtin"` | `"chromadb"` | `"memory"`

### 团队共享

```json
{
  "knowledge": {
    "share": {
      "enabled": true,
      "path": "~/.kanban/knowledge_share/knowledge.db"
    }
  }
}
```

### 知识条目管理

```bash
kanban knowledge add --domain web --category 踩坑 --severity high --ttl 90 \
  --title "MySQL 8.0 FOR UPDATE 语法差异" \
  --content "在子查询中需要加 SKIP LOCKED"

kanban knowledge categories          # 查看标准分类
kanban knowledge share --push K001   # 推到团队共享库
kanban knowledge teach "红点开发流程" --step "1. 加字段" --step "2. 改API" --step "3. 改前端"
```

---

## 六、任务创建自定义

### 模式选择

```bash
kanban create "title" --mode full          # 完整流程
kanban create "title" --lightweight       # 轻量流程
kanban create "title" --mode custom       # 自定义流程
```

不指定 `--mode` 时自动检测并提示用户确认。

### 全自动模式

```bash
kanban create "title" --auto-mode all     # 所有交互点自动决策
kanban create "title" --auto-mode brainstorm,iteration  # 部分自动
```

auto-decider 置信度 < 0.7 时降级回人工确认。

### 全手动模式

```bash
kanban create "title" --control-mode manual  # 每步完成后用户选择下一步
```

### 测试配置

```bash
kanban create "title" --test-level quick --test-cmd "pytest tests/ -v" --coverage "80%"
```

---

## 七、统计后端切换

```json
{ "stats": { "backend": "native", "days": 30 } }
```

| backend | 数据源 | 说明 |
|---------|--------|------|
| `"native"` | Claude Code JSONL | 零依赖，默认 |
| `"codeburn"` | codeburn CLI | 全局聚合，需安装 |

切换后 Dashboard 无感知。

---

## 八、自定义 Agent 定义

`.claude/agents/` 目录下创建 Markdown 文件，可被 workflow.json 引用：

```markdown
# .claude/agents/my-security-auditor.md
你是安全审计 Agent。检查代码中的:
- 注入风险（SQL/XSS）
- 认证缺陷
- 敏感数据泄露
```

然后在 workflow.json 中：
```json
{"role": "security", "required": true, "file": "agents/my-security-auditor.md"}
```

---

## 九、Dashboard 自定义

```bash
kanban dashboard start      # 启动 (默认端口 3000)
kanban dashboard start 8080 # 指定端口
kanban dashboard stop       # 停止
kanban dashboard status     # 状态
```

Dashboard `.framework_version` 标记自动在 `kanban update` 时强制 redeploy。

---

## 十、常用命令速查

```bash
# 版本管理
kanban update                  # 最新稳定版
kanban update 0.27.0           # 指定版本
kanban update --channel dev    # 最新开发版

# 知识库
kanban knowledge search "auth" --intent pitfall_check
kanban knowledge backup

# 统计
kanban stats
kanban track <task> <phase> <tokens> --agent <name> --session <id>

# 巡检
kanban check-env
kanban status
kanban recover [<task_id>]
```

---

## 十一、相关文档

| 文档 | 内容 |
|------|------|
| `config-json-reference.md` | config.json 完整字段参考 |
| `workflow-json-reference.md` | workflow.json 完整字段参考 |
| `mode-comparison.md` | Full/Light/Custom 模式对比 |
| `external-knowledge-backend-integration.md` | 知识库后端接入指南 |
| `dashboard-stats-algorithm.md` | Dashboard 统计算法 |
| `knowledge-usage-in-fsm.md` | 知识库在流程中的使用 |
| `lessons-learned.md` | 踩坑经验 |
