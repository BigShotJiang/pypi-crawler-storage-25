# Kanban Framework — Changelog

所有版本的迭代记录索引。每个版本有对应的详细记录文件 `v{X.Y.Z}.md`。
升级指南见 [UPGRADE.md](UPGRADE.md)。

## [v0.47.1] - 2026-05-25

### Summary

Fix `_skill/` directory out of sync — SKILL.md, agents, and version records were not copied to `_skill/`, causing pip install users to get stale files.

- 详细记录: [v0.47.1.md](v0.47.1.md)

## [v0.47.0] - 2026-05-25

### Summary

Task detail panel redesigned with tabbed navigation (Overview/Progress/Reports), sticky header, left-aligned table data. Fixed `_skill/references/` missing 7 files in pip package.

- 详细记录: [v0.47.0.md](v0.47.0.md)

## [v0.46.1] - 2026-05-25

### Summary

Fix daily token chart always showing 0 — `get_stats()` extracted call counts from JSONL but never read `message.usage` token fields.

- 详细记录: [v0.46.1.md](v0.46.1.md)

## [v0.46.0] - 2026-05-25

### Summary

Dashboard UI 全面升级（SVG 图标系统 + 统计卡片修复 + 图表容器），修复 per-task duration 始终为 0 的问题，修复 Windows 上 JSONL 路径匹配失败 (#318)。

- 详细记录: [v0.46.0.md](v0.46.0.md)

## [v0.34.0] - 2026-05-23

### Added
- StatsBackend 中间层（Native + CodeBurn，config 切换）
- Dashboard 时序趋势图（Token + Prompt 分离图表）
- per-step API 调用次数统计（subagent JSONL 直接计数）
- prompt_hooks 步骤级提示词注入机制
- 知识条目 TTL 过期 + 历史数据迁移
- 知识库中间层可插拔后端（KnowledgeBackend Protocol + 3 backends）
- TaskRun 数据模型 + 结构化交接（summary/metadata）
- kanban update 版本号指定 + stable/dev 双通道
- DB 备份机制（最多 5 个轮转备份）
- Dashboard 步骤 agent_type 信息展示
- References 路由表（10 个文档）
- BDD 场景 151 个

### Fixed
- 知识库注入导致编码质量下降（Context Rot #240）
- 知识库搜索质量 7 项修复（子串/缩写/阈值/域权重 #224-#233）
- Dashboard 阶段可见性（plan_review/qa_spec 等阶段不显示 #217）
- TDD 豁免模式（lightweight/quick 任务 #223）
- subprocess 窗口弹窗（#218）
- per-task 统计精度（JSONL 回退过估 #232 #233）

详见 v0.34.0 各子版本记录。

## [v0.17.4] - 2026-05-18

### Fixed
- 全仓库 `-m core` → `-m kanban_framework` 引用修正 + README 扩展
详见 [v0.17.4.md](v0.17.4.md)

## [v0.17.3] - 2026-05-18

### Added
- `kanban update` — 一键升级到最新 PyPI 版本
详见 [v0.17.3.md](v0.17.3.md)

## [v0.17.2] - 2026-05-18

### Fixed
- #198 dashboard 无参数默认启动服务
- #199 dashboard --help 显示帮助
- #200 内联 SVG favicon
详见 [v0.17.2.md](v0.17.2.md)

## [v0.17.1] - 2026-05-18

### Fixed
- #197 Dashboard AttributeError (v0.17.0 已修，降级用户升级即可)
- #177 归档阶段清理 worktree 命令修正 + stray archive/ 自动清除
详见 [v0.17.1.md](v0.17.1.md)

## [v0.17.0] - 2026-05-18

### Added
- Dashboard 纳入 pip 包分发 + 设计迭代 "Raster Console v2"
- `kanban inbox process` / `add-subtasks` / `workflow replan` 命令
- Guard check-inbox 双层检查 + inbox.md 加入 FSM 上下文
详见 [v0.17.0.md](v0.17.0.md)

## [v0.15.3] - 2026-05-18

### Fixed
- Plan reviewer 检查 index.md 路由表 + ST-NNN_*.md 内容质量
详见 [v0.15.3.md](v0.15.3.md)

## [v0.15.1] - 2026-05-18

### Fixed
- brainstorming 改为 interactive 模式，保留用户需求沟通交互
- kanban-rules.md 同步过时规则（IR-03/12/R-002/R-006 + 新增 IR-18）
详见 [v0.15.1.md](v0.15.1.md)

## [v0.15.0] - 2026-05-18

### Added
- `StepDef.spawn_prompt` — subagent prompt 模板，约束执行边界，防止接管流程
- `_validate_fsm_state()` — CLI 命令 FSM 状态校验，检测跳步
### Changed
- SKILL.md 精简至 82 行，编排器只做 next-step 循环
详见 [v0.15.0.md](v0.15.0.md)

## [v0.14.1] - 2026-05-17

### Fixed
- Lightweight guard 死锁: `transition()` 传递 `lightweight` 参数给 guard
- SKILL.md 编排清单精简，减少 agent 过度执行

详细记录: [v0.14.1.md](v0.14.1.md)

## [v0.14.0] - 2026-05-17

### Added
- 状态机驱动编排引擎: `kanban workflow next-step` 返回精确下一步指令
- `kanban workflow mark-step` 标记子步骤完成
- `kanban workflow progress` 查看子步骤进度
- complete-phase 自动标记该阶段所有子步骤
- FULL_STEPS (9 阶段 34 步骤) + LIGHTWEIGHT_STEPS (5 阶段 16 步骤)

### Changed
- 编排器通过 `next-step` 驱动，不再需要记忆 FSM 规则
- 上下文压缩恢复改为 `next-step` 驱动

详细记录: [v0.14.0.md](v0.14.0.md)

## [v0.13.40] - 2026-05-17

### Added
- #188: agent 文件同步检查 — check-env 报告状态 + sync-agents 命令
- #189: knowledge add_entry 重复条目检测（title+domain 去重 + upsert 模式）
- #191: worktree merge 前检查分支是否已合并

### Fixed
- #190: 辅助函数 bare except 改为具体异常类型 + logging.warning

详细记录: [v0.13.40.md](v0.13.40.md)

## [v0.13.39] - 2026-05-17

### Added
- #175: executor agent 逐步 Git commit 规范 + commit changelog 表格
- #178: Plan A 调研产物跨会话复用（investigation.md 可选产物）

详细记录: [v0.13.39.md](v0.13.39.md)

## [v0.13.38] - 2026-05-17

### Added
- #184: `kanban task edit <id> --auto-mode all|none|<flags>` CLI 选项
- SKILL.md 命令表补充 --auto-mode 用法

详细记录: [v0.13.38.md](v0.13.38.md)

## [v0.13.37] - 2026-05-17

### Fixed
- #180: Guard TDD 证据格式要求文档化（错误信息含完整表格格式模板）
- SKILL.md Execute 清单补充 TDD 证据表格格式规范
- BDD 验收模块 10 新增 2 场景（格式文档化 + 回归测试容错）

详细记录: [v0.13.37.md](v0.13.37.md)

## [v0.13.36] - 2026-05-17

### Fixed
- #182: complete-phase evaluate 自动同步评分（无需手动 record-score）
- #181: Guard 评分键名容错（average/overall/score）+ 未知键明确报错

详细记录: [v0.13.36.md](v0.13.36.md)

## [v0.13.35] - 2026-05-17

### Fixed
- #186: knowledge add 位置参数作为 content 快捷方式（不再被静默跳过）
- #187: add_entry 非空校验 + CLI --verify 回读验证
- complete-phase 知识导入跳过空条目

详细记录: [v0.13.35.md](v0.13.35.md)

## [v0.13.34] - 2026-05-17

### Fixed
- #183: LIGHTWEIGHT_PHASE_ORDER 增加 USER_DECISION 阶段（EVALUATE→USER_DECISION→ARCHIVE）
- #185: cmd_guard check-evaluation 传入 lightweight 参数，轻量任务只检查 QA 报告
- BDD 验收场景补充: 17_mode(+2), 03-workflow(更新1+新增2), 15-cli(+1)

详细记录: [v0.13.34.md](v0.13.34.md)

## [v0.13.33] - 2026-05-17

### Fixed
- #176: complete-phase retrospective 自动导入 knowledge_extracted.json 到 knowledge.db
- Agent 文档修正 4 处 contradiction（stdout → 文件输出，knowledge-log.md → knowledge.db）
- Guard retrospective 检查移除 legacy knowledge-log.md
- IR-06 规则更新为引用 knowledge_extracted.json 和 knowledge.db

详细记录: [v0.13.33.md](v0.13.33.md)

## [v0.13.32] - 2026-05-17

### Added
- E2E 测试策略自动推荐: init 时基于技术栈推荐并写入 test_profile.md (#174)
- QA agent 自动生成 E2E 测试场景表格 (E2E-NNN)
- QA agent eval 新增 e2e_coverage 维度
- detect_e2e_recommendation 函数支持 Python/JS/TS/Go

### Changed
- generate_default_test_profile 所有分支追加 E2E 策略段落
- cmd_init 返回结果新增 test_strategy 字段

详细记录: [v0.13.32.md](v0.13.32.md)

## [v0.13.29] - 2026-05-16

### Changed
- SKILL.md 优化精简: 509→211 行 (58% 缩减)
- agent/rule 孤儿链接改为报告而非自动删除，新增 `--clean-orphaned` 标志
- 孤儿链接匹配改为按 skill 实际文件列表，覆盖非 kanban- 前缀的 rule 文件

### Added
- 升级指南: versions/UPGRADE.md
- README: Full/Lightweight 模式详细对比 + 全自动模式说明

## [v0.13.28] - 2026-05-16

### Changed
- SKILL.md 移除 agent symlink 引用，新增 task edit、knowledge semantic/hybrid 命令

## [v0.13.27] - 2026-05-16

首次通过 Trusted Publisher 自动发布。

## [v0.13.1] - 2026-05-14

### Fixed
- #143: TDD evidence table separator matching standard Markdown

### Changed
- Lightweight mode simplified to Plan→Execute→Evaluate(QA only)→Archive
- 3-mode system: full / lightweight / custom with ask-on-create recommendation

详细记录见 `v0.13.1.md`

## [v0.13.0] - 2026-05-13

### Added
- **知识系统结构化存储**: JSON entry 存储 + domains.json/index.json/usage-log.json
- **知识注入闭环**: Plan 注入 → Plan Review 交叉验证 → Execute 预警 → Archive 提取
- **独立学习**: knowledge learn 命令，从代码目录分析提取最佳实践
- **知识积累指南**: 含 6 条边界原则（拒绝通用常识、无操作性抽象等）
- **Draft 任务**: --draft 创建占位，通过 inbox 逐步完善
- **InboxAnalyzer 分析引擎**: 读 inbox → 提取需求 → 判断 FSM 入口 → 补入 spec.md
- **task promote 命令**: draft → FSM 正式流程
- **Plan 方案冲突检测**: find_conflicting_solutions + conflicts/choose CLI
- **Plan 代码可靠性验证**: Plan Review 交叉验证知识库
- **Execute 硬约束注入**: plan_choices.json 在启动时强制执行
- **plan.md → plan/ 目录**: 单文件拆为 index.md + per-subtask 文件，Executor 按需加载
- **test_profile.md**: kanban init 自动生成，定义项目测试与验收规范
- **耗时与 Token 追踪**: per-phase + per-agent 维度
- **Superpowers 技能检测**: 扫描缺少的必装 skill（含 ~/.claude/plugins/）
- **自定义 Agent**: workflow.json 支持 agent_file 字段
- **BDD 验收清单**: 按 16 功能模块拆分到 acceptance/ 目录（69 场景）
- **知识 CLI 全命令**: 14 个子命令（search/add/domains/match/stale/gaps/migrate/import/similar/usage/health/conflicts/choose/learn）

### Changed
- Python 解释器约定: `<py> -m core` 替代 `python3 -m core`（92 处）
- KnowledgeManager 完全重写（JSON 存储 + 索引 + 引用追踪）
- Planner/Executor/Knowledge-Manager Agent 文档全部更新
- init python_bin 改用 sys.executable

### Fixed
- KF-001~007: python_bin 默认值、中文编码、superpowers 检测、phase completeness、source_code_committed、双阈值死循环、知识提取路径

详细记录见 `v0.13.0.md`

## [v0.12.0] - 2026-05-10

### Added
- **Plan Review 6 维度并行调度**: 6 个评审维度并行 Agent + collect-plan-review 收集报告
- **Retrospective 3 角色并行调度**: retrospective_writer / acceptance_writer / knowledge_extractor 并行
- **Guard 批量并行检查**: batch_check + batch_check_combined
- **Evaluate 阶段分数门槛硬性门控**: complete-phase 自动检查 score vs threshold，不达标时阻止转换
- **History 自动记录**: create/transition/complete-phase 自动追加 history 条目
- **Version CLI 命令**: version list + record 子命令

### Fixed
- 新旧 Task Format 不一致导致 5 个测试 stale data（_write_task 清理旧格式）
- Windows symlink 检测失败（path-parts 匹配替代字符串匹配）
- Windows GBK 编码错误（统一 encoding="utf-8"）
- check-env 测试环境隔离
- SKILL.md 自定义 subagent_type 无法调度（统一改为 general-purpose）

### Changed
- cmd_workflow transition/complete-phase 持久化 history
- SKILL.md: Plan Review 6 并行维度 + Retrospective 3 并行角色 + 串行回退

详细记录见 `v0.12.0.md`

## [v0.11.0] - 2026-05-09

### Added
- **Evaluator 自动评分链路**: collect-scores / record-score / self-improve-check 自动读 score_history
- **迭代产物隔离**: workflow start-iteration hot/full + execution artifacts 迁移到 iteration-N/
- **评分趋势 UI**: score_history 可视化（Canvas 折线图 + pass_threshold 参考线 + 颜色区分）
- **轻量模式硬性门控**: requires_confirmation + AskUserQuestion 强制确认
- **Agent 调度增强**: get-phase-agents 暴露 timeout/parallel 配置
- **跨任务冲突检测**: Guard.check_cross_task_conflicts()
- **知识库语义搜索**: search_scored() 加权评分（标题×3 + 分类×2 + 内容×1）
- **Agent 注册表自动发现**: Scheduler.scan_agents() 扫描 .claude/agents/*.md
- **项目根目录自动检测**: Filesystem.find_project_root() + check-env 异常检测
- **NLP → LLM 推理**: 删除 1000 行关键词匹配，改为 interpret_by_llm

### Changed
- SKILL.md: brainstorming 强制 AskUserQuestion，LLM 推理路由
- github-issue-processing skill: 不再基于标题过滤，验收报告缺口补齐前不关闭
- Task 类型: 新增 scores + score_history 字段

### Fixed
- cmd_workflow transition 持久化阶段状态 (#100/#101)
- Dashboard 缺失 StatsOverview.js + useScoreChart.js (#103)
- Guard 兼容 iteration-N/ legacy 格式 (#102)

详细记录见 `v0.11.0.md`

## [v0.10.0] - 2026-05-08

### Added
- **Agent kanban- 前缀统一命名**: 全部 10 个 agent 使用 `kanban-` 前缀（kanban-planner, kanban-executor, kanban-code-reviewer, kanban-designer, kanban-pm, kanban-qa, kanban-researcher, kanban-knowledge-manager, kanban-plan-reviewer, kanban-test-spec-reviewer）
- **Agent 全能力化**: executor/planner/knowledge-manager/researcher 移除 tools/skills 限制，获得全部工具能力
- **Init 智能分析层** (`scanner.py`): 项目扫描模块，检测 agent 冲突、skills、语言/框架基础设施、领域特定基建
- **Plan Review 质量门禁**: 新 kanban-plan-reviewer agent，6 维度量化评分 Plan 产物
- **QA Spec 测试用例并行开发**: kanban-qa 支持 spec/eval 双模式，Plan 通过后产出 test_spec.md
- **Spec Review 质量门禁**: 新 kanban-test-spec-reviewer agent，5 维度审核测试用例文档
- **FSM 阶段扩展**: 新增 plan_review / qa_spec / spec_review / retrospective 四个阶段（共 9 阶段）
- **Execute 多 Agent 并行调度**: subtask.py 拓扑排序 + 文件冲突检测批次调度，parallelizable/file_ownership/shared_files_readonly 元数据
- **Plan Review 自动重试**: WorkflowEngine.quality_gate_check + RETRY_PREV action
- `cmd_scan` 命令：独立项目扫描
- 测试覆盖: 167 个测试全部通过（含 28 个 scanner + 12 个 guard + 9 个 subtask scheduler）

### Changed
- **Phase 枚举扩展**: PLAN_REVIEW, QA_SPEC, SPEC_REVIEW, RETROSPECTIVE 加入
- **workflow.json**: 从扁平的 4 阶段扩展到 9 阶段对象格式，含 agent_type 引用
- **SKILL.md**: 全部 subagent_type 引用更新为 kanban- 前缀，新增 4 阶段文档
- **Guard 扩展**: check_spec, check_parallel_conflicts, check_retrospective
- **Config.phases**: 向后兼容，自动从对象列表提取 id 或回退到字符串列表
- **types.py Report**: scores 字段改为 dimensions 对象格式
- **Scheduler**: PHASE_ORDER 扩展，agent_type 使用 kanban- 前缀

### Fixed
- **Stub 实现修复**: cmd_worktree/create/remove/merge/cleanup, cmd_guard/check-artifacts/evaluation/inbox/spec/parallel-conflicts, cmd_workflow/transition/complete-phase/self-improve-check/get-roles, cmd_nlp
- **代码重复消除**: CLI 层并行冲突检测委托给 Guard 领域方法
- **异常处理修复**: cmd_init scanner 异常不再吞没
- **Agent 模板路径**: $KANBAN_DIR/reports/ → tasks/${task_id}/iteration-N/
- **8 个回归测试**: conftest.py Phase 顺序、test_run/test_workflow/test_scheduler/test_config 全部适配
- **__pycache__ 清理**: 添加 .gitignore 排除规则，移除已提交缓存文件

### Security
- cmd_worktree merge/cleanup 使用原始 task_id，建议后续添加 tm.show() 校验

详细记录见 `v0.10.0.md`

## [v0.6.0] - 2026-05-04

### Added
- 自然语言命令解析层（NLP Router）：用户可用中文/英文/混合自然语言与 kanban 交互
- 数据驱动关键词配置 `nlp_patterns.json`：11 个命令类型，200+ 关键词模式
- 三层置信度匹配：精确 (1.0) / 同义词 (0.8) / 模糊 (0.6)
- Task ID 智能提取：标准格式、纯数字、中文数字、序数表达式
- 繁体中文支持（19 个繁简映射）
- 拼写容错（10 个常见拼写纠错）
- 单任务推断：仅一个活跃任务时自动推断 task_id
- Create 命令三层 title 提取（引号 > 中文标记 > 关键词剥离）
- SKILL.md 自然语言路由文档（含示例映射表）
- NLP 路由器单元测试（148 项断言，全部通过）

### Changed
- SKILL.md 命令路由章节：新增自然语言路由入口，精确命令优先匹配
- `kanban_init_env` 自动加载 `nlp_router.sh`（通过 lib/*.sh glob）

### Security
- sed 替换中正则元字符转义防护（`_nlp_sed_escape` helper）

详细记录见 `v0.6.0.md`

## [v0.2.0] - 2026-05-03

### Added
- 目录内聚化（tasks/TASK-NNN/ 新布局 + 自动迁移）
- Plan 质量门禁（4维加权评分: 需求清晰度/技术可行性/拆解合理性/验收标准完整性）
- Worktree 生命周期（validate/create/merge/cleanup 容错增强）
- 归档自演进（framework_self_assess 自动创建改进任务）
- kanban_changes_summary（user_decision 阶段变更全景展示）
- Dashboard 可视化看板
- 版本管理系统（CHANGELOG + 逐版本记录）

### Changed
- evaluator_record_score 读取 .average_score（兼容 .score 回退）
- worktree_merge 容错处理（无 worktree 时兜底 commit）
- SKILL.md 编排逻辑更新（Phase 4 增加 changes_summary）
- .gitignore 追加运行时数据规则和敏感文件模式

### Fixed
- worktree_cleanup 清空 task JSON 字段问题
- hot iteration worktree 校验/重建逻辑
- evaluate→archive 转换被阻止（IR-11 合规）
- grep -c 在 zsh 中的整数比较警告

详细记录见 `v0.2.0.md`

## [v0.1.0] - 2026-04-28

### Added
- FSM 工作流引擎（plan → execute → evaluate → user_decision → archive）
- 4 角色评估体系（code_reviewer / qa / pm / designer）
- Guard 三层防护（阶段转换/产物完整性/评分标准）
- Worktree 隔离执行（独立分支 + 合并）
- 自迭代循环（hot iteration 快速修复 / full iteration 全量重来）
- 评分系统（10分制 + pass_threshold 可配置）
- 任务 CRUD（create / status / show / decide / recover）
- 知识沉淀（knowledge-log.md）
- 崩溃恢复机制
- Inbox 反馈分析
- Iron Rules 铁律体系（11条）

详细记录见 `v0.1.0.md`
