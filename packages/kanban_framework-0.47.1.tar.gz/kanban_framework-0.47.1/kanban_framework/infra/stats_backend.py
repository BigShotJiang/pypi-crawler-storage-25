"""Stats backend abstraction — pluggable token/time statistics providers.

Same middleware pattern as knowledge_backend.py:
  Dashboard / CLI commands (unchanged)
        ↓
  StatsBackend (Protocol)
    ├─ NativeBackend  → read Claude Code JSONL directly, zero deps
    └─ CodeBurnBackend → delegate to codeburn CLI for aggregated analytics

Switch via config.json: {"stats": {"backend": "native"}}
"""

from __future__ import annotations
import json
import os
import time
from datetime import datetime as _dt
from pathlib import Path
from typing import Protocol, runtime_checkable


@runtime_checkable
class StatsBackend(Protocol):
    """Protocol for token/time statistics backends."""

    def get_stats(self, days: int = 30) -> dict:
        """Return aggregated global stats for the last N days."""
        ...

    def get_task_stats(self, task_id: str) -> dict:
        """Return per-task statistics.

        Returns:
            {
                "total_tokens": int,
                "total_prompts": int,
                "phases": {ph: tokens},
                "agents": {ag: tokens},
                "models": {m: tokens},
                "phase_duration": {ph: seconds},
                "phase_api_calls": {ph: count},
                "step_api_calls": {step_id: count},
                "real_api_calls": int,
                "source": str,
                "note": str
            }
        """
        ...


class NativeBackend:
    """Read Claude Code JSONL conversation logs for the current project.

    Scans ~/.claude/projects/<project-hash>/*.jsonl for operation logs
    and augments with global stats-cache.json counters (scoped to project).

    Zero dependencies — data already exists on disk.
    """

    def __init__(self, project_root: Path):
        self._root = Path(project_root).resolve()
        self._claude_dir = Path.home() / ".claude"

    def get_stats(self, days: int = 30) -> dict:
        cutoff = time.time() - days * 86400

        stats: dict = {
            "total_tokens": 0, "total_input": 0, "total_output": 0,
            "total_prompt_calls": 0, "total_duration_seconds": 0.0,
            "sessions": 0, "by_model": {}, "daily": {},
            "source": "native",
        }

        # ── Scan THIS project's JSONL session files ──
        project_jsonl = self._find_project_jsonl_files()
        seen_sessions = set()

        for jf in project_jsonl:
            try:
                for line in jf.read_text(encoding="utf-8", errors="replace").strip().splitlines():
                    if not line.strip():
                        continue
                    try:
                        entry = json.loads(line)
                    except json.JSONDecodeError:
                        continue

                    ts = entry.get("timestamp", "")
                    try:
                        if isinstance(ts, (int, float)):
                            t = float(ts)
                        else:
                            from datetime import datetime
                            t = datetime.fromisoformat(str(ts).replace("Z", "+00:00")).timestamp()
                    except (ValueError, TypeError):
                        continue

                    if t < cutoff:
                        continue

                    sid = entry.get("sessionId", "")
                    if sid:
                        seen_sessions.add(sid)

                    stats["total_prompt_calls"] += 1

                    # Extract token usage from message.usage
                    usage = (entry.get("message") or {}).get("usage") or {}
                    inp = usage.get("input_tokens") or usage.get("inputTokens") or 0
                    out = usage.get("output_tokens") or usage.get("outputTokens") or 0
                    tok = inp + out
                    stats["total_tokens"] += tok
                    stats["total_input"] += inp
                    stats["total_output"] += out

                    # Collect daily counts
                    from datetime import datetime
                    date_key = datetime.fromtimestamp(t).strftime("%Y-%m-%d")
                    dd = stats["daily"].setdefault(date_key, {"tokens": 0, "calls": 0})
                    dd["calls"] += 1
                    dd["tokens"] += tok

            except Exception:
                pass

        stats["sessions"] = len(seen_sessions)

        # ── Augment with global stats-cache.json (model/token totals) ──
        # The cache aggregates all projects, but model distribution is useful
        cache_file = self._claude_dir / "stats-cache.json"
        if cache_file.is_file():
            try:
                cache = json.loads(cache_file.read_text(encoding="utf-8"))
                model_usage = cache.get("modelUsage", {})
                if isinstance(model_usage, str):
                    model_usage = json.loads(model_usage)
                for model, mu in model_usage.items():
                    stats["by_model"][model] = {
                        "tokens": mu.get("inputTokens", 0) + mu.get("outputTokens", 0),
                        "calls": mu.get("messageCount", 0),
                    }
            except Exception:
                pass

        stats["daily"] = sorted(
            [{"date": k, **v} for k, v in stats["daily"].items()],
            key=lambda x: x["date"], reverse=True
        )[:days]

        return stats

    def get_task_stats(self, task_id: str) -> dict:
        """Per-task stats from token_tracking.json + JSONL estimation."""
        from pathlib import Path as _Path
        from kanban_framework.infra.filesystem import Filesystem as _FS

        result: dict = {
            "total_tokens": 0, "total_prompts": 0,
            "phases": {}, "agents": {}, "models": {},
            "phase_duration": {}, "phase_api_calls": {}, "step_api_calls": {},
            "real_api_calls": 0, "source": "native",
        }

        kanban_dir = self._root / ".kanban"
        if not kanban_dir.is_dir():
            kanban_dir = _Path(_FS.find_project_root()) / ".kanban"

        # 1. Try token_tracking.json first
        tt_file = kanban_dir / "reports" / "token_tracking.json"
        task_dir = kanban_dir / "tasks" / task_id
        archive_dir = kanban_dir / "archive" / task_id
        if archive_dir.is_dir() and not task_dir.is_dir():
            task_dir = archive_dir

        task_json = task_dir / "task.json"

        if tt_file.is_file():
            data = json.loads(tt_file.read_text(encoding="utf-8"))
            entry = data.get(task_id, {})
            if entry.get("total_tokens", 0) > 0:
                result["total_tokens"] = entry.get("total_tokens", 0)
                result["total_prompts"] = entry.get("total_prompts", 0)
                result["phases"] = entry.get("by_phase", {})
                result["agents"] = entry.get("agent_totals", {})
                result["models"] = entry.get("by_model", {})
                result["phase_duration"] = entry.get("phase_duration", {})

                # Subagent-based API call counting
                session_steps = entry.get("session_steps", {})
                session_phases = entry.get("session_phases", {})
                total_calls = 0
                for step, sids in session_steps.items():
                    step_calls = sum(self._count_subagent(sid) for sid in sids)
                    result["step_api_calls"][step] = step_calls
                    total_calls += step_calls
                for ph, sids in session_phases.items():
                    result["phase_api_calls"][ph] = sum(self._count_subagent(sid) for sid in sids)
                result["real_api_calls"] = total_calls
                result["source"] = "subagent_tracked"
                return result

        # 2. JSONL estimation fallback
        if task_json.is_file():
            try:
                task = json.loads(task_json.read_text(encoding="utf-8"))
                history = task.get("history", [])
                if history:
                    ts = []
                    for h in history:
                        for k in ("started_at", "completed_at"):
                            v = h.get(k)
                            if v:
                                try:
                                    ts.append(float(v))
                                except (ValueError, TypeError):
                                    pass
                    if ts:
                        t_min, t_max = min(ts) - 60, max(ts) + 60
                        result["real_api_calls"] = self._count_window(t_min, t_max)
                        if result["real_api_calls"] > 0:
                            result["total_tokens"] = round(result["real_api_calls"] * 800)
                            result["source"] = "jsonl_estimate"
                            result["note"] = f"Estimated from {result['real_api_calls']} JSONL calls"
                        # Per-phase
                        pw = {}
                        for h in history:
                            ph = h.get("phase", "")
                            if not ph: continue
                            for k in ("started_at", "completed_at"):
                                v = h.get(k)
                                if v:
                                    try:
                                        t = float(v)
                                        pw.setdefault(ph, {"min": 1e99, "max": -1e99})
                                        if t < pw[ph]["min"]: pw[ph]["min"] = t
                                        if t > pw[ph]["max"]: pw[ph]["max"] = t
                                    except (ValueError, TypeError):
                                        pass
                        # Infer start time from adjacent phases when only completed_at exists
                        completed_at = {}
                        for h in history:
                            ph = h.get("phase", "")
                            if not ph: continue
                            v = h.get("completed_at")
                            if v:
                                try:
                                    ts = float(v)
                                    if ts > 0:
                                        completed_at[ph] = ts
                                except (ValueError, TypeError):
                                    pass
                        sorted_phases = sorted(completed_at.items(), key=lambda x: x[1])
                        for i, (ph, end_time) in enumerate(sorted_phases):
                            w = pw.get(ph)
                            if not w: continue
                            if w["max"] - w["min"] < 1 and i > 0:
                                prev_end = sorted_phases[i - 1][1]
                                w["min"] = prev_end
                        # For phases still with min==max, use JSONL window end as fallback
                        for ph, w in pw.items():
                            if w["min"] < 1e99 and w["max"] - w["min"] < 1:
                                # Find last JSONL entry in this phase's window
                                last_ts = self._find_last_timestamp(w["min"] - 60, w["min"] + 3600)
                                if last_ts and last_ts > w["min"]:
                                    w["max"] = last_ts
                        for ph, w in pw.items():
                            if w["min"] < 1e99:
                                pc = self._count_window(w["min"] - 60, w["max"] + 60)
                                result["phase_api_calls"][ph] = pc
                                result["phases"][ph] = round(pc * 800)
                                result["phase_duration"][ph] = round(w["max"] - w["min"])
                        # Per-step
                        progress_file = task_dir / "progress.json"
                        if progress_file.is_file():
                            pg = json.loads(progress_file.read_text(encoding="utf-8"))
                            for sid, si in pg.get("steps", {}).items():
                                if si.get("status") != "completed": continue
                                ut = si.get("updated_at")
                                if ut:
                                    try:
                                        t = float(ut)
                                        result["step_api_calls"][sid] = self._count_window(t - 300, t + 10)
                                    except (ValueError, TypeError):
                                        pass
            except Exception:
                pass

        return result

    def _count_subagent(self, subagent_id: str) -> int:
        """Count entries in a subagent JSONL file."""
        projects_dir = self._claude_dir / "projects"
        if not projects_dir.is_dir():
            return 0
        for proj_dir in projects_dir.iterdir():
            if not proj_dir.is_dir():
                continue
            for session_dir in proj_dir.iterdir():
                if not session_dir.is_dir():
                    continue
                target = session_dir / "subagents" / f"{subagent_id}.jsonl"
                if target.is_file():
                    try:
                        return len([l for l in target.read_text(errors="replace").strip().splitlines() if l.strip()])
                    except Exception:
                        return 0
        return 0

    def _count_window(self, t_min: float, t_max: float) -> int:
        """Count JSONL entries within a time window."""
        count = 0
        cache_file = self._claude_dir / "stats-cache.json"
        # Use project JSONL files for accurate per-project counting
        jsonl_files = self._find_project_jsonl_files()
        for jf in jsonl_files:
            try:
                for line in jf.read_text(errors="replace").strip().splitlines():
                    if not line.strip():
                        continue
                    try:
                        e = json.loads(line)
                        ts = e.get("timestamp")
                        if not ts:
                            continue
                        t = float(ts) if isinstance(ts, (int, float)) else (
                            _dt.fromisoformat(str(ts).replace("Z", "+00:00")).timestamp()
                        )
                    except Exception:
                        continue
                    if t_min <= t <= t_max:
                        count += 1
            except Exception:
                pass
        return count

    def _find_last_timestamp(self, t_min: float, t_max: float) -> float | None:
        """Find the latest JSONL timestamp within a time window."""
        last = None
        jsonl_files = self._find_project_jsonl_files()
        for jf in jsonl_files:
            try:
                for line in jf.read_text(errors="replace").strip().splitlines():
                    if not line.strip():
                        continue
                    try:
                        e = json.loads(line)
                        ts = e.get("timestamp")
                        if not ts:
                            continue
                        t = float(ts) if isinstance(ts, (int, float)) else (
                            _dt.fromisoformat(str(ts).replace("Z", "+00:00")).timestamp()
                        )
                        if t_min <= t <= t_max:
                            if last is None or t > last:
                                last = t
                    except Exception:
                        continue
            except Exception:
                pass
        return last

    def _find_project_jsonl_files(self) -> list[Path]:
        """Find JSONL session files for this specific project.

        Claude Code organizes sessions under:
          ~/.claude/projects/<project-name-hash>/<uuid>.jsonl

        We match the project by resolving the project root path and looking
        for a matching directory name pattern.
        """
        files: list[Path] = []
        projects_dir = self._claude_dir / "projects"
        if not projects_dir.is_dir():
            return files

        # Resolve the actual project root (parent of .kanban)
        # self._root may be /path/to/project/.kanban or /path/to/project
        resolved = self._root.resolve()
        if resolved.name == ".kanban":
            resolved = resolved.parent

        # Match: project root name appears in the project dir name
        # e.g., "-Users-ks-128-Documents-important-demo"
        # Claude Code replaces underscores with hyphens in directory names
        # Windows paths use backslashes — normalize both separators
        root_name = str(resolved).replace("\\", "-").replace("/", "-").replace("_", "-")
        if root_name.startswith("-"):
            root_name = root_name[1:]  # strip leading dash (e.g. Windows drive letter)

        best_dir = None
        for proj_dir in projects_dir.iterdir():
            if not proj_dir.is_dir():
                continue
            dir_name = proj_dir.name
            # Match: project dir name contains the project path
            if root_name in dir_name or dir_name in root_name:
                if best_dir is None or len(list(proj_dir.glob("*.jsonl"))) > len(list(best_dir.glob("*.jsonl"))):
                    best_dir = proj_dir

        if best_dir is not None:
            for jf in sorted(best_dir.glob("*.jsonl")):
                if "subagents" not in str(jf):
                    files.append(jf)

        return files


class CodeBurnBackend:
    """Delegate to codeburn CLI for aggregated analytics.

    Requires: codeburn (brew install codeburn or pip install codeburn)
    Falls back to NativeBackend if codeburn is not installed.
    """

    def __init__(self, project_root: Path):
        self._root = Path(project_root)
        self._native = NativeBackend(project_root)

    def get_stats(self, days: int = 30) -> dict:
        import subprocess
        try:
            period = f"{days}days"
            result = subprocess.run(
                ["codeburn", "report", "-p", period, "--format", "json"],
                capture_output=True, text=True, timeout=15,
                cwd=str(self._root),
            )
            if result.returncode == 0 and result.stdout.strip():
                data = json.loads(result.stdout)
                overview = data.get("overview", {})
                tokens_info = overview.get("tokens", {})
                daily_raw = data.get("daily", [])
                # Convert codeburn daily format to kanban format
                daily = [{
                    "date": d.get("date", ""),
                    "calls": d.get("calls", 0),
                    "tokens": (d.get("inputTokens", 0) + d.get("outputTokens", 0)),
                } for d in daily_raw]
                return {
                    "total_tokens": tokens_info.get("input", 0) + tokens_info.get("output", 0),
                    "total_input": tokens_info.get("input", 0),
                    "total_output": tokens_info.get("output", 0),
                    "total_prompt_calls": overview.get("calls", 0),
                    "total_duration_seconds": 0,
                    "sessions": overview.get("sessions", 0),
                    "by_model": data.get("models", {}),
                    "daily": daily,
                    "source": "codeburn",
                }
        except Exception:
            pass
        # Fallback to native
        return self._native.get_stats(days)

    def get_task_stats(self, task_id: str) -> dict:
        # CodeBurn has no per-task capability, fallback to native
        return self._native.get_task_stats(task_id)


# Registry
STATS_BACKEND_REGISTRY = {
    "native": NativeBackend,
    "codeburn": CodeBurnBackend,
}


def resolve_stats_backend(name: str, project_root: Path) -> StatsBackend:
    """Resolve a stats backend by name. Falls back to native."""
    cls = STATS_BACKEND_REGISTRY.get(name)
    if cls is None:
        import warnings
        warnings.warn(f"Unknown stats backend '{name}', falling back to native")
        cls = NativeBackend
    return cls(project_root)
