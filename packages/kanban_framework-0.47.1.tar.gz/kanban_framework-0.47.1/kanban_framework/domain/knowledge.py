"""Knowledge management backed by SQLite (stdlib, zero deps).

Single .db file replaces entries/*.json, index.json, usage-log.json, domains.json.
FTS5 provides full-text search with BM25 ranking.
jieba (optional) provides Chinese tokenization for FTS5 search.
fastembed (optional, ONNX-based) provides semantic vector search.
"""
from __future__ import annotations
import json
import sqlite3
import struct
from datetime import datetime, timezone, timedelta

# Lazy imports: jieba and chromadb are only loaded when actually needed.
# Simple operations like get/list/health use only SQLite and don't pay their cost.
_jieba = None
_chromadb = None

def _get_jieba():
    global _jieba
    if _jieba is None:
        try:
            import jieba as _j
            _jieba = _j
        except ImportError:
            _jieba = False
    return _jieba if _jieba is not False else None

def _get_chromadb():
    global _chromadb
    if _chromadb is None:
        try:
            import chromadb as _c
            _chromadb = _c
        except ImportError:
            _chromadb = False
    return _chromadb if _chromadb is not False else None

_EMBED_MODEL = None
_EMBED_FAILED = False
_EMBED_DIM = 512  # bge-small-zh-v1.5


def _get_embed_model():
    """Lazy-load bge-small-zh-v1.5 via fastembed (ONNX, no PyTorch).
    Returns None if unavailable.
    """
    global _EMBED_MODEL, _EMBED_FAILED, _EMBED_DIM
    if _EMBED_FAILED:
        return None
    if _EMBED_MODEL is None:
        try:
            from fastembed import TextEmbedding
            _EMBED_MODEL = TextEmbedding(model_name="BAAI/bge-small-zh-v1.5")
            # Probe dim from first embedding
            probe = list(_EMBED_MODEL.embed(["dim_probe"]))[0]
            _EMBED_DIM = len(probe)
        except Exception:
            _EMBED_FAILED = True
            return None
    return _EMBED_MODEL


def _embed(text: str) -> bytes | None:
    """Compute float32 embedding for text. Returns packed bytes.
    Returns None if embedding model is unavailable.
    """
    if _EMBED_FAILED or not text:
        return None
    model = _get_embed_model()
    if model is None:
        return None
    try:
        vec = list(model.embed([text]))[0]
        return struct.pack(f"{len(vec)}f", *vec)
    except Exception:
        return None


def _unpack_embedding(blob: bytes) -> list[float]:
    """Unpack BLOB back to float list."""
    n = len(blob) // 4
    return list(struct.unpack(f"{n}f", blob))


def _cosine_similarity(a: list[float], b: list[float]) -> float:
    """Cosine similarity between two vectors (both should be normalized)."""
    return sum(x * y for x, y in zip(a, b))


def _segment(text: str) -> str:
    """Segment Chinese text with jieba. Returns space-separated tokens.
    If jieba is not installed, returns the original text unchanged.
    """
    if not _get_jieba() or not text:
        return text
    # Only segment if text contains CJK characters
    if not any('一' <= c <= '鿿' for c in text):
        return text
    words = _get_jieba().cut(text)
    return " ".join(w for w in words if w.strip())

DEFAULT_DOMAINS = {
    "cli": {"label": "CLI 命令", "keywords": ["argparse", "dispatch", "subcommand", "cli"]},
    "agent": {"label": "Agent 定义", "keywords": ["agent", "prompt", "role", "model"]},
    "testing": {"label": "测试", "keywords": ["pytest", "assert", "mock", "coverage", "test"]},
    "infra": {"label": "基础设施", "keywords": ["filesystem", "git", "config", "worktree", "path"]},
    "workflow": {"label": "工作流", "keywords": ["FSM", "state", "transition", "iteration", "phase"]},
    "dashboard": {"label": "看板仪表盘", "keywords": ["dashboard", "frontend", "js", "css"]},
    "git": {"label": "版本控制", "keywords": ["commit", "branch", "merge", "push", "remote"]},
    "web": {"label": "Web 开发", "keywords": ["fastapi", "flask", "django", "express", "api", "rest", "http", "router", "middleware", "cors"]},
    "database": {"label": "数据库", "keywords": ["sqlite", "sql", "postgresql", "mysql", "orm", "migration", "query", "transaction"]},
    "ui": {"label": "前端界面", "keywords": ["component", "react", "vue", "template", "render", "dom", "event", "async"]},
    "game": {"label": "游戏开发", "keywords": ["game", "pygame", "sprite", "collision", "render", "fps", "input", "animation"]},
    "security": {"label": "安全", "keywords": ["auth", "token", "jwt", "hash", "encrypt", "permission", "xss", "csrf"]},
}

# Standard category and severity enumerations (#238)
VALID_CATEGORIES = {
    "架构": {"label": "架构", "desc": "系统设计、模块结构、数据流", "weight": 1.0},
    "踩坑": {"label": "踩坑", "desc": "已知的坑和 workaround", "weight": 1.3},
    "反模式": {"label": "反模式", "desc": "明确的错误做法及其危害", "weight": 1.5},
    "最佳实践": {"label": "最佳实践", "desc": "经过验证的推荐做法", "weight": 1.2},
    "优化": {"label": "优化", "desc": "性能或质量提升方案", "weight": 1.0},
    "流程": {"label": "流程", "desc": "工作流、规范、SOP", "weight": 1.0},
    "接口": {"label": "接口", "desc": "API/协议/数据格式规范", "weight": 1.0},
    "工具": {"label": "工具", "desc": "工具使用技巧", "weight": 1.0},
}

VALID_SEVERITIES = {
    "high": {"label": "high", "desc": "必须遵守，违反会导致严重问题", "pitfall_weight": 1.5},
    "medium": {"label": "medium", "desc": "建议遵守，违反可能导致问题", "pitfall_weight": 1.0},
    "low": {"label": "low", "desc": "参考性质", "pitfall_weight": 0.8},
}

STALE_DAYS = 30

# Score threshold for hybrid search — results below this are filtered.
# Default 0.0 preserves backward compatibility (no filtering).
DEFAULT_SCORE_THRESHOLD = 0.0

# Technology abbreviation → full name mapping for query expansion (#230).
TECH_ABBREVIATIONS: dict[str, str] = {
    # Infrastructure
    "k8s": "Kubernetes",
    "k3s": "K3s",
    "ec2": "AWS EC2",
    "ecs": "AWS ECS",
    "eks": "AWS EKS",
    "s3": "AWS S3",
    "rds": "AWS RDS",
    "vpc": "AWS VPC",
    "cdn": "CDN",
    "lb": "Load Balancer",
    "dns": "DNS",
    "tls": "TLS",
    "ssl": "SSL",
    "https": "HTTPS",
    "ssh": "SSH",
    "vpn": "VPN",
    # Auth & Security
    "jwt": "JWT JSON Web Token",
    "oauth": "OAuth OAuth2",
    "oauth2": "OAuth2",
    "sso": "SSO Single Sign-On",
    "rbac": "RBAC Role-Based Access Control",
    "mfa": "MFA Multi-Factor Authentication",
    "csrf": "CSRF Cross-Site Request Forgery",
    "xss": "XSS Cross Site Scripting",
    "cors": "CORS Cross Origin Resource Sharing",
    # Development
    "api": "API",
    "sdk": "SDK",
    "cli": "CLI Command Line Interface",
    "ci_cd": "CI/CD",
    "cicd": "CI/CD Continuous Integration Deployment",
    "orm": "ORM Object-Relational Mapping",
    "mvc": "MVC Model View Controller",
    "mvvm": "MVVM Model View ViewModel",
    "ddd": "DDD Domain-Driven Design",
    "tdd": "TDD Test-Driven Development",
    "bdd": "BDD Behavior-Driven Development",
    "db": "Database",
    "sql": "SQL",
    "nosql": "NoSQL",
    "crud": "CRUD Create Read Update Delete",
    "rest": "REST Representational State Transfer",
    "grpc": "gRPC",
    "mq": "Message Queue",
    "rpc": "RPC Remote Procedure Call",
    "dag": "DAG Directed Acyclic Graph",
    "fsm": "FSM Finite State Machine",
    "dsl": "DSL Domain-Specific Language",
    # GUI Frameworks
    "pyqt": "PyQt Qt Python GUI",
    "pyside": "PySide Qt Python GUI",
    "qt": "Qt Framework C++ GUI",
    "tkinter": "Tkinter Python GUI",
    "wx": "wxPython wxWidgets GUI",
}


def _expand_abbreviations(query: str) -> str:
    """Expand known tech abbreviations in a search query. (#230)

    Returns the ORIGINAL query with abbreviations appended using OR operator
    for FTS5 compatibility. Special chars in expansion values are stripped
    to avoid FTS5 syntax errors (#231).

    Example: "K8s deployment" → "K8s OR kubernetes deployment"
    """
    if not query:
        return query
    import re
    expanded = []
    for word in query.split():
        key = word.lower().rstrip(",.;:")
        if key in TECH_ABBREVIATIONS:
            # Strip special chars that break FTS5 MATCH (#231)
            full = re.sub(r'[^a-zA-Z0-9\s]', ' ', TECH_ABBREVIATIONS[key])
            full = ' '.join(full.split())  # normalize whitespace
            expanded.append(f"{word} OR {full}")
        else:
            expanded.append(word)
    return " ".join(expanded)


def _stale_penalty(stale_at_str: str | None) -> float:
    """Return a score multiplier for stale entries. (#226)

    Returns 1.0 for active entries, 0.7 for past stale_at, 0.4 for
    entries more than 30 days past stale_at.
    """
    if not stale_at_str:
        return 1.0
    try:
        stale_dt = datetime.fromisoformat(stale_at_str)
        now = datetime.now(timezone.utc)
        if stale_dt.tzinfo is None:
            stale_dt = stale_dt.replace(tzinfo=timezone.utc)
        if now < stale_dt:
            return 1.0
        days_past = (now - stale_dt).days
        if days_past <= 30:
            return 0.7
        elif days_past <= 90:
            return 0.4
        else:
            return 0.2
    except (ValueError, TypeError):
        return 1.0


def _substring_match_score(query: str, text: str) -> float:
    """Check if query appears as substring in text. Returns bonus score. (#224)

    Handles partial-word matches like "OAuth" matching "OAuth2".
    """
    if not query or not text:
        return 0.0
    ql = query.lower()
    tl = text.lower()
    if ql in tl:
        # Longer substring match = higher bonus
        return min(0.15, len(ql) / len(tl) * 0.15)
    return 0.0


class KnowledgeManager:
    def __init__(self, fs, backend=None, read_only=False):
        self._fs = fs
        self._read_only = read_only
        db_dir = fs.kanban_dir / "knowledge"
        fs.ensure_dir(db_dir)
        self._db_path = db_dir / "knowledge.db"
        self._conn = sqlite3.connect(str(self._db_path), timeout=5)
        self._conn.row_factory = sqlite3.Row
        self._conn.text_factory = str  # Fix #212: Chinese garbled on Windows
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA busy_timeout=3000")  # #315: prevent hang on locked DB
        self._chroma_client = None
        self._chroma_collection = None

        if read_only:
            # Fast path: validate schema exists, skip all write-related init.
            # Read-only commands (search/get/list/hybrid) don't need
            # schema mutations, backfills, migrations, backups, or config.
            try:
                self._conn.execute("SELECT 1 FROM entries LIMIT 1")
            except sqlite3.OperationalError:
                self._ensure_schema()
            from kanban_framework.domain.knowledge_backend import BuiltinBackend
            self._backend = BuiltinBackend(self)
            # Preload jieba in background so first Chinese search is fast (#perf)
            import threading
            threading.Thread(target=_get_jieba, daemon=True).start()
        else:
            self._ensure_schema()
            self._ensure_domains()
            # Migrate historical data for new columns (#235)
            self._migrate_stale_at()

            # Auto-backup: run in background thread to avoid blocking CLI (#315)
            import threading
            threading.Thread(target=self._auto_backup, daemon=True).start()
            # Backend adapter: resolved from config or default to BuiltinBackend
            self._init_backend(fs, backend)

    def _init_backend(self, fs, backend):
        from kanban_framework.domain.knowledge_backend import resolve_backend, MultiBackend, ShareBackend

        if backend is None:
            backend_name = "builtin"
            share_path = None
            try:
                cfg_path = fs.config_file()
                if cfg_path.is_file():
                    import json
                    raw = json.loads(cfg_path.read_text(encoding="utf-8"))
                    kb_cfg = raw.get("knowledge", {})
                    if isinstance(kb_cfg, dict):
                        backend_name = kb_cfg.get("backend", "builtin")
                        share_cfg = kb_cfg.get("share", {})
                        if isinstance(share_cfg, dict) and share_cfg.get("enabled"):
                            share_path = share_cfg.get("path")
            except Exception:
                pass

            primary = resolve_backend(backend_name, self)
            # Multi-backend: local + share coexisting (#237)
            if share_path:
                share = ShareBackend(self, share_path)
                self._backend = MultiBackend(primary, share)
            else:
                self._backend = primary
        else:
            self._backend = backend

    # -- backup --

    MAX_BACKUPS = 5

    def _migrate_stale_at(self) -> None:
        """Backfill stale_at for historical entries that have NULL stale_at. (#235)

        Sets stale_at = created_at + 90 days so existing entries get a reasonable
        default instead of silently staying active forever.

        Short-circuits on the first row (LIMIT 1) to avoid full table scan
        on every startup. Once all entries have stale_at, this is ~1ms. (#315)
        """
        try:
            null_exists = self._conn.execute(
                "SELECT 1 FROM entries WHERE stale_at IS NULL LIMIT 1"
            ).fetchone()
            if null_exists:
                self._conn.execute(
                    "UPDATE entries SET stale_at = datetime(created_at, '+90 days') "
                    "WHERE stale_at IS NULL"
                )
                self._conn.commit()
        except Exception:
            pass  # Migration must not block startup

    def _auto_backup(self) -> None:
        """Rotate backups of knowledge.db on startup (at most once per hour).

        Creates knowledge.db.bak.1 through knowledge.db.bak.5, rotating
        oldest out. Skips if DB is empty or last backup was < 1 hour ago.
        """
        import shutil
        try:
            src = self._db_path
            if not src.is_file() or src.stat().st_size == 0:
                return

            # Throttle: skip if last backup was within the last hour
            newest = self._db_path.parent / "knowledge.db.bak.1"
            if newest.is_file():
                age_s = time.time() - newest.stat().st_mtime
                if age_s < 3600:
                    return

            # Rotate: bak.4 → bak.5, bak.3 → bak.4, ... bak.1 → bak.2
            for i in range(self.MAX_BACKUPS, 0, -1):
                old = self._db_path.parent / f"knowledge.db.bak.{i}"
                if old.is_file():
                    if i == self.MAX_BACKUPS:
                        old.unlink()
                    else:
                        new = self._db_path.parent / f"knowledge.db.bak.{i + 1}"
                        shutil.move(str(old), str(new))

            # Create fresh backup using sqlite3 backup API (consistent copy)
            bak_path = self._db_path.parent / "knowledge.db.bak.1"
            dst = sqlite3.connect(str(bak_path))
            self._conn.backup(dst)
            dst.close()
        except Exception:
            pass  # Backup failure must never block startup

    # -- schema --

    def _ensure_schema(self):
        # Base tables
        self._conn.executescript("""
            CREATE TABLE IF NOT EXISTS entries (
                id TEXT PRIMARY KEY,
                domain TEXT NOT NULL,
                category TEXT NOT NULL,
                title TEXT NOT NULL,
                content TEXT NOT NULL,
                content_segmented TEXT DEFAULT '',
                code_example TEXT DEFAULT '',
                tags TEXT DEFAULT '[]',
                source TEXT DEFAULT '{}',
                severity TEXT DEFAULT 'medium',
                status TEXT DEFAULT 'active',
                created_at TEXT NOT NULL,
                updated_at TEXT,
                stale_at TEXT,
                referenced_count INTEGER DEFAULT 0,
                last_referenced_at TEXT,
                last_referenced_by TEXT,
                type TEXT DEFAULT 'knowledge',
                steps TEXT DEFAULT NULL
            );
            CREATE TABLE IF NOT EXISTS usage_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                entry_id TEXT NOT NULL,
                task_id TEXT NOT NULL,
                timestamp TEXT NOT NULL
            );
        """)

        # Add content_segmented column to existing databases (migration)
        cols = {r[1] for r in self._conn.execute("PRAGMA table_info(entries)")}
        if "content_segmented" not in cols:
            self._conn.execute("ALTER TABLE entries ADD COLUMN content_segmented TEXT DEFAULT ''")
        if "embedding" not in cols:
            self._conn.execute("ALTER TABLE entries ADD COLUMN embedding BLOB DEFAULT NULL")
        if "type" not in cols:
            self._conn.execute("ALTER TABLE entries ADD COLUMN type TEXT DEFAULT 'knowledge'")
        if "steps" not in cols:
            self._conn.execute("ALTER TABLE entries ADD COLUMN steps TEXT DEFAULT NULL")

        # Rebuild FTS5 with content_segmented column
        has_content_seg = False
        try:
            fts_cols = {r[1] for r in self._conn.execute("PRAGMA table_info(entries_fts)")}
            has_content_seg = "content_segmented" in fts_cols
        except sqlite3.OperationalError:
            pass

        if not has_content_seg:
            self._conn.execute("DROP TABLE IF EXISTS entries_fts")
            self._conn.execute(
                "CREATE VIRTUAL TABLE entries_fts USING fts5("
                "title, content, content_segmented, code_example, tags, "
                "content=entries, content_rowid=rowid)"
            )
            # Populate FTS5 from existing entries
            self._conn.execute(
                "INSERT INTO entries_fts(rowid, title, content, content_segmented, code_example, tags) "
                "SELECT rowid, title, content, content_segmented, code_example, tags FROM entries"
            )

        # Rebuild triggers (idempotent IF NOT EXISTS)
        self._conn.executescript("""
            DROP TRIGGER IF EXISTS entries_ai;
            DROP TRIGGER IF EXISTS entries_ad;
            DROP TRIGGER IF EXISTS entries_au;
            CREATE TRIGGER entries_ai AFTER INSERT ON entries BEGIN
                INSERT INTO entries_fts(rowid, title, content, content_segmented, code_example, tags)
                VALUES (new.rowid, new.title, new.content, new.content_segmented, new.code_example, new.tags);
            END;
            CREATE TRIGGER entries_ad AFTER DELETE ON entries BEGIN
                INSERT INTO entries_fts(entries_fts, rowid, title, content, content_segmented, code_example, tags)
                VALUES ('delete', old.rowid, old.title, old.content, old.content_segmented, old.code_example, old.tags);
            END;
            CREATE TRIGGER entries_au AFTER UPDATE ON entries BEGIN
                INSERT INTO entries_fts(entries_fts, rowid, title, content, content_segmented, code_example, tags)
                VALUES ('delete', old.rowid, old.title, old.content, old.content_segmented, old.code_example, old.tags);
                INSERT INTO entries_fts(rowid, title, content, content_segmented, code_example, tags)
                VALUES (new.rowid, new.title, new.content, new.content_segmented, new.code_example, new.tags);
            END;
        """)

    def _ensure_domains(self):
        self._conn.execute(
            "CREATE TABLE IF NOT EXISTS domains (name TEXT PRIMARY KEY, label TEXT, keywords TEXT)"
        )
        existing = {r[0] for r in self._conn.execute("SELECT name FROM domains")}
        for name, info in DEFAULT_DOMAINS.items():
            if name not in existing:
                self._conn.execute(
                    "INSERT INTO domains(name, label, keywords) VALUES(?,?,?)",
                    (name, info["label"], json.dumps(info["keywords"])),
                )

        # Backfill content_segmented for entries created before jieba integration
        if _get_jieba():
            blanks = self._conn.execute(
                "SELECT rowid, title, content, code_example FROM entries WHERE content_segmented=''"
            ).fetchall()
            if blanks:
                for row in blanks:
                    seg = _segment(row[1]) + " " + _segment(row[2])
                    if row[3]:
                        seg += " " + _segment(row[3])
                    self._conn.execute(
                        "UPDATE entries SET content_segmented=? WHERE rowid=?",
                        (seg, row[0]),
                    )
                self._conn.commit()
                # Rebuild FTS5 to pick up the new segmented content
                self._conn.execute("DELETE FROM entries_fts")
                self._conn.execute(
                    "INSERT INTO entries_fts(rowid, title, content, content_segmented, code_example, tags) "
                    "SELECT rowid, title, content, content_segmented, code_example, tags FROM entries"
                )

        # Backfill embeddings for entries created before fastembed integration
        model = _get_embed_model()
        if model is not None:
            blanks = self._conn.execute(
                "SELECT rowid, title, content FROM entries WHERE embedding IS NULL"
            ).fetchall()
            if blanks:
                for row in blanks:
                    emb = _embed(row[1] + " " + row[2])
                    if emb:
                        self._conn.execute(
                            "UPDATE entries SET embedding=? WHERE rowid=?",
                            (emb, row[0]),
                        )
                self._conn.commit()

    # -- public API --

    MAX_CONTENT_LENGTH = 3000
    MAX_CODE_EXAMPLE_LENGTH = 2000

    def add_entry(self, *, domain, category, title, content,
                  tags=None, severity="medium", source=None, code_example="",
                  status="active", upsert=False, ttl_days=None,
                  entry_type="knowledge", steps=None):
        if not title.strip() and not content.strip():
            raise ValueError("at least title or content is required")
        # Enforce content size limits (#knowledge-size-limit)
        if len(content) > self.MAX_CONTENT_LENGTH:
            content = content[:self.MAX_CONTENT_LENGTH]
        if len(code_example) > self.MAX_CODE_EXAMPLE_LENGTH:
            code_example = code_example[:self.MAX_CODE_EXAMPLE_LENGTH]
        # Validate category and severity against standard enumerations (#238)
        if category not in VALID_CATEGORIES:
            raise ValueError(
                f"invalid category '{category}'. Valid: {sorted(VALID_CATEGORIES.keys())}"
            )
        if severity not in VALID_SEVERITIES:
            raise ValueError(
                f"invalid severity '{severity}'. Valid: {sorted(VALID_SEVERITIES.keys())}"
            )
        tags = tags or []
        source = source or {}
        now = datetime.now(timezone.utc).isoformat()
        segmented = _segment(title) + " " + _segment(content)
        if code_example:
            segmented += " " + _segment(code_example)
        emb = _embed(title + " " + content)

        # Compute stale_at from ttl_days (#226)
        stale_at = None
        if ttl_days is not None and ttl_days > 0:
            stale_at = (datetime.now(timezone.utc) + timedelta(days=ttl_days)).isoformat()

        # Check for existing entry with same title + domain (#189)
        existing = self._conn.execute(
            "SELECT id FROM entries WHERE title=? AND domain=? LIMIT 1",
            (title.strip(), domain),
        ).fetchone()
        if existing:
            if not upsert:
                return {"id": existing[0], "skipped": True, "reason": "duplicate", "existing_id": existing[0]}
            self._conn.execute(
                """UPDATE entries SET category=?, content=?, content_segmented=?,
                   embedding=?, code_example=?, tags=?, source=?, severity=?,
                   status=?, updated_at=?, stale_at=?, type=?, steps=?
                   WHERE id=?""",
                (category, content, segmented, emb, code_example,
                 json.dumps(tags), json.dumps(source), severity, status, now,
                 stale_at, entry_type, json.dumps(steps) if steps else None, existing[0]),
            )
            self._conn.commit()
            entry = self.get_entry(existing[0])
            self._chroma_upsert_entry(existing[0], title, content, domain, category, status)
            return entry

        eid = self._next_id()
        self._conn.execute(
            """INSERT INTO entries(id, domain, category, title, content, content_segmented,
               embedding, code_example, tags, source, severity, status, created_at, updated_at, stale_at, type, steps)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (eid, domain, category, title, content, segmented, emb, code_example,
             json.dumps(tags), json.dumps(source), severity, status, now, now, stale_at,
             entry_type, json.dumps(steps) if steps else None),
        )
        self._conn.commit()
        entry = self.get_entry(eid)
        self._chroma_upsert_entry(eid, title, content, domain, category, status)
        return entry

    def get_entry(self, entry_id):
        row = self._conn.execute("SELECT * FROM entries WHERE id=?", (entry_id,)).fetchone()
        return self._row_to_dict(row) if row else None

    def delete_entry(self, entry_id):
        self._conn.execute("DELETE FROM entries WHERE id=?", (entry_id,))
        self._conn.execute("DELETE FROM entries_fts WHERE rowid=(SELECT rowid FROM entries WHERE id=?)", (entry_id,))
        self._conn.commit()

    def list_entries(self, domain=None, category=None, status="active", limit=50, offset=0):
        """List entries with optional filters.

        Args:
            domain: Optional domain filter (e.g. 'testing', 'cli').
            category: Optional category filter (e.g. '踩坑', '架构').
            status: Entry status filter ('active', 'stale', 'draft'). Default 'active'.
            limit: Max entries to return (default 50).
            offset: Pagination offset (default 0).

        Returns:
            List of entry dicts ordered by id.
        """
        conditions = []
        params = []

        if domain:
            conditions.append("domain = ?")
            params.append(domain)
        if category:
            conditions.append("category = ?")
            params.append(category)
        if status:
            conditions.append("status = ?")
            params.append(status)

        where = " AND ".join(conditions) if conditions else "1=1"
        query = f"SELECT * FROM entries WHERE {where} ORDER BY id LIMIT ? OFFSET ?"
        params.extend([limit, offset])
        rows = self._conn.execute(query, params).fetchall()
        return [self._row_to_dict(r) for r in rows]

    # -- Chroma vector DB integration --

    def _ensure_chroma(self):
        """Lazily initialize Chroma PersistentClient and collection.

        Backfills existing entries with embeddings from SQLite on first run.
        Returns True if Chroma is ready, False otherwise.

        When chromadb has not been imported yet, return False immediately
        instead of paying the ~900ms import cost. Callers should fall back
        to FTS5-only search. (#perf)
        """
        import sys as _sys
        if "chromadb" not in _sys.modules:
            if not _get_chromadb():
                return False
        if self._chroma_collection is not None:
            return True
        try:
            chroma_dir = str(self._fs.kanban_dir / "knowledge" / "chroma")
            self._chroma_client = _get_chromadb().PersistentClient(path=chroma_dir)
            self._chroma_collection = self._chroma_client.get_or_create_collection(
                name="knowledge_entries",
                metadata={"hnsw:space": "cosine"},
            )
            # Backfill existing entries that have embeddings
            existing_ids = set(self._chroma_collection.get()["ids"])
            rows = self._conn.execute(
                "SELECT * FROM entries WHERE embedding IS NOT NULL"
            ).fetchall()
            for r in rows:
                eid = r["id"]
                if eid in existing_ids:
                    continue
                emb_blob = r["embedding"]
                if not emb_blob:
                    continue
                e_vec = _unpack_embedding(emb_blob)
                title = r["title"] or ""
                content = r["content"] or ""
                text = title + " " + content
                self._chroma_collection.add(
                    ids=[eid],
                    embeddings=[e_vec],
                    documents=[text],
                    metadatas=[{
                        "id": eid,
                        "domain": r["domain"],
                        "category": r["category"],
                        "title": title,
                        "status": r["status"],
                    }],
                )
            return True
        except Exception:
            return False

    def _chroma_upsert_entry(self, entry_id, title, content, domain, category, status):
        """Upsert a single entry to Chroma. Silently ignores failures."""
        if not self._ensure_chroma():
            return
        try:
            text = (title or "") + " " + (content or "")
            emb = _embed(text)
            if emb is None:
                return
            e_vec = _unpack_embedding(emb)
            self._chroma_collection.upsert(
                ids=[entry_id],
                embeddings=[e_vec],
                documents=[text],
                metadatas=[{
                    "id": entry_id,
                    "domain": domain,
                    "category": category,
                    "title": title,
                    "status": status,
                }],
            )
        except Exception:
            pass  # Chroma failure must not block SQLite writes

    def _chroma_delete_entry(self, entry_id):
        """Remove an entry from Chroma by ID. Silently ignores failures."""
        if self._chroma_collection is None:
            return
        try:
            self._chroma_collection.delete(ids=[entry_id])
        except Exception:
            pass

    def search(self, keyword, domain=None, limit=20):
        if not keyword:
            return []

        # Expand tech abbreviations for better recall (#230)
        expanded = _expand_abbreviations(keyword)

        # Segment the query for Chinese search
        if any('一' <= c <= '鿿' for c in keyword) and _get_jieba():
            segmented = " ".join(w for w in _get_jieba().cut(expanded) if w.strip())
            query = """SELECT e.*, rank FROM entries_fts f
                       JOIN entries e ON e.rowid = f.rowid
                       WHERE entries_fts MATCH ? ORDER BY rank LIMIT ?"""
            params = [segmented, limit]
            rows = self._fts_safe(query, params)
            if not rows and " " in segmented:
                or_query = segmented.replace(" ", " OR ")
                params = [or_query, limit]
                rows = self._fts_safe(query, params)
            if not rows:
                params = [keyword, limit]
                rows = self._fts_safe(query, params)
        else:
            query = """SELECT e.*, rank FROM entries_fts f
                       JOIN entries e ON e.rowid = f.rowid
                       WHERE entries_fts MATCH ? ORDER BY rank LIMIT ?"""
            for q in (expanded, keyword):
                if q == keyword and expanded == keyword:
                    params = [keyword, limit]
                    rows = self._fts_safe(query, params)
                    break
                params = [q, limit]
                rows = self._fts_safe(query, params)
                if rows:
                    break
            else:
                rows = []

        results = [self._row_to_dict(r) for r in rows]

        # Substring matching bonus for partial-word queries (#224)
        # Example: "OAuth" should match entries containing "OAuth2"
        if keyword and results:
            for r in results:
                title_bonus = _substring_match_score(keyword, r.get("title", ""))
                content_bonus = _substring_match_score(keyword, r.get("content", ""))
                bonus = max(title_bonus, content_bonus)
                if bonus > 0:
                    current_score = r.get("score", 0.0)
                    r["score"] = float(current_score) + bonus

        # Fallback: if FTS5 returns nothing, try SQL LIKE for substring (#224)
        if not results and keyword:
            kw = f"%{keyword}%"
            like_rows = self._conn.execute(
                "SELECT * FROM entries WHERE status='active' AND "
                "(title LIKE ? OR content LIKE ?) LIMIT ?",
                (kw, kw, limit),
            ).fetchall()
            results = [self._row_to_dict(r) for r in like_rows]

        if domain:
            results = [r for r in results if r["domain"] == domain]

        # Apply stale penalty to sort expired entries lower (#226)
        for r in results:
            r["_stale_penalty"] = _stale_penalty(r.get("stale_at"))

        return results

    def search_by_domain(self, domain, severity=None, status="active", limit=20):
        rows = self._conn.execute(
            """SELECT * FROM entries WHERE domain=? AND status=?
               {} ORDER BY referenced_count DESC LIMIT ?""".format(
                "AND severity=?" if severity else ""),
            (domain, status, *([severity] if severity else []), limit),
        ).fetchall()
        return [self._row_to_dict(r) for r in rows]

    def search_by_tag(self, tag):
        rows = self._conn.execute(
            "SELECT * FROM entries WHERE tags LIKE ?", (f'%"{tag}"%',)
        ).fetchall()
        return [self._row_to_dict(r) for r in rows]

    def search_by_task(self, task_id):
        rows = self._conn.execute(
            "SELECT * FROM entries WHERE source LIKE ?", (f'%"{task_id}"%',)
        ).fetchall()
        return [self._row_to_dict(r) for r in rows]

    def search_semantic(self, query: str, limit: int = 20) -> list[dict]:
        """Semantic search using Chroma ANN with cosine distance.

        Falls back to full-table cosine scan if Chroma is unavailable, then to
        keyword search if embeddings are also unavailable.
        """
        if not query or _EMBED_FAILED:
            return self.search(query, limit=limit) if query else []

        model = _get_embed_model()
        if model is None:
            return self.search(query, limit=limit)

        # Skip semantic if chromadb / fastembed not already loaded (#perf)
        import sys as _sys
        if "chromadb" not in _sys.modules and "fastembed" not in _sys.modules:
            return self.search(query, limit=limit)

        q_emb = _embed(query)
        if q_emb is None:
            return self.search(query, limit=limit)

        q_vec = _unpack_embedding(q_emb)

        # Try Chroma ANN first
        if self._ensure_chroma():
            try:
                results = self._chroma_collection.query(
                    query_embeddings=[q_vec],
                    n_results=limit,
                )
                ids = results.get("ids", [[]])[0]
                if ids is not None and len(ids) > 0:
                    distances = results.get("distances", [[]])[0]
                    entries = []
                    for idx, eid in enumerate(ids):
                        entry = self.get_entry(eid)
                        if entry:
                            if distances and idx < len(distances):
                                entry["score"] = round(1.0 - distances[idx], 4)
                            entries.append(entry)
                    return entries
            except Exception:
                pass  # Fall through to manual scan

        # Fallback: full-table scan with cosine similarity
        rows = self._conn.execute(
            "SELECT * FROM entries WHERE embedding IS NOT NULL AND status='active'"
        ).fetchall()

        scored = []
        for r in rows:
            emb_blob = r["embedding"]
            if not emb_blob:
                continue
            e_vec = _unpack_embedding(emb_blob)
            score = _cosine_similarity(q_vec, e_vec)
            entry = self._row_to_dict(r)
            scored.append((score, entry))

        scored.sort(key=lambda x: x[0], reverse=True)
        return [e for _, e in scored[:limit]]

    def search_hybrid(self, keyword: str, limit: int = 20,
                      score_threshold: float | None = None) -> list[dict]:
        """Hybrid search: BM25 keyword + semantic vector fused via RRF.

        Falls back to FTS5-only when chromadb is not available, avoiding
        the ~1.3s import cost of chromadb + fastembed for simple queries.
        """
        if score_threshold is None:
            score_threshold = DEFAULT_SCORE_THRESHOLD

        kw_results = self.search(keyword, limit=limit * 2) if keyword else []

        # Only attempt semantic search if chromadb is already loaded.
        # If not, skip to avoid blocking the query on chromadb import (#perf).
        try:
            sem_results = self.search_semantic(keyword, limit=limit * 2)
        except Exception:
            sem_results = []

        if not sem_results:
            return kw_results[:limit]

        # Reciprocal Rank Fusion
        scores: dict[str, float] = {}
        k = 60.0  # RRF constant

        for rank, r in enumerate(kw_results, 1):
            eid = r["id"]
            scores[eid] = scores.get(eid, 0) + 1.0 / (k + rank)

        for rank, r in enumerate(sem_results, 1):
            eid = r["id"]
            scores[eid] = scores.get(eid, 0) + 1.0 / (k + rank)

        # Merge entries, sort by combined score, apply threshold (#229)
        all_entries = {r["id"]: r for r in kw_results + sem_results}
        ranked = sorted(scores.items(), key=lambda x: x[1], reverse=True)

        # Score threshold: only filter when explicitly set (> 0).
        # Auto-thresholding hurts cross-language queries (#232, #233).
        return [all_entries[eid] for eid, s in ranked[:limit]
                if eid in all_entries
                and (score_threshold <= 0 or s >= score_threshold)]

    # ── Internal methods (delegated by BuiltinBackend) ──────────────────

    def _fts_safe(self, query, params):
        """Execute FTS5 MATCH safely, falling back to empty on syntax error. (#270)"""
        try:
            return self._conn.execute(query, params).fetchall()
        except sqlite3.OperationalError:
            return []

    def _search_fts(self, keyword: str, limit: int = 20) -> list[dict]:
        """Raw FTS5 keyword search. Used by BuiltinBackend."""
        return self.search(keyword, limit=limit)

    def _search_semantic(self, query: str, limit: int = 20) -> list[dict]:
        """Raw semantic search. Used by BuiltinBackend."""
        return self.search_semantic(query, limit=limit)

    def _search_hybrid(self, keyword: str, limit: int = 20) -> list[dict]:
        """Raw hybrid search. Used by BuiltinBackend."""
        return self.search_hybrid(keyword, limit=limit)

    def _add_entry_internal(self, **kwargs) -> dict:
        """Add entry and return dict. Used by BuiltinBackend."""
        return self.add_entry(**kwargs)

    def _list_entries_internal(
        self, domain=None, category=None, status="active",
        limit=50, offset=0,
    ) -> list[dict]:
        """List entries. Used by BuiltinBackend."""
        return self.list_entries(
            domain=domain, category=category, status=status,
            limit=limit, offset=offset,
        )

    def _get_entry_internal(self, entry_id: str) -> dict | None:
        """Get single entry. Used by BuiltinBackend."""
        try:
            return self.get_entry(entry_id)
        except Exception:
            return None

    # ── Intent-based search (kanban middleware layer) ────────────────────

    def search_by_intent(
        self, intent: str, query: str, limit: int = 20, **context
    ) -> list[dict]:
        """Route a search to the right strategy based on retrieval intent.

        This is the kanban value layer — agent says *why* it's searching,
        and the middleware picks the best retrieval strategy.

        Intents:
        - pitfall_check: prioritize high-severity pitfall entries by keyword
        - constraint_lookup: exact match on tags + source.file context
        - experience_reuse: semantic similarity + domain boost + recency
        - general (default): standard hybrid search
        """
        if intent == "pitfall_check":
            results = self._backend.search(query, limit=limit * 2)
            domain = context.get("domain")
            scored = []
            for r in results:
                score = float(r.get("score", 0))
                if r.get("severity") == "high":
                    score *= 1.5
                if r.get("category") == "踩坑":
                    score *= 1.3
                # Domain match boost to reduce cross-domain noise (#228)
                if domain and r.get("domain") == domain:
                    score *= 1.2
                scored.append((score, r))
            scored.sort(key=lambda x: x[0], reverse=True)
            return [e for _, e in scored[:limit]]

        elif intent == "constraint_lookup":
            # Exact match on tags, optionally filtered by source file
            keyword_results = self._backend.search(query, limit=limit)
            source_file = context.get("source_file")
            domain = context.get("domain")
            if source_file:
                keyword_results = [
                    r for r in keyword_results
                    if source_file in str(r.get("source", ""))
                ]
            # Domain filter for better cross-domain precision (#228)
            if domain:
                domain_filtered = [r for r in keyword_results if r.get("domain") == domain]
                if domain_filtered:
                    keyword_results = domain_filtered
            # Prioritize must_not constraints
            keyword_results.sort(
                key=lambda r: 1 if "must_not" in str(r.get("tags", "")) else 0,
                reverse=True,
            )
            return keyword_results[:limit]

        elif intent == "experience_reuse":
            # Semantic search with domain-based boosting
            results = self._backend.search_hybrid(query, limit=limit * 2)
            domain = context.get("domain")
            scored = []
            for r in results:
                score = float(r.get("score", 0))
                if domain and r.get("domain") == domain:
                    score *= 1.2
                # Boost procedure entries for plan/reuse (#239)
                if r.get("type") == "procedure":
                    score *= 1.3
                rc = r.get("referenced_count", 0)
                if rc > 0:
                    score *= min(1.0 + rc * 0.05, 1.5)
                scored.append((score, r))
            scored.sort(key=lambda x: x[0], reverse=True)
            return [e for _, e in scored[:limit]]

        else:
            # general (default) — standard hybrid
            return self._backend.search_hybrid(query, limit=limit)

    # ── Management methods (CLI/management, not part of backend protocol) ─

    def record_usage(self, entry_id, task_id):
        now = datetime.now(timezone.utc).isoformat()
        self._conn.execute(
            "UPDATE entries SET referenced_count=referenced_count+1,"
            " last_referenced_at=?, last_referenced_by=?, stale_at=NULL,"
            " status='active' WHERE id=?",
            (now, task_id, entry_id),
        )
        self._conn.execute(
            "INSERT INTO usage_log(entry_id, task_id, timestamp) VALUES(?,?,?)",
            (entry_id, task_id, now),
        )
        self._conn.commit()

    def mark_stale_entries(self):
        threshold = (datetime.now(timezone.utc) - timedelta(days=STALE_DAYS)).isoformat()
        rows = self._conn.execute(
            """SELECT id FROM entries WHERE status='active'
               AND COALESCE(last_referenced_at, created_at) < ?""",
            (threshold,),
        ).fetchall()
        stale_ids = [r[0] for r in rows]
        if stale_ids:
            now = datetime.now(timezone.utc).isoformat()
            placeholders = ",".join("?" * len(stale_ids))
            self._conn.execute(
                f"UPDATE entries SET status='stale', stale_at=? WHERE id IN ({placeholders})",
                [now] + stale_ids,
            )
            self._conn.commit()
        return stale_ids

    def get_domains(self):
        rows = self._conn.execute("SELECT name, label, keywords FROM domains").fetchall()
        domains = {}
        for r in rows:
            domains[r[0]] = {"label": r[1], "keywords": json.loads(r[2])}
        return {"domains": domains or DEFAULT_DOMAINS}

    def match_domain(self, text):
        domains = self.get_domains()
        text_lower = text.lower()
        scores = {}
        for name, info in domains.get("domains", DEFAULT_DOMAINS).items():
            for kw in info.get("keywords", []):
                if kw.lower() in text_lower:
                    scores[name] = scores.get(name, 0) + 1
        return sorted(scores, key=scores.get, reverse=True)

    def find_similar_pitfalls(self, tags, min_tag_overlap=2):
        rows = self._conn.execute(
            "SELECT * FROM entries WHERE category='踩坑' AND status='active'"
        ).fetchall()
        tags_set = set(tags)
        results = []
        for r in rows:
            entry = self._row_to_dict(r)
            overlap = len(tags_set & set(entry.get("tags", [])))
            if overlap >= min_tag_overlap:
                results.append({**entry, "tag_overlap": overlap})
        results.sort(key=lambda x: x["tag_overlap"], reverse=True)
        return results

    def find_conflicting_solutions(self, task_id=""):
        rows = self._conn.execute(
            "SELECT * FROM entries WHERE category!='踩坑' AND status='active'"
        ).fetchall()
        entries = [self._row_to_dict(r) for r in rows]
        by_domain = {}
        for e in entries:
            by_domain.setdefault(e["domain"], []).append(e)
        conflicts = []
        for domain, ents in by_domain.items():
            n = len(ents)
            for i in range(n):
                for j in range(i + 1, n):
                    a, b = ents[i], ents[j]
                    tags_a = set(a.get("tags", []))
                    tags_b = set(b.get("tags", []))
                    overlap = len(tags_a & tags_b)
                    if overlap < 2:
                        continue
                    if a.get("category") != "架构" and b.get("category") != "架构":
                        continue
                    conflicts.append({
                        "entry_a": a["id"], "entry_b": b["id"],
                        "title_a": a["title"], "title_b": b["title"],
                        "domain": domain,
                        "shared_tags": sorted(tags_a & tags_b),
                        "tag_overlap": overlap,
                        "content_a": a["content"][:200],
                        "content_b": b["content"][:200],
                    })
        return conflicts

    def get_knowledge_gap_report(self):
        rows = self._conn.execute("SELECT domain, category FROM entries WHERE status='active'").fetchall()
        domain_counts = {}
        domain_pitfalls = {}
        for r in rows:
            d, c = r[0], r[1]
            domain_counts[d] = domain_counts.get(d, 0) + 1
            if c == "踩坑":
                domain_pitfalls[d] = domain_pitfalls.get(d, 0) + 1
        gaps = {}
        for d, pitfall_count in domain_pitfalls.items():
            if domain_counts.get(d, 1) < pitfall_count * 2:
                gaps[d] = {"total_entries": domain_counts.get(d, 0), "pitfalls": pitfall_count}
        return gaps

    def migrate_legacy_log(self):
        """Migrate old knowledge-log.md files to SQLite entries.
        Scans both project root and task directories. Returns total count."""
        import re
        log_files = []
        # Project root
        root_log = self._fs.kanban_dir / "knowledge-log.md"
        if self._fs.file_exists(root_log):
            log_files.append((root_log, None))
        # Task directories
        for task_dir in sorted(self._fs.kanban_dir.glob("tasks/TASK-*")):
            if task_dir.is_dir():
                task_log = task_dir / "knowledge-log.md"
                if self._fs.file_exists(task_log):
                    log_files.append((task_log, task_dir.name))

        pattern = re.compile(r'###\s+(\S+):\s*(.+?)\n\s*\n(.*?)(?=\n###|\Z)', re.DOTALL)
        count = 0
        for log_path, task_id in log_files:
            text = log_path.read_text(encoding="utf-8")
            for m in pattern.finditer(text):
                category = m.group(1)
                title = m.group(2).strip()
                content = m.group(3).strip()
                source = {"migrated_from": str(log_path.relative_to(self._fs.kanban_dir))}
                if task_id:
                    source["task_id"] = task_id
                self.add_entry(
                    domain=self.match_domain(f"{title} {content}")[0] if self.match_domain(title) else "infra",
                    category=category, title=title, content=content,
                    tags=[category], source=source,
                )
                count += 1
            log_path.rename(log_path.with_suffix(".md.bak"))
        return count

    # -- helpers --

    def _next_id(self):
        row = self._conn.execute(
            "SELECT id FROM entries ORDER BY CAST(SUBSTR(id, 2) AS INTEGER) DESC LIMIT 1"
        ).fetchone()
        if not row:
            return "K001"
        try:
            return f"K{int(row[0][1:]) + 1:03d}"
        except ValueError:
            return "K001"

    def _row_to_dict(self, row):
        d = dict(row)
        # Defensive: ensure all text values are str, not bytes.
        # On some Windows Python builds sqlite3 may return bytes for TEXT columns
        # despite text_factory=str. (#window-encoding)
        for key, val in list(d.items()):
            if isinstance(val, bytes):
                d[key] = val.decode("utf-8", errors="replace")
        for field in ("tags", "source", "steps"):
            if field in d and isinstance(d[field], str):
                try:
                    d[field] = json.loads(d[field])
                except (json.JSONDecodeError, TypeError):
                    d[field] = [] if field in ("tags", "steps") else {}
        d.pop("embedding", None)
        return d

    def _all_entry_ids(self):
        return [r[0] for r in self._conn.execute("SELECT id FROM entries ORDER BY id")]

    def close(self):
        try:
            self._conn.close()
        except Exception:
            pass
        try:
            if self._chroma_client:
                self._chroma_client = None
                self._chroma_collection = None
        except Exception:
            pass

    def __del__(self):
        try:
            self.close()
        except Exception:
            pass
