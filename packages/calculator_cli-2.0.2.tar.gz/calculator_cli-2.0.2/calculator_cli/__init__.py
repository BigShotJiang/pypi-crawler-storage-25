"""calculator-cli package."""
