import os

from je_auto_control.utils.exception.exceptions import AutoControlException
from je_auto_control.utils.logging.logging_instance import autocontrol_logger
from je_auto_control.windows.core.utils import win32_keypress_check
from je_auto_control.windows.core.utils.win32_vk import (
    WIN32_ABSOLUTE, WIN32_EventF_EXTENDEDKEY, WIN32_EventF_KEYUP,
    WIN32_EventF_SCANCODE, WIN32_EventF_UNICODE, WIN32_HWHEEL,
    WIN32_LEFTDOWN, WIN32_LEFTUP, WIN32_MIDDLEDOWN, WIN32_MIDDLEUP,
    WIN32_MOVE, WIN32_RIGHTDOWN, WIN32_RIGHTUP,
    WIN32_VK_ACCEPT, WIN32_VK_ADD, WIN32_VK_APPS, WIN32_VK_BACK,
    WIN32_VK_BROWSER_BACK, WIN32_VK_BROWSER_FAVORITES,
    WIN32_VK_BROWSER_FORWARD, WIN32_VK_BROWSER_REFRESH,
    WIN32_VK_BROWSER_SEARCH, WIN32_VK_BROWSER_STOP, WIN32_VK_CANCEL,
    WIN32_VK_CAPITAL, WIN32_VK_CLEAR, WIN32_VK_CONTROL, WIN32_VK_CONVERT,
    WIN32_VK_DECIMAL, WIN32_VK_DELETE, WIN32_VK_DIVIDE, WIN32_VK_DOWN,
    WIN32_VK_END, WIN32_VK_ESCAPE, WIN32_VK_EXECUTE,
    WIN32_VK_F1, WIN32_VK_F2, WIN32_VK_F3, WIN32_VK_F4, WIN32_VK_F5,
    WIN32_VK_F6, WIN32_VK_F7, WIN32_VK_F8, WIN32_VK_F9, WIN32_VK_F10,
    WIN32_VK_F11, WIN32_VK_F12, WIN32_VK_F13, WIN32_VK_F14, WIN32_VK_F15,
    WIN32_VK_F16, WIN32_VK_F17, WIN32_VK_F18, WIN32_VK_F19, WIN32_VK_F20,
    WIN32_VK_F21, WIN32_VK_F22, WIN32_VK_F23, WIN32_VK_F24,
    WIN32_VK_FINAL, WIN32_VK_HANJA, WIN32_VK_HELP, WIN32_VK_HOME,
    WIN32_VK_IME_OFF, WIN32_VK_IME_ON, WIN32_VK_INSERT, WIN32_VK_JUNJA,
    WIN32_VK_KANA, WIN32_VK_LAUNCH_APP1, WIN32_VK_LAUNCH_APP2,
    WIN32_VK_LAUNCH_MAIL, WIN32_VK_LAUNCH_MEDIA_SELECT,
    WIN32_VK_LBUTTON, WIN32_VK_LCONTROL, WIN32_VK_LEFT, WIN32_VK_LMENU,
    WIN32_VK_LSHIFT, WIN32_VK_LWIN, WIN32_VK_MBUTTON,
    WIN32_VK_MEDIA_NEXT_TRACK, WIN32_VK_MEDIA_PLAY_PAUSE,
    WIN32_VK_MEDIA_PREV_TRACK, WIN32_VK_MEDIA_STOP,
    WIN32_VK_MODECHANGE, WIN32_VK_MULTIPLY, WIN32_VK_Menu,
    WIN32_VK_NEXT, WIN32_VK_NONCONVERT, WIN32_VK_NUMLOCK,
    WIN32_VK_NUMPAD0, WIN32_VK_NUMPAD1, WIN32_VK_NUMPAD2,
    WIN32_VK_NUMPAD3, WIN32_VK_NUMPAD4, WIN32_VK_NUMPAD5,
    WIN32_VK_NUMPAD6, WIN32_VK_NUMPAD7, WIN32_VK_NUMPAD8, WIN32_VK_NUMPAD9,
    WIN32_VK_PAUSE, WIN32_VK_PRINT, WIN32_VK_PRIOR, WIN32_VK_RBUTTON,
    WIN32_VK_RCONTROL, WIN32_VK_RETURN, WIN32_VK_RIGHT, WIN32_VK_RMENU,
    WIN32_VK_RSHIFT, WIN32_VK_RWIN, WIN32_VK_SCROLL, WIN32_VK_SELECT,
    WIN32_VK_SEPARATOR, WIN32_VK_SHIFT, WIN32_VK_SLEEP, WIN32_VK_SNAPSHOT,
    WIN32_VK_SPACE, WIN32_VK_SUBTRACT, WIN32_VK_TAB, WIN32_VK_UP,
    WIN32_VK_VOLUME_DOWN, WIN32_VK_VOLUME_MUTE, WIN32_VK_VOLUME_UP,
    WIN32_VK_XBUTTON1, WIN32_VK_XBUTTON2, WIN32_VkToVSC,
    WIN32_WHEEL, WIN32_XBUTTON1, WIN32_XBUTTON2, WIN32_DOWN, WIN32_XUP,
    WIN32_key0, WIN32_key1, WIN32_key2, WIN32_key3, WIN32_key4,
    WIN32_key5, WIN32_key6, WIN32_key7, WIN32_key8, WIN32_key9,
    WIN32_keyA, WIN32_keyB, WIN32_keyC, WIN32_keyD, WIN32_keyE,
    WIN32_keyF, WIN32_keyG, WIN32_keyH, WIN32_keyI, WIN32_keyJ,
    WIN32_keyK, WIN32_keyL, WIN32_keyM, WIN32_keyN, WIN32_keyO,
    WIN32_keyP, WIN32_keyQ, WIN32_keyR, WIN32_keyS, WIN32_keyT,
    WIN32_keyU, WIN32_keyV, WIN32_keyW, WIN32_keyX, WIN32_keyY, WIN32_keyZ,
)
from je_auto_control.windows.keyboard import win32_ctype_keyboard_control
from je_auto_control.windows.mouse import win32_ctype_mouse_control
from je_auto_control.windows.mouse.win32_ctype_mouse_control import (
    win32_mouse_left, win32_mouse_middle, win32_mouse_right,
    win32_mouse_x1, win32_mouse_x2,
)
from je_auto_control.windows.record.win32_record import win32_recorder
from je_auto_control.windows.screen import win32_screen


def _select_input_backend():
    """Pick keyboard/mouse modules based on JE_AUTOCONTROL_WIN32_BACKEND.

    Default is ``sendinput`` (the existing ctypes / SendInput backend).
    Set the env var to ``interception`` to route synthetic input
    through the Interception driver instead — required for games that
    read input via ``GetRawInputData`` and ignore SendInput. Falls back
    to SendInput with a warning when the driver isn't installed, so
    deployments can roll the driver out lazily.
    """
    backend = os.environ.get(
        "JE_AUTOCONTROL_WIN32_BACKEND", "sendinput",
    ).strip().lower()
    if backend != "interception":
        return win32_ctype_keyboard_control, win32_ctype_mouse_control
    try:
        from je_auto_control.windows.interception import (
            keyboard as interception_keyboard,
            mouse as interception_mouse,
            is_available,
        )
    except ImportError as error:  # defensive: optional sub-package
        autocontrol_logger.warning(
            "Interception backend requested but module import failed: "
            "%r — falling back to SendInput.", error,
        )
        return win32_ctype_keyboard_control, win32_ctype_mouse_control
    if not is_available():
        autocontrol_logger.warning(
            "Interception backend requested but the driver is not "
            "available — falling back to SendInput. Install the "
            "driver from https://github.com/oblitum/Interception",
        )
        return win32_ctype_keyboard_control, win32_ctype_mouse_control
    autocontrol_logger.info("Win32 input backend: Interception driver")
    # Refresh the mouse-button tuples to use Interception flag bits
    # so the wrapper's mouse_keys_table dispatches correctly.
    global win32_mouse_left, win32_mouse_middle, win32_mouse_right
    global win32_mouse_x1, win32_mouse_x2
    win32_mouse_left = interception_mouse.win32_mouse_left
    win32_mouse_middle = interception_mouse.win32_mouse_middle
    win32_mouse_right = interception_mouse.win32_mouse_right
    win32_mouse_x1 = interception_mouse.win32_mouse_x1
    win32_mouse_x2 = interception_mouse.win32_mouse_x2
    return interception_keyboard, interception_mouse


autocontrol_logger.info("Load Windows Setting")

keyboard_keys_table = {
    "absolute": WIN32_ABSOLUTE,
    "eventf_extendedkey": WIN32_EventF_EXTENDEDKEY,
    "eventf_keyup": WIN32_EventF_KEYUP,
    "eventf_scancode": WIN32_EventF_SCANCODE,
    "eventf_unicode": WIN32_EventF_UNICODE,
    "hwheel": WIN32_HWHEEL,
    "leftdown": WIN32_LEFTDOWN,
    "leftup": WIN32_LEFTUP,
    "middledown": WIN32_MIDDLEDOWN,
    "middleup": WIN32_MIDDLEUP,
    "move": WIN32_MOVE,
    "rightdown": WIN32_RIGHTDOWN,
    "rightup": WIN32_RIGHTUP,
    "accept": WIN32_VK_ACCEPT,
    "add": WIN32_VK_ADD,
    "apps": WIN32_VK_APPS,
    "back": WIN32_VK_BACK,
    "browser_back": WIN32_VK_BROWSER_BACK,
    "browser_favorites": WIN32_VK_BROWSER_FAVORITES,
    "browser_forward": WIN32_VK_BROWSER_FORWARD,
    "browser_refresh": WIN32_VK_BROWSER_REFRESH,
    "browser_search": WIN32_VK_BROWSER_SEARCH,
    "browser_stop": WIN32_VK_BROWSER_STOP,
    "cancel": WIN32_VK_CANCEL,
    "capital": WIN32_VK_CAPITAL,
    "clear": WIN32_VK_CLEAR,
    "control": WIN32_VK_CONTROL,
    "convert": WIN32_VK_CONVERT,
    "decimal": WIN32_VK_DECIMAL,
    "delete": WIN32_VK_DELETE,
    "divide": WIN32_VK_DIVIDE,
    "vk_down": WIN32_VK_DOWN,
    "end": WIN32_VK_END,
    "escape": WIN32_VK_ESCAPE,
    "execute": WIN32_VK_EXECUTE,
    "f1": WIN32_VK_F1,
    "f2": WIN32_VK_F2,
    "f3": WIN32_VK_F3,
    "f4": WIN32_VK_F4,
    "f5": WIN32_VK_F5,
    "f6": WIN32_VK_F6,
    "f7": WIN32_VK_F7,
    "f8": WIN32_VK_F8,
    "f9": WIN32_VK_F9,
    "f10": WIN32_VK_F10,
    "f11": WIN32_VK_F11,
    "f12": WIN32_VK_F12,
    "f13": WIN32_VK_F13,
    "f14": WIN32_VK_F14,
    "f15": WIN32_VK_F15,
    "f16": WIN32_VK_F16,
    "f17": WIN32_VK_F17,
    "f18": WIN32_VK_F18,
    "f19": WIN32_VK_F19,
    "f20": WIN32_VK_F20,
    "f21": WIN32_VK_F21,
    "f22": WIN32_VK_F22,
    "f23": WIN32_VK_F23,
    "f24": WIN32_VK_F24,
    "final": WIN32_VK_FINAL,
    "hanja": WIN32_VK_HANJA,
    "help": WIN32_VK_HELP,
    "home": WIN32_VK_HOME,
    "ime_off": WIN32_VK_IME_OFF,
    "ime_on": WIN32_VK_IME_ON,
    "insert": WIN32_VK_INSERT,
    "junja": WIN32_VK_JUNJA,
    "kana": WIN32_VK_KANA,
    "launch_app1": WIN32_VK_LAUNCH_APP1,
    "LAUNCH_APP2": WIN32_VK_LAUNCH_APP2,
    "launch_mail": WIN32_VK_LAUNCH_MAIL,
    "launch_media_select": WIN32_VK_LAUNCH_MEDIA_SELECT,
    "lbutton": WIN32_VK_LBUTTON,
    "lcontrol": WIN32_VK_LCONTROL,
    "left": WIN32_VK_LEFT,
    "lmenu": WIN32_VK_LMENU,
    "lshift": WIN32_VK_LSHIFT,
    "lwin": WIN32_VK_LWIN,
    "mbutton": WIN32_VK_MBUTTON,
    "media_next_track": WIN32_VK_MEDIA_NEXT_TRACK,
    "media_play_pause": WIN32_VK_MEDIA_PLAY_PAUSE,
    "media_prev_track": WIN32_VK_MEDIA_PREV_TRACK,
    "media_stop": WIN32_VK_MEDIA_STOP,
    "modechange": WIN32_VK_MODECHANGE,
    "multiply": WIN32_VK_MULTIPLY,
    "menu": WIN32_VK_Menu,
    "next": WIN32_VK_NEXT,
    "nonconvert": WIN32_VK_NONCONVERT,
    "numlock": WIN32_VK_NUMLOCK,
    "num0": WIN32_VK_NUMPAD0,
    "num1": WIN32_VK_NUMPAD1,
    "num2": WIN32_VK_NUMPAD2,
    "num3": WIN32_VK_NUMPAD3,
    "num4": WIN32_VK_NUMPAD4,
    "num5": WIN32_VK_NUMPAD5,
    "num6": WIN32_VK_NUMPAD6,
    "num7": WIN32_VK_NUMPAD7,
    "num8": WIN32_VK_NUMPAD8,
    "num9": WIN32_VK_NUMPAD9,
    "pause": WIN32_VK_PAUSE,
    "print": WIN32_VK_PRINT,
    "prior": WIN32_VK_PRIOR,
    "rbutton": WIN32_VK_RBUTTON,
    "rcontrol": WIN32_VK_RCONTROL,
    "return": WIN32_VK_RETURN,
    "right": WIN32_VK_RIGHT,
    "rmenu": WIN32_VK_RMENU,
    "rshift": WIN32_VK_RSHIFT,
    "rwin": WIN32_VK_RWIN,
    "scroll": WIN32_VK_SCROLL,
    "select": WIN32_VK_SELECT,
    "separator": WIN32_VK_SEPARATOR,
    "shift": WIN32_VK_SHIFT,
    "sleep": WIN32_VK_SLEEP,
    "snapshot": WIN32_VK_SNAPSHOT,
    "space": WIN32_VK_SPACE,
    "subtract": WIN32_VK_SUBTRACT,
    "tab": WIN32_VK_TAB,
    "up": WIN32_VK_UP,
    "volume_down": WIN32_VK_VOLUME_DOWN,
    "volume_mute": WIN32_VK_VOLUME_MUTE,
    "volume_up": WIN32_VK_VOLUME_UP,
    "vk_xbutton1": WIN32_VK_XBUTTON1,
    "vk_xbutton2": WIN32_VK_XBUTTON2,
    "xbutton1": WIN32_XBUTTON1,
    "xbutton2": WIN32_XBUTTON2,
    "vktovsc": WIN32_VkToVSC,
    "wheel": WIN32_WHEEL,
    "down": WIN32_DOWN,
    "xup": WIN32_XUP,
    "0": WIN32_key0,
    "1": WIN32_key1,
    "2": WIN32_key2,
    "3": WIN32_key3,
    "4": WIN32_key4,
    "5": WIN32_key5,
    "6": WIN32_key6,
    "7": WIN32_key7,
    "8": WIN32_key8,
    "9": WIN32_key9,
    "A": WIN32_keyA,
    "a": WIN32_keyA,
    "B": WIN32_keyB,
    "b": WIN32_keyB,
    "C": WIN32_keyC,
    "c": WIN32_keyC,
    "D": WIN32_keyD,
    "d": WIN32_keyD,
    "E": WIN32_keyE,
    "e": WIN32_keyE,
    "F": WIN32_keyF,
    "f": WIN32_keyF,
    "G": WIN32_keyG,
    "g": WIN32_keyG,
    "H": WIN32_keyH,
    "h": WIN32_keyH,
    "I": WIN32_keyI,
    "i": WIN32_keyI,
    "J": WIN32_keyJ,
    "j": WIN32_keyJ,
    "K": WIN32_keyK,
    "k": WIN32_keyK,
    "L": WIN32_keyL,
    "l": WIN32_keyL,
    "M": WIN32_keyM,
    "m": WIN32_keyM,
    "N": WIN32_keyN,
    "n": WIN32_keyN,
    "O": WIN32_keyO,
    "o": WIN32_keyO,
    "P": WIN32_keyP,
    "p": WIN32_keyP,
    "Q": WIN32_keyQ,
    "q": WIN32_keyQ,
    "R": WIN32_keyR,
    "r": WIN32_keyR,
    "S": WIN32_keyS,
    "s": WIN32_keyS,
    "T": WIN32_keyT,
    "t": WIN32_keyT,
    "U": WIN32_keyU,
    "u": WIN32_keyU,
    "V": WIN32_keyV,
    "v": WIN32_keyV,
    "W": WIN32_keyW,
    "w": WIN32_keyW,
    "X": WIN32_keyX,
    "x": WIN32_keyX,
    "Y": WIN32_keyY,
    "y": WIN32_keyY,
    "Z": WIN32_keyZ,
    "z": WIN32_keyZ,
}

mouse_keys_table = {
    "mouse_left": win32_mouse_left,
    "mouse_middle": win32_mouse_middle,
    "mouse_right": win32_mouse_right,
    "mouse_x1": win32_mouse_x1,
    "mouse_x2": win32_mouse_x2,
}

special_mouse_keys_table = None
keyboard, mouse = _select_input_backend()
keyboard_check = win32_keypress_check
screen = win32_screen
recorder = win32_recorder

if None in [keyboard_keys_table, mouse_keys_table, keyboard_check, keyboard, mouse, screen, recorder]:
    raise AutoControlException("Can't init auto control")
