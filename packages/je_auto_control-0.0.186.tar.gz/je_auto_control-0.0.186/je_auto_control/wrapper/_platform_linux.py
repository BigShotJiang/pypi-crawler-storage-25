from je_auto_control.linux_with_x11.core.utils.x11_linux_vk import (
    x11_linux_key_backspace, x11_linux_key_slash_b, x11_linux_key_tab,
    x11_linux_key_enter, x11_linux_key_return, x11_linux_key_shift,
    x11_linux_key_ctrl, x11_linux_key_alt, x11_linux_key_pause,
    x11_linux_key_capslock, x11_linux_key_esc, x11_linux_key_pgup,
    x11_linux_key_pgdn, x11_linux_key_pageup, x11_linux_key_pagedown,
    x11_linux_key_end, x11_linux_key_home, x11_linux_key_left,
    x11_linux_key_up, x11_linux_key_right, x11_linux_key_down,
    x11_linux_key_select, x11_linux_key_print, x11_linux_key_execute,
    x11_linux_key_prtsc, x11_linux_key_prtscr, x11_linux_key_prntscrn,
    x11_linux_key_insert, x11_linux_key_del, x11_linux_key_delete,
    x11_linux_key_help, x11_linux_key_win, x11_linux_key_winleft,
    x11_linux_key_winright, x11_linux_key_apps,
    x11_linux_key_num0, x11_linux_key_num1, x11_linux_key_num2,
    x11_linux_key_num3, x11_linux_key_num4, x11_linux_key_num5,
    x11_linux_key_num6, x11_linux_key_num7, x11_linux_key_num8,
    x11_linux_key_num9, x11_linux_key_multiply, x11_linux_key_add,
    x11_linux_key_separator, x11_linux_key_subtract,
    x11_linux_key_decimal, x11_linux_key_divide,
    x11_linux_key_f1, x11_linux_key_f2, x11_linux_key_f3, x11_linux_key_f4,
    x11_linux_key_f5, x11_linux_key_f6, x11_linux_key_f7, x11_linux_key_f8,
    x11_linux_key_f9, x11_linux_key_f10, x11_linux_key_f11, x11_linux_key_f12,
    x11_linux_key_f13, x11_linux_key_f14, x11_linux_key_f15, x11_linux_key_f16,
    x11_linux_key_f17, x11_linux_key_f18, x11_linux_key_f19, x11_linux_key_f20,
    x11_linux_key_f21, x11_linux_key_f22, x11_linux_key_f23, x11_linux_key_f24,
    x11_linux_key_numlock, x11_linux_key_scrolllock,
    x11_linux_key_shiftleft, x11_linux_key_shiftright,
    x11_linux_key_ctrlleft, x11_linux_key_ctrlright,
    x11_linux_key_altleft, x11_linux_key_altright,
    x11_linux_key_space, x11_linux_key_newline_n, x11_linux_key_newline_r,
    x11_linux_key_newline_t, x11_linux_key_exclam, x11_linux_key_numbersign,
    x11_linux_key_percent, x11_linux_key_dollar, x11_linux_key_ampersand,
    x11_linux_key_quotedbl, x11_linux_key_apostrophe,
    x11_linux_key_parenleft, x11_linux_key_parenright,
    x11_linux_key_asterisk, x11_linux_key_equal, x11_linux_key_plus,
    x11_linux_key_comma, x11_linux_key_minus, x11_linux_key_period,
    x11_linux_key_slash, x11_linux_key_colon, x11_linux_key_semicolon,
    x11_linux_key_less, x11_linux_key_greater, x11_linux_key_question,
    x11_linux_key_at, x11_linux_key_bracketleft, x11_linux_key_bracketright,
    x11_linux_key_backslash, x11_linux_key_asciicircum,
    x11_linux_key_underscore, x11_linux_key_grave,
    x11_linux_key_braceleft, x11_linux_key_bar, x11_linux_key_braceright,
    x11_linux_key_asciitilde,
    x11_linux_key_a, x11_linux_key_b, x11_linux_key_c, x11_linux_key_d,
    x11_linux_key_e, x11_linux_key_f, x11_linux_key_g, x11_linux_key_h,
    x11_linux_key_i, x11_linux_key_j, x11_linux_key_k, x11_linux_key_l,
    x11_linux_key_m, x11_linux_key_n, x11_linux_key_o, x11_linux_key_p,
    x11_linux_key_q, x11_linux_key_r, x11_linux_key_s, x11_linux_key_t,
    x11_linux_key_u, x11_linux_key_v, x11_linux_key_w, x11_linux_key_x,
    x11_linux_key_y, x11_linux_key_z,
    x11_linux_key_A, x11_linux_key_B, x11_linux_key_C, x11_linux_key_D,
    x11_linux_key_E, x11_linux_key_F, x11_linux_key_G, x11_linux_key_H,
    x11_linux_key_I, x11_linux_key_J, x11_linux_key_K, x11_linux_key_L,
    x11_linux_key_M, x11_linux_key_N, x11_linux_key_O, x11_linux_key_P,
    x11_linux_key_Q, x11_linux_key_R, x11_linux_key_S, x11_linux_key_T,
    x11_linux_key_U, x11_linux_key_V, x11_linux_key_W, x11_linux_key_X,
    x11_linux_key_Y, x11_linux_key_Z,
    x11_linux_key_1, x11_linux_key_2, x11_linux_key_3, x11_linux_key_4,
    x11_linux_key_5, x11_linux_key_6, x11_linux_key_7, x11_linux_key_8,
    x11_linux_key_9, x11_linux_key_0,
)
from je_auto_control.linux_with_x11.keyboard import x11_linux_keyboard_control
from je_auto_control.linux_with_x11.listener import x11_linux_listener
from je_auto_control.linux_with_x11.mouse import x11_linux_mouse_control
from je_auto_control.linux_with_x11.mouse.x11_linux_mouse_control import (
    x11_linux_mouse_left, x11_linux_mouse_middle, x11_linux_mouse_right,
    x11_linux_scroll_direction_up, x11_linux_scroll_direction_down,
    x11_linux_scroll_direction_left, x11_linux_scroll_direction_right,
)
from je_auto_control.linux_with_x11.record.x11_linux_record import x11_linux_recoder
from je_auto_control.linux_with_x11.screen import x11_linux_screen
from je_auto_control.utils.exception.exceptions import AutoControlException
from je_auto_control.utils.logging.logging_instance import autocontrol_logger

autocontrol_logger.info("Load Linux x11 Setting")

keyboard_keys_table = {
    "backspace": x11_linux_key_backspace,
    "\b": x11_linux_key_slash_b,
    "tab": x11_linux_key_tab,
    "enter": x11_linux_key_enter,
    "return": x11_linux_key_return,
    "shift": x11_linux_key_shift,
    "ctrl": x11_linux_key_ctrl,
    "alt": x11_linux_key_alt,
    "pause": x11_linux_key_pause,
    "capslock": x11_linux_key_capslock,
    "esc": x11_linux_key_esc,
    "pgup": x11_linux_key_pgup,
    "pgdn": x11_linux_key_pgdn,
    "pageup": x11_linux_key_pageup,
    "pagedown": x11_linux_key_pagedown,
    "end": x11_linux_key_end,
    "home": x11_linux_key_home,
    "left": x11_linux_key_left,
    "up": x11_linux_key_up,
    "right": x11_linux_key_right,
    "down": x11_linux_key_down,
    "select": x11_linux_key_select,
    "print": x11_linux_key_print,
    "execute": x11_linux_key_execute,
    "prtsc": x11_linux_key_prtsc,
    "prtscr": x11_linux_key_prtscr,
    "prntscrn": x11_linux_key_prntscrn,
    "insert": x11_linux_key_insert,
    "del": x11_linux_key_del,
    "delete": x11_linux_key_delete,
    "help": x11_linux_key_help,
    "win": x11_linux_key_win,
    "winleft": x11_linux_key_winleft,
    "winright": x11_linux_key_winright,
    "apps": x11_linux_key_apps,
    "num0": x11_linux_key_num0,
    "num1": x11_linux_key_num1,
    "num2": x11_linux_key_num2,
    "num3": x11_linux_key_num3,
    "num4": x11_linux_key_num4,
    "num5": x11_linux_key_num5,
    "num6": x11_linux_key_num6,
    "num7": x11_linux_key_num7,
    "num8": x11_linux_key_num8,
    "num9": x11_linux_key_num9,
    "multiply": x11_linux_key_multiply,
    "add": x11_linux_key_add,
    "separator": x11_linux_key_separator,
    "subtract": x11_linux_key_subtract,
    "decimal": x11_linux_key_decimal,
    "divide": x11_linux_key_divide,
    "f1": x11_linux_key_f1, "f2": x11_linux_key_f2, "f3": x11_linux_key_f3,
    "f4": x11_linux_key_f4, "f5": x11_linux_key_f5, "f6": x11_linux_key_f6,
    "f7": x11_linux_key_f7, "f8": x11_linux_key_f8, "f9": x11_linux_key_f9,
    "f10": x11_linux_key_f10, "f11": x11_linux_key_f11, "f12": x11_linux_key_f12,
    "f13": x11_linux_key_f13, "f14": x11_linux_key_f14, "f15": x11_linux_key_f15,
    "f16": x11_linux_key_f16, "f17": x11_linux_key_f17, "f18": x11_linux_key_f18,
    "f19": x11_linux_key_f19, "f20": x11_linux_key_f20, "f21": x11_linux_key_f21,
    "f22": x11_linux_key_f22, "f23": x11_linux_key_f23, "f24": x11_linux_key_f24,
    "numlock": x11_linux_key_numlock,
    "scrolllock": x11_linux_key_scrolllock,
    "shiftleft": x11_linux_key_shiftleft,
    "shiftright": x11_linux_key_shiftright,
    "ctrlleft": x11_linux_key_ctrlleft,
    "ctrlright": x11_linux_key_ctrlright,
    "altleft": x11_linux_key_altleft,
    "altright": x11_linux_key_altright,
    "space": x11_linux_key_space,
    "\n": x11_linux_key_newline_n,
    "\r": x11_linux_key_newline_r,
    "\t": x11_linux_key_newline_t,
    "!": x11_linux_key_exclam,
    "#": x11_linux_key_numbersign,
    "%": x11_linux_key_percent,
    "$": x11_linux_key_dollar,
    "&": x11_linux_key_ampersand,
    '"': x11_linux_key_quotedbl,
    "'": x11_linux_key_apostrophe,
    "(": x11_linux_key_parenleft,
    ")": x11_linux_key_parenright,
    "*": x11_linux_key_asterisk,
    "=": x11_linux_key_equal,
    "+": x11_linux_key_plus,
    ",": x11_linux_key_comma,
    "-": x11_linux_key_minus,
    ".": x11_linux_key_period,
    "/": x11_linux_key_slash,
    ":": x11_linux_key_colon,
    ";": x11_linux_key_semicolon,
    "<": x11_linux_key_less,
    ">": x11_linux_key_greater,
    "?": x11_linux_key_question,
    "@": x11_linux_key_at,
    "[": x11_linux_key_bracketleft,
    "]": x11_linux_key_bracketright,
    "\\": x11_linux_key_backslash,
    "^": x11_linux_key_asciicircum,
    "_": x11_linux_key_underscore,
    "`": x11_linux_key_grave,
    "{": x11_linux_key_braceleft,
    "|": x11_linux_key_bar,
    "}": x11_linux_key_braceright,
    "~": x11_linux_key_asciitilde,
    "a": x11_linux_key_a, "b": x11_linux_key_b, "c": x11_linux_key_c,
    "d": x11_linux_key_d, "e": x11_linux_key_e, "f": x11_linux_key_f,
    "g": x11_linux_key_g, "h": x11_linux_key_h, "i": x11_linux_key_i,
    "j": x11_linux_key_j, "k": x11_linux_key_k, "l": x11_linux_key_l,
    "m": x11_linux_key_m, "n": x11_linux_key_n, "o": x11_linux_key_o,
    "p": x11_linux_key_p, "q": x11_linux_key_q, "r": x11_linux_key_r,
    "s": x11_linux_key_s, "t": x11_linux_key_t, "u": x11_linux_key_u,
    "v": x11_linux_key_v, "w": x11_linux_key_w, "x": x11_linux_key_x,
    "y": x11_linux_key_y, "z": x11_linux_key_z,
    "A": x11_linux_key_A, "B": x11_linux_key_B, "C": x11_linux_key_C,
    "D": x11_linux_key_D, "E": x11_linux_key_E, "F": x11_linux_key_F,
    "G": x11_linux_key_G, "H": x11_linux_key_H, "I": x11_linux_key_I,
    "J": x11_linux_key_J, "K": x11_linux_key_K, "L": x11_linux_key_L,
    "M": x11_linux_key_M, "N": x11_linux_key_N, "O": x11_linux_key_O,
    "P": x11_linux_key_P, "Q": x11_linux_key_Q, "R": x11_linux_key_R,
    "S": x11_linux_key_S, "T": x11_linux_key_T, "U": x11_linux_key_U,
    "V": x11_linux_key_V, "W": x11_linux_key_W, "X": x11_linux_key_X,
    "Y": x11_linux_key_Y, "Z": x11_linux_key_Z,
    "1": x11_linux_key_1, "2": x11_linux_key_2, "3": x11_linux_key_3,
    "4": x11_linux_key_4, "5": x11_linux_key_5, "6": x11_linux_key_6,
    "7": x11_linux_key_7, "8": x11_linux_key_8, "9": x11_linux_key_9,
    "0": x11_linux_key_0,
}

mouse_keys_table = {
    "mouse_left": x11_linux_mouse_left,
    "mouse_middle": x11_linux_mouse_middle,
    "mouse_right": x11_linux_mouse_right,
}

special_mouse_keys_table = {
    "scroll_up": x11_linux_scroll_direction_up,
    "scroll_down": x11_linux_scroll_direction_down,
    "scroll_left": x11_linux_scroll_direction_left,
    "scroll_right": x11_linux_scroll_direction_right,
}

def _select_input_backend():
    """Pick keyboard/mouse modules based on JE_AUTOCONTROL_LINUX_BACKEND.

    Default is ``x11`` (the existing XTest backend). Set the env var
    to ``uinput`` to route synthetic input through ``/dev/uinput`` —
    required for games that read evdev and ignore XTest. Falls back
    to XTest with a warning when ``/dev/uinput`` isn't writable, so
    deployments can roll permissions out lazily.
    """
    import os

    from je_auto_control.utils.logging.logging_instance import (
        autocontrol_logger,
    )
    backend = os.environ.get(
        "JE_AUTOCONTROL_LINUX_BACKEND", "x11",
    ).strip().lower()
    if backend != "uinput":
        return x11_linux_keyboard_control, x11_linux_mouse_control
    try:
        from je_auto_control.linux_with_x11.uinput import (
            keyboard as uinput_keyboard,
            mouse as uinput_mouse,
            is_available,
        )
    except ImportError as error:
        autocontrol_logger.warning(
            "uinput backend requested but module import failed: "
            "%r — falling back to XTest.", error,
        )
        return x11_linux_keyboard_control, x11_linux_mouse_control
    if not is_available():
        autocontrol_logger.warning(
            "uinput backend requested but /dev/uinput is not writable "
            "— falling back to XTest. Run "
            "`sudo modprobe uinput && sudo chmod 666 /dev/uinput` "
            "or install the udev rule documented in new_features.",
        )
        return x11_linux_keyboard_control, x11_linux_mouse_control
    autocontrol_logger.info("Linux input backend: uinput (kernel)")
    return uinput_keyboard, uinput_mouse


keyboard, mouse = _select_input_backend()
keyboard_check = x11_linux_listener
screen = x11_linux_screen
recorder = x11_linux_recoder

if None in [keyboard_keys_table, mouse_keys_table, special_mouse_keys_table, keyboard, mouse, screen, recorder]:
    raise AutoControlException("Can't init auto control")
