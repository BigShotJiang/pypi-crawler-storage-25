from enum import Enum

import tenacity
from py_clob_client.client import ClobClient
from py_clob_client.clob_types import MarketOrderArgs, OrderType
from py_clob_client.exceptions import PolyApiException
from pydantic import BaseModel
from web3 import Web3

from prediction_market_agent_tooling.chains import POLYGON_CHAIN_ID
from prediction_market_agent_tooling.config import APIKeys, RPCConfig
from prediction_market_agent_tooling.gtypes import USD, HexBytes, OutcomeToken, Wei
from prediction_market_agent_tooling.loggers import logger
from prediction_market_agent_tooling.markets.polymarket.constants import (
    CTF_EXCHANGE_POLYMARKET,
    NEG_RISK_ADAPTER,
    NEG_RISK_EXCHANGE,
    POLYMARKET_CLOB_API_URL,
    POLYMARKET_TINY_BET_AMOUNT,
)
from prediction_market_agent_tooling.markets.polymarket.data_models import (
    PolymarketSideEnum,
)
from prediction_market_agent_tooling.markets.polymarket.polymarket_contracts import (
    PolymarketConditionalTokenContract,
    USDCeContract,
)
from prediction_market_agent_tooling.tools.cow.cow_order import handle_allowance


class OrderNotFoundError(Exception):
    pass


class OrderStatusEnum(str, Enum):
    MATCHED = "matched"
    LIVE = "live"
    DELAYED = "delayed"
    UNMATCHED = "unmatched"


class CreateOrderResult(BaseModel):
    errorMsg: str
    orderID: str
    transactionsHashes: list[HexBytes]
    status: OrderStatusEnum
    success: bool


class PriceResponse(BaseModel):
    price: float

    @property
    def price_usd(self) -> USD:
        return USD(self.price)


class ClobManager:
    def __init__(self, api_keys: APIKeys | None = None) -> None:
        self.api_keys = api_keys or APIKeys()
        self.clob_client = ClobClient(
            POLYMARKET_CLOB_API_URL,
            key=self.api_keys.bet_from_private_key.get_secret_value(),
            chain_id=POLYGON_CHAIN_ID,
        )
        self.clob_client.set_api_creds(self.clob_client.create_or_derive_api_creds())
        self.polygon_web3 = RPCConfig().get_polygon_web3()

    def get_token_fee_bps(self, token_id: int) -> int:
        try:
            in_bps: int = self.clob_client.get_fee_rate_bps(token_id=token_id)
        except PolyApiException as e:
            if "fee rate not found" in str(e.error_msg):
                return 0
            raise

        return in_bps

    def get_token_fee_rate(self, token_id: int) -> float:
        in_bps: int = self.get_token_fee_bps(token_id=token_id)
        return (
            in_bps / 100 / 100
        )  # convert from bps to percentage and percentage to decimal

    def get_token_price(self, token_id: int, side: PolymarketSideEnum) -> USD:
        price_data = self.clob_client.get_price(token_id=token_id, side=side.value)
        price_item = PriceResponse.model_validate(price_data)
        return price_item.price_usd

    def _place_market_order(
        self,
        token_id: int,
        amount: USD | OutcomeToken,
        side: PolymarketSideEnum,
    ) -> CreateOrderResult:
        amount_float = amount.value
        if side == PolymarketSideEnum.BUY and amount_float < 1.0:
            raise ValueError(
                f"usdc_amounts < 1.0 are not supported by Polymarket, got {amount_float}"
            )

        self.__init_approvals()

        order_args = MarketOrderArgs(
            token_id=str(token_id),
            amount=amount_float,
            side=side.value,
        )

        logger.info(f"Placing market order: {order_args}")
        signed_order = self.clob_client.create_market_order(order_args)
        resp = self.clob_client.post_order(signed_order, orderType=OrderType.FOK)
        result = CreateOrderResult.model_validate(resp)

        if result.success and result.transactionsHashes:
            self._verify_order_on_chain(result)

        return result

    @tenacity.retry(
        wait=tenacity.wait_exponential(max=5),
        stop=tenacity.stop_after_attempt(5),
        retry=tenacity.retry_if_exception_type(OrderNotFoundError),
        reraise=True,
    )
    def _verify_order_on_chain(self, result: CreateOrderResult) -> None:
        """Verify that a FOK order was actually filled by checking the tx on-chain.

        The CLOB returns success=True even for killed FOK orders, so we must
        verify the transaction hash exists on Polygon.
        """
        tx_hash = result.transactionsHashes[0]
        try:
            receipt = self.polygon_web3.eth.get_transaction_receipt(tx_hash)
            if receipt["status"] != 1:
                raise ValueError(
                    f"Order transaction {tx_hash.to_0x_hex()} failed on-chain "
                    f"(status={receipt['status']})"
                )

        except Exception as e:
            if "not found" in str(e).lower():
                raise OrderNotFoundError(
                    f"Order was not found — transaction {tx_hash.to_0x_hex()} "
                    f"not found on-chain"
                ) from e
            raise

    def place_buy_market_order(
        self, token_id: int, usdc_amount: USD
    ) -> CreateOrderResult:
        return self._place_market_order(token_id, usdc_amount, PolymarketSideEnum.BUY)

    def place_sell_market_order(
        self, token_id: int, token_shares: OutcomeToken
    ) -> CreateOrderResult:
        return self._place_market_order(token_id, token_shares, PolymarketSideEnum.SELL)

    def __init_approvals(
        self,
        polygon_web3: Web3 | None = None,
    ) -> None:
        # from https://github.com/Polymarket/agents/blob/main/agents/polymarket/polymarket.py#L341
        polygon_web3 = polygon_web3 or self.polygon_web3

        usdc = USDCeContract()

        # When setting allowances on Polymarket, it's important to set a large amount, because
        # every trade reduces the allowance by the amount of the trade.
        large_amount_wei = Wei(int(100 * 1e6))  # 100 USDC in Wei
        amount_to_check_wei = Wei(int(POLYMARKET_TINY_BET_AMOUNT.value * 1e6))
        ctf = PolymarketConditionalTokenContract()

        for target_address in [
            CTF_EXCHANGE_POLYMARKET,
            NEG_RISK_EXCHANGE,
            NEG_RISK_ADAPTER,
        ]:
            logger.info(f"Checking allowances for {target_address}")
            handle_allowance(
                api_keys=self.api_keys,
                sell_token=usdc.address,
                for_address=target_address,
                amount_to_check_wei=amount_to_check_wei,
                amount_to_set_wei=large_amount_wei,
                web3=polygon_web3,
            )

            ctf.approve_if_not_approved(
                api_keys=self.api_keys,
                for_address=target_address,
                web3=polygon_web3,
            )
