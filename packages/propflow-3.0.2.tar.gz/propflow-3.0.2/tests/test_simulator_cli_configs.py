import pickle
import sys
from types import SimpleNamespace

import pytest

from propflow.cli import main as cli_main
from propflow.computators import COMPUTATORS
from propflow.configs import (
    CTFactories,
    EngineDefaults,
    LOG_LEVELS,
    Logger,
    get_ct_factory,
    validate_engine_config,
    validate_policy_config,
)
from dataclasses import asdict
from propflow.engines import ENGINES
from propflow.simulator import Simulator, _setup_logger


class StubEngine:
    def __init__(self, factor_graph, convergence_config, **kwargs):
        self.factor_graph = factor_graph
        self.snapshots = [
            SimpleNamespace(global_cost=10.0),
            SimpleNamespace(global_cost=5.0),
        ]

    def run(self, max_iter):
        return None


def test_simulator_logger_level():
    logger = _setup_logger("INFO")
    assert logger.level == LOG_LEVELS["INFORMATIVE"]


def test_simulator_run_simulations(monkeypatch):
    configs = {"engineA": {"class": StubEngine, "param": 1}}
    sim = Simulator(configs)

    def fake_run_batch(args, max_workers):
        assert len(args) == 1
        assert args[0][-1] is None
        return [(0, "engineA", [1.0, 0.5, 0.25])]

    monkeypatch.setattr(sim, "_run_batch_safe", fake_run_batch)
    graphs = [{"nodes": [1, 2]}]
    results = sim.run_simulations(graphs, max_iter=3)
    assert results["engineA"][0][-1] == 0.25


def test_run_single_simulation_success():
    graph = {"nodes": [1]}
    args = (
        0,
        "engineA",
        {"class": StubEngine},
        pickle.dumps(graph),
        3,
        LOG_LEVELS["INFORMATIVE"],
        None,
    )
    index, name, costs = Simulator._run_single_simulation(args)
    assert index == 0 and name == "engineA" and costs[-1] == 5.0


def test_sequential_fallback(monkeypatch):
    sim = Simulator({"engineA": {"class": StubEngine}})
    monkeypatch.setattr(
        Simulator,
        "_run_single_simulation",
        staticmethod(lambda args: (args[0], args[1], [42])),
    )
    results = sim._sequential_fallback([(0, "engineA", {}, b"", 1, 0, None)])
    assert results[0][2] == [42]


def test_set_log_level_and_invalid_value():
    sim = Simulator({"engineA": {"class": StubEngine}})
    sim.set_log_level("HIGH")
    assert sim.logger.level == LOG_LEVELS["HIGH"]
    previous = sim.logger.level
    sim.set_log_level("unknown")
    assert sim.logger.level == previous


def test_cli_main_version_output(monkeypatch, capsys):
    monkeypatch.setattr(sys, "argv", ["propflow", "--version"])
    cli_main()
    out = capsys.readouterr().out
    assert "PropFlow Version" in out
    monkeypatch.setattr(sys, "argv", ["propflow"])
    cli_main()
    out = capsys.readouterr().out
    assert "usage" in out.lower()


def test_config_validators_and_factories():
    config = asdict(EngineDefaults())
    assert validate_engine_config(config)
    policy = {"damping_factor": 0.5, "split_factor": 0.4, "pruning_threshold": 0.1}
    assert validate_policy_config(policy)
    factory_fn = get_ct_factory(CTFactories.RANDOM_INT)
    arr = factory_fn(2, 3, low=0, high=2)
    assert arr.shape == (3, 3)


def test_global_logger_and_registries():
    logger = Logger("test", file=False)
    logger.info("hello")
    assert "min-sum" in COMPUTATORS
    assert "BPEngine" in ENGINES


def test_run_single_simulation_handles_engine_failure():
    class FailingEngine:
        def __init__(self, factor_graph, convergence_config, **_):
            self.snapshots = []

        def run(self, max_iter):  # pragma: no cover - intentional failure path
            raise RuntimeError("boom")

    args = (
        0,
        "broken",
        {"class": FailingEngine},
        pickle.dumps({"nodes": [1]}),
        3,
        20,
        None,
    )

    index, name, costs = Simulator._run_single_simulation(args)
    assert index == 0 and name == "broken" and costs == []


def test_run_single_simulation_handles_unpickle_error():
    class NoOpEngine:
        def __init__(self, **_):
            self.snapshots = []

        def run(self, max_iter):
            self.snapshots.append(SimpleNamespace(global_cost=0.0))

    args = (
        1,
        "noop",
        {"class": NoOpEngine},
        b"not-a-real-pickle",
        2,
        20,
        None,
    )

    index, name, costs = Simulator._run_single_simulation(args)
    assert index == 1 and name == "noop" and costs == []


def test_simulator_seed_propagation(monkeypatch):
    configs = {
        "engineA": {"class": StubEngine},
        "engineB": {"class": StubEngine},
    }
    sim = Simulator(configs, seed=900)

    def fake_run_batch(args, max_workers):
        seeds = [job[-1] for job in args]
        # 2 graphs × 2 engines
        assert seeds == [900, 901, 902, 903]
        return [(job[0], job[1], [float(job[0])]) for job in args]

    monkeypatch.setattr(sim, "_run_batch_safe", fake_run_batch)
    graphs = [{"nodes": [1]}, {"nodes": [2]}]
    results = sim.run_simulations(graphs, max_iter=2)
    assert len(results["engineA"]) == 2
    assert len(results["engineB"]) == 2
