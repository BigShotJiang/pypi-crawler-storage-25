"""Free-function tree CRUD operations."""


def merge(a, b, c=None):
    """Set-union of two node collections (works on any CclTtNodes-like type)."""
    if a is None:
        return b
    if b is None:
        return a
    return type(a)(a.nodes + b.nodes)


def remove(a, b):
    """Set-difference: copy of `a` with any node also present in `b` removed."""
    a_copy = a.copy()
    for node in a_copy.nodes:
        for node2 in b.nodes:
            if node.node_id == node2.node_id and node.tree.name == node2.tree.name:
                a_copy.nodes.remove(node)
    return a_copy
