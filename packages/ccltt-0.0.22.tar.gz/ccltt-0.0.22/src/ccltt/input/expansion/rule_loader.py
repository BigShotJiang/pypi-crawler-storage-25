"""Load expansion YAML rules from a directory."""
from dataclasses import dataclass
from pathlib import Path
from typing import List, Dict, Any
import yaml


class RuleLoadError(Exception):
    """Raised when rule files are malformed."""


@dataclass
class Rule:
    name: str
    expanded: Dict[str, Any]


_EXPANDED_SUFFIX = ".expanded.yaml"


def _load_yaml(path: Path) -> Dict[str, Any]:
    try:
        with path.open("r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
    except yaml.YAMLError as e:
        raise RuleLoadError(f"YAML parse error in {path.name}: {e}") from e
    if data is None:
        return {}
    if not isinstance(data, dict):
        raise RuleLoadError(f"Top-level YAML in {path.name} must be a mapping, got {type(data).__name__}")
    return data


def load(rules_dir) -> List[Rule]:
    """Scan `rules_dir` for `<name>.expanded.yaml` rules.

    Returns rules sorted by `name` (lexicographic). Invalid YAML raises
    RuleLoadError. A non-existent directory yields an empty list.
    """
    rules_dir = Path(rules_dir)
    if not rules_dir.exists():
        return []
    expandeds: Dict[str, Path] = {}
    for entry in rules_dir.iterdir():
        if not entry.is_file():
            continue
        nm = entry.name
        if nm.endswith(_EXPANDED_SUFFIX):
            expandeds[nm[: -len(_EXPANDED_SUFFIX)]] = entry
        # other files are ignored
    rules: List[Rule] = []
    for name in sorted(expandeds):
        rules.append(Rule(
            name=name,
            expanded=_load_yaml(expandeds[name]),
        ))
    return rules
