"""Expansion engine: anchor each rule at a top-level child of the tree root.

Each rule file is named `<ANCHOR>.expanded.yaml`. `<ANCHOR>` matches a direct
child of the parsed tree's root by type-name (typed instances use `node_type`,
singletons use `node_name`). The YAML contents describe the subtree to reconcile
underneath that anchor. If the anchor does not yet exist, it is created as a
fake (is_real=False) child of root before reconciliation.
"""
from typing import Dict, Any
from ...core import CclTtTree, CclTtNode

RESERVED_KEYS = {"__value__", "__type__", "__unit__", "__is_real__"}


def _node_type_name(tree: CclTtTree, node_id: int) -> str:
    """Return the type-name used for matching:
       - typed instance (TYPE: name) -> node_type
       - singleton (TYPE)            -> node_name
    """
    db_node = tree.db.get_node(tree.name, node_id)
    if db_node is None:
        return ""
    _id, name, ty, _val, _expr = db_node
    return ty if ty is not None else name


def _find_child_by_typename(tree: CclTtTree, parent_id: int, type_name: str):
    children = tree.find_by_path_with_wildcard(parent_id, "*")
    for ch in children:
        if ch.name == type_name or _node_type_name(tree, ch.node_id) == type_name:
            return ch
    return None


def _find_children_by_typename(tree: CclTtTree, parent_id: int, type_name: str):
    children = tree.find_by_path_with_wildcard(parent_id, "*")
    return [
        ch for ch in children
        if ch.name == type_name or _node_type_name(tree, ch.node_id) == type_name
    ]


def _reconcile(tree: CclTtTree, anchor: CclTtNode, rhs_subtree: Dict[str, Any], stats: Dict[str, int]):
    """Walk RHS subtree under `anchor`. Add any missing child per `__is_real__`."""
    for child_name, child_spec in rhs_subtree.items():
        if child_name in RESERVED_KEYS:
            continue
        spec = child_spec if isinstance(child_spec, dict) else {}
        existing_nodes = _find_children_by_typename(tree, anchor.node_id, child_name)
        if not existing_nodes:
            value = spec.get("__value__")
            ty = spec.get("__type__")
            unit = spec.get("__unit__")
            is_real = bool(spec.get("__is_real__", False))
            new_id = tree.build_tree(
                parent_id=anchor.node_id,
                name=child_name,
                ty=ty,
                value=str(value) if value is not None else None,
                is_real=is_real,
            )
            if unit is not None:
                tree.add_exprn(new_id, unit)
            new_node = tree.nodes[new_id]
            stats["added"] += 1
            existing_nodes = [new_node]
        for existing in existing_nodes:
            _reconcile(tree, existing, spec, stats)


def apply(tree: CclTtTree, rules) -> None:
    """Apply each rule: anchor it at `tree.root/<rule.name>` and reconcile."""
    import logging
    logger = logging.getLogger("ccltt.expansion")
    for rule in rules:
        if not isinstance(rule.expanded, dict):
            continue
        anchor = _find_child_by_typename(tree, tree.root.node_id, rule.name)
        if anchor is None:
            new_id = tree.build_tree(
                parent_id=tree.root.node_id,
                name=rule.name,
                is_real=False,
            )
            anchor = tree.nodes[new_id]
        stats = {"added": 0}
        _reconcile(tree, anchor, rule.expanded, stats)
        logger.info("rule=%s nodes_added=%d", rule.name, stats["added"])
