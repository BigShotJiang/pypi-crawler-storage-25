"""CCL parser — wraps legacy build_tree_from_ccl, then runs expansion engine."""
from pathlib import Path
from ..._legacy_parsers import build_tree_from_ccl
from ..expansion import rule_loader, engine

RULES_DIR = Path(__file__).parent / "rules"


def parse(path: str):
    manager = build_tree_from_ccl(path)
    rules = rule_loader.load(RULES_DIR)
    if rules:
        engine.apply(manager.trees["source"], rules)
    return manager
