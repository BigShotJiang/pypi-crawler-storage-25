"""Parser abstract interface."""
from abc import ABC, abstractmethod


class Parser(ABC):
    @abstractmethod
    def parse(self, path: str):
        """Parse `path` and return a CclManager-like object with at least `trees['source']`."""
