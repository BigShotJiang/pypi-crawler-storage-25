import json
import re
from .core.tree import CclTtTree
from .core.database import MyDatabase
from .core.node import CclTtNode, CclTtNodes
from collections import OrderedDict


class CclManager:
    def __init__(self):
        self.db = MyDatabase()
        self.trees = {}
        self.init_tree("source")
    
    def init_tree(self, name: str):
        if name in self.trees:
            return False
        tree = CclTtTree(name, self.db)
        self.trees[name] = tree
        return tree

def build_tree(father:CclTtNodes,data):
    name = data["name"]
    ty = data.get("type", None)
    value = data.get("value", None)
    if value is not None:
        if ty == "int":
            father.add(name, int(value))
        elif ty == "bool":
            father.add(name, bool(value))
        elif ty == "str":
            father.add(name, str(value))
        elif ty == "real":
            father.add(name, float(value))
        elif ty == "int list":
            father.add(name, [int(val) for val in value])
        elif ty == "real list":
            father.add(name, [float(val) for val in value])
        elif ty == "str list":
            father.add(name, [str(val) for val in value])
        else:
            father.add(name, value)
    else:
        father.add(name)
        # For typed container nodes (e.g. type="FLOW", value=None), persist the
        # type so that the expansion engine can match by type-name.
        if ty is not None:
            node = father.get(name)
            if node is not None:
                node.retype(ty)
    exprn = data.get("exprn", None)
    if exprn is not None:
        child = father.get(name)
        child.add_exprn(exprn)
    node = father.get(name)
    for child_data in data.get('children', []):
        build_tree(node,child_data)


def parse_config_to_dict(config_text):
    root = {
        "name": "root",
        "children": []
    }
    current_node = root
    stack = [current_node]
    lines = config_text.splitlines()
    for line in lines:
        line = line.strip()
        if not line:
            continue
        if line.startswith("//"):
            continue
        if re.match(r'^[a-zA-Z_][a-zA-Z0-9_]*\s*:?\s*[a-zA-Z0-9_]*$', line):
            new_node = {
                "name": line,
                "children": []
            }
            current_node["children"].append(new_node)
            stack.append(current_node)
        elif line == "{":
            current_node = new_node
        elif line == "}":
            if stack:
                current_node = stack[-1]
                stack.pop()
            else:
                current_node = root
        elif re.match(r'^[a-zA-Z_][a-zA-Z0-9_]*\s*=\s*.*$', line):
            name, value = line.split("=", 1)
            name = name.strip().strip('"')
            value = value.strip().strip('"')
            ty = "str"
            if value.lower() == "true":
                value = True
                ty = "bool"
            elif value.lower() == "false":
                value = False
                ty = "bool"
            elif re.match(r'^\d+$', value):
                value = int(value)
                ty = "int"
            elif re.match(r'^\d+\.\d+$', value):
                value = float(value)
                ty = "real"
            elif re.match(r'^\d+\.?\d*[eE][+-]?\d+$', value):
                value = float(value)
                ty = "real"
            elif re.match(r'^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$', value):
                value = float(value)
                ty = "real"
            elif re.match(r'^\d+(,\d+)*$', value):
                value = [int(val) for val in value.split(",")]
                ty = "int list"
            elif re.match(r'^[+-]?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?(?:\s*,\s*[+-]?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?)+$', value):
                value = [float(v) for v in value.split(",")]
                ty = "real list"
            elif re.match(r'(\w+\[?\d*\]?)=("[^"]*"|[^;]+)', value):
                pattern = r'(\w+\[?\d*\]?)=("[^"]*"|[^;]+)'
                value_node = {
                    "name": name,
                    "children": []
                }
                for key, v in re.findall(pattern, value):
                    key = key.strip()
                    v = v.strip()
                    child_ty = "str"
                    if v.startswith('"') and v.endswith('"'):
                        v = v[1:-1]
                    if re.match(r'^\d+$', v):
                        v = int(v)
                        child_ty = "int"
                    elif re.match(r'^\d+\.\d+$', v):
                        v = float(v)
                        child_ty = "real"
                    elif re.match(r'^\d+\.?\d*[eE][+-]?\d+$', v):
                        v = float(v)
                        child_ty = "real"
                    elif re.match(r'^\d+(,\d+)*$', v):
                        v = [int(val) for val in v.split(",")]
                        child_ty = "int list"
                    elif re.match(r'^\d+(\.\d+)?(,\d+(\.\d+)?)*$', v):
                        v = [float(val) for val in v.split(",")]
                        child_ty = "real list"
                    value_node["children"].append({"name": key, "value": v, "type": child_ty})
                current_node["children"].append(value_node)
                continue

            current_node["children"].append({
                "name": name,
                "value": value,
                "type": ty,
            })
        else:
            raise ValueError(f"无法解析的行: {line}")
    return root


def _infer_type(value):
    if isinstance(value, bool):
        return "bool"
    if isinstance(value, int) and not isinstance(value, bool):
        return "int"
    if isinstance(value, float):
        return "real"
    if isinstance(value, list) and all(isinstance(item, int) and not isinstance(item, bool) for item in value):
        return "int list"
    if isinstance(value, list) and all(isinstance(item, (int, float)) and not isinstance(item, bool) for item in value):
        return "real list"
    if isinstance(value, list) and all(isinstance(item, str) for item in value):
        return "str list"
    return "str"


def _json_mapping_to_tree_dict(data, name="root"):
    node = {"name": name, "children": []}
    if isinstance(data, dict) and "name" in data:
        return data
    if not isinstance(data, dict):
        node["value"] = data
        node["type"] = _infer_type(data)
        node.pop("children")
        return node
    for key, value in data.items():
        if isinstance(value, dict):
            node["children"].append(_json_mapping_to_tree_dict(value, key))
        else:
            node["children"].append({
                "name": key,
                "value": value,
                "type": _infer_type(value),
            })
    return node


def build_tree_from_json(path: str):
    with open(path, "r", encoding="utf-8") as f:
        config_text = f.read()
    try:
        root = _json_mapping_to_tree_dict(json.loads(config_text, object_pairs_hook=OrderedDict))
    except json.JSONDecodeError:
        root = parse_config_to_dict(config_text)
    json_str = json.dumps(root, indent=4, ensure_ascii=False)
    data = json.loads(json_str, object_pairs_hook=OrderedDict)
    manager = CclManager()
    tree = manager.trees["source"]
    root = tree.ROOT()
    for child_data in data.get('children', []):
        build_tree(root, child_data)
    return manager


def preprocess_ccl_text(text):
    """
    CCL 文本前处理：
    1. 删除所有行尾注释（以 # 开头到行末的内容）。
    2. 处理 `\\` 行连续符：将以 `\\` 结尾的行与下一行连接，支持连续多行。
    """
    lines = text.splitlines()

    stripped = []
    for line in lines:
        idx = line.find('#')
        if idx >= 0:
            line = line[:idx]
        stripped.append(line)

    result = []
    buffer = None
    for line in stripped:
        rstripped = line.rstrip()
        if rstripped.endswith('\\'):
            piece = rstripped[:-1].rstrip()
            if buffer is None:
                buffer = piece
            else:
                buffer += ' ' + piece.lstrip()
        else:
            if buffer is None:
                result.append(line)
            else:
                result.append(buffer + ' ' + line.lstrip())
                buffer = None
    if buffer is not None:
        result.append(buffer)
    return '\n'.join(result)


def parse_ccl_to_dict(ccl_text):
    lines = preprocess_ccl_text(ccl_text).splitlines()
    root = {
        "name": "root",
        "children": []
    }
    current_node = root
    stack = []
    skipped_blocks = {"MATERIAL GROUP", "COMMAND FILE", "SIMULATION CONTROL"}
    skip_depth = 0
    
    for line in lines:
        # line = line.split()
        line = line.strip()
        if not line:
            continue
        if skip_depth:
            if re.match(r'^[a-zA-Z0-9 _]+\s*:', line):
                skip_depth += 1
            elif re.match(r'^END$', line):
                skip_depth -= 1
            continue
        #以一个关键字开头，最后是一个冒号，可以有空格
        if re.match(r'^[a-zA-Z0-9 _]+\s*:', line):
            type_key, _, instance_name = line.partition(':')
            type_key = type_key.strip()
            instance_name = instance_name.strip()
            if type_key.upper() in skipped_blocks:
                skip_depth = 1
                continue
            stack.append(current_node)
            if instance_name:
                new_node = {
                    "name": instance_name,
                    "type": type_key,
                    "children": []
                }
            else:
                new_node = {
                    "name": type_key,
                    "children": []
                }
            current_node["children"].append(new_node)
            current_node = new_node
            current_node = new_node
        #END
        elif re.match(r'^END$', line):
            if stack:
                current_node = stack[-1]
                stack.pop()
            else :
                current_node = root
        # 匹配任何"前面内容=后面内容"形式的赋值语句
        elif '=' in line:
            parts = line.split('=', 1)
            name = parts[0].strip()
            value = parts[1].strip()
            
            # 判断是否为数组带单位格式
            # array_with_unit_match = re.match(r'^(\[.*\])\s*(\[.*\])$', value)
            if re.match(r'^([a-zA-Z0-9+\-*. ]*)\[([^\[\]]+)\]$', value):
                # match = re.match(r'^[a-zA-Z0-9+\-*]*\[[a-zA-Z0-9+\-*]+\]$', value)
                # print("1",value)
                match = re.match(r'^([a-zA-Z0-9+\-*. ]*)\[([^\[\]]+)\]$', value)
                if match:
                    value_ = match.group(1) if match.group(1) else "1"
                
                unit = match.group(2)
                value_ = value_.strip()
                if len(value_) == 0:
                    value_ = "1"
                type = "str"
                if value_.lower() == "true":
                    value_ = True
                    type = "bool"
                elif value_.lower() == "false":
                    value_ = False
                    type = "bool"
                elif re.match(r'^\d+$', value_):
                    value_ = int(value_)
                    type = "int"
                elif re.match(r'^\d+\.\d*$', value_):
                    value_ = float(value_)
                    type = "real"
                #1.0e-5
                elif re.match(r'^\d+\.?\d*[eE][+-]?\d+$', value_):
                    value_ = float(value_)
                    type = "real"
                value_node = {
                    "name": name,
                    "value": value_,
                    "exprn": unit,
                    "type": type
                }
            elif re.match(r'^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$', value):
                value_ = value.strip()
                type = "str"
                if value_.lower() == "true":
                    value_ = True
                    type = "bool"
                elif value_.lower() == "false":
                    value_ = False
                    type = "bool"
                elif re.match(r'^\d+$', value_):
                    value_ = int(value_)
                    type = "int"
                elif re.match(r'^\d+\.\d+$', value_):
                    value_ = float(value_)
                    type = "real"
                #1.0e-5
                elif re.match(r'^\d+\.?\d*[eE][+-]?\d+$', value_):
                    value_ = float(value_)
                    type = "real"
                # 处理负数浮点数
                elif re.match(r'^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$', value_):
                    value_ = float(value_)
                    type = "real"
                value_node = {
                    "name": name,
                    "value": value_,
                    "type": type
                }
            elif re.match(r'^[^,\[\]]+(?:\s*,\s*[^,\[\]]+)+$', value):
                type = "str list"
                if re.match(r'^\d+(,\d+)*$', value):
                    value = [int(val) for val in value.split(",")]
                    type = "int list"
                elif re.match(r'^[+-]?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?(?:\s*,\s*[+-]?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?)+$', value):
                    value = [float(v) for v in value.split(",")]
                    type = "real list"
                else:
                    value = [v for v in value.split(",")]
                value_node = {
                    "name": name,
                    "value": value,
                    "type": type
                }
            elif re.fullmatch(r'(?:[^,\[\]]*?\[[^\[\]]*?\])(?:\s*,\s*(?:[^,\[\]]*?\[[^\[\]]*?\]))*', value):
                value_list = value.split(",")
                value_after_tt = []
                unit_list = []
                type = 0
                # print(value_list)
                for value in value_list:
                    # print(value)
                    match = re.match(r'^([^\[\]]*)\[([^\[\]]+)\]$', value.strip())
                    value_ = match.group(1).strip()
                    unit = match.group(2).strip()
                    # print(value_)
                    if re.match(r'^\d+$', value_):
                        value_after_tt.append (int(value_))
                        type = max(type,1)
                    elif re.match(r'^\d+\.\d*$', value_):
                        value_after_tt.append (float(value_))
                        type = max(type,2)
                    #1.0e-5
                    elif re.match(r'^\d+\.?\d*[eE][+-]?\d+$', value_):
                        value_after_tt.append (float(value_))
                        type = max(type,2)
                    elif len(value_.strip()) == 0:
                        value_after_tt.append (1)
                        type = max(type,1)
                    unit_list.append(unit)
                if type > 1:
                    type = "real list"
                elif type >0 :
                    type = "int list"
                else :
                    type = "str list"
                value_node = {
                    "name": name,
                    "value": value_after_tt,
                    "exprn": unit_list,
                    "type": type
                }
                # print(value_node)
            else:
                value_node = {
                    "name": name,
                    "value": value,
                    "type": "str"
                }
            current_node["children"].append(value_node)
        else:
            raise ValueError(f"无法解析的行: {line}")
    
    return root

def build_tree_from_ccl(path: str):
    with open(path, "r", encoding="utf-8") as f:
        config_text = f.read()
    root =  parse_ccl_to_dict(config_text)
    json_str = json.dumps(root, indent=4, ensure_ascii=False)
    data = json.loads(json_str, object_pairs_hook=OrderedDict)
    manager = CclManager()
    tree = manager.trees["source"]
    root = tree.ROOT()
    for child_data in data.get('children', []):
        build_tree(root,child_data)
    return manager

# Legacy module-level CclManager is kept; new top-level CclManager lives in ccltt.manager.
# `from ccltt import CclManager` continues to import the new one (see __init__.py).
