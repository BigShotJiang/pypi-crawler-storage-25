"""Top-level coordinator: wraps input parsers, transform-layer trees, and output writers."""
from __future__ import annotations

from .core import MyDatabase, CclTtTree


class CclManager:
    def __init__(self):
        self.db = MyDatabase()
        self.trees = {}
        self.init_tree("source")

    def init_tree(self, name: str):
        if name in self.trees:
            return False
        tree = CclTtTree(name, self.db)
        self.trees[name] = tree
        return tree

    @classmethod
    def from_ccl(cls, path: str) -> "CclManager":
        from .input.ccl.parser import parse
        legacy = parse(path)
        mgr = cls.__new__(cls)
        mgr.db = legacy.db
        mgr.trees = legacy.trees
        return mgr

    @classmethod
    def from_json(cls, path: str) -> "CclManager":
        from ._legacy_parsers import build_tree_from_json
        legacy = build_tree_from_json(path)
        mgr = cls.__new__(cls)
        mgr.db = legacy.db
        mgr.trees = legacy.trees
        return mgr

    def to_ccl(self, tree_name: str = "source", include_expanded: bool = False, name_style: str = "original") -> str:
        raise NotImplementedError("CCL output is not supported yet")

    def to_json(
        self,
        tree_name: str = "source",
        include_expanded: bool | None = None,
        indent: int | None = 4,
        schema: str = "ccl2json",
    ) -> str:
        from .output.json.writer import JsonWriter
        return JsonWriter().write(
            self.trees[tree_name],
            include_expanded=include_expanded,
            indent=indent,
            schema=schema,
        )

    def debug_print(self, tree_name: str = "source", name_style: str = "original") -> str:
        raise NotImplementedError("Debug printing is not supported yet")
