"""Name-style conversions for output writers."""
import re

SNAKE = "snake"
CAMEL = "camel"
ORIGINAL = "original"

_VALID = {SNAKE, CAMEL, ORIGINAL}


def to_snake(name: str) -> str:
    s = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", name)
    s = re.sub(r"([A-Z]+)([A-Z][a-z])", r"\1_\2", s)
    s = re.sub(r"[\s\-]+", "_", s)
    s = re.sub(r"_+", "_", s)
    return s.strip("_").lower()


def to_camel(name: str) -> str:
    snake = to_snake(name)
    if not snake:
        return name
    tokens = snake.split("_")
    return tokens[0] + "".join(t[:1].upper() + t[1:] for t in tokens[1:] if t)


def format_name(name: str, style: str = ORIGINAL) -> str:
    if name is None:
        return name
    if style == ORIGINAL:
        return name
    if style == SNAKE:
        return to_snake(name)
    if style == CAMEL:
        return to_camel(name)
    raise ValueError(f"unknown name_style: {style!r} (expected one of {sorted(_VALID)})")
