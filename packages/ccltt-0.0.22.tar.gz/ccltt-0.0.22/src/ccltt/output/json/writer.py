"""JSON writer.

The default output follows the ccl2json shape: original CCL names are preserved,
typed instances become ``TYPE:name`` object keys, and value nodes collapse to
their scalar/list values. The older ``name/type/value/children`` debug schema is
still available via ``schema="tree"``.
"""
from __future__ import annotations

import json as _json
import re
from collections import OrderedDict

from ..base import Writer
from ..name_style import format_name, SNAKE
from ...core import CclTtTree


_SI_FACTORS = {
    "m": 1.0,
    "meter": 1.0,
    "metre": 1.0,
    "mm": 0.001,
    "cm": 0.01,
    "km": 1000.0,
    "s": 1.0,
    "sec": 1.0,
    "min": 60.0,
    "hr": 3600.0,
    "h": 3600.0,
    "kg": 1.0,
    "g": 0.001,
    "mg": 0.000001,
    "pa": 1.0,
    "kpa": 1000.0,
    "mpa": 1000000.0,
    "bar": 100000.0,
    "n": 1.0,
    "j": 1.0,
    "w": 1.0,
    "k": 1.0,
    "rad": 1.0,
}


def _underscore_text(value):
    if not isinstance(value, str):
        return value
    text = value.strip().strip('"')
    text = re.sub(r"\s*[|｜]\s*", "__", text)
    text = re.sub(r"\s+", "_", text)
    return text


def _normalize_value(value):
    if isinstance(value, str):
        return _underscore_text(value)
    if isinstance(value, list):
        return [_normalize_value(item) for item in value]
    return value


def _unit_factor(unit):
    if not isinstance(unit, str):
        return None
    normalized = unit.strip().lower().replace(" ", "")
    return _SI_FACTORS.get(normalized)


def _to_si_value(value, exprn):
    if exprn is None:
        return value
    if isinstance(value, list) and isinstance(exprn, list):
        converted = []
        for item, unit in zip(value, exprn):
            converted.append(_to_si_value(item, unit))
        if len(value) > len(converted):
            converted.extend(value[len(converted):])
        return converted
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        factor = _unit_factor(exprn)
        if factor is not None:
            return value * factor
    return value


def _typed_value(value, ty):
    if value is None:
        return None
    if ty == "int":
        try:
            return int(value)
        except (TypeError, ValueError):
            return value
    if ty == "real":
        try:
            return float(value)
        except (TypeError, ValueError):
            return value
    if ty == "bool":
        if isinstance(value, bool):
            return value
        return str(value).lower() in ("1", "true")
    if ty in ("int list", "real list", "str list"):
        if isinstance(value, str):
            try:
                return _json.loads(value)
            except _json.JSONDecodeError:
                return value
        return _normalize_value(value)
    return value


def _typed_exprn(exprn):
    if not isinstance(exprn, str):
        return exprn
    try:
        return _json.loads(exprn)
    except _json.JSONDecodeError:
        return exprn


def _value_with_exprn(value, exprn):
    if isinstance(value, list) and isinstance(exprn, list):
        return [f"{v}[{e}]" for v, e in zip(value, exprn)]
    return f"{value}[{exprn}]"


class JsonWriter(Writer):
    def write(
        self,
        tree: CclTtTree,
        include_expanded: bool | None = None,
        indent: int | None = 4,
        schema: str = "ccl2json",
    ) -> str:
        if schema == "tree":
            data = self._node_to_dict(
                tree.root,
                include_expanded=False if include_expanded is None else include_expanded,
            )
        elif schema == "ccl2json":
            data = self._tree_to_ccl2json_dict(
                tree,
                include_expanded=True if include_expanded is None else include_expanded,
            )
        else:
            raise ValueError(f"Unsupported JSON schema: {schema!r}")
        return _json.dumps(data, indent=indent, ensure_ascii=False)

    def _tree_to_ccl2json_dict(self, tree, include_expanded: bool):
        out = OrderedDict()
        for child in tree.find_by_path_with_wildcard(tree.root.node_id, "*"):
            if not include_expanded and not child.is_real():
                continue
            out[self._ccl2json_key(child, top_level=True)] = self._ccl2json_value(child, include_expanded)
        return out

    def _ccl2json_key(self, node, top_level: bool = False, parent=None):
        ty = node.type()
        if (
            parent is not None
            and node.name.lower() == "group description"
            and (str(parent.type()).lower() == "material" or parent.name.lower() == "material")
        ):
            return "Material_Description"
        if ty is not None and node.value() is None:
            if top_level:
                return _underscore_text(ty)
            return _underscore_text(f"{ty}_{node.name}")
        return _underscore_text(node.name)

    def _ccl2json_value(self, node, include_expanded: bool):
        value = node.value()
        ty = node.type()
        if value is not None:
            typed_value = _typed_value(value, ty)
            exprn = node.exprn()
            if exprn is not None:
                return _normalize_value(_to_si_value(typed_value, _typed_exprn(exprn)))
            return _normalize_value(typed_value)

        out = OrderedDict()
        for child in node.tree.find_by_path_with_wildcard(node.node_id, "*"):
            if not include_expanded and not child.is_real():
                continue
            out[self._ccl2json_key(child, parent=node)] = self._ccl2json_value(child, include_expanded)
        return out

    def _node_to_dict(self, node, include_expanded: bool):
        out = {"name": format_name(node.name, SNAKE)}
        ty = node.type()
        if ty is not None:
            out["type"] = ty
        value = node.value()
        if value is not None:
            out["value"] = _typed_value(value, ty)
        exprn = node.exprn()
        if exprn is not None:
            out["exprn"] = exprn
        children = []
        for child in node.tree.find_by_path_with_wildcard(node.node_id, "*"):
            if not include_expanded and not child.is_real():
                continue
            children.append(self._node_to_dict(child, include_expanded))
        if children:
            out["children"] = children
        return out
