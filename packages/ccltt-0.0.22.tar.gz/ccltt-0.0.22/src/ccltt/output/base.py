"""Writer abstract interface."""
from abc import ABC, abstractmethod
from ..core import CclTtTree


class Writer(ABC):
    @abstractmethod
    def write(self, tree: CclTtTree, include_expanded: bool = False) -> str:
        """Serialize the tree. By default skip is_real=False subtrees."""
