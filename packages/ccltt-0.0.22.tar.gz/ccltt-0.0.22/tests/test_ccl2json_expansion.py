from pathlib import Path

import pytest

from src.ccltt.input.ccl import parser as ccl_parser


CCL2JSON_DIR = Path(__file__).resolve().parents[1] / "ccl2json"
CCL2JSON_CCL_FILES = sorted(CCL2JSON_DIR.rglob("*.ccl"))

assert CCL2JSON_CCL_FILES, f"no ccl2json CCL samples found under {CCL2JSON_DIR}"


@pytest.mark.parametrize("ccl_path", CCL2JSON_CCL_FILES, ids=lambda p: p.name)
def test_ccl2json_samples_receive_builtin_expansion(ccl_path):
    mgr = ccl_parser.parse(str(ccl_path))
    tree = mgr.trees["source"]

    # path -> expected is_real after expansion. True paths carry __is_real__: true
    # in YAML (or are auto-promoted by a descendant that does). False paths stay
    # scaffolding-only.
    expected_paths_with_is_real = {
        "FLOW/ANALYSIS_TYPE/Restart": True,
        "FLOW/SOLVER_CONTROL/EQUATION_GROUPS_RESIDUAL_SETTINGS": True,
        # LOCAL_INITIAL_CONDITIONS is __is_real__: false but auto-promoted by Local_Init_1.
        "FLOW/*/INITIALISATION/LOCAL_INITIAL_CONDITIONS": True,
        "LIBRARY/UserDefinedRegion": False,
        "FLOW/ContactInfo": True,
    }

    for path, expected_real in expected_paths_with_is_real.items():
        nodes = tree.find_by_path_with_wildcard(1, path)
        assert nodes, f"{path} was not expanded for {ccl_path}"
        assert all(node.is_real() is expected_real for node in nodes), (
            f"{path} expected is_real={expected_real} for {ccl_path}, got "
            f"{[n.is_real() for n in nodes]}"
        )

    # path -> (type, value, expected_is_real)
    scalar_checks = {
        "FLOW/ANALYSIS_TYPE/Restart/Dump_Data_for_Restart/Dump_Data_for_Restart": ("bool", "True", True),
        "FLOW/SOLVER_CONTROL/EQUATION_GROUPS_RESIDUAL_SETTINGS/MOMENTUM/Residual_Target": ("real", "0.0001", True),
        "LIBRARY/UserDefinedRegion/FluidDomain_1/UserDefinedCylinder_1/radius": ("real", "0.01", False),
        "FLOW/ContactInfo/gap": ("real", "1e-05", True),
    }

    for path, (expected_type, expected_value, expected_real) in scalar_checks.items():
        nodes = tree.find_by_path_with_wildcard(1, path)
        assert len(nodes) == 1, f"expected one node at {path} for {ccl_path}, got {len(nodes)}"
        assert nodes[0].is_real() is expected_real
        assert nodes[0].type() == expected_type
        assert str(nodes[0].value()) == expected_value

    local_u_values = tree.find_by_path_with_wildcard(
        1,
        "FLOW/*/INITIALISATION/LOCAL_INITIAL_CONDITIONS/"
        "CARTESIAN_VELOCITY_COMPONENTS/Local_Init_1/U_value",
    )
    assert local_u_values, f"local init U_value was not expanded for {ccl_path}"
    assert all(node.type() == "real" and str(node.value()) == "1.0" for node in local_u_values)
    # Local_Init_1 carries __is_real__: true in YAML, so its leaves are real too.
    assert all(node.is_real() is True for node in local_u_values)
