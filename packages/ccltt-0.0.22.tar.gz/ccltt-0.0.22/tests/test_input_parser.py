from src.ccltt.input.ccl.parser import parse as parse_ccl
from src.ccltt import build_tree_from_ccl, build_tree_from_json
from pathlib import Path


CCL2JSON_SAMPLE = (
    Path(__file__).resolve().parents[1]
    / "ccl2json"
    / "重启动、残差、局部初始化"
    / "CASE2719-ifd-0011-sx2_tr.ccl"
)


def test_parse_ccl_matches_legacy_build_tree_from_ccl(tmp_path, monkeypatch):
    from src.ccltt.input.ccl import parser as ccl_parser
    monkeypatch.setattr(ccl_parser, "RULES_DIR", tmp_path)
    legacy = build_tree_from_ccl(str(CCL2JSON_SAMPLE))
    new = ccl_parser.parse(str(CCL2JSON_SAMPLE))
    legacy_out = legacy.trees["source"].ROOT().transfrom()
    new_out = new.trees["source"].ROOT().transfrom()
    assert legacy_out == new_out


def test_parse_ccl_returns_manager_with_source_tree():
    mgr = parse_ccl(str(CCL2JSON_SAMPLE))
    assert "source" in mgr.trees
    root = mgr.trees["source"].ROOT()
    assert root.name() == "root"


def test_ccl_parser_runs_expansion_engine_with_empty_rules_dir(tmp_path, monkeypatch):
    # No rule files in tmp_path -> parsing must be a no-op vs legacy.
    from src.ccltt.input.ccl import parser as ccl_parser
    monkeypatch.setattr(ccl_parser, "RULES_DIR", tmp_path)
    new = ccl_parser.parse(str(CCL2JSON_SAMPLE))
    legacy = build_tree_from_ccl(str(CCL2JSON_SAMPLE))
    assert new.trees["source"].ROOT().transfrom() == legacy.trees["source"].ROOT().transfrom()


def test_ccl_parser_applies_sanity_rule(tmp_path, monkeypatch):
    # Filename stem == anchor name (a direct child of tree.root).
    (tmp_path / "LIBRARY.expanded.yaml").write_text(
        "CclTtSentinel: {}\n", encoding="utf-8",
    )
    from src.ccltt.input.ccl import parser as ccl_parser
    monkeypatch.setattr(ccl_parser, "RULES_DIR", tmp_path)
    mgr = ccl_parser.parse(str(CCL2JSON_SAMPLE))
    sentinels = mgr.trees["source"].find_by_path_with_wildcard(1, "LIBRARY/CclTtSentinel")
    assert len(sentinels) >= 1
    for s in sentinels:
        assert s.is_real() is False


def test_manager_from_ccl_loads_source_tree():
    from src.ccltt.manager import CclManager as NewMgr
    mgr = NewMgr.from_ccl(str(CCL2JSON_SAMPLE))
    assert "source" in mgr.trees


def test_ccl_parser_skips_unneeded_control_blocks(tmp_path, monkeypatch):
    sample = tmp_path / "skip.ccl"
    sample.write_text(
        """
FLOW: Flow Analysis 1
    DOMAIN: Domain 1
        Domain Type = Fluid
    END
END
MATERIAL GROUP:
    MATERIAL: Hidden
        Density = 10 [kg m^-3]
    END
END
COMMAND FILE:
    Version = 1
END
SIMULATION CONTROL:
    Option = Hidden
END
""",
        encoding="utf-8",
    )
    from src.ccltt.input.ccl import parser as ccl_parser
    monkeypatch.setattr(ccl_parser, "RULES_DIR", tmp_path)

    mgr = ccl_parser.parse(str(sample))
    tree = mgr.trees["source"]

    assert tree.find_by_path_with_wildcard(1, "FLOW")
    assert not tree.find_by_path_with_wildcard(1, "MATERIAL GROUP")
    assert not tree.find_by_path_with_wildcard(1, "COMMAND FILE")
    assert not tree.find_by_path_with_wildcard(1, "SIMULATION CONTROL")


def test_legacy_build_tree_from_json_is_exported_and_manager_uses_it(tmp_path):
    path = tmp_path / "input.json"
    path.write_text('{"Fluid pair": "Water | Air", "Count": 2}', encoding="utf-8")

    legacy = build_tree_from_json(str(path))
    assert legacy.trees["source"].ROOT().get("Fluid pair").value() == "Water | Air"

    from src.ccltt.manager import CclManager as NewMgr
    mgr = NewMgr.from_json(str(path))
    assert mgr.trees["source"].ROOT().get("Count").value() == "2"
