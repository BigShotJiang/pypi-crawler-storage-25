from src.ccltt.core.database import MyDatabase


def test_node_table_has_is_real_column():
    db = MyDatabase()
    db.init_node_table("source")
    db.cursor.execute("PRAGMA table_info(source)")
    cols = {row[1]: row for row in db.cursor.fetchall()}
    assert "is_real" in cols, f"is_real column missing; columns: {list(cols)}"
    # PRAGMA table_info row layout: (cid, name, type, notnull, dflt_value, pk)
    assert cols["is_real"][2].upper() == "INTEGER"
    assert cols["is_real"][3] == 1, "is_real must be NOT NULL"
    assert cols["is_real"][4] == "1", "is_real must default to 1"


def test_default_is_real_is_one_when_inserted():
    db = MyDatabase()
    db.init_node_table("source")
    db.add_node("source", id=1, name="root")
    db.cursor.execute("SELECT is_real FROM source WHERE id = ?", (1,))
    assert db.cursor.fetchone()[0] == 1


def test_add_node_with_is_real_false():
    db = MyDatabase()
    db.init_node_table("source")
    db.add_node("source", id=1, name="scaffold", is_real=False)
    db.cursor.execute("SELECT is_real FROM source WHERE id = ?", (1,))
    assert db.cursor.fetchone()[0] == 0


def test_add_node_default_is_real_true():
    db = MyDatabase()
    db.init_node_table("source")
    db.add_node("source", id=1, name="real")
    db.cursor.execute("SELECT is_real FROM source WHERE id = ?", (1,))
    assert db.cursor.fetchone()[0] == 1


def test_get_node_is_real_returns_bool():
    db = MyDatabase()
    db.init_node_table("source")
    db.add_node("source", id=1, name="r")
    db.add_node("source", id=2, name="s", is_real=False)
    assert db.get_node_is_real("source", 1) is True
    assert db.get_node_is_real("source", 2) is False


def test_promote_ancestors_walks_up_relations():
    db = MyDatabase()
    db.init_node_table("source")
    # tree:  1(real) -- 2(fake) -- 3(fake) -- 4(real, just added)
    db.add_node("source", id=1, name="root")
    db.add_node("source", id=2, name="a", is_real=False)
    db.add_node("source", id=3, name="b", is_real=False)
    db.add_node("source", id=4, name="c", is_real=True)
    db.add_relation("source", parent_id=1, child_id=2)
    db.add_relation("source", parent_id=2, child_id=3)
    db.add_relation("source", parent_id=3, child_id=4)
    db._promote_ancestors("source", 4)
    assert db.get_node_is_real("source", 1) is True
    assert db.get_node_is_real("source", 2) is True
    assert db.get_node_is_real("source", 3) is True
    assert db.get_node_is_real("source", 4) is True


def test_promote_ancestors_stops_at_root():
    db = MyDatabase()
    db.init_node_table("source")
    db.add_node("source", id=1, name="root")
    db.add_node("source", id=2, name="x", is_real=False)
    db.add_relation("source", parent_id=1, child_id=2)
    db._promote_ancestors("source", 2)
    assert db.get_node_is_real("source", 1) is True
    assert db.get_node_is_real("source", 2) is False, "starting node itself untouched"


from src.ccltt import CclManager


def test_build_tree_default_is_real_true_and_does_not_demote():
    mgr = CclManager()
    tree = mgr.trees["source"]
    nid = tree.build_tree(parent_id=1, name="x")
    assert mgr.db.get_node_is_real("source", nid) is True


def test_build_tree_with_is_real_false_does_not_promote_parent():
    mgr = CclManager()
    tree = mgr.trees["source"]
    fake_id = tree.build_tree(parent_id=1, name="scaffold", is_real=False)
    assert mgr.db.get_node_is_real("source", fake_id) is False
    # root (id=1) was real, stays real
    assert mgr.db.get_node_is_real("source", 1) is True


def test_build_tree_real_under_fake_promotes_chain():
    mgr = CclManager()
    tree = mgr.trees["source"]
    fake_a = tree.build_tree(parent_id=1, name="a", is_real=False)
    fake_b = tree.build_tree(parent_id=fake_a, name="b", is_real=False)
    real_c = tree.build_tree(parent_id=fake_b, name="c", is_real=True)
    assert mgr.db.get_node_is_real("source", fake_a) is True
    assert mgr.db.get_node_is_real("source", fake_b) is True
    assert mgr.db.get_node_is_real("source", real_c) is True


def test_add_link_promotes_parent_chain_only():
    mgr = CclManager()
    tree = mgr.trees["source"]
    # parent chain has a fake link site; the link target stays whatever it was.
    fake_a = tree.build_tree(parent_id=1, name="a", is_real=False)
    target_real = tree.build_tree(parent_id=1, name="t")
    target_real_under_fake = fake_a    # reuse for clarity in test name
    # Confirm: parent_id=fake_a is fake before linking
    assert mgr.db.get_node_is_real("source", fake_a) is False
    tree.add_link(parent_id=fake_a, child=target_real, alias="link1")
    # parent chain now real
    assert mgr.db.get_node_is_real("source", fake_a) is True
    # link target's is_real untouched
    assert mgr.db.get_node_is_real("source", target_real) is True


def test_node_is_real_accessor():
    mgr = CclManager()
    tree = mgr.trees["source"]
    real_id = tree.build_tree(parent_id=1, name="r")
    fake_id = tree.build_tree(parent_id=1, name="f", is_real=False)
    real_node = tree.nodes[real_id]
    fake_node = tree.nodes[fake_id]
    assert real_node.is_real() is True
    assert fake_node.is_real() is False


def test_nodes_collection_is_real_single_vs_multi():
    mgr = CclManager()
    tree = mgr.trees["source"]
    a = tree.build_tree(parent_id=1, name="a")
    b = tree.build_tree(parent_id=1, name="b", is_real=False)
    from src.ccltt import CclTtNodes
    single = CclTtNodes([tree.nodes[a]])
    multi = CclTtNodes([tree.nodes[a], tree.nodes[b]])
    assert single.is_real() is True
    assert multi.is_real() is None
