from src.ccltt import CclManager
from src.ccltt.input.expansion.engine import _node_type_name, apply
from src.ccltt.input.expansion.rule_loader import Rule


def test_node_type_name_for_singleton():
    mgr = CclManager()
    tree = mgr.trees["source"]
    nid = tree.build_tree(parent_id=1, name="FLOW")
    assert _node_type_name(tree, nid) == "FLOW"


def test_node_type_name_for_typed_instance():
    mgr = CclManager()
    tree = mgr.trees["source"]
    nid = tree.build_tree(parent_id=1, name="Domain 1", ty="DOMAIN")
    assert _node_type_name(tree, nid) == "DOMAIN"


def test_apply_anchors_at_existing_root_child():
    """rule.name picks the anchor (a child of tree.root); YAML content is what to reconcile under it."""
    mgr = CclManager()
    tree = mgr.trees["source"]
    a = tree.build_tree(parent_id=1, name="A")
    tree.build_tree(parent_id=a, name="d1", ty="Domain")
    tree.build_tree(parent_id=a, name="d2", ty="Domain")
    rule = Rule(name="A", expanded={"Domain": {"C": {}}})
    apply(tree, [rule])
    for inst_name in ("d1", "d2"):
        children = tree.find_by_path_with_wildcard(a, f"{inst_name}/*")
        names = [c.name for c in children]
        assert "C" in names
        c = next(c for c in children if c.name == "C")
        assert c.is_real() is False


def test_apply_creates_anchor_when_missing():
    """If the anchor (rule.name) doesn't exist under root, the engine creates it as fake."""
    mgr = CclManager()
    tree = mgr.trees["source"]
    rule = Rule(name="Nope", expanded={"X": {}})
    apply(tree, [rule])
    anchors = tree.find_by_path_with_wildcard(1, "Nope")
    assert len(anchors) == 1
    assert anchors[0].is_real() is False
    nodes = tree.find_by_path_with_wildcard(1, "Nope/X")
    assert len(nodes) == 1
    assert nodes[0].is_real() is False


def test_apply_preserves_existing_attributes():
    mgr = CclManager()
    tree = mgr.trees["source"]
    a = tree.build_tree(parent_id=1, name="A")
    d = tree.build_tree(parent_id=a, name="d1", ty="Domain")
    tree.build_tree(parent_id=d, name="C", ty="int", value="42")
    rule = Rule(name="A", expanded={"Domain": {"C": {"__value__": 99, "__type__": "int"}}})
    apply(tree, [rule])
    c = tree.find_by_path_with_wildcard(d, "C")[0]
    assert c.value() == "42", "existing value must not be overwritten"


def test_apply_is_idempotent():
    mgr = CclManager()
    tree = mgr.trees["source"]
    a = tree.build_tree(parent_id=1, name="A")
    tree.build_tree(parent_id=a, name="d1", ty="Domain")
    rule = Rule(name="A", expanded={"Domain": {"C": {}}})
    apply(tree, [rule])
    apply(tree, [rule])
    children = tree.find_by_path_with_wildcard(a, "d1/*")
    c_count = sum(1 for c in children if c.name == "C")
    assert c_count == 1


def test_apply_adds_value_type_unit_from_reserved_keys():
    mgr = CclManager()
    tree = mgr.trees["source"]
    a = tree.build_tree(parent_id=1, name="A")
    rule = Rule(name="A", expanded={"V": {"__value__": 5, "__type__": "real", "__unit__": "m/s"}})
    apply(tree, [rule])
    v = tree.find_by_path_with_wildcard(a, "V")[0]
    assert v.is_real() is False
    assert str(v.value()) == "5"
    assert v.type() == "real"
    assert v.exprn() == "m/s"


def test_apply_adds_nested_subtree():
    mgr = CclManager()
    tree = mgr.trees["source"]
    a = tree.build_tree(parent_id=1, name="A")
    rule = Rule(name="A", expanded={"E": {"E1": {}, "E2": {"__value__": True, "__type__": "bool"}}})
    apply(tree, [rule])
    e_nodes = tree.find_by_path_with_wildcard(a, "E")
    assert len(e_nodes) == 1
    assert e_nodes[0].is_real() is False
    e1 = tree.find_by_path_with_wildcard(e_nodes[0].node_id, "E1")
    e2 = tree.find_by_path_with_wildcard(e_nodes[0].node_id, "E2")
    assert len(e1) == 1 and e1[0].is_real() is False
    assert len(e2) == 1 and e2[0].is_real() is False
    assert e2[0].type() == "bool"


def test_apply_does_not_demote_existing_real_node():
    mgr = CclManager()
    tree = mgr.trees["source"]
    a = tree.build_tree(parent_id=1, name="A")
    c_real = tree.build_tree(parent_id=a, name="C", ty="int", value="1")
    rule = Rule(name="A", expanded={"C": {}})
    apply(tree, [rule])
    assert mgr.db.get_node_is_real("source", c_real) is True


def test_apply_is_real_true_creates_real_node_and_promotes_ancestors():
    """`__is_real__: true` in YAML => new node is real, ancestor chain auto-promotes."""
    mgr = CclManager()
    tree = mgr.trees["source"]
    rule = Rule(name="A", expanded={"B": {"C": {"__value__": 1, "__type__": "int", "__is_real__": True}}})
    apply(tree, [rule])
    a = tree.find_by_path_with_wildcard(1, "A")[0]
    b = tree.find_by_path_with_wildcard(a.node_id, "B")[0]
    c = tree.find_by_path_with_wildcard(b.node_id, "C")[0]
    assert c.is_real() is True
    # build_tree(..., is_real=True) auto-promotes the parent chain.
    assert a.is_real() is True
    assert b.is_real() is True


def test_apply_is_real_false_explicit_matches_default():
    """`__is_real__: false` is just the default; node stays fake."""
    mgr = CclManager()
    tree = mgr.trees["source"]
    rule = Rule(name="A", expanded={"B": {"__is_real__": False}})
    apply(tree, [rule])
    b = tree.find_by_path_with_wildcard(1, "A/B")[0]
    assert b.is_real() is False


def test_apply_default_is_real_false_when_field_omitted():
    """Backward-compat: rules without `__is_real__` still produce fake nodes."""
    mgr = CclManager()
    tree = mgr.trees["source"]
    rule = Rule(name="A", expanded={"B": {}})
    apply(tree, [rule])
    b = tree.find_by_path_with_wildcard(1, "A/B")[0]
    assert b.is_real() is False
