import pytest
from pathlib import Path
from src.ccltt.input.expansion.rule_loader import load, RuleLoadError


def write(tmp_path: Path, name: str, content: str) -> Path:
    p = tmp_path / name
    p.write_text(content, encoding="utf-8")
    return p


def test_load_returns_empty_list_for_empty_dir(tmp_path):
    assert load(tmp_path) == []


def test_load_returns_expanded_rules_sorted_by_name(tmp_path):
    write(tmp_path, "b_rule.expanded.yaml", "A:\n  X: {}")
    write(tmp_path, "a_rule.expanded.yaml", "B:\n  Y: {}")
    rules = load(tmp_path)
    assert [r.name for r in rules] == ["a_rule", "b_rule"]
    assert rules[0].expanded == {"B": {"Y": {}}}


def test_load_ignores_original_files(tmp_path):
    write(tmp_path, "lonely.original.yaml", "A: {}")
    assert load(tmp_path) == []


def test_load_invalid_yaml_raises(tmp_path):
    write(tmp_path, "bad.expanded.yaml", "A: [unclosed")
    with pytest.raises(RuleLoadError, match="bad.expanded.yaml"):
        load(tmp_path)


def test_load_ignores_unrelated_files(tmp_path):
    write(tmp_path, "README.md", "ignore me")
    write(tmp_path, "ok.expanded.yaml", "A:\n  X: {}")
    rules = load(tmp_path)
    assert len(rules) == 1
    assert rules[0].name == "ok"


def test_load_nonexistent_dir_returns_empty(tmp_path):
    missing = tmp_path / "does_not_exist"
    assert load(missing) == []
