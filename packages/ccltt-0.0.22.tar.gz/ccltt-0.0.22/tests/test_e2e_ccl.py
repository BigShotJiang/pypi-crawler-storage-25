import json
from pathlib import Path

FIXTURES = Path(__file__).parent / "fixtures"


def test_e2e_parse_expand_write(monkeypatch):
    """End-to-end: load CCL → run expansion rule → emit JSON, with and without scaffolding."""
    from src.ccltt.input.ccl import parser as ccl_parser
    monkeypatch.setattr(ccl_parser, "RULES_DIR", FIXTURES)

    mgr = ccl_parser.parse(str(FIXTURES / "e2e_input.ccl"))
    tree = mgr.trees["source"]

    # The new node must exist and be is_real=False.
    nodes = tree.find_by_path_with_wildcard(1, "FLOW/Domain 1/Solver Target Residual")
    assert len(nodes) == 1
    assert nodes[0].is_real() is False
    assert nodes[0].type() == "real"
    assert str(nodes[0].value()) == "1e-05" or str(nodes[0].value()) == "1.0e-05"

    # Default JSON drops scaffolding.
    from src.ccltt.output.json.writer import JsonWriter
    out_default = JsonWriter().write(tree, include_expanded=False, schema="tree")
    assert "solver_target_residual" not in out_default
    assert '"domain_type"' in out_default

    # include_expanded surfaces it.
    out_full = JsonWriter().write(tree, include_expanded=True, schema="tree")
    assert "solver_target_residual" in out_full


def test_e2e_promotion_when_user_writes_under_scaffold(monkeypatch):
    from src.ccltt.input.ccl import parser as ccl_parser
    monkeypatch.setattr(ccl_parser, "RULES_DIR", FIXTURES)
    mgr = ccl_parser.parse(str(FIXTURES / "e2e_input.ccl"))
    tree = mgr.trees["source"]
    # Scaffolded node:
    sentinel = tree.find_by_path_with_wildcard(1, "FLOW/Domain 1/Solver Target Residual")[0]
    # User now writes under it: this should promote the chain.
    tree.build_tree(parent_id=sentinel.node_id, name="UserChild", ty="int", value="1")
    assert sentinel.is_real() is True
