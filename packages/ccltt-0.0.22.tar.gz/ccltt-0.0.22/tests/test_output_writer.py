import json

from src.ccltt import CclManager
from src.ccltt.output.json.writer import JsonWriter
from src.ccltt.output.name_style import to_snake, to_camel


def test_name_style_helpers():
    assert to_snake("Flow Analysis 1") == "flow_analysis_1"
    assert to_snake("MeshImportationParameter") == "mesh_importation_parameter"
    assert to_snake("XMLParser") == "xml_parser"
    assert to_snake("already_snake") == "already_snake"
    assert to_camel("Flow Analysis 1") == "flowAnalysis1"
    assert to_camel("mesh_importation_parameter") == "meshImportationParameter"


def _name_style_tree():
    mgr = CclManager()
    tree = mgr.trees["source"]
    flow = tree.build_tree(parent_id=1, name="Flow Analysis 1", ty="FLOW")
    tree.build_tree(parent_id=flow, name="Domain Type", ty="str", value="Fluid")
    return mgr, tree


def test_json_writer_always_snake_case():
    mgr, tree = _name_style_tree()
    out = JsonWriter().write(tree, schema="tree")
    data = json.loads(out)
    assert data["name"] == "root"
    flow = data["children"][0]
    assert flow["name"] == "flow_analysis_1"
    assert flow["type"] == "FLOW"
    leaf = flow["children"][0]
    assert leaf["name"] == "domain_type"
    assert leaf["value"] == "Fluid"


def test_manager_to_json_round_trip_through_loads():
    mgr, _ = _name_style_tree()
    out = mgr.to_json(schema="tree")
    data = json.loads(out)
    assert data["children"][0]["name"] == "flow_analysis_1"


def test_json_writer_defaults_to_ccl2json_shape():
    mgr, tree = _name_style_tree()
    out = JsonWriter().write(tree)
    data = json.loads(out)
    assert "FLOW" in data
    assert data["FLOW"]["Domain_Type"] == "Fluid"
    assert "name" not in data


def test_ccl2json_uses_underscores_typed_keys_and_si_values():
    mgr = CclManager()
    tree = mgr.trees["source"]
    material = tree.build_tree(parent_id=1, name="Water Liquid", ty="MATERIAL")
    tree.build_tree(parent_id=material, name="Group Description", ty="str", value="Fluid pair A | B")
    tree.build_tree(parent_id=material, name="Length Scale", ty="real", value=25.0, exprn="mm")

    out = json.loads(JsonWriter().write(tree, include_expanded=False))

    assert out["MATERIAL"]["Material_Description"] == "Fluid_pair_A__B"
    assert out["MATERIAL"]["Length_Scale"] == 0.025
