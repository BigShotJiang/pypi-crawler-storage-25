"""Shared test paths.

All test fixture data lives under ``tests/fixtures/`` and any test-time
artifacts should be written to ``tests/outputs/`` (gitignored, kept by
``.gitkeep``). Tests should reference these constants instead of using
filenames relative to the current working directory.
"""

from pathlib import Path

TESTS_DIR = Path(__file__).resolve().parent
FIXTURES_DIR = TESTS_DIR / "fixtures"
INPUTS_DIR = FIXTURES_DIR / "inputs"
OUTPUTS_DIR = TESTS_DIR / "outputs"

OUTPUTS_DIR.mkdir(exist_ok=True)


def fixture(name: str) -> str:
    """Return the absolute path of a test input under ``tests/fixtures/inputs``."""
    return str(INPUTS_DIR / name)


def output(name: str) -> str:
    """Return the absolute path of a test output under ``tests/outputs``."""
    return str(OUTPUTS_DIR / name)
