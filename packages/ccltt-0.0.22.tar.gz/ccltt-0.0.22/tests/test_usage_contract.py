import json

from src.ccltt import CclManager
from src.ccltt.output.json.writer import JsonWriter


def test_documented_add_val_type_inference_and_json_lists():
    mgr = CclManager()
    root = mgr.trees["source"].ROOT()

    root.add("a/d")
    node = root.get("a/d")

    assert node.add_val("d5", [1, 2])
    assert node.add_val("d6", [1.0, 2])
    assert node.add_val("d7", ["left", "right"])

    assert node.get("d5").type() == "int list"
    assert node.get("d6").type() == "real list"
    assert node.get("d7").type() == "str list"

    out = json.loads(mgr.to_json(include_expanded=False))
    assert out["a"]["d"]["d5"] == [1, 2]
    assert out["a"]["d"]["d6"] == [1.0, 2]
    assert out["a"]["d"]["d7"] == ["left", "right"]


def test_documented_subtree_copy_preserves_exprn():
    mgr = CclManager()
    src = mgr.trees["source"]
    tgt = mgr.init_tree("target")

    src_root = src.ROOT()
    src_root.add("a/d")
    src_root.get("a/d").add_val("speed", 12.5)
    src_root.get("a/d/speed").add_exprn("m/s")

    assert tgt.ROOT().add(src_root.get("a/d"))

    copied_speed = tgt.ROOT().get("d/speed")
    assert copied_speed.value() == "12.5"
    assert copied_speed.type() == "real"
    assert copied_speed.nodes[0].exprn() == "m/s"

    out = json.loads(JsonWriter().write(tgt, include_expanded=False))
    assert out["d"]["speed"] == 12.5


def test_single_node_mutators_work_for_find_by_path_results():
    mgr = CclManager()
    tree = mgr.trees["source"]
    root = tree.ROOT()
    root.add("a")
    root.get("a").add_val("count", 1)

    count = tree.find_by_path_with_wildcard(tree.root.node_id, "a/count")[0]
    assert count.retype("real")
    assert count.revalue(1.5)
    assert count.rename("count_new")

    changed = root.get("a/count_new")
    assert changed.type() == "real"
    assert changed.value() == "1.5"
