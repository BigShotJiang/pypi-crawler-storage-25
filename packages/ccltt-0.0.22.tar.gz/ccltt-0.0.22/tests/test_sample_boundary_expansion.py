"""End-to-end tests for builtin expansion against ccl2json CCL samples."""
from pathlib import Path

CCL2JSON_SAMPLE = (
    Path(__file__).resolve().parents[1]
    / "ccl2json"
    / "物理量类型"
    / "CASE2202-cfd-xxxapp-0003-sx.ccl"
)


def test_sample_boundary_expansion_adds_default_boundary_conditions():
    from src.ccltt.input.ccl import parser as ccl_parser

    mgr = ccl_parser.parse(str(CCL2JSON_SAMPLE))
    tree = mgr.trees["source"]

    # LOCAL_INITIAL_CONDITIONS is __is_real__: false in YAML but auto-promoted to
    # real by Local_Init_1 (which is __is_real__: true).
    local_init = tree.find_by_path_with_wildcard(1, "FLOW/*/INITIALISATION/LOCAL_INITIAL_CONDITIONS")
    assert local_init
    assert all(node.is_real() is True for node in local_init)

    cartesian_u = tree.find_by_path_with_wildcard(
        1,
        "FLOW/*/INITIALISATION/LOCAL_INITIAL_CONDITIONS/"
        "CARTESIAN_VELOCITY_COMPONENTS/Local_Init_1/U_value",
    )
    assert cartesian_u
    assert all(node.is_real() is True for node in cartesian_u)
    assert all(node.type() == "real" and str(node.value()) == "1.0" for node in cartesian_u)

    # Sibling Local_Init_2 stays fake (explicit __is_real__: false in YAML).
    local_init_2 = tree.find_by_path_with_wildcard(
        1,
        "FLOW/*/INITIALISATION/LOCAL_INITIAL_CONDITIONS/"
        "CARTESIAN_VELOCITY_COMPONENTS/Local_Init_2",
    )
    assert local_init_2
    assert all(node.is_real() is False for node in local_init_2)

    residual_target = tree.find_by_path_with_wildcard(
        1,
        "FLOW/SOLVER_CONTROL/EQUATION_GROUPS_RESIDUAL_SETTINGS/MOMENTUM/Residual_Target",
    )
    assert len(residual_target) == 1
    assert residual_target[0].is_real() is True
    assert residual_target[0].type() == "real"
    assert str(residual_target[0].value()) == "0.0001"


def test_sample_boundary_json_writer_hides_scaffolding_by_default():
    from src.ccltt.input.ccl import parser as ccl_parser
    from src.ccltt.output.json.writer import JsonWriter

    mgr = ccl_parser.parse(str(CCL2JSON_SAMPLE))
    tree = mgr.trees["source"]

    out_default = JsonWriter().write(tree, include_expanded=False, schema="tree")
    # UserDefinedRegion subtree is fully scaffolded (false), so nothing leaks.
    assert "user_defined_region" not in out_default
    # Local_Init_2 is explicit false, so it stays hidden even though
    # LOCAL_INITIAL_CONDITIONS/CARTESIAN_VELOCITY_COMPONENTS are promoted.
    assert '"local_init_2"' not in out_default
    # Real-or-promoted scaffolding does surface:
    assert "local_initial_conditions" in out_default
    assert "equation_groups_residual_settings" in out_default

    out_full = JsonWriter().write(tree, include_expanded=True, schema="tree")
    assert "user_defined_region" in out_full
    assert "local_init_2" in out_full
    assert "residual_target" in out_full


def test_sample_boundary_json_writer_ccl2json_shape_includes_defaults():
    import json
    from src.ccltt.input.ccl import parser as ccl_parser
    from src.ccltt.output.json.writer import JsonWriter

    mgr = ccl_parser.parse(str(CCL2JSON_SAMPLE))
    tree = mgr.trees["source"]

    data = json.loads(JsonWriter().write(tree))
    assert "FLOW" in data
    flow = data["FLOW"]
    assert "SOLVER_CONTROL" in flow
    assert flow["SOLVER_CONTROL"]["EQUATION_GROUPS_RESIDUAL_SETTINGS"]["MOMENTUM"][
        "Residual_Target"
    ] == 0.0001
    assert flow["SOLVER_CONTROL"]["EQUATION_GROUPS_RESIDUAL_SETTINGS"]["MOMENTUM"][
        "expand_setting"
    ]["max_residual_target"] == 0.1
    assert "LIBRARY" in data
    assert "UserDefinedRegion" in data["LIBRARY"]
