# CclTt 三层架构重构 实施计划

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 把 `src/ccltt/` 重构为 input / transform / output 三层架构，加 `is_real` 字段与自动晋升，落地 YAML 成对的扩充规则引擎；旧测试在每一步都保持全绿。

**Architecture:** 在现有 `MyDatabase` / `CclTtTree` / `CclTtNode` / `CclTtNodes` 基础上**渐进迁移**：先扩 schema、加新模块、保留旧 API 作为 thin wrapper，最后清理。扩充引擎绑定到各 input format 的 `rules/` 子目录，由 parser 在解析后调用。

**Tech Stack:** Python 3.8+，sqlite3（in-memory），PyYAML，pytest。

**Spec:** [docs/superpowers/specs/2026-05-08-ccltt-three-layer-architecture-design.md](../specs/2026-05-08-ccltt-three-layer-architecture-design.md)

---

## File Structure

**Files to create**:

```
src/ccltt/
  core/                          # (Task 7)
    __init__.py                  # re-export from old modules during transition
  input/                         # (Task 7)
    __init__.py
    base.py                      # (Task 10) Parser ABC
    ccl/
      __init__.py                # (Task 7)
      parser.py                  # (Task 10)
      rules/
        __init__.py              # (Task 7) empty package marker
    json/
      __init__.py                # (Task 7)
      parser.py                  # (Task 11)
      rules/
        __init__.py              # (Task 7)
    expansion/
      __init__.py                # (Task 7)
      rule_loader.py             # (Task 12)
      engine.py                  # (Task 13/14)
  transform/                     # (Task 7)
    __init__.py
    operations.py                # (Task 17)
  output/                        # (Task 7)
    __init__.py
    base.py                      # (Task 8) Writer ABC
    ccl/
      __init__.py                # (Task 7)
      writer.py                  # (Task 8)
    debug/
      __init__.py                # (Task 7)
      printer.py                 # (Task 9)
  manager.py                     # (Task 18) new CclManager

tests/
  test_is_real.py                # (Task 1-6 progressively)
  test_output_writer.py          # (Task 8-9)
  test_input_parser.py           # (Task 10-11)
  test_expansion_loader.py       # (Task 12)
  test_expansion_engine.py       # (Task 13-14)
  test_e2e_ccl.py                # (Task 19)
```

**Files to modify (during transition; deleted in Task 20)**:
- `src/ccltt/data_base.py` — Tasks 1, 2, 3
- `src/ccltt/ccl_tt_tree.py` — Tasks 4, 5
- `src/ccltt/ccl_tt_node.py` — Tasks 6, 17
- `src/ccltt/ccl_manager.py` — Tasks 10, 11, 18
- `src/ccltt/__init__.py` — Tasks 7, 18, 20
- `pyproject.toml` — Task 0

**Files moved/renamed (Task 20)**:
- `src/ccltt/data_base.py` → `src/ccltt/core/database.py`
- `src/ccltt/ccl_tt_tree.py` → `src/ccltt/core/tree.py`
- `src/ccltt/ccl_tt_node.py` → `src/ccltt/core/node.py`
- `src/ccltt/ccl_manager.py` → `src/ccltt/_legacy_parsers.py` (private internal; not re-exported by name)

---

## Workflow conventions

- **Working directory**: `/Users/zhangyang/Code/Doml/CclTt`
- **Tests run from repo root**: `pytest tests/ -v`
- **Each task ends with**: run all tests, verify green, commit.
- **Commit messages** use Conventional Commits: `feat`, `refactor`, `test`, `chore`, `docs`. Scope is the module touched.
- **Dependency**: PyYAML — added in Task 0.

---

## Task 0: Add PyYAML dependency

**Files:**
- Modify: `pyproject.toml`

- [ ] **Step 1: Add PyYAML to dependencies**

Edit `pyproject.toml` line 27 (the empty `dependencies = []`):

```toml
dependencies = [
    "PyYAML>=6.0",
]
```

- [ ] **Step 2: Verify import works**

Run: `python3 -c "import yaml; print(yaml.__version__)"`
Expected: prints a version number (e.g. `6.0.3`); no `ModuleNotFoundError`.

- [ ] **Step 3: Run baseline tests**

Run: `pytest tests/ -v`
Expected: all existing tests pass (the count and names from `tests/test_initial.py` should match the pre-change baseline).

- [ ] **Step 4: Commit**

```bash
git add pyproject.toml
git commit -m "chore: declare PyYAML dependency for upcoming expansion engine"
```

---

## Task 1: Schema — add `is_real` column

**Files:**
- Modify: `src/ccltt/data_base.py`
- Test: `tests/test_is_real.py` (create)

- [ ] **Step 1: Write the failing test**

Create `tests/test_is_real.py`:

```python
from src.ccltt.data_base import MyDatabase


def test_node_table_has_is_real_column():
    db = MyDatabase()
    db.init_node_table("source")
    db.cursor.execute("PRAGMA table_info(source)")
    cols = {row[1]: row for row in db.cursor.fetchall()}
    assert "is_real" in cols, f"is_real column missing; columns: {list(cols)}"
    # PRAGMA table_info row layout: (cid, name, type, notnull, dflt_value, pk)
    assert cols["is_real"][2].upper() == "INTEGER"
    assert cols["is_real"][3] == 1, "is_real must be NOT NULL"
    assert cols["is_real"][4] == "1", "is_real must default to 1"


def test_default_is_real_is_one_when_inserted():
    db = MyDatabase()
    db.init_node_table("source")
    db.add_node("source", id=1, name="root")
    db.cursor.execute("SELECT is_real FROM source WHERE id = ?", (1,))
    assert db.cursor.fetchone()[0] == 1
```

- [ ] **Step 2: Run test to verify it fails**

Run: `pytest tests/test_is_real.py -v`
Expected: FAIL on `is_real column missing`.

- [ ] **Step 3: Modify `init_node_table`**

In `src/ccltt/data_base.py`, replace the SQL inside `init_node_table` (currently around lines 27–35) with:

```python
        sql = f'''
        CREATE TABLE IF NOT EXISTS {name} (
            id INTEGER PRIMARY KEY,
            node_name TEXT NOT NULL,
            node_type TEXT,
            node_value TEXT,
            node_exprn TEXT,
            is_real INTEGER NOT NULL DEFAULT 1
        )
        '''
```

- [ ] **Step 4: Run test to verify it passes**

Run: `pytest tests/test_is_real.py -v`
Expected: both tests PASS.

- [ ] **Step 5: Run full suite to confirm no regression**

Run: `pytest tests/ -v`
Expected: all tests pass.

- [ ] **Step 6: Commit**

```bash
git add src/ccltt/data_base.py tests/test_is_real.py
git commit -m "feat(db): add is_real column to per-tree node tables"
```

---

## Task 2: Plumb `is_real` through `add_node`

**Files:**
- Modify: `src/ccltt/data_base.py`
- Modify: `tests/test_is_real.py`

- [ ] **Step 1: Write the failing test**

Append to `tests/test_is_real.py`:

```python
def test_add_node_with_is_real_false():
    db = MyDatabase()
    db.init_node_table("source")
    db.add_node("source", id=1, name="scaffold", is_real=False)
    db.cursor.execute("SELECT is_real FROM source WHERE id = ?", (1,))
    assert db.cursor.fetchone()[0] == 0


def test_add_node_default_is_real_true():
    db = MyDatabase()
    db.init_node_table("source")
    db.add_node("source", id=1, name="real")
    db.cursor.execute("SELECT is_real FROM source WHERE id = ?", (1,))
    assert db.cursor.fetchone()[0] == 1
```

- [ ] **Step 2: Run test to verify it fails**

Run: `pytest tests/test_is_real.py::test_add_node_with_is_real_false -v`
Expected: FAIL with `TypeError: add_node() got an unexpected keyword argument 'is_real'`.

- [ ] **Step 3: Add `is_real` parameter to `add_node`**

In `src/ccltt/data_base.py`, replace the body of `add_node` (currently around lines 68–80) with:

```python
    def add_node(self, table_name, id, name, ty=None, value=None, is_real=True):
        if not table_name.isidentifier():
            raise ValueError(f"非法的表名: {table_name}")

        if isinstance(value, (list, dict)):
            value = json.dumps(value)

        insert_sql = f'''
        INSERT INTO {table_name} (id, node_name, node_type, node_value, is_real)
        VALUES (?, ?, ?, ?, ?)
        '''
        self.cursor.execute(insert_sql, (id, name, ty, value, 1 if is_real else 0))
        self.conn.commit()
```

- [ ] **Step 4: Run test to verify it passes**

Run: `pytest tests/test_is_real.py -v`
Expected: all 4 tests PASS.

- [ ] **Step 5: Full suite still green**

Run: `pytest tests/ -v`
Expected: all tests pass (existing callers use default `is_real=True`).

- [ ] **Step 6: Commit**

```bash
git add src/ccltt/data_base.py tests/test_is_real.py
git commit -m "feat(db): accept is_real parameter in add_node"
```

---

## Task 3: Add `_promote_ancestors` helper + `get_node_is_real`

**Files:**
- Modify: `src/ccltt/data_base.py`
- Modify: `tests/test_is_real.py`

- [ ] **Step 1: Write the failing test**

Append to `tests/test_is_real.py`:

```python
def test_get_node_is_real_returns_bool():
    db = MyDatabase()
    db.init_node_table("source")
    db.add_node("source", id=1, name="r")
    db.add_node("source", id=2, name="s", is_real=False)
    assert db.get_node_is_real("source", 1) is True
    assert db.get_node_is_real("source", 2) is False


def test_promote_ancestors_walks_up_relations():
    db = MyDatabase()
    db.init_node_table("source")
    # tree:  1(real) -- 2(fake) -- 3(fake) -- 4(real, just added)
    db.add_node("source", id=1, name="root")
    db.add_node("source", id=2, name="a", is_real=False)
    db.add_node("source", id=3, name="b", is_real=False)
    db.add_node("source", id=4, name="c", is_real=True)
    db.add_relation("source", parent_id=1, child_id=2)
    db.add_relation("source", parent_id=2, child_id=3)
    db.add_relation("source", parent_id=3, child_id=4)
    db._promote_ancestors("source", 4)
    assert db.get_node_is_real("source", 1) is True
    assert db.get_node_is_real("source", 2) is True
    assert db.get_node_is_real("source", 3) is True
    assert db.get_node_is_real("source", 4) is True


def test_promote_ancestors_stops_at_root():
    db = MyDatabase()
    db.init_node_table("source")
    db.add_node("source", id=1, name="root")
    db.add_node("source", id=2, name="x", is_real=False)
    db.add_relation("source", parent_id=1, child_id=2)
    db._promote_ancestors("source", 2)
    assert db.get_node_is_real("source", 1) is True
    assert db.get_node_is_real("source", 2) is False, "starting node itself untouched"
```

- [ ] **Step 2: Run test to verify it fails**

Run: `pytest tests/test_is_real.py -v -k "promote or get_node_is_real"`
Expected: FAIL on `AttributeError: 'MyDatabase' object has no attribute 'get_node_is_real'`.

- [ ] **Step 3: Implement `get_node_is_real` and `_promote_ancestors`**

Append to `src/ccltt/data_base.py` (inside `MyDatabase`, before `close`):

```python
    def get_node_is_real(self, table_name, node_id):
        if not table_name.isidentifier():
            raise ValueError(f"非法的表名: {table_name}")
        select_sql = f'SELECT is_real FROM {table_name} WHERE id = ?'
        self.cursor.execute(select_sql, (node_id,))
        row = self.cursor.fetchone()
        if row is None:
            return None
        return bool(row[0])

    def _promote_ancestors(self, tree_name, node_id):
        """从 node_id 的 parent 开始向上把 is_real=0 改为 1，直到根。
        本节点自身不修改（语义：'我加了一个真节点，祖先链都应是真的'）。"""
        if not tree_name.isidentifier():
            raise ValueError(f"非法的表名: {tree_name}")
        current = node_id
        while True:
            self.cursor.execute(
                'SELECT parent_id FROM relations WHERE tree_name = ? AND child_id = ? AND relation_type = ?',
                (tree_name, current, 'normal'),
            )
            row = self.cursor.fetchone()
            if row is None:
                break  # 到根了
            parent_id = row[0]
            update_sql = f'UPDATE {tree_name} SET is_real = 1 WHERE id = ? AND is_real = 0'
            self.cursor.execute(update_sql, (parent_id,))
            current = parent_id
        self.conn.commit()
```

- [ ] **Step 4: Run test to verify it passes**

Run: `pytest tests/test_is_real.py -v`
Expected: all tests PASS.

- [ ] **Step 5: Full suite still green**

Run: `pytest tests/ -v`
Expected: all tests pass.

- [ ] **Step 6: Commit**

```bash
git add src/ccltt/data_base.py tests/test_is_real.py
git commit -m "feat(db): add get_node_is_real and _promote_ancestors helper"
```

---

## Task 4: Auto-promote in `CclTtTree.build_tree`

**Files:**
- Modify: `src/ccltt/ccl_tt_tree.py`
- Modify: `tests/test_is_real.py`

- [ ] **Step 1: Write the failing test**

Append to `tests/test_is_real.py`:

```python
from src.ccltt import CclManager


def test_build_tree_default_is_real_true_and_does_not_demote():
    mgr = CclManager()
    tree = mgr.trees["source"]
    nid = tree.build_tree(parent_id=1, name="x")
    assert mgr.db.get_node_is_real("source", nid) is True


def test_build_tree_with_is_real_false_does_not_promote_parent():
    mgr = CclManager()
    tree = mgr.trees["source"]
    fake_id = tree.build_tree(parent_id=1, name="scaffold", is_real=False)
    assert mgr.db.get_node_is_real("source", fake_id) is False
    # root (id=1) was real, stays real
    assert mgr.db.get_node_is_real("source", 1) is True


def test_build_tree_real_under_fake_promotes_chain():
    mgr = CclManager()
    tree = mgr.trees["source"]
    fake_a = tree.build_tree(parent_id=1, name="a", is_real=False)
    fake_b = tree.build_tree(parent_id=fake_a, name="b", is_real=False)
    real_c = tree.build_tree(parent_id=fake_b, name="c", is_real=True)
    assert mgr.db.get_node_is_real("source", fake_a) is True
    assert mgr.db.get_node_is_real("source", fake_b) is True
    assert mgr.db.get_node_is_real("source", real_c) is True
```

- [ ] **Step 2: Run test to verify it fails**

Run: `pytest tests/test_is_real.py -v -k "build_tree"`
Expected: FAIL on `TypeError: build_tree() got an unexpected keyword argument 'is_real'`.

- [ ] **Step 3: Update `build_tree` signature and call site**

Replace `build_tree` in `src/ccltt/ccl_tt_tree.py` (currently around lines 25–33):

```python
    def build_tree(self, parent_id, name, ty=None, value=None, is_real=True):
        self.node_id_counter += 1
        node = CclTtNode(self, node_id=self.node_id_counter, name=name)
        self.nodes[self.node_id_counter] = node

        self.db.add_node(self.name, node.node_id, node.name, ty, value, is_real=is_real)
        self.db.add_relation(self.name, parent_id, node.node_id)

        if is_real:
            self.db._promote_ancestors(self.name, node.node_id)

        return node.node_id
```

- [ ] **Step 4: Run test to verify it passes**

Run: `pytest tests/test_is_real.py -v`
Expected: all tests PASS.

- [ ] **Step 5: Full suite still green**

Run: `pytest tests/ -v`
Expected: all tests pass.

- [ ] **Step 6: Commit**

```bash
git add src/ccltt/ccl_tt_tree.py tests/test_is_real.py
git commit -m "feat(core): auto-promote ancestor chain when build_tree adds a real node"
```

---

## Task 5: Auto-promote in `CclTtTree.add_link`

**Files:**
- Modify: `src/ccltt/ccl_tt_tree.py`
- Modify: `tests/test_is_real.py`

- [ ] **Step 1: Write the failing test**

Append to `tests/test_is_real.py`:

```python
def test_add_link_promotes_parent_chain_only():
    mgr = CclManager()
    tree = mgr.trees["source"]
    # parent chain has a fake link site; the link target stays whatever it was.
    fake_a = tree.build_tree(parent_id=1, name="a", is_real=False)
    target_real = tree.build_tree(parent_id=1, name="t")
    target_real_under_fake = fake_a    # reuse for clarity in test name
    # Confirm: parent_id=fake_a is fake before linking
    assert mgr.db.get_node_is_real("source", fake_a) is False
    tree.add_link(parent_id=fake_a, child=target_real, alias="link1")
    # parent chain now real
    assert mgr.db.get_node_is_real("source", fake_a) is True
    # link target's is_real untouched
    assert mgr.db.get_node_is_real("source", target_real) is True
```

- [ ] **Step 2: Run test to verify it fails**

Run: `pytest tests/test_is_real.py::test_add_link_promotes_parent_chain_only -v`
Expected: FAIL — `fake_a` would still be False because `add_link` doesn't promote yet.

- [ ] **Step 3: Update `add_link` to promote parent chain**

Replace the body of `add_link` in `src/ccltt/ccl_tt_tree.py` (around lines 104–113):

```python
    def add_link(self, parent_id: int, child: int, alias: str | None) -> 'CclTtNode':
        now = CclTtNode(self, node_id=parent_id)
        if now.type() is not None and now.value() is not None:
            return False
        node = self.db.find_child_by_name(self.name, self.name, parent_id, alias)
        if node is not None:
            return False
        self.db.add_link(self.name, parent_id, child, alias)
        # adding a link is an explicit user action -> promote parent chain
        self.db._promote_ancestors(self.name, parent_id)
        # also make sure parent_id itself is real (the helper only walks above it)
        self.db.cursor.execute(
            f'UPDATE {self.name} SET is_real = 1 WHERE id = ? AND is_real = 0',
            (parent_id,),
        )
        self.db.conn.commit()
        return True
```

- [ ] **Step 4: Run test to verify it passes**

Run: `pytest tests/test_is_real.py -v`
Expected: all tests PASS.

- [ ] **Step 5: Full suite still green**

Run: `pytest tests/ -v`
Expected: all tests pass.

- [ ] **Step 6: Commit**

```bash
git add src/ccltt/ccl_tt_tree.py tests/test_is_real.py
git commit -m "feat(core): auto-promote parent chain on add_link"
```

---

## Task 6: Add `is_real()` accessor on `CclTtNode` / `CclTtNodes`

**Files:**
- Modify: `src/ccltt/ccl_tt_node.py`
- Modify: `tests/test_is_real.py`

- [ ] **Step 1: Write the failing test**

Append to `tests/test_is_real.py`:

```python
def test_node_is_real_accessor():
    mgr = CclManager()
    tree = mgr.trees["source"]
    real_id = tree.build_tree(parent_id=1, name="r")
    fake_id = tree.build_tree(parent_id=1, name="f", is_real=False)
    real_node = tree.nodes[real_id]
    fake_node = tree.nodes[fake_id]
    assert real_node.is_real() is True
    assert fake_node.is_real() is False


def test_nodes_collection_is_real_single_vs_multi():
    mgr = CclManager()
    tree = mgr.trees["source"]
    a = tree.build_tree(parent_id=1, name="a")
    b = tree.build_tree(parent_id=1, name="b", is_real=False)
    from src.ccltt.core import CclTtNodes
    single = CclTtNodes([tree.nodes[a]])
    multi = CclTtNodes([tree.nodes[a], tree.nodes[b]])
    assert single.is_real() is True
    assert multi.is_real() is None
```

- [ ] **Step 2: Run test to verify it fails**

Run: `pytest tests/test_is_real.py -v -k "is_real_accessor or collection_is_real"`
Expected: FAIL with `AttributeError: 'CclTtNode' object has no attribute 'is_real'`.

- [ ] **Step 3: Add `is_real()` to both classes**

In `src/ccltt/ccl_tt_node.py`, append a method to `CclTtNode` (after the `exprn` method, around line 33):

```python
    def is_real(self):
        return self.tree.db.get_node_is_real(self.tree.name, self.node_id)
```

Append to `CclTtNodes` (after `type`, around line 124):

```python
    def is_real(self):
        if len(self.nodes) != 1:
            return None
        return self.nodes[0].is_real()
```

- [ ] **Step 4: Run test to verify it passes**

Run: `pytest tests/test_is_real.py -v`
Expected: all tests PASS.

- [ ] **Step 5: Full suite still green**

Run: `pytest tests/ -v`
Expected: all tests pass.

- [ ] **Step 6: Commit**

```bash
git add src/ccltt/ccl_tt_node.py tests/test_is_real.py
git commit -m "feat(core): expose is_real() accessor on CclTtNode and CclTtNodes"
```

---

## Task 7: Create three-layer directory skeleton

**Files:**
- Create: `src/ccltt/core/__init__.py`
- Create: `src/ccltt/input/__init__.py`
- Create: `src/ccltt/input/ccl/__init__.py`
- Create: `src/ccltt/input/ccl/rules/__init__.py`
- Create: `src/ccltt/input/json/__init__.py`
- Create: `src/ccltt/input/json/rules/__init__.py`
- Create: `src/ccltt/input/expansion/__init__.py`
- Create: `src/ccltt/transform/__init__.py`
- Create: `src/ccltt/output/__init__.py`
- Create: `src/ccltt/output/ccl/__init__.py`
- Create: `src/ccltt/output/debug/__init__.py`

- [ ] **Step 1: Create `core/__init__.py` re-exporting old modules**

```python
"""Core data structures (tree / node / database).

During migration this re-exports from the legacy module locations.
After Task 20 the actual implementations live here.
"""
from ..ccl_tt_tree import CclTtTree
from ..ccl_tt_node import CclTtNode, CclTtNodes, format_values
from ..data_base import MyDatabase

__all__ = ["CclTtTree", "CclTtNode", "CclTtNodes", "MyDatabase", "format_values"]
```

- [ ] **Step 2: Create the other empty package markers**

For each of the following paths, create a file with the single line `"""Package marker."""`:

- `src/ccltt/input/__init__.py`
- `src/ccltt/input/ccl/__init__.py`
- `src/ccltt/input/ccl/rules/__init__.py`
- `src/ccltt/input/json/__init__.py`
- `src/ccltt/input/json/rules/__init__.py`
- `src/ccltt/input/expansion/__init__.py`
- `src/ccltt/transform/__init__.py`
- `src/ccltt/output/__init__.py`
- `src/ccltt/output/ccl/__init__.py`
- `src/ccltt/output/debug/__init__.py`

- [ ] **Step 3: Smoke-import the new packages**

Run: `python3 -c "from src.ccltt.core import CclTtTree, CclTtNode, MyDatabase; from src.ccltt import input, transform, output; print('ok')"`
Expected: prints `ok`.

- [ ] **Step 4: Full suite still green**

Run: `pytest tests/ -v`
Expected: all tests pass.

- [ ] **Step 5: Commit**

```bash
git add src/ccltt/core src/ccltt/input src/ccltt/transform src/ccltt/output
git commit -m "refactor: scaffold core/input/transform/output packages with re-exports"
```

---

## Task 8: Output base + CCL writer

**Files:**
- Create: `src/ccltt/output/base.py`
- Create: `src/ccltt/output/ccl/writer.py`
- Create: `tests/test_output_writer.py`

- [ ] **Step 1: Write the failing test**

Create `tests/test_output_writer.py`:

```python
from src.ccltt import CclManager
from src.ccltt.output.ccl.writer import CclWriter


def _build_tree_with_real_and_fake():
    mgr = CclManager()
    tree = mgr.trees["source"]
    # real chain: root -> A -> B (with value)
    a = tree.build_tree(parent_id=1, name="A")
    tree.build_tree(parent_id=a, name="B", ty="int", value="5")
    # fake sibling: root -> Scaffold (is_real=False, no real descendants)
    tree.build_tree(parent_id=1, name="Scaffold", is_real=False)
    return mgr, tree


def test_ccl_writer_default_filters_fake_subtrees():
    mgr, tree = _build_tree_with_real_and_fake()
    out = CclWriter().write(tree)
    assert "A" in out
    assert "B = 5" in out
    assert "Scaffold" not in out


def test_ccl_writer_include_expanded_keeps_fake_nodes():
    mgr, tree = _build_tree_with_real_and_fake()
    out = CclWriter().write(tree, include_expanded=True)
    assert "Scaffold" in out


def test_ccl_writer_byte_equal_to_legacy_transfrom_when_all_real():
    """When the tree has no fake nodes, new writer must match legacy transfrom() output."""
    mgr = CclManager()
    tree = mgr.trees["source"]
    a = tree.build_tree(parent_id=1, name="A")
    tree.build_tree(parent_id=a, name="B", ty="int", value="5")
    legacy = tree.ROOT().transfrom()
    new = CclWriter().write(tree)
    assert new == legacy
```

- [ ] **Step 2: Run test to verify it fails**

Run: `pytest tests/test_output_writer.py -v`
Expected: FAIL with `ModuleNotFoundError: No module named 'src.ccltt.output.ccl.writer'`.

- [ ] **Step 3: Implement Writer ABC**

Create `src/ccltt/output/base.py`:

```python
"""Writer abstract interface."""
from abc import ABC, abstractmethod
from ..core import CclTtTree


class Writer(ABC):
    @abstractmethod
    def write(self, tree: CclTtTree, include_expanded: bool = False) -> str:
        """Serialize the tree. By default skip is_real=False subtrees."""
```

- [ ] **Step 4: Implement CclWriter**

Create `src/ccltt/output/ccl/writer.py`:

```python
"""CCL writer — round-trips a tree back to CCL text."""
from ..base import Writer
from ...core import CclTtTree
from ...core import format_values


class CclWriter(Writer):
    def write(self, tree: CclTtTree, include_expanded: bool = False) -> str:
        return self._write_node(tree.root, indent="", include_expanded=include_expanded)

    def _write_node(self, node, indent: str, include_expanded: bool) -> str:
        if not include_expanded and not node.is_real():
            return ""
        ans = indent + node.name
        # leaf with value -> "name = value[unit]"
        if node.value() is not None and node.type() is not None:
            ans += " = "
            value = '"' + node.value() + '"' if node.type() == "str" else node.value()
            exprn = node.exprn()
            if exprn is not None:
                ans += format_values(exprn, value)
            else:
                ans += str(value)
            return ans
        # container -> "name\n{ children }"
        ans += "\n" + indent + "{"
        children = node.tree.find_by_path_with_wildcard(node.node_id, "*")
        for child in children:
            piece = self._write_node(child, indent + "    ", include_expanded)
            if piece:
                ans += "\n" + piece
        ans += "\n" + indent + "}"
        return ans
```

- [ ] **Step 5: Run test to verify it passes**

Run: `pytest tests/test_output_writer.py -v`
Expected: all 3 tests PASS.

- [ ] **Step 6: Full suite still green**

Run: `pytest tests/ -v`
Expected: all tests pass.

- [ ] **Step 7: Snapshot regression check**

Run all `test_build_from_ccl_*` tests and verify the corresponding `*_output.txt` files are unchanged (legacy `transfrom()` is still in use; new writer is parallel, not yet replacing). Run:

```bash
pytest tests/test_initial.py -v -k "build_from_ccl"
git status        # *_output.txt files should not appear modified relative to HEAD
```

Expected: all build_from_ccl tests pass; `git status` shows no diff in `*_output.txt`.

- [ ] **Step 8: Commit**

```bash
git add src/ccltt/output tests/test_output_writer.py
git commit -m "feat(output): add CclWriter with is_real filtering"
```

---

## Task 9: Output debug printer

**Files:**
- Create: `src/ccltt/output/debug/printer.py`
- Modify: `tests/test_output_writer.py`

- [ ] **Step 1: Write the failing test**

Append to `tests/test_output_writer.py`:

```python
from src.ccltt.output.debug.printer import DebugPrinter


def test_debug_printer_includes_expanded_marker():
    mgr = CclManager()
    tree = mgr.trees["source"]
    a = tree.build_tree(parent_id=1, name="A")
    tree.build_tree(parent_id=a, name="B", is_real=False)  # fake leaf
    out = DebugPrinter().write(tree)
    assert "A" in out
    assert "B" in out
    assert "[expanded]" in out


def test_debug_printer_no_marker_for_real_nodes():
    mgr = CclManager()
    tree = mgr.trees["source"]
    a = tree.build_tree(parent_id=1, name="A")
    tree.build_tree(parent_id=a, name="B", ty="int", value="5")
    out = DebugPrinter().write(tree)
    assert "[expanded]" not in out
```

- [ ] **Step 2: Run test to verify it fails**

Run: `pytest tests/test_output_writer.py -v -k "debug"`
Expected: FAIL with `ModuleNotFoundError`.

- [ ] **Step 3: Implement DebugPrinter**

Create `src/ccltt/output/debug/printer.py`:

```python
"""Debug printer — tree-shape view with [expanded] markers."""
from ..base import Writer
from ...core import CclTtTree
from ...core import format_values


class DebugPrinter(Writer):
    def write(self, tree: CclTtTree, include_expanded: bool = True) -> str:
        # Default for debug is to show everything.
        return self._print_node(tree.root, indent="", include_expanded=include_expanded)

    def _print_node(self, node, indent: str, include_expanded: bool) -> str:
        if not include_expanded and not node.is_real():
            return ""
        ans = indent + node.name
        if not node.is_real():
            ans += " [expanded]"
        cnt = 0
        if node.type():
            ans += " : " + node.type()
            cnt = 1
        if node.value() is not None:
            ans += " = "
            value = '"' + node.value() + '"' if node.type() == "str" else node.value()
            exprn = node.exprn()
            if exprn is not None:
                ans += format_values(exprn, value)
            else:
                ans += str(value)
            cnt = 1
        if cnt == 1:
            return ans
        children = node.tree.find_by_path_with_wildcard(node.node_id, "*")
        if children:
            ans += "\n" + indent + "children :"
            for child in children:
                piece = self._print_node(child, indent + "    ", include_expanded)
                if piece:
                    ans += "\n" + piece
        return ans
```

- [ ] **Step 4: Run test to verify it passes**

Run: `pytest tests/test_output_writer.py -v`
Expected: all tests PASS.

- [ ] **Step 5: Full suite still green**

Run: `pytest tests/ -v`
Expected: all tests pass.

- [ ] **Step 6: Commit**

```bash
git add src/ccltt/output/debug tests/test_output_writer.py
git commit -m "feat(output): add DebugPrinter with [expanded] markers"
```

---

## Task 10: Input base + CCL parser migration

**Files:**
- Create: `src/ccltt/input/base.py`
- Create: `src/ccltt/input/ccl/parser.py`
- Create: `tests/test_input_parser.py`

- [ ] **Step 1: Write the failing test**

Create `tests/test_input_parser.py`:

```python
from src.ccltt.input.ccl.parser import parse as parse_ccl
from src.ccltt import build_tree_from_ccl


def test_parse_ccl_matches_legacy_build_tree_from_ccl():
    legacy = build_tree_from_ccl("VMFL047.ccl")
    new = parse_ccl("VMFL047.ccl")
    legacy_out = legacy.trees["source"].ROOT().transfrom()
    new_out = new.trees["source"].ROOT().transfrom()
    assert legacy_out == new_out


def test_parse_ccl_returns_manager_with_source_tree():
    mgr = parse_ccl("VMFL047.ccl")
    assert "source" in mgr.trees
    root = mgr.trees["source"].ROOT()
    assert root.name() == "root"
```

- [ ] **Step 2: Run test to verify it fails**

Run: `pytest tests/test_input_parser.py -v`
Expected: FAIL with `ModuleNotFoundError: No module named 'src.ccltt.input.ccl.parser'`.

- [ ] **Step 3: Create Parser ABC**

Create `src/ccltt/input/base.py`:

```python
"""Parser abstract interface."""
from abc import ABC, abstractmethod


class Parser(ABC):
    @abstractmethod
    def parse(self, path: str):
        """Parse `path` and return a CclManager-like object with at least `trees['source']`."""
```

- [ ] **Step 4: Implement CCL parser as a thin wrapper**

Create `src/ccltt/input/ccl/parser.py`:

```python
"""CCL parser — wraps the legacy build_tree_from_ccl during migration.

Until Task 15 wires the expansion engine in, this is a pure delegation."""
from pathlib import Path
from ...ccl_manager import build_tree_from_ccl

RULES_DIR = Path(__file__).parent / "rules"


def parse(path: str):
    manager = build_tree_from_ccl(path)
    # Expansion engine wired in Task 15.
    return manager
```

- [ ] **Step 5: Run test to verify it passes**

Run: `pytest tests/test_input_parser.py -v`
Expected: tests PASS.

- [ ] **Step 6: Full suite still green**

Run: `pytest tests/ -v`
Expected: all tests pass.

- [ ] **Step 7: Commit**

```bash
git add src/ccltt/input/base.py src/ccltt/input/ccl/parser.py tests/test_input_parser.py
git commit -m "feat(input): add ccl parser as wrapper over legacy build_tree_from_ccl"
```

---

## Task 11: Input JSON parser migration

**Files:**
- Create: `src/ccltt/input/json/parser.py`
- Modify: `tests/test_input_parser.py`

- [ ] **Step 1: Write the failing test**

Append to `tests/test_input_parser.py`:

```python
from src.ccltt.input.json.parser import parse as parse_json
from src.ccltt import build_tree_from_json


def test_parse_json_matches_legacy_build_tree_from_json():
    legacy = build_tree_from_json("aesim_cb.input")
    new = parse_json("aesim_cb.input")
    legacy_out = legacy.trees["source"].print()
    new_out = new.trees["source"].print()
    assert legacy_out == new_out
```

Note: `tree.print()` here refers to `CclTtNodes.print()` if `trees["source"]` is a tree — but in legacy it's `manager.trees["source"]` which is a `CclTtTree`, and its `ROOT().print()` is the right call. Adjust:

```python
    legacy_out = legacy.trees["source"].ROOT().print()
    new_out = new.trees["source"].ROOT().print()
```

- [ ] **Step 2: Run test to verify it fails**

Run: `pytest tests/test_input_parser.py -v -k "json"`
Expected: FAIL with `ModuleNotFoundError`.

- [ ] **Step 3: Implement JSON parser as a thin wrapper**

Create `src/ccltt/input/json/parser.py`:

```python
"""JSON-like input parser — wraps legacy build_tree_from_json during migration."""
from pathlib import Path
from ...ccl_manager import build_tree_from_json

RULES_DIR = Path(__file__).parent / "rules"


def parse(path: str):
    manager = build_tree_from_json(path)
    # Expansion engine wired in Task 16.
    return manager
```

- [ ] **Step 4: Run test to verify it passes**

Run: `pytest tests/test_input_parser.py -v`
Expected: tests PASS.

- [ ] **Step 5: Full suite still green**

Run: `pytest tests/ -v`
Expected: all tests pass.

- [ ] **Step 6: Commit**

```bash
git add src/ccltt/input/json/parser.py tests/test_input_parser.py
git commit -m "feat(input): add json parser as wrapper over legacy build_tree_from_json"
```

---

## Task 12: Expansion rule_loader

**Files:**
- Create: `src/ccltt/input/expansion/rule_loader.py`
- Create: `tests/test_expansion_loader.py`

- [ ] **Step 1: Write the failing test**

Create `tests/test_expansion_loader.py`:

```python
import pytest
from pathlib import Path
from src.ccltt.input.expansion.rule_loader import load, RuleLoadError


def write(tmp_path: Path, name: str, content: str) -> Path:
    p = tmp_path / name
    p.write_text(content, encoding="utf-8")
    return p


def test_load_returns_empty_list_for_empty_dir(tmp_path):
    assert load(tmp_path) == []


def test_load_returns_paired_rules_sorted_by_name(tmp_path):
    write(tmp_path, "b_rule.original.yaml", "A: {}")
    write(tmp_path, "b_rule.expanded.yaml", "A:\n  X: {}")
    write(tmp_path, "a_rule.original.yaml", "B: {}")
    write(tmp_path, "a_rule.expanded.yaml", "B:\n  Y: {}")
    rules = load(tmp_path)
    assert [r.name for r in rules] == ["a_rule", "b_rule"]
    assert rules[0].original == {"B": {}}
    assert rules[0].expanded == {"B": {"Y": {}}}


def test_load_missing_pair_raises(tmp_path):
    write(tmp_path, "lonely.original.yaml", "A: {}")
    with pytest.raises(RuleLoadError, match="lonely.*expanded"):
        load(tmp_path)


def test_load_invalid_yaml_raises(tmp_path):
    write(tmp_path, "bad.original.yaml", "A: [unclosed")
    write(tmp_path, "bad.expanded.yaml", "A: {}")
    with pytest.raises(RuleLoadError, match="bad.original.yaml"):
        load(tmp_path)


def test_load_ignores_unrelated_files(tmp_path):
    write(tmp_path, "README.md", "ignore me")
    write(tmp_path, "ok.original.yaml", "A: {}")
    write(tmp_path, "ok.expanded.yaml", "A:\n  X: {}")
    rules = load(tmp_path)
    assert len(rules) == 1
    assert rules[0].name == "ok"


def test_load_nonexistent_dir_returns_empty(tmp_path):
    missing = tmp_path / "does_not_exist"
    assert load(missing) == []
```

- [ ] **Step 2: Run test to verify it fails**

Run: `pytest tests/test_expansion_loader.py -v`
Expected: FAIL with `ModuleNotFoundError`.

- [ ] **Step 3: Implement rule_loader**

Create `src/ccltt/input/expansion/rule_loader.py`:

```python
"""Load YAML rule pairs (original.yaml + expanded.yaml) from a directory."""
from dataclasses import dataclass
from pathlib import Path
from typing import List, Dict, Any
import yaml


class RuleLoadError(Exception):
    """Raised when rule files are malformed or pairing is incomplete."""


@dataclass
class Rule:
    name: str
    original: Dict[str, Any]
    expanded: Dict[str, Any]


_ORIGINAL_SUFFIX = ".original.yaml"
_EXPANDED_SUFFIX = ".expanded.yaml"


def _load_yaml(path: Path) -> Dict[str, Any]:
    try:
        with path.open("r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
    except yaml.YAMLError as e:
        raise RuleLoadError(f"YAML parse error in {path.name}: {e}") from e
    if data is None:
        return {}
    if not isinstance(data, dict):
        raise RuleLoadError(f"Top-level YAML in {path.name} must be a mapping, got {type(data).__name__}")
    return data


def load(rules_dir) -> List[Rule]:
    """Scan `rules_dir` for `<name>.original.yaml` + `<name>.expanded.yaml` pairs.

    Returns rules sorted by `name` (lexicographic). Missing pair or invalid YAML raises RuleLoadError.
    A non-existent directory yields an empty list.
    """
    rules_dir = Path(rules_dir)
    if not rules_dir.exists():
        return []
    originals: Dict[str, Path] = {}
    expandeds: Dict[str, Path] = {}
    for entry in rules_dir.iterdir():
        if not entry.is_file():
            continue
        nm = entry.name
        if nm.endswith(_ORIGINAL_SUFFIX):
            originals[nm[: -len(_ORIGINAL_SUFFIX)]] = entry
        elif nm.endswith(_EXPANDED_SUFFIX):
            expandeds[nm[: -len(_EXPANDED_SUFFIX)]] = entry
        # other files are ignored
    only_in_orig = set(originals) - set(expandeds)
    only_in_exp = set(expandeds) - set(originals)
    if only_in_orig:
        bad = sorted(only_in_orig)[0]
        raise RuleLoadError(f"rule '{bad}' has original.yaml but no expanded.yaml")
    if only_in_exp:
        bad = sorted(only_in_exp)[0]
        raise RuleLoadError(f"rule '{bad}' has expanded.yaml but no original.yaml")
    rules: List[Rule] = []
    for name in sorted(originals):
        rules.append(Rule(
            name=name,
            original=_load_yaml(originals[name]),
            expanded=_load_yaml(expandeds[name]),
        ))
    return rules
```

- [ ] **Step 4: Run test to verify it passes**

Run: `pytest tests/test_expansion_loader.py -v`
Expected: all tests PASS.

- [ ] **Step 5: Full suite still green**

Run: `pytest tests/ -v`
Expected: all tests pass.

- [ ] **Step 6: Commit**

```bash
git add src/ccltt/input/expansion/rule_loader.py tests/test_expansion_loader.py
git commit -m "feat(expansion): add rule_loader for YAML original/expanded pairs"
```

---

## Task 13: Expansion engine — type-name matching

**Files:**
- Create: `src/ccltt/input/expansion/engine.py`
- Create: `tests/test_expansion_engine.py`

- [ ] **Step 1: Write the failing test**

Create `tests/test_expansion_engine.py`:

```python
from src.ccltt import CclManager
from src.ccltt.input.expansion.engine import _find_anchors, _node_type_name


def test_node_type_name_for_singleton():
    mgr = CclManager()
    tree = mgr.trees["source"]
    nid = tree.build_tree(parent_id=1, name="FLOW")
    assert _node_type_name(tree, nid) == "FLOW"


def test_node_type_name_for_typed_instance():
    mgr = CclManager()
    tree = mgr.trees["source"]
    nid = tree.build_tree(parent_id=1, name="Domain 1", ty="DOMAIN")
    assert _node_type_name(tree, nid) == "DOMAIN"


def test_find_anchors_single_level():
    mgr = CclManager()
    tree = mgr.trees["source"]
    a = tree.build_tree(parent_id=1, name="A")
    tree.build_tree(parent_id=a, name="d1", ty="Domain")
    tree.build_tree(parent_id=a, name="d2", ty="Domain")
    tree.build_tree(parent_id=a, name="other", ty="Boundary")
    anchors = _find_anchors(tree, ["A", "Domain"])
    assert sorted(n.name for n in anchors) == ["d1", "d2"]


def test_find_anchors_no_match():
    mgr = CclManager()
    tree = mgr.trees["source"]
    tree.build_tree(parent_id=1, name="A")
    anchors = _find_anchors(tree, ["A", "Nope"])
    assert anchors == []


def test_find_anchors_three_levels_with_mix_of_singleton_and_typed():
    mgr = CclManager()
    tree = mgr.trees["source"]
    a = tree.build_tree(parent_id=1, name="A")              # singleton "A"
    d = tree.build_tree(parent_id=a, name="d1", ty="Domain")  # typed Domain
    tree.build_tree(parent_id=d, name="B")                   # singleton "B"
    anchors = _find_anchors(tree, ["A", "Domain", "B"])
    assert len(anchors) == 1
    assert anchors[0].name == "B"
```

- [ ] **Step 2: Run test to verify it fails**

Run: `pytest tests/test_expansion_engine.py -v`
Expected: FAIL with `ModuleNotFoundError`.

- [ ] **Step 3: Implement matching helpers**

Create `src/ccltt/input/expansion/engine.py`:

```python
"""Expansion engine: match LHS type chains and reconcile RHS subtrees."""
from typing import List, Dict, Any
from ...core import CclTtTree, CclTtNode

RESERVED_KEYS = {"__value__", "__type__", "__unit__"}


def _node_type_name(tree: CclTtTree, node_id: int) -> str:
    """Return the 'type-name' to match against LHS:
       - typed instance (TYPE: name) -> node_type
       - singleton (TYPE)            -> node_name
    """
    db_node = tree.db.get_node(tree.name, node_id)
    if db_node is None:
        return ""
    _id, name, ty, _val, _expr = db_node
    return ty if ty is not None else name


def _find_anchors(tree: CclTtTree, lhs_path: List[str]) -> List[CclTtNode]:
    """Walk `lhs_path` from tree.root through children, matching by type-name.

    Returns the list of anchor nodes (the deepest matched node per branch).
    For an empty `lhs_path`, returns `[tree.root]`.
    """
    candidates: List[CclTtNode] = [tree.root]
    for ti in lhs_path:
        next_round: List[CclTtNode] = []
        for parent in candidates:
            children = tree.find_by_path_with_wildcard(parent.node_id, "*")
            for ch in children:
                if _node_type_name(tree, ch.node_id) == ti:
                    next_round.append(ch)
        candidates = next_round
        if not candidates:
            return []
    return candidates
```

- [ ] **Step 4: Run test to verify it passes**

Run: `pytest tests/test_expansion_engine.py -v`
Expected: all tests PASS.

- [ ] **Step 5: Full suite still green**

Run: `pytest tests/ -v`
Expected: all tests pass.

- [ ] **Step 6: Commit**

```bash
git add src/ccltt/input/expansion/engine.py tests/test_expansion_engine.py
git commit -m "feat(expansion): add type-name based LHS anchor matching"
```

---

## Task 14: Expansion engine — RHS reconcile + apply

**Files:**
- Modify: `src/ccltt/input/expansion/engine.py`
- Modify: `tests/test_expansion_engine.py`

- [ ] **Step 1: Write the failing test**

Append to `tests/test_expansion_engine.py`:

```python
from src.ccltt.input.expansion.engine import apply
from src.ccltt.input.expansion.rule_loader import Rule


def _flatten_path_to_yaml(path: list) -> dict:
    """Build nested mapping for {A: {Domain: {B: {}}}} from ['A','Domain','B']."""
    out: dict = {}
    cur = out
    for p in path:
        cur[p] = {}
        cur = cur[p]
    return out


def test_apply_adds_missing_child_with_is_real_false():
    mgr = CclManager()
    tree = mgr.trees["source"]
    a = tree.build_tree(parent_id=1, name="A")
    tree.build_tree(parent_id=a, name="d1", ty="Domain")
    tree.build_tree(parent_id=a, name="d2", ty="Domain")
    rule = Rule(
        name="add_C",
        original={"A": {"Domain": {}}},
        expanded={"A": {"Domain": {"C": {}}}},
    )
    apply(tree, [rule])
    # Each Domain instance must now contain a child whose type-name == 'C', is_real=False.
    for inst_name in ("d1", "d2"):
        nodes = tree.find_by_path_with_wildcard(1, f"A/{inst_name}")
        assert len(nodes) == 1
        children = tree.find_by_path_with_wildcard(nodes[0].node_id, "*")
        names = [c.name for c in children]
        assert "C" in names
        c = next(c for c in children if c.name == "C")
        assert c.is_real() is False


def test_apply_preserves_existing_attributes():
    mgr = CclManager()
    tree = mgr.trees["source"]
    a = tree.build_tree(parent_id=1, name="A")
    d = tree.build_tree(parent_id=a, name="d1", ty="Domain")
    tree.build_tree(parent_id=d, name="C", ty="int", value="42")  # already exists with value
    rule = Rule(
        name="touch_C",
        original={"A": {"Domain": {}}},
        expanded={"A": {"Domain": {"C": {"__value__": 99, "__type__": "int"}}}},
    )
    apply(tree, [rule])
    c = tree.find_by_path_with_wildcard(d, "C")[0]
    assert c.value() == "42", "existing value must not be overwritten"


def test_apply_is_idempotent():
    mgr = CclManager()
    tree = mgr.trees["source"]
    a = tree.build_tree(parent_id=1, name="A")
    tree.build_tree(parent_id=a, name="d1", ty="Domain")
    rule = Rule(name="r", original={"A": {"Domain": {}}}, expanded={"A": {"Domain": {"C": {}}}})
    apply(tree, [rule])
    apply(tree, [rule])
    children = tree.find_by_path_with_wildcard(a, "d1/*")
    c_count = sum(1 for c in children if c.name == "C")
    assert c_count == 1


def test_apply_adds_value_type_unit_from_reserved_keys():
    mgr = CclManager()
    tree = mgr.trees["source"]
    a = tree.build_tree(parent_id=1, name="A")
    rule = Rule(
        name="add_v",
        original={"A": {}},
        expanded={"A": {"V": {"__value__": 5, "__type__": "real", "__unit__": "m/s"}}},
    )
    apply(tree, [rule])
    v = tree.find_by_path_with_wildcard(a, "V")[0]
    assert v.is_real() is False
    assert str(v.value()) == "5"
    assert v.type() == "real"
    assert v.exprn() == "m/s"


def test_apply_adds_nested_subtree():
    mgr = CclManager()
    tree = mgr.trees["source"]
    a = tree.build_tree(parent_id=1, name="A")
    rule = Rule(
        name="nested",
        original={"A": {}},
        expanded={"A": {"E": {"E1": {}, "E2": {"__value__": True, "__type__": "bool"}}}},
    )
    apply(tree, [rule])
    e_nodes = tree.find_by_path_with_wildcard(a, "E")
    assert len(e_nodes) == 1
    assert e_nodes[0].is_real() is False
    e1 = tree.find_by_path_with_wildcard(e_nodes[0].node_id, "E1")
    e2 = tree.find_by_path_with_wildcard(e_nodes[0].node_id, "E2")
    assert len(e1) == 1 and e1[0].is_real() is False
    assert len(e2) == 1 and e2[0].is_real() is False
    assert e2[0].type() == "bool"


def test_apply_no_match_is_silent():
    mgr = CclManager()
    tree = mgr.trees["source"]
    rule = Rule(name="noop", original={"Nope": {}}, expanded={"Nope": {"X": {}}})
    apply(tree, [rule])  # must not raise
    # nothing added
    children = tree.find_by_path_with_wildcard(1, "*")
    assert children == []


def test_apply_does_not_demote_existing_real_node():
    mgr = CclManager()
    tree = mgr.trees["source"]
    a = tree.build_tree(parent_id=1, name="A")
    c_real = tree.build_tree(parent_id=a, name="C", ty="int", value="1")  # real
    rule = Rule(name="touch", original={"A": {}}, expanded={"A": {"C": {}}})
    apply(tree, [rule])
    assert mgr.db.get_node_is_real("source", c_real) is True
```

- [ ] **Step 2: Run test to verify it fails**

Run: `pytest tests/test_expansion_engine.py -v -k "apply"`
Expected: FAIL with `ImportError: cannot import name 'apply'`.

- [ ] **Step 3: Implement `apply` and `reconcile`**

Append to `src/ccltt/input/expansion/engine.py`:

```python
def _flatten_lhs_path(node: Dict[str, Any]) -> List[str]:
    """Reduce an LHS yaml dict to its single-spine path of keys.

    LHS is expected to be a single chain of mappings; siblings in LHS are not
    used in C-semantics. We pick the deepest single-spine path; if branching
    exists we use only the first key at each level (deterministic / lexicographic).
    Reserved keys are ignored at the LHS root level.
    """
    path: List[str] = []
    cur = node
    while isinstance(cur, dict) and cur:
        keys = [k for k in cur.keys() if k not in RESERVED_KEYS]
        if not keys:
            break
        keys.sort()
        k = keys[0]
        path.append(k)
        cur = cur[k] if isinstance(cur[k], dict) else {}
    return path


def _find_child_by_typename(tree: CclTtTree, parent_id: int, type_name: str):
    children = tree.find_by_path_with_wildcard(parent_id, "*")
    for ch in children:
        if _node_type_name(tree, ch.node_id) == type_name:
            return ch
    return None


def _reconcile(tree: CclTtTree, anchor: CclTtNode, rhs_subtree: Dict[str, Any], stats: Dict[str, int]):
    """Walk RHS subtree under `anchor`. Add any missing child as is_real=False."""
    for child_name, child_spec in rhs_subtree.items():
        if child_name in RESERVED_KEYS:
            continue
        spec = child_spec if isinstance(child_spec, dict) else {}
        existing = _find_child_by_typename(tree, anchor.node_id, child_name)
        if existing is None:
            value = spec.get("__value__")
            ty = spec.get("__type__")
            unit = spec.get("__unit__")
            new_id = tree.build_tree(
                parent_id=anchor.node_id,
                name=child_name,
                ty=ty,
                value=str(value) if value is not None else None,
                is_real=False,
            )
            if unit is not None:
                tree.add_exprn(new_id, unit)
            new_node = tree.nodes[new_id]
            stats["added"] += 1
            _reconcile(tree, new_node, spec, stats)
        else:
            _reconcile(tree, existing, spec, stats)


def apply(tree: CclTtTree, rules) -> None:
    """Apply each rule in order: find LHS anchors and reconcile RHS under each."""
    import logging
    logger = logging.getLogger("ccltt.expansion")
    for rule in rules:
        lhs_path = _flatten_lhs_path(rule.original)
        anchors = _find_anchors(tree, lhs_path)
        # The RHS root mirrors the same top-level key as LHS; descend into the matched-anchor's subtree.
        rhs_subtree = rule.expanded
        for key in lhs_path:
            if isinstance(rhs_subtree, dict) and key in rhs_subtree:
                rhs_subtree = rhs_subtree[key]
            else:
                rhs_subtree = {}
                break
        stats = {"added": 0}
        if isinstance(rhs_subtree, dict):
            for anchor in anchors:
                _reconcile(tree, anchor, rhs_subtree, stats)
        logger.info(
            "rule=%s matches=%d nodes_added=%d",
            rule.name, len(anchors), stats["added"],
        )
```

- [ ] **Step 4: Run test to verify it passes**

Run: `pytest tests/test_expansion_engine.py -v`
Expected: all tests PASS.

- [ ] **Step 5: Full suite still green**

Run: `pytest tests/ -v`
Expected: all tests pass.

- [ ] **Step 6: Commit**

```bash
git add src/ccltt/input/expansion/engine.py tests/test_expansion_engine.py
git commit -m "feat(expansion): add apply() with idempotent RHS reconcile"
```

---

## Task 15: Wire expansion into CCL parser

**Files:**
- Modify: `src/ccltt/input/ccl/parser.py`
- Modify: `tests/test_input_parser.py`

- [ ] **Step 1: Write the failing test**

Append to `tests/test_input_parser.py`:

```python
def test_ccl_parser_runs_expansion_engine_with_empty_rules_dir(tmp_path, monkeypatch):
    # No rule files in tmp_path -> parsing must be a no-op vs legacy.
    from src.ccltt.input.ccl import parser as ccl_parser
    monkeypatch.setattr(ccl_parser, "RULES_DIR", tmp_path)
    new = ccl_parser.parse("VMFL047.ccl")
    legacy = build_tree_from_ccl("VMFL047.ccl")
    assert new.trees["source"].ROOT().transfrom() == legacy.trees["source"].ROOT().transfrom()


def test_ccl_parser_applies_sanity_rule(tmp_path, monkeypatch):
    (tmp_path / "sanity.original.yaml").write_text("LIBRARY: {}\n", encoding="utf-8")
    (tmp_path / "sanity.expanded.yaml").write_text(
        "LIBRARY:\n  CclTtSentinel: {}\n", encoding="utf-8",
    )
    from src.ccltt.input.ccl import parser as ccl_parser
    monkeypatch.setattr(ccl_parser, "RULES_DIR", tmp_path)
    mgr = ccl_parser.parse("VMFL047.ccl")
    sentinels = mgr.trees["source"].find_by_path_with_wildcard(1, "LIBRARY/CclTtSentinel")
    assert len(sentinels) >= 1
    for s in sentinels:
        assert s.is_real() is False
```

(VMFL047.ccl contains a top-level `LIBRARY:` block per inspection of repo CCL files; if not, replace with a top-level keyword that does appear.)

- [ ] **Step 2: Run test to verify it fails**

Run: `pytest tests/test_input_parser.py -v -k "expansion or sanity"`
Expected: FAIL — sentinel not added.

- [ ] **Step 3: Wire expansion engine into parser**

Replace the body of `src/ccltt/input/ccl/parser.py`:

```python
"""CCL parser — wraps legacy build_tree_from_ccl, then runs expansion engine."""
from pathlib import Path
from ...ccl_manager import build_tree_from_ccl
from ..expansion import rule_loader, engine

RULES_DIR = Path(__file__).parent / "rules"


def parse(path: str):
    manager = build_tree_from_ccl(path)
    rules = rule_loader.load(RULES_DIR)
    if rules:
        engine.apply(manager.trees["source"], rules)
    return manager
```

- [ ] **Step 4: Verify the rule's top-level key actually exists in the CCL fixture**

Before running the test, verify:

Run: `grep -c "^LIBRARY:" VMFL047.ccl` (expected: ≥ 1)
If it's 0, change `LIBRARY` in both the test and the YAML to a key that does occur (e.g. `SIMULATION CONTROL` → no, must be a single token). A safe alternative: `LIBRARY` is a CCL standard top-level block; if missing, use `FLOW` (also standard).

- [ ] **Step 5: Run test to verify it passes**

Run: `pytest tests/test_input_parser.py -v`
Expected: all tests PASS.

- [ ] **Step 6: Full suite still green**

Run: `pytest tests/ -v`
Expected: all tests pass.

- [ ] **Step 7: Commit**

```bash
git add src/ccltt/input/ccl/parser.py tests/test_input_parser.py
git commit -m "feat(input/ccl): wire expansion engine into ccl parser"
```

---

## Task 16: Wire expansion into JSON parser

**Files:**
- Modify: `src/ccltt/input/json/parser.py`
- Modify: `tests/test_input_parser.py`

- [ ] **Step 1: Write the failing test**

Append to `tests/test_input_parser.py`:

```python
def test_json_parser_runs_expansion_engine_with_empty_rules_dir(tmp_path, monkeypatch):
    from src.ccltt.input.json import parser as json_parser
    monkeypatch.setattr(json_parser, "RULES_DIR", tmp_path)
    new = json_parser.parse("aesim_cb.input")
    legacy = build_tree_from_json("aesim_cb.input")
    assert new.trees["source"].ROOT().print() == legacy.trees["source"].ROOT().print()
```

- [ ] **Step 2: Run test to verify it fails (or already passes)**

Run: `pytest tests/test_input_parser.py -v -k "json_parser_runs"`
This may pass already if Task 11 wrapper is unchanged; but the new code path must explicitly call the engine.

- [ ] **Step 3: Wire expansion engine into JSON parser**

Replace the body of `src/ccltt/input/json/parser.py`:

```python
"""JSON-like input parser — wraps legacy build_tree_from_json, then runs expansion."""
from pathlib import Path
from ...ccl_manager import build_tree_from_json
from ..expansion import rule_loader, engine

RULES_DIR = Path(__file__).parent / "rules"


def parse(path: str):
    manager = build_tree_from_json(path)
    rules = rule_loader.load(RULES_DIR)
    if rules:
        engine.apply(manager.trees["source"], rules)
    return manager
```

- [ ] **Step 4: Run test to verify it passes**

Run: `pytest tests/test_input_parser.py -v`
Expected: all tests PASS.

- [ ] **Step 5: Full suite still green**

Run: `pytest tests/ -v`
Expected: all tests pass.

- [ ] **Step 6: Commit**

```bash
git add src/ccltt/input/json/parser.py tests/test_input_parser.py
git commit -m "feat(input/json): wire expansion engine into json parser"
```

---

## Task 17: Transform — migrate `merge` / `remove`

**Files:**
- Create: `src/ccltt/transform/operations.py`
- Modify: `src/ccltt/ccl_tt_node.py`

- [ ] **Step 1: Move the implementations**

Create `src/ccltt/transform/operations.py`. Note: we deliberately avoid importing `CclTtNodes` here. Importing it from `..core` would create a circular dependency because `core/__init__.py` re-exports from `..ccl_tt_node`, and `ccl_tt_node.py` will (in step 2) import back from `..transform.operations`. Using `type(a)(...)` yields the same result without taking on any import:

```python
"""Free-function tree CRUD operations."""


def merge(a, b, c=None):
    """Set-union of two node collections (works on any CclTtNodes-like type)."""
    if a is None:
        return b
    if b is None:
        return a
    return type(a)(a.nodes + b.nodes)


def remove(a, b):
    """Set-difference: copy of `a` with any node also present in `b` removed."""
    a_copy = a.copy()
    for node in a_copy.nodes:
        for node2 in b.nodes:
            if node.node_id == node2.node_id and node.tree.name == node2.tree.name:
                a_copy.nodes.remove(node)
    return a_copy
```

- [ ] **Step 2: Convert old definitions in `ccl_tt_node.py` into re-exports**

Replace the bottom of `src/ccltt/ccl_tt_node.py` (the existing `merge` and `remove` functions, around lines 297–310) with:

```python
# merge/remove migrated to ccltt.transform.operations.
# Re-export here to keep legacy imports working.
from .transform.operations import merge, remove  # noqa: E402
```

- [ ] **Step 3: Run full suite to confirm**

Run: `pytest tests/ -v`
Expected: all tests pass (existing tests use `from src.ccltt.ccl_tt_node import merge, remove`).

- [ ] **Step 4: Commit**

```bash
git add src/ccltt/transform/operations.py src/ccltt/ccl_tt_node.py
git commit -m "refactor(transform): move merge/remove to transform.operations with legacy re-export"
```

---

## Task 18: Manager rewrite

**Files:**
- Create: `src/ccltt/manager.py`
- Modify: `src/ccltt/ccl_manager.py`
- Modify: `src/ccltt/__init__.py`

- [ ] **Step 1: Write the failing test**

Append to `tests/test_input_parser.py`:

```python
def test_manager_from_ccl_classmethod_round_trip():
    from src.ccltt.manager import CclManager as NewMgr
    mgr = NewMgr.from_ccl("VMFL047.ccl")
    assert "source" in mgr.trees
    out = mgr.to_ccl()
    assert out == NewMgr.from_ccl("VMFL047.ccl").trees["source"].ROOT().transfrom()


def test_manager_debug_print_emits_string():
    from src.ccltt.manager import CclManager as NewMgr
    mgr = NewMgr.from_ccl("VMFL047.ccl")
    out = mgr.debug_print()
    assert isinstance(out, str) and len(out) > 0
```

- [ ] **Step 2: Run test to verify it fails**

Run: `pytest tests/test_input_parser.py -v -k "manager_from_ccl or manager_debug"`
Expected: FAIL with `ModuleNotFoundError: No module named 'src.ccltt.manager'`.

- [ ] **Step 3: Implement new manager**

Create `src/ccltt/manager.py`:

```python
"""Top-level coordinator: wraps input parsers, transform-layer trees, and output writers."""
from .core import MyDatabase, CclTtTree


class CclManager:
    def __init__(self):
        self.db = MyDatabase()
        self.trees = {}
        self.init_tree("source")

    def init_tree(self, name: str):
        if name in self.trees:
            return False
        tree = CclTtTree(name, self.db)
        self.trees[name] = tree
        return tree

    @classmethod
    def from_ccl(cls, path: str) -> "CclManager":
        from .input.ccl.parser import parse
        return parse(path)

    @classmethod
    def from_json(cls, path: str) -> "CclManager":
        from .input.json.parser import parse
        return parse(path)

    def to_ccl(self, tree_name: str = "source", include_expanded: bool = False) -> str:
        from .output.ccl.writer import CclWriter
        return CclWriter().write(self.trees[tree_name], include_expanded)

    def debug_print(self, tree_name: str = "source") -> str:
        from .output.debug.printer import DebugPrinter
        return DebugPrinter().write(self.trees[tree_name])
```

- [ ] **Step 4: Make legacy `ccl_manager.CclManager` an alias**

The existing parsers (`build_tree_from_ccl`, `build_tree_from_json`) instantiate `ccl_manager.CclManager`. Keep them working: at the bottom of `src/ccltt/ccl_manager.py`, add (after the existing class definition):

```python
# Legacy module-level CclManager is kept; new top-level CclManager lives in ccltt.manager.
# `from ccltt import CclManager` continues to import the new one (see __init__.py).
```

(No code change required if both classes can coexist. The legacy `CclManager` in `ccl_manager.py` is what `build_tree_from_ccl` returns; that's fine for now — the new `CclManager.from_ccl` returns whatever the legacy parser produces, structurally compatible because both delegate to the same db/tree types via core re-exports.)

Verify by inspection: `src/ccltt/ccl_manager.py` line 9–20 (`class CclManager`) is unchanged.

- [ ] **Step 5: Update `__init__.py` to export the new manager preferentially**

Replace `src/ccltt/__init__.py` content with:

```python
# SPDX-FileCopyrightText: 2025-present Flyshde <zhangyang@outlook.es>
# SPDX-License-Identifier: MIT
from .core import CclTtTree, CclTtNode, CclTtNodes
from .transform.operations import merge, remove
from .manager import CclManager
from .ccl_manager import build_tree_from_json, build_tree_from_ccl

__all__ = [
    "CclTtTree", "CclTtNode", "CclTtNodes",
    "CclManager",
    "merge", "remove",
    "build_tree_from_json", "build_tree_from_ccl",
]
```

- [ ] **Step 6: Run test to verify it passes**

Run: `pytest tests/ -v`
Expected: all tests pass; new manager tests PASS.

- [ ] **Step 7: Commit**

```bash
git add src/ccltt/manager.py src/ccltt/ccl_manager.py src/ccltt/__init__.py tests/test_input_parser.py
git commit -m "feat(manager): introduce top-level CclManager with from_ccl/from_json/to_ccl/debug_print"
```

---

## Task 19: End-to-end test

**Files:**
- Create: `tests/test_e2e_ccl.py`
- Create: `tests/fixtures/e2e_input.ccl`
- Create: `tests/fixtures/e2e_rule.original.yaml`
- Create: `tests/fixtures/e2e_rule.expanded.yaml`

- [ ] **Step 1: Create test fixtures**

Create `tests/fixtures/e2e_input.ccl`:

```
FLOW: Flow Analysis 1
    DOMAIN: Domain 1
        Domain Type = Fluid
    END
END
```

Create `tests/fixtures/e2e_rule.original.yaml`:

```yaml
FLOW:
  DOMAIN: {}
```

Create `tests/fixtures/e2e_rule.expanded.yaml`:

```yaml
FLOW:
  DOMAIN:
    Solver Target Residual:
      __value__: 1.0e-5
      __type__: real
```

- [ ] **Step 2: Write the test**

Create `tests/test_e2e_ccl.py`:

```python
from pathlib import Path

FIXTURES = Path(__file__).parent / "fixtures"


def test_e2e_parse_expand_write(monkeypatch):
    """End-to-end: load CCL → run expansion rule → write back, with and without scaffolding."""
    from src.ccltt.input.ccl import parser as ccl_parser
    monkeypatch.setattr(ccl_parser, "RULES_DIR", FIXTURES)

    mgr = ccl_parser.parse(str(FIXTURES / "e2e_input.ccl"))
    tree = mgr.trees["source"]

    # The new node must exist and be is_real=False.
    nodes = tree.find_by_path_with_wildcard(1, "FLOW/Domain 1/Solver Target Residual")
    assert len(nodes) == 1
    assert nodes[0].is_real() is False
    assert nodes[0].type() == "real"
    assert str(nodes[0].value()) == "1e-05" or str(nodes[0].value()) == "1.0e-05"

    # Default writer drops scaffolding.
    from src.ccltt.output.ccl.writer import CclWriter
    out_default = CclWriter().write(tree)
    assert "Solver Target Residual" not in out_default
    assert "Domain Type = Fluid" in out_default

    # include_expanded surfaces it.
    out_full = CclWriter().write(tree, include_expanded=True)
    assert "Solver Target Residual" in out_full


def test_e2e_promotion_when_user_writes_under_scaffold(monkeypatch):
    from src.ccltt.input.ccl import parser as ccl_parser
    monkeypatch.setattr(ccl_parser, "RULES_DIR", FIXTURES)
    mgr = ccl_parser.parse(str(FIXTURES / "e2e_input.ccl"))
    tree = mgr.trees["source"]
    # Scaffolded node:
    sentinel = tree.find_by_path_with_wildcard(1, "FLOW/Domain 1/Solver Target Residual")[0]
    # User now writes under it: this should promote the chain.
    tree.build_tree(parent_id=sentinel.node_id, name="UserChild", ty="int", value="1")
    assert sentinel.is_real() is True
```

- [ ] **Step 3: Run the test**

Run: `pytest tests/test_e2e_ccl.py -v`
Expected: both tests PASS.

- [ ] **Step 4: Full suite still green**

Run: `pytest tests/ -v`
Expected: all tests pass.

- [ ] **Step 5: Commit**

```bash
git add tests/test_e2e_ccl.py tests/fixtures
git commit -m "test(e2e): end-to-end ccl parse + expand + write with sample rule"
```

---

## Task 20: Cleanup — move data structures into `core/`, hide legacy parsers

**Goal:** move tree/node/database implementations into `core/` and turn the legacy `ccl_manager.py` into a private internal module that only the input parsers consume. Public API (`from src.ccltt import ...`) is unchanged. Avoid duplicating the multi-hundred-line regex parsers — keep them where they are, just rename.

**Files:**
- Move: `src/ccltt/data_base.py` → `src/ccltt/core/database.py`
- Move: `src/ccltt/ccl_tt_tree.py` → `src/ccltt/core/tree.py`
- Move: `src/ccltt/ccl_tt_node.py` → `src/ccltt/core/node.py`
- Move: `src/ccltt/ccl_manager.py` → `src/ccltt/_legacy_parsers.py`
- Modify: `src/ccltt/core/__init__.py`
- Modify: `src/ccltt/_legacy_parsers.py` (intra-imports)
- Modify: `src/ccltt/input/ccl/parser.py` (consume from `.._legacy_parsers`)
- Modify: `src/ccltt/input/json/parser.py` (consume from `.._legacy_parsers`)
- Modify: `src/ccltt/__init__.py`

- [ ] **Step 1: Move data structures into `core/`**

Run:

```bash
git mv src/ccltt/data_base.py src/ccltt/core/database.py
git mv src/ccltt/ccl_tt_tree.py src/ccltt/core/tree.py
git mv src/ccltt/ccl_tt_node.py src/ccltt/core/node.py
```

- [ ] **Step 2: Update intra-`core/` imports**

In `src/ccltt/core/tree.py`, replace the top-of-file imports:

```python
from .ccl_tt_node import CclTtNode, CclTtNodes
from .data_base import MyDatabase
```

with:

```python
from .node import CclTtNode, CclTtNodes
from .database import MyDatabase
```

In `src/ccltt/core/node.py`, the legacy re-export added in Task 17:

```python
from .transform.operations import merge, remove  # noqa: E402
```

becomes:

```python
from ..transform.operations import merge, remove  # noqa: E402
```

- [ ] **Step 3: Replace `core/__init__.py` with direct imports (no fallback indirection)**

Replace `src/ccltt/core/__init__.py`:

```python
"""Core data structures."""
from .tree import CclTtTree
from .node import CclTtNode, CclTtNodes, format_values
from .database import MyDatabase

__all__ = ["CclTtTree", "CclTtNode", "CclTtNodes", "MyDatabase", "format_values"]
```

- [ ] **Step 4: Move legacy parsers to a private internal module**

Run:

```bash
git mv src/ccltt/ccl_manager.py src/ccltt/_legacy_parsers.py
```

Then update its imports. In `src/ccltt/_legacy_parsers.py`, replace:

```python
from .ccl_tt_tree import CclTtTree
from .data_base import MyDatabase
from .ccl_tt_node import CclTtNode, CclTtNodes
```

with:

```python
from .core.tree import CclTtTree
from .core.database import MyDatabase
from .core.node import CclTtNode, CclTtNodes
```

The rest of the file (regex parsing, `build_tree`, `build_tree_from_ccl`, `build_tree_from_json`, the legacy `CclManager` class) is unchanged.

- [ ] **Step 5: Update `input/ccl/parser.py` to import from the renamed module**

In `src/ccltt/input/ccl/parser.py`, change:

```python
from ...ccl_manager import build_tree_from_ccl
```

to:

```python
from .._legacy_parsers import build_tree_from_ccl
```

- [ ] **Step 6: Update `input/json/parser.py` to import from the renamed module**

In `src/ccltt/input/json/parser.py`, change:

```python
from ...ccl_manager import build_tree_from_json
```

to:

```python
from .._legacy_parsers import build_tree_from_json
```

- [ ] **Step 7: Update `src/ccltt/__init__.py` to use new sources**

Replace `src/ccltt/__init__.py` content:

```python
# SPDX-FileCopyrightText: 2025-present Flyshde <zhangyang@outlook.es>
# SPDX-License-Identifier: MIT
from .core import CclTtTree, CclTtNode, CclTtNodes
from .transform.operations import merge, remove
from .manager import CclManager
from ._legacy_parsers import build_tree_from_ccl, build_tree_from_json

__all__ = [
    "CclTtTree", "CclTtNode", "CclTtNodes",
    "CclManager",
    "merge", "remove",
    "build_tree_from_json", "build_tree_from_ccl",
]
```

Note: `from src.ccltt import CclManager` now resolves to the **new** top-level `CclManager` from `manager.py`. The legacy `CclManager` in `_legacy_parsers.py` is still used internally by `build_tree_from_ccl`/`build_tree_from_json` to hold their results, but is not re-exported.

- [ ] **Step 8: Update `tests/test_initial.py` imports**

`tests/test_initial.py` line 1 currently uses `from src.ccltt.ccl_manager import CclManager, build_tree_from_ccl, build_tree_from_json`. Replace lines 1-3 with:

```python
from src.ccltt import build_tree_from_ccl, build_tree_from_json, CclManager
from src.ccltt.core import CclTtTree
from src.ccltt.transform.operations import merge, remove
```

Note that this test currently does `CclManager()` and reads `manager.trees["source"]` and `manager.db.get_all_node_tables()`. Both legacy and new `CclManager` provide these — the test passes either way.

- [ ] **Step 9: Sanity-grep for any remaining stale imports**

Run:

```bash
grep -rn "from src.ccltt.ccl_manager" src tests
grep -rn "from src.ccltt.data_base" src tests
grep -rn "from src.ccltt.ccl_tt_tree" src tests
grep -rn "from src.ccltt.ccl_tt_node" src tests
```

Expected: no matches anywhere.

- [ ] **Step 10: Run full suite**

Run: `pytest tests/ -v`
Expected: all tests pass.

- [ ] **Step 11: Snapshot regression check**

Run: `git status` and `git diff -- '*_output.txt'`.
Expected: no diff in `*_output.txt` snapshots.

- [ ] **Step 12: Commit**

```bash
git add -A
git commit -m "refactor: move tree/node/db into core/, hide legacy parsers as _legacy_parsers"
```

---

## Task 21: Final verification — full snapshot regression

**Files:** none (verification only)

- [ ] **Step 1: Run full pytest with verbose output**

Run: `pytest tests/ -v`
Expected: all tests pass — including all `test_build_from_ccl_*` and `test_build_from_json_*`.

- [ ] **Step 2: Diff every committed snapshot**

Run: `git status` and `git diff` against any snapshot outputs (`8-23_output.txt`, `8-23_json_output.txt`, `CFXPreGui_output.txt`, `UnitSystems_output.txt`, `VMFL002B_VV002CFX_output.txt`, `VMFL012B_VV012CFX_output.txt`, `VMFL047_output.txt`, `execrules_output.txt`, `ccl_output.txt`, `json_output.txt`, `json_transfrom.txt`, `output2.txt`).

Expected: every snapshot identical to pre-refactor (HEAD before Task 0).

- [ ] **Step 3: Confirm no `ccl_manager` / `data_base` / `ccl_tt_*` imports remain outside core**

Run:

```bash
grep -rn "from src.ccltt.ccl_manager" src tests
grep -rn "from src.ccltt.data_base" src tests
grep -rn "from src.ccltt.ccl_tt_tree" src tests
grep -rn "from src.ccltt.ccl_tt_node" src tests
```

Expected: no matches.

- [ ] **Step 4: Confirm legacy `transfrom`/`print` methods on nodes still work**

Run:

```bash
python3 -c "from src.ccltt import build_tree_from_ccl; m = build_tree_from_ccl('VMFL047.ccl'); print(len(m.trees['source'].ROOT().transfrom()))"
```

Expected: prints a positive integer (no AttributeError).

- [ ] **Step 5: Tag the milestone**

```bash
git tag refactor/three-layer-arch-complete
```

(Tag is local-only unless pushed; no push required.)

---

## Self-review

**Spec coverage check** (all sections of the spec have at least one task):

- §3.1 (schema is_real column) → Task 1
- §3.2 (write paths) → Tasks 2, 4, 5
- §3.3 (auto-promotion) → Tasks 3, 4, 5
- §3.4 (is_real accessor) → Task 6
- §4.1 (rule files paired) → Task 12
- §4.2 (YAML reserved keys) → Tasks 12, 14
- §4.3 (matching by type-name) → Task 13
- §4.4 (RHS reconcile + idempotence) → Task 14
- §4.5 (RULES_DIR per-format) → Tasks 10, 11, 15, 16
- §4.6 (errors at load) → Task 12
- §4.7 (logging) → Task 14 implementation includes `logger.info(...)`
- §5 (transform layer migration) → Task 17
- §6.1 (Writer ABC) → Task 8
- §6.2 (CclWriter) → Task 8
- §6.3 (DebugPrinter) → Task 9
- §7 (Manager) → Task 18
- §8 (migration order) → Tasks 1–18 follow this order
- §9 (test files) → Tasks 1, 8, 12, 13, 14, 15, 19
- §10 risks → covered: snapshot regression check (Tasks 8 step 7, 21), `add_link` promotion (Task 5), YAML strict load (Task 12)
