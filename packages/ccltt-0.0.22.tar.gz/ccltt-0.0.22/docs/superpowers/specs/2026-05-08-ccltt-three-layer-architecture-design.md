# CclTt 三层架构重构 · 设计文档

- **Date**: 2026-05-08
- **Status**: 已审定（待实施）
- **Scope**: 本仓库 `src/ccltt/`、`tests/`

---

## 1. 背景与目标

`src/ccltt/` 当前把"输入解析"、"树/节点/数据库"、"变换 API"、"输出"全部混在 `ccl_manager.py` 里。需要重构为**三层**：

1. **输入层** —— 多格式输入源 → 在内存中建一棵树；解析后立刻按内置规则**扩充**这棵树，扩充节点全部标记为非真实。
2. **转换层** —— 在已扩充的树上做 CRUD（命令式 API；规则化变换留作未来 spec）。
3. **输出层** —— 多格式输出，默认只回写真实节点。

底层 `MyDatabase` / `CclTtTree` / `CclTtNode` / `CclTtNodes` 三件套**保留扩展**（不重写），主要新增 `is_real` 字段与自动晋升逻辑。

## 2. 模块组织

```
src/ccltt/
  core/                          # 底层数据结构
    tree.py                      # CclTtTree
    node.py                      # CclTtNode / CclTtNodes
    database.py                  # MyDatabase（schema 加 is_real）

  input/
    base.py                      # Parser 抽象接口
    ccl/
      parser.py                  # CCL → 树
      rules/                     # CCL 专属扩充规则（YAML 对）
    json/
      parser.py                  # JSON-like → 树
      rules/
    expansion/                   # 共享扩充引擎
      engine.py
      rule_loader.py

  transform/                     # 命令式 CRUD
    operations.py

  output/
    base.py                      # Writer 抽象接口
    ccl/
      writer.py                  # CCL 回写
    debug/
      printer.py                 # 树形 debug 输出

  manager.py                     # 顶层协调
  __about__.py
  __init__.py
```

边界约定：

- `core/` 不依赖任何输入/输出格式或规则。
- `input/<format>/` 内部各自独立：parser + 它自己的 `rules/`。
- `input/expansion/` 是被各 input format 共享调用的引擎，与 format 解耦。
- `output/` 各 writer 默认按 `include_expanded=False` 输出。
- `manager.py` 协调读输入 → 跑扩充 → 暴露 transform API → 写输出全链路。

## 3. 节点模型变更

### 3.1 Schema

每棵树的节点表新增 `is_real` 列：

```sql
CREATE TABLE IF NOT EXISTS <tree_name> (
    id INTEGER PRIMARY KEY,
    node_name TEXT NOT NULL,
    node_type TEXT,
    node_value TEXT,
    node_exprn TEXT,
    is_real INTEGER NOT NULL DEFAULT 1
)
```

`relations` 表不变。

### 3.2 写入路径

| 节点来源 | `is_real` |
|---|---|
| Parser 调 `tree.build_tree(...)` | `1` |
| 扩充引擎补齐 | `0` |
| Transform 层 `add` / `add_val` / `add_link` 等 | `1` |

`MyDatabase.add_node()` 增加 `is_real` 参数（默认 `1`）。

### 3.3 自动晋升

新增 `MyDatabase._promote_ancestors(tree_name, node_id)`：沿 `relations` 表向上走到 root，把途中所有 `is_real=0` 改成 `1`。

调用时机：

- `CclTtTree.build_tree(...)` 在 `is_real=True` 路径下，对新节点的 parent 调一次 `_promote_ancestors`。
- `CclTtTree.add_link(...)` 同理（晋升发生在 parent 链）。
- 扩充引擎的添加路径走 `is_real=False`，**不触发**晋升。

### 3.4 节点 API

```python
class CclTtNode:
    def is_real(self) -> bool: ...

class CclTtNodes:
    def is_real(self) -> bool | None:    # 单节点返回布尔；多节点返回 None
        ...
```

## 4. 扩充引擎

### 4.1 规则文件结构

每条规则只维护一个 `expanded.yaml`：

```
input/ccl/rules/
  FLOW.expanded.yaml
  LIBRARY.expanded.yaml
```

`rule_loader` 扫描目录中的 `*.expanded.yaml`；返回按前缀字典序排序的规则列表。**文件名 stem（去掉 `.expanded.yaml`）就是锚点名**，必须匹配输入树 root 的一个直接子节点（按类型名匹配，见 §4.3）。

### 4.2 YAML 写法

每个 `expanded.yaml` 描述的是**锚点子节点之下**要补齐的子树。子节点用嵌套 mapping，叶子用 `{}` 或带保留键的 mapping：

```yaml
# FLOW.expanded.yaml —— 锚点为 tree.root 下的 FLOW 节点
Domain:
  B: {}
  C: {}                           # 空容器
  D:                              # 带值/单位
    __value__: 5
    __type__: real
    __unit__: m/s
  E:                              # 带子树
    E1: {}
    E2:
      __value__: true
      __type__: bool
  F:                              # 显式标记为真实节点
    __value__: 1
    __type__: int
    __is_real__: true
```

保留键：`__value__` / `__type__` / `__unit__` / `__is_real__`。其余键都视作子节点名。

`__is_real__` 默认 `false`（即规则补出来的节点默认为脚手架）。显式写 `true` 时，新建节点会带 `is_real=True`，并按 `build_tree` 的标准逻辑自动晋升整条祖先链（§3）。CCL 输入本身不带这个字段，它只在 YAML 规则里有意义。

### 4.3 匹配语义（filename-anchored reconcile）

每条规则都以文件名 stem 作为锚点名，在输入树 root 的直接子节点里查找：

```
对每条规则:
    anchor = find_child_by_typename(tree.root, rule.name)
    if anchor is None:
        anchor = tree.build_tree(parent_id=root.id, name=rule.name, is_real=False)
    递归遍历 expanded.yaml，缺啥补啥（默认 is_real=False，YAML 显式写 __is_real__: true 则为真）
```

"已存在"判断使用类型名语义：

- 节点是 `TYPE: name` 形式（`node_type=TYPE`、`node_name=name`）→ 看 `node_type`。
- 节点是 `TYPE` 单例形式（`node_name=TYPE`、`node_type=None`）→ 看 `node_name`。

因此 `FLOW.expanded.yaml` 描述的是已存在 FLOW 节点之下的默认结构；`LIBRARY.expanded.yaml` 同理。锚点缺失时引擎会以 is_real=False 把它补出来，再向下递归。

### 4.4 RHS 补齐逻辑

对每个匹配到的锚点：

```python
def reconcile(anchor_node, rhs_subtree):
    for child_name, child_spec in rhs_subtree.items():
        if child_name in {"__value__", "__type__", "__unit__", "__is_real__"}:
            continue
        # 用 §4.3 的"类型名"语义查同名子节点（实例形式看 node_type，单例形式看 node_name）
        existing = find_child_by_typename(anchor_node, child_name)
        if existing is None:
            new_id = anchor_node.tree.build_tree(
                anchor_node.id, child_name,
                ty=child_spec.get("__type__"),
                value=child_spec.get("__value__"),
                exprn=child_spec.get("__unit__"),
                is_real=bool(child_spec.get("__is_real__", False)),
            )
            new_node = anchor_node.tree.nodes[new_id]
        else:
            new_node = existing                  # 已存在则不动属性
        reconcile(new_node, child_spec)
```

- "已存在"判定与匹配语义一致：用同一份"类型名"匹配（§4.3），不区分该子节点是 `TYPE: name` 还是 `TYPE` 单例。
- 已存在节点的属性**不被覆盖**（即使 RHS 写了不同的值/类型/单位）。
- 幂等：再次应用同一规则不会重复添加，不修改既有节点的 `is_real`。

### 4.5 调用时机

```python
# input/ccl/parser.py
RULES_DIR = Path(__file__).parent / "rules"

def parse(path) -> CclManager:
    manager = ...                         # 现有解析逻辑
    rules = rule_loader.load(RULES_DIR)
    expansion.engine.apply(manager.trees["source"], rules)
    return manager
```

每个 input format 的 parser 在产出 manager 后调用一次扩充引擎。`RULES_DIR` 在每种格式的 `parser.py` 里硬编码为同包下的 `rules/` 子目录（即 `input/ccl/rules/`），用户不可注入额外规则源（§问答阶段已敲定为内置 only）。

### 4.6 错误处理

- YAML 语法错误、保留键格式错误（如 `__type__` 没配 `__value__`）→ 加载阶段抛 `RuleLoadError`，附文件名/行号。
- 应用阶段不抛错（无匹配视为合法，记日志）。

### 4.7 日志

每应用一条规则后记一行：`rule=<name> matches=<n> nodes_added=<m>`。

## 5. Transform 层

**职责**：保留并迁移现有命令式 CRUD API，本 spec 不引入规则化变换。

迁移做法：

- `CclTtNode` / `CclTtNodes` 的实例方法（`add` / `add_val` / `add_link` / `delete` / `rename` / `retype` / `revalue` / `add_exprn`）继续留在 `core/node.py`（这些是节点对象自身的方法）。
- 自由函数 `merge` / `remove` 迁到 `transform/operations.py`。
- `transform/operations.py` 预留位置容纳未来复合操作（`move`、`replace_subtree` 等），本 spec 不实现。

外部用法不变：所有现有调用（如 `tree.get("a/d").rename("d1")`）继续工作。

## 6. Output 层

### 6.1 Writer 抽象

```python
# output/base.py
class Writer(ABC):
    @abstractmethod
    def write(self, tree: CclTtTree, include_expanded: bool = False) -> str:
        ...
```

返回字符串；写文件由调用方决定。

### 6.2 CCL Writer

迁自 `CclTtNode.transfrom(indent)` / `CclTtNodes.transfrom()`，加 `is_real` 过滤分支：

```python
class CclWriter(Writer):
    def write(self, tree, include_expanded=False):
        return self._write_node(tree.root, indent="", include_expanded=include_expanded)

    def _write_node(self, node, indent, include_expanded):
        if not include_expanded and not node.is_real():
            return ""
        # ... 原 transfrom 逻辑 ...
```

由于自动晋升机制（§3.3）保证 "父假但子真" 不会出现，"跳过假节点 + 其子树" 是正确行为。

### 6.3 Debug Printer

迁自 `CclTtNode.print(indent)` / `CclTtNodes.print()`。**默认输出全部节点**（`include_expanded=True`），并在每个 `is_real=false` 节点旁标 `[expanded]`，便于排查规则。

## 7. Manager（顶层）

```python
# manager.py
class CclManager:
    def __init__(self):
        self.db = MyDatabase()
        self.trees = {}
        self.init_tree("source")

    def init_tree(self, name): ...

    @classmethod
    def from_ccl(cls, path) -> "CclManager":
        from .input.ccl.parser import parse
        return parse(path)

    @classmethod
    def from_json(cls, path) -> "CclManager":
        from .input.json.parser import parse
        return parse(path)

    def to_ccl(self, tree_name="source", include_expanded=False) -> str:
        from .output.ccl.writer import CclWriter
        return CclWriter().write(self.trees[tree_name], include_expanded)

    def debug_print(self, tree_name="source") -> str:
        from .output.debug.printer import DebugPrinter
        return DebugPrinter().write(self.trees[tree_name])
```

兼容性：旧顶层函数 `build_tree_from_ccl` / `build_tree_from_json` 在 `manager.py` 保留为 thin wrapper 调到新接口，旧测试零改动。

## 8. 增量迁移路径

每步必须跑全套现有测试，保持绿。

1. **Schema 加 `is_real`**：`data_base.py` 加列 + 加 `is_real` 参数 + 加 `_promote_ancestors`；`build_tree` / `add_link` 增加 `is_real` 参数（默认 `True`）。
2. **目录骨架**：建 `core/` / `input/` / `output/` / `transform/` / `input/expansion/` 包；`core/` 内 re-export 旧三件套。
3. **Output 层落地**：把 `transfrom()` 复制到 `output/ccl/writer.py`、`print()` 复制到 `output/debug/printer.py`，加 `is_real` 过滤。旧方法保留。
4. **Input 层落地**：`parse_ccl_to_dict` / `build_tree_from_ccl` 迁到 `input/ccl/parser.py`，`parse_config_to_dict` / `build_tree_from_json` 迁到 `input/json/parser.py`；旧 `ccl_manager.py` 保留同名 wrapper。
5. **扩充引擎**：实现 `rule_loader` + `engine`，独立单测覆盖。先**不**接到 parser。
6. **接通扩充**：parser 末尾调 `engine.apply(...)`；规则目录暂留空（无副作用），加最小 sanity 规则 + e2e 测试。
7. **Transform 层迁移**：`merge` / `remove` 自由函数迁到 `transform/operations.py`；`ccl_tt_node.py` 重新 export 同名兼容旧导入。
8. **Manager 重写**：新 `manager.py` + `CclManager` classmethod；旧 `ccl_manager.py` 顶层函数作 wrapper。
9. **清理**：所有旧 API 都成 thin wrapper 后，把 `ccl_tt_tree.py` 的实现搬到 `core/tree.py`、`ccl_tt_node.py` 搬到 `core/node.py`、`data_base.py` 搬到 `core/database.py`，根目录下 `src/ccltt/ccl_tt_tree.py` / `ccl_tt_node.py` / `data_base.py` / `ccl_manager.py` 全部删除；调整 `src/ccltt/__init__.py` 重新导出（保持 `from ccltt import CclManager` 等老 import 路径有效）。

## 9. 测试策略

- **回归基线**：现有 `tests/test_initial.py` 完全不动，每步迁移后必须全绿。
- **新增测试**：
  - `tests/test_is_real.py` —— `is_real` 默认值、显式传 `False`、自动晋升。
  - `tests/test_expansion_loader.py` —— YAML 解析、文件配对、保留键校验、错误诊断。
  - `tests/test_expansion_engine.py` —— 类型链匹配（含 `TYPE: name` 与 `TYPE` 单例混合）、C 语义末端冗余、多锚点同时补齐、嵌套 RHS、应用两次幂等。
  - `tests/test_output_filter.py` —— `include_expanded=True/False` 输出对比；自动晋升后过滤行为。
  - `tests/test_e2e_ccl.py` —— 最小 CCL 输入 + 一个 sanity 规则的端到端。
- **快照基线**：现有 `*_output.txt`（如 `CFXPreGui_output.txt`）作 snapshot；迁移完成后用新 writer 重新生成应**逐字节相等**（前提：规则目录暂为空）。

## 10. 风险与未决项

### 风险

- **自动晋升的边界**：`add_link` 的晋升应作用于 link 的 parent 链而非 child 链；要在单测覆盖。
- **快照输出对齐**：现有 `transfrom()` 的缩进、引号、单位写法有微妙之处，新 writer 容易出微小 diff。缓解：步骤 3 完成后立即跑全部 `test_build_from_ccl_*` 比对 `*_output.txt`。
- **YAML 保留键写错**：加载阶段强校验并给清晰错误（§4.6）。

### 未决项（不在本 spec 范围）

- 转换层规则化（声明式变换 DSL）—— 独立 spec。
- JSON writer —— YAGNI。
- 扩充规则覆写已存在节点属性的能力（`__force__` 类标记）—— 待实际需求出现再加。
- 任何新的 input 格式。

## 11. 范围确认

**本 spec 包含**：

- Schema 加 `is_real` + 自动晋升
- 三层目录结构（core / input / transform / output / manager）
- Input 层：CCL parser + JSON parser 迁移 + 扩充引擎接通
- Output 层：CCL writer + Debug printer
- Transform 层：现有 CRUD API 迁移（命令式）

**本 spec 不包含**：

- JSON writer
- 转换层规则化 DSL
- 扩充规则覆写已存在节点属性的能力
- 任何新的 input 格式
