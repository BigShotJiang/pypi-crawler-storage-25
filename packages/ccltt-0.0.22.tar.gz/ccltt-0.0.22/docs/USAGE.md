# CclTt 使用文档

> 版本：`ccltt 0.0.21`（见 [src/ccltt/__about__.py](../src/ccltt/__about__.py)）
> 适用对象：需要解析、转换、扩充、回写 CCL（CFX Command Language / 自定义层级配置）的开发者与脚本作者。

`CclTt` 把 CCL 文本变成一棵在 SQLite（`:memory:`）中持久化的树，并在树上提供命令式增删改查 API。整个流程由三层组成：

1. **输入层**（`ccltt.input.*`）— 多格式输入源 → 内存树；解析完成后立刻按内置规则扩充树，扩充节点标记为 `is_real=False`。
2. **转换层**（`ccltt.core.*` + `ccltt.transform.*`）— 在树上做 CRUD、查询、合并、删除等命令式操作。
3. **输出层**（`ccltt.output.*`）— 把树序列化成 JSON 等格式，默认只输出真实节点。

> 顶层协调器是 [`ccltt.manager.CclManager`](../src/ccltt/manager.py)。架构动机与详细设计参见 [docs/superpowers/specs/2026-05-08-ccltt-three-layer-architecture-design.md](superpowers/specs/2026-05-08-ccltt-three-layer-architecture-design.md)。

---

## 目录

- [1. 安装](#1-安装)
- [2. 30 秒上手](#2-30-秒上手)
- [3. 全链路操作](#3-全链路操作)
- [4. 概念模型](#4-概念模型)
- [5. 高层 API：CclManager](#5-高层-apiCclManager)
- [6. 树 / 节点 API](#6-树--节点-api)
- [7. 输入层：CCL 解析](#7-输入层CCL-解析)
- [8. 扩充引擎与规则文件](#8-扩充引擎与规则文件)
- [9. 输出层：JSON Writer](#9-输出层json-writer)
- [10. 类型系统与单位](#10-类型系统与单位)
- [11. 路径查询与通配符](#11-路径查询与通配符)
- [12. 完整示例](#12-完整示例)
- [13. 测试与开发](#13-测试与开发)
- [14. 发布到 PyPI](#14-发布到-pypi)
- [15. 常见问题](#15-常见问题)

---

## 1. 安装

```bash
pip install ccltt
```

源码安装（开发模式）：

```bash
git clone https://github.com/Flyshde/ccltt
cd ccltt
pip install -e .
# 可选：测试依赖
pip install pytest pyyaml
```

依赖：`PyYAML>=6.0`，Python `>=3.8`。

---

## 2. 30 秒上手

```python
from ccltt import CclManager

# 1. 解析 CCL 文件，自动套用内置扩充规则
mgr = CclManager.from_ccl("path/to/sample.ccl")

# 2. 转换层：拿到 source 树并做查询
tree = mgr.trees["source"]
flow = tree.find_by_path_with_wildcard(tree.root.node_id, "FLOW")
print(flow)            # [CclTtNode (id=... name=Flow Analysis 1)]

# 3. 输出层：得到 ccl2json 形态的 JSON
print(mgr.to_json(include_expanded=False))      # 只含真实节点
print(mgr.to_json(include_expanded=True))       # 含扩充出来的脚手架
```

示例输入（[tests/fixtures/e2e_input.ccl](../tests/fixtures/e2e_input.ccl)）：

```ccl
FLOW: Flow Analysis 1
    DOMAIN: Domain 1
        Domain Type = Fluid
    END
END
```

经过解析后，`mgr.to_json()` 默认输出形如：

```json
{
    "FLOW": {
        "Flow Analysis 1": {
            "DOMAIN:Domain 1": {
                "Domain Type": "Fluid"
            }
        }
    }
}
```

---

## 3. 全链路操作

CclTt 的典型工作流是一条三段式管道：

```
        ┌────────────────┐        ┌──────────────────┐        ┌────────────────┐
.ccl ─▶ │  输入层 + 扩充 │ ─tree▶ │   转换层（修改） │ ─tree▶ │   输出层 JSON │ ─▶ .json / str
        │  CclManager    │        │   （细节后述）    │        │   to_json(...) │
        │  .from_ccl()   │        │                  │        │                │
        └────────────────┘        └──────────────────┘        └────────────────┘
```

整条链路可以**只用 `CclManager` 这一个对象**走完。中间「修改」部分先当成黑盒（实际就是在 `mgr.trees["source"]` 上调几行 CRUD），它的具体 API 会在后面 [§6 树 / 节点 API](#6-树--节点-api) 里展开。

### 3.1 推荐写法：把修改封装成函数

```python
from ccltt import CclManager


def edit(mgr: CclManager) -> None:
    """业务侧的全部修改集中在这里——读、改、删、补默认值，随你。"""
    ...   # 详见 §6（暂时当作黑盒）


def run(in_ccl: str, out_json: str) -> None:
    # 1) 输入：解析 + 自动扩充
    mgr = CclManager.from_ccl(in_ccl)

    # 2) 转换：在 source 树上做任意修改
    edit(mgr)

    # 3) 输出：只输出真实节点（隐藏扩充层脚手架）
    with open(out_json, "w", encoding="utf-8") as f:
        f.write(mgr.to_json(include_expanded=False))


run("input.ccl", "out.json")
```

关键点：

- **一次解析 = 一次扩充**：`CclManager.from_ccl` 内部已经按 [src/ccltt/input/ccl/rules/](../src/ccltt/input/ccl/rules) 跑完扩充引擎，调用方不必关心。
- **修改是可选的**：跳过 `edit(mgr)`，整条链路就退化成「CCL → JSON 转换器」。
- **输出可双形态**：同一棵树可分别得到 `include_expanded=False`（干净的业务结果）和 `include_expanded=True`（含默认值脚手架，便于审阅）两份 JSON。

### 3.2 不修改的最短链路

```python
from ccltt import CclManager

json_str = CclManager.from_ccl("input.ccl").to_json()   # 解析 + 扩充 + 序列化
```

### 3.3 修改 + 双形态输出

```python
mgr = CclManager.from_ccl("input.ccl")
edit(mgr)                                        # 业务修改（细节见 §6）

clean = mgr.to_json(include_expanded=False)      # 仅真实节点
full  = mgr.to_json(include_expanded=True)       # 含扩充脚手架
```

> 在这一阶段你只需要记住三个入口：`CclManager.from_ccl(path)` 拿管理器、`mgr.trees["source"]` 拿到要改的树、`mgr.to_json(...)` 把结果落地。修改具体怎么写、改了之后扩充节点会不会被晋升为真实节点，统一留到 [§4 概念模型](#4-概念模型) 与 [§6 树 / 节点 API](#6-树--节点-api)。

---

## 4. 概念模型

### 3.1 树、节点与数据库

- 一棵树（`CclTtTree`）= SQLite 中的一张同名表 + 公共的 `relations` 表。
- 每个节点（`CclTtNode`）= 表中一行：`id, node_name, node_type, node_value, node_exprn, is_real`。
- `CclTtNodes` 是节点集合的薄包装，链式 API 都返回它，便于批量操作。
- 一个 `CclManager` 持有共享 `MyDatabase` 与若干棵树（默认包含 `source`）。

### 3.2 节点四要素

| 字段        | 含义                                  | 例子                            |
| ----------- | ------------------------------------- | ------------------------------- |
| `name`      | 节点名                                | `Domain Type`                   |
| `type`      | 类型；典型容器类型或标量类型          | `FLOW`、`int`、`real`、`bool`   |
| `value`     | 标量/列表值（叶子节点才有）           | `"Fluid"`、`0.0001`、`[1,2,3]`  |
| `exprn`     | 单位或其它附注表达式                  | `"m/s"`、`"K"`                  |
| `is_real`   | 是否由用户/输入显式写入（vs 脚手架）  | `True`/`False`                  |

> CCL 里 `TYPE: Instance Name` 形式（如 `DOMAIN: Domain 1`）会被解析成 `type=DOMAIN, name="Domain 1", value=None` 的“容器节点”；裸 `TYPE` 形式（如 `FLOW`）会被解析成 `name=FLOW, type=None` 的“单例节点”。扩充引擎按这个规则匹配。

### 3.3 `is_real` 与自动晋升

- 解析时显式存在的节点 → `is_real=True`。
- 扩充引擎按规则补出来的脚手架 → 默认 `is_real=False`，除非 YAML 里写了 `__is_real__: true`。
- 在某个 `is_real=False` 节点下显式创建子节点时，该节点及其祖先链会被自动晋升为 `True`（`MyDatabase._promote_ancestors`）。
- JSON 输出默认丢弃 `is_real=False` 子树（`include_expanded=False`）。

---

## 5. 高层 API：CclManager

`from ccltt import CclManager` 始终拿到 [src/ccltt/manager.py](../src/ccltt/manager.py) 中的新版协调器：

| 方法 | 作用 |
| ---- | ---- |
| `CclManager()` | 新建一个空管理器，自动初始化名为 `source` 的空树。 |
| `init_tree(name)` | 新建一棵命名树（注意 `name` 必须是合法的 SQL 标识符；中文/空格不可用作树名）。 |
| `CclManager.from_ccl(path)` | 解析 `.ccl` 文件并跑扩充引擎，返回管理器。 |
| `CclManager.from_json(path)` | 暂未实现（`NotImplementedError`）。 |
| `to_json(tree_name="source", include_expanded=None, indent=4, schema="ccl2json")` | 序列化为 JSON 字符串。`schema` 取 `"ccl2json"`（默认）或 `"tree"`。 |
| `to_ccl(...)` / `debug_print(...)` | 占位 API，目前抛 `NotImplementedError`。 |

`to_json` 的 `include_expanded` 默认值由 `schema` 决定：

- `schema="ccl2json"` → 默认 `True`，保留扩充脚手架；
- `schema="tree"` → 默认 `False`，仅输出真实节点。
显式传参可覆盖默认值。

---

## 6. 树 / 节点 API

> 这是转换层的命令式 CRUD 接口，定义在 [src/ccltt/core/tree.py](../src/ccltt/core/tree.py) 与 [src/ccltt/core/node.py](../src/ccltt/core/node.py)。

### 5.1 拿到根

```python
tree = mgr.trees["source"]
root = tree.ROOT()      # CclTtNodes，包含单个 root 节点
root.name()             # "root"
```

### 5.2 增加子节点（目录式）

```python
root.add("a/w")             # 多级路径自动建中间节点
root.add("a/df/ccc")
root.add("a/df/cb")
```

返回 `True/False`：路径上若存在“已带值的叶子”则失败。

### 5.3 增加带值节点

```python
node = root.get("a/d")
node.add_val("d1", True)     # bool
node.add_val("d2", "hello")  # str
node.add_val("d3", 0)        # int
node.add_val("d4", 1.0)      # real
node.add_val("d5", [1, 2])   # int list
node.add_val("d6", [1.0,2])  # real list
```

类型推断规则：

| Python 值 | 入库 type |
| --------- | --------- |
| `bool` | `bool` |
| `str` | `str` |
| `int` | `int` |
| `float` | `real` |
| `list[int]` | `int list` |
| `list[float]` | `real list` |

### 5.4 取值 / 改值 / 改名 / 改类型

```python
node = root.get("a/d3")
node.value()                # 字符串形式（注：DB 内值统一以 TEXT 存储）
node.type()                 # "int"
node.retype("real")
node.revalue(1.5)
node.rename("d3_new")
```

### 5.5 加链接（别名引用）

```python
target = root.get("a/d")
holder = root.get("a/w")
holder.add_link(target, "link_to_d")     # 在 a/w 下挂一个别名子节点
holder.get("link_to_d")
```

`add_link` 不会复制子树，只在 `relations` 表里插入一条 `relation_type='link'` 的关系，遍历时按 `alias` 命名显示。

### 5.6 复制整棵子树

```python
src_node = root.get("a/d")
dst_node = root.get("a/w")
dst_node.add(src_node)       # 深拷贝；可跨树拷贝
```

### 5.7 删除

```python
root.get("a/df").delete()           # 删除节点及全部子节点
root.get("a").delete("ddg/ca")      # 等价于 a.get("ddg/ca").delete()
```

### 5.8 表达式 / 单位

带单位的标量在解析 CCL 时会自动填 `exprn`，例如 `r0 = 90[mm]` → `value="90", exprn="mm", type="int"`。

也可以手动设置：

```python
root.get("a/d4").add_exprn("m/s")
```

### 5.9 集合操作：merge / remove

```python
from ccltt import merge, remove

a = root.get("a/df/c*")
b = root.get("a/ddg/c*")
union = merge(a, b)           # 并集
diff  = remove(union, b)      # 差集（a - b）
```

---

## 7. 输入层：CCL 解析

[src/ccltt/input/ccl/parser.py](../src/ccltt/input/ccl/parser.py) 是 CCL 入口：

```python
from ccltt.input.ccl.parser import parse

mgr = parse("path/to/sample.ccl")    # 返回新版 CclManager
tree = mgr.trees["source"]
```

`parse(...)` 的处理流程：

1. 读取文件，跑预处理：
   - 删除 `#` 起始的行尾注释；
   - 合并以 `\` 结尾的续行。
2. 行式词法（`_legacy_parsers.parse_ccl_to_dict`）识别四类语句：
   - `TYPE: Instance Name` → 容器节点入栈。
   - `TYPE` `END` 配对 → 单例节点。
   - `Name = value` → 标量赋值。
   - 单 `END` → 出栈。
3. 把字典递归塞进 `CclTtTree`。
4. 加载 `src/ccltt/input/ccl/rules/*.expanded.yaml`，调用扩充引擎补出脚手架。

### 6.1 标量值识别（重要）

CCL 行右侧 `value` 会被分类成下列形式之一：

| 形式 | 例子 | 入库 `type`、`value`、`exprn` |
| ---- | ---- | ------------------------------ |
| `bool` | `Flag = True` | `bool, "True", —` |
| `int`  | `N = 10` | `int, "10", —` |
| `real` | `R = 0.5`、`R = 1e-5` | `real, "0.5"/"1e-05", —` |
| `int` + 单位 | `n = 5[—]` | `int, "5", "—"` |
| `real` + 单位 | `r0 = 90[mm]` | `int, "90", "mm"`（注：整数字面量保持 `int` 类型；带小数才识别为 `real`） |
| 列表（无单位） | `Data Pairs = 0,100,9610,90` | `int list/real list/str list, [...]` |
| 列表（带单位） | `R = 1[m], 2[m]` | `int list/real list/str list, [...], [...]` |
| 表达式 / 其它 | 任何不能匹配上面正则的右值 | 视为 `str` |

### 6.2 兼容路径：`build_tree_from_ccl`

`from ccltt import build_tree_from_ccl` 是 0.0.x 旧版直接调用的解析函数（不跑扩充引擎），保留用于回归测试或对比：

```python
from ccltt import build_tree_from_ccl
legacy = build_tree_from_ccl("sample.ccl")
```

新代码请优先用 `CclManager.from_ccl(...)` 或 `parse(...)`。

---

## 8. 扩充引擎与规则文件

扩充（expansion）= 在解析完的树上，按规则补出业务上“应该有但用户没写”的节点，作为提示/默认值。引擎位于 [src/ccltt/input/expansion/](../src/ccltt/input/expansion)，规则文件放在 [src/ccltt/input/ccl/rules/](../src/ccltt/input/ccl/rules)。

### 7.1 规则文件命名

```
src/ccltt/input/ccl/rules/
  FLOW.expanded.yaml
  LIBRARY.expanded.yaml
```

- 文件名形如 `<ANCHOR>.expanded.yaml`。
- `<ANCHOR>` = 树根的一个直接子节点的类型名（容器用 `node_type`，单例用 `node_name`）。
- 若 anchor 尚不存在，引擎会**创建一个 `is_real=False` 的占位 anchor** 再向下铺规则。

### 7.2 规则文件结构

YAML 顶层是一个 mapping。键是子节点名/类型；值是嵌套 mapping，可包含保留字段：

| 保留字段 | 含义 |
| -------- | ---- |
| `__type__` | 节点类型（标量类型如 `int`/`real`/`bool`/`str`，或容器类型名） |
| `__value__` | 默认值 |
| `__unit__` | 单位（写入 `exprn`） |
| `__is_real__` | 是否真实节点。`true` 时新节点为真实，并自动晋升祖先链；缺省 / `false` 视为脚手架 |

示例（节选自 [FLOW.expanded.yaml](../src/ccltt/input/ccl/rules/FLOW.expanded.yaml)）：

```yaml
ANALYSIS_TYPE:
  Restart:
    __is_real__: true
    Dump_Data_for_Restart:
      __is_real__: true
      Dump_Data_for_Restart:
        __value__: true
        __type__: bool
        __is_real__: true
      Restart_Dump_Dirname:
        __value__: CheckPoint
        __type__: str
        __is_real__: true
```

### 7.3 引擎语义

- **Idempotent**：重复运行不会重复创建已有节点。
- **不覆盖已有属性**：若节点已经存在，引擎只会向下递归 reconciliate，不会改写 `value/type`。
- **晋升**：往 `is_real=False` 节点下显式写真实节点时，祖先链都会被晋升。
- **多实例**：若 anchor 下存在多个同类型实例（例如多个 `DOMAIN`），规则会分别套到每个实例上。

### 7.4 自定义规则路径

测试或脚本想用自己一套规则时，临时替换 `RULES_DIR`：

```python
from pathlib import Path
from ccltt.input.ccl import parser as ccl_parser

ccl_parser.RULES_DIR = Path("/path/to/my_rules")
mgr = ccl_parser.parse("sample.ccl")
```

也可以让规则目录为空 → 等价于纯解析、不扩充。

---

## 9. 输出层：JSON Writer

[src/ccltt/output/json/writer.py](../src/ccltt/output/json/writer.py) 提供两种 schema：

### 8.1 `schema="ccl2json"`（默认）

形态贴近原 CCL：

- 顶层容器节点 → 用 `node_type` 作 key（例如 `"FLOW"`）。
- 子层容器 → key 形如 `"DOMAIN:Domain 1"`。
- 单例容器 → 用名字作 key（例如 `"ANALYSIS_TYPE"`）。
- 标量叶子 → 直接是 JSON scalar；若带单位，输出形如 `"90[mm]"`。
- 列表叶子 → JSON 数组；列表+单位形如 `["1[m]", "2[m]"]`。

```python
from ccltt.output.json.writer import JsonWriter

JsonWriter().write(tree)                              # 默认 ccl2json + 含脚手架
JsonWriter().write(tree, include_expanded=False)      # 只输出真实节点
JsonWriter().write(tree, indent=None)                 # 单行紧凑
```

### 8.2 `schema="tree"`（调试形态）

每个节点 → `{"name": "...", "type": "...", "value": ..., "exprn": ..., "children": [...]}`。

- `name` 自动转为 snake_case；
- 默认 `include_expanded=False`，扩充节点被裁剪掉；
- 适合调试、diff、回归比对。

```python
JsonWriter().write(tree, schema="tree")                       # 默认丢弃 is_real=False
JsonWriter().write(tree, schema="tree", include_expanded=True)
```

### 8.3 命名风格工具

[src/ccltt/output/name_style.py](../src/ccltt/output/name_style.py) 暴露三种风格：`original / snake / camel`。`tree` schema 内部固定走 snake；`ccl2json` schema 保留原始名以便回写。

如果要自行做 key 转换：

```python
from ccltt.output.name_style import to_snake, to_camel
to_snake("Flow Analysis 1")        # "flow_analysis_1"
to_camel("mesh_importation_param") # "meshImportationParam"
```

---

## 10. 类型系统与单位

| `type`        | 入库形式 (`value`) | 在 ccl2json 输出  | 备注                          |
| ------------- | ------------------ | ----------------- | ----------------------------- |
| `bool`        | `"True"`/`"False"` | `true`/`false`    | 输出时还原成布尔              |
| `int`         | `"123"`            | `123`             |                               |
| `real`        | `"0.0001"`         | `0.0001`          |                               |
| `str`         | `"Fluid"`          | `"Fluid"`         |                               |
| `int list`    | JSON 字符串        | `[1, 2, 3]`       | 数据库里以 JSON 文本存储      |
| `real list`   | JSON 字符串        | `[1.0, 2.0]`      |                               |
| `str list`    | JSON 字符串        | `["a", "b"]`      | 来自逗号分隔的非数值列表      |
| 容器          | `value=None`       | 嵌套对象          | 类型为大写枚举名，如 `FLOW`   |

带单位的标量在 `ccl2json` schema 下序列化成形如 `"<value>[<unit>]"` 的字符串；带单位列表则是字符串列表。

---

## 11. 路径查询与通配符

`tree.find_by_path_with_wildcard(start_id, path)` 接收 `/` 分隔的层级路径，每段支持 `fnmatch` 通配符：

- `*` 任意字符。
- `?` 单字符。
- `[abc]` 字符集。

匹配会同时尝试 `node_name` 和 `node_type`，所以对容器节点既可以用实例名 `"Flow Analysis 1"` 也可以用类型名 `"FLOW"`。

`CclTtNodes.get(path)`：

```python
root.get("FLOW/*/INITIALISATION/LOCAL_INITIAL_CONDITIONS")
root.get("a/df/c*")
```

返回 `CclTtNodes` 或 `None`（无匹配时）。注意 `get` 返回的是新集合，多次链式 `get` 会做笛卡尔展开。

---

## 12. 完整示例

### 11.1 解析 + 修改 + 写回 JSON

```python
from ccltt import CclManager

mgr = CclManager.from_ccl("ccl2json/物理量类型/CASE2202-cfd-xxxapp-0003-sx.ccl")
tree = mgr.trees["source"]
root = tree.ROOT()

# 改一个真实节点的值
node = root.get("FLOW/SOLVER_CONTROL/EQUATION_GROUPS_RESIDUAL_SETTINGS/MOMENTUM/Residual_Target")
if node is not None:
    node.revalue(1e-6)

# 看看扩充层都补了什么
print(mgr.to_json(include_expanded=True))

# 只保留真实节点写回
with open("out.json", "w", encoding="utf-8") as f:
    f.write(mgr.to_json(include_expanded=False))
```

### 11.2 从零构建一棵树并输出

```python
from ccltt import CclManager
from ccltt.output.json.writer import JsonWriter

mgr = CclManager()
tree = mgr.trees["source"]

flow_id = tree.build_tree(parent_id=tree.root.node_id, name="Flow Analysis 1", ty="FLOW")
tree.build_tree(parent_id=flow_id, name="Domain Type", ty="str", value="Fluid")

print(JsonWriter().write(tree))
# {
#     "FLOW": {
#         "Flow Analysis 1": {
#             "Domain Type": "Fluid"
#         }
#     }
# }
```

### 11.3 自定义扩充规则

```python
# my_rules/FLOW.expanded.yaml
# ContactInfo:
#   __is_real__: true
#   gap:
#     __value__: 1e-05
#     __type__: real
#     __is_real__: true

from pathlib import Path
from ccltt.input.ccl import parser as ccl_parser

ccl_parser.RULES_DIR = Path("my_rules")
mgr = ccl_parser.parse("tests/fixtures/e2e_input.ccl")
gap = mgr.trees["source"].find_by_path_with_wildcard(1, "FLOW/ContactInfo/gap")[0]
print(gap.value(), gap.exprn(), gap.is_real())   # 1e-05 None True
```

### 11.4 跨树拷贝子树

```python
mgr = CclManager()
src  = mgr.trees["source"]
tgt  = mgr.init_tree("target")

src_root = src.ROOT()
src_root.add("a/d/c")
src_root.get("a/d").add_val("d1", 1.0)

tgt.ROOT().add(src_root.get("a/d"))   # 深拷贝到 target 树
print(tgt.ROOT().print())
```

---

## 13. 测试与开发

```bash
# 跑全部测试
pytest -v

# 只跑 e2e
pytest tests/test_e2e_ccl.py -v

# 跑示例 CCL 上的扩充验证（参数化）
pytest tests/test_ccl2json_expansion.py -v
```

测试约定见 [tests/conftest.py](../tests/conftest.py)：

- 输入放 `tests/fixtures/inputs/`；
- 产物写到 `tests/outputs/`（gitignored，仅 `.gitkeep` 入库）。

类型检查（hatch 环境定义在 `pyproject.toml`）：

```bash
hatch run types:check
```

---

## 14. 发布到 PyPI

仓库自带一键脚本 [upload_package.py](../upload_package.py)：

```bash
export PYPI_TOKEN="pypi-..."   # 也支持 HATCH_INDEX_AUTH
python upload_package.py
```

脚本会依次：清理缓存 → 跑 `tests/test_initial.py` → `python -m build` → `twine upload` → 轮询 PyPI 验证版本号。

版本号源 = [src/ccltt/__about__.py](../src/ccltt/__about__.py) 的 `__version__`，由 `hatch` 在打包时读出。

---

## 15. 常见问题

**Q: `CclManager.from_json` 报 `NotImplementedError`？**
A: JSON 输入和 CCL 回写、调试打印目前都是占位 API。短期内仍需用 `from_ccl(...)` + `to_json(...)`。

**Q: `init_tree("中文名")` 抛 `非法的表名`。**
A: 树名直接当 SQL 表名拼接，必须满足 `str.isidentifier()`。请使用 ASCII 字母数字+下划线。

**Q: `to_json(include_expanded=False)` 为什么还能看到一些“看着像默认值”的节点？**
A: 规则文件里 `__is_real__: true` 的节点会被视为“业务上必须存在”，即使原 CCL 未写，也会被序列化。需要严格区分用户输入与默认值时，可让规则用默认 `__is_real__: false` 或 omit。

**Q: 列表节点出现奇怪的 `1[unitless]`？**
A: CCL 形如 `Data = ,1,,2` 这类残缺写法会进入“列表+单位”分支，缺值用 `1` 填充。建议在源 CCL 里规整化空字段。

**Q: 怎么调试一棵树？**
A: 用 `root.print()` 拿到层级文本；用 `JsonWriter().write(tree, schema="tree", include_expanded=True)` 拿到带 `is_real`/`type` 的完整 JSON。

**Q: 多个同类型实例（如多个 `DOMAIN`）会被扩充规则覆盖到吗？**
A: 会。引擎对 anchor 下匹配到的所有同类型节点都会递归 reconcile。

---

如需进一步深入，请阅读：

- 设计文档：[docs/superpowers/specs/2026-05-08-ccltt-three-layer-architecture-design.md](superpowers/specs/2026-05-08-ccltt-three-layer-architecture-design.md)
- 实施计划：[docs/superpowers/plans/2026-05-08-ccltt-three-layer-architecture.md](superpowers/plans/2026-05-08-ccltt-three-layer-architecture.md)
- 端到端示例：[tests/test_e2e_ccl.py](../tests/test_e2e_ccl.py)、[tests/test_ccl2json_expansion.py](../tests/test_ccl2json_expansion.py)
