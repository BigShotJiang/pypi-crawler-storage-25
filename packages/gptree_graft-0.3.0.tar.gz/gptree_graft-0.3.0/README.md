# GPTree Graft

Unified local client that grafts GPTree agent runtimes onto your machine.

The runtime registry can host:

- `pentest` - existing PentestGPT integration
- `code` - Claude-Code-style local coding runtime
- `openclaw` - OpenClaw-compatible runtime

```bash
GPTREE_TOKEN=pt_... gptree-graft
GPTREE_TOKEN=pt_... gptree-graft --runtime pentest
```

Legacy aliases remain available for the runtime-specific entry points:

```bash
pentestgpt-bridge
openclaw-bridge
```
