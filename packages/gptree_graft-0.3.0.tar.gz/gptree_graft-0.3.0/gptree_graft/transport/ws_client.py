"""Pusher-compatible WebSocket client for GPTree bridge work dispatch."""

from __future__ import annotations

import asyncio
import json
import logging
import ssl
from typing import Awaitable, Callable, Optional

import httpx
import websockets

logger = logging.getLogger(__name__)


class WsClient:
    def __init__(
        self,
        gptree_url: str,
        token: str,
        ws_host: str,
        ws_port: int,
        ws_key: str,
        ws_scheme: str = "wss",
        channel: str = "",
        on_work: Optional[Callable[[dict], Awaitable[None]]] = None,
        on_session_action: Optional[Callable[[dict], Awaitable[None]]] = None,
        verify_ssl: bool = True,
        ssl_context: Optional[ssl.SSLContext] = None,
        api_prefix: str = "bridge",
    ):
        self.gptree_url = gptree_url.rstrip("/")
        self.token = token
        self.ws_host = ws_host
        self.ws_port = ws_port
        self.ws_key = ws_key
        self.ws_scheme = ws_scheme
        self.channel = channel
        self.on_work = on_work
        self.on_session_action = on_session_action
        self.verify_ssl = verify_ssl
        self.ssl_context = ssl_context
        self.api_prefix = api_prefix.strip("/")
        self._ws = None
        self._socket_id: Optional[str] = None
        self._running = False
        self._backoff = 1

    @property
    def ws_url(self) -> str:
        return f"{self.ws_scheme}://{self.ws_host}:{self.ws_port}/app/{self.ws_key}"

    async def connect(self) -> None:
        self._running = True
        while self._running:
            try:
                await self._connect_once()
            except (websockets.ConnectionClosed, ConnectionError, OSError) as exc:
                if not self._running:
                    break
                logger.warning("Connection lost: %s. Reconnecting in %ds...", exc, self._backoff)
                await asyncio.sleep(self._backoff)
                self._backoff = min(self._backoff * 2, 60)
            except Exception as exc:
                if not self._running:
                    break
                logger.error("Unexpected WebSocket error: %s. Reconnecting in %ds...", exc, self._backoff)
                await asyncio.sleep(self._backoff)
                self._backoff = min(self._backoff * 2, 60)

    async def _connect_once(self) -> None:
        connect_kwargs = {}
        if self.ws_scheme == "wss":
            connect_kwargs["ssl"] = self.ssl_context or True

        async with websockets.connect(self.ws_url, **connect_kwargs) as ws:
            self._ws = ws
            self._backoff = 1

            raw = await ws.recv()
            msg = json.loads(raw)
            if msg.get("event") != "pusher:connection_established":
                raise ConnectionError(f"Expected connection_established, got: {msg}")

            data = json.loads(msg.get("data", "{}"))
            self._socket_id = data.get("socket_id")
            await self._subscribe()

            ping_task = asyncio.create_task(self._ping_loop(ws))
            try:
                await self._listen(ws)
            finally:
                ping_task.cancel()

    async def _subscribe(self) -> None:
        if not self.channel:
            raise ConnectionError("No channel name provided. Bootstrap may have failed.")

        async with httpx.AsyncClient(verify=self.verify_ssl) as client:
            resp = await client.post(
                f"{self.gptree_url}/api/{self.api_prefix}/broadcasting/auth",
                headers={"Authorization": f"Bearer {self.token}", "Content-Type": "application/json"},
                json={"socket_id": self._socket_id, "channel_name": self.channel},
            )
            if resp.status_code != 200:
                raise ConnectionError(f"Broadcasting auth failed: HTTP {resp.status_code}")

            auth_data = resp.json()

        await self._ws.send(json.dumps({
            "event": "pusher:subscribe",
            "data": {"channel": self.channel, "auth": auth_data["auth"]},
        }))

        raw = await self._ws.recv()
        msg = json.loads(raw)
        if msg.get("event") == "pusher_internal:subscription_succeeded":
            logger.info("Subscribed to %s", self.channel)
        else:
            logger.warning("Unexpected subscription response: %s", msg)

    async def _listen(self, ws) -> None:
        async for raw in ws:
            try:
                msg = json.loads(raw)
                event = msg.get("event", "")
                data = json.loads(msg.get("data", "{}")) if isinstance(msg.get("data"), str) else msg.get("data", {})

                if event == "pusher:pong":
                    continue
                if event in ("work.dispatched", "bridge.work.dispatched") and self.on_work:
                    asyncio.create_task(self.on_work(data))
                elif event in ("session.action", "bridge.session.action") and self.on_session_action:
                    asyncio.create_task(self.on_session_action(data))
                elif event == "pusher:error":
                    logger.error("WebSocket error: %s", msg.get("data"))
            except json.JSONDecodeError:
                logger.warning("Non-JSON message: %s", raw[:200])
            except Exception as exc:
                logger.error("Error processing message: %s", exc)

    async def _ping_loop(self, ws) -> None:
        while True:
            await asyncio.sleep(30)
            try:
                await ws.send(json.dumps({"event": "pusher:ping", "data": {}}))
            except Exception:
                break

    async def disconnect(self) -> None:
        self._running = False
        if self._ws:
            await self._ws.close()
