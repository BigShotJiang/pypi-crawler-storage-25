"""HTTP client for posting runtime results back to GPTree."""

from __future__ import annotations

import asyncio
import logging
from typing import Any, Optional

import httpx

logger = logging.getLogger(__name__)


class HttpPoster:
    def __init__(
        self,
        gptree_url: str,
        token: str,
        timeout: float = 30.0,
        verify_ssl: bool = True,
        api_prefix: str = "bridge",
    ):
        self.gptree_url = gptree_url.rstrip("/")
        self.token = token
        self.timeout = timeout
        self.verify_ssl = verify_ssl
        self.api_prefix = api_prefix.strip("/")

    def _headers(self) -> dict:
        return {
            "Authorization": f"Bearer {self.token}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        }

    def _url(self, path: str) -> str:
        return f"{self.gptree_url}/api/{self.api_prefix}/{path.lstrip('/')}"

    @staticmethod
    def _retry_delay_seconds(response: httpx.Response, attempt: int) -> float:
        """Honor Retry-After when present; otherwise exponential backoff (capped)."""
        retry_after = response.headers.get("Retry-After")
        if retry_after is not None:
            try:
                return min(60.0, max(0.25, float(retry_after)))
            except ValueError:
                pass
        return min(60.0, 0.35 * (2**attempt))

    async def post_stream_chunk(
        self,
        request_id: str,
        chunk_type: str,
        chunk_data: dict,
        is_final: bool = False,
    ) -> bool:
        payload = {
            "request_id": request_id,
            "chunk_type": chunk_type,
            "chunk_data": chunk_data,
            "is_final": is_final,
        }
        return await self._post_json_with_429_retry("stream-chunk", payload, label="stream-chunk")

    async def post_complete_request(
        self,
        request_id: str,
        response: str,
        metadata: Optional[dict] = None,
    ) -> bool:
        payload = {
            "request_id": request_id,
            "response": response,
            "metadata": metadata or {},
        }
        return await self._post_json_with_429_retry("complete-request", payload, label="complete-request")

    async def post_heartbeat(
        self,
        instance_id: str,
        name: str,
        version: str,
        capabilities: Optional[dict] = None,
    ) -> Optional[dict]:
        try:
            async with httpx.AsyncClient(timeout=10.0, verify=self.verify_ssl) as client:
                resp = await client.post(
                    self._url("heartbeat"),
                    headers=self._headers(),
                    json={
                        "instance_id": instance_id,
                        "name": name,
                        "version": version,
                        "capabilities": capabilities or {},
                    },
                )
                if resp.status_code == 200:
                    return resp.json()
                logger.warning("heartbeat failed: %d", resp.status_code)
                return None
        except Exception as exc:
            logger.error("heartbeat error: %s", exc)
            return None

    async def post_tool_ack(self, request_id: str, tool_use_id: str) -> bool:
        """Acknowledge a tool_use_id server-side before executing locally (two-phase tool contract)."""
        return await self._post_json_with_429_retry(
            "tool-ack",
            {"request_id": request_id, "tool_use_id": tool_use_id},
            label="tool-ack",
        )

    async def get_permission_decision(self, request_id: str, tool_use_id: str) -> Optional[dict]:
        params = {"request_id": request_id, "tool_use_id": tool_use_id}
        return await self._get_json_with_429_retry("permission-decision", params)

    async def _post_json_with_429_retry(self, path: str, json_body: dict, *, label: str) -> bool:
        max_attempts = 8
        try:
            async with httpx.AsyncClient(timeout=self.timeout, verify=self.verify_ssl) as client:
                for attempt in range(max_attempts):
                    resp = await client.post(
                        self._url(path),
                        headers=self._headers(),
                        json=json_body,
                    )
                    if resp.status_code == 200:
                        return True
                    if resp.status_code == 429 and attempt < max_attempts - 1:
                        delay = self._retry_delay_seconds(resp, attempt)
                        logger.warning("%s rate limited (HTTP 429), retry in %.1fs", label, delay)
                        await asyncio.sleep(delay)
                        continue
                    logger.error("%s failed: HTTP %d", label, resp.status_code)
                    return False
        except Exception as exc:
            logger.error("%s error: %s", label, exc)
            return False
        return False

    async def _get_json_with_429_retry(self, path: str, params: dict[str, Any]) -> Optional[dict]:
        max_attempts = 8
        try:
            async with httpx.AsyncClient(timeout=10.0, verify=self.verify_ssl) as client:
                for attempt in range(max_attempts):
                    resp = await client.get(
                        self._url(path),
                        headers=self._headers(),
                        params=params,
                    )
                    if resp.status_code == 200:
                        return resp.json()
                    if resp.status_code == 429 and attempt < max_attempts - 1:
                        delay = self._retry_delay_seconds(resp, attempt)
                        logger.warning("permission-decision rate limited (HTTP 429), retry in %.1fs", delay)
                        await asyncio.sleep(delay)
                        continue
                    logger.warning("permission-decision failed: %d", resp.status_code)
                    return None
        except Exception as exc:
            logger.error("permission-decision error: %s", exc)
            return None
        return None

    async def get_pending_requests(self, instance_id: str | None = None, runtimes: list[str] | None = None) -> list[dict]:
        params: dict[str, Any] = {}
        if instance_id:
            params["instance_id"] = instance_id
        if runtimes:
            # Server already filters by what the heartbeat advertised; the
            # explicit param is a belt-and-braces hint for HTTP-only flows
            # that may have skipped the heartbeat path.
            params["runtimes"] = ",".join(runtimes)
        try:
            async with httpx.AsyncClient(timeout=10.0, verify=self.verify_ssl) as client:
                resp = await client.get(
                    self._url("pending-requests"),
                    headers=self._headers(),
                    params=params or None,
                )
                if resp.status_code == 200:
                    data = resp.json()
                    requests = data.get("requests", [])
                    return requests if isinstance(requests, list) else []
                if resp.status_code == 429:
                    retry_after = resp.headers.get("Retry-After")
                    logger.warning("pending-requests rate limited%s", f" (retry after {retry_after}s)" if retry_after else "")
                    return []
                logger.warning("pending-requests failed: %d", resp.status_code)
                return []
        except Exception as exc:
            logger.error("pending-requests error: %s", exc)
            return []
