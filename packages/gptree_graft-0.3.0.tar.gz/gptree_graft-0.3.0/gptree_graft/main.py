"""GPTree Bridge - unified local client for GPTree runtimes."""

from __future__ import annotations

import argparse
import asyncio
import hashlib
import logging
import os
import platform
import signal
import ssl
import sys
from collections import OrderedDict

import httpx

from . import __version__
from .config import BridgeConfig
from .runtimes.code import CodeRuntime
from .runtimes.browser import BrowserRuntime
from .runtimes.openclaw import OpenClawRuntime
from .runtimes.pentest import PentestRuntime
from .runtimes.registry import RuntimeRegistry
from .transport.http_poster import HttpPoster
from .transport.ws_client import WsClient

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
logger = logging.getLogger(__name__)


class Bridge:
    def __init__(self, config: BridgeConfig):
        self.config = config
        self.instance_id = config.instance_id or self._stable_instance_id(config)
        self.poster = HttpPoster(
            config.gptree_url,
            config.gptree_token,
            verify_ssl=config.verify_ssl,
            api_prefix=config.api_prefix,
        )
        self.runtimes = RuntimeRegistry()
        self.ws_client: WsClient | None = None
        self._running = False
        # OrderedDict gives true insertion-order LRU eviction. The earlier
        # set+slice was nondeterministic — set ordering is unspecified, so
        # `list(self._handled_request_ids)[-250:]` kept a random 250
        # instead of the most recent 250. Bound is the same (500); behaviour
        # is now what the comment claims.
        self._handled_request_ids: "OrderedDict[str, None]" = OrderedDict()
        self._register_runtimes()

    @staticmethod
    def _stable_instance_id(config: BridgeConfig) -> str:
        workspace = os.path.abspath(os.path.expanduser(config.workspace_dir))
        basis = "|".join([
            platform.node() or "unknown-host",
            config.instance_name,
            config.runtime,
            ",".join(sorted(config.enabled_runtimes)),
            workspace,
        ])
        digest = hashlib.sha256(basis.encode("utf-8")).hexdigest()[:8]
        return f"{config.instance_id_prefix}-{digest}"

    def _register_runtimes(self) -> None:
        for runtime in self.config.enabled_runtimes:
            if runtime == "pentest":
                self.runtimes.register(PentestRuntime(self.config, self.poster))
            elif runtime == "code":
                self.runtimes.register(CodeRuntime(self.config, self.poster))
            elif runtime == "browser":
                self.runtimes.register(BrowserRuntime(self.config, self.poster))
            elif runtime == "openclaw":
                self.runtimes.register(OpenClawRuntime(self.config, self.poster))
            else:
                logger.warning("Unknown runtime configured: %s", runtime)

    async def _bootstrap(self) -> None:
        if not self.config.needs_bootstrap:
            logger.info("WebSocket config provided via env — skipping bootstrap.")
            return

        prefix = self.config.api_prefix.strip().strip("/") or "bridge"
        url = f"{self.config.gptree_url.rstrip('/')}/api/{prefix}/bootstrap"
        try:
            async with httpx.AsyncClient(verify=self.config.verify_ssl) as client:
                resp = await client.get(
                    url,
                    headers={
                        "Authorization": f"Bearer {self.config.gptree_token}",
                        "Accept": "application/json",
                    },
                )
                if resp.status_code != 200:
                    logger.error("Bootstrap failed: HTTP %d", resp.status_code)
                    sys.exit(1)
                self.config.apply_bootstrap(resp.json())
                logger.info("Bootstrap OK — user_id=%s, channel=%s", self.config.user_id, self.config.channel)
        except httpx.ConnectError as exc:
            logger.error("Cannot reach GPTree at %s: %s", self.config.gptree_url, exc)
            sys.exit(1)
        except Exception as exc:
            logger.error("Bootstrap error: %s", exc)
            sys.exit(1)

    async def start(self) -> None:
        if not self.config.gptree_token:
            logger.error("GPTREE_TOKEN is required. Generate one in GPTree Settings.")
            sys.exit(1)

        url = self.config.gptree_url.lower()
        if url.startswith("http://") and not any(h in url for h in ("localhost", "127.0.0.1", "0.0.0.0", "[::1]")):
            logger.warning("WARNING: GPTREE_URL uses http:// for a remote host. Use https:// instead.")

        await self._bootstrap()

        if not self.config.ws_key:
            logger.error("Could not determine WebSocket key. Set WS_KEY env or check your token.")
            sys.exit(1)

        ssl_context = None
        if self.config.ws_scheme == "wss":
            ssl_context = ssl.create_default_context()
            if not self.config.verify_ssl:
                ssl_context.check_hostname = False
                ssl_context.verify_mode = ssl.CERT_NONE

        self.ws_client = WsClient(
            gptree_url=self.config.gptree_url,
            token=self.config.gptree_token,
            ws_host=self.config.ws_host,
            ws_port=self.config.ws_port,
            ws_key=self.config.ws_key,
            ws_scheme=self.config.ws_scheme,
            channel=self.config.channel,
            on_work=self.handle_work,
            on_session_action=self.handle_session_action,
            verify_ssl=self.config.verify_ssl,
            ssl_context=ssl_context,
            api_prefix=self.config.api_prefix,
        )

        self._running = True
        logger.info("GPTree Bridge starting...")
        logger.info("  GPTree URL: %s", self.config.gptree_url)
        logger.info("  Runtimes: %s", ", ".join(self.runtimes.names()))
        logger.info("  Active runtime: %s", self.config.runtime)
        logger.info("  Instance ID: %s", self.instance_id)
        logger.info("  Workspace: %s", self.config.workspace_dir)

        await asyncio.gather(self.ws_client.connect(), self._heartbeat_loop(), self._pending_work_loop())

    async def handle_work(self, data: dict) -> None:
        request_id = data.get("request_id")
        target_instance_id = data.get("target_instance_id") or (data.get("session_config") or {}).get("target_instance_id")
        if target_instance_id and target_instance_id != self.instance_id:
            logger.info("Ignoring work %s targeted at bridge %s", request_id, target_instance_id)
            return
        if request_id and request_id in self._handled_request_ids:
            logger.info("Ignoring duplicate work request %s", request_id)
            return
        if request_id:
            self._handled_request_ids[request_id] = None
            # Bound the cache: evict the oldest entries once we exceed 500.
            while len(self._handled_request_ids) > 500:
                self._handled_request_ids.popitem(last=False)

        runtime_name = data.get("runtime") or self.config.runtime
        if not self.runtimes.has(runtime_name):
            await self.poster.post_complete_request(
                request_id=request_id,
                response=f"Runtime [{runtime_name}] is not available on this bridge.",
                metadata={"runtime": runtime_name, "status": "unavailable"},
            )
            return

        await self.runtimes.get(runtime_name).handle_work(data)

    async def handle_session_action(self, data: dict) -> None:
        runtime_name = data.get("runtime") or self.config.runtime
        if self.runtimes.has(runtime_name):
            await self.runtimes.get(runtime_name).handle_session_action(data)

    async def _heartbeat_loop(self) -> None:
        while self._running:
            await self.poster.post_heartbeat(
                instance_id=self.instance_id,
                name=self.config.instance_name,
                version=__version__,
                capabilities={
                    **self.config.capabilities(),
                    "runtime_capabilities": self.runtimes.capabilities(),
                },
            )
            await asyncio.sleep(self.config.heartbeat_interval)

    async def _pending_work_loop(self) -> None:
        claimed: set[str] = set()
        while self._running:
            try:
                requests = await self.poster.get_pending_requests(
                    instance_id=self.instance_id,
                    runtimes=list(self.config.enabled_runtimes or [self.config.runtime]),
                )
                for request in requests:
                    request_id = request.get("request_id")
                    if not request_id or request_id in claimed:
                        continue

                    claimed.add(request_id)
                    logger.info("Claimed queued work request %s", request_id)
                    asyncio.create_task(self._handle_claimed_work(request, claimed))
            except Exception as exc:
                logger.error("pending work loop error: %s", exc)

            await asyncio.sleep(5)

    async def _handle_claimed_work(self, request: dict, claimed: set[str]) -> None:
        request_id = request.get("request_id")
        try:
            await self.handle_work(request)
        finally:
            if request_id:
                claimed.discard(request_id)

    def stop(self) -> None:
        self._running = False
        if self.ws_client:
            asyncio.create_task(self.ws_client.disconnect())


async def async_main(runtime: str | None = None) -> None:
    config = BridgeConfig.from_env(runtime_override=runtime)
    bridge = Bridge(config)

    loop = asyncio.get_event_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        loop.add_signal_handler(sig, bridge.stop)

    await bridge.start()


def _parse_args(argv: list[str] | None = None, default_runtime: str | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        prog="gptree-bridge",
        description="Unified outbound-only bridge for GPTree local runtimes.",
    )
    parser.add_argument("--runtime", default=default_runtime, choices=["pentest", "code", "openclaw", "browser"], help="Runtime to use for legacy work envelopes.")
    parser.add_argument("--version", action="version", version=f"gptree-bridge {__version__}")
    return parser.parse_args(argv)


def cli() -> None:
    if len(sys.argv) > 1 and sys.argv[1] == "setup-browser":
        raise SystemExit(setup_browser())
    args = _parse_args()
    asyncio.run(async_main(args.runtime))


def pentest_cli() -> None:
    args = _parse_args(default_runtime="pentest")
    asyncio.run(async_main(args.runtime or "pentest"))


def openclaw_cli() -> None:
    args = _parse_args(default_runtime="openclaw")
    asyncio.run(async_main(args.runtime or "openclaw"))


def setup_browser() -> int:
    """Install the Playwright Chromium driver used by the browser runtime."""
    try:
        import playwright  # noqa: F401
    except ModuleNotFoundError:
        print("Playwright is not installed. Install the browser extra first:", file=sys.stderr)
        print("  pipx inject gptree-graft 'playwright>=1.40'", file=sys.stderr)
        return 1

    cmd = [sys.executable, "-m", "playwright", "install", "chromium"]
    return subprocess_run(cmd)


def subprocess_run(cmd: list[str]) -> int:
    import subprocess

    completed = subprocess.run(cmd, check=False)
    return int(completed.returncode)


if __name__ == "__main__":
    cli()
