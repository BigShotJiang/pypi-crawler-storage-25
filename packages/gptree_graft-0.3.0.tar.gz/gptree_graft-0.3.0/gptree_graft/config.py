"""Bridge configuration for GPTree's unified local client."""

from __future__ import annotations

import os
from dataclasses import dataclass, field


@dataclass
class BridgeConfig:
    gptree_url: str = "https://gp-tree.com"
    gptree_token: str = ""

    ws_host: str = ""
    ws_port: int = 0
    ws_key: str = ""
    ws_scheme: str = ""

    user_id: int = 0
    channel: str = ""

    runtime: str = "pentest"
    enabled_runtimes: list[str] = field(default_factory=lambda: ["pentest"])
    heartbeat_interval: int = 30
    instance_name: str = "GPTree Bridge"
    instance_id_prefix: str = "gptree"
    instance_id: str = ""
    verify_ssl: bool = True
    # After /api/ for bootstrap, heartbeat, streaming callbacks (`/api/<prefix>/...`).
    # Some deployments only register `pentest`; this repo registers both `bridge` and `pentest`.
    api_prefix: str = "bridge"

    max_iterations: int = 300
    workspace_dir: str = "./workspace"
    # Locally-trusted workspace roots. The bridge accepts a `workspace.root`
    # value pushed down by the server only when it resolves to one of these
    # entries. Empty list means "only the configured workspace_dir is
    # trusted." This blocks a compromised or malicious server from steering
    # local tool I/O at arbitrary directories on the user's machine.
    workspace_allowlist: list[str] = field(default_factory=list)
    session_dir: str = os.path.expanduser("~/.pentestgpt/sessions")
    default_model: str = "claude-sonnet-4-5-20250929"
    permission_mode: str = "default"

    # Per-tool approval-prompt timeout, in seconds.
    #   > 0 → wait up to this many seconds for the user to allow/deny,
    #         then return status='timeout'.
    #   ≤ 0 → wait indefinitely (until the user decides or the agent
    #         run is cancelled by the server).
    # 1800 (30 min) by default — long enough that stepping away to
    # read the agent's plan or grab coffee doesn't nuke the run, short
    # enough that an abandoned prompt eventually clears server-side
    # resources. Per-call overrides via the tool input
    # `approval_timeout_seconds` field still win.
    approval_timeout_seconds: int = 1800

    def __repr__(self) -> str:
        return f"BridgeConfig(gptree_url={self.gptree_url!r}, runtime={self.runtime!r}, token=****)"

    @classmethod
    def from_env(cls, runtime_override: str | None = None) -> "BridgeConfig":
        gptree_url = os.getenv("GPTREE_URL", "https://gp-tree.com")
        verify_ssl = os.getenv("VERIFY_SSL", "true").lower() not in ("false", "0", "no")
        runtime = runtime_override or os.getenv("GPTREE_BRIDGE_RUNTIME", "pentest")
        enabled = [
            value.strip()
            for value in os.getenv("GPTREE_BRIDGE_RUNTIMES", runtime).split(",")
            if value.strip()
        ]
        if runtime not in enabled:
            enabled.insert(0, runtime)

        api_prefix = os.getenv("GPTREE_BRIDGE_API_PREFIX", "bridge").strip().strip("/")

        return cls(
            gptree_url=gptree_url,
            gptree_token=os.getenv("GPTREE_TOKEN", ""),
            ws_host=os.getenv("WS_HOST", ""),
            ws_port=int(os.getenv("WS_PORT", "0")),
            ws_key=os.getenv("WS_KEY", ""),
            ws_scheme=os.getenv("WS_SCHEME", ""),
            runtime=runtime,
            enabled_runtimes=enabled,
            heartbeat_interval=int(os.getenv("HEARTBEAT_INTERVAL", "30")),
            instance_name=os.getenv("INSTANCE_NAME", "GPTree Bridge"),
            instance_id_prefix=os.getenv("GPTREE_BRIDGE_INSTANCE_PREFIX", "gptree"),
            instance_id=os.getenv("GPTREE_BRIDGE_INSTANCE_ID", ""),
            verify_ssl=verify_ssl,
            api_prefix=api_prefix or "bridge",
            max_iterations=int(os.getenv("PENTESTGPT_MAX_ITERATIONS", "300")),
            workspace_dir=os.getenv("GPTREE_BRIDGE_WORKSPACE", os.getenv("PENTESTGPT_WORKSPACE", "./workspace")),
            workspace_allowlist=[
                value.strip()
                for value in os.getenv("GPTREE_BRIDGE_WORKSPACE_ALLOWLIST", "").split(",")
                if value.strip()
            ],
            session_dir=os.getenv(
                "PENTESTGPT_SESSION_DIR",
                os.path.expanduser("~/.pentestgpt/sessions"),
            ),
            default_model=os.getenv("PENTESTGPT_MODEL", "claude-sonnet-4-5-20250929"),
            permission_mode=os.getenv("PENTESTGPT_PERMISSION_MODE", "default"),
            approval_timeout_seconds=int(
                os.getenv("GPTREE_BRIDGE_APPROVAL_TIMEOUT_SECONDS", "1800")
            ),
        )

    @property
    def needs_bootstrap(self) -> bool:
        return not self.ws_key or not self.ws_host

    @staticmethod
    def _normalize_ws_scheme(scheme: str) -> str:
        return {"http": "ws", "https": "wss"}.get(scheme, scheme)

    def apply_bootstrap(self, data: dict) -> None:
        ws = data.get("reverb", {})
        if not self.ws_key:
            self.ws_key = ws.get("key", "")
        if not self.ws_host:
            self.ws_host = str(ws.get("host", ""))
        if not self.ws_port:
            port = int(ws.get("port", 8080))
            if not (1 <= port <= 65535):
                raise ValueError(f"Invalid WebSocket port from bootstrap: {port}")
            self.ws_port = port
        if not self.ws_scheme:
            scheme = self._normalize_ws_scheme(ws.get("scheme", "ws"))
            if scheme not in ("ws", "wss"):
                raise ValueError(f"Invalid WebSocket scheme from bootstrap: {scheme}")
            self.ws_scheme = scheme
        self.user_id = data.get("user_id", 0)
        self.channel = data.get("channel", "")

    def is_trusted_workspace_root(self, candidate: str | None) -> bool:
        """Return True iff `candidate` is locally trusted as a workspace root.

        The default workspace_dir is always trusted; additional roots can be
        opted in via GPTREE_BRIDGE_WORKSPACE_ALLOWLIST. Comparison is done on
        realpath so symlinks cannot escape the allowlist.
        """
        if not candidate:
            return False
        try:
            target = os.path.realpath(os.path.abspath(candidate))
        except (OSError, ValueError):
            return False
        trusted_paths = [self.workspace_dir, *self.workspace_allowlist]
        for trusted in trusted_paths:
            if not trusted:
                continue
            try:
                trusted_real = os.path.realpath(os.path.abspath(trusted))
            except (OSError, ValueError):
                continue
            if target == trusted_real:
                return True
        return False

    def capabilities(self) -> dict:
        return {
            "runtimes": self.enabled_runtimes,
            "active_runtime": self.runtime,
            "protocols": ["pusher-ws", "https-callback"],
            "tool_protocol_versions": [1],
            "workspace": {
                "root": self.workspace_dir,
            },
        }
