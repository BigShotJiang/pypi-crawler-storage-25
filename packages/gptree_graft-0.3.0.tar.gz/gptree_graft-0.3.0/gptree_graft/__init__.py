"""Unified GPTree bridge package."""

# Derive __version__ from the installed package metadata so the bridge
# always reports the same version pyproject.toml declares. Previously we
# hardcoded this here and it silently drifted (0.1.0 in source while
# pyproject said 0.2.0), which made it impossible to tell from the
# server side whether a connected bridge was the published build or the
# working tree.
from importlib.metadata import PackageNotFoundError, version as _pkg_version

try:
    __version__ = _pkg_version("gptree-graft")
except PackageNotFoundError:
    # Source-checkout-without-install fallback (e.g. running tests
    # directly with PYTHONPATH). Should not happen in production.
    __version__ = "0.0.0+unknown"
