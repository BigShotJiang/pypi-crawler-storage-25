"""Git worktree tools for GPTree Code runtime."""

from __future__ import annotations

import asyncio
import os
import shutil

from .base import LocalTool, ToolResult


class EnterWorktreeTool(LocalTool):
    name = "bridge.git.worktree.enter"

    async def run(self, input_data: dict) -> ToolResult:
        branch = input_data.get("branch") or "gptree-agent"
        base = input_data.get("base", "HEAD")
        worktree_root = self.guard.resolve(input_data.get("worktree_root") or ".gptree/worktrees")
        path = self.guard.resolve(os.path.join(worktree_root, branch.replace("/", "-")))
        os.makedirs(worktree_root, exist_ok=True)

        if not shutil.which("git"):
            return ToolResult(self.name, "git is not available on this machine.", status="failed", exit_code=127)

        if os.path.exists(path):
            return ToolResult(
                self.name,
                f"Reusing existing worktree at {path}.",
                metadata={"worktree_path": path, "branch": branch, "reused": True},
            )

        proc = await asyncio.create_subprocess_exec(
            "git",
            "worktree",
            "add",
            "-b",
            branch,
            path,
            base,
            cwd=self.guard.workspace_root,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
        )
        stdout, _ = await proc.communicate()
        output = stdout.decode("utf-8", errors="replace")

        return ToolResult(
            self.name,
            output,
            status="completed" if proc.returncode == 0 else "failed",
            exit_code=proc.returncode,
            metadata={"worktree_path": path, "branch": branch, "base": base},
        )


class ExitWorktreeTool(LocalTool):
    name = "bridge.git.worktree.exit"

    async def run(self, input_data: dict) -> ToolResult:
        path = self.guard.resolve(input_data.get("path"))
        remove = bool(input_data.get("remove", False))

        if not remove:
            return ToolResult(
                self.name,
                f"Leaving worktree context: {path}",
                metadata={"worktree_path": path, "removed": False},
            )

        if not shutil.which("git"):
            return ToolResult(self.name, "git is not available on this machine.", status="failed", exit_code=127)

        proc = await asyncio.create_subprocess_exec(
            "git",
            "worktree",
            "remove",
            path,
            cwd=self.guard.workspace_root,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
        )
        stdout, _ = await proc.communicate()
        output = stdout.decode("utf-8", errors="replace")

        return ToolResult(
            self.name,
            output,
            status="completed" if proc.returncode == 0 else "failed",
            exit_code=proc.returncode,
            metadata={"worktree_path": path, "removed": proc.returncode == 0},
        )
