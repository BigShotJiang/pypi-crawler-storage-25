"""Shared local tool primitives."""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Any


@dataclass
class ToolResult:
    tool_name: str
    output: Any
    status: str = "completed"
    exit_code: int | None = 0
    metadata: dict = field(default_factory=dict)
    truncated: bool = False
    artifacts: list[dict] = field(default_factory=list)

    def as_chunk(self, tool_use_id: str) -> dict:
        return {
            "tool_use_id": tool_use_id,
            "tool_name": self.tool_name,
            "status": self.status,
            "output": self.output,
            "exit_code": self.exit_code,
            "truncated": self.truncated,
            "artifacts": self.artifacts,
            "metadata": self.metadata,
        }


class WorkspaceGuard:
    def __init__(self, workspace_root: str):
        self.workspace_root = os.path.realpath(os.path.abspath(workspace_root))

    def resolve(self, path: str | None = None) -> str:
        raw_path = path or self.workspace_root
        candidate_path = raw_path if os.path.isabs(raw_path) else os.path.join(self.workspace_root, raw_path)
        candidate = os.path.realpath(os.path.abspath(candidate_path))
        if not (candidate == self.workspace_root or candidate.startswith(self.workspace_root + os.sep)):
            raise ValueError("path must stay inside workspace_root")
        return candidate


class LocalTool:
    name: str

    def __init__(self, workspace_root: str):
        self.guard = WorkspaceGuard(workspace_root)

    async def run(self, input_data: dict) -> ToolResult:
        raise NotImplementedError
