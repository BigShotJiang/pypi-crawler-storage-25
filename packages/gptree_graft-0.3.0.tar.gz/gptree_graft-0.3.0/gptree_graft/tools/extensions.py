"""Extension surface tools: skills, hooks, MCP config, and notebooks."""

from __future__ import annotations

import asyncio
import json
import os
from pathlib import Path

from .base import LocalTool, ToolResult


class SkillListTool(LocalTool):
    name = "bridge.skills.list"

    async def run(self, input_data: dict) -> ToolResult:
        roots = [
            Path(self.guard.resolve(".gptree/skills")),
            Path.home() / ".gptree" / "skills",
        ]
        skills = []

        for root in roots:
            if not root.exists():
                continue
            for skill_file in sorted(root.glob("*/SKILL.md")):
                skills.append({
                    "id": skill_file.parent.name,
                    "path": str(skill_file),
                    "scope": "project" if str(skill_file).startswith(self.guard.workspace_root) else "user",
                })

        return ToolResult(self.name, skills, metadata={"count": len(skills)})


class SkillReadTool(LocalTool):
    name = "bridge.skills.read"

    async def run(self, input_data: dict) -> ToolResult:
        skill_id = input_data.get("id")
        if not skill_id:
            return ToolResult(self.name, "id is required.", status="failed", exit_code=1)
        if "/" in skill_id or "\\" in skill_id or ".." in skill_id:
            return ToolResult(self.name, "id must be a skill directory name.", status="failed", exit_code=1)

        candidates = [
            Path(self.guard.resolve(".gptree/skills")) / skill_id / "SKILL.md",
            Path.home() / ".gptree" / "skills" / skill_id / "SKILL.md",
        ]
        for candidate in candidates:
            if candidate.exists():
                return ToolResult(self.name, candidate.read_text(encoding="utf-8"), metadata={"path": str(candidate)})

        return ToolResult(self.name, f"Skill [{skill_id}] was not found.", status="failed", exit_code=1)


class HookRunTool(LocalTool):
    name = "bridge.hooks.run"
    allowed_hooks = {"SessionStart", "PreToolUse", "PostToolUse", "PostFailure", "Denied", "Stop"}

    async def run(self, input_data: dict) -> ToolResult:
        hook = input_data.get("hook")
        if hook not in self.allowed_hooks:
            return ToolResult(self.name, f"Hook [{hook}] is not allowed.", status="failed", exit_code=1)

        hook_path = Path(self.guard.resolve(f".gptree/hooks/{hook}"))
        payload = json.dumps(input_data.get("payload") or {})
        if not hook_path.exists():
            return ToolResult(self.name, f"No hook installed for {hook}.", metadata={"hook": hook, "skipped": True})

        proc = await asyncio.create_subprocess_exec(
            str(hook_path),
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
            cwd=self.guard.workspace_root,
        )
        try:
            stdout, _ = await asyncio.wait_for(proc.communicate(payload.encode("utf-8")), timeout=int(input_data.get("timeout", 10)))
        except asyncio.TimeoutError:
            proc.kill()
            return ToolResult(self.name, f"Hook [{hook}] timed out.", status="failed", exit_code=124)

        output = stdout.decode("utf-8", errors="replace")
        return ToolResult(
            self.name,
            output,
            status="completed" if proc.returncode == 0 else "failed",
            exit_code=proc.returncode,
            metadata={"hook": hook, "path": str(hook_path)},
        )


class McpConfigTool(LocalTool):
    name = "bridge.mcp.config"

    async def run(self, input_data: dict) -> ToolResult:
        configs = []
        for scope, path in [
            ("project", Path(self.guard.resolve(".gptree/mcp.json"))),
            ("user", Path.home() / ".gptree" / "mcp.json"),
        ]:
            if not path.exists():
                continue
            configs.append({
                "scope": scope,
                "path": str(path),
                "config": json.loads(path.read_text(encoding="utf-8")),
            })

        return ToolResult(self.name, configs, metadata={"count": len(configs)})


class NotebookEditTool(LocalTool):
    name = "bridge.notebook.edit"

    async def run(self, input_data: dict) -> ToolResult:
        notebook_path = Path(self.guard.resolve(input_data.get("path")))
        cell_index = int(input_data.get("cell_index", 0))
        if cell_index < 0:
            return ToolResult(self.name, "cell_index must be zero or greater.", status="failed", exit_code=1)
        old_string = input_data.get("old_string", "")
        new_string = input_data.get("new_string", "")

        notebook = json.loads(notebook_path.read_text(encoding="utf-8"))
        cells = notebook.setdefault("cells", [])

        if cell_index >= len(cells):
            cells.append({
                "cell_type": input_data.get("cell_type", "markdown"),
                "metadata": {},
                "source": [],
            })

        cell = cells[cell_index]
        source = cell.get("source", [])
        source_text = "".join(source) if isinstance(source, list) else str(source)

        if old_string:
            if old_string not in source_text:
                return ToolResult(self.name, "old_string was not found in target cell.", status="failed", exit_code=1)
            source_text = source_text.replace(old_string, new_string, 1)
        else:
            source_text = new_string

        cell["source"] = source_text.splitlines(keepends=True)
        notebook_path.write_text(json.dumps(notebook, indent=2) + "\n", encoding="utf-8")

        return ToolResult(
            self.name,
            "Notebook cell updated.",
            metadata={"path": str(notebook_path), "cell_index": cell_index},
        )
