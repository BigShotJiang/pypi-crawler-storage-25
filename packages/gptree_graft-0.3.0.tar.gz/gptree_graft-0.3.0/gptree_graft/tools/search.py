"""Search tools for GPTree Code runtime."""

from __future__ import annotations

import fnmatch
import os
import re
from pathlib import Path

from .base import LocalTool, ToolResult


class GlobTool(LocalTool):
    name = "bridge.fs.glob"

    async def run(self, input_data: dict) -> ToolResult:
        pattern = input_data.get("pattern", "**/*")
        root = Path(self.guard.resolve(input_data.get("path")))
        limit = int(input_data.get("limit", 200) or 200)

        matches = []
        for path in root.glob(pattern):
            resolved = self.guard.resolve(str(path))
            if path.is_file():
                matches.append(os.path.relpath(resolved, self.guard.workspace_root))
            if len(matches) >= limit:
                break

        return ToolResult(
            tool_name=self.name,
            output=matches,
            metadata={"pattern": pattern, "count": len(matches), "limited": len(matches) >= limit},
        )


class GrepTool(LocalTool):
    name = "bridge.fs.grep"

    async def run(self, input_data: dict) -> ToolResult:
        pattern = input_data.get("pattern", "")
        root = self.guard.resolve(input_data.get("path"))
        include = input_data.get("include")
        limit = int(input_data.get("limit", 200) or 200)
        flags = 0 if input_data.get("case_sensitive", True) else re.IGNORECASE
        regex = re.compile(pattern, flags)

        matches = []
        for current_root, _, files in os.walk(root):
            self.guard.resolve(current_root)
            for filename in files:
                if include and not fnmatch.fnmatch(filename, include):
                    continue
                full_path = self.guard.resolve(os.path.join(current_root, filename))
                try:
                    with open(full_path, "r", encoding=input_data.get("encoding", "utf-8"), errors="replace") as handle:
                        for line_number, line in enumerate(handle, start=1):
                            if regex.search(line):
                                matches.append({
                                    "path": os.path.relpath(full_path, self.guard.workspace_root),
                                    "line": line_number,
                                    "text": line.rstrip("\n"),
                                })
                                if len(matches) >= limit:
                                    return ToolResult(
                                        tool_name=self.name,
                                        output=matches,
                                        metadata={"pattern": pattern, "count": len(matches), "limited": True},
                                    )
                except OSError:
                    continue

        return ToolResult(
            tool_name=self.name,
            output=matches,
            metadata={"pattern": pattern, "count": len(matches), "limited": False},
        )
