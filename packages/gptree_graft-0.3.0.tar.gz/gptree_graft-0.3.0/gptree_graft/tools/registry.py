"""Local tool registry for GPTree Code runtime."""

from __future__ import annotations

from .bash import BashTool
from .extensions import HookRunTool, McpConfigTool, NotebookEditTool, SkillListTool, SkillReadTool
from .files import FileEditTool, FileReadTool, FileWriteTool
from .search import GlobTool, GrepTool
from .web import WebFetchTool
from .worktree import EnterWorktreeTool, ExitWorktreeTool


def build_tool_registry(workspace_root: str) -> dict:
    tools = [
        BashTool(workspace_root),
        FileReadTool(workspace_root),
        FileWriteTool(workspace_root),
        FileEditTool(workspace_root),
        GrepTool(workspace_root),
        GlobTool(workspace_root),
        WebFetchTool(workspace_root),
        EnterWorktreeTool(workspace_root),
        ExitWorktreeTool(workspace_root),
        SkillListTool(workspace_root),
        SkillReadTool(workspace_root),
        HookRunTool(workspace_root),
        McpConfigTool(workspace_root),
        NotebookEditTool(workspace_root),
    ]

    return {tool.name: tool for tool in tools}


CORE_TOOL_NAMES = [
    BashTool.name,
    FileReadTool.name,
    FileWriteTool.name,
    FileEditTool.name,
    GrepTool.name,
    GlobTool.name,
    WebFetchTool.name,
    EnterWorktreeTool.name,
    ExitWorktreeTool.name,
    SkillListTool.name,
    SkillReadTool.name,
    HookRunTool.name,
    McpConfigTool.name,
    NotebookEditTool.name,
]
