"""Web tools for GPTree Code runtime."""

from __future__ import annotations

import httpx

from .base import LocalTool, ToolResult


class WebFetchTool(LocalTool):
    name = "bridge.web.fetch"

    async def run(self, input_data: dict) -> ToolResult:
        url = input_data.get("url", "")
        timeout = float(input_data.get("timeout", 15))
        max_chars = int(input_data.get("max_chars", 50_000) or 50_000)

        async with httpx.AsyncClient(timeout=timeout, follow_redirects=True) as client:
            response = await client.get(url)

        content = response.text
        truncated = len(content) > max_chars

        return ToolResult(
            tool_name=self.name,
            output=content[:max_chars] + ("\n[output truncated]" if truncated else ""),
            status="completed" if response.is_success else "failed",
            exit_code=0 if response.is_success else response.status_code,
            metadata={
                "url": url,
                "status_code": response.status_code,
                "content_type": response.headers.get("content-type"),
            },
            truncated=truncated,
        )
