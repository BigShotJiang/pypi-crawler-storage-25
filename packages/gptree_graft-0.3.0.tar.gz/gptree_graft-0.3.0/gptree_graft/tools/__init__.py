"""Local tool implementations for GPTree bridge."""
