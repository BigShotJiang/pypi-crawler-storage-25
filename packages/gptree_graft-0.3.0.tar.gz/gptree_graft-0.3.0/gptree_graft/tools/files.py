"""File read/write/edit tools for GPTree Code runtime."""

from __future__ import annotations

import difflib
import os

from .base import LocalTool, ToolResult


class FileReadTool(LocalTool):
    name = "bridge.fs.read"

    async def run(self, input_data: dict) -> ToolResult:
        path = self.guard.resolve(input_data.get("path"))
        offset = int(input_data.get("offset", 0) or 0)
        limit = input_data.get("limit")
        max_chars = int(input_data.get("max_chars", 50_000) or 50_000)

        with open(path, "r", encoding=input_data.get("encoding", "utf-8"), errors="replace") as handle:
            content = handle.read()

        if offset:
            content = content[offset:]
        if limit is not None:
            content = content[: int(limit)]

        truncated = len(content) > max_chars
        output = content[:max_chars] + ("\n[output truncated]" if truncated else "")

        return ToolResult(
            tool_name=self.name,
            output=output,
            metadata={"path": path, "size_bytes": os.path.getsize(path)},
            truncated=truncated,
        )


class FileWriteTool(LocalTool):
    name = "bridge.fs.write"

    async def run(self, input_data: dict) -> ToolResult:
        path = self.guard.resolve(input_data.get("path"))
        content = input_data.get("content", "")
        create_dirs = bool(input_data.get("create_dirs", False))
        mode = input_data.get("mode", "overwrite")

        if create_dirs:
            os.makedirs(os.path.dirname(path), exist_ok=True)
        if mode not in ("overwrite", "append"):
            raise ValueError("mode must be overwrite or append")

        write_mode = "a" if mode == "append" else "w"
        with open(path, write_mode, encoding=input_data.get("encoding", "utf-8")) as handle:
            handle.write(content)

        return ToolResult(
            tool_name=self.name,
            output=f"Wrote {len(content)} characters to {path}.",
            metadata={"path": path, "mode": mode, "chars": len(content)},
        )


class FileEditTool(LocalTool):
    name = "bridge.fs.edit"

    async def run(self, input_data: dict) -> ToolResult:
        path = self.guard.resolve(input_data.get("path"))
        old_string = input_data.get("old_string", "")
        new_string = input_data.get("new_string", "")
        replace_all = bool(input_data.get("replace_all", False))

        with open(path, "r", encoding=input_data.get("encoding", "utf-8"), errors="replace") as handle:
            before = handle.read()

        if old_string not in before:
            return ToolResult(
                tool_name=self.name,
                output="old_string was not found.",
                status="failed",
                exit_code=1,
                metadata={"path": path},
            )

        after = before.replace(old_string, new_string) if replace_all else before.replace(old_string, new_string, 1)
        with open(path, "w", encoding=input_data.get("encoding", "utf-8")) as handle:
            handle.write(after)

        diff = "".join(difflib.unified_diff(
            before.splitlines(keepends=True),
            after.splitlines(keepends=True),
            fromfile=path,
            tofile=path,
        ))

        return ToolResult(
            tool_name=self.name,
            output=diff,
            metadata={"path": path, "replace_all": replace_all},
        )
