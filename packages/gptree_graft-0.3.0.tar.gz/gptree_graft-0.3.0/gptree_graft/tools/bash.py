"""Bash tool scaffold for GPTree Code runtime."""

from __future__ import annotations

import asyncio
import os
from dataclasses import dataclass

from .base import LocalTool, ToolResult, WorkspaceGuard


@dataclass
class BashResult:
    command: str
    output: str
    exit_code: int
    cwd: str
    timed_out: bool = False


class BashTool:
    name = "bridge.bash.exec"

    def __init__(self, workspace_root: str, timeout_seconds: int = 30, max_output_chars: int = 50_000):
        self.workspace_root = os.path.abspath(workspace_root)
        self.guard = WorkspaceGuard(workspace_root)
        self.timeout_seconds = timeout_seconds
        self.max_output_chars = max_output_chars

    async def run_tool(self, input_data: dict) -> ToolResult:
        result = await self.run(
            command=input_data.get("command", ""),
            cwd=input_data.get("cwd"),
        )
        return ToolResult(
            tool_name=self.name,
            output=result.output,
            status="completed" if result.exit_code == 0 else "failed",
            exit_code=result.exit_code,
            metadata={
                "command": result.command,
                "cwd": result.cwd,
                "timed_out": result.timed_out,
            },
            truncated=result.output.endswith("[output truncated]"),
        )

    async def run(self, command: str, cwd: str | None = None) -> BashResult:
        working_dir = self._resolve_cwd(cwd)
        proc = await asyncio.create_subprocess_shell(
            command,
            cwd=working_dir,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
        )

        timed_out = False
        try:
            stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=self.timeout_seconds)
        except asyncio.TimeoutError:
            timed_out = True
            proc.kill()
            stdout, _ = await proc.communicate()

        output = stdout.decode("utf-8", errors="replace")
        if len(output) > self.max_output_chars:
            output = output[: self.max_output_chars] + "\n[output truncated]"

        return BashResult(
            command=command,
            output=output,
            exit_code=proc.returncode if proc.returncode is not None else 124,
            cwd=working_dir,
            timed_out=timed_out,
        )

    def _resolve_cwd(self, cwd: str | None) -> str:
        return self.guard.resolve(cwd)
