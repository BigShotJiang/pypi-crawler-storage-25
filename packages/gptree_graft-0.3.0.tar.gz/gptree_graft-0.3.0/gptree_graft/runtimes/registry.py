"""Runtime registry for GPTree bridge."""

from __future__ import annotations

from .base import Runtime


class RuntimeRegistry:
    def __init__(self):
        self._runtimes: dict[str, Runtime] = {}

    def register(self, runtime: Runtime) -> None:
        self._runtimes[runtime.name] = runtime

    def get(self, name: str) -> Runtime:
        if name not in self._runtimes:
            raise KeyError(f"Runtime [{name}] is not registered.")
        return self._runtimes[name]

    def has(self, name: str) -> bool:
        return name in self._runtimes

    def names(self) -> list[str]:
        return sorted(self._runtimes.keys())

    def capabilities(self) -> dict:
        return {name: runtime.capabilities() for name, runtime in sorted(self._runtimes.items())}
