"""Runtime adapters for GPTree bridge."""
