"""Local browser automation runtime for Graft actions."""

from __future__ import annotations

import asyncio
import importlib.util
import os
import platform
import time
import uuid
from pathlib import Path

from .base import Runtime
from ..transport.http_poster import HttpPoster

APPROVAL_TIMEOUT_SECONDS = 1800


class BrowserRuntime(Runtime):
    name = "browser"

    def __init__(self, config, poster: HttpPoster):
        self.config = config
        self.poster = poster
        # Single-completion bookkeeping. A sub-handler may successfully call
        # post_complete_request and then raise during cleanup (e.g. Playwright
        # context close), which used to make the outer except-block call
        # _complete_failure → post_complete_request a SECOND time for the same
        # request_id. Recording successful completions here lets the failure
        # path bail out instead of double-firing.
        self._completed_requests: set[str] = set()

    def capabilities(self) -> dict:
        profile_dir = self._profile_dir()
        return {
            "status": "ready",
            "actions": [
                "browser.automate",
                "social.facebook_page.create",
                "social.twitter.post",
                "social.instagram.bio",
            ],
            "requires_user_session": True,
            "approval_before_submit": True,
            "headed": True,
            "persistent_profile": str(profile_dir),
            "playwright_available": importlib.util.find_spec("playwright") is not None,
        }

    async def handle_work(self, data: dict) -> None:
        request_id = data.get("request_id")
        # Defensive: server contract says session_config is a dict, but if a
        # malformed payload arrives (string / list / None) the rest of this
        # method would explode on .get() and surface as "unknown" instead
        # of the real shape problem.
        raw_session_config = data.get("session_config")
        session_config = raw_session_config if isinstance(raw_session_config, dict) else {}
        raw_action = session_config.get("action")
        action = raw_action if isinstance(raw_action, dict) else {}
        action_type = action.get("type") or "browser.automate"
        raw_args = action.get("args")
        args = raw_args if isinstance(raw_args, dict) else {}
        target_url = args.get("url") or session_config.get("url")
        post_text = str(args.get("post_text") or "").strip()
        bio_text = str(args.get("bio_text") or "").strip()

        await self.poster.post_stream_chunk(
            request_id=request_id,
            chunk_type="content",
            chunk_data={
                "content": f"[graft-browser] Starting {action_type}.",
                "model": "gptree-graft:browser",
            },
        )

        if importlib.util.find_spec("playwright") is None:
            await self._complete_failure(
                request_id,
                action_type,
                target_url,
                reason="browser_setup_required",
                output=(
                    "Graft browser automation needs Playwright and Chromium before it can control pages. "
                    "Run `gptree-graft setup-browser`, then retry this action."
                ),
            )
            return

        try:
            from playwright.async_api import Error as PlaywrightError
            from playwright.async_api import async_playwright
        except Exception:
            await self._complete_failure(
                request_id,
                action_type,
                target_url,
                reason="browser_setup_required",
                output=(
                    "Graft could not load Playwright. Run `gptree-graft setup-browser`, then retry this action."
                ),
            )
            return

        context = None
        try:
            async with async_playwright() as playwright:
                context = await playwright.chromium.launch_persistent_context(
                    user_data_dir=str(self._profile_dir()),
                    headless=False,
                    viewport={"width": 1280, "height": 900},
                    args=["--disable-blink-features=AutomationControlled"],
                )
                page = context.pages[0] if context.pages else await context.new_page()
                if target_url:
                    await page.goto(str(target_url), wait_until="domcontentloaded", timeout=45000)
                    await self._content(request_id, f"[graft-browser] Opened {target_url}.")

                if await self._is_login_wall(page, action_type):
                    await self._emit_tool_result(
                        request_id,
                        "graft.browser.login_required",
                        "login_required",
                        (
                            "Graft opened the site, but it looks like you need to log in. "
                            "Log in in the browser window, then retry this action."
                        ),
                        metadata={"action_type": action_type, "target_url": target_url},
                    )
                    await self._complete_failure(
                        request_id,
                        action_type,
                        target_url,
                        reason="login_required",
                        output="Login required. Log in in the browser window, then retry this Graft action.",
                    )
                    return

                if action_type == "social.twitter.post":
                    await self._handle_twitter_post(request_id, page, action, post_text)
                    return

                if action_type == "social.instagram.bio":
                    await self._handle_instagram_bio(request_id, page, action, bio_text)
                    return

                if action_type == "social.facebook_page.create":
                    await self._handle_facebook_page_create(request_id, page, action)
                    return

                snapshot = await self._snapshot(page)
                await self._emit_tool_result(
                    request_id,
                    "graft.browser.snapshot",
                    "needs_selector",
                    "Graft captured the visible page, but generic browser automation needs a specific target before it can act.",
                    metadata={"snapshot": snapshot["text"][:4000], "action_type": action_type},
                )
                await self._mark_completed(request_id, self.poster.post_complete_request(
                    request_id=request_id,
                    response=(
                        "Graft captured the page context, but generic browser automation is not wired to replace "
                        "missing tools yet. Provide the exact field/button or use a specific Graft action."
                    ),
                    metadata={
                        "runtime": "browser",
                        "status": "needs_selector",
                        "action_type": action_type,
                        "target_url": target_url,
                    },
                ))
        except PlaywrightError as exc:
            await self._complete_failure(
                request_id,
                action_type,
                target_url,
                reason="network",
                output=f"Graft browser automation hit a retryable browser error: {exc}",
            )
        except Exception as exc:
            await self._complete_failure(
                request_id,
                action_type,
                target_url,
                reason="unknown",
                output=f"Graft browser automation failed: {exc}",
            )
        finally:
            if context:
                try:
                    await context.close()
                except Exception:
                    pass

    async def _handle_twitter_post(self, request_id: str, page, action: dict, post_text: str) -> None:
        if not post_text:
            await self._complete_failure(
                request_id,
                "social.twitter.post",
                action.get("args", {}).get("url"),
                reason="missing_fields",
                output="Graft needs post_text before it can draft an X/Twitter post.",
            )
            return

        fill_tool_id = await self._emit_tool_request(request_id, "graft.browser.fill", {"field": "post_text", "value": post_text})
        await self._fill_first(page, [
            '[data-testid="tweetTextarea_0"]',
            'div[role="textbox"][contenteditable="true"]',
            'div[aria-label*="Post text"]',
            'div[aria-label*="Tweet text"]',
        ], post_text)
        await self._emit_tool_result(request_id, "graft.browser.fill", "completed", "Filled the X/Twitter composer.", tool_use_id=fill_tool_id)

        permission = await self._await_permission(
            request_id,
            tool_name="graft.browser.publish",
            input_data={
                "action_type": "social.twitter.post",
                "post_text": post_text,
                "approval_timeout_seconds": APPROVAL_TIMEOUT_SECONDS,
                "expires_at_unix": int(time.time()) + APPROVAL_TIMEOUT_SECONDS,
            },
            reason="Approve publishing this X/Twitter post.",
        )

        if permission.get("status") != "allow":
            status = permission.get("status") or "denied"
            await self._emit_tool_result(
                request_id,
                "graft.browser.publish",
                status,
                permission.get("reason") or "Publishing was not approved.",
                exit_code=126,
            )
            await self._mark_completed(request_id, self.poster.post_complete_request(
                request_id=request_id,
                response="Graft filled the X/Twitter draft but did not publish it.",
                metadata={
                    "runtime": "browser",
                    "status": "user_cancelled" if status == "deny" else "approval_timeout",
                    "action_type": "social.twitter.post",
                    "approval_required_before_submit": True,
                },
            ))
            return

        publish_tool_id = await self._emit_tool_request(request_id, "graft.browser.publish", {"action_type": "social.twitter.post"})
        await self._click_first(page, [
            '[data-testid="tweetButton"]',
            '[data-testid="tweetButtonInline"]',
            'button:has-text("Post")',
            'button:has-text("Tweet")',
        ])
        await self._emit_tool_result(request_id, "graft.browser.publish", "completed", "Published the X/Twitter post.", tool_use_id=publish_tool_id)
        await self._mark_completed(request_id, self.poster.post_complete_request(
            request_id=request_id,
            response="Graft published the X/Twitter post after approval.",
            metadata={
                "runtime": "browser",
                "status": "completed",
                "action_type": "social.twitter.post",
                "approval_required_before_submit": True,
            },
        ))

    async def _handle_instagram_bio(self, request_id: str, page, action: dict, bio_text: str) -> None:
        if not bio_text:
            await self._complete_failure(
                request_id,
                "social.instagram.bio",
                action.get("args", {}).get("url"),
                reason="missing_fields",
                output="Graft needs bio_text before it can update your Instagram bio.",
            )
            return

        fill_tool_id = await self._emit_tool_request(request_id, "graft.browser.fill", {"field": "bio_text", "value": bio_text})
        await self._fill_first(page, [
            'textarea[name="biography"]',
            'textarea[aria-label*="Bio"]',
            'textarea[placeholder*="Bio"]',
            'div[contenteditable="true"][aria-label*="Bio"]',
        ], bio_text)
        await self._emit_tool_result(request_id, "graft.browser.fill", "completed", "Filled the Instagram bio field.", tool_use_id=fill_tool_id)

        permission = await self._await_permission(
            request_id,
            tool_name="graft.browser.save_bio",
            input_data={
                "action_type": "social.instagram.bio",
                "bio_text": bio_text,
                "approval_timeout_seconds": APPROVAL_TIMEOUT_SECONDS,
                "expires_at_unix": int(time.time()) + APPROVAL_TIMEOUT_SECONDS,
            },
            reason="Approve saving this Instagram bio.",
        )

        if permission.get("status") != "allow":
            status = permission.get("status") or "denied"
            await self._emit_tool_result(
                request_id,
                "graft.browser.save_bio",
                status,
                permission.get("reason") or "Saving was not approved.",
                exit_code=126,
            )
            await self._mark_completed(request_id, self.poster.post_complete_request(
                request_id=request_id,
                response="Graft filled the Instagram bio but did not save it.",
                metadata={
                    "runtime": "browser",
                    "status": "user_cancelled" if status == "deny" else "approval_timeout",
                    "action_type": "social.instagram.bio",
                    "approval_required_before_submit": True,
                },
            ))
            return

        save_tool_id = await self._emit_tool_request(request_id, "graft.browser.save_bio", {"action_type": "social.instagram.bio"})
        await self._click_first(page, [
            'button:has-text("Submit")',
            'button:has-text("Save")',
            'div[role="button"]:has-text("Submit")',
        ])
        await self._emit_tool_result(request_id, "graft.browser.save_bio", "completed", "Saved the Instagram bio.", tool_use_id=save_tool_id)
        await self._mark_completed(request_id, self.poster.post_complete_request(
            request_id=request_id,
            response="Graft saved the Instagram bio after approval.",
            metadata={
                "runtime": "browser",
                "status": "completed",
                "action_type": "social.instagram.bio",
                "approval_required_before_submit": True,
            },
        ))

    async def _handle_facebook_page_create(self, request_id: str, page, action: dict) -> None:
        args = action.get("args") or {}
        filled = []
        for field, selectors in {
            "page_name": ['input[aria-label*="Page name"]', 'input[placeholder*="Page name"]'],
            "category": ['input[aria-label*="Category"]', 'input[placeholder*="Category"]'],
            "description": ['textarea[aria-label*="Description"]', 'textarea[placeholder*="Description"]'],
        }.items():
            value = str(args.get(field) or "").strip()
            if not value:
                continue
            try:
                fill_tool_id = await self._emit_tool_request(request_id, "graft.browser.fill", {"field": field, "value": value})
                await self._fill_first(page, selectors, value)
                await self._emit_tool_result(request_id, "graft.browser.fill", "completed", f"Filled {field}.", tool_use_id=fill_tool_id)
                filled.append(field)
            except Exception:
                await self._emit_tool_result(request_id, "graft.browser.fill", "failed", f"Could not fill {field}.", exit_code=1)

        permission = await self._await_permission(
            request_id,
            tool_name="graft.browser.create_page",
            input_data={
                "action_type": "social.facebook_page.create",
                "filled_fields": filled,
                "approval_timeout_seconds": APPROVAL_TIMEOUT_SECONDS,
                "expires_at_unix": int(time.time()) + APPROVAL_TIMEOUT_SECONDS,
            },
            reason="Approve creating this Facebook page.",
        )

        if permission.get("status") != "allow":
            await self._mark_completed(request_id, self.poster.post_complete_request(
                request_id=request_id,
                response="Graft prepared the Facebook page form but did not create the page.",
                metadata={
                    "runtime": "browser",
                    "status": "user_cancelled" if permission.get("status") == "deny" else "approval_timeout",
                    "action_type": "social.facebook_page.create",
                    "filled_fields": filled,
                },
            ))
            return

        create_tool_id = await self._emit_tool_request(request_id, "graft.browser.create_page", {"action_type": "social.facebook_page.create"})
        await self._click_first(page, [
            'div[role="button"]:has-text("Create Page")',
            'button:has-text("Create Page")',
            'div[role="button"]:has-text("Create")',
            'button:has-text("Create")',
        ])
        await self._emit_tool_result(request_id, "graft.browser.create_page", "completed", "Created the Facebook page.", tool_use_id=create_tool_id)
        await self._mark_completed(request_id, self.poster.post_complete_request(
            request_id=request_id,
            response="Graft created the Facebook page after approval.",
            metadata={
                "runtime": "browser",
                "status": "completed",
                "action_type": "social.facebook_page.create",
                "filled_fields": filled,
                "approval_required_before_submit": True,
            },
        ))

    async def _snapshot(self, page) -> dict:
        script = """
        () => {
          const out = [];
          let id = 1;
          const interesting = 'a,button,input,textarea,select,[role="button"],[role="textbox"],[contenteditable="true"]';
          for (const el of Array.from(document.querySelectorAll(interesting))) {
            const rect = el.getBoundingClientRect();
            const style = window.getComputedStyle(el);
            if (rect.width < 2 || rect.height < 2 || style.visibility === 'hidden' || style.display === 'none') continue;
            if (rect.bottom < 0 || rect.right < 0 || rect.top > window.innerHeight || rect.left > window.innerWidth) continue;
            const tag = el.tagName.toLowerCase();
            const text = (el.innerText || el.value || el.getAttribute('aria-label') || el.getAttribute('placeholder') || '').trim().slice(0, 120);
            const attrs = [];
            for (const name of ['type', 'role', 'aria-label', 'placeholder', 'data-testid', 'href']) {
              const value = el.getAttribute(name);
              if (value) attrs.push(`${name}="${String(value).slice(0, 80)}"`);
            }
            out.push({ id: `@${id++}`, tag, text, attrs, rect: { x: Math.round(rect.x), y: Math.round(rect.y), w: Math.round(rect.width), h: Math.round(rect.height) } });
          }
          return out;
        }
        """
        elements = await page.evaluate(script)
        lines = [f"# viewport {page.viewport_size['width'] if page.viewport_size else 0}x{page.viewport_size['height'] if page.viewport_size else 0}"]
        for item in elements:
            attrs = " ".join(item.get("attrs") or [])
            text = f' "{item.get("text")}"' if item.get("text") else ""
            rect = item.get("rect") or {}
            lines.append(f'{item.get("id")} {item.get("tag")}{text} {attrs} [x={rect.get("x")} y={rect.get("y")} w={rect.get("w")} h={rect.get("h")}]')
        return {"elements": elements, "text": "\n".join(lines)}

    async def _is_login_wall(self, page, action_type: str) -> bool:
        url = page.url.lower()
        if any(marker in url for marker in ["/login", "/i/flow/login", "checkpoint", "privacy/consent"]):
            return True
        login_selectors = [
            'input[name="text"][autocomplete="username"]',
            'input[name="session[username_or_email]"]',
            'input[type="password"]',
        ]
        for selector in login_selectors:
            try:
                if await page.locator(selector).first.count() > 0:
                    return True
            except Exception:
                continue
        return False

    async def _fill_first(self, page, selectors: list[str], value: str) -> None:
        last_error = None
        for selector in selectors:
            try:
                locator = page.locator(selector).first
                if await locator.count() == 0:
                    continue
                await locator.click(timeout=5000)
                try:
                    await locator.fill(value, timeout=5000)
                except Exception:
                    await page.keyboard.press("Meta+A" if platform.system().lower() == "darwin" else "Control+A")
                    await page.keyboard.type(value)
                return
            except Exception as exc:
                last_error = exc
        raise RuntimeError(f"Could not find a fill target. Last error: {last_error}")

    async def _click_first(self, page, selectors: list[str]) -> None:
        last_error = None
        for selector in selectors:
            try:
                locator = page.locator(selector).first
                if await locator.count() == 0:
                    continue
                await locator.click(timeout=10000)
                return
            except Exception as exc:
                last_error = exc
        raise RuntimeError(f"Could not find a clickable target. Last error: {last_error}")

    async def _await_permission(self, request_id: str, tool_name: str, input_data: dict, reason: str) -> dict:
        tool_use_id = "browser_perm_" + uuid.uuid4().hex[:20]
        await self.poster.post_stream_chunk(
            request_id=request_id,
            chunk_type="permission_request",
            chunk_data={
                "tool_use_id": tool_use_id,
                "tool_name": tool_name,
                "input": input_data,
                "reason": reason,
            },
        )

        deadline = time.monotonic() + int(input_data.get("approval_timeout_seconds") or APPROVAL_TIMEOUT_SECONDS)
        while time.monotonic() < deadline:
            decision = await self.poster.get_permission_decision(request_id, tool_use_id)
            status = (decision or {}).get("status")
            if status in ("allow", "deny"):
                return decision
            await asyncio.sleep(2)
        return {"status": "timeout", "reason": "Timed out waiting for approval."}

    async def _emit_tool_request(self, request_id: str, tool_name: str, input_data: dict) -> str:
        tool_use_id = "browser_tool_" + uuid.uuid4().hex[:20]
        await self.poster.post_stream_chunk(
            request_id=request_id,
            chunk_type="tool_request",
            chunk_data={
                "tool_use_id": tool_use_id,
                "tool_name": tool_name,
                "input": input_data,
            },
        )
        return tool_use_id

    async def _emit_tool_result(self, request_id: str, tool_name: str, status: str, output: str, exit_code: int = 0, metadata: dict | None = None, tool_use_id: str | None = None) -> None:
        await self.poster.post_stream_chunk(
            request_id=request_id,
            chunk_type="tool_result",
            chunk_data={
                "tool_use_id": tool_use_id or "browser_result_" + uuid.uuid4().hex[:20],
                "tool_name": tool_name,
                "status": status,
                "output": output,
                "exit_code": exit_code,
                **(metadata or {}),
            },
        )

    async def _content(self, request_id: str, content: str) -> None:
        await self.poster.post_stream_chunk(
            request_id=request_id,
            chunk_type="content",
            chunk_data={"content": content, "model": "gptree-graft:browser"},
        )

    async def _complete_failure(self, request_id: str, action_type: str, target_url: str | None, reason: str, output: str) -> None:
        # Bail out if the sub-handler already completed this request.
        # See _completed_requests docblock — protects the server from
        # double completion callbacks when post-success cleanup raises.
        if request_id and request_id in self._completed_requests:
            return
        await self._emit_tool_result(
            request_id,
            "graft.browser.error",
            reason,
            output,
            exit_code=1,
            metadata={"action_type": action_type, "target_url": target_url},
        )
        await self._mark_completed(request_id, self.poster.post_complete_request(
            request_id=request_id,
            response=output,
            metadata={
                "runtime": "browser",
                "status": "failed",
                "reason": reason,
                "action_type": action_type,
                "target_url": target_url,
            },
        ))

    async def _mark_completed(self, request_id: str | None, awaitable) -> None:
        """Await a post_complete_request call and record the request_id as
        completed so _complete_failure never double-fires.

        IMPORTANT: only record on success. Earlier this used a `finally`
        block, which set _completed_requests even when post_complete_request
        itself raised — that suppressed the outer exception handler's
        retry via _complete_failure, and the server saw zero terminal
        completions for that request. Now: if the await raises, the id is
        NOT recorded, the exception propagates, the outer handler calls
        _complete_failure, and the server gets a (failure) completion.
        The original double-completion guard (success → cleanup raises →
        outer except → _complete_failure) still works because the
        successful post path reaches the add() below before cleanup runs.
        """
        await awaitable
        if request_id:
            self._completed_requests.add(request_id)
            # Same bound as the dedup cache upstream; this set is per
            # runtime instance so it can stay smaller.
            if len(self._completed_requests) > 1000:
                # Cheap eviction: drop everything. Worst case we
                # double-complete one request after the eviction; the
                # server is idempotent on completion.
                self._completed_requests.clear()

    def _profile_dir(self) -> Path:
        base = os.getenv("GPTREE_GRAFT_BROWSER_PROFILE")
        if base:
            return Path(base).expanduser()
        return Path.home() / ".config" / "gptree-graft" / "chrome-profile"
