"""Placeholder for the future OpenClaw-compatible runtime."""

from __future__ import annotations

from .base import Runtime
from ..transport.http_poster import HttpPoster


class OpenClawRuntime(Runtime):
    name = "openclaw"

    def __init__(self, config, poster: HttpPoster):
        self.config = config
        self.poster = poster

    def capabilities(self) -> dict:
        return {
            "status": "planned",
            "protocols": ["openclaw-compatible"],
        }

    async def handle_work(self, data: dict) -> None:
        request_id = data.get("request_id")
        await self.poster.post_complete_request(
            request_id=request_id,
            response="OpenClaw runtime is installed but not enabled yet.",
            metadata={"runtime": "openclaw", "status": "not_implemented"},
        )
