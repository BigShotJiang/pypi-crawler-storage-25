"""GPTree Code runtime scaffold."""

from __future__ import annotations

import uuid
import asyncio

from .base import Runtime
from ..transport.http_poster import HttpPoster
from ..tools.base import ToolResult
from ..tools.registry import CORE_TOOL_NAMES, build_tool_registry


class CodeRuntime(Runtime):
    name = "code"
    APPROVAL_REQUIRED_TOOLS = {
        "bridge.bash.exec",
        "bridge.fs.write",
        "bridge.fs.edit",
        "bridge.git.worktree.enter",
        "bridge.git.worktree.exit",
        "bridge.hooks.run",
        "bridge.notebook.edit",
    }

    def __init__(self, config, poster: HttpPoster):
        self.config = config
        self.poster = poster

    def capabilities(self) -> dict:
        return {
            "tool_protocol_versions": [1],
            "tools": CORE_TOOL_NAMES,
            "status": "ready",
        }

    async def handle_work(self, data: dict) -> None:
        request_id = data.get("request_id")
        tool_calls = data.get("tool_calls", [])

        if tool_calls:
            await self._handle_tool_calls(request_id, data, tool_calls)
            return

        # Natural-language prompt parsing was removed: the GPTree server owns the planner loop.
        await self.poster.post_complete_request(
            request_id=request_id,
            response=(
                "GPTree Code is connected, but this bridge did not receive structured tool calls. "
                "Update GPTree to the latest release and ensure the conversation uses the GPTree Code provider."
            ),
            metadata={"runtime": "code", "status": "needs_structured_tools", "model": "gptree-code:local"},
        )

    async def _handle_tool_calls(self, request_id: str, data: dict, tool_calls: list[dict]) -> None:
        workspace = data.get("workspace") or {}
        # The server proposes a workspace root, but the bridge MUST NOT trust
        # an arbitrary path it received over the wire. WorkspaceGuard only
        # confines paths inside whatever root we pick; if the root itself is
        # attacker-controlled, every "safe relative path" tool call resolves
        # against that attacker-chosen directory. Fall back to the locally
        # configured workspace whenever the proposal is not on the trust list.
        proposed_root = workspace.get("root")
        if proposed_root and self.config.is_trusted_workspace_root(proposed_root):
            workspace_root = proposed_root
        else:
            workspace_root = self.config.workspace_dir
            if proposed_root:
                # Surface the rejection so the user sees why their tools are
                # running in the local workspace and not the remote-proposed
                # path — silent override is worse than a visible mismatch.
                await self.poster.post_stream_chunk(
                    request_id=request_id,
                    chunk_type="content",
                    chunk_data={
                        "content": (
                            f"[bridge] Server-proposed workspace root '{proposed_root}' is not "
                            f"on this bridge's local allowlist — running tools in '{workspace_root}' instead."
                        ),
                        "model": "gptree-code:local",
                    },
                )
        tools = build_tool_registry(workspace_root)
        final_output: list[str] = []
        metadata = {"runtime": "code", "model": "gptree-code:local", "tools_used": []}

        for call in tool_calls:
            tool_name = call.get("tool_name") or call.get("name")
            tool_use_id = call.get("tool_use_id") or str(uuid.uuid4())
            input_data = call.get("input") or {}

            await self.poster.post_stream_chunk(
                request_id=request_id,
                chunk_type="tool_request",
                chunk_data={
                    "tool_use_id": tool_use_id,
                    "tool_name": tool_name,
                    "input": input_data,
                },
            )

            await self.poster.post_tool_ack(request_id, tool_use_id)

            if self._requires_permission(tool_name, input_data):
                permission = await self._await_permission(request_id, tool_use_id, tool_name, input_data)
                if permission.get("status") != "allow":
                    output = permission.get("reason") or "Tool call was denied or timed out waiting for approval."
                    await self.poster.post_stream_chunk(
                        request_id=request_id,
                        chunk_type="tool_result",
                        chunk_data={
                            "tool_use_id": tool_use_id,
                            "tool_name": tool_name or "unknown",
                            "status": "denied",
                            "output": output,
                            "exit_code": 126,
                        },
                    )
                    await self.poster.post_stream_chunk(
                        request_id=request_id,
                        chunk_type="content",
                        chunk_data={"content": output, "model": "gptree-code:local"},
                    )
                    final_output.append(output)
                    continue

            if tool_name not in tools:
                output = f"Tool [{tool_name}] is not available in the Phase 2 code runtime scaffold."
                await self.poster.post_stream_chunk(
                    request_id=request_id,
                    chunk_type="tool_result",
                    chunk_data={
                        "tool_use_id": tool_use_id,
                        "tool_name": tool_name or "unknown",
                        "status": "failed",
                        "output": output,
                        "exit_code": 127,
                    },
                )
                final_output.append(output)
                continue

            try:
                result = await tools[tool_name].run_tool(input_data) if hasattr(tools[tool_name], "run_tool") else await tools[tool_name].run(input_data)
            except Exception as exc:
                result = ToolResult(
                    tool_name=tool_name,
                    output=str(exc),
                    status="failed",
                    exit_code=1,
                )

            metadata["tools_used"].append(
                {
                    "tool_use_id": tool_use_id,
                    "tool_name": tool_name,
                    "exit_code": result.exit_code,
                    **getattr(result, "metadata", {}),
                }
            )
            await self.poster.post_stream_chunk(request_id, "tool_result", result.as_chunk(tool_use_id))
            await self.poster.post_stream_chunk(
                request_id=request_id,
                chunk_type="content",
                chunk_data={"content": str(result.output), "model": "gptree-code:local"},
            )
            final_output.append(str(result.output))

        await self.poster.post_stream_chunk(
            request_id=request_id,
            chunk_type="done",
            chunk_data={},
            is_final=True,
        )
        await self.poster.post_complete_request(
            request_id=request_id,
            response="\n".join(final_output),
            metadata={**metadata, "status": "completed"},
        )

    def _requires_permission(self, tool_name: str | None, input_data: dict) -> bool:
        # NEVER honor an `approval: preapproved`/`auto` value in tool input.
        # That field is part of the server-supplied (and, transitively,
        # model-supplied) tool payload; trusting it lets a compromised
        # server bypass local approval for side-effecting tools by simply
        # adding `"approval": "preapproved"` to the input. Approval bypass
        # must be a local policy decision (see config.permission_mode), not
        # something the remote planner can talk us into.
        if self.config.permission_mode == "auto-approve":
            return False
        return tool_name in self.APPROVAL_REQUIRED_TOOLS

    async def _await_permission(self, request_id: str, tool_use_id: str, tool_name: str | None, input_data: dict) -> dict:
        await self.poster.post_stream_chunk(
            request_id=request_id,
            chunk_type="permission_request",
            chunk_data={
                "tool_use_id": tool_use_id,
                "tool_name": tool_name or "unknown",
                "input": input_data,
                "reason": f"Approval required to run {tool_name}.",
            },
        )

        # Resolve the timeout from three sources, in order of precedence:
        #   1. per-call override (the planner can set
        #      `approval_timeout_seconds` on a specific tool input),
        #   2. local config (env: GPTREE_BRIDGE_APPROVAL_TIMEOUT_SECONDS),
        #   3. the bare default of 1800s (30 min).
        # An EXPLICIT non-positive value (0 or negative) means "wait
        # indefinitely" — the loop has no deadline and only exits when
        # the user decides (or the agent run is cancelled server-side,
        # in which case the request gets torn down anyway).
        # MISSING / non-numeric input falls through to the configured
        # default, which keeps the safety net in place when the planner
        # forgets to set the field.
        raw = input_data.get("approval_timeout_seconds")
        if raw is None:
            timeout_seconds = int(getattr(self.config, "approval_timeout_seconds", 1800) or 0)
        else:
            try:
                # Honor explicit per-call override, including 0 / negative
                # for "no timeout". Non-numeric falls back to config.
                timeout_seconds = int(raw)
            except (TypeError, ValueError):
                timeout_seconds = int(getattr(self.config, "approval_timeout_seconds", 1800) or 0)

        loop = asyncio.get_event_loop()
        deadline = (loop.time() + timeout_seconds) if timeout_seconds > 0 else None
        while deadline is None or loop.time() < deadline:
            decision = await self.poster.get_permission_decision(request_id, tool_use_id)
            status = (decision or {}).get("status")
            if status in ("allow", "deny"):
                return decision
            await asyncio.sleep(2)

        return {"status": "timeout", "reason": "Timed out waiting for user approval."}
