"""Runtime contracts for GPTree bridge work handlers."""

from __future__ import annotations

from abc import ABC, abstractmethod


class Runtime(ABC):
    name: str

    @abstractmethod
    async def handle_work(self, data: dict) -> None:
        """Handle a single work item dispatched by GPTree."""

    async def handle_session_action(self, data: dict) -> None:
        """Handle runtime-specific session control. Optional."""
        return None

    def capabilities(self) -> dict:
        return {}
