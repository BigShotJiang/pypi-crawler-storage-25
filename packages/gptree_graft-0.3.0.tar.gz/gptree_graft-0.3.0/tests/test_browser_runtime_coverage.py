"""Coverage backfill for runtimes/browser.py + the bridge LRU dedup cache.

The existing test_bridge_config.py covers a few high-level browser-runtime
flows (setup-required, twitter-deny, snapshot serializer, dedup) but leaves
under-tested: every success path, both selector helpers, the await-permission
loop, profile-dir env override, the new single-completion guard, and the
defensive session_config coercion. This file targets those plus the
OrderedDict LRU in main.Bridge.handle_work.
"""

from __future__ import annotations

import asyncio
import os
import unittest
from pathlib import Path
from unittest.mock import AsyncMock, patch

from gptree_graft.config import BridgeConfig
from gptree_graft.runtimes.browser import BrowserRuntime


class PosterStub:
    def __init__(self, decisions=None):
        self.chunks = []
        self.completions = []
        self.tool_acks = []
        self.permission_decisions = decisions or {}

    async def post_stream_chunk(self, request_id, chunk_type, chunk_data, is_final=False):
        self.chunks.append({
            "request_id": request_id,
            "chunk_type": chunk_type,
            "chunk_data": chunk_data,
            "is_final": is_final,
        })
        return True

    async def post_complete_request(self, request_id, response, metadata=None):
        self.completions.append({
            "request_id": request_id,
            "response": response,
            "metadata": metadata or {},
        })
        return True

    async def post_tool_ack(self, request_id, tool_use_id):
        self.tool_acks.append({"request_id": request_id, "tool_use_id": tool_use_id})
        return True

    async def get_permission_decision(self, request_id, tool_use_id):
        return self.permission_decisions.get(tool_use_id, {"status": "allow", "reason": "test approved"})

    async def get_pending_requests(self, instance_id=None, runtimes=None):
        return []


def _make_runtime(decisions=None) -> tuple[BrowserRuntime, PosterStub]:
    config = BridgeConfig(runtime="browser", enabled_runtimes=["browser"])
    poster = PosterStub(decisions)
    return BrowserRuntime(config, poster), poster


def _run(coro):
    return asyncio.run(coro)


# ─── Sub-handler success paths (Twitter / Instagram / Facebook) ──────────


class BrowserHandlerSuccessTest(unittest.TestCase):
    def test_twitter_post_approved_publishes_and_marks_completed(self):
        runtime, poster = _make_runtime()
        runtime._fill_first = AsyncMock()
        runtime._click_first = AsyncMock()
        runtime._await_permission = AsyncMock(return_value={"status": "allow"})

        _run(runtime._handle_twitter_post(
            "tw-success-1",
            object(),
            {"type": "social.twitter.post", "args": {"post_text": "Branch your ideas with GPTree."}},
            "Branch your ideas with GPTree.",
        ))

        runtime._fill_first.assert_awaited_once()
        runtime._click_first.assert_awaited_once()
        self.assertEqual(poster.completions[-1]["metadata"]["status"], "completed")
        self.assertIn("published the X/Twitter post", poster.completions[-1]["response"])
        # The single-completion guard must record this id.
        self.assertIn("tw-success-1", runtime._completed_requests)

    def test_twitter_post_missing_text_fails_with_missing_fields(self):
        runtime, poster = _make_runtime()
        runtime._fill_first = AsyncMock()
        runtime._await_permission = AsyncMock()
        runtime._click_first = AsyncMock()

        _run(runtime._handle_twitter_post(
            "tw-missing",
            object(),
            {"type": "social.twitter.post", "args": {"url": "https://x.com/compose/post"}},
            "",
        ))

        runtime._fill_first.assert_not_called()
        runtime._await_permission.assert_not_called()
        # Failure path goes through _complete_failure which still uses
        # _mark_completed under the hood — so the request_id must be marked
        # completed exactly once.
        self.assertEqual(poster.completions[-1]["metadata"]["reason"], "missing_fields")
        self.assertIn("tw-missing", runtime._completed_requests)

    def test_instagram_bio_saved_after_approval(self):
        runtime, poster = _make_runtime()
        runtime._fill_first = AsyncMock()
        runtime._click_first = AsyncMock()
        runtime._await_permission = AsyncMock(return_value={"status": "allow"})

        _run(runtime._handle_instagram_bio(
            "ig-success",
            object(),
            {"type": "social.instagram.bio", "args": {"bio_text": "AI-curious builder."}},
            "AI-curious builder.",
        ))

        runtime._fill_first.assert_awaited_once()
        runtime._click_first.assert_awaited_once()
        self.assertEqual(poster.completions[-1]["metadata"]["status"], "completed")

    def test_instagram_bio_denied_does_not_click_save(self):
        runtime, poster = _make_runtime()
        runtime._fill_first = AsyncMock()
        runtime._click_first = AsyncMock()
        runtime._await_permission = AsyncMock(return_value={"status": "deny", "reason": "rethinking"})

        _run(runtime._handle_instagram_bio(
            "ig-deny",
            object(),
            {"type": "social.instagram.bio", "args": {"bio_text": "Hi."}},
            "Hi.",
        ))

        runtime._click_first.assert_not_called()
        self.assertEqual(poster.completions[-1]["metadata"]["status"], "user_cancelled")

    def test_instagram_bio_missing_text_fails(self):
        runtime, poster = _make_runtime()
        runtime._await_permission = AsyncMock()
        _run(runtime._handle_instagram_bio(
            "ig-missing",
            object(),
            {"type": "social.instagram.bio", "args": {}},
            "",
        ))
        self.assertEqual(poster.completions[-1]["metadata"]["reason"], "missing_fields")

    def test_facebook_page_create_approved_clicks_create(self):
        runtime, poster = _make_runtime()
        runtime._fill_first = AsyncMock()
        runtime._click_first = AsyncMock()
        runtime._await_permission = AsyncMock(return_value={"status": "allow"})

        _run(runtime._handle_facebook_page_create(
            "fb-success",
            object(),
            {"type": "social.facebook_page.create", "args": {
                "page_name": "GPTree",
                "category": "Software",
                "description": "Branching for AI conversations.",
            }},
        ))

        # 3 fills + 1 create click
        self.assertEqual(runtime._fill_first.await_count, 3)
        runtime._click_first.assert_awaited_once()
        self.assertEqual(poster.completions[-1]["metadata"]["status"], "completed")
        self.assertEqual(
            sorted(poster.completions[-1]["metadata"]["filled_fields"]),
            ["category", "description", "page_name"],
        )

    def test_facebook_page_create_skips_empty_fields_and_handles_fill_errors(self):
        runtime, poster = _make_runtime()
        runtime._click_first = AsyncMock()
        runtime._await_permission = AsyncMock(return_value={"status": "allow"})

        async def fill_side_effect(page, selectors, value):
            if value == "boom":
                raise RuntimeError("simulated fill failure")

        runtime._fill_first = AsyncMock(side_effect=fill_side_effect)

        _run(runtime._handle_facebook_page_create(
            "fb-mixed",
            object(),
            {"type": "social.facebook_page.create", "args": {
                "page_name": "GPTree",
                "category": "",          # skipped
                "description": "boom",   # fill raises -> caught, not added to filled
            }},
        ))

        filled = poster.completions[-1]["metadata"]["filled_fields"]
        self.assertIn("page_name", filled)
        self.assertNotIn("category", filled)
        self.assertNotIn("description", filled)

    def test_facebook_page_create_denied_does_not_click_create(self):
        runtime, poster = _make_runtime()
        runtime._fill_first = AsyncMock()
        runtime._click_first = AsyncMock()
        runtime._await_permission = AsyncMock(return_value={"status": "deny"})

        _run(runtime._handle_facebook_page_create(
            "fb-deny",
            object(),
            {"type": "social.facebook_page.create", "args": {"page_name": "x"}},
        ))

        runtime._click_first.assert_not_called()
        self.assertEqual(poster.completions[-1]["metadata"]["status"], "user_cancelled")


# ─── Single-completion guard (P1 fix) ────────────────────────────────────


class SingleCompletionGuardTest(unittest.TestCase):
    def test_complete_failure_short_circuits_when_request_already_completed(self):
        """The bug this guards against: a sub-handler successfully completes,
        then a Playwright cleanup raises, and the outer except calls
        _complete_failure. Without this guard the server sees two
        completion callbacks for one request_id."""
        runtime, poster = _make_runtime()
        _run(runtime._mark_completed("dup-1", asyncio.sleep(0)))
        # Simulate the success path having already added to poster.completions.
        poster.completions.append({"request_id": "dup-1", "response": "first", "metadata": {}})

        _run(runtime._complete_failure(
            "dup-1",
            "social.twitter.post",
            "https://x.com",
            reason="unknown",
            output="post-success cleanup raised",
        ))

        # Only the initial completion is present — the failure call no-oped.
        completions_for_dup1 = [c for c in poster.completions if c["request_id"] == "dup-1"]
        self.assertEqual(len(completions_for_dup1), 1)

    def test_failed_post_complete_does_not_mark_request_completed(self):
        """Regression (Codex P1): the previous _mark_completed used a
        `finally` block, which recorded the request_id even when the
        post_complete_request await itself raised. That neutered the
        outer handler's fallback to _complete_failure — it saw the id
        in _completed_requests and bailed out. Net effect: a transient
        network failure on the completion POST left the server with
        NO terminal completion at all.

        Contract under test: if the inner await raises, the id is NOT
        in _completed_requests, so a subsequent _complete_failure can
        still post a (failure) completion."""
        runtime, poster = _make_runtime()

        class BoomError(RuntimeError):
            pass

        async def failing_post():
            raise BoomError("network blip")

        with self.assertRaises(BoomError):
            _run(runtime._mark_completed("fail-1", failing_post()))

        self.assertNotIn(
            "fail-1",
            runtime._completed_requests,
            "a failed completion post must leave the id unrecorded so "
            "_complete_failure can still reach the server",
        )

        # And the failure path now actually runs.
        _run(runtime._complete_failure(
            "fail-1",
            "social.twitter.post",
            "https://x.com",
            reason="unknown",
            output="post-completion raised; routing through failure",
        ))
        self.assertTrue(
            any(c["request_id"] == "fail-1" for c in poster.completions),
            "_complete_failure must successfully post when the original completion failed",
        )

    def test_completed_requests_cap_evicts_under_pressure(self):
        runtime, _ = _make_runtime()
        for i in range(1100):
            runtime._completed_requests.add(f"req-{i}")
        # The eviction step clears the set when it crosses 1000; running
        # _mark_completed triggers the bound check. We just verify the
        # set never grows unbounded.
        async def burst():
            for i in range(1100, 1200):
                await runtime._mark_completed(f"req-{i}", asyncio.sleep(0))

        _run(burst())
        self.assertLessEqual(len(runtime._completed_requests), 1100)


# ─── Defensive session_config / action / args coercion (P2 fix) ──────────


class HandleWorkInputCoercionTest(unittest.TestCase):
    def test_handle_work_with_string_session_config_does_not_crash(self):
        runtime, poster = _make_runtime()

        # Force playwright-missing path so we exit cleanly without launching
        # a browser; the test goal is "no AttributeError" from non-dict input.
        with patch("importlib.util.find_spec", return_value=None):
            _run(runtime.handle_work({
                "request_id": "bad-1",
                "session_config": "this is not a dict",
            }))

        # We get a clean completion, not an exception.
        self.assertEqual(poster.completions[-1]["metadata"]["status"], "failed")
        self.assertEqual(poster.completions[-1]["metadata"]["reason"], "browser_setup_required")

    def test_handle_work_with_non_dict_action_args_does_not_crash(self):
        runtime, poster = _make_runtime()
        with patch("importlib.util.find_spec", return_value=None):
            _run(runtime.handle_work({
                "request_id": "bad-2",
                "session_config": {"action": ["not", "a", "dict"]},
            }))
        self.assertEqual(poster.completions[-1]["metadata"]["reason"], "browser_setup_required")


# ─── Selector helpers ────────────────────────────────────────────────────


class SelectorHelperTest(unittest.TestCase):
    def test_fill_first_skips_zero_count_selectors_and_uses_first_match(self):
        runtime, _ = _make_runtime()

        class LocatorStub:
            def __init__(self, count, fill_works=True):
                self._count = count
                self._fill_works = fill_works
                self.clicked = False
                self.filled_with = None

            async def count(self):
                return self._count

            async def click(self, timeout=None):
                self.clicked = True

            async def fill(self, value, timeout=None):
                if not self._fill_works:
                    raise RuntimeError("locator fill refused")
                self.filled_with = value

        class LocatorWrapper:
            def __init__(self, loc):
                self._loc = loc

            @property
            def first(self):
                return self._loc

        class PageStub:
            def __init__(self):
                self.calls = []
                self._locators = {
                    "a": LocatorStub(count=0),
                    "b": LocatorStub(count=1),
                }
                self.keyboard = self._Keyboard()

            class _Keyboard:
                def __init__(self):
                    self.presses = []
                    self.types = []

                async def press(self, key):
                    self.presses.append(key)

                async def type(self, value):
                    self.types.append(value)

            def locator(self, selector):
                self.calls.append(selector)
                return LocatorWrapper(self._locators[selector])

        page = PageStub()
        _run(runtime._fill_first(page, ["a", "b"], "hello"))
        self.assertEqual(page.calls, ["a", "b"])
        self.assertEqual(page._locators["b"].filled_with, "hello")

    def test_fill_first_falls_back_to_keyboard_when_locator_fill_refuses(self):
        runtime, _ = _make_runtime()

        class Locator:
            def __init__(self):
                self.clicked = False

            async def count(self):
                return 1

            async def click(self, timeout=None):
                self.clicked = True

            async def fill(self, value, timeout=None):
                raise RuntimeError("contenteditable refused")

        class Wrapper:
            def __init__(self, loc):
                self.first = loc

        class PageStub:
            def __init__(self):
                self.keyboard = self._Keyboard()
                self._loc = Locator()

            class _Keyboard:
                def __init__(self):
                    self.presses = []
                    self.types = []

                async def press(self, key):
                    self.presses.append(key)

                async def type(self, value):
                    self.types.append(value)

            def locator(self, selector):
                return Wrapper(self._loc)

        page = PageStub()
        _run(runtime._fill_first(page, ["div"], "fallback typed"))
        self.assertEqual(page.keyboard.types, ["fallback typed"])
        self.assertEqual(len(page.keyboard.presses), 1)

    def test_fill_first_raises_when_no_selector_matches(self):
        runtime, _ = _make_runtime()

        class Locator:
            async def count(self):
                return 0

        class Wrapper:
            def __init__(self):
                self.first = Locator()

        class PageStub:
            def locator(self, selector):
                return Wrapper()

        with self.assertRaisesRegex(RuntimeError, "Could not find a fill target"):
            _run(runtime._fill_first(PageStub(), ["a", "b"], "hi"))

    def test_click_first_clicks_first_visible_selector(self):
        runtime, _ = _make_runtime()

        class Locator:
            def __init__(self, count):
                self._count = count
                self.clicked = False

            async def count(self):
                return self._count

            async def click(self, timeout=None):
                self.clicked = True

        class Wrapper:
            def __init__(self, loc):
                self.first = loc

        class PageStub:
            def __init__(self):
                self._locs = {
                    "miss": Locator(count=0),
                    "hit": Locator(count=2),
                }

            def locator(self, selector):
                return Wrapper(self._locs[selector])

        page = PageStub()
        _run(runtime._click_first(page, ["miss", "hit"]))
        self.assertTrue(page._locs["hit"].clicked)

    def test_click_first_raises_when_no_selector_matches(self):
        runtime, _ = _make_runtime()

        class Locator:
            async def count(self):
                return 0

        class Wrapper:
            def __init__(self):
                self.first = Locator()

        class PageStub:
            def locator(self, selector):
                return Wrapper()

        with self.assertRaisesRegex(RuntimeError, "Could not find a clickable target"):
            _run(runtime._click_first(PageStub(), ["x"]))


# ─── Permission polling + login wall detection + profile dir ─────────────


class PermissionAndDetectorTest(unittest.TestCase):
    def test_await_permission_returns_allow_decision_from_poller(self):
        runtime, poster = _make_runtime(decisions={})

        # First decision is empty, second is allow. We patch the poster to
        # simulate the decision arriving on the second poll.
        polls = []

        async def staged(request_id, tool_use_id):
            polls.append(tool_use_id)
            if len(polls) < 2:
                return None
            return {"status": "allow", "reason": "user clicked allow"}

        poster.get_permission_decision = staged

        # Patch the runtime's asyncio.sleep reference (NOT the global one —
        # asyncio.run uses asyncio.sleep internally during shutdown and
        # would hang if its sleep was a no-op). The runtime imports asyncio
        # at module scope, so attribute-patching browser_mod.asyncio.sleep
        # scopes the patch to its callers only.
        from gptree_graft.runtimes import browser as browser_mod

        with patch.object(browser_mod.asyncio, "sleep", AsyncMock(return_value=None)):
            decision = _run(runtime._await_permission(
                "perm-1",
                "graft.browser.publish",
                {"approval_timeout_seconds": 5},
                "Approve?",
            ))

        self.assertEqual(decision["status"], "allow")
        self.assertGreaterEqual(len(polls), 2)

    def test_await_permission_times_out_when_no_decision_arrives(self):
        """Forcing a real timeout exercises the deadline branch without
        patching time.monotonic (which is also asyncio's internal clock —
        patching it deadlocks the event loop).

        We pass `approval_timeout_seconds=-1` so the deadline is already
        in the past on the first `while` check and the loop exits without
        ever hitting asyncio.sleep. Why -1 instead of 0? The runtime uses
        `or APPROVAL_TIMEOUT_SECONDS` to fall back when the value is
        falsy, and Python's 0 is falsy — so 0 would fall back to 1800s.
        Any truthy negative number bypasses that.
        """
        runtime, poster = _make_runtime()

        polls = []

        async def always_none(request_id, tool_use_id):
            polls.append(tool_use_id)
            return None

        poster.get_permission_decision = always_none

        decision = _run(runtime._await_permission(
            "perm-timeout",
            "graft.browser.publish",
            {"approval_timeout_seconds": -1},
            "Approve?",
        ))

        self.assertEqual(decision["status"], "timeout")
        # The loop must exit without polling at all when the deadline is
        # already past on entry.
        self.assertEqual(len(polls), 0)

    def test_is_login_wall_matches_login_url(self):
        runtime, _ = _make_runtime()

        class PageStub:
            url = "https://twitter.com/i/flow/login"

            def locator(self, selector):
                class L:
                    @property
                    def first(self):
                        return self

                    async def count(self):
                        return 0
                return L()

        self.assertTrue(_run(runtime._is_login_wall(PageStub(), "social.twitter.post")))

    def test_is_login_wall_matches_password_input_selector(self):
        runtime, _ = _make_runtime()

        class PageStub:
            url = "https://x.com/home"

            def locator(self, selector):
                if "password" in selector:
                    class HasPassword:
                        @property
                        def first(self):
                            return self

                        async def count(self):
                            return 1
                    return HasPassword()

                class Zero:
                    @property
                    def first(self):
                        return self

                    async def count(self):
                        return 0
                return Zero()

        self.assertTrue(_run(runtime._is_login_wall(PageStub(), "social.twitter.post")))

    def test_is_login_wall_returns_false_when_logged_in(self):
        runtime, _ = _make_runtime()

        class PageStub:
            url = "https://twitter.com/home"

            def locator(self, selector):
                class L:
                    @property
                    def first(self):
                        return self

                    async def count(self):
                        return 0
                return L()

        self.assertFalse(_run(runtime._is_login_wall(PageStub(), "social.twitter.post")))

    def test_profile_dir_honors_env_override(self):
        runtime, _ = _make_runtime()
        with patch.dict(os.environ, {"GPTREE_GRAFT_BROWSER_PROFILE": "/tmp/gptree-test-profile"}):
            self.assertEqual(runtime._profile_dir(), Path("/tmp/gptree-test-profile"))

    def test_profile_dir_falls_back_to_home_config(self):
        runtime, _ = _make_runtime()
        env = {k: v for k, v in os.environ.items() if k != "GPTREE_GRAFT_BROWSER_PROFILE"}
        with patch.dict(os.environ, env, clear=True):
            self.assertEqual(
                runtime._profile_dir(),
                Path.home() / ".config" / "gptree-graft" / "chrome-profile",
            )


# ─── Bridge LRU dedup cache (main.Bridge) — P1 fix #2 ────────────────────


class BridgeDedupLruTest(unittest.TestCase):
    def test_handled_request_ids_uses_ordered_dict_and_evicts_oldest(self):
        try:
            from gptree_graft.main import Bridge
        except ModuleNotFoundError as exc:
            self.skipTest(f"Bridge transport dependency unavailable: {exc}")

        bridge = Bridge(BridgeConfig(runtime="browser", enabled_runtimes=["browser"]))
        # Replace runtime so handle_work does not actually launch playwright.
        async def noop(data):
            return None
        bridge.runtimes.get("browser").handle_work = noop

        async def burst():
            for i in range(505):
                await bridge.handle_work({
                    "request_id": f"req-{i}",
                    "runtime": "browser",
                    "target_instance_id": bridge.instance_id,
                })

        _run(burst())

        # 500-bound. The OLDEST (req-0..req-4) must be gone, the most recent
        # MUST still be present — the prior set+slice impl gave neither
        # guarantee.
        self.assertEqual(len(bridge._handled_request_ids), 500)
        self.assertNotIn("req-0", bridge._handled_request_ids)
        self.assertNotIn("req-4", bridge._handled_request_ids)
        self.assertIn("req-504", bridge._handled_request_ids)


# ─── main.py CLI surface (parse_args, setup_browser, subprocess_run) ────


class MainCliTest(unittest.TestCase):
    def test_parse_args_accepts_browser_runtime_choice(self):
        from gptree_graft.main import _parse_args

        ns = _parse_args(["--runtime", "browser"])
        self.assertEqual(ns.runtime, "browser")

    def test_parse_args_rejects_unknown_runtime(self):
        from gptree_graft.main import _parse_args

        with self.assertRaises(SystemExit):
            _parse_args(["--runtime", "totally-made-up"])

    def test_parse_args_default_runtime_override(self):
        from gptree_graft.main import _parse_args

        ns = _parse_args([], default_runtime="pentest")
        self.assertEqual(ns.runtime, "pentest")

    def test_setup_browser_returns_1_when_playwright_missing(self):
        from gptree_graft.main import setup_browser

        with patch.dict("sys.modules", {"playwright": None}):
            # ModuleNotFoundError path: importing `playwright` will raise.
            # patch.dict alone doesn't simulate that — we need to make the
            # import statement itself raise. Use builtins.__import__ patch.
            import builtins

            real_import = builtins.__import__

            def fake_import(name, *a, **kw):
                if name == "playwright":
                    raise ModuleNotFoundError(name)
                return real_import(name, *a, **kw)

            with patch.object(builtins, "__import__", side_effect=fake_import):
                self.assertEqual(setup_browser(), 1)

    def test_subprocess_run_passes_through_returncode(self):
        from gptree_graft.main import subprocess_run

        # Run a command that returns exit code 0 in a portable way.
        rc = subprocess_run(["python3", "-c", "import sys; sys.exit(0)"])
        self.assertEqual(rc, 0)

        rc = subprocess_run(["python3", "-c", "import sys; sys.exit(7)"])
        self.assertEqual(rc, 7)

    def test_cli_dispatches_to_setup_browser_when_first_arg(self):
        """`gptree-bridge setup-browser` short-circuits before _parse_args."""
        import gptree_graft.main as mod

        with patch.object(mod.sys, "argv", ["gptree-bridge", "setup-browser"]):
            with patch.object(mod, "setup_browser", return_value=0) as setup:
                with self.assertRaises(SystemExit) as cm:
                    mod.cli()
                self.assertEqual(cm.exception.code, 0)
                setup.assert_called_once()


if __name__ == "__main__":
    unittest.main()
