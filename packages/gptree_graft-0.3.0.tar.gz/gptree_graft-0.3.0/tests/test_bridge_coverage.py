"""Coverage tests for the changed Python files in 1.13.0-agents.

These exercise the transport layer, the pentest runtime stub, the bridge
main loop, and the web/worktree tools — code paths the existing
`test_bridge_config.py` skipped because it focused on contract behavior.
"""

from __future__ import annotations

import asyncio
import os
import shutil
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch, AsyncMock, MagicMock

import json as _json
import httpx

from gptree_graft.config import BridgeConfig
from gptree_graft.transport.http_poster import HttpPoster
from gptree_graft.transport.ws_client import WsClient
from gptree_graft.runtimes.pentest import PentestRuntime, StubSessionManager, StubPentestSession
from gptree_graft.tools.web import WebFetchTool
from gptree_graft.tools.worktree import EnterWorktreeTool, ExitWorktreeTool


def make_response(status_code, json_data=None, text="", headers=None):
    """Build an httpx.Response that an AsyncClient mock can return.

    Some httpx versions ignore the `json=` kwarg in the constructor; encode
    the payload manually so resp.json() round-trips reliably across pinned
    versions.
    """
    request = httpx.Request("GET", "http://example.invalid/")
    final_headers = dict(headers or {})
    if json_data is not None:
        body = _json.dumps(json_data).encode("utf-8")
        final_headers.setdefault("content-type", "application/json")
        return httpx.Response(
            status_code=status_code,
            content=body,
            headers=final_headers,
            request=request,
        )
    return httpx.Response(
        status_code=status_code,
        text=text or "",
        headers=final_headers,
        request=request,
    )


class HttpPosterTest(unittest.TestCase):
    def setUp(self):
        self.poster = HttpPoster(
            gptree_url="https://example.invalid/",
            token="test-token",
            timeout=1.0,
            verify_ssl=True,
            api_prefix="bridge",
        )

    def test_url_and_headers_are_built_correctly(self):
        # The poster strips trailing slashes off gptree_url and the api
        # prefix so callers can pass either form. Headers carry the bearer
        # token plus JSON content-type.
        self.assertEqual(self.poster._url("stream-chunk"), "https://example.invalid/api/bridge/stream-chunk")
        self.assertEqual(self.poster._url("/stream-chunk"), "https://example.invalid/api/bridge/stream-chunk")
        self.assertEqual(self.poster._headers()["Authorization"], "Bearer test-token")
        self.assertEqual(self.poster._headers()["Content-Type"], "application/json")

    def test_retry_delay_honors_retry_after_header_then_falls_back_to_backoff(self):
        with_after = make_response(429, headers={"Retry-After": "2.5"})
        self.assertEqual(self.poster._retry_delay_seconds(with_after, attempt=0), 2.5)

        invalid_after = make_response(429, headers={"Retry-After": "not-a-number"})
        delay = self.poster._retry_delay_seconds(invalid_after, attempt=2)
        self.assertGreaterEqual(delay, 0.25)
        self.assertLessEqual(delay, 60.0)

        no_header = make_response(429, headers={})
        # Backoff doubles per attempt, capped at 60s.
        self.assertAlmostEqual(self.poster._retry_delay_seconds(no_header, attempt=0), 0.35)
        self.assertAlmostEqual(self.poster._retry_delay_seconds(no_header, attempt=1), 0.70)

    def test_post_stream_chunk_returns_true_on_200(self):
        async def run():
            with patch("httpx.AsyncClient") as mock_client_cls:
                client = mock_client_cls.return_value.__aenter__.return_value
                client.post = AsyncMock(return_value=make_response(200))
                result = await self.poster.post_stream_chunk(
                    "req-1", "tool_request", {"tool_use_id": "t-1"}, is_final=False
                )
                self.assertTrue(result)
                client.post.assert_called_once()

        asyncio.run(run())

    def test_post_returns_false_on_non_200_terminal(self):
        async def run():
            with patch("httpx.AsyncClient") as mock_client_cls:
                client = mock_client_cls.return_value.__aenter__.return_value
                client.post = AsyncMock(return_value=make_response(500))
                self.assertFalse(await self.poster.post_complete_request("req", "body"))

        asyncio.run(run())

    def test_post_returns_false_on_transport_exception(self):
        async def run():
            with patch("httpx.AsyncClient") as mock_client_cls:
                client = mock_client_cls.return_value.__aenter__.return_value
                client.post = AsyncMock(side_effect=httpx.ConnectError("boom"))
                self.assertFalse(await self.poster.post_tool_ack("req", "tool"))

        asyncio.run(run())

    def test_post_retries_on_429_then_succeeds(self):
        async def run():
            responses = [make_response(429, headers={"Retry-After": "0"}), make_response(200)]
            with patch("httpx.AsyncClient") as mock_client_cls, \
                 patch("asyncio.sleep", new=AsyncMock()):
                client = mock_client_cls.return_value.__aenter__.return_value
                client.post = AsyncMock(side_effect=responses)
                result = await self.poster.post_complete_request("req", "ok")
                self.assertTrue(result)
                self.assertEqual(client.post.call_count, 2)

        asyncio.run(run())

    def test_get_permission_decision_returns_payload(self):
        async def run():
            with patch("httpx.AsyncClient") as mock_client_cls:
                client = mock_client_cls.return_value.__aenter__.return_value
                client.get = AsyncMock(return_value=make_response(200, json_data={"status": "allow"}))
                got = await self.poster.get_permission_decision("req", "tool")
                self.assertEqual(got, {"status": "allow"})

        asyncio.run(run())

    def test_get_permission_decision_returns_none_on_non_200(self):
        async def run():
            with patch("httpx.AsyncClient") as mock_client_cls:
                client = mock_client_cls.return_value.__aenter__.return_value
                client.get = AsyncMock(return_value=make_response(404))
                self.assertIsNone(await self.poster.get_permission_decision("req", "tool"))

        asyncio.run(run())

    def test_get_pending_requests_passes_instance_and_runtimes(self):
        async def run():
            with patch("httpx.AsyncClient") as mock_client_cls:
                client = mock_client_cls.return_value.__aenter__.return_value
                client.get = AsyncMock(return_value=make_response(200, json_data={"requests": [{"id": 1}]}))
                requests = await self.poster.get_pending_requests(
                    instance_id="abc", runtimes=["code", "pentest"]
                )
                self.assertEqual(requests, [{"id": 1}])
                _args, kwargs = client.get.call_args
                self.assertEqual(kwargs["params"], {"instance_id": "abc", "runtimes": "code,pentest"})

        asyncio.run(run())

    def test_get_pending_requests_returns_empty_when_response_shape_is_unexpected(self):
        async def run():
            with patch("httpx.AsyncClient") as mock_client_cls:
                client = mock_client_cls.return_value.__aenter__.return_value
                # Server returns success but `requests` is a string, not a list.
                client.get = AsyncMock(return_value=make_response(200, json_data={"requests": "oops"}))
                self.assertEqual(await self.poster.get_pending_requests(), [])

        asyncio.run(run())

    def test_get_pending_requests_returns_empty_on_429(self):
        async def run():
            with patch("httpx.AsyncClient") as mock_client_cls:
                client = mock_client_cls.return_value.__aenter__.return_value
                client.get = AsyncMock(return_value=make_response(429, headers={"Retry-After": "1"}))
                self.assertEqual(await self.poster.get_pending_requests(), [])

        asyncio.run(run())

    def test_get_pending_requests_returns_empty_on_exception(self):
        async def run():
            with patch("httpx.AsyncClient") as mock_client_cls:
                client = mock_client_cls.return_value.__aenter__.return_value
                client.get = AsyncMock(side_effect=httpx.ReadTimeout("timeout"))
                self.assertEqual(await self.poster.get_pending_requests(), [])

        asyncio.run(run())

    def test_post_heartbeat_returns_dict_on_success_and_none_on_failure(self):
        async def run():
            with patch("httpx.AsyncClient") as mock_client_cls:
                client = mock_client_cls.return_value.__aenter__.return_value
                client.post = AsyncMock(return_value=make_response(200, json_data={"ok": True}))
                got = await self.poster.post_heartbeat("inst", "Bridge", "1.0.0", capabilities={"runtimes": ["code"]})
                self.assertEqual(got, {"ok": True})

            with patch("httpx.AsyncClient") as mock_client_cls:
                client = mock_client_cls.return_value.__aenter__.return_value
                client.post = AsyncMock(return_value=make_response(500))
                self.assertIsNone(await self.poster.post_heartbeat("inst", "Bridge", "1.0.0"))

            with patch("httpx.AsyncClient") as mock_client_cls:
                client = mock_client_cls.return_value.__aenter__.return_value
                client.post = AsyncMock(side_effect=httpx.ConnectError("nope"))
                self.assertIsNone(await self.poster.post_heartbeat("inst", "Bridge", "1.0.0"))

        asyncio.run(run())


class WsClientUrlAndDisconnectTest(unittest.TestCase):
    def test_ws_url_uses_configured_scheme_host_port_and_key(self):
        client = WsClient(
            gptree_url="https://example.invalid",
            token="t",
            ws_host="ws.example.invalid",
            ws_port=8080,
            ws_key="key-123",
            ws_scheme="wss",
            channel="private-bridge.1",
        )
        self.assertEqual(client.ws_url, "wss://ws.example.invalid:8080/app/key-123")

    def test_disconnect_closes_socket_and_clears_running_flag(self):
        async def run():
            client = WsClient(
                gptree_url="https://example.invalid",
                token="t",
                ws_host="h",
                ws_port=80,
                ws_key="k",
            )
            client._running = True
            ws_mock = MagicMock()
            ws_mock.close = AsyncMock()
            client._ws = ws_mock

            await client.disconnect()

            self.assertFalse(client._running)
            ws_mock.close.assert_awaited()

        asyncio.run(run())

    def test_subscribe_raises_when_no_channel_configured(self):
        async def run():
            client = WsClient(
                gptree_url="https://example.invalid",
                token="t",
                ws_host="h",
                ws_port=80,
                ws_key="k",
                channel="",
            )
            with self.assertRaises(ConnectionError):
                await client._subscribe()

        asyncio.run(run())


class PentestRuntimeStubTest(unittest.TestCase):
    """Hits PentestRuntime via its StubSessionManager fallback (no legacy SDK)."""

    def setUp(self):
        self.config = BridgeConfig(runtime="pentest")

    def _make_poster_stub(self):
        poster = MagicMock()
        poster.post_stream_chunk = AsyncMock(return_value=True)
        poster.post_complete_request = AsyncMock(return_value=True)
        return poster

    def test_capabilities_lists_pentest_modes(self):
        runtime = PentestRuntime(self.config, self._make_poster_stub())
        caps = runtime.capabilities()
        self.assertEqual(caps["modes"], ["auto", "web", "network", "full"])
        self.assertIn("content", caps["chunk_types"])
        self.assertIn("done", caps["chunk_types"])

    def test_handle_work_streams_stub_session_events_and_completes(self):
        async def run():
            poster = self._make_poster_stub()
            # Force the stub fallback path even when the legacy package is
            # installed in the test environment.
            with patch("gptree_graft.runtimes.pentest.LegacySessionManager", None):
                runtime = PentestRuntime(self.config, poster)
                await runtime.handle_work({
                    "request_id": "req-pentest-1",
                    "message": "scan",
                    "session_config": {"target": "example.com", "mode": "pentestgpt:web"},
                })

            chunk_types = [call.kwargs.get("chunk_type") or call.args[1] for call in poster.post_stream_chunk.call_args_list]
            self.assertIn("content", chunk_types)
            self.assertIn("pentest_tool", chunk_types)
            self.assertIn("done", chunk_types)
            poster.post_complete_request.assert_awaited_once()
            # PentestRuntime calls post_complete_request positionally:
            #   (request_id, full_content, metadata)
            call = poster.post_complete_request.call_args
            metadata = call.kwargs.get("metadata") or call.args[2]
            self.assertEqual(metadata["status"], "completed")
            self.assertGreaterEqual(len(metadata["tools_used"]), 1)

        asyncio.run(run())

    def test_handle_work_recovers_from_session_exception(self):
        async def run():
            poster = self._make_poster_stub()
            with patch("gptree_graft.runtimes.pentest.LegacySessionManager", None):
                runtime = PentestRuntime(self.config, poster)
                runtime.session_manager = MagicMock()
                runtime.session_manager.get.return_value = None
                runtime.session_manager.create.side_effect = RuntimeError("boom")

                await runtime.handle_work({
                    "request_id": "req-pentest-err",
                    "message": "scan",
                    "session_config": {"target": "example.com"},
                })

            poster.post_complete_request.assert_awaited_once()
            call = poster.post_complete_request.call_args
            metadata = call.kwargs.get("metadata") or call.args[2]
            self.assertEqual(metadata["status"], "error")

        asyncio.run(run())

    def test_handle_session_action_dispatches_pause_resume_stop(self):
        async def run():
            poster = self._make_poster_stub()
            with patch("gptree_graft.runtimes.pentest.LegacySessionManager", None):
                runtime = PentestRuntime(self.config, poster)
            mgr = StubSessionManager(self.config)
            session = mgr.create(target="example.com", mode="pentestgpt:auto")
            session.pause = AsyncMock()
            session.resume = AsyncMock()
            runtime.session_manager = mgr

            # No-session id is a no-op; both branches should not raise.
            await runtime.handle_session_action({"action": "pause"})

            await runtime.handle_session_action({"action": "pause", "pentest_session_id": session.session_id})
            session.pause.assert_awaited_once()

            await runtime.handle_session_action({"action": "resume", "pentest_session_id": session.session_id})
            session.resume.assert_awaited_once()

            await runtime.handle_session_action({"action": "stop", "pentest_session_id": session.session_id})
            self.assertIsNone(mgr.get(session.session_id))

            # Session-not-found path
            await runtime.handle_session_action({"action": "pause", "pentest_session_id": "nope"})

        asyncio.run(run())


class WebFetchToolTest(unittest.TestCase):
    def test_web_fetch_returns_completed_for_200_response(self):
        async def run():
            tool = WebFetchTool("/tmp")
            with patch("httpx.AsyncClient") as mock_client_cls:
                client = mock_client_cls.return_value.__aenter__.return_value
                client.get = AsyncMock(return_value=make_response(200, text="hello world", headers={"content-type": "text/plain"}))
                result = await tool.run({"url": "https://example.invalid/page", "max_chars": 1000})

            self.assertEqual(result.status, "completed")
            self.assertEqual(result.exit_code, 0)
            self.assertIn("hello world", result.output)
            self.assertEqual(result.metadata["status_code"], 200)
            self.assertFalse(result.truncated)

        asyncio.run(run())

    def test_web_fetch_truncates_long_responses(self):
        async def run():
            tool = WebFetchTool("/tmp")
            big = "x" * 200
            with patch("httpx.AsyncClient") as mock_client_cls:
                client = mock_client_cls.return_value.__aenter__.return_value
                client.get = AsyncMock(return_value=make_response(200, text=big))
                result = await tool.run({"url": "https://example.invalid/", "max_chars": 50})

            self.assertTrue(result.truncated)
            self.assertIn("[output truncated]", result.output)

        asyncio.run(run())

    def test_web_fetch_marks_failure_on_4xx(self):
        async def run():
            tool = WebFetchTool("/tmp")
            with patch("httpx.AsyncClient") as mock_client_cls:
                client = mock_client_cls.return_value.__aenter__.return_value
                client.get = AsyncMock(return_value=make_response(404, text="not found"))
                result = await tool.run({"url": "https://example.invalid/missing"})

            self.assertEqual(result.status, "failed")
            self.assertEqual(result.exit_code, 404)

        asyncio.run(run())


class WorktreeToolsTest(unittest.TestCase):
    def test_enter_creates_new_worktree_when_path_missing(self):
        if not shutil.which("git"):
            self.skipTest("git not installed in this environment")

        async def run():
            with tempfile.TemporaryDirectory() as workspace:
                # init a real git repo so `git worktree add` succeeds
                proc = await asyncio.create_subprocess_exec(
                    "git", "init", "-q", cwd=workspace,
                    stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT,
                )
                await proc.communicate()
                # set a basic config + a single commit
                for cmd in [
                    ["git", "config", "user.email", "t@t"],
                    ["git", "config", "user.name", "t"],
                    ["git", "commit", "--allow-empty", "-m", "init", "-q"],
                ]:
                    p = await asyncio.create_subprocess_exec(*cmd, cwd=workspace, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT)
                    await p.communicate()

                tool = EnterWorktreeTool(workspace)
                result = await tool.run({
                    "branch": "agent-coverage",
                    "worktree_root": ".gptree/worktrees",
                })
                self.assertEqual(result.metadata["branch"], "agent-coverage")
                self.assertTrue(Path(result.metadata["worktree_path"]).exists())

        asyncio.run(run())

    def test_exit_without_remove_does_not_delete_path(self):
        async def run():
            with tempfile.TemporaryDirectory() as workspace:
                target = Path(workspace, ".gptree", "worktrees", "agent-x")
                target.mkdir(parents=True)
                tool = ExitWorktreeTool(workspace)
                result = await tool.run({"path": ".gptree/worktrees/agent-x", "remove": False})
                self.assertFalse(result.metadata["removed"])
                self.assertTrue(target.exists())

        asyncio.run(run())

    def test_exit_with_remove_returns_failed_when_git_unavailable(self):
        async def run():
            with tempfile.TemporaryDirectory() as workspace:
                Path(workspace, ".gptree", "worktrees", "agent-y").mkdir(parents=True)
                tool = ExitWorktreeTool(workspace)
                with patch("shutil.which", return_value=None):
                    result = await tool.run({"path": ".gptree/worktrees/agent-y", "remove": True})
                self.assertEqual(result.status, "failed")
                self.assertEqual(result.exit_code, 127)

        asyncio.run(run())

    def test_enter_returns_failed_when_git_unavailable(self):
        async def run():
            with tempfile.TemporaryDirectory() as workspace:
                tool = EnterWorktreeTool(workspace)
                with patch("shutil.which", return_value=None):
                    result = await tool.run({"branch": "x", "worktree_root": ".gptree/worktrees"})
                self.assertEqual(result.status, "failed")
                self.assertEqual(result.exit_code, 127)

        asyncio.run(run())


class BridgeMainTest(unittest.TestCase):
    def test_register_runtimes_skips_unknown_and_registers_known(self):
        from gptree_graft.main import Bridge
        config = BridgeConfig(
            runtime="code",
            enabled_runtimes=["code", "pentest", "openclaw", "not-a-runtime"],
            workspace_dir="/tmp",
        )
        bridge = Bridge(config)
        self.assertEqual(sorted(bridge.runtimes.names()), ["code", "openclaw", "pentest"])

    def test_handle_work_routes_to_registered_runtime(self):
        from gptree_graft.main import Bridge
        async def run():
            config = BridgeConfig(runtime="code", enabled_runtimes=["code"], workspace_dir="/tmp")
            bridge = Bridge(config)
            handled = []
            async def fake_handle(data):
                handled.append(data)
            bridge.runtimes.get("code").handle_work = fake_handle  # type: ignore[assignment]

            await bridge.handle_work({"runtime": "code", "request_id": "req-1"})
            self.assertEqual(handled[0]["request_id"], "req-1")

        asyncio.run(run())

    def test_handle_work_reports_unavailable_runtime(self):
        from gptree_graft.main import Bridge
        async def run():
            config = BridgeConfig(runtime="code", enabled_runtimes=["code"], workspace_dir="/tmp")
            bridge = Bridge(config)
            bridge.poster.post_complete_request = AsyncMock(return_value=True)
            await bridge.handle_work({"runtime": "pentest", "request_id": "req-no-rt"})
            bridge.poster.post_complete_request.assert_awaited_once()
            metadata = bridge.poster.post_complete_request.call_args.kwargs["metadata"]
            self.assertEqual(metadata["status"], "unavailable")

        asyncio.run(run())

    def test_handle_session_action_silently_skips_unknown_runtime(self):
        from gptree_graft.main import Bridge
        async def run():
            config = BridgeConfig(runtime="code", enabled_runtimes=["code"], workspace_dir="/tmp")
            bridge = Bridge(config)
            # Should not raise even though the runtime isn't registered.
            await bridge.handle_session_action({"runtime": "openclaw"})

        asyncio.run(run())

    def test_pending_work_loop_skips_already_claimed_request_ids(self):
        from gptree_graft.main import Bridge
        async def run():
            config = BridgeConfig(runtime="code", enabled_runtimes=["code"], workspace_dir="/tmp")
            bridge = Bridge(config)
            # Stop the loop after one iteration so the test exits.
            bridge._running = True
            calls = []
            async def get_pending(instance_id=None, runtimes=None):
                bridge._running = False
                return [
                    {"request_id": "dup"},
                    {"request_id": "dup"},
                    {"request_id": ""},
                    {"request_id": "fresh"},
                ]
            async def handle(data):
                calls.append(data["request_id"])
            bridge.poster.get_pending_requests = get_pending  # type: ignore[assignment]
            bridge.handle_work = handle  # type: ignore[assignment]

            await bridge._pending_work_loop()
            await asyncio.sleep(0.05)

            # `dup` should appear only once; the empty id and the fresh one
            # are filtered/included as expected.
            self.assertIn("dup", calls)
            self.assertEqual(calls.count("dup"), 1)
            self.assertIn("fresh", calls)
            self.assertNotIn("", calls)

        asyncio.run(run())

    def test_stop_clears_running_flag(self):
        from gptree_graft.main import Bridge
        config = BridgeConfig(runtime="code", enabled_runtimes=["code"], workspace_dir="/tmp")
        bridge = Bridge(config)
        bridge._running = True
        # No ws_client → stop() should still flip the flag without raising.
        bridge.stop()
        self.assertFalse(bridge._running)


class BridgeConfigEdgeTest(unittest.TestCase):
    def test_apply_bootstrap_sets_user_id_channel_and_ws_fields(self):
        cfg = BridgeConfig()
        cfg.apply_bootstrap({
            "user_id": 42,
            "channel": "private-bridge.42",
            "reverb": {"key": "k", "host": "r.example", "port": 6001, "scheme": "https"},
        })
        self.assertEqual(cfg.user_id, 42)
        self.assertEqual(cfg.channel, "private-bridge.42")
        self.assertEqual(cfg.ws_host, "r.example")
        self.assertEqual(cfg.ws_port, 6001)
        # https was normalized to wss.
        self.assertEqual(cfg.ws_scheme, "wss")
        self.assertEqual(cfg.ws_key, "k")

    def test_apply_bootstrap_rejects_invalid_port(self):
        cfg = BridgeConfig()
        with self.assertRaises(ValueError):
            cfg.apply_bootstrap({
                "user_id": 1,
                "channel": "c",
                "reverb": {"key": "k", "host": "h", "port": 70000, "scheme": "wss"},
            })

    def test_apply_bootstrap_rejects_invalid_scheme(self):
        cfg = BridgeConfig()
        with self.assertRaises(ValueError):
            cfg.apply_bootstrap({
                "user_id": 1,
                "channel": "c",
                "reverb": {"key": "k", "host": "h", "port": 80, "scheme": "ftp"},
            })

    def test_needs_bootstrap_reports_true_until_ws_fields_filled(self):
        cfg = BridgeConfig(ws_key="", ws_host="")
        self.assertTrue(cfg.needs_bootstrap)
        cfg.ws_key = "k"
        cfg.ws_host = "h"
        self.assertFalse(cfg.needs_bootstrap)

    def test_is_trusted_workspace_root_matches_only_configured_paths(self):
        with tempfile.TemporaryDirectory() as workspace, tempfile.TemporaryDirectory() as elsewhere:
            cfg = BridgeConfig(workspace_dir=workspace, workspace_allowlist=[])
            self.assertTrue(cfg.is_trusted_workspace_root(workspace))
            self.assertFalse(cfg.is_trusted_workspace_root(elsewhere))
            self.assertFalse(cfg.is_trusted_workspace_root(""))
            self.assertFalse(cfg.is_trusted_workspace_root(None))

            cfg2 = BridgeConfig(workspace_dir=workspace, workspace_allowlist=[elsewhere])
            self.assertTrue(cfg2.is_trusted_workspace_root(elsewhere))


class WsClientHandlersTest(unittest.TestCase):
    """Cover the connect / _listen / _ping_loop / _subscribe paths."""

    def test_listen_dispatches_work_and_session_action_events(self):
        async def run():
            calls = {"work": [], "session": []}
            async def on_work(d): calls["work"].append(d)
            async def on_session(d): calls["session"].append(d)

            client = WsClient(
                gptree_url="https://example.invalid",
                token="t",
                ws_host="h", ws_port=80, ws_key="k",
                channel="c",
                on_work=on_work,
                on_session_action=on_session,
            )

            messages = [
                _json.dumps({"event": "work.dispatched", "data": _json.dumps({"runtime": "code"})}),
                _json.dumps({"event": "session.action", "data": {"action": "pause"}}),
                _json.dumps({"event": "pusher:pong"}),
                _json.dumps({"event": "pusher:error", "data": {"message": "bad"}}),
                "{not-json",  # JSONDecodeError path
            ]

            class _AsyncIter:
                def __init__(self, items): self._iter = iter(items)
                def __aiter__(self): return self
                async def __anext__(self):
                    try: return next(self._iter)
                    except StopIteration: raise StopAsyncIteration

            await client._listen(_AsyncIter(messages))
            await asyncio.sleep(0.05)

            self.assertEqual(calls["work"][0]["runtime"], "code")
            self.assertEqual(calls["session"][0]["action"], "pause")

        asyncio.run(run())

    def test_subscribe_sends_pusher_subscribe_after_auth(self):
        async def run():
            client = WsClient(
                gptree_url="https://example.invalid",
                token="t",
                ws_host="h", ws_port=80, ws_key="k",
                channel="private-bridge.1",
            )
            client._socket_id = "1.2"

            ws_mock = MagicMock()
            sent = []
            async def fake_send(payload): sent.append(payload)
            async def fake_recv():
                return _json.dumps({"event": "pusher_internal:subscription_succeeded"})
            ws_mock.send = fake_send
            ws_mock.recv = fake_recv
            client._ws = ws_mock

            with patch("httpx.AsyncClient") as mock_client_cls:
                api_client = mock_client_cls.return_value.__aenter__.return_value
                api_client.post = AsyncMock(return_value=make_response(200, json_data={"auth": "key:sig"}))
                await client._subscribe()

            self.assertEqual(len(sent), 1)
            payload = _json.loads(sent[0])
            self.assertEqual(payload["event"], "pusher:subscribe")
            self.assertEqual(payload["data"]["auth"], "key:sig")

        asyncio.run(run())

    def test_subscribe_raises_on_non_200_auth_response(self):
        async def run():
            client = WsClient(
                gptree_url="https://example.invalid",
                token="t",
                ws_host="h", ws_port=80, ws_key="k",
                channel="private-bridge.1",
            )
            client._socket_id = "1.2"
            with patch("httpx.AsyncClient") as mock_client_cls:
                api_client = mock_client_cls.return_value.__aenter__.return_value
                api_client.post = AsyncMock(return_value=make_response(403))
                with self.assertRaises(ConnectionError):
                    await client._subscribe()

        asyncio.run(run())

    def test_ping_loop_exits_when_send_fails(self):
        async def run():
            client = WsClient(
                gptree_url="https://example.invalid",
                token="t", ws_host="h", ws_port=80, ws_key="k",
            )
            ws = MagicMock()
            ws.send = AsyncMock(side_effect=ConnectionError("closed"))
            with patch("asyncio.sleep", new=AsyncMock()):
                await client._ping_loop(ws)
            ws.send.assert_awaited_once()

        asyncio.run(run())

    def test_connect_retries_after_transport_error(self):
        # connect() loops until _running becomes False; verify it calls
        # _connect_once and on connection error sleeps then exits when
        # disconnect() flips the flag.
        async def run():
            client = WsClient(
                gptree_url="https://example.invalid",
                token="t", ws_host="h", ws_port=80, ws_key="k",
            )

            attempt = {"n": 0}
            async def fake_connect_once():
                attempt["n"] += 1
                if attempt["n"] >= 2:
                    client._running = False
                raise ConnectionError("simulated")

            client._connect_once = fake_connect_once  # type: ignore[assignment]
            with patch("asyncio.sleep", new=AsyncMock()):
                await client.connect()

            self.assertEqual(attempt["n"], 2)

        asyncio.run(run())


class BridgeMainBootstrapTest(unittest.TestCase):
    def test_bootstrap_skips_when_ws_fields_already_set(self):
        from gptree_graft.main import Bridge
        async def run():
            cfg = BridgeConfig(
                runtime="code", enabled_runtimes=["code"], workspace_dir="/tmp",
                ws_key="k", ws_host="h", ws_port=80, ws_scheme="wss",
            )
            bridge = Bridge(cfg)
            with patch("httpx.AsyncClient") as mock_client_cls:
                # If bootstrap is called we'd see this raise; ensure it's not.
                client = mock_client_cls.return_value.__aenter__.return_value
                client.get = AsyncMock(side_effect=AssertionError("should not call"))
                await bridge._bootstrap()

        asyncio.run(run())

    def test_bootstrap_exits_on_non_200(self):
        from gptree_graft.main import Bridge
        async def run():
            cfg = BridgeConfig(runtime="code", enabled_runtimes=["code"], workspace_dir="/tmp")
            bridge = Bridge(cfg)
            with patch("httpx.AsyncClient") as mock_client_cls:
                client = mock_client_cls.return_value.__aenter__.return_value
                client.get = AsyncMock(return_value=make_response(401))
                with self.assertRaises(SystemExit):
                    await bridge._bootstrap()

        asyncio.run(run())

    def test_bootstrap_exits_on_connect_error(self):
        from gptree_graft.main import Bridge
        async def run():
            cfg = BridgeConfig(runtime="code", enabled_runtimes=["code"], workspace_dir="/tmp")
            bridge = Bridge(cfg)
            with patch("httpx.AsyncClient") as mock_client_cls:
                client = mock_client_cls.return_value.__aenter__.return_value
                client.get = AsyncMock(side_effect=httpx.ConnectError("nope"))
                with self.assertRaises(SystemExit):
                    await bridge._bootstrap()

        asyncio.run(run())

    def test_bootstrap_applies_response_payload_on_200(self):
        from gptree_graft.main import Bridge
        async def run():
            cfg = BridgeConfig(runtime="code", enabled_runtimes=["code"], workspace_dir="/tmp")
            bridge = Bridge(cfg)
            payload = {
                "user_id": 7,
                "channel": "private-bridge.7",
                "reverb": {"key": "K", "host": "ws.example", "port": 8080, "scheme": "wss"},
            }
            with patch("httpx.AsyncClient") as mock_client_cls:
                client = mock_client_cls.return_value.__aenter__.return_value
                client.get = AsyncMock(return_value=make_response(200, json_data=payload))
                await bridge._bootstrap()
            self.assertEqual(cfg.ws_host, "ws.example")
            self.assertEqual(cfg.user_id, 7)

        asyncio.run(run())

    def test_start_exits_when_token_missing(self):
        from gptree_graft.main import Bridge
        async def run():
            cfg = BridgeConfig(runtime="code", enabled_runtimes=["code"], workspace_dir="/tmp", gptree_token="")
            bridge = Bridge(cfg)
            with self.assertRaises(SystemExit):
                await bridge.start()

        asyncio.run(run())

    def test_heartbeat_loop_exits_when_running_flag_clears(self):
        from gptree_graft.main import Bridge
        async def run():
            cfg = BridgeConfig(runtime="code", enabled_runtimes=["code"], workspace_dir="/tmp")
            bridge = Bridge(cfg)
            calls = []
            async def fake_post(*args, **kwargs):
                calls.append(kwargs)
                bridge._running = False
                return {"ok": True}
            bridge.poster.post_heartbeat = fake_post  # type: ignore[assignment]
            bridge._running = True
            with patch("asyncio.sleep", new=AsyncMock()):
                await bridge._heartbeat_loop()
            self.assertEqual(len(calls), 1)

        asyncio.run(run())

    def test_handle_claimed_work_removes_id_from_claimed_set_after_completion(self):
        from gptree_graft.main import Bridge
        async def run():
            cfg = BridgeConfig(runtime="code", enabled_runtimes=["code"], workspace_dir="/tmp")
            bridge = Bridge(cfg)
            async def fake_handle(data): return None
            bridge.handle_work = fake_handle  # type: ignore[assignment]
            claimed = {"req-1"}
            await bridge._handle_claimed_work({"request_id": "req-1"}, claimed)
            self.assertEqual(claimed, set())

        asyncio.run(run())


if __name__ == "__main__":
    unittest.main()
