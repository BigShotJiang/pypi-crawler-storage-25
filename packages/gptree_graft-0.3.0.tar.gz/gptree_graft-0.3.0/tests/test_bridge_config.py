import os
import asyncio
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import AsyncMock, patch

from gptree_graft.config import BridgeConfig
from gptree_graft.runtimes.browser import BrowserRuntime
from gptree_graft.runtimes.code import CodeRuntime
from gptree_graft.runtimes.openclaw import OpenClawRuntime
from gptree_graft.runtimes.pentest import PentestRuntime
from gptree_graft.runtimes.registry import RuntimeRegistry
from gptree_graft.tools.bash import BashTool
from gptree_graft.tools.extensions import HookRunTool, McpConfigTool, NotebookEditTool, SkillListTool, SkillReadTool
from gptree_graft.tools.files import FileEditTool, FileReadTool, FileWriteTool
from gptree_graft.tools.registry import CORE_TOOL_NAMES, build_tool_registry
from gptree_graft.tools.search import GlobTool, GrepTool
from gptree_graft.tools.worktree import EnterWorktreeTool, ExitWorktreeTool


class PosterStub:
    def __init__(self):
        self.chunks = []
        self.completions = []
        self.permission_decisions = {}
        self.tool_acks = []

    async def post_stream_chunk(self, request_id, chunk_type, chunk_data, is_final=False):
        self.chunks.append({
            "request_id": request_id,
            "chunk_type": chunk_type,
            "chunk_data": chunk_data,
            "is_final": is_final,
        })
        return True

    async def post_complete_request(self, request_id, response, metadata=None):
        self.completions.append({
            "request_id": request_id,
            "response": response,
            "metadata": metadata or {},
        })
        return True

    async def post_tool_ack(self, request_id, tool_use_id):
        # CodeRuntime always acks before executing (two-phase tool contract);
        # the stub records calls so tests can assert ordering.
        self.tool_acks.append({"request_id": request_id, "tool_use_id": tool_use_id})
        return True

    async def get_permission_decision(self, request_id, tool_use_id):
        return self.permission_decisions.get(tool_use_id, {"status": "allow", "reason": "test approved"})

    async def get_pending_requests(self, instance_id=None, runtimes=None):
        return []


class BridgeConfigTest(unittest.TestCase):
    def test_config_builds_consolidated_capabilities(self):
        env = {
            **os.environ,
            "GPTREE_BRIDGE_RUNTIME": "code",
            "GPTREE_BRIDGE_RUNTIMES": "code,pentest",
            "GPTREE_BRIDGE_WORKSPACE": "/tmp/gptree-workspace",
        }
        with patch.dict(os.environ, env, clear=True):
            config = BridgeConfig.from_env()

        self.assertEqual(config.runtime, "code")
        self.assertEqual(config.workspace_dir, "/tmp/gptree-workspace")
        self.assertEqual(config.capabilities()["runtimes"], ["code", "pentest"])
        self.assertEqual(config.capabilities()["active_runtime"], "code")
        self.assertEqual(config.capabilities()["workspace"]["root"], "/tmp/gptree-workspace")

    def test_runtime_registry_collects_runtime_capabilities(self):
        config = BridgeConfig(runtime="pentest", enabled_runtimes=["pentest", "code", "openclaw", "browser"])
        poster = PosterStub()
        registry = RuntimeRegistry()

        registry.register(PentestRuntime(config, poster))
        registry.register(CodeRuntime(config, poster))
        registry.register(OpenClawRuntime(config, poster))
        registry.register(BrowserRuntime(config, poster))

        self.assertEqual(registry.names(), ["browser", "code", "openclaw", "pentest"])
        self.assertEqual(registry.capabilities()["pentest"]["modes"], ["auto", "web", "network", "full"])
        self.assertEqual(registry.capabilities()["code"]["status"], "ready")
        self.assertEqual(registry.capabilities()["browser"]["status"], "ready")
        self.assertIn("social.facebook_page.create", registry.capabilities()["browser"]["actions"])
        self.assertIn("social.twitter.post", registry.capabilities()["browser"]["actions"])

    def test_browser_runtime_reports_clear_setup_command_when_playwright_missing(self):
        async def run_test():
            config = BridgeConfig(runtime="browser", enabled_runtimes=["browser"])
            poster = PosterStub()
            runtime = BrowserRuntime(config, poster)

            with patch("importlib.util.find_spec", return_value=None):
                await runtime.handle_work({
                    "request_id": "browser-1",
                    "session_config": {
                        "action": {
                            "type": "social.facebook_page.create",
                            "args": {"url": "https://www.facebook.com/pages/create"},
                        },
                    },
                })

            self.assertEqual(poster.completions[0]["metadata"]["runtime"], "browser")
            self.assertEqual(poster.completions[0]["metadata"]["reason"], "browser_setup_required")
            self.assertIn("gptree-graft setup-browser", poster.completions[0]["response"])

        asyncio.run(run_test())

    def test_browser_runtime_fills_twitter_and_pauses_for_publish_approval(self):
        async def run_test():
            config = BridgeConfig(runtime="browser", enabled_runtimes=["browser"])
            poster = PosterStub()
            runtime = BrowserRuntime(config, poster)
            post_text = "GPTree helps you branch ideas and make better decisions."

            runtime._fill_first = AsyncMock()
            runtime._click_first = AsyncMock()
            runtime._await_permission = AsyncMock(return_value={"status": "deny", "reason": "review later"})
            await runtime._handle_twitter_post(
                "twitter-1",
                object(),
                {
                    "type": "social.twitter.post",
                    "args": {
                        "url": "https://x.com/compose/post",
                        "post_text": post_text,
                    },
                },
                post_text,
            )

            runtime._fill_first.assert_awaited_once()
            runtime._await_permission.assert_awaited_once()
            runtime._click_first.assert_not_called()
            self.assertEqual(poster.completions[0]["metadata"]["status"], "user_cancelled")
            self.assertIn("did not publish", poster.completions[0]["response"])

        asyncio.run(run_test())

    def test_bridge_ignores_work_targeted_at_another_instance_and_dedupes(self):
        async def run_test():
            try:
                from gptree_graft.main import Bridge
            except ModuleNotFoundError as exc:
                self.skipTest(f"Bridge transport dependency unavailable: {exc}")

            bridge = Bridge(BridgeConfig(runtime="browser", enabled_runtimes=["browser"]))
            poster = PosterStub()
            bridge.poster = poster
            calls = []

            async def handle_work(data):
                calls.append(data["request_id"])

            bridge.runtimes.get("browser").handle_work = handle_work
            await bridge.handle_work({
                "request_id": "targeted-away",
                "runtime": "browser",
                "target_instance_id": "someone-else",
            })
            await bridge.handle_work({
                "request_id": "same-request",
                "runtime": "browser",
                "target_instance_id": bridge.instance_id,
            })
            await bridge.handle_work({
                "request_id": "same-request",
                "runtime": "browser",
                "target_instance_id": bridge.instance_id,
            })

            self.assertEqual(calls, ["same-request"])
            self.assertEqual(poster.completions, [])

        asyncio.run(run_test())

    def test_browser_snapshot_serializes_visible_actionable_elements(self):
        async def run_test():
            runtime = BrowserRuntime(BridgeConfig(runtime="browser", enabled_runtimes=["browser"]), PosterStub())

            class PageStub:
                viewport_size = {"width": 1280, "height": 720}

                async def evaluate(self, _script):
                    return [{
                        "id": "@1",
                        "tag": "button",
                        "text": "Post",
                        "attrs": ['role="button"', 'data-testid="tweetButton"'],
                        "rect": {"x": 10, "y": 20, "w": 80, "h": 32},
                    }]

            snapshot = await runtime._snapshot(PageStub())
            self.assertIn("@1 button \"Post\"", snapshot["text"])
            self.assertEqual(snapshot["elements"][0]["id"], "@1")

        asyncio.run(run_test())

    def test_bridge_claims_pending_requests_from_polling_fallback(self):
        async def run_test():
            try:
                from gptree_graft.main import Bridge
            except ModuleNotFoundError as exc:
                self.skipTest(f"Bridge transport dependency unavailable: {exc}")

            bridge = Bridge(BridgeConfig(runtime="code", enabled_runtimes=["code"]))
            poster = PosterStub()
            pending = [{
                "request_id": "queued-1",
                "runtime": "code",
                "message": "read README.md",
            }]
            calls = []

            async def get_pending_requests(instance_id=None, runtimes=None):
                # Verify the poller now identifies itself by instance + runtimes
                # so the server can scope claims to this bridge.
                self.assertEqual(instance_id, bridge.instance_id)
                self.assertIn("code", runtimes or [])
                bridge._running = False
                return pending

            async def handle_work(data):
                calls.append(data)

            poster.get_pending_requests = get_pending_requests
            bridge.poster = poster
            bridge.handle_work = handle_work
            bridge._running = True

            await bridge._pending_work_loop()
            await asyncio.sleep(0)

            self.assertEqual(calls, pending)

        asyncio.run(run_test())

    def test_bridge_instance_id_is_stable_for_same_machine_workspace_and_runtime(self):
        try:
            from gptree_graft.main import Bridge
        except ModuleNotFoundError as exc:
            self.skipTest(f"Bridge transport dependency unavailable: {exc}")

        config = BridgeConfig(
            runtime="code",
            enabled_runtimes=["code"],
            workspace_dir="/tmp/gptree-workspace",
            instance_name="GPTree Bridge",
        )

        self.assertEqual(Bridge(config).instance_id, Bridge(config).instance_id)

    def test_bridge_instance_id_can_be_overridden_from_env(self):
        env = {
            **os.environ,
            "GPTREE_BRIDGE_INSTANCE_ID": "gptree-fixed-local",
        }
        with patch.dict(os.environ, env, clear=True):
            config = BridgeConfig.from_env()

        self.assertEqual(config.instance_id, "gptree-fixed-local")

    def test_bash_tool_runs_inside_workspace_and_blocks_cwd_escape(self):
        with tempfile.TemporaryDirectory() as workspace:
            tool = BashTool(workspace_root=workspace)
            result = asyncio.run(tool.run("printf ok"))

            self.assertEqual(result.output, "ok")
            self.assertEqual(result.exit_code, 0)

            with self.assertRaises(ValueError):
                asyncio.run(tool.run("printf no", cwd="/tmp"))

    def test_file_tools_read_write_and_edit_inside_workspace(self):
        with tempfile.TemporaryDirectory() as workspace:
            write = FileWriteTool(workspace)
            read = FileReadTool(workspace)
            edit = FileEditTool(workspace)

            asyncio.run(write.run({"path": "notes.txt", "content": "hello world"}))
            read_result = asyncio.run(read.run({"path": "notes.txt"}))
            self.assertEqual(read_result.output, "hello world")

            edit_result = asyncio.run(edit.run({
                "path": "notes.txt",
                "old_string": "world",
                "new_string": "GPTree",
            }))
            self.assertIn("+hello GPTree", edit_result.output)
            self.assertEqual(Path(workspace, "notes.txt").read_text(), "hello GPTree")

            with self.assertRaises(ValueError):
                asyncio.run(read.run({"path": "/tmp/outside.txt"}))

    def test_search_tools_grep_and_glob(self):
        with tempfile.TemporaryDirectory() as workspace:
            Path(workspace, "src").mkdir()
            Path(workspace, "src", "app.py").write_text("print('GPTree')\n")
            Path(workspace, "README.md").write_text("Nothing\n")

            glob_result = asyncio.run(GlobTool(workspace).run({"pattern": "**/*.py"}))
            self.assertEqual(glob_result.output, ["src/app.py"])

            grep_result = asyncio.run(GrepTool(workspace).run({"pattern": "GPTree", "include": "*.py"}))
            self.assertEqual(grep_result.output[0]["path"], "src/app.py")
            self.assertEqual(grep_result.output[0]["line"], 1)

    def test_code_runtime_dispatches_core_tools_generically(self):
        with tempfile.TemporaryDirectory() as workspace:
            poster = PosterStub()
            runtime = CodeRuntime(BridgeConfig(workspace_dir=workspace), poster)

            asyncio.run(runtime.handle_work({
                "request_id": "req-core-tools",
                "workspace": {"root": workspace},
                "tool_calls": [
                    {
                        "tool_use_id": "write-1",
                        "tool_name": "bridge.fs.write",
                        "input": {"path": "hello.txt", "content": "hello"},
                    },
                    {
                        "tool_use_id": "read-1",
                        "tool_name": "bridge.fs.read",
                        "input": {"path": "hello.txt"},
                    },
                ],
            }))

            result_chunks = [chunk for chunk in poster.chunks if chunk["chunk_type"] == "tool_result"]
            permission_chunks = [chunk for chunk in poster.chunks if chunk["chunk_type"] == "permission_request"]
            self.assertEqual(len(permission_chunks), 1)
            self.assertEqual(len(result_chunks), 2)
            self.assertEqual(result_chunks[1]["chunk_data"]["output"], "hello")
            self.assertEqual(poster.completions[0]["metadata"]["status"], "completed")
            # Two-phase contract: every tool_use_id should be acked before
            # execution so the server can reconcile bridge work even if a
            # tool_result chunk later races ahead of the ack.
            self.assertEqual(
                [a["tool_use_id"] for a in poster.tool_acks],
                ["write-1", "read-1"],
            )

    def test_code_runtime_rejects_untrusted_workspace_root(self):
        # Server-supplied workspace.root that is not on the bridge's local
        # allowlist must be ignored — falling back to the configured local
        # workspace_dir — and the user-visible content chunk must explain
        # the override so a compromised account/server cannot silently
        # redirect tool I/O to another folder on the user's machine.
        with tempfile.TemporaryDirectory() as local_workspace, tempfile.TemporaryDirectory() as elsewhere:
            poster = PosterStub()
            runtime = CodeRuntime(BridgeConfig(workspace_dir=local_workspace), poster)

            asyncio.run(runtime.handle_work({
                "request_id": "req-untrusted-root",
                "workspace": {"root": elsewhere},
                "tool_calls": [
                    {
                        "tool_use_id": "read-1",
                        "tool_name": "bridge.fs.read",
                        "input": {"path": "anything.txt"},
                    },
                ],
            }))

            content_chunks = [c for c in poster.chunks if c["chunk_type"] == "content"]
            warning_seen = any(
                "not on this bridge's local allowlist" in (c["chunk_data"].get("content") or "")
                for c in content_chunks
            )
            self.assertTrue(warning_seen, "Bridge must surface the workspace-root rejection")

    def test_code_runtime_payload_cannot_bypass_local_approval(self):
        # The bridge MUST NOT honor `approval: preapproved` from the tool
        # input — that field arrives over the wire from the server/planner
        # and trusting it would let a compromised server skip approval for
        # side-effecting tools.
        with tempfile.TemporaryDirectory() as workspace:
            poster = PosterStub()
            poster.permission_decisions["write-1"] = {"status": "deny", "reason": "not approved"}
            runtime = CodeRuntime(BridgeConfig(workspace_dir=workspace), poster)

            asyncio.run(runtime.handle_work({
                "request_id": "req-bypass",
                "workspace": {"root": workspace},
                "tool_calls": [
                    {
                        "tool_use_id": "write-1",
                        "tool_name": "bridge.fs.write",
                        "input": {
                            "path": "no.txt",
                            "content": "blocked",
                            "approval": "preapproved",
                        },
                    },
                ],
            }))

            self.assertFalse(Path(workspace, "no.txt").exists())
            permission_chunks = [c for c in poster.chunks if c["chunk_type"] == "permission_request"]
            self.assertEqual(len(permission_chunks), 1)

    def test_code_runtime_denies_side_effecting_tools_without_permission(self):
        with tempfile.TemporaryDirectory() as workspace:
            poster = PosterStub()
            poster.permission_decisions["write-denied"] = {"status": "deny", "reason": "No writes"}
            runtime = CodeRuntime(BridgeConfig(workspace_dir=workspace), poster)

            asyncio.run(runtime.handle_work({
                "request_id": "req-denied-tool",
                "workspace": {"root": workspace},
                "tool_calls": [
                    {
                        "tool_use_id": "write-denied",
                        "tool_name": "bridge.fs.write",
                        "input": {"path": "blocked.txt", "content": "no"},
                    },
                ],
            }))

            self.assertFalse(Path(workspace, "blocked.txt").exists())
            result_chunks = [chunk for chunk in poster.chunks if chunk["chunk_type"] == "tool_result"]
            self.assertEqual(result_chunks[0]["chunk_data"]["status"], "denied")
            self.assertEqual(result_chunks[0]["chunk_data"]["exit_code"], 126)

    def test_code_runtime_without_tool_calls_returns_needs_structured_tools(self):
        # Natural-language prompt parsing was removed: the GPTree server
        # owns the planner loop. Bridges that receive a bare message (no
        # tool_calls) should reply with a clear "needs structured tools"
        # status instead of trying to interpret prose.
        with tempfile.TemporaryDirectory() as workspace:
            poster = PosterStub()
            runtime = CodeRuntime(BridgeConfig(workspace_dir=workspace), poster)

            asyncio.run(runtime.handle_work({
                "request_id": "req-no-tools",
                "message": "read README.md",
            }))

            self.assertEqual(len(poster.completions), 1)
            self.assertEqual(poster.completions[0]["metadata"]["status"], "needs_structured_tools")

    def test_tool_registry_contains_phase_three_tools(self):
        with tempfile.TemporaryDirectory() as workspace:
            tools = build_tool_registry(workspace)
            self.assertEqual(sorted(tools.keys()), sorted(CORE_TOOL_NAMES))
            self.assertIn("bridge.fs.edit", tools)
            self.assertIn("bridge.web.fetch", tools)
            self.assertIn("bridge.git.worktree.enter", tools)
            self.assertIn("bridge.notebook.edit", tools)

    def test_worktree_tools_reuse_existing_worktree_and_exit_without_removal(self):
        with tempfile.TemporaryDirectory() as workspace:
            worktree_path = Path(workspace, ".gptree", "worktrees", "agent-a")
            worktree_path.mkdir(parents=True)

            enter_result = asyncio.run(EnterWorktreeTool(workspace).run({
                "branch": "agent/a",
                "worktree_root": ".gptree/worktrees",
            }))

            self.assertEqual(enter_result.metadata["worktree_path"], os.path.realpath(worktree_path))
            self.assertTrue(enter_result.metadata["reused"])

            exit_result = asyncio.run(ExitWorktreeTool(workspace).run({
                "path": ".gptree/worktrees/agent-a",
                "remove": False,
            }))

            self.assertFalse(exit_result.metadata["removed"])
            self.assertTrue(worktree_path.exists())

    def test_skill_tools_discover_and_read_project_skills(self):
        with tempfile.TemporaryDirectory() as workspace:
            skill_dir = Path(workspace, ".gptree", "skills", "reviewer")
            skill_dir.mkdir(parents=True)
            Path(skill_dir, "SKILL.md").write_text("# Reviewer\nCheck carefully.\n", encoding="utf-8")

            list_result = asyncio.run(SkillListTool(workspace).run({}))
            self.assertEqual(list_result.metadata["count"], 1)
            self.assertEqual(list_result.output[0]["id"], "reviewer")

            read_result = asyncio.run(SkillReadTool(workspace).run({"id": "reviewer"}))
            self.assertIn("Check carefully.", read_result.output)

    def test_mcp_config_tool_reads_project_config(self):
        with tempfile.TemporaryDirectory() as workspace:
            config_dir = Path(workspace, ".gptree")
            config_dir.mkdir()
            Path(config_dir, "mcp.json").write_text('{"servers":{"local":{"command":"node"}}}', encoding="utf-8")

            result = asyncio.run(McpConfigTool(workspace).run({}))

            self.assertEqual(result.metadata["count"], 1)
            self.assertEqual(result.output[0]["scope"], "project")
            self.assertIn("local", result.output[0]["config"]["servers"])

    def test_hook_tool_skips_missing_hook(self):
        with tempfile.TemporaryDirectory() as workspace:
            result = asyncio.run(HookRunTool(workspace).run({"hook": "PreToolUse", "payload": {"tool": "bridge.fs.read"}}))

            self.assertTrue(result.metadata["skipped"])
            self.assertIn("No hook installed", result.output)

    def test_notebook_edit_tool_replaces_cell_text(self):
        with tempfile.TemporaryDirectory() as workspace:
            notebook_path = Path(workspace, "notes.ipynb")
            notebook_path.write_text(json.dumps({
                "cells": [
                    {"cell_type": "markdown", "metadata": {}, "source": ["hello world\n"]},
                ],
                "metadata": {},
                "nbformat": 4,
                "nbformat_minor": 5,
            }), encoding="utf-8")

            result = asyncio.run(NotebookEditTool(workspace).run({
                "path": "notes.ipynb",
                "cell_index": 0,
                "old_string": "world",
                "new_string": "GPTree",
            }))
            updated = json.loads(notebook_path.read_text(encoding="utf-8"))

            self.assertEqual(result.output, "Notebook cell updated.")
            self.assertEqual(updated["cells"][0]["source"], ["hello GPTree\n"])


if __name__ == "__main__":
    unittest.main()
