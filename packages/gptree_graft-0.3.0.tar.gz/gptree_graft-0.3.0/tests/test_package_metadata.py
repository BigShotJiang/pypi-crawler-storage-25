"""Cover the importlib.metadata fallback in gptree_graft/__init__.py.

When the package is run from a checkout without `pip install`, the
metadata lookup fails and __version__ falls back to "0.0.0+unknown".
The bug-fix this guards: previously __version__ was hardcoded to
"0.1.0" while pyproject.toml said "0.2.0", so the server-reported
bridge version silently lied about what was deployed.
"""

from __future__ import annotations

import importlib
import sys
import unittest
from unittest.mock import patch

import gptree_graft


class PackageVersionTest(unittest.TestCase):
    def test_version_attribute_is_string(self):
        self.assertIsInstance(gptree_graft.__version__, str)
        self.assertTrue(gptree_graft.__version__)

    def test_version_fallback_when_metadata_unavailable(self):
        """Re-import the module with `version()` patched to raise."""
        from importlib.metadata import PackageNotFoundError

        # Drop cached module so the import re-executes.
        sys.modules.pop("gptree_graft", None)
        try:
            with patch(
                "importlib.metadata.version",
                side_effect=PackageNotFoundError("gptree-graft"),
            ):
                pkg = importlib.import_module("gptree_graft")
                self.assertEqual(pkg.__version__, "0.0.0+unknown")
        finally:
            # Restore the live module for any subsequent test.
            sys.modules.pop("gptree_graft", None)
            importlib.import_module("gptree_graft")


if __name__ == "__main__":
    unittest.main()
