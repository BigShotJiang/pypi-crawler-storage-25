"""CLI config persistence with multi-profile support.

State lives at ``~/.sirb/config.json`` by default (overridable with
``SIRB_CLI_CONFIG``). We do NOT keep a separate credential store — the
config file's permissions are the boundary (0600 on Unix). On Windows
the file inherits user-level perms.

File layout (current, v2):

    {
      "active": "default",
      "profiles": {
        "default": {
          "base_url": "https://api.sirb.run",
          "api_key": "sirb_...",
          "default_model": "gemma4:e4b"
        },
        "local-dev": {
          "base_url": "http://localhost:8000",
          "api_key": "sirb_dev_key",
          "default_model": "mock-7b"
        }
      }
    }

Legacy (v1) layout — automatically migrated on first read:

    { "base_url": "...", "api_key": "...", "default_model": "..." }

…becomes a single profile named "default".
"""

from __future__ import annotations

import json
import os
import sys
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path


DEFAULT_PROFILE_NAME = "default"


def _config_path() -> Path:
    env = os.environ.get("SIRB_CLI_CONFIG")
    if env:
        return Path(env)
    return Path.home() / ".sirb" / "config.json"


@dataclass
class CliConfig:
    """One profile's worth of state. Kept as a flat dataclass so existing
    call sites — `cfg.base_url`, `cfg.api_key`, `cfg.default_model` — keep
    working unchanged after the multi-profile refactor."""

    base_url: str = "https://api.sirb.run"
    api_key: str | None = None
    default_model: str = "gemma4:e4b"

    @classmethod
    def load(cls) -> "CliConfig":
        """Load the active profile, or empty config if no file exists."""
        store = ProfileStore.load()
        return store.active_profile()

    def save(self) -> Path:
        """Save this config as the active profile, preserving siblings."""
        store = ProfileStore.load()
        store.profiles[store.active] = self
        return store.save()


@dataclass
class ProfileStore:
    """All saved profiles + which one is currently active."""

    active: str = DEFAULT_PROFILE_NAME
    profiles: dict[str, CliConfig] = field(default_factory=dict)

    @classmethod
    def load(cls) -> "ProfileStore":
        """Read the saved store.

        The file is the sole place we keep API keys, so the load path
        is paranoid:

          - File missing → empty store (first-run case).
          - File present but unreadable / unparseable → DO NOT silently
            substitute an empty store. The next `save()` would happily
            overwrite the broken-but-still-present keys with whatever
            the caller just typed, irreversibly destroying every other
            profile. Instead, sidestep the suspect file to a timestamped
            `.corrupt-<ts>` copy, print a clear stderr notice, and
            raise. The user must intervene before we touch the original.
        """
        p = _config_path()
        if not p.exists():
            return cls()
        try:
            raw = p.read_text()
            data = json.loads(raw)
        except FileNotFoundError:
            # Lost between exists() and read(): race with another `sirb`
            # process. Treat as first-run.
            return cls()
        except (OSError, json.JSONDecodeError, UnicodeDecodeError) as e:
            _preserve_corrupt(p, str(e))
            raise

        # Legacy v1 detection: flat object with base_url/api_key at the root.
        # Migrate inline by wrapping it as the "default" profile.
        if "profiles" not in data and any(k in data for k in ("api_key", "base_url", "default_model")):
            return cls(
                active=DEFAULT_PROFILE_NAME,
                profiles={DEFAULT_PROFILE_NAME: _profile_from_dict(data)},
            )

        profiles = {
            name: _profile_from_dict(body)
            for name, body in (data.get("profiles") or {}).items()
        }
        active = data.get("active") or DEFAULT_PROFILE_NAME
        # Defensive: if the file claims an active profile that doesn't exist,
        # fall back to one that does (or empty).
        if active not in profiles and profiles:
            active = next(iter(profiles))
        return cls(active=active, profiles=profiles)

    def save(self) -> Path:
        """Atomically persist the store at ~/.sirb/config.json (mode 0600).

        Writes to a sibling tmpfile created with O_CREAT|O_EXCL at mode
        0600 (so the file is never briefly world-readable), fsyncs, then
        os.replace()s onto the real path. A crash, SIGINT, or full disk
        mid-write leaves the previous good config intact rather than a
        zero-byte file that `load()` would refuse to interpret.
        """
        p = _config_path()
        p.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "active": self.active,
            "profiles": {name: asdict(cfg) for name, cfg in self.profiles.items()},
        }
        body = json.dumps(payload, indent=2)

        tmp = p.with_name(p.name + f".tmp.{os.getpid()}")
        # Open with the mode we want; on POSIX this creates the file
        # already at 0600. On Windows the mode is honored as far as
        # the platform allows. O_EXCL guards against a stale tmpfile
        # from a previous crashed write being reused.
        fd = os.open(str(tmp), os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_TRUNC, 0o600)
        try:
            # encoding=utf-8 explicit so Windows (cp1252 locale by
            # default) can't mis-encode any non-ASCII chars that ever
            # land in a profile name or saved future field.
            with os.fdopen(fd, "w", encoding="utf-8") as fh:
                fh.write(body)
                fh.flush()
                # fsync so the bytes are on disk before the rename — the
                # whole point of atomic-rename is undone if the rename
                # commits before the data does.
                try:
                    os.fsync(fh.fileno())
                except OSError:
                    pass
            os.replace(str(tmp), str(p))
        except Exception:
            try:
                tmp.unlink(missing_ok=True)
            except OSError:
                pass
            raise
        return p

    def active_profile(self) -> CliConfig:
        """Return the active profile, or an empty default when nothing is
        configured. Never raises — callers downstream check `api_key` is set."""
        if self.active in self.profiles:
            return self.profiles[self.active]
        return CliConfig()

    def names(self) -> list[str]:
        return sorted(self.profiles.keys())


def _profile_from_dict(d: dict) -> CliConfig:
    return CliConfig(
        base_url=d.get("base_url", CliConfig.base_url),
        api_key=d.get("api_key"),
        default_model=d.get("default_model", CliConfig.default_model),
    )


def _preserve_corrupt(p: Path, reason: str) -> None:
    """Move an unreadable / unparseable config file to a timestamped
    backup so the next `save()` can't unknowingly overwrite the user's
    only copy of their saved API keys. Print a clear stderr notice.
    """
    backup = p.with_name(f"{p.name}.corrupt-{int(time.time())}")
    try:
        p.rename(backup)
        location = backup
    except OSError:
        # Can't move it — at least surface the error so the caller
        # doesn't silently proceed against the suspect file.
        location = p
    print(
        f"sirb: refusing to use {p} — {reason}.\n"
        f"      The file has been preserved at {location}; "
        f"remove or repair it before retrying.",
        file=sys.stderr,
    )


def env_override_or_config() -> CliConfig:
    """Env vars trump the saved active profile. Lets users do one-off calls
    without rewriting their config and without flipping profiles."""
    cfg = CliConfig.load()
    if (env_url := os.environ.get("SIRB_BASE_URL")):
        cfg.base_url = env_url
    if (env_key := os.environ.get("SIRB_API_KEY")):
        cfg.api_key = env_key
    if (env_model := os.environ.get("SIRB_MODEL")):
        cfg.default_model = env_model
    return cfg
