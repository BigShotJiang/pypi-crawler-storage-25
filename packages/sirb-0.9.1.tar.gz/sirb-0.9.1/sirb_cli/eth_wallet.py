"""Helpers for the Ethereum-wallet half of ``sirb wallet new``.

Why this lives in its own module (per CLAUDE.md §3, separation of
concerns + §1, files < ~300 lines):

* ``commands/wallet.py`` owns the Typer CLI surface — argument
  parsing, output formatting, exit codes.
* This module owns the **security-sensitive material**: keypair
  generation, on-disk private-key storage, gateway transport for
  the auto-bind. Keeping it in one place makes it the obvious
  place a security reviewer looks first.

Public surface:

* :func:`generate_real_keypair` — `eth-account` wrapper that returns
  ``{address, private_key}`` for the lazy-import + clean-error
  pattern.
* :func:`write_wallet_file_atomic` — opens with
  ``O_CREAT|O_WRONLY|O_EXCL|O_TRUNC`` and explicit ``mode=0o600`` so
  the file is *never* world-readable between create and chmod (the
  reviewer-found race we ship without). Returns the actually-enforced
  mode so the caller can print honestly.
* :func:`try_bind_claim_address` — narrowly-typed PUT call. Returns a
  ``BindOutcome`` carrying either the trial-mint result or a precise
  failure reason. Replaces the previous ``except Exception`` swallow
  that conflated four distinct failure modes into one misleading
  "gateway unreachable" hint.
* :func:`legacy_payload` — random 40-hex pseudonymous identifier for
  the ``--legacy`` escape hatch.

These don't import Typer or Rich, so they're trivially unit-testable
without spinning up the CLI runner.
"""

from __future__ import annotations

import json
import os
import re
import secrets
import stat
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Literal

ETH_ADDRESS_RE = re.compile(r"^0x[0-9a-fA-F]{40}$")


class EthAccountMissing(RuntimeError):
    """Raised when ``eth_account`` isn't importable.

    Lifted out of the import path so the CLI surface can render a
    clear remediation (``pip install --upgrade sirb``) instead of
    leaking the ImportError stack trace.
    """


def generate_real_keypair() -> dict[str, str]:
    """Generate a real secp256k1 Ethereum keypair, fully client-side.

    Returns ``{address, private_key}``. The address is EIP-55
    checksummed; the private key is ``0x`` + 64 hex chars (33 bytes
    encoded). Uses ``os.urandom`` under the hood (via
    ``eth_account.Account.create``) — fails loud if the kernel
    entropy pool is unavailable instead of returning weak bytes.

    The private key is generated in this process and *never* leaves
    it through this module. Disk persistence is the caller's job and
    goes through :func:`write_wallet_file_atomic` which honors
    mode-0600 at inode creation.
    """
    try:
        from eth_account import Account
    except ImportError as e:
        raise EthAccountMissing(
            "eth-account is not importable. Reinstall the sirb CLI."
        ) from e
    acct = Account.create()
    # ``acct.address`` is EIP-55 checksummed. The gateway lowercases
    # before comparing, so both forms work — but we store the
    # checksummed form locally because that's what users see in
    # MetaMask/Etherscan and matching matters for "is this MY wallet?"
    # eyeballing.
    return {
        "address": acct.address,
        "private_key": acct.key.to_0x_hex(),
    }


def legacy_payload() -> dict[str, Any]:
    """Random 40-hex pseudonymous identifier — the pre-0.8 behaviour.

    Kept under ``--legacy`` for users who specifically want an
    off-chain identifier with no private key (throwaway test nodes
    that won't claim rewards).
    """
    return {
        "address": "0x" + secrets.token_hex(20),
        "private_key": None,
        "created_at": datetime.now(UTC).isoformat().replace("+00:00", "Z"),
        "kind": "legacy",
        "note": (
            "Off-chain identifier only — no private key. "
            "Cannot receive on-chain SIRB. Re-run `sirb wallet new` "
            "(without --legacy) to upgrade to a real Ethereum keypair."
        ),
    }


def wallet_path() -> Path:
    """Match install.sh: ``~/.sirb/wallet.json`` (mode 0600 when supported)."""
    return Path.home() / ".sirb" / "wallet.json"


def write_wallet_file_atomic(payload: dict[str, Any], path: Path) -> int:
    """Persist ``payload`` to ``path`` with **atomic mode-0600 creation**.

    Returns the mode actually achieved (``stat.S_IMODE``). On Unix
    this is always ``0o600`` because we pass the mode through
    ``os.open``'s ``mode=`` argument, which is honored at inode
    creation. On Windows, ``os.open`` ignores the mode argument and
    the file ends up under the user's home-dir ACL; we report the
    enforced bits honestly so callers don't lie to the user.

    Two security properties this function guarantees:

    1. **No race window.** The pre-fix code used
       ``Path.write_text()`` (creates file with default umask, often
       0644 — world-readable) then ``os.chmod(0o600)`` a few syscalls
       later. A co-tenant inotify race could read the private key in
       that window. ``os.open(..., O_CREAT|O_EXCL, 0o600)`` closes
       this — the file is created with the right mode atomically.

    2. **Refuses to overwrite a symlink.** ``O_EXCL`` rejects pre-
       existing paths, so a malicious local actor can't pre-plant a
       symlink at ``~/.sirb/wallet.json`` pointing at a writable spot
       and trick us into writing the private key there. Callers
       handling ``--force`` must ``path.unlink(missing_ok=True)``
       (NOT replace) before calling this — making the destructive
       step explicit.

    Raises whatever ``os.open`` / ``os.fdopen`` raise on filesystem
    failure. Caller is responsible for the user-visible error.
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    # Tighten the parent dir too. mkdir(mode=…) doesn't retighten
    # an existing dir (a quirk users notice on first run with
    # umask 022). chmod is best-effort — if it fails on a weird
    # filesystem we still proceed; the per-file mode below is the
    # real defense.
    try:
        os.chmod(path.parent, 0o700)
    except (OSError, NotImplementedError):
        pass

    flags = os.O_CREAT | os.O_WRONLY | os.O_TRUNC | os.O_EXCL
    fd = os.open(path, flags, 0o600)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(json.dumps(payload, indent=2) + "\n")
    except Exception:
        # Best-effort: try to remove a half-written file so a retry
        # with ``--force`` doesn't trip O_EXCL on a corpse.
        try:
            path.unlink(missing_ok=True)
        except OSError:
            pass
        raise

    # Defense-in-depth: some filesystems (FAT, certain NFS configs)
    # silently ignore the mode in os.open. Verify and report what
    # actually landed rather than pretending.
    return stat.S_IMODE(path.stat().st_mode)


# ─────────────────────── auto-bind (gateway PUT) ───────────────────────


@dataclass(frozen=True)
class BindOutcome:
    """Result of the auto-bind PUT to ``/v1/wallet/claim-address``.

    The pre-fix code returned ``(bool, str|None)`` and collapsed
    every failure into a generic "gateway unreachable" hint — exactly
    the silent-failure pattern CLAUDE.md §6 forbids. This dataclass
    lets the caller render the actual failure reason (dev_key_unsupported,
    no_database, network timeout, …) so support can debug.
    """

    bound: bool
    # Gateway's ``trial_mint`` field on success. Only meaningful when
    # ``bound`` is True.
    mint: Literal["minted", "already_granted", "unsupported", "failed"] | None = None
    # Why we didn't bind, when ``bound`` is False. One of:
    #   ``no_api_key``    — the user isn't logged in.
    #   ``http_<code>``   — gateway returned a structured HTTP error.
    #   ``network``       — connect / read / timeout failure.
    #   ``contract``      — response missing/wrong shape (gateway upgrade?).
    fail_reason: str | None = None
    # Human-readable detail to print alongside ``fail_reason`` when
    # available (e.g. the gateway's ``error.message``).
    fail_detail: str | None = None
    # Structured ``error.code`` from the gateway, when the failure
    # was an HTTP error and the body parsed cleanly.
    fail_code: str | None = None


def try_bind_claim_address(address: str) -> BindOutcome:
    """Best-effort PUT to bind ``address`` as the active key's claim address.

    Returns a typed :class:`BindOutcome`. The wallet file is already on
    disk before this call, so a failure here is recoverable — the user
    can re-run ``sirb wallet claim-address --set <addr>`` once the
    underlying issue (no login, network, etc.) is resolved.

    Narrow exception handling per reviewer feedback:

    * ``httpx.HTTPStatusError`` → extract the gateway's structured
      ``error.code`` + ``message`` so the user sees the actual reason
      (``dev_key_unsupported``, ``invalid_claim_address``,
      ``no_database``, …). The pre-fix code collapsed these into the
      generic "no API key, or unreachable" hint.
    * Network exceptions (``ConnectError``, ``TimeoutException``,
      generic ``HTTPError``) → reported as ``network`` with the
      exception type for debugging.
    * Anything else propagates. Unknown exceptions are bugs, not
      "expected" failure modes — they should fail loud.
    """
    import httpx

    from sirb_cli.client import SirbClient
    from sirb_cli.config import env_override_or_config

    cfg = env_override_or_config()
    if not cfg.api_key:
        return BindOutcome(bound=False, fail_reason="no_api_key")

    try:
        client = SirbClient(cfg)
        resp = client.put(
            "/v1/wallet/claim-address",
            body={"claim_address": address.lower()},
        )
    except httpx.HTTPStatusError as e:
        code, msg = _extract_gateway_error(e.response)
        return BindOutcome(
            bound=False,
            fail_reason=f"http_{e.response.status_code}",
            fail_code=code,
            fail_detail=msg,
        )
    except (httpx.ConnectError, httpx.TimeoutException) as e:
        return BindOutcome(
            bound=False,
            fail_reason="network",
            fail_detail=f"{type(e).__name__}: {e}",
        )
    except httpx.HTTPError as e:
        # Catchall for other httpx exceptions (DecodingError, RequestError).
        return BindOutcome(
            bound=False,
            fail_reason="network",
            fail_detail=f"{type(e).__name__}: {e}",
        )

    # Response handler — also narrow. A response missing
    # ``trial_mint`` shouldn't crash the CLI; the address WAS bound.
    if not isinstance(resp, dict):
        return BindOutcome(
            bound=False,
            fail_reason="contract",
            fail_detail=f"expected JSON object, got {type(resp).__name__}",
        )
    return BindOutcome(bound=True, mint=resp.get("trial_mint"))


def _extract_gateway_error(response: Any) -> tuple[str | None, str | None]:
    """Peel the FastAPI exception envelope to extract ``code`` + ``message``.

    The gateway raises ``HTTPException(status, {"error": {code, type,
    message}})``. FastAPI serialises that as ``{"detail": {"error":
    {...}}}``. We try the inner ``error`` shape first, then the outer
    ``detail`` shape, then fall back to the raw text — never crashing
    on a malformed body.
    """
    try:
        body = response.json()
    except (ValueError, AttributeError):
        try:
            text = response.text
        except AttributeError:
            text = ""
        return (None, text[:200] if text else None)

    if not isinstance(body, dict):
        return (None, str(body)[:200])
    detail = body.get("detail")
    if isinstance(detail, dict):
        err = detail.get("error")
        if isinstance(err, dict):
            return (err.get("code"), err.get("message"))
        # ``{"detail": "string message"}`` form — older endpoints.
        return (None, detail.get("message") if "message" in detail else None)
    if isinstance(detail, str):
        return (None, detail)
    err = body.get("error")
    if isinstance(err, dict):
        return (err.get("code"), err.get("message"))
    return (None, None)
