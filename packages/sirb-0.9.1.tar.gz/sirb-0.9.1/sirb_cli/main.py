"""``sirb`` CLI entry point.

Each command lives in ``sirb_cli.commands.<name>`` and registers itself
against the Typer app here.
"""

from __future__ import annotations

import typer

from sirb_cli.commands import (
    admin, balance, chat, deploy, keys, login, models, observations, opencode,
    profiles, signing_secret, status, update, usage, wallet,
)

app = typer.Typer(
    name="sirb",
    no_args_is_help=True,
    help=(
        "Sirb — Decentralized AI Compute CLI.\n\n"
        "[bold yellow]⚠ Experimental / beta software.[/bold yellow] "
        "Sirb is in active development. Interfaces, on-chain contracts, "
        "image tags, pricing, and reward mechanics may change without notice. "
        "Provided AS-IS, no warranty — maintainers are not responsible for "
        "any damages, data loss, financial loss, or other consequences. Run on "
        "hardware you control, with credentials and funds you can afford to lose. "
        "Full notice: https://sirb.run/docs/about/"
    ),
    rich_markup_mode="rich",
    add_completion=False,
)

app.command(name="login", help="Save your API key and base URL to ~/.sirb/config.json.")(login.run)
app.command(name="status", help="Health check — gateway, auth, network, local node.")(status.run)
app.add_typer(
    models.app, name="models",
    help="List available models, or add/remove models on your running node.",
)
app.command(name="balance", help="Show your current Sirb allowance.")(balance.run)
app.command(name="usage", help="Show your usage rollup.")(usage.run)
app.command(name="chat", help="Send a single chat completion request.")(chat.run)

app.add_typer(profiles.app, name="profiles",
              help="Manage saved profiles (multiple keys / gateways / models).")
app.add_typer(keys.app, name="keys", help="Manage API keys.")
app.add_typer(wallet.app, name="wallet",
              help="Generate or inspect off-chain wallet identifiers.")
app.add_typer(signing_secret.app, name="signing-secret",
              help="Generate HMAC signing secrets for the node↔gateway envelope.")
app.add_typer(deploy.app, name="deploy",
              help="Deploy a node on this machine, or a brand-new gateway on Fly.io.")
app.add_typer(update.app, name="update",
              help="Upgrade the sirb CLI, node-agent container, or gateway image.")
app.add_typer(opencode.app, name="opencode", help="Print OpenCode-compatible config.")
app.add_typer(observations.app, name="observations",
              help="(admin) Network observations from the monitoring + fraud agents.")
app.add_typer(admin.app, name="admin",
              help="(admin) Operator-only actions on the gateway (e.g. evict stale nodes).")


if __name__ == "__main__":
    app()
