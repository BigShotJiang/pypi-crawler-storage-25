"""Thin HTTP client over the Sirb backend.

Plain httpx — we deliberately do NOT depend on the openai SDK here. The
CLI also hits admin endpoints (keys, usage) that aren't OpenAI-compatible,
so dragging the SDK in for two chat endpoints would just add deps. Plus
plain httpx is easier to lift into a user's own integration.
"""

from __future__ import annotations

import json
from collections.abc import Iterator
from typing import Any

import httpx

from sirb_cli.config import CliConfig


class AdminScopeRequired(Exception):
    """Raised when the gateway returns 403 admin_scope_required.

    Distinct from a generic httpx.HTTPStatusError so commands can render
    a clean "this command needs an admin key" message instead of leaking
    an HTTP status traceback. The backend's auth layer (require_admin)
    returns this code via app/security/auth.py; we surface the same code
    so the contract is observable end-to-end."""

    def __init__(self, message: str = "this command requires an admin-scoped API key") -> None:
        super().__init__(message)


def _raise_for_status_friendly(r: httpx.Response) -> None:
    """Like httpx's raise_for_status, but maps 403 admin_scope_required
    to our typed exception so the CLI can render a friendly message."""
    if r.status_code == 403:
        try:
            body = r.json()
        except ValueError:
            body = {}
        err = (body.get("detail") or {}).get("error") or body.get("error") or {}
        if err.get("code") == "admin_scope_required":
            raise AdminScopeRequired(
                err.get("message", "this command requires an admin-scoped API key")
            )
    r.raise_for_status()


class SirbClient:
    def __init__(self, config: CliConfig, timeout: float = 60.0) -> None:
        self._cfg = config
        self._timeout = timeout

    def _headers(self) -> dict[str, str]:
        if not self._cfg.api_key:
            raise RuntimeError("no API key configured — run `sirb login`")
        return {"Authorization": f"Bearer {self._cfg.api_key}"}

    # ─────────── reads ───────────

    def get(self, path: str, params: dict | None = None) -> dict:
        r = httpx.get(
            f"{self._cfg.base_url}{path}",
            headers=self._headers(),
            params=params,
            timeout=self._timeout,
        )
        _raise_for_status_friendly(r)
        return r.json()

    def post(self, path: str, body: dict) -> dict:
        r = httpx.post(
            f"{self._cfg.base_url}{path}", headers=self._headers(), json=body, timeout=self._timeout
        )
        _raise_for_status_friendly(r)
        return r.json()

    def put(self, path: str, body: dict | None = None) -> dict:
        r = httpx.put(
            f"{self._cfg.base_url}{path}", headers=self._headers(), json=body, timeout=self._timeout
        )
        _raise_for_status_friendly(r)
        return r.json()

    def delete(self, path: str) -> None:
        r = httpx.delete(
            f"{self._cfg.base_url}{path}", headers=self._headers(), timeout=self._timeout
        )
        _raise_for_status_friendly(r)

    # ─────────── chat / streaming ───────────

    def chat(self, prompt: str, model: str | None = None) -> dict:
        return self.post(
            "/v1/chat/completions",
            {
                "model": model or self._cfg.default_model,
                "messages": [{"role": "user", "content": prompt}],
            },
        )

    def chat_stream(self, prompt: str, model: str | None = None) -> Iterator[str]:
        """Yields completion text fragments as they arrive."""
        with httpx.stream(
            "POST",
            f"{self._cfg.base_url}/v1/chat/completions",
            headers=self._headers(),
            json={
                "model": model or self._cfg.default_model,
                "messages": [{"role": "user", "content": prompt}],
                "stream": True,
            },
            timeout=self._timeout,
        ) as r:
            r.raise_for_status()
            for line in r.iter_lines():
                if not line or not line.startswith("data:"):
                    continue
                payload = line[len("data:") :].strip()
                if payload == "[DONE]":
                    return
                try:
                    obj: Any = json.loads(payload)
                except ValueError:
                    continue
                choices = obj.get("choices") or []
                if not choices:
                    continue
                delta = choices[0].get("delta", {}).get("content")
                if delta:
                    yield delta
