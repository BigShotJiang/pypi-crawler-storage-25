"""Auto-discovery + download for `--backend llama-cpp` model files.

The llama-cpp backend needs an on-disk GGUF file at deploy time. Before
0.6.0 the operator had to download it manually and pass
``--llama-model-path /abs/path/to/model.gguf``. This module makes that
optional: when the operator omits the path AND `--models <id>` looks
like a HuggingFace reference, we resolve it to a concrete file in
``~/.sirb/models/`` and download it (or reuse if cached).

Supported model-id shapes (same Ollama HF shortcut convention used
elsewhere in the CLI):

  hf.co/<owner>/<repo>:<quant>
        e.g. hf.co/bartowski/Qwen2.5-0.5B-Instruct-GGUF:Q4_K_M
        Resolves to: repo bartowski/Qwen2.5-0.5B-Instruct-GGUF,
                     file matching *Q4_K_M*.gguf
  <owner>/<repo>:<quant>          (no scheme; same as above)
  hf.co/<owner>/<repo>/<file>     explicit file path inside the repo
  <owner>/<repo>/<file>           explicit file path, no scheme

Anything else → return None (the deploy flow then expects an explicit
``--llama-model-path``).

Phase 10C tie-in: when a future revision adds expert-shard downloads
(only the experts a node is assigned), the entry point is a sibling
``fetch_expert_shards()`` function in this module — same caching
location, same auth handling. Keeping it in one module per the
separation-of-concerns rule.
"""

from __future__ import annotations

import os
import re
import shutil
from dataclasses import dataclass
from pathlib import Path

from rich import print as rprint


# Default cache root, override with $SIRB_MODELS_DIR for operators who
# want models on a different filesystem (large NVMe, attached storage).
def _models_root() -> Path:
    env = os.environ.get("SIRB_MODELS_DIR")
    if env:
        return Path(env).expanduser()
    return Path.home() / ".sirb" / "models"


@dataclass(frozen=True)
class HfModelRef:
    """A parsed HuggingFace model reference."""
    repo_id: str            # e.g. "bartowski/Qwen2.5-0.5B-Instruct-GGUF"
    quant: str | None       # e.g. "Q4_K_M" — None when an explicit file was given
    explicit_filename: str | None  # e.g. "Qwen2.5-0.5B-Instruct-Q4_K_M.gguf"


# Strict-ish regex: owner and repo must look HF-name-shaped, quant is
# alphanumeric + underscores (the conventional GGUF quant naming),
# explicit-filename path is whatever follows the repo / segment.
#
# Owner / repo deliberately reject ".." with a negative lookahead so
# the parser can never produce a `repo_id` starting with `..` (which
# would map to a `..__something` cache directory — harmless but ugly).
# The `file` group still permits `/` for sub-directory layouts; the
# `_is_safe_path_segment` check in parse_hf_ref + the resolved-path
# assertion in fetch_model cover the path-traversal cases.
_REF_WITH_QUANT = re.compile(
    r"^(?:hf\.co/)?(?!\.\.?$)(?P<owner>[A-Za-z0-9._-]+)/"
    r"(?!\.\.?$)(?P<repo>[A-Za-z0-9._-]+):(?P<quant>[A-Za-z0-9_]+)$"
)
_REF_WITH_FILE = re.compile(
    r"^(?:hf\.co/)?(?!\.\.?$)(?P<owner>[A-Za-z0-9._-]+)/"
    r"(?!\.\.?$)(?P<repo>[A-Za-z0-9._-]+)/"
    r"(?P<file>[A-Za-z0-9._\-/]+\.gguf)$"
)
# Bare owner/repo — a real HF reference but with no GGUF affordance.
# Used to give the operator a better error message: this is what
# vLLM consumes directly (operator runs `vllm serve <owner/repo>`),
# but llama-cpp can't use it without a re-quantized GGUF.
_REF_BARE_REPO = re.compile(
    r"^(?:hf\.co/)?(?!\.\.?$)(?P<owner>[A-Za-z0-9._-]+)/"
    r"(?!\.\.?$)(?P<repo>[A-Za-z0-9._-]+)$"
)


def _is_safe_path_segment(segment: str) -> bool:
    """Reject path-traversal markers and absolute paths in any segment
    that flows into a filesystem path. Belt-and-suspenders to the
    post-resolve check in ``fetch_model`` — defense in depth so a
    malformed input can't even reach the path construction step.
    """
    if not segment:
        return False
    if segment in (".", ".."):
        return False
    if segment.startswith("/") or segment.startswith("\\"):
        return False
    # Components separated by `/` — each must be safe in turn.
    for part in segment.replace("\\", "/").split("/"):
        if part in ("", ".", ".."):
            return False
    return True


def parse_hf_ref(model_id: str) -> HfModelRef | None:
    """Best-effort parse of a model id into a HF reference. Returns
    None when the id doesn't look like a HF reference at all (e.g.
    Ollama-only tags like ``gemma2:2b`` — short repo names without an
    owner) — those go through the existing manual path.

    Also returns None when the id parses BUT contains path-traversal
    markers (`..`, absolute paths) — silently treating those as
    "not a HF ref" forces the deploy flow to the manual --llama-model-path
    code path, which is the safe default.
    """
    m = _REF_WITH_FILE.match(model_id)
    if m:
        owner, repo, file = m.group("owner"), m.group("repo"), m.group("file")
        if not all(_is_safe_path_segment(s) for s in (owner, repo, file)):
            return None
        return HfModelRef(
            repo_id=f"{owner}/{repo}",
            quant=None,
            explicit_filename=file,
        )
    m = _REF_WITH_QUANT.match(model_id)
    if m:
        owner, repo = m.group("owner"), m.group("repo")
        if not all(_is_safe_path_segment(s) for s in (owner, repo)):
            return None
        return HfModelRef(
            repo_id=f"{owner}/{repo}",
            quant=m.group("quant"),
            explicit_filename=None,
        )
    return None


def _local_cache_path(ref: HfModelRef, filename: str) -> Path:
    """Where this file lives on disk after download. Mirrors the HF
    repo structure so cache hits across re-runs are obvious."""
    return _models_root() / ref.repo_id.replace("/", "__") / filename


def _pick_gguf_filename(repo_id: str, quant: str) -> str:
    """For a `repo:quant` reference, list the repo's files and pick
    the GGUF whose name contains the quant token. Falls back to a
    plain HEAD if multiple match (operator can disambiguate by passing
    an explicit filename).

    Raises RuntimeError if the API rejects the request or no file
    matches — these are surfaced to the operator without retry magic.
    """
    try:
        from huggingface_hub import list_repo_files
    except ImportError as e:
        raise RuntimeError(
            "huggingface_hub is required for auto-download. Install with "
            "`pip install 'sirb[hf]'` or pass --llama-model-path manually."
        ) from e
    try:
        files = list_repo_files(repo_id)
    except Exception as e:  # noqa: BLE001 — surface the underlying error
        raise RuntimeError(
            f"couldn't list files in {repo_id!r} on HuggingFace: {e}"
        ) from e
    # Word-bounded match on the quant token. Naively doing
    # `quant_lower in f.lower()` would match "Q4" against "Q4_K_M",
    # "Q4_0", "IQ4_XS" all equally — operators who pass `:Q4_K_M`
    # would silently get whichever sorted shortest (often "Q4_0").
    # Require the quant to appear as its own token, bounded by the
    # conventional separators `.`, `_`, `-` or start / end of the
    # basename (modulo the `.gguf` suffix).
    boundary = r"[._\-]"
    pattern = re.compile(
        rf"(?:^|{boundary}){re.escape(quant)}(?:{boundary}|\.gguf$)",
        re.IGNORECASE,
    )
    gguf_files = [f for f in files if f.endswith(".gguf")]
    matches = [f for f in gguf_files if pattern.search(f)]
    if not matches:
        raise RuntimeError(
            f"no .gguf file in {repo_id!r} matches quant {quant!r}. "
            f"Available files: {gguf_files[:10]}"
        )
    if len(matches) > 1:
        # Still ambiguous despite the word-boundary tightening (e.g.
        # imatrix variants of the same quant). Surface the
        # alternatives so the operator can pick — pass an explicit
        # `hf.co/owner/repo/<exact-file>.gguf` to disambiguate.
        matches.sort(key=lambda f: (len(f), f))
        rprint(
            f"[yellow][model-fetch][/yellow] {len(matches)} files match "
            f"quant {quant!r}; picking {matches[0]!r}. Alternatives: "
            f"{matches[1:5]}{'…' if len(matches) > 5 else ''}. "
            "Pass an explicit filename to disambiguate."
        )
    return matches[0]


def fetch_model(model_id: str) -> Path | None:
    """Resolve `model_id` to a local GGUF path, downloading via the
    HuggingFace hub when needed.

    Returns:
        Path to the local .gguf — caller mounts this into the container.
        None if `model_id` doesn't look like a HF reference at all
        (operator is expected to provide --llama-model-path manually).

    Raises:
        RuntimeError on network / parse / file-not-found errors. The
        deploy flow catches these and prints a clean operator-facing
        message; we don't swallow.
    """
    ref = parse_hf_ref(model_id)
    if ref is None:
        return None  # not a HF reference — fall back to manual path

    # Resolve the concrete filename to download.
    if ref.explicit_filename:
        filename = ref.explicit_filename
    else:
        assert ref.quant is not None  # parser invariant
        filename = _pick_gguf_filename(ref.repo_id, ref.quant)

    # Re-check the filename can't escape — HF can return arbitrary
    # paths in `list_repo_files()` (subdirs are valid repo layouts).
    # The parser already rejected explicit ".." in the caller-supplied
    # form, but a HF repo could publish files like `foo/../../bar.gguf`.
    if not _is_safe_path_segment(filename):
        raise RuntimeError(
            f"refusing to fetch {ref.repo_id!r}/{filename!r}: path "
            "contains traversal markers"
        )

    local_path = _local_cache_path(ref, filename)
    # Defense in depth: even though every segment passed _is_safe_path_segment,
    # confirm the resolved path is under the configured models root.
    # `resolve(strict=False)` collapses any residual `..` / symlink
    # surprises without requiring the file to exist yet.
    models_root_resolved = _models_root().resolve()
    if models_root_resolved not in local_path.resolve().parents:
        raise RuntimeError(
            f"refusing to fetch {ref.repo_id}/{filename}: resolved "
            f"cache path {local_path} escapes {_models_root()}"
        )
    # Reject a planted symlink BEFORE the cache-hit short-circuit.
    # is_file() follows symlinks, so without this check a malicious
    # symlink → /etc/passwd would be returned as "cached".
    if local_path.is_symlink():
        raise RuntimeError(
            f"refusing to use symlink at cache slot {local_path}: "
            "remove the symlink and retry."
        )
    if local_path.is_file():
        rprint(f"[green][model-fetch][/green] cached: {local_path}")
        return local_path

    # Download via huggingface_hub. Caches to its own dir, then we
    # link / copy into ~/.sirb/models/<repo>__<file>/ so the path is
    # stable + visible to operators independent of HF's cache layout.
    try:
        from huggingface_hub import hf_hub_download
    except ImportError as e:
        raise RuntimeError(
            "huggingface_hub is required for auto-download. Install with "
            "`pip install 'sirb[hf]'` or pass --llama-model-path manually."
        ) from e

    rprint(f"[blue][model-fetch][/blue] downloading {ref.repo_id}/{filename} → {local_path}")
    local_path.parent.mkdir(parents=True, exist_ok=True)
    # Refuse to write through a planted symlink at the cache slot —
    # a malicious local process can pre-create
    # ``~/.sirb/models/<repo>__<name>/<file>.gguf`` as a symlink to
    # e.g. ``~/.ssh/authorized_keys``, and ``shutil.copy2`` would
    # silently follow it.
    if local_path.is_symlink():
        raise RuntimeError(
            f"refusing to write through symlink at {local_path}: "
            "remove the existing entry and retry."
        )
    if local_path.parent.is_symlink():
        raise RuntimeError(
            f"refusing to use symlinked cache directory {local_path.parent}: "
            "remove the symlink and retry."
        )
    try:
        downloaded = hf_hub_download(
            repo_id=ref.repo_id,
            filename=filename,
            # Honor HF_TOKEN env when set — needed for gated models.
            token=os.environ.get("HF_TOKEN") or None,
        )
    except Exception as e:  # noqa: BLE001
        raise RuntimeError(
            f"download failed for {ref.repo_id}/{filename}: {e}"
        ) from e

    # Place the file under our cache root without doubling disk usage
    # for multi-GB GGUFs. Try a hardlink first (zero extra bytes when
    # both paths live on the same filesystem) and fall back to copy
    # only when the OS rejects (cross-filesystem, ACL mismatch, etc).
    # Atomic via tempfile + os.replace so a SIGINT mid-write doesn't
    # leave a half-written local_path that the next deploy would
    # silently mount as a corrupt model.
    tmp_path = local_path.with_suffix(local_path.suffix + ".part")
    try:
        tmp_path.unlink(missing_ok=True)
    except OSError:
        pass
    try:
        os.link(downloaded, tmp_path)
    except OSError:
        # Cross-filesystem (HF cache on a different mount) or any other
        # link-not-supported error → fall back to a real copy.
        shutil.copy2(downloaded, tmp_path)
    os.replace(tmp_path, local_path)
    rprint(f"[green][model-fetch][/green] saved: {local_path}")
    return local_path


def is_bare_hf_repo(model_id: str) -> bool:
    """True iff ``model_id`` parses as ``owner/repo`` (with optional
    ``hf.co/`` prefix) but has no GGUF-quant suffix and no explicit
    filename.

    Used by the llama-cpp preflight to distinguish "this looks like a
    HF reference but isn't pointing at a GGUF" from "this isn't a HF
    reference at all" — so we can give the operator a precise hint
    (re-quantized GGUF, or switch to vLLM) instead of a generic
    "isn't a HuggingFace reference" message.
    """
    if parse_hf_ref(model_id) is not None:
        return False  # already a usable GGUF reference
    return parse_bare_hf_repo(model_id) is not None


def parse_bare_hf_repo(model_id: str) -> str | None:
    """Return ``owner/repo`` when ``model_id`` is a bare HF reference,
    None otherwise. Mirrors ``is_bare_hf_repo`` but returns the
    canonical repo_id so callers can hit the HF API without re-parsing.
    """
    if parse_hf_ref(model_id) is not None:
        return None
    m = _REF_BARE_REPO.match(model_id)
    if m is None:
        return None
    owner, repo = m.group("owner"), m.group("repo")
    if not (_is_safe_path_segment(owner) and _is_safe_path_segment(repo)):
        return None
    return f"{owner}/{repo}"


# Preferred GGUF quant order — picked when a bare GGUF repo is given
# without an explicit `:quant` suffix. Q4_K_M is the community's
# accuracy/size sweet spot; we walk down to less-preferred options
# if Q4_K_M isn't published, and finally fall back to whichever
# .gguf is available.
_QUANT_PREFERENCE = [
    "Q4_K_M",  # best quality:size balance
    "Q5_K_M",  # higher quality, larger
    "Q4_K_S",  # smaller variant
    "Q4_0",    # legacy baseline
    "Q5_0",
    "Q8_0",    # near-lossless, biggest practical
    "Q6_K",
    "Q3_K_M",  # last-resort, lossier
]


def _quant_in_string(s: str) -> str | None:
    """Walk _QUANT_PREFERENCE and return the first quant that appears
    as a word-bounded token in ``s``. Shared helper between the
    filename-based and repo-name-based passes of autodiscover_quant
    so the precedence order is consistent across both code paths.
    """
    boundary = r"[._\-]"
    for quant in _QUANT_PREFERENCE:
        pattern = re.compile(
            rf"(?:^|{boundary}){re.escape(quant)}(?:{boundary}|\.gguf$|$)",
            re.IGNORECASE,
        )
        if pattern.search(s):
            return quant
    return None


def autodiscover_quant(repo_id: str) -> str | None:
    """For a bare HF repo, pick a sensible default quant.

    Two-pass strategy:

      1. **Filenames first.** Most modern HF GGUF repos publish many
         quants in one repo with the quant token in each filename
         (e.g. ``bartowski/Foo-GGUF/foo-Q4_K_M.gguf``). List files,
         walk ``_QUANT_PREFERENCE`` and return the first quant whose
         token appears in any filename.

      2. **Repo name fallback.** Some publishers put the quant in
         the REPO NAME itself with a single generic ``model.gguf``
         inside (e.g. ``unsloth/Llama-Q4_K_M-GGUF`` containing
         ``model.gguf``). If pass 1 finds nothing, parse the repo
         name for a quant token.

    Returns the chosen quant string (e.g. ``"Q4_K_M"``) or None when
    the repo isn't a GGUF repo at all OR neither pass finds a known
    quant token (operator gets a manual-pick error from the caller).
    Raises RuntimeError on transport / auth errors so the caller can
    surface a clean message rather than a stack trace.
    """
    try:
        from huggingface_hub import list_repo_files
    except ImportError as e:
        raise RuntimeError(
            "huggingface_hub is required for auto-discovery. Install with "
            "`pip install 'sirb[hf]'` or pass an explicit :quant suffix."
        ) from e
    try:
        files = list_repo_files(repo_id)
    except Exception as e:  # noqa: BLE001
        raise RuntimeError(
            f"couldn't list files in {repo_id!r} on HuggingFace: {e}"
        ) from e
    gguf_files = [f for f in files if f.endswith(".gguf")]
    if not gguf_files:
        return None  # not a GGUF repo — caller hints at vLLM / conversion

    # Pass 1: filename-based. Walk the preference list, pick the first
    # quant that has at least one matching file.
    for quant in _QUANT_PREFERENCE:
        if any(_quant_in_string(f) == quant for f in gguf_files):
            return quant

    # Pass 2: repo-name-based. Single-quant repos with a generic
    # ``model.gguf`` filename carry the quant in the repo name itself.
    # Only check the repo segment (not the owner) — owners aren't
    # supposed to carry quant info, and matching there would create
    # false positives.
    repo_segment = repo_id.split("/")[-1] if "/" in repo_id else repo_id
    quant_from_name = _quant_in_string(repo_segment)
    if quant_from_name is not None:
        return quant_from_name

    # Neither pass found a known quant token. Caller surfaces the
    # available filenames so the operator can disambiguate manually.
    return None


def fetch_expert_shards(model_id: str, expert_ids: list[int]) -> Path | None:
    """Phase 10C placeholder — download only the expert subset this
    node is assigned. Currently raises NotImplementedError; full
    impl arrives in Phase 10C M3 (custom expert-shard runner). The
    function signature is committed now so consumers can target it
    without further refactor when M3 lands.
    """
    raise NotImplementedError(
        "Expert-shard download arrives in Phase 10C M3 — see "
        "docs/sharding-phase-10c.md. For now, llama-cpp serves the "
        "whole model on one node (Reading A in the 10C plan)."
    )
