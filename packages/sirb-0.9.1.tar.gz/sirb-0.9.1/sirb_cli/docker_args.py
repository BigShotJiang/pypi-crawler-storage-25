"""Docker-flag allowlist for `sirb deploy node`.

Lives in its own module because it's a security boundary: anything that
flows through here ends up on the literal `docker run` argv. We want a
future addition of an operator-facing knob (env var, config file, etc.)
to have to go through this filter, and a code review of any future
change to the allowlist to be unambiguous.

Background: `sirb_cli.gpu.detect_gpu()` emits vendor-specific GPU
passthrough flags (`--device /dev/kfd`, `--group-add render`,
`--security-opt seccomp=unconfined` for ROCm). The source today is
in-process and trustworthy, but the data path COULD be influenced via
``SIRB_NODE_GPU_VENDOR`` or future deploy-time knobs, so we narrow the
acceptable shape at the last layer before docker.

Allowlist rationale (each entry has a real reason to be here):

  --device              Required by AMD ROCm (``/dev/kfd``, ``/dev/dri``)
                        and Intel SYCL (``/dev/dri``). Without these the
                        container can't see the GPU. NVIDIA goes through
                        ``--gpus all`` (handled separately in
                        ``_build_resource_flags``); it is intentionally
                        NOT on this allowlist so the two paths can't
                        cross-contaminate.
  --group-add           Required so the unprivileged container user (uid
                        10001) can read ``/dev/dri`` and ``/dev/kfd``,
                        which are owned by ``render`` / ``video`` gids
                        that vary per distro.
  --security-opt        Required ONLY by ROCm to allow the amdkfd
                        ioctls that the default seccomp profile rejects.
                        Emitted only when ``/dev/kfd`` actually exists
                        on the host (see ``sirb_cli.gpu._probe_amd``),
                        so a forced ``--gpu-vendor=amd`` on a non-AMD
                        host cannot trigger seccomp relaxation.
"""

from __future__ import annotations

# Allowlist for the vendor-specific GPU passthrough flags coming out of
# ``sirb_cli.gpu.detect_gpu()``. Each entry is a flag NAME; we accept
# the flag plus exactly one argument-value following it.
_ALLOWED_EXTRA_DOCKER_FLAGS = frozenset({
    "--device",
    "--group-add",
    "--security-opt",
})


def filter_safe_docker_args(
    args: list[str],
    *,
    warn: "_Warn | None" = None,
) -> list[str]:
    """Keep only `--flag value` pairs whose flag is on the allowlist.

    Pairs are matched positionally — if an allowed flag is followed by
    another `--` token (i.e. the caller misformatted the list), the
    orphan flag is dropped. The expected shape is always exactly
    ``[..., '--device', '/dev/kfd', '--group-add', '109', ...]`` so
    positional pairing is unambiguous.

    Anything not on the allowlist is dropped AND surfaced via the
    ``warn`` callback. Previously the drop was silent under the
    "covered by tests" rationale, but a future addition of a new
    vendor probe (Apple Metal, Tenstorrent, Huawei Ascend, etc.) that
    legitimately needed a new flag like ``--cap-add SYS_NICE`` or
    ``--ipc host`` would silently lose that flag on every operator
    deploy. The visible failure mode would then be "GPU support
    quietly degraded" rather than "deploy aborted with a clear
    message". A loud warn at the first deploy that hits a regression
    is the correct trade-off.

    Returns a new list; never mutates the input. Safe to call with
    None? No — caller passes ``[]`` for the empty case.
    """
    out: list[str] = []
    i = 0
    while i < len(args):
        tok = args[i]
        if (
            tok in _ALLOWED_EXTRA_DOCKER_FLAGS
            and i + 1 < len(args)
            and not args[i + 1].startswith("--")
        ):
            out.append(tok)
            out.append(args[i + 1])
            i += 2
        else:
            # Drop, with a visible warning so a code-side regression in
            # the source emitter (sirb_cli.gpu) surfaces on the first
            # deploy that hits it. Without this, a missing GPU flag
            # silently degrades performance, and operators file vague
            # "GPU not working" issues that are hard to triage.
            if warn is not None:
                warn(
                    f"dropping non-allowlisted docker flag from GPU "
                    f"probe: {tok!r} (this is a Sirb-side regression; "
                    f"please file an issue with this token)"
                )
            i += 1
    return out


# Type alias for the optional warn callback (str -> None). Kept local
# to avoid pulling in a logging dependency at the boundary module.
class _Warn:  # pragma: no cover - typing helper
    def __call__(self, msg: str) -> None: ...
