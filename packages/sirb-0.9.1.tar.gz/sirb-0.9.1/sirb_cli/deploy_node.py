"""Native-Python port of `install.sh`.

The legacy `install.sh` works fine on Linux + macOS but breaks on
Windows in two ways: MSYS argv-translation mangles paths passed to
Git Bash, and the WSL `bash.EXE` wrapper loses bytes piped through
stdin from Python under PowerShell. Rather than chase the
Python↔bash↔OS handoff bugs forever, this module re-implements the
same workflow in pure Python — so the only hard dependency is Python
itself, plus the standard tools (`docker`, `cloudflared`) which we'd
need regardless.

What this does, in order:

  1. Echo the disclosure banner (matches the one in install.sh).
  2. Persist the API key the operator supplied to ~/.sirb/api_key.
  3. Fetch the wallet bound to that key via `GET /v1/me`, fall back
     to ~/.sirb/wallet.json or a random off-chain identifier.
  4. Generate or reuse a per-node callback secret in
     ~/.sirb/callback_secret.
  5. Start `cloudflared tunnel --url http://localhost:9000` in the
     background, parse the trycloudflare URL out of its stderr.
  6. `docker pull` the node image, kill any existing container with
     the same name, `docker run -d` with the full env block.
  7. Poll `/nodes` until the gateway sees our first heartbeat.
  8. Print the API-key banner the same way install.sh does.

Cross-platform notes:

  - Subprocesses are launched with `subprocess.Popen` directly. On
    Windows we set CREATE_NEW_PROCESS_GROUP so cloudflared survives
    Ctrl-C and keeps running after the CLI exits.
  - Path handling uses pathlib throughout — no shell quoting or
    backslash translation.
  - Tunnel URL extraction reads cloudflared's output line by line
    via a thread; works regardless of whether cloudflared writes to
    stdout or stderr on a given platform.
"""

from __future__ import annotations

import os
import re
import secrets
import shutil
import socket
import subprocess
import sys
import threading
import time
from pathlib import Path

import httpx
import typer
from rich import print as rprint
from rich.console import Console


console = Console()


# ────────────────────────── disclosure banner ──────────────────────────────


def _print_disclosure() -> None:
    bar = "━" * 64
    rprint()
    rprint(f"[yellow]{bar}[/yellow]")
    rprint(f"[bold yellow]  ⚠  EXPERIMENTAL / BETA SOFTWARE[/bold yellow]")
    rprint(f"[yellow]{bar}[/yellow]")
    rprint("Sirb is in active development. Interfaces, on-chain contracts,")
    rprint("image tags, and reward mechanics may change without notice.")
    rprint("[bold]Provided AS-IS, no warranty[/bold] — maintainers are NOT responsible")
    rprint("for any damages, data loss, hardware wear, financial loss, or")
    rprint("regulatory consequences arising from running this software.")
    rprint()
    rprint("Full notice: [blue]https://sirb.run/docs/disclaimer/[/blue]")
    rprint(f"[yellow]{bar}[/yellow]")
    rprint()


# ────────────────────────── small helpers ──────────────────────────────────


def _step(msg: str) -> None:
    rprint(f"\n[blue]━━━[/blue] {msg} [blue]━━━[/blue]")


def _info(msg: str) -> None:
    rprint(f"[green][sirb][/green] {msg}")


def _warn(msg: str) -> None:
    rprint(f"[yellow][sirb][/yellow] {msg}")


def _fatal(msg: str) -> typer.Exit:
    rprint(f"[red][sirb][/red] {msg}")
    return typer.Exit(code=1)


def _sirb_home() -> Path:
    p = Path(os.environ.get("SIRB_HOME") or (Path.home() / ".sirb"))
    p.mkdir(parents=True, exist_ok=True)
    return p


def _save_secret(path: Path, value: str) -> None:
    """Write text + chmod 0600 where supported. On Windows the chmod
    call is a no-op but doesn't error."""
    path.write_text(value, encoding="utf-8")
    try:
        os.chmod(path, 0o600)
    except (OSError, NotImplementedError):
        pass


# ────────────────────────── /v1/me wallet lookup ───────────────────────────


def _resolve_wallet(
    backend_url: str, api_key: str, explicit: str | None,
) -> str:
    """Pick the wallet the agent will register under.

    The gateway enforces wallet/API-key binding: `/nodes/register` is
    rejected with `wallet_mismatch` when the claim doesn't match the
    wallet bound to the API key. So this function must NEVER mint a
    wallet that the gateway hasn't seen — silently falling back to a
    random identifier would guarantee a permanent `wallet_mismatch`
    while the operator sees only a vague "no heartbeat" timeout.

    Order:
      1. `--wallet` if it matches the key's bound wallet (or no bound).
      2. The wallet returned by `GET /v1/me`.
      3. The wallet in ~/.sirb/wallet.json ONLY if `/v1/me` was
         unreachable for transport reasons (so we can support offline
         re-runs against a gateway that's flapping).
      4. Otherwise fail with an actionable error.
    """
    bound: str | None = None
    reached_gateway = False
    try:
        r = httpx.get(
            f"{backend_url.rstrip('/')}/v1/me",
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=10.0,
        )
        reached_gateway = True
        if r.status_code == 401 or r.status_code == 403:
            raise _fatal(
                f"/v1/me returned {r.status_code} — your API key isn't valid for "
                f"{backend_url}. Run `sirb login --api-key sirb_…` and retry."
            )
        if r.status_code == 200:
            try:
                payload = r.json()
            except ValueError as e:
                raise _fatal(f"/v1/me returned non-JSON ({e}); is {backend_url} a Sirb gateway?")
            if not isinstance(payload, dict):
                raise _fatal(f"/v1/me returned {type(payload).__name__}, expected object")
            bound = payload.get("wallet_address")
            if bound is not None and not isinstance(bound, str):
                raise _fatal(f"/v1/me wallet_address is {type(bound).__name__}, expected string")
    except httpx.HTTPError:
        # Transport-level failure (DNS, connection refused, timeout).
        # Fall through to the local-wallet path so flapping gateways
        # don't block a re-deploy.
        pass

    if explicit:
        if not re.fullmatch(r"0x[a-fA-F0-9]{40}", explicit):
            raise _fatal("wallet must be 0x + 40 hex chars")
        if bound and explicit.lower() != bound.lower():
            raise _fatal(
                f"--wallet {explicit} doesn't match the wallet bound to your API "
                f"key ({bound}). Mint a new key under {explicit} on the gateway, "
                f"or drop --wallet to use {bound}."
            )
        _info(f"using provided wallet: {explicit}")
        return explicit

    wallet_file = _sirb_home() / "wallet.json"
    if bound:
        _info(f"using wallet bound to API key: {bound}")
        wallet_file.write_text(
            f'{{"address":"{bound}","source":"v1/me","created_at":"{_now_iso()}"}}\n',
            encoding="utf-8",
        )
        try:
            os.chmod(wallet_file, 0o600)
        except (OSError, NotImplementedError):
            pass
        return bound

    if reached_gateway:
        # /v1/me succeeded but returned no bound wallet — the key was
        # minted without one. We can't guess what the operator wants.
        raise _fatal(
            "your API key has no bound wallet. Re-mint a key with --wallet "
            "set on the gateway, or pass --wallet 0x… to this command. "
            "(Random off-chain wallets would be rejected by the gateway's "
            "wallet/API-key binding.)"
        )

    # Gateway unreachable. Re-use the previously-bound wallet from
    # disk so re-runs work against a flapping gateway.
    if wallet_file.exists():
        m = re.search(
            r'"address"\s*:\s*"(0x[a-fA-F0-9]{40})"',
            wallet_file.read_text(encoding="utf-8"),
        )
        if m:
            _warn(
                f"couldn't reach /v1/me; reusing wallet from {wallet_file}: "
                f"{m.group(1)} — registration will fail if the gateway hasn't seen this wallet"
            )
            return m.group(1)

    raise _fatal(
        f"couldn't reach {backend_url}/v1/me and no local wallet is cached. "
        f"Check the gateway URL / network and retry. (Random wallets would be "
        f"rejected at registration — refusing to silently generate one.)"
    )


def _now_iso() -> str:
    from datetime import datetime, timezone
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


# ────────────────────────── cloudflared tunnel ─────────────────────────────


_TUNNEL_RE = re.compile(rb"https://[a-z0-9-]+\.trycloudflare\.com")


def _start_tunnel(local_port: int) -> tuple[subprocess.Popen, str]:
    """Spawn `cloudflared tunnel --url http://localhost:N` and return
    (process, https_url) once the URL appears in the log. The Popen
    object stays alive for the lifetime of the CLI; cleanup is the
    operator's job (the existing `docker rm`/`pkill` workflow).
    """
    if not shutil.which("cloudflared"):
        raise _fatal(
            "cloudflared not on PATH. Install: "
            "https://developers.cloudflare.com/cloudflare-one/connections/connect-networks/downloads/"
        )

    log_path = _sirb_home() / "logs" / "cloudflared.log"
    log_path.parent.mkdir(parents=True, exist_ok=True)
    # Open the log, hand the FD to Popen, then close the Python-side
    # handle. Keeping it open on Windows leads to sharing-violation
    # errors if anything else (or a follow-up run) tries to read the
    # file; on POSIX it's harmless but wasteful.
    log_file = open(log_path, "wb")

    # Detach the process group on Windows so cloudflared keeps running
    # after the Python CLI exits. On POSIX, the process inherits our
    # session — operator manages with `pkill -f cloudflared`.
    popen_kwargs: dict = dict(
        stdout=log_file, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL,
    )
    if sys.platform == "win32":
        popen_kwargs["creationflags"] = (
            subprocess.CREATE_NEW_PROCESS_GROUP   # type: ignore[attr-defined]
            | getattr(subprocess, "DETACHED_PROCESS", 0)
        )
    else:
        popen_kwargs["start_new_session"] = True

    try:
        proc = subprocess.Popen(
            ["cloudflared", "tunnel", "--url", f"http://localhost:{local_port}"],
            **popen_kwargs,
        )
    finally:
        # Popen has dup'd the FD into the child; close our copy so
        # we don't hold an exclusive Windows handle for the rest of
        # the CLI's lifetime.
        log_file.close()

    # Poll the log file for the tunnel URL. cloudflared typically
    # writes it within 5s; bail at 30s with the tail of the log.
    _info("waiting for tunnel URL…")
    deadline = time.time() + 30
    url: str | None = None
    while time.time() < deadline:
        time.sleep(1)
        try:
            content = log_path.read_bytes()
        except OSError:
            continue
        m = _TUNNEL_RE.search(content)
        if m:
            url = m.group(0).decode("utf-8")
            break

    if not url:
        # Cloudflared may have crashed (bad binary, missing libs, port
        # conflict that we couldn't detect). Surface its exit code and
        # the log tail so the operator can see why.
        exit_code = proc.poll()
        try:
            raw = log_path.read_bytes()
        except OSError:
            raw = b""
        tail = raw[-2000:].decode("utf-8", errors="replace")
        if exit_code is not None:
            rprint(
                f"\n[red]cloudflared exited with code {exit_code} before "
                f"the tunnel URL appeared.[/red]"
            )
        if tail.strip():
            rprint(f"[red]Tail of {log_path}:[/red]\n{tail}")
        else:
            rprint(
                f"[red]Log at {log_path} is empty — cloudflared may have "
                f"failed to launch at all. Try `cloudflared tunnel --url "
                f"http://localhost:{local_port}` manually.[/red]"
            )
        try:
            proc.terminate()
        except OSError:
            pass
        raise _fatal("tunnel did not start within 30s — see diagnostics above")

    _info(f"tunnel URL: {url}")
    (_sirb_home() / "tunnel.url").write_text(url + "\n", encoding="utf-8")
    (_sirb_home() / "tunnel.pid").write_text(str(proc.pid) + "\n", encoding="utf-8")
    return proc, url


# ────────────────────────── docker run ─────────────────────────────────────


# ────────────────────────── host resources ─────────────────────────────────


def _detect_nvidia_gpus() -> list[tuple[str, float]]:
    """Return [(gpu_name, vram_gb), ...] using `nvidia-smi`.

    Returns [] when nvidia-smi isn't on PATH (the most common case —
    no GPU host). When the binary IS present but probing fails (driver
    crashed, hung, permission denied, locale-mangled output), we _warn
    the operator with the specific reason so they know why their node
    is starting CPU-only on a known-good GPU host.

    Doesn't auto-detect AMD ROCm or Apple Metal: ROCm needs
    `--device=/dev/kfd --device=/dev/dri` which has different UX, and
    Apple Silicon Metal isn't exposed to Linux containers at all on
    Docker Desktop. Operators wanting those paths use the example
    docker-compose template and add the right `devices:` block.
    """
    if not shutil.which("nvidia-smi"):
        return []
    # Binary exists → from here on, every failure path warns so a
    # legitimate GPU host doesn't silently fall through to CPU-only.
    try:
        p = subprocess.run(
            ["nvidia-smi", "--query-gpu=name,memory.total",
             "--format=csv,noheader,nounits"],
            capture_output=True, text=True, timeout=5.0,
        )
    except subprocess.TimeoutExpired:
        _warn(
            "nvidia-smi hung past 5s — driver may be wedged. "
            "Container will start CPU-only; reboot or reinstall the "
            "NVIDIA driver if you expected GPU support."
        )
        return []
    except OSError as e:
        _warn(f"nvidia-smi found on PATH but failed to exec: {e}. "
              "Container will start CPU-only.")
        return []
    if p.returncode != 0:
        stderr_tail = (p.stderr or "").strip()[-400:]
        _warn(
            f"nvidia-smi exited {p.returncode}; container will start "
            f"CPU-only. Common cause: kernel updated without matching "
            f"driver reload (`Driver/library version mismatch`). "
            f"stderr: {stderr_tail!r}"
        )
        return []

    gpus: list[tuple[str, float]] = []
    skipped = 0
    for line in p.stdout.splitlines():
        line = line.strip()
        if not line:
            continue
        # rsplit so a GPU name containing a comma (some OEM rebadges
        # and certain Tesla SKUs) doesn't drop the row entirely.
        # memory.total is always the rightmost field.
        parts = [s.strip() for s in line.rsplit(",", 1)]
        if len(parts) != 2:
            skipped += 1
            continue
        try:
            # --format=...,nounits emits integer MiB. Always C locale
            # (nvidia-smi doesn't honor LC_NUMERIC), but guard anyway.
            mib = float(parts[1])
        except ValueError:
            skipped += 1
            continue
        gpus.append((parts[0], mib / 1024.0))
    if skipped:
        _warn(
            f"nvidia-smi returned {skipped} GPU row(s) we couldn't "
            f"parse; the registration claim will under-count by that "
            f"many GPUs. Report at https://github.com/ammarwa/SIRB/issues."
        )
    return gpus


def _detect_host_cpu_cores() -> int:
    """Cross-platform CPU count, 0 when unknown. Stdlib only."""
    n = os.cpu_count()
    return int(n) if n else 0


# Security-boundary docker-flag allowlist lives in its own module so
# any future change to what reaches `docker run` is a single-file PR
# obvious to reviewers. See ``cli/sirb_cli/docker_args.py``.
from sirb_cli.docker_args import filter_safe_docker_args as _filter_safe_docker_args  # noqa: E402


def _build_resource_flags(
    *,
    cpu_cores: int | None,
    ram_gb: int | None,
    gpu_count: int | None,
    gpu_percent: int | None,
    vram_gb: float | None,
    detected_gpus: list[tuple[str, float]],
) -> tuple[list[str], dict[str, str]]:
    """Translate operator caps into docker flags + matching env-var
    declarations for the registration claim.

    Default (operator passes nothing) is "use everything":
      - no --cpus  → all host CPUs available to the container
      - no --memory → no RAM cap
      - --gpus all  → every NVIDIA GPU exposed, when available

    Returns (docker_flag_list, env_dict). env_dict feeds SIRB_NODE_*
    so the heartbeat claim matches the docker reality. Operator
    overrides (vram_gb, gpu_percent) always win — resolved here so
    we never double-emit the same env var.
    """
    flags: list[str] = []
    claim: dict[str, str] = {}

    # CPU: cap when operator specified a number, otherwise leave docker
    # default (unlimited). Always declare the claim using the operator
    # value when set, else the detected total (better than 0 in the
    # registry).
    if cpu_cores is not None:
        flags += ["--cpus", str(cpu_cores)]
        claim["SIRB_NODE_CPU_CORES"] = str(cpu_cores)
    else:
        detected = _detect_host_cpu_cores()
        if detected:
            claim["SIRB_NODE_CPU_CORES"] = str(detected)

    # RAM: cap when specified. --memory and --memory-swap together
    # prevent the container from swapping past the cap into host swap.
    if ram_gb is not None:
        flags += ["--memory", f"{ram_gb}g", "--memory-swap", f"{ram_gb}g"]
        claim["SIRB_NODE_RAM_GB"] = str(ram_gb)

    # GPU: three states.
    #   gpu_count == 0       → operator opted CPU-only; no --gpus.
    #   gpu_count > 0        → expose exactly N (validates docker has
    #                          NVIDIA runtime — error is clear).
    #   gpu_count is None    → "use what's available". If nvidia-smi
    #                          finds GPUs, pass --gpus all. Otherwise
    #                          quietly no --gpus (CPU-only run).
    detected_vram_total = sum(v for _, v in detected_gpus)
    detected_vram_per_gpu = (
        detected_vram_total / len(detected_gpus) if detected_gpus else 0.0
    )
    if gpu_count is None:
        if detected_gpus:
            flags += ["--gpus", "all"]
            claim["SIRB_NODE_GPU_COUNT"] = str(len(detected_gpus))
            # Total VRAM = sum across GPUs (a node-level resource).
            claim["SIRB_NODE_VRAM_GB"] = f"{detected_vram_total:.1f}"
        # No GPUs detected → no --gpus, claim stays 0 (default).
    elif gpu_count == 0:
        # Explicit CPU-only, even on a GPU host.
        claim["SIRB_NODE_GPU_COUNT"] = "0"
    elif gpu_count > 0:
        flags += ["--gpus", f"count={gpu_count}"]
        claim["SIRB_NODE_GPU_COUNT"] = str(gpu_count)
        # Partial-allocation VRAM: assume even split across detected
        # GPUs. Operator can still override via --vram-gb. Without
        # this fallback the claim would advertise N GPUs with 0 VRAM,
        # which routes badly.
        if detected_gpus:
            claim["SIRB_NODE_VRAM_GB"] = (
                f"{detected_vram_per_gpu * gpu_count:.1f}"
            )

    # Operator overrides last — these are explicit declarations and
    # must win over any auto-detected value, with no double-emit.
    if vram_gb is not None:
        claim["SIRB_NODE_VRAM_GB"] = str(vram_gb)
    if gpu_percent is not None:
        claim["SIRB_NODE_GPU_PERCENT"] = str(gpu_percent)

    return flags, claim


# ────────────────────────── docker run ─────────────────────────────────────


def _docker_run_node(
    *,
    image: str,
    name: str,
    backend_url: str,
    api_key: str,
    signing_secret: str,
    wallet: str,
    tunnel_url: str,
    models: str | None,
    allow_sharding: bool,
    local_port: int,
    model_backend: str,
    ollama_url: str,
    vllm_url: str,
    llama_model_path: str | None,
    cpu_cores: int | None,
    ram_gb: int | None,
    gpu_count: int | None,
    gpu_percent: int | None,
    vram_gb: float | None,
    extra_docker_args: list[str] | None = None,
) -> None:
    # Best-effort kill of an existing container with the same name.
    subprocess.run(
        ["docker", "rm", "-f", name],
        capture_output=True, text=True,
    )

    env_flags: list[str] = []
    def add_env(k: str, v: str | int) -> None:
        env_flags.extend(["-e", f"{k}={v}"])

    pub_tail = wallet[-8:] if len(wallet) >= 8 else "dev"
    add_env("SIRB_NODE_HOST", "0.0.0.0")
    add_env("SIRB_NODE_PORT", "9000")
    add_env("SIRB_NODE_BACKEND_URL", backend_url)
    add_env("SIRB_NODE_API_KEY", api_key)
    add_env("SIRB_NODE_SIGNING_SECRET", signing_secret)
    add_env("SIRB_NODE_WALLET_ADDRESS", wallet)
    add_env("SIRB_NODE_PUBLIC_KEY", f"0xnodepub_{pub_tail}")
    add_env("SIRB_NODE_PUBLIC_ENDPOINT", tunnel_url)
    add_env("SIRB_NODE_MODEL_BACKEND", model_backend)
    add_env("SIRB_NODE_ALLOW_SHARDING", "true" if allow_sharding else "false")
    if models:
        # Models pass through as a JSON-shaped string so the agent's
        # pydantic Settings can parse them. Use json.dumps so embedded
        # quotes / backslashes in unusual model ids are escaped properly.
        import json
        items = [m.strip() for m in models.split(",") if m.strip()]
        add_env("SIRB_NODE_SUPPORTED_MODELS", json.dumps(items))

    # Backend-specific env. The CLI's preflight already validated the
    # combinations are coherent (e.g. llama-cpp requires the path).
    extra_mounts: list[str] = []
    if model_backend == "ollama":
        add_env("SIRB_NODE_OLLAMA_BASE_URL", ollama_url)
    elif model_backend == "vllm":
        add_env("SIRB_NODE_VLLM_BASE_URL", vllm_url)
    elif model_backend == "llama-cpp" and llama_model_path:
        # Mount the GGUF read-only into the Linux container under a stable
        # POSIX path. Mirroring the host path on the target side breaks on
        # Windows because Docker's `-v src:dst:mode` parser can't
        # disambiguate the colon in a `C:\...` target ("too many colons").
        # The container is Linux, so a Windows-style target wouldn't be a
        # valid path inside the container anyway.
        host_src = Path(llama_model_path).resolve()
        container_path = f"/models/{host_src.name}"
        extra_mounts += ["-v", f"{host_src}:{container_path}:ro"]
        add_env("SIRB_NODE_LLAMA_MODEL_PATH", container_path)
        # Signed-manifest verification (security plan §7): the node-agent
        # defaults to refusing any GGUF without a trusted ``.manifest.json``
        # next to it. Publisher-signed manifests exist for the official
        # Sirb model catalog, but nearly every community GGUF on
        # HuggingFace (bartowski, unsloth, lmstudio-community, …) ships
        # WITHOUT one. A default ``sirb deploy node --backend llama-cpp
        # --models hf.co/...`` lands the user in a crash-loop with a
        # confusing ``FileNotFoundError: manifest not found`` from the
        # LlamaCppRunner constructor.
        #
        # Detect the missing manifest at deploy time and either mount it
        # (when present) or auto-set
        # ``SIRB_NODE_LLAMA_VERIFY_MANIFEST=false`` (when absent) with
        # a clear console warning. The operator sees the trade-off
        # upfront ("you're trusting this GGUF as-is — no signature
        # verification") and the node actually boots; they can
        # re-enable verification by obtaining a manifest and
        # re-deploying.
        manifest_host_path = host_src.with_suffix(
            host_src.suffix + ".manifest.json"
        )
        if manifest_host_path.is_file():
            manifest_container_path = f"/models/{manifest_host_path.name}"
            extra_mounts += [
                "-v",
                f"{manifest_host_path}:{manifest_container_path}:ro",
            ]
            add_env(
                "SIRB_NODE_LLAMA_MANIFEST_PATH", manifest_container_path,
            )
            rprint(
                f"[green]Found manifest:[/green] [dim]{manifest_host_path.name}[/dim]"
                " — signature will be verified at node startup."
            )
        else:
            add_env("SIRB_NODE_LLAMA_VERIFY_MANIFEST", "false")
            rprint(
                f"[yellow]No manifest found at[/yellow] [dim]{manifest_host_path}[/dim]."
            )
            rprint(
                "[yellow]Disabling signed-manifest verification for this deploy "
                "([bold]SIRB_NODE_LLAMA_VERIFY_MANIFEST=false[/bold]).[/yellow]"
            )
            rprint(
                "[dim]The GGUF will be trusted as-is, with no signature check. "
                "This is the expected path for community-pulled HuggingFace GGUFs. "
                "If this is a production node, obtain a signed manifest from the "
                "model publisher and place it at the path above before re-deploying.[/dim]"
            )

    # Mount ~/.sirb/data/ into the container at /data so `sirb models
    # add / remove` can persist the operator's model edits. The node
    # agent reads /data/supported_models.json at boot via
    # `model_runner._apply_models_override()`, so changes survive a
    # container restart even though docker run env is fixed at deploy
    # time. Bind read-only — only the CLI writes to this file.
    host_data_dir = _sirb_home() / "data"
    host_data_dir.mkdir(parents=True, exist_ok=True)
    extra_mounts += ["-v", f"{host_data_dir}:/data:ro"]
    # Seed the file with the deploy-time model list so the CLI's
    # later `sirb models add` knows the starting point without
    # having to scrape the container env. Atomic write via tempfile
    # rename keeps a partially-written file from breaking boot.
    if models:
        import json as _json
        items = [m.strip() for m in models.split(",") if m.strip()]
        seed_path = host_data_dir / "supported_models.json"
        tmp = seed_path.with_suffix(".tmp")
        tmp.write_text(_json.dumps(items, indent=2) + "\n", encoding="utf-8")
        tmp.replace(seed_path)

    # Host resources → docker flags + matching env-var claims. Default
    # is "use everything available": no --cpus / --memory caps, --gpus
    # all when NVIDIA GPUs are detected. Each operator-set flag both
    # caps the container AND becomes the registration claim so the
    # scheduler routes accordingly. All claim values (including
    # operator overrides for --vram-gb / --gpu-percent) are resolved
    # inside _build_resource_flags so we never double-emit an env var.
    detected_gpus = _detect_nvidia_gpus()
    resource_flags, resource_env = _build_resource_flags(
        cpu_cores=cpu_cores,
        ram_gb=ram_gb,
        gpu_count=gpu_count,
        gpu_percent=gpu_percent,
        vram_gb=vram_gb,
        detected_gpus=detected_gpus,
    )
    for k, v in resource_env.items():
        add_env(k, v)

    if "--gpus" in resource_flags:
        gpu_label = "all" if gpu_count is None else f"count={gpu_count}"
        _info(f"exposing GPUs to container: {gpu_label} (detected {len(detected_gpus)})")
    elif detected_gpus and gpu_count == 0:
        _info("NVIDIA GPUs detected but --gpu-count 0 → running CPU-only")
    elif not detected_gpus:
        # No-op: NVIDIA GPUs absent. We don't print here because most
        # operators are on CPU-only hosts and the noise isn't useful.
        pass

    _info(f"docker pull {image}")
    pull = subprocess.run(["docker", "pull", "--quiet", image], capture_output=True, text=True)
    if pull.returncode != 0:
        # Print the tail of stderr (last 2000 chars) — docker's relevant
        # error line is almost always at the end, after warnings/banners.
        rprint(f"[red]docker pull failed (exit {pull.returncode}):[/red]\n{pull.stderr.strip()[-2000:]}")
        raise typer.Exit(code=pull.returncode)

    # Vendor-specific GPU passthrough flags from the CLI's GPU probe
    # (AMD: --device /dev/kfd /dev/dri --group-add render+video;
    # Intel: --device /dev/dri --group-add render). NVIDIA's --gpus
    # all is in resource_flags from _build_resource_flags, so this
    # list is empty on NVIDIA / CPU hosts. Validate to keep things
    # honest: only known-safe flags allowed through, per the same
    # workflow-injection hygiene applied elsewhere — operators can't
    # smuggle anything weird via SIRB_NODE_GPU_VENDOR.
    # The warn callback surfaces dropped flags loudly: a future
    # addition of a vendor probe that needs a new flag would otherwise
    # silently degrade GPU support, leaving operators to triage vague
    # "GPU not working" issues at runtime.
    safe_extra = _filter_safe_docker_args(
        list(extra_docker_args or []),
        warn=_warn,
    )

    _info(f"docker run --name {name} {image}")
    run = subprocess.run(
        [
            "docker", "run", "-d",
            "--name", name,
            "--restart", "unless-stopped",
            "-p", f"{local_port}:9000",
            *resource_flags,
            *safe_extra,
            *extra_mounts,
            *env_flags,
            image,
        ],
        capture_output=True, text=True,
    )
    if run.returncode != 0:
        rprint(f"[red]docker run failed (exit {run.returncode}):[/red]\n{run.stderr.strip()[-2000:]}")
        raise typer.Exit(code=run.returncode)
    _info(f"container started: {name}")

    # Record the local URL `sirb models add` will hit for runtime
    # mutation. The port is dynamic (see _pick_local_port) and the
    # container name is the operator's --name, so the CLI needs a
    # stable place to read this from.
    (_sirb_home() / "local_url").write_text(
        f"http://127.0.0.1:{local_port}\n", encoding="utf-8",
    )
    (_sirb_home() / "container_name").write_text(name + "\n", encoding="utf-8")


# ────────────────────────── heartbeat verification ─────────────────────────


def _wait_for_heartbeat(backend_url: str, wallet: str, timeout_s: float = 30.0) -> bool:
    """Poll GET /nodes until we see a row with this wallet. Returns
    True on success, False on timeout. Bails early if /nodes returns
    a shape we don't recognize so we don't burn the full 30s while
    silently producing a misleading 'no heartbeat' warning."""
    _info("waiting for first heartbeat (up to 30s)…")
    deadline = time.time() + timeout_s
    shape_warned = False
    while time.time() < deadline:
        try:
            r = httpx.get(f"{backend_url.rstrip('/')}/nodes", timeout=5.0)
            if r.status_code == 200:
                try:
                    nodes = r.json()
                except ValueError:
                    if not shape_warned:
                        _warn("/nodes returned non-JSON; can't verify heartbeat")
                        shape_warned = True
                    return False
                if not isinstance(nodes, list):
                    if not shape_warned:
                        _warn(f"/nodes returned {type(nodes).__name__}, expected list; "
                              f"can't verify heartbeat (gateway version mismatch?)")
                        shape_warned = True
                    return False
                for n in nodes:
                    if not isinstance(n, dict):
                        continue
                    if (n.get("wallet_address") or "").lower() == wallet.lower():
                        return True
        except httpx.HTTPError:
            pass
        time.sleep(2)
    return False


# ────────────────────────── port discovery ─────────────────────────────────


def _pick_local_port(start: int = 9000) -> int:
    """Find an open port — usually 9000 is free, but on shared dev
    machines we don't want to assume. Raises typer.Exit when nothing
    in [start, start+10) is bindable; silently returning `start` would
    just defer the failure to `docker run -p` with a worse error."""
    for port in range(start, start + 10):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind(("127.0.0.1", port))
                return port
            except OSError:
                continue
    raise _fatal(
        f"no free local port in [{start}, {start+10}); stop the conflicting "
        f"service or free a port in that range and retry."
    )


# ────────────────────────── entrypoint ─────────────────────────────────────


def run(
    *,
    backend_url: str,
    api_key: str,
    image: str,
    name: str,
    wallet: str | None,
    signing_secret: str | None,
    models: str | None,
    allow_sharding: bool,
    model_backend: str,
    ollama_url: str,
    vllm_url: str = "http://host.docker.internal:8000",
    llama_model_path: str | None = None,
    cpu_cores: int | None = None,
    ram_gb: int | None = None,
    gpu_count: int | None = None,
    gpu_percent: int | None = None,
    vram_gb: float | None = None,
    extra_docker_args: list[str] | None = None,
) -> None:
    """Top-level deploy. Caller (sirb deploy node) has already validated
    that docker is on PATH, the API key is present, and that
    `model_backend` is one of {"ollama", "llama-cpp", "vllm"} with
    any backend-specific prerequisites satisfied.

    ``extra_docker_args`` carries vendor-specific GPU passthrough flags
    decided by sirb_cli.gpu.detect_gpu() (e.g. ``--device /dev/kfd``
    for AMD, ``--device /dev/dri --group-add render`` for Intel). The
    NVIDIA path stays on ``--gpus all`` and is handled by
    _build_resource_flags so we don't double-add it.

    Resource caps default to None which means "let the container use
    everything available" — no docker --cpus / --memory limit, and
    --gpus all when an NVIDIA GPU is detected. Pass explicit values to
    cap (and to ensure the registration claim matches the cap)."""
    _print_disclosure()

    home = _sirb_home()
    # We intentionally don't persist the API key here. The rest of the
    # CLI reads keys from `~/.sirb/config.json` via `ProfileStore`; a
    # plain `~/.sirb/api_key` file is read by nothing, and writing both
    # would create two sources of truth that drift. `sirb login` is the
    # right place to persist a key.

    # Wallet — fetched from /v1/me preferred path, falls back to local.
    _step("Wallet")
    resolved_wallet = _resolve_wallet(backend_url, api_key, wallet)

    # Per-node callback secret. Reuses ~/.sirb/callback_secret across
    # runs so the gateway's stored value stays valid.
    _step("Callback secret")
    cb_file = home / "callback_secret"
    if signing_secret:
        if len(signing_secret) < 16:
            raise _fatal("--signing-secret must be ≥16 chars")
        _save_secret(cb_file, signing_secret)
        _info(f"using provided signing secret")
    elif cb_file.exists():
        signing_secret = cb_file.read_text(encoding="utf-8").strip()
        _info(f"reusing per-node callback secret from {cb_file}")
    else:
        signing_secret = secrets.token_hex(32)
        _save_secret(cb_file, signing_secret)
        _info(f"generated per-node callback secret (gateway will store it at registration)")

    # Tunnel
    _step("Starting Cloudflare Tunnel")
    local_port = _pick_local_port(9000)
    _tunnel_proc, tunnel_url = _start_tunnel(local_port)

    # Docker
    _step("Starting node-agent container")
    _docker_run_node(
        image=image,
        name=name,
        backend_url=backend_url,
        api_key=api_key,
        signing_secret=signing_secret,
        wallet=resolved_wallet,
        tunnel_url=tunnel_url,
        models=models,
        allow_sharding=allow_sharding,
        local_port=local_port,
        model_backend=model_backend,
        ollama_url=ollama_url,
        vllm_url=vllm_url,
        llama_model_path=llama_model_path,
        cpu_cores=cpu_cores,
        ram_gb=ram_gb,
        gpu_count=gpu_count,
        gpu_percent=gpu_percent,
        vram_gb=vram_gb,
        extra_docker_args=extra_docker_args or [],
    )

    # Verify
    _step("Verifying registration")
    ok = _wait_for_heartbeat(backend_url, resolved_wallet)
    if ok:
        _info("registered — gateway sees this node")
    else:
        # Common case: gateway rejected the register call (wallet
        # mismatch, signature, schema). Pull the container's tail so
        # the actual HTTP status is visible; the agent logs the
        # gateway's response body alongside the status code.
        _warn("no heartbeat in 30s — checking container logs for the actual cause…")
        logs = subprocess.run(
            ["docker", "logs", "--tail", "40", name],
            capture_output=True, text=True,
        )
        body = (logs.stdout or "") + (logs.stderr or "")
        if body.strip():
            rprint(f"[dim]docker logs {name} (last 40 lines):[/dim]\n{body[-2000:]}")
        else:
            _warn(f"`docker logs {name}` returned nothing yet — container may still be starting")
        _warn(f"keep watching with: docker logs -f {name}")

    # Final banner
    bar = "━" * 67
    rprint(f"\n[green]{bar}[/green]")
    rprint(f"[bold green]    Done.[/bold green]")
    rprint(f"[green]{bar}[/green]")
    rprint(f"  Container:  [cyan]{name}[/cyan]")
    rprint(f"  Image:      [cyan]{image}[/cyan]")
    rprint(f"  Tunnel:     [cyan]{tunnel_url}[/cyan]")
    rprint(f"  Wallet:     [cyan]{resolved_wallet}[/cyan]")
    rprint(f"  Tail logs:  [dim]docker logs -f {name}[/dim]")
    rprint()
