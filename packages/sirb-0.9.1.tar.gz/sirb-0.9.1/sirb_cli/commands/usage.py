from __future__ import annotations

import typer
from rich import print as rprint
from rich.console import Console
from rich.table import Table

from sirb_cli.client import SirbClient
from sirb_cli.config import env_override_or_config


def run(
    from_date: str | None = typer.Option(None, "--from", help="Start date (YYYY-MM-DD)."),
    to_date: str | None = typer.Option(None, "--to", help="End date (YYYY-MM-DD)."),
) -> None:
    params = {}
    if from_date:
        params["from"] = from_date
    if to_date:
        params["to"] = to_date
    body = SirbClient(env_override_or_config()).get("/v1/usage", params=params or None)
    # Phase 8D: backends running 8D+ return total_cost/per-row cost in
    # SIRB; older backends omit them. Default to 0.0 / "—" so the CLI
    # works against either era.
    total_cost = body.get("total_cost", 0.0)
    currency = body.get("currency", "SIRB")
    rprint(f"[bold]{body['wallet']}[/bold]   {body['from_date']} → {body['to_date']}")
    rprint(f"  total: [green]{body['total_requests']}[/green] requests "
           f"({body['successful_requests']} ok, {body['failed_requests']} failed)")
    rprint(f"  tokens: {body['total_prompt_tokens']} in + "
           f"{body['total_completion_tokens']} out = "
           f"[green]{body['total_tokens']}[/green]")
    rprint(f"  cost:   [green]{_fmt_cost(total_cost)}[/green] {currency}")

    if body.get("by_day"):
        t = Table(title="By day")
        for col in ("date", "requests", "in", "out", f"cost ({currency})"):
            t.add_column(col)
        for d in body["by_day"]:
            t.add_row(d["date"], str(d["requests"]), str(d["prompt_tokens"]),
                      str(d["completion_tokens"]),
                      _fmt_cost(d.get("cost", 0.0)))
        Console().print(t)

    if body.get("by_model"):
        t = Table(title="By model")
        for col in ("model", "requests", "in", "out", f"cost ({currency})"):
            t.add_column(col)
        for d in body["by_model"]:
            t.add_row(d["model"], str(d["requests"]), str(d["prompt_tokens"]),
                      str(d["completion_tokens"]),
                      _fmt_cost(d.get("cost", 0.0)))
        Console().print(t)


def _fmt_cost(c: float) -> str:
    """SIRB prices live in the 1e-4 range at MVP rates. Six decimals is
    enough resolution to distinguish a 100-token call from a 10-token
    one (~1e-7 difference) without looking like a scientific paper."""
    if c == 0.0:
        return "0"
    return f"{c:.6f}"
