"""`sirb opencode config` and `sirb opencode env`.

Prints config snippets for OpenCode-style tools. Reads the saved CLI
config so users don't have to retype anything.
"""

from __future__ import annotations

import json
import typer
from rich import print as rprint

from sirb_cli.config import env_override_or_config

app = typer.Typer(no_args_is_help=True)


@app.command("config")
def show_config() -> None:
    """Print an OpenAI-compatible JSON config for OpenCode."""
    cfg = env_override_or_config()
    if not cfg.api_key:
        rprint("[red]No API key configured.[/red] Run `sirb login` first.")
        raise typer.Exit(1)
    out = {
        "provider": "openai-compatible",
        "baseURL": cfg.base_url.rstrip("/") + "/v1",
        "apiKey": cfg.api_key,
        "model": cfg.default_model,
    }
    print(json.dumps(out, indent=2))


@app.command("env")
def show_env() -> None:
    """Print export commands that point an OpenAI-SDK-based tool at Sirb."""
    cfg = env_override_or_config()
    if not cfg.api_key:
        rprint("[red]No API key configured.[/red] Run `sirb login` first.")
        raise typer.Exit(1)
    base = cfg.base_url.rstrip("/") + "/v1"
    print(f'export OPENAI_API_KEY="{cfg.api_key}"')
    print(f'export OPENAI_BASE_URL="{base}"')
    print(f'export OPENAI_MODEL="{cfg.default_model}"')
    print(f'export SIRB_API_KEY="{cfg.api_key}"')
    print(f'export SIRB_BASE_URL="{base}"')
    print(f'export SIRB_MODEL="{cfg.default_model}"')
