"""``sirb wallet`` — generate / inspect Ethereum wallets and claim addresses.

`sirb wallet new` generates a **real Ethereum keypair** by default and
**auto-binds the address as your `claim_address`** when you're logged
in — so on-chain SIRB rewards mint to a wallet you control without a
second command.

The private key is generated client-side and persisted to
``~/.sirb/wallet.json`` with **atomic mode-0600 creation** (no race
window where another local user could read the key). The CLI never
sends the private key over the wire — only the public address goes
to the gateway.

Security-sensitive helpers (keypair generation, atomic write, gateway
PUT) live in :mod:`sirb_cli.eth_wallet`. This file is the Typer
surface only.
"""

from __future__ import annotations

import json
import os
from pathlib import Path

import typer
from rich import print as rprint

from sirb_cli.client import SirbClient
from sirb_cli.config import env_override_or_config
from sirb_cli.eth_wallet import (
    ETH_ADDRESS_RE,
    BindOutcome,
    EthAccountMissing,
    generate_real_keypair,
    legacy_payload,
    try_bind_claim_address,
    wallet_path,
    write_wallet_file_atomic,
)

_ETH_ADDRESS_RE = ETH_ADDRESS_RE  # backwards-compat for in-repo callers

app = typer.Typer(
    invoke_without_command=False,
    no_args_is_help=True,
    help="Generate or inspect Ethereum wallets + bind claim addresses.",
)


def _build_eth_payload() -> dict:
    """Wrap :func:`generate_real_keypair` so the ImportError translates
    into a clean CLI exit instead of a stack trace."""
    from datetime import UTC, datetime

    try:
        kp = generate_real_keypair()
    except EthAccountMissing:
        rprint(
            "[red]eth-account is not installed.[/red] "
            "It ships in the base install — try [bold]pip install --upgrade sirb[/bold]."
        )
        raise typer.Exit(code=1) from None
    return {
        **kp,
        "kind": "eth",
        "created_at": datetime.now(UTC).isoformat().replace("+00:00", "Z"),
        "note": (
            "Real Ethereum keypair. Private key NEVER leaves this machine. "
            "Back it up — losing it means losing on-chain SIRB rewards."
        ),
    }


def _render_save_banner(path: Path, mode_actually_enforced: int) -> None:
    """Print the file-saved banner honestly.

    Pre-fix code printed ``(mode 0600)`` regardless of what the OS
    actually enforced — a lie on Windows and on filesystems that
    silently drop the mode bits. We now report what landed.
    """
    if mode_actually_enforced == 0o600:
        rprint(f"[dim]saved to {path} (mode 0600)[/dim]")
    elif os.name == "nt":
        rprint(
            f"[dim]saved to {path} (POSIX 0600 not enforceable on Windows — "
            "the file relies on your user-home ACL)[/dim]"
        )
    else:
        rprint(
            f"[yellow]WARN: saved to {path} with mode {oct(mode_actually_enforced)}, "
            "expected 0o600. Filesystem may not support POSIX permissions. "
            "Your private key is on disk with weaker permissions than intended — "
            "move the file to a secure location and delete it from this path.[/yellow]"
        )


def _peek_existing_address(path: Path) -> tuple[str | None, bool]:
    """Read the existing wallet file (if any) to surface what would be
    overwritten. Returns ``(address, has_private_key)``. Never reads
    the private key into memory beyond a boolean check — the CLI
    should never echo a stored private key, even on overwrite."""
    if not path.exists():
        return (None, False)
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return (None, False)
    if not isinstance(data, dict):
        return (None, False)
    return (data.get("address"), bool(data.get("private_key")))


@app.command("new")
def new(
    save: bool = typer.Option(
        True,
        "--save/--no-save",
        help="Persist to ~/.sirb/wallet.json (default). --no-save prints to stdout only.",
    ),
    force: bool = typer.Option(
        False,
        "--force",
        "-f",
        help="Overwrite an existing ~/.sirb/wallet.json. The CLI backs up the "
             "existing file to ~/.sirb/wallet.json.bak.<timestamp> before "
             "overwriting, so a finger-slip doesn't destroy a real keypair.",
    ),
    legacy: bool = typer.Option(
        False,
        "--legacy",
        help="Generate a random off-chain identifier (no private key, no claim binding). "
             "Pre-0.8 behaviour; only useful for throwaway nodes that won't claim rewards.",
    ),
    bind: bool = typer.Option(
        True,
        "--bind/--no-bind",
        help="When logged in (sirb login already run), automatically bind the new "
             "wallet's address as your claim_address on the gateway. Default on; "
             "ignored with --legacy.",
    ),
) -> None:
    """Generate an Ethereum wallet and auto-bind it for on-chain rewards.

    The default behaviour generates a real secp256k1 keypair, saves
    the private key to ``~/.sirb/wallet.json`` with atomic mode-0600
    creation (no race window where the file is briefly world-readable),
    and binds the address as your ``claim_address`` if you're logged
    in — so on-chain SIRB rewards mint directly to a wallet you
    control, without any second step.

    The private key never leaves this machine. Back it up immediately:
    losing it means losing access to whatever rewards land there.

    For the old off-chain-identifier behaviour (random 40-hex, no
    private key, no claim binding), pass ``--legacy``.
    """
    path = wallet_path()

    # Force-overwrite safety: if we'd destroy an existing real keypair,
    # back it up first so the operation is recoverable. The pre-fix
    # code clobbered silently — irreversible private-key loss on a
    # muscle-memory --force re-run.
    if save and path.exists():
        existing_addr, existing_has_pk = _peek_existing_address(path)
        if not force:
            rprint(f"[yellow]wallet file already exists at {path}[/yellow]")
            if existing_addr:
                rprint(f"[dim]current address: {existing_addr}"
                       + (" (real keypair)" if existing_has_pk else " (legacy)")
                       + "[/dim]")
            rprint(
                "Pass [bold]--force[/bold] to overwrite (the current file is "
                "automatically backed up to .bak.<timestamp>), or use "
                "[bold]--no-save[/bold] to print without writing."
            )
            raise typer.Exit(code=1)
        if existing_has_pk:
            from datetime import UTC, datetime

            ts = datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ")
            backup = path.with_suffix(path.suffix + f".bak.{ts}")
            rprint(
                f"[yellow]--force:[/yellow] backing up existing keypair "
                f"({existing_addr}) → [bold]{backup.name}[/bold]"
            )
            path.replace(backup)
        else:
            # Legacy file with no private key — safe to drop without backup,
            # but unlink first so O_EXCL in the atomic write doesn't trip.
            path.unlink(missing_ok=True)

    if legacy:
        payload = legacy_payload()
    else:
        payload = _build_eth_payload()

    if save:
        try:
            mode_landed = write_wallet_file_atomic(payload, path)
        except OSError as e:
            rprint(f"[red]could not save wallet file to {path}:[/red] {e}")
            raise typer.Exit(code=1) from e
        rprint(f"[green]wallet:[/green] [bold]{payload['address']}[/bold]")
        _render_save_banner(path, mode_landed)
    else:
        rprint(f"[green]wallet:[/green] [bold]{payload['address']}[/bold]")
        if payload.get("private_key"):
            rprint(f"[red bold]private key:[/red bold] [bold]{payload['private_key']}[/bold]")
            rprint(
                "[red]Save this immediately. It will not be shown again. "
                "Note: this output is on stdout — capture it now, and consider "
                "running [bold]sirb wallet new[/bold] (without --no-save) for "
                "the safer disk-persisted flow.[/red]"
            )
        rprint("[dim]not saved (--no-save)[/dim]")

    if legacy:
        rprint(
            "\n[yellow]--legacy:[/yellow] [dim]random off-chain identifier with no "
            "private key. Cannot receive on-chain SIRB. For real rewards, "
            "run `sirb wallet new` without --legacy.[/dim]"
        )
        return

    # Real-keypair path — try the auto-bind so the user doesn't have
    # to run a second command.
    if bind:
        outcome = try_bind_claim_address(payload["address"])
        _render_bind_outcome(outcome, payload["address"])

    if payload.get("private_key") and save:
        rprint(
            "\n[red bold]BACK UP YOUR PRIVATE KEY.[/red bold] "
            f"It's in [bold]{path}[/bold] (mode 0600 where supported). "
            "If you lose this file you lose access to whatever SIRB rewards "
            "land on this address — no recovery is possible."
        )


def _render_bind_outcome(outcome: BindOutcome, address: str) -> None:
    """Render the typed auto-bind result.

    The pre-fix code collapsed every failure into a single generic
    "no API key, or unreachable" hint — useless for debugging. We
    now branch on the structured reason so users see the actual
    gateway response code (``dev_key_unsupported``,
    ``invalid_claim_address``, etc.) and can act on it.
    """
    if outcome.bound:
        mint_lines = {
            "minted": "[green]✓ trial allowance minted[/green] — check [bold]sirb balance[/bold] in a minute.",
            "already_granted": "[dim]trial allowance was already granted on a prior bind (sticky per security plan).[/dim]",
            "unsupported": "[dim]trial allowance not available — gateway is in off-chain mode.[/dim]",
            "failed": "[red]trial-allowance mint reverted on chain.[/red] [dim]Contact gateway ops; the address is still bound.[/dim]",
        }
        rprint("[green]✓ bound as claim_address[/green] on the active API key.")
        if outcome.mint and outcome.mint in mint_lines:
            rprint("  " + mint_lines[outcome.mint])
        return

    # Not bound — surface the actual reason. Each branch tells the
    # user the specific next step instead of the generic catchall.
    if outcome.fail_reason == "no_api_key":
        rprint("\n[yellow]Could not auto-bind claim_address[/yellow] — not logged in.")
        rprint(
            f"  Run [bold]sirb login[/bold] then [bold]sirb wallet claim-address "
            f"--set {address}[/bold] to bind manually."
        )
    elif outcome.fail_reason and outcome.fail_reason.startswith("http_"):
        status = outcome.fail_reason.removeprefix("http_")
        code = outcome.fail_code or "?"
        msg = outcome.fail_detail or "(no message)"
        rprint(
            f"\n[yellow]Could not auto-bind claim_address[/yellow] — "
            f"gateway returned {status} ([bold]{code}[/bold]): {msg}"
        )
        if code == "dev_key_unsupported":
            rprint(
                "  [dim]Dev keys can't bind claim addresses. Mint a real key "
                "via [bold]sirb keys create[/bold] and run [bold]sirb wallet new[/bold] again.[/dim]"
            )
        else:
            rprint(
                f"  [dim]The wallet file is saved locally. Retry with "
                f"[bold]sirb wallet claim-address --set {address}[/bold] once "
                f"the underlying issue is resolved.[/dim]"
            )
    elif outcome.fail_reason == "network":
        rprint(
            f"\n[yellow]Could not auto-bind claim_address[/yellow] — "
            f"network error: {outcome.fail_detail or 'unknown'}"
        )
        rprint(
            f"  [dim]Check your network / gateway URL, then retry with "
            f"[bold]sirb wallet claim-address --set {address}[/bold].[/dim]"
        )
    elif outcome.fail_reason == "contract":
        rprint(
            f"\n[yellow]Could not auto-bind claim_address[/yellow] — "
            f"gateway returned an unexpected response shape: {outcome.fail_detail}"
        )
        rprint("  [dim]Likely a gateway-version mismatch. File a bug.[/dim]")
    else:
        rprint(
            "\n[yellow]Could not auto-bind claim_address[/yellow] — "
            f"unknown failure ({outcome.fail_reason})."
        )


@app.command("show")
def show() -> None:
    """Print the wallet currently saved at ~/.sirb/wallet.json."""
    path = wallet_path()
    if not path.exists():
        rprint(f"[yellow]no wallet at {path}[/yellow] — run `sirb wallet new` to create one")
        raise typer.Exit(code=1)
    try:
        data = json.loads(path.read_text())
    except (OSError, json.JSONDecodeError) as e:
        rprint(f"[red]could not read wallet file:[/red] {e}")
        raise typer.Exit(code=1) from None
    rprint(f"[green]address:[/green]  [bold]{data.get('address', '?')}[/bold]")
    kind = data.get("kind")
    if kind == "eth" or data.get("private_key"):
        rprint("[dim]kind:     real Ethereum keypair (private key on disk)[/dim]")
    elif kind == "legacy" or data.get("private_key") is None:
        rprint("[yellow]kind:     legacy off-chain identifier (no private key)[/yellow]")
        rprint("[dim]          cannot receive on-chain SIRB — run `sirb wallet new` to upgrade[/dim]")
    if data.get("created_at"):
        rprint(f"[dim]created:  {data['created_at']}[/dim]")


@app.command("claim-address")
def claim_address(
    set_to: str | None = typer.Option(
        None,
        "--set",
        "-s",
        help="Set the claim address (0x + 40 hex). Pass an empty string to clear.",
    ),
    clear: bool = typer.Option(
        False,
        "--clear",
        help="Clear any currently-set claim address.",
    ),
) -> None:
    """Show or set the on-chain Ethereum address that receives SIRB rewards.

    Without flags: prints the current claim address (or "not set").
    With ``--set 0x…``: binds the address to your API key. The pseudonymous
    ``wallet_address`` (used for identity and accounting) is unchanged —
    only the address rewards mint to changes.

    Format: ``0x`` followed by exactly 40 hexadecimal characters.

    Most users don't need to run this directly anymore: ``sirb wallet
    new`` auto-binds the generated address by default.
    """
    if set_to is not None and clear:
        rprint("[red]--set and --clear are mutually exclusive[/red]")
        raise typer.Exit(code=1)

    client = SirbClient(env_override_or_config())

    if set_to is not None or clear:
        if clear:
            payload_addr: str | None = None
        else:
            assert set_to is not None  # type-narrow for the linter
            s = set_to.strip()
            payload_addr = None if not s else s
            if payload_addr and not _ETH_ADDRESS_RE.match(payload_addr):
                rprint("[red]invalid address format[/red] — must be 0x + 40 hex chars")
                raise typer.Exit(code=1)
        body = client.put("/v1/wallet/claim-address", body={"claim_address": payload_addr})
    else:
        body = client.get("/v1/wallet/claim-address")

    current = body.get("claim_address")
    wallet = body.get("wallet_address", "?")
    if current:
        rprint(f"[green]claim address:[/green] [bold]{current}[/bold]")
    else:
        rprint("[yellow]claim address:[/yellow] [dim]not set[/dim]")
        rprint(
            "[dim]Run [bold]sirb wallet new[/bold] to generate a wallet + auto-bind, or "
            "[bold]sirb wallet claim-address --set 0x…[/bold] to bind an existing address.[/dim]"
        )
    rprint(f"[dim]wallet (identity): {wallet}[/dim]")
