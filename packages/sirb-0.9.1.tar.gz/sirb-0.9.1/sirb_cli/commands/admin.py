"""``sirb admin`` — operator commands that require an admin-scoped API key.

Every subcommand under this group is gated at the group's Typer callback:
we ping `GET /admin/whoami` before delegating to the subcommand. If the
active key isn't admin (or isn't valid at all), the user gets a clean
"this is the wrong key" message immediately — no walking through a
destructive confirmation prompt only to discover the request was going
to 403 anyway.

Why not under ``sirb deploy`` or ``sirb observations``: those groups are
about *what you're operating on* (your machine / the network's agents);
``sirb admin`` is about *who you have to be* (an admin key holder).
"""

from __future__ import annotations

import datetime as _dt

import httpx
import typer
from rich import box
from rich import print as rprint
from rich.console import Console
from rich.table import Table

from sirb_cli.client import AdminScopeRequired, SirbClient
from sirb_cli.config import env_override_or_config


app = typer.Typer(
    name="admin",
    no_args_is_help=True,
    help="(admin) Operator-only actions on the gateway.",
)

nodes_app = typer.Typer(
    name="nodes",
    no_args_is_help=True,
    help="Manage entries in the node registry.",
)
app.add_typer(nodes_app, name="nodes")

console = Console()


def _client() -> SirbClient:
    return SirbClient(env_override_or_config())


# ─── admin preflight (runs for every `sirb admin …` subcommand) ──────────


def _require_admin_or_exit() -> dict:
    """Verify the active API key has admin scope by calling `GET /admin/whoami`.

    Returns the whoami response on success. Calls `typer.Exit(1)` with a
    clean message on:
      - no API key configured at all (`sirb login` not run);
      - key configured but rejected by the gateway (401);
      - key valid but not admin (403);
      - gateway unreachable / other error.
    """
    cfg = env_override_or_config()
    if not cfg.api_key:
        rprint("[red]No API key configured.[/red] "
               "Run [cyan]sirb login --api-key sirb_<admin-key>[/cyan] first.")
        raise typer.Exit(code=1)

    try:
        return _client().get("/admin/whoami")
    except AdminScopeRequired as e:
        rprint("[red]Admin scope required.[/red] "
               "The active key isn't admin-scoped — `sirb admin` commands need a "
               "key minted via `python -m app.scripts.admin_key create --admin …` on "
               "the gateway, or promoted via the same CLI.")
        rprint(f"[dim]gateway: {e}[/dim]")
        rprint(f"[dim]active key ends in …{cfg.api_key[-6:] if cfg.api_key and len(cfg.api_key) > 6 else '***'}[/dim]")
        raise typer.Exit(code=1)
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 401:
            rprint("[red]API key rejected (401).[/red] Run `sirb keys` to see what's active, "
                   "or `sirb login --api-key sirb_…` to swap.")
            raise typer.Exit(code=1)
        rprint(f"[red]Gateway error during admin preflight ({e.response.status_code}):[/red] "
               f"{e.response.text[:200]}")
        raise typer.Exit(code=1)
    except httpx.HTTPError as e:
        rprint(f"[red]Could not reach gateway:[/red] {type(e).__name__}: {e}")
        raise typer.Exit(code=1)


# Typer invokes the group's @callback BEFORE any subcommand. Running the
# preflight here means every `sirb admin …` is admin-gated by construction,
# and individual subcommands don't have to repeat the check.
def _is_help_invocation() -> bool:
    """True if the caller is asking for help anywhere in the argv stack —
    `sirb admin --help`, `sirb admin nodes --help`, etc. We don't want
    to make a network round-trip just to render a help string."""
    import sys
    return any(arg in ("-h", "--help") for arg in sys.argv[1:])


@app.callback()
def _preflight(ctx: typer.Context) -> None:
    # Skip the preflight for:
    #  - the bare `sirb admin` invocation (Typer renders help itself);
    #  - any `--help` request anywhere in the command tree;
    #  - shell-completion resilient-parsing passes.
    if (
        ctx.resilient_parsing
        or ctx.invoked_subcommand is None
        or _is_help_invocation()
    ):
        return
    ctx.obj = _require_admin_or_exit()


@nodes_app.callback()
def _nodes_group(ctx: typer.Context) -> None:
    # Nothing — the parent `admin` group's preflight has already run.
    # This callback exists so we can hang `nodes_app` off the typer
    # tree without printing a spurious header.
    return


# ─── sirb admin nodes ls ─────────────────────────────────────────────────


@nodes_app.command("ls", help="List every node in the registry (fresh + stale).")
def ls(
    stale: bool = typer.Option(
        False, "--stale", help="Show ONLY stale rows (heartbeat past the freshness window).",
    ),
    online: bool = typer.Option(
        False, "--online", help="Show ONLY fresh-and-online rows.",
    ),
) -> None:
    """Prints one row per node with id, wallet, endpoint, supported models,
    status, last-heartbeat. Filters via --stale / --online when you want a
    narrower view — useful for spotting zombies (`--stale`) before running
    `sirb admin nodes rm`.

    Calls the public `GET /nodes` endpoint; the admin scope was already
    enforced at the group's preflight, so this just renders the result.
    """
    if stale and online:
        rprint("[red]--stale and --online are mutually exclusive.[/red]")
        raise typer.Exit(code=1)

    try:
        nodes = _client().get("/nodes")
    except httpx.HTTPError as e:
        rprint(f"[red]Could not fetch nodes:[/red] {type(e).__name__}: {e}")
        raise typer.Exit(code=1)

    # /nodes returns a bare list — keep us robust against either shape
    # (in case a future envelope wrapper lands).
    rows = nodes if isinstance(nodes, list) else nodes.get("data", [])

    if stale:
        rows = [n for n in rows if n.get("status") == "stale"]
    elif online:
        rows = [n for n in rows if n.get("status") == "online"]

    if not rows:
        if stale:
            rprint("[dim]No stale nodes — registry is clean.[/dim]")
        elif online:
            rprint("[dim]No online nodes right now.[/dim]")
        else:
            rprint("[dim]Registry is empty.[/dim]")
        return

    # Phase 10C M7: show the "experts" column ONLY when at least one
    # node in the result actually declares distributed-expert
    # assignments. Hiding the column when empty keeps the typical
    # operator's view uncluttered.
    any_expert_assignments = any(n.get("expert_assignments") for n in rows)

    t = Table(
        title=f"nodes ({len(rows)} shown)",
        title_justify="left", title_style="bold",
        box=box.SIMPLE_HEAD, header_style="bold",
    )
    t.add_column("id",       no_wrap=True, style="dim")
    t.add_column("wallet",   no_wrap=True)
    t.add_column("endpoint", overflow="fold")
    t.add_column("models",   overflow="fold")
    if any_expert_assignments:
        t.add_column("experts", overflow="fold")
    t.add_column("status",   no_wrap=True)
    t.add_column("heartbeat", no_wrap=True, style="dim")

    for n in rows:
        wallet = n.get("wallet_address", "?")
        wallet_short = f"{wallet[:8]}…{wallet[-4:]}" if len(wallet) > 14 else wallet
        models = n.get("supported_models") or []
        models_str = ", ".join(models[:3]) + (f"  (+{len(models)-3} more)" if len(models) > 3 else "")
        status = n.get("status", "?")
        status_styled = {
            "online":   f"[green]{status}[/green]",
            "stale":    f"[yellow]{status}[/yellow]",
            "draining": f"[yellow]{status}[/yellow]",
            "offline":  f"[red]{status}[/red]",
        }.get(status, status)
        row_cells = [
            n.get("node_id", "?"),
            wallet_short,
            n.get("endpoint", "?"),
            models_str or "[dim](none)[/dim]",
        ]
        if any_expert_assignments:
            row_cells.append(_fmt_expert_assignments(n.get("expert_assignments")))
        row_cells.append(status_styled)
        row_cells.append(_fmt_relative(n.get("last_heartbeat_at")))
        t.add_row(*row_cells)
    console.print(t)


def _fmt_expert_assignments(assignments: dict | None) -> str:
    """Compact display for Node.expert_assignments. Shows the first
    few experts per model and a +N-more marker when truncated, so
    the column stays narrow even for DeepSeek-style 256-expert
    deployments.

    Phase 10C M7. Returns a dim placeholder when the node has no
    assignments (Reading-A full-replica nodes, legacy rows)."""
    if not assignments:
        return "[dim]—[/dim]"
    parts: list[str] = []
    for model_id, expert_ids in sorted(assignments.items()):
        if not expert_ids:
            continue
        ids = sorted(expert_ids)
        if len(ids) <= 5:
            ids_str = ",".join(str(i) for i in ids)
        else:
            head = ",".join(str(i) for i in ids[:3])
            ids_str = f"{head}…+{len(ids) - 3}"
        parts.append(f"{model_id}:[{ids_str}]")
    return "  ".join(parts) if parts else "[dim]—[/dim]"


def _fmt_relative(iso: str | None) -> str:
    if not iso:
        return "—"
    try:
        # FastAPI emits Z-suffixed RFC3339; convert to fromisoformat shape.
        dt = _dt.datetime.fromisoformat(iso.replace("Z", "+00:00"))
    except (ValueError, AttributeError):
        return "?"
    delta = (_dt.datetime.now(_dt.timezone.utc) - dt).total_seconds()
    if delta < 60:    return f"{int(delta)}s ago"
    if delta < 3600:  return f"{int(delta/60)}m ago"
    if delta < 86400: return f"{int(delta/3600)}h ago"
    return f"{int(delta/86400)}d ago"


# ─── sirb admin nodes rm ─────────────────────────────────────────────────


@nodes_app.command("rm", help="Delete a node from the registry. Operator hygiene only.")
def rm(
    node_id: str = typer.Argument(..., help="Node id to delete (e.g. node_abc123…)."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip the confirmation prompt."),
) -> None:
    """Evict a stale row — most often a zombie left over from before the
    deterministic-node_id fix landed. Does not touch on-chain state.

    The scheduler already filters by heartbeat freshness, so a stale row
    is benign for routing. This command exists for tidiness and for
    de-duping the /nodes view operators look at.
    """
    if not yes:
        if not typer.confirm(f"Delete node {node_id} from the registry?", default=False):
            rprint("[dim]aborted[/dim]")
            raise typer.Exit(code=1)

    try:
        _client().delete(f"/admin/nodes/{node_id}")
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 404:
            rprint(f"[red]No node with id [bold]{node_id}[/bold] in the registry.[/red]")
            raise typer.Exit(code=1)
        rprint(f"[red]Gateway error ({e.response.status_code}):[/red] {e.response.text[:200]}")
        raise typer.Exit(code=1)

    rprint(f"[green]Deleted[/green] node [cyan]{node_id}[/cyan] from the registry.")
