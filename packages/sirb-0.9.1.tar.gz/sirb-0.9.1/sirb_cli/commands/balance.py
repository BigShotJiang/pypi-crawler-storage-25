from __future__ import annotations

from rich import print as rprint

from sirb_cli.client import SirbClient
from sirb_cli.config import env_override_or_config


def run() -> None:
    body = SirbClient(env_override_or_config()).get("/v1/balance")
    src = body.get("source", "?")
    bal = body.get("balance", 0.0)
    if src == "unconfigured":
        rprint("[yellow]Balance unavailable[/yellow] (backend has no chain configured).")
        rprint(f"  wallet: [dim]{body.get('wallet')}[/dim]")
        return
    rprint(f"[green]{bal:.6f} Sirb[/green] available")
    rprint(f"  wallet: [dim]{body.get('wallet')}[/dim]")
    rprint(f"  source: [dim]{src}[/dim]")
