"""``sirb signing-secret`` — generate or inspect HMAC signing secrets.

The signing secret is the HMAC key the gateway uses to verify node-to-
gateway messages (register, heartbeat, result-submit). Same secret on
both sides → messages are accepted. Mismatch → 401.

Two scenarios where you'd generate one:

  1. **You're standing up a brand-new gateway.** The gateway needs ONE
     signing secret (set via `fly secrets set SIRB_SIGNING_SECRET=…`).
     Generate it, save it, hand it to your node operators. This is
     usually `sirb deploy gateway`'s job — it generates one for you —
     but you can mint extras with `sirb signing-secret new`.

  2. **You're rotating the secret.** Bad secret in your password
     manager, suspected leak, periodic rotation. Mint a new one, set it
     on the gateway, distribute to your node operators. Old nodes will
     get 401 until they restart with the new value.

Node operators joining an existing network DO NOT generate their own —
they ask the operator. There's no way to "make up" a secret that the
gateway will accept.
"""

from __future__ import annotations

import secrets

import typer
from rich import print as rprint

# Hyphen in the typer name maps fine — typer kebab-cases command names
# from snake_case-imported modules. We declare both the var name and
# the help text below.
app = typer.Typer(
    invoke_without_command=False,
    no_args_is_help=True,
    help="Generate or inspect HMAC signing secrets for the node↔gateway envelope.",
)


@app.command("new")
def new(
    bytes_: int = typer.Option(
        32, "--bytes", "-b", min=16, max=64,
        help="Entropy in bytes (rendered as 2× hex chars). Default 32 = 256 bits.",
    ),
    show_only: bool = typer.Option(
        False, "--show", help="Print the secret without any contextual hints — useful for piping.",
    ),
) -> None:
    """Generate a fresh HMAC signing secret.

    Used by the gateway as ``SIRB_SIGNING_SECRET`` and by every
    node-agent as ``SIRB_NODE_SIGNING_SECRET``. Both sides must hold
    the same value or messages get rejected with 401.

    If you're a node operator trying to join an EXISTING network, don't
    generate one — get the value from the gateway operator. There's no
    way to invent a secret the gateway will accept.
    """
    secret = secrets.token_hex(bytes_)

    if show_only:
        print(secret)
        return

    rprint(f"[green]new signing secret ({bytes_ * 2} hex chars):[/green]")
    rprint(f"  [bold]{secret}[/bold]")
    rprint()
    rprint("[dim]Save in your password manager. Then:[/dim]")
    rprint("[dim]  • on the gateway:  [/dim][bold]fly secrets set -a sirb-api SIRB_SIGNING_SECRET=" + secret[:16] + "…[/bold]")
    rprint("[dim]  • on each node:    [/dim][bold]sirb deploy node --signing-secret " + secret[:16] + "…[/bold]")
    rprint(
        "\n[yellow]If you're joining an existing network, do NOT use this — "
        "ask the gateway operator for theirs.[/yellow]"
    )
