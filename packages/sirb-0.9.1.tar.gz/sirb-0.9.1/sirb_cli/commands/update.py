"""``sirb update`` — upgrade Sirb components on this machine.

Three things you can update independently, since they ship on different
release cadences:

  sirb update cli       — `pip install --upgrade sirb`
  sirb update node      — `docker pull` the latest image + restart the
                          local sirb-node container against it.
  sirb update gateway   — operators only: `fly deploy --image` against the
                          latest published gateway image.

`sirb update` (bare) checks-but-doesn't-do: shows the version drift for
each component and tells you what to run. Same advisory the per-deploy
hook prints, just on demand.
"""

from __future__ import annotations

import shutil
import subprocess
import sys

import typer
from rich import print as rprint

from sirb_cli.update_check import (
    DEFAULT_NODE_IMAGE_REF,
    check_cli_update,
    check_node_image_age,
    latest_pypi_version,
)


app = typer.Typer(
    name="update",
    invoke_without_command=True,
    no_args_is_help=False,
    help="Check + apply updates for sirb CLI, node-agent, and gateway.",
)


@app.callback()
def _status(ctx: typer.Context) -> None:
    """Bare `sirb update` prints a status report. Subcommands apply the change."""
    if ctx.invoked_subcommand is not None:
        return
    _print_status()


def _print_status() -> None:
    cli_update = check_cli_update()
    if cli_update:
        installed, latest = cli_update
        rprint(
            f"[yellow]●[/yellow] CLI:     installed [yellow]{installed}[/yellow] · "
            f"latest [green]{latest}[/green] — run [cyan]sirb update cli[/cyan]"
        )
    else:
        # Show the installed version regardless so the user has a quick
        # reference; matches what `sirb status` shows.
        try:
            from sirb_cli import __version__ as v

            rprint(f"[green]●[/green] CLI:     [green]{v}[/green] (latest)")
        except Exception:
            rprint("[dim]●[/dim] CLI:     version unknown")

    age = check_node_image_age()
    if age is not None:
        rprint(
            f"[yellow]●[/yellow] node:    local image is [yellow]{age}d[/yellow] old — "
            f"run [cyan]sirb update node[/cyan]"
        )
    elif shutil.which("docker"):
        rprint("[green]●[/green] node:    no stale container detected")
    else:
        rprint("[dim]●[/dim] node:    docker not on PATH; skipping")

    rprint(
        "[dim]●[/dim] gateway: run [cyan]sirb update gateway[/cyan] on the operator host "
        "to redeploy against the latest published image (operators only)"
    )


# ─── sirb update cli ──────────────────────────────────────────────


@app.command(
    "cli", help="Upgrade the sirb CLI via pip (in-place upgrade of this Python's site-packages)."
)
def update_cli(
    pre: bool = typer.Option(
        False, "--pre", help="Allow pre-release versions when resolving --upgrade."
    ),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip the confirmation prompt."),
) -> None:
    """Equivalent to `pip install --upgrade sirb`, but resolves the same
    Python interpreter sirb is currently running under — so a system
    pip / pipx / venv split can't accidentally upgrade the wrong copy."""
    latest = latest_pypi_version() or "unknown"
    rprint("[bold]This will:[/bold]")
    rprint(f"  • run [cyan]{sys.executable} -m pip install --upgrade sirb[/cyan]")
    rprint(f"  • upgrade to PyPI's latest ([green]{latest}[/green])")
    if not yes:
        if not typer.confirm("Proceed?", default=True):
            rprint("[dim]aborted[/dim]")
            raise typer.Exit(code=1)

    cmd = [sys.executable, "-m", "pip", "install", "--upgrade"]
    if pre:
        cmd.append("--pre")
    cmd.append("sirb")
    rprint(f"\n[dim]$ {' '.join(cmd)}[/dim]\n")
    proc = subprocess.run(cmd)
    raise typer.Exit(code=proc.returncode)


# ─── sirb update node ─────────────────────────────────────────────


@app.command("node", help="Pull the latest node-agent image and restart the local container.")
def update_node(
    name: str = typer.Option(
        "sirb-node", "--name", "-n", help="Docker container name (default: sirb-node)."
    ),
    image: str = typer.Option(
        DEFAULT_NODE_IMAGE_REF,
        "--image",
        "-i",
        envvar="SIRB_NODE_IMAGE",
        help=f"Image to pull (default: {DEFAULT_NODE_IMAGE_REF}).",
    ),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip the confirmation prompt."),
) -> None:
    """Pulls the image, stops the running container, and recreates it
    with the same env vars + ports. This is the simple "just take the
    new code" path; for a fresh install (different signing secret, new
    wallet, etc.) re-run `sirb deploy node`."""
    if not shutil.which("docker"):
        rprint("[red]docker not on PATH.[/red] Install Docker and retry.")
        raise typer.Exit(code=1)

    # Inspect the running container so we can recreate it with the same
    # config. If there's no container by that name, advise `sirb deploy
    # node` instead — there's nothing to update.
    inspect = subprocess.run(
        ["docker", "container", "inspect", name],
        capture_output=True,
        text=True,
    )
    if inspect.returncode != 0:
        rprint(f"[yellow]No running container named [bold]{name}[/bold].[/yellow]")
        rprint(
            "Use [cyan]sirb deploy node[/cyan] to set one up from scratch, "
            "or pass [cyan]--name <existing>[/cyan] if it's named differently."
        )
        raise typer.Exit(code=1)

    rprint("[bold]This will:[/bold]")
    rprint(f"  • pull [cyan]{image}[/cyan]")
    rprint(f"  • stop and remove the [cyan]{name}[/cyan] container")
    rprint("  • recreate it from the new image with the same env / ports / restart policy")
    rprint("  • [dim](does not change your signing secret, wallet, or API key)[/dim]")
    if not yes:
        if not typer.confirm("Proceed?", default=True):
            rprint("[dim]aborted[/dim]")
            raise typer.Exit(code=1)

    # Pull the new image. Fail loudly if it doesn't exist.
    rprint(f"\n[dim]$ docker pull {image}[/dim]")
    pull = subprocess.run(["docker", "pull", image])
    if pull.returncode != 0:
        rprint(
            "[red]docker pull failed.[/red] "
            "Check the image ref or your network reachability to ghcr.io."
        )
        raise typer.Exit(code=pull.returncode)

    # Reuse the running container's config so we don't lose the wallet /
    # signing secret / tunnel URL / MODEL MOUNTS / GPU access. Bare
    # env+ports re-emit was the original v0.x behavior and caused the
    # "update corrupts the node" bug: the new container would start
    # without the GGUF mount, without --gpus all, and without the
    # /data:ro mount that holds `sirb models add` history — model_runner
    # would then fail to find the model and the node would appear broken.
    import json

    spec = json.loads(inspect.stdout)[0]
    run = _build_recreate_args(name, image, spec)

    rprint(f"[dim]$ docker rm -f {name}[/dim]")
    removed = subprocess.run(["docker", "rm", "-f", name], capture_output=True, text=True)
    if removed.returncode != 0:
        # Surface what stopped us instead of barreling on to docker run,
        # which would then 409 with "container name already in use" and
        # hide the real reason (permissions, daemon hiccup, paused
        # container, etc.).
        rprint(f"[red]docker rm -f failed:[/red] {removed.stderr.strip() or '(no stderr)'}")
        rprint("[dim]The old container is still in place — your node hasn't been touched.[/dim]")
        raise typer.Exit(code=removed.returncode)

    rprint(
        f"[dim]$ docker run -d --name {name} {image} (with prior env + ports + mounts + gpus)[/dim]"
    )
    started = subprocess.run(run, capture_output=True, text=True)
    if started.returncode != 0:
        # At this point the OLD container has already been removed — the
        # node IS offline. Print the recovery hint so the user can get
        # back online manually instead of leaving them to reconstruct the
        # docker run line from memory.
        rprint(f"[red]docker run failed:[/red] {started.stderr.strip() or '(no stderr)'}")
        rprint()
        rprint(
            "[bold red]Your old container has already been removed — the node is offline.[/bold red]"
        )
        rprint(
            "Re-run [cyan]sirb deploy node[/cyan] to rebuild from scratch, or "
            "manually invoke the captured docker run with the OLD image:"
        )
        # SECURITY: never print raw env values for keys that look like
        # secrets (API key, signing secret, etc.). Operators commonly
        # paste this hint into Discord / issue tracker — exposing the
        # signing secret would let any reader forge node→backend
        # messages from that wallet. Matches CLAUDE.md §6.4 / §8.
        rprint("  [dim]$[/dim] " + " ".join(_shell_quote(a) for a in _redact_secret_envs(run)))
        raise typer.Exit(code=started.returncode)

    rprint(f"\n[green]Updated.[/green] [cyan]{name}[/cyan] is now running [cyan]{image}[/cyan].")
    rprint("Tail logs with: [dim]docker logs -f " + name + "[/dim]")


def _shell_quote(arg: str) -> str:
    """Minimal shlex-style quoting for the recovery-hint pretty-print.
    We use this only for display, never to construct an actual shell
    invocation — that would be a command-injection foot-gun. The CLI
    invokes docker via subprocess.run(list), not via a shell."""
    import shlex

    return shlex.quote(arg)


# Substrings (case-insensitive) that mark an env var as secret-bearing.
# Designed for the operator-facing recovery hint — anything matching
# gets its value replaced with ``***`` before display. Conservative on
# purpose: better to over-redact and hide one harmless config var than
# to leak a signing secret. The actual ``docker run`` we exec uses the
# unredacted argv; redaction is display-only.
_SECRET_ENV_MARKERS = ("API_KEY", "SECRET", "TOKEN", "PASSWORD", "PRIVATE_KEY")


def _redact_secret_envs(argv: list[str]) -> list[str]:
    """Return a copy of ``argv`` with secret-looking ``-e KEY=value``
    pairs rewritten to ``-e KEY=***``. Idempotent. Tolerates ``-e KEY``
    (no ``=``) and ``-e =value`` shapes without crashing — both pass
    through unchanged since they don't expose a key/value pair to redact.
    """
    redacted: list[str] = []
    i = 0
    while i < len(argv):
        token = argv[i]
        if token == "-e" and i + 1 < len(argv):
            kv = argv[i + 1]
            if "=" in kv:
                key, _, _value = kv.partition("=")
                if key and any(m in key.upper() for m in _SECRET_ENV_MARKERS):
                    redacted += ["-e", f"{key}=***"]
                    i += 2
                    continue
            redacted += [token, kv]
            i += 2
            continue
        redacted.append(token)
        i += 1
    return redacted


def _build_recreate_args(name: str, image: str, spec: dict) -> list[str]:
    """Translate a `docker inspect` snapshot into the `docker run` arg
    list that recreates the same container against ``image``.

    Carries over the slices that matter for a working sirb-node:

    - **env vars** (wallet, signing secret, API key, tunnel URL,
      backend URL, model-backend selection)
    - **port bindings** (the agent's 9000 → operator-chosen host port)
    - **bind mounts** (``~/.sirb/data:/data:ro`` for `sirb models add`
      persistence; the GGUF mount for llama-cpp)
    - **device requests** (NVIDIA ``--gpus all`` / ``--gpus count=N``)
    - **devices** (AMD ``--device=/dev/kfd`` etc.)
    - **network mode** (when it's not the default bridge)
    - **resource caps** (``--cpus`` / ``--memory`` if the operator set them)
    - **shm-size / ulimits / sysctls** (llama.cpp + vLLM operators
      commonly set ``--shm-size 4g`` and ``--ulimit memlock=-1``;
      losing those at update time produces silent OOMs after restart)
    - **restart policy** (defaults to ``unless-stopped`` if missing)

    What this DOESN'T carry:

    - ``Cmd`` / ``Entrypoint``: deliberate. A new image may legitimately
      change its default command; pinning the old one would lock us out
      of a fix.
    - ``Labels``: docker-internal; the agent doesn't read them.
    - Image-defined ``ENV`` vars: re-emitted as-is because docker
      inspect doesn't distinguish them from operator-set vars. The
      cost is reverting any new-image default env changes; the win is
      not losing operator-set vars that share a key with image
      defaults. Net: safer to over-preserve.

    Returns the full ``docker run`` argv list. Pure function — no
    subprocess calls — so it's directly unit-testable from a recorded
    inspect fixture without monkey-patching docker.
    """
    config = spec.get("Config") or {}
    host = spec.get("HostConfig") or {}

    restart_policy = (host.get("RestartPolicy") or {}).get("Name") or "unless-stopped"
    args: list[str] = ["docker", "run", "-d", "--name", name, "--restart", restart_policy]

    # Network mode. Skip the docker defaults ("default", "bridge", "")
    # so we don't pin a setting the user never asked for — and skip
    # container:* / "none" too, which can't be re-specified without the
    # original target still existing.
    netmode = host.get("NetworkMode") or ""
    if netmode and netmode not in ("default", "bridge") and not netmode.startswith("container:"):
        args += ["--network", netmode]

    # Resource caps. NanoCpus is in 1e-9 CPUs (so 1.5 CPU == 1500000000).
    # Memory is bytes. Only emit when set — zero means "no cap" in docker.
    nano_cpus = host.get("NanoCpus") or 0
    if nano_cpus:
        cpus = nano_cpus / 1_000_000_000
        # Trim trailing zeros so `1.0` doesn't show up as `1.000000`.
        args += ["--cpus", f"{cpus:g}"]
    memory = host.get("Memory") or 0
    if memory:
        args += ["--memory", str(memory)]

    # llama.cpp and vLLM both commonly need ``--shm-size`` bumped for
    # large-model loads (default 64MB → OOM on multi-GB tensor copies)
    # and ``--ulimit memlock=-1`` so the model can be pinned in RAM
    # without paging. Operators set these once at `sirb deploy node`
    # time and forget about them — losing them on update was the second
    # most likely cause of post-update performance regressions after
    # losing GPU access. Inspect emits both with explicit values when
    # set; we only re-emit when non-zero / non-empty so a default-config
    # container doesn't suddenly grow a `--shm-size 67108864` flag it
    # never had.
    shm = host.get("ShmSize") or 0
    if shm:
        args += ["--shm-size", str(shm)]
    # Ulimits = [{"Name": "memlock", "Soft": -1, "Hard": -1}, ...]
    for u in host.get("Ulimits") or []:
        ulim_name = u.get("Name")
        soft = u.get("Soft")
        hard = u.get("Hard")
        if not ulim_name or soft is None:
            continue
        spec_str = f"{ulim_name}={soft}" + (f":{hard}" if hard is not None and hard != soft else "")
        args += ["--ulimit", spec_str]
    # Sysctls = {"net.ipv4.ip_forward": "1", ...}
    for k, v in (host.get("Sysctls") or {}).items():
        args += ["--sysctl", f"{k}={v}"]

    # Port bindings: PortBindings = {"9000/tcp": [{"HostIp": "", "HostPort": "9000"}, ...], ...}
    for container_port, host_specs in (host.get("PortBindings") or {}).items():
        for host_spec in host_specs or []:
            host_port = host_spec.get("HostPort", "")
            host_ip = host_spec.get("HostIp", "")
            port_arg = (
                f"{host_ip + ':' if host_ip else ''}{host_port}:{container_port.split('/')[0]}"
            )
            args += ["-p", port_arg]

    # Bind mounts. docker inspect exposes BOTH the legacy ``Binds`` list
    # ("src:dst[:mode]") AND the modern ``Mounts`` array with structured
    # entries. We prefer Binds when present (it's what `docker run -v`
    # emitted in the first place) and fall back to Mounts.
    binds = host.get("Binds") or []
    if binds:
        for b in binds:
            args += ["-v", b]
    else:
        for m in host.get("Mounts") or []:
            mtype = m.get("Type") or "bind"
            src = m.get("Source") or ""
            dst = m.get("Target") or m.get("Destination") or ""
            if not src or not dst:
                continue
            # ReadOnly key shape varies between docker API versions —
            # check both forms.
            ro = m.get("ReadOnly") or m.get("RW") is False
            spec_str = f"{src}:{dst}" + (":ro" if ro else "")
            args += (
                ["-v", spec_str]
                if mtype == "bind"
                else [
                    "--mount",
                    f"type={mtype},source={src},target={dst}" + (",readonly" if ro else ""),
                ]
            )

    # GPU device requests (NVIDIA runtime). DeviceRequests is a list of:
    #   {Driver: "nvidia", Count: -1, DeviceIDs: [], Capabilities: [["gpu"]]}
    # Count == -1 == "all". DeviceIDs non-empty == "device=<id>,<id>".
    for dr in host.get("DeviceRequests") or []:
        caps = dr.get("Capabilities") or []
        # Only translate gpu requests — other capability sets are esoteric
        # and we'd rather emit nothing than emit something invalid.
        # Defensive `c or []` guards against a daemon returning a None
        # entry; without it `"gpu" in None` would raise TypeError and
        # take the whole recreate down.
        if not any("gpu" in (c or []) for c in caps):
            continue
        count = dr.get("Count")
        ids = dr.get("DeviceIDs") or []
        if ids:
            args += ["--gpus", "device=" + ",".join(ids)]
        elif count == -1:
            args += ["--gpus", "all"]
        elif isinstance(count, int) and count > 0:
            args += ["--gpus", f"count={count}"]

    # Raw devices (AMD ROCm, /dev/dri, etc.).
    for d in host.get("Devices") or []:
        on_host = d.get("PathOnHost") or ""
        in_container = d.get("PathInContainer") or on_host
        perms = d.get("CgroupPermissions") or ""
        if not on_host:
            continue
        # docker run --device PATH[:CONTAINER[:PERMS]] form.
        parts = on_host
        if in_container and in_container != on_host:
            parts += f":{in_container}"
            if perms and perms != "rwm":
                parts += f":{perms}"
        args += ["--device", parts]

    # Env vars LAST so they show up at the tail of the command line —
    # easier for an operator to scan / diff against the deploy hint.
    for e in config.get("Env") or []:
        args += ["-e", e]

    args.append(image)
    return args


# ─── sirb update gateway ──────────────────────────────────────────


@app.command(
    "gateway", help="(operator) Redeploy a Fly.io gateway against the latest published image."
)
def update_gateway(
    app_name: str = typer.Option(..., "--app-name", "-a", help="Fly app name (e.g. sirb-api)."),
    image: str = typer.Option(
        "ghcr.io/ammarwa/sirb-gateway:latest",
        "--image",
        envvar="SIRB_GATEWAY_IMAGE",
        help="Image to deploy. Default: ghcr.io/ammarwa/sirb-gateway:latest.",
    ),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip the confirmation prompt."),
) -> None:
    """Wraps `fly deploy --image <ref>` so an operator doesn't have to
    keep that incantation in their head. Runs alembic migrations on the
    new container at first request automatically (entrypoint handles it
    when SIRB_DATABASE_URL is set)."""
    if not shutil.which("fly") and not shutil.which("flyctl"):
        rprint("[red]flyctl not on PATH.[/red] Install from https://fly.io/docs/flyctl/install/")
        raise typer.Exit(code=1)

    rprint("[bold]This will:[/bold]")
    rprint(f"  • run [cyan]fly deploy -a {app_name} --image {image}[/cyan]")
    rprint("  • [dim]alembic migrations run automatically on container boot[/dim]")
    if not yes:
        if not typer.confirm("Proceed?", default=False):
            rprint("[dim]aborted[/dim]")
            raise typer.Exit(code=1)

    cmd = ["fly", "deploy", "-a", app_name, "--image", image]
    rprint(f"\n[dim]$ {' '.join(cmd)}[/dim]\n")
    proc = subprocess.run(cmd)
    raise typer.Exit(code=proc.returncode)
