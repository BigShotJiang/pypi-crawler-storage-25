"""Agent observations subcommand. **Admin-scoped only.**

Three operations against the admin observations surface:

    sirb observations                    # = `list`  (default: most recent 20)
    sirb observations list [--kind monitoring] [--limit 20] [--full]
    sirb observations show <observation_id>
    sirb observations run [--kind monitoring]

Every endpoint here lands on /admin/observations* in the gateway, which
is gated by ``require_admin``. Non-admin keys get 403; the CLI catches
that and prints a one-line "admin scope required" message rather than
leaking an HTTP traceback. The dry-run footer + the ``run`` operator
hints are intentionally rendered AFTER the admin auth check has passed
— a casual reader with a non-admin key never sees gateway-tuning
guidance they couldn't act on anyway.

Bare `sirb observations` runs the list — typer would otherwise show
help-only, which is unfriendly for the day-to-day "what did the agents
just see?" use.

When every recent observation is in `dry_run` outcome it means the
gateway's per-agent enable flag is off (default-deny). The table
surfaces that with an explicit footer hint so the operator doesn't have
to grep the runbook to figure out why nothing's happening.
"""

from __future__ import annotations

import typer
from rich import box
from rich import print as rprint
from rich.console import Console
from rich.table import Table

from sirb_cli.client import AdminScopeRequired, SirbClient
from sirb_cli.config import env_override_or_config

app = typer.Typer(
    invoke_without_command=True,
    no_args_is_help=False,
    help="(admin) Network observations from the monitoring + fraud agents.",
)


def _client() -> SirbClient:
    return SirbClient(env_override_or_config())


def _admin_only_or_exit(fn):
    """Decorator: run `fn` and translate AdminScopeRequired into a clean
    typer.Exit(1) with a one-line message. Keeps the per-command code
    free of try/except boilerplate."""
    def wrapper(*args, **kwargs):
        try:
            return fn(*args, **kwargs)
        except AdminScopeRequired as e:
            rprint("[red]Admin scope required.[/red] "
                   "Sign in with an admin key (`sirb login --api-key sirb_<admin>…`) to use this command.")
            rprint(f"[dim]gateway: {e}[/dim]")
            raise typer.Exit(code=1)
    wrapper.__wrapped__ = fn
    wrapper.__doc__ = fn.__doc__
    return wrapper


# Pretty-print these by hand; rich Table can't color cells based on content
# without one column per state, which is overkill for a one-column case.
_OUTCOME_COLOR = {
    "ok":          "green",
    "success":     "green",
    "dry_run":     "yellow",
    "skipped":     "yellow",
    "error":       "red",
    "parse_error": "red",
}
_SEV_COLOR = {"critical": "red", "warning": "yellow", "info": "cyan"}

VALID_KINDS = ("monitoring", "fraud_detection", "routing_recommender", "model_demand")


def _fmt_findings(findings: list[dict]) -> str:
    if not findings:
        return "[dim](none)[/dim]"
    counts: dict[str, int] = {}
    for f in findings:
        sev = f.get("severity", "info")
        counts[sev] = counts.get(sev, 0) + 1
    parts = []
    for sev in ("critical", "warning", "info"):
        if sev in counts:
            color = _SEV_COLOR.get(sev, "white")
            parts.append(f"[{color}]{counts[sev]} {sev}[/{color}]")
    return ", ".join(parts)


def _outcome_cell(outcome: str) -> str:
    color = _OUTCOME_COLOR.get(outcome, "white")
    return f"[{color}]{outcome}[/{color}]"


def _print_observation_table(data: list[dict], title_extra: str = "") -> None:
    title = f"agent observations ({len(data)} shown)"
    if title_extra:
        title = f"{title} — {title_extra}"

    t = Table(title=title, box=box.SIMPLE_HEAD, title_justify="left", title_style="bold")
    t.add_column("when",     style="dim", no_wrap=True)
    t.add_column("kind",     no_wrap=True)
    t.add_column("outcome",  no_wrap=True)
    t.add_column("provider", style="dim", no_wrap=True)
    t.add_column("summary",  overflow="fold")
    t.add_column("findings", no_wrap=True)

    for obs in data:
        t.add_row(
            obs.get("created_at", "")[:19].replace("T", " "),
            obs.get("kind", ""),
            _outcome_cell(obs.get("outcome", "")),
            obs.get("provider", "") or "—",
            (obs.get("summary") or "")[:90] or "[dim]—[/dim]",
            _fmt_findings(obs.get("findings", [])),
        )
    Console().print(t)

    # Surface the "everything's in dry_run" footgun explicitly. Without
    # this the user sees "yellow yellow yellow" and has to dig through
    # docs to learn that the gateway's per-agent flags are default-off.
    all_dry = data and all(o.get("outcome") == "dry_run" for o in data)
    if all_dry:
        rprint(
            "\n[yellow]All rows are dry_run.[/yellow] Each agent is currently in "
            "snapshot-only mode (no LLM call). To enable real runs, on the gateway:"
        )
        rprint("  fly secrets set -a sirb-api \\")
        rprint("    SIRB_MONITORING_ENABLED=true \\")
        rprint("    SIRB_FRAUD_DETECTION_ENABLED=true \\")
        rprint("    SIRB_ROUTING_RECOMMENDER_ENABLED=true \\")
        rprint("    SIRB_MODEL_DEMAND_ENABLED=true \\")
        rprint("    SIRB_AGENT_SIRB_API_KEY=sirb_…  [dim]# admin key the agent calls /v1 with[/dim]")


@app.callback()
def _default(ctx: typer.Context) -> None:
    """When the user runs `sirb observations` with no subcommand, list the
    most recent observations instead of showing help. Subcommands
    explicitly invoked still take precedence."""
    if ctx.invoked_subcommand is None:
        list_observations(kind=None, limit=20, full=False)


@app.command("list")
@_admin_only_or_exit
def list_observations(
    kind: str | None = typer.Option(None, "--kind", help=f"Filter by agent kind: one of {', '.join(VALID_KINDS)}."),
    limit: int = typer.Option(20, "--limit", min=1, max=500, help="Most-recent N (1-500)."),
    full: bool = typer.Option(False, "--full", help="Also print per-observation findings detail."),
) -> None:
    """(admin) List recent agent observations."""
    if kind and kind not in VALID_KINDS:
        raise typer.BadParameter(f"--kind must be one of: {', '.join(VALID_KINDS)}")
    params: dict[str, str] = {"limit": str(limit)}
    if kind:
        params["kind"] = kind
    body = _client().get("/admin/observations", params=params)
    data = body.get("data", [])
    if not data:
        rprint("[dim](no observations recorded yet — try `sirb observations run`)[/dim]")
        return

    _print_observation_table(data, title_extra=f"kind={kind}" if kind else "")

    if full:
        for obs in data:
            _print_observation_detail(obs)


@app.command("show")
@_admin_only_or_exit
def show_observation(
    observation_id: str = typer.Argument(..., help="Observation id, e.g. obs_abc123…"),
) -> None:
    """(admin) Print full detail of a single observation, including findings."""
    body = _client().get(f"/admin/observations/{observation_id}")
    _print_observation_detail(body)


@app.command("run")
@_admin_only_or_exit
def run_now(
    kind: str = typer.Option(
        "monitoring", "--kind", "-k",
        help=f"Which agent to dispatch: one of {', '.join(VALID_KINDS)}.",
    ),
) -> None:
    """(admin) Trigger one agent run immediately. Defaults to the monitoring agent.

    The agent's outcome will be ``dry_run`` until the matching enable
    flag is set on the gateway (SIRB_<KIND>_ENABLED=true) AND an LLM
    API key is configured (SIRB_AGENT_SIRB_API_KEY=…).
    """
    if kind not in VALID_KINDS:
        raise typer.BadParameter(f"--kind must be one of: {', '.join(VALID_KINDS)}")
    body = _client().post(f"/admin/observations/run?kind={kind}", {})
    _print_observation_detail(body)


def _print_observation_detail(obs: dict) -> None:
    rprint()
    rprint(f"[bold]{obs.get('id')}[/bold]  "
           f"kind={obs.get('kind')}  "
           f"outcome={_outcome_cell(obs.get('outcome', ''))}  "
           f"provider={obs.get('provider') or 'none'}  "
           f"latency={obs.get('latency_ms', '?')}ms")
    if obs.get("summary"):
        rprint(f"  summary:    {obs.get('summary')}")
    if obs.get("confidence"):
        rprint(f"  confidence: {obs.get('confidence')}")
    findings = obs.get("findings", [])
    if not findings:
        rprint("  findings:   [dim](none)[/dim]")
        return
    rprint("  findings:")
    for f in findings:
        color = _SEV_COLOR.get(f.get("severity", "info"), "white")
        rprint(f"    [{color}]{f.get('severity', '?'):>8}[/{color}]  "
               f"{f.get('category', ''):<22}  "
               f"[bold]{f.get('target', ''):<28}[/bold]  "
               f"{f.get('detail', '')}")
