from __future__ import annotations

import typer
from rich import print as rprint
from rich.console import Console
from rich.table import Table

from sirb_cli.client import SirbClient
from sirb_cli.config import env_override_or_config

app = typer.Typer(no_args_is_help=True, help="Manage your Sirb API keys.")


@app.command("list")
def list_keys() -> None:
    body = SirbClient(env_override_or_config()).get("/admin/api-keys")
    t = Table(title="Your API keys")
    t.add_column("id"); t.add_column("name"); t.add_column("status")
    t.add_column("created"); t.add_column("last used")
    for k in body.get("data", []):
        t.add_row(k["id"], k["name"], k["status"],
                  (k.get("created_at") or "")[:19],
                  (k.get("last_used_at") or "—")[:19])
    Console().print(t)


@app.command("create")
def create_key(
    name: str = typer.Option(..., "--name", "-n", help="Human-friendly label."),
    rate_limit: int | None = typer.Option(None, "--rate-limit-per-minute",
                                          help="Optional rate limit (default 60)."),
) -> None:
    body = SirbClient(env_override_or_config()).post(
        "/admin/api-keys",
        {"name": name, "rate_limit_per_minute": rate_limit},
    )
    rprint(f"[green]Created[/green] key [bold]{body['id']}[/bold]")
    rprint(f"\n  [bold yellow]{body['key']}[/bold yellow]\n")
    rprint("[red]This is the only time this plaintext key is shown. Save it now.[/red]")


@app.command("revoke")
def revoke_key(key_id: str = typer.Argument(..., help="Key id to revoke.")) -> None:
    SirbClient(env_override_or_config()).delete(f"/admin/api-keys/{key_id}")
    rprint(f"[green]Revoked[/green] {key_id}")
