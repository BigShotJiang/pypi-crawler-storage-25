"""``sirb profiles`` — manage saved (base_url, api_key, model) bundles.

Each profile is a full config bundle, so switching profiles also switches
the gateway you talk to and the default model. Common shapes:

  - Just multiple keys against api.sirb.run: every profile shares the
    same base_url, only api_key differs.
  - Prod + local-dev: one profile points at api.sirb.run, another at
    http://localhost:8000 with the dev key.
  - Prod + a fork's stage env: similar, with the fork's domain.

Commands:

  sirb profiles                    # list (default action; same as `list`)
  sirb profiles list
  sirb profiles show [name]        # full bundle for one profile
  sirb profiles add <name>         # add or update (prompts for fields)
  sirb profiles use <name>         # switch the active profile
  sirb profiles rm <name>          # delete; can't delete the active one

Existing commands (`chat`, `balance`, `keys`, …) keep reading the active
profile — no per-command flag needed.
"""

from __future__ import annotations

import typer
from rich import box
from rich import print as rprint
from rich.console import Console
from rich.table import Table

from sirb_cli.config import (
    CliConfig,
    ProfileStore,
)


app = typer.Typer(
    name="profiles",
    invoke_without_command=True,
    no_args_is_help=False,
    help="Manage saved (base_url, api_key, model) profiles.",
)
console = Console()


def _mask_key(key: str | None) -> str:
    if not key:
        return "[dim]<unset>[/dim]"
    if len(key) <= 8:
        return "[dim]sirb_***[/dim]"
    return f"[dim]…{key[-6:]}[/dim]"


def _render_table(store: ProfileStore) -> None:
    if not store.profiles:
        rprint("[dim]No profiles saved.[/dim]")
        rprint("Add one with: [cyan]sirb profiles add <name>[/cyan]  "
               "(or run [cyan]sirb login[/cyan] to create the [green]default[/green] profile)")
        return

    table = Table(box=box.SIMPLE_HEAD, header_style="bold",
                  title="Profiles", title_justify="left", title_style="bold")
    table.add_column("", no_wrap=True)  # active marker
    table.add_column("Name", no_wrap=True, style="cyan")
    table.add_column("Base URL", no_wrap=True)
    table.add_column("API key", no_wrap=True)
    table.add_column("Default model")

    for name in store.names():
        cfg = store.profiles[name]
        marker = "[bold green]●[/bold green]" if name == store.active else " "
        table.add_row(marker, name, cfg.base_url, _mask_key(cfg.api_key), cfg.default_model)
    console.print(table)
    rprint("[dim]Active profile is marked with [bold green]●[/bold green]. "
           "Switch with [cyan]sirb profiles use <name>[/cyan].[/dim]")


@app.callback()
def _default(ctx: typer.Context) -> None:
    """When invoked bare (`sirb profiles`), default to listing."""
    if ctx.invoked_subcommand is None:
        _render_table(ProfileStore.load())


@app.command("list", help="List saved profiles (default action).")
def list_() -> None:
    _render_table(ProfileStore.load())


@app.command("show", help="Show full details for one profile (or the active one if no name given).")
def show(name: str | None = typer.Argument(None, help="Profile name; defaults to active.")) -> None:
    store = ProfileStore.load()
    target = name or store.active
    if target not in store.profiles:
        rprint(f"[red]Profile [bold]{target}[/bold] not found.[/red]")
        rprint(f"Saved profiles: {', '.join(store.names()) or '[dim](none)[/dim]'}")
        raise typer.Exit(code=1)
    cfg = store.profiles[target]
    marker = " [bold green](active)[/bold green]" if target == store.active else ""
    rprint(f"[bold]Profile [cyan]{target}[/cyan]{marker}[/bold]")
    rprint(f"  base_url:      {cfg.base_url}")
    rprint(f"  api_key:       {_mask_key(cfg.api_key)}")
    rprint(f"  default_model: {cfg.default_model}")


@app.command("add", help="Add or update a profile. Prompts for any field you omit.")
def add(
    name: str = typer.Argument(..., help="Profile name (e.g. prod, local-dev, stage)."),
    api_key: str | None = typer.Option(None, "--api-key", "-k",
                                        help="API key. Prompted (hidden) if omitted."),
    base_url: str = typer.Option("https://api.sirb.run", "--base-url", "-u",
                                  help="Gateway base URL."),
    default_model: str = typer.Option("gemma4:e4b", "--model", "-m",
                                       help="Default model for `sirb chat`."),
    use: bool = typer.Option(False, "--use",
                              help="Also switch the active profile to this one."),
) -> None:
    if not api_key:
        api_key = typer.prompt(f"API key for profile [{name}]", hide_input=True)
    store = ProfileStore.load()
    is_update = name in store.profiles
    store.profiles[name] = CliConfig(
        base_url=base_url.rstrip("/"),
        api_key=api_key,
        default_model=default_model,
    )
    # First profile ever? Auto-mark it active even without --use.
    if len(store.profiles) == 1 or use:
        store.active = name
    p = store.save()
    verb = "Updated" if is_update else "Saved"
    rprint(f"[green]{verb}[/green] profile [cyan]{name}[/cyan] → [bold]{p}[/bold]")
    if store.active == name:
        rprint("  [bold green]●[/bold green] now active")
    else:
        rprint(f"  active profile is still [cyan]{store.active}[/cyan]; "
               f"switch with [cyan]sirb profiles use {name}[/cyan]")


@app.command("use", help="Switch the active profile.")
def use(name: str = typer.Argument(..., help="Profile name to activate.")) -> None:
    store = ProfileStore.load()
    if name not in store.profiles:
        rprint(f"[red]Profile [bold]{name}[/bold] not found.[/red]")
        rprint(f"Saved profiles: {', '.join(store.names()) or '[dim](none)[/dim]'}")
        rprint(f"Create it first with: [cyan]sirb profiles add {name}[/cyan]")
        raise typer.Exit(code=1)
    store.active = name
    store.save()
    cfg = store.profiles[name]
    rprint(f"[green]Active profile[/green] → [cyan]{name}[/cyan]")
    rprint(f"  base_url:      {cfg.base_url}")
    rprint(f"  default_model: {cfg.default_model}")


@app.command("rm", help="Delete a profile. The active profile cannot be removed.")
def rm(
    name: str = typer.Argument(..., help="Profile name to delete."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip the confirmation prompt."),
) -> None:
    store = ProfileStore.load()
    if name not in store.profiles:
        rprint(f"[red]Profile [bold]{name}[/bold] not found.[/red]")
        raise typer.Exit(code=1)
    if name == store.active:
        rprint(f"[red]Refusing to delete the active profile [bold]{name}[/bold].[/red]")
        rprint(f"Switch first: [cyan]sirb profiles use <other>[/cyan], then [cyan]sirb profiles rm {name}[/cyan]")
        raise typer.Exit(code=1)
    if not yes:
        if not typer.confirm(f"Delete profile {name}?", default=False):
            rprint("[dim]aborted[/dim]")
            raise typer.Exit(code=1)
    del store.profiles[name]
    store.save()
    rprint(f"[green]Deleted[/green] profile [cyan]{name}[/cyan]")
