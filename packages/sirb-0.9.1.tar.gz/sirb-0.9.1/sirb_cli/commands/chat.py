from __future__ import annotations

import sys

import typer
from rich import print as rprint

from sirb_cli.client import SirbClient
from sirb_cli.config import env_override_or_config


def run(
    prompt: list[str] = typer.Argument(..., help="The user prompt."),
    model: str | None = typer.Option(None, "--model", "-m",
                                     help="Model id or alias. Defaults to config default."),
    stream: bool = typer.Option(False, "--stream", help="Stream tokens as they arrive."),
) -> None:
    text = " ".join(prompt)
    client = SirbClient(env_override_or_config())

    if stream:
        for chunk in client.chat_stream(text, model=model):
            sys.stdout.write(chunk)
            sys.stdout.flush()
        sys.stdout.write("\n")
        return

    body = client.chat(text, model=model)
    completion = body["choices"][0]["message"]["content"]
    rprint(completion)
    u = body.get("usage", {})
    rprint(f"[dim]usage: {u.get('prompt_tokens', 0)} prompt + "
           f"{u.get('completion_tokens', 0)} completion = "
           f"{u.get('total_tokens', 0)} tokens[/dim]")
