"""``sirb status`` — single-pane health check.

Promised on the homepage's install snippet ("Confirm you're alive in the
swarm: `sirb status`"), this command gives a holistic answer to "is
everything wired up right?":

  - Local config (base URL, configured API key)
  - Gateway reachable (probes /healthz, no auth needed)
  - Auth working (probes /v1/balance, needs a valid key)
  - Network shape (number of online nodes, available models)
  - Optional: local node container if one is running

Exit code 0 when everything is green, 1 when at least one check failed.
Helpful in shell scripts and CI: `sirb status && deploy_my_thing`.
"""

from __future__ import annotations

import shutil
import subprocess
import time
from typing import Any

import httpx
from rich import box
from rich.console import Console
from rich.table import Table

from sirb_cli.config import env_override_or_config
from sirb_cli.update_check import (
    check_cli_update,
    check_node_image_age,
    print_cli_update_advisory_if_outdated,
)


console = Console()

OK   = "[green]ok[/green]"
WARN = "[yellow]warn[/yellow]"
FAIL = "[red]fail[/red]"


def run() -> None:
    cfg = env_override_or_config()
    table = Table(show_header=True, header_style="bold", box=box.SIMPLE_HEAD,
                  title="Sirb status", title_justify="left", title_style="bold")
    table.add_column("Check",   style="dim", no_wrap=True)
    table.add_column("Result",  no_wrap=True)
    table.add_column("Detail",  overflow="fold")

    any_fail = False

    # ── Config ──
    if cfg.api_key:
        key_tail = cfg.api_key[-6:] if len(cfg.api_key) > 6 else "***"
        table.add_row("Config", OK, f"{cfg.base_url}  ·  key …{key_tail}  ·  default-model {cfg.default_model}")
    else:
        table.add_row("Config", WARN, f"{cfg.base_url}  ·  [yellow]no api key[/yellow] — run `sirb login`")

    # ── Gateway /healthz (no auth) ──
    health_url = cfg.base_url.rstrip("/") + "/healthz"
    started = time.monotonic()
    try:
        r = httpx.get(health_url, timeout=8.0)
        latency_ms = int((time.monotonic() - started) * 1000)
        if r.status_code == 200:
            badge = OK if latency_ms < 1000 else WARN
            table.add_row("Gateway", badge, f"{health_url} → {r.status_code} in {latency_ms}ms")
        else:
            any_fail = True
            table.add_row("Gateway", FAIL, f"{health_url} → HTTP {r.status_code}")
    except httpx.HTTPError as e:
        any_fail = True
        table.add_row("Gateway", FAIL, f"{health_url} → {type(e).__name__}: {e}")

    # ── /readyz (no auth) — Postgres + chain ──
    ready_url = cfg.base_url.rstrip("/") + "/readyz"
    try:
        r = httpx.get(ready_url, timeout=8.0)
        body = _try_json(r)
        if r.status_code == 200:
            db_ok = body.get("db", {}).get("ok", body.get("db_ok", True))
            chain = body.get("chain", {})
            chain_state = "skipped" if chain.get("skipped") else ("ok" if chain.get("ok", True) else "fail")
            table.add_row("Readiness", OK, f"db={db_ok}  ·  chain={chain_state}")
        elif r.status_code == 503:
            table.add_row("Readiness", WARN, f"503 — {body.get('detail', body)}")
        else:
            table.add_row("Readiness", WARN, f"HTTP {r.status_code}")
    except httpx.HTTPError as e:
        table.add_row("Readiness", WARN, f"{type(e).__name__}: {e}")

    # ── Auth (requires API key) ──
    if cfg.api_key:
        try:
            r = httpx.get(cfg.base_url.rstrip("/") + "/v1/balance",
                          headers={"Authorization": f"Bearer {cfg.api_key}"},
                          timeout=8.0)
            if r.status_code == 200:
                b = r.json()
                detail = f"wallet={b.get('wallet', '?')[:14]}…  ·  balance={b.get('balance', 0):.4f} SIRB ({b.get('source')})"
                table.add_row("Auth", OK, detail)
            elif r.status_code == 401:
                any_fail = True
                table.add_row("Auth", FAIL, "key rejected (401) — mint a new one via `sirb keys create`")
            else:
                any_fail = True
                table.add_row("Auth", FAIL, f"HTTP {r.status_code}")
        except httpx.HTTPError as e:
            any_fail = True
            table.add_row("Auth", FAIL, f"{type(e).__name__}: {e}")
    else:
        table.add_row("Auth", WARN, "skipped (no api key)")

    # ── Network — model catalog + node count ──
    try:
        models = httpx.get(cfg.base_url.rstrip("/") + "/v1/models", timeout=8.0).json()
        items = models.get("data", []) or []
        if items:
            sample = ", ".join(m["id"] for m in items[:4])
            more = f" (+{len(items) - 4} more)" if len(items) > 4 else ""
            table.add_row("Models", OK, f"{len(items)} routable: {sample}{more}")
        else:
            table.add_row("Models", WARN, "0 models — no node is advertising anything right now")
    except httpx.HTTPError as e:
        table.add_row("Models", WARN, f"{type(e).__name__}: {e}")

    try:
        nodes = httpx.get(cfg.base_url.rstrip("/") + "/nodes", timeout=8.0).json()
        if isinstance(nodes, list):
            online = sum(1 for n in nodes if n.get("status") == "online")
            table.add_row("Nodes", OK if online > 0 else WARN,
                          f"{online} online / {len(nodes)} registered")
    except httpx.HTTPError as e:
        table.add_row("Nodes", WARN, f"{type(e).__name__}: {e}")

    # ── Local node container (best-effort, only if docker is on PATH) ──
    local_node_running = False
    if shutil.which("docker"):
        try:
            out = subprocess.run(
                ["docker", "ps", "--filter", "name=sirb-node", "--format", "{{.Status}}\t{{.Image}}"],
                capture_output=True, text=True, timeout=5,
            )
            stdout = (out.stdout or "").strip()
            if stdout:
                first = stdout.splitlines()[0]
                table.add_row("Local node", OK, first.replace("\t", "  ·  "))
                local_node_running = True
            else:
                table.add_row("Local node", WARN, "no `sirb-node` container running on this machine")
        except (subprocess.SubprocessError, OSError):
            pass  # silent — docker is optional

    # ── Update advisories: CLI version (always) + local node image age ──
    cli_update = check_cli_update()
    if cli_update:
        installed, latest = cli_update
        table.add_row("CLI version", WARN,
                      f"installed {installed} · latest {latest} — run `pip install --upgrade sirb`")
    else:
        # Show installed version even when current; useful in bug reports.
        from sirb_cli import __version__ as _v
        table.add_row("CLI version", OK, f"{_v} (latest)")

    if local_node_running:
        age = check_node_image_age()
        if age is not None:
            table.add_row("Node image", WARN,
                          f"image is {age} days old — run `sirb deploy node` to refresh to :latest")

    console.print(table)

    # The big coral banner is the part users actually notice. Print it
    # AFTER the table so it's the last thing in the terminal scrollback.
    print_cli_update_advisory_if_outdated()

    if any_fail:
        raise SystemExit(1)


def _try_json(r: httpx.Response) -> dict[str, Any]:
    try:
        return r.json()
    except ValueError:
        return {}
