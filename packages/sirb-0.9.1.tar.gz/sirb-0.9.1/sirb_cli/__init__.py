# Source of truth for the version is pyproject.toml — read it via
# package metadata so the two can't drift. The fallback covers the
# dev case of running from an unpinned checkout.
from importlib import metadata as _metadata

try:
    __version__ = _metadata.version("sirb")
except _metadata.PackageNotFoundError:
    __version__ = "0.0.0+dev"
