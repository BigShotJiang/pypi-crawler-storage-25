"""Detect inference servers already running on the host.

Most contributors already have Ollama, LM Studio, vLLM, or
``llama-server`` (llama.cpp's HTTP server) installed and serving models
on their workstation. Rather than spinning up a second model server
inside the node-agent container, ``sirb deploy node`` can detect those
and offer to proxy through them — the operator gets working multi-model
serving in one command without managing a second model stack.

When the operator picks "proxy this", we:

  1. Use the slim ``:proxy-latest`` container variant (no bundled
     llama-cpp-python — see ``node-agent/Dockerfile.proxy``).
  2. Auto-fill ``--models`` from the server's model list.
  3. Auto-set ``--ollama-url`` / ``--vllm-url`` to point at the host
     (translated to ``host.docker.internal`` for the in-container URL).

Detection is **probe-by-port** on localhost only. We don't scan an IP
range — the container will reach the host via Docker's bridge, and
nothing outside localhost should be auto-proxied without an explicit
``--ollama-url`` / ``--vllm-url`` flag from the operator.

Server endpoints checked (all OpenAI-compatible except Ollama):

  Ollama        :11434  GET /api/tags          (Ollama-native models list)
  LM Studio     :1234   GET /v1/models         (OpenAI-compat)
  vLLM          :8000   GET /v1/models         (OpenAI-compat)
  llama-server  :8080   GET /v1/models         (llama.cpp HTTP, OpenAI-compat)

Probes are bounded by a tight per-request timeout (1 second) so a host
with nothing listening doesn't add noticeable latency to ``sirb deploy
node``.
"""

from __future__ import annotations

import json
import socket
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from typing import Literal

ServerKind = Literal["ollama", "lmstudio", "vllm", "llama-server"]


# Maps the kind label to the Sirb node-agent backend that should proxy
# it. Ollama has its own protocol (``--backend ollama``); the others
# are OpenAI-API-shaped and go through the vLLM bridge (``--backend
# vllm``), which is just an OpenAI-API client under the hood.
KIND_TO_SIRB_BACKEND: dict[ServerKind, str] = {
    "ollama":       "ollama",
    "lmstudio":     "vllm",
    "vllm":         "vllm",
    "llama-server": "vllm",
}


@dataclass(frozen=True)
class DetectedServer:
    """One inference server found on the host."""

    kind: ServerKind
    port: int
    base_url: str             # http://localhost:PORT
    in_container_url: str     # http://host.docker.internal:PORT (what the agent uses)
    models: list[str] = field(default_factory=list)
    version: str | None = None

    def display(self) -> str:
        """One-liner for the deploy preflight prompt."""
        if self.models:
            count = len(self.models)
            preview = ", ".join(self.models[:3])
            more = "" if count <= 3 else f" + {count - 3} more"
            return (f"{self.kind} at {self.base_url} "
                    f"({count} model{'s' if count != 1 else ''}: {preview}{more})")
        return f"{self.kind} at {self.base_url} (no models loaded yet)"


# ─────────────────── helpers ─────────────────────────────


# Per-port probe timeout. 1 second is enough for a tcp-accept + a small
# json response on localhost; anything slower than that is almost
# certainly not a real inference server.
_PROBE_TIMEOUT = 1.0


def _tcp_open(port: int, host: str = "127.0.0.1") -> bool:
    """Cheap TCP-connect probe. We only HTTP-poke ports that accept TCP,
    so closed-port hosts (the common case) skip the urllib path entirely.
    """
    try:
        with socket.create_connection((host, port), timeout=_PROBE_TIMEOUT):
            return True
    except OSError:
        return False


def _http_get_json(url: str) -> dict | list | None:
    """GET JSON with a tight timeout. Returns None on any failure
    (timeout, non-200, non-JSON body, network error). The probes call
    this for each candidate server and treat None as "not running"."""
    req = urllib.request.Request(url, headers={"Accept": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=_PROBE_TIMEOUT) as resp:
            if resp.status != 200:
                return None
            body = resp.read()
    except (urllib.error.URLError, socket.timeout, OSError, ConnectionResetError):
        return None
    try:
        return json.loads(body)
    except (ValueError, json.JSONDecodeError):
        return None


# ─────────────────── per-server probes ─────────────────────────────


def _probe_ollama(port: int = 11434) -> DetectedServer | None:
    """Ollama exposes ``GET /api/tags`` → ``{"models": [{"name": ...,
    ...}]}``. Distinctive enough that we don't need a second sentinel
    check — no other server uses that shape on that path."""
    if not _tcp_open(port):
        return None
    base = f"http://localhost:{port}"
    tags = _http_get_json(f"{base}/api/tags")
    if not isinstance(tags, dict) or "models" not in tags:
        return None
    models = [m.get("name") for m in tags.get("models", []) if m.get("name")]
    version = None
    ver = _http_get_json(f"{base}/api/version")
    if isinstance(ver, dict):
        version = ver.get("version")
    return DetectedServer(
        kind="ollama",
        port=port,
        base_url=base,
        in_container_url=f"http://host.docker.internal:{port}",
        models=sorted(models),
        version=version,
    )


def _probe_openai_compat(
    kind: ServerKind, port: int, sentinel_id_contains: str | None = None
) -> DetectedServer | None:
    """LM Studio / vLLM / llama-server all expose ``GET /v1/models`` in
    the OpenAI shape. We tell them apart by port because the response
    body is uniform.

    ``sentinel_id_contains`` lets a caller insist on a substring in at
    least one model id before claiming a match. Not currently used —
    port + shape is unambiguous enough for the four servers we probe.
    """
    if not _tcp_open(port):
        return None
    base = f"http://localhost:{port}"
    models_doc = _http_get_json(f"{base}/v1/models")
    if not isinstance(models_doc, dict) or "data" not in models_doc:
        return None
    ids: list[str] = []
    for item in models_doc.get("data", []):
        if isinstance(item, dict) and item.get("id"):
            ids.append(str(item["id"]))
    if sentinel_id_contains and not any(sentinel_id_contains in i for i in ids):
        return None
    return DetectedServer(
        kind=kind,
        port=port,
        base_url=base,
        in_container_url=f"http://host.docker.internal:{port}",
        models=sorted(ids),
    )


def _probe_lmstudio(port: int = 1234) -> DetectedServer | None:
    return _probe_openai_compat("lmstudio", port)


def _probe_vllm(port: int = 8000) -> DetectedServer | None:
    return _probe_openai_compat("vllm", port)


def _probe_llama_server(port: int = 8080) -> DetectedServer | None:
    return _probe_openai_compat("llama-server", port)


# ─────────────────── public API ─────────────────────────────


def detect_servers() -> list[DetectedServer]:
    """Probe all known inference servers on localhost. Returns the list
    of found servers in detection order; empty list when nothing is
    listening.

    Order matters slightly for the UI: we present Ollama first (most
    common contributor setup), then LM Studio (rising), then the
    OpenAI-API-shaped servers (vLLM, llama-server).
    """
    out: list[DetectedServer] = []
    for probe in (_probe_ollama, _probe_lmstudio, _probe_vllm, _probe_llama_server):
        try:
            found = probe()
        except Exception:  # noqa: BLE001 - probe failures must never crash deploy
            continue
        if found is not None:
            out.append(found)
    return out
