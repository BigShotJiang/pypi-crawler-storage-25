# `sirb` — Sirb CLI

A thin command-line client for the Sirb decentralized AI compute network.

> Full documentation: **[sirb.run/docs/cli](https://sirb.run/docs/cli/)** —
> renders the same content as `docs/cli.md` in the repo.

> ## ⚠ Experimental / beta software
>
> Sirb is in active development. Interfaces, data layouts, on-chain contracts, image tags, pricing, and reward mechanics may change without notice — sometimes in ways that aren't backward-compatible. The software is provided **as-is, without warranty of any kind**. By running the CLI, the node-agent, the gateway, or the contracts you accept that the maintainers and contributors are **not responsible** for any damages, data loss, hardware wear, financial loss, security incidents, regulatory issues, or other consequences arising from its use. Run on hardware you control, with credentials and funds you can afford to lose.

## Install

```bash
pip install sirb
```

From PyPI ([pypi.org/project/sirb](https://pypi.org/project/sirb/)). Installs a `sirb` binary into your `$PATH`.

For local hacking on the CLI itself:

```bash
git clone https://github.com/ammarwa/SIRB.git
pip install -e SIRB/cli
```

## First-time setup

```bash
sirb login \
  --base-url https://api.sirb.run \
  --api-key sirb_... \
  --model gemma4:e4b
```

Saves to `~/.sirb/config.json` (mode 0600). Environment variables override the
saved config per-command: `SIRB_API_KEY`, `SIRB_BASE_URL`, `SIRB_MODEL`.

Don't have a key yet? Mint one in 30 seconds — no signup, no email:

```bash
curl -X POST https://api.sirb.run/v1/signup \
  -H 'Content-Type: application/json' \
  -d '{"name":"laptop"}'
```

## Commands

```bash
sirb models                                       # list available models + aliases
sirb chat "explain CRDTs in three sentences"
sirb chat --stream "write a haiku about uvicorn"  # token-by-token streaming
sirb chat -m gemma4:e4b "..."                     # pick a specific model
sirb balance                                      # your remaining SIRB
sirb usage --from 2026-05-01 --to 2026-05-14
sirb keys list
sirb keys create --name "opencode"                # plaintext shown once
sirb keys revoke key_abc123
sirb opencode config                              # JSON snippet for OpenCode
sirb opencode env                                 # `export` lines for OpenAI-SDK tools
```

## What it talks to

Plain `httpx`. No `openai` SDK dependency — the CLI hits admin endpoints
too (`/admin/api-keys`), so the marginal value of pulling in the full SDK
just for `/v1/chat/completions` wasn't worth the dependency footprint. The
HTTP code in `sirb_cli/client.py` is short enough to lift into a user's
own integration if they want a starting point.

## Releasing

The CLI is published to PyPI via the GitHub Actions workflow at
[`.github/workflows/publish-cli.yml`](../.github/workflows/publish-cli.yml),
triggered by pushing a `cli-v<version>` tag:

```bash
# bump cli/pyproject.toml version first, commit, then:
git tag cli-v0.1.2
git push origin cli-v0.1.2
```

The workflow asserts the tag version matches `pyproject.toml`, builds sdist
and wheel, runs `twine check`, and publishes via Trusted Publishing (OIDC) —
no PyPI tokens stored as secrets.
