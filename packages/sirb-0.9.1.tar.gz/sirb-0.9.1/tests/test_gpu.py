"""Tests for sirb_cli.gpu — GPU vendor detection + image variant selection.

The probes touch /sys, /dev, and subprocess. We isolate by monkey-
patching:
  - ``shutil.which`` to control whether nvidia-smi / rocminfo / lspci
    are "installed"
  - ``subprocess.run`` to fake nvidia-smi / rocminfo / lspci output
  - ``Path.exists`` / ``Path.is_dir`` / ``Path.glob`` / ``Path.read_text``
    to fake /dev and /sys layout
  - ``platform.system`` to control macOS-vs-Linux branching

The goal is to verify priority ordering (NVIDIA wins over Intel iGPU),
the empty/garbage-input failure modes (don't fall open to admin UI…
sorry, don't fall open to GPU image), and that operator overrides via
detect_for_vendor() honor the choice even on a host without that GPU.
"""

from __future__ import annotations

import subprocess
from unittest.mock import patch

import pytest

from sirb_cli import gpu


# ─────────────────── helpers ─────────────────────────────


class _FakeRun:
    """Pretend `subprocess.run(...)` returned (stdout, returncode)."""

    def __init__(self, stdout: str = "", returncode: int = 0):
        self.stdout = stdout
        self.stderr = ""
        self.returncode = returncode


def _no_subprocess(*_a, **_kw):
    """Default: any subprocess call returns 'binary not found'."""
    raise OSError("FileNotFoundError")


# ─────────────────── NVIDIA probe ─────────────────────────────


def test_nvidia_probe_returns_cuda_when_smi_lists_gpu(monkeypatch):
    """A working nvidia-smi -L means we pick the cuda variant."""
    monkeypatch.setattr(gpu.shutil, "which",
                        lambda name: "/usr/bin/nvidia-smi" if name == "nvidia-smi" else None)
    monkeypatch.setattr(gpu.subprocess, "run", lambda *a, **kw: _FakeRun(
        stdout="GPU 0: NVIDIA GeForce RTX 4090 (UUID: GPU-abc123)\n",
        returncode=0,
    ))
    monkeypatch.setattr(gpu.platform, "system", lambda: "Linux")
    monkeypatch.setattr(gpu, "_read_pci_vendors", lambda: [])

    det = gpu.detect_gpu()
    assert det.vendor == "nvidia"
    assert "RTX 4090" in (det.device_name or "")
    assert det.docker_args == ["--gpus", "all"]


def test_nvidia_probe_falls_through_when_smi_missing(monkeypatch):
    """No nvidia-smi → no NVIDIA detection. Must NOT fall back to a
    fake CUDA detection."""
    monkeypatch.setattr(gpu.shutil, "which", lambda _name: None)
    monkeypatch.setattr(gpu.platform, "system", lambda: "Linux")
    monkeypatch.setattr(gpu, "_read_pci_vendors", lambda: [])

    det = gpu.detect_gpu()
    assert det.vendor == "cpu"


def test_nvidia_probe_falls_through_when_smi_errors(monkeypatch):
    """nvidia-smi exists but exits non-zero (driver mismatch is the
    most common cause) → do NOT pick CUDA. Forcing CUDA in this state
    just relocates the failure into container start time."""
    monkeypatch.setattr(gpu.shutil, "which",
                        lambda name: "/usr/bin/nvidia-smi" if name == "nvidia-smi" else None)
    monkeypatch.setattr(gpu.subprocess, "run", lambda *a, **kw: _FakeRun(
        stdout="", returncode=9,  # NVIDIA-SMI's "driver version mismatch" code
    ))
    monkeypatch.setattr(gpu.platform, "system", lambda: "Linux")
    monkeypatch.setattr(gpu, "_read_pci_vendors", lambda: [])

    det = gpu.detect_gpu()
    assert det.vendor == "cpu"


def test_nvidia_probe_rejects_malformed_smi_output(monkeypatch):
    """C1 fix (silent-failure review): nvidia-smi -L's canonical line
    is `GPU N: ...`. A PATH-shadowing binary (someone's unrelated
    script also called nvidia-smi) emitting non-empty stdout with
    exit 0 used to be silently accepted, leading to a 5GB :cuda
    image pull on a non-NVIDIA host. We now require the line to
    match the canonical regex."""
    monkeypatch.setattr(gpu.shutil, "which",
                        lambda name: "/usr/bin/nvidia-smi" if name == "nvidia-smi" else None)
    monkeypatch.setattr(gpu.subprocess, "run", lambda *a, **kw: _FakeRun(
        stdout="hello world\n",       # not the canonical "GPU 0: ..." shape
        returncode=0,
    ))
    monkeypatch.setattr(gpu.platform, "system", lambda: "Linux")
    monkeypatch.setattr(gpu, "_read_pci_vendors", lambda: [])

    det = gpu.detect_gpu()
    assert det.vendor == "cpu"


def test_nvidia_probe_handles_subprocess_timeout(monkeypatch):
    """nvidia-smi hanging → return None, NOT raise."""
    def _hang(*_a, **_kw):
        raise subprocess.TimeoutExpired(cmd="nvidia-smi -L", timeout=5)
    monkeypatch.setattr(gpu.shutil, "which",
                        lambda name: "/usr/bin/nvidia-smi" if name == "nvidia-smi" else None)
    monkeypatch.setattr(gpu.subprocess, "run", _hang)
    monkeypatch.setattr(gpu.platform, "system", lambda: "Linux")
    monkeypatch.setattr(gpu, "_read_pci_vendors", lambda: [])

    det = gpu.detect_gpu()
    assert det.vendor == "cpu"


# ─────────────────── AMD probe ─────────────────────────────


def test_amd_probe_needs_both_kfd_and_amd_pci(monkeypatch):
    """/dev/kfd alone isn't enough — must also see an AMD-vendor card
    on /sys/class/drm. This avoids false positives on hosts where the
    amdkfd module is loaded but no AMD GPU is actually present."""
    monkeypatch.setattr(gpu.shutil, "which", lambda _name: None)
    monkeypatch.setattr(gpu.platform, "system", lambda: "Linux")

    from pathlib import Path
    monkeypatch.setattr(Path, "exists",
                        lambda self: str(self) == "/dev/kfd")
    monkeypatch.setattr(gpu, "_read_pci_vendors",
                        lambda: [("card0", gpu.PCI_VENDOR_AMD)])

    det = gpu.detect_gpu()
    assert det.vendor == "amd"
    assert "--device" in det.docker_args
    assert "/dev/kfd" in det.docker_args
    assert "/dev/dri" in det.docker_args


def test_amd_probe_skips_when_kfd_missing(monkeypatch):
    """No /dev/kfd → no AMD pick, even if /sys/class/drm shows an AMD
    card (because ROCm requires the kernel module, not just the GPU)."""
    monkeypatch.setattr(gpu.shutil, "which", lambda _name: None)
    monkeypatch.setattr(gpu.platform, "system", lambda: "Linux")
    from pathlib import Path
    monkeypatch.setattr(Path, "exists", lambda self: False)
    monkeypatch.setattr(gpu, "_read_pci_vendors",
                        lambda: [("card0", gpu.PCI_VENDOR_AMD)])

    det = gpu.detect_gpu()
    assert det.vendor == "cpu"


# ─────────────────── Intel probe ─────────────────────────────


def test_intel_probe_picks_sycl_for_intel_pci(monkeypatch):
    """Intel-vendor card on /sys/class/drm with no NVIDIA / AMD signal
    → pick the sycl variant."""
    monkeypatch.setattr(gpu.shutil, "which", lambda _name: None)
    monkeypatch.setattr(gpu.platform, "system", lambda: "Linux")
    from pathlib import Path
    monkeypatch.setattr(Path, "exists", lambda self: False)  # no /dev/kfd
    monkeypatch.setattr(gpu, "_read_pci_vendors",
                        lambda: [("card0", gpu.PCI_VENDOR_INTEL)])
    monkeypatch.setattr(gpu, "_intel_device_name", lambda _c: "Arc A750")

    det = gpu.detect_gpu()
    assert det.vendor == "intel"
    assert det.device_name == "Arc A750"
    assert "--device" in det.docker_args
    assert "/dev/dri" in det.docker_args


# ─────────────────── priority ordering ─────────────────────────────


def test_priority_nvidia_wins_over_intel_igpu(monkeypatch):
    """Hybrid laptop: Intel iGPU on /sys/class/drm + working NVIDIA
    dGPU via nvidia-smi. Must pick CUDA, not Intel iGPU."""
    monkeypatch.setattr(gpu.shutil, "which",
                        lambda name: "/usr/bin/nvidia-smi" if name == "nvidia-smi" else None)
    monkeypatch.setattr(gpu.subprocess, "run", lambda *a, **kw: _FakeRun(
        stdout="GPU 0: NVIDIA GeForce RTX 4070 (UUID: GPU-xyz)\n",
        returncode=0,
    ))
    monkeypatch.setattr(gpu.platform, "system", lambda: "Linux")
    monkeypatch.setattr(gpu, "_read_pci_vendors",
                        lambda: [("card0", gpu.PCI_VENDOR_INTEL),
                                 ("card1", gpu.PCI_VENDOR_NVIDIA)])

    det = gpu.detect_gpu()
    assert det.vendor == "nvidia"


def test_priority_amd_wins_over_intel(monkeypatch):
    """Server with AMD MI300 + Intel BMC display chip — pick ROCm, not
    sycl. AMD comes second in the probe order so this also exercises
    the "AMD short-circuits before Intel" branch."""
    monkeypatch.setattr(gpu.shutil, "which", lambda _name: None)
    monkeypatch.setattr(gpu.platform, "system", lambda: "Linux")
    from pathlib import Path
    monkeypatch.setattr(Path, "exists",
                        lambda self: str(self) == "/dev/kfd")
    monkeypatch.setattr(gpu, "_read_pci_vendors",
                        lambda: [("card0", gpu.PCI_VENDOR_INTEL),
                                 ("card1", gpu.PCI_VENDOR_AMD)])

    det = gpu.detect_gpu()
    assert det.vendor == "amd"


def test_priority_macos_skips_linux_probes(monkeypatch):
    """macOS Apple Silicon: don't run Linux probes (no /sys/class/drm).
    Return cpu directly. GPU work goes through host Ollama with Metal."""
    monkeypatch.setattr(gpu.platform, "system", lambda: "Darwin")

    det = gpu.detect_gpu()
    assert det.vendor == "cpu"
    assert "macOS" in " ".join(det.notes)


# ─────────────────── operator override path ─────────────────────────────


def test_force_vendor_on_mismatched_host_raises(monkeypatch):
    """Operator passed --gpu-vendor=nvidia on a CPU-only host.

    Per the silent-failure review (C2): the previous "silent fallback"
    behavior silently pulled a 5 GB :cuda image, started a container
    with no GPU passthrough, and let llama-cpp-python fall back to
    CPU — invisible to the operator until they wondered why inference
    was at 2 tok/s. We now raise GpuVendorMismatch so the deploy
    preflight surfaces a RED actionable error.
    """
    monkeypatch.setattr(gpu.shutil, "which", lambda _name: None)
    monkeypatch.setattr(gpu.platform, "system", lambda: "Linux")
    from pathlib import Path
    monkeypatch.setattr(Path, "exists", lambda self: False)
    monkeypatch.setattr(gpu, "_read_pci_vendors", lambda: [])

    with pytest.raises(gpu.GpuVendorMismatch) as exc_info:
        gpu.detect_for_vendor("nvidia")
    msg = str(exc_info.value)
    assert "--gpu-vendor=nvidia" in msg
    assert "nvidia-smi -L found no GPUs" in msg


def test_force_amd_on_mismatched_host_raises(monkeypatch):
    """Same C2 fix for the AMD path — must raise rather than silently
    pull the :rocm image without /dev/kfd passthrough."""
    monkeypatch.setattr(gpu.shutil, "which", lambda _name: None)
    monkeypatch.setattr(gpu.platform, "system", lambda: "Linux")
    from pathlib import Path
    monkeypatch.setattr(Path, "exists", lambda self: False)
    monkeypatch.setattr(gpu, "_read_pci_vendors", lambda: [])
    with pytest.raises(gpu.GpuVendorMismatch) as exc_info:
        gpu.detect_for_vendor("amd")
    assert "/dev/kfd" in str(exc_info.value)


def test_force_cpu_always_works(monkeypatch):
    """--gpu-vendor=cpu always succeeds — it's an explicit operator
    choice to run CPU-only even on a GPU host. No probe needed."""
    det = gpu.detect_for_vendor("cpu")
    assert det.vendor == "cpu"
    assert det.docker_args == []


# ─────────────────── image tag mapping ─────────────────────────────


@pytest.mark.parametrize("vendor,expected_variant", [
    ("nvidia", "cuda"),
    ("amd",    "rocm"),
    ("intel",  "sycl"),
    ("cpu",    "cpu"),
    # `proxy` is not a hardware vendor — it's the deployment shape
    # for nodes whose host already runs an Ollama / vLLM / etc.
    # The slim image (no llama-cpp-python bundled) lives at
    # ghcr.io/.../sirb-node:proxy-...
    ("proxy",  "proxy"),
])
def test_image_tag_for_maps_vendor_to_variant(vendor, expected_variant):
    """The detection labels (nvidia/amd/intel/cpu) map to the GHCR
    image variant tags (cuda/rocm/sycl/cpu). Locking this contract
    so a refactor of either name space surfaces here first."""
    tag = gpu.image_tag_for(vendor, "v0.20.0")
    assert tag == f"ghcr.io/ammarwa/sirb-node:{expected_variant}-v0.20.0"


def test_image_tag_for_uses_latest_by_default():
    assert gpu.image_tag_for("nvidia") == "ghcr.io/ammarwa/sirb-node:cuda-latest"
