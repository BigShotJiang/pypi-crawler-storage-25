"""CLI smoke tests.

We don't spin up a real backend — respx intercepts httpx calls and returns
canned responses. The goal is to assert the CLI parses output correctly
and shapes the right HTTP requests, not to re-test the backend.
"""

from __future__ import annotations

import json
import os
from pathlib import Path

import pytest
import respx
from httpx import Response
from typer.testing import CliRunner

from sirb_cli.config import CliConfig
from sirb_cli.main import app

runner = CliRunner()


@pytest.fixture(autouse=True)
def tmp_config(tmp_path: Path, monkeypatch):
    """Point the CLI's config at a tmp file so tests don't touch the real one."""
    monkeypatch.setenv("SIRB_CLI_CONFIG", str(tmp_path / "config.json"))
    # Pre-seed with a base_url + api_key so commands work without `login`.
    CliConfig(base_url="http://sirb.test", api_key="sirb_test", default_model="mock-7b").save()
    yield


def test_login_writes_config(tmp_path):
    """`sirb login` writes credentials into the active profile.

    The on-disk schema is profiles-nested ({"active": "...", "profiles":
    {"<name>": {api_key, base_url, default_model}}}). It was flat in v1
    and migrated to this nested shape when multi-profile support landed;
    the test was still asserting against the v1 shape and failing. We
    assert via the active-profile pointer so the test stays accurate
    even if the default profile name changes.
    """
    cfg_path = Path(os.environ["SIRB_CLI_CONFIG"])
    r = runner.invoke(app, ["login", "--api-key", "sirb_new", "--base-url", "https://example.com"])
    assert r.exit_code == 0, r.output
    saved = json.loads(cfg_path.read_text())
    active = saved["active"]
    profile = saved["profiles"][active]
    assert profile["api_key"] == "sirb_new"
    assert profile["base_url"] == "https://example.com"


@respx.mock
def test_models_calls_endpoint_and_renders():
    respx.get("http://sirb.test/v1/models").mock(
        return_value=Response(200, json={"object": "list", "data": [
            {"id": "mock-7b", "owned_by": "decentralized-community"},
        ]})
    )
    r = runner.invoke(app, ["models"])
    assert r.exit_code == 0, r.output
    assert "mock-7b" in r.output


@respx.mock
def test_chat_non_stream_prints_completion():
    respx.post("http://sirb.test/v1/chat/completions").mock(
        return_value=Response(200, json={
            "id": "x", "object": "chat.completion", "created": 0, "model": "mock-7b",
            "choices": [{"index": 0, "message": {"role": "assistant", "content": "pong"},
                         "finish_reason": "stop"}],
            "usage": {"prompt_tokens": 1, "completion_tokens": 1, "total_tokens": 2},
        })
    )
    r = runner.invoke(app, ["chat", "ping"])
    assert r.exit_code == 0, r.output
    assert "pong" in r.output


@respx.mock
def test_balance_unconfigured_renders_warning():
    respx.get("http://sirb.test/v1/balance").mock(
        return_value=Response(200, json={
            "object": "sirb.balance", "wallet": "0xtest",
            "balance": 0.0, "balance_wei": "0", "currency": "SIRB",
            "source": "unconfigured",
        })
    )
    r = runner.invoke(app, ["balance"])
    assert r.exit_code == 0, r.output
    assert "unavailable" in r.output.lower() or "no chain" in r.output.lower()


@respx.mock
def test_keys_create_renders_plaintext_warning():
    respx.post("http://sirb.test/admin/api-keys").mock(
        return_value=Response(201, json={
            "object": "sirb.api_key.created", "id": "key_abc",
            "key": "sirb_supersecret", "name": "demo",
            "wallet_address": "0xtest", "created_at": "2026-05-14T00:00:00Z",
            "rate_limit_per_minute": 60,
        })
    )
    r = runner.invoke(app, ["keys", "create", "--name", "demo"])
    assert r.exit_code == 0, r.output
    assert "sirb_supersecret" in r.output
    assert "only time" in r.output.lower()


@respx.mock
def test_keys_revoke_calls_delete():
    route = respx.delete("http://sirb.test/admin/api-keys/key_abc").mock(
        return_value=Response(204)
    )
    r = runner.invoke(app, ["keys", "revoke", "key_abc"])
    assert r.exit_code == 0, r.output
    assert route.called


def test_opencode_env_prints_export_lines():
    r = runner.invoke(app, ["opencode", "env"])
    assert r.exit_code == 0, r.output
    assert 'export OPENAI_API_KEY="sirb_test"' in r.output
    assert 'export OPENAI_BASE_URL="http://sirb.test/v1"' in r.output


def test_opencode_config_prints_json():
    r = runner.invoke(app, ["opencode", "config"])
    assert r.exit_code == 0, r.output
    parsed = json.loads(r.output)
    assert parsed["provider"] == "openai-compatible"
    assert parsed["baseURL"] == "http://sirb.test/v1"
    assert parsed["apiKey"] == "sirb_test"


@respx.mock
def test_status_all_green_exits_zero():
    """Status command should hit healthz/readyz/balance/models/nodes and
    render a green row for each. Exit code 0 when nothing failed."""
    respx.get("http://sirb.test/healthz").mock(return_value=Response(200, json={"status": "ok"}))
    respx.get("http://sirb.test/readyz").mock(return_value=Response(200, json={"db": {"ok": True}, "chain": {"skipped": True}}))
    respx.get("http://sirb.test/v1/balance").mock(return_value=Response(200, json={
        "wallet": "0xtest", "balance": 1.5, "balance_wei": "1500000000000000000",
        "currency": "SIRB", "source": "chain",
    }))
    respx.get("http://sirb.test/v1/models").mock(return_value=Response(200, json={
        "object": "list", "data": [{"id": "mock-7b", "owned_by": "x"}],
    }))
    respx.get("http://sirb.test/nodes").mock(return_value=Response(200, json=[
        {"node_id": "n1", "status": "online"},
        {"node_id": "n2", "status": "offline"},
    ]))
    r = runner.invoke(app, ["status"])
    assert r.exit_code == 0, r.output
    # Spot-check the table contains each check's output
    assert "Gateway" in r.output
    assert "Readiness" in r.output
    assert "Auth" in r.output
    assert "1 online / 2 registered" in r.output
    assert "mock-7b" in r.output


@respx.mock
def test_status_gateway_unreachable_exits_nonzero():
    """If /healthz can't be reached, exit code should be 1 so shell
    scripts (`sirb status && deploy`) short-circuit cleanly. respx
    raises AllMockedAssertionError for unmocked URLs, so we have to
    mock every endpoint the command probes (the later probes still get
    rendered but don't change the fail outcome)."""
    import httpx
    respx.get("http://sirb.test/healthz").mock(side_effect=httpx.ConnectError("nope"))
    respx.get("http://sirb.test/readyz").mock(side_effect=httpx.ConnectError("nope"))
    respx.get("http://sirb.test/v1/balance").mock(side_effect=httpx.ConnectError("nope"))
    respx.get("http://sirb.test/v1/models").mock(side_effect=httpx.ConnectError("nope"))
    respx.get("http://sirb.test/nodes").mock(side_effect=httpx.ConnectError("nope"))
    r = runner.invoke(app, ["status"])
    assert r.exit_code == 1, r.output
    assert "fail" in r.output.lower() or "ConnectError" in r.output


@respx.mock
def test_observations_bare_runs_list():
    """Bare `sirb observations` (no subcommand) should default to the
    list view, not show help. Without this default, the unfriendly
    no-args-is-help behavior left users dead-ended on `sirb observations`."""
    respx.get("http://sirb.test/admin/observations").mock(
        return_value=Response(200, json={"object": "list", "data": [
            {"id": "obs_1", "kind": "monitoring", "outcome": "ok",
             "provider": "sirb", "summary": "all green", "findings": []},
        ]})
    )
    r = runner.invoke(app, ["observations"])
    assert r.exit_code == 0, r.output
    # The table doesn't render the id column (id is part of `show`),
    # but kind + outcome + summary are visible enough to confirm the
    # list defaulted as intended.
    assert "monitoring" in r.output
    assert "all green" in r.output


@respx.mock
def test_observations_show_fetches_single():
    """`sirb observations show <id>` hits the singular endpoint and
    renders the findings section."""
    respx.get("http://sirb.test/admin/observations/obs_42").mock(
        return_value=Response(200, json={
            "id": "obs_42", "kind": "fraud_detection", "outcome": "ok",
            "provider": "sirb", "summary": "two suspect nodes",
            "findings": [
                {"severity": "warning", "category": "low_pass_rate",
                 "target": "0xnode_a", "detail": "0.41 over window=200"},
            ],
        })
    )
    r = runner.invoke(app, ["observations", "show", "obs_42"])
    assert r.exit_code == 0, r.output
    assert "obs_42" in r.output
    assert "two suspect nodes" in r.output
    assert "warning" in r.output


@respx.mock
def test_observations_all_dry_run_shows_hint():
    """When every recent observation is dry_run, the user should see the
    'how to enable real runs' footer — otherwise they think the agents
    are broken."""
    respx.get("http://sirb.test/admin/observations").mock(
        return_value=Response(200, json={"object": "list", "data": [
            {"id": "o1", "kind": "monitoring", "outcome": "dry_run", "provider": "none", "summary": None, "findings": []},
            {"id": "o2", "kind": "monitoring", "outcome": "dry_run", "provider": "none", "summary": None, "findings": []},
        ]})
    )
    r = runner.invoke(app, ["observations"])
    assert r.exit_code == 0, r.output
    assert "dry_run" in r.output.lower()
    assert "SIRB_MONITORING_ENABLED" in r.output


@respx.mock
def test_observations_403_renders_admin_scope_message():
    """Non-admin key → backend returns 403 admin_scope_required.
    The CLI catches that and prints a clean one-line message instead
    of leaking an HTTPStatusError traceback. Exit code 1 so shell
    scripts can branch."""
    respx.get("http://sirb.test/admin/observations").mock(
        return_value=Response(403, json={"detail": {"error": {
            "code": "admin_scope_required",
            "type": "permission_error",
            "message": "this endpoint requires an admin-scoped API key",
        }}})
    )
    r = runner.invoke(app, ["observations"])
    assert r.exit_code == 1, r.output
    assert "admin scope required" in r.output.lower()
    # Operator-only guidance must NOT appear for non-admin users —
    # they can't act on it and it leaks gateway-tuning intent.
    assert "SIRB_MONITORING_ENABLED" not in r.output
    assert "fly secrets set" not in r.output


@respx.mock
def test_observations_show_admin_only():
    """Same gating on `show` subcommand."""
    respx.get("http://sirb.test/admin/observations/obs_x").mock(
        return_value=Response(403, json={"detail": {"error": {
            "code": "admin_scope_required",
            "message": "needs admin",
        }}})
    )
    r = runner.invoke(app, ["observations", "show", "obs_x"])
    assert r.exit_code == 1, r.output
    assert "admin scope required" in r.output.lower()


@respx.mock
def test_observations_run_admin_only():
    """Same gating on `run` subcommand."""
    respx.post("http://sirb.test/admin/observations/run").mock(
        return_value=Response(403, json={"detail": {"error": {
            "code": "admin_scope_required",
            "message": "needs admin",
        }}})
    )
    r = runner.invoke(app, ["observations", "run", "--kind", "monitoring"])
    assert r.exit_code == 1, r.output
    assert "admin scope required" in r.output.lower()


def test_deploy_help_lists_node_and_gateway():
    """Just confirm both deploy subcommands are wired up."""
    r = runner.invoke(app, ["deploy", "--help"])
    assert r.exit_code == 0, r.output
    assert "node" in r.output
    assert "gateway" in r.output


def test_wallet_new_no_save_prints_address(tmp_path, monkeypatch):
    """`sirb wallet new --no-save` should print a 0x + 40-hex address.

    Auto-bind is skipped because we can't safely hit the real network
    in this smoke test; we set --no-bind. Asserting both the address
    pattern and the private-key reveal — they MUST coexist when
    nothing is saved, so the user can copy them before the process
    ends.
    """
    monkeypatch.setenv("HOME", str(tmp_path))
    r = runner.invoke(app, ["wallet", "new", "--no-save", "--no-bind"])
    assert r.exit_code == 0, r.output
    import re
    m = re.search(r"0x[a-fA-F0-9]{40}", r.output)
    assert m, f"no wallet address in output: {r.output}"
    # The new default generates a real Eth keypair — the reveal must
    # include the private key when nothing's saved to disk.
    assert "private key" in r.output.lower()
    pk = re.search(r"0x[a-fA-F0-9]{64}", r.output)
    assert pk, f"no private key revealed in --no-save output: {r.output}"


def test_wallet_new_legacy_emits_no_private_key(tmp_path, monkeypatch):
    """`--legacy` is the pre-0.8 escape hatch — produces a random
    off-chain identifier with NO private key. Pin that the new
    keypair-generation path doesn't accidentally fire when a user
    explicitly opts out."""
    monkeypatch.setenv("HOME", str(tmp_path))
    r = runner.invoke(app, ["wallet", "new", "--no-save", "--legacy", "--no-bind"])
    assert r.exit_code == 0, r.output
    import re
    assert re.search(r"0x[a-fA-F0-9]{40}", r.output), r.output
    # CRITICAL: no private key surfaced on the legacy path. A regression
    # here could quietly leak a key the user didn't ask for. The literal
    # 64-hex string is the canary — the word "private key" appears in
    # legitimate copy ("no private key, cannot claim rewards") that
    # we don't want to false-positive on.
    pk = re.search(r"0x[a-fA-F0-9]{64}", r.output)
    assert pk is None, f"legacy path leaked a 64-hex private key: {r.output}"
    # No "private key:" label either (the value-reveal pattern).
    assert "private key:" not in r.output.lower(), r.output


def test_wallet_new_persists_keypair_to_disk(tmp_path, monkeypatch):
    """The real-keypair path writes both ``address`` and
    ``private_key`` to ~/.sirb/wallet.json. File mode is 0600 so
    other users on the box can't read the key."""
    monkeypatch.setenv("HOME", str(tmp_path))
    r = runner.invoke(app, ["wallet", "new", "--no-bind"])
    assert r.exit_code == 0, r.output
    wpath = tmp_path / ".sirb" / "wallet.json"
    assert wpath.exists(), f"wallet file not created at {wpath}"
    data = json.loads(wpath.read_text())
    assert data.get("kind") == "eth"
    assert data.get("address", "").startswith("0x")
    assert data.get("private_key", "").startswith("0x")
    assert len(data["private_key"]) == 66  # 0x + 64 hex chars
    # Mode 0600 on Unix; Windows doesn't enforce so we only check
    # when we can read the bits.
    if os.name == "posix":
        mode = wpath.stat().st_mode & 0o777
        assert mode == 0o600, f"wallet file is {oct(mode)}, expected 0o600"


@respx.mock
def test_wallet_new_auto_binds_claim_address_when_logged_in(tmp_path, monkeypatch):
    """The headline UX win: when the user is already logged in,
    generating a wallet auto-binds the address as their
    claim_address via PUT /v1/wallet/claim-address. The trial-mint
    outcome from the gateway response surfaces in the CLI output
    so the user can see whether their bonus actually fired."""
    monkeypatch.setenv("HOME", str(tmp_path))
    route = respx.put("http://sirb.test/v1/wallet/claim-address").mock(
        return_value=Response(200, json={
            "object": "sirb.claim_address",
            "wallet_address": "0xops_x",
            "claim_address": "0x" + "ab" * 20,
            "trial_granted": True,
            "trial_mint": "minted",
        })
    )
    r = runner.invoke(app, ["wallet", "new"])
    assert r.exit_code == 0, r.output
    assert route.called, "did not call PUT /v1/wallet/claim-address"
    # The body sent to the gateway must use the generated address,
    # not some hardcoded value.
    sent = json.loads(route.calls.last.request.content)
    assert sent["claim_address"].startswith("0x")
    assert len(sent["claim_address"]) == 42
    # Surface to the user: explicit success + the trial-mint outcome.
    assert "bound as claim_address" in r.output
    assert "trial allowance minted" in r.output.lower()


def test_wallet_new_no_bind_skips_gateway_call(tmp_path, monkeypatch):
    """--no-bind preserves the offline workflow: generate a keypair
    locally without contacting the gateway. Useful for setting up
    a wallet ahead of `sirb login`."""
    monkeypatch.setenv("HOME", str(tmp_path))
    # No respx mock — if the CLI tries to hit the gateway, respx's
    # passthrough rejection turns it into a transport error and
    # _try_bind_claim_address's broad except masks it. The
    # absence of a "bound as claim_address" line in the output is
    # the actual signal we care about.
    r = runner.invoke(app, ["wallet", "new", "--no-bind"])
    assert r.exit_code == 0, r.output
    assert "bound as claim_address" not in r.output


def test_wallet_new_handles_no_api_key_gracefully(tmp_path, monkeypatch):
    """If no API key is configured, the auto-bind silently no-ops
    and the user gets a clear hint to run ``sirb login`` first.
    The wallet is still generated and saved — losing the local
    keypair just because the user isn't logged in yet would be
    a frustrating surprise."""
    monkeypatch.setenv("HOME", str(tmp_path))
    # Clear the seeded api_key so the auto-bind has no credentials.
    CliConfig(base_url="http://sirb.test", api_key=None, default_model="mock-7b").save()
    r = runner.invoke(app, ["wallet", "new"])
    assert r.exit_code == 0, r.output
    # Wallet was still generated + saved.
    assert (tmp_path / ".sirb" / "wallet.json").exists()
    # User gets a clear next-step hint.
    assert "sirb login" in r.output


@respx.mock
def test_wallet_new_surfaces_gateway_4xx_with_structured_code(tmp_path, monkeypatch):
    """The pre-fix code swallowed every gateway error into a generic
    'gateway unreachable' hint. The reviewer-flagged silent failure:
    a clean 400 with code=dev_key_unsupported looked identical to a
    network outage. After the fix the user sees the actual code and
    a code-specific remediation."""
    monkeypatch.setenv("HOME", str(tmp_path))
    respx.put("http://sirb.test/v1/wallet/claim-address").mock(
        return_value=Response(400, json={"detail": {"error": {
            "code": "dev_key_unsupported",
            "type": "invalid_request_error",
            "message": "claim_address can only be set on DB-issued API keys",
        }}}),
    )
    r = runner.invoke(app, ["wallet", "new"])
    assert r.exit_code == 0, r.output
    # Wallet was still saved — gateway failure is recoverable.
    assert (tmp_path / ".sirb" / "wallet.json").exists()
    # CRITICAL: the actual gateway code must surface, NOT the
    # generic "network / unreachable" hint that masked it pre-fix.
    assert "dev_key_unsupported" in r.output
    # The code-specific remediation kicks in for dev_key_unsupported.
    assert "sirb keys create" in r.output


def test_wallet_new_force_backs_up_existing_keypair(tmp_path, monkeypatch):
    """--force used to silently clobber a real keypair — an
    irrecoverable finger-slip vector since losing the private key
    means losing on-chain SIRB. Post-fix: existing real keypairs
    are renamed to ``wallet.json.bak.<timestamp>`` before the new
    one lands."""
    monkeypatch.setenv("HOME", str(tmp_path))
    # First run creates a keypair.
    r1 = runner.invoke(app, ["wallet", "new", "--no-bind"])
    assert r1.exit_code == 0
    wfile = tmp_path / ".sirb" / "wallet.json"
    assert wfile.exists()
    original = json.loads(wfile.read_text())
    assert original.get("private_key")

    # Force-overwrite. Must NOT destroy the original keypair —
    # it should be safely renamed.
    r2 = runner.invoke(app, ["wallet", "new", "--force", "--no-bind"])
    assert r2.exit_code == 0, r2.output
    # New file is a different keypair.
    new = json.loads(wfile.read_text())
    assert new["address"] != original["address"]
    # Old keypair survives as a backup.
    backups = list((tmp_path / ".sirb").glob("wallet.json.bak.*"))
    assert backups, f"no backup created in {tmp_path / '.sirb'}"
    backed_up = json.loads(backups[0].read_text())
    assert backed_up["address"] == original["address"]
    assert backed_up["private_key"] == original["private_key"]
    # User saw a heads-up about the backup.
    assert "backing up existing keypair" in r2.output


def test_wallet_new_uses_atomic_mode_600_creation(tmp_path, monkeypatch):
    """The wallet file must be created with mode 0600 at the inode
    level — NOT created at default umask and then chmod'd, which
    leaves a race window where a co-tenant could read the private
    key. This is the file-mode-race the reviewer caught as CRITICAL
    (95% confidence): `Path.write_text()` honors umask (usually 0644
    on Linux); the atomic O_EXCL+mode-600 path closes the window.
    The check below pins the achieved-mode invariant; the actual
    atomicity is enforced by ``os.open`` in ``eth_wallet.py``."""
    monkeypatch.setenv("HOME", str(tmp_path))
    # Hostile umask: simulate the worst-case Linux default where
    # files would otherwise be created 0644.
    original_umask = os.umask(0o022)
    try:
        r = runner.invoke(app, ["wallet", "new", "--no-bind"])
        assert r.exit_code == 0, r.output
        wfile = tmp_path / ".sirb" / "wallet.json"
        assert wfile.exists()
        if os.name == "posix":
            mode = wfile.stat().st_mode & 0o777
            assert mode == 0o600, (
                f"wallet file is {oct(mode)}, expected 0o600 "
                "(umask race may have re-opened — check eth_wallet.write_wallet_file_atomic)"
            )
    finally:
        os.umask(original_umask)


@respx.mock
def test_wallet_new_surfaces_network_failure_distinctly(tmp_path, monkeypatch):
    """A network error must surface as a network error — not as the
    pre-fix generic 'gateway unreachable' message that conflated it
    with auth failure, missing DB, dev-key bugs, etc."""
    monkeypatch.setenv("HOME", str(tmp_path))
    import httpx
    respx.put("http://sirb.test/v1/wallet/claim-address").mock(
        side_effect=httpx.ConnectError("connection refused"),
    )
    r = runner.invoke(app, ["wallet", "new"])
    assert r.exit_code == 0, r.output
    assert (tmp_path / ".sirb" / "wallet.json").exists()
    # User sees the actual exception class — actionable for debugging
    # (DNS? firewall? wrong gateway URL?).
    assert "ConnectError" in r.output or "network error" in r.output.lower()


def test_signing_secret_new_show_prints_hex_only():
    """`sirb signing-secret new --show` should print only the hex value,
    pipe-friendly. 32 bytes default = 64 hex chars."""
    r = runner.invoke(app, ["signing-secret", "new", "--show"])
    assert r.exit_code == 0, r.output
    line = r.output.strip()
    # Exactly 64 lowercase hex chars
    import re
    assert re.fullmatch(r"[a-f0-9]{64}", line), f"unexpected output: {line!r}"


def test_signing_secret_new_default_includes_hints():
    """Without --show, the command should print the secret PLUS the
    operator-facing setup hints (fly secrets set / sirb deploy node)."""
    r = runner.invoke(app, ["signing-secret", "new"])
    assert r.exit_code == 0, r.output
    assert "fly secrets set" in r.output
    assert "sirb deploy node" in r.output


def test_deploy_node_help_shows_no_sharding_default():
    """The --no-sharding flag must show as the DEFAULT in --help so
    contributors see at a glance that they're opted-out by default."""
    r = runner.invoke(app, ["deploy", "node", "--help"])
    assert r.exit_code == 0, r.output
    assert "--no-sharding" in r.output
    assert "--allow-sharding" in r.output


def test_deploy_gateway_print_mode():
    """`--print` should emit the deploy script without trying to run it,
    so users can review what gets executed before saying yes. We point
    at a fake backend dir to satisfy the fly.toml existence check."""
    import os
    from pathlib import Path
    repo = Path(os.environ.get("TMPDIR", "/tmp")) / "sirb-deploy-test"
    (repo / "backend").mkdir(parents=True, exist_ok=True)
    (repo / "backend" / "fly.toml").write_text("# fake\n")
    cwd = os.getcwd()
    os.chdir(repo)
    try:
        r = runner.invoke(app, ["deploy", "gateway", "--app-name", "sirb-test",
                                 "--region", "iad", "--print"])
        assert r.exit_code == 0, r.output
        assert "fly apps create" in r.output
        assert "sirb-test" in r.output
        assert "openssl rand -hex 32" in r.output
        assert "alembic upgrade head" in r.output
        # Confirm we didn't accidentally invoke flyctl
        assert "Connecting to" not in r.output
    finally:
        os.chdir(cwd)


def test_status_warns_when_no_api_key(monkeypatch):
    """No key configured → Config + Auth show warn, but exit 0 (the
    user might just be browsing models, which doesn't need auth)."""
    # Wipe the api_key out of the seeded config
    CliConfig(base_url="http://sirb.test", api_key=None, default_model="mock-7b").save()
    # Mock the unauthed endpoints so we don't time out
    with respx.mock() as mock:
        mock.get("http://sirb.test/healthz").mock(return_value=Response(200, json={"status": "ok"}))
        mock.get("http://sirb.test/readyz").mock(return_value=Response(200, json={"db": {"ok": True}}))
        mock.get("http://sirb.test/v1/models").mock(return_value=Response(200, json={"object": "list", "data": []}))
        mock.get("http://sirb.test/nodes").mock(return_value=Response(200, json=[]))
        r = runner.invoke(app, ["status"])
    assert r.exit_code == 0, r.output
    assert "no api key" in r.output.lower()
