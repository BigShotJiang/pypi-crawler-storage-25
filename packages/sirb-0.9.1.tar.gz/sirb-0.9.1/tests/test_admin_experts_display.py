"""Phase 10C M7 — display logic for Node.expert_assignments in
`sirb admin nodes ls`. The helper is small + pure; test covers the
display heuristics so a future format tweak can't silently change
what operators see."""

from __future__ import annotations

from sirb_cli.commands.admin import _fmt_expert_assignments


def test_none_renders_dim_dash():
    """Legacy / non-MoE nodes have no assignments — show '—'."""
    assert _fmt_expert_assignments(None) == "[dim]—[/dim]"


def test_empty_dict_renders_dim_dash():
    assert _fmt_expert_assignments({}) == "[dim]—[/dim]"


def test_small_assignment_shows_full_list():
    """≤5 experts → show all of them so operators see exact ids."""
    got = _fmt_expert_assignments({"deepseek-v4-pro": [0, 1, 2]})
    assert got == "deepseek-v4-pro:[0,1,2]"


def test_large_assignment_truncates_with_more_marker():
    """>5 experts → show first 3 + '+N' so the column stays narrow
    even for DeepSeek-V2-Lite style 64-expert deployments."""
    got = _fmt_expert_assignments({"big-moe": list(range(20))})
    assert got == "big-moe:[0,1,2…+17]"


def test_multiple_models_separated_by_double_space():
    got = _fmt_expert_assignments({
        "model-a": [0, 1],
        "model-b": [5, 6, 7],
    })
    # Sorted by model name + double-space separator for readability.
    assert got == "model-a:[0,1]  model-b:[5,6,7]"


def test_empty_list_under_model_id_is_skipped():
    """A node that registered with `{"some-model": []}` is technically
    valid (degenerate) but the display should hide it. Otherwise we'd
    show 'some-model:[]' which is just noise."""
    got = _fmt_expert_assignments({"some-model": []})
    assert got == "[dim]—[/dim]"


def test_sorted_within_model_id():
    """Display order is sorted ascending so two scrapes of the same
    state produce the same column content."""
    got = _fmt_expert_assignments({"m": [42, 5, 17, 1]})
    assert got == "m:[1,5,17,42]"
