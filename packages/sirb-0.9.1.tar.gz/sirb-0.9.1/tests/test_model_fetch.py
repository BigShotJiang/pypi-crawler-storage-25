"""Tests for `sirb_cli.model_fetch` — HF reference parsing + path
resolution. The actual download is exercised in M8 of Phase 10C
(end-to-end with a real model); these unit tests cover the parsing
and resolution logic only.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from sirb_cli.model_fetch import (
    HfModelRef,
    _local_cache_path,
    autodiscover_quant,
    fetch_expert_shards,
    is_bare_hf_repo,
    parse_bare_hf_repo,
    parse_hf_ref,
)


# ────────────────────────── parse_hf_ref ────────────────────────────────


class TestParseHfRef:
    def test_with_hf_co_prefix_and_quant(self):
        ref = parse_hf_ref("hf.co/bartowski/Qwen2.5-0.5B-Instruct-GGUF:Q4_K_M")
        assert ref == HfModelRef(
            repo_id="bartowski/Qwen2.5-0.5B-Instruct-GGUF",
            quant="Q4_K_M",
            explicit_filename=None,
        )

    def test_no_prefix_and_quant(self):
        ref = parse_hf_ref("bartowski/Qwen2.5-0.5B-Instruct-GGUF:Q4_K_M")
        assert ref is not None
        assert ref.repo_id == "bartowski/Qwen2.5-0.5B-Instruct-GGUF"
        assert ref.quant == "Q4_K_M"
        assert ref.explicit_filename is None

    def test_explicit_filename(self):
        ref = parse_hf_ref(
            "hf.co/bartowski/Qwen2.5-0.5B-Instruct-GGUF/Qwen2.5-0.5B-Instruct-Q4_K_M.gguf"
        )
        assert ref is not None
        assert ref.repo_id == "bartowski/Qwen2.5-0.5B-Instruct-GGUF"
        assert ref.quant is None
        assert ref.explicit_filename == "Qwen2.5-0.5B-Instruct-Q4_K_M.gguf"

    @pytest.mark.parametrize("model_id", [
        # Ollama-only short tags — no owner.
        "gemma2:2b",
        "qwen2.5:0.5b",
        # Local-only model ids — caller falls back to --llama-model-path.
        "mock-7b",
        "my-custom-model",
        # Junk
        "",
        ":Q4_K_M",
        "/Q4_K_M",
        "owner/",
    ])
    def test_non_hf_refs_return_none(self, model_id):
        """Anything that doesn't look like a HF reference returns None
        so the deploy flow can fall back to the manual path."""
        assert parse_hf_ref(model_id) is None

    @pytest.mark.parametrize("malicious", [
        # Path-traversal in the explicit-file form.
        "hf.co/owner/repo/../../../etc/passwd.gguf",
        "hf.co/owner/repo/sub/../escape.gguf",
        "owner/repo/../escape.gguf",
        # `..` as owner or repo name.
        "hf.co/../etc/repo.gguf",
        "hf.co/owner/../etc.gguf",
        "../bad/repo:Q4_K_M",
        "owner/..:Q4_K_M",
        # Absolute paths in the file segment.
        "hf.co/owner/repo//etc/passwd.gguf",
        # Backslash variants (Windows-style traversal).
        "hf.co/owner/repo/..\\escape.gguf",
    ])
    def test_path_traversal_inputs_return_none(self, malicious):
        """Any input that contains a `..` or absolute-path segment
        is rejected by parse_hf_ref — this stops fetch_model from
        ever writing outside the configured models root. Regression
        test for the bug fixed in 0.6.0 before ship.
        """
        assert parse_hf_ref(malicious) is None, (
            f"path-traversal input {malicious!r} was accepted — "
            "fetch_model would write outside ~/.sirb/models/"
        )

    def test_hf_co_prefix_with_file_path(self):
        """Explicit-file form with hf.co prefix."""
        ref = parse_hf_ref(
            "hf.co/TheBloke/Mistral-7B-v0.1-GGUF/mistral-7b-v0.1.Q4_K_M.gguf"
        )
        assert ref is not None
        assert ref.repo_id == "TheBloke/Mistral-7B-v0.1-GGUF"
        assert ref.explicit_filename == "mistral-7b-v0.1.Q4_K_M.gguf"

    def test_quant_with_underscores_and_digits(self):
        """Real-world quant naming uses underscores and digits."""
        for quant in ["Q4_K_M", "Q5_K_S", "Q8_0", "IQ3_XXS", "F16"]:
            ref = parse_hf_ref(f"owner/repo:{quant}")
            assert ref is not None, f"failed to parse :{quant}"
            assert ref.quant == quant


# ─────────────────────── _local_cache_path ──────────────────────────────


class TestLocalCachePath:
    def test_path_mirrors_repo_id_with_double_underscore(self, tmp_path, monkeypatch):
        """The cache path encodes `/` in the repo_id as `__` so the
        filesystem layout is operator-readable without nested dirs."""
        monkeypatch.setenv("SIRB_MODELS_DIR", str(tmp_path))
        ref = HfModelRef(
            repo_id="bartowski/Qwen2.5-0.5B-Instruct-GGUF",
            quant="Q4_K_M",
            explicit_filename=None,
        )
        p = _local_cache_path(ref, "Qwen2.5-0.5B-Instruct-Q4_K_M.gguf")
        assert p == tmp_path / "bartowski__Qwen2.5-0.5B-Instruct-GGUF" / "Qwen2.5-0.5B-Instruct-Q4_K_M.gguf"

    def test_models_dir_env_override(self, tmp_path, monkeypatch):
        """$SIRB_MODELS_DIR overrides the default ~/.sirb/models/."""
        custom = tmp_path / "custom_models"
        monkeypatch.setenv("SIRB_MODELS_DIR", str(custom))
        ref = HfModelRef(repo_id="owner/repo", quant="Q4_K_M", explicit_filename=None)
        p = _local_cache_path(ref, "model.gguf")
        # Should be inside the custom dir, not under ~/.sirb/.
        assert str(p).startswith(str(custom))


# ──────────────────────── fetch_expert_shards ───────────────────────────


def test_fetch_expert_shards_is_a_placeholder():
    """Phase 10C M3 will implement this. Today it raises so we know
    if anything is calling it prematurely."""
    with pytest.raises(NotImplementedError, match="Phase 10C M3"):
        fetch_expert_shards("hf.co/owner/repo:Q4_K_M", expert_ids=[0, 1])


class TestIsBareHfRepo:
    """The user-reported bug: `hf.co/google/gemma-4-31B-it` IS a valid
    HuggingFace reference (bare owner/repo, the form vLLM consumes
    directly) but isn't a GGUF reference. Pre-fix, the llama-cpp
    preflight told the operator it 'isn't a HuggingFace reference' —
    misleading. is_bare_hf_repo identifies this specific shape so
    the operator gets a precise hint instead.
    """

    @pytest.mark.parametrize("model_id", [
        "hf.co/google/gemma-4-31B-it",
        "google/gemma-4-31B-it",
        "hf.co/meta-llama/Llama-3.1-8B-Instruct",
        "meta-llama/Llama-3.1-8B-Instruct",
        "hf.co/Qwen/Qwen2.5-0.5B",
    ])
    def test_bare_hf_repo_detected(self, model_id):
        assert is_bare_hf_repo(model_id) is True

    @pytest.mark.parametrize("model_id", [
        # Already a usable GGUF reference — not bare.
        "hf.co/bartowski/Qwen2.5-0.5B-Instruct-GGUF:Q4_K_M",
        "hf.co/bartowski/Qwen2.5-0.5B-Instruct-GGUF/Qwen2.5-0.5B-Instruct-Q4_K_M.gguf",
        # Not a HF reference at all.
        "gemma2:2b",
        "mock-7b",
        "",
        # Path-traversal — must NOT be flagged as a bare HF repo
        # (would have leaked to the better-error path with an
        # attacker-supplied repo name).
        "hf.co/../etc/passwd",
        "hf.co/owner/..",
    ])
    def test_non_bare_or_unsafe_inputs_return_false(self, model_id):
        assert is_bare_hf_repo(model_id) is False

    def test_parse_bare_returns_canonical_repo_id(self):
        """parse_bare_hf_repo strips the optional `hf.co/` prefix and
        returns just `owner/repo` — what the HF API expects."""
        assert parse_bare_hf_repo("hf.co/unsloth/DeepSeek-R1-Distill-Llama-70B-GGUF") == (
            "unsloth/DeepSeek-R1-Distill-Llama-70B-GGUF"
        )
        assert parse_bare_hf_repo("google/gemma-4-31B-it") == "google/gemma-4-31B-it"
        assert parse_bare_hf_repo("not-a-ref") is None


class TestAutodiscoverQuant:
    """The user-reported bug #2: passing `hf.co/unsloth/...-GGUF` (no
    quant) used to be rejected. autodiscover_quant picks a sensible
    default from the repo's actual .gguf files when no quant is
    specified. Q4_K_M preferred; falls down the preference list when
    not available; returns None when the repo isn't a GGUF repo at all.
    """

    def test_picks_q4_k_m_when_available(self, monkeypatch):
        import huggingface_hub  # type: ignore
        monkeypatch.setattr(
            huggingface_hub, "list_repo_files",
            lambda repo_id: [
                "model.Q4_K_M.gguf",
                "model.Q5_K_M.gguf",
                "model.Q8_0.gguf",
                "README.md",
            ],
        )
        assert autodiscover_quant("unsloth/some-repo-GGUF") == "Q4_K_M"

    def test_falls_back_to_next_preferred(self, monkeypatch):
        """Repo has GGUFs but not Q4_K_M — pick the next in the
        preference list."""
        import huggingface_hub  # type: ignore
        monkeypatch.setattr(
            huggingface_hub, "list_repo_files",
            lambda repo_id: ["model.Q5_K_M.gguf", "model.Q8_0.gguf"],
        )
        assert autodiscover_quant("owner/repo-GGUF") == "Q5_K_M"

    def test_returns_none_when_no_gguf_files(self, monkeypatch):
        """The `google/gemma-4-31B-it` case — repo exists, no GGUFs
        published (operator would need to use vLLM or a re-quant)."""
        import huggingface_hub  # type: ignore
        monkeypatch.setattr(
            huggingface_hub, "list_repo_files",
            lambda repo_id: [
                "config.json", "model.safetensors", "tokenizer.json",
            ],
        )
        assert autodiscover_quant("google/gemma-4-31B-it") is None

    def test_returns_none_when_only_unknown_quants(self, monkeypatch):
        """Repo has GGUFs but none of them match our preference order
        (some experimental quant set) AND the repo name has no quant
        token. Return None so the caller can surface available files
        for manual pick rather than guess wrong."""
        import huggingface_hub  # type: ignore
        monkeypatch.setattr(
            huggingface_hub, "list_repo_files",
            lambda repo_id: [
                "model.NF4.gguf",  # nonstandard
                "model.AWQ.gguf",
            ],
        )
        assert autodiscover_quant("owner/repo") is None

    def test_repo_name_fallback_when_filenames_lack_quants(self, monkeypatch):
        """Pass 2 of autodiscover_quant: single-quant repos with a
        generic `model.gguf` filename. The quant lives in the repo
        name (e.g. `unsloth/Llama-Q4_K_M-GGUF` containing only
        `model.gguf`)."""
        import huggingface_hub  # type: ignore
        monkeypatch.setattr(
            huggingface_hub, "list_repo_files",
            lambda repo_id: ["model.gguf", "README.md"],
        )
        # Generic filename → no filename match. Repo name has Q5_K_M
        # → that's what we pick.
        assert autodiscover_quant("unsloth/Llama-Q5_K_M-GGUF") == "Q5_K_M"

    def test_filename_pass_wins_when_both_match(self, monkeypatch):
        """When BOTH the filename and the repo name carry a quant,
        the filename pass wins — the actual file we download is the
        source of truth."""
        import huggingface_hub  # type: ignore
        monkeypatch.setattr(
            huggingface_hub, "list_repo_files",
            lambda repo_id: ["model.Q4_K_M.gguf"],
        )
        # Repo name says Q8_0; filename says Q4_K_M. Filename wins.
        assert autodiscover_quant("owner/Foo-Q8_0-GGUF") == "Q4_K_M"

    def test_owner_quant_token_does_not_leak(self, monkeypatch):
        """Sanity: only the repo segment (not the owner) is checked
        for a quant token. An owner literally named `Q4_K_M` would
        otherwise cause false-positive picks."""
        import huggingface_hub  # type: ignore
        monkeypatch.setattr(
            huggingface_hub, "list_repo_files",
            lambda repo_id: ["model.gguf"],
        )
        # Pathological owner name — repo name has no quant token, so
        # nothing should be picked.
        assert autodiscover_quant("Q4_K_M/SomeRepo") is None


# ───────────────────── word-bounded quant matching ──────────────────────


class TestQuantMatching:
    """The 0.6.0 pre-merge reviewer flagged that `quant in filename`
    matches "Q4" against "Q4_0", "Q4_K_M", "IQ4_XS" etc., so an
    operator asking for :Q4_K_M would silently get a different file.
    These tests pin the fix: word-bounded matching + explicit warn
    when multiple files still match.
    """

    @pytest.fixture(autouse=True)
    def _patch_list_files(self, monkeypatch):
        """Stub huggingface_hub.list_repo_files with a known set."""
        files = [
            "model.Q4_0.gguf",
            "model.Q4_K_M.gguf",
            "model.IQ4_XS.gguf",
            "model.Q5_K_M.gguf",
            "model.Q8_0.gguf",
            "model.f16.gguf",
            "README.md",
            "config.json",
        ]
        # Patch the symbol the way _pick_gguf_filename imports it.
        import huggingface_hub  # type: ignore
        monkeypatch.setattr(
            huggingface_hub, "list_repo_files", lambda repo_id: files,
        )

    def test_q4_only_matches_q4_not_q4_k_m(self):
        """`:Q4` must NOT match `Q4_K_M` or `IQ4_XS` — word-bounded."""
        from sirb_cli.model_fetch import _pick_gguf_filename
        picked = _pick_gguf_filename("owner/repo", "Q4")
        assert picked == "model.Q4_0.gguf", picked

    def test_q4_k_m_picks_q4_k_m(self):
        from sirb_cli.model_fetch import _pick_gguf_filename
        assert _pick_gguf_filename("owner/repo", "Q4_K_M") == "model.Q4_K_M.gguf"

    def test_iq4_xs_picks_iq4_xs(self):
        from sirb_cli.model_fetch import _pick_gguf_filename
        assert _pick_gguf_filename("owner/repo", "IQ4_XS") == "model.IQ4_XS.gguf"

    def test_unknown_quant_raises(self):
        from sirb_cli.model_fetch import _pick_gguf_filename
        with pytest.raises(RuntimeError, match="no .gguf file"):
            _pick_gguf_filename("owner/repo", "Q9_K_M")


# ─────────────── symlink rejection in fetch_model ───────────────────────


class TestSymlinkRejection:
    """Reviewer-flagged: shutil.copy2 follows symlinks. A planted
    dangling symlink in the cache slot could redirect a GGUF write
    to e.g. ~/.ssh/authorized_keys. Verify we refuse."""

    def test_pre_existing_symlink_at_cache_path_is_refused(
        self, tmp_path, monkeypatch,
    ):
        from sirb_cli.model_fetch import fetch_model
        monkeypatch.setenv("SIRB_MODELS_DIR", str(tmp_path))

        # Simulate the attacker: plant a dangling symlink at the
        # exact cache slot where the next fetch would write.
        ref_dir = tmp_path / "owner__repo"
        ref_dir.mkdir(parents=True)
        target = tmp_path / "innocuous_file"
        target.write_text("attacker target")
        link = ref_dir / "model.Q4_K_M.gguf"
        link.symlink_to(target)

        # Patch hf_hub_download so the test doesn't hit the network.
        import huggingface_hub  # type: ignore
        monkeypatch.setattr(
            huggingface_hub, "list_repo_files",
            lambda repo_id: ["model.Q4_K_M.gguf"],
        )
        monkeypatch.setattr(
            huggingface_hub, "hf_hub_download",
            lambda **kw: str(tmp_path / "downloaded.gguf"),
        )
        (tmp_path / "downloaded.gguf").write_text("real model bytes")

        with pytest.raises(RuntimeError, match="symlink"):
            fetch_model("hf.co/owner/repo:Q4_K_M")

        # Target was NOT clobbered.
        assert target.read_text() == "attacker target"
