"""Tests for sirb_cli.host_servers — inference-server probes.

Mock-only — never opens real TCP sockets to localhost (tests should
not depend on whether the developer happens to have Ollama running).
We monkeypatch ``_tcp_open`` to control which ports we pretend are
listening, and ``urllib.request.urlopen`` to fake the JSON shapes
each server type would return.
"""

from __future__ import annotations

import io
import json
from unittest.mock import patch

import pytest

from sirb_cli import host_servers


# ─────────────────── fixtures ─────────────────────────────


class _FakeResponse:
    """Stand-in for the urllib.request.urlopen() context manager."""

    def __init__(self, body: bytes, status: int = 200):
        self._body = body
        self.status = status

    def __enter__(self):
        return self

    def __exit__(self, *_):
        return False

    def read(self) -> bytes:
        return self._body


def _fake_urlopen_for(routes: dict[str, dict | list]):
    """Return a urlopen replacement that serves the routes dict.

    Each key is the full URL; value is the JSON body to return. Any
    URL not in routes raises URLError to mimic ConnectionRefused.
    """
    def _opener(req, timeout=None):
        url = req.get_full_url() if hasattr(req, "get_full_url") else str(req)
        if url not in routes:
            import urllib.error
            raise urllib.error.URLError("connection refused")
        return _FakeResponse(json.dumps(routes[url]).encode())
    return _opener


# ─────────────────── port-open probe ─────────────────────────────


def test_tcp_open_returns_false_on_unreachable(monkeypatch):
    """No socket needed — connect attempt to closed port → OSError →
    return False (not raise)."""
    import socket
    def _raise(*_a, **_kw):
        raise OSError("connection refused")
    monkeypatch.setattr(socket, "create_connection", _raise)
    assert host_servers._tcp_open(11434) is False


# ─────────────────── per-server probes ─────────────────────────────


def test_probe_ollama_happy_path(monkeypatch):
    """Ollama on :11434 with three models loaded → DetectedServer
    populated with sorted model names + version string."""
    monkeypatch.setattr(host_servers, "_tcp_open", lambda port, host="127.0.0.1": port == 11434)
    monkeypatch.setattr(host_servers.urllib.request, "urlopen", _fake_urlopen_for({
        "http://localhost:11434/api/tags": {"models": [
            {"name": "llama3.2:3b"}, {"name": "qwen2.5:7b"}, {"name": "mistral:7b"},
        ]},
        "http://localhost:11434/api/version": {"version": "0.3.12"},
    }))
    srv = host_servers._probe_ollama()
    assert srv is not None
    assert srv.kind == "ollama"
    assert srv.port == 11434
    assert srv.models == ["llama3.2:3b", "mistral:7b", "qwen2.5:7b"]  # sorted
    assert srv.version == "0.3.12"
    # The in-container URL is what the agent uses to actually call
    # the host server — must use host.docker.internal, not localhost.
    assert srv.in_container_url == "http://host.docker.internal:11434"


def test_probe_ollama_returns_none_when_port_closed(monkeypatch):
    """No probe HTTP traffic when TCP is closed — saves latency on
    the common 'no server running' case."""
    monkeypatch.setattr(host_servers, "_tcp_open", lambda port, host="127.0.0.1": False)
    # urllib should not be called — if it is, the test will fail with
    # a missing-route ConnectionRefused, which is fine either way.
    assert host_servers._probe_ollama() is None


def test_probe_ollama_returns_none_on_wrong_shape(monkeypatch):
    """A server that ACCEPTS TCP on 11434 but responds with non-Ollama
    JSON (e.g. a generic web server) must not be claimed as Ollama."""
    monkeypatch.setattr(host_servers, "_tcp_open", lambda port, host="127.0.0.1": True)
    monkeypatch.setattr(host_servers.urllib.request, "urlopen", _fake_urlopen_for({
        "http://localhost:11434/api/tags": {"error": "not Ollama"},
    }))
    assert host_servers._probe_ollama() is None


def test_probe_lmstudio_openai_compat(monkeypatch):
    """LM Studio at :1234 returns OpenAI-style /v1/models."""
    monkeypatch.setattr(host_servers, "_tcp_open", lambda port, host="127.0.0.1": port == 1234)
    monkeypatch.setattr(host_servers.urllib.request, "urlopen", _fake_urlopen_for({
        "http://localhost:1234/v1/models": {"data": [
            {"id": "gemma-2-9b-it"},
            {"id": "qwen2.5-coder-32b"},
        ]},
    }))
    srv = host_servers._probe_lmstudio()
    assert srv is not None
    assert srv.kind == "lmstudio"
    assert sorted(srv.models) == ["gemma-2-9b-it", "qwen2.5-coder-32b"]


def test_probe_llama_server(monkeypatch):
    """llama-server at :8080 — same OpenAI shape as LM Studio."""
    monkeypatch.setattr(host_servers, "_tcp_open", lambda port, host="127.0.0.1": port == 8080)
    monkeypatch.setattr(host_servers.urllib.request, "urlopen", _fake_urlopen_for({
        "http://localhost:8080/v1/models": {"data": [{"id": "llama-3.1-8b-instruct-q4_k_m"}]},
    }))
    srv = host_servers._probe_llama_server()
    assert srv is not None
    assert srv.kind == "llama-server"
    assert srv.models == ["llama-3.1-8b-instruct-q4_k_m"]


def test_probe_vllm(monkeypatch):
    """vLLM at :8000 — OpenAI-API server."""
    monkeypatch.setattr(host_servers, "_tcp_open", lambda port, host="127.0.0.1": port == 8000)
    monkeypatch.setattr(host_servers.urllib.request, "urlopen", _fake_urlopen_for({
        "http://localhost:8000/v1/models": {"data": [{"id": "Qwen/Qwen2.5-72B-Instruct"}]},
    }))
    srv = host_servers._probe_vllm()
    assert srv is not None
    assert srv.kind == "vllm"


# ─────────────────── full sweep ─────────────────────────────


def test_detect_servers_returns_all_running(monkeypatch):
    """Both Ollama and llama-server up → both surfaced. Detection
    order matters: Ollama first (most common contributor setup),
    then LM Studio (rising), then vLLM, then llama-server."""
    def _tcp(port, host="127.0.0.1"):
        return port in (11434, 8080)
    monkeypatch.setattr(host_servers, "_tcp_open", _tcp)
    monkeypatch.setattr(host_servers.urllib.request, "urlopen", _fake_urlopen_for({
        "http://localhost:11434/api/tags": {"models": [{"name": "qwen3:8b"}]},
        "http://localhost:11434/api/version": {"version": "0.3.0"},
        "http://localhost:8080/v1/models": {"data": [{"id": "llama-3.1-8b"}]},
    }))
    servers = host_servers.detect_servers()
    kinds = [s.kind for s in servers]
    assert kinds == ["ollama", "llama-server"]


def test_detect_servers_empty_when_nothing_running(monkeypatch):
    """No probe finds anything → empty list (caller skips the prompt)."""
    monkeypatch.setattr(host_servers, "_tcp_open", lambda port, host="127.0.0.1": False)
    assert host_servers.detect_servers() == []


def test_detect_servers_swallows_probe_exceptions(monkeypatch):
    """If one probe raises an unexpected exception, the others must
    still run — never let a corner-case crash the deploy."""
    monkeypatch.setattr(host_servers, "_tcp_open", lambda port, host="127.0.0.1": True)
    def _broken(*_a, **_kw):
        raise RuntimeError("probe blew up unexpectedly")
    monkeypatch.setattr(host_servers, "_probe_ollama", _broken)
    # Other probes still attempt — they'll likely return None against
    # the fake URL routes, but the function returns cleanly either way.
    monkeypatch.setattr(host_servers.urllib.request, "urlopen", _fake_urlopen_for({}))
    out = host_servers.detect_servers()
    assert isinstance(out, list)  # No exception bubbled.


# ─────────────────── KIND_TO_SIRB_BACKEND mapping ─────────────────────────


def test_kind_to_sirb_backend_mapping():
    """Locking the mapping: Ollama → ollama backend (its native
    protocol); the OpenAI-API-shaped servers all proxy via the vllm
    backend (which is just an OpenAI-API client). A refactor that
    flips this would silently change which backend the deploy CLI
    picks when proxying."""
    assert host_servers.KIND_TO_SIRB_BACKEND["ollama"] == "ollama"
    assert host_servers.KIND_TO_SIRB_BACKEND["lmstudio"] == "vllm"
    assert host_servers.KIND_TO_SIRB_BACKEND["vllm"] == "vllm"
    assert host_servers.KIND_TO_SIRB_BACKEND["llama-server"] == "vllm"


def test_display_handles_long_model_list():
    """display() truncates at 3 models with a 'N more' suffix so the
    prompt stays readable on a host with 50 models loaded."""
    srv = host_servers.DetectedServer(
        kind="ollama", port=11434,
        base_url="http://localhost:11434",
        in_container_url="http://host.docker.internal:11434",
        models=[f"model-{i}:7b" for i in range(20)],
    )
    text = srv.display()
    assert "20 models" in text
    assert "+ 17 more" in text


def test_display_handles_no_models():
    """A server that's up but has no models loaded (Ollama before
    first pull) is reported, not hidden — operator may want to
    proxy it intending to `ollama pull` later."""
    srv = host_servers.DetectedServer(
        kind="ollama", port=11434,
        base_url="http://localhost:11434",
        in_container_url="http://host.docker.internal:11434",
        models=[],
    )
    assert "no models loaded yet" in srv.display()
