"""Tests for sirb_cli.docker_args.filter_safe_docker_args.

The docker_args module exists as a dedicated security boundary: every
flag that reaches the literal `docker run` invocation flows through
its allowlist. sirb_cli.gpu emits vendor-specific GPU passthrough
flags (--device /dev/kfd, --group-add render, --security-opt
seccomp=unconfined for ROCm), and sirb_cli.deploy_node imports the
filter so an addition of an operator-facing knob (e.g. SIRB_NODE_GPU_VENDOR
env var) can't smuggle arbitrary docker flags through. Same defense-in-
depth posture as the workflow-injection guard on the GHA workflows.
"""

from __future__ import annotations

from sirb_cli.docker_args import filter_safe_docker_args as _filter_safe_docker_args


def test_passes_known_flags_through():
    """The flags emitted by gpu.detect_gpu() for AMD + Intel all need to
    survive — this is the happy path."""
    inp = [
        "--device", "/dev/kfd",
        "--device", "/dev/dri",
        "--security-opt", "seccomp=unconfined",
        "--group-add", "109",
        "--group-add", "44",
    ]
    assert _filter_safe_docker_args(inp) == inp


def test_drops_unknown_flag():
    """An unknown flag (--privileged, --cap-add, --pid, ...) must be
    dropped silently. We never want a regression in the source emitter
    to translate into 'arbitrary docker flag injection into the run
    command'."""
    inp = ["--device", "/dev/dri", "--privileged", "--device", "/dev/kfd"]
    out = _filter_safe_docker_args(inp)
    assert "--privileged" not in out
    assert "--device" in out
    assert "/dev/dri" in out
    assert "/dev/kfd" in out


def test_drops_flag_without_value():
    """`--device` with no value following must drop the lone flag, not
    consume the next flag as its value."""
    inp = ["--device", "--group-add", "render"]
    out = _filter_safe_docker_args(inp)
    # The first --device has no value; second token is another flag.
    # Both should drop the orphan --device but keep the valid pair.
    assert out == ["--group-add", "render"]


def test_drops_empty_input():
    """Empty list (NVIDIA path / no-GPU host) → empty output."""
    assert _filter_safe_docker_args([]) == []


def test_no_value_at_end_dropped():
    """`--device` at the very end of the list (no following token)
    must not crash and must drop the orphan."""
    inp = ["--group-add", "render", "--device"]
    out = _filter_safe_docker_args(inp)
    assert out == ["--group-add", "render"]


def test_warns_on_drop(monkeypatch):
    """C3 fix (silent-failure review): the original drop-and-continue
    posture was the documented anti-pattern. A future vendor probe
    that emitted a legitimate new flag would silently lose it on
    every deploy. We now invoke the warn callback for each drop so
    a code-side regression in gpu.py surfaces at the first deploy
    that hits it."""
    warnings: list[str] = []
    inp = ["--privileged", "--device", "/dev/dri", "--cap-add", "SYS_NICE"]
    out = _filter_safe_docker_args(inp, warn=warnings.append)
    # Allowlisted pair survives; bad flags dropped.
    assert out == ["--device", "/dev/dri"]
    # Both dropped tokens warned about. SYS_NICE is the value-side of
    # --cap-add and gets warned independently — that's fine; the
    # operator sees TWO related warnings, which is louder than one.
    assert len(warnings) >= 2
    assert any("--privileged" in w for w in warnings)
    assert any("--cap-add" in w for w in warnings)


def test_no_warn_when_callback_is_none():
    """Default behavior (no warn= passed) must not crash. Used by
    callers that don't want the visible regression signal yet."""
    inp = ["--privileged"]
    out = _filter_safe_docker_args(inp)
    assert out == []
