"""Tests for `sirb update node`'s container-recreation logic.

The bug we're guarding against: pre-fix, `update node` captured only
``Env``, ``PortBindings`` and ``RestartPolicy`` from the running
container — so the new container came up WITHOUT the GGUF mount,
without ``--gpus all``, and without the ``~/.sirb/data:/data:ro`` mount
holding the `sirb models add` history. The node would then start but
fail to find its model, and the operator would see a "corrupted update."

We test against recorded ``docker inspect`` fixtures so a daemon isn't
required and the assertions are deterministic.
"""

from __future__ import annotations

from sirb_cli.commands.update import _build_recreate_args, _redact_secret_envs


def _inspect_minimal() -> dict:
    """The simplest viable sirb-node inspect: env + port + restart only."""
    return {
        "Config": {
            "Env": [
                "SIRB_NODE_WALLET_ADDRESS=0xabc",
                "SIRB_NODE_API_KEY=sirb_secret",
                "SIRB_NODE_BACKEND_URL=https://api.sirb.run",
            ],
        },
        "HostConfig": {
            "RestartPolicy": {"Name": "unless-stopped"},
            "PortBindings": {"9000/tcp": [{"HostIp": "", "HostPort": "9001"}]},
        },
    }


def _inspect_full() -> dict:
    """A realistic GPU + llama-cpp sirb-node inspect — the shape that
    exposed the bug. Has bind mounts (model + data dir), GPU device
    request, CPU/memory caps, all the standard env."""
    return {
        "Config": {
            "Env": [
                "SIRB_NODE_WALLET_ADDRESS=0xdeadbeef",
                "SIRB_NODE_API_KEY=sirb_realkey",
                "SIRB_NODE_LLAMA_MODEL_PATH=/models/gemma3-27b-q4.gguf",
                "SIRB_NODE_MODEL_BACKEND=llama-cpp",
            ],
        },
        "HostConfig": {
            "RestartPolicy": {"Name": "always"},
            "PortBindings": {"9000/tcp": [{"HostIp": "0.0.0.0", "HostPort": "9000"}]},
            "Binds": [
                "/home/op/.sirb/data:/data:ro",
                "/srv/models/gemma3-27b-q4.gguf:/models/gemma3-27b-q4.gguf:ro",
            ],
            "DeviceRequests": [
                {
                    "Driver": "",
                    "Count": -1,  # -1 == "all"
                    "DeviceIDs": [],
                    "Capabilities": [["gpu"]],
                }
            ],
            "NanoCpus": 8_000_000_000,  # 8 CPUs
            "Memory": 32 * 1024**3,  # 32 GiB
            "NetworkMode": "default",
        },
    }


# ─── env + ports + restart (regression: was already preserved) ──────────


def test_minimal_inspect_preserves_env_and_port():
    args = _build_recreate_args("sirb-node", "ghcr.io/x/y:v2", _inspect_minimal())
    assert args[:7] == ["docker", "run", "-d", "--name", "sirb-node", "--restart", "unless-stopped"]
    # All three env vars present.
    for v in (
        "SIRB_NODE_WALLET_ADDRESS=0xabc",
        "SIRB_NODE_API_KEY=sirb_secret",
        "SIRB_NODE_BACKEND_URL=https://api.sirb.run",
    ):
        assert "-e" in args
        assert v in args
    assert "-p" in args
    p_idx = args.index("-p")
    assert args[p_idx + 1] == "9001:9000"
    assert args[-1] == "ghcr.io/x/y:v2"


def test_restart_policy_defaults_when_missing():
    spec = _inspect_minimal()
    spec["HostConfig"].pop("RestartPolicy")
    args = _build_recreate_args("n", "img", spec)
    assert "--restart" in args
    assert args[args.index("--restart") + 1] == "unless-stopped"


# ─── the bug: bind mounts ───────────────────────────────────────────────


def test_bind_mounts_preserved():
    """Regression: without this, model_runner can't find the GGUF after
    update and `sirb models add` history is wiped."""
    args = _build_recreate_args("sirb-node", "img:v2", _inspect_full())
    # Both binds should appear as `-v src:dst:mode` pairs.
    bind_positions = [i for i, a in enumerate(args) if a == "-v"]
    assert len(bind_positions) == 2, args
    binds_emitted = {args[i + 1] for i in bind_positions}
    assert "/home/op/.sirb/data:/data:ro" in binds_emitted
    assert "/srv/models/gemma3-27b-q4.gguf:/models/gemma3-27b-q4.gguf:ro" in binds_emitted


def test_modern_mounts_fallback():
    """When ``Binds`` is empty but ``Mounts`` is populated (the newer
    --mount syntax), the helper should still preserve them."""
    spec = _inspect_minimal()
    spec["HostConfig"]["Mounts"] = [
        {"Type": "bind", "Source": "/host/data", "Target": "/data", "ReadOnly": True},
    ]
    args = _build_recreate_args("n", "img", spec)
    v_idx = args.index("-v")
    assert args[v_idx + 1] == "/host/data:/data:ro"


# ─── the bug: GPU device requests ───────────────────────────────────────


def test_gpus_all_preserved():
    """Regression: without this, an NVIDIA node loses GPU access after
    update and silently runs CPU-only (or crashes if the model is too
    large for system RAM)."""
    args = _build_recreate_args("sirb-node", "img:v2", _inspect_full())
    assert "--gpus" in args
    assert args[args.index("--gpus") + 1] == "all"


def test_gpus_count_form():
    spec = _inspect_minimal()
    spec["HostConfig"]["DeviceRequests"] = [
        {"Driver": "", "Count": 2, "DeviceIDs": [], "Capabilities": [["gpu"]]}
    ]
    args = _build_recreate_args("n", "img", spec)
    assert args[args.index("--gpus") + 1] == "count=2"


def test_gpus_device_ids_form():
    spec = _inspect_minimal()
    spec["HostConfig"]["DeviceRequests"] = [
        {"Driver": "", "Count": 0, "DeviceIDs": ["GPU-abc", "GPU-def"], "Capabilities": [["gpu"]]}
    ]
    args = _build_recreate_args("n", "img", spec)
    assert args[args.index("--gpus") + 1] == "device=GPU-abc,GPU-def"


def test_non_gpu_device_request_ignored():
    """Esoteric capability sets (e.g. compute-only) — we'd rather emit
    nothing than emit something the new docker version rejects."""
    spec = _inspect_minimal()
    spec["HostConfig"]["DeviceRequests"] = [
        {"Driver": "", "Count": -1, "DeviceIDs": [], "Capabilities": [["compute"]]}
    ]
    args = _build_recreate_args("n", "img", spec)
    assert "--gpus" not in args


# ─── the bug: raw devices (AMD ROCm path) ───────────────────────────────


def test_raw_devices_preserved():
    spec = _inspect_minimal()
    spec["HostConfig"]["Devices"] = [
        {"PathOnHost": "/dev/kfd", "PathInContainer": "/dev/kfd", "CgroupPermissions": "rwm"},
        {"PathOnHost": "/dev/dri", "PathInContainer": "/dev/dri", "CgroupPermissions": "rwm"},
    ]
    args = _build_recreate_args("n", "img", spec)
    dev_positions = [i for i, a in enumerate(args) if a == "--device"]
    assert len(dev_positions) == 2
    devs = {args[i + 1] for i in dev_positions}
    assert "/dev/kfd" in devs
    assert "/dev/dri" in devs


# ─── resource caps + network mode ───────────────────────────────────────


def test_cpus_and_memory_preserved():
    args = _build_recreate_args("n", "img", _inspect_full())
    assert args[args.index("--cpus") + 1] == "8"
    assert args[args.index("--memory") + 1] == str(32 * 1024**3)


def test_default_network_mode_not_emitted():
    """`default` / `bridge` / empty NetworkMode shouldn't pollute the
    command line — pinning them surprises operators who never asked for
    a custom network."""
    args = _build_recreate_args("n", "img", _inspect_full())
    assert "--network" not in args


def test_custom_network_mode_preserved():
    spec = _inspect_minimal()
    spec["HostConfig"]["NetworkMode"] = "host"
    args = _build_recreate_args("n", "img", spec)
    assert args[args.index("--network") + 1] == "host"


def test_container_network_mode_skipped():
    """`container:<id>` requires the referenced container to still exist
    — silently dropping is safer than failing a recreate."""
    spec = _inspect_minimal()
    spec["HostConfig"]["NetworkMode"] = "container:abcdef"
    args = _build_recreate_args("n", "img", spec)
    assert "--network" not in args


# ─── argv shape sanity ──────────────────────────────────────────────────


def test_image_is_always_last_arg():
    args = _build_recreate_args("sirb-node", "ghcr.io/x/y:v3", _inspect_full())
    assert args[-1] == "ghcr.io/x/y:v3"


def test_no_empty_or_none_args():
    """Catches missed `or ""` fallbacks that would emit a literal empty
    string and confuse docker."""
    args = _build_recreate_args("n", "img", _inspect_full())
    assert all(a != "" and a is not None for a in args)


# ─── secret redaction in recovery hint (CLAUDE.md §6.4) ─────────────────


def test_redact_strips_api_key_and_signing_secret():
    """The recovery hint after a failed `sirb update node` prints the
    captured argv. Operators paste that into Discord / GitHub issues for
    help — leaking the signing secret would let any reader forge
    node→backend messages from that wallet."""
    argv = [
        "docker",
        "run",
        "-d",
        "--name",
        "sirb-node",
        "-e",
        "SIRB_NODE_API_KEY=sirb_topsecret",
        "-e",
        "SIRB_NODE_SIGNING_SECRET=hunter2",
        "-e",
        "SIRB_NODE_BACKEND_URL=https://api.sirb.run",
        "-e",
        "SIRB_NODE_WALLET_ADDRESS=0xabc",
        "img:v2",
    ]
    out = _redact_secret_envs(argv)
    joined = " ".join(out)
    assert "sirb_topsecret" not in joined
    assert "hunter2" not in joined
    # Non-secret env vars pass through untouched so the operator still
    # sees the backend URL / wallet / etc.
    assert "https://api.sirb.run" in joined
    assert "0xabc" in joined
    # Redacted form is "KEY=***" so operators can SEE that a value was
    # there (vs the key being missing entirely).
    assert "SIRB_NODE_API_KEY=***" in out
    assert "SIRB_NODE_SIGNING_SECRET=***" in out


def test_redact_handles_token_and_password_substrings():
    """Pattern matches conservatively — anything with TOKEN, PASSWORD,
    PRIVATE_KEY in the key name gets redacted too, even if it's not a
    sirb-specific env we ship today."""
    argv = ["-e", "GITHUB_TOKEN=ghp_xxx", "-e", "DB_PASSWORD=pw"]
    out = _redact_secret_envs(argv)
    assert "ghp_xxx" not in " ".join(out)
    assert "pw" not in " ".join(out)


def test_redact_passes_through_non_env_tokens():
    """``-v`` / ``--gpus`` / ``--restart`` etc. should pass through —
    redaction only acts on ``-e KEY=value`` pairs."""
    argv = ["docker", "run", "--gpus", "all", "-v", "/host:/data", "img"]
    assert _redact_secret_envs(argv) == argv


def test_redact_tolerates_malformed_e_pairs():
    """`-e KEY` (no `=`) and `-e =foo` shapes shouldn't crash the
    redactor — they don't expose a key/value pair so they just pass
    through unchanged."""
    argv = ["-e", "BARE_KEY", "-e", "=valueonly"]
    out = _redact_secret_envs(argv)
    assert out == argv


# ─── ShmSize + Ulimits + Sysctls (llama.cpp / vLLM hot paths) ───────────


def test_shm_size_preserved():
    """vLLM batched-inference workloads with large tensor parallelism
    routinely set --shm-size 4g; losing it on update produces silent
    OOMs after restart."""
    spec = _inspect_minimal()
    spec["HostConfig"]["ShmSize"] = 4 * 1024**3
    args = _build_recreate_args("n", "img", spec)
    assert args[args.index("--shm-size") + 1] == str(4 * 1024**3)


def test_ulimit_memlock_preserved():
    spec = _inspect_minimal()
    spec["HostConfig"]["Ulimits"] = [{"Name": "memlock", "Soft": -1, "Hard": -1}]
    args = _build_recreate_args("n", "img", spec)
    # Soft == Hard collapses to just `memlock=-1` (matches docker run's
    # short form when both limits are the same).
    assert args[args.index("--ulimit") + 1] == "memlock=-1"


def test_ulimit_distinct_soft_hard_preserved():
    spec = _inspect_minimal()
    spec["HostConfig"]["Ulimits"] = [{"Name": "nofile", "Soft": 1024, "Hard": 65536}]
    args = _build_recreate_args("n", "img", spec)
    assert args[args.index("--ulimit") + 1] == "nofile=1024:65536"


def test_sysctls_preserved():
    spec = _inspect_minimal()
    spec["HostConfig"]["Sysctls"] = {"net.ipv4.ip_forward": "1"}
    args = _build_recreate_args("n", "img", spec)
    assert args[args.index("--sysctl") + 1] == "net.ipv4.ip_forward=1"


# ─── defensive None handling in DeviceRequests parse ────────────────────


def test_gpu_caps_with_none_entry_does_not_crash():
    """A daemon returning ``Capabilities: [None]`` (or similar) would
    crash on ``"gpu" in None`` without the defensive ``c or []`` guard.
    Recreate should fall through to "no GPU flag" instead of taking
    down the whole update path."""
    spec = _inspect_minimal()
    spec["HostConfig"]["DeviceRequests"] = [
        {"Driver": "", "Count": -1, "DeviceIDs": [], "Capabilities": [None]}
    ]
    # Just shouldn't raise; no GPU flag emitted.
    args = _build_recreate_args("n", "img", spec)
    assert "--gpus" not in args
