"""Regression tests for ``sirb deploy node``'s llama-cpp manifest handling.

The node-agent's LlamaCppRunner defaults to refusing any GGUF that
doesn't have a Sirb-signed ``<file>.manifest.json`` next to it
(security plan §7). HuggingFace community GGUFs (bartowski, unsloth,
…) don't ship signed manifests — so a default ``sirb deploy node
--backend llama-cpp --models hf.co/...`` used to land users in a
crash-loop with a confusing ``FileNotFoundError`` from the runner.

The CLI now detects this at deploy time and either:

* mounts the manifest into the container + sets
  ``SIRB_NODE_LLAMA_MANIFEST_PATH`` (when a manifest is present), or
* sets ``SIRB_NODE_LLAMA_VERIFY_MANIFEST=false`` with a clear console
  warning (when there's no manifest — the common HF case).

These tests pin both branches by mocking ``subprocess.run`` and
inspecting the constructed ``docker run`` argv. We don't need a real
docker daemon or container — the boundary we care about is "what
env / mounts does the CLI hand to docker."
"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import patch

import pytest

from sirb_cli import deploy_node


@pytest.fixture
def fake_gguf(tmp_path: Path) -> Path:
    """A zero-byte file shaped like a GGUF — the CLI only checks
    existence + builds the mount path."""
    f = tmp_path / "google_gemma-4-E4B-it-Q8_0.gguf"
    f.write_bytes(b"")
    return f


def _invoke_with_recorder(llama_model_path: Path):
    """Run ``_docker_run_node`` with the subprocess + filesystem
    side-effects mocked, returning the captured ``docker run`` argv."""
    captured = {}

    def fake_run(cmd, **kwargs):
        if cmd and cmd[0] == "docker" and len(cmd) >= 2 and cmd[1] == "run":
            captured["argv"] = list(cmd)

        class _Result:
            returncode = 0
            stdout = ""
            stderr = ""

        return _Result()

    with patch.object(deploy_node.subprocess, "run", side_effect=fake_run), \
         patch.object(deploy_node, "_sirb_home", return_value=llama_model_path.parent / ".sirb"):
        deploy_node._docker_run_node(
            image="ghcr.io/test/sirb-node:latest",
            name="sirb-node-test",
            backend_url="https://api.sirb.test",
            api_key="sirb_test",
            signing_secret="00" * 32,
            wallet="0xops_test",
            tunnel_url="http://test.example",
            models=None,
            allow_sharding=False,
            local_port=9000,
            model_backend="llama-cpp",
            ollama_url="",
            vllm_url="",
            llama_model_path=str(llama_model_path),
            cpu_cores=None,
            ram_gb=None,
            gpu_count=None,
            gpu_percent=None,
            vram_gb=None,
        )

    return captured.get("argv", [])


def _env_value(argv: list[str], key: str) -> str | None:
    """Pull the ``-e KEY=value`` value out of a ``docker run`` argv."""
    for i, tok in enumerate(argv):
        if tok == "-e" and i + 1 < len(argv) and argv[i + 1].startswith(f"{key}="):
            return argv[i + 1].split("=", 1)[1]
    return None


def _has_mount(argv: list[str], substring: str) -> bool:
    for i, tok in enumerate(argv):
        if tok == "-v" and i + 1 < len(argv) and substring in argv[i + 1]:
            return True
    return False


def test_llama_no_manifest_auto_disables_verification(fake_gguf):
    """The headline bug: HF-pulled GGUFs have no manifest. The CLI must
    auto-set SIRB_NODE_LLAMA_VERIFY_MANIFEST=false so the node-agent
    actually boots instead of crash-looping with FileNotFoundError.

    Pre-fix: this case crashed the node every time. Post-fix: the
    flag flips automatically with a console warning."""
    argv = _invoke_with_recorder(fake_gguf)
    assert argv, "docker run was never invoked"
    assert _env_value(argv, "SIRB_NODE_LLAMA_VERIFY_MANIFEST") == "false"
    # No manifest path env when there's no manifest — would be
    # nonsensical and might trip the runner's manifest-path validation.
    assert _env_value(argv, "SIRB_NODE_LLAMA_MANIFEST_PATH") is None
    # The GGUF itself is still mounted.
    assert _has_mount(argv, fake_gguf.name)


def test_llama_with_manifest_mounts_and_enables_verification(fake_gguf):
    """When a signed manifest exists next to the GGUF, the CLI must
    mount it into the container AND set SIRB_NODE_LLAMA_MANIFEST_PATH —
    and must NOT set SIRB_NODE_LLAMA_VERIFY_MANIFEST=false (which
    would defeat the whole point of having a manifest)."""
    manifest = fake_gguf.with_suffix(fake_gguf.suffix + ".manifest.json")
    manifest.write_text('{"signer": "test", "signature": "..."}')

    argv = _invoke_with_recorder(fake_gguf)
    assert argv
    # Verification stays at the node-agent's default (True). The flag
    # is explicitly NOT in the env — we only set it to disable.
    assert _env_value(argv, "SIRB_NODE_LLAMA_VERIFY_MANIFEST") is None
    # Manifest is mounted into the container and the path is wired up
    # so the runner can find it without guessing at the GGUF's suffix.
    assert _has_mount(argv, manifest.name)
    manifest_env = _env_value(argv, "SIRB_NODE_LLAMA_MANIFEST_PATH")
    assert manifest_env == f"/models/{manifest.name}"


def test_non_llama_backend_does_not_touch_manifest_flags(fake_gguf):
    """Sanity: the manifest detection is scoped to the llama-cpp branch.
    Ollama / vLLM users with a stray .gguf file in their HF cache
    shouldn't see manifest-related env on their deploys."""
    captured = {}

    def fake_run(cmd, **kwargs):
        if cmd and cmd[0] == "docker" and cmd[1:2] == ["run"]:
            captured["argv"] = list(cmd)

        class _R:
            returncode = 0
            stdout = ""
            stderr = ""

        return _R()

    with patch.object(deploy_node.subprocess, "run", side_effect=fake_run), \
         patch.object(deploy_node, "_sirb_home", return_value=fake_gguf.parent / ".sirb"):
        deploy_node._docker_run_node(
            image="ghcr.io/test/sirb-node:latest",
            name="sirb-node-test",
            backend_url="https://api.sirb.test",
            api_key="sirb_test",
            signing_secret="00" * 32,
            wallet="0xops_test",
            tunnel_url="http://test.example",
            models=None,
            allow_sharding=False,
            local_port=9000,
            model_backend="ollama",
            ollama_url="http://localhost:11434",
            vllm_url="",
            llama_model_path=None,
            cpu_cores=None,
            ram_gb=None,
            gpu_count=None,
            gpu_percent=None,
            vram_gb=None,
        )

    argv = captured.get("argv", [])
    assert argv
    assert _env_value(argv, "SIRB_NODE_LLAMA_VERIFY_MANIFEST") is None
    assert _env_value(argv, "SIRB_NODE_LLAMA_MANIFEST_PATH") is None
