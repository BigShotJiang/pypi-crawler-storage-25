"""
Hyrax has several built-in datasets that you can use for astronomical data. For many uses, these datasets
can be configured out-of-the box for a given project.

:doc:`FitsImageDataset <fits_image_dataset/index>` is a generic container for fits image cutout data
indexed by a user-provided catalog file. It attempts to cover common usage paradigms such as multiple images
of the same object differentiated by telescope filter; however, extending the class as a custom dataset
may be more well fit to advanced usage.

:doc:`LSSTDataset <lsst_dataset/index>` Is a alpha-quality container for LSST cutout images, currently
limited to ``deep_coadd`` type images, and restricted to run only on a Rubin observatory RSP environment
where `LSST Pipeline <https://pipelines.lsst.io/>`_ tools and a
`data butler <https://pipelines.lsst.io/modules/lsst.daf.butler/index.html>`_ with the appropriate images
are available.

:doc:`DownloadedLSSTDataset <downloaded_lsst_dataset/index>` is a subclass of LSSTDataset that generates
cutouts from the butler and saves them as ``.pt`` files on first access. On subsequent access,
it loads the cutouts directly from these files, which can significantly speed up data loading times.
It inherits from LSSTDataset to access the data butler and catalog functionality.

:doc:`HSCDataset <hsc_dataset/index>` Works similarly to FitsImageDataset, but is specialized to
`Hyper Suprime-Cam (HSC) <https://hsc-release.mtk.nao.ac.jp/doc/index.php/data/>`_ cutout images downloaded
with the hyrax ``download`` verb. It contains additional integrity checks and is tightly integrated with
the ``download`` and ``rebuild_manifest`` verbs. In future this class and the downloader may become a
separate package.

:doc:`HyraxCifarDataset <hyrax_cifar_dataset/index>` gives access to the standard
`CIFAR10 <https://www.cs.toronto.edu/~kriz/cifar.html>`_ labeled image dataset, automatically downloading the
dataset if it is not present. This dataset is useful for testing hyrax and occasionally individual models,
but it is not an astronomical dataset.

:doc:`HyraxRandomDataset <random/hyrax_random_dataset/index>` is a utility dataset that
generates random data with a specific shape.
This dataset makes it easy to test new models with simple random data.
It is highly configurable such that it's possible to simulate input data for models that
are under development.

Each of these datasets can be used a starting point for a Custom Dataset by inheriting your custom dataset
from e.g. `FitsImageDataset`, or you can make an entirely custom dataset following the
:doc:`dataset class reference </dataset_class_reference>` and/or
:doc:`dataset class notebook example </pre_executed/external_dataset_class>`.

The remaining classes in this module exist primarily for Hyrax interface purposes:

:doc:`InferenceDataset <inference_dataset/index>` is a dataset class that represents an ``infer`` or ``umap``
result, and may be returned from those verbs to provide data access

:doc:`HyraxDataset <dataset_registry/index>` is a base class for all datasets in Hyrax and must be within
the inheritance hierarchy of all custom datasets. It is not usable on its own, but provides various fall-back
functionality to make custom datasets easier to write. See the
:doc:`dataset class reference </dataset_class_reference>` and
:doc:`example notebook </pre_executed/external_dataset_class>` for more information.

"""

# Remove import sorting, these are imported in the order written so that
# autoapi docs are generated with ordering controlled below.
# ruff: noqa: I001
from .fits_image_dataset import FitsImageDataset
from .lsst_dataset import LSSTDataset
from .downloaded_lsst_dataset import DownloadedLSSTDataset
from .hsc_dataset import HSCDataset
from .hyrax_cifar_dataset import HyraxCifarDataset
from .random.hyrax_random_dataset import (
    HyraxRandomDataset,
    HyraxRandomDatasetBase,
)
from .inference_dataset import InferenceDataset
from .result_dataset import ResultDataset, ResultDatasetWriter
from .result_factories import create_results_writer, load_results_dataset
from .dataset_registry import HyraxDataset
from .hyrax_csv_dataset import HyraxCSVDataset
from .mmu_dataset import MultimodalUniverseDataset
from .data_cache import DataCache

__all__ = [
    "HyraxCifarDataset",
    "FitsImageDataset",
    "HSCDataset",
    "InferenceDataset",
    "ResultDataset",
    "ResultDatasetWriter",
    "create_results_writer",
    "load_results_dataset",
    "HyraxDataset",
    "LSSTDataset",
    "DownloadedLSSTDataset",
    "HyraxRandomDataset",
    "HyraxRandomDatasetBase",
    "HyraxCSVDataset",
    "MultimodalUniverseDataset",
    "DataCache",
]
