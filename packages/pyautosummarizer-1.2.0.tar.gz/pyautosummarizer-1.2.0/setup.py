from setuptools import setup, find_packages
from pathlib import Path

this_directory    = Path(__file__).parent
long_description  = (this_directory / 'README.md').read_text()

# Core dependencies required for all extractive/abstractive methods and
# the classic evaluation metrics (ROUGE, BLEU, METEOR, BERTScore).
_install_requires = [
    'chardet',
    'numpy',
    'openai>=1.0',
    'regex',
    'scikit-learn',
    'sentence_transformers',
    'torch',
    'transformers>=4.30',
    'bert-score',
]

# Optional extras for faithfulness metrics.
# Install with:  pip install pyAutoSummarizer[faithfulness]
# AlignScore additionally requires: python -m spacy download en_core_web_sm
_extras_require = {
    'faithfulness': [
        'alignscore',
    ],
}

setup(
    name                          = 'pyautosummarizer',
    version                       = '1.2.0',
    license                       = 'GNU',
    author                        = 'Valdecy Pereira',
    author_email                  = 'valdecy.pereira@gmail.com',
    url                           = 'https://github.com/Valdecy/pyAutoSummarizer',
    python_requires               = '>=3.9',
    packages                      = find_packages(),
    include_package_data          = True,
    install_requires              = _install_requires,
    extras_require                = _extras_require,
    zip_safe                      = False,
    description                   = 'An Extractive and Abstractive Summarization Library Powered with Artificial Intelligence',
    long_description              = long_description,
    long_description_content_type = 'text/markdown',
    classifiers                   = [
        'Development Status :: 5 - Production/Stable',
        'Intended Audience :: Science/Research',
        'License :: OSI Approved :: GNU General Public License v3 (GPLv3)',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Topic :: Scientific/Engineering :: Artificial Intelligence',
        'Topic :: Text Processing :: Linguistic',
    ],
)
