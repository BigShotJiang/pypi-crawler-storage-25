############################################################################

# Created by: Prof. Valdecy Pereira, D.Sc.
# UFF - Universidade Federal Fluminense (Brazil)
# email:  valdecy.pereira@gmail.com
#pyAutoSummarizer - An Extractive and Abstractive Summarization Library Powered with Artificial Intelligence

# Citation: 
# PEREIRA, V. (2023). Project: pyAutoSummarizer, GitHub repository: <https://github.com/Valdecy/pyAutoSummarizer>

############################################################################

# Required Libraries
import chardet
import numpy as np
import openai 
import os
import re 
import regex
import unicodedata 

import importlib.resources as pkg_resources
from . import stws

from collections import Counter
from itertools import combinations
from sentence_transformers import SentenceTransformer 
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from transformers import BartTokenizer, BartForConditionalGeneration
from transformers import T5ForConditionalGeneration, T5Tokenizer
from transformers import PegasusForConditionalGeneration, PegasusTokenizer
from transformers import AutoTokenizer, AutoModelForSequenceClassification
import torch

############################################################################

class summarization():
    def __init__(self, text, stop_words = ['en'], n_words = 0, n_chars = 0, lowercase = True, rmv_accents = True, rmv_special_chars = True, rmv_numbers = True, rmv_custom_words = [], verbose = False):
        self.p_sw     = stop_words
        self.p_lc     = lowercase
        self.p_ra     = rmv_accents
        self.p_rc     = rmv_special_chars 
        self.p_rn     = rmv_numbers
        self.p_rw     = rmv_custom_words
        self.p_vb     = verbose
        self.limit_w  = n_words
        self.limit_c  = n_chars
        self.full_txt = text
        self.sw_full  = []
        pattern       = r'(?<!\b(?:Mr|Mrs|Ms|Dr|Prof|St|Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec|[A-Z]|[A-Z][a-z]|[a-z]))[.!?]\s+' # r'(?<=[.!?])\s+'
        if (self.limit_w <= 0 and self.limit_c <= 0):
            self.sentences = regex.split(pattern, text.strip()) 
            self.original  = regex.split(pattern, text.strip()) 
        else:
            self.sentences = self.split_sentences(words_per_sentence = self.limit_w, chars_per_sentence = self.limit_c)
            self.original  = self.split_sentences(words_per_sentence = self.limit_w, chars_per_sentence = self.limit_c)
        self.corpus    = self.clear_text(self.sentences, stop_words = self.p_sw, lowercase = self.p_lc, rmv_accents = self.p_ra, rmv_special_chars = self.p_rc, rmv_numbers = self.p_rn, rmv_custom_words = self.p_rw)
        self.txt       = '. '.join(self.corpus)
        self.sentences = regex.split(pattern, self.txt)
        for i in range(len(self.corpus)-1, -1, -1):
            self.corpus[i] = self.corpus[i].replace('.', '')
            if (self.corpus[i] == ''):
                del self.corpus[i]
                del self.sentences[i]
                del self.original[i]
        self.tokens        = []
        self.w_freq        = {}
        self.w_dist        = {}
        self.loaded_models = {}
        for i in range(0, len(self.corpus)):
            self.tokens.append(re.findall(r'\b\w+\b', self.corpus[i].lower()))
        self.vocabulary = set([token for s in self.tokens for token in s])
        self.all_tokens = [item for sublist in self.tokens for item in sublist]
        self.w_freq     = dict(Counter(self.all_tokens))
        total_w         = sum(self.w_freq.values())
        for token in self.vocabulary:
            self.w_dist[token] = self.w_freq[token] / total_w
   
    ##############################################################################

    # Function: Split Sentences
    def split_sentences(self, words_per_sentence = 7, chars_per_sentence = -1):
        words     = self.full_txt.split()
        num_words = len(words)
        if (chars_per_sentence > -1):
            words_per_sentence = num_words
        num_sentences = (num_words + words_per_sentence - 1) // words_per_sentence
        sentences     = []
        for i in range(0, num_sentences):
            start    = i * words_per_sentence
            end      = min((i + 1) * words_per_sentence, num_words)
            sentence = ' '.join(words[start:end])
            if (chars_per_sentence > -1 and len(sentence) > chars_per_sentence):
                sentence_parts = []
                part           = ''
                for word in sentence.split():
                    if (len(part) + len(word) + 1 > chars_per_sentence):
                        sentence_parts.append(part)
                        part = ''
                    part = part + (' ' if part else '') + word
                if (part):
                    sentence_parts.append(part)
                sentences.extend(sentence_parts)
            else:
                sentences.append(sentence)
        return sentences

    # Function: Show Summary
    def show_summary(self, rank, n = 3, verbose = False):
        idx       = np.argsort(rank)[::-1]
        self.summ = []
        if (n > len(rank)):
            n = len(rank)
        for i in range(0, n):
            sentence =  self.original[idx[i]]
            if (verbose == True):
                print(sentence)
            self.summ.append(sentence)
        self.summ = ' '.join(self.summ)
        return self.summ
    
    # Function: Text Pre-Processing
    def clear_text(self, corpus, stop_words = ['en'], lowercase = True, rmv_accents = True, rmv_special_chars = True, rmv_numbers = True, rmv_custom_words = [], verbose = False):
        self.sw_full = []
        # Lower Case
        if (lowercase == True):
            if (verbose == True):
                print('Lower Case: Working...')
            corpus = [str(x).lower().replace("’","'") for x in  corpus]
            if (verbose == True):
                print('Lower Case: Done!')
        # Replace Accents 
        if (rmv_accents == True):
            if (verbose == True):
                print('Removing Accents: Working...')
            for i in range(0, len(corpus)):
                text = corpus[i]
                try:
                    text = unicode(text, 'utf-8')
                except NameError: 
                    pass
                text      = unicodedata.normalize('NFD', text).encode('ascii', 'ignore').decode('utf-8')
                corpus[i] = str(text)
            if (verbose == True):
                print('Removing Accents: Done!')
        # Remove Punctuation & Special Characters
        if (rmv_special_chars == True):
            if (verbose == True):
                print('Removing Special Characters: Working...')
            corpus = [re.sub(r"[^a-zA-Z0-9']+", ' ', i) for i in corpus]
            if (verbose == True):
                print('Removing Special Characters: Done!')
        # Remove Stopwords
        if (len(stop_words) > 0):
            for sw_ in stop_words: 
                if   (sw_ == 'ar' or sw_ == 'ara' or sw_ == 'arabic'):
                    name = 'Stopwords-Arabic.txt'
                elif (sw_ == 'bn' or sw_ == 'ben' or sw_ == 'bengali'):
                    name = 'Stopwords-Bengali.txt'
                elif (sw_ == 'bg' or sw_ == 'bul' or sw_ == 'bulgarian'):
                    name = 'Stopwords-Bulgarian.txt'
                elif (sw_ == 'zh' or sw_ == 'chi' or sw_ == 'chinese'):
                    name = 'Stopwords-Chinese.txt'
                elif (sw_ == 'cs' or sw_ == 'cze' or sw_ == 'ces' or sw_ == 'czech'):
                    name = 'Stopwords-Czech.txt'
                elif (sw_ == 'en' or sw_ == 'eng' or sw_ == 'english'):
                    name = 'Stopwords-English.txt'
                elif (sw_ == 'fi' or sw_ == 'fin' or sw_ == 'finnish'):
                    name = 'Stopwords-Finnish.txt'
                elif (sw_ == 'fr' or sw_ == 'fre' or sw_ == 'fra' or sw_ ==  'french'):
                    name = 'Stopwords-French.txt'
                elif (sw_ == 'de' or sw_ == 'ger' or sw_ == 'deu' or sw_ ==  'german'):
                    name = 'Stopwords-German.txt'
                elif (sw_ == 'el' or sw_ == 'gre' or sw_ == 'greek'):
                    name = 'Stopwords-Greek.txt'
                elif (sw_ == 'he' or sw_ == 'heb' or sw_ == 'hebrew'):
                    name = 'Stopwords-Hebrew.txt'
                elif (sw_ == 'hi' or sw_ == 'hin' or sw_ == 'hind'):
                    name = 'Stopwords-Hindi.txt'
                elif (sw_ == 'hu' or sw_ == 'hun' or sw_ == 'hungarian'):
                    name = 'Stopwords-Hungarian.txt'
                elif (sw_ == 'it' or sw_ == 'ita' or sw_ == 'italian'):
                    name = 'Stopwords-Italian.txt'
                elif (sw_ == 'ja' or sw_ == 'jpn' or sw_ == 'japanese'):
                    name = 'Stopwords-Japanese.txt'
                elif (sw_ == 'ko' or sw_ == 'kor' or sw_ == 'korean'):
                    name = 'Stopwords-Korean.txt'
                elif (sw_ == 'mr' or sw_ == 'mar' or sw_ == 'marathi'):
                    name = 'Stopwords-Marathi.txt'
                elif (sw_ == 'fa' or sw_ == 'per' or sw_ == 'fas' or sw_ == 'persian'):
                    name = 'Stopwords-Persian.txt'
                elif (sw_ == 'pl' or sw_ == 'pol' or sw_ == 'polish'):
                    name = 'Stopwords-Polish.txt'
                elif (sw_ == 'pt-br' or sw_ == 'por-br' or sw_ == 'portuguese-br'):
                    name = 'Stopwords-Portuguese-br.txt'
                elif (sw_ == 'ro' or sw_ == 'rum' or sw_ == 'ron' or sw_ == 'romanian'):
                    name = 'Stopwords-Romanian.txt'
                elif (sw_ == 'ru' or sw_ == 'rus' or sw_ == 'russian'):
                    name = 'Stopwords-Russian.txt'
                elif (sw_ == 'sk' or sw_ == 'slo' or sw_ == 'slovak'):
                    name = 'Stopwords-Slovak.txt'
                elif (sw_ == 'es' or sw_ == 'spa' or sw_ == 'spanish'):
                    name = 'Stopwords-Spanish.txt'
                elif (sw_ == 'sv' or sw_ == 'swe' or sw_ == 'swedish'):
                    name = 'Stopwords-Swedish.txt'
                elif (sw_ == 'th' or sw_ == 'tha' or sw_ == 'thai'):
                    name = 'Stopwords-Thai.txt'
                elif (sw_ == 'uk' or sw_ == 'ukr' or sw_ == 'ukrainian'):
                    name = 'Stopwords-Ukrainian.txt'
                with pkg_resources.open_binary(stws, name) as file:
                    raw_data = file.read()
                result   = chardet.detect(raw_data)
                encoding = result['encoding']
                content  = raw_data.decode(encoding).split('\n')
                content  = [line.rstrip('\r').rstrip('\n') for line in content]
                sw      = list(filter(None, content))
                self.sw_full.extend(sw)
            if (verbose == True):
                print('Removing Stopwords: Working...')
            for i in range(0, len(corpus)):
               text      = corpus[i].split()
               text      = [x.replace(' ', '') for x in text if x.replace(' ', '') not in self.sw_full]
               corpus[i] = ' '.join(text) 
               if (verbose == True):
                   print('Removing Stopwords: ' + str(i + 1) +  ' of ' + str(len(corpus)) )
            if (verbose == True):
                print('Removing Stopwords: Done!')
        # Remove Custom Words
        if (len(rmv_custom_words) > 0):
            if (verbose == True):
                print('Removing Custom Words: Working...')
            for i in range(0, len(corpus)):
               text      = corpus[i].split()
               text      = [x.replace(' ', '') for x in text if x.replace(' ', '') not in rmv_custom_words]
               corpus[i] = ' '.join(text) 
               if (verbose == True):
                   print('Removing Custom Words: ' + str(i + 1) +  ' of ' + str(len(corpus)) )
            if (verbose == True):
                print('Removing Custom Word: Done!')
        # Remove Numbers
        if (rmv_numbers == True):
            if (verbose == True):
                print('Removing Numbers: Working...')
            corpus = [re.sub('[0-9]', ' ', i) for i in corpus] 
            if (verbose == True):
                print('Removing Numbers: Done!')
        for i in range(0, len(corpus)):
            corpus[i] = ' '.join(corpus[i].split())
        return corpus
    
    ##############################################################################
    
    # Function: Invert Rank    
    def invert_rank(self, rank):
        inverted_rank = [0] * len(rank)
        for i, r in enumerate(rank):
            inverted_rank[i] = len(rank) - 1 - r
        return inverted_rank
    
    # Function: Page Rank
    def page_rank(self, M, iteration = 1000, D = 0.85):
        N   = len(M)
        V   = np.full(N, 1 / N)
        V_  = V.copy() 
        _EPS = np.finfo(float).eps
        M_N = ( M - M.min() ) / ( M.max() - M.min() + _EPS)
        M_N = M_N/( M_N.sum(axis = 0) + _EPS)
        M_T = ( D * M_N + (1 - D) / N )
        for i in range(0, iteration):
            V = np.dot(M_T, V)
            if ( np.isnan(V).any() or np.isinf(V).any() ):
                break
            else:
                V_ = V.copy()
        return V_
    
    ##############################################################################
    
    # Function: TF
    def tf_matrix(self):
        vectorizer = CountVectorizer()
        vectorizer.fit(self.corpus)
        tf_matrix  = vectorizer.transform(self.corpus)
        tf_m       = tf_matrix.toarray()
        tf_m       = tf_m/np.sum(tf_m, axis = 1).reshape(-1, 1)
        #vectorizer.vocabulary_
        #vectorizer.get_feature_names()
        return tf_m
    
    # Function: IDF
    def idf_matrix(self):
        vectorizer = TfidfVectorizer(use_idf = True)
        vectorizer.fit(self.corpus)
        idf_m      = vectorizer.transform(self.corpus)
        idf_m      = vectorizer.idf_
        #vectorizer.vocabulary_
        return idf_m
    
    # Function: TF-IDF
    def tf_idf_matrix(self):
        vectorizer    = TfidfVectorizer()
        vectorizer.fit(self.corpus)
        tf_idf_matrix = vectorizer.transform(self.corpus)
        tf_idf_m      = tf_idf_matrix.toarray()
        #vectorizer.vocabulary_
        #vectorizer.get_feature_names()
        return tf_idf_m

    ##############################################################################

    # ROUGE N

    # Function: Rouge N 
    def rouge_N(self, generated_summary, reference_summary, n = 1):
        generated_summary = self.clear_text([generated_summary], stop_words = self.p_sw, lowercase = self.p_lc, rmv_accents = self.p_ra, rmv_special_chars = self.p_rc, rmv_numbers = self.p_rn, rmv_custom_words = self.p_rw)
        reference_summary = self.clear_text([reference_summary], stop_words = self.p_sw, lowercase = self.p_lc, rmv_accents = self.p_ra, rmv_special_chars = self.p_rc, rmv_numbers = self.p_rn, rmv_custom_words = self.p_rw)
        gen_tokens        = generated_summary[0].split()
        ref_tokens        = reference_summary[0].split()
        max_n             = min(len(gen_tokens), len(ref_tokens))
        if (n > max_n):
            n = max_n
        if (n > 1):
            gen_ngrams = set([tuple(gen_tokens[i:i + n]) for i in range(len(gen_tokens) - n + 1)]) 
            ref_ngrams = set([tuple(ref_tokens[i:i + n]) for i in range(len(ref_tokens) - n + 1)])
        else:
            gen_ngrams = set(gen_tokens)
            ref_ngrams = set(ref_tokens)
        if (len(gen_ngrams) == 0 or len(ref_ngrams) == 0):
            return 0, 0, 0
        overlap   = len(set(gen_ngrams).intersection(set(ref_ngrams)))
        precision = overlap / len(gen_ngrams) if len(gen_ngrams) > 0 else 0
        recall    = overlap / len(ref_ngrams) if len(ref_ngrams) > 0 else 0
        f1        = 2 * (precision * recall) / (precision + recall) if (precision + recall) > 0 else 0
        return f1, precision, recall

    ##############################################################################
    
    # ROUGE L
    
    # Function: LCS
    def LCS(self, gen_tokens, ref_tokens):
        if len(ref_tokens) < len(gen_tokens):
            ref_tokens, gen_tokens = gen_tokens, ref_tokens
        m, n     = len(ref_tokens), len(gen_tokens)
        prev_row = [0] * (n + 1)
        curr_row = [0] * (n + 1)
        for i in range(1, m + 1):
            for j in range(1, n + 1):
                if ref_tokens[i - 1] == gen_tokens[j - 1]:
                    curr_row[j] = prev_row[j - 1] + 1
                else:
                    curr_row[j] = max(prev_row[j], curr_row[j - 1])
            prev_row, curr_row = curr_row, [0] * (n + 1)
        long_c_s = prev_row[n]
        return long_c_s
        
    # Function: Rouge LCS
    def rouge_L(self, generated_summary, reference_summary):
        generated_summary = self.clear_text([generated_summary], stop_words = self.p_sw, lowercase = self.p_lc, rmv_accents = self.p_ra, rmv_special_chars = self.p_rc, rmv_numbers = self.p_rn, rmv_custom_words = self.p_rw)
        reference_summary = self.clear_text([reference_summary], stop_words = self.p_sw, lowercase = self.p_lc, rmv_accents = self.p_ra, rmv_special_chars = self.p_rc, rmv_numbers = self.p_rn, rmv_custom_words = self.p_rw)
        gen_tokens        = generated_summary[0].split()
        ref_tokens        = reference_summary[0].split()
        lcs_length        = self.LCS(gen_tokens, ref_tokens)
        precision         = lcs_length / len(gen_tokens) if len(gen_tokens) > 0 else 0
        recall            = lcs_length / len(ref_tokens) if len(ref_tokens) > 0 else 0
        f1                = 2 * (precision * recall) / (precision + recall) if (precision + recall) > 0 else 0
        return f1, precision, recall
    
    ##############################################################################
    
    # ROUGE S
    
    # Function: Generate Skip Gram
    def generate_skip_bigrams(self, tokens, skip_distance):
        skip_bigrams = set()
        tokens       = self.clear_text([tokens], stop_words = self.p_sw, lowercase = self.p_lc, rmv_accents = self.p_ra, rmv_special_chars = self.p_rc, rmv_numbers = self.p_rn, rmv_custom_words = self.p_rw)
        tokens       = tokens[0].split()
        for i in range(0, len(tokens)):
            for j in range(i+1, min(i+1+skip_distance, len(tokens))):
                skip_bigrams.add((tokens[i], tokens[j]))
        return skip_bigrams
    
    # Function: ROUGE S
    def rouge_S(self, generated_summary, reference_summary, skip_distance = 4):
        g_skip_bigrams = self.generate_skip_bigrams(generated_summary, skip_distance = skip_distance)
        r_skip_bigrams = self.generate_skip_bigrams(reference_summary, skip_distance = skip_distance)
        overlap        = len(set(g_skip_bigrams).intersection(set(r_skip_bigrams)))
        total_g        = len(g_skip_bigrams)
        total_r        = len(r_skip_bigrams)
        precision      = overlap / total_g if total_g > 0 else 0
        recall         = overlap / total_r if total_r > 0 else 0
        f1             = 2 * (precision * recall) / (precision + recall) if (precision + recall) > 0 else 0
        return f1, precision, recall

    ##############################################################################
    
    # BLEU
    
    # Function: Count N-Grams
    def count_ngrams(self, tokens, n):
        ngrams = {}
        if (n == 1):
            for i in range(0, len(tokens) - n + 1):
                ngram         = tokens[i:i+n][0]
                ngrams[ngram] = ngrams.get(ngram, 0) + 1
        else:
            for i in range(0, len(tokens) - n + 1):
                ngram         = tuple(tokens[i:i+n])
                ngrams[ngram] = ngrams.get(ngram, 0) + 1
        return ngrams
    
    # Function: Compute BLEU
    def compute_bleu(self, gen_tokens, ref_tokens, n):
        generated_ngrams = self.count_ngrams(gen_tokens, n)
        reference_ngrams = self.count_ngrams(ref_tokens, n)
        numerator        = sum(min(generated_ngrams[ngram], reference_ngrams.get(ngram, 0)) for ngram in generated_ngrams)
        denominator      = sum(generated_ngrams.values())
        c_bleu           = numerator / max(denominator, 1)
        return c_bleu
    
    # Function: BLEU Score
    def bleu(self, generated_summary, reference_summary, n = 4):
        generated_summary = self.clear_text([generated_summary], stop_words = self.p_sw, lowercase = self.p_lc, rmv_accents = self.p_ra, rmv_special_chars = self.p_rc, rmv_numbers = self.p_rn, rmv_custom_words = self.p_rw)
        reference_summary = self.clear_text([reference_summary], stop_words = self.p_sw, lowercase = self.p_lc, rmv_accents = self.p_ra, rmv_special_chars = self.p_rc, rmv_numbers = self.p_rn, rmv_custom_words = self.p_rw)
        gen_tokens        = generated_summary[0].split()
        ref_tokens        = reference_summary[0].split()
        bleu_n            = [self.compute_bleu(gen_tokens, ref_tokens, n + 1) for n in range(0, n)]
        gm                = [p for p in bleu_n if p != 0]
        if (len(gm) == 0):
            return 0.0
        gm                = np.exp(np.mean(np.log(gm)))   
        rt                = len(ref_tokens) / len(gen_tokens) if  len(gen_tokens) > 0 else 0
        bp                = min(1, np.exp(1 - rt)) # brevity penalty
        bleu_s            = bp * gm
        return bleu_s

    ##############################################################################
    
    # METEOR
    
    # Function: Match Tokens
    def match_tokens(self, gen_tokens, ref_tokens):
        matches  = 0
        ref_dict = {}
        for token in ref_tokens:
            if (token in ref_dict):
                ref_dict[token] = ref_dict[token] + 1
            else:
                ref_dict[token] = 1
        for token in gen_tokens:
            if (token in ref_dict and ref_dict[token] > 0):
                matches         = matches + 1
                ref_dict[token] = ref_dict[token] - 1
        return matches
    
    # Function: Number of Chunks
    def calculate_num_chunks(self, candidate_chunks, reference_chunks):
        num_chunks = 0
        for chunk in candidate_chunks:
            for ref_chunk in reference_chunks:
                if any(token in ref_chunk for token in chunk):
                    num_chunks = num_chunks + 1
                    break  
        return num_chunks
    
    # Function: Chunck Penalty
    def calculate_chunk_penalty(self, gen_tokens, ref_tokens, matches):
        candidate_chunks = set()
        reference_chunks = set()
        chunk_start      = None
        ref_chunk_start  = None
        ref_chunk_end    = None
        for i, candidate_word in enumerate(gen_tokens):
            if (candidate_word in ref_tokens):
                ref_index = ref_tokens.index(candidate_word)
                if (chunk_start is None):
                    chunk_start = i
                if (ref_chunk_start is None):
                    ref_chunk_start = ref_index
                ref_chunk_end = ref_index
            else:
                if (chunk_start is not None ):
                    candidate_chunks.add(tuple(range(chunk_start, i)))
                    chunk_start = None
                if (ref_chunk_start is not None and ref_chunk_end is not None):
                    reference_chunks.add(tuple(range(ref_chunk_start, ref_chunk_end + 1)))
                    ref_chunk_start = None
                    ref_chunk_end   = None
        if (chunk_start is not None):
            candidate_chunks.add(tuple(range(chunk_start, len(gen_tokens))))
        if (ref_chunk_start is not None and ref_chunk_end is not None):
            reference_chunks.add(tuple(range(ref_chunk_start, ref_chunk_end + 1)))
        num_chunks    = self.calculate_num_chunks(candidate_chunks, reference_chunks)
        chunk_penalty = 0 if matches == 0 else 0.5*(num_chunks / matches)**3
        return chunk_penalty
    
    # Function: METEOR Score
    def meteor(self, generated_summary, reference_summary, alpha = 0.9, beta = 3):
        generated_summary = self.clear_text([generated_summary], stop_words = self.p_sw, lowercase = self.p_lc, rmv_accents = self.p_ra, rmv_special_chars = self.p_rc, rmv_numbers = self.p_rn, rmv_custom_words = self.p_rw)
        reference_summary = self.clear_text([reference_summary], stop_words = self.p_sw, lowercase = self.p_lc, rmv_accents = self.p_ra, rmv_special_chars = self.p_rc, rmv_numbers = self.p_rn, rmv_custom_words = self.p_rw)
        gen_tokens        = generated_summary[0].split()
        ref_tokens        = reference_summary[0].split()
        matches           = self.match_tokens(gen_tokens, ref_tokens)
        precision         = matches / len(gen_tokens) if len(gen_tokens)> 0 else 0
        recall            = matches / len(ref_tokens) if len(ref_tokens)> 0 else 0
        if (precision == 0 or recall == 0):
            return 0
        fmean    = (precision * recall) / (alpha * precision + (1 - alpha) * recall)
        penalty  = self.calculate_chunk_penalty(gen_tokens, ref_tokens, matches)
        meteor_s = fmean * (1 - penalty**beta)
        return  meteor_s
    
        ##############################################################################
    
    # TextRank
    
    # Function: Sentence Embeddings
    def create_embeddings(self, model = 'all-MiniLM-L6-v2'):
        if (model not in self.loaded_models):
            self.loaded_models[model] = SentenceTransformer(model)
        embds = self.loaded_models[model].encode(self.corpus)
        return embds
    
    # Function: TextRank
    def summ_text_rank(self, iteration = 1000, D = 0.85, model = 'all-MiniLM-L6-v2'):
        embeddings = self.create_embeddings(model = model)
        sim_matrix = cosine_similarity(embeddings)
        rank       = self.page_rank(sim_matrix, iteration = iteration, D = D)
        return rank

    ##############################################################################
    
    # LexRank
    
    # Function: LexRank
    def summ_lex_rank(self, iteration = 1000, D = 0.85):
        tf_idf     = self.tf_idf_matrix()
        sim_matrix = cosine_similarity(tf_idf + 0.1) 
        rank       = self.page_rank(sim_matrix, iteration = iteration, D = D)
        return rank 
    
    ##############################################################################
    
    # LSA
    
    # Function: LSA
    def summ_ext_LSA(self, embeddings = True, model = 'all-MiniLM-L6-v2'):
        if (embeddings == True):
            X = self.create_embeddings(model = model)
        else:
            X = self.tf_idf_matrix()
        U, S, Vt = np.linalg.svd(X, full_matrices = True)
        rank     = np.copy(U[:, 0])
        return rank

    ##############################################################################
    
    # KL Divergence  
    
    # Function: Candidate Summary Distribution
    def cs_distribution(self, idx, vocab):
        tokens = []
        for i in idx:
            tokens.append(self.corpus[i].split())
        tokens = [word for sentence in tokens for word in sentence]
        q      = [tokens.count(word)/len(tokens) if word in tokens else 0 for word in vocab]
        return q 

    # Function: KL Divergence
    def KL_divergence(self, p, q):
        pq = [(p_i, q_i) for p_i, q_i in zip(p, q) if p_i > 0 and q_i > 0]
        KL = [p_i * np.log2(p_i / q_i) for p_i, q_i in pq]
        KL = sum(KL)
        return KL
    
    # Function: KL
    def summ_ext_KL(self, n = 3):
        _MAX_CORPUS = 50
        if n > len(self.corpus):
            raise ValueError(f"n = {n} cannot exceed number of sentences = {len(self.corpus)}")
        if (len(self.corpus) > _MAX_CORPUS):
            raise ValueError(
                f'summ_ext_KL: corpus has {len(self.corpus)} sentences, but exhaustive '
                f'search over C(n, {n}) combinations is only feasible for corpora up to '
                f'~{_MAX_CORPUS} sentences. Reduce the text or use a graph-based method instead.'
            )
        best_summary = None
        min_KL       = float('inf')
        vocab        = sorted(self.vocabulary)
        p            = [self.w_dist[word] for word in vocab]
        for candidate_summaries in combinations(range(0, len(self.corpus)), n):
            idx = [i for i in candidate_summaries]
            q   = self.cs_distribution(idx, vocab)
            KL  = self.KL_divergence(p, q)
            if (KL < min_KL):
                min_KL       = KL
                best_summary = [item for item in idx]
        rank     = [1 if x in best_summary else 0 for x in range(0, len(self.corpus))]
        rank_sum = sum(rank)
        for i in range(0, len(rank)):
            if (rank[i] == 1):
                rank[i]  = rank_sum
                rank_sum = rank_sum - 1
        rank = np.array(rank)
        return rank

    ##############################################################################   
    
    # BART
    
    # Function: BART
    def summ_ext_bart(self, model = 'facebook/bart-large-cnn', max_len = 250, verbose = False):
        tokenizer = BartTokenizer.from_pretrained(model)
        bart      = BartForConditionalGeneration.from_pretrained(model)
        inputs    = tokenizer([self.full_txt], max_length = 1024, truncation = True, padding = 'longest', return_tensors = 'pt')
        outputs   = bart.generate(inputs['input_ids'], num_beams = 4, max_length = max_len, early_stopping = True)
        summary   = tokenizer.decode(outputs[0], skip_special_tokens = True)
        self.summ = summary
        if (verbose == True):
            print(summary)
        return summary
        
    # T5
    
    # Function: T5       
    def summ_ext_t5(self, model = 't5-base', min_len = 30, max_len = 250, model_max_length = 512, verbose = False):
        tokenizer = T5Tokenizer.from_pretrained(model, model_max_length = model_max_length)
        t5_model  = T5ForConditionalGeneration.from_pretrained(model)
        inputs    = tokenizer.encode('summarize: ' + self.full_txt, return_tensors = 'pt', truncation = True)
        outputs   = t5_model.generate(inputs, min_length = min_len, max_length = max_len, num_beams = 4, no_repeat_ngram_size = 2)
        summary   = tokenizer.decode(outputs[0], skip_special_tokens = True)
        self.summ = summary
        if (verbose == True):
            print(summary)
        return summary
        
    ##############################################################################
    
    # PEGASUS
    
    # Function: PEGASUS
    def summ_abst_pegasus(self, model_name = 'google/pegasus-xsum', min_L = 100, max_L = 150, verbose = False):
        tokenizer = PegasusTokenizer.from_pretrained(model_name)
        pegasus   = PegasusForConditionalGeneration.from_pretrained(model_name)
        tokens    = tokenizer.encode('summarize: ' + self.full_txt, return_tensors = 'pt', max_length = 1024, truncation = True)
        summary   = pegasus.generate(tokens, min_length = min_L, max_length = max_L, length_penalty = 2.0, num_beams = 4, early_stopping = True)
        summary   = tokenizer.decode(summary[0], skip_special_tokens = True)
        self.summ = summary 
        if (verbose == True):
            print(summary)
        return summary
    
    # chatGPT
    
    # Function: chatGPT
    def summ_abst_chatgpt(self, api_key = 'your_api_key_here', query = 'make an abstractive summarization', model = 'gpt-4o-mini', max_tokens = 250, n = 1, temperature = 0.8, verbose = False):
        os.environ['OPENAI_API_KEY'] = api_key
        prompt                       = query + ':\n\n' + f'{self.full_txt}\n'
        
        def query_chatgpt(prompt, model = model, max_tokens = max_tokens, n = n, temperature = temperature):
            client   = openai.OpenAI(api_key = api_key)
            response = client.chat.completions.create(
                model      = model,
                messages   = [{'role': 'user', 'content': prompt}],
                max_tokens = max_tokens
            )
            return response.choices[0].message.content
        
        summary   = query_chatgpt(prompt)
        self.summ = summary
        if (verbose == True):
            print(summary)
        return summary

    ##############################################################################

    # BERTScore

    # Function: BERTScore
    # Computes token-level semantic similarity between generated and reference summaries
    # using contextualised BERT embeddings. Returns (F1, Precision, Recall).
    # Requires: pip install bert-score
    def bert_score(self, generated_summary, reference_summary, model_type = 'roberta-large', verbose = False):
        try:
            from bert_score import score as _bs
        except ImportError:
            raise ImportError("bert-score is required: pip install bert-score")
        P, R, F1 = _bs(
            cands   = [generated_summary],
            refs    = [reference_summary],
            model_type = model_type,
            verbose    = verbose
        )
        f1        = float(F1[0])
        precision = float(P[0])
        recall    = float(R[0])
        if (verbose == True):
            print(f'BERTScore  F1={f1:.4f}  P={precision:.4f}  R={recall:.4f}')
        return f1, precision, recall

    ##############################################################################

    # SummaC

    # Function: SummaC
    # Measures factual consistency (faithfulness) of the generated summary against the
    # source document using an NLI model. Score in [0, 1]; higher = more faithful.
    # This implementation is self-contained and uses a lightweight cross-encoder NLI
    # model from HuggingFace so no extra pip install is needed beyond transformers.
    def summa_c(self, generated_summary, nli_model = 'cross-encoder/nli-deberta-v3-small', granularity = 'sentence', verbose = False):
        _cache_key = f'summac_nli_{nli_model}'
        if (_cache_key not in self.loaded_models):
            tokenizer = AutoTokenizer.from_pretrained(nli_model)
            model     = AutoModelForSequenceClassification.from_pretrained(nli_model)
            model.eval()
            self.loaded_models[_cache_key] = (tokenizer, model)
        tokenizer, model = self.loaded_models[_cache_key]
        # Split source into chunks based on granularity
        if (granularity == 'sentence'):
            import regex as _re
            _pattern = r'(?<![.!?])[.!?]\s+'
            chunks   = _re.split(_pattern, self.full_txt.strip())
            chunks   = [c.strip() for c in chunks if c.strip()]
        else:
            chunks = [self.full_txt]
        # Score each source chunk against the generated summary, take max (soft alignment)
        chunk_scores = []
        for chunk in chunks:
            enc = tokenizer(
                chunk, generated_summary,
                return_tensors   = 'pt',
                truncation       = True,
                max_length       = 512,
                padding          = True
            )
            with torch.no_grad():
                logits = model(**enc).logits
            probs  = torch.softmax(logits, dim = -1)[0]
            labels = model.config.id2label
            # DeBERTa NLI label order: contradiction=0, neutral=1, entailment=2
            entail_idx = next((i for i, l in labels.items() if 'entail' in l.lower()), 2)
            chunk_scores.append(float(probs[entail_idx]))
        score = float(np.mean(chunk_scores))
        if (verbose == True):
            print(f'SummaC score (mean entailment): {score:.4f}')
        return score

    ##############################################################################

    # AlignScore

    # Function: AlignScore
    # Evaluates factual consistency using the AlignScore unified alignment function.
    # Requires: pip install alignscore  (and then: python -m spacy download en_core_web_sm)
    # Paper: Zha et al., ACL 2023.
    def align_score(self, generated_summary, model = 'AlignScore-base', device = 'cpu', verbose = False):
        try:
            from alignscore import AlignScore as _AlignScore
        except ImportError:
            raise ImportError(
                "alignscore is required: pip install alignscore\n"
                "Then run: python -m spacy download en_core_web_sm"
            )
        _cache_key = f'alignscore_{model}_{device}'
        if (_cache_key not in self.loaded_models):
            self.loaded_models[_cache_key] = _AlignScore(
                model           = model,
                batch_size      = 1,
                device          = device,
                evaluation_mode = 'nli_sp'
            )
        scorer = self.loaded_models[_cache_key]
        score  = scorer.score(contexts = [self.full_txt], claims = [generated_summary])[0]
        if (verbose == True):
            print(f'AlignScore: {score:.4f}')
        return float(score)

    ##############################################################################

    # G-Eval

    # Function: G-Eval
    # LLM-as-judge: uses an OpenAI chat model to score the generated summary across
    # four dimensions on a 1–5 scale. Returns a dict {dimension: score}.
    # Paper: Liu et al., 2023 (GPTEval / G-Eval).
    # Requires an OpenAI API key.
    def g_eval(self, generated_summary, api_key, model = 'gpt-4o-mini', dimensions = None, verbose = False):
        _prompts = {
            'coherence':   (
                'Rate the COHERENCE of the summary below on a scale of 1 to 5, '
                'where 1 = completely incoherent and 5 = perfectly coherent and well-structured. '
                'Reply with a single digit only.\n\n'
                'Source:\n{src}\n\nSummary:\n{summ}'
            ),
            'consistency': (
                'Rate the FACTUAL CONSISTENCY of the summary below with respect to the source '
                'on a scale of 1 to 5, where 1 = many hallucinations or contradictions and '
                '5 = fully faithful to the source. Reply with a single digit only.\n\n'
                'Source:\n{src}\n\nSummary:\n{summ}'
            ),
            'fluency':     (
                'Rate the FLUENCY and grammaticality of the summary below on a scale of 1 to 5, '
                'where 1 = unreadable and 5 = fluent and error-free. '
                'Reply with a single digit only.\n\nSummary:\n{summ}'
            ),
            'relevance':   (
                'Rate the RELEVANCE of the summary below to the source text on a scale of 1 to 5, '
                'where 1 = captures nothing important and 5 = captures all key information. '
                'Reply with a single digit only.\n\n'
                'Source:\n{src}\n\nSummary:\n{summ}'
            ),
        }
        if (dimensions is None):
            dimensions = list(_prompts.keys())
        invalid = [d for d in dimensions if d not in _prompts]
        if (invalid):
            raise ValueError(f"Unknown dimension(s): {invalid}. Choose from: {list(_prompts.keys())}")
        os.environ['OPENAI_API_KEY'] = api_key
        client = openai.OpenAI(api_key = api_key)
        scores = {}
        for dim in dimensions:
            prompt   = _prompts[dim].format(src = self.full_txt, summ = generated_summary)
            response = client.chat.completions.create(
                model       = model,
                messages    = [{'role': 'user', 'content': prompt}],
                max_tokens  = 5,
                temperature = 0.0
            )
            raw = response.choices[0].message.content.strip()
            try:
                scores[dim] = int(raw[0])
            except (ValueError, IndexError):
                scores[dim] = None
        if (verbose == True):
            for k, v in scores.items():
                print(f'G-Eval {k}: {v}/5')
        return scores

    ##############################################################################