"""Movement model helpers."""
