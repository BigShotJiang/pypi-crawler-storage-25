"""Vision model helpers."""
