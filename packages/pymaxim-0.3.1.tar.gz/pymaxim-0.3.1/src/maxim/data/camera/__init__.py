"""Camera-related utilities."""
