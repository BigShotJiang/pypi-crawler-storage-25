# src/py_async_log/core.py
import logging
import logging.handlers
import multiprocessing
from typing import Optional

# --- 模块级全局变量，模块变量法；
# 模块级全局变量在 Python 中是天然且最正宗的单例模式
# 在 Python 的设计哲学里，模块（Module）本身就是对象，而且它们在同一个进程中只会被加载和执行一次。
# 运行模块代码，并将生成的对象、函数和变量放入一个缓存字典中（即 sys.modules） ---
_instance = None


def _worker_configurer_internal(queue, level):
    h = logging.handlers.QueueHandler(queue)
    root = logging.getLogger()
    root.handlers.clear()
    # 清除旧的 handler
    for handler in root.handlers[:]:
        root.removeHandler(handler)
    root.addHandler(h)
    root.setLevel(level)


class AsyncLogManager:
    def __init__(self, filename: str, level: int = logging.INFO):
        self.filename = filename
        self.level = level
        self._manager = multiprocessing.Manager()
        self.queue = self._manager.Queue(-1)
        self._listener: Optional[logging.handlers.QueueListener] = None

    def start_logging(self):
        """在主进程中启动监听器"""
        # 配置主进程的最终写入方式
        handler = logging.FileHandler(self.filename, encoding="utf-8")
        formatter = logging.Formatter(
            "%(asctime)s [%(levelname)s] [%(processName)s-%(threadName)s] %(message)s"
        )
        handler.setFormatter(formatter)

        # 启动监听线程
        self._listener = logging.handlers.QueueListener(self.queue, handler)
        self._listener.start()

    def get_worker_config_args(self):
        """返回子进程初始化所需的参数包"""
        # 不返回函数，而是返回 (函数, 参数) 的元组，或者只返回参数
        return _worker_configurer_internal, (self.queue, self.level)

    def stop_logging(self):
        if self._listener:
            self._listener.stop()
        self._manager.shutdown()  # 显式关闭 Manager


# --- 显式的单例获取函数，模块变量法 (推荐Explicit is better than implicit 显式优于隐式) ---
def get_manager(filename: str = "app.log", level: int = 20) -> AsyncLogManager:
    """显式的单例获取函数"""
    global _instance
    if _instance is None:
        _instance = AsyncLogManager(filename, level)
    return _instance
