from .core import AsyncLogManager, get_manager

__version__ = "0.1.0"

# --- 导出的符号,__all__ 控制 import * 的行为，是一个非常重要的导出控制变量。
# 当别人使用 from package import * 时，哪些内容会被导入;
# __all__ 依然是定义包入口（Public API）的标准方式---
# 导出 AsyncLogManager 和 get_manager 函数
__all__ = ["AsyncLogManager", "get_manager"]
