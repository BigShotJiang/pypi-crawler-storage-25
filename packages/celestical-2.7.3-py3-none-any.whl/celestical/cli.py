"""The CLI to interface with the Celestical European Serverless Cloud."""
from typing import Optional
from pathlib import Path
import typer

from celestical.utils.display import (cli_panel, print_console, print_text,
    print_warning, read_wait, print_space)
from celestical.config import Config
from celestical.config.cli_config import FallbackGroup
from celestical.session import Session
from celestical.session.commands import add_session_commands
from celestical.user import User
#from celestical.commands.select import Select
# Prepare is Enrich+etc
#from celestical.commands.prepare import Prepare
from celestical.docker.docker import DockerMachine
from celestical.utils.version_check import check_cli_version
from celestical.utils.prompts import prompt_user

# --- new eventually for-testing imports
from celestical.app.app import App
import celestical.dashboard.layout as dashistical 


# ----------- Startup setup
user = User()
user.config.logger.info(" ======= Starting Celestical TUI (single encryption).")
openssl_version="unknown"
try:
    import ssl
    openssl_version = ssl.OPENSSL_VERSION
    user.config.logger.info(f"  - OpenSSL version: {ssl.OPENSSL_VERSION}")
except Exception as all_possible:
    user.config.logger.warning(all_possible)
    # and continue as usual.


# ----------- Setting up global App
app = typer.Typer(pretty_exceptions_short=False,
                  no_args_is_help=False,
                  context_settings={
                      "help_option_names": ["-h", "--help"]},
                  help=user.welcome(),
                  rich_markup_mode="rich",
                  cls=FallbackGroup)

# TODO inject config with base arguments
#   config = Config(host=api_host, scheme=api_scheme)

# --- Add session commands like login and register
add_session_commands(app)


@app.callback(invoke_without_command=True)
def dashboard_up(ctx: typer.Context) -> bool:
    """ This function runs only and before when user calls commands
    no_args_is_help must be False and invoke_without_command must be True.

    no_args_is_help might be necessary to define the context of the app.

    This is by default launching the dashboard
    """
    # print_console(user.welcome())
    if ctx.invoked_subcommand is not None:
        return False

    print_text(f"[grey50]Launching dashboard[/grey50]")
    dashboard = dashistical.Dashboard()
    dashboard.run()

    return True


@app.command()
def version():
    """ Print one line version information """
    oneliner = f"celestical {user.current_celestical_version}"
    oneliner += f" (deps: {openssl_version})"
    print(oneliner)


@app.command()
def deploy(compose_path: Optional[str] =
             typer.Argument(
                 default="./",
                 help="Path(str) to compose file. Default current directory"),
           api_host: Optional[str] =
             typer.Option(
                 default="",
                 help="Custom host (including port) for API connections. "
                 + "Mostly used for testing."),
           api_scheme: Optional[str] =
             typer.Option(
                 default="",
                 help="Custom connection scheme; http or https. "
                 + "Mostly used for testing.")):
    """ Select or create, prepare and push your applications
    (docker-compose.yml) to the Celestical Cloud.

        Deploy can work without parameters, it would take as default the working
        directory (where the command is called from) as parameter and look for
        standard docker-compose.yml files.
        If nothing is found in the current directory or in the given directory
        messages will be printed to the users for help.

    Parameters:
        - compose_path: string path to the compose file or its directory
        - api_host: mostly used for testing or celestical enterprise instances
        - api_scheme: mosted used for testing, default to https
    """
    # Check CLI version compatibility before proceeding
    if not check_cli_version():
        raise typer.Exit(1)

    # Before we event start the session we know what we need
    compose_file = Path(compose_path)
    if not compose_file.is_dir():  # covers "./" use-case
        if not compose_file.is_file():
            msg = f"{compose_path} file is not found"
            if compose_file.is_dir():
                msg = f"{compose_path} is a folder"
            print_warning(msg)
            read_wait()
            raise typer.Exit(1)

    # Configuration setup and connectivity
    config = None
    if len(api_host) > 3 or len(api_scheme) > 3:
        config = Config(host=api_host, scheme=api_scheme)

    session = Session(needs_login=True, config=config)

    is_deployed = False
    if session.select_app() is True:
        # Enrich using the input compose file
        if not session.check_docker_service():
            print_space()
            msg = "Docker is not running: "
            msg += "please start your docker local service."
            print_warning(msg)
            read_wait()
            prompt_user("Hit enter when ready")
        if session.app.enrich(compose_path):
            # Push (and deploy) the necessary images
            is_deployed = session.app.push()

    app_domain = session.app.compose.get("base_domain")
    msg = f"[green]All images successfully uploaded[/green] for: {app_domain}"
    msg += "\n\nCheck the celestical dashboard with command:"
    msg += "\n    [yellow]celestical[/yellow]"
    if not is_deployed:
        msg = "Nothing has been deployed yet. Please follow given instructions."

    print_space() 
    cli_panel(msg, title="Deployed status")
