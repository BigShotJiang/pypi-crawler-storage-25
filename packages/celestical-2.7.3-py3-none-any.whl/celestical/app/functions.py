from celestical.api.exceptions import UnauthorizedException
from celestical import api
from celestical.utils.display import (
    print_text, write_app_row,
    print_console, cli_panel)

def get_apps_list(
        user,
        config,
        call_nbr: int = 1,
        start_index: int = 1) -> (dict, str):
    """ Get the list of apps for given user from celestical cloud.

        Returns:
            - dict of api.models.app.App
              or an empty dict if user not be logged in or other issues arise.
              this should never return None but rather an empty dictionary.
            - status return from: nouser, noconf, noapi, unauthorized,
              unreachable, ok
    """
    if user is None:
        return {}, "nouser"

    if user is None:
        return {}, "noconf"

    apiconf = user.get_api_with_auth()
    if apiconf is None:
        return {}, "noapi"

    api_response = None
    with api.ApiClient(apiconf) as api_client:
        app_api = api.AppApi(api_client)

        try:
            api_response = app_api.get_user_apps_app_get()
        except UnauthorizedException as oops:
            config.logger.debug(oops)
            if call_nbr >= 2:
                return {}, "unauthorized"
            call_nbr += 1
            return get_apps_list(user, config, call_nbr)
        except Exception as oops:
            config.logger.debug(oops)
            return {}, "unreachable"

    res = api_response
    if isinstance(api_response, api.models.app.App):
        res = [api_response]
    # it must be a list already

    dres = {}
    app_nb = start_index
    for item in res:
        # keeping the whole api.models.App objects as is
        dres[str(app_nb)] = item
        app_nb += 1

    return dres, "ok"

