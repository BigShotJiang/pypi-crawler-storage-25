import typer
from celestical.utils.display import (cli_panel, print_console,
    print_text, print_error)
from celestical.session import Session
from celestical.utils.version_check import check_cli_version

def add_session_commands(app: typer.Typer) -> bool:
    if app is None:
        return False 

    @app.command()
    def login() -> None:
        """Login to Celestical Cloud Services via the CLI.
            The session is explicitly set to force relogin.
            After successful login, automatically launches the dashboard.
        """
        # Check CLI version compatibility before proceeding
        if not check_cli_version():
            raise typer.Exit(1)

        session = Session(needs_login=True, force_login=True)
        if session.user is not None:
            print_console(session.user.to_rich())

    @app.command()
    def logout() -> None:
        """Logout to Celestical Cloud Services via the CLI.
        """
        # Check CLI version compatibility before proceeding
        if not check_cli_version():
            raise typer.Exit(1)

        session = Session(needs_login=False, force_login=False)
        session.logout()
        print_console("Logged out.")

    @app.command()
    def register():
        """Register as a user for Celestical Cloud Services via the CLI."""
        session = Session(needs_login=False, force_login=False)
        flag, username = session.user.user_register()
        config = session.user.config.load_config()
        if flag == 0:
            print_error("User could not be created.")
        if flag in (1, 3):
            msg = ""
            if config['username'] != username:
                msg = "You can now switch user to "
            else:
                msg = "You can now login with user "
            msg += f"[yellow]{username}[/yellow] using [blue]celestical login[/blue]"
            cli_panel(msg)
            
    return True
