// Licensed to the Apache Software Foundation (ASF) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The ASF licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

mod mode;
pub use mode::EntryMode;

mod buffer;
pub use buffer::Buffer;

mod entry;
pub use entry::Entry;

mod metadata;
pub use metadata::Metadata;

mod read;
pub use read::*;

mod write;
pub use write::*;

mod list;
pub use list::Lister;

mod delete;
pub use delete::*;

mod execute;
pub use execute::*;

mod operator;
pub use operator::IntoOperatorUri;
pub use operator::Operator;
pub use operator::OperatorBuilder;
pub use operator::OperatorFactory;
pub use operator::OperatorInfo;
pub use operator::OperatorRegistry;
pub use operator::OperatorUri;
pub use operator::operator_futures;

mod builder;
pub use builder::Builder;
pub use builder::Configurator;

mod error;
pub use error::Error;
pub use error::ErrorKind;
pub use error::Result;

mod capability;
pub use capability::Capability;

pub mod options;

mod context;
pub(crate) use context::*;
