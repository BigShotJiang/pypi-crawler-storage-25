"""Test suite for pl4pm.sim — benchmarking pm4py vs pl4pm."""
from __future__ import annotations

from typing import Any

import polars as pl
import pytest

import pm4py
import pl4pm

from _filter_read_support import ACTIVITY, CASE_ID, TIMESTAMP, print_perf, synthetic_logs, timed_call


def _maybe_timed_pm4py(label: str, func_name: str, *args, **kwargs):
    func = getattr(pm4py, func_name, None)
    if func is None:
        print(f"{label} pm4py skipped (AttributeError: missing {func_name})")
        return None, None
    try:
        return timed_call(func, *args, **kwargs)
    except Exception as exc:
        print(f"{label} pm4py skipped ({type(exc).__name__}: {exc})")
        return None, None


def _normalize_playout(log: Any) -> list[dict[str, Any]]:
    if hasattr(log, "lazy"):
        df = log.collect() if isinstance(log, pl.LazyFrame) else log
    else:
        df = pl.from_pandas(pm4py.convert_to_dataframe(log), include_index=False)
    if df.is_empty():
        return []
    df = df.sort([CASE_ID, TIMESTAMP, ACTIVITY])
    grouped = (
        df.group_by(CASE_ID)
        .agg(pl.col(ACTIVITY).alias("activities"))
        .sort(CASE_ID)
    )
    return grouped.to_dicts()


def _label_set(rows: list[dict[str, Any]]) -> set[str]:
    return {activity for row in rows for activity in row["activities"]}


@pytest.fixture(scope="session")
def sim_models(synthetic_logs):
    models = []
    for info in synthetic_logs:
        first_case = info.standard_lazy.select(pl.col(CASE_ID).first()).collect().item()
        first_case_df = info.standard_lazy.filter(pl.col(CASE_ID) == first_case).collect()
        first_case_pm = info.pm_df[info.pm_df[CASE_ID] == first_case]

        pm_tree = pm4py.discover_process_tree_inductive(first_case_pm)
        pm_net = pm4py.discover_petri_net_inductive(first_case_pm)
        pm_dfg = pm4py.discover_dfg(first_case_pm)

        pl_tree_raw = pl4pm.discover_process_tree_inductive(first_case_df)
        pl_net = pl4pm.convert_to_petri_net(pl_tree_raw)
        pl_tree = pl4pm.convert_to_process_tree(*pl_net)
        pl_dfg = pl4pm.discover_dfg(first_case_df)

        expected = (
            first_case_df.sort(TIMESTAMP)
            .select([CASE_ID, ACTIVITY, TIMESTAMP])
            .group_by(CASE_ID)
            .agg(pl.col(ACTIVITY).alias("activities"))
            .to_dicts()
        )

        models.append(
            {
                "pm_tree": pm_tree,
                "pm_net": pm_net,
                "pm_dfg": pm_dfg,
                "pl_tree": pl_tree,
                "pl_net": pl_net,
                "pl_dfg": pl_dfg,
                "expected": expected,
                "expected_labels": _label_set(expected),
            }
        )
    return models


@pytest.mark.parametrize("log_index", range(10))
def test_play_out_process_tree(synthetic_logs, sim_models, log_index):
    info = synthetic_logs[log_index]
    pm_tree = sim_models[log_index]["pm_tree"]
    pl_tree = sim_models[log_index]["pl_tree"]
    expected_labels = sim_models[log_index]["expected_labels"]

    pm_result, pm_time = _maybe_timed_pm4py(
        f"{info.name}:play_out_process_tree",
        "play_out",
        pm_tree,
        parameters={"no_traces": 20},
    )
    pl_result, pl_time = timed_call(pl4pm.play_out, pl_tree, n_traces=20)
    pl_lazy_result, pl_lazy_time = timed_call(lambda: pl4pm.play_out(pl_tree, n_traces=20).lazy())

    pl_norm = _normalize_playout(pl_result)
    assert len(pl_norm) == 20
    assert all(item["activities"] for item in pl_norm)
    assert all(set(item["activities"]).issubset(expected_labels) for item in pl_norm)

    print_perf(f"{info.name}:play_out_process_tree", pm_time, pl_time, pl_lazy_time)


@pytest.mark.parametrize("log_index", range(10))
def test_play_out_petri_net(synthetic_logs, sim_models, log_index):
    info = synthetic_logs[log_index]
    pm_net, pm_im, pm_fm = sim_models[log_index]["pm_net"]
    pl_net, pl_im, pl_fm = sim_models[log_index]["pl_net"]
    expected_labels = sim_models[log_index]["expected_labels"]

    pm_result, pm_time = _maybe_timed_pm4py(
        f"{info.name}:play_out_petri_net",
        "play_out",
        pm_net,
        pm_im,
        pm_fm,
        parameters={"no_traces": 20, "max_trace_length": 200},
    )
    pl_result, pl_time = timed_call(pl4pm.play_out, pl_net, pl_im, pl_fm, n_traces=20)
    pl_lazy_result, pl_lazy_time = timed_call(lambda: pl4pm.play_out(pl_net, pl_im, pl_fm, n_traces=20).lazy())

    pl_norm = _normalize_playout(pl_result)
    assert len(pl_norm) == 20
    assert all(item["activities"] for item in pl_norm)
    assert all(set(item["activities"]).issubset(expected_labels) for item in pl_norm)

    print_perf(f"{info.name}:play_out_petri_net", pm_time, pl_time, pl_lazy_time)


@pytest.mark.parametrize("log_index", range(10))
def test_play_out_dfg(synthetic_logs, sim_models, log_index):
    info = synthetic_logs[log_index]
    expected_labels = sim_models[log_index]["expected_labels"]
    pm_dfg = sim_models[log_index]["pm_dfg"]
    pl_dfg = sim_models[log_index]["pl_dfg"]

    pm_result, pm_time = _maybe_timed_pm4py(
        f"{info.name}:play_out_dfg",
        "play_out",
        pm_dfg[0],
        pm_dfg[1],
        pm_dfg[2],
        parameters={"max_no_variants": 20},
    )
    pl_result, pl_time = timed_call(pl4pm.play_out, pl_dfg[0], n_traces=20, start_activities=pl_dfg[1], end_activities=pl_dfg[2])
    pl_lazy_result, pl_lazy_time = timed_call(lambda: pl4pm.play_out(pl_dfg[0], n_traces=20, start_activities=pl_dfg[1], end_activities=pl_dfg[2]).lazy())

    pl_norm = _normalize_playout(pl_result)
    assert len(pl_norm) == 20
    assert all(item["activities"] for item in pl_norm)
    assert all(set(item["activities"]).issubset(expected_labels) for item in pl_norm)

    print_perf(f"{info.name}:play_out_dfg", pm_time, pl_time, pl_lazy_time)
