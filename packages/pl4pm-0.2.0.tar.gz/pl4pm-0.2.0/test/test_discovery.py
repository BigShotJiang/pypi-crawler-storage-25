from __future__ import annotations

import polars as pl
import pytest

import pm4py
import pl4pm

from _filter_read_support import (
    print_perf,
    record_mismatch,
    synthetic_logs,
    timed_call,
    normalize_dfg,
    normalize_petri_net,
    normalize_tree,
    normalize_bpmn,
)

DISCOVERY_CASES = [
    ("discover_dfg", normalize_dfg),
    ("discover_petri_net_alpha", normalize_petri_net),
    ("discover_process_tree_inductive", normalize_tree),
    ("discover_petri_net_inductive", normalize_petri_net),
    ("discover_bpmn_inductive", normalize_bpmn),
]

@pytest.mark.parametrize("func_name,normalizer", DISCOVERY_CASES)
@pytest.mark.parametrize("log_index", range(10))
def test_discovery_matches_pm4py_and_lazy(synthetic_logs, func_name, normalizer, log_index):
    info = synthetic_logs[log_index]
    
    pl_func = getattr(pl4pm, func_name)
    pm_func = getattr(pm4py, func_name)

    pm_input = info.pm_df
    
    # Executing the Discovery Functions
    pm_result, pm_time = timed_call(pm_func, pm_input)
    pl_df_result, pl_df_time = timed_call(pl_func, info.standard_lazy)
    pl_lazy_result, pl_lazy_time = timed_call(pl_func, info.standard_lazy)

    # Normalize Outputs to ensure structural ID parity
    pm_normalized = normalizer(pm_result)

    pl_df_normalized = normalizer(pl_df_result)
    pl_lazy_normalized = normalizer(pl_lazy_result)

    if pl_df_normalized != pm_normalized:
        record_mismatch(
            f"{info.name}:{func_name}",
            pm_normalized,
            pl_df_normalized,
            pl_lazy_normalized,
        )

    assert pl_df_normalized == pm_normalized
    assert pl_lazy_normalized == pm_normalized

    print_perf(f"{info.name}:{func_name}", pm_time, pl_df_time, pl_lazy_time)
