"""Test suite for pl4pm.ml — benchmarking pm4py vs pl4pm DF vs Lazy."""
from __future__ import annotations

import random
from typing import Any

import polars as pl
import pytest

import pm4py
import pl4pm

from _filter_read_support import (
    ACTIVITY,
    CASE_ID,
    normalize_ocel,
    normalize_table,
    print_perf,
    record_mismatch,
    synthetic_logs,
    timed_call,
)


def _maybe_timed_pm4py(label: str, func_name: str, *args, **kwargs):
    func = getattr(pm4py, func_name, None)
    if func is None:
        print(f"{label} pm4py skipped (AttributeError: missing {func_name})")
        return None, None
    try:
        return timed_call(func, *args, **kwargs)
    except Exception as exc:
        print(f"{label} pm4py skipped ({type(exc).__name__}: {exc})")
        return None, None


def _normalize_target(result: tuple[Any, list[str]]) -> dict[str, Any]:
    values, classes = result
    return {"values": [str(v) for v in values], "classes": sorted(str(c) for c in classes)}


def _normalize_temporal_shared(obj: Any) -> list[dict[str, str]]:
    rows = normalize_table(obj)
    shared_rows: list[dict[str, str]] = []
    for row in rows:
        shared_rows.append(
            {
                "n_events": row.get("n_events", row.get("num_events", "")),
                "n_cases": row.get("n_cases", row.get("number_of_cases", "")),
                "n_unique_activities": row.get("n_unique_activities", row.get("unique_activities", "")),
                "n_unique_resources": row.get("n_unique_resources", row.get("unique_resources", "")),
                "events_per_case": row.get("events_per_case", row.get("avg_events_per_case", "")),
            }
        )
    return shared_rows


def _expected_target(info, variant: str) -> dict[str, Any]:
    df = info.standard_lazy.sort([CASE_ID, "time:timestamp"])

    if variant == "next_activity":
        result = (
            df.with_columns(pl.col(ACTIVITY).shift(-1).over(CASE_ID).alias("_next"))
            .filter(pl.col("_next").is_not_null())
            .collect()
        )
        values = [str(value) for value in result.get_column("_next").to_list()]
        return {"length": len(values), "classes": sorted(set(values))}

    if variant == "next_time":
        result = (
            df.with_columns(pl.col("time:timestamp").shift(-1).over(CASE_ID).alias("_next_ts"))
            .filter(pl.col("_next_ts").is_not_null())
            .with_columns(
                (pl.col("_next_ts") - pl.col("time:timestamp")).dt.total_seconds().alias("_delta")
            )
            .collect()
        )
        values = result.get_column("_delta").to_list()
        return {
            "length": len(values),
            "all_non_negative": all(float(value) >= 0.0 for value in values),
        }

    if variant == "remaining_time":
        result = (
            df.with_columns(pl.col("time:timestamp").max().over(CASE_ID).alias("_end"))
            .with_columns((pl.col("_end") - pl.col("time:timestamp")).dt.total_seconds().alias("_remaining"))
            .collect()
        )
        values = result.get_column("_remaining").to_list()
        last_values = (
            result.group_by(CASE_ID)
            .agg(pl.col("_remaining").last().alias("_last_remaining"))
            .get_column("_last_remaining")
            .to_list()
        )
        return {
            "length": len(values),
            "all_non_negative": all(float(value) >= 0.0 for value in values),
            "all_case_ends_zero": all(float(value) == 0.0 for value in last_values),
        }

    raise ValueError(f"Unsupported variant: {variant}")


@pytest.fixture(scope="session")
def ml_ocels(synthetic_logs):
    ocels = []
    for info in synthetic_logs:
        source = info.standard_lazy.with_columns(
            [
                pl.col(CASE_ID).alias("order"),
                pl.concat_str([pl.lit("variant::"), pl.col("Variant")]).alias("variant_object"),
            ]
        )
        ocels.append(
            pl4pm.convert_log_to_ocel(
                source,
                object_types=["order", "variant_object"],
                additional_event_attributes=["org:resource", "Variant"],
            )
        )
    return ocels


@pytest.mark.parametrize("log_index", range(10))
def test_split_train_test(synthetic_logs, log_index):
    info = synthetic_logs[log_index]

    def _run(obj):
        random.seed(1337)
        return pl4pm.split_train_test(obj, train_percentage=0.8)

    pl_df_result, pl_df_time = timed_call(_run, info.standard_lazy)
    pl_lazy_result, pl_lazy_time = timed_call(_run, info.standard_lazy)

    train_df, test_df = pl_df_result
    train_lazy, test_lazy = pl_lazy_result
    base_log = info.standard_lazy.collect()
    all_cases = set(base_log.get_column(CASE_ID).unique().to_list())

    train_cases = set(train_df.get_column(CASE_ID).unique().to_list())
    test_cases = set(test_df.get_column(CASE_ID).unique().to_list())
    assert train_cases.isdisjoint(test_cases)
    assert train_cases | test_cases == all_cases

    assert train_df.height + test_df.height == base_log.height
    assert train_lazy.height + test_lazy.height == base_log.height
    assert len(train_cases) == len(set(train_lazy.get_column(CASE_ID).unique().to_list()))
    assert len(test_cases) == len(set(test_lazy.get_column(CASE_ID).unique().to_list()))

    print_perf(f"{info.name}:split_train_test", None, pl_df_time, pl_lazy_time)


@pytest.mark.parametrize("log_index", range(10))
def test_get_prefixes_from_log(synthetic_logs, log_index):
    info = synthetic_logs[log_index]

    pm_result, pm_time = _maybe_timed_pm4py(
        f"{info.name}:get_prefixes_from_log", "get_prefixes_from_log", info.pm_df, 3
    )
    pl_df_result, pl_df_time = timed_call(pl4pm.get_prefixes_from_log, info.standard_lazy, 3)
    pl_lazy_result, pl_lazy_time = timed_call(pl4pm.get_prefixes_from_log, info.standard_lazy, 3)

    pl_df_norm = normalize_table(pl_df_result)
    pl_lazy_norm = normalize_table(pl_lazy_result)
    assert pl_df_norm == pl_lazy_norm

    if pm_result is not None:
        pm_norm = normalize_table(pm_result)
        if pl_df_norm != pm_norm:
            record_mismatch(f"{info.name}:get_prefixes_from_log", pm_norm, pl_df_norm, pl_lazy_norm)
        assert pl_df_norm == pm_norm

    print_perf(f"{info.name}:get_prefixes_from_log", pm_time, pl_df_time, pl_lazy_time)


@pytest.mark.parametrize("log_index", range(10))
def test_extract_outcome_enriched_dataframe(synthetic_logs, log_index):
    info = synthetic_logs[log_index]

    pm_result, pm_time = _maybe_timed_pm4py(
        f"{info.name}:extract_outcome_enriched_dataframe",
        "extract_outcome_enriched_dataframe",
        info.pm_df,
    )
    pl_df_result, pl_df_time = timed_call(pl4pm.extract_outcome_enriched_dataframe, info.standard_lazy)
    pl_lazy_result, pl_lazy_time = timed_call(pl4pm.extract_outcome_enriched_dataframe, info.standard_lazy)

    pl_df_norm = normalize_table(pl_df_result)
    pl_lazy_norm = normalize_table(pl_lazy_result)
    assert pl_df_norm == pl_lazy_norm

    if pm_result is not None:
        pm_norm = normalize_table(pm_result)
        if pl_df_norm != pm_norm:
            record_mismatch(f"{info.name}:extract_outcome_enriched_dataframe", pm_norm, pl_df_norm, pl_lazy_norm)
        assert pl_df_norm == pm_norm

    print_perf(f"{info.name}:extract_outcome_enriched_dataframe", pm_time, pl_df_time, pl_lazy_time)


@pytest.mark.parametrize("log_index", range(10))
def test_extract_features_dataframe(synthetic_logs, log_index):
    info = synthetic_logs[log_index]

    pm_result, pm_time = _maybe_timed_pm4py(
        f"{info.name}:extract_features_dataframe",
        "extract_features_dataframe",
        info.pm_df,
    )
    pl_df_result, pl_df_time = timed_call(
        pl4pm.extract_features_dataframe,
        info.standard_lazy,
        str_ev_attr=["org:resource"],
        include_case_id=True,
        count_occurrences=True,
    )
    pl_lazy_result, pl_lazy_time = timed_call(
        pl4pm.extract_features_dataframe,
        info.standard_lazy,
        str_ev_attr=["org:resource"],
        include_case_id=True,
        count_occurrences=True,
    )

    pl_df_norm = normalize_table(pl_df_result)
    pl_lazy_norm = normalize_table(pl_lazy_result)
    assert pl_df_norm == pl_lazy_norm

    if pm_result is not None:
        assert pl_df_result.height == len(pm_result)
        assert pl_lazy_result.height == len(pm_result)
        assert CASE_ID in pl_df_result.columns
        assert pl_df_result.width > 2

    print_perf(f"{info.name}:extract_features_dataframe", pm_time, pl_df_time, pl_lazy_time)


@pytest.mark.parametrize("log_index", range(10))
def test_extract_temporal_features_dataframe(synthetic_logs, log_index):
    info = synthetic_logs[log_index]

    pm_result, pm_time = _maybe_timed_pm4py(
        f"{info.name}:extract_temporal_features_dataframe",
        "extract_temporal_features_dataframe",
        info.pm_df,
    )
    pl_df_result, pl_df_time = timed_call(pl4pm.extract_temporal_features_dataframe, info.standard_lazy)
    pl_lazy_result, pl_lazy_time = timed_call(pl4pm.extract_temporal_features_dataframe, info.standard_lazy)

    pl_df_norm = normalize_table(pl_df_result)
    pl_lazy_norm = normalize_table(pl_lazy_result)
    assert pl_df_norm == pl_lazy_norm

    if pm_result is not None:
        pm_norm = _normalize_temporal_shared(pm_result)
        pl_shared_norm = _normalize_temporal_shared(pl_df_result)
        assert sum(int(row["n_events"]) for row in pl_shared_norm) == info.standard_lazy.collect().height
        assert sum(int(row["n_events"]) for row in pm_norm) == len(info.pm_df)
        assert all(float(row["events_per_case"]) >= 0.0 for row in pl_shared_norm)
        assert all(float(row["events_per_case"]) >= 0.0 for row in pm_norm)

    print_perf(f"{info.name}:extract_temporal_features_dataframe", pm_time, pl_df_time, pl_lazy_time)


@pytest.mark.parametrize("variant", ["next_activity", "next_time", "remaining_time"])
@pytest.mark.parametrize("log_index", range(10))
def test_extract_target_vector(synthetic_logs, log_index, variant):
    info = synthetic_logs[log_index]

    pm_result, pm_time = _maybe_timed_pm4py(
        f"{info.name}:extract_target_vector:{variant}",
        "extract_target_vector",
        info.pm_df,
        variant,
    )
    pl_df_result, pl_df_time = timed_call(pl4pm.extract_target_vector, info.standard_lazy, variant)
    pl_lazy_result, pl_lazy_time = timed_call(pl4pm.extract_target_vector, info.standard_lazy, variant)

    pl_df_norm = _normalize_target(pl_df_result)
    pl_lazy_norm = _normalize_target(pl_lazy_result)
    assert pl_df_norm == pl_lazy_norm

    expected = _expected_target(info, variant)
    assert len(pl_df_result[0]) == expected["length"]

    if variant == "next_activity":
        assert sorted(str(value) for value in pl_df_result[1]) == expected["classes"]
    elif variant == "next_time":
        assert expected["all_non_negative"]
    else:
        assert expected["all_non_negative"]
        assert expected["all_case_ends_zero"]

    if pm_result is not None:
        assert pm_time is not None

    print_perf(f"{info.name}:extract_target_vector:{variant}", pm_time, pl_df_time, pl_lazy_time)


@pytest.mark.parametrize("log_index", range(10))
def test_extract_ocel_features(ml_ocels, synthetic_logs, log_index):
    info = synthetic_logs[log_index]
    ocel = ml_ocels[log_index]

    result, pl_time = timed_call(
        pl4pm.extract_ocel_features,
        ocel,
        "order",
        object_str_attributes=["ocel:type"],
    )

    assert isinstance(result, pl.DataFrame)
    assert result.height > 0
    print_perf(f"{info.name}:extract_ocel_features", None, pl_time, None)
