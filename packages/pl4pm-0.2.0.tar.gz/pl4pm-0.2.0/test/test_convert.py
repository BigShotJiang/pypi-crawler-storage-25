"""Test suite for pl4pm.convert — benchmarking pm4py vs pl4pm DF vs Lazy."""
from __future__ import annotations

from typing import Any

import polars as pl
import pytest

import pm4py
import pl4pm

from _filter_read_support import (
    ACTIVITY,
    CASE_ID,
    TIMESTAMP,
    normalize_bpmn,
    normalize_dfg,
    normalize_ocel,
    normalize_petri_net,
    normalize_table,
    normalize_tree,
    print_perf,
    record_mismatch,
    synthetic_logs,
    timed_call,
)


def _maybe_timed_pm4py(label: str, func_name: str, *args, **kwargs):
    func = getattr(pm4py, func_name, None)
    if func is None:
        print(f"{label} pm4py skipped (AttributeError: missing {func_name})")
        return None, None
    try:
        return timed_call(func, *args, **kwargs)
    except Exception as exc:
        print(f"{label} pm4py skipped ({type(exc).__name__}: {exc})")
        return None, None


def _normalize_transition_system(ts: Any) -> dict[str, Any]:
    return {
        "state_count": len(getattr(ts, "states", [])),
        "transition_count": len(getattr(ts, "transitions", [])),
    }


def _normalize_networkx_graph(graph: Any) -> dict[str, Any]:
    nodes = sorted(
        (
            str(node_id),
            str(attrs.get("node_type", "")),
        )
        for node_id, attrs in graph.nodes(data=True)
    )
    edges = sorted(
        (
            str(source),
            str(target),
            str(attrs.get("edge_type", "")),
        )
        for source, target, attrs in graph.edges(data=True)
    )
    return {"nodes": nodes, "edges": edges}


def _normalize_petri_shape(result: Any) -> dict[str, Any]:
    net, im, fm = result
    visible = sorted(
        str(getattr(transition, "label", None) or "")
        for transition in net.transitions
        if getattr(transition, "label", None)
    )
    silent_count = sum(1 for transition in net.transitions if not getattr(transition, "label", None))
    return {
        "place_count": len(net.places),
        "transition_count": len(net.transitions),
        "visible_labels": visible,
        "silent_count": silent_count,
        "initial_tokens": sum(int(tokens) for tokens in im.values()),
        "final_tokens": sum(int(tokens) for tokens in fm.values()),
    }


def _normalize_bpmn_shape(model: Any) -> dict[str, Any]:
    raw = normalize_bpmn(model)
    node_types = sorted(node_type for node_type, _ in raw["nodes"])
    task_names = sorted(name for node_type, name in raw["nodes"] if node_type == "task")
    return {
        "node_count": len(raw["nodes"]),
        "flow_count": len(raw["flows"]),
        "node_types": node_types,
        "task_names": task_names,
    }


def _normalize_bpmn_semantics(model: Any) -> dict[str, Any]:
    raw = normalize_bpmn(model)
    node_types = [node_type for node_type, _ in raw["nodes"]]
    task_names = sorted(
        name
        for node_type, name in raw["nodes"]
        if node_type == "task" and name and name != "τ"
    )
    return {
        "task_names": task_names,
        "has_start": any(node_type == "startevent" for node_type in node_types),
        "has_end": any(node_type == "endevent" for node_type in node_types),
        "gateway_count": sum("gateway" in str(node_type) for node_type in node_types),
    }


def _normalize_pl_log_object(obj: Any) -> list[dict[str, Any]]:
    return normalize_table(obj)


@pytest.fixture(scope="session")
def convert_models(synthetic_logs):
    models = []
    for info in synthetic_logs:
        pm_tree = pm4py.discover_process_tree_inductive(info.pm_df)
        pl_tree = pl4pm.discover_process_tree_inductive(info.standard_lazy)
        pm_dfg = pm4py.discover_dfg(info.pm_df)
        pl_dfg = pl4pm.discover_dfg(info.standard_lazy)
        pm_net = pm4py.convert_to_petri_net(pm_tree)
        pl_net = pl4pm.convert_to_petri_net(pl_tree)
        pm_bpmn = pm4py.convert_to_bpmn(pm_tree)
        pl_bpmn = pl4pm.convert_to_bpmn(pl_tree)
        ocel_source = info.standard_lazy.with_columns(
            [
                pl.col(CASE_ID).alias("order"),
                pl.concat_str([pl.lit("variant::"), pl.col("Variant")]).alias("variant_object"),
            ]
        ).collect()
        pl_ocel = pl4pm.convert_log_to_ocel(
            ocel_source,
            object_types=["order", "variant_object"],
            additional_event_attributes=["org:resource", "Variant"],
        )
        models.append(
            {
                "pm_tree": pm_tree,
                "pl_tree": pl_tree,
                "pm_dfg": pm_dfg,
                "pl_dfg": pl_dfg,
                "pm_net": pm_net,
                "pl_net": pl_net,
                "pm_bpmn": pm_bpmn,
                "pl_bpmn": pl_bpmn,
                "pl_ocel": pl_ocel,
            }
        )
    return models


@pytest.mark.parametrize("log_index", range(10))
def test_convert_to_event_log(synthetic_logs, log_index):
    info = synthetic_logs[log_index]

    pm_result, pm_time = _maybe_timed_pm4py(
        f"{info.name}:convert_to_event_log", "convert_to_event_log", info.pm_df
    )
    pl_result, pl_time = timed_call(pl4pm.convert_to_event_log, info.standard_lazy)

    expected = normalize_table(info.standard_lazy)
    pl_norm = _normalize_pl_log_object(pl_result)

    assert pl_norm == expected
    print_perf(f"{info.name}:convert_to_event_log", pm_time, pl_time)


@pytest.mark.parametrize("log_index", range(10))
def test_convert_to_event_stream(synthetic_logs, log_index):
    info = synthetic_logs[log_index]

    pm_result, pm_time = _maybe_timed_pm4py(
        f"{info.name}:convert_to_event_stream", "convert_to_event_stream", info.pm_df
    )
    pl_result, pl_time = timed_call(pl4pm.convert_to_event_stream, info.standard_lazy)

    expected = normalize_table(info.standard_lazy)
    pl_norm = _normalize_pl_log_object(pl_result)

    assert pl_norm == expected
    print_perf(f"{info.name}:convert_to_event_stream", pm_time, pl_time)


@pytest.mark.parametrize("log_index", range(10))
def test_convert_to_petri_net(synthetic_logs, convert_models, log_index):
    info = synthetic_logs[log_index]
    pm_tree = convert_models[log_index]["pm_tree"]
    pl_tree = convert_models[log_index]["pl_tree"]

    pm_result, pm_time = _maybe_timed_pm4py(
        f"{info.name}:convert_to_petri_net", "convert_to_petri_net", pm_tree
    )
    pl_result, pl_time = timed_call(pl4pm.convert_to_petri_net, pl_tree)

    pl_norm = _normalize_petri_shape(pl_result)
    if pm_result is not None:
        pm_norm = _normalize_petri_shape(pm_result)
        if pl_norm != pm_norm:
            record_mismatch(f"{info.name}:convert_to_petri_net", pm_norm, pl_norm)
        assert pl_norm == pm_norm

    print_perf(f"{info.name}:convert_to_petri_net", pm_time, pl_time, None)


@pytest.mark.parametrize("log_index", range(10))
def test_convert_to_bpmn(synthetic_logs, convert_models, log_index):
    info = synthetic_logs[log_index]
    pm_tree = convert_models[log_index]["pm_tree"]
    pl_tree = convert_models[log_index]["pl_tree"]

    pm_result, pm_time = _maybe_timed_pm4py(
        f"{info.name}:convert_to_bpmn", "convert_to_bpmn", pm_tree
    )
    pl_result, pl_time = timed_call(pl4pm.convert_to_bpmn, pl_tree)

    pl_norm = _normalize_bpmn_semantics(pl_result)
    if pm_result is not None:
        pm_norm = _normalize_bpmn_semantics(pm_result)
        if pl_norm != pm_norm:
            record_mismatch(f"{info.name}:convert_to_bpmn", pm_norm, pl_norm)
        assert pl_norm == pm_norm

    print_perf(f"{info.name}:convert_to_bpmn", pm_time, pl_time, None)


@pytest.mark.parametrize("log_index", range(5))
def test_convert_to_reachability_graph(synthetic_logs, convert_models, log_index):
    info = synthetic_logs[log_index]
    pm_net, pm_im, pm_fm = convert_models[log_index]["pm_net"]
    pl_net, pl_im, pl_fm = convert_models[log_index]["pl_net"]

    pm_result, pm_time = _maybe_timed_pm4py(
        f"{info.name}:convert_to_reachability_graph", "convert_to_reachability_graph", pm_net, pm_im, pm_fm
    )
    pl_result, pl_time = timed_call(pl4pm.convert_to_reachability_graph, pl_net, pl_im, pl_fm)

    pl_norm = _normalize_transition_system(pl_result)
    if pm_result is not None:
        pm_norm = _normalize_transition_system(pm_result)
        if pl_norm != pm_norm:
            record_mismatch(f"{info.name}:convert_to_reachability_graph", pm_norm, pl_norm)
        assert pl_norm == pm_norm

    print_perf(f"{info.name}:convert_to_reachability_graph", pm_time, pl_time, None)


@pytest.mark.parametrize("log_index", range(10))
def test_convert_log_to_ocel(synthetic_logs, log_index):
    info = synthetic_logs[log_index]
    source = info.standard_lazy.with_columns(
        [
            pl.col(CASE_ID).alias("order"),
            pl.concat_str([pl.lit("variant::"), pl.col("Variant")]).alias("variant_object"),
        ]
    ).collect()

    pl_df_result, pl_df_time = timed_call(
        pl4pm.convert_log_to_ocel,
        source,
        object_types=["order", "variant_object"],
        additional_event_attributes=["org:resource", "Variant"],
    )
    pl_lazy_result, pl_lazy_time = timed_call(
        pl4pm.convert_log_to_ocel,
        source.lazy(),
        object_types=["order", "variant_object"],
        additional_event_attributes=["org:resource", "Variant"],
    )

    pl_df_norm = normalize_ocel(pl_df_result)
    pl_lazy_norm = normalize_ocel(pl_lazy_result)
    assert pl_df_norm == pl_lazy_norm

    print_perf(f"{info.name}:convert_log_to_ocel", None, pl_df_time, pl_lazy_time)


@pytest.mark.parametrize("log_index", range(5))
def test_convert_log_to_networkx(synthetic_logs, log_index):
    info = synthetic_logs[log_index]

    pl_df_result, pl_df_time = timed_call(pl4pm.convert_log_to_networkx, info.standard_lazy)
    pl_lazy_result, pl_lazy_time = timed_call(pl4pm.convert_log_to_networkx, info.standard_lazy)

    pl_df_norm = _normalize_networkx_graph(pl_df_result)
    pl_lazy_norm = _normalize_networkx_graph(pl_lazy_result)

    assert pl_df_norm == pl_lazy_norm
    print_perf(f"{info.name}:convert_log_to_networkx", None, pl_df_time, pl_lazy_time)


@pytest.mark.parametrize("log_index", range(5))
def test_convert_petri_net_to_networkx(synthetic_logs, convert_models, log_index):
    info = synthetic_logs[log_index]
    pl_net, pl_im, pl_fm = convert_models[log_index]["pl_net"]

    pl_result, pl_time = timed_call(pl4pm.convert_petri_net_to_networkx, pl_net, pl_im, pl_fm)
    pl_norm = _normalize_networkx_graph(pl_result)

    assert len(pl_norm["nodes"]) > 0
    assert len(pl_norm["edges"]) > 0
    print_perf(f"{info.name}:convert_petri_net_to_networkx", None, pl_time, None)


@pytest.mark.parametrize("log_index", range(5))
def test_convert_petri_net_type(synthetic_logs, convert_models, log_index):
    info = synthetic_logs[log_index]
    pl_net, pl_im, pl_fm = convert_models[log_index]["pl_net"]

    result, pl_time = timed_call(pl4pm.convert_petri_net_type, pl_net, pl_im, pl_fm, type="inhibitor")
    r_net, r_im, r_fm = result
    assert r_net.properties.get("petri_net_type") == "inhibitor"
    assert normalize_marking_like(r_im) == normalize_marking_like(pl_im)
    assert normalize_marking_like(r_fm) == normalize_marking_like(pl_fm)
    print_perf(f"{info.name}:convert_petri_net_type", None, pl_time, None)


def normalize_marking_like(marking: Any) -> dict[str, int]:
    return {str(getattr(place, "name", place)): int(tokens) for place, tokens in marking.items()}
