"""Test suite for pl4pm.conformance — 3-way benchmarking (pm4py vs pl4pm DF vs Lazy)."""
from __future__ import annotations

import math
import polars as pl
import pytest

import pm4py
import pl4pm

from _filter_read_support import (
    ACTIVITY,
    CASE_ID,
    TIMESTAMP,
    print_perf,
    record_mismatch,
    synthetic_logs,
    timed_call,
)


# ════════════════════════════════════════════════════════════════════
# Shared fixtures: discover models once per log
# ════════════════════════════════════════════════════════════════════

@pytest.fixture(scope="session")
def discovered_models(synthetic_logs):
    """Discover Petri nets (pm4py + pl4pm) once per log for conformance tests."""
    models = []
    for info in synthetic_logs:
        # pm4py model (from Pandas)
        pm_net, pm_im, pm_fm = pm4py.discover_petri_net_inductive(info.pm_df)

        # pl4pm model (from Polars)
        pl_net, pl_im, pl_fm = pl4pm.discover_petri_net_inductive(info.standard_lazy)

        # pl4pm footprints (for footprint conformance)
        pl_fp_log = pl4pm.discover_footprints(info.standard_lazy)
        pl_fp_model = pl4pm.discover_footprints(pl_net, pl_im, pl_fm)

        pm_fp_log = pm4py.discover_footprints(info.pm_df)
        pm_fp_model = pm4py.discover_footprints(pm_net, pm_im, pm_fm)

        # Temporal profile
        pl_tp = pl4pm.discover_temporal_profile(info.standard_lazy)
        pm_tp = pm4py.discover_temporal_profile(info.pm_df)

        # Log skeleton
        pl_skel = pl4pm.discover_log_skeleton(info.standard_lazy)
        pm_skel = pm4py.discover_log_skeleton(info.pm_df)

        # DECLARE model
        pl_declare = pl4pm.discover_declare(info.standard_lazy)
        pm_declare = pm4py.discover_declare(info.pm_df)

        models.append({
            "pm_net": (pm_net, pm_im, pm_fm),
            "pl_net": (pl_net, pl_im, pl_fm),
            "pl_fp_log": pl_fp_log,
            "pl_fp_model": pl_fp_model,
            "pm_fp_log": pm_fp_log,
            "pm_fp_model": pm_fp_model,
            "pl_tp": pl_tp,
            "pm_tp": pm_tp,
            "pl_skel": pl_skel,
            "pm_skel": pm_skel,
            "pl_declare": pl_declare,
            "pm_declare": pm_declare,
        })
    return models


# ════════════════════════════════════════════════════════════════════
# Token-Based Replay
# ════════════════════════════════════════════════════════════════════

@pytest.mark.parametrize("log_index", range(10))
def test_fitness_token_based_replay(synthetic_logs, discovered_models, log_index):
    info = synthetic_logs[log_index]
    pm_net, pm_im, pm_fm = discovered_models[log_index]["pm_net"]
    pl_net, pl_im, pl_fm = discovered_models[log_index]["pl_net"]

    pm_result, pm_time = timed_call(
        pm4py.fitness_token_based_replay, info.pm_df, pm_net, pm_im, pm_fm
    )
    pl_df_result, pl_df_time = timed_call(
        pl4pm.fitness_token_based_replay, info.standard_lazy, pl_net, pl_im, pl_fm
    )
    pl_lazy_result, pl_lazy_time = timed_call(
        pl4pm.fitness_token_based_replay, info.standard_lazy, pl_net, pl_im, pl_fm
    )

    # Compare average_trace_fitness or log_fitness
    pm_fitness = pm_result.get("average_trace_fitness", pm_result.get("log_fitness", 0))
    pl_df_fitness = pl_df_result.get("average_trace_fitness", pl_df_result.get("log_fitness", 0))
    pl_lazy_fitness = pl_lazy_result.get("average_trace_fitness", pl_lazy_result.get("log_fitness", 0))

    assert math.isclose(pl_df_fitness, pm_fitness, rel_tol=0.05), \
        f"Fitness DF: pl4pm={pl_df_fitness:.4f} vs pm4py={pm_fitness:.4f}"
    assert math.isclose(pl_lazy_fitness, pm_fitness, rel_tol=0.05), \
        f"Fitness Lazy: pl4pm={pl_lazy_fitness:.4f} vs pm4py={pm_fitness:.4f}"
    print_perf(f"{info.name}:fitness_tbr", pm_time, pl_df_time, pl_lazy_time)


@pytest.mark.parametrize("log_index", range(10))
def test_precision_token_based_replay(synthetic_logs, discovered_models, log_index):
    info = synthetic_logs[log_index]
    pm_net, pm_im, pm_fm = discovered_models[log_index]["pm_net"]
    pl_net, pl_im, pl_fm = discovered_models[log_index]["pl_net"]

    pm_result, pm_time = timed_call(
        pm4py.precision_token_based_replay, info.pm_df, pm_net, pm_im, pm_fm
    )
    pl_df_result, pl_df_time = timed_call(
        pl4pm.precision_token_based_replay, info.standard_lazy, pl_net, pl_im, pl_fm
    )
    pl_lazy_result, pl_lazy_time = timed_call(
        pl4pm.precision_token_based_replay, info.standard_lazy, pl_net, pl_im, pl_fm
    )

    assert math.isclose(pl_df_result, pm_result, abs_tol=0.10), \
        f"Precision DF: pl4pm={pl_df_result:.4f} vs pm4py={pm_result:.4f}"
    assert math.isclose(pl_lazy_result, pm_result, abs_tol=0.10), \
        f"Precision Lazy: pl4pm={pl_lazy_result:.4f} vs pm4py={pm_result:.4f}"
    print_perf(f"{info.name}:precision_tbr", pm_time, pl_df_time, pl_lazy_time)


@pytest.mark.parametrize("log_index", range(10))
def test_conformance_diagnostics_tbr(synthetic_logs, discovered_models, log_index):
    info = synthetic_logs[log_index]
    pl_net, pl_im, pl_fm = discovered_models[log_index]["pl_net"]
    pm_net, pm_im, pm_fm = discovered_models[log_index]["pm_net"]

    pm_result, pm_time = timed_call(
        pm4py.conformance_diagnostics_token_based_replay, info.pm_df, pm_net, pm_im, pm_fm
    )
    pl_df_result, pl_df_time = timed_call(
        pl4pm.conformance_diagnostics_token_based_replay, info.standard_lazy, pl_net, pl_im, pl_fm
    )
    pl_lazy_result, pl_lazy_time = timed_call(
        pl4pm.conformance_diagnostics_token_based_replay, info.standard_lazy, pl_net, pl_im, pl_fm
    )

    # Compare number of results and fit trace counts
    assert len(pl_df_result) == len(pm_result), \
        f"Result len: pl4pm={len(pl_df_result)} vs pm4py={len(pm_result)}"
    assert len(pl_lazy_result) == len(pm_result)

    pm_fit = sum(1 for d in pm_result if d.get("trace_is_fit", False))
    pl_df_fit = sum(1 for d in pl_df_result if d.get("trace_is_fit", False))
    pl_lazy_fit = sum(1 for d in pl_lazy_result if d.get("trace_is_fit", False))

    # Allow discrepancy: nets are independently discovered and TBR implementations differ
    assert abs(pl_df_fit - pm_fit) <= max(2, len(pm_result) // 3), \
        f"Fit count DF: pl4pm={pl_df_fit} vs pm4py={pm_fit}"
    assert abs(pl_lazy_fit - pm_fit) <= max(2, len(pm_result) // 3), \
        f"Fit count Lazy: pl4pm={pl_lazy_fit} vs pm4py={pm_fit}"
    print_perf(f"{info.name}:conformance_diag_tbr", pm_time, pl_df_time, pl_lazy_time)


@pytest.mark.parametrize("log_index", range(10))
def test_generalization_tbr(synthetic_logs, discovered_models, log_index):
    info = synthetic_logs[log_index]
    pl_net, pl_im, pl_fm = discovered_models[log_index]["pl_net"]

    pl_df_result, pl_df_time = timed_call(
        pl4pm.generalization_tbr, info.standard_lazy, pl_net, pl_im, pl_fm
    )
    pl_lazy_result, pl_lazy_time = timed_call(
        pl4pm.generalization_tbr, info.standard_lazy, pl_net, pl_im, pl_fm
    )

    assert math.isclose(pl_df_result, pl_lazy_result, rel_tol=0.01), \
        f"Generalization: DF={pl_df_result:.4f} vs Lazy={pl_lazy_result:.4f}"
    assert 0.0 <= pl_df_result <= 1.0, f"Generalization out of range: {pl_df_result}"
    print_perf(f"{info.name}:generalization_tbr", None, pl_df_time, pl_lazy_time)


# ════════════════════════════════════════════════════════════════════
# Alignments
# ════════════════════════════════════════════════════════════════════

@pytest.mark.parametrize("log_index", range(5))  # Limited — alignments are expensive
def test_conformance_diagnostics_alignments(synthetic_logs, discovered_models, log_index):
    info = synthetic_logs[log_index]
    pl_net, pl_im, pl_fm = discovered_models[log_index]["pl_net"]
    pm_net, pm_im, pm_fm = discovered_models[log_index]["pm_net"]

    pm_result, pm_time = timed_call(
        pm4py.conformance_diagnostics_alignments, info.pm_df, pm_net, pm_im, pm_fm
    )
    pl_df_result, pl_df_time = timed_call(
        pl4pm.conformance_diagnostics_alignments, info.standard_lazy, pl_net, pl_im, pl_fm
    )
    pl_lazy_result, pl_lazy_time = timed_call(
        pl4pm.conformance_diagnostics_alignments, info.standard_lazy, pl_net, pl_im, pl_fm
    )

    assert len(pl_df_result) == len(pm_result), \
        f"Alignment count: pl4pm={len(pl_df_result)} vs pm4py={len(pm_result)}"
    assert len(pl_lazy_result) == len(pm_result)
    print_perf(f"{info.name}:conformance_diag_align", pm_time, pl_df_time, pl_lazy_time)


@pytest.mark.parametrize("log_index", range(5))
def test_fitness_alignments(synthetic_logs, discovered_models, log_index):
    info = synthetic_logs[log_index]
    pl_net, pl_im, pl_fm = discovered_models[log_index]["pl_net"]
    pm_net, pm_im, pm_fm = discovered_models[log_index]["pm_net"]

    pm_result, pm_time = timed_call(
        pm4py.fitness_alignments, info.pm_df, pm_net, pm_im, pm_fm
    )
    pl_df_result, pl_df_time = timed_call(
        pl4pm.fitness_alignments, info.standard_lazy, pl_net, pl_im, pl_fm
    )
    pl_lazy_result, pl_lazy_time = timed_call(
        pl4pm.fitness_alignments, info.standard_lazy, pl_net, pl_im, pl_fm
    )

    pm_fitness = pm_result.get("average_trace_fitness", pm_result.get("log_fitness", 0))
    pl_df_fitness = pl_df_result.get("average_trace_fitness", pl_df_result.get("log_fitness", 0))
    pl_lazy_fitness = pl_lazy_result.get("average_trace_fitness", pl_lazy_result.get("log_fitness", 0))

    assert math.isclose(pl_df_fitness, pm_fitness, abs_tol=0.15), \
        f"Alignment fitness DF: pl4pm={pl_df_fitness:.4f} vs pm4py={pm_fitness:.4f}"
    assert math.isclose(pl_lazy_fitness, pm_fitness, abs_tol=0.15), \
        f"Alignment fitness Lazy: pl4pm={pl_lazy_fitness:.4f} vs pm4py={pm_fitness:.4f}"
    print_perf(f"{info.name}:fitness_alignments", pm_time, pl_df_time, pl_lazy_time)


# ════════════════════════════════════════════════════════════════════
# Footprints
# ════════════════════════════════════════════════════════════════════

@pytest.mark.parametrize("log_index", range(10))
def test_conformance_diagnostics_footprints(synthetic_logs, discovered_models, log_index):
    info = synthetic_logs[log_index]
    pl_fp_model = discovered_models[log_index]["pl_fp_model"]
    pm_fp_model = discovered_models[log_index]["pm_fp_model"]

    pm_result, pm_time = timed_call(
        pm4py.conformance_diagnostics_footprints, info.pm_df, pm_fp_model
    )
    pl_df_result, pl_df_time = timed_call(
        pl4pm.conformance_diagnostics_footprints, info.standard_lazy, pl_fp_model
    )
    pl_lazy_result, pl_lazy_time = timed_call(
        pl4pm.conformance_diagnostics_footprints, info.standard_lazy, pl_fp_model
    )

    # pl4pm returns per-trace list; pm4py returns a log-level dict
    # Compare: DF and Lazy must agree with each other
    assert len(pl_df_result) == len(pl_lazy_result), \
        f"FP diag count: DF={len(pl_df_result)} vs Lazy={len(pl_lazy_result)}"

    # Compare fit counts between DF and Lazy
    pl_df_fit = sum(1 for d in pl_df_result if d.get("is_fit", False))
    pl_lazy_fit = sum(1 for d in pl_lazy_result if d.get("is_fit", False))
    assert pl_df_fit == pl_lazy_fit, \
        f"FP fit count: DF={pl_df_fit} vs Lazy={pl_lazy_fit}"
    print_perf(f"{info.name}:conformance_diag_fp", pm_time, pl_df_time, pl_lazy_time)


@pytest.mark.parametrize("log_index", range(10))
def test_fitness_footprints(synthetic_logs, discovered_models, log_index):
    info = synthetic_logs[log_index]
    pl_fp_model = discovered_models[log_index]["pl_fp_model"]
    pm_fp_model = discovered_models[log_index]["pm_fp_model"]

    pm_result, pm_time = timed_call(
        pm4py.fitness_footprints, info.pm_df, pm_fp_model
    )
    pl_df_result, pl_df_time = timed_call(
        pl4pm.fitness_footprints, info.standard_lazy, pl_fp_model
    )
    pl_lazy_result, pl_lazy_time = timed_call(
        pl4pm.fitness_footprints, info.standard_lazy, pl_fp_model
    )

    # Extract fitness values (pm4py returns float, pl4pm returns dict)
    pm_log_fitness = pm_result if isinstance(pm_result, (int, float)) else pm_result.get("log_fitness", pm_result.get("perc_fit_traces", 0))
    pl_df_log_fitness = pl_df_result if isinstance(pl_df_result, (int, float)) else pl_df_result.get("log_fitness", pl_df_result.get("perc_fit_traces", 0))
    pl_lazy_log_fitness = pl_lazy_result if isinstance(pl_lazy_result, (int, float)) else pl_lazy_result.get("log_fitness", pl_lazy_result.get("perc_fit_traces", 0))

    # DF and Lazy must agree
    assert math.isclose(pl_df_log_fitness, pl_lazy_log_fitness, abs_tol=0.01), \
        f"FP fitness DF={pl_df_log_fitness:.4f} vs Lazy={pl_lazy_log_fitness:.4f}"
    # Both must be in valid range
    assert 0.0 <= pl_df_log_fitness <= 1.0, f"FP fitness DF out of range: {pl_df_log_fitness}"
    print_perf(f"{info.name}:fitness_footprints", pm_time, pl_df_time, pl_lazy_time)


@pytest.mark.parametrize("log_index", range(10))
def test_precision_footprints(synthetic_logs, discovered_models, log_index):
    info = synthetic_logs[log_index]
    pl_fp_log = discovered_models[log_index]["pl_fp_log"]
    pl_fp_model = discovered_models[log_index]["pl_fp_model"]
    pm_fp_log = discovered_models[log_index]["pm_fp_log"]
    pm_fp_model = discovered_models[log_index]["pm_fp_model"]

    pm_result, pm_time = timed_call(pm4py.precision_footprints, pm_fp_log, pm_fp_model)
    pl_df_result, pl_df_time = timed_call(pl4pm.precision_footprints, pl_fp_log, pl_fp_model)

    # Validate result is in valid range
    assert 0.0 <= pl_df_result <= 1.0, f"FP precision out of range: {pl_df_result}"
    assert 0.0 <= pm_result <= 1.0, f"pm4py FP precision out of range: {pm_result}"
    print_perf(f"{info.name}:precision_footprints", pm_time, pl_df_time, None)


# ════════════════════════════════════════════════════════════════════
# Temporal profile
# ════════════════════════════════════════════════════════════════════

@pytest.mark.parametrize("log_index", range(10))
def test_conformance_temporal_profile(synthetic_logs, discovered_models, log_index):
    info = synthetic_logs[log_index]
    pl_tp = discovered_models[log_index]["pl_tp"]

    pl_df_result, pl_df_time = timed_call(
        pl4pm.conformance_temporal_profile, info.standard_lazy, pl_tp, zeta=2.0
    )
    pl_lazy_result, pl_lazy_time = timed_call(
        pl4pm.conformance_temporal_profile, info.standard_lazy, pl_tp, zeta=2.0
    )

    assert len(pl_df_result) == len(pl_lazy_result), \
        f"Temporal profile diag count: DF={len(pl_df_result)} vs Lazy={len(pl_lazy_result)}"
    # Compare deviation counts
    df_devs = sum(len(d) for d in pl_df_result)
    lazy_devs = sum(len(d) for d in pl_lazy_result)
    assert df_devs == lazy_devs, f"Deviation count: DF={df_devs} vs Lazy={lazy_devs}"
    print_perf(f"{info.name}:conformance_temporal", None, pl_df_time, pl_lazy_time)


# ════════════════════════════════════════════════════════════════════
# DECLARE conformance
# ════════════════════════════════════════════════════════════════════

@pytest.mark.parametrize("log_index", range(10))
def test_conformance_declare(synthetic_logs, discovered_models, log_index):
    info = synthetic_logs[log_index]
    pl_declare = discovered_models[log_index]["pl_declare"]

    pl_df_result, pl_df_time = timed_call(
        pl4pm.conformance_declare, info.standard_lazy, pl_declare
    )
    pl_lazy_result, pl_lazy_time = timed_call(
        pl4pm.conformance_declare, info.standard_lazy, pl_declare
    )

    assert len(pl_df_result) == len(pl_lazy_result), \
        f"Declare diag count: DF={len(pl_df_result)} vs Lazy={len(pl_lazy_result)}"

    # Compare fit counts
    df_fit = sum(1 for d in pl_df_result if d.get("is_fit", False))
    lazy_fit = sum(1 for d in pl_lazy_result if d.get("is_fit", False))
    assert df_fit == lazy_fit, f"Declare fit count: DF={df_fit} vs Lazy={lazy_fit}"
    print_perf(f"{info.name}:conformance_declare", None, pl_df_time, pl_lazy_time)


# ════════════════════════════════════════════════════════════════════
# Log skeleton conformance
# ════════════════════════════════════════════════════════════════════

@pytest.mark.parametrize("log_index", range(10))
def test_conformance_log_skeleton(synthetic_logs, discovered_models, log_index):
    info = synthetic_logs[log_index]
    pl_skel = discovered_models[log_index]["pl_skel"]

    pl_df_result, pl_df_time = timed_call(
        pl4pm.conformance_log_skeleton, info.standard_lazy, pl_skel
    )
    pl_lazy_result, pl_lazy_time = timed_call(
        pl4pm.conformance_log_skeleton, info.standard_lazy, pl_skel
    )

    assert len(pl_df_result) == len(pl_lazy_result), \
        f"Log skeleton diag count: DF={len(pl_df_result)} vs Lazy={len(pl_lazy_result)}"

    # Compare violation counts
    df_violations = sum(len(v) for v in pl_df_result)
    lazy_violations = sum(len(v) for v in pl_lazy_result)
    assert df_violations == lazy_violations, \
        f"Log skeleton violations: DF={df_violations} vs Lazy={lazy_violations}"
    print_perf(f"{info.name}:conformance_log_skeleton", None, pl_df_time, pl_lazy_time)


# ════════════════════════════════════════════════════════════════════
# Replay prefix
# ════════════════════════════════════════════════════════════════════

@pytest.mark.parametrize("log_index", range(10))
def test_replay_prefix_tbr(synthetic_logs, discovered_models, log_index):
    info = synthetic_logs[log_index]
    pl_net, pl_im, pl_fm = discovered_models[log_index]["pl_net"]

    # Get a prefix from the first case
    df = info.standard_lazy
    first_case_id = df.select(pl.col(CASE_ID).first()).collect().item()
    acts = (
        df.filter(pl.col(CASE_ID) == first_case_id)
        .select(ACTIVITY)
        .collect()
        .get_column(ACTIVITY)
        .to_list()
    )
    prefix = acts[:max(1, len(acts) // 2)]

    result = pl4pm.replay_prefix_tbr(prefix, pl_net, pl_im, pl_fm)
    assert isinstance(result, dict), f"Expected Marking dict, got {type(result)}"
    assert len(result) > 0, "Replay prefix returned empty marking"
    print_perf(f"{info.name}:replay_prefix_tbr", None, None, None)
