"""Test suite for pl4pm.stats — 3-way benchmarking (pm4py vs pl4pm DF vs Lazy)."""
from __future__ import annotations

import math
from datetime import datetime
import polars as pl
import pytest

import pm4py
import pl4pm

from _filter_read_support import (
    ACTIVITY,
    CASE_ID,
    RESOURCE,
    TIMESTAMP,
    print_perf,
    record_mismatch,
    synthetic_logs,
    timed_call,
)

# ════════════════════════════════════════════════════════════════════
# Helpers
# ════════════════════════════════════════════════════════════════════

def _normalize_dict_keys(d: dict) -> dict:
    """Normalize dict keys to strings for comparison."""
    return {str(k): v for k, v in d.items()}


def _normalize_variant_dict(d: dict) -> dict:
    """Normalize variant dict keys (tuples vs comma-joined strings)."""
    result = {}
    for k, v in d.items():
        if isinstance(k, tuple):
            key = tuple(str(x) for x in k)
        elif isinstance(k, str) and "," in k:
            key = tuple(k.split(","))
        elif isinstance(k, list):
            key = tuple(str(x) for x in k)
        else:
            key = (str(k),)
        result[key] = v
    return result


def _dicts_approx_equal(d1: dict, d2: dict, rel_tol: float = 1e-2) -> bool:
    """Check if two dicts have same keys and approximately equal float values."""
    if set(d1.keys()) != set(d2.keys()):
        return False
    for k in d1:
        v1, v2 = d1[k], d2[k]
        if isinstance(v1, float) and isinstance(v2, float):
            if not math.isclose(v1, v2, rel_tol=rel_tol, abs_tol=1e-9):
                return False
        elif v1 != v2:
            return False
    return True


# ════════════════════════════════════════════════════════════════════
# Stats functions with pm4py equivalents
# ════════════════════════════════════════════════════════════════════

@pytest.mark.parametrize("log_index", range(10))
def test_get_start_activities(synthetic_logs, log_index):
    info = synthetic_logs[log_index]

    pm_result, pm_time = timed_call(pm4py.get_start_activities, info.pm_df)
    pl_df_result, pl_df_time = timed_call(pl4pm.get_start_activities, info.standard_lazy)
    pl_lazy_result, pl_lazy_time = timed_call(pl4pm.get_start_activities, info.standard_lazy)

    pm_norm = _normalize_dict_keys(pm_result)
    pl_df_norm = _normalize_dict_keys(pl_df_result)
    pl_lazy_norm = _normalize_dict_keys(pl_lazy_result)

    if pl_df_norm != pm_norm:
        record_mismatch(f"{info.name}:get_start_activities", pm_norm, pl_df_norm, pl_lazy_norm)
    assert pl_df_norm == pm_norm
    assert pl_lazy_norm == pm_norm
    print_perf(f"{info.name}:get_start_activities", pm_time, pl_df_time, pl_lazy_time)


@pytest.mark.parametrize("log_index", range(10))
def test_get_end_activities(synthetic_logs, log_index):
    info = synthetic_logs[log_index]

    pm_result, pm_time = timed_call(pm4py.get_end_activities, info.pm_df)
    pl_df_result, pl_df_time = timed_call(pl4pm.get_end_activities, info.standard_lazy)
    pl_lazy_result, pl_lazy_time = timed_call(pl4pm.get_end_activities, info.standard_lazy)

    pm_norm = _normalize_dict_keys(pm_result)
    pl_df_norm = _normalize_dict_keys(pl_df_result)
    pl_lazy_norm = _normalize_dict_keys(pl_lazy_result)

    if pl_df_norm != pm_norm:
        record_mismatch(f"{info.name}:get_end_activities", pm_norm, pl_df_norm, pl_lazy_norm)
    assert pl_df_norm == pm_norm
    assert pl_lazy_norm == pm_norm
    print_perf(f"{info.name}:get_end_activities", pm_time, pl_df_time, pl_lazy_time)


@pytest.mark.parametrize("log_index", range(10))
def test_get_event_attributes(synthetic_logs, log_index):
    info = synthetic_logs[log_index]

    pm_result, pm_time = timed_call(pm4py.get_event_attributes, info.pm_df)
    pl_df_result, pl_df_time = timed_call(pl4pm.get_event_attributes, info.standard_lazy)
    pl_lazy_result, pl_lazy_time = timed_call(pl4pm.get_event_attributes, info.standard_lazy)

    # Compare as sets since order may differ
    # pm4py adds internal columns; only check pl4pm columns are in pm4py
    pl_df_set = set(pl_df_result)
    pl_lazy_set = set(pl_lazy_result)

    assert pl_df_set == pl_lazy_set, f"DF vs Lazy mismatch: {pl_df_set} != {pl_lazy_set}"
    # pl4pm columns should be a subset of what pm4py returns (pm4py adds @@index etc.)
    pm_set = set(pm_result)
    common = pl_df_set & pm_set
    assert len(common) >= 3, f"Expected at least case_id, activity, timestamp in common; got {common}"
    print_perf(f"{info.name}:get_event_attributes", pm_time, pl_df_time, pl_lazy_time)


@pytest.mark.parametrize("log_index", range(10))
def test_get_event_attribute_values(synthetic_logs, log_index):
    info = synthetic_logs[log_index]

    pm_result, pm_time = timed_call(pm4py.get_event_attribute_values, info.pm_df, ACTIVITY)
    pl_df_result, pl_df_time = timed_call(pl4pm.get_event_attribute_values, info.standard_lazy, ACTIVITY)
    pl_lazy_result, pl_lazy_time = timed_call(pl4pm.get_event_attribute_values, info.standard_lazy, ACTIVITY)

    pm_norm = _normalize_dict_keys(pm_result)
    pl_df_norm = _normalize_dict_keys(pl_df_result)
    pl_lazy_norm = _normalize_dict_keys(pl_lazy_result)

    if pl_df_norm != pm_norm:
        record_mismatch(f"{info.name}:get_event_attribute_values", pm_norm, pl_df_norm, pl_lazy_norm)
    assert pl_df_norm == pm_norm
    assert pl_lazy_norm == pm_norm
    print_perf(f"{info.name}:get_event_attribute_values", pm_time, pl_df_time, pl_lazy_time)


@pytest.mark.parametrize("log_index", range(10))
def test_get_variants(synthetic_logs, log_index):
    info = synthetic_logs[log_index]

    # pm4py returns {variant_tuple: [list_of_traces]}, convert to counts
    pm_input = pm4py.convert_to_event_log(info.pm_df)
    pm_raw, pm_time = timed_call(pm4py.get_variants_as_tuples, pm_input)
    pm_counts = {k: (len(v) if isinstance(v, list) else v) for k, v in pm_raw.items()}

    pl_df_result, pl_df_time = timed_call(pl4pm.get_variants, info.standard_lazy)
    pl_lazy_result, pl_lazy_time = timed_call(pl4pm.get_variants, info.standard_lazy)

    pm_norm = _normalize_variant_dict(pm_counts)
    pl_df_norm = _normalize_variant_dict(pl_df_result)
    pl_lazy_norm = _normalize_variant_dict(pl_lazy_result)

    # Compare key sets and value sums
    assert set(pl_df_norm.keys()) == set(pm_norm.keys()), \
        f"Variant keys mismatch: pl4pm has {len(pl_df_norm)} vs pm4py {len(pm_norm)}"
    assert sum(pl_df_norm.values()) == sum(pm_norm.values()), "Total case counts differ"
    assert set(pl_lazy_norm.keys()) == set(pm_norm.keys())
    print_perf(f"{info.name}:get_variants", pm_time, pl_df_time, pl_lazy_time)


@pytest.mark.parametrize("log_index", range(10))
def test_get_stochastic_language(synthetic_logs, log_index):
    info = synthetic_logs[log_index]

    # pm4py stochastic_language needs an EventLog object
    pm_input = pm4py.convert_to_event_log(info.pm_df)
    pm_raw, pm_time = timed_call(pm4py.get_stochastic_language, pm_input)
    # pm4py may return list values; normalize to float counts
    pm_counts = {k: (float(len(v)) if isinstance(v, list) else float(v)) for k, v in pm_raw.items()}
    pm_total = sum(pm_counts.values())
    pm_probs = {k: v / pm_total for k, v in pm_counts.items()} if pm_total > 0 else pm_counts

    pl_df_result, pl_df_time = timed_call(pl4pm.get_stochastic_language, info.standard_lazy)
    pl_lazy_result, pl_lazy_time = timed_call(pl4pm.get_stochastic_language, info.standard_lazy)

    pm_norm = _normalize_variant_dict(pm_probs)
    pl_df_norm = _normalize_variant_dict(pl_df_result)
    pl_lazy_norm = _normalize_variant_dict(pl_lazy_result)

    assert _dicts_approx_equal(pl_df_norm, pm_norm, rel_tol=1e-2), \
        f"Stochastic language DF mismatch"
    assert _dicts_approx_equal(pl_lazy_norm, pm_norm, rel_tol=1e-2), \
        f"Stochastic language Lazy mismatch"
    print_perf(f"{info.name}:get_stochastic_language", pm_time, pl_df_time, pl_lazy_time)


@pytest.mark.parametrize("log_index", range(10))
def test_get_minimum_self_distances(synthetic_logs, log_index):
    info = synthetic_logs[log_index]

    pm_result, pm_time = timed_call(pm4py.get_minimum_self_distances, info.pm_df)
    pl_df_result, pl_df_time = timed_call(pl4pm.get_minimum_self_distances, info.standard_lazy)
    pl_lazy_result, pl_lazy_time = timed_call(pl4pm.get_minimum_self_distances, info.standard_lazy)

    pm_norm = _normalize_dict_keys(pm_result)
    pl_df_norm = _normalize_dict_keys(pl_df_result)
    pl_lazy_norm = _normalize_dict_keys(pl_lazy_result)

    if pl_df_norm != pm_norm:
        record_mismatch(f"{info.name}:get_minimum_self_distances", pm_norm, pl_df_norm, pl_lazy_norm)
    assert pl_df_norm == pm_norm
    assert pl_lazy_norm == pm_norm
    print_perf(f"{info.name}:get_minimum_self_distances", pm_time, pl_df_time, pl_lazy_time)


@pytest.mark.parametrize("log_index", range(10))
def test_get_minimum_self_distance_witnesses(synthetic_logs, log_index):
    info = synthetic_logs[log_index]

    pm_result, pm_time = timed_call(pm4py.get_minimum_self_distance_witnesses, info.pm_df)
    pl_df_result, pl_df_time = timed_call(pl4pm.get_minimum_self_distance_witnesses, info.standard_lazy)
    pl_lazy_result, pl_lazy_time = timed_call(pl4pm.get_minimum_self_distance_witnesses, info.standard_lazy)

    # Normalize: keys to str, values to frozenset of str
    def _norm_witnesses(d):
        return {str(k): frozenset(str(v) for v in vals) for k, vals in d.items()}

    pm_norm = _norm_witnesses(pm_result)
    pl_df_norm = _norm_witnesses(pl_df_result)
    pl_lazy_norm = _norm_witnesses(pl_lazy_result)

    if pl_df_norm != pm_norm:
        record_mismatch(f"{info.name}:get_msd_witnesses", pm_norm, pl_df_norm, pl_lazy_norm)
    assert pl_df_norm == pm_norm
    assert pl_lazy_norm == pm_norm
    print_perf(f"{info.name}:get_msd_witnesses", pm_time, pl_df_time, pl_lazy_time)


@pytest.mark.parametrize("log_index", range(10))
def test_get_case_arrival_average(synthetic_logs, log_index):
    info = synthetic_logs[log_index]

    pm_result, pm_time = timed_call(pm4py.get_case_arrival_average, info.pm_df)
    pl_df_result, pl_df_time = timed_call(pl4pm.get_case_arrival_average, info.standard_lazy)
    pl_lazy_result, pl_lazy_time = timed_call(pl4pm.get_case_arrival_average, info.standard_lazy)

    assert math.isclose(pl_df_result, pm_result, rel_tol=0.05), \
        f"DF arrival avg: pl4pm={pl_df_result:.2f} vs pm4py={pm_result:.2f}"
    assert math.isclose(pl_lazy_result, pm_result, rel_tol=0.05), \
        f"Lazy arrival avg: pl4pm={pl_lazy_result:.2f} vs pm4py={pm_result:.2f}"
    print_perf(f"{info.name}:get_case_arrival_average", pm_time, pl_df_time, pl_lazy_time)


@pytest.mark.parametrize("log_index", range(10))
def test_get_all_case_durations(synthetic_logs, log_index):
    info = synthetic_logs[log_index]

    pm_result, pm_time = timed_call(pm4py.get_all_case_durations, info.pm_df)
    pl_df_result, pl_df_time = timed_call(pl4pm.get_all_case_durations, info.standard_lazy)
    pl_lazy_result, pl_lazy_time = timed_call(pl4pm.get_all_case_durations, info.standard_lazy)

    # Both return sorted lists of floats
    assert len(pl_df_result) == len(pm_result), \
        f"Length mismatch: pl4pm={len(pl_df_result)} vs pm4py={len(pm_result)}"
    assert len(pl_lazy_result) == len(pm_result)

    # Compare sorted values with tolerance
    pm_sorted = sorted(pm_result)
    pl_df_sorted = sorted(pl_df_result)
    for i in range(min(len(pm_sorted), 20)):  # Spot check first 20
        assert math.isclose(pl_df_sorted[i], pm_sorted[i], rel_tol=0.01, abs_tol=1.0), \
            f"Duration[{i}]: pl4pm={pl_df_sorted[i]:.1f} vs pm4py={pm_sorted[i]:.1f}"

    print_perf(f"{info.name}:get_all_case_durations", pm_time, pl_df_time, pl_lazy_time)


def test_get_activity_pair_average_durations_expected_values_and_collect_modes():
    log = pl.DataFrame(
        {
            CASE_ID: ["c1", "c1", "c1", "c2", "c2", "c2"],
            ACTIVITY: ["A", "B", "C", "A", "B", "C"],
            TIMESTAMP: [
                datetime(2024, 1, 1, 8, 0, 0),
                datetime(2024, 1, 1, 8, 30, 0),
                datetime(2024, 1, 1, 9, 0, 0),
                datetime(2024, 1, 1, 10, 0, 0),
                datetime(2024, 1, 1, 11, 0, 0),
                datetime(2024, 1, 1, 12, 30, 0),
            ],
        }
    ).lazy()

    lazy_result = pl4pm.get_activity_pair_average_durations(log, measure="minutes")
    assert isinstance(lazy_result, pl.LazyFrame)
    collected = lazy_result.collect().sort(["source_activity", "target_activity"])

    expected = {
        ("A", "B"): (45.0, 2),
        ("A", "C"): (105.0, 2),
        ("B", "C"): (60.0, 2),
    }
    rows = {
        (row["source_activity"], row["target_activity"]): (row["avg_duration"], row["occurrences"])
        for row in collected.to_dicts()
    }
    assert rows.keys() >= expected.keys()
    for pair, (avg_duration, occurrences) in expected.items():
        got_avg, got_occ = rows[pair]
        assert math.isclose(got_avg, avg_duration, rel_tol=1e-9)
        assert got_occ == occurrences

    eager = pl4pm.get_activity_pair_average_durations(
        log,
        measure="hours",
        do_collect=True,
        collect_engine="streaming",
    )
    assert isinstance(eager, pl.DataFrame)
    ab_hours = (
        eager.filter((pl.col("source_activity") == "A") & (pl.col("target_activity") == "B"))
        .select("avg_duration")
        .item()
    )
    assert math.isclose(ab_hours, 0.75, rel_tol=1e-9)


def test_get_activity_pair_average_durations_handles_repeated_targets_without_pair_expansion():
    log = pl.DataFrame(
        {
            CASE_ID: ["c1", "c1", "c1", "c1"],
            ACTIVITY: ["A", "B", "B", "C"],
            TIMESTAMP: [
                datetime(2024, 1, 1, 8, 0, 0),
                datetime(2024, 1, 1, 8, 10, 0),
                datetime(2024, 1, 1, 8, 30, 0),
                datetime(2024, 1, 1, 9, 0, 0),
            ],
        }
    ).lazy()

    result = (
        pl4pm.get_activity_pair_average_durations(log, measure="minutes")
        .collect()
        .sort(["source_activity", "target_activity"])
    )

    rows = {
        (row["source_activity"], row["target_activity"]): (row["avg_duration"], row["occurrences"])
        for row in result.to_dicts()
    }

    assert math.isclose(rows[("A", "B")][0], 20.0, rel_tol=1e-9)
    assert rows[("A", "B")][1] == 2
    assert math.isclose(rows[("B", "B")][0], 20.0, rel_tol=1e-9)
    assert rows[("B", "B")][1] == 1
    assert math.isclose(rows[("A", "C")][0], 60.0, rel_tol=1e-9)
    assert rows[("A", "C")][1] == 1


@pytest.mark.parametrize("log_index", range(10))
def test_get_rework_cases_per_activity(synthetic_logs, log_index):
    info = synthetic_logs[log_index]

    pm_result, pm_time = timed_call(pm4py.get_rework_cases_per_activity, info.pm_df)
    pl_df_result, pl_df_time = timed_call(pl4pm.get_rework_cases_per_activity, info.standard_lazy)
    pl_lazy_result, pl_lazy_time = timed_call(pl4pm.get_rework_cases_per_activity, info.standard_lazy)

    pm_norm = _normalize_dict_keys(pm_result)
    pl_df_norm = _normalize_dict_keys(pl_df_result)
    pl_lazy_norm = _normalize_dict_keys(pl_lazy_result)

    if pl_df_norm != pm_norm:
        record_mismatch(f"{info.name}:get_rework_cases", pm_norm, pl_df_norm, pl_lazy_norm)
    assert pl_df_norm == pm_norm
    assert pl_lazy_norm == pm_norm
    print_perf(f"{info.name}:get_rework_cases", pm_time, pl_df_time, pl_lazy_time)


# ════════════════════════════════════════════════════════════════════
# pl4pm-only functions (DF vs Lazy consistency)
# ════════════════════════════════════════════════════════════════════

@pytest.mark.parametrize("log_index", range(10))
def test_get_trace_attributes_df_vs_lazy(synthetic_logs, log_index):
    info = synthetic_logs[log_index]

    pl_df_result, pl_df_time = timed_call(pl4pm.get_trace_attributes, info.standard_lazy)
    pl_lazy_result, pl_lazy_time = timed_call(pl4pm.get_trace_attributes, info.standard_lazy)

    assert set(pl_df_result) == set(pl_lazy_result)
    print_perf(f"{info.name}:get_trace_attributes", None, pl_df_time, pl_lazy_time)


@pytest.mark.parametrize("log_index", range(10))
def test_get_cycle_time_df_vs_lazy(synthetic_logs, log_index):
    info = synthetic_logs[log_index]

    pl_df_result, pl_df_time = timed_call(pl4pm.get_cycle_time, info.standard_lazy)
    pl_lazy_result, pl_lazy_time = timed_call(pl4pm.get_cycle_time, info.standard_lazy)

    assert math.isclose(pl_df_result, pl_lazy_result, rel_tol=1e-6, abs_tol=1e-9), \
        f"Cycle time: DF={pl_df_result} vs Lazy={pl_lazy_result}"
    print_perf(f"{info.name}:get_cycle_time", None, pl_df_time, pl_lazy_time)


@pytest.mark.parametrize("log_index", range(10))
def test_get_service_time_df_vs_lazy(synthetic_logs, log_index):
    info = synthetic_logs[log_index]

    pl_df_result, pl_df_time = timed_call(pl4pm.get_service_time, info.standard_lazy)
    pl_lazy_result, pl_lazy_time = timed_call(pl4pm.get_service_time, info.standard_lazy)

    pl_df_norm = _normalize_dict_keys(pl_df_result)
    pl_lazy_norm = _normalize_dict_keys(pl_lazy_result)

    assert _dicts_approx_equal(pl_df_norm, pl_lazy_norm, rel_tol=1e-6), \
        f"Service time mismatch: DF={pl_df_norm} vs Lazy={pl_lazy_norm}"
    print_perf(f"{info.name}:get_service_time", None, pl_df_time, pl_lazy_time)


@pytest.mark.parametrize("log_index", range(3))  # Limited to 3 — O(n^2) overlap
def test_get_case_overlap_df_vs_lazy(synthetic_logs, log_index):
    info = synthetic_logs[log_index]

    pl_df_result, pl_df_time = timed_call(pl4pm.get_case_overlap, info.standard_lazy)
    pl_lazy_result, pl_lazy_time = timed_call(pl4pm.get_case_overlap, info.standard_lazy)

    assert pl_df_result == pl_lazy_result
    print_perf(f"{info.name}:get_case_overlap", None, pl_df_time, pl_lazy_time)


@pytest.mark.parametrize("log_index", range(3))  # Limited — O(n * variants) segments
def test_get_frequent_trace_segments_df_vs_lazy(synthetic_logs, log_index):
    info = synthetic_logs[log_index]

    pl_df_result, pl_df_time = timed_call(
        pl4pm.get_frequent_trace_segments, info.standard_lazy, 2
    )
    pl_lazy_result, pl_lazy_time = timed_call(
        pl4pm.get_frequent_trace_segments, info.standard_lazy, 2
    )

    assert dict(pl_df_result) == dict(pl_lazy_result)
    print_perf(f"{info.name}:get_frequent_trace_segments", None, pl_df_time, pl_lazy_time)


@pytest.mark.parametrize("log_index", range(10))
def test_get_variants_paths_duration_df_vs_lazy(synthetic_logs, log_index):
    info = synthetic_logs[log_index]

    pl_df_result, pl_df_time = timed_call(pl4pm.get_variants_paths_duration, info.standard_lazy)
    pl_lazy_result, pl_lazy_time = timed_call(pl4pm.get_variants_paths_duration, info.standard_lazy)

    # Both return DataFrames; compare row count and columns
    assert pl_df_result.shape == pl_lazy_result.shape, \
        f"Shape mismatch: DF={pl_df_result.shape} vs Lazy={pl_lazy_result.shape}"
    print_perf(f"{info.name}:get_variants_paths_duration", None, pl_df_time, pl_lazy_time)


@pytest.mark.parametrize("log_index", range(10))
def test_split_by_process_variant_df_vs_lazy(synthetic_logs, log_index):
    info = synthetic_logs[log_index]

    pl_df_result, pl_df_time = timed_call(
        lambda: dict(pl4pm.split_by_process_variant(info.standard_lazy))
    )
    pl_lazy_result, pl_lazy_time = timed_call(
        lambda: dict(pl4pm.split_by_process_variant(info.standard_lazy))
    )

    # Compare variant keys and total rows
    assert set(pl_df_result.keys()) == set(pl_lazy_result.keys())
    df_total = sum(v.height for v in pl_df_result.values())
    lazy_total = sum(v.height for v in pl_lazy_result.values())
    assert df_total == lazy_total
    print_perf(f"{info.name}:split_by_process_variant", None, pl_df_time, pl_lazy_time)
