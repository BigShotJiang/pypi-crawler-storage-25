"""Test suite for pl4pm.org — benchmarking pm4py vs pl4pm DF vs Lazy."""
from __future__ import annotations

import polars as pl
import pytest

import pm4py
import pl4pm

from _filter_read_support import (
    print_perf,
    record_mismatch,
    synthetic_logs,
    timed_call,
)


def _normalize_sna(sna_obj):
    if sna_obj is None:
        return None
    if hasattr(sna_obj, "to_dict"):
        raw_dict = sna_obj.to_dict()
    elif isinstance(sna_obj, dict):
        raw_dict = sna_obj
    else:
        return str(sna_obj)
        
    return tuple(sorted(((str(a), str(b)), round(float(w), 5)) for (a, b), w in raw_dict.items()))


def _normalize_roles(roles):
    if roles is None:
        return None
    if isinstance(roles, list) and len(roles) > 0 and (hasattr(roles[0], "activities") or hasattr(roles[0], "originator_set") or str(type(roles[0])).find("Role") != -1):
        def _get_res(r):
            if hasattr(r, "resources") and r.resources: return r.resources
            if hasattr(r, "originator_set") and r.originator_set: return r.originator_set
            if hasattr(r, "originators") and r.originators: return r.originators
            for k in dir(r):
                if k not in ("activities", "properties") and not k.startswith("_"):
                    v = getattr(r, k)
                    if isinstance(v, (set, list, tuple)): return v
            return set()
            
        def _get_act(r):
            return getattr(r, "activities", set())
            
        return tuple(sorted(
            (tuple(sorted(_get_act(r))), tuple(sorted(_get_res(r)))) 
            for r in roles
        ))
    elif isinstance(roles, list):
        return tuple(sorted(str(r) for r in roles))
    return str(roles)


ORG_FUNCS = [
    ("discover_handover_of_work_network", _normalize_sna),
    ("discover_working_together_network", _normalize_sna),
    ("discover_activity_based_resource_similarity", _normalize_sna),
    ("discover_subcontracting_network", _normalize_sna),
    ("discover_organizational_roles", _normalize_roles),
]


@pytest.mark.parametrize("func_name, normalizer", ORG_FUNCS)
@pytest.mark.parametrize("log_index", range(5))
def test_org_matches_pm4py_and_lazy(synthetic_logs, func_name, normalizer, log_index):
    info = synthetic_logs[log_index]
    
    pl_func = getattr(pl4pm, func_name)
    pm_func = getattr(pm4py, func_name, None)
    
    pl_df_result, pl_df_time = timed_call(pl_func, info.standard_lazy)
    pl_lazy_result, pl_lazy_time = timed_call(pl_func, info.standard_lazy)
    
    pl_df_norm = normalizer(pl_df_result)
    pl_lazy_norm = normalizer(pl_lazy_result)
    assert pl_df_norm == pl_lazy_norm
    
    pm_time = None
    if pm_func is not None:
        try:
            pm_result, pm_time = timed_call(pm_func, info.pm_df)
            pm_norm = normalizer(pm_result)
            if pl_df_norm != pm_norm:
                if isinstance(pm_norm, str) and pm_norm.startswith("<pm4py."):
                    pass
                else:
                    record_mismatch(f"{info.name}:{func_name}", pm_norm, pl_df_norm, pl_lazy_norm)
        except Exception as e:
            print(f"pm4py failed on {func_name}: {e}")
            
    print_perf(f"{info.name}:{func_name}", pm_time, pl_df_time, pl_lazy_time)


@pytest.mark.parametrize("log_index", range(5))
def test_org_network_analysis(synthetic_logs, log_index):
    info = synthetic_logs[log_index]
    pl_func = pl4pm.discover_network_analysis
    
    pl_df_result, pl_time = timed_call(pl_func, info.standard_lazy)
    pl_lazy_result, _ = timed_call(pl_func, info.standard_lazy)
    
    def _norm(res):
        if not isinstance(res, dict): return str(res)
        return tuple(sorted((str(k), v["frequency"], tuple(sorted(v.get("edge_types", {}).items()))) for k, v in res.items()))
        
    assert _norm(pl_df_result) == _norm(pl_lazy_result)
