from __future__ import annotations

import polars as pl
import pytest

import pm4py
import pl4pm

from _filter_read_support import (
    ACTIVITY,
    CASE_ID,
    RESOURCE,
    TIMESTAMP,
    normalize_bpmn,
    normalize_dfg,
    normalize_ocel,
    normalize_petri_net,
    normalize_table,
    normalize_tree,
    print_perf,
    read_assets,
    record_mismatch,
    standardize_pl,
    standardize_pm,
    synthetic_logs,
    timed_call,
)


@pytest.mark.parametrize("log_index", range(10))
def test_read_csv_matches_source(synthetic_logs, log_index):
    info = synthetic_logs[log_index]
    pl_result, pl_time = timed_call(pl4pm.read_csv, str(info.csv_path))

    expected = standardize_pl(info.raw_df)
    assert normalize_table(pl_result) == normalize_table(expected)

    print_perf(f"{info.name}:read_csv", None, pl_time)


@pytest.mark.parametrize("log_index", range(10))
def test_format_dataframe_matches_pm4py_and_lazy(synthetic_logs, log_index):
    info = synthetic_logs[log_index]
    pl_result, pl_time = timed_call(
        pl4pm.format_dataframe,
        info.raw_df.lazy(),
        case_id_column="Case ID",
        activity_column="Activity",
        timestamp_column="Timestamp",
    )
    pm_result, pm_time = timed_call(
        pm4py.format_dataframe,
        info.raw_df.to_pandas(),
        case_id="Case ID",
        activity_key="Activity",
        timestamp_key="Timestamp",
    )

    assert normalize_table(pl_result) == normalize_table(standardize_pm(pm_result))

    print_perf(f"{info.name}:format_dataframe", pm_time, pl_time)


@pytest.mark.parametrize("log_index", range(10))
def test_read_parquet_matches_source_and_lazy(synthetic_logs, log_index):
    info = synthetic_logs[log_index]
    pl_result, pl_time = timed_call(pl4pm.read_parquet, str(info.parquet_path))

    expected = standardize_pl(pl.read_parquet(info.parquet_path))
    assert normalize_table(pl_result) == normalize_table(expected)

    print_perf(f"{info.name}:read_parquet", None, pl_time)


@pytest.mark.parametrize("log_index", range(10))
def test_read_xes_matches_pm4py_and_lazy(synthetic_logs, read_assets, log_index):
    info = synthetic_logs[log_index]
    xes_path = read_assets[info.name]["xes"]

    pm_result, pm_time = timed_call(pm4py.read_xes, str(xes_path), return_legacy_log_object=False)
    pl_result, pl_time = timed_call(pl4pm.read_xes, str(xes_path))

    assert normalize_table(pl_result) == normalize_table(pm_result)

    print_perf(f"{info.name}:read_xes", pm_time, pl_time)


@pytest.mark.parametrize("log_index", range(10))
def test_read_ocel_csv_matches_pm4py(synthetic_logs, read_assets, log_index):
    info = synthetic_logs[log_index]
    asset_bundle = read_assets[info.name]
    pl_result, pl_time = timed_call(
        pl4pm.read_ocel_csv,
        str(asset_bundle["ocel_csv_events"]),
        objects_path=str(asset_bundle["ocel_csv_objects"]),
    )
    pm_result, pm_time = timed_call(
        pm4py.read_ocel_csv,
        str(asset_bundle["ocel_csv_events"]),
        objects_path=str(asset_bundle["ocel_csv_objects"]),
    )

    pm_normalized = normalize_ocel(pm_result)
    pl_normalized = normalize_ocel(pl_result)
    if pl_normalized != pm_normalized:
        record_mismatch(
            f"{info.name}:read_ocel_csv",
            pm_normalized,
            pl_normalized,
            None,
        )
    assert pl_normalized == pm_normalized
    print_perf(f"{info.name}:read_ocel_csv", pm_time, pl_time, None)


MODEL_CASES = [
    ("read_dfg", "dfg", normalize_dfg),
    ("read_pnml", "pnml", normalize_petri_net),
    ("read_ptml", "ptml", normalize_tree),
    ("read_bpmn", "bpmn", normalize_bpmn),
]


@pytest.mark.parametrize("func_name,asset_key,normalizer", MODEL_CASES)
@pytest.mark.parametrize("log_index", range(10))
def test_model_readers_match_pm4py(synthetic_logs, read_assets, func_name, asset_key, normalizer, log_index):
    info = synthetic_logs[log_index]
    asset_bundle = read_assets[info.name]
    asset_path = asset_bundle[asset_key]
    pm_func = getattr(pm4py, func_name)
    pl_func = getattr(pl4pm, func_name)

    pl_result, pl_time = timed_call(pl_func, str(asset_path))
    pl_normalized = normalizer(pl_result)
    expected_normalized = asset_bundle[f"expected_{asset_key}"]
    if pl_normalized != expected_normalized:
        record_mismatch(
            f"{info.name}:{func_name}",
            expected_normalized,
            pl_normalized,
            None,
        )
    assert pl_normalized == expected_normalized

    pm_time = None
    try:
        pm_result, pm_time = timed_call(pm_func, str(asset_path))
        pm_normalized = normalizer(pm_result)
        if pl_normalized != pm_normalized:
            record_mismatch(
                f"{info.name}:{func_name}:pm4py_compare",
                pm_normalized,
                pl_normalized,
                None,
            )
        assert pl_normalized == pm_normalized
    except Exception as exc:
        print(f"{info.name}:{func_name} pm4py skipped ({type(exc).__name__}: {exc})")

    print_perf(f"{info.name}:{func_name}", pm_time, pl_time, None)


OCEL_CASES = [
    ("read_ocel", "ocel_json"),
    ("read_ocel", "ocel_xml"),
    ("read_ocel", "ocel_sqlite"),
    ("read_ocel2", "ocel2_json"),
    ("read_ocel2", "ocel2_xml"),
    ("read_ocel2", "ocel2_sqlite"),
]


@pytest.mark.parametrize("func_name,asset_key", OCEL_CASES)
@pytest.mark.parametrize("log_index", range(10))
def test_ocel_read_wrappers_match_pm4py(synthetic_logs, read_assets, func_name, asset_key, log_index):
    info = synthetic_logs[log_index]
    asset_bundle = read_assets[info.name]
    asset_path = asset_bundle[asset_key]
    pm_func = getattr(pm4py, func_name, None)
    pl_func = getattr(pl4pm, func_name)

    pl_result, pl_time = timed_call(pl_func, str(asset_path))
    pl_normalized = normalize_ocel(pl_result)
    expected_normalized = asset_bundle["expected_ocel"]
    if pl_normalized != expected_normalized:
        record_mismatch(
            f"{info.name}:{func_name}:{asset_key}",
            expected_normalized,
            pl_normalized,
            None,
        )
    assert pl_normalized == expected_normalized
    pm_time = None
    if callable(pm_func):
        try:
            pm_result, pm_time = timed_call(pm_func, str(asset_path))
            pm_normalized = normalize_ocel(pm_result)
            if pl_normalized != pm_normalized:
                record_mismatch(
                    f"{info.name}:{func_name}:{asset_key}:pm4py_compare",
                    pm_normalized,
                    pl_normalized,
                    None,
                )
            assert pl_normalized == pm_normalized
        except Exception as exc:
            print(f"{info.name}:{func_name}:{asset_key} pm4py skipped ({type(exc).__name__}: {exc})")
    else:
        print(f"{info.name}:{func_name}:{asset_key} pm4py not available")

    print_perf(f"{info.name}:{func_name}:{asset_key}", pm_time, pl_time, None)
