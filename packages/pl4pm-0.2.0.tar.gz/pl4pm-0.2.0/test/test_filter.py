from __future__ import annotations

from datetime import datetime

import polars as pl
import pytest

import pm4py
import pl4pm

from _filter_read_support import (
    ACTIVITY,
    CASE_ID,
    RESOURCE,
    TIMESTAMP,
    normalize_table,
    print_perf,
    record_mismatch,
    synthetic_logs,
    timed_call,
)


def _variants(log_df):
    rows = (
        log_df.sort([CASE_ID, TIMESTAMP])
        .group_by(CASE_ID)
        .agg(pl.col(ACTIVITY).alias("_variant"))
        .collect()
        .to_dicts()
    )
    return [tuple(row["_variant"]) for row in rows[:2]]


def _scenario_params(info, scenario):
    df = info.standard_lazy
    materialized = df.collect()
    end_activities = (
        df.sort([CASE_ID, TIMESTAMP])
        .group_by(CASE_ID)
        .agg(pl.col(ACTIVITY).last().alias("_last"))
        .collect()
        .get_column("_last")
        .unique()
        .to_list()
    )
    timestamps = materialized.get_column(TIMESTAMP).sort()
    dt1 = timestamps[int(len(timestamps) * 0.2)]
    dt2 = timestamps[int(len(timestamps) * 0.8)]
    durations = (
        df.group_by(CASE_ID)
        .agg(
            [
                pl.col(TIMESTAMP).min().alias("_start"),
                pl.col(TIMESTAMP).max().alias("_end"),
            ]
        )
        .with_columns((pl.col("_end") - pl.col("_start")).dt.total_seconds().alias("_dur"))
        .sort("_dur")
        .collect()
    )
    duration_values = durations.get_column("_dur").to_list()
    min_duration = duration_values[max(0, len(duration_values) // 4 - 1)]
    max_duration = duration_values[min(len(duration_values) - 1, (len(duration_values) * 3) // 4)]

    if scenario == "start":
        return {"activities": ["Create Request"], "retain": True}
    if scenario == "end":
        return {"activities": end_activities[:3], "retain": True}
    if scenario == "event_attr":
        return {"attribute_key": ACTIVITY, "values": ["Reject Budget", "Reopen Request"], "retain": True, "level": "case"}
    if scenario == "trace_attr":
        return {"attribute_key": "Variant", "values": materialized.get_column("Variant").unique().to_list()[:2], "retain": True}
    if scenario == "variants":
        return {"variants": _variants(df), "retain": True}
    if scenario == "df_rel":
        return {"relations": [("Validate Request", "Approve Budget"), ("Compare Quotes", "Issue Purchase Order")], "retain": True}
    if scenario == "ef_rel":
        return {"relations": [("Create Request", "Pay Invoice"), ("Create Request", "Close Case")], "retain": True}
    if scenario == "time_range":
        return {"dt1": dt1.isoformat(sep=" "), "dt2": dt2.isoformat(sep=" "), "mode": "traces_intersecting"}
    if scenario == "case_perf":
        return {"min_performance": float(min_duration), "max_performance": float(max_duration)}
    if scenario == "case_size":
        return {"min_size": 5, "max_size": 20}
    if scenario == "between":
        return {"act1": "Create Request", "act2": "Issue Purchase Order"}
    if scenario == "rework":
        return {"activity": "Validate Request", "min_num_occurrences": 2}
    if scenario == "prefix":
        return {"activity": "Issue Purchase Order", "strict": True}
    if scenario == "four_eyes":
        return {"activity1": "Approve Budget", "activity2": "Issue Purchase Order"}
    if scenario == "rel_occ":
        return {"min_relative_stake": 0.2, "attribute_key": ACTIVITY, "level": "cases"}
    if scenario == "top_k":
        return {"k": 2}
    if scenario == "coverage":
        return {"min_coverage_percentage": 0.2}
    if scenario == "suffix":
        return {"activity": "Issue Purchase Order", "strict": True}
    if scenario == "path_perf":
        return {"path": ("Validate Request", "Approve Budget"), "min_performance": float(min_duration), "max_performance": float(max_duration)}
    if scenario == "diff_res":
        return {"activity": "Validate Request"}
    if scenario == "trace_seg":
        return {"admitted_traces": [["...", "Validate Request", "Approve Budget", "..."]]}
    raise AssertionError(f"Unknown scenario: {scenario}")


FILTER_CASES = [
    ("filter_start_activities", "start"),
    ("filter_end_activities", "end"),
    ("filter_event_attribute_values", "event_attr"),
    ("filter_trace_attribute_values", "trace_attr"),
    ("filter_variants", "variants"),
    ("filter_directly_follows_relation", "df_rel"),
    ("filter_eventually_follows_relation", "ef_rel"),
    ("filter_time_range", "time_range"),
    ("filter_case_performance", "case_perf"),
    ("filter_case_size", "case_size"),
    ("filter_between", "between"),
    ("filter_activities_rework", "rework"),
    ("filter_prefixes", "prefix"),
    ("filter_four_eyes_principle", "four_eyes"),
    ("filter_log_relative_occurrence_event_attribute", "rel_occ"),
    ("filter_variants_top_k", "top_k"),
    ("filter_variants_by_coverage_percentage", "coverage"),
    ("filter_suffixes", "suffix"),
    ("filter_paths_performance", "path_perf"),
    ("filter_activity_done_different_resources", "diff_res"),
    ("filter_trace_segments", "trace_seg"),
]


@pytest.mark.parametrize("func_name,scenario", FILTER_CASES)
@pytest.mark.parametrize("log_index", range(10))
def test_filter_matches_pm4py_and_lazy(synthetic_logs, func_name, scenario, log_index):
    info = synthetic_logs[log_index]
    params = _scenario_params(info, scenario)
    pl_func = getattr(pl4pm, func_name)
    pm_func = getattr(pm4py, func_name)

    pl_kwargs = dict(params)
    pm_kwargs = dict(params)
    if func_name == "filter_activities_rework":
        pm_kwargs["min_occurrences"] = pm_kwargs.pop("min_num_occurrences")
    pm_input = info.pm_df
    if func_name in {"filter_variants", "filter_variants_top_k", "filter_variants_by_coverage_percentage", "filter_trace_segments"}:
        pm_input = pm4py.convert_to_event_log(info.pm_df)

    pm_result, pm_time = timed_call(pm_func, pm_input, **pm_kwargs)
    pl_result, pl_time = timed_call(pl_func, info.standard_lazy, **pl_kwargs)

    pm_normalized = normalize_table(pm_result)
    pl_normalized = normalize_table(pl_result)

    if pl_normalized != pm_normalized:
        record_mismatch(
            f"{info.name}:{func_name}",
            pm_normalized,
            pl_normalized,
        )
    if pl_normalized != pm_normalized and func_name in {"filter_time_range", "filter_between", "filter_variants_top_k"}:
        pytest.xfail(f"Known semantic divergence between pm4py and pl4pm for {func_name} on {info.name}")

    assert pl_normalized == pm_normalized

    print_perf(f"{info.name}:{func_name}", pm_time, pl_time)


def test_filter_activities_duration_returns_expected_cases_and_collect_modes():
    log = pl.DataFrame(
        {
            CASE_ID: ["c1", "c1", "c1", "c2", "c2", "c3", "c3"],
            ACTIVITY: ["A", "B", "C", "A", "B", "B", "A"],
            TIMESTAMP: [
                datetime(2024, 1, 1, 8, 0, 0),
                datetime(2024, 1, 1, 8, 30, 0),
                datetime(2024, 1, 1, 9, 0, 0),
                datetime(2024, 1, 1, 8, 0, 0),
                datetime(2024, 1, 1, 10, 0, 0),
                datetime(2024, 1, 1, 8, 0, 0),
                datetime(2024, 1, 1, 8, 20, 0),
            ],
        }
    ).lazy()

    lazy_result = pl4pm.filter_activities_duration(
        log,
        ("A", "B"),
        45,
        "minutes",
        "<=",
    )
    assert isinstance(lazy_result, pl.LazyFrame)
    normalized = normalize_table(lazy_result)
    assert {row[CASE_ID] for row in normalized} == {"c1"}

    collected = pl4pm.filter_activities_duration(
        log,
        ("A", "B"),
        90,
        "minutes",
        ">=",
        do_collect=True,
        collect_engine="streaming",
    )
    assert isinstance(collected, pl.DataFrame)
    assert set(collected.get_column(CASE_ID).unique().to_list()) == {"c2"}


def test_filter_trace_segments_handles_prefix_suffix_and_internal_wildcards():
    log = pl.DataFrame(
        {
            CASE_ID: ["c1", "c1", "c1", "c1", "c2", "c2", "c2", "c3", "c3", "c3", "c4", "c4", "c4"],
            ACTIVITY: ["A", "B", "C", "D", "X", "A", "B", "A", "B", "X", "A", "X", "D"],
            TIMESTAMP: [
                datetime(2024, 1, 1, 8, 0, 0),
                datetime(2024, 1, 1, 8, 1, 0),
                datetime(2024, 1, 1, 8, 2, 0),
                datetime(2024, 1, 1, 8, 3, 0),
                datetime(2024, 1, 1, 9, 0, 0),
                datetime(2024, 1, 1, 9, 1, 0),
                datetime(2024, 1, 1, 9, 2, 0),
                datetime(2024, 1, 1, 10, 0, 0),
                datetime(2024, 1, 1, 10, 1, 0),
                datetime(2024, 1, 1, 10, 2, 0),
                datetime(2024, 1, 1, 11, 0, 0),
                datetime(2024, 1, 1, 11, 1, 0),
                datetime(2024, 1, 1, 11, 2, 0),
            ],
        }
    ).lazy()

    result = (
        pl4pm.filter_trace_segments(
            log,
            admitted_traces=[["A", "B", "...", "D"], ["...", "B", "C", "..."]],
        )
        .select(CASE_ID)
        .unique()
        .sort(CASE_ID)
        .collect()
        .get_column(CASE_ID)
        .to_list()
    )

    assert result == ["c1"]
