"""Test suite for pl4pm.analysis — 3-way benchmarking (pm4py vs pl4pm DF vs Lazy)."""
from __future__ import annotations

import math
import polars as pl
import pytest

import pm4py
import pl4pm

from _filter_read_support import (
    ACTIVITY,
    CASE_ID,
    TIMESTAMP,
    normalize_table,
    print_perf,
    record_mismatch,
    synthetic_logs,
    timed_call,
)


# ════════════════════════════════════════════════════════════════════
# Shared fixtures
# ════════════════════════════════════════════════════════════════════

@pytest.fixture(scope="session")
def analysis_models(synthetic_logs):
    """Discover Petri nets for analysis tests."""
    models = []
    for info in synthetic_logs:
        pm_net, pm_im, pm_fm = pm4py.discover_petri_net_inductive(info.pm_df)
        pl_net, pl_im, pl_fm = pl4pm.discover_petri_net_inductive(info.standard_lazy)
        models.append({
            "pm_net": (pm_net, pm_im, pm_fm),
            "pl_net": (pl_net, pl_im, pl_fm),
        })
    return models


# ════════════════════════════════════════════════════════════════════
# Workflow net and soundness checks
# ════════════════════════════════════════════════════════════════════

@pytest.mark.parametrize("log_index", range(10))
def test_check_is_workflow_net(synthetic_logs, analysis_models, log_index):
    info = synthetic_logs[log_index]
    pm_net, pm_im, pm_fm = analysis_models[log_index]["pm_net"]
    pl_net, pl_im, pl_fm = analysis_models[log_index]["pl_net"]

    pm_result, pm_time = timed_call(pm4py.check_is_workflow_net, pm_net)
    pl_result, pl_time = timed_call(pl4pm.check_is_workflow_net, pl_net)

    assert pl_result == pm_result, \
        f"WF-net check: pl4pm={pl_result} vs pm4py={pm_result}"
    print_perf(f"{info.name}:check_is_workflow_net", pm_time, pl_time, None)


@pytest.mark.parametrize("log_index", range(10))
def test_check_soundness(synthetic_logs, analysis_models, log_index):
    info = synthetic_logs[log_index]
    pl_net, pl_im, pl_fm = analysis_models[log_index]["pl_net"]

    pl_result, pl_time = timed_call(pl4pm.check_soundness, pl_net, pl_im, pl_fm)

    is_sound, diagnostics = pl_result
    assert isinstance(is_sound, bool)
    assert isinstance(diagnostics, dict)
    assert "is_wf_net" in diagnostics
    assert "can_reach_final_marking" in diagnostics
    assert "n_reachable_states" in diagnostics
    print_perf(f"{info.name}:check_soundness", None, pl_time, None)


@pytest.mark.parametrize("log_index", range(10))
def test_check_is_sound(synthetic_logs, analysis_models, log_index):
    info = synthetic_logs[log_index]
    pm_net, pm_im, pm_fm = analysis_models[log_index]["pm_net"]
    pl_net, pl_im, pl_fm = analysis_models[log_index]["pl_net"]

    try:
        pm_result, pm_time = timed_call(pm4py.check_is_sound, pm_net, pm_im, pm_fm)
    except Exception:
        pm_result, pm_time = None, None

    pl_result, pl_time = timed_call(pl4pm.check_is_sound, pl_net, pl_im, pl_fm)

    assert isinstance(pl_result, bool)
    if pm_result is not None:
        assert pl_result == pm_result, \
            f"Sound check: pl4pm={pl_result} vs pm4py={pm_result}"
    print_perf(f"{info.name}:check_is_sound", pm_time, pl_time, None)


# ════════════════════════════════════════════════════════════════════
# Simplicity
# ════════════════════════════════════════════════════════════════════

@pytest.mark.parametrize("log_index", range(10))
def test_simplicity_petri_net(synthetic_logs, analysis_models, log_index):
    info = synthetic_logs[log_index]
    pm_net, pm_im, pm_fm = analysis_models[log_index]["pm_net"]
    pl_net, pl_im, pl_fm = analysis_models[log_index]["pl_net"]

    try:
        pm_result, pm_time = timed_call(pm4py.simplicity_petri_net, pm_net, pm_im, pm_fm)
    except Exception:
        pm_result, pm_time = None, None

    pl_result, pl_time = timed_call(pl4pm.simplicity_petri_net, pl_net, pl_im, pl_fm)

    assert isinstance(pl_result, float)
    assert 0.0 <= pl_result <= 1.0, f"Simplicity out of range: {pl_result}"
    if pm_result is not None:
        assert math.isclose(pl_result, pm_result, abs_tol=0.15), \
            f"Simplicity: pl4pm={pl_result:.4f} vs pm4py={pm_result:.4f}"
    print_perf(f"{info.name}:simplicity_petri_net", pm_time, pl_time, None)


# ════════════════════════════════════════════════════════════════════
# Maximal decomposition
# ════════════════════════════════════════════════════════════════════

@pytest.mark.parametrize("log_index", range(10))
def test_maximal_decomposition(synthetic_logs, analysis_models, log_index):
    info = synthetic_logs[log_index]
    pl_net, pl_im, pl_fm = analysis_models[log_index]["pl_net"]

    pl_result, pl_time = timed_call(pl4pm.maximal_decomposition, pl_net, pl_im, pl_fm)

    assert isinstance(pl_result, list)
    assert len(pl_result) == len(pl_net.transitions), \
        f"Decomposition: {len(pl_result)} components vs {len(pl_net.transitions)} transitions"
    for subnet, sub_im, sub_fm in pl_result:
        assert len(subnet.transitions) == 1
    print_perf(f"{info.name}:maximal_decomposition", None, pl_time, None)


# ════════════════════════════════════════════════════════════════════
# Marking generation
# ════════════════════════════════════════════════════════════════════

@pytest.mark.parametrize("log_index", range(10))
def test_generate_marking(synthetic_logs, analysis_models, log_index):
    info = synthetic_logs[log_index]
    pl_net, pl_im, pl_fm = analysis_models[log_index]["pl_net"]

    # Test with a place name
    places = list(pl_net.places)
    if places:
        place = places[0]
        result = pl4pm.generate_marking(pl_net, place.name)
        assert isinstance(result, dict)
        assert place in result
        assert result[place] == 1

    # Test with dict
    result_dict = pl4pm.generate_marking(pl_net, {place.name: 2})
    assert result_dict[place] == 2
    print_perf(f"{info.name}:generate_marking", None, None, None)


# ════════════════════════════════════════════════════════════════════
# Petri net reductions
# ════════════════════════════════════════════════════════════════════

@pytest.mark.parametrize("log_index", range(10))
def test_reduce_petri_net_invisibles(synthetic_logs, analysis_models, log_index):
    info = synthetic_logs[log_index]
    pl_net, pl_im, pl_fm = analysis_models[log_index]["pl_net"]

    # Copy net to avoid mutating shared fixture
    import copy
    net_copy = copy.deepcopy(pl_net)
    original_transitions = len(net_copy.transitions)

    result, pl_time = timed_call(pl4pm.reduce_petri_net_invisibles, net_copy)

    assert isinstance(result, type(pl_net))
    assert len(result.transitions) <= original_transitions
    print_perf(f"{info.name}:reduce_invisibles", None, pl_time, None)


@pytest.mark.parametrize("log_index", range(10))
def test_reduce_petri_net_implicit_places(synthetic_logs, analysis_models, log_index):
    info = synthetic_logs[log_index]
    pl_net, pl_im, pl_fm = analysis_models[log_index]["pl_net"]

    import copy
    net_copy = copy.deepcopy(pl_net)
    im_copy = copy.deepcopy(pl_im)
    fm_copy = copy.deepcopy(pl_fm)
    original_places = len(net_copy.places)

    result, pl_time = timed_call(
        pl4pm.reduce_petri_net_implicit_places, net_copy, im_copy, fm_copy
    )
    r_net, r_im, r_fm = result
    assert len(r_net.places) <= original_places
    print_perf(f"{info.name}:reduce_implicit_places", None, pl_time, None)


# ════════════════════════════════════════════════════════════════════
# Log enrichment (DF vs Lazy)
# ════════════════════════════════════════════════════════════════════

@pytest.mark.parametrize("log_index", range(10))
def test_insert_artificial_start_end(synthetic_logs, log_index):
    info = synthetic_logs[log_index]

    pl_df_result, pl_df_time = timed_call(
        pl4pm.insert_artificial_start_end, info.standard_lazy
    )
    pl_lazy_result, pl_lazy_time = timed_call(
        pl4pm.insert_artificial_start_end, info.standard_lazy
    )

    # Both return DataFrames
    assert isinstance(pl_df_result, pl.DataFrame)
    assert isinstance(pl_lazy_result, pl.DataFrame)

    # Should have more rows than original (2 per case: start + end)
    lazy_input = info.standard_lazy.collect()
    n_cases = lazy_input.select(pl.col(CASE_ID).n_unique()).item()
    expected_rows = lazy_input.height + 2 * n_cases
    assert pl_df_result.height == expected_rows, \
        f"Expected {expected_rows} rows, got {pl_df_result.height}"
    assert pl_lazy_result.height == expected_rows

    # Check artificial activities exist
    arts = pl_df_result[ACTIVITY].unique().to_list()
    assert "▶" in arts, "Artificial start not found"
    assert "■" in arts, "Artificial end not found"

    print_perf(f"{info.name}:insert_artificial_start_end", None, pl_df_time, pl_lazy_time)


@pytest.mark.parametrize("log_index", range(10))
def test_insert_case_service_waiting_time(synthetic_logs, log_index):
    info = synthetic_logs[log_index]

    pl_df_result, pl_df_time = timed_call(
        pl4pm.insert_case_service_waiting_time, info.standard_lazy
    )
    pl_lazy_result, pl_lazy_time = timed_call(
        pl4pm.insert_case_service_waiting_time, info.standard_lazy
    )

    assert isinstance(pl_df_result, pl.DataFrame)
    assert isinstance(pl_lazy_result, pl.DataFrame)

    # Should have 3 new columns
    assert "@@service_time" in pl_df_result.columns
    assert "@@sojourn_time" in pl_df_result.columns
    assert "@@waiting_time" in pl_df_result.columns

    assert "@@service_time" in pl_lazy_result.columns
    assert pl_df_result.height == pl_lazy_result.height

    print_perf(f"{info.name}:insert_service_waiting", None, pl_df_time, pl_lazy_time)


@pytest.mark.parametrize("log_index", range(10))
def test_insert_case_arrival_finish_rate(synthetic_logs, log_index):
    info = synthetic_logs[log_index]

    pl_df_result, pl_df_time = timed_call(
        pl4pm.insert_case_arrival_finish_rate, info.standard_lazy
    )
    pl_lazy_result, pl_lazy_time = timed_call(
        pl4pm.insert_case_arrival_finish_rate, info.standard_lazy
    )

    assert isinstance(pl_df_result, pl.DataFrame)
    assert isinstance(pl_lazy_result, pl.DataFrame)

    assert "@@arrival_rate" in pl_df_result.columns
    assert "@@finish_rate" in pl_df_result.columns
    assert "@@arrival_rate" in pl_lazy_result.columns
    assert pl_df_result.height == pl_lazy_result.height

    print_perf(f"{info.name}:insert_arrival_finish_rate", None, pl_df_time, pl_lazy_time)


# ════════════════════════════════════════════════════════════════════
# Activity labels
# ════════════════════════════════════════════════════════════════════

@pytest.mark.parametrize("log_index", range(10))
def test_get_activity_labels_from_log(synthetic_logs, log_index):
    info = synthetic_logs[log_index]

    pl_df_result, pl_df_time = timed_call(pl4pm.get_activity_labels, info.standard_lazy)
    pl_lazy_result, pl_lazy_time = timed_call(pl4pm.get_activity_labels, info.standard_lazy)

    assert isinstance(pl_df_result, list)
    assert len(pl_df_result) > 0
    assert pl_df_result == pl_lazy_result
    print_perf(f"{info.name}:get_activity_labels", None, pl_df_time, pl_lazy_time)


@pytest.mark.parametrize("log_index", range(10))
def test_get_activity_labels_from_model(synthetic_logs, analysis_models, log_index):
    info = synthetic_logs[log_index]
    pl_net, pl_im, pl_fm = analysis_models[log_index]["pl_net"]

    result = pl4pm.get_activity_labels(pl_net)
    assert isinstance(result, list)
    # Labels from net should be subset of labels from log
    log_labels = set(pl4pm.get_activity_labels(info.standard_lazy))
    net_labels = set(result)
    assert net_labels.issubset(log_labels), \
        f"Net labels not in log: {net_labels - log_labels}"
    print_perf(f"{info.name}:get_activity_labels_model", None, None, None)


# ════════════════════════════════════════════════════════════════════
# Similarity metrics
# ════════════════════════════════════════════════════════════════════

@pytest.mark.parametrize("log_index", range(5))
def test_structural_similarity(synthetic_logs, analysis_models, log_index):
    info = synthetic_logs[log_index]
    pm_net, pm_im, pm_fm = analysis_models[log_index]["pm_net"]
    pl_net, pl_im, pl_fm = analysis_models[log_index]["pl_net"]

    result = pl4pm.structural_similarity(pl_net, pl_im, pl_fm, pl_net, pl_im, pl_fm)
    assert isinstance(result, float)
    assert math.isclose(result, 1.0, abs_tol=0.01), \
        f"Self-similarity should be 1.0, got {result}"

    # Cross-similarity between pm4py and pl4pm nets
    cross = pl4pm.structural_similarity(pl_net, pl_im, pl_fm, pm_net, pm_im, pm_fm)
    assert 0.0 <= cross <= 1.0
    print_perf(f"{info.name}:structural_similarity", None, None, None)


@pytest.mark.parametrize("log_index", range(5))
def test_behavioral_similarity(synthetic_logs, analysis_models, log_index):
    info = synthetic_logs[log_index]
    pl_net, pl_im, pl_fm = analysis_models[log_index]["pl_net"]

    result = pl4pm.behavioral_similarity(pl_net, pl_im, pl_fm, pl_net, pl_im, pl_fm)
    assert isinstance(result, float)
    assert math.isclose(result, 1.0, abs_tol=0.01), \
        f"Self-behavioral-similarity should be 1.0, got {result}"
    print_perf(f"{info.name}:behavioral_similarity", None, None, None)


# ════════════════════════════════════════════════════════════════════
# Earth Mover Distance
# ════════════════════════════════════════════════════════════════════

@pytest.mark.parametrize("log_index", range(10))
def test_compute_emd(synthetic_logs, log_index):
    info = synthetic_logs[log_index]

    lang = pl4pm.get_stochastic_language(info.standard_lazy)

    # EMD of a language with itself should be 0
    result = pl4pm.compute_emd(lang, lang)
    assert math.isclose(result, 0.0, abs_tol=1e-9), \
        f"Self-EMD should be 0, got {result}"

    # EMD with empty should be 0.5
    empty_lang = {}
    if lang:
        result_empty = pl4pm.compute_emd(lang, empty_lang)
        assert 0.0 <= result_empty <= 1.0
    print_perf(f"{info.name}:compute_emd", None, None, None)


# ════════════════════════════════════════════════════════════════════
# Synchronous product net
# ════════════════════════════════════════════════════════════════════

@pytest.mark.parametrize("log_index", range(5))
def test_construct_synchronous_product_net(synthetic_logs, analysis_models, log_index):
    info = synthetic_logs[log_index]
    pl_net, pl_im, pl_fm = analysis_models[log_index]["pl_net"]

    # Get first trace
    df = info.standard_lazy
    first_case_id = df.select(pl.col(CASE_ID).first()).collect().item()
    trace = (
        df.filter(pl.col(CASE_ID) == first_case_id)
        .select(ACTIVITY)
        .collect()
        .get_column(ACTIVITY)
        .to_list()
    )

    result, pl_time = timed_call(
        pl4pm.construct_synchronous_product_net, trace, pl_net, pl_im, pl_fm
    )
    sync_net, sync_im, sync_fm = result

    assert len(sync_net.places) > 0
    assert len(sync_net.transitions) > 0
    assert len(sync_im) > 0
    assert len(sync_fm) > 0
    print_perf(f"{info.name}:sync_product_net", None, pl_time, None)


# ════════════════════════════════════════════════════════════════════
# Cluster log
# ════════════════════════════════════════════════════════════════════

@pytest.mark.parametrize("log_index", range(5))
def test_cluster_log(synthetic_logs, log_index):
    info = synthetic_logs[log_index]

    clusters_df = list(pl4pm.cluster_log(info.standard_lazy))
    clusters_lazy = list(pl4pm.cluster_log(info.standard_lazy))

    assert len(clusters_df) >= 1, "Expected at least 1 cluster"
    assert len(clusters_lazy) >= 1

    # Total rows across clusters should equal original
    total_df = sum(c.height for c in clusters_df)
    total_lazy = sum(c.height for c in clusters_lazy)
    original_height = info.standard_lazy.collect().height
    assert total_df == original_height, \
        f"Cluster row sum: {total_df} vs original {original_height}"
    assert total_lazy == original_height
    print_perf(f"{info.name}:cluster_log", None, None, None)


# ════════════════════════════════════════════════════════════════════
# Enabled transitions
# ════════════════════════════════════════════════════════════════════

@pytest.mark.parametrize("log_index", range(10))
def test_get_enabled_transitions(synthetic_logs, analysis_models, log_index):
    info = synthetic_logs[log_index]
    pl_net, pl_im, pl_fm = analysis_models[log_index]["pl_net"]

    result = pl4pm.get_enabled_transitions(pl_net, pl_im)

    assert isinstance(result, set)
    assert len(result) > 0, "No enabled transitions at initial marking"
    # All enabled transitions should be from the net
    for t in result:
        assert t in pl_net.transitions
    print_perf(f"{info.name}:get_enabled_transitions", None, None, None)


# ════════════════════════════════════════════════════════════════════
# Marking equation
# ════════════════════════════════════════════════════════════════════

@pytest.mark.parametrize("log_index", range(10))
def test_solve_marking_equation(synthetic_logs, analysis_models, log_index):
    info = synthetic_logs[log_index]
    pl_net, pl_im, pl_fm = analysis_models[log_index]["pl_net"]

    result, pl_time = timed_call(pl4pm.solve_marking_equation, pl_net, pl_im, pl_fm)

    assert isinstance(result, float)
    assert result >= 0.0, f"Marking equation cost should be >= 0, got {result}"
    print_perf(f"{info.name}:solve_marking_equation", None, pl_time, None)
