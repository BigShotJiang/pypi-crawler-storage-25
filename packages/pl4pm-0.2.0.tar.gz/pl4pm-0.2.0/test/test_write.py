"""Test suite for pl4pm.write — benchmarking pm4py vs pl4pm DF vs Lazy."""
from __future__ import annotations

from pathlib import Path

import polars as pl
import pytest

import pm4py
import pl4pm

from _filter_read_support import (
    ACTIVITY,
    CASE_ID,
    RESOURCE,
    VARIANT,
    normalize_bpmn,
    normalize_dfg,
    normalize_ocel,
    normalize_petri_net,
    normalize_table,
    normalize_tree,
    print_perf,
    record_mismatch,
    synthetic_logs,
    timed_call,
)


def _maybe_timed_pm4py(label: str, func_name: str, *args, **kwargs):
    func = getattr(pm4py, func_name, None)
    if func is None:
        print(f"{label} pm4py skipped (AttributeError: missing {func_name})")
        return None, None
    try:
        return timed_call(func, *args, **kwargs)
    except Exception as exc:
        print(f"{label} pm4py skipped ({type(exc).__name__}: {exc})")
        return None, None


def _normalize_petri_shape(result):
    net, im, fm = result
    visible = sorted(
        str(getattr(transition, "label", None) or "")
        for transition in net.transitions
        if getattr(transition, "label", None)
    )
    silent_count = sum(1 for transition in net.transitions if not getattr(transition, "label", None))
    return {
        "place_count": len(net.places),
        "transition_count": len(net.transitions),
        "visible_labels": visible,
        "silent_count": silent_count,
        "initial_tokens": sum(int(tokens) for tokens in im.values()),
        "final_tokens": sum(int(tokens) for tokens in fm.values()),
    }


def _normalize_bpmn_semantics(model):
    raw = normalize_bpmn(model)
    node_types = [node_type for node_type, _ in raw["nodes"]]
    task_names = sorted(
        name
        for node_type, name in raw["nodes"]
        if node_type == "task" and name and name != "τ"
    )
    return {
        "task_names": task_names,
        "has_start": any(node_type == "startevent" for node_type in node_types),
        "has_end": any(node_type == "endevent" for node_type in node_types),
        "gateway_count": sum("gateway" in str(node_type) for node_type in node_types),
    }


@pytest.fixture(scope="session")
def write_models(synthetic_logs):
    models = []
    for info in synthetic_logs:
        pm_tree = pm4py.discover_process_tree_inductive(info.pm_df)
        pl_tree = pl4pm.discover_process_tree_inductive(info.standard_lazy)
        pm_net = pm4py.convert_to_petri_net(pm_tree)
        pl_net = pl4pm.convert_to_petri_net(pl_tree)
        pm_bpmn = pm4py.convert_to_bpmn(pm_tree)
        pl_bpmn = pl4pm.convert_to_bpmn(pl_tree)
        pm_dfg = pm4py.discover_dfg(info.pm_df)
        pl_dfg = pl4pm.discover_dfg(info.standard_lazy)

        ocel_source = info.standard_lazy.with_columns(
            [
                pl.col(CASE_ID).alias("order"),
                pl.concat_str([pl.lit("variant::"), pl.col(VARIANT)]).alias("variant_object"),
            ]
        ).collect()
        pl_ocel = pl4pm.convert_log_to_ocel(
            ocel_source,
            object_types=["order", "variant_object"],
            additional_event_attributes=[RESOURCE, VARIANT],
        )
        models.append(
            {
                "pm_tree": pm_tree,
                "pl_tree": pl_tree,
                "pm_net": pm_net,
                "pl_net": pl_net,
                "pm_bpmn": pm_bpmn,
                "pl_bpmn": pl_bpmn,
                "pm_dfg": pm_dfg,
                "pl_dfg": pl_dfg,
                "pl_ocel": pl_ocel,
            }
        )
    return models


@pytest.mark.parametrize("log_index", range(10))
def test_write_xes(tmp_path, synthetic_logs, log_index):
    info = synthetic_logs[log_index]
    pm_path = tmp_path / f"{info.name}_pm.xes"
    pl_df_path = tmp_path / f"{info.name}_pl_df.xes"
    pl_lazy_path = tmp_path / f"{info.name}_pl_lazy.xes"

    pm_result, pm_time = _maybe_timed_pm4py(f"{info.name}:write_xes", "write_xes", info.pm_df, str(pm_path))
    _, pl_df_time = timed_call(pl4pm.write_xes, info.standard_lazy, str(pl_df_path))
    _, pl_lazy_time = timed_call(pl4pm.write_xes, info.standard_lazy, str(pl_lazy_path))

    expected = normalize_table(info.standard_lazy)
    pl_df_norm = normalize_table(pl4pm.read_xes(str(pl_df_path)))
    pl_lazy_norm = normalize_table(pl4pm.read_xes(str(pl_lazy_path)))
    assert pl_df_norm == expected
    assert pl_lazy_norm == expected

    if pm_time is not None:
        pm_norm = normalize_table(pl4pm.read_xes(str(pm_path)))
        if pl_df_norm != pm_norm:
            record_mismatch(f"{info.name}:write_xes", pm_norm, pl_df_norm, pl_lazy_norm)
        assert pl_df_norm == pm_norm

    print_perf(f"{info.name}:write_xes", pm_time, pl_df_time, pl_lazy_time)


@pytest.mark.parametrize("log_index", range(10))
def test_write_csv(tmp_path, synthetic_logs, log_index):
    info = synthetic_logs[log_index]
    pl_df_path = tmp_path / f"{info.name}_pl_df.csv"
    pl_lazy_path = tmp_path / f"{info.name}_pl_lazy.csv"

    _, pl_df_time = timed_call(pl4pm.write_csv, info.standard_lazy, str(pl_df_path))
    _, pl_lazy_time = timed_call(pl4pm.write_csv, info.standard_lazy, str(pl_lazy_path))

    expected = normalize_table(info.standard_lazy)
    pl_df_norm = normalize_table(pl.read_csv(pl_df_path, try_parse_dates=True))
    pl_lazy_norm = normalize_table(pl.read_csv(pl_lazy_path, try_parse_dates=True))
    assert pl_df_norm == expected
    assert pl_lazy_norm == expected

    print_perf(f"{info.name}:write_csv", None, pl_df_time, pl_lazy_time)


@pytest.mark.parametrize("log_index", range(10))
def test_write_pnml(tmp_path, synthetic_logs, write_models, log_index):
    info = synthetic_logs[log_index]
    pm_net, pm_im, pm_fm = write_models[log_index]["pm_net"]
    pl_net, pl_im, pl_fm = write_models[log_index]["pl_net"]
    pm_path = tmp_path / f"{info.name}_pm.pnml"
    pl_path = tmp_path / f"{info.name}_pl.pnml"

    pm_result, pm_time = _maybe_timed_pm4py(
        f"{info.name}:write_pnml", "write_pnml", pm_net, pm_im, pm_fm, str(pm_path)
    )
    _, pl_time = timed_call(pl4pm.write_pnml, pl_net, pl_im, pl_fm, str(pl_path))

    pl_norm = _normalize_petri_shape(pl4pm.read_pnml(str(pl_path)))
    if pm_time is not None:
        pm_norm = _normalize_petri_shape(pl4pm.read_pnml(str(pm_path)))
        if pl_norm != pm_norm:
            record_mismatch(f"{info.name}:write_pnml", pm_norm, pl_norm)
        assert pl_norm == pm_norm

    print_perf(f"{info.name}:write_pnml", pm_time, pl_time, None)


@pytest.mark.parametrize("log_index", range(10))
def test_write_ptml(tmp_path, synthetic_logs, write_models, log_index):
    info = synthetic_logs[log_index]
    pm_tree = write_models[log_index]["pm_tree"]
    pl_tree = write_models[log_index]["pl_tree"]
    pm_path = tmp_path / f"{info.name}_pm.ptml"
    pl_path = tmp_path / f"{info.name}_pl.ptml"

    pm_result, pm_time = _maybe_timed_pm4py(f"{info.name}:write_ptml", "write_ptml", pm_tree, str(pm_path))
    _, pl_time = timed_call(pl4pm.write_ptml, pl_tree, str(pl_path))

    pl_norm = normalize_tree(pl4pm.read_ptml(str(pl_path)))
    assert pl_norm == normalize_tree(pl_tree)

    print_perf(f"{info.name}:write_ptml", pm_time, pl_time, None)


@pytest.mark.parametrize("log_index", range(10))
def test_write_bpmn(tmp_path, synthetic_logs, write_models, log_index):
    info = synthetic_logs[log_index]
    pm_bpmn = write_models[log_index]["pm_bpmn"]
    pl_bpmn = write_models[log_index]["pl_bpmn"]
    pm_path = tmp_path / f"{info.name}_pm.bpmn"
    pl_path = tmp_path / f"{info.name}_pl.bpmn"

    pm_result, pm_time = _maybe_timed_pm4py(f"{info.name}:write_bpmn", "write_bpmn", pm_bpmn, str(pm_path))
    _, pl_time = timed_call(pl4pm.write_bpmn, pl_bpmn, str(pl_path))

    pl_norm = _normalize_bpmn_semantics(pl4pm.read_bpmn(str(pl_path)))
    if pm_time is not None:
        pm_norm = _normalize_bpmn_semantics(pl4pm.read_bpmn(str(pm_path)))
        if pl_norm != pm_norm:
            record_mismatch(f"{info.name}:write_bpmn", pm_norm, pl_norm)
        assert pl_norm == pm_norm

    print_perf(f"{info.name}:write_bpmn", pm_time, pl_time, None)


@pytest.mark.parametrize("log_index", range(10))
def test_write_dfg(tmp_path, synthetic_logs, write_models, log_index):
    info = synthetic_logs[log_index]
    pm_dfg = write_models[log_index]["pm_dfg"]
    pl_dfg = write_models[log_index]["pl_dfg"]
    pm_path = tmp_path / f"{info.name}_pm.dfg"
    pl_path = tmp_path / f"{info.name}_pl.dfg"

    pm_result, pm_time = _maybe_timed_pm4py(
        f"{info.name}:write_dfg", "write_dfg", pm_dfg[0], pm_dfg[1], pm_dfg[2], str(pm_path)
    )
    _, pl_time = timed_call(pl4pm.write_dfg, pl_dfg[0], pl_dfg[1], pl_dfg[2], str(pl_path))

    pl_norm = normalize_dfg(pl4pm.read_dfg(str(pl_path)))
    assert pl_norm == normalize_dfg(pl_dfg)

    print_perf(f"{info.name}:write_dfg", pm_time, pl_time, None)


@pytest.mark.parametrize("log_index", range(5))
@pytest.mark.parametrize(
    "variant,ext,writer,reader",
    [
        ("ocel_json", ".jsonocel", "write_ocel_json", "read_ocel_json"),
        ("ocel_xml", ".xmlocel", "write_ocel_xml", "read_ocel_xml"),
        ("ocel_sqlite", ".sqlite", "write_ocel_sqlite", "read_ocel_sqlite"),
        ("ocel2_json", ".jsonocel", "write_ocel2_json", "read_ocel2_json"),
        ("ocel2_xml", ".xmlocel", "write_ocel2_xml", "read_ocel2_xml"),
        ("ocel2_sqlite", ".sqlite", "write_ocel2_sqlite", "read_ocel2_sqlite"),
    ],
)
def test_write_ocel_variants(tmp_path, synthetic_logs, write_models, log_index, variant, ext, writer, reader):
    info = synthetic_logs[log_index]
    ocel = write_models[log_index]["pl_ocel"]
    pl_path = tmp_path / f"{info.name}_{variant}{ext}"

    _, pl_time = timed_call(getattr(pl4pm, writer), ocel, str(pl_path))
    pl_norm = normalize_ocel(getattr(pl4pm, reader)(str(pl_path)))
    expected = normalize_ocel(ocel)
    assert pl_norm == expected

    print_perf(f"{info.name}:{variant}", None, pl_time, None)


@pytest.mark.parametrize("log_index", range(2))
def test_write_ocel_wrappers(tmp_path, synthetic_logs, write_models, log_index):
    info = synthetic_logs[log_index]
    ocel = write_models[log_index]["pl_ocel"]
    json_path = tmp_path / f"{info.name}_1.json"
    sqlite_path = tmp_path / f"{info.name}_2.sqlite"

    pl4pm.write_ocel(ocel, str(json_path))
    assert json_path.exists()
    
    pl4pm.write_ocel2(ocel, str(sqlite_path))
    assert sqlite_path.exists()
