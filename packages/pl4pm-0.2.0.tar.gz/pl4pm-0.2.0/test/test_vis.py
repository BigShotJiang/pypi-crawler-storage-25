"""Test suite for pl4pm.vis — benchmarking pm4py vs pl4pm."""
from __future__ import annotations

import os
import polars as pl
import pytest

import pm4py
import pl4pm

from _filter_read_support import synthetic_logs, timed_call


@pytest.fixture(scope="session")
def vis_models(synthetic_logs):
    models = []
    for info in synthetic_logs:
        dfg = pl4pm.discover_dfg(info.standard_lazy)
        tree = pl4pm.discover_process_tree_inductive(info.standard_lazy)
        net, im, fm = pl4pm.convert_to_petri_net(tree)
        bpmn = pl4pm.convert_to_bpmn(tree)
        
        models.append({
            "dfg": dfg,
            "tree": tree,
            "net": (net, im, fm),
            "bpmn": bpmn,
        })
    return models


VIS_FUNCS = [
    ("save_vis_dfg", lambda m, path: [m["dfg"][0], m["dfg"][1], m["dfg"][2], path]),
    ("save_vis_petri_net", lambda m, path: [m["net"][0], m["net"][1], m["net"][2], path]),
    ("save_vis_process_tree", lambda m, path: [m["tree"], path]),
    ("save_vis_bpmn", lambda m, path: [m["bpmn"], path]),
]


@pytest.mark.parametrize("log_index", range(3))
@pytest.mark.parametrize("func_name, args_extractor", VIS_FUNCS)
def test_vis_save(tmp_path, synthetic_logs, vis_models, log_index, func_name, args_extractor):
    info = synthetic_logs[log_index]
    m = vis_models[log_index]
    
    pl_func = getattr(pl4pm, func_name)
    pm_func = getattr(pm4py, func_name, None)
    
    pl_path = tmp_path / f"{info.name}_pl.png"
    pm_path = tmp_path / f"{info.name}_pm.png"
    
    pl_args = args_extractor(m, str(pl_path))
    _, pl_time = timed_call(pl_func, *pl_args)
    assert os.path.exists(pl_path)
    
    if pm_func is not None:
        pm_args = args_extractor(m, str(pm_path))
        try:
            _, pm_time = timed_call(pm_func, *pm_args)
            assert os.path.exists(pm_path)
        except Exception as e:
            print(f"pm4py failed on {func_name}: {e}")


DF_VIS_FUNCS = [
    "save_vis_dotted_chart",
    "save_vis_case_duration_graph",
    "save_vis_events_per_time_graph",
]


@pytest.mark.parametrize("log_index", range(3))
@pytest.mark.parametrize("func_name", DF_VIS_FUNCS)
def test_vis_df_save(tmp_path, synthetic_logs, log_index, func_name):
    info = synthetic_logs[log_index]
    
    pl_func = getattr(pl4pm, func_name)
    pm_func = getattr(pm4py, func_name, None)
    
    pl_path = tmp_path / f"{info.name}_pl.png"
    pm_path = tmp_path / f"{info.name}_pm.png"
    
    _, pl_time = timed_call(pl_func, info.standard_lazy, str(pl_path))
    assert os.path.exists(pl_path)
    
    if pm_func is not None:
        try:
            _, pm_time = timed_call(pm_func, info.pm_df, str(pm_path))
            assert os.path.exists(pm_path)
        except Exception as e:
            print(f"pm4py failed on {func_name}: {e}")
