# pl4pm

`pl4pm` is a Python process mining library built around Polars.

## Install

```bash
pip install .
```

For editable development:

```bash
pip install -e .
```

Optional visualization and graph extras:

```bash
pip install ".[viz,nx]"
```

## Quick start

```python
import pl4pm

log = pl4pm.read_csv(
    "event_log.csv",
    case_id_col="case:concept:name",
    activity_col="concept:name",
    timestamp_col="time:timestamp",
)

dfg = pl4pm.discover_dfg(log)
pl4pm.save_vis_dfg(*dfg, "dfg.png")
```
