"""Correlation Miner over Polars, aligned with pm4py semantics."""

from __future__ import annotations

from collections import Counter
from typing import Dict, Iterable, Tuple

import numpy as np
import polars as pl
from scipy.optimize import linprog

try:
    from cvxopt import matrix as cvx_matrix
    from cvxopt import glpk as cvx_glpk

    _HAS_CVXOPT = True
except Exception:  # noqa: BLE001
    cvx_matrix = None
    cvx_glpk = None
    _HAS_CVXOPT = False

from pl4pm.constants import ACTIVITY_KEY, TIMESTAMP_KEY


def _to_seconds_expr(timestamp_key: str, time_unit: str) -> pl.Expr:
    if time_unit == "ns":
        return (pl.col(timestamp_key).dt.epoch("ns") / 1_000_000_000.0).alias("_ts_seconds")
    return (pl.col(timestamp_key).dt.epoch("us") / 1_000_000.0).alias("_ts_seconds")


def _prepare_events(
    df: pl.LazyFrame,
    activity_key: str,
    timestamp_key: str,
) -> tuple[pl.DataFrame, str, str]:
    source = df if isinstance(df, pl.LazyFrame) else df.lazy()
    schema = source.collect_schema()
    timestamp_dtype = schema[timestamp_key]
    time_unit = "us"
    if isinstance(timestamp_dtype, pl.Datetime):
        time_unit = timestamp_dtype.time_unit
    prepared = (
        source
        .select([activity_key, timestamp_key])
        .with_row_index("_event_index")
        .with_columns(
            [
                pl.col(activity_key).cast(pl.Utf8),
                _to_seconds_expr(timestamp_key, time_unit),
            ]
        )
        .sort(["_ts_seconds", "_event_index"])
        .collect()
    )
    if prepared.is_empty():
        return prepared, "", ""

    original = (
        source
        .select(pl.col(activity_key).cast(pl.Utf8).alias(activity_key))
        .collect()
    )
    first_activity = original.get_column(activity_key)[0]
    last_activity = original.get_column(activity_key)[-1]
    return prepared, first_activity, last_activity


def _activity_times(
    events: pl.DataFrame,
    activity_key: str,
) -> tuple[list[str], dict[str, np.ndarray], dict[str, int]]:
    grouped = (
        events
        .group_by(activity_key)
        .agg(pl.col("_ts_seconds").sort().alias("_times"))
        .sort(activity_key)
    )
    activities = grouped.get_column(activity_key).to_list()
    times = {
        row[activity_key]: np.asarray(row["_times"], dtype=np.float64)
        for row in grouped.to_dicts()
    }
    counter = {act: len(times[act]) for act in activities}
    return activities, times, counter


def _precede_succeed_matrix(
    activities: list[str],
    times_by_activity: dict[str, np.ndarray],
) -> np.ndarray:
    n = len(activities)
    ret = np.zeros((n, n), dtype=np.float64)
    for i, act_i in enumerate(activities):
        ai = times_by_activity[act_i]
        len_ai = len(ai)
        if len_ai == 0:
            continue
        for j, act_j in enumerate(activities):
            if i == j:
                continue
            aj = times_by_activity[act_j]
            len_aj = len(aj)
            if len_aj == 0:
                continue
            z = 0
            count = 0
            for a_end in ai:
                while z < len_aj and a_end >= aj[z]:
                    z += 1
                count += len_aj - z
            ret[i, j] = count / float(len_ai * len_aj)
    return ret


def _fifo_pairs(ai: np.ndarray, aj: np.ndarray) -> list[tuple[float, float]]:
    pairs: list[tuple[float, float]] = []
    k = 0
    z = 0
    len_ai = len(ai)
    len_aj = len(aj)
    while k < len_ai:
        while z < len_aj:
            if ai[k] < aj[z]:
                pairs.append((ai[k], aj[z]))
                z += 1
                break
            z += 1
        k += 1
    return pairs


def _rlifo_pairs(ai: np.ndarray, aj: np.ndarray) -> list[tuple[float, float]]:
    pairs: list[tuple[float, float]] = []
    k = len(ai) - 1
    z = len(aj) - 1
    while z >= 0:
        while k >= 0:
            if ai[k] < aj[z]:
                pairs.append((ai[k], aj[z]))
                k -= 1
                break
            k -= 1
        z -= 1
    return pairs


def _match_return_avg_time(ai: np.ndarray, aj: np.ndarray) -> float:
    fifo = _fifo_pairs(ai, aj)
    fifo_avg = float(np.mean([end - start for start, end in fifo])) if fifo else 0.0
    rlifo = _rlifo_pairs(ai, aj)
    rlifo_avg = float(np.mean([end - start for start, end in rlifo])) if rlifo else 0.0
    return min(fifo_avg, rlifo_avg)


def _duration_matrix(
    activities: list[str],
    times_by_activity: dict[str, np.ndarray],
) -> np.ndarray:
    n = len(activities)
    ret = np.zeros((n, n), dtype=np.float64)
    for i, act_i in enumerate(activities):
        ai = times_by_activity[act_i]
        if len(ai) == 0:
            continue
        for j, act_j in enumerate(activities):
            if i == j:
                continue
            aj = times_by_activity[act_j]
            if len(aj) == 0:
                continue
            ret[i, j] = _match_return_avg_time(ai, aj)
    return ret


def _c_matrix(
    ps_matrix: np.ndarray,
    duration_matrix: np.ndarray,
    activities: list[str],
    activities_counter: dict[str, int],
) -> np.ndarray:
    n = len(activities)
    ret = np.zeros((n, n), dtype=np.float64)
    for i, act_i in enumerate(activities):
        for j, act_j in enumerate(activities):
            ps = ps_matrix[i, j]
            if ps > 0:
                ret[i, j] = duration_matrix[i, j] / ps / min(
                    activities_counter[act_i], activities_counter[act_j]
                )
            else:
                ret[i, j] = 100_000_000_000.0
    return ret


def _solve_lp(
    c_matrix: np.ndarray,
    duration_matrix: np.ndarray,
    activities: list[str],
    activities_counter: dict[str, int],
) -> tuple[dict[tuple[str, str], int], dict[tuple[str, str], float]]:
    n = len(activities)
    num_edges = n * n
    costs = c_matrix.reshape(num_edges)

    a_eq = np.zeros((2 * n, num_edges), dtype=np.float64)
    b_eq = np.zeros(2 * n, dtype=np.float64)
    a_ub_rows: list[list[float]] = []
    b_ub_vals: list[float] = []

    for i, act_i in enumerate(activities):
        row = i
        start = i * n
        a_eq[row, start:start + n] = 1.0
        b_eq[row] = activities_counter[act_i]
        for edge_idx in range(start, start + n):
            rec = [0.0] * num_edges
            rec[edge_idx] = 1.0
            a_ub_rows.append(rec)
            b_ub_vals.append(float(activities_counter[act_i]))
            rec = [0.0] * num_edges
            rec[edge_idx] = -1.0
            a_ub_rows.append(rec)
            b_ub_vals.append(0.0)

    for j, act_j in enumerate(activities):
        row = n + j
        a_eq[row, j::n] = 1.0
        b_eq[row] = activities_counter[act_j]
        for edge_idx in range(j, num_edges, n):
            rec = [0.0] * num_edges
            rec[edge_idx] = 1.0
            a_ub_rows.append(rec)
            b_ub_vals.append(float(activities_counter[act_j]))
            rec = [0.0] * num_edges
            rec[edge_idx] = -1.0
            a_ub_rows.append(rec)
            b_ub_vals.append(0.0)

    a_ub = np.asarray(a_ub_rows, dtype=np.float64)
    b_ub = np.asarray(b_ub_vals, dtype=np.float64)

    if _HAS_CVXOPT:
        options = {
            "LPX_K_MSGLEV": 0,
            "msg_lev": "GLP_MSG_OFF",
            "show_progress": False,
            "presolve": "GLP_ON",
            "tol_bnd": 1e-5,
            "tol_piv": 1e-5,
            "obj_ll": 1e-5,
            "obj_ul": 1e-5,
        }
        status, x, _, _ = cvx_glpk.lp(
            cvx_matrix(costs, tc="d"),
            cvx_matrix(a_ub, tc="d"),
            cvx_matrix(b_ub, tc="d"),
            cvx_matrix(a_eq, tc="d"),
            cvx_matrix(b_eq, tc="d"),
            options=options,
        )
        if status != "optimal" or x is None:
            raise RuntimeError(f"Correlation miner LP failed: {status}")
        points = np.rint(np.asarray(x, dtype=np.float64).reshape(-1)).astype(int).reshape((n, n))
    else:
        bounds = [(0.0, None)] * num_edges
        result = linprog(costs, A_ub=a_ub, b_ub=b_ub, A_eq=a_eq, b_eq=b_eq, bounds=bounds, method="highs")
        if not result.success or result.x is None:
            raise RuntimeError(f"Correlation miner LP failed: {result.message}")
        points = np.rint(result.x).astype(int).reshape((n, n))

    dfg: dict[tuple[str, str], int] = {}
    perf_dfg: dict[tuple[str, str], float] = {}
    for i, src in enumerate(activities):
        for j, tgt in enumerate(activities):
            value = int(points[i, j])
            if value > 0:
                edge = (src, tgt)
                dfg[edge] = value
                perf_dfg[edge] = float(duration_matrix[i, j])
    return dfg, perf_dfg


def _boundary_activities(
    dfg: dict[tuple[str, str], int],
    first_activity: str,
    last_activity: str,
) -> tuple[dict[str, int], dict[str, int]]:
    entering = Counter()
    exiting = Counter()
    for (src, tgt), freq in dfg.items():
        exiting[src] += int(freq)
        entering[tgt] += int(freq)
    return {first_activity: int(exiting[first_activity])}, {last_activity: int(entering[last_activity])}


def correlation_miner(
    df: pl.LazyFrame,
    annotation: str = "frequency",
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
) -> Tuple[Dict[Tuple[str, str], float], Dict[str, int], Dict[str, int]]:
    """Discover a case-less DFG using the Correlation Miner semantics of pm4py."""

    events, first_activity, last_activity = _prepare_events(df, activity_key, timestamp_key)
    if events.is_empty():
        return {}, {}, {}

    activities, times_by_activity, activities_counter = _activity_times(events, activity_key)
    ps_matrix = _precede_succeed_matrix(activities, times_by_activity)
    duration_matrix = _duration_matrix(activities, times_by_activity)
    c_matrix = _c_matrix(ps_matrix, duration_matrix, activities, activities_counter)
    dfg, perf_dfg = _solve_lp(c_matrix, duration_matrix, activities, activities_counter)
    start_activities, end_activities = _boundary_activities(dfg, first_activity, last_activity)

    if annotation == "performance":
        return perf_dfg, start_activities, end_activities
    return dfg, start_activities, end_activities
