"""Temporal profile discovery."""

from __future__ import annotations

from typing import Dict, Tuple

import polars as pl

from pl4pm.constants import ACTIVITY_KEY, CASE_ID_KEY, TIMESTAMP_KEY


def discover_temporal_profile(
    log: pl.LazyFrame,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
) -> Dict[Tuple[str, str], Tuple[float, float]]:
    """Discover a temporal profile matching pm4py's dataframe semantics.

    The implementation keeps the expensive trace grouping inside Polars and then
    performs lightweight Python updates over compact activity/timestamp lists.
    The returned standard deviation matches pandas' sample std (`ddof=1`), with
    single observations mapped to ``0.0`` like pm4py does after ``fillna(0)``.
    """

    source = log if isinstance(log, pl.LazyFrame) else log.lazy()
    traces = (
        source
        .sort([case_id_key, timestamp_key])
        .group_by(case_id_key, maintain_order=True)
        .agg(
            [
                pl.col(activity_key).alias("_acts"),
                pl.col(timestamp_key).dt.epoch("us").alias("_ts_us"),
            ]
        )
        .select(["_acts", "_ts_us"])
        .collect()
    )

    # pair -> [count, mean, m2]
    stats: dict[tuple[str, str], list[float]] = {}
    for acts, ts_us in traces.iter_rows():
        n = len(acts)
        for i in range(n - 1):
            src = acts[i]
            start_ts = ts_us[i]
            for j in range(i + 1, n):
                pair = (src, acts[j])
                value = (ts_us[j] - start_ts) / 1_000_000.0
                current = stats.get(pair)
                if current is None:
                    stats[pair] = [1.0, value, 0.0]
                    continue
                count, mean, m2 = current
                count += 1.0
                delta = value - mean
                mean += delta / count
                delta2 = value - mean
                m2 += delta * delta2
                current[0] = count
                current[1] = mean
                current[2] = m2

    result: Dict[Tuple[str, str], Tuple[float, float]] = {}
    for pair, (count, mean, m2) in stats.items():
        std = 0.0 if count <= 1.0 else (m2 / (count - 1.0)) ** 0.5
        result[pair] = (float(mean), float(std))

    return result
