"""DECLARE model discovery aligned with pm4py, implemented over Polars variants."""

from __future__ import annotations

from collections import Counter
from typing import Any

import polars as pl

from pl4pm.constants import ACTIVITY_KEY, CASE_ID_KEY, TIMESTAMP_KEY


EXISTENCE = "existence"
EXACTLY_ONE = "exactly_one"
INIT = "init"
RESPONDED_EXISTENCE = "responded_existence"
RESPONSE = "response"
PRECEDENCE = "precedence"
SUCCESSION = "succession"
ALTRESPONSE = "altresponse"
ALTPRECEDENCE = "altprecedence"
ALTSUCCESSION = "altsuccession"
CHAINRESPONSE = "chainresponse"
CHAINPRECEDENCE = "chainprecedence"
CHAINSUCCESSION = "chainsuccession"
ABSENCE = "absence"
COEXISTENCE = "coexistence"
NONCOEXISTENCE = "noncoexistence"
NONSUCCESSION = "nonsuccession"
NONCHAINSUCCESSION = "nonchainsuccession"

ALL_TEMPLATES = {
    EXISTENCE,
    EXACTLY_ONE,
    INIT,
    RESPONDED_EXISTENCE,
    RESPONSE,
    PRECEDENCE,
    SUCCESSION,
    ALTRESPONSE,
    ALTPRECEDENCE,
    ALTSUCCESSION,
    CHAINRESPONSE,
    CHAINPRECEDENCE,
    CHAINSUCCESSION,
    ABSENCE,
    COEXISTENCE,
    NONCOEXISTENCE,
    NONSUCCESSION,
    NONCHAINSUCCESSION,
}


def _extract_variants(
    log: pl.LazyFrame,
    activity_key: str,
    timestamp_key: str,
    case_id_key: str,
) -> tuple[Counter[tuple[str, ...]], set[str], int]:
    source = log if isinstance(log, pl.LazyFrame) else log.lazy()
    traces = (
        source
        .sort([case_id_key, timestamp_key])
        .group_by(case_id_key, maintain_order=True)
        .agg(pl.col(activity_key).alias("_trace"))
        .select("_trace")
        .collect()
        .get_column("_trace")
        .to_list()
    )
    variants = Counter(tuple(trace) for trace in traces)
    activities = {act for trace in variants for act in trace}
    n_cases = int(sum(variants.values()))
    return variants, activities, n_cases


def _alt_response(trace_len: int, act_idxs: dict[str, list[int]], a: str, b: str) -> bool:
    a_idxs = act_idxs.get(a, [])
    if not a_idxs:
        return True
    b_idxs = act_idxs.get(b, [])
    if not b_idxs:
        return False
    b_ptr = 0
    for i, a_idx in enumerate(a_idxs):
        next_a = a_idxs[i + 1] if i + 1 < len(a_idxs) else trace_len
        while b_ptr < len(b_idxs) and b_idxs[b_ptr] <= a_idx:
            b_ptr += 1
        if b_ptr >= len(b_idxs) or b_idxs[b_ptr] >= next_a:
            return False
    return True


def _chain_response(trace: tuple[str, ...], act_idxs: dict[str, list[int]], a: str, b: str) -> bool:
    a_idxs = act_idxs.get(a, [])
    if not a_idxs:
        return True
    for idx in a_idxs:
        if idx + 1 >= len(trace) or trace[idx + 1] != b:
            return False
    return True


def _alt_precedence(act_idxs: dict[str, list[int]], a: str, b: str) -> bool:
    b_idxs = act_idxs.get(b, [])
    if not b_idxs:
        return True
    a_idxs = act_idxs.get(a, [])
    if not a_idxs:
        return False
    a_ptr = 0
    prev_b = -1
    for b_idx in b_idxs:
        while a_ptr < len(a_idxs) and a_idxs[a_ptr] <= prev_b:
            a_ptr += 1
        if a_ptr >= len(a_idxs) or a_idxs[a_ptr] >= b_idx:
            return False
        prev_b = b_idx
    return True


def _chain_precedence(trace: tuple[str, ...], act_idxs: dict[str, list[int]], a: str, b: str) -> bool:
    b_idxs = act_idxs.get(b, [])
    if not b_idxs:
        return True
    for idx in b_idxs:
        if idx == 0 or trace[idx - 1] != a:
            return False
    return True


def _rule_key(rule: str, a: str, b: str | None = None) -> tuple[str, Any]:
    return (rule, a) if b is None else (rule, (a, b))


def _trace_rule_values(
    trace: tuple[str, ...],
    activities: list[str],
    allowed_templates: set[str],
) -> dict[tuple[str, Any], int]:
    act_counter = Counter(trace)
    act_idxs: dict[str, list[int]] = {}
    for idx, act in enumerate(trace):
        act_idxs.setdefault(act, []).append(idx)

    rules: dict[tuple[str, Any], int] = {}
    trace_len = len(trace)
    first = trace[0] if trace else None

    for act in activities:
        count = act_counter.get(act, 0)
        if EXISTENCE in allowed_templates:
            rules[_rule_key(EXISTENCE, act)] = 1 if count > 0 else -1
        if EXACTLY_ONE in allowed_templates:
            rules[_rule_key(EXACTLY_ONE, act)] = 1 if count == 1 else -1
        if INIT in allowed_templates:
            rules[_rule_key(INIT, act)] = 1 if first == act else -1

    for a in activities:
        a_present = a in act_counter
        for b in activities:
            if a == b:
                continue
            b_present = b in act_counter

            if RESPONDED_EXISTENCE in allowed_templates and a_present:
                rules[_rule_key(RESPONDED_EXISTENCE, a, b)] = 1 if b_present else -1

            if RESPONSE in allowed_templates and a_present:
                rules[_rule_key(RESPONSE, a, b)] = 1 if (b_present and act_idxs[a][-1] < act_idxs[b][-1]) else -1

            if PRECEDENCE in allowed_templates and b_present:
                rules[_rule_key(PRECEDENCE, a, b)] = 1 if (a_present and act_idxs[a][0] < act_idxs[b][0]) else -1

            if ALTRESPONSE in allowed_templates and a_present:
                rules[_rule_key(ALTRESPONSE, a, b)] = 1 if _alt_response(trace_len, act_idxs, a, b) else -1

            if CHAINRESPONSE in allowed_templates and a_present:
                rules[_rule_key(CHAINRESPONSE, a, b)] = 1 if _chain_response(trace, act_idxs, a, b) else -1

            if ALTPRECEDENCE in allowed_templates and b_present:
                rules[_rule_key(ALTPRECEDENCE, a, b)] = 1 if _alt_precedence(act_idxs, a, b) else -1

            if CHAINPRECEDENCE in allowed_templates and b_present:
                rules[_rule_key(CHAINPRECEDENCE, a, b)] = 1 if _chain_precedence(trace, act_idxs, a, b) else -1

    for a in activities:
        if ABSENCE in allowed_templates and EXISTENCE in allowed_templates:
            rules[_rule_key(ABSENCE, a)] = -rules[_rule_key(EXISTENCE, a)]
        for b in activities:
            if a == b:
                continue
            if SUCCESSION in allowed_templates and RESPONSE in allowed_templates and PRECEDENCE in allowed_templates:
                rules[_rule_key(SUCCESSION, a, b)] = min(
                    rules.get(_rule_key(RESPONSE, a, b), 0),
                    rules.get(_rule_key(PRECEDENCE, a, b), 0),
                )
            if ALTSUCCESSION in allowed_templates and ALTRESPONSE in allowed_templates and ALTPRECEDENCE in allowed_templates:
                rules[_rule_key(ALTSUCCESSION, a, b)] = min(
                    rules.get(_rule_key(ALTRESPONSE, a, b), 0),
                    rules.get(_rule_key(ALTPRECEDENCE, a, b), 0),
                )
            if CHAINSUCCESSION in allowed_templates and CHAINRESPONSE in allowed_templates and CHAINPRECEDENCE in allowed_templates:
                rules[_rule_key(CHAINSUCCESSION, a, b)] = min(
                    rules.get(_rule_key(CHAINRESPONSE, a, b), 0),
                    rules.get(_rule_key(CHAINPRECEDENCE, a, b), 0),
                )
            if COEXISTENCE in allowed_templates and RESPONDED_EXISTENCE in allowed_templates:
                rules[_rule_key(COEXISTENCE, a, b)] = min(
                    rules.get(_rule_key(RESPONDED_EXISTENCE, a, b), 0),
                    rules.get(_rule_key(RESPONDED_EXISTENCE, b, a), 0),
                )
            if NONCOEXISTENCE in allowed_templates and COEXISTENCE in allowed_templates:
                rules[_rule_key(NONCOEXISTENCE, a, b)] = -rules.get(_rule_key(COEXISTENCE, a, b), 0)
            if NONSUCCESSION in allowed_templates and SUCCESSION in allowed_templates:
                rules[_rule_key(NONSUCCESSION, a, b)] = -rules.get(_rule_key(SUCCESSION, a, b), 0)
            if NONCHAINSUCCESSION in allowed_templates and CHAINSUCCESSION in allowed_templates:
                rules[_rule_key(NONCHAINSUCCESSION, a, b)] = -rules.get(_rule_key(CHAINSUCCESSION, a, b), 0)

    return rules


def _auto_thresholds(stats: dict[tuple[str, Any], list[int]], n_cases: int, multiplier: float) -> tuple[float, float]:
    best_key = None
    best_prod = -1.0
    for key, (support, confidence) in stats.items():
        if support <= 0:
            continue
        supp_ratio = support / n_cases
        conf_ratio = confidence / support
        prod = supp_ratio * conf_ratio
        if prod > best_prod or (prod == best_prod and (best_key is None or repr(key) > repr(best_key))):
            best_prod = prod
            best_key = key
    if best_key is None:
        return 0.0, 0.0
    support, confidence = stats[best_key]
    return (support / n_cases) * multiplier, (confidence / support) * multiplier if support > 0 else 1.0


def discover_declare(
    log: pl.LazyFrame,
    allowed_templates: set[str] | None = None,
    considered_activities: set[str] | None = None,
    min_support_ratio: float | None = None,
    min_confidence_ratio: float | None = None,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
) -> dict[str, dict[Any, dict[str, int]]]:
    """Discover a DECLARE model matching pm4py's classic semantics."""

    templates = set(allowed_templates) if allowed_templates is not None else set(ALL_TEMPLATES)
    variants, activities, n_cases = _extract_variants(log, activity_key, timestamp_key, case_id_key)
    if considered_activities is not None:
        activities &= set(considered_activities)
    if not activities or n_cases == 0:
        return {}

    sorted_acts = sorted(activities)
    stats: dict[tuple[str, Any], list[int]] = {}

    for trace, occs in variants.items():
        filtered_trace = tuple(act for act in trace if act in activities)
        rule_values = _trace_rule_values(filtered_trace, sorted_acts, templates)
        for key, value in rule_values.items():
            support, confidence = stats.setdefault(key, [0, 0])
            if value != 0:
                support += occs
            if value == 1:
                confidence += occs
            stats[key][0] = support
            stats[key][1] = confidence

    if min_support_ratio is None and min_confidence_ratio is None:
        min_support_ratio, min_confidence_ratio = _auto_thresholds(stats, n_cases, 0.8)
    elif min_support_ratio is None:
        min_support_ratio = 0.0
    elif min_confidence_ratio is None:
        min_confidence_ratio = 0.0

    result: dict[str, dict[Any, dict[str, int]]] = {}
    for (rule, key), (support, confidence) in stats.items():
        if support < n_cases * float(min_support_ratio):
            continue
        if support == 0 or confidence < support * float(min_confidence_ratio):
            continue
        result.setdefault(rule, {})[key] = {"support": support, "confidence": confidence}

    return result
