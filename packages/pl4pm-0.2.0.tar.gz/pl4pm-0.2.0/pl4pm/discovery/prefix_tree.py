"""Prefix tree (trie) discovery aligned with pm4py."""

from __future__ import annotations

from typing import Optional

import polars as pl

from pl4pm.constants import ACTIVITY_KEY, CASE_ID_KEY, TIMESTAMP_KEY
from pl4pm.objects.trie import Trie, TrieNode


def discover_prefix_tree(
    log: pl.LazyFrame,
    max_path_length: Optional[int] = None,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
) -> Trie:
    """Discover a prefix tree with pm4py-compatible structure.

    The trie is built on unique variants only, mirroring pm4py's transformation
    logic while keeping the expensive grouping in Polars.
    """

    source = log if isinstance(log, pl.LazyFrame) else log.lazy()
    traces = (
        source
        .sort([case_id_key, timestamp_key])
        .group_by(case_id_key, maintain_order=True)
        .agg(pl.col(activity_key).alias("_trace"))
        .select("_trace")
        .collect()
        .get_column("_trace")
        .to_list()
    )

    variants = {tuple(trace[:max_path_length] if max_path_length is not None else trace) for trace in traces}
    trie = Trie()
    trie.root.label = None
    trie.root.count = None

    for variant in variants:
        node = trie.root
        for index, activity in enumerate(variant):
            child = node.children.get(activity)
            if child is None:
                child = TrieNode(label=activity, depth=node.depth + 1, parent=node)
                child.count = None
                node.children[activity] = child
            node = child
            if index == len(variant) - 1:
                node.is_end = True

    return trie
