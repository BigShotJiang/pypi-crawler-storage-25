"""pl4pm.discovery.powl_discovery — POWL model discovery.

Discovers a Partially Ordered Workflow Language (POWL) model from an event log,
following the algorithm described in:

    Kourani, H., & van Zelst, S. J. (2023). POWL: partially ordered workflow
    language. International Conference on Business Process Management.
    Springer Nature Switzerland.

Algorithm (recursive, inductive-style)
---------------------------------------
1. Build a directed DFG from the log (Polars — fast).
2. Apply cuts in priority order on the set of activities:
   a. **Base case**  — one activity → Transition node.
   b. **XOR cut**    — disconnected components in the co-occurrence graph
                       → OperatorPOWL(XOR, [discover(Ci) for Ci]).
   c. **Sequence cut** — topological ordering without back-edges
                         → StrictPartialOrder with sequence edges.
   d. **Parallel cut** — all activity pairs bidirectionally reachable
                         → StrictPartialOrder with no ordering edges.
   e. **Loop cut**   — ∃ back-edges in DFG → OperatorPOWL(LOOP, [body, redo]).
   f. **Fallback**   — all activities as concurrent nodes in a StrictPartialOrder.

All log operations use Polars; no pandas or pm4py dependency.
"""

from __future__ import annotations

from collections import defaultdict, deque
from typing import Dict, FrozenSet, List, Optional, Set, Tuple

import polars as pl

from pl4pm.constants import ACTIVITY_KEY, CASE_ID_KEY, TIMESTAMP_KEY
from pl4pm.objects.powl import (
    POWL, OperatorPOWL, POWLOperator,
    StrictPartialOrder, Transition, SilentTransition,
)


# ---------------------------------------------------------------------------
# Polars preprocessing helpers
# ---------------------------------------------------------------------------

def _build_dfg_and_relations(
    log: pl.LazyFrame,
    activity_key: str,
    timestamp_key: str,
    case_id_key: str,
) -> tuple[
    set[str],                        # all activities
    set[tuple[str, str]],            # directly-follows set
    dict[str, int],                  # start activity counts
    dict[str, int],                  # end activity counts
]:
    source = log if isinstance(log, pl.LazyFrame) else log.lazy()
    base = source.sort([case_id_key, timestamp_key])

    activities_list: list[str] = (
        base.select(pl.col(activity_key).unique()).collect().to_series().to_list()
    )
    all_acts: set[str] = set(activities_list)

    # DF pairs
    df_frame = (
        base
        .with_columns(
            pl.col(activity_key).shift(-1).over(case_id_key).alias("_next")
        )
        .filter(pl.col("_next").is_not_null())
        .group_by([activity_key, "_next"])
        .agg(pl.len().alias("_cnt"))
        .collect()
    )
    df_set: set[tuple[str, str]] = set(df_frame.select([activity_key, "_next"]).rows())

    start_counts: dict[str, int] = dict(
        base
        .group_by(case_id_key)
        .agg(pl.col(activity_key).first().alias("_f"))
        .select("_f")
        .collect()
        .to_series()
        .value_counts()
        .rows()
    )
    end_counts: dict[str, int] = dict(
        base
        .group_by(case_id_key)
        .agg(pl.col(activity_key).last().alias("_l"))
        .select("_l")
        .collect()
        .to_series()
        .value_counts()
        .rows()
    )

    return all_acts, df_set, start_counts, end_counts


# ---------------------------------------------------------------------------
# Graph utilities
# ---------------------------------------------------------------------------

def _connected_components(
    activities: set[str],
    df_set: set[tuple[str, str]],
) -> list[set[str]]:
    """Undirected connected components of the DFG restricted to *activities*."""
    adj: dict[str, set[str]] = defaultdict(set)
    for (a, b) in df_set:
        if a in activities and b in activities:
            adj[a].add(b)
            adj[b].add(a)

    visited: set[str] = set()
    components: list[set[str]] = []
    for start in activities:
        if start in visited:
            continue
        cc: set[str] = set()
        queue = deque([start])
        while queue:
            node = queue.popleft()
            if node in visited:
                continue
            visited.add(node)
            cc.add(node)
            for nb in adj[node]:
                if nb not in visited:
                    queue.append(nb)
        components.append(cc)
    return components


def _has_cycle(
    activities: set[str],
    df_set: set[tuple[str, str]],
) -> bool:
    """True iff the DFG restricted to *activities* has a directed cycle."""
    # Kahn's algorithm
    in_degree: dict[str, int] = {a: 0 for a in activities}
    for (a, b) in df_set:
        if a in activities and b in activities:
            in_degree[b] += 1

    queue = deque(a for a in activities if in_degree[a] == 0)
    processed = 0
    while queue:
        node = queue.popleft()
        processed += 1
        for (a, b) in df_set:
            if a == node and b in activities:
                in_degree[b] -= 1
                if in_degree[b] == 0:
                    queue.append(b)
    return processed < len(activities)


def _topological_order(
    activities: set[str],
    df_set: set[tuple[str, str]],
) -> list[str]:
    """Kahn topological sort.  Raises ValueError if cycle detected."""
    in_degree: dict[str, int] = {a: 0 for a in activities}
    adj: dict[str, list[str]] = defaultdict(list)
    for (a, b) in df_set:
        if a in activities and b in activities and a != b:
            adj[a].append(b)
            in_degree[b] += 1

    queue = deque(sorted(a for a in activities if in_degree[a] == 0))
    order: list[str] = []
    while queue:
        node = queue.popleft()
        order.append(node)
        for nb in sorted(adj[node]):
            in_degree[nb] -= 1
            if in_degree[nb] == 0:
                queue.append(nb)
    if len(order) != len(activities):
        raise ValueError("Cycle detected")
    return order


# ---------------------------------------------------------------------------
# Cut detection
# ---------------------------------------------------------------------------

def _try_xor_cut(
    activities: set[str],
    df_set: set[tuple[str, str]],
    start_counts: dict[str, int],
    end_counts: dict[str, int],
) -> Optional[list[set[str]]]:
    """XOR cut: split into connected components of the *undirected* DFG.

    Valid only if components have no DF edges crossing between them AND
    every component has at least one start and one end activity.
    """
    comps = _connected_components(activities, df_set)
    if len(comps) < 2:
        return None

    # Verify no cross-component DF edges (would invalidate XOR)
    comp_of: dict[str, int] = {}
    for i, comp in enumerate(comps):
        for a in comp:
            comp_of[a] = i

    for (a, b) in df_set:
        if a in activities and b in activities and comp_of.get(a) != comp_of.get(b):
            return None  # cross-edge → not a clean XOR

    return comps


def _try_sequence_cut(
    activities: set[str],
    df_set: set[tuple[str, str]],
) -> Optional[list[set[str]]]:
    """Sequence cut: partition activities into a topological sequence of groups."""
    if _has_cycle(activities, df_set):
        return None

    try:
        order = _topological_order(activities, df_set)
    except ValueError:
        return None

    if len(order) < 2:
        return None

    # Group into blocks: each activity is its own block
    return [{a} for a in order]


def _try_parallel_cut(
    activities: set[str],
    df_set: set[tuple[str, str]],
    start_counts: dict[str, int],
    end_counts: dict[str, int],
) -> Optional[list[set[str]]]:
    """Parallel cut: all activities can interleave (bidirectional DF between every pair)."""
    acts = list(activities)
    if len(acts) < 2:
        return None

    for i in range(len(acts)):
        for j in range(i + 1, len(acts)):
            a, b = acts[i], acts[j]
            if (a, b) not in df_set or (b, a) not in df_set:
                return None

    # All activities are parallel → each is its own component
    return [{a} for a in acts]


def _try_loop_cut(
    activities: set[str],
    df_set: set[tuple[str, str]],
    start_counts: dict[str, int],
    end_counts: dict[str, int],
) -> Optional[tuple[set[str], set[str]]]:
    """Loop cut: identify body and redo sets.

    Heuristic: activities that are start or end of the sub-log belong to the
    body; activities that appear between repetitions of the body belong to
    the redo part.
    """
    if not _has_cycle(activities, df_set):
        return None

    # Body: activities that are start/end of the entire fragment
    body: set[str] = set()
    redo: set[str] = set()

    for a in activities:
        is_start = a in start_counts
        is_end = a in end_counts
        # Any activity that directly follows an end OR is directly followed by a
        # start (in the fragment) is part of the redo set
        goes_to_start = any((a, s) in df_set for s in start_counts if s in activities)
        comes_from_end = any((e, a) in df_set for e in end_counts if e in activities)

        if is_start or is_end:
            body.add(a)
        elif goes_to_start and comes_from_end:
            redo.add(a)
        else:
            body.add(a)

    if not redo:
        return None

    return body, redo


# ---------------------------------------------------------------------------
# Recursive discovery
# ---------------------------------------------------------------------------

def _discover_recursive(
    activities: set[str],
    df_set: set[tuple[str, str]],
    start_counts: dict[str, int],
    end_counts: dict[str, int],
    depth: int = 0,
) -> POWL:
    """Recursively build the POWL model for a subset of activities."""

    # Base case: single activity
    if len(activities) == 1:
        act = next(iter(activities))
        return Transition(act)

    # Base case: empty
    if not activities:
        return SilentTransition()

    # ------------------------------------------------------------------
    # 1. XOR cut
    # ------------------------------------------------------------------
    xor_comps = _try_xor_cut(activities, df_set, start_counts, end_counts)
    if xor_comps and len(xor_comps) >= 2:
        children = [
            _discover_recursive(comp, df_set, start_counts, end_counts, depth + 1)
            for comp in xor_comps
        ]
        return OperatorPOWL(POWLOperator.XOR, children)

    # ------------------------------------------------------------------
    # 2. Sequence cut (only when no cycle)
    # ------------------------------------------------------------------
    seq_comps = _try_sequence_cut(activities, df_set)
    if seq_comps and len(seq_comps) >= 2:
        # Each component is a singleton — build into child nodes
        nodes: list[POWL] = [
            _discover_recursive(comp, df_set, start_counts, end_counts, depth + 1)
            for comp in seq_comps
        ]
        spo = StrictPartialOrder(nodes=nodes)
        # Add sequence edges following topological order
        for i in range(len(nodes) - 1):
            spo.add_edge(nodes[i], nodes[i + 1])
        return spo

    # ------------------------------------------------------------------
    # 3. Parallel cut
    # ------------------------------------------------------------------
    par_comps = _try_parallel_cut(activities, df_set, start_counts, end_counts)
    if par_comps and len(par_comps) >= 2:
        nodes = [
            _discover_recursive(comp, df_set, start_counts, end_counts, depth + 1)
            for comp in par_comps
        ]
        # No order edges — StrictPartialOrder with empty order
        return StrictPartialOrder(nodes=nodes)

    # ------------------------------------------------------------------
    # 4. Loop cut
    # ------------------------------------------------------------------
    loop_parts = _try_loop_cut(activities, df_set, start_counts, end_counts)
    if loop_parts:
        body_acts, redo_acts = loop_parts
        body_node = _discover_recursive(body_acts, df_set, start_counts, end_counts, depth + 1)
        redo_node = _discover_recursive(redo_acts, df_set, start_counts, end_counts, depth + 1)
        return OperatorPOWL(POWLOperator.LOOP, [body_node, redo_node])

    # ------------------------------------------------------------------
    # Fallback: concurrent partial order over all activities
    # ------------------------------------------------------------------
    nodes = [Transition(a) for a in sorted(activities)]
    return StrictPartialOrder(nodes=nodes)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def discover_powl(
    log: pl.LazyFrame,
    variant: object = None,
    filtering_weight_factor: float = 0.0,
    order_graph_filtering_threshold: Optional[float] = None,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
) -> POWL:
    """Discover a POWL model from an event log.

    Parameters
    ----------
    log:
        Event log as a Polars DataFrame or LazyFrame.
    variant:
        Algorithm variant (currently ignored — reserved for future use).
    filtering_weight_factor:
        Factoring threshold for filtering, ``0 <= x < 1`` (default 0.0).
    order_graph_filtering_threshold:
        Filtering threshold for the order graph (default None).
    activity_key:
        Column name for the activity attribute.
    timestamp_key:
        Column name for the timestamp attribute.
    case_id_key:
        Column name for the case identifier.

    Returns
    -------
    POWL
        Root node of the discovered POWL model.
    """
    all_acts, df_set, start_counts, end_counts = _build_dfg_and_relations(
        log, activity_key, timestamp_key, case_id_key
    )

    # Apply filtering_weight_factor: remove DF edges with relative weight below threshold
    if filtering_weight_factor > 0.0:
        source = log if isinstance(log, pl.LazyFrame) else log.lazy()
        base = source.sort([case_id_key, timestamp_key])
        df_with_freq = (
            base
            .with_columns(
                pl.col(activity_key).shift(-1).over(case_id_key).alias("_next")
            )
            .filter(pl.col("_next").is_not_null())
            .group_by([activity_key, "_next"])
            .agg(pl.len().alias("_cnt"))
            .collect()
        )
        if len(df_with_freq) > 0:
            max_cnt = df_with_freq["_cnt"].max()
            threshold = filtering_weight_factor * max_cnt
            kept = df_with_freq.filter(pl.col("_cnt") > threshold)
            df_set = set(kept.select([activity_key, "_next"]).rows())

    return _discover_recursive(all_acts, df_set, start_counts, end_counts)
