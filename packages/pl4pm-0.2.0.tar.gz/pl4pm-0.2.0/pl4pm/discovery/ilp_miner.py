"""pl4pm.discovery.ilp_miner — ILP Miner for Petri net discovery.

Algorithm
---------
The ILP Miner finds the *minimal* set of Petri net places that is consistent
with all observed traces, using a two-phase approach:

Phase 1 — Polars preprocessing (fast, vectorised):
    * Sort events by [case_id, timestamp].
    * Compute directly-follows (DF) pairs with frequency.
    * Apply the alpha noise threshold to filter low-frequency DF pairs.
    * Extract unique traces and start/end activities.

Phase 2 — Candidate generation + ILP minimisation (Python / scipy):
    * Derive the footprint (causal >, parallel ||, choice #) from filtered DF.
    * Enumerate all *valid* alpha-candidate places (X, Y):
        - Every (x, y) ∈ X × Y is causal (x > y).
        - Every pair within X is unrelated (choice).
        - Every pair within Y is unrelated (choice).
        - The place is *feasible*: no negative marking occurs in any observed trace.
    * Remove dominated candidates (A ⊆ A', B ⊆ B' → dominated).
    * (Optional) use scipy MILP to find the provably-minimal covering set.
      Falls back to the maximal-pairs set when scipy is unavailable.

This mirrors pm4py's direct_ilp variant.  The Polars preprocessing gives a
significant speed advantage over pm4py's pandas-based implementation.

References
----------
* van der Aalst, W. M. P., Rubin, V., Verbeek, H. M. W., van Dongen, B. F.,
  Kindler, E., & Günther, C. W. (2010). Process mining: a two-step approach to
  balance between underfitting and overfitting.  Software & Systems Modeling.
"""

from __future__ import annotations

from typing import FrozenSet, List, Set, Tuple

import polars as pl

from pl4pm.constants import ACTIVITY_KEY, CASE_ID_KEY, TIMESTAMP_KEY
from pl4pm.objects.petri_net import PetriNet, Marking, add_arc_from_to


# ---------------------------------------------------------------------------
# Phase 1 — Polars preprocessing
# ---------------------------------------------------------------------------

def _extract_log_info(
    log: pl.LazyFrame,
    activity_key: str,
    timestamp_key: str,
    case_id_key: str,
    alpha: float,
) -> tuple[
    list[str],                       # sorted activity list
    set[tuple[str, str]],            # directly-follows set (after alpha filter)
    list[str],                       # start activities
    list[str],                       # end activities
    list[tuple[str, ...]],           # unique traces
]:
    source = log if isinstance(log, pl.LazyFrame) else log.lazy()
    base = source.sort([case_id_key, timestamp_key])

    # All activities (sorted for determinism)
    activities: list[str] = sorted(
        base.select(pl.col(activity_key).unique()).collect().to_series().to_list()
    )

    # DF pairs with frequency
    df_raw = (
        base
        .with_columns(
            pl.col(activity_key)
            .shift(-1)
            .over(case_id_key)
            .alias("_next")
        )
        .filter(pl.col("_next").is_not_null())
        .group_by([activity_key, "_next"])
        .agg(pl.len().alias("_cnt"))
        .collect()
    )

    # Alpha threshold: keep pairs whose frequency ≥ alpha * max_frequency
    if alpha < 1.0 and len(df_raw) > 0:
        threshold = int(alpha * df_raw["_cnt"].max())
        df_raw = df_raw.filter(pl.col("_cnt") >= max(threshold, 1))

    df_set: set[tuple[str, str]] = set(df_raw.select([activity_key, "_next"]).rows())

    # Start / end activities
    start_acts: list[str] = (
        base
        .group_by(case_id_key)
        .agg(pl.col(activity_key).first().alias("_f"))
        .select("_f").unique().collect()
        .to_series().to_list()
    )
    end_acts: list[str] = (
        base
        .group_by(case_id_key)
        .agg(pl.col(activity_key).last().alias("_l"))
        .select("_l").unique().collect()
        .to_series().to_list()
    )

    # Unique traces (for feasibility validation)
    raw_traces: list[list[str]] = (
        base
        .group_by(case_id_key)
        .agg(pl.col(activity_key).alias("_trace"))
        .select("_trace")
        .collect()
        .get_column("_trace")
        .to_list()
    )
    seen: set[tuple[str, ...]] = set()
    unique_traces: list[tuple[str, ...]] = []
    for t in raw_traces:
        key = tuple(t)
        if key not in seen:
            seen.add(key)
            unique_traces.append(key)

    return activities, df_set, start_acts, end_acts, unique_traces


# ---------------------------------------------------------------------------
# Phase 2 — Candidate generation and minimisation
# ---------------------------------------------------------------------------

def _build_relations(
    activities: list[str],
    df_set: set[tuple[str, str]],
) -> tuple[set[tuple[str, str]], set[tuple[str, str]]]:
    """Return (causal, parallel) relation sets from the filtered DF pairs."""
    causal: set[tuple[str, str]] = set()
    parallel: set[tuple[str, str]] = set()
    for a in activities:
        for b in activities:
            ab = (a, b) in df_set
            ba = (b, a) in df_set
            if ab and not ba:
                causal.add((a, b))
            elif ab and ba:
                parallel.add((a, b))
                parallel.add((b, a))
    return causal, parallel


def _place_feasible(
    preset: FrozenSet[str],
    postset: FrozenSet[str],
    m0: int,
    traces: list[tuple[str, ...]],
) -> bool:
    """Return True iff the place (preset, postset, m0) never goes negative."""
    for trace in traces:
        marking = m0
        for act in trace:
            if act in preset:
                marking += 1
            if act in postset:
                marking -= 1
                if marking < 0:
                    return False
    return True


def _enumerate_candidates(
    activities: list[str],
    causal: set[tuple[str, str]],
    parallel: set[tuple[str, str]],
    traces: list[tuple[str, ...]],
) -> list[tuple[FrozenSet[str], FrozenSet[str]]]:
    """
    BFS over (X, Y) pairs starting from causal singletons.

    Expansion rules (same as Alpha+ / ILP Miner):
    - To extend X with activity x2: must be causal before every y ∈ Y and
      must NOT be in a causal or parallel relation with any x ∈ X.
    - To extend Y with activity y2: every x ∈ X must be causal before y2
      and y2 must NOT be in a causal or parallel relation with any y ∈ Y.
    - The resulting place must be feasible against all observed traces.
    """
    act_set = set(activities)

    seen: set[tuple[FrozenSet[str], FrozenSet[str]]] = set()
    queue: list[tuple[FrozenSet[str], FrozenSet[str]]] = []
    feasible: list[tuple[FrozenSet[str], FrozenSet[str]]] = []

    # Seed: singleton causal pairs
    for (a, b) in sorted(causal):
        pair: tuple[FrozenSet[str], FrozenSet[str]] = (frozenset({a}), frozenset({b}))
        if pair not in seen:
            seen.add(pair)
            queue.append(pair)

    idx = 0
    while idx < len(queue):
        X, Y = queue[idx]
        idx += 1

        # Check feasibility of this candidate
        if _place_feasible(X, Y, 0, traces):
            feasible.append((X, Y))

        # Try extending X
        for x2 in activities:
            if x2 in X:
                continue
            # x2 must causally precede every y ∈ Y
            if not all((x2, y) in causal for y in Y):
                continue
            # x2 must be unrelated (not causal, not parallel) to every x ∈ X
            if any(
                (x2, x) in causal or (x, x2) in causal or (x2, x) in parallel
                for x in X
            ):
                continue
            new = (X | frozenset({x2}), Y)
            if new not in seen:
                seen.add(new)
                queue.append(new)

        # Try extending Y
        for y2 in activities:
            if y2 in Y:
                continue
            if not all((x, y2) in causal for x in X):
                continue
            if any(
                (y2, y) in causal or (y, y2) in causal or (y2, y) in parallel
                for y in Y
            ):
                continue
            new = (X, Y | frozenset({y2}))
            if new not in seen:
                seen.add(new)
                queue.append(new)

    # Remove dominated candidates: (X1,Y1) dominated if ∃ (X2,Y2): X1⊆X2, Y1⊆Y2
    def dominated(p: tuple, candidates: list) -> bool:
        X1, Y1 = p
        for X2, Y2 in candidates:
            if (X1, Y1) != (X2, Y2) and X1 <= X2 and Y1 <= Y2:
                return True
        return False

    maximal = [p for p in feasible if not dominated(p, feasible)]
    return maximal


def _ilp_minimize(
    candidates: list[tuple[FrozenSet[str], FrozenSet[str]]],
    causal: set[tuple[str, str]],
) -> list[tuple[FrozenSet[str], FrozenSet[str]]]:
    """
    Optional MILP minimisation using scipy.

    Finds the smallest subset of *candidates* that covers every observed
    causal pair (a, b): ∃ candidate (X,Y) with a ∈ X and b ∈ Y.

    Falls back to returning all maximal candidates when scipy is unavailable
    or when the problem is trivially small.
    """
    if not causal or not candidates:
        return candidates

    try:
        from scipy.optimize import milp, LinearConstraint, Bounds
        import numpy as np
    except ImportError:
        return candidates

    causal_list = sorted(causal)
    n_cands = len(candidates)
    n_constraints = len(causal_list)

    if n_cands <= 1:
        return candidates

    # Build coverage matrix: A[i][j] = 1 if candidate j covers causal pair i
    A = np.zeros((n_constraints, n_cands), dtype=np.float64)
    for i, (a, b) in enumerate(causal_list):
        for j, (X, Y) in enumerate(candidates):
            if a in X and b in Y:
                A[i, j] = 1.0

    # If any causal pair is not covered at all, return all candidates
    if np.any(A.sum(axis=1) == 0):
        return candidates

    c = np.ones(n_cands)                              # minimise: sum of selected places
    constraints = LinearConstraint(A, lb=1.0)          # each causal pair covered ≥ 1
    bounds = Bounds(lb=0.0, ub=1.0)
    integrality = np.ones(n_cands)                     # binary variables

    result = milp(c, constraints=constraints, integrality=integrality, bounds=bounds)

    if result.success:
        selected = [candidates[j] for j in range(n_cands) if result.x[j] > 0.5]
        return selected if selected else candidates

    return candidates


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def discover_petri_net_ilp(
    log: pl.LazyFrame,
    alpha: float = 1.0,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
) -> tuple[PetriNet, Marking, Marking]:
    """Discover a Petri net using the ILP Miner.

    Parameters
    ----------
    log:
        Event log as a Polars DataFrame or LazyFrame.
    alpha:
        Noise threshold for the sequence encoding graph
        (1.0 = no filtering, 0.0 = maximum filtering).
    activity_key:
        Column name for the activity attribute.
    timestamp_key:
        Column name for the timestamp attribute.
    case_id_key:
        Column name for the case identifier.

    Returns
    -------
    tuple[PetriNet, Marking, Marking]
        Petri net, initial marking, final marking.
    """
    activities, df_set, start_acts, end_acts, unique_traces = _extract_log_info(
        log, activity_key, timestamp_key, case_id_key, alpha
    )

    causal, parallel = _build_relations(activities, df_set)

    candidates = _enumerate_candidates(activities, causal, parallel, unique_traces)

    # Minimise via MILP (uses scipy if available)
    places = _ilp_minimize(candidates, causal)

    # ------------------------------------------------------------------ #
    # Build the Petri net                                                  #
    # ------------------------------------------------------------------ #
    net = PetriNet("ilp_net")
    source = PetriNet.Place("source")
    sink = PetriNet.Place("sink")
    net.places.add(source)
    net.places.add(sink)

    trans_map: dict[str, PetriNet.Transition] = {}
    for act in activities:
        t = PetriNet.Transition(f"t_{act}", label=act)
        net.transitions.add(t)
        trans_map[act] = t

    for act in start_acts:
        add_arc_from_to(source, trans_map[act], net)
    for act in end_acts:
        add_arc_from_to(trans_map[act], sink, net)

    for idx, (X, Y) in enumerate(places):
        p = PetriNet.Place(f"p_ilp_{idx}")
        net.places.add(p)
        for x in sorted(X):
            add_arc_from_to(trans_map[x], p, net)
        for y in sorted(Y):
            add_arc_from_to(p, trans_map[y], net)

    im = Marking({source: 1})
    fm = Marking({sink: 1})
    return net, im, fm
