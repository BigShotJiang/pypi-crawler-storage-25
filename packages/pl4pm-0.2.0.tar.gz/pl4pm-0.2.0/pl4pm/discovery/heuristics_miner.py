"""pl4pm.discovery.heuristics_miner — Heuristics Miner algorithm."""

from __future__ import annotations

from typing import Dict, Set, Tuple

import polars as pl

from pl4pm.constants import CASE_ID_KEY, ACTIVITY_KEY, TIMESTAMP_KEY
from pl4pm.objects.petri_net import PetriNet, Marking, add_arc_from_to
from pl4pm.objects.heuristics_net import HeuristicsNet
from pl4pm.discovery.dfg import discover_dfg


def discover_heuristics_net(
    log: pl.LazyFrame,
    dependency_threshold: float = 0.5,
    and_threshold: float = 0.65,
    loop_two_threshold: float = 0.5,
    min_act_count: int = 1,
    min_dfg_occurrences: int = 1,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
    decoration: str = "frequency",
) -> HeuristicsNet:
    """Discover a Heuristics Net from the log."""
    res = discover_dfg(log, activity_key, timestamp_key, case_id_key, include_window_2=True)
    dfg, start_acts, end_acts, dfg_w2, triples = res

    # Activity occurrences
    df = log.collect() if isinstance(log, pl.LazyFrame) else log
    act_occ_df = (
        df.lazy()
        .group_by(activity_key)
        .agg(pl.len().alias("cnt"))
        .collect()
    )
    act_occ: Dict[str, int] = dict(zip(
        act_occ_df[activity_key].to_list(),
        act_occ_df["cnt"].to_list()
    ))

    # Filter by min counts
    if min_act_count > 1:
        valid_acts = {a for a, c in act_occ.items() if c >= min_act_count}
        dfg = {k: v for k, v in dfg.items() if k[0] in valid_acts and k[1] in valid_acts}
    if min_dfg_occurrences > 1:
        dfg = {k: v for k, v in dfg.items() if v >= min_dfg_occurrences}

    hnet = HeuristicsNet(
        dfg=dfg,
        start_activities=start_acts,
        end_activities=end_acts,
        activities_occurrences=act_occ,
    )
    hnet.compute_dependency_matrix()

    # Apply dependency threshold — build output/input sets
    for a in hnet.activities:
        outputs: set[str] = set()
        inputs: set[str] = set()
        for b in hnet.activities:
            dep_ab = hnet.dependency_matrix.get(a, {}).get(b, 0.0)
            if dep_ab >= dependency_threshold:
                outputs.add(b)
            dep_ba = hnet.dependency_matrix.get(b, {}).get(a, 0.0)
            if dep_ba >= dependency_threshold:
                inputs.add(b)

        # Detect AND splits/joins using and_threshold
        if len(outputs) > 1:
            and_edges = []
            for n1 in outputs:
                for n2 in outputs:
                    if n1 < n2:
                        c1 = dfg.get((n1, n2), 0)
                        c2 = dfg.get((n2, n1), 0)
                        c3 = dfg.get((a, n1), 0)
                        c4 = dfg.get((a, n2), 0)
                        val = (c1 + c2) / (c3 + c4 + 1.0)
                        if val >= and_threshold:
                            and_edges.append((n1, n2))
            
            # Simple Bron-Kerbosch to find maximal cliques
            adj = {n: set() for n in outputs}
            for u, v in and_edges:
                adj[u].add(v)
                adj[v].add(u)
                
            cliques = []
            def bron_kerbosch(r, p, x):
                if not p and not x:
                    if len(r) > 0:
                        cliques.append(set(r))
                    return
                for v in list(p):
                    bron_kerbosch(r.union({v}), p.intersection(adj[v]), x.intersection(adj[v]))
                    p.remove(v)
                    x.add(v)
            bron_kerbosch(set(), set(outputs), set())
            
            # Filter non-maximal and sort
            maximal = []
            for c in sorted(cliques, key=len, reverse=True):
                if not any(c.issubset(m) for m in maximal):
                    maximal.append(c)
            # Add standalone
            in_clique = set().union(*maximal) if maximal else set()
            for out_act in outputs:
                if out_act not in in_clique:
                    maximal.append({out_act})
            hnet.output_sets[a] = maximal
        elif outputs:
            hnet.output_sets[a] = [outputs]

        if len(inputs) > 1:
            and_edges_in = []
            for n1 in inputs:
                for n2 in inputs:
                    if n1 < n2:
                        c1 = dfg.get((n1, n2), 0)
                        c2 = dfg.get((n2, n1), 0)
                        c3 = dfg.get((n1, a), 0)
                        c4 = dfg.get((n2, a), 0)
                        val = (c1 + c2) / (c3 + c4 + 1.0)
                        if val >= and_threshold:
                            and_edges_in.append((n1, n2))
                            
            adj_in = {n: set() for n in inputs}
            for u, v in and_edges_in:
                adj_in[u].add(v)
                adj_in[v].add(u)
                
            cliques_in = []
            def bron_kerbosch_in(r, p, x):
                if not p and not x:
                    if len(r) > 0:
                        cliques_in.append(set(r))
                    return
                for v in list(p):
                    bron_kerbosch_in(r.union({v}), p.intersection(adj_in[v]), x.intersection(adj_in[v]))
                    p.remove(v)
                    x.add(v)
            bron_kerbosch_in(set(), set(inputs), set())
            
            maximal_in = []
            for c in sorted(cliques_in, key=len, reverse=True):
                if not any(c.issubset(m) for m in maximal_in):
                    maximal_in.append(c)
            in_clique_in = set().union(*maximal_in) if maximal_in else set()
            for in_act in inputs:
                if in_act not in in_clique_in:
                    maximal_in.append({in_act})
            hnet.input_sets[a] = maximal_in
        elif inputs:
            hnet.input_sets[a] = [inputs]

    # Calculate Loops Length Two
    # vA_B_A is triples.get((A, B, A), 0)
    freq_triples_matrix = {}
    for (a1, a2, a3), count in triples.items():
        if a1 == a3 and a1 != a2:
            if a1 not in freq_triples_matrix:
                freq_triples_matrix[a1] = {}
            freq_triples_matrix[a1][a2] = count

    for n1 in hnet.activities:
        if n1 not in freq_triples_matrix:
            continue
        for n2 in freq_triples_matrix[n1]:
            v1 = freq_triples_matrix[n1].get(n2, 0)
            v2 = freq_triples_matrix.get(n2, {}).get(n1, 0)
            l2l = (v1 + v2) / (v1 + v2 + 1)

            if l2l >= loop_two_threshold:
                # Check if basic dfg threshold is met
                c1 = dfg.get((n1, n2), 0)
                if c1 >= min_dfg_occurrences and act_occ.get(n1, 0) >= min_act_count and act_occ.get(n2, 0) >= min_act_count:
                    # Only add if it's not already connected by dependency threshold
                    dep_n1_n2 = hnet.dependency_matrix.get(n1, {}).get(n2, 0.0)
                    dep_n2_n1 = hnet.dependency_matrix.get(n2, {}).get(n1, 0.0)
                    if not (dep_n1_n2 >= dependency_threshold or dep_n2_n1 >= dependency_threshold):
                        # Force edges n1 -> n2 and n2 -> n1 as singletons (OR relations)
                        if n1 not in hnet.output_sets: hnet.output_sets[n1] = []
                        if n2 not in hnet.input_sets: hnet.input_sets[n2] = []
                        if not any(n2 in g for g in hnet.output_sets[n1]):
                            hnet.output_sets[n1].append({n2})
                        if not any(n1 in g for g in hnet.input_sets[n2]):
                            hnet.input_sets[n2].append({n1})
                        
                        if n2 not in hnet.output_sets: hnet.output_sets[n2] = []
                        if n1 not in hnet.input_sets: hnet.input_sets[n1] = []
                        if not any(n1 in g for g in hnet.output_sets[n2]):
                            hnet.output_sets[n2].append({n1})
                        if not any(n2 in g for g in hnet.input_sets[n1]):
                            hnet.input_sets[n1].append({n2})

    return hnet


def discover_petri_net_heuristics(
    log: pl.LazyFrame,
    dependency_threshold: float = 0.5,
    and_threshold: float = 0.65,
    loop_two_threshold: float = 0.5,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
) -> Tuple[PetriNet, Marking, Marking]:
    """Discover a Petri net using the Heuristics Miner."""
    hnet = discover_heuristics_net(
        log, dependency_threshold, and_threshold, loop_two_threshold,
        activity_key=activity_key, timestamp_key=timestamp_key,
        case_id_key=case_id_key,
    )
    return _hnet_to_petri_net(hnet)


def _has_only_this_transition_as_output(place: PetriNet.Place, transition: PetriNet.Transition) -> bool:
    outgoing_transitions = {arc.target for arc in place.out_arcs if isinstance(arc.target, PetriNet.Transition)}
    return outgoing_transitions == {transition}


def _has_only_this_transition_as_input(place: PetriNet.Place, transition: PetriNet.Transition) -> bool:
    incoming_transitions = {arc.source for arc in place.in_arcs if isinstance(arc.source, PetriNet.Transition)}
    return incoming_transitions == {transition}


def reduce_single_entry_transitions(net: PetriNet) -> PetriNet:
    cont = True
    while cont:
        cont = False
        single_entry = [t for t in net.transitions if t.label is None and len(t.in_arcs) == 1]
        for t in single_entry:
            source_place = list(t.in_arcs)[0].source
            if len(source_place.in_arcs) == 1 and _has_only_this_transition_as_output(source_place, t):
                source_transition = list(source_place.in_arcs)[0].source
                target_places = [arc.target for arc in t.out_arcs]
                
                # Manual removal since we have it in net
                from pl4pm.objects.petri_net import remove_transition, remove_place
                remove_transition(net, t)
                remove_place(net, source_place)
                
                for p in target_places:
                    add_arc_from_to(source_transition, p, net)
                cont = True
                break
    return net


def reduce_single_exit_transitions(net: PetriNet) -> PetriNet:
    cont = True
    while cont:
        cont = False
        single_exit = [t for t in net.transitions if t.label is None and len(t.out_arcs) == 1]
        for t in single_exit:
            target_place = list(t.out_arcs)[0].target
            if len(target_place.out_arcs) == 1 and _has_only_this_transition_as_input(target_place, t):
                target_transition = list(target_place.out_arcs)[0].target
                source_places = [arc.source for arc in t.in_arcs]
                
                from pl4pm.objects.petri_net import remove_transition, remove_place
                remove_transition(net, t)
                remove_place(net, target_place)
                
                for p in source_places:
                    add_arc_from_to(p, target_transition, net)
                cont = True
                break
    return net


def apply_simple_reduction(net: PetriNet) -> PetriNet:
    changed = True
    while changed:
        old_t = len(net.transitions)
        old_p = len(net.places)
        
        reduce_single_entry_transitions(net)
        reduce_single_exit_transitions(net)
        
        if len(net.transitions) < old_t or len(net.places) < old_p:
            changed = True
        else:
            changed = False
    return net


def _hnet_to_petri_net(hnet: HeuristicsNet) -> Tuple[PetriNet, Marking, Marking]:
    """Convert a HeuristicsNet to a Petri net matching pm4py structure strictly."""
    net = PetriNet("heuristics_pn")
    im = Marking()
    fm = Marking()

    source_places = []
    sink_places = []
    hid_trans_count = 0

    acts_list = sorted(list(hnet.activities))
    start_list = sorted(list(hnet.start_activities.keys()))
    end_list = sorted(list(hnet.end_activities.keys()))

    source = PetriNet.Place("source0")
    source_places.append(source)
    net.places.add(source)
    im[source] = 1

    sink = PetriNet.Place("sink0")
    sink_places.append(sink)
    net.places.add(sink)
    fm[sink] = 1

    act_trans = {}
    who_is_entering: Dict[str, Set[Tuple[str | None, int | None]]] = {a: set() for a in acts_list}
    who_is_exiting: Dict[str, Set[Tuple[str | None, int | None]]] = {a: set() for a in acts_list}

    for act in acts_list:
        act_trans[act] = PetriNet.Transition(act, label=act)
        net.transitions.add(act_trans[act])

    for act in start_list:
        who_is_entering[act].add((None, 0))

    for act in end_list:
        who_is_exiting[act].add((None, 0))

    for a in acts_list:
        for b in acts_list:
            # Reconstruct exact dependencies entering and exiting via loops
            outputs = set()
            for grp in hnet.output_sets.get(a, []):
                outputs.update(grp)
            if b in outputs:
                who_is_entering[b].add((a, None))
                who_is_exiting[a].add((b, None))

    places_entering = {}
    for act in acts_list:
        places_entering[act] = {}
        entering = list(who_is_entering[act])
        entering_preds = sorted([x for x in entering if x[0] is not None], key=lambda x: str(x[0]))
        entering_sources = [x for x in entering if x[0] is None]

        master_place = None
        if entering_preds or len(entering) > 1:
            master_place = PetriNet.Place("pre_" + act)
            net.places.add(master_place)
            add_arc_from_to(master_place, act_trans[act], net)

        cliques = hnet.input_sets.get(act, [])
        pred_names_set = set([x[0] for x in entering_preds if x[0]])
        and_members = set()

        for clique in cliques:
            clique_filtered = sorted([n for n in clique if n in pred_names_set])
            if len(clique_filtered) < 2:
                continue
            and_members.update(clique_filtered)
            hid_trans_count += 1
            hid_trans = PetriNet.Transition(f"hid_{hid_trans_count}", None)
            net.transitions.add(hid_trans)
            if master_place:
                add_arc_from_to(hid_trans, master_place, net)
            for pred in clique_filtered:
                key = (pred, None)
                if key not in places_entering[act]:
                    s_place = PetriNet.Place(f"splace_in_{act}_{pred}")
                    net.places.add(s_place)
                    places_entering[act][key] = s_place
                add_arc_from_to(places_entering[act][key], hid_trans, net)

        for pred_tuple in entering_preds:
            pred_name = pred_tuple[0]
            if pred_name in and_members:
                continue
            if len(entering) == 1:
                places_entering[act][pred_tuple] = master_place
            else:
                key = pred_tuple
                if key not in places_entering[act]:
                    s_place = PetriNet.Place(f"splace_in_{act}_{pred_name}")
                    net.places.add(s_place)
                    places_entering[act][key] = s_place
                hid_trans_count += 1
                hid_trans = PetriNet.Transition(f"hid_{hid_trans_count}", None)
                net.transitions.add(hid_trans)
                add_arc_from_to(places_entering[act][key], hid_trans, net)
                if master_place:
                    add_arc_from_to(hid_trans, master_place, net)

        for src_tuple in entering_sources:
            src_idx = src_tuple[1]
            if len(entering) == 1:
                add_arc_from_to(source_places[src_idx], act_trans[act], net)
            else:
                hid_trans_count += 1
                hid_trans = PetriNet.Transition(f"hid_{hid_trans_count}", None)
                net.transitions.add(hid_trans)
                add_arc_from_to(source_places[src_idx], hid_trans, net)
                if master_place:
                    add_arc_from_to(hid_trans, master_place, net)

    for act in acts_list:
        exiting = list(who_is_exiting[act])
        exiting_succs = sorted([x for x in exiting if x[0] is not None], key=lambda x: str(x[0]))
        exiting_sinks = [x for x in exiting if x[0] is None]

        if len(exiting) == 1 and exiting_succs:
            succ = exiting_succs[0][0]
            if (act, None) in places_entering.get(succ, {}):
                add_arc_from_to(act_trans[act], places_entering[succ][(act, None)], net)
            continue

        if len(exiting) == 1 and exiting_sinks:
            sink_idx = exiting_sinks[0][1]
            add_arc_from_to(act_trans[act], sink_places[sink_idx], net)
            continue

        int_place = PetriNet.Place("intplace_" + act)
        net.places.add(int_place)
        add_arc_from_to(act_trans[act], int_place, net)

        cliques = hnet.output_sets.get(act, [])
        succ_names_set = set([x[0] for x in exiting_succs if x[0]])
        and_members = set()

        for clique in cliques:
            clique_filtered = sorted([n for n in clique if n in succ_names_set])
            if len(clique_filtered) < 2:
                continue
            and_members.update(clique_filtered)
            hid_trans_count += 1
            hid_trans = PetriNet.Transition(f"hid_{hid_trans_count}", None)
            net.transitions.add(hid_trans)
            add_arc_from_to(int_place, hid_trans, net)
            for succ in clique_filtered:
                if (act, None) in places_entering.get(succ, {}):
                    add_arc_from_to(hid_trans, places_entering[succ][(act, None)], net)

        for succ_tuple in exiting_succs:
            succ = succ_tuple[0]
            if succ in and_members:
                continue
            if (act, None) in places_entering.get(succ, {}):
                hid_trans_count += 1
                hid_trans = PetriNet.Transition(f"hid_{hid_trans_count}", None)
                net.transitions.add(hid_trans)
                add_arc_from_to(int_place, hid_trans, net)
                add_arc_from_to(hid_trans, places_entering[succ][(act, None)], net)

        for sink_tuple in exiting_sinks:
            sink_idx = sink_tuple[1]
            hid_trans_count += 1
            hid_trans = PetriNet.Transition(f"hid_{hid_trans_count}", None)
            net.transitions.add(hid_trans)
            add_arc_from_to(int_place, hid_trans, net)
            add_arc_from_to(hid_trans, sink_places[sink_idx], net)

    from pl4pm.objects.petri_net import remove_transition
    trans = [x for x in list(net.transitions) if x.is_silent]
    i = 0
    while i < len(trans):
        if trans[i] in net.transitions:
            preset_i = set(x.source for x in trans[i].in_arcs)
            postset_i = set(x.target for x in trans[i].out_arcs)
            j = 0
            while j < len(trans):
                if not j == i and trans[j] in net.transitions:
                    preset_j = set(x.source for x in trans[j].in_arcs)
                    postset_j = set(x.target for x in trans[j].out_arcs)
                    if len(preset_j) == len(preset_i) and len(postset_j) < len(postset_i):
                        if (
                            len(preset_j.intersection(preset_i)) == len(preset_j)
                            and len(postset_j.intersection(postset_i)) == len(postset_j)
                        ):
                            remove_transition(net, trans[j])
                            continue
                j += 1
        i += 1

    apply_simple_reduction(net)

    return net, im, fm
