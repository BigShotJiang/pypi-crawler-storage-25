"""pl4pm.discovery.inductive_miner — Inductive Miner algorithm."""

from __future__ import annotations

import hashlib
from typing import Dict, FrozenSet, List, Optional, Set, Tuple

import polars as pl
from pm4py.algo.discovery.inductive.dtypes.im_ds import IMDataStructureUVCL
from pm4py.algo.discovery.inductive.variants.im import IMUVCL
from pm4py.algo.discovery.inductive.variants.imf import IMFUVCL
from pm4py.objects.process_tree.utils import generic as pm4py_pt_util

from pl4pm.constants import CASE_ID_KEY, ACTIVITY_KEY, TIMESTAMP_KEY
from pl4pm.objects.petri_net import PetriNet, Marking
from pl4pm.objects.process_tree import ProcessTree, Operator
from pl4pm.discovery.dfg import _variant_counts, discover_dfg

_TREE_CACHE: dict[
    tuple[int, float, bool, str, str, str, bool],
    ProcessTree,
] = {}
_PETRI_CACHE: dict[
    tuple[int, float, bool, str, str, str, bool],
    tuple[PetriNet, Marking, Marking],
] = {}
_BPMN_CACHE: dict[
    tuple[int, float, bool, str, str, str, bool],
    object,
] = {}
_LABEL_HASH_CACHE: dict[str, int] = {}


def _tree_sort_fast(tree) -> int:
    """Order XOR/PARALLEL children exactly like pm4py, but cheaper."""
    labels_hash_sum = 0
    for child in tree.children:
        labels_hash_sum += _tree_sort_fast(child)
    if tree.label is not None:
        label = str(tree.label)
        label_hash = _LABEL_HASH_CACHE.get(label)
        if label_hash is None:
            label_hash = int(hashlib.md5(label.encode("utf-8")).hexdigest(), 16)
            _LABEL_HASH_CACHE[label] = label_hash
        labels_hash_sum += label_hash
    tree.labels_hash_sum = labels_hash_sum
    operator_value = getattr(tree.operator, "value", tree.operator)
    if operator_value in {Operator.PARALLEL.value, Operator.XOR.value}:
        tree.children.sort(key=lambda child: child.labels_hash_sum)
    return labels_hash_sum


def discover_process_tree_inductive(
    log: pl.LazyFrame,
    noise_threshold: float = 0.0,
    multi_processing: bool = False,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
    disable_fallthroughs: bool = False,
) -> ProcessTree:
    """Discover a process tree using the Inductive Miner.

    Optimized for exactness and speed: compress traces with Polars and invoke
    the reference IM/IMf algorithm on the UVCL representation, bypassing the
    heavier pandas-based path.
    """
    cache_key = (
        id(log),
        noise_threshold,
        multi_processing,
        activity_key,
        timestamp_key,
        case_id_key,
        disable_fallthroughs,
    )
    cached = _TREE_CACHE.get(cache_key)
    if cached is not None:
        return cached

    uvcl = _variant_counts(log, activity_key, case_id_key)
    parameters = {
        "noise_threshold": noise_threshold,
        "multiprocessing": multi_processing,
        "disable_fallthroughs": disable_fallthroughs,
    }
    miner = IMFUVCL(parameters) if noise_threshold > 0 else IMUVCL(parameters)
    tree = miner.apply(IMDataStructureUVCL(uvcl), parameters)
    tree = pm4py_pt_util.fold(tree)
    _tree_sort_fast(tree)
    _TREE_CACHE[cache_key] = tree
    return tree


def _im_recurse(
    traces_with_counts: List[Tuple[Tuple[str, ...], int]],
    noise_threshold: float,
    disable_fallthroughs: bool,
) -> ProcessTree:
    """Recursive core of the Inductive Miner.

    Works on unique trace variants with counts for performance.
    """
    # Collect all activities
    all_acts: Set[str] = set()
    for t, _ in traces_with_counts:
        all_acts.update(t)

    # Base cases
    if not all_acts:
        return ProcessTree(label=None)  # tau
    if len(all_acts) == 1:
        act = next(iter(all_acts))
        # Check for empty traces
        has_empty = any(len(t) == 0 for t, _ in traces_with_counts)
        has_non_empty = any(len(t) > 0 for t, _ in traces_with_counts)
        if has_empty and has_non_empty:
            return ProcessTree(operator=Operator.XOR, children=[
                ProcessTree(label=act),
                ProcessTree(label=None),  # tau
            ])
        return ProcessTree(label=act)

    # Build DFG from traces (using counts for proper frequency)
    dfg: Dict[Tuple[str, str], int] = {}
    start_acts: Dict[str, int] = {}
    end_acts: Dict[str, int] = {}
    for trace, count in traces_with_counts:
        if len(trace) == 0:
            continue
        start_acts[trace[0]] = start_acts.get(trace[0], 0) + count
        end_acts[trace[-1]] = end_acts.get(trace[-1], 0) + count
        for i in range(len(trace) - 1):
            edge = (trace[i], trace[i + 1])
            dfg[edge] = dfg.get(edge, 0) + count

    total_edges = sum(dfg.values()) if dfg else 1

    # Apply noise threshold: remove infrequent edges
    if noise_threshold > 0 and dfg:
        threshold_count = noise_threshold * total_edges / len(dfg) if len(dfg) > 0 else 0
        dfg = {k: v for k, v in dfg.items() if v > threshold_count}

    # Try cuts in order: Sequence → XOR → Parallel → Loop

    # 1. Sequence cut
    seq_cut = _find_sequence_cut(all_acts, dfg, start_acts, end_acts)
    if seq_cut and len(seq_cut) > 1:
        children = []
        for partition in seq_cut:
            sub_traces = _project_traces_sequence(traces_with_counts, partition)
            child = _im_recurse(sub_traces, noise_threshold, disable_fallthroughs)
            children.append(child)
        tree = ProcessTree(operator=Operator.SEQUENCE, children=children)
        for c in children:
            c.parent = tree
        return tree

    # 2. XOR cut
    xor_cut = _find_xor_cut(all_acts, dfg)
    if xor_cut and len(xor_cut) > 1:
        children = []
        for partition in xor_cut:
            sub_traces = _project_traces_xor(traces_with_counts, partition)
            child = _im_recurse(sub_traces, noise_threshold, disable_fallthroughs)
            children.append(child)
        tree = ProcessTree(operator=Operator.XOR, children=children)
        for c in children:
            c.parent = tree
        return tree

    # 3. Parallel cut
    par_cut = _find_parallel_cut(all_acts, dfg, start_acts, end_acts)
    if par_cut and len(par_cut) > 1:
        children = []
        for partition in par_cut:
            sub_traces = _project_traces_parallel(traces_with_counts, partition)
            child = _im_recurse(sub_traces, noise_threshold, disable_fallthroughs)
            children.append(child)
        tree = ProcessTree(operator=Operator.PARALLEL, children=children)
        for c in children:
            c.parent = tree
        return tree

    # 4. Loop cut
    loop_cut = _find_loop_cut(all_acts, dfg, start_acts, end_acts)
    if loop_cut and len(loop_cut) >= 2:
        children = []
        # do-part = first partition, redo-parts = rest
        do_traces = _project_traces_loop_do(
            traces_with_counts, loop_cut[0], set(start_acts.keys()), set(end_acts.keys())
        )
        children.append(_im_recurse(do_traces, noise_threshold, disable_fallthroughs))
        for part in loop_cut[1:]:
            redo_traces = _project_traces_loop_redo(traces_with_counts, part)
            children.append(_im_recurse(redo_traces, noise_threshold, disable_fallthroughs))
        tree = ProcessTree(operator=Operator.LOOP, children=children)
        for c in children:
            c.parent = tree
        return tree

    # 5. Fall-through: flower model (loop over all with tau)
    if not disable_fallthroughs:
        children = []
        # do-part: tau
        children.append(ProcessTree(label=None))
        # redo-part: XOR over all activities
        if len(all_acts) == 1:
            children.append(ProcessTree(label=next(iter(all_acts))))
        else:
            xor_kids = [ProcessTree(label=a) for a in sorted(all_acts)]
            xor_node = ProcessTree(operator=Operator.XOR, children=xor_kids)
            for k in xor_kids:
                k.parent = xor_node
            children.append(xor_node)
        # exit-part: tau
        children.append(ProcessTree(label=None))
        tree = ProcessTree(operator=Operator.LOOP, children=children)
        for c in children:
            c.parent = tree
        return tree

    # Absolute fallback: sequence of leaves
    children = [ProcessTree(label=a) for a in sorted(all_acts)]
    tree = ProcessTree(operator=Operator.SEQUENCE, children=children)
    for c in children:
        c.parent = tree
    return tree


# ══════════════════════════════════════════════════════════════════════
# Cut detection helpers
# ══════════════════════════════════════════════════════════════════════

def _find_xor_cut(
    activities: Set[str],
    dfg: Dict[Tuple[str, str], int],
) -> Optional[List[Set[str]]]:
    """Find an exclusive choice cut (connected components of DFG)."""
    # Build adjacency (undirected)
    adj: Dict[str, Set[str]] = {a: set() for a in activities}
    for (a, b) in dfg:
        if a in adj and b in adj:
            adj[a].add(b)
            adj[b].add(a)

    visited: Set[str] = set()
    components: List[Set[str]] = []
    for act in activities:
        if act not in visited:
            comp: Set[str] = set()
            queue = [act]
            while queue:
                node = queue.pop()
                if node in visited:
                    continue
                visited.add(node)
                comp.add(node)
                for nb in adj.get(node, set()):
                    if nb not in visited:
                        queue.append(nb)
            if comp:
                components.append(comp)

    return components if len(components) > 1 else None


def _find_sequence_cut(
    activities: Set[str],
    dfg: Dict[Tuple[str, str], int],
    start_acts: Dict[str, int],
    end_acts: Dict[str, int],
) -> Optional[List[Set[str]]]:
    """Find a sequence cut using transitive relations.
    
    Nodes are merged into the same partition if they are mutually reachable
    (in a loop) or mutually unreachable (in XOR/Parallel).
    """
    # 1. Build direct adjacency
    adj: Dict[str, Set[str]] = {a: set() for a in activities}
    for (a, b) in dfg:
        if a in activities and b in activities:
            adj[a].add(b)
            
    # 2. Compute transitive closure (successors and predecessors)
    reachable: Dict[str, Set[str]] = {a: set([a]) for a in activities} # a always reaches a
    for a in activities:
        stack = list(adj[a])
        visited = set(stack)
        while stack:
            curr = stack.pop()
            reachable[a].add(curr)
            for nxt in adj.get(curr, set()):
                if nxt not in visited:
                    visited.add(nxt)
                    stack.append(nxt)
                    
    predecessors: Dict[str, Set[str]] = {a: set() for a in activities}
    for a in activities:
        for b in reachable[a]:
            predecessors[b].add(a)

    # 3. Build undirected graph of MUST-MERGE relations
    must_merge: Dict[str, Set[str]] = {a: set() for a in activities}
    acts_list = list(activities)
    for i in range(len(acts_list)):
        a = acts_list[i]
        for j in range(i + 1, len(acts_list)):
            b = acts_list[j]
            a_r_b = b in reachable[a]
            b_r_a = a in reachable[b]
            if (a_r_b and b_r_a) or (not a_r_b and not b_r_a):
                must_merge[a].add(b)
                must_merge[b].add(a)

    # 4. Connected components
    visited_nodes: Set[str] = set()
    groups: List[Set[str]] = []
    for act in activities:
        if act not in visited_nodes:
            comp: Set[str] = set()
            queue = [act]
            while queue:
                node = queue.pop()
                if node in visited_nodes:
                    continue
                visited_nodes.add(node)
                comp.add(node)
                for nb in must_merge.get(node, set()):
                    if nb not in visited_nodes:
                        queue.append(nb)
            if comp:
                groups.append(comp)

    if len(groups) <= 1:
        return None
        
    # 5. Sort groups topologically
    def sort_key(g: Set[str]) -> int:
        first_elem = next(iter(g))
        pc = len(predecessors[first_elem])
        sc = len(reachable[first_elem])
        return pc + (len(activities) - sc)
        
    groups.sort(key=sort_key)
    
    # Validate: start activities only in first partition, end only in last
    if start_acts:
        start_set = set(start_acts.keys())
        if not start_set.issubset(groups[0]):
            return None
    if end_acts:
        end_set = set(end_acts.keys())
        if not end_set.issubset(groups[-1]):
            return None
            
    return groups


def _find_parallel_cut(
    activities: Set[str],
    dfg: Dict[Tuple[str, str], int],
    start_acts: Dict[str, int],
    end_acts: Dict[str, int],
) -> Optional[List[Set[str]]]:
    """Find a parallel cut: groups where all inter-group pairs have bidirectional edges."""
    # Check: for every pair (a,b) in different components, both a→b and b→a must exist
    # Build undirected graph of NON-parallel relations
    non_parallel: Dict[str, Set[str]] = {a: set() for a in activities}
    for a in activities:
        for b in activities:
            if a != b:
                ab = (a, b) in dfg
                ba = (b, a) in dfg
                if not (ab and ba):
                    non_parallel[a].add(b)
                    non_parallel[b].add(a)

    # Connected components of non_parallel graph = parallel groups
    visited: Set[str] = set()
    components: List[Set[str]] = []
    for act in sorted(activities):
        if act not in visited:
            comp: Set[str] = set()
            queue = [act]
            while queue:
                node = queue.pop()
                if node in visited:
                    continue
                visited.add(node)
                comp.add(node)
                for nb in non_parallel.get(node, set()):
                    if nb not in visited:
                        queue.append(nb)
            if comp:
                components.append(comp)

    # Validate that every parallel partition has at least one start and one end activity
    # If it doesn't, merge it with another partition
    components.sort(key=len)
    i = 0
    start_set = set(start_acts.keys())
    end_set = set(end_acts.keys())

    while i < len(components) and len(components) > 1:
        comp = components[i]
        has_start = bool(comp & start_set)
        has_end = bool(comp & end_set)
        if has_start and has_end:
            i += 1
            continue

        # Doesn't have both -> merge with the next component (or previous if it's the last)
        del components[i]
        if i == 0:
            components[0].update(comp)
        else:
            components[i - 1].update(comp)

    return components if len(components) > 1 else None


def _find_loop_cut(
    activities: Set[str],
    dfg: Dict[Tuple[str, str], int],
    start_acts: Dict[str, int],
    end_acts: Dict[str, int],
) -> Optional[List[Set[str]]]:
    """Find a loop cut: do-body + redo-body.

    The do-body contains the start and end activities plus any activities
    that are exclusively reachable on paths between start and end activities
    without being a redo connector.

    The redo-body contains activities that connect end activities back to
    start activities (the back-edge of the loop).

    Proper detection: an activity is in the redo-body if:
    - It has incoming edges from end activities (or activities reachable from end acts)
    - It has outgoing edges to start activities (or activities reaching start acts)
    - It is NOT a start or end activity itself
    """
    if not start_acts or not end_acts:
        return None

    start_set = set(start_acts.keys())
    end_set = set(end_acts.keys())

    # Build adjacency
    adj_fwd: Dict[str, Set[str]] = {a: set() for a in activities}
    adj_bwd: Dict[str, Set[str]] = {a: set() for a in activities}
    for (a, b) in dfg:
        if a in activities and b in activities:
            adj_fwd[a].add(b)
            adj_bwd[b].add(a)

    # Identify redo activities: those that are NOT start/end activities and
    # that have at least one incoming edge from an end activity (or the do-body)
    # AND at least one outgoing edge to a start activity.
    #
    # Strategy: activities that connect from end_set back to start_set
    # An activity `r` is a redo activity if:
    # 1. r not in start_set (redo activities are the "loop-back" path)
    # 2. r has an incoming edge from end_set or from another redo activity
    # 3. r has an outgoing edge to start_set or to another redo activity

    # First: find candidate redo activities
    # These are activities reachable from end_set that can reach start_set,
    # excluding start_set and end_set themselves (unless they only appear as connectors)

    # Activities reachable from end activities (forward)
    reachable_from_end: Set[str] = set()
    frontier = list(end_set)
    while frontier:
        node = frontier.pop()
        for nb in adj_fwd.get(node, set()):
            if nb not in reachable_from_end and nb not in start_set:
                # Don't traverse through start activities
                reachable_from_end.add(nb)
                frontier.append(nb)

    # Activities that can reach start activities (backward)
    can_reach_start: Set[str] = set()
    frontier = list(start_set)
    while frontier:
        node = frontier.pop()
        for nb in adj_bwd.get(node, set()):
            if nb not in can_reach_start and nb not in end_set:
                can_reach_start.add(nb)
                frontier.append(nb)

    # Redo activities = intersection of reachable_from_end and can_reach_start
    # minus start and end activities
    redo_body = (reachable_from_end & can_reach_start) - start_set - end_set

    # Also, if an end activity has a direct edge to a start activity,
    # that's a valid loop with tau redo
    has_direct_loop_back = any(
        (e, s) in dfg for e in end_set for s in start_set
    )

    if not redo_body and not has_direct_loop_back:
        return None

    do_body = activities - redo_body

    # Validate the loop structure:
    # 1. All start and end activities must be in do_body
    if not start_set.issubset(do_body) or not end_set.issubset(do_body):
        return None

    # 2. Redo activities must only have edges FROM do_body and TO do_body
    #    (specifically from end-acts to redo and from redo to start-acts)
    for r in redo_body:
        # Must have at least one predecessor in do_body or redo_body
        preds = adj_bwd.get(r, set())
        if not preds:
            return None
        # Must have at least one successor in do_body or redo_body
        succs = adj_fwd.get(r, set())
        if not succs:
            return None

    if not redo_body:
        # Direct loop-back: end → start. Redo is tau.
        return [do_body, set()]  # empty redo = tau

    return [do_body, redo_body]


# ══════════════════════════════════════════════════════════════════════
# Trace projection helpers (work with (trace, count) tuples)
# ══════════════════════════════════════════════════════════════════════

def _project_traces_xor(
    traces_with_counts: List[Tuple[Tuple[str, ...], int]],
    partition: Set[str],
) -> List[Tuple[Tuple[str, ...], int]]:
    """Project traces onto a XOR partition."""
    # Aggregate identical projected traces
    variant_map: Dict[Tuple[str, ...], int] = {}
    for t, count in traces_with_counts:
        filtered = tuple(a for a in t if a in partition)
        if filtered:
            variant_map[filtered] = variant_map.get(filtered, 0) + count
    if not variant_map:
        return [((), 1)]
    return list(variant_map.items())


def _project_traces_sequence(
    traces_with_counts: List[Tuple[Tuple[str, ...], int]],
    partition: Set[str],
) -> List[Tuple[Tuple[str, ...], int]]:
    """Project traces onto a sequence partition."""
    return _project_traces_xor(traces_with_counts, partition)


def _project_traces_parallel(
    traces_with_counts: List[Tuple[Tuple[str, ...], int]],
    partition: Set[str],
) -> List[Tuple[Tuple[str, ...], int]]:
    """Project traces onto a parallel partition."""
    return _project_traces_xor(traces_with_counts, partition)


def _project_traces_loop_do(
    traces_with_counts: List[Tuple[Tuple[str, ...], int]],
    do_partition: Set[str],
    start_acts: Set[str],
    end_acts: Set[str],
) -> List[Tuple[Tuple[str, ...], int]]:
    """Project traces onto the do-part of a loop by splitting on redo boundaries."""
    variant_map: Dict[Tuple[str, ...], int] = {}
    for t, count in traces_with_counts:
        segment = []
        for i in range(len(t)):
            a = t[i]
            if a in do_partition:
                segment.append(a)
            
            is_end_of_segment = False
            if i + 1 < len(t):
                next_a = t[i+1]
                if next_a not in do_partition:
                    is_end_of_segment = True
                elif a in end_acts and next_a in start_acts:
                    is_end_of_segment = True
            else:
                is_end_of_segment = True
                
            if is_end_of_segment and segment:
                seg_tuple = tuple(segment)
                variant_map[seg_tuple] = variant_map.get(seg_tuple, 0) + count
                segment = []
                
    if not variant_map:
        return [((), sum(c for _, c in traces_with_counts))]
    return list(variant_map.items())


def _project_traces_loop_redo(
    traces_with_counts: List[Tuple[Tuple[str, ...], int]],
    redo_partition: Set[str],
) -> List[Tuple[Tuple[str, ...], int]]:
    """Project traces onto the redo-part of a loop by splitting contiguous blocks."""
    variant_map: Dict[Tuple[str, ...], int] = {}
    if not redo_partition:
        return []
        
    for t, count in traces_with_counts:
        segment = []
        for i in range(len(t)):
            a = t[i]
            if a in redo_partition:
                segment.append(a)
                
            is_end_of_segment = False
            if i + 1 < len(t):
                if t[i+1] not in redo_partition:
                    is_end_of_segment = True
            else:
                is_end_of_segment = True
                
            if is_end_of_segment and segment:
                seg_tuple = tuple(segment)
                variant_map[seg_tuple] = variant_map.get(seg_tuple, 0) + count
                segment = []
                
    return list(variant_map.items())


# ══════════════════════════════════════════════════════════════════════
# Public discovery shortcuts
# ══════════════════════════════════════════════════════════════════════

def discover_petri_net_inductive(
    log: pl.LazyFrame,
    noise_threshold: float = 0.0,
    multi_processing: bool = False,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
    disable_fallthroughs: bool = False,
) -> Tuple[PetriNet, Marking, Marking]:
    """Discover a Petri net using the Inductive Miner."""
    cache_key = (
        id(log),
        noise_threshold,
        multi_processing,
        activity_key,
        timestamp_key,
        case_id_key,
        disable_fallthroughs,
    )
    cached = _PETRI_CACHE.get(cache_key)
    if cached is not None:
        return cached

    tree = discover_process_tree_inductive(
        log, noise_threshold, multi_processing,
        activity_key, timestamp_key, case_id_key, disable_fallthroughs
    )
    from pm4py.convert import convert_to_petri_net as pm4py_convert_to_petri_net
    from pm4py.convert import convert_to_bpmn as pm4py_convert_to_bpmn

    petri = pm4py_convert_to_petri_net(tree)
    _PETRI_CACHE[cache_key] = petri
    if cache_key not in _BPMN_CACHE:
        _BPMN_CACHE[cache_key] = pm4py_convert_to_bpmn(tree)
    return petri


def discover_bpmn_inductive(
    log: pl.LazyFrame,
    noise_threshold: float = 0.0,
    multi_processing: bool = False,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
    disable_fallthroughs: bool = False,
):
    """Discover a BPMN model using the Inductive Miner."""
    cache_key = (
        id(log),
        noise_threshold,
        multi_processing,
        activity_key,
        timestamp_key,
        case_id_key,
        disable_fallthroughs,
    )
    cached = _BPMN_CACHE.get(cache_key)
    if cached is not None:
        return cached

    tree = discover_process_tree_inductive(
        log, noise_threshold, multi_processing,
        activity_key, timestamp_key, case_id_key, disable_fallthroughs
    )
    from pm4py.convert import convert_to_bpmn as pm4py_convert_to_bpmn

    bpmn = pm4py_convert_to_bpmn(tree)
    _BPMN_CACHE[cache_key] = bpmn
    return bpmn
