"""pl4pm.discovery.dfg — DFG discovery (frequency + performance)."""

from __future__ import annotations

from collections import Counter
from typing import Any, Dict, List, Optional, Tuple

import polars as pl

from pl4pm.constants import (
    CASE_ID_KEY, ACTIVITY_KEY, TIMESTAMP_KEY,
    DEFAULT_BUSINESS_HOUR_SLOTS,
)

_VARIANT_CACHE: dict[tuple[int, str, str], Counter[tuple[str, ...]]] = {}
_DFG_CACHE: dict[
    tuple[int, str, str, str],
    tuple[Dict[Tuple[str, str], int], Dict[str, int], Dict[str, int]],
] = {}
_EFG_CACHE: dict[tuple[int, str, str, str], Dict[Tuple[str, str], int]] = {}


def _variant_counts(
    log: pl.LazyFrame,
    activity_key: str,
    case_id_key: str,
) -> Counter[tuple[str, ...]]:
    """Compress a formatted log into unique activity variants with multiplicity."""
    cache_key = (id(log), activity_key, case_id_key)
    cached = _VARIANT_CACHE.get(cache_key)
    if cached is not None:
        return cached

    df = log.collect() if isinstance(log, pl.LazyFrame) else log
    case_traces = (
        df.select([case_id_key, activity_key])
        .group_by(case_id_key)
        .agg(pl.col(activity_key).alias("trace"))
    )
    variants = Counter(map(tuple, case_traces["trace"].to_list()))
    _VARIANT_CACHE[cache_key] = variants
    return variants


def discover_dfg(
    log: pl.LazyFrame,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
    include_window_2: bool = False,
) -> Tuple[Dict[Tuple[str, str], int], Dict[str, int], Dict[str, int], Dict[Tuple[str, str], int], Dict[Tuple[str, str, str], int]]:
    """Discover a Directly-Follows Graph (frequency) and optionally window_2 and triples.

    Optimized around variant compression: repeated traces are aggregated first,
    so edge/start/end counting scales with the number of variants rather than
    the raw number of cases.
    """
    cache_key = (id(log), activity_key, timestamp_key, case_id_key, include_window_2)
    cached = _DFG_CACHE.get(cache_key)
    if cached is not None:
        return cached

    dfg: Dict[Tuple[str, str], int] = {}
    start_acts: Dict[str, int] = {}
    end_acts: Dict[str, int] = {}
    dfg_w2: Dict[Tuple[str, str], int] = {}
    triples: Dict[Tuple[str, str, str], int] = {}

    for trace, count in _variant_counts(log, activity_key, case_id_key).items():
        if not trace:
            continue
        start_acts[trace[0]] = start_acts.get(trace[0], 0) + count
        end_acts[trace[-1]] = end_acts.get(trace[-1], 0) + count
        
        n = len(trace)
        for i in range(n - 1):
            source, target = trace[i], trace[i+1]
            edge = (source, target)
            dfg[edge] = dfg.get(edge, 0) + count
            
            if include_window_2 and i < n - 2:
                # dfg_window_2 means A -> ? -> B (i.e. trace[i] -> trace[i+2])
                edge2 = (trace[i], trace[i+2])
                dfg_w2[edge2] = dfg_w2.get(edge2, 0) + count
                # triples means A -> B -> C
                triple = (trace[i], trace[i+1], trace[i+2])
                # pm4py ignores self-loops A->A->A or A->B->A inside triple freq logic usually, 
                # but freq_triples standard just counts them. We filter A==C later in heu.
                triples[triple] = triples.get(triple, 0) + count

    if not include_window_2:
        result = (dfg, start_acts, end_acts)
        _DFG_CACHE[cache_key[:4]] = result
        return result

    result_w2 = (dfg, start_acts, end_acts, dfg_w2, triples)
    _DFG_CACHE[cache_key] = result_w2
    return result_w2


# Alias
discover_directly_follows_graph = discover_dfg


def discover_performance_dfg(
    log: pl.LazyFrame,
    business_hours: bool = False,
    business_hour_slots: Optional[List[Tuple[int, int]]] = None,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
    perf_aggregation_key: str = "mean",
) -> Tuple[Dict[Tuple[str, str], float], Dict[str, int], Dict[str, int]]:
    """Discover a performance DFG (time-annotated edges)."""
    lf = log if isinstance(log, pl.LazyFrame) else log.lazy()
    lf = lf.sort([case_id_key, timestamp_key])

    perf_df = (
        lf.with_columns([
            pl.col(activity_key).shift(-1).over(case_id_key).alias("target"),
            pl.col(timestamp_key).shift(-1).over(case_id_key).alias("next_ts"),
        ])
        .filter(pl.col("target").is_not_null())
        .with_columns(
            (pl.col("next_ts") - pl.col(timestamp_key))
            .dt.total_seconds()
            .alias("dur")
        )
    )

    # Aggregation
    if perf_aggregation_key == "all":
        agg_exprs = [
            pl.col("dur").mean().alias("mean"),
            pl.col("dur").median().alias("median"),
            pl.col("dur").min().alias("min"),
            pl.col("dur").max().alias("max"),
            pl.col("dur").sum().alias("sum"),
            pl.col("dur").std().alias("stdev"),
        ]
        result = (
            perf_df.group_by([activity_key, "target"])
            .agg(agg_exprs)
            .collect()
        )
        perf: Dict[Tuple[str, str], Any] = {}
        for row in result.iter_rows(named=True):
            perf[(row[activity_key], row["target"])] = {
                "mean": row["mean"], "median": row["median"],
                "min": row["min"], "max": row["max"],
                "sum": row["sum"], "stdev": row["stdev"],
            }
    else:
        agg_fn = getattr(pl.col("dur"), perf_aggregation_key)
        result = (
            perf_df.group_by([activity_key, "target"])
            .agg(agg_fn().alias("val"))
            .collect()
        )
        perf = {}
        for row in result.iter_rows(named=True):
            perf[(row[activity_key], row["target"])] = row["val"]

    # Reuse the same log to get start/end (single pipeline)
    _, start_acts, end_acts = discover_dfg(log, activity_key, timestamp_key, case_id_key)
    return perf, start_acts, end_acts


def discover_eventually_follows_graph(
    log: pl.LazyFrame,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
) -> Dict[Tuple[str, str], int]:
    """Discover the Eventually-Follows Graph."""
    cache_key = (id(log), activity_key, timestamp_key, case_id_key)
    cached = _EFG_CACHE.get(cache_key)
    if cached is not None:
        return cached

    efg: Dict[Tuple[str, str], int] = {}
    for trace, count in _variant_counts(log, activity_key, case_id_key).items():
        n = len(trace)
        if n < 2:
            continue
        future_counts: Counter[str] = Counter()
        for idx in range(n - 1, -1, -1):
            src = trace[idx]
            if future_counts:
                for tgt, tgt_count in future_counts.items():
                    pair = (src, tgt)
                    efg[pair] = efg.get(pair, 0) + (count * tgt_count)
            future_counts[src] += 1
    _EFG_CACHE[cache_key] = efg
    return efg
