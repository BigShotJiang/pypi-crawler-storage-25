"""pl4pm.discovery.alpha_miner — Alpha Miner algorithm."""

from __future__ import annotations

from typing import Dict, FrozenSet, Set, Tuple

import polars as pl

from pl4pm.constants import CASE_ID_KEY, ACTIVITY_KEY, TIMESTAMP_KEY
from pl4pm.objects.petri_net import PetriNet, Marking, add_arc_from_to
from pl4pm.discovery.dfg import discover_dfg


def discover_petri_net_alpha(
    log: pl.LazyFrame,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
) -> Tuple[PetriNet, Marking, Marking]:
    """Discover a Petri net using the Alpha Miner.

    Steps:
    1. Build directly-follows relation (>)
    2. Derive causality (→), parallel (||), and unrelated (#) relations
    3. Find maximal pairs (A, B) s.t. A×B ⊆ →, A×A ⊆ #, B×B ⊆ #
    4. Construct Petri net with places for each pair
    """
    dfg, start_acts, end_acts = discover_dfg(log, activity_key, timestamp_key, case_id_key)

    # All activities
    all_acts: Set[str] = set()
    for (a, b) in dfg:
        all_acts.add(a)
        all_acts.add(b)
    all_acts.update(start_acts.keys())
    all_acts.update(end_acts.keys())

    # Build relation sets
    directly_follows: Set[Tuple[str, str]] = set(dfg.keys())

    causality: Set[Tuple[str, str]] = set()
    parallel: Set[Tuple[str, str]] = set()
    unrelated: Set[Tuple[str, str]] = set()

    for a in all_acts:
        for b in all_acts:
            ab = (a, b) in directly_follows
            ba = (b, a) in directly_follows
            if ab and not ba:
                causality.add((a, b))
            elif ab and ba:
                parallel.add((a, b))
            elif not ab and not ba:
                unrelated.add((a, b))

    def _initial_filter(a: str, b: str) -> bool:
        return (a, a) not in parallel and (b, b) not in parallel

    def _check_is_unrelated(
        item_set_1: FrozenSet[str],
        item_set_2: FrozenSet[str],
    ) -> bool:
        for a in item_set_1:
            for b in item_set_2:
                if (a, b) in parallel or (a, b) in causality or (b, a) in causality:
                    return True
        return False

    def _check_all_causal(
        item_set_1: FrozenSet[str],
        item_set_2: FrozenSet[str],
    ) -> bool:
        for a in item_set_1:
            for b in item_set_2:
                if (a, b) not in causality:
                    return False
        return True

    def _pair_is_maximal(
        pair: Tuple[FrozenSet[str], FrozenSet[str]],
        candidates: list[Tuple[FrozenSet[str], FrozenSet[str]]],
    ) -> bool:
        a1, b1 = pair
        for a2, b2 in candidates:
            if (a1, b1) != (a2, b2) and a1.issubset(a2) and b1.issubset(b2):
                return False
        return True

    # Same candidate expansion strategy used by the classic alpha miner,
    # but on top of the pl4pm DFG abstraction.
    pairs: list[Tuple[FrozenSet[str], FrozenSet[str]]] = [
        (frozenset((a,)), frozenset((b,)))
        for (a, b) in sorted(causality)
        if _initial_filter(a, b)
    ]
    pair_set = set(pairs)

    i = 0
    while i < len(pairs):
        a1, b1 = pairs[i]
        for j in range(i, len(pairs)):
            a2, b2 = pairs[j]
            if (a1, b1) == (a2, b2):
                continue
            if a1.issubset(a2) or b1.issubset(b2):
                if not (
                    _check_is_unrelated(a1, a2)
                    or _check_is_unrelated(b1, b2)
                ):
                    merged = (frozenset(a1 | a2), frozenset(b1 | b2))
                    if merged not in pair_set and _check_all_causal(merged[0], merged[1]):
                        pair_set.add(merged)
                        pairs.append(merged)
        i += 1

    maximal_pairs = [pair for pair in pairs if _pair_is_maximal(pair, pairs)]

    # Build Petri net
    net = PetriNet("alpha_net")
    source = PetriNet.Place("source")
    sink = PetriNet.Place("sink")
    net.places.add(source)
    net.places.add(sink)

    # Transitions
    trans_map: Dict[str, PetriNet.Transition] = {}
    for act in all_acts:
        t = PetriNet.Transition(f"t_{act}", label=act)
        net.transitions.add(t)
        trans_map[act] = t

    # Start / end arcs
    for act in start_acts:
        add_arc_from_to(source, trans_map[act], net)
    for act in end_acts:
        add_arc_from_to(trans_map[act], sink, net)

    # Place for each maximal pair
    for idx, (A, B) in enumerate(maximal_pairs):
        p = PetriNet.Place(f"p({','.join(sorted(A))}),({','.join(sorted(B))})")
        net.places.add(p)
        for a in A:
            add_arc_from_to(trans_map[a], p, net)
        for b in B:
            add_arc_from_to(p, trans_map[b], net)

    im = Marking({source: 1})
    fm = Marking({sink: 1})
    return net, im, fm
