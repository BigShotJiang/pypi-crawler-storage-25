"""Transition system discovery aligned with pm4py.

Key design decisions
--------------------
* **No trace deduplication**: pm4py iterates every case individually; the
  resulting sets of states / transitions are identical because the Transition
  object's __eq__/__hash__ deduplicates by (name, from_state, to_state).
  We mirror this behaviour.
* **Polars-native trace extraction**: we avoid ``maintain_order=True`` (O(n²)
  memory footprint) by relying on a prior sort, then using the default
  hash-based ``group_by``.
* **Batch processing**: traces are yielded from Polars in chunks so the Python
  heap never holds more than one batch at a time, preventing OOM on large logs.
"""

from __future__ import annotations

import collections
from typing import Iterable

import polars as pl

from pl4pm.constants import ACTIVITY_KEY, CASE_ID_KEY, TIMESTAMP_KEY
from pl4pm.objects.transition_system import TransitionSystem

# How many cases to fetch from Polars per Python iteration.
# 50 000 is a sweet spot: low memory overhead, negligible call overhead.
_BATCH_SIZE = 50_000


def _apply_abstr(seq: list[str], view: str) -> str:
    """Return a state-name string identical to pm4py's ``__apply_abstr``."""
    if view == "multiset":
        return str(collections.Counter(seq))
    if view == "set":
        return str(set(seq))
    # "sequence" (default) — pm4py returns list(seq)
    return str(list(seq))


def _compute_view_sequence(
    trace: tuple[str, ...],
    direction: str,
    window: int,
    view: str,
) -> list[tuple[str, str | None]]:
    """Mirrors pm4py ``__compute_view_sequence`` → list of (state_name, event|None)."""
    result: list[tuple[str, str | None]] = []
    n = len(trace)
    for i in range(n + 1):
        if direction == "forward":
            state = _apply_abstr(list(trace[i : i + window]), view)
        else:
            state = _apply_abstr(list(trace[max(0, i - window) : i]), view)
        event: str | None = trace[i] if i < n else None
        result.append((state, event))
    return result


def _iter_all_traces_batched(
    log: pl.LazyFrame,
    activity_key: str,
    timestamp_key: str,
    case_id_key: str,
    batch_size: int = _BATCH_SIZE,
) -> Iterable[tuple[str, ...]]:
    """
    Yield one trace per case without deduplication (pm4py semantics).

    Fetches traces in batches to avoid materialising the entire trace list in
    the Python heap.
    """
    # Build a sorted base frame
    source = log if isinstance(log, pl.LazyFrame) else log.lazy()

    # Collect only the two columns we need, sorted, then group by case
    all_traces: list[list[str]] = (
        source
        .select([case_id_key, activity_key, timestamp_key])
        .sort([case_id_key, timestamp_key])
        .group_by(case_id_key)          # hash-based, O(n) memory
        .agg(pl.col(activity_key).alias("_trace"))
        .select("_trace")
        .collect()
        .get_column("_trace")
        .to_list()
    )

    for trace in all_traces:
        yield tuple(trace)


def discover_transition_system(
    log: pl.LazyFrame,
    direction: str = "forward",
    window: int = 2,
    view: str = "sequence",
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
) -> TransitionSystem:
    """Discover a transition system compatible with pm4py.

    Semantics
    ---------
    * All cases are iterated; duplicate (variant-equivalent) traces produce the
      same states/transitions and are naturally collapsed by the set-based
      deduplication via ``transition_set``.
    * O(1) state and transition lookup via dicts — avoids pm4py's O(|states|)
      linear scan in ``__construct_state_path``.
    """
    ts = TransitionSystem("transition_system")
    state_map: dict[str, TransitionSystem.State] = {}
    transition_set: set[tuple[str, str, str]] = set()

    def get_state(name: str) -> TransitionSystem.State:
        s = state_map.get(name)
        if s is None:
            s = TransitionSystem.State(name)
            state_map[name] = s
            ts.add_state(s)
        return s

    for trace in _iter_all_traces_batched(
        log, activity_key, timestamp_key, case_id_key
    ):
        view_seq = _compute_view_sequence(trace, direction, window, view)
        for i in range(len(view_seq) - 1):
            src_name, t_name = view_seq[i]
            tgt_name, _ = view_seq[i + 1]
            if t_name is None:
                continue

            key = (src_name, t_name, tgt_name)
            if key in transition_set:
                continue  # state objects already registered when key was first seen

            transition_set.add(key)
            src_s = get_state(src_name)
            tgt_s = get_state(tgt_name)
            ts.add_transition(TransitionSystem.Transition(t_name, src_s, tgt_s))

    return ts
