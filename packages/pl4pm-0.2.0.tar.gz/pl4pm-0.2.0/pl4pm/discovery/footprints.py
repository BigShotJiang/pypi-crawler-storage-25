"""pl4pm.discovery.footprints — Footprint matrix discovery."""

from __future__ import annotations

from typing import Any, Dict, Set, Tuple

import polars as pl

from pl4pm.constants import CASE_ID_KEY, ACTIVITY_KEY, TIMESTAMP_KEY
from pl4pm.discovery.dfg import discover_dfg
from pl4pm.objects.petri_net import PetriNet, Marking
from pl4pm.objects.process_tree import ProcessTree


def discover_footprints(
    *args,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
) -> Dict[str, Any]:
    """Discover footprints from a log or model.

    Returns a dict with keys:
        - "activities": set of activities
        - "sequence": set of (a,b) meaning a→b (causality)
        - "parallel": set of (a,b) meaning a||b
        - "activities_always_happening": activities in all traces
    """
    if len(args) == 1:
        obj = args[0]
        if isinstance(obj, ProcessTree):
            return _footprints_from_tree(obj)
        if isinstance(obj, (pl.DataFrame, pl.LazyFrame)):
            return _footprints_from_log(obj, activity_key, timestamp_key, case_id_key)
    if len(args) == 3:
        net, im, fm = args
        if isinstance(net, PetriNet):
            return _footprints_from_pn(net, im, fm)
        # pm4py's PetriNet from pm4py.convert — duck-type check
        if type(net).__name__ == "PetriNet" and hasattr(net, "transitions") and hasattr(net, "places"):
            return _footprints_from_pn(net, im, fm)
    raise TypeError(f"Cannot compute footprints from {[type(a).__name__ for a in args]}")


def _footprints_from_log(
    log: pl.LazyFrame,
    activity_key: str,
    timestamp_key: str,
    case_id_key: str,
) -> Dict[str, Any]:
    dfg, start_acts, end_acts = discover_dfg(log, activity_key, timestamp_key, case_id_key)

    all_acts: Set[str] = set()
    for (a, b) in dfg:
        all_acts.add(a)
        all_acts.add(b)
    all_acts.update(start_acts.keys())
    all_acts.update(end_acts.keys())

    parallel: Set[Tuple[str, str]] = {(a, b) for (a, b) in dfg if (b, a) in dfg}
    sequence: Set[Tuple[str, str]] = {(a, b) for (a, b) in dfg if (b, a) not in dfg}

    trace_lengths = (
        log.group_by(case_id_key).agg(pl.len().alias("_trace_length")).select(pl.col("_trace_length").min()).collect()
        if isinstance(log, pl.LazyFrame)
        else log.lazy().group_by(case_id_key).agg(pl.len().alias("_trace_length")).select(pl.col("_trace_length").min()).collect()
    )
    min_trace_length = int(trace_lengths.item()) if trace_lengths.height > 0 and trace_lengths.item() is not None else 0

    return {
        "activities": all_acts,
        "dfg": dfg,
        "sequence": sequence,
        "parallel": parallel,
        "start_activities": set(start_acts.keys()),
        "end_activities": set(end_acts.keys()),
        "min_trace_length": min_trace_length,
    }


def _footprints_from_pn(
    net, im, fm,
) -> Dict[str, Any]:
    """Derive footprints from Petri net structure.

    Uses BFS reachability through silent transitions to compute the
    full follows relation, matching pm4py's approach.
    """
    visible = {t for t in net.transitions if t.label}
    acts = {t.label for t in visible}

    # For each visible transition, find which visible transitions can follow it
    # by traversing output places → (silent transitions)* → visible transition
    follows: Set[Tuple[str, str]] = set()

    for src_t in visible:
        # BFS: start from output places of src_t
        visited_places: set = set()
        queue = []
        for arc in src_t.out_arcs:
            p = arc.target
            if p not in visited_places:
                visited_places.add(p)
                queue.append(p)

        while queue:
            place = queue.pop()
            for arc in place.out_arcs:
                next_t = arc.target
                if next_t.label:
                    # Found a visible transition reachable from src_t
                    follows.add((src_t.label, next_t.label))
                else:
                    # Silent transition — continue through its output places
                    for out_arc in next_t.out_arcs:
                        next_p = out_arc.target
                        if next_p not in visited_places:
                            visited_places.add(next_p)
                            queue.append(next_p)

    # Classify: if a→b AND b→a both exist → parallel; only a→b → sequence
    sequence: Set[Tuple[str, str]] = set()
    parallel: Set[Tuple[str, str]] = set()
    for a in acts:
        for b in acts:
            ab = (a, b) in follows
            ba = (b, a) in follows
            if ab and not ba:
                sequence.add((a, b))
            elif ab and ba:
                parallel.add((a, b))

    return {
        "activities": acts,
        "sequence": sequence,
        "parallel": parallel,
        "activities_always_happening": set(),
    }


def _footprints_from_tree(tree: ProcessTree) -> Dict[str, Any]:
    """Derive footprints from a process tree."""
    from pl4pm.convert.to_petri_net import convert_to_petri_net
    net, im, fm = convert_to_petri_net(tree)
    return _footprints_from_pn(net, im, fm)
