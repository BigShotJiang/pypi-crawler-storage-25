"""Log skeleton discovery aligned with pm4py."""

from __future__ import annotations

from collections import Counter
from typing import Any

import polars as pl

from pl4pm.constants import ACTIVITY_KEY, CASE_ID_KEY, TIMESTAMP_KEY


def _equivalence(trace: tuple[str, ...]) -> Counter[tuple[str, str]]:
    freq = Counter(trace)
    ret: Counter[tuple[str, str]] = Counter()
    for x, fx in freq.items():
        for y, fy in freq.items():
            if x != y and fx == fy:
                ret[(x, y)] += fx
    return ret


def _after(trace: tuple[str, ...]) -> set[tuple[str, str]]:
    return {(trace[i], trace[j]) for i in range(len(trace)) for j in range(i + 1, len(trace))}


def _before(trace: tuple[str, ...]) -> set[tuple[str, str]]:
    return {(trace[i], trace[j]) for i in range(len(trace)) for j in range(i) if j < i}


def _combos(trace: tuple[str, ...]) -> set[tuple[str, str]]:
    return {(x, y) for x in trace for y in trace if x != y}


def _directly_follows(trace: tuple[str, ...]) -> Counter[tuple[str, str]]:
    return Counter((trace[i], trace[i + 1]) for i in range(len(trace) - 1))


def _activ_freq(trace: tuple[str, ...]) -> Counter[str]:
    return Counter(trace)


def _build_variant_statistics(
    log: pl.LazyFrame,
    activity_key: str,
    timestamp_key: str,
    case_id_key: str,
) -> tuple[Counter[tuple[str, ...]], Counter[str], int]:
    source = log if isinstance(log, pl.LazyFrame) else log.lazy()

    traces = (
        source
        .sort([case_id_key, timestamp_key])
        .group_by(case_id_key, maintain_order=True)
        .agg(pl.col(activity_key).alias("_trace"))
        .select("_trace")
        .collect()
    )
    logs_traces: Counter[tuple[str, ...]] = Counter(tuple(trace) for trace in traces.get_column("_trace").to_list())

    activ_counts_df = source.group_by(activity_key).len().collect()
    all_activs = Counter(
        {
            str(activity): int(count)
            for activity, count in activ_counts_df.iter_rows()
        }
    )

    events_count = int(source.select(pl.len()).collect().item())
    return logs_traces, all_activs, events_count


def _equivalence_relations(
    logs_traces: Counter[tuple[str, ...]],
    all_activs: Counter[str],
    noise_threshold: float,
) -> set[tuple[str, str]]:
    ret0: Counter[tuple[str, str]] = Counter()
    for trace, freq in logs_traces.items():
        rs = _equivalence(trace)
        for key in list(rs):
            rs[key] *= freq
        ret0 += rs
    return {pair for pair, count in ret0.items() if count >= all_activs[pair[0]] * (1.0 - noise_threshold)}


def _always_after_relations(
    logs_traces: Counter[tuple[str, ...]],
    noise_threshold: float,
) -> set[tuple[str, str]]:
    traces_with_a: Counter[str] = Counter()
    traces_with_a_then_b: Counter[tuple[str, str]] = Counter()

    for trace, freq in logs_traces.items():
        for act in trace:
            traces_with_a[act] += freq
        for pair in _after(trace):
            traces_with_a_then_b[pair] += freq

    return {
        pair
        for pair, count in traces_with_a_then_b.items()
        if count >= traces_with_a[pair[0]] * (1.0 - noise_threshold)
    }


def _always_before_relations(
    logs_traces: Counter[tuple[str, ...]],
    noise_threshold: float,
) -> set[tuple[str, str]]:
    traces_with_a: Counter[str] = Counter()
    traces_with_a_then_b: Counter[tuple[str, str]] = Counter()

    for trace, freq in logs_traces.items():
        for act in trace:
            traces_with_a[act] += freq
        for pair in _before(trace):
            traces_with_a_then_b[pair] += freq

    return {
        pair
        for pair, count in traces_with_a_then_b.items()
        if count >= traces_with_a[pair[0]] * (1.0 - noise_threshold)
    }


def _never_together_relations(
    logs_traces: Counter[tuple[str, ...]],
    all_activs: Counter[str],
    noise_threshold: float,
) -> set[tuple[str, str]]:
    all_combos = {(x, y) for x in all_activs for y in all_activs if x != y}
    ret0: Counter[tuple[str, str]] = Counter({pair: all_activs[pair[0]] for pair in all_combos})
    for trace, freq in logs_traces.items():
        rs = Counter(_combos(trace))
        for key in list(rs):
            rs[key] *= freq
        ret0 -= rs
    return {pair for pair, count in ret0.items() if count >= all_activs[pair[0]] * (1.0 - noise_threshold)}


def _directly_follows_relations(
    logs_traces: Counter[tuple[str, ...]],
    all_activs: Counter[str],
    noise_threshold: float,
) -> set[tuple[str, str]]:
    ret0: Counter[tuple[str, str]] = Counter()
    for trace, freq in logs_traces.items():
        rs = _directly_follows(trace)
        for key in list(rs):
            rs[key] *= freq
        ret0 += rs
    return {pair for pair, count in ret0.items() if count >= all_activs[pair[0]] * (1.0 - noise_threshold)}


def _activity_frequencies(
    logs_traces: Counter[tuple[str, ...]],
    all_activs: Counter[str],
    events_count: int,
    noise_threshold: float,
) -> dict[str, set[int]]:
    ret0: dict[str, Counter[int]] = {}
    ret: dict[str, set[int]] = {}

    for trace, freq in logs_traces.items():
        rs = _activ_freq(trace)
        for act in all_activs:
            rs.setdefault(act, 0)
        for act, value in rs.items():
            ret0.setdefault(act, Counter())
            ret0[act][value] += freq

    threshold = (1.0 - noise_threshold) * events_count
    for act, counts in ret0.items():
        ranked = sorted(counts.items(), key=lambda item: item[1], reverse=True)
        added = 0
        i = 0
        while i < len(ranked):
            added += ranked[i][1]
            if added >= threshold:
                ranked = ranked[: min(i + 1, len(ranked))]
            i += 1
        ret[act] = {value for value, _ in ranked}

    return ret


def discover_log_skeleton(
    log: pl.LazyFrame,
    noise_threshold: float = 0.0,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
) -> dict[str, Any]:
    """Discover a log skeleton matching pm4py's classic variant."""

    logs_traces, all_activs, events_count = _build_variant_statistics(log, activity_key, timestamp_key, case_id_key)

    return {
        "equivalence": _equivalence_relations(logs_traces, all_activs, noise_threshold),
        "always_after": _always_after_relations(logs_traces, noise_threshold),
        "always_before": _always_before_relations(logs_traces, noise_threshold),
        "never_together": _never_together_relations(logs_traces, all_activs, noise_threshold),
        "directly_follows": _directly_follows_relations(logs_traces, all_activs, noise_threshold),
        "activ_freq": _activity_frequencies(logs_traces, all_activs, events_count, noise_threshold),
    }
