"""Batch detection aligned with pm4py, implemented on top of Polars."""

from __future__ import annotations

from typing import Any

import polars as pl

from pl4pm.constants import ACTIVITY_KEY, CASE_ID_KEY, RESOURCE_KEY, TIMESTAMP_KEY


SIMULTANEOUS = "Simultaneous"
BATCHING_START = "Batching on Start"
BATCHING_END = "Batching on End"
SEQUENTIAL = "Sequential batching"
CONCURRENT = "Concurrent batching"
EventTuple = tuple[float, float, str, int]
BatchTuple = tuple[float, float, set[EventTuple]]
InternalBatchTuple = tuple[float, float, list[EventTuple]]


def _timestamp_to_pm_seconds(dtype: pl.DataType) -> pl.Expr:
    if dtype == pl.Datetime("ns"):
        return pl.col("_start_raw").dt.epoch("ns") / 1_000_000_000
    return pl.col("_start_raw").dt.epoch("us") / 1_000_000_000


def _classify_batch(events_batch: list[EventTuple]) -> str:
    events_batch = sorted(events_batch)
    min_left = min(event[0] for event in events_batch)
    max_left = max(event[0] for event in events_batch)
    min_right = min(event[1] for event in events_batch)
    max_right = max(event[1] for event in events_batch)

    if min_left == max_left and min_right == max_right:
        return SIMULTANEOUS
    if min_left == max_left:
        return BATCHING_START
    if min_right == max_right:
        return BATCHING_END

    for index in range(len(events_batch) - 1):
        if events_batch[index][1] != events_batch[index + 1][0]:
            return CONCURRENT
    return SEQUENTIAL


def _merge_overlapping(intervals: list[InternalBatchTuple]) -> list[InternalBatchTuple]:
    if not intervals:
        return intervals
    intervals.sort(key=lambda item: (item[0], item[1]))
    merged: list[InternalBatchTuple] = [intervals[0]]
    for start, end, events in intervals[1:]:
        last_start, last_end, last_events = merged[-1]
        if last_end > start:
            merged[-1] = (
                min(last_start, start),
                max(last_end, end),
                last_events + events,
            )
        else:
            merged.append((start, end, events))
    return merged


def _merge_near(intervals: list[InternalBatchTuple], max_allowed_distance: float) -> list[InternalBatchTuple]:
    if not intervals:
        return intervals
    intervals.sort(key=lambda item: (item[0], item[1]))
    merged: list[InternalBatchTuple] = [intervals[0]]
    for start, end, events in intervals[1:]:
        last_start, last_end, last_events = merged[-1]
        if start - last_end <= max_allowed_distance:
            merged[-1] = (
                min(last_start, start),
                max(last_end, end),
                last_events + events,
            )
        else:
            merged.append((start, end, events))
    return merged


def _detect_single(
    events: list[EventTuple],
    merge_distance: float,
    min_batch_size: int,
) -> dict[str, list[BatchTuple]]:
    ret = {
        SIMULTANEOUS: [],
        BATCHING_START: [],
        BATCHING_END: [],
        CONCURRENT: [],
        SEQUENTIAL: [],
    }

    intervals: list[InternalBatchTuple] = [(event[0], event[1], [event]) for event in sorted(events)]
    intervals = _merge_overlapping(intervals)
    intervals = _merge_near(intervals, merge_distance)
    batches = [interval for interval in intervals if len(interval[2]) >= min_batch_size]

    for start, end, batch_events in batches:
        ret[_classify_batch(batch_events)].append((start, end, set(batch_events)))

    return {key: value for key, value in ret.items() if value}


def discover_batches(
    log: pl.LazyFrame,
    merge_distance: int = 900,
    min_batch_size: int = 2,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
    resource_key: str = RESOURCE_KEY,
) -> list[tuple[tuple[str, str], int, dict[str, Any]]]:
    """Discover batches, matching pm4py's output structure."""

    source = log if isinstance(log, pl.LazyFrame) else log.lazy()
    schema = log.schema if isinstance(log, pl.DataFrame) else log.collect_schema()
    if resource_key not in schema:
        return []

    prepared = (
        source
        .with_row_index("_event_id")
        .with_columns(pl.col(case_id_key).cast(pl.Utf8).alias("_case_id"))
        .with_columns(pl.col(timestamp_key).alias("_start_raw"))
        .with_columns(_timestamp_to_pm_seconds(schema[timestamp_key]).alias("_ts_seconds"))
        .group_by([activity_key, resource_key], maintain_order=False)
        .agg(
            [
                pl.col("_ts_seconds").alias("_start_list"),
                pl.col("_ts_seconds").alias("_end_list"),
                pl.col("_case_id").alias("_case_list"),
                pl.col("_event_id").alias("_event_list"),
            ]
        )
        .collect()
    )

    results: list[tuple[tuple[str, str], int, dict[str, Any]]] = []
    for activity, resource, starts, ends, cases, event_ids in prepared.iter_rows():
        events = list(zip(starts, ends, cases, event_ids, strict=True))
        batches = _detect_single(events, float(merge_distance), min_batch_size)
        if batches:
            total_length = sum(len(value) for value in batches.values())
            results.append(((activity, resource), total_length, batches))

    results.sort(key=lambda item: (item[1], item[0]), reverse=True)
    return results
