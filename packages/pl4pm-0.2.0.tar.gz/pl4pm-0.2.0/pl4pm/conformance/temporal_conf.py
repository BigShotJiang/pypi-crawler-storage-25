"""pl4pm.conformance.temporal_conf — Temporal profile conformance checking."""

from __future__ import annotations

from typing import Any, Dict, List, Tuple

import polars as pl

from pl4pm.constants import CASE_ID_KEY, ACTIVITY_KEY, TIMESTAMP_KEY


def conformance_temporal_profile(
    log: pl.LazyFrame,
    temporal_profile: Dict[Tuple[str, str], Tuple[float, float]],
    zeta: float = 1.0,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
    return_diagnostics_dataframe: bool = False,
) -> list:
    """Conformance checking using temporal profile.

    For each case, returns list of (diff, mean, std, zeta_threshold) tuples
    for every eventually-follows pair that deviates.
    """
    df = log.collect() if isinstance(log, pl.LazyFrame) else log
    df = df.sort([case_id_key, timestamp_key])

    results: List[List[Tuple[float, float, float, float]]] = []

    for _, group in df.group_by(case_id_key, maintain_order=True):
        acts = group[activity_key].to_list()
        timestamps = group[timestamp_key].to_list()
        n = len(acts)
        deviations: List[Tuple[float, float, float, float]] = []

        for i in range(n):
            for j in range(i + 1, n):
                pair = (acts[i], acts[j])
                if pair in temporal_profile:
                    mean, std = temporal_profile[pair]
                    actual = (timestamps[j] - timestamps[i]).total_seconds()
                    threshold = mean + zeta * std
                    lower = mean - zeta * std

                    if actual > threshold or actual < lower:
                        deviations.append((actual, mean, std, zeta))

        results.append(deviations)

    if return_diagnostics_dataframe:
        rows = []
        for i, devs in enumerate(results):
            rows.append({
                "case_index": i,
                "n_deviations": len(devs),
                "is_fit": len(devs) == 0,
            })
        return pl.DataFrame(rows)

    return results
