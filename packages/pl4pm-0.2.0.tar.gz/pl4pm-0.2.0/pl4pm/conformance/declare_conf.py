"""pl4pm.conformance.declare_conf — DECLARE model conformance checking."""

from __future__ import annotations

from typing import Any, Dict, List, Set, Tuple

import polars as pl

from pl4pm.constants import CASE_ID_KEY, ACTIVITY_KEY, TIMESTAMP_KEY


def conformance_declare(
    log: pl.LazyFrame,
    declare_model: Dict[str, Dict[Any, Dict[str, int]]],
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
    return_diagnostics_dataframe: bool = False,
) -> list:
    """Conformance checking against a DECLARE model."""
    df = log.collect() if isinstance(log, pl.LazyFrame) else log
    df = df.sort([case_id_key, timestamp_key])

    results: List[Dict[str, Any]] = []

    for _, group in df.group_by(case_id_key, maintain_order=True):
        acts = group[activity_key].to_list()
        acts_set = set(acts)
        deviations: List[Dict[str, Any]] = []

        # Check each template
        for template_name, constraints in declare_model.items():
            for key, details in constraints.items():
                violation = _check_constraint(template_name, key, acts, acts_set)
                if violation:
                    deviations.append({
                        "template": template_name,
                        "constraint": key,
                        "violation": violation,
                    })

        results.append({
            "is_fit": len(deviations) == 0,
            "deviations": deviations,
            "n_violations": len(deviations),
        })

    if return_diagnostics_dataframe:
        rows = []
        for i, d in enumerate(results):
            rows.append({
                "case_index": i,
                "is_fit": d["is_fit"],
                "n_violations": d["n_violations"],
            })
        return pl.DataFrame(rows)

    return results


def _check_constraint(
    template: str, key: Any, acts: list, acts_set: set,
) -> str | None:
    """Check a single DECLARE constraint. Returns violation description or None."""
    if template == "existence":
        # key = activity, must exist
        if key not in acts_set:
            return f"Activity {key} not found"

    elif template == "init":
        if acts and acts[0] != key:
            return f"Trace does not start with {key}"

    elif template == "end":
        if acts and acts[-1] != key:
            return f"Trace does not end with {key}"

    elif template == "responded_existence":
        a, b = key
        if a in acts_set and b not in acts_set:
            return f"{b} not present when {a} is"

    elif template == "response":
        a, b = key
        if a in acts_set:
            last_a = len(acts) - 1 - acts[::-1].index(a)
            if b not in acts[last_a:]:
                return f"{b} does not follow last occurrence of {a}"

    elif template == "precedence":
        a, b = key
        if b in acts_set:
            first_b = acts.index(b)
            if a not in acts[:first_b]:
                return f"{a} does not precede first {b}"

    elif template == "co_existence":
        a, b = key
        if (a in acts_set) != (b in acts_set):
            return f"{a} and {b} should co-exist"

    elif template == "not_co_existence":
        a, b = key
        if a in acts_set and b in acts_set:
            return f"{a} and {b} should not co-exist"

    return None
