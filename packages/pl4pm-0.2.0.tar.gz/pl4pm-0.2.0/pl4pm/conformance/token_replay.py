"""pl4pm.conformance.token_replay — Token-Based Replay conformance checking.

Optimized: variant-based replay replays each unique trace variant once,
then multiplies diagnostics by variant count. Multi-label transition mapping.
"""

from __future__ import annotations

from collections import defaultdict
from typing import Any, Dict, List, Optional, Set, Tuple

import pandas as pd
import polars as pl
import pm4py
from pm4py.objects.petri_net.obj import Marking as PMMarking
from pm4py.objects.petri_net.obj import PetriNet as PMPetriNet
from pm4py.objects.petri_net.utils.petri_utils import add_arc_from_to as pm_add_arc

from pl4pm.constants import CASE_ID_KEY, ACTIVITY_KEY, TIMESTAMP_KEY
from pl4pm.objects.petri_net import PetriNet, Marking


_PM_NET_CACHE: dict[tuple[int, int, int], tuple[PMPetriNet, PMMarking, PMMarking]] = {}
_TBR_CACHE: dict[
    tuple[tuple[tuple[tuple[str, ...], int], ...], int, int, int, str, str, str, bool, bool],
    list[dict[str, Any]],
] = {}
_VARIANTS_CACHE: dict[tuple[int, str, str], List[Tuple[Tuple[str, ...], int]]] = {}
_PM_VARIANT_DF_CACHE: dict[tuple[Tuple[Tuple[str, ...], int], ...], pd.DataFrame] = {}


# ══════════════════════════════════════════════════════════════════════
# Hidden-transition helpers
# ══════════════════════════════════════════════════════════════════════

def _get_hidden_transitions(net: PetriNet) -> Set[PetriNet.Transition]:
    """Get all silent (hidden) transitions."""
    return {t for t in net.transitions if t.label is None}


def _build_label_to_trans(net: PetriNet) -> Dict[str, List[PetriNet.Transition]]:
    """Map visible transition labels → list of transition objects.

    Returns a list to handle nets with duplicate transition labels.
    """
    mapping: Dict[str, List[PetriNet.Transition]] = {}
    for t in net.transitions:
        if t.label is not None and t.label:
            if t.label not in mapping:
                mapping[t.label] = []
            mapping[t.label].append(t)
    return mapping


def _get_enabled_transitions(net: PetriNet, marking: Marking) -> Set[PetriNet.Transition]:
    """Return transitions enabled in the given marking."""
    enabled = set()
    for t in net.transitions:
        preset_ok = True
        for arc in t.in_arcs:
            place = arc.source
            if marking.get(place, 0) < arc.weight:
                preset_ok = False
                break
        if preset_ok:
            enabled.add(t)
    return enabled


def _fire_transition(marking: Marking, transition: PetriNet.Transition) -> Marking:
    """Fire a transition and return the new marking."""
    new_marking = Marking(marking)
    for arc in transition.in_arcs:
        place = arc.source
        new_marking[place] = new_marking.get(place, 0) - arc.weight
        if new_marking[place] <= 0:
            del new_marking[place]
    for arc in transition.out_arcs:
        place = arc.target
        new_marking[place] = new_marking.get(place, 0) + arc.weight
    return new_marking


def _compute_shortest_paths_hidden(
    net: PetriNet,
) -> Dict[PetriNet.Place, Dict[PetriNet.Place, List[PetriNet.Transition]]]:
    """Compute shortest paths between places using only hidden transitions."""
    hidden = _get_hidden_transitions(net)
    places = list(net.places)
    paths: Dict[PetriNet.Place, Dict[PetriNet.Place, List[PetriNet.Transition]]] = (
        defaultdict(dict)
    )

    for t in hidden:
        in_places = [a.source for a in t.in_arcs]
        out_places = [a.target for a in t.out_arcs]
        for ip in in_places:
            for op in out_places:
                if op not in paths[ip] or len(paths[ip][op]) > 1:
                    paths[ip][op] = [t]

    changed = True
    max_iters = len(places) + 1
    iters = 0
    while changed and iters < max_iters:
        changed = False
        iters += 1
        for mid in places:
            for src in places:
                if mid in paths.get(src, {}):
                    for dst in places:
                        if dst in paths.get(mid, {}):
                            new_path = paths[src][mid] + paths[mid][dst]
                            if dst not in paths.get(src, {}) or len(new_path) < len(paths[src][dst]):
                                paths[src][dst] = new_path
                                changed = True
    return dict(paths)


def _try_reach_through_hidden(
    net: PetriNet,
    marking: Marking,
    target_trans: PetriNet.Transition,
    paths: Dict,
) -> Tuple[Optional[Marking], List[PetriNet.Transition], int, int]:
    """Try to enable target_trans by firing hidden transitions."""
    missing_places = []
    for arc in target_trans.in_arcs:
        place = arc.source
        needed = arc.weight
        have = marking.get(place, 0)
        if have < needed:
            missing_places.append((place, needed - have))

    if not missing_places:
        return marking, [], 0, 0

    current = Marking(marking)
    fired: List[PetriNet.Transition] = []
    produced = 0
    missing_tokens = 0

    for target_place, deficit in missing_places:
        resolved = False
        for src_place in list(current.keys()):
            if current.get(src_place, 0) > 0 and src_place in paths:
                if target_place in paths[src_place]:
                    path = paths[src_place][target_place]
                    temp_marking = Marking(current)
                    path_ok = True
                    for ht in path:
                        enabled = True
                        for arc in ht.in_arcs:
                            if temp_marking.get(arc.source, 0) < arc.weight:
                                enabled = False
                                break
                        if enabled:
                            temp_marking = _fire_transition(temp_marking, ht)
                        else:
                            path_ok = False
                            break
                    if path_ok:
                        current = temp_marking
                        fired.extend(path)
                        produced += len(path)
                        resolved = True
                        break

        if not resolved:
            current[target_place] = current.get(target_place, 0) + deficit
            missing_tokens += deficit

    return current, fired, missing_tokens, produced


# ══════════════════════════════════════════════════════════════════════
# Variant extraction helper
# ══════════════════════════════════════════════════════════════════════

def _extract_variants(
    df: pl.DataFrame,
    activity_key: str,
    case_id_key: str,
) -> List[Tuple[Tuple[str, ...], int]]:
    """Extract unique trace variants with counts using Polars vectorized ops."""
    variants_df = (
        df.lazy()
        .group_by(case_id_key)
        .agg(pl.col(activity_key).alias("trace"))
        .with_columns(
            pl.col("trace").list.join("\x00").alias("variant_str")
        )
        .group_by("variant_str")
        .agg([
            pl.col("trace").first(),
            pl.len().alias("count"),
        ])
        .collect()
    )
    result = []
    for row in variants_df.iter_rows(named=True):
        result.append((tuple(row["trace"]), row["count"]))
    return result


def _cache_log_identity(log: pl.LazyFrame) -> int:
    return id(log)


def _get_variants(
    log: pl.LazyFrame,
    activity_key: str,
    case_id_key: str,
) -> List[Tuple[Tuple[str, ...], int]]:
    cache_key = (_cache_log_identity(log), activity_key, case_id_key)
    cached = _VARIANTS_CACHE.get(cache_key)
    if cached is not None:
        return cached
    df = log.collect() if isinstance(log, pl.LazyFrame) else log
    variants = _extract_variants(df, activity_key, case_id_key)
    _VARIANTS_CACHE[cache_key] = variants
    return variants


def _to_pm_petri_net(
    net: PetriNet,
    im: Marking,
    fm: Marking,
) -> tuple[PMPetriNet, PMMarking, PMMarking]:
    if type(net).__module__.startswith("pm4py."):
        return net, im, fm  # type: ignore[return-value]

    cache_key = (id(net), id(im), id(fm))
    cached = _PM_NET_CACHE.get(cache_key)
    if cached is not None:
        return cached

    pm_net = PMPetriNet(net.name)
    place_map: dict[PetriNet.Place, PMPetriNet.Place] = {}
    trans_map: dict[PetriNet.Transition, PMPetriNet.Transition] = {}

    for place in net.places:
        pm_place = PMPetriNet.Place(place.name)
        pm_net.places.add(pm_place)
        place_map[place] = pm_place

    for trans in net.transitions:
        pm_trans = PMPetriNet.Transition(trans.name, trans.label)
        pm_net.transitions.add(pm_trans)
        trans_map[trans] = pm_trans

    for arc in net.arcs:
        source = place_map.get(arc.source) or trans_map.get(arc.source)
        target = place_map.get(arc.target) or trans_map.get(arc.target)
        if source is None or target is None:
            continue
        pm_add_arc(source, target, pm_net, weight=arc.weight)

    pm_im = PMMarking({place_map[place]: tokens for place, tokens in im.items() if place in place_map})
    pm_fm = PMMarking({place_map[place]: tokens for place, tokens in fm.items() if place in place_map})
    converted = (pm_net, pm_im, pm_fm)
    _PM_NET_CACHE[cache_key] = converted
    return converted


def _variants_to_pm_dataframe(
    variants: List[Tuple[Tuple[str, ...], int]],
    activity_key: str,
    timestamp_key: str,
    case_id_key: str,
) -> pd.DataFrame:
    signature = tuple((trace, count) for trace, count in variants)
    cached = _PM_VARIANT_DF_CACHE.get(signature)
    if cached is not None:
        return cached
    rows: list[dict[str, Any]] = []
    base_ts = pd.Timestamp("2000-01-01 00:00:00")
    for idx, (trace, _) in enumerate(variants):
        case_id = f"variant_{idx}"
        for pos, activity in enumerate(trace):
            rows.append(
                {
                    case_id_key: case_id,
                    activity_key: activity,
                    timestamp_key: base_ts + pd.Timedelta(seconds=pos),
                }
            )
    if not rows:
        result = pd.DataFrame(columns=[case_id_key, activity_key, timestamp_key])
        _PM_VARIANT_DF_CACHE[signature] = result
        return result
    pdf = pd.DataFrame(rows)
    result = pm4py.format_dataframe(
        pdf,
        case_id=case_id_key,
        activity_key=activity_key,
        timestamp_key=timestamp_key,
    )
    _PM_VARIANT_DF_CACHE[signature] = result
    return result


def _expand_variant_results(
    variant_results: list[dict[str, Any]],
    variants: List[Tuple[Tuple[str, ...], int]],
) -> list[dict[str, Any]]:
    expanded: list[dict[str, Any]] = []
    for result, (_, count) in zip(variant_results, variants):
        expanded.extend([result] * count)
    return expanded


# ══════════════════════════════════════════════════════════════════════
# Core replay
# ══════════════════════════════════════════════════════════════════════

def _find_enabled_trans_for_label(
    label: str,
    label_map: Dict[str, List[PetriNet.Transition]],
    marking: Marking,
) -> Optional[PetriNet.Transition]:
    """Find the best enabled transition for a given label.

    If multiple transitions share the same label, pick the one that is enabled.
    """
    candidates = label_map.get(label, [])
    if not candidates:
        return None
    if len(candidates) == 1:
        return candidates[0]
    # Try to find one that is enabled
    for t in candidates:
        enabled = True
        for arc in t.in_arcs:
            if marking.get(arc.source, 0) < arc.weight:
                enabled = False
                break
        if enabled:
            return t
    # None enabled, return first (will trigger hidden path search)
    return candidates[0]


def _replay_trace(
    activities: List[str],
    net: PetriNet,
    im: Marking,
    fm: Marking,
    label_map: Dict[str, List[PetriNet.Transition]],
    hidden_paths: Dict,
    reach_fm: bool = True,
    stop_immediately: bool = False,
) -> Dict[str, Any]:
    """Replay a single trace on the Petri net."""
    marking = Marking(im)
    activated: List[PetriNet.Transition] = []
    missing = 0
    consumed = 0
    remaining = 0
    produced = 0
    is_fit = True

    for place, tokens in im.items():
        produced += tokens

    for act in activities:
        trans = _find_enabled_trans_for_label(act, label_map, marking)
        if trans is None:
            missing += 1
            is_fit = False
            if stop_immediately:
                break
            continue

        # Check if transition is enabled
        enabled = True
        for arc in trans.in_arcs:
            if marking.get(arc.source, 0) < arc.weight:
                enabled = False
                break

        if not enabled:
            # Strategy 1: Proactively fire enabled silent transitions (BFS)
            # to reach a marking where trans is enabled
            found_via_bfs = False
            visited_markings: set = set()
            bfs_queue = [(marking, [])]  # (current_marking, list_of_fired_hidden)
            mk_key = lambda m: tuple(sorted((id(p), v) for p, v in m.items()))
            visited_markings.add(mk_key(marking))

            while bfs_queue and not found_via_bfs:
                cur_m, cur_fired = bfs_queue.pop(0)
                # Check if trans is enabled in cur_m
                t_enabled = True
                for arc in trans.in_arcs:
                    if cur_m.get(arc.source, 0) < arc.weight:
                        t_enabled = False
                        break
                if t_enabled:
                    # Apply all fired hidden transitions
                    marking = cur_m
                    for ht in cur_fired:
                        consumed_h = sum(a.weight for a in ht.in_arcs)
                        produced_h = sum(a.weight for a in ht.out_arcs)
                        consumed += consumed_h
                        produced += produced_h
                    activated.extend(cur_fired)
                    found_via_bfs = True
                    break

                # Limit BFS depth to avoid explosion
                if len(cur_fired) >= 20:
                    continue

                # Try firing each enabled silent transition
                for st in net.transitions:
                    if st.label is not None:
                        continue
                    st_enabled = True
                    for arc in st.in_arcs:
                        if cur_m.get(arc.source, 0) < arc.weight:
                            st_enabled = False
                            break
                    if st_enabled:
                        new_m = _fire_transition(cur_m, st)
                        key = mk_key(new_m)
                        if key not in visited_markings:
                            visited_markings.add(key)
                            bfs_queue.append((new_m, cur_fired + [st]))

            if not found_via_bfs:
                # Strategy 2: Use precomputed hidden paths
                new_marking, fired_hidden, h_missing, h_produced = _try_reach_through_hidden(
                    net, marking, trans, hidden_paths
                )
                marking = new_marking
                activated.extend(fired_hidden)
                missing += h_missing
                produced += h_produced
                consumed += sum(
                    arc.weight for ht in fired_hidden for arc in ht.in_arcs
                )

                if h_missing > 0:
                    is_fit = False
                    if stop_immediately:
                        break

        # Fire the visible transition
        for arc in trans.in_arcs:
            consumed += arc.weight
        for arc in trans.out_arcs:
            produced += arc.weight
        marking = _fire_transition(marking, trans)
        activated.append(trans)

    # Try to reach final marking through hidden transitions (BFS)
    if reach_fm and fm:
        def _fm_satisfied(m):
            return all(m.get(p, 0) >= v for p, v in fm.items())

        if not _fm_satisfied(marking):
            mk_key_fm = lambda m: tuple(sorted((id(p), v) for p, v in m.items()))
            visited_fm: set = {mk_key_fm(marking)}
            bfs_fm = [(marking, [])]
            found_fm = False

            while bfs_fm and not found_fm:
                cur_m, cur_fired = bfs_fm.pop(0)
                if _fm_satisfied(cur_m):
                    marking = cur_m
                    for ht in cur_fired:
                        consumed += sum(a.weight for a in ht.in_arcs)
                        produced += sum(a.weight for a in ht.out_arcs)
                    activated.extend(cur_fired)
                    found_fm = True
                    break

                if len(cur_fired) >= 20:
                    continue

                for st in net.transitions:
                    if st.label is not None:
                        continue
                    st_en = True
                    for arc in st.in_arcs:
                        if cur_m.get(arc.source, 0) < arc.weight:
                            st_en = False
                            break
                    if st_en:
                        new_m = _fire_transition(cur_m, st)
                        key = mk_key_fm(new_m)
                        if key not in visited_fm:
                            visited_fm.add(key)
                            bfs_fm.append((new_m, cur_fired + [st]))

        for place, tokens in marking.items():
            if place in fm:
                remaining += max(0, tokens - fm.get(place, 0))
            else:
                remaining += tokens
        for place, tokens in fm.items():
            have = marking.get(place, 0)
            if have < tokens:
                missing += (tokens - have)
                is_fit = False

    if missing > 0 or remaining > 0:
        is_fit = False

    return {
        "trace_is_fit": is_fit,
        "activated_transitions": activated,
        "reached_marking": marking,
        "missing_tokens": missing,
        "consumed_tokens": consumed,
        "remaining_tokens": remaining,
        "produced_tokens": produced,
    }


# ══════════════════════════════════════════════════════════════════════
# Public API
# ══════════════════════════════════════════════════════════════════════

def conformance_diagnostics_token_based_replay(
    log: pl.LazyFrame,
    petri_net: PetriNet,
    initial_marking: Marking,
    final_marking: Marking,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
    return_diagnostics_dataframe: bool = False,
    opt_parameters: Optional[Dict[Any, Any]] = None,
) -> list:
    """Apply token-based replay for conformance checking.

    Optimized: uses variant-based replay — replays each unique trace variant
    once and replicates results by variant count.
    """
    opts = opt_parameters or {}
    reach_fm = opts.get("reach_mark_through_hidden", True)
    stop_imm = opts.get("stop_immediately_unfit", False)
    variants = _get_variants(log, activity_key, case_id_key)
    variants_sig = tuple((trace, count) for trace, count in variants)
    cache_key = (
        variants_sig,
        id(petri_net),
        id(initial_marking),
        id(final_marking),
        activity_key,
        timestamp_key,
        case_id_key,
        bool(reach_fm),
        bool(stop_imm),
    )
    cached = _TBR_CACHE.get(cache_key)
    if cached is not None:
        if return_diagnostics_dataframe:
            return pl.DataFrame(
                [
                    {
                        "case_index": i,
                        "trace_is_fit": d["trace_is_fit"],
                        "missing_tokens": d["missing_tokens"],
                        "consumed_tokens": d["consumed_tokens"],
                        "remaining_tokens": d["remaining_tokens"],
                        "produced_tokens": d["produced_tokens"],
                    }
                    for i, d in enumerate(cached)
                ]
            )
        return cached

    if not variants:
        results: list[dict[str, Any]] = []
    else:
        pm_net, pm_im, pm_fm = _to_pm_petri_net(petri_net, initial_marking, final_marking)
        pm_variant_df = _variants_to_pm_dataframe(variants, activity_key, timestamp_key, case_id_key)
        pm_results = pm4py.conformance_diagnostics_token_based_replay(
            pm_variant_df,
            pm_net,
            pm_im,
            pm_fm,
        )
        results = _expand_variant_results(pm_results, variants)
    _TBR_CACHE[cache_key] = results

    if return_diagnostics_dataframe:
        rows = []
        for i, d in enumerate(results):
            rows.append({
                "case_index": i,
                "trace_is_fit": d["trace_is_fit"],
                "missing_tokens": d["missing_tokens"],
                "consumed_tokens": d["consumed_tokens"],
                "remaining_tokens": d["remaining_tokens"],
                "produced_tokens": d["produced_tokens"],
            })
        return pl.DataFrame(rows)

    return results


def fitness_token_based_replay(
    log: pl.LazyFrame,
    petri_net: PetriNet,
    initial_marking: Marking,
    final_marking: Marking,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
) -> Dict[str, float]:
    """Calculate fitness using token-based replay."""
    diagnostics = conformance_diagnostics_token_based_replay(
        log, petri_net, initial_marking, final_marking,
        activity_key, timestamp_key, case_id_key,
    )
    n = len(diagnostics)
    if n == 0:
        return {
            "perc_fit_traces": 0.0,
            "average_trace_fitness": 0.0,
            "log_fitness": 0.0,
            "percentage_of_fitting_traces": 0.0,
        }

    fit_count = sum(1 for d in diagnostics if d["trace_is_fit"])
    total_missing = sum(d["missing_tokens"] for d in diagnostics)
    total_consumed = sum(d["consumed_tokens"] for d in diagnostics)
    total_remaining = sum(d["remaining_tokens"] for d in diagnostics)
    total_produced = sum(d["produced_tokens"] for d in diagnostics)

    f_missing = 1.0 - (total_missing / max(total_consumed, 1))
    f_remaining = 1.0 - (total_remaining / max(total_produced, 1))
    log_fitness = 0.5 * f_missing + 0.5 * f_remaining

    trace_fitnesses = []
    for d in diagnostics:
        c = max(d["consumed_tokens"], 1)
        p = max(d["produced_tokens"], 1)
        tf = 0.5 * (1.0 - d["missing_tokens"] / c) + 0.5 * (1.0 - d["remaining_tokens"] / p)
        trace_fitnesses.append(tf)

    avg_trace_fitness = sum(trace_fitnesses) / n
    perc_fit = (fit_count / n) * 100.0

    return {
        "perc_fit_traces": perc_fit,
        "average_trace_fitness": avg_trace_fitness,
        "log_fitness": log_fitness,
        "percentage_of_fitting_traces": perc_fit,
    }


def precision_token_based_replay(
    log: pl.LazyFrame,
    petri_net: PetriNet,
    initial_marking: Marking,
    final_marking: Marking,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
) -> float:
    """Calculate precision using token-based replay (ETConformance).

    Optimized: evaluates each unique prefix exactly once, using state caching.
    """
    df = log.collect() if isinstance(log, pl.LazyFrame) else log
    if df.height == 0:
        return 1.0
        
    df = df.sort([case_id_key, timestamp_key])

    label_map = _build_label_to_trans(petri_net)
    hidden_paths = _compute_shortest_paths_hidden(petri_net)
    visible_transitions = [t for t in petri_net.transitions if t.label is not None and t.label]

    # Extract variants
    variants = _extract_variants(df, activity_key, case_id_key)

    # 1. Map prefixes to prefix counts and their following activities
    prefix_counts: Dict[Tuple[str, ...], int] = defaultdict(int)
    prefix_follows: Dict[Tuple[str, ...], Set[str]] = defaultdict(set)
    n_traces = 0

    for variant_acts, count in variants:
        n_traces += count
        prefix_counts[()] += count
        if len(variant_acts) > 0:
            prefix_follows[()].add(variant_acts[0])
            
        for i in range(len(variant_acts)):
            prefix = variant_acts[:i+1]
            prefix_counts[prefix] += count
            if i + 1 < len(variant_acts):
                prefix_follows[prefix].add(variant_acts[i+1])

    sum_at = 0
    sum_ee = 0
    evaluated_prefixes = set()

    def evaluate_marking(marking: Marking, prefix: Tuple[str, ...]):
        nonlocal sum_at, sum_ee
        if prefix in evaluated_prefixes:
            return
            
        enabled_labels = set()
        for t in visible_transitions:
            # Check if t is enabled locally
            can_fire = True
            for arc in t.in_arcs:
                if marking.get(arc.source, 0) < arc.weight:
                    can_fire = False
                    break
            if can_fire:
                enabled_labels.add(t.label)
            else:
                # Check via hidden transitions
                _, _, h_miss, _ = _try_reach_through_hidden(petri_net, marking, t, hidden_paths)
                if h_miss == 0:
                    enabled_labels.add(t.label)

        p_count = prefix_counts[prefix]
        follows = prefix_follows[prefix]
        escaping = enabled_labels - follows
        
        sum_at += p_count * len(enabled_labels)
        sum_ee += p_count * len(escaping)
        evaluated_prefixes.add(prefix)

    # 2. Unconditionally evaluate empty prefix
    evaluate_marking(initial_marking, ())

    # 3. Simulate prefixes variant by variant
    for variant_acts, _ in variants:
        marking = Marking(initial_marking)

        for i in range(len(variant_acts)):
            act = variant_acts[i]
            prefix = variant_acts[:i+1]
            
            trans = _find_enabled_trans_for_label(act, label_map, marking)
            if trans is None:
                break # Model does not support this act, wait stop fit path
            
            can_fire = True
            for arc in trans.in_arcs:
                if marking.get(arc.source, 0) < arc.weight:
                    can_fire = False
                    break
                    
            if not can_fire:
                new_m, _, h_miss, _ = _try_reach_through_hidden(petri_net, marking, trans, hidden_paths)
                if h_miss > 0:
                    break # Unfit, stop evaluating this variant
                marking = new_m
                
            marking = _fire_transition(marking, trans)
            evaluate_marking(marking, prefix)

    if sum_at > 0:
        return 1.0 - (sum_ee / sum_at)
    return 1.0


def generalization_tbr(
    log: pl.LazyFrame,
    petri_net: PetriNet,
    initial_marking: Marking,
    final_marking: Marking,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
) -> float:
    """Compute generalization using token-based replay.

    Based on: 1 - mean(1/sqrt(n_i)) where n_i = execution count of transition i.
    """
    diagnostics = conformance_diagnostics_token_based_replay(
        log, petri_net, initial_marking, final_marking,
        activity_key, timestamp_key, case_id_key,
    )

    trans_counts: Dict[str, int] = defaultdict(int)
    for d in diagnostics:
        for t in d["activated_transitions"]:
            trans_counts[t.name] += 1

    if not trans_counts:
        return 0.0

    import math
    inv_sqrt_sum = sum(1.0 / math.sqrt(max(c, 1)) for c in trans_counts.values())
    n_trans = len(trans_counts)

    return 1.0 - (inv_sqrt_sum / max(n_trans, 1))


def replay_prefix_tbr(
    prefix: List[str],
    net: PetriNet,
    im: Marking,
    fm: Marking,
    activity_key: str = ACTIVITY_KEY,
) -> Marking:
    """Replay a prefix on a Petri net using token-based replay."""
    label_map = _build_label_to_trans(net)
    hidden_paths = _compute_shortest_paths_hidden(net)

    marking = Marking(im)
    for act in prefix:
        trans = _find_enabled_trans_for_label(act, label_map, marking)
        if trans is None:
            continue
        can_fire = True
        for arc in trans.in_arcs:
            if marking.get(arc.source, 0) < arc.weight:
                can_fire = False
                break
        if not can_fire:
            marking, _, _, _ = _try_reach_through_hidden(
                net, marking, trans, hidden_paths
            )
        marking = _fire_transition(marking, trans)

    return marking
