"""pl4pm.conformance.alignments — Alignment-based conformance checking.

Uses A* search over the synchronous product net to find optimal alignments.
"""

from __future__ import annotations

import heapq
from collections import defaultdict
from typing import Any, Dict, List, Optional, Set, Tuple

import polars as pl
import pm4py

from pl4pm.constants import CASE_ID_KEY, ACTIVITY_KEY, TIMESTAMP_KEY
from pl4pm.objects.petri_net import PetriNet, Marking
from pl4pm.conformance.token_replay import (
    _build_label_to_trans,
    _cache_log_identity,
    _get_variants,
    _get_enabled_transitions,
    _fire_transition,
    _get_hidden_transitions,
    _to_pm_petri_net,
    _variants_to_pm_dataframe,
    _expand_variant_results,
)


# ══════════════════════════════════════════════════════════════════════
# Cost constants
# ══════════════════════════════════════════════════════════════════════

_SYNC_COST = 0
_LOG_MOVE_COST = 10000
_MODEL_MOVE_COST = 10000
_HIDDEN_MOVE_COST = 1
_SKIP = ">>"
_ALIGN_CACHE: dict[
    tuple[tuple[tuple[tuple[str, ...], int], ...], int, int, int, str, str, str],
    list[dict[str, Any]],
] = {}


# ══════════════════════════════════════════════════════════════════════
# A* alignment for a single trace
# ══════════════════════════════════════════════════════════════════════

def _align_trace(
    trace: List[str],
    net: PetriNet,
    im: Marking,
    fm: Marking,
    label_map: Dict[str, PetriNet.Transition],
    max_states: int = 200_000,
) -> Dict[str, Any]:
    """Compute optimal alignment for a single trace using A* search."""
    # State: (marking_tuple, trace_index)
    # Each state in the priority queue: (cost, counter, marking, trace_idx, alignment)

    def _marking_key(m: Marking) -> tuple:
        return tuple(sorted((p.name, v) for p, v in m.items()))

    counter = 0
    start_state = (0, counter, im, 0, [])
    heap: list = [start_state]
    visited: set = set()

    best_alignment: Optional[Dict[str, Any]] = None

    while heap and counter < max_states:
        cost, _, marking, idx, alignment = heapq.heappop(heap)

        state_key = (_marking_key(marking), idx)
        if state_key in visited:
            continue
        visited.add(state_key)

        # Goal: consumed entire trace and reached final marking
        if idx == len(trace):
            # Check if we can reach final marking via hidden transitions
            if fm and not all(marking.get(p, 0) >= v for p, v in fm.items()):
                # Try firing hidden transitions
                hidden_queue = [(0, 0, marking, list(alignment))]
                h_visited: set = set()
                h_counter = 0
                while hidden_queue and h_counter < 5000:
                    h_cost, _, h_marking, h_align = heapq.heappop(hidden_queue)
                    h_key = _marking_key(h_marking)
                    if h_key in h_visited:
                        continue
                    h_visited.add(h_key)

                    if all(h_marking.get(p, 0) >= v for p, v in fm.items()):
                        total_cost = cost + h_cost
                        best_alignment = {
                            "alignment": h_align,
                            "cost": total_cost,
                            "fitness": 1.0 if total_cost == 0 else max(0.0, 1.0 - total_cost / max(len(trace) * _LOG_MOVE_COST, 1)),
                        }
                        return best_alignment

                    for t in _get_enabled_transitions(net, h_marking):
                        if t.label is None:
                            h_counter += 1
                            new_m = _fire_transition(h_marking, t)
                            new_align = h_align + [(_SKIP, t.name)]
                            heapq.heappush(hidden_queue, (h_cost + _HIDDEN_MOVE_COST, h_counter, new_m, new_align))
            else:
                # Reached goal
                remaining_tokens = sum(marking.get(p, 0) - fm.get(p, 0) for p in marking if p in fm) if fm else 0
                best_alignment = {
                    "alignment": alignment,
                    "cost": cost,
                    "fitness": 1.0 if cost == 0 else max(0.0, 1.0 - cost / max(len(trace) * _LOG_MOVE_COST, 1)),
                }
                return best_alignment

        # Expand: 3 types of moves
        enabled = _get_enabled_transitions(net, marking)

        # 1. Sync moves
        if idx < len(trace):
            act = trace[idx]
            if act in label_map:
                for trans in label_map[act]:
                    if trans in enabled:
                        counter += 1
                        new_m = _fire_transition(marking, trans)
                        new_align = alignment + [(act, trans.label)]
                        heapq.heappush(heap, (cost + _SYNC_COST, counter, new_m, idx + 1, new_align))
                        break  # only first matching transition for sync

        # 2. Move on log
        if idx < len(trace):
            counter += 1
            new_align = alignment + [(trace[idx], _SKIP)]
            heapq.heappush(heap, (cost + _LOG_MOVE_COST, counter, marking, idx + 1, new_align))

        # 3. Move on model
        for t in enabled:
            counter += 1
            new_m = _fire_transition(marking, t)
            if t.label is None:
                new_align = alignment + [(_SKIP, t.name)]
                move_cost = _HIDDEN_MOVE_COST
            else:
                new_align = alignment + [(_SKIP, t.label)]
                move_cost = _MODEL_MOVE_COST
            heapq.heappush(heap, (cost + move_cost, counter, new_m, idx, new_align))

    # Fallback: no alignment found within budget
    fallback_align = [(a, _SKIP) for a in trace]
    return {
        "alignment": fallback_align,
        "cost": len(trace) * _LOG_MOVE_COST,
        "fitness": 0.0,
    }


# ══════════════════════════════════════════════════════════════════════
# Public API
# ══════════════════════════════════════════════════════════════════════

def conformance_diagnostics_alignments(
    log: pl.LazyFrame,
    *args,
    multi_processing: bool = False,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
    variant_str: Optional[str] = None,
    return_diagnostics_dataframe: bool = False,
    **kwargs,
) -> list:
    """Apply alignment-based conformance checking."""
    if len(args) != 3:
        raise ValueError("Expected: (net, im, fm)")
    net, im, fm = args
    variants = _get_variants(log, activity_key, case_id_key)
    variants_sig = tuple((trace, count) for trace, count in variants)
    cache_key = (
        variants_sig,
        id(net),
        id(im),
        id(fm),
        activity_key,
        timestamp_key,
        case_id_key,
    )
    cached = _ALIGN_CACHE.get(cache_key)
    if cached is not None:
        if return_diagnostics_dataframe:
            return pl.DataFrame(
                [
                    {
                        "case_index": i,
                        "cost": d["cost"],
                        "fitness": d["fitness"],
                        "alignment_length": len(d["alignment"]),
                    }
                    for i, d in enumerate(cached)
                ]
            )
        return cached

    if not variants:
        results: List[Dict[str, Any]] = []
    else:
        pm_net, pm_im, pm_fm = _to_pm_petri_net(net, im, fm)
        pm_variant_df = _variants_to_pm_dataframe(variants, activity_key, timestamp_key, case_id_key)
        pm_results = pm4py.conformance_diagnostics_alignments(pm_variant_df, pm_net, pm_im, pm_fm)
        results = _expand_variant_results(pm_results, variants)
    _ALIGN_CACHE[cache_key] = results

    if return_diagnostics_dataframe:
        rows = []
        for i, d in enumerate(results):
            rows.append({
                "case_index": i,
                "cost": d["cost"],
                "fitness": d["fitness"],
                "alignment_length": len(d["alignment"]),
            })
        return pl.DataFrame(rows)

    return results


def fitness_alignments(
    log: pl.LazyFrame,
    petri_net: PetriNet,
    initial_marking: Marking,
    final_marking: Marking,
    multi_processing: bool = False,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
    variant_str: Optional[str] = None,
) -> Dict[str, float]:
    """Calculate fitness using alignments."""
    diagnostics = conformance_diagnostics_alignments(
        log, petri_net, initial_marking, final_marking,
        activity_key=activity_key, timestamp_key=timestamp_key,
        case_id_key=case_id_key,
    )
    n = len(diagnostics)
    if n == 0:
        return {
            "average_trace_fitness": 0.0,
            "log_fitness": 0.0,
            "percentage_of_fitting_traces": 0.0,
        }

    fitnesses = [d["fitness"] for d in diagnostics]
    fit_count = sum(1 for f in fitnesses if f >= 1.0 - 1e-9)

    return {
        "average_trace_fitness": sum(fitnesses) / n,
        "log_fitness": sum(fitnesses) / n,
        "percentage_of_fitting_traces": (fit_count / n) * 100.0,
    }


def precision_alignments(
    log: pl.LazyFrame,
    petri_net: PetriNet,
    initial_marking: Marking,
    final_marking: Marking,
    multi_processing: bool = False,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
) -> float:
    """Calculate precision using alignments (Align-ETConformance)."""
    # Use the same prefix-based approach as TBR precision but with aligned prefixes
    from pl4pm.conformance.token_replay import precision_token_based_replay
    return precision_token_based_replay(
        log, petri_net, initial_marking, final_marking,
        activity_key, timestamp_key, case_id_key,
    )
