"""pl4pm.conformance.ocel_conf — OCEL conformance checking (OC-DFG, OTG, ET-OT)."""

from __future__ import annotations

from typing import Any, Dict, Optional, Set, Tuple

from pl4pm.objects.ocel import OCEL


def conformance_ocdfg(
    ocel,
    model: Dict[str, Any],
    variant=None,
    parameters: Optional[Dict[Any, Any]] = None,
) -> Dict[str, Any]:
    """OC-DFG conformance: compares real vs normative OC-DFG edges."""
    if isinstance(ocel, OCEL):
        real_edges = _ocel_to_ocdfg_edges(ocel)
    elif isinstance(ocel, dict):
        real_edges = ocel.get("edges", {})
    else:
        real_edges = {}

    model_edges = model.get("edges", {})

    # Compare edges per object type
    diagnostics: Dict[str, Any] = {"deviations": [], "is_conformant": True}

    all_ot = set(list(real_edges.keys()) + list(model_edges.keys()))
    for ot in all_ot:
        real_set = set(real_edges.get(ot, set()))
        model_set = set(model_edges.get(ot, set()))

        extra = real_set - model_set
        missing = model_set - real_set

        if extra:
            diagnostics["deviations"].append({
                "object_type": ot, "type": "extra_edges", "edges": extra,
            })
            diagnostics["is_conformant"] = False
        if missing:
            diagnostics["deviations"].append({
                "object_type": ot, "type": "missing_edges", "edges": missing,
            })
            diagnostics["is_conformant"] = False

    return diagnostics


def conformance_otg(
    ocel,
    model,
    variant=None,
    parameters: Optional[Dict[Any, Any]] = None,
) -> Dict[str, Any]:
    """OTG conformance: compare object-type graphs."""
    if isinstance(ocel, tuple) and len(ocel) == 2:
        real_ot, real_edges = ocel
    elif isinstance(ocel, OCEL):
        real_ot = set(ocel.object_types) if hasattr(ocel, 'object_types') else set()
        real_edges = {}
    else:
        real_ot, real_edges = set(), {}

    if isinstance(model, tuple) and len(model) == 2:
        model_ot, model_edges = model
    else:
        model_ot, model_edges = set(), {}

    extra_ot = real_ot - model_ot
    missing_ot = model_ot - real_ot
    extra_edges = set(real_edges.keys()) - set(model_edges.keys())
    missing_edges = set(model_edges.keys()) - set(real_edges.keys())

    return {
        "is_conformant": not (extra_ot or missing_ot or extra_edges or missing_edges),
        "extra_object_types": extra_ot,
        "missing_object_types": missing_ot,
        "extra_edges": extra_edges,
        "missing_edges": missing_edges,
    }


def conformance_etot(
    ocel,
    model,
    variant=None,
    parameters: Optional[Dict[Any, Any]] = None,
) -> Dict[str, Any]:
    """ET-OT conformance: compare event-type / object-type graphs."""
    if isinstance(ocel, tuple) and len(ocel) == 4:
        real_acts, real_ots, real_rels, real_weights = ocel
    else:
        real_acts, real_ots, real_rels, real_weights = set(), set(), set(), {}

    if isinstance(model, tuple) and len(model) == 4:
        model_acts, model_ots, model_rels, model_weights = model
    else:
        model_acts, model_ots, model_rels, model_weights = set(), set(), set(), {}

    extra_rels = real_rels - model_rels
    missing_rels = model_rels - real_rels

    return {
        "is_conformant": not (extra_rels or missing_rels),
        "extra_relations": extra_rels,
        "missing_relations": missing_rels,
        "extra_activities": real_acts - model_acts,
        "missing_activities": model_acts - real_acts,
    }


def _ocel_to_ocdfg_edges(ocel: OCEL) -> Dict[str, set]:
    """Extract OC-DFG edges from an OCEL object."""
    edges: Dict[str, set] = {}
    if hasattr(ocel, 'events') and ocel.events is not None:
        # Simplified: extract directly-follows per object type
        pass  # Full implementation would group events by object and extract DFG
    return edges
