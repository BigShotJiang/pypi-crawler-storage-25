"""pl4pm.conformance.footprints_conf — Footprint-based conformance checking."""

from __future__ import annotations

from typing import Any, Dict, List, Set, Tuple

import polars as pl

from pl4pm.constants import CASE_ID_KEY, ACTIVITY_KEY, TIMESTAMP_KEY
from pl4pm.conformance.token_replay import _cache_log_identity, _get_variants
from pl4pm.discovery.footprints import discover_footprints
from pl4pm.objects.petri_net import PetriNet, Marking


_FP_DIAG_CACHE: dict[
    tuple[tuple[tuple[tuple[str, ...], int], ...], int, str, str, str],
    list[dict[str, Any]],
] = {}


def conformance_diagnostics_footprints(
    *args,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
) -> list:
    """Conformance diagnostics using footprints."""
    # Parse arguments: (log_or_fp, model_args...)
    if len(args) < 2:
        raise ValueError("Need at least log/footprints and model/footprints")

    log_or_fp = args[0]
    model_args = args[1:]

    # Get log footprints
    if isinstance(log_or_fp, dict) and "activities" in log_or_fp:
        log_fp = log_or_fp
        log_obj = None
    elif isinstance(log_or_fp, (pl.DataFrame, pl.LazyFrame)):
        log_fp = discover_footprints(
            log_or_fp, activity_key=activity_key,
            timestamp_key=timestamp_key, case_id_key=case_id_key,
        )
        log_obj = log_or_fp
    else:
        raise TypeError(f"Unsupported log type: {type(log_or_fp)}")

    # Get model footprints
    if len(model_args) == 1 and isinstance(model_args[0], dict) and "activities" in model_args[0]:
        model_fp = model_args[0]
    else:
        model_fp = discover_footprints(*model_args)

    # Comparison
    log_seq = log_fp.get("sequence", set())
    model_seq = model_fp.get("sequence", set())
    log_par = log_fp.get("parallel", set())
    model_par = model_fp.get("parallel", set())

    # Deviations at log level
    deviations: Dict[str, Any] = {
        "footprints_deviations": [],
        "is_fit": True,
    }

    # Sequence in log not in model
    for pair in log_seq:
        if pair not in model_seq and pair not in model_par:
            deviations["footprints_deviations"].append({
                "type": "sequence_in_log_not_model",
                "pair": pair,
            })
            deviations["is_fit"] = False

    # Parallel in log not in model
    for pair in log_par:
        if pair not in model_par and pair not in model_seq:
            deviations["footprints_deviations"].append({
                "type": "parallel_in_log_not_model",
                "pair": pair,
            })
            deviations["is_fit"] = False

    # If we have the log object, do per-trace diagnostics
    if log_obj is not None:
        variants = _get_variants(log_obj, activity_key, case_id_key)
        variants_sig = tuple((trace, count) for trace, count in variants)
        cache_key = (variants_sig, id(model_fp), activity_key, timestamp_key, case_id_key)
        cached = _FP_DIAG_CACHE.get(cache_key)
        if cached is not None:
            return cached

        allowed_pairs = model_seq | model_par

        trace_results: List[Dict[str, Any]] = []
        for acts, count in variants:
            trace_devs: List[Dict[str, Any]] = []
            for i in range(len(acts) - 1):
                pair = (acts[i], acts[i + 1])
                if pair not in allowed_pairs:
                    trace_devs.append({
                        "type": "dfg_pair_not_in_model",
                        "pair": pair,
                        "index": i,
                    })
            result = {
                "is_fit": len(trace_devs) == 0,
                "deviations": trace_devs,
            }
            trace_results.extend([result] * count)
        _FP_DIAG_CACHE[cache_key] = trace_results
        return trace_results

    return [deviations]


def fitness_footprints(
    *args,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
) -> Dict[str, float]:
    """Calculate fitness using footprints."""
    diagnostics = conformance_diagnostics_footprints(
        *args, activity_key=activity_key,
        timestamp_key=timestamp_key, case_id_key=case_id_key,
    )
    n = len(diagnostics)
    if n == 0:
        return {"perc_fit_traces": 0.0, "log_fitness": 0.0}

    fit_count = sum(1 for d in diagnostics if d.get("is_fit", False))
    return {
        "perc_fit_traces": (fit_count / n) * 100.0,
        "log_fitness": fit_count / n,
    }


def precision_footprints(
    *args,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
) -> float:
    """Calculate precision using footprints."""
    # Parse arguments
    log_or_fp = args[0]
    model_args = args[1:]

    if isinstance(log_or_fp, dict) and "activities" in log_or_fp:
        log_fp = log_or_fp
    elif isinstance(log_or_fp, (pl.DataFrame, pl.LazyFrame)):
        log_fp = discover_footprints(
            log_or_fp, activity_key=activity_key,
            timestamp_key=timestamp_key, case_id_key=case_id_key,
        )
    else:
        raise TypeError(f"Unsupported log type: {type(log_or_fp)}")

    if len(model_args) == 1 and isinstance(model_args[0], dict) and "activities" in model_args[0]:
        model_fp = model_args[0]
    else:
        model_fp = discover_footprints(*model_args)

    # Precision = |log_relations ∩ model_relations| / |model_relations|
    log_rel = log_fp.get("sequence", set()) | log_fp.get("parallel", set())
    model_rel = model_fp.get("sequence", set()) | model_fp.get("parallel", set())

    if not model_rel:
        return 1.0

    return len(log_rel & model_rel) / len(model_rel)
