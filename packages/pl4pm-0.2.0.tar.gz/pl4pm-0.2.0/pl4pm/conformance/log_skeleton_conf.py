"""pl4pm.conformance.log_skeleton_conf — Log skeleton conformance checking."""

from __future__ import annotations

from collections import Counter
from typing import Any, Dict, List, Set

import polars as pl

from pl4pm.constants import CASE_ID_KEY, ACTIVITY_KEY, TIMESTAMP_KEY


def conformance_log_skeleton(
    log: pl.LazyFrame,
    log_skeleton: Dict[str, Any],
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
    return_diagnostics_dataframe: bool = False,
) -> list:
    """Conformance checking using log skeleton constraints."""
    df = log.collect() if isinstance(log, pl.LazyFrame) else log
    df = df.sort([case_id_key, timestamp_key])

    directly_follows = log_skeleton.get("directly_follows", set())
    always_before = log_skeleton.get("always_before", set())
    always_after = log_skeleton.get("always_after", set())
    equivalence = log_skeleton.get("equivalence", set())
    never_together = log_skeleton.get("never_together", set())
    activ_occurrences = log_skeleton.get("activ_occurrences", {})

    results: List[Set[Any]] = []

    for _, group in df.group_by(case_id_key, maintain_order=True):
        acts = group[activity_key].to_list()
        acts_set = set(acts)
        acts_counter = Counter(acts)
        violations: Set[str] = set()

        # 1. Activity occurrences
        for act, allowed_counts in activ_occurrences.items():
            actual = acts_counter.get(act, 0)
            if actual not in allowed_counts:
                violations.add(
                    f"activ_occurrences: {act} occurred {actual} times, "
                    f"allowed: {allowed_counts}"
                )

        # 2. Never together
        for (a, b) in never_together:
            if a in acts_set and b in acts_set:
                violations.add(f"never_together: {a} and {b}")

        # 3. Equivalence
        for (a, b) in equivalence:
            if acts_counter.get(a, 0) != acts_counter.get(b, 0):
                violations.add(
                    f"equivalence: {a}({acts_counter.get(a, 0)}) "
                    f"!= {b}({acts_counter.get(b, 0)})"
                )

        # 4. Always before
        for (a, b) in always_before:
            if b in acts_set:
                first_b = acts.index(b)
                if a not in acts[:first_b] and a not in acts_set:
                    violations.add(f"always_before: {a} should precede {b}")

        # 5. Always after
        for (a, b) in always_after:
            if a in acts_set:
                last_a = len(acts) - 1 - acts[::-1].index(a)
                if b not in acts[last_a + 1:] and b not in acts_set:
                    violations.add(f"always_after: {b} should follow {a}")

        results.append(violations)

    if return_diagnostics_dataframe:
        rows = []
        for i, vs in enumerate(results):
            rows.append({
                "case_index": i,
                "is_fit": len(vs) == 0,
                "n_violations": len(vs),
                "violations": str(vs) if vs else "",
            })
        return pl.DataFrame(rows)

    return results
