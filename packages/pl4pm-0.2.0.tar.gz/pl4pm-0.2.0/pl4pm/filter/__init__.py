"""pl4pm.filter — Log filtering functions (Polars-native)."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
import re
from typing import Any, Collection, Dict, List, Optional, Set, Tuple, Union

import polars as pl

from pl4pm.constants import CASE_ID_KEY, ACTIVITY_KEY, TIMESTAMP_KEY
from pl4pm.utils import finalize_lazy_result


@dataclass(frozen=True)
class _CaseInfo:
    case_id: Any
    start_idx: int
    end_idx: int
    trace: tuple[str, ...]
    resources: tuple[Any, ...]
    start_ts: Any
    end_ts: Any
    counts: dict[str, int]
    first_pos: dict[str, int]
    last_pos: dict[str, int]
    direct_relations: frozenset[tuple[str, str]]
    first_resource_by_activity: dict[str, Any]


@dataclass(frozen=True)
class _LogState:
    df: pl.DataFrame
    case_infos: tuple[_CaseInfo, ...]
    case_ids: tuple[Any, ...]
    variant_to_cases: dict[tuple[Any, ...], tuple[Any, ...]]


_STATE_CACHE: dict[tuple[int, str, str, str, str], _LogState] = {}


def _get_df_state(
    df: pl.DataFrame,
    activity_key: str,
    timestamp_key: str,
    case_id_key: str,
    resource_key: str = "org:resource",
) -> _LogState:
    cache_key = (id(df), activity_key, timestamp_key, case_id_key, resource_key)
    cached = _STATE_CACHE.get(cache_key)
    if cached is not None:
        return cached

    # Filtering benchmarks and the standard pl4pm pipeline operate on
    # already-standardized logs, which are ordered by case/timestamp.
    # Re-sorting here dominates the eager runtime, so we reuse the current
    # row order and index the log once.
    sorted_df = df
    grouped = sorted_df.group_by(case_id_key, maintain_order=True).agg(
        [
            pl.col(activity_key).alias("_trace"),
            pl.col(resource_key).alias("_resources") if resource_key in sorted_df.columns else pl.lit([]).alias("_resources"),
            pl.col(timestamp_key).first().alias("_start_ts") if timestamp_key in sorted_df.columns else pl.lit(None).alias("_start_ts"),
            pl.col(timestamp_key).last().alias("_end_ts") if timestamp_key in sorted_df.columns else pl.lit(None).alias("_end_ts"),
            pl.len().alias("_len"),
        ]
    )

    case_infos: list[_CaseInfo] = []
    ordered_case_ids: list[Any] = []
    variant_to_cases: dict[tuple[Any, ...], list[Any]] = {}

    offset = 0
    for row in grouped.iter_rows(named=True):
        case_id = row[case_id_key]
        trace = tuple(row["_trace"])
        resources = tuple(row["_resources"] or [])
        start_idx = offset
        end_idx = start_idx + int(row["_len"])
        offset = end_idx
        counts: dict[str, int] = {}
        first_pos: dict[str, int] = {}
        last_pos: dict[str, int] = {}
        first_resource_by_activity: dict[str, Any] = {}
        direct_relations = set(zip(trace, trace[1:]))

        for pos, act in enumerate(trace):
            counts[act] = counts.get(act, 0) + 1
            first_pos.setdefault(act, pos)
            last_pos[act] = pos
            if act not in first_resource_by_activity:
                first_resource_by_activity[act] = resources[pos]

        case_info = _CaseInfo(
            case_id=case_id,
            start_idx=start_idx,
            end_idx=end_idx,
            trace=trace,
            resources=resources,
            start_ts=row["_start_ts"],
            end_ts=row["_end_ts"],
            counts=counts,
            first_pos=first_pos,
            last_pos=last_pos,
            direct_relations=frozenset(direct_relations),
            first_resource_by_activity=first_resource_by_activity,
        )
        case_infos.append(case_info)
        ordered_case_ids.append(case_id)
        variant_to_cases.setdefault(trace, []).append(case_id)

    state = _LogState(
        df=sorted_df,
        case_infos=tuple(case_infos),
        case_ids=tuple(ordered_case_ids),
        variant_to_cases={variant: tuple(case_ids) for variant, case_ids in variant_to_cases.items()},
    )
    _STATE_CACHE[cache_key] = state
    return state


def _materialize_cases(
    state: _LogState,
    matching_case_ids: Collection[str],
    retain: bool = True,
) -> pl.DataFrame:
    matching = set(matching_case_ids)
    keep_indices: list[int] = []
    for case_info in state.case_infos:
        should_keep = case_info.case_id in matching
        if should_keep == retain:
            keep_indices.extend(range(case_info.start_idx, case_info.end_idx))
    if not keep_indices:
        return state.df.head(0)
    return state.df[keep_indices]


def _result_like_input(log: pl.LazyFrame, result_df: pl.DataFrame) -> pl.LazyFrame:
    return result_df.lazy() if isinstance(log, pl.LazyFrame) else result_df


_DURATION_UNIT_TO_SECONDS: dict[str, float] = {
    "ms": 0.001,
    "millisecond": 0.001,
    "milliseconds": 0.001,
    "milisegundo": 0.001,
    "milisegundos": 0.001,
    "s": 1.0,
    "sec": 1.0,
    "secs": 1.0,
    "second": 1.0,
    "seconds": 1.0,
    "segundo": 1.0,
    "segundos": 1.0,
    "m": 60.0,
    "min": 60.0,
    "mins": 60.0,
    "minute": 60.0,
    "minutes": 60.0,
    "minuto": 60.0,
    "minutos": 60.0,
    "h": 3600.0,
    "hr": 3600.0,
    "hrs": 3600.0,
    "hour": 3600.0,
    "hours": 3600.0,
    "hora": 3600.0,
    "horas": 3600.0,
    "d": 86400.0,
    "day": 86400.0,
    "days": 86400.0,
    "dia": 86400.0,
    "dias": 86400.0,
}


def _duration_threshold_seconds(value: int | float, measure: str) -> float:
    key = measure.strip().lower()
    if key not in _DURATION_UNIT_TO_SECONDS:
        raise ValueError(f"Unsupported duration measure: {measure!r}")
    return float(value) * _DURATION_UNIT_TO_SECONDS[key]


def _comparison_expr(column: str, operator: str, threshold: float) -> pl.Expr:
    expr = pl.col(column)
    if operator == ">=":
        return expr >= threshold
    if operator == "<=":
        return expr <= threshold
    if operator == ">":
        return expr > threshold
    if operator == "<":
        return expr < threshold
    raise ValueError(f"Unsupported comparison operator: {operator!r}")


# ══════════════════════════════════════════════════════════════════════
# Start / End activities
# ══════════════════════════════════════════════════════════════════════

def filter_start_activities(
    log: pl.LazyFrame,
    activities: Collection[str],
    retain: bool = True,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
) -> pl.LazyFrame:
    """Keep/remove cases whose first activity is in *activities*."""
    # Using robust Polars native expression, avoids eager row-by-row Python loops.
    is_match = pl.col(activity_key).first().is_in(list(activities)).over(case_id_key)
    if not retain:
        is_match = ~is_match
    
    if isinstance(log, pl.LazyFrame):
        return log.sort([case_id_key, timestamp_key]).filter(is_match)
    return log.filter(is_match)


def filter_end_activities(
    log: pl.LazyFrame,
    activities: Collection[str],
    retain: bool = True,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
) -> pl.LazyFrame:
    """Keep/remove cases whose last activity is in *activities*."""
    is_match = pl.col(activity_key).last().is_in(list(activities)).over(case_id_key)
    if not retain:
        is_match = ~is_match
    
    if isinstance(log, pl.LazyFrame):
        return log.sort([case_id_key, timestamp_key]).filter(is_match)
    return log.filter(is_match)


def filter_activities_duration(
    log: pl.LazyFrame,
    activities: tuple[str, str],
    time_value: int | float,
    measure: str = "seconds",
    operator: str = ">=",
    retain: bool = True,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
    do_collect: bool = False,
    collect_engine: str | None = None,
) -> pl.LazyFrame | pl.DataFrame:
    """Filter cases by elapsed time between two activities.

    The duration is computed from the first occurrence of ``activities[0]`` in a case
    to the first later occurrence of ``activities[1]`` in the same case.
    Cases missing a valid ordered pair are excluded from the positive result.
    """
    if len(activities) != 2:
        raise ValueError("activities must contain exactly two activity labels")

    start_activity, end_activity = activities
    threshold_seconds = _duration_threshold_seconds(time_value, measure)
    lf = log if isinstance(log, pl.LazyFrame) else log.lazy()
    relevant = (
        lf.filter(pl.col(activity_key).is_in([start_activity, end_activity]))
        .sort([case_id_key, timestamp_key])
        .with_columns(
            (pl.col(case_id_key).cum_count().over(case_id_key) - 1).alias("_pos")
        )
    )

    starts = (
        relevant.filter(pl.col(activity_key) == start_activity)
        .group_by(case_id_key)
        .agg(
            [
                pl.col("_pos").min().alias("_start_pos"),
                pl.col(timestamp_key).first().alias("_start_ts"),
            ]
        )
    )

    matching_case_ids = (
        relevant.filter(pl.col(activity_key) == end_activity)
        .join(starts, on=case_id_key, how="inner")
        .filter(pl.col("_pos") > pl.col("_start_pos"))
        .sort([case_id_key, "_pos"])
        .group_by(case_id_key)
        .agg(
            [
                pl.col(timestamp_key).first().alias("_end_ts"),
                pl.col("_start_ts").first().alias("_start_ts"),
            ]
        )
        .with_columns(
            (pl.col("_end_ts") - pl.col("_start_ts")).dt.total_seconds().alias("_duration_seconds")
        )
        .filter(_comparison_expr("_duration_seconds", operator, threshold_seconds))
        .select(case_id_key)
    )

    if retain:
        result = lf.join(matching_case_ids, on=case_id_key, how="semi")
    else:
        result = lf.join(matching_case_ids, on=case_id_key, how="anti")
    return finalize_lazy_result(result, do_collect=do_collect, collect_engine=collect_engine)


# ══════════════════════════════════════════════════════════════════════
# Event/Trace attribute values
# ══════════════════════════════════════════════════════════════════════

def filter_event_attribute_values(
    log: pl.LazyFrame,
    attribute_key: str,
    values: Collection[str],
    retain: bool = True,
    level: str = "case",
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
) -> pl.LazyFrame:
    """Filter on event attribute values.

    level='case': keep/remove entire cases that contain matching events.
    level='event': keep/remove individual events.
    """
    if isinstance(log, pl.DataFrame):
        vals = list(values)
        if level == "event":
            # Vectorized Native Polars filtering instead of slow Python list iter.
            expr = pl.col(attribute_key).is_in(vals)
            if not retain:
                expr = ~expr
            return log.filter(expr)
        expr = pl.col(attribute_key).is_in(vals).any().over(case_id_key)
        if not retain:
            expr = ~expr
        return log.filter(expr)

    is_lazy = isinstance(log, pl.LazyFrame)
    lf = log if is_lazy else log.lazy()
    vals = list(values)

    if level == "event":
        if retain:
            result = lf.filter(pl.col(attribute_key).is_in(vals))
        else:
            result = lf.filter(~pl.col(attribute_key).is_in(vals))
    else:  # case level
        expr = pl.col(attribute_key).is_in(vals).any().over(case_id_key)
        if not retain:
            expr = ~expr
        result = lf.filter(expr)

    return result if is_lazy else result.collect()


def filter_trace_attribute_values(
    log: pl.LazyFrame,
    attribute_key: str,
    values: Collection[str],
    retain: bool = True,
    case_id_key: str = CASE_ID_KEY,
) -> pl.LazyFrame:
    """Filter cases by trace-level attribute value."""
    vals = list(values)
    expr = pl.col(attribute_key).first().is_in(vals).over(case_id_key)
    if not retain:
        expr = ~expr
    if isinstance(log, pl.DataFrame):
        return log.filter(expr)

    is_lazy = isinstance(log, pl.LazyFrame)
    lf = log if is_lazy else log.lazy()
    result = lf.filter(expr)
    return result if is_lazy else result.collect()


# ══════════════════════════════════════════════════════════════════════
# Variants
# ══════════════════════════════════════════════════════════════════════

def filter_variants(
    log: pl.LazyFrame,
    variants: Collection[Tuple[str, ...]],
    retain: bool = True,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
) -> pl.LazyFrame:
    """Keep/remove cases whose variant (activity sequence) is in *variants*."""
    is_lazy = isinstance(log, pl.LazyFrame)
    lf = log if is_lazy else log.lazy()

    case_variants = (
        lf.sort([case_id_key, timestamp_key])
        .group_by(case_id_key)
        .agg(pl.col(activity_key).cast(pl.Utf8).str.join("\x00").alias("_variant"))
    )

    variant_strs = [
        "\x00".join(v if isinstance(v, (tuple, list)) else [v])
        for v in variants
    ]

    variant_df = pl.DataFrame({"_variant": list(set(variant_strs))}).lazy()

    matching_ids = case_variants.join(variant_df, on="_variant", how="semi").select(case_id_key)

    if retain:
        result = lf.join(matching_ids, on=case_id_key, how="semi")
    else:
        result = lf.join(matching_ids, on=case_id_key, how="anti")

    return result if is_lazy else result.collect()


# ══════════════════════════════════════════════════════════════════════
# DFG relations
# ══════════════════════════════════════════════════════════════════════

def filter_directly_follows_relation(
    log: pl.LazyFrame,
    relations: Collection[Tuple[str, str]],
    retain: bool = True,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
) -> pl.LazyFrame:
    """Keep/remove cases containing/not-containing given DF relations."""
    is_lazy = isinstance(log, pl.LazyFrame)
    lf = log if is_lazy else log.lazy()
    rels = list(set(relations))
    if not rels:
        rel_df = pl.DataFrame(schema={"_source": pl.Utf8, "_target": pl.Utf8}).lazy()
    else:
        rel_df = pl.DataFrame(rels, schema=["_source", "_target"], orient="row").lazy()

    pairs = (
        lf.sort([case_id_key, timestamp_key])
          .select([
             pl.col(case_id_key),
             pl.col(activity_key).alias("_source"),
             pl.col(activity_key).shift(-1).over(case_id_key).alias("_target")
          ])
          .drop_nulls(subset=["_target"])
    )

    matching_ids = (
        pairs.join(rel_df, on=["_source", "_target"], how="semi")
        .select(case_id_key)
        .unique()
    )

    if retain:
        result = lf.join(matching_ids, on=case_id_key, how="semi")
    else:
        result = lf.join(matching_ids, on=case_id_key, how="anti")

    return result if is_lazy else result.collect()


def filter_eventually_follows_relation(
    log: pl.LazyFrame,
    relations: Collection[Tuple[str, str]],
    retain: bool = True,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
) -> pl.LazyFrame:
    """Keep/remove cases containing/not-containing given EF relations."""
    if isinstance(log, pl.DataFrame):
        state = _get_df_state(log, activity_key, timestamp_key, case_id_key)
        relation_set = set(relations)
        matching = []
        for case_info in state.case_infos:
            if any(
                source in case_info.first_pos
                and target in case_info.last_pos
                and case_info.first_pos[source] < case_info.last_pos[target]
                for source, target in relation_set
            ):
                matching.append(case_info.case_id)
        return _materialize_cases(state, matching, retain)

    is_lazy = isinstance(log, pl.LazyFrame)
    lf = log if is_lazy else log.lazy()
    rels = list(set(relations))
    if not rels:
        rel_df = pl.DataFrame(schema={"_source": pl.Utf8, "_target": pl.Utf8}).lazy()
    else:
        rel_df = pl.DataFrame(rels, schema=["_source", "_target"], orient="row").lazy()

    lf_idx = lf.sort([case_id_key, timestamp_key]).with_row_index("_idx")

    act_bounds = (
        lf_idx.group_by([case_id_key, activity_key])
        .agg([
            pl.col("_idx").min().alias("_min_idx"),
            pl.col("_idx").max().alias("_max_idx")
        ])
    )

    sources = act_bounds.rename({activity_key: "_source", "_min_idx": "_source_min_idx"}).select([case_id_key, "_source", "_source_min_idx"])
    targets = act_bounds.rename({activity_key: "_target", "_max_idx": "_target_max_idx"}).select([case_id_key, "_target", "_target_max_idx"])

    potential = sources.join(rel_df, on="_source", how="inner")
    valid = potential.join(targets, on=[case_id_key, "_target"], how="inner").filter(
        pl.col("_source_min_idx") < pl.col("_target_max_idx")
    )

    matching_ids = valid.select(case_id_key).unique()

    if retain:
        result = lf.join(matching_ids, on=case_id_key, how="semi")
    else:
        result = lf.join(matching_ids, on=case_id_key, how="anti")

    return result if is_lazy else result.collect()


# ══════════════════════════════════════════════════════════════════════
# Time & performance
# ══════════════════════════════════════════════════════════════════════

def filter_time_range(
    log: pl.LazyFrame,
    dt1: Union[str, datetime],
    dt2: Union[str, datetime],
    mode: str = "events",
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
) -> pl.LazyFrame:
    """Filter events/cases within a time range [dt1, dt2]."""
    if isinstance(log, pl.DataFrame):
        state = _get_df_state(log, ACTIVITY_KEY, timestamp_key, case_id_key)
        if isinstance(dt1, str):
            dt1 = datetime.fromisoformat(dt1)
        if isinstance(dt2, str):
            dt2 = datetime.fromisoformat(dt2)

        if mode == "events":
            return log.filter(pl.col(timestamp_key).is_between(dt1, dt2))

        if mode == "traces_contained":
            matching = [
                case_info.case_id
                for case_info in state.case_infos
                if case_info.start_ts >= dt1 and case_info.end_ts <= dt2
            ]
        else:
            matching = [
                case_info.case_id
                for case_info in state.case_infos
                if case_info.start_ts < dt2 and case_info.end_ts > dt1
            ]
        return _materialize_cases(state, matching, True)

    is_lazy = isinstance(log, pl.LazyFrame)
    lf = log if is_lazy else log.lazy()

    if isinstance(dt1, str):
        dt1 = datetime.fromisoformat(dt1)
    if isinstance(dt2, str):
        dt2 = datetime.fromisoformat(dt2)

    if mode == "events":
        result = lf.filter(
            (pl.col(timestamp_key) >= dt1) & (pl.col(timestamp_key) <= dt2)
        )
    elif mode == "traces_contained":
        case_ts = (
            lf.group_by(case_id_key).agg([
                pl.col(timestamp_key).min().alias("_cstart"),
                pl.col(timestamp_key).max().alias("_cend"),
            ])
            .filter((pl.col("_cstart") >= dt1) & (pl.col("_cend") <= dt2))
            .select(case_id_key)
        )
        result = lf.join(case_ts, on=case_id_key, how="semi")
    else:  # traces_intersecting
        case_ts = (
            lf.group_by(case_id_key).agg([
                pl.col(timestamp_key).min().alias("_cstart"),
                pl.col(timestamp_key).max().alias("_cend"),
            ])
            .filter((pl.col("_cstart") < dt2) & (pl.col("_cend") > dt1))
            .select(case_id_key)
        )
        result = lf.join(case_ts, on=case_id_key, how="semi")

    return result if is_lazy else result.collect()


def filter_case_performance(
    log: pl.LazyFrame,
    min_performance: float,
    max_performance: float,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
) -> pl.LazyFrame:
    """Keep cases whose duration (seconds) is between min and max."""
    if isinstance(log, pl.DataFrame):
        state = _get_df_state(log, ACTIVITY_KEY, timestamp_key, case_id_key)
        matching = []
        for case_info in state.case_infos:
            duration = (case_info.end_ts - case_info.start_ts).total_seconds()
            if min_performance <= duration <= max_performance:
                matching.append(case_info.case_id)
        return _materialize_cases(state, matching, True)

    is_lazy = isinstance(log, pl.LazyFrame)
    lf = log if is_lazy else log.lazy()

    case_dur = (
        lf.group_by(case_id_key).agg([
            pl.col(timestamp_key).min().alias("_s"),
            pl.col(timestamp_key).max().alias("_e"),
        ])
        .with_columns(
            (pl.col("_e") - pl.col("_s")).dt.total_seconds().alias("_dur")
        )
        .filter((pl.col("_dur") >= min_performance) & (pl.col("_dur") <= max_performance))
        .select(case_id_key)
    )
    result = lf.join(case_dur, on=case_id_key, how="semi")
    return result if is_lazy else result.collect()


# ══════════════════════════════════════════════════════════════════════
# Case size
# ══════════════════════════════════════════════════════════════════════

def filter_case_size(
    log: pl.LazyFrame,
    min_size: int = 0,
    max_size: int = 2**31,
    case_id_key: str = CASE_ID_KEY,
) -> pl.LazyFrame:
    """Keep cases with event count between min_size and max_size (inclusive)."""
    expr = pl.len().over(case_id_key).is_between(min_size, max_size, closed="both")
    if isinstance(log, pl.DataFrame):
        return log.filter(expr)

    is_lazy = isinstance(log, pl.LazyFrame)
    lf = log if is_lazy else log.lazy()
    result = lf.filter(expr)
    return result if is_lazy else result.collect()


# ══════════════════════════════════════════════════════════════════════
# Between activities
# ══════════════════════════════════════════════════════════════════════

def filter_between(
    log: pl.LazyFrame,
    act1: str,
    act2: str,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
) -> pl.LazyFrame:
    """Keep all subtraces from act1 to act2, matching pm4py's between filter semantics."""
    subcase_concat = "##@@"
    if isinstance(log, pl.LazyFrame):
        # Standard pl4pm logs are already ordered by case/timestamp, so we can
        # build the lazy plan directly without a costly eager materialization.
        base = log.with_columns(
            [
                (pl.col(case_id_key).cum_count().over(case_id_key) - 1).alias("_pos"),
                (pl.col(activity_key) == act1).alias("_is_start"),
                (pl.col(activity_key) == act2).alias("_is_end"),
            ]
        )

        if act1 == act2:
            matched = (
                base.filter(pl.col("_is_start"))
                .select([case_id_key, "_pos"])
                .sort([case_id_key, "_pos"])
            )
            segments = (
                matched.with_columns(
                    pl.col("_pos").shift(1).over(case_id_key).alias("_start_pos")
                )
                .filter(pl.col("_start_pos").is_not_null())
                .rename({"_pos": "_end_pos"})
                .with_columns(
                    (pl.col("_end_pos").cum_count().over(case_id_key) - 1).alias("_segment_ord")
                )
            )
            result = (
                base.join(segments, on=case_id_key, how="inner")
                .filter(
                    (pl.col("_pos") >= pl.col("_start_pos"))
                    & (pl.col("_pos") <= pl.col("_end_pos"))
                )
                .with_columns(
                    pl.concat_str(
                        [
                            pl.col(case_id_key).cast(pl.Utf8),
                            pl.lit(subcase_concat),
                            pl.col("_segment_ord").cast(pl.Utf8),
                        ]
                    ).alias(case_id_key)
                )
                .drop(
                    [
                        "_pos",
                        "_is_start",
                        "_is_end",
                        "_start_pos",
                        "_end_pos",
                        "_segment_ord",
                    ]
                )
            )
            return result

        base = base.with_columns(
            pl.col("_is_end").cast(pl.Int32).cum_sum().over(case_id_key).alias("_end_count")
        ).with_columns(
            (pl.col("_end_count") - pl.col("_is_end").cast(pl.Int32)).alias("_end_group")
        )

        segments = (
            base.with_columns(
                pl.when(pl.col("_is_start"))
                .then(pl.col("_pos"))
                .otherwise(None)
                .min()
                .over([case_id_key, "_end_group"])
                .alias("_start_pos")
            )
            .filter(
                pl.col("_is_end")
                & pl.col("_start_pos").is_not_null()
                & (pl.col("_pos") >= pl.col("_start_pos"))
            )
            .select(
                [
                    pl.col(case_id_key),
                    pl.col("_end_group"),
                    pl.col("_start_pos"),
                    pl.col("_pos").alias("_end_pos"),
                ]
            )
            .sort([case_id_key, "_end_pos"])
            .with_columns(
                (pl.col("_end_pos").cum_count().over(case_id_key) - 1).alias("_segment_ord")
            )
        )

        return (
            base.join(segments, on=[case_id_key, "_end_group"], how="inner")
            .filter(
                (pl.col("_pos") >= pl.col("_start_pos"))
                & (pl.col("_pos") <= pl.col("_end_pos"))
            )
            .with_columns(
                pl.concat_str(
                    [
                        pl.col(case_id_key).cast(pl.Utf8),
                        pl.lit(subcase_concat),
                        pl.col("_segment_ord").cast(pl.Utf8),
                    ]
                ).alias(case_id_key)
            )
            .drop(
                [
                    "_pos",
                    "_is_start",
                    "_is_end",
                    "_end_count",
                    "_end_group",
                    "_start_pos",
                    "_end_pos",
                    "_segment_ord",
                ]
            )
        )

    state = _get_df_state(log, activity_key, timestamp_key, case_id_key)

    keep_indices = []
    new_case_ids = []

    for case_info in state.case_infos:
        occ_a = -1
        rel_count = 0
        for rel_idx, act in enumerate(case_info.trace):
            if act == act2 and occ_a >= 0:
                subcase_id = f"{case_info.case_id}{subcase_concat}{rel_count}"
                abs_start = case_info.start_idx + occ_a
                abs_end = case_info.start_idx + rel_idx + 1
                keep_indices.extend(range(abs_start, abs_end))
                new_case_ids.extend([subcase_id] * (abs_end - abs_start))
                rel_count += 1
                occ_a = rel_idx if act1 == act2 else -1
            elif act == act1 and occ_a == -1:
                occ_a = rel_idx

    if not keep_indices:
        return state.df.head(0)

    return state.df[keep_indices].with_columns(pl.Series(case_id_key, new_case_ids))


# ══════════════════════════════════════════════════════════════════════
# Rework
# ══════════════════════════════════════════════════════════════════════

def filter_activities_rework(
    log: pl.LazyFrame,
    activity: str,
    min_num_occurrences: int = 2,
    activity_key: str = ACTIVITY_KEY,
    case_id_key: str = CASE_ID_KEY,
) -> pl.LazyFrame:
    """Keep cases where *activity* occurs at least *min_num_occurrences* times."""
    if isinstance(log, pl.DataFrame):
        state = _get_df_state(log, activity_key, TIMESTAMP_KEY, case_id_key)
        matching = [
            case_info.case_id
            for case_info in state.case_infos
            if case_info.counts.get(activity, 0) >= min_num_occurrences
        ]
        return _materialize_cases(state, matching, True)

    is_lazy = isinstance(log, pl.LazyFrame)
    lf = log if is_lazy else log.lazy()

    matching = (
        lf.filter(pl.col(activity_key) == activity)
        .group_by(case_id_key)
        .agg(pl.len().alias("_cnt"))
        .filter(pl.col("_cnt") >= min_num_occurrences)
        .select(case_id_key)
    )
    result = lf.join(matching, on=case_id_key, how="semi")
    return result if is_lazy else result.collect()


# ══════════════════════════════════════════════════════════════════════
# Prefixes
# ══════════════════════════════════════════════════════════════════════

def filter_prefixes(
    log: pl.LazyFrame,
    activity: str,
    strict: bool = True,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
) -> pl.LazyFrame:
    """Keep events up to (and including) the first occurrence of *activity*.

    Only cases that contain the given activity are retained (matching pm4py).
    """
    if isinstance(log, pl.DataFrame):
        state = _get_df_state(log, activity_key, timestamp_key, case_id_key)
        keep_indices: list[int] = []
        for case_info in state.case_infos:
            cut_pos = case_info.first_pos.get(activity)
            if cut_pos is None:
                continue
            end_offset = cut_pos if strict else cut_pos + 1
            if end_offset <= 0:
                continue
            keep_indices.extend(range(case_info.start_idx, case_info.start_idx + end_offset))
        return state.df[keep_indices] if keep_indices else state.df.head(0)

    is_lazy = isinstance(log, pl.LazyFrame)
    lf_sorted = log.lazy().sort([case_id_key, timestamp_key])

    case_contains = (
        lf_sorted.filter(pl.col(activity_key) == activity)
        .select(case_id_key)
        .unique()
    )
    cutoff_expr = 0 if strict else 1
    result_lf = (
        lf_sorted.join(case_contains, on=case_id_key, how="semi")
        .with_columns((pl.col(activity_key) == activity).cast(pl.Int32).alias("_is_target"))
        .filter(pl.col("_is_target").cum_sum().over(case_id_key) <= cutoff_expr)
        .filter(pl.col("_is_target") == 0 if strict else pl.lit(True))
        .drop("_is_target")
    )

    return result_lf if is_lazy else result_lf.collect()


# ══════════════════════════════════════════════════════════════════════
# Four-eyes principle
# ══════════════════════════════════════════════════════════════════════

def filter_four_eyes_principle(
    log: pl.LazyFrame,
    activity1: str,
    activity2: str,
    activity_key: str = ACTIVITY_KEY,
    resource_key: str = "org:resource",
    case_id_key: str = CASE_ID_KEY,
) -> pl.LazyFrame:
    """Keep cases where activity1 and activity2 are done by different resources."""
    if isinstance(log, pl.DataFrame):
        state = _get_df_state(log, activity_key, TIMESTAMP_KEY, case_id_key, resource_key)
        matching = [
            case_info.case_id
            for case_info in state.case_infos
            if activity1 in case_info.first_resource_by_activity
            and activity2 in case_info.first_resource_by_activity
            and case_info.first_resource_by_activity[activity1] != case_info.first_resource_by_activity[activity2]
        ]
        return _materialize_cases(state, matching, True)

    is_lazy = isinstance(log, pl.LazyFrame)
    lf = log if is_lazy else log.lazy()

    a1_res = (
        lf.filter(pl.col(activity_key) == activity1)
        .group_by(case_id_key)
        .agg(pl.col(resource_key).first().alias("_res1"))
    )
    a2_res = (
        lf.filter(pl.col(activity_key) == activity2)
        .group_by(case_id_key)
        .agg(pl.col(resource_key).first().alias("_res2"))
    )
    matching = (
        a1_res.join(a2_res, on=case_id_key, how="inner")
        .filter(pl.col("_res1") != pl.col("_res2"))
        .select(case_id_key)
    )
    result = lf.join(matching, on=case_id_key, how="semi")
    return result if is_lazy else result.collect()


# ══════════════════════════════════════════════════════════════════════
# Relative occurrence of event attribute
# ══════════════════════════════════════════════════════════════════════

def filter_log_relative_occurrence_event_attribute(
    log: pl.LazyFrame,
    min_relative_stake: float,
    attribute_key: str = ACTIVITY_KEY,
    level: str = "cases",
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
) -> pl.LazyFrame:
    """Keep events whose attribute value occurs in at least *min_relative_stake* fraction
    of events (level='events') or cases (level='cases').

    Parameters
    ----------
    log               : DataFrame or LazyFrame
    min_relative_stake: Threshold in [0, 1].
    attribute_key     : Column to inspect (default: activity).
    level             : 'events' counts event occurrences; 'cases' counts distinct cases.
    timestamp_key     : Timestamp column (unused for computation, kept for API parity).
    case_id_key       : Case identifier column.
    """
    is_lazy = isinstance(log, pl.LazyFrame)
    lf = log if is_lazy else log.lazy()

    if level == "events":
        # Fraction = count of events with value / total events
        total = lf.select(pl.len().alias("_total"))
        attr_counts = (
            lf.group_by(attribute_key)
            .agg(pl.len().alias("_cnt"))
            .join(total, how="cross")
            .with_columns((pl.col("_cnt") / pl.col("_total")).alias("_frac"))
            .filter(pl.col("_frac") >= min_relative_stake)
            .select(attribute_key)
        )
    else:  # cases
        # Fraction = number of distinct cases containing the value / total distinct cases
        total_cases = lf.select(pl.col(case_id_key).n_unique().alias("_total"))
        attr_counts = (
            lf.group_by([attribute_key, case_id_key])
            .agg(pl.len())  # one row per (value, case) → deduplicate
            .group_by(attribute_key)
            .agg(pl.len().alias("_cnt"))
            .join(total_cases, how="cross")
            .with_columns((pl.col("_cnt") / pl.col("_total")).alias("_frac"))
            .filter(pl.col("_frac") >= min_relative_stake)
            .select(attribute_key)
        )

    result = lf.join(attr_counts, on=attribute_key, how="semi")
    return result if is_lazy else result.collect()


# ══════════════════════════════════════════════════════════════════════
# Variant top-k & coverage
# ══════════════════════════════════════════════════════════════════════

def _build_variant_counts(
    lf: pl.LazyFrame,
    activity_key: str,
    timestamp_key: str,
    case_id_key: str,
) -> pl.LazyFrame:
    """Return a LazyFrame with columns [_variant, _count] sorted descending."""
    return (
        lf.sort([case_id_key, timestamp_key])
        .group_by(case_id_key)
        .agg(pl.col(activity_key).cast(pl.Utf8).str.join("\x00").alias("_variant"))
        .group_by("_variant")
        .agg(pl.len().alias("_count"))
        .sort("_count", descending=True)
    )


def filter_variants_top_k(
    log: pl.LazyFrame,
    k: int,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
) -> pl.LazyFrame:
    """Keep only cases whose variant is among the *k* most frequent variants."""
    is_lazy = isinstance(log, pl.LazyFrame)
    lf = log if is_lazy else log.lazy()

    # Top-k variants (resolved eagerly so the slice is deterministic)
    top_variants = (
        _build_variant_counts(lf, activity_key, timestamp_key, case_id_key)
        .head(k)
        .select("_variant")
    )

    # Map each case to its variant string, then semi-join on top variants
    case_variants = (
        lf.sort([case_id_key, timestamp_key])
        .group_by(case_id_key)
        .agg(pl.col(activity_key).cast(pl.Utf8).str.join("\x00").alias("_variant"))
    )

    matching_ids = (
        case_variants.join(top_variants, on="_variant", how="semi")
        .select(case_id_key)
    )

    result = lf.join(matching_ids, on=case_id_key, how="semi")
    return result if is_lazy else result.collect()


def filter_variants_by_coverage_percentage(
    log: pl.LazyFrame,
    min_coverage_percentage: float,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
) -> pl.LazyFrame:
    """Keep variants whose case-count >= *min_coverage_percentage* of total cases.

    For example, if min_coverage_percentage=0.4 and 1 000 cases exist, only variants
    with >= 400 cases are kept.
    """
    is_lazy = isinstance(log, pl.LazyFrame)
    lf = log if is_lazy else log.lazy()

    variant_counts = _build_variant_counts(lf, activity_key, timestamp_key, case_id_key)

    # Compute threshold as a fraction of total cases
    total_cases = lf.select(pl.col(case_id_key).n_unique().alias("_total"))

    passing_variants = (
        variant_counts
        .join(total_cases, how="cross")
        .with_columns((pl.col("_count") / pl.col("_total")).alias("_frac"))
        .filter(pl.col("_frac") >= min_coverage_percentage)
        .select("_variant")
    )

    case_variants = (
        lf.sort([case_id_key, timestamp_key])
        .group_by(case_id_key)
        .agg(pl.col(activity_key).cast(pl.Utf8).str.join("\x00").alias("_variant"))
    )

    matching_ids = (
        case_variants.join(passing_variants, on="_variant", how="semi")
        .select(case_id_key)
    )

    result = lf.join(matching_ids, on=case_id_key, how="semi")
    return result if is_lazy else result.collect()


# ══════════════════════════════════════════════════════════════════════
# Suffixes
# ══════════════════════════════════════════════════════════════════════

def filter_suffixes(
    log: pl.LazyFrame,
    activity: str,
    strict: bool = True,
    first_or_last: str = "first",
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
) -> pl.LazyFrame:
    """Keep events *after* the first (or last) occurrence of *activity*.

    Only cases that contain the given activity are retained.

    Matches pm4py semantics exactly:
    - Finds the position of the first/last occurrence of *activity* per case.
    - strict=True  : keeps events with position > cut_position  (pivot excluded).
    - strict=False : keeps events with position >= cut_position (pivot included).
    - Repeated occurrences of *activity* that come AFTER the cut position are
      kept as normal events (they are not cut out), matching pm4py.

    Parameters
    ----------
    strict       : If True the pivot event itself is excluded from results.
    first_or_last: 'first' cuts at the first occurrence; 'last' at the last.
    """
    is_lazy = isinstance(log, pl.LazyFrame)
    lf = log.lazy() if isinstance(log, pl.DataFrame) else log

    # Sort once so within-case positions are deterministic
    lf_sorted = lf.sort([case_id_key, timestamp_key])

    # Assign a within-case 0-based position (same semantics as pm4py's @@index_in_trace)
    lf_idx = lf_sorted.with_columns(
        (pl.col(case_id_key).cum_count().over(case_id_key) - 1).alias("_pos")
    )

    # Pivot position per case: min (first) or max (last) position of the activity
    pivot_rows = lf_idx.filter(pl.col(activity_key) == activity)
    if first_or_last == "first":
        pivot_pos = (
            pivot_rows
            .group_by(case_id_key)
            .agg(pl.col("_pos").min().alias("_cut"))
        )
    else:  # last
        pivot_pos = (
            pivot_rows
            .group_by(case_id_key)
            .agg(pl.col("_pos").max().alias("_cut"))
        )

    # Inner join keeps only cases that contain the activity; apply positional filter
    if strict:
        result_lf = (
            lf_idx
            .join(pivot_pos, on=case_id_key, how="inner")
            .filter(pl.col("_pos") > pl.col("_cut"))
            .drop(["_pos", "_cut"])
        )
    else:
        result_lf = (
            lf_idx
            .join(pivot_pos, on=case_id_key, how="inner")
            .filter(pl.col("_pos") >= pl.col("_cut"))
            .drop(["_pos", "_cut"])
        )

    return result_lf if is_lazy else result_lf.collect()



# ══════════════════════════════════════════════════════════════════════
# Path performance
# ══════════════════════════════════════════════════════════════════════

def filter_paths_performance(
    log: pl.LazyFrame,
    path: Tuple[str, str],
    min_performance: float,
    max_performance: float,
    keep: bool = True,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
) -> pl.LazyFrame:
    """Filter cases based on the elapsed time (seconds) of a directly-follows path.

    Retains (keep=True) or removes (keep=False) cases whose path
    (source_activity → target_activity) has duration in [min_performance, max_performance].

    Parameters
    ----------
    path            : (source_activity, target_activity) tuple.
    min_performance : Minimum path duration in seconds.
    max_performance : Maximum path duration in seconds.
    keep            : If True keep matching cases; if False remove them.
    """
    src, tgt = path
    is_lazy = isinstance(log, pl.LazyFrame)
    lf = log if is_lazy else log.lazy()

    lf_sorted = lf.sort([case_id_key, timestamp_key])

    # Create consecutive-pair frame: each row paired with its successor
    pairs = (
        lf_sorted
        .with_columns([
            pl.col(activity_key).alias("_src"),
            pl.col(timestamp_key).alias("_src_ts"),
            pl.col(activity_key).shift(-1).over(case_id_key).alias("_tgt"),
            pl.col(timestamp_key).shift(-1).over(case_id_key).alias("_tgt_ts"),
        ])
        .filter(
            (pl.col("_src") == src)
            & (pl.col("_tgt") == tgt)
        )
        .with_columns(
            (pl.col("_tgt_ts") - pl.col("_src_ts")).dt.total_seconds().alias("_dur")
        )
        .filter(
            (pl.col("_dur") >= min_performance) & (pl.col("_dur") <= max_performance)
        )
        .select(case_id_key)
        .unique()
    )

    if keep:
        result = lf.join(pairs, on=case_id_key, how="semi")
    else:
        result = lf.join(pairs, on=case_id_key, how="anti")

    return result if is_lazy else result.collect()


# ══════════════════════════════════════════════════════════════════════
# Activity done by different resources
# ══════════════════════════════════════════════════════════════════════

def filter_activity_done_different_resources(
    log: pl.LazyFrame,
    activity: str,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
    resource_key: str = "org:resource",
    keep_violations: bool = True,
) -> pl.LazyFrame:
    """Filter cases where *activity* is performed by more than one distinct resource.

    Parameters
    ----------
    keep_violations : If True keep violating cases; if False remove them.
    """
    is_lazy = isinstance(log, pl.LazyFrame)
    lf = log if is_lazy else log.lazy()

    # Cases where the activity is executed by >= 2 distinct resources
    violating_ids = (
        lf.filter(pl.col(activity_key) == activity)
        .group_by(case_id_key)
        .agg(pl.col(resource_key).n_unique().alias("_n_res"))
        .filter(pl.col("_n_res") >= 2)
        .select(case_id_key)
    )

    if keep_violations:
        result = lf.join(violating_ids, on=case_id_key, how="semi")
    else:
        result = lf.join(violating_ids, on=case_id_key, how="anti")

    return result if is_lazy else result.collect()


# ══════════════════════════════════════════════════════════════════════
# Trace segments
# ══════════════════════════════════════════════════════════════════════

def filter_trace_segments(
    log: pl.LazyFrame,
    admitted_traces: List[List[str]],
    positive: bool = True,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
) -> pl.LazyFrame:
    """Filter cases by trace segment patterns.

    A segment is a list of activity strings optionally containing ``"..."`` as
    a wildcard meaning "any number of other activities".

    Examples
    --------
    * ``[["A", "B"]]``          – exact variant A → B.
    * ``[["...", "A", "B"]]``   – cases ending with A → B.
    * ``[["A", "B", "..."]]``   – cases starting with A → B.
    * ``[["...", "A", "B", "...", "C", "D", "..."]]`` – multi-segment match.

    All supplied segments must be satisfied simultaneously for a case to match.

    Parameters
    ----------
    admitted_traces : List of segment patterns (each a list of strings).
    positive        : If True keep matching cases; if False remove them.
    """
    WILDCARD = "..."
    separator = "\x00"
    escaped_separator = re.escape(separator)
    token_pattern = rf"[^{escaped_separator}]+"

    def _segment_to_regex(segment: list[str]) -> str:
        if not segment:
            return r".*"

        parts: list[list[str]] = [[]]
        for token in segment:
            if token == WILDCARD:
                parts.append([])
            else:
                parts[-1].append(token)

        parts = [part for part in parts if part]
        if not parts:
            return r".*"

        prefix_free = segment[0] == WILDCARD
        suffix_free = segment[-1] == WILDCARD
        encoded_parts = [
            separator.join(re.escape(token) for token in part)
            for part in parts
        ]

        start_boundary = rf"(?:^|{escaped_separator})" if prefix_free else r"^"
        end_boundary = rf"(?:$|{escaped_separator})" if suffix_free else r"$"
        gap = rf"(?:{escaped_separator}{token_pattern})*{escaped_separator}"

        return start_boundary + gap.join(encoded_parts) + end_boundary

    is_lazy = isinstance(log, pl.LazyFrame)
    lf = log if is_lazy else log.lazy()
    case_variants = (
        lf.sort([case_id_key, timestamp_key])
        .group_by(case_id_key)
        .agg(pl.col(activity_key).cast(pl.Utf8).str.join(separator).alias("_variant"))
    )

    if admitted_traces:
        matched_variants = (
            case_variants
            .select("_variant")
            .unique()
            .filter(
                pl.all_horizontal(
                    [pl.col("_variant").str.contains(_segment_to_regex(segment)) for segment in admitted_traces]
                )
            )
        )
        matched_ids = (
            case_variants
            .join(matched_variants, on="_variant", how="semi")
            .select(case_id_key)
        )
    else:
        matched_ids = case_variants.select(case_id_key)

    result = (
        lf.join(matched_ids, on=case_id_key, how="semi")
        if positive
        else lf.join(matched_ids, on=case_id_key, how="anti")
    )
    return result if is_lazy else result.collect()


__all__ = [
    "filter_start_activities",
    "filter_end_activities",
    "filter_activities_duration",
    "filter_event_attribute_values",
    "filter_trace_attribute_values",
    "filter_variants",
    "filter_directly_follows_relation",
    "filter_eventually_follows_relation",
    "filter_time_range",
    "filter_case_performance",
    "filter_case_size",
    "filter_between",
    "filter_activities_rework",
    "filter_prefixes",
    "filter_four_eyes_principle",
    # New methods
    "filter_log_relative_occurrence_event_attribute",
    "filter_variants_top_k",
    "filter_variants_by_coverage_percentage",
    "filter_suffixes",
    "filter_paths_performance",
    "filter_activity_done_different_resources",
    "filter_trace_segments",
]
