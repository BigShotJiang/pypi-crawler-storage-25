"""pl4pm.vis — Visualization module.

Uses graphviz for graph-based visualizations and matplotlib/plotly for charts.
All view_* functions display; all save_vis_* functions save to file.
"""

from __future__ import annotations

import math
import os
import subprocess
import tempfile
from html import escape as _html_escape
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple, Union

from pl4pm.objects.petri_net import PetriNet, Marking
from pl4pm.objects.process_tree import ProcessTree, Operator, from_any_process_tree
from pl4pm.objects.bpmn import BPMN
from pl4pm.objects.heuristics_net import HeuristicsNet
from pl4pm.objects.trie import Trie, TrieNode
from pl4pm.objects.transition_system import TransitionSystem
from pl4pm.objects.ocel import OCEL
from pl4pm.constants import CASE_ID_KEY, ACTIVITY_KEY, TIMESTAMP_KEY

import polars as pl

_PLT = None


def _get_matplotlib_pyplot():
    global _PLT
    if _PLT is not None:
        return _PLT
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        _PLT = plt
        return plt
    except ImportError:
        raise ImportError("matplotlib is required for static chart export. Install with: pip install matplotlib")


def _save_simple_matplotlib_chart(
    file_path: str,
    kind: str,
    x,
    y,
    *,
    title: str,
    xlabel: str,
    ylabel: str,
    color_by=None,
    show_legend: bool = True,
) -> None:
    plt = _get_matplotlib_pyplot()
    fig, ax = plt.subplots(figsize=(8, 4.5), dpi=100)
    try:
        if kind == "line":
            ax.plot(x, y, color="#4e79a7", linewidth=1.8)
        elif kind == "bar":
            ax.bar(x, y, color="#4e79a7", width=0.8)
        elif kind == "scatter":
            if color_by is None:
                ax.scatter(x, y, s=8, c="#4e79a7", alpha=0.75, linewidths=0, rasterized=True)
            else:
                series = pl.Series("color", color_by).fill_null("N/A")
                categories = series.unique(maintain_order=True).to_list()
                cat_to_idx = {value: idx for idx, value in enumerate(categories)}
                encoded = [cat_to_idx.get(value, 0) for value in series.to_list()]
                cmap = plt.get_cmap("tab20", max(len(categories), 1))
                ax.scatter(x, y, s=8, c=encoded, cmap=cmap, alpha=0.75, linewidths=0, rasterized=True)
                if show_legend and categories:
                    handles = [
                        plt.Line2D(
                            [0], [0],
                            marker="o",
                            linestyle="",
                            color=cmap(idx % cmap.N),
                            label=str(value),
                            markersize=5,
                        )
                        for idx, value in enumerate(categories[:20])
                    ]
                    ax.legend(handles=handles, loc="best", fontsize=8)

        ax.set_title(title)
        ax.set_xlabel(xlabel)
        ax.set_ylabel(ylabel)
        fig.subplots_adjust(left=0.11, right=0.98, top=0.90, bottom=0.16)
        fig.savefig(file_path, bbox_inches="tight")
    finally:
        plt.close(fig)


# ══════════════════════════════════════════════════════════════════════
# Graphviz helpers
# ══════════════════════════════════════════════════════════════════════

def _get_graphviz():
    """Import graphviz or raise a helpful error."""
    try:
        import graphviz
        return graphviz
    except ImportError:
        raise ImportError("graphviz is required for visualization. Install with: pip install graphviz")


def _gv_q(value: Any) -> str:
    text = str(value)
    text = text.replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n")
    return f'"{text}"'


def _render_gv(gv, file_path: Optional[str] = None, format: str = "png") -> Any:
    """Render a graphviz object: save to file or display."""
    if format == "gv":
        if file_path:
            with open(file_path, "w") as f:
                f.write(gv.source)
            return
        return gv.source

    if file_path:
        ext = file_path.rsplit(".", 1)[-1] if "." in file_path else format
        if ext == "html":
            Path(file_path).write_text(f"<pre>{gv.source}</pre>", encoding="utf-8")
            return
        engine = getattr(gv, "engine", None) or "dot"
        try:
            subprocess.run(
                [engine, f"-T{ext}", "-o", file_path],
                input=gv.source,
                text=True,
                capture_output=True,
                check=True,
            )
        except Exception:
            payload = gv.pipe(format=ext)
            Path(file_path).write_bytes(payload)
    else:
        gv.render(tempfile.mktemp(), format=format, view=True, cleanup=True)


def _sample_frame_for_plot(df: pl.DataFrame, max_points: int = 50_000) -> pl.DataFrame:
    if df.height <= max_points:
        return df
    stride = max(1, math.ceil(df.height / max_points))
    return (
        df.with_row_index("_row_nr")
        .filter((pl.col("_row_nr") % stride) == 0)
        .drop("_row_nr")
    )


def _make_plotly_figure(x, y, *, kind: str, title: str, xlabel: str, ylabel: str, color=None, show_legend: bool = True):
    try:
        import plotly.graph_objects as go
    except ImportError:
        raise ImportError("plotly required.")

    if kind == "scatter":
        trace = go.Scattergl(
            x=x,
            y=y,
            mode="markers",
            marker=dict(size=5, opacity=0.75),
            text=color,
            name=str(color[0]) if color else None,
            showlegend=show_legend and color is not None,
        )
    elif kind == "line":
        trace = go.Scatter(x=x, y=y, mode="lines", line=dict(color="#4e79a7", width=1.8), showlegend=False)
    else:
        trace = go.Bar(x=x, y=y, marker=dict(color="#4e79a7"), showlegend=False)

    fig = go.Figure([trace])
    fig.update_layout(
        title=title,
        xaxis_title=xlabel,
        yaxis_title=ylabel,
        template="plotly_white",
        showlegend=show_legend,
    )
    return fig


def _svg_polyline_html(
    file_path: str,
    segments: list[tuple[Any, Any, int, int]],
    labels: list[str],
    title: str,
) -> None:
    width = 1100
    height = 460
    left = 80
    right = 20
    top = 40
    bottom = 40
    inner_width = width - left - right
    inner_height = height - top - bottom
    if not segments:
        svg = f'<svg width="{width}" height="{height}" xmlns="http://www.w3.org/2000/svg"></svg>'
        Path(file_path).write_text(f"<html><body>{svg}</body></html>", encoding="utf-8")
        return

    def _x_numeric(value: Any) -> float:
        if hasattr(value, "timestamp"):
            return float(value.timestamp())
        return float(value)

    xs = [_x_numeric(value) for seg in segments for value in (seg[0], seg[1])]
    min_x = min(xs)
    max_x = max(xs)
    x_span = max(max_x - min_x, 1.0)
    y_den = max(len(labels) - 1, 1)

    parts = [
        f'<svg width="{width}" height="{height}" xmlns="http://www.w3.org/2000/svg">',
        f'<text x="{left}" y="24" font-size="18" font-family="sans-serif">{_html_escape(title)}</text>',
        f'<rect x="{left}" y="{top}" width="{inner_width}" height="{inner_height}" fill="white" stroke="#cfcfcf"/>',
    ]
    for idx, label in enumerate(labels):
        y = top + inner_height - (idx / y_den) * inner_height
        parts.append(f'<line x1="{left}" y1="{y:.2f}" x2="{left + inner_width}" y2="{y:.2f}" stroke="#f0f0f0"/>')
        parts.append(f'<text x="{left - 8}" y="{y + 4:.2f}" font-size="11" text-anchor="end" font-family="sans-serif">{_html_escape(str(label))}</text>')
    for x0, x1, y0, y1 in segments:
        x0_num = _x_numeric(x0)
        x1_num = _x_numeric(x1)
        px0 = left + ((x0_num - min_x) / x_span) * inner_width
        px1 = left + ((x1_num - min_x) / x_span) * inner_width
        py0 = top + inner_height - (y0 / y_den) * inner_height
        py1 = top + inner_height - (y1 / y_den) * inner_height
        parts.append(
            f'<line x1="{px0:.2f}" y1="{py0:.2f}" x2="{px1:.2f}" y2="{py1:.2f}" stroke="rgba(78,121,167,0.28)" stroke-width="1"/>'
        )
    parts.append("</svg>")
    Path(file_path).write_text("<html><body>" + "".join(parts) + "</body></html>", encoding="utf-8")


def _svg_bar_chart_html(file_path: str, x_labels: list[Any], y_values: list[float], title: str, xlabel: str, ylabel: str) -> None:
    width = 1100
    height = 460
    left = 80
    right = 20
    top = 40
    bottom = 70
    inner_width = width - left - right
    inner_height = height - top - bottom
    max_y = max(y_values) if y_values else 1
    bar_width = inner_width / max(len(y_values), 1)
    parts = [
        f'<svg width="{width}" height="{height}" xmlns="http://www.w3.org/2000/svg">',
        f'<text x="{left}" y="24" font-size="18" font-family="sans-serif">{_html_escape(title)}</text>',
        f'<rect x="{left}" y="{top}" width="{inner_width}" height="{inner_height}" fill="white" stroke="#cfcfcf"/>',
        f'<text x="{left + inner_width / 2:.2f}" y="{height - 10}" font-size="12" text-anchor="middle" font-family="sans-serif">{_html_escape(xlabel)}</text>',
        f'<text x="18" y="{top + inner_height / 2:.2f}" font-size="12" text-anchor="middle" font-family="sans-serif" transform="rotate(-90,18,{top + inner_height / 2:.2f})">{_html_escape(ylabel)}</text>',
    ]
    for idx, value in enumerate(y_values):
        x = left + idx * bar_width
        bar_h = 0 if max_y == 0 else (value / max_y) * inner_height
        y = top + inner_height - bar_h
        parts.append(
            f'<rect x="{x + 1:.2f}" y="{y:.2f}" width="{max(bar_width - 2, 1):.2f}" height="{bar_h:.2f}" fill="#4e79a7"/>'
        )
        if len(x_labels) <= 60:
            parts.append(
                f'<text x="{x + bar_width / 2:.2f}" y="{top + inner_height + 14}" font-size="9" text-anchor="middle" font-family="sans-serif">{_html_escape(str(x_labels[idx]))}</text>'
            )
    parts.append("</svg>")
    Path(file_path).write_text("<html><body>" + "".join(parts) + "</body></html>", encoding="utf-8")


# ══════════════════════════════════════════════════════════════════════
# Petri Net
# ══════════════════════════════════════════════════════════════════════

def _build_pn_gv(
    net: PetriNet,
    im: Optional[Marking] = None,
    fm: Optional[Marking] = None,
    bgcolor: str = "white",
    decorations: Optional[Dict] = None,
    debug: bool = False,
    rankdir: str = "LR",
    graph_title: Optional[str] = None,
):
    gv = _get_graphviz()
    g = gv.Digraph("petri_net", engine="dot")
    g.attr(rankdir=rankdir, bgcolor=bgcolor)
    if graph_title:
        g.attr(label=graph_title, labelloc="t", fontsize="18")

    im = im or Marking()
    fm = fm or Marking()
    decos = decorations or {}

    for place in net.places:
        label = str(im.get(place, 0)) if im.get(place, 0) > 0 else ""
        if debug:
            label = place.name
        color = "green" if im.get(place, 0) > 0 else ("orange" if fm.get(place, 0) > 0 else "white")
        pn_decos = decos.get(place, {})
        g.node(place.name, label=label, shape="circle",
               style="filled", fillcolor=pn_decos.get("color", color),
               width="0.5", height="0.5")

    for trans in net.transitions:
        if trans.is_silent:
            g.node(trans.name, label="" if not debug else trans.name,
                   shape="box", style="filled", fillcolor="black",
                   width="0.3", height="0.3")
        else:
            label = decos.get(trans, {}).get("label", trans.label or trans.name)
            color = decos.get(trans, {}).get("color", "#a4c2f4")
            g.node(trans.name, label=label, shape="box",
                   style="filled", fillcolor=color)

    for arc in net.arcs:
        src_name = arc.source.name
        tgt_name = arc.target.name
        label = str(arc.weight) if arc.weight > 1 else ""
        g.edge(src_name, tgt_name, label=label)

    return g


def view_petri_net(
    petri_net: PetriNet,
    initial_marking: Optional[Marking] = None,
    final_marking: Optional[Marking] = None,
    format: str = "png",
    bgcolor: str = "white",
    decorations: Optional[Dict] = None,
    debug: bool = False,
    rankdir: str = "LR",
    graph_title: Optional[str] = None,
    **kwargs,
) -> None:
    """View a Petri net."""
    g = _build_pn_gv(petri_net, initial_marking, final_marking, bgcolor,
                      decorations, debug, rankdir, graph_title)
    _render_gv(g, format=format)


def save_vis_petri_net(
    petri_net: PetriNet,
    initial_marking: Marking,
    final_marking: Marking,
    file_path: str,
    bgcolor: str = "white",
    decorations: Optional[Dict] = None,
    debug: bool = False,
    rankdir: str = "LR",
    graph_title: Optional[str] = None,
    **kwargs,
) -> None:
    """Save a Petri net visualization to file."""
    g = _build_pn_gv(petri_net, initial_marking, final_marking, bgcolor,
                      decorations, debug, rankdir, graph_title)
    _render_gv(g, file_path=file_path)


# ══════════════════════════════════════════════════════════════════════
# DFG
# ══════════════════════════════════════════════════════════════════════

def _build_dfg_gv(
    dfg: dict,
    start_activities: dict,
    end_activities: dict,
    bgcolor: str = "white",
    max_num_edges: int = 2**63,
    rankdir: str = "LR",
    graph_title: Optional[str] = None,
    is_performance: bool = False,
    aggregation_measure: str = "mean",
    serv_time: Optional[Dict[str, float]] = None,
):
    gv = _get_graphviz()
    g = gv.Digraph("dfg", engine="dot")
    g.attr(rankdir=rankdir, bgcolor=bgcolor)
    if graph_title:
        g.attr(label=graph_title, labelloc="t", fontsize="18")

    # Collect activities
    all_acts: set = set()
    for (a, b) in dfg:
        all_acts.add(a)
        all_acts.add(b)
    all_acts.update(start_activities.keys())
    all_acts.update(end_activities.keys())

    # Frequency range for coloring
    values = list(dfg.values())
    if is_performance:
        vals_flat = []
        for v in values:
            if isinstance(v, dict):
                vals_flat.append(v.get(aggregation_measure, 0))
            else:
                vals_flat.append(v)
        values = vals_flat
    max_val = max(values) if values else 1
    min_val = min(values) if values else 0

    # Source/sink nodes
    g.node("@@source", label="●", shape="circle", style="filled",
           fillcolor="green", width="0.3", fontsize="10")
    g.node("@@sink", label="■", shape="doublecircle", style="filled",
           fillcolor="orange", width="0.3", fontsize="10")

    # Activity nodes
    # Calculate occurrences for nodes to display them as "A (1000)"
    activities_count = {act: int(start_activities.get(act, 0)) for act in all_acts}
    for (_, target), freq in dfg.items():
        activities_count[target] = activities_count.get(target, 0) + int(freq)

    for act in all_acts:
        label = f"{act} ({activities_count[act]})"
        if serv_time and act in serv_time:
            label += f"\n({_format_time(serv_time[act])})"
        g.node(act, label=label, shape="box", style="filled,rounded",
               fillcolor="#a4c2f4")

    # Start/end edges
    for act, freq in start_activities.items():
        edge_label = "0 s" if is_performance else str(freq)
        g.edge("@@source", act, label=edge_label)
    for act, freq in end_activities.items():
        edge_label = "0 s" if is_performance else str(freq)
        g.edge(act, "@@sink", label=edge_label)

    # DFG edges (limit to max_num_edges)
    sorted_edges = sorted(dfg.items(), key=lambda x: -(_edge_val(x[1], aggregation_measure)))
    for i, ((a, b), val) in enumerate(sorted_edges):
        if i >= max_num_edges:
            break
        if is_performance:
            if isinstance(val, dict):
                label = _format_time(val.get(aggregation_measure, 0))
            else:
                label = _format_time(val)
        else:
            label = str(val)

        # Color intensity
        norm = (_edge_val(val, aggregation_measure) - min_val) / max(max_val - min_val, 1)
        width = str(1.0 + 2.0 * norm)
        color = f"0.6 {0.2 + 0.8 * norm:.2f} 0.9"
        g.edge(a, b, label=label, penwidth=width, color=color)

    return g


def _edge_val(val, agg="mean"):
    if isinstance(val, dict):
        return val.get(agg, 0)
    return val


def _format_time(seconds: float) -> str:
    """Format seconds into human-readable duration."""
    if seconds is None:
        return "N/A"
    seconds = abs(seconds)
    if seconds < 60:
        return f"{seconds:.1f}s"
    if seconds < 3600:
        return f"{seconds / 60:.1f}m"
    if seconds < 86400:
        return f"{seconds / 3600:.1f}h"
    return f"{seconds / 86400:.1f}d"


def view_dfg(
    dfg: dict, start_activities: dict, end_activities: dict,
    format: str = "png", bgcolor: str = "white",
    max_num_edges: int = 2**63, rankdir: str = "LR",
    graph_title: Optional[str] = None,
) -> None:
    """View a frequency DFG."""
    g = _build_dfg_gv(dfg, start_activities, end_activities, bgcolor,
                       max_num_edges, rankdir, graph_title)
    _render_gv(g, format=format)


def save_vis_dfg(
    dfg: dict, start_activities: dict, end_activities: dict,
    file_path: str, bgcolor: str = "white",
    max_num_edges: int = 2**63, rankdir: str = "LR",
    graph_title: Optional[str] = None, **kwargs,
) -> None:
    """Save a DFG visualization."""
    g = _build_dfg_gv(dfg, start_activities, end_activities, bgcolor,
                       max_num_edges, rankdir, graph_title)
    _render_gv(g, file_path=file_path)


def save_vis_dfg_pyvis(
    dfg: dict, start_activities: dict, end_activities: dict,
    file_path: str, bgcolor: str = "#ffffff",
    max_num_edges: int = 2**63,
    graph_title: str = "DFG (Interactive PyVis)", **kwargs,
) -> None:
    """Save an interactive DFG visualization using PyVis (returns an HTML file)."""
    try:
        from pyvis.network import Network
    except ImportError:
        raise ImportError("PyVis is required for interactive visualization. Install with: pip install pyvis")

    net = Network(height="750px", width="100%", bgcolor=bgcolor, font_color="black", directed=True)
    if graph_title:
        net.heading = graph_title

    all_acts: set = set()
    for (a, b) in dfg:
        all_acts.add(a)
        all_acts.add(b)
    all_acts.update(start_activities.keys())
    all_acts.update(end_activities.keys())

    activities_count = {}
    for act in all_acts:
        count = start_activities.get(act, 0)
        for (u, v), freq in dfg.items():
            if v == act:
                count += freq
        activities_count[act] = count

    # Nodes
    net.add_node("@@source", label="START", shape="circle", color="lightgreen", size=25)
    net.add_node("@@sink", label="END", shape="circle", color="orange", size=25)
    
    for act in all_acts:
        label = f"{act} ({activities_count[act]})"
        net.add_node(act, label=label, shape="box", color="#a4c2f4")

    # Edges
    for act, freq in start_activities.items():
        net.add_edge("@@source", act, title=str(freq), label=str(freq), color="green", width=2)
    for act, freq in end_activities.items():
        net.add_edge(act, "@@sink", title=str(freq), label=str(freq), color="darkorange", width=2)

    for i, ((a, b), val) in enumerate(sorted(dfg.items(), key=lambda x: -x[1])):
        if i >= max_num_edges: break
        net.add_edge(a, b, title=str(val), label=str(val), color="gray", width=2)

    net.toggle_physics(True)
    net.write_html(file_path)


def view_performance_dfg(
    dfg: dict, start_activities: dict, end_activities: dict,
    format: str = "png", aggregation_measure: str = "mean",
    bgcolor: str = "white", rankdir: str = "LR",
    serv_time: Optional[Dict[str, float]] = None,
    graph_title: Optional[str] = None,
) -> None:
    """View a performance DFG."""
    g = _build_dfg_gv(dfg, start_activities, end_activities, bgcolor,
                       2**63, rankdir, graph_title, is_performance=True,
                       aggregation_measure=aggregation_measure, serv_time=serv_time)
    _render_gv(g, format=format)


def save_vis_performance_dfg(
    dfg: dict, start_activities: dict, end_activities: dict,
    file_path: str, aggregation_measure: str = "mean",
    bgcolor: str = "white", rankdir: str = "LR",
    serv_time: Optional[Dict[str, float]] = None,
    graph_title: Optional[str] = None, **kwargs,
) -> None:
    """Save a performance DFG visualization."""
    g = _build_dfg_gv(dfg, start_activities, end_activities, bgcolor,
                       2**63, rankdir, graph_title, is_performance=True,
                       aggregation_measure=aggregation_measure, serv_time=serv_time)
    _render_gv(g, file_path=file_path)


# ══════════════════════════════════════════════════════════════════════
# Process Tree
# ══════════════════════════════════════════════════════════════════════

_OP_SYMBOLS = {
    Operator.SEQUENCE: "→",
    Operator.XOR: "×",
    Operator.PARALLEL: "+",
    Operator.LOOP: "↺",
    Operator.OR: "∨",
}


def _build_pt_gv(
    tree: ProcessTree,
    bgcolor: str = "white",
    rankdir: str = "LR",
    graph_title: Optional[str] = None,
):
    tree = from_any_process_tree(tree)
    gv = _get_graphviz()
    g = gv.Digraph("process_tree", engine="dot")
    g.attr(rankdir=rankdir, bgcolor=bgcolor)
    if graph_title:
        g.attr(label=graph_title, labelloc="t", fontsize="18")

    _counter = [0]

    def _add_node(node: ProcessTree, parent_id: Optional[str] = None) -> str:
        _counter[0] += 1
        nid = str(_counter[0])
        if node.is_leaf:
            label = node.label if node.label else "τ"
            g.node(nid, label=label, shape="box", style="filled,rounded",
                   fillcolor="#a4c2f4")
        else:
            symbol = _OP_SYMBOLS.get(node.operator, "?")
            g.node(nid, label=symbol, shape="circle", style="filled",
                   fillcolor="#f4b084", width="0.5", fontsize="16")
        if parent_id:
            g.edge(parent_id, nid)
        for child in node.children:
            _add_node(child, nid)
        return nid

    _add_node(tree)
    return g


def view_process_tree(
    tree: ProcessTree, format: str = "png", bgcolor: str = "white",
    rankdir: str = "LR", graph_title: Optional[str] = None,
) -> None:
    g = _build_pt_gv(tree, bgcolor, rankdir, graph_title)
    _render_gv(g, format=format)


def save_vis_process_tree(
    tree: ProcessTree, file_path: str, bgcolor: str = "white",
    rankdir: str = "LR", graph_title: Optional[str] = None, **kwargs,
) -> None:
    g = _build_pt_gv(tree, bgcolor, rankdir, graph_title)
    _render_gv(g, file_path=file_path)


# ══════════════════════════════════════════════════════════════════════
# BPMN
# ══════════════════════════════════════════════════════════════════════

_BPMN_SHAPES = {
    BPMN.NodeType.START_EVENT: ("circle", "#66bb6a", "●"),
    BPMN.NodeType.END_EVENT: ("doublecircle", "#ef5350", "■"),
    BPMN.NodeType.TASK: ("box", "#a4c2f4", None),
    BPMN.NodeType.EXCLUSIVE_GATEWAY: ("diamond", "#fff176", "×"),
    BPMN.NodeType.PARALLEL_GATEWAY: ("diamond", "#fff176", "+"),
    BPMN.NodeType.INCLUSIVE_GATEWAY: ("diamond", "#fff176", "○"),
}


def _build_bpmn_gv(
    bpmn: BPMN, bgcolor: str = "white", rankdir: str = "LR",
    graph_title: Optional[str] = None,
):
    gv = _get_graphviz()
    lines = ["digraph bpmn {", f"rankdir={rankdir};", f'bgcolor={_gv_q(bgcolor)};']
    if graph_title:
        lines.append(f'label={_gv_q(graph_title)}; labelloc="t"; fontsize="18";')
    for node in bpmn.nodes:
        shape, color, symbol = _BPMN_SHAPES.get(
            node.node_type, ("box", "#cccccc", None))
        label = symbol if symbol else node.name
        lines.append(
            f"{_gv_q(node.id)} [label={_gv_q(label)}, shape={shape}, style=filled, fillcolor={_gv_q(color)}];"
        )

    for flow in bpmn.flows:
        edge = f"{_gv_q(flow.source.id)} -> {_gv_q(flow.target.id)}"
        if flow.name:
            edge += f" [label={_gv_q(flow.name)}]"
        lines.append(edge + ";")
    lines.append("}")
    return gv.Source("\n".join(lines), engine="dot")


def view_bpmn(
    bpmn_graph: BPMN, format: str = "png", bgcolor: str = "white",
    rankdir: str = "LR", variant_str: str = "classic",
    graph_title: Optional[str] = None,
) -> None:
    g = _build_bpmn_gv(bpmn_graph, bgcolor, rankdir, graph_title)
    _render_gv(g, format=format)


def save_vis_bpmn(
    bpmn_graph: BPMN, file_path: str, bgcolor: str = "white",
    rankdir: str = "LR", variant_str: str = "classic",
    graph_title: Optional[str] = None, **kwargs,
) -> None:
    g = _build_bpmn_gv(bpmn_graph, bgcolor, rankdir, graph_title)
    _render_gv(g, file_path=file_path)


# ══════════════════════════════════════════════════════════════════════
# Heuristics Net
# ══════════════════════════════════════════════════════════════════════

def _build_hnet_gv(
    hnet: HeuristicsNet, bgcolor: str = "white",
    graph_title: Optional[str] = None,
):
    gv = _get_graphviz()
    g = gv.Digraph("heuristics_net", engine="dot")
    g.attr(rankdir="LR", bgcolor=bgcolor)
    if graph_title:
        g.attr(label=graph_title, labelloc="t", fontsize="18")

    for act in hnet.activities:
        occ = hnet.activities_occurrences.get(act, 0)
        g.node(act, label=f"{act}\n({occ})", shape="box",
               style="filled,rounded", fillcolor="#a4c2f4")

    for (a, b), freq in hnet.dfg.items():
        dep = hnet.dependency_matrix.get(a, {}).get(b, 0.0)
        g.edge(a, b, label=f"{freq} ({dep:.2f})")

    return g


def view_heuristics_net(
    heu_net: HeuristicsNet, format: str = "png", bgcolor: str = "white",
    graph_title: Optional[str] = None,
) -> None:
    g = _build_hnet_gv(heu_net, bgcolor, graph_title)
    _render_gv(g, format=format)


def save_vis_heuristics_net(
    heu_net: HeuristicsNet, file_path: str, bgcolor: str = "white",
    graph_title: Optional[str] = None, **kwargs,
) -> None:
    g = _build_hnet_gv(heu_net, bgcolor, graph_title)
    _render_gv(g, file_path=file_path)


# ══════════════════════════════════════════════════════════════════════
# Transition System
# ══════════════════════════════════════════════════════════════════════

def _build_ts_gv(
    ts: TransitionSystem, bgcolor: str = "white",
    graph_title: Optional[str] = None,
):
    gv = _get_graphviz()
    lines = ['digraph transition_system {', 'rankdir=LR;', f'bgcolor={_gv_q(bgcolor)};']
    if graph_title:
        lines.append(f'label={_gv_q(graph_title)}; labelloc="t"; fontsize="18";')
    for state in ts.states:
        lines.append(
            f'{_gv_q(state.name)} [label={_gv_q(state.name)}, shape=ellipse, style=filled, fillcolor="#e8eaf6"];'
        )

    for trans in ts.transitions:
        lines.append(
            f"{_gv_q(trans.source.name)} -> {_gv_q(trans.target.name)} [label={_gv_q(trans.name)}];"
        )
    lines.append("}")
    return gv.Source("\n".join(lines), engine="dot")


def view_transition_system(
    transition_system: TransitionSystem, format: str = "png",
    bgcolor: str = "white", graph_title: Optional[str] = None,
) -> None:
    g = _build_ts_gv(transition_system, bgcolor, graph_title)
    _render_gv(g, format=format)


def save_vis_transition_system(
    transition_system: TransitionSystem, file_path: str,
    bgcolor: str = "white", graph_title: Optional[str] = None, **kwargs,
) -> None:
    g = _build_ts_gv(transition_system, bgcolor, graph_title)
    _render_gv(g, file_path=file_path)


# ══════════════════════════════════════════════════════════════════════
# Prefix Tree (Trie)
# ══════════════════════════════════════════════════════════════════════

def _build_trie_gv(
    trie: Trie, bgcolor: str = "white",
    graph_title: Optional[str] = None,
):
    gv = _get_graphviz()
    lines = ['digraph prefix_tree {', 'rankdir=TB;', f'bgcolor={_gv_q(bgcolor)};']
    if graph_title:
        lines.append(f'label={_gv_q(graph_title)}; labelloc="t"; fontsize="18";')

    _counter = [0]

    def _label_of(node) -> str:
        raw = getattr(node, "label", None)
        return str(raw) if raw is not None else "ROOT"

    def _count_of(node) -> Optional[int]:
        return getattr(node, "count", None)

    def _is_end(node) -> bool:
        return bool(getattr(node, "is_end", getattr(node, "final", False)))

    def _children_of(node):
        raw_children = getattr(node, "children", {})
        if isinstance(raw_children, dict):
            return raw_children.values()
        return raw_children

    def _add(node, parent_id: Optional[str] = None):
        _counter[0] += 1
        nid = str(_counter[0])
        count = _count_of(node)
        label = _label_of(node) if count is None else f"{_label_of(node)}\n({count})"
        color = "#c8e6c9" if _is_end(node) else "#e3f2fd"
        lines.append(
            f'{_gv_q(nid)} [label={_gv_q(label)}, shape=box, style="filled,rounded", fillcolor={_gv_q(color)}];'
        )
        if parent_id:
            lines.append(f"{_gv_q(parent_id)} -> {_gv_q(nid)};")
        for child in _children_of(node):
            _add(child, nid)

    _add(trie.root if hasattr(trie, "root") else trie)
    lines.append("}")
    return gv.Source("\n".join(lines), engine="dot")


def view_prefix_tree(
    trie: Trie, format: str = "png", bgcolor: str = "white",
    graph_title: Optional[str] = None,
) -> None:
    g = _build_trie_gv(trie, bgcolor, graph_title)
    _render_gv(g, format=format)


def save_vis_prefix_tree(
    trie: Trie, file_path: str, bgcolor: str = "white",
    graph_title: Optional[str] = None, **kwargs,
) -> None:
    g = _build_trie_gv(trie, bgcolor, graph_title)
    _render_gv(g, file_path=file_path)


# ══════════════════════════════════════════════════════════════════════
# Footprints
# ══════════════════════════════════════════════════════════════════════

def _build_footprints_gv(
    footprints: Dict[str, Any], bgcolor: str = "white",
    graph_title: Optional[str] = None,
):
    gv = _get_graphviz()
    g = gv.Digraph("footprints", engine="neato")
    g.attr(bgcolor=bgcolor)
    if graph_title:
        g.attr(label=graph_title, labelloc="t", fontsize="18")

    acts = sorted(footprints.get("activities", set()))
    for act in acts:
        g.node(act, label=act, shape="box", style="filled,rounded",
               fillcolor="#a4c2f4")

    for (a, b) in footprints.get("sequence", set()):
        g.edge(a, b, color="blue", label="→")
    for (a, b) in footprints.get("parallel", set()):
        if a < b:
            g.edge(a, b, color="green", dir="both", label="||")

    return g


def view_footprints(
    footprints, format: str = "png", graph_title: Optional[str] = None,
) -> None:
    fp = footprints if isinstance(footprints, dict) else footprints[0]
    g = _build_footprints_gv(fp, graph_title=graph_title)
    _render_gv(g, format=format)


def save_vis_footprints(
    footprints, file_path: str, graph_title: Optional[str] = None, **kwargs,
) -> None:
    fp = footprints if isinstance(footprints, dict) else footprints[0]
    g = _build_footprints_gv(fp, graph_title=graph_title)
    _render_gv(g, file_path=file_path)


# ══════════════════════════════════════════════════════════════════════
# Dotted Chart
# ══════════════════════════════════════════════════════════════════════

def _build_dotted_chart(
    log: pl.LazyFrame,
    attributes: Optional[List[str]] = None,
    bgcolor: str = "white",
    show_legend: bool = True,
    graph_title: Optional[str] = None,
) -> str:
    """Build dotted chart as SVG using plotly."""
    df = log.collect() if isinstance(log, pl.LazyFrame) else log

    if attributes is None:
        attributes = [TIMESTAMP_KEY, CASE_ID_KEY, ACTIVITY_KEY]

    x_col, y_col = attributes[0], attributes[1]
    color_col = attributes[2] if len(attributes) > 2 else None
    subset = df.select([col for col in [x_col, y_col, color_col] if col is not None])
    subset = _sample_frame_for_plot(subset)
    x_values = subset.get_column(x_col).to_list()
    y_values = subset.get_column(y_col).to_list()
    fig = _make_plotly_figure(
        x_values,
        y_values,
        kind="scatter",
        title=graph_title or "Dotted Chart",
        xlabel=x_col,
        ylabel=y_col,
        color=subset.get_column(color_col).to_list() if color_col is not None else None,
        show_legend=show_legend,
    )
    fig.update_layout(paper_bgcolor=bgcolor)
    return fig


def view_dotted_chart(
    log: pl.LazyFrame, format: str = "png",
    attributes: Optional[List[str]] = None, bgcolor: str = "white",
    show_legend: bool = True, graph_title: Optional[str] = None,
) -> None:
    fig = _build_dotted_chart(log, attributes, bgcolor, show_legend, graph_title)
    if format == "svg":
        fig.write_image("dotted_chart.svg")
    else:
        fig.show()


def save_vis_dotted_chart(
    log: pl.LazyFrame, file_path: str,
    attributes: Optional[List[str]] = None, bgcolor: str = "white",
    show_legend: bool = True, graph_title: Optional[str] = None, **kwargs,
) -> None:
    if file_path.endswith(".html"):
        fig = _build_dotted_chart(log, attributes, bgcolor, show_legend, graph_title)
        fig.write_html(file_path)
    else:
        df = log.collect() if isinstance(log, pl.LazyFrame) else log
        if attributes is None:
            attributes = [TIMESTAMP_KEY, CASE_ID_KEY, ACTIVITY_KEY]
        x_col, y_col = attributes[0], attributes[1]
        color_col = attributes[2] if len(attributes) > 2 else None
        subset = _sample_frame_for_plot(df.select([col for col in [x_col, y_col, color_col] if col is not None]))
        x_values = subset.get_column(x_col).to_list()
        y_values = subset.get_column(y_col).to_list()
        color_values = subset.get_column(color_col).to_list() if color_col is not None else None
        _save_simple_matplotlib_chart(
            file_path,
            kind="scatter",
            x=x_values,
            y=y_values,
            color_by=color_values,
            title=graph_title or "Dotted Chart",
            xlabel=x_col,
            ylabel=y_col,
            show_legend=show_legend,
        )


# ══════════════════════════════════════════════════════════════════════
# Case Duration Graph
# ══════════════════════════════════════════════════════════════════════

def view_case_duration_graph(
    log: pl.LazyFrame, format: str = "png",
    activity_key: str = ACTIVITY_KEY, timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY, graph_title: Optional[str] = None,
) -> None:
    fig = _build_case_duration_graph(log, activity_key, timestamp_key,
                                     case_id_key, graph_title)
    if format == "svg":
        fig.write_image("case_duration.svg")
    else:
        fig.show()


def save_vis_case_duration_graph(
    log: pl.LazyFrame, file_path: str,
    activity_key: str = ACTIVITY_KEY, timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY, graph_title: Optional[str] = None, **kwargs,
) -> None:
    if file_path.endswith(".html"):
        fig = _build_case_duration_graph(log, activity_key, timestamp_key,
                                         case_id_key, graph_title)
        fig.write_html(file_path)
    else:
        durations = _case_duration_data(log, timestamp_key, case_id_key)
        _save_simple_matplotlib_chart(
            file_path,
            kind="line",
            x=list(range(durations.height)),
            y=durations.get_column("duration_s").to_list(),
            title=graph_title or "Case Duration Graph",
            xlabel="Cases (sorted)",
            ylabel="Duration (s)",
        )


def _build_case_duration_graph(log, activity_key, timestamp_key, case_id_key, graph_title):
    durations = _case_duration_data(log, timestamp_key, case_id_key)
    return _make_plotly_figure(
        list(range(durations.height)),
        durations.get_column("duration_s").to_list(),
        kind="line",
        title=graph_title or "Case Duration Graph",
        xlabel="Cases (sorted)",
        ylabel="Duration (s)",
    )


def _case_duration_data(log, timestamp_key, case_id_key):
    df = log.collect() if isinstance(log, pl.LazyFrame) else log
    return (
        df.lazy()
        .group_by(case_id_key)
        .agg([
            pl.col(timestamp_key).min().alias("start"),
            pl.col(timestamp_key).max().alias("end"),
        ])
        .with_columns(
            (pl.col("end") - pl.col("start")).dt.total_seconds().alias("duration_s")
        )
        .sort("duration_s")
        .select("duration_s")
        .collect()
    )


# ══════════════════════════════════════════════════════════════════════
# Events Per Time Graph
# ══════════════════════════════════════════════════════════════════════

def view_events_per_time_graph(
    log: pl.LazyFrame, format: str = "png",
    activity_key: str = ACTIVITY_KEY, timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY, graph_title: Optional[str] = None,
) -> None:
    fig = _build_events_per_time(log, timestamp_key, graph_title)
    fig.show() if format != "svg" else fig.write_image("events_per_time.svg")


def save_vis_events_per_time_graph(
    log: pl.LazyFrame, file_path: str,
    activity_key: str = ACTIVITY_KEY, timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY, graph_title: Optional[str] = None, **kwargs,
) -> None:
    if file_path.endswith(".html"):
        fig = _build_events_per_time(log, timestamp_key, graph_title)
        fig.write_html(file_path)
    else:
        result = _events_per_time_data(log, timestamp_key)
        _save_simple_matplotlib_chart(
            file_path,
            kind="bar",
            x=result.get_column("date").to_list(),
            y=result.get_column("events").to_list(),
            title=graph_title or "Events Per Time",
            xlabel="date",
            ylabel="events",
        )


def _build_events_per_time(log, timestamp_key, graph_title):
    result = _events_per_time_data(log, timestamp_key)
    return _make_plotly_figure(
        result.get_column("date").to_list(),
        result.get_column("events").to_list(),
        kind="bar",
        title=graph_title or "Events Per Time",
        xlabel="date",
        ylabel="events",
    )


def _events_per_time_data(log, timestamp_key):
    df = log.collect() if isinstance(log, pl.LazyFrame) else log
    return (
        df.lazy()
        .with_columns(pl.col(timestamp_key).dt.truncate("1d").alias("date"))
        .group_by("date")
        .agg(pl.len().alias("events"))
        .sort("date")
        .collect()
    )


# ══════════════════════════════════════════════════════════════════════
# Events Distribution Graph
# ══════════════════════════════════════════════════════════════════════

def view_events_distribution_graph(
    log: pl.LazyFrame, distr_type: str = "days_week",
    format: str = "png", activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY, case_id_key: str = CASE_ID_KEY,
    graph_title: Optional[str] = None,
) -> None:
    fig = _build_events_distribution(log, distr_type, timestamp_key, graph_title)
    fig.show() if format != "svg" else fig.write_image("events_distribution.svg")


def save_vis_events_distribution_graph(
    log: pl.LazyFrame, file_path: str,
    distr_type: str = "days_week", activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY, case_id_key: str = CASE_ID_KEY,
    graph_title: Optional[str] = None, **kwargs,
) -> None:
    result, xlabel = _events_distribution_data(log, distr_type, timestamp_key)
    if file_path.endswith(".html"):
        _svg_bar_chart_html(
            file_path,
            result.get_column("bucket").to_list(),
            result.get_column("events").to_list(),
            graph_title or f"Events Distribution ({xlabel})",
            xlabel,
            "Count",
        )
    else:
        _save_simple_matplotlib_chart(
            file_path,
            kind="bar",
            x=result.get_column("bucket").to_list(),
            y=result.get_column("events").to_list(),
            title=graph_title or f"Events Distribution ({xlabel})",
            xlabel=xlabel,
            ylabel="Count",
        )


def _build_events_distribution(log, distr_type, timestamp_key, graph_title):
    result, xlabel = _events_distribution_data(log, distr_type, timestamp_key)
    return _make_plotly_figure(
        result.get_column("bucket").to_list(),
        result.get_column("events").to_list(),
        kind="bar",
        title=graph_title or f"Events Distribution ({xlabel})",
        xlabel=xlabel,
        ylabel="Count",
    )


def _events_distribution_data(log, distr_type, timestamp_key):
    df = log.collect() if isinstance(log, pl.LazyFrame) else log
    _DISTR_MAP = {
        "days_week": (lambda lf: lf.with_columns(
            pl.col(timestamp_key).dt.weekday().alias("bucket")), "Day of Week"),
        "days_month": (lambda lf: lf.with_columns(
            pl.col(timestamp_key).dt.day().alias("bucket")), "Day of Month"),
        "months": (lambda lf: lf.with_columns(
            pl.col(timestamp_key).dt.month().alias("bucket")), "Month"),
        "years": (lambda lf: lf.with_columns(
            pl.col(timestamp_key).dt.year().alias("bucket")), "Year"),
        "hours": (lambda lf: lf.with_columns(
            pl.col(timestamp_key).dt.hour().alias("bucket")), "Hour"),
        "weeks": (lambda lf: lf.with_columns(
            pl.col(timestamp_key).dt.week().alias("bucket")), "Week"),
    }

    transform, xlabel = _DISTR_MAP.get(distr_type, _DISTR_MAP["days_week"])
    result = (
        transform(df.lazy())
        .group_by("bucket")
        .agg(pl.len().alias("events"))
        .sort("bucket")
        .collect()
    )
    return result, xlabel


# ══════════════════════════════════════════════════════════════════════
# Performance Spectrum
# ══════════════════════════════════════════════════════════════════════

def view_performance_spectrum(
    log: pl.LazyFrame, activities: List[str],
    format: str = "png", activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY, case_id_key: str = CASE_ID_KEY,
    bgcolor: str = "white", graph_title: Optional[str] = None,
) -> None:
    fig = _build_perf_spectrum(log, activities, activity_key, timestamp_key,
                               case_id_key, graph_title)
    fig.show() if format != "svg" else fig.write_image("perf_spectrum.svg")


def save_vis_performance_spectrum(
    log: pl.LazyFrame, activities: List[str],
    file_path: str, activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY, case_id_key: str = CASE_ID_KEY,
    bgcolor: str = "white", graph_title: Optional[str] = None, **kwargs,
) -> None:
    if file_path.endswith(".html"):
        _svg_polyline_html(
            file_path,
            _performance_spectrum_segments(log, activities, activity_key, timestamp_key, case_id_key),
            activities,
            graph_title or "Performance Spectrum",
        )
    else:
        segments = _performance_spectrum_segments(log, activities, activity_key, timestamp_key, case_id_key)
        plt = _get_matplotlib_pyplot()
        fig, ax = plt.subplots(figsize=(10, 5), dpi=120)
        try:
            if segments:
                from matplotlib.collections import LineCollection
                from matplotlib import dates as mdates

                def _mpl_x(value: Any) -> Any:
                    return mdates.date2num(value) if hasattr(value, "timetuple") else value

                line_segments = [((_mpl_x(x0), y0), (_mpl_x(x1), y1)) for x0, x1, y0, y1 in segments]
                collection = LineCollection(line_segments, colors="#4e79a7", linewidths=0.4, alpha=0.25)
                ax.add_collection(collection)
                xs = [_mpl_x(value) for seg in segments for value in (seg[0], seg[1])]
                ax.set_xlim(min(xs), max(xs))
            ax.set_ylim(-0.5, max(len(activities) - 0.5, 0.5))
            ax.set_title(graph_title or "Performance Spectrum")
            ax.set_xlabel("Time")
            ax.set_ylabel("Activity")
            ax.set_yticks(list(range(len(activities))))
            ax.set_yticklabels(activities)
            fig.subplots_adjust(left=0.12, right=0.98, top=0.90, bottom=0.12)
            fig.savefig(file_path, bbox_inches="tight")
        finally:
            plt.close(fig)


def _build_perf_spectrum(log, activities, activity_key, timestamp_key, case_id_key, graph_title):
    try:
        import plotly.graph_objects as go
    except ImportError:
        raise ImportError("plotly required.")
    segments = _performance_spectrum_segments(log, activities, activity_key, timestamp_key, case_id_key)
    xs: list[Any] = []
    ys: list[Any] = []
    for x0, x1, y0, y1 in segments:
        xs.extend([x0, x1, None])
        ys.extend([y0, y1, None])

    fig = go.Figure()
    fig.add_trace(go.Scattergl(
        x=xs,
        y=ys,
        mode="lines",
        line=dict(width=0.5, color="rgba(100,100,200,0.3)"),
        showlegend=False,
    ))

    fig.update_layout(
        title=graph_title or "Performance Spectrum",
        xaxis_title="Time",
        yaxis_title="Activity",
        yaxis=dict(tickvals=list(range(len(activities))), ticktext=activities),
        template="plotly_white",
    )
    return fig


def _performance_spectrum_segments(log, activities, activity_key, timestamp_key, case_id_key):
    df = log if isinstance(log, pl.LazyFrame) else log.lazy()
    grouped = (
        df.sort([case_id_key, timestamp_key])
        .group_by(case_id_key, maintain_order=True)
        .agg(
            [
                pl.col(activity_key).alias("_acts"),
                pl.col(timestamp_key).alias("_times"),
            ]
        )
        .collect()
    )
    segments: list[tuple[Any, Any, int, int]] = []
    target_len = len(activities)
    for acts, times in grouped.select(["_acts", "_times"]).iter_rows():
        positions: list[tuple[int, Any]] = []
        start_search = 0
        for target in activities:
            found = False
            for idx in range(start_search, len(acts)):
                if acts[idx] == target:
                    positions.append((idx, times[idx]))
                    start_search = idx + 1
                    found = True
                    break
            if not found:
                positions = []
                break
        if len(positions) == target_len:
            for i in range(target_len - 1):
                segments.append((positions[i][1], positions[i + 1][1], i, i + 1))
    return segments


# ══════════════════════════════════════════════════════════════════════
# Alignments
# ══════════════════════════════════════════════════════════════════════

def view_alignments(
    log, aligned_traces: List[Dict[str, Any]], format: str = "png",
    graph_title: Optional[str] = None,
) -> None:
    """View alignment results (prints to console as table for now)."""
    _print_alignments(aligned_traces)


def save_vis_alignments(
    log, aligned_traces: List[Dict[str, Any]], file_path: str,
    graph_title: Optional[str] = None, **kwargs,
) -> None:
    """Save alignment visualization."""
    with open(file_path, "w") as f:
        for i, trace in enumerate(aligned_traces):
            f.write(f"Trace {i}: {trace}\n")


def _print_alignments(aligned_traces):
    for i, trace in enumerate(aligned_traces):
        print(f"Trace {i}: cost={trace.get('cost', 'N/A')}, "
              f"fitness={trace.get('fitness', 'N/A')}")
