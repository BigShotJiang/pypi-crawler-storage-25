"""pl4pm.utils — Utility functions."""

from __future__ import annotations

import pickle
from collections import Counter
from datetime import datetime, timedelta
from typing import Any, Collection, Dict, List, Optional, Tuple

import polars as pl

from pl4pm.constants import (
    CASE_ID_KEY, ACTIVITY_KEY, TIMESTAMP_KEY, START_TIMESTAMP_KEY,
    RESOURCE_KEY, GROUP_KEY,
)
from pl4pm.objects.process_tree import ProcessTree, Operator, parse_tree_string


# ── Type checking ────────────────────────────────────────────────────

def is_polars_lazyframe(df: Any) -> bool:
    """Return True if *df* is a Polars LazyFrame."""
    return isinstance(df, pl.LazyFrame)


def _collect_log(log: pl.LazyFrame) -> pl.DataFrame:
    """Collect a LazyFrame when materialization is required."""
    return log.collect()


def finalize_lazy_result(
    result: pl.LazyFrame,
    do_collect: bool = False,
    collect_engine: str | None = None,
) -> pl.LazyFrame | pl.DataFrame:
    """Return a LazyFrame as-is or collect it with an optional engine.

    Parameters
    ----------
    result:
        Lazy query to finalize.
    do_collect:
        When ``True``, execute ``collect()`` before returning.
    collect_engine:
        Optional engine forwarded as ``collect(engine=...)``.
    """
    if not do_collect:
        return result
    if collect_engine is None:
        return result.collect()
    return result.collect(engine=collect_engine)


# ── format / rebase ──────────────────────────────────────────────────

def format_dataframe(
    df: pl.LazyFrame,
    case_id: str = CASE_ID_KEY,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    start_timestamp_key: str = START_TIMESTAMP_KEY,
    timest_format: Optional[str] = None,
) -> pl.LazyFrame:
    """Rename columns to standard XES keys, cast timestamps, sort."""
    rename: dict[str, str] = {}
    schema = df.collect_schema()
    if case_id != CASE_ID_KEY and case_id in schema.names():
        rename[case_id] = CASE_ID_KEY
    if activity_key != ACTIVITY_KEY and activity_key in schema.names():
        rename[activity_key] = ACTIVITY_KEY
    if timestamp_key != TIMESTAMP_KEY and timestamp_key in schema.names():
        rename[timestamp_key] = TIMESTAMP_KEY
    if (start_timestamp_key and start_timestamp_key != START_TIMESTAMP_KEY
            and start_timestamp_key in schema.names()):
        rename[start_timestamp_key] = START_TIMESTAMP_KEY

    if rename:
        df = df.rename(rename)

    # Cast timestamp columns
    new_schema = df.collect_schema()
    for col in (TIMESTAMP_KEY, START_TIMESTAMP_KEY):
        if col in new_schema.names() and new_schema[col] == pl.Utf8:
            if timest_format:
                df = df.with_columns(
                    pl.col(col).str.to_datetime(timest_format).alias(col)
                )
            else:
                df = df.with_columns(
                    pl.col(col).str.to_datetime().alias(col)
                )

    return df.sort([CASE_ID_KEY, TIMESTAMP_KEY])


def rebase(
    log_obj: pl.LazyFrame,
    case_id: str = CASE_ID_KEY,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    start_timestamp_key: str = START_TIMESTAMP_KEY,
    timest_format: Optional[str] = None,
) -> pl.LazyFrame:
    """Re-base a log by changing case ID, activity, and timestamp columns."""
    return format_dataframe(
        log_obj, case_id, activity_key, timestamp_key,
        start_timestamp_key, timest_format
    )


# ── Parsing ──────────────────────────────────────────────────────────

def parse_process_tree(tree_string: str) -> ProcessTree:
    """Parse a process tree from string (e.g., ``-> ( 'A', X ( 'B', 'C' ) )``)."""
    return parse_tree_string(tree_string)


def parse_event_log_string(
    traces: Collection[str],
    sep: str = ",",
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
) -> pl.DataFrame:
    """Parse traces like ``["A,B,C", "A,D"]`` into a Polars DataFrame."""
    rows: list[dict] = []
    base = datetime(2020, 1, 1)
    for i, trace_str in enumerate(traces):
        acts = [a.strip() for a in trace_str.split(sep)]
        for j, act in enumerate(acts):
            rows.append({
                case_id_key: f"case_{i}",
                activity_key: act,
                timestamp_key: base + timedelta(hours=i * 100 + j),
            })
    return pl.DataFrame(rows)


# ── Properties ───────────────────────────────────────────────────────

def get_properties(
    log: pl.LazyFrame,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
    resource_key: str = RESOURCE_KEY,
    group_key: Optional[str] = None,
    start_timestamp_key: Optional[str] = None,
    **kwargs,
) -> Dict[str, Any]:
    """Retrieve properties dict for a log."""
    props: Dict[str, Any] = {
        "activity_key": activity_key,
        "timestamp_key": timestamp_key,
        "case_id_key": case_id_key,
        "resource_key": resource_key,
    }
    if group_key:
        props["group_key"] = group_key
    if start_timestamp_key:
        props["start_timestamp_key"] = start_timestamp_key
    props.update(kwargs)
    return props


# ── Projection ───────────────────────────────────────────────────────

def project_on_event_attribute(
    log: pl.LazyFrame,
    attribute_key: str = ACTIVITY_KEY,
    case_id_key: str = CASE_ID_KEY,
) -> List[List[str]]:
    """Project log onto an event attribute, returning list of lists."""
    df = _collect_log(log).sort([case_id_key, TIMESTAMP_KEY])
    result: List[List[str]] = []
    for _, group in df.group_by(case_id_key, maintain_order=True):
        result.append(group[attribute_key].cast(pl.Utf8).to_list())
    return result


# ── Sampling ─────────────────────────────────────────────────────────

def sample_cases(
    log: pl.LazyFrame,
    num_cases: int,
    case_id_key: str = CASE_ID_KEY,
) -> pl.LazyFrame:
    """Randomly sample *num_cases* cases from the log."""
    df = log.collect()
    unique_cases = df[case_id_key].unique()
    if num_cases >= len(unique_cases):
        return log
    sampled = unique_cases.sample(num_cases, seed=42)
    result = df.filter(pl.col(case_id_key).is_in(sampled))
    return result.lazy()


def sample_events(
    log: pl.LazyFrame,
    num_events: int,
) -> pl.LazyFrame:
    """Randomly sample *num_events* events."""
    df = log.collect()
    if num_events >= df.height:
        return log
    result = df.sample(num_events, seed=42)
    return result.lazy()


# ── Serialization ────────────────────────────────────────────────────

def serialize(*args) -> Tuple[str, bytes]:
    """Serialize a pl4pm object to (type_string, bytes)."""
    if len(args) == 1:
        obj = args[0]
        if isinstance(obj, pl.LazyFrame):
            return ("dataframe", pickle.dumps(obj.collect()))
        type_name = type(obj).__name__.lower()
        return (type_name, pickle.dumps(obj))
    if len(args) == 3:
        from pl4pm.objects.petri_net import PetriNet, Marking
        if isinstance(args[0], PetriNet):
            return ("petri_net", pickle.dumps(args))
        if isinstance(args[0], dict):
            return ("dfg", pickle.dumps(args))
    return ("unknown", pickle.dumps(args))


def deserialize(ser_obj: Tuple[str, bytes]) -> Any:
    """Deserialize bytes back into a pl4pm object."""
    _, data = ser_obj
    return pickle.loads(data)
