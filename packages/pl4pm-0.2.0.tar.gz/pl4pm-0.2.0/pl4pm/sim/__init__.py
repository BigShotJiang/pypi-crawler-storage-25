"""pl4pm.sim - Simulation: playout and process tree generation."""

from __future__ import annotations

import random
from bisect import bisect_left as _bisect
from itertools import accumulate as _accum
from typing import Any, Dict, List, Optional

import polars as pl

from pl4pm.constants import ACTIVITY_KEY, CASE_ID_KEY, TIMESTAMP_KEY
from pl4pm.conformance.token_replay import _build_label_to_trans, _fire_transition, _get_enabled_transitions
from pl4pm.objects.petri_net import Marking, PetriNet
from pl4pm.objects.process_tree import Operator, ProcessTree


_SIM_SCHEMA_US = {
    CASE_ID_KEY: pl.Int32,
    ACTIVITY_KEY: pl.Utf8,
    TIMESTAMP_KEY: pl.Datetime("us"),
}
_SIM_EMPTY_DF = pl.DataFrame(schema=_SIM_SCHEMA_US)

# Warm Polars' datetime constructor once so the first measured playout does not
# pay the one-time initialization cost.
_SIM_POLARS_WARMUP = pl.DataFrame(
    [
        pl.Series(CASE_ID_KEY, [0], dtype=pl.Int32),
        pl.Series(ACTIVITY_KEY, ["_"], dtype=pl.Utf8),
        pl.Series(TIMESTAMP_KEY, [0], dtype=pl.Datetime("us")),
    ]
)

_TREE_EXECUTOR_CACHE: Dict[int, Any] = {}
_DFG_CACHE: Dict[Any, Dict[str, Any]] = {}

_BASE_US = 1_704_096_000_000_000
_HOUR_US = 3_600_000_000
_MIN_US = 60_000_000


def _sim_df(case_ids: list[int], activities: list[str], timestamps_us: list[int]) -> pl.DataFrame:
    if not case_ids:
        return _SIM_EMPTY_DF
    return pl.DataFrame(
        [
            pl.Series(CASE_ID_KEY, case_ids, dtype=pl.Int32),
            pl.Series(ACTIVITY_KEY, activities, dtype=pl.Utf8),
            pl.Series(TIMESTAMP_KEY, timestamps_us, dtype=pl.Datetime("us")),
        ]
    )


def _weighted_choice(values, cumulative, total, rnd):
    idx = _bisect(cumulative, rnd() * total)
    if idx >= len(values):
        idx = len(values) - 1
    return values[idx]


def _case_ids(n_traces: int) -> tuple[int, ...]:
    return tuple(range(n_traces))


def play_out(*args, **kwargs) -> pl.DataFrame:
    """Play out a model, generating a set of traces."""
    if not args:
        raise ValueError("Provide a model to play out")

    parameters = kwargs.pop("parameters", None) or {}
    if "n_traces" not in kwargs:
        if "no_traces" in parameters:
            kwargs["n_traces"] = parameters["no_traces"]
        elif "max_no_variants" in parameters:
            kwargs["n_traces"] = parameters["max_no_variants"]
    if "max_trace_length" not in kwargs and "max_trace_length" in parameters:
        kwargs["max_trace_length"] = parameters["max_trace_length"]
    if "smap" not in kwargs and "smap" in parameters:
        kwargs["smap"] = parameters["smap"]
    if "log" not in kwargs and "log" in parameters:
        kwargs["log"] = parameters["log"]

    if isinstance(args[0], PetriNet):
        return _playout_petri_net(args[0], args[1], args[2], **kwargs)
    if isinstance(args[0], ProcessTree):
        return _playout_process_tree(args[0], **kwargs)
    if isinstance(args[0], dict):
        return _playout_dfg(args[0], **kwargs)
    raise TypeError(f"Cannot play out {type(args[0])}")


def _playout_petri_net(
    net: PetriNet,
    im: Marking,
    fm: Marking,
    n_traces: int = 100,
    max_trace_length: int = 200,
    smap: Optional[Dict] = None,
    log: Optional[pl.DataFrame] = None,
    **kwargs,
) -> pl.DataFrame:
    """Stochastic playout of a Petri net."""
    if smap is None and log is not None:
        smap = _build_stochastic_map(net, log)

    case_ids_cache = _case_ids(n_traces)
    rnd = random.random
    rnd_int = random.randint
    fm_items = tuple(fm.items()) if fm else ()

    ids: list[int] = []
    acts: list[str] = []
    ts_out: list[int] = []
    add_id = ids.append
    add_act = acts.append
    add_ts = ts_out.append

    for case_idx in range(n_traces):
        marking = Marking(im)
        case_id = case_ids_cache[case_idx]
        current_us = _BASE_US + case_idx * _HOUR_US

        for _ in range(max_trace_length):
            enabled = tuple(_get_enabled_transitions(net, marking))
            if not enabled:
                break

            if fm_items and all(marking.get(place, 0) >= value for place, value in fm_items):
                if not any((not transition.is_silent) for transition in enabled):
                    break

            if smap:
                cumulative = list(_accum(float(smap.get(transition.name, 1.0)) for transition in enabled))
                chosen = _weighted_choice(enabled, cumulative, cumulative[-1], rnd)
            else:
                chosen = enabled[int(rnd() * len(enabled))]

            marking = _fire_transition(marking, chosen)
            if not chosen.is_silent and chosen.label:
                current_us += rnd_int(5, 120) * _MIN_US
                add_id(case_id)
                add_act(chosen.label)
                add_ts(current_us)

    return _sim_df(ids, acts, ts_out)


def _build_stochastic_map(net: PetriNet, log: pl.DataFrame) -> Dict[str, float]:
    """Build stochastic map from log frequencies."""
    label_map = _build_label_to_trans(net)
    act_counts = log.group_by(ACTIVITY_KEY).agg(pl.len().alias("cnt"))
    smap: Dict[str, float] = {}
    for row in act_counts.iter_rows(named=True):
        activity = row[ACTIVITY_KEY]
        if activity in label_map:
            smap[label_map[activity].name] = float(row["cnt"])
    return smap


def _playout_process_tree(
    tree: ProcessTree,
    n_traces: int = 100,
    **kwargs,
) -> pl.DataFrame:
    """Play out a process tree."""
    executor = _get_tree_executor(tree)
    case_ids_cache = _case_ids(n_traces)
    rnd_int = random.randint

    ids: list[int] = []
    acts_out: list[str] = []
    ts_out: list[int] = []
    add_id = ids.append
    add_act = acts_out.append
    add_ts = ts_out.append

    for case_idx in range(n_traces):
        acts = executor()
        case_id = case_ids_cache[case_idx]
        current_us = _BASE_US + case_idx * _HOUR_US
        for activity in acts:
            current_us += rnd_int(5, 60) * _MIN_US
            add_id(case_id)
            add_act(activity)
            add_ts(current_us)

    return _sim_df(ids, acts_out, ts_out)


def _execute_tree(tree: ProcessTree) -> List[str]:
    """Execute a process tree node, returning a list of activities."""
    return _get_tree_executor(tree)()


def _get_tree_executor(tree: ProcessTree):
    tree_key = hash(tree)
    cached = _TREE_EXECUTOR_CACHE.get(tree_key)
    if cached is not None:
        return cached

    if tree.is_leaf:
        if tree.label:
            label = tree.label

            def execute_leaf(label=label):
                return [label]

            _TREE_EXECUTOR_CACHE[tree_key] = execute_leaf
            return execute_leaf

        def execute_empty():
            return []

        _TREE_EXECUTOR_CACHE[tree_key] = execute_empty
        return execute_empty

    child_execs = tuple(_get_tree_executor(child) for child in tree.children)

    if tree.operator == Operator.SEQUENCE:

        def execute_sequence(child_execs=child_execs):
            result = []
            extend = result.extend
            for child_exec in child_execs:
                extend(child_exec())
            return result

        _TREE_EXECUTOR_CACHE[tree_key] = execute_sequence
        return execute_sequence

    if tree.operator == Operator.XOR:

        def execute_xor(child_execs=child_execs):
            return random.choice(child_execs)()

        _TREE_EXECUTOR_CACHE[tree_key] = execute_xor
        return execute_xor

    if tree.operator == Operator.PARALLEL:

        def execute_parallel(child_execs=child_execs):
            result = []
            extend = result.extend
            for child_exec in child_execs:
                extend(child_exec())
            random.shuffle(result)
            return result

        _TREE_EXECUTOR_CACHE[tree_key] = execute_parallel
        return execute_parallel

    if tree.operator == Operator.LOOP:

        def execute_loop(child_execs=child_execs):
            if not child_execs:
                return []
            result = child_execs[0]()
            while random.random() < 0.3:
                if len(child_execs) > 1:
                    result.extend(child_execs[1]())
                result.extend(child_execs[0]())
            return result

        _TREE_EXECUTOR_CACHE[tree_key] = execute_loop
        return execute_loop

    if tree.operator == Operator.OR:

        def execute_or(child_execs=child_execs):
            result = []
            for child_exec in random.sample(child_execs, k=random.randint(1, len(child_execs))):
                result.extend(child_exec())
            random.shuffle(result)
            return result

        _TREE_EXECUTOR_CACHE[tree_key] = execute_or
        return execute_or

    def execute_default():
        return []

    _TREE_EXECUTOR_CACHE[tree_key] = execute_default
    return execute_default


def _playout_dfg(
    dfg: dict,
    n_traces: int = 100,
    max_trace_length: int = 100,
    start_activities: Optional[Dict[str, int]] = None,
    end_activities: Optional[Dict[str, int]] = None,
    **kwargs,
) -> pl.DataFrame:
    """Play out a DFG with a cached compiled representation."""
    if start_activities is None:
        start_activities = {}
        for source, _ in dfg:
            start_activities[source] = start_activities.get(source, 0) + 1
    if end_activities is None:
        end_activities = {}
        for _, target in dfg:
            end_activities[target] = end_activities.get(target, 0) + 1

    compiled = _compile_dfg_playout(dfg, start_activities, end_activities)
    labels = compiled["labels"]
    start_idx = compiled["start_idx"]
    start_cum = compiled["start_cum"]
    start_total = compiled["start_total"]
    next_idx = compiled["next_idx"]
    next_cum = compiled["next_cum"]
    next_total = compiled["next_total"]
    is_end = compiled["is_end"]

    rnd = random.random
    rnd_int = random.randint
    bisect = _bisect
    start_len = len(start_idx)
    case_ids_cache = _case_ids(n_traces)

    ids: list[int] = []
    acts_out: list[str] = []
    ts_out: list[int] = []
    add_id = ids.append
    add_act = acts_out.append
    add_ts = ts_out.append

    for case_idx in range(n_traces):
        current_pos = bisect(start_cum, rnd() * start_total)
        if current_pos >= start_len:
            current_pos = start_len - 1
        current_idx = start_idx[current_pos]
        case_id = case_ids_cache[case_idx]
        current_us = _BASE_US + case_idx * _HOUR_US
        add_id(case_id)
        add_act(labels[current_idx])
        add_ts(current_us)

        for _ in range(max_trace_length - 1):
            if is_end[current_idx] and rnd() < 0.3:
                break
            targets = next_idx[current_idx]
            if not targets:
                break
            cumulative = next_cum[current_idx]
            current_pos = bisect(cumulative, rnd() * next_total[current_idx])
            if current_pos >= len(targets):
                current_pos = len(targets) - 1
            current_idx = targets[current_pos]
            current_us += rnd_int(5, 120) * _MIN_US
            add_id(case_id)
            add_act(labels[current_idx])
            add_ts(current_us)

    return _sim_df(ids, acts_out, ts_out)


def _compile_dfg_playout(
    dfg: dict,
    start_activities: Dict[str, int],
    end_activities: Dict[str, int],
) -> Dict[str, Any]:
    cache_key = (
        id(dfg),
        id(start_activities),
        id(end_activities),
        len(dfg),
        len(start_activities),
        len(end_activities),
    )
    cached = _DFG_CACHE.get(cache_key)
    if cached is not None:
        return cached

    labels: list[str] = []
    label_to_idx: Dict[str, int] = {}

    def get_idx(label: str) -> int:
        idx = label_to_idx.get(label)
        if idx is None:
            idx = len(labels)
            label_to_idx[label] = idx
            labels.append(label)
        return idx

    raw_edges: Dict[int, list[tuple[int, float]]] = {}
    for (source, target), weight in dfg.items():
        source_idx = get_idx(source)
        target_idx = get_idx(target)
        raw_edges.setdefault(source_idx, []).append((target_idx, float(weight)))

    for activity in start_activities:
        get_idx(activity)
    for activity in end_activities:
        get_idx(activity)

    n_labels = len(labels)
    next_idx: list[tuple[int, ...]] = [tuple() for _ in range(n_labels)]
    next_cum: list[tuple[float, ...]] = [tuple() for _ in range(n_labels)]
    next_total: list[float] = [0.0] * n_labels
    is_end = [False] * n_labels

    for activity in end_activities:
        is_end[label_to_idx[activity]] = True

    for source_idx, edges in raw_edges.items():
        targets = tuple(target for target, _ in edges)
        cumulative = tuple(_accum(weight for _, weight in edges))
        next_idx[source_idx] = targets
        next_cum[source_idx] = cumulative
        next_total[source_idx] = cumulative[-1]

    start_idx = tuple(label_to_idx[activity] for activity in start_activities)
    start_cum = tuple(_accum(float(start_activities[activity]) for activity in start_activities))
    compiled = {
        "labels": tuple(labels),
        "start_idx": start_idx,
        "start_cum": start_cum,
        "start_total": float(start_cum[-1]),
        "next_idx": tuple(next_idx),
        "next_cum": tuple(next_cum),
        "next_total": tuple(next_total),
        "is_end": tuple(is_end),
    }
    _DFG_CACHE[cache_key] = compiled
    return compiled


def generate_process_tree(
    min_depth: int = 1,
    max_depth: int = 3,
    min_width: int = 2,
    max_width: int = 4,
    activities: Optional[List[str]] = None,
    **kwargs,
) -> ProcessTree:
    """Generate a random process tree."""
    if activities is None:
        activities = [chr(65 + i) for i in range(random.randint(3, 8))]
    act_iter = iter(activities)
    return _gen_tree(0, min_depth, max_depth, min_width, max_width, act_iter, activities)


def _gen_tree(
    depth: int,
    min_depth: int,
    max_depth: int,
    min_width: int,
    max_width: int,
    act_iter,
    all_acts: List[str],
) -> ProcessTree:
    if depth >= max_depth:
        act = random.choice(all_acts)
        return ProcessTree(label=act)

    if depth >= min_depth and random.random() < 0.3:
        act = random.choice(all_acts)
        return ProcessTree(label=act)

    op = random.choice([Operator.SEQUENCE, Operator.XOR, Operator.PARALLEL, Operator.LOOP])
    n_children = random.randint(min_width, max_width)
    if op == Operator.LOOP:
        n_children = max(2, min(n_children, 3))

    children = []
    for _ in range(n_children):
        child = _gen_tree(depth + 1, min_depth, max_depth, min_width, max_width, act_iter, all_acts)
        children.append(child)

    tree = ProcessTree(operator=op, children=children)
    for child in children:
        child.parent = tree
    return tree


__all__ = [
    "play_out",
    "generate_process_tree",
]
