"""pl4pm.convert.to_networkx — Convert logs/models to NetworkX DiGraphs."""

from __future__ import annotations

from typing import Collection, Optional

import polars as pl

from pl4pm.constants import CASE_ID_KEY, ACTIVITY_KEY, TIMESTAMP_KEY
from pl4pm.objects.petri_net import PetriNet, Marking
from pl4pm.objects.ocel import OCEL


def convert_log_to_networkx(
    log: pl.LazyFrame,
    include_df: bool = True,
    case_id_key: str = CASE_ID_KEY,
    other_case_attributes_as_nodes: Optional[Collection[str]] = None,
    event_attributes_as_nodes: Optional[Collection[str]] = None,
) -> "nx.DiGraph":
    """Convert an event log to a NetworkX DiGraph."""
    try:
        import networkx as nx
    except ImportError:
        raise ImportError("networkx is required for this function. Install with: pip install networkx")

    df = log.collect() if isinstance(log, pl.LazyFrame) else log
    G = nx.DiGraph()

    for case_id, group in df.group_by(case_id_key, maintain_order=True):
        case_id_val = case_id[0] if isinstance(case_id, tuple) else case_id
        case_node = f"case:{case_id_val}"
        G.add_node(case_node, node_type="case")

        prev_event_node = None
        for i, row in enumerate(group.iter_rows(named=True)):
            event_node = f"event:{case_id_val}_{i}"
            G.add_node(event_node, node_type="event", **row)
            G.add_edge(event_node, case_node, edge_type="BELONGS_TO")

            if include_df and prev_event_node is not None:
                G.add_edge(prev_event_node, event_node, edge_type="DF")
            prev_event_node = event_node

            if event_attributes_as_nodes:
                for attr in event_attributes_as_nodes:
                    if attr in row and row[attr] is not None:
                        attr_node = f"{attr}:{row[attr]}"
                        G.add_node(attr_node, node_type="attribute")
                        G.add_edge(event_node, attr_node, edge_type="ATTRIBUTE_EDGE")

        if other_case_attributes_as_nodes:
            first_row = group.row(0, named=True)
            for attr in other_case_attributes_as_nodes:
                if attr in first_row and first_row[attr] is not None:
                    attr_node = f"{attr}:{first_row[attr]}"
                    G.add_node(attr_node, node_type="attribute")
                    G.add_edge(case_node, attr_node, edge_type="ATTRIBUTE_EDGE")

    return G


def convert_ocel_to_networkx(
    ocel: OCEL,
    variant: str = "ocel_to_nx",
) -> "nx.DiGraph":
    """Convert an OCEL to a NetworkX DiGraph."""
    try:
        import networkx as nx
    except ImportError:
        raise ImportError("networkx is required.")

    G = nx.DiGraph()

    for row in ocel.events.iter_rows(named=True):
        eid = row[OCEL.EVENT_ID]
        G.add_node(eid, node_type="event", **row)

    for row in ocel.objects.iter_rows(named=True):
        oid = row[OCEL.OBJECT_ID]
        G.add_node(oid, node_type="object", **row)

    for row in ocel.relations.iter_rows(named=True):
        G.add_edge(row[OCEL.EVENT_ID], row[OCEL.OBJECT_ID], edge_type="REL")

    return G


def convert_petri_net_to_networkx(
    net: PetriNet,
    im: Marking,
    fm: Marking,
) -> "nx.DiGraph":
    """Convert a Petri net to a NetworkX DiGraph."""
    try:
        import networkx as nx
    except ImportError:
        raise ImportError("networkx is required.")

    G = nx.DiGraph()

    for place in net.places:
        G.add_node(place.name, node_type="place",
                    initial=im.get(place, 0),
                    final=fm.get(place, 0))

    for trans in net.transitions:
        G.add_node(trans.name, node_type="transition",
                    label=trans.label, silent=trans.is_silent)

    for arc in net.arcs:
        G.add_edge(repr(arc.source), repr(arc.target), weight=arc.weight)

    return G
