"""pl4pm.convert.to_process_tree — Convert models to ProcessTree."""

from __future__ import annotations

from typing import Tuple

from pl4pm.objects.petri_net import PetriNet, Marking
from pl4pm.objects.process_tree import ProcessTree, Operator
from pl4pm.objects.bpmn import BPMN


def _pn_to_pt(net: PetriNet, im: Marking, fm: Marking) -> ProcessTree:
    """Convert a Petri net to a process tree (basic, for structured WF-nets).

    Uses a simplified region-based decomposition. May raise if net is not structured.
    """
    # Identify visible transitions in sequence
    ordered = _topological_order(net, im)
    if not ordered:
        raise ValueError("Cannot convert non-structured Petri net to process tree")

    if len(ordered) == 1:
        t = ordered[0]
        return ProcessTree(label=t.label)

    # Simple heuristic: wrap all visible transitions in a sequence
    children = []
    for t in ordered:
        children.append(ProcessTree(label=t.label))

    root = ProcessTree(operator=Operator.SEQUENCE, children=children)
    for c in children:
        c.parent = root
    return root


def _topological_order(net: PetriNet, im: Marking) -> list[PetriNet.Transition]:
    """Get visible transitions in topological order via BFS from initial marking."""
    visited_places: set = set()
    visited_trans: set = set()
    result: list[PetriNet.Transition] = []
    queue = list(im.keys())

    while queue:
        place = queue.pop(0)
        if place in visited_places:
            continue
        visited_places.add(place)
        for arc in place.out_arcs:
            trans = arc.target
            if trans in visited_trans:
                continue
            visited_trans.add(trans)
            if not trans.is_silent:
                result.append(trans)
            for out_arc in trans.out_arcs:
                if out_arc.target not in visited_places:
                    queue.append(out_arc.target)
    return result


def _bpmn_to_pt(bpmn: BPMN) -> ProcessTree:
    """Convert BPMN to process tree via intermediate Petri net."""
    from pl4pm.convert.to_petri_net import convert_to_petri_net
    net, im, fm = convert_to_petri_net(bpmn)
    return _pn_to_pt(net, im, fm)


def convert_to_process_tree(*args) -> ProcessTree:
    """Convert (PetriNet, Marking, Marking) or BPMN to ProcessTree."""
    if len(args) == 1:
        obj = args[0]
        if isinstance(obj, ProcessTree):
            return obj
        if isinstance(obj, BPMN):
            return _bpmn_to_pt(obj)
    if len(args) == 3 and isinstance(args[0], PetriNet):
        return _pn_to_pt(args[0], args[1], args[2])
    raise TypeError(f"Cannot convert {[type(a).__name__ for a in args]} to ProcessTree")
