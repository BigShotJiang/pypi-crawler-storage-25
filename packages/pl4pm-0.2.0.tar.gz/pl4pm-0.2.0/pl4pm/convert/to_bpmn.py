"""pl4pm.convert.to_bpmn — Convert models to BPMN."""

from __future__ import annotations

from typing import Tuple
import uuid

from pl4pm.objects.petri_net import PetriNet, Marking
from pl4pm.objects.process_tree import ProcessTree, Operator, from_any_process_tree
from pl4pm.objects.bpmn import BPMN


def _pt_to_bpmn(tree: ProcessTree) -> BPMN:
    """Convert a ProcessTree to a BPMN model."""
    bpmn = BPMN()
    start = BPMN.StartEvent(name="start")
    end = BPMN.EndEvent(name="end")
    bpmn.add_node(start)
    bpmn.add_node(end)

    src, tgt = _subtree_to_bpmn(tree, bpmn)
    bpmn.add_flow(BPMN.Flow(source=start, target=src))
    bpmn.add_flow(BPMN.Flow(source=tgt, target=end))
    return bpmn


def _subtree_to_bpmn(node: ProcessTree, bpmn: BPMN) -> Tuple[BPMN.Node, BPMN.Node]:
    """Return (entry_node, exit_node) for a subtree."""
    if node.is_leaf:
        label = node.label or "τ"
        task = BPMN.Task(name=label)
        bpmn.add_node(task)
        return task, task

    if node.operator == Operator.SEQUENCE:
        entries = []
        for child in node.children:
            s, e = _subtree_to_bpmn(child, bpmn)
            entries.append((s, e))
        # chain them
        for i in range(len(entries) - 1):
            bpmn.add_flow(BPMN.Flow(source=entries[i][1], target=entries[i + 1][0]))
        return entries[0][0], entries[-1][1]

    if node.operator == Operator.XOR:
        split = BPMN.ExclusiveGateway(name="xor_split",
                                       direction=BPMN.GatewayDirection.DIVERGING)
        join = BPMN.ExclusiveGateway(name="xor_join",
                                      direction=BPMN.GatewayDirection.CONVERGING)
        bpmn.add_node(split)
        bpmn.add_node(join)
        for child in node.children:
            s, e = _subtree_to_bpmn(child, bpmn)
            bpmn.add_flow(BPMN.Flow(source=split, target=s))
            bpmn.add_flow(BPMN.Flow(source=e, target=join))
        return split, join

    if node.operator == Operator.PARALLEL:
        split = BPMN.ParallelGateway(name="and_split",
                                      direction=BPMN.GatewayDirection.DIVERGING)
        join = BPMN.ParallelGateway(name="and_join",
                                     direction=BPMN.GatewayDirection.CONVERGING)
        bpmn.add_node(split)
        bpmn.add_node(join)
        for child in node.children:
            s, e = _subtree_to_bpmn(child, bpmn)
            bpmn.add_flow(BPMN.Flow(source=split, target=s))
            bpmn.add_flow(BPMN.Flow(source=e, target=join))
        return split, join

    if node.operator == Operator.LOOP:
        split = BPMN.ExclusiveGateway(name="loop_split",
                                       direction=BPMN.GatewayDirection.DIVERGING)
        join = BPMN.ExclusiveGateway(name="loop_join",
                                      direction=BPMN.GatewayDirection.CONVERGING)
        bpmn.add_node(split)
        bpmn.add_node(join)
        # do-part: children[0]
        do_s, do_e = _subtree_to_bpmn(node.children[0], bpmn)
        bpmn.add_flow(BPMN.Flow(source=join, target=do_s))
        bpmn.add_flow(BPMN.Flow(source=do_e, target=split))
        # redo-part: children[1] if exists
        if len(node.children) > 1:
            redo_s, redo_e = _subtree_to_bpmn(node.children[1], bpmn)
            bpmn.add_flow(BPMN.Flow(source=split, target=redo_s))
            bpmn.add_flow(BPMN.Flow(source=redo_e, target=join))
        return join, split

    # fallback: OR
    split = BPMN.InclusiveGateway(name="or_split",
                                   direction=BPMN.GatewayDirection.DIVERGING)
    join = BPMN.InclusiveGateway(name="or_join",
                                  direction=BPMN.GatewayDirection.CONVERGING)
    bpmn.add_node(split)
    bpmn.add_node(join)
    for child in node.children:
        s, e = _subtree_to_bpmn(child, bpmn)
        bpmn.add_flow(BPMN.Flow(source=split, target=s))
        bpmn.add_flow(BPMN.Flow(source=e, target=join))
    return split, join


def _pn_to_bpmn(net: PetriNet, im: Marking, fm: Marking) -> BPMN:
    """Convert a Petri net to BPMN (basic structural mapping)."""
    bpmn = BPMN()
    start = BPMN.StartEvent(name="start")
    end = BPMN.EndEvent(name="end")
    bpmn.add_node(start)
    bpmn.add_node(end)

    # Map transitions to tasks
    trans_map: dict[PetriNet.Transition, BPMN.Node] = {}
    for t in net.transitions:
        if t.is_silent:
            gw = BPMN.ExclusiveGateway(name=t.name)
            bpmn.add_node(gw)
            trans_map[t] = gw
        else:
            task = BPMN.Task(name=t.label or t.name)
            bpmn.add_node(task)
            trans_map[t] = task

    # simple mapping: for each arc pair place-transition, add flow
    for t in net.transitions:
        bpmn_node = trans_map[t]
        # inputs
        if not t.in_arcs:
            bpmn.add_flow(BPMN.Flow(source=start, target=bpmn_node))
        # outputs
        if not t.out_arcs:
            bpmn.add_flow(BPMN.Flow(source=bpmn_node, target=end))

    # connect through places
    for arc in net.arcs:
        if isinstance(arc.source, PetriNet.Transition) and isinstance(arc.target, PetriNet.Place):
            src_bpmn = trans_map[arc.source]
            # find transitions consuming from this place
            for out_arc in arc.target.out_arcs:
                if isinstance(out_arc.target, PetriNet.Transition):
                    tgt_bpmn = trans_map[out_arc.target]
                    bpmn.add_flow(BPMN.Flow(source=src_bpmn, target=tgt_bpmn))

    return bpmn


def convert_to_bpmn(*args) -> BPMN:
    """Convert a ProcessTree or (PetriNet, Marking, Marking) to BPMN."""
    if len(args) == 1:
        tree = args[0]
        if not isinstance(tree, ProcessTree) and all(hasattr(tree, attr) for attr in ("label", "operator", "children")):
            tree = from_any_process_tree(tree)
        if isinstance(tree, ProcessTree):
            return _pt_to_bpmn(tree)
    if len(args) == 3:
        net, im, fm = args
        if isinstance(net, PetriNet):
            return _pn_to_bpmn(net, im, fm)
    raise TypeError(f"Cannot convert {[type(a).__name__ for a in args]} to BPMN")
