"""pl4pm.convert.petri_net_type — Change Petri net type."""

from __future__ import annotations

from typing import Tuple

from pl4pm.objects.petri_net import PetriNet, Marking


def convert_petri_net_type(
    net: PetriNet,
    im: Marking,
    fm: Marking,
    type: str = "classic",
) -> Tuple[PetriNet, Marking, Marking]:
    """Convert the internal type of a Petri net.

    Currently stores the type as a property; the net structure is unchanged.

    Args:
        type: One of "classic", "reset", "inhibitor", "reset_inhibitor".
    """
    valid = {"classic", "reset", "inhibitor", "reset_inhibitor"}
    if type not in valid:
        raise ValueError(f"Invalid Petri net type '{type}'. Must be one of {valid}")

    net.properties["petri_net_type"] = type
    return net, im, fm
