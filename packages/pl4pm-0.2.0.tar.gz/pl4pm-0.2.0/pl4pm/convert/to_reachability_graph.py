"""pl4pm.convert.to_reachability_graph — Build reachability graph from Petri net."""

from __future__ import annotations

from typing import Tuple

from pl4pm.objects.petri_net import PetriNet, Marking
from pl4pm.objects.transition_system import TransitionSystem


def _is_enabled(trans: PetriNet.Transition, marking: Marking) -> bool:
    """Check if a transition is enabled under a marking."""
    for arc in trans.in_arcs:
        if marking.get(arc.source, 0) < arc.weight:
            return False
    return True


def _fire(trans: PetriNet.Transition, marking: Marking) -> Marking:
    """Fire a transition and return the new marking."""
    new_marking = Marking(marking)
    for arc in trans.in_arcs:
        new_marking[arc.source] -= arc.weight
    for arc in trans.out_arcs:
        new_marking[arc.target] += arc.weight
    # clean zeros
    new_marking = Marking({p: n for p, n in new_marking.items() if n > 0})
    return new_marking


def convert_to_reachability_graph(
    net: PetriNet,
    im: Marking,
    fm: Marking,
    max_states: int = 10000,
) -> TransitionSystem:
    """Build reachability graph by state-space exploration.

    Args:
        net: Petri net.
        im: Initial marking.
        fm: Final marking.
        max_states: Maximum number of states before stopping.

    Returns:
        TransitionSystem representing the reachability graph.
    """
    ts = TransitionSystem("reachability_graph")

    marking_to_state: dict[Marking, TransitionSystem.State] = {}
    initial_state = TransitionSystem.State(repr(im), data=im)
    ts.add_state(initial_state)
    marking_to_state[im] = initial_state

    queue: list[Marking] = [im]

    while queue and len(ts.states) < max_states:
        current = queue.pop(0)
        current_state = marking_to_state[current]

        for trans in net.transitions:
            if _is_enabled(trans, current):
                new_marking = _fire(trans, current)

                if new_marking not in marking_to_state:
                    new_state = TransitionSystem.State(repr(new_marking),
                                                       data=new_marking)
                    ts.add_state(new_state)
                    marking_to_state[new_marking] = new_state
                    queue.append(new_marking)

                target_state = marking_to_state[new_marking]
                label = trans.label or trans.name
                ts_trans = TransitionSystem.Transition(
                    label, current_state, target_state, data=trans)
                ts.add_transition(ts_trans)

    return ts
