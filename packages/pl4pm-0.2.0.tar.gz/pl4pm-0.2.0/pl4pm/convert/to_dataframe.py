"""pl4pm.convert.to_dataframe — Convert legacy log objects to pl4pm formats."""

from __future__ import annotations

import polars as pl

from pl4pm.constants import CASE_ID_KEY
from pl4pm.objects.log import EventLog, EventStream, Trace

def convert_to_event_log(
    df: pl.LazyFrame,
    case_id_key: str = CASE_ID_KEY,
) -> EventLog:
    """Convert a Polars LazyFrame to an EventLog."""
    df = df.collect()

    log = EventLog()
    event_cols = [c for c in df.columns if c != case_id_key]

    for case_id, group in df.group_by(case_id_key, maintain_order=True):
        case_id_val = case_id[0] if isinstance(case_id, tuple) else case_id
        trace = Trace(attributes={"concept:name": case_id_val})
        for row in group.select(event_cols).iter_rows(named=True):
            from pl4pm.objects.log import Event
            trace.append(Event(row))
        log.append(trace)

    return log


def convert_to_event_stream(
    df: pl.LazyFrame,
) -> EventStream:
    """Convert a Polars LazyFrame to an EventStream."""
    df = df.collect()

    stream = EventStream()
    for row in df.iter_rows(named=True):
        from pl4pm.objects.log import Event
        stream.append(Event(row))
    return stream
