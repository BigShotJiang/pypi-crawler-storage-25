"""pl4pm.convert.to_ocel — Convert traditional logs to OCEL."""

from __future__ import annotations

from typing import Collection, Dict, Optional

import polars as pl

from pl4pm.constants import ACTIVITY_KEY, TIMESTAMP_KEY, CASE_ID_KEY
from pl4pm.objects.ocel import OCEL


def convert_log_to_ocel(
    log: pl.LazyFrame,
    activity_column: str = ACTIVITY_KEY,
    timestamp_column: str = TIMESTAMP_KEY,
    object_types: Optional[Collection[str]] = None,
    obj_separator: str = " AND ",
    additional_event_attributes: Optional[Collection[str]] = None,
    additional_object_attributes: Optional[Dict[str, Collection[str]]] = None,
) -> OCEL:
    """Convert an event log DataFrame to an OCEL.

    Args:
        log: Polars DataFrame/LazyFrame of the event log.
        activity_column: Column for the activity name.
        timestamp_column: Column for the timestamp.
        object_types: Columns to treat as object types. Defaults to [case_id_key].
        obj_separator: Separator for multiple objects in a column.
        additional_event_attributes: Extra event-level columns.
        additional_object_attributes: Extra object-level attributes per type.

    Returns:
        OCEL object.
    """
    df = log.collect() if isinstance(log, pl.LazyFrame) else log

    if object_types is None:
        object_types = [CASE_ID_KEY]
    object_types_list = list(object_types)

    # assign event IDs
    df = df.with_row_index("ocel:eid")
    df = df.with_columns(pl.col("ocel:eid").cast(pl.Utf8))

    # Build events DataFrame
    ev_cols = [OCEL.EVENT_ID, activity_column, timestamp_column]
    if additional_event_attributes:
        ev_cols.extend(additional_event_attributes)
    # select only available columns
    ev_cols = [c for c in ev_cols if c in df.columns or c == OCEL.EVENT_ID]
    rename_map = {
        "ocel:eid": OCEL.EVENT_ID,
        activity_column: OCEL.EVENT_ACTIVITY,
        timestamp_column: OCEL.EVENT_TIMESTAMP,
    }
    events_df = df.select(
        [c for c in ["ocel:eid", activity_column, timestamp_column] if c in df.columns]
        + [c for c in (additional_event_attributes or []) if c in df.columns]
    ).rename({k: v for k, v in rename_map.items() if k in df.columns})

    # Build objects + relations
    all_objects: dict[str, str] = {}  # oid -> otype
    relation_rows: list[dict[str, str]] = []

    for otype_col in object_types_list:
        if otype_col not in df.columns:
            continue
        for row in df.select(["ocel:eid", otype_col]).iter_rows(named=True):
            eid = row["ocel:eid"]
            raw = row[otype_col]
            if raw is None:
                continue
            oids = [s.strip() for s in str(raw).split(obj_separator)] if obj_separator in str(raw) else [str(raw)]
            for oid in oids:
                if oid:
                    all_objects[oid] = otype_col
                    relation_rows.append({
                        OCEL.EVENT_ID: eid,
                        OCEL.OBJECT_ID: oid,
                        OCEL.QUALIFIER: otype_col,
                    })

    objects_df = pl.DataFrame([
        {OCEL.OBJECT_ID: oid, OCEL.OBJECT_TYPE: otype}
        for oid, otype in all_objects.items()
    ]) if all_objects else pl.DataFrame(
        schema={OCEL.OBJECT_ID: pl.Utf8, OCEL.OBJECT_TYPE: pl.Utf8})

    relations_df = pl.DataFrame(relation_rows) if relation_rows else pl.DataFrame(
        schema={OCEL.EVENT_ID: pl.Utf8, OCEL.OBJECT_ID: pl.Utf8,
                OCEL.QUALIFIER: pl.Utf8})

    return OCEL(events=events_df, objects=objects_df, relations=relations_df)
