"""pl4pm.convert.to_petri_net — Convert models to Petri nets."""

from __future__ import annotations

from typing import Dict, Tuple

from pl4pm.objects.petri_net import PetriNet, Marking, add_arc_from_to, remove_transition, remove_place
from pl4pm.objects.process_tree import ProcessTree, Operator, from_any_process_tree
from pl4pm.objects.bpmn import BPMN


def _pt_to_pn(tree: ProcessTree) -> Tuple[PetriNet, Marking, Marking]:
    """Convert a ProcessTree to a Petri net using the standard reduction rules."""
    net = PetriNet("pt_to_pn")
    src = PetriNet.Place("source")
    sink = PetriNet.Place("sink")
    net.places.add(src)
    net.places.add(sink)

    _subtree_to_pn(tree, net, src, sink)
    _apply_simple_reduction(net)

    im = Marking({src: 1})
    fm = Marking({sink: 1})
    return net, im, fm

def _has_only_trans_as_output(place: PetriNet.Place, trans: PetriNet.Transition) -> bool:
    outs = {arc.target for arc in place.out_arcs if isinstance(arc.target, PetriNet.Transition)}
    return outs == {trans}

def _has_only_trans_as_input(place: PetriNet.Place, trans: PetriNet.Transition) -> bool:
    ins = {arc.source for arc in place.in_arcs if isinstance(arc.source, PetriNet.Transition)}
    return ins == {trans}

def _apply_simple_reduction(net: PetriNet) -> None:
    changed = True
    while changed:
        old_t = len(net.transitions)
        old_p = len(net.places)

        # entry
        cont = True
        while cont:
            cont = False
            for t in [x for x in net.transitions if x.label is None and len(x.in_arcs) == 1]:
                src_p = list(t.in_arcs)[0].source
                if len(src_p.in_arcs) == 1 and _has_only_trans_as_output(src_p, t):
                    src_t = list(src_p.in_arcs)[0].source
                    tgt_places = [arc.target for arc in t.out_arcs]
                    remove_transition(net, t)
                    remove_place(net, src_p)
                    for p in tgt_places:
                        add_arc_from_to(src_t, p, net)
                    cont = True
                    break

        # exit
        cont = True
        while cont:
            cont = False
            for t in [x for x in net.transitions if x.label is None and len(x.out_arcs) == 1]:
                tgt_p = list(t.out_arcs)[0].target
                if len(tgt_p.out_arcs) == 1 and _has_only_trans_as_input(tgt_p, t):
                    tgt_t = list(tgt_p.out_arcs)[0].target
                    src_places = [arc.source for arc in t.in_arcs]
                    remove_transition(net, t)
                    remove_place(net, tgt_p)
                    for p in src_places:
                        add_arc_from_to(p, tgt_t, net)
                    cont = True
                    break

        new_t = len(net.transitions)
        new_p = len(net.places)
        changed = (new_t < old_t or new_p < old_p)


_counter = [0]


def _new_id() -> str:
    _counter[0] += 1
    return str(_counter[0])


def _subtree_to_pn(node: ProcessTree, net: PetriNet,
                    src: PetriNet.Place, sink: PetriNet.Place) -> None:
    """Recursively map a process tree node into the Petri net between src and sink."""
    if node.is_leaf:
        t = PetriNet.Transition(f"t_{_new_id()}",
                                label=node.label)  # None for tau
        net.transitions.add(t)
        add_arc_from_to(src, t, net)
        add_arc_from_to(t, sink, net)
        return

    if node.operator == Operator.SEQUENCE:
        places = [src]
        for _ in range(len(node.children) - 1):
            p = PetriNet.Place(f"p_{_new_id()}")
            net.places.add(p)
            places.append(p)
        places.append(sink)
        for i, child in enumerate(node.children):
            _subtree_to_pn(child, net, places[i], places[i + 1])

    elif node.operator == Operator.XOR:
        for child in node.children:
            _subtree_to_pn(child, net, src, sink)

    elif node.operator == Operator.PARALLEL:
        t_split = PetriNet.Transition(f"t_split_{_new_id()}", label=None)
        t_join = PetriNet.Transition(f"t_join_{_new_id()}", label=None)
        net.transitions.add(t_split)
        net.transitions.add(t_join)
        add_arc_from_to(src, t_split, net)
        add_arc_from_to(t_join, sink, net)

        for child in node.children:
            p_in = PetriNet.Place(f"p_{_new_id()}")
            p_out = PetriNet.Place(f"p_{_new_id()}")
            net.places.add(p_in)
            net.places.add(p_out)
            add_arc_from_to(t_split, p_in, net)
            add_arc_from_to(p_out, t_join, net)
            _subtree_to_pn(child, net, p_in, p_out)

    elif node.operator == Operator.LOOP:
        # *(do, redo[, exit])
        p_start = PetriNet.Place(f"p_{_new_id()}")
        net.places.add(p_start)
        t_init = PetriNet.Transition(f"t_init_loop_{_new_id()}", label=None)
        net.transitions.add(t_init)
        add_arc_from_to(src, t_init, net)
        add_arc_from_to(t_init, p_start, net)

        p_mid = PetriNet.Place(f"p_{_new_id()}")
        net.places.add(p_mid)
        # do: p_start -> p_mid
        _subtree_to_pn(node.children[0], net, p_start, p_mid)
        # redo: p_mid -> p_start (if exists)
        if len(node.children) > 1:
            _subtree_to_pn(node.children[1], net, p_mid, p_start)
        # exit: p_mid -> sink (tau if no explicit exit child)
        if len(node.children) > 2:
            _subtree_to_pn(node.children[2], net, p_mid, sink)
        else:
            t_exit = PetriNet.Transition(f"t_exit_{_new_id()}", label=None)
            net.transitions.add(t_exit)
            add_arc_from_to(p_mid, t_exit, net)
            add_arc_from_to(t_exit, sink, net)


def _dfg_to_pn(dfg: Dict[Tuple[str, str], int],
               start_acts: Dict[str, int],
               end_acts: Dict[str, int]) -> Tuple[PetriNet, Marking, Marking]:
    """Convert a DFG to a Petri net (flower model or direct mapping)."""
    net = PetriNet("dfg_to_pn")
    src = PetriNet.Place("source")
    sink = PetriNet.Place("sink")
    net.places.add(src)
    net.places.add(sink)

    all_acts: set[str] = set()
    for (a, b) in dfg:
        all_acts.add(a)
        all_acts.add(b)
    all_acts.update(start_acts.keys())
    all_acts.update(end_acts.keys())

    # Create a place for each activity
    act_places: dict[str, PetriNet.Place] = {}
    act_trans: dict[str, PetriNet.Transition] = {}

    for act in all_acts:
        t = PetriNet.Transition(f"t_{act}", label=act)
        net.transitions.add(t)
        act_trans[act] = t

        p = PetriNet.Place(f"p_{act}")
        net.places.add(p)
        act_places[act] = p
        add_arc_from_to(t, p, net)

    # start activities
    for act in start_acts:
        add_arc_from_to(src, act_trans[act], net)

    # end activities
    for act in end_acts:
        add_arc_from_to(act_places[act], PetriNet.Transition(f"t_end_{act}", label=None), net)
        t_end = list(net.transitions)[-1]  # just added
        add_arc_from_to(t_end, sink, net)

    # DFG edges
    for (a, b) in dfg:
        add_arc_from_to(act_places[a], act_trans[b], net)

    im = Marking({src: 1})
    fm = Marking({sink: 1})
    return net, im, fm


def _bpmn_to_pn(bpmn: BPMN) -> Tuple[PetriNet, Marking, Marking]:
    """Convert BPMN to Petri net (basic structural mapping)."""
    net = PetriNet("bpmn_to_pn")
    src = PetriNet.Place("source")
    sink = PetriNet.Place("sink")
    net.places.add(src)
    net.places.add(sink)

    node_in: dict[str, PetriNet.Place] = {}
    node_out: dict[str, PetriNet.Place] = {}

    for node in bpmn.nodes:
        p_in = PetriNet.Place(f"p_in_{node.id}")
        p_out = PetriNet.Place(f"p_out_{node.id}")
        net.places.add(p_in)
        net.places.add(p_out)
        node_in[node.id] = p_in
        node_out[node.id] = p_out

        if isinstance(node, BPMN.StartEvent):
            add_arc_from_to(src, PetriNet.Transition(f"t_start_{node.id}", label=None), net)
            t = list(net.transitions)[-1]
            add_arc_from_to(t, p_out, net)
        elif isinstance(node, BPMN.EndEvent):
            t = PetriNet.Transition(f"t_end_{node.id}", label=None)
            net.transitions.add(t)
            add_arc_from_to(p_in, t, net)
            add_arc_from_to(t, sink, net)
        elif isinstance(node, BPMN.Task):
            t = PetriNet.Transition(f"t_{node.id}", label=node.name)
            net.transitions.add(t)
            add_arc_from_to(p_in, t, net)
            add_arc_from_to(t, p_out, net)
        elif isinstance(node, (BPMN.ExclusiveGateway, BPMN.InclusiveGateway)):
            t = PetriNet.Transition(f"t_{node.id}", label=None)
            net.transitions.add(t)
            add_arc_from_to(p_in, t, net)
            add_arc_from_to(t, p_out, net)
        elif isinstance(node, BPMN.ParallelGateway):
            t = PetriNet.Transition(f"t_{node.id}", label=None)
            net.transitions.add(t)
            add_arc_from_to(p_in, t, net)
            add_arc_from_to(t, p_out, net)

    # Flows → connect output place of source to input place of target
    for flow in bpmn.flows:
        src_out = node_out.get(flow.source.id)
        tgt_in = node_in.get(flow.target.id)
        if src_out and tgt_in:
            t = PetriNet.Transition(f"t_flow_{flow.id}", label=None)
            net.transitions.add(t)
            add_arc_from_to(src_out, t, net)
            add_arc_from_to(t, tgt_in, net)

    im = Marking({src: 1})
    fm = Marking({sink: 1})
    return net, im, fm


def convert_to_petri_net(*args) -> Tuple[PetriNet, Marking, Marking]:
    """Convert ProcessTree, BPMN, or DFG to (PetriNet, Marking, Marking)."""
    if len(args) == 1:
        obj = args[0]
        if not isinstance(obj, ProcessTree) and all(hasattr(obj, attr) for attr in ("label", "operator", "children")):
            obj = from_any_process_tree(obj)
        if isinstance(obj, ProcessTree):
            _counter[0] = 0
            return _pt_to_pn(obj)
        if isinstance(obj, BPMN):
            return _bpmn_to_pn(obj)
    if len(args) == 3:
        if isinstance(args[0], dict):
            return _dfg_to_pn(args[0], args[1], args[2])
    raise TypeError(f"Cannot convert {[type(a).__name__ for a in args]} to Petri net")
