"""pl4pm.analysis — Petri net analysis, similarity, and log enrichment utilities."""

from __future__ import annotations

import math
from collections import defaultdict
from collections import deque
from typing import Any, Dict, Generator, List, Optional, Set, Tuple, Union

import polars as pl
import numpy as np
import pm4py

from pl4pm.constants import (
    CASE_ID_KEY, ACTIVITY_KEY, TIMESTAMP_KEY, RESOURCE_KEY,
)
from pl4pm.objects.petri_net import PetriNet, Marking, add_arc_from_to
from pl4pm.objects.process_tree import ProcessTree, Operator
from pl4pm.objects.bpmn import BPMN
from pl4pm.objects.log import Trace


_WF_NET_CACHE: Dict[int, bool] = {}
_SIMPLICITY_CACHE: Dict[Tuple[int, int, int, Optional[str]], float] = {}


def _is_petri_net_like(obj: Any) -> bool:
    return hasattr(obj, "places") and hasattr(obj, "transitions")


def _is_place_like(obj: Any) -> bool:
    return hasattr(obj, "in_arcs") and hasattr(obj, "out_arcs") and not hasattr(obj, "label")


def _is_transition_like(obj: Any) -> bool:
    return hasattr(obj, "in_arcs") and hasattr(obj, "out_arcs") and hasattr(obj, "label")


def _is_pm4py_petri_net(obj: Any) -> bool:
    return _is_petri_net_like(obj) and type(obj).__module__.startswith("pm4py.")


def _as_lazy_frame(log: pl.LazyFrame) -> pl.LazyFrame:
    return log if isinstance(log, pl.LazyFrame) else log.lazy()


# ══════════════════════════════════════════════════════════════════════
# Enabled transitions
# ══════════════════════════════════════════════════════════════════════

def get_enabled_transitions(
    net: PetriNet, marking: Marking,
) -> Set[PetriNet.Transition]:
    """Get transitions enabled in the given marking."""
    enabled: Set[PetriNet.Transition] = set()
    for t in net.transitions:
        ok = True
        for arc in t.in_arcs:
            if marking.get(arc.source, 0) < arc.weight:
                ok = False
                break
        if ok:
            enabled.add(t)
    return enabled


# ══════════════════════════════════════════════════════════════════════
# Synchronous product net
# ══════════════════════════════════════════════════════════════════════

def construct_synchronous_product_net(
    trace: Trace | List[str],
    petri_net: PetriNet,
    initial_marking: Marking,
    final_marking: Marking,
) -> Tuple[PetriNet, Marking, Marking]:
    """Construct the synchronous product net between a trace and a Petri net."""
    activities = trace if isinstance(trace, list) else [e.get(ACTIVITY_KEY, "") for e in trace]
    n = len(activities)

    sync_net = PetriNet("sync_product")

    # Create trace places p_0 .. p_n
    trace_places = []
    for i in range(n + 1):
        p = PetriNet.Place(f"tp_{i}")
        sync_net.places.add(p)
        trace_places.append(p)

    # Copy model places
    model_place_map: Dict[str, PetriNet.Place] = {}
    for p in petri_net.places:
        sp = PetriNet.Place(f"mp_{p.name}")
        sync_net.places.add(sp)
        model_place_map[p.name] = sp

    # Copy model transitions as model-moves
    model_trans_map: Dict[str, PetriNet.Transition] = {}
    for t in petri_net.transitions:
        st = PetriNet.Transition(f"model_{t.name}", label=None)
        sync_net.transitions.add(st)
        model_trans_map[t.name] = st
        for arc in t.in_arcs:
            add_arc_from_to(model_place_map[arc.source.name], st, sync_net, arc.weight)
        for arc in t.out_arcs:
            add_arc_from_to(st, model_place_map[arc.target.name], sync_net, arc.weight)

    # Trace transitions (log moves)
    for i in range(n):
        lt = PetriNet.Transition(f"log_{i}_{activities[i]}", label=None)
        sync_net.transitions.add(lt)
        add_arc_from_to(trace_places[i], lt, sync_net)
        add_arc_from_to(lt, trace_places[i + 1], sync_net)

    # Sync transitions
    label_to_trans = {t.label: t for t in petri_net.transitions if t.label}
    for i in range(n):
        act = activities[i]
        if act in label_to_trans:
            mt = label_to_trans[act]
            st = PetriNet.Transition(f"sync_{i}_{act}", label=act)
            sync_net.transitions.add(st)
            add_arc_from_to(trace_places[i], st, sync_net)
            add_arc_from_to(st, trace_places[i + 1], sync_net)
            for arc in mt.in_arcs:
                add_arc_from_to(model_place_map[arc.source.name], st, sync_net, arc.weight)
            for arc in mt.out_arcs:
                add_arc_from_to(st, model_place_map[arc.target.name], sync_net, arc.weight)

    # Markings
    sync_im = Marking({trace_places[0]: 1})
    for p, tokens in initial_marking.items():
        sync_im[model_place_map[p.name]] = tokens

    sync_fm = Marking({trace_places[n]: 1})
    for p, tokens in final_marking.items():
        sync_fm[model_place_map[p.name]] = tokens

    return sync_net, sync_im, sync_fm


# ══════════════════════════════════════════════════════════════════════
# Earth Mover Distance
# ══════════════════════════════════════════════════════════════════════

def compute_emd(
    language1: Dict, language2: Dict,
) -> float:
    """Compute Earth Mover Distance between two stochastic languages."""
    all_variants = set(
        [tuple(k) if isinstance(k, list) else k for k in language1.keys()]
    ) | set(
        [tuple(k) if isinstance(k, list) else k for k in language2.keys()]
    )

    if not all_variants:
        return 0.0

    def _norm(lang: dict) -> Dict[tuple, float]:
        total = sum(lang.values())
        if total == 0:
            return {}
        return {(tuple(k) if isinstance(k, list) else k): v / total for k, v in lang.items()}

    n1 = _norm(language1)
    n2 = _norm(language2)

    emd = 0.0
    for v in all_variants:
        p1 = n1.get(v, 0.0)
        p2 = n2.get(v, 0.0)
        emd += abs(p1 - p2)

    return emd / 2.0


# ══════════════════════════════════════════════════════════════════════
# Marking equation
# ══════════════════════════════════════════════════════════════════════

def solve_marking_equation(
    petri_net: PetriNet,
    initial_marking: Marking,
    final_marking: Marking,
    cost_function: Optional[Dict[PetriNet.Transition, float]] = None,
) -> float:
    """Solve the marking equation using a simplified ILP heuristic."""
    transitions = list(petri_net.transitions)
    places = list(petri_net.places)
    n_t = len(transitions)
    n_p = len(places)

    if n_t == 0:
        return 0.0

    costs = cost_function or {t: 1.0 for t in transitions}

    # Incidence matrix
    place_idx = {p: i for i, p in enumerate(places)}
    A = np.zeros((n_p, n_t), dtype=np.float64)
    for j, t in enumerate(transitions):
        for arc in t.in_arcs:
            i = place_idx.get(arc.source)
            if i is not None:
                A[i, j] -= arc.weight
        for arc in t.out_arcs:
            i = place_idx.get(arc.target)
            if i is not None:
                A[i, j] += arc.weight

    # b = fm - im
    b = np.zeros(n_p, dtype=np.float64)
    for p, tokens in final_marking.items():
        if p in place_idx:
            b[place_idx[p]] += tokens
    for p, tokens in initial_marking.items():
        if p in place_idx:
            b[place_idx[p]] -= tokens

    # Simple heuristic: least-squares solution
    try:
        x, _, _, _ = np.linalg.lstsq(A, b, rcond=None)
        x = np.maximum(x, 0)
        cost = sum(costs.get(transitions[j], 1.0) * x[j] for j in range(n_t))
        return float(cost)
    except Exception:
        return float("inf")


def solve_extended_marking_equation(
    trace: Trace | List[str],
    sync_net: PetriNet,
    sync_im: Marking,
    sync_fm: Marking,
    split_points: Optional[List[int]] = None,
) -> float:
    """Solve the extended marking equation on a synchronous product net."""
    return solve_marking_equation(sync_net, sync_im, sync_fm)


# ══════════════════════════════════════════════════════════════════════
# Soundness and workflow net checks
# ══════════════════════════════════════════════════════════════════════

def check_is_workflow_net(net: PetriNet) -> bool:
    """Check if a Petri net satisfies WF-net conditions."""
    cache_key = id(net)
    cached = _WF_NET_CACHE.get(cache_key)
    if cached is not None:
        return cached

    sources = [p for p in net.places if len(p.in_arcs) == 0]
    sinks = [p for p in net.places if len(p.out_arcs) == 0]

    if len(sources) != 1 or len(sinks) != 1:
        return False

    # Every node on path from source to sink (reachability)
    source = sources[0]
    sink = sinks[0]

    reachable_from_source: Set = set()
    queue = deque([source])
    while queue:
        node = queue.popleft()
        if node in reachable_from_source:
            continue
        reachable_from_source.add(node)
        queue.extend(arc.target for arc in node.out_arcs)

    reach_to_sink: Set = set()
    queue = deque([sink])
    while queue:
        node = queue.popleft()
        if node in reach_to_sink:
            continue
        reach_to_sink.add(node)
        queue.extend(arc.source for arc in node.in_arcs)

    all_nodes = set(net.places) | set(net.transitions)
    result = all_nodes.issubset(reachable_from_source & reach_to_sink)
    _WF_NET_CACHE[cache_key] = result
    return result


def check_is_sound(
    petri_net: PetriNet,
    initial_marking: Marking,
    final_marking: Marking,
) -> bool:
    """Check if a Petri net is a sound WF-net."""
    if not check_is_workflow_net(petri_net):
        return False
    is_s, _ = check_soundness(petri_net, initial_marking, final_marking)
    return is_s


def check_soundness(
    petri_net: PetriNet,
    initial_marking: Marking,
    final_marking: Marking,
    print_diagnostics: bool = False,
) -> Tuple[bool, Dict[str, Any]]:
    """Check WF-net soundness with diagnostics via reachability exploration."""
    from pl4pm.conformance.token_replay import _fire_transition

    diagnostics: Dict[str, Any] = {
        "is_wf_net": check_is_workflow_net(petri_net),
        "deadlocks": [],
        "livelocks": False,
        "n_reachable_states": 0,
        "can_reach_final_marking": False,
    }

    if not diagnostics["is_wf_net"]:
        return False, diagnostics

    # BFS reachability
    def _mk(m: Marking) -> tuple:
        return tuple(sorted((p.name, v) for p, v in m.items()))

    visited: Set[tuple] = set()
    queue = [initial_marking]
    can_reach_fm = False
    max_states = 50_000

    while queue and len(visited) < max_states:
        marking = queue.pop(0)
        mk = _mk(marking)
        if mk in visited:
            continue
        visited.add(mk)

        if all(marking.get(p, 0) >= v for p, v in final_marking.items()):
            can_reach_fm = True

        enabled = get_enabled_transitions(petri_net, marking)
        if not enabled and not can_reach_fm:
            diagnostics["deadlocks"].append(marking)

        for t in enabled:
            new_m = _fire_transition(marking, t)
            nmk = _mk(new_m)
            if nmk not in visited:
                queue.append(new_m)

    is_sound = can_reach_fm and len(diagnostics["deadlocks"]) == 0
    diagnostics["can_reach_final_marking"] = can_reach_fm
    diagnostics["n_reachable_states"] = len(visited)

    if print_diagnostics:
        for key, val in diagnostics.items():
            print(f"  {key}: {val}")

    return is_sound, diagnostics


# ══════════════════════════════════════════════════════════════════════
# Simplicity
# ══════════════════════════════════════════════════════════════════════

def simplicity_petri_net(
    net: PetriNet,
    im: Marking,
    fm: Marking,
    variant: Optional[str] = "arc_degree",
) -> float:
    """Compute simplicity of a Petri net."""
    cache_key = (id(net), id(im), id(fm), variant)
    cached = _SIMPLICITY_CACHE.get(cache_key)
    if cached is not None:
        return cached

    if _is_pm4py_petri_net(net):
        result = float(pm4py.simplicity_petri_net(net, im, fm, variant=variant))
        _SIMPLICITY_CACHE[cache_key] = result
        return result

    if variant == "extended_cardoso":
        ext_card = 0
        for place in net.places:
            targets = set()
            for out_arc in place.out_arcs:
                targets1 = set()
                for out_arc2 in out_arc.target.out_arcs:
                    targets1.add(out_arc2.target.name)
                targets.add(tuple(sorted(targets1)))
            ext_card += len(targets)
        result = float(ext_card)
    elif variant == "extended_cyclomatic":
        n_arcs = len(net.arcs)
        n_nodes = len(net.places) + len(net.transitions)
        result = float(max(n_arcs - n_nodes + 2, 0))
    else:  # arc_degree (default)
        all_arc_degrees = []
        for place in net.places:
            all_arc_degrees.append(len(place.in_arcs) + len(place.out_arcs))
        for trans in net.transitions:
            all_arc_degrees.append(len(trans.in_arcs) + len(trans.out_arcs))
        mean_degree = float(np.mean(all_arc_degrees)) if all_arc_degrees else 0.0
        result = 1.0 / (1.0 + max(mean_degree - 2.0, 0.0))

    _SIMPLICITY_CACHE[cache_key] = result
    return result


# ══════════════════════════════════════════════════════════════════════
# Maximal decomposition
# ══════════════════════════════════════════════════════════════════════

def maximal_decomposition(
    net: PetriNet, im: Marking, fm: Marking,
) -> List[Tuple[PetriNet, Marking, Marking]]:
    """Decompose a Petri net into maximal components (one per transition)."""
    components: List[Tuple[PetriNet, Marking, Marking]] = []

    for t in net.transitions:
        subnet = PetriNet(f"component_{t.name}")
        place_map: Dict[str, PetriNet.Place] = {}
        st = PetriNet.Transition(t.name, label=t.label)
        subnet.transitions.add(st)

        for arc in t.in_arcs:
            p = arc.source
            if p.name not in place_map:
                sp = PetriNet.Place(p.name)
                subnet.places.add(sp)
                place_map[p.name] = sp
            add_arc_from_to(place_map[p.name], st, subnet, arc.weight)

        for arc in t.out_arcs:
            p = arc.target
            if p.name not in place_map:
                sp = PetriNet.Place(p.name)
                subnet.places.add(sp)
                place_map[p.name] = sp
            add_arc_from_to(st, place_map[p.name], subnet, arc.weight)

        sub_im = Marking()
        for p, tokens in im.items():
            if p.name in place_map:
                sub_im[place_map[p.name]] = tokens
        sub_fm = Marking()
        for p, tokens in fm.items():
            if p.name in place_map:
                sub_fm[place_map[p.name]] = tokens

        components.append((subnet, sub_im, sub_fm))

    return components


# ══════════════════════════════════════════════════════════════════════
# Marking generation
# ══════════════════════════════════════════════════════════════════════

def generate_marking(
    net: PetriNet,
    place_or_dct: Union[str, PetriNet.Place, Dict],
) -> Marking:
    """Generate a Marking from a place name, Place object, or dict."""
    place_by_name = {p.name: p for p in net.places}

    if isinstance(place_or_dct, PetriNet.Place):
        return Marking({place_or_dct: 1})
    elif isinstance(place_or_dct, str):
        if place_or_dct in place_by_name:
            return Marking({place_by_name[place_or_dct]: 1})
        raise ValueError(f"Place '{place_or_dct}' not found in net")
    elif isinstance(place_or_dct, dict):
        m = Marking()
        for k, v in place_or_dct.items():
            if isinstance(k, PetriNet.Place):
                m[k] = v
            elif isinstance(k, str):
                if k in place_by_name:
                    m[place_by_name[k]] = v
                else:
                    raise ValueError(f"Place '{k}' not found")
            else:
                raise TypeError(f"Unsupported key type: {type(k)}")
        return m
    raise TypeError(f"Unsupported type: {type(place_or_dct)}")


# ══════════════════════════════════════════════════════════════════════
# Petri net reductions
# ══════════════════════════════════════════════════════════════════════

def reduce_petri_net_invisibles(net: PetriNet) -> PetriNet:
    """Reduce invisible transitions where possible (fusion of series)."""
    changed = True
    while changed:
        changed = False
        for t in list(net.transitions):
            if t.label is not None:
                continue
            in_places = [a.source for a in t.in_arcs]
            out_places = [a.target for a in t.out_arcs]
            if len(in_places) == 1 and len(out_places) == 1:
                p_in = in_places[0]
                p_out = out_places[0]
                if len(p_in.out_arcs) == 1 and len(p_out.in_arcs) == 1:
                    # Merge: redirect all arcs from p_out to p_in
                    for arc in list(p_out.out_arcs):
                        add_arc_from_to(p_in, arc.target, net, arc.weight)
                    # Remove t, p_out, and related arcs
                    net.transitions.discard(t)
                    net.places.discard(p_out)
                    net.arcs -= t.in_arcs | t.out_arcs | p_out.out_arcs
                    changed = True
                    break
    return net


def reduce_petri_net_implicit_places(
    net: PetriNet, im: Marking, fm: Marking,
) -> Tuple[PetriNet, Marking, Marking]:
    """Remove implicit places (places whose removal doesn't change behavior)."""
    implicit = []
    for p in net.places:
        if p in im or p in fm:
            continue
        in_trans = {a.source for a in p.in_arcs}
        out_trans = {a.target for a in p.out_arcs}
        if len(in_trans) == 1 and len(out_trans) == 1:
            t_in = next(iter(in_trans))
            t_out = next(iter(out_trans))
            other_places_between = set()
            for arc in t_in.out_arcs:
                if arc.target != p:
                    for arc2 in arc.target.out_arcs:
                        if arc2.target == t_out:
                            other_places_between.add(arc.target)
            if other_places_between:
                implicit.append(p)

    for p in implicit:
        net.arcs -= p.in_arcs | p.out_arcs
        net.places.discard(p)

    return net, im, fm


# ══════════════════════════════════════════════════════════════════════
# Log enrichment
# ══════════════════════════════════════════════════════════════════════

def insert_artificial_start_end(
    log: pl.LazyFrame,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
    artificial_start: str = "▶",
    artificial_end: str = "■",
) -> pl.DataFrame:
    """Insert artificial start and end events."""
    lf = _as_lazy_frame(log).sort([case_id_key, timestamp_key])
    delta = pl.duration(microseconds=1)

    case_bounds = lf.group_by(case_id_key).agg([
        pl.col(timestamp_key).min().alias("_start_ts"),
        pl.col(timestamp_key).max().alias("_end_ts"),
    ])

    common_cols = [case_id_key, activity_key, timestamp_key]
    starts = case_bounds.select([
        pl.col(case_id_key),
        pl.lit(artificial_start).alias(activity_key),
        (pl.col("_start_ts") - delta).alias(timestamp_key),
    ])
    ends = case_bounds.select([
        pl.col(case_id_key),
        pl.lit(artificial_end).alias(activity_key),
        (pl.col("_end_ts") + delta).alias(timestamp_key),
    ])

    return (
        pl.concat([
            starts,
            lf.select(common_cols),
            ends,
        ])
        .sort([case_id_key, timestamp_key])
        .collect()
    )


def insert_case_service_waiting_time(
    log: pl.LazyFrame,
    service_time_column: str = "@@service_time",
    sojourn_time_column: str = "@@sojourn_time",
    waiting_time_column: str = "@@waiting_time",
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
    start_timestamp_key: str = TIMESTAMP_KEY,
) -> pl.DataFrame:
    """Insert service, waiting, and sojourn time columns."""
    return (
        _as_lazy_frame(log)
        .sort([case_id_key, timestamp_key])
        .with_columns([
            (pl.col(timestamp_key) - pl.col(start_timestamp_key))
            .dt.total_seconds()
            .alias(service_time_column),
            (pl.col(timestamp_key) - pl.col(timestamp_key).shift(1).over(case_id_key))
            .dt.total_seconds()
            .fill_null(0.0)
            .alias(sojourn_time_column),
        ])
        .with_columns(
            (pl.col(sojourn_time_column) - pl.col(service_time_column))
            .alias(waiting_time_column),
        )
        .collect()
    )


def insert_case_arrival_finish_rate(
    log: pl.LazyFrame,
    arrival_rate_column: str = "@@arrival_rate",
    finish_rate_column: str = "@@finish_rate",
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
    start_timestamp_key: str = TIMESTAMP_KEY,
) -> pl.DataFrame:
    """Insert arrival and finish rate columns."""
    lf = _as_lazy_frame(log)

    case_times = (
        lf.group_by(case_id_key)
        .agg([
            pl.col(timestamp_key).min().alias("_case_start"),
            pl.col(timestamp_key).max().alias("_case_end"),
        ])
        .sort("_case_start")
        .with_columns([
            (pl.col("_case_start") - pl.col("_case_start").shift(1))
            .dt.total_seconds()
            .fill_null(0.0)
            .alias(arrival_rate_column),
            (pl.col("_case_end").shift(-1) - pl.col("_case_end"))
            .dt.total_seconds()
            .fill_null(0.0)
            .alias(finish_rate_column),
        ])
        .select([case_id_key, arrival_rate_column, finish_rate_column])
    )

    return lf.join(case_times, on=case_id_key, how="left").collect()


# ══════════════════════════════════════════════════════════════════════
# Activity labels
# ══════════════════════════════════════════════════════════════════════

def get_activity_labels(*args) -> List[str]:
    """Get activity labels from a log or model."""
    for obj in args:
        if isinstance(obj, pl.DataFrame):
            if ACTIVITY_KEY in obj.columns:
                return sorted(obj.get_column(ACTIVITY_KEY).unique().to_list())
        elif isinstance(obj, pl.LazyFrame):
            schema = obj.collect_schema()
            if ACTIVITY_KEY in schema:
                values = (
                    obj.select(pl.col(ACTIVITY_KEY).unique().sort())
                    .collect()
                    .get_column(ACTIVITY_KEY)
                    .to_list()
                )
                return list(values)
        elif isinstance(obj, PetriNet) or _is_petri_net_like(obj):
            return sorted({t.label for t in obj.transitions if t.label})
        elif isinstance(obj, ProcessTree):
            return sorted(_tree_labels(obj))
        elif isinstance(obj, BPMN):
            return sorted({n.name for n in obj.nodes if n.node_type == BPMN.NodeType.TASK})
    return []


def _tree_labels(tree: ProcessTree) -> Set[str]:
    labels: Set[str] = set()
    if tree.label:
        labels.add(tree.label)
    for c in tree.children:
        labels |= _tree_labels(c)
    return labels


def replace_activity_labels(string_dictio: Dict[str, str], *args):
    """Replace activity labels in a process model."""
    for obj in args:
        if isinstance(obj, PetriNet):
            for t in obj.transitions:
                if t.label and t.label in string_dictio:
                    t.label = string_dictio[t.label]
        elif isinstance(obj, ProcessTree):
            _replace_tree_labels(obj, string_dictio)
    return args[0] if len(args) == 1 else args


def _replace_tree_labels(tree: ProcessTree, mapping: Dict[str, str]):
    if tree.label and tree.label in mapping:
        tree.label = mapping[tree.label]
    for c in tree.children:
        _replace_tree_labels(c, mapping)


# ══════════════════════════════════════════════════════════════════════
# Similarity metrics
# ══════════════════════════════════════════════════════════════════════

def behavioral_similarity(*args) -> float:
    """Footprints-based behavioral similarity between two models.

    Accepts:
        (net1, im1, fm1, net2, im2, fm2) — two Petri nets with markings
        (log1, log2) — two event logs
        (fp_dict1, fp_dict2) — two precomputed footprint dicts
    """
    from pl4pm.discovery.footprints import discover_footprints

    # Parse arguments into two footprint dicts
    if len(args) == 6 and _is_petri_net_like(args[0]) and _is_petri_net_like(args[3]):
        fp1 = discover_footprints(args[0], args[1], args[2])
        fp2 = discover_footprints(args[3], args[4], args[5])
    elif len(args) == 2:
        fp1 = discover_footprints(args[0]) if not isinstance(args[0], dict) else args[0]
        fp2 = discover_footprints(args[1]) if not isinstance(args[1], dict) else args[1]
    elif len(args) == 4 and _is_petri_net_like(args[0]):
        # (net, im, fm, log_or_dict)
        fp1 = discover_footprints(args[0], args[1], args[2])
        fp2 = discover_footprints(args[3]) if not isinstance(args[3], dict) else args[3]
    else:
        raise ValueError(f"Cannot compute behavioral_similarity from {len(args)} args")

    rel1 = fp1.get("sequence", set()) | fp1.get("parallel", set())
    rel2 = fp2.get("sequence", set()) | fp2.get("parallel", set())
    if not rel1 and not rel2:
        return 1.0
    intersection = len(rel1 & rel2)
    union = len(rel1 | rel2)
    return intersection / max(union, 1)


def structural_similarity(*args) -> float:
    """Structural similarity (Jaccard on transitions/places)."""
    labels = []
    for obj in args:
        if isinstance(obj, PetriNet):
            labels.append({t.label for t in obj.transitions if t.label})
        elif isinstance(obj, ProcessTree):
            labels.append(_tree_labels(obj))
        elif isinstance(obj, BPMN):
            labels.append({n.name for n in obj.nodes if n.node_type == BPMN.NodeType.TASK})
        elif isinstance(obj, Marking):
            continue
        else:
            labels.append(set())
    if len(labels) < 2:
        return 0.0
    s1, s2 = labels[0], labels[-1]
    if not s1 and not s2:
        return 1.0
    return len(s1 & s2) / max(len(s1 | s2), 1)


def label_sets_similarity(*args, threshold: float = 0.75) -> float:
    """Label sets similarity between two models."""
    return structural_similarity(*args)


def embeddings_similarity(*args) -> float:
    """Embeddings similarity (simplified: label Jaccard)."""
    return structural_similarity(*args)


def map_labels_from_second_model(
    *args, threshold: float = 0.75,
):
    """Map labels from second model into first (no-op placeholder)."""
    return args[0] if args else None


# ══════════════════════════════════════════════════════════════════════
# Clustering
# ══════════════════════════════════════════════════════════════════════

def cluster_log(
    log: pl.LazyFrame,
    sklearn_clusterer=None,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
) -> Generator[pl.DataFrame, None, None]:
    """Cluster traces using sklearn (default: KMeans k=2)."""
    df = log.collect() if isinstance(log, pl.LazyFrame) else log
    df = df.sort([case_id_key, timestamp_key])

    # Build feature matrix: activity one-hot per case
    all_acts = sorted(df[activity_key].unique().to_list())
    act_to_idx = {a: i for i, a in enumerate(all_acts)}
    n_acts = len(all_acts)

    cases = df.group_by(case_id_key, maintain_order=True)
    case_ids: List[str] = []
    features_list: List[List[float]] = []

    for cid, group in cases:
        case_ids.append(str(cid[0]) if isinstance(cid, tuple) else str(cid))
        vec = [0.0] * n_acts
        for act in group[activity_key].to_list():
            if act in act_to_idx:
                vec[act_to_idx[act]] += 1
        features_list.append(vec)

    X = np.array(features_list)

    if sklearn_clusterer is None:
        try:
            from sklearn.cluster import KMeans
            sklearn_clusterer = KMeans(n_clusters=2, random_state=0, n_init="auto")
        except ImportError:
            # Fallback: simple 2-cluster by median distance
            norms = np.linalg.norm(X, axis=1)
            median = np.median(norms)
            labels = (norms >= median).astype(int)
            for label in np.unique(labels):
                mask_cases = [case_ids[i] for i in range(len(labels)) if labels[i] == label]
                yield df.filter(pl.col(case_id_key).is_in(mask_cases))
            return

    labels = sklearn_clusterer.fit_predict(X)
    for label in np.unique(labels):
        mask_cases = [case_ids[i] for i in range(len(labels)) if labels[i] == label]
        yield df.filter(pl.col(case_id_key).is_in(mask_cases))


__all__ = [
    "get_enabled_transitions",
    "construct_synchronous_product_net",
    "compute_emd",
    "solve_marking_equation",
    "solve_extended_marking_equation",
    "check_is_workflow_net",
    "check_is_sound",
    "check_soundness",
    "simplicity_petri_net",
    "maximal_decomposition",
    "generate_marking",
    "reduce_petri_net_invisibles",
    "reduce_petri_net_implicit_places",
    "insert_artificial_start_end",
    "insert_case_service_waiting_time",
    "insert_case_arrival_finish_rate",
    "get_activity_labels",
    "replace_activity_labels",
    "behavioral_similarity",
    "structural_similarity",
    "label_sets_similarity",
    "embeddings_similarity",
    "map_labels_from_second_model",
    "cluster_log",
]
