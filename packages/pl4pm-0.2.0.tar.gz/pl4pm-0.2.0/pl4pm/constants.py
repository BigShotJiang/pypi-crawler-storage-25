"""pl4pm.constants — Default column keys and constants."""

# Standard XES column keys
CASE_ID_KEY: str = "case:concept:name"
ACTIVITY_KEY: str = "concept:name"
TIMESTAMP_KEY: str = "time:timestamp"
START_TIMESTAMP_KEY: str = "time:timestamp"
RESOURCE_KEY: str = "org:resource"
GROUP_KEY: str = "org:group"
LIFECYCLE_KEY: str = "lifecycle:transition"

# Internal utility column names
VARIANT_COLUMN: str = "@@variant_column"
VARIANT_COUNT: str = "@@variant_count"
INDEX_IN_TRACE: str = "@@index_in_trace"
CUMULATIVE_OCC_PATH: str = "@@cumulative_occ_path_column"
SOJOURN_TIME: str = "@@sojourn_time"
ARRIVAL_RATE: str = "@@arrival_rate"
FINISH_RATE: str = "@@finish_rate"

# XES XML namespaces and tags
XES_TAG_LOG: str = "log"
XES_TAG_TRACE: str = "trace"
XES_TAG_EVENT: str = "event"
XES_TAG_STRING: str = "string"
XES_TAG_DATE: str = "date"
XES_TAG_INT: str = "int"
XES_TAG_FLOAT: str = "float"
XES_TAG_BOOLEAN: str = "boolean"
XES_TAG_LIST: str = "list"
XES_TAG_ID: str = "id"

# Default business hour slots (seconds from week-start)
DEFAULT_BUSINESS_HOUR_SLOTS: list[tuple[int, int]] = [
    (25200, 61200),    # Mon 07:00–17:00
    (111600, 147600),  # Tue 07:00–17:00
    (198000, 234000),  # Wed 07:00–17:00
    (284400, 320400),  # Thu 07:00–17:00
    (370800, 406800),  # Fri 07:00–17:00
]
