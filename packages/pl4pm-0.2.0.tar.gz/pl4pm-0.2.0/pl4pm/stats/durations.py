"""pl4pm.stats.durations — Case durations, service time, cycle time, arrival average."""

from __future__ import annotations

from typing import Dict, List, Optional, Tuple, Union

import polars as pl

from pl4pm.constants import (
    CASE_ID_KEY, ACTIVITY_KEY, TIMESTAMP_KEY, START_TIMESTAMP_KEY,
    DEFAULT_BUSINESS_HOUR_SLOTS,
)
from pl4pm.utils import finalize_lazy_result


_DURATION_UNIT_TO_SECONDS: dict[str, float] = {
    "ms": 0.001,
    "millisecond": 0.001,
    "milliseconds": 0.001,
    "milisegundo": 0.001,
    "milisegundos": 0.001,
    "s": 1.0,
    "sec": 1.0,
    "secs": 1.0,
    "second": 1.0,
    "seconds": 1.0,
    "segundo": 1.0,
    "segundos": 1.0,
    "m": 60.0,
    "min": 60.0,
    "mins": 60.0,
    "minute": 60.0,
    "minutes": 60.0,
    "minuto": 60.0,
    "minutos": 60.0,
    "h": 3600.0,
    "hr": 3600.0,
    "hrs": 3600.0,
    "hour": 3600.0,
    "hours": 3600.0,
    "hora": 3600.0,
    "horas": 3600.0,
    "d": 86400.0,
    "day": 86400.0,
    "days": 86400.0,
    "dia": 86400.0,
    "dias": 86400.0,
}


def _duration_unit_divisor(measure: str) -> float:
    key = measure.strip().lower()
    if key not in _DURATION_UNIT_TO_SECONDS:
        raise ValueError(f"Unsupported duration measure: {measure!r}")
    return _DURATION_UNIT_TO_SECONDS[key]


def get_all_case_durations(
    log: pl.LazyFrame,
    business_hours: bool = False,
    business_hour_slots: Optional[List[Tuple[int, int]]] = None,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
) -> List[float]:
    """Return sorted list of all case durations in seconds."""
    lf = log if isinstance(log, pl.LazyFrame) else log.lazy()
    result = (
        lf.group_by(case_id_key)
        .agg([
            pl.col(timestamp_key).min().alias("start"),
            pl.col(timestamp_key).max().alias("end"),
        ])
        .with_columns(
            (pl.col("end") - pl.col("start")).dt.total_seconds().alias("duration")
        )
        .sort("duration")
        .select("duration")
        .collect()
    )
    return result["duration"].to_list()


def get_case_duration(
    log: pl.LazyFrame,
    case_id: str,
    business_hours: bool = False,
    business_hour_slots: Optional[List[Tuple[int, int]]] = None,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
) -> float:
    """Return the duration of a specific case in seconds."""
    lf = log if isinstance(log, pl.LazyFrame) else log.lazy()
    result = (
        lf.filter(pl.col(case_id_key) == case_id)
        .select([
            pl.col(timestamp_key).min().alias("start"),
            pl.col(timestamp_key).max().alias("end"),
        ])
        .with_columns(
            (pl.col("end") - pl.col("start")).dt.total_seconds().alias("duration")
        )
        .collect()
    )
    if result.height == 0:
        return 0.0
    return result["duration"][0]


def get_case_arrival_average(
    log: pl.LazyFrame,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
) -> float:
    """Return average time between consecutive case start times (seconds)."""
    lf = log if isinstance(log, pl.LazyFrame) else log.lazy()
    case_starts = (
        lf.group_by(case_id_key)
        .agg(pl.col(timestamp_key).min().alias("case_start"))
        .sort("case_start")
        .with_columns(
            pl.col("case_start").shift(1).alias("prev_start")
        )
        .filter(pl.col("prev_start").is_not_null())
        .with_columns(
            (pl.col("case_start") - pl.col("prev_start"))
            .dt.total_seconds()
            .alias("diff")
        )
        .select(pl.col("diff").mean().alias("avg"))
        .collect()
    )
    if case_starts.height == 0:
        return 0.0
    return case_starts["avg"][0]


def get_cycle_time(
    log: pl.LazyFrame,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
    start_timestamp_key: str = START_TIMESTAMP_KEY,
) -> float:
    """Return cycle time: average per-event processing time.

    Computes the mean of (complete_timestamp - start_timestamp) for all
    events.  Returns 0.0 when no separate start_timestamp column exists
    (matching pm4py behaviour).
    """
    lf = log if isinstance(log, pl.LazyFrame) else log.lazy()
    schema = lf.collect_schema()

    # If there is no distinct start_timestamp column → instant events → 0
    if start_timestamp_key not in schema.names() or start_timestamp_key == timestamp_key:
        return 0.0

    result = (
        lf.with_columns(
            (pl.col(timestamp_key) - pl.col(start_timestamp_key))
            .dt.total_seconds()
            .alias("_evt_dur")
        )
        .select(pl.col("_evt_dur").mean().alias("avg"))
        .collect()
    )
    if result.height == 0 or result["avg"][0] is None:
        return 0.0
    return result["avg"][0]


def get_service_time(
    log: pl.LazyFrame,
    aggregation_measure: str = "mean",
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    start_timestamp_key: str = START_TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
) -> Dict[str, float]:
    """Return service time per activity using the given aggregation."""
    lf = log if isinstance(log, pl.LazyFrame) else log.lazy()

    # If start_timestamp_key is the same as timestamp_key, service time = 0
    if start_timestamp_key == timestamp_key:
        # Use diff between consecutive events within each case as proxy
        schema = lf.collect_schema()
        if start_timestamp_key in schema.names():
            result = (
                lf.sort([case_id_key, timestamp_key])
                .group_by(activity_key)
                .agg(pl.lit(0.0).alias("service_time"))
                .collect()
            )
            return dict(zip(
                result[activity_key].to_list(),
                result["service_time"].to_list()
            ))
    else:
        lf = lf.with_columns(
            (pl.col(timestamp_key) - pl.col(start_timestamp_key))
            .dt.total_seconds()
            .alias("svc_duration")
        )
        agg_expr = getattr(pl.col("svc_duration"), aggregation_measure)()

        result = (
            lf.group_by(activity_key)
            .agg(agg_expr.alias("service_time"))
            .collect()
        )
        return dict(zip(
            result[activity_key].to_list(),
            result["service_time"].to_list()
        ))

    return {}


def get_activity_pair_average_durations(
    log: pl.LazyFrame,
    measure: str = "seconds",
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
    do_collect: bool = False,
    collect_engine: str | None = None,
) -> pl.LazyFrame | pl.DataFrame:
    """Return the average duration between all ordered activity pairs.

    The result contains one row per ordered pair of activities with:
    ``source_activity``, ``target_activity``, ``avg_duration`` and ``occurrences``.
    Only later events within the same case are considered.
    """
    divisor = _duration_unit_divisor(measure)
    lf = log if isinstance(log, pl.LazyFrame) else log.lazy()
    unit_scale = divisor * 1_000_000.0

    ordered = (
        lf.select([case_id_key, activity_key, timestamp_key])
        .sort([case_id_key, timestamp_key])
        .with_columns(
            [
                (pl.col(case_id_key).cum_count().over(case_id_key) - 1).alias("_pos"),
                pl.col(timestamp_key).dt.epoch(time_unit="us").alias("_ts_us"),
            ]
        )
    )

    case_targets = (
        ordered.select(
            [
                pl.col(case_id_key),
                pl.col(activity_key).alias("target_activity"),
            ]
        )
        .unique()
    )

    target_suffix = (
        ordered.select(
            [
                pl.col(case_id_key),
                pl.col(activity_key).alias("target_activity"),
                pl.col("_pos").alias("_target_pos"),
                pl.col("_ts_us").alias("_target_ts_us"),
            ]
        )
        .sort([case_id_key, "target_activity", "_target_pos"], descending=[False, False, True])
        .with_columns(
            [
                pl.col("_target_pos").cum_count().over([case_id_key, "target_activity"]).alias("_remaining_count"),
                pl.col("_target_ts_us").cum_sum().over([case_id_key, "target_activity"]).alias("_remaining_ts_us"),
            ]
        )
        .sort([case_id_key, "target_activity", "_target_pos"])
    )

    result = (
        ordered.select(
            [
                pl.col(case_id_key),
                pl.col(activity_key).alias("source_activity"),
                pl.col("_pos"),
                pl.col("_ts_us"),
            ]
        )
        .join(case_targets, on=case_id_key, how="inner")
        .with_columns((pl.col("_pos") + 1).alias("_next_pos"))
        .sort([case_id_key, "target_activity", "_next_pos"])
        .join_asof(
            target_suffix,
            left_on="_next_pos",
            right_on="_target_pos",
            by=[case_id_key, "target_activity"],
            strategy="forward",
        )
        .filter(pl.col("_remaining_count").is_not_null())
        .with_columns(
            (
                (
                    pl.col("_remaining_ts_us").cast(pl.Float64)
                    - pl.col("_remaining_count").cast(pl.Float64) * pl.col("_ts_us").cast(pl.Float64)
                )
                / unit_scale
            ).alias("_duration_sum")
        )
        .group_by(["source_activity", "target_activity"])
        .agg(
            [
                pl.col("_duration_sum").sum().alias("_duration_sum"),
                pl.col("_remaining_count").sum().alias("occurrences"),
            ]
        )
        .filter(pl.col("occurrences") > 0)
        .with_columns(
            (pl.col("_duration_sum") / pl.col("occurrences").cast(pl.Float64)).alias("avg_duration")
        )
        .select(["source_activity", "target_activity", "avg_duration", "occurrences"])
        .sort(["source_activity", "target_activity"])
    )
    return finalize_lazy_result(result, do_collect=do_collect, collect_engine=collect_engine)
