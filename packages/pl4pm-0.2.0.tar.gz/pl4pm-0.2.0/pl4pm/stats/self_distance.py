"""pl4pm.stats.self_distance — Minimum self-distance and witnesses (vectorized)."""

from __future__ import annotations

from typing import Dict, Set

import polars as pl

from pl4pm.constants import CASE_ID_KEY, ACTIVITY_KEY, TIMESTAMP_KEY


def get_minimum_self_distances(
    log: pl.LazyFrame,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
) -> Dict[str, int]:
    """Compute minimum self-distance for each activity.

    Self-distance of 'a' in <a,b,c,a> is 2 (two activities between occurrences).
    """
    df = log.collect() if isinstance(log, pl.LazyFrame) else log
    df = df.sort([case_id_key, timestamp_key])

    # Assign 0-based position within each case
    with_pos = df.with_columns(
        pl.col(activity_key)
        .cum_count()
        .over(case_id_key)
        .alias("_pos")
    )

    # Group by (case, activity), collect sorted position lists,
    # filter to activities that repeat within a case
    positions = (
        with_pos
        .group_by([case_id_key, activity_key])
        .agg(pl.col("_pos").sort().alias("positions"))
        .filter(pl.col("positions").list.len() > 1)
    )

    # Compute consecutive differences using list.diff(), drop leading null,
    # subtract 1 to get self-distance, then take min per row
    with_min = positions.with_columns(
        (pl.col("positions").list.diff()
         .list.tail(pl.col("positions").list.len() - 1)  # drop leading null
         .list.min() - 1)
        .alias("_min_dist")
    )

    # Take global min per activity
    result = with_min.group_by(activity_key).agg(
        pl.col("_min_dist").min().alias("min_dist")
    )

    return dict(zip(
        result[activity_key].to_list(),
        result["min_dist"].to_list()
    ))


def get_minimum_self_distance_witnesses(
    log: pl.LazyFrame,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
) -> Dict[str, Set[str]]:
    """Return witness activities for each activity's minimum self-distance.

    Only activities with non-empty witness sets are included.
    """
    df = log.collect() if isinstance(log, pl.LazyFrame) else log
    df = df.sort([case_id_key, timestamp_key])

    msd = get_minimum_self_distances(df, activity_key, timestamp_key, case_id_key)
    if not msd:
        return {}

    witnesses: Dict[str, Set[str]] = {act: set() for act in msd}

    # Build activity list per case once — use to_list() for fast Python access
    case_acts = (
        df.group_by(case_id_key, maintain_order=True)
        .agg(pl.col(activity_key).alias("_acts"))
    )
    acts_lists = case_acts["_acts"].to_list()

    rework_acts = set(msd.keys())

    # Process each case's activity list in Python — minimal overhead
    for activities in acts_lists:
        last_seen: Dict[str, int] = {}
        for i, act in enumerate(activities):
            if act in rework_acts:
                prev = last_seen.get(act)
                if prev is not None:
                    dist = i - prev - 1
                    if dist == msd[act]:
                        witness_set = witnesses[act]
                        for j in range(prev + 1, i):
                            witness_set.add(activities[j])
                last_seen[act] = i

    return {k: v for k, v in witnesses.items() if v}
