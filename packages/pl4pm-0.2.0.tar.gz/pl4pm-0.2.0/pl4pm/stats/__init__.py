"""pl4pm.stats — Unified statistics module."""

from pl4pm.stats.activities import (
    get_start_activities,
    get_end_activities,
    get_rework_cases_per_activity,
    get_activity_position_summary,
)
from pl4pm.stats.attributes import (
    get_event_attributes,
    get_trace_attributes,
    get_event_attribute_values,
    get_trace_attribute_values,
)
from pl4pm.stats.variants import (
    get_variants,
    get_variants_as_tuples,
    split_by_process_variant,
    get_variants_paths_duration,
    get_stochastic_language,
)
from pl4pm.stats.durations import (
    get_all_case_durations,
    get_case_duration,
    get_case_arrival_average,
    get_cycle_time,
    get_service_time,
    get_activity_pair_average_durations,
)
from pl4pm.stats.self_distance import (
    get_minimum_self_distances,
    get_minimum_self_distance_witnesses,
)
from pl4pm.stats.case_overlap import get_case_overlap
from pl4pm.stats.segments import get_frequent_trace_segments
from pl4pm.stats.process_cube import get_process_cube
from pl4pm.stats.bottlenecks import detect_bottlenecks

__all__ = [
    "get_start_activities", "get_end_activities",
    "get_rework_cases_per_activity", "get_activity_position_summary",
    "get_event_attributes", "get_trace_attributes",
    "get_event_attribute_values", "get_trace_attribute_values",
    "get_variants", "get_variants_as_tuples",
    "split_by_process_variant", "get_variants_paths_duration",
    "get_stochastic_language",
    "get_all_case_durations", "get_case_duration",
    "get_case_arrival_average", "get_cycle_time", "get_service_time",
    "get_activity_pair_average_durations",
    "get_minimum_self_distances", "get_minimum_self_distance_witnesses",
    "get_case_overlap",
    "get_frequent_trace_segments",
    "get_process_cube",
    "detect_bottlenecks",
]
