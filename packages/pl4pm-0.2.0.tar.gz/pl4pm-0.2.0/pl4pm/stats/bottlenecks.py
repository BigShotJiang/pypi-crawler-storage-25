"""pl4pm.stats.bottlenecks — Bottleneck detection."""

from __future__ import annotations

from typing import Union

import polars as pl

from pl4pm.constants import ACTIVITY_KEY


def detect_bottlenecks(
    log: pl.LazyFrame,
    activity_col: str = ACTIVITY_KEY,
    duration_col: str = "@@duration",
) -> pl.LazyFrame:
    """Detect process bottlenecks by activity.

    Groups events by *activity_col* and computes frequency, mean/median/total
    duration, and derived impact scores.  The result is sorted descending by
    ``impacto_total`` — the primary bottleneck metric.

    Args:
        log: Event log (``pl.DataFrame`` or ``pl.LazyFrame``).
        activity_col: Column containing the activity/task name.
        duration_col: Column containing the event duration (numeric, seconds).

    Returns:
        A ``pl.DataFrame`` (or ``pl.LazyFrame`` when the input is lazy)
        with the following columns:

        * ``actividad`` – activity name
        * ``frecuencia`` – occurrence count
        * ``tiempo_promedio`` – mean duration
        * ``tiempo_mediano`` – median duration
        * ``tiempo_total`` – sum of durations
        * ``impacto_promedio`` – frequency × mean
        * ``impacto_mediano`` – frequency × median
        * ``impacto_total`` – frequency × total (main bottleneck metric)
    """
    is_lazy = isinstance(log, pl.LazyFrame)
    lf = log if is_lazy else log.lazy()

    result = (
        lf.group_by(activity_col)
        .agg([
            pl.len().alias("frecuencia"),
            pl.col(duration_col).mean().alias("tiempo_promedio"),
            pl.col(duration_col).median().alias("tiempo_mediano"),
            pl.col(duration_col).sum().alias("tiempo_total"),
        ])
        .with_columns([
            (pl.col("frecuencia").cast(pl.Float64) * pl.col("tiempo_promedio"))
            .alias("impacto_promedio"),
            (pl.col("frecuencia").cast(pl.Float64) * pl.col("tiempo_mediano"))
            .alias("impacto_mediano"),
            (pl.col("frecuencia").cast(pl.Float64) * pl.col("tiempo_total"))
            .alias("impacto_total"),
        ])
        .rename({activity_col: "actividad"})
        .sort("impacto_total", descending=True)
    )

    return result if is_lazy else result.collect()
