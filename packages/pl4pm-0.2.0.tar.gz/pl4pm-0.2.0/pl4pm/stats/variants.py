"""pl4pm.stats.variants — Variant extraction and stochastic language."""

from __future__ import annotations

from typing import Dict, Iterator, List, Tuple, Union

import polars as pl

from pl4pm.constants import (
    CASE_ID_KEY, ACTIVITY_KEY, TIMESTAMP_KEY,
    VARIANT_COLUMN, VARIANT_COUNT, INDEX_IN_TRACE,
    CUMULATIVE_OCC_PATH,
)


def _build_variant_key_df(
    df: pl.DataFrame,
    activity_key: str,
    timestamp_key: str,
    case_id_key: str,
) -> pl.DataFrame:
    """Internal: sort + group_by to build per-case variant key strings.

    Returns a DataFrame with columns: [case_id_key, "_vkey"].
    """
    sorted_df = df.sort([case_id_key, timestamp_key])
    return (
        sorted_df
        .group_by(case_id_key)
        .agg(pl.col(activity_key).alias("_var"))
        .with_columns(pl.col("_var").list.join("\x00").alias("_vkey"))
    )


def get_variants(
    log: pl.LazyFrame,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
) -> Dict[Tuple[str, ...], int]:
    """Return variants (activity sequences) and their frequencies."""
    df = log.collect() if isinstance(log, pl.LazyFrame) else log
    case_variants = _build_variant_key_df(df, activity_key, timestamp_key, case_id_key)
    # Use value_counts on the string key for fast native hashing
    vc = case_variants["_vkey"].value_counts()
    keys = vc["_vkey"].to_list()
    counts = vc["count"].to_list()
    # Convert NUL-separated strings back to tuples
    return {tuple(k.split("\x00")): c for k, c in zip(keys, counts)}


def get_variants_as_tuples(
    log: pl.LazyFrame,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
) -> Dict[Tuple[str, ...], int]:
    """Alias for get_variants with tuple keys."""
    return get_variants(log, activity_key, timestamp_key, case_id_key)


def split_by_process_variant(
    log: pl.LazyFrame,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
    variant_column: str = VARIANT_COLUMN,
    index_in_trace_column: str = INDEX_IN_TRACE,
) -> Iterator[Tuple[Tuple[str, ...], pl.DataFrame]]:
    """Yield (variant_tuple, sub_dataframe) for each process variant."""
    df = log.collect() if isinstance(log, pl.LazyFrame) else log
    df = df.sort([case_id_key, timestamp_key])

    # Build variant key per case
    case_vkeys = _build_variant_key_df(df, activity_key, timestamp_key, case_id_key)

    # Semi-join: attach variant key to each row, then partition_by
    df_tagged = df.join(
        case_vkeys.select([case_id_key, "_vkey"]),
        on=case_id_key,
        how="left",
    )

    # partition_by is faster than manual group_by iteration
    for sub_df in df_tagged.partition_by("_vkey", maintain_order=True):
        vkey = sub_df["_vkey"][0]
        variant_tuple = tuple(vkey.split("\x00"))
        yield variant_tuple, sub_df.drop("_vkey")


def get_variants_paths_duration(
    log: pl.LazyFrame,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
    times_agg: str = "mean",
) -> pl.DataFrame:
    """Return a DataFrame with variant paths and aggregated durations."""
    df = log.collect() if isinstance(log, pl.LazyFrame) else log
    df = df.sort([case_id_key, timestamp_key])

    # Build edges: (source_activity, target_activity, duration) per consecutive pair
    # Use eager shift within each case via group_by+agg
    edges = (
        df.group_by(case_id_key)
        .agg([
            pl.col(activity_key).alias("acts"),
            pl.col(timestamp_key).alias("times"),
        ])
    )

    # Explode the pairs: for each case, compute (act[i], act[i+1], time[i+1]-time[i])
    edges = edges.with_columns([
        pl.col("acts").list.slice(0, pl.col("acts").list.len() - 1).alias("source"),
        pl.col("acts").list.slice(1).alias("target"),
        pl.col("times").list.slice(0, pl.col("times").list.len() - 1).alias("t_from"),
        pl.col("times").list.slice(1).alias("t_to"),
    ]).select(["source", "target", "t_from", "t_to"])

    exploded = edges.explode(["source", "target", "t_from", "t_to"])
    exploded = exploded.with_columns(
        (pl.col("t_to") - pl.col("t_from")).dt.total_seconds().alias("duration_seconds")
    )

    agg_expr = getattr(pl.col("duration_seconds"), times_agg)()
    result = (
        exploded
        .group_by(["source", "target"])
        .agg([
            agg_expr.alias("agg_duration"),
            pl.len().alias("count"),
        ])
        .sort(["source", "target"])
        .rename({"source": activity_key, "target": "target_activity"})
    )
    return result


def get_stochastic_language(
    log: pl.LazyFrame,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
) -> Dict[Tuple[str, ...], float]:
    """Return the stochastic language (variant probabilities)."""
    variants = get_variants(log, activity_key, timestamp_key, case_id_key)
    total = sum(variants.values())
    if total == 0:
        return {}
    return {k: v / total for k, v in variants.items()}
