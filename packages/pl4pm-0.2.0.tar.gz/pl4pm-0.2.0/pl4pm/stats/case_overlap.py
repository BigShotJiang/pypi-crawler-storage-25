"""pl4pm.stats.case_overlap — Count concurrently open cases."""

from __future__ import annotations

from typing import List

import polars as pl

from pl4pm.constants import CASE_ID_KEY, ACTIVITY_KEY, TIMESTAMP_KEY


def get_case_overlap(
    log: pl.LazyFrame,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
) -> List[int]:
    """Return list of concurrent case counts (one per case, ordered by start).

    For each case, counts how many OTHER cases overlap with it in time.
    Matches pm4py semantics: case j overlaps case i if j starts before i ends
    AND j ends after i starts (and j != i is NOT excluded — pm4py counts all
    simultaneously active cases including the case itself, i.e. returns count-1
    of all overlapping intervals).
    """
    lf = log if isinstance(log, pl.LazyFrame) else log.lazy()

    case_intervals = (
        lf.group_by(case_id_key)
        .agg([
            pl.col(timestamp_key).min().alias("case_start"),
            pl.col(timestamp_key).max().alias("case_end"),
        ])
        .sort("case_start")
        .collect()
    )

    starts = case_intervals["case_start"].to_list()
    ends = case_intervals["case_end"].to_list()
    n = len(starts)
    overlaps: List[int] = []

    for i in range(n):
        count = 0
        for j in range(n):
            # j overlaps i if j.start <= i.end and j.end >= i.start
            if starts[j] <= ends[i] and ends[j] >= starts[i]:
                count += 1
        # pm4py counts ALL simultaneously active cases (including self)
        overlaps.append(count)

    return overlaps
