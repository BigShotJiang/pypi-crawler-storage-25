"""pl4pm.stats.attributes — Event/trace attribute analysis."""

from __future__ import annotations

from typing import Dict, List, Union

import polars as pl

from pl4pm.constants import CASE_ID_KEY


def get_event_attributes(
    log: pl.LazyFrame,
) -> List[str]:
    """Return the list of event-level attribute names (columns)."""
    if isinstance(log, pl.LazyFrame):
        return log.collect_schema().names()
    return log.columns


def get_trace_attributes(
    log: pl.LazyFrame,
) -> List[str]:
    """Return trace-level attribute names (columns starting with 'case:')."""
    cols = log.collect_schema().names() if isinstance(log, pl.LazyFrame) else log.columns
    return [c for c in cols if c.startswith("case:")]


def get_event_attribute_values(
    log: pl.LazyFrame,
    attribute: str,
    count_once_per_case: bool = False,
    case_id_key: str = CASE_ID_KEY,
) -> Dict[str, int]:
    """Return value counts for a given event attribute."""
    df = log.collect() if isinstance(log, pl.LazyFrame) else log

    if count_once_per_case:
        df = df.unique(subset=[case_id_key, attribute])

    # Use native value_counts() — much faster than group_by+agg for simple counting
    vc = df[attribute].value_counts()
    return dict(zip(
        [str(v) for v in vc[attribute].to_list()],
        vc["count"].to_list()
    ))


def get_trace_attribute_values(
    log: pl.LazyFrame,
    attribute: str,
    case_id_key: str = CASE_ID_KEY,
) -> Dict[str, int]:
    """Return value counts for a trace-level attribute (one per case)."""
    df = log.collect() if isinstance(log, pl.LazyFrame) else log
    # Deduplicate to one row per case, then count values
    case_vals = df.group_by(case_id_key).agg(pl.col(attribute).first().alias("_val"))
    vc = case_vals["_val"].value_counts()
    return dict(zip(
        [str(v) for v in vc["_val"].to_list()],
        vc["count"].to_list()
    ))
