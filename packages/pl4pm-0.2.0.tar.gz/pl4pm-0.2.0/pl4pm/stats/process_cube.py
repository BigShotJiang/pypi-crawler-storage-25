"""pl4pm.stats.process_cube — 2D process cube (pivot/aggregation)."""

from __future__ import annotations

from typing import Any, Dict, Optional, Set, Tuple

import polars as pl

from pl4pm.constants import CASE_ID_KEY


def get_process_cube(
    feature_table: pl.DataFrame,
    x_col: str,
    y_col: str,
    agg_col: str,
    parameters: Optional[Dict[str, Any]] = None,
) -> Tuple[pl.DataFrame, Dict[Tuple[Any, Any], set]]:
    """Build a 2D process cube from a feature table.

    Args:
        feature_table: DataFrame with one row per case.
        x_col: X dimension column or prefix.
        y_col: Y dimension column or prefix.
        agg_col: Column to aggregate.
        parameters: Optional settings (max_divisions_x, max_divisions_y, aggregation_function).

    Returns:
        (pivot_df, cell_case_dict) where cell_case_dict maps (x_bin, y_bin) -> set of case IDs.
    """
    params = parameters or {}
    max_div_x = params.get("max_divisions_x", 10)
    max_div_y = params.get("max_divisions_y", 10)
    agg_func = params.get("aggregation_function", "mean")

    df = feature_table.clone()
    case_col = CASE_ID_KEY if CASE_ID_KEY in df.columns else df.columns[0]

    # Determine X bins
    x_bin_col = _create_bins(df, x_col, max_div_x, "x_bin")
    df = df.with_columns(x_bin_col)

    # Determine Y bins
    y_bin_col = _create_bins(df, y_col, max_div_y, "y_bin")
    df = df.with_columns(y_bin_col)

    # Build cell_case_dict
    cell_cases: Dict[Tuple[Any, Any], set] = {}
    for row in df.select([case_col, "x_bin", "y_bin"]).iter_rows(named=True):
        key = (row["x_bin"], row["y_bin"])
        cell_cases.setdefault(key, set()).add(row[case_col])

    # Pivot
    agg_expr = getattr(pl.col(agg_col), agg_func)()
    pivot_df = (
        df.group_by(["x_bin", "y_bin"])
        .agg(agg_expr.alias("value"))
        .pivot(on="y_bin", index="x_bin", values="value")
        .sort("x_bin")
    )

    return pivot_df, cell_cases


def _create_bins(
    df: pl.DataFrame,
    col: str,
    max_divisions: int,
    alias: str,
) -> pl.Expr:
    """Create bin labels for a column (numeric → equal-width bins, prefix → indicator grouping)."""
    if col in df.columns:
        dtype = df[col].dtype
        if dtype in (pl.Float32, pl.Float64, pl.Int8, pl.Int16, pl.Int32, pl.Int64,
                     pl.UInt8, pl.UInt16, pl.UInt32, pl.UInt64):
            # Numeric: cut into bins
            min_val = df[col].min()
            max_val = df[col].max()
            if min_val is not None and max_val is not None and min_val != max_val:
                step = (max_val - min_val) / max_divisions
                return (
                    ((pl.col(col) - min_val) / step).floor().cast(pl.Int32)
                    .clip(0, max_divisions - 1)
                    .cast(pl.Utf8)
                    .alias(alias)
                )
            return pl.lit("0").alias(alias)
        else:
            return pl.col(col).cast(pl.Utf8).alias(alias)
    else:
        # Prefix mode: find columns with this prefix
        prefix_cols = [c for c in df.columns if c.startswith(col)]
        if prefix_cols:
            # Use the first non-zero indicator column as the bin
            exprs = []
            for pc in prefix_cols:
                exprs.append(
                    pl.when(pl.col(pc) > 0)
                    .then(pl.lit(pc.replace(col + "_", "").replace(col, "")))
                )
            # fallback
            return (
                pl.coalesce(exprs)
                .fill_null("other")
                .alias(alias)
            )
        return pl.lit("N/A").alias(alias)
