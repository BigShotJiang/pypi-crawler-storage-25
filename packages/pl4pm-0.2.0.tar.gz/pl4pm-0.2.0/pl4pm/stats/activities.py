"""pl4pm.stats.activities — Start/end activity stats, rework, position summary."""

from __future__ import annotations

from typing import Dict, Union

import polars as pl

from pl4pm.constants import CASE_ID_KEY, ACTIVITY_KEY, TIMESTAMP_KEY


def get_start_activities(
    log: pl.LazyFrame,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
) -> Dict[str, int]:
    """Return start activities and their frequencies."""
    df = log.collect() if isinstance(log, pl.LazyFrame) else log
    # Sort by case+timestamp, then unique(keep="first") gives first event per case — O(n)
    sorted_df = df.sort([case_id_key, timestamp_key])
    first_per_case = sorted_df.unique(subset=[case_id_key], keep="first")
    vc = first_per_case[activity_key].value_counts()
    return dict(zip(vc[activity_key].to_list(), vc["count"].to_list()))


def get_end_activities(
    log: pl.LazyFrame,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
) -> Dict[str, int]:
    """Return end activities and their frequencies."""
    df = log.collect() if isinstance(log, pl.LazyFrame) else log
    # Sort by case+timestamp, then unique(keep="last") gives last event per case — O(n)
    sorted_df = df.sort([case_id_key, timestamp_key])
    last_per_case = sorted_df.unique(subset=[case_id_key], keep="last")
    vc = last_per_case[activity_key].value_counts()
    return dict(zip(vc[activity_key].to_list(), vc["count"].to_list()))


def get_rework_cases_per_activity(
    log: pl.LazyFrame,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
) -> Dict[str, int]:
    """Return activities with rework and number of cases where rework occurred."""
    df = log.collect() if isinstance(log, pl.LazyFrame) else log
    # group by (case, activity), keep only those with count > 1,
    # then value_counts on activity column — faster than double group_by
    pairs = df.group_by([case_id_key, activity_key]).len()
    rework = pairs.filter(pl.col("len") > 1)
    vc = rework[activity_key].value_counts()
    return dict(zip(
        vc[activity_key].to_list(),
        vc["count"].to_list()
    ))


def get_activity_position_summary(
    log: pl.LazyFrame,
    activity: str,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
) -> Dict[int, int]:
    """Return positions of a specific activity and their counts."""
    df = log.collect() if isinstance(log, pl.LazyFrame) else log
    df = df.sort([case_id_key, timestamp_key])
    result = (
        df.with_columns(
            pl.col(activity_key)
            .cum_count()
            .over(case_id_key)
            .alias("pos_in_trace")
        )
        .filter(pl.col(activity_key) == activity)
    )
    vc = result["pos_in_trace"].value_counts().sort("pos_in_trace")
    return dict(zip(
        vc["pos_in_trace"].to_list(),
        vc["count"].to_list()
    ))
