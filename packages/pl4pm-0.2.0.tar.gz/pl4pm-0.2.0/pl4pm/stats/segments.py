"""pl4pm.stats.segments — Frequent trace segments extraction."""

from __future__ import annotations

from collections import Counter
from typing import Tuple

import polars as pl

from pl4pm.constants import CASE_ID_KEY, ACTIVITY_KEY, TIMESTAMP_KEY


def get_frequent_trace_segments(
    log: pl.LazyFrame,
    min_occ: int,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
) -> Counter:
    """Return frequent trace segments (sub-sequences) above min_occ.

    Each segment key is a tuple of activities prefixed/suffixed with "...".
    """
    df = log.collect() if isinstance(log, pl.LazyFrame) else log
    df = df.sort([case_id_key, timestamp_key])

    segment_counter: Counter = Counter()

    for case_id, group in df.group_by(case_id_key, maintain_order=True):
        activities = group[activity_key].to_list()
        n = len(activities)
        # Generate all contiguous sub-sequences of length >= 1
        for length in range(1, n + 1):
            for start in range(n - length + 1):
                segment = tuple(["..."] + activities[start:start + length] + ["..."])
                segment_counter[segment] += 1

    # Filter by min_occ
    return Counter({k: v for k, v in segment_counter.items() if v >= min_occ})
