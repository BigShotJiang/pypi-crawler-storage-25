"""pl4pm.ocel_module — Object-centric event log analysis functions."""

from __future__ import annotations

import random
import sys
from collections import defaultdict
from typing import Any, Collection, Dict, List, Optional, Set, Tuple

import polars as pl

from pl4pm.objects.ocel import OCEL
from pl4pm.constants import CASE_ID_KEY, ACTIVITY_KEY, TIMESTAMP_KEY


# ══════════════════════════════════════════════════════════════════════
# Basic getters
# ══════════════════════════════════════════════════════════════════════

def ocel_get_object_types(ocel: OCEL) -> List[str]:
    """Get the list of object types."""
    if hasattr(ocel, "object_types") and ocel.object_types:
        return sorted(ocel.object_types)
    if ocel.objects is not None:
        obj_df = ocel.objects.collect() if isinstance(ocel.objects, pl.LazyFrame) else ocel.objects
        type_col = _find_col(obj_df, "type")
        if type_col:
            return sorted(obj_df[type_col].unique().to_list())
    return []


def ocel_get_attribute_names(ocel: OCEL) -> List[str]:
    """Get attribute names at event and object levels."""
    attrs: Set[str] = set()
    if ocel.events is not None:
        ev_df = ocel.events.collect() if isinstance(ocel.events, pl.LazyFrame) else ocel.events
        attrs.update(c for c in ev_df.columns if not c.startswith("ocel:"))
    if ocel.objects is not None:
        obj_df = ocel.objects.collect() if isinstance(ocel.objects, pl.LazyFrame) else ocel.objects
        attrs.update(c for c in obj_df.columns if not c.startswith("ocel:"))
    return sorted(attrs)


# ══════════════════════════════════════════════════════════════════════
# Flattening
# ══════════════════════════════════════════════════════════════════════

def ocel_flattening(ocel: OCEL, object_type: str) -> pl.DataFrame:
    """Flatten OCEL to traditional log by object type as case."""
    ev_df = ocel.events.collect() if isinstance(ocel.events, pl.LazyFrame) else ocel.events
    rel_df = ocel.relations.collect() if isinstance(ocel.relations, pl.LazyFrame) else ocel.relations

    if ev_df is None or rel_df is None:
        return pl.DataFrame()

    type_col = _find_col(rel_df, "type")
    oid_col = _find_col(rel_df, "oid", "object")
    eid_col = _find_col(rel_df, "eid", "event")
    act_col = _find_col(ev_df, "activity", "name")
    ts_col = _find_col(ev_df, "timestamp")
    ev_id_col = _find_col(ev_df, "eid", "event")

    if not all([type_col, oid_col, eid_col, act_col, ts_col, ev_id_col]):
        return pl.DataFrame()

    # Filter relations by object type
    filtered_rels = rel_df.filter(pl.col(type_col) == object_type)

    # Join with events
    result = (
        filtered_rels.lazy()
        .join(ev_df.lazy(), left_on=eid_col, right_on=ev_id_col, how="inner")
        .select([
            pl.col(oid_col).alias(CASE_ID_KEY),
            pl.col(act_col).alias(ACTIVITY_KEY),
            pl.col(ts_col).alias(TIMESTAMP_KEY),
        ])
        .sort([CASE_ID_KEY, TIMESTAMP_KEY])
        .collect()
    )
    return result


# ══════════════════════════════════════════════════════════════════════
# Object type activities
# ══════════════════════════════════════════════════════════════════════

def ocel_object_type_activities(ocel: OCEL) -> Dict[str, Collection[str]]:
    """Activities performed per object type."""
    flat_results: Dict[str, Set[str]] = {}
    for ot in ocel_get_object_types(ocel):
        flat = ocel_flattening(ocel, ot)
        if len(flat) > 0 and ACTIVITY_KEY in flat.columns:
            flat_results[ot] = set(flat[ACTIVITY_KEY].unique().to_list())
        else:
            flat_results[ot] = set()
    return flat_results


# ══════════════════════════════════════════════════════════════════════
# Objects per OT count
# ══════════════════════════════════════════════════════════════════════

def ocel_objects_ot_count(ocel: OCEL) -> Dict[str, Dict[str, int]]:
    """Count of related objects per type for each event."""
    rel_df = ocel.relations
    if rel_df is None:
        return {}
    rel_df = rel_df.collect() if isinstance(rel_df, pl.LazyFrame) else rel_df

    eid_col = _find_col(rel_df, "eid", "event")
    type_col = _find_col(rel_df, "type")
    if not eid_col or not type_col:
        return {}

    result: Dict[str, Dict[str, int]] = {}
    grouped = rel_df.group_by([eid_col, type_col]).agg(pl.len().alias("cnt"))
    for row in grouped.iter_rows(named=True):
        eid = str(row[eid_col])
        ot = str(row[type_col])
        result.setdefault(eid, {})[ot] = row["cnt"]
    return result


# ══════════════════════════════════════════════════════════════════════
# Temporal summary
# ══════════════════════════════════════════════════════════════════════

def ocel_temporal_summary(ocel: OCEL) -> pl.DataFrame:
    """Temporal summary: aggregate events at same timestamp."""
    ev_df = ocel.events.collect() if isinstance(ocel.events, pl.LazyFrame) else ocel.events
    if ev_df is None:
        return pl.DataFrame()

    ts_col = _find_col(ev_df, "timestamp")
    act_col = _find_col(ev_df, "activity", "name")
    if not ts_col or not act_col:
        return ev_df

    return (
        ev_df.group_by(ts_col)
        .agg([
            pl.col(act_col).alias("activities"),
            pl.len().alias("n_events"),
        ])
        .sort(ts_col)
    )


# ══════════════════════════════════════════════════════════════════════
# Objects summary
# ══════════════════════════════════════════════════════════════════════

def ocel_objects_summary(ocel: OCEL) -> pl.DataFrame:
    """Objects summary with lifecycle info."""
    obj_df = ocel.objects
    if obj_df is None:
        return pl.DataFrame()
    return obj_df.collect() if isinstance(obj_df, pl.LazyFrame) else obj_df


def ocel_objects_interactions_summary(ocel: OCEL) -> pl.DataFrame:
    """Objects interactions summary."""
    rel_df = ocel.relations
    if rel_df is None:
        return pl.DataFrame()
    rel_df = rel_df.collect() if isinstance(rel_df, pl.LazyFrame) else rel_df

    eid_col = _find_col(rel_df, "eid", "event")
    oid_col = _find_col(rel_df, "oid", "object")
    if not eid_col or not oid_col:
        return rel_df

    # Self-join to get pairs of objects in the same event
    left = rel_df.rename({oid_col: "object_1"})
    right = rel_df.rename({oid_col: "object_2"})

    interactions = (
        left.lazy()
        .join(right.lazy(), on=eid_col, how="inner")
        .filter(pl.col("object_1") != pl.col("object_2"))
        .collect()
    )
    return interactions


# ══════════════════════════════════════════════════════════════════════
# OC-DFG discovery
# ══════════════════════════════════════════════════════════════════════

def discover_ocdfg(
    ocel: OCEL,
    business_hours: bool = False,
    business_hour_slots: Optional[List[Tuple[int, int]]] = None,
) -> Dict[str, Any]:
    """Discover Object-Centric DFG."""
    result: Dict[str, Any] = {
        "activities": set(),
        "object_types": set(),
        "edges": {},
        "activities_indep": {},
        "activities_ot": {},
        "start_activities": {},
        "end_activities": {},
    }

    ot_list = ocel_get_object_types(ocel)
    result["object_types"] = set(ot_list)

    for ot in ot_list:
        flat = ocel_flattening(ocel, ot)
        if len(flat) == 0:
            continue

        from pl4pm.discovery.dfg import discover_dfg
        dfg, sa, ea = discover_dfg(flat)

        result["edges"][ot] = set(dfg.keys())
        result["start_activities"][ot] = sa
        result["end_activities"][ot] = ea

        for (a, b) in dfg:
            result["activities"].add(a)
            result["activities"].add(b)
        result["activities"].update(sa.keys())
        result["activities"].update(ea.keys())

        result["activities_ot"][ot] = set()
        for (a, b) in dfg:
            result["activities_ot"][ot].add(a)
            result["activities_ot"][ot].add(b)

    # Activities independent of OT
    for act in result["activities"]:
        result["activities_indep"][act] = sum(
            1 for ot_edges in result["edges"].values()
            for (a, b) in ot_edges if a == act or b == act
        )

    return result


# ══════════════════════════════════════════════════════════════════════
# OC Petri net discovery
# ══════════════════════════════════════════════════════════════════════

def discover_oc_petri_net(
    ocel: OCEL,
    inductive_miner_variant: str = "im",
    diagnostics_with_tbr: bool = False,
) -> Dict[str, Any]:
    """Discover object-centric Petri net."""
    from pl4pm.discovery.inductive_miner import discover_petri_net_inductive

    result: Dict[str, Any] = {"petri_nets": {}, "object_types": []}
    ot_list = ocel_get_object_types(ocel)
    result["object_types"] = ot_list

    for ot in ot_list:
        flat = ocel_flattening(ocel, ot)
        if len(flat) == 0:
            continue
        net, im, fm = discover_petri_net_inductive(flat)
        result["petri_nets"][ot] = {"net": net, "im": im, "fm": fm}

    return result


# ══════════════════════════════════════════════════════════════════════
# Object graphs
# ══════════════════════════════════════════════════════════════════════

def discover_objects_graph(
    ocel: OCEL,
    graph_type: str = "object_interaction",
) -> Set[Tuple[str, str]]:
    """Discover object graph of specified type."""
    rel_df = ocel.relations
    if rel_df is None:
        return set()
    rel_df = rel_df.collect() if isinstance(rel_df, pl.LazyFrame) else rel_df

    eid_col = _find_col(rel_df, "eid", "event")
    oid_col = _find_col(rel_df, "oid", "object")
    if not eid_col or not oid_col:
        return set()

    if graph_type == "object_interaction":
        # Objects that appear in the same event
        pairs: Set[Tuple[str, str]] = set()
        for eid, group in rel_df.group_by(eid_col, maintain_order=True):
            objs = sorted(group[oid_col].unique().to_list())
            for i in range(len(objs)):
                for j in range(i + 1, len(objs)):
                    pairs.add((str(objs[i]), str(objs[j])))
        return pairs

    elif graph_type in ("object_descendants", "object_inheritance",
                        "object_cobirth", "object_codeath"):
        ev_df = ocel.events
        if ev_df is None:
            return set()
        ev_df = ev_df.collect() if isinstance(ev_df, pl.LazyFrame) else ev_df
        ts_col = _find_col(ev_df, "timestamp")
        ev_id_col = _find_col(ev_df, "eid", "event")
        if not ts_col or not ev_id_col:
            return set()

        # Join relations with event timestamps
        enriched = (
            rel_df.lazy()
            .join(ev_df.lazy().select([ev_id_col, ts_col]), left_on=eid_col, right_on=ev_id_col, how="left")
            .collect()
        )

        # Per object: first and last event timestamp
        obj_lifecycle = (
            enriched.group_by(oid_col)
            .agg([
                pl.col(ts_col).min().alias("_first_ts"),
                pl.col(ts_col).max().alias("_last_ts"),
            ])
        )

        pairs = set()
        objs = obj_lifecycle.to_dicts()

        for i in range(len(objs)):
            for j in range(i + 1, len(objs)):
                o1, o2 = objs[i], objs[j]
                if graph_type == "object_cobirth":
                    if o1["_first_ts"] == o2["_first_ts"]:
                        pairs.add((str(o1[oid_col]), str(o2[oid_col])))
                elif graph_type == "object_codeath":
                    if o1["_last_ts"] == o2["_last_ts"]:
                        pairs.add((str(o1[oid_col]), str(o2[oid_col])))
                elif graph_type == "object_descendants":
                    if o1["_first_ts"] < o2["_first_ts"]:
                        pairs.add((str(o1[oid_col]), str(o2[oid_col])))
                    elif o2["_first_ts"] < o1["_first_ts"]:
                        pairs.add((str(o2[oid_col]), str(o1[oid_col])))
                elif graph_type == "object_inheritance":
                    if o1["_last_ts"] == o2["_first_ts"]:
                        pairs.add((str(o1[oid_col]), str(o2[oid_col])))
                    elif o2["_last_ts"] == o1["_first_ts"]:
                        pairs.add((str(o2[oid_col]), str(o1[oid_col])))
        return pairs

    return set()


# ══════════════════════════════════════════════════════════════════════
# OCEL enrichment
# ══════════════════════════════════════════════════════════════════════

def ocel_o2o_enrichment(
    ocel: OCEL,
    included_graphs: Optional[Collection[str]] = None,
) -> OCEL:
    """Enrich OCEL O2O relations with graph computations."""
    graphs = included_graphs or [
        "object_interaction_graph", "object_descendants_graph",
    ]
    graph_type_map = {
        "object_interaction_graph": "object_interaction",
        "object_descendants_graph": "object_descendants",
        "object_inheritance_graph": "object_inheritance",
        "object_cobirth_graph": "object_cobirth",
        "object_codeath_graph": "object_codeath",
    }
    all_o2o: List[Dict[str, str]] = []
    for g_name in graphs:
        g_type = graph_type_map.get(g_name, g_name)
        pairs = discover_objects_graph(ocel, g_type)
        for (o1, o2) in pairs:
            all_o2o.append({"ocel:oid_1": o1, "ocel:oid_2": o2, "ocel:qualifier": g_type})

    if all_o2o:
        ocel.o2o = pl.DataFrame(all_o2o)
    return ocel


def ocel_e2o_lifecycle_enrichment(ocel: OCEL) -> OCEL:
    """Enrich E2O relations with lifecycle info."""
    # Placeholder: adds qualifier column if missing
    if ocel.relations is not None:
        rel_df = ocel.relations.collect() if isinstance(ocel.relations, pl.LazyFrame) else ocel.relations
        if "ocel:qualifier" not in rel_df.columns:
            rel_df = rel_df.with_columns(pl.lit("related").alias("ocel:qualifier"))
            ocel.relations = rel_df
    return ocel


# ══════════════════════════════════════════════════════════════════════
# Sampling
# ══════════════════════════════════════════════════════════════════════

def sample_ocel_objects(ocel: OCEL, num_objects: int) -> OCEL:
    """Sample OCEL by random objects."""
    obj_df = ocel.objects.collect() if isinstance(ocel.objects, pl.LazyFrame) else ocel.objects
    if obj_df is None:
        return ocel

    oid_col = _find_col(obj_df, "oid", "object")
    if not oid_col:
        return ocel

    all_oids = obj_df[oid_col].unique().to_list()
    sampled = random.sample(all_oids, min(num_objects, len(all_oids)))

    new_obj = obj_df.filter(pl.col(oid_col).is_in(sampled))

    new_ocel = OCEL(events=ocel.events, objects=new_obj, relations=ocel.relations)

    if ocel.relations is not None:
        rel_df = ocel.relations.collect() if isinstance(ocel.relations, pl.LazyFrame) else ocel.relations
        rel_oid_col = _find_col(rel_df, "oid", "object")
        if rel_oid_col:
            new_ocel.relations = rel_df.filter(pl.col(rel_oid_col).is_in(sampled))

    return new_ocel


def sample_ocel_connected_components(
    ocel: OCEL,
    connected_components: int = 1,
    max_num_events_per_cc: int = sys.maxsize,
    max_num_objects_per_cc: int = sys.maxsize,
    max_num_e2o_relations_per_cc: int = sys.maxsize,
) -> OCEL:
    """Sample OCEL by connected components."""
    # Build object interaction graph
    interactions = discover_objects_graph(ocel, "object_interaction")

    # Find connected components via BFS
    adj: Dict[str, Set[str]] = defaultdict(set)
    for (o1, o2) in interactions:
        adj[o1].add(o2)
        adj[o2].add(o1)

    obj_df = ocel.objects.collect() if isinstance(ocel.objects, pl.LazyFrame) else ocel.objects
    oid_col = _find_col(obj_df, "oid", "object") if obj_df is not None else None
    all_objs = set(obj_df[oid_col].unique().to_list()) if oid_col else set()
    for o in adj:
        all_objs.add(o)

    visited: Set[str] = set()
    components: List[Set[str]] = []
    for o in all_objs:
        if o in visited:
            continue
        comp: Set[str] = set()
        queue = [o]
        while queue:
            node = queue.pop()
            if node in visited:
                continue
            visited.add(node)
            comp.add(node)
            for nb in adj.get(node, set()):
                if nb not in visited:
                    queue.append(nb)
        if len(comp) <= max_num_objects_per_cc:
            components.append(comp)

    selected_objects: Set[str] = set()
    for comp in components[:connected_components]:
        selected_objects |= comp

    return sample_ocel_objects(ocel, len(selected_objects))


# ══════════════════════════════════════════════════════════════════════
# Deduplication and sorting
# ══════════════════════════════════════════════════════════════════════

def ocel_drop_duplicates(ocel: OCEL) -> OCEL:
    """Remove duplicate relations."""
    if ocel.relations is not None:
        rel_df = ocel.relations.collect() if isinstance(ocel.relations, pl.LazyFrame) else ocel.relations
        ocel.relations = rel_df.unique()
    return ocel


def ocel_merge_duplicates(ocel: OCEL, have_common_object: Optional[bool] = False) -> OCEL:
    """Merge events with same activity and timestamp."""
    if ocel.events is not None:
        ev_df = ocel.events.collect() if isinstance(ocel.events, pl.LazyFrame) else ocel.events
        act_col = _find_col(ev_df, "activity", "name")
        ts_col = _find_col(ev_df, "timestamp")
        if act_col and ts_col:
            ocel.events = ev_df.unique(subset=[act_col, ts_col])
    return ocel


def ocel_sort_by_additional_column(
    ocel: OCEL,
    additional_column: str,
    primary_column: str = "ocel:timestamp",
) -> OCEL:
    """Sort OCEL events by primary and additional columns."""
    if ocel.events is not None:
        ev_df = ocel.events.collect() if isinstance(ocel.events, pl.LazyFrame) else ocel.events
        sort_cols = []
        if primary_column in ev_df.columns:
            sort_cols.append(primary_column)
        if additional_column in ev_df.columns:
            sort_cols.append(additional_column)
        if sort_cols:
            ocel.events = ev_df.sort(sort_cols)
    return ocel


def ocel_add_index_based_timedelta(ocel: OCEL) -> OCEL:
    """Add small time delta based on index for ordering."""
    if ocel.events is not None:
        ev_df = ocel.events.collect() if isinstance(ocel.events, pl.LazyFrame) else ocel.events
        ts_col = _find_col(ev_df, "timestamp")
        if ts_col:
            from datetime import timedelta
            ev_df = ev_df.with_row_index("_idx")
            ev_df = ev_df.with_columns(
                (pl.col(ts_col) + pl.duration(microseconds=pl.col("_idx"))).alias(ts_col)
            )
            ev_df = ev_df.drop("_idx")
            ocel.events = ev_df
    return ocel


# ══════════════════════════════════════════════════════════════════════
# Clustering
# ══════════════════════════════════════════════════════════════════════

def cluster_equivalent_ocel(
    ocel: OCEL,
    object_type: str,
    max_objs: int = sys.maxsize,
    exclude_object_types_from_renaming: Optional[Set[str]] = None,
) -> Dict[str, Collection[OCEL]]:
    """Cluster equivalent executions by object type."""
    flat = ocel_flattening(ocel, object_type)
    if len(flat) == 0:
        return {}

    # Group by variant (activity sequence)
    variants: Dict[str, List[str]] = defaultdict(list)
    for cid, group in flat.group_by(CASE_ID_KEY, maintain_order=True):
        case_id = str(cid[0]) if isinstance(cid, tuple) else str(cid)
        acts = tuple(group[ACTIVITY_KEY].to_list())
        variants[str(acts)].append(case_id)

    result: Dict[str, Collection[OCEL]] = {}
    for variant_key, case_ids in variants.items():
        if len(case_ids) > max_objs:
            case_ids = case_ids[:max_objs]
        # Create sub-OCEL for each variant group
        sub_log = flat.filter(pl.col(CASE_ID_KEY).is_in(case_ids))
        sub_ocel = OCEL(events=sub_log)
        result[variant_key] = [sub_ocel]

    return result


# ══════════════════════════════════════════════════════════════════════
# Helpers
# ══════════════════════════════════════════════════════════════════════

def _find_col(df: pl.DataFrame, *keywords: str) -> Optional[str]:
    """Find a column containing any of the keywords."""
    for col in df.columns:
        for kw in keywords:
            if kw in col.lower():
                return col
    return None


__all__ = [
    "ocel_get_object_types",
    "ocel_get_attribute_names",
    "ocel_flattening",
    "ocel_object_type_activities",
    "ocel_objects_ot_count",
    "ocel_temporal_summary",
    "ocel_objects_summary",
    "ocel_objects_interactions_summary",
    "discover_ocdfg",
    "discover_oc_petri_net",
    "discover_objects_graph",
    "ocel_o2o_enrichment",
    "ocel_e2o_lifecycle_enrichment",
    "sample_ocel_objects",
    "sample_ocel_connected_components",
    "ocel_drop_duplicates",
    "ocel_merge_duplicates",
    "ocel_sort_by_additional_column",
    "ocel_add_index_based_timedelta",
    "cluster_equivalent_ocel",
]
