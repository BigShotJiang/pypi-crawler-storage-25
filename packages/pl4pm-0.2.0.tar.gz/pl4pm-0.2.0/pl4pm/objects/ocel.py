"""pl4pm.objects.ocel — Object-Centric Event Log."""

from __future__ import annotations

from typing import Optional, Dict, Any, List

import polars as pl


class OCEL:
    """Object-Centric Event Log (OCEL 1.0 / 2.0).

    Stores events, objects, and their relations as Polars DataFrames.
    """

    # Standard column names
    EVENT_ID: str = "ocel:eid"
    EVENT_ACTIVITY: str = "ocel:activity"
    EVENT_TIMESTAMP: str = "ocel:timestamp"
    OBJECT_ID: str = "ocel:oid"
    OBJECT_TYPE: str = "ocel:type"
    QUALIFIER: str = "ocel:qualifier"
    CHANGED_FIELD: str = "ocel:field"

    def __init__(
        self,
        events: Optional[pl.DataFrame] = None,
        objects: Optional[pl.DataFrame] = None,
        relations: Optional[pl.DataFrame] = None,
        o2o: Optional[pl.DataFrame] = None,
        object_changes: Optional[pl.DataFrame] = None,
        globals: Optional[Dict[str, Any]] = None,
        parameters: Optional[Dict[str, Any]] = None,
    ) -> None:
        self.events: pl.DataFrame = events if events is not None else pl.DataFrame(
            schema={self.EVENT_ID: pl.Utf8, self.EVENT_ACTIVITY: pl.Utf8,
                    self.EVENT_TIMESTAMP: pl.Datetime}
        )
        self.objects: pl.DataFrame = objects if objects is not None else pl.DataFrame(
            schema={self.OBJECT_ID: pl.Utf8, self.OBJECT_TYPE: pl.Utf8}
        )
        self.relations: pl.DataFrame = relations if relations is not None else pl.DataFrame(
            schema={self.EVENT_ID: pl.Utf8, self.OBJECT_ID: pl.Utf8,
                    self.QUALIFIER: pl.Utf8}
        )
        self.o2o: pl.DataFrame = o2o if o2o is not None else pl.DataFrame(
            schema={"ocel:oid_src": pl.Utf8, "ocel:oid_tgt": pl.Utf8,
                    self.QUALIFIER: pl.Utf8}
        )
        self.object_changes: pl.DataFrame = (
            object_changes if object_changes is not None else pl.DataFrame(
                schema={self.EVENT_ID: pl.Utf8, self.OBJECT_ID: pl.Utf8,
                        self.CHANGED_FIELD: pl.Utf8}
            )
        )
        self.globals: Dict[str, Any] = globals or {}
        self.parameters: Dict[str, Any] = parameters or {}

    @property
    def event_ids(self) -> List[str]:
        return self.events[self.EVENT_ID].to_list()

    @property
    def object_ids(self) -> List[str]:
        return self.objects[self.OBJECT_ID].to_list()

    @property
    def object_types(self) -> List[str]:
        return self.objects[self.OBJECT_TYPE].unique().sort().to_list()

    @property
    def activities(self) -> List[str]:
        return self.events[self.EVENT_ACTIVITY].unique().sort().to_list()

    @property
    def num_events(self) -> int:
        return self.events.height

    @property
    def num_objects(self) -> int:
        return self.objects.height

    def get_events_of_object(self, object_id: str) -> pl.DataFrame:
        """Return events related to a specific object."""
        eids = (
            self.relations
            .filter(pl.col(self.OBJECT_ID) == object_id)
            .select(self.EVENT_ID)
        )
        return self.events.join(eids, on=self.EVENT_ID, how="inner")

    def get_objects_of_event(self, event_id: str) -> pl.DataFrame:
        """Return objects related to a specific event."""
        oids = (
            self.relations
            .filter(pl.col(self.EVENT_ID) == event_id)
            .select(self.OBJECT_ID)
        )
        return self.objects.join(oids, on=self.OBJECT_ID, how="inner")

    def __repr__(self) -> str:
        return (f"OCEL(events={self.num_events}, objects={self.num_objects}, "
                f"object_types={self.object_types})")
