"""pl4pm.objects.powl — Partially Ordered Workflow Language (POWL) model.

Reference:
    Kourani, H., & van Zelst, S. J. (2023). POWL: partially ordered workflow
    language. International Conference on Business Process Management.
    Springer Nature Switzerland.
"""

from __future__ import annotations

from enum import Enum
from typing import List, Optional, Set, Tuple


class POWLOperator(Enum):
    """Operators available in POWL composite nodes."""
    XOR = "X"
    LOOP = "*"


class POWL:
    """Abstract base for all POWL model nodes."""

    def __repr__(self) -> str:  # pragma: no cover
        return object.__repr__(self)


class Transition(POWL):
    """A visible (labelled) activity in a POWL model."""

    def __init__(self, label: str) -> None:
        self.label: str = label

    def __repr__(self) -> str:
        return self.label

    def __eq__(self, other: object) -> bool:
        return isinstance(other, Transition) and self.label == other.label

    def __hash__(self) -> int:
        return hash(("Transition", self.label))


class SilentTransition(POWL):
    """A silent (tau / skip) transition in a POWL model."""

    def __repr__(self) -> str:
        return "τ"

    def __eq__(self, other: object) -> bool:
        return isinstance(other, SilentTransition)

    def __hash__(self) -> int:
        return hash("SilentTransition")


class OperatorPOWL(POWL):
    """An operator node (XOR choice or LOOP) over a list of child POWL nodes."""

    def __init__(self, operator: POWLOperator, children: List[POWL]) -> None:
        self.operator = operator
        self.children: List[POWL] = children

    def __repr__(self) -> str:
        inner = ", ".join(repr(c) for c in self.children)
        return f"{self.operator.value}({inner})"

    def __eq__(self, other: object) -> bool:
        return (
            isinstance(other, OperatorPOWL)
            and self.operator == other.operator
            and self.children == other.children
        )

    def __hash__(self) -> int:
        return hash((self.operator, tuple(self.children)))


class StrictPartialOrder(POWL):
    """A partial order over a set of POWL nodes.

    ``order`` is a set of (source_node, target_node) pairs encoding the
    strict precedence relation.  Transitivity is assumed but not stored
    explicitly.
    """

    def __init__(
        self,
        nodes: Optional[List[POWL]] = None,
        order: Optional[Set[Tuple[POWL, POWL]]] = None,
    ) -> None:
        self.nodes: List[POWL] = nodes if nodes is not None else []
        self.order: Set[Tuple[POWL, POWL]] = order if order is not None else set()

    # ------------------------------------------------------------------ #
    # Mutation helpers                                                     #
    # ------------------------------------------------------------------ #

    def add_node(self, node: POWL) -> None:
        """Append *node* to the partial order (no edges added)."""
        if node not in self.nodes:
            self.nodes.append(node)

    def add_edge(self, source: POWL, target: POWL) -> None:
        """Add a precedence edge source → target."""
        self.order.add((source, target))

    # ------------------------------------------------------------------ #
    # Query helpers                                                        #
    # ------------------------------------------------------------------ #

    def predecessors(self, node: POWL) -> Set[POWL]:
        return {s for (s, t) in self.order if t is node}

    def successors(self, node: POWL) -> Set[POWL]:
        return {t for (s, t) in self.order if s is node}

    def __repr__(self) -> str:
        edges = ", ".join(f"{repr(s)}→{repr(t)}" for (s, t) in self.order)
        nodes_repr = ", ".join(repr(n) for n in self.nodes)
        return f"PO([{nodes_repr}], {{{edges}}})"

    def __eq__(self, other: object) -> bool:
        return (
            isinstance(other, StrictPartialOrder)
            and self.nodes == other.nodes
            and self.order == other.order
        )

    def __hash__(self) -> int:
        return hash((tuple(self.nodes), frozenset(self.order)))
