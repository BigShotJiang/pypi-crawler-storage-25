"""pl4pm.objects.heuristics_net — Heuristics net model."""

from __future__ import annotations

from typing import Dict, Optional, Set, Tuple


class HeuristicsNet:
    """Heuristics net discovered from a DFG."""

    def __init__(
        self,
        dfg: Dict[Tuple[str, str], int],
        activities: Optional[Set[str]] = None,
        start_activities: Optional[Dict[str, int]] = None,
        end_activities: Optional[Dict[str, int]] = None,
        activities_occurrences: Optional[Dict[str, int]] = None,
    ) -> None:
        self.dfg = dfg
        all_acts: Set[str] = set()
        for (a, b) in dfg:
            all_acts.add(a)
            all_acts.add(b)
        self.activities: Set[str] = activities or all_acts
        self.start_activities: Dict[str, int] = start_activities or {}
        self.end_activities: Dict[str, int] = end_activities or {}
        self.activities_occurrences: Dict[str, int] = activities_occurrences or {}

        # dependency_matrix[a][b] = dependency value
        self.dependency_matrix: Dict[str, Dict[str, float]] = {}
        # input/output sets per activity (AND/XOR splits/joins)
        self.input_sets: Dict[str, list[set[str]]] = {a: [] for a in self.activities}
        self.output_sets: Dict[str, list[set[str]]] = {a: [] for a in self.activities}

    def compute_dependency_matrix(self) -> None:
        """Compute dependency values: dep(a,b) = (|a>b| - |b>a|) / (|a>b| + |b>a| + 1)."""
        for a in self.activities:
            self.dependency_matrix[a] = {}
            for b in self.activities:
                ab = self.dfg.get((a, b), 0)
                ba = self.dfg.get((b, a), 0)
                if a == b:
                    dep = ab / (ab + 1) if ab > 0 else 0.0
                else:
                    dep = (ab - ba) / (ab + ba + 1) if (ab + ba) > 0 else 0.0
                self.dependency_matrix[a][b] = dep

    def __repr__(self) -> str:
        return (f"HeuristicsNet(activities={len(self.activities)}, "
                f"edges={len(self.dfg)})")
