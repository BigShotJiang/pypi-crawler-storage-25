"""pl4pm.objects.trie — Prefix tree (Trie) for process mining."""

from __future__ import annotations

from typing import Dict, List, Optional


class TrieNode:
    """A single node in the prefix tree."""

    def __init__(self, label: str = "", depth: int = 0, parent: Optional[TrieNode] = None) -> None:
        self.label: str = label
        self.depth: int = depth
        self.parent: Optional[TrieNode] = parent
        self.children: Dict[str, TrieNode] = {}
        self.count: int = 0  # how many traces pass through this node
        self.is_end: bool = False  # marks end of at least one trace
        self.final_count: int = 0  # how many traces end here

    def __repr__(self) -> str:
        return f"TrieNode('{self.label}', depth={self.depth}, count={self.count})"


class Trie:
    """Prefix tree storing activity sequences."""

    def __init__(self) -> None:
        self.root: TrieNode = TrieNode(label="ROOT", depth=0)

    def insert(self, trace: List[str]) -> None:
        """Insert a trace (list of activity names) into the trie."""
        node = self.root
        node.count += 1
        for act in trace:
            if act not in node.children:
                child = TrieNode(label=act, depth=node.depth + 1, parent=node)
                node.children[act] = child
            node = node.children[act]
            node.count += 1
        node.is_end = True
        node.final_count += 1

    @property
    def num_nodes(self) -> int:
        """Total number of nodes (excluding root)."""
        count = 0
        queue = [self.root]
        while queue:
            n = queue.pop(0)
            count += len(n.children)
            queue.extend(n.children.values())
        return count

    @property
    def num_traces(self) -> int:
        return self.root.count

    def __repr__(self) -> str:
        return f"Trie(nodes={self.num_nodes}, traces={self.num_traces})"
