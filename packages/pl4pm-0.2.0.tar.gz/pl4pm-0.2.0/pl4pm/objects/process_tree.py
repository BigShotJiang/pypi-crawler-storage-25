"""pl4pm.objects.process_tree — Process tree model."""

from __future__ import annotations

from enum import Enum
from typing import Optional, List


class Operator(Enum):
    """Process tree operators."""
    SEQUENCE = "->"
    XOR = "X"
    PARALLEL = "+"
    LOOP = "*"
    OR = "O"

    def __repr__(self) -> str:
        return self.value

    def __str__(self) -> str:
        return self.value


class ProcessTree:
    """A process tree node.

    Leaf nodes have ``label`` set and ``operator`` is None.
    Internal nodes have ``operator`` set and ``label`` is None.
    Silent (tau) leaves have both ``operator`` and ``label`` as None.
    """

    def __init__(
        self,
        operator: Optional[Operator] = None,
        parent: Optional[ProcessTree] = None,
        children: Optional[List[ProcessTree]] = None,
        label: Optional[str] = None,
    ) -> None:
        self.operator: Optional[Operator] = operator
        self.parent: Optional[ProcessTree] = parent
        self.children: List[ProcessTree] = children if children is not None else []
        self.label: Optional[str] = label
        self.properties: dict = {}

    @property
    def is_leaf(self) -> bool:
        return len(self.children) == 0

    @property
    def is_tau(self) -> bool:
        return self.is_leaf and self.label is None

    def _to_str(self, level: int = 0) -> str:
        if self.is_leaf:
            return self.label if self.label else "τ"
        children_str = ", ".join(c._to_str(level + 1) for c in self.children)
        return f"{self.operator}({children_str})"

    def __repr__(self) -> str:
        return self._to_str()

    def __str__(self) -> str:
        return self._to_str()

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, ProcessTree):
            return False
        if self.operator != other.operator or self.label != other.label:
            return False
        if len(self.children) != len(other.children):
            return False
        return all(a == b for a, b in zip(self.children, other.children))

    def __hash__(self) -> int:
        return hash((self.operator, self.label,
                      tuple(hash(c) for c in self.children)))


def from_any_process_tree(tree: object, parent: Optional[ProcessTree] = None) -> ProcessTree:
    """Coerce a pm4py-like process tree node into a pl4pm ProcessTree."""
    if isinstance(tree, ProcessTree):
        if parent is None:
            return tree
        cloned = ProcessTree(operator=tree.operator, parent=parent, label=tree.label)
        cloned.children = [from_any_process_tree(child, cloned) for child in tree.children]
        return cloned

    operator_raw = getattr(getattr(tree, "operator", None), "value", getattr(tree, "operator", None))
    operator = None
    for candidate in Operator:
        if operator_raw == candidate.value:
            operator = candidate
            break

    node = ProcessTree(
        operator=operator,
        parent=parent,
        label=getattr(tree, "label", None),
    )
    node.children = [from_any_process_tree(child, node) for child in getattr(tree, "children", [])]
    return node


def parse_tree_string(tree_str: str) -> ProcessTree:
    """Parse a process tree from its string representation."""
    tree_str = tree_str.strip()
    if tree_str == "τ" or tree_str == "tau":
        return ProcessTree()

    op_map = {op.value: op for op in Operator}
    for symbol, op in op_map.items():
        if tree_str.startswith(symbol + "(") and tree_str.endswith(")"):
            inner = tree_str[len(symbol) + 1:-1]
            children_strs = _split_top_level(inner)
            children = [parse_tree_string(s) for s in children_strs]
            node = ProcessTree(operator=op, children=children)
            for c in children:
                c.parent = node
            return node

    return ProcessTree(label=tree_str.strip("'\""))


def _split_top_level(s: str) -> list[str]:
    """Split comma-separated tokens respecting parenthesis nesting."""
    parts: list[str] = []
    depth = 0
    current: list[str] = []
    for ch in s:
        if ch == "(":
            depth += 1
            current.append(ch)
        elif ch == ")":
            depth -= 1
            current.append(ch)
        elif ch == "," and depth == 0:
            parts.append("".join(current).strip())
            current = []
        else:
            current.append(ch)
    if current:
        parts.append("".join(current).strip())
    return parts
