"""pl4pm.objects.bpmn — BPMN 2.0 model objects."""

from __future__ import annotations

from enum import Enum
from typing import Optional, Set, Dict, Any
import uuid


class BPMN:
    """A BPMN 2.0 process diagram."""

    # ── Node types ────────────────────────────────────────────────

    class NodeType(Enum):
        TASK = "task"
        START_EVENT = "startEvent"
        END_EVENT = "endEvent"
        EXCLUSIVE_GATEWAY = "exclusiveGateway"
        PARALLEL_GATEWAY = "parallelGateway"
        INCLUSIVE_GATEWAY = "inclusiveGateway"
        INTERMEDIATE_EVENT = "intermediateEvent"

    class GatewayDirection(Enum):
        DIVERGING = "Diverging"
        CONVERGING = "Converging"
        UNSPECIFIED = "Unspecified"

    class Node:
        """Base BPMN node."""

        def __init__(self, id: Optional[str] = None, name: str = "",
                     node_type: Optional[BPMN.NodeType] = None,
                     process: Optional[str] = None,
                     properties: Optional[Dict[str, Any]] = None) -> None:
            self.id: str = id or str(uuid.uuid4())
            self.name: str = name
            self.node_type: Optional[BPMN.NodeType] = node_type
            self.process: Optional[str] = process
            self.in_arcs: Set[BPMN.Flow] = set()
            self.out_arcs: Set[BPMN.Flow] = set()
            self.properties: Dict[str, Any] = properties or {}
            # layout
            self.x: float = 0.0
            self.y: float = 0.0
            self.width: float = 100.0
            self.height: float = 80.0

        def __repr__(self) -> str:
            return f"{self.node_type.value if self.node_type else 'Node'}('{self.name}')"

        def __eq__(self, other: object) -> bool:
            return isinstance(other, BPMN.Node) and self.id == other.id

        def __hash__(self) -> int:
            return hash(self.id)

    class Task(Node):
        def __init__(self, id: Optional[str] = None, name: str = "",
                     properties: Optional[Dict[str, Any]] = None) -> None:
            super().__init__(id=id, name=name, node_type=BPMN.NodeType.TASK,
                             properties=properties)

    class StartEvent(Node):
        def __init__(self, id: Optional[str] = None, name: str = "",
                     properties: Optional[Dict[str, Any]] = None) -> None:
            super().__init__(id=id, name=name, node_type=BPMN.NodeType.START_EVENT,
                             properties=properties)

    class EndEvent(Node):
        def __init__(self, id: Optional[str] = None, name: str = "",
                     properties: Optional[Dict[str, Any]] = None) -> None:
            super().__init__(id=id, name=name, node_type=BPMN.NodeType.END_EVENT,
                             properties=properties)

    class ExclusiveGateway(Node):
        def __init__(self, id: Optional[str] = None, name: str = "",
                     direction: Optional[BPMN.GatewayDirection] = None,
                     properties: Optional[Dict[str, Any]] = None) -> None:
            super().__init__(id=id, name=name,
                             node_type=BPMN.NodeType.EXCLUSIVE_GATEWAY,
                             properties=properties)
            self.direction = direction or BPMN.GatewayDirection.UNSPECIFIED

    class ParallelGateway(Node):
        def __init__(self, id: Optional[str] = None, name: str = "",
                     direction: Optional[BPMN.GatewayDirection] = None,
                     properties: Optional[Dict[str, Any]] = None) -> None:
            super().__init__(id=id, name=name,
                             node_type=BPMN.NodeType.PARALLEL_GATEWAY,
                             properties=properties)
            self.direction = direction or BPMN.GatewayDirection.UNSPECIFIED

    class InclusiveGateway(Node):
        def __init__(self, id: Optional[str] = None, name: str = "",
                     direction: Optional[BPMN.GatewayDirection] = None,
                     properties: Optional[Dict[str, Any]] = None) -> None:
            super().__init__(id=id, name=name,
                             node_type=BPMN.NodeType.INCLUSIVE_GATEWAY,
                             properties=properties)
            self.direction = direction or BPMN.GatewayDirection.UNSPECIFIED

    class Flow:
        """A sequence flow between two BPMN nodes."""

        def __init__(self, source: BPMN.Node, target: BPMN.Node,
                     id: Optional[str] = None, name: str = "",
                     properties: Optional[Dict[str, Any]] = None) -> None:
            self.id: str = id or str(uuid.uuid4())
            self.name: str = name
            self.source: BPMN.Node = source
            self.target: BPMN.Node = target
            self.properties: Dict[str, Any] = properties or {}
            # waypoints for layout
            self.waypoints: list[tuple[float, float]] = []

        def __repr__(self) -> str:
            return f"Flow({self.source} --> {self.target})"

        def __eq__(self, other: object) -> bool:
            return isinstance(other, BPMN.Flow) and self.id == other.id

        def __hash__(self) -> int:
            return hash(self.id)

    # ── BPMN graph ────────────────────────────────────────────────

    def __init__(self, name: str = "",
                 nodes: Optional[Set[BPMN.Node]] = None,
                 flows: Optional[Set[BPMN.Flow]] = None,
                 properties: Optional[Dict[str, Any]] = None) -> None:
        self.name: str = name
        self.nodes: Set[BPMN.Node] = nodes or set()
        self.flows: Set[BPMN.Flow] = flows or set()
        self.properties: Dict[str, Any] = properties or {}

    def add_node(self, node: BPMN.Node) -> None:
        self.nodes.add(node)

    def add_flow(self, flow: BPMN.Flow) -> None:
        self.flows.add(flow)
        flow.source.out_arcs.add(flow)
        flow.target.in_arcs.add(flow)

    def remove_node(self, node: BPMN.Node) -> None:
        for flow in list(node.in_arcs | node.out_arcs):
            self.remove_flow(flow)
        self.nodes.discard(node)

    def remove_flow(self, flow: BPMN.Flow) -> None:
        flow.source.out_arcs.discard(flow)
        flow.target.in_arcs.discard(flow)
        self.flows.discard(flow)

    def get_nodes_by_type(self, node_type: type) -> Set[BPMN.Node]:
        return {n for n in self.nodes if isinstance(n, node_type)}

    def __repr__(self) -> str:
        return (f"BPMN('{self.name}', nodes={len(self.nodes)}, "
                f"flows={len(self.flows)})")
