"""pl4pm.objects.log — Legacy event log wrappers (thin compatibility layer)."""

from __future__ import annotations

from typing import Any, Dict, Iterator, List, Optional


class Event(dict):
    """Single event as a dictionary of attribute→value."""
    pass


class Trace(list):
    """A trace is an ordered list of events with optional case-level attributes."""

    def __init__(self, events: Optional[List[Event]] = None,
                 attributes: Optional[Dict[str, Any]] = None) -> None:
        super().__init__(events or [])
        self.attributes: Dict[str, Any] = attributes or {}

    def __repr__(self) -> str:
        acts = [e.get("concept:name", "?") for e in self]
        return f"Trace({', '.join(acts)})"


class EventLog(list):
    """A log is a list of Trace objects with optional global attributes."""

    def __init__(self, traces: Optional[List[Trace]] = None,
                 attributes: Optional[Dict[str, Any]] = None,
                 classifiers: Optional[Dict[str, list]] = None,
                 extensions: Optional[Dict[str, dict]] = None,
                 properties: Optional[Dict[str, Any]] = None) -> None:
        super().__init__(traces or [])
        self.attributes: Dict[str, Any] = attributes or {}
        self.classifiers: Dict[str, list] = classifiers or {}
        self.extensions: Dict[str, dict] = extensions or {}
        self.properties: Dict[str, Any] = properties or {}

    def __repr__(self) -> str:
        return f"EventLog({len(self)} traces)"


class EventStream(list):
    """A flat list of events (no trace grouping)."""

    def __init__(self, events: Optional[List[Event]] = None,
                 attributes: Optional[Dict[str, Any]] = None) -> None:
        super().__init__(events or [])
        self.attributes: Dict[str, Any] = attributes or {}

    def __repr__(self) -> str:
        return f"EventStream({len(self)} events)"
