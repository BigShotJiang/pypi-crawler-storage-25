"""pl4pm.objects.petri_net — Petri net, places, transitions, arcs, markings."""

from __future__ import annotations

from collections import Counter
from typing import Optional, Set, Dict, Any
import uuid


class PetriNet:
    """Petri net model with places, transitions and arcs."""

    class Place:
        """A place in a Petri net."""

        def __init__(self, name: str, in_arcs: Optional[Set[PetriNet.Arc]] = None,
                     out_arcs: Optional[Set[PetriNet.Arc]] = None,
                     properties: Optional[Dict[str, Any]] = None) -> None:
            self.name: str = name
            self.in_arcs: Set[PetriNet.Arc] = in_arcs or set()
            self.out_arcs: Set[PetriNet.Arc] = out_arcs or set()
            self.properties: Dict[str, Any] = properties or {}
            self._id: str = str(uuid.uuid4())

        def __repr__(self) -> str:
            return self.name

        def __eq__(self, other: object) -> bool:
            if not isinstance(other, PetriNet.Place):
                return False
            return self._id == other._id

        def __hash__(self) -> int:
            return hash(self._id)

    class Transition:
        """A transition in a Petri net."""

        def __init__(self, name: str, label: Optional[str] = None,
                     in_arcs: Optional[Set[PetriNet.Arc]] = None,
                     out_arcs: Optional[Set[PetriNet.Arc]] = None,
                     properties: Optional[Dict[str, Any]] = None) -> None:
            self.name: str = name
            self.label: Optional[str] = label
            self.in_arcs: Set[PetriNet.Arc] = in_arcs or set()
            self.out_arcs: Set[PetriNet.Arc] = out_arcs or set()
            self.properties: Dict[str, Any] = properties or {}
            self._id: str = str(uuid.uuid4())

        @property
        def is_silent(self) -> bool:
            return self.label is None

        def __repr__(self) -> str:
            if self.label:
                return f"{self.name} ({self.label})"
            return f"{self.name} (tau)"

        def __eq__(self, other: object) -> bool:
            if not isinstance(other, PetriNet.Transition):
                return False
            return self._id == other._id

        def __hash__(self) -> int:
            return hash(self._id)

    class Arc:
        """An arc connecting a place to a transition or vice-versa."""

        def __init__(self, source: PetriNet.Place | PetriNet.Transition,
                     target: PetriNet.Place | PetriNet.Transition,
                     weight: int = 1,
                     properties: Optional[Dict[str, Any]] = None) -> None:
            self.source = source
            self.target = target
            self.weight: int = weight
            self.properties: Dict[str, Any] = properties or {}
            self._id: str = str(uuid.uuid4())

        def __repr__(self) -> str:
            return f"({self.source})-->({self.target})[{self.weight}]"

        def __eq__(self, other: object) -> bool:
            if not isinstance(other, PetriNet.Arc):
                return False
            return self._id == other._id

        def __hash__(self) -> int:
            return hash(self._id)

    def __init__(self, name: str = "",
                 places: Optional[Set[PetriNet.Place]] = None,
                 transitions: Optional[Set[PetriNet.Transition]] = None,
                 arcs: Optional[Set[PetriNet.Arc]] = None,
                 properties: Optional[Dict[str, Any]] = None) -> None:
        self.name: str = name
        self.places: Set[PetriNet.Place] = places or set()
        self.transitions: Set[PetriNet.Transition] = transitions or set()
        self.arcs: Set[PetriNet.Arc] = arcs or set()
        self.properties: Dict[str, Any] = properties or {}

    def __repr__(self) -> str:
        return (f"PetriNet('{self.name}', places={len(self.places)}, "
                f"transitions={len(self.transitions)}, arcs={len(self.arcs)})")


def add_arc_from_to(source: PetriNet.Place | PetriNet.Transition,
                    target: PetriNet.Place | PetriNet.Transition,
                    net: PetriNet, weight: int = 1) -> PetriNet.Arc:
    """Add an arc from *source* to *target* in *net*."""
    arc = PetriNet.Arc(source, target, weight)
    net.arcs.add(arc)
    source.out_arcs.add(arc)
    target.in_arcs.add(arc)
    return arc


def remove_arc(net: PetriNet, arc: PetriNet.Arc) -> None:
    """Remove an arc from *net*."""
    arc.source.out_arcs.discard(arc)
    arc.target.in_arcs.discard(arc)
    net.arcs.discard(arc)


def remove_place(net: PetriNet, place: PetriNet.Place) -> None:
    """Remove a place and all connected arcs."""
    for arc in list(place.in_arcs | place.out_arcs):
        remove_arc(net, arc)
    net.places.discard(place)


def remove_transition(net: PetriNet, trans: PetriNet.Transition) -> None:
    """Remove a transition and all connected arcs."""
    for arc in list(trans.in_arcs | trans.out_arcs):
        remove_arc(net, arc)
    net.transitions.discard(trans)


class Marking(Counter):
    """A marking is a multiset of places (Counter[Place] -> int)."""

    def __repr__(self) -> str:
        items = ", ".join(f"{p.name}:{n}" for p, n in self.items() if n > 0)
        return f"[{items}]"

    def __hash__(self) -> int:  # type: ignore[override]
        return hash(frozenset((p, n) for p, n in self.items() if n > 0))

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Marking):
            return NotImplemented
        return Counter.__eq__(self, other)
