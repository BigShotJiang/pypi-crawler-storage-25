"""pl4pm.objects.transition_system — Transition system / reachability graph."""

from __future__ import annotations

from typing import Optional, Set, Dict, Any
import uuid


class TransitionSystem:
    """Labelled transition system (reachability graph)."""

    class State:
        """A state in the transition system."""

        def __init__(self, name: str, data: Optional[Any] = None) -> None:
            self.name: str = name
            self.data: Any = data
            self.incoming: Set[TransitionSystem.Transition] = set()
            self.outgoing: Set[TransitionSystem.Transition] = set()
            self._id: str = str(uuid.uuid4())

        def __repr__(self) -> str:
            return self.name

        def __eq__(self, other: object) -> bool:
            return isinstance(other, TransitionSystem.State) and self._id == other._id

        def __hash__(self) -> int:
            return hash(self._id)

    class Transition:
        """A transition (edge) in the transition system."""

        def __init__(self, name: str,
                     source: TransitionSystem.State,
                     target: TransitionSystem.State,
                     data: Optional[Any] = None) -> None:
            self.name: str = name
            self.source: TransitionSystem.State = source
            self.target: TransitionSystem.State = target
            self.data: Any = data
            self._id: str = str(uuid.uuid4())

        def __repr__(self) -> str:
            return f"{self.source}--{self.name}-->{self.target}"

        def __eq__(self, other: object) -> bool:
            return isinstance(other, TransitionSystem.Transition) and self._id == other._id

        def __hash__(self) -> int:
            return hash(self._id)

    def __init__(self, name: str = "",
                 states: Optional[Set[TransitionSystem.State]] = None,
                 transitions: Optional[Set[TransitionSystem.Transition]] = None) -> None:
        self.name: str = name
        self.states: Set[TransitionSystem.State] = states or set()
        self.transitions: Set[TransitionSystem.Transition] = transitions or set()

    def add_state(self, state: TransitionSystem.State) -> None:
        self.states.add(state)

    def add_transition(self, transition: TransitionSystem.Transition) -> None:
        self.transitions.add(transition)
        transition.source.outgoing.add(transition)
        transition.target.incoming.add(transition)

    def __repr__(self) -> str:
        return (f"TransitionSystem('{self.name}', states={len(self.states)}, "
                f"transitions={len(self.transitions)})")
