"""pl4pm.org — Organizational analysis (SNA, roles, network analysis)."""

from __future__ import annotations

from collections import Counter, defaultdict
from typing import Any, Collection, Dict, List, Optional, Set, Tuple

import polars as pl
import numpy as np

from pl4pm.constants import (
    CASE_ID_KEY, ACTIVITY_KEY, TIMESTAMP_KEY, RESOURCE_KEY,
)


# ══════════════════════════════════════════════════════════════════════
# SNA result type
# ══════════════════════════════════════════════════════════════════════

class SNA:
    """Social Network Analysis result: a weighted directed graph between resources."""
    def __init__(self, connections: Dict[Tuple[str, str], float]):
        self.connections = connections
        nodes = set()
        for (a, b) in connections:
            nodes.add(a)
            nodes.add(b)
        self.nodes = sorted(nodes)

    def __repr__(self) -> str:
        return f"SNA(nodes={len(self.nodes)}, edges={len(self.connections)})"

    def to_dict(self) -> Dict[Tuple[str, str], float]:
        return dict(self.connections)

    def to_matrix(self) -> Tuple[List[str], np.ndarray]:
        idx = {n: i for i, n in enumerate(self.nodes)}
        n = len(self.nodes)
        mat = np.zeros((n, n), dtype=np.float64)
        for (a, b), w in self.connections.items():
            if a in idx and b in idx:
                mat[idx[a], idx[b]] = w
        return self.nodes, mat


# ══════════════════════════════════════════════════════════════════════
# Role type
# ══════════════════════════════════════════════════════════════════════

class Role:
    """An organizational role = a group of (activities, resources)."""
    def __init__(self, activities: Set[str], resources: Set[str]):
        self.activities = activities
        self.resources = resources

    def __repr__(self) -> str:
        return f"Role(activities={self.activities}, resources={self.resources})"


# ══════════════════════════════════════════════════════════════════════
# Helper: extract (case, resource) sequences
# ══════════════════════════════════════════════════════════════════════

def _resource_sequences(
    log: pl.LazyFrame,
    resource_key: str, timestamp_key: str, case_id_key: str,
) -> List[List[str]]:
    df = log.collect() if isinstance(log, pl.LazyFrame) else log
    df = df.sort([case_id_key, timestamp_key])
    seqs: List[List[str]] = []
    for _, group in df.group_by(case_id_key, maintain_order=True):
        if resource_key in group.columns:
            seqs.append(group[resource_key].to_list())
        else:
            seqs.append([])
    return seqs


# ══════════════════════════════════════════════════════════════════════
# Handover of work
# ══════════════════════════════════════════════════════════════════════

def discover_handover_of_work_network(
    log: pl.LazyFrame,
    beta: int = 0,
    resource_key: str = RESOURCE_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
) -> SNA:
    """Handover of work: DFG but with resources as nodes."""
    seqs = _resource_sequences(log, resource_key, timestamp_key, case_id_key)
    edge_counts: Dict[Tuple[str, str], int] = defaultdict(int)

    for seq in seqs:
        for i in range(len(seq) - 1):
            if seq[i] and seq[i + 1] and seq[i] != seq[i + 1]:
                # With beta: consider distance up to beta
                for j in range(i + 1, min(i + 2 + beta, len(seq))):
                    if seq[j] and seq[i] != seq[j]:
                        edge_counts[(str(seq[i]), str(seq[j]))] += 1
                        break

    # Normalize
    max_val = max(edge_counts.values()) if edge_counts else 1
    connections = {k: v / max_val for k, v in edge_counts.items()}
    return SNA(connections)


# ══════════════════════════════════════════════════════════════════════
# Working together
# ══════════════════════════════════════════════════════════════════════

def discover_working_together_network(
    log: pl.LazyFrame,
    resource_key: str = RESOURCE_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
) -> SNA:
    """Working together: resources connected if they share a case."""
    df = log.collect() if isinstance(log, pl.LazyFrame) else log
    if resource_key not in df.columns:
        return SNA({})

    edge_counts: Dict[Tuple[str, str], int] = defaultdict(int)
    for _, group in df.group_by(case_id_key, maintain_order=True):
        resources = set(group[resource_key].unique().to_list())
        resources.discard(None)
        resources_list = sorted(str(r) for r in resources)
        for i in range(len(resources_list)):
            for j in range(i + 1, len(resources_list)):
                edge_counts[(resources_list[i], resources_list[j])] += 1
                edge_counts[(resources_list[j], resources_list[i])] += 1

    max_val = max(edge_counts.values()) if edge_counts else 1
    return SNA({k: v / max_val for k, v in edge_counts.items()})


# ══════════════════════════════════════════════════════════════════════
# Activity-based resource similarity
# ══════════════════════════════════════════════════════════════════════

def discover_activity_based_resource_similarity(
    log: pl.LazyFrame,
    activity_key: str = ACTIVITY_KEY,
    resource_key: str = RESOURCE_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
) -> SNA:
    """Cosine similarity between resource activity profiles."""
    df = log.collect() if isinstance(log, pl.LazyFrame) else log
    if resource_key not in df.columns:
        return SNA({})

    # Build resource-activity matrix
    profile = (
        df.group_by([resource_key, activity_key])
        .agg(pl.len().alias("cnt"))
        .collect() if isinstance(df, pl.LazyFrame) else
        df.group_by([resource_key, activity_key])
        .agg(pl.len().alias("cnt"))
    )

    resources = sorted(profile[resource_key].unique().to_list())
    activities = sorted(profile[activity_key].unique().to_list())
    act_idx = {a: i for i, a in enumerate(activities)}

    vectors: Dict[str, np.ndarray] = {}
    for res in resources:
        vec = np.zeros(len(activities))
        subset = profile.filter(pl.col(resource_key) == res)
        for row in subset.iter_rows(named=True):
            vec[act_idx[row[activity_key]]] = row["cnt"]
        vectors[str(res)] = vec

    connections: Dict[Tuple[str, str], float] = {}
    res_list = sorted(vectors.keys())
    for i in range(len(res_list)):
        for j in range(i + 1, len(res_list)):
            v1, v2 = vectors[res_list[i]], vectors[res_list[j]]
            denom = np.linalg.norm(v1) * np.linalg.norm(v2)
            sim = float(np.dot(v1, v2) / denom) if denom > 0 else 0.0
            connections[(res_list[i], res_list[j])] = sim
            connections[(res_list[j], res_list[i])] = sim

    return SNA(connections)


# ══════════════════════════════════════════════════════════════════════
# Subcontracting
# ══════════════════════════════════════════════════════════════════════

def discover_subcontracting_network(
    log: pl.LazyFrame,
    n: int = 2,
    resource_key: str = RESOURCE_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
) -> SNA:
    """Subcontracting: A→B→...→A pattern detection."""
    seqs = _resource_sequences(log, resource_key, timestamp_key, case_id_key)
    edge_counts: Dict[Tuple[str, str], int] = defaultdict(int)

    for seq in seqs:
        for i in range(len(seq)):
            r_start = seq[i]
            if not r_start:
                continue
            for depth in range(2, n + 2):
                end_idx = i + depth
                if end_idx < len(seq) and seq[end_idx] == r_start:
                    for mid in range(i + 1, end_idx):
                        if seq[mid] and seq[mid] != r_start:
                            edge_counts[(str(r_start), str(seq[mid]))] += 1

    max_val = max(edge_counts.values()) if edge_counts else 1
    return SNA({k: v / max_val for k, v in edge_counts.items()})


# ══════════════════════════════════════════════════════════════════════
# Organizational roles
# ══════════════════════════════════════════════════════════════════════

def discover_organizational_roles(
    log: pl.LazyFrame,
    activity_key: str = ACTIVITY_KEY,
    resource_key: str = RESOURCE_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
) -> List[Role]:
    """Mine organizational roles via activity-resource clustering."""
    df = log.collect() if isinstance(log, pl.LazyFrame) else log
    if resource_key not in df.columns:
        return []

    # Group resources by their activity sets
    res_acts: Dict[str, Set[str]] = defaultdict(set)
    for row in df.select([resource_key, activity_key]).iter_rows(named=True):
        res = str(row[resource_key])
        act = str(row[activity_key])
        res_acts[res].add(act)

    # Cluster by identical activity sets
    act_set_to_resources: Dict[frozenset, Set[str]] = defaultdict(set)
    for res, acts in res_acts.items():
        act_set_to_resources[frozenset(acts)].add(res)

    roles: List[Role] = []
    for acts_frozen, resources in act_set_to_resources.items():
        roles.append(Role(activities=set(acts_frozen), resources=resources))

    return roles


# ══════════════════════════════════════════════════════════════════════
# Network analysis
# ══════════════════════════════════════════════════════════════════════

def discover_network_analysis(
    log: pl.LazyFrame,
    out_column: str = CASE_ID_KEY,
    in_column: str = CASE_ID_KEY,
    node_column_source: str = RESOURCE_KEY,
    node_column_target: str = RESOURCE_KEY,
    edge_column: str = ACTIVITY_KEY,
    edge_reference: str = "_out",
    performance: bool = False,
    sorting_column: str = TIMESTAMP_KEY,
    timestamp_column: str = TIMESTAMP_KEY,
) -> Dict[Tuple[str, str], Dict[str, Any]]:
    """General network analysis: link events by signal columns."""
    df = log.collect() if isinstance(log, pl.LazyFrame) else log
    df = df.sort(sorting_column)

    required_cols = {out_column, in_column, node_column_source,
                     node_column_target, edge_column}
    if not required_cols.issubset(set(df.columns)):
        missing = required_cols - set(df.columns)
        return {}

    # Self-join: EV1.out_column == EV2.in_column and EV1 before EV2
    ev_out = df.with_row_index("_idx_out")
    ev_in = df.with_row_index("_idx_in")

    joined = (
        ev_out.lazy()
        .join(
            ev_in.lazy(),
            left_on=out_column,
            right_on=in_column,
            how="inner",
        )
        .filter(pl.col("_idx_out") < pl.col("_idx_in"))
    )

    # Keep only directly-follows within the same signal
    joined = (
        joined.sort(["_idx_out", "_idx_in"])
        .group_by("_idx_out")
        .agg(pl.all().first())
        .collect()
    )

    if len(joined) == 0:
        return {}

    src_col = f"{node_column_source}"
    tgt_col = f"{node_column_target}_right"
    edge_col = f"{edge_column}" if edge_reference == "_out" else f"{edge_column}_right"

    # Check column existence after join
    available = set(joined.columns)
    if src_col not in available or tgt_col not in available:
        # Try alternative naming
        tgt_col = node_column_target
        if tgt_col not in available:
            return {}

    result: Dict[Tuple[str, str], Dict[str, Any]] = defaultdict(
        lambda: {"frequency": 0, "performance": []}
    )

    ts_col_out = timestamp_column
    ts_col_in = f"{timestamp_column}_right"

    for row in joined.iter_rows(named=True):
        src = str(row.get(src_col, ""))
        tgt = str(row.get(tgt_col, ""))
        edge = str(row.get(edge_col, ""))
        key = (src, tgt)
        result[key]["frequency"] += 1
        result[key].setdefault("edge_types", Counter())[edge] += 1
        if performance and ts_col_out in row and ts_col_in in row:
            try:
                dt = (row[ts_col_in] - row[ts_col_out]).total_seconds()
                result[key]["performance"].append(dt)
            except Exception:
                pass

    # Aggregate performance
    for key in result:
        perfs = result[key].get("performance", [])
        if perfs:
            result[key]["mean_performance"] = float(np.mean(perfs))
        del result[key]["performance"]

    return dict(result)


__all__ = [
    "SNA", "Role",
    "discover_handover_of_work_network",
    "discover_working_together_network",
    "discover_activity_based_resource_similarity",
    "discover_subcontracting_network",
    "discover_organizational_roles",
    "discover_network_analysis",
]
