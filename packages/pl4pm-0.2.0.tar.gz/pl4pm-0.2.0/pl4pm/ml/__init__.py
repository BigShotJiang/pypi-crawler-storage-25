"""pl4pm.ml — Machine learning features for process mining."""

from __future__ import annotations

from collections import Counter
from typing import Any, Collection, Dict, List, Optional, Set, Tuple, Union

import polars as pl
import numpy as np

from pl4pm.constants import (
    CASE_ID_KEY, ACTIVITY_KEY, TIMESTAMP_KEY, RESOURCE_KEY,
)
from pl4pm.objects.ocel import OCEL


# ══════════════════════════════════════════════════════════════════════
# Train/test split
# ══════════════════════════════════════════════════════════════════════

def split_train_test(
    log: pl.LazyFrame,
    train_percentage: float = 0.8,
    case_id_key: str = CASE_ID_KEY,
) -> Tuple[pl.DataFrame, pl.DataFrame]:
    """Split log into train and test sets by case."""
    df = log.collect() if isinstance(log, pl.LazyFrame) else log
    case_ids = df[case_id_key].unique().to_list()
    n_train = int(len(case_ids) * train_percentage)

    import random
    shuffled = list(case_ids)
    random.shuffle(shuffled)

    train_ids = set(shuffled[:n_train])
    test_ids = set(shuffled[n_train:])

    train_df = df.filter(pl.col(case_id_key).is_in(list(train_ids)))
    test_df = df.filter(pl.col(case_id_key).is_in(list(test_ids)))

    return train_df, test_df


# ══════════════════════════════════════════════════════════════════════
# Prefix extraction
# ══════════════════════════════════════════════════════════════════════

def get_prefixes_from_log(
    log: pl.LazyFrame,
    length: int,
    case_id_key: str = CASE_ID_KEY,
) -> pl.DataFrame:
    """Get prefixes of traces up to a specified length."""
    df = log.collect() if isinstance(log, pl.LazyFrame) else log

    result = (
        df.lazy()
        .with_columns(
            pl.col(case_id_key)
            .cum_count()
            .over(case_id_key)
            .alias("_event_idx")
        )
        .filter(pl.col("_event_idx") <= length)
        .drop("_event_idx")
        .collect()
    )
    return result


# ══════════════════════════════════════════════════════════════════════
# Outcome-enriched dataframe
# ══════════════════════════════════════════════════════════════════════

def extract_outcome_enriched_dataframe(
    log: pl.LazyFrame,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
    start_timestamp_key: str = TIMESTAMP_KEY,
) -> pl.DataFrame:
    """Enrich dataframe with outcome columns (remaining time, elapsed, etc.)."""
    df = log.collect() if isinstance(log, pl.LazyFrame) else log
    df = df.sort([case_id_key, timestamp_key])

    result = (
        df.lazy()
        .with_columns([
            # Last activity in case
            pl.col(activity_key).last().over(case_id_key).alias("@@case_last_activity"),
            # Case end timestamp
            pl.col(timestamp_key).max().over(case_id_key).alias("@@case_end_timestamp"),
            # Case start timestamp
            pl.col(timestamp_key).min().over(case_id_key).alias("@@case_start_timestamp"),
        ])
        .with_columns([
            # Remaining time
            (pl.col("@@case_end_timestamp") - pl.col(timestamp_key))
            .dt.total_seconds()
            .alias("@@remaining_time"),
            # Elapsed time
            (pl.col(timestamp_key) - pl.col("@@case_start_timestamp"))
            .dt.total_seconds()
            .alias("@@elapsed_time"),
            # Case duration
            (pl.col("@@case_end_timestamp") - pl.col("@@case_start_timestamp"))
            .dt.total_seconds()
            .alias("@@case_duration"),
        ])
        .collect()
    )
    return result


# ══════════════════════════════════════════════════════════════════════
# Feature extraction
# ══════════════════════════════════════════════════════════════════════

def extract_features_dataframe(
    log: pl.LazyFrame,
    str_tr_attr: Optional[List[str]] = None,
    num_tr_attr: Optional[List[str]] = None,
    str_ev_attr: Optional[List[str]] = None,
    num_ev_attr: Optional[List[str]] = None,
    str_evsucc_attr: Optional[List[str]] = None,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: Optional[str] = None,
    resource_key: str = RESOURCE_KEY,
    include_case_id: bool = False,
    count_occurrences: bool = False,
    **kwargs,
) -> pl.DataFrame:
    """Extract features per case for ML tasks."""
    case_id = case_id_key or CASE_ID_KEY
    df = log.collect() if isinstance(log, pl.LazyFrame) else log
    df = df.sort([case_id, timestamp_key])

    # Base: one-hot encode activities per case
    all_acts = sorted(df[activity_key].unique().to_list())

    agg_exprs: List[pl.Expr] = []

    # Activity features
    for act in all_acts:
        col_name = f"act_{act}"
        if count_occurrences:
            agg_exprs.append(
                (pl.col(activity_key) == act).sum().cast(pl.Float64).alias(col_name)
            )
        else:
            agg_exprs.append(
                (pl.col(activity_key) == act).any().cast(pl.Float64).alias(col_name)
            )

    # Case duration
    agg_exprs.append(
        (pl.col(timestamp_key).max() - pl.col(timestamp_key).min())
        .dt.total_seconds()
        .alias("case_duration_s")
    )
    # Number of events
    agg_exprs.append(pl.len().cast(pl.Float64).alias("n_events"))

    # Numeric event attributes (last value)
    if num_ev_attr:
        for attr in num_ev_attr:
            if attr in df.columns:
                agg_exprs.append(
                    pl.col(attr).last().cast(pl.Float64).alias(f"num_ev_{attr}")
                )

    # String event attributes (one-hot via count)
    if str_ev_attr:
        for attr in str_ev_attr:
            if attr in df.columns and attr != activity_key:
                vals = sorted(df[attr].unique().to_list())
                for val in vals:
                    agg_exprs.append(
                        (pl.col(attr) == val).sum().cast(pl.Float64).alias(f"str_ev_{attr}_{val}")
                    )

    features = df.group_by(case_id).agg(agg_exprs)

    # Trace-level attributes
    if num_tr_attr:
        for attr in num_tr_attr:
            if attr in df.columns:
                tr_vals = (
                    df.group_by(case_id)
                    .agg(pl.col(attr).first().cast(pl.Float64).alias(f"num_tr_{attr}"))
                )
                features = features.join(tr_vals, on=case_id, how="left")

    if str_tr_attr:
        for attr in str_tr_attr:
            if attr in df.columns:
                vals = sorted(df[attr].unique().to_list())
                tr_onehot = (
                    df.group_by(case_id)
                    .agg([
                        (pl.col(attr).first() == val).cast(pl.Float64).alias(f"str_tr_{attr}_{val}")
                        for val in vals
                    ])
                )
                features = features.join(tr_onehot, on=case_id, how="left")

    if not include_case_id:
        features = features.drop(case_id)

    return features


# ══════════════════════════════════════════════════════════════════════
# OCEL feature extraction
# ══════════════════════════════════════════════════════════════════════

def extract_ocel_features(
    ocel: OCEL,
    obj_type: str,
    enable_object_lifecycle_paths: bool = True,
    enable_object_work_in_progress: bool = False,
    object_str_attributes: Optional[Collection[str]] = None,
    object_num_attributes: Optional[Collection[str]] = None,
    include_obj_id: bool = False,
    debug: bool = False,
) -> pl.DataFrame:
    """Extract features from OCEL for objects of a given type."""
    if ocel.objects is None:
        return pl.DataFrame()

    obj_df = ocel.objects.collect() if isinstance(ocel.objects, pl.LazyFrame) else ocel.objects
    type_col = "ocel:type" if "ocel:type" in obj_df.columns else None

    if type_col is None:
        # Try to find type column
        for col in obj_df.columns:
            if "type" in col.lower():
                type_col = col
                break

    if type_col is None:
        return pl.DataFrame()

    objects_of_type = obj_df.filter(pl.col(type_col) == obj_type)

    if len(objects_of_type) == 0:
        return pl.DataFrame()

    # Build feature columns
    feature_cols: Dict[str, List] = {}

    id_col = "ocel:oid" if "ocel:oid" in objects_of_type.columns else objects_of_type.columns[0]
    obj_ids = objects_of_type[id_col].to_list()

    if include_obj_id:
        feature_cols["object_id"] = obj_ids

    # Numeric attributes
    if object_num_attributes:
        for attr in object_num_attributes:
            if attr in objects_of_type.columns:
                feature_cols[f"num_{attr}"] = objects_of_type[attr].to_list()

    # String attributes (one-hot)
    if object_str_attributes:
        for attr in object_str_attributes:
            if attr in objects_of_type.columns:
                vals = sorted(objects_of_type[attr].unique().to_list())
                for val in vals:
                    feature_cols[f"str_{attr}_{val}"] = [
                        1.0 if v == val else 0.0
                        for v in objects_of_type[attr].to_list()
                    ]

    if not feature_cols:
        feature_cols["_placeholder"] = [0.0] * len(obj_ids)

    return pl.DataFrame(feature_cols)


# ══════════════════════════════════════════════════════════════════════
# Temporal features
# ══════════════════════════════════════════════════════════════════════

def extract_temporal_features_dataframe(
    log: pl.LazyFrame,
    grouper_freq: str = "W",
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: Optional[str] = None,
    start_timestamp_key: str = TIMESTAMP_KEY,
    resource_key: str = RESOURCE_KEY,
) -> pl.DataFrame:
    """Extract temporal features grouped by time period."""
    case_id = case_id_key or CASE_ID_KEY
    df = log.collect() if isinstance(log, pl.LazyFrame) else log

    freq_map = {"D": "1d", "W": "1w", "M": "1mo", "Y": "1y"}
    pl_freq = freq_map.get(grouper_freq, "1w")

    result = (
        df.lazy()
        .with_columns(
            pl.col(timestamp_key).dt.truncate(pl_freq).alias("_period")
        )
        .group_by("_period")
        .agg([
            pl.len().alias("n_events"),
            pl.col(case_id).n_unique().alias("n_cases"),
            pl.col(activity_key).n_unique().alias("n_unique_activities"),
        ])
        .sort("_period")
        .collect()
    )

    # Add derived features
    result = result.with_columns([
        (pl.col("n_events") / pl.col("n_cases").cast(pl.Float64)).alias("events_per_case"),
    ])

    # Add resource features if available
    if resource_key in df.columns:
        res_features = (
            df.lazy()
            .with_columns(
                pl.col(timestamp_key).dt.truncate(pl_freq).alias("_period")
            )
            .group_by("_period")
            .agg(pl.col(resource_key).n_unique().alias("n_unique_resources"))
            .collect()
        )
        result = result.join(res_features, on="_period", how="left")

    return result


# ══════════════════════════════════════════════════════════════════════
# Target vector extraction
# ══════════════════════════════════════════════════════════════════════

def extract_target_vector(
    log: pl.LazyFrame,
    variant: str,
    activity_key: str = ACTIVITY_KEY,
    timestamp_key: str = TIMESTAMP_KEY,
    case_id_key: str = CASE_ID_KEY,
) -> Tuple[Any, List[str]]:
    """Extract target vector for ML prediction tasks.

    Variants: 'next_activity', 'next_time', 'remaining_time'.
    """
    df = log.collect() if isinstance(log, pl.LazyFrame) else log
    df = df.sort([case_id_key, timestamp_key])

    if variant == "next_activity":
        result = (
            df.lazy()
            .with_columns(
                pl.col(activity_key).shift(-1).over(case_id_key).alias("_next_act")
            )
            .filter(pl.col("_next_act").is_not_null())
            .collect()
        )
        targets = result["_next_act"].to_list()
        classes = sorted(set(targets))
        return targets, classes

    elif variant == "next_time":
        result = (
            df.lazy()
            .with_columns(
                pl.col(timestamp_key).shift(-1).over(case_id_key).alias("_next_ts")
            )
            .filter(pl.col("_next_ts").is_not_null())
            .with_columns(
                (pl.col("_next_ts") - pl.col(timestamp_key))
                .dt.total_seconds()
                .alias("_time_to_next")
            )
            .collect()
        )
        targets = result["_time_to_next"].to_list()
        return targets, []

    elif variant == "remaining_time":
        result = (
            df.lazy()
            .with_columns(
                pl.col(timestamp_key).max().over(case_id_key).alias("_case_end")
            )
            .with_columns(
                (pl.col("_case_end") - pl.col(timestamp_key))
                .dt.total_seconds()
                .alias("_remaining_time")
            )
            .collect()
        )
        targets = result["_remaining_time"].to_list()
        return targets, []

    else:
        raise ValueError(f"Unsupported variant: {variant}. Use 'next_activity', 'next_time', or 'remaining_time'.")


__all__ = [
    "split_train_test",
    "get_prefixes_from_log",
    "extract_outcome_enriched_dataframe",
    "extract_features_dataframe",
    "extract_ocel_features",
    "extract_temporal_features_dataframe",
    "extract_target_vector",
]
