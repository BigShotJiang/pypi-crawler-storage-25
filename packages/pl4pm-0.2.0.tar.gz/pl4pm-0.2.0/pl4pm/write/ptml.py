"""pl4pm.write.ptml — Process tree (.ptml) writer."""

from __future__ import annotations

from lxml import etree  # type: ignore[import-untyped]

from pl4pm.objects.process_tree import ProcessTree, Operator, from_any_process_tree

_OP_NAME_MAP = {
    Operator.SEQUENCE: "sequence",
    Operator.XOR: "xor",
    Operator.PARALLEL: "and",
    Operator.LOOP: "xorLoop",
    Operator.OR: "or",
}


def _build_elem(node: ProcessTree) -> etree._Element:
    """Recursively build XML elements for a process tree node."""
    if node.is_leaf:
        if node.is_tau:
            return etree.Element("automaticTask")
        elem = etree.Element("manualTask", name=node.label or "")
        return elem

    op_name = _OP_NAME_MAP.get(node.operator, "sequence")
    elem = etree.Element("parentsNode", name="", operator=op_name)
    for child in node.children:
        elem.append(_build_elem(child))
    return elem


def write_ptml(
    tree: ProcessTree,
    file_path: str,
    auto_layout: bool = True,
    encoding: str = "utf-8",
) -> None:
    """Write a process tree to a .ptml file."""
    if not isinstance(tree, ProcessTree):
        tree = from_any_process_tree(tree)
    root = etree.Element("ptml")
    tree_elem = _build_elem(tree)
    root.append(tree_elem)
    xml_tree = etree.ElementTree(root)
    xml_tree.write(file_path, pretty_print=True, xml_declaration=True,
                   encoding=encoding)
