"""pl4pm.write.bpmn — BPMN 2.0 XML writer."""

from __future__ import annotations

from lxml import etree  # type: ignore[import-untyped]

from pl4pm.objects.bpmn import BPMN

_BPMN_NS = "http://www.omg.org/spec/BPMN/20100524/MODEL"
_BPMNDI_NS = "http://www.omg.org/spec/BPMN/20100524/DI"
_DC_NS = "http://www.omg.org/spec/DD/20100524/DC"
_DI_NS = "http://www.omg.org/spec/DD/20100524/DI"

_TYPE_TAG = {
    BPMN.NodeType.TASK: "task",
    BPMN.NodeType.START_EVENT: "startEvent",
    BPMN.NodeType.END_EVENT: "endEvent",
    BPMN.NodeType.EXCLUSIVE_GATEWAY: "exclusiveGateway",
    BPMN.NodeType.PARALLEL_GATEWAY: "parallelGateway",
    BPMN.NodeType.INCLUSIVE_GATEWAY: "inclusiveGateway",
}


def _auto_layout(bpmn: BPMN) -> None:
    """Assign simple left-to-right positions if not set."""
    x, y = 100.0, 100.0
    visited: set[str] = set()
    # BFS from start events
    queue: list[BPMN.Node] = []
    for n in bpmn.nodes:
        if isinstance(n, BPMN.StartEvent):
            queue.append(n)

    if not queue:
        queue = list(bpmn.nodes)[:1]

    while queue:
        node = queue.pop(0)
        if node.id in visited:
            continue
        visited.add(node.id)
        node.x, node.y = x, y
        x += 150.0
        if x > 1500:
            x = 100.0
            y += 150.0
        for flow in node.out_arcs:
            if flow.target.id not in visited:
                queue.append(flow.target)

    # assign remaining
    for n in bpmn.nodes:
        if n.id not in visited:
            n.x, n.y = x, y
            x += 150.0


def write_bpmn(
    model: BPMN,
    file_path: str,
    auto_layout: bool = True,
    encoding: str = "utf-8",
) -> None:
    """Write a BPMN model to a .bpmn XML file."""
    if auto_layout:
        _auto_layout(model)

    nsmap = {
        None: _BPMN_NS,
        "bpmndi": _BPMNDI_NS,
        "dc": _DC_NS,
        "di": _DI_NS,
    }
    root = etree.Element("{%s}definitions" % _BPMN_NS, nsmap=nsmap,
                         id="definitions")

    process_elem = etree.SubElement(root, "{%s}process" % _BPMN_NS,
                                    id="process", isExecutable="false")

    for node in model.nodes:
        tag = _TYPE_TAG.get(node.node_type, "task")
        attribs = {"id": node.id, "name": node.name}
        etree.SubElement(process_elem, "{%s}%s" % (_BPMN_NS, tag), **attribs)

    for flow in model.flows:
        etree.SubElement(process_elem, "{%s}sequenceFlow" % _BPMN_NS,
                         id=flow.id, sourceRef=flow.source.id,
                         targetRef=flow.target.id, name=flow.name)

    # Diagram
    diagram = etree.SubElement(root, "{%s}BPMNDiagram" % _BPMNDI_NS, id="diagram")
    plane = etree.SubElement(diagram, "{%s}BPMNPlane" % _BPMNDI_NS,
                             bpmnElement="process")

    for node in model.nodes:
        shape = etree.SubElement(plane, "{%s}BPMNShape" % _BPMNDI_NS,
                                 bpmnElement=node.id)
        etree.SubElement(shape, "{%s}Bounds" % _DC_NS,
                         x=str(node.x), y=str(node.y),
                         width=str(node.width), height=str(node.height))

    for flow in model.flows:
        edge = etree.SubElement(plane, "{%s}BPMNEdge" % _BPMNDI_NS,
                                bpmnElement=flow.id)
        if flow.waypoints:
            for wx, wy in flow.waypoints:
                etree.SubElement(edge, "{%s}waypoint" % _DI_NS,
                                 x=str(wx), y=str(wy))
        else:
            etree.SubElement(edge, "{%s}waypoint" % _DI_NS,
                             x=str(flow.source.x + flow.source.width),
                             y=str(flow.source.y + flow.source.height / 2))
            etree.SubElement(edge, "{%s}waypoint" % _DI_NS,
                             x=str(flow.target.x),
                             y=str(flow.target.y + flow.target.height / 2))

    tree = etree.ElementTree(root)
    tree.write(file_path, pretty_print=True, xml_declaration=True, encoding=encoding)
