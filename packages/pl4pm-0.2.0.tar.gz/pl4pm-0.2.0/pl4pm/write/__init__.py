"""pl4pm.write — Unified writer module."""

from pl4pm.write.xes import write_xes
from pl4pm.write.csv import write_csv
from pl4pm.write.pnml import write_pnml
from pl4pm.write.ptml import write_ptml
from pl4pm.write.dfg import write_dfg
from pl4pm.write.bpmn import write_bpmn
from pl4pm.write.ocel import (
    write_ocel_csv, write_ocel_json, write_ocel_xml, write_ocel_sqlite,
    write_ocel2_json, write_ocel2_xml, write_ocel2_sqlite,
)
from pl4pm.objects.ocel import OCEL


def write_ocel(
    ocel: OCEL,
    file_path: str,
    objects_path: str | None = None,
    encoding: str = "utf-8",
) -> None:
    """Auto-detect output format by extension."""
    fp = file_path.lower()
    if fp.endswith(".csv"):
        write_ocel_csv(ocel, file_path, objects_path=objects_path, encoding=encoding)
    elif fp.endswith(".jsonocel") or fp.endswith(".json"):
        write_ocel_json(ocel, file_path, encoding=encoding)
    elif fp.endswith(".xmlocel") or fp.endswith(".xml"):
        write_ocel_xml(ocel, file_path, encoding=encoding)
    elif fp.endswith(".sqlite"):
        write_ocel_sqlite(ocel, file_path, encoding=encoding)
    else:
        raise ValueError(f"Unsupported OCEL output format: {file_path}")


def write_ocel2(
    ocel: OCEL,
    file_path: str,
    encoding: str = "utf-8",
) -> None:
    """Auto-detect OCEL 2.0 output format by extension."""
    fp = file_path.lower()
    if fp.endswith(".jsonocel") or fp.endswith(".json"):
        write_ocel2_json(ocel, file_path, encoding=encoding)
    elif fp.endswith(".xmlocel") or fp.endswith(".xml"):
        write_ocel2_xml(ocel, file_path, encoding=encoding)
    elif fp.endswith(".sqlite"):
        write_ocel2_sqlite(ocel, file_path, encoding=encoding)
    else:
        raise ValueError(f"Unsupported OCEL 2.0 output format: {file_path}")


__all__ = [
    "write_xes", "write_csv", "write_pnml", "write_ptml", "write_dfg", "write_bpmn",
    "write_ocel", "write_ocel_csv", "write_ocel_json", "write_ocel_xml", "write_ocel_sqlite",
    "write_ocel2", "write_ocel2_json", "write_ocel2_xml", "write_ocel2_sqlite",
]
