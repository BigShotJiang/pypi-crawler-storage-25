"""pl4pm.write.xes - XES event log writer."""

from __future__ import annotations

from datetime import datetime

import polars as pl

from pl4pm.constants import ACTIVITY_KEY, CASE_ID_KEY, TIMESTAMP_KEY


_XML_TRANSLATE = str.maketrans(
    {
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
    }
)


def write_xes(
    log: pl.LazyFrame,
    file_path: str,
    case_id_key: str = CASE_ID_KEY,
    encoding: str = "utf-8",
) -> None:
    """Write a Polars DataFrame as a .xes file."""
    is_lazy = isinstance(log, pl.LazyFrame)
    source = log if is_lazy else log.lazy()

    schema = source.collect_schema()
    if case_id_key not in schema:
        raise ValueError(f"Missing case id column: {case_id_key}")

    all_cols = list(schema.names())
    trace_cols = [col for col in all_cols if col.startswith("case:") and col != case_id_key]
    event_cols = [col for col in all_cols if col != case_id_key and col not in trace_cols]

    sort_cols = [case_id_key]
    if TIMESTAMP_KEY in all_cols:
        sort_cols.append(TIMESTAMP_KEY)
    if ACTIVITY_KEY in all_cols:
        sort_cols.append(ACTIVITY_KEY)

    prepared = (
        source
        .with_columns(_xes_text_expr(col, schema[col]).alias(col) for col in [case_id_key, *trace_cols, *event_cols])
        .select([case_id_key, *trace_cols, *event_cols])
        .sort(sort_cols, maintain_order=True)
        .collect()
    )

    meta_trace = [_xes_meta(col[5:], schema[col], "    ") for col in trace_cols]
    meta_event = [_xes_meta(col, schema[col], "      ") for col in event_cols]
    case_idx = 0
    trace_indexes = [prepared.columns.index(col) for col in trace_cols]
    event_indexes = [prepared.columns.index(col) for col in event_cols]

    with open(file_path, "w", encoding=encoding, newline="") as handle:
        write = handle.write
        write(f'<?xml version="1.0" encoding="{encoding}"?>\n')
        write('<log xes.version="2.0" xmlns="http://www.xes-standard.org/">\n')

        current_case = None
        first_in_case = False
        for row in prepared.iter_rows(named=False, buffer_size=4096):
            case_value = row[case_idx]
            if case_value != current_case:
                if current_case is not None:
                    write("  </trace>\n")
                current_case = case_value
                first_in_case = True
                write("  <trace>\n")
                write(f'    <string key="concept:name" value="{_esc(case_value)}"/>\n')

            if first_in_case:
                for meta, idx in zip(meta_trace, trace_indexes):
                    value = row[idx]
                    if value is not None:
                        write(meta.render(value))
                first_in_case = False

            write("    <event>\n")
            for meta, idx in zip(meta_event, event_indexes):
                value = row[idx]
                if value is not None:
                    write(meta.render(value))
            write("    </event>\n")

        if current_case is not None:
            write("  </trace>\n")
        write("</log>\n")


class _XesMeta:
    __slots__ = ("prefix", "key", "tag", "needs_escape")

    def __init__(self, key: str, tag: str, prefix: str, needs_escape: bool) -> None:
        self.prefix = prefix
        self.key = _esc(key)
        self.tag = tag
        self.needs_escape = needs_escape

    def render(self, value: str) -> str:
        if self.needs_escape:
            value = _esc(value)
        return f'{self.prefix}<{self.tag} key="{self.key}" value="{value}"/>\n'


def _xes_meta(key: str, dtype: pl.DataType, prefix: str) -> _XesMeta:
    kind = _xes_kind(dtype)
    tag = {
        "date": "date",
        "boolean": "boolean",
        "int": "int",
        "float": "float",
        "string": "string",
    }[kind]
    return _XesMeta(key=key, tag=tag, prefix=prefix, needs_escape=(kind == "string"))


def _xes_kind(dtype: pl.DataType) -> str:
    if isinstance(dtype, (pl.Datetime, pl.Date, pl.Time)):
        return "date"
    if dtype == pl.Boolean:
        return "boolean"
    if dtype in (pl.Int8, pl.Int16, pl.Int32, pl.Int64, pl.UInt8, pl.UInt16, pl.UInt32, pl.UInt64):
        return "int"
    if dtype in (pl.Float32, pl.Float64):
        return "float"
    return "string"


def _xes_text_expr(col: str, dtype: pl.DataType) -> pl.Expr:
    expr = pl.col(col)
    kind = _xes_kind(dtype)
    if kind == "date":
        return expr.dt.strftime("%Y-%m-%dT%H:%M:%S%.f")
    if kind == "boolean":
        return (
            pl.when(expr.is_null())
            .then(pl.lit(None, dtype=pl.String))
            .when(expr)
            .then(pl.lit("true"))
            .otherwise(pl.lit("false"))
        )
    return expr.cast(pl.String)


def _write_attr(f, key: str, value, indent: int) -> None:
    """Write a single XES attribute element."""
    prefix = " " * indent
    if value is None:
        return
    if isinstance(value, datetime):
        f.write(f'{prefix}<date key="{_esc(key)}" value="{value.isoformat()}"/>\n')
    elif isinstance(value, bool):
        f.write(f'{prefix}<boolean key="{_esc(key)}" value="{str(value).lower()}"/>\n')
    elif isinstance(value, int):
        f.write(f'{prefix}<int key="{_esc(key)}" value="{value}"/>\n')
    elif isinstance(value, float):
        f.write(f'{prefix}<float key="{_esc(key)}" value="{value}"/>\n')
    else:
        f.write(f'{prefix}<string key="{_esc(key)}" value="{_esc(str(value))}"/>\n')


def _esc(s: str) -> str:
    """Escape XML special characters."""
    return str(s).translate(_XML_TRANSLATE)
