"""pl4pm.write.ocel.csv — OCEL CSV writer."""

from __future__ import annotations

from pl4pm.objects.ocel import OCEL


def write_ocel_csv(
    ocel: OCEL,
    file_path: str,
    objects_path: str | None = None,
    encoding: str = "utf-8",
) -> None:
    """Write OCEL to CSV (events file + optional objects file)."""
    ocel.events.write_csv(file_path)
    if objects_path:
        ocel.objects.write_csv(objects_path)
