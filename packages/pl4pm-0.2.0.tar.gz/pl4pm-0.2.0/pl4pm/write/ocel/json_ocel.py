"""pl4pm.write.ocel.json_ocel — OCEL JSON writer (1.0 and 2.0)."""

from __future__ import annotations

import json
from datetime import datetime
from typing import Any

from pl4pm.objects.ocel import OCEL


def _serialize(obj: Any) -> Any:
    if isinstance(obj, datetime):
        return obj.isoformat()
    return obj


def write_ocel_json(
    ocel: OCEL,
    file_path: str,
    encoding: str = "utf-8",
) -> None:
    """Write OCEL 1.0 to JSON-OCEL format."""
    out: dict[str, Any] = {"ocel:global-log": ocel.globals}

    # Events
    events_dict: dict[str, Any] = {}
    rel_grouped = {}
    for row in ocel.relations.iter_rows(named=True):
        eid = row[OCEL.EVENT_ID]
        rel_grouped.setdefault(eid, []).append(row[OCEL.OBJECT_ID])

    ev_cols = [c for c in ocel.events.columns
               if c not in {OCEL.EVENT_ID, OCEL.EVENT_ACTIVITY, OCEL.EVENT_TIMESTAMP}]
    for row in ocel.events.iter_rows(named=True):
        eid = row[OCEL.EVENT_ID]
        events_dict[eid] = {
            "ocel:activity": row.get(OCEL.EVENT_ACTIVITY, ""),
            "ocel:timestamp": _serialize(row.get(OCEL.EVENT_TIMESTAMP)),
            "ocel:omap": rel_grouped.get(eid, []),
            "ocel:vmap": {c: _serialize(row[c]) for c in ev_cols if row[c] is not None},
        }
    out["ocel:events"] = events_dict

    # Objects
    objects_dict: dict[str, Any] = {}
    obj_cols = [c for c in ocel.objects.columns
                if c not in {OCEL.OBJECT_ID, OCEL.OBJECT_TYPE}]
    for row in ocel.objects.iter_rows(named=True):
        oid = row[OCEL.OBJECT_ID]
        objects_dict[oid] = {
            "ocel:type": row.get(OCEL.OBJECT_TYPE, ""),
            "ocel:ovmap": {c: _serialize(row[c]) for c in obj_cols if row[c] is not None},
        }
    out["ocel:objects"] = objects_dict

    with open(file_path, "w", encoding=encoding) as f:
        json.dump(out, f, indent=2, default=str)


def write_ocel2_json(
    ocel: OCEL,
    file_path: str,
    encoding: str = "utf-8",
) -> None:
    """Write OCEL 2.0 to JSON format."""
    out: dict[str, Any] = {}

    # Events
    events_list = []
    rel_grouped: dict[str, list] = {}
    for row in ocel.relations.iter_rows(named=True):
        eid = row[OCEL.EVENT_ID]
        rel_grouped.setdefault(eid, []).append({
            "objectId": row[OCEL.OBJECT_ID],
            "qualifier": row.get(OCEL.QUALIFIER, ""),
        })

    ev_cols = [c for c in ocel.events.columns
               if c not in {OCEL.EVENT_ID, OCEL.EVENT_ACTIVITY, OCEL.EVENT_TIMESTAMP}]
    for row in ocel.events.iter_rows(named=True):
        eid = row[OCEL.EVENT_ID]
        ev = {
            "id": eid,
            "type": row.get(OCEL.EVENT_ACTIVITY, ""),
            "time": _serialize(row.get(OCEL.EVENT_TIMESTAMP)),
            "attributes": [{"name": c, "value": _serialize(row[c])}
                           for c in ev_cols if row[c] is not None],
            "relationships": rel_grouped.get(eid, []),
        }
        events_list.append(ev)
    out["events"] = events_list

    # Objects
    objects_list = []
    o2o_grouped: dict[str, list] = {}
    for row in ocel.o2o.iter_rows(named=True):
        src = row["ocel:oid_src"]
        o2o_grouped.setdefault(src, []).append({
            "objectId": row["ocel:oid_tgt"],
            "qualifier": row.get(OCEL.QUALIFIER, ""),
        })

    obj_cols = [c for c in ocel.objects.columns
                if c not in {OCEL.OBJECT_ID, OCEL.OBJECT_TYPE}]
    for row in ocel.objects.iter_rows(named=True):
        oid = row[OCEL.OBJECT_ID]
        obj = {
            "id": oid,
            "type": row.get(OCEL.OBJECT_TYPE, ""),
            "attributes": [{"name": c, "value": _serialize(row[c])}
                           for c in obj_cols if row[c] is not None],
            "relationships": o2o_grouped.get(oid, []),
        }
        objects_list.append(obj)
    out["objects"] = objects_list

    with open(file_path, "w", encoding=encoding) as f:
        json.dump(out, f, indent=2, default=str)
