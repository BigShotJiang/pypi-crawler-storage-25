"""pl4pm.write.ocel.sqlite_ocel — OCEL SQLite writer (1.0 and 2.0)."""

from __future__ import annotations

import sqlite3

import polars as pl

from pl4pm.objects.ocel import OCEL


def _df_to_sqlite(conn: sqlite3.Connection, table_name: str, df) -> None:
    """Write a Polars DataFrame to a SQLite table."""
    if df.height == 0:
        return
    normalized = df.select(
        [
            (
                pl.col(col).dt.strftime("%Y-%m-%dT%H:%M:%S%.f")
                if isinstance(df.schema[col], (pl.Datetime, pl.Date, pl.Time))
                else pl.col(col).cast(pl.Utf8)
            ).alias(col)
            for col in df.columns
        ]
    )
    cols = normalized.columns
    placeholders = ", ".join(["?"] * len(cols))
    col_defs = ", ".join([f'"{c}" TEXT' for c in cols])
    conn.execute(f"CREATE TABLE IF NOT EXISTS [{table_name}] ({col_defs})")
    rows = normalized.iter_rows(named=False, buffer_size=4096)
    conn.executemany(
        f"INSERT INTO [{table_name}] VALUES ({placeholders})", rows
    )


def write_ocel_sqlite(
    ocel: OCEL,
    file_path: str,
    encoding: str = "utf-8",
) -> None:
    """Write OCEL 1.0 to a SQLite database."""
    conn = sqlite3.connect(file_path)
    try:
        _df_to_sqlite(conn, "event", ocel.events)
        _df_to_sqlite(conn, "object", ocel.objects)
        _df_to_sqlite(conn, "event_object", ocel.relations)
        conn.commit()
    finally:
        conn.close()


def write_ocel2_sqlite(
    ocel: OCEL,
    file_path: str,
    encoding: str = "utf-8",
) -> None:
    """Write OCEL 2.0 to a SQLite database."""
    conn = sqlite3.connect(file_path)
    try:
        _df_to_sqlite(conn, "event", ocel.events)
        _df_to_sqlite(conn, "object", ocel.objects)
        _df_to_sqlite(conn, "event_object", ocel.relations)
        _df_to_sqlite(conn, "object_object", ocel.o2o)
        if ocel.object_changes.height > 0:
            _df_to_sqlite(conn, "object_change", ocel.object_changes)
        conn.commit()
    finally:
        conn.close()
