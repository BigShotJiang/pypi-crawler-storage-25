"""pl4pm.write.ocel.xml_ocel — OCEL XML writer (1.0 and 2.0)."""

from __future__ import annotations

from datetime import datetime

from lxml import etree  # type: ignore[import-untyped]

from pl4pm.objects.ocel import OCEL


def write_ocel_xml(
    ocel: OCEL,
    file_path: str,
    encoding: str = "utf-8",
) -> None:
    """Write OCEL 1.0 to XML-OCEL format."""
    root = etree.Element("log")

    # Events
    events_el = etree.SubElement(root, "events")
    rel_grouped: dict[str, list[str]] = {}
    for row in ocel.relations.iter_rows(named=True):
        rel_grouped.setdefault(row[OCEL.EVENT_ID], []).append(row[OCEL.OBJECT_ID])

    ev_cols = [c for c in ocel.events.columns
               if c not in {OCEL.EVENT_ID, OCEL.EVENT_ACTIVITY, OCEL.EVENT_TIMESTAMP}]

    for row in ocel.events.iter_rows(named=True):
        ev = etree.SubElement(events_el, "event")
        etree.SubElement(ev, "string", key="ocel:eid", value=str(row[OCEL.EVENT_ID]))
        etree.SubElement(ev, "string", key="ocel:activity",
                         value=str(row.get(OCEL.EVENT_ACTIVITY, "")))
        ts = row.get(OCEL.EVENT_TIMESTAMP)
        ts_str = ts.isoformat() if isinstance(ts, datetime) else str(ts or "")
        etree.SubElement(ev, "date", key="ocel:timestamp", value=ts_str)

        # vmap
        for c in ev_cols:
            if row[c] is not None:
                etree.SubElement(ev, "string", key=c, value=str(row[c]))

        # omap
        omap_el = etree.SubElement(ev, "omap")
        for oid in rel_grouped.get(row[OCEL.EVENT_ID], []):
            etree.SubElement(omap_el, "object-id", value=str(oid))

    # Objects
    objects_el = etree.SubElement(root, "objects")
    obj_cols = [c for c in ocel.objects.columns
                if c not in {OCEL.OBJECT_ID, OCEL.OBJECT_TYPE}]

    for row in ocel.objects.iter_rows(named=True):
        obj = etree.SubElement(objects_el, "object")
        etree.SubElement(obj, "string", key="ocel:oid", value=str(row[OCEL.OBJECT_ID]))
        etree.SubElement(obj, "string", key="ocel:type",
                         value=str(row.get(OCEL.OBJECT_TYPE, "")))
        ovmap = etree.SubElement(obj, "ovmap")
        for c in obj_cols:
            if row[c] is not None:
                etree.SubElement(ovmap, "string", key=c, value=str(row[c]))

    tree = etree.ElementTree(root)
    tree.write(file_path, pretty_print=True, xml_declaration=True, encoding=encoding)


def write_ocel2_xml(
    ocel: OCEL,
    file_path: str,
    encoding: str = "utf-8",
) -> None:
    """Write OCEL 2.0 to XML format."""
    root = etree.Element("log")

    event_type_attrs: dict[str, set[str]] = {}
    for row in ocel.events.iter_rows(named=True):
        etype = str(row.get(OCEL.EVENT_ACTIVITY, ""))
        event_type_attrs.setdefault(etype, set())
        for col in ocel.events.columns:
            if col not in {OCEL.EVENT_ID, OCEL.EVENT_ACTIVITY, OCEL.EVENT_TIMESTAMP} and row[col] is not None:
                event_type_attrs[etype].add(col)

    object_type_attrs: dict[str, set[str]] = {}
    for row in ocel.objects.iter_rows(named=True):
        otype = str(row.get(OCEL.OBJECT_TYPE, ""))
        object_type_attrs.setdefault(otype, set())
        for col in ocel.objects.columns:
            if col not in {OCEL.OBJECT_ID, OCEL.OBJECT_TYPE} and row[col] is not None:
                object_type_attrs[otype].add(col)

    object_types_el = etree.SubElement(root, "object-types")
    for otype, attrs in sorted(object_type_attrs.items()):
        ot_el = etree.SubElement(object_types_el, "object-type", name=otype)
        attrs_el = etree.SubElement(ot_el, "attributes")
        for attr in sorted(attrs):
            etree.SubElement(attrs_el, "attribute", name=attr, type="string")

    event_types_el = etree.SubElement(root, "event-types")
    for etype, attrs in sorted(event_type_attrs.items()):
        et_el = etree.SubElement(event_types_el, "event-type", name=etype)
        attrs_el = etree.SubElement(et_el, "attributes")
        for attr in sorted(attrs):
            etree.SubElement(attrs_el, "attribute", name=attr, type="string")

    rel_by_event: dict[str, list[dict]] = {}
    for row in ocel.relations.iter_rows(named=True):
        rel_by_event.setdefault(str(row[OCEL.EVENT_ID]), []).append(row)

    o2o_by_source: dict[str, list[dict]] = {}
    for row in ocel.o2o.iter_rows(named=True):
        o2o_by_source.setdefault(str(row["ocel:oid_src"]), []).append(row)

    objects_el = etree.SubElement(root, "objects")
    for row in ocel.objects.iter_rows(named=True):
        obj = etree.SubElement(
            objects_el,
            "object",
            id=str(row[OCEL.OBJECT_ID]),
            type=str(row.get(OCEL.OBJECT_TYPE, "")),
        )
        attrs_el = etree.SubElement(obj, "attributes")
        obj_cols = [c for c in ocel.objects.columns if c not in {OCEL.OBJECT_ID, OCEL.OBJECT_TYPE}]
        for c in obj_cols:
            if row[c] is not None:
                attr_el = etree.SubElement(attrs_el, "attribute", name=c, time="1970-01-01T00:00:00Z")
                attr_el.text = str(row[c])
        rels = o2o_by_source.get(str(row[OCEL.OBJECT_ID]), [])
        if rels:
            rels_el = etree.SubElement(obj, "objects")
            for rel in rels:
                etree.SubElement(
                    rels_el,
                    "relationship",
                    **{
                        "object-id": str(rel["ocel:oid_tgt"]),
                        "qualifier": str(rel.get(OCEL.QUALIFIER, "")),
                    },
                )

    events_el = etree.SubElement(root, "events")
    ev_cols = [c for c in ocel.events.columns if c not in {OCEL.EVENT_ID, OCEL.EVENT_ACTIVITY, OCEL.EVENT_TIMESTAMP}]
    for row in ocel.events.iter_rows(named=True):
        ts = row.get(OCEL.EVENT_TIMESTAMP)
        ts_str = ts.isoformat() if isinstance(ts, datetime) else str(ts or "")
        ev = etree.SubElement(
            events_el,
            "event",
            id=str(row[OCEL.EVENT_ID]),
            type=str(row.get(OCEL.EVENT_ACTIVITY, "")),
            time=ts_str,
        )
        attrs_el = etree.SubElement(ev, "attributes")
        for c in ev_cols:
            if row[c] is not None:
                attr_el = etree.SubElement(attrs_el, "attribute", name=c)
                attr_el.text = str(row[c])
        rels_el = etree.SubElement(ev, "objects")
        for rel in rel_by_event.get(str(row[OCEL.EVENT_ID]), []):
            etree.SubElement(
                rels_el,
                "relationship",
                **{
                    "object-id": str(rel[OCEL.OBJECT_ID]),
                    "qualifier": str(rel.get(OCEL.QUALIFIER, "")),
                },
            )

    tree = etree.ElementTree(root)
    tree.write(file_path, pretty_print=True, xml_declaration=True, encoding=encoding)
