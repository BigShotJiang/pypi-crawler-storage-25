"""pl4pm.write.dfg — DFG text file writer."""

from __future__ import annotations

from typing import Dict, Tuple


def write_dfg(
    dfg: Dict[Tuple[str, str], int],
    start_activities: Dict[str, int],
    end_activities: Dict[str, int],
    file_path: str,
    encoding: str = "utf-8",
) -> None:
    """Write a DFG to a .dfg text file (pm4py-compatible format)."""
    # Collect all activity names
    activities: set[str] = set()
    for (a, b) in dfg:
        activities.add(a)
        activities.add(b)
    activities.update(start_activities.keys())
    activities.update(end_activities.keys())
    sorted_acts = sorted(activities)

    with open(file_path, "w", encoding=encoding) as f:
        # Activities
        f.write(f"{len(sorted_acts)}\n")
        for act in sorted_acts:
            f.write(f"{act}\n")

        # Start activities
        f.write(f"{len(start_activities)}\n")
        for act, freq in sorted(start_activities.items()):
            f.write(f"{freq} {act}\n")

        # End activities
        f.write(f"{len(end_activities)}\n")
        for act, freq in sorted(end_activities.items()):
            f.write(f"{freq} {act}\n")

        # Edges
        f.write(f"{len(dfg)}\n")
        for (src, tgt), freq in sorted(dfg.items()):
            f.write(f"{src}>{tgt}>{freq}\n")
