"""pl4pm.write.csv — CSV event log writer."""

from __future__ import annotations

import polars as pl


def write_csv(
    log: pl.LazyFrame,
    file_path: str,
    separator: str = ",",
) -> None:
    """Write a Polars event log to CSV."""
    df = log.collect() if isinstance(log, pl.LazyFrame) else log
    df.write_csv(file_path, separator=separator)
