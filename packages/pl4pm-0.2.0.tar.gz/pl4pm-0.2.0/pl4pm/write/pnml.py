"""pl4pm.write.pnml — PNML Petri net writer."""

from __future__ import annotations

from lxml import etree  # type: ignore[import-untyped]

from pl4pm.objects.petri_net import PetriNet, Marking


def write_pnml(
    petri_net: PetriNet,
    initial_marking: Marking,
    final_marking: Marking,
    file_path: str,
    encoding: str = "utf-8",
) -> None:
    """Write a Petri net to a .pnml file."""
    root = etree.Element("pnml")
    net_elem = etree.SubElement(root, "net", id=petri_net.name or "net0",
                                type="http://www.pnml.org/version-2009/grammar/pnmlcoremodel")
    page = etree.SubElement(net_elem, "page", id="page0")

    # Map objects to ids
    place_ids: dict[PetriNet.Place, str] = {}
    trans_ids: dict[PetriNet.Transition, str] = {}

    for i, place in enumerate(petri_net.places):
        pid = f"p{i}"
        place_ids[place] = pid
        p_elem = etree.SubElement(page, "place", id=pid)
        name_elem = etree.SubElement(p_elem, "name")
        text_elem = etree.SubElement(name_elem, "text")
        text_elem.text = place.name

        if place in initial_marking and initial_marking[place] > 0:
            im_elem = etree.SubElement(p_elem, "initialMarking")
            im_text = etree.SubElement(im_elem, "text")
            im_text.text = str(initial_marking[place])

    for i, trans in enumerate(petri_net.transitions):
        tid = trans.name or f"t{i}"
        trans_ids[trans] = tid
        t_elem = etree.SubElement(page, "transition", id=tid)
        name_elem = etree.SubElement(t_elem, "name")
        text_elem = etree.SubElement(name_elem, "text")
        text_elem.text = trans.label if trans.label else trans.name

        if trans.is_silent:
            ts_elem = etree.SubElement(
                t_elem, "toolspecific", tool="ProM", version="6.4",
                activity="$invisible$", localNodeID=tid)

    for i, arc in enumerate(petri_net.arcs):
        src_id = place_ids.get(arc.source) or trans_ids.get(arc.source, "")
        tgt_id = place_ids.get(arc.target) or trans_ids.get(arc.target, "")
        a_elem = etree.SubElement(page, "arc", id=f"a{i}",
                                  source=src_id, target=tgt_id)
        if arc.weight != 1:
            insc = etree.SubElement(a_elem, "inscription")
            insc_text = etree.SubElement(insc, "text")
            insc_text.text = str(arc.weight)

    # Final marking
    if final_marking:
        fm_container = etree.SubElement(net_elem, "finalmarkings")
        fm_marking = etree.SubElement(fm_container, "marking")
        for place, tokens in final_marking.items():
            if tokens > 0:
                fm_place = etree.SubElement(fm_marking, "place",
                                            idref=place_ids.get(place, ""))
                fm_text = etree.SubElement(fm_place, "text")
                fm_text.text = str(tokens)

    tree = etree.ElementTree(root)
    tree.write(file_path, pretty_print=True, xml_declaration=True,
               encoding=encoding)
