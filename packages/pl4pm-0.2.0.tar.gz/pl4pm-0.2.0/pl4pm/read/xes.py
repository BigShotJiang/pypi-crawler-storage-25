"""pl4pm.read.xes — XES event log parser (lxml iterparse → Polars)."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List

import polars as pl
from lxml import etree  # type: ignore[import-untyped]

from pl4pm.constants import (
    CASE_ID_KEY, ACTIVITY_KEY, TIMESTAMP_KEY,
    XES_TAG_TRACE, XES_TAG_EVENT,
    XES_TAG_STRING, XES_TAG_DATE, XES_TAG_INT, XES_TAG_FLOAT, XES_TAG_BOOLEAN,
)

_ATTR_TAGS = frozenset({XES_TAG_STRING, XES_TAG_DATE, XES_TAG_INT,
                        XES_TAG_FLOAT, XES_TAG_BOOLEAN})


def _parse_value(tag: str, raw: str) -> Any:
    """Convert a raw XES attribute value to its Python type."""
    if tag == XES_TAG_DATE:
        return raw  # Keep as string and let Polars vectorize parsing
    if tag == XES_TAG_INT:
        return int(raw)
    if tag == XES_TAG_FLOAT:
        return float(raw)
    if tag == XES_TAG_BOOLEAN:
        return raw.strip().lower() in ("true", "1", "yes")
    return raw  # string


def read_xes(
    file_path: str,
    return_lazy: bool = True,
    encoding: str = "utf-8",
) -> pl.LazyFrame:
    """Read a .xes file and return a Polars LazyFrame.

    Args:
        file_path: Path to the XES file.
        encoding: File encoding.

    Returns:
        ``pl.LazyFrame`` with one row per event.
    """
    rows: List[Dict[str, Any]] = []
    trace_attrs: Dict[str, Any] = {}
    in_trace = False
    in_event = False
    event_attrs: Dict[str, Any] = {}

    _ = return_lazy

    context = etree.iterparse(
        file_path, events=("start", "end"), encoding=encoding
    )

    for action, elem in context:
        tag = etree.QName(elem).localname if isinstance(elem.tag, str) else elem.tag

        if action == "start":
            if tag == XES_TAG_TRACE:
                in_trace = True
                trace_attrs.clear()
            elif tag == XES_TAG_EVENT:
                in_event = True
                event_attrs.clear()
            elif in_trace and tag in _ATTR_TAGS:
                key = elem.get("key", "")
                value = elem.get("value", "")
                parsed = _parse_value(tag, value)
                if in_event:
                    event_attrs[key] = parsed
                else:
                    # Trace-level attribute → prefix with "case:"
                    if not key.startswith("case:"):
                        key = f"case:{key}"
                    trace_attrs[key] = parsed

        elif action == "end":
            if tag == XES_TAG_EVENT and in_event:
                row = trace_attrs.copy()
                row.update(event_attrs)
                rows.append(row)
                in_event = False
                event_attrs.clear()
            elif tag == XES_TAG_TRACE:
                in_trace = False
                trace_attrs.clear()
            # free memory
            elem.clear()
            while elem.getprevious() is not None:
                parent = elem.getparent()
                if parent is not None:
                    del parent[0]

    if not rows:
        df = pl.DataFrame(schema={
            CASE_ID_KEY: pl.Utf8,
            ACTIVITY_KEY: pl.Utf8,
            TIMESTAMP_KEY: pl.Datetime,
        })
    else:
        df = pl.DataFrame(rows)
        # ensure timestamp columns are Datetime
        for col_name in df.columns:
            if "timestamp" in col_name.lower() or "time:" in col_name.lower():
                if df[col_name].dtype != pl.Datetime:
                    try:
                        # Vectorized datetime parsing with Polars
                        df = df.with_columns(
                            pl.col(col_name)
                            .str.replace(r"\\+00:00$", "Z")
                            .str.to_datetime(strict=False, time_unit="ms")
                            .alias(col_name)
                        )
                    except Exception:
                        pass

    lf = df.lazy()
    if CASE_ID_KEY in df.columns and TIMESTAMP_KEY in df.columns:
        lf = lf.sort([CASE_ID_KEY, TIMESTAMP_KEY])
    return lf
