"""pl4pm.read.parquet — Parquet file reader."""

from __future__ import annotations

from typing import Optional

import polars as pl

from pl4pm.constants import CASE_ID_KEY, TIMESTAMP_KEY


def read_parquet(
    file_path: str,
    return_pl_lazyframe: bool = True,
    n_rows: Optional[int] = None,
    columns: Optional[list[str]] = None,
    use_pyarrow: bool = False,
    hive_partitioning: bool = True,
) -> pl.LazyFrame:
    """Read an event log from Parquet file(s).

    Supports single files and partitioned folders via ``hive_partitioning``.

    Args:
        file_path: Path to ``.parquet`` file or partitioned directory.
        return_pl_lazyframe: If ``True`` returns a ``pl.LazyFrame``
            (backed by ``pl.scan_parquet``).
        n_rows: Optional row limit (eager mode only).
        columns: Subset of columns to read.
        use_pyarrow: Use PyArrow backend (passed to Polars).
        hive_partitioning: Enable Hive-style partition discovery.

    Returns:
        ``pl.LazyFrame``.
    """
    _ = return_pl_lazyframe
    if n_rows is not None or use_pyarrow:
        # LazyFrame-only API: eager-only options are intentionally ignored.
        # Keeping them as accepted parameters avoids noisy breakage in callers.
        pass
    lf = pl.scan_parquet(
        file_path,
        hive_partitioning=hive_partitioning,
    )
    if columns:
        lf = lf.select(columns)
    schema_names = lf.collect_schema().names()
    if CASE_ID_KEY in schema_names and TIMESTAMP_KEY in schema_names:
        lf = lf.sort([CASE_ID_KEY, TIMESTAMP_KEY])
    return lf
