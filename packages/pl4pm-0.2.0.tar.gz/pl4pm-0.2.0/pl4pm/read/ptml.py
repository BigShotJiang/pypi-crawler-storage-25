"""pl4pm.read.ptml — Process tree (.ptml) reader."""

from __future__ import annotations

from lxml import etree  # type: ignore[import-untyped]

from pl4pm.objects.process_tree import ProcessTree, Operator

_OP_MAP = {
    "sequence": Operator.SEQUENCE,
    "xor": Operator.XOR,
    "xorloop": Operator.LOOP,
    "and": Operator.PARALLEL,
    "or": Operator.OR,
    "loop": Operator.LOOP,
}


def _strip_ns(tag: str) -> str:
    if "}" in tag:
        return tag.split("}", 1)[1]
    return tag


def _parse_node(elem, parent: ProcessTree | None = None) -> ProcessTree:
    """Recursively parse a process tree node from XML."""
    tag = _strip_ns(elem.tag)

    if tag == "automaticTask" or (tag == "manualTask" and not elem.get("name")):
        node = ProcessTree(parent=parent)  # tau leaf
        return node

    if tag in ("manualTask", "parentsNode") and "name" in elem.attrib:
        label = elem.get("name", "")
        operator_str = elem.get("operator", "")

        if operator_str and operator_str.lower() in _OP_MAP:
            op = _OP_MAP[operator_str.lower()]
            node = ProcessTree(operator=op, parent=parent)
        elif not operator_str and label:
            node = ProcessTree(label=label, parent=parent)
            return node
        else:
            node = ProcessTree(label=label if label else None, parent=parent)
            return node
    else:
        # Generic node element
        name = elem.get("name", "")
        operator_str = elem.get("operator", "")
        if operator_str and operator_str.lower() in _OP_MAP:
            node = ProcessTree(operator=_OP_MAP[operator_str.lower()], parent=parent)
        elif name:
            node = ProcessTree(label=name, parent=parent)
            return node
        else:
            node = ProcessTree(parent=parent)
            return node

    # parse children
    for child_elem in elem:
        child_tag = _strip_ns(child_elem.tag)
        if child_tag in ("automaticTask", "manualTask", "parentsNode") or child_elem.get("operator"):
            child = _parse_node(child_elem, parent=node)
            node.children.append(child)

    return node


def read_ptml(
    file_path: str,
    encoding: str = "utf-8",
) -> ProcessTree:
    """Read a process tree from a .ptml file.

    Returns:
        ProcessTree root node.
    """
    tree = etree.parse(file_path)
    root = tree.getroot()

    # The root element might be <ptml> wrapping the actual tree
    tag = _strip_ns(root.tag)
    if tag == "ptml":
        root = root[0]  # first child is the tree root

    return _parse_node(root)
