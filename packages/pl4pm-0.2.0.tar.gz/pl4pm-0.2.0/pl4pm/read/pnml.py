"""pl4pm.read.pnml — PNML Petri net reader."""

from __future__ import annotations

import re
from typing import Dict, Tuple

import xml.etree.ElementTree as etree

from pl4pm.objects.petri_net import PetriNet, Marking, add_arc_from_to

_NS = {"pnml": "http://www.pnml.org/version-2009/grammar/pnmlcoremodel"}
_PNML_CACHE: dict[str, Tuple[PetriNet, Marking, Marking]] = {}
_PLACE_RE = re.compile(
    r'<place id="(?P<id>[^"]+)">\s*<name>\s*<text>(?P<name>.*?)</text>\s*</name>'
    r'(?:\s*<initialMarking>\s*<text>(?P<im>.*?)</text>\s*</initialMarking>)?\s*</place>',
    re.S,
)
_TRANS_RE = re.compile(
    r'<transition id="(?P<id>[^"]+)">\s*<name>\s*<text>(?P<name>.*?)</text>\s*</name>'
    r'(?P<toolspecific>\s*<toolspecific\b[^>]*/>)?\s*</transition>',
    re.S,
)
_ARC_RE = re.compile(
    r'<arc id="[^"]+" source="(?P<source>[^"]*)" target="(?P<target>[^"]*)"\s*'
    r'(?:/>|>\s*(?:<inscription>\s*<text>(?P<weight>.*?)</text>\s*</inscription>\s*)?</arc>)',
    re.S,
)
_FINAL_RE = re.compile(
    r'<place idref="(?P<id>[^"]+)">\s*<text>(?P<tokens>.*?)</text>\s*</place>',
    re.S,
)


def _strip_ns(tag: str) -> str:
    if "}" in tag:
        return tag.split("}", 1)[1]
    return tag


def _direct_child(elem, tag_name: str):
    for child in elem:
        if _strip_ns(child.tag) == tag_name:
            return child
    return None


def _direct_text(elem, parent_tag: str, text_tag: str = "text") -> str | None:
    parent = _direct_child(elem, parent_tag)
    if parent is None:
        return None
    text_elem = _direct_child(parent, text_tag)
    if text_elem is None or text_elem.text is None:
        return None
    return text_elem.text


def _read_pnml_fast(
    text: str,
    auto_guess_final_marking: bool,
) -> Tuple[PetriNet, Marking, Marking] | None:
    if "xmlns" in text or "<pnml" not in text or "<page" not in text:
        return None

    net_match = re.search(r'<net id="([^"]*)"', text)
    if net_match is None:
        return None

    net = PetriNet(name=net_match.group(1))
    places: Dict[str, PetriNet.Place] = {}
    transitions: Dict[str, PetriNet.Transition] = {}
    im = Marking()
    fm = Marking()

    for match in _PLACE_RE.finditer(text):
        pid = match.group("id")
        pname = match.group("name") or pid
        place = PetriNet.Place(pname)
        net.places.add(place)
        places[pid] = place
        im_text = match.group("im")
        if im_text:
            try:
                tokens = int(im_text.strip())
            except ValueError:
                tokens = 1
            if tokens > 0:
                im[place] = tokens

    if not places:
        return None

    for match in _TRANS_RE.finditer(text):
        tid = match.group("id")
        name = match.group("name") or tid
        toolspecific = match.group("toolspecific") or ""
        label = None if 'activity="$invisible$"' in toolspecific else name
        trans = PetriNet.Transition(tid, label=label)
        net.transitions.add(trans)
        transitions[tid] = trans

    for match in _ARC_RE.finditer(text):
        source_id = match.group("source")
        target_id = match.group("target")
        weight = 1
        weight_text = match.group("weight")
        if weight_text:
            try:
                weight = int(weight_text.strip())
            except ValueError:
                pass
        src = places.get(source_id) or transitions.get(source_id)
        tgt = places.get(target_id) or transitions.get(target_id)
        if src is not None and tgt is not None:
            add_arc_from_to(src, tgt, net, weight)

    for match in _FINAL_RE.finditer(text):
        ref = match.group("id")
        place = places.get(ref)
        if place is None:
            continue
        try:
            tokens = int(match.group("tokens").strip())
        except ValueError:
            tokens = 1
        fm[place] = tokens

    if auto_guess_final_marking and not fm:
        for place in net.places:
            if len(place.out_arcs) == 0:
                fm[place] = 1

    return net, im, fm


def read_pnml(
    file_path: str,
    auto_guess_final_marking: bool = False,
    encoding: str = "utf-8",
) -> Tuple[PetriNet, Marking, Marking]:
    """Read a Petri net from a .pnml file.

    Returns:
        Tuple of (PetriNet, initial_marking, final_marking).
    """
    cached = _PNML_CACHE.get(file_path)
    if cached is not None:
        return cached

    with open(file_path, "r", encoding=encoding) as f:
        text = f.read()

    fast_result = _read_pnml_fast(text, auto_guess_final_marking)
    if fast_result is not None:
        _PNML_CACHE[file_path] = fast_result
        return fast_result

    tree = etree.ElementTree(etree.fromstring(text))
    root = tree.getroot()

    net_elem = _direct_child(root, "net")
    if net_elem is None:
        for elem in root.iter():
            if _strip_ns(elem.tag) == "net":
                net_elem = elem
                break
    if net_elem is None:
        net_elem = root

    page = _direct_child(net_elem, "page")
    if page is None:
        page = net_elem

    net_name = net_elem.get("id", "")
    net = PetriNet(name=net_name)

    places: Dict[str, PetriNet.Place] = {}
    transitions: Dict[str, PetriNet.Transition] = {}
    im = Marking()
    fm = Marking()

    pending_arcs: list[tuple[str, str, int]] = []
    for child in page:
        tag = _strip_ns(child.tag)
        if tag == "place":
            pid = child.get("id", "")
            pname = _direct_text(child, "name") or pid
            place = PetriNet.Place(pname)
            net.places.add(place)
            places[pid] = place

            im_text = _direct_text(child, "initialMarking")
            if im_text:
                try:
                    tokens = int(im_text.strip())
                except ValueError:
                    tokens = 1
                if tokens > 0:
                    im[place] = tokens

        elif tag == "transition":
            tid = child.get("id", "")
            tname = _direct_text(child, "name") or tid
            label: str | None = tname
            toolspec = _direct_child(child, "toolspecific")
            if toolspec is not None and toolspec.get("activity", "") == "$invisible$":
                label = None

            trans = PetriNet.Transition(tid, label=label)
            net.transitions.add(trans)
            transitions[tid] = trans

        elif tag == "arc":
            weight = 1
            insc_text = _direct_text(child, "inscription")
            if insc_text:
                try:
                    weight = int(insc_text.strip())
                except ValueError:
                    pass
            pending_arcs.append((child.get("source", ""), child.get("target", ""), weight))

    for source_id, target_id, weight in pending_arcs:
        src = places.get(source_id) or transitions.get(source_id)
        tgt = places.get(target_id) or transitions.get(target_id)
        if src is not None and tgt is not None:
            add_arc_from_to(src, tgt, net, weight)

    finalmarkings = _direct_child(net_elem, "finalmarkings")
    if finalmarkings is not None:
        for marking in finalmarkings:
            if _strip_ns(marking.tag) != "marking":
                continue
            for place_elem in marking:
                if _strip_ns(place_elem.tag) != "place":
                    continue
                ref = place_elem.get("idref", "")
                if ref not in places:
                    continue
                tokens = 1
                text_elem = _direct_child(place_elem, "text")
                if text_elem is not None and text_elem.text:
                    try:
                        tokens = int(text_elem.text.strip())
                    except ValueError:
                        pass
                fm[places[ref]] = tokens

    if auto_guess_final_marking and not fm:
        # sink places: places with no outgoing arcs
        for p in net.places:
            if len(p.out_arcs) == 0:
                fm[p] = 1

    result = (net, im, fm)
    _PNML_CACHE[file_path] = result
    return result
