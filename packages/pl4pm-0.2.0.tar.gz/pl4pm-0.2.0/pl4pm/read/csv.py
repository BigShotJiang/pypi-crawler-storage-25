"""pl4pm.read.csv — CSV event log reader via Polars LazyFrame."""

from __future__ import annotations

from typing import Optional

import polars as pl

from pl4pm.constants import CASE_ID_KEY, ACTIVITY_KEY, TIMESTAMP_KEY


def read_csv(
    file_path: str,
    separator: str = ",",
    case_id_col: Optional[str] = None,
    activity_col: Optional[str] = None,
    timestamp_col: Optional[str] = None,
    return_lazy: bool = True,
    **kwargs,
) -> pl.LazyFrame:
    """Read a CSV event log into a Polars LazyFrame.

    Optionally renames columns to standard XES keys.
    """
    _ = return_lazy
    lf = pl.scan_csv(file_path, separator=separator, **kwargs)

    rename_map: dict[str, str] = {}
    if case_id_col and case_id_col != CASE_ID_KEY:
        rename_map[case_id_col] = CASE_ID_KEY
    if activity_col and activity_col != ACTIVITY_KEY:
        rename_map[activity_col] = ACTIVITY_KEY
    if timestamp_col and timestamp_col != TIMESTAMP_KEY:
        rename_map[timestamp_col] = TIMESTAMP_KEY

    if rename_map:
        lf = lf.rename(rename_map)

    # try to cast timestamp column
    schema = lf.collect_schema()
    if TIMESTAMP_KEY in schema.names():
        if schema[TIMESTAMP_KEY] == pl.Utf8:
            lf = lf.with_columns(
                pl.col(TIMESTAMP_KEY).str.to_datetime().alias(TIMESTAMP_KEY)
            )
    if CASE_ID_KEY in schema.names() and TIMESTAMP_KEY in schema.names():
        lf = lf.sort([CASE_ID_KEY, TIMESTAMP_KEY])

    return lf


def format_dataframe(
    df: pl.LazyFrame,
    case_id_column: str = CASE_ID_KEY,
    activity_column: str = ACTIVITY_KEY,
    timestamp_column: str = TIMESTAMP_KEY,
) -> pl.LazyFrame:
    """Rename columns to standard XES names and sort by case + timestamp."""
    rename_map: dict[str, str] = {}
    if case_id_column != CASE_ID_KEY:
        rename_map[case_id_column] = CASE_ID_KEY
    if activity_column != ACTIVITY_KEY:
        rename_map[activity_column] = ACTIVITY_KEY
    if timestamp_column != TIMESTAMP_KEY:
        rename_map[timestamp_column] = TIMESTAMP_KEY

    if rename_map:
        df = df.rename(rename_map)

    return df.sort([CASE_ID_KEY, TIMESTAMP_KEY])
