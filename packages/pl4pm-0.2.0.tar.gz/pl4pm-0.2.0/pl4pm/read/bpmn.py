"""pl4pm.read.bpmn — BPMN 2.0 XML reader."""

from __future__ import annotations

from typing import Dict

from lxml import etree  # type: ignore[import-untyped]

from pl4pm.objects.bpmn import BPMN

_BPMN_NS = "http://www.omg.org/spec/BPMN/20100524/MODEL"

_NODE_TYPE_MAP = {
    "task": BPMN.Task,
    "sendTask": BPMN.Task,
    "receiveTask": BPMN.Task,
    "userTask": BPMN.Task,
    "serviceTask": BPMN.Task,
    "scriptTask": BPMN.Task,
    "manualTask": BPMN.Task,
    "businessRuleTask": BPMN.Task,
    "subProcess": BPMN.Task,
    "startEvent": BPMN.StartEvent,
    "endEvent": BPMN.EndEvent,
    "exclusiveGateway": BPMN.ExclusiveGateway,
    "parallelGateway": BPMN.ParallelGateway,
    "inclusiveGateway": BPMN.InclusiveGateway,
    "intermediateCatchEvent": BPMN.Task,
    "intermediateThrowEvent": BPMN.Task,
}


def _strip_ns(tag: str) -> str:
    if "}" in tag:
        return tag.split("}", 1)[1]
    return tag


def read_bpmn(
    file_path: str,
    encoding: str = "utf-8",
) -> BPMN:
    """Read a BPMN model from a .bpmn XML file.

    Returns:
        BPMN graph object.
    """
    tree = etree.parse(file_path)
    root = tree.getroot()

    bpmn = BPMN()
    nodes_by_id: Dict[str, BPMN.Node] = {}

    # find all processes
    for process_elem in root.iter():
        tag = _strip_ns(process_elem.tag)
        if tag != "process":
            continue

        process_id = process_elem.get("id", "")

        for child in process_elem:
            child_tag = _strip_ns(child.tag)

            # Nodes
            if child_tag in _NODE_TYPE_MAP:
                cls = _NODE_TYPE_MAP[child_tag]
                node_id = child.get("id", "")
                node_name = child.get("name", "")
                node = cls(id=node_id, name=node_name)
                node.process = process_id
                bpmn.add_node(node)
                nodes_by_id[node_id] = node

        # Sequence flows (second pass)
        for child in process_elem:
            child_tag = _strip_ns(child.tag)
            if child_tag == "sequenceFlow":
                flow_id = child.get("id", "")
                source_ref = child.get("sourceRef", "")
                target_ref = child.get("targetRef", "")
                flow_name = child.get("name", "")

                src = nodes_by_id.get(source_ref)
                tgt = nodes_by_id.get(target_ref)
                if src is not None and tgt is not None:
                    flow = BPMN.Flow(source=src, target=tgt, id=flow_id, name=flow_name)
                    bpmn.add_flow(flow)

    # Try to read layout from BPMNDiagram
    for shape_elem in root.iter():
        tag = _strip_ns(shape_elem.tag)
        if tag == "BPMNShape":
            ref = shape_elem.get("bpmnElement", "")
            node = nodes_by_id.get(ref)
            if node is not None:
                bounds = None
                for child in shape_elem:
                    if _strip_ns(child.tag) == "Bounds":
                        bounds = child
                        break
                if bounds is not None:
                    node.x = float(bounds.get("x", "0"))
                    node.y = float(bounds.get("y", "0"))
                    node.width = float(bounds.get("width", "100"))
                    node.height = float(bounds.get("height", "80"))

        elif tag == "BPMNEdge":
            ref = shape_elem.get("bpmnElement", "")
            for flow in bpmn.flows:
                if flow.id == ref:
                    for child in shape_elem:
                        if _strip_ns(child.tag) == "waypoint":
                            x = float(child.get("x", "0"))
                            y = float(child.get("y", "0"))
                            flow.waypoints.append((x, y))
                    break

    return bpmn
