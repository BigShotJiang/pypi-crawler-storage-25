"""pl4pm.read.dfg — DFG text file reader."""

from __future__ import annotations

from typing import Dict, Tuple


def read_dfg(
    file_path: str,
    encoding: str = "utf-8",
) -> Tuple[Dict[Tuple[str, str], int], Dict[str, int], Dict[str, int]]:
    """Read a DFG from a .dfg file.

    The .dfg format (as used by pm4py):
        Line 1: number of activities
        Next N lines: activity names
        Next line: number of start activities
        Next S lines: "freq activity"
        Next line: number of end activities
        Next E lines: "freq activity"
        Next line: number of DFG edges
        Next D lines: "source>target>freq"

    Returns:
        (dfg_dict, start_activities, end_activities)
    """
    dfg: Dict[Tuple[str, str], int] = {}
    start_activities: Dict[str, int] = {}
    end_activities: Dict[str, int] = {}

    with open(file_path, "r", encoding=encoding) as f:
        lines = [line.strip() for line in f.readlines() if line.strip()]

    idx = 0

    # Number of activities
    n_activities = int(lines[idx]); idx += 1
    activities: list[str] = []
    for _ in range(n_activities):
        activities.append(lines[idx]); idx += 1

    # Start activities
    n_start = int(lines[idx]); idx += 1
    for _ in range(n_start):
        parts = lines[idx].split("x", 1) if "x" in lines[idx] else [lines[idx]]
        if len(parts) == 2:
            freq, act = int(parts[0].strip()), parts[1].strip()
        else:
            # format: "freq activity"
            tokens = lines[idx].split(maxsplit=1)
            freq, act = int(tokens[0]), tokens[1] if len(tokens) > 1 else tokens[0]
        start_activities[act] = freq
        idx += 1

    # End activities
    n_end = int(lines[idx]); idx += 1
    for _ in range(n_end):
        tokens = lines[idx].split(maxsplit=1)
        freq, act = int(tokens[0]), tokens[1] if len(tokens) > 1 else tokens[0]
        end_activities[act] = freq
        idx += 1

    # DFG edges
    n_edges = int(lines[idx]); idx += 1
    for _ in range(n_edges):
        line = lines[idx]; idx += 1
        # format: "source>target>freq"
        parts = line.split(">")
        if len(parts) >= 3:
            source = parts[0].strip()
            target = parts[1].strip()
            freq = int(parts[2].strip())
            dfg[(source, target)] = freq

    return dfg, start_activities, end_activities
