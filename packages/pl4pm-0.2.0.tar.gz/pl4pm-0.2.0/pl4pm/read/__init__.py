"""pl4pm.read — Unified reader module."""

from __future__ import annotations

from typing import Optional

from pl4pm.objects.petri_net import PetriNet, Marking
from pl4pm.objects.process_tree import ProcessTree
from pl4pm.objects.bpmn import BPMN
from pl4pm.objects.ocel import OCEL

from pl4pm.read.xes import read_xes
from pl4pm.read.csv import read_csv, format_dataframe
from pl4pm.read.pnml import read_pnml
from pl4pm.read.ptml import read_ptml
from pl4pm.read.dfg import read_dfg
from pl4pm.read.bpmn import read_bpmn
from pl4pm.read.parquet import read_parquet
from pl4pm.read.ocel import (
    read_ocel_csv, read_ocel_json, read_ocel_xml, read_ocel_sqlite,
    read_ocel2_json, read_ocel2_xml, read_ocel2_sqlite,
)


def read_ocel(
    file_path: str,
    objects_path: Optional[str] = None,
    encoding: str = "utf-8",
) -> OCEL:
    """Auto-detect OCEL format by extension and read."""
    fp = file_path.lower()
    if fp.endswith(".csv"):
        return read_ocel_csv(file_path, objects_path=objects_path, encoding=encoding)
    if fp.endswith(".jsonocel") or fp.endswith(".json"):
        return read_ocel_json(file_path, encoding=encoding)
    if fp.endswith(".xmlocel") or fp.endswith(".xml"):
        return read_ocel_xml(file_path, encoding=encoding)
    if fp.endswith(".sqlite"):
        return read_ocel_sqlite(file_path, encoding=encoding)
    raise ValueError(f"Unsupported OCEL file format: {file_path}")


def read_ocel2(
    file_path: str,
    variant_str: Optional[str] = None,
    encoding: str = "utf-8",
) -> OCEL:
    """Auto-detect OCEL 2.0 format by extension and read."""
    fp = file_path.lower()
    if fp.endswith(".jsonocel") or fp.endswith(".json"):
        return read_ocel2_json(file_path, encoding=encoding)
    if fp.endswith(".xmlocel") or fp.endswith(".xml"):
        return read_ocel2_xml(file_path, encoding=encoding)
    if fp.endswith(".sqlite"):
        return read_ocel2_sqlite(file_path, variant_str=variant_str, encoding=encoding)
    raise ValueError(f"Unsupported OCEL 2.0 file format: {file_path}")


__all__ = [
    "read_xes", "read_csv", "format_dataframe", "read_parquet",
    "read_pnml", "read_ptml", "read_dfg", "read_bpmn",
    "read_ocel", "read_ocel_csv", "read_ocel_json", "read_ocel_xml", "read_ocel_sqlite",
    "read_ocel2", "read_ocel2_json", "read_ocel2_xml", "read_ocel2_sqlite",
]
