"""pl4pm.read.ocel.csv — OCEL CSV reader."""

from __future__ import annotations

import ast
from typing import Optional

import polars as pl

from pl4pm.objects.ocel import OCEL


def _parse_object_values(value: object) -> list[str]:
    if value is None:
        return []
    if isinstance(value, list):
        return [str(item) for item in value if item not in (None, "")]
    text = str(value).strip()
    if not text or text.lower() in {"nan", "null", "none"}:
        return []
    if text.startswith("[") and text.endswith("]"):
        try:
            parsed = ast.literal_eval(text)
        except (SyntaxError, ValueError):
            return []
        if isinstance(parsed, list):
            return [str(item) for item in parsed if item not in (None, "")]
    return []


def read_ocel_csv(
    file_path: str,
    objects_path: Optional[str] = None,
    encoding: str = "utf-8",
) -> OCEL:
    """Read an OCEL from a CSV file.

    Args:
        file_path: Path to the events CSV.
        objects_path: Optional path to the objects CSV.
        encoding: File encoding.

    Returns:
        OCEL object.
    """
    events_df = pl.read_csv(file_path, encoding=encoding)

    # Normalise column names
    col_map = {}
    for c in events_df.columns:
        cl = c.lower().strip()
        if cl in ("ocel:eid", "event_id", "eid"):
            col_map[c] = OCEL.EVENT_ID
        elif cl in ("ocel:activity", "activity", "ocel:type-name"):
            col_map[c] = OCEL.EVENT_ACTIVITY
        elif cl in ("ocel:timestamp", "timestamp", "time:timestamp"):
            col_map[c] = OCEL.EVENT_TIMESTAMP
    if col_map:
        events_df = events_df.rename(col_map)

    # Cast timestamp
    if OCEL.EVENT_TIMESTAMP in events_df.columns:
        if events_df[OCEL.EVENT_TIMESTAMP].dtype == pl.Utf8:
            events_df = events_df.with_columns(
                pl.col(OCEL.EVENT_TIMESTAMP).str.to_datetime().alias(OCEL.EVENT_TIMESTAMP)
            )

    objects_df = pl.DataFrame(schema={OCEL.OBJECT_ID: pl.Utf8, OCEL.OBJECT_TYPE: pl.Utf8})
    if objects_path:
        objects_df = pl.read_csv(objects_path, encoding=encoding)
        obj_map = {}
        for c in objects_df.columns:
            cl = c.lower().strip()
            if cl in ("ocel:oid", "object_id", "oid"):
                obj_map[c] = OCEL.OBJECT_ID
            elif cl in ("ocel:type", "object_type", "type"):
                obj_map[c] = OCEL.OBJECT_TYPE
        if obj_map:
            objects_df = objects_df.rename(obj_map)

    # pm4py treats OCEL CSV as an extended-table format:
    # non object-type columns stay in events, while object columns are exploded
    # into relations only when they contain list-like values.
    relations_rows: list[dict] = []
    obj_type_cols = [c for c in events_df.columns
                     if c.startswith("ocel:type")]
    event_cols = [c for c in events_df.columns if c not in set(obj_type_cols)]

    for col in obj_type_cols:
        otype = col.replace("ocel:type:", "").replace("ocel:type-", "")
        sub = events_df.select([c for c in [OCEL.EVENT_ID, OCEL.EVENT_ACTIVITY, OCEL.EVENT_TIMESTAMP, col] if c in events_df.columns]).drop_nulls()
        for row in sub.iter_rows(named=True):
            for oid in _parse_object_values(row[col]):
                relations_rows.append({
                    OCEL.EVENT_ID: row[OCEL.EVENT_ID],
                    OCEL.EVENT_ACTIVITY: row.get(OCEL.EVENT_ACTIVITY, ""),
                    OCEL.EVENT_TIMESTAMP: row.get(OCEL.EVENT_TIMESTAMP),
                    OCEL.OBJECT_ID: oid,
                    OCEL.OBJECT_TYPE: otype,
                })

    relations_df = pl.DataFrame(relations_rows) if relations_rows else pl.DataFrame(
        schema={
            OCEL.EVENT_ID: pl.Utf8,
            OCEL.EVENT_ACTIVITY: pl.Utf8,
            OCEL.EVENT_TIMESTAMP: pl.Datetime,
            OCEL.OBJECT_ID: pl.Utf8,
            OCEL.OBJECT_TYPE: pl.Utf8,
        }
    )

    events_df = events_df.select(event_cols)
    if OCEL.EVENT_TIMESTAMP in events_df.columns:
        events_df = events_df.sort([OCEL.EVENT_TIMESTAMP, OCEL.EVENT_ID])
    if OCEL.EVENT_TIMESTAMP in relations_df.columns and relations_df.height:
        relations_df = relations_df.sort([OCEL.EVENT_TIMESTAMP, OCEL.EVENT_ID, OCEL.OBJECT_ID])

    return OCEL(events=events_df, objects=objects_df, relations=relations_df)
