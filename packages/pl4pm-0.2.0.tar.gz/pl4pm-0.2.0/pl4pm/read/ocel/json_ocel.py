"""pl4pm.read.ocel.json_ocel — OCEL JSON reader (1.0 and 2.0)."""

from __future__ import annotations

import json
from datetime import datetime
from typing import Any, Dict, List

import polars as pl

from pl4pm.objects.ocel import OCEL


def _parse_ts(val: Any) -> datetime | None:
    if isinstance(val, str):
        try:
            return datetime.fromisoformat(val.replace("Z", "+00:00"))
        except ValueError:
            return None
    return val


def read_ocel_json(
    file_path: str,
    encoding: str = "utf-8",
) -> OCEL:
    """Read an OCEL 1.0 JSON file."""
    with open(file_path, "r", encoding=encoding) as f:
        data = json.load(f)

    # Objects are parsed first so relation qualifiers can reuse the object type,
    # matching the semantics exposed by pm4py.
    obj_rows: List[Dict[str, Any]] = []
    object_type_by_id: Dict[str, str] = {}
    objects_raw = data.get("ocel:objects", {})
    for oid, odata in objects_raw.items():
        otype = odata.get("ocel:type", "")
        object_type_by_id[oid] = otype
        obj_rows.append({
            OCEL.OBJECT_ID: oid,
            OCEL.OBJECT_TYPE: otype,
            **odata.get("ocel:ovmap", {}),
        })

    # Events
    event_rows: List[Dict[str, Any]] = []
    relation_rows: List[Dict[str, Any]] = []
    events_raw = data.get("ocel:events", {})
    for eid, edata in events_raw.items():
        row: Dict[str, Any] = {OCEL.EVENT_ID: eid}
        row[OCEL.EVENT_ACTIVITY] = edata.get("ocel:activity", "")
        row[OCEL.EVENT_TIMESTAMP] = _parse_ts(edata.get("ocel:timestamp"))
        vmap = edata.get("ocel:vmap", {})
        row.update(vmap)
        event_rows.append(row)
        for oid in edata.get("ocel:omap", []):
            relation_rows.append({
                OCEL.EVENT_ID: eid,
                OCEL.OBJECT_ID: oid,
                OCEL.QUALIFIER: object_type_by_id.get(oid, ""),
            })

    events_df = pl.DataFrame(event_rows) if event_rows else pl.DataFrame(
        schema={OCEL.EVENT_ID: pl.Utf8, OCEL.EVENT_ACTIVITY: pl.Utf8,
                OCEL.EVENT_TIMESTAMP: pl.Datetime})
    objects_df = pl.DataFrame(obj_rows) if obj_rows else pl.DataFrame(
        schema={OCEL.OBJECT_ID: pl.Utf8, OCEL.OBJECT_TYPE: pl.Utf8})
    relations_df = pl.DataFrame(relation_rows) if relation_rows else pl.DataFrame(
        schema={OCEL.EVENT_ID: pl.Utf8, OCEL.OBJECT_ID: pl.Utf8,
                OCEL.QUALIFIER: pl.Utf8})

    return OCEL(events=events_df, objects=objects_df, relations=relations_df,
                globals=data.get("ocel:global-log", {}))


def read_ocel2_json(
    file_path: str,
    encoding: str = "utf-8",
) -> OCEL:
    """Read an OCEL 2.0 JSON file."""
    with open(file_path, "r", encoding=encoding) as f:
        data = json.load(f)

    event_rows: List[Dict[str, Any]] = []
    relation_rows: List[Dict[str, Any]] = []
    obj_rows: List[Dict[str, Any]] = []
    o2o_rows: List[Dict[str, Any]] = []

    for ev in data.get("events", []):
        row = {OCEL.EVENT_ID: ev.get("id", ""),
               OCEL.EVENT_ACTIVITY: ev.get("type", ev.get("activity", "")),
               OCEL.EVENT_TIMESTAMP: _parse_ts(ev.get("time", ev.get("timestamp")))}
        for attr in ev.get("attributes", []):
            row[attr.get("name", "")] = attr.get("value", "")
        event_rows.append(row)
        for rel in ev.get("relationships", []):
            relation_rows.append({
                OCEL.EVENT_ID: ev.get("id", ""),
                OCEL.OBJECT_ID: rel.get("objectId", ""),
                OCEL.QUALIFIER: rel.get("qualifier", ""),
            })

    for obj in data.get("objects", []):
        obj_row = {OCEL.OBJECT_ID: obj.get("id", ""),
                   OCEL.OBJECT_TYPE: obj.get("type", "")}
        for attr in obj.get("attributes", []):
            obj_row[attr.get("name", "")] = attr.get("value", "")
        obj_rows.append(obj_row)
        for rel in obj.get("relationships", []):
            o2o_rows.append({
                "ocel:oid_src": obj.get("id", ""),
                "ocel:oid_tgt": rel.get("objectId", ""),
                OCEL.QUALIFIER: rel.get("qualifier", ""),
            })

    events_df = pl.DataFrame(event_rows) if event_rows else pl.DataFrame(
        schema={OCEL.EVENT_ID: pl.Utf8, OCEL.EVENT_ACTIVITY: pl.Utf8,
                OCEL.EVENT_TIMESTAMP: pl.Datetime})
    objects_df = pl.DataFrame(obj_rows) if obj_rows else pl.DataFrame(
        schema={OCEL.OBJECT_ID: pl.Utf8, OCEL.OBJECT_TYPE: pl.Utf8})
    relations_df = pl.DataFrame(relation_rows) if relation_rows else pl.DataFrame(
        schema={OCEL.EVENT_ID: pl.Utf8, OCEL.OBJECT_ID: pl.Utf8,
                OCEL.QUALIFIER: pl.Utf8})
    o2o_df = pl.DataFrame(o2o_rows) if o2o_rows else pl.DataFrame(
        schema={"ocel:oid_src": pl.Utf8, "ocel:oid_tgt": pl.Utf8,
                OCEL.QUALIFIER: pl.Utf8})

    return OCEL(events=events_df, objects=objects_df,
                relations=relations_df, o2o=o2o_df)
