"""pl4pm.read.ocel.sqlite_ocel — OCEL SQLite reader (1.0 and 2.0)."""

from __future__ import annotations

import sqlite3
from typing import Optional

import polars as pl

from pl4pm.objects.ocel import OCEL


def _read_table(conn: sqlite3.Connection, table_name: str) -> pl.DataFrame:
    """Read an entire SQLite table into a Polars DataFrame."""
    cursor = conn.execute(f"SELECT * FROM [{table_name}]")
    cols = [desc[0] for desc in cursor.description]
    rows = cursor.fetchall()
    if not rows:
        return pl.DataFrame(schema={c: pl.Utf8 for c in cols})
    data = {c: [r[i] for r in rows] for i, c in enumerate(cols)}
    return pl.DataFrame(data)


def _table_exists(conn: sqlite3.Connection, name: str) -> bool:
    cur = conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name=?", (name,))
    return cur.fetchone() is not None


def read_ocel_sqlite(
    file_path: str,
    encoding: str = "utf-8",
) -> OCEL:
    """Read an OCEL 1.0 from a SQLite database."""
    conn = sqlite3.connect(file_path)
    try:
        events_df = _read_table(conn, "event") if _table_exists(conn, "event") else (
            _read_table(conn, "events") if _table_exists(conn, "events") else
            pl.DataFrame(schema={OCEL.EVENT_ID: pl.Utf8, OCEL.EVENT_ACTIVITY: pl.Utf8,
                                 OCEL.EVENT_TIMESTAMP: pl.Utf8}))

        objects_df = _read_table(conn, "object") if _table_exists(conn, "object") else (
            _read_table(conn, "objects") if _table_exists(conn, "objects") else
            pl.DataFrame(schema={OCEL.OBJECT_ID: pl.Utf8, OCEL.OBJECT_TYPE: pl.Utf8}))

        relations_df = pl.DataFrame(
            schema={OCEL.EVENT_ID: pl.Utf8, OCEL.OBJECT_ID: pl.Utf8,
                    OCEL.QUALIFIER: pl.Utf8})
        for tbl in ("event_object", "event_to_object", "relation", "relations"):
            if _table_exists(conn, tbl):
                relations_df = _read_table(conn, tbl)
                break

        # Normalise column names
        for df_name, expected in [
            ("events_df", {OCEL.EVENT_ID, OCEL.EVENT_ACTIVITY, OCEL.EVENT_TIMESTAMP}),
            ("objects_df", {OCEL.OBJECT_ID, OCEL.OBJECT_TYPE}),
        ]:
            df = locals()[df_name]
            renames = {}
            for c in df.columns:
                cl = c.lower().replace(" ", "_")
                if cl in ("ocel_eid", "event_id", "eid") and OCEL.EVENT_ID not in df.columns:
                    renames[c] = OCEL.EVENT_ID
                elif cl in ("ocel_activity", "activity") and OCEL.EVENT_ACTIVITY not in df.columns:
                    renames[c] = OCEL.EVENT_ACTIVITY
                elif cl in ("ocel_timestamp", "timestamp") and OCEL.EVENT_TIMESTAMP not in df.columns:
                    renames[c] = OCEL.EVENT_TIMESTAMP
                elif cl in ("ocel_oid", "object_id", "oid") and OCEL.OBJECT_ID not in df.columns:
                    renames[c] = OCEL.OBJECT_ID
                elif cl in ("ocel_type", "object_type") and OCEL.OBJECT_TYPE not in df.columns:
                    renames[c] = OCEL.OBJECT_TYPE
            if renames:
                if df_name == "events_df":
                    events_df = events_df.rename(renames)
                else:
                    objects_df = objects_df.rename(renames)

        return OCEL(events=events_df, objects=objects_df, relations=relations_df)
    finally:
        conn.close()


def read_ocel2_sqlite(
    file_path: str,
    variant_str: Optional[str] = None,
    encoding: str = "utf-8",
) -> OCEL:
    """Read an OCEL 2.0 from a SQLite database."""
    conn = sqlite3.connect(file_path)
    try:
        events_df = _read_table(conn, "event") if _table_exists(conn, "event") else pl.DataFrame(
            schema={OCEL.EVENT_ID: pl.Utf8, OCEL.EVENT_ACTIVITY: pl.Utf8,
                    OCEL.EVENT_TIMESTAMP: pl.Utf8})

        objects_df = _read_table(conn, "object") if _table_exists(conn, "object") else pl.DataFrame(
            schema={OCEL.OBJECT_ID: pl.Utf8, OCEL.OBJECT_TYPE: pl.Utf8})

        relations_df = pl.DataFrame(
            schema={OCEL.EVENT_ID: pl.Utf8, OCEL.OBJECT_ID: pl.Utf8,
                    OCEL.QUALIFIER: pl.Utf8})
        for tbl in ("event_object", "event_to_object"):
            if _table_exists(conn, tbl):
                relations_df = _read_table(conn, tbl)
                break

        o2o_df = pl.DataFrame(
            schema={"ocel:oid_src": pl.Utf8, "ocel:oid_tgt": pl.Utf8,
                    OCEL.QUALIFIER: pl.Utf8})
        for tbl in ("object_object", "object_to_object"):
            if _table_exists(conn, tbl):
                o2o_df = _read_table(conn, tbl)
                break

        object_changes_df = pl.DataFrame(
            schema={OCEL.EVENT_ID: pl.Utf8, OCEL.OBJECT_ID: pl.Utf8,
                    OCEL.CHANGED_FIELD: pl.Utf8})
        if _table_exists(conn, "object_change"):
            object_changes_df = _read_table(conn, "object_change")

        return OCEL(events=events_df, objects=objects_df,
                    relations=relations_df, o2o=o2o_df,
                    object_changes=object_changes_df)
    finally:
        conn.close()
