"""pl4pm.read.ocel.xml_ocel — OCEL XML reader (1.0 and 2.0)."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List

import polars as pl
from lxml import etree  # type: ignore[import-untyped]

from pl4pm.objects.ocel import OCEL


def _strip_ns(tag: str) -> str:
    return tag.split("}", 1)[1] if "}" in tag else tag


def _parse_ts(val: str) -> datetime | None:
    try:
        return datetime.fromisoformat(val.replace("Z", "+00:00"))
    except (ValueError, TypeError):
        return None


def read_ocel_xml(
    file_path: str,
    encoding: str = "utf-8",
) -> OCEL:
    """Read an OCEL 1.0 XML file."""
    tree = etree.parse(file_path)
    root = tree.getroot()

    event_rows: List[Dict[str, Any]] = []
    pending_relations: List[Dict[str, Any]] = []
    obj_rows: List[Dict[str, Any]] = []
    object_type_by_id: Dict[str, str] = {}

    # Events
    for ev_elem in root.iter():
        tag = _strip_ns(ev_elem.tag)
        if tag != "event":
            continue
        eid = ""
        activity = ""
        ts = None
        attrs: Dict[str, Any] = {}
        omap: List[str] = []

        for child in ev_elem:
            ctag = _strip_ns(child.tag)
            if ctag == "string" or ctag == "id":
                key = child.get("key", "")
                val = child.get("value", child.text or "")
                if key == "ocel:eid" or key == "id":
                    eid = val
                elif key == "ocel:activity" or key == "activity":
                    activity = val
                else:
                    attrs[key] = val
            elif ctag == "date":
                key = child.get("key", "")
                val = child.get("value", child.text or "")
                if key == "ocel:timestamp" or key == "timestamp":
                    ts = _parse_ts(val)
                else:
                    attrs[key] = _parse_ts(val)
            elif ctag == "omap" or ctag == "objects":
                for obj_ref in child:
                    oid_val = obj_ref.get("value", obj_ref.text or "")
                    if oid_val:
                        omap.append(oid_val)

        row = {OCEL.EVENT_ID: eid, OCEL.EVENT_ACTIVITY: activity,
               OCEL.EVENT_TIMESTAMP: ts}
        row.update(attrs)
        event_rows.append(row)
        for oid in omap:
            pending_relations.append({
                OCEL.EVENT_ID: eid,
                OCEL.OBJECT_ID: oid,
            })

    # Objects
    for obj_elem in root.iter():
        tag = _strip_ns(obj_elem.tag)
        if tag != "object":
            continue
        oid = ""
        otype = ""
        oattrs: Dict[str, Any] = {}
        for child in obj_elem:
            ctag = _strip_ns(child.tag)
            key = child.get("key", "")
            val = child.get("value", child.text or "")
            if key in ("ocel:oid", "id"):
                oid = val
            elif key in ("ocel:type", "type"):
                otype = val
            elif ctag == "ovmap" or ctag == "attributes":
                for attr in child:
                    akey = attr.get("key", attr.get("name", ""))
                    aval = attr.get("value", attr.text or "")
                    oattrs[akey] = aval
            else:
                oattrs[key] = val
        object_type_by_id[oid] = otype
        obj_rows.append({OCEL.OBJECT_ID: oid, OCEL.OBJECT_TYPE: otype, **oattrs})

    relation_rows: List[Dict[str, Any]] = []
    for rel in pending_relations:
        relation_rows.append({
            **rel,
            OCEL.QUALIFIER: object_type_by_id.get(rel[OCEL.OBJECT_ID], ""),
        })

    events_df = pl.DataFrame(event_rows) if event_rows else pl.DataFrame(
        schema={OCEL.EVENT_ID: pl.Utf8, OCEL.EVENT_ACTIVITY: pl.Utf8,
                OCEL.EVENT_TIMESTAMP: pl.Datetime})
    objects_df = pl.DataFrame(obj_rows) if obj_rows else pl.DataFrame(
        schema={OCEL.OBJECT_ID: pl.Utf8, OCEL.OBJECT_TYPE: pl.Utf8})
    relations_df = pl.DataFrame(relation_rows) if relation_rows else pl.DataFrame(
        schema={OCEL.EVENT_ID: pl.Utf8, OCEL.OBJECT_ID: pl.Utf8,
                OCEL.QUALIFIER: pl.Utf8})

    return OCEL(events=events_df, objects=objects_df, relations=relations_df)


def read_ocel2_xml(
    file_path: str,
    encoding: str = "utf-8",
) -> OCEL:
    """Read an OCEL 2.0 XML file."""
    tree = etree.parse(file_path)
    root = tree.getroot()

    event_rows: List[Dict[str, Any]] = []
    relation_rows: List[Dict[str, Any]] = []
    obj_rows: List[Dict[str, Any]] = []
    o2o_rows: List[Dict[str, Any]] = []

    for elem in root.iter():
        tag = _strip_ns(elem.tag)

        if tag == "event":
            eid = elem.get("id", "")
            etype = elem.get("type", "")
            ets = _parse_ts(elem.get("time", ""))
            row: Dict[str, Any] = {OCEL.EVENT_ID: eid,
                                    OCEL.EVENT_ACTIVITY: etype,
                                    OCEL.EVENT_TIMESTAMP: ets}
            for child in elem:
                ctag = _strip_ns(child.tag)
                if ctag == "attribute":
                    row[child.get("name", "")] = child.get("value", child.text or "")
                elif ctag == "relationship":
                    relation_rows.append({
                        OCEL.EVENT_ID: eid,
                        OCEL.OBJECT_ID: child.get("objectId", child.get("object-id", "")),
                        OCEL.QUALIFIER: child.get("qualifier", ""),
                    })
                elif ctag == "attributes":
                    for attr in child:
                        if _strip_ns(attr.tag) == "attribute":
                            row[attr.get("name", "")] = attr.get("value", attr.text or "")
                elif ctag == "objects":
                    for rel in child:
                        if _strip_ns(rel.tag) == "relationship":
                            relation_rows.append({
                                OCEL.EVENT_ID: eid,
                                OCEL.OBJECT_ID: rel.get("objectId", rel.get("object-id", "")),
                                OCEL.QUALIFIER: rel.get("qualifier", ""),
                            })
            event_rows.append(row)

        elif tag == "object":
            oid = elem.get("id", "")
            otype = elem.get("type", "")
            orow: Dict[str, Any] = {OCEL.OBJECT_ID: oid, OCEL.OBJECT_TYPE: otype}
            for child in elem:
                ctag = _strip_ns(child.tag)
                if ctag == "attribute":
                    orow[child.get("name", "")] = child.get("value", child.text or "")
                elif ctag == "relationship":
                    o2o_rows.append({
                        "ocel:oid_src": oid,
                        "ocel:oid_tgt": child.get("objectId", child.get("object-id", "")),
                        OCEL.QUALIFIER: child.get("qualifier", ""),
                    })
                elif ctag == "attributes":
                    for attr in child:
                        if _strip_ns(attr.tag) == "attribute":
                            orow[attr.get("name", "")] = attr.get("value", attr.text or "")
                elif ctag == "objects":
                    for rel in child:
                        if _strip_ns(rel.tag) == "relationship":
                            o2o_rows.append({
                                "ocel:oid_src": oid,
                                "ocel:oid_tgt": rel.get("objectId", rel.get("object-id", "")),
                                OCEL.QUALIFIER: rel.get("qualifier", ""),
                            })
            obj_rows.append(orow)

    events_df = pl.DataFrame(event_rows) if event_rows else pl.DataFrame(
        schema={OCEL.EVENT_ID: pl.Utf8, OCEL.EVENT_ACTIVITY: pl.Utf8,
                OCEL.EVENT_TIMESTAMP: pl.Datetime})
    objects_df = pl.DataFrame(obj_rows) if obj_rows else pl.DataFrame(
        schema={OCEL.OBJECT_ID: pl.Utf8, OCEL.OBJECT_TYPE: pl.Utf8})
    relations_df = pl.DataFrame(relation_rows) if relation_rows else pl.DataFrame(
        schema={OCEL.EVENT_ID: pl.Utf8, OCEL.OBJECT_ID: pl.Utf8,
                OCEL.QUALIFIER: pl.Utf8})
    o2o_df = pl.DataFrame(o2o_rows) if o2o_rows else pl.DataFrame(
        schema={"ocel:oid_src": pl.Utf8, "ocel:oid_tgt": pl.Utf8,
                OCEL.QUALIFIER: pl.Utf8})

    return OCEL(events=events_df, objects=objects_df,
                relations=relations_df, o2o=o2o_df)
