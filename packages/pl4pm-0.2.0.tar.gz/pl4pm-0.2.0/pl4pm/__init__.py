"""
pl4pm — Polars for Process Mining
==================================
A high-performance Process Mining library built on Polars.
Drop-in API-compatible replacement for pm4py's core functionality.
"""

__version__ = "0.2.0"

# ── Read ──────────────────────────────────────────────────────────────
from pl4pm.read import (
    read_xes, read_csv, format_dataframe, read_parquet,
    read_pnml, read_ptml, read_dfg, read_bpmn,
    read_ocel, read_ocel_csv, read_ocel_json, read_ocel_xml, read_ocel_sqlite,
    read_ocel2, read_ocel2_json, read_ocel2_xml, read_ocel2_sqlite,
)

# ── Write ─────────────────────────────────────────────────────────────
from pl4pm.write import (
    write_xes, write_csv, write_pnml, write_ptml, write_dfg, write_bpmn,
    write_ocel, write_ocel_csv, write_ocel_json, write_ocel_xml, write_ocel_sqlite,
    write_ocel2, write_ocel2_json, write_ocel2_xml, write_ocel2_sqlite,
)

# ── Convert ───────────────────────────────────────────────────────────
from pl4pm.convert import (
    convert_to_bpmn,
    convert_to_petri_net,
    convert_to_process_tree,
    convert_to_reachability_graph,
    convert_to_event_log,
    convert_to_event_stream,
    convert_log_to_ocel,
    convert_log_to_networkx,
    convert_ocel_to_networkx,
    convert_petri_net_to_networkx,
    convert_petri_net_type,
)

# ── Stats ─────────────────────────────────────────────────────────────
from pl4pm.stats import (
    get_start_activities,
    get_end_activities,
    get_event_attributes,
    get_trace_attributes,
    get_event_attribute_values,
    get_trace_attribute_values,
    get_variants,
    get_variants_as_tuples,
    split_by_process_variant,
    get_variants_paths_duration,
    get_stochastic_language,
    get_minimum_self_distances,
    get_minimum_self_distance_witnesses,
    get_case_arrival_average,
    get_rework_cases_per_activity,
    get_case_overlap,
    get_cycle_time,
    get_service_time,
    get_activity_pair_average_durations,
    get_all_case_durations,
    get_case_duration,
    get_frequent_trace_segments,
    get_activity_position_summary,
    get_process_cube,
    detect_bottlenecks,
)

# ── Discovery ─────────────────────────────────────────────────────────
from pl4pm.discovery import (
    discover_dfg,
    discover_directly_follows_graph,
    discover_performance_dfg,
    discover_eventually_follows_graph,
    discover_petri_net_alpha,
    discover_process_tree_inductive,
    discover_petri_net_inductive,
    discover_bpmn_inductive,
    discover_heuristics_net,
    discover_petri_net_heuristics,
    discover_footprints,
    discover_temporal_profile,
    discover_log_skeleton,
    discover_transition_system,
    discover_prefix_tree,
    discover_batches,
    discover_declare,
    correlation_miner,
    derive_minimum_self_distance,
    discover_petri_net_ilp,
    discover_powl,
)

# ── Conformance ───────────────────────────────────────────────────────
from pl4pm.conformance import (
    conformance_diagnostics_token_based_replay,
    fitness_token_based_replay,
    precision_token_based_replay,
    generalization_tbr,
    replay_prefix_tbr,
    conformance_diagnostics_alignments,
    fitness_alignments,
    precision_alignments,
    conformance_diagnostics_footprints,
    fitness_footprints,
    precision_footprints,
    conformance_temporal_profile,
    conformance_declare,
    conformance_log_skeleton,
    conformance_ocdfg,
    conformance_otg,
    conformance_etot,
)

# ── Analysis ──────────────────────────────────────────────────────────
from pl4pm.analysis import (
    get_enabled_transitions,
    construct_synchronous_product_net,
    compute_emd,
    solve_marking_equation,
    solve_extended_marking_equation,
    check_is_workflow_net,
    check_is_sound,
    check_soundness,
    simplicity_petri_net,
    maximal_decomposition,
    generate_marking,
    reduce_petri_net_invisibles,
    reduce_petri_net_implicit_places,
    insert_artificial_start_end,
    insert_case_service_waiting_time,
    insert_case_arrival_finish_rate,
    get_activity_labels,
    replace_activity_labels,
    behavioral_similarity,
    structural_similarity,
    label_sets_similarity,
    embeddings_similarity,
    map_labels_from_second_model,
    cluster_log,
)

# ── Organizational ────────────────────────────────────────────────────
from pl4pm.org import (
    SNA, Role,
    discover_handover_of_work_network,
    discover_working_together_network,
    discover_activity_based_resource_similarity,
    discover_subcontracting_network,
    discover_organizational_roles,
    discover_network_analysis,
)

# ── Simulation ────────────────────────────────────────────────────────
from pl4pm.sim import play_out, generate_process_tree

# ── Machine Learning ──────────────────────────────────────────────────
from pl4pm.ml import (
    split_train_test,
    get_prefixes_from_log,
    extract_outcome_enriched_dataframe,
    extract_features_dataframe,
    extract_ocel_features,
    extract_temporal_features_dataframe,
    extract_target_vector,
)

# ── OCEL Analysis ─────────────────────────────────────────────────────
from pl4pm.ocel_module import (
    ocel_get_object_types,
    ocel_get_attribute_names,
    ocel_flattening,
    ocel_object_type_activities,
    ocel_objects_ot_count,
    ocel_temporal_summary,
    ocel_objects_summary,
    ocel_objects_interactions_summary,
    discover_ocdfg,
    discover_oc_petri_net,
    discover_objects_graph,
    ocel_o2o_enrichment,
    ocel_e2o_lifecycle_enrichment,
    sample_ocel_objects,
    sample_ocel_connected_components,
    ocel_drop_duplicates,
    ocel_merge_duplicates,
    ocel_sort_by_additional_column,
    ocel_add_index_based_timedelta,
    cluster_equivalent_ocel,
)

# ── Filtering ─────────────────────────────────────────────────────────
from pl4pm.filter import (
    filter_start_activities,
    filter_end_activities,
    filter_activities_duration,
    filter_event_attribute_values,
    filter_trace_attribute_values,
    filter_variants,
    filter_directly_follows_relation,
    filter_eventually_follows_relation,
    filter_time_range,
    filter_case_performance,
    filter_case_size,
    filter_between,
    filter_activities_rework,
    filter_prefixes,
    filter_four_eyes_principle,
    filter_log_relative_occurrence_event_attribute,
    filter_variants_top_k,
    filter_variants_by_coverage_percentage,
    filter_suffixes,
    filter_paths_performance,
    filter_activity_done_different_resources,
    filter_trace_segments,
)

# ── Utils ─────────────────────────────────────────────────────────────
from pl4pm.utils import (
    is_polars_lazyframe,
    format_dataframe as format_dataframe_util,
    rebase,
    parse_process_tree,
    parse_event_log_string,
    get_properties,
    project_on_event_attribute,
    sample_cases,
    sample_events,
    serialize,
    deserialize,
)

# ── Visualization ─────────────────────────────────────────────────────
from pl4pm.vis import (
    view_petri_net, save_vis_petri_net,
    view_dfg, save_vis_dfg, save_vis_dfg_pyvis,
    view_performance_dfg, save_vis_performance_dfg,
    view_process_tree, save_vis_process_tree,
    view_bpmn, save_vis_bpmn,
    view_heuristics_net, save_vis_heuristics_net,
    view_transition_system, save_vis_transition_system,
    view_prefix_tree, save_vis_prefix_tree,
    view_footprints, save_vis_footprints,
    view_dotted_chart, save_vis_dotted_chart,
    view_case_duration_graph, save_vis_case_duration_graph,
    view_events_per_time_graph, save_vis_events_per_time_graph,
    view_events_distribution_graph, save_vis_events_distribution_graph,
    view_performance_spectrum, save_vis_performance_spectrum,
    view_alignments, save_vis_alignments,
)

# ── Objects (re-export for convenience) ───────────────────────────────
from pl4pm.objects import (
    PetriNet, Marking,
    ProcessTree, Operator,
    BPMN, OCEL,
    TransitionSystem,
    EventLog, EventStream, Trace,
    HeuristicsNet, Trie,
    POWL, POWLTransition, POWLSilentTransition,
    OperatorPOWL, StrictPartialOrder, POWLOperator,
)
