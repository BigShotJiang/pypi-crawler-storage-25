# ruff: noqa
"""Lloyd-Max scalar quantizer for rotated unit vectors.

The coordinate distribution is approximately Beta-shaped on [-1, 1] after
random rotation. For d >= 64, a Gaussian N(0, 1/d) is a good approximation.
"""

from __future__ import annotations

import math

import torch


# ---------------------------------------------------------------------------
# Pure-Python Gaussian integration helpers (replaces scipy.integrate.quad)
# ---------------------------------------------------------------------------


def _gauss_pdf(x: float, sigma: float) -> float:
    """N(0, σ²) probability density at x."""
    return math.exp(-0.5 * (x / sigma) ** 2) / (sigma * math.sqrt(2.0 * math.pi))


def _gauss_cdf(x: float, sigma: float) -> float:
    """N(0, σ²) cumulative distribution at x."""
    return 0.5 * (1.0 + math.erf(x / (sigma * math.sqrt(2.0))))


def _int_pdf(a: float, b: float, sigma: float) -> float:
    """∫[a,b] N(0,σ²)(x) dx — closed form via erf."""
    return _gauss_cdf(b, sigma) - _gauss_cdf(a, sigma)


def _int_x_pdf(a: float, b: float, sigma: float) -> float:
    """∫[a,b] x·N(0,σ²)(x) dx = σ²·[f(a) − f(b)]."""
    return sigma * sigma * (_gauss_pdf(a, sigma) - _gauss_pdf(b, sigma))


def _int_sq_pdf(a: float, b: float, sigma: float, c: float) -> float:
    """∫[a,b] (x−c)²·N(0,σ²)(x) dx — closed form."""
    fa, fb = _gauss_pdf(a, sigma), _gauss_pdf(b, sigma)
    cdf_diff = _gauss_cdf(b, sigma) - _gauss_cdf(a, sigma)
    sig2 = sigma * sigma
    return (
        sig2 * (a * fa - b * fb)
        - 2.0 * c * sig2 * (fa - fb)
        + (sig2 + c * c) * cdf_diff
    )


def _quad(f, a: float, b: float, n: int = 200) -> float:
    """Composite Simpson's rule numerical integration over [a, b].

    Used only for the ``use_exact=True`` (Beta-PDF) path; the Gaussian path
    uses closed-form helpers above.
    """
    if n % 2 != 0:
        n += 1
    h = (b - a) / n
    s = f(a) + f(b)
    for i in range(1, n):
        s += (4 if i % 2 else 2) * f(a + i * h)
    return h / 3.0 * s


def beta_pdf(x: float, d: int) -> float:
    """PDF of a single coordinate after random rotation of a d-dim unit vector."""
    if abs(x) >= 1.0:
        return 0.0
    coeff = math.gamma(d / 2) / (math.sqrt(math.pi) * math.gamma((d - 1) / 2))
    return coeff * (1 - x * x) ** ((d - 3) / 2)


def gaussian_approx_pdf(x: float, d: int) -> float:
    """Gaussian approximation N(0, 1/d) -- accurate for d >= 64."""
    sigma2 = 1.0 / d
    return (1.0 / math.sqrt(2 * math.pi * sigma2)) * math.exp(-x * x / (2 * sigma2))


def solve_lloyd_max(
    d: int, bits: int, use_exact: bool = False, max_iter: int = 200, tol: float = 1e-10
):
    """
    Solve Lloyd-Max optimal quantizer for the coordinate distribution.

    Args:
        d: vector dimension
        bits: number of quantization bits
        use_exact: if True, use exact Beta PDF; if False, use Gaussian approx
        max_iter: maximum Lloyd-Max iterations
        tol: convergence tolerance

    Returns:
        centroids: sorted tensor of 2^bits optimal centroids
        boundaries: sorted tensor of 2^bits - 1 boundaries between centroids
    """
    n_levels = 2**bits
    sigma = 1.0 / math.sqrt(d)

    lo, hi = -3.5 * sigma, 3.5 * sigma
    centroids = [lo + (hi - lo) * (i + 0.5) / n_levels for i in range(n_levels)]

    for _ in range(max_iter):
        boundaries = [
            (centroids[i] + centroids[i + 1]) / 2.0 for i in range(n_levels - 1)
        ]
        edges = [lo * 3] + boundaries + [hi * 3]
        new_centroids = []
        for i in range(n_levels):
            a, b = edges[i], edges[i + 1]

            if use_exact:
                numerator = _quad(lambda x: x * beta_pdf(x, d), a, b)
                denominator = _quad(lambda x: beta_pdf(x, d), a, b)
            else:
                numerator = _int_x_pdf(a, b, sigma)
                denominator = _int_pdf(a, b, sigma)

            if denominator > 1e-15:
                new_centroids.append(numerator / denominator)
            else:
                new_centroids.append(centroids[i])

        max_shift = max(abs(new_centroids[i] - centroids[i]) for i in range(n_levels))
        centroids = new_centroids

        if max_shift < tol:
            break

    boundaries = [(centroids[i] + centroids[i + 1]) / 2.0 for i in range(n_levels - 1)]

    return (
        torch.tensor(centroids, dtype=torch.float32),
        torch.tensor(boundaries, dtype=torch.float32),
    )


def compute_expected_distortion(
    d: int,
    bits: int,
    centroids: torch.Tensor,
    boundaries: torch.Tensor,
    use_exact: bool = False,
) -> float:
    """Compute the expected MSE distortion per coordinate for the given quantizer."""
    sigma = 1.0 / math.sqrt(d)
    n_levels = len(centroids)

    edges = [-3.5 * sigma * 3] + boundaries.tolist() + [3.5 * sigma * 3]
    total_distortion = 0.0

    for i in range(n_levels):
        a, b = edges[i], edges[i + 1]
        c = centroids[i].item()
        if use_exact:
            dist = _quad(lambda x, _c=c: (x - _c) ** 2 * beta_pdf(x, d), a, b)
        else:
            dist = _int_sq_pdf(a, b, sigma, c)
        total_distortion += dist

    return total_distortion


class LloydMaxCodebook:
    """Precomputed Lloyd-Max codebook for a given dimension and bit-width."""

    def __init__(self, d: int, bits: int, use_exact: bool = False):
        self.d = d
        self.bits = bits
        self.n_levels = 2**bits
        self.centroids, self.boundaries = solve_lloyd_max(d, bits, use_exact)
        self.distortion = compute_expected_distortion(
            d, bits, self.centroids, self.boundaries, use_exact
        )

    def quantize(self, x: torch.Tensor) -> torch.Tensor:
        """Quantize values to nearest centroid indices."""
        diffs = x.unsqueeze(-1) - self.centroids.to(x.device)
        return diffs.abs().argmin(dim=-1)

    def dequantize(self, indices: torch.Tensor) -> torch.Tensor:
        """Map indices back to centroid values."""
        return self.centroids.to(indices.device)[indices]

    def __repr__(self):
        return (
            f"LloydMaxCodebook(d={self.d}, bits={self.bits}, "
            f"levels={self.n_levels}, distortion_per_coord={self.distortion:.6f})"
        )
