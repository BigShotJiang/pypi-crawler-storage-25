# Copyright 2026 Terrene Foundation
# SPDX-License-Identifier: Apache-2.0
"""QueryDialect strategy pattern for cross-database SQL generation.

Provides an abstract base class ``QueryDialect`` and concrete implementations
for PostgreSQL, MySQL, and SQLite.  The canonical placeholder is ``?``
(SQLite style); ``translate_query`` converts to the dialect's native format.

This module has **zero** external dependencies — it generates SQL strings only.
"""

from __future__ import annotations

import logging
import re
from abc import ABC, abstractmethod
from enum import Enum
from typing import Any, Dict, List, Optional, Sequence, Tuple

from kailash.utils.url_credentials import mask_url

logger = logging.getLogger(__name__)

__all__ = [
    "DatabaseType",
    "IdentifierError",
    "QueryDialect",
    "PostgresDialect",
    "MySQLDialect",
    "SQLiteDialect",
    "detect_dialect",
]

_IDENTIFIER_RE = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_]*$")
_JSON_PATH_RE = re.compile(r"^[a-zA-Z0-9_.]+$")


class IdentifierError(ValueError):
    """Raised when a SQL identifier fails safety validation.

    Subclasses ``ValueError`` so existing call sites that catch
    ``ValueError`` (e.g. `_validate_identifier` raisers) continue to
    work. Error messages NEVER echo the raw input verbatim — they
    use a fingerprint hash (`hash(name) & 0xFFFF:04x`) to prevent
    log poisoning / stored-XSS-via-error-message.

    Per ``rules/dataflow-identifier-safety.md`` MUST Rule 2, the
    quote-identifier contract requires distinct typed error surfaces
    so DDL-layer callers can distinguish identifier-validation
    failures from unrelated ``ValueError`` raises in surrounding
    code.
    """

    pass


def _identifier_fingerprint(name: object) -> str:
    """Return a 4-hex-digit fingerprint of *name* safe on unhashable inputs.

    The fingerprint is a stable, non-reversible tag that lets operators
    correlate errors in logs without echoing the raw (possibly malicious)
    payload. Unhashable inputs (``dict``, ``list``, ``set``) that would
    otherwise crash ``hash()`` are fingerprinted as ``"____"`` so the
    caller can still raise a typed ``ValueError`` with a useful marker.
    """
    try:
        return f"{hash(name) & 0xFFFF:04x}"
    except TypeError:
        return "____"


def _validate_identifier(name: str, *, max_length: int = 128) -> None:
    """Validate a SQL identifier (table or column name).

    This is the validate-only primitive for sites that interpolate
    an identifier into SQL WITHOUT wrapping it in dialect quotes —
    for example, `upsert` column lists where the SET clause embeds
    bare column names (`col = EXCLUDED.col`), or hardcoded-identifier
    lists that defense-in-depth validate per
    ``rules/dataflow-identifier-safety.md`` Rule 5.

    DDL paths that interpolate dynamic identifiers into statements
    like ``CREATE INDEX``, ``CREATE TABLE``, ``ALTER TABLE``, or
    ``DROP`` MUST use ``dialect.quote_identifier(name)`` instead —
    which both validates AND wraps in dialect-appropriate quotes
    (per ``rules/dataflow-identifier-safety.md`` MUST Rule 1).

    Parameters
    ----------
    name
        The identifier to validate.
    max_length
        Maximum allowed length (default 128, the SQLite limit;
        PostgreSQL is 63, MySQL is 64).

    Raises
    ------
    IdentifierError
        (``ValueError`` subclass) if *name* is not a string,
        exceeds the length limit, or contains characters that
        could enable SQL injection. Unhashable non-string inputs
        (``dict``, ``list``, ``set``) raise ``IdentifierError`` —
        NOT ``TypeError`` — because the fingerprint helper is
        safe on unhashable values.
    """
    if not isinstance(name, str):
        raise IdentifierError(
            f"Invalid SQL identifier "
            f"(fingerprint={_identifier_fingerprint(name)}): "
            f"must be a string, got {type(name).__name__}"
        )
    if len(name) > max_length:
        raise IdentifierError(
            f"Invalid SQL identifier "
            f"(fingerprint={_identifier_fingerprint(name)}): "
            f"exceeds {max_length}-char limit (len={len(name)})"
        )
    if not _IDENTIFIER_RE.match(name):
        raise IdentifierError(
            f"Invalid SQL identifier "
            f"(fingerprint={_identifier_fingerprint(name)}): "
            "must match [a-zA-Z_][a-zA-Z0-9_]*"
        )


def _quote_identifier_impl(
    name: str,
    *,
    max_length: int,
    quote_char: str,
) -> str:
    """Validate *name* against the allowlist regex AND wrap it in
    *quote_char* for dialect-appropriate identifier quoting.

    Contract per ``rules/dataflow-identifier-safety.md`` MUST Rule 2:

    1. **Validate** against ``^[a-zA-Z_][a-zA-Z0-9_]*$`` (baseline).
    2. **Reject** — the raise does NOT echo the raw input; only a
       fingerprint hash is emitted for forensic correlation.
    3. **Check length** against *max_length* (PG 63 / MySQL 64 /
       SQLite 128).
    4. **Quote** with *quote_char* (``"`` for PG/SQLite, ``\u0060``
       for MySQL).
    5. **Do NOT escape** embedded quote characters — invalid
       inputs are rejected outright.
    """
    if not isinstance(name, str):
        raise IdentifierError(
            f"Invalid SQL identifier "
            f"(fingerprint={_identifier_fingerprint(name)}): "
            f"must be a string, got {type(name).__name__}"
        )
    if len(name) > max_length:
        raise IdentifierError(
            f"Invalid SQL identifier "
            f"(fingerprint={_identifier_fingerprint(name)}): "
            f"exceeds {max_length}-char limit (len={len(name)})"
        )
    if not _IDENTIFIER_RE.match(name):
        raise IdentifierError(
            f"Invalid SQL identifier "
            f"(fingerprint={_identifier_fingerprint(name)}): "
            "must match [a-zA-Z_][a-zA-Z0-9_]*"
        )
    return f"{quote_char}{name}{quote_char}"


def _validate_json_path(path: str) -> None:
    """Validate a JSON extraction path.

    Raises
    ------
    ValueError
        If *path* contains characters that could enable SQL injection.
    """
    if not _JSON_PATH_RE.match(path):
        raise ValueError(
            f"Invalid JSON path "
            f"(fingerprint={hash(path) & 0xFFFF:04x}): "
            "must match [a-zA-Z0-9_.]+"
        )


# ---------------------------------------------------------------------------
# DatabaseType enum
# ---------------------------------------------------------------------------
class DatabaseType(Enum):
    """Supported database engine types."""

    POSTGRESQL = "postgresql"
    MYSQL = "mysql"
    SQLITE = "sqlite"


# ---------------------------------------------------------------------------
# Abstract base
# ---------------------------------------------------------------------------
class QueryDialect(ABC):
    """Abstract base for database dialect translation.

    Subclasses implement SQL generation methods that produce dialect-specific
    SQL strings.  The canonical placeholder character is ``?``.
    """

    @property
    @abstractmethod
    def database_type(self) -> DatabaseType:
        """Return the :class:`DatabaseType` for this dialect."""

    @abstractmethod
    def placeholder(self, index: int) -> str:
        """Return the parameter placeholder for the given 0-based *index*.

        PostgreSQL: ``$1``, ``$2``, ...
        MySQL: ``%s``
        SQLite: ``?``
        """

    @abstractmethod
    def quote_identifier(self, name: str) -> str:
        """Validate *name* and return it wrapped in dialect-appropriate
        identifier quotes.

        This is the canonical helper for every DDL path that
        interpolates a dynamic identifier — ``CREATE TABLE``,
        ``CREATE INDEX``, ``ALTER TABLE``, ``DROP`` — per
        ``rules/dataflow-identifier-safety.md`` MUST Rule 1.

        Contract per MUST Rule 2:

        - PostgreSQL / SQLite: wraps in ``"``; max length 63 / 128.
        - MySQL: wraps in ``\u0060`` (backtick); max length 64.
        - Raises :class:`IdentifierError` on invalid input; error
          message does NOT echo the raw identifier.
        """

    def translate_query(self, query: str) -> str:
        """Translate a query with ``?`` placeholders to dialect-specific form.

        The default implementation calls :meth:`placeholder` for each ``?``
        found in *query*.  Subclasses that use ``?`` natively (SQLite) can
        override with a no-op for efficiency.
        """
        counter = 0

        def _replace(match: re.Match) -> str:
            nonlocal counter
            result = self.placeholder(counter)
            counter += 1
            return result

        return re.sub(r"\?", _replace, query)

    @abstractmethod
    def upsert(
        self,
        table: str,
        columns: List[str],
        conflict_keys: List[str],
        update_columns: Optional[List[str]] = None,
    ) -> Tuple[str, List[str]]:
        """Generate an upsert statement.

        Parameters
        ----------
        table:
            Target table name.
        columns:
            All columns being inserted (including conflict keys).
        conflict_keys:
            Columns that form the unique constraint.
        update_columns:
            Columns to update on conflict.  Defaults to all *columns* that
            are **not** in *conflict_keys*.

        Returns
        -------
        tuple[str, list[str]]
            ``(sql_template, param_columns)`` where *sql_template* uses
            dialect-specific placeholders and *param_columns* lists the
            column names in parameter-binding order.
        """

    def insert_ignore(
        self, table: str, columns: List[str], conflict_keys: List[str]
    ) -> str:
        """Generate INSERT ... ignore-on-conflict statement.

        PostgreSQL/SQLite: ``INSERT INTO ... ON CONFLICT (keys) DO NOTHING``
        MySQL: ``INSERT IGNORE INTO ...``

        Returns SQL with ``?`` placeholders.
        """
        _validate_identifier(table)
        for col in columns:
            _validate_identifier(col)
        for key in conflict_keys:
            _validate_identifier(key)
        cols = ", ".join(columns)
        placeholders = ", ".join(["?"] * len(columns))
        conflict = ", ".join(conflict_keys)
        return f"INSERT INTO {table} ({cols}) VALUES ({placeholders}) ON CONFLICT ({conflict}) DO NOTHING"

    def auto_id_column(self) -> str:
        """Return the auto-incrementing primary key column DDL fragment.

        PostgreSQL: ``id SERIAL PRIMARY KEY``
        MySQL: ``id INTEGER PRIMARY KEY AUTO_INCREMENT``
        SQLite: ``id INTEGER PRIMARY KEY``
        """
        return "id INTEGER PRIMARY KEY"

    def text_column(self, indexed: bool = False) -> str:
        """Return the text column type.

        For indexed columns, MySQL requires ``VARCHAR(255)`` instead of
        ``TEXT`` because MySQL cannot index ``TEXT`` without a key length.

        Parameters
        ----------
        indexed:
            If ``True``, returns a type suitable for use in indexes/unique
            constraints.  Default ``False`` returns unbounded ``TEXT``.
        """
        return "TEXT"

    def boolean_default(self, value: bool) -> str:
        """Return a boolean default expression.

        PostgreSQL: ``DEFAULT TRUE`` / ``DEFAULT FALSE``
        MySQL/SQLite: ``DEFAULT 1`` / ``DEFAULT 0``
        """
        return f"DEFAULT {1 if value else 0}"

    def blob_type(self) -> str:
        """Return the binary data column type.

        PostgreSQL: ``BYTEA``, MySQL/SQLite: ``BLOB``.
        """
        return "BLOB"

    def double_precision_type(self) -> str:
        """Return the 8-byte (IEEE 754 double-precision) float column type.

        Required for storing ``time.time()`` values without truncation:
        Python's ``time.time()`` returns a 64-bit double, but PostgreSQL
        ``REAL`` is a 4-byte single-precision float and silently truncates
        current epoch values by ~50 seconds.  Anything storing a Unix
        timestamp via ``time.time()`` MUST use this type.

        - PostgreSQL: ``DOUBLE PRECISION`` (8 bytes)
        - MySQL: ``DOUBLE`` (8 bytes)
        - SQLite: ``REAL`` (8 bytes per SQLite docs — REAL IS double-
          precision in SQLite, despite the name overlap with Postgres'
          4-byte REAL)

        See ``rules/infrastructure-sql.md`` § 4 ("dialect.blob_type() not
        hardcoded BLOB") — same dialect-portability discipline.
        """
        return "DOUBLE PRECISION"

    @abstractmethod
    def json_column_type(self) -> str:
        """Return the native JSON column type.

        PostgreSQL: ``JSONB``, MySQL: ``JSON``, SQLite: ``TEXT``.
        """

    @abstractmethod
    def json_extract(self, column: str, path: str) -> str:
        """Generate a JSON field extraction expression.

        PostgreSQL: ``column->>'path'``
        MySQL: ``JSON_EXTRACT(column, '$.path')``
        SQLite: ``json_extract(column, '$.path')``
        """

    @abstractmethod
    def for_update_skip_locked(self) -> str:
        """Return the row-level locking clause for task-queue dequeue.

        PostgreSQL/MySQL: ``FOR UPDATE SKIP LOCKED``
        SQLite: ``""`` (use ``BEGIN IMMEDIATE`` instead)
        """

    @abstractmethod
    def timestamp_now(self) -> str:
        """Return the current-timestamp expression.

        PostgreSQL/MySQL: ``NOW()``
        SQLite: ``datetime('now')``
        """


# ---------------------------------------------------------------------------
# PostgresDialect
# ---------------------------------------------------------------------------
class PostgresDialect(QueryDialect):
    """PostgreSQL dialect — uses ``$1, $2, ...`` numbered placeholders."""

    _MAX_IDENTIFIER_LENGTH = 63  # PostgreSQL NAMEDATALEN - 1
    _QUOTE_CHAR = '"'

    @property
    def database_type(self) -> DatabaseType:
        return DatabaseType.POSTGRESQL

    def placeholder(self, index: int) -> str:
        return f"${index + 1}"

    def quote_identifier(self, name: str) -> str:
        return _quote_identifier_impl(
            name,
            max_length=self._MAX_IDENTIFIER_LENGTH,
            quote_char=self._QUOTE_CHAR,
        )

    # translate_query inherited from base — replaces ? with $N

    def upsert(
        self,
        table: str,
        columns: List[str],
        conflict_keys: List[str],
        update_columns: Optional[List[str]] = None,
    ) -> Tuple[str, List[str]]:
        _validate_identifier(table)
        for col in columns:
            _validate_identifier(col)
        for key in conflict_keys:
            _validate_identifier(key)
        if update_columns is None:
            update_columns = [c for c in columns if c not in conflict_keys]
        for col in update_columns:
            _validate_identifier(col)

        placeholders = ", ".join(self.placeholder(i) for i in range(len(columns)))
        col_list = ", ".join(columns)
        conflict_list = ", ".join(conflict_keys)
        update_set = ", ".join(f"{c} = EXCLUDED.{c}" for c in update_columns)

        sql = (
            f"INSERT INTO {table} ({col_list}) VALUES ({placeholders}) "
            f"ON CONFLICT ({conflict_list}) DO UPDATE SET {update_set}"
        )
        return sql, list(columns)

    def auto_id_column(self) -> str:
        return "id SERIAL PRIMARY KEY"

    def boolean_default(self, value: bool) -> str:
        return f"DEFAULT {'TRUE' if value else 'FALSE'}"

    def blob_type(self) -> str:
        return "BYTEA"

    def json_column_type(self) -> str:
        return "JSONB"

    def json_extract(self, column: str, path: str) -> str:
        _validate_identifier(column)
        _validate_json_path(path)
        return f"{column}->>'{path}'"

    def for_update_skip_locked(self) -> str:
        return "FOR UPDATE SKIP LOCKED"

    def timestamp_now(self) -> str:
        return "NOW()"


# ---------------------------------------------------------------------------
# MySQLDialect
# ---------------------------------------------------------------------------
class MySQLDialect(QueryDialect):
    """MySQL dialect — uses ``%s`` positional placeholders."""

    _MAX_IDENTIFIER_LENGTH = 64  # MySQL identifier length limit
    _QUOTE_CHAR = "`"

    @property
    def database_type(self) -> DatabaseType:
        return DatabaseType.MYSQL

    def placeholder(self, index: int) -> str:
        return "%s"

    def quote_identifier(self, name: str) -> str:
        return _quote_identifier_impl(
            name,
            max_length=self._MAX_IDENTIFIER_LENGTH,
            quote_char=self._QUOTE_CHAR,
        )

    # translate_query inherited from base — replaces ? with %s

    def upsert(
        self,
        table: str,
        columns: List[str],
        conflict_keys: List[str],
        update_columns: Optional[List[str]] = None,
    ) -> Tuple[str, List[str]]:
        _validate_identifier(table)
        for col in columns:
            _validate_identifier(col)
        for key in conflict_keys:
            _validate_identifier(key)
        if update_columns is None:
            update_columns = [c for c in columns if c not in conflict_keys]
        for col in update_columns:
            _validate_identifier(col)

        placeholders = ", ".join(self.placeholder(i) for i in range(len(columns)))
        col_list = ", ".join(columns)
        update_set = ", ".join(f"{c} = VALUES({c})" for c in update_columns)

        sql = (
            f"INSERT INTO {table} ({col_list}) VALUES ({placeholders}) "
            f"ON DUPLICATE KEY UPDATE {update_set}"
        )
        return sql, list(columns)

    def insert_ignore(
        self, table: str, columns: List[str], conflict_keys: List[str]
    ) -> str:
        _validate_identifier(table)
        for col in columns:
            _validate_identifier(col)
        for key in conflict_keys:
            _validate_identifier(key)
        cols = ", ".join(columns)
        placeholders = ", ".join(["?"] * len(columns))
        return f"INSERT IGNORE INTO {table} ({cols}) VALUES ({placeholders})"

    def auto_id_column(self) -> str:
        return "id INTEGER PRIMARY KEY AUTO_INCREMENT"

    def text_column(self, indexed: bool = False) -> str:
        return "VARCHAR(255)" if indexed else "TEXT"

    def blob_type(self) -> str:
        return "LONGBLOB"

    def double_precision_type(self) -> str:
        """MySQL: ``DOUBLE`` (8-byte IEEE 754 float).

        ``DOUBLE PRECISION`` is also valid in MySQL but is an alias for
        ``DOUBLE``; we emit the canonical short form.  See base
        :meth:`QueryDialect.double_precision_type` for the rationale.
        """
        return "DOUBLE"

    def create_index_prefix(self) -> str:
        """Return the CREATE INDEX statement prefix.

        MySQL does not support ``IF NOT EXISTS`` on ``CREATE INDEX``.
        """
        return "CREATE INDEX"

    def json_column_type(self) -> str:
        return "JSON"

    def json_extract(self, column: str, path: str) -> str:
        _validate_identifier(column)
        _validate_json_path(path)
        return f"JSON_EXTRACT({column}, '$.{path}')"

    def for_update_skip_locked(self) -> str:
        return "FOR UPDATE SKIP LOCKED"

    def timestamp_now(self) -> str:
        return "NOW()"


# ---------------------------------------------------------------------------
# SQLiteDialect
# ---------------------------------------------------------------------------
class SQLiteDialect(QueryDialect):
    """SQLite dialect — uses ``?`` positional placeholders (canonical)."""

    _MAX_IDENTIFIER_LENGTH = 128  # SQLite practical limit
    _QUOTE_CHAR = '"'

    @property
    def database_type(self) -> DatabaseType:
        return DatabaseType.SQLITE

    def placeholder(self, index: int) -> str:
        return "?"

    def quote_identifier(self, name: str) -> str:
        return _quote_identifier_impl(
            name,
            max_length=self._MAX_IDENTIFIER_LENGTH,
            quote_char=self._QUOTE_CHAR,
        )

    def translate_query(self, query: str) -> str:
        """SQLite uses ``?`` natively — identity translation."""
        return query

    def upsert(
        self,
        table: str,
        columns: List[str],
        conflict_keys: List[str],
        update_columns: Optional[List[str]] = None,
    ) -> Tuple[str, List[str]]:
        _validate_identifier(table)
        for col in columns:
            _validate_identifier(col)
        for key in conflict_keys:
            _validate_identifier(key)
        if update_columns is None:
            update_columns = [c for c in columns if c not in conflict_keys]
        for col in update_columns:
            _validate_identifier(col)

        placeholders = ", ".join("?" for _ in columns)
        col_list = ", ".join(columns)
        conflict_list = ", ".join(conflict_keys)
        update_set = ", ".join(f"{c} = excluded.{c}" for c in update_columns)

        sql = (
            f"INSERT INTO {table} ({col_list}) VALUES ({placeholders}) "
            f"ON CONFLICT ({conflict_list}) DO UPDATE SET {update_set}"
        )
        return sql, list(columns)

    def json_column_type(self) -> str:
        return "TEXT"

    def double_precision_type(self) -> str:
        """SQLite: ``REAL`` (8-byte IEEE 754 float per SQLite docs).

        Note the dialect difference: SQLite's ``REAL`` IS double-precision
        (8 bytes) per the SQLite type-affinity rules, while PostgreSQL's
        ``REAL`` is single-precision (4 bytes) and would truncate
        ``time.time()`` values.  This override emits the SQLite-native
        spelling; PostgreSQL/MySQL use the base/MySQL overrides.
        """
        return "REAL"

    def json_extract(self, column: str, path: str) -> str:
        _validate_identifier(column)
        _validate_json_path(path)
        return f"json_extract({column}, '$.{path}')"

    def for_update_skip_locked(self) -> str:
        return ""

    def timestamp_now(self) -> str:
        return "datetime('now')"


# ---------------------------------------------------------------------------
# detect_dialect()
# ---------------------------------------------------------------------------
def detect_dialect(url: str) -> QueryDialect:
    """Auto-detect the appropriate dialect from a database URL.

    Parameters
    ----------
    url:
        A database connection URL.  Supported schemes:

        * ``postgresql://`` or ``postgres://`` (including ``+asyncpg`` driver)
        * ``mysql://`` (including ``+aiomysql`` driver)
        * ``sqlite:///`` (including ``:///:memory:``)
        * A plain file path (treated as SQLite)

    Returns
    -------
    QueryDialect
        The dialect instance for the detected database.

    Raises
    ------
    ValueError
        If *url* is empty or uses an unsupported scheme.
    TypeError
        If *url* is not a string.
    """
    if not isinstance(url, str):
        raise TypeError(f"Database URL must be a string, got {type(url).__name__}")

    if not url.strip():
        raise ValueError(
            "Database URL must not be empty. Set KAILASH_DATABASE_URL or "
            "DATABASE_URL, or pass a URL explicitly."
        )

    url_lower = url.lower()

    # PostgreSQL
    if url_lower.startswith(("postgresql://", "postgresql+", "postgres://")):
        logger.debug("Detected PostgreSQL dialect from URL: %s", mask_url(url))
        return PostgresDialect()

    # MySQL
    if url_lower.startswith(("mysql://", "mysql+")):
        logger.debug("Detected MySQL dialect from URL: %s", mask_url(url))
        return MySQLDialect()

    # SQLite
    if url_lower.startswith("sqlite://"):
        logger.debug("Detected SQLite dialect from URL: %s", mask_url(url))
        return SQLiteDialect()

    # Plain file path (relative or absolute) -> SQLite
    if url.startswith(("/", "./", "../")) or not re.match(
        r"^[a-zA-Z][a-zA-Z0-9+.-]*://", url
    ):
        logger.debug(
            "No scheme detected; treating as SQLite file path: %s", mask_url(url)
        )
        return SQLiteDialect()

    # Unknown scheme
    scheme = url.split("://", 1)[0]
    raise ValueError(
        f"Unsupported database URL scheme '{scheme}'. "
        f"Supported: postgresql, mysql, sqlite, or a file path for SQLite."
    )
