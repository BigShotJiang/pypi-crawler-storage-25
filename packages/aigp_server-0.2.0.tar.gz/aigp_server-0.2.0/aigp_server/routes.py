"""AIGP Server Routes — framework-agnostic handler functions.

These return (status_code, response_dict) tuples. The host application
(GOV_APP, RUN_PRJ) wraps them in its framework's response type.
"""

import json
import logging

from .governance_engine import GovernanceEngine
from .hmac_auth import verify_hmac

logger = logging.getLogger(__name__)


class AigpRouter:
    """Stateless router that delegates to GovernanceEngine."""

    def __init__(self, engine: GovernanceEngine, hmac_secret: str = ""):
        self.engine = engine
        self.secret = hmac_secret

    def _verify(self, headers: dict, body: bytes) -> dict | None:
        """Verify HMAC and parse body. Returns parsed dict or None."""
        if self.secret and not verify_hmac(headers, body, self.secret):
            return None
        try:
            return json.loads(body)
        except (json.JSONDecodeError, ValueError):
            return None

    async def handle_tool_request(self, headers: dict, body: bytes) -> tuple[int, dict]:
        msg = self._verify(headers, body)
        if msg is None:
            return 401, {"error": "unauthorized"}
        result = await self.engine.handle_tool_request(msg)
        await self.engine.db.put_audit(msg.get("agent_id", ""), "TOOL_REQUEST", result["decision"], {"tool_id": msg.get("tool_id"), "reason": result.get("reason")})
        return 200, result

    async def handle_plan_submit(self, headers: dict, body: bytes) -> tuple[int, dict]:
        msg = self._verify(headers, body)
        if msg is None:
            return 401, {"error": "unauthorized"}
        result = await self.engine.handle_plan_submit(msg)
        await self.engine.db.put_audit(msg.get("agent_id", ""), "PLAN_SUBMIT", result["decision"], msg)
        return 200, result

    async def handle_step_complete(self, headers: dict, body: bytes) -> tuple[int, dict]:
        msg = self._verify(headers, body)
        if msg is None:
            return 401, {"error": "unauthorized"}
        result = await self.engine.handle_step_complete(msg)
        await self.engine.db.put_audit(msg.get("agent_id", ""), "STEP_COMPLETE", msg.get("status", ""), msg)
        return 200, result

    async def handle_escalate(self, headers: dict, body: bytes) -> tuple[int, dict]:
        msg = self._verify(headers, body)
        if msg is None:
            return 401, {"error": "unauthorized"}
        result = await self.engine.handle_escalate(msg)
        await self.engine.db.put_audit(msg.get("agent_id", ""), "ESCALATE", result.get("status", ""), msg)
        return 200, result

    async def handle_delegate(self, headers: dict, body: bytes) -> tuple[int, dict]:
        msg = self._verify(headers, body)
        if msg is None:
            return 401, {"error": "unauthorized"}
        result = await self.engine.handle_delegate(msg)
        await self.engine.db.put_audit(msg.get("delegating_agent_id", ""), "DELEGATE", result["decision"], msg)
        return 200, result

    async def handle_memory_write(self, headers: dict, body: bytes) -> tuple[int, dict]:
        msg = self._verify(headers, body)
        if msg is None:
            return 401, {"error": "unauthorized"}
        result = await self.engine.handle_memory_write(msg)
        await self.engine.db.put_audit(msg.get("agent_id", ""), "MEMORY_WRITE", result["decision"], msg)
        return 200, result
