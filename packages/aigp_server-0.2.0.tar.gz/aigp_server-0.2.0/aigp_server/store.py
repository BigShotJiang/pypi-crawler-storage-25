"""Storage protocol — abstract interface that host applications must implement."""

from __future__ import annotations

from abc import ABC, abstractmethod


class GovernanceStore(ABC):
    """Abstract storage backend for the AIGP governance server.

    Host applications (GOV_APP, RUN_PRJ) implement this interface
    to provide persistence for scope envelopes, circuit breakers,
    budgets, delegations, audits, and tasks.
    """

    # --- Scope Envelopes ---

    @abstractmethod
    async def put_scope_envelope(self, envelope: dict) -> None: ...

    @abstractmethod
    async def get_scope_envelope(self, envelope_id: str) -> dict | None: ...

    @abstractmethod
    async def get_active_scope(self, agent_id: str) -> dict | None: ...

    @abstractmethod
    async def update_scope_envelope(self, envelope_id: str, updates: dict) -> None: ...

    @abstractmethod
    async def query_scopes(self, agent_id: str) -> list[dict]: ...

    # --- Circuit Breaker ---

    @abstractmethod
    async def get_circuit_breaker(self, agent_id: str) -> dict | None: ...

    @abstractmethod
    async def put_circuit_breaker(self, agent_id: str, state: dict) -> None: ...

    @abstractmethod
    async def update_circuit_breaker(self, agent_id: str, updates: dict) -> None: ...

    # --- Budget ---

    @abstractmethod
    async def increment_budget(self, agent_id: str, actions: int = 0, tokens: int = 0) -> None: ...

    @abstractmethod
    async def get_budget_remaining(self, agent_id: str) -> dict: ...

    # --- Delegation ---

    @abstractmethod
    async def put_delegation(self, delegation: dict) -> None: ...

    @abstractmethod
    async def get_delegates(self, agent_id: str) -> list[dict]: ...

    # --- Agent ---

    @abstractmethod
    async def get_agent(self, agent_id: str) -> dict | None: ...

    # --- Tasks (escalations, approvals) ---

    @abstractmethod
    async def put_task(self, task: dict) -> str: ...

    # --- Audit ---

    @abstractmethod
    async def put_audit(self, agent_id: str, action: str, decision: str, details: dict) -> None: ...

    # --- Run Steps ---

    @abstractmethod
    async def put_run_step(self, run_id: str, step: dict) -> None: ...
