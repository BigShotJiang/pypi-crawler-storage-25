"""AIGP Server — Agentic Governance Engine with provider-based architecture.

Usage (new — config-driven):
    from aigp_server import ServerConfig

    config = ServerConfig(
        storage={"provider": "memory"},
        pii={"provider": "regex"},
        key_store={"provider": "local"},
        mode="ENFORCE",
    )
    components = config.build()
    engine = GovernanceEngine(components.store, components.scope_mgr, components.circuit_breaker, mode="ENFORCE")
    router = AigpRouter(engine, hmac_secret="...")

Usage (backward compat — still works):
    from aigp_server import GovernanceEngine, GovernanceStore, AigpRouter

    class MyStore(GovernanceStore): ...
    store = MyStore()
    engine = GovernanceEngine(store, ScopeEnvelopeManager(store), CircuitBreakerService(store))
    router = AigpRouter(engine)
"""

__version__ = "0.2.0"

# Backward compat — original flat imports
from .governance_engine import GovernanceEngine
from .routes import AigpRouter
from .hmac_auth import verify_hmac, sign_request

# Provider-based (new)
from .providers.storage import StorageProviderBase, GovernanceStore
from .providers.scope import ScopeEnvelopeManager, CircuitBreakerService, TEMPLATES
from .providers.enforcement import EnforcementAdapterBase
from .providers.pii import PiiDetectorBase, PiiEntity
from .providers.key_store import KeyStoreBase
from .providers.consent import ConsentEngine, TokenMap
from .config import ServerConfig, ServerComponents

__all__ = [
    # Engine + Router
    "GovernanceEngine", "AigpRouter",
    # Auth
    "verify_hmac", "sign_request",
    # Storage
    "StorageProviderBase", "GovernanceStore",
    # Scope
    "ScopeEnvelopeManager", "CircuitBreakerService", "TEMPLATES",
    # Enforcement
    "EnforcementAdapterBase",
    # PII
    "PiiDetectorBase", "PiiEntity",
    # Key Store
    "KeyStoreBase",
    # Consent
    "ConsentEngine", "TokenMap",
    # Config
    "ServerConfig", "ServerComponents",
]
