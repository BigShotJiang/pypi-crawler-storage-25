"""Server configuration — provider selection and initialization."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from .providers.storage import create as create_storage, StorageProviderBase
from .providers.scope import ScopeEnvelopeManager, CircuitBreakerService
from .providers.enforcement import create as create_enforcement, EnforcementAdapterBase
from .providers.pii import create as create_pii, PiiDetectorBase
from .providers.key_store import create as create_key_store, KeyStoreBase
from .providers.consent import ConsentEngine


@dataclass
class ServerConfig:
    """Configuration for the AIGP governance server.

    Example:
        config = ServerConfig(
            storage={"provider": "memory"},
            pii={"provider": "regex"},
            key_store={"provider": "local"},
            enforcement={"provider": "bedrock", "region": "us-east-1"},
            mode="ENFORCE",
        )
        server = config.build()
    """
    storage: dict = field(default_factory=lambda: {"provider": "memory"})
    pii: dict = field(default_factory=lambda: {"provider": "regex"})
    key_store: dict = field(default_factory=lambda: {"provider": "local"})
    enforcement: dict | None = None
    consent_default_tier: str = "STANDARD"
    mode: str = "REPORT"

    def build(self) -> "ServerComponents":
        """Build all server components from config."""
        # Storage
        storage_provider = self.storage.pop("provider", "memory")
        store = create_storage(storage_provider, **self.storage)

        # PII
        pii_provider = self.pii.pop("provider", "regex")
        pii = create_pii(pii_provider, **self.pii)

        # Key store
        ks_provider = self.key_store.pop("provider", "local")
        key_store = create_key_store(ks_provider, **self.key_store)

        # Consent engine
        consent = ConsentEngine(pii, key_store, self.consent_default_tier)

        # Enforcement (optional)
        enforcement = None
        if self.enforcement:
            enf_provider = self.enforcement.pop("provider")
            enforcement = create_enforcement(enf_provider, **self.enforcement)

        # Scope + Circuit Breaker
        scope_mgr = ScopeEnvelopeManager(store)
        circuit_breaker = CircuitBreakerService(store)

        return ServerComponents(
            store=store, scope_mgr=scope_mgr, circuit_breaker=circuit_breaker,
            consent=consent, pii=pii, key_store=key_store,
            enforcement=enforcement, mode=self.mode,
        )


@dataclass
class ServerComponents:
    """Fully initialized server components."""
    store: StorageProviderBase
    scope_mgr: ScopeEnvelopeManager
    circuit_breaker: CircuitBreakerService
    consent: ConsentEngine
    pii: PiiDetectorBase
    key_store: KeyStoreBase
    enforcement: EnforcementAdapterBase | None
    mode: str
