"""Governance Engine — evaluates AIGP agentic messages against scope envelopes."""

import fnmatch
import logging
from datetime import datetime, timezone, timedelta
from uuid import uuid4

from .providers.scope.circuit_breaker import CircuitBreakerService
from .providers.scope.scope_manager import ScopeEnvelopeManager, _now, _expiry
from .providers.storage.storage_provider_base import StorageProviderBase as GovernanceStore

logger = logging.getLogger(__name__)


class GovernanceEngine:
    """Core AIGP decision engine. Mode: REPORT | REPORT-TRACE | ENFORCE."""

    def __init__(self, db: GovernanceStore, scope_mgr: ScopeEnvelopeManager,
                 circuit_breaker: CircuitBreakerService, mode: str = "REPORT"):
        self.db = db
        self.scope_mgr = scope_mgr
        self.cb = circuit_breaker
        self.mode = mode

    async def handle_tool_request(self, msg: dict) -> dict:
        agent_id = msg["agent_id"]
        tool_id = msg["tool_id"]

        if await self.cb.is_open(agent_id):
            return self._decision("DENY", "CIRCUIT_OPEN", agent_id, tool_id)

        envelope = await self.scope_mgr.get_active_envelope(agent_id)
        if not envelope:
            return self._decision("DENY", "NO_ACTIVE_SCOPE", agent_id, tool_id)

        tools_perm = envelope.get("permissions", {}).get("tools", {})
        if tool_id in tools_perm.get("denied", []):
            return self._decision("DENY", "TOOL_DENIED", agent_id, tool_id)
        if tools_perm.get("mode") == "allowlist" and tool_id not in tools_perm.get("allowed", []):
            return self._decision("DENY", "TOOL_NOT_IN_ALLOWLIST", agent_id, tool_id)

        budget = await self._check_budget(agent_id, envelope)
        if not budget["ok"]:
            return self._decision("DENY", f"BUDGET_DEPLETED:{budget['reason']}", agent_id, tool_id)

        await self.db.increment_budget(agent_id, actions=1)
        return self._decision("ALLOW", None, agent_id, tool_id, budget_remaining=budget["remaining"])

    async def handle_plan_submit(self, msg: dict) -> dict:
        agent_id = msg["agent_id"]
        envelope = await self.scope_mgr.get_active_envelope(agent_id)
        if not envelope:
            return {"decision": "REJECTED", "plan_id": msg.get("plan_id"), "reason": "NO_ACTIVE_SCOPE"}

        allowed_tools = set(envelope.get("permissions", {}).get("tools", {}).get("allowed", []))
        modifications = []
        for step in msg.get("steps", []):
            tool_id = step.get("tool_id", "")
            if tool_id and tool_id not in allowed_tools:
                return {"decision": "REJECTED", "plan_id": msg["plan_id"], "reason": f"Tool '{tool_id}' not in scope"}
            for gate in envelope.get("approval_gates", []):
                if fnmatch.fnmatch(tool_id, gate.get("action_pattern", "")):
                    modifications.append({"step_number": step["step_number"], "gate": gate["requires"], "reason": f"Matches: {gate['action_pattern']}"})

        if modifications:
            return {"decision": "APPROVED_WITH_MODIFICATIONS", "plan_id": msg["plan_id"], "modifications": modifications}
        return {"decision": "APPROVED", "plan_id": msg["plan_id"]}

    async def handle_step_complete(self, msg: dict) -> dict:
        agent_id = msg["agent_id"]
        await self.db.increment_budget(agent_id, tokens=msg.get("tokens_used", 0))
        await self.cb.record_outcome(agent_id, msg.get("status") == "SUCCESS")
        run_id = msg.get("plan_id", msg.get("run_id", ""))
        if run_id:
            await self.db.put_run_step(run_id, {"step_number": msg.get("step_number", 0), "status": msg.get("status", ""), "tokens_used": msg.get("tokens_used", 0)})
        return {"status": "recorded"}

    async def handle_escalate(self, msg: dict) -> dict:
        task_id = await self.db.put_task({
            "type": "ESCALATION", "agent_id": msg["agent_id"],
            "escalation_id": msg.get("escalation_id", f"esc-{uuid4().hex[:8]}"),
            "reason": msg.get("reason", ""), "action": msg.get("action", {}),
            "context": msg.get("context", {}),
            "timeout_seconds": msg.get("timeout_seconds", 300),
            "timeout_action": msg.get("timeout_action", "DENY"), "status": "PENDING",
        })
        return {"status": "PAUSED", "task_id": task_id}

    async def handle_delegate(self, msg: dict) -> dict:
        parent_id = msg["delegating_agent_id"]
        target_id = msg["target_agent_id"]
        chain = msg.get("delegation_chain", [])

        if len(chain) >= 5:
            return {"decision": "DENIED", "reason": "MAX_DELEGATION_DEPTH_EXCEEDED"}

        parent_scope = await self.scope_mgr.get_active_envelope(parent_id)
        if not parent_scope:
            return {"decision": "DENIED", "reason": "PARENT_NO_ACTIVE_SCOPE"}

        requested = msg.get("requested_scope", {})
        narrowed = self._intersect_scope(parent_scope, requested)
        ttl = narrowed["budgets"].get("max_ttl_seconds", 1800)

        await self.db.put_scope_envelope({
            "scope_envelope_id": f"del-{uuid4().hex[:12]}",
            "agent_id": target_id, "version": 1, "status": "ACTIVE",
            "permissions": narrowed["permissions"], "budgets": narrowed["budgets"],
            "autonomy_level": parent_scope.get("autonomy_level", "ACT_WITH_APPROVAL"),
            "delegation_chain": chain + [parent_id],
            "issued_at": _now(), "expires_at": _expiry(ttl),
        })
        await self.db.put_delegation({"delegating_agent_id": parent_id, "target_agent_id": target_id, "delegation_chain": chain + [parent_id]})
        return {"decision": "ALLOWED", "target_agent_id": target_id, "narrowed_scope": narrowed}

    async def handle_memory_write(self, msg: dict) -> dict:
        agent_id = msg["agent_id"]
        envelope = await self.scope_mgr.get_active_envelope(agent_id)
        if not envelope:
            return {"decision": "DENY", "reason": "NO_ACTIVE_SCOPE"}

        mem_scope = envelope.get("memory_scope", {})
        if not mem_scope.get("may_write", False):
            return {"decision": "DENY", "reason": "MEMORY_WRITE_NOT_PERMITTED"}

        classification = msg.get("data_classification", "HIGH")
        allowed = mem_scope.get("allowed_classifications", [])
        if allowed and classification not in allowed:
            return {"decision": "DENY", "reason": f"CLASSIFICATION_{classification}_NOT_ALLOWED"}

        max_ret = mem_scope.get("max_retention_seconds", 86400)
        return {"decision": "ALLOW", "actual_retention_seconds": min(msg.get("retention_seconds", 86400), max_ret), "isolation": mem_scope.get("isolation", "AGENT_PRIVATE")}

    def _decision(self, decision: str, reason: str | None, agent_id: str, tool_id: str, **extra) -> dict:
        result = {"decision": decision, "reason": reason, "agent_id": agent_id, "tool_id": tool_id, **extra}
        if self.mode in ("REPORT", "REPORT-TRACE") and decision == "DENY":
            result["decision"] = "ALLOW"
            result["report_only_denial"] = True
            result["original_decision"] = "DENY"
            result["original_reason"] = reason
        return result

    def _intersect_scope(self, parent: dict, requested: dict) -> dict:
        parent_tools = set(parent.get("permissions", {}).get("tools", {}).get("allowed", []))
        req_tools = set(requested.get("tools", []))
        narrowed_tools = list(parent_tools & req_tools) if req_tools else list(parent_tools)
        parent_budgets = parent.get("budgets", {})
        return {
            "permissions": {"tools": {"mode": "allowlist", "allowed": narrowed_tools}},
            "budgets": {
                "max_actions": min(requested.get("max_actions", 999), parent_budgets.get("max_actions", 999)),
                "max_tokens": min(requested.get("max_tokens", 999999), parent_budgets.get("max_tokens", 999999)),
                "max_cost_usd": min(requested.get("max_cost_usd", 99), parent_budgets.get("max_cost_usd", 99)),
                "max_ttl_seconds": min(requested.get("max_ttl_seconds", 3600), parent_budgets.get("max_ttl_seconds", 3600)),
            },
        }

    async def _check_budget(self, agent_id: str, envelope: dict) -> dict:
        remaining = await self.db.get_budget_remaining(agent_id)
        budgets = envelope.get("budgets", {})
        if remaining.get("actions", 0) >= budgets.get("max_actions", 999):
            return {"ok": False, "reason": "actions", "remaining": remaining}
        if remaining.get("tokens", 0) >= budgets.get("max_tokens", 999999):
            return {"ok": False, "reason": "tokens", "remaining": remaining}
        return {"ok": True, "remaining": remaining}
