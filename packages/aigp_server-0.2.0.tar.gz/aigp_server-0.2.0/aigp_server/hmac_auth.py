"""HMAC-SHA256 authentication for AIGP protocol messages."""

import hashlib
import hmac
import logging
from datetime import datetime, timezone

logger = logging.getLogger(__name__)

MAX_TIMESTAMP_DRIFT_SECONDS = 300


def verify_hmac(headers: dict, body: bytes, secret: str) -> bool:
    """Verify AIGP HMAC-SHA256 signature.

    Headers (case-insensitive):
      X-AIGP-Signature: hmac-sha256={hex_digest}
      X-AIGP-Timestamp: ISO 8601 timestamp
      X-AIGP-Agent-Id: agent identifier
    """
    sig_header = headers.get("x-aigp-signature", "")
    timestamp = headers.get("x-aigp-timestamp", "")

    if not sig_header or not timestamp:
        return False

    try:
        ts = datetime.fromisoformat(timestamp.replace("Z", "+00:00"))
        if abs((datetime.now(timezone.utc) - ts).total_seconds()) > MAX_TIMESTAMP_DRIFT_SECONDS:
            return False
    except (ValueError, TypeError):
        return False

    if not sig_header.startswith("hmac-sha256="):
        return False

    body_hash = hashlib.sha256(body).hexdigest()
    message = f"{timestamp}\n{body_hash}"
    expected = hmac.new(secret.encode(), message.encode(), hashlib.sha256).hexdigest()
    return hmac.compare_digest(sig_header[len("hmac-sha256="):], expected)


def sign_request(body: bytes, secret: str, agent_id: str) -> dict:
    """Generate AIGP HMAC headers for outbound requests."""
    timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    body_hash = hashlib.sha256(body).hexdigest()
    message = f"{timestamp}\n{body_hash}"
    sig = hmac.new(secret.encode(), message.encode(), hashlib.sha256).hexdigest()
    return {
        "X-AIGP-Signature": f"hmac-sha256={sig}",
        "X-AIGP-Timestamp": timestamp,
        "X-AIGP-Agent-Id": agent_id,
        "Content-Type": "application/json",
    }
