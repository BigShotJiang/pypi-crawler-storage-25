"""Scope providers — envelope management and circuit breakers."""

from .scope_manager import ScopeEnvelopeManager, TEMPLATES
from .circuit_breaker import CircuitBreakerService

__all__ = ["ScopeEnvelopeManager", "CircuitBreakerService", "TEMPLATES"]
