"""Circuit Breaker — halts anomalous agents, cascades to delegation chains."""

import logging
from datetime import datetime, timezone, timedelta

from ..storage.storage_provider_base import StorageProviderBase as GovernanceStore

logger = logging.getLogger(__name__)

CLOSED, OPEN, HALF_OPEN = "CLOSED", "OPEN", "HALF_OPEN"

DEFAULT_CONFIG = {
    "error_rate_threshold": 0.5,
    "time_window_seconds": 60,
    "cooldown_seconds": 30,
    "max_probe_requests": 3,
    "recovery_conditions": {"consecutive_successes": 3},
}


def _now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _expiry(seconds: int) -> str:
    return (datetime.now(timezone.utc) + timedelta(seconds=seconds)).strftime("%Y-%m-%dT%H:%M:%SZ")


class CircuitBreakerService:
    def __init__(self, db: GovernanceStore):
        self.db = db

    async def is_open(self, agent_id: str) -> bool:
        state = await self.db.get_circuit_breaker(agent_id)
        if not state:
            return False
        if state.get("state") == OPEN:
            if _now() > state.get("cooldown_until", ""):
                await self.db.update_circuit_breaker(agent_id, {"state": HALF_OPEN})
                return False
            return True
        return False

    async def get_state(self, agent_id: str) -> str:
        state = await self.db.get_circuit_breaker(agent_id)
        return state.get("state", CLOSED) if state else CLOSED

    async def record_outcome(self, agent_id: str, success: bool):
        state = await self.db.get_circuit_breaker(agent_id) or {
            "state": CLOSED, "errors": 0, "total": 0, "consecutive_successes": 0,
        }
        state["total"] += 1
        if not success:
            state["errors"] += 1
            state["consecutive_successes"] = 0
        else:
            state["consecutive_successes"] += 1

        current = state.get("state", CLOSED)
        config = await self._get_config(agent_id)

        if current == CLOSED and state["total"] >= 5:
            if state["errors"] / state["total"] > config["error_rate_threshold"]:
                await self._trip(agent_id, config)
                return

        if current == HALF_OPEN and success:
            if state["consecutive_successes"] >= config["recovery_conditions"]["consecutive_successes"]:
                await self._reset(agent_id)
                return

        if current == HALF_OPEN and not success:
            await self._trip(agent_id, config)
            return

        await self.db.put_circuit_breaker(agent_id, state)

    async def manual_reset(self, agent_id: str):
        await self._reset(agent_id)

    async def _trip(self, agent_id: str, config: dict):
        await self.db.put_circuit_breaker(agent_id, {
            "state": OPEN,
            "tripped_at": _now(),
            "cooldown_until": _expiry(config["cooldown_seconds"]),
            "errors": 0, "total": 0, "consecutive_successes": 0,
        })
        logger.warning("Circuit breaker TRIPPED for agent %s", agent_id)
        # Cascade to delegates
        for d in await self.db.get_delegates(agent_id):
            if target := d.get("target_agent_id"):
                await self._trip(target, config)
        await self.db.put_task({"type": "CIRCUIT_BREAKER", "agent_id": agent_id, "status": "PENDING"})

    async def _reset(self, agent_id: str):
        await self.db.put_circuit_breaker(agent_id, {
            "state": CLOSED, "errors": 0, "total": 0, "consecutive_successes": 0,
        })

    async def _get_config(self, agent_id: str) -> dict:
        agent = await self.db.get_agent(agent_id)
        return agent.get("circuit_breaker_config", DEFAULT_CONFIG) if agent else DEFAULT_CONFIG
