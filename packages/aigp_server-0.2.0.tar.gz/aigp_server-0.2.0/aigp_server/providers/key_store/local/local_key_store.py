"""Local key store — in-memory, for development and testing."""

import os
from uuid import uuid4

from ..key_store_base import KeyStoreBase
from ..key_store_factory import register


@register("local")
class LocalKeyStore(KeyStoreBase):
    """In-memory key store. Keys lost on restart."""

    def __init__(self, **kwargs):
        self._keys: dict[str, dict] = {}

    async def get_key(self, key_id: str) -> bytes | None:
        entry = self._keys.get(key_id)
        if not entry or entry.get("status") == "REVOKED":
            return None
        return entry["key"]

    async def create_key(self, purpose: str, ttl_days: int = 90) -> str:
        key_id = f"key-{uuid4().hex[:12]}"
        self._keys[key_id] = {"key": os.urandom(32), "purpose": purpose, "status": "ACTIVE", "ttl_days": ttl_days}
        return key_id

    async def rotate_key(self, key_id: str) -> str:
        old = self._keys.get(key_id)
        if old:
            old["status"] = "ROTATING"
        new_id = await self.create_key(old.get("purpose", "") if old else "rotated")
        return new_id

    async def revoke_key(self, key_id: str) -> None:
        if key_id in self._keys:
            self._keys[key_id]["status"] = "REVOKED"
            self._keys[key_id]["key"] = None

    async def list_keys(self) -> list[dict]:
        return [{"key_id": k, "status": v["status"], "purpose": v["purpose"]} for k, v in self._keys.items()]
