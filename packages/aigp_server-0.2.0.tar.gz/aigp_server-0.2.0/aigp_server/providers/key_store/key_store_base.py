"""Key store base — abstract interface for consent token key management."""

from __future__ import annotations

from abc import ABC, abstractmethod


class KeyStoreBase(ABC):
    """Manages encryption keys for consent tokenization.

    Keys are used to tokenize/de-tokenize PII. Revoking a key = permanent anonymization.
    """

    @abstractmethod
    async def get_key(self, key_id: str) -> bytes | None:
        """Get an active encryption key."""
        ...

    @abstractmethod
    async def create_key(self, purpose: str, ttl_days: int = 90) -> str:
        """Create a new key. Returns key_id."""
        ...

    @abstractmethod
    async def rotate_key(self, key_id: str) -> str:
        """Rotate a key. Returns new key_id. Old key remains valid for grace period."""
        ...

    @abstractmethod
    async def revoke_key(self, key_id: str) -> None:
        """Revoke a key. Tokenized data becomes permanently anonymous."""
        ...

    @abstractmethod
    async def list_keys(self) -> list[dict]:
        """List all keys with status."""
        ...
