"""Key store factory."""

from __future__ import annotations

from .key_store_base import KeyStoreBase

_REGISTRY: dict[str, type[KeyStoreBase]] = {}


def register(name: str):
    def wrapper(cls: type[KeyStoreBase]):
        _REGISTRY[name] = cls
        return cls
    return wrapper


def create(provider_name: str, **config) -> KeyStoreBase:
    if provider_name not in _REGISTRY:
        raise ValueError(f"Unknown key_store provider: {provider_name}. Available: {list(_REGISTRY.keys())}")
    return _REGISTRY[provider_name](**config)


def available() -> list[str]:
    return list(_REGISTRY.keys())
