"""Consent engine — orchestrates PII tokenization based on consent tier."""

from __future__ import annotations

import hashlib
import hmac as _hmac
from dataclasses import dataclass, field

from ..pii.pii_detector_base import PiiDetectorBase, PiiEntity
from ..key_store.key_store_base import KeyStoreBase


@dataclass
class TokenMap:
    """Maps original PII to tokens for reversible de-tokenization."""
    mappings: dict[str, str] = field(default_factory=dict)  # token → original
    key_id: str = ""


class ConsentEngine:
    """Orchestrates consent-aware data processing.

    Tiers:
        NONE: block if PII detected
        ANONYMOUS: hash (irreversible)
        REDACTED: tokenize (reversible with key)
        STANDARD: pass through, store with access controls
        FULL: pass through, no restrictions
    """

    def __init__(self, pii_detector: PiiDetectorBase, key_store: KeyStoreBase, default_tier: str = "STANDARD"):
        self._pii = pii_detector
        self._keys = key_store
        self._default_tier = default_tier

    async def pre_process(self, text: str, tier: str | None = None) -> tuple[str, TokenMap]:
        """Process text before model invocation. Returns (processed_text, token_map)."""
        tier = tier or self._default_tier
        if tier == "FULL":
            return text, TokenMap()
        if tier == "STANDARD":
            return text, TokenMap()

        entities = await self._pii.detect(text)
        if not entities:
            return text, TokenMap()

        if tier == "NONE" and entities:
            raise ValueError(f"PII detected in NONE consent tier: {[e.entity_type for e in entities]}")

        # Tokenize (ANONYMOUS = irreversible hash, REDACTED = reversible token)
        token_map = TokenMap()
        if tier == "REDACTED":
            key_id = await self._keys.create_key("consent_tokenize", ttl_days=90)
            token_map.key_id = key_id

        processed = text
        for entity in sorted(entities, key=lambda e: e.start, reverse=True):
            if tier == "ANONYMOUS":
                token = f"[{entity.entity_type}_{hashlib.sha256(entity.text.encode()).hexdigest()[:8]}]"
            else:  # REDACTED
                token = f"[{entity.entity_type}_TOKEN_{len(token_map.mappings)}]"
                token_map.mappings[token] = entity.text
            processed = processed[:entity.start] + token + processed[entity.end:]

        return processed, token_map

    async def post_process(self, text: str, token_map: TokenMap) -> str:
        """De-tokenize output for the user."""
        if not token_map.mappings:
            return text
        # Verify key is still valid
        if token_map.key_id:
            key = await self._keys.get_key(token_map.key_id)
            if key is None:
                return text  # Key revoked — can't de-tokenize
        result = text
        for token, original in token_map.mappings.items():
            result = result.replace(token, original)
        return result
