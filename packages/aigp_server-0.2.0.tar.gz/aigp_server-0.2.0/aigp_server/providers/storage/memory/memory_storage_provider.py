"""In-memory storage provider — for testing and development."""

from ..storage_provider_base import StorageProviderBase
from ..storage_provider_factory import register


@register("memory")
class MemoryStorageProvider(StorageProviderBase):
    """In-memory implementation for tests. No persistence."""

    def __init__(self, **kwargs):
        self._data: dict[str, dict] = {}
        self._budgets: dict[str, dict] = {}

    def _key(self, pk: str, sk: str) -> str:
        return f"{pk}|{sk}"

    async def put_scope_envelope(self, envelope: dict) -> None:
        self._data[self._key(f"AGENT#{envelope['agent_id']}", f"SCOPE#{envelope['scope_envelope_id']}")] = envelope

    async def get_scope_envelope(self, envelope_id: str) -> dict | None:
        return next((v for v in self._data.values() if v.get("scope_envelope_id") == envelope_id), None)

    async def get_active_scope(self, agent_id: str) -> dict | None:
        return next((v for v in self._data.values() if v.get("agent_id") == agent_id and v.get("status") == "ACTIVE"), None)

    async def update_scope_envelope(self, envelope_id: str, updates: dict) -> None:
        env = await self.get_scope_envelope(envelope_id)
        if env:
            env.update(updates)

    async def query_scopes(self, agent_id: str) -> list[dict]:
        return [v for v in self._data.values() if v.get("agent_id") == agent_id and "scope_envelope_id" in v]

    async def get_circuit_breaker(self, agent_id: str) -> dict | None:
        return self._data.get(self._key("CB", agent_id))

    async def put_circuit_breaker(self, agent_id: str, state: dict) -> None:
        self._data[self._key("CB", agent_id)] = state

    async def update_circuit_breaker(self, agent_id: str, updates: dict) -> None:
        cb = await self.get_circuit_breaker(agent_id)
        if cb:
            cb.update(updates)

    async def increment_budget(self, agent_id: str, actions: int = 0, tokens: int = 0) -> None:
        b = self._budgets.setdefault(agent_id, {"actions": 0, "tokens": 0})
        b["actions"] += actions
        b["tokens"] += tokens

    async def get_budget_remaining(self, agent_id: str) -> dict:
        return self._budgets.get(agent_id, {"actions": 0, "tokens": 0})

    async def put_delegation(self, delegation: dict) -> None:
        self._data[self._key("DEL", f"{delegation['delegating_agent_id']}>{delegation['target_agent_id']}")] = delegation

    async def get_delegates(self, agent_id: str) -> list[dict]:
        return [v for v in self._data.values() if v.get("delegating_agent_id") == agent_id]

    async def get_agent(self, agent_id: str) -> dict | None:
        return self._data.get(self._key("AGENT", agent_id))

    async def put_task(self, task: dict) -> str:
        from uuid import uuid4
        tid = f"task-{uuid4().hex[:8]}"
        task["task_id"] = tid
        self._data[self._key("TASK", tid)] = task
        return tid

    async def put_audit(self, agent_id: str, action: str, decision: str, details: dict) -> None:
        pass  # no-op for testing

    async def put_run_step(self, run_id: str, step: dict) -> None:
        self._data[self._key("STEP", f"{run_id}#{step.get('step_number', 0)}")] = step
