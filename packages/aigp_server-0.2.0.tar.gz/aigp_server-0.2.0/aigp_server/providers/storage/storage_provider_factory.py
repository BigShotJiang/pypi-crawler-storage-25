"""Storage provider factory — config-driven instantiation."""

from __future__ import annotations

from .storage_provider_base import StorageProviderBase

_REGISTRY: dict[str, type[StorageProviderBase]] = {}


def register(name: str):
    """Decorator to register a storage provider implementation."""
    def wrapper(cls: type[StorageProviderBase]):
        _REGISTRY[name] = cls
        return cls
    return wrapper


def create(provider_name: str, **config) -> StorageProviderBase:
    """Create a storage provider instance from config."""
    if provider_name not in _REGISTRY:
        raise ValueError(f"Unknown storage provider: {provider_name}. Available: {list(_REGISTRY.keys())}")
    return _REGISTRY[provider_name](**config)


def available() -> list[str]:
    """List registered storage providers."""
    return list(_REGISTRY.keys())
