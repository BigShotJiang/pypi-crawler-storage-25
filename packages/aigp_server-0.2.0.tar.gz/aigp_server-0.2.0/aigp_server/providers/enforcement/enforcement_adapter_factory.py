"""Enforcement adapter factory — config-driven instantiation."""

from __future__ import annotations

from .enforcement_adapter_base import EnforcementAdapterBase

_REGISTRY: dict[str, type[EnforcementAdapterBase]] = {}


def register(name: str):
    """Decorator to register an enforcement adapter."""
    def wrapper(cls: type[EnforcementAdapterBase]):
        _REGISTRY[name] = cls
        return cls
    return wrapper


def create(provider_name: str, **config) -> EnforcementAdapterBase:
    """Create an enforcement adapter from config."""
    if provider_name not in _REGISTRY:
        raise ValueError(f"Unknown enforcement provider: {provider_name}. Available: {list(_REGISTRY.keys())}")
    return _REGISTRY[provider_name](**config)


def available() -> list[str]:
    return list(_REGISTRY.keys())
