"""Enforcement adapter base — cloud-agnostic policy enforcement interface."""

from __future__ import annotations

from abc import ABC, abstractmethod


class EnforcementAdapterBase(ABC):
    """Translates AIGP policies into provider-native controls.

    Implementations: bedrock (guardrails, model access), azure (content safety), gcp (vertex safety).
    """

    @abstractmethod
    async def apply_policy(self, policy: dict, app_registration: dict) -> dict:
        """Apply an AIGP policy to the provider's native controls."""
        ...

    @abstractmethod
    async def verify_policy(self, policy: dict, app_registration: dict) -> dict:
        """Verify that a policy is currently enforced at the provider level."""
        ...

    @abstractmethod
    async def revoke_policy(self, policy: dict, app_registration: dict) -> dict:
        """Remove a policy from the provider's native controls."""
        ...

    @abstractmethod
    async def list_enforceable_controls(self) -> list[dict]:
        """List all controls this adapter can enforce."""
        ...

    @abstractmethod
    async def health(self) -> bool:
        """Check if the provider is reachable."""
        ...
