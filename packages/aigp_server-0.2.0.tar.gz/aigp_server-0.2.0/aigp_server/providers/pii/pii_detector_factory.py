"""PII detector factory — config-driven instantiation."""

from __future__ import annotations

from .pii_detector_base import PiiDetectorBase

_REGISTRY: dict[str, type[PiiDetectorBase]] = {}


def register(name: str):
    def wrapper(cls: type[PiiDetectorBase]):
        _REGISTRY[name] = cls
        return cls
    return wrapper


def create(provider_name: str, **config) -> PiiDetectorBase:
    if provider_name not in _REGISTRY:
        raise ValueError(f"Unknown PII provider: {provider_name}. Available: {list(_REGISTRY.keys())}")
    return _REGISTRY[provider_name](**config)


def available() -> list[str]:
    return list(_REGISTRY.keys())
