"""PII detector base — abstract interface for PII detection."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass


@dataclass
class PiiEntity:
    """A detected PII entity."""
    entity_type: str  # EMAIL, PHONE, SSN, CREDIT_CARD, PERSON, etc.
    start: int
    end: int
    score: float
    text: str


class PiiDetectorBase(ABC):
    """Abstract PII detection interface.

    Implementations: presidio (local), comprehend (AWS), regex (lightweight).
    """

    @abstractmethod
    async def detect(self, text: str) -> list[PiiEntity]:
        """Detect PII entities in text."""
        ...

    @abstractmethod
    async def supported_entities(self) -> list[str]:
        """List entity types this detector can find."""
        ...
