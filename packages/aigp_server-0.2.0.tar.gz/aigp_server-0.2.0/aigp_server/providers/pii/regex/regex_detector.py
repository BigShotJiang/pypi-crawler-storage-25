"""Regex PII detector — lightweight fallback, no external dependencies."""

import re

from ..pii_detector_base import PiiDetectorBase, PiiEntity
from ..pii_detector_factory import register

PATTERNS = {
    "EMAIL": re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b"),
    "PHONE": re.compile(r"\b(?:\+?1[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}\b"),
    "SSN": re.compile(r"\b\d{3}-\d{2}-\d{4}\b"),
    "CREDIT_CARD": re.compile(r"\b(?:\d{4}[-\s]?){3}\d{4}\b"),
    "IP_ADDRESS": re.compile(r"\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b"),
}


@register("regex")
class RegexPiiDetector(PiiDetectorBase):
    """Regex-based PII detection. No external dependencies."""

    def __init__(self, entities: list[str] | None = None, **kwargs):
        self._entities = entities or list(PATTERNS.keys())

    async def detect(self, text: str) -> list[PiiEntity]:
        results = []
        for entity_type in self._entities:
            pattern = PATTERNS.get(entity_type)
            if not pattern:
                continue
            for match in pattern.finditer(text):
                results.append(PiiEntity(
                    entity_type=entity_type,
                    start=match.start(), end=match.end(),
                    score=0.9, text=match.group(),
                ))
        return results

    async def supported_entities(self) -> list[str]:
        return list(PATTERNS.keys())
