"""Scope Envelope Manager — create, approve, enforce scope envelopes with SoD."""

import copy
import logging
from datetime import datetime, timezone, timedelta
from uuid import uuid4

from .store import GovernanceStore

logger = logging.getLogger(__name__)

TEMPLATES = {
    "ANALYST": {
        "permissions": {"tools": {"mode": "allowlist", "allowed": []}, "models": {"mode": "allowlist", "allowed": ["us.anthropic.claude-sonnet-4-5-20250929-v1:0"]}},
        "budgets": {"max_actions": 100, "max_tokens": 200000, "max_cost_usd": 10.0, "max_ttl_seconds": 3600},
        "autonomy_level": "ACT_AUTONOMOUS",
        "memory_scope": {"may_write": False},
    },
    "EXECUTOR": {
        "permissions": {"tools": {"mode": "allowlist", "allowed": []}, "models": {"mode": "allowlist", "allowed": ["us.anthropic.claude-sonnet-4-5-20250929-v1:0"]}},
        "budgets": {"max_actions": 50, "max_tokens": 100000, "max_cost_usd": 5.0, "max_ttl_seconds": 3600},
        "autonomy_level": "ACT_WITH_APPROVAL",
        "approval_gates": [{"action_pattern": "*_delete_*", "requires": "HUMAN_APPROVAL", "timeout_seconds": 300, "timeout_action": "DENY"}],
        "memory_scope": {"may_write": True, "max_retention_seconds": 86400, "allowed_classifications": ["LOW", "MEDIUM"], "isolation": "AGENT_PRIVATE"},
    },
    "ORCHESTRATOR": {
        "permissions": {"tools": {"mode": "allowlist", "allowed": []}, "models": {"mode": "allowlist", "allowed": ["us.anthropic.claude-opus-4-7"]}},
        "budgets": {"max_actions": 200, "max_tokens": 500000, "max_cost_usd": 25.0, "max_ttl_seconds": 3600},
        "autonomy_level": "ACT_WITH_APPROVAL",
        "memory_scope": {"may_write": True, "max_retention_seconds": 3600, "allowed_classifications": ["LOW", "MEDIUM", "HIGH"], "isolation": "APP_SHARED"},
    },
}


def _now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _expiry(ttl_seconds: int) -> str:
    return (datetime.now(timezone.utc) + timedelta(seconds=ttl_seconds)).strftime("%Y-%m-%dT%H:%M:%SZ")


class ScopeEnvelopeManager:
    def __init__(self, db: GovernanceStore):
        self.db = db

    async def create_request(self, agent_id: str, envelope: dict, requester: str) -> str:
        envelope_id = f"scope-{uuid4().hex[:12]}"
        version = len(await self.db.query_scopes(agent_id)) + 1
        envelope.update({
            "scope_envelope_id": envelope_id,
            "agent_id": agent_id,
            "version": version,
            "status": "PENDING_APPROVAL",
            "created_by": requester,
            "created_at": _now(),
        })
        await self.db.put_scope_envelope(envelope)
        task_id = await self.db.put_task({
            "type": "SCOPE_APPROVAL", "agent_id": agent_id,
            "envelope_id": envelope_id, "requester": requester, "status": "PENDING",
        })
        return task_id

    async def approve(self, envelope_id: str, approver: str) -> bool:
        envelope = await self.db.get_scope_envelope(envelope_id)
        if not envelope:
            raise ValueError("Envelope not found")
        if envelope["created_by"] == approver:
            raise PermissionError("SoD violation: approver cannot be the creator")
        ttl = envelope.get("budgets", {}).get("max_ttl_seconds", 3600)
        await self.db.update_scope_envelope(envelope_id, {
            "status": "ACTIVE", "approved_by": approver,
            "issued_at": _now(), "expires_at": _expiry(ttl),
        })
        return True

    async def reject(self, envelope_id: str, rejector: str, reason: str = "") -> bool:
        await self.db.update_scope_envelope(envelope_id, {
            "status": "REJECTED", "rejected_by": rejector,
            "rejection_reason": reason, "rejected_at": _now(),
        })
        return True

    async def get_active_envelope(self, agent_id: str) -> dict | None:
        envelope = await self.db.get_active_scope(agent_id)
        if not envelope:
            return None
        if envelope.get("expires_at", "") and envelope["expires_at"] < _now():
            await self.db.update_scope_envelope(envelope["scope_envelope_id"], {"status": "EXPIRED"})
            return None
        return envelope

    async def from_template(self, template_name: str, agent_id: str, tools: list[str] | None = None) -> dict:
        envelope = copy.deepcopy(TEMPLATES.get(template_name, TEMPLATES["EXECUTOR"]))
        if tools:
            envelope["permissions"]["tools"]["allowed"] = tools
        envelope["agent_id"] = agent_id
        return envelope
