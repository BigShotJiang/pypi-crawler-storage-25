# aigp-server — AIGP Governance Engine

Server-side governance engine for the AI Governance Protocol (AIGP). Provider-based architecture following OOP/SOLID principles.

## Install

```bash
pip install aigp-server>=0.2.0
```

## Quick Start (Config-Driven)

```python
from aigp_server import ServerConfig, GovernanceEngine, AigpRouter

# Configure providers
config = ServerConfig(
    storage={"provider": "memory"},          # or "dynamodb"
    pii={"provider": "regex"},               # or "presidio", "comprehend"
    key_store={"provider": "local"},          # or "kms", "vault"
    mode="ENFORCE",
)
components = config.build()

# Wire up engine + router
engine = GovernanceEngine(components.store, components.scope_mgr, components.circuit_breaker, mode="ENFORCE")
router = AigpRouter(engine, hmac_secret="your-secret")

# Handle requests (framework-agnostic)
status, resp = await router.handle_tool_request(headers, body)
```

## Provider Architecture

```
aigp_server/
├── providers/
│   ├── storage/         StorageProviderBase → memory, dynamodb
│   ├── scope/           ScopeEnvelopeManager, CircuitBreakerService
│   ├── enforcement/     EnforcementAdapterBase → bedrock, azure, gcp
│   ├── pii/             PiiDetectorBase → regex, presidio, comprehend
│   ├── key_store/       KeyStoreBase → local, kms, vault
│   └── consent/         ConsentEngine (tier-aware tokenization)
├── governance_engine.py
├── routes.py
├── config.py
└── hmac_auth.py
```

## Adding a Provider

```python
from aigp_server.providers.pii import PiiDetectorBase, register

@register("my_detector")
class MyPiiDetector(PiiDetectorBase):
    async def detect(self, text: str) -> list[PiiEntity]: ...
    async def supported_entities(self) -> list[str]: ...
```

Then use it: `ServerConfig(pii={"provider": "my_detector", ...})`

## Consent Tiers

| Tier | Behavior |
|------|----------|
| NONE | Block if PII detected |
| ANONYMOUS | Hash PII (irreversible) |
| REDACTED | Tokenize PII (reversible with key) |
| STANDARD | Pass through, store with access controls |
| FULL | Pass through, no restrictions |

## Handlers

| Handler | RFC §15 | Decision |
|---------|---------|----------|
| `handle_tool_request` | §15.6 | ALLOW / DENY |
| `handle_plan_submit` | §15.8 | APPROVED / REJECTED |
| `handle_step_complete` | — | Budget decrement |
| `handle_escalate` | §15.9 | Creates pending task |
| `handle_delegate` | §15.10 | Scope narrowing |
| `handle_memory_write` | §15.13 | Classification check |

## License

Proprietary — © 2025-2026 Evan Erwee. All rights reserved.
