# Changelog

## 0.2.0 — Feb 2026 (Major formula rewrite — independent regression)

### 🚨 Breaking change: NIS formula coefficients

Following an independent multivariate regression on the n=147 frozen
Holt-Bell-Bao Food Insulin Index cohort (`HoltBellBao_v1_frozen_2026.csv`,
sha256 b41eb157…), v0.2.0 ships **fully independent coefficients**:

| Coefficient | v0.1.x (Kendall heuristic) | v0.2.0 (Nutramilo OLS) |
|-------------|---------------------------:|-----------------------:|
| net_carbs   | 1.00                       | **1.61** |
| protein     | 0.46                       | **0.66** |
| fat         | 0.15                       | **1.20** |
| fiber       | -0.78                      | **-1.14** |
| **MAE**     | 25.53                      | **13.04** |
| **R²**      | -0.315                     | **0.572** |
| **MAPE**    | 45.7%                      | **30.3%** |

Coefficients are **per-1000-kJ scaled** (Atwater factors). Stable across
OLS, Ridge α=1.0, Ridge α=10.0, LASSO α=0.5, and Bayesian Ridge (max
delta < 0.05).

**Interpretation note.** Within the harmonized per-1000-kJ dataset, fat
content contributed positively to predictive accuracy in mixed-meal
contexts. This is an empirical regression result on the n=147 cohort and
should NOT be interpreted as a direct physiological claim that fat alone
stimulates insulin secretion.

### Added
- `nis_version` and `coefficient_set_date` in NIS output for audit.
- `regression_pct` field replaces `kendall_pct` (semantic correction).
- `methodology_note` field with reviewer-safe interpretation guidance.
- Per-1000-kJ normalization step in `piru()` matching production.
- Frozen reference dataset: `sdk/notebooks/HoltBellBao_v1_frozen_2026.csv`
  + manifest + sha256 hash for reproducibility.
- Independent regression pipeline:
  `sdk/notebooks/independent_regression_v2.py`.

### Changed
- `nutramilo_insulin_score()` now uses v2 coefficients by default.
- Citations updated: Kendall demoted from primary source to "concurrent
  prior work"; Nutramilo 2026 regression added as primary derivation.

### Migration
- v0.1.x users: numerical NIS values WILL change. Final NIS may stay
  similar for "insulin paradox" foods (Holt cross-track dominates), but
  for plates without Holt FII coverage expect higher NIS scores.
- API consumers: switch to `result["regression_pct"]` (was `kendall_pct`).

---

## 0.1.1 — Feb 2026 (Production parity fix)

### Fixed (BREAKING — formula correction)
- **PIRU coefficients now match production** `routes/plate_simulator.py`:
  - Old (v0.1.0): `1.0×net_carbs + 0.55×protein − 0.45×fat`
  - New (v0.1.1): `1.0×net_carbs + 0.46×protein + 0.15×fat − 0.78×fiber`
    (Kendall heuristic on Holt n=147)
- Production NIS combines Kendall % with **Holt cross-track** and
  **clinical tier floor** (low/medium/high → 0%/30%/55%). The SDK now
  exposes both as optional parameters of `nutramilo_insulin_score()`:
  `holt_il_track=...` and `tier_floor=...`.

### Added
- `kendall_pct`, `holt_pct`, `tier_floor_pct`, `contributions` keys in NIS dict.
- New citation: Kendall (optimisingnutrition.com multivariate regression).
- Pytest reproducing exact production output for nutra2 lunch
  (NIS = 77.5%, matching app PDF NIS = 78%).

### Migration
If you were relying on v0.1.0 NIS values, expect different numbers.
v0.1.1 was a transient "production parity" release; v0.2.0 supersedes it
with independently regressed coefficients.

---

## 0.1.0 — Feb 2026

Initial public release.

### Added
- `nutramilo_insulin_score()` — 0-100 % NIS computation with per-food breakdown.
- `piru_to_percent()` — exposed piecewise PIRU→% mapping for custom flows.
- `unified_inflammation_score()` — composite EDIP+DII+NEAP (UIS).
- `edip_score()`, `dii_score()`, `edih_score()`, `neap_score()`, `pral_score()`.
- `PlateFood` dataclass for structured plate input.
- Trilingual interpretation strings (BG / EN / ES) on UIS.
- Colab validation notebook (`PIR_validation.ipynb`) covering n=147 reference
  foods (Holt 1997 + Bell 2014 + Bao 2009).

### Methodology
- Deterministic; zero runtime dependencies.
- All cutoffs and beta coefficients sourced from PubMed-indexed primary
  literature; PMIDs included on each output dict.
- EU AI Act Article 50 compliant — no opaque ML.
