"""iter350.H Phase 2 — Independent regression with proper FII normalization.

Improvement over v1: Holt's FII is per-1000-kJ portion, not per-gram.
We normalize macros to per-1000-kJ before regression for proper comparison
with Kendall.

Each food has macros in per-portion grams; we approximate kJ as:
  kJ = 17·carbs_g + 17·protein_g + 37·fat_g
"""
from __future__ import annotations
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression, Ridge, Lasso, BayesianRidge
from sklearn.metrics import mean_absolute_error, r2_score, mean_absolute_percentage_error

df = pd.read_csv("/app/sdk/notebooks/HoltBellBao_v1_frozen_2026.csv")
print(f"Loaded {len(df)} foods.\n")

# Compute kJ per portion (Atwater factors)
df["kJ"] = 17 * df["carbs_g"] + 17 * df["protein_g"] + 37 * df["fat_g"]
df["scale"] = 1000 / df["kJ"].clip(lower=50)  # per-1000-kJ scale factor

# Normalize macros to per-1000-kJ (matches Holt 1997 reference convention)
for col in ["carbs_g", "fiber_g", "protein_g", "fat_g"]:
    df[col + "_per1000kJ"] = df[col] * df["scale"]

df["net_carbs_per1000kJ"] = (df["carbs_g_per1000kJ"] - df["fiber_g_per1000kJ"]).clip(lower=0)

X = df[["net_carbs_per1000kJ", "protein_g_per1000kJ", "fat_g_per1000kJ", "fiber_g_per1000kJ"]].values
y = df["FII"].values

# Fit OLS / Ridge / LASSO / Bayesian
results = {}
for name, model in [
    ("OLS",            LinearRegression(fit_intercept=False)),
    ("Ridge α=1.0",    Ridge(alpha=1.0, fit_intercept=False)),
    ("Ridge α=10.0",   Ridge(alpha=10.0, fit_intercept=False)),
    ("LASSO α=0.5",    Lasso(alpha=0.5, fit_intercept=False, max_iter=10000)),
    ("Bayesian Ridge", BayesianRidge(fit_intercept=False)),
]:
    model.fit(X, y)
    pred = model.predict(X)
    results[name] = {
        "coefs": model.coef_,
        "mae": mean_absolute_error(y, pred),
        "r2": r2_score(y, pred),
        "mape": mean_absolute_percentage_error(y, pred) * 100,
    }

kendall = np.array([1.00, 0.46, 0.15, -0.78])
kendall_pred = X @ kendall
results["Kendall (reference)"] = {
    "coefs": kendall,
    "mae": mean_absolute_error(y, kendall_pred),
    "r2": r2_score(y, kendall_pred),
    "mape": mean_absolute_percentage_error(y, kendall_pred) * 100,
}

print("=" * 100)
print(f"{'Algorithm':<22} {'net_carbs':>11} {'protein':>10} {'fat':>9} {'fiber':>9} {'MAE':>7} {'R²':>7} {'MAPE':>7}")
print("=" * 100)
for name, r in results.items():
    c = r["coefs"]
    print(f"{name:<22} {c[0]:>11.3f} {c[1]:>10.3f} {c[2]:>9.3f} {c[3]:>9.3f} {r['mae']:>7.2f} {r['r2']:>7.3f} {r['mape']:>6.1f}%")
print("=" * 100)

# Compare to Kendall
print("\n--- Δ vs Kendall (1.00 / 0.46 / 0.15 / -0.78) ---")
for name, r in results.items():
    if "Kendall" in name:
        continue
    d = r["coefs"] - kendall
    print(f"  {name:<22} Δ = [{d[0]:+.3f}, {d[1]:+.3f}, {d[2]:+.3f}, {d[3]:+.3f}]  max|Δ| = {max(abs(d)):.3f}")

# ── Pick best Nutramilo formula ───────────────────────────────────────────
# Use OLS rounded to 2 decimals as our "Nutramilo coefficients" candidate
ols_coefs = results["OLS"]["coefs"]
nutra_coefs = np.array([round(c, 2) for c in ols_coefs])
nutra_pred = X @ nutra_coefs
nutra_mae = mean_absolute_error(y, nutra_pred)
nutra_r2 = r2_score(y, nutra_pred)

print("\n--- Proposed 'Nutramilo independent' coefficients (OLS rounded to 2dp) ---")
print(f"  net_carbs: {nutra_coefs[0]:.2f}")
print(f"  protein:   {nutra_coefs[1]:.2f}")
print(f"  fat:       {nutra_coefs[2]:.2f}")
print(f"  fiber:     {nutra_coefs[3]:.2f}")
print(f"  MAE:       {nutra_mae:.2f}  (Kendall: {results['Kendall (reference)']['mae']:.2f})")
print(f"  R²:        {nutra_r2:.3f}  (Kendall: {results['Kendall (reference)']['r2']:.3f})")

# Save coefficients to JSON for downstream reuse
import json
out = {
    "n_foods": len(df),
    "dataset": "Holt 1997 + Bell 2014 + Bao 2009",
    "normalization": "per-1000-kJ (Atwater factors: 17·carb + 17·protein + 37·fat)",
    "algorithms": {name: {"coefs": list(r["coefs"]), "mae": r["mae"], "r2": r["r2"], "mape": r["mape"]} for name, r in results.items()},
    "nutramilo_v2_coefs": {
        "net_carbs": float(nutra_coefs[0]),
        "protein":   float(nutra_coefs[1]),
        "fat":       float(nutra_coefs[2]),
        "fiber":     float(nutra_coefs[3]),
        "mae": nutra_mae,
        "r2": nutra_r2,
    },
}
with open("/tmp/nutramilo_v2_regression.json", "w") as f:
    json.dump(out, f, indent=2)
print("\n✅ Saved full regression report to /tmp/nutramilo_v2_regression.json")
