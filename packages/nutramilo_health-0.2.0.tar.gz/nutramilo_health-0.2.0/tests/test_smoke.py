"""SDK smoke tests — v0.2.0 (independent regression coefficients)."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "backend"))
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from nutramilo_health import (  # noqa: E402
    PlateFood,
    nutramilo_insulin_score,
    piru_to_percent,
    unified_inflammation_score,
    edip_score,
    dii_score,
    neap_score,
)
from nutramilo_health.insulin import piru, NIS_VERSION, NIS_COEFS_DATE  # noqa: E402


def test_piru_anchors():
    assert piru_to_percent(0) == 0.0
    assert piru_to_percent(30) == 50.0
    assert piru_to_percent(75) == 100.0


def test_v2_coefficients_match_production():
    """v0.2.0 coefficients must match production plate_simulator.py."""
    # Pure carb (no fiber, no protein, no fat) → only carb term contributes.
    # 50g carbs, 0g everything else → kJ ≈ 850, scale = 1.176
    # net_carbs_p1k = 58.8, fiber_p1k = 0
    # PIRU = 1.61 × 58.8 = 94.7
    expected_piru = 1.61 * 50 * (1000 / max(50, 17 * 50))
    actual = piru(50, 0, 0, 0)
    assert abs(actual - expected_piru) < 0.5


def test_nis_version_metadata():
    """v0.2.0 must expose `nis_version` and `coefficient_set_date` for audit."""
    plate = [PlateFood(name="test", grams=100, carbs_g=20, fiber_g=2, protein_g=10, fat_g=5)]
    nis = nutramilo_insulin_score(plate)
    assert nis["nis_version"] == "2.0-regression"
    assert nis["coefficient_set_date"] == "2026-02-10"
    # Methodology guard rail — NEVER frame fat coefficient as direct physiology
    assert "should not be interpreted as a direct physiological claim" in nis["methodology_note"]


def test_nis_with_holt_cross_track_protein_paradox():
    """Reproducing nutra2-style protein-paradox plate: Holt track should dominate.

    78g protein + 13.7g fat + ~0g carbs → low regression_pct, but Holt FII
    track (46.5 → ~77.5%) and tier_floor='high' (55%) push final NIS to ~78%.
    """
    plate = [PlateFood(name="protein_lunch", grams=463,
                       protein_g=78, carbs_g=0.8, fiber_g=0.19, fat_g=13.7)]
    nis = nutramilo_insulin_score(plate, holt_il_track=46.5, tier_floor="high")
    # Final NIS should be ≥ 55% (tier floor) and ≤ 100%.
    assert nis["percent"] >= 55.0
    assert nis["percent"] <= 100.0
    # Holt track should be the dominant contributor (≈77.5%) for this paradox food
    assert nis["holt_pct"] == 77.5
    assert nis["tier_floor_pct"] == 55.0
    assert "Nutramilo 2026 v2 regression" in " ".join(nis["citations"])


def test_uis_returns_trilingual():
    plate = [
        PlateFood(name="spinach", grams=200, protein_g=5, carbs_g=7,
                  fiber_g=4, category="vegetable_leafy"),
        PlateFood(name="salmon", grams=150, protein_g=30, fat_g=10,
                  category="fish"),
    ]
    uis = unified_inflammation_score(plate)
    if uis.get("available"):
        assert "tier_bg" in uis and "tier_en" in uis and "tier_es" in uis
        assert 0 <= uis["percent"] <= 100


def test_individual_indices_callable():
    plate = [PlateFood(name="apple", grams=200, carbs_g=25, fiber_g=4,
                       protein_g=0.5, category="fruit")]
    edip = edip_score(plate)
    dii = dii_score(plate)
    neap = neap_score(plate)
    assert "score" in edip
    assert "score" in dii
    assert neap is None or "score_meq" in neap
