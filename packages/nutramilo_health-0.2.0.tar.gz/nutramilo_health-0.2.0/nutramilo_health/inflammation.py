"""Inflammation & acid-load scoring (UIS, EDIP, DII, EDIH, NEAP, PRAL).

Thin wrapper around the production `meal_pattern_indices` service, exposing
the same peer-reviewed formulas as a stand-alone library.

All scores are deterministic, citation-backed, and EU AI Act compliant.
"""
from __future__ import annotations
from typing import Iterable, Optional

from .models import PlateFood


def _import_backend():
    """Lazy-import the production module (single source of truth).

    The SDK ships with a vendored copy at install time (see setup.py); for
    development inside the monorepo we import directly.
    """
    try:
        from services import meal_pattern_indices as m  # monorepo dev
    except ImportError:
        from nutramilo_health._vendor import meal_pattern_indices as m  # packaged
    return m


def edip_score(foods: Iterable[PlateFood]) -> dict:
    """Empirical Dietary Inflammatory Pattern (Tabung 2016, PMID 27358416)."""
    m = _import_backend()
    result = m.calculate_meal_pattern_indices(list(foods))
    return result["edip"]


def dii_score(foods: Iterable[PlateFood]) -> dict:
    """Dietary Inflammatory Index — 9-parameter meal proxy (Shivappa 2014, PMID 23824729)."""
    m = _import_backend()
    return m.calculate_meal_pattern_indices(list(foods))["dii"]


def edih_score(foods: Iterable[PlateFood]) -> dict:
    """Empirical Dietary Index for Hyperinsulinemia (Tabung 2017, PMID 28196579)."""
    m = _import_backend()
    return m.calculate_meal_pattern_indices(list(foods))["edih"]


def neap_score(foods: Iterable[PlateFood]) -> Optional[dict]:
    """Net Endogenous Acid Production (Frassetto 1998, PMID 9734733)."""
    m = _import_backend()
    return m.calculate_meal_pattern_indices(list(foods))["neap"]


def pral_score(foods: Iterable[PlateFood]) -> Optional[dict]:
    """Potential Renal Acid Load (Remer & Manz 1995, PMID 7797810)."""
    m = _import_backend()
    return m.calculate_meal_pattern_indices(list(foods))["pral"]


def unified_inflammation_score(foods: Iterable[PlateFood]) -> dict:
    """Composite Unified Inflammation Score (UIS) — 0-100 %.

    Weighted combination of EDIP (0.40), DII (0.40) and NEAP (0.20).
    Linearly normalized to a 0-100 % scale where:
        0   = strongly anti-inflammatory
        50  = neutral
        100 = strongly pro-inflammatory

    Returns
    -------
    dict with keys: percent, tier_bg, tier_en, tier_es, color, components,
    methodology, citations, interpretation_{bg,en,es}.
    """
    m = _import_backend()
    return m.calculate_meal_pattern_indices(list(foods))["unified_inflammation"]
