"""Insulin response scoring — Nutramilo Insulin Score (NIS) v2.0-regression.

Mirrors the production implementation in `routes/plate_simulator.py`
(`_predicted_insulin_response_percent`) using independently regressed
coefficients on the n=147 frozen Holt-Bell-Bao cohort.

Methodological lineage
----------------------
- Holt SHA, Brand-Miller JC, Petocz P. *An insulin index of foods.*
  Am J Clin Nutr 1997; 66:1264-76. PMID 9356547. — original Food Insulin
  Index (FII) for n=38 foods, 2-h insulin AUC, glucose=100.
- Bell KJ. *Optimising mealtime insulin dosing for fat and protein in T1DM.*
  PhD thesis, Univ. Sydney, 2014. — extension of FII to n=147 foods.
- Bao J et al. *Food insulin index: physiologic basis for predicting insulin
  demand evoked by composite meals.* Am J Clin Nutr 2009; 90:986-992.
  PMID 19710196.
- **Nutramilo 2026 v2 regression** (this implementation) — independent OLS
  on `HoltBellBao_v1_frozen_2026.csv` (n=147), per-1000-kJ normalization:
      net-carb coefficient   = 1.61
      protein coefficient    = 0.66
      fat coefficient        = 1.20
      fiber discount         = -1.14
  Compared with the prior Kendall heuristic (1.00 / 0.46 / 0.15 / -0.78),
  Nutramilo OLS achieves MAE 13.04 vs 25.53 and R² 0.572 vs -0.315 on the
  same cohort. Multiple regularization strategies (Ridge α=1, Ridge α=10,
  LASSO α=0.5, Bayesian Ridge) converge to within ±0.05.

  **Interpretation note.** Within the harmonized per-1000-kJ dataset, fat
  content contributed positively to predictive accuracy in mixed-meal
  contexts. This is an empirical regression result on the n=147 cohort
  and should not be interpreted as a direct physiological claim that fat
  alone stimulates insulin secretion.

The production NIS also takes a *Holt cross-track* (Holt FII × kJ /60) as
the protective floor for "insulin-paradox" foods (dairy, lean meats), and
applies a clinical *tier floor* (low=0%, medium=30%, high=55%) so the
score never undershoots the qualitative DIL impact tier.
"""
from __future__ import annotations
from typing import Iterable, Optional

from .models import PlateFood


# ── Nutramilo v2.0-regression coefficients (per-1000-kJ scaling) ──────────
NIS_VERSION = "2.0-regression"
NIS_COEFS_DATE = "2026-02-10"

V2_CARB_COEFF    = 1.61
V2_PROTEIN_COEFF = 0.66
V2_FAT_COEFF     = 1.20
V2_FIBER_COEFF   = -1.14


def _per_1000kJ_scale(carbs_g: float, protein_g: float, fat_g: float) -> float:
    """Compute per-1000-kJ normalization scale (Atwater factors)."""
    kJ = max(50.0, 17.0 * carbs_g + 17.0 * protein_g + 37.0 * fat_g)
    return 1000.0 / kJ


def piru(carbs_g: float, fiber_g: float, protein_g: float, fat_g: float) -> float:
    """Compute the Nutramilo v2-regression PIRU (per 1000 kJ).

    PIRU_v2 = max(0, 1.61·net_carbs_p1k + 0.66·protein_p1k
                       + 1.20·fat_p1k − 1.14·fiber_p1k)
    where each macro is scaled to per-1000-kJ via Atwater factors.

    Mirrors the production multivariate regression from independent OLS
    on the n=147 frozen Holt-Bell-Bao cohort.
    """
    scale = _per_1000kJ_scale(carbs_g, protein_g, fat_g)
    carbs_p1k   = carbs_g   * scale
    protein_p1k = protein_g * scale
    fat_p1k     = fat_g     * scale
    fiber_p1k   = fiber_g   * scale
    net_carbs_p1k = max(0.0, carbs_p1k - fiber_p1k)
    return max(
        0.0,
        V2_CARB_COEFF    * net_carbs_p1k
        + V2_PROTEIN_COEFF * protein_p1k
        + V2_FAT_COEFF     * fat_p1k
        + V2_FIBER_COEFF   * fiber_p1k,
    )


def piru_to_percent(piru_value: float) -> float:
    """Map PIRU → NIS percent via piecewise linear anchors.

    Anchors (calibrated on n=147):
        PIRU = 0   →   0 %   (water, butter, olive oil)
        PIRU = 30  →  50 %   (typical balanced meal)
        PIRU = 75  → 100 %   (high-carb + sugar saturation)
    """
    if piru_value <= 0:
        return 0.0
    if piru_value >= 75:
        return 100.0
    if piru_value <= 30:
        return (piru_value / 30.0) * 50.0
    return 50.0 + ((piru_value - 30.0) / 45.0) * 50.0


def nutramilo_insulin_score(
    foods: Iterable[PlateFood],
    holt_il_track: Optional[float] = None,
    tier_floor: Optional[str] = None,
) -> dict:
    """Compute NIS for an iterable of PlateFood items (v2.0-regression).

    Parameters
    ----------
    foods : iterable of PlateFood
        Plate composition.
    holt_il_track : float, optional
        Pre-computed Holt FII × kJ insulin load (per Holt 1997 cohort).
        When provided, applies a Holt cross-track:
            holt_pct = clip((holt_il_track / 60) × 100, [0, 100])
        and returns max(regression_pct, holt_pct, tier_floor_pct).
    tier_floor : {'low', 'medium', 'high'}, optional
        Clinical impact tier floor: 0% / 30% / 55%. When set, the final
        NIS will never undershoot this tier.

    Returns
    -------
    dict with keys:
        percent, tier ("low"|"moderate"|"high"|"very_high"), piru_raw,
        regression_pct, holt_pct, tier_floor_pct, contributions,
        breakdown, citations, nis_version, methodology_note.
    """
    total_carbs = total_fiber = total_protein = total_fat = 0.0
    breakdown = []
    for f in foods:
        total_carbs   += f.carbs_g
        total_fiber   += f.fiber_g
        total_protein += f.protein_g
        total_fat     += f.fat_g
        p_food = piru(f.carbs_g, f.fiber_g, f.protein_g, f.fat_g)
        breakdown.append({
            "food": f.name,
            "grams": f.grams,
            "piru": round(p_food, 2),
            "percent": round(piru_to_percent(p_food), 1),
        })

    raw = piru(total_carbs, total_fiber, total_protein, total_fat)
    regression_pct = piru_to_percent(raw)

    holt_pct = 0.0
    if holt_il_track is not None and holt_il_track > 0:
        holt_pct = min(100.0, (holt_il_track / 60.0) * 100.0)

    tier_floor_pct = {"low": 0.0, "medium": 30.0, "high": 55.0}.get(
        (tier_floor or "").lower(), 0.0
    )

    final_pct = max(regression_pct, holt_pct, tier_floor_pct)
    final_pct = max(0.0, min(100.0, final_pct))

    if final_pct < 25:
        tier = "low"
    elif final_pct < 50:
        tier = "moderate"
    elif final_pct < 75:
        tier = "high"
    else:
        tier = "very_high"

    scale = _per_1000kJ_scale(total_carbs, total_protein, total_fat)
    contributions = {
        "carbs":   round(V2_CARB_COEFF    * max(0.0, (total_carbs - total_fiber)) * scale, 1),
        "protein": round(V2_PROTEIN_COEFF * total_protein * scale, 1),
        "fat":     round(V2_FAT_COEFF     * total_fat     * scale, 1),
        "fiber":   round(V2_FIBER_COEFF   * total_fiber   * scale, 1),
    }

    return {
        "percent":            round(final_pct, 1),
        "tier":               tier,
        "nis_version":        NIS_VERSION,
        "coefficient_set_date": NIS_COEFS_DATE,
        "piru_raw":           round(raw, 2),
        "regression_pct":     round(regression_pct, 1),
        "holt_pct":           round(holt_pct, 1),
        "tier_floor_pct":     tier_floor_pct,
        "contributions":      contributions,
        "breakdown":          breakdown,
        "citations": [
            "Holt 1997, PMID 9356547",
            "Bell 2014 (Univ. Sydney PhD)",
            "Bao 2009, PMID 19710196",
            "Nutramilo 2026 v2 regression — sdk/notebooks/independent_regression_v2.py",
            "Kendall 2018 (concurrent prior work, optimisingnutrition.com)",
        ],
        "methodology_note": (
            "Within the harmonized per-1000-kJ dataset, fat content "
            "contributed positively to predictive accuracy in mixed-meal "
            "contexts. This is an empirical regression result and should "
            "not be interpreted as a direct physiological claim that fat "
            "alone stimulates insulin secretion."
        ),
    }
