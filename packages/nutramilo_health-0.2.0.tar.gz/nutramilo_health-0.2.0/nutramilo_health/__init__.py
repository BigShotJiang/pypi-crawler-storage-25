"""nutramilo_health — Scientific SDK exposing peer-reviewed nutritional pattern
indices used by the Nutramilo Health OS platform.

Implements:
- NIS (Nutramilo Insulin Score) — % insulin response forecast
- UIS (Unified Inflammation Score) — composite EDIP+DII+NEAP
- EDIP, DII, EDIH, NEAP, PRAL — individual peer-reviewed indices

All formulas are deterministic, citation-backed, EU AI Act compliant.
"""
from .insulin import (
    nutramilo_insulin_score,
    piru_to_percent,
    PlateFood,
)
from .inflammation import (
    unified_inflammation_score,
    edip_score,
    dii_score,
    edih_score,
    neap_score,
    pral_score,
)

__version__ = "0.2.0"
__all__ = [
    "nutramilo_insulin_score",
    "piru_to_percent",
    "PlateFood",
    "unified_inflammation_score",
    "edip_score",
    "dii_score",
    "edih_score",
    "neap_score",
    "pral_score",
]
