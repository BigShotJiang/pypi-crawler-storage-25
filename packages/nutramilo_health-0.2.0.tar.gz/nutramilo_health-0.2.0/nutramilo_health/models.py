"""Plate-food data model used by the SDK."""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class PlateFood:
    """Single food item on a plate.

    Attributes
    ----------
    name : str
        Food name in any supported language (EN/BG/ES). Used for EDIP/EDIH
        keyword classification.
    grams : float
        Portion weight in grams.
    protein_g, carbs_g, fiber_g, fat_g : float
        Macronutrients per portion.
    sugar_g, sat_fat_g : float, optional
        Sub-macros (used by DII).
    category : str, optional
        Food category (e.g., "vegetable_leafy", "fish", "grain_refined").
    phosphorus_mg, potassium_mg, magnesium_mg, calcium_mg, iron_mg : float, optional
        Mineral content (used by PRAL/NEAP/DII).
    """
    name: str
    grams: float = 100.0
    protein_g: float = 0.0
    carbs_g: float = 0.0
    fiber_g: float = 0.0
    fat_g: float = 0.0
    sugar_g: float = 0.0
    sat_fat_g: float = 0.0
    category: str = ""
    phosphorus_mg: Optional[float] = None
    potassium_mg: Optional[float] = None
    magnesium_mg: Optional[float] = None
    calcium_mg: Optional[float] = None
    iron_mg: Optional[float] = None
    calories: Optional[float] = None
