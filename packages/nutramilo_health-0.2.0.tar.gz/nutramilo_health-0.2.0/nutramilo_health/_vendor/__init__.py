# Vendored snapshot of /app/backend/services/meal_pattern_indices.py
# Sync with: cp /app/backend/services/meal_pattern_indices.py /app/sdk/nutramilo_health/_vendor/
__all__ = ['meal_pattern_indices']
