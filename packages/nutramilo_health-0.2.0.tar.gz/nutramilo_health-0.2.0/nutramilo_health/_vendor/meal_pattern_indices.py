"""iter327d — Meal-level food pattern indices for the Plate Simulator.

Implements three peer-reviewed nutritional pattern scores adapted to per-meal
input from the plate simulator (typically 1-6 foods at a single eating
occasion). All three originals are FFQ-based (servings/week) — we provide
**meal-level proxies** with explicit disclaimers and citations.

Indices implemented
-------------------
1. **PRAL** — Potential Renal Acid Load (Remer & Manz 1995, PMID 7797810)
   • mEq per meal; original is per 100 g, we sum across all foods scaled by grams
   • Need protein + ≥2 minerals (phosphorus/potassium/magnesium/calcium)
2. **EDIH** — Empirical Dietary Index for Hyperinsulinemia (Tabung 2017,
   PMID 28196579, J Nutr 147:1567-1577)
   • 18 food groups (13 hyperinsulinemic + 5 hypoinsulinemic)
   • Original is FFQ servings/week + sex-specific betas
   • We compute a **per-meal proxy** by mapping foods to groups and applying
     the published betas to portion grams (then normalize to ~servings)
3. **EDIP** — Empirical Dietary Inflammatory Pattern (Tabung 2016,
   PMID 27358416, J Nutr 146:1560-1570)
   • 18 food groups (9 anti-inflammatory + 9 pro-inflammatory)
   • Same per-meal proxy approach

Compliance (EU AI Act Art. 50):
- Rule-based, deterministic, citations on every entry.
- Output labels include disclaimer about meal-level adaptation.
"""
from __future__ import annotations
from typing import Any, Optional


# ── PRAL coefficients (Remer & Manz 1995) ─────────────────────────────────
_PRAL_PROTEIN = 0.4888  # sulfur from sulfur-containing AAs
_PRAL_P_MG = 0.0366
_PRAL_K_MG = 0.0205
_PRAL_MG_MG = 0.0263
_PRAL_CA_MG = 0.0125


def _meal_pral(foods: list) -> Optional[dict]:
    """Sum of per-food PRAL × (grams/100). mEq for the entire meal.

    Each food may carry phosphorus_mg, potassium_mg, magnesium_mg, calcium_mg
    fields (already in food schema). If too few foods have data, return None.
    """
    total_pral = 0.0
    contributing = 0
    for f in foods:
        protein = getattr(f, "protein_g", None) or 0
        # Foods may carry detailed mineral data in extra fields. Most won't —
        # we use macro-only fallback in that case via category presets below.
        p_mg = _attr(f, "phosphorus_mg", None)
        k_mg = _attr(f, "potassium_mg", None)
        mg_mg = _attr(f, "magnesium_mg", None)
        ca_mg = _attr(f, "calcium_mg", None)
        grams = getattr(f, "grams", None) or 100

        # If detailed mineral data present, use Remer formula
        available = sum(1 for v in [p_mg, k_mg, mg_mg, ca_mg] if v is not None)
        if protein > 0 and available >= 2:
            pral_per_100g = (
                _PRAL_PROTEIN * protein
                + _PRAL_P_MG * (p_mg or 0)
                - _PRAL_K_MG * (k_mg or 0)
                - _PRAL_MG_MG * (mg_mg or 0)
                - _PRAL_CA_MG * (ca_mg or 0)
            )
            scaled = pral_per_100g * (grams / 100.0)
            total_pral += scaled
            contributing += 1
            continue

        # Fallback: category-based mean PRAL per 100 g (Remer 2003 reference
        # tables — Eur J Nutr 42(6):332-7).
        cat_pral = _category_pral_proxy(f)
        if cat_pral is not None:
            total_pral += cat_pral * (grams / 100.0)
            contributing += 1

    if contributing == 0:
        return None

    pral = round(total_pral, 1)
    if pral < -10:
        label, label_bg, color = "Strongly alkaline", "Силно алкално", "#059669"
    elif pral < -3:
        label, label_bg, color = "Alkaline", "Алкално", "#10B981"
    elif pral <= 5:
        label, label_bg, color = "Neutral", "Неутрално", "#84CC16"
    elif pral <= 15:
        label, label_bg, color = "Acid", "Киселинно", "#F59E0B"
    else:
        label, label_bg, color = "Strongly acid", "Силно киселинно", "#EF4444"

    return {
        "pral_meq": pral,
        "label": label,
        "label_bg": label_bg,
        "color": color,
        "interpretation_bg": (
            "PRAL > +5 mEq натоварва бъбреците с метаболитна киселина "
            "(месо, твърди сирена, зърнени). PRAL < -5 mEq е алкализиращ "
            "(зеленчуци, плодове). Целта при здрави е средно ≤ 0 mEq/ден "
            "(Remer 2003)."
        ),
        "interpretation_en": (
            "PRAL > +5 mEq adds metabolic acid load (meat, hard cheese, grains). "
            "PRAL < -5 mEq is alkalinizing (veg, fruits). Healthy target is "
            "average ≤ 0 mEq/day (Remer 2003)."
        ),
        "methodology": "Remer & Manz 1995, PMID 7797810",
        "contributing_foods": contributing,
    }


def _attr(obj, name: str, default=None):
    """Safe attribute extraction supporting both dataclass and pydantic."""
    if hasattr(obj, name):
        v = getattr(obj, name)
        return v if v is not None else default
    if isinstance(obj, dict):
        return obj.get(name, default)
    return default


# ── Category-mean PRAL per 100 g (Remer 2003 Eur J Nutr) ──────────────────
_CATEGORY_PRAL_PER_100G = {
    "meat": 9.5,            # red meat avg
    "poultry": 8.0,
    "fish": 7.0,
    "seafood": 8.0,
    "eggs": 8.2,
    "cheese_hard": 26.4,    # parmesan-class
    "cheese_soft": 4.3,     # cottage cheese class
    "milk": 0.7,
    "yogurt": 1.5,
    "grain_refined": 7.0,   # white bread, rice
    "grain_whole": 4.5,     # brown rice, oats, whole wheat
    "legume": -3.5,         # beans, chickpeas, lentils
    "vegetable_leafy": -8.0,  # spinach, kale
    "vegetable": -5.0,      # broccoli, cauliflower
    "fruit": -3.0,          # apple, pear
    "fruit_citrus": -5.5,
    "nuts": +5.0,           # mixed nuts
    "fat_oil": 0.0,         # neutral
    "sweet_processed": +3.0,
    "drink_alcohol": -1.0,
    "water": 0.0,
}


def _category_pral_proxy(f) -> Optional[float]:
    """Map a food's `category` field to a mean PRAL value for fallback."""
    cat = (_attr(f, "category", "") or "").lower()
    if not cat:
        return None
    # Direct match
    if cat in _CATEGORY_PRAL_PER_100G:
        return _CATEGORY_PRAL_PER_100G[cat]
    # Fuzzy categorical mapping for the simulator's rough categories
    if "meat" in cat or "месо" in cat or "beef" in cat or "pork" in cat:
        return _CATEGORY_PRAL_PER_100G["meat"]
    if "fish" in cat or "риба" in cat:
        return _CATEGORY_PRAL_PER_100G["fish"]
    if "vegetable" in cat or "зеленчук" in cat:
        return _CATEGORY_PRAL_PER_100G["vegetable"]
    if "fruit" in cat or "плод" in cat:
        return _CATEGORY_PRAL_PER_100G["fruit"]
    if "grain" in cat or "зърн" in cat or "хляб" in cat:
        return _CATEGORY_PRAL_PER_100G["grain_refined"]
    if "legume" in cat or "боб" in cat or "нахут" in cat:
        return _CATEGORY_PRAL_PER_100G["legume"]
    if "dairy" in cat or "млечн" in cat:
        return _CATEGORY_PRAL_PER_100G["yogurt"]
    if "egg" in cat or "яйце" in cat:
        return _CATEGORY_PRAL_PER_100G["eggs"]
    if "nut" in cat or "ядк" in cat:
        return _CATEGORY_PRAL_PER_100G["nuts"]
    return None


# ── EDIH (Empirical Dietary Index for Hyperinsulinemia) ─────────────────────
# Tabung et al. 2017, J Nutr 147:1567-1577. Original beta coefficients are
# per serving/day; we apply per-100 g equivalents proportionally.
# Higher EDIH = more hyperinsulinemic dietary pattern.
# Hyperinsulinemic (positive betas in original):
EDIH_HYPER = {
    "red_meat":            +0.114,   # per serving/day
    "processed_meat":      +0.082,
    "margarine":           +0.072,
    "low_energy_drink":    +0.058,
    "french_fries":        +0.094,
    "creamer":             +0.041,
    "high_energy_drink":   +0.155,
    "tomatoes":            +0.039,
    "butter":              +0.073,
    "poultry":             +0.084,
    "cream_soup":          +0.040,
    "eggs":                +0.087,
    "fish":                +0.070,
}
# Hypoinsulinemic (negative betas in original):
EDIH_HYPO = {
    "wine":                -0.121,
    "coffee":              -0.064,
    "whole_fruit":         -0.040,
    "high_fat_dairy":      -0.073,
    "leafy_greens":        -0.075,
}


# ── EDIP (Empirical Dietary Inflammatory Pattern) ──────────────────────────
# Tabung et al. 2016, J Nutr 146:1560-1570. Higher = more pro-inflammatory.
EDIP_PRO = {
    "processed_meat":      +0.110,
    "red_meat":            +0.096,
    "organ_meat":          +0.097,
    "fish_other":          +0.058,   # non-dark fish
    "vegetables_other":    +0.059,
    "refined_grains":      +0.054,
    "high_energy_drink":   +0.122,
    "low_energy_drink":    +0.061,
    "tomato":              +0.047,
}
EDIP_ANTI = {
    "wine":                -0.058,
    "coffee":              -0.135,
    "tea":                 -0.121,
    "yellow_vegetables":   -0.205,
    "leafy_greens":        -0.106,
    "fruit_juice":         -0.061,
    "snacks":              -0.057,
    "pizza":               -0.027,
    "beer":                -0.038,
}


# ── Food name → group mapping (BG + EN) ───────────────────────────────────
_FOOD_GROUP_MAP = {
    # Red meat / processed
    "red_meat": ["beef", "pork", "lamb", "veal", "burger", "телешк", "свинск", "агнешк", "говежд", "бургер"],
    "processed_meat": ["sausage", "ham", "salami", "bacon", "hot dog", "колбас", "шунка", "салам", "бекон", "наденица", "кренвирш"],
    "poultry": ["chicken", "turkey", "duck", "пиле", "пуйка", "пилеш", "пуешко"],
    "organ_meat": ["liver", "kidney", "heart", "черен дроб", "бъбре", "сърце", "карантия"],
    "fish": ["salmon", "tuna", "trout", "sardine", "cod", "сьомга", "риба", "тон", "пъстърв", "сардин"],
    "fish_other": ["fish", "риба"],
    "eggs": ["egg", "яйце"],
    "high_fat_dairy": ["whole milk", "butter", "cream", "сметана", "извара", "пълномаслен"],
    "butter": ["butter", "масло"],
    "creamer": ["creamer"],
    "cream_soup": ["cream soup", "крем супа"],
    # Veg
    "leafy_greens": ["spinach", "kale", "lettuce", "arugula", "rocket", "спанак", "къдрав зеле", "кейл", "марули", "рукол"],
    "yellow_vegetables": ["carrot", "pumpkin", "squash", "sweet potato", "морков", "тиква", "сладък картоф"],
    "tomatoes": ["tomato", "домат"],
    "tomato": ["tomato", "домат"],
    "vegetables_other": ["broccoli", "cauliflower", "pepper", "cabbage", "брокол", "карфиол", "чушки", "зеле"],
    # Fruits & juice
    "whole_fruit": ["apple", "pear", "berry", "orange", "banana", "grape", "fig", "ябълка", "круша", "ягода", "малина", "боровинка", "портокал", "банан", "грозде", "смокин"],
    "fruit_juice": ["juice", "сок"],
    # Grains
    "refined_grains": ["white bread", "white rice", "pasta", "noodle", "baguette", "бял хляб", "бял ориз", "макарон", "паста", "багета"],
    "french_fries": ["french fries", "fries", "пържени картоф"],
    # Beverages
    "wine": ["wine", "вино"],
    "beer": ["beer", "бира"],
    "coffee": ["coffee", "кафе", "espresso"],
    "tea": ["tea", "чай"],
    "high_energy_drink": ["soda", "cola", "energy drink", "газирана напитка", "кола"],
    "low_energy_drink": ["diet soda", "diet cola", "diet coke"],
    "margarine": ["margarine", "маргарин"],
    "snacks": ["chips", "crisps", "crackers", "чипс", "крекер"],
    "pizza": ["pizza", "пица"],
}


def _classify_food_groups(food_name: str, category: str = "") -> list[str]:
    """Map a food name (BG/EN) to one or more EDIH/EDIP groups.

    Uses word-boundary matching to avoid false positives like "steak" → "tea".
    """
    if not food_name:
        return []
    import re
    needle = " " + food_name.lower() + " "
    # Replace common separators with spaces for cleaner word boundaries
    needle = re.sub(r"[/\-_,()]", " ", needle)
    groups = []
    for group, keywords in _FOOD_GROUP_MAP.items():
        for kw in keywords:
            kw_l = kw.lower()
            # Multi-word keywords: substring is fine. Single words: word boundary.
            if " " in kw_l:
                if kw_l in needle:
                    groups.append(group)
                    break
            else:
                # Exact word match using regex
                if re.search(rf"\b{re.escape(kw_l)}\b", needle):
                    groups.append(group)
                    break
    return groups


def _meal_edih_edip(foods: list) -> dict:
    """Compute EDIH and EDIP per-meal proxy scores.

    Methodology
    -----------
    Original: sum_i (beta_i * servings_i_per_day)
    Per-meal proxy: sum_i (beta_i * (grams_i / 100))
    where grams/100 ≈ "approximate single serving".

    Returns a normalized score and a tier label.
    """
    edih_score = 0.0
    edip_score = 0.0
    edih_contributors: list[dict] = []
    edip_contributors: list[dict] = []

    for f in foods:
        name = _attr(f, "name", "") or _attr(f, "food_name", "") or ""
        cat = _attr(f, "category", "") or ""
        grams = _attr(f, "grams", None) or 100
        serv = grams / 100.0

        groups = _classify_food_groups(name, cat)
        for g in groups:
            if g in EDIH_HYPER:
                contrib = EDIH_HYPER[g] * serv
                edih_score += contrib
                edih_contributors.append({"food": name, "group": g, "contribution": round(contrib, 3), "direction": "hyper"})
            if g in EDIH_HYPO:
                contrib = EDIH_HYPO[g] * serv
                edih_score += contrib
                edih_contributors.append({"food": name, "group": g, "contribution": round(contrib, 3), "direction": "hypo"})
            if g in EDIP_PRO:
                contrib = EDIP_PRO[g] * serv
                edip_score += contrib
                edip_contributors.append({"food": name, "group": g, "contribution": round(contrib, 3), "direction": "pro"})
            if g in EDIP_ANTI:
                contrib = EDIP_ANTI[g] * serv
                edip_score += contrib
                edip_contributors.append({"food": name, "group": g, "contribution": round(contrib, 3), "direction": "anti"})

    edih_score = round(edih_score, 3)
    edip_score = round(edip_score, 3)

    # Tier labels — published Tabung 2017/2016 quintile cutoffs adapted to
    # per-meal magnitude (~1/3 of daily score).
    def _tier(score: float, thresholds=(-0.05, 0.05, 0.20)) -> tuple[str, str, str]:
        # thresholds (low/neutral/elevated/high)
        if score <= thresholds[0]:
            return "favorable", "Благоприятен", "#10B981"
        if score <= thresholds[1]:
            return "neutral", "Неутрален", "#84CC16"
        if score <= thresholds[2]:
            return "elevated", "Повишен", "#F59E0B"
        return "high", "Висок", "#EF4444"

    edih_label, edih_label_bg, edih_color = _tier(edih_score)
    edip_label, edip_label_bg, edip_color = _tier(edip_score)

    return {
        "edih": {
            "score": edih_score,
            "label": edih_label,
            "label_bg": edih_label_bg,
            "color": edih_color,
            "interpretation_bg": (
                "Положителен EDIH = храненето насърчава хиперинсулинемия "
                "(червено месо, преработени меса, бързи захари, мазни сирена). "
                "Отрицателен = хипоинсулинемичен паттерн (вино в умерени количества, "
                "кафе, пълно мазни млечни, листни зеленчуци, цели плодове)."
            ),
            "interpretation_en": (
                "Positive EDIH = pattern promotes hyperinsulinemia (red/processed meat, "
                "rapid sugars, high-fat cheese). Negative = hypoinsulinemic pattern "
                "(moderate wine, coffee, whole-fat dairy, leafy greens, whole fruit)."
            ),
            "methodology": "Tabung 2017, PMID 28196579 — meal-level proxy",
            "contributors": edih_contributors,
        },
        "edip": {
            "score": edip_score,
            "label": edip_label,
            "label_bg": edip_label_bg,
            "color": edip_color,
            "interpretation_bg": (
                "Положителен EDIP = провъзпалителен паттерн (червено/преработено месо, "
                "рафинирани зърнени, газирани напитки, доматено-базирани сосове). "
                "Отрицателен = противовъзпалителен (зелени и жълти зеленчуци, чай, кафе, "
                "вино в умерени количества)."
            ),
            "interpretation_en": (
                "Positive EDIP = pro-inflammatory pattern (red/processed meat, refined "
                "grains, sodas, tomato-based sauces). Negative = anti-inflammatory "
                "(leafy/yellow vegetables, tea, coffee, moderate wine)."
            ),
            "methodology": "Tabung 2016, PMID 27358416 — meal-level proxy",
            "contributors": edip_contributors,
        },
    }


def calculate_meal_pattern_indices(foods: list) -> dict:
    """Public entry point — returns PRAL + EDIH + EDIP + DII + NEAP for a plate.

    Args:
        foods: list of PlateFood-like objects with name, grams, protein_g,
               carbs_g, fiber_g, fat_g, category, and optional minerals.

    Returns:
        {
          "pral": {...} or None,
          "neap": {...} or None,        # iter327S
          "edih": {...},
          "edip": {...},
          "dii": {...},                 # iter327S
          "unified_inflammation": {...},  # iter350 — composite score
          "disclaimer_bg": "...",
          "disclaimer_en": "...",
        }
    """
    pral = _meal_pral(foods)
    neap = _meal_neap(foods)
    edih_edip = _meal_edih_edip(foods)
    dii = _meal_dii(foods)
    unified = _unified_inflammation_score(
        edip=edih_edip.get("edip"),
        dii=dii,
        neap=neap,
    )
    return {
        "pral": pral,
        "neap": neap,
        **edih_edip,
        "dii": dii,
        "unified_inflammation": unified,
        "disclaimer_bg": (
            "Индексите са peer-reviewed (PRAL: Remer 1995; NEAP: Frassetto 1998; "
            "EDIH: Tabung 2017; EDIP: Tabung 2016; DII: Shivappa 2014). "
            "Оригиналните формули са FFQ-based; тук се прилага per-meal proxy. "
            "Образователна референция; не замества лекарски съвет."
        ),
        "disclaimer_en": (
            "Indices are peer-reviewed (PRAL: Remer 1995; NEAP: Frassetto 1998; "
            "EDIH: Tabung 2017; EDIP: Tabung 2016; DII: Shivappa 2014). "
            "Original formulas are FFQ-based; this is a per-meal proxy. "
            "Educational reference; not medical advice."
        ),
    }


# ── iter350: Unified Inflammation Score (UIS) ──────────────────────────────
# Combines three peer-reviewed inflammation-related indices into a single
# normalized 0-100 % score, where 0 = strongly anti-inflammatory and
# 100 = strongly pro-inflammatory. Methodology:
#   1. Normalize EDIP score → [-1, +1] using empirical quintile cutoffs from
#      Tabung 2016 (J Nutr 146:1560-1570).
#   2. Normalize DII score → [-1, +1] using Shivappa 2014 cohort cutoffs
#      (PMID 23824729).
#   3. Normalize NEAP score → [-1, +1] using Frassetto 1998 cohort cutoffs
#      (alkalinizing < 30 → -1; high acid > 75 → +1).
#   4. Weighted average (EDIP 0.40, DII 0.40, NEAP 0.20) — EDIP and DII are
#      direct inflammatory pattern indices; NEAP is a metabolic-acid-load
#      modulator linked to systemic low-grade inflammation (Adeva 2011, PMID
#      21864752).
#   5. Map [-1, +1] → [0, 100] %.
def _normalize_pm1(value: float, anti_at: float, pro_at: float) -> float:
    """Map score linearly to [-1, +1] given empirical anti/pro cutoffs.

    anti_at → -1.0, pro_at → +1.0. Saturates beyond cutoffs.
    """
    if pro_at == anti_at:
        return 0.0
    norm = 2.0 * (value - anti_at) / (pro_at - anti_at) - 1.0
    return max(-1.0, min(1.0, norm))


def _unified_inflammation_score(edip: Optional[dict], dii: Optional[dict],
                                 neap: Optional[dict]) -> dict:
    """Composite inflammation score (0-100 %, higher = more pro-inflammatory).

    Returns dict with `percent`, tier labels (BG/EN/ES), color, contributing
    components, methodology, interpretation. If insufficient inputs → returns
    a fallback dict with `available: False`.
    """
    components: list[dict] = []
    weights: list[float] = []
    norm_values: list[float] = []

    # EDIP: anti at -0.20 (Tabung Q1 cohort), pro at +0.30 (Q5)
    if edip and isinstance(edip.get("score"), (int, float)):
        n = _normalize_pm1(edip["score"], anti_at=-0.20, pro_at=0.30)
        components.append({
            "name": "EDIP",
            "raw": edip["score"],
            "normalized": round(n, 2),
            "weight": 0.40,
            "label_bg": edip.get("label_bg"),
            "label_en": edip.get("label"),
            "color": edip.get("color"),
        })
        norm_values.append(n)
        weights.append(0.40)

    # DII: anti at -1.5 (Shivappa cohort lower), pro at +1.5 (cohort upper)
    if dii and isinstance(dii.get("score"), (int, float)):
        n = _normalize_pm1(dii["score"], anti_at=-1.5, pro_at=1.5)
        components.append({
            "name": "DII",
            "raw": dii["score"],
            "normalized": round(n, 2),
            "weight": 0.40,
            "label_bg": dii.get("tier_bg"),
            "label_en": dii.get("tier_en"),
            "color": dii.get("color"),
        })
        norm_values.append(n)
        weights.append(0.40)

    # NEAP: anti at 20 (alkalizing), pro at 80 (high acid load)
    if neap and isinstance(neap.get("score_meq"), (int, float)):
        n = _normalize_pm1(neap["score_meq"], anti_at=20.0, pro_at=80.0)
        components.append({
            "name": "NEAP",
            "raw": neap["score_meq"],
            "normalized": round(n, 2),
            "weight": 0.20,
            "label_bg": neap.get("tier_bg"),
            "label_en": neap.get("tier_en"),
            "color": neap.get("color"),
        })
        norm_values.append(n)
        weights.append(0.20)

    if not norm_values:
        return {
            "available": False,
            "percent": None,
            "tier_bg": "Недостатъчно данни",
            "tier_en": "Insufficient data",
            "tier_es": "Datos insuficientes",
            "color": "#9CA3AF",
            "components": [],
            "methodology": "iter350 — composite of EDIP+DII+NEAP",
            "interpretation_bg": "Нужни са повече макронутриенти за изчисление.",
            "interpretation_en": "More macronutrient data needed.",
            "interpretation_es": "Se requieren más datos de macronutrientes.",
        }

    # Renormalize weights for available components
    total_w = sum(weights)
    composite_norm = sum(n * w for n, w in zip(norm_values, weights)) / total_w
    # Map [-1, +1] → [0, 100]
    percent = round((composite_norm + 1.0) * 50.0, 1)
    percent = max(0.0, min(100.0, percent))

    # Tier labels — symmetric quintiles
    if percent < 25:
        tier_bg = "Силно противовъзпалително"
        tier_en = "Strongly anti-inflammatory"
        tier_es = "Fuertemente antiinflamatorio"
        color = "#10B981"
    elif percent < 45:
        tier_bg = "Леко противовъзпалително"
        tier_en = "Mildly anti-inflammatory"
        tier_es = "Levemente antiinflamatorio"
        color = "#84CC16"
    elif percent <= 55:
        tier_bg = "Неутрално"
        tier_en = "Neutral"
        tier_es = "Neutro"
        color = "#EAB308"
    elif percent <= 75:
        tier_bg = "Леко провъзпалително"
        tier_en = "Mildly pro-inflammatory"
        tier_es = "Levemente proinflamatorio"
        color = "#F59E0B"
    else:
        tier_bg = "Силно провъзпалително"
        tier_en = "Strongly pro-inflammatory"
        tier_es = "Fuertemente proinflamatorio"
        color = "#EF4444"

    return {
        "available": True,
        "percent": percent,
        "tier_bg": tier_bg,
        "tier_en": tier_en,
        "tier_es": tier_es,
        "color": color,
        "components": components,
        "methodology": (
            "iter350 — Unified Inflammation Score (UIS): weighted composite "
            "of EDIP (0.40), DII (0.40) и NEAP (0.20). Each index normalized "
            "to [-1, +1] спрямо публикувани cohort cutoffs."
        ),
        "citations": [
            "EDIP: Tabung 2016, PMID 27358416",
            "DII: Shivappa 2014, PMID 23824729",
            "NEAP: Frassetto 1998, PMID 9734733",
            "NEAP↔inflammation link: Adeva 2011, PMID 21864752",
        ],
        "interpretation_bg": (
            f"UIS = {percent}% — {tier_bg}. Композитният индекс комбинира "
            "EDIP (емпиричен възпалителен паттерн), DII (валидиран 45-параметрен) "
            "и NEAP (метаболитно киселинно натоварване, свързано с хронично "
            "low-grade възпаление). 0% = силно противовъзпалително; 100% = "
            "силно провъзпалително."
        ),
        "interpretation_en": (
            f"UIS = {percent}% — {tier_en}. Composite index combining EDIP "
            "(empirical inflammatory pattern), DII (validated 45-parameter), "
            "and NEAP (metabolic acid load linked to chronic low-grade "
            "inflammation). 0% = strongly anti-inflammatory; 100% = "
            "strongly pro-inflammatory."
        ),
        "interpretation_es": (
            f"UIS = {percent}% — {tier_es}. Índice compuesto que combina "
            "EDIP (patrón inflamatorio empírico), DII (validado 45-parámetros) "
            "y NEAP (carga ácida metabólica vinculada a inflamación crónica "
            "low-grade). 0% = fuertemente antiinflamatorio; 100% = "
            "fuertemente proinflamatorio."
        ),
    }


# ── NEAP (Net Endogenous Acid Production) ──────────────────────────────────
# Frassetto et al. 1998, Am J Clin Nutr 68:576-583, PMID 9734733.
# Simpler than PRAL — uses just protein/potassium ratio. Validated against
# 24-h urine acid excretion. Useful when phosphorus/magnesium/calcium are
# missing (common with photo-AI logged meals).
#   NEAP (mEq/day) = 54.5 × (Protein_g / K_mEq) − 10.2
# Per-meal: scaled by grams.
def _meal_neap(foods: list) -> Optional[dict]:
    """Compute NEAP per meal. Returns None if K data unavailable for ≥1 food."""
    total_protein = 0.0
    total_k_meq = 0.0
    contributing = 0
    for f in foods:
        protein = getattr(f, "protein_g", None) or 0
        k_mg = _attr(f, "potassium_mg", None)
        grams = getattr(f, "grams", None) or 100
        if k_mg is None:
            # Fallback estimate: vegetables/fruits ≈ 250 mg K/100 g; meats ≈ 300 mg
            cat = (_attr(f, "category", "") or "").lower()
            if "vegetable" in cat or "fruit" in cat or "leafy" in cat:
                k_mg = 250 * (grams / 100.0)
            elif "meat" in cat or "fish" in cat or "poultry" in cat:
                k_mg = 300 * (grams / 100.0)
            elif "legume" in cat or "nuts" in cat:
                k_mg = 400 * (grams / 100.0)
            else:
                continue  # skip — not enough info
        else:
            k_mg = k_mg * (grams / 100.0) if k_mg < 1000 else k_mg  # already absolute if large
        total_protein += protein
        # K mEq = K mg / 39.1 (atomic weight of potassium)
        total_k_meq += float(k_mg) / 39.1
        contributing += 1

    if contributing == 0 or total_k_meq <= 0:
        return None
    neap = 54.5 * (total_protein / total_k_meq) - 10.2
    neap = round(neap, 1)

    # Tier (Frassetto cohort: <40 healthy; 40-70 moderate; >70 high acid load)
    if neap < 30:
        tier_bg, tier_en, color = "Алкализиращо", "Alkalizing", "#10B981"
    elif neap < 50:
        tier_bg, tier_en, color = "Балансирано", "Balanced", "#84CC16"
    elif neap < 75:
        tier_bg, tier_en, color = "Умерено киселинно", "Moderate acid load", "#F59E0B"
    else:
        tier_bg, tier_en, color = "Високо киселинно", "High acid load", "#EF4444"

    return {
        "score_meq": neap,
        "tier_bg": tier_bg,
        "tier_en": tier_en,
        "color": color,
        "interpretation_bg": (
            "NEAP < 30 = алкализиращо (богато на K от плодове/зеленчуци). "
            "> 75 = високо киселинно — рисково за костна минерализация и "
            "бъбречна функция при дългосрочна експозиция."
        ),
        "interpretation_en": (
            "NEAP < 30 = alkalizing (K-rich from fruits/vegetables). "
            "> 75 = high acid load — risk for bone mineralization and renal "
            "function with chronic exposure."
        ),
        "methodology": "Frassetto 1998, PMID 9734733 — protein/K ratio",
        "total_protein_g": round(total_protein, 1),
        "total_potassium_meq": round(total_k_meq, 1),
    }


# ── DII (Dietary Inflammatory Index) — Shivappa et al. 2014 ────────────────
# PMID 23824729. Most-validated inflammatory dietary index. Uses 45 food
# parameters. We provide a simplified per-meal proxy using a subset of
# parameters that are computable from common food fields.
#   DII = sum_i (centered_z(intake_i) × inflammatory_effect_score_i)
# We approximate centered z-scores via target ranges (intake / global mean − 1).

# Inflammatory effect scores (negative = anti-inflammatory)
_DII_EFFECTS = {
    "fiber":          -0.663,
    "protein":         0.021,
    "carbohydrate":    0.097,
    "saturated_fat":   0.373,
    "sugar":           0.214,
    "vitamin_c":      -0.424,
    "vitamin_d":      -0.446,
    "vitamin_e":      -0.419,
    "magnesium":      -0.484,
    "iron":            0.032,
    "zinc":           -0.313,
    "selenium":       -0.191,
    "n3_pufa":        -0.436,
    "n6_pufa":        -0.159,
    "energy_kcal":     0.180,
}
# Global mean intakes (Shivappa Table 1) — used for centered z-score
_DII_GLOBAL_MEAN = {
    "fiber":          18.8,
    "protein":         79.4,
    "carbohydrate":    272,
    "saturated_fat":   28.6,
    "sugar":           90,
    "vitamin_c":       118,
    "vitamin_d":       6.26,
    "vitamin_e":       8.73,
    "magnesium":       310.1,
    "iron":            13.35,
    "zinc":            9.84,
    "selenium":        67,
    "n3_pufa":         1.06,
    "n6_pufa":         10.8,
    "energy_kcal":     2056,
}


def _meal_dii(foods: list) -> dict:
    """Compute per-meal DII proxy using available macros + minerals.

    The full original DII uses 45 nutrients across a daily FFQ. Here we use
    the subset that PlateFood reliably exposes: fiber, protein, carbs, sat fat,
    sugar, kcal, plus minerals (iron, magnesium, vitamin C from cofactor DB
    estimates). Score is normalized so positive = pro-inflammatory.
    """
    intakes = {
        "fiber": 0.0, "protein": 0.0, "carbohydrate": 0.0,
        "saturated_fat": 0.0, "sugar": 0.0, "energy_kcal": 0.0,
        "iron": 0.0, "magnesium": 0.0, "vitamin_c": 0.0,
    }
    for f in foods:
        intakes["fiber"]         += _attr(f, "fiber_g", 0) or 0
        intakes["protein"]       += _attr(f, "protein_g", 0) or 0
        intakes["carbohydrate"]  += _attr(f, "carbs_g", 0) or 0
        intakes["saturated_fat"] += _attr(f, "sat_fat_g", 0) or 0
        intakes["sugar"]         += _attr(f, "sugar_g", 0) or 0
        # Estimate kcal from macros if not provided
        kcal = _attr(f, "calories", None)
        if kcal is None:
            kcal = ((_attr(f, "protein_g", 0) or 0) * 4
                    + (_attr(f, "carbs_g", 0) or 0) * 4
                    + (_attr(f, "fat_g", 0) or 0) * 9)
        intakes["energy_kcal"]   += kcal
        intakes["iron"]          += _attr(f, "iron_mg", 0) or 0
        intakes["magnesium"]     += _attr(f, "magnesium_mg", 0) or 0

    # DII calculation
    total_dii = 0.0
    contributing: list[dict] = []
    for nutrient, intake in intakes.items():
        if nutrient not in _DII_EFFECTS:
            continue
        global_mean = _DII_GLOBAL_MEAN[nutrient]
        # Centered z-score proxy (intake / global_mean − 1) capped to ±2
        z = (intake / global_mean) - 1 if global_mean > 0 else 0
        z = max(-2.0, min(2.0, z))
        contribution = z * _DII_EFFECTS[nutrient]
        total_dii += contribution
        if abs(contribution) > 0.01:
            contributing.append({
                "nutrient": nutrient,
                "intake": round(intake, 1),
                "z_proxy": round(z, 2),
                "effect_score": _DII_EFFECTS[nutrient],
                "contribution": round(contribution, 3),
            })

    total_dii = round(total_dii, 2)

    # Tier (Shivappa cohort: < -1.5 strong anti-inflam; > +1.5 strong pro-inflam)
    if total_dii < -1.0:
        tier_bg, tier_en, color = "Силно противовъзпалителен", "Strongly anti-inflammatory", "#10B981"
    elif total_dii < 0:
        tier_bg, tier_en, color = "Леко противовъзпалителен", "Mildly anti-inflammatory", "#84CC16"
    elif total_dii < 1.0:
        tier_bg, tier_en, color = "Леко провъзпалителен", "Mildly pro-inflammatory", "#F59E0B"
    else:
        tier_bg, tier_en, color = "Силно провъзпалителен", "Strongly pro-inflammatory", "#EF4444"

    return {
        "score": total_dii,
        "tier_bg": tier_bg,
        "tier_en": tier_en,
        "color": color,
        "interpretation_bg": (
            "DII = валидиран индекс с 45 параметра в оригинала (Shivappa 2014). "
            "Тук използваме 9 от тях достъпни на ниво ястие. "
            "Отрицателен = противовъзпалителен (фибри, Vit C/D/E, Mg, n-3). "
            "Положителен = провъзпалителен (наситени мазнини, захар, преработени)."
        ),
        "interpretation_en": (
            "DII is a validated 45-parameter index (Shivappa 2014). Here we use "
            "9 parameters available at meal level. Negative = anti-inflammatory "
            "(fiber, Vit C/D/E, Mg, n-3). Positive = pro-inflammatory "
            "(saturated fat, sugar, processed foods)."
        ),
        "methodology": "Shivappa 2014, PMID 23824729 — 9-parameter meal proxy",
        "contributors": sorted(contributing, key=lambda c: -abs(c["contribution"]))[:5],
    }
