"""Setup script for the nutramilo_health SDK.

Build & publish:
    python -m build
    twine upload dist/*
"""
from setuptools import setup, find_packages
from pathlib import Path

ROOT = Path(__file__).parent
README = (ROOT / "README.md").read_text(encoding="utf-8")

setup(
    name="nutramilo-health",
    version="0.2.0",
    description=(
        "Scientific SDK for peer-reviewed nutritional pattern indices "
        "(NIS, UIS, EDIP, DII, EDIH, NEAP, PRAL) used by the Nutramilo "
        "Health OS platform."
    ),
    long_description=README,
    long_description_content_type="text/markdown",
    author="Nutramilo Labs",
    author_email="science@nutramilo.com",
    url="https://nutramilo.com",
    license="MIT",
    packages=find_packages(exclude=["tests", "tests.*"]),
    python_requires=">=3.10",
    install_requires=[],  # pure-Python, zero runtime deps
    extras_require={
        "dev": ["pytest>=8.0", "build", "twine"],
        "validation": ["numpy>=1.24", "pandas>=2.0", "matplotlib>=3.7"],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Healthcare Industry",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Scientific/Engineering :: Medical Science Apps.",
        "Topic :: Scientific/Engineering :: Bio-Informatics",
    ],
    keywords=[
        "nutrition", "insulin-index", "inflammation", "DII", "EDIP", "EDIH",
        "PRAL", "NEAP", "metabolic-health", "health-os",
    ],
    project_urls={
        "Source": "https://github.com/nutramilo/health-os",
        "Documentation": "https://github.com/nutramilo/health-os/blob/main/sdk/README.md",
        "Tracker": "https://github.com/nutramilo/health-os/issues",
        "Changelog": "https://github.com/nutramilo/health-os/blob/main/sdk/CHANGELOG.md",
    },
)
