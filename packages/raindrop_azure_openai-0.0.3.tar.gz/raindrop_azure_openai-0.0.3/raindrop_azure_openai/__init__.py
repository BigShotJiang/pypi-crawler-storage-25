"""Raindrop integration for Azure OpenAI."""

from .wrapper import RaindropAzureOpenAI, create_raindrop_azure_openai

__version__ = "0.0.3"

__all__ = ["RaindropAzureOpenAI", "create_raindrop_azure_openai"]
