"""
Azure OpenAI client wrapper for Raindrop observability.

Wraps AzureOpenAI and AsyncAzureOpenAI clients to automatically capture
``chat.completions.create()`` calls and ship telemetry to Raindrop.

Usage (class-based)::

    from raindrop_azure_openai import RaindropAzureOpenAI
    from openai import AzureOpenAI

    raindrop = RaindropAzureOpenAI(api_key="rk_...")
    client = AzureOpenAI(azure_endpoint="...", api_key="...", api_version="...")
    wrapped = raindrop.wrap(client)

    response = wrapped.chat.completions.create(model="gpt-4o", messages=[...])
    raindrop.shutdown()

Usage (factory function, backwards-compatible)::

    from raindrop_azure_openai import create_raindrop_azure_openai
    from openai import AzureOpenAI

    raindrop = create_raindrop_azure_openai(api_key="your-write-key")
    client = AzureOpenAI(azure_endpoint="...", api_key="...", api_version="...")
    wrapped = raindrop.wrap(client)

    response = wrapped.chat.completions.create(model="gpt-4o", messages=[...])
    raindrop.shutdown()
"""

from __future__ import annotations

import json
import logging
import uuid
import warnings
from typing import TYPE_CHECKING, Any, Dict, Literal, Optional, Union

import raindrop.analytics as raindrop

if TYPE_CHECKING:
    from openai import AsyncAzureOpenAI, AzureOpenAI

logger = logging.getLogger("raindrop_azure_openai")


class RaindropAzureOpenAI:
    """Raindrop observability wrapper for Azure OpenAI clients.

    Provides ``wrap()``, ``flush()``, ``shutdown()``, ``identify()``,
    and ``track_signal()`` methods for instrumenting AzureOpenAI and
    AsyncAzureOpenAI clients.

    Args:
        api_key: Raindrop API key (``rk_...``). Pass ``None`` to disable
            telemetry shipping.
        user_id: Default user ID to associate with all events.
        convo_id: Default conversation ID to group related events.
        tracing_enabled: Enable OTEL-based tracing (default ``True``).
        bypass_otel_for_tools: Bypass OTEL for tool calls (default ``True``).
        debug: Enable verbose debug logging.
    """

    _METHOD_MAP = frozenset({"wrap", "flush", "shutdown", "identify", "track_signal"})

    def __init__(
        self,
        api_key: Optional[str] = None,
        user_id: Optional[str] = None,
        convo_id: Optional[str] = None,
        tracing_enabled: bool = True,
        bypass_otel_for_tools: bool = True,
        debug: bool = False,
    ) -> None:
        if debug:
            logger.setLevel(logging.DEBUG)
        else:
            logger.setLevel(logging.WARNING)
        if not api_key:
            warnings.warn(
                "[raindrop-azure-openai] api_key not provided; telemetry shipping is disabled",
                stacklevel=2,
            )
        raindrop.init(
            api_key=api_key or "",
            tracing_enabled=tracing_enabled,
            bypass_otel_for_tools=bypass_otel_for_tools,
        )
        self._user_id = user_id
        self._convo_id = convo_id

    def __getitem__(self, key: str) -> Any:
        """Support dict-style access for backwards compatibility.

        .. deprecated::
            Use attribute access instead.
        """
        if key in self._METHOD_MAP:
            warnings.warn(
                f'raindrop["{key}"] is deprecated — use raindrop.{key} instead',
                DeprecationWarning,
                stacklevel=2,
            )
            return getattr(self, key)
        raise KeyError(key)

    def __contains__(self, key: object) -> bool:
        """Support ``"wrap" in raindrop`` for backwards compatibility."""
        return key in self._METHOD_MAP

    def wrap(self, client: AzureOpenAI | AsyncAzureOpenAI) -> AzureOpenAI | AsyncAzureOpenAI:
        """Instrument an AzureOpenAI or AsyncAzureOpenAI client.

        Monkey-patches ``chat.completions.create`` to capture telemetry.
        Detects async clients automatically and instruments accordingly.

        Args:
            client: An ``AzureOpenAI`` or ``AsyncAzureOpenAI`` instance.

        Returns:
            The same client instance, now instrumented.
        """
        try:
            return _wrap_client(client, user_id=self._user_id, convo_id=self._convo_id)
        except Exception:
            logger.debug("Failed to wrap client", exc_info=True)
            return client

    def flush(self) -> None:
        """Flush pending telemetry events to Raindrop."""
        try:
            raindrop.flush()
        except Exception:
            logger.debug("Failed to flush events", exc_info=True)

    def shutdown(self) -> None:
        """Flush pending events and release resources."""
        try:
            raindrop.shutdown()
        except Exception:
            logger.debug("Failed to shutdown", exc_info=True)

    def identify(
        self,
        user_id: str,
        traits: Optional[Dict[str, Union[str, int, bool, float]]] = None,
    ) -> None:
        """Identify a user with optional traits.

        Args:
            user_id: The user identifier.
            traits: Optional dictionary of user traits.
        """
        try:
            raindrop.identify(user_id=user_id, traits=traits or {})
        except Exception:
            logger.debug("Failed to call raindrop.identify", exc_info=True)

    def track_signal(
        self,
        event_id: str,
        name: str,
        signal_type: Literal["default", "feedback", "edit"] = "default",
        *,
        timestamp: Optional[str] = None,
        properties: Optional[Dict[str, object]] = None,
        attachment_id: Optional[str] = None,
        comment: Optional[str] = None,
        after: Optional[str] = None,
        sentiment: Optional[Literal["POSITIVE", "NEGATIVE"]] = None,
    ) -> None:
        """Track a signal event.

        Args:
            event_id: The event ID to associate the signal with.
            name: Signal name.
            signal_type: One of "default", "feedback", or "edit".
            timestamp: Optional ISO-8601 timestamp string.
            properties: Optional extra properties dict.
            attachment_id: Optional attachment identifier.
            comment: Optional comment text.
            after: Optional "after" value for edit signals.
            sentiment: Optional sentiment ("POSITIVE" or "NEGATIVE").
        """
        try:
            raindrop.track_signal(
                event_id=event_id,
                name=name,
                signal_type=signal_type,
                timestamp=timestamp,
                properties=properties,
                attachment_id=attachment_id,
                comment=comment,
                after=after,
                sentiment=sentiment,
            )
        except Exception:
            logger.debug("Failed to call raindrop.track_signal", exc_info=True)


def create_raindrop_azure_openai(
    api_key: Optional[str] = None,
    user_id: Optional[str] = None,
    convo_id: Optional[str] = None,
    tracing_enabled: bool = True,
    bypass_otel_for_tools: bool = True,
    debug: bool = False,
) -> RaindropAzureOpenAI:
    """Create a Raindrop-instrumented Azure OpenAI wrapper.

    Backwards-compatible factory function. Returns a
    :class:`RaindropAzureOpenAI` instance.

    Args:
        api_key: Raindrop API key (``rk_...``). Pass ``None`` to disable
            telemetry shipping.
        user_id: Associate all events with this user.
        convo_id: Conversation ID to group related events.
        tracing_enabled: Enable OTEL-based tracing (default ``True``).
        bypass_otel_for_tools: Bypass OTEL for tool calls (default ``True``).
        debug: Enable verbose debug logging.

    Returns:
        A :class:`RaindropAzureOpenAI` instance with ``wrap``, ``flush``,
        ``shutdown``, ``identify``, and ``track_signal`` methods.
    """
    return RaindropAzureOpenAI(
        api_key=api_key,
        user_id=user_id,
        convo_id=convo_id,
        tracing_enabled=tracing_enabled,
        bypass_otel_for_tools=bypass_otel_for_tools,
        debug=debug,
    )


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _is_async_client(client: object) -> bool:
    """Check whether *client* is an ``AsyncAzureOpenAI`` instance.

    Uses class-name inspection to avoid importing the async class at
    runtime when only the sync client is used.
    """
    for cls in type(client).__mro__:
        if cls.__name__ == "AsyncAzureOpenAI":
            return True
    return False


def _wrap_client(
    client: AzureOpenAI | AsyncAzureOpenAI,
    user_id: Optional[str] = None,
    convo_id: Optional[str] = None,
) -> AzureOpenAI | AsyncAzureOpenAI:
    """Instrument an AzureOpenAI or AsyncAzureOpenAI client.

    Adds a ``_raindrop_wrapped`` sentinel attribute to prevent
    double-instrumentation.
    """
    if getattr(client, "_raindrop_wrapped", False) is True:
        logger.debug("Client already wrapped — skipping")
        return client

    try:
        completions = client.chat.completions
        original_create = completions.create

        if _is_async_client(client):
            async def wrapped_create_async(**kwargs: object) -> object:
                """Async wrapper around chat.completions.create."""
                return await _instrument_create_async(
                    original_create, kwargs, user_id, convo_id,  # type: ignore[arg-type]
                )

            completions.create = wrapped_create_async  # type: ignore[assignment]
        else:
            def wrapped_create_sync(**kwargs: object) -> object:
                """Sync wrapper around chat.completions.create."""
                return _instrument_create_sync(
                    original_create, kwargs, user_id, convo_id,  # type: ignore[arg-type]
                )

            completions.create = wrapped_create_sync  # type: ignore[assignment]

        client._raindrop_wrapped = True  # type: ignore[attr-defined]
    except Exception:
        logger.debug("Failed to wrap Azure OpenAI client", exc_info=True)

    return client


def _instrument_create_sync(
    original_fn: object,
    kwargs: Dict[str, object],
    user_id: Optional[str],
    convo_id: Optional[str],
) -> object:
    """Instrument a synchronous ``chat.completions.create`` call.

    Captures input, output, model, token usage, and errors as Raindrop
    telemetry events.
    """
    try:
        model_id = kwargs.get("model")
        input_text = _extract_input(kwargs.get("messages"))
        event_id = str(uuid.uuid4())
    except Exception:
        logger.debug("Failed to extract pre-call metadata", exc_info=True)
        return original_fn(**kwargs)  # type: ignore[operator]

    try:
        response = original_fn(**kwargs)  # type: ignore[operator]
    except Exception as exc:
        _track_error(exc, event_id, input_text, model_id, user_id, convo_id)
        raise

    _track_success(response, event_id, input_text, model_id, user_id, convo_id)
    return response


async def _instrument_create_async(
    original_fn: object,
    kwargs: Dict[str, object],
    user_id: Optional[str],
    convo_id: Optional[str],
) -> object:
    """Instrument an asynchronous ``chat.completions.create`` call.

    Captures input, output, model, token usage, and errors as Raindrop
    telemetry events.
    """
    try:
        model_id = kwargs.get("model")
        input_text = _extract_input(kwargs.get("messages"))
        event_id = str(uuid.uuid4())
    except Exception:
        logger.debug("Failed to extract pre-call metadata", exc_info=True)
        return await original_fn(**kwargs)  # type: ignore[operator]

    try:
        response = await original_fn(**kwargs)  # type: ignore[operator]
    except Exception as exc:
        _track_error(exc, event_id, input_text, model_id, user_id, convo_id)
        raise

    _track_success(response, event_id, input_text, model_id, user_id, convo_id)
    return response


def _track_error(
    exc: BaseException,
    event_id: str,
    input_text: Optional[str],
    model_id: object,
    user_id: Optional[str],
    convo_id: Optional[str],
) -> None:
    """Send a telemetry event for a failed ``chat.completions.create`` call.

    Captures the error type and message as event properties so failures
    are visible in the Raindrop dashboard.
    """
    try:
        properties: Dict[str, object] = {
            "error": True,
            "error_type": type(exc).__name__,
            "error_message": str(exc),
        }
        raindrop.track_ai(
            user_id=user_id or "unknown",
            event="ai_generation",
            event_id=event_id,
            input=input_text,
            model=model_id,
            properties=properties,
            convo_id=convo_id,
        )
    except Exception:
        logger.debug("Failed to track error event", exc_info=True)


def _track_success(
    response: object,
    event_id: str,
    input_text: Optional[str],
    model_id: object,
    user_id: Optional[str],
    convo_id: Optional[str],
) -> None:
    """Send a telemetry event for a successful ``chat.completions.create`` call.

    Extracts output text, response model, and token usage from the
    response object.
    """
    try:
        output_text = _extract_output(response)
        response_model = getattr(response, "model", model_id)
        usage = getattr(response, "usage", None)
        prompt_tokens = getattr(usage, "prompt_tokens", None) if usage else None
        completion_tokens = (
            getattr(usage, "completion_tokens", None) if usage else None
        )

        properties: Dict[str, object] = {}
        if prompt_tokens is not None:
            properties["ai.usage.prompt_tokens"] = prompt_tokens
        if completion_tokens is not None:
            properties["ai.usage.completion_tokens"] = completion_tokens

        # Capture finish_reason from the first choice
        finish_reason = _extract_finish_reason(response)
        if finish_reason is not None:
            properties["azure_openai.finish_reason"] = finish_reason

        # Capture extended token details (cached_tokens, reasoning_tokens)
        if usage is not None:
            prompt_details = getattr(usage, "prompt_tokens_details", None)
            if prompt_details is not None:
                cached = getattr(prompt_details, "cached_tokens", None)
                if cached is not None:
                    properties["ai.usage.cached_tokens"] = cached

            completion_details = getattr(usage, "completion_tokens_details", None)
            if completion_details is not None:
                reasoning = getattr(completion_details, "reasoning_tokens", None)
                if reasoning is not None:
                    properties["ai.usage.thoughts_tokens"] = reasoning

        raindrop.track_ai(
            user_id=user_id or "unknown",
            event="ai_generation",
            event_id=event_id,
            input=input_text,
            output=output_text,
            model=response_model,
            properties=properties or None,
            convo_id=convo_id,
        )
    except Exception:
        logger.debug("Failed to track success event", exc_info=True)


def _extract_input(messages: object) -> Optional[str]:
    """Extract the user's input text from the messages list.

    Looks for the last ``user`` role message; falls back to the last
    message of any role if no ``user`` message is found.

    Returns:
        The content string, or ``None`` if extraction fails.
    """
    if not isinstance(messages, list):
        return None
    try:
        user_msgs = [
            m for m in messages if isinstance(m, dict) and m.get("role") == "user"
        ]
        last_msg = user_msgs[-1] if user_msgs else (messages[-1] if messages else None)
        if not last_msg or not isinstance(last_msg, dict):
            return None
        content = last_msg.get("content", "")
        if isinstance(content, str):
            return content or None
        try:
            return json.dumps(content, default=str)
        except Exception:
            return str(content)
    except Exception:
        logger.debug("Failed to extract input from messages", exc_info=True)
        return None


def _extract_finish_reason(response: object) -> Optional[str]:
    """Extract ``finish_reason`` from the first choice of a chat completion response.

    Azure OpenAI responses include values like ``'stop'``, ``'length'``,
    ``'content_filter'``, or ``'tool_calls'``.

    Returns:
        The finish_reason string, or ``None`` if not available.
    """
    try:
        choices = getattr(response, "choices", None)
        if choices and len(choices) > 0:
            return getattr(choices[0], "finish_reason", None)
    except Exception:
        logger.debug("Failed to extract finish_reason", exc_info=True)
    return None


def _extract_output(response: object) -> Optional[str]:
    """Extract the assistant's reply from a chat completion response.

    Reads the ``content`` field of the first choice's message.

    Returns:
        The content string, or ``None`` if extraction fails.
    """
    try:
        choices = getattr(response, "choices", None)
        if choices and len(choices) > 0:
            message = getattr(choices[0], "message", None)
            if message:
                return getattr(message, "content", None)
    except Exception:
        logger.debug("Failed to extract output from response", exc_info=True)
    return None
