"""End-to-end tests for Azure OpenAI Raindrop integration.

These tests make REAL API calls to Azure OpenAI and verify that events
land in the Raindrop dashboard with correct properties via the TRPC API.
They are skipped in CI where the required environment variables are not set.
"""

from __future__ import annotations

import asyncio
import json
import os
import time
import uuid

import pytest
import requests

from raindrop_azure_openai import RaindropAzureOpenAI, create_raindrop_azure_openai

# ---------------------------------------------------------------------------
# Environment
# ---------------------------------------------------------------------------

WRITE_KEY = os.getenv("RAINDROP_WRITE_KEY") or os.getenv("RAINDROP_API_KEY")
AZURE_OPENAI_API_KEY = os.getenv("AZURE_OPENAI_API_KEY")
AZURE_OPENAI_ENDPOINT = os.getenv("AZURE_OPENAI_ENDPOINT")
AZURE_OPENAI_DEPLOYMENT = os.getenv("AZURE_OPENAI_DEPLOYMENT")
DASHBOARD_TOKEN = os.getenv("RAINDROP_DASHBOARD_TOKEN")
BACKEND_URL = os.getenv("RAINDROP_BACKEND_URL", "https://backend.raindrop.ai")

skip_unless_e2e = pytest.mark.skipif(
    not all([AZURE_OPENAI_API_KEY, AZURE_OPENAI_ENDPOINT, WRITE_KEY, DASHBOARD_TOKEN]),
    reason="Azure OpenAI credentials, RAINDROP_WRITE_KEY, and RAINDROP_DASHBOARD_TOKEN required",
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _fetch_events(convo_id: str, timeout: int = 30, min_count: int = 1) -> list:
    """Poll backend until at least *min_count* events with matching convoId appear."""
    deadline = time.time() + timeout
    while time.time() < deadline:
        input_data = json.dumps({
            "json": {
                "limit": 50,
                "orderBy": {"field": "timestamp", "direction": "desc"},
            }
        })
        resp = requests.get(
            f"{BACKEND_URL}/api/trpc/events.list",
            params={"input": input_data},
            headers={"Authorization": f"Bearer {DASHBOARD_TOKEN}"},
        )
        if resp.ok:
            all_events = resp.json().get("result", {}).get("data", [])
            matched = [
                ev for ev in all_events
                if (ev.get("aiData") or {}).get("convoId") == convo_id
            ]
            if len(matched) >= min_count:
                return matched
        time.sleep(3)
    return []


def _make_azure_client():
    from openai import AzureOpenAI
    return AzureOpenAI(
        azure_endpoint=AZURE_OPENAI_ENDPOINT,
        api_key=AZURE_OPENAI_API_KEY,
        api_version="2024-10-21",
    )


def _make_async_azure_client():
    from openai import AsyncAzureOpenAI
    return AsyncAzureOpenAI(
        azure_endpoint=AZURE_OPENAI_ENDPOINT,
        api_key=AZURE_OPENAI_API_KEY,
        api_version="2024-10-21",
    )


def _model() -> str:
    return AZURE_OPENAI_DEPLOYMENT or "gpt-4o-mini"


def _prop_int(props: dict, key: str) -> int:
    """Get a property value as int (dashboard may serialize as string)."""
    v = props.get(key)
    if v is None:
        raise KeyError(f"{key} not found in properties: {props}")
    return int(v)


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


@skip_unless_e2e
class TestEventPayloadProperties:
    """Verify that tracked events contain the correct aiData and properties."""

    def test_sync_event_has_complete_payload(self):
        convo_id = f"e2e-azure-payload-{uuid.uuid4().hex[:8]}"
        user_id = f"e2e-user-{uuid.uuid4().hex[:8]}"
        rd = RaindropAzureOpenAI(api_key=WRITE_KEY, user_id=user_id, convo_id=convo_id)
        client = _make_azure_client()
        wrapped = rd.wrap(client)

        response = wrapped.chat.completions.create(
            model=_model(),
            messages=[{"role": "user", "content": "Say 'hello world' and nothing else."}],
        )
        rd.shutdown()

        events = _fetch_events(convo_id)
        assert len(events) >= 1, f"Expected >= 1 event, got {len(events)}"

        ev = events[0]
        ai = ev.get("aiData") or {}

        # input/output must be present and non-empty
        assert ai.get("input"), "aiData.input should be captured"
        assert "hello world" in ai["input"].lower() or "hello" in ai["input"].lower(), \
            f"input should contain the user message, got: {ai['input'][:100]}"
        assert ai.get("output"), "aiData.output should be captured"

        # model should match the deployment
        assert ai.get("model"), "aiData.model should be captured"

        # convoId must match
        assert ai.get("convoId") == convo_id, \
            f"convoId mismatch: expected {convo_id}, got {ai.get('convoId')}"

        # userId must match
        assert ev.get("userId") == user_id, \
            f"userId mismatch: expected {user_id}, got {ev.get('userId')}"

        # properties must have token usage (values may be strings from the API)
        props = ev.get("properties") or {}
        assert _prop_int(props, "ai.usage.prompt_tokens") > 0, \
            f"prompt_tokens should be > 0, got {props.get('ai.usage.prompt_tokens')}"
        assert _prop_int(props, "ai.usage.completion_tokens") > 0, \
            f"completion_tokens should be > 0, got {props.get('ai.usage.completion_tokens')}"

        # finish_reason should be present (likely "stop" for a short reply)
        assert props.get("azure_openai.finish_reason") == "stop", \
            f"Expected finish_reason='stop', got {props.get('azure_openai.finish_reason')}"

    def test_async_event_has_complete_payload(self):
        convo_id = f"e2e-azure-async-payload-{uuid.uuid4().hex[:8]}"
        user_id = f"e2e-user-async-{uuid.uuid4().hex[:8]}"
        rd = RaindropAzureOpenAI(api_key=WRITE_KEY, user_id=user_id, convo_id=convo_id)
        client = _make_async_azure_client()
        wrapped = rd.wrap(client)

        async def _run():
            return await wrapped.chat.completions.create(
                model=_model(),
                messages=[{"role": "user", "content": "Say 'async hello' and nothing else."}],
            )

        response = asyncio.run(_run())
        rd.shutdown()

        assert response.choices[0].message.content is not None

        events = _fetch_events(convo_id)
        assert len(events) >= 1

        ev = events[0]
        ai = ev.get("aiData") or {}
        assert ai.get("input"), "async input should be captured"
        assert ai.get("output"), "async output should be captured"
        assert ai.get("model"), "async model should be captured"
        assert ai.get("convoId") == convo_id

        props = ev.get("properties") or {}
        assert _prop_int(props, "ai.usage.prompt_tokens") > 0
        assert _prop_int(props, "ai.usage.completion_tokens") > 0
        assert props.get("azure_openai.finish_reason") == "stop"


@skip_unless_e2e
class TestMultipleCalls:
    """Multiple sequential calls → verify distinct events with unique inputs."""

    def test_multiple_calls_produce_distinct_events(self):
        convo_id = f"e2e-azure-multi-{uuid.uuid4().hex[:8]}"
        rd = RaindropAzureOpenAI(api_key=WRITE_KEY, convo_id=convo_id)
        client = _make_azure_client()
        wrapped = rd.wrap(client)

        for i in range(3):
            wrapped.chat.completions.create(
                model=_model(),
                messages=[{"role": "user", "content": f"Count: {i}. Reply with just the number."}],
            )
        rd.shutdown()

        events = _fetch_events(convo_id, min_count=3)
        assert len(events) >= 3, f"Expected >= 3 events, got {len(events)}"

        inputs = [(ev.get("aiData") or {}).get("input", "") for ev in events]
        unique_inputs = set(inputs)
        assert len(unique_inputs) >= 2, \
            f"Expected distinct inputs across calls, got: {inputs}"


@skip_unless_e2e
class TestConvoGrouping:
    """Events with the same convo_id are grouped; different convo_ids are separate."""

    def test_events_grouped_by_convo_id(self):
        convo_id = f"e2e-azure-convo-{uuid.uuid4().hex[:8]}"
        other_convo = f"e2e-azure-other-{uuid.uuid4().hex[:8]}"

        rd1 = RaindropAzureOpenAI(api_key=WRITE_KEY, convo_id=convo_id)
        client1 = _make_azure_client()
        wrapped1 = rd1.wrap(client1)

        wrapped1.chat.completions.create(
            model=_model(),
            messages=[{"role": "user", "content": "Convo A message 1"}],
        )
        wrapped1.chat.completions.create(
            model=_model(),
            messages=[{"role": "user", "content": "Convo A message 2"}],
        )
        rd1.shutdown()

        rd2 = RaindropAzureOpenAI(api_key=WRITE_KEY, convo_id=other_convo)
        client2 = _make_azure_client()
        wrapped2 = rd2.wrap(client2)

        wrapped2.chat.completions.create(
            model=_model(),
            messages=[{"role": "user", "content": "Convo B message 1"}],
        )
        rd2.shutdown()

        events_a = _fetch_events(convo_id, min_count=2)
        events_b = _fetch_events(other_convo, min_count=1)

        assert len(events_a) >= 2
        assert len(events_b) >= 1

        for ev in events_a:
            assert (ev.get("aiData") or {}).get("convoId") == convo_id
        for ev in events_b:
            assert (ev.get("aiData") or {}).get("convoId") == other_convo


@skip_unless_e2e
class TestMultiTurnConversation:
    """System + user messages → verify input extraction picks the user message."""

    def test_system_plus_user_extracts_user_input(self):
        convo_id = f"e2e-azure-multiturn-{uuid.uuid4().hex[:8]}"
        rd = RaindropAzureOpenAI(api_key=WRITE_KEY, convo_id=convo_id)
        client = _make_azure_client()
        wrapped = rd.wrap(client)

        wrapped.chat.completions.create(
            model=_model(),
            messages=[
                {"role": "system", "content": "You are a geography expert."},
                {"role": "user", "content": "What is the capital of Japan?"},
            ],
        )
        rd.shutdown()

        events = _fetch_events(convo_id)
        assert len(events) >= 1

        ai = events[0].get("aiData") or {}
        assert ai.get("input"), "input should be captured"
        assert "japan" in ai["input"].lower(), \
            f"input should be the user message about Japan, got: {ai['input'][:100]}"
        assert "geography" not in ai["input"].lower(), \
            "input should NOT contain the system message"


@skip_unless_e2e
class TestErrorEventCapture:
    """Error events should still be tracked with error properties."""

    def test_error_event_has_error_properties(self):
        convo_id = f"e2e-azure-error-{uuid.uuid4().hex[:8]}"
        rd = RaindropAzureOpenAI(api_key=WRITE_KEY, convo_id=convo_id)
        client = _make_azure_client()
        wrapped = rd.wrap(client)

        try:
            wrapped.chat.completions.create(
                model="nonexistent-deployment-that-should-404",
                messages=[{"role": "user", "content": "This should fail"}],
            )
        except Exception:
            pass

        rd.shutdown()

        events = _fetch_events(convo_id, timeout=15)
        if not events:
            pytest.skip("Error event did not land in dashboard (pipeline may not store error events)")

        ev = events[0]
        props = ev.get("properties") or {}
        assert str(props.get("error")).lower() == "true", f"Expected error=true, got props: {props}"
        assert props.get("error_type"), "error_type should be present"
        assert props.get("error_message"), "error_message should be present"


@skip_unless_e2e
class TestFactoryFunction:
    """Factory function API produces events with the same payload shape."""

    def test_factory_function_event_payload(self):
        convo_id = f"e2e-azure-factory-{uuid.uuid4().hex[:8]}"
        rd = create_raindrop_azure_openai(api_key=WRITE_KEY, convo_id=convo_id)
        client = _make_azure_client()
        wrapped = rd.wrap(client)

        response = wrapped.chat.completions.create(
            model=_model(),
            messages=[{"role": "user", "content": "Say 'factory' and nothing else."}],
        )
        rd.shutdown()

        events = _fetch_events(convo_id)
        assert len(events) >= 1

        ev = events[0]
        ai = ev.get("aiData") or {}
        assert ai.get("input"), "factory input captured"
        assert ai.get("output"), "factory output captured"
        assert ai.get("model"), "factory model captured"

        props = ev.get("properties") or {}
        assert _prop_int(props, "ai.usage.prompt_tokens") > 0
