"""Tests for Azure OpenAI Raindrop integration."""

import asyncio
import logging
import warnings
from unittest.mock import MagicMock, patch

import pytest

from raindrop_azure_openai import RaindropAzureOpenAI, create_raindrop_azure_openai
from raindrop_azure_openai.wrapper import (
    _extract_finish_reason,
    _extract_input,
    _extract_output,
    _is_async_client,
    _wrap_client,
)


def _make_response(
    content="Hello!",
    model="gpt-4o-mini",
    prompt_tokens=10,
    completion_tokens=5,
    finish_reason="stop",
    cached_tokens=None,
    reasoning_tokens=None,
):
    msg = MagicMock()
    msg.content = content
    choice = MagicMock()
    choice.message = msg
    choice.finish_reason = finish_reason
    usage = MagicMock()
    usage.prompt_tokens = prompt_tokens
    usage.completion_tokens = completion_tokens

    # Extended token details
    if cached_tokens is not None:
        prompt_details = MagicMock()
        prompt_details.cached_tokens = cached_tokens
        usage.prompt_tokens_details = prompt_details
    else:
        usage.prompt_tokens_details = None

    if reasoning_tokens is not None:
        completion_details = MagicMock()
        completion_details.reasoning_tokens = reasoning_tokens
        usage.completion_tokens_details = completion_details
    else:
        usage.completion_tokens_details = None

    resp = MagicMock()
    resp.choices = [choice]
    resp.model = model
    resp.usage = usage
    return resp


class TestExtractInput:
    def test_user_message_only(self):
        messages = [
            {"role": "system", "content": "Be helpful"},
            {"role": "user", "content": "Hello!"},
        ]
        assert _extract_input(messages) == "Hello!"

    def test_no_user_falls_back_to_last(self):
        messages = [{"role": "system", "content": "Be helpful"}]
        assert _extract_input(messages) == "Be helpful"

    def test_none_input(self):
        assert _extract_input(None) is None

    def test_empty_list(self):
        assert _extract_input([]) is None


class TestExtractOutput:
    def test_extracts_content(self):
        resp = _make_response(content="Paris")
        assert _extract_output(resp) == "Paris"

    def test_handles_empty(self):
        resp = MagicMock()
        resp.choices = []
        assert _extract_output(resp) is None


class TestWrapClient:
    def test_chat_completion_tracked(self):
        client = MagicMock()
        fake_resp = _make_response(content="Paris", model="gpt-4o", prompt_tokens=12, completion_tokens=3)
        client.chat.completions.create = MagicMock(return_value=fake_resp)

        with patch("raindrop_azure_openai.wrapper.raindrop") as mock_rd:
            wrapped = _wrap_client(client, user_id="test-user")
            result = wrapped.chat.completions.create(
                model="gpt-4o",
                messages=[{"role": "user", "content": "What is the capital of France?"}],
            )

            assert result is fake_resp
            mock_rd.track_ai.assert_called_once()
            kwargs = mock_rd.track_ai.call_args.kwargs
            assert kwargs["user_id"] == "test-user"
            assert kwargs["input"] == "What is the capital of France?"
            assert kwargs["output"] == "Paris"
            assert kwargs["model"] == "gpt-4o"
            assert kwargs["properties"]["ai.usage.prompt_tokens"] == 12

    def test_error_tracked_and_reraised(self):
        client = MagicMock()
        client.chat.completions.create = MagicMock(side_effect=RuntimeError("Rate limited"))

        with patch("raindrop_azure_openai.wrapper.raindrop") as mock_rd:
            wrapped = _wrap_client(client, user_id="test-user")
            with pytest.raises(RuntimeError, match="Rate limited"):
                wrapped.chat.completions.create(model="gpt-4o", messages=[])
            mock_rd.track_ai.assert_called_once()
            call_kwargs = mock_rd.track_ai.call_args.kwargs
            assert call_kwargs["properties"]["error"] is True
            assert call_kwargs["properties"]["error_type"] == "RuntimeError"
            assert call_kwargs["properties"]["error_message"] == "Rate limited"

    def test_convo_id_forwarded(self):
        client = MagicMock()
        client.chat.completions.create = MagicMock(return_value=_make_response())

        with patch("raindrop_azure_openai.wrapper.raindrop") as mock_rd:
            wrapped = _wrap_client(client, user_id="u", convo_id="c1")
            wrapped.chat.completions.create(model="m", messages=[{"role": "user", "content": "Hi"}])
            assert mock_rd.track_ai.call_args.kwargs["convo_id"] == "c1"

    def test_multiple_calls_no_leak(self):
        client = MagicMock()
        client.chat.completions.create = MagicMock(return_value=_make_response())

        with patch("raindrop_azure_openai.wrapper.raindrop") as mock_rd:
            wrapped = _wrap_client(client, user_id="u")
            for _ in range(10):
                wrapped.chat.completions.create(model="m", messages=[{"role": "user", "content": "Hi"}])
            assert mock_rd.track_ai.call_count == 10

    def test_telemetry_error_does_not_mask_response(self):
        client = MagicMock()
        client.chat.completions.create = MagicMock(return_value=_make_response(content="OK"))

        with patch("raindrop_azure_openai.wrapper.raindrop") as mock_rd:
            mock_rd.track_ai.side_effect = RuntimeError("telemetry broke")
            wrapped = _wrap_client(client, user_id="u")
            result = wrapped.chat.completions.create(model="m", messages=[])
            assert result.choices[0].message.content == "OK"

    def test_user_id_defaults_to_unknown(self):
        client = MagicMock()
        client.chat.completions.create = MagicMock(return_value=_make_response())

        with patch("raindrop_azure_openai.wrapper.raindrop") as mock_rd:
            wrapped = _wrap_client(client, user_id=None)
            wrapped.chat.completions.create(model="m", messages=[])
            assert mock_rd.track_ai.call_args.kwargs["user_id"] == "unknown"


class TestDoubleWrapGuard:
    def test_double_wrap_is_noop(self):
        client = MagicMock()
        client.chat.completions.create = MagicMock(return_value=_make_response())

        with patch("raindrop_azure_openai.wrapper.raindrop"):
            wrapped = _wrap_client(client, user_id="u")
            first_create = wrapped.chat.completions.create
            double_wrapped = _wrap_client(wrapped, user_id="u")
            assert double_wrapped.chat.completions.create is first_create

    def test_raindrop_wrapped_attribute_set(self):
        client = MagicMock()
        client._raindrop_wrapped = False
        client.chat.completions.create = MagicMock(return_value=_make_response())

        with patch("raindrop_azure_openai.wrapper.raindrop"):
            wrapped = _wrap_client(client, user_id="u")
            assert wrapped._raindrop_wrapped is True


class TestAsyncClient:
    def test_is_async_client_detection(self):
        sync_client = MagicMock()
        assert _is_async_client(sync_client) is False

        class AsyncAzureOpenAI:
            """Mimics the real openai.AsyncAzureOpenAI class name."""

        async_client = AsyncAzureOpenAI()
        assert _is_async_client(async_client) is True

    def test_async_client_wraps_as_coroutine(self):
        class AsyncAzureOpenAI:
            """Mimics the real openai.AsyncAzureOpenAI class name."""

        client = AsyncAzureOpenAI()
        client.chat = MagicMock()
        client.chat.completions = MagicMock()

        async def fake_create(**kwargs):
            return _make_response()

        client.chat.completions.create = fake_create

        with patch("raindrop_azure_openai.wrapper.raindrop"):
            wrapped = _wrap_client(client, user_id="u")
            result = asyncio.run(
                wrapped.chat.completions.create(model="m", messages=[])
            )
            assert result.choices[0].message.content == "Hello!"

    def test_async_error_tracked_with_properties(self):
        class AsyncAzureOpenAI:
            """Mimics the real openai.AsyncAzureOpenAI class name."""

        client = AsyncAzureOpenAI()
        client.chat = MagicMock()
        client.chat.completions = MagicMock()

        async def fake_create(**kwargs):
            raise ValueError("quota exceeded")

        client.chat.completions.create = fake_create

        with patch("raindrop_azure_openai.wrapper.raindrop") as mock_rd:
            wrapped = _wrap_client(client, user_id="u")
            with pytest.raises(ValueError, match="quota exceeded"):
                asyncio.run(
                    wrapped.chat.completions.create(model="m", messages=[])
                )
            call_kwargs = mock_rd.track_ai.call_args.kwargs
            assert call_kwargs["properties"]["error_type"] == "ValueError"
            assert call_kwargs["properties"]["error_message"] == "quota exceeded"


class TestRaindropAzureOpenAIClass:
    def test_class_has_expected_methods(self):
        with patch("raindrop_azure_openai.wrapper.raindrop"):
            rd = RaindropAzureOpenAI(api_key="rk_test")
            assert callable(rd.wrap)
            assert callable(rd.flush)
            assert callable(rd.shutdown)
            assert callable(rd.identify)
            assert callable(rd.track_signal)

    def test_wrap_instruments_client(self):
        client = MagicMock()
        client.chat.completions.create = MagicMock(return_value=_make_response())

        with patch("raindrop_azure_openai.wrapper.raindrop") as mock_rd:
            rd = RaindropAzureOpenAI(api_key="rk_test", user_id="u1")
            wrapped = rd.wrap(client)
            wrapped.chat.completions.create(model="m", messages=[])
            mock_rd.track_ai.assert_called_once()

    def test_flush_delegates(self):
        with patch("raindrop_azure_openai.wrapper.raindrop") as mock_rd:
            rd = RaindropAzureOpenAI(api_key="rk_test")
            rd.flush()
            mock_rd.flush.assert_called_once()

    def test_shutdown_delegates(self):
        with patch("raindrop_azure_openai.wrapper.raindrop") as mock_rd:
            rd = RaindropAzureOpenAI(api_key="rk_test")
            rd.shutdown()
            mock_rd.shutdown.assert_called_once()

    def test_identify_delegates(self):
        with patch("raindrop_azure_openai.wrapper.raindrop") as mock_rd:
            rd = RaindropAzureOpenAI(api_key="rk_test")
            rd.identify("user-1", {"plan": "pro"})
            mock_rd.identify.assert_called_once_with(user_id="user-1", traits={"plan": "pro"})

    def test_track_signal_delegates(self):
        with patch("raindrop_azure_openai.wrapper.raindrop") as mock_rd:
            rd = RaindropAzureOpenAI(api_key="rk_test")
            rd.track_signal("evt-1", "thumbs_up", sentiment="POSITIVE")
            mock_rd.track_signal.assert_called_once_with(
                event_id="evt-1",
                name="thumbs_up",
                signal_type="default",
                timestamp=None,
                properties=None,
                attachment_id=None,
                comment=None,
                after=None,
                sentiment="POSITIVE",
            )

    def test_track_signal_without_sentiment(self):
        with patch("raindrop_azure_openai.wrapper.raindrop") as mock_rd:
            rd = RaindropAzureOpenAI(api_key="rk_test")
            rd.track_signal("evt-1", "thumbs_down")
            mock_rd.track_signal.assert_called_once_with(
                event_id="evt-1",
                name="thumbs_down",
                signal_type="default",
                timestamp=None,
                properties=None,
                attachment_id=None,
                comment=None,
                after=None,
                sentiment=None,
            )

    def test_track_signal_full_params(self):
        with patch("raindrop_azure_openai.wrapper.raindrop") as mock_rd:
            rd = RaindropAzureOpenAI(api_key="rk_test")
            rd.track_signal(
                "evt-1",
                "edit_signal",
                "edit",
                timestamp="2026-01-01T00:00:00Z",
                properties={"key": "value"},
                attachment_id="att-1",
                comment="edited",
                after="new text",
                sentiment="NEGATIVE",
            )
            mock_rd.track_signal.assert_called_once_with(
                event_id="evt-1",
                name="edit_signal",
                signal_type="edit",
                timestamp="2026-01-01T00:00:00Z",
                properties={"key": "value"},
                attachment_id="att-1",
                comment="edited",
                after="new text",
                sentiment="NEGATIVE",
            )

    def test_empty_api_key_warns(self):
        with patch("raindrop_azure_openai.wrapper.raindrop"):
            with warnings.catch_warnings(record=True) as w:
                warnings.simplefilter("always")
                RaindropAzureOpenAI(api_key="")
                assert len(w) == 1
                assert "api_key not provided" in str(w[0].message)

    def test_none_api_key_warns(self):
        with patch("raindrop_azure_openai.wrapper.raindrop"):
            with warnings.catch_warnings(record=True) as w:
                warnings.simplefilter("always")
                RaindropAzureOpenAI()
                assert len(w) == 1
                assert "api_key not provided" in str(w[0].message)


class TestFactory:
    def test_returns_raindrop_instance(self):
        with patch("raindrop_azure_openai.wrapper.raindrop") as mock_rd:
            result = create_raindrop_azure_openai(api_key="rk_test", user_id="u1")
            assert isinstance(result, RaindropAzureOpenAI)
            mock_rd.init.assert_called_once_with(
                api_key="rk_test",
                tracing_enabled=True,
                bypass_otel_for_tools=True,
            )

    def test_factory_passes_tracing_params(self):
        with patch("raindrop_azure_openai.wrapper.raindrop") as mock_rd:
            create_raindrop_azure_openai(
                api_key="rk_test",
                tracing_enabled=False,
                bypass_otel_for_tools=False,
            )
            mock_rd.init.assert_called_once_with(
                api_key="rk_test",
                tracing_enabled=False,
                bypass_otel_for_tools=False,
            )

    def test_factory_wrap_instruments_client(self):
        client = MagicMock()
        client.chat.completions.create = MagicMock(return_value=_make_response())

        with patch("raindrop_azure_openai.wrapper.raindrop") as mock_rd:
            rd = create_raindrop_azure_openai(api_key="rk_test", user_id="u1")
            wrapped = rd.wrap(client)
            wrapped.chat.completions.create(model="m", messages=[])
            mock_rd.track_ai.assert_called_once()

    def test_factory_forwards_debug_flag(self):
        with patch("raindrop_azure_openai.wrapper.raindrop"):
            with patch("raindrop_azure_openai.wrapper.logger") as mock_logger:
                create_raindrop_azure_openai(api_key="rk_test", debug=True)
                mock_logger.setLevel.assert_called_once_with(logging.DEBUG)


class TestDictStyleAccess:
    """Backwards compatibility: raindrop["wrap"], raindrop["flush"], etc."""

    def test_getitem_returns_methods(self):
        with patch("raindrop_azure_openai.wrapper.raindrop"):
            rd = RaindropAzureOpenAI(api_key="rk_test")
            with warnings.catch_warnings(record=True):
                warnings.simplefilter("always")
                assert rd["wrap"] == rd.wrap
                assert rd["flush"] == rd.flush
                assert rd["shutdown"] == rd.shutdown

    def test_getitem_emits_deprecation_warning(self):
        with patch("raindrop_azure_openai.wrapper.raindrop"):
            rd = RaindropAzureOpenAI(api_key="rk_test")
            with warnings.catch_warnings(record=True) as w:
                warnings.simplefilter("always")
                _ = rd["wrap"]
                assert len(w) == 1
                assert issubclass(w[0].category, DeprecationWarning)
                assert "deprecated" in str(w[0].message)

    def test_getitem_invalid_key_raises(self):
        with patch("raindrop_azure_openai.wrapper.raindrop"):
            rd = RaindropAzureOpenAI(api_key="rk_test")
            with pytest.raises(KeyError):
                rd["nonexistent"]

    def test_contains_operator(self):
        with patch("raindrop_azure_openai.wrapper.raindrop"):
            rd = RaindropAzureOpenAI(api_key="rk_test")
            assert "wrap" in rd
            assert "flush" in rd
            assert "shutdown" in rd
            assert "nonexistent" not in rd

    def test_dict_style_wrap_works(self):
        client = MagicMock()
        client.chat.completions.create = MagicMock(return_value=_make_response())

        with patch("raindrop_azure_openai.wrapper.raindrop") as mock_rd:
            rd = create_raindrop_azure_openai(api_key="rk_test", user_id="u1")
            with warnings.catch_warnings(record=True):
                warnings.simplefilter("always")
                wrapped = rd["wrap"](client)
            wrapped.chat.completions.create(model="m", messages=[])
            mock_rd.track_ai.assert_called_once()


class TestDebugFlag:
    """Tests for the debug=True constructor flag."""

    def test_debug_true_sets_logger_to_debug(self):
        with patch("raindrop_azure_openai.wrapper.raindrop"):
            with patch("raindrop_azure_openai.wrapper.logger") as mock_logger:
                RaindropAzureOpenAI(api_key="rk_test", debug=True)
                mock_logger.setLevel.assert_called_once_with(logging.DEBUG)

    def test_debug_false_resets_to_warning(self):
        with patch("raindrop_azure_openai.wrapper.raindrop"):
            with patch("raindrop_azure_openai.wrapper.logger") as mock_logger:
                RaindropAzureOpenAI(api_key="rk_test", debug=False)
                mock_logger.setLevel.assert_called_once_with(logging.WARNING)

    def test_debug_default_resets_to_warning(self):
        with patch("raindrop_azure_openai.wrapper.raindrop"):
            with patch("raindrop_azure_openai.wrapper.logger") as mock_logger:
                RaindropAzureOpenAI(api_key="rk_test")
                mock_logger.setLevel.assert_called_once_with(logging.WARNING)


class TestFinishReason:
    """Tests for finish_reason extraction."""

    def test_finish_reason_stop(self):
        resp = _make_response(finish_reason="stop")
        assert _extract_finish_reason(resp) == "stop"

    def test_finish_reason_length(self):
        resp = _make_response(finish_reason="length")
        assert _extract_finish_reason(resp) == "length"

    def test_finish_reason_content_filter(self):
        resp = _make_response(finish_reason="content_filter")
        assert _extract_finish_reason(resp) == "content_filter"

    def test_finish_reason_tool_calls(self):
        resp = _make_response(finish_reason="tool_calls")
        assert _extract_finish_reason(resp) == "tool_calls"

    def test_finish_reason_none_when_missing(self):
        resp = MagicMock()
        resp.choices = [MagicMock(spec=[])]
        # spec=[] means no attributes, so getattr returns None
        assert _extract_finish_reason(resp) is None

    def test_finish_reason_none_when_no_choices(self):
        resp = MagicMock()
        resp.choices = []
        assert _extract_finish_reason(resp) is None

    def test_finish_reason_none_when_choices_is_none(self):
        resp = MagicMock(spec=[])
        assert _extract_finish_reason(resp) is None

    def test_finish_reason_tracked_in_properties(self):
        client = MagicMock()
        fake_resp = _make_response(finish_reason="stop")
        client.chat.completions.create = MagicMock(return_value=fake_resp)

        with patch("raindrop_azure_openai.wrapper.raindrop") as mock_rd:
            wrapped = _wrap_client(client, user_id="u")
            wrapped.chat.completions.create(model="m", messages=[])
            props = mock_rd.track_ai.call_args.kwargs["properties"]
            assert props["azure_openai.finish_reason"] == "stop"

    def test_finish_reason_tool_calls_tracked(self):
        client = MagicMock()
        fake_resp = _make_response(finish_reason="tool_calls")
        client.chat.completions.create = MagicMock(return_value=fake_resp)

        with patch("raindrop_azure_openai.wrapper.raindrop") as mock_rd:
            wrapped = _wrap_client(client, user_id="u")
            wrapped.chat.completions.create(model="m", messages=[])
            props = mock_rd.track_ai.call_args.kwargs["properties"]
            assert props["azure_openai.finish_reason"] == "tool_calls"

    def test_finish_reason_not_set_when_none(self):
        client = MagicMock()
        fake_resp = _make_response(finish_reason=None)
        client.chat.completions.create = MagicMock(return_value=fake_resp)

        with patch("raindrop_azure_openai.wrapper.raindrop") as mock_rd:
            wrapped = _wrap_client(client, user_id="u")
            wrapped.chat.completions.create(model="m", messages=[])
            props = mock_rd.track_ai.call_args.kwargs["properties"]
            assert "azure_openai.finish_reason" not in props


class TestExtendedTokens:
    """Tests for extended token categories (cached_tokens, reasoning_tokens)."""

    def test_cached_tokens_tracked(self):
        client = MagicMock()
        fake_resp = _make_response(cached_tokens=50)
        client.chat.completions.create = MagicMock(return_value=fake_resp)

        with patch("raindrop_azure_openai.wrapper.raindrop") as mock_rd:
            wrapped = _wrap_client(client, user_id="u")
            wrapped.chat.completions.create(model="m", messages=[])
            props = mock_rd.track_ai.call_args.kwargs["properties"]
            assert props["ai.usage.cached_tokens"] == 50

    def test_reasoning_tokens_tracked_as_thoughts_tokens(self):
        client = MagicMock()
        fake_resp = _make_response(reasoning_tokens=200)
        client.chat.completions.create = MagicMock(return_value=fake_resp)

        with patch("raindrop_azure_openai.wrapper.raindrop") as mock_rd:
            wrapped = _wrap_client(client, user_id="u")
            wrapped.chat.completions.create(model="m", messages=[])
            props = mock_rd.track_ai.call_args.kwargs["properties"]
            assert props["ai.usage.thoughts_tokens"] == 200

    def test_both_extended_tokens_tracked(self):
        client = MagicMock()
        fake_resp = _make_response(cached_tokens=100, reasoning_tokens=300)
        client.chat.completions.create = MagicMock(return_value=fake_resp)

        with patch("raindrop_azure_openai.wrapper.raindrop") as mock_rd:
            wrapped = _wrap_client(client, user_id="u")
            wrapped.chat.completions.create(model="m", messages=[])
            props = mock_rd.track_ai.call_args.kwargs["properties"]
            assert props["ai.usage.cached_tokens"] == 100
            assert props["ai.usage.thoughts_tokens"] == 300

    def test_no_extended_tokens_when_details_missing(self):
        client = MagicMock()
        fake_resp = _make_response()  # no cached/reasoning tokens
        client.chat.completions.create = MagicMock(return_value=fake_resp)

        with patch("raindrop_azure_openai.wrapper.raindrop") as mock_rd:
            wrapped = _wrap_client(client, user_id="u")
            wrapped.chat.completions.create(model="m", messages=[])
            props = mock_rd.track_ai.call_args.kwargs["properties"]
            assert "ai.usage.cached_tokens" not in props
            assert "ai.usage.thoughts_tokens" not in props

    def test_cached_tokens_zero_is_tracked(self):
        client = MagicMock()
        fake_resp = _make_response(cached_tokens=0)
        client.chat.completions.create = MagicMock(return_value=fake_resp)

        with patch("raindrop_azure_openai.wrapper.raindrop") as mock_rd:
            wrapped = _wrap_client(client, user_id="u")
            wrapped.chat.completions.create(model="m", messages=[])
            props = mock_rd.track_ai.call_args.kwargs["properties"]
            assert props["ai.usage.cached_tokens"] == 0

    def test_reasoning_tokens_zero_is_tracked(self):
        client = MagicMock()
        fake_resp = _make_response(reasoning_tokens=0)
        client.chat.completions.create = MagicMock(return_value=fake_resp)

        with patch("raindrop_azure_openai.wrapper.raindrop") as mock_rd:
            wrapped = _wrap_client(client, user_id="u")
            wrapped.chat.completions.create(model="m", messages=[])
            props = mock_rd.track_ai.call_args.kwargs["properties"]
            assert props["ai.usage.thoughts_tokens"] == 0

    def test_extended_tokens_with_no_usage(self):
        """When response.usage is None, extended tokens are not tracked."""
        client = MagicMock()
        fake_resp = _make_response()
        fake_resp.usage = None
        client.chat.completions.create = MagicMock(return_value=fake_resp)

        with patch("raindrop_azure_openai.wrapper.raindrop") as mock_rd:
            wrapped = _wrap_client(client, user_id="u")
            wrapped.chat.completions.create(model="m", messages=[])
            props = mock_rd.track_ai.call_args.kwargs.get("properties")
            # properties is None when no tokens at all
            if props is not None:
                assert "ai.usage.cached_tokens" not in props
                assert "ai.usage.thoughts_tokens" not in props


class TestTracingFlags:
    """Tests for tracing_enabled and bypass_otel_for_tools flags."""

    def test_init_passes_tracing_flags_defaults(self):
        with patch("raindrop_azure_openai.wrapper.raindrop") as mock_rd:
            RaindropAzureOpenAI(api_key="rk_test")
            mock_rd.init.assert_called_once_with(
                api_key="rk_test",
                tracing_enabled=True,
                bypass_otel_for_tools=True,
            )

    def test_init_passes_custom_tracing_flags(self):
        with patch("raindrop_azure_openai.wrapper.raindrop") as mock_rd:
            RaindropAzureOpenAI(
                api_key="rk_test",
                tracing_enabled=False,
                bypass_otel_for_tools=False,
            )
            mock_rd.init.assert_called_once_with(
                api_key="rk_test",
                tracing_enabled=False,
                bypass_otel_for_tools=False,
            )

    def test_factory_passes_tracing_flags_defaults(self):
        with patch("raindrop_azure_openai.wrapper.raindrop") as mock_rd:
            create_raindrop_azure_openai(api_key="rk_test")
            mock_rd.init.assert_called_once_with(
                api_key="rk_test",
                tracing_enabled=True,
                bypass_otel_for_tools=True,
            )

    def test_empty_api_key_passes_empty_string(self):
        with patch("raindrop_azure_openai.wrapper.raindrop") as mock_rd:
            with warnings.catch_warnings(record=True):
                warnings.simplefilter("always")
                RaindropAzureOpenAI(api_key="")
            mock_rd.init.assert_called_once_with(
                api_key="",
                tracing_enabled=True,
                bypass_otel_for_tools=True,
            )


class TestFullPropertyCapture:
    """Integration tests verifying all properties are captured together."""

    def test_all_properties_captured_together(self):
        client = MagicMock()
        fake_resp = _make_response(
            content="Answer",
            model="gpt-4o",
            prompt_tokens=100,
            completion_tokens=50,
            finish_reason="stop",
            cached_tokens=25,
            reasoning_tokens=10,
        )
        client.chat.completions.create = MagicMock(return_value=fake_resp)

        with patch("raindrop_azure_openai.wrapper.raindrop") as mock_rd:
            wrapped = _wrap_client(client, user_id="u")
            wrapped.chat.completions.create(
                model="gpt-4o",
                messages=[{"role": "user", "content": "test"}],
            )
            props = mock_rd.track_ai.call_args.kwargs["properties"]
            assert props["ai.usage.prompt_tokens"] == 100
            assert props["ai.usage.completion_tokens"] == 50
            assert props["azure_openai.finish_reason"] == "stop"
            assert props["ai.usage.cached_tokens"] == 25
            assert props["ai.usage.thoughts_tokens"] == 10

    def test_async_captures_all_properties(self):
        class AsyncAzureOpenAI:
            """Mimics the real openai.AsyncAzureOpenAI class name."""

        client = AsyncAzureOpenAI()
        client.chat = MagicMock()
        client.chat.completions = MagicMock()

        fake_resp = _make_response(
            content="Async answer",
            finish_reason="length",
            cached_tokens=30,
            reasoning_tokens=15,
        )

        async def fake_create(**kwargs):
            return fake_resp

        client.chat.completions.create = fake_create

        with patch("raindrop_azure_openai.wrapper.raindrop") as mock_rd:
            wrapped = _wrap_client(client, user_id="u")
            asyncio.run(
                wrapped.chat.completions.create(
                    model="m", messages=[{"role": "user", "content": "Hi"}]
                )
            )
            props = mock_rd.track_ai.call_args.kwargs["properties"]
            assert props["azure_openai.finish_reason"] == "length"
            assert props["ai.usage.cached_tokens"] == 30
            assert props["ai.usage.thoughts_tokens"] == 15


class TestErrorSwallowing:
    """identify() and track_signal() must never crash user code."""

    def test_identify_swallows_raindrop_errors(self):
        with patch("raindrop_azure_openai.wrapper.raindrop") as mock_rd:
            mock_rd.identify.side_effect = RuntimeError("identify broke")
            rd = RaindropAzureOpenAI(api_key="rk_test")
            rd.identify("user-1", {"plan": "pro"})

    def test_track_signal_swallows_raindrop_errors(self):
        with patch("raindrop_azure_openai.wrapper.raindrop") as mock_rd:
            mock_rd.track_signal.side_effect = RuntimeError("signal broke")
            rd = RaindropAzureOpenAI(api_key="rk_test")
            rd.track_signal("evt-1", "thumbs_up")

    def test_identify_none_traits_passes_empty_dict(self):
        with patch("raindrop_azure_openai.wrapper.raindrop") as mock_rd:
            rd = RaindropAzureOpenAI(api_key="rk_test")
            rd.identify("user-1")
            mock_rd.identify.assert_called_once_with(user_id="user-1", traits={})

    def test_track_error_telemetry_failure_does_not_mask_exception(self):
        """When _track_error itself fails, the original exception must still propagate."""
        client = MagicMock()
        client.chat.completions.create = MagicMock(side_effect=ValueError("real error"))

        with patch("raindrop_azure_openai.wrapper.raindrop") as mock_rd:
            mock_rd.track_ai.side_effect = RuntimeError("telemetry broke")
            wrapped = _wrap_client(client, user_id="u")
            with pytest.raises(ValueError, match="real error"):
                wrapped.chat.completions.create(model="m", messages=[])


class TestAsyncParity:
    """Async path should capture the same properties as sync."""

    def test_async_error_includes_error_true(self):
        class AsyncAzureOpenAI:
            pass

        client = AsyncAzureOpenAI()
        client.chat = MagicMock()
        client.chat.completions = MagicMock()

        async def fake_create(**kwargs):
            raise ValueError("quota exceeded")

        client.chat.completions.create = fake_create

        with patch("raindrop_azure_openai.wrapper.raindrop") as mock_rd:
            wrapped = _wrap_client(client, user_id="u")
            with pytest.raises(ValueError, match="quota exceeded"):
                asyncio.run(wrapped.chat.completions.create(model="m", messages=[]))
            call_kwargs = mock_rd.track_ai.call_args.kwargs
            assert call_kwargs["properties"]["error"] is True
            assert call_kwargs["properties"]["error_type"] == "ValueError"
            assert call_kwargs["properties"]["error_message"] == "quota exceeded"

    def test_async_captures_prompt_and_completion_tokens(self):
        class AsyncAzureOpenAI:
            pass

        client = AsyncAzureOpenAI()
        client.chat = MagicMock()
        client.chat.completions = MagicMock()

        fake_resp = _make_response(prompt_tokens=42, completion_tokens=18)

        async def fake_create(**kwargs):
            return fake_resp

        client.chat.completions.create = fake_create

        with patch("raindrop_azure_openai.wrapper.raindrop") as mock_rd:
            wrapped = _wrap_client(client, user_id="u")
            asyncio.run(wrapped.chat.completions.create(
                model="m", messages=[{"role": "user", "content": "test"}]))
            props = mock_rd.track_ai.call_args.kwargs["properties"]
            assert props["ai.usage.prompt_tokens"] == 42
            assert props["ai.usage.completion_tokens"] == 18


class TestDefensiveTryExcept:
    """wrap(), flush(), shutdown() must swallow internal failures."""

    def test_flush_swallows_raindrop_errors(self):
        with patch("raindrop_azure_openai.wrapper.raindrop") as mock_rd:
            mock_rd.flush.side_effect = RuntimeError("flush broke")
            rd = RaindropAzureOpenAI(api_key="rk_test")
            rd.flush()

    def test_shutdown_swallows_raindrop_errors(self):
        with patch("raindrop_azure_openai.wrapper.raindrop") as mock_rd:
            mock_rd.shutdown.side_effect = RuntimeError("shutdown broke")
            rd = RaindropAzureOpenAI(api_key="rk_test")
            rd.shutdown()

    def test_wrap_returns_unwrapped_client_on_internal_error(self):
        """If _wrap_client raises, wrap() returns the original client unchanged."""
        client = MagicMock()
        client._raindrop_wrapped = False
        client.chat = None  # will cause AttributeError in _wrap_client

        with patch("raindrop_azure_openai.wrapper.raindrop"):
            rd = RaindropAzureOpenAI(api_key="rk_test")
            result = rd.wrap(client)
            assert result is client
            assert not getattr(result, "_raindrop_wrapped", True)

    def test_factory_propagates_init_failure(self):
        """Factory should let init exceptions propagate — no silent fallback."""
        with patch("raindrop_azure_openai.wrapper.raindrop") as mock_rd:
            mock_rd.init.side_effect = RuntimeError("init failed")
            with warnings.catch_warnings(record=True):
                warnings.simplefilter("always")
                with pytest.raises(RuntimeError, match="init failed"):
                    create_raindrop_azure_openai(api_key="rk_test", user_id="u1")


class TestEdgeCases:
    """Edge cases in _track_success."""

    def test_completion_tokens_in_main_sync_test(self):
        """The main sync test should verify both prompt and completion tokens."""
        client = MagicMock()
        fake_resp = _make_response(prompt_tokens=12, completion_tokens=3)
        client.chat.completions.create = MagicMock(return_value=fake_resp)

        with patch("raindrop_azure_openai.wrapper.raindrop") as mock_rd:
            wrapped = _wrap_client(client, user_id="u")
            wrapped.chat.completions.create(
                model="m", messages=[{"role": "user", "content": "test"}])
            props = mock_rd.track_ai.call_args.kwargs["properties"]
            assert props["ai.usage.prompt_tokens"] == 12
            assert props["ai.usage.completion_tokens"] == 3

    def test_no_usage_no_finish_reason_produces_no_properties(self):
        """When there are no tokens and no finish_reason, properties should be None."""
        client = MagicMock()
        fake_resp = _make_response(finish_reason=None)
        fake_resp.usage = None
        client.chat.completions.create = MagicMock(return_value=fake_resp)

        with patch("raindrop_azure_openai.wrapper.raindrop") as mock_rd:
            wrapped = _wrap_client(client, user_id="u")
            wrapped.chat.completions.create(model="m", messages=[])
            assert mock_rd.track_ai.call_args.kwargs["properties"] is None

    def test_response_model_overrides_request_model(self):
        """track_ai should use response.model, not the model kwarg from the request."""
        client = MagicMock()
        fake_resp = _make_response(model="gpt-4o-2024-08-06")
        client.chat.completions.create = MagicMock(return_value=fake_resp)

        with patch("raindrop_azure_openai.wrapper.raindrop") as mock_rd:
            wrapped = _wrap_client(client, user_id="u")
            wrapped.chat.completions.create(
                model="gpt-4o", messages=[{"role": "user", "content": "test"}])
            assert mock_rd.track_ai.call_args.kwargs["model"] == "gpt-4o-2024-08-06"


class TestVersion:
    def test_version_exported(self):
        from raindrop_azure_openai import __version__
        assert isinstance(__version__, str)
        assert __version__ == "0.0.3"


class TestExports:
    def test_class_exported(self):
        from raindrop_azure_openai import RaindropAzureOpenAI as Cls
        assert Cls is RaindropAzureOpenAI

    def test_factory_exported(self):
        from raindrop_azure_openai import create_raindrop_azure_openai as fn
        assert callable(fn)
