"""
CLI entry points for PrePrompt.

Commands
--------
preprompt-history            View recent prompt history (all sessions)
preprompt-stats              Aggregate optimization stats
preprompt-test-classifier    Run the classifier against 6 benchmark prompts
preprompt-memory             Show learned stack memory
preprompt-optimize           Optimize a prompt from the command line
"""

import argparse
import sys
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from cli.setup import maybe_run_setup

_DB_PATH = Path.home() / ".preprompt" / "history.db"


# ── Helpers ───────────────────────────────────────────────────────────────────

def _relative_time(dt) -> str:
    if isinstance(dt, str):
        dt = datetime.fromisoformat(dt)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    delta = datetime.now(timezone.utc) - dt
    seconds = int(delta.total_seconds())
    if seconds < 60:
        return f"{seconds}s ago"
    if seconds < 3600:
        return f"{seconds // 60}m ago"
    if seconds < 86400:
        return f"{seconds // 3600}h ago"
    return f"{seconds // 86400}d ago"


def _truncate(text: str, width: int) -> str:
    if len(text) <= width:
        return text
    return text[: width - 3] + "..."


def _open_db() -> sqlite3.Connection:
    if not _DB_PATH.exists():
        print(f"No history database found at {_DB_PATH}", file=sys.stderr)
        print("Run PrePrompt and send a few prompts first.", file=sys.stderr)
        sys.exit(1)
    from storage.db import get_read_connection
    return get_read_connection()


# ── Version check ────────────────────────────────────────────────────────────

def _parse_version(v: str) -> tuple:
    try:
        return tuple(int(x) for x in v.split("."))
    except Exception:
        return (0,)


def _check_for_updates() -> None:
    """Silently check PyPI for newer version. Print notice if behind."""
    try:
        import urllib.request, json
        from importlib.metadata import version as pkg_version
        current = pkg_version("preprompt")
        url = "https://pypi.org/pypi/preprompt/json"
        req = urllib.request.Request(url, headers={"User-Agent": "preprompt-cli"})
        with urllib.request.urlopen(req, timeout=2) as r:
            latest = json.loads(r.read())["info"]["version"]
        if _parse_version(latest) > _parse_version(current):
            print(f"  ⚡ PrePrompt {latest} available (you have {current})")
            print(f"     Run: preprompt-update")
            print()
    except Exception:
        pass  # never block CLI on network failure


# ── preprompt-history ────────────────────────────────────────────────────────

def history_cmd() -> None:
    maybe_run_setup()
    _check_for_updates()
    parser = argparse.ArgumentParser(
        prog="preprompt-history",
        description="Show recent prompts seen by PrePrompt (all sessions).",
    )
    parser.add_argument("--limit", type=int, default=20, metavar="N",
                        help="Maximum rows to display (default: 20)")
    parser.add_argument("--intercepted-only", action="store_true",
                        help="Show only prompts that were optimized")
    args = parser.parse_args()

    if not _DB_PATH.exists():
        print("No history database found. Run PrePrompt and send a few prompts first.")
        return

    try:
        from storage.db import get_all_history, flush_pending_hook_events
        flush_pending_hook_events()
        events = get_all_history(limit=args.limit, intercepted_only=args.intercepted_only)
    except Exception as e:
        print(f"Error reading history: {e}", file=sys.stderr)
        return

    if not events:
        print("No prompt history found.")
        return

    col_time   = 8
    col_score  = 5
    col_int    = 3
    col_prompt = 60

    header = f"{'TIME':<{col_time}}  {'SCORE':>{col_score}}  {'INT':<{col_int}}  ORIGINAL PROMPT"
    sep    = "─" * (col_time + 2 + col_score + 2 + col_int + 2 + col_prompt)
    print(header)
    print(sep)

    for e in events:
        time_str   = _relative_time(e["timestamp"])
        int_str    = "yes" if e["was_intercepted"] else "no"
        prompt_str = _truncate(e["original_prompt"] or "", col_prompt)
        print(f"{time_str:<{col_time}}  {e['classifier_score']:>{col_score}}  {int_str:<{col_int}}  {prompt_str}")


# ── preprompt-stats ──────────────────────────────────────────────────────────

def stats_cmd() -> None:
    maybe_run_setup()
    _check_for_updates()
    from storage.db import flush_pending_hook_events
    flush_pending_hook_events()
    conn = _open_db()
    row = conn.execute("""
        SELECT
            COUNT(*)                                            AS total,
            SUM(CASE WHEN was_intercepted THEN 1 ELSE 0 END)   AS intercepted,
            AVG(classifier_score)                              AS avg_score,
            AVG(CASE WHEN was_intercepted THEN classifier_score END) AS avg_intercepted,
            COUNT(DISTINCT session_id)                         AS sessions
        FROM prompt_history
    """).fetchone()
    conn.close()

    total, intercepted, avg_score, avg_intercepted, sessions = row
    total        = total or 0
    intercepted  = intercepted or 0
    avg_score    = avg_score or 0.0
    avg_intercepted = avg_intercepted or 0.0
    pct = (intercepted / total * 100) if total else 0.0

    try:
        from importlib.metadata import version as pkg_version
        v = pkg_version("preprompt")
    except Exception:
        v = "dev"
    sep = "─" * 46
    print(f" PrePrompt v{v} — optimization stats")
    print(sep)
    print(f" Total prompts seen:      {total}")
    print(f" Prompts intercepted:     {intercepted} ({pct:.1f}%)")
    print(f" Avg classifier score:    {avg_score:.1f}")
    print(f" Avg score (intercepted): {avg_intercepted:.1f}")
    print(f" Sessions tracked:        {sessions}")
    print(f" DB path:                 {_DB_PATH}")

    from storage.db import get_feedback_stats
    fb = get_feedback_stats()
    if fb["accept_rate"] is not None:
        print(f" Accept rate:             {fb['accept_rate']}% "
              f"({fb['kept']} kept / {fb['rejected']} rejected)")


# ── preprompt-test-classifier ────────────────────────────────────────────────

_BENCHMARK_PROMPTS = [
    "write me a middleware that validates tokens and handles refresh",
    "what is jwt",
    "thanks",
    "refactor this to handle edge cases and manage errors properly",
    "add tests",
    (
        "implement a rate limiter that tracks requests, manages quotas, "
        "and handles burst traffic with backoff"
    ),
]


def test_classifier_cmd() -> None:
    maybe_run_setup()
    _here = Path(__file__).resolve().parent.parent
    if str(_here) not in sys.path:
        sys.path.insert(0, str(_here))

    from mcp_server.classifier import classify_prompt, OPTIMIZATION_THRESHOLD

    col_score  = 5
    col_flag   = 9
    col_prompt = 65

    header = f"{'SCORE':>{col_score}}  {'INTERCEPT':<{col_flag}}  PROMPT"
    sep    = "─" * (col_score + 2 + col_flag + 2 + col_prompt)
    print(header)
    print(sep)

    for prompt in _BENCHMARK_PROMPTS:
        score = classify_prompt(prompt, history=[], turn=1)
        flag  = "YES" if score >= OPTIMIZATION_THRESHOLD else "no"
        print(f"{score:>{col_score}}  {flag:<{col_flag}}  {_truncate(prompt, col_prompt)}")


# ── preprompt-memory ─────────────────────────────────────────────────────────

def memory_cmd() -> None:
    maybe_run_setup()
    conn = _open_db()

    try:
        rows = conn.execute("""
            SELECT key, value, confidence, source_count, updated_at
            FROM stack_memory
            ORDER BY confidence DESC
        """).fetchall()
    except Exception:
        # Table doesn't exist yet — DB predates Phase 3
        rows = []

    if not rows:
        conn.close()
        print("No stack memory yet. Send a few prompts in Claude Code to build it.")
        return

    total_prompts = conn.execute("SELECT COUNT(*) FROM prompt_history").fetchone()[0]
    last_updated  = max(row[4] for row in rows)   # ISO string — max() is lexicographic, correct
    conn.close()

    sep = "─" * 54
    print(" PrePrompt — learned stack memory")
    print(sep)
    for key, value, confidence, source_count, _ in rows:
        print(
            f"  {key:<12} {value:<16} "
            f"confidence: {confidence:.2f}  (seen {source_count}x)"
        )
    print()
    print(f"  Last updated: {_relative_time(last_updated)}")
    print(f"  Total prompts analyzed: {total_prompts}")
    print(sep)
    print("  Tip: more prompts = better optimization context")


# ── preprompt-clip ───────────────────────────────────────────────────────────

def _clipboard_read() -> str:
    """Read clipboard cross-platform."""
    import subprocess
    if sys.platform == "darwin":
        return subprocess.run(["pbpaste"], capture_output=True, text=True).stdout
    elif sys.platform == "win32":
        import tkinter as tk
        root = tk.Tk()
        root.withdraw()
        text = root.clipboard_get()
        root.destroy()
        return text
    else:  # Linux
        try:
            return subprocess.run(
                ["xclip", "-selection", "clipboard", "-o"],
                capture_output=True, text=True,
            ).stdout
        except FileNotFoundError:
            try:
                return subprocess.run(
                    ["xsel", "--clipboard", "--output"],
                    capture_output=True, text=True,
                ).stdout
            except FileNotFoundError:
                print("Install xclip or xsel for clipboard support on Linux")
                return ""


def _clipboard_write(text: str) -> None:
    """Write clipboard cross-platform."""
    import subprocess
    if sys.platform == "darwin":
        subprocess.run(["pbcopy"], input=text, text=True)
    elif sys.platform == "win32":
        import tkinter as tk
        root = tk.Tk()
        root.withdraw()
        root.clipboard_clear()
        root.clipboard_append(text)
        root.update()
        root.destroy()
    else:  # Linux
        try:
            subprocess.run(["xclip", "-selection", "clipboard"], input=text, text=True)
        except FileNotFoundError:
            try:
                subprocess.run(["xsel", "--clipboard", "--input"], input=text, text=True)
            except FileNotFoundError:
                print(f"Optimized prompt:\n{text}")


def clip_cmd() -> None:
    """Read clipboard, optimize, write back. Works on macOS, Windows, Linux."""
    maybe_run_setup()
    prompt = _clipboard_read().strip()

    if not prompt:
        print("Clipboard is empty.")
        return

    _here = Path(__file__).resolve().parent.parent
    if str(_here) not in sys.path:
        sys.path.insert(0, str(_here))

    from mcp_server.classifier import classify_prompt, OPTIMIZATION_THRESHOLD
    from mcp_server.optimizer import optimize
    from dotenv import load_dotenv
    load_dotenv(_here / ".env")

    score = classify_prompt(prompt, [], 1)

    if score < OPTIMIZATION_THRESHOLD:
        print(f"Score {score} — below threshold, prompt is clear enough.")
        return

    print(f"Optimizing… (score {score})")
    opt_result = optimize(prompt, [])
    optimized = opt_result["optimized_prompt"]

    _clipboard_write(optimized)
    print(f"✓ Optimized and copied to clipboard (+{score})")
    if opt_result.get("reason"):
        print(f"  {opt_result['reason']}")


# ── preprompt-optimize ───────────────────────────────────────────────────────

def optimize_cmd() -> None:
    """Optimize a prompt from stdin or --prompt flag and print the result."""
    maybe_run_setup()
    _here = Path(__file__).resolve().parent.parent
    if str(_here) not in sys.path:
        sys.path.insert(0, str(_here))

    parser = argparse.ArgumentParser(
        prog="preprompt-optimize",
        description="Optimize a prompt using Claude Haiku and your stack memory.",
    )
    parser.add_argument("prompt", nargs="?", help="Prompt text (omit to read from stdin)")
    parser.add_argument("--raw", action="store_true", help="Print only the optimized prompt text")
    args = parser.parse_args()

    if args.prompt:
        prompt_text = args.prompt
    elif not sys.stdin.isatty():
        prompt_text = sys.stdin.read().strip()
    else:
        print("Error: provide a prompt as an argument or pipe it via stdin.", file=sys.stderr)
        sys.exit(1)

    if not prompt_text:
        print("Error: empty prompt.", file=sys.stderr)
        sys.exit(1)

    from mcp_server.classifier import classify_prompt, OPTIMIZATION_THRESHOLD
    from mcp_server.optimizer import optimize

    score = classify_prompt(prompt_text, history=[], turn=1)
    if not args.raw:
        print(f"Classifier score: {score} (threshold: {OPTIMIZATION_THRESHOLD})")

    if score < OPTIMIZATION_THRESHOLD:
        if not args.raw:
            print("Prompt is already clear — no optimization needed.")
            print()
            print(prompt_text)
        else:
            print(prompt_text)
        return

    if not args.raw:
        print("Optimizing…")
        print()

    try:
        result = optimize(prompt_text, history=[])
    except Exception as e:
        print(f"Optimization failed: {e}", file=sys.stderr)
        sys.exit(1)

    optimized = result.get("optimized_prompt") or prompt_text
    if args.raw:
        print(optimized)
    else:
        sep = "─" * 60
        print(sep)
        print(optimized)
        print(sep)


# ── preprompt-feedback ───────────────────────────────────────────────────────

def feedback_cmd() -> None:
    """Rate recent intercepted prompts to build accept/reject stats."""
    maybe_run_setup()
    from storage.db import get_all_history, record_user_feedback, flush_pending_hook_events
    flush_pending_hook_events()

    events = get_all_history(limit=10, intercepted_only=True)
    if not events:
        print("No intercepted prompts yet.")
        return

    unrated = [e for e in events if e.get("user_kept") is None]
    if not unrated:
        print("All recent prompts have feedback. Check preprompt-stats for results.")
        return

    print()
    print("  PrePrompt — prompt feedback")
    print("  Rate recent optimizations (y=kept as-is, n=edited/ignored, s=skip)")
    print()

    for event in unrated[:5]:
        original  = event["original_prompt"][:70]
        optimized = event["optimized_prompt"][:70]
        score     = event["classifier_score"]

        print(f"  ┌─ score: {score} ─────────────────────────────────────────")
        print(f"  │  ORIGINAL   {original}")
        print(f"  │  OPTIMIZED  {optimized}...")
        print(f"  └─────────────────────────────────────────────────────────")
        print()

        while True:
            ans = input("  Did you use the optimized version? (y/n/s): ").strip().lower()
            if ans in ("y", "n", "s"):
                break
            print("  Please enter y, n, or s")

        if ans == "y":
            record_user_feedback(event["id"], kept=True)
            print("  ✓ Recorded — thanks!")
        elif ans == "n":
            record_user_feedback(event["id"], kept=False)
            print("  ✓ Recorded — helps us improve!")
        else:
            print("  Skipped.")
        print()

    from storage.db import get_feedback_stats
    stats = get_feedback_stats()
    if stats["accept_rate"] is not None:
        print(f"  Accept rate: {stats['accept_rate']}% "
              f"({stats['kept']} kept / {stats['rejected']} rejected)")
        print()


# ── preprompt-install ─────────────────────────────────────────────────────────

def install_cmd() -> None:
    """One-command setup: configure API key, register hooks, done."""
    import subprocess
    import os

    print()
    print("  ⚡ PrePrompt — setup")
    print()

    # Step 1: Check for API key
    api_key  = os.environ.get("ANTHROPIC_API_KEY", "")
    env_file = Path.home() / ".preprompt" / ".env"
    local_env = Path(__file__).resolve().parent.parent / ".env"

    if not api_key and local_env.exists():
        from dotenv import load_dotenv
        load_dotenv(local_env)
        api_key = os.environ.get("ANTHROPIC_API_KEY", "")

    if not api_key:
        print("  Step 1/3 — Anthropic API key")
        print("  Get your key at: https://console.anthropic.com/api-keys")
        print("  New accounts get $5 free (no card required)")
        print()
        api_key = input("  Paste your API key: ").strip()
        if not api_key:
            print("  Skipped — you can add it later to ~/.preprompt/.env")
        else:
            env_file.parent.mkdir(parents=True, exist_ok=True)
            env_file.write_text(f"ANTHROPIC_API_KEY={api_key}\n")
            if not local_env.exists():
                local_env.write_text(f"ANTHROPIC_API_KEY={api_key}\n")
            print("  ✓ API key saved")
    else:
        print("  Step 1/3 — API key already configured ✓")

    print()

    # Load API key into current process env before registration
    if api_key:
        os.environ["ANTHROPIC_API_KEY"] = api_key

    # Step 2: Register Claude Code global hook
    print("  Step 2/3 — Registering Claude Code hook...")
    try:
        from cli._register import register_hooks
        register_hooks(api_key)
        print("  ✓ Claude Code hook registered")
    except Exception as e:
        print(f"  ⚠ Hook registration failed: {e}")

    print()

    # Step 3: Register Cursor if installed
    print("  Step 3/3 — Checking for Cursor...")
    cursor_config = Path.home() / ".cursor"
    if cursor_config.exists():
        cursor_script = Path(__file__).resolve().parent.parent / "scripts" / "install_cursor.py"
        if cursor_script.exists():
            result = subprocess.run(
                [sys.executable, str(cursor_script)],
                capture_output=True, text=True,
            )
            if result.returncode == 0:
                print("  ✓ Cursor MCP registered")
            else:
                print(f"  ⚠ Cursor registration failed")
        else:
            # pip-installed: run the Cursor registration inline
            try:
                from scripts.install_cursor import main as _cursor_main
                _cursor_main()
                print("  ✓ Cursor MCP registered")
            except Exception:
                print("  ⚠ Run manually: python scripts/install_cursor.py")
    else:
        print("  Cursor not found — skipping")

    print()
    print("  ✓ PrePrompt is ready")
    print()
    print("  Restart Claude Code and Cursor to activate.")
    print()
    print("  Test it:   preprompt-test-classifier")
    print("  Watch live: preprompt-watch")
    print()


# ── preprompt-update ─────────────────────────────────────────────────────────

def update_cmd() -> None:
    """Upgrade PrePrompt to latest version and re-register hooks."""
    maybe_run_setup()
    import subprocess
    from importlib.metadata import version as pkg_version

    current = pkg_version("preprompt")
    print(f"  Current version: {current}")
    print(f"  Checking PyPI...")

    try:
        import urllib.request, json
        req = urllib.request.Request(
            "https://pypi.org/pypi/preprompt/json",
            headers={"User-Agent": "preprompt-cli"},
        )
        with urllib.request.urlopen(req, timeout=5) as r:
            latest = json.loads(r.read())["info"]["version"]
    except Exception as e:
        print(f"  Could not reach PyPI: {e}")
        return

    if latest == current:
        print(f"  Already on latest ({current})")
        return

    print(f"  Upgrading {current} → {latest}...")
    result = subprocess.run(
        [sys.executable, "-m", "pip", "install", "--upgrade", "preprompt"],
        capture_output=True, text=True,
    )
    if result.returncode != 0:
        print(f"  Upgrade failed:\n{result.stderr}")
        return

    print(f"  ✓ Upgraded to {latest}")
    print()
    print(f"  Re-registering hooks...")

    try:
        from cli._register import register_hooks
        register_hooks()
        print(f"  Hooks re-registered")
    except Exception as e:
        print(f"  ⚠ Hook re-registration failed: {e}")
    print()
    print(f"  Restart Claude Code and Cursor to activate {latest}")


# ── preprompt-update-context ─────────────────────────────────────────────────

def update_context_cmd() -> None:
    """Regenerate CONTEXT.md with current phase, test count, and file map."""
    import subprocess
    import datetime
    import re

    # Run pytest to get current test count
    result = subprocess.run(
        ["python", "-m", "pytest", "--tb=no", "-q"],
        capture_output=True, text=True,
        cwd=str(Path(__file__).parent.parent),
    )
    match = re.search(r"(\d+) passed", result.stdout + result.stderr)
    test_count = match.group(1) if match else "unknown"

    # Read current CONTEXT.md, update the test count line
    context_path = Path(__file__).parent.parent / "CONTEXT.md"
    content = context_path.read_text()
    content = re.sub(
        r"\d+/\d+ tests passing",
        f"{test_count}/{test_count} tests passing",
        content,
    )

    # Add / refresh last-updated timestamp at the top
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
    content = re.sub(r"^<!-- Last updated: .* -->\n", "", content)
    if content.startswith("# PrePrompt"):
        content = f"<!-- Last updated: {timestamp} -->\n" + content

    context_path.write_text(content)
    print(f"✓ CONTEXT.md updated — {test_count} tests passing")
    print(f"  Last updated: {timestamp}")
