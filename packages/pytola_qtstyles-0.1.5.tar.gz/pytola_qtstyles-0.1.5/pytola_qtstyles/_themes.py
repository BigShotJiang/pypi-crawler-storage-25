"""基于预构建 QSS 样式表的简化主题系统.

该模块提供一个简单的主题配置系统，用于加载已存在的 QSS 样式表文件.
"""

from __future__ import annotations

import threading
from pathlib import Path
from typing import ClassVar, Dict, Optional

from PySide2.QtWidgets import QWidget
from pytola_core.logger import logger

__all__ = ["apply_theme", "get_theme_count", "get_theme_files", "has_theme"]


_STYLESHEETS_DIR = Path(__file__).parent / "stylesheets"


class ThemeManager:
    """简单的主题管理器，使用预构建的 QSS 样式表.

    功能：
    - 加载已存在的 QSS 样式表文件
    - 将主题应用到 Qt 控件
    - 列出可用主题
    - 预览主题信息

    Examples
    --------
        apply_theme(widget, "dark")

    Note
    ----
    本类是线程安全的，但 Qt 控件操作必须在主线程中执行.
    """

    _instance: ClassVar[Optional[ThemeManager]] = None
    _lock: ClassVar[threading.Lock] = threading.Lock()

    def __init__(self) -> None:
        """初始化主题管理器."""
        self._theme_files: Dict[str, Path] = {}
        self._load_available_themes()

        # 存储为单例
        if ThemeManager._instance is None:
            ThemeManager._instance = self

    @classmethod
    def get_instance(cls) -> ThemeManager:
        """获取单例实例（线程安全）.

        Returns
        -------
            主题管理器实例
        """
        # 双重检查锁定模式
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = cls()
        return cls._instance

    def _load_available_themes(self) -> None:
        """从样式表目录加载可用的主题文件（线程安全）."""
        try:
            if not _STYLESHEETS_DIR.exists():
                logger.warning(f"未找到样式表目录：{_STYLESHEETS_DIR}")
                return

            themes = {}
            for qss_file in _STYLESHEETS_DIR.glob("*.qss"):
                theme_name = qss_file.stem
                themes[theme_name] = qss_file

            # 使用锁保护字典更新
            with self._lock:
                self._theme_files = themes

            logger.info(f"已加载 {len(self._theme_files)} 个主题样式表")

        except OSError as e:
            logger.error(f"加载主题样式表失败：{e}")
            raise

    def _generate_qss(self, theme_name: str) -> str:
        """从文件加载 QSS 样式表（线程安全）.

        Args:
            theme_name: 主题名称

        Returns
        -------
            完整的 QSS 样式表字符串
        """
        # 使用锁保护字典读取
        with self._lock:
            if theme_name not in self._theme_files:
                logger.warning(f"未找到主题 '{theme_name}'")
                return ""

            theme_file = self._theme_files[theme_name]

        try:
            with theme_file.open("r", encoding="utf-8") as f:
                return f.read()
        except (OSError, UnicodeDecodeError) as e:
            logger.error(f"加载主题 '{theme_name}' 失败：{e}")
            return ""

    def apply_theme(self, widget: QWidget, theme_name: str) -> bool:
        """将主题应用到控件（线程安全）.

        Args:
            widget: 要样式化的 Qt 控件（必须在主线程中）
            theme_name: 要应用的主题名称

        Returns
        -------
            如果成功则为 True

        Note
        ----
        Qt 控件操作必须在主线程中执行. 如果在子线程中调用，
        方法会尝试使用 Qt 的信号槽机制切换到主线程.
        """
        # 验证参数
        if widget is None:
            logger.error("控件不能为 None")
            return False

        if not theme_name:
            logger.error("主题名称不能为空")
            return False

        # 检查是否在主线程（Qt 要求 GUI 操作必须在主线程）
        main_thread = threading.main_thread()
        if threading.current_thread() != main_thread:
            logger.error(f"检测到子线程调用！Qt 控件操作必须在主线程中执行. 主题 '{theme_name}' 应用失败. ")
            return False

        # 在主线程中直接应用
        return self._apply_theme_internal(widget, theme_name)

    def _apply_theme_internal(self, widget: QWidget, theme_name: str) -> bool:
        """内部方法：实际应用主题到控件.

        Args:
            widget: Qt 控件
            theme_name: 主题名称

        Returns
        -------
            如果成功则为 True
        """
        # 加载 QSS 内容
        qss = self._generate_qss(theme_name)
        if not qss:
            logger.warning(f"主题 '{theme_name}' 未找到或内容为空")
            return False

        # 应用样式表
        try:
            widget.setStyleSheet(qss)
        except (OSError, UnicodeDecodeError) as e:
            logger.error(f"应用主题 '{theme_name}' 失败：{e}")
            return False
        else:
            logger.info(f"已应用主题 '{theme_name}' 到控件")
            return True

    def list_themes(self) -> list[str]:
        """列出可用主题（线程安全）.

        Returns
        -------
            可用主题名称列表，按字母顺序排序
        """
        with self._lock:
            return sorted(self._theme_files.keys())

    def get_theme_files(self) -> dict[str, Path]:
        """获取主题文件字典（线程安全）.

        Returns
        -------
            主题名称及其对应文件路径的字典（只读副本）
        """
        with self._lock:
            return dict(self._theme_files)

    def has_theme(self, theme_name: str) -> bool:
        """检查主题是否存在（线程安全）.

        Args:
            theme_name: 主题名称

        Returns
        -------
            如果主题存在则为 True
        """
        with self._lock:
            return theme_name in self._theme_files

    def get_theme_count(self) -> int:
        """获取可用主题数量（线程安全）.

        Returns
        -------
            主题数量
        """
        with self._lock:
            return len(self._theme_files)


_theme_manager = ThemeManager()
apply_theme = _theme_manager.apply_theme
get_theme_files = _theme_manager.get_theme_files
has_theme = _theme_manager.has_theme
get_theme_count = _theme_manager.get_theme_count
