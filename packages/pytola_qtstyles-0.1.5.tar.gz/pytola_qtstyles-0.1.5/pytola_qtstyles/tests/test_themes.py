"""Tests for the simplified QSS theme system."""

import threading
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

# Import using absolute path
from pytola_qtstyles._themes import ThemeManager


@pytest.fixture
def themes_dir():
    """Get themes directory."""
    return Path(__file__).parent.parent / "stylesheets"


class TestSimpleThemeManager:
    """Test cases for SimpleThemeManager."""

    @pytest.fixture
    def manager(self):
        """Create a theme manager instance."""
        return ThemeManager()

    def test_singleton_instance(self):
        """Test that get_instance returns singleton."""
        mgr1 = ThemeManager.get_instance()
        mgr2 = ThemeManager.get_instance()
        assert mgr1 is mgr2

    def test_get_instance_thread_safe(self):
        """Test that get_instance is thread-safe."""
        instances = []

        def get_instance():
            instances.append(ThemeManager.get_instance())

        # Create multiple threads to get instance simultaneously
        threads = [threading.Thread(target=get_instance) for _ in range(5)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        # All should be the same instance
        assert len({id(inst) for inst in instances}) == 1

    def test_list_themes(self, manager):
        """Test listing available themes."""
        themes = manager.list_themes()
        # Should have at least some themes from stylesheets directory
        assert isinstance(themes, list)
        assert len(themes) > 0
        # Check some common theme names exist
        assert "aqua" in themes or len(themes) > 0  # At least one theme should exist

    def test_apply_theme_invalid(self, manager):
        """Test applying invalid theme."""
        mock_widget = MagicMock()

        success = manager.apply_theme(mock_widget, "nonexistent_theme")

        # Should fail gracefully
        assert success is False

    def test_apply_theme_none_widget(self, manager):
        """Test applying theme with None widget."""
        success = manager.apply_theme(None, "aqua")
        assert success is False

    def test_apply_theme_empty_name(self, manager):
        """Test applying theme with empty name."""
        mock_widget = MagicMock()
        success = manager.apply_theme(mock_widget, "")
        assert success is False

    def test_apply_theme_valid(self, manager, themes_dir):
        """Test applying valid theme."""
        mock_widget = MagicMock()
        success = manager.apply_theme(mock_widget, "aqua")

        # Should succeed
        assert success is True
        mock_widget.setStyleSheet.assert_called_once()

    def test_apply_theme_from_subthread(self, manager):
        """Test applying theme from subthread (should fail)."""
        mock_widget = MagicMock()
        result = {"success": None}

        def apply_in_thread():
            result["success"] = manager.apply_theme(mock_widget, "aqua")

        thread = threading.Thread(target=apply_in_thread)
        thread.start()
        thread.join()

        # Should fail because Qt operations must be in main thread
        assert result["success"] is False

    def test_list_themes_returns_sorted_list(self, manager):
        """Test that list_themes returns a sorted list."""
        themes = manager.list_themes()
        assert themes == sorted(themes)

    def test_multiple_instances_share_state(self):
        """Test that multiple get_instance calls return same instance."""
        mgr1 = ThemeManager.get_instance()
        mgr2 = ThemeManager.get_instance()

        # get_instance should return same instance
        assert mgr1 is mgr2

    def test_has_theme_existing(self, manager, themes_dir):
        """Test has_theme with existing theme."""
        assert manager.has_theme("aqua") is True

    def test_has_theme_nonexisting(self, manager):
        """Test has_theme with non-existing theme."""
        assert manager.has_theme("nonexistent_theme_xyz") is False

    def test_get_theme_count(self, manager, themes_dir):
        """Test get_theme_count returns correct count."""
        qss_files = list(themes_dir.glob("*.qss"))
        count = manager.get_theme_count()
        assert count == len(qss_files)

    def test_get_theme_files_returns_copy(self, manager):
        """Test that get_theme_files returns a copy."""
        files1 = manager.get_theme_files()
        files2 = manager.get_theme_files()

        # Should be different objects
        assert files1 is not files2
        # But contain same data
        assert files1 == files2

    def test_generate_qss_valid_theme(self, manager, themes_dir):
        """Test _generate_qss with valid theme."""
        qss = manager._generate_qss("aqua")
        assert isinstance(qss, str)
        assert len(qss) > 0
        # Should contain Qt stylesheet syntax
        assert "QWidget" in qss or "QPushButton" in qss or "{" in qss

    def test_generate_qss_invalid_theme(self, manager):
        """Test _generate_qss with invalid theme."""
        qss = manager._generate_qss("nonexistent_theme_xyz")
        assert not qss

    def test_load_available_themes_empty_directory(self):
        """Test _load_available_themes with non-existent directory."""
        # Create a manager without loading themes
        manager = object.__new__(ThemeManager)
        manager._theme_files = {}
        manager._lock = threading.Lock()

        with patch("pytola_qtstyles._themes._STYLESHEETS_DIR") as mock_dir:
            mock_dir.exists.return_value = False
            mock_dir.glob.return_value = []

            # Should not raise, just log warning
            manager._load_available_themes()

            # Should have no themes
            assert manager.get_theme_count() == 0

    def test_thread_safety_list_themes(self, manager):
        """Test that list_themes is thread-safe."""
        results = []

        def list_themes():
            # Reduced iterations
            results.extend(manager.list_themes() for _ in range(5))

        threads = [threading.Thread(target=list_themes) for _ in range(2)]  # Reduced threads
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        # All results should be lists
        assert all(isinstance(r, list) for r in results)

    def test_thread_safety_has_theme(self, manager):
        """Test that has_theme is thread-safe."""
        results = []

        def check_theme():
            # Reduced iterations
            results.extend(manager.has_theme("aqua") for _ in range(5))

        threads = [threading.Thread(target=check_theme) for _ in range(2)]  # Reduced threads
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        # All results should be booleans
        assert all(isinstance(r, bool) for r in results)

    def test_generate_qss_file_read_error(self, manager, themes_dir, monkeypatch):
        """Test _generate_qss when file reading fails."""
        # Mock the open method to raise an error
        original_open = Path.open

        def mock_open(self, *args, **kwargs):
            if self.name == "aqua.qss":
                msg = "Mocked read error"
                raise OSError(msg)
            return original_open(self, *args, **kwargs)

        monkeypatch.setattr(Path, "open", mock_open)

        qss = manager._generate_qss("aqua")
        assert not qss

    def test_apply_theme_widget_error(self, manager, themes_dir):
        """Test apply_theme when widget.setStyleSheet raises error."""
        mock_widget = MagicMock()
        mock_widget.setStyleSheet.side_effect = OSError("Mocked setStyleSheet error")

        success = manager.apply_theme(mock_widget, "aqua")
        assert success is False

    def test_get_instance_creates_new_when_none(self):
        """Test that get_instance creates new instance when _instance is None."""
        # This tests the double-check locking pattern
        original_instance = ThemeManager._instance
        try:
            ThemeManager._instance = None

            # Mock the _load_available_themes to avoid file system access during testing
            with patch.object(ThemeManager, "_load_available_themes", return_value=None):
                mgr = ThemeManager.get_instance()
                assert mgr is not None
                assert isinstance(mgr, ThemeManager)

                # Second call should return same instance (singleton behavior)
                mgr2 = ThemeManager.get_instance()
                assert mgr is mgr2
        finally:
            # Reset for other tests - restore original instance
            ThemeManager._instance = original_instance


class TestThemeConfiguration:
    """Test theme configuration files."""

    def test_stylesheets_directory_exists(self, themes_dir):
        """Test that stylesheets directory exists."""
        assert themes_dir.exists()
        assert themes_dir.is_dir()

    def test_qss_files_exist(self, themes_dir):
        """Test that at least some QSS files exist."""
        qss_files = list(themes_dir.glob("*.qss"))
        assert len(qss_files) > 0, "No QSS files found in stylesheets directory"

    def test_aqua_qss_exists(self, themes_dir):
        """Test that aqua.qss exists."""
        assert (themes_dir / "aqua.qss").exists()

    def test_dracula_qss_exists(self, themes_dir):
        """Test that dracula.qss exists."""
        assert (themes_dir / "dracula.qss").exists()

    def test_gruvbox_qss_exists(self, themes_dir):
        """Test that gruvbox.qss exists."""
        assert (themes_dir / "gruvbox.qss").exists()

    def test_monokai_qss_exists(self, themes_dir):
        """Test that monokai.qss exists."""
        assert (themes_dir / "monokai.qss").exists()

    def test_nord_qss_exists(self, themes_dir):
        """Test that nord.qss exists."""
        assert (themes_dir / "nord.qss").exists()

    def test_onedark_qss_exists(self, themes_dir):
        """Test that onedark.qss exists."""
        assert (themes_dir / "onedark.qss").exists()

    def test_tokyo_night_qss_exists(self, themes_dir):
        """Test that tokyo_night.qss exists."""
        assert (themes_dir / "tokyo_night.qss").exists()

    def test_vitesse_qss_exists(self, themes_dir):
        """Test that vitesse.qss exists."""
        assert (themes_dir / "vitesse.qss").exists()

    def test_catppuccin_qss_exists(self, themes_dir):
        """Test that catppuccin.qss exists."""
        assert (themes_dir / "catppuccin.qss").exists()

    def test_material_dark_qss_exists(self, themes_dir):
        """Test that material_dark.qss exists."""
        assert (themes_dir / "material_dark.qss").exists()

    def test_high_contrast_qss_exists(self, themes_dir):
        """Test that high_contrast.qss exists."""
        assert (themes_dir / "high_contrast.qss").exists()

    def test_macos_qss_exists(self, themes_dir):
        """Test that macos.qss exists."""
        assert (themes_dir / "macos.qss").exists()

    def test_ubuntu_qss_exists(self, themes_dir):
        """Test that ubuntu.qss exists."""
        assert (themes_dir / "ubuntu.qss").exists()

    def test_qss_file_valid(self, themes_dir):
        """Test that a QSS file is valid and readable."""
        qss_file = themes_dir / "aqua.qss"

        with qss_file.open("r", encoding="utf-8") as f:
            content = f.read()

        # Should have some content
        assert len(content) > 0
        # Should contain Qt stylesheet syntax
        assert "QWidget" in content or "QPushButton" in content or "{" in content

    def test_qss_file_size_reasonable(self, themes_dir):
        """Test that QSS files have reasonable size."""
        qss_files = list(themes_dir.glob("*.qss"))

        for qss_file in qss_files:
            size_kb = qss_file.stat().st_size / 1024
            # Each QSS file should be at least 1KB
            assert size_kb >= 1.0, f"{qss_file.name} is too small ({size_kb:.1f}KB)"
            # And not excessively large (less than 1MB)
            assert size_kb < 1024.0, f"{qss_file.name} is too large ({size_kb:.1f}KB)"

    def test_all_qss_files_readable(self, themes_dir):
        """Test that all QSS files are readable."""
        qss_files = list(themes_dir.glob("*.qss"))

        for qss_file in qss_files:
            with qss_file.open("r", encoding="utf-8") as f:
                content = f.read()
            assert len(content) > 0, f"{qss_file.name} is empty"

    def test_no_duplicate_theme_names(self, themes_dir):
        """Test that there are no duplicate theme names."""
        qss_files = list(themes_dir.glob("*.qss"))
        theme_names = [f.stem for f in qss_files]

        # Check for duplicates
        assert len(theme_names) == len(set(theme_names)), "Duplicate theme names found"

    def test_theme_manager_loads_all_themes(self, themes_dir):
        """Test that theme manager loads all available themes."""
        # Create a new manager instance to test loading
        fresh_manager = ThemeManager()
        qss_files = list(themes_dir.glob("*.qss"))
        expected_themes = {f.stem for f in qss_files}
        loaded_themes = set(fresh_manager.list_themes())

        assert expected_themes == loaded_themes

    def test_load_available_themes_oserror(self, monkeypatch):
        """Test _load_available_themes when OSError occurs."""
        import pathlib

        # Create a manager without loading themes
        manager = object.__new__(ThemeManager)
        manager._theme_files = {}
        manager._lock = threading.Lock()

        # Mock pathlib.Path.glob to raise OSError
        original_glob = pathlib.Path.glob

        def mock_glob(self, pattern):
            if "stylesheets" in str(self):
                msg = "Mocked directory access error"
                raise OSError(msg)
            return original_glob(self, pattern)

        monkeypatch.setattr(pathlib.Path, "glob", mock_glob)

        # Should raise OSError and log error
        with pytest.raises(OSError, match="Mocked directory access error"):
            manager._load_available_themes()
