"""Tests for PySide2 environment setup module."""

import os
from unittest.mock import MagicMock, patch

import pytola_qtstyles._env as env_module


class TestPySide2EnvClass:
    """Test _PySide2Env class."""

    def test_class_attributes_exist(self):
        """Test that class attributes exist."""
        assert hasattr(env_module._PySide2Env, "_initialized")
        assert hasattr(env_module._PySide2Env, "_chinese_fonts")
        assert isinstance(env_module._PySide2Env._chinese_fonts, list)
        assert len(env_module._PySide2Env._chinese_fonts) > 0

    def test_setup_env_method_exists(self):
        """Test that setup_env method exists."""
        assert hasattr(env_module._PySide2Env, "setup_env")
        assert callable(env_module._PySide2Env.setup_env)


class TestSetupPySide2Env:
    """Test setup_pyside2_env function (aliased from _PySide2Env.setup_env)."""

    def test_setup_pyside2_env_is_callable(self):
        """Test that setup_pyside2_env is callable."""
        assert callable(env_module.setup_pyside2_env)

    def test_setup_pyside2_env_without_pyside2(self):
        """Test setup when PySide2 is not installed."""
        with patch.dict("sys.modules", {"PySide2": None}), patch(
            "builtins.__import__", side_effect=ImportError("No module named 'PySide2'")
        ):
            # Should not raise an exception
            env_module.setup_pyside2_env()

    def test_setup_pyside2_env_with_pyside2(self, monkeypatch, tmp_path):
        """Test setup when PySide2 is installed."""
        # Create a fake PySide2 directory structure
        fake_pyside2_dir = tmp_path / "PySide2"
        fake_pyside2_dir.mkdir()
        fake_plugins_dir = fake_pyside2_dir / "plugins"
        fake_plugins_dir.mkdir()

        # Mock PySide2 module
        mock_pyside2 = MagicMock()
        mock_pyside2.__file__ = str(fake_pyside2_dir / "__init__.py")

        # Reset initialization state
        original_state = env_module._PySide2Env._initialized
        env_module._PySide2Env._initialized = False

        try:
            with patch.dict("sys.modules", {"PySide2": mock_pyside2}), patch.dict(os.environ, {}, clear=False):
                env_module.setup_pyside2_env()

                # Check environment variables were set
                assert "QT_QPA_PLATFORM_PLUGIN_PATH" in os.environ
                assert "QT_PLUGIN_PATH" in os.environ
                # Verify the paths point to the plugins directory
                assert "plugins" in os.environ["QT_QPA_PLATFORM_PLUGIN_PATH"]
        finally:
            # Restore original state
            env_module._PySide2Env._initialized = original_state

    def test_setup_pyside2_env_plugins_not_found(self, monkeypatch, tmp_path):
        """Test setup when plugins directory doesn't exist."""
        # Create a fake PySide2 directory without plugins
        fake_pyside2_dir = tmp_path / "PySide2"
        fake_pyside2_dir.mkdir()

        mock_pyside2 = MagicMock()
        mock_pyside2.__file__ = str(fake_pyside2_dir / "__init__.py")

        # Reset initialization state
        original_state = env_module._PySide2Env._initialized
        env_module._PySide2Env._initialized = False

        try:
            with patch.dict("sys.modules", {"PySide2": mock_pyside2}):
                env_module.setup_pyside2_env()
        finally:
            env_module._PySide2Env._initialized = original_state

    def test_setup_pyside2_env_idempotent(self):
        """Test that setup_pyside2_env can be called multiple times safely."""
        # First call - should initialize
        env_module._PySide2Env._initialized = False
        env_module.setup_pyside2_env()
        assert env_module._PySide2Env._initialized is True

        # Second call - should skip initialization
        env_module.setup_pyside2_env()
        # Still initialized
        assert env_module._PySide2Env._initialized is True


class TestChineseFontsConfiguration:
    """Test Chinese fonts configuration."""

    def test_chinese_fonts_list_not_empty(self):
        """Test that Chinese fonts list is not empty."""
        fonts = env_module._PySide2Env._chinese_fonts
        assert len(fonts) > 0

    def test_chinese_fonts_contains_windows_fonts(self):
        """Test that Chinese fonts list contains Windows fonts."""
        fonts = env_module._PySide2Env._chinese_fonts
        assert "Microsoft YaHei" in fonts
        assert "Microsoft YaHei UI" in fonts
        assert "Segoe UI" in fonts

    def test_chinese_fonts_contains_linux_fonts(self):
        """Test that Chinese fonts list contains Linux fonts."""
        fonts = env_module._PySide2Env._chinese_fonts
        assert "WenQuanYi Micro Hei" in fonts or "Noto Sans CJK SC" in fonts

    def test_chinese_fonts_contains_macos_fonts(self):
        """Test that Chinese fonts list contains macOS fonts."""
        fonts = env_module._PySide2Env._chinese_fonts
        assert "PingFang SC" in fonts

    def test_chinese_fonts_order(self):
        """Test that Windows fonts have higher priority."""
        fonts = env_module._PySide2Env._chinese_fonts
        # First font should be Microsoft YaHei (Windows default)
        assert fonts[0] == "Microsoft YaHei"


class TestSetupChineseFonts:
    """Test _setup_chinese_fonts method."""

    def test_setup_chinese_fonts_without_qt(self):
        """Test font setup when Qt is not available."""
        with patch.dict("sys.modules", {"PySide2.QtGui": None, "PySide2.QtWidgets": None}), patch(
            "builtins.__import__", side_effect=ImportError("No module named 'PySide2'")
        ):
            # Should not raise an exception
            env_module._PySide2Env._setup_chinese_fonts()

    def test_setup_chinese_fonts_no_qapplication(self, monkeypatch):
        """Test font setup when QApplication instance doesn't exist."""
        # Mock Qt modules
        mock_qt_gui = MagicMock()
        mock_qt_widgets = MagicMock()
        mock_qt_widgets.QApplication.instance.return_value = None

        monkeypatch.setattr("PySide2.QtGui", mock_qt_gui)
        monkeypatch.setattr("PySide2.QtWidgets", mock_qt_widgets)

        # Reset initialization to allow font setup
        original_state = env_module._PySide2Env._initialized
        env_module._PySide2Env._initialized = False

        try:
            with patch.dict(os.environ, {}, clear=False):
                env_module._PySide2Env._setup_chinese_fonts()

                # Should set environment variable
                assert "QT_DEFAULT_FONT_FAMILY" in os.environ
                assert os.environ["QT_DEFAULT_FONT_FAMILY"] == env_module._PySide2Env._chinese_fonts[0]
        finally:
            env_module._PySide2Env._initialized = original_state

    def test_setup_chinese_fonts_with_qapplication(self):
        """Test font setup when QApplication instance exists."""
        # Mock Qt modules before importing
        mock_qt_gui = MagicMock()
        mock_qfont = MagicMock()
        mock_qt_gui.QFont.return_value = mock_qfont

        mock_qapp_instance = MagicMock()
        mock_qt_widgets = MagicMock()
        mock_qt_widgets.QApplication.instance.return_value = mock_qapp_instance
        mock_qt_widgets.QApplication.font.return_value = mock_qfont

        with patch.dict("sys.modules", {"PySide2.QtGui": mock_qt_gui, "PySide2.QtWidgets": mock_qt_widgets}):
            # Need to reset the initialized flag to allow font setup
            original_initialized = env_module._PySide2Env._initialized
            env_module._PySide2Env._initialized = False

            try:
                env_module._PySide2Env._setup_chinese_fonts()

                # QFont.setFamily should have been called at least once
                assert mock_qfont.setFamily.call_count >= 1
                mock_qt_widgets.QApplication.setFont.assert_called_once()
            finally:
                env_module._PySide2Env._initialized = original_initialized

    def test_setup_chinese_fonts_font_iteration(self):
        """Test that font setup iterates through available fonts."""
        # Mock Qt modules before importing
        mock_qt_gui = MagicMock()
        mock_qfont = MagicMock()
        mock_qt_gui.QFont.return_value = mock_qfont

        mock_qapp_instance = MagicMock()
        mock_qt_widgets = MagicMock()
        mock_qt_widgets.QApplication.instance.return_value = mock_qapp_instance
        mock_qt_widgets.QApplication.font.return_value = mock_qfont

        with patch.dict("sys.modules", {"PySide2.QtGui": mock_qt_gui, "PySide2.QtWidgets": mock_qt_widgets}):
            # Need to reset the initialized flag to allow font setup
            original_initialized = env_module._PySide2Env._initialized
            env_module._PySide2Env._initialized = False

            try:
                env_module._PySide2Env._setup_chinese_fonts()

                # Should try at least the first font
                assert mock_qfont.setFamily.call_count >= 1
                # First call should be with the first font in the list
                mock_qfont.setFamily.assert_any_call(env_module._PySide2Env._chinese_fonts[0])
            finally:
                env_module._PySide2Env._initialized = original_initialized


class TestModuleExports:
    """Test module exports."""

    def test_setup_pyside2_env_exported(self):
        """Test that setup_pyside2_env is exported."""
        assert hasattr(env_module, "setup_pyside2_env")
        # They should be functionally equivalent (both are classmethod references)
        assert callable(env_module.setup_pyside2_env)
        assert callable(env_module._PySide2Env.setup_env)

    def test_setup_pyside2_env_import_error_handling(self, monkeypatch):
        """Test that setup_env handles PySide2 import error gracefully."""
        # Reset initialization state
        original_state = env_module._PySide2Env._initialized
        env_module._PySide2Env._initialized = False

        try:
            # Mock import to raise ImportError
            with patch.dict("sys.modules", {"PySide2": None}), patch(
                "builtins.__import__", side_effect=ImportError("No module named 'PySide2'")
            ):
                # Should not raise an exception
                env_module._PySide2Env.setup_env()

                # Should remain not initialized (because PySide2 import failed)
                assert env_module._PySide2Env._initialized is False
        finally:
            env_module._PySide2Env._initialized = original_state


class TestSetupCodePath:
    """Test _setup_code_path method."""

    def test_setup_code_path_current_frame_none(self, monkeypatch):
        """Test _setup_code_path when inspect.currentframe() returns None."""
        with patch("inspect.currentframe", return_value=None):
            # Should not raise an exception
            env_module._PySide2Env._setup_code_path()

    def test_setup_code_path_no_valid_callers(self, monkeypatch):
        """Test _setup_code_path when no valid callers are found."""
        mock_frame = MagicMock()
        mock_frame_info = MagicMock()
        mock_frame_info.filename = None  # No filename

        with patch("inspect.currentframe", return_value=mock_frame), patch(
            "inspect.getouterframes", return_value=[mock_frame_info]
        ):
            env_module._PySide2Env._setup_code_path()
            # Should not add anything to sys.path

    def test_setup_code_path_all_internal_callers(self, monkeypatch):
        """Test _setup_code_path when all callers are internal."""
        mock_frame = MagicMock()
        mock_frame_info = MagicMock()
        mock_frame_info.filename = "d:\\_dev\\pytola\\pytola-qtstyles\\pytola_qtstyles\\test.py"

        with patch("inspect.currentframe", return_value=mock_frame), patch(
            "inspect.getouterframes", return_value=[mock_frame_info]
        ):
            env_module._PySide2Env._setup_code_path()
            # Should not add internal paths to sys.path

    def test_setup_code_path_adds_caller_directory(self, monkeypatch):
        """Test _setup_code_path adds caller directory to sys.path."""
        import sys

        original_sys_path = list(sys.path)
        try:
            mock_frame = MagicMock()
            mock_frame_info = MagicMock()
            mock_frame_info.filename = "z:\\unique_test_path\\test_script.py"

            with patch("inspect.currentframe", return_value=mock_frame), patch(
                "inspect.getouterframes", return_value=[mock_frame_info]
            ):
                env_module._PySide2Env._setup_code_path()

                # Check if path was added (use 'in' to check membership)
                assert "z:\\unique_test_path" in sys.path
        finally:
            sys.path = original_sys_path

    def test_setup_code_path_exception_handling(self, monkeypatch):
        """Test _setup_code_path handles exceptions gracefully."""
        with patch("inspect.currentframe", side_effect=OSError("Mock error")):
            # Should not raise an exception
            env_module._PySide2Env._setup_code_path()


class TestIsInternalPath:
    """Test _is_internal_path static method."""

    def test_is_internal_pytola_qtstyles(self):
        """Test detection of pytola_qtstyles paths."""
        from pathlib import Path

        path = Path("d:\\_dev\\pytola\\pytola-qtstyles\\pytola_qtstyles\\test.py")
        assert env_module._PySide2Env._is_internal_path(path) is True

    def test_is_internal_venv(self):
        """Test detection of venv paths."""
        from pathlib import Path

        path = Path("d:\\_dev\\pytola\\.venv\\Lib\\site-packages\\test.py")
        assert env_module._PySide2Env._is_internal_path(path) is True

    def test_is_internal_python(self):
        """Test detection of Python installation paths."""
        from pathlib import Path

        path = Path("C:\\Python38\\Lib\\test.py")
        assert env_module._PySide2Env._is_internal_path(path) is True

    def test_is_internal_conda(self):
        """Test detection of conda paths."""
        from pathlib import Path

        path = Path("C:\\Users\\user\\anaconda3\\Lib\\test.py")
        assert env_module._PySide2Env._is_internal_path(path) is True

    def test_is_internal_frozen(self):
        """Test detection of frozen paths."""
        from pathlib import Path

        path = Path("<frozen importlib._bootstrap>")
        assert env_module._PySide2Env._is_internal_path(path) is True

    def test_is_not_internal_external(self):
        """Test detection of external paths."""
        from pathlib import Path

        path = Path("d:\\my_project\\my_script.py")
        assert env_module._PySide2Env._is_internal_path(path) is False
