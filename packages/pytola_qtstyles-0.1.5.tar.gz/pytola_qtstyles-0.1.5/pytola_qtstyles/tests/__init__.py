"""Test module for pytola_qtstyles package."""
