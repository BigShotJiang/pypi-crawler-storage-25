"""Tests for high DPI support module."""

from unittest.mock import MagicMock, patch

import pytest

from pytola_qtstyles._highdpi import (
    HIGH_DPI_THRESHOLD,
    STANDARD_DPI,
    _HighDPIManager,
    get_scaled_font,
    get_scaling_factors,
    scale_value,
)


class TestConstants:
    """Test module constants."""

    def test_standard_dpi(self):
        """Test STANDARD_DPI constant."""
        assert pytest.approx(96.0) == STANDARD_DPI

    def test_high_dpi_threshold(self):
        """Test HIGH_DPI_THRESHOLD constant."""
        assert pytest.approx(1.25) == HIGH_DPI_THRESHOLD


class TestHighDPIManager:
    """Test _HighDPIManager class."""

    def test_manager_initialization(self):
        """Test manager class attributes initialization."""
        # Reset the singleton for testing
        _HighDPIManager._initialized = False

        assert _HighDPIManager._initialized is False
        assert pytest.approx(1.0) == _HighDPIManager._scale_factor
        assert _HighDPIManager._is_high_dpi is False

    def test_setup_highdpi_already_initialized(self):
        """Test that setup_highdpi skips if already initialized."""
        # Set as already initialized
        _HighDPIManager._initialized = True

        # Should return immediately without doing anything
        _HighDPIManager.setup_highdpi()
        assert _HighDPIManager._initialized is True

    def test_get_scale_factor_auto_initializes(self):
        """Test that get_scale_factor auto-initializes."""
        # Reset initialization
        _HighDPIManager._initialized = False

        factor = _HighDPIManager.get_scale_factor()
        assert isinstance(factor, float)
        assert factor >= 1.0
        assert _HighDPIManager._initialized is True

    def test_is_high_dpi_auto_initializes(self):
        """Test that is_high_dpi auto-initializes."""
        # Reset initialization
        _HighDPIManager._initialized = False

        result = _HighDPIManager.is_high_dpi()
        assert isinstance(result, bool)
        assert _HighDPIManager._initialized is True


class TestModuleFunctions:
    """Test module-level convenience functions."""

    def test_get_scaling_factors(self):
        """Test get_scaling_factors function."""
        factors = get_scaling_factors()
        assert isinstance(factors, dict)
        assert "scale_factor" in factors
        assert "is_high_dpi" in factors
        assert isinstance(factors["scale_factor"], float)
        assert isinstance(factors["is_high_dpi"], bool)

    def test_scale_value_normal(self):
        """Test normal value scaling."""
        # Set a known scale factor
        _HighDPIManager._scale_factor = 2.0
        _HighDPIManager._initialized = True

        result = scale_value(10.0)
        assert pytest.approx(20.0) == result

    def test_scale_value_with_min(self):
        """Test scaling with minimum value constraint."""
        _HighDPIManager._scale_factor = 0.5  # Small scale factor
        _HighDPIManager._initialized = True

        # Value smaller than min_value should return min_value
        result = scale_value(0.5, min_value=1.0)
        assert result >= 1.0

    def test_scale_value_default_min(self):
        """Test scaling with default minimum value."""
        _HighDPIManager._scale_factor = 0.1  # Very small scale factor
        _HighDPIManager._initialized = True

        # Should use default min_value of 1.0
        result = scale_value(0.5)
        assert result >= 1.0


class TestScalingValues:
    """Test value scaling calculations."""

    def test_scale_value_identity_at_1x(self):
        """Test that values scale correctly at 1.0x factor."""
        _HighDPIManager._scale_factor = 1.0
        _HighDPIManager._initialized = True

        result = scale_value(100.0)
        assert pytest.approx(100.0) == result

    def test_scale_value_at_high_dpi(self):
        """Test scaling at high DPI (above threshold)."""
        _HighDPIManager._scale_factor = 2.0
        _HighDPIManager._is_high_dpi = True
        _HighDPIManager._initialized = True

        result = scale_value(50.0)
        assert pytest.approx(100.0) == result


class TestHighDPIManagerWithQApp:
    """Test _HighDPIManager with QApplication instance."""

    def test_setup_highdpi_with_qapplication_instance(self, monkeypatch):
        """Test setup_highdpi when QApplication instance exists."""
        # Reset initialization
        _HighDPIManager._initialized = False
        _HighDPIManager._scale_factor = 1.0
        _HighDPIManager._is_high_dpi = False

        # Mock the actual PySide2 modules that are already imported
        import PySide2.QtWidgets

        # Create mock screen with high DPI
        mock_screen = MagicMock()
        mock_screen.logicalDotsPerInch.return_value = 144.0  # High DPI

        # Create mock QApplication
        mock_qapp = MagicMock()
        mock_qapp.primaryScreen.return_value = mock_screen

        # Store original method
        original_instance = PySide2.QtWidgets.QApplication.instance

        try:
            # Mock QApplication.instance to return our mock
            PySide2.QtWidgets.QApplication.instance = MagicMock(return_value=mock_qapp)  # type: ignore[assignment]

            # Call setup
            _HighDPIManager.setup_highdpi()

            # Verify it detected high DPI (144/96 = 1.5)
            assert _HighDPIManager._scale_factor > 1.0
            assert _HighDPIManager._initialized is True
        finally:
            # Restore original method
            PySide2.QtWidgets.QApplication.instance = original_instance

    def test_setup_highdpi_screen_none(self, monkeypatch):
        """Test setup_highdpi when screen is None."""
        _HighDPIManager._initialized = False
        _HighDPIManager._scale_factor = 1.0

        import PySide2.QtWidgets

        mock_qapp = MagicMock()
        mock_qapp.primaryScreen.return_value = None

        original_instance = PySide2.QtWidgets.QApplication.instance
        try:
            PySide2.QtWidgets.QApplication.instance = MagicMock(return_value=mock_qapp)  # type: ignore[assignment]
            _HighDPIManager.setup_highdpi()

            # Should use default values
            assert _HighDPIManager._scale_factor == pytest.approx(1.0)
            assert _HighDPIManager._initialized is True
        finally:
            PySide2.QtWidgets.QApplication.instance = original_instance

    def test_setup_highdpi_no_logical_dpi_method(self, monkeypatch):
        """Test setup_highdpi when screen doesn't have logicalDotsPerInch."""
        _HighDPIManager._initialized = False
        _HighDPIManager._scale_factor = 1.0

        import PySide2.QtWidgets

        mock_screen = MagicMock(spec=[])  # No methods
        mock_qapp = MagicMock()
        mock_qapp.primaryScreen.return_value = mock_screen

        original_instance = PySide2.QtWidgets.QApplication.instance
        try:
            PySide2.QtWidgets.QApplication.instance = MagicMock(return_value=mock_qapp)  # type: ignore[assignment]
            _HighDPIManager.setup_highdpi()

            # Should use default values
            assert _HighDPIManager._scale_factor == pytest.approx(1.0)
            assert _HighDPIManager._initialized is True
        finally:
            PySide2.QtWidgets.QApplication.instance = original_instance

    def test_setup_highdpi_exception_handling(self, monkeypatch):
        """Test setup_highdpi handles exceptions gracefully."""
        _HighDPIManager._initialized = False

        import PySide2.QtWidgets

        original_instance = PySide2.QtWidgets.QApplication.instance
        try:
            PySide2.QtWidgets.QApplication.instance = MagicMock(side_effect=RuntimeError("Mock error"))  # type: ignore[assignment]
            # Should not raise an exception
            _HighDPIManager.setup_highdpi()
            assert _HighDPIManager._initialized is True
        finally:
            PySide2.QtWidgets.QApplication.instance = original_instance


class TestGetScaledFont:
    """Test get_scaled_font function."""

    def test_get_scaled_font_returns_qfont(self):
        """Test that get_scaled_font returns a QFont instance."""
        # Just verify it returns a QFont when Qt is available
        result = get_scaled_font(16)
        from PySide2.QtGui import QFont

        assert isinstance(result, QFont)
        assert result.pixelSize() == 16

    def test_get_scaled_font_default_size(self):
        """Test get_scaled_font with default size."""
        # Set scale factor to 1.0 for predictable default size
        _HighDPIManager._scale_factor = 1.0
        _HighDPIManager._initialized = True

        result = get_scaled_font()
        from PySide2.QtGui import QFont

        assert isinstance(result, QFont)
        # Default size should be around 14 (scaled)
        assert result.pixelSize() >= 14

    def test_get_scaled_font_default_size_uses_scaling(self):
        """Test that default font size uses scaling."""
        # Set a known scale factor
        _HighDPIManager._scale_factor = 2.0
        _HighDPIManager._initialized = True

        # When size is None, it should use scale_value(14, 9)
        # With scale_factor=2.0: max(9, 14*2.0) = 28
        result = get_scaled_font(None)
        from PySide2.QtGui import QFont

        assert isinstance(result, QFont)
        # Default size should be scaled: max(9, 14*2.0) = 28
        assert result.pixelSize() == 28


class TestQtNotAvailable:
    """Test behavior when Qt is not available."""

    def test_qt_import_failure(self, monkeypatch):
        """Test module behavior when PySide2 cannot be imported."""
        # Temporarily modify sys.modules to simulate missing PySide2
        with patch.dict("sys.modules", {"PySide2": None}):
            # The module should handle this gracefully during import
            # We just verify the constants are still accessible
            assert pytest.approx(96.0) == STANDARD_DPI
            assert pytest.approx(1.25) == HIGH_DPI_THRESHOLD
