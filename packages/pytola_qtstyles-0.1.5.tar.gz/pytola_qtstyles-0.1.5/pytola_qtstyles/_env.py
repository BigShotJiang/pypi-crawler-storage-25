"""Env module for pytola_qtstyles."""

from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import ClassVar

from pytola_core.logger import logger


class _PySide2Env:
    """PySide2 环境管理器（单例模式）."""

    _initialized: ClassVar[bool] = False
    _chinese_fonts: ClassVar[list[str]] = [
        # Windows 系统字体
        "Microsoft YaHei",
        "Microsoft YaHei UI",
        "Segoe UI",
        # Linux/WSL 中文字体
        "WenQuanYi Micro Hei",
        "WenQuanYi Zen Hei",
        "Noto Sans CJK SC",
        "Source Han Sans SC",
        "AR PL UMing CN",
        "AR PL UKai CN",
        # macOS 字体
        "PingFang SC",
    ]

    @classmethod
    def setup_env(cls) -> None:
        """初始化 PySide2 环境."""
        if cls._initialized:
            logger.debug("PySide2 环境已初始化，跳过.")
            return

        logger.debug("初始化 PySide2 环境.")

        try:
            import PySide2
        except ImportError:
            logger.error("PySide2 未安装，请安装 PySide2.")
            return

        logger.debug("PySide2 环境初始化完成.")
        pyside2_dir = Path(PySide2.__file__).parent
        plugins_path = pyside2_dir / "plugins"
        if plugins_path.exists():
            qt_plugins_path = str(plugins_path.absolute()).strip()
            os.environ["QT_QPA_PLATFORM_PLUGIN_PATH"] = qt_plugins_path
            os.environ["QT_PLUGIN_PATH"] = qt_plugins_path
        else:
            logger.warning("未找到 PySide2 插件路径")

        cls._setup_code_path()
        cls._setup_chinese_fonts()

        cls._initialized = True
        logger.debug("PySide2 环境初始化完成.")

    @classmethod
    def _setup_code_path(cls) -> None:
        """将调用者所在目录添加到 sys.path."""
        try:
            import inspect

            # 获取调用栈，找到调用 pytola_qtstyles 的模块
            frame = inspect.currentframe()
            if frame is None:
                return

            try:
                # 收集所有调用者文件
                caller_files: list[Path] = []
                for frame_info in inspect.getouterframes(frame, context=0):
                    filename = frame_info.filename
                    if not filename:
                        continue

                    file_path = Path(filename)

                    # 跳过内部调用（pytola_qtstyles、标准库、虚拟环境等）
                    if cls._is_internal_path(file_path):
                        continue

                    caller_files.append(file_path)

                if not caller_files:
                    return

                # 使用最后一个调用者文件所在的目录
                caller_path = caller_files[-1].parent

                # 如果调用者路径不在 sys.path 中，则添加
                if str(caller_path) not in sys.path:
                    sys.path.insert(0, str(caller_path.absolute()))
                    logger.info(f"已添加调用者目录到 sys.path: {caller_path.absolute()}")
            finally:
                # 避免循环引用
                del frame
        except (AttributeError, ImportError, OSError) as e:
            logger.warning(f"无法添加调用者目录到 sys.path: {e}")

    @staticmethod
    def _is_internal_path(file_path: Path) -> bool:
        """判断是否为内部路径（需要跳过的路径）."""
        path_str = str(file_path)

        # pytola_qtstyles 内部
        if "pytola_qtstyles" in file_path.parts:
            return True

        # Python 标准库和虚拟环境
        internal_keywords = [".venv", "python", "anaconda", "<frozen"]
        return any(keyword in path_str.lower() for keyword in internal_keywords)

    @classmethod
    def _setup_chinese_fonts(cls) -> None:
        """设置中文字体."""
        try:
            from PySide2.QtGui import QFont
            from PySide2.QtWidgets import QApplication
        except (ImportError, RuntimeError) as e:
            logger.warning(f"无法设置中文字体：{e}")
            return

        app = QApplication.instance()
        if app is None:
            # 如果 QApplication 还未创建，通过环境变量设置
            # 注意：QT_DEFAULT_FONT_FAMILY 只在某些 Qt 版本中有效
            os.environ["QT_DEFAULT_FONT_FAMILY"] = cls._chinese_fonts[0]
            logger.info(f"通过 QT_DEFAULT_FONT_FAMILY 设置中文字体：`{cls._chinese_fonts[0]}`")
            return

        # 如果 QApplication 已经创建，直接设置字体
        # 注意：QApplication.instance() 返回 QCoreApplication*，需要类型转换
        font: QFont = QApplication.font()
        # 尝试设置第一个可用的中文字体
        for font_name in cls._chinese_fonts:
            font.setFamily(font_name)
            # Qt 会自动回退到最接近的匹配，所以设置第一个即可
            break

        QApplication.setFont(font)
        logger.info(f"已配置中文字体：`{cls._chinese_fonts[0]}`")
        logger.info(f"可用中文字体优先级列表：`{cls._chinese_fonts}`")


setup_pyside2_env = _PySide2Env.setup_env
setup_pyside2_env()
