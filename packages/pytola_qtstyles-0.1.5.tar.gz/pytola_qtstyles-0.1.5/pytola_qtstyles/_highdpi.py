"""为 Pytola 应用程序提供高 DPI 支持.

该模块实现简单自动的高 DPI 缩放功能，在支持 HighDPI 的平台自动初始化，在不支持的平台静默跳过.
"""

from __future__ import annotations

from typing import ClassVar

from pytola_core.logger import logger

# Qt 可用性检查
try:
    from PySide2.QtCore import Qt
    from PySide2.QtGui import QFont
    from PySide2.QtWidgets import QApplication

    QT_AVAILABLE = True
except ImportError:
    QT_AVAILABLE = False
    logger.warning("PySide2 不可用，HighDPI 缩放功能已禁用.")

# 常量
STANDARD_DPI: float = 96.0
HIGH_DPI_THRESHOLD: float = 1.25


class _HighDPIManager:
    """高 DPI 管理器，支持自动初始化."""

    _initialized: ClassVar[bool] = False
    _scale_factor: ClassVar[float] = 1.0
    _is_high_dpi: ClassVar[bool] = False

    @classmethod
    def setup_highdpi(cls) -> None:
        """初始化高 DPI 支持（如果可用）.

        注意：HighDPI 属性应在创建 QApplication 之前设置，这是 Qt 官方推荐做法。
        """
        if cls._initialized or not QT_AVAILABLE:
            return

        try:
            # 在创建 QApplication 之前设置 HighDPI 属性
            # 这些属性需要在 QApplication 实例化前配置
            app = QApplication.instance()

            # 检测屏幕 DPI（如果有 QApplication 实例）
            if app:
                # 为 primaryScreen 添加类型忽略 - 在 PySide2 中可用，但类型提示可能不完整
                screen = app.primaryScreen()  # type: ignore[union-attr]
                if screen and hasattr(screen, "logicalDotsPerInch"):
                    screen_dpi = screen.logicalDotsPerInch()
                    cls._scale_factor = max(1.0, screen_dpi / STANDARD_DPI)
                    cls._is_high_dpi = cls._scale_factor > HIGH_DPI_THRESHOLD

                    if cls._is_high_dpi:
                        logger.info(f"检测到高 DPI：缩放因子 {cls._scale_factor:.2f}")
                    else:
                        logger.info(f"检测到标准 DPI：{screen_dpi:.1f} DPI")
                else:
                    logger.warning("屏幕 logicalDotsPerInch 不可用，使用默认 DPI。")
            else:
                # 无 QApplication 实例时，直接启用 HighDPI 属性
                # 这是 Qt 推荐的做法：在实例化 QApplication 前设置属性
                logger.warning("未找到 Qt 应用程序实例，将在创建 QApplication 时启用 HighDPI。")
                cls._scale_factor = 1.0  # 默认值，实际缩放由 Qt 自动处理
                cls._is_high_dpi = False  # 待 QApplication 创建后检测

            # 无论是否有 QApplication 实例，都设置 HighDPI 属性
            # 这样在后续创建 QApplication 时会自动应用
            QApplication.setAttribute(Qt.AA_EnableHighDpiScaling, True)
            QApplication.setAttribute(Qt.AA_UseHighDpiPixmaps, True)

        except (OSError, RuntimeError) as e:
            logger.warning(f"设置 HighDPI 失败：{e}")

        cls._initialized = True

    @classmethod
    def get_scale_factor(cls) -> float:
        """获取当前缩放因子."""
        if not cls._initialized:
            cls.setup_highdpi()
        return cls._scale_factor

    @classmethod
    def is_high_dpi(cls) -> bool:
        """检查系统是否为高 DPI."""
        if not cls._initialized:
            cls.setup_highdpi()
        return cls._is_high_dpi


def setup_highdpi_scaling() -> None:
    """自动设置高 DPI 缩放."""
    _HighDPIManager.setup_highdpi()


def get_scaling_factors() -> dict[str, float]:
    """获取当前缩放因子.

    Returns
    -------
        包含 'scale_factor' 和 'is_high_dpi' 键的字典。
    """
    return {"scale_factor": _HighDPIManager.get_scale_factor(), "is_high_dpi": _HighDPIManager.is_high_dpi()}


def scale_value(value: float, min_value: float = 1.0) -> float:
    """根据当前 DPI 设置缩放值.

    Args:
        value: 要缩放的值。
        min_value: 最小返回值。

    Returns
    -------
        缩放后的值。
    """
    scale_factor = _HighDPIManager.get_scale_factor()
    return max(min_value, value * scale_factor)


def get_scaled_font(size: int | None = None) -> QFont | None:
    """获取缩放后的 QFont 实例.

    Args:
        size: 字体大小（像素）。如果为 None，则使用默认大小。

    Returns
    -------
        缩放后的 QFont 实例，如果 Qt 不可用则为 None。
    """
    if not QT_AVAILABLE:
        return None

    try:
        font = QFont()
        font_size = size or int(scale_value(14, 9))
        font.setPixelSize(font_size)
    except (TypeError, ValueError) as e:
        logger.warning(f"创建缩放字体失败：{e}")
        return None
    else:
        return font


# 导入时自动初始化
setup_highdpi_scaling()
