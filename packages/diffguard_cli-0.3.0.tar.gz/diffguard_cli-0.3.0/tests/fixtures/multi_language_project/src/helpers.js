// JavaScript helper module
export function add(a, b) {
    return a + b;
}
