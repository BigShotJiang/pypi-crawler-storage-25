import os
import traceback
from collections import OrderedDict

from velocity.db.core.row import Row
from velocity.db.core.table import Table
from velocity.db.core.view import View
from velocity.db.core.result import Result
from velocity.db.core.column import Column
from velocity.db.core.database import Database
from velocity.db.core.sequence import Sequence
from velocity.db.utils import mask_config_for_display
from velocity.misc.db import randomword

debug = False

# Default maximum number of cached query results per transaction.
_DEFAULT_QUERY_CACHE_SIZE = int(os.environ.get("VELOCITY_QUERY_CACHE_SIZE", "100"))


class Transaction:
    """
    Encapsulates a single transaction in the database (connection + commit/rollback).
    """

    def __init__(self, engine, connection=None):
        self.engine = engine
        self.connection = connection
        self.__pg_types = {}
        # Track whether this connection came from the pool and should be returned.
        self.__pooled = connection is None and engine.pool_enabled
        # R5 — Transaction-scoped query cache (opt-in via cache=True on select).
        self.__query_cache: OrderedDict = OrderedDict()
        self.__query_cache_max = _DEFAULT_QUERY_CACHE_SIZE

    def __str__(self):
        config = mask_config_for_display(self.engine.config)

        if isinstance(config, dict):
            server = config.get("host", config.get("server"))
            database = config.get("database", config.get("dbname"))
            return f"{self.engine.sql.server}.transaction({server}:{database})"

        return f"{self.engine.sql.server}.transaction({config})"

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type:
            if debug:
                print("Transaction.__exit__ - an exception occurred.")
                traceback.print_exc()
            self.rollback()
            # After an error + rollback, discard the connection from the pool
            # rather than returning it in a potentially dirty state.
            if self.__pooled and self.connection:
                self.engine.return_pooled_connection(self.connection, discard=True)
                self.connection = None
                self.__pooled = False
        self.close()

    def cursor(self):
        """
        Retrieves a database cursor, opening a connection if necessary.
        """
        # Lazily connect, and also recover if the driver reports a closed connection.
        # (psycopg v3 uses `connection.closed` returning bool; v2 used int != 0.)
        if self.connection is not None:
            try:
                if getattr(self.connection, "closed", 0):
                    self.connection = None
            except Exception:
                # If the driver object is in a bad state, force a reconnect.
                self.connection = None

        if not self.connection:
            self.connection = self.engine.connect()
        if debug:
            print(f"*** {id(self)} --> transaction.cursor()")
        return self.connection.cursor()

    def close(self):
        """
        Commits (if needed) and closes or returns the connection.
        If the connection was obtained from the pool, it is returned to
        the pool instead of being closed.
        """
        if self.connection:
            self.commit()
            if debug:
                print(f"<<< {id(self)} close connection.")
            if self.__pooled and self.engine.return_pooled_connection(self.connection):
                self.connection = None
            else:
                self.connection.close()
                self.connection = None

    def execute(self, sql, parms=None, single=False, cursor=None, prepare=None):
        return self._execute(sql, parms, single, cursor, prepare=prepare)

    def _execute(self, sql, parms=None, single=False, cursor=None, prepare=None):
        if single:
            cursor = None
        if not self.connection:
            self.connection = self.engine.connect()

        if single:
            self.commit()
            self.connection.autocommit = True

        if not cursor:
            cursor = self.cursor()

        # R6 — Resolve effective 'prepare' flag.
        # None → use engine default; True/False → explicit override.
        # pgbouncer transaction-mode doesn't support prepared statements,
        # so the engine can disable them globally.
        if prepare is None:
            prepare = getattr(self.engine, "prepare_enabled", False)

        try:
            if parms:
                cursor.execute(sql, parms, prepare=prepare)
            else:
                cursor.execute(sql, prepare=prepare)
        except TypeError:
            # Driver doesn't support 'prepare' keyword (non-psycopg3).
            try:
                if parms:
                    cursor.execute(sql, parms)
                else:
                    cursor.execute(sql)
            except Exception as e:
                raise self.engine.process_error(e, sql, parms)
        except Exception as e:
            raise self.engine.process_error(e, sql, parms)

        if single:
            self.connection.autocommit = False

        return Result(cursor, self, sql, parms)

    def _execute_values(self, sql, args_list, template=None, page_size=1000):
        """
        Execute a multi-row statement by expanding a VALUES block inline.

        This replaces the former ``psycopg2.extras.execute_values`` helper
        with a driver-agnostic implementation compatible with psycopg v3.

        Args:
            sql: SQL template with a single ``%s`` for the VALUES block.
            args_list: List of tuples, one per row.
            template: Optional per-row template, e.g. ``"(%s, %s, DEFAULT)"``.
            page_size: Rows per batch sent to the server.

        Returns:
            Total number of rows affected.
        """
        if not self.connection:
            self.connection = self.engine.connect()

        if not template:
            ncols = len(args_list[0]) if args_list else 0
            template = "(" + ", ".join(["%s"] * ncols) + ")"

        cursor = self.cursor()
        total = 0
        try:
            for offset in range(0, len(args_list), page_size):
                page = args_list[offset : offset + page_size]
                values_clause = ", ".join([template] * len(page))
                query = sql.replace("%s", values_clause, 1)
                flat_params = []
                for row in page:
                    flat_params.extend(row)
                cursor.execute(query, flat_params)
                total += cursor.rowcount
        except Exception as e:
            raise self.engine.process_error(e, sql, args_list)

        return total

    def server_execute(self, sql, parms=None):
        """
        Executes SQL using an existing cursor, typically for server-side usage.
        """
        return self._execute(sql, parms, cursor=self.cursor())

    def commit(self):
        """
        Commits the current transaction if there's an open connection.
        """
        if self.connection:
            if debug:
                print(f"{id(self)} --- connection commit.")
            self.connection.commit()

    def rollback(self):
        """
        Rolls back the current transaction if there's an open connection.
        """
        if self.connection:
            if debug:
                print(f"{id(self)} --- connection rollback.")
            self.connection.rollback()

    def create_savepoint(self, sp=None, cursor=None):
        """
        Creates a savepoint named `sp`. If none given, uses a random name.
        """
        if not sp:
            sp = randomword()
        sql, vals = self.engine.sql.create_savepoint(sp)
        if sql:
            self._execute(sql, vals, cursor=cursor)
        return sp

    def release_savepoint(self, sp=None, cursor=None):
        """
        Releases the given savepoint.
        """
        sql, vals = self.engine.sql.release_savepoint(sp)
        if sql:
            self._execute(sql, vals, cursor=cursor)

    def rollback_savepoint(self, sp=None, cursor=None):
        """
        Rolls back to the given savepoint.
        """
        sql, vals = self.engine.sql.rollback_savepoint(sp)
        if sql:
            self._execute(sql, vals, cursor=cursor)

    def advisory_lock(self, key):
        """Acquire a transaction-scoped PostgreSQL advisory lock.

        The lock is automatically released when the transaction commits or
        rolls back.  Use this to serialize DDL or other operations across
        concurrent Lambda containers.

        Args:
            key: An integer lock key, or a string that will be hashed to
                 a 64-bit integer.
        """
        if isinstance(key, str):
            import hashlib
            # Use first 8 bytes of SHA-256 as a signed 64-bit int.
            digest = hashlib.sha256(key.encode("utf-8")).digest()
            key = int.from_bytes(digest[:8], byteorder="big", signed=True)
        self._execute("SELECT pg_advisory_xact_lock(%s)", (key,))

    # ------------------------------------------------------------------
    # Query result cache  (R5)
    # ------------------------------------------------------------------

    def _cache_key(self, sql, parms):
        """Build a hashable cache key from a SQL string and its parameters."""
        if parms is None:
            return (sql,)
        if isinstance(parms, dict):
            return (sql, tuple(sorted(parms.items())))
        return (sql, tuple(parms))

    def _cache_get(self, key):
        """Return cached rows for *key*, or ``None`` on a miss.

        Accessing a key promotes it to the most-recently-used position.
        """
        if key in self.__query_cache:
            self.__query_cache.move_to_end(key)
            return self.__query_cache[key]
        return None

    def _cache_put(self, key, rows):
        """Store *rows* in the cache under *key*, evicting LRU if needed."""
        self.__query_cache[key] = rows
        self.__query_cache.move_to_end(key)
        while len(self.__query_cache) > self.__query_cache_max:
            self.__query_cache.popitem(last=False)

    def invalidate_cache(self, table_name=None):
        """Invalidate cached queries.

        Args:
            table_name: When provided, only entries whose SQL mentions
                this table name are evicted.  When ``None``, the entire
                cache is cleared.
        """
        if table_name is None:
            self.__query_cache.clear()
            return
        # Simple substring match on the SQL text (first element of the key).
        tbl_lower = table_name.lower()
        to_remove = [
            k for k in self.__query_cache if tbl_lower in k[0].lower()
        ]
        for k in to_remove:
            del self.__query_cache[k]

    # Alias for readability in user code.
    clear_cache = invalidate_cache

    @property
    def cache_size(self):
        """Number of entries currently held in the query cache."""
        return len(self.__query_cache)

    def database(self, name=None):
        """
        Returns a Database object for the given database name or the current one.
        """
        return Database(self, name)

    def table(self, tablename):
        """
        Returns a Table object for the given table name.
        """
        return Table(self, tablename)

    def view(self, viewname, schema=None):
        """Returns a View helper for the given view name."""
        return View(self, viewname, schema=schema)

    def sequence(self, name):
        """
        Returns a Sequence object for the given sequence name.
        """
        return Sequence(self, name)

    def row(self, tablename, pk, lock=None):
        """
        Returns a Row for the given table & primary key condition.
        """
        return Row(self.table(tablename), pk, lock=lock)

    def get(self, tablename, where, lock=None, use_where=False):
        """Shortcut to table.get() with optional ``use_where`` passthrough."""
        return self.table(tablename).get(where, lock=lock, use_where=use_where)

    def find(
        self,
        tablename,
        where,
        lock=None,
        use_where=False,
        raise_if_missing=False,
    ):
        """Shortcut to table.find() with ``use_where``/``raise_if_missing`` passthrough."""
        return self.table(tablename).find(
            where,
            lock=lock,
            use_where=use_where,
            raise_if_missing=raise_if_missing,
        )

    def column(self, tablename, colname):
        """
        Returns a Column object for (table=tablename, column=colname).
        """
        return Column(self.table(tablename), colname)

    def current_database(self):
        """
        Returns the current database name from the server.
        """
        sql, vals = self.engine.sql.current_database()
        return self.execute(sql, vals).scalar()

    def tables(self):
        """
        Returns a list of tables in the current database as "schema.table" strings.
        """
        sql, vals = self.engine.sql.tables()
        result = self.execute(sql, vals)
        return [f"{x[0]}.{x[1]}" for x in result.as_tuple()]

    @property
    def pg_types(self):
        """
        Cached mapping of OID -> type name for columns.
        """
        if not self.__pg_types:
            sql = "select oid, typname from pg_type"
            vals = ()
            result = self.execute(sql, vals)
            self.__pg_types = dict(result.as_tuple())
        return self.__pg_types

    def switch_to_database(self, name):
        """
        Closes the current connection, changes config, and lazily reconnects for the new DB.
        """
        if self.connection:
            # Switching databases invalidates the connection — discard it.
            if self.__pooled:
                self.engine.return_pooled_connection(self.connection, discard=True)
            else:
                self.connection.close()
            self.connection = None
            self.__pooled = False
        self.engine.switch_to_database(name)
        return self
