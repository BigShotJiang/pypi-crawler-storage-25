# vantage-x

VANTAGE X — Static code analysis pipeline. Runs METEOR → NOVA → ECLIPSE → PULSAR → AURORA and returns an APPROVED/REJECTED verdict with scored breakdown.

## Install

```bash
pip install vantage-x
```

## Requirements

- Python 3.8+
- Node.js with `vantage` binary on PATH (VANTAGE X must be installed separately)

## Usage

### Python API

```python
from vantage import analyze

report = analyze("/path/to/project")
print(report.verdict)    # APPROVED or REJECTED
print(report.score_pct)  # e.g. "87.4%"

for issue in report.aurora.top_issues:
    print(issue.severity, issue.file, issue.description)
```

### CLI

```bash
vantage-py /path/to/project
vantage-py /path/to/project --engine PULSAR
vantage-py /path/to/project --json
```

## Engines

- **METEOR** — File scanner & complexity parser
- **NOVA** — Dependency graph & circular dependency detection
- **ECLIPSE** — Per-file risk scoring (0.0–1.0)
- **PULSAR** — Adversarial stress testing
- **AURORA** — Final verdict + prioritised issue list
