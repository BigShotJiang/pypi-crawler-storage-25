"""
🎭 ComicScript

ComicScript is the ultimate Python library for developers who don't take themselves too seriously. Why settle for boring, cold, and technical error messages when you can get a personalized "roast" from your own console?

ComicScript replaces standard Python Tracebacks with humorous, witty, and sometimes brutal comments about your coding mistakes.

✨ Features

Zero Configuration: Just import it, and it's active. No complex setup required.

Custom Roasts: Specific jokes for the most common errors (NameError, SyntaxError, TypeError, ZeroDivisionError, etc.).

Dynamic Messages: It picks a random joke from its database every time you fail, so you never get bored of debugging.

Safety Fallback: If you manage to create an error so weird that we don't have a joke for it, it will still show you the original Python error so you aren't left in the dark.

🚀 Installation

Since it's part of the Emilve Ecosystem, you can install it via pip:

pip install ComicScript


🛠️ How to Use

Simply import the library at the very top of your main script. That's it!

import ComicScript

# Now, let's make a mistake on purpose...
print(Variable_That_Does_Not_Exist)


Potential Console Output:

🔥 [COMIC-SCRIPT ERROR] 🔥
>>> Whoops! 'Variable_That_Does_Not_Exist'? I haven't heard that name since the Big Bang.

📂 Supported Errors

ComicScript currently "bullies" you for:

NameError: For when you invent names out of thin air.

SyntaxError: For when your cat walks over the keyboard.

ZeroDivisionError: For when you try to destroy the fabric of mathematics (don't create a black hole!).

IndexError: For when you reach for things that aren't there.

AttributeError: For when you ask a fish to fly a plane.

And many more! (TypeError, KeyError, ModuleNotFoundError...)

👨‍💻 Author

Developed with humor by Emiliano (emicics).
"Because if the code is going to break, we might as well have a laugh."
"""

from .core import setup_comic_errors

# Al importar la librería, se activan los errores automáticamente
setup_comic_errors()

__version__ = "1.0.0"
__author__ = "Emiliano"