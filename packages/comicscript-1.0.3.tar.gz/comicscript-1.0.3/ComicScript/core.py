﻿import sys
import random
import linecache
import traceback
from rich.console import Console
from rich.panel import Panel
from rich.text import Text

console = Console()

def setup_comic_errors():
    def custom_excepthook(type, value, tb):
        traceback_details = traceback.extract_tb(tb)[-1]
        archivo_completo = traceback_details.filename
        nombre_archivo = archivo_completo.split('\\')[-1]
        num_linea = traceback_details.lineno
        contenido_linea = linecache.getline(archivo_completo, num_linea).strip()

        roasts = {
            'NameError': [
                "Whoops! '{0}'? I haven't heard that name since the Big Bang.",
                "Are you inventing a new language? Because '{0}' is definitely not in Python.",
                "Variable '{0}' not found. Maybe it's hiding in a different dimension?"
            ],
            'SyntaxError': [
                "Syntax Error at '{0}'? My keyboard codes cleaner than this.",
                "You call '{0}' code? It looks like a cat walked over the keyboard.",
                "Check '{0}' again. Even a compiler has feelings, you know?"
            ],
            'TypeError': [
                "'{0}'? You're trying to mix things that don't belong together.",
                "Invalid type '{0}'! Even an AI has higher standards than this.",
                "TypeError '{0}': Your code is trying to be something it's not. Just be yourself."
            ],
            'IndexError': [
                "Index '{0}' is out of bounds! You're reaching for things that don't exist.",
                "Index '{0}' out of range. You've gone too far, come back to reality!",
                "Error at index '{0}': Try staying inside the lines for once."
            ],
            'ZeroDivisionError': [
                "Dividing '{0}'? Do you want to create a black hole in the server room?",
                "Math '{0}' is hard, I know. But that's literally impossible.",
                "Zero division '{0}' detected. Somewhere, a math teacher is crying."
            ],
            'AttributeError': [
                "'{0}'? Asking for that is like asking a fish to fly a plane.",
                "Attribute Error: Stop trying to make '{0}' happen. It's not going to happen."
            ],
            'ModuleNotFoundError': [
                "Module '{0}' missing! Did you forget to install your dependencies?",
                "I can't find '{0}'. It's probably lost in the cloud somewhere."
            ],
            'KeyError': [
                "Key '{0}' isn't in the dictionary. It's like looking for keys already in your hand.",
                "KeyError '{0}': Access denied. The dictionary says NO."
            ],
            'RuntimeError': [
                "RuntimeError: Your code is alive, but it has a death wish.",
                "The system said 'NO'. '{0}' is basically Windows laughing at you.",
                "Something went wrong while running. It's not syntax, it's just... you."
            ],
            'OSError': [
                "OS Error: '{0}'. Even the Operating System is tired of your scripts.",
                "File paths are hard, right? '{0}' looks like it was written by a drunk bot.",
                "The system path '{0}' is as real as my love for your bugs."
            ],
            'RecursionError': [
                "Recursion depth exceeded. You're stuck in a loop of your own failure.",
                "Infinite loop? Do you want to melt the CPU or what?",
                "Mirror, mirror on the wall... your code is crashing after all."
            ],
            # Agrégalo a la base de datos de roasts en core.py
            'IndentationError': [
                "Indentation Error: One space to rule them all, and in the darkness bind them.",
                "Is it a tab? Is it a space? No, it's just you failing at basic alignment.",
                "Your code's indentation is as messy as my room. Fix it, '{0}'.",
                "Python is not a freestyle poem. Align your code or go back to Notepad (the basic one).",
                "My nightmares are coming back with '{0}'"
                ]
            }

        error_name = type.__name__
        
        if error_name in roasts:
            msg = random.choice(roasts[error_name]).format(value)
            
            # --- DISEÑO CON RICH ---
            error_text = Text()
            error_text.append(f">>> {msg}\n", style="bold yellow")
            error_text.append(f"\n📍 File: ", style="cyan")
            error_text.append(f"'{nombre_archivo}'", style="bold white")
            error_text.append(f"\n📟 Line {num_linea}: ", style="magenta")
            error_text.append(f"{contenido_linea}", style="italic green")

            # Creamos un panel elegante
            panel = Panel(
                error_text,
                title="[bold red]🔥 COMIC-SCRIPT ERROR 🔥[/bold red]",
                border_style="red",
                expand=False,
                padding=(1, 2)
            )
            
            console.print("\n") # Espacio para respirar
            console.print(panel)
            console.print("\n")
        else:
            console.print(f"\n[italic]🙄 Even I don't know what you did with '{value}'. Here's the boring stuff:[/italic]")
            sys.__excepthook__(type, value, traceback)

    sys.excepthook = custom_excepthook

setup_comic_errors()