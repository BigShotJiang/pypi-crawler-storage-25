import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="lightwave2",
    version="0.9.0",
    author="Perry Beau",
    author_email="psbeau@gmail.com",
    description="Controls for Lightwave RF second generation devices",
    install_requires=[
        "aiohttp>=3.9",
    ],
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/AbsenteeAtom/lightwave2",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.9",
)
