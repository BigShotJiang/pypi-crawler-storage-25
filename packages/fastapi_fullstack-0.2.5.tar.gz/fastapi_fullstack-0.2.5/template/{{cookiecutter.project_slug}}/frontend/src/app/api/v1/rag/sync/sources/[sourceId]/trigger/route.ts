{%- if cookiecutter.enable_rag and cookiecutter.use_jwt %}
{% raw %}import { NextRequest, NextResponse } from "next/server";
import { backendFetch, BackendApiError } from "@/lib/server-api";

// POST /api/v1/rag/sync/sources/:sourceId/trigger - Trigger sync
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ sourceId: string }> }
) {
  try {
    const { sourceId } = await params;
    const accessToken = request.cookies.get("access_token")?.value;
    const headers: Record<string, string> = {};
    if (accessToken) headers["Authorization"] = `Bearer ${accessToken}`;

    const data = await backendFetch(`/api/v1/rag/sync/sources/${sourceId}/trigger`, {
      method: "POST",
      headers,
    });
    return NextResponse.json(data);
  } catch (error) {
    if (error instanceof BackendApiError) {
      return NextResponse.json({ detail: error.message }, { status: error.status });
    }
    return NextResponse.json({ detail: "Internal server error" }, { status: 500 });
  }
}
{% endraw %}
{%- else %}
// Sync source trigger API route - not configured (enable_rag or use_jwt is false)
{%- endif %}
