# Returning-user flow

Read this file when the slim controller routes you here (state.kind ==
"returning"). The common steps run in ALL returning sub-states. Then branch
on `state.sub_state` for the drift-specific menus.

---

## Common steps (always run)

### 0. Drift check first

Run the wheel-version drift check (see slim controller §"Wheel-version
drift check"). If `installed < recommended_wheel_version`, the slim
controller's rule is to **auto-upgrade unattended via `pipx upgrade
selph-mcp` + `install-skill-tree --force`** and then continue this flow.
Do NOT stop and ask the user. Do NOT report the drift as "non-blocking"
or "advisory" — the upgrade is mandatory regardless of `min_supported_wheel_version`.
Only stop if the upgrade itself fails.

### 1. Self-update the slash command

```bash
selph-mcp-bootstrap refresh-slash-command --api-url "<api_url>"
```

Best-effort — if it exits non-zero (network failure), log and continue
with the cached local copy. The next invocation picks up the refreshed spec.

### 2. Ensure CLAUDE.md policy block + rule files are current

```bash
selph-mcp-bootstrap append-claude-md --workspace "<cwd>"
selph-mcp-bootstrap install-policy-block --workspace "<cwd>"
selph-mcp-bootstrap install-retrieval-rule --workspace "<cwd>"
selph-mcp-bootstrap install-writeback-rule --workspace "<cwd>"
selph-mcp-bootstrap install-memory-boundary-rule --workspace "<cwd>"
selph-mcp-bootstrap install-ambient-capture-rule --workspace "<cwd>"
selph-mcp-bootstrap install-context-lookup-rule --workspace "<cwd>"
```

Each `install-*-rule` keeps the corresponding file under
`<workspace>/.claude/rules/` at the current template. Only the managed
marker region is rewritten in place; any user prose appended outside the
markers is preserved.

### 3. Write/refresh the remote MCP entry (idempotent — only writes if stale)

```bash
selph-mcp-bootstrap write-mcp-entry --remote-url "<api_url>"
```

This also migrates any legacy `type: "stdio"` `selph` entry on first contact.

### 4. Reconcile onboarding state against the server

If `global_hydrated` is non-null, fetch the server's authoritative view:

```bash
selph-mcp-bootstrap whoami-remote \
    --api-url "<api_url>"
# bearer_token and consumer_id are read automatically from the credentials file
```

On success, write the response JSON to a temp file and reconcile:

```bash
selph-mcp-bootstrap reconcile-onboarding \
    --workspace "<cwd>" \
    --whoami @<whoami_temp>.json
```

### 4a. Refresh per-workspace credentials (always run — bearer_token may have rotated)

After `whoami-remote` succeeds, re-read global credentials and refresh the
per-workspace credentials file. This ensures upgrading users (whose
`credentials.json` was written before wheel 1.4.0 and lacks `bearer_token`)
can use ambient capture hooks without re-running the first-run flow:

```bash
selph-mcp-bootstrap hydrate-global
# → data: {consumer_id, user_id, api_url, bearer_token, ...}

selph-mcp-bootstrap write-credentials \
    --workspace "<cwd>" \
    --consumer-id "<consumer_id>" \
    --user-id "<user_id>" \
    --api-url "<api_url>" \
    --bearer-token "<bearer_token>"
```

If `hydrate-global` returns `data: null` (global credentials absent or
incomplete), skip this step and log internally — ambient capture hooks will
no-op until the user re-registers.

If `whoami-remote` returns `ok: false` with an auth error (HTTP 401/403),
surface the failure:

> Selph could not verify your consumer identity (auth failed on `/whoami`).
> Run `selph-mcp-bootstrap doctor` to diagnose. Continuing with cached state.

Do NOT silently skip — the user must know their credentials may need renewal.

If `whoami-remote` exits non-zero with a **validation error** — the error
field contains `"ValidationError"` or `"Extra inputs are not permitted"` —
this means the installed wheel is too old to parse the server's response.
Treat this as an automatic upgrade trigger:

1. Tell the user in one line: "Your selph-mcp wheel is out of date — upgrading now."
2. Run: `pipx upgrade selph-mcp`
3. After upgrade, re-run `whoami-remote` once. If it now succeeds, continue
   normally. If it still fails, surface the error and stop.

Do NOT continue with cached state on a validation error — the wheel must be
upgraded first because the rest of the flow may depend on fields only
present in the new contract.

If the failure is a network/5xx error, log and continue with cached state.

### 5. Drain invalidations

Call the Remote MCP tool `what_changed(since_cursor=<state.etag_cursor>)`.
The response returns `data.invalidated_keys`. Intersect with
`<workspace>/.selph/cache/_index.json` and purge stale cache entries.

### 6. Update the etag cursor

```bash
selph-mcp-bootstrap update-etag --workspace "<cwd>" --cursor <new_cursor>
```

### 7. Read the user's voice signal (Layer 2 personalization)

Call the Remote MCP tool `get_context` once with
`domain_hint="voice_and_creative_context"` and a short, broad question
like "How does this person prefer to be talked to — tone, length, level
of formality, things to avoid?" Hold the response in working memory for
the rest of the session.

Apply the response to *texture only* — the static rules in the slim
controller's "Voice & manner" section always remain in force. Use the
signal to bend defaults: if it indicates "prefers short", trim adjectives;
if "dry humor", let phrasing be drier; if "direct", drop softeners. If the
signal is absent or sparse (`meta.confidence < 0.3` OR
`meta.evidence_count == 0`), continue with the static defaults — do
NOT prompt the user for voice preferences. The signal accumulates over
time as the graph fills; cold sessions just feel like a polite,
plain-spoken assistant.

Soft-fail on any error: log internally and continue. A missing voice
signal must never block the rest of the session.

### 7a. Refresh ambient capture hooks (idempotent)

```bash
selph-mcp-bootstrap install-hooks --workspace "<cwd>"
```

This is a no-op when hooks are already current. If `state.drift_reasons`
includes `"hooks_missing"`, this step repairs that structural drift.

---

### 8. MANDATORY — run the workflow scan now, before branching

```bash
selph-mcp-bootstrap scan-workflows --workspace "<cwd>"
```

Parse `data` as the `WorkflowScanReport`. Hold it in scope. **Each
sub-state branch is required to render proposals from `data.proposals`
(per `flows/workflow-audit.md`) before producing its status summary.**
If `data.proposals` is empty, render nothing for proposals; do not
silently drop a non-empty list.

---

## Branch on `state.sub_state`

### `sub_state == "clean"` (no drift)

**Required ordering: render workflow proposals → then status line.**

1. Render proposals from the scan report per `flows/workflow-audit.md`. If
   empty, skip and continue.
2. Short status line: workspace name, installed workflow count, last sync
   timestamp, and proposal counts (N applied, M skipped/deferred).
3. No deep retrieval unless the user asks.

### `sub_state == "upgrade_in_place"` (version drift; no structural damage)

`upgrade_in_place` is triggered by one or more of:
`persona_contract_version`, `harness_adapter_version`,
`memory_boundary_policy_version`, or `contract_drift=True`.

If `contract_drift` is True (persona contract bumped), run:
`pipx upgrade selph-mcp`. Reuse the existing `consumer_id`; do not register
again.

Present the following numbered proposal menu (render actual drift_reasons):

```
Selph found N updates available:
- <drift_reason 1>
- <drift_reason 2>
How would you like to proceed?
  [1] Apply all updates
  [2] Review each
  [3] Skip this run
  [4] Defer until later
```

On `[1]` accept-all, apply the matching surgical primitives:

- `"retrieval_policy_block_missing"` →
  `selph-mcp-bootstrap install-policy-block --workspace "<cwd>"`
- `"retrieval_rule_v2_missing"` →
  `selph-mcp-bootstrap install-retrieval-rule --workspace "<cwd>"`
- `"writeback_rule_v2_missing"` →
  `selph-mcp-bootstrap install-writeback-rule --workspace "<cwd>"`
- `"memory_boundary_rule_v2_missing"` →
  `selph-mcp-bootstrap install-memory-boundary-rule --workspace "<cwd>"`
- `"ambient_capture_rule_v2_missing"` →
  `selph-mcp-bootstrap install-ambient-capture-rule --workspace "<cwd>"`
- `"context_lookup_rule_missing"` →
  `selph-mcp-bootstrap install-context-lookup-rule --workspace "<cwd>"`
- `"workflow_template_stale"` → for each installed workflow:
  `selph-mcp-bootstrap migrate-workflow --workspace "<cwd>" --workflow-id <id> --current-template-version 1`
- `"hooks_missing"` →
  `selph-mcp-bootstrap install-hooks --workspace "<cwd>"`
- `"credentials_missing_bearer_token"` → Step 4a (hydrate-global + write-credentials
  with `--bearer-token`) repairs this automatically — no extra menu step needed.
  The drift tag ensures upgrading users who skip the explicit drift menu still get
  their credentials file updated during Step 4a.
- Version drift tags → re-run `selph-mcp-bootstrap record-onboarding`
  with current constants to stamp the new versions.

On `[2]` review-each, show one accept/skip prompt per drift item.

On `[3]`/`[4]`, emit an observation via `observe_session` noting the deferred
upgrade (best-effort; do not block if the MCP call fails) and continue.

After the drift menu resolves, render proposals from the scan report per
`flows/workflow-audit.md`, then produce the final status summary.

### `sub_state == "repair"` (structural drift)

`repair` means at least one structural artifact is broken.

Present a narrower "Repair required" menu:

```
Selph detected broken artifacts that need repair:
- <drift_reason 1>
- <drift_reason 2>
These issues can be fixed without resetting your workspace.
  [1] Repair all broken artifacts now
  [2] Review each artifact
  [3] Skip repair this run
  [4] Defer repair until later
```

On `[1]` repair-all, apply the same surgical primitives as `upgrade_in_place`.
On `[2]`, show one per-artifact accept/skip prompt.
On `[3]`/`[4]`, log the deferral and continue.

After the repair menu resolves, render proposals from the scan report, then
produce the final status summary.

---

## Session menu (always present after the sub-state section resolves)

Once the drift/repair/clean section above finishes and the status line is
shown, present this menu on **every returning run**. It appears after the
status line — not before, not in place of it.

```
What would you like to do?
  [1] Audit and personalize my workflows
  [2] How does this work?
  [3] What does Selph know about me right now?
  [4] Nothing — I'm done
```

**On `[1]` — Workflow audit:**
Read `flows/workflow-audit.md` and run the full five-phase
persona-personalization audit. This walks through each installed workflow
and helps tailor it to how you actually work — prompts, cadence, what gets
surfaced, how it talks to you.

**On `[2]` — How does this work?:**
Explain in plain language, no jargon, no internal taxonomy names:

> This skill connects your Claude Code workspace to your Selph persona
> graph — a private, structured record of who you are: your projects,
> goals, relationships, preferences, and how you like to work.
>
> Every time you run `/using-selph`, it does a few things automatically:
> - Checks that your local files are in sync with the Selph server
> - Installs any missing workflow files
> - Picks up changes Selph has learned since your last session
>
> Over time, Selph builds up a picture of you from the conversations and
> context you share. That picture stays on Selph's side — your workspace
> only holds lightweight operational files (tasks, drafts, reminders) that
> are yours to edit or delete. The durable stuff — your goals, how you
> prefer to communicate, what projects matter to you — lives in Selph and
> travels with you across workspaces.
>
> Workflows are pre-built sequences — things like a morning briefing,
> meeting prep, or a weekly review — that Claude runs using your Selph
> context. The more Selph knows about you, the more useful they get.
>
> If you want to see what Selph knows, choose [3]. To shape how your
> workflows fit your style, choose [1].

After explaining, loop back with one line: "Anything else?" and show
`[1] [3] [4]`.

**On `[3]` — What does Selph know about me?:**
Call `get_context(intent="briefing", subject="self")`. Render the result
in plain language, applying the evidence-chip contract from
`reference/voice-and-evidence.md`. Cap the summary at 5–6 bullet points;
offer to go deeper on any one if the user asks.

Apply sparse-graph posture: if `meta.confidence < 0.3` OR
`meta.evidence_count == 0`, say:

> I don't know you well enough yet — Selph is still building your
> picture. The more you work with it, the more it learns.

Do not fabricate claims when evidence is thin.

**On `[4]` — Done:**
Close with a single line:

> Done. Run `/using-selph` again any time.

Do NOT prompt for further input after `[4]`.
