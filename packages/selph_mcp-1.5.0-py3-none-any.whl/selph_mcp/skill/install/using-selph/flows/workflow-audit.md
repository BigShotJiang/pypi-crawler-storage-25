# Workflow refresh proposals + five-phase audit

Read this file when rendering `scan_workflows` proposals from any flow.

---

## Workflow refresh proposals

For each proposal in `scan_workflows data.proposals`:

- If `proposal_kind == "noop"`: skip silently.
- If `proposal_kind == "upgrade_in_place"` (Selph-managed workflow):
  ```
  Workflow: <workflow_id>
  Update: <suggested_action>
    [1] Update  [2] Skip  [3] Note for manual review  [4] Defer
  ```
  On `[1]`: `selph-mcp-bootstrap migrate-workflow --workspace "<cwd>" --workflow-id <id> --current-template-version 1`.
- If `proposal_kind == "advisory_only"` AND
  `drift_reasons == ["no_selph_tool_allowlisted"]` (skill missing every
  `mcp__selph-remote__*` entry from its `allowed-tools` frontmatter):
  ```
  Workflow: <workflow_id>  (no Selph tool in allowed-tools)
  Risk: this skill cannot honour the context-lookup rule when its
  runtime input names people, projects, or events. It will guess
  instead of asking Selph.
    [1] Show the rule and what to add  [2] Skip
  ```

  On `[1]`, open
  `<workspace>/.claude/rules/selph-context-lookup.md` (install it via
  `selph-mcp-bootstrap install-context-lookup-rule --workspace "<cwd>"`
  if it isn't there yet) and walk the user through adding both
  `mcp__selph-remote__ask_selph` and `mcp__selph-remote__get_context`
  to the skill's frontmatter. Offer the
  `templates/workflow_skill_author.md.tmpl` scaffold as a reference for
  what a compliant SKILL.md looks like. Do NOT modify the skill file
  on the user's behalf — this is a flag-and-coach moment, not an
  auto-patch. If the user is sure the skill is personalization-not-
  applicable, the resolution is to add the skill-meta tag
  `personalization_mode=not_applicable` so the scanner stops flagging
  it; the rule docstring covers when that's the right call.

- If `proposal_kind == "advisory_only"` (unmanaged pre-existing,
  other drift reasons):
  ```
  Workflow: <workflow_id>  (unmanaged — Selph cannot upgrade automatically)
  Suggestion: <suggested_action>
    [1] Show me what Selph would add  [2] Skip
  ```

  On `[1]`, run the **five-phase audit flow** below. Do NOT make a single
  blind `ask_selph` call on the workflow slug — that surfaces unrelated
  memories from the broad DEEP-embedding path. Read the design brief at
  `docs/using_selph_workflow_personalization_strategy.md` if you want
  the full rationale.

  All working state for this audit lives under
  `<workspace>/.selph/sketches/<workflow_id>/` (created lazily; already
  covered by the `.selph/` gitignore block from `append-claude-md`).
  The directory persists between turns in the same session so follow-up
  questions don't re-audit; the next `/using-selph` invocation starts
  Phase A from scratch unless the directory is still present.

---

## Phase A — Workflow audit (no Selph call)

Read the workflow's controller file (its `SKILL.md`, or its primary
spec/controller if no `SKILL.md` exists). Do NOT truncate. Write
`<workspace>/.selph/sketches/<workflow_id>/01-audit.md` with these
sections:

- **What it is** — name, surface (slash command, agent, cron, etc.),
  trigger, cadence (one paragraph)
- **Purpose** — one paragraph in plain English, derived verbatim from
  the controller
- **Steps & decision points** — bullets covering each step where the
  workflow makes a choice (filter, rank, route, draft, synthesize, send)
- **Enrichment slots** — for each step that ranks/filters/drafts/decides,
  a one-line note on where persona context could change the output
- **Intent classification** — pick exactly one primary bucket (and
  optionally one secondary) from this six-bucket vocabulary:

  | Intent | Covers | `domain_hint` to use in Phase B |
  |---|---|---|
  | `professional-output` | Workflows that produce work artifacts (briefings, memos, plans, decks) | `professional_context` |
  | `learning-and-research` | Workflows for absorbing/structuring information (study, summarization, deep-dives) | `learning_and_active_interests` |
  | `social-and-relational` | Workflows touching messaging, replies, social engagement, contacts | `social_context` |
  | `personal-routines` | Daily/weekly cadences, home, health, errands, recreation | `daily_routines` |
  | `creative-output` | Drafting, ideation, voice/style-driven artifacts (writing, design briefs) | `voice_and_creative_context` |
  | `ops-and-admin` | Tooling, scripts, infra, maintenance, devops | `tools_and_workflow_context` |

**If two buckets tie or none fit confidently:** stop and ask the user.
This is an *inquiry* moment, not an action choice — follow the
slim controller's "Voice & manner" rules: explain what you saw, name the
ambiguity in plain words, then ask one open follow-up question about
their intent. Don't lead with a numbered menu; let them tell you in their
own words why they built the workflow. A short clarifying menu may
follow if their answer leaves the bucket genuinely tied, but it's
optional.

Concrete example of the right shape (do NOT copy the exact wording —
adapt it to the workflow you actually read and to the user's voice
signal from returning §7):

> "I read the controller for the morning AI/tech briefing you read over
> coffee. It pulls together YouTube and Twitter into one PDF every
> morning — a clean little intel digest. I can't tell from the file
> alone whether you started building this to stay sharp on AI/tech as a
> personal habit, or because the briefing actually feeds your work
> decisions. What pushed you to build it?"

Wrong shape (don't do this):

> "Intent classification is borderline. Pick:
>   [1] learning-and-research → domain_hint=learning_and_active_interests
>   [2] professional-output → domain_hint=professional_context
>   [3] none of these — describe the intent in your own words
>   [4] skip personalization for daily-briefing"

The wrong version names internal vocabulary (`domain_hint=`, slug
`daily-briefing`) and forces inquiry into a menu. The right version
reflects the workflow back in the user's words and asks them to tell
you why. Don't guess silently — a wrong bucket burns a Phase B call.

---

## Phase B — Broad context bundle (1 Selph call, intentionally wide)

Make exactly one `ask_selph` call. Use the `domain_hint` value from the
intent table above. The question itself asks for a comprehensive context
block appropriate to the intent — don't include the workflow slug; let
the hint do the scoping.

Example for `professional-output`:

> "Give me a comprehensive context block on my professional self:
> active projects I'm building, current learning trajectory,
> professional interests, output preferences, and working style."

Save the response (verbatim, including all citation chips) to
`<workspace>/.selph/sketches/<workflow_id>/02-context-bundle.md`.

**Failure-mode check after the call returns:** if the bundle reads
tonally off for the classified intent (e.g. you classified
`professional-output` and the bundle is dominated by social/messaging
evidence), surface to the user:

> "This workflow looks more `<other-intent>` than `<classified-intent>`
> based on what your graph returned. Re-classify and re-query?
>   [1] Yes, re-classify  [2] Continue with current bundle  [3] Skip"

Do not paper over the mismatch by proceeding silently.

---

## Phase C — Slot drafting with lazy gap-fills

For each enrichment slot listed in `01-audit.md`, before considering
any new Selph call:

1. Read `02-context-bundle.md` plus any existing `03-gap-*.md` files
   in the same directory.
2. Ask explicitly: *"Does this context answer what I need to draft
   this slot? If not, what specifically is missing?"*
3. **If covered** → draft the slot from existing context. No Selph call.
4. **If not covered** → identify the specific gap (one sentence), fire
   one narrow `ask_selph` query targeted at that gap (e.g. "What's my
   preferred output format for short briefings?"), save the response
   to `<workspace>/.selph/sketches/<workflow_id>/03-gap-<slug>.md`,
   then draft.

Newly-saved gap files are in scope for every later slot — a gap-fill
for slot 3 may silently answer slot 5. The default is no call. A
6-slot workflow typically fires 1 broad Phase B call + 0–2 gap-fills,
not 6 calls.

---

## Phase D — Synthesis (no Selph)

Read `01-audit.md` + `02-context-bundle.md` + each `03-gap-*.md`. Draft
two artifacts and present BOTH inline in the chat (do not write either
to disk in v1):

1. **The user-facing sketch.** For each slot:
   - *the slot* (from audit)
   - *the change* (what Selph would add or modify)
   - *why* (which goal/project/interest from the bundle this serves)
   - *evidence* (which markdown file you wrote it to + which MEM-IDs
     inside that file)

2. **The context block preview.** A structured block under a heading
   `Persona context for <workflow_id>` with subsections:
   - `priority_topics:` — bulleted list of what to weight up
   - `signals_to_watch:` — bulleted list of what to look for in the
     workflow's input
   - `output_style:` — one paragraph on tone/length/format preference
   - `exclusions:` — bulleted list of what to deprioritize

   Tell the user this block is the durable spec the workflow would read
   at runtime — they can copy/paste it wherever they want. (v2 will
   write this to `.selph/context/<workflow_id>.md` automatically; v1
   keeps it in chat.)

Save the rendered sketch to
`<workspace>/.selph/sketches/<workflow_id>/99-draft-sketch.md` for
follow-up turns to reference. Citations point to the source markdown
files (and to the memory IDs inside those files), not just to MEM-IDs.

---

## Phase E — Iterate (v1 — no on-disk durable spec, no workflow patch)

Sketch + context block live in the chat conversation. The user can
copy them, ignore them, or ask for changes:

- "more on the ranker slot" → re-read the working state, fire one
  targeted gap-fill if needed, re-synthesize
- "drop slot 2" → re-render without it, no new Selph call
- "different intent — try `learning-and-research`" → re-run Phase B
  with the new `domain_hint`, overwrite `02-context-bundle.md`,
  re-synthesize

Working state under `.selph/sketches/<workflow_id>/` is retained
between turns. The next `/using-selph` invocation re-runs Phase A
from scratch unless the working state is still present.

Do NOT in v1: write `.selph/context/<workflow_id>.md`, patch the
workflow file, or maintain a `_shared/` cross-workflow bundle. Those
ship in v2 once v1 has produced ≥3 sketches across ≥2 buckets and
the audit pattern is validated.

Then continue to the next proposal in the loop.

On `[2]`: continue to the next proposal silently.

Do NOT offer the old `[3] Note for manual review` / `[4] Defer`
options — both collapsed into `[2] Skip` so the menu stays binary.

After rendering all proposals, show the session summary.
