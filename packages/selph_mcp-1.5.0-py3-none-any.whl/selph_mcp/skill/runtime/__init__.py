"""Async watcher + binding runtime for the ``using-selph`` Claude Code skill.

Phase 3 (§3.3.a–§3.3.c) of
``docs/selph_harness_context_implementation_plan.md``.

This sub-package is the **only** place async I/O lives in the
``using-selph`` adapter. ``bootstrap`` remains bootstrap-only (sync,
I/O-free). SKILL.md and workflow loaders call
``runtime.workflow_state_changed`` on every harness state mutation;
lifecycle evaluations are single-threaded per run (§2.1
binding-resolution semantics).

Import constraints (per ``.importlinter`` ``adapters-surface-only``):
  ALLOWED: ``selph_mcp.contracts``, ``selph_mcp.adapters.binding``,
           ``selph_utils``, stdlib, this package.
  FORBIDDEN: ``selph_core``, ``selph_db``, ``selph_graph``,
             ``ingestion_api``, ``selph_apps``.

Sub-module layout
-----------------
- ``_shared``       — logger (pinned name), constants, _int_env
- ``_protocol``     — PersonaCallProtocol, _get_workflow_spec_type
- ``_fingerprint``  — _FINGERPRINT_RE, _is_safe_fingerprint, _safe_cache_file
- ``_paths``        — _cache_dir, _cache_index_path, _telemetry_dir, _memo_dir
- ``_cache_index``  — _load_cache_index, _save_cache_index,
                      enforce_cache_limits, purge_stale_cache
- ``_telemetry``    — _rotate_telemetry_if_needed, _append_telemetry
- ``_runtime``      — Runtime class (held whole at ~860 lines — see file docstring)
"""

from __future__ import annotations

# ── shared infrastructure ─────────────────────────────────────────────────────
from ._shared import (
    _ADAPTER_CONTRACT_VERSION,
    _CACHE_MAX_ENTRIES_DEFAULT,
    _CACHE_TTL_DAYS_DEFAULT,
    _PURGE_INTERVAL_SECONDS,
    _TELEMETRY_BACKUP_COUNT_DEFAULT,
    _TELEMETRY_MAX_BYTES_DEFAULT,
    _int_env,
    _log,
)

# ── re-export contract version helpers ───────────────────────────────────────
from selph_mcp.contracts.versions import (
    HARNESS_ADAPTER_VERSION,
    load_contract_versions,
)

# ── protocol ──────────────────────────────────────────────────────────────────
from ._protocol import (
    PersonaCallProtocol,
    _get_workflow_spec_type,
)

# ── fingerprint validator ─────────────────────────────────────────────────────
from ._fingerprint import (
    _FINGERPRINT_RE,
    _is_safe_fingerprint,
    _safe_cache_file,
)

# ── path helpers ──────────────────────────────────────────────────────────────
from ._paths import (
    _cache_dir,
    _cache_index_path,
    _memo_dir,
    _telemetry_dir,
)

# ── cache-index I/O + eviction ────────────────────────────────────────────────
from ._cache_index import (
    _load_cache_index,
    _save_cache_index,
    enforce_cache_limits,
    purge_stale_cache,
)

# ── telemetry ─────────────────────────────────────────────────────────────────
from ._telemetry import (
    _append_telemetry,
    _rotate_telemetry_if_needed,
)

# ── Runtime class ─────────────────────────────────────────────────────────────
from ._runtime import Runtime

# ── Session spool (Phase D harness-side local log + trigger logic) ────────────
from ._session_spool import (
    on_session_turn,
    evaluate_trigger,
    build_flush_payload,
    force_flush_payload,
    on_flush_success,
    on_flush_failure,
    on_flush_409,
    append_turn_auto_idx,
    list_sessions_with_unacked_turns,
    count_total_unacked_user_turns,
)

# ── public surface ────────────────────────────────────────────────────────────
__all__ = [
    # Production public surface
    "Runtime",
    "PersonaCallProtocol",
    "purge_stale_cache",
    "enforce_cache_limits",
    # Defensive re-exports — were module-level attributes before the refactor;
    # any caller reaching in via attribute access (runtime.<name>) keeps working.
    "_log",
    "_ADAPTER_CONTRACT_VERSION",
    "_PURGE_INTERVAL_SECONDS",
    "_CACHE_MAX_ENTRIES_DEFAULT",
    "_CACHE_TTL_DAYS_DEFAULT",
    "_TELEMETRY_MAX_BYTES_DEFAULT",
    "_TELEMETRY_BACKUP_COUNT_DEFAULT",
    "_int_env",
    "_FINGERPRINT_RE",
    "_is_safe_fingerprint",
    "_safe_cache_file",
    "_cache_dir",
    "_cache_index_path",
    "_telemetry_dir",
    "_memo_dir",
    "_load_cache_index",
    "_save_cache_index",
    "_rotate_telemetry_if_needed",
    "_append_telemetry",
    "_get_workflow_spec_type",
    # Contract version helpers
    "HARNESS_ADAPTER_VERSION",
    "load_contract_versions",
    # Session spool (Phase D + G)
    "on_session_turn",
    "evaluate_trigger",
    "build_flush_payload",
    "force_flush_payload",
    "on_flush_success",
    "on_flush_failure",
    "on_flush_409",
    "append_turn_auto_idx",
    "list_sessions_with_unacked_turns",
    "count_total_unacked_user_turns",
]
