"""Public ``install_*_rule`` functions for the four new v2 rule files.

Each function is a thin wrapper over ``install_marker_rule`` from
``_rule_install_common``. Adding a new rule file means adding one entry here
and the matching template + marker ID.

Marker IDs and file names must match the templates:

| Function                    | File                              | Marker ID                  |
|-----------------------------|-----------------------------------|----------------------------|
| install_retrieval_rule      | selph-retrieval-rule.md           | retrieval-rule             |
| install_writeback_rule      | selph-writeback-rule.md           | writeback-rule             |
| install_memory_boundary_rule| selph-memory-boundary-rule.md     | memory-boundary-rule       |
| install_ambient_capture_rule| selph-ambient-capture-rule.md     | ambient-capture-rule       |
"""

from __future__ import annotations

from pathlib import Path

from ._rule_install_common import install_marker_rule

__all__ = [
    "install_retrieval_rule",
    "install_writeback_rule",
    "install_memory_boundary_rule",
    "install_ambient_capture_rule",
]


def install_retrieval_rule(workspace: Path) -> bool:
    """Install/refresh ``.claude/rules/selph-retrieval-rule.md``.

    Covers: when/how to call Selph, tool selection, envelope reading, evidence
    chips, caching, and revocation. Managed region: ``selph:retrieval-rule:v1``.

    Returns True if the file was created or updated.
    """
    return install_marker_rule(
        workspace=workspace,
        rule_filename="selph-retrieval-rule.md",
        template_relpath="selph_retrieval_rule.md",
        marker_id="retrieval-rule",
    )


def install_writeback_rule(workspace: Path) -> bool:
    """Install/refresh ``.claude/rules/selph-writeback-rule.md``.

    Covers: ``observe_session`` correct signature and provenance values,
    ``correct``, ``recommendation_feedback``. Fixes the stale
    ``store_raw_only`` / ``mode`` reference in legacy v1 CLAUDE.md blocks.
    Managed region: ``selph:writeback-rule:v1``.

    Returns True if the file was created or updated.
    """
    return install_marker_rule(
        workspace=workspace,
        rule_filename="selph-writeback-rule.md",
        template_relpath="selph_writeback_rule.md",
        marker_id="writeback-rule",
    )


def install_memory_boundary_rule(workspace: Path) -> bool:
    """Install/refresh ``.claude/rules/selph-memory-boundary-rule.md``.

    Covers: the key durable-vs-operational test, what belongs in Selph vs
    stays local, and anti-patterns (do not mirror transcripts, do not infer
    from single mentions). Managed region: ``selph:memory-boundary-rule:v1``.

    Returns True if the file was created or updated.
    """
    return install_marker_rule(
        workspace=workspace,
        rule_filename="selph-memory-boundary-rule.md",
        template_relpath="selph_memory_boundary_rule.md",
        marker_id="memory-boundary-rule",
    )


def install_ambient_capture_rule(workspace: Path) -> bool:
    """Install/refresh ``.claude/rules/selph-ambient-capture-rule.md``.

    Covers: the three hooks (UserPromptSubmit, Stop, SessionEnd), the spool
    location, flush triggers, when to call ``observe_session`` explicitly vs
    letting ambient capture handle it, and how to disable. Managed region:
    ``selph:ambient-capture-rule:v1``.

    Returns True if the file was created or updated.
    """
    return install_marker_rule(
        workspace=workspace,
        rule_filename="selph-ambient-capture-rule.md",
        template_relpath="selph_ambient_capture_rule.md",
        marker_id="ambient-capture-rule",
    )
