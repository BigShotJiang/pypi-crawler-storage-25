"""Shared R-M-W helper for installing managed marker-protected rule files.

All ``install_*_rule`` functions in this package delegate here, eliminating
duplicated R-M-W logic across ``_claude_md.py``,
``_context_lookup_rule.py``, and the new rule installers.
"""

from __future__ import annotations

from pathlib import Path

from ._shared import _read_template, logger
from ._file_locking import _atomic_write_text, _locked_write

__all__ = ["install_marker_rule"]


def _rules_dir(workspace: Path) -> Path:
    return workspace / ".claude" / "rules"


def install_marker_rule(
    workspace: Path,
    rule_filename: str,
    template_relpath: str,
    marker_id: str,
) -> bool:
    """Install or update a managed marker-protected rule file.

    Writes ``<workspace>/.claude/rules/<rule_filename>`` from the template at
    ``templates/<template_relpath>``. The template must contain a matching
    ``<!-- selph:<marker_id>:v1 START -->`` / ``<!-- selph:<marker_id>:v1 END -->``
    pair — the function extracts only that region from the template and writes
    it as the managed block in the target file.

    Behaviour:
    - If the target file has both markers: replaces only the region between
      them (user prose outside the markers is preserved).
    - If the target file has only one marker (partial): refuses to write and
      returns False, logging a warning. Never appends to a partially-marked
      file to avoid duplicate blocks.
    - If the target file has no markers: appends the full marked block.
    - If the file does not exist: creates it with the marked block.

    Returns True if the file was created or the managed region was updated.
    """
    marker_start = f"<!-- selph:{marker_id}:v1 START -->"
    marker_end = f"<!-- selph:{marker_id}:v1 END -->"

    rules_dir = _rules_dir(workspace)
    rules_dir.mkdir(parents=True, exist_ok=True)
    target = rules_dir / rule_filename

    template_text = _read_template(template_relpath)
    s_tmpl = template_text.find(marker_start)
    e_tmpl = template_text.find(marker_end)
    if s_tmpl == -1 or e_tmpl == -1:
        logger.warning(
            "install_marker_rule: markers not found in template; skipping",
            extra={
                "event": "bootstrap.install_marker_rule.no_markers",
                "rule_filename": rule_filename,
                "template_relpath": template_relpath,
                "marker_id": marker_id,
            },
        )
        return False

    rule_block = template_text[s_tmpl: e_tmpl + len(marker_end)]
    changed = {"value": False}

    def _do_write() -> None:
        existing = target.read_text(encoding="utf-8") if target.exists() else ""
        es = existing.find(marker_start)
        ee = existing.find(marker_end)

        if es != -1 and ee != -1 and ee > es:
            # Both markers present — replace managed region in place.
            current_block = existing[es: ee + len(marker_end)]
            if current_block == rule_block:
                logger.debug(
                    "install_marker_rule: already up to date",
                    extra={
                        "event": "bootstrap.install_marker_rule",
                        "rule_filename": rule_filename,
                        "changed": False,
                    },
                )
                return
            new_content = (
                existing[:es]
                + rule_block
                + existing[ee + len(marker_end):]
            )
        elif es != -1 or ee != -1:
            # Partial markers — refuse to avoid creating a duplicate block.
            logger.warning(
                "install_marker_rule: partial markers found; refusing to "
                "append to avoid duplicate block",
                extra={
                    "event": "bootstrap.install_marker_rule.partial_markers",
                    "rule_filename": rule_filename,
                    "has_start": es != -1,
                    "has_end": ee != -1,
                },
            )
            return
        else:
            # No markers — append the full block.
            sep = "" if existing.endswith("\n\n") else (
                "\n" if existing.endswith("\n") else "\n\n"
            )
            if not existing:
                sep = ""
            new_content = existing + sep + rule_block
            if not new_content.endswith("\n"):
                new_content += "\n"

        _atomic_write_text(target, new_content)
        changed["value"] = True
        logger.info(
            "install_marker_rule: rule installed",
            extra={
                "event": "bootstrap.install_marker_rule",
                "rule_filename": rule_filename,
                "changed": True,
                "path": str(target),
            },
        )

    _locked_write(target, _do_write)
    return changed["value"]
