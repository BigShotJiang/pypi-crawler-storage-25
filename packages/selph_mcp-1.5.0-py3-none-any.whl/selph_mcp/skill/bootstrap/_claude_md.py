"""CLAUDE.md append and retrieval-policy block helpers for the using-selph bootstrap."""

from __future__ import annotations

from pathlib import Path

from ._shared import logger, _read_template
from ._paths import _claude_md_path
from ._file_locking import _atomic_write_text, _locked_write

__all__: list[str] = [
    "rewrite_generated_block",
    "append_claude_md_block",
    "install_claude_md_block",
    "install_retrieval_policy_block",
    "migrate_v1_claude_md_block",
]

# Ownership markers — single source of truth
# Legacy v1 marker (append-only, no end marker — never modify in place).
_CLAUDE_MD_MARKER = "<!-- selph:using-selph:v1 -->"
# v2 START/END markers — support in-place replacement via rewrite_generated_block.
_CLAUDE_MD_V2_START = "<!-- selph:using-selph:v2 START -->"
_CLAUDE_MD_V2_END = "<!-- selph:using-selph:v2 END -->"
# Phase 3 retrieval-policy block markers (§3.4).
_RETRIEVAL_POLICY_START = "<!-- selph:retrieval-policy:v1 START -->"
_RETRIEVAL_POLICY_END = "<!-- selph:retrieval-policy:v1 END -->"


def rewrite_generated_block(
    target_path: Path,
    marker_start: str,
    marker_end: str,
    new_content: str,
) -> bool:
    """Replace content between ``marker_start`` / ``marker_end`` in ``target_path``.

    - If both markers are present: replaces the region between them (inclusive)
      with ``marker_start + new_content + marker_end``.
    - If markers are absent: appends the full marked block at the end of the
      file.
    - Read/modify/write is protected by ``_locked_write``.

    Returns True when the file was modified.
    """
    changed = {"value": False}

    def _do_write() -> None:
        existing = target_path.read_text(encoding="utf-8") if target_path.exists() else ""
        full_block = f"{marker_start}\n{new_content}\n{marker_end}"
        s = existing.find(marker_start)
        e = existing.find(marker_end)
        if s != -1 and e != -1 and e > s:
            # Both markers present — replace block in-place.
            current = existing[s: e + len(marker_end)]
            if current == full_block:
                return  # already up to date
            new_text = existing[:s] + full_block + existing[e + len(marker_end):]
        elif s != -1 or e != -1:
            # Defense-in-depth: partial markers — caller (migrate_workflow_skill)
            # is responsible for routing to legacy_rewrite before reaching here,
            # but if called directly with a partial-marker file, refuse silently
            # rather than appending a duplicate block.
            logger.warning(
                "rewrite_generated_block: partial markers found; refusing to "
                "append to avoid duplicate block",
                extra={
                    "event": "bootstrap.rewrite_generated_block.partial_markers_refused",
                    "path": str(target_path),
                    "has_start": s != -1,
                    "has_end": e != -1,
                },
            )
            return
        else:
            # No markers present — append.
            sep = "" if existing.endswith("\n\n") else ("\n" if existing.endswith("\n") else "\n\n")
            if existing == "":
                sep = ""
            new_text = existing + sep + full_block
            if not new_text.endswith("\n"):
                new_text += "\n"

        _atomic_write_text(target_path, new_text)
        changed["value"] = True

    _locked_write(target_path, _do_write)
    return changed["value"]


def migrate_v1_claude_md_block(workspace: Path) -> bool:
    """Detect a lone v1 marker (no v1 END) and insert a v2 START/END block below it.

    The old v1 block has only a start marker — no end marker — so it cannot
    be updated in place. This function detects the v1-only pattern and appends
    a v2 pointer block below it without touching the v1 block.

    Returns True if the v2 block was inserted, False if the file already has
    a v2 block or no v1 marker was found.
    """
    path = _claude_md_path(workspace)
    changed = {"value": False}

    def _do_write() -> None:
        existing = path.read_text(encoding="utf-8") if path.exists() else ""
        # Already has v2 — nothing to do.
        if _CLAUDE_MD_V2_START in existing:
            logger.debug(
                "migrate_v1_claude_md_block: v2 block already present",
                extra={"event": "bootstrap.migrate_v1_claude_md.already_v2"},
            )
            return
        # No v1 marker — nothing to migrate.
        if _CLAUDE_MD_MARKER not in existing:
            logger.debug(
                "migrate_v1_claude_md_block: no v1 marker found",
                extra={"event": "bootstrap.migrate_v1_claude_md.no_v1"},
            )
            return

        # v1-only present — append the v2 block below the existing content.
        block = _read_template("CLAUDE.md.block")
        sep = "" if existing.endswith("\n\n") else ("\n" if existing.endswith("\n") else "\n\n")
        new_content = existing + sep + block
        if not new_content.endswith("\n"):
            new_content += "\n"
        _atomic_write_text(path, new_content)
        changed["value"] = True
        logger.info(
            "migrate_v1_claude_md_block: v2 block appended below v1",
            extra={
                "event": "bootstrap.migrate_v1_claude_md",
                "changed": True,
                "path": str(path),
            },
        )

    _locked_write(path, _do_write)
    return changed["value"]


def install_claude_md_block(workspace: Path) -> bool:
    """Install or replace the v2 Selph CLAUDE.md pointer block.

    Uses ``rewrite_generated_block`` with v2 markers so the block can be
    updated in place on subsequent installs — unlike the old append-only v1
    approach.

    If the file has a v1-only marker but no v2 block, ``migrate_v1_claude_md_block``
    is called first to ensure the v2 block is inserted below the v1 content
    rather than clobbering it.

    Returns True if the file was modified (or created).
    """
    path = _claude_md_path(workspace)

    # Ensure parent directory exists.
    path.parent.mkdir(parents=True, exist_ok=True)

    # If there is a v1-only marker, migrate first (appends v2 below it).
    existing = path.read_text(encoding="utf-8") if path.exists() else ""
    if _CLAUDE_MD_MARKER in existing and _CLAUDE_MD_V2_START not in existing:
        migrate_v1_claude_md_block(workspace)

    block = _read_template("CLAUDE.md.block")
    # The template is the full v2 block including START/END markers.
    # Extract only the inner content (between the markers) for rewrite_generated_block.
    s = block.find(_CLAUDE_MD_V2_START)
    e = block.find(_CLAUDE_MD_V2_END)
    if s == -1 or e == -1:
        logger.warning(
            "install_claude_md_block: v2 markers not found in template; skipping",
            extra={"event": "bootstrap.install_claude_md_block.no_markers"},
        )
        return False
    inner = block[s + len(_CLAUDE_MD_V2_START): e].strip("\n")

    changed = rewrite_generated_block(path, _CLAUDE_MD_V2_START, _CLAUDE_MD_V2_END, inner)
    if changed:
        logger.info(
            "install_claude_md_block: v2 block installed",
            extra={
                "event": "bootstrap.install_claude_md_block",
                "changed": True,
                "path": str(path),
            },
        )
    return changed


def append_claude_md_block(workspace: Path) -> bool:
    """Append the using-selph rule block to CLAUDE.md if missing.

    Idempotent: if the marker comment is present, no-op. Otherwise read the
    current contents (or empty), append the template block. Never overwrites
    existing user content — append-only.

    Read/modify/write is protected by ``_file_lock`` so two concurrent
    bootstrap runs can't race on the marker check and double-append the block.

    Returns True if modified (or created).
    """
    path = _claude_md_path(workspace)
    changed = {"value": False}

    def _do_write() -> None:
        existing = path.read_text(encoding="utf-8") if path.exists() else ""
        if _CLAUDE_MD_MARKER in existing:
            logger.debug(
                "CLAUDE.md block already present",
                extra={"event": "bootstrap.append_claude_md", "changed": False},
            )
            return
        block = _read_template("CLAUDE.md.block")
        sep = "" if existing.endswith("\n\n") else ("\n" if existing.endswith("\n") else "\n\n")
        if existing == "":
            sep = ""
        new_content = existing + sep + block
        if not new_content.endswith("\n"):
            new_content += "\n"
        _atomic_write_text(path, new_content)
        changed["value"] = True
        logger.info(
            "CLAUDE.md block appended",
            extra={
                "event": "bootstrap.append_claude_md",
                "changed": True,
                "path": str(path),
            },
        )

    _locked_write(path, _do_write)
    return changed["value"]


def install_retrieval_policy_block(workspace: Path) -> bool:
    """Insert or replace the Phase 3 retrieval-policy block in ``CLAUDE.md``.

    The block is wrapped in HTML comment markers:

        <!-- selph:retrieval-policy:v1 START -->
        ...
        <!-- selph:retrieval-policy:v1 END -->

    Idempotent — if the markers are already present, the content between
    them is replaced in place. If absent, the block is appended after the
    main using-selph block (or at the end of the file). No async I/O —
    bootstrap stays sync.

    Read/modify/write is protected by ``_file_lock``.

    Returns True if the file was modified (or created).
    """
    path = _claude_md_path(workspace)
    changed = {"value": False}

    # Read the retrieval-policy block from the template.
    template_text = _read_template("CLAUDE.md.block")

    # Extract the block between the markers from the template.
    start_idx = template_text.find(_RETRIEVAL_POLICY_START)
    end_idx = template_text.find(_RETRIEVAL_POLICY_END)
    if start_idx == -1 or end_idx == -1:
        logger.warning(
            "retrieval-policy markers not found in template; skipping install",
            extra={"event": "bootstrap.install_retrieval_policy.no_markers"},
        )
        return False
    policy_block = template_text[start_idx : end_idx + len(_RETRIEVAL_POLICY_END)]

    def _do_write() -> None:
        existing = path.read_text(encoding="utf-8") if path.exists() else ""

        s = existing.find(_RETRIEVAL_POLICY_START)
        e = existing.find(_RETRIEVAL_POLICY_END)

        if s != -1 and e != -1:
            # Block already present — replace in place.
            current_block = existing[s : e + len(_RETRIEVAL_POLICY_END)]
            if current_block == policy_block:
                logger.debug(
                    "retrieval-policy block already up to date",
                    extra={"event": "bootstrap.install_retrieval_policy", "changed": False},
                )
                return
            new_content = existing[:s] + policy_block + existing[e + len(_RETRIEVAL_POLICY_END):]
        else:
            # Not present — append after the using-selph block if present,
            # else at the end of the file.
            sep = "" if existing.endswith("\n\n") else ("\n" if existing.endswith("\n") else "\n\n")
            if existing == "":
                sep = ""
            new_content = existing + sep + policy_block
            if not new_content.endswith("\n"):
                new_content += "\n"

        _atomic_write_text(path, new_content)
        changed["value"] = True
        logger.info(
            "retrieval-policy block installed",
            extra={
                "event": "bootstrap.install_retrieval_policy",
                "changed": True,
                "path": str(path),
            },
        )

    _locked_write(path, _do_write)

    # Transitional bridge — best-effort slash-command self-update.
    # The user's installed `/using-selph` (`~/.claude/commands/using-selph.md`)
    # diverged from the canonical SKILL.md spec and there's no current
    # mechanism for an OLD slash command to call refresh_slash_command()
    # explicitly (since OLD versions don't know that function exists). Until
    # all live installs have migrated to a slash command that calls
    # refresh_slash_command directly as a step, we trigger it here as a side
    # effect: install_retrieval_policy_block is the first bootstrap helper
    # called by every returning-user flow, so OLD slash commands will pick
    # up the latest controller spec on their next /using-selph invocation.
    # Removable once telemetry confirms zero OLD installs remain.
    try:
        from ._credentials import hydrate_from_global_credentials
        from ._slash_command import refresh_slash_command
        creds = hydrate_from_global_credentials()
        api_url = (creds or {}).get("api_url")
        if api_url:
            refresh_slash_command(api_url)
    except Exception as _exc:  # noqa: BLE001 — best-effort, never blocks
        logger.debug(
            "install_retrieval_policy_block: slash-command refresh skipped",
            extra={
                "event": "bootstrap.install_retrieval_policy.refresh_skipped",
                "error_type": type(_exc).__name__,
            },
        )

    return changed["value"]
