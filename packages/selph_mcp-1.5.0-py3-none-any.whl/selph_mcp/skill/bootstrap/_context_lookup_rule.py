"""Install/update the skill-author-facing Selph context-lookup rule file.

Writes ``<workspace>/.claude/rules/selph-context-lookup.md`` from the
``templates/selph_context_lookup_rule.md`` template. Idempotent — if the
file is already at the current template content, no-op. If the file exists
but its content between the v1 markers diverged, the marker region is
rewritten in place (user prose outside the markers is preserved).

Delegates R-M-W logic to ``_rule_install_common.install_marker_rule``.
"""

from __future__ import annotations

from pathlib import Path

from ._rule_install_common import install_marker_rule

__all__ = ["install_context_lookup_rule"]

_RULE_FILENAME = "selph-context-lookup.md"
_RULE_TEMPLATE = "selph_context_lookup_rule.md"
_MARKER_ID = "context-lookup-rule"


def install_context_lookup_rule(workspace: Path) -> bool:
    """Install the Selph context-lookup rule file under .claude/rules/.

    Returns True if the file was created or its marker region was updated.

    The template is wrapped in HTML-comment markers; this function only
    rewrites the region between them so user-authored prose appended below
    survives a re-install.
    """
    return install_marker_rule(
        workspace=workspace,
        rule_filename=_RULE_FILENAME,
        template_relpath=_RULE_TEMPLATE,
        marker_id=_MARKER_ID,
    )
