<!-- selph:writeback-rule:v1 START -->
# Selph writeback rule

This rule governs how to write observations, corrections, and feedback back
to Selph from Claude Code sessions. It is installed by the `using-selph`
adapter and applies to every session where the `selph-remote` MCP server is
connected.

## Core principle

Never alter the graph in a way the user did not authorize. Every writeback
must reflect something the user said, did, or explicitly confirmed — not
something you inferred on their behalf.

## observe_session

Persists Layer 1 evidence and runs the full extraction pipeline (Phases 0–7).

**Correct signature:**
```
observe_session(
    text=…,
    observation_provenance=…,   # required: see provenance values below
    apply_session_ranker=…,     # True for user-turn observations; False for harness-authored
    idempotency_key=…,          # optional: pass on retries to attach to in-flight op
)
```

**Provenance values:**
- `user_stated` — the user said this directly
- `user_endorsed_summary` — summary the user confirmed as accurate
- `assistant_generated` — observation authored by the assistant (not user words)
- `file_derived` — extracted from a file the user provided
- `correction` — fixes a prior observation

**What was removed:** the `mode` and `store_raw_only` parameters no longer
exist server-side. Do not pass them. Full extraction always runs.

**Response:** `data.operation_id` and `data.raw_evidence_id`. Most harness
use cases are fire-and-forget. To track async progress, poll:
`GET /core/observe/operations/{operation_id}?user_id=<user_id>`
and inspect `public_state` through to `completed` or `failed`.

**Ambient capture already records conversation turns. Do not call
observe_session merely to mirror the chat transcript.** Call it explicitly
only when you want to flag a specific statement as particularly important
evidence: a stated preference, a project decision, or a correction to prior
understanding.

## correct

Compiles 1:1 to a kernel revise operation. Requires explicit user confirmation
per call — blanket pre-authorization is not sufficient.

If the needed `(action, target_type)` pair is not supported, surface the gap
to the user. Do not invent a workaround.

## recommendation_feedback

Fire-and-forget. Always send it when the user accepts, skips, modifies, or
defers a Selph recommendation. Pass the `feedback_event_key` from the
original recommendation response. This is how Selph's ranker learns.
<!-- selph:writeback-rule:v1 END -->
