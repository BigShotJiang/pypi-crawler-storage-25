<!-- selph:ambient-capture-rule:v1 START -->
# Selph ambient capture rule

## Ambient capture (Selph background hooks)

Three hooks are installed in this workspace's `.claude/settings.local.json`:

- **UserPromptSubmit** — captures each user prompt turn
- **Stop** — captures each assistant reply
- **SessionEnd** — flushes the session spool to Selph for memory extraction

These run silently via `selph-mcp-hook` and append turns to a local SQLite
spool (`.selph/state/session_spool.db`). Selph periodically extracts durable
memories from the spool (Layer 1 → Layer 2+).

## What this means in practice

- You do not need to manually call `observe_session` for routine conversation
  turns; ambient capture handles it automatically.
- Do call `observe_session` explicitly when you want to flag a specific
  statement as particularly important evidence (a stated preference, a project
  decision, a correction to prior understanding).
- If the user asks "is Selph recording this?" — yes, session turns are captured
  automatically. The user can disable it with:
  ```bash
  selph-mcp-bootstrap uninstall-hooks --workspace "<cwd>"
  ```
- If `selph-mcp-hook` is not found (wheel not installed), the hooks fail
  silently (`|| true`) — the session continues unaffected.
- To remove everything Selph added to this workspace (hooks, slash command,
  workspace state):
  ```bash
  selph-mcp-bootstrap uninstall-all --workspace "<cwd>"
  ```
  Adding `--purge` also removes credentials. See `flows/uninstall.md` for a
  full description of what each option removes.

## Flush triggers

Selph flushes the spool (whichever fires first):

- **20 user messages** since the last successful flush in the current session.
- **SessionEnd** — fires when Claude Code exits the session, so partial buffers
  are not stranded.
- **4-hour idle** since the last successful flush when the spool is non-empty
  — drains orphaned sessions.
- **Collective threshold** — the next flush in any session also drains
  oldest-pending turns from sessions that failed earlier flushes.

Debounce: a flush is skipped if the last successful flush was within the last
10 minutes AND the current session has not crossed the per-session threshold.
<!-- selph:ambient-capture-rule:v1 END -->
