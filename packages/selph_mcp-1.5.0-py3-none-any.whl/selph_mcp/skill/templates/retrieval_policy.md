# Retrieval policy (§5.7 of the MCP distribution plan)

This document is the canonical retrieval policy referenced by the
`using-selph` CLAUDE.md block. It governs how Claude Code interacts with
the Selph persona MCP during normal (non-onboarding) work.

## When to call Selph

Call the persona MCP whenever you need persona context that is not already
in the current Claude Code session transcript:

- About the user themselves (preferences, history, voice, current
  pursuits).
- About a person they know (a relationship, a colleague, a contact).
- About a project, pursuit, or decision they are working on.
- About a recent change in their world (yesterday's events, this week's
  pattern).

Do **not** call Selph for general world knowledge, code in the current
repo, or anything you can resolve from the active session.

## Tool selection

| You need… | Call |
|---|---|
| A short briefing or reply draft | `get_context(intent="briefing" or "reply_draft", depth="auto")` |
| A specific question answered | `ask_selph(question=…)` |
| A recent-changes drift list | `what_changed(since_cursor=…)` |
| A specific evidence record / citation | `find_evidence(ref_id=…)` |
| A summary card for one entity | `get_entity_card(entity_id=…)` |
| To install a role-bound bootstrap | `hire_for_role(role=…, purpose=…)` |
| To write back a session observation | `observe_session(text=…, observation_provenance=…, apply_session_ranker=…)` |
| To correct a memory or observation | `correct(payload=…)` |

`depth="auto"` is the default. Override only when you specifically need
`brief`, `targeted`, `insight`, or `evidence`.

## Reading the response envelope

Every read returns a `PersonaResponse` envelope. Always inspect:

- `meta.confidence` — float in [0, 1]. Below 0.3 ⇒ sparse-graph posture.
- `meta.evidence_count` — integer. 0 ⇒ sparse-graph posture.
- `meta.staleness_status` — `fresh`, `stale`, or `unknown`. Stale ⇒ flag
  it to the user; do not silently serve.
- `meta.degraded_from` — present when the depth router downgraded due to
  budget pressure. Mention it inline.
- `citations[]` — typed Citation objects. Source for every chip.
- `suggested_next_actions[]` — surface as proposal-first menu items
  whenever they would help the user.

## Sparse-graph posture

Trigger when `meta.confidence < 0.3` OR `meta.evidence_count == 0`.

The literal opening line is:

> "I don't know you well enough yet."

Never substitute a softer phrase. Then, in plain language, explain what
Selph has on this subject (count, freshness) and what would help (an
import, a recent conversation, a correction). Do not fabricate to fill
the gap.

## Caching

`.selph/cache/` is a local optimization, not source of truth. Rules:

- Cache reads keyed by the etag from `meta.etag`.
- On every session start, run `what_changed(since_cursor=…)` and purge
  any cache entries whose key matches an invalidation prefix.
- Never serve a cached read whose etag falls before an invalidation.
- A cache miss is fine — refetching is cheap.

## Revocation

A 401 from any persona call means the consumer was revoked. Stop calling.
Tell the user the harness was revoked and what to do (re-run
`/using-selph` to register a new consumer or wait for the operator).

## Ambient capture

Selph quietly observes this workspace's conversation turns — user prompts,
assistant replies, and tool invocations — and buffers them locally in the
**session spool** at `<workspace>/.selph/state/session_spool.db`. The
buffer is drained by **flushes**: each flush sends a batch of recent
turns to the Selph engine via `observe_session` for memory extraction.

The capture mechanism is a set of **ambient capture hooks** registered
in `.claude/settings.local.json` (`UserPromptSubmit`, `Stop`,
`SessionEnd` — installed by `selph-mcp-bootstrap install-hooks` in
Phase G). Nothing leaves the machine without going through the
registered engine endpoint and bearer token.

Flush triggers (whichever fires first):

- **20 user messages** since the last successful flush in the current
  session (`_USER_MSG_THRESHOLD` in
  `selph_mcp/skill/runtime/_session_spool.py`).
- **`SessionEnd`** — every flush also fires when Claude Code exits the
  session, so partial buffers are not stranded.
- **4-hour idle cron** since the last successful flush when the log is
  non-empty (`_IDLE_CRON_HOURS`) — drains orphaned sessions whose own
  triggers exhausted.
- **Collective threshold** across sessions — the next flush in any
  session also drains oldest-pending turns from sessions that failed
  earlier flushes or hit backoff.

Debounce: a flush is skipped if the last successful flush was within the
last 10 minutes AND the current session has not crossed the per-session
threshold since that flush.

To answer "what's the state of the spool / how many user turns until the
next flush" from inside a session, read `spool_meta` and
`session_turn_counter` in the spool DB; the gap to the next flush is
`20 - count_user_turns_since_flush(session_id, last_acked_turn_idx)`.

To disable ambient capture in this workspace:

```bash
selph-mcp-bootstrap uninstall-hooks --workspace "<cwd>"
```

To remove everything Selph added to this workspace (hooks, slash command,
and workspace state):

```bash
selph-mcp-bootstrap uninstall-all --workspace "<cwd>"
```

Adding `--purge` also removes credentials. See `flows/uninstall.md` for a
full description of what each option removes.

---

## Writeback

The retrieval policy and writeback policy share one rule: **never alter the
graph in a way the user did not authorize**. Specifically:

- `observe_session` always persists Layer 1 evidence and runs the full
  extraction pipeline (Phases 0–7). The `mode`/`store_raw_only` option has
  been removed — there is no fast-path that skips extraction. Use
  `observation_provenance` to declare the evidence kind (`user_stated`,
  `user_endorsed_summary`, `assistant_generated`, `file_derived`,
  `correction`); set `apply_session_ranker=False` for harness-authored
  observations that should bypass conversation-turn ranking. Pass an
  `idempotency_key` on retries so the server attaches to the in-flight
  operation instead of re-running ingestion.

  The call is processed asynchronously. The MCP envelope `data` field
  contains `operation_id` (UUID) and `raw_evidence_id` (UUID). Most
  harness use cases are fire-and-forget; if you need to confirm completion,
  poll `GET /core/observe/operations/{operation_id}?user_id=<user_id>` and
  check `public_state` (`queued` → `evidence_recorded` → `interpreting` →
  `linking` → `persisting` → `completed` or `failed`).

- `correct` requires explicit user confirmation per call (not blanket
  pre-authorization).
- `recommendation_feedback` is fire-and-forget — but always send it when
  the user accepts/skips/modifies/defers a recommendation, so the heuristic
  ranker can learn.
