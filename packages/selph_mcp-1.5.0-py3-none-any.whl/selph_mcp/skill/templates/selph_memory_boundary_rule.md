<!-- selph:memory-boundary-rule:v1 START -->
# Selph memory boundary rule

This rule defines what belongs in Selph (durable) versus what stays local to
this workspace (operational). It is installed by the `using-selph` adapter.

## The key test

Ask: "If I deleted this workspace and started fresh, would the user want this
information to carry over?"

- **Yes** → durable. Send to Selph via `observe_session`.
- **No** → operational. Keep it local (task files, drafts, scratch notes).

## What is durable (goes to Selph)

- Stated preferences ("I always want unit tests for new functions")
- Relationships and people context ("Julian is my co-founder")
- Projects and pursuits ("I'm building a REST API for this startup")
- Decisions and their reasoning
- Skills, roles, affiliations
- Corrections to prior understanding

## What is operational (stays local)

- Active task lists and in-progress drafts
- Scratch notes and transient reminders
- In-session context that only matters for this session
- Anything the user said is temporary or disposable

## Anti-patterns

**Do not** call `observe_session` to mirror the chat transcript — ambient
capture handles routine conversation turns automatically.

**Do not** persist operational working state to Selph as if it were durable
identity context. A shopping list is not a preference.

**Do not** infer durable context from a single mention. One passing reference
to a restaurant is not a food preference. Corroboration comes from the graph;
you are not the arbiter.

For extended examples and the durable-vs-operational distinction applied to
specific scenarios, see `~/.claude/commands/using-selph/reference/memory-boundary.md`.
<!-- selph:memory-boundary-rule:v1 END -->
