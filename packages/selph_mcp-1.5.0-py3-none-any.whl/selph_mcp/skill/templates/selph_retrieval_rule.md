<!-- selph:retrieval-rule:v1 START -->
# Selph retrieval rule

This rule governs when and how to call Selph in every Claude Code session
where the `selph-remote` MCP server is connected. It is installed by the
`using-selph` adapter and is the runtime counterpart to the skill-author
rule in `.claude/rules/selph-context-lookup.md`.

## When to call Selph

Call the persona MCP whenever you need persona context that is not already
in the current session transcript:

- About the user themselves (preferences, history, voice, current pursuits).
- About a person they know (a relationship, a colleague, a contact).
- About a project, pursuit, or decision they are working on.
- About a recent change in their world (yesterday's events, this week's pattern).

Do **not** call Selph for general world knowledge, code in the current repo,
or anything you can resolve from the active session.

## Tool selection

| You need… | Call |
|---|---|
| A short briefing or reply draft | `get_context(intent="briefing", depth="auto")` |
| A specific question answered | `ask_selph(question=…)` |
| A recent-changes drift list | `what_changed(since_cursor=…)` |
| A specific evidence record | `find_evidence(ref_id=…)` |
| A summary card for one entity | `get_entity_card(entity_id=…)` |
| To install a role-bound bootstrap | `hire_for_role(role=…, purpose=…)` |
| To write back a session observation | `observe_session(text=…, observation_provenance=…, apply_session_ranker=…)` |
| To correct a memory or observation | `correct(payload=…)` |

`depth="auto"` is the default. Override only when you specifically need
`brief`, `targeted`, `insight`, or `evidence`.

## Reading the response envelope

Every read returns a `PersonaResponse` envelope. Always inspect:

- `meta.confidence` — float in [0, 1]. Below 0.3 ⇒ sparse-graph posture.
- `meta.evidence_count` — integer. 0 ⇒ sparse-graph posture.
- `meta.staleness_status` — `fresh`, `stale`, or `unknown`. Stale ⇒ flag to
  the user; do not silently serve.
- `meta.degraded_from` — present when the depth router downgraded due to budget
  pressure. Mention it inline.
- `citations[]` — typed Citation objects. Source for every evidence chip.
- `suggested_next_actions[]` — surface as proposal-first menu items when they
  would help the user.

## Sparse-graph posture

Trigger when `meta.confidence < 0.3` OR `meta.evidence_count == 0`.

The literal opening line is:

> "I don't know you well enough yet."

Never substitute a softer phrase. Then explain in plain language what Selph
has on this subject (count, freshness) and what would help (an import, a
recent conversation, a correction). Do not fabricate to fill the gap.

## Evidence-chip contract

Every interpretive statement you echo back must carry at least one chip:

```
[ref_id · layer · captured_at]
```

`ref_id` is the canonical Selph ID (`MEM-…`, `ENT-…`, `HUB-…`, `OBS-…`).
`layer` is the integer 1–4. `captured_at` is the ISO-8601 timestamp from
the citation. No chip → do not make the claim.

## Caching

`.selph/cache/` is a local optimization, not source of truth. Rules:

- Cache identity is the Selph-returned `meta.query_fingerprint` (stable,
  server-computed). Use `query_fingerprint` as the authoritative key.
- Before every cache read, run `what_changed(since_cursor=…)` and purge any
  cache entries whose stored `dependency_keys` intersect with the returned
  `invalidated_keys` set.
- Memoization keys are lookup hints only — they never participate in durable
  identity or coherence.
- A cache miss is fine — refetching is cheap.

## Revocation

A 401 from any persona call means the consumer was revoked. Stop calling.
Tell the user the harness was revoked and what to do (re-run `/using-selph`
to register a new consumer or wait for the operator).
<!-- selph:retrieval-rule:v1 END -->
