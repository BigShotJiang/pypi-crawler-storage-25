"""Argparse wiring + ``main()`` entry point for selph-mcp-bootstrap.

Registers all subcommands from the sibling modules and the existing
register/whoami/doctor handlers migrated from the pre-split ``cli.py``.

Exit codes
----------
- 0 — success
- 1 — operational error (network, file I/O, contract mismatch)
- 2 — user error (missing args, invalid input)
"""

from __future__ import annotations

import argparse
import sys

from selph_mcp._log import configure_logging

# ── Rule-file install subcommands ─────────────────────────────────────────────
from ._rule_subcommands import (
    _cmd_install_retrieval_rule,
    _cmd_install_writeback_rule,
    _cmd_install_memory_boundary_rule,
    _cmd_install_ambient_capture_rule,
)

# ── New Phase C/D subcommand modules ─────────────────────────────────────────
from ._state_subcommands import (
    _cmd_append_claude_md,
    _cmd_detect_state,
    _cmd_hydrate_global,
    _cmd_hydrate_legacy,
    _cmd_install_context_lookup_rule,
    _cmd_install_hooks,
    _cmd_install_policy_block,
    _cmd_record_onboarding,
    _cmd_reconcile_onboarding,
    _cmd_session_do_flush,
    _cmd_session_flush,
    _cmd_uninstall_all,
    _cmd_uninstall_hooks,
    _cmd_update_etag,
    _cmd_verify_hooks,
    _cmd_write_credentials,
)
from ._workflow_subcommands import (
    _cmd_install_workflow,
    _cmd_migrate_workflow,
    _cmd_scan_workflows,
)
from ._install_subcommands import (
    _cmd_install_skill_tree,
    _cmd_install_slash_command,
    _cmd_refresh_slash_command,
    _cmd_whoami_remote,
    _cmd_write_mcp_entry,
)
from ._version_subcommands import _cmd_self_check, _cmd_version
from ._setup_subcommand import _cmd_setup
from ._feedback_subcommands import _cmd_feedback, _cmd_retry_reports

# ── Legacy handlers (register, whoami, doctor) — imported from the original
#    cli.py which is kept as _legacy.py for backward compat during transition.
from ._legacy import _cmd_doctor, _cmd_register, _cmd_whoami
from ._defaults import DEFAULT_API_URL as _DEFAULT_API_URL

_WORKSPACE_ARG_KWARGS = {
    "default": ".",
    "help": "Workspace root directory (default: current directory).",
}


def _build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="selph-mcp-bootstrap",
        description=(
            "Register / inspect / verify the local selph-mcp wheel "
            "credentials, and drive workspace onboarding helpers."
        ),
    )
    sub = p.add_subparsers(dest="cmd", required=True)

    # ── setup (one-shot interactive Q&A) ──────────────────────────────────────
    setup = sub.add_parser(
        "setup",
        help="One-shot interactive onboarding (register + slash-command + MCP entry).",
        description=(
            "Recommended first command after `pipx install selph-mcp`. Prompts "
            "for your user_id and api_key, then wires up everything in one go."
        ),
    )
    setup.add_argument("--user-id", default=None,
                       help="Skip prompt by passing this (or set SELPH_USER_ID).")
    setup.add_argument("--api-key", default=None,
                       help="Skip prompt by passing this (or set SELPH_API_KEY).")
    setup.add_argument("--api-url", default=None,
                       help=f"Override the Selph endpoint (default: {_DEFAULT_API_URL}).")
    setup.set_defaults(func=_cmd_setup)

    # ── register ──────────────────────────────────────────────────────────────
    reg = sub.add_parser(
        "register",
        help="Create an MCP consumer + save its bearer token locally.",
    )
    reg.add_argument("--user-id", default=None,
                     help="Selph user_id (e.g. U001). Prompted interactively if omitted.")
    reg.add_argument("--api-url", default=None,
                     help=f"Engine base URL (default: SELPH_API_URL or {_DEFAULT_API_URL}).")
    reg.add_argument("--api-key", default=None,
                     help="Selph API key (or set SELPH_API_KEY). Prompted interactively if omitted.")
    reg.add_argument("--harness-id", default=None)
    reg.add_argument("--display-name", default=None)
    reg.add_argument("--scopes", default=None)
    reg.add_argument("--sensitivity-ceiling", default=None,
                     choices=["normal", "sensitive", "restricted"])
    reg.add_argument("--budget-tier", default=None,
                     choices=["cheap", "standard", "expensive"])
    reg.add_argument("--persist-api-key", action="store_true")
    reg.add_argument("--transport", default="http", choices=["stdio", "http"],
                     help="Print snippet for stdio or http transport (default: http).")
    reg.set_defaults(func=_cmd_register)

    # ── whoami (local) ────────────────────────────────────────────────────────
    who = sub.add_parser("whoami",
                         help="Print the locally-stored consumer identity (no network).")
    who.set_defaults(func=_cmd_whoami)

    # ── doctor ────────────────────────────────────────────────────────────────
    doc = sub.add_parser("doctor",
                         help="Verify creds parse, engine reachable, contract version matches.")
    doc.add_argument("--api-url", default=None)
    doc.set_defaults(func=_cmd_doctor)

    # ── detect-state ──────────────────────────────────────────────────────────
    ds = sub.add_parser("detect-state", help="Return workspace State as JSON.")
    ds.add_argument("--workspace", **_WORKSPACE_ARG_KWARGS)
    ds.set_defaults(func=_cmd_detect_state)

    # ── hydrate-global ────────────────────────────────────────────────────────
    hg = sub.add_parser("hydrate-global", help="Load global credentials (JSON or null).")
    hg.set_defaults(func=_cmd_hydrate_global)

    # ── hydrate-legacy ────────────────────────────────────────────────────────
    hl = sub.add_parser("hydrate-legacy",
                        help="Load legacy ~/.claude.json credentials (v1 compat).")
    hl.set_defaults(func=_cmd_hydrate_legacy)

    # ── write-mcp-entry (Phase D) ─────────────────────────────────────────────
    wme = sub.add_parser("write-mcp-entry",
                         help="Write selph-remote HTTP MCP entry to ~/.claude.json.")
    wme.add_argument("--remote-url", default=None,
                     help=f"Selph API base URL (default: credentials file or {_DEFAULT_API_URL}).")
    wme.add_argument("--workspace", default=None,
                     help="Workspace root for migration audit (optional).")
    wme.set_defaults(func=_cmd_write_mcp_entry)

    # ── install-policy-block ──────────────────────────────────────────────────
    ipb = sub.add_parser("install-policy-block",
                         help="Install/refresh the retrieval policy block in CLAUDE.md.")
    ipb.add_argument("--workspace", **_WORKSPACE_ARG_KWARGS)
    ipb.set_defaults(func=_cmd_install_policy_block)

    # ── install-context-lookup-rule ──────────────────────────────────────────
    iclr = sub.add_parser(
        "install-context-lookup-rule",
        help=(
            "Install/refresh the skill-author Selph context-lookup rule at "
            ".claude/rules/selph-context-lookup.md."
        ),
    )
    iclr.add_argument("--workspace", **_WORKSPACE_ARG_KWARGS)
    iclr.set_defaults(func=_cmd_install_context_lookup_rule)

    # ── install-retrieval-rule ────────────────────────────────────────────────
    irr = sub.add_parser(
        "install-retrieval-rule",
        help=(
            "Install/refresh .claude/rules/selph-retrieval-rule.md — "
            "when/how to call Selph, tool selection, envelope reading, "
            "evidence chips, caching, revocation."
        ),
    )
    irr.add_argument("--workspace", **_WORKSPACE_ARG_KWARGS)
    irr.set_defaults(func=_cmd_install_retrieval_rule)

    # ── install-writeback-rule ────────────────────────────────────────────────
    iwr = sub.add_parser(
        "install-writeback-rule",
        help=(
            "Install/refresh .claude/rules/selph-writeback-rule.md — "
            "observe_session correct signature, correct, recommendation_feedback."
        ),
    )
    iwr.add_argument("--workspace", **_WORKSPACE_ARG_KWARGS)
    iwr.set_defaults(func=_cmd_install_writeback_rule)

    # ── install-memory-boundary-rule ──────────────────────────────────────────
    imbr = sub.add_parser(
        "install-memory-boundary-rule",
        help=(
            "Install/refresh .claude/rules/selph-memory-boundary-rule.md — "
            "durable vs operational memory boundary."
        ),
    )
    imbr.add_argument("--workspace", **_WORKSPACE_ARG_KWARGS)
    imbr.set_defaults(func=_cmd_install_memory_boundary_rule)

    # ── install-ambient-capture-rule ──────────────────────────────────────────
    iacr = sub.add_parser(
        "install-ambient-capture-rule",
        help=(
            "Install/refresh .claude/rules/selph-ambient-capture-rule.md — "
            "background hooks, spool, flush triggers, how to disable."
        ),
    )
    iacr.add_argument("--workspace", **_WORKSPACE_ARG_KWARGS)
    iacr.set_defaults(func=_cmd_install_ambient_capture_rule)

    # ── append-claude-md ──────────────────────────────────────────────────────
    acm = sub.add_parser("append-claude-md",
                         help="Append the Selph CLAUDE.md block (idempotent).")
    acm.add_argument("--workspace", **_WORKSPACE_ARG_KWARGS)
    acm.set_defaults(func=_cmd_append_claude_md)

    # ── session-flush (Phase D §13a item #7) ──────────────────────────────────
    sf = sub.add_parser(
        "session-flush",
        help=(
            "Build and print pending session turns payload to stdout "
            "(bypasses debounce/threshold — useful for debugging)."
        ),
    )
    sf.add_argument("--workspace", **_WORKSPACE_ARG_KWARGS)
    sf.add_argument("--session-id", required=True,
                    help="Session UUID to flush.")
    sf.add_argument("--user-id", required=True,
                    help="Selph user_id (e.g. U001).")
    sf.set_defaults(func=_cmd_session_flush)

    # ── session-do-flush (Phase G) — actually POSTs to the server ─────────────
    sdf = sub.add_parser(
        "session-do-flush",
        help=(
            "POST pending session turns to the server (Bearer auth). "
            "Used by the background subprocess spawned on UserPromptSubmit "
            "threshold triggers. Always exits 0."
        ),
    )
    sdf.add_argument("--workspace", **_WORKSPACE_ARG_KWARGS)
    sdf.add_argument("--session-id", required=True,
                     help="Session UUID to flush.")
    sdf.add_argument("--user-id", required=True,
                     help="Selph user_id (e.g. U001).")
    sdf.set_defaults(func=_cmd_session_do_flush)

    # ── write-credentials ─────────────────────────────────────────────────────
    wc = sub.add_parser("write-credentials",
                        help="Write per-workspace credentials projection.")
    wc.add_argument("--workspace", **_WORKSPACE_ARG_KWARGS)
    wc.add_argument("--consumer-id", required=True)
    wc.add_argument("--user-id", required=True)
    wc.add_argument("--api-url", required=True)
    wc.add_argument("--api-key", default="")
    wc.add_argument(
        "--bearer-token",
        default="",
        help=(
            "Bearer token for ambient capture HTTP flushes. "
            "Required for session hooks to POST turns to the engine. "
            "Value is written with 0600 permissions and never logged."
        ),
    )
    wc.set_defaults(func=_cmd_write_credentials)

    # ── record-onboarding ─────────────────────────────────────────────────────
    ro = sub.add_parser("record-onboarding",
                        help="Persist onboarding completion to state.json.")
    ro.add_argument("--workspace", **_WORKSPACE_ARG_KWARGS)
    ro.add_argument("--consumer-id", required=True)
    ro.add_argument("--user-id", required=True)
    ro.add_argument("--etag-cursor", required=True, type=int)
    ro.add_argument("--installed-workflows", default="[]",
                    help="JSON array of installed workflow IDs.")
    ro.set_defaults(func=_cmd_record_onboarding)

    # ── update-etag ───────────────────────────────────────────────────────────
    ue = sub.add_parser("update-etag", help="Update the etag cursor in onboarding state.")
    ue.add_argument("--workspace", **_WORKSPACE_ARG_KWARGS)
    ue.add_argument("--cursor", required=True, type=int)
    ue.set_defaults(func=_cmd_update_etag)

    # ── install-workflow ──────────────────────────────────────────────────────
    iw = sub.add_parser("install-workflow", help="Install a workflow SKILL.md.")
    iw.add_argument("--workspace", **_WORKSPACE_ARG_KWARGS)
    iw.add_argument("--workflow-id", required=True)
    iw.add_argument("--manifest", default=None,
                    help="JSON manifest: @path.json, - (stdin), or inline JSON.")
    iw.set_defaults(func=_cmd_install_workflow)

    # ── migrate-workflow ──────────────────────────────────────────────────────
    mw = sub.add_parser("migrate-workflow", help="Migrate a workflow SKILL.md in place.")
    mw.add_argument("--workspace", **_WORKSPACE_ARG_KWARGS)
    mw.add_argument("--workflow-id", required=True)
    mw.add_argument("--current-template-version", required=True, type=int)
    mw.set_defaults(func=_cmd_migrate_workflow)

    # ── scan-workflows ────────────────────────────────────────────────────────
    sw = sub.add_parser("scan-workflows", help="Scan workspace workflows; return ScanReport JSON.")
    sw.add_argument("--workspace", **_WORKSPACE_ARG_KWARGS)
    sw.set_defaults(func=_cmd_scan_workflows)

    # ── refresh-slash-command ─────────────────────────────────────────────────
    rsc = sub.add_parser("refresh-slash-command",
                         help="Fetch latest SKILL.md from server and update ~/.claude/commands/.")
    rsc.add_argument("--api-url", default=None,
                     help=f"Selph API base URL (default: {_DEFAULT_API_URL}).")
    rsc.set_defaults(func=_cmd_refresh_slash_command)

    # ── version ───────────────────────────────────────────────────────────────
    ver = sub.add_parser("version",
                         help="Print installed wheel version and persona_contract_version.")
    ver.set_defaults(func=_cmd_version)

    # ── whoami-remote ─────────────────────────────────────────────────────────
    wr = sub.add_parser("whoami-remote",
                        help="Fetch Whoami from server; returns JSON.")
    wr.add_argument("--api-url", default=None,
                    help=f"Selph API base URL (default: {_DEFAULT_API_URL}).")
    wr.add_argument("--bearer-token", default=None,
                    help="Override bearer token (default: read from credentials file).")
    wr.add_argument("--consumer-id", default=None,
                    help="Override consumer ID (default: read from credentials file).")
    wr.set_defaults(func=_cmd_whoami_remote)

    # ── reconcile-onboarding ──────────────────────────────────────────────────
    reconcile = sub.add_parser(
        "reconcile-onboarding",
        help="Reconcile onboarding.json against server Whoami response.",
    )
    reconcile.add_argument("--workspace", **_WORKSPACE_ARG_KWARGS)
    reconcile.add_argument("--whoami", required=True,
                           help="Whoami JSON: @path.json, - (stdin), or inline JSON.")
    reconcile.set_defaults(func=_cmd_reconcile_onboarding)

    # ── install-slash-command (Phase E option 1) ──────────────────────────────
    isc = sub.add_parser(
        "install-slash-command",
        help="Fetch SKILL.md from server and write to ~/.claude/commands/using-selph.md.",
    )
    isc.add_argument("--api-url", default=None,
                     help=f"Selph API base URL (default: {_DEFAULT_API_URL}).")
    isc.set_defaults(func=_cmd_install_slash_command)

    # ── install-skill-tree (modular sub-files for the slim controller) ────────
    ist = sub.add_parser(
        "install-skill-tree",
        help=(
            "Restore the modular sub-tree under "
            "~/.claude/commands/using-selph/{flows,reference}/. "
            "Idempotent: missing files are written from the wheel-bundled "
            "fallback; existing files are preserved unless --force."
        ),
    )
    ist.add_argument("--api-url", default=None,
                     help=(
                         "Optional Selph API base URL. When provided, prefer "
                         "the server-hosted copy over the wheel bundle "
                         f"(default: {_DEFAULT_API_URL})."
                     ))
    ist.add_argument("--force", action="store_true",
                     help="Overwrite existing files that differ from canonical.")
    ist.set_defaults(func=_cmd_install_skill_tree)

    # ── _self-check ───────────────────────────────────────────────────────────
    sc = sub.add_parser(
        "_self-check",
        help="Round-trip fixture check for State/OnboardingState/ScanReport.",
    )
    sc.set_defaults(func=_cmd_self_check)

    # ── feedback ──────────────────────────────────────────────────────────────
    fb = sub.add_parser(
        "feedback",
        help=(
            'Record explicit user feedback and flush to server. '
            'Usage: selph-mcp-bootstrap feedback "<your note>"'
        ),
    )
    fb.add_argument(
        "note",
        help="Free-text feedback (e.g. \"the persona thinks I work at Acme, that's wrong\").",
    )
    fb.set_defaults(func=_cmd_feedback)

    # ── retry-reports ─────────────────────────────────────────────────────────
    rr = sub.add_parser(
        "retry-reports",
        help=(
            "Show and replay any bridge-CLI retryable entries. "
            "In v1 this is a no-op (Remote-MCP retries happen in conversation)."
        ),
    )
    rr.set_defaults(func=_cmd_retry_reports)

    # ── install-hooks (Phase G ambient capture) ───────────────────────────────
    ih = sub.add_parser(
        "install-hooks",
        help="Install ambient capture hooks into <workspace>/.claude/settings.local.json.",
    )
    ih.add_argument("--workspace", **_WORKSPACE_ARG_KWARGS)
    ih.set_defaults(func=_cmd_install_hooks)

    # ── uninstall-hooks ───────────────────────────────────────────────────────
    uh = sub.add_parser(
        "uninstall-hooks",
        help="Remove Selph-owned hook entries from settings.local.json.",
    )
    uh.add_argument("--workspace", **_WORKSPACE_ARG_KWARGS)
    uh.set_defaults(func=_cmd_uninstall_hooks)

    # ── uninstall-all ─────────────────────────────────────────────────────────
    ua = sub.add_parser(
        "uninstall-all",
        help=(
            "Remove hooks, slash command, and onboarding state. "
            "Add --purge to also remove credentials."
        ),
    )
    ua.add_argument("--workspace", **_WORKSPACE_ARG_KWARGS)
    ua.add_argument(
        "--purge",
        action="store_true",
        help="Also remove credentials.json from the workspace.",
    )
    ua.set_defaults(func=_cmd_uninstall_all)

    # ── verify-hooks ──────────────────────────────────────────────────────────
    vh = sub.add_parser(
        "verify-hooks",
        help="Return JSON indicating whether all three hook events are installed.",
    )
    vh.add_argument("--workspace", **_WORKSPACE_ARG_KWARGS)
    vh.set_defaults(func=_cmd_verify_hooks)

    return p


def main() -> None:
    """Console-script entry point — referenced by pyproject.toml."""
    configure_logging()
    parser = _build_parser()
    args = parser.parse_args()
    rc = args.func(args)
    sys.exit(int(rc))
