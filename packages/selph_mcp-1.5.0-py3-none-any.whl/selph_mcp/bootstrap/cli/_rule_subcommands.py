"""Rule-file install subcommand handlers for selph-mcp-bootstrap.

Subcommands (each mirrors the pattern of _cmd_install_context_lookup_rule
in _state_subcommands.py):

- install-retrieval-rule
- install-writeback-rule
- install-memory-boundary-rule
- install-ambient-capture-rule
"""

from __future__ import annotations

import argparse
import logging
from pathlib import Path

from selph_mcp._log import get_logger, log_event
from ._envelope import err_envelope, ok_envelope

_log = get_logger("selph_mcp.bootstrap.cli")


# ---------------------------------------------------------------------------
# install-retrieval-rule
# ---------------------------------------------------------------------------

def _cmd_install_retrieval_rule(args: argparse.Namespace) -> int:
    """install-retrieval-rule --workspace PATH

    Installs (or refreshes) ``.claude/rules/selph-retrieval-rule.md`` —
    the runtime rule governing when and how to call Selph, tool selection,
    envelope reading, evidence chips, caching, and revocation.
    """
    workspace = Path(getattr(args, "workspace", ".")).resolve()
    log_event(_log, logging.INFO, "cli.install_retrieval_rule.entry",
              workspace=str(workspace))
    try:
        from selph_mcp.skill.bootstrap import (
            install_retrieval_rule,
            resolve_workspace_root,
        )
        ws = resolve_workspace_root(str(workspace))
        changed = install_retrieval_rule(ws)
        ok_envelope({"workspace": str(ws), "changed": changed})
        log_event(_log, logging.INFO, "cli.install_retrieval_rule.complete",
                  changed=changed)
        return 0
    except Exception as exc:  # noqa: BLE001
        log_event(_log, logging.ERROR, "cli.install_retrieval_rule.error",
                  error_type=type(exc).__name__, error=str(exc)[:200])
        return err_envelope(exc)


# ---------------------------------------------------------------------------
# install-writeback-rule
# ---------------------------------------------------------------------------

def _cmd_install_writeback_rule(args: argparse.Namespace) -> int:
    """install-writeback-rule --workspace PATH

    Installs (or refreshes) ``.claude/rules/selph-writeback-rule.md`` —
    the rule governing observe_session (correct signature, provenance values),
    correct, and recommendation_feedback. Fixes the stale store_raw_only
    reference in legacy v1 CLAUDE.md blocks.
    """
    workspace = Path(getattr(args, "workspace", ".")).resolve()
    log_event(_log, logging.INFO, "cli.install_writeback_rule.entry",
              workspace=str(workspace))
    try:
        from selph_mcp.skill.bootstrap import (
            install_writeback_rule,
            resolve_workspace_root,
        )
        ws = resolve_workspace_root(str(workspace))
        changed = install_writeback_rule(ws)
        ok_envelope({"workspace": str(ws), "changed": changed})
        log_event(_log, logging.INFO, "cli.install_writeback_rule.complete",
                  changed=changed)
        return 0
    except Exception as exc:  # noqa: BLE001
        log_event(_log, logging.ERROR, "cli.install_writeback_rule.error",
                  error_type=type(exc).__name__, error=str(exc)[:200])
        return err_envelope(exc)


# ---------------------------------------------------------------------------
# install-memory-boundary-rule
# ---------------------------------------------------------------------------

def _cmd_install_memory_boundary_rule(args: argparse.Namespace) -> int:
    """install-memory-boundary-rule --workspace PATH

    Installs (or refreshes) ``.claude/rules/selph-memory-boundary-rule.md``
    — the rule governing durable vs operational memory (what goes to Selph vs
    what stays local in this workspace).
    """
    workspace = Path(getattr(args, "workspace", ".")).resolve()
    log_event(_log, logging.INFO, "cli.install_memory_boundary_rule.entry",
              workspace=str(workspace))
    try:
        from selph_mcp.skill.bootstrap import (
            install_memory_boundary_rule,
            resolve_workspace_root,
        )
        ws = resolve_workspace_root(str(workspace))
        changed = install_memory_boundary_rule(ws)
        ok_envelope({"workspace": str(ws), "changed": changed})
        log_event(_log, logging.INFO, "cli.install_memory_boundary_rule.complete",
                  changed=changed)
        return 0
    except Exception as exc:  # noqa: BLE001
        log_event(_log, logging.ERROR, "cli.install_memory_boundary_rule.error",
                  error_type=type(exc).__name__, error=str(exc)[:200])
        return err_envelope(exc)


# ---------------------------------------------------------------------------
# install-ambient-capture-rule
# ---------------------------------------------------------------------------

def _cmd_install_ambient_capture_rule(args: argparse.Namespace) -> int:
    """install-ambient-capture-rule --workspace PATH

    Installs (or refreshes) ``.claude/rules/selph-ambient-capture-rule.md``
    — the rule explaining the three background hooks, what they do, the spool
    location, flush triggers, and how to disable ambient capture.
    """
    workspace = Path(getattr(args, "workspace", ".")).resolve()
    log_event(_log, logging.INFO, "cli.install_ambient_capture_rule.entry",
              workspace=str(workspace))
    try:
        from selph_mcp.skill.bootstrap import (
            install_ambient_capture_rule,
            resolve_workspace_root,
        )
        ws = resolve_workspace_root(str(workspace))
        changed = install_ambient_capture_rule(ws)
        ok_envelope({"workspace": str(ws), "changed": changed})
        log_event(_log, logging.INFO, "cli.install_ambient_capture_rule.complete",
                  changed=changed)
        return 0
    except Exception as exc:  # noqa: BLE001
        log_event(_log, logging.ERROR, "cli.install_ambient_capture_rule.error",
                  error_type=type(exc).__name__, error=str(exc)[:200])
        return err_envelope(exc)
