"""Visualization utilities for Nuke script node graphs.

Two renderers are provided:

TextTree
    Renders the script as a human-readable ASCII tree showing each node's
    class, name, and optional knob values.

DotExporter
    Exports the node connectivity as a Graphviz DOT file. If the optional
    ``graphviz`` Python package is installed, can also render to PNG/SVG.

Usage::

    from nkparser import Script, TextTree, DotExporter

    script = Script.from_file("comp.nk")

    # Print text tree
    print(TextTree(script).render(show_knobs=True))

    # Export DOT graph
    dot_src = DotExporter(script).export("graph.dot")
"""

from __future__ import annotations

import os
import subprocess
from typing import Optional
from pathlib import Path

from .models import Node, Script, GroupNode

# ---------------------------------------------------------------------------
# Text tree renderer
# ---------------------------------------------------------------------------


class TextTree:
    """Render a Script as a Unicode/ASCII node tree."""

    BRANCH = "├── "
    LAST_BRANCH = "└── "
    PIPE = "│   "
    SPACE = "    "

    def __init__(self, script: Script) -> None:
        self._script = script

    def render(self, show_knobs: bool = False, max_depth: int = 99) -> str:
        """Return a multi-line string tree representation of the script.

        Args:
            show_knobs: If True, each node's knobs are printed beneath it.
            max_depth: Maximum nesting depth to display.
        """
        lines: list[str] = []
        header_parts: list[str] = []
        if self._script.nuke_version:
            header_parts.append(f"version {self._script.nuke_version}")
        if self._script.shebang:
            header_parts.append(self._script.shebang)
        lines.append(
            f"Script ({', '.join(header_parts) if header_parts else 'unknown version'})")

        nodes = self._script.nodes
        for i, node in enumerate(nodes):
            is_last = i == len(nodes) - 1
            self._render_node(node, prefix="", is_last=is_last, depth=0,
                              show_knobs=show_knobs, max_depth=max_depth, lines=lines)
        return "\n".join(lines)

    def _render_node(
        self,
        node: Node,
        prefix: str,
        is_last: bool,
        depth: int,
        show_knobs: bool,
        max_depth: int,
        lines: list[str],
    ) -> None:
        connector = self.LAST_BRANCH if is_last else self.BRANCH
        label = f"{node.node_class}"
        if node.name:
            label += f"  [{node.name}]"
        if node._inputs:
            input_names = [
                (n.name or n.node_class) if n else "?"
                for n in node._inputs
            ]
            label += f"  ← {', '.join(input_names)}"
        lines.append(f"{prefix}{connector}{label}")

        extension = self.SPACE if is_last else self.PIPE

        if show_knobs and depth < max_depth:
            knob_lines = [
                k for k in node.knobs if k.name not in ("name", "xpos", "ypos")
            ]
            for j, knob in enumerate(knob_lines):
                is_last_knob = j == len(knob_lines) - 1 and not (
                    isinstance(node, GroupNode) and node.children
                )
                knob_connector = self.LAST_BRANCH if is_last_knob else self.BRANCH
                val_preview = knob.value.raw[:50].replace("\n", "\\n")
                if len(knob.value.raw) > 50:
                    val_preview += "..."
                lines.append(
                    f"{prefix}{extension}{knob_connector}{knob.name}: {val_preview}")

        if isinstance(node, GroupNode) and depth < max_depth:
            children = node.children
            for k, child in enumerate(children):
                child_is_last = k == len(children) - 1
                self._render_node(
                    child,
                    prefix=prefix + extension,
                    is_last=child_is_last,
                    depth=depth + 1,
                    show_knobs=show_knobs,
                    max_depth=max_depth,
                    lines=lines,
                )


# ---------------------------------------------------------------------------
# DOT / Graphviz exporter
# ---------------------------------------------------------------------------


class DotExporter:
    """Export a Script's node graph to Graphviz DOT format."""

    def __init__(self, script: Script) -> None:
        self._script = script

    def export(
        self,
        output_path: Optional[str] = None,
        *,
        render: bool = False,
        render_format: str = "png",
        dot_command: Optional[str] = None,
    ) -> str:
        """Generate DOT source and optionally write to file.

        Args:
            output_path: If given, write DOT source to this path.
            render: If True, also render to an image (e.g. PNG) using a
                Graphviz ``dot`` executable. The rendered file is placed
                alongside *output_path* using the DOT file stem.
            render_format: Image format for rendering (default "png").
            dot_command: Optional Graphviz ``dot`` executable path or command
                name. Defaults to the ``NKPARSER_DOT`` environment variable,
                then ``dot``.

        Returns:
            The DOT source string.
        """
        lines: list[str] = [
            "digraph nk {",
            '  rankdir=TB;',
            '  node [shape=box fontname="Courier" style="filled" fillcolor="#f5f5f5"];',
            '  edge [color="#555555"];',
        ]

        # Node declarations
        for node in self._script.all_nodes():
            node_id = self._node_id(node)
            label = self._node_label(node)
            color = self._node_color(node.node_class)
            lines.append(f'  {node_id} [label="{label}" fillcolor="{color}"];')

        # Edges
        for node in self._script.all_nodes():
            for i, inp in enumerate(node.inputs):
                if inp is not None:
                    src_id = self._node_id(inp)
                    dst_id = self._node_id(node)
                    if len(node.inputs) > 1:
                        lines.append(f'  {src_id} -> {dst_id} [label="{i}"];')
                    else:
                        lines.append(f'  {src_id} -> {dst_id};')

        lines.append("}")
        dot_src = "\n".join(lines) + "\n"

        if output_path:
            with open(output_path, "w", encoding="utf-8") as fh:
                fh.write(dot_src)
            if render:
                self._try_render(output_path, render_format, dot_command)

        return dot_src

    @staticmethod
    def _node_id(node: Node) -> str:
        return f"n{id(node)}"

    @staticmethod
    def _node_label(node: Node) -> str:
        lines = [node.node_class]
        if node.name:
            lines.append(node.name)
        return "\\n".join(lines)

    @staticmethod
    def _node_color(node_class: str) -> str:
        color_map: dict[str, str] = {
            "Root": "#ffffcc",
            "Read": "#cce5ff",
            "Write": "#ffcccc",
            "Merge": "#ccffcc",
            "Merge2": "#ccffcc",
            "Grade": "#ffd9b3",
            "ColorCorrect": "#ffd9b3",
            "Blur": "#e0ccff",
            "Viewer": "#d9d9d9",
            "BackdropNode": "#f0f0f0",
            "Group": "#ffe0cc",
        }
        return color_map.get(node_class, "#f5f5f5")

    @staticmethod
    def _rendered_path(output_path: str, fmt: str) -> Path:
        path = Path(output_path)
        stem_path = path.with_suffix(
            "") if path.suffix.lower() == ".dot" else path
        return stem_path.with_suffix(f".{fmt}")

    @staticmethod
    def _try_render(output_path: str, fmt: str, dot_command: Optional[str] = None) -> None:
        command = dot_command or os.environ.get("NKPARSER_DOT") or "dot"
        rendered_path = DotExporter._rendered_path(output_path, fmt)
        try:
            subprocess.run(
                [command, f"-T{fmt}", output_path, "-o", str(rendered_path)],
                check=True,
                capture_output=True,
                text=True,
            )
        except (FileNotFoundError, subprocess.CalledProcessError):
            pass
