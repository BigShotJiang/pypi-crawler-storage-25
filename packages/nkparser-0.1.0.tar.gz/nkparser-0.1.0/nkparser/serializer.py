"""Round-trip serializer: converts a Script back to valid .nk text.

Fidelity strategy
-----------------
Each Knob stores ``raw_line`` — the verbatim line(s) from the original source.
The serializer replays ``raw_line`` for every unmodified knob, achieving
byte-level fidelity for untouched knobs.

For knobs that have been mutated (``Knob._dirty == True``), the serializer
re-renders from the model using ``" {name} {value.raw}"``.

The ``Script._ordered_statements`` list records every top-level statement
(Node, RawSetOp, RawPushOp, RawAddLayer) in original document order,
which is essential for preserving the exact interleaving of set/push
operations between nodes.

Known limitations
-----------------
- The exact whitespace inside brace blocks (indentation of multi-line knob
  values) is preserved verbatim via ``raw_line``.
- The ``define_window_layout_xml`` block's internal XML whitespace is
  preserved if the original source text was captured in
  ``Script.window_layout_xml``.
- Trailing newlines: the serializer always ends with a single trailing newline.
"""

from __future__ import annotations

from .models import Node, Script, GroupNode
from .parser import RawSetOp, RawPushOp, RawAddLayer


class Serializer:
    def __init__(self, script: Script) -> None:
        self._script = script

    def serialize(self) -> str:
        parts: list[str] = []

        # Header
        if self._script.shebang:
            parts.append(self._script.shebang)
        if self._script.nuke_version:
            parts.append(f"version {self._script.nuke_version}")
        if self._script.window_layout_xml is not None:
            parts.append(
                f"define_window_layout_xml {{{self._script.window_layout_xml}}}")

        # Body — replay ordered statements to preserve set/push interleaving
        for stmt in self._script._ordered_statements:
            if isinstance(stmt, Node):
                parts.append(self._serialize_node(stmt))
            elif isinstance(stmt, RawSetOp):
                parts.append(f"set {stmt.name} [stack {stmt.stack_index}]")
            elif isinstance(stmt, RawPushOp):
                parts.append(f"push ${stmt.ref}")
            elif isinstance(stmt, RawAddLayer):
                parts.append(f"add_layer {{{stmt.declaration}}}")

        return "\n".join(parts) + "\n"

    @staticmethod
    def _serialize_node(node: Node) -> str:
        lines: list[str] = [f"{node.node_class} {{"]
        for knob in node.knobs:
            lines.append(knob.raw_line)
        if isinstance(node, GroupNode):
            for child in node.children:
                lines.append(Serializer._serialize_node(child))
            lines.append("end_group")
        lines.append("}")
        return "\n".join(lines)
