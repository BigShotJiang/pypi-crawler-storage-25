"""Fluent traversal and query API for Script node graphs.

Usage::

    script = Script.from_file("comp.nk")

    # Find all Read nodes
    reads = script.query().of_class("Read").all()

    # Find nodes whose name starts with "Merge"
    merges = script.query().named("^Merge").all()

    # Find all upstream nodes from a given node
    node = script.find("Grade1")
    upstream = script.query().upstream(node, script).all()
"""

from __future__ import annotations

import re
from typing import Callable, Iterator, Optional
from collections import deque

from .models import Node, Script


class NodeQuery:
    """Immutable, chainable query builder over a sequence of Nodes."""

    def __init__(self, nodes: Iterator[Node] | list[Node]) -> None:
        self._nodes: list[Node] = list(nodes)

    # ------------------------------------------------------------------
    # Filters
    # ------------------------------------------------------------------

    def of_class(self, *classes: str) -> "NodeQuery":
        """Keep only nodes whose node_class is in *classes*."""
        class_set = set(classes)
        return NodeQuery(n for n in self._nodes if n.node_class in class_set)

    def named(self, pattern: str) -> "NodeQuery":
        """Keep nodes whose name knob matches the regex *pattern*."""
        rx = re.compile(pattern)
        return NodeQuery(n for n in self._nodes if rx.search(n.name))

    def with_knob(self, name: str, value_pattern: Optional[str] = None) -> "NodeQuery":
        """Keep nodes that have a knob with the given name.

        If *value_pattern* is given, also filter by that regex against the
        knob's raw value.
        """
        rx = re.compile(value_pattern) if value_pattern else None
        results: list[Node] = []
        for node in self._nodes:
            k = node.knob(name)
            if k is None:
                continue
            if rx is not None and not rx.search(k.value.raw):
                continue
            results.append(node)
        return NodeQuery(results)

    def where(self, predicate: Callable[[Node], bool]) -> "NodeQuery":
        """Keep nodes that satisfy *predicate*."""
        return NodeQuery(n for n in self._nodes if predicate(n))

    # ------------------------------------------------------------------
    # Graph traversal
    # ------------------------------------------------------------------

    def inputs_of(self, node: Node) -> "NodeQuery":
        """Return direct input nodes of *node* (excludes None/missing inputs)."""
        return NodeQuery(n for n in node.inputs if n is not None)

    def outputs_of(self, node: Node, script: Script) -> "NodeQuery":
        """Return all nodes in *script* that have *node* as a direct input."""
        return NodeQuery(n for n in script.all_nodes() if node in n.inputs)

    def upstream(self, node: Node, script: Script) -> "NodeQuery":  # noqa: ARG002
        """BFS all nodes upstream from (and including) *node*."""
        visited: set[int] = set()
        queue: deque[Node] = deque([node])
        result: list[Node] = []
        while queue:
            current = queue.popleft()
            if id(current) in visited:
                continue
            visited.add(id(current))
            result.append(current)
            for inp in current.inputs:
                if inp is not None and id(inp) not in visited:
                    queue.append(inp)
        return NodeQuery(result)

    def downstream(self, node: Node, script: Script) -> "NodeQuery":
        """BFS all nodes downstream from (and including) *node*."""
        visited: set[int] = set()
        queue: deque[Node] = deque([node])
        result: list[Node] = []
        while queue:
            current = queue.popleft()
            if id(current) in visited:
                continue
            visited.add(id(current))
            result.append(current)
            for n in script.all_nodes():
                if current in n.inputs and id(n) not in visited:
                    queue.append(n)
        return NodeQuery(result)

    # ------------------------------------------------------------------
    # Terminal operations
    # ------------------------------------------------------------------

    def first(self) -> Optional[Node]:
        return self._nodes[0] if self._nodes else None

    def last(self) -> Optional[Node]:
        return self._nodes[-1] if self._nodes else None

    def all(self) -> list[Node]:
        return list(self._nodes)

    def count(self) -> int:
        return len(self._nodes)

    def __iter__(self) -> Iterator[Node]:
        return iter(self._nodes)

    def __len__(self) -> int:
        return len(self._nodes)

    def __repr__(self) -> str:
        return f"NodeQuery({len(self._nodes)} nodes)"
