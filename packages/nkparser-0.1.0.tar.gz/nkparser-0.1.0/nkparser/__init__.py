"""nkparser — Parse, query, and serialize Foundry Nuke .nk script files.

Quick start::

    import nkparser

    # Parse a .nk file
    script = nkparser.Script.from_file("comp.nk")

    # Inspect
    print(f"{len(list(script.all_nodes()))} nodes")
    for d in script.diagnostics:
        print(d)

    # Query
    reads = script.query().of_class("Read").all()
    grade = script.find("Grade1")

    # Visualize
    print(nkparser.TextTree(script).render(show_knobs=True))
    nkparser.DotExporter(script).export("graph.dot")

    # Modify
    if grade:
        grade.set("white", "2.0")

    # Write back
    script.write("comp_modified.nk")
"""

from __future__ import annotations

from .query import NodeQuery
from .errors import (LexError, ParseError, NkParserError, ValidationError,
                     SerializationError)
from .models import (Knob, Node, Script, GroupNode, KnobValue, Diagnostic,
                     KnobValueKind, VariableReference, DiagnosticSeverity,
                     VariableAssignment)
from .visualization import TextTree, DotExporter

__version__ = "0.1.0"

__all__ = [
    # Core model
    "Script",
    "Node",
    "GroupNode",
    "Knob",
    "KnobValue",
    "KnobValueKind",
    "VariableAssignment",
    "VariableReference",
    "Diagnostic",
    "DiagnosticSeverity",
    # Errors
    "NkParserError",
    "LexError",
    "ParseError",
    "ValidationError",
    "SerializationError",
    # Query
    "NodeQuery",
    # Visualization
    "TextTree",
    "DotExporter",
    # Version
    "__version__",
]
