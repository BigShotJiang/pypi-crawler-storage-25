"""Command-line interface for nkparser.

Subcommands
-----------
info        Print a summary of a .nk file (version, node counts, diagnostics).
validate    List all diagnostics (errors and warnings) found in a .nk file.
tree        Print a hierarchical text tree of the node graph.
dot         Export the node graph to a Graphviz DOT file.
nodes       List all nodes, optionally filtered by class or name.
show        Dump the raw (or modified) .nk text — useful for debugging.

Usage examples
--------------
    nkparse info           comp.nk
    nkparse validate       comp.nk
    nkparse tree           comp.nk --knobs
    nkparse dot            comp.nk -o graph.dot
    nkparse nodes          comp.nk --class Merge2
    nkparse nodes          comp.nk --name "^Grade"
    nkparse show           comp.nk
"""

from __future__ import annotations

import sys
import json
import argparse
from typing import Any
from pathlib import Path

from . import __version__
from .models import Node, Script, DiagnosticSeverity
from .visualization import TextTree, DotExporter

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _load(path: str) -> Script:
    p = Path(path)
    if not p.exists():
        print(f"error: file not found: {path}", file=sys.stderr)
        sys.exit(1)
    if p.suffix.lower() != ".nk":
        print(
            f"warning: file does not have .nk extension: {path}", file=sys.stderr)
    return Script.from_file(p)


def _severity_symbol(sev: DiagnosticSeverity) -> str:
    return {"error": "✖", "warning": "⚠", "info": "ℹ"}.get(sev.value, "?")


def _exit_code(script: Script) -> int:
    return 1 if script.has_errors else 0


# ---------------------------------------------------------------------------
# Subcommands
# ---------------------------------------------------------------------------


def cmd_info(args: argparse.Namespace) -> int:
    script = _load(args.file)
    nodes = list(script.all_nodes())

    from collections import Counter
    class_counts = Counter(n.node_class for n in nodes)
    top = class_counts.most_common(5)

    errors = script.errors()
    warnings = script.warnings()

    if getattr(args, "format", "text") == "json":
        out = {
            "file": args.file,
            "version": script.nuke_version,
            "node_count": len(nodes),
            "top_classes": [{"class": cls, "count": n} for cls, n in top],
            "diagnostics": {"errors": len(errors), "warnings": len(warnings)},
        }
        print(json.dumps(out, indent=2))
        return _exit_code(script)

    print(f"File       : {args.file}")
    print(f"Version    : {script.nuke_version or '(none)'}")
    print(f"Nodes      : {len(nodes)}")
    print(
        f"Variables  : {len(script._variables)} set  /  {len(script._variable_refs)} push")
    print(f"Diagnostics: {len(errors)} error(s)  {len(warnings)} warning(s)")
    print()
    print("Top node classes:")
    for cls, n in top:
        print(f"  {cls:<22} {n}")
    if len(class_counts) > 5:
        print(f"  ... and {len(class_counts) - 5} more class(es)")

    if errors:
        print()
        print("Errors:")
        for d in errors:
            print(
                f"  {_severity_symbol(d.severity)} [{d.code}] line {d.line}: {d.message}")

    return _exit_code(script)


def cmd_validate(args: argparse.Namespace) -> int:
    script = _load(args.file)

    errors = script.errors()
    warnings = script.warnings()

    if getattr(args, "format", "text") == "json":
        out = {
            "file": args.file,
            "diagnostics": [
                {
                    "severity": d.severity.value,
                    "code": d.code,
                    "message": d.message,
                    "line": d.line,
                    "col": d.col,
                }
                for d in script.diagnostics
            ],
            "summary": {"errors": len(errors), "warnings": len(warnings)},
        }
        print(json.dumps(out, indent=2))
        return _exit_code(script)

    if not script.diagnostics:
        print(f"No issues found in {args.file}")
        return 0

    for d in script.diagnostics:
        sym = _severity_symbol(d.severity)
        print(f"{sym}  [{d.code}] line {d.line}: {d.message}")

    print()
    print(f"{len(errors)} error(s)  {len(warnings)} warning(s)")
    return _exit_code(script)


def cmd_tree(args: argparse.Namespace) -> int:
    script = _load(args.file)
    output = TextTree(script).render(
        show_knobs=args.knobs,
        max_depth=args.depth,
    )
    print(output)
    return _exit_code(script)


def cmd_dot(args: argparse.Namespace) -> int:
    script = _load(args.file)
    exporter = DotExporter(script)

    output_path: str | None = args.output
    dot = exporter.export(
        output_path,
        render=args.render,
        render_format=args.format,
        dot_command=args.dot_command,
    )

    if not output_path:
        print(dot)
    else:
        print(f"DOT graph written to: {output_path}")
        if args.render:
            rendered = DotExporter._rendered_path(output_path, args.format)
            if rendered.exists():
                print(f"Rendered image:       {rendered}")

    return _exit_code(script)


def cmd_nodes(args: argparse.Namespace) -> int:
    script = _load(args.file)
    q = script.query()

    if args.cls:
        q = q.of_class(*args.cls.split(","))
    if args.name:
        q = q.named(args.name)

    nodes = q.all()

    if not nodes:
        if getattr(args, "format", "text") == "json":
            print(json.dumps(
                {"file": args.file, "nodes": [], "count": 0}, indent=2))
        else:
            print("No nodes match the filter.")
        return 0

    # Determine extra knob columns
    _FIXED = {"name", "xpos", "ypos"}
    extra_cols: list[str] = []
    if args.attrs is not None:
        if args.attrs == "*":
            # Collect all knob names in first-seen order, excluding fixed cols
            seen: dict[str, None] = {}
            for node in nodes:
                for k in node.knobs:
                    if k.name not in _FIXED and k.name not in seen:
                        seen[k.name] = None
            extra_cols = list(seen)
        else:
            extra_cols = [c.strip()
                          for c in args.attrs.split(",") if c.strip()]

    # Build column widths
    _MAX_W = 30
    col_w = {"#": 5, "Class": 22, "Name": 30, "xpos": 8, "ypos": 8}
    for col in extra_cols:
        # Width = max of header length and longest value (capped)
        max_val = max(
            (len(node.get(col)) for node in nodes if node.knob(col)),
            default=0,
        )
        col_w[col] = min(_MAX_W, max(len(col), max_val))

    if getattr(args, "format", "text") == "json":
        def _node_dict(node: Node) -> dict[str, Any]:
            d: dict[str, Any] = {
                "class": node.node_class,
                "name": node.name,
                "xpos": int(node.xpos) if node.xpos is not None else None,
                "ypos": int(node.ypos) if node.ypos is not None else None,
            }
            if extra_cols:
                d["knobs"] = {c: node.get(c)
                              for c in extra_cols if node.knob(c)}
            return d

        out: dict[str, Any] = {
            "file": args.file,
            "nodes": [_node_dict(n) for n in nodes],
            "count": len(nodes),
        }
        print(json.dumps(out, indent=2))
        return _exit_code(script)

    parts = [
        f"{{:<{col_w['#']}}}",
        f"{{:<{col_w['Class']}}}",
        f"{{:<{col_w['Name']}}}",
        f"{{:<{col_w['xpos']}}}",
        f"{{:<{col_w['ypos']}}}",
    ] + [f"{{:<{col_w[c]}}}" for c in extra_cols]
    fmt = "  ".join(parts)

    headers = ["#", "Class", "Name", "xpos", "ypos"] + extra_cols
    print(fmt.format(*headers))
    total_width = sum(col_w[h] for h in headers) + 2 * (len(headers) - 1)
    print("-" * max(total_width, 80))

    for i, node in enumerate(nodes, 1):
        xp = str(int(node.xpos)) if node.xpos is not None else ""
        yp = str(int(node.ypos)) if node.ypos is not None else ""
        extra_vals = [node.get(c)[:col_w[c]] for c in extra_cols]
        row = [str(i), node.node_class[:col_w["Class"]],
               node.name[:col_w["Name"]], xp, yp]
        print(fmt.format(*(row + extra_vals)))

    print()
    print(f"{len(nodes)} node(s)")
    return _exit_code(script)


def cmd_show(args: argparse.Namespace) -> int:
    script = _load(args.file)
    print(script.to_nk(), end="")
    return _exit_code(script)


# ---------------------------------------------------------------------------
# Argument parser
# ---------------------------------------------------------------------------


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Parse, inspect, and validate Foundry Nuke .nk script files.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
examples:
  nkparse info      comp.nk
  nkparse info      comp.nk --format json
  nkparse validate  comp.nk
  nkparse validate  comp.nk --format json
  nkparse tree      comp.nk --knobs
  nkparse dot       comp.nk -o graph.dot --render
  nkparse nodes     comp.nk --class Read
  nkparse nodes     comp.nk --name "^Merge"
  nkparse nodes     comp.nk --class Grade --attrs
  nkparse nodes     comp.nk --class Grade --attrs white,multiply --format json
  nkparse show      comp.nk
""",
    )
    parser.add_argument("--version", action="version",
                        version=f"nkparser {__version__}")

    sub = parser.add_subparsers(dest="command", metavar="command")

    # info
    p_info = sub.add_parser("info", help="Print a summary of the script")
    p_info.add_argument("file", metavar="FILE", help=".nk file to inspect")
    p_info.add_argument(
        "--format", choices=["text", "json"], default="text", help="Output format (default: text)"
    )

    # validate
    p_val = sub.add_parser(
        "validate", help="List all diagnostics (errors and warnings)")
    p_val.add_argument("file", metavar="FILE", help=".nk file to validate")
    p_val.add_argument(
        "--format", choices=["text", "json"], default="text", help="Output format (default: text)"
    )

    # tree
    p_tree = sub.add_parser("tree", help="Print the node graph as a text tree")
    p_tree.add_argument("file", metavar="FILE", help=".nk file")
    p_tree.add_argument(
        "--knobs", "-k", action="store_true", help="Show knob values under each node"
    )
    p_tree.add_argument(
        "--depth", "-d", type=int, default=99, metavar="N", help="Maximum tree depth (default: 99)"
    )

    # dot
    p_dot = sub.add_parser(
        "dot", help="Export the node graph to Graphviz DOT format")
    p_dot.add_argument("file", metavar="FILE", help=".nk file")
    p_dot.add_argument("-o", "--output", metavar="OUT",
                       help="Write DOT to file (default: stdout)")
    p_dot.add_argument(
        "--render",
        action="store_true",
        help="Render to image (requires the graphviz Python package)",
    )
    p_dot.add_argument(
        "--format",
        default="png",
        metavar="FMT",
        help="Render format: png, svg, pdf (default: png)",
    )
    p_dot.add_argument(
        "--dot-command",
        metavar="PATH",
        help="Graphviz dot executable to use for --render (default: NKPARSER_DOT or dot)",
    )

    # nodes
    p_nodes = sub.add_parser("nodes", help="List nodes, optionally filtered")
    p_nodes.add_argument("file", metavar="FILE", help=".nk file")
    p_nodes.add_argument(
        "--class",
        dest="cls",
        metavar="CLASS",
        help="Filter by node class (comma-separated for multiple, e.g. Read,Write)",
    )
    p_nodes.add_argument(
        "--name", metavar="PATTERN", help="Filter by name regex (e.g. '^Grade')"
    )
    p_nodes.add_argument(
        "--attrs",
        metavar="KNOBS",
        nargs="?",
        const="*",
        default=None,
        help=(
            "Show extra knob columns. Omit value for all knobs (--attrs), "
            "or pass a comma-separated list (--attrs white,multiply)"
        ),
    )
    p_nodes.add_argument(
        "--format", choices=["text", "json"], default="text", help="Output format (default: text)"
    )

    # show
    p_show = sub.add_parser(
        "show", help="Print the serialized .nk text (round-trip output)")
    p_show.add_argument("file", metavar="FILE", help=".nk file")

    return parser


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    dispatch = {
        "info": cmd_info,
        "validate": cmd_validate,
        "tree": cmd_tree,
        "dot": cmd_dot,
        "nodes": cmd_nodes,
        "show": cmd_show,
    }

    fn = dispatch.get(args.command)
    if fn is None:
        parser.print_help()
        sys.exit(1)

    sys.exit(fn(args))


if __name__ == "__main__":
    main()
