"""Validation pass over a built Script object.

Each check appends Diagnostic entries to script.diagnostics.
Checks are independent and non-fatal — a script with errors can still be
serialized (with potentially degraded output).

Diagnostic codes emitted:
  unresolved-variable    — push $X where X was never set
  unclosed-group         — Group { without matching end_group
  duplicate-name         — two nodes share the same 'name' knob value
  orphaned-set           — set X whose variable is never push-ed
  missing-root           — no Root node in script
  empty-name             — node has no name knob or empty name
  invalid-inputs-count   — inputs knob is not a valid non-negative integer
"""

from __future__ import annotations

from .models import Script, GroupNode, Diagnostic, DiagnosticSeverity


class Validator:
    def __init__(self, script: Script) -> None:
        self._script = script

    def validate(self) -> list[Diagnostic]:
        self._check_unclosed_groups()
        self._check_unresolved_variables()
        self._check_duplicate_names()
        self._check_orphaned_sets()
        self._check_missing_root()
        self._check_empty_names()
        self._check_invalid_inputs_count()
        return self._script.diagnostics

    # ------------------------------------------------------------------
    # Checks
    # ------------------------------------------------------------------

    def _check_unclosed_groups(self) -> None:
        for node in self._script.all_nodes():
            if isinstance(node, GroupNode) and node.is_unclosed:
                self._emit(
                    DiagnosticSeverity.ERROR,
                    f"Group node {node.name!r} has no matching 'end_group'",
                    "unclosed-group",
                    node.source_line,
                )

    def _check_unresolved_variables(self) -> None:
        set_names = set(self._script._variables.keys())
        for ref in self._script._variable_refs:
            if ref.name not in set_names:
                self._emit(
                    DiagnosticSeverity.ERROR,
                    f"push references undefined variable '${ref.name}'",
                    "unresolved-variable",
                    ref.source_line,
                )

    def _check_duplicate_names(self) -> None:
        seen: dict[str, int] = {}
        for node in self._script.all_nodes():
            n = node.name
            if not n:
                continue
            if n in seen:
                self._emit(
                    DiagnosticSeverity.WARNING,
                    f"Duplicate node name {n!r} (first at line {seen[n]})",
                    "duplicate-name",
                    node.source_line,
                )
            else:
                seen[n] = node.source_line

    def _check_orphaned_sets(self) -> None:
        pushed_names = {ref.name for ref in self._script._variable_refs}
        for name, assignment in self._script._variables.items():
            if name not in pushed_names:
                self._emit(
                    DiagnosticSeverity.WARNING,
                    f"Variable '{name}' is set but never push-ed",
                    "orphaned-set",
                    assignment.source_line,
                )

    def _check_missing_root(self) -> None:
        if self._script.root() is None:
            self._emit(
                DiagnosticSeverity.WARNING,
                "Script has no Root node",
                "missing-root",
                0,
            )

    def _check_empty_names(self) -> None:
        for node in self._script.all_nodes():
            if not node.name:
                self._emit(
                    DiagnosticSeverity.WARNING,
                    f"Node of class {node.node_class!r} has no name",
                    "empty-name",
                    node.source_line,
                )

    def _check_invalid_inputs_count(self) -> None:
        for node in self._script.all_nodes():
            k = node.knob("inputs")
            if k is None:
                continue
            raw = k.value.raw
            try:
                val = int(raw)
                if val < 0:
                    raise ValueError
            except ValueError:
                self._emit(
                    DiagnosticSeverity.WARNING,
                    f"Node {node.name!r} has invalid 'inputs' value {raw!r} (expected non-negative integer)",
                    "invalid-inputs-count",
                    k.source_line,
                )

    # ------------------------------------------------------------------
    # Helper
    # ------------------------------------------------------------------

    def _emit(
        self,
        severity: DiagnosticSeverity,
        message: str,
        code: str,
        line: int,
        col: int = 0,
    ) -> None:
        self._script.diagnostics.append(
            Diagnostic(severity=severity, message=message,
                       code=code, line=line, col=col)
        )
