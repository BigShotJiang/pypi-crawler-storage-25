"""Recursive-descent parser for Nuke .nk token streams.

Converts a flat list of Tokens produced by the Lexer into an intermediate
representation (raw AST) consisting of RawNode, RawSetOp, RawPushOp, and
RawAddLayer dataclasses.  The builder module converts this raw AST into the
final Script/Node object model.

Design notes:
- The grammar is LL(2): any ambiguity is resolved by at most one look-ahead token.
- Error recovery uses per-node checkpoints: when parsing a node body fails, the
  parser skips forward to the next top-level closing '}' and resumes, emitting
  a ParseError diagnostic for the broken node.
- Groups (Group { ... end_group }) are handled recursively via _parse_group().
"""

from __future__ import annotations

import re
from dataclasses import field, dataclass

from .errors import ParseError
from .tokens import Token, TokenKind

# ---------------------------------------------------------------------------
# Raw AST node types (internal, not part of the public API)
# ---------------------------------------------------------------------------


@dataclass
class RawKnob:
    name: str
    raw_value: str   # verbatim value text as it appears after the knob name
    source_line: int
    raw_line: str    # the full original line(s) including leading space


@dataclass
class RawNode:
    node_class: str
    knobs: list[RawKnob] = field(default_factory=list)
    children: list["RawStatement"] = field(default_factory=list)  # for groups
    is_group: bool = False
    is_unclosed: bool = False   # set if group end_group was missing
    source_line: int = 0
    source_end_line: int = 0


@dataclass
class RawSetOp:
    name: str        # variable name without $
    stack_index: int
    source_line: int


@dataclass
class RawPushOp:
    ref: str         # variable name without $
    source_line: int


@dataclass
class RawAddLayer:
    declaration: str  # raw content inside {}
    source_line: int


RawStatement = RawNode | RawSetOp | RawPushOp | RawAddLayer

# Pattern to extract stack index from "[stack N]"
_STACK_RE = re.compile(r"\[stack\s+(\d+)\]")


# ---------------------------------------------------------------------------
# Parser
# ---------------------------------------------------------------------------


class Parser:
    """Parse a token list into (header_dict, list[RawStatement]).

    Usage::

        tokens = Lexer(source).tokenize()
        parser = Parser(tokens)
        header, statements = parser.parse()
    """

    def __init__(self, tokens: list[Token]) -> None:
        # Filter out COMMENT tokens; keep NEWLINEs for line-number tracking
        self._tokens = [t for t in tokens if t.kind != TokenKind.COMMENT]
        self._pos = 0
        self.errors: list[ParseError] = []

    # ------------------------------------------------------------------
    # Public entry point
    # ------------------------------------------------------------------

    def parse(self) -> tuple[dict[str, str], list[RawStatement]]:
        """Return (header, statements) for the script."""
        header = self._parse_header()
        statements: list[RawStatement] = []
        while not self._at_eof():
            self._skip_newlines()
            if self._at_eof():
                break
            stmt = self._parse_statement()
            if stmt is not None:
                statements.append(stmt)
        return header, statements

    # ------------------------------------------------------------------
    # Header
    # ------------------------------------------------------------------

    def _parse_header(self) -> dict[str, str]:
        header: dict[str, str] = {}
        self._skip_newlines()

        # Shebang
        if self._peek().kind == TokenKind.SHEBANG:
            header["shebang"] = self._consume().value
            self._skip_newlines()

        # version 15.0 v2
        if self._peek().kind == TokenKind.WORD and self._peek().value == "version":
            self._consume()  # "version"
            parts: list[str] = []
            while not self._at_newline_or_eof():
                parts.append(self._consume().value)
            header["version"] = " ".join(parts)
            self._skip_newlines()

        # define_window_layout_xml { ... }
        if (
            self._peek().kind == TokenKind.WORD
            and self._peek().value == "define_window_layout_xml"
        ):
            self._consume()  # keyword
            self._skip_newlines()
            if self._peek().kind == TokenKind.BRACE_BLOCK:
                tok = self._consume()
                # Strip surrounding { }
                inner = tok.value[1:-1]
                header["window_layout_xml"] = inner
            self._skip_newlines()

        return header

    # ------------------------------------------------------------------
    # Statement dispatcher
    # ------------------------------------------------------------------

    def _parse_statement(self) -> RawStatement | None:
        self._skip_newlines()
        if self._at_eof():
            return None

        tok = self._peek()
        if tok.kind != TokenKind.WORD:
            # Unexpected token; skip it
            self.errors.append(
                ParseError(
                    f"expected node class or keyword, got {tok.kind.name} {tok.value!r}",
                    tok.line,
                    tok.col,
                )
            )
            self._consume()
            return None

        word = tok.value

        if word == "set":
            return self._parse_set()
        if word == "push":
            return self._parse_push()
        if word == "add_layer":
            return self._parse_add_layer()

        # Anything else should be a node class followed by {
        return self._parse_node()

    # ------------------------------------------------------------------
    # Stack operations
    # ------------------------------------------------------------------

    def _parse_set(self) -> RawSetOp | None:
        tok = self._consume()  # "set"
        line = tok.line
        if self._peek().kind != TokenKind.WORD:
            self.errors.append(ParseError(
                "expected variable name after 'set'", line, tok.col))
            return None
        name = self._consume().value  # variable name
        if self._peek().kind != TokenKind.BRACKET_EXPR:
            self.errors.append(ParseError(
                "expected [stack N] after variable name", line, tok.col))
            return None
        bracket = self._consume()
        m = _STACK_RE.match(bracket.value)
        if not m:
            self.errors.append(
                ParseError(
                    f"malformed stack expression: {bracket.value!r}", line, bracket.col)
            )
            return None
        return RawSetOp(name=name, stack_index=int(m.group(1)), source_line=line)

    def _parse_push(self) -> RawPushOp | None:
        tok = self._consume()  # "push"
        line = tok.line
        if self._peek().kind != TokenKind.WORD:
            self.errors.append(ParseError(
                "expected $variable after 'push'", line, tok.col))
            return None
        ref_tok = self._consume()
        ref = ref_tok.value.lstrip("$")
        return RawPushOp(ref=ref, source_line=line)

    def _parse_add_layer(self) -> RawAddLayer | None:
        tok = self._consume()  # "add_layer"
        line = tok.line
        if self._peek().kind != TokenKind.BRACE_BLOCK:
            self.errors.append(ParseError(
                "expected {...} after 'add_layer'", line, tok.col))
            return None
        block = self._consume()
        # Strip { and } and return inner content
        return RawAddLayer(declaration=block.value[1:-1].strip(), source_line=line)

    # ------------------------------------------------------------------
    # Node parsing
    # ------------------------------------------------------------------

    def _parse_node(self) -> RawNode | None:
        class_tok = self._consume()
        node_class = class_tok.value
        line = class_tok.line
        is_group = node_class == "Group"

        self._skip_newlines()
        if self._peek().kind != TokenKind.BRACE_BLOCK and not (
            self._peek().kind == TokenKind.WORD and self._peek().value == "{"
        ):
            # The brace block may be a BRACE_BLOCK token (most common) or the
            # lexer may have split it into separate WORD/NEWLINE tokens if
            # the node body spans lines — but our lexer always emits BRACE_BLOCK
            # for { tokens.  However in the outer grammar the lexer produces
            # BRACE_BLOCKs only when { is encountered; node bodies ARE brace
            # blocks, so this path is always BRACE_BLOCK.
            if self._peek().kind != TokenKind.BRACE_BLOCK:
                self.errors.append(
                    ParseError(
                        f"expected '{{' after node class {node_class!r}",
                        line,
                        class_tok.col,
                    )
                )
                return None

        body_tok = self._consume()  # BRACE_BLOCK token for the node body
        end_line = body_tok.end_line

        # Parse the brace block's inner text for knob lines.
        # Groups additionally contain child statements between their knobs and end_group.
        if is_group:
            knobs, children, is_unclosed = self._parse_group_body(
                body_tok.value[1:-1], line)
            return RawNode(
                node_class=node_class,
                knobs=knobs,
                children=children,
                is_group=True,
                is_unclosed=is_unclosed,
                source_line=line,
                source_end_line=end_line,
            )
        else:
            knobs = self._parse_node_body(body_tok.value[1:-1], line)
            return RawNode(
                node_class=node_class,
                knobs=knobs,
                source_line=line,
                source_end_line=end_line,
            )

    # ------------------------------------------------------------------
    # Node body parsing (knob lines inside a brace block)
    # ------------------------------------------------------------------

    def _parse_node_body(self, body_text: str, base_line: int) -> list[RawKnob]:
        """Parse the interior text of a node {} block into RawKnob list."""
        knobs: list[RawKnob] = []
        lines = body_text.split("\n")
        i = 0
        current_line = base_line + \
            1  # body starts one line after the opening {

        while i < len(lines):
            raw_line = lines[i]
            stripped = raw_line.strip()
            i += 1
            current_line += 1

            if not stripped:
                continue

            # A knob line is:  <name> <value>
            # Value may be a brace block that spans multiple lines — but since
            # the lexer already collected the full brace block into a single
            # BRACE_BLOCK token, within the node body text the braces are
            # already balanced inline.
            parts = stripped.split(None, 1)
            if len(parts) == 0:
                continue
            knob_name = parts[0]
            raw_value = parts[1] if len(parts) > 1 else ""
            knobs.append(
                RawKnob(
                    name=knob_name,
                    raw_value=raw_value,
                    source_line=current_line - 1,
                    raw_line=raw_line,
                )
            )

        return knobs

    def _parse_group_body(
        self, body_text: str, base_line: int
    ) -> tuple[list[RawKnob], list[RawStatement], bool]:
        """Parse the interior of a Group { ... end_group } block.

        Returns (knobs, children, is_unclosed).
        """
        # Re-tokenise the inner body so we can use the same parser logic.
        from .lexer import \
            Lexer  # local import to avoid circular at module load

        inner_lexer = Lexer(body_text)
        inner_tokens = inner_lexer.tokenize()
        # Adjust line numbers by base_line offset
        adjusted: list[Token] = []
        for t in inner_tokens:
            adjusted.append(
                Token(
                    kind=t.kind,
                    value=t.value,
                    line=t.line + base_line,
                    col=t.col,
                    end_line=t.end_line + base_line,
                    end_col=t.end_col,
                )
            )

        inner_parser = Parser(adjusted)
        knobs: list[RawKnob] = []
        children: list[RawStatement] = []
        is_unclosed = True

        inner_parser._skip_newlines()

        # First, parse leading knob lines (before any child nodes / end_group)
        # Knobs appear before child nodes in Group bodies.
        while not inner_parser._at_eof():
            inner_parser._skip_newlines()
            if inner_parser._at_eof():
                break
            tok = inner_parser._peek()
            if tok.kind != TokenKind.WORD:
                break
            if tok.value == "end_group":
                inner_parser._consume()
                is_unclosed = False
                break

            # Peek ahead: if next meaningful token after word is BRACE_BLOCK,
            # this is a child node; otherwise it's a knob line.
            next_idx = inner_parser._pos + 1
            while next_idx < len(inner_parser._tokens) and inner_parser._tokens[next_idx].kind in (
                TokenKind.NEWLINE,
            ):
                next_idx += 1
            next_tok = (
                inner_parser._tokens[next_idx]
                if next_idx < len(inner_parser._tokens)
                else inner_parser._tokens[-1]
            )

            if next_tok.kind == TokenKind.BRACE_BLOCK and tok.value not in (
                "set",
                "push",
                "add_layer",
            ):
                # Child node or nested group
                stmt = inner_parser._parse_statement()
                if stmt is not None:
                    children.append(stmt)
            elif tok.value in ("set", "push", "add_layer"):
                stmt = inner_parser._parse_statement()
                if stmt is not None:
                    children.append(stmt)
            else:
                # Knob line — consume the rest of the logical line
                knob_tok = inner_parser._consume()
                parts = knob_tok.value.split(
                    None, 1)  # shouldn't really happen
                knob_name = parts[0]
                raw_value = ""

                # Value tokens follow on same logical line
                val_parts: list[str] = []
                while not inner_parser._at_newline_or_eof():
                    val_parts.append(inner_parser._consume().value)
                raw_value = " ".join(val_parts)

                knobs.append(
                    RawKnob(
                        name=knob_name,
                        raw_value=raw_value,
                        source_line=knob_tok.line,
                        raw_line=f" {knob_name} {raw_value}",
                    )
                )

        self.errors.extend(inner_parser.errors)
        return knobs, children, is_unclosed

    # ------------------------------------------------------------------
    # Token stream helpers
    # ------------------------------------------------------------------

    def _peek(self, offset: int = 0) -> Token:
        idx = self._pos + offset
        if idx < len(self._tokens):
            return self._tokens[idx]
        # Return a sentinel EOF token
        last = self._tokens[-1] if self._tokens else Token(
            TokenKind.EOF, "", 1, 1, 1, 1)
        return Token(TokenKind.EOF, "", last.line, last.col, last.line, last.col)

    def _consume(self, expected_kind: TokenKind | None = None) -> Token:
        tok = self._peek()
        if expected_kind is not None and tok.kind != expected_kind:
            raise ParseError(
                f"expected {expected_kind.name}, got {tok.kind.name} {tok.value!r}",
                tok.line,
                tok.col,
            )
        self._pos += 1
        return tok

    def _at_eof(self) -> bool:
        return self._peek().kind == TokenKind.EOF

    def _at_newline_or_eof(self) -> bool:
        k = self._peek().kind
        return k in (TokenKind.NEWLINE, TokenKind.EOF)

    def _skip_newlines(self) -> None:
        while self._peek().kind == TokenKind.NEWLINE:
            self._pos += 1
