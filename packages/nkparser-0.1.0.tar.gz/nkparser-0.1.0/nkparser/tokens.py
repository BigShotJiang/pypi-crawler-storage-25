"""Token types and Token dataclass for the nkparser lexer."""

from __future__ import annotations

from enum import Enum, auto
from dataclasses import dataclass


class TokenKind(Enum):
    WORD = auto()        # bare identifier, number, or unquoted value fragment
    STRING = auto()      # "..." — quotes included in .value
    BRACE_BLOCK = auto()  # {...} balanced block — braces included in .value
    BRACKET_EXPR = auto()  # [...] — brackets included in .value
    SHEBANG = auto()     # #! ... rest of line (line 1 only)
    COMMENT = auto()     # # ... rest of line
    NEWLINE = auto()
    EOF = auto()


@dataclass(slots=True)
class Token:
    kind: TokenKind
    value: str      # raw text as it appears in source (including delimiters)
    line: int       # 1-based start line
    col: int        # 1-based start column
    end_line: int   # 1-based end line
    end_col: int    # 1-based end column

    def __repr__(self) -> str:
        preview = self.value[:40].replace("\n", "\\n")
        if len(self.value) > 40:
            preview += "..."
        return f"Token({self.kind.name}, {preview!r}, {self.line}:{self.col})"
