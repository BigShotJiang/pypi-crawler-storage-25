"""Data model for Nuke .nk script files.

Public classes:
    KnobValueKind  — enum tag for knob value representation
    KnobValue      — tagged value holding verbatim raw text
    Knob           — a single knob (property) on a node
    Node           — a Nuke node with knobs and connectivity
    GroupNode      — a Group node containing child nodes/statements
    VariableAssignment  — a 'set X [stack 0]' operation
    VariableReference   — a 'push $X' operation
    DiagnosticSeverity  — enum for diagnostic level
    Diagnostic     — a single validation or parse diagnostic message
    Script         — the root object for a parsed .nk file
"""

from __future__ import annotations

import os
import re
from enum import Enum, auto
from typing import TYPE_CHECKING, Iterator, Optional
from dataclasses import field, dataclass

if TYPE_CHECKING:
    from .query import NodeQuery


# ---------------------------------------------------------------------------
# Knob value model
# ---------------------------------------------------------------------------


class KnobValueKind(Enum):
    BARE = auto()        # xpos -409, inputs 2, true/false
    QUOTED = auto()      # "some string"
    BRACE_EXPR = auto()  # {{sin(frame/5)}} — double-brace TCL expression
    BRACE_BLOCK = auto()  # {1 0.5434 0 1} — vector / multiline data block
    BRACKET = auto()     # [stack 0] — bracket expression (rare as knob value)


@dataclass
class KnobValue:
    # verbatim source text (used for round-trip)
    raw: str
    kind: KnobValueKind
    interpreted: Optional[str] = None  # lazily computed unescaped/parsed form

    @classmethod
    def classify(cls, raw: str) -> "KnobValue":
        """Create a KnobValue with automatically determined kind."""
        if raw.startswith('"'):
            return cls(raw=raw, kind=KnobValueKind.QUOTED)
        if raw.startswith("{{") and raw.endswith("}}"):
            return cls(raw=raw, kind=KnobValueKind.BRACE_EXPR)
        if raw.startswith("{"):
            return cls(raw=raw, kind=KnobValueKind.BRACE_BLOCK)
        if raw.startswith("["):
            return cls(raw=raw, kind=KnobValueKind.BRACKET)
        return cls(raw=raw, kind=KnobValueKind.BARE)

    def as_string(self) -> Optional[str]:
        """Return unquoted string content if QUOTED, else None."""
        if self.kind != KnobValueKind.QUOTED:
            return None
        s = self.raw
        if s.startswith('"') and s.endswith('"') and len(s) >= 2:
            # Unescape standard backslash sequences
            return s[1:-1].replace('\\"', '"').replace("\\n", "\n").replace("\\t", "\t")
        return s

    def as_number(self) -> Optional[float]:
        """Return float if value is a bare numeric literal, else None."""
        if self.kind != KnobValueKind.BARE:
            return None
        try:
            return float(self.raw)
        except ValueError:
            return None

    def as_bool(self) -> Optional[bool]:
        """Return bool if value is 'true' or 'false', else None."""
        if self.kind == KnobValueKind.BARE:
            if self.raw == "true":
                return True
            if self.raw == "false":
                return False
        return None


# ---------------------------------------------------------------------------
# Knob
# ---------------------------------------------------------------------------


@dataclass
class Knob:
    name: str
    value: KnobValue
    source_line: int = 0
    # verbatim source line(s) — used for round-trip serialization
    raw_line: str = ""
    # set when value is mutated
    _dirty: bool = field(default=False, repr=False)

    def set_value(self, raw: str) -> None:
        """Update the knob value and mark for re-serialization."""
        self.value = KnobValue.classify(raw)
        self.raw_line = f" {self.name} {raw}"
        self._dirty = True

    def is_user_knob(self) -> bool:
        return self.name == "addUserKnob"

    @property
    def string_value(self) -> Optional[str]:
        return self.value.as_string()

    @property
    def number_value(self) -> Optional[float]:
        return self.value.as_number()

    @property
    def bool_value(self) -> Optional[bool]:
        return self.value.as_bool()


# ---------------------------------------------------------------------------
# Node
# ---------------------------------------------------------------------------


@dataclass
class Node:
    node_class: str
    knobs: list[Knob] = field(default_factory=list)
    source_line: int = 0
    source_end_line: int = 0

    # Populated by the builder — not part of the serialized form
    _inputs: list[Optional["Node"]] = field(default_factory=list, repr=False)
    _script_ref: Optional["Script"] = field(default=None, repr=False)

    # ------------------------------------------------------------------
    # Knob accessors
    # ------------------------------------------------------------------

    def knob(self, name: str) -> Optional[Knob]:
        """Return the first Knob with the given name, or None."""
        return next((k for k in self.knobs if k.name == name), None)

    def knobs_named(self, name: str) -> list[Knob]:
        """Return all knobs with the given name."""
        return [k for k in self.knobs if k.name == name]

    def get(self, name: str, default: str = "") -> str:
        """Return the raw value of the first knob with the given name, or default."""
        k = self.knob(name)
        return default if k is None else k.value.raw

    def get_string(self, name: str, default: str = "") -> str:
        """Return unquoted string value of knob, or default."""
        k = self.knob(name)
        if k is None:
            return default
        s = k.string_value
        return s if s is not None else k.value.raw

    def set(self, name: str, raw_value: str) -> None:
        """Set a knob value by name. Creates the knob if it doesn't exist."""
        k = self.knob(name)
        if k is not None:
            k.set_value(raw_value)
        else:
            new_knob = Knob(
                name=name,
                value=KnobValue.classify(raw_value),
                raw_line=f" {name} {raw_value}",
                _dirty=True,
            )
            self.knobs.append(new_knob)

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def name(self) -> str:
        """Value of the 'name' knob (the node's unique identifier in Nuke)."""
        k = self.knob("name")
        if k is None:
            return ""
        s = k.string_value
        return s if s is not None else k.value.raw

    @property
    def inputs(self) -> list[Optional["Node"]]:
        return self._inputs

    @property
    def xpos(self) -> Optional[float]:
        x = self.knob("xpos")
        return x.number_value if x else None

    @property
    def ypos(self) -> Optional[float]:
        y = self.knob("ypos")
        return y.number_value if y else None

    # ------------------------------------------------------------------
    # Serialization
    # ------------------------------------------------------------------

    def to_nk(self) -> str:
        """Serialize this node to .nk text."""
        from .serializer import Serializer  # avoid circular at import time

        return Serializer._serialize_node(self)

    def __repr__(self) -> str:
        return f"<Node {self.node_class!r} name={self.name!r}>"

    def __hash__(self) -> int:
        return id(self)

    def __eq__(self, other: object) -> bool:
        return self is other


# ---------------------------------------------------------------------------
# GroupNode
# ---------------------------------------------------------------------------


@dataclass
class GroupNode(Node):
    """A Group { ... end_group } block containing child nodes and statements."""

    # Children are the inner statements (RawStatement converted to Node instances
    # by the builder; also includes nested GroupNodes).
    children: list[Node] = field(default_factory=list)
    is_unclosed: bool = False  # True if end_group was missing (parse error)

    def iter_nodes(self, recursive: bool = True) -> Iterator[Node]:
        """Yield all descendant Nodes depth-first."""
        for child in self.children:
            yield child
            if recursive and isinstance(child, GroupNode):
                yield from child.iter_nodes(recursive=True)

    def __repr__(self) -> str:
        return f"<GroupNode {self.node_class!r} name={self.name!r} children={len(self.children)}>"


# ---------------------------------------------------------------------------
# Variable operations (retained for validation and round-trip)
# ---------------------------------------------------------------------------


@dataclass
class VariableAssignment:
    """Represents: set Na154c800 [stack 0]"""

    name: str
    stack_index: int
    source_line: int


@dataclass
class VariableReference:
    """Represents: push $Na154cc00"""

    name: str
    source_line: int
    resolved: Optional[Node] = None  # populated by the builder


# ---------------------------------------------------------------------------
# Diagnostics
# ---------------------------------------------------------------------------


class DiagnosticSeverity(Enum):
    ERROR = "error"
    WARNING = "warning"
    INFO = "info"


@dataclass
class Diagnostic:
    severity: DiagnosticSeverity
    message: str
    code: str     # e.g. "unresolved-variable", "unclosed-group", "duplicate-name"
    line: int
    col: int = 0

    def __str__(self) -> str:
        return f"[{self.severity.value.upper()}] {self.code}: {self.message} (line {self.line})"


# ---------------------------------------------------------------------------
# Script — the root object
# ---------------------------------------------------------------------------

# Type alias for any statement stored alongside nodes in the ordered sequence
from .parser import (RawSetOp, RawPushOp,  # noqa: E402  (after dataclass defs)
                     RawAddLayer)


@dataclass
class Script:
    """The root object for a parsed Nuke .nk file.

    Typical usage::

        script = Script.from_file("comp.nk")
        for node in script.all_nodes():
            print(node)
        reads = script.query().of_class("Read").all()
        script.write("comp_modified.nk")
    """

    # Header metadata
    shebang: Optional[str] = None
    nuke_version: Optional[str] = None
    window_layout_xml: Optional[str] = None

    # Top-level nodes in document order
    nodes: list[Node] = field(default_factory=list)

    # Layer declarations in document order
    add_layer_declarations: list[str] = field(default_factory=list)

    # Variable tracking for validation (populated by builder)
    _variables: dict[str, VariableAssignment] = field(
        default_factory=dict, repr=False)
    _variable_refs: list[VariableReference] = field(
        default_factory=list, repr=False)

    # Ordered list of all top-level statements (nodes + set/push/add_layer ops)
    # needed for round-trip serialization preserving exact ordering.
    _ordered_statements: list[object] = field(default_factory=list, repr=False)

    # Validation diagnostics
    diagnostics: list[Diagnostic] = field(default_factory=list, repr=False)

    # ------------------------------------------------------------------
    # I/O class methods
    # ------------------------------------------------------------------

    @classmethod
    def from_file(cls, path: str | os.PathLike[str]) -> "Script":
        """Parse a .nk file and return a Script.

        Raises ParseError on fatal failures. Non-fatal issues are appended to
        ``script.diagnostics``.
        """
        text = open(path, encoding="utf-8", errors="replace").read()
        return cls.from_string(text)

    @classmethod
    def from_string(cls, text: str) -> "Script":
        """Parse a .nk script from an in-memory string."""
        from .lexer import Lexer
        from .parser import Parser
        from .builder import ScriptBuilder
        from .validator import Validator

        lexer = Lexer(text)
        tokens = lexer.tokenize()
        parser = Parser(tokens)
        header, statements = parser.parse()
        script = ScriptBuilder().build(header, statements)

        # Absorb any lex/parse errors as diagnostics

        for err in lexer.errors:
            script.diagnostics.append(
                Diagnostic(DiagnosticSeverity.ERROR, str(
                    err), "lex-error", err.line, err.col)
            )
        for err in parser.errors:
            script.diagnostics.append(
                Diagnostic(DiagnosticSeverity.ERROR, str(
                    err), "parse-error", err.line, err.col)
            )

        Validator(script).validate()
        return script

    def to_nk(self) -> str:
        """Serialize the entire script back to .nk text."""
        from .serializer import Serializer

        return Serializer(self).serialize()

    def write(self, path: str | os.PathLike[str]) -> None:
        """Write the serialized script to a file."""
        with open(path, "w", encoding="utf-8") as fh:
            fh.write(self.to_nk())

    # ------------------------------------------------------------------
    # Navigation
    # ------------------------------------------------------------------

    def all_nodes(self, recursive: bool = True) -> Iterator[Node]:
        """Yield every Node in the script.

        If recursive=True, descends into GroupNode children.
        """
        for node in self.nodes:
            yield node
            if recursive and isinstance(node, GroupNode):
                yield from node.iter_nodes(recursive=True)

    def find(
        self,
        name: Optional[str] = None,
        *,
        attr: Optional[str] = None,
        value: Optional[str] = None,
    ) -> Optional[Node]:
        """Return the first matching node.

        Modes:
          find("Grade1")                    — exact name match (backward compat)
          find(value=r".+comp")             — any knob value matches regex
          find(attr="label", value=r"comp") — specific knob value matches regex
          find(attr="label")                — first node that has that knob
        """
        if name is not None:
            for node in self.all_nodes():
                if node.name == name:
                    return node
            return None

        rx = re.compile(value) if value is not None else None
        for node in self.all_nodes():
            if attr is not None:
                k = node.knob(attr)
                if k is None:
                    continue
                if rx is None or rx.search(k.value.raw):
                    return node
            else:
                if rx is None:
                    return node
                for k in node.knobs:
                    if rx.search(k.value.raw):
                        return node
                        break
        return None

    def find_all(
        self,
        node_class: Optional[str] = None,
        name_pattern: Optional[str] = None,
        *,
        attr: Optional[str] = None,
        value: Optional[str] = None,
    ) -> list[Node]:
        """Filter nodes by class, name regex, and/or knob attr/value regex.

        Parameters
        ----------
        node_class:    keep only nodes of this class
        name_pattern:  regex matched against the node name
        attr:          keep only nodes that have this knob name
        value:         regex matched against the knob's raw value
                       (all knobs when attr is None, specific knob otherwise)
        """
        name_rx = re.compile(name_pattern) if name_pattern else None
        val_rx = re.compile(value) if value is not None else None
        results: list[Node] = []
        for node in self.all_nodes():
            if node_class is not None and node.node_class != node_class:
                continue
            if name_rx is not None and not name_rx.search(node.name):
                continue
            if attr is not None or val_rx is not None:
                if attr is not None:
                    k = node.knob(attr)
                    if k is None:
                        continue
                    if val_rx is not None and not val_rx.search(k.value.raw):
                        continue
                else:
                    # val_rx without attr: any knob must match
                    if val_rx is not None and not any(
                        val_rx.search(k.value.raw) for k in node.knobs
                    ):
                        continue
            results.append(node)
        return results

    def root(self) -> Optional[Node]:
        """Return the Root node, or None."""
        for node in self.nodes:
            if node.node_class == "Root":
                return node
        return None

    def query(self) -> "NodeQuery":
        """Return a NodeQuery over all nodes in the script."""
        from .query import NodeQuery

        return NodeQuery(self.all_nodes())

    # ------------------------------------------------------------------
    # Diagnostic helpers
    # ------------------------------------------------------------------

    @property
    def has_errors(self) -> bool:
        return any(d.severity == DiagnosticSeverity.ERROR for d in self.diagnostics)

    def errors(self) -> list[Diagnostic]:
        return [d for d in self.diagnostics if d.severity == DiagnosticSeverity.ERROR]

    def warnings(self) -> list[Diagnostic]:
        return [d for d in self.diagnostics if d.severity == DiagnosticSeverity.WARNING]

    def __repr__(self) -> str:
        return (
            f"<Script version={self.nuke_version!r} "
            f"nodes={len(self.nodes)} diagnostics={len(self.diagnostics)}>"
        )
