"""Character-level lexer for Foundry Nuke .nk script files.

The lexer converts raw source text into a flat list of Tokens. It handles:
- Bare words (identifiers, numbers, unquoted values)
- Quoted strings (double-quoted, with backslash escapes)
- Brace blocks {...} — fully matched, including multiline and nested braces
- Bracket expressions [...] — used in set/push operations
- Shebang lines (#! ...) and comments (# ...)
- Newlines (emitted as NEWLINE tokens to assist the parser)
"""

from __future__ import annotations

from .errors import LexError
from .tokens import Token, TokenKind


class Lexer:
    """Tokenise a Nuke .nk source string.

    Usage::

        lexer = Lexer(source_text)
        tokens = lexer.tokenize()
        if lexer.errors:
            for err in lexer.errors:
                print(err)
    """

    def __init__(self, source: str) -> None:
        self._src = source
        self._pos = 0
        self._line = 1
        self._col = 1
        self.errors: list[LexError] = []

    # ------------------------------------------------------------------
    # Public entry point
    # ------------------------------------------------------------------

    def tokenize(self) -> list[Token]:
        """Return all tokens for the source text, including a trailing EOF."""
        tokens: list[Token] = []
        while self._pos < len(self._src):
            ch = self._src[self._pos]

            # Shebang (#! at very start of file)
            if ch == "#" and self._pos == 0 and self._src[self._pos: self._pos + 2] == "#!":
                tokens.append(self._read_shebang())
                continue

            # Comment
            if ch == "#":
                tokens.append(self._read_comment())
                continue

            # Newline
            if ch == "\n":
                tok = Token(
                    kind=TokenKind.NEWLINE,
                    value="\n",
                    line=self._line,
                    col=self._col,
                    end_line=self._line,
                    end_col=self._col + 1,
                )
                tokens.append(tok)
                self._advance()
                continue

            # Carriage return (treat \r\n as single newline)
            if ch == "\r":
                self._advance()
                continue

            # Whitespace (space, tab — skip silently)
            if ch in (" ", "\t"):
                self._advance()
                continue

            # Quoted string
            if ch == '"':
                tokens.append(self._read_string())
                continue

            # Brace block
            if ch == "{":
                tokens.append(self._read_brace_block())
                continue

            # Bracket expression  [stack 0]  or  [value ...]
            if ch == "[":
                tokens.append(self._read_bracket_expr())
                continue

            # Bare word (identifier / number / unquoted value including $var refs)
            if self._is_word_char(ch):
                tokens.append(self._read_word())
                continue

            # Unrecognised character — record error and skip
            err = LexError(
                f"unexpected character {ch!r}",
                self._line,
                self._col,
                self._current_line_text(),
            )
            self.errors.append(err)
            self._advance()

        tokens.append(
            Token(TokenKind.EOF, "", self._line,
                  self._col, self._line, self._col)
        )
        return tokens

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _advance(self) -> str:
        """Consume one character and update position tracking."""
        ch = self._src[self._pos]
        self._pos += 1
        if ch == "\n":
            self._line += 1
            self._col = 1
        else:
            self._col += 1
        return ch

    def _peek(self, offset: int = 0) -> str:
        idx = self._pos + offset
        if idx < len(self._src):
            return self._src[idx]
        return ""

    @staticmethod
    def _is_word_char(ch: str) -> bool:
        # Allow identifiers, numbers, signs, slashes, dots, colons, $, %, @, ~, ^, *, =, <, >, |, &, +
        return ch not in (" ", "\t", "\n", "\r", "{", "}", "[", "]", '"', "#")

    def _current_line_text(self) -> str:
        start = self._src.rfind("\n", 0, self._pos)
        start = 0 if start == -1 else start + 1
        end = self._src.find("\n", self._pos)
        end = len(self._src) if end == -1 else end
        return self._src[start:end]

    # ------------------------------------------------------------------
    # Token readers
    # ------------------------------------------------------------------

    def _read_shebang(self) -> Token:
        start_line, start_col = self._line, self._col
        buf: list[str] = []
        while self._pos < len(self._src) and self._src[self._pos] != "\n":
            buf.append(self._advance())
        return Token(
            kind=TokenKind.SHEBANG,
            value="".join(buf),
            line=start_line,
            col=start_col,
            end_line=self._line,
            end_col=self._col,
        )

    def _read_comment(self) -> Token:
        start_line, start_col = self._line, self._col
        buf: list[str] = []
        while self._pos < len(self._src) and self._src[self._pos] != "\n":
            buf.append(self._advance())
        return Token(
            kind=TokenKind.COMMENT,
            value="".join(buf),
            line=start_line,
            col=start_col,
            end_line=self._line,
            end_col=self._col,
        )

    def _read_string(self) -> Token:
        """Read a double-quoted string, handling backslash escapes."""
        start_line, start_col = self._line, self._col
        buf: list[str] = [self._advance()]  # consume opening "
        while self._pos < len(self._src):
            ch = self._src[self._pos]
            if ch == "\\":
                buf.append(self._advance())  # backslash
                if self._pos < len(self._src):
                    buf.append(self._advance())  # escaped char
                continue
            buf.append(self._advance())
            if ch == '"':
                break
        else:
            self.errors.append(
                LexError("unterminated string literal", start_line, start_col)
            )
        return Token(
            kind=TokenKind.STRING,
            value="".join(buf),
            line=start_line,
            col=start_col,
            end_line=self._line,
            end_col=self._col,
        )

    def _read_brace_block(self) -> Token:
        """Read a balanced {...} block, handling arbitrary nesting and strings inside."""
        start_line, start_col = self._line, self._col
        buf: list[str] = []
        depth = 0
        while self._pos < len(self._src):
            ch = self._src[self._pos]
            if ch == "{":
                depth += 1
                buf.append(self._advance())
            elif ch == "}":
                depth -= 1
                buf.append(self._advance())
                if depth == 0:
                    break
            elif ch == '"':
                # Consume string inside brace block verbatim to avoid
                # misinterpreting braces inside quoted strings.
                str_start = self._pos
                buf.append(self._advance())  # opening "
                while self._pos < len(self._src):
                    c2 = self._src[self._pos]
                    if c2 == "\\":
                        buf.append(self._advance())
                        if self._pos < len(self._src):
                            buf.append(self._advance())
                        continue
                    buf.append(self._advance())
                    if c2 == '"':
                        break
                _ = str_start  # used only for clarity
            else:
                buf.append(self._advance())
        else:
            self.errors.append(
                LexError("unterminated brace block", start_line, start_col)
            )
        return Token(
            kind=TokenKind.BRACE_BLOCK,
            value="".join(buf),
            line=start_line,
            col=start_col,
            end_line=self._line,
            end_col=self._col,
        )

    def _read_bracket_expr(self) -> Token:
        """Read a [...] expression (used in 'set X [stack 0]')."""
        start_line, start_col = self._line, self._col
        buf: list[str] = []
        depth = 0
        while self._pos < len(self._src):
            ch = self._src[self._pos]
            if ch == "[":
                depth += 1
                buf.append(self._advance())
            elif ch == "]":
                depth -= 1
                buf.append(self._advance())
                if depth == 0:
                    break
            else:
                buf.append(self._advance())
        else:
            self.errors.append(
                LexError("unterminated bracket expression",
                         start_line, start_col)
            )
        return Token(
            kind=TokenKind.BRACKET_EXPR,
            value="".join(buf),
            line=start_line,
            col=start_col,
            end_line=self._line,
            end_col=self._col,
        )

    def _read_word(self) -> Token:
        """Read a bare word token (identifier, number, unquoted value, $variable)."""
        start_line, start_col = self._line, self._col
        buf: list[str] = []
        while self._pos < len(self._src) and self._is_word_char(self._src[self._pos]):
            buf.append(self._advance())
        return Token(
            kind=TokenKind.WORD,
            value="".join(buf),
            line=start_line,
            col=start_col,
            end_line=self._line,
            end_col=self._col,
        )
