"""Builder: converts the raw AST from the Parser into the Script object model.

The builder's primary responsibility beyond creating Node/GroupNode instances
is simulating Nuke's execution-stack connectivity model:

  1. Every node pops N items from the execution stack as its inputs, where N is
     the value of its 'inputs' knob (or a class-specific default).
  2. After processing its inputs, a node pushes itself onto the execution stack.
  3. 'set X [stack N]' captures the node at depth N without consuming it.
  4. 'push $X' re-pushes a captured variable, enabling fan-out and merges.
  5. Unresolved 'push $X' (where X was never set) push None, indicating a
     missing connection.
"""

from __future__ import annotations

from .models import (Knob, Node, Script, GroupNode, KnobValue,
                     VariableReference, VariableAssignment)
from .parser import (RawKnob, RawNode, RawSetOp, RawPushOp, RawAddLayer,
                     RawStatement)

# ---------------------------------------------------------------------------
# Node class default-input-count table
# ---------------------------------------------------------------------------

# These node classes produce no output visible as downstream inputs and/or have
# zero implicit stream inputs by default.
_ZERO_INPUT_CLASSES: frozenset[str] = frozenset(
    {
        "Root",
        "Viewer",
        "Read",
        "ReadGeo",
        "ReadGeo2",
        "Constant",
        "CheckerBoard",
        "CheckerBoard2",
        "ColorBars",
        "ColorWheel",
        "StickyNote",
        "BackdropNode",
        "Camera",
        "Camera2",
        "Camera3",
        "Light",
        "Light2",
        "DirectLight",
        "PointLight",
        "SpotLight",
        "Environment",
        "Axis",
        "Axis2",
        "Axis3",
    }
)


def _default_input_count(node_class: str, knob_inputs: int | None) -> int:
    """Return the number of stream inputs a node should consume from the stack."""
    # If the script explicitly sets 'inputs N', trust it.
    if knob_inputs is not None:
        return knob_inputs
    # Classes that default to 0 inputs
    if node_class in _ZERO_INPUT_CLASSES:
        return 0
    # Everything else defaults to 1 input
    return 1


# ---------------------------------------------------------------------------
# Builder
# ---------------------------------------------------------------------------


class ScriptBuilder:
    """Convert raw AST (header dict + RawStatement list) into a Script."""

    def __init__(self) -> None:
        self._execution_stack: list[Node | None] = []
        self._variables: dict[str, Node | None] = {}
        self._variable_assignments: dict[str, VariableAssignment] = {}
        self._variable_refs: list[VariableReference] = []
        self._script = Script()

    def build(
        self,
        header: dict[str, str],
        statements: list[RawStatement],
    ) -> Script:
        self._apply_header(header)
        for stmt in statements:
            self._process_statement(stmt)
        self._script._variables = self._variable_assignments
        self._script._variable_refs = self._variable_refs
        return self._script

    # ------------------------------------------------------------------
    # Header
    # ------------------------------------------------------------------

    def _apply_header(self, header: dict[str, str]) -> None:
        self._script.shebang = header.get("shebang")
        self._script.nuke_version = header.get("version")
        self._script.window_layout_xml = header.get("window_layout_xml")

    # ------------------------------------------------------------------
    # Statement processing
    # ------------------------------------------------------------------

    def _process_statement(self, stmt: RawStatement) -> None:
        if isinstance(stmt, RawSetOp):
            self._handle_set(stmt)
        elif isinstance(stmt, RawPushOp):
            self._handle_push(stmt)
        elif isinstance(stmt, RawAddLayer):
            self._script.add_layer_declarations.append(stmt.declaration)
            self._script._ordered_statements.append(stmt)
        elif isinstance(stmt, RawNode):
            node = self._build_node(stmt)
            self._connect_inputs(node, stmt)
            self._script.nodes.append(node)
            self._script._ordered_statements.append(node)
            # Push node onto execution stack (it becomes available as an input)
            self._execution_stack.append(node)

    # ------------------------------------------------------------------
    # Stack operations
    # ------------------------------------------------------------------

    def _handle_set(self, op: RawSetOp) -> None:
        """Capture stack[op.stack_index] into _variables without consuming."""
        idx = op.stack_index
        if len(self._execution_stack) > idx:
            captured = self._execution_stack[-(idx + 1)]
        else:
            captured = None
        self._variables[op.name] = captured
        self._variable_assignments[op.name] = VariableAssignment(
            name=op.name, stack_index=op.stack_index, source_line=op.source_line
        )
        self._script._ordered_statements.append(op)

    def _handle_push(self, op: RawPushOp) -> None:
        """Push a previously-captured variable back onto the execution stack."""
        node = self._variables.get(op.ref)
        ref = VariableReference(
            name=op.ref, source_line=op.source_line, resolved=node)
        self._variable_refs.append(ref)
        self._execution_stack.append(node)  # None if unresolved
        self._script._ordered_statements.append(op)

    # ------------------------------------------------------------------
    # Input connection
    # ------------------------------------------------------------------

    def _connect_inputs(self, node: Node, raw: RawNode) -> None:
        """Pop N items from the execution stack as this node's inputs."""
        # Read the 'inputs' knob value if present
        knob_inputs: int | None = None
        for k in raw.knobs:
            if k.name == "inputs":
                try:
                    knob_inputs = int(k.raw_value.strip())
                except ValueError:
                    pass
                break

        n = _default_input_count(raw.node_class, knob_inputs)
        inputs: list[Node | None] = []
        for _ in range(n):
            if self._execution_stack:
                inputs.insert(0, self._execution_stack.pop())
            else:
                inputs.insert(0, None)
        node._inputs = inputs

    # ------------------------------------------------------------------
    # Node construction
    # ------------------------------------------------------------------

    def _build_node(self, raw: RawNode) -> Node:
        knobs = [self._build_knob(rk) for rk in raw.knobs]

        if raw.is_group:
            # Build children, simulating stack within the group context.
            # Groups have their own isolated stack; we save and restore.
            saved_stack = self._execution_stack
            self._execution_stack = []
            children: list[Node] = []
            for child_stmt in raw.children:
                self._process_statement(child_stmt)
                # Collect nodes that were appended to self._script.nodes
                # from this group's children processing — we need to move
                # them into the group's children list instead.
            # Any nodes added to script.nodes during group processing are
            # actually children — move the last N nodes.
            n_children = len(raw.children)
            group_children = self._script.nodes[-n_children:]
            del self._script.nodes[-n_children:]
            # Also remove their ordered statements
            # (re-add them nested under the group in serializer)
            del self._script._ordered_statements[-n_children:]
            children = group_children
            self._execution_stack = saved_stack
            node: Node = GroupNode(
                node_class=raw.node_class,
                knobs=knobs,
                children=children,
                is_unclosed=raw.is_unclosed,
                source_line=raw.source_line,
                source_end_line=raw.source_end_line,
            )
        else:
            node = Node(
                node_class=raw.node_class,
                knobs=knobs,
                source_line=raw.source_line,
                source_end_line=raw.source_end_line,
            )

        node._script_ref = self._script
        return node

    def _build_knob(self, rk: RawKnob) -> Knob:
        value = KnobValue.classify(rk.raw_value)
        return Knob(
            name=rk.name,
            value=value,
            source_line=rk.source_line,
            raw_line=rk.raw_line,
        )
