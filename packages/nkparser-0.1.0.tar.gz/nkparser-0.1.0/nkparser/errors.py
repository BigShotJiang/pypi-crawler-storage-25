"""Exception hierarchy for nkparser."""

from __future__ import annotations


class NkParserError(Exception):
    """Base for all nkparser errors."""


class LexError(NkParserError):
    """Raised when the lexer encounters an unrecognised character sequence."""

    def __init__(self, message: str, line: int, col: int, source: str = "") -> None:
        self.line = line
        self.col = col
        self.source = source
        super().__init__(f"[{line}:{col}] {message}" +
                         (f"\n  {source}" if source else ""))


class ParseError(NkParserError):
    """Raised when the parser encounters unexpected tokens."""

    def __init__(self, message: str, line: int, col: int, source: str = "") -> None:
        self.line = line
        self.col = col
        self.source = source
        super().__init__(f"[{line}:{col}] {message}" +
                         (f"\n  {source}" if source else ""))


class ValidationError(NkParserError):
    """Raised for script-level structural violations (also collected into Script.diagnostics)."""


class SerializationError(NkParserError):
    """Raised when the serializer cannot produce valid .nk output."""
