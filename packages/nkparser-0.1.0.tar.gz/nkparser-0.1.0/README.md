# nkparser

`nkparser` parses, queries, validates, and round-trips Foundry Nuke `.nk` script files.

## Install

This project is managed with `uv`.

```bash
uv sync
```

Install the package into the current environment:

```bash
uv pip install .
```

Install with Graphviz rendering support:

```bash
uv pip install '.[graphviz]'
```

## CLI

The package exposes two console scripts:

```bash
uv run nkparser --help
uv run nkparse --help
```

You can also run it as a module:

```bash
uv run python -m nkparser --help
```

### Examples

```bash
uv run nkparser info tests/fixtures/minimal.nk
uv run nkparser validate tests/fixtures/malformed_unclosed.nk
uv run nkparser tree tests/fixtures/complex_groups.nk --knobs
uv run nkparser nodes tests/fixtures/minimal.nk --class Grade
uv run nkparser dot tests/fixtures/minimal.nk -o graph.dot
uv run nkparser dot tests/fixtures/minimal.nk -o graph.dot --render --dot-command /opt/homebrew/bin/dot
```

## Development

Sync the dev environment:

```bash
uv sync --dev
```

Run checks:

```bash
uv run pytest
uv run ruff check .
uv run mypy
```

Build distributions:

```bash
uv build
```

## Python API

```python
import nkparser

script = nkparser.Script.from_file("comp.nk")

print(script.nuke_version)
print(len(list(script.all_nodes())))

reads = script.query().of_class("Read").all()
grade = script.find("Grade1")

if grade:
    grade.set("disable", "true")

script.write("comp_modified.nk")
```
