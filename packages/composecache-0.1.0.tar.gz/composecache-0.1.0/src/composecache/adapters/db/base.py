from __future__ import annotations

from abc import ABC, abstractmethod
from datetime import datetime

from ...types import CacheEntry


class DBAdapter(ABC):
    @abstractmethod
    def connect(self) -> None:
        raise NotImplementedError

    @abstractmethod
    def migrate(self) -> None:
        raise NotImplementedError

    @abstractmethod
    def get_by_key(self, key: str) -> CacheEntry | None:
        raise NotImplementedError

    @abstractmethod
    def similarity_search(self, embedding: list[float], k: int) -> list[CacheEntry]:
        raise NotImplementedError

    @abstractmethod
    def insert(self, entry: CacheEntry) -> None:
        raise NotImplementedError

    @abstractmethod
    def delete(self, key: str) -> None:
        raise NotImplementedError

    @abstractmethod
    def purge(self, older_than: datetime | None = None, model: str | None = None) -> int:
        raise NotImplementedError

    @abstractmethod
    def stats(self) -> dict[str, float]:
        raise NotImplementedError

    @abstractmethod
    def close(self) -> None:
        raise NotImplementedError
