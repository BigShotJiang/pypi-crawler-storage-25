from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Any

import psycopg

from ...types import CacheEntry, ComposeCacheError, ComposeCacheErrorCode
from .base import DBAdapter


class PostgresAdapter(DBAdapter):
    def __init__(self, connection_string: str) -> None:
        self._connection_string = connection_string
        self._conn: psycopg.Connection | None = None

    def connect(self) -> None:
        try:
            self._conn = psycopg.connect(self._connection_string)
            with self._conn.cursor() as cur:
                cur.execute("SELECT 1")
        except Exception as exc:
            raise ComposeCacheError(
                ComposeCacheErrorCode.DB_CONNECTION_FAILED,
                "Failed to connect to PostgreSQL",
                {"cause": str(exc)},
            ) from exc

    def migrate(self) -> None:
        if not self._conn:
            self.connect()
        assert self._conn is not None

        migration_path = Path(__file__).resolve().parents[2] / "sql" / "001_init.sql"
        try:
            migration = migration_path.read_text(encoding="utf-8")
            with self._conn.cursor() as cur:
                cur.execute(migration)
            self._conn.commit()
        except Exception as exc:
            raise ComposeCacheError(
                ComposeCacheErrorCode.MIGRATION_FAILED,
                "Failed to run migration",
                {"cause": str(exc)},
            ) from exc

    def get_by_key(self, key: str) -> CacheEntry | None:
        if not self._conn:
            return None
        try:
            with self._conn.cursor(row_factory=psycopg.rows.dict_row) as cur:
                cur.execute("SELECT * FROM llm_cache WHERE cache_key = %s LIMIT 1", (key,))
                row = cur.fetchone()
            if not row:
                return None
            return self._map_row(row)
        except Exception:
            return None

    def similarity_search(self, embedding: list[float], k: int) -> list[CacheEntry]:
        if not self._conn:
            return []
        try:
            vector = "[" + ",".join(str(v) for v in embedding) + "]"
            with self._conn.cursor(row_factory=psycopg.rows.dict_row) as cur:
                cur.execute(
                    """
                    SELECT * FROM llm_cache
                    WHERE query_embedding IS NOT NULL
                    ORDER BY query_embedding <=> %s::vector
                    LIMIT %s
                    """,
                    (vector, k),
                )
                rows = cur.fetchall()
            return [self._map_row(row) for row in rows]
        except Exception:
            return []

    def insert(self, entry: CacheEntry) -> None:
        if not self._conn:
            return
        try:
            vector = (
                "[" + ",".join(str(v) for v in entry.query_embedding) + "]"
                if entry.query_embedding
                else None
            )
            with self._conn.cursor() as cur:
                cur.execute(
                    """
                    INSERT INTO llm_cache (
                      cache_key, query_text, query_normalized, response, model, params_hash,
                      query_embedding, doc_fingerprint, uncertainty, is_sub_query,
                      parent_query_id, tokens_saved, expires_at
                    ) VALUES (%s, %s, %s, %s, %s, %s, %s::vector, %s, %s, %s, %s, %s, %s)
                    ON CONFLICT (cache_key)
                    DO UPDATE SET
                      hit_count = llm_cache.hit_count + 1,
                      last_hit_at = NOW()
                    """,
                    (
                        entry.cache_key,
                        entry.query_text,
                        entry.query_normalized,
                        entry.response,
                        entry.model,
                        entry.params_hash,
                        vector,
                        entry.doc_fingerprint,
                        entry.uncertainty,
                        entry.is_sub_query,
                        entry.parent_query_id,
                        entry.tokens_saved,
                        entry.expires_at,
                    ),
                )
            self._conn.commit()
        except Exception:
            self._conn.rollback()

    def delete(self, key: str) -> None:
        if not self._conn:
            return
        try:
            with self._conn.cursor() as cur:
                cur.execute("DELETE FROM llm_cache WHERE cache_key = %s", (key,))
            self._conn.commit()
        except Exception:
            self._conn.rollback()

    def purge(self, older_than: datetime | None = None, model: str | None = None) -> int:
        if not self._conn:
            return 0

        conditions: list[str] = []
        params: list[object] = []

        if older_than is not None:
            conditions.append("created_at < %s")
            params.append(older_than)
        if model is not None:
            conditions.append("model = %s")
            params.append(model)

        where_clause = f" WHERE {' AND '.join(conditions)}" if conditions else ""
        try:
            with self._conn.cursor() as cur:
                cur.execute(f"DELETE FROM llm_cache{where_clause}", tuple(params))
                deleted = cur.rowcount or 0
            self._conn.commit()
            return deleted
        except Exception:
            self._conn.rollback()
            return 0

    def stats(self) -> dict[str, float]:
        if not self._conn:
            return {"total_entries": 0.0, "hit_rate": 0.0}
        try:
            with self._conn.cursor(row_factory=psycopg.rows.dict_row) as cur:
                cur.execute(
                    """
                    SELECT
                      COUNT(*)::int AS total,
                      COALESCE(SUM(CASE WHEN hit_count > 0 THEN 1 ELSE 0 END), 0)::int AS hits
                    FROM llm_cache
                    """
                )
                row = cur.fetchone() or {"total": 0, "hits": 0}
            total = float(row["total"])
            hits = float(row["hits"])
            hit_rate = 0.0 if total == 0 else hits / total
            return {"total_entries": total, "hit_rate": hit_rate}
        except Exception:
            return {"total_entries": 0.0, "hit_rate": 0.0}

    def close(self) -> None:
        if self._conn:
            self._conn.close()
            self._conn = None

    def _map_row(self, row: dict[str, Any]) -> CacheEntry:
        query_embedding = row.get("query_embedding")
        embedding: list[float] | None = None
        if isinstance(query_embedding, str):
            stripped = query_embedding.strip().strip("[]")
            embedding = [float(x) for x in stripped.split(",") if x.strip()] if stripped else []
        elif isinstance(query_embedding, list):
            embedding = [float(x) for x in query_embedding]

        doc_fingerprint = row.get("doc_fingerprint")
        uncertainty = self._to_float(row.get("uncertainty"), 0.0)
        parent_query_id = self._to_int(row.get("parent_query_id"))
        hit_count = self._to_int(row.get("hit_count"), 0)
        tokens_saved = self._to_int(row.get("tokens_saved"), 0)
        created_at = row.get("created_at") if isinstance(row.get("created_at"), datetime) else None
        last_hit_at = row.get("last_hit_at") if isinstance(row.get("last_hit_at"), datetime) else None
        expires_at = row.get("expires_at") if isinstance(row.get("expires_at"), datetime) else None

        return CacheEntry(
            cache_key=str(row.get("cache_key", "")),
            query_text=str(row.get("query_text", "")),
            query_normalized=str(row.get("query_normalized", "")),
            response=str(row.get("response", "")),
            model=str(row.get("model", "")),
            params_hash=str(row.get("params_hash", "")),
            query_embedding=embedding,
            doc_fingerprint=doc_fingerprint if isinstance(doc_fingerprint, bytes) else None,
            uncertainty=uncertainty,
            is_sub_query=bool(row.get("is_sub_query", False)),
            parent_query_id=parent_query_id,
            hit_count=hit_count,
            tokens_saved=tokens_saved,
            created_at=created_at,
            last_hit_at=last_hit_at,
            expires_at=expires_at,
        )

    def _to_int(self, value: Any, default: int = 0) -> int:
        if value is None:
            return default
        try:
            return int(value)
        except (TypeError, ValueError):
            return default

    def _to_float(self, value: Any, default: float = 0.0) -> float:
        try:
            return float(value)
        except (TypeError, ValueError):
            return default
