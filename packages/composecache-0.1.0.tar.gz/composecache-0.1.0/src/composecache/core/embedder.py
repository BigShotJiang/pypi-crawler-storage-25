from __future__ import annotations

import hashlib


class TransformerEmbedder:
    def __init__(self, dims: int = 384) -> None:
        self.dims = dims

    def embed(self, text: str) -> list[float]:
        # Deterministic fallback embedding for environments without local transformer setup.
        output: list[float] = []
        for i in range(self.dims):
            digest = hashlib.sha256(f"{text}:{i}".encode("utf-8")).digest()
            value = int.from_bytes(digest[:4], byteorder="big", signed=False) / 0xFFFFFFFF
            output.append((value * 2) - 1)
        return output
