from __future__ import annotations

import math
import re
import time
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Protocol

from ..adapters.db.base import DBAdapter
from ..adapters.llm.base import LLMAdapter, LLMCompletionRequest, LLMMessage
from ..core.composer import Composer
from ..core.decomposer import Decomposer
from ..core.hasher import Hasher
from ..core.minhash import MinHash
from ..core.normalizer import Normalizer
from ..core.uncertainty import UncertaintyEstimator
from ..types import (
    CacheEntry,
    CacheType,
    CompletionRequest,
    CompletionResponse,
    ComposeCacheConfig,
    DecompositionResult,
    SubQuery,
    SubQueryHit,
)


class Orchestrator:
    def __init__(
        self,
        db: DBAdapter,
        llm: LLMAdapter,
        embedder: "Embedder",
        config: ComposeCacheConfig,
    ) -> None:
        self._db = db
        self._llm = llm
        self._embedder = embedder
        self._config = config
        self._uncertainty = UncertaintyEstimator()
        self._decomposer = Decomposer(
            llm=llm,
            enabled=config.decomposition.enabled,
            model=config.decomposition.model,
        )
        self._composer = Composer(llm=llm, model=config.decomposition.model)

    def complete(self, request: CompletionRequest, ttl: str | None = None) -> CompletionResponse:
        start = time.time()
        query = self._extract_query(request)
        doc_fingerprint = (
            MinHash.from_document_ids([doc.id for doc in request.documents]) if request.documents else None
        )

        decomposition = self._decomposer.classify(query)

        if decomposition.type.value == "atomic":
            answer = self._probe_and_resolve(query, doc_fingerprint, request, is_sub_query=False, ttl=ttl)
            return CompletionResponse(
                content=answer.content,
                cache_type=CacheType(answer.from_cache if answer.cached else "miss"),
                sub_query_hits=[
                    SubQueryHit(id=0, query=query, hit=answer.cached, from_cache=answer.from_cache)
                ],
                tokens_saved=answer.tokens_saved,
                latency_ms=int((time.time() - start) * 1000),
                cost_saved=self._estimate_cost_saved(answer.tokens_saved),
            )

        answers: dict[int, ResolvedAnswer] = {}

        independent = [sq for sq in decomposition.sub_queries if not sq.depends_on]
        for sq in independent:
            answers[sq.id] = self._probe_and_resolve(sq.text, doc_fingerprint, request, is_sub_query=True, ttl=ttl)

        dependent = [sq for sq in self._topological_order(decomposition.sub_queries) if sq.depends_on]
        for sq in dependent:
            resolved_query = self._substitute_dependencies(sq.text, sq.depends_on, answers)
            answers[sq.id] = self._probe_and_resolve(
                resolved_query,
                doc_fingerprint,
                request,
                is_sub_query=True,
                ttl=ttl,
            )

        composed = self._composer.compose(
            original_query=query,
            query_type=decomposition.type,
            sub_queries=decomposition.sub_queries,
            answers={k: v.content for k, v in answers.items()},
        )

        sub_hits = self._to_sub_query_hits(decomposition, answers)
        tokens_saved = sum(answers[hit.id].tokens_saved for hit in sub_hits if hit.id in answers)

        return CompletionResponse(
            content=composed,
            cache_type=self._determine_cache_type(sub_hits),
            sub_query_hits=sub_hits,
            tokens_saved=tokens_saved,
            latency_ms=int((time.time() - start) * 1000),
            cost_saved=self._estimate_cost_saved(tokens_saved),
        )

    def _probe_and_resolve(
        self,
        query: str,
        doc_fingerprint: bytes | None,
        request: CompletionRequest,
        is_sub_query: bool,
        ttl: str | None,
    ) -> "ResolvedAnswer":
        normalized = Normalizer.normalize(query)
        params_hash = Hasher.hash_params(
            {
                "model": request.model,
                "temperature": request.temperature or 0,
                "top_p": request.top_p or 1,
                "max_tokens": request.max_tokens or 0,
            }
        )
        exact_key = Hasher.hash(normalized, doc_fingerprint, params_hash)

        exact_hit = self._db.get_by_key(exact_key)
        if exact_hit:
            return ResolvedAnswer(
                content=exact_hit.response,
                cached=True,
                from_cache="exact",
                tokens_saved=exact_hit.tokens_saved,
            )

        embedding = self._embedder.embed(normalized)
        candidates = self._db.similarity_search(embedding, 5)

        for candidate in candidates:
            if not candidate.query_embedding:
                continue

            query_sim = self._cosine_similarity(embedding, candidate.query_embedding)
            if doc_fingerprint and candidate.doc_fingerprint:
                doc_sim = MinHash.jaccard_from_signatures(doc_fingerprint, candidate.doc_fingerprint)
            else:
                doc_sim = 1.0

            if (
                query_sim >= self._config.thresholds.query
                and doc_sim >= self._config.thresholds.document
                and candidate.uncertainty <= self._config.thresholds.uncertainty
            ):
                return ResolvedAnswer(
                    content=candidate.response,
                    cached=True,
                    from_cache="semantic",
                    tokens_saved=candidate.tokens_saved,
                )

        llm_response = self._llm.complete(
            LLMCompletionRequest(
                model=request.model,
                messages=[LLMMessage(role="user", content=query)],
                temperature=request.temperature,
                top_p=request.top_p,
                max_tokens=request.max_tokens,
            )
        )

        uncertainty = self._uncertainty.estimate(query, llm_response.content, llm_response.logprobs)
        usage_tokens = (
            llm_response.usage.total_tokens
            if llm_response.usage is not None
            else max(1, math.ceil(len(llm_response.content) / 4))
        )

        if uncertainty <= self._config.thresholds.uncertainty and not self._is_refusal(llm_response.content):
            self._db.insert(
                CacheEntry(
                    cache_key=exact_key,
                    query_text=query,
                    query_normalized=normalized,
                    response=llm_response.content,
                    model=request.model,
                    params_hash=params_hash,
                    query_embedding=embedding,
                    doc_fingerprint=doc_fingerprint,
                    uncertainty=uncertainty,
                    is_sub_query=is_sub_query,
                    tokens_saved=usage_tokens,
                    expires_at=self._to_expiry(ttl),
                )
            )

        return ResolvedAnswer(
            content=llm_response.content,
            cached=False,
            from_cache="miss",
            tokens_saved=0,
        )

    def _extract_query(self, request: CompletionRequest) -> str:
        for message in reversed(request.messages):
            if message.role == "user":
                return message.content
        return ""

    def _to_sub_query_hits(
        self, decomposition: DecompositionResult, answers: dict[int, "ResolvedAnswer"]
    ) -> list[SubQueryHit]:
        out: list[SubQueryHit] = []
        for sq in decomposition.sub_queries:
            answer = answers.get(sq.id)
            out.append(
                SubQueryHit(
                    id=sq.id,
                    query=sq.text,
                    hit=answer.cached if answer else False,
                    from_cache=answer.from_cache if answer else "miss",
                )
            )
        return out

    def _determine_cache_type(self, hits: list[SubQueryHit]) -> CacheType:
        if not hits:
            return CacheType.MISS
        total_hits = len([h for h in hits if h.hit])
        if total_hits == 0:
            return CacheType.MISS
        if total_hits == len(hits):
            return CacheType.EXACT if all(h.from_cache == "exact" for h in hits) else CacheType.SEMANTIC
        return CacheType.PARTIAL

    def _topological_order(self, sub_queries: list[SubQuery]) -> list[SubQuery]:
        by_id = {sq.id: sq for sq in sub_queries}
        visited: set[int] = set()
        order: list[SubQuery] = []

        def visit(sq_id: int) -> None:
            if sq_id in visited:
                return
            visited.add(sq_id)
            sq = by_id.get(sq_id)
            if not sq:
                return
            for dep in sq.depends_on:
                visit(dep)
            order.append(sq)

        for sq in sub_queries:
            visit(sq.id)
        return order

    def _substitute_dependencies(
        self, text: str, dependencies: list[int], answers: dict[int, "ResolvedAnswer"]
    ) -> str:
        resolved = text
        for dep in dependencies:
            dep_content = answers[dep].content if dep in answers else ""
            resolved = re.sub(r"\{" + str(dep) + r"\}", dep_content, resolved)
        return resolved

    def _to_expiry(self, ttl: str | None) -> datetime | None:
        if not ttl:
            return None
        match = re.match(r"^(\d+)([smhdw])$", ttl.lower())
        if not match:
            return None
        value = int(match.group(1))
        unit = match.group(2)

        if unit == "s":
            delta = timedelta(seconds=value)
        elif unit == "m":
            delta = timedelta(minutes=value)
        elif unit == "h":
            delta = timedelta(hours=value)
        elif unit == "d":
            delta = timedelta(days=value)
        else:
            delta = timedelta(weeks=value)

        return datetime.now(tz=timezone.utc) + delta

    def _cosine_similarity(self, a: list[float], b: list[float]) -> float:
        length = min(len(a), len(b))
        if length == 0:
            return 0.0

        dot = 0.0
        norm_a = 0.0
        norm_b = 0.0
        for i in range(length):
            dot += a[i] * b[i]
            norm_a += a[i] * a[i]
            norm_b += b[i] * b[i]
        if norm_a == 0 or norm_b == 0:
            return 0.0
        return dot / ((norm_a**0.5) * (norm_b**0.5))

    def _estimate_cost_saved(self, tokens_saved: int) -> float:
        return round(tokens_saved * 0.000002, 6)

    def _is_refusal(self, text: str) -> bool:
        lower = text.lower()
        return (
            "i cannot" in lower
            or "i can't" in lower
            or "i am unable" in lower
            or "sorry, i" in lower
        )


@dataclass(slots=True)
class ResolvedAnswer:
    content: str
    cached: bool
    from_cache: str
    tokens_saved: int


class Embedder(Protocol):
    def embed(self, text: str) -> list[float]:
        ...
