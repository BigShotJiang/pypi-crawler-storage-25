from __future__ import annotations

import re
from datetime import datetime, timedelta, timezone
from typing import Any, Mapping

from .adapters.db.base import DBAdapter
from .adapters.db.postgres import PostgresAdapter
from .adapters.llm.openai_adapter import OpenAIAdapter
from .core.embedder import TransformerEmbedder
from .core.orchestrator import Orchestrator
from .types import CacheEntry, CompletionRequest, CompletionResponse, ComposeCacheConfig, Message


class _NoopDBAdapter(DBAdapter):
    def connect(self) -> None:
        return None

    def migrate(self) -> None:
        return None

    def get_by_key(self, key: str) -> CacheEntry | None:
        return None

    def similarity_search(self, embedding: list[float], k: int) -> list[CacheEntry]:
        return []

    def insert(self, entry: CacheEntry) -> None:
        return None

    def delete(self, key: str) -> None:
        return None

    def purge(self, older_than: datetime | None = None, model: str | None = None) -> int:
        return 0

    def stats(self) -> dict[str, float]:
        return {"total_entries": 0.0, "hit_rate": 0.0}

    def close(self) -> None:
        return None


class ComposeCache:
    def __init__(self, database_url: str, openai_api_key: str, ttl: str | None = "7d") -> None:
        self._config = ComposeCacheConfig(database_url=database_url, openai_api_key=openai_api_key, ttl=ttl)
        self._db: DBAdapter = PostgresAdapter(database_url)
        self._llm = OpenAIAdapter(openai_api_key)
        self._embedder = TransformerEmbedder()
        self._orchestrator = Orchestrator(self._db, self._llm, self._embedder, self._config)
        self._initialized = False

    def complete(self, request: Mapping[str, Any]) -> dict[str, Any]:
        self._ensure_initialized()

        typed_request = CompletionRequest(
            model=str(request["model"]),
            messages=self._parse_messages(request.get("messages", [])),
            documents=request.get("documents"),
            temperature=self._to_optional_float(request.get("temperature")),
            top_p=self._to_optional_float(request.get("top_p")),
            max_tokens=self._to_optional_int(request.get("max_tokens")),
        )

        result: CompletionResponse = self._orchestrator.complete(typed_request, ttl=self._config.ttl)
        return {
            "content": result.content,
            "cache_type": result.cache_type.value,
            "sub_query_hits": [
                {
                    "id": h.id,
                    "query": h.query,
                    "hit": h.hit,
                    "from": h.from_cache,
                }
                for h in result.sub_query_hits
            ],
            "tokens_saved": result.tokens_saved,
            "latency_ms": result.latency_ms,
            "cost_saved": result.cost_saved,
        }

    def stats(self) -> dict[str, Any]:
        self._ensure_initialized()
        stats = self._db.stats()
        return {
            "total_entries": int(stats.get("total_entries", 0)),
            "hit_rate": float(stats.get("hit_rate", 0.0)),
            "cost_saved_total": 0.0,
            "avg_latency_ms": 0.0,
            "top_queries": [],
        }

    def purge(self, older_than: str | None = None, model: str | None = None) -> int:
        self._ensure_initialized()
        older_than_date = self._duration_to_date(older_than) if older_than else None
        return self._db.purge(older_than=older_than_date, model=model)

    def invalidate(self, cache_key: str) -> None:
        self._ensure_initialized()
        self._db.delete(cache_key)

    def close(self) -> None:
        self._db.close()

    def _ensure_initialized(self) -> None:
        if self._initialized:
            return

        self._initialized = True
        try:
            self._db.connect()
        except Exception:
            self._db = _NoopDBAdapter()
            self._orchestrator = Orchestrator(self._db, self._llm, self._embedder, self._config)

    def _duration_to_date(self, duration: str) -> datetime:
        match = re.match(r"^(\d+)([smhdw])$", duration.lower())
        if not match:
            return datetime.fromtimestamp(0, tz=timezone.utc)

        value = int(match.group(1))
        unit = match.group(2)
        if unit == "s":
            delta = timedelta(seconds=value)
        elif unit == "m":
            delta = timedelta(minutes=value)
        elif unit == "h":
            delta = timedelta(hours=value)
        elif unit == "d":
            delta = timedelta(days=value)
        else:
            delta = timedelta(weeks=value)

        return datetime.now(tz=timezone.utc) - delta

    def _parse_messages(self, payload: Any) -> list[Message]:
        if not isinstance(payload, list):
            return []

        out: list[Message] = []
        for item in payload:
            if isinstance(item, Message):
                out.append(item)
                continue
            if isinstance(item, Mapping):
                out.append(
                    Message(
                        role=str(item.get("role", "user")),
                        content=str(item.get("content", "")),
                    )
                )
        return out

    def _to_optional_float(self, value: Any) -> float | None:
        if value is None:
            return None
        try:
            return float(value)
        except (TypeError, ValueError):
            return None

    def _to_optional_int(self, value: Any) -> int | None:
        if value is None:
            return None
        try:
            return int(value)
        except (TypeError, ValueError):
            return None
