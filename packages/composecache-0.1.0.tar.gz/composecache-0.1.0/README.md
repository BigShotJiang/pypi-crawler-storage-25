# ComposeCache Python Package

Python package for compositional semantic caching over LLM requests.

## Quick Start

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e ".[dev]"
```

```python
from composecache import ComposeCache

cache = ComposeCache(
    database_url="postgresql://dev:dev@localhost:5432/composecache",
    openai_api_key="YOUR_OPENAI_KEY",
)

response = cache.complete(
    {
        "model": "gpt-4o-mini",
        "messages": [{"role": "user", "content": "Compare GDP of France and Germany"}],
    }
)

print(response["content"])
print(response["cache_type"])
```
