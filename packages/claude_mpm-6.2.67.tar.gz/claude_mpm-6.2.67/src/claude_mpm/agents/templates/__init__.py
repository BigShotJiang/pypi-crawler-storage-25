"""Agent templates module."""
