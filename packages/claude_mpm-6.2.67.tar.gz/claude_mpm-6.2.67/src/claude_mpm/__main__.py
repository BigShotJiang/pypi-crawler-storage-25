from pathlib import Path

"""
Main entry point for claude-mpm package.

WHY: This module enables running claude-mpm as a Python module via `python -m claude_mpm`.
It's the standard Python pattern for making packages executable.

DESIGN DECISION: We only import and call the main function from the CLI module,
keeping this file minimal and focused on its single responsibility.
"""

import sys

# Add parent directory to path to ensure proper imports
sys.path.insert(0, str(Path(__file__).parent.parent))

from claude_mpm.core.env_defaults import apply_env_defaults

apply_env_defaults()

# Import main function from the new CLI module structure
from claude_mpm.cli import main

if __name__ == "__main__":
    sys.exit(main())
