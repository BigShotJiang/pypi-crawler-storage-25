"""csrd-utils: template and feature tooling for csrd services."""

from .augmentor import ServiceAugmentor

__all__ = ["ServiceAugmentor"]
