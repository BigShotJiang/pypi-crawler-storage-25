"""Shared test fixtures for {{ cookiecutter.service_name }}."""

import os
import sys
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from app import build_app

HAS_DATABASE = {{ "True" if cookiecutter.has_database else "False" }}
DB_KIND = "{{ cookiecutter.database }}"


@pytest.fixture
def client():
    if HAS_DATABASE and DB_KIND == "maria":
        os.environ.setdefault("DB_HOST", "localhost")
        os.environ.setdefault("DB_PORT", "3306")
        os.environ.setdefault("DB_USER", "sandbox")
        os.environ.setdefault("DB_PASSWORD", "sandbox")
        os.environ.setdefault("DB_NAME", "sandbox")
    elif HAS_DATABASE and DB_KIND == "postgres":
        os.environ.setdefault("DB_HOST", "localhost")
        os.environ.setdefault("DB_PORT", "5432")
        os.environ.setdefault("DB_USER", "sandbox")
        os.environ.setdefault("DB_PASSWORD", "sandbox")
        os.environ.setdefault("DB_NAME", "sandbox")

    app = build_app()
    return TestClient(app)
