"""Command-line interface for csrd-utils."""

from __future__ import annotations

import argparse
from pathlib import Path

from .augmentor import ServiceAugmentor
from .resources import features_path


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="csrd", description="csrd utilities")
    sub = parser.add_subparsers(dest="command")

    feature = sub.add_parser("feature", help="Feature operations")
    feature_sub = feature.add_subparsers(dest="feature_command")

    for name, plan in (("add", False), ("plan", True)):
        cmd = feature_sub.add_parser(name, help=f"{name} feature")
        cmd.add_argument("feature", help="Feature name, e.g. workers")
        cmd.add_argument("--service", type=Path, default=Path.cwd(), help="Service root path")
        cmd.set_defaults(plan=plan)

    return parser


def main() -> int:
    parser = _build_parser()
    args = parser.parse_args()

    if args.command != "feature" or args.feature_command not in {"add", "plan"}:
        parser.print_help()
        return 0

    with features_path() as feature_lib:
        augmentor = ServiceAugmentor(args.service, feature_lib)
        success, changes = augmentor.add_feature(args.feature, plan=args.plan)

    if not success:
        return 1

    if args.plan:
        print("Plan validated.")
    else:
        print(f"Feature '{args.feature}' added.")
        if changes:
            for change in changes:
                print(f"- {change}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
