"""Core augmentor logic for adding features to existing services."""

from __future__ import annotations

import shutil
import tempfile
from pathlib import Path
from typing import Any

import yaml  # type: ignore[import-untyped]

from .fragments import (
    ConfTestMerger,
    DockerComposeMerger,
    FragmentMergeError,
    ManifestLoader,
    RequirementsMerger,
    SettingsMerger,
)


class ServiceAugmentor:
    """Add features to an existing service."""

    def __init__(self, service_root: Path, feature_lib: Path):
        """
        Initialize augmentor.

        Parameters
        ----------
        service_root : Path
            Root directory of the service to augment
        feature_lib : Path
            Root directory containing feature manifests
        """
        self.service_root = service_root.resolve()
        self.feature_lib = feature_lib.resolve()
        self.manifest: dict[str, Any] = {}
        self.applied_changes: list[str] = []
        self.backups: dict[str, str] = {}

    def load_feature(self, feature_name: str) -> bool:
        """
        Load and validate feature manifest.

        Parameters
        ----------
        feature_name : str
            Feature name (e.g., "workers")

        Returns
        -------
        bool
            True if valid, False otherwise
        """
        manifest_path = self.feature_lib / feature_name / "manifest.yaml"

        try:
            self.manifest = ManifestLoader.load(manifest_path)
        except FileNotFoundError as e:
            print(f"❌ {e}")
            return False

        errors = ManifestLoader.validate(self.manifest)
        if errors:
            print("❌ Manifest validation failed:")
            for err in errors:
                print(f"   - {err}")
            return False

        return True

    def validate_service(self) -> bool:
        """
        Validate that service has required structure.

        Checks for src/app/, docker-compose.yml, etc.

        Returns
        -------
        bool
            True if valid
        """
        required_dirs = ["src/app", "tests"]
        required_files = ["docker-compose.yml", "requirements.txt"]

        for d in required_dirs:
            if not (self.service_root / d).is_dir():
                print(f"❌ Missing required directory: {d}")
                return False

        for f in required_files:
            if not (self.service_root / f).is_file():
                print(f"❌ Missing required file: {f}")
                return False

        return True

    def validate_requirements(self) -> list[str]:
        """
        Validate that feature requirements are met.

        Returns
        -------
        list[str]
            List of validation errors (empty if all met)
        """
        errors: list[str] = []
        requires = self.manifest.get("requires", {})

        # Check dependencies
        for dep_type, _deps in requires.items():
            if dep_type == "dependencies":
                # Would check if packages are installed
                pass
            elif dep_type == "external_services":
                # Could check if services are available in docker-compose
                pass
            elif dep_type == "settings":
                # Would check if settings exist
                pass

        return errors

    def backup_file(self, file_path: Path) -> None:
        """
        Create backup of file before modification.

        Parameters
        ----------
        file_path : Path
            File to backup
        """
        if file_path.exists():
            with tempfile.NamedTemporaryFile(mode="w", suffix=".backup", delete=False) as backup:
                backup.write(file_path.read_text())
                self.backups[str(file_path)] = backup.name

    def merge_requirements(self, feature_name: str) -> bool:
        """
        Merge requirements.txt fragment.

        Parameters
        ----------
        feature_name : str
            Feature name

        Returns
        -------
        bool
            True if successful
        """
        fragment_path = self.feature_lib / feature_name / "requirements.fragment"

        if not fragment_path.exists():
            return True  # Not required

        try:
            req_path = self.service_root / "requirements.txt"
            self.backup_file(req_path)

            base = req_path.read_text()
            fragment = fragment_path.read_text()
            merged = RequirementsMerger.merge(base, fragment)

            req_path.write_text(merged)
            self.applied_changes.append(f"Merged {feature_name} requirements")
            print("✓ Merged requirements.txt")
            return True
        except Exception as e:
            print(f"❌ Failed to merge requirements: {e}")
            return False

    def merge_docker_compose(self, feature_name: str) -> bool:
        """
        Merge docker-compose.yml fragment.

        Parameters
        ----------
        feature_name : str
            Feature name

        Returns
        -------
        bool
            True if successful
        """
        fragment_path = self.feature_lib / feature_name / "docker-compose.fragment.yaml"

        if not fragment_path.exists():
            return True  # Not required

        try:
            dc_path = self.service_root / "docker-compose.yml"
            self.backup_file(dc_path)

            # Load YAMLs
            with open(dc_path) as f:
                base = yaml.safe_load(f) or {}
            with open(fragment_path) as f:
                fragment = yaml.safe_load(f) or {}

            merged = DockerComposeMerger.merge(base, fragment)

            with open(dc_path, "w") as f:
                yaml.dump(merged, f, default_flow_style=False, sort_keys=False)
            self.applied_changes.append(f"Merged {feature_name} docker-compose")
            print("✓ Merged docker-compose.yml")
            return True
        except Exception as e:
            print(f"❌ Failed to merge docker-compose: {e}")
            return False

    def merge_settings(self, feature_name: str) -> bool:
        """
        Merge settings.py fragment.

        Parameters
        ----------
        feature_name : str
            Feature name

        Returns
        -------
        bool
            True if successful
        """
        fragment_path = self.feature_lib / feature_name / "settings.fragment.py"

        if not fragment_path.exists():
            return True  # Not required

        try:
            settings_path = self.service_root / "src/app/settings.py"
            if not settings_path.exists():
                print("⚠ settings.py not found, skipping")
                return True

            self.backup_file(settings_path)

            base = settings_path.read_text()
            fragment = fragment_path.read_text()
            merged = SettingsMerger.merge(base, fragment)

            settings_path.write_text(merged)
            self.applied_changes.append(f"Merged {feature_name} settings")
            print("✓ Merged settings.py")
            return True
        except FragmentMergeError as e:
            print(f"⚠ {e}")
            return True  # Non-fatal; feature still usable
        except Exception as e:
            print(f"❌ Failed to merge settings: {e}")
            return False

    def merge_conftest(self, feature_name: str) -> bool:
        """
        Merge conftest.py fragment.

        Parameters
        ----------
        feature_name : str
            Feature name

        Returns
        -------
        bool
            True if successful
        """
        fragment_path = self.feature_lib / feature_name / "conftest.fragment.py"

        if not fragment_path.exists():
            return True  # Not required

        try:
            conftest_path = self.service_root / "tests/conftest.py"
            if not conftest_path.exists():
                print("⚠ conftest.py not found, skipping")
                return True

            self.backup_file(conftest_path)

            base = conftest_path.read_text()
            fragment = fragment_path.read_text()
            merged = ConfTestMerger.merge(base, fragment)

            conftest_path.write_text(merged)
            self.applied_changes.append(f"Merged {feature_name} conftest")
            print("✓ Merged conftest.py")
            return True
        except FragmentMergeError as e:
            print(f"⚠ {e}")
            return True  # Non-fatal
        except Exception as e:
            print(f"❌ Failed to merge conftest: {e}")
            return False

    def create_feature_files(self, feature_name: str) -> bool:
        """
        Create feature-specific files (templates).

        Parameters
        ----------
        feature_name : str
            Feature name

        Returns
        -------
        bool
            True if successful
        """
        feature_dir = self.feature_lib / feature_name / "src" / "app"

        if not feature_dir.exists():
            # No template files to create
            return True

        try:
            # Copy entire tree
            for src_file in feature_dir.rglob("*"):
                if src_file.is_file():
                    # Map to destination
                    rel_path = src_file.relative_to(feature_dir)
                    dest_file = self.service_root / "src" / "app" / rel_path

                    # Create parent dirs
                    dest_file.parent.mkdir(parents=True, exist_ok=True)

                    # Copy file
                    shutil.copy2(src_file, dest_file)
                    self.applied_changes.append(f"Created {rel_path}")

            print("✓ Created feature files")
            return True
        except Exception as e:
            print(f"❌ Failed to create feature files: {e}")
            return False

    def create_test_files(self, feature_name: str) -> bool:
        """
        Create test files.

        Parameters
        ----------
        feature_name : str
            Feature name

        Returns
        -------
        bool
            True if successful
        """
        test_dir = self.feature_lib / feature_name / "tests"

        if not test_dir.exists():
            return True

        try:
            for src_file in test_dir.rglob("*"):
                if src_file.is_file():
                    rel_path = src_file.relative_to(test_dir)
                    dest_file = self.service_root / "tests" / rel_path

                    dest_file.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(src_file, dest_file)
                    self.applied_changes.append(f"Created {rel_path}")

            print("✓ Created test files")
            return True
        except Exception as e:
            print(f"❌ Failed to create test files: {e}")
            return False

    def add_feature(self, feature_name: str, plan: bool = False) -> tuple[bool, list[str]]:
        """
        Add feature to service.

        Parameters
        ----------
        feature_name : str
            Feature name
        plan : bool
            If True, dry-run (show plan without applying)

        Returns
        -------
        tuple[bool, list[str]]
            (success, list of changes applied)
        """
        print(f"\n📦 Adding feature: {feature_name}")
        print()

        # Step 1: Load & validate manifest
        if not self.load_feature(feature_name):
            return False, []

        # Step 2: Validate service structure
        if not self.validate_service():
            print("❌ Service validation failed")
            return False, []

        # Step 3: Check requirements
        req_errors = self.validate_requirements()
        if req_errors:
            print("❌ Feature requirements not met:")
            for err in req_errors:
                print(f"   - {err}")
            return False, []

        # Step 4: If plan mode, just describe
        if plan:
            print("📋 Plan (dry-run):")
            modifies = self.manifest.get("modifies", [])
            for f in modifies:
                print(f"  • Update {f}")
            creates = self.manifest.get("creates", [])
            for f in creates:
                print(f"  • Create {f}")
            return True, []

        # Step 5: Apply changes
        print("Applying changes...")
        print()

        all_success = True
        all_success &= self.merge_requirements(feature_name)
        all_success &= self.merge_docker_compose(feature_name)
        all_success &= self.merge_settings(feature_name)
        all_success &= self.merge_conftest(feature_name)
        all_success &= self.create_feature_files(feature_name)
        all_success &= self.create_test_files(feature_name)

        return all_success, self.applied_changes

    def rollback(self) -> None:
        """Restore all backups."""
        print("\n🔄 Rolling back changes...")
        for original_path, backup_path in self.backups.items():
            shutil.copy2(backup_path, original_path)
            Path(backup_path).unlink()
            print(f"  Restored {original_path}")
