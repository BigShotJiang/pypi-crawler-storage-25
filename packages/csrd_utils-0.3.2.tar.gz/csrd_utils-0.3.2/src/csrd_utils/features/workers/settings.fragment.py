# [INSERT: fields]
celery_broker_url: str = Field(  # noqa: F821
    default="redis://localhost:6379/0",
    description="Celery broker URL",
)
celery_result_backend: str = Field(  # noqa: F821
    default="redis://localhost:6379/0",
    description="Celery result backend URL",
)
