# Copyright Thales 2026
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""
AgentPodConfig — structured YAML configuration for Fred agent pods.

Why this exists:
- Every agent pod (rags-v2 and future pods) needs the same configuration
  structure as agentic-backend: security, storage, scheduler, AI settings, MCP.
- Using pydantic-settings env-var flat fields is not viable for production:
  security keys, store backends, and scheduler settings need structured config.
- This model is composed entirely from existing fred-core types so nothing is
  reinvented.

How to use it:
- Add a `config/configuration.yaml` to your pod (same format as agentic-backend).
- Call `load_agent_pod_config()` in `main.py` and pass the result to
  `create_agent_app(config=...)`.

Example `config/configuration.yaml`:
    app:
      name: "RAGS"
      base_url: "/rags/v1"
      port: 8000
      log_level: "info"

    security:
      m2m:
        enabled: false
        client_id: "rags"
        realm_url: "http://app-keycloak:8080/realms/app"
      user:
        enabled: false
        client_id: "app"
        realm_url: "http://app-keycloak:8080/realms/app"
      authorized_origins:
        - "http://localhost:5173"

    ai:
      knowledge_flow_url: "http://localhost:8111/knowledge-flow/v1"
      models_catalog_path: "config/models_catalog.yaml"
      default_model_profile: "chat"

    storage:
      postgres:
        sqlite_path: "~/.fred/rags/rags.sqlite3"
      session_store:
        type: "postgres"
        table: session
      history_store:
        type: "postgres"
        table: session_history
      kpi_store:
        type: "log"
        level: "DEBUG"

    scheduler:
      enabled: false

    mcp:
      servers: []
"""

from __future__ import annotations

from typing import List, Optional

from fred_core.common import (
    LogStoreConfig,
    OpenSearchStoreConfig,
    PostgresStoreConfig,
    PostgresTableConfig,
    StoreConfig,
    TemporalSchedulerConfig,
)
from fred_core.logs.log_structures import LogStorageConfig
from fred_core.scheduler.backend import SchedulerBackend
from fred_core.security.structure import SecurityConfiguration
from fred_sdk.contracts.models import MCPServerConfiguration
from pydantic import BaseModel, Field

# ---------------------------------------------------------------------------
# App section
# ---------------------------------------------------------------------------


class PodAppConfig(BaseModel):
    """
    Basic HTTP server settings for an agent pod.

    Why separate from agentic-backend's AppConfig:
    - pods don't expose metrics, reload dirs, or KPI summary intervals
    - keeping it minimal avoids YAML fields that have no meaning in a pod
    """

    name: str = "Fred Agent Pod"
    base_url: str = "/api/v1"
    port: int = 8000
    log_level: str = "info"
    metrics_enabled: bool = False
    metrics_port: int = 9005
    metrics_address: str = "0.0.0.0"  # nosec B104


# ---------------------------------------------------------------------------
# AI section
# ---------------------------------------------------------------------------


class PodAIConfig(BaseModel):
    """
    AI model and knowledge-flow settings for an agent pod.

    Why this section exists separately from AgentAppSettings:
    - `knowledge_flow_url` and model selection belong to structured YAML config,
      not pydantic-settings env vars
    - `models_catalog_path` points to the pod-local catalog file
    """

    knowledge_flow_url: str = "http://localhost:8111/knowledge-flow/v1"
    models_catalog_path: str = "config/models_catalog.yaml"
    default_model_profile: str = "chat"
    recursion_limit: int = Field(
        default=40,
        description="Maximum LangGraph recursion depth for ReAct loops.",
    )


# ---------------------------------------------------------------------------
# Storage section
# ---------------------------------------------------------------------------


class PodStorageConfig(BaseModel):
    """
    Persistence backend settings for an agent pod.

    Reuses fred-core types directly so there is no type duplication between
    agentic-backend and agent pods.

    Minimal required fields:
    - `postgres` for the SQL engine (session/history/checkpointer)
    - `session_store` and `history_store` for multi-turn state
    - `kpi_store` for metrics emission

    Optional:
    - `opensearch` for log/KPI forwarding in production
    - `log_store` for structured log persistence
    """

    postgres: PostgresStoreConfig = Field(
        default_factory=lambda: PostgresStoreConfig(
            sqlite_path="~/.fred/pod/pod.sqlite3"
        )
    )
    opensearch: Optional[OpenSearchStoreConfig] = None
    session_store: StoreConfig = Field(
        default_factory=lambda: PostgresTableConfig(type="postgres", table="session")
    )
    history_store: StoreConfig = Field(
        default_factory=lambda: PostgresTableConfig(
            type="postgres", table="session_history"
        )
    )
    kpi_store: StoreConfig = Field(
        default_factory=lambda: LogStoreConfig(type="log", level="DEBUG")
    )
    log_store: Optional[LogStorageConfig] = None


# ---------------------------------------------------------------------------
# Scheduler section
# ---------------------------------------------------------------------------


class PodSchedulerConfig(BaseModel):
    """
    Temporal scheduler settings for an agent pod.

    Disabled by default — only needed for Story B (deep/durable agents).
    Reuses TemporalSchedulerConfig from fred-core.
    """

    enabled: bool = False
    backend: SchedulerBackend = SchedulerBackend.TEMPORAL
    temporal: TemporalSchedulerConfig = Field(default_factory=TemporalSchedulerConfig)


# ---------------------------------------------------------------------------
# MCP section
# ---------------------------------------------------------------------------


class PodMcpConfig(BaseModel):
    """
    MCP server catalog for an agent pod.

    Reuses MCPServerConfiguration from fred-sdk.
    Set via `config/mcp_catalog.yaml` or inline in `configuration.yaml`.
    """

    servers: List[MCPServerConfiguration] = Field(default_factory=list)

    def get_server(self, id: str) -> Optional[MCPServerConfiguration]:
        """Return an enabled MCP server by id, or None."""
        for s in self.servers:
            if s.id == id and s.enabled:
                return s
        return None


# ---------------------------------------------------------------------------
# Root config
# ---------------------------------------------------------------------------


class AgentPodConfig(BaseModel):
    """
    Complete structured configuration for a Fred agent pod.

    Mirrors agentic-backend's `Configuration` model, scoped to what an agent
    pod actually needs. All field types are reused from fred-core and fred-sdk
    — no new types invented here.

    How to use it:
    - write a `config/configuration.yaml` alongside `config/models_catalog.yaml`
    - call `load_agent_pod_config()` at startup
    - pass the result to `create_agent_app(config=...)`

    The `security` field is a `SecurityConfiguration` from fred-core, the same
    type used in agentic-backend. When `security.user.enabled` is True,
    `create_agent_app` enforces Keycloak JWT validation on every endpoint.
    """

    app: PodAppConfig = Field(default_factory=PodAppConfig)
    security: SecurityConfiguration
    ai: PodAIConfig = Field(default_factory=PodAIConfig)
    storage: PodStorageConfig = Field(default_factory=PodStorageConfig)
    scheduler: PodSchedulerConfig = Field(default_factory=PodSchedulerConfig)
    mcp: PodMcpConfig = Field(default_factory=PodMcpConfig)
