# Copyright Thales 2026
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""
Reusable FastAPI app factory for Fred agent pods.

Why this module exists:
- every agent pod (rags-v2, future pods) needs identical SSE streaming plumbing:
  RuntimeConfig wiring, BoundRuntimeContext construction, ReActRuntime lifecycle,
  and a `POST /agents/execute/stream` endpoint
- duplicating that across pods causes divergence bugs and maintenance overhead

How to use it:
- call `create_agent_app(registry, config)` in your pod's `main.py`
- the returned FastAPI app already exposes:
    POST {config.app.base_url}/agents/execute/stream  — stream RuntimeEvent JSON over SSE
    GET  {config.app.base_url}/agents                 — list registered agent IDs
- pass `extra_routers` to mount additional domain-specific routers under `config.app.base_url`

Example:
    from fred_runtime.app import create_agent_app, load_agent_pod_config
    from myapp.agents.registry import REGISTRY

    config = load_agent_pod_config()
    app = create_agent_app(registry=REGISTRY, config=config)
"""

from __future__ import annotations

import json
import logging
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any
from uuid import uuid4

from fastapi import APIRouter, Depends, FastAPI, HTTPException, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from fred_core.security.oidc import get_keycloak_client_id, get_keycloak_url
from fred_runtime.common.kf_markdown_media_client import KfMarkdownMediaClient
from fred_sdk.contracts.context import (
    BoundRuntimeContext,
    PortableContext,
    PortableEnvironment,
    RuntimeContext,
)
from fred_sdk.contracts.models import AgentTuning, ReActAgentDefinition
from fred_sdk.contracts.react_contract import ReActInput, ReActMessage, ReActMessageRole
from fred_sdk.contracts.runtime import ExecutionConfig, RuntimeServices
from fred_sdk.react.react_runtime import ReActRuntime
from fred_sdk.support.authored_toolsets import (
    AuthoredToolRuntimePorts,
    build_authored_tool_handlers,
)
from pydantic import BaseModel, Field

from ..common.structures import AgentSettingsLike
from ..integrations.v2_runtime.adapters import (
    CompositeToolInvoker,
    FredArtifactPublisher,
    FredKnowledgeSearchToolInvoker,
    FredMcpToolProvider,
    FredResourceReader,
    build_default_tracer,
)
from ..runtime_context import (
    RuntimeConfig,
    RuntimeTimeouts,
    get_runtime_context,
    set_runtime_context,
)
from ..runtime_context import RuntimeContext as FredRuntimeContext
from ..runtime_support import refresh_user_access_token_from_keycloak
from .config import AgentPodConfig

if TYPE_CHECKING:
    from langchain_core.language_models.chat_models import BaseChatModel

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Chat model factory builder
# ---------------------------------------------------------------------------


def _build_chat_model_factory(config: AgentPodConfig) -> Any:
    """
    Build a ChatModelFactoryPort for the configured model backend.

    Resolution order:
    1. If `config.ai.models_catalog_path` exists on disk: load it via
       `load_model_catalog`, build a `RoutedChatModelFactory` backed by
       `ModelRoutingResolver`. Rules in the catalog are evaluated per-request
       against the real `BoundRuntimeContext` (agent_id, team_id, user_id).
    2. Otherwise fall back to a simple env-var factory (openai / google only).

    Why this returns a ChatModelFactoryPort (not a zero-arg callable):
    - `RoutedChatModelFactory.build(definition, binding)` receives the full
      runtime context per invocation, enabling per-request rule evaluation.
    """
    import os

    from ..model_routing import (
        ModelRoutingResolver,
        RoutedChatModelFactory,
        load_model_catalog,
    )

    catalog_path = config.ai.models_catalog_path

    if os.path.isfile(catalog_path):
        try:
            catalog = load_model_catalog(catalog_path)
            policy = catalog.to_policy()
            logger.info(
                "[fred-runtime] model routing from catalog=%s profiles=%d rules=%d",
                catalog_path,
                len(policy.profiles),
                len(policy.rules),
            )
            return RoutedChatModelFactory(resolver=ModelRoutingResolver(policy))
        except Exception:
            logger.exception(
                "[fred-runtime] Failed to load models catalog from %s — falling back to env-var config",
                catalog_path,
            )

    # Fallback: simple env-var factory (openai / google only)
    logger.info(
        "[fred-runtime] model catalog not found at %s — falling back to env-var config",
        catalog_path,
    )
    return _EnvVarChatModelFactory()


class _EnvVarChatModelFactory:
    """
    Minimal ChatModelFactoryPort for the env-var fallback path (openai / google).

    Used when no `models_catalog.yaml` file is present on disk.
    Reads CHAT_MODEL_PROVIDER, CHAT_MODEL_NAME, OPENAI_API_KEY, GOOGLE_API_KEY
    from environment variables. Ignores definition and binding — every call
    returns the same statically configured model.
    """

    def build(self, definition: Any, binding: Any) -> BaseChatModel:  # type: ignore[return]
        import os

        provider = os.environ.get("CHAT_MODEL_PROVIDER", "openai")
        model_name = os.environ.get("CHAT_MODEL_NAME", "gpt-4o-mini")
        if provider == "google":
            from langchain_google_genai import (
                ChatGoogleGenerativeAI,  # type: ignore[import-untyped]
            )

            return ChatGoogleGenerativeAI(model=model_name)
        from langchain_openai import ChatOpenAI  # type: ignore[import-untyped]

        return ChatOpenAI(model=model_name)

    def build_for_operation(
        self, *, definition: Any, binding: Any, purpose: str, operation: str | None
    ) -> BaseChatModel:
        return self.build(definition, binding)


@dataclass(slots=True)
class _PodAgentSettings:
    """
    Minimal settings object expected by fred-runtime adapter ports.

    Why this exists:
    - the reusable pod app executes raw `ReActAgentDefinition` objects, not the
      richer settings model assembled inside agentic-backend
    - runtime adapters still need a small identity/tuning object so authored
      tools, Fred built-ins, and MCP defaults behave the same way in pods

    How to use it:
    - build one from the current agent definition for each request
    - pass it to the fred-runtime adapter constructors

    Example:
    - `settings = _build_agent_settings(definition)`
    """

    id: str
    name: str
    team_id: str | None
    tuning: AgentTuning | None


class _MediaClientAgentAdapter:
    """
    Small bridge exposing token refresh to the markdown media client.

    Why this exists:
    - authored tools may call `ctx.fetch_media(...)`
    - `KfMarkdownMediaClient` expects an agent-like object with runtime context,
      settings, and a token-refresh hook

    How to use it:
    - instantiate only from `_build_media_fetcher(...)`

    Example:
    - `adapter = _MediaClientAgentAdapter(binding=binding, settings=settings)`
    """

    def __init__(
        self, *, binding: BoundRuntimeContext, settings: _PodAgentSettings
    ) -> None:
        self.runtime_context = binding.runtime_context
        self.agent_settings: AgentSettingsLike = settings

    def refresh_user_access_token(self) -> str:
        """
        Refresh the user access token for media downloads.

        Why this exists:
        - media fetch retries need the same Keycloak refresh path as other
          runtime adapters

        How to use it:
        - called by `KfMarkdownMediaClient` when the current token is expired

        Example:
        - `token = adapter.refresh_user_access_token()`
        """

        refresh_token = self.runtime_context.refresh_token
        if not refresh_token:
            raise RuntimeError(
                "Cannot refresh user access token: refresh_token missing from runtime context."
            )

        keycloak_url = get_keycloak_url()
        client_id = get_keycloak_client_id()
        if not keycloak_url:
            raise RuntimeError(
                "User security realm_url is not configured for Keycloak."
            )
        if not client_id:
            raise RuntimeError(
                "User security client_id is not configured for Keycloak."
            )

        payload = refresh_user_access_token_from_keycloak(
            keycloak_url=keycloak_url,
            client_id=client_id,
            refresh_token=refresh_token,
        )
        new_access_token = payload.get("access_token")
        new_refresh_token = payload.get("refresh_token") or refresh_token
        if not isinstance(new_access_token, str) or not new_access_token:
            raise RuntimeError(
                "Keycloak refresh response did not include a valid access_token."
            )

        self.runtime_context.access_token = new_access_token
        self.runtime_context.refresh_token = new_refresh_token
        return new_access_token


def _build_agent_settings(definition: ReActAgentDefinition) -> _PodAgentSettings:
    """
    Derive the minimal runtime settings object for one pod-hosted agent.

    Why this exists:
    - fred-runtime adapter ports operate on a small settings contract rather
      than raw definitions
    - pod execution should still honor default MCP servers and agent identity
      the same way the backend bootstrap does

    How to use it:
    - call once per request before constructing runtime adapter ports

    Example:
    - `settings = _build_agent_settings(definition)`
    """

    return _PodAgentSettings(
        id=definition.agent_id,
        name=definition.agent_id,
        team_id=None,
        tuning=AgentTuning(
            role=definition.role,
            description=definition.description,
            tags=list(definition.tags),
            fields=list(definition.fields),
            mcp_servers=list(definition.default_mcp_servers),
        ),
    )


def _build_media_fetcher(*, binding: BoundRuntimeContext, settings: _PodAgentSettings):
    """
    Build the media-fetcher port exposed to Python-authored tool handlers.

    Why this exists:
    - authored tools can fetch packaged markdown media through `ctx.fetch_media`
    - the SDK expects a small async callable, not a concrete fred-runtime client

    How to use it:
    - pass the current binding and agent settings while assembling authored-tool
      runtime ports

    Example:
    - `media_fetcher = _build_media_fetcher(binding=binding, settings=settings)`
    """

    adapter = _MediaClientAgentAdapter(binding=binding, settings=settings)
    client: KfMarkdownMediaClient | None = None

    async def _fetch_media(document_uid: str, file_name: str) -> bytes:
        """
        Fetch one packaged media asset lazily through Knowledge Flow.

        Why this exists:
        - media support should be available to authored tools without incurring
          client setup cost when no tool uses it

        How to use it:
        - invoked by the authored-tool runtime when a tool calls
          `ctx.fetch_media(...)`

        Example:
        - `payload = await media_fetcher("doc-123", "image.png")`
        """

        nonlocal client
        if client is None:
            client = KfMarkdownMediaClient(agent=adapter)
        return await client.fetch_media(document_uid, file_name)

    return _fetch_media


def _build_runtime_services(
    definition: ReActAgentDefinition,
    binding: BoundRuntimeContext,
) -> RuntimeServices:
    """
    Assemble the full `RuntimeServices` bundle for one pod request.

    Why this exists:
    - authored local tools, Fred built-ins, MCP tools, resource reads, and
      artifact publication now all share one runtime contract in `fred-sdk`
    - the reusable pod app must mirror the same binding-aware service assembly
      already used by agentic-backend, or declared tools fail at runtime

    How to use it:
    - call from `_stream(...)` after the request binding is constructed
    - create a fresh service bundle per request so binding-scoped adapters stay
      aligned with the current session/user/token context

    Example:
    - `services = _build_runtime_services(definition, binding)`
    """

    runtime_config = get_runtime_context().config
    settings = _build_agent_settings(definition)
    base_tool_invoker = FredKnowledgeSearchToolInvoker(
        binding=binding,
        settings=settings,
    )
    tool_provider = FredMcpToolProvider(
        binding=binding,
        settings=settings,
    )
    artifact_publisher = FredArtifactPublisher(
        binding=binding,
        settings=settings,
    )
    resource_reader = FredResourceReader(
        binding=binding,
        settings=settings,
    )
    handlers = build_authored_tool_handlers(
        definition=definition,
        toolset_key=getattr(definition, "toolset_key", None),
        binding=binding,
        settings=settings,
        ports=AuthoredToolRuntimePorts(
            chat_model_factory=runtime_config.chat_model_factory,
            artifact_publisher=artifact_publisher,
            resource_reader=resource_reader,
            fallback_tool_invoker=base_tool_invoker,
            media_fetcher=_build_media_fetcher(binding=binding, settings=settings),
        ),
    )
    tool_invoker = (
        CompositeToolInvoker(
            handlers=handlers,
            fallback=base_tool_invoker,
        )
        if handlers
        else base_tool_invoker
    )
    return RuntimeServices(
        tracer=build_default_tracer(),
        chat_model_factory=runtime_config.chat_model_factory,
        tool_invoker=tool_invoker,
        tool_provider=tool_provider,
        artifact_publisher=artifact_publisher,
        resource_reader=resource_reader,
        checkpointer=runtime_config.checkpointer,
    )


def _normalize_base_url(base_url: str) -> str:
    """
    Normalize the configured FastAPI base URL for router and docs mounting.

    Why this exists:
    - pod apps should honor `config.app.base_url` consistently
    - normalization avoids accidental double slashes from empty or trailing-slash
      values

    How to use it:
    - call once inside `create_agent_app(...)`

    Example:
    - `_normalize_base_url("/rags/v1/") == "/rags/v1"`
    """

    cleaned = base_url.strip()
    if not cleaned or cleaned == "/":
        return ""
    return f"/{cleaned.strip('/')}"


# ---------------------------------------------------------------------------
# SSE streaming helpers
# ---------------------------------------------------------------------------


class _AgentExecuteRequest(BaseModel):
    """
    Input payload for the SSE execution endpoint.

    Example:
    ```json
    {"agent_id": "rags.sample.echo", "message": "hello"}
    ```
    """

    agent_id: str = Field(..., min_length=1)
    message: str = Field(..., min_length=1)
    context: dict[str, Any] | None = None


def _sse(payload: str) -> str:
    return f"data: {payload}\n\n"


async def _stream(
    definition: ReActAgentDefinition,
    request: _AgentExecuteRequest,
    access_token: str | None = None,
) -> AsyncIterator[str]:
    """
    Execute a ReAct agent and yield SSE-framed RuntimeEvent JSON.

    Why this is a standalone async generator:
    - keeps the FastAPI endpoint thin (just returns StreamingResponse)
    - raises no HTTPException — the endpoint already validated agent_id before
      passing the definition in

    access_token:
    - the user's JWT forwarded from agentic-backend via the Authorization header
    - stored in RuntimeContext so KF tool adapters can use it for outbound calls
      (same path as local agents in agentic-backend)
    - None in local dev when security is disabled
    """

    request_id = str(uuid4())
    ctx = request.context or {}
    correlation_id = ctx.get("correlation_id", request_id)

    portable_context = PortableContext(
        request_id=request_id,
        correlation_id=correlation_id,
        actor=ctx.get("user_id", "anonymous"),
        tenant=ctx.get("tenant", "default"),
        environment=PortableEnvironment.DEV,
        agent_id=definition.agent_id,
        agent_name=definition.agent_id,
        session_id=ctx.get("session_id"),
        user_id=ctx.get("user_id"),
    )

    runtime_context = RuntimeContext(
        session_id=ctx.get("session_id"),
        user_id=ctx.get("user_id"),
        language=ctx.get("language"),
        access_token=access_token,
    )

    binding = BoundRuntimeContext(
        runtime_context=runtime_context,
        portable_context=portable_context,
    )

    runtime = ReActRuntime(
        definition=definition,
        services=_build_runtime_services(definition, binding),
    )
    runtime.bind(binding)

    try:
        await runtime.activate()
        executor = await runtime.get_executor()
        react_input = ReActInput(
            messages=(
                ReActMessage(role=ReActMessageRole.USER, content=request.message),
            ),
        )
        # thread_id = session_id enables LangGraph checkpointing: the agent
        # resumes its graph state from the SQL checkpointer on every turn.
        # When session_id is absent (e.g. one-shot calls) thread_id=None and
        # LangGraph runs stateless — no checkpoint written or read.
        execution_config = ExecutionConfig(thread_id=ctx.get("session_id"))
        async for event in executor.stream(react_input, execution_config):
            yield _sse(event.model_dump_json())
    except Exception as exc:
        logger.exception(
            "[fred-runtime] agent execution error agent_id=%s", definition.agent_id
        )
        yield _sse(json.dumps({"error": str(exc)}))
    finally:
        await runtime.dispose()


# ---------------------------------------------------------------------------
# Router builder
# ---------------------------------------------------------------------------


def _build_agent_router(
    registry: dict[str, ReActAgentDefinition],
    security_enabled: bool,
) -> APIRouter:
    """
    Build the FastAPI router for agent execution.

    Why this is a function rather than a module-level router:
    - the registry is provided at app-creation time, not import time
    - each call produces an isolated router instance bound to that registry
    - security_enabled controls whether get_current_user is applied as a dependency
    """
    from fred_core.security.oidc import get_current_user

    router = APIRouter(prefix="/agents", tags=["Agents"])

    # Build the dependency list once — empty when security is off so that
    # local-dev pods start without any Keycloak configuration.
    _auth_deps = [Depends(get_current_user)] if security_enabled else []

    @router.get("")
    async def list_agents() -> list[str]:
        """Return the agent IDs registered in this pod."""
        return list(registry.keys())

    @router.post("/execute/stream", dependencies=_auth_deps)
    async def execute_stream(
        request: _AgentExecuteRequest, http_request: Request
    ) -> StreamingResponse:
        """
        Stream RuntimeEvent JSON over SSE for a single agent invocation.

        POST <configured base_url>/agents/execute/stream
        Authorization: Bearer <user JWT forwarded from agentic-backend>
        Body: {"agent_id": "...", "message": "...", "context": {...}}
        Response: text/event-stream, each `data:` line is a RuntimeEvent JSON

        The Bearer token is the user's Keycloak JWT forwarded by agentic-backend.
        It is stored in RuntimeContext.access_token so KF tool adapters can use it
        for outbound calls — the same pattern as local agents in agentic-backend.
        """
        definition = registry.get(request.agent_id)
        if definition is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Unknown agent_id: {request.agent_id!r}. "
                f"Known agents: {list(registry.keys())}",
            )
        auth = http_request.headers.get("Authorization", "")
        access_token = auth.removeprefix("Bearer ").strip() or None
        return StreamingResponse(
            _stream(definition, request, access_token=access_token),
            media_type="text/event-stream",
        )

    return router


# ---------------------------------------------------------------------------
# Public factory
# ---------------------------------------------------------------------------


def create_agent_app(
    registry: dict[str, ReActAgentDefinition],
    config: AgentPodConfig,
    extra_routers: list[APIRouter] | None = None,
) -> FastAPI:
    """
    Create a ready-to-serve FastAPI app for a Fred agent pod.

    Why this exists:
    - every agent pod needs the same SSE endpoint, RuntimeConfig wiring, lifespan
      hook, and security middleware — this factory provides all of it so pods
      contain zero infrastructure code

    How to use it:
    - call from your pod's `main.py` after loading your config
    - security is taken from `config.security` — no separate parameter needed

    Example:
    ```python
    from fred_runtime.app import create_agent_app, load_agent_pod_config
    from myapp.agents.registry import REGISTRY

    config = load_agent_pod_config()
    app = create_agent_app(registry=REGISTRY, config=config)
    ```

    Parameters:
    - registry: maps agent_id → ReActAgentDefinition; built at startup, read-only
    - config: AgentPodConfig loaded from `config/configuration.yaml`
    - extra_routers: additional APIRouter instances mounted under `config.app.base_url`

    Security (from config.security):
    - when `config.security.user.enabled` is True:
        - initializes Keycloak JWT validation (initialize_user_security)
        - adds Depends(get_current_user) to POST /agents/execute/stream
    - `config.security.authorized_origins` controls CORS (when non-empty)
    - routes, docs, and OpenAPI are mounted under `config.app.base_url`
    """

    security = config.security
    base_url = _normalize_base_url(config.app.base_url)
    user_security = security.user if security is not None else None
    security_enabled: bool = (
        user_security.enabled if user_security is not None else False
    )
    authorized_origins: list[str] = (
        [str(o).rstrip("/") for o in security.authorized_origins]
        if security is not None and security.authorized_origins
        else []
    )

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        # Initialize Keycloak inbound validation before any request is handled.
        if security_enabled and user_security is not None:
            from fred_core.security.oidc import initialize_user_security

            initialize_user_security(user_security)

        chat_factory = _build_chat_model_factory(config)

        # SQL checkpointer — always initialized from config.storage.postgres.
        # Uses SQLite (via aiosqlite) when no Postgres host is set (local dev).
        # Uses asyncpg Postgres in production.
        # Provides durable LangGraph session state keyed by session_id.
        sql_engine = None
        checkpointer = None
        try:
            from fred_core.sql.base_sql import create_async_engine_from_config

            from ..runtime_support.sql_checkpointer import FredSqlCheckpointer

            sql_engine = create_async_engine_from_config(config.storage.postgres)
            checkpointer = FredSqlCheckpointer(sql_engine)
            logger.info(
                "[fred-runtime] SQL checkpointer ready (dialect=%s)",
                sql_engine.dialect.name,
            )
        except Exception:
            logger.exception(
                "[fred-runtime] Failed to initialize SQL checkpointer — running stateless"
            )

        # MCP catalog — passed when any servers are declared.
        # PodMcpConfig satisfies McpConfigurationLike (has servers + get_server).
        mcp_configuration = config.mcp if config.mcp.servers else None

        runtime_config = RuntimeConfig(
            knowledge_flow_url=config.ai.knowledge_flow_url,
            timeouts=RuntimeTimeouts(),
            chat_model_factory=chat_factory,
            checkpointer=checkpointer,
            mcp_configuration=mcp_configuration,
        )
        set_runtime_context(FredRuntimeContext(runtime_config))
        logger.info(
            "[fred-runtime] agent pod started — base_url=%s kf=%s security=%s checkpointer=%s agents=%s",
            base_url or "/",
            config.ai.knowledge_flow_url,
            "enabled" if security_enabled else "disabled",
            "sql" if checkpointer is not None else "none",
            list(registry.keys()),
        )
        yield

        # Graceful shutdown — dispose the SQL engine connection pool.
        if sql_engine is not None:
            await sql_engine.dispose()
            logger.info("[fred-runtime] SQL engine disposed")

    app = FastAPI(
        title=config.app.name,
        version="0.1.0",
        docs_url=f"{base_url}/docs" if base_url else "/docs",
        redoc_url=f"{base_url}/redoc" if base_url else "/redoc",
        openapi_url=f"{base_url}/openapi.json" if base_url else "/openapi.json",
        lifespan=lifespan,
    )

    # CORS — only added when security is provided so local-dev pods stay simple.
    if authorized_origins:
        app.add_middleware(
            CORSMiddleware,
            allow_origins=authorized_origins,
            allow_methods=["GET", "POST"],
            allow_headers=["Content-Type", "Authorization"],
        )
        logger.debug("[fred-runtime] CORS allow_origins=%s", authorized_origins)

    api_router = APIRouter(prefix=base_url)
    api_router.include_router(
        _build_agent_router(registry, security_enabled=security_enabled)
    )

    for extra in extra_routers or []:
        api_router.include_router(extra)

    app.include_router(api_router)
    return app
