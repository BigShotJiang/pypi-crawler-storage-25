# Copyright 2024 ACSONE SA/NV
# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl).

from odoo import Command, api, fields, models


class Rma(models.Model):
    _inherit = "rma"

    lot_id = fields.Many2one(
        comodel_name="stock.lot",
        string="Lot/Serial Number",
        domain="[('product_id', '=?', product_id)]",
        compute="_compute_lot_id",
        store=True,
        readonly=False,
    )
    product_tracking = fields.Selection(related="product_id.tracking")
    lots_visible = fields.Boolean(compute="_compute_lots_visible")

    @api.depends("product_id.tracking")
    def _compute_lots_visible(self):
        for rec in self:
            rec.lots_visible = rec.product_id.tracking != "none"

    def _prepare_delivery_procurement_vals(self, scheduled_date=None):
        vals = super()._prepare_delivery_procurement_vals(scheduled_date=scheduled_date)
        if vals.get("restrict_lot_id") and self.reception_move_id.restrict_lot_id:
            if self.reception_move_id.restrict_lot_id.id != vals.get("restrict_lot_id"):
                vals["move_orig_ids"] = [Command.clear()]  # Avoid inconsistencies
        return vals

    def _prepare_reception_procurement_vals(self, group=None):
        vals = super()._prepare_reception_procurement_vals(group=group)
        vals["restrict_lot_id"] = self.lot_id.id
        return vals

    def _prepare_common_procurement_vals(
        self, warehouse=None, scheduled_date=None, group=None
    ):
        vals = super()._prepare_common_procurement_vals(
            warehouse=warehouse, scheduled_date=scheduled_date, group=group
        )
        replace_lot = self.env.context.get("rma_replace_lot_id")
        if replace_lot:
            vals["restrict_lot_id"] = replace_lot.id
        elif self.operation_id.deliver_same_lot:
            vals["restrict_lot_id"] = self.lot_id.id
        return vals

    @api.depends("move_id", "lot_id")
    def _compute_product_id(self):
        res = super()._compute_product_id()
        for rec in self:
            if not rec.move_id and rec.lot_id:
                self.product_id = rec.lot_id.product_id
        return res

    @api.depends("product_id")
    def _compute_lot_id(self):
        self.update({"lot_id": False})
