import os
import smtplib
from email.mime.text import MIMEText

from jira_ticket_updater.jira_operations import get_ticket_summary

_EMAIL_SEP = ","


def _to_html_preserved_block(text: str) -> str:
    """Convert plain text into HTML while preserving line breaks."""
    safe = (text or "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    return safe.replace("\n", "<br>")


def send_ticket_report_email(pr_closure_data):
    """
    Sends a single email with testcase summary.

    Parameters:
    - issue_key (str): Issue key.
    - ticket_summary (str): Ticket summary.
    """
    issue_key = pr_closure_data["issue_key"]
    ticket_summary = pr_closure_data["ticket_summary"]
    testcases_summary = pr_closure_data["testcases_summary"]

    email_user = os.getenv("EMAIL_USER", "")
    email_password = os.getenv("EMAIL_PASS", "")
    email_receiver = os.getenv("EMAIL_TO", "")
    email_cc = os.getenv("EMAIL_CC", "")
    if email_user == "" or email_password == "":
        print("Email user or password is not set")
        return

    message = f"""
    <html>
      <body style="font-family: Arial, sans-serif; color: #222; line-height: 1.5;">
        <p>Hello Team,</p>
        <p>
          Pull request for ticket <strong>{issue_key}</strong> has been merged into
          the main branch.
        </p>
        <div style="background:#f7f8fa; border:1px solid #e5e7eb; border-radius:8px; padding:12px; margin:12px 0;">
          <h3 style="margin:0 0 8px 0; font-size:16px;">Ticket Summary</h3>
          <p style="margin:0;">{_to_html_preserved_block(ticket_summary)}</p>
        </div>
        <div style="background:#f7f8fa; border:1px solid #e5e7eb; border-radius:8px; padding:12px; margin:12px 0;">
          <h3 style="margin:0 0 8px 0; font-size:16px;">Linked Testcases</h3>
          <p style="margin:0;">{_to_html_preserved_block(testcases_summary)}</p>
        </div>
        <p>Thanks,<br>Automation Team</p>
      </body>
    </html>
    """
    msg = MIMEText(message, "html")
    msg["Subject"] = f"PR Closure - {issue_key} - Ticket Completion Summary"
    msg["From"] = email_user
    msg["To"] = email_receiver
    msg["CC"] = email_cc

    try:
        server = smtplib.SMTP("smtp.gmail.com", 587)
        server.starttls()
        server.login(email_user, email_password)
        receiver_email_list = [
            t.strip() for t in email_receiver.split(_EMAIL_SEP) if t.strip()
        ] + [c.strip() for c in email_cc.split(_EMAIL_SEP) if c.strip()]
        server.sendmail(email_user, receiver_email_list, msg.as_string())
        server.quit()
        print("Ticket summary email sent")
    except Exception as e:
        print(f"Error sending ticket summary email: {e}")


def send_merge_pr_alert(issue_key):
    try:
        # Import lazily to avoid circular import during package initialization.
        from zephyr_jira_linker.main import get_test_status

        # Set up environment variables JIRA_BASE_URL, JIRA_EMAIL, JIRA_API_TOKEN
        # Ticket summary
        ticket_summary = get_ticket_summary(issue_key)
        # Testcases summary
        testcases_summary = get_test_status(issue_key)

        ticket_report_data = {
            "issue_key": issue_key,
            "ticket_summary": ticket_summary,
            "testcases_summary": testcases_summary,
        }
        print(ticket_report_data)

        send_ticket_report_email(ticket_report_data)
    except Exception as e:
        print(f"Failed to send linked testcases summary email: {str(e)}")
