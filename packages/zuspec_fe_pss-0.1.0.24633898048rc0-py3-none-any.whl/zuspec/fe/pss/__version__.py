BASE="0.1.0"
SUFFIX=".24633898048rc0"
version="%s%s" % (BASE, SUFFIX)
