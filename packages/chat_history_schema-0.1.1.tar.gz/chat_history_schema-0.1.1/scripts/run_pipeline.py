from __future__ import annotations

import argparse
from pathlib import Path

from scripts.combine_conversations import combine_provider
from scripts.merge_provider_histories import (
    merge_provider_histories,
    write_merged_output,
)
from scripts.parse_validate_clean import resolve_providers


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description='Run end-to-end pipeline: combine raw exports, validate, and write merged pickle.'
    )
    parser.add_argument(
        '--provider',
        choices=('openai', 'anthropic', 'all'),
        default='all',
        help='Provider to process. Use "all" to process both providers.',
    )
    parser.add_argument(
        '--raw-root',
        type=Path,
        default=Path('data/raw'),
        help='Root directory containing provider raw export folders.',
    )
    parser.add_argument(
        '--combined-root',
        type=Path,
        default=Path('data/combined'),
        help='Root directory where combined provider files are written/read.',
    )
    parser.add_argument(
        '--output-pkl',
        type=Path,
        default=Path('data/merged/all-conversations-clean.pkl'),
        help='Output pickle path for merged history.',
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    providers = resolve_providers(args.provider)

    for provider in providers:
        combine_provider(
            provider=provider,
            raw_root=args.raw_root.resolve(),
            combined_root=args.combined_root.resolve(),
        )

    merged = merge_provider_histories(
        providers=providers,
        combined_root=args.combined_root.resolve(),
    )
    write_merged_output(merged, args.output_pkl.resolve())


if __name__ == '__main__':
    main()
