"""Ingestion and cleanup scripts."""
