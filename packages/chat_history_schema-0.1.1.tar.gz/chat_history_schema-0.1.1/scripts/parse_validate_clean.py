from __future__ import annotations

import argparse
import json
import re
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import pydantic
from pydantic import BaseModel

from chat_history_schema.anthropic.claude import ClaudeConversation
from chat_history_schema.openai.conversation import Conversation, Node


PROVIDERS = ('openai', 'anthropic')


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description='Validate combined conversation exports.'
    )
    parser.add_argument(
        '--provider',
        choices=(*PROVIDERS, 'all'),
        default='all',
        help='Provider to process. Use "all" to process both providers.',
    )
    parser.add_argument(
        '--combined-root',
        type=Path,
        default=Path('data/combined'),
        help='Root directory that contains provider combined JSON files.',
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    providers = resolve_providers(args.provider)
    for provider in providers:
        convos = validate_provider_conversations(
            provider=provider,
            combined_root=args.combined_root.resolve(),
        )
        print(f'[{provider}] validation succeeded for {len(convos)} conversations.')


def resolve_providers(provider: str) -> tuple[str, ...]:
    return PROVIDERS if provider == 'all' else (provider,)


def validate_provider_conversations(
    provider: str,
    combined_root: Path,
) -> list[Conversation] | list[ClaudeConversation]:
    input_json = combined_root / provider / 'conversations.json'
    if not input_json.exists():
        raise SystemExit(
            f'Combined conversations file not found for "{provider}": {input_json}'
        )

    with input_json.open('r') as file:
        documents = json.load(file)

    if not isinstance(documents, list):
        raise SystemExit(f'Expected JSON array in {input_json}')

    if provider == 'openai':
        documents = shorten_all_uuids(documents, last_chars=16, test=True)
        convos = validate_documents(
            model=Conversation,
            documents=documents,
            provider=provider,
        )
        for convo in convos:
            sort_mapping(convo)
        convos = sorted(convos, key=lambda convo: convo.create_time, reverse=True)
    else:
        convos = validate_documents(
            model=ClaudeConversation,
            documents=documents,
            provider=provider,
        )
        convos = sorted(
            convos,
            key=lambda convo: parse_iso_utc(convo.created_at),
            reverse=True,
        )
    return convos


def validate_documents[T: BaseModel](
    model: type[T],
    documents: list[dict[str, Any]],
    provider: str,
) -> list[T]:
    results: list[T] = []
    for index, doc in enumerate(documents):
        try:
            results.append(model(**doc))
        except pydantic.ValidationError as err:
            print(format_error(str(err)))
            print(
                f'\n[{provider}] failed on {model.__name__} {index} / {len(documents)}'
            )
            print_schema_enrichment_guidance(provider=provider, error=err)
            raise SystemExit(1)
    return results


def print_schema_enrichment_guidance(
    provider: str,
    error: pydantic.ValidationError,
) -> None:
    print(
        f'[{provider}] Conversation structures can vary across exports, so iterative schema updates are expected.'
    )
    extra_fields = sorted(
        {
            '.'.join(map(str, issue.get('loc', ())))
            for issue in error.errors(include_url=False)
            if issue.get('type') == 'extra_forbidden'
        }
    )
    if extra_fields:
        print(f'[{provider}] Unsupported fields detected:')
        for path in extra_fields[:20]:
            print(f'  - {path}')
        if len(extra_fields) > 20:
            print(f'  - ... and {len(extra_fields) - 20} more')
    print(
        f'[{provider}] Enrich schemas by updating chat_history_schema/{provider}/* with the new fields/types from this error output, then rerun.'
    )


def format_error(err: str) -> str:
    lines = err.split('\n')
    lines = [lines[0], '', *lines[1:]]
    lines = [line for line in lines if 'https://errors.pydantic.dev' not in line]
    return '\n'.join(lines)


def parse_iso_utc(value: str) -> datetime:
    return datetime.fromisoformat(value.replace('Z', '+00:00')).astimezone(UTC)


def shorten_all_uuids(data: Any, last_chars: int, test: bool = False) -> Any:
    def shorten_all_uuids_rec(obj: Any) -> Any:
        if isinstance(obj, dict):
            return {
                shorten_all_uuids_rec(k): shorten_all_uuids_rec(v)
                for k, v in obj.items()
            }
        if isinstance(obj, list):
            return [shorten_all_uuids_rec(x) for x in obj]
        if isinstance(obj, tuple):
            return tuple(shorten_all_uuids_rec(x) for x in obj)
        if isinstance(obj, str) and is_uuid(obj):
            return shorten_uuid(obj)
        return obj

    full_uuids_seen: set[str] = set()
    shortened_uuids: set[str] = set()

    if test:

        def shorten_uuid(uuid: str) -> str:
            full_uuids_seen.add(uuid)
            shortened = uuid[-last_chars:]
            shortened_uuids.add(shortened)
            return shortened
    else:

        def shorten_uuid(uuid: str) -> str:
            return uuid[-last_chars:]

    uuid_re_lower = re.compile(
        r'^[0-9a-f]{8}-'
        r'[0-9a-f]{4}-'
        r'[0-9a-f]{4}-'
        r'[0-9a-f]{4}-'
        r'[0-9a-f]{12}$'
    )
    uuid_re_upper = re.compile(
        r'^[0-9A-F]{8}-'
        r'[0-9A-F]{4}-'
        r'[0-9A-F]{4}-'
        r'[0-9A-F]{4}-'
        r'[0-9A-F]{12}$'
    )

    def is_uuid(s: str) -> bool:
        return bool(uuid_re_lower.match(s)) or bool(uuid_re_upper.match(s))

    result = shorten_all_uuids_rec(data)
    assert len(full_uuids_seen) == len(shortened_uuids)
    return result


def sort_mapping(convo: Conversation) -> None:
    num_messages = len(convo.mapping)
    sorted_nodes: list[Node] = []

    def add_node(node_id: str) -> None:
        node = convo.mapping[node_id]
        sorted_nodes.append(node)
        for child in node.children:
            add_node(child)

    root = convo.get_root_node()
    add_node(root.id)
    assert num_messages == len(sorted_nodes)
    convo.mapping = {node.id: node for node in sorted_nodes}


if __name__ == '__main__':
    main()
