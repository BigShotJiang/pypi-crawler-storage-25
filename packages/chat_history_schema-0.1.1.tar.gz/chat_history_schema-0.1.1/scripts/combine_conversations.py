from __future__ import annotations

import argparse
import json
from pathlib import Path

PROVIDERS = ('openai', 'anthropic')
DEFAULT_PATTERNS = {
    'openai': ('conversations-*.json', 'conversations.json'),
    'anthropic': (
        'conversation-*.json',
        'conversations-*.json',
        'conversation.json',
        'conversations.json',
    ),
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description='Combine provider-specific raw conversation export JSON files.'
    )
    parser.add_argument(
        '--provider',
        choices=(*PROVIDERS, 'all'),
        default='all',
        help='Provider to process. Use "all" to process both providers.',
    )
    parser.add_argument(
        '--raw-root',
        type=Path,
        default=Path('data/raw'),
        help='Root directory containing provider raw export folders.',
    )
    parser.add_argument(
        '--combined-root',
        type=Path,
        default=Path('data/combined'),
        help='Root directory where combined provider files are written.',
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    providers = PROVIDERS if args.provider == 'all' else (args.provider,)
    for provider in providers:
        combine_provider(
            provider, args.raw_root.resolve(), args.combined_root.resolve()
        )


def combine_provider(provider: str, raw_root: Path, combined_root: Path) -> None:
    raw_provider_dir = raw_root / provider
    if not raw_provider_dir.exists():
        raise SystemExit(f'Missing provider folder: {raw_provider_dir}')

    files = discover_input_files(raw_provider_dir, provider)
    if not files:
        raise SystemExit(
            f'No raw JSON files found for provider "{provider}" in {raw_provider_dir}'
        )

    combined: list[object] = []
    for path in files:
        docs = load_json_array(path)
        combined.extend(docs)

    output_path = combined_root / provider / 'conversations.json'
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open('w') as file:
        json.dump(combined, file, indent=2)
        file.write('\n')

    print(f'[{provider}] combined {len(files)} files -> {output_path}')
    print(f'[{provider}] total conversations: {len(combined)}')


def discover_input_files(raw_provider_dir: Path, provider: str) -> list[Path]:
    paths: list[Path] = []
    seen: set[Path] = set()
    for pattern in DEFAULT_PATTERNS[provider]:
        for path in sorted(raw_provider_dir.glob(pattern)):
            resolved = path.resolve()
            if resolved in seen:
                continue
            seen.add(resolved)
            paths.append(path)
    return paths


def load_json_array(path: Path) -> list[object]:
    with path.open() as file:
        payload = json.load(file)
    if not isinstance(payload, list):
        raise SystemExit(
            f'Expected {path} to contain a JSON array, got {type(payload).__name__}.'
        )
    return payload


if __name__ == '__main__':
    main()
