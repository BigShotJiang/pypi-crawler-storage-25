from __future__ import annotations

import argparse
import pickle
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from scripts.parse_validate_clean import (
    resolve_providers,
    validate_provider_conversations,
)

PROVIDERS = ('openai', 'anthropic')


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description='Validate combined exports, then merge provider histories into one pickle with provider tags.'
    )
    parser.add_argument(
        '--provider',
        choices=(*PROVIDERS, 'all'),
        default='all',
        help='Provider to process. Use "all" to process both providers.',
    )
    parser.add_argument(
        '--combined-root',
        type=Path,
        default=Path('data/combined'),
        help='Root directory that contains provider combined JSON files.',
    )
    parser.add_argument(
        '--output-pkl',
        type=Path,
        default=Path('data/merged/all-conversations-clean.pkl'),
        help='Output pickle path for merged history.',
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    providers = resolve_providers(args.provider)
    merged = merge_provider_histories(
        providers=providers,
        combined_root=args.combined_root.resolve(),
    )
    write_merged_output(merged, args.output_pkl.resolve())


def merge_provider_histories(
    providers: tuple[str, ...],
    combined_root: Path,
) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    for provider in providers:
        convos = validate_provider_conversations(
            provider=provider,
            combined_root=combined_root,
        )
        print(f'[{provider}] validation succeeded for {len(convos)} conversations.')

        for convo in convos:
            payload = model_to_dict(convo)
            records.append(
                {
                    'provider': provider,
                    'conversation_id': payload.get('id') or payload.get('uuid'),
                    'created_at': get_created_at(provider, payload),
                    'conversation': payload,
                }
            )

    records.sort(
        key=lambda record: to_sortable_datetime(record['created_at']), reverse=True
    )
    return records


def write_merged_output(records: list[dict[str, Any]], output_pkl: Path) -> None:
    output_pkl.parent.mkdir(parents=True, exist_ok=True)
    with output_pkl.open('wb') as file:
        pickle.dump(records, file)
    print(f'Merged {len(records)} conversations -> {output_pkl}')


def model_to_dict(model: Any) -> dict[str, Any]:
    if hasattr(model, 'model_dump'):
        return model.model_dump()
    if isinstance(model, dict):
        return model
    raise TypeError(f'Unsupported conversation payload type: {type(model).__name__}')


def get_created_at(provider: str, payload: dict[str, Any]) -> float | int | str:
    if provider == 'openai':
        return float(payload['create_time'])
    return str(payload['created_at'])


def to_sortable_datetime(value: float | int | str) -> datetime:
    if isinstance(value, (float, int)):
        return datetime.fromtimestamp(float(value), tz=UTC)
    return datetime.fromisoformat(value.replace('Z', '+00:00')).astimezone(UTC)


if __name__ == '__main__':
    main()
