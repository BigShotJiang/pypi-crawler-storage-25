"""Provider-specific chat history models."""
