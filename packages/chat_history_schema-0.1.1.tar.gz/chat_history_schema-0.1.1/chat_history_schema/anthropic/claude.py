from __future__ import annotations

from typing import Annotated, Any, Literal as Lit

import pydantic as pyd

from .config import Model


class ClaudeConversation(Model):
    uuid: str
    name: str
    summary: str
    created_at: str
    updated_at: str
    account: ClaudeAccount
    chat_messages: list[ClaudeChatMessage]


class ClaudeAccount(Model):
    uuid: str


class ClaudeChatMessage(Model):
    uuid: str
    text: str
    content: list[ClaudeContent]
    sender: Lit['human', 'assistant']
    created_at: str
    updated_at: str
    attachments: list[ClaudeAttachment]
    files: list[ClaudeFile]


class ClaudeAttachment(Model):
    file_name: str
    file_size: int
    file_type: str
    extracted_content: str


class ClaudeFile(Model):
    file_name: str


class ClaudeTextCitation(Model):
    uuid: str
    start_index: int
    end_index: int
    details: dict[str, Any]


class ClaudeTextContent(Model):
    start_timestamp: str | None
    stop_timestamp: str | None
    flags: None
    type: Lit['text']
    text: str
    citations: list[ClaudeTextCitation]


class ClaudeToolUseContent(Model):
    start_timestamp: str | None
    stop_timestamp: str | None
    flags: None
    type: Lit['tool_use']
    id: str | None
    name: str
    input: dict[str, Any]
    message: str | None
    integration_name: str | None
    integration_icon_url: str | None
    icon_name: str | None
    context: None
    display_content: dict[str, Any] | None
    approval_options: None
    approval_key: None
    is_mcp_app: bool | None
    mcp_server_url: None


class ClaudeToolResultTextContent(Model):
    type: Lit['text']
    text: str
    uuid: str


class ClaudeToolResultKnowledgeContent(Model):
    type: Lit['knowledge']
    title: str
    text: str
    url: str
    is_citable: bool
    is_missing: bool
    metadata: dict[str, Any]
    prompt_context_metadata: dict[str, Any]


class ClaudeToolResultLocalResourceContent(Model):
    type: Lit['local_resource']
    file_path: str
    mime_type: str | None
    name: str
    uuid: str


class ClaudeToolResultImageGalleryContent(Model):
    type: Lit['image_gallery']
    images: list[dict[str, Any]]
    is_expired: bool
    uuid: str


class ClaudeToolResultImageContent(Model):
    type: Lit['image']
    file_uuid: str


type ClaudeToolResultItem = Annotated[
    ClaudeToolResultTextContent
    | ClaudeToolResultKnowledgeContent
    | ClaudeToolResultLocalResourceContent
    | ClaudeToolResultImageGalleryContent
    | ClaudeToolResultImageContent,
    pyd.Discriminator('type'),
]


class ClaudeToolResultContent(Model):
    start_timestamp: str | None
    stop_timestamp: str | None
    flags: None
    type: Lit['tool_result']
    tool_use_id: str | None
    name: str
    content: list[ClaudeToolResultItem]
    is_error: bool
    structured_content: dict[str, Any] | None
    meta: None
    message: str | None
    integration_name: str | None
    mcp_server_url: None
    integration_icon_url: str | None
    icon_name: str | None
    display_content: dict[str, Any] | None


class ClaudeTokenBudgetContent(Model):
    start_timestamp: None
    stop_timestamp: None
    flags: None
    type: Lit['token_budget']


class ClaudeThinkingSummary(Model):
    summary: str


class ClaudeThinkingContent(Model):
    start_timestamp: str
    stop_timestamp: str
    flags: None
    type: Lit['thinking']
    thinking: str
    summaries: list[ClaudeThinkingSummary]
    cut_off: bool
    truncated: bool
    alternative_display_type: None
    signature: None


type ClaudeContent = Annotated[
    ClaudeTextContent
    | ClaudeToolUseContent
    | ClaudeToolResultContent
    | ClaudeTokenBudgetContent
    | ClaudeThinkingContent,
    pyd.Discriminator('type'),
]


ClaudeConversation.model_rebuild()
