from pydantic import BaseModel, ConfigDict


def to_camel(name: str) -> str:
    is_camel_or_pascal = '_' not in name
    if is_camel_or_pascal:
        return name[0].lower() + name[1:]
    s = name.replace('_', ' ').title().replace(' ', '')
    return s[0].lower() + s[1:]


class Model(BaseModel):
    model_config = ConfigDict(
        extra='forbid',
        strict=True,
        protected_namespaces=(),
        alias_generator=to_camel,
        populate_by_name=True,
    )
