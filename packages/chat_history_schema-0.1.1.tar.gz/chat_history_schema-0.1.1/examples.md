# Usage Examples

## 1) Combine raw exports by provider

```bash
python scripts/combine_conversations.py --provider all
```

## 2) Validate each provider

```bash
python scripts/parse_validate_clean.py --provider all
```

## 3) Merge both providers into one unified history file

```bash
python scripts/merge_provider_histories.py --provider all
```

## 4) Run everything end-to-end in one command

```bash
python scripts/run_pipeline.py --provider all
```

## 5) Run per-provider steps manually

```bash
python scripts/combine_conversations.py --provider openai
python scripts/parse_validate_clean.py --provider openai
python scripts/merge_provider_histories.py --provider openai

python scripts/combine_conversations.py --provider anthropic
python scripts/parse_validate_clean.py --provider anthropic
python scripts/merge_provider_histories.py --provider anthropic
```
