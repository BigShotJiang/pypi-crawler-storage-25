#!/usr/bin/env bash
# 一键升级版本号 + 构建分发包 + 上传
# 用法：
#   ./publish.sh patch
#   ./publish.sh minor
#   ./publish.sh major
#   ./publish.sh           # 默认 patch
#
# 可选环境变量：
#   AUTO_CONFIRM=1       跳过确认提示
#   DRY_RUN=1            执行构建和校验，但不上传，并在结束后回滚版本号
#   USE_CIBUILDWHEEL=0   强制跳过 cibuildwheel
#   USE_CIBUILDWHEEL=1   允许在需要平台轮子时使用 cibuildwheel（默认）
#   ENABLE_CYTHON=1      额外执行 in-place cythonize（默认关闭）
#   PRIVATE_PYPI_URL=... 上传到私有仓库

set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT_DIR"

PYPROJECT="$ROOT_DIR/pyproject.toml"
BUMP_TYPE="${1:-patch}"
AUTO_CONFIRM="${AUTO_CONFIRM:-0}"
DRY_RUN="${DRY_RUN:-0}"
USE_CIBUILDWHEEL="${USE_CIBUILDWHEEL:-1}"
ENABLE_CYTHON="${ENABLE_CYTHON:-0}"
PRIVATE_PYPI_URL="${PRIVATE_PYPI_URL:-}"

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; BOLD='\033[1m'; RESET='\033[0m'

info()    { echo -e "${BLUE}[INFO]${RESET} $*"; }
success() { echo -e "${GREEN}[OK]${RESET}  $*"; }
warn()    { echo -e "${YELLOW}[WARN]${RESET} $*"; }
error()   { echo -e "${RED}[ERROR]${RESET} $*"; exit 1; }

[[ "$BUMP_TYPE" =~ ^(patch|minor|major)$ ]] \
    || error "参数必须是 patch / minor / major，当前：$BUMP_TYPE"

detect_package_dir() {
    local package_dir

    package_dir="$(
        awk '
            /^\[tool\.hatch\.build\.targets\.wheel\]$/ { in_section = 1; next }
            /^\[/ { if (in_section) exit; in_section = 0 }
            in_section && /^packages = \[/ {
                line = $0
                sub(/^packages = \["/, "", line)
                sub(/".*$/, "", line)
                print line
                exit
            }
        ' "$PYPROJECT"
    )"
    if [[ -n "$package_dir" && -d "$ROOT_DIR/$package_dir" ]]; then
        printf '%s\n' "$package_dir"
        return 0
    fi

    package_dir="$(find "$ROOT_DIR" -mindepth 2 -maxdepth 2 -type f -name "__init__.py" \
        ! -path '*/tests/*' ! -path '*/.*/*' \
        -exec dirname {} \; | head -n1)"
    if [[ -n "$package_dir" ]]; then
        basename "$package_dir"
        return 0
    fi

    return 1
}

ensure_python_pip() {
    if python3 -m pip --version >/dev/null 2>&1; then
        return 0
    fi

    warn "当前 python3 缺少 pip，尝试使用 ensurepip 修复..."
    python3 -m ensurepip --upgrade >/dev/null 2>&1 \
        || error "当前 python3 不包含 pip/ensurepip，请切换到带 pip 的解释器后重试"
    python3 -m pip --version >/dev/null 2>&1 \
        || error "pip 修复失败，请检查当前 python3 环境"
}

is_pure_python_wheel() {
    local wheel_path="$1"
    [[ "$wheel_path" == *"-none-any.whl" ]]
}

CURRENT_VERSION="$(grep -m1 '^version = ' "$PYPROJECT" | sed 's/version = "\(.*\)"/\1/')"
[[ -n "$CURRENT_VERSION" ]] || error "无法从 $PYPROJECT 读取 version 字段"
IFS='.' read -r MAJOR MINOR PATCH <<< "$CURRENT_VERSION"

case "$BUMP_TYPE" in
    patch) PATCH=$((PATCH + 1)) ;;
    minor) MINOR=$((MINOR + 1)); PATCH=0 ;;
    major) MAJOR=$((MAJOR + 1)); MINOR=0; PATCH=0 ;;
esac
NEW_VERSION="${MAJOR}.${MINOR}.${PATCH}"
NEW_FALLBACK_VERSION="${NEW_VERSION}-dev"

PACKAGE_DIR="$(detect_package_dir)" || error "无法自动探测包目录，请检查 $PYPROJECT 的 wheel packages 配置"
VERSION_FILE="$ROOT_DIR/$PACKAGE_DIR/version.py"

PYPROJECT_BAK="$(mktemp)"
VERSION_FILE_BAK=""
ROLLBACK_REQUIRED=0

cleanup_backups() {
    rm -f "$PYPROJECT_BAK"
    if [[ -n "$VERSION_FILE_BAK" ]]; then
        rm -f "$VERSION_FILE_BAK"
    fi
}

rollback_versions() {
    if [[ "$ROLLBACK_REQUIRED" != "1" ]]; then
        return
    fi

    cp "$PYPROJECT_BAK" "$PYPROJECT"
    if [[ -n "$VERSION_FILE_BAK" && -f "$VERSION_FILE" ]]; then
        cp "$VERSION_FILE_BAK" "$VERSION_FILE"
    fi
    warn "已回滚版本文件到发布前状态"
}

trap 'status=$?; if [[ $status -ne 0 ]]; then rollback_versions; fi; cleanup_backups' EXIT

echo -e "\n${BOLD}======================================${RESET}"
echo -e "${BOLD} 发布脚本（稳健版）${RESET}"
echo -e "${BOLD}======================================${RESET}"
echo -e "  包目录    ：${BLUE}${PACKAGE_DIR}${RESET}"
echo -e "  当前版本：${YELLOW}${CURRENT_VERSION}${RESET}"
echo -e "  新版本  ：${GREEN}${NEW_VERSION}${RESET}  (${BUMP_TYPE})"
echo -e "  Dry Run ：${YELLOW}${DRY_RUN}${RESET}"
echo -e "${BOLD}======================================${RESET}\n"

if [[ "$AUTO_CONFIRM" != "1" ]]; then
    read -rp "确认发布？[y/N] " CONFIRM
    [[ "$CONFIRM" =~ ^[Yy]$ ]] || { warn "已取消"; exit 0; }
fi

info "Step 1/10 检查依赖工具..."
command -v python3 &>/dev/null || error "未找到 python3"
ensure_python_pip
python3 -c "import build" 2>/dev/null || { warn "正在安装 build..."; python3 -m pip install build -q; }
python3 -c "import twine" 2>/dev/null || { warn "正在安装 twine..."; python3 -m pip install twine -q; }
if [[ "$ENABLE_CYTHON" == "1" ]]; then
    python3 -c "import Cython" 2>/dev/null || { warn "正在安装 Cython..."; python3 -m pip install cython -q; }
fi
success "工具检查通过"

info "Step 2/10 校验项目结构..."
[[ -d "$ROOT_DIR/$PACKAGE_DIR" ]] || error "包目录不存在：$ROOT_DIR/$PACKAGE_DIR"
if [[ -f "$VERSION_FILE" ]]; then
    grep -q '^FALLBACK_VERSION = "' "$VERSION_FILE" \
        || error "未在 $VERSION_FILE 找到 FALLBACK_VERSION，无法同步开发态版本"
else
    warn "未找到 $VERSION_FILE，发布时将只更新 pyproject.toml"
fi
success "项目结构校验通过"

info "Step 3/10 更新版本号 → ${NEW_VERSION}..."
cp "$PYPROJECT" "$PYPROJECT_BAK"
if [[ -f "$VERSION_FILE" ]]; then
    VERSION_FILE_BAK="$(mktemp)"
    cp "$VERSION_FILE" "$VERSION_FILE_BAK"
fi
ROLLBACK_REQUIRED=1

sed -i.bak "s/^version = \"${CURRENT_VERSION}\"/version = \"${NEW_VERSION}\"/" "$PYPROJECT"
rm -f "${PYPROJECT}.bak"

if [[ -f "$VERSION_FILE" ]]; then
    sed -i.bak "s/^FALLBACK_VERSION = \".*\"/FALLBACK_VERSION = \"${NEW_FALLBACK_VERSION}\"/" "$VERSION_FILE"
    rm -f "${VERSION_FILE}.bak"
fi
success "版本号已更新"

info "Step 4/10 清理旧构建产物..."
rm -rf dist/ build/ *.egg-info/
success "清理完成"

info "Step 5/10 处理可选 Cython 编译..."
if [[ "$ENABLE_CYTHON" == "1" ]]; then
    mapfile -t pyfiles < <(find "$ROOT_DIR/$PACKAGE_DIR" -type f -name "*.py" ! -name "__init__.py" | sort)
    if [[ "${#pyfiles[@]}" -eq 0 ]]; then
        warn "未找到可编译的 Python 源文件，跳过 Cython"
    else
        for pyfile in "${pyfiles[@]}"; do
            info "  编译 ${pyfile#$ROOT_DIR/}"
            cythonize -3 -i "$pyfile"
        done
        success "Cython 编译完成"
    fi
else
    warn "默认跳过 Cython。当前项目使用 hatchling，in-place cythonize 不会自动变成可靠的发布产物。"
fi

info "Step 6/10 构建分发包..."
info "  构建 sdist..."
python3 -m build --sdist --outdir dist

info "  预构建 wheel，用于判断是否为纯 Python 包..."
python3 -m build --wheel --outdir dist

shopt -s nullglob
probe_wheels=(dist/*.whl)
shopt -u nullglob
[[ "${#probe_wheels[@]}" -gt 0 ]] || error "预构建 wheel 失败，dist/ 中未发现 wheel 产物"
PROBE_WHEEL="${probe_wheels[0]}"

if is_pure_python_wheel "$PROBE_WHEEL"; then
    warn "检测到纯 Python wheel：$(basename "$PROBE_WHEEL")"
    warn "纯 Python 包不需要 cibuildwheel，保留当前 wheel 作为发布产物"
elif [[ "$USE_CIBUILDWHEEL" == "1" ]]; then
    info "  检测到平台相关 wheel，切换到 cibuildwheel 生成多 Python 版本产物..."
    python3 -c "import cibuildwheel" 2>/dev/null || { warn "正在安装 cibuildwheel..."; python3 -m pip install cibuildwheel -q; }
    rm -f dist/*.whl
    cibuildwheel --output-dir dist
else
    warn "检测到平台相关 wheel，但 USE_CIBUILDWHEEL=0；将仅发布当前解释器构建的 wheel"
fi
success "构建完成"

info "Step 7/10 校验包（twine check）..."
shopt -s nullglob
artifacts=(dist/*)
shopt -u nullglob
[[ "${#artifacts[@]}" -gt 0 ]] || error "dist/ 目录为空，未生成任何构建产物"
twine check "${artifacts[@]}"
success "校验通过"
printf '%s\n' "${artifacts[@]##$ROOT_DIR/}" | sed 's/^/    /'

info "Step 8/10 上传包..."
if [[ "$DRY_RUN" == "1" ]]; then
    warn "DRY_RUN=1，跳过上传"
elif [[ -n "$PRIVATE_PYPI_URL" ]]; then
    twine upload --repository-url "$PRIVATE_PYPI_URL" "${artifacts[@]}"
else
    twine upload "${artifacts[@]}"
fi
success "上传步骤完成"

info "Step 9/10 清理临时编译文件..."
if [[ "$ENABLE_CYTHON" == "1" ]]; then
    find "$ROOT_DIR/$PACKAGE_DIR" -type f \( -name "*.c" -o -name "*.so" -o -name "*.pyd" \) -delete
    success "临时编译文件清理完成"
else
    warn "未启用 Cython，无需清理临时编译文件"
fi

if [[ "$DRY_RUN" == "1" ]]; then
    rollback_versions
    ROLLBACK_REQUIRED=0
fi

if [[ "$DRY_RUN" != "1" ]]; then
    ROLLBACK_REQUIRED=0
fi

echo ""
info "Step 10/10 完成提示："
echo "    pip install aukeys-opscli==${NEW_VERSION}"
echo "    opscli --version"
echo ""
if [[ "$DRY_RUN" == "1" ]]; then
    success "Dry run 完成，版本文件已回滚，可直接检查 dist/ 产物"
else
    success "全部完成 aukeys-opscli v${NEW_VERSION} 已发布"
fi
