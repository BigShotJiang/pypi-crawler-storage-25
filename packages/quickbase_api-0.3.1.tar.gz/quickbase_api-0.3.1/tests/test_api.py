"""Tests for QuickbaseClient high-level API methods."""

import json

import pytest

from quickbase_api.exceptions import QuickbaseAPIError, QuickbaseNotFoundError

BASE_URL = "https://api.quickbase.com/v1"
REALM = "testrealm.quickbase.com"


# ── App Tests ────────────────────────────────────────────────────────────


class TestCreateApp:
    def test_create_app_success(self, mock_api, client):
        mock_api.post(
            f"{BASE_URL}/apps",
            json={"id": "abc123", "name": "Test App"},
            status=200,
        )
        result = client.create_app("Test App")
        assert result["id"] == "abc123"
        assert result["name"] == "Test App"

    def test_create_app_with_optional_params(self, mock_api, client):
        mock_api.post(
            f"{BASE_URL}/apps",
            json={"id": "abc123", "name": "Test App"},
            status=200,
        )
        result = client.create_app(
            "Test App",
            description="A test",
            assign_token=True,
        )
        assert result["id"] == "abc123"

    def test_create_app_failure_raises(self, mock_api, client):
        mock_api.post(
            f"{BASE_URL}/apps",
            json={"message": "Unauthorized"},
            status=401,
        )
        with pytest.raises(QuickbaseAPIError) as exc_info:
            client.create_app("Test App")
        assert exc_info.value.status_code == 401

    def test_create_app_returns_dict(self, mock_api, client):
        mock_api.post(
            f"{BASE_URL}/apps",
            json={"id": "abc123", "name": "Test App", "description": "test"},
            status=200,
        )
        result = client.create_app("Test App")
        assert isinstance(result, dict)

    def test_create_app_keyword_only(self, client):
        with pytest.raises(TypeError):
            client.create_app("Test App", "description", True)


class TestDeleteApp:
    def test_delete_app_success(self, mock_api, client):
        mock_api.delete(
            f"{BASE_URL}/apps/abc123",
            json={"deletedAppId": "abc123"},
            status=200,
        )
        result = client.delete_app("abc123", app_name="Test App")
        assert result["deletedAppId"] == "abc123"

    def test_delete_app_failure_raises(self, mock_api, client):
        mock_api.delete(
            f"{BASE_URL}/apps/abc123",
            json={"message": "Not found"},
            status=404,
        )
        with pytest.raises(QuickbaseAPIError):
            client.delete_app("abc123", app_name="Test App")

    def test_delete_app_keyword_only(self, client):
        with pytest.raises(TypeError):
            client.delete_app("abc123", "Test App")


class TestGetApp:
    def test_get_app_success(self, mock_api, client):
        mock_api.get(
            f"{BASE_URL}/apps/abc123",
            json={"id": "abc123", "name": "Test App"},
            status=200,
        )
        app = client.get_app("abc123")
        assert app["name"] == "Test App"

    def test_get_app_failure_raises(self, mock_api, client):
        mock_api.get(
            f"{BASE_URL}/apps/invalid",
            json={"message": "Not found"},
            status=404,
        )
        with pytest.raises(QuickbaseAPIError):
            client.get_app("invalid")


class TestCopyApp:
    def test_copy_app_success(self, mock_api, client):
        mock_api.get(
            f"{BASE_URL}/apps/abc123",
            json={"id": "abc123", "name": "Original App", "description": "Original desc"},
            status=200,
        )
        mock_api.post(
            f"{BASE_URL}/apps/abc123/copy",
            json={"id": "xyz789", "name": "Copy of Original App"},
            status=200,
        )
        result = client.copy_app("abc123")
        assert result["id"] == "xyz789"
        assert result["name"] == "Copy of Original App"

    def test_copy_app_default_name(self, mock_api, client):
        mock_api.get(
            f"{BASE_URL}/apps/abc123",
            json={"id": "abc123", "name": "My App", "description": "desc"},
            status=200,
        )
        mock_api.post(
            f"{BASE_URL}/apps/abc123/copy",
            json={"id": "xyz789", "name": "Copy of My App"},
            status=200,
        )
        client.copy_app("abc123")
        body = json.loads(mock_api.calls[1].request.body)
        assert body["name"] == "Copy of My App"

    def test_copy_app_default_description(self, mock_api, client):
        mock_api.get(
            f"{BASE_URL}/apps/abc123",
            json={"id": "abc123", "name": "My App", "description": "Original desc"},
            status=200,
        )
        mock_api.post(
            f"{BASE_URL}/apps/abc123/copy",
            json={"id": "xyz789", "name": "Copy of My App"},
            status=200,
        )
        client.copy_app("abc123")
        body = json.loads(mock_api.calls[1].request.body)
        assert body["description"] == "Original desc"

    def test_copy_app_custom_name_skips_get(self, mock_api, client):
        mock_api.post(
            f"{BASE_URL}/apps/abc123/copy",
            json={"id": "xyz789", "name": "Custom Name"},
            status=200,
        )
        client.copy_app("abc123", name="Custom Name", description="Custom desc")
        assert len(mock_api.calls) == 1  # no GET call

    def test_copy_app_with_properties(self, mock_api, client):
        mock_api.post(
            f"{BASE_URL}/apps/abc123/copy",
            json={"id": "xyz789", "name": "Copy"},
            status=200,
        )
        client.copy_app(
            "abc123",
            name="Copy",
            description="desc",
            keep_data=True,
            exclude_files=False,
            users_and_roles=True,
            assign_user_token=True,
        )
        body = json.loads(mock_api.calls[0].request.body)
        assert body["properties"]["keepData"] is True
        assert body["properties"]["excludeFiles"] is False
        assert body["properties"]["usersAndRoles"] is True
        assert body["properties"]["assignUserToken"] is True

    def test_copy_app_omits_empty_properties(self, mock_api, client):
        mock_api.post(
            f"{BASE_URL}/apps/abc123/copy",
            json={"id": "xyz789", "name": "Copy"},
            status=200,
        )
        client.copy_app("abc123", name="Copy", description="desc")
        body = json.loads(mock_api.calls[0].request.body)
        assert "properties" not in body

    def test_copy_app_failure_raises(self, mock_api, client):
        mock_api.post(
            f"{BASE_URL}/apps/abc123/copy",
            json={"message": "Unauthorized"},
            status=401,
        )
        with pytest.raises(QuickbaseAPIError):
            client.copy_app("abc123", name="Copy", description="desc")

    def test_copy_app_keyword_only(self, client):
        with pytest.raises(TypeError):
            client.copy_app("abc123", "Copy Name")

    def test_copy_app_returns_dict(self, mock_api, client):
        mock_api.post(
            f"{BASE_URL}/apps/abc123/copy",
            json={"id": "xyz789", "name": "Copy", "created": "2024-01-01"},
            status=200,
        )
        result = client.copy_app("abc123", name="Copy", description="desc")
        assert isinstance(result, dict)
        assert "created" in result


# ── Table Tests ──────────────────────────────────────────────────────────


class TestCreateTable:
    def test_create_table_success(self, mock_api, client):
        mock_api.post(
            f"{BASE_URL}/tables",
            json={"id": "tbl1", "name": "Customers"},
            status=200,
        )
        result = client.create_table("abc123", name="Customers")
        assert result["id"] == "tbl1"
        assert result["name"] == "Customers"

    def test_create_table_returns_dict(self, mock_api, client):
        mock_api.post(
            f"{BASE_URL}/tables",
            json={"id": "tbl1", "name": "Customers", "description": "test"},
            status=200,
        )
        result = client.create_table("abc123", name="Customers")
        assert isinstance(result, dict)

    def test_create_table_with_all_params(self, mock_api, client):
        mock_api.post(
            f"{BASE_URL}/tables",
            json={"id": "tbl1", "name": "Tasks"},
            status=200,
        )
        client.create_table(
            "abc123",
            name="Tasks",
            description="Task tracker",
            single_record_name="Task",
            plural_record_name="Tasks",
            icon_name="Briefcase",
            color="#ff0000",
        )
        body = json.loads(mock_api.calls[0].request.body)
        assert body["name"] == "Tasks"
        assert body["description"] == "Task tracker"
        assert body["singleRecordName"] == "Task"
        assert body["pluralRecordName"] == "Tasks"
        assert body["iconName"] == "Briefcase"
        assert body["color"] == "#ff0000"

    def test_create_table_omits_none_params(self, mock_api, client):
        mock_api.post(
            f"{BASE_URL}/tables",
            json={"id": "tbl1", "name": "Tasks"},
            status=200,
        )
        client.create_table("abc123", name="Tasks")
        body = json.loads(mock_api.calls[0].request.body)
        assert body == {"name": "Tasks"}

    def test_create_table_keyword_only(self, client):
        with pytest.raises(TypeError):
            client.create_table("abc123", "Tasks")


class TestGetTables:
    def test_get_tables_success(self, mock_api, client):
        mock_api.get(
            f"{BASE_URL}/tables",
            json=[
                {"id": "tbl1", "name": "Customers"},
                {"id": "tbl2", "name": "Orders"},
            ],
            status=200,
        )
        tables = client.get_tables("abc123")
        assert len(tables) == 2
        assert tables[0]["name"] == "Customers"


class TestGetTableId:
    def test_get_table_id_found(self, mock_api, client):
        mock_api.get(
            f"{BASE_URL}/tables",
            json=[
                {"id": "tbl1", "name": "Customers"},
                {"id": "tbl2", "name": "Orders"},
            ],
            status=200,
        )
        table_id = client.get_table_id("abc123", table_name="Orders")
        assert table_id == "tbl2"

    def test_get_table_id_not_found(self, mock_api, client):
        mock_api.get(
            f"{BASE_URL}/tables",
            json=[{"id": "tbl1", "name": "Customers"}],
            status=200,
        )
        with pytest.raises(QuickbaseNotFoundError):
            client.get_table_id("abc123", table_name="Nonexistent")

    def test_get_table_id_keyword_only(self, client):
        with pytest.raises(TypeError):
            client.get_table_id("abc123", "Orders")


class TestDeleteTable:
    def test_delete_table_success(self, mock_api, client):
        mock_api.delete(
            f"{BASE_URL}/tables/tbl1",
            json={"deletedTableId": "tbl1"},
            status=200,
        )
        result = client.delete_table("abc123", table_id="tbl1")
        assert result["deletedTableId"] == "tbl1"

    def test_delete_table_keyword_only(self, client):
        with pytest.raises(TypeError):
            client.delete_table("abc123", "tbl1")


# ── Report Tests ─────────────────────────────────────────────────────────


class TestGetReports:
    def test_get_reports_success(self, mock_api, client):
        mock_api.get(
            f"{BASE_URL}/reports",
            json=[{"id": "1", "name": "List All"}],
            status=200,
        )
        reports = client.get_reports("tbl1")
        assert len(reports) == 1


class TestGetReport:
    def test_get_report_success(self, mock_api, client):
        mock_api.get(
            f"{BASE_URL}/reports/1",
            json={"id": "1", "name": "List All"},
            status=200,
        )
        report = client.get_report("tbl1", report_id="1")
        assert report["name"] == "List All"

    def test_get_report_keyword_only(self, client):
        with pytest.raises(TypeError):
            client.get_report("tbl1", "1")


class TestRunReport:
    def test_run_report_success(self, mock_api, client):
        mock_api.post(
            f"{BASE_URL}/reports/1/run",
            json={"data": [{"6": {"value": "test"}}], "metadata": {}},
            status=200,
        )
        result = client.run_report("tbl1", report_id="1")
        assert "data" in result

    def test_run_report_with_pagination(self, mock_api, client):
        mock_api.post(
            f"{BASE_URL}/reports/1/run",
            json={"data": [], "metadata": {}},
            status=200,
        )
        client.run_report("tbl1", report_id="1", skip=10, top=50)
        params = mock_api.calls[0].request.params
        assert params["skip"] == "10"
        assert params["top"] == "50"

    def test_run_report_keyword_only(self, client):
        with pytest.raises(TypeError):
            client.run_report("tbl1", "1")


# ── Field Tests ──────────────────────────────────────────────────────────


class TestCreateField:
    def test_create_field_success(self, mock_api, client):
        mock_api.post(
            f"{BASE_URL}/fields",
            json={"id": 6, "label": "Name", "fieldType": "text"},
            status=200,
        )
        result = client.create_field("tbl1", label="Name", field_type="text")
        assert result["id"] == 6

    def test_create_field_with_all_params(self, mock_api, client):
        mock_api.post(
            f"{BASE_URL}/fields",
            json={"id": 6, "label": "Name", "fieldType": "text"},
            status=200,
        )
        client.create_field(
            "tbl1",
            label="Name",
            field_type="text",
            description="Full name",
            no_wrap=True,
            bold=True,
            required=True,
            appears_by_default=True,
            find_enabled=True,
            unique=True,
            field_help="Enter full name",
            add_to_forms=True,
            type_properties={"maxLength": 100},
            permissions=[{"role": "Viewer", "permissionType": "view"}],
        )
        body = json.loads(mock_api.calls[0].request.body)
        assert body["label"] == "Name"
        assert body["fieldType"] == "text"
        assert body["description"] == "Full name"
        assert body["noWrap"] is True
        assert body["bold"] is True
        assert body["required"] is True
        assert body["appearsByDefault"] is True
        assert body["findEnabled"] is True
        assert body["unique"] is True
        assert body["fieldHelp"] == "Enter full name"
        assert body["addToForms"] is True
        assert body["properties"] == {"maxLength": 100}
        assert body["permissions"] == [{"role": "Viewer", "permissionType": "view"}]

    def test_create_field_omits_none_params(self, mock_api, client):
        mock_api.post(
            f"{BASE_URL}/fields",
            json={"id": 6, "label": "Name", "fieldType": "text"},
            status=200,
        )
        client.create_field("tbl1", label="Name", field_type="text")
        body = json.loads(mock_api.calls[0].request.body)
        assert body == {"label": "Name", "fieldType": "text"}

    def test_create_field_failure_raises(self, mock_api, client):
        mock_api.post(
            f"{BASE_URL}/fields",
            json={"message": "Invalid field type"},
            status=400,
        )
        with pytest.raises(QuickbaseAPIError):
            client.create_field("tbl1", label="Bad", field_type="invalid")

    def test_create_field_keyword_only(self, client):
        with pytest.raises(TypeError):
            client.create_field("tbl1", "Name", "text")


class TestCreateFields:
    def test_create_fields_all_succeed(self, mock_api, client):
        mock_api.post(
            f"{BASE_URL}/fields",
            json={"id": 6, "label": "Name", "fieldType": "text"},
            status=200,
        )
        mock_api.post(
            f"{BASE_URL}/fields",
            json={"id": 7, "label": "Email", "fieldType": "email"},
            status=200,
        )
        results = client.create_fields(
            "tbl1",
            fields=[
                {"label": "Name", "field_type": "text"},
                {"label": "Email", "field_type": "email"},
            ],
        )
        assert len(results["succeeded"]) == 2
        assert len(results["failed"]) == 0

    def test_create_fields_partial_failure(self, mock_api, client):
        mock_api.post(
            f"{BASE_URL}/fields",
            json={"id": 6, "label": "Name", "fieldType": "text"},
            status=200,
        )
        mock_api.post(
            f"{BASE_URL}/fields",
            json={"message": "Invalid"},
            status=400,
        )
        results = client.create_fields(
            "tbl1",
            fields=[
                {"label": "Name", "field_type": "text"},
                {"label": "Bad", "field_type": "invalid"},
            ],
        )
        assert len(results["succeeded"]) == 1
        assert len(results["failed"]) == 1

    def test_create_fields_keyword_only(self, client):
        with pytest.raises(TypeError):
            client.create_fields("tbl1", [{"label": "Name", "field_type": "text"}])


class TestGetTableFields:
    def test_get_table_fields_success(self, mock_api, client):
        mock_api.get(
            f"{BASE_URL}/fields",
            json=[
                {"id": 6, "label": "Name"},
                {"id": 7, "label": "Email"},
            ],
            status=200,
        )
        fields = client.get_table_fields("tbl1")
        assert len(fields) == 2


class TestGetFieldId:
    def test_get_field_id_found(self, mock_api, client):
        mock_api.get(
            f"{BASE_URL}/fields",
            json=[
                {"id": 6, "label": "Name"},
                {"id": 7, "label": "Email"},
            ],
            status=200,
        )
        field_id = client.get_field_id("tbl1", field_label="Email")
        assert field_id == "7"

    def test_get_field_id_not_found(self, mock_api, client):
        mock_api.get(
            f"{BASE_URL}/fields",
            json=[{"id": 6, "label": "Name"}],
            status=200,
        )
        with pytest.raises(QuickbaseNotFoundError):
            client.get_field_id("tbl1", field_label="Nonexistent")

    def test_get_field_id_keyword_only(self, client):
        with pytest.raises(TypeError):
            client.get_field_id("tbl1", "Email")


class TestGetFieldLabelIdMap:
    def test_builds_correct_mapping(self, mock_api, client):
        mock_api.get(
            f"{BASE_URL}/fields",
            json=[
                {"id": 6, "label": "Name"},
                {"id": 7, "label": "Email"},
                {"id": 8, "label": "Age"},
            ],
            status=200,
        )
        field_map = client.get_field_label_id_map("tbl1")
        assert field_map == {"Name": "6", "Email": "7", "Age": "8"}


class TestGetKeyFieldId:
    def test_get_key_field_id_success(self, mock_api, client):
        mock_api.get(
            f"{BASE_URL}/tables/tbl1",
            json={"id": "tbl1", "keyFieldId": 3},
            status=200,
        )
        key_field = client.get_key_field_id("abc123", table_id="tbl1")
        assert key_field == "3"

    def test_get_key_field_id_keyword_only(self, client):
        with pytest.raises(TypeError):
            client.get_key_field_id("abc123", "tbl1")


class TestSetKeyField:
    def test_set_key_field_success(self, mock_api, client):
        mock_api.post(
            f"https://{REALM}/db/tbl1",
            body="<?xml version='1.0'?><qdbapi><errcode>0</errcode></qdbapi>",
            status=200,
            content_type="application/xml",
        )
        result = client.set_key_field("tbl1", field_id="6")
        assert isinstance(result, dict)

    def test_set_key_field_xml_error_raises(self, mock_api, client):
        mock_api.post(
            f"https://{REALM}/db/tbl1",
            body="<?xml version='1.0'?><qdbapi><errcode>32</errcode><errtext>No such field</errtext></qdbapi>",
            status=200,
            content_type="application/xml",
        )
        with pytest.raises(QuickbaseAPIError):
            client.set_key_field("tbl1", field_id="6")

    def test_set_key_field_http_error_raises(self, mock_api, client):
        mock_api.post(
            f"https://{REALM}/db/tbl1",
            body="<?xml version='1.0'?><qdbapi><errcode>1</errcode><errtext>Failed</errtext></qdbapi>",
            status=400,
            content_type="application/xml",
        )
        with pytest.raises(QuickbaseAPIError):
            client.set_key_field("tbl1", field_id="6")

    def test_set_key_field_keyword_only(self, client):
        with pytest.raises(TypeError):
            client.set_key_field("tbl1", "6")


class TestSetRequiredField:
    def test_set_required_field_success(self, mock_api, client):
        mock_api.post(
            f"{BASE_URL}/fields/6",
            json={"id": 6, "required": True},
            status=200,
        )
        result = client.set_required_field("tbl1", field_id="6")
        assert isinstance(result, dict)
        assert result["required"] is True

    def test_set_required_field_keyword_only(self, client):
        with pytest.raises(TypeError):
            client.set_required_field("tbl1", "6")


# ── Record Tests ─────────────────────────────────────────────────────────


class TestUpsertRecords:
    def test_upsert_all_created(self, mock_api, client):
        mock_api.post(
            f"{BASE_URL}/records",
            json={
                "metadata": {
                    "totalNumberOfRecordsProcessed": 2,
                    "createdRecordIds": [1, 2],
                    "updatedRecordIds": [],
                    "unchangedRecordIds": [],
                },
            },
            status=200,
        )
        result = client.upsert_records(
            "tbl1",
            data=[
                {"6": {"value": "Alice"}},
                {"6": {"value": "Bob"}},
            ],
        )
        assert result["metadata"]["totalNumberOfRecordsProcessed"] == 2
        assert result["metadata"]["createdRecordIds"] == [1, 2]

    def test_upsert_returns_full_response(self, mock_api, client):
        mock_api.post(
            f"{BASE_URL}/records",
            json={
                "metadata": {
                    "totalNumberOfRecordsProcessed": 1,
                    "createdRecordIds": [1],
                    "updatedRecordIds": [],
                    "unchangedRecordIds": [],
                },
            },
            status=200,
        )
        result = client.upsert_records("tbl1", data=[{"6": {"value": "Alice"}}])
        assert "metadata" in result

    def test_upsert_partial_success_207(self, mock_api, client):
        mock_api.post(
            f"{BASE_URL}/records",
            json={
                "metadata": {
                    "totalNumberOfRecordsProcessed": 3,
                    "createdRecordIds": [1, 2],
                    "updatedRecordIds": [],
                    "unchangedRecordIds": [],
                    "lineErrors": {"3": ["Invalid value for field 7"]},
                },
            },
            status=207,
        )
        result = client.upsert_records(
            "tbl1",
            data=[
                {"6": {"value": "Alice"}},
                {"6": {"value": "Bob"}},
                {"6": {"value": "Bad"}},
            ],
        )
        assert "3" in result["metadata"]["lineErrors"]

    def test_upsert_all_updated(self, mock_api, client):
        mock_api.post(
            f"{BASE_URL}/records",
            json={
                "metadata": {
                    "totalNumberOfRecordsProcessed": 2,
                    "createdRecordIds": [],
                    "updatedRecordIds": [1, 2],
                    "unchangedRecordIds": [],
                },
            },
            status=200,
        )
        result = client.upsert_records(
            "tbl1",
            data=[
                {"3": {"value": 1}, "6": {"value": "Updated Alice"}},
                {"3": {"value": 2}, "6": {"value": "Updated Bob"}},
            ],
        )
        assert result["metadata"]["updatedRecordIds"] == [1, 2]

        def test_upsert_failure_raises(self, mock_api, client):
            mock_api.post(
                f"{BASE_URL}/records",
                json={"message": "Unauthorized"},
                status=401,
            )
            with pytest.raises(QuickbaseAPIError):
                client.upsert_records("tbl1", data=[{"6": {"value": "test"}}])

        def test_upsert_keyword_only(self, client):
            with pytest.raises(TypeError):
                client.upsert_records("tbl1", [{"6": {"value": "test"}}])


class TestSummarizeUpsert:
    def test_summarize_all_created(self, client):
        resp = {
            "metadata": {
                "totalNumberOfRecordsProcessed": 2,
                "createdRecordIds": [1, 2],
                "updatedRecordIds": [],
                "unchangedRecordIds": [],
            },
        }
        summary = client.summarize_upsert(resp)
        assert summary["created"] == 2
        assert summary["updated"] == 0
        assert summary["unchanged"] == 0
        assert summary["errored"] == 0
        assert summary["processed"] == 2

    def test_summarize_with_errors(self, client):
        resp = {
            "metadata": {
                "totalNumberOfRecordsProcessed": 3,
                "createdRecordIds": [1, 2],
                "updatedRecordIds": [],
                "unchangedRecordIds": [],
                "lineErrors": {"3": ["Invalid value"]},
            },
        }
        summary = client.summarize_upsert(resp)
        assert summary["created"] == 2
        assert summary["errored"] == 1
        assert summary["processed"] == 2
        assert "3" in summary["errored_details"]

    def test_summarize_mixed(self, client):
        resp = {
            "metadata": {
                "totalNumberOfRecordsProcessed": 4,
                "createdRecordIds": [1],
                "updatedRecordIds": [2],
                "unchangedRecordIds": [3],
                "lineErrors": {"4": ["Bad data"]},
            },
        }
        summary = client.summarize_upsert(resp)
        assert summary["created"] == 1
        assert summary["updated"] == 1
        assert summary["unchanged"] == 1
        assert summary["errored"] == 1
        assert summary["processed"] == 3


class TestDeleteRecords:
    def test_delete_records_success(self, mock_api, client):
        mock_api.delete(
            f"{BASE_URL}/records",
            json={"numberDeleted": 5},
            status=200,
        )
        result = client.delete_records("tbl1", where="{6.EX.'test'}")
        assert result["numberDeleted"] == 5

    def test_delete_records_returns_dict(self, mock_api, client):
        mock_api.delete(
            f"{BASE_URL}/records",
            json={"numberDeleted": 5},
            status=200,
        )
        result = client.delete_records("tbl1", where="{6.EX.'test'}")
        assert isinstance(result, dict)

    def test_delete_records_failure_raises(self, mock_api, client):
        mock_api.delete(
            f"{BASE_URL}/records",
            json={"message": "Invalid query"},
            status=400,
        )
        with pytest.raises(QuickbaseAPIError):
            client.delete_records("tbl1", where="bad query")

    def test_delete_records_keyword_only(self, client):
        with pytest.raises(TypeError):
            client.delete_records("tbl1", "{6.EX.'test'}")


class TestQueryForData:
    def test_query_minimal(self, mock_api, client):
        mock_api.post(
            f"{BASE_URL}/records/query",
            json={
                "data": [{"6": {"value": "Alice"}}],
                "fields": [{"id": 6, "label": "Name"}],
                "metadata": {"totalRecordCount": 1},
            },
            status=200,
        )
        result = client.query_for_data("tbl1")
        assert len(result["data"]) == 1

    def test_query_with_all_params(self, mock_api, client):
        mock_api.post(
            f"{BASE_URL}/records/query",
            json={"data": [], "fields": [], "metadata": {"totalRecordCount": 0}},
            status=200,
        )
        client.query_for_data(
            "tbl1",
            select=[6, 7],
            where="{6.EX.'test'}",
            sort_by=[{"fieldId": 6, "order": "ASC"}],
            group_by=[{"fieldId": 6, "grouping": "equal-values"}],
            options={"skip": 0, "top": 100},
        )
        body = json.loads(mock_api.calls[0].request.body)
        assert body["from"] == "tbl1"
        assert body["select"] == [6, 7]
        assert body["where"] == "{6.EX.'test'}"
        assert body["sortBy"] == [{"fieldId": 6, "order": "ASC"}]
        assert body["groupBy"] == [{"fieldId": 6, "grouping": "equal-values"}]
        assert body["options"] == {"skip": 0, "top": 100}

    def test_query_omits_none_params(self, mock_api, client):
        mock_api.post(
            f"{BASE_URL}/records/query",
            json={"data": [], "fields": [], "metadata": {}},
            status=200,
        )
        client.query_for_data("tbl1", select=[6])
        body = json.loads(mock_api.calls[0].request.body)
        assert body == {"from": "tbl1", "select": [6]}
        assert "where" not in body
        assert "sortBy" not in body

    def test_query_failure_raises(self, mock_api, client):
        mock_api.post(
            f"{BASE_URL}/records/query",
            json={"message": "Invalid query"},
            status=400,
        )
        with pytest.raises(QuickbaseAPIError):
            client.query_for_data("tbl1", where="bad")

    def test_query_keyword_only(self, client):
        with pytest.raises(TypeError):
            client.query_for_data("tbl1", [6, 7])


# ── User & Role Tests ───────────────────────────────────────────────────


class TestGetUser:
    def test_get_user_success(self, mock_api, client):
        mock_api.post(
            f"https://{REALM}/db/main",
            body=(
                "<?xml version='1.0'?><qdbapi>"
                "<errcode>0</errcode>"
                "<user id='58351651.xc1'>"
                "<firstName>John</firstName>"
                "<lastName>Doe</lastName>"
                "<login>john@example.com</login>"
                "<email>john@example.com</email>"
                "</user>"
                "</qdbapi>"
            ),
            status=200,
            content_type="application/xml",
        )
        user = client.get_user("john@example.com")
        assert user["id"] == "58351651.xc1"
        assert user["firstName"] == "John"
        assert user["lastName"] == "Doe"
        assert user["email"] == "john@example.com"

    def test_get_user_not_found(self, mock_api, client):
        mock_api.post(
            f"https://{REALM}/db/main",
            body=("<?xml version='1.0'?><qdbapi>" "<errcode>0</errcode>" "</qdbapi>"),
            status=200,
            content_type="application/xml",
        )
        user = client.get_user("nobody@example.com")
        assert user is None

    def test_get_user_xml_error_raises(self, mock_api, client):
        mock_api.post(
            f"https://{REALM}/db/main",
            body=(
                "<?xml version='1.0'?><qdbapi>" "<errcode>1</errcode>" "<errtext>Not authorized</errtext>" "</qdbapi>"
            ),
            status=200,
            content_type="application/xml",
        )
        with pytest.raises(QuickbaseAPIError):
            client.get_user("john@example.com")

    def test_get_user_lowercases_email(self, mock_api, client):
        mock_api.post(
            f"https://{REALM}/db/main",
            body=("<?xml version='1.0'?><qdbapi>" "<errcode>0</errcode>" "</qdbapi>"),
            status=200,
            content_type="application/xml",
        )
        client.get_user("John@Example.COM")
        body = mock_api.calls[0].request.body
        assert "john@example.com" in body


class TestAddUserToRole:
    def test_add_user_to_role_success(self, mock_api, client):
        mock_api.post(
            f"https://{REALM}/db/abc123",
            body=("<?xml version='1.0'?><qdbapi>" "<errcode>0</errcode>" "</qdbapi>"),
            status=200,
            content_type="application/xml",
        )
        result = client.add_user_to_role("abc123", user_id="58351651.xc1", role_id=12)
        assert isinstance(result, dict)

    def test_add_user_to_role_xml_error_raises(self, mock_api, client):
        mock_api.post(
            f"https://{REALM}/db/abc123",
            body=("<?xml version='1.0'?><qdbapi>" "<errcode>1</errcode>" "<errtext>Invalid user</errtext>" "</qdbapi>"),
            status=200,
            content_type="application/xml",
        )
        with pytest.raises(QuickbaseAPIError):
            client.add_user_to_role("abc123", user_id="bad", role_id=12)

    def test_add_user_to_role_keyword_only(self, client):
        with pytest.raises(TypeError):
            client.add_user_to_role("abc123", "58351651.xc1", 12)


# ── Internal Helper Tests ────────────────────────────────────────────────


class TestRequireLegacySuccess:
    def test_passes_on_success(self, client):
        resp = {"errcode": "0", "errtext": "No error"}
        result = client._require_legacy_success(resp, 200, "test")
        assert result == resp

    def test_raises_on_http_error(self, client):
        resp = {"errcode": "0"}
        with pytest.raises(QuickbaseAPIError):
            client._require_legacy_success(resp, 500, "test")

    def test_raises_on_xml_error(self, client):
        resp = {"errcode": "32", "errtext": "No such field"}
        with pytest.raises(QuickbaseAPIError):
            client._require_legacy_success(resp, 200, "test")

    def test_missing_errcode_treated_as_success(self, client):
        resp = {"some": "data"}
        result = client._require_legacy_success(resp, 200, "test")
        assert result == resp


class TestLegacyUrl:
    def test_builds_url(self, client):
        url = client._legacy_url("tbl1")
        assert url == f"https://{REALM}/db/tbl1"

    def test_builds_main_url(self, client):
        url = client._legacy_url("main")
        assert url == f"https://{REALM}/db/main"
