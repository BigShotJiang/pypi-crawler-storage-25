"""Shared test fixtures for the quickbase-api test suite."""

import pytest
import responses

from quickbase_api.client import QuickbaseClient
from quickbase_api.legacy_method import LegacyMethod
from quickbase_api.rest_method import RestMethod

REALM = "testrealm.quickbase.com"
USER_TOKEN = "test-token-123"
BASE_URL = "https://api.quickbase.com/v1"


@pytest.fixture
def rest():
    """Create a RestMethod instance for testing."""
    return RestMethod(REALM, USER_TOKEN)


@pytest.fixture
def legacy():
    """Create a LegacyMethod instance for testing."""
    return LegacyMethod(REALM, USER_TOKEN)


@pytest.fixture
def client():
    """Create a QuickbaseClient instance for testing."""
    return QuickbaseClient(REALM, USER_TOKEN)


@pytest.fixture
def mock_api():
    """Activate responses mock and yield for adding mock endpoints.

    Usage::

        def test_something(mock_api, client):
            mock_api.get(
                "https://api.quickbase.com/v1/apps/abc123",
                json={"id": "abc123", "name": "Test App"},
                status=200,
            )
            result = client.get_app("abc123")
            assert result["name"] == "Test App"
    """
    with responses.RequestsMock() as rsps:
        yield rsps
