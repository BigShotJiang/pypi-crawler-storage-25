"""Tests for Solutions API methods on QuickbaseClient."""

from unittest.mock import MagicMock, patch

import pytest

from quickbase_api.client import QuickbaseClient
from quickbase_api.exceptions import QuickbaseAPIError
from quickbase_api.qbl import QBLDiagnostics, merge_qbl_for_update

# Reuse the sample QBL from test_qbl
SAMPLE_QBL = """\
Version: '0.12'
ParameterDefinitions:
  $Param_App_Name:
    Value: My Test App
Resources:
  $App_My_Test_App:
    Type: QB::Application
    Properties:
      Name: My Test App
      AppColor: '#1a73e8'
      AppIcon: Briefcase
      Manager: owner@example.com
    Tables:
      $Table_Tasks:
        Type: QB::Table
        Properties:
          Name: Tasks
"""

SAMPLE_TARGET_QBL = """\
Version: '0.12'
ParameterDefinitions:
  $Param_App_Name:
    Value: Target App
  $Param_App_AppColor:
    Value: '#ff0000'
  $Param_App_AppIcon:
    Value: Globe
Resources:
  $App_Target_App:
    Type: QB::Application
    Properties:
      Name: Target App
      AppColor: '#ff0000'
      AppIcon: Globe
      Manager: other@example.com
    Tables:
      $Table_Tasks:
        Type: QB::Table
        Properties:
          Name: Tasks
"""


@pytest.fixture
def client():
    return QuickbaseClient("test.quickbase.com", "fake-token")


class TestExportSolution:

    def test_returns_qbl_string(self, client):
        with patch.object(client._rm, "make_request", return_value=(SAMPLE_QBL, 200)):
            result = client.export_solution("sol-123")
            assert "Version" in result
            assert "Resources" in result

    def test_raises_on_error(self, client):
        error = {"message": "Not found"}
        with patch.object(client._rm, "make_request", return_value=(error, 404)):
            with pytest.raises(QuickbaseAPIError):
                client.export_solution("bad-id")


class TestGetSolution:

    def test_returns_dict(self, client):
        response = {"solutionId": "sol-123", "resources": []}
        with patch.object(client._rm, "get", return_value=(response, 200)):
            result = client.get_solution("sol-123")
            assert result["solutionId"] == "sol-123"

    def test_raises_on_error(self, client):
        error = {"message": "Not found"}
        with patch.object(client._rm, "get", return_value=(error, 404)):
            with pytest.raises(QuickbaseAPIError):
                client.get_solution("bad-id")


class TestCreateSolution:

    def test_returns_response(self, client):
        response = {"solutionId": "sol-new"}
        with patch.object(client._rm, "make_request", return_value=(response, 200)):
            result = client.create_solution(SAMPLE_QBL)
            assert result["solutionId"] == "sol-new"

    def test_passes_body_not_data(self, client):
        response = {"solutionId": "sol-new"}
        with patch.object(client._rm, "make_request", return_value=(response, 200)) as mock:
            client.create_solution(SAMPLE_QBL)
            _, kwargs = mock.call_args
            assert kwargs["body"] == SAMPLE_QBL

    def test_raises_on_error(self, client):
        error = {"message": "Bad QBL"}
        with patch.object(client._rm, "make_request", return_value=(error, 400)):
            with pytest.raises(QuickbaseAPIError):
                client.create_solution(SAMPLE_QBL)


class TestUpdateSolution:

    def test_returns_response(self, client):
        response = {"status": "updated"}
        with patch.object(client._rm, "make_request", return_value=(response, 200)):
            result = client.update_solution("sol-123", qbl=SAMPLE_QBL)
            assert result["status"] == "updated"

    def test_raises_on_error(self, client):
        error = {"message": "Failed"}
        with patch.object(client._rm, "make_request", return_value=(error, 400)):
            with pytest.raises(QuickbaseAPIError):
                client.update_solution("sol-123", qbl=SAMPLE_QBL)


class TestListSolutionChanges:

    def test_returns_changeset(self, client):
        response = {"changes": ["add field", "modify report"]}
        with patch.object(client._rm, "make_request", return_value=(response, 200)):
            result = client.list_solution_changes("sol-123", qbl=SAMPLE_QBL)
            assert len(result["changes"]) == 2

    def test_raises_on_error(self, client):
        error = {"message": "Failed"}
        with patch.object(client._rm, "make_request", return_value=(error, 400)):
            with pytest.raises(QuickbaseAPIError):
                client.list_solution_changes("sol-123", qbl=SAMPLE_QBL)


class TestMergeQBLForUpdate:

    def test_preserves_target_logical_id(self):
        """Verify merged QBL uses target's logical ID, not source's."""
        merged_qbl, diagnostics = merge_qbl_for_update(SAMPLE_QBL, SAMPLE_TARGET_QBL)
        assert "$App_Target_App" in merged_qbl
        assert "$App_My_Test_App" not in merged_qbl

    def test_preserves_target_parameter_definitions(self):
        """Verify target's ParameterDefinitions are restored in merged QBL."""
        merged_qbl, diagnostics = merge_qbl_for_update(SAMPLE_QBL, SAMPLE_TARGET_QBL)
        assert "$Param_App_Name" in merged_qbl
        assert "$Param_App_AppColor" in merged_qbl
        assert "$Param_App_AppIcon" in merged_qbl

    def test_removes_manager_field(self):
        """Verify Manager field is stripped from the merged QBL."""
        merged_qbl, diagnostics = merge_qbl_for_update(SAMPLE_QBL, SAMPLE_TARGET_QBL)
        assert "Manager:" not in merged_qbl
        assert diagnostics.manager_removed is not None

    def test_includes_source_schema(self):
        """Verify source schema (tables, fields) is used in merged QBL."""
        merged_qbl, diagnostics = merge_qbl_for_update(SAMPLE_QBL, SAMPLE_TARGET_QBL)
        assert "$Table_Tasks" in merged_qbl

    def test_returns_diagnostics(self):
        """Verify diagnostics object is returned."""
        merged_qbl, diagnostics = merge_qbl_for_update(SAMPLE_QBL, SAMPLE_TARGET_QBL)
        assert isinstance(diagnostics, QBLDiagnostics)

    def test_diagnostics_summary(self):
        """Verify diagnostics can be summarized."""
        merged_qbl, diagnostics = merge_qbl_for_update(SAMPLE_QBL, SAMPLE_TARGET_QBL)
        summary = diagnostics.summary()
        assert isinstance(summary, str)
        assert "Manager" in summary or "No issues" in summary


class TestPushSolution:

    def test_preview_returns_changeset(self, client):
        changeset = {"changes": ["add field"]}
        with patch.object(
            client._rm,
            "make_request",
            side_effect=[
                (SAMPLE_QBL, 200),  # export source
                (SAMPLE_TARGET_QBL, 200),  # export target
                (changeset, 200),  # list changes
            ],
        ):
            result = client.push_solution(
                "sol-source",
                "sol-target",
                preview_only=True,
            )
            assert result["changes"] == ["add field"]

    def test_apply_returns_result_and_diagnostics(self, client):
        update_response = {"status": "updated"}
        with patch.object(
            client._rm,
            "make_request",
            side_effect=[
                (SAMPLE_QBL, 200),  # export source
                (SAMPLE_TARGET_QBL, 200),  # export target
                (update_response, 200),  # update
            ],
        ):
            result, diagnostics = client.push_solution(
                "sol-source",
                "sol-target",
            )
            assert result["status"] == "updated"
            assert isinstance(diagnostics, QBLDiagnostics)

    def test_rejects_same_ids(self, client):
        with pytest.raises(ValueError, match="same"):
            client.push_solution("sol-123", "sol-123")

    def test_raises_on_source_export_error(self, client):
        error = {"message": "Not found"}
        with patch.object(client._rm, "make_request", return_value=(error, 404)):
            with pytest.raises(QuickbaseAPIError):
                client.push_solution("bad-id", "sol-target")

    def test_merged_qbl_preserves_target_identity(self, client):
        """Verify merged QBL sent to update preserves target's logical ID."""
        update_response = {"status": "updated"}
        calls = []

        def capture_calls(method, endpoint, **kwargs):
            calls.append((method, endpoint, kwargs))
            if len(calls) == 1:
                return (SAMPLE_QBL, 200)
            elif len(calls) == 2:
                return (SAMPLE_TARGET_QBL, 200)
            else:
                return (update_response, 200)

        with patch.object(client._rm, "make_request", side_effect=capture_calls):
            result, diagnostics = client.push_solution("sol-source", "sol-target")

        # The third call is the update — check the body
        _, _, kwargs = calls[2]
        body = kwargs["body"]
        assert "$App_Target_App" in body
        assert "$App_My_Test_App" not in body

    def test_merged_qbl_removes_manager(self, client):
        """Verify Manager field is removed from merged QBL."""
        update_response = {"status": "updated"}
        calls = []

        def capture_calls(method, endpoint, **kwargs):
            calls.append((method, endpoint, kwargs))
            if len(calls) == 1:
                return (SAMPLE_QBL, 200)
            elif len(calls) == 2:
                return (SAMPLE_TARGET_QBL, 200)
            else:
                return (update_response, 200)

        with patch.object(client._rm, "make_request", side_effect=capture_calls):
            result, diagnostics = client.push_solution("sol-source", "sol-target")

        # The third call is the update — check the body
        _, _, kwargs = calls[2]
        body = kwargs["body"]
        assert "Manager:" not in body
        assert diagnostics.manager_removed is not None
