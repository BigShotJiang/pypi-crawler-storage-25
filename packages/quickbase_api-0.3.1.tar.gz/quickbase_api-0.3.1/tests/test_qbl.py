"""Tests for QBL parsing, modification, and serialization."""

import pytest

from quickbase_api.qbl import (
    QBLDiagnostics,
    collect_bad_refs,
    merge_qbl_for_update,
    parse_qbl,
    serialize_qbl,
)

# ── Sample QBL for testing ────────────────────────────────────────────

SAMPLE_QBL = """\
Version: '0.12'
ParameterDefinitions:
  $Param_App_Name:
    Value: My Test App
  $Param_App_AppColor:
    Value: '#1a73e8'
  $Param_App_AppIcon:
    Value: Briefcase
Resources:
  $App_My_Test_App:
    Type: QB::Application
    Properties:
      Name: My Test App
      AppColor: '#1a73e8'
      AppIcon: Briefcase
      Manager: owner@example.com
    Tables:
      $Table_Tasks:
        Type: QB::Table
        Properties:
          Name: Tasks
        Fields:
          $Field_Name:
            Type: QB::Field
            Properties:
              Label: Name
              FieldType: text
          $Field_Status:
            Type: QB::Field
            Properties:
              Label: Status
              FieldType: text
              FormulaRef: !Ref $Field_Name
          $Field_Owner:
            Type: QB::Field
            Properties:
              Label: Owner
              FieldType: text
              LookupRef: !BadRef $Field_Deleted_User
        Relationships:
          $Relationship_to_Projects_1:
            Type: QB::Relationship
            Properties:
              ParentTable: !Ref $Table_Projects
      $Table_Projects:
        Type: QB::Table
        Properties:
          Name: Projects
        Fields:
          $Field_Project_Name:
            Type: QB::Field
            Properties:
              Label: Project Name
              FieldType: text
"""

SAMPLE_TARGET_QBL = """\
Version: '0.12'
ParameterDefinitions:
  $Param_App_Name:
    Value: Target App
  $Param_App_AppColor:
    Value: '#ff0000'
  $Param_App_AppIcon:
    Value: Globe
Resources:
  $App_Target_App:
    Type: QB::Application
    Properties:
      Name: Target App
      AppColor: '#ff0000'
      AppIcon: Globe
      Manager: other@example.com
    Tables:
      $Table_Old_Table:
        Type: QB::Table
        Properties:
          Name: Old Table
"""

SAMPLE_QBL_NO_MANAGER = """\
Version: '0.12'
ParameterDefinitions:
  $Param_App_Name:
    Value: My Test App
  $Param_App_AppColor:
    Value: '#1a73e8'
  $Param_App_AppIcon:
    Value: Briefcase
Resources:
  $App_My_Test_App:
    Type: QB::Application
    Properties:
      Name: My Test App
      AppColor: '#1a73e8'
      AppIcon: Briefcase
    Tables:
      $Table_Tasks:
        Type: QB::Table
        Properties:
          Name: Tasks
"""


# ── parse_qbl / serialize_qbl ────────────────────────────────────────


class TestParseAndSerialize:
    """Tests for QBL round-tripping."""

    def test_parse_returns_dict_like(self):
        data = parse_qbl(SAMPLE_QBL)
        assert "Version" in data
        assert "Resources" in data
        assert "ParameterDefinitions" in data

    def test_round_trip_preserves_structure(self):
        data = parse_qbl(SAMPLE_QBL)
        result = serialize_qbl(data)
        reparsed = parse_qbl(result)
        assert reparsed["Version"] == "0.12"
        assert "ParameterDefinitions" in reparsed
        assert "Resources" in reparsed

    def test_round_trip_preserves_ref_tags(self):
        data = parse_qbl(SAMPLE_QBL)
        result = serialize_qbl(data)
        assert "!Ref" in result

    def test_round_trip_preserves_bad_ref_tags(self):
        data = parse_qbl(SAMPLE_QBL)
        result = serialize_qbl(data)
        assert "!BadRef" in result

    def test_parse_nested_tables(self):
        data = parse_qbl(SAMPLE_QBL)
        app_key = list(data["Resources"].keys())[0]
        tables = data["Resources"][app_key]["Tables"]
        assert "$Table_Tasks" in tables
        assert "$Table_Projects" in tables


# ── collect_bad_refs ─────────────────────────────────────────────────


class TestCollectBadRefs:
    """Tests for !BadRef collection."""

    def test_finds_bad_refs(self):
        data = parse_qbl(SAMPLE_QBL)
        bad_refs = collect_bad_refs(data)
        assert len(bad_refs) > 0

    def test_bad_ref_includes_path(self):
        data = parse_qbl(SAMPLE_QBL)
        bad_refs = collect_bad_refs(data)
        paths = [path for path, _ in bad_refs]
        assert any("LookupRef" in p for p in paths)

    def test_bad_ref_includes_value(self):
        data = parse_qbl(SAMPLE_QBL)
        bad_refs = collect_bad_refs(data)
        values = [value for _, value in bad_refs]
        assert any("Deleted_User" in v for v in values)

    def test_no_bad_refs_in_clean_qbl(self):
        qbl = """\
Version: '0.12'
ParameterDefinitions:
  $Param_App_Name:
    Value: Clean App
Resources:
  $App_Clean_App:
    Type: QB::Application
    Properties:
      AppColor: '#000000'
"""
        data = parse_qbl(qbl)
        bad_refs = collect_bad_refs(data)
        assert len(bad_refs) == 0

    def test_does_not_flag_good_refs(self):
        data = parse_qbl(SAMPLE_QBL)
        bad_refs = collect_bad_refs(data)
        values = [value for _, value in bad_refs]
        assert not any("Table_Projects" in v for v in values)


# ── merge_qbl_for_update ──────────────────────────────────────────────


class TestMergeQBLForUpdate:
    """Tests for QBL merging for environment updates."""

    def test_preserves_target_logical_id(self):
        """Verify merged QBL uses target's logical ID, not source's."""
        merged, _ = merge_qbl_for_update(SAMPLE_QBL, SAMPLE_TARGET_QBL)
        assert "$App_Target_App" in merged
        assert "$App_My_Test_App" not in merged

    def test_preserves_target_parameter_definitions(self):
        """Verify target's ParameterDefinitions are restored in merged QBL."""
        merged, _ = merge_qbl_for_update(SAMPLE_QBL, SAMPLE_TARGET_QBL)
        data = parse_qbl(merged)
        assert "ParameterDefinitions" in data
        assert "$Param_App_Name" in data["ParameterDefinitions"]
        assert "$Param_App_AppColor" in data["ParameterDefinitions"]

    def test_uses_source_schema_resources(self):
        """Verify source schema (tables, fields) is used in merged QBL."""
        merged, _ = merge_qbl_for_update(SAMPLE_QBL, SAMPLE_TARGET_QBL)
        data = parse_qbl(merged)
        app_key = "$App_Target_App"  # target's ID
        tables = data["Resources"][app_key]["Tables"]
        # Should have source's tables, not target's
        assert "$Table_Tasks" in tables
        assert "$Table_Projects" in tables
        assert "$Table_Old_Table" not in tables

    def test_removes_manager_field(self):
        """Verify Manager field is stripped from the merged QBL."""
        merged, diagnostics = merge_qbl_for_update(SAMPLE_QBL, SAMPLE_TARGET_QBL)
        data = parse_qbl(merged)
        app_key = "$App_Target_App"
        props = data["Resources"][app_key]["Properties"]
        assert "Manager" not in props
        assert diagnostics.manager_removed is not None

    def test_reports_stripped_manager(self):
        """Verify diagnostics captures the removed Manager value."""
        _, diagnostics = merge_qbl_for_update(SAMPLE_QBL, SAMPLE_TARGET_QBL)
        assert diagnostics.manager_removed == "owner@example.com"

    def test_no_manager_in_source(self):
        """Verify handling when source has no Manager."""
        _, diagnostics = merge_qbl_for_update(SAMPLE_QBL_NO_MANAGER, SAMPLE_TARGET_QBL)
        assert diagnostics.manager_removed is None

    def test_collects_bad_refs_from_source(self):
        """Verify bad refs from source schema are collected."""
        _, diagnostics = merge_qbl_for_update(SAMPLE_QBL, SAMPLE_TARGET_QBL)
        assert diagnostics.has_bad_refs
        assert len(diagnostics.bad_refs) > 0

    def test_preserves_ref_tags(self):
        """Verify !Ref tags are preserved in merged QBL."""
        merged, _ = merge_qbl_for_update(SAMPLE_QBL, SAMPLE_TARGET_QBL)
        assert "!Ref" in merged

    def test_preserves_bad_ref_tags(self):
        """Verify !BadRef tags are preserved in merged QBL."""
        merged, _ = merge_qbl_for_update(SAMPLE_QBL, SAMPLE_TARGET_QBL)
        assert "!BadRef" in merged

    def test_returns_diagnostics(self):
        """Verify diagnostics object is returned."""
        merged, diagnostics = merge_qbl_for_update(SAMPLE_QBL, SAMPLE_TARGET_QBL)
        assert isinstance(diagnostics, QBLDiagnostics)

    def test_same_logical_ids_no_warning(self):
        """Verify no warning when source and target have same logical ID."""
        qbl_same_id = SAMPLE_QBL.replace("$App_My_Test_App", "$App_Target_App")
        _, diagnostics = merge_qbl_for_update(qbl_same_id, SAMPLE_TARGET_QBL)
        # Should not warn about logical ID mismatch
        assert not any("Renamed" in w for w in diagnostics.warnings)

    def test_missing_target_app_resource_warns(self):
        """Verify warning when target has no QB::Application resource."""
        qbl_no_app = """\
Version: '0.12'
ParameterDefinitions:
  $Param_Test:
    Value: test
Resources:
  $Table_Only:
    Type: QB::Table
    Properties:
      Name: Some Table
"""
        _, diagnostics = merge_qbl_for_update(SAMPLE_QBL, qbl_no_app)
        assert any("QB::Application" in w for w in diagnostics.warnings)

    def test_missing_source_app_resource_warns(self):
        """Verify warning when source has no QB::Application resource."""
        qbl_no_app = """\
Version: '0.12'
ParameterDefinitions:
  $Param_Test:
    Value: test
Resources:
  $Table_Only:
    Type: QB::Table
    Properties:
      Name: Some Table
"""
        _, diagnostics = merge_qbl_for_update(qbl_no_app, SAMPLE_TARGET_QBL)
        assert any("QB::Application" in w for w in diagnostics.warnings)

    def test_no_target_parameter_definitions(self):
        """Verify handling when target has no ParameterDefinitions."""
        qbl_no_params = """\
Version: '0.12'
Resources:
  $App_Target_App:
    Type: QB::Application
    Properties:
      Name: Target App
"""
        merged, _ = merge_qbl_for_update(SAMPLE_QBL, qbl_no_params)
        data = parse_qbl(merged)
        # Source's ParameterDefinitions should still be there (merged data uses source)
        assert "ParameterDefinitions" in data

    def test_merged_qbl_is_valid_yaml(self):
        """Verify merged QBL can be re-parsed."""
        merged, _ = merge_qbl_for_update(SAMPLE_QBL, SAMPLE_TARGET_QBL)
        reparsed = parse_qbl(merged)
        assert "Version" in reparsed
        assert "Resources" in reparsed
        assert "ParameterDefinitions" in reparsed

    def test_diagnostics_summary(self):
        """Verify diagnostics can be summarized."""
        _, diagnostics = merge_qbl_for_update(SAMPLE_QBL, SAMPLE_TARGET_QBL)
        summary = diagnostics.summary()
        assert isinstance(summary, str)
        assert len(summary) > 0


# ── QBLDiagnostics ───────────────────────────────────────────────────


class TestQBLDiagnostics:
    """Tests for the diagnostics dataclass."""

    def test_empty_diagnostics(self):
        diag = QBLDiagnostics()
        assert not diag.has_bad_refs
        assert diag.manager_removed is None
        assert diag.summary() == "No issues found."

    def test_has_bad_refs(self):
        diag = QBLDiagnostics(bad_refs=[("path.to.field", "$Field_Deleted")])
        assert diag.has_bad_refs

    def test_summary_includes_manager(self):
        diag = QBLDiagnostics(manager_removed="owner@example.com")
        assert "owner@example.com" in diag.summary()

    def test_summary_includes_bad_refs(self):
        diag = QBLDiagnostics(bad_refs=[("path.to.field", "$Field_Deleted")])
        summary = diag.summary()
        assert "BadRef" in summary
        assert "path.to.field" in summary

    def test_summary_includes_warnings(self):
        diag = QBLDiagnostics(warnings=["Something went wrong"])
        assert "Something went wrong" in diag.summary()
