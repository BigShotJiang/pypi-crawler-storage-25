"""Tests for LegacyMethod HTTP client."""

REALM = "testrealm.quickbase.com"


class TestLegacyMethodPost:
    def test_post_success(self, mock_api, legacy):
        url = f"https://{REALM}/db/tbl1"
        mock_api.post(url, json={"errcode": 0}, status=200)

        body, status = legacy.post(url, params={"a": "API_SetKeyField"})
        assert status == 200
        assert body["errcode"] == 0

    def test_post_passes_params(self, mock_api, legacy):
        url = f"https://{REALM}/db/tbl1"
        mock_api.post(url, json={"errcode": 0}, status=200)

        legacy.post(url, params={"a": "API_SetKeyField"})
        assert mock_api.calls[0].request.params["a"] == "API_SetKeyField"

    def test_post_with_xml_body(self, mock_api, legacy):
        url = f"https://{REALM}/db/tbl1"
        mock_api.post(
            url,
            body="<?xml version='1.0'?><qdbapi><errcode>0</errcode></qdbapi>",
            status=200,
            content_type="application/xml",
        )
        body, status = legacy.post(
            url,
            params={"a": "API_SetKeyField"},
            data={"fid": "6"},
        )
        assert status == 200
        request_body = mock_api.calls[0].request.body
        assert "<fid>6</fid>" in request_body

    def test_post_xml_body_sets_content_type(self, mock_api, legacy):
        url = f"https://{REALM}/db/tbl1"
        mock_api.post(url, json={"errcode": 0}, status=200)

        legacy.post(url, params={"a": "API_SetKeyField"}, data={"fid": "6"})
        content_type = mock_api.calls[0].request.headers.get("Content-Type")
        assert "xml" in content_type

    def test_post_without_data_no_xml_header(self, mock_api, legacy):
        url = f"https://{REALM}/db/tbl1"
        mock_api.post(url, json={"errcode": 0}, status=200)

        legacy.post(url, params={"a": "API_SetKeyField"})
        content_type = mock_api.calls[0].request.headers.get("Content-Type")
        assert content_type is None or "xml" not in content_type


class TestLegacyMethodGet:
    def test_get_success(self, mock_api, legacy):
        url = f"https://{REALM}/db/main"
        mock_api.get(url, json={"data": "test"}, status=200)

        body, status = legacy.get(url)
        assert status == 200
        assert body["data"] == "test"


class TestLegacyMethodHeaders:
    def test_session_has_auth_headers(self, legacy):
        assert legacy.session.headers["QB-Realm-Hostname"] == REALM
        assert legacy.session.headers["Authorization"] == "QB-USER-TOKEN test-token-123"


class TestLegacyMethodErrorHandling:
    def test_non_json_response(self, mock_api, legacy):
        url = f"https://{REALM}/db/tbl1"
        mock_api.post(
            url,
            body="<?xml version='1.0'?><error>Something broke</error>",
            status=500,
            content_type="text/xml",
        )
        body, status = legacy.post(url)
        assert status == 500


class TestBuildQdbapi:
    def test_builds_basic_xml(self, legacy):
        xml = legacy._build_qdbapi({"fid": "6"})
        assert "<fid>6</fid>" in xml
        assert "<qdbapi>" in xml

    def test_builds_multiple_params(self, legacy):
        xml = legacy._build_qdbapi({"userid": "123", "roleid": "12"})
        assert "<userid>123</userid>" in xml
        assert "<roleid>12</roleid>" in xml

    def test_wraps_in_qdbapi(self, legacy):
        xml = legacy._build_qdbapi({"fid": "6"})
        assert xml.strip().startswith("<?xml")
        assert "<qdbapi>" in xml
        assert "</qdbapi>" in xml
