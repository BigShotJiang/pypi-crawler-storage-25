"""Table-related API methods."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from quickbase_api.exceptions import QuickbaseNotFoundError

if TYPE_CHECKING:
    from quickbase_api.client import QuickbaseClient

logger = logging.getLogger(__name__)


class TablesMixin:
    """Table-related methods for the Quickbase client."""

    # ── API Methods ───────────────────────────────────────────────────

    def create_table(
        self: QuickbaseClient,
        app_id: str,
        *,
        name: str,
        description: str = None,
        single_record_name: str = None,
        plural_record_name: str = None,
        icon_name: str = None,
        color: str = None,
    ) -> dict:
        """Create a new table in a Quickbase app.

        Args:
            app_id: The ID of the app to create the table in.
            properties: A dictionary of table properties (must include 'name').

        Returns:
            The table ID of the newly created table.

        Raises:
            QuickbaseAPIError: If the API request fails.
        """
        body = {"name": name}
        if description is not None:
            body["description"] = description
        if single_record_name is not None:
            body["singleRecordName"] = single_record_name
        if plural_record_name is not None:
            body["pluralRecordName"] = plural_record_name
        if icon_name is not None:
            body["iconName"] = icon_name
        if color is not None:
            body["color"] = color

        resp_json, resp_code = self._rm.post(
            "tables",
            params={"appId": app_id},
            data=body,
        )
        self._require_success(resp_json, resp_code, f"create table in app '{app_id}'")
        logger.info("Created table '%s' with ID: %s", resp_json["name"], resp_json["id"])
        return resp_json

    def get_tables(
        self: QuickbaseClient,
        app_id: str,
    ) -> list[dict]:
        """Get all tables for a Quickbase app.

        Args:
            app_id: The ID of the app.

        Returns:
            A list of table metadata dictionaries.

        Raises:
            QuickbaseAPIError: If the API request fails.
        """
        resp_json, resp_code = self._rm.get("tables", params={"appId": app_id})
        self._require_success(resp_json, resp_code, f"get tables for app '{app_id}'")
        return resp_json

    def delete_table(
        self: QuickbaseClient,
        app_id: str,
        *,
        table_id: str,
    ) -> dict:
        """Get all tables for a Quickbase app.

        Args:
            app_id: The ID of the app.

        Returns:
            A list of table metadata dictionaries.

        Raises:
            QuickbaseAPIError: If the API request fails.
        """
        resp_json, resp_code = self._rm.delete(
            f"tables/{table_id}",
            params={"appId": app_id},
        )
        self._require_success(resp_json, resp_code, f"delete table '{table_id}'")
        logger.info("Deleted table %s from app %s", table_id, app_id)
        return resp_json

    # ── Helpers ───────────────────────────────────────────────────────

    def get_table_id(
        self: QuickbaseClient,
        app_id: str,
        *,
        table_name: str,
    ) -> str:
        """Find a table ID by its name.

        Args:
            app_id: The ID of the app containing the table.
            table_name: The exact name of the table to find.

        Returns:
            The table ID.

        Raises:
            QuickbaseNotFoundError: If no table with the given name is found.
        """
        tables = self.get_tables(app_id)
        for table in tables:
            if table["name"] == table_name:
                return table["id"]
        raise QuickbaseNotFoundError(f"No table named '{table_name}' in app '{app_id}'")
