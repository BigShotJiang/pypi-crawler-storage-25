"""Field-related API methods."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from quickbase_api.exceptions import QuickbaseAPIError, QuickbaseNotFoundError

if TYPE_CHECKING:
    from quickbase_api.client import QuickbaseClient

logger = logging.getLogger(__name__)


class FieldsMixin:
    """Field-related methods for the Quickbase client."""

    # ── API Methods ───────────────────────────────────────────────────

    def create_field(
        self: QuickbaseClient,
        table_id: str,
        *,
        label: str,
        field_type: str,
        description: str = None,
        no_wrap: bool = None,
        bold: bool = None,
        required: bool = None,
        appears_by_default: bool = None,
        find_enabled: bool = None,
        unique: bool = None,
        field_help: str = None,
        add_to_forms: bool = None,
        type_properties: dict = None,
        permissions: list[dict] = None,
    ) -> dict:
        """Create a new field in a table.

        Args:
            table_id: The ID of the table.
            properties: Field properties (must include 'label' and 'fieldType').

        Returns:
            The API response body with the created field's metadata.

        Raises:
            QuickbaseAPIError: If the API request fails.
        """
        body = {
            "label": label,
            "fieldType": field_type,
        }
        if description is not None:
            body["description"] = description
        if no_wrap is not None:
            body["noWrap"] = no_wrap
        if bold is not None:
            body["bold"] = bold
        if required is not None:
            body["required"] = required
        if appears_by_default is not None:
            body["appearsByDefault"] = appears_by_default
        if find_enabled is not None:
            body["findEnabled"] = find_enabled
        if unique is not None:
            body["unique"] = unique
        if field_help is not None:
            body["fieldHelp"] = field_help
        if add_to_forms is not None:
            body["addToForms"] = add_to_forms
        if type_properties is not None:
            body["properties"] = type_properties
        if permissions is not None:
            body["permissions"] = permissions

        resp_json, resp_code = self._rm.post(
            "fields",
            params={"tableId": table_id},
            data=body,
        )
        self._require_success(resp_json, resp_code, f"create field in table '{table_id}'")
        logger.info(
            "Created field '%s' (ID: %s) in table %s",
            resp_json["label"],
            resp_json["id"],
            table_id,
        )
        return resp_json

    def get_table_fields(
        self: QuickbaseClient,
        table_id: str,
    ) -> list[dict]:
        """Get all fields for a table.

        Args:
            table_id: The ID of the table.

        Returns:
            A list of field metadata dictionaries.

        Raises:
            QuickbaseAPIError: If the API request fails.
        """
        resp_json, resp_code = self._rm.get("fields", params={"tableId": table_id})
        self._require_success(resp_json, resp_code, f"get fields for table '{table_id}'")
        return resp_json

    def set_key_field(
        self: QuickbaseClient,
        table_id: str,
        *,
        field_id: str,
    ) -> dict:
        """Set the key field for a table using the legacy API.

        Args:
            table_id: The ID of the table.
            field_id: The ID of the field to set as the key field.

        Returns:
            True if the key field was set successfully.

        Raises:
            QuickbaseAPIError: If the API request fails.
        """
        resp_json, resp_code = self._lm.post(
            self._legacy_url(table_id),
            params={"a": "API_SetKeyField"},
            data={"fid": field_id},
        )
        self._require_legacy_success(resp_json, resp_code, f"set key field '{field_id}' on table '{table_id}'")
        logger.info("Set key field to %s for table %s", field_id, table_id)
        return resp_json

    def set_required_field(
        self: QuickbaseClient,
        table_id: str,
        *,
        field_id: str,
    ) -> dict:
        """Mark a field as required.

        Args:
            table_id: The ID of the table.
            field_id: The ID of the field to mark as required.

        Returns:
            True if the field was successfully marked as required.

        Raises:
            QuickbaseAPIError: If the API request fails.
        """
        resp_json, resp_code = self._rm.post(
            f"fields/{field_id}",
            params={"tableId": table_id},
            data={"required": True},
        )
        self._require_success(resp_json, resp_code, f"set field '{field_id}' as required")
        return resp_json

    # ── Helpers ───────────────────────────────────────────────────────

    def create_fields(
        self: QuickbaseClient,
        table_id: str,
        *,
        fields: list[dict],
    ) -> dict:
        """Create multiple fields in a table.

        Args:
            table_id: The ID of the table.
            fields: A list of field property dictionaries.

        Returns:
            A dict with 'succeeded' and 'failed' lists.
        """
        results = {"succeeded": [], "failed": []}
        for field in fields:
            try:
                created = self.create_field(table_id, **field)
                results["succeeded"].append(created)
            except QuickbaseAPIError as e:
                logger.warning("Failed to create field %s: %s", field, e)
                results["failed"].append({"field": field, "error": str(e)})

        logger.info(
            "%d of %d fields created for table %s",
            len(results["succeeded"]),
            len(fields),
            table_id,
        )
        return results

    def get_field_id(
        self: QuickbaseClient,
        table_id: str,
        *,
        field_label: str,
    ) -> str:
        """Find a field ID by its label.

        Args:
            table_id: The ID of the table.
            field_label: The exact label of the field to find.

        Returns:
            The field ID as a string.

        Raises:
            QuickbaseNotFoundError: If no field with the given label is found.
        """
        fields = self.get_table_fields(table_id)
        for field in fields:
            if field["label"] == field_label:
                return str(field["id"])
        raise QuickbaseNotFoundError(f"No field labeled '{field_label}' in table '{table_id}'")

    def get_field_label_id_map(
        self: QuickbaseClient,
        table_id: str,
    ) -> dict[str, str]:
        """Build a mapping of field labels to field IDs.

        Args:
            table_id: The ID of the table.

        Returns:
            A dict mapping field label strings to field ID strings.
        """
        fields = self.get_table_fields(table_id)
        return {f["label"]: str(f["id"]) for f in fields}

    def get_key_field_id(
        self: QuickbaseClient,
        app_id: str,
        *,
        table_id: str,
    ) -> str:
        """Get the key field ID for a table.

        Args:
            app_id: The ID of the app.
            table_id: The ID of the table.

        Returns:
            The key field ID as a string.

        Raises:
            QuickbaseAPIError: If the API request fails.
        """
        resp_json, resp_code = self._rm.get(
            f"tables/{table_id}",
            params={"appId": app_id},
        )
        self._require_success(resp_json, resp_code, f"get key field for table '{table_id}'")
        return str(resp_json["keyFieldId"])
