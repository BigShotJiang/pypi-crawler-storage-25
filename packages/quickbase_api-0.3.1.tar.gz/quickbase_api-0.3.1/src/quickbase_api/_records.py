"""Record-related API methods."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from quickbase_api.exceptions import QuickbaseAPIError

if TYPE_CHECKING:
    from quickbase_api.client import QuickbaseClient

logger = logging.getLogger(__name__)


class RecordsMixin:
    """Record-related methods for the Quickbase client."""

    # ── API Methods ───────────────────────────────────────────────────

    def upsert_records(
        self: QuickbaseClient,
        table_id: str,
        *,
        data: list[dict],
    ) -> dict:
        """Insert or update records in a table.

        Args:
            table_id: The ID of the table.
            data: A list of record dictionaries, keyed by field ID::

                [
                    {
                        "6": {"value": "Some text"},
                        "7": {"value": 42},
                        "8": {"value": "2024-01-15T08:00:00Z"},
                    }
                ]

        Returns:
            A dict with keys: processed, created, updated, unchanged,
            errored, errored_details.

        Raises:
            QuickbaseAPIError: If the API request fails entirely (4xx/5xx).
        """
        resp_json, resp_code = self._rm.post(
            "records",
            data={"to": table_id, "data": data},
        )
        if resp_code not in (200, 207):
            raise QuickbaseAPIError(resp_code, resp_json)

        line_errors = resp_json.get("metadata", {}).get("lineErrors", {})
        if line_errors:
            logger.warning(
                "Upsert to table %s had %d line errors: %s",
                table_id,
                len(line_errors),
                line_errors,
            )

        return resp_json

    def delete_records(
        self: QuickbaseClient,
        table_id: str,
        *,
        where: str,
    ) -> dict:
        """Delete records from a table.

        Args:
            table_id: The ID of the table.
            where: A Quickbase query string (e.g., "{6.EX.'123'}").

        Returns:
            The number of records deleted.

        Raises:
            QuickbaseAPIError: If the API request fails.
        """
        resp_json, resp_code = self._rm.delete(
            "records",
            data={"from": table_id, "where": where},
        )
        self._require_success(resp_json, resp_code, f"delete records from table '{table_id}'")
        logger.info("Deleted %d records from table %s", resp_json["numberDeleted"], table_id)
        return resp_json

    def query_for_data(
        self: QuickbaseClient,
        table_id: str,
        *,
        select: list[int] = None,
        where: str = None,
        sort_by: list[dict] = None,
        group_by: list[dict] = None,
        options: dict = None,
    ) -> dict:
        """Query for record data from a table.

        Args:
            table_id: The ID of the table to query.
            select: List of field IDs to return. If omitted, returns
                fields from the default report.
            where: A Quickbase query string (e.g., "{12.EX.'VPF'}").
            sort_by: Sort order, e.g., [{"fieldId": 6, "order": "ASC"}].
            group_by: Grouping, e.g., [{"fieldId": 6, "grouping": "equal-values"}].
            options: Additional options, e.g.,
                {"skip": 0, "top": 100, "compareWithAppLocalTime": False}.

        Returns:
            The query response including data and metadata.

        Raises:
            QuickbaseAPIError: If the API request fails.
        """
        body = {"from": table_id}
        if select is not None:
            body["select"] = select
        if where is not None:
            body["where"] = where
        if sort_by is not None:
            body["sortBy"] = sort_by
        if group_by is not None:
            body["groupBy"] = group_by
        if options is not None:
            body["options"] = options

        resp_json, resp_code = self._rm.post("records/query", data=body)
        self._require_success(resp_json, resp_code, f"query table '{table_id}'")
        return resp_json

    # ── Helpers ───────────────────────────────────────────────────────

    def summarize_upsert(self, resp_json: dict) -> dict:
        """Build a summary dict from an upsert response.

        Args:
            resp_json: The full response from upsert_records.

        Returns:
            A dict with keys: processed, created, updated, unchanged,
            errored, errored_details.
        """
        metadata = resp_json["metadata"]
        line_errors = metadata.get("lineErrors", {})

        return {
            "processed": metadata["totalNumberOfRecordsProcessed"] - len(line_errors),
            "created": len(metadata["createdRecordIds"]),
            "updated": len(metadata["updatedRecordIds"]),
            "unchanged": len(metadata["unchangedRecordIds"]),
            "errored": len(line_errors),
            "errored_details": line_errors,
        }
