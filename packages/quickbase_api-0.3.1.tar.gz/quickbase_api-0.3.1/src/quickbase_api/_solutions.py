"""Solution-related API methods."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from quickbase_api.qbl import QBLDiagnostics, merge_qbl_for_update

if TYPE_CHECKING:
    from quickbase_api.client import QuickbaseClient

logger = logging.getLogger(__name__)


class SolutionsMixin:
    """Solution-related methods for the Quickbase client."""

    # ── API Methods ───────────────────────────────────────────────────

    def export_solution(
        self: QuickbaseClient,
        solution_id: str,
    ) -> str:
        result, resp_code = self._rm.make_request("GET", f"solutions/{solution_id}")
        self._require_success(result, resp_code, f"export solution '{solution_id}'")
        logger.info("Exported solution '%s'", solution_id)
        return result

    def create_solution(
        self: QuickbaseClient,
        qbl: str,
    ) -> dict:
        result, resp_code = self._rm.make_request("POST", "solutions", body=qbl)
        self._require_success(result, resp_code, "create solution")
        logger.info("Created solution from QBL")
        return result

    def update_solution(
        self: QuickbaseClient,
        solution_id: str,
        *,
        qbl: str,
    ) -> dict:
        result, resp_code = self._rm.make_request("PUT", f"solutions/{solution_id}", body=qbl)
        self._require_success(result, resp_code, f"update solution '{solution_id}'")
        logger.info("Updated solution '%s'", solution_id)
        return result

    def list_solution_changes(
        self: QuickbaseClient,
        solution_id: str,
        *,
        qbl: str,
    ) -> dict:
        result, resp_code = self._rm.make_request("PUT", f"solutions/{solution_id}/changeset", body=qbl)
        self._require_success(result, resp_code, f"list changes for solution '{solution_id}'")
        logger.info("Retrieved changeset for solution '%s'", solution_id)
        return result

    def get_solution(
        self: QuickbaseClient,
        solution_id: str,
    ) -> dict:
        resp_json, resp_code = self._rm.get(f"solutions/{solution_id}/resources")
        self._require_success(resp_json, resp_code, f"get solution '{solution_id}'")
        return resp_json

    # ── Helpers ───────────────────────────────────────────────────────

    def push_solution(
        self: QuickbaseClient,
        source_solution_id: str,
        target_solution_id: str,
        *,
        preview_only: bool = False,
    ) -> dict | tuple[dict, QBLDiagnostics]:
        """Push a solution from source to target environment.

        Merges the source QBL schema with target QBL, preserving:
        - Target app's logical ID and identity
        - Target app's ParameterDefinitions

        Removes the Manager field to prevent API errors.

        Args:
            source_solution_id: The source solution ID to push from.
            target_solution_id: The target solution ID to push to.
            preview_only: If True, return a preview of changes without applying them.

        Returns:
            If preview_only: dict of changes
            Otherwise: tuple of (result dict, diagnostics)

        Raises:
            ValueError: If source and target solution IDs are identical.
        """
        if source_solution_id == target_solution_id:
            raise ValueError(
                f"Source and target solution IDs are the same: '{source_solution_id}'. "
                "This would be a no-op at best."
            )

        logger.info(
            "Exporting source solution '%s' and target solution '%s'",
            source_solution_id,
            target_solution_id,
        )
        source_qbl = self.export_solution(source_solution_id)
        target_qbl = self.export_solution(target_solution_id)

        logger.info(
            "Merging source schema into target environment for '%s'",
            target_solution_id,
        )
        merged_qbl, diagnostics = merge_qbl_for_update(source_qbl, target_qbl)

        if diagnostics.warnings:
            logger.warning("Merge warnings:\n%s", diagnostics.summary())

        if preview_only:
            logger.info(
                "Previewing push from '%s' to '%s'",
                source_solution_id,
                target_solution_id,
            )
            return self.list_solution_changes(target_solution_id, qbl=merged_qbl)

        logger.info(
            "Pushing solution '%s' to '%s'",
            source_solution_id,
            target_solution_id,
        )
        result = self.update_solution(target_solution_id, qbl=merged_qbl)
        logger.info(
            "Push complete: '%s' → '%s'\n%s",
            source_solution_id,
            target_solution_id,
            diagnostics.summary(),
        )
        return result, diagnostics
