"""Quickbase API client providing high-level methods for apps, tables, fields, and records."""

from __future__ import annotations

import logging

from quickbase_api._apps import AppsMixin
from quickbase_api._fields import FieldsMixin
from quickbase_api._records import RecordsMixin
from quickbase_api._reports import ReportsMixin
from quickbase_api._solutions import SolutionsMixin
from quickbase_api._tables import TablesMixin
from quickbase_api._users_and_roles import UsersAndRolesMixin
from quickbase_api.exceptions import QuickbaseAPIError
from quickbase_api.legacy_method import LegacyMethod
from quickbase_api.rest_method import RestMethod

logger = logging.getLogger(__name__)


class QuickbaseClient(
    AppsMixin,
    TablesMixin,
    FieldsMixin,
    RecordsMixin,
    ReportsMixin,
    UsersAndRolesMixin,
    SolutionsMixin,
):
    """High-level client for interacting with the Quickbase API.

    Args:
        realm: The Quickbase realm hostname (e.g., 'mycompany.quickbase.com').
        user_token: The Quickbase user token for authentication.

    Example::

        from quickbase_api import QuickbaseClient

        client = QuickbaseClient("mycompany.quickbase.com", "my-token")
        app = client.get_app("bqrg4xyza")
    """

    def __init__(self, realm: str, user_token: str):
        self.realm = realm
        self.user_token = user_token
        self._rm = RestMethod(realm, user_token)
        self._lm = LegacyMethod(realm, user_token)

    def _require_success(self, resp_json: dict, resp_code: int, context: str) -> dict:
        """Raise QuickbaseAPIError if the response code indicates failure."""
        if resp_code >= 400:
            raise QuickbaseAPIError(resp_code, resp_json)
        return resp_json

    def _require_legacy_success(self, resp: dict, resp_code: int, context: str) -> dict:
        """Raise QuickbaseAPIError if a legacy API call failed."""
        if resp_code >= 400:
            raise QuickbaseAPIError(resp_code, resp)
        errcode = resp.get("errcode", "0")
        if errcode != "0":
            raise QuickbaseAPIError(
                resp_code,
                {
                    "errcode": errcode,
                    "errtext": resp.get("errtext", "Unknown legacy error"),
                    "context": context,
                    "full_response": resp,
                },
            )
        return resp

    def _legacy_url(self, dbid: str) -> str:
        """Build a legacy API endpoint URL."""
        return f"https://{self.realm}/db/{dbid}"
