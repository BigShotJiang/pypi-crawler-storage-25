"""QBL parsing, modification, and serialization utilities for the Quickbase Solutions API."""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from io import StringIO

from ruamel.yaml import YAML  # type: ignore[import-unresolved]

from quickbase_api.constants import DEFAULT_APP_ICON, KNOWN_APP_ICONS

logger = logging.getLogger(__name__)


@dataclass
class QBLDiagnostics:
    """Collects issues found during QBL parsing and modification.

    Attributes:
        bad_refs: List of (path, value) tuples for every !BadRef found.
        warnings: General warnings encountered during modification.
        manager_removed: The manager value that was stripped, if any.
    """

    bad_refs: list[tuple[str, str]] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    manager_removed: str | None = None

    @property
    def has_bad_refs(self) -> bool:
        return len(self.bad_refs) > 0

    def summary(self) -> str:
        """Return a human-readable summary of diagnostics."""
        lines = []
        if self.manager_removed:
            lines.append(f"Stripped Manager: {self.manager_removed}")
        if self.bad_refs:
            lines.append(f"Found {len(self.bad_refs)} !BadRef entries:")
            for path, value in self.bad_refs:
                lines.append(f"  {path}: {value}")
        if self.warnings:
            lines.append(f"Warnings ({len(self.warnings)}):")
            for w in self.warnings:
                lines.append(f"  {w}")
        return "\n".join(lines) if lines else "No issues found."


def _create_yaml_handler() -> YAML:
    """Create a ruamel.yaml handler configured for QBL round-tripping."""
    handler = YAML()
    handler.preserve_quotes = True
    # Allow arbitrary custom tags (!Ref, !BadRef, etc.) to pass through
    # without raising errors. ruamel.yaml round-trip mode does this by default.
    return handler


def parse_qbl(qbl: str) -> dict:
    """Parse a QBL YAML string into a round-trip-safe data structure.

    The returned object preserves tags, comments, and key ordering
    so it can be modified and re-serialized without losing !Ref entries.

    Args:
        qbl: The raw QBL YAML string.

    Returns:
        A ruamel.yaml CommentedMap (dict-like) preserving all tags.
    """
    handler = _create_yaml_handler()
    return handler.load(qbl)


def serialize_qbl(data) -> str:
    """Serialize a parsed QBL structure back to a YAML string.

    Preserves custom tags (!Ref, !BadRef) and key ordering.

    Args:
        data: The parsed QBL data (from parse_qbl).

    Returns:
        The QBL YAML string, ready to send to the Solutions API.
    """
    handler = _create_yaml_handler()
    stream = StringIO()
    handler.dump(data, stream)
    return stream.getvalue()


def collect_bad_refs(data, path: str = "") -> list[tuple[str, str]]:
    """Walk a parsed QBL structure and collect all !BadRef entries.

    Args:
        data: The parsed QBL data (or a subtree).
        path: The current dot-delimited path (used for recursion).

    Returns:
        A list of (path, value) tuples for each !BadRef found.
    """
    results = []

    # ruamel.yaml tagged scalars have a .tag attribute
    if hasattr(data, "tag") and data.tag is not None:
        tag_str = str(data.tag)
        if "BadRef" in tag_str:
            results.append((path or "(root)", str(data)))

    if isinstance(data, dict):
        for key, value in data.items():
            child_path = f"{path}.{key}" if path else str(key)
            results.extend(collect_bad_refs(value, child_path))
    elif isinstance(data, list):
        for i, item in enumerate(data):
            child_path = f"{path}[{i}]"
            results.extend(collect_bad_refs(item, child_path))

    return results


def _get_app_logical_id(qbl_data: dict) -> str | None:
    """Extract the logical ID key for the QB::Application resource.

    Args:
        qbl_data: Parsed QBL data.

    Returns:
        The logical ID (e.g., '$App_MyApp') or None if not found.
    """
    resources = qbl_data.get("Resources", {})
    for key, resource in resources.items():
        if isinstance(resource, dict) and resource.get("Type") == "QB::Application":
            return str(key)
    return None


def _strip_manager_from_app(qbl_data: dict) -> str | None:
    """Remove the Manager field from the QB::Application resource.

    Args:
        qbl_data: Parsed QBL data (modified in-place).

    Returns:
        The manager value that was removed, if any.
    """
    resources = qbl_data.get("Resources", {})
    for key, resource in resources.items():
        if isinstance(resource, dict) and resource.get("Type") == "QB::Application":
            props = resource.get("Properties", {})
            if "Manager" in props:
                return props.pop("Manager")
    return None


def merge_qbl_for_update(
    source_qbl: str,
    target_qbl: str,
) -> tuple[str, QBLDiagnostics]:
    """Merge source QBL with target QBL for updating target environment.

    Takes the source QBL as the primary schema, but preserves:
      - ParameterDefinitions from the target
      - The app's logical ID (Resources key) from the target
    Removes the Manager field to prevent API errors.

    Args:
        source_qbl: The QBL from the source app (schema to deploy).
        target_qbl: The QBL from the target app (to extract ParameterDefinitions and logical ID).

    Returns:
        A tuple of (merged_qbl_string, diagnostics).
    """
    diagnostics = QBLDiagnostics()

    # Parse both QBL documents
    source_data = parse_qbl(source_qbl)
    target_data = parse_qbl(target_qbl)

    # ── Collect !BadRef entries from source ────────────────────────────
    diagnostics.bad_refs = collect_bad_refs(source_data)
    if diagnostics.bad_refs:
        logger.warning(
            "Source QBL contains %d !BadRef entries. See diagnostics for details.",
            len(diagnostics.bad_refs),
        )

    # ── Extract target ParameterDefinitions ────────────────────────────
    target_parameter_defs = target_data.get("ParameterDefinitions", {})

    # ── Extract target app logical ID ──────────────────────────────────
    target_app_logical_id = _get_app_logical_id(target_data)
    if not target_app_logical_id:
        diagnostics.warnings.append("Could not find QB::Application resource in target QBL.")

    # ── Extract source app logical ID ──────────────────────────────────
    source_app_logical_id = _get_app_logical_id(source_data)
    if not source_app_logical_id:
        diagnostics.warnings.append("Could not find QB::Application resource in source QBL.")

    # ── Use source as base, then update Resources ──────────────────────
    merged_data = source_data

    # If logical IDs differ, rename the app resource in Resources
    if source_app_logical_id and target_app_logical_id and source_app_logical_id != target_app_logical_id:
        resources = merged_data.get("Resources", {})
        if source_app_logical_id in resources:
            # Get the source app resource
            source_app_resource = resources[source_app_logical_id]
            # Remove it from source logical ID
            del resources[source_app_logical_id]
            # Re-add it under target logical ID
            resources[target_app_logical_id] = source_app_resource
            logger.info(
                "Renamed app resource from '%s' to '%s'",
                source_app_logical_id,
                target_app_logical_id,
            )

    # ── Add back target ParameterDefinitions ────────────────────────────
    if target_parameter_defs:
        merged_data["ParameterDefinitions"] = target_parameter_defs
        logger.info("Restored ParameterDefinitions from target QBL")

    # ── Strip Manager field from the app resource ──────────────────────
    manager_removed = _strip_manager_from_app(merged_data)
    if manager_removed:
        diagnostics.manager_removed = manager_removed
        logger.info("Stripped Manager '%s' from merged QBL", manager_removed)

    merged_qbl = serialize_qbl(merged_data)
    return merged_qbl, diagnostics
