"""Report-related API methods."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from quickbase_api.client import QuickbaseClient

logger = logging.getLogger(__name__)


class ReportsMixin:
    """Report-related methods for the Quickbase client."""

    # ── API Methods ───────────────────────────────────────────────────

    def get_reports(
        self: QuickbaseClient,
        table_id: str,
    ) -> list[dict]:
        """Get all reports for a table.

        Args:
            table_id: The ID of the table.

        Returns:
            A list of report metadata dictionaries.

        Raises:
            QuickbaseAPIError: If the API request fails.
        """
        resp_json, resp_code = self._rm.get("reports", params={"tableId": table_id})
        self._require_success(resp_json, resp_code, f"get reports for table '{table_id}'")
        return resp_json

    def get_report(
        self: QuickbaseClient,
        table_id: str,
        *,
        report_id: str,
    ) -> dict:
        """Get metadata for a specific report.

        Args:
            table_id: The ID of the table containing the report.
            report_id: The ID of the report.

        Returns:
            A dictionary of report metadata.

        Raises:
            QuickbaseAPIError: If the API request fails.
        """
        resp_json, resp_code = self._rm.get(
            f"reports/{report_id}",
            params={"tableId": table_id},
        )
        self._require_success(resp_json, resp_code, f"get report '{report_id}'")
        return resp_json

    def run_report(
        self: QuickbaseClient,
        table_id: str,
        *,
        report_id: str,
        skip: int = None,
        top: int = None,
    ) -> dict:
        """Run a report and return its results.

        Args:
            table_id: The ID of the table containing the report.
            report_id: The ID of the report to run.
            skip: Number of records to skip (for pagination).
            top: Maximum number of records to return.

        Returns:
            The report results.

        Raises:
            QuickbaseAPIError: If the API request fails.
        """
        params = {"tableId": table_id}
        if skip is not None:
            params["skip"] = skip
        if top is not None:
            params["top"] = top

        resp_json, resp_code = self._rm.post(
            f"reports/{report_id}/run",
            params=params,
        )
        self._require_success(resp_json, resp_code, f"run report '{report_id}'")
        return resp_json
