"""App-related API methods."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from quickbase_api.client import QuickbaseClient

logger = logging.getLogger(__name__)


class AppsMixin:
    """App-related methods for the Quickbase client."""

    # ── API Methods ───────────────────────────────────────────────────

    def create_app(
        self: QuickbaseClient,
        name: str,
        *,
        description: str = None,
        assign_token: bool = None,
    ) -> dict:
        """Create a new Quickbase app.

        Args:
            name: The name for the new app.
            description: Optional description for the app.
            assign_token: If True, assigns the user token to the new app.

        Returns:
            The app ID of the newly created app.

        Raises:
            QuickbaseAPIError: If the API request fails.
        """
        body = {"name": name}
        if description is not None:
            body["description"] = description
        if assign_token is not None:
            body["assignToken"] = assign_token

        resp_json, resp_code = self._rm.post("apps", data=body)
        self._require_success(resp_json, resp_code, f"create app '{name}'")
        logger.info("Created app '%s' with ID: %s", resp_json["name"], resp_json["id"])
        return resp_json

    def delete_app(
        self: QuickbaseClient,
        app_id: str,
        *,
        app_name: str,
    ) -> dict:
        """Delete a Quickbase app.

        Args:
            app_name: The name of the app (required for confirmation).
            app_id: The ID of the app to delete.

        Returns:
            The API response body.

        Raises:
            QuickbaseAPIError: If the API request fails.
        """
        resp_json, resp_code = self._rm.delete(
            f"apps/{app_id}",
            data={"name": app_name},
        )
        self._require_success(resp_json, resp_code, f"delete app '{app_name}'")
        logger.info("Deleted app '%s' (%s)", app_name, app_id)
        return resp_json

    def get_app(
        self: QuickbaseClient,
        app_id: str,
    ) -> dict:
        """Get metadata for a Quickbase app.

        Args:
            app_id: The ID of the app.

        Returns:
            A dictionary of app metadata.

        Raises:
            QuickbaseAPIError: If the API request fails.
        """
        resp_json, resp_code = self._rm.get(f"apps/{app_id}")
        self._require_success(resp_json, resp_code, f"get app '{app_id}'")
        return resp_json

    def copy_app(
        self: QuickbaseClient,
        app_id: str,
        *,
        name: str = None,
        description: str = None,
        keep_data: bool = None,
        exclude_files: bool = None,
        users_and_roles: bool = None,
        assign_user_token: bool = None,
    ) -> dict:
        """Copy an existing Quickbase app.

        Args:
            app_id: The ID of the app to copy.
            name: The name for the copied app. Defaults to "Copy of <original app name>".
            description: The description for the copied app. Defaults to the
                original app's description.
            keep_data: If True, copies the data from the original app.
            exclude_files: If True, excludes file attachments from the copy.
            users_and_roles: If True, copies users and roles from the original app.
            assign_user_token: If True, assigns the user token to the copied app.

        Returns:
            A dictionary of the copied app's metadata.

        Raises:
            QuickbaseAPIError: If the API request fails.
        """
        if name is None or description is None:
            original_app = self.get_app(app_id)
            if name is None:
                name = f"Copy of {original_app['name']}"
            if description is None:
                description = original_app.get("description", "")

        body = {"name": name, "description": description}

        properties = {}
        if keep_data is not None:
            properties["keepData"] = keep_data
        if exclude_files is not None:
            properties["excludeFiles"] = exclude_files
        if users_and_roles is not None:
            properties["usersAndRoles"] = users_and_roles
        if assign_user_token is not None:
            properties["assignUserToken"] = assign_user_token
        if properties:
            body["properties"] = properties

        resp_json, resp_code = self._rm.post(f"apps/{app_id}/copy", data=body)
        self._require_success(resp_json, resp_code, f"copy app '{app_id}'")
        logger.info(
            "Copied app '%s' to new app '%s' with ID: %s",
            app_id,
            resp_json["name"],
            resp_json["id"],
        )
        return resp_json
