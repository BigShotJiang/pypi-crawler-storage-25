# TODO

## Ideas / Improvements
- [ ] GitHub Actions — automatically run tests on every push and publish on new releases
- [ ] Pagination helpers — auto-paginate through large query results
- [ ] Async support — aiohttp version for async applications
- [ ] File attachments — upload/download support
- [ ] Rate limit handling — detect 429 responses and wait automatically at the client level
- [ ] More test coverage — edge cases, integration tests against a sandbox app
