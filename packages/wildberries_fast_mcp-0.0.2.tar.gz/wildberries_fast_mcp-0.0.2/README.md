# wildberries-fast-mcp

> A Python wrapper around [FastMCP](https://gofastmcp.com/integrations/openapi) that exposes the full Wildberries API as an MCP server.

---

## What is this?

**wildberries-fast-mcp** lets any MCP-compatible client (Claude Desktop, Cursor, Cline, etc.) interact with the Wildberries API directly — search products, manage shipments, analyze statistics, and more — without writing a single line of integration code.

---

## Features

- Full coverage of the Wildberries public API
- Easy setup with minimal configuration
- Built on [FastMCP](https://gofastmcp.com/integrations/openapi) — a fast Python framework for MCP servers

---

## Installation

```bash
pip install wildberries-fast-mcp
```

Or with `uv`:

```bash
uv add wildberries-fast-mcp
```

---

## Quick Start


### Connect to Claude Desktop

Add this to your `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "wildberries-content": {
      "command": "python",
      "args": ["-m", "wbmcp", "--scope", "content", "--token", "YOU_WB_API_TOKEN"]
    }
  }
}
```

## Available Tools

The server provides tools grouped by WB API section:

| Section                  | Description                                     |
|--------------------------|-------------------------------------------------|
| **Content**              | Product cards, categories, attributes           |
| **Marketplace**          | Warehouses, tariffs, commissions                |
| **Statistics**           | Sales, orders, stock levels, funnel             |
| **Prices & Discounts**   | Price management, promotions                    |
| **Shipments**            | Create and manage supplies, stickers            |
| **Analytics**            | Paid storage reports, paid acceptance           |
| **Reviews & Questions**  | Manage customer reviews and Q&A                 |

---


## License

MIT