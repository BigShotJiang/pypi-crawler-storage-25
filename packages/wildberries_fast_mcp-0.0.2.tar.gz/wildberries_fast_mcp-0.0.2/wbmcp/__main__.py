import dataclasses
import httpx
from fastmcp import FastMCP
import argparse

from .load import load_http

# WB specs shared on github pages after WB blocked automatic downloads from https://dev.wildberries.ru
OPENAPI_DOWNLOAD_URI: str = "https://bigancientmammoth.github.io/wb-swagger/original"

@dataclasses.dataclass
class Scope:
    uri: str         # WB API uri
    spec_file: str   # Open API spec


SCOPES: dict[str, Scope] = {
    "content": Scope(uri="https://content-api.wildberries.ru", spec_file="02-products.yaml"),
    "prices": Scope(uri="https://discounts-prices-api.wildberries.ru", spec_file="02-products.yaml"),
    "fbs": Scope(uri="https://marketplace-api.wildberries.ru", spec_file="03-orders-fbs"),
}


def main():
    parser = argparse.ArgumentParser(description="WB API")
    parser.add_argument("--token", required=True, help="API token")
    parser.add_argument("--scope", required=True, help="scope", choices=SCOPES.keys())
    parser.add_argument("--locale", required=False, help="locale (en, ru)", choices=("en", "ru"))
    args = parser.parse_args()

    locale: str = args.locale or "en"
    scope: Scope = SCOPES[args.scope]

    # load specs
    spec = load_http(f'{OPENAPI_DOWNLOAD_URI}/{locale}/{scope.spec_file}')

    # remove routes on other domains (iter over copy of keys)
    for path in list(spec["paths"].keys()):
        path_obj = spec["paths"][path]
        path_urls = [server["url"] for server in path_obj.get("servers", [])]
        is_matching = len(path_urls) == 0 or scope.uri in path_urls
        if not is_matching:
            del spec["paths"][path]

    client = httpx.AsyncClient(
        base_url=scope.uri,
        headers={"Authorization": "Bearer " + args.token},
    )
    mcp = FastMCP.from_openapi(
        openapi_spec=spec,
        client=client,
        name="WB API " + args.scope,
    )
    mcp.run()


if __name__ == "__main__":
    main()
