import logging
from functools import wraps
from typing import Any, Dict, Optional

from pydantic import BaseModel, TypeAdapter
from snowflake.snowpark import Session

from .configuration import (
    ConnectionConfigurationParameters,
    ConnectivityOption,
    InboundSyncConfigurationParameters,
    StoredConfigurationValue,
    get_secrets,
)

logger = logging.getLogger(__name__)


def snowflake_stored_proc(func):
    """
    Decorator for Snowflake stored procedure handlers.

    Wraps a function to serve as a Snowflake stored procedure entry point.
    The decorated function receives (session: Session, args: Dict) where args
    contains an 'operation' field plus connection/configuration data.

    The decorator:
    1. Resolves secrets (oauth_secret, other_secrets) from Snowflake
    2. Constructs the appropriate parameter object for the operation
    3. Calls the wrapped function with (session, <parameters>)
    4. Wraps the result in {"success": True, "data": ...}
    5. Catches exceptions and returns {"success": False, "error": ...}

    Supported operations:
    - 'connect': Calls func(session, ConnectionConfigurationParameters)

    Example args dict::

        {
            "operation": "connect",
            "connectivity_option": "direct",
            "connection_method": "Credentials",
            "connection_parameters": {...},
            "oauth_secret": "my_oauth_secret",
            "other_secrets": "my_other_secrets"
        }

    Usage::

        @snowflake_stored_proc
        def my_handler(session: Session, parameters: ConnectionConfigurationParameters):
            # Business logic for the 'connect' operation
            return ConnectResponse(...)
    """

    @wraps(func)
    def wrapper(session: Session, args: Dict) -> Dict:
        try:
            operation = args.get("operation")
            if operation is None:
                raise ValueError("'operation' is required in the args dict")

            # Resolve secrets
            oauth_secret_name = args.get("oauth_secret")
            other_secrets_name = args.get("other_secrets")
            connection_secrets = get_secrets(oauth_secret_name, other_secrets_name)
            if args.get("connection_secrets_direct") is not None:
                connection_secrets.update(
                    TypeAdapter(Dict[str, StoredConfigurationValue]).validate_python(
                        args["connection_secrets_direct"]
                    )
                )

            if operation == "connect" or operation == "network_addresses":
                parameters = _build_connection_configuration_parameters(
                    args, connection_secrets, oauth_secret_name
                )
                result = func(session, parameters)
            elif operation == 'connection_form':
                result = func()
            elif operation == 'inbound_stream_list':
                # takes a single parameter named 'parameters': InboundSyncConfigurationParameters
                # same as connect but also includes:
                # sync_parameters = TypeAdapter(Dict[str, StoredConfigurationValue]).validate_python(sync_parameters)
                    parameters = _build_connection_configuration_parameters(
                        args, connection_secrets, oauth_secret_name
                    )
                    sync_parameters = args.get("sync_parameters", {})
                    if sync_parameters:
                        sync_parameters = TypeAdapter(
                            Dict[str, StoredConfigurationValue]
                        ).validate_python(sync_parameters)
                    parameter = InboundSyncConfigurationParameters(
                        **parameters, sync_parameters=sync_parameters
                    )
                    result = func(session, parameter)
            else:
                raise ValueError(f"Unknown operation: '{operation}'")

            # Serialize the result
            data = _serialize_result(result)
            return {"success": True, "data": data}

        except Exception as e:
            logger.error(
                f"Error in stored proc handler ({args.get('operation', 'unknown')}): {e}",
                exc_info=True,
            )
            return {"success": False, "error": str(e)}

    return wrapper


def snowflake_udtf(cls):
    """
    Decorator for Snowflake UDTF handler classes.

    Wraps the ``process`` method of a UDTF handler class so that the first
    parameter (the connection configuration dict) is automatically resolved
    into a :class:`ConnectionConfigurationParameters` instance before the
    real ``process`` implementation is called.

    Unlike ``snowflake_stored_proc`` there is no Snowpark session parameter,
    and results are yielded as rows rather than wrapped in a success/error dict.

    Supported operations:
    - ``'inbound_sync_rest_paginated'``: Calls ``process(ConnectionConfigurationParameters, *rest_args)``

    Example::

        @snowflake_udtf
        class MyUDTF:
            def process(self, connection_config: ConnectionConfigurationParameters, url: str):
                # Business logic – yield one tuple per output row
                yield (result_value,)
    """

    original_process = cls.process

    @wraps(original_process)
    def wrapped_process(self, connection_config: Dict, *args):
        operation = connection_config.get("operation")
        if operation is None:
            raise ValueError("'operation' is required in the connection configuration")

        # Resolve secrets
        oauth_secret_name = connection_config.get("oauth_secret")
        other_secrets_name = connection_config.get("other_secrets")
        connection_secrets = get_secrets(oauth_secret_name, other_secrets_name)
        if connection_config.get("connection_secrets_direct") is not None:
            connection_secrets.update(
                TypeAdapter(Dict[str, StoredConfigurationValue]).validate_python(
                    connection_config["connection_secrets_direct"]
                )
            )

        if operation == "inbound_sync_rest_paginated":
            parameters = _build_connection_configuration_parameters(
                connection_config, connection_secrets, oauth_secret_name
            )
            yield from original_process(self, parameters, *args)
        else:
            raise ValueError(f"Unknown operation: '{operation}'")

    cls.process = wrapped_process
    return cls


def _build_connection_configuration_parameters(
    args: Dict,
    connection_secrets: Dict[str, StoredConfigurationValue],
    oauth_secret_name: Optional[str],
) -> ConnectionConfigurationParameters:
    """
    Constructs a ConnectionConfigurationParameters from the raw args dict.
    """
    connection_parameters = args.get("connection_parameters", {})
    if connection_parameters:
        connection_parameters = TypeAdapter(
            Dict[str, StoredConfigurationValue]
        ).validate_python(connection_parameters)

    parameters = ConnectionConfigurationParameters(
        connectivity_option=ConnectivityOption(args["connectivity_option"]),
        connection_method=args["connection_method"],
        connection_parameters=connection_parameters,
        connection_secrets=connection_secrets,
    )
    if oauth_secret_name is not None:
        parameters.access_token_secret_name = oauth_secret_name

    return parameters


def _serialize_result(result: Any) -> Any:
    """
    Serializes the result of a stored proc handler into a JSON-compatible form.
    Handles Pydantic BaseModel instances and lists of BaseModel instances.
    """
    if isinstance(result, BaseModel):
        return result.model_dump()
    elif isinstance(result, list):
        return [
            item.model_dump() if isinstance(item, BaseModel) else item
            for item in result
        ]
    elif isinstance(result, dict):
        return result
    elif result is None:
        return None
    return result
