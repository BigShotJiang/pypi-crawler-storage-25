"""
JannaAuth Cryptographic Identity
Ed25519 key pairs and challenge-response proofs for AI agents
"""

import json
import secrets
import threading
import time
from dataclasses import dataclass
from typing import Optional, Dict, Any

from .exceptions import (
    CryptoError,
    InvalidProofError,
    InvalidSignatureError,
    ProofExpiredError,
    KeyPairError
)

try:
    from cryptography.hazmat.primitives.asymmetric import ed25519
    from cryptography.hazmat.primitives import serialization
    CRYPTO_AVAILABLE = True
except ImportError:
    CRYPTO_AVAILABLE = False


class KeyPair:
    """
    Ed25519 key pair for agent identity.

    Usage:
        keys = KeyPair()
        signature = keys.sign(b"message")
        keys.verify(b"message", signature)  # Returns True
    """

    def __init__(self, private_key_bytes: Optional[bytes] = None):
        """
        Create or load a key pair.

        Args:
            private_key_bytes: Optional existing private key to load

        Raises:
            CryptoError: If the 'cryptography' package is not installed.
        """
        if not CRYPTO_AVAILABLE:
            raise CryptoError(
                "Ed25519 requires the 'cryptography' package. "
                "Install it with: pip install 'jannaauth[crypto]'"
            )
        self._init_ed25519(private_key_bytes)

    def _init_ed25519(self, private_key_bytes: Optional[bytes] = None):
        try:
            if private_key_bytes:
                self._private_key = ed25519.Ed25519PrivateKey.from_private_bytes(
                    private_key_bytes
                )
            else:
                self._private_key = ed25519.Ed25519PrivateKey.generate()

            self._public_key = self._private_key.public_key()
            self._algorithm = "ed25519"
        except Exception as e:
            raise KeyPairError(f"Failed to initialize Ed25519 key pair: {e}")

    @property
    def public_key_bytes(self) -> bytes:
        return self._public_key.public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw
        )

    @property
    def public_key_hex(self) -> str:
        return self.public_key_bytes.hex()

    @property
    def private_key_bytes(self) -> bytes:
        return self._private_key.private_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PrivateFormat.Raw,
            encryption_algorithm=serialization.NoEncryption()
        )

    @property
    def algorithm(self) -> str:
        return self._algorithm

    def sign(self, message: bytes) -> bytes:
        return self._private_key.sign(message)

    def verify(self, message: bytes, signature: bytes) -> bool:
        try:
            self._public_key.verify(signature, message)
            return True
        except Exception as e:
            raise InvalidSignatureError(f"Signature verification failed: {e}")

    @classmethod
    def from_public_key_hex(cls, public_key_hex: str) -> 'PublicKeyOnly':
        return PublicKeyOnly(bytes.fromhex(public_key_hex))


class PublicKeyOnly:
    """Public key only — can verify but not sign."""

    def __init__(self, public_key_bytes: bytes):
        self._public_key_bytes = public_key_bytes

        if CRYPTO_AVAILABLE:
            try:
                self._public_key = ed25519.Ed25519PublicKey.from_public_bytes(
                    public_key_bytes
                )
                self._algorithm = "ed25519"
            except Exception:
                self._public_key = None
                self._algorithm = "unknown"
        else:
            self._public_key = None
            self._algorithm = "unknown"

    @property
    def public_key_bytes(self) -> bytes:
        return self._public_key_bytes

    @property
    def public_key_hex(self) -> str:
        return self._public_key_bytes.hex()

    def verify(self, message: bytes, signature: bytes) -> bool:
        if not CRYPTO_AVAILABLE or not self._public_key:
            raise CryptoError(
                "Ed25519 verification requires the 'cryptography' package. "
                "Install it with: pip install 'jannaauth[crypto]'"
            )
        try:
            self._public_key.verify(signature, message)
            return True
        except Exception as e:
            raise InvalidSignatureError(f"Signature verification failed: {e}")


@dataclass
class Proof:
    """
    Cryptographic proof of agent identity.

    Contains everything needed to verify an agent's identity:
    - Challenge that was signed
    - Timestamp (for replay protection)
    - Signature
    - Public key
    - Agent ID
    """
    challenge: str
    timestamp: int
    signature: str  # Hex encoded
    public_key: str  # Hex encoded
    agent_id: str
    nonce: str       # 128-bit random — tracked by verifier for replay prevention
    algorithm: str = "ed25519"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "challenge": self.challenge,
            "timestamp": self.timestamp,
            "signature": self.signature,
            "public_key": self.public_key,
            "agent_id": self.agent_id,
            "nonce": self.nonce,
            "algorithm": self.algorithm
        }

    def to_json(self) -> str:
        return json.dumps(self.to_dict())

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Proof':
        return cls(
            challenge=data["challenge"],
            timestamp=data["timestamp"],
            signature=data["signature"],
            public_key=data["public_key"],
            agent_id=data["agent_id"],
            nonce=data["nonce"],
            algorithm=data.get("algorithm", "ed25519")
        )

    @classmethod
    def from_json(cls, json_str: str) -> 'Proof':
        return cls.from_dict(json.loads(json_str))

    @property
    def message_bytes(self) -> bytes:
        return f"{self.challenge}:{self.timestamp}:{self.nonce}".encode()

    @property
    def signature_bytes(self) -> bytes:
        return bytes.fromhex(self.signature)

    @property
    def age_seconds(self) -> float:
        return time.time() - self.timestamp

    def is_expired(self, max_age_seconds: int = 60) -> bool:
        return self.age_seconds > max_age_seconds


class _NonceCache:
    """
    TTL-bounded in-memory nonce cache for replay prevention.

    Stores seen proof nonces until their TTL expires. A proof whose nonce
    appears in this cache is a replay and must be rejected.

    Thread-safe. For multi-process deployments, replace with a Redis backend
    by subclassing and overriding check_and_add / _evict.
    """

    def __init__(self):
        self._seen: Dict[str, float] = {}  # nonce -> expiry timestamp
        self._lock = threading.Lock()

    def check_and_add(self, nonce: str, max_age_seconds: int) -> bool:
        """
        Return True if nonce is fresh (first time seen). False = replay.

        On True, the nonce is recorded and will be rejected for the next
        max_age_seconds seconds.
        """
        now = time.time()
        with self._lock:
            self._evict(now)
            if nonce in self._seen:
                return False
            self._seen[nonce] = now + max_age_seconds
            return True

    def _evict(self, now: float):
        expired = [n for n, exp in self._seen.items() if exp <= now]
        for n in expired:
            del self._seen[n]


# Module-level nonce cache shared across all ProofVerifier instances in this process.
# For multi-process deployments, replace with a Redis-backed equivalent.
_nonce_cache = _NonceCache()


class ProofGenerator:
    """
    Generates cryptographic proofs for an agent.

    Usage:
        generator = ProofGenerator(agent_id, key_pair)
        proof = generator.create_proof("challenge_string")
    """

    def __init__(self, agent_id: str, key_pair: KeyPair):
        self.agent_id = agent_id
        self.key_pair = key_pair

    def create_proof(self, challenge: str, timestamp: Optional[int] = None) -> Proof:
        timestamp = timestamp or int(time.time())
        nonce = secrets.token_hex(16)  # 128-bit

        message = f"{challenge}:{timestamp}:{nonce}".encode()
        signature = self.key_pair.sign(message)

        return Proof(
            challenge=challenge,
            timestamp=timestamp,
            signature=signature.hex(),
            public_key=self.key_pair.public_key_hex,
            agent_id=self.agent_id,
            nonce=nonce,
            algorithm=self.key_pair.algorithm
        )


class ProofVerifier:
    """
    Verifies cryptographic proofs from agents.

    Usage:
        verifier = ProofVerifier(registry)
        verifier.verify(proof, max_age_seconds=60)
    """

    def __init__(self, registry=None):
        self.registry = registry

    def verify(
        self,
        proof: Proof,
        expected_challenge: Optional[str] = None,
        max_age_seconds: int = 60,
    ) -> bool:
        """
        Verify a proof of identity.

        Checks (in order):
          1. Proof is not future-dated
          2. Proof has not expired
          3. Nonce has not been seen before (replay prevention)
          4. Challenge matches expected value (if provided)
          5. Agent is active in registry and public key matches registered key
          6. Ed25519 signature is valid

        Args:
            proof:              Proof to verify.
            expected_challenge: If provided, the proof's challenge must match exactly.
                                Pass this to bind the proof to specific data (e.g. handoff).
            max_age_seconds:    Maximum proof age in seconds (default 60).

        Returns:
            True if valid.

        Raises:
            InvalidProofError:    Future-dated, challenge mismatch, replay, or key mismatch.
            ProofExpiredError:    Proof is older than max_age_seconds.
            InvalidSignatureError: Ed25519 signature is invalid.
            AgentNotFoundError:   Agent not in registry.
            AgentRevokedError:    Agent has been revoked.
            AgentSuspendedError:  Agent has been suspended.
        """
        # 1. Reject future-dated proofs (negative age bypasses is_expired check)
        if proof.age_seconds < 0:
            raise InvalidProofError("Proof timestamp is in the future")

        # 2. Check expiration
        if proof.is_expired(max_age_seconds):
            raise ProofExpiredError(
                f"Proof is {proof.age_seconds:.1f}s old, max is {max_age_seconds}s"
            )

        # 3. Replay prevention — nonce must not have been seen in this window
        if not _nonce_cache.check_and_add(proof.nonce, max_age_seconds):
            raise InvalidProofError("Proof nonce already used — replay detected")

        # 4. Challenge binding
        if expected_challenge is not None and proof.challenge != expected_challenge:
            raise InvalidProofError("Challenge mismatch")

        # 5. Registry check — binds agent_id to its registered public key
        if self.registry:
            from .agent import AgentStatus
            from .exceptions import AgentNotFoundError, AgentRevokedError, AgentSuspendedError

            agent = self.registry.get(proof.agent_id)  # raises AgentNotFoundError

            if agent.status == AgentStatus.REVOKED:
                raise AgentRevokedError(f"Agent {proof.agent_id} is revoked")

            if agent.status == AgentStatus.SUSPENDED:
                raise AgentSuspendedError(f"Agent {proof.agent_id} is suspended")

            if agent.public_key_hex != proof.public_key:
                raise InvalidProofError("Public key does not match registered key")

        # 6. Ed25519 signature verification
        if not CRYPTO_AVAILABLE or proof.algorithm != "ed25519":
            raise InvalidProofError(
                "Only Ed25519 proofs are supported. "
                "Install 'cryptography': pip install 'jannaauth[crypto]'"
            )

        try:
            public_key = ed25519.Ed25519PublicKey.from_public_bytes(
                bytes.fromhex(proof.public_key)
            )
            public_key.verify(proof.signature_bytes, proof.message_bytes)
        except Exception as e:
            raise InvalidSignatureError(f"Signature verification failed: {e}")

        return True

    def verify_dict(self, proof_dict: Dict[str, Any], **kwargs) -> bool:
        return self.verify(Proof.from_dict(proof_dict), **kwargs)

    def verify_json(self, proof_json: str, **kwargs) -> bool:
        return self.verify(Proof.from_json(proof_json), **kwargs)


def generate_challenge() -> str:
    """Generate a random 128-bit challenge string."""
    return secrets.token_hex(16)
