"""
JannaAuth Permissions System
Granular permission management for AI agents
"""

import inspect
import re
import functools
from enum import Enum
from typing import List, Optional, Set, Dict, Any, Callable, Union
from dataclasses import dataclass, field

from .exceptions import (
    PermissionDeniedError,
    InvalidPermissionError,
    NoActiveSessionError
)


class PermissionAction(Enum):
    """Standard permission actions"""
    READ = "read"
    WRITE = "write"
    DELETE = "delete"
    EXECUTE = "execute"
    CALL = "call"
    ADMIN = "admin"
    ALL = "*"


@dataclass
class Permission:
    """
    Represents a single permission.

    Format: action:resource
    Examples:
        - read:database
        - write:files
        - delete:records
        - call:api.openai
        - admin:*
        - *:* (superuser)

    Wildcards:
        - read:* = read any resource
        - *:database = any action on database
        - *:* = full access
    """
    action: str
    resource: str

    def __post_init__(self):
        """Validate permission format"""
        if not self.action or not self.resource:
            raise InvalidPermissionError(
                "Invalid permission: action and resource required"
            )

    @classmethod
    def from_string(cls, perm_string: str) -> 'Permission':
        if ':' not in perm_string:
            raise InvalidPermissionError(
                f"Invalid permission format '{perm_string}'. Expected 'action:resource'"
            )
        parts = perm_string.split(':', 1)
        return cls(action=parts[0], resource=parts[1])

    def __str__(self) -> str:
        return f"{self.action}:{self.resource}"

    def __hash__(self) -> int:
        return hash(str(self))

    def __eq__(self, other) -> bool:
        if isinstance(other, Permission):
            return str(self) == str(other)
        if isinstance(other, str):
            return str(self) == other
        return False

    def matches(self, required: 'Permission') -> bool:
        action_match = (self.action == "*" or self.action == required.action)
        resource_match = self._resource_matches(required.resource)
        return action_match and resource_match

    def _resource_matches(self, required_resource: str) -> bool:
        if self.resource == required_resource:
            return True
        if self.resource == "*":
            return True
        if self.resource.endswith(".*"):
            prefix = self.resource[:-2]
            # Require a dot boundary — "files.*" must not match "filesabc"
            if required_resource.startswith(prefix + "."):
                return True
        if "*" in self.resource:
            # re.escape first, then restore wildcards to avoid regex injection
            escaped = re.escape(self.resource)
            pattern = escaped.replace(r"\*", r"[^:.]*")
            if re.match(f"^{pattern}$", required_resource):
                return True
        return False

    # Convenience constructors
    @classmethod
    def READ(cls, resource: str) -> 'Permission':
        return cls(action="read", resource=resource)

    @classmethod
    def WRITE(cls, resource: str) -> 'Permission':
        return cls(action="write", resource=resource)

    @classmethod
    def DELETE(cls, resource: str) -> 'Permission':
        return cls(action="delete", resource=resource)

    @classmethod
    def EXECUTE(cls, resource: str) -> 'Permission':
        return cls(action="execute", resource=resource)

    @classmethod
    def CALL(cls, resource: str) -> 'Permission':
        return cls(action="call", resource=resource)

    @classmethod
    def ADMIN(cls, resource: str) -> 'Permission':
        return cls(action="admin", resource=resource)

    @classmethod
    def ALL(cls, resource: str = "*") -> 'Permission':
        return cls(action="*", resource=resource)


class PermissionSet:
    """
    A set of permissions with efficient checking.

    Usage:
        perms = PermissionSet([
            Permission.READ("database"),
            Permission.WRITE("files.*"),
            Permission.CALL("api.*")
        ])

        perms.has("read:database")          # True
        perms.has("write:files.documents")  # True
        perms.has("delete:records")         # False
    """

    def __init__(self, permissions: List[Union[Permission, str]] = None):
        self._permissions: Set[Permission] = set()
        if permissions:
            for p in permissions:
                self.add(p)

    def add(self, permission: Union[Permission, str]):
        if isinstance(permission, str):
            permission = Permission.from_string(permission)
        self._permissions.add(permission)

    def remove(self, permission: Union[Permission, str]):
        if isinstance(permission, str):
            permission = Permission.from_string(permission)
        self._permissions.discard(permission)

    def has(self, required: Union[Permission, str]) -> bool:
        if isinstance(required, str):
            required = Permission.from_string(required)
        return any(perm.matches(required) for perm in self._permissions)

    def has_all(self, required: List[Union[Permission, str]]) -> bool:
        return all(self.has(p) for p in required)

    def has_any(self, required: List[Union[Permission, str]]) -> bool:
        return any(self.has(p) for p in required)

    def check(self, required: Union[Permission, str]) -> bool:
        if not self.has(required):
            raise PermissionDeniedError(f"Permission denied: {required}")
        return True

    def __contains__(self, permission: Union[Permission, str]) -> bool:
        return self.has(permission)

    def __iter__(self):
        return iter(self._permissions)

    def __len__(self) -> int:
        return len(self._permissions)

    def to_list(self) -> List[str]:
        return [str(p) for p in self._permissions]

    @classmethod
    def from_list(cls, permission_strings: List[str]) -> 'PermissionSet':
        return cls([Permission.from_string(p) for p in permission_strings])


def protect(
    requires: Union[str, List[str], Permission, List[Permission]] = None,
    any_of: Union[str, List[str], Permission, List[Permission]] = None,
    deny_message: str = None,
    requires_approval: bool = False,
    approval_timeout: int = 300,
    approval_details_fn: Optional[Callable] = None,
    wait_for_approval: bool = False,
    approval_poll_interval: float = 1.0,
):
    """
    Decorator to protect functions with permission checks and optional
    human approval gates.

    Works with both synchronous and async (async def) functions.

    Args:
        requires:               Single permission or list — agent must have ALL.
        any_of:                 List of permissions — agent must have ANY ONE.
        deny_message:           Custom message on permission denial.
        requires_approval:      If True, a human must approve before execution.
        approval_timeout:       Seconds the approval request stays open (default 300).
        approval_details_fn:    Optional callable(func, args, kwargs) → dict
                                for contextual details shown to the approver.
        wait_for_approval:      If True, block/await until decision.
                                If False (default), raise ApprovalPendingError.
        approval_poll_interval: Polling interval (seconds) when wait_for_approval=True.

    Usage:
        @protect(requires="read:database")
        def get_data(): ...

        @protect(requires="delete:records", requires_approval=True)
        def delete_all(): ...

        # Async function — works identically
        @protect(requires="write:reports", requires_approval=True, wait_for_approval=True)
        async def generate_report(): ...

    Must be called within an agent session:
        with agent.session():
            get_data()

        async with agent.async_session():
            await generate_report()
    """

    # ------------------------------------------------------------------
    # Shared helpers (called by both sync and async wrappers)
    # ------------------------------------------------------------------

    def _get_session_and_agent(func_name):
        from .session import session_manager
        from .agent import agent_registry

        session = session_manager.get_current()
        if not session:
            raise NoActiveSessionError(
                f"Cannot call protected function '{func_name}' "
                "outside of an agent session"
            )
        try:
            agent = agent_registry.get(session.agent_id)
        except Exception:
            raise PermissionDeniedError(
                f"Agent {session.agent_id} not found in registry"
            )
        return session, agent

    def _check_permissions(agent, required_str):
        if requires:
            req_list = [requires] if isinstance(requires, (str, Permission)) else requires
            if not agent.permissions.has_all(req_list):
                raise PermissionDeniedError(deny_message or f"Requires all of: {req_list}")

        if any_of:
            any_list = [any_of] if isinstance(any_of, (str, Permission)) else any_of
            if not agent.permissions.has_any(any_list):
                raise PermissionDeniedError(deny_message or f"Requires any of: {any_list}")

    def _build_approval_request(agent, func, args, kwargs):
        from .approval import approval_queue

        details = None
        if approval_details_fn:
            try:
                details = approval_details_fn(func, args, kwargs)
            except Exception:
                details = {"function": func.__name__}

        return approval_queue.request(
            agent=agent,
            action=func.__name__,
            details=details,
            timeout_seconds=approval_timeout,
        )

    def _log_executed(session, func_name, required_str):
        from .audit import audit_log, ActionType, ActionStatus
        audit_log.log(
            agent_id=session.agent_id,
            agent_name=session.agent_name,
            action_type=ActionType.ACTION_EXECUTED,
            status=ActionStatus.SUCCESS,
            resource=func_name,
            details={"permissions_checked": required_str},
        )

    def _log_denied(session, func_name, required_str, error):
        from .audit import audit_log, ActionType, ActionStatus
        audit_log.log(
            agent_id=session.agent_id,
            agent_name=session.agent_name,
            action_type=ActionType.ACTION_DENIED,
            status=ActionStatus.DENIED,
            resource=func_name,
            details={"permissions_required": required_str},
            error=str(error),
        )

    # ------------------------------------------------------------------
    # Decorator factory — returns sync or async wrapper based on func type
    # ------------------------------------------------------------------

    def decorator(func: Callable) -> Callable:

        required_str = str(requires) if requires else str(any_of)

        if inspect.iscoroutinefunction(func):
            # --------------------------------------------------------
            # Async wrapper — returned when decorating an async def
            # --------------------------------------------------------
            @functools.wraps(func)
            async def async_wrapper(*args, **kwargs):
                from .exceptions import ApprovalPendingError

                session, agent = _get_session_and_agent(func.__name__)
                try:
                    _check_permissions(agent, required_str)

                    if requires_approval:
                        from .approval import approval_queue
                        approval_request = _build_approval_request(agent, func, args, kwargs)

                        if wait_for_approval:
                            await approval_queue.wait_for_decision_async(
                                approval_request.id,
                                poll_interval=approval_poll_interval,
                                timeout=approval_timeout,
                            )
                        else:
                            raise ApprovalPendingError(
                                f"Action '{func.__name__}' requires human approval "
                                f"(id: {approval_request.id}).",
                                request=approval_request,
                            )

                    _log_executed(session, func.__name__, required_str)
                    return await func(*args, **kwargs)

                except PermissionDeniedError as e:
                    _log_denied(session, func.__name__, required_str, e)
                    raise

            return async_wrapper

        else:
            # --------------------------------------------------------
            # Sync wrapper — original behaviour, fully backward-compat
            # --------------------------------------------------------
            @functools.wraps(func)
            def wrapper(*args, **kwargs):
                from .exceptions import ApprovalPendingError

                session, agent = _get_session_and_agent(func.__name__)
                try:
                    _check_permissions(agent, required_str)

                    if requires_approval:
                        from .approval import approval_queue
                        approval_request = _build_approval_request(agent, func, args, kwargs)

                        if wait_for_approval:
                            approval_queue.wait_for_decision(
                                approval_request.id,
                                poll_interval=approval_poll_interval,
                                timeout=approval_timeout,
                            )
                        else:
                            raise ApprovalPendingError(
                                f"Action '{func.__name__}' requires human approval "
                                f"(id: {approval_request.id}).",
                                request=approval_request,
                            )

                    _log_executed(session, func.__name__, required_str)
                    return func(*args, **kwargs)

                except PermissionDeniedError as e:
                    _log_denied(session, func.__name__, required_str, e)
                    raise

            return wrapper

    return decorator


def requires_permission(permission: Union[str, Permission]):
    """
    Simpler decorator for single permission.

    Usage:
        @requires_permission("read:database")
        def query_database():
            return ...
    """
    return protect(requires=permission)


class PermissionChecker:
    """
    Standalone permission checker for manual checks.

    Usage:
        checker = PermissionChecker(agent)

        if checker.can("read:database"):
            data = query_database()

        checker.require("write:files")  # Raises if denied
    """

    def __init__(self, agent):
        self.agent = agent

    def can(self, permission: Union[str, Permission]) -> bool:
        return self.agent.permissions.has(permission)

    def can_all(self, permissions: List[Union[str, Permission]]) -> bool:
        return self.agent.permissions.has_all(permissions)

    def can_any(self, permissions: List[Union[str, Permission]]) -> bool:
        return self.agent.permissions.has_any(permissions)

    def require(self, permission: Union[str, Permission]):
        return self.agent.permissions.check(permission)

    def require_all(self, permissions: List[Union[str, Permission]]):
        for p in permissions:
            self.require(p)

    def require_any(self, permissions: List[Union[str, Permission]]):
        if not self.can_any(permissions):
            raise PermissionDeniedError(
                f"Requires at least one of: {permissions}"
            )
