"""
JannaAuth Audit Logging
Track all agent actions for compliance and debugging
"""

import hashlib
import json
import os
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional, Dict, Any, List, Union
from dataclasses import dataclass, field, asdict
from enum import Enum
import threading


def _utcnow() -> datetime:
    """Return current UTC time as a naive datetime (timezone-unaware, UTC)."""
    return datetime.now(timezone.utc).replace(tzinfo=None)


class ActionType(Enum):
    """Types of auditable actions"""
    # Session
    SESSION_START = "session_start"
    SESSION_END = "session_end"

    # Token
    TOKEN_GENERATED = "token_generated"
    TOKEN_VERIFIED = "token_verified"
    TOKEN_EXPIRED = "token_expired"
    TOKEN_INVALID = "token_invalid"

    # Agent lifecycle
    AGENT_CREATED = "agent_created"
    AGENT_REVOKED = "agent_revoked"
    AGENT_SUSPENDED = "agent_suspended"
    AGENT_REACTIVATED = "agent_reactivated"

    # Actions
    ACTION_EXECUTED = "action_executed"
    ACTION_DENIED = "action_denied"

    # Proofs
    PROOF_CREATED = "proof_created"
    PROOF_VERIFIED = "proof_verified"
    PROOF_REJECTED = "proof_rejected"

    # Permissions
    PERMISSION_GRANTED = "permission_granted"
    PERMISSION_REVOKED = "permission_revoked"
    PERMISSION_CHECKED = "permission_checked"

    # Handoffs
    HANDOFF_SENT = "handoff_sent"
    HANDOFF_RECEIVED = "handoff_received"
    HANDOFF_REJECTED = "handoff_rejected"

    # Human approvals (v0.3.0)
    APPROVAL_REQUESTED = "approval_requested"
    APPROVAL_GRANTED = "approval_granted"
    APPROVAL_REJECTED = "approval_rejected"
    APPROVAL_EXPIRED = "approval_expired"


class ActionStatus(Enum):
    """Status of an action"""
    SUCCESS = "success"
    DENIED = "denied"
    ERROR = "error"
    PENDING = "pending"


@dataclass
class AuditEntry:
    """Single audit log entry"""
    timestamp: str
    agent_id: str
    agent_name: str
    action_type: str
    status: str
    resource: Optional[str] = None
    details: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
    duration_ms: Optional[int] = None
    session_id: Optional[str] = None
    # Hash of the preceding entry's JSON — forms a tamper-evident chain.
    # None for the first entry written before this version (pre-chain).
    prev_hash: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {k: v for k, v in asdict(self).items() if v is not None}

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), sort_keys=True)


class AuditLog:
    """
    Audit logging for JannaAuth.

    Tracks all agent actions including:
    - Session start/end
    - Token operations
    - Action execution
    - Permission checks
    - Proofs and verifications
    - Errors and denials

    Entries are written to an append-only JSONL file with:
    - A sha256 hash chain (each entry records sha256 of the previous entry)
    - fsync after every write for durability
    - No public clear() — use clear(allow_clear=True) explicitly

    Usage:
        from jannaauth import audit_log
        audit_log.configure(persist_path="logs/jannaauth.jsonl")
        entries = audit_log.query(agent_id="agent_123", limit=100)
        ok, errors = audit_log.verify_chain()
    """

    _instance = None
    _lock = threading.Lock()

    def __new__(cls):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
                    cls._instance._initialized = False
        return cls._instance

    def __init__(self):
        if self._initialized:
            return

        self._entries: List[AuditEntry] = []
        self._max_entries = 10000
        self._callbacks: List[callable] = []
        self._persist_path: Optional[Path] = None
        self._file_lock = threading.Lock()
        self._prev_hash: str = "0" * 64  # genesis sentinel
        self._initialized = True

    def configure(
        self,
        persist_path: Union[str, Path] = None,
        max_entries: int = None
    ):
        """
        Configure persistence and/or entry cap.

        Call once at startup, before any agents are created.

        Args:
            persist_path: Path to a .jsonl file. Created if it doesn't exist.
                          Existing entries are loaded into memory on first call.
            max_entries:  Override the default 10,000 in-memory cap.
        """
        if max_entries is not None:
            self._max_entries = max_entries

        if persist_path is not None:
            path = Path(persist_path)
            path.parent.mkdir(parents=True, exist_ok=True)
            self._persist_path = path
            self._load_from_file()

    def _load_from_file(self):
        """Load existing entries from the .jsonl file into memory."""
        if not self._persist_path or not self._persist_path.exists():
            return

        loaded = []
        last_raw_line = None

        with open(self._persist_path, "r", encoding="utf-8") as f:
            for line in f:
                stripped = line.strip()
                if not stripped:
                    continue
                try:
                    data = json.loads(stripped)
                    loaded.append(AuditEntry(**{
                        k: v for k, v in data.items()
                        if k in AuditEntry.__dataclass_fields__
                    }))
                    last_raw_line = stripped
                except Exception:
                    pass  # Skip malformed lines

        self._entries = loaded + self._entries
        if len(self._entries) > self._max_entries:
            self._entries = self._entries[-self._max_entries:]

        # Seed the hash chain from the last stored entry
        if last_raw_line:
            self._prev_hash = hashlib.sha256(last_raw_line.encode()).hexdigest()

    def _append_to_file(self, entry: AuditEntry):
        """Append a single entry to the .jsonl file and fsync for durability."""
        if not self._persist_path:
            return
        with self._file_lock:
            with open(self._persist_path, "a", encoding="utf-8") as f:
                f.write(entry.to_json() + "\n")
                f.flush()
                os.fsync(f.fileno())

    def log(
        self,
        agent_id: str,
        agent_name: str,
        action_type: ActionType,
        status: ActionStatus = ActionStatus.SUCCESS,
        resource: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
        error: Optional[str] = None,
        duration_ms: Optional[int] = None,
        session_id: Optional[str] = None
    ) -> AuditEntry:
        """Log an action."""
        entry = AuditEntry(
            timestamp=_utcnow().isoformat() + "Z",
            agent_id=agent_id,
            agent_name=agent_name,
            action_type=action_type.value,
            status=status.value,
            resource=resource,
            details=details,
            error=error,
            duration_ms=duration_ms,
            session_id=session_id,
            prev_hash=self._prev_hash,
        )

        self._entries.append(entry)
        self._append_to_file(entry)

        # Advance the chain pointer
        self._prev_hash = hashlib.sha256(entry.to_json().encode()).hexdigest()

        if len(self._entries) > self._max_entries:
            self._entries = self._entries[-self._max_entries:]

        for callback in self._callbacks:
            try:
                callback(entry)
            except Exception:
                pass

        return entry

    def verify_chain(self) -> tuple:
        """
        Verify the hash chain integrity of the persisted log file.

        Reads the file from disk and checks that each entry's prev_hash equals
        sha256 of the preceding entry's JSON. Entries without prev_hash (written
        before this version) are skipped — they cannot be chain-verified.

        Returns:
            (ok: bool, errors: List[str]) — ok is True if no tampering detected.

        Usage:
            ok, errors = audit_log.verify_chain()
            if not ok:
                alert(errors)
        """
        if not self._persist_path or not self._persist_path.exists():
            return True, []

        entries = []
        raw_lines = []

        with open(self._persist_path, "r", encoding="utf-8") as f:
            for line in f:
                stripped = line.strip()
                if not stripped:
                    continue
                try:
                    data = json.loads(stripped)
                    entries.append(data)
                    raw_lines.append(stripped)
                except Exception:
                    pass

        errors = []
        prev_raw = None

        for i, (entry, raw) in enumerate(zip(entries, raw_lines)):
            ph = entry.get("prev_hash")
            if ph is None:
                # Pre-chain entry — skip verification, advance pointer
                prev_raw = raw
                continue

            if prev_raw is None:
                # First chained entry but no predecessor in file — genesis
                prev_raw = raw
                continue

            expected = hashlib.sha256(prev_raw.encode()).hexdigest()
            if ph != expected:
                errors.append(
                    f"Entry {i} (agent={entry.get('agent_id')}, "
                    f"ts={entry.get('timestamp')}) has invalid prev_hash — "
                    f"log may have been tampered with"
                )
            prev_raw = raw

        return len(errors) == 0, errors

    def query(
        self,
        agent_id: Optional[str] = None,
        agent_name: Optional[str] = None,
        action_type: Optional[ActionType] = None,
        status: Optional[ActionStatus] = None,
        session_id: Optional[str] = None,
        since: Optional[datetime] = None,
        until: Optional[datetime] = None,
        limit: int = 100
    ) -> List[AuditEntry]:
        """Query audit log entries"""
        results = []

        for entry in reversed(self._entries):
            if agent_id and entry.agent_id != agent_id:
                continue
            if agent_name and entry.agent_name != agent_name:
                continue
            if action_type and entry.action_type != action_type.value:
                continue
            if status and entry.status != status.value:
                continue
            if session_id and entry.session_id != session_id:
                continue
            if since:
                entry_time = datetime.fromisoformat(entry.timestamp.rstrip('Z'))
                if entry_time < since:
                    continue
            if until:
                entry_time = datetime.fromisoformat(entry.timestamp.rstrip('Z'))
                if entry_time > until:
                    continue

            results.append(entry)

            if len(results) >= limit:
                break

        return results

    def get_agent_history(self, agent_id: str, limit: int = 100) -> List[AuditEntry]:
        return self.query(agent_id=agent_id, limit=limit)

    def get_session_history(self, session_id: str) -> List[AuditEntry]:
        return self.query(session_id=session_id, limit=1000)

    def add_callback(self, callback: callable):
        self._callbacks.append(callback)

    def remove_callback(self, callback: callable):
        if callback in self._callbacks:
            self._callbacks.remove(callback)

    def export(self, format: str = "json") -> str:
        """Export all in-memory entries."""
        if format == "json":
            return json.dumps([e.to_dict() for e in self._entries], indent=2)
        elif format == "csv":
            if not self._entries:
                return ""

            headers = ["timestamp", "agent_id", "agent_name", "action_type",
                       "status", "resource", "error", "duration_ms", "session_id"]

            lines = [",".join(headers)]
            for entry in self._entries:
                row = []
                for h in headers:
                    val = getattr(entry, h, "") or ""
                    val = str(val).replace('"', '""')
                    if ',' in val or '"' in val:
                        val = f'"{val}"'
                    row.append(val)
                lines.append(",".join(row))

            return "\n".join(lines)
        else:
            raise ValueError(f"Unknown format: {format}")

    def clear(self, allow_clear: bool = False):
        """
        Clear all in-memory entries and truncate the persist file.

        Requires allow_clear=True to prevent accidental calls in production.
        Intended for testing only — clearing an audit log destroys evidence.
        """
        if not allow_clear:
            raise RuntimeError(
                "audit_log.clear() requires allow_clear=True. "
                "This operation destroys audit evidence — use only in tests."
            )
        self._entries = []
        self._prev_hash = "0" * 64
        if self._persist_path and self._persist_path.exists():
            with self._file_lock:
                self._persist_path.write_text("", encoding="utf-8")

    @property
    def count(self) -> int:
        return len(self._entries)


# Global audit log instance
audit_log = AuditLog()
