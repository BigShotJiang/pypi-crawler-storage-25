"""
JannaAuth Token Management
JWT-like token generation and verification
"""

import json
import base64
import hashlib
import hmac
import time
import secrets
from typing import Optional, Dict, Any
from datetime import datetime, timedelta, timezone

from .exceptions import InvalidTokenError, TokenExpiredError


class TokenManager:
    """Manages JWT-like tokens for agent authentication"""

    def __init__(self, secret_key: Optional[str] = None):
        self.secret_key = secret_key or secrets.token_hex(32)
        self._revoked_jtis: set = set()
        # Stable key identifier — changes when secret_key rotates
        self._kid = hashlib.sha256(self.secret_key.encode()).hexdigest()[:16]

    def revoke(self, token: str):
        """
        Add a token's JTI to the in-memory revocation list.

        Call this before clearing an agent's token on revoke/suspend
        so that already-issued tokens cannot be reused.
        """
        try:
            payload = self.decode_without_verify(token)
            jti = payload.get("jti")
            if jti:
                self._revoked_jtis.add(jti)
        except Exception:
            pass

    def load_revoked_jtis(self, jtis):
        """Bulk-load revoked JTIs (e.g. from DB on startup)."""
        self._revoked_jtis.update(jtis)
    
    def _base64_encode(self, data: bytes) -> str:
        return base64.urlsafe_b64encode(data).rstrip(b'=').decode('utf-8')
    
    def _base64_decode(self, data: str) -> bytes:
        padding = 4 - len(data) % 4
        if padding != 4:
            data += '=' * padding
        return base64.urlsafe_b64decode(data)
    
    def _sign(self, message: str) -> str:
        signature = hmac.new(
            self.secret_key.encode('utf-8'),
            message.encode('utf-8'),
            hashlib.sha256
        ).digest()
        return self._base64_encode(signature)
    
    def generate(
        self,
        agent_id: str,
        agent_name: str,
        expires_in: Optional[int] = 86400,
        claims: Optional[Dict[str, Any]] = None
    ) -> str:
        """Generate a signed token"""
        now = int(time.time())

        payload = {
            "iss": "jannaauth",
            "aud": agent_id,
            "aid": agent_id,
            "name": agent_name,
            "iat": now,
            "nbf": now,
            "jti": secrets.token_hex(16),  # 128-bit
        }

        if expires_in is not None:
            payload["exp"] = now + expires_in

        if claims:
            payload["claims"] = claims

        header = {"alg": "HS256", "typ": "JAT", "kid": self._kid}
        
        header_b64 = self._base64_encode(json.dumps(header).encode('utf-8'))
        payload_b64 = self._base64_encode(json.dumps(payload).encode('utf-8'))
        
        message = f"{header_b64}.{payload_b64}"
        signature = self._sign(message)
        
        return f"ja_{header_b64}.{payload_b64}.{signature}"
    
    def verify(self, token: str) -> Dict[str, Any]:
        """Verify a token and return payload"""
        if not token.startswith("ja_"):
            raise InvalidTokenError("Invalid token format: missing 'ja_' prefix")
        
        token_body = token[3:]
        parts = token_body.split('.')
        
        if len(parts) != 3:
            raise InvalidTokenError("Invalid token format: expected 3 parts")
        
        header_b64, payload_b64, signature = parts

        # Enforce declared algorithm — prevents alg-confusion attacks
        try:
            header = json.loads(self._base64_decode(header_b64))
        except Exception as e:
            raise InvalidTokenError(f"Invalid token header: {e}")
        if header.get("alg") != "HS256":
            raise InvalidTokenError(
                f"Unsupported algorithm '{header.get('alg')}': only HS256 is accepted"
            )

        message = f"{header_b64}.{payload_b64}"
        expected_signature = self._sign(message)
        
        if not hmac.compare_digest(signature, expected_signature):
            raise InvalidTokenError("Invalid token signature")
        
        try:
            payload = json.loads(self._base64_decode(payload_b64))
        except Exception as e:
            raise InvalidTokenError(f"Invalid token payload: {e}")
        
        if "exp" in payload:
            if int(time.time()) > payload["exp"]:
                raise TokenExpiredError("Token has expired")

        jti = payload.get("jti")
        if jti and jti in self._revoked_jtis:
            raise InvalidTokenError("Token has been revoked")

        return payload
    
    def decode_without_verify(self, token: str) -> Dict[str, Any]:
        """Decode token without verification"""
        if not token.startswith("ja_"):
            raise InvalidTokenError("Invalid token format")
        
        parts = token[3:].split('.')
        if len(parts) != 3:
            raise InvalidTokenError("Invalid token format")
        
        try:
            return json.loads(self._base64_decode(parts[1]))
        except Exception as e:
            raise InvalidTokenError(f"Cannot decode token: {e}")
    
    def is_expired(self, token: str) -> bool:
        """Check if token is expired"""
        try:
            self.verify(token)
            return False
        except TokenExpiredError:
            return True
        except InvalidTokenError:
            return True
