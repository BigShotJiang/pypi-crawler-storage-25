"""
JannaAuth Session Management
Context manager for agent sessions
"""

import secrets
import time
from typing import Optional, Dict, Any, TYPE_CHECKING
from contextlib import contextmanager, asynccontextmanager
from dataclasses import dataclass
from datetime import datetime, timezone
import threading


def _utcnow() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)

from .audit import audit_log, ActionType, ActionStatus
from .exceptions import NoActiveSessionError, SessionError

if TYPE_CHECKING:
    from .agent import Agent


@dataclass
class Session:
    """Represents an active agent session"""
    session_id: str
    agent_id: str
    agent_name: str
    started_at: datetime
    ended_at: Optional[datetime] = None
    action_count: int = 0
    status: str = "active"
    metadata: Optional[Dict[str, Any]] = None
    
    @property
    def is_active(self) -> bool:
        return self.status == "active" and self.ended_at is None
    
    @property
    def duration_seconds(self) -> float:
        end = self.ended_at or _utcnow()
        return (end - self.started_at).total_seconds()
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "session_id": self.session_id,
            "agent_id": self.agent_id,
            "agent_name": self.agent_name,
            "started_at": self.started_at.isoformat() + "Z",
            "ended_at": self.ended_at.isoformat() + "Z" if self.ended_at else None,
            "action_count": self.action_count,
            "status": self.status,
            "duration_seconds": self.duration_seconds,
            "metadata": self.metadata
        }


class SessionManager:
    """Manages agent sessions"""
    
    def __init__(self):
        self._sessions: Dict[str, Session] = {}
        self._active_sessions: Dict[str, Session] = {}
        self._local = threading.local()
    
    def create(
        self,
        agent_id: str,
        agent_name: str,
        metadata: Optional[Dict[str, Any]] = None
    ) -> Session:
        """Create a new session for an agent"""
        session_id = f"sess_{secrets.token_hex(8)}"
        
        session = Session(
            session_id=session_id,
            agent_id=agent_id,
            agent_name=agent_name,
            started_at=_utcnow(),
            metadata=metadata
        )
        
        self._sessions[session_id] = session
        self._active_sessions[agent_id] = session
        
        audit_log.log(
            agent_id=agent_id,
            agent_name=agent_name,
            action_type=ActionType.SESSION_START,
            status=ActionStatus.SUCCESS,
            session_id=session_id,
            details={"metadata": metadata} if metadata else None
        )
        
        return session
    
    def end(self, session_id: str, status: str = "completed") -> Session:
        """End a session"""
        if session_id not in self._sessions:
            raise SessionError(f"Session not found: {session_id}")
        
        session = self._sessions[session_id]
        session.ended_at = _utcnow()
        session.status = status
        
        if session.agent_id in self._active_sessions:
            if self._active_sessions[session.agent_id].session_id == session_id:
                del self._active_sessions[session.agent_id]
        
        audit_log.log(
            agent_id=session.agent_id,
            agent_name=session.agent_name,
            action_type=ActionType.SESSION_END,
            status=ActionStatus.SUCCESS,
            session_id=session_id,
            details={
                "duration_seconds": session.duration_seconds,
                "action_count": session.action_count,
                "final_status": status
            }
        )
        
        return session
    
    def get(self, session_id: str) -> Optional[Session]:
        return self._sessions.get(session_id)
    
    def get_active(self, agent_id: str) -> Optional[Session]:
        session = self._active_sessions.get(agent_id)
        if session and session.is_active:
            return session
        return None
    
    def increment_action_count(self, session_id: str):
        if session_id in self._sessions:
            self._sessions[session_id].action_count += 1
    
    def set_current(self, session: Optional[Session]):
        self._local.current_session = session
    
    def get_current(self) -> Optional[Session]:
        return getattr(self._local, 'current_session', None)
    
    def require_current(self) -> Session:
        session = self.get_current()
        if not session:
            raise NoActiveSessionError(
                "No active session. Use 'with agent.session():' first."
            )
        return session
    
    @contextmanager
    def session_context(
        self,
        agent_id: str,
        agent_name: str,
        metadata: Optional[Dict[str, Any]] = None
    ):
        """Context manager for sessions"""
        session = self.create(agent_id, agent_name, metadata)
        self.set_current(session)
        
        try:
            yield session
            self.end(session.session_id, status="completed")
        except Exception as e:
            self.end(session.session_id, status="error")
            raise
        finally:
            self.set_current(None)
    
    @asynccontextmanager
    async def session_context_async(
        self,
        agent_id: str,
        agent_name: str,
        metadata: Optional[Dict[str, Any]] = None
    ):
        """
        Async context manager for sessions — use with async agent workflows.

        Usage:
            async with agent.async_session():
                await some_async_tool()
        """
        session = self.create(agent_id, agent_name, metadata)
        self.set_current(session)
        try:
            yield session
            self.end(session.session_id, status="completed")
        except Exception:
            self.end(session.session_id, status="error")
            raise
        finally:
            self.set_current(None)

    def list_active(self) -> list:
        return [s for s in self._active_sessions.values() if s.is_active]
    
    def list_all(self, limit: int = 100) -> list:
        sessions = sorted(
            self._sessions.values(),
            key=lambda s: s.started_at,
            reverse=True
        )
        return sessions[:limit]


# Global session manager
session_manager = SessionManager()
