"""
JannaAuth SDK v0.3.1
Identity and Authentication for AI Agents

Features:
- Cryptographic Identity (Ed25519 key pairs)
- Challenge-Response Proofs
- Permission System with Enforcement
- Session Management
- JWT-like Tokens
- Secure Agent-to-Agent Handoffs
- Full Audit Logging
- CrewAI Integration
- LangChain Integration

Basic Usage:
    from jannaauth import Agent, AgentRegistry
    
    # Create an agent with permissions
    agent = Agent(
        name="DataAnalyst",
        permissions=["read:database", "write:reports"],
        owner="analytics@company.com"
    )
    
    # Use in a session
    with agent.session():
        # Actions are tracked and permission-checked
        process_data()
    
    # Create cryptographic proof
    proof = agent.create_proof("challenge")
    
    # Verify proof
    registry = AgentRegistry()
    registry.verify_proof(proof)

CrewAI Integration:
    from jannaauth.integrations.crewai import JannaCrewAgent, JannaCrew
    
    researcher = JannaCrewAgent(
        name="Researcher",
        permissions=["read:web"],
        role="Senior Researcher",
        goal="Find information"
    )

LangChain Integration:
    from jannaauth.integrations.langchain import JannaAuthCallback, protected_tool
    
    @protected_tool(requires="read:database")
    def search_database(query: str) -> str:
        return db.search(query)

Copyright (c) 2025 Janna Labs (IRAVEN GROUP UK)
MIT License
"""

__version__ = "0.3.1"
__author__ = "Janna Labs"
__license__ = "MIT"

# Core classes
from .agent import (
    Agent,
    AgentRegistry,
    AgentStatus,
    agent_registry
)

# Cryptographic proofs
from .crypto import (
    KeyPair,
    PublicKeyOnly,
    Proof,
    ProofGenerator,
    ProofVerifier,
    generate_challenge,
    CRYPTO_AVAILABLE
)

# Permissions
from .permissions import (
    Permission,
    PermissionAction,
    PermissionSet,
    PermissionChecker,
    protect,
    requires_permission
)

# Sessions
from .session import (
    Session,
    SessionManager,
    session_manager
)

# Tokens
from .token import TokenManager

# Audit logging
from .audit import (
    AuditLog,
    AuditEntry,
    ActionType,
    ActionStatus,
    audit_log
)

# Storage
from .storage import AgentStore

# Key store backends
from .keystore import (
    KeyStoreBackend,
    EnvVarKeyStore,
    VaultKeyStore,
    AWSSecretsKeyStore,
)

# Human approval workflows (v0.3.0)
from .approval import (
    ApprovalStatus,
    ApprovalRequest,
    ApprovalQueue,
    ApprovalGate,
    approval_queue,
)

# Handoffs
from .handoff import (
    Handoff,
    HandoffManager,
    create_handoff,
    receive_handoff
)

# Exceptions
from .exceptions import (
    JannaAuthError,
    AgentNotFoundError,
    AgentRevokedError,
    AgentSuspendedError,
    InvalidTokenError,
    TokenExpiredError,
    SessionError,
    NoActiveSessionError,
    PermissionError,
    PermissionDeniedError,
    InvalidPermissionError,
    CryptoError,
    InvalidProofError,
    InvalidSignatureError,
    ProofExpiredError,
    KeyPairError,
    HandoffError,
    InvalidRecipientError,
    HandoffVerificationError,
    ApprovalError,
    ApprovalPendingError,
    ApprovalRejectedError,
    ApprovalExpiredError,
    ApprovalNotFoundError,
)

__all__ = [
    # Version
    '__version__',
    '__author__',
    '__license__',
    
    # Core
    'Agent',
    'AgentRegistry',
    'AgentStatus',
    'agent_registry',
    'AgentStore',

    # Key store backends
    'KeyStoreBackend',
    'EnvVarKeyStore',
    'VaultKeyStore',
    'AWSSecretsKeyStore',

    # Approvals
    'ApprovalStatus',
    'ApprovalRequest',
    'ApprovalQueue',
    'ApprovalGate',
    'approval_queue',
    
    # Crypto
    'KeyPair',
    'PublicKeyOnly',
    'Proof',
    'ProofGenerator',
    'ProofVerifier',
    'generate_challenge',
    'CRYPTO_AVAILABLE',
    
    # Permissions
    'Permission',
    'PermissionAction',
    'PermissionSet',
    'PermissionChecker',
    'protect',
    'requires_permission',
    
    # Sessions
    'Session',
    'SessionManager',
    'session_manager',
    
    # Tokens
    'TokenManager',
    
    # Audit
    'AuditLog',
    'AuditEntry',
    'ActionType',
    'ActionStatus',
    'audit_log',
    
    # Handoffs
    'Handoff',
    'HandoffManager',
    'create_handoff',
    'receive_handoff',
    
    # Exceptions
    'JannaAuthError',
    'AgentNotFoundError',
    'AgentRevokedError',
    'AgentSuspendedError',
    'InvalidTokenError',
    'TokenExpiredError',
    'SessionError',
    'NoActiveSessionError',
    'PermissionError',
    'PermissionDeniedError',
    'InvalidPermissionError',
    'CryptoError',
    'InvalidProofError',
    'InvalidSignatureError',
    'ProofExpiredError',
    'KeyPairError',
    'HandoffError',
    'InvalidRecipientError',
    'HandoffVerificationError',

    # Approval exceptions
    'ApprovalError',
    'ApprovalPendingError',
    'ApprovalRejectedError',
    'ApprovalExpiredError',
    'ApprovalNotFoundError',
]
