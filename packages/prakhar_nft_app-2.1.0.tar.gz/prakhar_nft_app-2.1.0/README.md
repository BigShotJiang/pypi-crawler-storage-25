# My Dash App

Install:

pip install prakhar-nft-app

Run:

prakhar-nft-app