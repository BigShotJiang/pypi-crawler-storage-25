"""pytest file built from docs/custom-types.md"""


def test_code_15():
    from dataclasses import dataclass, field
    from json import JSONEncoder

    import numpy as np
    from dacite import Config
    from tomlkit import item as tomlitem, register_encoder

    from serde_dataclass import JsonDataclass, TomlDataclass, json_config, toml_config


    @register_encoder
    def encode_ndarray(obj, /, _parent=None, _sort_keys=False):
        if isinstance(obj, np.ndarray):
            return tomlitem(obj.tolist())
        raise TypeError(f"Unsupported type: {type(obj)!r}")


    class ArrayEncoder(JSONEncoder):
        def default(self, obj):
            if isinstance(obj, np.ndarray):
                return obj.tolist()
            return super().default(obj)


    array_hooks = Config(type_hooks={np.ndarray: np.array})


    @dataclass
    @json_config(ser=ArrayEncoder, de=array_hooks)
    @toml_config(de=array_hooks)
    class ArrayConfig(TomlDataclass, JsonDataclass):
        data: np.ndarray = field(metadata={"description": "Matrix values"})

    # Caution- no assertions.


def test_code_58():
    from dataclasses import dataclass

    from serde_dataclass import JsonDataclass


    @dataclass
    class Payload(JsonDataclass):
        name: str
        count: int


    payload = Payload(name="jobs", count=3)
    text = payload.to_json(indent=2)
    loaded = Payload.from_json(text)

    assert loaded == payload

    # Caution- no assertions.
