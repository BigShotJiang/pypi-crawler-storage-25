"""pytest file built from README.md"""


def test_code_33():
    from dataclasses import dataclass, field
    from enum import Enum
    from typing import Literal

    from serde_dataclass import TomlDataclass


    class Mode(str, Enum):
        DEV = "dev"
        PROD = "prod"


    @dataclass
    class Database:
        host: str = field(metadata={"description": "Database host"})
        port: int = field(default=5432, metadata={"description": "Database port"})


    @dataclass
    class AppConfig(TomlDataclass):
        """Application configuration"""

        app_name: str = field(
            default="demo",
            metadata={"description": "Application name", "toml": "app-name"},
        )
        log_level: Literal["debug", "info", "warning", "error"] = field(
            default="info",
            metadata={"description": "Logging verbosity", "toml": "log-level"},
        )
        mode: Mode = field(default=Mode.DEV, metadata={"description": "Runtime mode"})
        database: Database = field(
            default_factory=lambda: Database(host="localhost"),
            metadata={"description": "Database settings"},
        )


    cfg = AppConfig()
    text = cfg.to_toml()
    loaded = AppConfig.from_toml(text)

    assert loaded == cfg
    print(text)

    # Caution- no assertions.
