"""pytest file built from docs/api.md"""


def test_code_38():
    from dataclasses import dataclass, field

    from serde_dataclass import TomlDataclass, toml_config


    @dataclass
    @toml_config(root_comment="Application configuration")
    class Config(TomlDataclass):
        value: int = field(metadata={"description": "Example value"})

    # Caution- no assertions.


def test_code_73():
    from dataclasses import dataclass
    from json import JSONEncoder

    from serde_dataclass import JsonDataclass, json_config


    class CustomEncoder(JSONEncoder):
        pass


    @dataclass
    @json_config(ser=CustomEncoder)
    class Payload(JsonDataclass):
        name: str

    # Caution- no assertions.


def test_code_103():
    from typing import Any, Annotated, Callable

    TypeChecker = Callable[[Any, Annotated], None]

    # Caution- no assertions.


def test_code_111():
    from dataclasses import dataclass, field
    from typing import Annotated, Any

    from serde_dataclass import TomlDataclass, toml_config

    def positive_int_checker(value: Any, annotation: Annotated) -> None:
        if not isinstance(value, int) or value <= 0:
            raise ValueError(f"Expected a positive integer, got {value!r}")

    @dataclass
    @toml_config(typecheck_key="typecheck")
    class Config(TomlDataclass):
        value: int = field(default=1, metadata={"typecheck": positive_int_checker})

    cfg = Config(value=5)
    cfg.to_toml()  # This will succeed
    cfg.value = -1
    try:
        cfg.to_toml()  # This will raise a ValueError due to failed type check
    except ValueError as e:
        print(f"Type check failed as expected: {e}")

    # Caution- no assertions.
