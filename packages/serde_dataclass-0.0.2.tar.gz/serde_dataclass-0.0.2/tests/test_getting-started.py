"""pytest file built from docs/getting-started.md"""


def test_code_13():
    from dataclasses import dataclass

    from serde_dataclass import JsonDataclass, TomlDataclass


    @dataclass
    class Config(TomlDataclass, JsonDataclass):
        value: int

    # Caution- no assertions.


def test_code_34():
    from dataclasses import dataclass, field

    from serde_dataclass import TomlDataclass


    @dataclass
    class Config(TomlDataclass):
        retries: int = field(metadata={"description": "Number of retries"})
        log_level: str = field(metadata={"toml": "log-level"})

    # Caution- no assertions.


def test_code_83():
    from dataclasses import dataclass, field

    from serde_dataclass import TomlDataclass


    def positive(value, _annotation):
        if value <= 0:
            raise ValueError("Value must be positive")


    @dataclass
    class Limits(TomlDataclass):
        timeout: int = field(
            default=30,
            metadata={
                "description": "Timeout in seconds",
                "typecheck": positive,
            },
        )

    # Caution- no assertions.


def test_code_109():
    from dataclasses import dataclass

    from serde_dataclass import TomlDataclass, toml_config


    @dataclass
    @toml_config(root_comment="Example")
    class Config(TomlDataclass):
        value: int

    # Caution- no assertions.
