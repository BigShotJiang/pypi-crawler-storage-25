"""
AzerAI - Azərbaycan dilində qabaqcıl səsli AI asistent
Plugin əsaslı, çoxdilli AI asistent framework
"""

__version__ = "3.0.8"
__author__ = "AzStudio Dev"
__email__ = "info.azstudiodev@gmail.com"

from .AzerAI import Assistant
from .plugins import get_all_tools, get_plugin_info, get_plugin_prompts, get_plugin_updates

__all__ = [
    "Assistant",
    "get_all_tools", 
    "get_plugin_info",
    "get_plugin_prompts",
    "get_plugin_updates"
]
