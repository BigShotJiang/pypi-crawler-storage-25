# 🤖 AzerAI

**AzerAI** - Azərbaycan dilində qabaqcıl səsli AI asistent - Plugin əsaslı, çoxdilli AI framework.

## 🌟 Xüsusiyyətlər

- 🎤 **Səsli interfeys** - Real-time səsli danışıq
- 🇦🇿 **Azərbaycan dili** - Əsas dil Azərbaycan dilidir
- 🔌 **Plugin sistemi** - Genişlənəbilən plugin arxitekturası
- 💾 **Yaddaş** - Konuşma tarixçəsi və context
- 🎭 **Şəxsiyyət** - Dostlu və əyləncəli xarakter
- 🌍 **Çoxdilli** - 50+ dil dəstəyi
- 🚀 **Yüksək performans** - LiveKit ilə real-time əməliyyatlar

## 🚀 Quraşdırma

### Əsas quraşdırma
```bash
pip install AzerAI
```

### Bütün pluginlərlə birlikdə
```bash
pip install AzerAI[plugins]
```

### Əl ilə quraşdırma
```bash
git clone https://github.com/AzStudio-Dev/AzerAI.git
cd AzerAI
pip install -e .
```
## 🎯 İstifadə

### Console modu
```bash
AzerAI console
```

### Əmrlər
```bash
AzerAI console          # Konsol modunda işlə
AzerAI start             # Serveri başlad
AzerAI dev               # İnkişaf rejimi
AzerAI connect           # Qoşul
AzerAI download-files    # Faylları yüklə
```

### Python kodu ilə
```python
from azerai import Assistant  # AzerAI paketindən Assistant sinfini idxal edirik
from azerai.plugins import get_all_tools, get_plugin_info, get_plugin_prompts, get_plugin_updates # Pluginləri idxal edirik
from livekit.agents import cli, AgentSession, WorkerOptions, RoomInputOptions  # livekit agent modulları
from livekit.plugins import google, openai, silero, noise_cancellation  
# google → Google Realtime AI modeli (səsli cavab verən LLM)
# openai → OpenAI Realtime AI modeli (ChatGPT kimi işləyən model)
# silero → VAD (Voice Activity Detection) - istifadəçinin danışıb-danışmadığını müəyyən edir
# noise_cancellation → səsdəki küyü (noise) azaltmaq üçün istifadə olunur (mikrofon təmizləmə)

async def entrypoint(ctx):  # proqramın başlanğıc funksiyası (async)
    assistant = Assistant()  # Assistant obyektini yaradırıq
    plugin_info = get_plugin_info()  # Plugin məlumatlarını alırıq
    plugin_prompts = get_plugin_prompts()  # Plugin promptlarını alırıq
    plugin_updates = get_plugin_updates()  # Plugin yeniləmələrini alırıq
    all_tools = get_all_tools()  # Bütün toolları alırıq

    # Agent sessiyası yaradırıq
    session = AgentSession(
        vad=silero.VAD.load(), # İstifadəçinin danışıb-danışmadığını müəyyən edir
        llm=google.realtime.Realtime.Model(voice="Puck"),  # səsli AI modeli seçirik
        # və ya OpenAI modeli: llm=openai.realtime.RealtimeModel(voice="marin")
        tools=all_tools  # Bütün toolları əlavə edirik
    )

    # Əvvəlcə otağa qoşuluruq
    await ctx.connect()

    await session.start(
        room=ctx.room,
        agent=assistant,
        # Otaq giriş konfiqurasiyası
        room_input_options=RoomInputOptions(
            # Video dəstəyi aktiv et
            video_enabled=True,
            
            # LiveKit Cloud təkmilləşdirilmiş gürültü aradan qaldırma
            # - Əgər self-hosting istifadə edirsinizsə, bu parametri buraxın
            # - Telephony proqramları üçün ən yaxşı nəticə üçün `BVCTelephony` istifadə edin
            noise_cancellation=noise_cancellation.BVC(),
        ),
    )

    # Reminder plugin-ünə session referansını ver (əgər plugin mövcuddursa)
    try:
        from azerai_reminder.plugins.reminder.main import reminder_tools
        if reminder_tools is not None:
            reminder_tools.session_ref = session
            reminder_tools.loop_ref = __import__('asyncio').get_running_loop()
            print("[OK] Reminder plugin-ünə session referansı verildi")
        else:
            print("[NO] Reminder_tools None olduğu üçün session referansı verilmədi")
    except ImportError:
        pass
    
    # İlk cavabı başlat
    await session.generate_reply(
        instructions="Salam! Necə kömək edə bilərəm?"
    )

# proqramı işə salmaq üçün
if __name__ == "__main__":
    cli.run_app(
        WorkerOptions(entrypoint_fnc=entrypoint)  # entrypoint funksiyasını veririk
    )
```

### Python kodu ilə (Ayrı Yaddaşlı)
```python
from azerai import Assistant  # AzerAI paketindən Assistant sinfini idxal edirik
from azerai.plugins import get_all_tools, get_plugin_info, get_plugin_prompts, get_plugin_updates # Pluginləri idxal edirik
from azerai.memory import MemoryManager  # Yaddaş menecerini ayrıca idxal edirik
from livekit.agents import cli, AgentSession, WorkerOptions, RoomInputOptions  # livekit agent modulları
from livekit.plugins import google, openai, silero, noise_cancellation  
# google → Google Realtime AI modeli (səsli cavab verən LLM)
# openai → OpenAI Realtime AI modeli (ChatGPT kimi işləyən model)
# silero → VAD (Voice Activity Detection) - istifadəçinin danışıb-danışmadığını müəyyən edir
# noise_cancellation → səsdəki küyü (noise) azaltmaq üçün istifadə olunur (mikrofon təmizləmə)

async def entrypoint(ctx):  # proqramın başlanğıc funksiyası (async)
    assistant = Assistant()  # Əsas Assistant obyektini yaradırıq (yaddaşsız)
    plugin_info = get_plugin_info()  # Plugin məlumatlarını alırıq
    plugin_prompts = get_plugin_prompts()  # Plugin promptlarını alırıq
    plugin_updates = get_plugin_updates()  # Plugin yeniləmələrini alırıq
    all_tools = get_all_tools()  # Bütün toolları alırıq
    
    # Ayrı yaddaş meneceri yaradırıq
    memory = MemoryManager()
    
    # Agent sessiyası yaradırıq
    session = AgentSession(
        vad=silero.VAD.load(), # İstifadəçinin danışıb-danışmadığını müəyyən edir
        llm=google.realtime.RealtimeModel(voice="Puck"),  # səsli AI modeli seçirik
        # və ya OpenAI modeli: llm=openai.realtime.RealtimeModel(voice="marin")
        tools=all_tools  # Bütün toolları əlavə edirik
    )

    # Danışıqları izləmək üçün
    last_user_message = None

    @session.on("conversation_item_added")
    def on_conversation_item(event):
        nonlocal last_user_message
        message = event.item
        
        # İstifadəçi mesajını yadda saxla
        if message.role == "user" and message.text_content:
            last_user_message = message.text_content
        
        # Asistan cavabını və istifadəçi sualını yaddaşa yaz
        elif message.role == "assistant" and message.text_content and last_user_message:
            # Danışıq cütünü ayrı yaddaşda saxla
            memory.add_conversation(last_user_message, message.text_content)
            last_user_message = None

    # Yaddaş kontekstini əsas assistanta dinamik olaraq veririk
    original_instructions = assistant.instructions
    
    def update_instructions_with_memory():
        """Yaddaş konteksti ilə təlimatları yenilə"""
        memory_context = memory.get_memory_context()
        if memory_context:
            new_instructions = f"{memory_context}\n\n{original_instructions}"
            assistant.instructions = new_instructions
    
    # Sessiya event-lərində yaddaşı yenilə
    @session.on("user_turn_started")
    def on_user_turn_started(turn_ctx):
        update_instructions_with_memory()

    # Əvvəlcə otağa qoşuluruq
    await ctx.connect()

    await session.start(
        room=ctx.room,
        agent=assistant,
        # Otaq giriş konfiqurasiyası
        room_input_options=RoomInputOptions(
            # Video dəstəyi aktiv et
            video_enabled=True,
            
            # LiveKit Cloud təkmilləşdirilmiş gürültü aradan qaldırma
            # - Əgər self-hosting istifadə edirsinizsə, bu parametri buraxın
            # - Telephony proqramları üçün ən yaxşı nəticə üçün `BVCTelephony` istifadə edin
            noise_cancellation=noise_cancellation.BVC(),
        ),
    )

    # Reminder plugin-ünə session referansını ver (əgər plugin mövcuddursa)
    try:
        from azerai_reminder.plugins.reminder.main import reminder_tools
        if reminder_tools is not None:
            reminder_tools.session_ref = session
            reminder_tools.loop_ref = __import__('asyncio').get_running_loop()
            print("[OK] Reminder plugin-ünə session referansı verildi")
        else:
            print("[NO] Reminder_tools None olduğu üçün session referansı verilmədi")
    except ImportError:
        pass

    # İlk cavabı başlat
    await session.generate_reply(
        instructions=original_instructions
    )

# proqramı işə salmaq üçün
if __name__ == "__main__":
    cli.run_app(
        WorkerOptions(entrypoint_fnc=entrypoint)  # entrypoint funksiyasını veririk
    )
```

## 🌍 Dəstəklənən Dillər

- 🇦🇿 **Azərbaycan** (Əsas)
- 🇹🇷 **Türkçe**
- 🇬🇧 **English**
- 🇷🇺 **Русский**
- 🇩🇪 **Deutsch**
- 🇫🇷 **Français**
- 🇪🇸 **Español**
- Və 40+ digər dil

## ⚙️ Konfiqurasiya

`.env` faylı yaradın:
```env
LIVEKIT_API_KEY=your_api_key
LIVEKIT_API_SECRET=your_api_secret
LIVEKIT_URL=wss://your-livekit-server.com
GOOGLE_API_KEY=your_google_api_key
OPENAI_API_KEY=your_openai_api_key

# AI modeli seçimi (google və ya openai)
AI_PROVIDER=google
```

## 🔌 Plugin Yaratmaq

Yeni plugin yaratmaq üçün aşağıdakı addımları izləyin:

### 1. Plugin qovluğu yaradın
```bash
mkdir my_azerai_plugin
cd my_azerai_plugin
```

### 2. `pyproject.toml` faylı yaradın
```toml
[build-system]
requires = ["setuptools>=61.0", "wheel"]
build-backend = "setuptools.build_meta"

[project]
name = "azerai-my-plugin"
version = "1.0.0"
description = "My AzerAI Plugin"
readme = "README.md"
license = {text = "MIT"}
authors = [
    {name = "Your Name", email = "your.email@example.com"}
]
dependencies = [
    "livekit-agents"
]

[project.urls]
Homepage = "https://github.com/yourusername/azerai-my-plugin"
Repository = "https://github.com/yourusername/azerai-my-plugin.git"

[tool.setuptools.packages.find]
where = ["."]
include = ["azerai_my_plugin*"]

[tool.setuptools.package-data]
azerai_my_plugin = ["*.txt", "*.md"]
```

### 3. Plugin strukturunu yaradın
```
azerai_my_plugin/
├── azerai_my_plugin/
│   ├── __init__.py
│   └── plugins/
│       └── my_plugin/
│           ├── __init__.py
│           ├── main.py
│           ├── info.py
│           └── prompts.py
├── LICENSE
├── pyproject.toml
└── README.md
```

### 4. `__init__.py` faylını yaradın
```python
"""
My AzerAI Plugin
"""

__version__ = "1.0.0"
__author__ = "Your Name"
__email__ = "your.email@example.com"

from .plugins.my_plugin.main import my_function

__all__ = [
    "my_function"
]
```

### 5. Plugin kodu yazın
```python
# azerai_my_plugin/plugins/my_plugin/main.py
import logging
from livekit.agents import function_tool, RunContext

logger = logging.getLogger("my-plugin")

@function_tool()
async def my_function(
    ctx: RunContext,  # type: ignore
    param: str
) -> str:
    """
    Plugin funksiyası - parametrlə işləyir
    
    Args:
        param: Giriş parametri
    
    Returns:
        Str: Nəticə
    """
    try:
        result = f"Plugin işlədi: {param}"
        logger.info(f"Plugin nəticə: {result}")
        return result
    except Exception as e:
        logger.error(f"Plugin xətası: {e}")
        return f"Xəta baş verdi: {str(e)}"
```

### 6. `info.py` faylını yaradın
```python
"""
Plugin məlumatları
"""

__version__ = "1.0.0"
__author__ = "Your Name"
__email__ = "your.email@example.com"
__description__ = "My AzerAI Plugin"

PLUGIN_INFO = {
    "name": "azerai-my-plugin",
    "version": __version__,
    "author": __author__,
    "email": __email__,
    "description": __description__,
    "category": "utility",
    "language": "az",
    "functions": [
        "my_function"
    ],
    "capabilities": [
        "Parametrlə işləmə",
        "Loglama",
        "Xəta idarəsi"
    ],
    "dependencies": [
        "livekit-agents"
    ],
    "tags": ["azerai", "plugin", "utility"]
}
```

### 7. `prompts.py` faylını yaradın
```python
"""
Plugin təlimatları
"""

PLUGIN_PROMPT = """
My Plugin Capability:
You can use my_function to process parameters and return results.

Available functions:
- my_function(param) - Processes the given parameter

When users need to process text or data, use this function.

Examples:
- "Test et" -> Use my_function("Test")
- "Məlumat işlə" -> Use my_function("məlumat")

Always provide responses in Azerbaijani language unless specifically asked otherwise.
"""
```

### 8. README.md dosyası yaradın
```markdown
# My AzerAI Plugin

My custom plugin for AzerAI.

## Lisenziya
MIT License
```

### 9. LICENSE faylı yaradın
```text
MIT License

Copyright (c) 2026 Your Name

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

### 10. Test edin
```bash
# Yerli quraşdırma
pip install -e .

# Test
python -c "from azerai_my_plugin import my_function; print(my_function('test'))"
```

### 11. Yayımlayın
```bash
# Build
python -m build

# PyPI-ə yüklə
python -m twine upload dist/*
```



### 12. 📦 Plugin Quraşdırma
```bash
pip install azerai-my-plugin
```

### 🔧 Lokal Plugin Quraşdırma
Əgər plugini yerli olaraq qurmaq istəyirsinizsə:

1. **Plugins qovluğu yaradın:**
```bash
mkdir plugins
cd plugins
```

2. **Plugini köçürün:**
```bash
# Plugin qovluğunu plugins içərinə köçürün
cp -r /path/to/my_azerai_plugin .
```

3. **Yerli quraşdırma:**
```bash
cd my_azerai_plugin
pip install -e .
```

4. **AzerAI-ni yenidən başladın:**
```bash
AzerAI console
# Plugin avtomatik aşkar ediləcək
```

**🎯 Nəticə:** Artıq hazırdır! Plugininiz lokal olaraq işləyəcək.

### İstifadə
Plugin avtomatik olaraq AzerAI tərəfindən aşkar edilir.

### 🔍 Plugin Yoxlaması
Plugin düzgün qurulubsa, AzerAI onu avtomatik aşkar edəcək:
```bash
AzerAI
# Plugin siyahısında plugininiz görünməlidir
```

### 💡 İpucları
- Plugin adı `azerai-` prefiksi ilə başlamalıdır
- Bütün funksiyalar `@function_tool()` dekoratoru ilə işarələnməlidir
- Hər plugin `info.py` və `prompts.py` fayllarına malik olmalıdır
- Azərbaycan dilində təsvirlər istifadə edin

## 🤝 İştirak

1. Fork edin
2. Feature branch yaradın (`git checkout -b feature/amazing-feature`)
3. Commit edin (`git commit -m 'Add amazing feature'`)
4. Push edin (`git push origin feature/amazing-feature`)
5. Pull Request yaradın

## 📄 Lisenziya

Bu layihə MIT Lisenziyası ilə lisenziyalaşdırılıb - [LICENSE](https://github.com/AzStudioDev/AzerAI/blob/main/LICENSE) faylına baxın.

## 🙏 Təşəkkürlər

- [Python](https://python.org/) - Proqramlaşdırma dili
- [LiveKit](https://livekit.io/) - Real-time audio/video framework
- [Google](https://ai.google.dev/) - AI modeli
- [OpenAI](https://openai.com/) - AI modeli
- Azərbaycan icması - Dəstək və tövsiyələr

## 📞 Əlaqə

- **Müəllif:** AzStudio Dev
- **Email:** info.azstudiodev@gmail.com
- **GitHub:** https://github.com/AzStudioDev/AzerAI
- **PyPI:** https://pypi.org/project/AzerAI/

---

**🇦🇿 Azərbaycanın ilk tam plugin ekosistemli AI asistenti!** 🚀
