"""Shared utilities for QuantumRAG."""
