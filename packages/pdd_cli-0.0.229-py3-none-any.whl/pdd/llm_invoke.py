# Corrected code_under_test (llm_invoke.py)
# Added optional debugging prints in _select_model_candidates

import copy
import getpass
import os
import pandas as pd
import litellm
import logging # ADDED FOR DETAILED LOGGING
import importlib.resources
import re
import socket
import subprocess
import sys
import traceback
import urllib.request
import uuid
from datetime import datetime, timezone
from litellm.caching.caching import Cache  # Fix for LiteLLM v1.75.5+

# --- Configure Standard Python Logging ---
logger = logging.getLogger("pdd.llm_invoke")

# Optional lightweight trace for core dumps (best-effort).
try:
    from .core.llm_trace import record_llm_pair as _record_llm_pair
except Exception:  # pragma: no cover
    _record_llm_pair = None  # type: ignore

# Environment variable to control log level
PDD_LOG_LEVEL = os.getenv("PDD_LOG_LEVEL", "INFO")
PRODUCTION_MODE = os.getenv("PDD_ENVIRONMENT") == "production"

# Set default level based on environment
if PRODUCTION_MODE:
    logger.setLevel(logging.WARNING)
else:
    logger.setLevel(getattr(logging, PDD_LOG_LEVEL, logging.INFO))

# Configure LiteLLM logger separately
litellm_logger = logging.getLogger("litellm")
litellm_log_level = os.getenv("LITELLM_LOG_LEVEL", "WARNING" if PRODUCTION_MODE else "INFO")
litellm_logger.setLevel(getattr(logging, litellm_log_level, logging.WARNING))

# Suppress LiteLLM debug messages and error info that includes "Give Feedback / Get Help"
# This prevents LiteLLM from printing these messages before raising exceptions
try:
    litellm.set_verbose = False
    litellm.suppress_debug_info = True
except Exception:
    # If these attributes don't exist in this LiteLLM version, continue silently
    pass

# Ensure LiteLLM drops provider-unsupported params instead of erroring
# This prevents failures like UnsupportedParamsError for OpenAI gpt-5-* when
# passing generic params (e.g., reasoning_effort) not accepted by that API path.
try:
    _drop_params_env = os.getenv("LITELLM_DROP_PARAMS", "true")
    litellm.drop_params = str(_drop_params_env).lower() in ("1", "true", "yes", "on")
except Exception:
    # Be conservative: default to True even if env parsing fails
    litellm.drop_params = True

# Add a console handler if none exists
if not logger.handlers:
    console_handler = logging.StreamHandler()
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)
    
    # Only add handler to litellm logger if it doesn't have any
    if not litellm_logger.handlers:
        litellm_logger.addHandler(console_handler)

# Function to set up file logging if needed
def setup_file_logging(log_file_path=None):
    """Configure rotating file handler for logging"""
    if not log_file_path:
        return
        
    try:
        from logging.handlers import RotatingFileHandler
        file_handler = RotatingFileHandler(
            log_file_path, maxBytes=10*1024*1024, backupCount=5
        )
        file_handler.setFormatter(logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        ))
        logger.addHandler(file_handler)
        litellm_logger.addHandler(file_handler)
        logger.info(f"File logging configured to: {log_file_path}")
    except Exception as e:
        logger.warning(f"Failed to set up file logging: {e}")

# Function to set verbose logging
def set_verbose_logging(verbose=False):
    """Set verbose logging based on flag or environment variable"""
    want_verbose = bool(verbose) or os.getenv("PDD_VERBOSE_LOGGING") == "1"

    # Python logging levels
    if want_verbose:
        logger.setLevel(logging.DEBUG)
        litellm_logger.setLevel(logging.DEBUG)
    else:
        # Restore defaults
        if PRODUCTION_MODE:
            logger.setLevel(logging.WARNING)
        else:
            logger.setLevel(getattr(logging, PDD_LOG_LEVEL, logging.INFO))
        litellm_logger.setLevel(getattr(logging, litellm_log_level, logging.WARNING))

    # LiteLLM internal verbosity/debug info
    # By default we suppress the noisy "Give Feedback / Get Help" debug banner.
    # When PDD is run with --verbose, re-enable LiteLLM verbose+debug outputs.
    try:
        if hasattr(litellm, "set_verbose"):
            litellm.set_verbose = want_verbose
        if hasattr(litellm, "suppress_debug_info"):
            litellm.suppress_debug_info = not want_verbose
    except Exception:
        # If these attributes don't exist in this LiteLLM version, ignore.
        pass

    if want_verbose:
        logger.debug("Verbose logging enabled (including LiteLLM debug output)")


def set_quiet_logging() -> None:
    """Suppress non-error logging for quiet mode."""
    logger.setLevel(logging.ERROR)
    litellm_logger.setLevel(logging.ERROR)
    try:
        if hasattr(litellm, "set_verbose"):
            litellm.set_verbose = False
        if hasattr(litellm, "suppress_debug_info"):
            litellm.suppress_debug_info = True
    except Exception:
        pass


# Honor process-level quiet mode as early as possible.
if os.getenv("PDD_QUIET") == "1":
    set_quiet_logging()
    
# --- End Logging Configuration ---

import json
# from rich import print as rprint # Replaced with logger
from dotenv import load_dotenv
from pathlib import Path
from typing import Optional, Dict, List, Any, Type, Union, Tuple
from pydantic import BaseModel, ValidationError
import openai  # Import openai for exception handling as LiteLLM maps to its types
import warnings
import time as time_module # Alias to avoid conflict with 'time' parameter
from pdd.path_resolution import get_default_resolver
from pdd.server.token_counter import get_context_limit

# Opt-in to future pandas behavior regarding downcasting
try:
    pd.set_option('future.no_silent_downcasting', True)
except pd._config.config.OptionError:
    # Skip if option doesn't exist in older pandas versions
    pass


# --- Custom Exceptions ---

class SchemaValidationError(Exception):
    """Raised when LLM response fails Pydantic/JSON schema validation.

    This exception triggers model fallback when caught at the outer exception
    handler level, allowing the next candidate model to be tried.

    Issue #168: Previously, validation errors only logged an error and continued
    to the next batch item, never triggering model fallback.
    """

    def __init__(self, message: str, raw_response: Any = None, item_index: int = 0):
        super().__init__(message)
        self.raw_response = raw_response
        self.item_index = item_index


class CloudFallbackError(Exception):
    """Raised when cloud execution fails and should fall back to local.

    This exception is caught internally and triggers fallback to local execution
    when cloud is unavailable (network errors, timeouts, auth failures).
    """
    pass


class CloudInvocationError(Exception):
    """Raised when cloud invocation fails with a non-recoverable error.

    This exception indicates a cloud error that should not fall back to local,
    such as validation errors returned by the cloud endpoint.
    """
    pass


class InsufficientCreditsError(Exception):
    """Raised when user has insufficient credits for cloud execution.

    This exception is raised when the cloud returns 402 (Payment Required)
    and should NOT fall back to local execution - the user needs to know.
    """
    pass


# --- Cloud Execution Helpers ---

def _ensure_all_properties_required(schema: Dict[str, Any]) -> Dict[str, Any]:
    """Recursively ensure ALL properties are in the required array (OpenAI strict mode).

    OpenAI's strict mode requires that all properties at ALL levels of a JSON schema
    are listed in the 'required' array. Pydantic's model_json_schema() only includes
    fields without default values in 'required', which causes OpenAI to reject the schema.

    This function walks the entire schema tree and ensures every object type has all
    its properties in the 'required' array.

    Args:
        schema: A JSON schema dictionary

    Returns:
        The schema with all properties added to 'required' at all nesting levels
    """
    if not isinstance(schema, dict):
        return schema

    # If this is an object with properties, make all properties required
    if schema.get('type') == 'object' and 'properties' in schema:
        schema['required'] = list(schema['properties'].keys())
        # Recurse into each property
        for prop_schema in schema['properties'].values():
            _ensure_all_properties_required(prop_schema)

    # Handle array items
    if schema.get('type') == 'array' and 'items' in schema:
        _ensure_all_properties_required(schema['items'])

    # Handle anyOf/oneOf/allOf
    for key in ('anyOf', 'oneOf', 'allOf'):
        if key in schema:
            for sub_schema in schema[key]:
                _ensure_all_properties_required(sub_schema)

    # Handle $defs
    if '$defs' in schema:
        for def_schema in schema['$defs'].values():
            _ensure_all_properties_required(def_schema)

    return schema


def _add_additional_properties_false(schema: Dict[str, Any]) -> Dict[str, Any]:
    """Recursively add additionalProperties: false to all object schemas.

    OpenAI's strict mode requires additionalProperties: false on ALL object
    schemas, including nested ones. This function walks the schema tree and
    adds the property to every object type.

    Args:
        schema: A JSON schema dictionary

    Returns:
        The schema with additionalProperties: false on all objects
    """
    if not isinstance(schema, dict):
        return schema

    # If this is an object type, add additionalProperties: false
    if schema.get('type') == 'object':
        schema['additionalProperties'] = False
        # Recursively process properties
        if 'properties' in schema:
            for prop_name, prop_schema in schema['properties'].items():
                _add_additional_properties_false(prop_schema)

    # Handle arrays - process items schema
    if schema.get('type') == 'array' and 'items' in schema:
        _add_additional_properties_false(schema['items'])

    # Handle anyOf, oneOf, allOf
    for key in ('anyOf', 'oneOf', 'allOf'):
        if key in schema:
            for sub_schema in schema[key]:
                _add_additional_properties_false(sub_schema)

    # Handle $defs (Pydantic's reference definitions)
    if '$defs' in schema:
        for def_name, def_schema in schema['$defs'].items():
            _add_additional_properties_false(def_schema)

    return schema


def _pydantic_to_json_schema(pydantic_class: Type[BaseModel]) -> Dict[str, Any]:
    """Convert a Pydantic model class to JSON Schema for cloud transport.

    Args:
        pydantic_class: A Pydantic BaseModel subclass

    Returns:
        JSON Schema dictionary that can be serialized and sent to cloud
    """
    schema = pydantic_class.model_json_schema()
    # Ensure all properties are in required array (OpenAI strict mode requirement)
    _ensure_all_properties_required(schema)
    # Include class name for debugging/logging purposes
    schema['__pydantic_class_name__'] = pydantic_class.__name__
    return schema


def _unwrap_parameter_envelope(obj: Any) -> Any:
    """Unwrap Vertex AI Anthropic's tool-call envelope.

    Vertex AI serves Anthropic structured outputs through tool-calling, which
    returns the schema fields wrapped as ``{"parameter": {<schema fields>}}``.
    The validators below gate this unwrap so it never silently reshapes a
    legitimate caller schema that itself accepts a top-level ``parameter`` key.
    Non-matching inputs are returned unchanged.
    """
    if (
        isinstance(obj, dict)
        and len(obj) == 1
        and "parameter" in obj
        and isinstance(obj["parameter"], dict)
    ):
        return obj["parameter"]
    return obj


def _pydantic_schema_accepts_parameter_key(cls: Type[BaseModel]) -> bool:
    """Return True if ``cls`` could validate a top-level ``"parameter"`` key.

    Walks declared fields and checks the field name, ``Field(alias=...)``, and
    ``Field(validation_alias=...)`` (string, ``AliasChoices``, or first segment
    of ``AliasPath``). When any of those equals ``"parameter"``, the envelope
    unwrap must be skipped — otherwise a payload like
    ``{"parameter": {"parameter": "inner"}}`` could be silently reshaped.
    """
    try:
        from pydantic import AliasChoices, AliasPath
    except ImportError:  # pragma: no cover — pydantic is a hard dep
        AliasChoices = AliasPath = None  # type: ignore

    def _path_first_is_parameter(path_obj: Any) -> bool:
        if AliasPath is None or not isinstance(path_obj, AliasPath):
            return False
        path = getattr(path_obj, "path", None)
        return bool(path) and path[0] == "parameter"

    for name, info in cls.model_fields.items():
        if name == "parameter":
            return True
        if getattr(info, "alias", None) == "parameter":
            return True
        va = getattr(info, "validation_alias", None)
        if va is None:
            continue
        if isinstance(va, str):
            if va == "parameter":
                return True
            continue
        if _path_first_is_parameter(va):
            return True
        if AliasChoices is not None and isinstance(va, AliasChoices):
            for choice in getattr(va, "choices", ()):
                if isinstance(choice, str) and choice == "parameter":
                    return True
                if _path_first_is_parameter(choice):
                    return True
    return False


def _jsonschema_eligible_for_envelope_unwrap(schema: Any) -> bool:
    """Return True if ``schema`` is an explicit object schema safe to unwrap into.

    Greg's review on PR #1365: only unwrap when the caller's schema is an
    explicit object whose top-level ``properties`` map exists and does not
    declare ``parameter``. Composed (``allOf``/``anyOf``/``oneOf``/``$ref``)
    or otherwise flexible (no top-level ``properties``) schemas are skipped
    rather than risk silently reshaping a payload that the composed schema
    might accept after unwrap.
    """
    if not isinstance(schema, dict):
        return False
    for composition_key in ("allOf", "anyOf", "oneOf", "$ref"):
        if composition_key in schema:
            return False
    properties = schema.get("properties")
    if not isinstance(properties, dict):
        return False
    return "parameter" not in properties


def _validate_pydantic_with_unwrap(
    payload: Any,
    pydantic_class: Type[BaseModel],
) -> BaseModel:
    """Validate ``payload`` against ``pydantic_class`` with envelope-unwrap fallback.

    Tries direct validation first. On ``ValidationError``, retries once after
    unwrapping a ``{"parameter": {...}}`` envelope. The original error is
    re-raised if both attempts fail, so existing diagnostics stay accurate.

    Gating (PR #1365 review): if ``pydantic_class`` could validate a
    top-level ``parameter`` key — by field name, ``Field(alias=...)``, or
    ``Field(validation_alias=...)`` (string, ``AliasChoices``, or first
    segment of ``AliasPath``) — the unwrap retry would silently reshape
    legitimate user payloads (e.g. ``{"parameter": {"parameter": "x"}}``
    would be accepted as ``{"parameter": "x"}``). Skip the unwrap branch in
    that case and let direct-validation errors propagate unchanged.
    """
    schema_uses_parameter = _pydantic_schema_accepts_parameter_key(pydantic_class)
    if isinstance(payload, str):
        try:
            return pydantic_class.model_validate_json(payload)
        except ValidationError as original_err:
            if schema_uses_parameter:
                raise
            try:
                obj = json.loads(payload)
            except (json.JSONDecodeError, ValueError):
                raise original_err
            unwrapped = _unwrap_parameter_envelope(obj)
            if unwrapped is obj:
                raise original_err
            try:
                return pydantic_class.model_validate(unwrapped)
            except ValidationError:
                raise original_err
    if isinstance(payload, dict):
        try:
            return pydantic_class.model_validate(payload)
        except ValidationError as original_err:
            if schema_uses_parameter:
                raise
            unwrapped = _unwrap_parameter_envelope(payload)
            if unwrapped is payload:
                raise original_err
            try:
                return pydantic_class.model_validate(unwrapped)
            except ValidationError:
                raise original_err
    if isinstance(payload, pydantic_class):
        return payload
    return pydantic_class.model_validate(payload)


def _validate_jsonschema_with_unwrap(
    instance: Any,
    schema: Dict[str, Any],
) -> Any:
    """Validate ``instance`` against a raw ``output_schema`` with envelope-unwrap fallback.

    Mirrors ``_validate_pydantic_with_unwrap`` for the ``output_schema``/jsonschema
    code path: tries direct validation first; on ``jsonschema.ValidationError``,
    retries once after stripping a single-key ``{"parameter": {...}}`` envelope.
    Vertex AI Anthropic serves structured outputs through tool-calling, and the
    same envelope shape reaches the jsonschema branch when callers pass
    ``output_schema`` instead of ``output_pydantic``. The original error is
    re-raised on second failure so diagnostics keep pointing at real schema
    fields, never at the synthetic ``parameter`` wrapper.

    Returns the validated payload — either ``instance`` itself when direct
    validation succeeds, or the unwrapped inner dict when the envelope-unwrap
    retry succeeds. Callers MUST use the returned value for any downstream
    serialization; using the original wrapped ``instance`` would leak the
    ``{"parameter": {...}}`` envelope into the caller's response shape (see
    PR #1365 review pass 3).

    Gating (PR #1365 review): unwrap only when ``schema`` is an explicit
    object schema whose top-level ``properties`` map exists and does not
    declare ``parameter``. Composed (``allOf``/``anyOf``/``oneOf``/``$ref``)
    or otherwise flexible schemas (e.g. ``additionalProperties`` without
    explicit ``properties``) are skipped rather than risk silently reshaping
    a payload the composed schema might accept after unwrap.

    Raises ``jsonschema.ValidationError`` (the original) if neither form
    validates. Raises ``ImportError`` if ``jsonschema`` is not installed.
    """
    import jsonschema
    eligible = _jsonschema_eligible_for_envelope_unwrap(schema)
    try:
        jsonschema.validate(instance=instance, schema=schema)
        return instance
    except jsonschema.ValidationError as original_err:
        if not eligible or not isinstance(instance, dict):
            raise
        unwrapped = _unwrap_parameter_envelope(instance)
        if unwrapped is instance:
            raise
        try:
            jsonschema.validate(instance=unwrapped, schema=schema)
            return unwrapped
        except jsonschema.ValidationError:
            raise original_err


def _validate_with_pydantic(
    result: Any,
    pydantic_class: Type[BaseModel]
) -> BaseModel:
    """Validate cloud response using original Pydantic class.

    Args:
        result: The result from cloud (dict or JSON string)
        pydantic_class: The Pydantic model to validate against

    Returns:
        Validated Pydantic model instance

    Raises:
        ValidationError: If validation fails
    """
    if isinstance(result, dict) or isinstance(result, str):
        return _validate_pydantic_with_unwrap(result, pydantic_class)
    elif isinstance(result, pydantic_class):
        # Already validated
        return result
    raise ValueError(f"Cannot validate result type {type(result)} with Pydantic model")


def _llm_invoke_cloud(
    prompt: Optional[str],
    input_json: Optional[Union[Dict[str, Any], List[Dict[str, Any]]]],
    strength: float,
    temperature: float,
    verbose: bool,
    output_pydantic: Optional[Type[BaseModel]],
    output_schema: Optional[Dict[str, Any]],
    time: float,
    use_batch_mode: bool,
    messages: Optional[Union[List[Dict[str, str]], List[List[Dict[str, str]]]]],
    language: Optional[str],
) -> Dict[str, Any]:
    """Execute llm_invoke via cloud endpoint.

    Args:
        All parameters match llm_invoke signature

    Returns:
        Dictionary with 'result', 'cost', 'model_name', 'thinking_output'

    Raises:
        CloudFallbackError: For recoverable errors (network, timeout, auth)
        InsufficientCreditsError: For 402 Payment Required
        CloudInvocationError: For non-recoverable cloud errors
    """
    import requests
    from rich.console import Console

    # Lazy import to avoid circular dependency
    from pdd.core.cloud import CloudConfig, get_cloud_request_timeout

    console = Console()

    # Get JWT token
    jwt_token = CloudConfig.get_jwt_token(verbose=verbose)
    if not jwt_token:
        raise CloudFallbackError("Could not authenticate with cloud")

    # Prepare payload
    payload: Dict[str, Any] = {
        "strength": strength,
        "temperature": temperature,
        "time": time,
        "verbose": verbose,
        "useBatchMode": use_batch_mode,
    }

    if language:
        payload["language"] = language

    # Add prompt/messages
    if messages:
        payload["messages"] = messages
    else:
        payload["prompt"] = prompt
        payload["inputJson"] = input_json

    # Handle output schema
    if output_pydantic:
        payload["outputSchema"] = _pydantic_to_json_schema(output_pydantic)
    elif output_schema:
        payload["outputSchema"] = output_schema

    # Make request
    headers = {
        "Authorization": f"Bearer {jwt_token}",
        "Content-Type": "application/json"
    }

    cloud_url = CloudConfig.get_endpoint_url("llmInvoke")

    if verbose:
        logger.debug(f"Cloud llm_invoke request to: {cloud_url}")

    try:
        response = requests.post(
            cloud_url,
            json=payload,
            headers=headers,
            timeout=get_cloud_request_timeout(),
        )

        if response.status_code == 200:
            data = response.json()
            result = data.get("result")
            # Best-effort trace: store the final prompt/messages and raw cloud "result".
            if _record_llm_pair is not None:
                try:
                    trace_prompt = payload.get("messages") if payload.get("messages") is not None else {
                        "prompt": payload.get("prompt"),
                        "inputJson": payload.get("inputJson"),
                    }
                    _record_llm_pair(
                        prompt=trace_prompt,
                        response=result,
                        model=str(data.get("modelName", "cloud_model")),
                    )
                except Exception:
                    pass

            # Validate with Pydantic if specified
            if output_pydantic and result:
                try:
                    result = _validate_with_pydantic(result, output_pydantic)
                except (ValidationError, ValueError) as e:
                    logger.warning(f"Cloud response validation failed: {e}")
                    # Return raw result if validation fails
                    pass

            return {
                "result": result,
                "cost": data.get("totalCost", 0.0),
                "model_name": data.get("modelName", "cloud_model"),
                "thinking_output": data.get("thinkingOutput"),
            }

        elif response.status_code == 402:
            error_msg = response.json().get("error", "Insufficient credits")
            raise InsufficientCreditsError(error_msg)

        elif response.status_code in (401, 403):
            # Clear stale JWT cache to prevent repeated failures
            try:
                from pdd.auth_service import clear_jwt_cache
                clear_jwt_cache()
            except Exception:
                pass  # Don't fail if cache clearing fails

            server_error = response.json().get("error", "")
            error_msg = (
                f"Authentication expired ({server_error or response.status_code}). "
                "Please re-authenticate with: pdd auth logout && pdd auth login"
            )
            raise CloudFallbackError(error_msg)

        elif response.status_code >= 500:
            error_msg = response.json().get("error", f"Server error ({response.status_code})")
            raise CloudFallbackError(error_msg)

        else:
            error_msg = response.json().get("error", f"HTTP {response.status_code}")
            raise CloudInvocationError(f"Cloud llm_invoke failed: {error_msg}")

    except requests.exceptions.Timeout:
        raise CloudFallbackError("Cloud request timed out")
    except requests.exceptions.ConnectionError as e:
        raise CloudFallbackError(f"Cloud connection failed: {e}")
    except requests.exceptions.RequestException as e:
        raise CloudFallbackError(f"Cloud request failed: {e}")


def _is_wsl_environment() -> bool:
    """
    Detect if we're running in WSL (Windows Subsystem for Linux) environment.
    
    Returns:
        True if running in WSL, False otherwise
    """
    try:
        # Check for WSL-specific indicators
        if os.path.exists('/proc/version'):
            with open('/proc/version', 'r') as f:
                version_info = f.read().lower()
                return 'microsoft' in version_info or 'wsl' in version_info
        
        # Alternative check: WSL_DISTRO_NAME environment variable
        if os.getenv('WSL_DISTRO_NAME'):
            return True
            
        # Check for Windows-style paths in PATH
        path_env = os.getenv('PATH', '')
        return '/mnt/c/' in path_env.lower()
        
    except Exception:
        return False


def _openai_responses_supports_response_format() -> bool:
    """Detect if current OpenAI Python SDK supports `response_format` on Responses.create.

    Returns True if the installed SDK exposes a `response_format` parameter on
    `openai.resources.responses.Responses.create`, else False. This avoids
    sending unsupported kwargs and triggering TypeError at runtime.
    """
    try:
        import inspect
        from openai.resources.responses import Responses
        sig = inspect.signature(Responses.create)
        return "response_format" in sig.parameters
    except Exception:
        return False


def _get_environment_info() -> Dict[str, str]:
    """
    Get environment information for debugging and error reporting.
    
    Returns:
        Dictionary containing environment details
    """
    import platform
    
    info = {
        'platform': platform.system(),
        'platform_release': platform.release(),
        'platform_version': platform.version(),
        'architecture': platform.machine(),
        'is_wsl': str(_is_wsl_environment()),
        'python_version': platform.python_version(),
    }
    
    # Add WSL-specific information
    if _is_wsl_environment():
        info['wsl_distro'] = os.getenv('WSL_DISTRO_NAME', 'unknown')
        info['wsl_interop'] = os.getenv('WSL_INTEROP', 'not_set')
    
    return info

# <<< SET LITELLM DEBUG LOGGING >>>
# os.environ['LITELLM_LOG'] = 'DEBUG' # Keep commented out unless debugging LiteLLM itself

LLM_CALL_TIMEOUT = int(os.getenv("LLM_CALL_TIMEOUT", "600"))  # seconds per LLM API call

# --- Constants and Configuration ---

# Determine project root: use PathResolver to ignore package-root PDD_PATH values.
PDD_PATH_ENV = os.getenv("PDD_PATH")
if PDD_PATH_ENV:
    try:
        _path_from_env = Path(PDD_PATH_ENV).expanduser().resolve()
        if not _path_from_env.is_dir():
            warnings.warn(
                f"PDD_PATH environment variable ('{PDD_PATH_ENV}') is set but not a valid directory. Attempting auto-detection."
            )
    except Exception as e:
        warnings.warn(f"Error validating PDD_PATH environment variable: {e}")

resolver = get_default_resolver()
PROJECT_ROOT = resolver.resolve_project_root()
PROJECT_ROOT_FROM_ENV = resolver.pdd_path_env is not None and PROJECT_ROOT == resolver.pdd_path_env
logger.debug(f"Using PROJECT_ROOT: {PROJECT_ROOT}")


# ENV_PATH is set after _is_env_path_package_dir is defined (see below)

# --- Determine LLM_MODEL_CSV_PATH ---
# Prioritize ~/.pdd/llm_model.csv, then a project .pdd from the current CWD,
# then PROJECT_ROOT (which may be set from PDD_PATH), else fall back to package.
user_pdd_dir = Path.home() / ".pdd"
user_model_csv_path = user_pdd_dir / "llm_model.csv"

def _detect_project_root_from_cwd(max_levels: int = 5) -> Path:
    """Search upwards from the current working directory for common project markers.

    This intentionally ignores PDD_PATH to support CLI invocations that set
    PDD_PATH to the installed package location. We want to honor a real project
    checkout's .pdd/llm_model.csv when running inside it.
    """
    try:
        current_dir = Path.cwd().resolve()
        for _ in range(max_levels):
            if (
                (current_dir / ".git").exists()
                or (current_dir / "pyproject.toml").exists()
                or (current_dir / "data").is_dir()
                or (current_dir / ".env").exists()
            ):
                return current_dir
            parent = current_dir.parent
            if parent == current_dir:
                break
            current_dir = parent
    except Exception:
        pass
    return Path.cwd().resolve()

# Resolve candidates
project_root_from_cwd = _detect_project_root_from_cwd()
project_csv_from_cwd = project_root_from_cwd / ".pdd" / "llm_model.csv"
project_csv_from_env = PROJECT_ROOT / ".pdd" / "llm_model.csv"

# Detect whether PDD_PATH points to the installed package directory. If so,
# don't prioritize it over the real project from CWD.
try:
    _installed_pkg_root = importlib.resources.files('pdd')
    # importlib.resources.files returns a Traversable; get a FS path string if possible
    try:
        _installed_pkg_root_path = Path(str(_installed_pkg_root))
    except Exception:
        _installed_pkg_root_path = None
except Exception:
    _installed_pkg_root_path = None

def _is_env_path_package_dir(env_path: Path) -> bool:
    try:
        if _installed_pkg_root_path is None:
            return False
        env_path = env_path.resolve()
        pkg_path = _installed_pkg_root_path.resolve()
        # Treat equal or subpath as package dir
        return env_path == pkg_path or str(env_path).startswith(str(pkg_path))
    except Exception:
        return False

# ENV_PATH: Use CWD-based project root when PDD_PATH points to package directory
# This ensures .env is written to the user's project, not the installed package location
if _is_env_path_package_dir(PROJECT_ROOT):
    ENV_PATH = project_root_from_cwd / ".env"
    logger.debug(f"PDD_PATH points to package; using ENV_PATH from CWD: {ENV_PATH}")
else:
    ENV_PATH = PROJECT_ROOT / ".env"

# Selection order
if user_model_csv_path.is_file():
    LLM_MODEL_CSV_PATH = user_model_csv_path
    logger.debug(f"Using user-specific LLM model CSV: {LLM_MODEL_CSV_PATH}")
elif PROJECT_ROOT_FROM_ENV and project_csv_from_env.is_file():
    # Honor an explicitly-set PDD_PATH pointing to a real project directory
    LLM_MODEL_CSV_PATH = project_csv_from_env
    logger.debug(f"Using project-specific LLM model CSV (from PDD_PATH): {LLM_MODEL_CSV_PATH}")
elif project_csv_from_cwd.is_file():
    # Otherwise, prefer the project relative to the current working directory
    LLM_MODEL_CSV_PATH = project_csv_from_cwd
    logger.debug(f"Using project-specific LLM model CSV (from CWD): {LLM_MODEL_CSV_PATH}")
else:
    # Neither exists, we'll use a marker path that _load_model_data will handle
    LLM_MODEL_CSV_PATH = None
    logger.debug("No local LLM model CSV found, will use package default")
# ---------------------------------

# Load environment variables from .env file
logger.debug(f"Attempting to load .env from: {ENV_PATH}")
if ENV_PATH.exists():
    load_dotenv(dotenv_path=ENV_PATH)
    logger.debug(f"Loaded .env file from: {ENV_PATH}")
else:
    # Silently proceed if .env is optional
    logger.debug(f".env file not found at {ENV_PATH}. API keys might need to be provided manually.")

# Default model if PDD_MODEL_DEFAULT is not set
# No hardcoded default - will use first available model from CSV if None
DEFAULT_BASE_MODEL = os.getenv("PDD_MODEL_DEFAULT", None)

# --- LiteLLM Cache Configuration (S3 compatible for GCS, with SQLite fallback) ---
GCS_BUCKET_NAME = os.getenv("GCS_BUCKET_NAME")
GCS_ENDPOINT_URL = "https://storage.googleapis.com" # GCS S3 compatibility endpoint
GCS_REGION_NAME = os.getenv("GCS_REGION_NAME", "auto") # Often 'auto' works for GCS
GCS_HMAC_ACCESS_KEY_ID = os.getenv("GCS_HMAC_ACCESS_KEY_ID") # Load HMAC Key ID
GCS_HMAC_SECRET_ACCESS_KEY = os.getenv("GCS_HMAC_SECRET_ACCESS_KEY") # Load HMAC Secret

# Sanitize GCS credentials to handle WSL environment issues
if GCS_HMAC_ACCESS_KEY_ID:
    GCS_HMAC_ACCESS_KEY_ID = GCS_HMAC_ACCESS_KEY_ID.strip()
if GCS_HMAC_SECRET_ACCESS_KEY:
    GCS_HMAC_SECRET_ACCESS_KEY = GCS_HMAC_SECRET_ACCESS_KEY.strip()

cache_configured = False
configured_cache = None  # Store the configured cache instance for restoration

if GCS_BUCKET_NAME and GCS_HMAC_ACCESS_KEY_ID and GCS_HMAC_SECRET_ACCESS_KEY:
    # Store original AWS credentials before overwriting for GCS cache setup
    original_aws_access_key_id = os.environ.get('AWS_ACCESS_KEY_ID')
    original_aws_secret_access_key = os.environ.get('AWS_SECRET_ACCESS_KEY')
    original_aws_region_name = os.environ.get('AWS_REGION_NAME')

    try:
        # Temporarily set AWS env vars to GCS HMAC keys for S3 compatible cache
        os.environ['AWS_ACCESS_KEY_ID'] = GCS_HMAC_ACCESS_KEY_ID
        os.environ['AWS_SECRET_ACCESS_KEY'] = GCS_HMAC_SECRET_ACCESS_KEY
        # os.environ['AWS_REGION_NAME'] = GCS_REGION_NAME  # Uncomment if needed

        configured_cache = Cache(
            type="s3",
            s3_bucket_name=GCS_BUCKET_NAME,
            s3_region_name=GCS_REGION_NAME, # Pass region explicitly to cache
            s3_endpoint_url=GCS_ENDPOINT_URL,
        )
        litellm.cache = configured_cache
        logger.info(f"LiteLLM cache configured for GCS bucket (S3 compatible): {GCS_BUCKET_NAME}")
        cache_configured = True

    except Exception as e:
        warnings.warn(f"Failed to configure LiteLLM S3/GCS cache: {e}. Attempting SQLite cache fallback.")
        litellm.cache = None # Explicitly disable cache on failure (will try SQLite next)

    finally:
        # Restore original AWS credentials after cache setup attempt
        if original_aws_access_key_id is not None:
            os.environ['AWS_ACCESS_KEY_ID'] = original_aws_access_key_id
        elif 'AWS_ACCESS_KEY_ID' in os.environ:
            del os.environ['AWS_ACCESS_KEY_ID']

        if original_aws_secret_access_key is not None:
            os.environ['AWS_SECRET_ACCESS_KEY'] = original_aws_secret_access_key
        elif 'AWS_SECRET_ACCESS_KEY' in os.environ:
            del os.environ['AWS_SECRET_ACCESS_KEY']

        if original_aws_region_name is not None:
            os.environ['AWS_REGION_NAME'] = original_aws_region_name
        elif 'AWS_REGION_NAME' in os.environ:
            pass # Or just leave it if the temporary setting wasn't done/needed

# Check if caching is disabled via environment variable
if os.getenv("LITELLM_CACHE_DISABLE") == "1":
    logger.debug("LiteLLM caching disabled via LITELLM_CACHE_DISABLE=1")
    litellm.cache = None
    cache_configured = True

if not cache_configured:
    try:
        # Try disk-based cache as a fallback
        sqlite_cache_path = PROJECT_ROOT / "litellm_cache.sqlite"
        configured_cache = Cache(type="disk", disk_cache_dir=str(sqlite_cache_path))
        litellm.cache = configured_cache
        logger.debug(f"LiteLLM disk cache configured at {sqlite_cache_path}")
        cache_configured = True
    except Exception as e2:
        warnings.warn(f"Failed to configure LiteLLM disk cache: {e2}. Caching is disabled.")
        litellm.cache = None

if not cache_configured:
    warnings.warn("All LiteLLM cache configuration attempts failed. Caching is disabled.")
    litellm.cache = None

# --- LiteLLM Callback for Success Logging ---

# Module-level storage for last callback data (Use with caution in concurrent environments)
_LAST_CALLBACK_DATA = {
    "input_tokens": 0,
    "output_tokens": 0,
    "finish_reason": None,
    "cost": 0.0,
}

def _litellm_success_callback(
    kwargs: Dict[str, Any],              # kwargs passed to completion
    completion_response: Any,            # response object from completion
    start_time: float, end_time: float   # start/end time
):
    """
    LiteLLM success callback to capture usage and finish reason.
    Stores data in a module-level variable for potential retrieval.
    """
    global _LAST_CALLBACK_DATA
    usage = getattr(completion_response, 'usage', None)
    input_tokens = getattr(usage, 'prompt_tokens', 0)
    output_tokens = getattr(usage, 'completion_tokens', 0)
    finish_reason = getattr(completion_response.choices[0], 'finish_reason', None)

    calculated_cost = 0.0
    try:
        # Attempt 1: Use the response object directly (works for most single calls)
        cost_val = litellm.completion_cost(completion_response=completion_response)
        calculated_cost = cost_val if cost_val is not None else 0.0
        # LiteLLM may silently return 0.0 (no exception) for models missing from
        # its bundled pricing DB. Fall back to CSV rates when tokens were
        # exchanged but cost came back zero.
        if calculated_cost == 0.0 and (input_tokens or output_tokens):
            model_name = kwargs.get("model")
            rates = _MODEL_RATE_MAP.get(str(model_name)) if model_name else None
            if rates is not None:
                in_rate, out_rate = rates
                calculated_cost = (
                    float(input_tokens or 0) * in_rate
                    + float(output_tokens or 0) * out_rate
                ) / 1_000_000.0
    except Exception as e1:
        # Attempt 2: Compute via tokens and model mapping. If LiteLLM mapping is
        # missing or API differs, fall back to CSV rates in _MODEL_RATE_MAP.
        logger.debug(f"Attempting cost calculation with fallback method: {e1}")
        try:
            model_name = kwargs.get("model")
            if model_name and usage:
                in_tok = getattr(usage, 'prompt_tokens', None)
                out_tok = getattr(usage, 'completion_tokens', None)
                # Some providers may use 'input_tokens'/'output_tokens'
                if in_tok is None:
                    in_tok = getattr(usage, 'input_tokens', 0)
                if out_tok is None:
                    out_tok = getattr(usage, 'output_tokens', 0)

                # Try LiteLLM helper (arg names vary across versions)
                try:
                    cost_val = litellm.completion_cost(
                        model=model_name,
                        prompt_tokens=in_tok,
                        completion_tokens=out_tok,
                    )
                    calculated_cost = cost_val if cost_val is not None else 0.0
                except TypeError:
                    # Older/newer versions may require input/output token names
                    try:
                        cost_val = litellm.completion_cost(
                            model=model_name,
                            input_tokens=in_tok,
                            output_tokens=out_tok,
                        )
                        calculated_cost = cost_val if cost_val is not None else 0.0
                    except Exception as e3:
                        # Final fallback: compute using CSV rates
                        rates = _MODEL_RATE_MAP.get(str(model_name))
                        if rates is not None:
                            in_rate, out_rate = rates
                            calculated_cost = (float(in_tok or 0) * in_rate + float(out_tok or 0) * out_rate) / 1_000_000.0
                        else:
                            calculated_cost = 0.0
                        logger.debug(f"Cost calculation failed with LiteLLM token API; used CSV rates if available. Detail: {e3}")
            else:
                calculated_cost = 0.0
        except Exception as e2:
            calculated_cost = 0.0 # Default to 0 on any error
            logger.debug(f"Cost calculation failed with fallback method: {e2}")

    _LAST_CALLBACK_DATA["input_tokens"] = input_tokens
    _LAST_CALLBACK_DATA["output_tokens"] = output_tokens
    _LAST_CALLBACK_DATA["finish_reason"] = finish_reason
    _LAST_CALLBACK_DATA["cost"] = calculated_cost # Store the calculated cost

    # Callback doesn't need to return a value now
    # return calculated_cost

    # Example of logging within the callback (can be expanded)
    # logger.info(f"[Callback] Tokens: In={input_tokens}, Out={output_tokens}. Reason: {finish_reason}. Cost: ${calculated_cost:.6f}")

# Register the callback with LiteLLM
litellm.success_callback = [_litellm_success_callback]

# --- Cost Mapping Support (CSV Rates) ---
# Populate from CSV inside llm_invoke; used by callback fallback
_MODEL_RATE_MAP: Dict[str, Tuple[float, float]] = {}

def _set_model_rate_map(df: pd.DataFrame) -> None:
    global _MODEL_RATE_MAP
    try:
        _MODEL_RATE_MAP = {
            str(row['model']): (
                float(row['input']) if pd.notna(row['input']) else 0.0,
                float(row['output']) if pd.notna(row['output']) else 0.0,
            )
            for _, row in df.iterrows()
        }
    except Exception:
        _MODEL_RATE_MAP = {}
    _register_csv_models_with_litellm()


def _register_csv_models_with_litellm() -> None:
    """Register CSV-defined models with LiteLLM so completion_cost works for
    models LiteLLM doesn't ship pricing for (e.g., new Fireworks aliases). CSV
    rates are per million tokens; LiteLLM expects per-token."""
    if not _MODEL_RATE_MAP:
        return
    try:
        existing = getattr(litellm, "model_cost", {}) or {}
        registrations: Dict[str, Dict[str, Any]] = {}
        for model_name, (in_rate, out_rate) in _MODEL_RATE_MAP.items():
            if not model_name or model_name in existing:
                continue
            provider = model_name.split("/", 1)[0] if "/" in model_name else "openai"
            registrations[model_name] = {
                "input_cost_per_token": in_rate / 1_000_000.0,
                "output_cost_per_token": out_rate / 1_000_000.0,
                "litellm_provider": provider,
                "mode": "chat",
            }
        if registrations:
            litellm.register_model(registrations)
    except Exception as exc:
        logger.debug(f"Skipped registering CSV models with LiteLLM: {exc}")

# --- LLM Attribution Logging ---

_ATTRIBUTION_CONTEXT_CACHE: Dict[str, Dict[str, Any]] = {}
_ATTRIBUTION_LOG_DEFAULT_MAX_BYTES = 25 * 1024 * 1024
_CLOUD_RUNTIME_ENV_KEYS = (
    "CLOUD_BUILD",
    "BATCH_TASK_INDEX",
    "K_SERVICE",
    "CLOUD_RUN_JOB",
    "CLOUD_RUN_EXECUTION",
)
_ATTRIBUTION_ENV_KEYS = [
    "PDD_MODEL_DEFAULT",
    "PDD_STRENGTH_DEFAULT",
    "PDD_AGENTIC_PROVIDER",
    "PDD_ENVIRONMENT",
    "PDD_FORCE_LOCAL",
    "PDD_PATH",
    "PDD_RUN_REAL_LLM_TESTS",
    "PDD_RUN_LLM_TESTS",
    "PDD_BUDGET_CAP",
    "CI",
    "CLOUD_BUILD",
    "BUILD_ID",
    "TRIGGER_NAME",
    "BRANCH_NAME",
    "COMMIT_SHA",
    "_OWNER",
    "_REPO",
    "_PR_NUMBER",
    "K_SERVICE",
    "K_CONFIGURATION",
    "K_REVISION",
    "CLOUD_RUN_JOB",
    "CLOUD_RUN_EXECUTION",
    "CLOUD_RUN_TASK_INDEX",
    "CLOUD_RUN_TASK_ATTEMPT",
    "CLOUD_RUN_TASK_COUNT",
    "BATCH_TASK_INDEX",
    "BATCH_JOB_UID",
    "GOOGLE_CLOUD_PROJECT",
    "GOOGLE_CLOUD_LOCATION",
    "GOOGLE_GENAI_USE_VERTEXAI",
    "VERTEX_PROJECT",
    "VERTEX_LOCATION",
    "VERTEXAI_PROJECT",
    "VERTEXAI_LOCATION",
    "CLAUDE_CODE_USE_VERTEX",
]
_SECRET_NAME_PATTERN = re.compile(
    r"(api[_-]?key|token|secret|password|credential|private[_-]?key|oauth|bearer|auth)",
    re.IGNORECASE,
)
_SAFE_SUBCOMMANDS = frozenset({
    "change",
    "config",
    "detect",
    "example",
    "fix",
    "generate",
    "install",
    "setup",
    "split",
    "sync",
    "test",
    "trace",
    "update",
    "verify",
})


def _env_truthy(name: str, default: bool = False) -> bool:
    """Return a bool from a conventional environment flag."""
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in ("1", "true", "yes", "on")


def _llm_attribution_enabled() -> bool:
    """Whether safe LLM attribution metadata should be emitted."""
    explicit = os.getenv("PDD_LLM_ATTRIBUTION")
    if explicit is not None:
        return _env_truthy("PDD_LLM_ATTRIBUTION")
    # Avoid writing to a developer's ~/.pdd during unit tests unless a test opts in.
    if os.getenv("PYTEST_CURRENT_TEST"):
        return False
    return True


def _llm_attribution_process_log_enabled() -> bool:
    """Whether attribution records should also go to the process log stream."""
    if os.getenv("PDD_LLM_ATTRIBUTION_PROCESS_LOG") is not None:
        return _env_truthy("PDD_LLM_ATTRIBUTION_PROCESS_LOG")
    if os.getenv("PDD_LLM_ATTRIBUTION_STDOUT") is not None:
        return _env_truthy("PDD_LLM_ATTRIBUTION_STDOUT")
    return _is_cloud_runtime()


def _is_cloud_runtime() -> bool:
    """Return whether the process appears to be running in a Google cloud runner."""
    return any(os.getenv(name) for name in _CLOUD_RUNTIME_ENV_KEYS)


def _llm_attribution_max_bytes() -> int:
    """Return the max JSONL file size before best-effort single-file rotation."""
    raw = os.getenv("PDD_LLM_ATTRIBUTION_MAX_BYTES")
    if raw is None:
        return _ATTRIBUTION_LOG_DEFAULT_MAX_BYTES
    try:
        value = int(raw)
    except (TypeError, ValueError):
        return _ATTRIBUTION_LOG_DEFAULT_MAX_BYTES
    return max(0, value)


def _llm_attribution_log_path() -> Optional[Path]:
    """Return the JSONL log path for attribution records."""
    raw_path = os.getenv("PDD_LLM_ATTRIBUTION_LOG_PATH")
    try:
        if raw_path:
            return Path(raw_path).expanduser()
        return Path.home() / ".pdd" / "logs" / "llm-attribution.jsonl"
    except Exception:
        return None


def _is_default_llm_attribution_log_path(log_path: Path) -> bool:
    """Return whether a path is the default local attribution log."""
    try:
        default_path = Path.home() / ".pdd" / "logs" / "llm-attribution.jsonl"
        return log_path.expanduser().resolve(strict=False) == default_path.resolve(strict=False)
    except Exception:
        return False


def _is_sensitive_name(value: Any) -> bool:
    return bool(_SECRET_NAME_PATTERN.search(str(value or "")))


def _safe_command_summary(argv: List[str]) -> Dict[str, Any]:
    """Summarize argv without preserving raw positional or flag values."""
    if not argv:
        return {"argc": 0}

    option_names: List[str] = []
    positional_count = 0
    subcommand: Optional[str] = None
    args = list(argv[1:])

    idx = 0
    while idx < len(args):
        arg = str(args[idx])
        if arg == "--":
            positional_count += max(0, len(args) - idx - 1)
            break

        if arg.startswith("--") and len(arg) > 2:
            option_name = arg.split("=", 1)[0]
            option_names.append(option_name)
            # Treat every explicit flag value as sensitive. Option names are
            # still useful for attribution; values are not needed and may be
            # prompts, file contents, tokens, or service account paths.
            if "=" not in arg and idx + 1 < len(args) and not str(args[idx + 1]).startswith("-"):
                idx += 1
            idx += 1
            continue

        if arg.startswith("-") and len(arg) > 1:
            option_names.append(arg)
            if len(arg) == 2 and idx + 1 < len(args) and not str(args[idx + 1]).startswith("-"):
                idx += 1
            idx += 1
            continue

        positional_count += 1
        if subcommand is None and arg in _SAFE_SUBCOMMANDS:
            subcommand = arg
        idx += 1

    return {
        "executable": Path(str(argv[0])).name,
        "argc": len(argv),
        "subcommand": subcommand,
        "option_names": list(dict.fromkeys(option_names)),
        "positional_count": positional_count,
    }


def _safe_error_fields(error: BaseException) -> Dict[str, Any]:
    """Return structured exception metadata without provider message text."""
    fields: Dict[str, Any] = {"error_type": type(error).__name__}
    for attr_name in ("status_code", "code", "type", "request_id"):
        try:
            value = getattr(error, attr_name, None)
        except Exception:
            value = None
        if value is None or _is_sensitive_name(value):
            continue
        if isinstance(value, str):
            fields[attr_name] = _truncate(value, 120)
        elif isinstance(value, (int, float, bool)):
            fields[attr_name] = value

    try:
        response = getattr(error, "response", None)
        response_status = getattr(response, "status_code", None)
        if response_status is not None:
            fields["response_status_code"] = response_status
    except Exception:
        pass

    return fields


def _json_safe(value: Any) -> Any:
    """Convert values into JSON-serializable primitives."""
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    if isinstance(value, dict):
        return {str(k): _json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [_json_safe(v) for v in value]
    try:
        return str(value)
    except Exception:
        return repr(value)


def _truncate(value: Any, max_len: int = 500) -> str:
    text = str(value)
    if len(text) <= max_len:
        return text
    return text[:max_len] + "...<truncated>"


def _run_attribution_command(args: List[str], cwd: Path) -> Optional[str]:
    """Run a short local command for attribution metadata."""
    try:
        result = subprocess.run(
            args,
            cwd=str(cwd),
            check=False,
            capture_output=True,
            text=True,
            timeout=1.0,
        )
        if result.returncode != 0:
            return None
        return result.stdout.strip()
    except Exception:
        return None


def _read_json_object(path: Path) -> Optional[Dict[str, Any]]:
    try:
        with path.open("r", encoding="utf-8") as f:
            parsed = json.load(f)
        if isinstance(parsed, dict):
            return parsed
    except Exception:
        return None
    return None


def _service_account_summary(raw: Dict[str, Any]) -> Dict[str, Any]:
    summary: Dict[str, Any] = {
        "type": raw.get("type"),
        "client_email": raw.get("client_email"),
        "project_id": raw.get("project_id"),
    }
    private_key_id = raw.get("private_key_id")
    if private_key_id:
        summary["private_key_id_prefix"] = str(private_key_id)[:12]
    quota_project_id = raw.get("quota_project_id")
    if quota_project_id:
        summary["quota_project_id"] = quota_project_id
    client_id = raw.get("client_id")
    if client_id and raw.get("type") != "service_account":
        summary["client_id_prefix"] = str(client_id)[:12]
    return {k: v for k, v in summary.items() if v not in (None, "")}


def _gcloud_config_summary() -> Dict[str, Any]:
    """Read active gcloud account/project without shelling out to gcloud."""
    config_dir = Path.home() / ".config" / "gcloud"
    summary: Dict[str, Any] = {}
    try:
        active_name = (config_dir / "active_config").read_text(encoding="utf-8").strip()
        if active_name:
            summary["active_config"] = active_name
            config_path = config_dir / "configurations" / f"config_{active_name}"
        else:
            config_path = config_dir / "configurations" / "config_default"
    except Exception:
        config_path = config_dir / "configurations" / "config_default"

    try:
        for raw_line in config_path.read_text(encoding="utf-8").splitlines():
            line = raw_line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, value = [part.strip() for part in line.split("=", 1)]
            if key == "account":
                summary["account"] = value
            elif key == "project":
                summary["project"] = value
    except Exception:
        pass
    return summary


def _metadata_server_service_account_summary() -> Dict[str, Any]:
    """Read the cloud runtime service account email without requesting a token."""
    if not _is_cloud_runtime():
        return {}

    metadata_host = os.getenv("GCE_METADATA_HOST", "metadata.google.internal")
    url = f"http://{metadata_host}/computeMetadata/v1/instance/service-accounts/default/email"
    request = urllib.request.Request(url, headers={"Metadata-Flavor": "Google"})
    try:
        with urllib.request.urlopen(request, timeout=0.2) as response:
            email = response.read(256).decode("utf-8", errors="replace").strip()
    except Exception:
        return {}

    if not email or _is_sensitive_name(email):
        return {}
    return {"service_account_email": email}


def _credential_context() -> Dict[str, Any]:
    """Return safe credential identity metadata without token or key material."""
    context: Dict[str, Any] = {}

    gac = os.getenv("GOOGLE_APPLICATION_CREDENTIALS")
    if gac:
        gac_path = Path(gac).expanduser()
        context["google_application_credentials"] = {
            "path": str(gac_path),
            "exists": gac_path.exists(),
        }
        parsed = _read_json_object(gac_path)
        if parsed:
            context["google_application_credentials"].update(_service_account_summary(parsed))

    adc_path = Path.home() / ".config" / "gcloud" / "application_default_credentials.json"
    context["application_default_credentials"] = {
        "path": str(adc_path),
        "exists": adc_path.exists(),
    }
    parsed_adc = _read_json_object(adc_path)
    if parsed_adc:
        context["application_default_credentials"].update(_service_account_summary(parsed_adc))

    gcloud_config = _gcloud_config_summary()
    if gcloud_config:
        context["gcloud_config"] = gcloud_config

    metadata_account = _metadata_server_service_account_summary()
    if metadata_account:
        context["metadata_server"] = metadata_account

    return context


def _git_context(cwd: Path) -> Dict[str, Any]:
    """Return git metadata for the current working directory."""
    cache_key = str(cwd)
    if cache_key in _ATTRIBUTION_CONTEXT_CACHE:
        return dict(_ATTRIBUTION_CONTEXT_CACHE[cache_key])

    context: Dict[str, Any] = {}
    root = _run_attribution_command(["git", "rev-parse", "--show-toplevel"], cwd)
    if root:
        context["root"] = root
        git_cwd = Path(root)
    else:
        git_cwd = cwd

    branch = _run_attribution_command(["git", "rev-parse", "--abbrev-ref", "HEAD"], git_cwd)
    commit = _run_attribution_command(["git", "rev-parse", "HEAD"], git_cwd)
    status = _run_attribution_command(["git", "status", "--short"], git_cwd)
    if branch:
        context["branch"] = branch
    if commit:
        context["commit"] = commit
    if status is not None:
        context["dirty"] = bool(status)
        context["status_line_count"] = 0 if not status else len(status.splitlines())

    _ATTRIBUTION_CONTEXT_CACHE[cache_key] = dict(context)
    return context


def _parent_process_context() -> Dict[str, Any]:
    pids = [str(os.getpid())]
    ppid = os.getppid()
    if ppid:
        pids.append(str(ppid))
    try:
        result = subprocess.run(
            ["ps", "-o", "pid=,ppid=,comm=", "-p", ",".join(pids)],
            check=False,
            capture_output=True,
            text=True,
            timeout=1.0,
        )
        if result.returncode == 0:
            return {
                "pid": os.getpid(),
                "ppid": ppid,
                "processes": [_truncate(line.strip(), 300) for line in result.stdout.splitlines() if line.strip()],
            }
    except Exception:
        pass
    return {"pid": os.getpid(), "ppid": ppid}


def _safe_env_context() -> Dict[str, str]:
    return {name: os.getenv(name, "") for name in _ATTRIBUTION_ENV_KEYS if os.getenv(name) is not None}


def _stack_context(cwd: Path) -> List[str]:
    """Return a compact stack trace without prompt/message content."""
    try:
        git_root = _git_context(cwd).get("root")
        roots = [Path(git_root)] if git_root else []
        roots.extend([cwd, Path.home()])
        frames = []
        for frame in traceback.extract_stack(limit=40):
            path = Path(frame.filename)
            display = str(path)
            for root in roots:
                try:
                    display = str(path.resolve().relative_to(root.resolve()))
                    break
                except Exception:
                    continue
            frames.append(f"{display}:{frame.lineno}:{frame.name}")
        return frames[-25:]
    except Exception:
        return []


def _build_llm_attribution_context(
    *,
    strength: float,
    temperature: float,
    time_value: Optional[float],
    use_batch_mode: bool,
    use_cloud: Optional[bool],
    output_pydantic: Optional[Type[BaseModel]],
    output_schema: Optional[Dict[str, Any]],
    language: Optional[str],
) -> Dict[str, Any]:
    """Build safe, prompt-free attribution metadata for an LLM invocation."""
    cwd = Path.cwd()
    return {
        "request_id": uuid.uuid4().hex,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "process": {
            "command": _safe_command_summary(sys.argv),
            "cwd": str(cwd),
            "executable": sys.executable,
            "user": getpass.getuser(),
            "hostname": socket.gethostname(),
            **_parent_process_context(),
        },
        "git": _git_context(cwd),
        "env": _safe_env_context(),
        "credentials": _credential_context(),
        "pdd": {
            "llm_model_csv_path": str(LLM_MODEL_CSV_PATH) if LLM_MODEL_CSV_PATH else "package_default",
            "default_base_model": DEFAULT_BASE_MODEL,
            "project_root": str(PROJECT_ROOT),
            "project_root_from_env": PROJECT_ROOT_FROM_ENV,
            "env_path": str(ENV_PATH),
        },
        "parameters": {
            "strength": strength,
            "temperature": temperature,
            "time": time_value,
            "use_batch_mode": use_batch_mode,
            "use_cloud": use_cloud,
            "output_pydantic": output_pydantic.__name__ if output_pydantic else None,
            "output_schema": bool(output_schema),
            "language": language,
        },
        "python_stack": _stack_context(cwd),
    }


def _maybe_build_llm_attribution_context(**kwargs: Any) -> Optional[Dict[str, Any]]:
    """Build attribution context only when emission is enabled."""
    if not _llm_attribution_enabled():
        return None
    return _build_llm_attribution_context(**kwargs)


def _api_key_field_names(api_key_field: Any) -> List[str]:
    try:
        from pdd.provider_manager import parse_api_key_vars
        return parse_api_key_vars(str(api_key_field or ""))
    except Exception:
        raw = str(api_key_field or "")
        return [part.strip() for part in raw.split("|") if part.strip()]


def _summarize_litellm_kwargs(kwargs: Dict[str, Any]) -> Dict[str, Any]:
    """Return a prompt-free, secret-free summary of LiteLLM kwargs."""
    safe_keys = [
        "model",
        "temperature",
        "num_retries",
        "vertex_location",
        "api_version",
        "caching",
    ]
    summary = {key: kwargs.get(key) for key in safe_keys if key in kwargs}
    summary["has_api_key"] = bool(kwargs.get("api_key"))
    summary["has_base_url"] = bool(kwargs.get("base_url") or kwargs.get("api_base"))
    summary["has_response_format"] = "response_format" in kwargs
    summary["has_reasoning"] = any(key in kwargs for key in ("reasoning", "reasoning_effort", "thinking"))
    messages = kwargs.get("messages")
    if isinstance(messages, list):
        summary["message_count"] = len(messages)
        if messages and isinstance(messages[0], list):
            summary["batch_count"] = len(messages)
            summary["first_batch_message_count"] = len(messages[0])
    return summary


def _model_disallows_temperature(model_name: Any) -> bool:
    """Return True for models whose provider rejects the temperature parameter."""
    model_lower = str(model_name or "").lower()
    return "claude-opus-4-7" in model_lower or "claude-opus-4.7" in model_lower


def _response_usage_summary(response: Any) -> Dict[str, Any]:
    """Return token and finish metadata from a LiteLLM response."""
    responses = response if isinstance(response, list) else [response]
    prompt_tokens = 0
    completion_tokens = 0
    total_tokens = 0
    finish_reasons: List[Any] = []

    for item in responses:
        usage = getattr(item, "usage", None)
        prompt_tokens += int(getattr(usage, "prompt_tokens", 0) or getattr(usage, "input_tokens", 0) or 0)
        completion_tokens += int(getattr(usage, "completion_tokens", 0) or getattr(usage, "output_tokens", 0) or 0)
        total_tokens += int(getattr(usage, "total_tokens", 0) or 0)
        try:
            finish_reasons.append(getattr(item.choices[0], "finish_reason", None))
        except Exception:
            pass

    return {
        "response_count": len(responses),
        "prompt_tokens": prompt_tokens,
        "completion_tokens": completion_tokens,
        "total_tokens": total_tokens,
        "finish_reasons": [reason for reason in finish_reasons if reason is not None],
    }


def _completion_with_attribution(
    *,
    context: Dict[str, Any],
    attempt_id: str,
    call_type: str,
    model: str,
    provider: str,
    api_key_name: Any,
    kwargs: Dict[str, Any],
) -> Any:
    """Call litellm.completion while emitting safe attribution metadata."""
    _emit_llm_attribution(
        context,
        "llm_invoke.litellm_request",
        attempt_id=attempt_id,
        call_type=call_type,
        model=str(model),
        provider=str(provider),
        api_key_env_names=_api_key_field_names(api_key_name),
        kwargs_summary=_summarize_litellm_kwargs(kwargs),
    )
    start = time_module.time()
    try:
        response = litellm.completion(**kwargs)
    except Exception as e:
        _emit_llm_attribution(
            context,
            "llm_invoke.litellm_error",
            attempt_id=attempt_id,
            call_type=call_type,
            model=str(model),
            provider=str(provider),
            **_safe_error_fields(e),
        )
        raise
    _emit_llm_attribution(
        context,
        "llm_invoke.litellm_response",
        attempt_id=attempt_id,
        call_type=call_type,
        model=str(model),
        provider=str(provider),
        duration_seconds=round(time_module.time() - start, 3),
        usage=_response_usage_summary(response),
    )
    return response


def _emit_llm_attribution(context: Optional[Dict[str, Any]], event: str, **fields: Any) -> None:
    """Emit one safe structured attribution record."""
    if not context or not _llm_attribution_enabled():
        return

    record = {
        "schema": "pdd.llm_attribution.v1",
        "log_type": "pdd_llm_attribution",
        "severity": "INFO",
        "event": event,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        **context,
        **fields,
    }
    try:
        payload = json.dumps(_json_safe(record), sort_keys=True, separators=(",", ":"))
    except Exception as dump_error:
        logger.debug(f"Failed to serialize LLM attribution record: {dump_error}")
        return

    log_path = _llm_attribution_log_path()
    if log_path is not None:
        try:
            _append_llm_attribution_payload(log_path, payload)
        except Exception as file_error:
            logger.debug(f"Failed to write LLM attribution log: {file_error}")

    if _llm_attribution_process_log_enabled():
        sys.stderr.write(payload + "\n")
        sys.stderr.flush()


def _append_llm_attribution_payload(log_path: Path, payload: str) -> None:
    """Append one JSONL attribution record with restrictive permissions and rotation."""
    parent_existed = log_path.parent.exists()
    log_path.parent.mkdir(parents=True, mode=0o700, exist_ok=True)
    if not parent_existed or _is_default_llm_attribution_log_path(log_path):
        try:
            os.chmod(log_path.parent, 0o700)
        except Exception:
            pass

    max_bytes = _llm_attribution_max_bytes()
    try:
        if max_bytes > 0 and log_path.exists() and log_path.stat().st_size >= max_bytes:
            rotated_path = log_path.with_name(f"{log_path.name}.1")
            try:
                rotated_path.unlink()
            except FileNotFoundError:
                pass
            log_path.replace(rotated_path)
            try:
                os.chmod(rotated_path, 0o600)
            except Exception:
                pass
    except Exception:
        pass

    fd = os.open(log_path, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o600)
    try:
        with os.fdopen(fd, "a", encoding="utf-8") as f:
            f.write(payload + "\n")
    finally:
        try:
            os.chmod(log_path, 0o600)
        except Exception:
            pass

# --- Helper Functions ---

def _is_malformed_json_response(content: str, threshold: int = 100) -> bool:
    """
    Detect if a JSON response appears malformed due to excessive trailing newlines.

    This can happen when Gemini generates thousands of \n characters in a JSON string value,
    causing the response to be truncated and missing closing braces.

    Args:
        content: The raw response content string
        threshold: Number of consecutive trailing \n sequences to consider malformed

    Returns:
        True if the response appears malformed, False otherwise
    """
    if not content or not isinstance(content, str):
        return False

    # Check if it starts like JSON but doesn't end properly
    stripped = content.strip()
    if not stripped.startswith('{'):
        return False

    # If it ends with }, it's probably fine
    if stripped.endswith('}'):
        return False

    # Count trailing \n sequences (escaped newlines in JSON strings)
    # The pattern \n in a JSON string appears as \\n in the raw content
    trailing_newline_count = 0
    check_content = stripped
    while check_content.endswith('\\n'):
        trailing_newline_count += 1
        check_content = check_content[:-2]

    # If there are many trailing \n sequences, it's likely malformed
    if trailing_newline_count >= threshold:
        return True

    # Also check for excessive actual trailing newlines (not just escaped \\n)
    # This catches cases where raw newlines cause truncation
    actual_newline_count = len(content) - len(content.rstrip('\n'))
    if actual_newline_count >= threshold:
        return True

    # Also check for response that looks truncated mid-string
    # (ends with characters that suggest we're inside a JSON string value)
    if not stripped.endswith('}') and not stripped.endswith(']') and not stripped.endswith('"'):
        # Could be truncated in the middle of an escaped sequence
        if stripped.endswith('\\'):
            return True

    return False


def _load_model_data(csv_path: Optional[Path]) -> pd.DataFrame:
    """Loads and preprocesses the LLM model data from CSV.
    
    Args:
        csv_path: Path to CSV file, or None to use package default
        
    Returns:
        DataFrame with model configuration data
    """
    # If csv_path is provided, try to load from it
    if csv_path is not None:
        if not csv_path.exists():
            logger.warning(f"Specified LLM model CSV not found at {csv_path}, trying package default")
            csv_path = None
        else:
            try:
                df = pd.read_csv(csv_path)
                logger.debug(f"Loaded model data from {csv_path}")
                # Continue with the rest of the function...
            except Exception as e:
                logger.warning(f"Failed to load CSV from {csv_path}: {e}, trying package default")
                csv_path = None
    
    # If csv_path is None or loading failed, use package default
    if csv_path is None:
        try:
            # Use importlib.resources to load the packaged CSV
            csv_data = importlib.resources.files('pdd').joinpath('data/llm_model.csv').read_text()
            import io
            df = pd.read_csv(io.StringIO(csv_data))
            logger.info("Loaded model data from package default")
        except Exception as e:
            raise FileNotFoundError(f"Failed to load default LLM model CSV from package: {e}")
    
    try:
        # Basic validation and type conversion
        required_cols = ['provider', 'model', 'input', 'output', 'coding_arena_elo', 'api_key', 'structured_output', 'reasoning_type']
        for col in required_cols:
            if col not in df.columns:
                raise ValueError(f"Missing required column in CSV: {col}")

        # Convert numeric columns, handling potential errors
        numeric_cols = ['input', 'output', 'coding_arena_elo', 'max_tokens',
                        'max_completion_tokens', 'max_reasoning_tokens']
        for col in numeric_cols:
            if col in df.columns:
                # Use errors='coerce' to turn unparseable values into NaN
                df[col] = pd.to_numeric(df[col], errors='coerce')

        # Fill NaN in critical numeric columns used for selection/interpolation
        df['input'] = df['input'].fillna(0.0)
        df['output'] = df['output'].fillna(0.0)
        df['coding_arena_elo'] = df['coding_arena_elo'].fillna(0) # Use 0 ELO for missing
        # Ensure max_reasoning_tokens is numeric, fillna with 0
        df['max_reasoning_tokens'] = df['max_reasoning_tokens'].fillna(0).astype(int) # Ensure int

        # Calculate average cost (handle potential division by zero if needed, though unlikely with fillna)
        df['avg_cost'] = (df['input'] + df['output']) / 2

        # Ensure boolean interpretation for structured_output
        if 'structured_output' in df.columns:
             df['structured_output'] = df['structured_output'].fillna(False).astype(bool)
        else:
             df['structured_output'] = False # Assume false if column missing

        # Ensure reasoning_type is string, fillna with 'none' and lowercase
        df['reasoning_type'] = df['reasoning_type'].fillna('none').astype(str).str.lower()

        # Ensure api_key is treated as string, fill NaN with empty string ''
        # This handles cases where read_csv might interpret empty fields as NaN
        df['api_key'] = df['api_key'].fillna('').astype(str)

        return df
    except Exception as e:
        raise RuntimeError(f"Error loading or processing LLM model CSV {csv_path}: {e}") from e


# Provider-prefix aliases. Each maps a model-name prefix (the form
# `litellm.completion(model=...)` expects for routing) to the provider
# string used in `llm_model.csv`. When `_select_model_candidates` misses
# a literal-match lookup, it retries with provider-aware alternatives
# derived from this map before falling back to the surrogate base.
#
# AWS Bedrock is intentionally omitted — its model names use a
# dot-separated convention (e.g. `anthropic.claude-opus-4-6-v1`) rather
# than a slash prefix, so there is no clean alias mapping.
_PROVIDER_PREFIX_TO_PROVIDER = {
    "vertex_ai/": "Google Vertex AI",
    "gemini/": "Google Gemini",
    "anthropic/": "Anthropic",
    "azure_ai/": "Azure AI",
}


def _alternative_base_lookups(base_model_name: str) -> List[Tuple[str, str]]:
    """Return ``(alt_name, required_provider)`` pairs to try when the literal
    form of ``base_model_name`` is not in the CSV.

    The lookup is provider-aware: each alternative is bound to the specific
    `provider` column value the prefix implies. This prevents a configured
    Vertex name like ``vertex_ai/claude-opus-4-6`` from silently resolving
    to a direct ``Anthropic,claude-opus-4-6`` row, which would change both
    credentials (`GOOGLE_APPLICATION_CREDENTIALS` → `ANTHROPIC_API_KEY`)
    and the actual API endpoint that gets hit. The same provider boundary
    is what the user's deployment expects when they pick a prefixed name.

    Two cases:

    * Configured name *has* a known provider prefix → try the bare form,
      constrained to the corresponding provider only. (Solves the bundled
      CSV's prefix inconsistency for Vertex models like
      ``vertex_ai/gemini-3.1-pro-preview`` that are stored bare under
      ``Google Vertex AI``.)
    * Configured name has *no* known prefix → try each prefix added,
      each constrained to its provider. (Solves the inverse direction:
      a bare configured name where the CSV only has the prefixed form.)

    Returns an empty list for empty/None input.
    """
    if not base_model_name:
        return []
    alternatives: List[Tuple[str, str]] = []
    for prefix, provider in _PROVIDER_PREFIX_TO_PROVIDER.items():
        if base_model_name.startswith(prefix):
            # Strip the prefix; only consider rows from the matching provider.
            alternatives.append((base_model_name[len(prefix):], provider))
            return alternatives
    # No known prefix → try with each prefix added, each provider-bound.
    for prefix, provider in _PROVIDER_PREFIX_TO_PROVIDER.items():
        alternatives.append((prefix + base_model_name, provider))
    return alternatives


def _select_model_candidates(
    strength: float,
    base_model_name: str,
    model_df: pd.DataFrame
) -> List[Dict[str, Any]]:
    """Selects and sorts candidate models based on strength and availability."""

    # 1. Filter by API Key Name Presence (initial availability check)
    # Keep models with a non-empty api_key field in the CSV.
    # The actual key value check happens later.
    # Allow models with empty api_key (e.g., Bedrock using AWS creds, local models)
    available_df = model_df[model_df['api_key'].notna()].copy()

    # In CI / headless environments, exclude local models (lm_studio, ollama)
    # that require a running local server — they hang on connection attempts.
    if os.environ.get("PDD_SKIP_LOCAL_MODELS"):
        local_providers = {"lm_studio", "ollama"}
        available_df = available_df[~available_df['provider'].str.lower().isin(local_providers)]

    # --- Check if the initial DataFrame itself was empty ---
    if model_df.empty:
        raise ValueError("Loaded model data is empty. Check CSV file.")

    # --- Check if filtering resulted in empty (might indicate all models had NaN api_key) ---
    if available_df.empty:
        # This case is less likely if notna() is the only filter, but good to check.
        logger.warning("No models found after filtering for non-NaN api_key. Check CSV 'api_key' column.")
        # Decide if this should be a hard error or allow proceeding if logic permits
        # For now, let's raise an error as it likely indicates a CSV issue.
        raise ValueError("No models available after initial filtering (all had NaN 'api_key'?).")

    # 2. Find Base Model
    base_model_row = available_df[available_df['model'] == base_model_name]
    if base_model_row.empty:
        # The bundled llm_model.csv has inconsistent provider-prefix conventions
        # for Vertex AI models — most have a `vertex_ai/` prefix, but a few
        # (notably gemini-3.1-pro-preview) are listed bare under
        # provider="Google Vertex AI". Users who configure
        # `PDD_MODEL_DEFAULT=vertex_ai/gemini-3.1-pro-preview` (the natural
        # form expected by litellm.completion for Vertex routing) silently
        # missed the lookup and fell into the surrogate-base branch below,
        # which picks the first CSV row — typically claude-opus-4-6 — and
        # routes every request to Opus regardless of strength.
        #
        # Before falling back, try provider-aware alternatives of the
        # configured name. Each alternative is bound to the provider that
        # the prefix implies, so prefix mismatches NEVER cross provider
        # boundaries (which would silently change credentials and routing).
        # Example: `vertex_ai/gemini-3.1-pro-preview` will only match rows
        # where provider="Google Vertex AI" — it will not pick up a direct
        # Gemini API or Anthropic row even if one happens to share the
        # bare name.
        alt_resolved = False
        for alt_name, required_provider in _alternative_base_lookups(base_model_name):
            alt_row = available_df[
                (available_df['model'] == alt_name)
                & (available_df['provider'] == required_provider)
            ]
            if not alt_row.empty:
                base_model = alt_row.iloc[0]
                alt_resolved = True
                break
        if not alt_resolved:
            # Try finding base model in the *original* df in case it was filtered out
            original_base = model_df[model_df['model'] == base_model_name]
            if not original_base.empty:
                # Base exists but may be misconfigured (e.g., missing API key). Keep erroring loudly.
                raise ValueError(
                    f"Base model '{base_model_name}' found in CSV but requires API key '{original_base.iloc[0]['api_key']}' which might be missing or invalid configuration."
                )
            # Option A': Soft fallback – choose a reasonable surrogate base and continue
            # Strategy (simplified and deterministic): pick the first available model
            # from the CSV as the surrogate base. This mirrors typical CSV ordering
            # expectations and keeps behavior predictable across environments.
            # Fix for issue #296: Don't warn when any base model (from env var or default) is not found in CSV
            try:
                base_model = available_df.iloc[0]
                # Silently use the first available model from user's CSV without warning
                # Users who intentionally customize their CSV shouldn't see warnings about removed models
            except Exception:
                # If any unexpected error occurs during fallback, raise a clear error
                raise ValueError(
                    f"Specified base model '{base_model_name}' not found and fallback selection failed. Check your LLM model CSV."
                )
    else:
        base_model = base_model_row.iloc[0]

    # 3. Determine Target and Sort
    candidates = []
    target_metric_value = None # For debugging print

    if strength == 0.5:
        # target_model = base_model
        # Sort remaining by ELO descending as fallback
        available_df['sort_metric'] = -available_df['coding_arena_elo'] # Negative for descending sort
        candidates = available_df.sort_values(by='sort_metric').to_dict('records')
        # Ensure effective base model is first if it exists (supports surrogate base)
        effective_base_name = str(base_model['model']) if isinstance(base_model, pd.Series) else base_model_name
        if any(c['model'] == effective_base_name for c in candidates):
            candidates.sort(key=lambda x: 0 if x['model'] == effective_base_name else 1)
        target_metric_value = f"Base Model ELO: {base_model['coding_arena_elo']}"

    elif strength < 0.5:
        # Interpolate by Cost (downwards from base)
        base_cost = base_model['avg_cost']
        cheapest_model = available_df.loc[available_df['avg_cost'].idxmin()]
        cheapest_cost = cheapest_model['avg_cost']

        if base_cost <= cheapest_cost: # Handle edge case where base is cheapest
             target_cost = cheapest_cost + strength * (base_cost - cheapest_cost) # Will be <= base_cost
        else:
             # Interpolate between cheapest and base
             target_cost = cheapest_cost + (strength / 0.5) * (base_cost - cheapest_cost)

        available_df['sort_metric'] = abs(available_df['avg_cost'] - target_cost)
        candidates = available_df.sort_values(by='sort_metric').to_dict('records')
        target_metric_value = f"Target Cost: {target_cost:.6f}"

    else: # strength > 0.5
        # Interpolate by ELO (upwards from base)
        base_elo = base_model['coding_arena_elo']
        highest_elo_model = available_df.loc[available_df['coding_arena_elo'].idxmax()]
        highest_elo = highest_elo_model['coding_arena_elo']

        if highest_elo <= base_elo: # Handle edge case where base has highest ELO
            target_elo = base_elo + (strength - 0.5) * (highest_elo - base_elo) # Will be >= base_elo
        else:
            # Interpolate between base and highest
            target_elo = base_elo + ((strength - 0.5) / 0.5) * (highest_elo - base_elo)

        available_df['sort_metric'] = abs(available_df['coding_arena_elo'] - target_elo)
        candidates = available_df.sort_values(by='sort_metric').to_dict('records')
        target_metric_value = f"Target ELO: {target_elo:.2f}"


    if not candidates:
         # This should ideally not happen if available_df was not empty
         raise RuntimeError("Model selection resulted in an empty candidate list.")

    # --- DEBUGGING PRINT ---
    if os.getenv("PDD_DEBUG_SELECTOR"): # Add env var check for debug prints
        logger.debug("\n--- DEBUG: _select_model_candidates ---")
        logger.debug(f"Strength: {strength}, Base Model: {base_model_name}")
        logger.debug(f"Metric: {target_metric_value}")
        logger.debug("Available DF (Sorted by metric):")
        # Select columns relevant to the sorting metric
        sort_cols = ['model', 'avg_cost', 'coding_arena_elo', 'sort_metric']
        logger.debug(available_df.sort_values(by='sort_metric')[sort_cols])
        logger.debug("Final Candidates List (Model Names):")
        logger.debug([c['model'] for c in candidates])
        logger.debug("---------------------------------------\n")
    # --- END DEBUGGING PRINT ---

    return candidates


def _sanitize_api_key(key_value: str) -> str:
    """
    Sanitize API key by removing whitespace and carriage returns.
    
    This fixes WSL environment issues where API keys may contain trailing \r characters
    that make them invalid for HTTP headers.
    
    Args:
        key_value: The raw API key value from environment
        
    Returns:
        Sanitized API key with whitespace and carriage returns removed
        
    Raises:
        ValueError: If the API key format is invalid after sanitization
    """
    if not key_value:
        return key_value
    
    # Strip all whitespace including carriage returns, newlines, etc.
    sanitized = key_value.strip()
    
    # Additional validation: ensure no remaining control characters
    if any(ord(c) < 32 for c in sanitized):
        logger.warning("API key contains control characters that may cause issues")
        # Remove any remaining control characters
        sanitized = ''.join(c for c in sanitized if ord(c) >= 32)
    
    # Validate API key format (basic checks)
    if sanitized:
        # Check for common API key patterns
        if len(sanitized) < 10:
            logger.warning(f"API key appears too short ({len(sanitized)} characters) - may be invalid")
        
        # Check for invalid characters in API keys (should be printable ASCII)
        if not all(32 <= ord(c) <= 126 for c in sanitized):
            logger.warning("API key contains non-printable characters")
            
        # Check for WSL-specific issues (detect if original had carriage returns)
        if key_value != sanitized and '\r' in key_value:
            if _is_wsl_environment():
                logger.info("Detected and fixed WSL line ending issue in API key")
            else:
                logger.info("Detected and fixed line ending issue in API key")
    
    return sanitized


def _save_key_to_env_file(key_name: str, value: str, env_path: Path) -> None:
    """Save or update a key in the .env file.

    - Replaces existing key in-place (no comment + append)
    - Removes old commented versions of the same key (Issue #183)
    - Preserves all other content
    """
    lines = []
    if env_path.exists():
        with open(env_path, 'r') as f:
            lines = f.readlines()

    new_lines = []
    key_replaced = False
    prefix = f"{key_name}="
    prefix_spaced = f"{key_name} ="

    for line in lines:
        stripped = line.strip()
        # Skip old commented versions of this key (cleanup accumulation)
        if stripped.startswith(f"# {prefix}") or stripped.startswith(f"# {prefix_spaced}"):
            continue
        elif stripped.startswith(prefix) or stripped.startswith(prefix_spaced):
            # Replace in-place
            new_lines.append(f'{key_name}="{value}"\n')
            key_replaced = True
        else:
            new_lines.append(line)

    # Add key if not found
    if not key_replaced:
        if new_lines and not new_lines[-1].endswith('\n'):
            new_lines.append('\n')
        new_lines.append(f'{key_name}="{value}"\n')

    with open(env_path, 'w') as f:
        f.writelines(new_lines)


def _ensure_api_key(model_info: Dict[str, Any], newly_acquired_keys: Dict[str, bool], verbose: bool) -> bool:
    """Checks for API key(s) in env, prompts user if missing, and updates .env.

    Supports pipe-delimited api_key fields (e.g. ``VAR1|VAR2|VAR3``).
    - Empty field → no auth needed (device flow / local model), always True.
    - Single var  → existing interactive-prompt behaviour for simple providers.
    - Multi var   → checks all vars; if any missing, directs user to ``pdd setup``.
    """
    from pdd.provider_manager import parse_api_key_vars

    api_key_field = str(model_info.get('api_key', '') or '')

    if not api_key_field.strip() or api_key_field == "EXISTING_KEY":
        # GitHub Copilot models use an interactive OAuth device flow managed by
        # litellm.  In non-interactive (--force) mode we must skip the model
        # unless the user has already authenticated (token file exists).
        model_name = str(model_info.get('model', ''))
        if model_name.startswith("github_copilot/") and os.environ.get('PDD_FORCE'):
            token_dir = Path(os.environ.get(
                'GITHUB_COPILOT_TOKEN_DIR',
                str(Path.home() / ".config" / "litellm" / "github_copilot"),
            ))
            api_key_file = os.environ.get('GITHUB_COPILOT_API_KEY_FILE', 'api-key.json')
            token_path = token_dir / api_key_file
            if not token_path.exists():
                logger.warning(
                    f"Skipping GitHub Copilot model '{model_name}' in --force mode: "
                    f"no OAuth token found at {token_path}. Run 'pdd setup' to authenticate."
                )
                return False
        if verbose:
            logger.info(f"Skipping API key check for model {model_info.get('model')} (key field: {api_key_field!r})")
        return True  # Device flow, local model, or handled elsewhere

    env_vars = parse_api_key_vars(api_key_field)

    # --- Multi-credential provider (pipe-delimited) ---
    if len(env_vars) > 1:
        missing = [v for v in env_vars if not os.getenv(v)]
        if not missing:
            if verbose:
                logger.info(f"All {len(env_vars)} env vars set for model {model_info.get('model')}.")
            newly_acquired_keys[api_key_field] = False
            return True

        # Vertex AI fallback: resolve missing VERTEXAI_PROJECT from
        # GOOGLE_CLOUD_PROJECT and missing VERTEXAI_LOCATION from CSV location column
        # (the invocation code already reads CSV location).
        if "GOOGLE_APPLICATION_CREDENTIALS" in env_vars:
            project = os.getenv("VERTEXAI_PROJECT") or os.getenv("GOOGLE_CLOUD_PROJECT")
            has_location = (
                "VERTEXAI_LOCATION" not in missing
                or bool(model_info.get("location"))
            )
            if project and has_location:
                remaining = [
                    v for v in missing
                    if v not in ("GOOGLE_APPLICATION_CREDENTIALS", "VERTEXAI_PROJECT", "VERTEXAI_LOCATION")
                ]
                if not remaining:
                    logger.info(f"Using Vertex AI credentials (project={project}).")
                    newly_acquired_keys[api_key_field] = False
                    return True

        logger.warning(
            f"Multi-credential provider for model '{model_info.get('model')}' "
            f"is missing env vars: {', '.join(missing)}. "
            f"Run 'pdd setup' to configure."
        )
        return False

    # --- Single-credential provider (original behaviour) ---
    key_name = env_vars[0]

    key_value = os.getenv(key_name)
    if key_value:
        key_value = _sanitize_api_key(key_value)

    if key_value:
        if verbose:
            logger.info(f"API key '{key_name}' found in environment.")
        newly_acquired_keys[key_name] = False  # Mark as existing
        return True

    logger.warning(f"API key environment variable '{key_name}' for model '{model_info.get('model')}' is not set.")

    # Vertex AI ADC fallback: when VERTEX_CREDENTIALS is missing but a
    # GCP project is configured, Application Default Credentials (e.g.
    # Cloud Build, GCE metadata, `gcloud auth application-default login`)
    # can authenticate without an explicit key.
    if key_name == "VERTEX_CREDENTIALS":
        project = os.getenv("VERTEXAI_PROJECT") or os.getenv("VERTEX_PROJECT") or os.getenv("GOOGLE_CLOUD_PROJECT")
        if project:
            logger.info(f"Using ADC for Vertex AI (project={project}).")
            newly_acquired_keys[key_name] = False
            return True

    # Skip prompting if --force flag is set (non-interactive mode)
    if os.environ.get('PDD_FORCE'):
        logger.error(f"API key '{key_name}' not set. In --force mode, skipping interactive prompt.")
        return False

    try:
        # Interactive prompt
        user_provided_key = input(f"Please enter the API key for {key_name}: ").strip()
        if not user_provided_key:
            logger.error("No API key provided. Cannot proceed with this model.")
            return False

        # Sanitize the user-provided key
        user_provided_key = _sanitize_api_key(user_provided_key)

        # Set environment variable for the current process
        os.environ[key_name] = user_provided_key
        logger.info(f"API key '{key_name}' set for the current session.")
        newly_acquired_keys[key_name] = True  # Mark as newly acquired

        # Update .env file
        try:
            _save_key_to_env_file(key_name, user_provided_key, ENV_PATH)
            logger.info(f"API key '{key_name}' saved to {ENV_PATH}.")
            logger.warning("SECURITY WARNING: The API key has been saved to your .env file. "
                   "Ensure this file is kept secure and is included in your .gitignore.")

        except IOError as e:
            logger.error(f"Failed to update .env file at {ENV_PATH}: {e}")
            # Continue since the key is set in the environment for this session

        return True

    except EOFError:  # Handle non-interactive environments
         logger.error(f"Cannot prompt for API key '{key_name}' in a non-interactive environment.")
         return False
    except Exception as e:
         logger.error(f"An unexpected error occurred during API key acquisition: {e}")
         return False


def _format_messages(prompt: str, input_data: Union[Dict[str, Any], List[Dict[str, Any]]], use_batch_mode: bool) -> Union[List[Dict[str, str]], List[List[Dict[str, str]]]]:
    """Formats prompt and input into LiteLLM message format."""
    try:
        if use_batch_mode:
            if not isinstance(input_data, list):
                raise ValueError("input_json must be a list of dictionaries when use_batch_mode is True.")
            all_messages = []
            for item in input_data:
                if not isinstance(item, dict):
                     raise ValueError("Each item in input_json list must be a dictionary for batch mode.")
                formatted_prompt = prompt.format(**item)
                all_messages.append([{"role": "user", "content": formatted_prompt}])
            return all_messages
        else:
            if not isinstance(input_data, dict):
                raise ValueError("input_json must be a dictionary when use_batch_mode is False.")
            formatted_prompt = prompt.format(**input_data)
            return [{"role": "user", "content": formatted_prompt}]
    except KeyError as e:
        raise ValueError(f"Prompt formatting error: Missing key {e} in input_json for prompt string.") from e
    except Exception as e:
        raise ValueError(f"Error formatting prompt: {e}") from e

# --- JSON Extraction Helpers ---

def _extract_fenced_json_block(text: str) -> Optional[str]:
    try:
        m = re.search(r"```json\s*(\{[\s\S]*?\})\s*```", text, flags=re.IGNORECASE)
        if m:
            return m.group(1)
        return None
    except Exception:
        return None

def _extract_balanced_json_objects(text: str) -> List[str]:
    results: List[str] = []
    brace_stack = 0
    start_idx = -1
    in_string = False
    escape = False
    for i, ch in enumerate(text):
        if in_string:
            if escape:
                escape = False
            elif ch == '\\':
                escape = True
            elif ch == '"':
                in_string = False
            continue
        else:
            if ch == '"':
                in_string = True
                continue
            if ch == '{':
                if brace_stack == 0:
                    start_idx = i
                brace_stack += 1
            elif ch == '}':
                if brace_stack > 0:
                    brace_stack -= 1
                    if brace_stack == 0 and start_idx != -1:
                        results.append(text[start_idx:i+1])
                        start_idx = -1
    return results


def _looks_like_python_code(s: str) -> bool:
    """
    Heuristic check if a string looks like Python code.

    Used to determine if we should attempt Python syntax repair on a string field.
    """
    if not s or len(s) < 10:
        return False
    # Check for common Python patterns
    code_indicators = ('def ', 'class ', 'import ', 'from ', 'if __name__', 'return ', 'print(')
    return any(indicator in s for indicator in code_indicators)


# Field names known to contain prose text, not Python code
# These are skipped during syntax validation to avoid false positives
_PROSE_FIELD_NAMES = frozenset({
    'reasoning',           # PromptAnalysis - completeness reasoning
    'explanation',         # TrimResultsOutput, FixerOutput - prose explanations
    'analysis',            # DiffAnalysis, CodePatchResult - analysis text
    'change_instructions', # ChangeInstruction, ConflictChange - instructions
    'change_description',  # DiffAnalysis - description of changes
    'planned_modifications', # CodePatchResult - modification plans
    'details',             # VerificationOutput - issue details
    'description',         # General prose descriptions
    'focus',               # Focus descriptions
    'file_summary',        # FileSummary - prose summaries of file contents
})


def _is_prose_field_name(field_name: str) -> bool:
    """Check if a field name indicates it contains prose, not code.

    Used to skip syntax validation on prose fields that may contain
    Python keywords (like 'return' or 'import') but are not actual code.
    """
    return field_name.lower() in _PROSE_FIELD_NAMES


def _repair_python_syntax(code: str) -> str:
    """
    Validate Python code syntax and attempt repairs if invalid.

    Sometimes LLMs include spurious characters at string boundaries,
    especially when the code contains quotes. This function attempts
    to detect and repair such issues.

    Args:
        code: Python code string to validate/repair

    Returns:
        Repaired code if a fix was found, otherwise original code
    """
    import ast

    if not code or not code.strip():
        return code

    # First, try to parse as-is
    try:
        ast.parse(code)
        return code  # Valid, no repair needed
    except SyntaxError:
        pass

    # Try common repairs
    repaired = code

    # Repair 1: Trailing spurious quote (the specific issue we've seen)
    for quote in ['"', "'"]:
        if repaired.rstrip().endswith(quote):
            candidate = repaired.rstrip()[:-1]
            try:
                ast.parse(candidate)
                logger.info(f"[INFO] Repaired code by removing trailing {quote!r}")
                return candidate
            except SyntaxError:
                pass

    # Repair 2: Leading spurious quote
    for quote in ['"', "'"]:
        if repaired.lstrip().startswith(quote):
            candidate = repaired.lstrip()[1:]
            try:
                ast.parse(candidate)
                logger.info(f"[INFO] Repaired code by removing leading {quote!r}")
                return candidate
            except SyntaxError:
                pass

    # Repair 3: Both leading and trailing spurious quotes
    for quote in ['"', "'"]:
        stripped = repaired.strip()
        if stripped.startswith(quote) and stripped.endswith(quote):
            candidate = stripped[1:-1]
            try:
                ast.parse(candidate)
                logger.info(f"[INFO] Repaired code by removing surrounding {quote!r}")
                return candidate
            except SyntaxError:
                pass

    # If no repair worked, return original (let it fail downstream)
    return code


def _smart_unescape_code(code: str) -> str:
    """
    Unescape literal \\n sequences in code while preserving them inside string literals.

    When LLMs return code as JSON, newlines get double-escaped. After JSON parsing,
    we have literal backslash-n (2 chars) that should be actual newlines for code
    structure, BUT escape sequences inside Python strings (like print("\\n")) should
    remain as escape sequences.

    Args:
        code: Python code that may have literal \\n sequences

    Returns:
        Code with structural newlines unescaped but string literals preserved
    """
    LITERAL_BACKSLASH_N = '\\' + 'n'      # Literal \n (2 chars)

    if LITERAL_BACKSLASH_N not in code:
        return code

    # First, check if the code already has actual newlines (mixed state)
    # If it does, we need to be more careful
    has_actual_newlines = '\n' in code

    if not has_actual_newlines:
        # All newlines are escaped - this is the double-escaped case
        # We need to unescape them but preserve \n inside string literals

        # Strategy: Use a placeholder for \n inside strings, unescape all, then restore
        # We detect string literals by tracking quote state

        result = []
        i = 0
        in_string = False
        string_char = None
        in_fstring = False

        # Placeholder that won't appear in code
        PLACEHOLDER = '\x00NEWLINE_ESCAPE\x00'

        while i < len(code):
            # Check for escape sequences (both actual and literal)
            if i + 1 < len(code) and code[i] == '\\':
                next_char = code[i + 1]

                if in_string:
                    # Inside a string - preserve escape sequences
                    if next_char == 'n':
                        result.append(PLACEHOLDER)
                        i += 2
                        continue
                    elif next_char == 't':
                        result.append('\\' + 't')  # Keep \t as-is in strings
                        i += 2
                        continue
                    elif next_char == 'r':
                        result.append('\\' + 'r')  # Keep \r as-is in strings
                        i += 2
                        continue
                    elif next_char in ('"', "'", '\\'):
                        # Keep escaped quotes and backslashes
                        result.append(code[i:i+2])
                        i += 2
                        continue

            # Check for string delimiters
            if not in_string:
                # Check for triple quotes first
                if i + 2 < len(code) and code[i:i+3] in ('"""', "'''"):
                    in_string = True
                    string_char = code[i:i+3]
                    # Check if preceded by 'f' for f-string
                    in_fstring = i > 0 and code[i-1] == 'f'
                    result.append(code[i:i+3])
                    i += 3
                    continue
                elif code[i] in ('"', "'"):
                    in_string = True
                    string_char = code[i]
                    in_fstring = i > 0 and code[i-1] == 'f'
                    result.append(code[i])
                    i += 1
                    continue
            else:
                # Check for end of string
                if len(string_char) == 3:  # Triple quote
                    if i + 2 < len(code) and code[i:i+3] == string_char:
                        in_string = False
                        in_fstring = False
                        result.append(code[i:i+3])
                        i += 3
                        continue
                else:  # Single quote
                    if code[i] == string_char:
                        in_string = False
                        in_fstring = False
                        result.append(code[i])
                        i += 1
                        continue

            result.append(code[i])
            i += 1

        intermediate = ''.join(result)

        # Now unescape all remaining \n (these are structural)
        LITERAL_BACKSLASH_R_N = '\\' + 'r' + '\\' + 'n'
        LITERAL_BACKSLASH_T = '\\' + 't'

        intermediate = intermediate.replace(LITERAL_BACKSLASH_R_N, '\r\n')
        intermediate = intermediate.replace(LITERAL_BACKSLASH_N, '\n')
        intermediate = intermediate.replace(LITERAL_BACKSLASH_T, '\t')

        # Restore placeholders to \n (as escape sequences in strings)
        result_code = intermediate.replace(PLACEHOLDER, '\\n')

        return result_code
    else:
        # Mixed state - some actual newlines, some literal \n
        # This means the JSON parsing already converted some, but not all
        # The literal \n remaining are likely in strings, so leave them alone
        return code


def _unescape_code_newlines(obj: Any) -> Any:
    """
    Fix double-escaped newlines in Pydantic model string fields.

    Some models (e.g., Gemini) return JSON with \\\\n instead of \\n in code strings,
    resulting in literal backslash-n text instead of actual newlines after JSON parsing.
    This function recursively unescapes these in string fields of Pydantic models.

    Also repairs Python syntax errors in code-like string fields (e.g., trailing quotes).

    The check uses literal backslash-n (2 chars) vs actual newline (1 char):
    - '\\\\n' in Python source = literal backslash + n (2 chars) - needs fixing
    - '\\n' in Python source = newline character (1 char) - already correct

    Args:
        obj: A Pydantic model, dict, list, or primitive value

    Returns:
        The same object with string fields unescaped and code fields repaired
    """
    if obj is None:
        return obj

    def _process_string(s: str) -> str:
        """Process a string: unescape newlines and repair Python syntax if needed."""
        result = s
        # Smart unescape that preserves \n inside string literals
        if _looks_like_python_code(result):
            result = _smart_unescape_code(result)
            result = _repair_python_syntax(result)
        else:
            # For non-code strings, do simple unescape
            LITERAL_BACKSLASH_N = '\\' + 'n'
            LITERAL_BACKSLASH_R_N = '\\' + 'r' + '\\' + 'n'
            LITERAL_BACKSLASH_T = '\\' + 't'
            if LITERAL_BACKSLASH_N in result:
                result = result.replace(LITERAL_BACKSLASH_R_N, '\r\n')
                result = result.replace(LITERAL_BACKSLASH_N, '\n')
                result = result.replace(LITERAL_BACKSLASH_T, '\t')
        return result

    # Handle Pydantic models
    if isinstance(obj, BaseModel):
        # Get all field values and process strings
        for field_name in obj.model_fields:
            value = getattr(obj, field_name)
            if isinstance(value, str):
                processed = _process_string(value)
                if processed != value:
                    object.__setattr__(obj, field_name, processed)
            elif isinstance(value, (dict, list, BaseModel)):
                _unescape_code_newlines(value)
        return obj

    # Handle dicts
    if isinstance(obj, dict):
        for key, value in obj.items():
            if isinstance(value, str):
                obj[key] = _process_string(value)
            elif isinstance(value, (dict, list)):
                _unescape_code_newlines(value)
        return obj

    # Handle lists
    if isinstance(obj, list):
        for i, item in enumerate(obj):
            if isinstance(item, str):
                obj[i] = _process_string(item)
            elif isinstance(item, (dict, list, BaseModel)):
                _unescape_code_newlines(item)
        return obj

    return obj


def _has_invalid_python_code(obj: Any, field_name: str = "") -> bool:
    """
    Check if any code-like string fields have invalid Python syntax.

    This is used after _unescape_code_newlines to detect if repair failed
    and we should retry with cache disabled.

    Skips fields in _PROSE_FIELD_NAMES to avoid false positives on prose
    text that mentions code patterns (e.g., "ends on a return statement").

    Args:
        obj: A Pydantic model, dict, list, or primitive value
        field_name: The name of the field being validated (used to skip prose)

    Returns:
        True if there are invalid code fields that couldn't be repaired
    """
    import ast

    if obj is None:
        return False

    if isinstance(obj, str):
        # Skip validation for known prose fields
        if _is_prose_field_name(field_name):
            return False
        if _looks_like_python_code(obj):
            try:
                ast.parse(obj)
                return False  # Valid
            except SyntaxError:
                return True  # Invalid
        return False

    if isinstance(obj, BaseModel):
        for name in obj.model_fields:
            value = getattr(obj, name)
            if _has_invalid_python_code(value, field_name=name):
                return True
        return False

    if isinstance(obj, dict):
        for key, value in obj.items():
            fname = key if isinstance(key, str) else ""
            if _has_invalid_python_code(value, field_name=fname):
                return True
        return False

    if isinstance(obj, list):
        for item in obj:
            if _has_invalid_python_code(item, field_name=field_name):
                return True
        return False

    return False


# --- Main Function ---

def llm_invoke(
    prompt: Optional[str] = None,
    input_json: Optional[Union[Dict[str, Any], List[Dict[str, Any]]]] = None,
    strength: float = 0.5, # Use pdd.DEFAULT_STRENGTH if available, else 0.5
    temperature: float = 0.1,
    verbose: bool = False,
    output_pydantic: Optional[Type[BaseModel]] = None,
    output_schema: Optional[Dict[str, Any]] = None,
    time: Optional[float] = 0.25,
    use_batch_mode: bool = False,
    messages: Optional[Union[List[Dict[str, str]], List[List[Dict[str, str]]]]] = None,
    language: Optional[str] = None,
    use_cloud: Optional[bool] = None,
) -> Dict[str, Any]:
    """
    Runs a prompt with given input using LiteLLM, handling model selection,
    API key acquisition, structured output, batching, and reasoning time.
    The maximum completion token length defaults to the provider's maximum.

    Args:
        prompt: Prompt template string (required if messages is None).
        input_json: Dictionary or list of dictionaries for prompt variables (required if messages is None).
        strength: Model selection strength (0=cheapest, 0.5=base, 1=highest ELO).
        temperature: LLM temperature.
        verbose: Print detailed logs.
        output_pydantic: Optional Pydantic model for structured output.
        output_schema: Optional raw JSON schema dictionary for structured output (alternative to output_pydantic).
        time: Relative thinking time (0-1, default 0.25).
        use_batch_mode: Use batch completion if True.
        messages: Pre-formatted list of messages (or list of lists for batch). If provided, ignores prompt and input_json.
        use_cloud: None=auto-detect (cloud if enabled, local if PDD_FORCE_LOCAL=1), True=force cloud, False=force local.

    Returns:
        Dictionary containing 'result', 'cost', 'model_name', 'thinking_output'.

    Raises:
        ValueError: For invalid inputs or prompt formatting errors.
        FileNotFoundError: If llm_model.csv is missing.
        RuntimeError: If all candidate models fail.
        InsufficientCreditsError: If cloud execution fails due to insufficient credits.
        openai.*Error: If LiteLLM encounters API errors after retries.
    """
    # Set verbose logging if requested
    set_verbose_logging(verbose)
    
    if verbose:
        logger.debug("llm_invoke start - Arguments received:")
        logger.debug(f"  prompt: {'provided' if prompt else 'None'}")
        logger.debug(f"  input_json: {'provided' if input_json is not None else 'None'}")
        logger.debug(f"  strength: {strength}")
        logger.debug(f"  temperature: {temperature}")
        logger.debug(f"  verbose: {verbose}")
        logger.debug(f"  output_pydantic: {output_pydantic.__name__ if output_pydantic else 'None'}")
        logger.debug(f"  time: {time}")
        logger.debug(f"  use_batch_mode: {use_batch_mode}")
        logger.debug(f"  messages: {'provided' if messages else 'None'}")
        logger.debug(f"  use_cloud: {use_cloud}")

    # --- 0. Validate Inputs (before any dispatch) ---
    # Validation runs before cloud dispatch so the ValueError contract holds
    # even when cloud returns a non-fallback error (e.g. InsufficientCreditsError).
    if messages:
        if verbose:
            logger.info("Using provided 'messages' input.")
        # Basic validation of messages format
        if use_batch_mode:
            if not isinstance(messages, list) or not all(isinstance(m_list, list) for m_list in messages):
                 raise ValueError("'messages' must be a list of lists when use_batch_mode is True.")
            if not all(isinstance(msg, dict) and 'role' in msg and 'content' in msg for m_list in messages for msg in m_list):
                 raise ValueError("Each message in the lists within 'messages' must be a dictionary with 'role' and 'content'.")
        else:
            if not isinstance(messages, list) or not all(isinstance(msg, dict) and 'role' in msg and 'content' in msg for msg in messages):
                 raise ValueError("'messages' must be a list of dictionaries with 'role' and 'content'.")
        formatted_messages = messages
    elif prompt and input_json is not None:
         if not isinstance(prompt, str) or not prompt:
             raise ValueError("'prompt' must be a non-empty string when 'messages' is not provided.")
         formatted_messages = _format_messages(prompt, input_json, use_batch_mode)
    else:
        raise ValueError("Either 'messages' or both 'prompt' and 'input_json' must be provided.")

    # --- 1. Cloud Execution Path ---
    # Determine cloud usage: explicit param > environment > default (local)
    if use_cloud is None:
        # Check environment for cloud preference
        # PDD_FORCE_LOCAL=1 forces local execution
        force_local = os.environ.get("PDD_FORCE_LOCAL", "").lower() in ("1", "true", "yes")
        if force_local:
            use_cloud = False
        else:
            # Try to use cloud if credentials are configured
            try:
                from pdd.core.cloud import CloudConfig
                use_cloud = CloudConfig.is_cloud_enabled()
            except ImportError:
                use_cloud = False

    attribution_context = _maybe_build_llm_attribution_context(
        strength=strength,
        temperature=temperature,
        time_value=time,
        use_batch_mode=use_batch_mode,
        use_cloud=use_cloud,
        output_pydantic=output_pydantic,
        output_schema=output_schema,
        language=language,
    )
    _emit_llm_attribution(
        attribution_context,
        "llm_invoke.start",
        input_shape={
            "messages_provided": bool(messages),
            "prompt_provided": bool(prompt),
            "input_json_provided": input_json is not None,
        },
    )

    if use_cloud:
        from rich.console import Console
        console = Console()

        if verbose:
            logger.debug("Attempting cloud execution...")

        try:
            _emit_llm_attribution(attribution_context, "llm_invoke.cloud_dispatch")
            return _llm_invoke_cloud(
                prompt=prompt,
                input_json=input_json,
                strength=strength,
                temperature=temperature,
                verbose=verbose,
                output_pydantic=output_pydantic,
                output_schema=output_schema,
                time=time,
                use_batch_mode=use_batch_mode,
                messages=messages,
                language=language,
            )
        except CloudFallbackError as e:
            # Notify user and fall back to local execution
            console.print(f"[yellow]Cloud execution failed ({e}), falling back to local execution...[/yellow]")
            logger.warning(f"Cloud fallback: {e}")
            _emit_llm_attribution(
                attribution_context,
                "llm_invoke.cloud_fallback",
                **_safe_error_fields(e),
            )
            # Continue to local execution below
        except InsufficientCreditsError:
            # Re-raise credit errors - user needs to know
            _emit_llm_attribution(attribution_context, "llm_invoke.cloud_insufficient_credits")
            raise
        except CloudInvocationError as e:
            # Non-recoverable cloud error - notify and fall back
            console.print(f"[yellow]Cloud error ({e}), falling back to local execution...[/yellow]")
            logger.warning(f"Cloud invocation error: {e}")
            _emit_llm_attribution(
                attribution_context,
                "llm_invoke.cloud_error",
                **_safe_error_fields(e),
            )
            # Continue to local execution below

    # --- 2. Local execution uses already-validated formatted_messages ---

    # Best-effort: precompute a compact representation of the final messages.
    # We'll record (messages, raw_response) after we receive the response.
    trace_prompt_repr: Any = None
    try:
        if not use_batch_mode:
            trace_prompt_repr = formatted_messages
        else:
            # Avoid huge traces for batch requests.
            trace_prompt_repr = None
    except Exception:
        trace_prompt_repr = None

    # Handle None time (means "no reasoning requested")
    if time is None:
        time = 0.0

    if not (0.0 <= strength <= 1.0):
        raise ValueError("'strength' must be between 0.0 and 1.0.")
    if not (0.0 <= temperature <= 2.0): # Common range for temperature
        warnings.warn("'temperature' is outside the typical range (0.0-2.0).")
    if not (0.0 <= time <= 1.0):
        raise ValueError("'time' must be between 0.0 and 1.0.")

    # --- 2. Load Model Data & Select Candidates ---
    try:
        model_df = _load_model_data(LLM_MODEL_CSV_PATH)
        candidate_models = _select_model_candidates(strength, DEFAULT_BASE_MODEL, model_df)
    except (FileNotFoundError, ValueError, RuntimeError) as e:
        logger.error(f"Failed during model loading or selection: {e}")
        _emit_llm_attribution(
            attribution_context,
            "llm_invoke.model_selection_error",
            **_safe_error_fields(e),
        )
        raise

    _emit_llm_attribution(
        attribution_context,
        "llm_invoke.model_candidates",
        candidate_models=[
            {
                "model": str(candidate.get("model")),
                "provider": str(candidate.get("provider", "")),
                "api_key_env_names": _api_key_field_names(candidate.get("api_key")),
                "location": str(candidate.get("location", "")) if pd.notna(candidate.get("location", "")) else "",
            }
            for candidate in candidate_models[:10]
        ],
        candidate_count=len(candidate_models),
    )

    if verbose:
        # This print statement is crucial for the verbose test
        # Calculate and print strength for each candidate model
        # Find min/max for cost and ELO
        min_cost = model_df['avg_cost'].min()
        max_elo = model_df['coding_arena_elo'].max()
        base_cost = model_df[model_df['model'] == DEFAULT_BASE_MODEL]['avg_cost'].iloc[0] if not model_df[model_df['model'] == DEFAULT_BASE_MODEL].empty else min_cost
        base_elo = model_df[model_df['model'] == DEFAULT_BASE_MODEL]['coding_arena_elo'].iloc[0] if not model_df[model_df['model'] == DEFAULT_BASE_MODEL].empty else max_elo
        
        def calc_strength(candidate):
            # If strength < 0.5, interpolate by cost (cheaper = 0, base = 0.5)
            # If strength > 0.5, interpolate by ELO (base = 0.5, highest = 1.0)
            avg_cost = candidate.get('avg_cost', min_cost)
            elo = candidate.get('coding_arena_elo', base_elo)
            if strength < 0.5:
                # Map cost to [0, 0.5]
                if base_cost == min_cost:
                    return 0.5 # Avoid div by zero
                rel = (avg_cost - min_cost) / (base_cost - min_cost)
                return max(0.0, min(0.5, rel * 0.5))
            elif strength > 0.5:
                # Map ELO to [0.5, 1.0]
                if max_elo == base_elo:
                    return 0.5 # Avoid div by zero
                rel = (elo - base_elo) / (max_elo - base_elo)
                return max(0.5, min(1.0, 0.5 + rel * 0.5))
            else:
                return 0.5
        
        model_strengths_formatted = [(c['model'], f"{float(calc_strength(c)):.3f}") for c in candidate_models]
        logger.info("Candidate models selected and ordered (with strength): %s", model_strengths_formatted) # CORRECTED
        logger.info(f"Strength: {strength}, Temperature: {temperature}, Time: {time}")
        if use_batch_mode:
            logger.info("Batch mode enabled.")
        if output_pydantic:
            logger.info(f"Pydantic output requested: {output_pydantic.__name__}")
        try:
            # Only print input_json if it was actually provided (not when messages were used)
            if input_json is not None:
                logger.info("Input JSON:")
                logger.info(input_json) 
            else:
                 logger.info("Input: Using pre-formatted 'messages'.")
        except Exception:
            logger.info("Input JSON/Messages (fallback print):") 
            logger.info(input_json if input_json is not None else "[Messages provided directly]")


    # --- 3. Iterate Through Candidates and Invoke LLM ---
    last_exception = None
    newly_acquired_keys: Dict[str, bool] = {} # Track keys obtained in this run
    
    # Initialize variables for retry section
    response_format = None
    time_kwargs = {}

    # Update global rate map for callback cost fallback
    try:
        _set_model_rate_map(model_df)
    except Exception:
        pass

    attempt_counter = 0

    for model_info in candidate_models:
        model_name_litellm = model_info['model']
        api_key_name = model_info.get('api_key')
        provider = model_info.get('provider', '').lower()

        if verbose:
            logger.info(f"\n[ATTEMPT] Trying model: {model_name_litellm} (Provider: {provider})")

        retry_with_same_model = True
        # Track per-model temperature adjustment attempt (avoid infinite loop)
        current_temperature = temperature
        temp_adjustment_done = False
        while retry_with_same_model:
            retry_with_same_model = False # Assume success unless auth error on new key
            attempt_counter += 1
            request_id = attribution_context.get("request_id", "no-attribution") if attribution_context else "no-attribution"
            attempt_id = f"{request_id}-{attempt_counter}"

            # --- 4. API Key Check & Acquisition ---
            if not _ensure_api_key(model_info, newly_acquired_keys, verbose):
                # Problem getting key, break inner loop, try next model candidate
                _emit_llm_attribution(
                    attribution_context,
                    "llm_invoke.model_skipped",
                    attempt_id=attempt_id,
                    model=str(model_name_litellm),
                    provider=str(provider),
                    api_key_env_names=_api_key_field_names(api_key_name),
                    reason="credential_check_failed",
                )
                if verbose:
                    logger.info(f"[SKIP] Skipping {model_name_litellm} due to API key/credentials issue after prompt.")
                break # Breaks the 'while retry_with_same_model' loop

            # --- 5. Prepare LiteLLM Arguments ---
            litellm_kwargs: Dict[str, Any] = {
                "model": model_name_litellm,
                "messages": copy.deepcopy(formatted_messages),
                # Retry on transient network errors (APIError, TimeoutError, ServiceUnavailableError)
                "num_retries": 2,
            }
            if _model_disallows_temperature(model_name_litellm):
                if verbose:
                    logger.info("[INFO] Skipping 'temperature' for this model; the provider rejects it.")
            else:
                # Use a local adjustable temperature to allow provider-specific fallbacks.
                litellm_kwargs["temperature"] = current_temperature

            # --- Resolve API key / credentials ---
            # The CSV api_key field may be:
            #   - Single env var (e.g. "ANTHROPIC_API_KEY") → pass as api_key=
            #   - Pipe-delimited (e.g. "VAR1|VAR2|VAR3")   → litellm reads from env
            #   - Empty (device flow / local)               → no api_key needed
            from pdd.provider_manager import parse_api_key_vars

            api_key_field = str(model_info.get('api_key', '') or '')
            env_vars = parse_api_key_vars(api_key_field)

            if len(env_vars) == 1:
                # Simple provider: pass env var value as api_key=
                key_value = os.getenv(env_vars[0])
                if key_value:
                    key_value = _sanitize_api_key(key_value)
                    litellm_kwargs["api_key"] = key_value
                    if verbose:
                        logger.info(f"[INFO] Passing API key from '{env_vars[0]}' to LiteLLM.")
                elif verbose:
                    logger.warning(f"[WARN] Env var '{env_vars[0]}' not set. LiteLLM will use default auth.")
            elif len(env_vars) > 1:
                # Multi-credential provider (Bedrock, Azure, Vertex AI, etc.)
                # litellm reads these env vars from os.environ automatically.
                if verbose:
                    logger.info(f"[INFO] Multi-credential provider; litellm reads env vars: {env_vars}")
            else:
                # Empty api_key — device flow (GitHub Copilot) or local model
                if verbose:
                    logger.info(f"[INFO] No API key for '{model_name_litellm}'; using device flow or default auth.")

            # Pass vertex_location from CSV (e.g., "global" for gemini-3-flash-preview)
            location = model_info.get('location')
            if pd.notna(location) and location:
                litellm_kwargs["vertex_location"] = str(location)

            # Add base_url/api_base override if present in CSV
            api_base = model_info.get('base_url')
            if pd.notna(api_base) and api_base:
                # LiteLLM prefers `base_url`; some older paths accept `api_base`.
                litellm_kwargs["base_url"] = str(api_base)
                litellm_kwargs["api_base"] = str(api_base)

            # Enable 1M context window for Claude models via Anthropic beta header.
            # Safe to send for all prompt lengths — the API only charges premium rates
            # when the request actually exceeds 200K tokens.
            if "claude" in model_name_litellm.lower():
                litellm_kwargs["extra_headers"] = {"anthropic-beta": "context-1m-2025-08-07"}
                if verbose:
                    logger.info("[INFO] Added anthropic-beta: context-1m-2025-08-07 header for Claude model.")

            # Provider-specific defaults (e.g., LM Studio)
            model_name_lower = str(model_name_litellm).lower()
            provider_lower_for_model = provider.lower()
            is_lm_studio = model_name_lower.startswith('lm_studio/') or provider_lower_for_model == 'lm_studio'
            is_groq = model_name_lower.startswith('groq/') or provider_lower_for_model == 'groq'
            if is_lm_studio:
                # Ensure base_url is set (fallback to env LM_STUDIO_API_BASE or localhost)
                if not litellm_kwargs.get("base_url"):
                    lm_studio_base = os.getenv("LM_STUDIO_API_BASE", "http://localhost:1234/v1")
                    litellm_kwargs["base_url"] = lm_studio_base
                    litellm_kwargs["api_base"] = lm_studio_base
                    if verbose:
                        logger.info(f"[INFO] Using LM Studio base_url: {lm_studio_base}")

                # Ensure a non-empty api_key; LM Studio accepts any non-empty token (e.g., 'lm-studio')
                if not litellm_kwargs.get("api_key"):
                    lm_studio_key = os.getenv("LM_STUDIO_API_KEY") or "lm-studio"
                    litellm_kwargs["api_key"] = lm_studio_key
                    if verbose:
                        logger.info("[INFO] Using LM Studio api_key placeholder (set LM_STUDIO_API_KEY to customize).")

            # Handle Structured Output (JSON Mode / Pydantic / JSON Schema)
            if output_pydantic or output_schema:
                # Check if model supports structured output based on CSV flag or LiteLLM check
                supports_structured = model_info.get('structured_output', False)
                # Optional: Add litellm.supports_response_schema check if CSV flag is unreliable
                # if not supports_structured:
                #     try: supports_structured = litellm.supports_response_schema(model=model_name_litellm)
                #     except: pass # Ignore errors in supports_response_schema check

                if supports_structured:
                    if output_pydantic:
                        if verbose:
                            logger.info(f"[INFO] Requesting structured output (Pydantic: {output_pydantic.__name__}) for {model_name_litellm}")
                        # Use json_schema with strict=True to enforce ALL required fields are present
                        # This prevents LLMs from omitting required fields when they think they're not needed
                        schema = output_pydantic.model_json_schema()
                        # Ensure all properties are in required array (OpenAI strict mode requirement)
                        _ensure_all_properties_required(schema)
                        # Add additionalProperties: false recursively for strict mode (required by OpenAI)
                        _add_additional_properties_false(schema)
                        response_format = {
                            "type": "json_schema",
                            "json_schema": {
                                "name": output_pydantic.__name__,
                                "schema": schema,
                                "strict": True
                            }
                        }
                    else: # output_schema is set
                        if verbose:
                            logger.info(f"[INFO] Requesting structured output (JSON Schema) for {model_name_litellm}")
                        # LiteLLM expects {"type": "json_schema", "json_schema": {"name": "response", "schema": schema_dict, "strict": true}}
                        # OR for some providers just the schema dict if type is json_object.
                        # Best practice for broad compatibility via LiteLLM is usually the dict directly or wrapped.
                        # For now, let's assume we pass the schema dict as 'response_format' which LiteLLM handles for many providers
                        # or wrap it if needed. LiteLLM 1.40+ supports passing the dict directly for many.
                        response_format = {
                            "type": "json_schema",
                            "json_schema": {
                                "name": "response",
                                "schema": output_schema,
                                "strict": False
                            }
                        }
                        # Ensure all properties are in required array (OpenAI strict mode requirement)
                        _ensure_all_properties_required(response_format["json_schema"]["schema"])
                        # Add additionalProperties: false recursively for strict mode (required by OpenAI)
                        _add_additional_properties_false(response_format["json_schema"]["schema"])

                    litellm_kwargs["response_format"] = response_format

                    # LM Studio requires "json_schema" format, not "json_object"
                    # Use extra_body to bypass litellm.drop_params stripping the schema
                    if is_lm_studio and response_format and response_format.get("type") == "json_object":
                        schema = response_format.get("response_schema", {})
                        lm_studio_response_format = {
                            "type": "json_schema",
                            "json_schema": {
                                "name": "response",
                                "strict": True,
                                "schema": schema
                            }
                        }
                        # Use extra_body to bypass drop_params - passes directly to API
                        litellm_kwargs["extra_body"] = {"response_format": lm_studio_response_format}
                        # Remove from regular response_format to avoid conflicts
                        if "response_format" in litellm_kwargs:
                            del litellm_kwargs["response_format"]
                        if verbose:
                            logger.info(f"[INFO] Using extra_body for LM Studio response_format to bypass drop_params")

                    # Groq has issues with tool-based structured output - use JSON mode with schema in prompt
                    if is_groq and response_format:
                        # Get the schema to include in system prompt
                        if output_pydantic:
                            schema = output_pydantic.model_json_schema()
                        else:
                            schema = output_schema

                        # Use simple json_object mode (Groq's tool_use often fails)
                        litellm_kwargs["response_format"] = {"type": "json_object"}

                        # Prepend schema instruction to messages (json module is imported at top of file)
                        schema_instruction = f"You must respond with valid JSON matching this schema:\n```json\n{json.dumps(schema, indent=2)}\n```\nRespond ONLY with the JSON object, no other text."

                        # Find or create system message to prepend schema
                        messages_list = litellm_kwargs.get("messages", [])
                        if messages_list and messages_list[0].get("role") == "system":
                            messages_list[0]["content"] = schema_instruction + "\n\n" + messages_list[0]["content"]
                        else:
                            messages_list.insert(0, {"role": "system", "content": schema_instruction})
                        litellm_kwargs["messages"] = messages_list

                        if verbose:
                            logger.info(f"[INFO] Using JSON object mode with schema in prompt for Groq (avoiding tool_use issues)")

                    # As a fallback, one could use:
                    # litellm_kwargs["response_format"] = {"type": "json_object"}
                    # And potentially enable client-side validation:
                    # litellm.enable_json_schema_validation = True # Enable globally if needed
                else:
                    schema_name = output_pydantic.__name__ if output_pydantic else "JSON Schema"
                    if verbose:
                        logger.warning(f"[WARN] Model {model_name_litellm} does not support structured output via CSV flag. Output might not be valid {schema_name}.")
                    # Proceed without forcing JSON mode, parsing will be attempted later

            # --- NEW REASONING LOGIC ---
            reasoning_type = model_info.get('reasoning_type', 'none') # Defaults to 'none'
            max_reasoning_tokens_val = model_info.get('max_reasoning_tokens', 0) # Defaults to 0

            if time > 0: # Only apply reasoning if time is requested
                if reasoning_type == 'budget':
                    if max_reasoning_tokens_val > 0:
                        budget = int(time * max_reasoning_tokens_val)
                        if budget > 0:
                            # Currently known: Anthropic uses 'thinking'
                            # Model name comparison is more robust than provider string
                            if provider == 'anthropic': # Check provider column instead of model prefix
                                thinking_param = {"type": "enabled", "budget_tokens": budget}
                                litellm_kwargs["thinking"] = thinking_param
                                time_kwargs["thinking"] = thinking_param
                                if verbose:
                                    logger.info(f"[INFO] Requesting Anthropic thinking (budget type) with budget: {budget} tokens for {model_name_litellm}")
                            else:
                                # If other providers adopt a budget param recognized by LiteLLM, add here
                                if verbose:
                                    logger.warning(f"[WARN] Reasoning type is 'budget' for {model_name_litellm}, but no specific LiteLLM budget parameter known for this provider. Parameter not sent.")
                        elif verbose:
                            logger.info(f"[INFO] Calculated reasoning budget is 0 for {model_name_litellm}, skipping reasoning parameter.")
                    elif verbose:
                        logger.warning(f"[WARN] Reasoning type is 'budget' for {model_name_litellm}, but 'max_reasoning_tokens' is missing or zero in CSV. Reasoning parameter not sent.")

                elif reasoning_type == 'effort':
                    from .reasoning import time_to_effort_level
                    effort = time_to_effort_level(time)

                    # Map effort parameter per-provider/model family
                    model_lower = str(model_name_litellm).lower()
                    provider_lower = str(provider).lower()

                    if provider_lower == 'openai' and model_lower.startswith('gpt-5'):
                        # OpenAI 5-series uses Responses API with nested 'reasoning'
                        reasoning_obj = {"effort": effort, "summary": "auto"}
                        litellm_kwargs["reasoning"] = reasoning_obj
                        time_kwargs["reasoning"] = reasoning_obj
                        if verbose:
                            logger.info(f"[INFO] Requesting OpenAI reasoning.effort='{effort}' for {model_name_litellm} (Responses API)")

                    elif provider_lower == 'openai' and model_lower.startswith('o') and 'mini' not in model_lower:
                        # Historical o* models may use LiteLLM's generic reasoning_effort param
                        litellm_kwargs["reasoning_effort"] = effort
                        time_kwargs["reasoning_effort"] = effort
                        if verbose:
                            logger.info(f"[INFO] Requesting reasoning_effort='{effort}' for {model_name_litellm}")

                    else:
                        # Fallback to LiteLLM generic param when supported by provider adapter
                        litellm_kwargs["reasoning_effort"] = effort
                        time_kwargs["reasoning_effort"] = effort
                        if verbose:
                            logger.info(f"[INFO] Requesting generic reasoning_effort='{effort}' for {model_name_litellm}")

                elif reasoning_type == 'none':
                    if verbose:
                        logger.info(f"[INFO] Model {model_name_litellm} has reasoning_type='none'. No reasoning parameter sent.")

                else: # Unknown reasoning_type in CSV
                     if verbose:
                         logger.warning(f"[WARN] Unknown reasoning_type '{reasoning_type}' for model {model_name_litellm} in CSV. No reasoning parameter sent.")

            # --- END NEW REASONING LOGIC ---

            # Add caching control per call if needed (example: force refresh)
            # litellm_kwargs["cache"] = {"no-cache": True}

            # --- 6. LLM Invocation ---
            try:
                start_time = time_module.time()

                # Log cache status with proper logging
                logger.debug(f"Cache Check: litellm.cache is None: {litellm.cache is None}")
                if litellm.cache is not None:
                    logger.debug(f"litellm.cache type: {type(litellm.cache)}, ID: {id(litellm.cache)}")

                # Only add if litellm.cache is configured
                if litellm.cache is not None:
                    litellm_kwargs["caching"] = True
                    # Workaround for litellm bug where metadata=None causes AttributeError
                    # in caching.py when it tries kwargs.get("metadata", {}).get("redis_namespace")
                    if litellm_kwargs.get("metadata") is None:
                        litellm_kwargs["metadata"] = {}
                    logger.debug("Caching enabled for this request")
                else:
                    logger.debug("NOT ENABLING CACHING: litellm.cache is None at call time")


                # Route OpenAI gpt-5* models through Responses API to support 'reasoning'
                model_lower_for_call = str(model_name_litellm).lower()
                provider_lower_for_call = str(provider).lower()

                if (
                    not use_batch_mode
                    and provider_lower_for_call == 'openai'
                    and model_lower_for_call.startswith('gpt-5')
                ):
                    if verbose:
                        logger.info(f"[INFO] Calling LiteLLM Responses API for {model_name_litellm}...")
                    try:
                        # Build input text from messages
                        if isinstance(formatted_messages, list) and formatted_messages and isinstance(formatted_messages[0], dict):
                            input_text = "\n\n".join(f"{m.get('role','user')}: {m.get('content','')}" for m in formatted_messages)
                        else:
                            # Fallback: string cast
                            input_text = str(formatted_messages)

                        # Derive effort mapping already computed in time_kwargs
                        reasoning_param = time_kwargs.get("reasoning")

                        # Build text.format block for structured output
                        # Default to plain text format
                        text_block = {"format": {"type": "text"}}

                        # If structured output requested, use text.format with json_schema
                        # This is the correct way to enforce structured output via litellm.responses()
                        if output_pydantic or output_schema:
                            try:
                                if output_pydantic:
                                    schema = output_pydantic.model_json_schema()
                                    name = output_pydantic.__name__
                                else:
                                    schema = output_schema
                                    name = "response"

                                # Ensure all properties are in required array (OpenAI strict mode requirement)
                                _ensure_all_properties_required(schema)
                                # Add additionalProperties: false recursively for strict mode (required by OpenAI)
                                _add_additional_properties_false(schema)

                                # Use text.format with json_schema for structured output
                                text_block = {
                                    "format": {
                                        "type": "json_schema",
                                        "name": name,
                                        "strict": True,
                                        "schema": schema,
                                    }
                                }
                                if verbose:
                                    logger.info(f"[INFO] Using structured output via text.format for Responses API")
                            except Exception as schema_e:
                                logger.warning(f"[WARN] Failed to derive JSON schema: {schema_e}. Proceeding with plain text format.")

                        # Build kwargs for litellm.responses()
                        responses_kwargs = {
                            "model": model_name_litellm,
                            "input": input_text,
                            "text": text_block,
                        }
                        if verbose and temperature not in (None, 0, 0.0):
                            logger.info("[INFO] Skipping 'temperature' for OpenAI GPT-5 Responses call (unsupported by API).")
                        if reasoning_param is not None:
                            responses_kwargs["reasoning"] = reasoning_param

                        # Call litellm.responses() which handles the API interaction
                        call_start = time_module.time()
                        _emit_llm_attribution(
                            attribution_context,
                            "llm_invoke.litellm_request",
                            attempt_id=attempt_id,
                            call_type="responses",
                            model=str(model_name_litellm),
                            provider=str(provider),
                            api_key_env_names=_api_key_field_names(api_key_name),
                            kwargs_summary={
                                "model": responses_kwargs.get("model"),
                                "has_reasoning": "reasoning" in responses_kwargs,
                                "has_structured_text_format": text_block.get("format", {}).get("type") == "json_schema",
                            },
                        )
                        resp = litellm.responses(**responses_kwargs)
                        call_duration = time_module.time() - call_start

                        # Extract text result from response
                        result_text = None
                        try:
                            # LiteLLM responses return output as a list of items
                            for item in resp.output:
                                if getattr(item, 'type', None) == 'message' and hasattr(item, 'content') and item.content:
                                    for content_item in item.content:
                                        if hasattr(content_item, 'text'):
                                            result_text = content_item.text
                                            break
                                    if result_text:
                                        break
                        except Exception:
                            result_text = None

                        # Calculate cost using usage + CSV rates
                        total_cost = 0.0
                        usage = getattr(resp, "usage", None)
                        if usage is not None:
                            in_tok = getattr(usage, "input_tokens", 0) or 0
                            out_tok = getattr(usage, "output_tokens", 0) or 0
                            in_rate = model_info.get('input', 0.0) or 0.0
                            out_rate = model_info.get('output', 0.0) or 0.0
                            total_cost = (in_tok * in_rate + out_tok * out_rate) / 1_000_000.0
                        _emit_llm_attribution(
                            attribution_context,
                            "llm_invoke.litellm_response",
                            attempt_id=attempt_id,
                            call_type="responses",
                            model=str(model_name_litellm),
                            duration_seconds=round(call_duration, 3),
                            usage={
                                "prompt_tokens": getattr(usage, "input_tokens", 0) if usage is not None else 0,
                                "completion_tokens": getattr(usage, "output_tokens", 0) if usage is not None else 0,
                            },
                            cost=total_cost,
                        )

                        # Parse result if Pydantic output requested
                        final_result = None
                        if output_pydantic and result_text:
                            try:
                                final_result = _validate_pydantic_with_unwrap(result_text, output_pydantic)
                            except Exception as e:
                                # With structured output, parsing should succeed
                                # But if it fails, try JSON repair as fallback
                                logger.warning(f"[WARN] Pydantic parse failed on Responses output: {e}. Attempting JSON repair...")

                                # Try extracting from fenced JSON blocks first
                                fenced = _extract_fenced_json_block(result_text)
                                candidates: List[str] = []
                                if fenced:
                                    candidates.append(fenced)
                                else:
                                    candidates.extend(_extract_balanced_json_objects(result_text))

                                # Also try the raw text as-is after stripping fences
                                cleaned = result_text.strip()
                                if cleaned.startswith("```json"):
                                    cleaned = cleaned[7:]
                                elif cleaned.startswith("```"):
                                    cleaned = cleaned[3:]
                                if cleaned.endswith("```"):
                                    cleaned = cleaned[:-3]
                                cleaned = cleaned.strip()
                                if cleaned and cleaned not in candidates:
                                    candidates.append(cleaned)

                                parse_succeeded = False
                                for cand in candidates:
                                    try:
                                        final_result = _validate_pydantic_with_unwrap(cand, output_pydantic)
                                        parse_succeeded = True
                                        logger.info(f"[SUCCESS] JSON repair succeeded for Responses output")
                                        break
                                    except Exception:
                                        continue

                                if not parse_succeeded:
                                    logger.error(f"[ERROR] All JSON repair attempts failed for Responses output. Original error: {e}")
                                    final_result = f"ERROR: Failed to parse structured output from Responses API. Raw: {repr(result_text)[:200]}"
                        else:
                            final_result = result_text

                        if verbose:
                            logger.info(f"[RESULT] Model Used: {model_name_litellm}")
                            logger.info(f"[RESULT] Total Cost (estimated): ${total_cost:.6g}")

                        _emit_llm_attribution(
                            attribution_context,
                            "llm_invoke.success",
                            attempt_id=attempt_id,
                            model=str(model_name_litellm),
                            provider=str(provider),
                            cost=total_cost,
                            call_type="responses",
                        )
                        return {
                            'result': final_result,
                            'cost': total_cost,
                            'model_name': model_name_litellm,
                            'thinking_output': None,
                        }
                    except Exception as e:
                        last_exception = e
                        _emit_llm_attribution(
                            attribution_context,
                            "llm_invoke.litellm_error",
                            attempt_id=attempt_id,
                            call_type="responses",
                            model=str(model_name_litellm),
                            provider=str(provider),
                            **_safe_error_fields(e),
                        )
                        logger.error(f"[ERROR] OpenAI Responses call failed for {model_name_litellm}: {e}")
                        # Remove 'reasoning' key to avoid OpenAI Chat API unknown param errors
                        if "reasoning" in litellm_kwargs:
                            try:
                                litellm_kwargs.pop("reasoning", None)
                            except Exception:
                                pass
                        # Fall through to LiteLLM path as a fallback

                # --- Context Window Validation ---
                token_count_for_attribution = None
                context_limit_for_attribution = None
                try:
                    messages_for_count = litellm_kwargs.get("messages", [])
                    token_count = litellm.token_counter(model=model_name_litellm, messages=messages_for_count)
                    context_limit = get_context_limit(model_name_litellm)
                    token_count_for_attribution = token_count
                    context_limit_for_attribution = context_limit

                    # If the Claude 1M beta header is active, honour it as the effective limit
                    extra_headers = litellm_kwargs.get("extra_headers", {})
                    if (context_limit is not None
                            and "anthropic-beta" in extra_headers
                            and "context-1m" in extra_headers.get("anthropic-beta", "")):
                        context_limit = 1_000_000
                        context_limit_for_attribution = context_limit

                    if context_limit is None:
                        if verbose:
                            logger.debug(
                                f"[CONTEXT] Context limit unknown for {model_name_litellm}; "
                                f"skipping validation. Token count: {token_count:,}"
                            )
                    else:
                        usage_pct = (token_count / context_limit) * 100

                        if token_count > context_limit:
                            logger.error(
                                f"[CONTEXT] Prompt ({token_count:,} tokens) exceeds {model_name_litellm} "
                                f"context limit ({context_limit:,} tokens, {usage_pct:.1f}% usage). "
                                f"Trying next model."
                            )
                            last_exception = RuntimeError(
                                f"Prompt ({token_count:,} tokens) exceeds {model_name_litellm} "
                                f"context limit ({context_limit:,} tokens)"
                            )
                            break  # try next candidate model

                        if verbose and usage_pct > 90:
                            logger.warning(
                                f"[CONTEXT] Prompt is {usage_pct:.1f}% of {model_name_litellm} context "
                                f"({token_count:,}/{context_limit:,} tokens)"
                            )
                        elif verbose:
                            logger.info(
                                f"[CONTEXT] Token count: {token_count:,}/{context_limit:,} "
                                f"({usage_pct:.1f}%) for {model_name_litellm}"
                            )
                except Exception as ctx_err:
                    if verbose:
                        logger.debug(f"[CONTEXT] Token validation skipped: {ctx_err}")

                call_type_for_attribution = "batch_completion" if use_batch_mode else "completion"
                _emit_llm_attribution(
                    attribution_context,
                    "llm_invoke.litellm_request",
                    attempt_id=attempt_id,
                    call_type=call_type_for_attribution,
                    model=str(model_name_litellm),
                    provider=str(provider),
                    api_key_env_names=_api_key_field_names(api_key_name),
                    kwargs_summary=_summarize_litellm_kwargs(litellm_kwargs),
                    token_count=token_count_for_attribution,
                    context_limit=context_limit_for_attribution,
                )

                if use_batch_mode:
                    if verbose:
                        logger.info(f"[INFO] Calling litellm.batch_completion for {model_name_litellm}...")
                    response = litellm.batch_completion(**litellm_kwargs)


                else:
                    # Claude requirement: when thinking/reasoning is enabled, temperature must be 1.
                    # Check model name (not provider) to cover both direct Anthropic and Vertex AI Claude.
                    # Check both 'thinking' and 'reasoning_effort' because litellm translates
                    # reasoning_effort to thinking internally during transform_request.
                    try:
                        is_claude_model = 'claude' in model_name_litellm.lower()
                        has_thinking_or_reasoning = 'thinking' in litellm_kwargs or 'reasoning_effort' in litellm_kwargs
                        if is_claude_model and has_thinking_or_reasoning and 'temperature' in litellm_kwargs:
                            if litellm_kwargs.get('temperature') != 1:
                                if verbose:
                                    logger.info("[INFO] Claude with thinking/reasoning enabled: forcing temperature=1 for compliance.")
                                litellm_kwargs['temperature'] = 1
                                current_temperature = 1
                    except Exception:
                        pass
                    # Gemini 3 requirement: temperature < 1.0 causes infinite loops and
                    # degraded reasoning. Force temperature=1 for all Gemini 3+ models.
                    try:
                        if 'gemini-3' in model_name_litellm.lower() and litellm_kwargs.get('temperature', 0) < 1:
                            if verbose:
                                logger.info(f"[INFO] Gemini 3 model detected: forcing temperature=1 (was {litellm_kwargs.get('temperature')}).")
                            litellm_kwargs['temperature'] = 1
                            current_temperature = 1
                    except Exception:
                        pass
                    if verbose:
                        logger.info(f"[INFO] Calling litellm.completion for {model_name_litellm}...")
                    response = litellm.completion(**litellm_kwargs, timeout=LLM_CALL_TIMEOUT)

                end_time = time_module.time()
                _emit_llm_attribution(
                    attribution_context,
                    "llm_invoke.litellm_response",
                    attempt_id=attempt_id,
                    call_type=call_type_for_attribution,
                    model=str(model_name_litellm),
                    provider=str(provider),
                    duration_seconds=round(end_time - start_time, 3),
                    usage=_response_usage_summary(response),
                )

                if verbose:
                    logger.info(f"[SUCCESS] Invocation successful for {model_name_litellm} (took {end_time - start_time:.2f}s)")

                # Build retry kwargs with provider credentials from litellm_kwargs
                retry_provider_kwargs = {k: v for k, v in litellm_kwargs.items()
                                         if k in ('api_key', 'base_url', 'api_base',
                                                  'api_version')}

                # --- 7. Process Response ---
                results = []
                thinking_outputs = []

                response_list = response if use_batch_mode else [response]

                for i, resp_item in enumerate(response_list):
                    # Cost calculation is handled entirely by the success callback

                    # Thinking Output
                    thinking = None
                    try:
                        # Attempt 1: Check _hidden_params based on isolated test script
                        if hasattr(resp_item, '_hidden_params') and resp_item._hidden_params and 'thinking' in resp_item._hidden_params:
                             thinking = resp_item._hidden_params['thinking']
                             if verbose:
                                 logger.debug("[DEBUG] Extracted thinking output from response._hidden_params['thinking']")
                        # Attempt 2: Fallback to reasoning_content in message
                        # Use .get() for safer access
                        elif hasattr(resp_item, 'choices') and resp_item.choices and hasattr(resp_item.choices[0], 'message') and hasattr(resp_item.choices[0].message, 'get') and resp_item.choices[0].message.get('reasoning_content'):
                            thinking = resp_item.choices[0].message.get('reasoning_content')
                            if verbose:
                                logger.debug("[DEBUG] Extracted thinking output from response.choices[0].message.get('reasoning_content')")

                    except (AttributeError, IndexError, KeyError, TypeError):
                        if verbose:
                            logger.debug("[DEBUG] Failed to extract thinking output from known locations.")
                        pass # Ignore if structure doesn't match or errors occur
                    thinking_outputs.append(thinking)

                    # Result (String or Pydantic)
                    try:
                        raw_result = resp_item.choices[0].message.content
                        # Record the last (prompt, raw response) pair for the current operation.
                        if _record_llm_pair is not None and trace_prompt_repr is not None:
                            try:
                                _record_llm_pair(
                                    prompt=trace_prompt_repr,
                                    response=raw_result,
                                    model=str(model_name_litellm),
                                )
                            except Exception:
                                pass
                        
                        # Check if raw_result is None (likely cached corrupted data)
                        if raw_result is None:
                            logger.warning(f"[WARNING] LLM returned None content for item {i}, likely due to corrupted cache. Retrying with cache bypass...")
                            # Retry with cache bypass by modifying the prompt slightly
                            if not use_batch_mode and prompt and input_json is not None:
                                # Add a small space to bypass cache
                                modified_prompt = prompt + " "
                                try:
                                    retry_messages = _format_messages(modified_prompt, input_json, use_batch_mode)
                                    # Disable cache for retry
                                    litellm.cache = None
                                    # Issue #509: Save accumulated cost/tokens before retry overwrites callback data
                                    _accumulated_cost = _LAST_CALLBACK_DATA.get("cost", 0.0)
                                    _accumulated_input_tokens = _LAST_CALLBACK_DATA.get("input_tokens", 0)
                                    _accumulated_output_tokens = _LAST_CALLBACK_DATA.get("output_tokens", 0)
                                    try:
                                        retry_kwargs = {
                                            "model": model_name_litellm,
                                            "messages": retry_messages,
                                            "temperature": current_temperature,
                                            "response_format": response_format,
                                            "timeout": LLM_CALL_TIMEOUT,
                                            **time_kwargs,
                                            **retry_provider_kwargs,  # Issue #185: Pass Vertex AI credentials
                                        }
                                        if _model_disallows_temperature(model_name_litellm):
                                            retry_kwargs.pop("temperature", None)
                                        retry_response = _completion_with_attribution(
                                            context=attribution_context,
                                            attempt_id=attempt_id,
                                            call_type="completion_retry_cache_bypass",
                                            model=str(model_name_litellm),
                                            provider=str(provider),
                                            api_key_name=api_key_name,
                                            kwargs=retry_kwargs,
                                        )
                                    finally:
                                        # Always restore cache, even if retry raises
                                        litellm.cache = configured_cache
                                    # Issue #509: Accumulate cost/tokens from original call + retry
                                    _LAST_CALLBACK_DATA["cost"] = _LAST_CALLBACK_DATA.get("cost", 0.0) + _accumulated_cost
                                    _LAST_CALLBACK_DATA["input_tokens"] = _LAST_CALLBACK_DATA.get("input_tokens", 0) + _accumulated_input_tokens
                                    _LAST_CALLBACK_DATA["output_tokens"] = _LAST_CALLBACK_DATA.get("output_tokens", 0) + _accumulated_output_tokens
                                    # Extract result from retry
                                    retry_raw_result = retry_response.choices[0].message.content
                                    if _record_llm_pair is not None and trace_prompt_repr is not None:
                                        try:
                                            _record_llm_pair(
                                                prompt=trace_prompt_repr,
                                                response=retry_raw_result,
                                                model=str(model_name_litellm),
                                            )
                                        except Exception:
                                            pass
                                    if retry_raw_result is not None:
                                        logger.info(f"[SUCCESS] Cache bypass retry succeeded for item {i}")
                                        raw_result = retry_raw_result
                                    else:
                                        logger.error(f"[ERROR] Cache bypass retry also returned None for item {i}")
                                        results.append("ERROR: LLM returned None content even after cache bypass")
                                        continue
                                except Exception as retry_e:
                                    logger.error(f"[ERROR] Cache bypass retry failed for item {i}: {retry_e}")
                                    results.append(f"ERROR: LLM returned None content and retry failed: {retry_e}")
                                    continue
                            else:
                                logger.error(f"[ERROR] Cannot retry - batch mode or missing prompt/input_json")
                                results.append("ERROR: LLM returned None content and cannot retry")
                                continue

                        # Check for malformed JSON response (excessive trailing newlines causing truncation)
                        # This can happen when Gemini generates thousands of \n in JSON string values
                        if isinstance(raw_result, str) and _is_malformed_json_response(raw_result):
                            logger.warning(f"[WARNING] Detected malformed JSON response with excessive trailing newlines for item {i}. Retrying with cache bypass...")
                            if not use_batch_mode and prompt and input_json is not None:
                                # Add a small space to bypass cache
                                modified_prompt = prompt + " "
                                try:
                                    retry_messages = _format_messages(modified_prompt, input_json, use_batch_mode)
                                    # Disable cache for retry
                                    original_cache = litellm.cache
                                    litellm.cache = None
                                    # Issue #509: Save accumulated cost/tokens before retry overwrites callback data
                                    _accumulated_cost = _LAST_CALLBACK_DATA.get("cost", 0.0)
                                    _accumulated_input_tokens = _LAST_CALLBACK_DATA.get("input_tokens", 0)
                                    _accumulated_output_tokens = _LAST_CALLBACK_DATA.get("output_tokens", 0)
                                    try:
                                        retry_kwargs = {
                                            "model": model_name_litellm,
                                            "messages": retry_messages,
                                            "temperature": current_temperature,
                                            "response_format": response_format,
                                            "timeout": LLM_CALL_TIMEOUT,
                                            **time_kwargs,
                                            **retry_provider_kwargs,  # Issue #185: Pass Vertex AI credentials
                                        }
                                        if _model_disallows_temperature(model_name_litellm):
                                            retry_kwargs.pop("temperature", None)
                                        retry_response = _completion_with_attribution(
                                            context=attribution_context,
                                            attempt_id=attempt_id,
                                            call_type="completion_retry_malformed_json",
                                            model=str(model_name_litellm),
                                            provider=str(provider),
                                            api_key_name=api_key_name,
                                            kwargs=retry_kwargs,
                                        )
                                    finally:
                                        # Always restore cache, even if retry raises
                                        litellm.cache = original_cache
                                    # Issue #509: Accumulate cost/tokens from original call + retry
                                    _LAST_CALLBACK_DATA["cost"] = _LAST_CALLBACK_DATA.get("cost", 0.0) + _accumulated_cost
                                    _LAST_CALLBACK_DATA["input_tokens"] = _LAST_CALLBACK_DATA.get("input_tokens", 0) + _accumulated_input_tokens
                                    _LAST_CALLBACK_DATA["output_tokens"] = _LAST_CALLBACK_DATA.get("output_tokens", 0) + _accumulated_output_tokens
                                    # Extract result from retry
                                    retry_raw_result = retry_response.choices[0].message.content
                                    if retry_raw_result is not None and not _is_malformed_json_response(retry_raw_result):
                                        logger.info(f"[SUCCESS] Cache bypass retry for malformed JSON succeeded for item {i}")
                                        raw_result = retry_raw_result
                                    else:
                                        # Retry also failed, but we'll continue with repair logic below
                                        logger.warning(f"[WARNING] Cache bypass retry also returned malformed JSON for item {i}, attempting repair...")
                                except Exception as retry_e:
                                    logger.warning(f"[WARNING] Cache bypass retry for malformed JSON failed for item {i}: {retry_e}, attempting repair...")
                            else:
                                logger.warning(f"[WARNING] Cannot retry malformed JSON - batch mode or missing prompt/input_json, attempting repair...")

                        if output_pydantic or output_schema:
                            parsed_result = None
                            json_string_to_parse = None

                            try:
                                # Attempt 1: Check if LiteLLM already parsed it (only for Pydantic)
                                if output_pydantic and isinstance(raw_result, output_pydantic):
                                    parsed_result = raw_result
                                    if verbose:
                                        logger.debug("[DEBUG] Pydantic object received directly from LiteLLM.")

                                # Attempt 2: Check if raw_result is dict-like and validate
                                elif isinstance(raw_result, dict):
                                    if output_pydantic:
                                        parsed_result = _validate_pydantic_with_unwrap(raw_result, output_pydantic)
                                    else:
                                        # Validate against JSON schema (with envelope unwrap for Vertex Anthropic).
                                        # The helper returns the validated payload — either ``raw_result``
                                        # itself or the inner dict when the ``{"parameter": {...}}`` envelope
                                        # was peeled off. Serializing ``raw_result`` directly would leak the
                                        # wrapper into the caller's response.
                                        try:
                                            validated = _validate_jsonschema_with_unwrap(raw_result, output_schema)
                                            parsed_result = json.dumps(validated)  # Return as JSON string for consistency
                                        except ImportError:
                                            logger.warning("jsonschema not installed, skipping validation")
                                            parsed_result = json.dumps(raw_result)
                                    
                                    if verbose:
                                        logger.debug("[DEBUG] Validated dictionary-like object directly.")

                                # Attempt 3: Process as string (if not already parsed/validated)
                                elif isinstance(raw_result, str):
                                    json_string_to_parse = raw_result # Start with the raw string
                                    try:
                                        # 1) Prefer fenced ```json blocks
                                        fenced = _extract_fenced_json_block(raw_result)
                                        candidates: List[str] = []
                                        if fenced:
                                            candidates.append(fenced)
                                        else:
                                            # 2) Fall back to scanning for balanced JSON objects
                                            candidates.extend(_extract_balanced_json_objects(raw_result))

                                        if not candidates:
                                            raise ValueError("No JSON-like content found")

                                        parse_err: Optional[Exception] = None
                                        for cand in candidates:
                                            try:
                                                if verbose:
                                                    logger.debug(f"[DEBUG] Attempting to parse candidate JSON block: {cand}")
                                                
                                                if output_pydantic:
                                                    parsed_result = _validate_pydantic_with_unwrap(cand, output_pydantic)
                                                else:
                                                    # Parse JSON and validate against schema (with envelope unwrap).
                                                    # Use the validated payload returned by the helper: when the
                                                    # ``{"parameter": {...}}`` envelope was peeled, ``cand`` still
                                                    # carries the wrapper, so we must re-serialize the unwrapped
                                                    # form. When no unwrap was needed, keep ``cand`` byte-for-byte
                                                    # to preserve the original whitespace/key order.
                                                    loaded = json.loads(cand)
                                                    try:
                                                        validated = _validate_jsonschema_with_unwrap(loaded, output_schema)
                                                        parsed_result = cand if validated is loaded else json.dumps(validated)
                                                    except ImportError:
                                                        parsed_result = cand # Skip validation if lib missing

                                                json_string_to_parse = cand
                                                parse_err = None
                                                break
                                            except (json.JSONDecodeError, ValidationError, ValueError) as pe:
                                                # Also catch jsonschema.ValidationError if imported
                                                parse_err = pe
                                                try:
                                                    import jsonschema
                                                    if isinstance(pe, jsonschema.ValidationError):
                                                        parse_err = pe
                                                except ImportError:
                                                    pass

                                        if parsed_result is None:
                                            # If none of the candidates parsed, raise last error
                                            if parse_err is not None:
                                                raise parse_err
                                            raise ValueError("Unable to parse any JSON candidates")
                                    except (json.JSONDecodeError, ValidationError, ValueError, Exception) as extraction_error:
                                        # Catch generic Exception to handle jsonschema errors without explicit import here
                                        if verbose:
                                            logger.debug(f"[DEBUG] JSON extraction/validation failed ('{extraction_error}'). Trying fence cleaning.")
                                        # Last resort: strip any leading/trailing code fences and retry
                                        cleaned_result_str = raw_result.strip()
                                        if cleaned_result_str.startswith("```json"):
                                            cleaned_result_str = cleaned_result_str[7:]
                                        elif cleaned_result_str.startswith("```"):
                                            cleaned_result_str = cleaned_result_str[3:]
                                        if cleaned_result_str.endswith("```"):
                                            cleaned_result_str = cleaned_result_str[:-3]
                                        cleaned_result_str = cleaned_result_str.strip()
                                        # Check for complete JSON object or array
                                        is_complete_object = cleaned_result_str.startswith('{') and cleaned_result_str.endswith('}')
                                        is_complete_array = cleaned_result_str.startswith('[') and cleaned_result_str.endswith(']')
                                        if is_complete_object or is_complete_array:
                                            if verbose:
                                                logger.debug(f"[DEBUG] Attempting parse after generic fence cleaning. Cleaned string: '{cleaned_result_str}'")
                                            json_string_to_parse = cleaned_result_str

                                            if output_pydantic:
                                                parsed_result = _validate_pydantic_with_unwrap(json_string_to_parse, output_pydantic)
                                            else:
                                                # Use the validated payload from the helper so the unwrapped
                                                # form is what callers see — see helper docstring.
                                                loaded = json.loads(json_string_to_parse)
                                                try:
                                                    validated = _validate_jsonschema_with_unwrap(loaded, output_schema)
                                                    parsed_result = json_string_to_parse if validated is loaded else json.dumps(validated)
                                                except ImportError:
                                                    parsed_result = json_string_to_parse
                                        elif cleaned_result_str.startswith('{') or cleaned_result_str.startswith('['):
                                            # Attempt to repair truncated JSON (e.g., missing closing braces)
                                            # This can happen when Gemini generates excessive trailing content
                                            # that causes token limit truncation
                                            if verbose:
                                                logger.debug(f"[DEBUG] JSON appears truncated (missing closing brace). Attempting repair.")

                                            # Try to find the last valid JSON structure
                                            # For simple schemas like {"extracted_code": "..."}, we can try to close it
                                            repaired = cleaned_result_str.rstrip()

                                            # Strip trailing escaped newline sequences (\\n in the JSON string)
                                            # These appear as literal backslash-n when Gemini generates excessive newlines
                                            while repaired.endswith('\\n'):
                                                repaired = repaired[:-2]
                                            # Also strip trailing literal backslashes that might be orphaned
                                            repaired = repaired.rstrip('\\')

                                            # If we're in the middle of a string value, try to close it
                                            # Count unescaped quotes to determine if we're inside a string
                                            # Simple heuristic: if it ends without proper closure, add closing
                                            is_array = cleaned_result_str.startswith('[')
                                            expected_end = ']' if is_array else '}'
                                            if not repaired.endswith(expected_end):
                                                # Try adding various closures to repair
                                                if is_array:
                                                    repair_attempts = [
                                                        repaired + '}]',  # Close object and array
                                                        repaired + '"}]',  # Close string, object and array
                                                        repaired + '"}}]',  # Close string, nested object and array
                                                        repaired.rstrip(',') + ']',  # Remove trailing comma and close array
                                                        repaired.rstrip('"') + '"}]',  # Handle partial string end
                                                    ]
                                                else:
                                                    repair_attempts = [
                                                        repaired + '"}',  # Close string and object
                                                        repaired + '"}\n}',  # Close string and nested object
                                                        repaired + '"}}}',  # Deeper nesting
                                                        repaired.rstrip(',') + '}',  # Remove trailing comma
                                                        repaired.rstrip('"') + '"}',  # Handle partial string end
                                                    ]

                                                for attempt in repair_attempts:
                                                    try:
                                                        if output_pydantic:
                                                            parsed_result = _validate_pydantic_with_unwrap(attempt, output_pydantic)
                                                        else:
                                                            # Use the validated payload from the helper — see
                                                            # helper docstring on why ``attempt`` cannot be used
                                                            # directly when an unwrap occurred.
                                                            loaded = json.loads(attempt)
                                                            try:
                                                                validated = _validate_jsonschema_with_unwrap(loaded, output_schema)
                                                                parsed_result = attempt if validated is loaded else json.dumps(validated)
                                                            except ImportError:
                                                                parsed_result = attempt

                                                        if verbose:
                                                            logger.info(f"[INFO] Successfully repaired truncated JSON response")
                                                        json_string_to_parse = attempt
                                                        break
                                                    except (json.JSONDecodeError, ValidationError, ValueError):
                                                        continue

                                                if parsed_result is None:
                                                    raise ValueError("Content after cleaning doesn't look like JSON (and repair attempts failed)")
                                        else:
                                            raise ValueError("Content after cleaning doesn't look like JSON")


                                # Check if any parsing attempt succeeded
                                if parsed_result is None:
                                    target_name = output_pydantic.__name__ if output_pydantic else "JSON Schema"
                                    # This case should ideally be caught by exceptions above, but as a safeguard:
                                    raise TypeError(f"Raw result type {type(raw_result)} or content could not be validated/parsed against {target_name}.")

                            except (ValidationError, json.JSONDecodeError, TypeError, ValueError, Exception) as parse_error:
                                target_name = output_pydantic.__name__ if output_pydantic else "JSON Schema"
                                logger.error(f"[ERROR] Failed to parse response into {target_name} for item {i}: {parse_error}")
                                # Use the string that was last attempted for parsing in the error message
                                error_content = json_string_to_parse if json_string_to_parse is not None else raw_result
                                logger.error("[ERROR] Content attempted for parsing: %s", repr(error_content))
                                # Issue #168: Raise SchemaValidationError to trigger model fallback
                                # Previously this used `continue` which only skipped to the next batch item
                                raise SchemaValidationError(
                                    f"Failed to parse response into {target_name}: {parse_error}",
                                    raw_response=raw_result,
                                    item_index=i
                                ) from parse_error

                            # Post-process: unescape newlines and repair Python syntax
                            _unescape_code_newlines(parsed_result)

                            # Check if code fields still have invalid Python syntax after repair
                            # If so, retry without cache to get a fresh response
                            # Skip validation for non-Python languages to avoid false positives
                            if language in (None, "python") and _has_invalid_python_code(parsed_result):
                                logger.warning(f"[WARNING] Detected invalid Python syntax in code fields for item {i} after repair. Retrying with cache bypass...")
                                if not use_batch_mode and prompt and input_json is not None:
                                    # Add a small variation to bypass cache
                                    modified_prompt = prompt + "  "  # Two spaces to differentiate from other retries
                                    try:
                                        retry_messages = _format_messages(modified_prompt, input_json, use_batch_mode)
                                        # Disable cache for retry
                                        original_cache = litellm.cache
                                        litellm.cache = None
                                        # Issue #509: Save accumulated cost/tokens before retry overwrites callback data
                                        _accumulated_cost = _LAST_CALLBACK_DATA.get("cost", 0.0)
                                        _accumulated_input_tokens = _LAST_CALLBACK_DATA.get("input_tokens", 0)
                                        _accumulated_output_tokens = _LAST_CALLBACK_DATA.get("output_tokens", 0)
                                        try:
                                            retry_kwargs = {
                                                "model": model_name_litellm,
                                                "messages": retry_messages,
                                                "temperature": current_temperature,
                                                "response_format": response_format,
                                                "timeout": LLM_CALL_TIMEOUT,
                                                **time_kwargs,
                                                **retry_provider_kwargs,  # Issue #185: Pass Vertex AI credentials
                                            }
                                            if _model_disallows_temperature(model_name_litellm):
                                                retry_kwargs.pop("temperature", None)
                                            retry_response = _completion_with_attribution(
                                                context=attribution_context,
                                                attempt_id=attempt_id,
                                                call_type="completion_retry_invalid_python",
                                                model=str(model_name_litellm),
                                                provider=str(provider),
                                                api_key_name=api_key_name,
                                                kwargs=retry_kwargs,
                                            )
                                        finally:
                                            # Always restore cache, even if retry raises
                                            litellm.cache = original_cache
                                        # Issue #509: Accumulate cost/tokens from original call + retry
                                        _LAST_CALLBACK_DATA["cost"] = _LAST_CALLBACK_DATA.get("cost", 0.0) + _accumulated_cost
                                        _LAST_CALLBACK_DATA["input_tokens"] = _LAST_CALLBACK_DATA.get("input_tokens", 0) + _accumulated_input_tokens
                                        _LAST_CALLBACK_DATA["output_tokens"] = _LAST_CALLBACK_DATA.get("output_tokens", 0) + _accumulated_output_tokens
                                        # Extract and re-parse the retry result
                                        retry_raw_result = retry_response.choices[0].message.content
                                        if retry_raw_result is not None:
                                            # Re-parse the retry result
                                            retry_parsed = None
                                            if output_pydantic:
                                                if isinstance(retry_raw_result, output_pydantic):
                                                    retry_parsed = retry_raw_result
                                                elif isinstance(retry_raw_result, (dict, str)):
                                                    retry_parsed = _validate_pydantic_with_unwrap(retry_raw_result, output_pydantic)
                                            elif output_schema and isinstance(retry_raw_result, str):
                                                retry_parsed = retry_raw_result  # Keep as string for schema validation

                                            if retry_parsed is not None:
                                                _unescape_code_newlines(retry_parsed)
                                                if not _has_invalid_python_code(retry_parsed):
                                                    logger.info(f"[SUCCESS] Cache bypass retry for invalid Python code succeeded for item {i}")
                                                    parsed_result = retry_parsed
                                                else:
                                                    logger.warning(f"[WARNING] Cache bypass retry still has invalid Python code for item {i}, using original")
                                            else:
                                                logger.warning(f"[WARNING] Cache bypass retry returned unparseable result for item {i}")
                                        else:
                                            logger.warning(f"[WARNING] Cache bypass retry returned None for item {i}")
                                    except Exception as retry_e:
                                        logger.warning(f"[WARNING] Cache bypass retry for invalid Python code failed for item {i}: {retry_e}")
                                else:
                                    logger.warning(f"[WARNING] Cannot retry invalid Python code - batch mode or missing prompt/input_json")

                            results.append(parsed_result)

                        else:
                            # If output_pydantic/schema was not requested, append the raw result
                            results.append(raw_result)

                    except (AttributeError, IndexError) as e:
                         logger.error(f"[ERROR] Could not extract result content from response item {i}: {e}")
                         results.append(f"ERROR: Could not extract result content. Response: {resp_item}")

                # --- Retrieve Cost from Callback Data --- (Reinstated)
                # For batch, this will reflect the cost associated with the *last* item processed by the callback.
                # A fully accurate batch total would require a more complex callback class to aggregate.
                total_cost = _LAST_CALLBACK_DATA.get("cost", 0.0)
                # ----------------------------------------

                final_result = results if use_batch_mode else results[0]
                final_thinking = thinking_outputs if use_batch_mode else thinking_outputs[0]

                # --- Verbose Output for Success ---
                if verbose:
                    # Get token usage from the *last* callback data (might not be accurate for batch)
                    input_tokens = _LAST_CALLBACK_DATA.get("input_tokens", 0)
                    output_tokens = _LAST_CALLBACK_DATA.get("output_tokens", 0)

                    cost_input_pm = model_info.get('input', 0.0) if pd.notna(model_info.get('input')) else 0.0
                    cost_output_pm = model_info.get('output', 0.0) if pd.notna(model_info.get('output')) else 0.0

                    logger.info(f"[RESULT] Model Used: {model_name_litellm}")
                    logger.info(f"[RESULT] Cost (Input): ${cost_input_pm:.2f}/M tokens")
                    logger.info(f"[RESULT] Cost (Output): ${cost_output_pm:.2f}/M tokens")
                    logger.info(f"[RESULT] Tokens (Prompt): {input_tokens}")
                    logger.info(f"[RESULT] Tokens (Completion): {output_tokens}")
                    # Display the cost captured by the callback
                    logger.info(f"[RESULT] Total Cost (from callback): ${total_cost:.6g}") # Renamed label for clarity
                    logger.info("[RESULT] Max Completion Tokens: Provider Default") # Indicate default limit
                    if final_thinking:
                        logger.info("[RESULT] Thinking Output:")
                        logger.info(final_thinking) 

                # --- Print raw output before returning if verbose ---
                if verbose:
                    logger.debug("[DEBUG] Raw output before return:")
                    logger.debug(f"  Raw Result (repr): {repr(final_result)}")
                    logger.debug(f"  Raw Thinking (repr): {repr(final_thinking)}")
                    logger.debug("-" * 20) # Separator

                # --- Return Success ---
                _emit_llm_attribution(
                    attribution_context,
                    "llm_invoke.success",
                    attempt_id=attempt_id,
                    model=str(model_name_litellm),
                    provider=str(provider),
                    cost=total_cost,
                    input_tokens=_LAST_CALLBACK_DATA.get("input_tokens", 0),
                    output_tokens=_LAST_CALLBACK_DATA.get("output_tokens", 0),
                    finish_reason=_LAST_CALLBACK_DATA.get("finish_reason"),
                    call_type=call_type_for_attribution,
                )
                return {
                    'result': final_result,
                    'cost': total_cost,
                    'model_name': model_name_litellm, # Actual model used
                    'thinking_output': final_thinking if final_thinking else None
                }

            # --- 6b. Handle Invocation Errors ---
            except openai.AuthenticationError as e:
                last_exception = e
                error_message = str(e)
                _emit_llm_attribution(
                    attribution_context,
                    "llm_invoke.litellm_error",
                    attempt_id=attempt_id,
                    model=str(model_name_litellm),
                    provider=str(provider),
                    **_safe_error_fields(e),
                )
                
                # Check for WSL-specific issues in authentication errors
                if _is_wsl_environment() and ('Illegal header value' in error_message or '\r' in error_message):
                    logger.warning(f"[WSL AUTH ERROR] Authentication failed for {model_name_litellm} - detected WSL line ending issue")
                    logger.warning("[WSL AUTH ERROR] This is likely caused by API key environment variables containing carriage returns")
                    logger.warning("[WSL AUTH ERROR] Try setting your API key again or check your .env file for line ending issues")
                    env_info = _get_environment_info()
                    logger.debug(f"Environment info: {env_info}")
                    
                if newly_acquired_keys.get(api_key_name):
                    logger.warning(f"[AUTH ERROR] Authentication failed for {model_name_litellm} with the newly provided key for '{api_key_name}'. Please check the key and try again.")
                    # Invalidate the key in env for this session to force re-prompt on retry
                    if api_key_name in os.environ:
                         del os.environ[api_key_name]
                    # Clear the 'newly acquired' status for this key so the next attempt doesn't trigger immediate retry loop
                    newly_acquired_keys[api_key_name] = False
                    retry_with_same_model = True # Set flag to retry the same model after re-prompt
                    # Go back to the start of the 'while retry_with_same_model' loop
                else:
                    logger.warning(f"[AUTH ERROR] Authentication failed for {model_name_litellm} using existing key '{api_key_name}'. Trying next model.")
                    break # Break inner loop, try next model candidate

            except SchemaValidationError as e:
                # Issue #168: Schema validation failures now trigger model fallback
                last_exception = e
                _emit_llm_attribution(
                    attribution_context,
                    "llm_invoke.schema_validation_error",
                    attempt_id=attempt_id,
                    model=str(model_name_litellm),
                    provider=str(provider),
                    **_safe_error_fields(e),
                    item_index=e.item_index,
                )
                logger.warning(f"[SCHEMA ERROR] Validation failed for {model_name_litellm}: {e}. Trying next model.")
                if verbose:
                    logger.debug(f"Raw response that failed validation: {repr(e.raw_response)}")
                break  # Break inner loop, try next model candidate

            except litellm.ContextWindowExceededError as e:
                # Post-call safety net: model rejected prompt as too large after the pre-call
                # check (e.g. tokenizer mismatch). Fall back to the next candidate.
                last_exception = e
                _emit_llm_attribution(
                    attribution_context,
                    "llm_invoke.context_window_error",
                    attempt_id=attempt_id,
                    model=str(model_name_litellm),
                    provider=str(provider),
                    **_safe_error_fields(e),
                )
                logger.error(
                    f"[CONTEXT] {model_name_litellm} rejected prompt as too large. Trying next model."
                )
                break  # Break inner loop, try next model candidate

            except (openai.RateLimitError, openai.APITimeoutError, openai.APIConnectionError,
                    openai.APIStatusError, openai.BadRequestError, openai.InternalServerError,
                    Exception) as e: # Catch generic Exception last
                last_exception = e
                error_type = type(e).__name__
                error_str = str(e)

                # Claude-specific handling for temperature + thinking/reasoning rules.
                # Check model name (not provider) to cover both direct Anthropic and Vertex AI Claude.
                # Two scenarios we auto-correct:
                # 1) temperature==1 without thinking -> retry with 0.99
                # 2) thinking enabled but temperature!=1 -> retry with 1
                lower_err = error_str.lower()
                if (not temp_adjustment_done) and ("temperature" in lower_err) and ("thinking" in lower_err):
                    claude_thinking_sent = ('thinking' in litellm_kwargs or 'reasoning_effort' in litellm_kwargs) and 'claude' in model_name_litellm.lower()
                    # Decide direction of adjustment based on whether thinking was enabled in the call
                    if claude_thinking_sent:
                        # thinking enabled -> force temperature=1
                        adjusted_temp = 1
                        logger.warning(
                            f"[WARN] {model_name_litellm}: Claude with thinking requires temperature=1. "
                            f"Retrying with temperature={adjusted_temp}."
                        )
                    else:
                        # thinking not enabled -> avoid temperature=1
                        adjusted_temp = 0.99
                        logger.warning(
                            f"[WARN] {model_name_litellm}: Provider rejected temperature=1 without thinking. "
                            f"Retrying with temperature={adjusted_temp}."
                        )
                    current_temperature = adjusted_temp
                    temp_adjustment_done = True
                    retry_with_same_model = True
                    _emit_llm_attribution(
                        attribution_context,
                        "llm_invoke.temperature_retry",
                        attempt_id=attempt_id,
                        model=str(model_name_litellm),
                        provider=str(provider),
                        adjusted_temperature=adjusted_temp,
                        **_safe_error_fields(e),
                    )
                    if verbose:
                        logger.debug(f"Retrying {model_name_litellm} with adjusted temperature {current_temperature}")
                    continue

                _emit_llm_attribution(
                    attribution_context,
                    "llm_invoke.litellm_error",
                    attempt_id=attempt_id,
                    model=str(model_name_litellm),
                    provider=str(provider),
                    **_safe_error_fields(e),
                )
                logger.error(f"[ERROR] Invocation failed for {model_name_litellm} ({error_type}): {e}. Trying next model.")
                # Log more details in verbose mode
                if verbose:
                    logger.debug(f"Detailed exception traceback for {model_name_litellm}:", exc_info=True)
                break # Break inner loop, try next model candidate

        # If the inner loop was broken (not by success), continue to the next candidate model
        continue

    # --- 8. Handle Failure of All Candidates ---
    error_message = "All candidate models failed."
    if last_exception:
        error_message += f" Last error ({type(last_exception).__name__}): {last_exception}"
    if last_exception and "context limit" in str(last_exception):
        error_message += (
            " Hint: Try reducing prompt size, splitting into smaller prompts, "
            "or using a model with a larger context window."
        )
    logger.error(f"[FATAL] {error_message}")
    _emit_llm_attribution(
        attribution_context,
        "llm_invoke.failure",
        failure_reason="all_candidate_models_failed",
        last_error_type=type(last_exception).__name__ if last_exception else None,
    )
    raise RuntimeError(error_message) from last_exception

# --- Example Usage (Optional) ---
if __name__ == "__main__":
    # This block allows running the file directly for testing.
    # Ensure you have a ./data/llm_model.csv file and potentially a .env file.

    # Set PDD_DEBUG_SELECTOR=1 to see model selection details
    # os.environ["PDD_DEBUG_SELECTOR"] = "1"

    # Example 1: Simple text generation
    logger.info("\n--- Example 1: Simple Text Generation (Strength 0.5) ---")
    try:
        response = llm_invoke(
            prompt="Tell me a short joke about {topic}.",
            input_json={"topic": "programmers"},
            strength=0.5, # Use base model (first available in CSV)
            temperature=0.7,
            verbose=True
        )
        logger.info("\nExample 1 Response:")
        logger.info(response)
    except Exception as e:
        logger.error(f"\nExample 1 Failed: {e}", exc_info=True)

    # Example 1b: Simple text generation (Strength 0.3)
    logger.info("\n--- Example 1b: Simple Text Generation (Strength 0.3) ---")
    try:
        response = llm_invoke(
            prompt="Tell me a short joke about {topic}.",
            input_json={"topic": "keyboards"},
            strength=0.3, # Should select gemini-pro based on cost interpolation
            temperature=0.7,
            verbose=True
        )
        logger.info("\nExample 1b Response:")
        logger.info(response)
    except Exception as e:
        logger.error(f"\nExample 1b Failed: {e}", exc_info=True)

    # Example 2: Structured output (requires a Pydantic model)
    logger.info("\n--- Example 2: Structured Output (Pydantic, Strength 0.8) ---")
    class JokeStructure(BaseModel):
        setup: str
        punchline: str
        rating: Optional[int] = None

    try:
        # Use a model known to support structured output (check your CSV)
        # Strength 0.8 should select gemini-pro based on ELO interpolation
        response_structured = llm_invoke(
            prompt="Create a joke about {topic}. Output ONLY the JSON object with 'setup' and 'punchline'.",
            input_json={"topic": "data science"},
            strength=0.8, # Try a higher ELO model (gemini-pro expected)
            temperature=1,
            output_pydantic=JokeStructure,
            verbose=True
        )
        logger.info("\nExample 2 Response:")
        logger.info(response_structured)
        if isinstance(response_structured.get('result'), JokeStructure):
             logger.info("\nPydantic object received successfully: %s", response_structured['result'].model_dump())
        else:
             logger.info("\nResult was not the expected Pydantic object: %s", response_structured.get('result'))

    except Exception as e:
        logger.error(f"\nExample 2 Failed: {e}", exc_info=True)


    # Example 3: Batch processing
    logger.info("\n--- Example 3: Batch Processing (Strength 0.3) ---")
    try:
        batch_input = [
            {"animal": "cat", "adjective": "lazy"},
            {"animal": "dog", "adjective": "energetic"},
        ]
        # Strength 0.3 should select gemini-pro
        response_batch = llm_invoke(
            prompt="Describe a {adjective} {animal} in one sentence.",
            input_json=batch_input,
            strength=0.3, # Cheaper model maybe (gemini-pro expected)
            temperature=0.5,
            use_batch_mode=True,
            verbose=True
        )
        logger.info("\nExample 3 Response:")
        logger.info(response_batch)
    except Exception as e:
        logger.error(f"\nExample 3 Failed: {e}", exc_info=True)

    # Example 4: Using 'messages' input
    logger.info("\n--- Example 4: Using 'messages' input (Strength 0.5) ---")
    try:
        custom_messages = [
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": "What is the capital of France?"}
        ]
        # Strength 0.5 should select the base model (first available in CSV)
        response_messages = llm_invoke(
            messages=custom_messages,
            strength=0.5,
            temperature=0.1,
            verbose=True
        )
        logger.info("\nExample 4 Response:")
        logger.info(response_messages)
    except Exception as e:
        logger.error(f"\nExample 4 Failed: {e}", exc_info=True)

    # Example 5: Requesting thinking time (e.g., for Anthropic)
    logger.info("\n--- Example 5: Requesting Thinking Time (Strength 1.0, Time 0.5) ---")
    try:
        # Ensure your CSV has max_reasoning_tokens for an Anthropic model
        # Strength 1.0 should select claude-3 (highest ELO)
        # Time 0.5 with budget type should request thinking
        response_thinking = llm_invoke(
            prompt="Explain the theory of relativity simply, taking some time to think.",
            input_json={},
            strength=1.0, # Try to get highest ELO model (claude-3)
            temperature=1,
            time=0.5, # Request moderate thinking time
            verbose=True
        )
        logger.info("\nExample 5 Response:")
        logger.info(response_thinking)
    except Exception as e:
        logger.error(f"\nExample 5 Failed: {e}", exc_info=True)

    # Example 6: Pydantic Fallback Parsing (Strength 0.3)
    logger.info("\n--- Example 6: Pydantic Fallback Parsing (Strength 0.3) ---")
    # This requires mocking litellm.completion to return a JSON string
    # even when gemini-pro (which supports structured output) is selected.
    # This is hard to demonstrate cleanly in the __main__ block without mocks.
    # The unit test test_llm_invoke_output_pydantic_unsupported_parses covers this.
    logger.info("(Covered by unit tests)")
