"""
Async sync runner: parallel module sync with dependency-aware scheduling.

Manages concurrent `pdd sync` subprocesses, respects dependency ordering,
updates a live GitHub issue comment with progress, and pauses on failure.
"""
from __future__ import annotations

import csv
import datetime
import json
import os
import re
import signal
import subprocess
import sys
import tempfile
import threading
import time
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, NamedTuple, Optional, Tuple

from rich.console import Console

from .agentic_change import _run_gh_command
from .architecture_registry import extract_modules
from .sync_order import extract_module_from_include

console = Console()

# Regex matching lines composed entirely of box-drawing / table characters
# (Rich Panel borders, table separators, etc.) — used to skip them in heartbeat.
_BOX_CHARS_RE = re.compile(r'^[\s╭╮╰╯─│┌┐└┘├┤┬┴┼═║╔╗╚╝╠╣╦╩╬\-|+]*$')

# Maximum concurrent syncs
MAX_WORKERS = 4
# Per-module timeout in seconds. Large modules (200KB+) routinely need the full
# generate+crash+verify+test+fix loop and can land at ~30-35 min for legitimate
# work. Default of 45 min keeps a ~10-min margin above observed real runtimes;
# override via PDD_MODULE_TIMEOUT_SECONDS for environments with tighter caps.
try:
    MODULE_TIMEOUT = int(os.environ.get("PDD_MODULE_TIMEOUT_SECONDS", "2700"))
except ValueError:
    MODULE_TIMEOUT = 2700
# State file for resumability (relative to project root)
STATE_FILE_PATH = ".pdd/agentic_sync_state.json"


@dataclass
class ModuleState:
    """Tracks the execution state of a single module sync."""

    status: str = "pending"  # pending, running, success, failed
    start_time: Optional[float] = None
    end_time: Optional[float] = None
    cost: float = 0.0
    error: Optional[str] = None
    current_phase: Optional[str] = None
    completed_phases: List[str] = field(default_factory=list)


def _find_pdd_executable() -> Optional[str]:
    """Find the pdd executable path."""
    import shutil

    pdd_path = shutil.which("pdd")
    if pdd_path:
        return pdd_path

    python_dir = Path(sys.executable).parent
    pdd_in_python_dir = python_dir / "pdd"
    if pdd_in_python_dir.exists():
        return str(pdd_in_python_dir)

    return None


def _parse_cost_from_csv(csv_path: str) -> float:
    """Parse total cost from a PDD_OUTPUT_COST_PATH CSV file."""
    total = 0.0
    try:
        with open(csv_path, "r", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for row in reader:
                cost_val = row.get("cost", "")
                if cost_val:
                    try:
                        total += float(cost_val)
                    except (ValueError, TypeError):
                        pass
    except (OSError, csv.Error):
        pass
    return total


class DepGraphFromArchitectureResult(NamedTuple):
    """Dependency subgraph from architecture.json plus validation warnings."""

    graph: Dict[str, List[str]]
    warnings: List[str]


def _basename_from_architecture_filename(filename: str) -> Optional[str]:
    """Return a sync basename from an architecture filename, preserving folders."""
    if not filename:
        return None

    path = Path(filename)
    basename = extract_module_from_include(path.name)
    if not basename:
        return None
    if path.parent == Path("."):
        return basename
    return str(path.parent / basename)


def _basename_from_architecture_filepath(filepath: str) -> Optional[str]:
    """Return a sync basename from an architecture filepath."""
    if not filepath:
        return None

    path = Path(filepath)
    if path.suffix:
        path = path.with_suffix("")
    return path.as_posix()


def _architecture_entry_aliases(entry: Dict[str, Any]) -> set[str]:
    """Return all sync basenames that may identify an architecture entry."""
    aliases: set[str] = set()

    filename_basename = _basename_from_architecture_filename(
        str(entry.get("filename", "") or "")
    )
    if filename_basename:
        aliases.add(filename_basename)

    filepath_basename = _basename_from_architecture_filepath(
        str(entry.get("filepath", "") or "")
    )
    if filepath_basename:
        aliases.add(filepath_basename)

    return aliases


def _target_basename_aliases(target_basename: str) -> set[str]:
    """Return aliases that should match a requested sync target."""
    aliases = {target_basename}
    path = Path(target_basename)
    stripped_name = extract_module_from_include(path.name + ".prompt")
    if stripped_name:
        if path.parent == Path("."):
            aliases.add(stripped_name)
        else:
            aliases.add((path.parent / stripped_name).as_posix())
    return aliases


def build_dep_graph_from_architecture(
    arch_path: Path, target_basenames: List[str]
) -> DepGraphFromArchitectureResult:
    """
    Build dependency subgraph for target basenames from architecture.json.

    Args:
        arch_path: Path to architecture.json.
        target_basenames: List of module basenames to include.

    Returns:
        DepGraphFromArchitectureResult: ``graph`` maps basename -> dependency basenames
        (only edges to modules in ``target_basenames``). ``warnings`` lists orphan dependency
        filenames and dependencies outside the target set (partial sync) that were omitted
        from the graph.
    """
    empty = DepGraphFromArchitectureResult({b: [] for b in target_basenames}, [])
    try:
        with open(arch_path, "r", encoding="utf-8") as f:
            arch = json.load(f)
    except (OSError, json.JSONDecodeError):
        return empty

    return build_dep_graph_from_architecture_data(
        arch,
        target_basenames,
        source_name=str(arch_path),
    )


def build_dep_graph_from_architecture_data(
    architecture: Any,
    target_basenames: List[str],
    *,
    source_name: str = "architecture.json",
) -> DepGraphFromArchitectureResult:
    """
    Build dependency subgraph from already-loaded architecture data.

    This variant supports combined architecture data loaded from root and nested
    architecture.json files, preserving dependency ordering for global sync.
    """
    empty = DepGraphFromArchitectureResult({b: [] for b in target_basenames}, [])
    modules = extract_modules(architecture)
    if not modules:
        return empty

    target_aliases_by_target = {
        target: _target_basename_aliases(target) for target in target_basenames
    }

    # Map architecture filename -> original requested target basename. Architecture
    # entries commonly store bare prompt filenames (config_Python.prompt) while
    # branch-diff sync targets may be path-qualified for .pddrc context routing
    # (src/config). Match via both filename-derived and filepath-derived aliases,
    # but keep graph keys as the original target strings the runner must execute.
    filename_to_target: Dict[str, str] = {}
    filename_to_aliases: Dict[str, set[str]] = {}
    for entry in modules:
        filename = str(entry.get("filename", "") or "")
        aliases = _architecture_entry_aliases(entry)
        if not filename or not aliases:
            continue
        filename_to_aliases[filename] = aliases
        for target in target_basenames:
            if aliases & target_aliases_by_target[target]:
                filename_to_target[filename] = target
                break

    warnings: List[str] = []
    # Build graph using original target basenames
    graph: Dict[str, List[str]] = {}
    for entry in modules:
        filename = str(entry.get("filename", "") or "")
        target_name = filename_to_target.get(filename)
        if target_name:
            deps = []
            for dep_filename in entry.get("dependencies", []):
                dep_aliases = filename_to_aliases.get(dep_filename)
                if dep_aliases is None:
                    warnings.append(
                        f"Orphan dependency {dep_filename!r} on architecture entry "
                        f"{entry.get('filename', '')!r}: no matching module entry in {source_name}"
                    )
                    continue
                dep_target = filename_to_target.get(dep_filename)
                if dep_target == target_name:
                    continue
                if dep_target is None:
                    dep_display = sorted(dep_aliases)[0]
                    warnings.append(
                        f"Partial sync: module {target_name!r} depends on {dep_display!r} "
                        f"(via {dep_filename!r}), which is not in the sync target set; "
                        "dependency edge omitted from graph"
                    )
                    continue
                deps.append(dep_target)
            graph[target_name] = deps

    # Ensure all target basenames are in graph
    for b in target_basenames:
        if b not in graph:
            graph[b] = []

    return DepGraphFromArchitectureResult(graph, warnings)


class AsyncSyncRunner:
    """
    Parallel sync engine that runs `pdd sync` for multiple modules concurrently,
    respecting dependency order and posting live progress to GitHub.
    """

    def __init__(
        self,
        basenames: List[str],
        dep_graph: Dict[str, List[str]],
        sync_options: Dict[str, Any],
        github_info: Optional[Dict[str, Any]],
        quiet: bool = False,
        verbose: bool = False,
        issue_url: Optional[str] = None,
        module_cwds: Optional[Dict[str, Path]] = None,
        initial_cost: float = 0.0,
    ):
        self.basenames = basenames
        self.dep_graph = dep_graph
        self.sync_options = sync_options
        self.github_info = github_info
        self.quiet = quiet
        self.verbose = verbose
        self.issue_url = issue_url
        self.project_root = Path.cwd()
        self.module_cwds = module_cwds or {}
        self.initial_cost = initial_cost
        self.total_budget = sync_options.get("total_budget")
        self.max_workers = 1 if self.total_budget is not None else MAX_WORKERS

        self.module_states: Dict[str, ModuleState] = {
            b: ModuleState() for b in basenames
        }
        self.failed = False
        self.budget_exhausted = False
        self.comment_id: Optional[int] = None
        self.lock = threading.Lock()

        # Track child process groups for cleanup on interrupt
        self._child_pgids: set = set()

        # Rate-limit GitHub comment updates for phase changes
        self._last_comment_update: float = 0.0
        self._comment_update_interval: float = 15.0  # seconds

        # Try to resume from saved state
        self._resumed_modules: List[str] = []
        self._load_state()

    def _state_file_path(self) -> Path:
        """Return the path to the state file."""
        return self.project_root / STATE_FILE_PATH

    def _load_state(self) -> None:
        """Load previously saved state if it matches the current run."""
        if not self.issue_url:
            return

        state_path = self._state_file_path()
        if not state_path.exists():
            return

        try:
            with open(state_path, "r", encoding="utf-8") as f:
                saved = json.load(f)
        except (OSError, json.JSONDecodeError):
            return

        # Must match the same issue URL
        if saved.get("issue_url") != self.issue_url:
            return
        saved_modules = saved.get("modules", {})

        # Restore succeeded modules that are still in the current module list.
        # Allow partial resumption: if the LLM returns a different (larger or
        # smaller) module list on re-run, we still honour previously completed
        # work instead of discarding everything and re-syncing from scratch.
        for basename, info in saved_modules.items():
            if basename in self.module_states and info.get("status") == "success":
                self.module_states[basename].status = "success"
                self.module_states[basename].cost = info.get("cost", 0.0)
                self._resumed_modules.append(basename)

        self.comment_id = saved.get("comment_id")

    def _save_state(self) -> None:
        """Atomically persist current state to disk."""
        if not self.issue_url:
            return

        state_path = self._state_file_path()
        state_path.parent.mkdir(parents=True, exist_ok=True)

        modules_data = {}
        with self.lock:
            for basename in self.basenames:
                state = self.module_states[basename]
                modules_data[basename] = {
                    "status": state.status,
                    "cost": state.cost,
                }

        data = {
            "issue_url": self.issue_url,
            "modules": modules_data,
            "total_cost": sum(m["cost"] for m in modules_data.values()),
            "comment_id": self.comment_id,
            "started_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        }

        # Atomic write via temp file + os.replace
        tmp_path = None
        try:
            fd, tmp_path = tempfile.mkstemp(
                dir=str(state_path.parent), suffix=".tmp"
            )
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)
            os.replace(tmp_path, str(state_path))
        except OSError:
            # Best-effort; don't break sync for state persistence failures
            if tmp_path is not None:
                try:
                    os.unlink(tmp_path)
                except OSError:
                    pass

    def _delete_state(self) -> None:
        """Remove the state file (called on full success)."""
        try:
            self._state_file_path().unlink(missing_ok=True)
        except OSError:
            pass

    def _kill_children(self) -> None:
        """Kill all tracked child process groups."""
        for pgid in list(self._child_pgids):
            try:
                os.killpg(pgid, signal.SIGTERM)
            except OSError:
                pass
        # Give children a moment to exit, then force-kill survivors
        time.sleep(1)
        for pgid in list(self._child_pgids):
            try:
                os.killpg(pgid, signal.SIGKILL)
            except OSError:
                pass
        self._child_pgids.clear()

    def run(self) -> Tuple[bool, str, float]:
        """
        Run all syncs respecting dependencies.

        Returns:
            Tuple of (all_success, summary_message, total_cost).
        """
        if not self.basenames:
            return True, "No modules to sync", self.initial_cost

        if self._resumed_modules and not self.quiet:
            console.print(
                f"[green]Resuming: skipping {len(self._resumed_modules)} already-succeeded "
                f"module(s): {self._resumed_modules}[/green]"
            )
            fresh = [b for b in self.basenames if b not in self._resumed_modules]
            if fresh:
                console.print(f"[blue]Modules to sync: {fresh}[/blue]")

        self._update_github_comment()

        # Install signal handler so Ctrl+C kills child processes instead of orphaning them
        prev_sigint = signal.getsignal(signal.SIGINT)
        prev_sigterm = signal.getsignal(signal.SIGTERM)

        def _on_interrupt(signum, frame):
            """Kill children then re-raise."""
            self._kill_children()
            # Restore and re-raise so the parent sees the interrupt
            signal.signal(signum, prev_sigint if signum == signal.SIGINT else prev_sigterm)
            os.kill(os.getpid(), signum)

        signal.signal(signal.SIGINT, _on_interrupt)
        signal.signal(signal.SIGTERM, _on_interrupt)

        try:
            return self._run_inner()
        finally:
            # Restore original handlers and clean up any remaining children
            signal.signal(signal.SIGINT, prev_sigint)
            signal.signal(signal.SIGTERM, prev_sigterm)
            self._kill_children()

    def _run_inner(self) -> Tuple[bool, str, float]:
        """Inner run loop, separated so signal handlers can be set up around it."""
        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            futures: Dict[Any, str] = {}  # Future -> basename

            while not self._all_done():
                if not self.failed and self._budget_exhausted():
                    self.failed = True
                    self.budget_exhausted = True

                # Find modules whose deps are all "success"
                ready = self._get_ready_modules()

                if self.failed:
                    # Don't start new modules; wait for running ones to finish
                    if not futures:
                        break
                else:
                    # Only submit up to available worker slots so modules
                    # aren't marked "running" while queued in the executor.
                    available_slots = self.max_workers - len(futures)
                    for basename in ready[:available_slots]:
                        with self.lock:
                            self.module_states[basename].status = "running"
                            self.module_states[basename].start_time = time.time()
                        self._update_github_comment()
                        future = executor.submit(self._sync_one_module, basename)
                        futures[future] = basename

                if not futures:
                    # No futures running and nothing ready — check for blocked modules
                    blocked = self._get_blocked_modules()
                    if blocked and not self.failed:
                        # Modules are blocked by failed deps
                        self.failed = True
                    break

                # Wait for at least one future to complete
                done, _ = wait(futures, return_when=FIRST_COMPLETED)
                for future in done:
                    basename = futures.pop(future)
                    try:
                        success, cost, error = future.result()
                    except Exception as e:
                        success, cost, error = False, 0.0, str(e)
                    self._record_result(basename, success, cost, error)
                    self._update_github_comment()
                    if not success:
                        self.failed = True
                    elif self._budget_exhausted():
                        self.failed = True
                        self.budget_exhausted = True

        # Final update
        self._update_github_comment()

        # Build summary
        total_cost = self.initial_cost + sum(s.cost for s in self.module_states.values())
        succeeded = [b for b, s in self.module_states.items() if s.status == "success"]
        failed = [b for b, s in self.module_states.items() if s.status == "failed"]
        pending = [b for b, s in self.module_states.items() if s.status == "pending"]

        if self.budget_exhausted:
            budget = float(self.total_budget)
            msg = (
                f"Budget exhausted (${total_cost:.2f} of ${budget:.2f}). "
                f"Succeeded: {succeeded}."
            )
            if failed:
                msg += f" Failed: {failed}."
            if pending:
                msg += f" Skipped (budget): {pending}."
            self._save_state()
            return False, msg, total_cost
        if failed:
            msg = f"Failed: {failed}. Succeeded: {succeeded}."
            if pending:
                msg += f" Skipped (blocked): {pending}."
            # Include error details for failed modules
            for b in failed:
                err = self.module_states[b].error
                if err:
                    # Truncate long errors but keep enough context
                    err_summary = err.strip()[:500]
                    msg += f"\n  {b}: {err_summary}"
            self._save_state()
            return False, msg, total_cost
        elif pending:
            msg = f"Succeeded: {succeeded}. Skipped (blocked): {pending}."
            self._save_state()
            return False, msg, total_cost
        else:
            self._delete_state()
            return True, f"All {len(succeeded)} modules synced successfully", total_cost

    def _all_done(self) -> bool:
        """Check if all modules are in a terminal state."""
        with self.lock:
            return all(
                s.status in ("success", "failed")
                for s in self.module_states.values()
            )

    def _get_ready_modules(self) -> List[str]:
        """Get modules whose deps are all satisfied and that are pending."""
        ready = []
        with self.lock:
            for basename in self.basenames:
                state = self.module_states[basename]
                if state.status != "pending":
                    continue
                deps = self.dep_graph.get(basename, [])
                # All deps must be "success" (deps not in basenames are assumed ok)
                deps_satisfied = all(
                    self.module_states.get(d, ModuleState(status="success")).status == "success"
                    for d in deps
                )
                if deps_satisfied:
                    ready.append(basename)
        return ready

    def _get_blocked_modules(self) -> List[str]:
        """Get modules that are pending but blocked by non-success deps."""
        blocked = []
        with self.lock:
            for basename in self.basenames:
                state = self.module_states[basename]
                if state.status != "pending":
                    continue
                deps = self.dep_graph.get(basename, [])
                has_failed_dep = any(
                    self.module_states.get(d, ModuleState(status="success")).status == "failed"
                    for d in deps
                )
                if has_failed_dep:
                    blocked.append(basename)
        return blocked

    def _record_result(self, basename: str, success: bool, cost: float, error: str) -> None:
        """Record the result of a module sync and persist state."""
        with self.lock:
            state = self.module_states[basename]
            state.status = "success" if success else "failed"
            state.end_time = time.time()
            state.cost = cost
            if not success:
                state.error = error
            # Finalize phase tracking: move current_phase to completed
            if state.current_phase and not state.current_phase.startswith("skip:"):
                state.completed_phases.append(state.current_phase)
            state.current_phase = None
        self._save_state()

    def _total_cost_so_far(self) -> float:
        """Return initial cost plus completed module costs."""
        with self.lock:
            return self.initial_cost + sum(s.cost for s in self.module_states.values())

    def _remaining_total_budget(self) -> Optional[float]:
        """Return remaining total budget, or None when no total budget is set."""
        if self.total_budget is None:
            return None
        return max(float(self.total_budget) - self._total_cost_so_far(), 0.0)

    def _budget_exhausted(self) -> bool:
        """Return True when the configured total budget is fully spent."""
        remaining = self._remaining_total_budget()
        return remaining is not None and remaining <= 0.0

    def _budget_for_module(self, basename: str) -> Optional[float]:
        """Return the budget cap to pass to a child sync process."""
        module_budgets = self.sync_options.get("module_budgets") or {}
        budget = module_budgets.get(basename, self.sync_options.get("budget"))
        remaining = self._remaining_total_budget()
        if remaining is None:
            return budget
        if budget is None:
            return remaining
        return min(float(budget), remaining)

    def _on_phase_change(self, basename: str, phase: str) -> None:
        """Handle a phase transition for a module."""
        with self.lock:
            state = self.module_states[basename]
            if state.current_phase and state.current_phase != phase:
                # Previous phase completed
                if not state.current_phase.startswith("skip:"):
                    state.completed_phases.append(state.current_phase)
            state.current_phase = phase
        # Rate-limited comment update
        self._update_github_comment_throttled()

    def _update_github_comment_throttled(self) -> None:
        """Update comment at most once per interval."""
        now = time.time()
        if now - self._last_comment_update >= self._comment_update_interval:
            self._last_comment_update = now
            self._update_github_comment()

    def _sync_one_module(self, basename: str) -> Tuple[bool, float, str]:
        """
        Run pdd sync for a single module as a subprocess.

        Uses Popen with threaded pipe readers to prevent deadlock when
        subprocess output exceeds the OS pipe buffer (~64KB).

        Returns:
            Tuple of (success, cost, error_message).
        """
        pdd_exe = _find_pdd_executable()
        if pdd_exe:
            cmd = [pdd_exe]
        else:
            cmd = [sys.executable, "-m", "pdd"]

        # Global options first
        cmd.append("--force")
        if self.sync_options.get("local"):
            cmd.append("--local")

        # Command + positional arg
        cmd.extend(["sync", basename])

        # Command-specific options
        # Always pass --agentic and --no-steer: child subprocess is headless (stdin=/dev/null)
        cmd.append("--agentic")
        cmd.append("--no-steer")
        if self.sync_options.get("skip_verify"):
            cmd.append("--skip-verify")
        if self.sync_options.get("skip_tests"):
            cmd.append("--skip-tests")
        target_coverage = self.sync_options.get("target_coverage")
        if target_coverage is not None:
            cmd.extend(["--target-coverage", str(target_coverage)])
        module_budget = self._budget_for_module(basename)
        if module_budget is not None:
            cmd.extend(["--budget", str(module_budget)])
        if self.sync_options.get("max_attempts"):
            cmd.extend(["--max-attempts", str(self.sync_options["max_attempts"])])
        if self.sync_options.get("one_session"):
            cmd.append("--one-session")

        # Set up environment for headless mode and cost capture
        cost_file = tempfile.NamedTemporaryFile(suffix=".csv", delete=False)
        cost_file.close()

        env = os.environ.copy()
        env["PDD_OUTPUT_COST_PATH"] = cost_file.name
        env["CI"] = "1"
        env["PDD_FORCE"] = "1"
        env["PDD_AUTO_UPDATE"] = "false"
        env["TERM"] = "dumb"
        env["PYTHONUNBUFFERED"] = "1"

        if not self.quiet:
            console.print(f"[blue]Starting sync: {basename}[/blue]")

        stdout_lines: List[str] = []
        stderr_lines: List[str] = []
        verbose_print = self.verbose and not self.quiet

        def _read_stream(stream, lines_list: List[str], prefix: str = "") -> None:
            """Drain a pipe stream line-by-line into a list."""
            try:
                for line in iter(stream.readline, ''):
                    if line:
                        lines_list.append(line)
                        # Parse phase markers emitted by sync_orchestration
                        stripped = line.strip()
                        if stripped.startswith("PDD_PHASE: "):
                            phase = stripped[len("PDD_PHASE: "):]
                            self._on_phase_change(basename, phase)
                        if verbose_print:
                            console.print(f"[dim]{prefix}{basename}>[/dim] {line.rstrip()}")
            except Exception:
                pass
            finally:
                stream.close()

        try:
            process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                stdin=subprocess.DEVNULL,
                cwd=str(self.module_cwds.get(basename, self.project_root)),
                env=env,
                text=True,
                bufsize=1,  # Line buffered
                start_new_session=True,  # Create process group for clean kill
            )
            # Track the process group so we can kill it on Ctrl+C
            self._child_pgids.add(process.pid)
        except Exception as e:
            cost = _parse_cost_from_csv(cost_file.name)
            try:
                os.remove(cost_file.name)
            except OSError:
                pass
            return False, cost, str(e)

        t_out = threading.Thread(
            target=_read_stream, args=(process.stdout, stdout_lines, ""), daemon=True
        )
        t_err = threading.Thread(
            target=_read_stream, args=(process.stderr, stderr_lines, "err:"), daemon=True
        )
        t_out.start()
        t_err.start()

        # Per-module wall-clock cap = MODULE_TIMEOUT plus the optional
        # `--timeout-adder` (forwarded via sync_options) so users can stretch
        # the budget for individual very-large modules without redefining the
        # global default. Negative or non-numeric values are treated as 0 so
        # that an over-eager flag never *shrinks* the cap.
        try:
            module_timeout = MODULE_TIMEOUT + max(
                0.0, float(self.sync_options.get("timeout_adder") or 0.0)
            )
        except (TypeError, ValueError):
            module_timeout = MODULE_TIMEOUT
        try:
            # Poll with heartbeat so user sees progress in non-verbose mode
            heartbeat_interval = 60  # seconds
            start_wall = self.module_states[basename].start_time or time.time()
            last_heartbeat = time.time()
            while True:
                elapsed_total = time.time() - start_wall
                remaining = max(module_timeout - elapsed_total, 0)
                try:
                    exit_code = process.wait(timeout=min(heartbeat_interval, remaining))
                    break  # Process finished
                except subprocess.TimeoutExpired:
                    elapsed_total = time.time() - start_wall
                    if elapsed_total >= module_timeout:
                        raise  # Re-raise to hit the timeout handler below
                    now = time.time()
                    if not self.quiet and now - last_heartbeat >= heartbeat_interval:
                        mins = int(elapsed_total) // 60
                        secs = int(elapsed_total) % 60
                        # Prefer parsed PDD_PHASE state over the last raw
                        # stdout line: heartbeats based on stdout were stuck
                        # on "Preprocessing complete" for the whole run even
                        # while test/fix phases were progressing, hiding real
                        # work behind a stale hint. Fall back to last
                        # non-box stdout line only when no phase has been
                        # reported yet.
                        with self.lock:
                            state = self.module_states[basename]
                            current_phase = state.current_phase
                            completed_phase_count = len(state.completed_phases)
                        if current_phase:
                            hint = (
                                f" — phase: {current_phase} "
                                f"({completed_phase_count} done)"
                            )
                        else:
                            last_line = ""
                            for line in reversed(stdout_lines):
                                stripped = line.strip()
                                if stripped and not _BOX_CHARS_RE.match(stripped):
                                    last_line = stripped
                                    break
                            hint = f" — {last_line[:80]}" if last_line else ""
                        console.print(
                            f"[dim]  {basename}: still running ({mins}m{secs}s){hint}[/dim]"
                        )
                        last_heartbeat = now
        except subprocess.TimeoutExpired:
            # Kill entire process group (includes grandchild agentic subprocesses)
            try:
                os.killpg(process.pid, signal.SIGTERM)
            except OSError:
                process.terminate()
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except OSError:
                    process.kill()
                process.wait()
            self._child_pgids.discard(process.pid)
            return False, _parse_cost_from_csv(cost_file.name), f"Timeout after {int(module_timeout)}s"
        finally:
            self._child_pgids.discard(process.pid)
            t_out.join(timeout=5)
            t_err.join(timeout=5)

        cost = _parse_cost_from_csv(cost_file.name)

        # Clean up cost file
        try:
            os.unlink(cost_file.name)
        except OSError:
            pass

        stdout = "".join(stdout_lines)
        stderr = "".join(stderr_lines)

        # Detect success
        success = exit_code == 0
        if success:
            for line in stdout.splitlines():
                if "Overall status:" in line and "Failed" in line:
                    success = False
                    break

        if not self.quiet:
            status_str = "success" if success else "FAILED"
            console.print(f"[{'green' if success else 'red'}]Sync {basename}: {status_str}[/{'green' if success else 'red'}]")

            # Forward notable status lines from child stdout
            if success:
                for line in stdout.splitlines():
                    if "Successfully submitted example" in line:
                        console.print(f"  [green]{basename}: Example submitted to cloud[/green]")
                        break

        error = ""
        if not success:
            # Extract meaningful error lines from stderr and stdout,
            # filtering out INFO/DEBUG log noise
            all_output = (stderr or "") + "\n" + (stdout or "")
            error_lines = [
                line for line in all_output.splitlines()
                if line.strip() and not re.match(
                    r"^\d{4}-\d{2}-\d{2} .* - (INFO|DEBUG)( |-)", line
                )
            ]
            # Prefer lines containing error/traceback keywords
            keyword_lines = [
                line for line in error_lines
                if any(kw in line.lower() for kw in ("error", "failed", "traceback", "exception", "abort"))
            ]
            if keyword_lines:
                error = "\n".join(keyword_lines[-20:])
            elif error_lines:
                error = "\n".join(error_lines[-20:])
            else:
                error = f"Exit code {exit_code}"
            if not self.quiet:
                console.print(f"[red]  Error for {basename}:[/red] {error[:500]}")

        return success, cost, error

    def _update_github_comment(self) -> None:
        """Create or update a GitHub issue comment with current progress."""
        if not self.github_info:
            return

        owner = self.github_info["owner"]
        repo = self.github_info["repo"]
        issue_number = self.github_info["issue_number"]

        body = self._build_comment_body(issue_number)

        # Use a timeout to prevent gh API calls from blocking the runner
        gh_timeout = 30

        try:
            if self.comment_id is None:
                self.comment_id = self._find_existing_progress_comment_id(
                    owner, repo, issue_number, timeout=gh_timeout
                )

            if self.comment_id is None:
                ok, response = _run_gh_command([
                    "api", f"repos/{owner}/{repo}/issues/{issue_number}/comments",
                    "-X", "POST", "-f", f"body={body}",
                ], timeout=gh_timeout)
                if ok:
                    try:
                        data = json.loads(response)
                        self.comment_id = data.get("id")
                    except json.JSONDecodeError:
                        pass
            else:
                ok, _ = _run_gh_command([
                    "api", f"repos/{owner}/{repo}/issues/comments/{self.comment_id}",
                    "-X", "PATCH", "-f", f"body={body}",
                ], timeout=gh_timeout)
                if not ok:
                    self.comment_id = None
        except Exception:
            pass  # Don't break sync for comment failures

    def _find_existing_progress_comment_id(
        self,
        owner: str,
        repo: str,
        issue_number: int,
        *,
        timeout: int,
    ) -> Optional[int]:
        """Return the newest existing PDD sync progress comment id for this issue."""
        ok, response = _run_gh_command([
            "api", f"repos/{owner}/{repo}/issues/{issue_number}/comments",
            "--paginate", "--slurp",
        ], timeout=timeout)
        if not ok:
            return None

        try:
            payload = json.loads(response)
        except json.JSONDecodeError:
            return None

        comments: List[Dict[str, Any]] = []
        if isinstance(payload, list) and all(isinstance(page, list) for page in payload):
            comments = [
                comment
                for page in payload
                for comment in page
                if isinstance(comment, dict)
            ]
        elif isinstance(payload, list):
            comments = [comment for comment in payload if isinstance(comment, dict)]

        marker = f"## PDD Agentic Sync Progress\nIssue: #{issue_number}"
        for comment in reversed(comments):
            body = comment.get("body")
            comment_id = comment.get("id")
            if isinstance(body, str) and body.startswith(marker) and comment_id:
                try:
                    return int(comment_id)
                except (TypeError, ValueError):
                    continue
        return None

    def _build_comment_body(self, issue_number: int) -> str:
        """Build the markdown comment body showing sync progress."""
        lines = [
            "## PDD Agentic Sync Progress",
            f"Issue: #{issue_number}",
            "",
            "| Module | Status | Phase | Duration | Cost |",
            "|--------|--------|-------|----------|------|",
        ]

        total_cost = self.initial_cost
        completed = 0
        total = len(self.basenames)

        with self.lock:
            for basename in self.basenames:
                state = self.module_states[basename]
                total_cost += state.cost

                if state.status == "success":
                    icon = "✅ Success"
                    completed += 1
                    duration = _format_duration(state.start_time, state.end_time)
                    cost_str = f"${state.cost:.2f}"
                    total_phases = len(state.completed_phases)
                    phase_str = f"{total_phases} phases" if total_phases else "-"
                elif state.status == "failed":
                    icon = "❌ Failed"
                    completed += 1
                    duration = _format_duration(state.start_time, state.end_time)
                    cost_str = f"${state.cost:.2f}"
                    total_phases = len(state.completed_phases)
                    phase_str = f"{total_phases} phases" if total_phases else "-"
                elif state.status == "running":
                    icon = "🔄 Running"
                    duration = _format_duration(state.start_time, time.time())
                    cost_str = "-"
                    if state.current_phase:
                        phase_name = state.current_phase.replace("skip:", "~")
                        done_count = len(state.completed_phases)
                        phase_str = f"`{phase_name}` ({done_count} done)" if done_count else f"`{phase_name}`"
                    else:
                        phase_str = "-"
                else:
                    icon = "⏳ Pending"
                    duration = "-"
                    cost_str = "-"
                    phase_str = "-"

                lines.append(f"| {basename} | {icon} | {phase_str} | {duration} | {cost_str} |")

        lines.append("")
        lines.append(f"**Total cost:** ${total_cost:.2f}")

        # Status line
        failed_modules = [b for b, s in self.module_states.items() if s.status == "failed"]
        all_done = all(s.status in ("success", "failed") for s in self.module_states.values())

        if failed_modules:
            lines.append(f"**⚠️ Paused: `{'`, `'.join(failed_modules)}` failed**")
        elif all_done:
            lines.append(f"**✅ All {total} modules synced successfully**")
        else:
            lines.append(f"**Status:** In Progress ({completed}/{total} complete)")

        return "\n".join(lines)



def _format_duration(start: Optional[float], end: Optional[float]) -> str:
    """Format a duration from start/end timestamps."""
    if start is None or end is None:
        return "-"
    seconds = int(end - start)
    if seconds < 60:
        return f"{seconds}s"
    minutes = seconds // 60
    remaining = seconds % 60
    return f"{minutes}m{remaining}s"
