# DIFP SDK

Initial skeleton package for DIFP SDK.
