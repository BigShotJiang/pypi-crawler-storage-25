"""
DIFP SDK - initial release (structure placeholder).
"""
