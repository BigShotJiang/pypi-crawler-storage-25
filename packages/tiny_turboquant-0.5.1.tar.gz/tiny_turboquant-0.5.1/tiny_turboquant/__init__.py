"""Tiny TurboQuant: low-bit vector and KV-cache compression research toolkit."""

from .attention import attention_similarity, dense_attention, streaming_paged_attention
from .bitpack import pack_indices, packed_num_bytes, tensor_nbytes, unpack_indices
from .outlier_split import OutlierSplitTurboQuant
from .quantizer import TurboQuantMSE, TurboQuantProd
from .rotation import RandomRotation
from .kv_bench import KVBenchConfig, first_divergence, markdown_report, run_kv_benchmark
from .kv_estimator import KVCacheMemoryEstimate, auto_outlier_count, estimate_kv_cache_memory
from .kv_presets import KV_CACHE_PRESETS, available_kv_presets, resolve_kv_cache_preset
from .serving import (
    PagedKVCacheSpec,
    ServingEngineAdapter,
    TensorRTLLMExperimentAdapter,
    VLLMExperimentAdapter,
)
from .vector_index import CompressedVectorIndex, VectorSearchResult
from .metrics import recall_at_k, precision_at_k, mrr_at_k, ndcg_at_k, exact_overlap, label_match_ratio
from .rag import (
    DocumentChunk,
    RAGSearchResult,
    RAGCompressedIndex,
    chunk_text,
    make_chunks,
    load_texts_from_jsonl,
    load_texts_from_folder,
    compare_retrieval_ids,
)

__all__ = [
    "pack_indices",
    "unpack_indices",
    "packed_num_bytes",
    "tensor_nbytes",
    "TurboQuantKVCache",
    "HybridTurboQuantKVCache",
    "OutlierSplitTurboQuant",
    "TurboQuantMSE",
    "TurboQuantProd",
    "RandomRotation",
    "CompressedVectorIndex",
    "VectorSearchResult",
    "dense_attention",
    "streaming_paged_attention",
    "attention_similarity",
    "PagedKVCacheSpec",
    "ServingEngineAdapter",
    "VLLMExperimentAdapter",
    "TensorRTLLMExperimentAdapter",
    "recall_at_k",
    "precision_at_k",
    "mrr_at_k",
    "ndcg_at_k",
    "exact_overlap",
    "label_match_ratio",
    "DocumentChunk",
    "RAGSearchResult",
    "RAGCompressedIndex",
    "chunk_text",
    "make_chunks",
    "load_texts_from_jsonl",
    "load_texts_from_folder",
    "compare_retrieval_ids",
    "KV_CACHE_PRESETS",
    "available_kv_presets",
    "resolve_kv_cache_preset",
    "KVCacheMemoryEstimate",
    "auto_outlier_count",
    "estimate_kv_cache_memory",
    "KVBenchConfig",
    "first_divergence",
    "run_kv_benchmark",
    "markdown_report",
]

__version__ = "0.5.1"


def __getattr__(name: str):
    if name in {"TurboQuantKVCache", "HybridTurboQuantKVCache"}:
        from .kv_cache import HybridTurboQuantKVCache, TurboQuantKVCache

        return {
            "TurboQuantKVCache": TurboQuantKVCache,
            "HybridTurboQuantKVCache": HybridTurboQuantKVCache,
        }[name]
    raise AttributeError(f"module 'tiny_turboquant' has no attribute {name!r}")
