"""Command-line utilities for tiny-turboquant."""

from __future__ import annotations

import argparse
import json
import sys
from typing import Sequence

import torch
import torch.nn.functional as F

from . import __version__
from .metrics import exact_overlap, label_match_ratio
from .rag import RAGCompressedIndex, load_texts_from_folder, load_texts_from_jsonl
from .vector_index import CompressedVectorIndex
from .kv_bench import KVBenchConfig, run_kv_benchmark, save_json_report, save_markdown_report
from .kv_estimator import estimate_kv_cache_memory
from .kv_presets import available_kv_presets


def _synthetic_rag_corpus(docs_per_topic: int = 100):
    topics = {
        "rag": [
            "Embedding compression can reduce vector-store memory in retrieval-heavy systems.",
            "Compressed vector indexes help store more document chunks in limited memory.",
            "RAG systems retrieve relevant chunks and pass them to an LLM as context.",
            "Reranking helps recover quality after compressed vector retrieval.",
        ],
        "kv_cache": [
            "KV cache stores Key and Value tensors during autoregressive LLM generation.",
            "KV cache memory grows with context length and active sequences.",
            "Hybrid KV cache keeps recent tokens dense and compresses older tokens.",
            "Fused attention kernels are needed for production-speed compressed cache.",
        ],
        "serving": [
            "LLM serving systems manage batching, throughput, latency, and memory.",
            "Paged cache layouts help serving engines manage many active users.",
            "Production inference requires stable latency and measured output quality.",
            "Serving benchmarks should report tokens per second and memory usage.",
        ],
    }
    docs = []
    labels = []
    for label, templates in topics.items():
        for i in range(docs_per_topic):
            docs.append(f"{templates[i % len(templates)]} Scenario {i:04d} topic={label}.")
            labels.append(label)
    return docs, labels


def _embed_with_sentence_transformers(texts, model_name: str, batch_size: int = 64):
    try:
        from sentence_transformers import SentenceTransformer
    except Exception as exc:  # pragma: no cover
        raise ImportError(
            "sentence-transformers is required for rag-bench text embedding. "
            "Install with: pip install tiny-turboquant[demos]"
        ) from exc
    model = SentenceTransformer(model_name)
    return model.encode(
        list(texts),
        convert_to_tensor=True,
        normalize_embeddings=True,
        batch_size=batch_size,
        show_progress_bar=False,
    )


def rag_bench(args: argparse.Namespace) -> int:
    if args.synthetic:
        docs, labels = _synthetic_rag_corpus(args.docs_per_topic)
        query = args.query or "How can we reduce memory usage in a RAG vector store?"
        expected_label = args.expected_label or "rag"
    elif args.input_jsonl:
        docs = load_texts_from_jsonl(args.input_jsonl, text_field=args.text_field)
        labels = [None] * len(docs)
        query = args.query
        expected_label = args.expected_label
    elif args.input_folder:
        docs = load_texts_from_folder(args.input_folder)
        labels = [None] * len(docs)
        query = args.query
        expected_label = args.expected_label
    else:
        raise SystemExit("rag-bench requires --synthetic, --input-jsonl, or --input-folder")

    if not query:
        raise SystemExit("rag-bench requires --query unless --synthetic is used")

    embeddings = _embed_with_sentence_transformers(docs, args.embedding_model, args.batch_size)
    query_embedding = _embed_with_sentence_transformers([query], args.embedding_model, args.batch_size)[0]

    # Baseline full-precision search.
    scores = embeddings @ query_embedding
    full_scores, full_idx = torch.topk(scores, k=min(args.top_k, embeddings.shape[0]))
    full_ids = [int(i) for i in full_idx]
    full_labels = [labels[i] for i in full_ids]

    # Compressed search + rerank.
    index = CompressedVectorIndex(bits=args.bits, store_original_for_rerank=True).add(embeddings)
    compressed = index.search(query_embedding, top_k=args.top_k, rerank_top_k=args.rerank_top_k)
    compressed_ids = [r.index for r in compressed]
    compressed_labels = [labels[i] for i in compressed_ids]

    fp32 = index.fp32_baseline_bytes()
    compressed_bytes = index.compressed_payload_bytes()

    result = {
        "version": __version__,
        "documents": len(docs),
        "embedding_dim": int(embeddings.shape[1]),
        "bits": args.bits,
        "fp32_bytes": fp32,
        "compressed_payload_bytes": compressed_bytes,
        "compression_ratio": fp32 / max(compressed_bytes, 1),
        "memory_saved_pct": (1.0 - compressed_bytes / fp32) * 100.0,
        "top_k": args.top_k,
        "rerank_top_k": args.rerank_top_k,
        "exact_overlap": exact_overlap(full_ids, compressed_ids, args.top_k),
    }
    if expected_label is not None:
        result["full_label_match"] = label_match_ratio(full_labels, expected_label, args.top_k)
        result["compressed_label_match"] = label_match_ratio(compressed_labels, expected_label, args.top_k)

    print(json.dumps(result, indent=2))
    return 0



def _coerce_outlier(value):
    if value is None:
        return None
    if isinstance(value, str) and value.lower() == "auto":
        return "auto"
    return int(value)


def kv_estimate(args: argparse.Namespace) -> int:
    estimate = estimate_kv_cache_memory(
        layers=args.layers,
        kv_heads=args.kv_heads,
        head_dim=args.head_dim,
        seq_len=args.seq_len,
        batch_size=args.batch_size,
        dtype_bytes=args.dtype_bytes,
        key_bits=args.key_bits,
        value_bits=args.value_bits,
        key_outlier_bits=args.key_outlier_bits,
        value_outlier_bits=args.value_outlier_bits,
        n_key_outliers=_coerce_outlier(args.n_key_outliers),
        n_value_outliers=_coerce_outlier(args.n_value_outliers),
        key_recent_window=args.key_recent_window,
        value_recent_window=args.value_recent_window,
    )
    print(json.dumps(estimate.to_dict(), indent=2))
    return 0


def kv_bench(args: argparse.Namespace) -> int:
    cfg = KVBenchConfig(
        model=args.model,
        cache_type="hybrid",
        preset=args.preset,
        prompt_mode=args.prompt_mode,
        prompt=args.prompt,
        max_new_tokens=args.max_new_tokens,
        device=args.device,
        dtype=args.dtype,
        kl_tokens=args.kl_tokens,
        skip_kl=args.skip_kl,
        key_bits=args.key_bits,
        value_bits=args.value_bits,
        key_recent_window=args.key_recent_window,
        value_recent_window=args.value_recent_window,
        key_outlier_bits=args.key_outlier_bits,
        value_outlier_bits=args.value_outlier_bits,
        n_key_outliers=_coerce_outlier(args.n_key_outliers),
        n_value_outliers=_coerce_outlier(args.n_value_outliers),
        per_head_calibration=args.per_head_calibration,
    )
    report = run_kv_benchmark(cfg)
    if args.report_json:
        save_json_report(report, args.report_json)
    if args.report_md:
        save_markdown_report(report, args.report_md)
    print(json.dumps(report, indent=2))
    return 0

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="tiny-tq", description="tiny-turboquant utilities")
    sub = parser.add_subparsers(dest="cmd")

    sub.add_parser("version", help="print package version")

    rb = sub.add_parser("rag-bench", help="run a small compressed RAG benchmark")
    rb.add_argument("--synthetic", action="store_true", help="use built-in synthetic corpus")
    rb.add_argument("--docs-per-topic", type=int, default=100)
    rb.add_argument("--input-jsonl", type=str, default=None)
    rb.add_argument("--input-folder", type=str, default=None)
    rb.add_argument("--text-field", type=str, default="text")
    rb.add_argument("--query", type=str, default=None)
    rb.add_argument("--expected-label", type=str, default=None)
    rb.add_argument("--embedding-model", type=str, default="sentence-transformers/all-MiniLM-L6-v2")
    rb.add_argument("--bits", type=int, default=4)
    rb.add_argument("--top-k", type=int, default=10)
    rb.add_argument("--rerank-top-k", type=int, default=50)
    rb.add_argument("--batch-size", type=int, default=64)
    rb.set_defaults(func=rag_bench)

    ke = sub.add_parser("kv-estimate", help="estimate dense vs hybrid KV-cache memory")
    ke.add_argument("--layers", type=int, required=True)
    ke.add_argument("--kv-heads", type=int, required=True)
    ke.add_argument("--head-dim", type=int, required=True)
    ke.add_argument("--seq-len", type=int, required=True)
    ke.add_argument("--batch-size", type=int, default=1)
    ke.add_argument("--dtype-bytes", type=int, default=2)
    ke.add_argument("--key-bits", type=int, default=6)
    ke.add_argument("--value-bits", type=int, default=4)
    ke.add_argument("--key-outlier-bits", type=int, default=8)
    ke.add_argument("--value-outlier-bits", type=int, default=8)
    ke.add_argument("--n-key-outliers", default="auto")
    ke.add_argument("--n-value-outliers", default="auto")
    ke.add_argument("--key-recent-window", type=int, default=128)
    ke.add_argument("--value-recent-window", type=int, default=64)
    ke.set_defaults(func=kv_estimate)

    kb = sub.add_parser("kv-bench", help="compare DynamicCache vs HybridTurboQuantKVCache on a real LLM")
    kb.add_argument("--model", type=str, required=True)
    kb.add_argument("--preset", type=str, default="balanced", choices=available_kv_presets())
    kb.add_argument("--prompt-mode", type=str, default="short", choices=["short", "medium", "long", "stress"])
    kb.add_argument("--prompt", type=str, default=None)
    kb.add_argument("--max-new-tokens", type=int, default=16)
    kb.add_argument("--device", type=str, default="auto", choices=["auto", "cpu", "cuda"])
    kb.add_argument("--dtype", type=str, default="auto", choices=["auto", "float16", "fp16", "bfloat16", "bf16", "float32", "fp32"])
    kb.add_argument("--kl-tokens", type=int, default=4)
    kb.add_argument("--skip-kl", action="store_true")
    kb.add_argument("--key-bits", type=int, default=None)
    kb.add_argument("--value-bits", type=int, default=None)
    kb.add_argument("--key-recent-window", type=int, default=None)
    kb.add_argument("--value-recent-window", type=int, default=None)
    kb.add_argument("--key-outlier-bits", type=int, default=None)
    kb.add_argument("--value-outlier-bits", type=int, default=None)
    kb.add_argument("--n-key-outliers", default=None)
    kb.add_argument("--n-value-outliers", default=None)
    kb.add_argument("--per-head-calibration", action="store_true", default=None)
    kb.add_argument("--report-json", type=str, default=None)
    kb.add_argument("--report-md", type=str, default=None)
    kb.set_defaults(func=kv_bench)

    return parser


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    if args.cmd == "version":
        print(__version__)
        return 0
    if hasattr(args, "func"):
        return int(args.func(args))
    parser.print_help()
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main(sys.argv[1:]))
