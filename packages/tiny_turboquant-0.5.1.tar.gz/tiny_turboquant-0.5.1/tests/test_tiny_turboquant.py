from __future__ import annotations

import sys
from pathlib import Path

import torch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tiny_turboquant import TurboQuantKVCache, TurboQuantMSE, TurboQuantProd
from tiny_turboquant.bitpack import pack_indices, unpack_indices
from tiny_turboquant.fwht import fwht
from tiny_turboquant.outlier_split import OutlierSplitTurboQuant
from tiny_turboquant.rotation import RandomRotation


def _unit(x: torch.Tensor) -> torch.Tensor:
    return x / x.norm(dim=-1, keepdim=True).clamp_min(1e-12)


def test_bitpack_roundtrip_all_supported_bits():
    g = torch.Generator().manual_seed(0)
    for bits in range(1, 9):
        idx = torch.randint(0, 1 << bits, (3, 5, 17), generator=g, dtype=torch.uint8)
        packed, shape = pack_indices(idx, bits)
        got = unpack_indices(packed, bits, shape)
        assert packed.dtype == torch.uint8
        assert tuple(got.shape) == tuple(idx.shape)
        assert torch.equal(got, idx)


def test_fwht_is_orthonormal():
    x = torch.randn(4, 64)
    y = fwht(fwht(x), force_torch=True)
    assert torch.allclose(x, y, atol=1e-5, rtol=1e-5)


def test_random_rotation_inverse():
    x = torch.randn(16, 48)
    rot = RandomRotation.make(48, seed=123)
    y = rot.apply(x)
    got = rot.apply_T(y)
    assert got.shape == x.shape
    assert torch.allclose(x, got, atol=1e-5, rtol=1e-5)


def test_mse_quantizer_shape_and_reasonable_distortion():
    x = _unit(torch.randn(256, 64))
    q = TurboQuantMSE.build(64, bits=4, seed=0)
    idx = q.quant(x)
    xh = q.dequant(idx)
    mse = ((x - xh) ** 2).sum(-1).mean().item()
    assert idx.dtype == torch.uint8
    assert idx.shape[-1] == q.d_pad
    assert xh.shape == x.shape
    assert mse < 0.08


def test_prod_quantizer_shape():
    x = _unit(torch.randn(64, 32))
    q = TurboQuantProd.build(32, bits=3, seed=0)
    idx, signs, gamma = q.quant(x)
    xh = q.dequant(idx, signs, gamma)
    assert idx.dtype == torch.uint8
    assert signs.dtype == torch.int8
    assert gamma.shape == (64, 1)
    assert xh.shape == x.shape


def test_outlier_split_roundtrip_shape():
    x = _unit(torch.randn(128, 64))
    q = OutlierSplitTurboQuant.calibrate(x, n_out=16, bits_out=3, bits_reg=2, seed=0)
    idx_out, idx_reg, n_out, n_reg = q.quant(x)
    xh = q.dequant(idx_out, idx_reg, n_out, n_reg)
    assert idx_out.dtype == torch.uint8
    assert idx_reg.dtype == torch.uint8
    assert xh.shape == x.shape
    assert 2.0 < q.effective_bits < 3.0


def test_kv_cache_uniform_actual_memory_less_than_fp16():
    torch.manual_seed(0)
    layers, batch, heads, seq, dim = 2, 1, 4, 16, 32
    cache = TurboQuantKVCache(bits=4)
    for layer in range(layers):
        k = torch.randn(batch, heads, seq, dim)
        v = torch.randn(batch, heads, seq, dim)
        kr, vr = cache.update(k, v, layer)
        assert kr.shape == k.shape
        assert vr.shape == v.shape

    for layer in range(layers):
        k = torch.randn(batch, heads, 1, dim)
        v = torch.randn(batch, heads, 1, dim)
        kr, vr = cache.update(k, v, layer)
        assert kr.shape[-2] == seq + 1
        assert vr.shape[-2] == seq + 1

    assert cache.get_seq_length(0) == seq + 1
    assert cache.actual_memory_bytes() == cache.memory_bytes()
    assert cache.actual_memory_bytes() < cache.fp16_baseline_bytes()
    assert abs(cache.actual_memory_bytes() - cache.theoretical_memory_bytes()) < 64


def test_kv_cache_outlier_split_uses_real_packed_storage():
    torch.manual_seed(1)
    cache = TurboQuantKVCache(bits=2, bits_outlier=3, n_outlier=8)
    k = torch.randn(1, 2, 8, 32)
    v = torch.randn(1, 2, 8, 32) * 1.7
    kr, vr = cache.update(k, v, 0)
    assert kr.shape == k.shape
    assert vr.shape == v.shape
    assert cache.get_seq_length(0) == 8
    assert cache.actual_memory_bytes() < cache.fp16_baseline_bytes()


def test_hybrid_cache_keeps_recent_tokens_dense_and_compresses_old_tokens():
    torch.manual_seed(2)
    from tiny_turboquant import HybridTurboQuantKVCache

    cache = HybridTurboQuantKVCache(bits=4, recent_window=2)
    k = torch.randn(1, 2, 12, 32)
    v = torch.randn(1, 2, 12, 32)
    kr, vr = cache.update(k, v, 0)

    assert kr.shape == k.shape
    assert vr.shape == v.shape
    assert cache.get_seq_length(0) == 12
    assert cache.compressed_seq_length(0) == 10
    assert cache.recent_seq_length(0) == 2
    assert cache.actual_memory_bytes() < cache.fp16_baseline_bytes()

    k2 = torch.randn(1, 2, 1, 32)
    v2 = torch.randn(1, 2, 1, 32)
    kr2, vr2 = cache.update(k2, v2, 0)

    assert kr2.shape[-2] == 13
    assert vr2.shape[-2] == 13
    assert cache.compressed_seq_length(0) == 11
    assert cache.recent_seq_length(0) == 2


def test_hybrid_cache_separate_key_value_bits_and_outliers():
    torch.manual_seed(3)
    from tiny_turboquant import HybridTurboQuantKVCache

    cache = HybridTurboQuantKVCache(
        key_bits=6,
        value_bits=4,
        key_outlier_bits=5,
        value_outlier_bits=4,
        n_key_outliers=8,
        n_value_outliers=0,
        recent_window=1,
    )
    k = torch.randn(1, 2, 8, 32)
    v = torch.randn(1, 2, 8, 32)
    cache.update(k, v, 0)

    key_page = cache._key_pages[0][0]
    value_page = cache._value_pages[0][0]

    assert key_page["type"] == "outlier_split"
    assert key_page["bits_reg"] == 6
    assert key_page["bits_out"] == 5
    assert value_page["type"] == "uniform"
    assert value_page["bits"] == 4


def test_hybrid_cache_per_layer_calibration_builds_distinct_quantizers():
    torch.manual_seed(4)
    from tiny_turboquant import HybridTurboQuantKVCache

    cache = HybridTurboQuantKVCache(bits=4, recent_window=1, per_layer_calibration=True)
    for layer in range(2):
        k = torch.randn(1, 2, 6, 32) + layer
        v = torch.randn(1, 2, 6, 32) - layer
        cache.update(k, v, layer)

    assert cache._q_key_by_layer[0] is not None
    assert cache._q_key_by_layer[1] is not None
    assert cache._q_key_by_layer[0] is not cache._q_key_by_layer[1]
    assert cache.get_seq_length(0) == 6
    assert cache.get_seq_length(1) == 6


def test_outlier_count_is_clamped_for_head_dim():
    torch.manual_seed(5)
    from tiny_turboquant import HybridTurboQuantKVCache

    # head_dim=16, but n_key_outliers is intentionally too large.
    # v0.3 should clamp instead of raising.
    cache = HybridTurboQuantKVCache(
        key_bits=4,
        value_bits=4,
        key_outlier_bits=8,
        value_outlier_bits=8,
        n_key_outliers=64,
        n_value_outliers=64,
        recent_window=1,
    )
    k = torch.randn(1, 2, 8, 16)
    v = torch.randn(1, 2, 8, 16)
    kr, vr = cache.update(k, v, 0)
    assert kr.shape == k.shape
    assert vr.shape == v.shape
    assert cache.actual_memory_bytes() < cache.fp16_baseline_bytes()


def test_hybrid_cache_per_head_calibration_and_paged_attention():
    torch.manual_seed(6)
    from tiny_turboquant import HybridTurboQuantKVCache, dense_attention, attention_similarity

    cache = HybridTurboQuantKVCache(
        key_bits=6,
        value_bits=4,
        key_outlier_bits=8,
        value_outlier_bits=8,
        n_key_outliers=8,
        n_value_outliers=4,
        recent_window=2,
        per_layer_calibration=True,
        per_head_calibration=True,
    )
    k = torch.randn(1, 3, 12, 16)
    v = torch.randn(1, 3, 12, 16)
    kr, vr = cache.update(k, v, 0)

    assert kr.shape == k.shape
    assert vr.shape == v.shape
    assert isinstance(cache._q_key_by_layer[0], list)
    assert len(cache._q_key_by_layer[0]) == 3

    q = torch.randn(1, 3, 1, 16)
    paged = cache.paged_attention(q, 0)
    dense = dense_attention(q, kr, vr)
    metrics = attention_similarity(dense, paged)
    assert paged.shape == dense.shape
    assert metrics["relative_error"] < 1e-4
    assert metrics["cosine_similarity"] > 0.999


def test_streaming_paged_attention_matches_dense_attention_on_pages():
    torch.manual_seed(7)
    from tiny_turboquant import dense_attention, streaming_paged_attention

    q = torch.randn(2, 4, 3, 16)
    k1 = torch.randn(2, 4, 5, 16)
    v1 = torch.randn(2, 4, 5, 16)
    k2 = torch.randn(2, 4, 7, 16)
    v2 = torch.randn(2, 4, 7, 16)

    dense = dense_attention(q, torch.cat([k1, k2], dim=2), torch.cat([v1, v2], dim=2))
    stream = streaming_paged_attention(q, [(k1, v1), (k2, v2)])
    assert torch.allclose(dense, stream, atol=1e-5, rtol=1e-5)


def test_compressed_vector_index_search_and_rerank():
    torch.manual_seed(8)
    from tiny_turboquant import CompressedVectorIndex

    x = torch.randn(200, 32)
    ids = [f"doc-{i}" for i in range(200)]
    index = CompressedVectorIndex(bits=4, store_original_for_rerank=True).add(x, ids=ids)

    results = index.search(x[0], top_k=5)
    reranked = index.search(x[0], top_k=5, rerank_top_k=50)

    assert len(results) == 5
    assert len(reranked) == 5
    assert index.compressed_payload_bytes() < index.fp32_baseline_bytes()
    assert index.compression_ratio() > 5.0
    assert reranked[0].id == "doc-0"


def test_serving_adapter_plan_is_explicit_scaffold():
    from tiny_turboquant import PagedKVCacheSpec, VLLMExperimentAdapter

    spec = PagedKVCacheSpec(key_bits=6, value_bits=4, page_size=64)
    plan = VLLMExperimentAdapter(spec).integration_plan()
    assert plan["engine"] == "vLLM-style paged cache"
    assert plan["spec"]["page_size"] == 64
    assert "not a drop-in" in plan["status"]


def test_hybrid_cache_paged_attention_handles_different_key_value_recent_windows():
    torch.manual_seed(9)
    from tiny_turboquant import HybridTurboQuantKVCache, dense_attention, attention_similarity

    # Use uniform low-bit quantizers so the regression test stays fast.
    # The bug being tested is page alignment when K and V use different
    # recent windows, not outlier or per-head calibration quality.
    cache = HybridTurboQuantKVCache(
        key_bits=4,
        value_bits=4,
        n_key_outliers=0,
        n_value_outliers=0,
        key_recent_window=6,
        value_recent_window=3,
        per_layer_calibration=True,
        per_head_calibration=False,
    )
    k = torch.randn(1, 2, 20, 16)
    v = torch.randn(1, 2, 20, 16)
    kr, vr = cache.update(k, v, 0)

    assert kr.shape == k.shape
    assert vr.shape == v.shape
    assert cache.compressed_seq_length(0) == 14
    assert cache.recent_seq_length(0) == 6

    q = torch.randn(1, 2, 2, 16)
    paged = cache.paged_attention(q, 0, page_size=5)
    dense = dense_attention(q, kr, vr)
    metrics = attention_similarity(dense, paged)

    assert paged.shape == dense.shape
    assert metrics["relative_error"] < 1e-4
    assert metrics["cosine_similarity"] > 0.999


def test_retrieval_metrics_basic():
    from tiny_turboquant import recall_at_k, precision_at_k, mrr_at_k, ndcg_at_k, exact_overlap

    retrieved = ["a", "b", "c", "d"]
    relevant = {"b", "d", "x"}

    assert recall_at_k(retrieved, relevant, 4) == 2 / 3
    assert precision_at_k(retrieved, relevant, 2) == 0.5
    assert mrr_at_k(retrieved, relevant, 4) == 0.5
    assert 0.0 < ndcg_at_k(retrieved, relevant, 4) <= 1.0
    assert exact_overlap([1, 2, 3], [2, 3, 4], 3) == 2 / 3


def test_chunk_text_and_make_chunks():
    from tiny_turboquant import chunk_text, make_chunks

    chunks = chunk_text("abcdefghij", chunk_size=4, overlap=1)
    assert chunks == ["abcd", "defg", "ghij", "j"]

    docs = make_chunks(["hello world"], chunk_size=5, overlap=0, ids=["doc-a"])
    assert docs[0].id == "doc-a::chunk-0"
    assert docs[0].metadata["source_id"] == "doc-a"


def test_rag_compressed_index_from_embeddings_search_and_save_load(tmp_path):
    torch.manual_seed(10)
    from tiny_turboquant import RAGCompressedIndex, DocumentChunk

    chunks = [
        DocumentChunk(id=f"doc-{i}", text=f"document {i}", metadata={"topic": "x" if i < 5 else "y"})
        for i in range(20)
    ]
    x = torch.randn(20, 16)
    x[0] = torch.ones(16)
    q = torch.ones(16)

    rag = RAGCompressedIndex.from_embeddings(chunks, x, bits=4, store_original_for_rerank=True)
    results = rag.search(q, top_k=3, rerank_top_k=10)
    assert len(results) == 3
    assert results[0].id == "doc-0"
    report = rag.memory_report()
    assert report["payload_compression_ratio"] > 5.0

    path = tmp_path / "rag.ttq"
    rag.save(path)
    loaded = RAGCompressedIndex.load(path)
    loaded_results = loaded.search(q, top_k=3, rerank_top_k=10)
    assert loaded_results[0].id == "doc-0"


def test_compressed_vector_index_save_load(tmp_path):
    torch.manual_seed(11)
    from tiny_turboquant import CompressedVectorIndex

    x = torch.randn(50, 16)
    x[0] = torch.ones(16)
    idx = CompressedVectorIndex(bits=4, store_original_for_rerank=True).add(x, ids=[f"id-{i}" for i in range(50)])
    path = tmp_path / "index.ttq"
    idx.save(str(path))
    loaded = CompressedVectorIndex.load(str(path))
    res = loaded.search(torch.ones(16), top_k=3, rerank_top_k=10)
    assert res[0].id == "id-0"


def test_cli_version_invocation(capsys):
    from tiny_turboquant.cli import main
    from tiny_turboquant import __version__

    assert main(["version"]) == 0
    captured = capsys.readouterr()
    assert __version__ in captured.out


def test_kv_presets_and_auto_outliers():
    from tiny_turboquant import HybridTurboQuantKVCache, available_kv_presets

    assert "balanced" in available_kv_presets()
    cache = HybridTurboQuantKVCache.from_preset("balanced", key_recent_window=32)
    assert cache.key_bits == 6
    assert cache.value_bits == 4
    assert cache.key_recent_window == 32
    assert cache.n_key_outliers == "auto"

    k = torch.randn(1, 2, 8, 16)
    v = torch.randn(1, 2, 8, 16)
    cache.update(k, v, 0)
    counts = cache.resolved_outlier_counts(16)
    assert counts["key"] == 8
    assert counts["value"] == 4


def test_kv_memory_estimator_reduces_memory_for_long_context():
    from tiny_turboquant import estimate_kv_cache_memory

    est = estimate_kv_cache_memory(
        layers=24,
        kv_heads=8,
        head_dim=128,
        seq_len=4096,
        batch_size=4,
        key_bits=6,
        value_bits=4,
        key_recent_window=128,
        value_recent_window=64,
    )
    d = est.to_dict()
    assert d["fp16_bytes"] > d["compressed_estimated_bytes"]
    assert d["compression_ratio"] > 1.0
    assert d["memory_saved_pct"] > 0.0
    assert d["n_key_outliers"] == 32
    assert d["n_value_outliers"] == 16


def test_kv_bench_report_markdown_and_first_divergence():
    from tiny_turboquant import KVBenchConfig, first_divergence, markdown_report

    a = torch.tensor([1, 2, 3, 4])
    b = torch.tensor([1, 2, 9, 4])
    assert first_divergence(a, b) == 2

    report = {
        "version": "0.5.0",
        "model": "dummy",
        "preset": "balanced",
        "prompt_mode": "short",
        "prompt_tokens": 4,
        "max_new_tokens": 2,
        "device": "cpu",
        "dtype": "float32",
        "memory": {
            "fp16_bytes": 100,
            "compressed_bytes": 50,
            "compression_ratio": 2.0,
            "memory_saved_pct": 50.0,
        },
        "quality": {
            "mean_kl": 0.1,
            "max_kl": 0.2,
            "kl_positions": 2,
            "first_divergence": 1,
            "continuation_tokens_compared": 2,
            "identical_generation": False,
        },
        "timing": {"baseline_seconds": 1.0, "compressed_seconds": 1.2},
        "text": {"baseline_output": "abc", "compressed_output": "abd"},
    }
    md = markdown_report(report)
    assert "KV benchmark report" in md
    assert "dummy" in md
    assert "production inference acceleration" in md

    cfg = KVBenchConfig(model="dummy")
    assert cfg.preset == "balanced"


def test_cli_kv_estimate_invocation(capsys):
    from tiny_turboquant.cli import main

    rc = main([
        "kv-estimate",
        "--layers", "2",
        "--kv-heads", "2",
        "--head-dim", "16",
        "--seq-len", "64",
    ])
    captured = capsys.readouterr()
    assert rc == 0
    assert "compression_ratio" in captured.out
