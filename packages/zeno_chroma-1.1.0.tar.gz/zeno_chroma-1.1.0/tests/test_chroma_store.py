"""`ChromaKnowledgeStore` integration tests.

These spin up a real ChromaDB persistent client. The first invocation
downloads the default ONNX embedding model; subsequent runs reuse the
cached weights. Marked `slow` so lightweight CI jobs can skip the model
boot while local and full-CI runs exercise it.
"""

from __future__ import annotations

from pathlib import Path

import pytest
from zeno.chroma.store import ChromaKnowledgeStore


@pytest.mark.slow
async def test_add_then_search_roundtrip(tmp_path: Path) -> None:
    store = ChromaKnowledgeStore(persist_dir=tmp_path / "chroma")
    await store.add("alice", "alice likes ramen")

    hits = await store.search("alice", "ramen")

    assert hits
    assert any("ramen" in h.text.lower() for h in hits)
    assert hits[0].meta.get("user_id") == "alice"


@pytest.mark.slow
async def test_cross_user_isolation(tmp_path: Path) -> None:
    store = ChromaKnowledgeStore(persist_dir=tmp_path / "chroma")
    await store.add("alice", "alice secret")
    await store.add("bob", "bob secret")

    alice_hits = await store.search("alice", "secret")
    bob_hits = await store.search("bob", "secret")

    assert all("bob" not in h.text for h in alice_hits)
    assert all("alice" not in h.text for h in bob_hits)


async def test_empty_text_rejected(tmp_path: Path) -> None:
    store = ChromaKnowledgeStore(persist_dir=tmp_path / "chroma")
    with pytest.raises(ValueError):
        await store.add("alice", "   ")


async def test_k_zero_returns_empty(tmp_path: Path) -> None:
    store = ChromaKnowledgeStore(persist_dir=tmp_path / "chroma")
    assert await store.search("alice", "anything", k=0) == []
