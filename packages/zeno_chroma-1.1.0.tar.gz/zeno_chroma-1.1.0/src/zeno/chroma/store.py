"""`ChromaKnowledgeStore` — `zeno.memory.protocols.KnowledgeStore` over ChromaDB.

Design notes:
  - A single collection with `user_id` stamped into each row's metadata.
    Querying with a `where` filter keeps multi-tenant isolation at the
    DB layer rather than relying on post-fetch filtering.
  - ChromaDB's Python client is synchronous. Every call is wrapped in
    `asyncio.to_thread` so the event loop keeps serving other turns
    while an embedding or query is in flight — matching the helios
    pattern at `assistant/memory/service.py:52`.
  - We use ChromaDB's default embedding function. Callers who want a
    different one pass `embedding_function=` at construction.

The store returns `zeno.memory.protocols.MemoryHit(text, score, meta)`.
ChromaDB reports *distance* (lower is closer); we convert to a similarity
score via `1.0 - distance` clamped into `[0, 1]`.
"""

from __future__ import annotations

import asyncio
import uuid
from pathlib import Path
from typing import TYPE_CHECKING, Any

from zeno.memory.protocols import MemoryHit

if TYPE_CHECKING:
    from chromadb.api.models.Collection import Collection


_DEFAULT_COLLECTION = "zeno_knowledge"


class ChromaKnowledgeStore:
    """Shared knowledge store backed by a persistent ChromaDB collection."""

    def __init__(
        self,
        persist_dir: str | Path,
        *,
        collection_name: str = _DEFAULT_COLLECTION,
        embedding_function: Any | None = None,
    ) -> None:
        import chromadb

        self._persist_dir = Path(persist_dir)
        self._persist_dir.mkdir(parents=True, exist_ok=True)
        self._client = chromadb.PersistentClient(path=str(self._persist_dir))

        kwargs: dict[str, Any] = {
            "name": collection_name,
            "metadata": {"hnsw:space": "cosine"},
        }
        if embedding_function is not None:
            kwargs["embedding_function"] = embedding_function
        self._collection: Collection = self._client.get_or_create_collection(**kwargs)

    async def add(
        self,
        user_id: str,
        text: str,
        meta: dict[str, Any] | None = None,
    ) -> None:
        """Insert `text` tagged with `user_id`. Errors out on empty text."""
        if not text.strip():
            raise ValueError("ChromaKnowledgeStore.add: text must be non-empty")
        row_meta: dict[str, Any] = {"user_id": user_id, **(meta or {})}
        row_id = uuid.uuid4().hex
        await asyncio.to_thread(
            self._collection.add,
            ids=[row_id],
            documents=[text],
            metadatas=[row_meta],
        )

    async def search(self, user_id: str, query: str, k: int = 5) -> list[MemoryHit]:
        """User-scoped similarity search; returns at most `k` hits."""
        if k <= 0:
            return []
        result = await asyncio.to_thread(
            self._collection.query,
            query_texts=[query],
            n_results=k,
            where={"user_id": user_id},
        )
        docs = (result.get("documents") or [[]])[0]
        metas = (result.get("metadatas") or [[]])[0]
        dists = (result.get("distances") or [[]])[0]

        hits: list[MemoryHit] = []
        for doc, meta, dist in zip(docs, metas, dists, strict=False):
            similarity = max(0.0, min(1.0, 1.0 - float(dist)))
            hits.append(MemoryHit(text=doc, score=similarity, meta=dict(meta or {})))
        return hits
