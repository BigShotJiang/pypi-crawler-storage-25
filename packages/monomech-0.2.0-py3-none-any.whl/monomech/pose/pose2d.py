from __future__ import annotations

from pathlib import Path

from ..config import PoseExtractionConfig
from .mediapipe_backend import PoseFrames, extract_pose_frames


def run_pose_extraction(video_path: str | Path, config: PoseExtractionConfig) -> PoseFrames:
    return extract_pose_frames(video_path, config)
