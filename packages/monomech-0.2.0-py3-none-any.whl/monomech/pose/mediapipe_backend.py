from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

import cv2
import numpy as np
import pandas as pd
from tqdm.auto import tqdm

from .._constants import LANDMARK_NAMES
from ..config import PoseExtractionConfig
from ..exceptions import MissingDependencyError


@dataclass
class PoseFrames:
    pose2d: pd.DataFrame
    pose3d: pd.DataFrame
    confidence: pd.DataFrame
    metadata: dict[str, Any]


def _read_video_basic_info(cap: cv2.VideoCapture) -> tuple[float, int, int, int | None]:
    fps = cap.get(cv2.CAP_PROP_FPS)
    if not np.isfinite(fps) or fps <= 1e-9:
        fps = 30.0
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 0)
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or 0)
    frame_count_raw = cap.get(cv2.CAP_PROP_FRAME_COUNT)
    frame_count = int(frame_count_raw) if np.isfinite(frame_count_raw) and frame_count_raw > 0 else None
    return float(fps), width, height, frame_count


def _rows_from_result(
    *,
    result: Any,
    frame_idx: int,
    time_sec: float,
    fps: float,
    width: int,
    height: int,
    presence_score: float | None = None,
) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any]]:
    row2d: dict[str, Any] = {"time": time_sec, "frame": frame_idx, "fps": fps, "width": width, "height": height}
    row3d: dict[str, Any] = {"time": time_sec, "frame": frame_idx, "fps": fps}
    conf: dict[str, Any] = {"time": time_sec, "frame": frame_idx, "fps": fps, "pose_presence": presence_score}

    norm_landmarks = None
    world_landmarks = None

    if hasattr(result, "pose_landmarks") and result.pose_landmarks:
        norm_landmarks = result.pose_landmarks[0] if isinstance(result.pose_landmarks, list) else result.pose_landmarks
    elif hasattr(result, "pose_landmarks"):
        norm_landmarks = result.pose_landmarks

    if hasattr(result, "pose_world_landmarks") and result.pose_world_landmarks:
        world_landmarks = result.pose_world_landmarks[0] if isinstance(result.pose_world_landmarks, list) else result.pose_world_landmarks
    elif hasattr(result, "pose_world_landmarks"):
        world_landmarks = result.pose_world_landmarks

    for idx, name in enumerate(LANDMARK_NAMES):
        lm2 = None if norm_landmarks is None else norm_landmarks[idx]
        lm3 = None if world_landmarks is None else world_landmarks[idx]

        if lm2 is None:
            row2d[f"{name}_x"] = np.nan
            row2d[f"{name}_y"] = np.nan
            row2d[f"{name}_z"] = np.nan
            row2d[f"{name}_x_px"] = np.nan
            row2d[f"{name}_y_px"] = np.nan
            conf[f"{name}_visibility"] = np.nan
            conf[f"{name}_presence"] = np.nan
        else:
            row2d[f"{name}_x"] = float(lm2.x)
            row2d[f"{name}_y"] = float(lm2.y)
            row2d[f"{name}_z"] = float(getattr(lm2, "z", np.nan))
            row2d[f"{name}_x_px"] = float(lm2.x) * width
            row2d[f"{name}_y_px"] = float(lm2.y) * height
            conf[f"{name}_visibility"] = float(getattr(lm2, "visibility", np.nan))
            conf[f"{name}_presence"] = float(getattr(lm2, "presence", np.nan))

        if lm3 is None:
            row3d[f"{name}_x"] = np.nan
            row3d[f"{name}_y"] = np.nan
            row3d[f"{name}_z"] = np.nan
        else:
            row3d[f"{name}_x"] = float(lm3.x)
            row3d[f"{name}_y"] = float(lm3.y)
            row3d[f"{name}_z"] = float(lm3.z)

    return row2d, row3d, conf


def _extract_with_tasks(video_path: str | Path, config: PoseExtractionConfig) -> PoseFrames:
    try:
        import mediapipe as mp
    except Exception as exc:
        raise MissingDependencyError("Install mediapipe to run pose extraction.") from exc

    if not config.task_model_path:
        raise ValueError("tasks backend requires PoseExtractionConfig.task_model_path")

    base_options = mp.tasks.BaseOptions
    vision = mp.tasks.vision
    options = vision.PoseLandmarkerOptions(
        base_options=base_options(model_asset_path=str(config.task_model_path)),
        running_mode=vision.RunningMode.VIDEO,
        num_poses=1,
        min_pose_detection_confidence=config.min_detection_confidence,
        min_tracking_confidence=config.min_tracking_confidence,
    )

    rows2d: list[dict[str, Any]] = []
    rows3d: list[dict[str, Any]] = []
    rowsc: list[dict[str, Any]] = []

    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        raise RuntimeError(f"Could not open video: {video_path}")
    fps, width, height, frame_count = _read_video_basic_info(cap)

    with vision.PoseLandmarker.create_from_options(options) as landmarker:
        frame_idx = 0
        kept_idx = 0
        iterator = tqdm(total=frame_count, disable=not config.progress, desc=f"Pose {Path(video_path).name}")
        try:
            while True:
                ok, frame = cap.read()
                if not ok:
                    break
                iterator.update(1)
                if config.stride > 1 and (frame_idx % config.stride != 0):
                    frame_idx += 1
                    continue

                image = mp.Image(image_format=mp.ImageFormat.SRGB, data=cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
                timestamp_ms = int(round((frame_idx / fps) * 1000.0))
                result = landmarker.detect_for_video(image, timestamp_ms)
                t_sec = frame_idx / fps
                presence = None
                if hasattr(result, "pose_presence_scores") and result.pose_presence_scores:
                    presence = float(result.pose_presence_scores[0])
                r2, r3, rc = _rows_from_result(
                    result=result, frame_idx=frame_idx, time_sec=t_sec, fps=fps, width=width, height=height, presence_score=presence
                )
                rows2d.append(r2)
                rows3d.append(r3)
                rowsc.append(rc)
                kept_idx += 1
                frame_idx += 1
        finally:
            iterator.close()
            cap.release()

    return PoseFrames(pd.DataFrame(rows2d), pd.DataFrame(rows3d), pd.DataFrame(rowsc), {"backend": "tasks", "fps": fps, "width": width, "height": height})


def _extract_with_legacy_solutions(video_path: str | Path, config: PoseExtractionConfig) -> PoseFrames:
    try:
        import mediapipe as mp
    except Exception as exc:
        raise MissingDependencyError("Install mediapipe to run pose extraction.") from exc

    pose = mp.solutions.pose.Pose(
        static_image_mode=False,
        model_complexity=config.model_complexity,
        enable_segmentation=False,
        smooth_landmarks=config.smooth_landmarks,
        min_detection_confidence=config.min_detection_confidence,
        min_tracking_confidence=config.min_tracking_confidence,
    )

    rows2d: list[dict[str, Any]] = []
    rows3d: list[dict[str, Any]] = []
    rowsc: list[dict[str, Any]] = []

    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        raise RuntimeError(f"Could not open video: {video_path}")
    fps, width, height, frame_count = _read_video_basic_info(cap)

    iterator = tqdm(total=frame_count, disable=not config.progress, desc=f"Pose {Path(video_path).name}")
    try:
        frame_idx = 0
        while True:
            ok, frame = cap.read()
            if not ok:
                break
            iterator.update(1)
            if config.stride > 1 and (frame_idx % config.stride != 0):
                frame_idx += 1
                continue

            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            result = pose.process(rgb)

            class _LegacyResult:
                pass

            wrapped = _LegacyResult()
            wrapped.pose_landmarks = result.pose_landmarks.landmark if result.pose_landmarks else None
            wrapped.pose_world_landmarks = result.pose_world_landmarks.landmark if result.pose_world_landmarks else None
            t_sec = frame_idx / fps
            r2, r3, rc = _rows_from_result(
                result=wrapped, frame_idx=frame_idx, time_sec=t_sec, fps=fps, width=width, height=height, presence_score=None
            )
            rows2d.append(r2)
            rows3d.append(r3)
            rowsc.append(rc)
            frame_idx += 1
    finally:
        iterator.close()
        cap.release()
        pose.close()

    return PoseFrames(pd.DataFrame(rows2d), pd.DataFrame(rows3d), pd.DataFrame(rowsc), {"backend": "solutions.pose", "fps": fps, "width": width, "height": height})


def extract_pose_frames(video_path: str | Path, config: PoseExtractionConfig) -> PoseFrames:
    backend = config.backend.lower().strip()
    if backend == "tasks":
        return _extract_with_tasks(video_path, config)
    if backend in {"solutions", "legacy", "pose"}:
        return _extract_with_legacy_solutions(video_path, config)

    if config.task_model_path:
        try:
            return _extract_with_tasks(video_path, config)
        except Exception:
            return _extract_with_legacy_solutions(video_path, config)
    return _extract_with_legacy_solutions(video_path, config)
