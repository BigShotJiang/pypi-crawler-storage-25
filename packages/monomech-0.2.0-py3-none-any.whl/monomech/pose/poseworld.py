from __future__ import annotations

from dataclasses import asdict
from typing import Any

import numpy as np
import pandas as pd

from .._constants import FOOT_MARKERS, LANDMARK_NAMES
from ..config import PoseWorldConfig
from .pnp import solve_pose_camera


def _copy_poseworld_row(row3d: pd.Series) -> dict[str, Any]:
    base = {"time": float(row3d["time"]), "frame": int(row3d["frame"]), "fps": float(row3d.get("fps", np.nan))}
    for name in LANDMARK_NAMES:
        base[f"{name}_x"] = float(row3d.get(f"{name}_x", np.nan)) if np.isfinite(row3d.get(f"{name}_x", np.nan)) else np.nan
        base[f"{name}_y"] = float(row3d.get(f"{name}_y", np.nan)) if np.isfinite(row3d.get(f"{name}_y", np.nan)) else np.nan
        base[f"{name}_z"] = float(row3d.get(f"{name}_z", np.nan)) if np.isfinite(row3d.get(f"{name}_z", np.nan)) else np.nan
    return base


def _shift_row_translation(row: dict[str, Any], tx: float, ty: float, tz: float) -> dict[str, Any]:
    for name in LANDMARK_NAMES:
        if np.isfinite(row[f"{name}_x"]):
            row[f"{name}_x"] = row[f"{name}_x"] - tx
        if np.isfinite(row[f"{name}_y"]):
            row[f"{name}_y"] = row[f"{name}_y"] - ty
        if np.isfinite(row[f"{name}_z"]):
            row[f"{name}_z"] = row[f"{name}_z"] - tz
    return row


def _trial_floor_offset(df: pd.DataFrame) -> float:
    mins = []
    for marker in FOOT_MARKERS:
        col = f"{marker}_y"
        if col in df.columns:
            mins.append(pd.to_numeric(df[col], errors="coerce").min())
    finite = [float(v) for v in mins if pd.notna(v)]
    return min(finite) if finite else 0.0


def build_poseworld(
    pose2d_df: pd.DataFrame,
    pose3d_df: pd.DataFrame,
    config: PoseWorldConfig,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    if len(pose2d_df) != len(pose3d_df):
        raise ValueError("pose2d_df and pose3d_df must have the same number of rows.")

    width = int(float(pose2d_df["width"].iloc[0])) if "width" in pose2d_df.columns else 1920
    height = int(float(pose2d_df["height"].iloc[0])) if "height" in pose2d_df.columns else 1080

    world_rows: list[dict[str, Any]] = []
    camera_rows: list[dict[str, Any]] = []

    for (_, row2), (_, row3) in zip(pose2d_df.iterrows(), pose3d_df.iterrows()):
        cam = solve_pose_camera(row2, row3, config, width=width, height=height)
        out_row = _copy_poseworld_row(row3)
        if cam.success:
            _shift_row_translation(out_row, cam.tx, cam.ty, cam.tz)
        world_rows.append(out_row)
        camera_rows.append(asdict(cam))

    poseworld_df = pd.DataFrame(world_rows)
    camera_df = pd.DataFrame(camera_rows)

    if config.ground_y and config.floor_mode == "trial_min":
        y_offset = _trial_floor_offset(poseworld_df)
        for marker in LANDMARK_NAMES:
            col = f"{marker}_y"
            poseworld_df[col] = poseworld_df[col] - y_offset
        camera_df["floor_offset_y"] = y_offset

    return poseworld_df, camera_df
