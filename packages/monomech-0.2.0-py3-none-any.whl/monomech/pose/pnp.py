from __future__ import annotations

from dataclasses import dataclass

import cv2
import numpy as np
import pandas as pd

from .._constants import LANDMARK_NAMES
from ..config import PoseWorldConfig


DEFAULT_PNP_MARKERS = [
    "left_shoulder", "right_shoulder",
    "left_elbow", "right_elbow",
    "left_wrist", "right_wrist",
    "left_hip", "right_hip",
    "left_knee", "right_knee",
    "left_ankle", "right_ankle",
]


@dataclass(slots=True)
class CameraSolveRow:
    time: float
    frame: int
    success: bool
    fx: float
    fy: float
    cx: float
    cy: float
    tx: float
    ty: float
    tz: float
    rvec_x: float
    rvec_y: float
    rvec_z: float
    points_used: int


def infer_camera_matrix(width: float, height: float, config: PoseWorldConfig) -> np.ndarray:
    fx = fy = float(config.focal_length_px or (max(width, height) * config.focal_length_factor))
    cx = float(width) / 2.0
    cy = float(height) / 2.0
    return np.array([[fx, 0.0, cx], [0.0, fy, cy], [0.0, 0.0, 1.0]], dtype=np.float64)


def _valid_triplet(x: float, y: float, z: float) -> bool:
    return np.isfinite(x) and np.isfinite(y) and np.isfinite(z)


def solve_pose_camera(
    pose2d_row: pd.Series,
    pose3d_row: pd.Series,
    config: PoseWorldConfig,
    width: float,
    height: float,
) -> CameraSolveRow:
    obj_points = []
    img_points = []

    for name in DEFAULT_PNP_MARKERS:
        wx, wy, wz = pose3d_row.get(f"{name}_x"), pose3d_row.get(f"{name}_y"), pose3d_row.get(f"{name}_z")
        ix, iy = pose2d_row.get(f"{name}_x_px"), pose2d_row.get(f"{name}_y_px")
        vis = pose2d_row.get(f"{name}_visibility", np.nan)
        if vis is not None and np.isfinite(vis) and vis < config.visibility_threshold:
            continue
        if _valid_triplet(wx, wy, wz) and np.isfinite(ix) and np.isfinite(iy):
            obj_points.append([float(wx), float(wy), float(wz)])
            img_points.append([float(ix), float(iy)])

    camera = infer_camera_matrix(width, height, config)
    fx = float(camera[0, 0])
    fy = float(camera[1, 1])
    cx = float(camera[0, 2])
    cy = float(camera[1, 2])

    if len(obj_points) < config.min_points:
        return CameraSolveRow(
            time=float(pose2d_row["time"]),
            frame=int(pose2d_row["frame"]),
            success=False,
            fx=fx, fy=fy, cx=cx, cy=cy,
            tx=0.0, ty=0.0, tz=0.0,
            rvec_x=0.0, rvec_y=0.0, rvec_z=0.0,
            points_used=len(obj_points),
        )

    obj = np.asarray(obj_points, dtype=np.float64)
    img = np.asarray(img_points, dtype=np.float64)
    dist = np.zeros((4, 1), dtype=np.float64)

    try:
        success, rvec, tvec = cv2.solvePnP(
            obj,
            img,
            camera,
            dist,
            flags=config.solvepnp_method if config.solvepnp_method is not None else cv2.SOLVEPNP_SQPNP,
        )
    except cv2.error:
        success = False
        rvec = np.zeros((3, 1), dtype=np.float64)
        tvec = np.zeros((3, 1), dtype=np.float64)

    return CameraSolveRow(
        time=float(pose2d_row["time"]),
        frame=int(pose2d_row["frame"]),
        success=bool(success),
        fx=fx, fy=fy, cx=cx, cy=cy,
        tx=float(tvec[0, 0]),
        ty=float(tvec[1, 0]),
        tz=float(tvec[2, 0]),
        rvec_x=float(rvec[0, 0]),
        rvec_y=float(rvec[1, 0]),
        rvec_z=float(rvec[2, 0]),
        points_used=len(obj_points),
    )
