from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Iterable, Sequence

import numpy as np
import pandas as pd

from ._constants import LANDMARK_NAMES

VectorLike = Sequence[float]
ForceCallable = Callable[[float], VectorLike]
PointCallable = Callable[[float], VectorLike]
TorqueCallable = Callable[[float], VectorLike]

GRAVITY = 9.80665


def _vector3(values: VectorLike | np.ndarray | None, *, default: tuple[float, float, float] = (0.0, 0.0, 0.0)) -> tuple[float, float, float]:
    if values is None:
        return default
    arr = np.asarray(list(values), dtype=float).reshape(-1)
    if arr.size != 3:
        raise ValueError(f"Expected a length-3 vector, got {values!r}")
    return float(arr[0]), float(arr[1]), float(arr[2])


@dataclass(slots=True)
class ExternalForce:
    name: str
    applied_to_body: str
    force_data: tuple[float, float, float] | pd.DataFrame | ForceCallable
    point_data: tuple[float, float, float] | pd.DataFrame | PointCallable | str = "body_origin"
    torque_data: tuple[float, float, float] | pd.DataFrame | TorqueCallable | None = None
    expressed_in: str = "ground"
    point_expressed_in: str = "ground"
    point_frame: str = "auto"
    time_window: tuple[float, float] | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def constant(
        cls,
        *,
        name: str,
        applied_to_body: str,
        force: VectorLike,
        point: VectorLike | str = "body_origin",
        torque: VectorLike | None = None,
        expressed_in: str = "ground",
        point_expressed_in: str = "ground",
        point_frame: str = "auto",
        metadata: dict[str, Any] | None = None,
    ) -> "ExternalForce":
        return cls(
            name=name,
            applied_to_body=applied_to_body,
            force_data=_vector3(force),
            point_data=point if isinstance(point, str) else _vector3(point),
            torque_data=None if torque is None else _vector3(torque),
            expressed_in=expressed_in,
            point_expressed_in=point_expressed_in,
            point_frame=point_frame,
            metadata=dict(metadata or {}),
        )

    @classmethod
    def from_dataframe(
        cls,
        *,
        name: str,
        applied_to_body: str,
        dataframe: pd.DataFrame,
        force_cols: tuple[str, str, str] = ("fx", "fy", "fz"),
        point_cols: tuple[str, str, str] = ("px", "py", "pz"),
        torque_cols: tuple[str, str, str] | None = None,
        time_col: str = "time",
        expressed_in: str = "ground",
        point_expressed_in: str = "ground",
        metadata: dict[str, Any] | None = None,
    ) -> "ExternalForce":
        required = [time_col, *force_cols, *point_cols]
        if torque_cols:
            required.extend(torque_cols)
        missing = [col for col in required if col not in dataframe.columns]
        if missing:
            raise ValueError(f"Missing columns for ExternalForce.from_dataframe(): {missing}")
        df = pd.DataFrame(
            {
                "time": pd.to_numeric(dataframe[time_col], errors="coerce"),
                "fx": pd.to_numeric(dataframe[force_cols[0]], errors="coerce"),
                "fy": pd.to_numeric(dataframe[force_cols[1]], errors="coerce"),
                "fz": pd.to_numeric(dataframe[force_cols[2]], errors="coerce"),
                "px": pd.to_numeric(dataframe[point_cols[0]], errors="coerce"),
                "py": pd.to_numeric(dataframe[point_cols[1]], errors="coerce"),
                "pz": pd.to_numeric(dataframe[point_cols[2]], errors="coerce"),
            }
        )
        if torque_cols:
            df["mx"] = pd.to_numeric(dataframe[torque_cols[0]], errors="coerce")
            df["my"] = pd.to_numeric(dataframe[torque_cols[1]], errors="coerce")
            df["mz"] = pd.to_numeric(dataframe[torque_cols[2]], errors="coerce")
        return cls(
            name=name,
            applied_to_body=applied_to_body,
            force_data=df[["time", "fx", "fy", "fz"]].copy(),
            point_data=df[["time", "px", "py", "pz"]].copy(),
            torque_data=df[["time", "mx", "my", "mz"]].copy() if {"mx", "my", "mz"}.issubset(df.columns) else None,
            expressed_in=expressed_in,
            point_expressed_in=point_expressed_in,
            metadata=dict(metadata or {}),
        )

    @classmethod
    def from_callable(
        cls,
        *,
        name: str,
        applied_to_body: str,
        force_fn: ForceCallable,
        point_fn: PointCallable | str = "body_origin",
        torque_fn: TorqueCallable | None = None,
        expressed_in: str = "ground",
        point_expressed_in: str = "ground",
        metadata: dict[str, Any] | None = None,
    ) -> "ExternalForce":
        return cls(
            name=name,
            applied_to_body=applied_to_body,
            force_data=force_fn,
            point_data=point_fn,
            torque_data=torque_fn,
            expressed_in=expressed_in,
            point_expressed_in=point_expressed_in,
            metadata=dict(metadata or {}),
        )

    @classmethod
    def from_mass(
        cls,
        *,
        name: str,
        applied_to_body: str,
        mass_kg: float,
        point: VectorLike | str = "segment_com",
        gravity_vector: VectorLike = (0.0, -GRAVITY, 0.0),
        metadata: dict[str, Any] | None = None,
    ) -> "ExternalForce":
        gravity = np.asarray(_vector3(gravity_vector), dtype=float)
        force = tuple((gravity * float(mass_kg)).tolist())
        meta = {"kind": "carried_mass", "mass_kg": float(mass_kg)}
        if metadata:
            meta.update(metadata)
        return cls.constant(
            name=name,
            applied_to_body=applied_to_body,
            force=force,
            point=point,
            metadata=meta,
        )

    def _evaluate_table(self, table: pd.DataFrame, time_s: float, cols: tuple[str, str, str]) -> tuple[float, float, float]:
        frame = table.sort_values("time")
        numeric_time = pd.to_numeric(frame["time"], errors="coerce")
        values = []
        for col in cols:
            series = pd.to_numeric(frame[col], errors="coerce")
            values.append(float(np.interp(time_s, numeric_time.to_numpy(dtype=float), series.to_numpy(dtype=float))))
        return float(values[0]), float(values[1]), float(values[2])

    def _resolve_landmark_point(self, landmark_name: str, poseworld_row: pd.Series | None) -> tuple[float, float, float]:
        if poseworld_row is None:
            raise ValueError(f"Force {self.name!r} requires poseworld data for landmark point {landmark_name!r}.")
        cols = [f"{landmark_name}_x", f"{landmark_name}_y", f"{landmark_name}_z"]
        return tuple(float(poseworld_row[c]) for c in cols)  # type: ignore[return-value]

    def _resolve_model_point(self, point_kind: str, model_context: dict[str, Any] | None) -> tuple[float, float, float]:
        if model_context is None:
            return (0.0, 0.0, 0.0)
        body_name = self.applied_to_body
        if point_kind == "body_origin":
            return tuple(float(v) for v in model_context["body_origin"](body_name))  # type: ignore[return-value]
        if point_kind == "segment_com":
            return tuple(float(v) for v in model_context["segment_com"](body_name))  # type: ignore[return-value]
        raise ValueError(f"Unsupported point kind: {point_kind}")

    def evaluate_at(
        self,
        time_s: float,
        *,
        poseworld_row: pd.Series | None = None,
        model_context: dict[str, Any] | None = None,
    ) -> dict[str, float | str]:
        if self.time_window is not None:
            start, end = self.time_window
            if not (float(start) <= float(time_s) <= float(end)):
                return {
                    "time": float(time_s),
                    "force_name": self.name,
                    "applied_to_body": self.applied_to_body,
                    "fx": 0.0,
                    "fy": 0.0,
                    "fz": 0.0,
                    "px": 0.0,
                    "py": 0.0,
                    "pz": 0.0,
                    "mx": 0.0,
                    "my": 0.0,
                    "mz": 0.0,
                    "expressed_in": self.expressed_in,
                    "point_expressed_in": self.point_expressed_in,
                }

        if isinstance(self.force_data, pd.DataFrame):
            fx, fy, fz = self._evaluate_table(self.force_data, time_s, ("fx", "fy", "fz"))
        elif callable(self.force_data):
            if self.metadata.get("kind") == "line_of_action":
                fx, fy, fz = (0.0, 0.0, 0.0)
            else:
                fx, fy, fz = _vector3(self.force_data(float(time_s)))
        else:
            fx, fy, fz = _vector3(self.force_data)

        if isinstance(self.point_data, pd.DataFrame):
            px, py, pz = self._evaluate_table(self.point_data, time_s, ("px", "py", "pz"))
        elif callable(self.point_data):
            px, py, pz = _vector3(self.point_data(float(time_s)))
        elif isinstance(self.point_data, str):
            point_key = self.point_data.lower()
            if point_key in {"body_origin", "segment_com"}:
                px, py, pz = self._resolve_model_point(point_key, model_context)
            elif point_key in LANDMARK_NAMES:
                px, py, pz = self._resolve_landmark_point(point_key, poseworld_row)
            else:
                raise ValueError(
                    f"Unsupported point string {self.point_data!r}. Use 'body_origin', 'segment_com', a landmark name, or a numeric point."
                )
        else:
            px, py, pz = _vector3(self.point_data)
            if self.point_frame == "local":
                if model_context is None:
                    raise ValueError(f"Force {self.name!r} requires model context to transform local points.")
                px, py, pz = tuple(float(v) for v in model_context["local_point"](self.applied_to_body, (px, py, pz)))  # type: ignore[assignment]

        if isinstance(self.torque_data, pd.DataFrame):
            mx, my, mz = self._evaluate_table(self.torque_data, time_s, ("mx", "my", "mz"))
        elif callable(self.torque_data):
            mx, my, mz = _vector3(self.torque_data(float(time_s)))
        else:
            mx, my, mz = _vector3(self.torque_data)

        return {
            "time": float(time_s),
            "force_name": self.name,
            "applied_to_body": self.applied_to_body,
            "fx": float(fx),
            "fy": float(fy),
            "fz": float(fz),
            "px": float(px),
            "py": float(py),
            "pz": float(pz),
            "mx": float(mx),
            "my": float(my),
            "mz": float(mz),
            "expressed_in": self.expressed_in,
            "point_expressed_in": self.point_expressed_in,
        }

    def evaluate_many(
        self,
        time_values: Iterable[float],
        *,
        poseworld_df: pd.DataFrame | None = None,
        model_context_factory: Callable[[float], dict[str, Any] | None] | None = None,
    ) -> pd.DataFrame:
        rows: list[dict[str, float | str]] = []
        poseworld_lookup: pd.DataFrame | None = None
        if poseworld_df is not None and not poseworld_df.empty and "time" in poseworld_df.columns:
            poseworld_lookup = poseworld_df.sort_values("time")
        for time_s in time_values:
            pose_row = None
            if poseworld_lookup is not None:
                idx = poseworld_lookup["time"].sub(float(time_s)).abs().idxmin()
                pose_row = poseworld_lookup.loc[idx]
            model_context = model_context_factory(float(time_s)) if model_context_factory is not None else None
            rows.append(self.evaluate_at(float(time_s), poseworld_row=pose_row, model_context=model_context))
        return pd.DataFrame(rows)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ExternalForce":
        kind = str(data.get("kind", "constant")).lower()
        if kind == "constant":
            return cls.constant(
                name=data["name"],
                applied_to_body=data["applied_to_body"],
                force=data["force"],
                point=data.get("point", "body_origin"),
                torque=data.get("torque"),
                expressed_in=data.get("expressed_in", "ground"),
                point_expressed_in=data.get("point_expressed_in", "ground"),
                point_frame=data.get("point_frame", "auto"),
                metadata=data.get("metadata"),
            )
        if kind == "carried_mass":
            return cls.from_mass(
                name=data["name"],
                applied_to_body=data["applied_to_body"],
                mass_kg=float(data["mass_kg"]),
                point=data.get("point", "segment_com"),
                gravity_vector=data.get("gravity_vector", (0.0, -GRAVITY, 0.0)),
                metadata=data.get("metadata"),
            )
        raise ValueError(f"Unsupported ExternalForce kind: {kind}")


@dataclass(slots=True)
class ExternalForceSet:
    forces: list[ExternalForce] = field(default_factory=list)

    def add(self, force: ExternalForce) -> None:
        self.forces.append(force)

    def remove(self, name: str) -> None:
        self.forces = [force for force in self.forces if force.name != name]

    def names(self) -> list[str]:
        return [force.name for force in self.forces]

    def validate(self) -> pd.DataFrame:
        rows = []
        seen: set[str] = set()
        for force in self.forces:
            duplicate = force.name in seen
            seen.add(force.name)
            rows.append(
                {
                    "name": force.name,
                    "applied_to_body": force.applied_to_body,
                    "expressed_in": force.expressed_in,
                    "point_expressed_in": force.point_expressed_in,
                    "duplicate_name": duplicate,
                    "point_kind": force.point_data if isinstance(force.point_data, str) else type(force.point_data).__name__,
                }
            )
        return pd.DataFrame(rows)

    def to_dataframe(
        self,
        time_values: Iterable[float],
        *,
        poseworld_df: pd.DataFrame | None = None,
        model_context_factory: Callable[[float], dict[str, Any] | None] | None = None,
    ) -> pd.DataFrame:
        parts = []
        for force in self.forces:
            parts.append(force.evaluate_many(time_values, poseworld_df=poseworld_df, model_context_factory=model_context_factory))
        return pd.concat(parts, ignore_index=True) if parts else pd.DataFrame(columns=["time", "force_name"])


def external_force(
    *,
    name: str,
    body: str,
    force: VectorLike,
    point: VectorLike | str = "body_origin",
    torque: VectorLike | None = None,
    expressed_in: str = "ground",
    point_expressed_in: str = "ground",
    point_frame: str = "auto",
    metadata: dict[str, Any] | None = None,
) -> ExternalForce:
    return ExternalForce.constant(
        name=name,
        applied_to_body=body,
        force=force,
        point=point,
        torque=torque,
        expressed_in=expressed_in,
        point_expressed_in=point_expressed_in,
        point_frame=point_frame,
        metadata=metadata,
    )


def carried_mass(
    *,
    body: str,
    mass_kg: float,
    point: VectorLike | str = "segment_com",
    name: str | None = None,
) -> ExternalForce:
    return ExternalForce.from_mass(
        name=name or f"carried_mass_{body}",
        applied_to_body=body,
        mass_kg=mass_kg,
        point=point,
    )


def line_of_action_force(
    *,
    name: str,
    body: str,
    magnitude: float,
    start: str,
    end: str,
    point: str | None = None,
) -> ExternalForce:
    start = start.lower()
    end = end.lower()
    if start not in LANDMARK_NAMES or end not in LANDMARK_NAMES:
        raise ValueError("line_of_action_force start/end must be landmark names available in poseworld output.")

    def force_fn(_: float) -> tuple[float, float, float]:
        raise RuntimeError("line_of_action_force requires poseworld-aware evaluation in OpenSim loads builder.")

    return ExternalForce.from_callable(
        name=name,
        applied_to_body=body,
        force_fn=force_fn,
        point_fn=point or start,
        metadata={"kind": "line_of_action", "magnitude": float(magnitude), "start": start, "end": end},
    )


def resolve_line_of_action(force: ExternalForce, poseworld_row: pd.Series) -> tuple[float, float, float]:
    magnitude = float(force.metadata["magnitude"])
    start = str(force.metadata["start"])
    end = str(force.metadata["end"])
    start_vec = np.array([poseworld_row[f"{start}_x"], poseworld_row[f"{start}_y"], poseworld_row[f"{start}_z"]], dtype=float)
    end_vec = np.array([poseworld_row[f"{end}_x"], poseworld_row[f"{end}_y"], poseworld_row[f"{end}_z"]], dtype=float)
    direction = end_vec - start_vec
    norm = float(np.linalg.norm(direction))
    if norm <= 1e-12:
        return (0.0, 0.0, 0.0)
    vec = direction / norm * magnitude
    return float(vec[0]), float(vec[1]), float(vec[2])


ExternalForceSpec = ExternalForce


def constant_force(*, name: str, body_name: str, force_vector: tuple[float, float, float], point_in_body: tuple[float, float, float] = (0.0, 0.0, 0.0)) -> ExternalForce:
    return external_force(name=name, body=body_name, force=force_vector, point=point_in_body, point_frame="local")


def dumbbell_force(*, side: str = "right", mass_kg: float | None = None, weight_lb: float | None = None, point_in_body: tuple[float, float, float] = (0.0, -0.02, 0.0), body_name: str | None = None) -> ExternalForce:
    side_norm = side.lower().strip()
    if side_norm not in {"left", "right", "l", "r"}:
        raise ValueError("side must be left/right or l/r.")
    side_norm = "left" if side_norm.startswith("l") else "right"
    if mass_kg is None and weight_lb is None:
        raise ValueError("Provide mass_kg or weight_lb for dumbbell_force().")
    if mass_kg is None:
        mass_kg = float(weight_lb) * 0.45359237
    target_body = body_name or ("hand_l" if side_norm == "left" else "hand_r")
    return ExternalForce.from_mass(
        name=f"dumbbell_{side_norm}",
        applied_to_body=target_body,
        mass_kg=float(mass_kg),
        point=point_in_body,
        metadata={"source": "dumbbell_force", "side": side_norm},
    )
