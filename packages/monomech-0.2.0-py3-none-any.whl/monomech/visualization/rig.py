from __future__ import annotations

import base64
from pathlib import Path

import pandas as pd
import yaml

from ..utils import json_dumps_compact


def render_rig_motion_html(
    mot_df: pd.DataFrame,
    output_html: str | Path,
    *,
    fbx_path: str | Path,
    rig_map_path: str | Path | None = None,
    title: str = "MonoMech Rig Viewer",
    in_degrees: bool = True,
    embed_model: bool = True,
) -> Path:
    output_html = Path(output_html)
    output_html.parent.mkdir(parents=True, exist_ok=True)
    fbx_path = Path(fbx_path)

    if rig_map_path is None:
        rig_map_path = Path(__file__).resolve().parents[1] / "assets" / "default_rig_map.yml"
    rig_map = yaml.safe_load(Path(rig_map_path).read_text(encoding="utf-8"))

    if embed_model:
        fbx_bytes = fbx_path.read_bytes()
        fbx_payload = base64.b64encode(fbx_bytes).decode("ascii")
        model_loader_block = f"""
const MODEL_BASE64 = "{fbx_payload}";
const fbxArrayBuffer = Uint8Array.from(atob(MODEL_BASE64), c => c.charCodeAt(0)).buffer;
const object = loader.parse(fbxArrayBuffer, "");
"""
    else:
        model_loader_block = f"""
const response = await fetch({json_dumps_compact(str(fbx_path))});
const fbxArrayBuffer = await response.arrayBuffer();
const object = loader.parse(fbxArrayBuffer, "");
"""

    mot_json = mot_df.to_dict(orient="records")

    html = f"""<!doctype html>
<html>
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>{title}</title>
<style>
body {{ margin:0; font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif; background:#0b1020; color:#edf2ff; }}
#app {{ display:grid; grid-template-rows:auto 1fr; height:100vh; }}
header {{ display:flex; flex-wrap:wrap; gap:10px; align-items:center; padding:10px 14px; background:#121a33; border-bottom:1px solid #24304f; }}
#view {{ position:relative; }}
button, input {{ background:#121a33; color:#edf2ff; border:1px solid #31456f; border-radius:8px; padding:6px 10px; }}
#status {{ margin-left:auto; opacity:0.8; }}
</style>
<script type="importmap">
{{
  "imports": {{
    "three": "https://unpkg.com/three@0.160.0/build/three.module.js",
    "three/addons/": "https://unpkg.com/three@0.160.0/examples/jsm/"
  }}
}}
</script>
</head>
<body>
<div id="app">
  <header>
    <strong>{title}</strong>
    <button id="btnPlay">Play</button>
    <button id="btnPause">Pause</button>
    <input id="slider" type="range" min="0" max="{max(0, len(mot_df)-1)}" step="1" value="0" style="width:280px"/>
    <span id="timeLabel"></span>
    <span id="status">Loading FBX…</span>
  </header>
  <div id="view"></div>
</div>
<script type="module">
import * as THREE from "three";
import {{ OrbitControls }} from "three/addons/controls/OrbitControls.js";
import {{ FBXLoader }} from "three/addons/loaders/FBXLoader.js";

const motion = {json_dumps_compact(mot_json)};
const rigMap = {json_dumps_compact(rig_map)};
const IN_DEGREES = {str(bool(in_degrees)).lower()};
const slider = document.getElementById('slider');
const timeLabel = document.getElementById('timeLabel');
const statusEl = document.getElementById('status');
const view = document.getElementById('view');

const renderer = new THREE.WebGLRenderer({{antialias:true, alpha:true}});
renderer.setSize(window.innerWidth, window.innerHeight - 52);
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.75));
view.appendChild(renderer.domElement);

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x0b1020);

const camera = new THREE.PerspectiveCamera(45, window.innerWidth / Math.max(1, window.innerHeight-52), 0.01, 1000);
camera.position.set(0, 1.2, 3.5);

const controls = new OrbitControls(camera, renderer.domElement);
controls.enableDamping = true;

scene.add(new THREE.HemisphereLight(0xffffff, 0x222244, 1.1));
const dir = new THREE.DirectionalLight(0xffffff, 1.0);
dir.position.set(2, 4, 3);
scene.add(dir);
scene.add(new THREE.GridHelper(4, 8, 0x35508a, 0x1b274b));

let avatar = null;
let boneIndex = new Map();
let playing = false;

function rad(v) {{
  if (v == null || Number.isNaN(v)) return 0;
  return IN_DEGREES ? (v * Math.PI / 180.0) : v;
}}

function findBone(candidates) {{
  for (const name of candidates || []) {{
    if (boneIndex.has(name)) return boneIndex.get(name);
  }}
  return null;
}}

function indexBones(root) {{
  root.traverse((obj) => {{
    if (obj.isBone) boneIndex.set(obj.name, obj);
  }});
}}

function applyCoordinate(row, coordName, spec) {{
  const bone = findBone(spec.bone_candidates);
  if (!bone || !(coordName in row)) return;
  const value = row[coordName];
  const mult = spec.multiplier ?? 1.0;
  if (spec.channel === 'rotation_x') bone.rotation.x = rad(value) * mult;
  if (spec.channel === 'rotation_y') bone.rotation.y = rad(value) * mult;
  if (spec.channel === 'rotation_z') bone.rotation.z = rad(value) * mult;
  if (spec.channel === 'position_x') bone.position.x = Number(value || 0) * mult;
  if (spec.channel === 'position_y') bone.position.y = Number(value || 0) * mult;
  if (spec.channel === 'position_z') bone.position.z = Number(value || 0) * mult;
}}

function applyFrame(i) {{
  if (!avatar || !motion.length) return;
  const row = motion[i];
  for (const [coordName, spec] of Object.entries(rigMap.coordinate_map || {{}})) {{
    applyCoordinate(row, coordName, spec);
  }}
  timeLabel.textContent = `t=${{Number(row.time || 0).toFixed(3)}}s`;
}}

async function init() {{
  const loader = new FBXLoader();
  {model_loader_block}
  avatar = object;
  scene.add(avatar);
  avatar.scale.setScalar(0.01);
  indexBones(avatar);
  statusEl.textContent = `FBX loaded · bones=${{boneIndex.size}}`;
  applyFrame(0);
}}

function animate() {{
  requestAnimationFrame(animate);
  if (playing && motion.length) {{
    let i = Number(slider.value);
    i = (i + 1) % motion.length;
    slider.value = String(i);
    applyFrame(i);
  }}
  controls.update();
  renderer.render(scene, camera);
}}

window.addEventListener('resize', ()=> {{
  const h = window.innerHeight - 52;
  renderer.setSize(window.innerWidth, h);
  camera.aspect = window.innerWidth / Math.max(1, h);
  camera.updateProjectionMatrix();
}});

slider.addEventListener('input', ()=> applyFrame(Number(slider.value)));
document.getElementById('btnPlay').addEventListener('click', ()=> playing = true);
document.getElementById('btnPause').addEventListener('click', ()=> playing = false);

init().catch((err)=> {{
  console.error(err);
  statusEl.textContent = "FBX load failed: " + String(err);
}});
animate();
</script>
</body>
</html>
"""
    output_html.write_text(html, encoding="utf-8")
    return output_html
