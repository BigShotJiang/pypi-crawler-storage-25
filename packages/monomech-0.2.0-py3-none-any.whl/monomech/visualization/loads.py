from __future__ import annotations

from pathlib import Path

import pandas as pd

from ..utils import json_dumps_compact


def render_loads_html(loads_df: pd.DataFrame, output_html: str | Path, *, title: str = "MonoMech External Loads") -> Path:
    output_html = Path(output_html)
    output_html.parent.mkdir(parents=True, exist_ok=True)

    traces: dict[str, dict[str, list[float]]] = {}
    if not loads_df.empty:
        for force_name, group in loads_df.groupby("force_name"):
            group = group.sort_values("time")
            traces[str(force_name)] = {
                "time": [float(v) for v in group["time"].tolist()],
                "fx": [float(v) for v in group["fx"].tolist()],
                "fy": [float(v) for v in group["fy"].tolist()],
                "fz": [float(v) for v in group["fz"].tolist()],
                "magnitude": [float((row.fx**2 + row.fy**2 + row.fz**2) ** 0.5) for row in group.itertuples()],
                "px": [float(v) for v in group["px"].tolist()],
                "py": [float(v) for v in group["py"].tolist()],
                "pz": [float(v) for v in group["pz"].tolist()],
            }

    html = f"""<!doctype html>
<html>
<head>
<meta charset=\"utf-8\"/>
<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"/>
<title>{title}</title>
<script src=\"https://cdn.plot.ly/plotly-2.35.2.min.js\"></script>
<style>
body {{ margin:0; font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif; background:#0b1020; color:#edf2ff; }}
#app {{ display:grid; grid-template-rows:auto 1fr 1fr; height:100vh; }}
header {{ padding:10px 14px; display:flex; gap:12px; align-items:center; background:#121a33; border-bottom:1px solid #24304f; }}
select {{ background:#121a33; color:#edf2ff; border:1px solid #31456f; border-radius:8px; padding:6px 10px; }}
.panel {{ min-height:0; }}
</style>
</head>
<body>
<div id=\"app\">
  <header>
    <strong>{title}</strong>
    <label>Force <select id=\"forceSel\"></select></label>
  </header>
  <div class=\"panel\" id=\"forcePlot\"></div>
  <div class=\"panel\" id=\"pointPlot\"></div>
</div>
<script>
const traces = {json_dumps_compact(traces)};
const names = Object.keys(traces);
const forceSel = document.getElementById('forceSel');
for (const name of names) {{
  const opt = document.createElement('option');
  opt.value = name;
  opt.textContent = name;
  forceSel.appendChild(opt);
}}
function render(name) {{
  const tr = traces[name] || {{time:[], fx:[], fy:[], fz:[], magnitude:[], px:[], py:[], pz:[]}};
  Plotly.react('forcePlot', [
    {{type:'scatter', mode:'lines', name:'Fx', x:tr.time, y:tr.fx}},
    {{type:'scatter', mode:'lines', name:'Fy', x:tr.time, y:tr.fy}},
    {{type:'scatter', mode:'lines', name:'Fz', x:tr.time, y:tr.fz}},
    {{type:'scatter', mode:'lines', name:'|F|', x:tr.time, y:tr.magnitude}},
  ], {{paper_bgcolor:'#0b1020', plot_bgcolor:'#0b1020', font:{{color:'#edf2ff'}}, title:`${{name}} force`, xaxis:{{title:'time (s)'}}, yaxis:{{title:'N'}}}}, {{displaylogo:false}});
  Plotly.react('pointPlot', [
    {{type:'scatter', mode:'lines', name:'Px', x:tr.time, y:tr.px}},
    {{type:'scatter', mode:'lines', name:'Py', x:tr.time, y:tr.py}},
    {{type:'scatter', mode:'lines', name:'Pz', x:tr.time, y:tr.pz}},
  ], {{paper_bgcolor:'#0b1020', plot_bgcolor:'#0b1020', font:{{color:'#edf2ff'}}, title:`${{name}} point`, xaxis:{{title:'time (s)'}}, yaxis:{{title:'m'}}}}, {{displaylogo:false}});
}}
forceSel.addEventListener('change', ()=> render(forceSel.value));
if (names.length) {{ forceSel.value = names[0]; render(names[0]); }}
</script>
</body>
</html>"""
    output_html.write_text(html, encoding="utf-8")
    return output_html
