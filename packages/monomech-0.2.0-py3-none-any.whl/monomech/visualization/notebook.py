from __future__ import annotations

from pathlib import Path

from IPython.display import HTML, IFrame  # type: ignore


def iframe_for_path(path: str | Path, width: str = "100%", height: int = 720):
    path = Path(path)
    return IFrame(src=str(path), width=width, height=height)


def html_file(path: str | Path, width: str = "100%", height: int = 720):
    return iframe_for_path(path, width=width, height=height)


def html_string(html: str):
    return HTML(html)
