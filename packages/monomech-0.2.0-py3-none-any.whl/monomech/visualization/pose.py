from __future__ import annotations

from pathlib import Path

import pandas as pd

from .._constants import LANDMARK_NAMES, POSE_CONNECTIONS
from ..utils import json_dumps_compact


def _extract_frames(df: pd.DataFrame) -> list[dict]:
    frames = []
    for _, row in df.iterrows():
        xs, ys, zs = [], [], []
        for name in LANDMARK_NAMES:
            xs.append(None if pd.isna(row.get(f"{name}_x")) else float(row.get(f"{name}_x")))
            ys.append(None if pd.isna(row.get(f"{name}_y")) else float(row.get(f"{name}_y")))
            zs.append(None if pd.isna(row.get(f"{name}_z")) else float(row.get(f"{name}_z")))
        frames.append({"time": float(row.get("time", 0.0)), "x": xs, "y": ys, "z": zs})
    return frames


def _trace_lookup(df: pd.DataFrame) -> dict:
    traces: dict[str, dict[str, list[float | None]]] = {}
    for name in LANDMARK_NAMES:
        traces[name] = {
            "t": [float(v) if pd.notna(v) else None for v in df["time"].tolist()],
            "x": [None if pd.isna(v) else float(v) for v in df[f"{name}_x"].tolist()],
            "y": [None if pd.isna(v) else float(v) for v in df[f"{name}_y"].tolist()],
            "z": [None if pd.isna(v) else float(v) for v in df[f"{name}_z"].tolist()],
        }
    return traces


def render_pose_analysis_html(
    pose_df: pd.DataFrame,
    output_html: str | Path,
    *,
    title: str = "MonoMech Pose Analysis",
) -> Path:
    output_html = Path(output_html)
    output_html.parent.mkdir(parents=True, exist_ok=True)

    frames = _extract_frames(pose_df)
    traces = _trace_lookup(pose_df)
    connections = POSE_CONNECTIONS

    html = f"""<!doctype html>
<html>
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>{title}</title>
<script src="https://cdn.plot.ly/plotly-2.35.2.min.js"></script>
<style>
body {{ margin:0; font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif; background:#0b1020; color:#edf2ff; }}
#app {{ display:grid; grid-template-rows:auto 1fr; height:100vh; }}
header {{ padding:10px 14px; display:flex; flex-wrap:wrap; gap:10px; align-items:center; background:#121a33; border-bottom:1px solid #24304f; }}
.panel {{ display:grid; grid-template-columns: 1.3fr 1fr; min-height:0; }}
#plot3d, #plot2d {{ min-height:0; }}
select, button, input {{ background:#121a33; color:#edf2ff; border:1px solid #31456f; border-radius:8px; padding:6px 10px; }}
label {{ display:flex; gap:8px; align-items:center; }}
</style>
</head>
<body>
<div id="app">
  <header>
    <strong>{title}</strong>
    <label>Joint
      <select id="jointSel"></select>
    </label>
    <button id="btnPlay">Play</button>
    <button id="btnPause">Pause</button>
    <label>Frame <input id="slider" type="range" min="0" max="{max(0, len(frames)-1)}" step="1" value="0" style="width:260px"/></label>
    <span id="timeLabel"></span>
  </header>
  <div class="panel">
    <div id="plot3d"></div>
    <div id="plot2d"></div>
  </div>
</div>
<script>
const frames = {json_dumps_compact(frames)};
const traces = {json_dumps_compact(traces)};
const connections = {json_dumps_compact(connections)};
const jointNames = {json_dumps_compact(LANDMARK_NAMES)};
const slider = document.getElementById('slider');
const timeLabel = document.getElementById('timeLabel');
const jointSel = document.getElementById('jointSel');
const plot3d = document.getElementById('plot3d');
const plot2d = document.getElementById('plot2d');

jointNames.forEach((name)=> {{
  const opt = document.createElement('option');
  opt.value = name;
  opt.textContent = name;
  jointSel.appendChild(opt);
}});
jointSel.value = 'right_wrist';

function segmentLines(frame) {{
  const xs = [], ys = [], zs = [];
  for (const [a,b] of connections) {{
    const ai = jointNames.indexOf(a), bi = jointNames.indexOf(b);
    xs.push(frame.x[ai], frame.x[bi], null);
    ys.push(frame.y[ai], frame.y[bi], null);
    zs.push(frame.z[ai], frame.z[bi], null);
  }}
  return {{x: xs, y: ys, z: zs}};
}}

function renderFrame(i) {{
  const frame = frames[i];
  if (!frame) return;
  const seg = segmentLines(frame);
  Plotly.react(plot3d, [
    {{
      type:'scatter3d',
      mode:'markers',
      x: frame.x, y: frame.y, z: frame.z,
      marker: {{ size: 4 }}
    }},
    {{
      type:'scatter3d',
      mode:'lines',
      x: seg.x, y: seg.y, z: seg.z,
      line: {{ width: 5 }}
    }}
  ], {{
    paper_bgcolor:'#0b1020',
    plot_bgcolor:'#0b1020',
    font: {{ color:'#edf2ff' }},
    margin: {{l:0, r:0, t:10, b:0}},
    scene: {{
      xaxis: {{title:'x'}},
      yaxis: {{title:'y'}},
      zaxis: {{title:'z'}},
      camera: {{eye: {{x:1.25,y:1.1,z:1.2}}}},
      aspectmode:'data'
    }}
  }}, {{displaylogo:false}});
  timeLabel.textContent = `t=${{frame.time.toFixed(3)}}s`;
}}

function renderTrace(name) {{
  const tr = traces[name];
  Plotly.react(plot2d, [
    {{type:'scatter', mode:'lines', name:'x', x: tr.t, y: tr.x}},
    {{type:'scatter', mode:'lines', name:'y', x: tr.t, y: tr.y}},
    {{type:'scatter', mode:'lines', name:'z', x: tr.t, y: tr.z}},
  ], {{
    paper_bgcolor:'#0b1020',
    plot_bgcolor:'#0b1020',
    font: {{ color:'#edf2ff' }},
    title: `${{name}} trace`,
    xaxis: {{title:'time (s)'}},
    yaxis: {{title:'position'}},
    margin: {{l:40, r:20, t:40, b:40}},
  }}, {{displaylogo:false}});
}}

slider.addEventListener('input', ()=> renderFrame(Number(slider.value)));
jointSel.addEventListener('change', ()=> renderTrace(jointSel.value));
document.getElementById('btnPause').addEventListener('click', ()=> window._playing = false);
document.getElementById('btnPlay').addEventListener('click', ()=> {{
  window._playing = true;
  const step = ()=> {{
    if (!window._playing) return;
    let i = Number(slider.value);
    i = (i + 1) % frames.length;
    slider.value = String(i);
    renderFrame(i);
    requestAnimationFrame(step);
  }};
  requestAnimationFrame(step);
}});

renderFrame(0);
renderTrace(jointSel.value);
</script>
</body>
</html>"""
    output_html.write_text(html, encoding="utf-8")
    return output_html
