from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import pandas as pd

from .utils import dataframe_preview_html


@dataclass
class StageResult:
    name: str
    dataframe: pd.DataFrame
    artifacts: dict[str, Path] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)
    wide_dataframe: pd.DataFrame | None = None

    @property
    def files(self) -> dict[str, Path]:
        return self.artifacts

    def inspect(self) -> pd.DataFrame:
        return self.dataframe

    def preview(self, n: int = 5) -> pd.DataFrame:
        return self.dataframe.head(n)

    def to_csv(self, path: str | Path | None = None, index: bool = False) -> Path:
        target = Path(path) if path is not None else self.artifacts.get("csv")
        if target is None:
            raise ValueError(f"No CSV target available for stage {self.name!r}.")
        target.parent.mkdir(parents=True, exist_ok=True)
        self.dataframe.to_csv(target, index=index)
        self.artifacts["csv"] = target
        return target

    def to_parquet(self, path: str | Path | None = None, index: bool = False) -> Path:
        target = Path(path) if path is not None else self.artifacts.get("parquet")
        if target is None:
            raise ValueError(f"No parquet target available for stage {self.name!r}.")
        target.parent.mkdir(parents=True, exist_ok=True)
        self.dataframe.to_parquet(target, index=index)
        self.artifacts["parquet"] = target
        return target

    def show(self) -> object:
        from .visualization.notebook import iframe_for_path

        html_path = self.artifacts.get("html") or self.artifacts.get("viewer")
        if html_path is None:
            return self.preview()
        return iframe_for_path(html_path)

    def _repr_html_(self) -> str:
        header = f"<h4>{self.name}</h4>"
        artifact_bits = "".join(f"<li><strong>{k}</strong>: {v}</li>" for k, v in sorted(self.artifacts.items()))
        artifacts = f"<ul>{artifact_bits}</ul>" if artifact_bits else "<em>No artifacts</em>"
        return header + dataframe_preview_html(self.dataframe) + "<hr/>" + artifacts


@dataclass
class TrialResult:
    video_path: Path
    output_dir: Path
    stages: dict[str, StageResult] = field(default_factory=dict)
    visualizations: dict[str, Path] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)

    def add_stage(self, stage: StageResult) -> None:
        self.stages[stage.name] = stage

    def __getattr__(self, item: str) -> StageResult:
        if item in self.stages:
            return self.stages[item]
        raise AttributeError(item)

    def stage(self, name: str) -> StageResult:
        return self.stages[name]

    def dataframe(self, name: str) -> pd.DataFrame:
        return self.stages[name].dataframe

    def summary(self) -> pd.DataFrame:
        rows = []
        for name, stage in self.stages.items():
            rows.append(
                {
                    "stage": name,
                    "rows": len(stage.dataframe),
                    "columns": len(stage.dataframe.columns),
                    "artifacts": ", ".join(sorted(stage.artifacts)),
                }
            )
        return pd.DataFrame(rows)


@dataclass
class BatchResult:
    trials: list[TrialResult]

    def summary(self) -> pd.DataFrame:
        rows = []
        for trial in self.trials:
            for name, stage in trial.stages.items():
                rows.append(
                    {
                        "video": str(trial.video_path),
                        "stage": name,
                        "rows": len(stage.dataframe),
                        "columns": len(stage.dataframe.columns),
                        "output_dir": str(trial.output_dir),
                    }
                )
        return pd.DataFrame(rows)
