from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path


@dataclass(slots=True)
class PoseExtractionConfig:
    backend: str = "auto"
    stride: int = 1
    task_model_path: str | None = None
    model_complexity: int = 2
    min_detection_confidence: float = 0.5
    min_tracking_confidence: float = 0.5
    smooth_landmarks: bool = True
    progress: bool = True


@dataclass(slots=True)
class PoseWorldConfig:
    focal_length_px: float | None = None
    focal_length_factor: float = 0.60
    use_full_transform: bool = False
    floor_mode: str = "trial_min"
    ground_y: bool = True
    solvepnp_method: int | None = None
    min_points: int = 6
    visibility_threshold: float = 0.25


@dataclass(slots=True)
class GapFillConfig:
    enabled: bool = True
    max_gap_frames: int = 6
    method: str = "linear"
    limit_area: str = "inside"


@dataclass(slots=True)
class SmoothingConfig:
    enabled: bool = True
    method: str = "savitzky_golay"
    window_length: int = 9
    polyorder: int = 2
    rolling_window: int = 5


@dataclass(slots=True)
class StagePostProcessConfig:
    enabled: bool = True
    gap_fill: GapFillConfig = field(default_factory=GapFillConfig)
    smoothing: SmoothingConfig = field(default_factory=SmoothingConfig)


@dataclass(slots=True)
class PostProcessConfig:
    pose2d: StagePostProcessConfig = field(
        default_factory=lambda: StagePostProcessConfig(
            enabled=False,
            gap_fill=GapFillConfig(enabled=True, max_gap_frames=4),
            smoothing=SmoothingConfig(enabled=False),
        )
    )
    pose3d: StagePostProcessConfig = field(
        default_factory=lambda: StagePostProcessConfig(
            enabled=True,
            gap_fill=GapFillConfig(enabled=True, max_gap_frames=6),
            smoothing=SmoothingConfig(enabled=True, method="savitzky_golay", window_length=9, polyorder=2),
        )
    )
    poseworld: StagePostProcessConfig = field(
        default_factory=lambda: StagePostProcessConfig(
            enabled=True,
            gap_fill=GapFillConfig(enabled=True, max_gap_frames=6),
            smoothing=SmoothingConfig(enabled=True, method="savitzky_golay", window_length=11, polyorder=2),
        )
    )


@dataclass(slots=True)
class OpenSimConfig:
    run_inverse_kinematics: bool = True
    run_inverse_dynamics: bool = True
    lowpass_cutoff_hz: float = 6.0
    in_degrees: bool = True
    force_expressed_in_body: str = "ground"
    point_expressed_in_body: str = "ground"
    default_mass_kg: float = 75.0
    default_height_m: float = 1.75


@dataclass(slots=True)
class PipelineConfig:
    output_root: str | Path = "monomech_outputs"
    pose: PoseExtractionConfig = field(default_factory=PoseExtractionConfig)
    poseworld: PoseWorldConfig = field(default_factory=PoseWorldConfig)
    postprocess: PostProcessConfig = field(default_factory=PostProcessConfig)
    opensim: OpenSimConfig = field(default_factory=OpenSimConfig)
    overwrite: bool = True
    write_visualizations: bool = True
    write_csv: bool = True
    write_parquet: bool = False
    write_trc: bool = True
    poseworld_stage_name: str = "poseworld"

    def output_root_path(self) -> Path:
        return Path(self.output_root)
