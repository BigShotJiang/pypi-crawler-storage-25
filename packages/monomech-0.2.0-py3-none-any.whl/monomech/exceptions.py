class MonoMechError(RuntimeError):
    """Base MonoMech error."""


class MissingDependencyError(MonoMechError):
    """Raised when an optional dependency is not available."""


class OpenSimUnavailableError(MissingDependencyError):
    """Raised when OpenSim-backed functionality is requested but unavailable."""
