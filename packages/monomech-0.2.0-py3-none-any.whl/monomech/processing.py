from __future__ import annotations

from typing import Iterable

import numpy as np
import pandas as pd

from ._constants import LANDMARK_NAMES
from .config import StagePostProcessConfig

try:  # pragma: no cover
    from scipy.signal import savgol_filter
except Exception:  # pragma: no cover
    savgol_filter = None


def _coordinate_columns(df: pd.DataFrame, suffixes: Iterable[str]) -> list[str]:
    cols: list[str] = []
    for name in LANDMARK_NAMES:
        for suffix in suffixes:
            col = f"{name}_{suffix}"
            if col in df.columns:
                cols.append(col)
    return cols


def _gap_fill_series(series: pd.Series, *, max_gap_frames: int, method: str, limit_area: str) -> tuple[pd.Series, int]:
    mask_before = series.isna()
    filled = series.interpolate(method=method, limit=max_gap_frames, limit_direction="both", limit_area=limit_area)
    filled_count = int((mask_before & filled.notna()).sum())
    return filled, filled_count


def _make_window(valid_points: int, window_length: int, polyorder: int) -> int:
    window_length = int(max(3, window_length))
    if window_length % 2 == 0:
        window_length += 1
    max_window = valid_points if valid_points % 2 == 1 else valid_points - 1
    if max_window < 3:
        return 0
    window_length = min(window_length, max_window)
    if window_length <= polyorder:
        window_length = polyorder + 1
        if window_length % 2 == 0:
            window_length += 1
    if window_length > max_window:
        return 0
    return window_length


def _smooth_series(series: pd.Series, cfg: StagePostProcessConfig) -> pd.Series:
    smooth_cfg = cfg.smoothing
    if not smooth_cfg.enabled:
        return series.copy()

    numeric = pd.to_numeric(series, errors="coerce")
    valid_count = int(numeric.notna().sum())
    if valid_count < 3:
        return numeric

    if smooth_cfg.method == "savitzky_golay" and savgol_filter is not None:
        work = numeric.interpolate(limit_direction="both")
        window = _make_window(valid_count, smooth_cfg.window_length, smooth_cfg.polyorder)
        if window >= 3:
            smoothed = savgol_filter(
                work.to_numpy(dtype=float),
                window_length=window,
                polyorder=min(smooth_cfg.polyorder, window - 1),
                mode="interp",
            )
            out = pd.Series(smoothed, index=series.index, dtype=float)
            out[numeric.isna()] = np.nan
            return out

    rolling_window = max(1, int(smooth_cfg.rolling_window))
    return numeric.rolling(rolling_window, center=True, min_periods=1).mean()


def process_pose_dataframe(
    df: pd.DataFrame,
    config: StagePostProcessConfig,
    *,
    coordinate_suffixes: Iterable[str] = ("x", "y", "z"),
    recompute_px_py: bool = False,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    if not config.enabled:
        return df.copy(), pd.DataFrame(
            [
                {
                    "stage_enabled": False,
                    "gap_fill_enabled": config.gap_fill.enabled,
                    "smoothing_enabled": config.smoothing.enabled,
                    "coordinates_processed": 0,
                    "values_gap_filled": 0,
                    "smoothing_method": config.smoothing.method,
                }
            ]
        )

    out = df.copy()
    processed_columns = _coordinate_columns(out, coordinate_suffixes)
    gap_filled_total = 0

    if config.gap_fill.enabled:
        for col in processed_columns:
            filled, filled_count = _gap_fill_series(
                pd.to_numeric(out[col], errors="coerce"),
                max_gap_frames=config.gap_fill.max_gap_frames,
                method=config.gap_fill.method,
                limit_area=config.gap_fill.limit_area,
            )
            out[col] = filled
            gap_filled_total += filled_count

    if config.smoothing.enabled:
        for col in processed_columns:
            out[col] = _smooth_series(pd.to_numeric(out[col], errors="coerce"), config)

    if recompute_px_py and {"width", "height"}.issubset(out.columns):
        width = pd.to_numeric(out["width"], errors="coerce")
        height = pd.to_numeric(out["height"], errors="coerce")
        for name in LANDMARK_NAMES:
            x_col = f"{name}_x"
            y_col = f"{name}_y"
            x_px_col = f"{name}_x_px"
            y_px_col = f"{name}_y_px"
            if x_col in out.columns and x_px_col in out.columns:
                out[x_px_col] = pd.to_numeric(out[x_col], errors="coerce") * width
            if y_col in out.columns and y_px_col in out.columns:
                out[y_px_col] = pd.to_numeric(out[y_col], errors="coerce") * height

    summary = pd.DataFrame(
        [
            {
                "stage_enabled": True,
                "gap_fill_enabled": config.gap_fill.enabled,
                "smoothing_enabled": config.smoothing.enabled,
                "gap_fill_method": config.gap_fill.method,
                "max_gap_frames": config.gap_fill.max_gap_frames,
                "smoothing_method": config.smoothing.method,
                "window_length": config.smoothing.window_length,
                "polyorder": config.smoothing.polyorder,
                "rolling_window": config.smoothing.rolling_window,
                "coordinates_processed": len(processed_columns),
                "values_gap_filled": int(gap_filled_total),
            }
        ]
    )
    return out, summary
