from __future__ import annotations

from pathlib import Path
from typing import Iterable

from ..utils import normalize_video_inputs


def normalize_inputs(video_paths: str | Path | Iterable[str | Path]) -> list[Path]:
    return normalize_video_inputs(video_paths)
