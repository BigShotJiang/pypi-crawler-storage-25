from .videos import normalize_inputs

__all__ = ["normalize_inputs"]
