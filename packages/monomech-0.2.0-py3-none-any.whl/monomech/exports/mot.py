from __future__ import annotations

from pathlib import Path

import pandas as pd


def write_storage_table(
    df: pd.DataFrame,
    path: str | Path,
    *,
    name: str | None = None,
    in_degrees: bool | None = None,
) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)

    header = []
    header.append(f"name {name or path.stem}")
    header.append(f"nRows={len(df)}")
    header.append(f"nColumns={len(df.columns)}")
    if in_degrees is not None:
        header.append(f"inDegrees={'yes' if in_degrees else 'no'}")
    header.append("endheader")
    body = df.to_csv(sep="\t", index=False, line_terminator="\n")
    path.write_text("\n".join(header) + "\n" + body, encoding="utf-8")
    return path
