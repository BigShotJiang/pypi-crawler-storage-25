from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

from .._constants import LANDMARK_NAMES


def _map_point(x: float, y: float, z: float) -> tuple[float, float, float]:
    # OpenSim-friendly default:
    # X = forward = z
    # Y = up      = -y
    # Z = right   = x
    return float(z), float(-y), float(x)


def dataframe_to_trc_text(
    df: pd.DataFrame,
    *,
    filename: str = "poseworld.trc",
    units: str = "m",
    lowercase_names: bool = True,
    ground_y: bool = True,
) -> str:
    marker_names = LANDMARK_NAMES if not lowercase_names else [name.lower() for name in LANDMARK_NAMES]
    times = pd.to_numeric(df["time"], errors="coerce").fillna(0.0).to_numpy()
    fps = float(pd.to_numeric(df.get("fps", pd.Series([30.0])), errors="coerce").dropna().iloc[0]) if "fps" in df.columns else 30.0

    y_min = 0.0
    if ground_y:
        ys = []
        for name in LANDMARK_NAMES:
            col = f"{name}_y"
            if col in df.columns:
                mapped = pd.to_numeric(df[col], errors="coerce").map(lambda v: -v if pd.notna(v) else np.nan)
                ys.append(mapped.min())
        finite = [float(v) for v in ys if pd.notna(v)]
        y_min = min(finite) if finite else 0.0

    scale = 1000.0 if units.lower() == "mm" else 1.0
    units_header = "mm" if units.lower() == "mm" else "m"

    lines = []
    lines.append(f"PathFileType\t4\t(X/Y/Z)\t{filename}")
    lines.append("DataRate\tCameraRate\tNumFrames\tNumMarkers\tUnits\tOrigDataRate\tOrigDataStartFrame\tOrigNumFrames")
    lines.append(f"{fps:.6f}\t{fps:.6f}\t{len(df)}\t{len(marker_names)}\t{units_header}\t{fps:.6f}\t1\t{len(df)}")

    header = ["Frame#", "Time"]
    for name in marker_names:
        header.extend([name, "", ""])
    lines.append("\t".join(header))

    axis_header = ["", ""]
    for i in range(1, len(marker_names) + 1):
        axis_header.extend([f"X{i}", f"Y{i}", f"Z{i}"])
    lines.append("\t".join(axis_header))

    for i, (_, row) in enumerate(df.iterrows(), start=1):
        fields = [str(i), f"{float(row.get('time', 0.0)):.6f}"]
        for name in LANDMARK_NAMES:
            x = row.get(f"{name}_x", np.nan)
            y = row.get(f"{name}_y", np.nan)
            z = row.get(f"{name}_z", np.nan)
            if not np.isfinite(x) or not np.isfinite(y) or not np.isfinite(z):
                fields.extend(["0.000000", "0.000000", "0.000000"])
                continue
            mx, my, mz = _map_point(float(x), float(y), float(z))
            my = my - y_min
            fields.extend([f"{mx*scale:.6f}", f"{my*scale:.6f}", f"{mz*scale:.6f}"])
        lines.append("\t".join(fields))

    return "\n".join(lines)


def write_trc(df: pd.DataFrame, path: str | Path, **kwargs) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    text = dataframe_to_trc_text(df, filename=path.name, **kwargs)
    path.write_text(text, encoding="utf-8")
    return path
