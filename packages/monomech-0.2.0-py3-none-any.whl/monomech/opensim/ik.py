from __future__ import annotations

from pathlib import Path

import pandas as pd

from ..exports.mot import write_storage_table
from .common import require_opensim
from .io import mot_to_dataframe


def run_inverse_kinematics(
    *,
    model_path: str | Path,
    marker_trc_path: str | Path,
    output_dir: str | Path,
    lowpass_cutoff_hz: float = 6.0,
) -> tuple[Path, pd.DataFrame]:
    osim = require_opensim()

    model_path = Path(model_path)
    marker_trc_path = Path(marker_trc_path)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    ik_path = output_dir / "ik.mot"
    setup_xml = output_dir / "Setup_IK.xml"

    trc_lines = marker_trc_path.read_text(encoding="utf-8", errors="ignore").splitlines()
    time_line = next((line for line in trc_lines if line.startswith("DataRate")), None)
    del time_line  # retained to make intent obvious

    ik_tool = osim.InverseKinematicsTool()
    ik_tool.setName("MonoMech_IK")
    ik_tool.set_model_file(str(model_path))
    ik_tool.setMarkerDataFileName(str(marker_trc_path))
    ik_tool.setOutputMotionFileName(str(ik_path))
    if hasattr(ik_tool, "set_results_directory"):
        ik_tool.set_results_directory(str(output_dir))
    elif hasattr(ik_tool, "setResultsDir"):
        ik_tool.setResultsDir(str(output_dir))
    if hasattr(ik_tool, "set_report_errors"):
        ik_tool.set_report_errors(True)
    if hasattr(ik_tool, "set_report_marker_locations"):
        ik_tool.set_report_marker_locations(False)
    if hasattr(ik_tool, "set_report_marker_errors"):
        ik_tool.set_report_marker_errors(True)
    if hasattr(ik_tool, "set_constraint_weight"):
        ik_tool.set_constraint_weight(10.0)
    if hasattr(ik_tool, "set_accuracy"):
        ik_tool.set_accuracy(1e-5)

    ik_tool.printToXML(str(setup_xml))
    ik_tool.run()

    ik_df = mot_to_dataframe(ik_path)
    ik_df.to_csv(output_dir / "ik.csv", index=False)
    return ik_path, ik_df
