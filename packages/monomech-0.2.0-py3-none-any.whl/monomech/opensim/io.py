from __future__ import annotations

import io
from pathlib import Path

import pandas as pd


def _read_lines(path: str | Path) -> list[str]:
    return Path(path).read_text(encoding="utf-8", errors="ignore").splitlines()


def _first_line_index_matching(lines: list[str], predicate) -> int | None:
    for idx, line in enumerate(lines):
        if predicate(line):
            return idx
    return None


def storage_is_in_degrees(path: str | Path) -> bool:
    lines = _read_lines(path)
    for line in lines[:30]:
        lower = line.strip().lower()
        if lower.startswith("indegrees="):
            return lower.split("=", 1)[1].strip() == "yes"
    return True


def mot_to_dataframe(path: str | Path) -> pd.DataFrame:
    lines = _read_lines(path)
    header_idx = _first_line_index_matching(lines, lambda line: bool(line.strip()) and line.strip().split()[0].lower() == "time")
    if header_idx is None:
        endheader_idx = _first_line_index_matching(lines, lambda line: line.strip().lower() == "endheader")
        if endheader_idx is None or endheader_idx + 1 >= len(lines):
            raise ValueError(f"Could not find MOT/STO table header in {path}")
        header_idx = endheader_idx + 1
    text = "\n".join(lines[header_idx:])
    return pd.read_csv(io.StringIO(text), sep=r"\s+|\t+", engine="python")


def trc_to_dataframe(path: str | Path) -> pd.DataFrame:
    lines = _read_lines(path)
    rows = [line.rstrip("\n").split("\t") for line in lines]
    if len(rows) < 6:
        raise ValueError(f"TRC too short: {path}")

    marker_row = rows[3]
    marker_names = [token.strip() for token in marker_row[2::3] if token.strip()]

    columns = ["Frame#", "Time"]
    for name in marker_names:
        columns.extend([f"{name}_X", f"{name}_Y", f"{name}_Z"])

    data_rows = rows[5:]
    normalized = []
    for row in data_rows:
        row = list(row)
        if len(row) < len(columns):
            row = row + [""] * (len(columns) - len(row))
        else:
            row = row[: len(columns)]
        normalized.append(row)

    df = pd.DataFrame(normalized, columns=columns)
    for col in df.columns:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    return df
