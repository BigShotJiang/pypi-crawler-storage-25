from __future__ import annotations

from pathlib import Path

from ..exceptions import OpenSimUnavailableError


def require_opensim():
    try:
        import opensim as osim  # type: ignore
    except Exception as exc:
        raise OpenSimUnavailableError(
            "OpenSim-backed functionality requires the opensim Python package. "
            "Install it in your environment, commonly via conda: `conda install -c opensim-org opensim`."
        ) from exc
    return osim
