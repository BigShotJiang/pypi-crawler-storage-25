from __future__ import annotations

from pathlib import Path

import pandas as pd

from .common import require_opensim
from .io import mot_to_dataframe
from .loads import build_external_loads, validate_external_forces


def run_inverse_dynamics(
    *,
    model_path: str | Path,
    ik_mot_path: str | Path,
    external_loads_xml_path: str | Path,
    output_dir: str | Path,
    lowpass_cutoff_hz: float = 6.0,
) -> tuple[Path, pd.DataFrame]:
    osim = require_opensim()

    model_path = Path(model_path)
    ik_mot_path = Path(ik_mot_path)
    external_loads_xml_path = Path(external_loads_xml_path)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    motion = mot_to_dataframe(ik_mot_path)
    if "time" not in motion.columns:
        raise ValueError(f"Expected a time column in {ik_mot_path}")

    id_path = output_dir / "id.sto"
    setup_xml = output_dir / "Setup_ID.xml"

    tool = osim.InverseDynamicsTool()
    tool.setName("MonoMech_ID")
    tool.setModelFileName(str(model_path))
    tool.setCoordinatesFileName(str(ik_mot_path))
    tool.setExternalLoadsFileName(str(external_loads_xml_path))
    tool.setLowpassCutoffFrequency(float(lowpass_cutoff_hz))
    tool.setStartTime(float(motion["time"].iloc[0]))
    tool.setEndTime(float(motion["time"].iloc[-1]))
    if hasattr(tool, "setResultsDir"):
        tool.setResultsDir(str(output_dir))
    tool.setOutputGenForceFileName(id_path.name)
    tool.printToXML(str(setup_xml))
    tool.run()

    id_df = mot_to_dataframe(id_path)
    id_df.to_csv(output_dir / "id.csv", index=False)
    return id_path, id_df


__all__ = ["build_external_loads", "run_inverse_dynamics", "validate_external_forces"]
