from __future__ import annotations

from pathlib import Path
from typing import Iterable

import pandas as pd

from ..forces import ExternalForce, resolve_line_of_action
from ..exports.mot import write_storage_table
from .common import require_opensim
from .io import mot_to_dataframe, storage_is_in_degrees


def _state_set_time_and_coords(osim, model, state, row: dict, coord_map: dict[str, object], in_degrees: bool) -> None:
    state.setTime(float(row["time"]))
    for name, coord in coord_map.items():
        if name not in row or pd.isna(row[name]):
            continue
        value = float(row[name])
        if in_degrees:
            value = float(value) * 3.141592653589793 / 180.0
        coord.setValue(state, value)


def _vec3(osim, xyz: tuple[float, float, float]):
    return osim.Vec3(float(xyz[0]), float(xyz[1]), float(xyz[2]))


def _model_context_factory(osim, model, state, in_degrees: bool):
    coord_set = model.getCoordinateSet()
    coord_map = {coord_set.get(i).getName(): coord_set.get(i) for i in range(coord_set.getSize())}

    def body_origin(body_name: str) -> tuple[float, float, float]:
        body = model.getBodySet().get(body_name)
        try:
            transform = body.getTransformInGround(state)
            p = transform.p()
            return float(p.get(0)), float(p.get(1)), float(p.get(2))
        except Exception:
            origin = body.findStationLocationInGround(state, _vec3(osim, (0.0, 0.0, 0.0)))
            return float(origin.get(0)), float(origin.get(1)), float(origin.get(2))

    def segment_com(body_name: str) -> tuple[float, float, float]:
        body = model.getBodySet().get(body_name)
        local_com = body.getMassCenter()
        world_com = body.findStationLocationInGround(state, local_com)
        return float(world_com.get(0)), float(world_com.get(1)), float(world_com.get(2))

    def local_point(body_name: str, xyz_local: tuple[float, float, float]) -> tuple[float, float, float]:
        body = model.getBodySet().get(body_name)
        world = body.findStationLocationInGround(state, _vec3(osim, xyz_local))
        return float(world.get(0)), float(world.get(1)), float(world.get(2))

    def factory(row: dict[str, float]):
        _state_set_time_and_coords(osim, model, state, row, coord_map, in_degrees)
        model.realizePosition(state)
        return {
            "body_origin": body_origin,
            "segment_com": segment_com,
            "local_point": local_point,
        }

    return factory


def validate_external_forces(model_path: str | Path, force_specs: Iterable[ExternalForce]) -> pd.DataFrame:
    model_path = Path(model_path)
    rows: list[dict[str, object]] = []
    try:
        osim = require_opensim()
        model = osim.Model(str(model_path))
        body_set = model.getBodySet()
        body_names = {body_set.get(i).getName() for i in range(body_set.getSize())}
    except Exception as exc:  # pragma: no cover
        body_names = set()
        rows.append({"name": "__validation__", "status": "warning", "message": f"OpenSim validation unavailable: {exc}"})

    seen: set[str] = set()
    for spec in force_specs:
        rows.append(
            {
                "name": spec.name,
                "applied_to_body": spec.applied_to_body,
                "unique_name": spec.name not in seen,
                "body_exists_in_model": spec.applied_to_body in body_names if body_names else None,
                "expressed_in": spec.expressed_in,
                "point_expressed_in": spec.point_expressed_in,
                "point_kind": spec.point_data if isinstance(spec.point_data, str) else type(spec.point_data).__name__,
            }
        )
        seen.add(spec.name)
    return pd.DataFrame(rows)


def build_external_loads(
    *,
    model_path: str | Path,
    ik_mot_path: str | Path,
    force_specs: Iterable[ExternalForce],
    output_dir: str | Path,
    poseworld_df: pd.DataFrame | None = None,
) -> tuple[Path, Path, pd.DataFrame, pd.DataFrame]:
    osim = require_opensim()

    model_path = Path(model_path)
    ik_mot_path = Path(ik_mot_path)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    model = osim.Model(str(model_path))
    state = model.initSystem()
    motion = mot_to_dataframe(ik_mot_path).copy()
    in_degrees = storage_is_in_degrees(ik_mot_path)

    model_context_for_row = _model_context_factory(osim, model, state, in_degrees)
    specs = list(force_specs)
    validation_df = validate_external_forces(model_path, specs)

    long_records: list[dict[str, object]] = []
    for _, motion_row in motion.iterrows():
        row_dict = motion_row.to_dict()
        model_context = model_context_for_row(row_dict)
        poseworld_row = None
        if poseworld_df is not None and not poseworld_df.empty:
            idx = poseworld_df["time"].sub(float(row_dict["time"])).abs().idxmin()
            poseworld_row = poseworld_df.loc[idx]
        for spec in specs:
            record = spec.evaluate_at(float(row_dict["time"]), poseworld_row=poseworld_row, model_context=model_context)
            if spec.metadata.get("kind") == "line_of_action" and poseworld_row is not None:
                fx, fy, fz = resolve_line_of_action(spec, poseworld_row)
                record["fx"], record["fy"], record["fz"] = fx, fy, fz
            long_records.append(record)

    force_df = pd.DataFrame(long_records)
    if force_df.empty:
        force_df = pd.DataFrame(columns=["time", "force_name", "fx", "fy", "fz", "px", "py", "pz", "mx", "my", "mz", "applied_to_body"])

    pivot_rows: list[dict[str, float]] = []
    for time_value, group in force_df.groupby("time", sort=True):
        row: dict[str, float] = {"time": float(time_value)}
        for _, item in group.iterrows():
            prefix = str(item["force_name"])
            row[f"{prefix}_fx"] = float(item["fx"])
            row[f"{prefix}_fy"] = float(item["fy"])
            row[f"{prefix}_fz"] = float(item["fz"])
            row[f"{prefix}_px"] = float(item["px"])
            row[f"{prefix}_py"] = float(item["py"])
            row[f"{prefix}_pz"] = float(item["pz"])
            row[f"{prefix}_tx"] = float(item["mx"])
            row[f"{prefix}_ty"] = float(item["my"])
            row[f"{prefix}_tz"] = float(item["mz"])
        pivot_rows.append(row)

    mot_df = pd.DataFrame(pivot_rows).sort_values("time") if pivot_rows else pd.DataFrame({"time": motion["time"]})
    force_mot_path = output_dir / "external_loads.mot"
    write_storage_table(mot_df, force_mot_path, name="external_loads", in_degrees=False)

    xml_path = output_dir / "ExternalLoads.xml"
    ext_loads = osim.ExternalLoads()
    ext_loads.setName("MonoMechExternalLoads")
    ext_loads.setDataFileName(str(force_mot_path))
    ground_name = model.getGround().getName()

    for spec in specs:
        exf = osim.ExternalForce()
        exf.setName(spec.name)
        exf.setAppliedToBodyName(spec.applied_to_body)
        exf.setForceExpressedInBodyName(spec.expressed_in if spec.expressed_in != "ground" else ground_name)
        exf.setPointExpressedInBodyName(spec.point_expressed_in if spec.point_expressed_in != "ground" else ground_name)
        exf.setForceIdentifier(f"{spec.name}_f")
        exf.setPointIdentifier(f"{spec.name}_p")
        exf.setTorqueIdentifier(f"{spec.name}_t")
        try:
            ext_loads.cloneAndAppend(exf)
        except Exception:  # pragma: no cover
            ext_loads.adoptAndAppend(exf)

    ext_loads.printToXML(str(xml_path))
    force_df.to_csv(output_dir / "external_forces.csv", index=False)
    validation_df.to_csv(output_dir / "external_forces_validation.csv", index=False)
    return force_mot_path, xml_path, force_df, validation_df
