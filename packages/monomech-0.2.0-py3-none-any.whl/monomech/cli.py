from __future__ import annotations

import argparse
from pathlib import Path

import yaml

from .config import PipelineConfig
from .forces import ExternalForce, ExternalForceSet, carried_mass
from .pipeline import MonoMechPipeline


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="MonoMech single-camera biomechanics pipeline")
    parser.add_argument("videos", nargs="+", help="Video path(s)")
    parser.add_argument("--output-root", default="monomech_outputs")
    parser.add_argument("--model-path", help="OpenSim model path (.osim)")
    parser.add_argument("--fbx-path", help="FBX path for notebook/HTML rig visualization")
    parser.add_argument("--stride", type=int, default=1)
    parser.add_argument("--backend", default="auto", choices=["auto", "tasks", "solutions"])
    parser.add_argument("--task-model-path", help="MediaPipe task model path for tasks backend")
    parser.add_argument("--external-force-yaml", help="YAML file with one or more external force definitions")
    parser.add_argument("--carried-mass-body", default=None)
    parser.add_argument("--carried-mass-kg", type=float, default=None)
    parser.add_argument("--disable-pose-smoothing", action="store_true")
    return parser


def _load_force_set(path: str | Path | None) -> ExternalForceSet:
    if not path:
        return ExternalForceSet([])
    data = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    if isinstance(data, dict) and "forces" in data:
        items = data["forces"]
    elif isinstance(data, list):
        items = data
    else:
        items = [data]
    return ExternalForceSet([ExternalForce.from_dict(item) for item in items])


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    config = PipelineConfig(output_root=args.output_root)
    config.pose.stride = args.stride
    config.pose.backend = args.backend
    config.pose.task_model_path = args.task_model_path
    if args.disable_pose_smoothing:
        config.postprocess.pose3d.smoothing.enabled = False
        config.postprocess.poseworld.smoothing.enabled = False

    force_set = _load_force_set(args.external_force_yaml)
    if args.carried_mass_body and args.carried_mass_kg is not None:
        force_set.add(carried_mass(body=args.carried_mass_body, mass_kg=args.carried_mass_kg))

    pipeline = MonoMechPipeline(config)
    if len(args.videos) == 1:
        trial = pipeline.run(
            args.videos[0],
            model_path=args.model_path,
            fbx_path=args.fbx_path,
            external_forces=force_set if force_set.forces else None,
        )
        print(trial.summary().to_string(index=False))
        print("Output:", trial.output_dir)
    else:
        batch = pipeline.run_many(
            args.videos,
            model_path=args.model_path,
            fbx_path=args.fbx_path,
            external_forces=force_set if force_set.forces else None,
        )
        print(batch.summary().to_string(index=False))
