from __future__ import annotations

import json
import math
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd


def ensure_dir(path: str | Path) -> Path:
    path = Path(path)
    path.mkdir(parents=True, exist_ok=True)
    return path


def safe_stem(path: str | Path) -> str:
    return Path(path).stem.replace(" ", "_")


def normalize_video_inputs(video_paths: str | Path | Iterable[str | Path]) -> list[Path]:
    if isinstance(video_paths, (str, Path)):
        return [Path(video_paths)]
    return [Path(p) for p in video_paths]


def dataframe_preview_html(df: pd.DataFrame, max_rows: int = 10) -> str:
    if df.empty:
        return "<em>Empty dataframe</em>"
    return df.head(max_rows).to_html(index=False, escape=False)


def series_to_triplets(row: pd.Series, names: list[str]) -> list[tuple[float | None, float | None, float | None]]:
    out = []
    for name in names:
        x = row.get(f"{name}_x")
        y = row.get(f"{name}_y")
        z = row.get(f"{name}_z")
        out.append((None if pd.isna(x) else float(x), None if pd.isna(y) else float(y), None if pd.isna(z) else float(z)))
    return out


def json_dumps_compact(data: object) -> str:
    return json.dumps(data, separators=(",", ":"), ensure_ascii=False)


def nanmin_safe(values: Iterable[float]) -> float:
    vals = [v for v in values if v is not None and math.isfinite(v)]
    return min(vals) if vals else 0.0


def rolling_mean(values: np.ndarray, window: int) -> np.ndarray:
    if window <= 1:
        return values.copy()
    series = pd.Series(values)
    return series.rolling(window, center=True, min_periods=1).mean().to_numpy()
