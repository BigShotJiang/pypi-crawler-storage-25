from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable

from .utils import normalize_video_inputs, safe_stem


@dataclass(slots=True)
class Trial:
    video_path: Path
    name: str
    output_dir: Path
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class TrialBatch:
    trials: list[Trial]



def load_trial(
    video_path: str | Path,
    *,
    output_root: str | Path = "monomech_outputs",
    name: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> Trial:
    video_path = Path(video_path)
    trial_name = name or safe_stem(video_path)
    output_dir = Path(output_root) / trial_name
    return Trial(video_path=video_path, name=trial_name, output_dir=output_dir, metadata=dict(metadata or {}))



def load_trials(video_paths: str | Path | Iterable[str | Path], *, output_root: str | Path = "monomech_outputs") -> TrialBatch:
    return TrialBatch([load_trial(path, output_root=output_root) for path in normalize_video_inputs(video_paths)])
