from __future__ import annotations

from dataclasses import asdict
from pathlib import Path
from typing import Iterable

import pandas as pd

from .config import PipelineConfig
from .exports.trc import write_trc
from .forces import ExternalForce, ExternalForceSet
from .pose.pose2d import run_pose_extraction
from .pose.poseworld import build_poseworld
from .processing import process_pose_dataframe
from .results import BatchResult, StageResult, TrialResult
from .trials import Trial, load_trial
from .utils import ensure_dir, normalize_video_inputs
from .visualization.loads import render_loads_html
from .visualization.pose import render_pose_analysis_html
from .visualization.rig import render_rig_motion_html


class MonoMechPipeline:
    def __init__(self, config: PipelineConfig | None = None):
        self.config = config or PipelineConfig()

    def load_trial(self, video_path: str | Path, *, name: str | None = None, metadata: dict | None = None) -> Trial:
        return load_trial(video_path, output_root=self.config.output_root, name=name, metadata=metadata)

    def _trial_from_input(self, video: str | Path | Trial) -> Trial:
        if isinstance(video, Trial):
            return video
        return self.load_trial(video)

    def _stage_dir(self, trial: Trial, stage_name: str) -> Path:
        return ensure_dir(Path(trial.output_dir) / stage_name)

    def _write_stage_csv(self, df: pd.DataFrame, stage_dir: Path, filename: str) -> Path:
        path = stage_dir / filename
        df.to_csv(path, index=False)
        return path

    def pose2d(self, trial: str | Path | Trial) -> StageResult:
        trial = self._trial_from_input(trial)
        stage_dir = self._stage_dir(trial, "pose2d")
        pose = run_pose_extraction(trial.video_path, self.config.pose)
        pose2d_df, summary_df = process_pose_dataframe(
            pose.pose2d,
            self.config.postprocess.pose2d,
            coordinate_suffixes=("x", "y", "z"),
            recompute_px_py=True,
        )
        csv_path = self._write_stage_csv(pose2d_df, stage_dir, "pose2d.csv")
        summary_path = self._write_stage_csv(summary_df, stage_dir, "pose2d_processing.csv")
        return StageResult(
            "pose2d",
            pose2d_df,
            artifacts={"csv": csv_path, "summary_csv": summary_path},
            metadata={**pose.metadata, "processing": summary_df.to_dict(orient="records")},
            wide_dataframe=pose.pose2d,
        )

    def pose3d(self, trial: str | Path | Trial, *, pose2d_result: StageResult | None = None) -> tuple[StageResult, StageResult]:
        trial = self._trial_from_input(trial)
        pose = run_pose_extraction(trial.video_path, self.config.pose)
        stage_dir = self._stage_dir(trial, "pose3d")
        pose3d_df, summary_df = process_pose_dataframe(pose.pose3d, self.config.postprocess.pose3d, coordinate_suffixes=("x", "y", "z"))
        conf_csv = self._write_stage_csv(pose.confidence, stage_dir, "pose_confidence.csv")
        pose3d_csv = self._write_stage_csv(pose3d_df, stage_dir, "pose3d_local.csv")
        summary_path = self._write_stage_csv(summary_df, stage_dir, "pose3d_processing.csv")
        pose3d_stage = StageResult(
            "pose3d",
            pose3d_df,
            artifacts={"csv": pose3d_csv, "summary_csv": summary_path},
            metadata={**pose.metadata, "processing": summary_df.to_dict(orient="records")},
            wide_dataframe=pose.pose3d,
        )
        confidence_stage = StageResult("pose_confidence", pose.confidence, artifacts={"csv": conf_csv}, metadata=pose.metadata)
        return pose3d_stage, confidence_stage

    def poseworld(
        self,
        trial: str | Path | Trial,
        *,
        pose2d_result: StageResult | None = None,
        pose3d_result: StageResult | None = None,
    ) -> tuple[StageResult, StageResult, StageResult | None]:
        trial = self._trial_from_input(trial)
        if pose2d_result is None or pose3d_result is None:
            pose = run_pose_extraction(trial.video_path, self.config.pose)
            pose2d_df, _ = process_pose_dataframe(pose.pose2d, self.config.postprocess.pose2d, coordinate_suffixes=("x", "y", "z"), recompute_px_py=True)
            pose3d_df, _ = process_pose_dataframe(pose.pose3d, self.config.postprocess.pose3d, coordinate_suffixes=("x", "y", "z"))
        else:
            pose2d_df = pose2d_result.dataframe
            pose3d_df = pose3d_result.dataframe
        world_df, camera_df = build_poseworld(pose2d_df, pose3d_df, self.config.poseworld)
        world_df, summary_df = process_pose_dataframe(world_df, self.config.postprocess.poseworld, coordinate_suffixes=("x", "y", "z"))
        stage_dir = self._stage_dir(trial, "poseworld")
        poseworld_csv = self._write_stage_csv(world_df, stage_dir, "poseworld.csv")
        camera_csv = self._write_stage_csv(camera_df, stage_dir, "camera.csv")
        summary_csv = self._write_stage_csv(summary_df, stage_dir, "poseworld_processing.csv")
        trc_stage = None
        trc_path = None
        if self.config.write_trc:
            trc_path = write_trc(world_df, stage_dir / "poseworld.trc")
            trc_stage = StageResult("trc", pd.DataFrame({"artifact": [str(trc_path)]}), artifacts={"trc": trc_path})
        pose_html = None
        if self.config.write_visualizations:
            pose_html = render_pose_analysis_html(world_df, stage_dir / "pose_analysis.html")
        poseworld_stage = StageResult(
            self.config.poseworld_stage_name,
            world_df,
            artifacts={
                "csv": poseworld_csv,
                "camera_csv": camera_csv,
                "summary_csv": summary_csv,
                **({"html": pose_html} if pose_html else {}),
                **({"trc": trc_path} if trc_path else {}),
            },
            metadata={"processing": summary_df.to_dict(orient="records")},
        )
        camera_stage = StageResult("camera", camera_df, artifacts={"csv": camera_csv})
        return poseworld_stage, camera_stage, trc_stage

    def inverse_kinematics(self, trial: str | Path | Trial, *, model_path: str | Path, poseworld_result: StageResult) -> StageResult:
        from .opensim.ik import run_inverse_kinematics

        trial = self._trial_from_input(trial)
        stage_dir = self._stage_dir(trial, "ik")
        trc_path = poseworld_result.artifacts.get("trc")
        if trc_path is None:
            trc_path = write_trc(poseworld_result.dataframe, stage_dir / "poseworld.trc")
        ik_path, ik_df = run_inverse_kinematics(
            model_path=model_path,
            marker_trc_path=trc_path,
            output_dir=stage_dir,
            lowpass_cutoff_hz=self.config.opensim.lowpass_cutoff_hz,
        )
        csv_path = stage_dir / "ik.csv"
        ik_df.to_csv(csv_path, index=False)
        return StageResult("inverse_kinematics", ik_df, artifacts={"mot": ik_path, "csv": csv_path})

    def external_loads(
        self,
        trial: str | Path | Trial,
        *,
        model_path: str | Path,
        ik_result: StageResult,
        external_forces: ExternalForceSet | Iterable[ExternalForce],
        poseworld_result: StageResult | None = None,
    ) -> tuple[StageResult, StageResult]:
        from .opensim.loads import build_external_loads

        trial = self._trial_from_input(trial)
        stage_dir = self._stage_dir(trial, "loads")
        force_set = external_forces if isinstance(external_forces, ExternalForceSet) else ExternalForceSet(list(external_forces))
        force_mot_path, ext_xml_path, force_df, validation_df = build_external_loads(
            model_path=model_path,
            ik_mot_path=ik_result.artifacts["mot"],
            force_specs=force_set.forces,
            output_dir=stage_dir,
            poseworld_df=None if poseworld_result is None else poseworld_result.dataframe,
        )
        html_path = None
        if self.config.write_visualizations:
            html_path = render_loads_html(force_df, stage_dir / "loads_viewer.html")
        loads_stage = StageResult(
            "external_loads",
            force_df,
            artifacts={"mot": force_mot_path, "xml": ext_xml_path, "csv": stage_dir / "external_forces.csv", **({"html": html_path} if html_path else {})},
        )
        validation_stage = StageResult("external_loads_validation", validation_df, artifacts={"csv": stage_dir / "external_forces_validation.csv"})
        return loads_stage, validation_stage

    def inverse_dynamics(self, trial: str | Path | Trial, *, model_path: str | Path, ik_result: StageResult, loads_result: StageResult) -> StageResult:
        from .opensim.id import run_inverse_dynamics

        trial = self._trial_from_input(trial)
        stage_dir = self._stage_dir(trial, "id")
        id_path, id_df = run_inverse_dynamics(
            model_path=model_path,
            ik_mot_path=ik_result.artifacts["mot"],
            external_loads_xml_path=loads_result.artifacts["xml"],
            output_dir=stage_dir,
            lowpass_cutoff_hz=self.config.opensim.lowpass_cutoff_hz,
        )
        csv_path = stage_dir / "id.csv"
        id_df.to_csv(csv_path, index=False)
        return StageResult("inverse_dynamics", id_df, artifacts={"sto": id_path, "csv": csv_path})

    def run(
        self,
        video_path: str | Path | Trial,
        *,
        model_path: str | Path | None = None,
        fbx_path: str | Path | None = None,
        external_forces: ExternalForceSet | Iterable[ExternalForce] | None = None,
    ) -> TrialResult:
        trial = self._trial_from_input(video_path)
        ensure_dir(trial.output_dir)
        result = TrialResult(video_path=trial.video_path, output_dir=Path(trial.output_dir), metadata={"config": asdict(self.config), **trial.metadata})

        pose2d_stage = self.pose2d(trial)
        result.add_stage(pose2d_stage)

        pose3d_stage, confidence_stage = self.pose3d(trial, pose2d_result=pose2d_stage)
        result.add_stage(pose3d_stage)
        result.add_stage(confidence_stage)

        poseworld_stage, camera_stage, trc_stage = self.poseworld(trial, pose2d_result=pose2d_stage, pose3d_result=pose3d_stage)
        result.add_stage(poseworld_stage)
        result.add_stage(camera_stage)
        if trc_stage is not None:
            result.add_stage(trc_stage)
        if "html" in poseworld_stage.artifacts:
            result.visualizations["pose_analysis"] = poseworld_stage.artifacts["html"]

        if model_path:
            ik_stage = self.inverse_kinematics(trial, model_path=model_path, poseworld_result=poseworld_stage)
            result.add_stage(ik_stage)

            if fbx_path and self.config.write_visualizations:
                rig_dir = self._stage_dir(trial, "ik")
                rig_html = render_rig_motion_html(
                    ik_stage.dataframe,
                    rig_dir / "rig_viewer.html",
                    fbx_path=fbx_path,
                    in_degrees=self.config.opensim.in_degrees,
                )
                ik_stage.artifacts["html"] = rig_html
                result.visualizations["rig_viewer"] = rig_html

            if external_forces:
                loads_stage, loads_validation_stage = self.external_loads(
                    trial,
                    model_path=model_path,
                    ik_result=ik_stage,
                    external_forces=external_forces,
                    poseworld_result=poseworld_stage,
                )
                result.add_stage(loads_stage)
                result.add_stage(loads_validation_stage)
                if "html" in loads_stage.artifacts:
                    result.visualizations["loads_viewer"] = loads_stage.artifacts["html"]
                if self.config.opensim.run_inverse_dynamics:
                    id_stage = self.inverse_dynamics(trial, model_path=model_path, ik_result=ik_stage, loads_result=loads_stage)
                    result.add_stage(id_stage)

        report_dir = self._stage_dir(trial, "report")
        summary_csv = report_dir / "summary.csv"
        result.summary().to_csv(summary_csv, index=False)
        return result

    def run_many(
        self,
        video_paths: str | Path | Iterable[str | Path],
        *,
        model_path: str | Path | None = None,
        fbx_path: str | Path | None = None,
        external_forces: ExternalForceSet | Iterable[ExternalForce] | None = None,
    ) -> BatchResult:
        trials = []
        for video_path in normalize_video_inputs(video_paths):
            trials.append(self.run(video_path, model_path=model_path, fbx_path=fbx_path, external_forces=external_forces))
        return BatchResult(trials=trials)


def run_pipeline(
    video_paths: str | Path | Iterable[str | Path],
    *,
    config: PipelineConfig | None = None,
    model_path: str | Path | None = None,
    fbx_path: str | Path | None = None,
    external_forces: ExternalForceSet | Iterable[ExternalForce] | None = None,
):
    pipeline = MonoMechPipeline(config=config)
    if isinstance(video_paths, (str, Path, Trial)):
        return pipeline.run(video_paths, model_path=model_path, fbx_path=fbx_path, external_forces=external_forces)
    return pipeline.run_many(video_paths, model_path=model_path, fbx_path=fbx_path, external_forces=external_forces)
