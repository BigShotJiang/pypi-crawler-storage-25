# HDEV 🚀 (Help Developer)

HDEV is a professional CLI tool designed to help developers instantly view their local development websites on mobile devices. No setup, no configuration—one command to rule them all.

Inspired by the "Help Developer" philosophy, HDEV ensures your mobile testing is seamless and fast.

## Features

- **Zero-Config SSH Tunnel**: Instantly exposes your local port to a public URL.
- **Universal Braille QR**: Highly compact QR rendering that fits in any terminal window.
- **Auto-Browser Open**: Automatically opens a high-res QR code in your browser (Fail-safe).
- **Smart Detection**: Detects Vite/Next.js and provides helpful environment-specific configuration tips.

## Installation

```bash
# Install via pip
pip install hdev-web

# Or install from source
git clone https://github.com/pankajdasbhaya005/HDEV
cd HDEV
pip install -e .
```

## Usage

```bash
hdev 3000
```

## How it works

HDEV creates a secure SSH tunnel via `localhost.run`, extracts the public URL, and renders it as a QR code using a custom Braille-based algorithm. It also automatically points your browser to a perfect QR code for a 100% reliable experience.

## License

MIT
