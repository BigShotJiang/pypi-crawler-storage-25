import subprocess
import re
import time

def get_tunnel_url(port, retries=3):
    """Starts the SSH tunnel via localhost.run and returns the URL with retries."""
    blacklist = ["admin.localhost.run", "twitter.com", "localhost.run/docs", "localhost:3000"]
    
    for attempt in range(retries):
        cmd = ["ssh", "-o", "StrictHostKeyChecking=no", "-R", f"80:localhost:{port}", "localhost.run"]
        process = subprocess.Popen(
            cmd, 
            stdout=subprocess.PIPE, 
            stderr=subprocess.STDOUT, 
            text=True, 
            bufsize=1, 
            universal_newlines=True
        )
        
        # Give it a few seconds to output the URL
        start_time = time.time()
        while time.time() - start_time < 15:
            line = process.stdout.readline()
            if not line:
                break
                
            if ".lhr.life" in line or "tunneled" in line:
                found_urls = re.findall(r"https?://[a-zA-Z0-9.-]+", line)
                for f_url in found_urls:
                    if any(b in f_url for b in blacklist):
                        continue
                    return f_url, process
        
        # If no URL found in 15 seconds, try again
        process.terminate()
        if attempt < retries - 1:
            time.sleep(2)
            
    return None, None
