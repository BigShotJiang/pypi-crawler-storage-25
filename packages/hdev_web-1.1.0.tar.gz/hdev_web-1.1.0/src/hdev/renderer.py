import qrcode

def render_braille(matrix):
    """Packs 2x4 pixels into a single Unicode Braille character."""
    output = ""
    for y in range(0, len(matrix), 4):
        line = "  "
        for x in range(0, len(matrix[0]), 2):
            def get_p(ix, iy):
                if 0 <= ix < len(matrix[0]) and 0 <= iy < len(matrix):
                    return matrix[iy][ix]
                return False

            byte = 0
            if get_p(x, y): byte |= 0x1
            if get_p(x, y+1): byte |= 0x2
            if get_p(x, y+2): byte |= 0x4
            if get_p(x+1, y): byte |= 0x8
            if get_p(x+1, y+1): byte |= 0x10
            if get_p(x+1, y+2): byte |= 0x20
            if get_p(x, y+3): byte |= 0x40
            if get_p(x+1, y+3): byte |= 0x80
            line += chr(0x2800 + byte)
        output += line + "\n"
    return output

def generate_qr_matrix(url):
    """Generates the QR code matrix for a given URL."""
    qr = qrcode.QRCode(version=1, border=1)
    qr.add_data(url)
    qr.make(fit=True)
    return qr.get_matrix()
