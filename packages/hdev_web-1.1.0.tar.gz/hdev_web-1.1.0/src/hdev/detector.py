import os
import json

def detect_project_type():
    """Detects the type of project by checking the root and common subfolders."""
    # List of places to look for package.json
    search_paths = [".", "frontend", "client", "web", "apps/web", "apps/frontend"]
    
    for path in search_paths:
        pkg_path = os.path.join(path, "package.json")
        if os.path.exists(pkg_path):
            try:
                with open(pkg_path, "r") as f:
                    data = json.load(f)
                    deps = {**data.get("dependencies", {}), **data.get("devDependencies", {})}
                    if "vite" in deps: return "Vite"
                    if "next" in deps: return "Next.js"
                    if "react-scripts" in deps: return "CRA (React)"
            except: continue
    
    if os.path.exists("requirements.txt") or os.path.exists("manage.py"):
        return "Python (Django/Flask)"
    return "Generic Web"

def get_framework_logo(project_type):
    """Returns an ASCII logo for common frameworks."""
    logos = {
        "Vite": r"""\033[93m  ⚡ Vite detected\033[0m""",
        "Next.js": r"""\033[97m  ▲ Next.js detected\033[0m""",
        "CRA (React)": r"""\033[96m  ⚛️ React (CRA) detected\033[0m"""
    }
    return logos.get(project_type, "")

def get_smart_tip(project_type):
    """Returns a helpful tip based on the project type."""
    if project_type == "Vite":
        return ("\033[93mTip for Vite:\033[0m Make sure to set \033[1mserver.allowedHosts: true\033[0m in your \033[4mvite.config.js\033[0m to avoid host errors.")
    if project_type == "Next.js":
        return ("\033[93mTip for Next.js:\033[0m Ensure your dev server is running. If using Server Actions, add \033[1m*.lhr.life\033[0m to \033[1mexperimental.serverActions.allowedOrigins\033[0m in \033[4mnext.config.js\033[0m.")
    return None
