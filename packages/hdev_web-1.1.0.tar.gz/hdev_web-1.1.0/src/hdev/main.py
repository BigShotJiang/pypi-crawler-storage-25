import sys
import time
import socket
import webbrowser
try:
    import pyperclip
except ImportError:
    pyperclip = None

from .tunnel import get_tunnel_url
from .renderer import generate_qr_matrix, render_braille
from .detector import detect_project_type, get_smart_tip, get_framework_logo

BANNER = r"""
\033[94m _   _  ____  _____ __     __
| | | ||  _ \| ____|\ \   / /
| |_| || | | |  _|   \ \ / / 
|  _  || |_| | |___   \ V /  
|_| |_||____/|_____|   \_/   \033[0m
\033[90m       Help Developer - v1.0.0\033[0m
"""

def is_port_open(port):
    """Check if the local port is actually listening."""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(1)
            return s.connect_ex(('localhost', int(port))) == 0
    except:
        return False

def main():
    print(BANNER)
    
    # 0. Interactive Port selection
    if len(sys.argv) < 2:
        try:
            port = input("\033[94m[HDEV]\033[0m Which port is your website running on? (e.g. 3000): ").strip()
            if not port:
                print("\033[91mError: Port is required.\033[0m")
                sys.exit(1)
        except KeyboardInterrupt:
            print("\nExiting...")
            sys.exit(0)
    else:
        port = sys.argv[1]
    
    # 1. Project Detection
    project = detect_project_type()
    logo = get_framework_logo(project)
    print(f"\033[94m[Info]\033[0m {project} project detected. {logo}")
    
    # 2. Port Validation
    if not is_port_open(port):
        print(f"\033[91m[Error] Port {port} is not active.\033[0m")
        print(f"\033[93mPahle apni website start karein (e.g., npm run dev).\033[0m")
        sys.exit(1)
    
    # 3. Start Tunnel
    print(f"\033[94m[HDEV]\033[0m Starting tunnel for port {port}...")
    url, tunnel_process = get_tunnel_url(port)
    
    if url:
        # MAGIC: Open browser automatically
        qr_api = f"https://api.qrserver.com/v1/create-qr-code/?size=300x300&data={url}"
        try:
            webbrowser.open(qr_api)
        except:
            pass
            
        print(f"\r\n🚀 \033[1mLIVE URL:\033[0m \033[4m{url}\033[0m")
        
        # Clipboard Support
        if pyperclip:
            try:
                pyperclip.copy(url)
                print("\033[90m(URL copied to clipboard!)\033[0m")
            except:
                pass
        
        # 4. Rendering
        matrix = generate_qr_matrix(url)
        print("\r") # Reset to start of line
        print(render_braille(matrix), end="") # Renderer already adds \r\n
        
        # 5. Smart Tip
        tip = get_smart_tip(project)
        if tip:
            print(f"\r\n{tip}")
            
        print(f"\r\n\033[90mScan above or check your browser. Press Ctrl+C to stop.\033[0m")
        
        try:
            while tunnel_process.poll() is None:
                time.sleep(1)
        except KeyboardInterrupt:
            print("\n\033[91mStopping HDEV...\033[0m")
            tunnel_process.terminate()
            tunnel_process.wait()
    else:
        print("\n\033[91mError: Could not capture the tunnel URL.\033[0m")
        if tunnel_process:
            tunnel_process.terminate()

if __name__ == "__main__":
    main()
