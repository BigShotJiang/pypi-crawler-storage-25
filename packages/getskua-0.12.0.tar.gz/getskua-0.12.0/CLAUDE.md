# Python Package CLAUDE.md

Instructions for the `skua` Python package (published to PyPI).

## IMPORTANT: Package Isolation

This package is **publicly published to PyPI** and must be **completely self-contained**:

❌ **NEVER:**
- Import from `backend/` or `apps/frontend/`
- Reference monorepo structure in code or README
- Include internal implementation details
- Expose secrets or internal APIs

✅ **ALWAYS:**
- Keep dependencies minimal (only `requests` for MVP)
- Write as if the code is already open source
- Make it work standalone (no monorepo dependencies)
- Keep README user-facing (for PyPI users)

## Client-Side Validation

**Fail Fast Principle:** Validate known errors on the client side BEFORE making HTTP requests to provide immediate feedback to users.

**Never Trust the Client:** The backend MUST validate everything. Client-side validation is for user experience only, not security.

### What to Validate Client-Side

✅ **DO validate:**
- File size limits (10MB) - fail before upload
- Invalid visibility values - catch typos immediately
- Anonymous user restrictions (e.g., "private" visibility requires verification)
- Obviously invalid inputs (empty strings, wrong types)

❌ **DON'T rely on client validation for:**
- Security (backend must re-validate everything)
- Business logic (may change, backend is source of truth)
- Complex rules (keep client simple, let backend handle nuance)

### Example Pattern

```python
# In client.py
def upload_record(data: Dict[str, Any]) -> str:
    """Upload a record to Skua API."""

    # Client-side validation: Fail fast for known errors
    visibility = data.get("visibility")
    if visibility == "private" and not is_verified():
        raise UploadError(
            "Private records require a verified account. "
            "Run 'skua.login()' to verify your email."
        )

    # Backend still validates - never trust the client!
    response = requests.post(f"{api_url}/records", ...)
```

## Publishing to PyPI

**Always use the `@pypi-publisher` agent** for publishing.

The agent handles:
- Pre-publish verification checklist
- Package isolation verification (no backend/frontend leaks)
- TestPyPI workflow before production
- Production publishing
- Post-publish verification

Quick verification command:
```bash
cd python-package
uv build
unzip -l dist/skua-*.whl
# Should contain ONLY skua/* module
```

## Package Structure

```
python-package/
├── pyproject.toml           # PEP 621 format
├── .python-version          # Pin to 3.12
├── README.md                # USER-FACING (for PyPI)
├── LICENSE                  # MIT or Apache 2.0
├── skua/
│   ├── __init__.py          # Export public API
│   ├── record.py            # Main record() function
│   ├── client.py            # HTTP client for API
│   ├── config.py            # Configuration management
│   ├── serializers.py       # Object serialization
│   └── exceptions.py        # Custom exceptions
└── tests/
    ├── conftest.py
    ├── test_record.py
    ├── test_serializers.py
    └── test_client.py
```

## Public API

Only export what users need in `__init__.py`:
```python
from skua.record import record
from skua.config import configure
from skua.exceptions import UploadError, SerializationError

__all__ = ['record', 'configure', 'UploadError', 'SerializationError']
```

## Python Code Style

```python
# Always include type hints
def serialize_dataframe(df: pd.DataFrame) -> dict[str, Any]:
    """Serialize a pandas DataFrame to JSON format.

    Args:
        df: The DataFrame to serialize

    Returns:
        Dict with 'data', 'format', and 'metadata' keys
    """
    pass

# Handle optional dependencies gracefully
try:
    import matplotlib.pyplot as plt
    HAS_MATPLOTLIB = True
except ImportError:
    HAS_MATPLOTLIB = False

def can_serialize_figure(obj: Any) -> bool:
    if not HAS_MATPLOTLIB:
        return False
    return isinstance(obj, plt.Figure)
```

## Serializers

Registry pattern - list of serializers checked in order:
```python
class DataFrameSerializer:
    @staticmethod
    def can_serialize(obj: Any) -> bool:
        """Check if this serializer can handle the object."""
        return isinstance(obj, pd.DataFrame)

    @staticmethod
    def serialize(obj: Any) -> dict[str, Any]:
        """Serialize the object to a dictionary."""
        return {
            "format": "json",
            "data": obj.to_json(orient="split"),
            "metadata": {
                "dtypes": obj.dtypes.astype(str).to_dict()
            }
        }

# Register all serializers
SERIALIZERS = [
    DataFrameSerializer,
    MatplotlibSerializer,
    PILImageSerializer,
    # ... order matters - most specific first
]
```

## Client Code

The HTTP client lives in `skua/client.py`. It reads the on-disk client token (`~/.skua/client` for anonymous installs, `~/.skua/token` after `skua.login()` activates a verified account), sends it as `X-Skua-Token` on every request, and surfaces `UploadError` for non-2xx responses with the server's error message extracted into the exception text.

```python
# Conceptual shape:
def upload_record(data: dict) -> dict:
    token = get_client_token()
    headers = {"X-Skua-Token": token}
    response = requests.post(f"{api_url}/records", json=data, headers=headers)
    if not response.ok:
        raise UploadError(_extract_error_detail(response))
    return response.json()
```

## Error Handling

Use custom exceptions:
```python
# skua/exceptions.py
class SkuaError(Exception):
    """Base exception for Skua errors."""
    pass

class UploadError(SkuaError):
    """Error uploading to server."""
    pass

class SerializationError(SkuaError):
    """Error serializing object."""
    pass

# In code:
if response.status_code == 413:
    raise UploadError("Record too large. Try reducing image resolution.")
```

## Configuration

Client-token management:
```python
# Store the per-machine client token in ~/.skua/client
# Format: "client_" + random alphanumeric (e.g., "client_abc123def456")
# Read once, cache in memory
# Generate a new token if the file is missing
# After skua.login() verifies an email, the token at ~/.skua/token takes
# precedence — same X-Skua-Token header, just a verified one.
```

## Testing

Tests must run without backend:
```python
# Use mocked HTTP responses
@pytest.fixture
def mock_api():
    with responses.RequestsMock() as rsps:
        rsps.add(
            responses.POST,
            "http://localhost:8000/api/records",
            json={"id": "test123", "url": "http://..."},
            status=200
        )
        yield rsps

def test_create_record(mock_api):
    client = SkuaClient("http://localhost:8000")
    record_id = client.create_record("Test", {...})
    assert record_id == "test123"
```

## README Guidelines

`python-package/README.md` is for **PyPI users**:
- Don't reference monorepo structure
- Focus on installation and quick start
- Show clear code examples
- Link to https://skua.dev/docs for full documentation
- Keep it concise and user-friendly

Example:
```markdown
# Skua

Share Jupyter notebook results via shareable web links.

## Installation

```bash
pip install getskua
```

## Quick Start

```python
import skua
import pandas as pd

# Create some data
df = pd.DataFrame({'A': [1, 2, 3], 'B': [4, 5, 6]})

# Record it
url = skua.record(df, title="My Data")
print(f"View at: {url}")
```

## Documentation

Visit [skua.dev/docs](https://skua.dev/docs) for full documentation.
```

## Common Tasks

### Adding a New Serializer

1. Create class in `skua/serializers.py`
2. Implement `can_serialize(obj)` and `serialize(obj)` static methods
3. Add to `SERIALIZERS` list (order matters - most specific first)
4. Write tests in `tests/test_serializers.py`
5. Update `README.md` with example if major feature
6. Test with optional dependencies (matplotlib, pandas, etc.)

### Versioning

**Bump the version in `pyproject.toml` as part of the PR that changes public surface**, not at release time. Any PR that adds/changes/removes something a user sees (new field in `result.metadata`, new function, changed signature, changed CLI behavior) must include the version bump in the same commit.

Why: staging installs `getskua` from PyPI for deps, then symlinks source. If the source version matches PyPI, it's ambiguous whether new behavior is live. Bumping in-PR makes `skua.__version__` the source of truth.

### Releasing a New Version

**Use the `@pypi-publisher` agent**. Version is already bumped (see above), so:

1. Update CHANGELOG if you have one
2. Invoke `@pypi-publisher` agent
3. Agent will verify, test, and publish

## Dependencies

Keep minimal:
- **Required:** `requests` only
- **Optional:** `matplotlib`, `pandas`, `pillow`

Handle optional dependencies:
```python
try:
    import pandas as pd
    HAS_PANDAS = True
except ImportError:
    HAS_PANDAS = False
```

## What Can Reference What

```
✅ ALLOWED:
backend/       → python-package/  (for testing, imports)
tests/integration/ → python-package/

❌ NOT ALLOWED:
python-package/ → backend/        (must be standalone)
python-package/ → frontend/       (must be standalone)
```
