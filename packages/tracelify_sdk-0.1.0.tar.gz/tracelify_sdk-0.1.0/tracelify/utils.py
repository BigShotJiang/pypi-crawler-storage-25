import platform
from datetime import datetime, timezone
from typing import Dict, Any

def get_runtime_context() -> Dict[str, Any]:
    """
    Get information about the system and runtime.
    
    Returns:
        A dictionary containing OS and Python runtime information.
    """
    return {
        "os": platform.system(),
        "runtime": "python",
        "python_version": platform.python_version()
    }

def get_timestamp() -> str:
    """
    Get current UTC timestamp in ISO 8601 format.
    
    Returns:
        ISO format timestamp (UTC).
    """
    return datetime.now(timezone.utc).isoformat()