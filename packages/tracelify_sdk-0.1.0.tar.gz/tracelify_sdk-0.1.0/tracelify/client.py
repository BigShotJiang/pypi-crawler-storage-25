import traceback
import logging
from typing import Any, Dict, Optional, List
from .config import Config
from .hub import set_client
from .scope import Scope
from .queue import event_queue
from .worker import start_worker
from .handlers import setup_global_handler
from .utils import get_runtime_context, get_timestamp
from .models import Event

logger = logging.getLogger(__name__)

class Client:
    """
    The main client for the Tracelify SDK.
    
    This class orchestrates exception capture, context management, and background event sending.
    
    Attributes:
        config (Config): Configuration for the SDK.
        scope (Scope): The current scope for user and tag context.
    """

    def __init__(self, dsn: str):
        """
        Initialize the Tracelify client.
        
        Args:
            dsn: DSN of the project.
        """
        try:
            self.config = Config(dsn)
            self.scope = Scope()

            # Global registration
            set_client(self)

            # Start background worker for asynchronous events
            start_worker(self.config)

            # Automatically capture unhandled exceptions
            setup_global_handler()
            
            logger.info("Tracelify SDK client initialized successfully.")
            
        except Exception as e:
            logger.error(f"Failed to initialize Tracelify SDK client: {e}")
            raise

    def capture_exception(self, error: Exception, stacktrace: Optional[str] = None):
        """
        Manually capture an exception and send it to Tracelify.
        
        Args:
            error: The exception to capture.
            stacktrace: Optional manual stacktrace string.
        """
        try:
            if stacktrace is None:
                tb = getattr(error, "__traceback__", None)
                if tb is not None:
                    stacktrace = "".join(traceback.format_exception(type(error), error, tb))
                else:
                    stacktrace = "".join(traceback.format_stack())

            if not stacktrace:
                stacktrace = "No stacktrace available"

            # Prepare the event data
            event_data = Event(
                project_id=self.config.project_id,
                timestamp=get_timestamp(),
                error={
                    "type": type(error).__name__,
                    "message": str(error),
                    "stacktrace": stacktrace
                },
                context=get_runtime_context(),
                **self.scope.get()
            )

            # Send the event to the background queue
            event_queue.put(event_data.to_dict())
            logger.debug(f"Exception captured and queued: {type(error).__name__}")
            
        except Exception as e:
            logger.error(f"Error while capturing exception: {e}")

    # -------- CONTEXT METHODS --------

    def set_user(self, user: Dict[str, Any]):
        """Set the user for the current scope."""
        self.scope.set_user(user)

    def set_tag(self, key: str, value: str):
        """Set a custom tag for context."""
        self.scope.set_tag(key, value)

    def add_breadcrumb(self, message: str, level: str = "info"):
        """Add a breadcrumb to the current scope."""
        self.scope.add_breadcrumb(message, level)