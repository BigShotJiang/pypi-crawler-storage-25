class TracelifyError(Exception):
    """Base exception for all Tracelify SDK errors."""
    pass

class ConfigError(TracelifyError):
    """Raised when there is a configuration error."""
    pass

class TransportError(TracelifyError):
    """Raised when there is an issue with the underlying HTTP transport."""
    pass

class APIError(TracelifyError):
    """Raised when the API returns an error response."""
    def __init__(self, message, status_code=None):
        super().__init__(message)
        self.status_code = status_code
