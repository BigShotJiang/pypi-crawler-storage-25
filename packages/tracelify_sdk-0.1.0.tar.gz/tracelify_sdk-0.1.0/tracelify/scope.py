from typing import Dict, Any, List, Optional
from .models.event import Breadcrumb

class Scope:
    """
    Manages the current context (user, tags, breadcrumbs) for events.
    """
    
    def __init__(self):
        """Initialize an empty scope."""
        self.user: Dict[str, Any] = {}
        self.tags: Dict[str, str] = {}
        self.breadcrumbs: List[Dict[str, Any]] = []

    def set_user(self, user: Dict[str, Any]) -> None:
        """Set user information for the current context."""
        self.user = user

    def set_tag(self, key: str, value: str) -> None:
        """Set a tag for the current context."""
        self.tags[key] = value

    def add_breadcrumb(self, message: str, level: str = "info") -> None:
        """Add a breadcrumb to the current context."""
        breadcrumb = Breadcrumb(message=message, level=level)
        self.breadcrumbs.append({
            "message": breadcrumb.message,
            "timestamp": breadcrumb.timestamp,
            "level": breadcrumb.level
        })
        
        # Keep only the last 100 breadcrumbs for memory safety
        if len(self.breadcrumbs) > 100:
            self.breadcrumbs.pop(0)

    def get(self) -> Dict[str, Any]:
        """
        Get the current scope as a dictionary.
        
        Returns:
            A dictionary containing user, tags, and breadcrumbs.
        """
        return {
            "user": self.user,
            "tags": self.tags,
            "breadcrumbs": self.breadcrumbs[-20:] # Only include last 20 in the final event
        }