import queue
from typing import Any

# Standard thread-safe queue for events
event_queue = queue.Queue(maxsize=1000)