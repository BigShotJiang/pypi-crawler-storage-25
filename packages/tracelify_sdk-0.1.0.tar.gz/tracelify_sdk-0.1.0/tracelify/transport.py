import requests
import logging
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from typing import Any, Dict
from .config import Config
from .exceptions import TransportError

logger = logging.getLogger(__name__)

# Use a session with retries for efficiency and resilience
_session = None

def get_session():
    """Get or create a requests session with retries."""
    global _session
    if _session is None:
        _session = requests.Session()
        
        # Configure retry logic: 3 retries, exponential backoff, handle status codes 429, 500, 502, 503, 504
        retries = Retry(
            total=3,
            backoff_factor=0.3,
            status_forcelist=[429, 500, 502, 503, 504],
            allowed_methods=["POST"]
        )
        _session.mount("http://", HTTPAdapter(max_retries=retries))
        _session.mount("https://", HTTPAdapter(max_retries=retries))
        
    return _session

def send_event(config: Config, data: Dict[str, Any]):
    """
    Send an event to the API using the provided configuration.
    
    Args:
        config: The SDK configuration.
        data: The event data to send.
        
    Raises:
        TransportError: If the event fails to send.
    """
    try:
        session = get_session()
        response = session.post(
            config.get_endpoint(),
            json=data,
            headers={
                "X-Tracelify-Key": config.public_key,
                "Content-Type": "application/json",
                "User-Agent": "tracelify-python-sdk/0.1.0"
            },
            timeout=5
        )
        
        # Raise an exception for 4xx or 5xx responses (not handled by Retry)
        response.raise_for_status()
        
        logger.debug(f"Event sent successfully: {response.status_code}")
        
    except requests.exceptions.RequestException as e:
        logger.error(f"Failed to send event to Tracelify: {e}")
        # We don't raise here to avoid crashing the user's application 
        # unless it was a configuration error. We just log the failure.
        pass
    except Exception as e:
        logger.error(f"Unexpected error in transport: {e}")
        pass