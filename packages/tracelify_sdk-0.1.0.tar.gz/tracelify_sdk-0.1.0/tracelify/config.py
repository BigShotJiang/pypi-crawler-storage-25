from urllib.parse import urlparse
from typing import Optional
from .exceptions import ConfigError


class Config:
    """
    Configuration for the Tracelify client.
    
    Attributes:
        dsn (str): The Data Source Name for the project.
        protocol (str): The protocol (http/https).
        host (str): The host of the server.
        port (int): The port of the server.
        public_key (str): The public key for authentication.
        project_id (str): The project ID to which events will be sent.
    """

    def __init__(self, dsn: str):
        """
        Initialize the config from a DSN string.
        
        Args:
            dsn: DSN of the project (e.g., http://key@host:port/1)
        
        Raises:
            ConfigError: If the DSN is invalid.
        """
        try:
            parsed = urlparse(dsn)
            self.dsn = dsn
            self.protocol = parsed.scheme or "https"
            self.host = parsed.hostname
            self.port = parsed.port or (443 if self.protocol == "https" else 80)
            self.public_key = parsed.username

            if not self.host:
                raise ConfigError("Invalid DSN: Missing host")
            if not self.public_key:
                raise ConfigError("Invalid DSN: Missing public key (username)")

            path_parts = parsed.path.strip("/").split("/")
            if not path_parts or not path_parts[0]:
                self.project_id = "1"
            else:
                self.project_id = path_parts[0]
                
        except Exception as e:
            if isinstance(e, ConfigError):
                raise
            raise ConfigError(f"Failed to parse DSN: {e}") from e

    def get_endpoint(self) -> str:
        """
        Get the endpoint URL for sending events.
        
        Returns:
            The complete URL for the events endpoint.
        """
        return f"{self.protocol}://{self.host}:{self.port}/api/{self.project_id}/events"