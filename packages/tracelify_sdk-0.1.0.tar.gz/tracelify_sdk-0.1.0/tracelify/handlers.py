import sys
import traceback
import logging
from typing import Optional, Any
from .hub import get_client

logger = logging.getLogger(__name__)

def setup_global_handler():
    """Register the SDK with sys.excepthook to automatically capture unhandled exceptions."""
    
    def handle_exception(exc_type, exc_value, exc_traceback):
        """Global exception handler callback."""
        # Don't capture KeyboardInterrupt or system exit
        if issubclass(exc_type, KeyboardInterrupt):
            sys.__excepthook__(exc_type, exc_value, exc_traceback)
            return

        client = get_client()
        if client:
            try:
                # Capture the exception
                client.capture_exception(exc_value)
            except Exception as e:
                logger.error(f"Error while capturing exception in global handler: {e}")
        
        # Still call the original excepthook to avoid hiding the error from the user
        sys.__excepthook__(exc_type, exc_value, exc_traceback)

    sys.excepthook = handle_exception