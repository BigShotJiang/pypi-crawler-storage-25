from dataclasses import dataclass, field
from typing import Dict, Any, List, Optional
from ..utils import get_timestamp

@dataclass
class User:
    id: Optional[str] = None
    email: Optional[str] = None
    username: Optional[str] = None
    ip_address: Optional[str] = None

@dataclass
class Breadcrumb:
    message: str
    timestamp: str = field(default_factory=get_timestamp)
    level: str = "info"
    category: Optional[str] = None

@dataclass
class Event:
    project_id: str
    timestamp: str
    error: Dict[str, Any]
    client: Dict[str, str] = field(default_factory=lambda: {"sdk": "tracelify-python"})
    user: Optional[Dict[str, Any]] = None
    tags: Dict[str, str] = field(default_factory=dict)
    breadcrumbs: List[Dict[str, Any]] = field(default_factory=list)
    context: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "project_id": self.project_id,
            "timestamp": self.timestamp,
            "error": self.error,
            "client": self.client,
            "user": self.user,
            "tags": self.tags,
            "breadcrumbs": self.breadcrumbs,
            "context": self.context,
        }
