from typing import Optional, Any

# Global reference to the current client
_current_client = None

def set_client(client: Any) -> None:
    """Set the globally available client."""
    global _current_client
    _current_client = client

def get_client() -> Optional[Any]:
    """Get the currently active client."""
    return _current_client