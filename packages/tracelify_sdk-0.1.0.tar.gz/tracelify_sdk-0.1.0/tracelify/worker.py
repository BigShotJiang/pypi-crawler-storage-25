import threading
import logging
from .queue import event_queue
from .transport import send_event
from .config import Config

logger = logging.getLogger(__name__)

def start_worker(config: Config) -> None:
    """
    Start a background thread to send events from the queue to the API.
    
    Args:
        config: SDK configuration for the transport.
    """

    def worker():
        """Background worker loop."""
        while True:
            try:
                # Wait for an event to be added to the queue
                event = event_queue.get()
                if event is None: # Shutdown signal
                    break
                    
                # Send the event via transport
                send_event(config, event)
                
            except Exception as e:
                logger.error(f"Error in background worker: {e}")
            finally:
                # Always mark the task as done
                event_queue.task_done()

    # Create a daemon thread so it doesn't block process exit
    thread = threading.Thread(target=worker, daemon=True, name="tracelify-worker")
    thread.start()
    logger.debug("Background worker thread started.")