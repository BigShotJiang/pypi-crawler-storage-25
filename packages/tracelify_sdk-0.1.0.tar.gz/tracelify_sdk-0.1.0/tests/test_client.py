import pytest
from tracelify import Client, Config, ConfigError

def test_config_parsing_valid():
    """Test valid DSN parsing."""
    dsn = "http://public_key@localhost:8000/1"
    config = Config(dsn)
    
    assert config.protocol == "http"
    assert config.public_key == "public_key"
    assert config.host == "localhost"
    assert config.port == 8000
    assert config.project_id == "1"
    assert config.get_endpoint() == "http://localhost:8000/api/1/events"

def test_config_parsing_invalid():
    """Test invalid DSN parsing raises ConfigError."""
    # Missing public key
    with pytest.raises(ConfigError):
        Config("http://localhost:8000/1")
        
    # Missing host
    with pytest.raises(ConfigError):
        Config("http://key@/1")

def test_client_init_success(monkeypatch):
    """Test successful client initialization."""
    # Mocking background worker start 
    monkeypatch.setattr("tracelify.client.start_worker", lambda config: None)
    
    dsn = "http://key@localhost:8000/1"
    client = Client(dsn)
    
    assert client.config.host == "localhost"
    assert client.scope is not None

def test_scope_context():
    """Test that scope correctly accumulates context."""
    from tracelify.scope import Scope
    scope = Scope()
    
    scope.set_user({"id": "1"})
    scope.set_tag("env", "prod")
    scope.add_breadcrumb("test message")
    
    context = scope.get()
    assert context["user"] == {"id": "1"}
    assert context["tags"] == {"env": "prod"}
    assert len(context["breadcrumbs"]) == 1
    assert context["breadcrumbs"][0]["message"] == "test message"

def test_event_model():
    """Test that the event model dictionary conversion is correct."""
    from tracelify.models import Event
    from tracelify.utils import get_timestamp
    
    ts = get_timestamp()
    event = Event(
        project_id="123",
        timestamp=ts,
        error={"type": "ValueError", "message": "error msg", "stacktrace": "..."}
    )
    
    d = event.to_dict()
    assert d["project_id"] == "123"
    assert d["timestamp"] == ts
    assert d["error"]["type"] == "ValueError"
    assert d["client"]["sdk"] == "tracelify-python"
