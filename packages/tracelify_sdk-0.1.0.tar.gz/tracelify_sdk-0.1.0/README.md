# Tracelify Python SDK

[![PyPI version](https://img.shields.io/pypi/v/tracelify-sdk.svg)](https://pypi.org/project/tracelify-sdk/)
[![Python versions](https://img.shields.io/pypi/pyversions/tracelify-sdk.svg)](https://pypi.org/project/tracelify-sdk/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

Official Python SDK for Tracelify - Effortless Error Tracking and Performance Monitoring for your Python applications.

---

## ⚡ Quick Start

### 1. Install

```bash
pip install tracelify-sdk
```

### 2. Initialize

Initialize the client with your DSN early in your application's entry point:

```python
from tracelify import Client

# Initialize the client (automatically captures unhandled exceptions)
client = Client("https://your-key@tracelify.io/project-id")
```

### 3. Capture Exceptions Manually

```python
try:
    1 / 0
except Exception as e:
    client.capture_exception(e)
```

### 4. Enrich context

```python
# Set user context
client.set_user({"id": "123", "email": "user@example.com"})

# Set custom tags
client.set_tag("environment", "production")

# Add breadcrumbs for debugging
client.add_breadcrumb("User clicked 'Submit' button")
```

---

## 🛠️ Components

- **Client**: Main interface to the SDK.
- **Config**: Configuration and DSN parsing.
- **Scope**: Manages user context, tags, and breadcrumbs.
- **Transport**: Sends events asynchronously to the Tracelify server with automatic retries and exponential backoff.
- **Handlers**: Automatic global exception capture for unhandled errors.

---

## ⚙️ Configuration

The Tracelify SDK is designed to work with minimal configuration. Simply provide a valid DSN:

| DSN Part | Description |
| --- | --- |
| `protocol` | http or https |
| `key` | Your public authentication key |
| `host` | Tracelify server hostname |
| `port` | Server port (optional) |
| `project_id`| Your project ID |

Example DSN: `https://abcd1234@api.tracelify.io:8080/1`

---

## 🤝 Contributing

We welcome contributions! Please check out our [CONTRIBUTING.md](CONTRIBUTING.md) and [CHANGELOG.md](CHANGELOG.md).

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.
