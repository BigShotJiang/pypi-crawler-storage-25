# mylib/mainstuff.py
import sounddevice as sd
import soundfile as sf


def record(duration, samplerate=44100, channels=1, device=None, output_file=None):
    audio = sd.rec(
        int(duration * samplerate),
        samplerate=samplerate,
        channels=channels,
        dtype='float32',
        device=device
    )

    sd.wait()

    if output_file:
        sf.write(output_file, audio, samplerate)

    return audio

def get_mic_list():
    return [
        d['name']
        for d in sd.query_devices()
        if d.get('max_input_channels', 0) > 0
    ]


def get_mic_info(name):
    for d in sd.query_devices():
        if d['name'] == name and d.get('max_input_channels', 0) > 0:
            return d
    return None


def get_default_mic():
    default = sd.default.device

    if not default:
        return None

    # handle InputOutputPair or tuple/list
    try:
        index = default.input
    except AttributeError:
        try:
            index = default[0]
        except Exception:
            return None

    if index is None:
        return None

    try:
        index = int(index)
    except Exception:
        return None

    if index < 0:
        return None

    try:
        return sd.query_devices(index)
    except Exception:
        return None


def get_default_mic_name():
    mic = get_default_mic()
    return mic['name'] if mic else None


def get_default_mic_settings():
    mic = get_default_mic()
    if not mic:
        return None

    return {
        "samplerate": mic.get('default_samplerate'),
        "channels": mic.get('max_input_channels', 0)
    }