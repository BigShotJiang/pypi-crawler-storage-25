import asyncio
from cvc.agent.settings import load_settings

async def main():
    settings = load_settings()
    print(settings.telegram)

asyncio.run(main())
