"""
cvc.core.user_model — Versioned User Identity Model (VUIM).

Implements Honcho-style formal logical reasoning (deductive, inductive,
abductive) over user data, but every update is a CVC commit on a dedicated
``user-model`` branch.

Key innovation: Unlike Honcho where the identity model is mutable,
CVC *versions* every identity update. You can:
  - ``cvc diff user-model~5 user-model`` to see how understanding evolved
  - Revert a bad user model update
  - Audit the full chain of reasoning that built the model

The model stores:
  - Deductive conclusions (certain, from explicit statements)
  - Inductive conclusions (probable patterns from repeated observations)
  - Abductive conclusions (best explanations for observed behavior)
  - Preferences, communication style, expertise areas
"""

from __future__ import annotations

import json
import logging
import time
import uuid
from pathlib import Path

from pydantic import BaseModel, Field

logger = logging.getLogger("cvc.user_model")


# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------


class Conclusion(BaseModel):
    """A single reasoned conclusion about the user."""

    conclusion_id: str = Field(default_factory=lambda: uuid.uuid4().hex[:12])
    reasoning_type: str  # "deductive" | "inductive" | "abductive"
    statement: str
    premises: list[str] = Field(default_factory=list)
    confidence: float = 0.0  # 0.0–1.0
    evidence_commits: list[str] = Field(default_factory=list)  # Source commit hashes
    created_at: float = Field(default_factory=time.time)
    supersedes: str | None = None  # ID of conclusion this replaces (contradiction handling)


class UserIdentitySnapshot(BaseModel):
    """
    A point-in-time snapshot of the agent's understanding of the user.

    Each snapshot is committed to the ``user-model`` branch, creating
    an immutable, auditable history of identity reasoning.
    """

    snapshot_id: str = Field(default_factory=lambda: uuid.uuid4().hex[:16])
    timestamp: float = Field(default_factory=time.time)

    # Structured identity dimensions
    name: str = ""
    expertise_areas: list[str] = Field(default_factory=list)
    communication_style: str = ""  # "concise" | "detailed" | "casual" | "formal" ...
    preferred_languages: list[str] = Field(default_factory=list)  # Programming languages
    preferred_tools: list[str] = Field(default_factory=list)
    coding_conventions: list[str] = Field(default_factory=list)
    workflow_preferences: list[str] = Field(default_factory=list)

    # Formal reasoning tree
    conclusions: list[Conclusion] = Field(default_factory=list)

    # Aggregate confidence per dimension
    confidence_scores: dict[str, float] = Field(default_factory=dict)

    # Summary for system prompt injection
    narrative_summary: str = ""

    def get_conclusions_by_type(self, reasoning_type: str) -> list[Conclusion]:
        """Filter conclusions by reasoning type."""
        return [c for c in self.conclusions if c.reasoning_type == reasoning_type]

    def active_conclusions(self) -> list[Conclusion]:
        """Return conclusions that haven't been superseded."""
        superseded_ids = {c.supersedes for c in self.conclusions if c.supersedes}
        return [c for c in self.conclusions if c.conclusion_id not in superseded_ids]


# ---------------------------------------------------------------------------
# Prompt templates
# ---------------------------------------------------------------------------

REASONING_PROMPT = """\
You are a user identity reasoning engine. Analyze the conversation to build a \
formal model of the user using three types of logical reasoning.

## Current User Model
{current_model_json}

## New Conversation Data (from recent commits)
{conversation_data}

## Instructions
Perform formal reasoning about the user's identity:

1. **Deductive** (certain): Conclusions directly stated by the user.
   Example: User said "I prefer Python" → deductive: user prefers Python.

2. **Inductive** (probable): Patterns from repeated observations.
   Example: User always asks for type hints → inductive: user values type safety.

3. **Abductive** (best explanation): Infer WHY the user behaves a certain way.
   Example: User often asks about performance → abductive: user works on \
   performance-critical systems.

Also check for **contradictions**: if new evidence contradicts an existing \
conclusion, mark the old conclusion as superseded with the ID of the new one.

Respond with ONLY valid JSON:
{{
  "new_conclusions": [
    {{
      "reasoning_type": "deductive|inductive|abductive",
      "statement": "...",
      "premises": ["evidence 1", "evidence 2"],
      "confidence": 0.0,
      "supersedes": null
    }}
  ],
  "updated_fields": {{
    "name": "",
    "expertise_areas": [],
    "communication_style": "",
    "preferred_languages": [],
    "preferred_tools": [],
    "coding_conventions": [],
    "workflow_preferences": []
  }},
  "narrative_summary": "One paragraph describing who this user is and how to best serve them."
}}

Only include fields in updated_fields that have new information. Use null for unchanged fields.
"""


class UserModelManager:
    """
    Manages the versioned user identity model.

    Works with the CVC engine to store identity snapshots as commits
    on the ``user-model`` branch. Each update creates a new commit
    with the full reasoning trace, enabling diff and revert.
    """

    USER_MODEL_BRANCH = "user-model"
    USER_MODEL_FILE = "user_model.json"

    def __init__(self, cvc_root: Path) -> None:
        self.cvc_root = cvc_root
        self._model_path = cvc_root / self.USER_MODEL_FILE

    def load_current_model(self) -> UserIdentitySnapshot:
        """Load the current user model from disk, or return empty."""
        if self._model_path.exists():
            try:
                data = json.loads(self._model_path.read_text(encoding="utf-8"))
                return UserIdentitySnapshot.model_validate(data)
            except Exception as e:
                logger.warning("Failed to load user model: %s", e)
        return UserIdentitySnapshot()

    def save_model(self, model: UserIdentitySnapshot) -> Path:
        """Persist the user model to disk."""
        self._model_path.write_text(
            model.model_dump_json(indent=2),
            encoding="utf-8",
        )
        logger.info("Saved user model snapshot %s", model.snapshot_id)
        return self._model_path

    def build_reasoning_prompt(
        self,
        current_model: UserIdentitySnapshot,
        conversation_messages: list[dict[str, str]],
    ) -> str:
        """Build the LLM prompt for user identity reasoning."""
        # Serialize current model (only active conclusions)
        model_data = {
            "name": current_model.name,
            "expertise_areas": current_model.expertise_areas,
            "communication_style": current_model.communication_style,
            "preferred_languages": current_model.preferred_languages,
            "preferred_tools": current_model.preferred_tools,
            "coding_conventions": current_model.coding_conventions,
            "workflow_preferences": current_model.workflow_preferences,
            "active_conclusions": [
                {
                    "id": c.conclusion_id,
                    "type": c.reasoning_type,
                    "statement": c.statement,
                    "confidence": c.confidence,
                }
                for c in current_model.active_conclusions()
            ],
        }

        # Format conversation data
        conv_text = ""
        for msg in conversation_messages[-30:]:  # Last 30 messages
            role = msg.get("role", "unknown")
            content = msg.get("content", "")[:300]
            conv_text += f"[{role}]: {content}\n\n"

        return REASONING_PROMPT.format(
            current_model_json=json.dumps(model_data, indent=2),
            conversation_data=conv_text[:4000],
        )

    def apply_reasoning_response(
        self,
        current_model: UserIdentitySnapshot,
        response_text: str,
        source_commits: list[str] | None = None,
    ) -> UserIdentitySnapshot:
        """
        Apply LLM reasoning response to update the user model.

        Returns a NEW snapshot (the old one is preserved in the DAG).
        """
        text = response_text.strip()
        if text.startswith("```"):
            lines = text.split("\n")
            text = "\n".join(lines[1:])
            if text.endswith("```"):
                text = text[:-3]
            text = text.strip()

        try:
            data = json.loads(text)
        except json.JSONDecodeError:
            logger.warning("Failed to parse user model reasoning response")
            return current_model

        # Create new snapshot based on current
        new_model = current_model.model_copy(deep=True)
        new_model.snapshot_id = uuid.uuid4().hex[:16]
        new_model.timestamp = time.time()

        # Add new conclusions
        for conc_data in data.get("new_conclusions", []):
            conclusion = Conclusion(
                reasoning_type=conc_data.get("reasoning_type", "inductive"),
                statement=conc_data.get("statement", ""),
                premises=conc_data.get("premises", []),
                confidence=float(conc_data.get("confidence", 0.5)),
                evidence_commits=source_commits or [],
                supersedes=conc_data.get("supersedes"),
            )
            if conclusion.statement:
                new_model.conclusions.append(conclusion)

        # Update fields (only non-null values)
        updated = data.get("updated_fields", {})
        if updated.get("name"):
            new_model.name = updated["name"]
        if updated.get("expertise_areas"):
            # Merge, don't replace
            existing = set(new_model.expertise_areas)
            existing.update(updated["expertise_areas"])
            new_model.expertise_areas = sorted(existing)
        if updated.get("communication_style"):
            new_model.communication_style = updated["communication_style"]
        if updated.get("preferred_languages"):
            existing = set(new_model.preferred_languages)
            existing.update(updated["preferred_languages"])
            new_model.preferred_languages = sorted(existing)
        if updated.get("preferred_tools"):
            existing = set(new_model.preferred_tools)
            existing.update(updated["preferred_tools"])
            new_model.preferred_tools = sorted(existing)
        if updated.get("coding_conventions"):
            existing = set(new_model.coding_conventions)
            existing.update(updated["coding_conventions"])
            new_model.coding_conventions = sorted(existing)
        if updated.get("workflow_preferences"):
            existing = set(new_model.workflow_preferences)
            existing.update(updated["workflow_preferences"])
            new_model.workflow_preferences = sorted(existing)

        # Update narrative
        if data.get("narrative_summary"):
            new_model.narrative_summary = data["narrative_summary"]

        # Update confidence scores
        for conc in new_model.active_conclusions():
            dim = conc.reasoning_type
            scores = new_model.confidence_scores.get(dim, [])
            if not isinstance(scores, list):
                scores = [scores]
            new_model.confidence_scores[dim] = conc.confidence

        return new_model

    def get_system_prompt_injection(self, model: UserIdentitySnapshot | None = None) -> str:
        """
        Generate a system prompt section from the user model.

        This is injected into the agent's system prompt so it can
        personalize responses based on learned user identity.
        """
        if model is None:
            model = self.load_current_model()

        if not model.narrative_summary and not model.expertise_areas:
            return ""

        parts = ["## User Profile (auto-learned)\n"]

        if model.name:
            parts.append(f"- **Name**: {model.name}")
        if model.expertise_areas:
            parts.append(f"- **Expertise**: {', '.join(model.expertise_areas)}")
        if model.communication_style:
            parts.append(f"- **Communication style**: {model.communication_style}")
        if model.preferred_languages:
            parts.append(f"- **Languages**: {', '.join(model.preferred_languages)}")
        if model.preferred_tools:
            parts.append(f"- **Tools**: {', '.join(model.preferred_tools)}")
        if model.coding_conventions:
            parts.append(f"- **Conventions**: {', '.join(model.coding_conventions[:5])}")

        if model.narrative_summary:
            parts.append(f"\n{model.narrative_summary}")

        # Include high-confidence active conclusions
        high_confidence = [c for c in model.active_conclusions() if c.confidence >= 0.7]
        if high_confidence:
            parts.append("\n### Key Insights")
            for c in high_confidence[:10]:
                parts.append(f"- [{c.reasoning_type}] {c.statement} (conf: {c.confidence:.0%})")

        return "\n".join(parts)
