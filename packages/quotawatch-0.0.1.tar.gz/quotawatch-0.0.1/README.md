# quotawatch

Python SDK for [QuotaWatch](https://quotawatch.app) — passive API usage monitoring.

**Never get surprised by a rate limit again.**

## Installation

```bash
pip install quotawatch
```

## Quick start

```python
from quotawatch import QuotaWatch
from quotawatch.types import QuotaWatchConfig, ApiConfig, ApiLimits

QuotaWatch.init(QuotaWatchConfig(
    api_key="qw_live_your_key_here",
    ingest_url="https://ingest.quotawatch.app",  # or http://localhost:3001 for local dev
    environment="production",
    apis=[
        ApiConfig(
            name="OpenAI",
            base_url="https://api.openai.com",
            limits=ApiLimits(
                requests_per_minute=60,
                requests_per_day=10_000,
                tokens_per_day=1_000_000,
            ),
        ),
    ],
))

# That's it. Your existing requests/httpx calls are now monitored automatically.
# No record() calls needed — the SDK patches the HTTP clients on init().
import requests
response = requests.get("https://api.openai.com/v1/models", headers={...})
```

## How it works

On `init()`, the SDK monkey-patches `requests.Session.send` and `httpx.Client.send` (both sync and async). Every outgoing HTTP call matching a configured `base_url` is recorded asynchronously — **fire-and-forget**. A background daemon thread flushes buffered events to the ingest API every 5 seconds.

**You never call `record()` manually** — the interceptors handle everything.

## Supported HTTP clients

| Client | Supported |
|---|---|
| `requests` | ✅ Auto-patched on init |
| `httpx` (sync) | ✅ Auto-patched on init |
| `httpx` (async) | ✅ Auto-patched on init |
| `aiohttp` | 🔜 v1.1 |
| `urllib` | ❌ Not supported |

## Requirements

- Python 3.9+
- Optional: `requests`, `httpx` (patches whichever is installed)

## Documentation

Full docs at [quotawatch.app/docs/python](https://quotawatch.app/docs/python)

## License

MIT
