from __future__ import annotations

import time
from datetime import datetime, timezone
from typing import Any, Callable


_RATELIMIT_PREFIXES = ("x-ratelimit-", "ratelimit-", "x-rate-limit-", "anthropic-ratelimit-")


def _extract_rate_limit_headers(headers: Any) -> dict[str, str]:
    return {
        k.lower(): v
        for k, v in headers.items()
        if k.lower().startswith(_RATELIMIT_PREFIXES)
    }


def _now_z() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"


def install_httpx_hook(
    base_url_map: dict[str, str],
    environment: str,
    record: Callable[[dict[str, Any]], None],
) -> None:
    try:
        import httpx

        if getattr(httpx.Client.send, "__quotawatch__", False):
            return

        original_send = httpx.Client.send

        def patched_send(client_self: Any, request: Any, **kwargs: Any) -> Any:
            url_str = str(request.url)
            api_name = None
            for base_url, name in base_url_map.items():
                if url_str.startswith(base_url):
                    api_name = name
                    break

            start = time.monotonic()
            response = original_send(client_self, request, **kwargs)

            if api_name is not None:
                latency_ms = int((time.monotonic() - start) * 1000)
                endpoint = request.url.path or "/"
                record({
                    "api": api_name,
                    "endpoint": endpoint,
                    "method": request.method.upper(),
                    "status": response.status_code,
                    "latencyMs": latency_ms,
                    "timestamp": _now_z(),
                    "environment": environment,
                    "hit429": response.status_code == 429,
                    "rateLimitHeaders": _extract_rate_limit_headers(dict(response.headers)),
                })

            return response

        patched_send.__quotawatch__ = True  # type: ignore[attr-defined]
        httpx.Client.send = patched_send  # type: ignore[method-assign]

        # Also patch AsyncClient
        if getattr(httpx.AsyncClient.send, "__quotawatch__", False):
            return

        original_async_send = httpx.AsyncClient.send

        async def patched_async_send(client_self: Any, request: Any, **kwargs: Any) -> Any:
            url_str = str(request.url)
            api_name = None
            for base_url, name in base_url_map.items():
                if url_str.startswith(base_url):
                    api_name = name
                    break

            start = time.monotonic()
            response = await original_async_send(client_self, request, **kwargs)

            if api_name is not None:
                latency_ms = int((time.monotonic() - start) * 1000)
                endpoint = request.url.path or "/"
                record({
                    "api": api_name,
                    "endpoint": endpoint,
                    "method": request.method.upper(),
                    "status": response.status_code,
                    "latencyMs": latency_ms,
                    "timestamp": _now_z(),
                    "environment": environment,
                    "hit429": response.status_code == 429,
                    "rateLimitHeaders": _extract_rate_limit_headers(dict(response.headers)),
                })

            return response

        patched_async_send.__quotawatch__ = True  # type: ignore[attr-defined]
        httpx.AsyncClient.send = patched_async_send  # type: ignore[method-assign]

    except ImportError:
        pass  # httpx not installed — skip
