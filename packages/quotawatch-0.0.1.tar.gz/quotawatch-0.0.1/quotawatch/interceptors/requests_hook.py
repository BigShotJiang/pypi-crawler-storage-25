from __future__ import annotations

import time
from datetime import datetime, timezone
from typing import Any, Callable


_RATELIMIT_PREFIXES = ("x-ratelimit-", "ratelimit-", "x-rate-limit-", "anthropic-ratelimit-")


def _extract_rate_limit_headers(headers: Any) -> dict[str, str]:
    return {
        k.lower(): v
        for k, v in headers.items()
        if k.lower().startswith(_RATELIMIT_PREFIXES)
    }


def _now_z() -> str:
    """Return current UTC time as ISO 8601 with Z suffix (Zod-compatible)."""
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"


def install_requests_hook(
    base_url_map: dict[str, str],
    environment: str,
    record: Callable[[dict[str, Any]], None],
) -> None:
    try:
        import requests

        if getattr(requests.Session.send, "__quotawatch__", False):
            return

        original_send = requests.Session.send

        def patched_send(session_self: Any, request: Any, **kwargs: Any) -> Any:
            api_name = None
            for base_url, name in base_url_map.items():
                if request.url.startswith(base_url):
                    api_name = name
                    break

            start = time.monotonic()
            response = original_send(session_self, request, **kwargs)

            if api_name is not None:
                latency_ms = int((time.monotonic() - start) * 1000)
                try:
                    from urllib.parse import urlparse
                    endpoint = urlparse(request.url).path or "/"
                except Exception:
                    endpoint = "/"
                record({
                    "api": api_name,
                    "endpoint": endpoint,
                    "method": request.method.upper(),
                    "status": response.status_code,
                    "latencyMs": latency_ms,
                    "timestamp": _now_z(),
                    "environment": environment,
                    "hit429": response.status_code == 429,
                    "rateLimitHeaders": _extract_rate_limit_headers(response.headers),
                })

            return response

        patched_send.__quotawatch__ = True  # type: ignore[attr-defined]
        requests.Session.send = patched_send  # type: ignore[method-assign]

    except ImportError:
        pass  # requests not installed — skip
