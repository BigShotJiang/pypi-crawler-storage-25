from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class ApiLimits:
    requests_per_minute: Optional[int] = None
    requests_per_hour: Optional[int] = None
    requests_per_day: Optional[int] = None
    requests_per_month: Optional[int] = None
    tokens_per_minute: Optional[int] = None
    tokens_per_day: Optional[int] = None
    tokens_per_month: Optional[int] = None


@dataclass
class ApiConfig:
    name: str
    base_url: str
    limits: ApiLimits
    plan: Optional[str] = None
    cost_per_month: Optional[float] = None


@dataclass
class QuotaWatchConfig:
    api_key: str
    apis: list[ApiConfig]
    environment: str = "production"
    ingest_url: str = "https://ingest.quotawatch.app"
    buffer_size: int = 500
    flush_interval_seconds: float = 5.0
