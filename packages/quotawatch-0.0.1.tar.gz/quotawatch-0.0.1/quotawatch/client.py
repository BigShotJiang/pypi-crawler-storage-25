from __future__ import annotations

import json
import threading
from typing import Any, Optional
from urllib.request import urlopen, Request

from .types import QuotaWatchConfig
from .interceptors.requests_hook import install_requests_hook
from .interceptors.httpx_hook import install_httpx_hook


class QuotaWatch:
    """
    QuotaWatch SDK — passive API usage monitoring.
    
    Usage::
    
        from quotawatch import QuotaWatch
        from quotawatch.types import ApiConfig, ApiLimits
        
        QuotaWatch.init(QuotaWatchConfig(
            api_key="qw_live_...",
            apis=[
                ApiConfig(
                    name="OpenAI",
                    base_url="https://api.openai.com",
                    limits=ApiLimits(requests_per_minute=60),
                )
            ]
        ))
    """

    _instance: Optional[QuotaWatch] = None
    _lock = threading.Lock()

    def __init__(self, config: QuotaWatchConfig) -> None:
        self.config = config
        self._buffer: list[dict[str, Any]] = []
        self._buffer_lock = threading.Lock()
        self._base_url_map: dict[str, str] = {
            api.base_url.rstrip("/"): api.name for api in config.apis
        }
        self._stop_event = threading.Event()
        self._flush_thread = threading.Thread(
            target=self._flush_loop, daemon=True
        )
        self._flush_thread.start()

        # Auto-patch requests and httpx if available
        install_requests_hook(self._base_url_map, config.environment, self.record)
        install_httpx_hook(self._base_url_map, config.environment, self.record)

    @classmethod
    def init(cls, config: QuotaWatchConfig) -> QuotaWatch:
        with cls._lock:
            if cls._instance is not None:
                return cls._instance
            cls._instance = cls(config)
            return cls._instance

    @classmethod
    def get_instance(cls) -> Optional[QuotaWatch]:
        return cls._instance

    def resolve_api_name(self, url: str) -> Optional[str]:
        for base_url, name in self._base_url_map.items():
            if url.startswith(base_url):
                return name
        return None

    def record(self, event: dict[str, Any]) -> None:
        with self._buffer_lock:
            if len(self._buffer) >= self.config.buffer_size:
                self._buffer.pop(0)  # drop oldest
            self._buffer.append(event)

    def flush(self) -> None:
        with self._buffer_lock:
            if not self._buffer:
                return
            batch = self._buffer[:]
            self._buffer.clear()

        payload = json.dumps({
            "projectApiKey": self.config.api_key,
            "events": batch,
        }).encode()

        try:
            req = Request(
                f"{self.config.ingest_url}/v1/ingest",
                data=payload,
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urlopen(req, timeout=5):
                pass
        except Exception:
            pass  # Fire-and-forget: silently drop

    def _flush_loop(self) -> None:
        while not self._stop_event.wait(self.config.flush_interval_seconds):
            self.flush()

    def destroy(self) -> None:
        self._stop_event.set()
        QuotaWatch._instance = None
