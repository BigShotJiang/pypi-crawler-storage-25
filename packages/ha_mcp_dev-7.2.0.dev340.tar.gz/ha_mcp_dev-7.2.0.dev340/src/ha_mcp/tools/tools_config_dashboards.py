"""
Configuration management tools for Home Assistant Lovelace dashboards.

This module provides tools for managing dashboard metadata and content.
"""

import asyncio
import hashlib
import json
import logging
import re
from typing import Annotated, Any, cast

from fastmcp.exceptions import ToolError
from pydantic import Field

from ..config import get_global_settings
from ..errors import ErrorCode, create_error_response, create_resource_not_found_error
from ..utils.python_sandbox import (
    PythonSandboxError,
    get_security_documentation,
    safe_execute,
)
from .helpers import exception_to_structured_error, log_tool_usage, raise_tool_error
from .util_helpers import parse_json_param

logger = logging.getLogger(__name__)



def _compute_config_hash(config: dict[str, Any]) -> str:
    """Compute a stable hash of dashboard config for optimistic locking."""
    # Use sorted keys for deterministic serialization
    config_str = json.dumps(config, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(config_str.encode()).hexdigest()[:16]


async def _verify_config_unchanged(
    client: Any,
    url_path: str,
    original_hash: str,
) -> dict[str, Any]:
    """
    Verify dashboard config hasn't changed since original read.

    Returns dict with:
    - success: bool (True if config unchanged)
    - error: str (if config changed)
    - suggestions: list[str] (if config changed)
    """
    # Re-fetch current config
    get_data: dict[str, Any] = {"type": "lovelace/config"}
    if url_path:
        get_data["url_path"] = url_path

    result = await client.send_websocket_message(get_data)
    current_config = (
        result.get("result", result) if isinstance(result, dict) else result
    )

    if not isinstance(current_config, dict):
        return {"success": True}  # Can't verify, proceed anyway

    current_hash = _compute_config_hash(current_config)

    if current_hash != original_hash:
        raise_tool_error(
            create_error_response(
                ErrorCode.SERVICE_CALL_FAILED,
                "Dashboard modified since last read (conflict)",
                suggestions=[
                    "Re-read dashboard with ha_config_get_dashboard",
                    "Then retry the operation with fresh data",
                ],
            )
        )

    return {"success": True}


def _badge_matches(badge: Any, entity_id: str) -> bool:
    """Check if a badge matches the entity_id search criteria.

    Badges can be simple strings (entity IDs) or dicts with an 'entity' field.
    Supports wildcard matching with *.
    """
    # Extract entity from badge
    if isinstance(badge, str):
        badge_entity = badge
    elif isinstance(badge, dict):
        badge_entity = badge.get("entity", "")
    else:
        return False

    if not badge_entity:
        return False

    # Support wildcard matching (same logic as _card_matches)
    if "*" in entity_id:
        pattern = entity_id.replace(".", r"\.").replace("*", ".*")
        return bool(re.match(pattern, badge_entity))

    return entity_id == badge_entity


def _find_cards_in_config(
    config: dict[str, Any],
    entity_id: str | None = None,
    card_type: str | None = None,
    heading: str | None = None,
) -> list[dict[str, Any]]:
    """
    Find cards, badges, and header cards in a dashboard config matching the search criteria.

    Returns a list of matches with location info and card/badge/header config.
    Searches cards (in sections and flat views), view-level badges, and
    sections-view header cards (views[n].header.card).
    """
    matches: list[dict[str, Any]] = []

    if "strategy" in config:
        return []  # Strategy dashboards don't have explicit cards

    views = config.get("views", [])
    for view_idx, view in enumerate(views):
        if not isinstance(view, dict):
            continue

        # Search view-level badges when filtering by entity_id or card_type="badge"
        if (
            entity_id is not None
            and heading is None
            and (card_type is None or card_type == "badge")
        ):
            badges = view.get("badges", [])
            for badge_idx, badge in enumerate(badges):
                if _badge_matches(badge, entity_id):
                    badge_config = (
                        badge if isinstance(badge, dict) else {"entity": badge}
                    )
                    matches.append(
                        {
                            "view_index": view_idx,
                            "section_index": None,
                            "card_index": None,
                            "badge_index": badge_idx,
                            "jq_path": f".views[{view_idx}].badges[{badge_idx}]",
                            "card_type": "badge",
                            "card_config": badge_config,
                        }
                    )

        # Search sections-view header card (views[n].header.card)
        # The header accepts a card (typically Markdown) that can contain entity refs
        header = view.get("header", {})
        if isinstance(header, dict):
            header_card = header.get("card")
            if isinstance(header_card, dict) and _card_matches(
                header_card, entity_id, card_type, heading
            ):
                matches.append(
                    {
                        "view_index": view_idx,
                        "section_index": None,
                        "card_index": None,
                        "jq_path": f".views[{view_idx}].header.card",
                        "card_type": header_card.get("type"),
                        "card_config": header_card,
                    }
                )

        view_type = view.get("type", "masonry")

        if view_type == "sections":
            # Sections-based view
            sections = view.get("sections", [])
            for section_idx, section in enumerate(sections):
                if not isinstance(section, dict):
                    continue
                cards = section.get("cards", [])
                for card_idx, card in enumerate(cards):
                    if not isinstance(card, dict):
                        continue
                    if _card_matches(card, entity_id, card_type, heading):
                        matches.append(
                            {
                                "view_index": view_idx,
                                "section_index": section_idx,
                                "card_index": card_idx,
                                "jq_path": f".views[{view_idx}].sections[{section_idx}].cards[{card_idx}]",
                                "card_type": card.get("type"),
                                "card_config": card,
                            }
                        )
        else:
            # Flat view (masonry, panel, sidebar)
            cards = view.get("cards", [])
            for card_idx, card in enumerate(cards):
                if not isinstance(card, dict):
                    continue
                if _card_matches(card, entity_id, card_type, heading):
                    matches.append(
                        {
                            "view_index": view_idx,
                            "section_index": None,
                            "card_index": card_idx,
                            "jq_path": f".views[{view_idx}].cards[{card_idx}]",
                            "card_type": card.get("type"),
                            "card_config": card,
                        }
                    )

    return matches


def _card_matches(
    card: dict[str, Any],
    entity_id: str | None,
    card_type: str | None,
    heading: str | None,
) -> bool:
    """Check if a card matches the search criteria."""
    # Type filter
    if card_type is not None:
        if card.get("type") != card_type:
            return False

    # Entity filter (supports partial matching with *)
    if entity_id is not None:
        card_entity = card.get("entity", "")
        # Also check entities list for cards that have multiple entities
        card_entities = card.get("entities", [])
        if isinstance(card_entities, list):
            all_entities = [card_entity] + [
                e.get("entity", e) if isinstance(e, dict) else e for e in card_entities
            ]
        else:
            all_entities = [card_entity]

        # Support wildcard matching
        if "*" in entity_id:
            pattern = entity_id.replace(".", r"\.").replace("*", ".*")
            if not any(re.match(pattern, e) for e in all_entities if e):
                return False
        else:
            if entity_id not in all_entities:
                return False

    # Heading filter (for heading cards or section titles)
    if heading is not None:
        card_heading = card.get("heading", card.get("title", ""))
        # Case-insensitive partial match
        if heading.lower() not in card_heading.lower():
            return False

    return True


def register_config_dashboard_tools(mcp: Any, client: Any, **kwargs: Any) -> None:
    """Register Home Assistant dashboard configuration tools."""

    @mcp.tool(
        tags={"Dashboards"},
        annotations={
            "idempotentHint": True,
            "readOnlyHint": True,
            "title": "Get Dashboard"
        }
    )
    @log_tool_usage
    async def ha_config_get_dashboard(
        url_path: Annotated[
            str | None,
            Field(
                description="Dashboard URL path (e.g., 'lovelace-home'). "
                "Use 'default' for default dashboard. "
                "If omitted with list_only=True, lists all dashboards."
            ),
        ] = None,
        list_only: Annotated[
            bool,
            Field(
                description="If True, list all dashboards instead of getting config. "
                "When True, url_path is ignored.",
            ),
        ] = False,
        force_reload: Annotated[
            bool, Field(description="Force reload from storage (bypass cache)")
        ] = False,
    ) -> dict[str, Any]:
        """
        Get dashboard info - list all dashboards or get config for a specific one.

        Without url_path (or with list_only=True): Lists all storage-mode dashboards
        with metadata including url_path, title, icon, admin requirements.

        With url_path: Returns the full Lovelace dashboard configuration
        including all views and cards.

        EXAMPLES:
        - List all dashboards: ha_config_get_dashboard(list_only=True)
        - Get default dashboard: ha_config_get_dashboard(url_path="default")
        - Get custom dashboard: ha_config_get_dashboard(url_path="lovelace-mobile")
        - Force reload: ha_config_get_dashboard(url_path="lovelace-home", force_reload=True)

        Note: YAML-mode dashboards (defined in configuration.yaml) are not included in list.
        """
        try:
            # List mode
            if list_only:
                result = await client.send_websocket_message(
                    {"type": "lovelace/dashboards/list"}
                )
                if isinstance(result, dict) and "result" in result:
                    dashboards = result["result"]
                elif isinstance(result, list):
                    dashboards = result
                else:
                    dashboards = []

                return {
                    "success": True,
                    "action": "list",
                    "dashboards": dashboards,
                    "count": len(dashboards),
                }

            # Get mode - build WebSocket message
            data: dict[str, Any] = {"type": "lovelace/config", "force": force_reload}
            # Handle "default" as special value for default dashboard
            if url_path and url_path != "default":
                data["url_path"] = url_path

            response = await client.send_websocket_message(data)

            # Check if request failed
            if isinstance(response, dict) and not response.get("success", True):
                error_msg = response.get("error", {})
                if isinstance(error_msg, dict):
                    error_msg = error_msg.get("message", str(error_msg))
                raise_tool_error(
                    create_error_response(
                        ErrorCode.SERVICE_CALL_FAILED,
                        str(error_msg),
                        suggestions=[
                            "Use ha_config_get_dashboard(list_only=True) to see available dashboards",
                            "Check if you have permission to access this dashboard",
                            "Use url_path='default' for default dashboard",
                        ],
                        context={"action": "get", "url_path": url_path},
                    )
                )

            # Extract config from WebSocket response
            config = response.get("result") if isinstance(response, dict) else response

            # Compute hash for optimistic locking in subsequent operations
            config_hash = (
                _compute_config_hash(config) if isinstance(config, dict) else None
            )

            # Calculate config size for progressive disclosure hint
            config_size = len(json.dumps(config)) if isinstance(config, dict) else 0

            result = {
                "success": True,
                "action": "get",
                "url_path": url_path,
                "config": config,
                "config_hash": config_hash,
                "config_size_bytes": config_size,
            }

            # Add hint for large configs (progressive disclosure) - 10KB ≈ 2-3k tokens
            if config_size >= 10000:
                result["hint"] = (
                    f"Large config ({config_size:,} bytes). For edits, use "
                    "ha_dashboard_find_card() + ha_config_set_dashboard(python_transform=...) "
                    "instead of full config replacement."
                )

            return result
        except ToolError:
            raise
        except Exception as e:
            logger.error(f"Error getting dashboard: {e}")
            exception_to_structured_error(
                e,
                context={
                    "action": "get" if not list_only else "list",
                    "url_path": url_path,
                },
                suggestions=[
                    "Use ha_config_get_dashboard(list_only=True) to see available dashboards",
                    "Check if you have permission to access this dashboard",
                    "Use url_path='default' for default dashboard",
                ],
            )

    @mcp.tool(
        tags={"Dashboards"},
        annotations={
            "destructiveHint": True,
            "title": "Create or Update Dashboard"
        }
    )
    @log_tool_usage
    async def ha_config_set_dashboard(
        url_path: Annotated[
            str,
            Field(
                description="Dashboard URL path (e.g., 'my-dashboard'). "
                "Use 'default' or 'lovelace' for the default dashboard. "
                "New dashboards must use a hyphenated path."
            ),
        ],
        config: Annotated[
            str | dict[str, Any] | None,
            Field(
                description="Dashboard configuration with views and cards. "
                "Can be dict or JSON string. "
                "Omit or set to None to create dashboard without initial config. "
                "Mutually exclusive with python_transform."
            ),
        ] = None,
        python_transform: Annotated[
            str | None,
            Field(
                description="Python expression to transform existing dashboard config. "
                "Mutually exclusive with config. "
                "Requires config_hash for validation. "
                "See PYTHON TRANSFORM SECURITY below for allowed operations. "
                "Examples: "
                "Simple: python_transform=\"config['views'][0]['cards'][0]['icon'] = 'mdi:lamp'\" "
                "Pattern: python_transform=\"for card in config['views'][0]['cards']: if 'light' in card.get('entity', ''): card['icon'] = 'mdi:lightbulb'\" "
                "Multi-op: python_transform=\"config['views'][0]['cards'][0]['icon'] = 'mdi:lamp'; del config['views'][0]['cards'][2]\" "
                "\n\n" + get_security_documentation(),
            ),
        ] = None,
        config_hash: Annotated[
            str | None,
            Field(
                description="Config hash from ha_config_get_dashboard for optimistic locking. "
                "REQUIRED for python_transform (validates dashboard unchanged). "
                "Optional for config (validates before full replacement if provided)."
            ),
        ] = None,
        title: Annotated[
            str | None,
            Field(description="Dashboard display name shown in sidebar"),
        ] = None,
        icon: Annotated[
            str | None,
            Field(
                description="MDI icon name (e.g., 'mdi:home', 'mdi:cellphone'). "
                "Defaults to 'mdi:view-dashboard'"
            ),
        ] = None,
        require_admin: Annotated[
            bool | None,
            Field(
                description="Restrict dashboard to admin users only. "
                "For existing dashboards, only updated when explicitly provided."
            ),
        ] = None,
        show_in_sidebar: Annotated[
            bool | None,
            Field(
                description="Show dashboard in sidebar navigation. "
                "For existing dashboards, only updated when explicitly provided."
            ),
        ] = None,
    ) -> dict[str, Any]:
        """
        Create or update a Home Assistant dashboard.

        Creates a new dashboard or updates an existing one with the provided configuration.
        Supports two modes: full config replacement OR Python transformation.

        Use 'default' or 'lovelace' to target the built-in default dashboard.
        New dashboards require a hyphenated url_path (e.g., 'my-dashboard').

        WHEN TO USE WHICH MODE:
        - python_transform: RECOMMENDED for edits. Surgical/pattern-based updates, works on all platforms.
        - config: New dashboards only, or full restructure. Replaces everything.

        IMPORTANT: After delete/add operations, indices shift! Subsequent python_transform calls
        must use fresh config_hash from ha_dashboard_find_card() or ha_config_get_dashboard()
        to get updated structure. Chain multiple ops in ONE expression when possible.

        TIP: Use ha_dashboard_find_card() to get the path for any card.

        PYTHON TRANSFORM EXAMPLES (RECOMMENDED):
        - Update card icon: 'config["views"][0]["cards"][0]["icon"] = "mdi:thermometer"'
        - Add card: 'config["views"][0]["cards"].append({"type": "button", "entity": "light.bedroom"})'
        - Delete card: 'del config["views"][0]["cards"][2]'
        - Pattern-based update: 'for card in config["views"][0]["cards"]: if "light" in card.get("entity", ""): card["icon"] = "mdi:lightbulb"'
        - Multi-operation: 'config["views"][0]["cards"][0]["icon"] = "mdi:a"; config["views"][0]["cards"][1]["icon"] = "mdi:b"'

        MODERN DASHBOARD BEST PRACTICES (2024+):
        - Use "sections" view type (default) with grid-based layouts
        - Use "tile" cards as primary card type (replaces legacy entity/light/climate cards)
        - Use "grid" cards for multi-column layouts within sections
        - Create multiple views with navigation paths (avoid single-view endless scrolling)
        - Use "area" cards with navigation for hierarchical organization

        DISCOVERING ENTITY IDs FOR DASHBOARDS:
        Do NOT guess entity IDs - use these tools to find exact entity IDs:
        1. ha_get_overview(include_entity_id=True) - Get all entities organized by domain/area
        2. ha_search_entities(query, domain_filter, area_filter) - Find specific entities
        3. ha_deep_search(query) - Comprehensive search across entities, areas, automations

        If unsure about entity IDs, ALWAYS use one of these tools first.

        DASHBOARD DOCUMENTATION (via MCP skills):
        - skill://home-assistant-best-practices/references/dashboard-guide.md — comprehensive guide
        - skill://home-assistant-best-practices/references/dashboard-cards.md — card types list
        - ha_get_skill_home_assistant_best_practices — guidance on card types and configuration

        EXAMPLES:

        Create empty dashboard:
        ha_config_set_dashboard(
            url_path="mobile-dashboard",
            title="Mobile View",
            icon="mdi:cellphone"
        )

        Create dashboard with modern sections view:
        ha_config_set_dashboard(
            url_path="home-dashboard",
            title="Home Overview",
            config={
                "views": [{
                    "title": "Home",
                    "type": "sections",
                    "sections": [{
                        "title": "Climate",
                        "cards": [{
                            "type": "tile",
                            "entity": "climate.living_room",
                            "features": [{"type": "target-temperature"}]
                        }]
                    }]
                }]
            }
        )

        Create strategy-based dashboard (auto-generated):
        ha_config_set_dashboard(
            url_path="my-home",
            title="My Home",
            config={
                "strategy": {
                    "type": "home",
                    "favorite_entities": ["light.bedroom"]
                }
            }
        )

        Note: Strategy dashboards cannot be converted to custom dashboards via this tool.
        Use the "Take Control" feature in the Home Assistant interface to convert them.

        Update existing dashboard config:
        ha_config_set_dashboard(
            url_path="existing-dashboard",
            config={
                "views": [{
                    "title": "Updated View",
                    "type": "sections",
                    "sections": [{
                        "cards": [{"type": "markdown", "content": "Updated!"}]
                    }]
                }]
            }
        )

        Note: When updating an existing dashboard, title/icon/require_admin/show_in_sidebar
        are also updated if explicitly provided alongside (or instead of) a config change.
        """
        try:
            # Handle "default" as alias for the default dashboard
            # (matches ha_config_get_dashboard behavior)
            if url_path == "default":
                url_path = "lovelace"

            # Validate url_path contains hyphen for new dashboards
            # The built-in "lovelace" dashboard is exempt since it already exists
            if "-" not in url_path and url_path != "lovelace":
                raise_tool_error(
                    create_error_response(
                        ErrorCode.VALIDATION_INVALID_PARAMETER,
                        "url_path must contain a hyphen (-)",
                        suggestions=[
                            f"Try '{url_path.replace('_', '-')}' instead",
                            "Use format like 'my-dashboard' or 'mobile-view'",
                            "Use 'lovelace' or 'default' to edit the default dashboard",
                        ],
                        context={"action": "set", "url_path": url_path},
                    )
                )

            # Validate mutual exclusivity of config and python_transform
            if config is not None and python_transform is not None:
                raise_tool_error(
                    create_error_response(
                        ErrorCode.VALIDATION_INVALID_PARAMETER,
                        "Cannot use both config and python_transform simultaneously",
                        suggestions=[
                            "Use only ONE of: config or python_transform",
                            "config: Full replacement",
                            "python_transform: Python-based edits (recommended)",
                        ],
                        context={"action": "set", "url_path": url_path},
                    )
                )

            # Handle python_transform mode
            if python_transform is not None:
                # config_hash is REQUIRED
                if config_hash is None:
                    raise_tool_error(
                        create_error_response(
                            ErrorCode.VALIDATION_INVALID_PARAMETER,
                            "config_hash is required for python_transform",
                            suggestions=[
                                "Call ha_config_get_dashboard() first",
                                "Use the config_hash from that response",
                            ],
                            context={
                                "action": "python_transform",
                                "url_path": url_path,
                            },
                        )
                    )

                # Fetch current dashboard config
                get_data: dict[str, Any] = {"type": "lovelace/config", "force": True}
                if url_path:
                    get_data["url_path"] = url_path

                response = await client.send_websocket_message(get_data)

                if isinstance(response, dict) and not response.get("success", True):
                    error_msg = response.get("error", {})
                    if isinstance(error_msg, dict):
                        error_msg = error_msg.get("message", str(error_msg))
                    raise_tool_error(
                        create_error_response(
                            ErrorCode.SERVICE_CALL_FAILED,
                            f"Dashboard not found or inaccessible: {error_msg}",
                            suggestions=[
                                "python_transform requires an existing dashboard",
                                "Use 'config' parameter to create a new dashboard",
                                "Verify dashboard exists with ha_config_get_dashboard(list_only=True)",
                            ],
                            context={
                                "action": "python_transform",
                                "url_path": url_path,
                            },
                        )
                    )

                current_config = (
                    response.get("result") if isinstance(response, dict) else response
                )
                if not isinstance(current_config, dict):
                    raise_tool_error(
                        create_error_response(
                            ErrorCode.SERVICE_CALL_FAILED,
                            "Current dashboard config is invalid",
                            suggestions=[
                                "Initialize dashboard with 'config' parameter first"
                            ],
                            context={
                                "action": "python_transform",
                                "url_path": url_path,
                            },
                        )
                    )

                # Validate config_hash for optimistic locking
                current_hash = _compute_config_hash(current_config)
                if current_hash != config_hash:
                    raise_tool_error(
                        create_error_response(
                            ErrorCode.SERVICE_CALL_FAILED,
                            "Dashboard modified since last read (conflict)",
                            suggestions=[
                                "Call ha_config_get_dashboard() again",
                                "Use the fresh config_hash from that response",
                            ],
                            context={
                                "action": "python_transform",
                                "url_path": url_path,
                            },
                        )
                    )

                # Apply Python transformation with validation
                try:
                    transformed_config = safe_execute(python_transform, current_config)
                except PythonSandboxError as e:
                    raise_tool_error(
                        create_error_response(
                            ErrorCode.VALIDATION_FAILED,
                            str(e),
                            suggestions=[
                                "Check expression syntax",
                                "Ensure only allowed operations are used",
                                "See tool description for allowed operations",
                                f"Expression: {python_transform[:100]}...",
                            ],
                            context={
                                "action": "python_transform",
                                "url_path": url_path,
                            },
                        )
                    )

                # Save transformed config
                save_data: dict[str, Any] = {
                    "type": "lovelace/config/save",
                    "config": transformed_config,
                }
                if url_path:
                    save_data["url_path"] = url_path

                save_result = await client.send_websocket_message(save_data)

                if isinstance(save_result, dict) and not save_result.get(
                    "success", True
                ):
                    error_msg = save_result.get("error", {})
                    if isinstance(error_msg, dict):
                        error_msg = error_msg.get("message", str(error_msg))
                    raise_tool_error(
                        create_error_response(
                            ErrorCode.SERVICE_CALL_FAILED,
                            f"Failed to save transformed config: {error_msg}",
                            suggestions=[
                                "Expression may have produced invalid dashboard structure",
                                "Verify config format is valid Lovelace JSON",
                            ],
                            context={
                                "action": "python_transform",
                                "url_path": url_path,
                            },
                        )
                    )

                # Compute new hash for potential chaining
                new_config_hash = _compute_config_hash(transformed_config)

                return {
                    "success": True,
                    "action": "python_transform",
                    "url_path": url_path,
                    "config_hash": new_config_hash,
                    "python_expression": python_transform,
                    "message": f"Dashboard {url_path} updated via Python transform",
                }

            # Check if dashboard exists
            result = await client.send_websocket_message(
                {"type": "lovelace/dashboards/list"}
            )
            if isinstance(result, dict) and "result" in result:
                existing_dashboards = result["result"]
            elif isinstance(result, list):
                existing_dashboards = result
            else:
                existing_dashboards = []
            dashboard_exists = any(
                d.get("url_path") == url_path for d in existing_dashboards
            )

            # The built-in default dashboard ("lovelace") is always present
            # but isn't listed by lovelace/dashboards/list on fresh installs
            if url_path == "lovelace":
                dashboard_exists = True

            # If dashboard doesn't exist, create it
            dashboard_id = None
            metadata_updated = False
            hint = None
            if not dashboard_exists:
                # Use provided title or generate from url_path
                dashboard_title = title or url_path.replace("-", " ").title()

                # Build create message
                create_data: dict[str, Any] = {
                    "type": "lovelace/dashboards/create",
                    "url_path": url_path,
                    "title": dashboard_title,
                    "require_admin": require_admin
                    if require_admin is not None
                    else False,
                    "show_in_sidebar": show_in_sidebar
                    if show_in_sidebar is not None
                    else True,
                }
                if icon:
                    create_data["icon"] = icon
                create_result = await client.send_websocket_message(create_data)

                # Check if dashboard creation was successful
                if isinstance(create_result, dict) and not create_result.get(
                    "success", True
                ):
                    error_msg = create_result.get("error", {})
                    if isinstance(error_msg, dict):
                        error_msg = error_msg.get("message", str(error_msg))
                    raise_tool_error(
                        create_error_response(
                            ErrorCode.SERVICE_CALL_FAILED,
                            str(error_msg),
                            context={"action": "create", "url_path": url_path},
                        )
                    )

                # Extract dashboard ID from create response
                if isinstance(create_result, dict) and "result" in create_result:
                    dashboard_info = create_result["result"]
                    dashboard_id = dashboard_info.get("id")
                elif isinstance(create_result, dict):
                    dashboard_id = create_result.get("id")
            else:
                # If dashboard already exists, get its ID from the list
                for dashboard in existing_dashboards:
                    if dashboard.get("url_path") == url_path:
                        dashboard_id = dashboard.get("id")
                        break

                # Update metadata for existing dashboard if any metadata params provided
                metadata_update_fields: dict[str, Any] = {
                    k: v
                    for k, v in {
                        "title": title,
                        "icon": icon,
                        "require_admin": require_admin,
                        "show_in_sidebar": show_in_sidebar,
                    }.items()
                    if v is not None
                }
                if metadata_update_fields and dashboard_id is not None:
                    meta_update: dict[str, Any] = {
                        "type": "lovelace/dashboards/update",
                        "dashboard_id": dashboard_id,
                        **metadata_update_fields,
                    }
                    meta_result = await client.send_websocket_message(meta_update)
                    if isinstance(meta_result, dict) and not meta_result.get(
                        "success", True
                    ):
                        error_msg = meta_result.get("error", {})
                        if isinstance(error_msg, dict):
                            error_msg = error_msg.get("message", str(error_msg))
                        raise_tool_error(
                            create_error_response(
                                code=ErrorCode.SERVICE_CALL_FAILED,
                                message=f"Failed to update dashboard metadata: {error_msg}",
                                suggestions=[
                                    "Check that you have admin permissions",
                                    "Verify dashboard is in storage mode (not YAML mode)",
                                ],
                                context={"action": "update", "url_path": url_path},
                            )
                        )
                    metadata_updated = True
                elif metadata_update_fields and dashboard_id is None:
                    # Dashboard ID not found in storage list (e.g. default lovelace on
                    # fresh installs). Metadata update via lovelace/dashboards/update
                    # is not possible without a storage ID — config update still proceeds.
                    metadata_updated = False
                    hint = (
                        "Metadata fields were provided but could not be applied: "
                        "dashboard has no storage ID (likely the built-in default dashboard). "
                        "Config changes were still saved."
                    )

            # Set config if provided
            config_updated = False
            existing_config_size = 0

            if config is not None:
                parsed_config = parse_json_param(config, "config")
                if parsed_config is None or not isinstance(parsed_config, dict):
                    raise_tool_error(
                        create_error_response(
                            ErrorCode.VALIDATION_INVALID_PARAMETER,
                            "Config parameter must be a dict/object",
                            context={
                                "action": "set",
                                "provided_type": type(parsed_config).__name__,
                            },
                        )
                    )

                config_dict = cast(dict[str, Any], parsed_config)

                # For existing dashboards, optionally validate config_hash and warn on large replacement
                if dashboard_exists:
                    # Fetch current config for validation/comparison
                    get_data = {
                        "type": "lovelace/config",
                        "force": True,
                    }
                    if url_path:
                        get_data["url_path"] = url_path
                    current_response = await client.send_websocket_message(get_data)
                    current_config = (
                        current_response.get("result")
                        if isinstance(current_response, dict)
                        else current_response
                    )

                    if isinstance(current_config, dict):
                        existing_config_size = len(json.dumps(current_config))

                        # Optional config_hash validation for full replacement
                        if config_hash is not None:
                            current_hash = _compute_config_hash(current_config)
                            if current_hash != config_hash:
                                raise_tool_error(
                                    create_error_response(
                                        ErrorCode.SERVICE_CALL_FAILED,
                                        "Dashboard modified since last read (conflict)",
                                        suggestions=[
                                            "Call ha_config_get_dashboard() again",
                                            "Use the fresh config_hash, or omit config_hash to force replace",
                                        ],
                                        context={"action": "set", "url_path": url_path},
                                    )
                                )

                        # Soft warning for large config full replacement (10KB ≈ 2-3k tokens)
                        if existing_config_size >= 10000:
                            hint = (
                                f"Replaced large config ({existing_config_size:,} bytes). "
                                "Consider python_transform for targeted edits."
                            )

                # Build save config message
                config_save_data: dict[str, Any] = {
                    "type": "lovelace/config/save",
                    "config": config_dict,
                }
                if url_path:
                    config_save_data["url_path"] = url_path
                save_result = await client.send_websocket_message(config_save_data)

                # Check if save failed
                if isinstance(save_result, dict) and not save_result.get(
                    "success", True
                ):
                    error_msg = save_result.get("error", {})
                    if isinstance(error_msg, dict):
                        error_msg = error_msg.get("message", str(error_msg))
                    raise_tool_error(
                        create_error_response(
                            ErrorCode.SERVICE_CALL_FAILED,
                            f"Failed to save dashboard config: {error_msg}",
                            suggestions=[
                                "Verify config format is valid Lovelace JSON",
                                "Check that you have admin permissions",
                                "Ensure all entity IDs in config exist",
                            ],
                            context={"action": "set", "url_path": url_path},
                        )
                    )

                config_updated = True

            result_dict: dict[str, Any] = {
                "success": True,
                "action": "create" if not dashboard_exists else "update",
                "url_path": url_path,
                "dashboard_id": dashboard_id,
                "dashboard_created": not dashboard_exists,
                "config_updated": config_updated,
                "metadata_updated": metadata_updated,
                "message": f"Dashboard {url_path} {'created' if not dashboard_exists else 'updated'} successfully",
            }

            if hint:
                result_dict["hint"] = hint

            return result_dict

        except ToolError:
            raise
        except Exception as e:
            logger.error(f"Error setting dashboard: {e}")
            exception_to_structured_error(
                e,
                context={"action": "set", "url_path": url_path},
                suggestions=[
                    "Ensure url_path is unique (not already in use for different dashboard type)",
                    "New dashboards require a hyphenated url_path",
                    "Check that you have admin permissions",
                    "Verify config format is valid Lovelace JSON",
                ],
            )

    @mcp.tool(
        tags={"Dashboards"},
        annotations={
            "destructiveHint": True,
            "title": "Delete Dashboard"
        }
    )
    @log_tool_usage
    async def ha_config_delete_dashboard(
        dashboard_id: Annotated[
            str,
            Field(
                description="Dashboard ID or URL path to delete (e.g., 'my-dashboard' or 'my_dashboard')"
            ),
        ],
    ) -> dict[str, Any]:
        """
        Delete a storage-mode dashboard completely.

        WARNING: This permanently deletes the dashboard and all its configuration.
        Cannot be undone. Does not work on YAML-mode dashboards.

        Accepts either the internal dashboard ID or the URL path.
        The tool resolves url_path to internal ID automatically.

        EXAMPLES:
        - Delete dashboard: ha_config_delete_dashboard("mobile-dashboard")

        Note: The default dashboard cannot be deleted via this method.
        """
        try:
            # Fetch dashboard list to resolve the provided identifier.
            # HA internal IDs may differ from url_path (e.g. hyphens → underscores),
            # so we accept either and resolve to the actual registry ID.
            list_result = await client.send_websocket_message(
                {"type": "lovelace/dashboards/list"}
            )
            if isinstance(list_result, dict) and "result" in list_result:
                dashboards = list_result["result"]
            elif isinstance(list_result, list):
                dashboards = list_result
            else:
                dashboards = []

            resolved_id = None
            for d in dashboards:
                if d.get("id") == dashboard_id:
                    resolved_id = d["id"]
                    break
                if d.get("url_path") == dashboard_id:
                    resolved_id = d["id"]
                    break

            if resolved_id is None:
                raise_tool_error(create_resource_not_found_error(
                    "Dashboard",
                    dashboard_id,
                    details=(
                        f"No dashboard found with ID or URL path '{dashboard_id}'. "
                        "Use ha_config_get_dashboard(list_only=True) to see available dashboards."
                    ),
                ))

            response = await client.send_websocket_message(
                {"type": "lovelace/dashboards/delete", "dashboard_id": resolved_id}
            )

            # Check response for error indication
            if isinstance(response, dict) and not response.get("success", True):
                error_msg = response.get("error", {})
                if isinstance(error_msg, dict):
                    error_str = error_msg.get("message", str(error_msg))
                else:
                    error_str = str(error_msg)

                logger.error(f"Error deleting dashboard: {error_str}")

                # If the error is "not found" / "doesn't exist", treat as success (idempotent)
                if (
                    "unable to find" in error_str.lower()
                    or "not found" in error_str.lower()
                ):
                    return {
                        "success": True,
                        "action": "delete",
                        "dashboard_id": dashboard_id,
                        "message": "Dashboard already deleted or does not exist",
                    }

                # For other errors, raise
                raise_tool_error(
                    create_error_response(
                        ErrorCode.SERVICE_CALL_FAILED,
                        f"Failed to delete dashboard: {error_str}",
                        suggestions=[
                            "Verify dashboard exists and is storage-mode",
                            "Check that you have admin permissions",
                            "Use ha_config_get_dashboard(list_only=True) to see available dashboards",
                            "Cannot delete YAML-mode or default dashboard",
                        ],
                        context={"action": "delete", "dashboard_id": dashboard_id},
                    )
                )

            # Delete successful
            result: dict[str, Any] = {
                "success": True,
                "action": "delete",
                "dashboard_id": dashboard_id,
                "message": "Dashboard deleted successfully",
            }
            if resolved_id != dashboard_id:
                result["resolved_id"] = resolved_id
            return result
        except ToolError:
            raise
        except Exception as e:
            logger.error(f"Error deleting dashboard: {e}")
            exception_to_structured_error(
                e,
                context={"action": "delete", "dashboard_id": dashboard_id},
                suggestions=[
                    "Verify dashboard exists and is storage-mode",
                    "Check that you have admin permissions",
                    "Use ha_config_get_dashboard(list_only=True) to see available dashboards",
                    "Cannot delete YAML-mode or default dashboard",
                ],
            )

    # =========================================================================
    # Dashboard Resource Management Tools
    # =========================================================================
    # Resource tools have been moved to tools_resources.py for better organization.
    # Available tools:
    # - ha_config_list_dashboard_resources: List all resources
    # - ha_config_set_dashboard_resource: Create/update resources (inline code or URL)
    # - ha_config_delete_dashboard_resource: Delete resources
    # =========================================================================

    # =========================================================================
    # Card Search Tool (partial update tools - controlled by feature flag)
    # Card add/update/remove replaced by python_transform in ha_config_set_dashboard
    # =========================================================================

    # Check feature flag for partial update tools (lazy check, default enabled)
    try:
        settings = get_global_settings()
        if not settings.enable_dashboard_partial_tools:
            return  # Skip registering find_card if partial tools disabled
    except Exception:
        pass  # Default: register the tool if settings unavailable

    @mcp.tool(
        tags={"Dashboards"},
        annotations={
            "idempotentHint": True,
            "readOnlyHint": True,
            "title": "Find Dashboard Card"
        }
    )
    @log_tool_usage
    async def ha_dashboard_find_card(
        url_path: Annotated[
            str | None,
            Field(
                description="Dashboard URL path, e.g. 'lovelace-home'. Omit for default."
            ),
        ] = None,
        entity_id: Annotated[
            str | None,
            Field(
                description="Find cards by entity ID. Supports wildcards, e.g. 'sensor.temperature_*'. "
                "Matches cards with this entity in 'entity' or 'entities' field."
            ),
        ] = None,
        card_type: Annotated[
            str | None,
            Field(description="Find cards by type, e.g. 'tile', 'button', 'heading'."),
        ] = None,
        heading: Annotated[
            str | None,
            Field(
                description="Find cards by heading/title text (case-insensitive partial match). "
                "Useful for finding section headings (type: 'heading')."
            ),
        ] = None,
        include_config: Annotated[
            bool,
            Field(
                description="Include full card configuration in results (increases output size)."
            ),
        ] = False,
    ) -> dict[str, Any]:
        """
        Find cards, badges, and header cards in a dashboard by entity_id, type, or heading text.

        Returns card/badge/header locations (view_index, section_index, card_index/badge_index)
        and path for use with ha_config_set_dashboard(python_transform=...).

        Also searches view-level badges (views[n].badges) and sections-view header cards
        (views[n].header.card). Badges are the chip row at the top of a view, and header
        cards are Markdown cards in the view header — both reference entities and are
        often missed during entity rename operations.

        Use this tool BEFORE targeted updates to find exact card positions without
        manually parsing the full dashboard config.

        SEARCH CRITERIA (at least one required):
        - entity_id: Match cards and badges containing this entity (supports wildcards with *)
        - card_type: Match cards of this type (e.g., 'tile', 'button', 'heading')
        - heading: Match cards with this text in heading/title (partial, case-insensitive)

        Multiple criteria are AND-ed together.

        EXAMPLES:

        Find all tile cards:
        ha_dashboard_find_card(url_path="my-dashboard", card_type="tile")

        Find cards for a specific entity:
        ha_dashboard_find_card(url_path="my-dashboard", entity_id="light.living_room")

        Find all temperature sensors (wildcard):
        ha_dashboard_find_card(url_path="my-dashboard", entity_id="sensor.temperature_*")

        Find the "Climate" section heading:
        ha_dashboard_find_card(url_path="my-dashboard", heading="Climate", card_type="heading")

        WORKFLOW EXAMPLE:
        1. find = ha_dashboard_find_card(url_path="my-dash", entity_id="light.bedroom")
        2. # Use jq_path and config_hash from result to update:
        3. ha_config_set_dashboard(
               url_path="my-dash",
               config_hash=find["config_hash"],
               python_transform=f'config{find["matches"][0]["jq_path"]}["icon"] = "mdi:lamp"'
           )
        """
        try:
            # Validate at least one search criteria
            if entity_id is None and card_type is None and heading is None:
                raise_tool_error(
                    create_error_response(
                        ErrorCode.VALIDATION_INVALID_PARAMETER,
                        "At least one search criteria required",
                        suggestions=[
                            "Provide entity_id, card_type, or heading parameter",
                            "Use entity_id='sensor.*' to find all sensor cards",
                            "Use card_type='heading' to find section headings",
                        ],
                        context={"action": "find_card"},
                    )
                )

            # Fetch dashboard config
            get_data: dict[str, Any] = {"type": "lovelace/config", "force": True}
            if url_path:
                get_data["url_path"] = url_path

            response = await client.send_websocket_message(get_data)

            if isinstance(response, dict) and not response.get("success", True):
                error_msg = response.get("error", {})
                if isinstance(error_msg, dict):
                    error_msg = error_msg.get("message", str(error_msg))
                raise_tool_error(
                    create_error_response(
                        ErrorCode.SERVICE_CALL_FAILED,
                        f"Failed to get dashboard: {error_msg}",
                        suggestions=[
                            "Verify dashboard exists with ha_config_get_dashboard(list_only=True)",
                            "Check HA connection",
                        ],
                        context={"action": "find_card", "url_path": url_path},
                    )
                )

            config = response.get("result") if isinstance(response, dict) else response
            if not isinstance(config, dict):
                raise_tool_error(
                    create_error_response(
                        ErrorCode.SERVICE_CALL_FAILED,
                        "Dashboard config is empty or invalid",
                        suggestions=[
                            "Initialize dashboard with ha_config_set_dashboard"
                        ],
                        context={"action": "find_card", "url_path": url_path},
                    )
                )

            # Check for strategy dashboard
            if "strategy" in config:
                raise_tool_error(
                    create_error_response(
                        ErrorCode.VALIDATION_FAILED,
                        "Strategy dashboards have no explicit cards to search",
                        suggestions=[
                            "Use 'Take Control' in HA UI to convert to editable",
                            "Or create a non-strategy dashboard",
                        ],
                        context={"action": "find_card", "url_path": url_path},
                    )
                )

            # Find matching cards
            matches = _find_cards_in_config(config, entity_id, card_type, heading)

            # Optionally strip config to reduce output size
            if not include_config:
                for match in matches:
                    del match["card_config"]

            # Compute config hash for potential follow-up operations
            config_hash = _compute_config_hash(config)

            return {
                "success": True,
                "action": "find_card",
                "url_path": url_path,
                "config_hash": config_hash,
                "search_criteria": {
                    "entity_id": entity_id,
                    "card_type": card_type,
                    "heading": heading,
                },
                "matches": matches,
                "match_count": len(matches),
                "hint": "Use jq_path with ha_config_set_dashboard(python_transform=...) for targeted updates"
                if matches
                else "No matches found. Try broader search criteria.",
            }

        except asyncio.CancelledError:
            raise
        except ToolError:
            raise
        except Exception as e:
            logger.error(
                f"Error finding card: url_path={url_path}, "
                f"entity_id={entity_id}, card_type={card_type}, heading={heading}, "
                f"error={e}",
                exc_info=True,
            )
            exception_to_structured_error(
                e,
                context={
                    "action": "find_card",
                    "url_path": url_path,
                    "entity_id": entity_id,
                    "card_type": card_type,
                    "heading": heading,
                },
                suggestions=[
                    "Check HA connection",
                    "Verify dashboard with ha_config_get_dashboard(list_only=True)",
                ],
            )
