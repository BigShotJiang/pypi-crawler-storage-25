# Travel Brief

- city: Lisbon
- trip goal: design-heavy long weekend
- constraints: walkable neighborhoods, low-friction transit
