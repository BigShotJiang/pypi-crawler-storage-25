# VibeCheck CLI

VibeCheck runs your command, catches failures, and translates technical stderr into beginner-friendly guidance.

## Install (Global)

Install once, use in all projects:

```bash
python3 -m pip install --user pipx
python3 -m pipx ensurepath
pipx install vibecheck-error-assistant-cli
```

Restart terminal once after `ensurepath`.

On first run, VibeCheck will guide you through setup and save your provider/token globally in `~/.config/vibecheck/.env`.

## Configure Token

Option A: per-project `.env` file:

```bash
VIBECHECK_GITHUB_TOKEN=your_token_here
VIBECHECK_ENDPOINT=https://models.inference.ai.azure.com
```

Option B: global shell variables in `~/.bashrc`:

```bash
export VIBECHECK_GITHUB_TOKEN="your_token_here"
export VIBECHECK_ENDPOINT="https://models.inference.ai.azure.com"
source ~/.bashrc
```

Or run the built-in setup wizard:

```bash
vibecheck setup
```

## Usage

Single command mode:

```bash
vibecheck node app.js
vibecheck python app.py
```

Interactive mode (tool waits in terminal):

```bash
vibecheck --shell
```

Exit interactive mode with `exit` or `quit`.

## Useful Flags

```bash
vibecheck --level beginner python app.py
vibecheck --level advanced node app.js
vibecheck --print-raw-error python app.py
```

## Developer Install (Contributors)

From project root:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -e .
```

## Exit Codes

- Returns `0` when wrapped command succeeds.
- Returns wrapped command's non-zero exit code when command fails.
- Returns `2` on configuration errors.
