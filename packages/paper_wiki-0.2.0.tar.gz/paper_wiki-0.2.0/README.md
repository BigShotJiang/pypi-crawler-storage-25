# paper-wiki

Deep paper reading wiki: search, summarize, and analyze arXiv papers into a three-layer markdown wiki.

## Features

- Search arXiv papers via [deepxiv](https://data.rag.ac.cn) CLI
- Download paper PDFs
- Generate per-section Chinese summaries using LLM
- Produce a full paper analysis with 5 dimensions:
  - ELI5 (小学生也能懂)
  - Core innovations (核心创新点)
  - Test datasets & metrics (测试集与指标)
  - Core weaknesses (核心缺点)
  - Future directions (后期演进方向)

## Three-Layer Wiki

```
wiki/{arxiv_id}/
├── README.md           # Layer 1: full summary + 5 analysis aspects
├── sections/           # Layer 2: per-section Chinese summaries
│   ├── 01_introduction.md
│   ├── 02_method.md
│   └── ...
└── paper.pdf           # Layer 3: original PDF
```

## Install

```bash
pip install paper-wiki
```

### Prerequisites

- [deepxiv](https://pypi.org/project/deepxiv/) CLI installed and configured (`pip install deepxiv`)
- OpenAI-compatible API endpoint

## Quick Start

```bash
# Configure API
export OPENAI_API_KEY=sk-xxx
export OPENAI_BASE_URL=https://api.openai.com/v1
export OPENAI_MODEL=gpt-4o

# Process a paper by arXiv ID
paper-wiki process 2409.05591

# Or by URL
paper-wiki process https://arxiv.org/pdf/2604.27393

# Search and interactively select
paper-wiki search "RAG long context"

# Search and auto-select first result
paper-wiki search "transformer memory" --first

# List processed papers
paper-wiki list
```

## Configuration

Create a `.env` file in your working directory:

```env
OPENAI_API_KEY=sk-xxx
OPENAI_BASE_URL=https://api.openai.com/v1
OPENAI_MODEL=gpt-4o
```

## License

MIT
