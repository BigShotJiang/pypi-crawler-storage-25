"""Wiki generation orchestration: fetch paper, summarize, assemble."""

import re
import os
from pathlib import Path

from rich.progress import Progress, SpinnerColumn, TextColumn

from . import deepxiv_client as dx
from . import llm
from . import prompts


def _slug(name: str) -> str:
    """Convert section name to a file-system friendly slug."""
    # Remove leading numbers like "1. " or "Appendix A "
    s = re.sub(r"^(\d+\.?\s*|Appendix\s+[A-Z]\s*)", "", name)
    s = s.strip().lower()
    s = re.sub(r"[^a-z0-9]+", "_", s)
    return s.strip("_") or "section"


def process_paper(arxiv_id: str, output_dir: str = "wiki", model: str | None = None) -> Path:
    """Full pipeline: fetch paper, summarize sections, generate wiki."""
    paper_dir = Path(output_dir) / arxiv_id
    sections_dir = paper_dir / "sections"
    sections_dir.mkdir(parents=True, exist_ok=True)

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        transient=True,
    ) as progress:
        # 1. Fetch metadata and brief
        t = progress.add_task("Fetching paper metadata...", total=None)
        metadata = dx.get_metadata(arxiv_id)
        brief = dx.get_brief(arxiv_id)
        title = metadata.get("title", arxiv_id)
        raw_authors = metadata.get("authors", [])
        if isinstance(raw_authors, str):
            authors = raw_authors
        elif raw_authors and isinstance(raw_authors[0], dict):
            authors = ", ".join(a["name"] for a in raw_authors)
        else:
            authors = ", ".join(str(a) for a in raw_authors)
        pub_date = metadata.get("publish_at", "")[:10]
        sections_list = metadata.get("sections", [])
        progress.update(t, completed=True)

        # 2. Download PDF
        progress.update(t, description="Downloading PDF...")
        dx.download_pdf(arxiv_id, str(paper_dir / "paper.pdf"))
        progress.update(t, completed=True)

        # 3. Summarize each section
        section_summaries: list[tuple[str, str, str]] = []  # (name, filename, summary)
        for i, sec in enumerate(sections_list, 1):
            sec_name = sec["name"]
            progress.update(t, description=f"Summarizing section: {sec_name}...")
            filename = f"{i:02d}_{_slug(sec_name)}.md"

            content = dx.get_section(arxiv_id, sec_name)
            summary = llm.chat(
                prompts.SECTION_SUMMARY_PROMPT.format(section_name=sec_name, content=content),
                "",
                model=model,
            )

            sec_path = sections_dir / filename
            sec_path.write_text(f"# {sec_name}\n\n{summary}\n", encoding="utf-8")
            section_summaries.append((sec_name, filename, summary))

        progress.update(t, completed=True)

        # 4. Full paper summary from section summaries
        progress.update(t, description="Generating full paper summary...")
        all_sections_text = "\n\n---\n\n".join(
            f"### {name}\n{summary}" for name, _, summary in section_summaries
        )
        full_summary = llm.chat(
            prompts.FULL_SUMMARY_PROMPT.format(title=title, sections=all_sections_text),
            "",
            model=model,
        )
        progress.update(t, completed=True)

        # 5. Five analysis aspects
        aspects = {}
        aspect_defs = [
            ("eli5", "小学生也能懂", prompts.ELI5_PROMPT),
            ("innovations", "核心创新点", prompts.INNOVATIONS_PROMPT),
            ("test_metrics", "测试集与指标", prompts.TEST_METRICS_PROMPT),
            ("weaknesses", "核心缺点", prompts.WEAKNESSES_PROMPT),
            ("future", "后期演进方向", prompts.FUTURE_DIRECTIONS_PROMPT),
        ]
        for key, label, prompt_tmpl in aspect_defs:
            progress.update(t, description=f"Analyzing: {label}...")
            aspects[key] = llm.chat(
                prompt_tmpl.format(title=title, summary=full_summary),
                "",
                model=model,
            )
        progress.update(t, completed=True)

    # 6. Assemble README.md
    section_links = "\n".join(
        f"- [{name}](sections/{fname})" for name, fname, _ in section_summaries
    )

    readme = f"""# {title}

> Authors: {authors} | Published: {pub_date} | arXiv: [{arxiv_id}](https://arxiv.org/abs/{arxiv_id})

## 论文概述

{full_summary}

## 小学生也能懂

{aspects["eli5"]}

## 核心创新点

{aspects["innovations"]}

## 测试集与指标

{aspects["test_metrics"]}

## 核心缺点

{aspects["weaknesses"]}

## 后期演进方向

{aspects["future"]}

---

## 章节详解

{section_links}

## 原文

- [PDF](paper.pdf)
"""

    readme_path = paper_dir / "README.md"
    readme_path.write_text(readme, encoding="utf-8")
    return paper_dir


def list_papers(output_dir: str = "wiki") -> list[dict]:
    """List all processed papers in the wiki directory."""
    wiki = Path(output_dir)
    if not wiki.exists():
        return []
    papers = []
    for d in sorted(wiki.iterdir()):
        readme = d / "README.md"
        if d.is_dir() and readme.exists():
            # Read first line for title
            first_line = readme.read_text(encoding="utf-8").split("\n")[0]
            title = first_line.lstrip("# ").strip()
            papers.append({"id": d.name, "title": title, "path": str(d)})
    return papers
