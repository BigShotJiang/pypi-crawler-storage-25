"""CLI entry point for paper-wiki."""

import re

import click
from rich.console import Console
from rich.table import Table

from . import deepxiv_client as dx
from .wiki import process_paper, list_papers

console = Console()

_ARXIV_ID_RE = re.compile(r"(?:^|/)(\d{4}\.\d{4,5})(?:$|\.pdf|v\d+)")
_ARXIV_URL_RE = re.compile(r"arxiv\.org/(?:abs|pdf)/(\d{4}\.\d{4,5})")


def _extract_arxiv_id(text: str) -> str | None:
    """Extract arXiv ID from raw ID, URL, or return None."""
    text = text.strip()
    # Pure ID like 2604.27393
    if re.fullmatch(r"\d{4}\.\d{4,5}", text):
        return text
    # URL like https://arxiv.org/abs/2604.27393 or .../pdf/2604.27393.pdf
    m = _ARXIV_URL_RE.search(text)
    if m:
        return m.group(1)
    return None


@click.group()
@click.option("--output-dir", default="wiki", envvar="PAPER_WIKI_DIR", help="Wiki output directory")
@click.pass_context
def cli(ctx, output_dir):
    """paper-wiki: Deep paper reading wiki generator."""
    ctx.ensure_object(dict)
    ctx.obj["output_dir"] = output_dir


@cli.command()
@click.argument("arxiv_id")
@click.option("--model", default=None, help="Override LLM model name")
@click.pass_context
def process(ctx, arxiv_id, model):
    """Process an arXiv paper by ID or URL into a wiki page."""
    output_dir = ctx.obj["output_dir"]
    arxiv_id = _extract_arxiv_id(arxiv_id) or arxiv_id
    console.print(f"[bold blue]Processing paper:[/] {arxiv_id}")
    try:
        paper_dir = process_paper(arxiv_id, output_dir=output_dir, model=model)
        console.print(f"[bold green]Done![/] Wiki page: {paper_dir}/README.md")
    except Exception as e:
        console.print(f"[bold red]Error:[/] {e}")
        raise SystemExit(1)


@cli.command()
@click.argument("query")
@click.option("--limit", "-l", default=5, help="Number of search results")
@click.option("--first", is_flag=True, help="Auto-select the first result")
@click.option("--model", default=None, help="Override LLM model name")
@click.pass_context
def search(ctx, query, limit, first, model):
    """Search for papers and process into wiki.

    If QUERY looks like an arXiv ID (e.g. 2604.27393) or arXiv URL,
    skip search and process directly.
    """
    output_dir = ctx.obj["output_dir"]

    # Detect direct arXiv ID / URL
    direct_id = _extract_arxiv_id(query)
    if direct_id:
        console.print(f"[bold blue]Detected arXiv ID:[/] {direct_id}, processing directly...")
        paper_dir = process_paper(direct_id, output_dir=output_dir, model=model)
        console.print(f"[bold green]Done![/] Wiki page: {paper_dir}/README.md")
        return

    console.print(f"[bold blue]Searching:[/] {query}")

    try:
        results = dx.search(query, limit=limit)
    except Exception as e:
        console.print(f"[bold red]Search error:[/] {e}")
        raise SystemExit(1)

    if not results:
        console.print("[yellow]No results found.[/]")
        return

    # Display results
    table = Table(title="Search Results")
    table.add_column("#", style="bold")
    table.add_column("arXiv ID")
    table.add_column("Title")
    table.add_column("Date")

    for i, r in enumerate(results, 1):
        arxiv_id = r.get("arxiv_id", r.get("id", ""))
        title = r.get("title", "")[:60]
        date = r.get("publish_at", "")[:10]
        table.add_row(str(i), arxiv_id, title, date)

    console.print(table)

    if first:
        selected = results[0]
    else:
        choice = click.prompt("Select a paper (#) or press Enter to cancel", default="")
        if not choice:
            return
        try:
            selected = results[int(choice) - 1]
        except (ValueError, IndexError):
            console.print("[red]Invalid selection.[/]")
            return

    arxiv_id = selected.get("arxiv_id", selected.get("id", ""))
    console.print(f"\n[bold blue]Processing:[/] {selected.get('title', arxiv_id)}")
    paper_dir = process_paper(arxiv_id, output_dir=output_dir, model=model)
    console.print(f"[bold green]Done![/] Wiki page: {paper_dir}/README.md")


@cli.command(name="list")
@click.pass_context
def list_cmd(ctx):
    """List all processed papers in the wiki."""
    output_dir = ctx.obj["output_dir"]
    papers = list_papers(output_dir)

    if not papers:
        console.print(f"[yellow]No papers found in {output_dir}/[/]")
        return

    table = Table(title="Processed Papers")
    table.add_column("arXiv ID", style="bold")
    table.add_column("Title")
    table.add_column("Path")

    for p in papers:
        table.add_row(p["id"], p["title"][:60], p["path"])

    console.print(table)
