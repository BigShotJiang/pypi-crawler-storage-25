"""paper-wiki: Deep paper reading wiki generator."""
