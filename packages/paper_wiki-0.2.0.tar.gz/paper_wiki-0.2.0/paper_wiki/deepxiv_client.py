"""Wrapper around the deepxiv CLI for paper search and retrieval."""

import json
import subprocess

import requests


class DeepxivError(Exception):
    """Error from deepxiv CLI."""


def _run(cmd: list[str]) -> str:
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        msg = result.stderr.strip() or f"deepxiv exited with code {result.returncode}"
        raise DeepxivError(f"{' '.join(cmd)}\n{msg}")
    return result.stdout


def search(query: str, limit: int = 10) -> list[dict]:
    """Search papers on arXiv. Returns list of result dicts."""
    out = _run(["deepxiv", "search", query, "-f", "json", "-l", str(limit)])
    data = json.loads(out)
    if isinstance(data, list):
        return data
    return data.get("result", data.get("results", []))


def get_metadata(arxiv_id: str) -> dict:
    """Get paper metadata (title, authors, sections list, etc.)."""
    out = _run(["deepxiv", "paper", arxiv_id, "--head", "-f", "json"])
    return json.loads(out)


def get_brief(arxiv_id: str) -> dict:
    """Get brief info (title, TLDR, keywords, citations, github_url)."""
    out = _run(["deepxiv", "paper", arxiv_id, "--brief", "-f", "json"])
    return json.loads(out)


def get_section(arxiv_id: str, section_name: str) -> str:
    """Get full markdown content of a specific section."""
    return _run(["deepxiv", "paper", arxiv_id, "--section", section_name])


def get_sections_list(arxiv_id: str) -> list[dict]:
    """Extract sections list from paper metadata."""
    meta = get_metadata(arxiv_id)
    return meta.get("sections", [])


def download_pdf(arxiv_id: str, dest_path: str) -> str:
    """Download paper PDF to dest_path. Returns dest_path."""
    meta = get_metadata(arxiv_id)
    url = meta.get("src_url") or f"https://arxiv.org/pdf/{arxiv_id}"
    resp = requests.get(url, timeout=120)
    resp.raise_for_status()
    with open(dest_path, "wb") as f:
        f.write(resp.content)
    return dest_path
