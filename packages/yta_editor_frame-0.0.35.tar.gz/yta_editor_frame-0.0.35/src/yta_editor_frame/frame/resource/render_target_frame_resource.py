from yta_editor_frame.frame.resource.abstract import FrameResourceABC
from yta_editor_frame.frame.resource.types import FrameResourceType
from yta_validation.parameter import ParameterValidator


class RenderTargetFrameResource(
    FrameResourceABC
):
    """
    A frame resource based on a render target.

    The `.frame` attribute is a `RenderTarget`.
    """
    
    @property
    def width(
        self
    ) -> int:
        return self.frame.width
    
    @property
    def height(
        self
    ) -> int:
        return self.frame.height
    
    @property
    def format(
        self
    ) -> str:
        return self.frame.dtype
    
    @property
    def type(
        self
    ) -> FrameResourceType:
        return FrameResourceType.GPU_RENDER_TARGET

    def __init__(
        self,
        frame: 'RenderTarget',
        render_context: 'RenderContext'
    ):
        ParameterValidator.validate_mandatory_instance_of('frame', frame, 'RenderTarget')

        super().__init__(
            frame = frame,
            render_context = render_context
        )

    def release(
        self
    ):
        self.render_context.gpu.texture.release(self.frame)

    # TODO: Untested
    def copy(
        self,
        # TODO: Maybe 'render_context' instead (?)
        opengl_context: 'moderngl.Context'
    ) -> 'RenderTargetFrameResource':
        """
        Get a copy of this frame resource.
        """
        texture_data = self.frame.read()
        copy = opengl_context.texture(
            size = self.frame.size,
            components = self.frame.components,
            dtype = self.frame.dtype,
            data = texture_data
        )

        # TODO: Check 'gpu_frame_resource.py'
        # copy = opengl_context.texture(
        #     size = self.frame.size,
        #     components = self.frame.number_of_components,
        #     dtype = self.frame.dtype,
        # )
        # opengl_context.copy_texture(self.frame.texture, copy)
        
        from yta_editor_pools.render_target import RenderTarget

        return RenderTargetFrameResource(
            RenderTarget(
                context = self.frame.context,
                texture = copy,
                width = self.frame.width,
                height = self.frame.height,
                number_of_components = self.frame.number_of_components,
                dtype = self.frame.dtype
            )
        )
        