"""Demonstrate duplicate tool-call recovery."""

from langchain.tools import tool

from langchain_tool_recover import recover_tool


@tool
def search_docs(query: str) -> str:
    """Search documentation."""
    return f"Results for {query}"


safe_search = recover_tool(search_docs)

print(safe_search.invoke({"query": "foo"}))
print(safe_search.invoke({"query": " foo  "}))
print(safe_search.invoke({"query": "FOO"}))
print(safe_search.invoke({"query": "foo"}))

