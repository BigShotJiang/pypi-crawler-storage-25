"""Basic create_agent usage with ToolRecoverMiddleware."""

from langchain.agents import create_agent
from langchain.tools import tool

from langchain_tool_recover import ToolRecoverMiddleware


@tool
def search_docs(query: str) -> str:
    """Search documentation."""
    return f"Found docs for {query}"


agent = create_agent(
    model="openai:gpt-5.4-mini",
    tools=[search_docs],
    middleware=[ToolRecoverMiddleware()],
)

print(agent.invoke({"messages": [{"role": "user", "content": "Search docs for middleware"}]}))

