"""Public types for structured tool recovery."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class FailureClass(str, Enum):
    TIMEOUT = "timeout"
    RATE_LIMIT = "rate_limit"
    VALIDATION_ERROR = "validation_error"
    AUTH_ERROR = "auth_error"
    EMPTY_RESULT = "empty_result"
    DUPLICATE_CALL = "duplicate_call"
    UNSAFE_COMMAND = "unsafe_command"
    UNKNOWN_ERROR = "unknown_error"


class RecoveryAction(str, Enum):
    RETRY = "retry"
    RETRY_WITH_BACKOFF = "retry_with_backoff"
    RETURN_TO_AGENT = "return_to_agent"
    FAIL_FAST = "fail_fast"
    BLOCK = "block"


@dataclass(frozen=True)
class RecoveryMessage:
    """Structured message returned to the agent or raised for fail-fast paths."""

    status: str
    tool: str
    failure_class: FailureClass
    message: str
    suggestion: str
    action: RecoveryAction
    attempt: int = 1
    details: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "status": self.status,
            "tool": self.tool,
            "failure_class": self.failure_class.value,
            "message": self.message,
            "suggestion": self.suggestion,
            "action": self.action.value,
            "attempt": self.attempt,
        }
        if self.details:
            payload["details"] = self.details
        return payload

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), separators=(",", ":"), ensure_ascii=False)


class ToolRecoverError(RuntimeError):
    """Raised for fail-fast recovery decisions."""

    def __init__(self, recovery: RecoveryMessage) -> None:
        self.recovery = recovery
        super().__init__(recovery.to_json())


class UnsafeCommandError(RuntimeError):
    """Signal that a tool attempted or received an unsafe command."""

