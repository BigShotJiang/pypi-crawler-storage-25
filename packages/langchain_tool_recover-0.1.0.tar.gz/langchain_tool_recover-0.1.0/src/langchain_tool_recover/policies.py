"""Policy decisions for classified tool-call failures."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass

from langchain_tool_recover.types import FailureClass, RecoveryAction


@dataclass(frozen=True)
class PolicyDecision:
    """Action to take for a classified failure."""

    failure_class: FailureClass
    action: RecoveryAction


DEFAULT_POLICIES: dict[FailureClass, RecoveryAction] = {
    FailureClass.TIMEOUT: RecoveryAction.RETRY_WITH_BACKOFF,
    FailureClass.RATE_LIMIT: RecoveryAction.RETRY_WITH_BACKOFF,
    FailureClass.VALIDATION_ERROR: RecoveryAction.RETURN_TO_AGENT,
    FailureClass.AUTH_ERROR: RecoveryAction.FAIL_FAST,
    FailureClass.EMPTY_RESULT: RecoveryAction.RETURN_TO_AGENT,
    FailureClass.DUPLICATE_CALL: RecoveryAction.BLOCK,
    FailureClass.UNSAFE_COMMAND: RecoveryAction.BLOCK,
    FailureClass.UNKNOWN_ERROR: RecoveryAction.FAIL_FAST,
}


class RecoveryPolicy:
    """Resolve recovery actions with optional user overrides."""

    def __init__(
        self,
        overrides: Mapping[FailureClass | str, RecoveryAction | str | PolicyDecision] | None = None,
    ) -> None:
        self._actions = dict(DEFAULT_POLICIES)
        if overrides:
            for key, value in overrides.items():
                failure_class = key if isinstance(key, FailureClass) else FailureClass(str(key))
                if isinstance(value, PolicyDecision):
                    action = value.action
                else:
                    action = (
                        value
                        if isinstance(value, RecoveryAction)
                        else RecoveryAction(str(value))
                    )
                self._actions[failure_class] = action

    def decide(self, failure_class: FailureClass) -> PolicyDecision:
        return PolicyDecision(
            failure_class=failure_class,
            action=self._actions.get(failure_class, RecoveryAction.FAIL_FAST),
        )
