"""Small logging helper for developer-visible recovery events."""

from __future__ import annotations

import logging
from typing import Any

LOGGER_NAME = "tool-recover"


def get_logger(enable_logging: bool = True) -> logging.Logger:
    """Return the package logger, installing a concise handler on first use."""

    logger = logging.getLogger(LOGGER_NAME)
    if not logger.handlers:
        handler = logging.StreamHandler()
        handler.setFormatter(logging.Formatter("[tool-recover] %(message)s"))
        logger.addHandler(handler)
        logger.propagate = False
    logger.setLevel(logging.INFO if enable_logging else logging.CRITICAL + 1)
    return logger


def log_event(
    logger: logging.Logger,
    tool: str,
    *,
    attempt: int | None = None,
    status: str | None = None,
    suggestion: str | None = None,
    action: str | None = None,
    extra: dict[str, Any] | None = None,
) -> None:
    """Emit the compact log lines promised by the README."""

    parts = [tool]
    if attempt is not None:
        parts.append(f"attempt={attempt}")
    if status is not None:
        parts.append(f"status={status}")
    if extra:
        parts.extend(f"{key}={value}" for key, value in extra.items())
    logger.info(" ".join(parts))
    if suggestion:
        logger.info("suggestion=%s", suggestion)
    if action:
        logger.info("action=%s", action)

