"""LangChain `create_agent` middleware integration."""

from __future__ import annotations

import asyncio
import time
from collections.abc import Awaitable, Callable, Mapping
from contextlib import suppress
from typing import Any

from langchain_core.messages import ToolMessage

try:  # Importing langchain is intentionally isolated for clearer install errors.
    from langchain.agents.middleware import AgentMiddleware
except Exception:  # pragma: no cover - exercised only when dependency is absent
    AgentMiddleware = object  # type: ignore[assignment,misc]

from langchain_tool_recover.classifier import classify_exception, classify_result
from langchain_tool_recover.logging import get_logger, log_event
from langchain_tool_recover.loop_detector import LoopDetector
from langchain_tool_recover.policies import PolicyDecision, RecoveryPolicy
from langchain_tool_recover.recovery import build_recovery_message, recovery_tool_message
from langchain_tool_recover.types import (
    FailureClass,
    RecoveryAction,
    ToolRecoverError,
)


class ToolRecoverMiddleware(AgentMiddleware):  # type: ignore[misc,valid-type]
    """Middleware that adds structured recovery UX around LangChain tool calls."""

    def __init__(
        self,
        max_duplicate_calls: int = 2,
        max_attempts: int = 3,
        enable_logging: bool = True,
        policies: Mapping[FailureClass | str, RecoveryAction | str | PolicyDecision] | None = None,
    ) -> None:
        with suppress(TypeError):
            super().__init__()
        self.max_duplicate_calls = max_duplicate_calls
        self.max_attempts = max(1, max_attempts)
        self.policy = RecoveryPolicy(policies)
        self.loop_detector = LoopDetector()
        self.logger = get_logger(enable_logging)

    def wrap_tool_call(
        self,
        request: Any,
        handler: Callable[[Any], ToolMessage | Any],
    ) -> ToolMessage | Any:
        tool_name = _tool_name(request)
        tool_call_id = _tool_call_id(request)
        duplicate = self.loop_detector.record(
            tool_name,
            _tool_args(request),
            run_id=_run_id(request),
        )

        if duplicate.duplicate_number == 1:
            log_event(
                self.logger,
                tool_name,
                status=FailureClass.DUPLICATE_CALL.value,
                action="warning_duplicate_call",
            )
        elif duplicate.duplicate_number == self.max_duplicate_calls:
            recovery = build_recovery_message(
                tool=tool_name,
                failure_class=FailureClass.DUPLICATE_CALL,
                decision=PolicyDecision(
                    FailureClass.DUPLICATE_CALL,
                    RecoveryAction.RETURN_TO_AGENT,
                ),
                attempt=duplicate.count,
                details=_duplicate_details(duplicate),
            )
            log_event(
                self.logger,
                tool_name,
                attempt=duplicate.count,
                status=recovery.failure_class.value,
                suggestion=recovery.suggestion,
                action="returned_recovery_message",
            )
            return recovery_tool_message(recovery, tool_call_id=tool_call_id)
        elif duplicate.duplicate_number > self.max_duplicate_calls:
            decision = self.policy.decide(FailureClass.DUPLICATE_CALL)
            recovery = build_recovery_message(
                tool=tool_name,
                failure_class=FailureClass.DUPLICATE_CALL,
                decision=decision,
                attempt=duplicate.count,
                status="blocked",
                details=_duplicate_details(duplicate),
            )
            log_event(
                self.logger,
                tool_name,
                attempt=duplicate.count,
                status=recovery.failure_class.value,
                suggestion=recovery.suggestion,
                action="blocked_duplicate_call",
            )
            return recovery_tool_message(recovery, tool_call_id=tool_call_id)

        return self._execute_with_recovery(request, handler)

    async def awrap_tool_call(
        self,
        request: Any,
        handler: Callable[[Any], Awaitable[ToolMessage | Any]],
    ) -> ToolMessage | Any:
        tool_name = _tool_name(request)
        tool_call_id = _tool_call_id(request)
        duplicate = self.loop_detector.record(
            tool_name,
            _tool_args(request),
            run_id=_run_id(request),
        )

        if duplicate.duplicate_number == 1:
            log_event(
                self.logger,
                tool_name,
                status=FailureClass.DUPLICATE_CALL.value,
                action="warning_duplicate_call",
            )
        elif duplicate.duplicate_number == self.max_duplicate_calls:
            recovery = build_recovery_message(
                tool=tool_name,
                failure_class=FailureClass.DUPLICATE_CALL,
                decision=PolicyDecision(
                    FailureClass.DUPLICATE_CALL,
                    RecoveryAction.RETURN_TO_AGENT,
                ),
                attempt=duplicate.count,
                details=_duplicate_details(duplicate),
            )
            log_event(
                self.logger,
                tool_name,
                attempt=duplicate.count,
                status=recovery.failure_class.value,
                suggestion=recovery.suggestion,
                action="returned_recovery_message",
            )
            return recovery_tool_message(recovery, tool_call_id=tool_call_id)
        elif duplicate.duplicate_number > self.max_duplicate_calls:
            decision = self.policy.decide(FailureClass.DUPLICATE_CALL)
            recovery = build_recovery_message(
                tool=tool_name,
                failure_class=FailureClass.DUPLICATE_CALL,
                decision=decision,
                attempt=duplicate.count,
                status="blocked",
                details=_duplicate_details(duplicate),
            )
            log_event(
                self.logger,
                tool_name,
                attempt=duplicate.count,
                status=recovery.failure_class.value,
                suggestion=recovery.suggestion,
                action="blocked_duplicate_call",
            )
            return recovery_tool_message(recovery, tool_call_id=tool_call_id)

        return await self._aexecute_with_recovery(request, handler)

    def after_agent(self, state: Any, runtime: Any) -> None:
        self.loop_detector.reset_run(_runtime_run_id(runtime))
        return None

    def _execute_with_recovery(
        self,
        request: Any,
        handler: Callable[[Any], ToolMessage | Any],
    ) -> ToolMessage | Any:
        tool_name = _tool_name(request)
        tool_call_id = _tool_call_id(request)
        last_failure: FailureClass | None = None

        for attempt in range(1, self.max_attempts + 1):
            try:
                result = handler(request)
            except Exception as exc:
                failure_class = classify_exception(exc)
                last_failure = failure_class
                decision = self.policy.decide(failure_class)
                if _should_retry(decision.action) and attempt < self.max_attempts:
                    log_event(
                        self.logger,
                        tool_name,
                        attempt=attempt,
                        status=failure_class.value,
                        action="retrying",
                    )
                    time.sleep(_backoff_seconds(failure_class, attempt))
                    continue
                return self._handle_failure(
                    tool_name,
                    tool_call_id,
                    failure_class,
                    decision,
                    attempt,
                    details={"error": str(exc)},
                )

            failure_class = classify_result(result)
            if failure_class is None:
                return result
            last_failure = failure_class
            decision = self.policy.decide(failure_class)
            return self._handle_failure(tool_name, tool_call_id, failure_class, decision, attempt)

        failure_class = last_failure or FailureClass.UNKNOWN_ERROR
        decision = self.policy.decide(failure_class)
        return self._handle_failure(
            tool_name,
            tool_call_id,
            failure_class,
            decision,
            self.max_attempts,
        )

    async def _aexecute_with_recovery(
        self,
        request: Any,
        handler: Callable[[Any], Awaitable[ToolMessage | Any]],
    ) -> ToolMessage | Any:
        tool_name = _tool_name(request)
        tool_call_id = _tool_call_id(request)
        last_failure: FailureClass | None = None

        for attempt in range(1, self.max_attempts + 1):
            try:
                result = await handler(request)
            except Exception as exc:
                failure_class = classify_exception(exc)
                last_failure = failure_class
                decision = self.policy.decide(failure_class)
                if _should_retry(decision.action) and attempt < self.max_attempts:
                    log_event(
                        self.logger,
                        tool_name,
                        attempt=attempt,
                        status=failure_class.value,
                        action="retrying",
                    )
                    await asyncio.sleep(_backoff_seconds(failure_class, attempt))
                    continue
                return self._handle_failure(
                    tool_name,
                    tool_call_id,
                    failure_class,
                    decision,
                    attempt,
                    details={"error": str(exc)},
                )

            failure_class = classify_result(result)
            if failure_class is None:
                return result
            last_failure = failure_class
            decision = self.policy.decide(failure_class)
            return self._handle_failure(tool_name, tool_call_id, failure_class, decision, attempt)

        failure_class = last_failure or FailureClass.UNKNOWN_ERROR
        decision = self.policy.decide(failure_class)
        return self._handle_failure(
            tool_name,
            tool_call_id,
            failure_class,
            decision,
            self.max_attempts,
        )

    def _handle_failure(
        self,
        tool_name: str,
        tool_call_id: str,
        failure_class: FailureClass,
        decision: PolicyDecision,
        attempt: int,
        *,
        details: dict[str, Any] | None = None,
    ) -> ToolMessage:
        recovery = build_recovery_message(
            tool=tool_name,
            failure_class=failure_class,
            decision=decision,
            attempt=attempt,
            details=details,
        )
        log_event(
            self.logger,
            tool_name,
            attempt=attempt,
            status=failure_class.value,
            suggestion=recovery.suggestion,
            action=(
                "returned_recovery_message"
                if decision.action != RecoveryAction.FAIL_FAST
                else "fail_fast"
            ),
        )
        if decision.action == RecoveryAction.FAIL_FAST:
            raise ToolRecoverError(recovery)
        return recovery_tool_message(recovery, tool_call_id=tool_call_id)


def _should_retry(action: RecoveryAction) -> bool:
    return action in {RecoveryAction.RETRY, RecoveryAction.RETRY_WITH_BACKOFF}


def _duplicate_details(duplicate: Any) -> dict[str, Any]:
    return {
        "fingerprint": duplicate.fingerprint,
        "duplicate_number": duplicate.duplicate_number,
    }


def _backoff_seconds(failure_class: FailureClass, attempt: int) -> float:
    base = 1.0 if failure_class == FailureClass.TIMEOUT else 2.0
    return min(8.0, base * (2 ** (attempt - 1)))


def _tool_name(request: Any) -> str:
    return str(getattr(request, "tool_call", {}).get("name", "unknown_tool"))


def _tool_call_id(request: Any) -> str:
    return str(getattr(request, "tool_call", {}).get("id", "tool-recover"))


def _tool_args(request: Any) -> Any:
    return getattr(request, "tool_call", {}).get("args", {})


def _run_id(request: Any) -> str:
    return _runtime_run_id(getattr(request, "runtime", None))


def _runtime_run_id(runtime: Any) -> str:
    execution_info = getattr(runtime, "execution_info", None)
    run_id = getattr(execution_info, "run_id", None)
    if run_id:
        return str(run_id)
    return "default"
