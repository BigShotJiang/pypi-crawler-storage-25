"""Shared recovery helpers used by middleware and wrappers."""

from __future__ import annotations

from typing import Any

from langchain_core.messages import ToolMessage

from langchain_tool_recover.policies import PolicyDecision
from langchain_tool_recover.types import FailureClass, RecoveryAction, RecoveryMessage

_MESSAGES: dict[FailureClass, tuple[str, str, str]] = {
    FailureClass.TIMEOUT: (
        "failed",
        "The tool timed out.",
        "Try again with a narrower request or use a different tool.",
    ),
    FailureClass.RATE_LIMIT: (
        "failed",
        "The tool was rate limited.",
        "Wait before retrying or use a less expensive query.",
    ),
    FailureClass.VALIDATION_ERROR: (
        "needs_correction",
        "The tool arguments failed validation.",
        "Correct the tool arguments before calling it again.",
    ),
    FailureClass.AUTH_ERROR: (
        "failed",
        "The tool failed authentication or authorization.",
        "Check credentials, permissions, or API key configuration.",
    ),
    FailureClass.EMPTY_RESULT: (
        "needs_replan",
        "The tool returned no results.",
        "Try broadening the query or removing exact-match terms.",
    ),
    FailureClass.DUPLICATE_CALL: (
        "needs_replan",
        "The same tool call was repeated.",
        "Rephrase the query or try a different tool.",
    ),
    FailureClass.UNSAFE_COMMAND: (
        "blocked",
        "The tool call was blocked because it was classified as unsafe.",
        "Use a safer command or ask for approval before retrying.",
    ),
    FailureClass.UNKNOWN_ERROR: (
        "failed",
        "The tool failed with an unknown error.",
        "Inspect the tool error and decide whether a different approach is needed.",
    ),
}


def build_recovery_message(
    *,
    tool: str,
    failure_class: FailureClass,
    decision: PolicyDecision,
    attempt: int,
    status: str | None = None,
    message: str | None = None,
    suggestion: str | None = None,
    details: dict[str, Any] | None = None,
) -> RecoveryMessage:
    default_status, default_message, default_suggestion = _MESSAGES[failure_class]
    return RecoveryMessage(
        status=status or _status_for_action(decision.action, default_status),
        tool=tool,
        failure_class=failure_class,
        message=message or default_message,
        suggestion=suggestion or default_suggestion,
        action=decision.action,
        attempt=attempt,
        details=details or {},
    )


def recovery_tool_message(
    recovery: RecoveryMessage,
    *,
    tool_call_id: str | None = None,
) -> ToolMessage:
    return ToolMessage(
        content=recovery.to_json(),
        name=recovery.tool,
        tool_call_id=tool_call_id or "tool-recover",
        status="error" if recovery.status in {"failed", "blocked"} else "success",
    )


def recovery_dict(recovery: RecoveryMessage) -> dict[str, Any]:
    return recovery.to_dict()


def _status_for_action(action: RecoveryAction, default: str) -> str:
    if action == RecoveryAction.BLOCK:
        return "blocked"
    if action == RecoveryAction.FAIL_FAST:
        return "failed"
    return default
