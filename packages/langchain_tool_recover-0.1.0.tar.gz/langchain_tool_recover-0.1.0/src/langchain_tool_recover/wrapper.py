"""Single-tool wrapper helper."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from langchain_core.tools import BaseTool
from pydantic import ConfigDict

from langchain_tool_recover.classifier import classify_exception, classify_result
from langchain_tool_recover.logging import get_logger, log_event
from langchain_tool_recover.loop_detector import LoopDetector
from langchain_tool_recover.policies import PolicyDecision, RecoveryPolicy
from langchain_tool_recover.recovery import build_recovery_message, recovery_dict
from langchain_tool_recover.types import (
    FailureClass,
    RecoveryAction,
    ToolRecoverError,
)

PolicyInput = (
    Mapping[FailureClass | str, RecoveryAction | str | PolicyDecision]
    | RecoveryPolicy
    | None
)


def recover_tool(
    tool: BaseTool,
    policy: PolicyInput = None,
    enable_logging: bool = True,
) -> BaseTool:
    """Wrap a single LangChain tool with recovery behavior."""

    recovery_policy = policy if isinstance(policy, RecoveryPolicy) else RecoveryPolicy(policy)
    return RecoveredTool(
        name=tool.name,
        description=tool.description,
        args_schema=tool.args_schema,
        return_direct=tool.return_direct,
        response_format=tool.response_format,
        wrapped_tool=tool,
        policy=recovery_policy,
        detector=LoopDetector(),
        enable_recovery_logging=enable_logging,
    )


class RecoveredTool(BaseTool):
    """A `BaseTool` that delegates to another tool with recovery handling."""

    model_config = ConfigDict(arbitrary_types_allowed=True)

    wrapped_tool: BaseTool
    policy: RecoveryPolicy
    detector: LoopDetector
    enable_recovery_logging: bool = True

    def _run(self, *args: Any, **kwargs: Any) -> Any:
        tool_input = _tool_input(args, kwargs)
        return self._invoke_with_recovery(tool_input)

    async def _arun(self, *args: Any, **kwargs: Any) -> Any:
        tool_input = _tool_input(args, kwargs)
        return await self._ainvoke_with_recovery(tool_input)

    def _invoke_with_recovery(self, tool_input: Any) -> Any:
        logger = get_logger(self.enable_recovery_logging)
        duplicate = self.detector.record(self.name, tool_input)
        if duplicate.duplicate_number == 1:
            log_event(
                logger,
                self.name,
                status=FailureClass.DUPLICATE_CALL.value,
                action="warning_duplicate_call",
            )
        elif duplicate.duplicate_number == 2:
            decision = PolicyDecision(FailureClass.DUPLICATE_CALL, RecoveryAction.RETURN_TO_AGENT)
            recovery = build_recovery_message(
                tool=self.name,
                failure_class=FailureClass.DUPLICATE_CALL,
                decision=decision,
                attempt=duplicate.count,
            )
            log_event(
                logger,
                self.name,
                attempt=duplicate.count,
                status=recovery.failure_class.value,
                suggestion=recovery.suggestion,
                action="returned_recovery_message",
            )
            return recovery_dict(recovery)
        elif duplicate.duplicate_number > 2:
            decision = self.policy.decide(FailureClass.DUPLICATE_CALL)
            recovery = build_recovery_message(
                tool=self.name,
                failure_class=FailureClass.DUPLICATE_CALL,
                decision=decision,
                attempt=duplicate.count,
                status="blocked",
            )
            log_event(
                logger,
                self.name,
                attempt=duplicate.count,
                status=recovery.failure_class.value,
                suggestion=recovery.suggestion,
                action="blocked_duplicate_call",
            )
            return recovery_dict(recovery)

        try:
            result = self.wrapped_tool.invoke(tool_input)
        except Exception as exc:
            return self._handle_failure(classify_exception(exc), 1, {"error": str(exc)})

        failure_class = classify_result(result)
        if failure_class is None:
            return result
        return self._handle_failure(failure_class, 1)

    async def _ainvoke_with_recovery(self, tool_input: Any) -> Any:
        logger = get_logger(self.enable_recovery_logging)
        duplicate = self.detector.record(self.name, tool_input)
        if duplicate.duplicate_number == 1:
            log_event(
                logger,
                self.name,
                status=FailureClass.DUPLICATE_CALL.value,
                action="warning_duplicate_call",
            )
        elif duplicate.duplicate_number == 2:
            decision = PolicyDecision(FailureClass.DUPLICATE_CALL, RecoveryAction.RETURN_TO_AGENT)
            recovery = build_recovery_message(
                tool=self.name,
                failure_class=FailureClass.DUPLICATE_CALL,
                decision=decision,
                attempt=duplicate.count,
            )
            log_event(
                logger,
                self.name,
                attempt=duplicate.count,
                status=recovery.failure_class.value,
                suggestion=recovery.suggestion,
                action="returned_recovery_message",
            )
            return recovery_dict(recovery)
        elif duplicate.duplicate_number > 2:
            decision = self.policy.decide(FailureClass.DUPLICATE_CALL)
            recovery = build_recovery_message(
                tool=self.name,
                failure_class=FailureClass.DUPLICATE_CALL,
                decision=decision,
                attempt=duplicate.count,
                status="blocked",
            )
            log_event(
                logger,
                self.name,
                attempt=duplicate.count,
                status=recovery.failure_class.value,
                suggestion=recovery.suggestion,
                action="blocked_duplicate_call",
            )
            return recovery_dict(recovery)

        try:
            result = await self.wrapped_tool.ainvoke(tool_input)
        except Exception as exc:
            return self._handle_failure(classify_exception(exc), 1, {"error": str(exc)})

        failure_class = classify_result(result)
        if failure_class is None:
            return result
        return self._handle_failure(failure_class, 1)

    def _handle_failure(
        self,
        failure_class: FailureClass,
        attempt: int,
        details: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        decision = self.policy.decide(failure_class)
        recovery = build_recovery_message(
            tool=self.name,
            failure_class=failure_class,
            decision=decision,
            attempt=attempt,
            details=details,
        )
        log_event(
            get_logger(self.enable_recovery_logging),
            self.name,
            attempt=attempt,
            status=failure_class.value,
            suggestion=recovery.suggestion,
            action=(
                "returned_recovery_message"
                if decision.action != RecoveryAction.FAIL_FAST
                else "fail_fast"
            ),
        )
        if decision.action == RecoveryAction.FAIL_FAST:
            raise ToolRecoverError(recovery)
        return recovery_dict(recovery)


def _tool_input(args: tuple[Any, ...], kwargs: dict[str, Any]) -> Any:
    if args and kwargs:
        return {"args": list(args), **kwargs}
    if len(args) == 1 and not kwargs:
        return args[0]
    if args:
        return list(args)
    return kwargs
