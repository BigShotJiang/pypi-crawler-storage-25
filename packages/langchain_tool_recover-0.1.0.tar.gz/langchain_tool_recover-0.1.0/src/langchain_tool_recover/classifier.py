"""Deterministic failure classification for LangChain tool calls."""

from __future__ import annotations

import asyncio
import concurrent.futures
import json
from collections.abc import Mapping, Sequence
from typing import Any

from langchain_core.messages import ToolMessage
from pydantic import ValidationError

try:  # pragma: no cover - pydantic v1 compatibility path
    from pydantic.v1 import ValidationError as PydanticV1ValidationError
except Exception:  # pragma: no cover
    PydanticV1ValidationError = ValidationError

from langchain_tool_recover.types import FailureClass, UnsafeCommandError


def classify_exception(exc: BaseException) -> FailureClass:
    """Classify an exception into a small, deterministic failure taxonomy."""

    if isinstance(exc, UnsafeCommandError):
        return FailureClass.UNSAFE_COMMAND

    if isinstance(exc, (TimeoutError, asyncio.TimeoutError, concurrent.futures.TimeoutError)):
        return FailureClass.TIMEOUT

    if isinstance(exc, (ValidationError, PydanticV1ValidationError)):
        return FailureClass.VALIDATION_ERROR

    if isinstance(exc, PermissionError):
        return FailureClass.AUTH_ERROR

    cls_name = type(exc).__name__.lower()
    message = str(exc).lower()
    haystack = f"{cls_name} {message}"

    if "unsafe" in haystack and "command" in haystack:
        return FailureClass.UNSAFE_COMMAND
    if "timeout" in haystack or "timed out" in haystack:
        return FailureClass.TIMEOUT
    if (
        "ratelimit" in haystack
        or "rate_limit" in haystack
        or "rate limit" in haystack
        or "too many requests" in haystack
        or " 429" in f" {haystack}"
        or "quota" in haystack
    ):
        return FailureClass.RATE_LIMIT
    if (
        "validation" in haystack
        or "toolinvocationerror" in haystack
        or "field required" in haystack
        or "missing field" in haystack
        or "invalid input" in haystack
        or "invalid arguments" in haystack
    ):
        return FailureClass.VALIDATION_ERROR
    if (
        "authentication" in haystack
        or "unauthorized" in haystack
        or "forbidden" in haystack
        or "permission denied" in haystack
        or "api key" in haystack
        or " 401" in f" {haystack}"
        or " 403" in f" {haystack}"
    ):
        return FailureClass.AUTH_ERROR

    return FailureClass.UNKNOWN_ERROR


def classify_result(result: Any) -> FailureClass | None:
    """Classify low-quality successful tool output, returning None when OK."""

    if isinstance(result, ToolMessage):
        if result.status == "error":
            return _classify_error_message(result.content)
        result = result.content

    if _is_empty_result(result):
        return FailureClass.EMPTY_RESULT

    return None


def _classify_error_message(content: Any) -> FailureClass:
    if isinstance(content, str):
        parsed = _maybe_json(content)
        if parsed is not content and isinstance(parsed, Mapping):
            failure_class = parsed.get("failure_class") or parsed.get("error")
            if failure_class:
                try:
                    return FailureClass(str(failure_class))
                except ValueError:
                    pass
        message = content.lower()
    else:
        message = str(content).lower()

    if "timeout" in message or "timed out" in message:
        return FailureClass.TIMEOUT
    if "rate limit" in message or "too many requests" in message or "429" in message:
        return FailureClass.RATE_LIMIT
    if "validation" in message or "invalid" in message or "field required" in message:
        return FailureClass.VALIDATION_ERROR
    if "auth" in message or "unauthorized" in message or "forbidden" in message or "401" in message:
        return FailureClass.AUTH_ERROR
    if "unsafe" in message and "command" in message:
        return FailureClass.UNSAFE_COMMAND
    return FailureClass.UNKNOWN_ERROR


def _is_empty_result(value: Any) -> bool:
    if value is None:
        return True

    if isinstance(value, str):
        stripped = value.strip()
        if not stripped:
            return True
        parsed = _maybe_json(stripped)
        if parsed is not value and parsed is not stripped:
            return _is_empty_result(parsed)
        return False

    if isinstance(value, Mapping):
        if not value:
            return True
        explicit_empty = value.get("empty")
        if explicit_empty is True:
            return True
        if "results" in value and _is_empty_collection(value["results"]):
            return True
        if "items" in value and _is_empty_collection(value["items"]):
            return True
        return "data" in value and _is_empty_collection(value["data"])

    return bool(_is_empty_collection(value))


def _is_empty_collection(value: Any) -> bool:
    if isinstance(value, (str, bytes, bytearray)):
        return False
    if isinstance(value, Mapping):
        return len(value) == 0
    if isinstance(value, Sequence):
        return len(value) == 0
    if isinstance(value, (set, frozenset)):
        return len(value) == 0
    return False


def _maybe_json(value: str) -> Any:
    if not value or value[0] not in "[{":
        return value
    try:
        return json.loads(value)
    except json.JSONDecodeError:
        return value
