"""Run-scoped duplicate tool-call detection."""

from __future__ import annotations

import json
import re
import threading
from collections import defaultdict
from dataclasses import dataclass
from typing import Any

_WHITESPACE = re.compile(r"\s+")


@dataclass(frozen=True)
class DuplicateCheck:
    """Result from recording a tool call fingerprint."""

    fingerprint: str
    count: int

    @property
    def duplicate_number(self) -> int:
        """Number of repeats after the original call."""

        return max(0, self.count - 1)

    @property
    def is_duplicate(self) -> bool:
        return self.count > 1


class LoopDetector:
    """Detect repeated calls to the same tool with the same normalized arguments."""

    def __init__(self) -> None:
        self._runs: dict[str, dict[str, int]] = defaultdict(dict)
        self._lock = threading.RLock()

    def record(self, tool_name: str, args: Any, *, run_id: str = "default") -> DuplicateCheck:
        fingerprint = fingerprint_tool_call(tool_name, args)
        with self._lock:
            counts = self._runs[run_id]
            counts[fingerprint] = counts.get(fingerprint, 0) + 1
            return DuplicateCheck(fingerprint=fingerprint, count=counts[fingerprint])

    def reset_run(self, run_id: str = "default") -> None:
        with self._lock:
            self._runs.pop(run_id, None)

    def reset(self) -> None:
        with self._lock:
            self._runs.clear()


def fingerprint_tool_call(tool_name: str, args: Any) -> str:
    """Return a stable fingerprint for a tool call."""

    canonical = _normalize(args)
    encoded = json.dumps(canonical, sort_keys=True, separators=(",", ":"), ensure_ascii=True)
    return f"{tool_name}:{encoded}"


def _normalize(value: Any) -> Any:
    if isinstance(value, str):
        return _WHITESPACE.sub(" ", value.strip()).casefold()
    if isinstance(value, dict):
        sorted_items = sorted(value.items(), key=lambda item: str(item[0]))
        return {str(key): _normalize(val) for key, val in sorted_items}
    if isinstance(value, (list, tuple)):
        return [_normalize(item) for item in value]
    if isinstance(value, (set, frozenset)):
        return sorted(_normalize(item) for item in value)
    return value
