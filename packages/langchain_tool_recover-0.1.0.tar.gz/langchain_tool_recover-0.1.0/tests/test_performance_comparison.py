from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any

import langchain.agents.middleware.tool_retry as langchain_tool_retry
from langchain.agents.middleware import ToolRetryMiddleware
from langchain_core.messages import ToolMessage

from langchain_tool_recover import FailureClass, ToolRecoverMiddleware


@dataclass
class FakeExecutionInfo:
    run_id: str


@dataclass
class FakeRuntime:
    execution_info: FakeExecutionInfo


@dataclass
class FakeRequest:
    tool_call: dict[str, Any]
    runtime: FakeRuntime
    tool: Any | None = None


def request(query: str = "foo", *, run_id: str = "run_1") -> FakeRequest:
    return FakeRequest(
        tool_call={
            "name": "search_docs",
            "args": {"query": query},
            "id": f"call_{run_id}_{query}",
        },
        runtime=FakeRuntime(FakeExecutionInfo(run_id)),
    )


def payload(message: ToolMessage) -> dict[str, Any]:
    return json.loads(str(message.content))


def test_validation_recovery_saves_retry_attempts_and_backoff_delay(monkeypatch: Any) -> None:
    """LangChain's default broad retry repeats bad args; tool-recover returns feedback."""

    langchain_delays: list[float] = []
    monkeypatch.setattr(
        langchain_tool_retry.time,
        "sleep",
        lambda delay: langchain_delays.append(delay),
    )

    langchain_attempts = 0

    def invalid_langchain_handler(_: Any) -> ToolMessage:
        nonlocal langchain_attempts
        langchain_attempts += 1
        raise ValueError("invalid input: query must be a string")

    langchain_retry = ToolRetryMiddleware(
        max_retries=2,
        initial_delay=1.0,
        backoff_factor=2.0,
        jitter=False,
    )
    langchain_retry.wrap_tool_call(request("bad", run_id="langchain"), invalid_langchain_handler)

    recover_attempts = 0

    def invalid_recover_handler(_: Any) -> ToolMessage:
        nonlocal recover_attempts
        recover_attempts += 1
        raise ValueError("invalid input: query must be a string")

    recover = ToolRecoverMiddleware(enable_logging=False, max_attempts=3)
    recovery = recover.wrap_tool_call(request("bad", run_id="recover"), invalid_recover_handler)

    assert langchain_attempts == 3
    assert langchain_delays == [1.0, 2.0]
    assert recover_attempts == 1
    assert payload(recovery)["failure_class"] == FailureClass.VALIDATION_ERROR.value


def test_scoped_langchain_retry_avoids_validation_retry_but_returns_plain_error() -> None:
    """A fair scoped LangChain retry can avoid wasted attempts, but not structured recovery UX."""

    langchain_attempts = 0

    def invalid_langchain_handler(_: Any) -> ToolMessage:
        nonlocal langchain_attempts
        langchain_attempts += 1
        raise ValueError("invalid input: query must be a string")

    langchain_retry = ToolRetryMiddleware(
        max_retries=2,
        retry_on=(TimeoutError,),
        jitter=False,
    )
    langchain_result = langchain_retry.wrap_tool_call(
        request("bad", run_id="langchain_scoped"),
        invalid_langchain_handler,
    )

    recover_attempts = 0

    def invalid_recover_handler(_: Any) -> ToolMessage:
        nonlocal recover_attempts
        recover_attempts += 1
        raise ValueError("invalid input: query must be a string")

    recover = ToolRecoverMiddleware(enable_logging=False, max_attempts=3)
    recover_result = recover.wrap_tool_call(
        request("bad", run_id="recover_structured"),
        invalid_recover_handler,
    )

    assert langchain_attempts == 1
    assert "Tool 'search_docs' failed after 1 attempt" in str(langchain_result.content)
    assert recover_attempts == 1
    assert payload(recover_result)["failure_class"] == FailureClass.VALIDATION_ERROR.value


def test_transient_timeout_does_not_create_false_performance_claim(monkeypatch: Any) -> None:
    """Both middlewares should retry transient timeouts and succeed with the same attempts."""

    langchain_delays: list[float] = []
    monkeypatch.setattr(
        langchain_tool_retry.time,
        "sleep",
        lambda delay: langchain_delays.append(delay),
    )
    langchain_attempts = 0

    def flaky_langchain_handler(_: Any) -> ToolMessage:
        nonlocal langchain_attempts
        langchain_attempts += 1
        if langchain_attempts < 3:
            raise TimeoutError("timed out")
        return ToolMessage(content="ok", tool_call_id="call_1")

    langchain_retry = ToolRetryMiddleware(
        max_retries=2,
        initial_delay=1.0,
        backoff_factor=2.0,
        jitter=False,
    )
    langchain_result = langchain_retry.wrap_tool_call(
        request("timeout", run_id="langchain_timeout"),
        flaky_langchain_handler,
    )

    recover_delays: list[float] = []
    monkeypatch.setattr(
        "langchain_tool_recover.middleware.time.sleep",
        lambda delay: recover_delays.append(delay),
    )
    recover_attempts = 0

    def flaky_recover_handler(_: Any) -> ToolMessage:
        nonlocal recover_attempts
        recover_attempts += 1
        if recover_attempts < 3:
            raise TimeoutError("timed out")
        return ToolMessage(content="ok", tool_call_id="call_1")

    recover = ToolRecoverMiddleware(enable_logging=False, max_attempts=3)
    recover_result = recover.wrap_tool_call(
        request("timeout", run_id="recover_timeout"),
        flaky_recover_handler,
    )

    assert langchain_result.content == "ok"
    assert recover_result.content == "ok"
    assert langchain_attempts == recover_attempts == 3
    assert langchain_delays == recover_delays == [1.0, 2.0]


def test_duplicate_loop_detection_skips_redundant_successful_tool_calls() -> None:
    """Successful duplicate calls are invisible to generic retry but blocked by tool-recover."""

    repeated_queries = ["foo", " foo ", "FOO", "foo"]
    langchain_calls = 0

    def langchain_handler(_: Any) -> ToolMessage:
        nonlocal langchain_calls
        langchain_calls += 1
        return ToolMessage(content="ok", tool_call_id="call_1")

    langchain_retry = ToolRetryMiddleware(max_retries=2)
    for query in repeated_queries:
        langchain_retry.wrap_tool_call(request(query, run_id="langchain"), langchain_handler)

    recover_calls = 0

    def recover_handler(_: Any) -> ToolMessage:
        nonlocal recover_calls
        recover_calls += 1
        return ToolMessage(content="ok", tool_call_id="call_1")

    recover = ToolRecoverMiddleware(enable_logging=False)
    recover_results = [
        recover.wrap_tool_call(request(query, run_id="recover"), recover_handler)
        for query in repeated_queries
    ]

    assert langchain_calls == 4
    assert recover_calls == 2
    assert payload(recover_results[2])["status"] == "needs_replan"
    assert payload(recover_results[3])["status"] == "blocked"


def test_duplicate_detection_does_not_block_distinct_arguments_or_runs() -> None:
    """The comparison should not pass by treating every repeated tool name as a loop."""

    calls = 0

    def handler(_: Any) -> ToolMessage:
        nonlocal calls
        calls += 1
        return ToolMessage(content="ok", tool_call_id="call_1")

    recover = ToolRecoverMiddleware(enable_logging=False)

    assert recover.wrap_tool_call(request("foo", run_id="run_1"), handler).content == "ok"
    assert recover.wrap_tool_call(request("bar", run_id="run_1"), handler).content == "ok"
    assert recover.wrap_tool_call(request("foo", run_id="run_2"), handler).content == "ok"
    assert calls == 3


def test_repeated_empty_results_stop_after_recovery_feedback() -> None:
    """Empty-result loops do less work because recovery feedback is returned before more calls."""

    repeated_queries = ["foo", "foo", "foo", "foo"]
    langchain_calls = 0

    def empty_langchain_handler(_: Any) -> ToolMessage:
        nonlocal langchain_calls
        langchain_calls += 1
        return ToolMessage(content="", tool_call_id="call_1")

    langchain_retry = ToolRetryMiddleware(max_retries=2)
    langchain_results = [
        langchain_retry.wrap_tool_call(request(query, run_id="langchain"), empty_langchain_handler)
        for query in repeated_queries
    ]

    recover_calls = 0

    def empty_recover_handler(_: Any) -> ToolMessage:
        nonlocal recover_calls
        recover_calls += 1
        return ToolMessage(content="", tool_call_id="call_1")

    recover = ToolRecoverMiddleware(enable_logging=False)
    recover_results = [
        recover.wrap_tool_call(request(query, run_id="recover"), empty_recover_handler)
        for query in repeated_queries
    ]

    assert langchain_calls == 4
    assert [result.content for result in langchain_results] == ["", "", "", ""]
    assert recover_calls == 2
    assert payload(recover_results[0])["failure_class"] == FailureClass.EMPTY_RESULT.value
    assert payload(recover_results[2])["failure_class"] == FailureClass.DUPLICATE_CALL.value
    assert payload(recover_results[3])["status"] == "blocked"
