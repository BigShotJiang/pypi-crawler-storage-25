from __future__ import annotations

from langchain_tool_recover.loop_detector import LoopDetector, fingerprint_tool_call


def test_fingerprint_canonicalizes_args() -> None:
    first = fingerprint_tool_call("search_docs", {"query": " Foo   Bar "})
    second = fingerprint_tool_call("search_docs", {"query": "foo bar"})
    assert first == second


def test_loop_detector_counts_duplicates_per_run() -> None:
    detector = LoopDetector()
    first = detector.record("search_docs", {"query": "foo"}, run_id="run_1")
    duplicate = detector.record("search_docs", {"query": " foo "}, run_id="run_1")
    other_run = detector.record("search_docs", {"query": "foo"}, run_id="run_2")

    assert first.count == 1
    assert not first.is_duplicate
    assert duplicate.count == 2
    assert duplicate.duplicate_number == 1
    assert other_run.count == 1


def test_loop_detector_reset_run() -> None:
    detector = LoopDetector()
    detector.record("search_docs", {"query": "foo"}, run_id="run_1")
    detector.record("search_docs", {"query": "foo"}, run_id="run_1")
    detector.reset_run("run_1")

    assert detector.record("search_docs", {"query": "foo"}, run_id="run_1").count == 1

