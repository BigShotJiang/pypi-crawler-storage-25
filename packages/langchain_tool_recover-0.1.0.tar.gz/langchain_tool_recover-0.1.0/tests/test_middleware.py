from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any

import pytest
from langchain_core.messages import ToolMessage

from langchain_tool_recover import (
    FailureClass,
    RecoveryAction,
    ToolRecoverError,
    ToolRecoverMiddleware,
)


@dataclass
class FakeExecutionInfo:
    run_id: str = "run_1"


@dataclass
class FakeRuntime:
    execution_info: FakeExecutionInfo


@dataclass
class FakeRequest:
    tool_call: dict[str, Any]
    runtime: FakeRuntime


def request(query: str = "foo", run_id: str = "run_1") -> FakeRequest:
    return FakeRequest(
        tool_call={"name": "search_docs", "args": {"query": query}, "id": f"call_{query}"},
        runtime=FakeRuntime(FakeExecutionInfo(run_id)),
    )


def payload(message: ToolMessage) -> dict[str, Any]:
    return json.loads(str(message.content))


def test_successful_pass_through() -> None:
    middleware = ToolRecoverMiddleware(enable_logging=False)
    result = ToolMessage(content="ok", tool_call_id="call_1")

    assert middleware.wrap_tool_call(request(), lambda _: result) is result


def test_empty_result_returns_recovery_message() -> None:
    middleware = ToolRecoverMiddleware(enable_logging=False)
    result = middleware.wrap_tool_call(
        request(),
        lambda _: ToolMessage(content="", tool_call_id="call_1"),
    )

    body = payload(result)
    assert body["failure_class"] == FailureClass.EMPTY_RESULT.value
    assert body["status"] == "needs_replan"


def test_duplicate_recovery_then_block() -> None:
    middleware = ToolRecoverMiddleware(enable_logging=False)
    handler_calls = 0

    def handler(_: Any) -> ToolMessage:
        nonlocal handler_calls
        handler_calls += 1
        return ToolMessage(content="ok", tool_call_id="call_1")

    assert middleware.wrap_tool_call(request(), handler).content == "ok"
    assert middleware.wrap_tool_call(request(" foo "), handler).content == "ok"

    recovery = middleware.wrap_tool_call(request("FOO"), handler)
    blocked = middleware.wrap_tool_call(request("foo"), handler)

    assert handler_calls == 2
    assert payload(recovery)["status"] == "needs_replan"
    assert payload(blocked)["status"] == "blocked"


def test_validation_error_returns_correction_message() -> None:
    middleware = ToolRecoverMiddleware(enable_logging=False)
    result = middleware.wrap_tool_call(
        request(),
        lambda _: (_ for _ in ()).throw(ValueError("invalid input")),
    )

    body = payload(result)
    assert body["failure_class"] == FailureClass.VALIDATION_ERROR.value
    assert body["status"] == "needs_correction"


def test_timeout_retries_until_success(monkeypatch: pytest.MonkeyPatch) -> None:
    middleware = ToolRecoverMiddleware(enable_logging=False, max_attempts=3)
    monkeypatch.setattr("langchain_tool_recover.middleware.time.sleep", lambda _: None)
    attempts = 0

    def handler(_: Any) -> ToolMessage:
        nonlocal attempts
        attempts += 1
        if attempts < 3:
            raise TimeoutError("timed out")
        return ToolMessage(content="ok", tool_call_id="call_1")

    assert middleware.wrap_tool_call(request(), handler).content == "ok"
    assert attempts == 3


def test_rate_limit_retry_exhaustion_returns_message(monkeypatch: pytest.MonkeyPatch) -> None:
    middleware = ToolRecoverMiddleware(enable_logging=False, max_attempts=2)
    monkeypatch.setattr("langchain_tool_recover.middleware.time.sleep", lambda _: None)

    result = middleware.wrap_tool_call(
        request(),
        lambda _: (_ for _ in ()).throw(RuntimeError("429 rate limit")),
    )

    body = payload(result)
    assert body["failure_class"] == FailureClass.RATE_LIMIT.value
    assert body["attempt"] == 2


def test_auth_error_fail_fast() -> None:
    middleware = ToolRecoverMiddleware(enable_logging=False)

    with pytest.raises(ToolRecoverError) as raised:
        middleware.wrap_tool_call(
            request(),
            lambda _: (_ for _ in ()).throw(PermissionError("denied")),
        )

    assert raised.value.recovery.failure_class == FailureClass.AUTH_ERROR


def test_policy_override_unknown_error_to_agent() -> None:
    middleware = ToolRecoverMiddleware(
        enable_logging=False,
        policies={FailureClass.UNKNOWN_ERROR: RecoveryAction.RETURN_TO_AGENT},
    )
    result = middleware.wrap_tool_call(
        request(),
        lambda _: (_ for _ in ()).throw(RuntimeError("boom")),
    )

    assert payload(result)["failure_class"] == FailureClass.UNKNOWN_ERROR.value
