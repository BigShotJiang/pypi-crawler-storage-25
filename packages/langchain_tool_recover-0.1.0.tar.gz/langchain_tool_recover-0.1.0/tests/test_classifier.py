from __future__ import annotations

import asyncio

from langchain_core.messages import ToolMessage
from pydantic import BaseModel, ValidationError

from langchain_tool_recover import FailureClass, UnsafeCommandError
from langchain_tool_recover.classifier import classify_exception, classify_result


class Model(BaseModel):
    value: int


def test_exception_classes() -> None:
    assert classify_exception(TimeoutError("slow")) == FailureClass.TIMEOUT
    assert classify_exception(asyncio.TimeoutError()) == FailureClass.TIMEOUT
    assert classify_exception(RuntimeError("429 rate limit")) == FailureClass.RATE_LIMIT
    assert classify_exception(PermissionError("denied")) == FailureClass.AUTH_ERROR
    assert classify_exception(UnsafeCommandError("unsafe command")) == FailureClass.UNSAFE_COMMAND
    assert classify_exception(RuntimeError("boom")) == FailureClass.UNKNOWN_ERROR


def test_validation_error_classification() -> None:
    try:
        Model(value="not-int")
    except ValidationError as exc:
        assert classify_exception(exc) == FailureClass.VALIDATION_ERROR


def test_empty_result_classification() -> None:
    assert classify_result(None) == FailureClass.EMPTY_RESULT
    assert classify_result("") == FailureClass.EMPTY_RESULT
    assert classify_result("   ") == FailureClass.EMPTY_RESULT
    assert classify_result([]) == FailureClass.EMPTY_RESULT
    assert classify_result({}) == FailureClass.EMPTY_RESULT
    assert classify_result({"empty": True}) == FailureClass.EMPTY_RESULT
    assert classify_result({"results": []}) == FailureClass.EMPTY_RESULT
    assert classify_result('{"results":[]}') == FailureClass.EMPTY_RESULT


def test_non_empty_false_positives() -> None:
    assert classify_result("no results found") is None
    assert classify_result({"results": ["item"]}) is None
    assert classify_result({"empty": False}) is None
    assert classify_result(0) is None


def test_error_tool_message_reclassified() -> None:
    message = ToolMessage(
        content="Validation failed: field required",
        tool_call_id="call_1",
        status="error",
    )
    assert classify_result(message) == FailureClass.VALIDATION_ERROR
