from __future__ import annotations

import asyncio

import pytest
from langchain_core.tools import tool

from langchain_tool_recover import FailureClass, ToolRecoverError, recover_tool


@tool
def search_docs(query: str) -> str:
    """Search documentation."""
    return f"Results for {query}"


@tool
def empty_search(query: str) -> dict:
    """Search documentation."""
    return {"results": []}


@tool
def auth_tool(query: str) -> str:
    """Search with auth."""
    raise PermissionError("denied")


@tool
async def async_search(query: str) -> str:
    """Async search documentation."""
    return f"Async {query}"


def test_wrapper_preserves_metadata_and_passes_results() -> None:
    wrapped = recover_tool(search_docs, enable_logging=False)

    assert wrapped.name == search_docs.name
    assert wrapped.description == search_docs.description
    assert wrapped.args_schema == search_docs.args_schema
    assert wrapped.invoke({"query": "foo"}) == "Results for foo"


def test_wrapper_empty_result_recovery() -> None:
    wrapped = recover_tool(empty_search, enable_logging=False)
    result = wrapped.invoke({"query": "foo"})

    assert result["failure_class"] == FailureClass.EMPTY_RESULT.value
    assert result["status"] == "needs_replan"


def test_wrapper_duplicate_detection() -> None:
    wrapped = recover_tool(search_docs, enable_logging=False)

    assert wrapped.invoke({"query": "foo"}) == "Results for foo"
    assert wrapped.invoke({"query": " FOO "}) == "Results for  FOO "
    recovery = wrapped.invoke({"query": "foo"})
    blocked = wrapped.invoke({"query": "foo"})

    assert recovery["failure_class"] == FailureClass.DUPLICATE_CALL.value
    assert recovery["status"] == "needs_replan"
    assert blocked["status"] == "blocked"


def test_wrapper_fail_fast_auth_error() -> None:
    wrapped = recover_tool(auth_tool, enable_logging=False)

    with pytest.raises(ToolRecoverError):
        wrapped.invoke({"query": "foo"})


def test_async_wrapper() -> None:
    wrapped = recover_tool(async_search, enable_logging=False)

    assert asyncio.run(wrapped.ainvoke({"query": "foo"})) == "Async foo"

