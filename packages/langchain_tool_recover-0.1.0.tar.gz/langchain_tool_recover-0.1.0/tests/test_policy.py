from __future__ import annotations

import pytest

from langchain_tool_recover import FailureClass, RecoveryAction, RecoveryMessage, ToolRecoverError
from langchain_tool_recover.policies import RecoveryPolicy


def test_default_policy_table() -> None:
    policy = RecoveryPolicy()
    assert policy.decide(FailureClass.TIMEOUT).action == RecoveryAction.RETRY_WITH_BACKOFF
    assert policy.decide(FailureClass.RATE_LIMIT).action == RecoveryAction.RETRY_WITH_BACKOFF
    assert policy.decide(FailureClass.VALIDATION_ERROR).action == RecoveryAction.RETURN_TO_AGENT
    assert policy.decide(FailureClass.AUTH_ERROR).action == RecoveryAction.FAIL_FAST
    assert policy.decide(FailureClass.EMPTY_RESULT).action == RecoveryAction.RETURN_TO_AGENT
    assert policy.decide(FailureClass.DUPLICATE_CALL).action == RecoveryAction.BLOCK
    assert policy.decide(FailureClass.UNSAFE_COMMAND).action == RecoveryAction.BLOCK
    assert policy.decide(FailureClass.UNKNOWN_ERROR).action == RecoveryAction.FAIL_FAST


def test_policy_overrides_accept_strings() -> None:
    policy = RecoveryPolicy({"unknown_error": "return_to_agent"})
    assert policy.decide(FailureClass.UNKNOWN_ERROR).action == RecoveryAction.RETURN_TO_AGENT


def test_tool_recover_error_contains_structured_payload() -> None:
    recovery = RecoveryMessage(
        status="failed",
        tool="search_docs",
        failure_class=FailureClass.UNKNOWN_ERROR,
        message="failed",
        suggestion="inspect",
        action=RecoveryAction.FAIL_FAST,
    )
    with pytest.raises(ToolRecoverError) as raised:
        raise ToolRecoverError(recovery)

    assert raised.value.recovery == recovery
    assert '"failure_class":"unknown_error"' in str(raised.value)

