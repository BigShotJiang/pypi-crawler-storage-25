"""Generate deployment scripts from templates with variable injection.

Follows the same pattern as Cloud control plane observability agent
script generation (clusters.py lines 366-397): load a template file,
replace {variable} placeholders with actual values.
"""

from __future__ import annotations

from pathlib import Path
from typing import Dict


TEMPLATE_DIR = Path(__file__).resolve().parent / "templates"

# Default Readyset ports by engine
DEFAULT_PORTS = {
    "postgresql": 5433,
    "mysql": 3307,
}

# Default Prometheus metrics port
DEFAULT_METRICS_PORT = 6034

# Default images
from shared.deploy import READYSET_IMAGE
SQUEEPY_IMAGE = "docker.io/readysettech/squeepy:latest"  # placeholder until published


_LOCALHOST_ALIASES = {"localhost", "127.0.0.1", "::1", "0.0.0.0"}


def _normalize_host(host: str) -> str:
    """Normalize localhost variants to a single value for comparison."""
    return "localhost" if host in _LOCALHOST_ALIASES else host


def _find_available_port(engine: str, deploy_host: str = "localhost") -> int:
    """Find a Readyset port that doesn't conflict with existing cache targets on the same host.

    Only matters when deploying to the same host (e.g., multiple local Docker caches).
    Remote hosts on different IPs can share the same port number.
    """
    default_port = DEFAULT_PORTS.get(engine, 5433)
    normalized_deploy = _normalize_host(deploy_host)

    try:
        from shared.config.targets import TargetsConfig
        cfg = TargetsConfig()
        cfg.load()

        used_ports = set()
        for _, config in cfg._data.get("targets", {}).items():
            if config.get("target_type") != "readyset":
                continue
            if _normalize_host(config.get("host", "localhost")) != normalized_deploy:
                continue
            used_ports.add(int(config.get("port", 0)))

        # Also check actually-bound Docker ports.
        try:
            import subprocess
            result = subprocess.run(
                ["docker", "ps", "--format", "{{.Ports}}"],
                capture_output=True, text=True, timeout=5,
            )
            if result.returncode == 0:
                import re
                for match in re.findall(r"0\.0\.0\.0:(\d+)->", result.stdout):
                    used_ports.add(int(match))
        except Exception:
            pass

        port = default_port
        while port in used_ports:
            port += 1
        return port
    except Exception:
        return default_port


def _find_available_metrics_port(deploy_host: str = "localhost") -> int:
    """Find a Prometheus metrics port that doesn't conflict with existing caches."""
    normalized_deploy = _normalize_host(deploy_host)
    try:
        from shared.config.targets import TargetsConfig
        cfg = TargetsConfig()
        cfg.load()

        used_ports = set()
        for _, config in cfg._data.get("targets", {}).items():
            if config.get("target_type") != "readyset":
                continue
            if _normalize_host(config.get("host", "localhost")) != normalized_deploy:
                continue
            metrics_port = config.get("metrics_port")
            if metrics_port:
                used_ports.add(int(metrics_port))

        # Also check actually-bound Docker ports to catch containers
        # that exist but aren't in the config (or config was stale).
        try:
            import subprocess
            result = subprocess.run(
                ["docker", "ps", "--format", "{{.Ports}}"],
                capture_output=True, text=True, timeout=5,
            )
            if result.returncode == 0:
                import re
                for match in re.findall(r"0\.0\.0\.0:(\d+)->", result.stdout):
                    used_ports.add(int(match))
        except Exception:
            pass

        port = DEFAULT_METRICS_PORT
        while port in used_ports:
            port += 1
        return port
    except Exception:
        return DEFAULT_METRICS_PORT


def build_variables(
    target_name: str,
    target_config: dict,
    password: str,
    port: int | None = None,
    deploy_config: str = "readyset",
    namespace: str = "readyset",
) -> Dict[str, str]:
    """Build template variables dict from target config."""
    engine = target_config.get("engine", "postgresql")
    deploy_host = target_config.get("host", "localhost")
    if port:
        readyset_port = port
    else:
        readyset_port = _find_available_port(engine, deploy_host)

    metrics_port = _find_available_metrics_port(deploy_host)

    return {
        "db_host": target_config.get("host", "localhost"),
        "db_port": str(target_config.get("port", 5432)),
        "db_user": target_config.get("user", "postgres"),
        "db_name": target_config.get("database", ""),
        "db_engine": engine,
        "readyset_port": str(readyset_port),
        "metrics_port": str(metrics_port),
        "container_name": f"rdst-readyset-{target_name}",
        "target_name": target_name,
        "readyset_image": READYSET_IMAGE,
        "squeepy_image": SQUEEPY_IMAGE,
        "deploy_config": deploy_config,
        "namespace": namespace,
    }


def generate_script(mode: str, variables: Dict[str, str]) -> str:
    """Load template and inject variables.

    Args:
        mode: "docker", "systemd", or "kubernetes"
        variables: Dict of {placeholder: value} pairs

    Returns:
        Rendered script/manifest content.
    """
    if mode == "kubernetes":
        return _generate_k8s_manifests(variables)

    template_file = TEMPLATE_DIR / f"deploy_{mode}.sh"
    if not template_file.exists():
        raise FileNotFoundError(f"Template not found: {template_file}")

    script = template_file.read_text()
    for key, value in variables.items():
        script = script.replace(f"{{{key}}}", str(value))
    return script


def generate_k8s_apply_manifests(variables: Dict[str, str]) -> str:
    """Generate only Deployment + Service manifests (Secret is handled via kubectl).

    Used by kubernetes.py when applying programmatically. Secret is created
    separately with the actual password via kubectl create secret.
    """
    return _generate_k8s_manifests(variables, include_secret=False)


def _generate_k8s_manifests(variables: Dict[str, str], include_secret: bool = True) -> str:
    """Combine K8s manifest templates into a single multi-document YAML."""
    template_names = ["deploy_k8s_deployment.yaml", "deploy_k8s_service.yaml"]
    if include_secret:
        template_names.insert(0, "deploy_k8s_secret.yaml")

    parts = []
    for name in template_names:
        template_file = TEMPLATE_DIR / name
        if not template_file.exists():
            raise FileNotFoundError(f"Template not found: {template_file}")
        content = template_file.read_text()
        for key, value in variables.items():
            content = content.replace(f"{{{key}}}", str(value))
        parts.append(content)

    return "---\n".join(parts)
