"""spur-skills package."""
