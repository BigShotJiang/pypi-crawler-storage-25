"""turbo-agent-job：任务调度与执行单元模块。

说明：
- 该模块用于替代/承接原 turbo-agent-worker 的能力。
- worker 已停用并更名为 job，本模块承载原 worker 的 CLI 与执行逻辑。
"""

from turbo_agent_job.pipeline import JobWorkerPipeline, JobWorkerHooks
from turbo_agent_job.worker import register_pipeline, get_pipeline

__all__ = [
    "__version__",
    "JobWorkerPipeline",
    "JobWorkerHooks",
    "register_pipeline",
    "get_pipeline",
]

__version__ = "0.1.8"
