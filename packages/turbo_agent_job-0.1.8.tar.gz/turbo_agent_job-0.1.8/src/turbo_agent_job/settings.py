from uuid import uuid4
from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    TA_JOB_REDIS_URL: str = "redis://localhost:6379/0"
    TA_JOB_REDIS_CACHE_URL: str = "redis://localhost:6379/1"
    TA_JOB_REDIS_RESULT_URL: str = "redis://localhost:6379/2"
    TA_JOB_LOG_LEVEL: str = "INFO"
    TA_JOB_ARCHIVE_CONSUMER: str | None = Field(default=None)

    model_config = SettingsConfigDict(
        env_file=str(".env"),
        env_file_encoding="utf-8",
        extra="ignore",
    )

    def get_store_consumer_name(self) -> str:
        return self.TA_JOB_ARCHIVE_CONSUMER or f"consumer-{uuid4().hex[:8]}"

settings = Settings()
