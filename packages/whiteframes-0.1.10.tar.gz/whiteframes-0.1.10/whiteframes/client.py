"""
Whiteframes AI Python SDK
~~~~~~~~~~~~~~~~~~~~~~~~~
Create AI-powered videos programmatically.

Usage:
    from whiteframes import WhiteframesAI

    client = WhiteframesAI(api_key="wfai_your_key_here")
    video = client.create_video(
        prompt="Explain how neural networks work",
        voice="Stephen",
        quality="enhanced",
        frames=8,
        video_type="educational"
    ).wait()
    print(video.title)
    print(video.frames[0].narration)

    # Create a video in another language
    video = client.create_video(
        prompt="Explain how neural networks work",
        voice="Kajal",
        language="hi-IN",
    ).wait()
    print(video.language)  # "hi-IN"

    # List supported languages and voices
    languages = client.list_languages()
    french_voices = client.list_voices(language="fr-FR")

    # Premium voices (+1 credit per video)
    voices = client.list_premium_voices()
    video = client.create_video(
        prompt="Explain quantum computing",
        voice=voices[0]["voiceId"],
        voice_tier="premium",
    ).wait()
    print(video.voice_tier)  # "premium"
"""

import time
import requests
from typing import Optional, List, Dict, Any

from ._internal import (
    BASE_URL, EXT, VOICE_IDS, VIDEO_TYPES,
    VOICE_TIER_STANDARD, VOICE_TIER_PREMIUM,
    F_VOICE_PROVIDER, F_PROVIDER_STD, F_PROVIDER_PREM, PREMIUM_VOICES_EP,
    F_VISUAL_KEY, F_VISUAL_ALT, F_AUDIO_KEY, F_ASSET_PREFIX, F_DOC_ASSET_KEY,
    F_VISUAL_SHORT, F_AUDIO_SHORT,
    ASSET_PATH_PFX, ASSET_PATH_SFX,
    VOICE_LANGUAGES, LANGUAGES,
)
from .exceptions import WhiteframesError, InsufficientCreditsError, ContentRejectedError
from .models import Video, VideoJob, UsageStats, Frame


class WhiteframesAI:
    """
    Whiteframes AI client.

    Args:
        api_key: Your API key (starts with wfai_).
        base_url: Override the API base URL (optional).
        timeout: HTTP request timeout in seconds (default 30).

    Example:
        client = WhiteframesAI(api_key="wfai_xxxx")
        video = client.create_video("Explain blockchain in simple terms")
        print(video.title)
    """

    def __init__(self, api_key: str, base_url: str = BASE_URL, timeout: int = 30):
        if not api_key or not api_key.startswith("wfai_"):
            raise ValueError("Invalid API key. Keys must start with 'wfai_'.")
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._session = requests.Session()
        self._session.headers.update({
            "X-API-Key": api_key,
            "Content-Type": "application/json",
        })
        self._user_id = None  # lazily fetched

    # ─── Core video creation ───────────────────────────────────────────────

    def create_video(
        self,
        prompt: str,
        voice: str = "Stephen",
        quality: str = "enhanced",
        frames: int = 4,
        video_type: str = "whiteboard",
        voice_tier: str = "standard",
        speaker_voices: Optional[Dict[str, str]] = None,
        file_path: str = None,
        language: str = "en-US",
        aspect_ratio: str = "16:9",
    ) -> VideoJob:
        """
        Start video generation and return a VideoJob.

        Call .wait() to block until the video is ready, or .refresh() to poll
        the status manually.

        Args:
            prompt: Topic or description for the video.
            voice: Narrator voice ID. For standard tier, use list_voices() to see
                   all available voices across languages. For premium tier, use any
                   voice ID from list_premium_voices(). Default: Stephen.
            quality: "basic" (fast), "enhanced" (default), or "premium" (high detail). Default: enhanced.
            frames: Number of frames - 4, 8, or 12. Default: 4.
            video_type: Visual style. One of: whiteboard, educational, quiz,
                        geo-map, social-short, top-10, flashcard, did-you-know,
                        myth-vs-fact, how-to, infographic, news, architecture,
                        comparison, timeline, storytelling, videocast, pitch,
                        corporate, saas-demo. Default: whiteboard.
            voice_tier: "standard" (included voices) or "premium" (extra voices,
                        +1 credit per video). Default: standard.
            speaker_voices: For videocast only. Dict mapping speaker IDs to voice IDs.
                            e.g. {"speaker_1": "Stephen", "speaker_2": "Ruth"}
            file_path: Optional local file (PDF, image, etc.) to use as input.
                       Max ~4.5 MB. The file is uploaded and its content is extracted
                       automatically before video generation begins.
            language: BCP-47 language code for narration. Default: "en-US".
                      Examples: "fr-FR" (French), "de-DE" (German), "es-ES" (Spanish),
                      "ja-JP" (Japanese), "ko-KR" (Korean), "cmn-CN" (Chinese).
                      Narration text will be generated in this language.
            aspect_ratio: "16:9" (horizontal) or "9:16" (vertical). Default: "16:9".
                          Social-short type is always 9:16 regardless of this setting.

        Returns:
            VideoJob — call .wait() to block, or .refresh() to poll.

        Examples:
            # Block until ready
            video = client.create_video("Explain photosynthesis").wait()

            # With premium voice
            video = client.create_video(
                prompt="How do neural networks work?",
                voice="Dennis",
                voice_tier="premium",
                quality="premium",
                frames=8,
            ).wait(on_progress=lambda p, msg: print(f"[{p}%] {msg}"))

            # Non-blocking
            job = client.create_video("Explain blockchain")
            # ... do other work ...
            video = job.wait()

            # From a document
            video = client.create_video(
                prompt="Summarize this report",
                file_path="quarterly-report.pdf",
            ).wait()
        """
        if voice_tier not in (VOICE_TIER_STANDARD, VOICE_TIER_PREMIUM):
            raise ValueError("voice_tier must be 'standard' or 'premium'")
        if voice_tier == VOICE_TIER_STANDARD and voice not in VOICE_IDS:
            raise ValueError(f"Invalid voice '{voice}'. Choose from: {', '.join(VOICE_IDS)}")
        if quality not in ("basic", "enhanced", "premium"):
            raise ValueError("quality must be 'basic', 'enhanced', or 'premium'")
        if frames not in (4, 8, 12):
            raise ValueError("frames must be 4, 8, or 12")
        if video_type not in VIDEO_TYPES:
            raise ValueError(f"Invalid video_type '{video_type}'. Choose from: {', '.join(VIDEO_TYPES)}")
        if aspect_ratio not in ("16:9", "9:16"):
            raise ValueError("aspect_ratio must be '16:9' or '9:16'")

        payload = {
            "prompt": prompt,
            "voiceId": voice,
            "qualityTier": quality,
            "maxScenes": frames,
            "videoType": video_type,
            "language": language,
            "aspectRatio": aspect_ratio,
        }
        if voice_tier == VOICE_TIER_PREMIUM:
            payload[F_VOICE_PROVIDER] = F_PROVIDER_PREM
        if speaker_voices:
            payload["speakerVoices"] = speaker_voices

        # If a local file is provided, upload it first
        if file_path:
            upload_key, mime_type, file_name = self._upload_file(file_path)
            payload[F_DOC_ASSET_KEY] = upload_key
            payload["documentMimeType"] = mime_type
            payload["documentName"] = file_name

        data = self._post(f"{EXT}/compose", payload)
        return VideoJob(job_id=data["jobId"], project_id=data["projectId"], client=self)

    # ─── Job status ──────────────────────────────────────────────────────

    def get_job_status(self, job_id: str) -> Dict[str, Any]:
        """
        Poll the status of a job (video generation, frame regeneration, fix, or render).

        Args:
            job_id: The jobId returned by create_video, regenerate_frame, fix_frame, etc.

        Returns:
            Dict with: jobId, status, progress (0-100), message, projectId.

        Example:
            job = client.create_video("Explain quantum computing")
            status = client.get_job_status(job.job_id)
            print(status["status"], status["progress"])  # "generating", 45
        """
        return self._get(f"{EXT}/jobs/{job_id}")

    # ─── Prompt enhancement ───────────────────────────────────────────────

    def enhance_prompt(self, prompt: str) -> str:
        """
        Use AI to enhance a raw prompt into a richer video description.
        Free — no credit cost.

        Args:
            prompt: The raw prompt text. Min 3, max 5,000 characters.

        Returns:
            Enhanced prompt string.

        Example:
            enhanced = client.enhance_prompt("explain blockchain")
            video = client.create_video(enhanced).wait()
        """
        if len(prompt) < 3:
            raise ValueError("prompt must be at least 3 characters")
        if len(prompt) > 5000:
            raise ValueError("prompt must be 5,000 characters or fewer")
        data = self._post(f"{EXT}/enhance-prompt", {"prompt": prompt})
        return data.get("enhanced", prompt)

    # ─── Voice management ──────────────────────────────────────────────────

    def list_voices(self, language: str = None) -> List[Dict[str, str]]:
        """
        List available standard voices (included with every video).

        Args:
            language: Optional BCP-47 language code to filter voices.
                      e.g. "fr-FR" returns only French voices.
                      If None, returns all voices.

        Returns:
            List of dicts with: id, language, language_name, tier ("standard").

        Example:
            voices = client.list_voices()
            for v in voices:
                print(f"{v['id']} ({v['language_name']})")

            # Filter by language
            french = client.list_voices(language="fr-FR")
        """
        voices = []
        for v in VOICE_IDS:
            lang = VOICE_LANGUAGES.get(v, "en-US")
            if language and lang != language:
                continue
            voices.append({
                "id": v,
                "language": lang,
                "language_name": LANGUAGES.get(lang, lang),
                "tier": VOICE_TIER_STANDARD,
            })
        return voices

    def list_premium_voices(self) -> List[Dict[str, str]]:
        """
        List available premium voices (+1 credit per video).

        Returns:
            List of dicts with: voiceId, name, gender, ageGroup, and other metadata.
            Returns empty list if premium voices are not enabled.

        Example:
            voices = client.list_premium_voices()
            for v in voices:
                print(f"{v['voiceId']}: {v.get('name', v['voiceId'])}")
        """
        data = self._get(f"{EXT}/{PREMIUM_VOICES_EP}")
        return data.get("voices", [])

    def list_languages(self) -> List[Dict[str, str]]:
        """
        List all supported languages for video narration.

        Includes both standard and premium voice counts.
        Languages only available via premium voices — such as Russian and Hebrew —
        appear with voices=0 and premium_voices>0.

        Returns:
            List of dicts with: code (BCP-47), name, voices (standard voice count),
            premium_voices (premium voice count).
            Only languages with at least one voice of either tier are returned.

        Example:
            languages = client.list_languages()
            for lang in languages:
                std = lang['voices']
                prem = lang['premium_voices']
                print(f"{lang['code']}: {lang['name']} ({std} standard, {prem} premium voices)")
            # en-US: English (US) (4 standard, 12 premium voices)
            # ru-RU: Russian (0 standard, 3 premium voices)
            # he-IL: Hebrew (0 standard, 2 premium voices)
        """
        # Count standard voices per language
        lang_counts: Dict[str, int] = {}
        for v in VOICE_IDS:
            lang = VOICE_LANGUAGES.get(v, "en-US")
            lang_counts[lang] = lang_counts.get(lang, 0) + 1

        # Count premium voices per language
        premium_counts: Dict[str, int] = {}
        try:
            for pv in self.list_premium_voices():
                raw = pv.get("langCode", "EN_US")
                if "_" in raw:
                    lang_part, region = raw.split("_", 1)
                    if lang_part == "ZH":
                        bcp47 = "cmn-CN"
                    elif lang_part == "AR":
                        bcp47 = "ar-AE"
                    else:
                        bcp47 = f"{lang_part.lower()}-{region}"
                else:
                    bcp47 = raw
                premium_counts[bcp47] = premium_counts.get(bcp47, 0) + 1
        except Exception:
            pass  # Premium voices unavailable — show standard counts only

        return [
            {
                "code": code,
                "name": name,
                "voices": lang_counts.get(code, 0),
                "premium_voices": premium_counts.get(code, 0),
            }
            for code, name in LANGUAGES.items()
            if lang_counts.get(code, 0) > 0 or premium_counts.get(code, 0) > 0
        ]

    # ─── Project management ────────────────────────────────────────────────

    def get_video(self, project_id: str) -> Video:
        """Get a completed video by project ID."""
        data = self._get(f"{EXT}/projects/{project_id}")
        return Video.from_dict(data["project"])

    def list_videos(self, cursor: str = None) -> Dict[str, Any]:
        """
        List all your videos.

        Returns:
            Dict with keys: videos (list of Video), next_cursor, total_count.
        """
        params = {}
        if cursor:
            params["cursor"] = cursor
        data = self._get(f"{EXT}/projects", params=params)
        return {
            "videos": [Video.from_dict(p) for p in data.get("projects", [])],
            "next_cursor": data.get("nextCursor"),
            "total_count": data.get("totalCount"),
        }

    def delete_video(self, project_id: str) -> bool:
        """Soft-delete a video. Returns True on success."""
        self._delete(f"{EXT}/projects/{project_id}")
        return True

    def __save_project(self, project: Dict[str, Any]) -> bool:
        """Save project data."""
        self._post(f"{EXT}/projects/save", project)
        return True

    # ─── Edit operations ───────────────────────────────────────────────────

    def update_frame(
        self,
        project_id: str,
        frame_num: int,
        *,
        narration: Optional[str] = None,
        visual_description: Optional[str] = None,
        keywords: Optional[List[str]] = None,
        voice_id: Optional[str] = None,
        voice_tier: Optional[str] = None,
    ) -> Video:
        """
        Update editable fields on a frame. When narration or voice changes, the
        audio is automatically re-synthesized and uploaded to S3. Premium voices
        cost 1 credit per synthesis.

        Args:
            project_id: The project ID.
            frame_num: The frame ID (1-based).
            narration: New narration text (optional). Triggers audio re-synthesis.
            visual_description: New visual description (optional).
            keywords: New keywords list (optional).
            voice_id: Per-frame voice override (optional).
            voice_tier: "standard" or "premium" (optional). Required when
                        switching between standard and premium voices.

        Returns:
            Updated Video object.

        Example:
            video = client.update_frame(
                "my-project-id", frame_num=2,
                narration="Revised narration for frame 2.",
                keywords=["AI", "deep learning"],
            )

            # Set a per-frame premium voice override
            video = client.update_frame(
                "my-project-id", frame_num=1,
                voice_id="Mark", voice_tier="premium",
            )
        """
        proj = self.get_video(project_id)
        data = proj._Video__raw
        scene = next((s for s in data.get("scenes", []) if s.get("id") == frame_num), None)
        if not scene:
            raise WhiteframesError(f"Frame {frame_num} not found in project")
        if visual_description is not None:
            scene["visualDescription"] = visual_description
        if keywords is not None:
            scene["keywords"] = keywords
        if voice_id is not None:
            scene["voiceId"] = voice_id
        if voice_tier is not None:
            if voice_tier not in (VOICE_TIER_STANDARD, VOICE_TIER_PREMIUM):
                raise ValueError("voice_tier must be 'standard' or 'premium'")
            scene[F_VOICE_PROVIDER] = F_PROVIDER_PREM if voice_tier == VOICE_TIER_PREMIUM else F_PROVIDER_STD

        # Update narration text in scene data — the backend handles audio
        # synthesis automatically on save (detects narration/voice changes)
        if narration is not None:
            scene["narration"] = narration
            if scene.get("versions"):
                av = scene.get("activeVersion", len(scene["versions"]) - 1)
                if 0 <= av < len(scene["versions"]):
                    scene["versions"][av]["narration"] = narration

        self.__save_project(data)
        return self.get_video(project_id)

    def update_project(
        self,
        project_id: str,
        *,
        video_type: Optional[str] = None,
        voice_id: Optional[str] = None,
        voice_tier: Optional[str] = None,
        language: Optional[str] = None,
        music_track_id: Optional[str] = None,
        music_volume: Optional[float] = None,
        background: Optional[str] = None,
        brand_override: Optional[Dict[str, Any]] = None,
    ) -> Video:
        """
        Update project-level settings.

        Args:
            project_id: The project ID.
            video_type: New visual style (optional).
            voice_id: New default voice (optional). For premium tier, use any
                      voice ID from list_premium_voices().
            voice_tier: "standard" or "premium" (optional). Set when changing
                        between standard and premium voices.
            language: BCP-47 language code (optional). e.g. "fr-FR", "hi-IN".
                      Use list_languages() to see supported codes.
            music_track_id: Background music track ID (optional). Set to "" to remove.
            music_volume: Music volume 0.0-1.0 (optional).
            background: Background preset (optional). One of: "plain", "grid",
                        "lined", "dot-grid", "paper", "chalkboard".
                        Set to "" to remove a custom background and revert to plain.
            brand_override: Dict of brand settings to apply to this video only
                           (optional). Keys: primaryColor, accentColor, fontFamily,
                           watermarkText, logoS3Key, logoPosition. Pass {} to
                           clear and revert to account brand.

        Returns:
            Updated Video object.

        Example:
            video = client.update_project(
                "my-project-id",
                music_track_id="track-02",
                music_volume=0.3,
            )

            # Switch to a premium voice
            video = client.update_project(
                "my-project-id",
                voice_id="Dennis",
                voice_tier="premium",
            )

            # Set background style
            video = client.update_project(
                "my-project-id",
                background="grid",
            )
        """
        _VALID_BACKGROUNDS = {"plain", "grid", "lined", "dot-grid", "paper", "chalkboard", ""}
        proj = self.get_video(project_id)
        data = proj._Video__raw
        if language is not None:
            if language not in LANGUAGES:
                raise ValueError(f"Invalid language '{language}'. Use list_languages() to see supported codes.")
            data["language"] = language
        if video_type is not None:
            if video_type not in VIDEO_TYPES:
                raise ValueError(f"Invalid video_type '{video_type}'. Choose from: {', '.join(VIDEO_TYPES)}")
            data["videoType"] = video_type
        if voice_tier is not None:
            if voice_tier not in (VOICE_TIER_STANDARD, VOICE_TIER_PREMIUM):
                raise ValueError("voice_tier must be 'standard' or 'premium'")
            data[F_VOICE_PROVIDER] = F_PROVIDER_PREM if voice_tier == VOICE_TIER_PREMIUM else F_PROVIDER_STD
        if voice_id is not None:
            effective_tier = voice_tier or (VOICE_TIER_PREMIUM if data.get(F_VOICE_PROVIDER) == F_PROVIDER_PREM else VOICE_TIER_STANDARD)
            if effective_tier == VOICE_TIER_STANDARD and voice_id not in VOICE_IDS:
                raise ValueError(f"Invalid voice_id '{voice_id}'. Choose from: {', '.join(VOICE_IDS)}")
            data["voiceId"] = voice_id
        if music_track_id is not None or music_volume is not None or background is not None:
            audio = data.get("audioSettings") or {}
            if music_track_id is not None:
                audio["musicTrackId"] = music_track_id
            if music_volume is not None:
                audio["musicVolume"] = music_volume
            if background is not None:
                if background not in _VALID_BACKGROUNDS:
                    raise ValueError(f"Invalid background '{background}'. Choose from: plain, grid, lined, dot-grid, paper, chalkboard")
                audio["background"] = background if background else None
            data["audioSettings"] = audio
        if brand_override is not None:
            data["brandOverride"] = brand_override if brand_override else {}
        self.__save_project(data)
        return self.get_video(project_id)

    # ─── Frame operations ──────────────────────────────────────────────────

    def regenerate_frame(
        self,
        project_id: str,
        frame_num: int,
        frame_description: str,
        narration: str = "",
        keywords: Optional[List[str]] = None,
        voice: str = "Stephen",
        quality: str = "basic",
        video_type: str = "whiteboard",
        voice_tier: str = "standard",
        regenerate_narration: bool = False,
        poll_interval: float = 3.0,
        timeout: float = 300.0,
        on_progress=None,
        **kwargs,
    ) -> Video:
        """
        Regenerate the visual for a single frame using AI. Blocks until done.

        Args:
            project_id: The project ID.
            frame_num: Frame number to regenerate (1-based).
            frame_description: Visual description of what to draw.
            narration: Frame narration text (for context).
            keywords: Keywords for the frame.
            voice: Voice ID for re-synthesized audio. For premium tier, use any
                   voice ID from list_premium_voices().
            quality: "basic" (2 credits) or "premium" (6 credits).
            video_type: Visual style.
            voice_tier: "standard" or "premium" voice tier. Default: standard.
            regenerate_narration: If True, AI will generate fresh narration from
                the visual description (+1 credit). Default: False.
            poll_interval: Seconds between status checks.
            timeout: Max seconds to wait.
            on_progress: Optional callback(progress, message).

        Returns:
            Updated Video object.

        Example:
            video = client.regenerate_frame(
                project_id="my-project-id",
                frame_num=2,
                frame_description="A bar chart comparing CPU vs GPU performance",
                narration="GPUs outperform CPUs for parallel workloads by 10x.",
                keywords=["GPU", "CPU", "performance"],
                quality="premium",
                voice="Dennis",
                voice_tier="premium",
                regenerate_narration=True,
            )
        """
        if quality not in ("basic", "premium"):
            raise ValueError("quality must be 'basic' or 'premium'")
        proj = self.get_video(project_id)
        # Compute next version number from existing versions on this frame
        next_version = 1
        for s in proj._Video__raw.get("scenes", []):
            if s.get("id") == frame_num:
                versions = s.get("versions") or []
                next_version = len(versions) + 1
                break
        total_scenes = len(proj._Video__raw.get("scenes", []))
        payload = {
            "sceneDescription": frame_description,
            "narration": narration,
            "keywords": keywords or [],
            "voiceId": voice,
            "qualityTier": quality,
            F_ASSET_PREFIX: proj._Video__raw.get(F_ASSET_PREFIX, ""),
            "sceneNum": frame_num,
            "versionNum": next_version,
            "totalScenes": total_scenes,
            "videoType": video_type,
        }
        if voice_tier == VOICE_TIER_PREMIUM:
            payload[F_VOICE_PROVIDER] = F_PROVIDER_PREM
        if regenerate_narration:
            payload["regenerateNarration"] = True
        if kwargs.get("_is_new_scene"):
            payload["isNewScene"] = True
        if kwargs.get("_ai_generated"):
            payload["aiGenerated"] = True
        data = self._post(f"{EXT}/generate-scene", payload)
        job = VideoJob(job_id=data["jobId"], project_id=project_id, client=self)
        video = job.wait(poll_interval=poll_interval, timeout=timeout, on_progress=on_progress)

        # Apply job result back to the project (including version history).
        if job._result:
            vis_key = job._result.get(F_VISUAL_SHORT) or job._result.get(F_VISUAL_KEY)
            audio_key = job._result.get(F_AUDIO_SHORT) or job._result.get(F_AUDIO_KEY)
            duration = job._result.get("duration")
            result_narration = job._result.get("narration")
            if vis_key or audio_key:
                raw = video._Video__raw
                for s in raw.get("scenes", []):
                    if s.get("id") == frame_num:
                        from datetime import datetime
                        voice_provider = F_PROVIDER_PREM if voice_tier == VOICE_TIER_PREMIUM else F_PROVIDER_STD
                        new_version = {
                            F_VISUAL_KEY: vis_key,
                            F_AUDIO_KEY: audio_key,
                            "duration": duration or s.get("duration", 8),
                            "narration": result_narration or s.get("narration", ""),
                            "visualDescription": s.get("visualDescription", ""),
                            "keywords": list(s.get("keywords", [])),
                            "qualityTier": quality,
                            "voiceId": voice,
                            F_VOICE_PROVIDER: voice_provider,
                            "generatedAt": datetime.now().strftime("%b %d, %H:%M"),
                        }
                        # Initialize versions array if missing
                        if not s.get("versions"):
                            if s.get(F_VISUAL_KEY):
                                s["versions"] = [{
                                    F_VISUAL_KEY: s.get(F_VISUAL_KEY),
                                    F_AUDIO_KEY: s.get(F_AUDIO_KEY),
                                    "duration": s.get("duration", 8),
                                    "narration": s.get("narration", ""),
                                    "visualDescription": s.get("visualDescription", ""),
                                    "keywords": list(s.get("keywords", [])),
                                    "qualityTier": s.get("qualityTier", "enhanced"),
                                    "voiceId": s.get("voiceId"),
                                    F_VOICE_PROVIDER: s.get(F_VOICE_PROVIDER),
                                    "generatedAt": "Original",
                                }]
                            else:
                                s["versions"] = []
                        s["versions"].append(new_version)
                        s["activeVersion"] = len(s["versions"]) - 1
                        if vis_key:
                            s[F_VISUAL_KEY] = vis_key
                        if audio_key:
                            s[F_AUDIO_KEY] = audio_key
                        if duration:
                            s["duration"] = duration
                        if result_narration:
                            s["narration"] = result_narration
                        s["qualityTier"] = quality
                        s["voiceId"] = voice
                        if voice_tier == VOICE_TIER_PREMIUM:
                            s[F_VOICE_PROVIDER] = F_PROVIDER_PREM
                        else:
                            s[F_VOICE_PROVIDER] = F_PROVIDER_STD
                        s["status"] = "ready"
                        s["needsRegeneration"] = False
                        break
                self.__save_project(raw)
                return self.get_video(project_id)

        return video

    def regenerate_narration(
        self,
        project_id: str,
        frame_num: int,
        frame_description: str = "",
        keywords: Optional[List[str]] = None,
        voice: str = "Stephen",
        voice_tier: str = "standard",
        poll_interval: float = 3.0,
        timeout: float = 120.0,
        on_progress=None,
    ) -> Video:
        """
        Regenerate narration for a frame using AI. The visual is unchanged —
        only the narration text and audio are regenerated. Costs 1 credit
        (+1 if premium voice). Blocks until done.

        Args:
            project_id: The project ID.
            frame_num: Frame number (1-based).
            frame_description: Visual description used as context for
                narration generation. If empty, uses the frame's existing
                visual description.
            keywords: Keywords for context.
            voice: Voice ID for TTS. For premium tier, use any voice ID
                from list_premium_voices().
            voice_tier: "standard" or "premium" voice tier.
            poll_interval: Seconds between status checks.
            timeout: Max seconds to wait.
            on_progress: Optional callback(progress, message).

        Returns:
            Updated Video object with new narration and audio.

        Example:
            video = client.regenerate_narration(
                project_id="my-project-id",
                frame_num=2,
                frame_description="A bar chart comparing CPU vs GPU performance",
                keywords=["GPU", "CPU", "performance"],
            )
        """
        proj = self.get_video(project_id)
        # Find the frame to get its visual description if not provided
        target_scene = None
        for s in proj._Video__raw.get("scenes", []):
            if s.get("id") == frame_num:
                target_scene = s
                break
        if not target_scene:
            raise WhiteframesError(f"Frame {frame_num} not found in project")
        desc = frame_description or target_scene.get("visualDescription", "")
        if not desc:
            raise WhiteframesError("frame_description is required (or frame must have a visualDescription)")

        # Compute version number for unique audio key
        versions = target_scene.get("versions") or []
        next_version = len(versions) + 1

        payload = {
            "sceneDescription": desc,
            "keywords": keywords or target_scene.get("keywords", []),
            "voiceId": voice,
            F_ASSET_PREFIX: proj._Video__raw.get(F_ASSET_PREFIX, ""),
            "sceneNum": frame_num,
            "versionNum": next_version,
        }
        if voice_tier == VOICE_TIER_PREMIUM:
            payload[F_VOICE_PROVIDER] = F_PROVIDER_PREM
        data = self._post(f"{EXT}/regenerate-narration", payload)
        job = VideoJob(job_id=data["jobId"], project_id=project_id, client=self)
        video = job.wait(poll_interval=poll_interval, timeout=timeout, on_progress=on_progress)

        # Apply narration result back to the project
        if job._result:
            audio_key = job._result.get(F_AUDIO_SHORT) or job._result.get(F_AUDIO_KEY)
            duration = job._result.get("duration")
            new_narration = job._result.get("narration")
            if new_narration:
                raw = video._Video__raw
                for s in raw.get("scenes", []):
                    if s.get("id") == frame_num:
                        s["narration"] = new_narration
                        if audio_key:
                            s[F_AUDIO_KEY] = audio_key
                        if duration:
                            s["duration"] = duration
                        break
                self.__save_project(raw)
                return self.get_video(project_id)

        return video

    def fix_frame(
        self,
        project_id: str,
        frame_num: int,
        instruction: str,
        quality: str = "basic",
        poll_interval: float = 3.0,
        timeout: float = 300.0,
        on_progress=None,
    ) -> Video:
        """
        Apply a surgical AI fix to a frame's visual. Blocks until done.

        Args:
            project_id: The project ID.
            frame_num: Frame number to fix (1-based).
            instruction: Natural language instruction for the fix (max 2,000 chars).
                         e.g. "Make the title larger", "Change the chart color to blue"
            quality: "basic" (1 credit) or "premium" (3 credits).
            poll_interval: Seconds between status checks.
            timeout: Max seconds to wait.
            on_progress: Optional callback(progress, message).

        Returns:
            Updated Video object.

        Example:
            video = client.fix_frame(
                project_id="my-project-id",
                frame_num=2,
                instruction="Make the title text larger and change color to blue",
            )

            # Use premium model for more complex fixes
            video = client.fix_frame(
                project_id="my-project-id",
                frame_num=2,
                instruction="Redesign the chart with gradient fills and 3D effects",
                quality="premium",
            )
        """
        if len(instruction) > 2000:
            raise ValueError("instruction must be 2,000 characters or fewer")
        if quality not in ("basic", "premium"):
            raise ValueError("quality must be 'basic' or 'premium'")

        proj = self.get_video(project_id)
        frame = next((s for s in proj.frames if s.id == frame_num), None)
        if not frame or not frame.has_visual:
            raise WhiteframesError(f"Frame {frame_num} not found or has no visual")
        # Look up the frame's visual asset reference
        raw_scene = next((s for s in proj._Video__raw.get("scenes", []) if s.get("id") == frame_num), {})
        vis_key = raw_scene.get(F_VISUAL_KEY) or raw_scene.get(F_VISUAL_ALT)

        payload = {
            F_VISUAL_KEY: vis_key,
            "instruction": instruction,
            "projectId": project_id,
            "sceneNum": frame_num,
            "qualityTier": quality,
        }
        data = self._post(f"{EXT}/fix-scene", payload)
        job = VideoJob(job_id=data["jobId"], project_id=project_id, client=self)
        video = job.wait(poll_interval=poll_interval, timeout=timeout, on_progress=on_progress)

        # Apply job result back to the project (including version history)
        if job._result:
            vis_key = job._result.get(F_VISUAL_SHORT) or job._result.get(F_VISUAL_KEY)
            if vis_key:
                raw = video._Video__raw
                for s in raw.get("scenes", []):
                    if s.get("id") == frame_num:
                        from datetime import datetime
                        if not s.get("versions"):
                            s["versions"] = [{
                                F_VISUAL_KEY: s.get(F_VISUAL_KEY),
                                F_AUDIO_KEY: s.get(F_AUDIO_KEY),
                                "narration": s.get("narration", ""),
                                "visualDescription": s.get("visualDescription", ""),
                                "keywords": list(s.get("keywords", [])),
                                "duration": s.get("duration", 8),
                                "qualityTier": s.get("qualityTier", "enhanced"),
                                "generatedAt": "Original",
                                "trigger": "initial",
                            }]
                        fix_version = {
                            F_VISUAL_KEY: vis_key,
                            F_AUDIO_KEY: s.get(F_AUDIO_KEY),
                            "narration": s.get("narration", ""),
                            "visualDescription": s.get("visualDescription", ""),
                            "keywords": list(s.get("keywords", [])),
                            "duration": s.get("duration", 8),
                            "qualityTier": quality,
                            "generatedAt": datetime.now().strftime("%b %d, %H:%M"),
                            "trigger": "fix",
                            "regenPrompt": instruction,
                        }
                        s["versions"].append(fix_version)
                        s["activeVersion"] = len(s["versions"]) - 1
                        s[F_VISUAL_KEY] = vis_key
                        break
                self.__save_project(raw)
                return self.get_video(project_id)

        return video

    # ─── API key management ────────────────────────────────────────────────

    def list_api_keys(self) -> List[Dict]:
        """List all your API keys (metadata only, no key values)."""
        return self._get(f"{EXT}/keys").get("keys", [])

    def create_api_key(self, name: str) -> Dict:
        """
        Create a new API key. The raw key is returned ONCE - save it.

        Returns:
            Dict with: apiKeyId, key (raw, save this!), name, createdAt.
        """
        return self._post(f"{EXT}/keys", {"name": name})

    def revoke_api_key(self, api_key_id: str) -> bool:
        """Revoke an API key by its ID."""
        self._delete(f"{EXT}/keys/{api_key_id}")
        return True

    # ─── Brand & style ─────────────────────────────────────────────────────────

    def get_brand(self) -> Dict[str, Any]:
        """
        Get your account brand settings (colors, font, logo, watermark).

        Returns:
            Dict with: primaryColor, accentColor, fontFamily, logoS3Key,
            watermarkText, logoPosition, logoBase64.
            Returns an empty dict if no brand settings have been saved.

        Example:
            brand = client.get_brand()
            print(f"Primary color: {brand.get('primaryColor')}")
            print(f"Font: {brand.get('fontFamily')}")
        """
        data = self._get(f"{EXT}/user/brand")
        return data.get("brand") or {}

    def set_brand(
        self,
        *,
        primary_color: Optional[str] = None,
        accent_color: Optional[str] = None,
        font_family: Optional[str] = None,
        watermark_text: Optional[str] = None,
        logo_base64: Optional[str] = None,
        logo_position: Optional[str] = None,
        logo_s3_key: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Save account-level brand settings. All fields are optional — only
        the fields you provide will be sent.

        Args:
            primary_color: Hex color string for primary elements (e.g. "#3B82F6").
            accent_color: Hex color string for accents (e.g. "#10B981").
            font_family: Font for titles and text. Allowed values:
                         "Caveat", "Patrick Hand", "Indie Flower", "Kalam",
                         "Architects Daughter", "Permanent Marker",
                         "Shadows Into Light". Default handwriting style
                         is used when not set.
            watermark_text: Text watermark overlaid on each frame (max 50 chars).
                            Pass "" to remove.
            logo_base64: Base64-encoded PNG/JPG logo image. The server stores it
                         and returns a logoS3Key for future reference.
            logo_position: Where to place the logo. One of: "bottom-left" (default),
                           "bottom-right", "top-left", "top-right".
            logo_s3_key: S3 key of a previously uploaded logo asset. Use instead
                         of logo_base64 to reference an existing upload.

        Returns:
            Updated brand dict with all current settings.

        Example:
            brand = client.set_brand(
                primary_color="#3B82F6",
                accent_color="#10B981",
                font_family="Kalam",
            )

            # Add a watermark
            brand = client.set_brand(watermark_text="© MyCompany")

            # Upload a logo from file
            import base64
            with open("logo.png", "rb") as f:
                logo_b64 = base64.b64encode(f.read()).decode()
            brand = client.set_brand(
                logo_base64=logo_b64,
                logo_position="bottom-right",
            )
        """
        _ALLOWED_FONTS = {
            "Caveat", "Patrick Hand", "Indie Flower", "Kalam",
            "Architects Daughter", "Permanent Marker", "Shadows Into Light",
        }
        _ALLOWED_POSITIONS = {"bottom-left", "bottom-right", "top-left", "top-right"}
        if font_family and font_family not in _ALLOWED_FONTS:
            raise ValueError(
                f"Invalid font_family '{font_family}'. Choose from: {', '.join(sorted(_ALLOWED_FONTS))}"
            )
        if logo_position and logo_position not in _ALLOWED_POSITIONS:
            raise ValueError(
                f"Invalid logo_position '{logo_position}'. Choose from: {', '.join(_ALLOWED_POSITIONS)}"
            )
        if watermark_text and len(watermark_text) > 50:
            raise ValueError("watermark_text must be 50 characters or fewer")

        payload: Dict[str, Any] = {}
        if primary_color is not None:
            payload["primaryColor"] = primary_color
        if accent_color is not None:
            payload["accentColor"] = accent_color
        if font_family is not None:
            payload["fontFamily"] = font_family
        if watermark_text is not None:
            payload["watermarkText"] = watermark_text
        if logo_base64 is not None:
            payload["logoBase64"] = logo_base64
        if logo_position is not None:
            payload["logoPosition"] = logo_position
        if logo_s3_key is not None:
            payload["logoS3Key"] = logo_s3_key

        data = self._post(f"{EXT}/user/brand", payload)
        return data.get("brand") or {}

    # ─── Account & usage ────────────────────────────────────────────────────

    def get_profile(self) -> Dict[str, Any]:
        """
        Get your user profile including credit balance, display name, and email.

        Returns:
            Dict with: userId, displayName, email, organization, role, credits.

        Example:
            profile = client.get_profile()
            print(f"Credits remaining: {profile['credits']}")
            print(f"Name: {profile['displayName']}")
        """
        data = self._get(f"{EXT}/user/profile")
        user = data.get("user", data)
        user.pop("isAdmin", None)
        return user

    def get_usage(self) -> List[Dict]:
        """
        Get your full API call history across all API keys.

        Returns:
            List of call log entries with endpoint, creditsUsed, timestamp, etc.

        Example:
            calls = client.get_usage()
            total = sum(c.get("creditsUsed", 0) for c in calls)
            print(f"Total credits used: {total}")
        """
        all_calls: List[Dict] = []
        next_token = None
        while True:
            params: Dict[str, str] = {"limit": "200"}
            if next_token:
                params["nextToken"] = next_token
            data = self._get(f"{EXT}/calls", params=params)
            all_calls.extend(data.get("calls", []))
            next_token = data.get("nextToken")
            if not next_token:
                break
        return all_calls

    def get_stats(self) -> "UsageStats":
        """
        Get your account usage statistics — overall totals and per-month breakdown.

        Returns:
            UsageStats with overall totals and a list of MonthlyStats.

        Example:
            stats = client.get_stats()
            print(f"Total videos: {stats.total_videos}")
            print(f"Downloads: {stats.downloads_count}")
            print(f"Credits: {stats.credits}")

            # Monthly breakdown
            for m in stats.monthly:
                print(f"  {m.month}: {m.videos_created} videos, {m.downloads_count} downloads")

            # Quality breakdown
            print(f"Basic: {stats.videos_by_quality.get('basic', 0)}")
            print(f"Enhanced: {stats.videos_by_quality.get('enhanced', 0)}")
            print(f"Premium: {stats.videos_by_quality.get('premium', 0)}")
        """
        data = self._get(f"{EXT}/user/stats")
        return UsageStats.from_dict(data.get("stats", data))

    # ─── Frame management helpers ─────────────────────────────────────────

    def add_frame(
        self,
        project_id: str,
        frame_description: str,
        narration: str = "",
        keywords: Optional[List[str]] = None,
        position: Optional[int] = None,
        voice: str = "Stephen",
        quality: str = "basic",
        video_type: str = "whiteboard",
        voice_tier: str = "standard",
        poll_interval: float = 3.0,
        timeout: float = 300.0,
        on_progress=None,
    ) -> Video:
        """
        Add a new frame to an existing video project. Generates the visual and
        audio using AI, then inserts the frame at the given position.

        Args:
            project_id: The project ID.
            frame_description: Visual description of what to draw. Max 5,000 chars.
            narration: Narration text for the frame. If empty, AI generates it.
            keywords: Keywords for the frame.
            position: Insert position (0-based). None = append at end.
            voice: Voice ID for audio. For premium tier, use any voice ID from
                   list_premium_voices().
            quality: "basic" or "premium" (higher quality).
            video_type: Visual style.
            voice_tier: "standard" or "premium" voice tier. Default: standard.
            poll_interval: Seconds between status checks.
            timeout: Max seconds to wait.
            on_progress: Optional callback(progress, message).

        Returns:
            Updated Video object with the new frame.

        Example:
            video = client.add_frame(
                project_id="my-project-id",
                frame_description="A world map showing global internet usage",
                narration="Over 5 billion people now have internet access.",
                keywords=["internet", "global", "map"],
                position=2,  # insert as 3rd frame
            )
            print(f"Now has {video.frame_count} frames")
        """
        proj = self.get_video(project_id)
        raw = proj._Video__raw

        # If narration is empty, use AI to generate narration + refine description
        final_narration = narration
        final_description = frame_description
        final_keywords = keywords or []
        if not narration:
            content = self._post(f"{EXT}/generate-scene-content", {
                "prompt": frame_description,
                "videoContext": raw.get("title") or raw.get("prompt") or "",
            })
            final_narration = content.get("narration", "")
            final_description = content.get("visualDescription", frame_description)
            final_keywords = content.get("keywords", final_keywords)

        # Determine the new frame number
        existing_ids = [s.get("id", 0) for s in raw.get("scenes", [])]
        new_id = max(existing_ids, default=0) + 1

        # Create placeholder frame
        new_scene = {
            "id": new_id,
            "narration": final_narration,
            "visualDescription": final_description,
            "keywords": final_keywords,
            "status": "pending",
        }

        scenes = list(raw.get("scenes", []))
        if position is not None and 0 <= position <= len(scenes):
            scenes.insert(position, new_scene)
        else:
            scenes.append(new_scene)
        raw["scenes"] = scenes
        raw["sceneCount"] = len(scenes)

        self.__save_project(raw)

        ai_generated = not narration  # AI generated if narration was empty
        return self.regenerate_frame(
            project_id=project_id,
            frame_num=new_id,
            frame_description=final_description,
            narration=final_narration,
            keywords=final_keywords,
            voice=voice,
            quality=quality,
            video_type=video_type,
            voice_tier=voice_tier,
            poll_interval=poll_interval,
            timeout=timeout,
            on_progress=on_progress,
            _is_new_scene=True,
            _ai_generated=ai_generated,
        )

    def delete_frame(self, project_id: str, frame_num: int) -> Video:
        """
        Delete a frame from a video project by its frame number.

        Args:
            project_id: The project ID.
            frame_num: The frame ID to delete (from frame.id, 1-based).

        Returns:
            Updated Video object without the deleted frame.

        Example:
            video = client.delete_frame("my-project-id", frame_num=3)
            print(f"Now has {video.frame_count} frames")
        """
        proj = self.get_video(project_id)
        raw = proj._Video__raw
        original_count = len(raw.get("scenes", []))
        raw["scenes"] = [s for s in raw.get("scenes", []) if s.get("id") != frame_num]
        if len(raw["scenes"]) == original_count:
            raise WhiteframesError(f"Frame {frame_num} not found in project")
        raw["sceneCount"] = len(raw["scenes"])

        audit = {
            "type": "scene-deleted",
            "sceneId": frame_num,
            "timestamp": self._et_now(),
            "detail": f"Frame {frame_num} deleted",
            "total": 0,
        }
        if "costs" not in raw:
            raw["costs"] = {}
        raw["costs"].setdefault("edits", []).append(audit)

        self.__save_project(raw)
        return self.get_video(project_id)

    def reorder_frames(self, project_id: str, frame_order: List[int]) -> Video:
        """
        Rearrange the frames in a video project.

        Args:
            project_id: The project ID.
            frame_order: List of frame IDs in the desired order.
                         e.g. [3, 1, 2, 4] to move frame 3 to the front.

        Returns:
            Updated Video object with reordered frames.

        Example:
            # Move frame 3 to the front
            video = client.reorder_frames("my-project-id", [3, 1, 2, 4])

            # Reverse all frames
            video = client.get_video("my-project-id")
            ids = [s.id for s in video.frames]
            video = client.reorder_frames("my-project-id", list(reversed(ids)))
        """
        proj = self.get_video(project_id)
        raw = proj._Video__raw
        scene_map = {s.get("id"): s for s in raw.get("scenes", [])}
        if set(frame_order) != set(scene_map.keys()):
            missing = set(scene_map.keys()) - set(frame_order)
            extra = set(frame_order) - set(scene_map.keys())
            parts = []
            if missing:
                parts.append(f"missing: {sorted(missing)}")
            if extra:
                parts.append(f"not found: {sorted(extra)}")
            raise WhiteframesError(f"frame_order must contain all frame IDs exactly once ({', '.join(parts)})")
        reordered = []
        for sid in frame_order:
            reordered.append(scene_map[sid])
        raw["scenes"] = reordered

        audit = {
            "type": "scene-reordered",
            "timestamp": self._et_now(),
            "detail": f"Reordered to [{', '.join(str(s) for s in frame_order)}]",
            "total": 0,
        }
        if "costs" not in raw:
            raw["costs"] = {}
        raw["costs"].setdefault("edits", []).append(audit)

        self.__save_project(raw)
        return self.get_video(project_id)

    # ─── Frame version management ─────────────────────────────────────────

    def list_frame_versions(self, project_id: str, frame_num: int) -> List[Dict]:
        """
        List all versions of a frame.

        Args:
            project_id: The project ID.
            frame_num: The frame ID (1-based).

        Returns:
            List of version dicts, each with: index, duration, narration,
            visualDescription, keywords, qualityTier, generatedAt, trigger,
            active (bool).

        Example:
            versions = client.list_frame_versions("my-project-id", frame_num=1)
            for v in versions:
                print(f"v{v['index'] + 1}: {v['generatedAt']} {'(active)' if v['active'] else ''}")
        """
        proj = self.get_video(project_id)
        scene = next((s for s in proj._Video__raw.get("scenes", []) if s.get("id") == frame_num), None)
        if not scene:
            raise WhiteframesError(f"Frame {frame_num} not found in project")
        versions = scene.get("versions") or []
        active = scene.get("activeVersion", 0)
        return [
            {
                "index": i,
                "duration": v.get("duration"),
                "narration": v.get("narration", ""),
                "visualDescription": v.get("visualDescription", ""),
                "keywords": v.get("keywords", []),
                "qualityTier": v.get("qualityTier", "enhanced"),
                "generatedAt": v.get("generatedAt", ""),
                "trigger": v.get("trigger", ""),
                "active": i == active,
            }
            for i, v in enumerate(versions)
        ]

    def switch_frame_version(self, project_id: str, frame_num: int, version_index: int) -> Video:
        """
        Switch a frame to a different version.

        Args:
            project_id: The project ID.
            frame_num: The frame ID (1-based).
            version_index: The version index to switch to (0-based).

        Returns:
            Updated Video object.

        Example:
            versions = client.list_frame_versions("my-project-id", frame_num=1)
            # Switch back to original
            video = client.switch_frame_version("my-project-id", frame_num=1, version_index=0)
        """
        proj = self.get_video(project_id)
        raw = proj._Video__raw
        scene = next((s for s in raw.get("scenes", []) if s.get("id") == frame_num), None)
        if not scene:
            raise WhiteframesError(f"Frame {frame_num} not found in project")
        versions = scene.get("versions") or []
        if not versions or version_index < 0 or version_index >= len(versions):
            raise WhiteframesError(f"Version {version_index} not found (frame has {len(versions)} versions)")
        prev_active = scene.get("activeVersion", len(versions) - 1)
        if prev_active == version_index:
            return proj

        v = versions[version_index]
        scene["activeVersion"] = version_index
        scene[F_VISUAL_KEY] = v.get(F_VISUAL_KEY)
        scene[F_AUDIO_KEY] = v.get(F_AUDIO_KEY)
        scene["duration"] = v.get("duration", scene.get("duration", 8))
        scene["narration"] = v.get("narration", "")
        scene["visualDescription"] = v.get("visualDescription", "")
        scene["keywords"] = list(v.get("keywords", []))
        if v.get("qualityTier"):
            scene["qualityTier"] = v["qualityTier"]

        # Append edit record
        audit = {
            "type": "scene-version-switched",
            "sceneId": frame_num,
            "timestamp": self._et_now(),
            "detail": f"Frame {frame_num}: v{prev_active + 1} → v{version_index + 1}",
            "total": 0,
        }
        if "costs" not in raw:
            raw["costs"] = {}
        raw["costs"].setdefault("edits", []).append(audit)

        self.__save_project(raw)
        return self.get_video(project_id)

    def delete_frame_version(self, project_id: str, frame_num: int, version_index: int) -> Video:
        """
        Delete a specific version of a frame. Cannot delete the last remaining version.

        Args:
            project_id: The project ID.
            frame_num: The frame ID (1-based).
            version_index: The version index to delete (0-based).

        Returns:
            Updated Video object.

        Example:
            # Delete the original version (v0)
            video = client.delete_frame_version("my-project-id", frame_num=1, version_index=0)
        """
        proj = self.get_video(project_id)
        raw = proj._Video__raw
        scene = next((s for s in raw.get("scenes", []) if s.get("id") == frame_num), None)
        if not scene:
            raise WhiteframesError(f"Frame {frame_num} not found in project")
        versions = scene.get("versions") or []
        if not versions or version_index < 0 or version_index >= len(versions):
            raise WhiteframesError(f"Version {version_index} not found (frame has {len(versions)} versions)")
        if len(versions) <= 1:
            raise WhiteframesError("Cannot delete the last remaining version")

        new_versions = [v for i, v in enumerate(versions) if i != version_index]
        active = scene.get("activeVersion", 0)
        if version_index == active:
            new_active = max(0, len(new_versions) - 1)
        elif version_index < active:
            new_active = active - 1
        else:
            new_active = active

        scene["versions"] = new_versions
        scene["activeVersion"] = new_active

        v = new_versions[new_active]
        scene[F_VISUAL_KEY] = v.get(F_VISUAL_KEY)
        scene[F_AUDIO_KEY] = v.get(F_AUDIO_KEY)
        scene["duration"] = v.get("duration", scene.get("duration", 8))
        scene["narration"] = v.get("narration", "")
        scene["visualDescription"] = v.get("visualDescription", "")
        scene["keywords"] = list(v.get("keywords", []))
        if v.get("qualityTier"):
            scene["qualityTier"] = v["qualityTier"]

        # Append edit record
        audit = {
            "type": "scene-version-deleted",
            "sceneId": frame_num,
            "timestamp": self._et_now(),
            "detail": f"Frame {frame_num}: deleted v{version_index + 1}",
            "total": 0,
        }
        if "costs" not in raw:
            raw["costs"] = {}
        raw["costs"].setdefault("edits", []).append(audit)

        self.__save_project(raw)
        return self.get_video(project_id)

    # ─── Private helpers ───────────────────────────────────────────────────

    @staticmethod
    def _et_now() -> str:
        """Return current timestamp as YYYY-MM-DD HH:MI:SS in US Eastern."""
        from datetime import datetime, timezone, timedelta
        try:
            from zoneinfo import ZoneInfo
            tz = ZoneInfo("America/New_York")
        except ImportError:
            try:
                from backports.zoneinfo import ZoneInfo
                tz = ZoneInfo("America/New_York")
            except ImportError:
                tz = timezone(timedelta(hours=-5))
        return datetime.now(tz).strftime("%Y-%m-%d %H:%M:%S")

    def _get_user_id(self) -> str:
        """Fetch and cache the current user's ID."""
        if not self._user_id:
            data = self._get(f"{EXT}/user/profile")
            self._user_id = data["user"]["userId"]
        return self._user_id

    def _upload_file(self, file_path: str) -> tuple:
        """Upload a local file and return (key, mime_type, file_name)."""
        import base64
        import mimetypes
        import os

        file_name = os.path.basename(file_path)
        mime_type, _ = mimetypes.guess_type(file_path)
        mime_type = mime_type or "application/octet-stream"

        file_size = os.path.getsize(file_path)
        if file_size > 4_500_000:
            raise ValueError(
                f"File too large ({file_size:,} bytes). Maximum is ~4.5 MB. "
                "Base64 encoding inflates size by ~33%, exceeding the upload limit."
            )

        user_id = self._get_user_id()
        ts = int(time.time() * 1000)
        upload_key = f"{ASSET_PATH_PFX}{user_id}{ASSET_PATH_SFX}{ts}-{file_name}"

        with open(file_path, "rb") as f:
            data = base64.b64encode(f.read()).decode()

        self._post(f"{EXT}/upload-asset", {
            "key": upload_key,
            "contentType": mime_type,
            "data": data,
        })
        return upload_key, mime_type, file_name

    # ─── HTTP helpers ──────────────────────────────────────────────────────

    def _request(self, method: str, path: str, **kwargs) -> dict:
        """HTTP request with retry on transient failures (timeouts, 5xx, connection errors)."""
        url = f"{self._base_url}{path}"
        kwargs.setdefault("timeout", self._timeout)
        last_exc = None
        for attempt in range(3):
            try:
                resp = self._session.request(method, url, **kwargs)
                if resp.status_code >= 500 and attempt < 2:
                    time.sleep(2 ** attempt)
                    continue
                if resp.status_code == 429 and attempt < 2:
                    time.sleep(2 ** attempt + 3)  # longer backoff for rate limits
                    continue
                return self._handle(resp)
            except (requests.exceptions.Timeout, requests.exceptions.ConnectionError) as e:
                last_exc = e
                if attempt < 2:
                    time.sleep(2 ** attempt)
                    continue
                raise WhiteframesError(f"Request failed after 3 attempts: {e}", status_code=None)
        raise WhiteframesError(f"Request failed after 3 attempts: {last_exc}", status_code=None)

    def _get(self, path: str, params: dict = None) -> dict:
        return self._request("GET", path, params=params)

    def _post(self, path: str, body: dict) -> dict:
        return self._request("POST", path, json=body)

    def _delete(self, path: str) -> dict:
        return self._request("DELETE", path)

    def _handle(self, resp: requests.Response) -> dict:
        # Detect when CloudFront converts an API error (403/404) into 200 + HTML
        # (CloudFront custom error responses apply to all origins, including API Gateway)
        content_type = resp.headers.get("Content-Type", "")
        if resp.ok and "text/html" in content_type:
            raise WhiteframesError(
                "Request failed — not found or not authorized",
                status_code=403,
            )

        try:
            data = resp.json()
        except Exception:
            data = {"error": resp.text}

        if resp.status_code == 402:
            raise InsufficientCreditsError(
                data.get("error", "Insufficient credits"),
                status_code=402,
            )
        if resp.status_code == 400 and "Content rejected" in data.get("error", ""):
            raise ContentRejectedError(data["error"], status_code=400)
        if not resp.ok:
            raise WhiteframesError(
                data.get("error", f"HTTP {resp.status_code}"),
                status_code=resp.status_code,
            )
        return data

    def __repr__(self):
        masked = self._api_key[:10] + "..." if len(self._api_key) > 10 else "***"
        return f"<WhiteframesAI api_key={masked!r}>"
