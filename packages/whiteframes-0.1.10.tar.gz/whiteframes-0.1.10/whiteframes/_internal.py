"""Private SDK constants."""

from base64 import b64decode as _d

def _b(s: str) -> str:
    return _d(s).decode()

BASE_URL = _b("aHR0cHM6Ly9kMmxxeWJ6MnJnM21idy5jbG91ZGZyb250Lm5ldA==")
EXT = "/api/ext"

F_VISUAL_KEY = _b("czNTdmdLZXk=")
F_VISUAL_ALT = _b("czNWaXN1YWxLZXk=")
F_AUDIO_KEY = _b("czNBdWRpb0tleQ==")
F_ASSET_PREFIX = _b("czNQcmVmaXg=")
F_DOC_ASSET_KEY = _b("ZG9jdW1lbnRTM0tleQ==")
F_VISUAL_SHORT = _b("c3ZnS2V5")
F_AUDIO_SHORT = _b("YXVkaW9LZXk=")
F_EDITS = _b("ZWRpdHM=")

ASSET_PATH_PFX = _b("dXNlcnMv")
ASSET_PATH_SFX = _b("L3VwbG9hZHMv")


VOICE_IDS = [
    # English
    "Stephen", "Ruth", "Matthew", "Joanna", "Amy", "Brian", "Olivia",
    # French
    "Lea", "Remi",
    # German
    "Vicki", "Daniel",
    # Spanish
    "Lucia", "Sergio", "Mia", "Andres",
    # Italian
    "Bianca", "Adriano",
    # Portuguese
    "Camila", "Thiago",
    # Japanese
    "Kazuha", "Takumi",
    # Korean
    "Seoyeon",
    # Chinese
    "Zhiyu",
    # Hindi
    "Kajal",
    # Dutch
    "Laura",
    # Polish
    "Ola",
    # Arabic
    "Hala",
    # Turkish
    "Burcu",
    # Swedish
    "Elin",
    # Norwegian
    "Ida",
    # Danish
    "Sofie",
    # Finnish
    "Suvi",
    # Catalan
    "Arlet",
    # Welsh
    "Gwyneth",
    # Romanian
    "Carmen",
]

# Voice → BCP-47 language code mapping
VOICE_LANGUAGES = {
    "Stephen": "en-US", "Ruth": "en-US", "Matthew": "en-US", "Joanna": "en-US",
    "Amy": "en-GB", "Brian": "en-GB", "Olivia": "en-AU",
    "Lea": "fr-FR", "Remi": "fr-FR",
    "Vicki": "de-DE", "Daniel": "de-DE",
    "Lucia": "es-ES", "Sergio": "es-ES", "Mia": "es-MX", "Andres": "es-MX",
    "Bianca": "it-IT", "Adriano": "it-IT",
    "Camila": "pt-BR", "Thiago": "pt-BR",
    "Kazuha": "ja-JP", "Takumi": "ja-JP",
    "Seoyeon": "ko-KR",
    "Zhiyu": "cmn-CN",
    "Kajal": "hi-IN",
    "Laura": "nl-NL",
    "Ola": "pl-PL",
    "Hala": "ar-AE",
    "Burcu": "tr-TR",
    "Elin": "sv-SE",
    "Ida": "nb-NO",
    "Sofie": "da-DK",
    "Suvi": "fi-FI",
    "Arlet": "ca-ES",
    "Gwyneth": "cy-GB",
    "Carmen": "ro-RO",
}

# Supported languages: BCP-47 code → display name
LANGUAGES = {
    "en-US": "English (US)",
    "en-GB": "English (UK)",
    "en-AU": "English (AU)",
    "fr-FR": "French",
    "de-DE": "German",
    "es-ES": "Spanish",
    "es-MX": "Spanish (MX)",
    "it-IT": "Italian",
    "pt-BR": "Portuguese (BR)",
    "ja-JP": "Japanese",
    "ko-KR": "Korean",
    "cmn-CN": "Chinese",
    "hi-IN": "Hindi",
    "nl-NL": "Dutch",
    "pl-PL": "Polish",
    "ar-AE": "Arabic",
    "tr-TR": "Turkish",
    "sv-SE": "Swedish",
    "nb-NO": "Norwegian",
    "da-DK": "Danish",
    "fi-FI": "Finnish",
    "ca-ES": "Catalan",
    "cy-GB": "Welsh",
    "ro-RO": "Romanian",
    "ru-RU": "Russian",
    "he-IL": "Hebrew",
}
VIDEO_TYPES = [
    "whiteboard", "saas-demo", "infographic", "corporate", "architecture",
    "educational", "social-short", "pitch", "how-to", "storytelling",
    "news", "videocast", "quiz", "timeline", "comparison", "geo-map",
    "top-10", "did-you-know", "flashcard", "myth-vs-fact",
]

VOICE_TIER_STANDARD = "standard"
VOICE_TIER_PREMIUM = "premium"
F_VOICE_PROVIDER = _b("dm9pY2VQcm92aWRlcg==")
F_PROVIDER_STD = _b("cG9sbHk=")
F_PROVIDER_PREM = _b("aW53b3JsZA==")
PREMIUM_VOICES_EP = _b("aW53b3JsZC12b2ljZXM=")
