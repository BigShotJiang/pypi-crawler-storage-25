"""Whiteframes SDK exceptions."""


class WhiteframesError(Exception):
    """Base exception for Whiteframes SDK errors."""

    def __init__(self, message: str, status_code: int = None):
        super().__init__(message)
        self.status_code = status_code


class InsufficientCreditsError(WhiteframesError):
    """Raised when the account has insufficient credits."""
    pass


class ContentRejectedError(WhiteframesError):
    """Raised when content is rejected by moderation."""
    pass
