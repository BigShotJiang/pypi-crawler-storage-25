"""
Whiteframes AI Python SDK
~~~~~~~~~~~~~~~~~~~~~~~~~
Create AI-powered videos programmatically.

    from whiteframes import WhiteframesAI

    client = WhiteframesAI(api_key="wfai_your_key_here")
    video = client.create_video("Explain how neural networks work").wait()
"""

from .client import WhiteframesAI
from .models import Video, VideoJob, Frame, UsageStats, MonthlyStats
from .exceptions import WhiteframesError, InsufficientCreditsError, ContentRejectedError

__version__ = "0.1.10"
__all__ = [
    "WhiteframesAI",
    "Video",
    "VideoJob",
    "Frame",
    "UsageStats",
    "MonthlyStats",
    "WhiteframesError",
    "InsufficientCreditsError",
    "ContentRejectedError",
]
