"""
Parsers específicos para lojas de e-commerce.

Implementações concretas da interface StoresParserInterface para
diferentes lojas (Nike, Maze Shop, Beleza na Web, etc).
"""

import logging
import json
import html
from typing import Optional
from notify_utils.models import Product, ResponseData
from notify_utils.parsers.stores_parser_interface import StoresParserInterface
from notify_utils.parser import parse_price

logger = logging.getLogger(__name__)


class ParserError(Exception):
    """
    Exceção customizada para erros de parsing.

    Levantada quando:
    - Formato de dados inválido
    - Parser não suporta o tipo de dados (JSON/HTML)
    - Dados obrigatórios estão ausentes
    """
    pass

class NikeAPIGatewayJSONParser(StoresParserInterface):
    """
    Parser para API Gateway da Nike.

    Extrai produtos de respostas JSON da API Gateway da Nike.

    Exemplo:
        >>> parser = NikeAPIGatewayJSONParser()
        >>> products = parser.from_json(nike_api_response)
    """

    def from_json(self, json_data: dict) -> list[Product]:
        """
        Extrai produtos da Nike de dados JSON.

        Args:
            json_data: Dicionário contendo resposta JSON da API Gateway da Nike

        Returns:
            Lista de objetos Product extraídos (implementação pendente)

        Note:
            Implementação ainda não finalizada - retorna lista vazia
        """
        # TODO: Implementar lógica de parsing para Nike API Gateway
        logger.warning("NikeAPIGatewayJSONParser.from_json() não implementado ainda")
        return []

    def from_html(self, html_data: str) -> list[Product]:
        """
        HTML não suportado para Nike API Gateway.

        Args:
            html_data: String contendo HTML

        Raises:
            ParserError: Sempre - Nike API usa JSON, não HTML
        """
        raise ParserError("HTML parsing is not supported for Nike API Gateway.")
    
    def is_last_page(self, response: ResponseData) -> bool:
        """
        Verifica se a resposta indica que é a última página de resultados.
        Args:
            response: Objeto ResponseData contendo status e dados da resposta
        Returns:
            bool: True se for a última página, False caso contrário
        Raises:
            NotImplementedError: Se o método não for implementado
        """
        raise NotImplementedError("Pagination check is not implemented for Nike API Gateway yet.")

    def from_product_page_html(self, html_data: str) -> Optional[Product]:
        """
        Extrai um produto de uma página HTML de produto.

        Args:
            html_data: String contendo HTML da página de produto

        Returns:
            Objeto Product extraído ou None se não for possível extrair

        Raises:
            ParserError: Parser não suporta extração de página de produto HTML ainda
        """
        raise ParserError("Product page HTML parsing is not implemented for Nike API Gateway yet.")

    def from_product_api_json(self, json_data: dict) -> Optional[Product]:
        """
        Extrai um produto de dados JSON da API.

        Args:
            json_data: Dicionário contendo resposta JSON da API

        Returns:
            Objeto Product extraído ou None se não for possível extrair

        Raises:
            ParserError: Parser não suporta extração de produto via API JSON ainda
        """
        raise ParserError("Product API JSON parsing is not implemented for Nike API Gateway yet.")


class MazeAPIJSONParser(StoresParserInterface):
    """
    Parser para API da Maze Shop.

    Extrai produtos de respostas JSON da API da Maze Shop, incluindo:
    - ID do produto
    - Nome e descrição
    - Preços (atual e promocional)
    - Estoque e disponibilidade
    - URLs (produto e imagem)
    - SKU

    Validações automáticas:
    - Ignora produtos com preço inválido (≤ 0)
    - Converte preços com fallback seguro
    - Trata ausência de campos opcionais

    Exemplo:
        >>> parser = MazeAPIJSONParser()
        >>> products = parser.from_json(maze_api_response)
        >>> for product in products:
        ...     print(f"{product.name}: R$ {product.current_price}")
    """

    def from_json(self, json_data: dict) -> list[Product]:
        """
        Extrai produtos da Maze Shop de dados JSON.

        Args:
            json_data: Dicionário contendo resposta JSON da API da Maze Shop
                      Estrutura esperada:
                      {
                          "products": [
                              {
                                  "idProduct": "123",
                                  "name": "Nome Produto",
                                  "price": 129.90,
                                  "pricePromotion": 99.90,
                                  "stock": 10,
                                  "urlFriendly": "produto-slug",
                                  "imageHome": "//cdn.maze.com.br/img.jpg",
                                  "code": "SKU123"
                              }
                          ]
                      }

        Returns:
            Lista de objetos Product extraídos e formatados.
            Lista vazia se não houver produtos ou se campo 'products' não existir.

        Note:
            - Produtos com preço inválido (≤ 0 ou None) são ignorados
            - Se pricePromotion existe, é usado como current_price
            - Caso contrário, price é usado como current_price
            - URLs são automaticamente formatadas com prefixo da loja
        """
        products: list[Product] = []
        logger.debug("Parsing Maze Shop products from JSON")

        products_json = json_data.get("products", [])
        if not products_json:
            logger.warning("No products found in JSON data.")
            return []

        for product_json in products_json:
            # Extrai preços com fallback seguro
            price_promotion = product_json.get("pricePromotion")
            price = product_json.get("price")
            available = product_json.get("stock", 0) > 0

            # Converte para float, tratando None e valores inválidos
            try:
                if price_promotion and float(price_promotion) > 0:
                    current_price = float(price_promotion)
                    old_price = float(price) if price else 0.0
                else:
                    current_price = float(price) if price else 0.0
                    old_price = 0.0  # Sem promoção: não há preço antigo diferente
            except (ValueError, TypeError):
                logger.warning(f"Preço inválido para produto {product_json.get('idProduct')}, pulando.")
                continue

            # Valida se o preço atual é válido (> 0)
            if current_price <= 0:
                logger.debug(f"Produto {product_json.get('idProduct')} tem preço atual inválido (R$ {current_price}), pulando.")
                continue

            url_friendly = product_json.get('urlFriendly', '') or ''
            image_home = product_json.get("imageHome", "") or ''

            product = Product(
                product_id=str(product_json.get("idProduct", "")),
                name=product_json.get("name", None),
                current_price_float=current_price,
                old_price_float=old_price,
                url=f"https://www.maze.com.br/{url_friendly}" if url_friendly else "",
                image_url=f"https:{image_home}" if image_home else "",
                sku=product_json.get("code", None),
                available=available,
                marketplace_name="Maze Shop",
                seller="Maze Shop"
            )

            products.append(product)
        return products

    def from_html(self, html_data: str) -> list[Product]:
        raise ParserError("HTML parsing is not supported for Maze API.")
    
    def is_last_page(self, response: ResponseData) -> bool:
        if not response.is_json():
            logger.warning("Response is not JSON, cannot determine pagination.")
            return True
        
        if response.is_not_found():
            logger.info("Response indicates no more pages (404 Not Found).")
            return True
        

        json_data = response.to_json()
        if json_data is None:
            logger.warning("Falha ao parsear JSON da resposta, assumindo última página.")
            return True

        products = json_data.get("products", [])
        if not products:
            logger.info("No products found in response, assuming no more pages.")
            return True

        return False  # Assume there may be more pages if products are present

    def from_product_page_html(self, html_data: str) -> Optional[Product]:
        """
        Extrai um produto de uma página HTML de produto.

        Args:
            html_data: String contendo HTML da página de produto

        Returns:
            Objeto Product extraído ou None se não for possível extrair

        Raises:
            ParserError: Parser não suporta extração de página de produto HTML ainda
        """
        raise ParserError("Product page HTML parsing is not implemented for Maze Shop yet.")

    def from_product_api_json(self, json_data: dict) -> Optional[Product]:
        """
        Extrai um produto de dados JSON da API.

        Args:
            json_data: Dicionário contendo resposta JSON da API

        Returns:
            Objeto Product extraído ou None se não for possível extrair

        Raises:
            ParserError: Parser não suporta extração de produto via API JSON ainda
        """
        raise ParserError("Product API JSON parsing is not implemented for Maze Shop yet.")


class SephoraAPIJSONParser(StoresParserInterface):
    """
    Parser para API Constructor.io da Sephora Brasil.

    Extrai produtos de respostas JSON da API da Sephora (Constructor.io),
    expandindo variações (tamanhos) em produtos individuais.

    Características:
    - Expande variações: 1 produto com N variações → N produtos únicos
    - Cada variação vira um Product separado (ex: 18 produtos → 68 itens)
    - Nome combinado: "{masterProductName} - {value}"
    - Validações: preço > 0, availability == "in stock"
    - Lógica de preços: se sale_price < price → desconto real

    Estrutura JSON esperada:
    ```json
    {
      "response": {
        "results": [
          {
            "data": {
              "id": "11220124",
              "variation_id": "439867",
              "masterProductName": "Mist Perfumado Sol de Janeiro...",
              "brand": "SOL DE JANEIRO",
              "price": 199,
              "sale_price": 199,
              "availability": "in stock",
              "url": "https://www.sephora.com.br/...",
              "image_url": "/on/demandware.static/..."
            },
            "variations": [
              {
                "value": "SOL DE JAN BRAZILIAN WATE 90ML",
                "data": {
                  "variation_id": "439867",
                  "price": 199,
                  "sale_price": 199,
                  "availability": "in stock",
                  "url": "https://www.sephora.com.br/...",
                  "image_url": "/on/demandware.static/..."
                }
              }
            ]
          }
        ]
      }
    }
    ```

    Exemplo:
        >>> parser = SephoraAPIJSONParser()
        >>> products = parser.from_json(sephora_response)
        >>> print(f"Extraídos {len(products)} itens únicos")
        Extraídos 68 itens únicos
    """

    def from_json(self, json_data: dict) -> list[Product]:
        """
        Extrai produtos da Sephora de dados JSON, expandindo variações.

        Args:
            json_data: Dicionário contendo resposta JSON da API Sephora (Constructor.io)
                      Estrutura esperada:
                      {
                          "response": {
                              "results": [
                                  {
                                      "data": {
                                          "id": "11220124",
                                          "variation_id": "439867",
                                          "masterProductName": "Mist Perfumado...",
                                          "brand": "SOL DE JANEIRO",
                                          "price": 199,
                                          "sale_price": 199,
                                          "availability": "in stock",
                                          "url": "https://...",
                                          "image_url": "/on/demandware..."
                                      },
                                      "variations": [
                                          {
                                              "value": "SOL DE JAN BRAZILIAN WATE 90ML",
                                              "data": {
                                                  "variation_id": "439867",
                                                  "price": 199,
                                                  "sale_price": 199,
                                                  "availability": "in stock",
                                                  "url": "https://...",
                                                  "image_url": "/on/demandware..."
                                              }
                                          }
                                      ]
                                  }
                              ]
                          }
                      }

        Returns:
            Lista de objetos Product expandidos (1 por variação).
            Lista vazia se não houver produtos ou campo 'response.results' não existir.

        Note:
            - **Expande variações**: Cada variação vira um Product individual
            - Variações com `availability != "in stock"` são ignoradas
            - Variações com `price <= 0` ou `None` são ignoradas
            - Nome combinado: "{masterProductName} - {value}"
            - URLs com prefixo `/` são convertidas para absolutas
            - Imagens com prefixo `/` são convertidas para absolutas
            - Lógica de preços: se `sale_price < price` → desconto (old_price = price)

        Example:
            >>> # 18 produtos com 50 variações → 68 itens (produto principal + variações)
            >>> parser = SephoraAPIJSONParser()
            >>> products = parser.from_json(api_data)
            >>> for p in products:
            ...     print(f"{p.product_id}: {p.name} - R$ {p.current_price_float}")
        """
        products: list[Product] = []
        logger.debug("Parsing Sephora products from Constructor.io API (expanding variations)")

        # Navegar em response.results
        results = json_data.get("response", {}).get("results", [])
        if not results:
            logger.warning("No products found in response.results.")
            return []

        total_items_processed = 0
        total_items_ignored = 0

        for result in results:
            product_data = result.get("data", {})
            variations = result.get("variations", [])

            product_id = product_data.get("id")
            master_product_name = product_data.get("masterProductName", "")
            brand = product_data.get("brand", "")

            if not master_product_name:
                logger.debug(f"Product {product_id} has no masterProductName, skipping.")
                continue

            # Expandir cada variação em um Product individual
            for variation in variations:
                try:
                    variation_data = variation.get("data", {})
                    variation_value = variation.get("value", "")

                    variation_id = variation_data.get("variation_id")
                    if not variation_id:
                        logger.debug(f"Variation without ID in product {product_id}, skipping.")
                        total_items_ignored += 1
                        continue

                    # Validação 1: Disponibilidade
                    availability = variation_data.get("availability", "out of stock")
                    if availability != "in stock":
                        logger.debug(f"Variation {variation_id} is not in stock (availability={availability}), skipping.")
                        total_items_ignored += 1
                        continue

                    # Extrair preços
                    try:
                        price = float(variation_data.get("price", 0))
                        sale_price = float(variation_data.get("sale_price", price))
                    except (ValueError, TypeError) as e:
                        logger.warning(f"Invalid price for variation {variation_id}: {e}, skipping.")
                        total_items_ignored += 1
                        continue

                    # Validação 2: Preço válido
                    if price <= 0:
                        logger.debug(f"Variation {variation_id} has invalid price ({price}), skipping.")
                        total_items_ignored += 1
                        continue

                    # Lógica de preços: se sale_price < price → há desconto real
                    if sale_price < price:
                        current_price = sale_price
                        old_price = price
                    else:
                        current_price = price
                        old_price = 0.0

                    # Montar nome com descrição da variação
                    combined_name = f"{master_product_name} - {variation_value}" if variation_value else master_product_name

                    # URLs
                    variation_url = variation_data.get("url", "")
                    absolute_url = self._make_absolute_url(variation_url)

                    # Imagem
                    image_url = variation_data.get("image_url", "")
                    if image_url and image_url.startswith("/"):
                        image_url = f"https://www.sephora.com.br{image_url}"

                    # Criar Product
                    product = Product(
                        product_id=str(variation_id),  # variation_id é o ID único
                        name=combined_name,
                        current_price_float=current_price,
                        old_price_float=old_price,
                        url=absolute_url,
                        image_url=image_url,
                        sku=str(variation_id),
                        available=True,  # Já validado acima
                        marketplace_name="Sephora Brasil",
                        seller="Sephora Brasil"
                    )

                    products.append(product)
                    total_items_processed += 1

                except Exception as e:
                    logger.error(f"Unexpected error processing variation in product {product_id}: {e}")
                    total_items_ignored += 1
                    continue

        logger.info(
            f"Extracted {total_items_processed} unique variations from {len(results)} products "
            f"({total_items_ignored} variations ignored)"
        )

        return products

    def from_html(self, html_data: str) -> list[Product]:
        """
        HTML não suportado para Sephora API.

        Args:
            html_data: String contendo HTML

        Raises:
            ParserError: Sempre - Sephora API usa JSON, não HTML
        """
        raise ParserError("Sephora API usa JSON, não HTML. Use from_json().")

    def _make_absolute_url(self, relative_url: str) -> str:
        """
        Converte URL relativa para absoluta.

        Args:
            relative_url: URL relativa ou absoluta

        Returns:
            URL absoluta com domínio completo da Sephora
        """
        if not relative_url:
            return ''

        if relative_url.startswith('http'):
            return relative_url

        if relative_url.startswith('/'):
            return f"https://www.sephora.com.br{relative_url}"

        return f"https://www.sephora.com.br/{relative_url}"

    def is_last_page(self, response: ResponseData) -> bool:
        """
        Verifica se a resposta indica que não há mais páginas.

        Retorna True se:
        - Status 404 Not Found
        - OU response JSON sem produtos (response.results vazio ou ausente)

        Args:
            response: Objeto ResponseData com dados da resposta HTTP

        Returns:
            True se for a última página, False caso contrário
        """
        # Caso 1: 404 Not Found
        if response.is_not_found():
            return True

        # Caso 2: Response JSON sem produtos
        if response.is_json():
            json_data = response.to_json()
            if json_data:
                results = json_data.get("response", {}).get("results", [])
                if not results or len(results) == 0:
                    return True

        return False

    def from_product_page_html(self, html_data: str) -> Optional[Product]:
        """
        Extrai um produto de uma página HTML de produto.

        Args:
            html_data: String contendo HTML da página de produto

        Returns:
            Objeto Product extraído ou None se não for possível extrair

        Raises:
            ParserError: Parser não suporta extração de página de produto HTML ainda
        """
        raise ParserError("Product page HTML parsing is not implemented for Sephora yet.")

    def from_product_api_json(self, json_data: dict) -> Optional[Product]:
        """
        Extrai um produto de dados JSON da API.

        Args:
            json_data: Dicionário contendo resposta JSON da API

        Returns:
            Objeto Product extraído ou None se não for possível extrair

        Raises:
            ParserError: Parser não suporta extração de produto via API JSON ainda
        """
        raise ParserError("Product API JSON parsing is not implemented for Sephora yet.")

class BelezaNaWebHTMLParser(StoresParserInterface):
    """
    Parser para HTML da Beleza na Web.

    Extrai produtos de páginas HTML da Beleza na Web (belezanaweb.com.br),
    com deduplicação automática de produtos repetidos em carrosséis.

    Características:
    - Parse híbrido: JSON embedded (data-event) + HTML estruturado
    - Deduplicação automática por SKU
    - Extrai: ID, nome, marca, preços (atual + antigo), URLs, desconto
    - Validações: ignora produtos sem SKU ou preço inválido

    Estrutura HTML esperada:
    - `<article class="showcase-item">` com atributo `data-event` (JSON)
    - Preço atual no JSON `data-event.price`
    - Preço antigo em `.item-price-max` (quando disponível)
    - URLs em `.showcase-card-link-overlay` e `img.showcase-image[data-src]`

    Exemplo:
        >>> parser = BelezaNaWebHTMLParser()
        >>> with open('beleza.html', 'r', encoding='utf-8') as f:
        ...     html = f.read()
        >>> products = parser.from_html(html)
        >>> print(f"Extraídos {len(products)} produtos únicos")
        Extraídos 36 produtos únicos
    """

    def __init__(self):
        """Inicializa parser e verifica dependência BeautifulSoup."""
        try:
            from bs4 import BeautifulSoup
            self.BeautifulSoup = BeautifulSoup
        except ImportError:
            raise ImportError(
                "beautifulsoup4 é necessário para BelezaNaWebHTMLParser. "
                "Instale com: pip install beautifulsoup4 lxml"
            )

    def from_json(self, json_data: dict) -> list[Product]:
        """
        JSON não suportado para Beleza na Web.

        Args:
            json_data: Dicionário JSON

        Raises:
            ParserError: Sempre - Beleza na Web usa HTML, não JSON
        """
        raise ParserError("Beleza na Web usa HTML parsing, não JSON. Use from_html().")

    def from_html(self, html_data: str) -> list[Product]:
        """
        Extrai produtos da Beleza na Web de HTML.

        Args:
            html_data: String contendo HTML da página de produtos
                      Estrutura esperada:
                      ```html
                      <article class="showcase-item" data-event="{...}">
                          <a class="showcase-card-link-overlay" href="/produto">...</a>
                          <img class="showcase-image" data-src="https://...">
                          <div class="item-price-max">R$ 599,00</div>
                          <span class="price-value">R$ 138,00</span>
                      </article>
                      ```

        Returns:
            Lista de objetos Product únicos (deduplicados por SKU).
            Lista vazia se não houver produtos válidos.

        Note:
            - Produtos duplicados (carrossel) são automaticamente removidos
            - Produtos sem SKU ou preço são ignorados com log de warning
            - Preço antigo é opcional (pode ser 0.0 se não disponível)
            - URLs relativas são convertidas para absolutas

        Example:
            >>> parser = BelezaNaWebHTMLParser()
            >>> products = parser.from_html(html_content)
            >>> for p in products:
            ...     print(f"{p.product_id}: {p.name} - R$ {p.current_price}")
        """
        products: list[Product] = []
        seen_skus: set[str] = set()
        logger.debug("Parsing Beleza na Web products from HTML")

        try:
            # Parse HTML com lxml (mais rápido) ou html.parser (fallback)
            soup = self.BeautifulSoup(html_data, 'lxml')
        except Exception:
            # Fallback para html.parser se lxml não estiver instalado
            soup = self.BeautifulSoup(html_data, 'html.parser')
            logger.debug("lxml not available, using html.parser")

        # Encontrar todos os artigos de produtos
        articles = soup.find_all('article', class_='showcase-item')
        logger.debug(f"Found {len(articles)} article elements in HTML")

        duplicates_count = 0

        for article in articles:
            try:
                # 1. Parse JSON do data-event
                data_event_str = article.get('data-event', '{}')
                if not data_event_str or data_event_str == '{}':
                    logger.debug("Article without data-event, skipping")
                    continue

                # Unescape HTML entities (&quot; → ")
                data_event_str = html.unescape(data_event_str)
                data_event = json.loads(data_event_str)

                # 2. Extrair SKU e verificar duplicata
                sku = data_event.get('sku')
                if not sku:
                    logger.warning("Product without SKU in data-event, skipping")
                    continue

                if sku in seen_skus:
                    duplicates_count += 1
                    continue  # Skip duplicata

                seen_skus.add(sku)

                # 3. Extrair dados do JSON embedded
                current_price = float(data_event.get('price', 0))
                product_name = data_event.get('productName', '')
                brand = data_event.get('brand', '')

                # Validar preço
                if current_price <= 0:
                    logger.warning(f"Product {sku} has invalid price ({current_price}), skipping")
                    continue

                # 4. Extrair URL do produto
                url_elem = article.find('a', class_='showcase-card-link-overlay')
                relative_url = url_elem.get('href', '') if url_elem else ''
                product_url = self._make_absolute_url(relative_url)

                # 5. Extrair URL da imagem
                img_elem = article.find('img', class_='showcase-image')
                image_url = img_elem.get('data-src', '') if img_elem else ''

                # 6. Extrair preço antigo (opcional)
                old_price = self._extract_old_price(article)

                # 7. Criar objeto Product
                product = Product(
                    product_id=sku,
                    name=product_name,
                    current_price_float=current_price,
                    old_price_float=old_price,
                    url=product_url,
                    image_url=image_url,
                    sku=sku,
                    available=True,
                    marketplace_name="Beleza na Web",
                    seller="Beleza na Web"
                )

                products.append(product)

            except json.JSONDecodeError as e:
                logger.warning(f"Failed to parse data-event JSON: {e}")
                continue
            except (ValueError, TypeError) as e:
                logger.warning(f"Error processing product: {e}")
                continue
            except Exception as e:
                logger.error(f"Unexpected error processing article: {e}")
                continue

        logger.info(
            f"Extracted {len(products)} unique products "
            f"({duplicates_count} duplicates ignored)"
        )

        return products

    def _make_absolute_url(self, relative_url: str) -> str:
        """
        Converte URL relativa para absoluta.

        Args:
            relative_url: URL relativa ou absoluta

        Returns:
            URL absoluta com domínio completo
        """
        if not relative_url:
            return ''

        if relative_url.startswith('http'):
            return relative_url

        if relative_url.startswith('/'):
            return f"https://www.belezanaweb.com.br{relative_url}"

        return f"https://www.belezanaweb.com.br/{relative_url}"

    def _extract_old_price(self, article) -> float:
        """
        Extrai preço antigo (preço "de") do HTML.

        Args:
            article: Elemento BeautifulSoup do article

        Returns:
            Preço antigo como float, ou 0.0 se não disponível
        """
        try:
            old_price_elem = article.find('div', class_='item-price-max')
            if old_price_elem:
                old_price_text = old_price_elem.get_text(strip=True)
                # Parse usando função do projeto (normaliza "R$ 599,00" → 599.0)
                return parse_price(old_price_text)
        except Exception as e:
            logger.debug(f"Could not extract old price: {e}")

        return 0.0

    def is_last_page(self, response: ResponseData) -> bool:
        """Verifica se a resposta indica que não há mais páginas (404 Not Found)."""
        return response.is_not_found()

    def from_product_page_html(self, html_data: str) -> Optional[Product]:
        """
        Extrai um produto de uma página HTML de produto.

        Args:
            html_data: String contendo HTML da página de produto

        Returns:
            Objeto Product extraído ou None se não for possível extrair

        Raises:
            ParserError: Parser não suporta extração de página de produto HTML ainda
        """
        raise ParserError("Product page HTML parsing is not implemented for Beleza na Web yet.")

    def from_product_api_json(self, json_data: dict) -> Optional[Product]:
        """
        Extrai um produto de dados JSON da API.

        Args:
            json_data: Dicionário contendo resposta JSON da API

        Returns:
            Objeto Product extraído ou None se não for possível extrair

        Raises:
            ParserError: Parser não suporta extração de produto via API JSON ainda
        """
        raise ParserError("Product API JSON parsing is not implemented for Beleza na Web yet.")


class NewEraAPIJSONParser(StoresParserInterface):
    """
    Parser para API da New Era Brasil.

    Extrai produtos de respostas JSON da API da New Era Brasil.

    Características:
    - **NÃO expande SKUs**: Retorna 1 Product por id_Product
    - `available = True` se PELO MENOS 1 SKU tiver estoque (qt_Stock > 0 e fg_B2C == True)
    - `available = False` se TODOS os SKUs estiverem sem estoque ou indisponíveis
    - SKU usado: primeiro SKU disponível encontrado
    - Validações: preço > 0

    Estrutura JSON esperada:
    ```json
    {
      "products": [
        {
          "id_Product": 105789,
          "nm_Product_Ecomm": "Camiseta Manga Curta NBA Indiana Pacers",
          "nm_Product": "camiseta-manga-curta-nba-indiana-pacers-nbi21tsh066",
          "nm_Brand": "NBA",
          "productPrice": [
            {
              "vl_Price": 118.9,
              "vl_Full_Price": 169.9,
              "vl_Perc_Discount": 30.02
            }
          ],
          "productStock": [
            {
              "cd_SKU": "7899564468967",
              "nm_Size": "P",
              "nm_Color": "Mescla Cinza",
              "qt_Stock": 1,
              "fg_B2C": true,
              "nm_Store": "New Era Brasil"
            }
          ],
          "productImage": [
            {
              "ds_Path_Image": "https://smarterappblob.blob.core.windows.net/public/1/image/thumb/...",
              "vl_Order": 1
            }
          ]
        }
      ],
      "qtProducts": 2476,
      "loadMore": true
    }
    ```

    Exemplo:
        >>> parser = NewEraAPIJSONParser()
        >>> products = parser.from_json(newera_response)
        >>> print(f"Extraídos {len(products)} produtos")
        Extraídos 48 produtos
        >>> available_count = sum(1 for p in products if p.available)
        >>> print(f"{available_count} produtos com estoque disponível")
    """

    def from_json(self, json_data: dict) -> list[Product]:
        """
        Extrai produtos da New Era de dados JSON.

        Args:
            json_data: Dicionário contendo resposta JSON da API New Era
                      Estrutura esperada:
                      {
                          "products": [
                              {
                                  "id_Product": 105789,
                                  "nm_Product_Ecomm": "Nome do Produto",
                                  "nm_Product": "slug-produto",
                                  "nm_Brand": "Marca",
                                  "productPrice": [{"vl_Price": 99.90, "vl_Full_Price": 149.90}],
                                  "productStock": [
                                      {
                                          "cd_SKU": "123456789",
                                          "nm_Size": "M",
                                          "nm_Color": "Preto",
                                          "qt_Stock": 5,
                                          "fg_B2C": true,
                                          "nm_Store": "New Era Brasil"
                                      }
                                  ],
                                  "productImage": [{"ds_Path_Image": "https://..."}]
                              }
                          ],
                          "qtProducts": 2476,
                          "loadMore": true
                      }

        Returns:
            Lista de objetos Product (1 por id_Product).
            Lista vazia se não houver produtos ou campo 'products' não existir.

        Note:
            - **NÃO expande SKUs**: Retorna 1 Product por id_Product
            - `available = False` se TODOS os SKUs tiverem `qt_Stock <= 0` ou `fg_B2C == False`
            - `available = True` se PELO MENOS 1 SKU tiver `qt_Stock > 0` E `fg_B2C == True`
            - SKU usado: primeiro SKU disponível encontrado
            - Produtos com `vl_Price <= 0` são ignorados
            - URL: `https://www.neweracap.com.br/p/{nm_Product}`
            - Imagem: primeira imagem de `productImage` ordenada por `vl_Order`
            - Marketplace: "New Era Brasil"
            - Seller: extraído de `nm_Store` do primeiro SKU disponível

        Example:
            >>> parser = NewEraAPIJSONParser()
            >>> products = parser.from_json(api_data)
            >>> for p in products:
            ...     print(f"{p.product_id}: {p.name} - Disponível: {p.available}")
        """
        products: list[Product] = []
        logger.debug("Parsing New Era products from JSON")

        products_json = json_data.get("products", [])
        if not products_json:
            logger.warning("No products found in JSON data.")
            return []

        total_products_processed = 0
        total_products_ignored = 0

        for product_json in products_json:
            try:
                product_id = product_json.get("id_Product")
                product_name = product_json.get("nm_Product_Ecomm", "")
                product_slug = product_json.get("nm_Product", "")

                # Extrair preços do primeiro item de productPrice
                product_prices = product_json.get("productPrice", [])
                if not product_prices:
                    logger.debug(f"Product {product_id} has no prices, skipping.")
                    total_products_ignored += 1
                    continue

                price_data = product_prices[0]
                try:
                    current_price = float(price_data.get("vl_Price", 0))
                    old_price = float(price_data.get("vl_Full_Price", 0))
                except (ValueError, TypeError) as e:
                    logger.warning(f"Invalid price for product {product_id}: {e}, skipping.")
                    total_products_ignored += 1
                    continue

                # Validação: Preço válido
                if current_price <= 0:
                    logger.debug(f"Product {product_id} has invalid price ({current_price}), skipping.")
                    total_products_ignored += 1
                    continue

                # Extrair primeira imagem (ordenada por vl_Order)
                product_images = product_json.get("productImage", [])
                image_url = ""
                if product_images:
                    # Ordenar por vl_Order e pegar a primeira
                    sorted_images = sorted(product_images, key=lambda img: img.get("vl_Order", 999))
                    image_url = sorted_images[0].get("ds_Path_Image", "")

                # URL do produto
                product_url = f"https://www.neweracap.com.br/p/{product_slug}" if product_slug else ""

                # Verificar disponibilidade: pelo menos 1 SKU com estoque
                product_stocks = product_json.get("productStock", [])
                is_available = False
                first_available_sku = None
                first_seller = "New Era Brasil"

                for stock_data in product_stocks:
                    sku = stock_data.get("cd_SKU")
                    fg_b2c = stock_data.get("fg_B2C", False)
                    qt_stock = stock_data.get("qt_Stock", 0)

                    # Verifica se SKU está disponível
                    if sku and fg_b2c and qt_stock > 0:
                        is_available = True
                        if not first_available_sku:
                            first_available_sku = sku
                            first_seller = stock_data.get("nm_Store", "New Era Brasil")

                # Usar primeiro SKU disponível, ou primeiro SKU se nenhum disponível
                sku_to_use = first_available_sku
                if not sku_to_use and product_stocks:
                    # Se nenhum disponível, usar primeiro SKU mesmo assim
                    sku_to_use = product_stocks[0].get("cd_SKU", str(product_id))
                    first_seller = product_stocks[0].get("nm_Store", "New Era Brasil")
                elif not sku_to_use:
                    # Se não há stocks, usar id_Product como SKU
                    sku_to_use = str(product_id)

                # Criar Product
                product = Product(
                    product_id=str(product_id),
                    name=product_name,
                    current_price_float=current_price,
                    old_price_float=old_price,
                    url=product_url,
                    image_url=image_url,
                    sku=sku_to_use,
                    available=is_available,
                    marketplace_name="New Era Brasil",
                    seller=first_seller
                )

                products.append(product)
                total_products_processed += 1

            except Exception as e:
                logger.error(f"Unexpected error processing product {product_json.get('id_Product')}: {e}")
                total_products_ignored += 1
                continue

        logger.info(
            f"Extracted {total_products_processed} products from {len(products_json)} in response "
            f"({total_products_ignored} products ignored)"
        )

        return products

    def from_html(self, html_data: str) -> list[Product]:
        """
        HTML não suportado para New Era API.

        Args:
            html_data: String contendo HTML

        Raises:
            ParserError: Sempre - New Era API usa JSON, não HTML
        """
        raise ParserError("New Era API usa JSON, não HTML. Use from_json().")

    def is_last_page(self, response: ResponseData) -> bool:
        """
        Verifica se a resposta indica que é a última página de resultados.

        Args:
            response: Objeto ResponseData contendo status e dados da resposta

        Returns:
            bool: True se for a última página (loadMore == False ou sem produtos)

        Note:
            - Verifica campo `loadMore` no JSON
            - Também retorna True se não houver produtos na resposta
            - Retorna True se houver erro ao parsear JSON
        """
        # Verificar se é 404
        if response.is_not_found():
            return True

        # Tentar parsear JSON
        try:
            json_data = response.to_json()
            if not json_data:
                logger.debug("No JSON data in response, assuming last page.")
                return True

            # Verificar campo loadMore
            load_more = json_data.get("loadMore", False)
            if not load_more:
                logger.debug("loadMore is False, this is the last page.")
                return True

            # Verificar se há produtos
            products = json_data.get("products", [])
            if not products:
                logger.debug("No products in response, this is the last page.")
                return True

            return False

        except Exception as e:
            logger.warning(f"Error checking pagination: {e}, assuming last page.")
            return True

    def from_product_page_html(self, html_data: str) -> Optional[Product]:
        """
        Extrai um produto de uma página HTML de produto.

        Args:
            html_data: String contendo HTML da página de produto

        Returns:
            Objeto Product extraído ou None se não for possível extrair

        Raises:
            ParserError: Parser não suporta extração de página de produto HTML ainda
        """
        raise ParserError("Product page HTML parsing is not implemented for New Era yet.")

    def from_product_api_json(self, json_data: dict) -> Optional[Product]:
        """
        Extrai um produto de dados JSON da API.

        Args:
            json_data: Dicionário contendo resposta JSON da API

        Returns:
            Objeto Product extraído ou None se não for possível extrair

        Raises:
            ParserError: Parser não suporta extração de produto via API JSON ainda
        """
        raise ParserError("Product API JSON parsing is not implemented for New Era yet.")


class HavanHTMLParser(StoresParserInterface):
    """
    Parser para HTML da Havan.

    Extrai produtos de páginas HTML da Havan (havan.com.br),
    com deduplicação automática de produtos repetidos em carrosséis.

    Características:
    - Parse HTML estruturado Magento 2
    - Deduplicação automática por product_id
    - Extrai: ID, nome, preços (atual + antigo), URLs, imagens
    - Validações: ignora produtos sem ID ou preço inválido
    - Suporta produtos com e sem desconto

    Estrutura HTML esperada:
    - `<li class="item product product-item">` com `data-product-id`
    - Nome em `.product-item-name a[title]`
    - Preço atual em `span.special-price data-price-amount` ou primeiro `span[data-price-amount]`
    - Preço antigo em `span.old-price data-price-amount` (opcional)
    - Imagem em `picture img[src]`

    Exemplo:
        >>> parser = HavanHTMLParser()
        >>> with open('havan.html', 'r', encoding='utf-8') as f:
        ...     html = f.read()
        >>> products = parser.from_html(html)
        >>> print(f"Extraídos {len(products)} produtos únicos")
        Extraídos 60 produtos únicos
    """

    def __init__(self):
        """Inicializa parser e verifica dependência BeautifulSoup."""
        try:
            from bs4 import BeautifulSoup
            self.BeautifulSoup = BeautifulSoup
        except ImportError:
            raise ImportError(
                "beautifulsoup4 é necessário para HavanHTMLParser. "
                "Instale com: pip install beautifulsoup4 lxml"
            )

    def from_json(self, json_data: dict) -> list[Product]:
        """
        JSON não suportado para Havan.

        Args:
            json_data: Dicionário JSON

        Raises:
            ParserError: Sempre - Havan usa HTML, não JSON
        """
        raise ParserError("Havan usa HTML parsing, não JSON. Use from_html().")

    def from_html(self, html_data: str) -> list[Product]:
        """
        Extrai produtos da Havan de HTML.

        Args:
            html_data: String contendo HTML da página de produtos
                      Estrutura esperada:
                      ```html
                      <li class="item product product-item">
                          <div class="product-item-info">
                              <a data-product-id="751923">
                              <strong class="product-item-name">
                                  <a href="URL" title="Nome">Nome</a>
                              </strong>
                              <picture><img src="https://..."></picture>
                              <div class="price-box">
                                  <span class="special-price">
                                      <span data-price-amount="2999.9">R$ 2.999,90</span>
                                  </span>
                                  <span class="old-price">
                                      <span data-price-amount="3899.9">R$ 3.899,90</span>
                                  </span>
                              </div>
                          </div>
                      </li>
                      ```

        Returns:
            Lista de objetos Product únicos (deduplicados por product_id).
            Lista vazia se não houver produtos válidos.

        Note:
            - Produtos duplicados (carrossel) são automaticamente removidos
            - Produtos sem product_id ou preço são ignorados com log de warning
            - Preço antigo é opcional (pode ser 0.0 se não disponível)
            - URLs já vêm completas do HTML

        Example:
            >>> parser = HavanHTMLParser()
            >>> products = parser.from_html(html_content)
            >>> for p in products:
            ...     print(f"{p.product_id}: {p.name} - R$ {p.current_price}")
        """
        products: list[Product] = []
        seen_ids: set[str] = set()
        logger.debug("Parsing Havan products from HTML")

        try:
            # Parse HTML com lxml (mais rápido) ou html.parser (fallback)
            soup = self.BeautifulSoup(html_data, 'lxml')
        except Exception:
            # Fallback para html.parser se lxml não estiver instalado
            soup = self.BeautifulSoup(html_data, 'html.parser')
            logger.debug("lxml not available, using html.parser")

        # Encontrar todos os itens de produtos
        product_items = soup.find_all('li', class_='product-item')
        logger.debug(f"Found {len(product_items)} product items in HTML")

        duplicates_count = 0

        for item in product_items:
            try:
                # 1. Extrair product_id (pode haver vários data-product-id no item)
                product_id_elem = item.find('a', attrs={'data-product-id': True})
                if not product_id_elem:
                    # Tentar no div.price-box
                    price_box = item.find('div', class_='price-box')
                    if price_box and price_box.get('data-product-id'):
                        product_id = str(price_box['data-product-id'])
                    else:
                        logger.warning("Product without ID, skipping")
                        continue
                else:
                    product_id = str(product_id_elem['data-product-id'])

                # 2. Verificar duplicata
                if product_id in seen_ids:
                    duplicates_count += 1
                    continue

                seen_ids.add(product_id)

                # 3. Extrair nome
                name_elem = item.find('strong', class_='product-item-name')
                if name_elem:
                    name_link = name_elem.find('a')
                    product_name = name_link.get('title', '') if name_link else ''
                else:
                    product_name = ''

                # 4. Extrair URL
                url_elem = item.find('strong', class_='product-item-name')
                if url_elem and url_elem.find('a'):
                    product_url = url_elem.find('a').get('href', '')
                else:
                    product_url = ''

                # 5. Extrair imagem
                img_elem = item.find('img', class_='img-default')
                if not img_elem:
                    # Fallback: qualquer img em picture
                    picture_elem = item.find('picture')
                    if picture_elem:
                        img_elem = picture_elem.find('img')

                image_url = img_elem.get('src', '') if img_elem else ''

                # 6. Extrair preços
                price_box = item.find('div', class_='price-box')
                if not price_box:
                    logger.warning(f"Product {product_id} has no price-box, skipping")
                    continue

                # Verificar se tem desconto (special-price + old-price)
                special_price_elem = price_box.find('span', class_='special-price')
                old_price_elem = price_box.find('span', class_='old-price')

                if special_price_elem and old_price_elem:
                    # Produto COM desconto
                    current_price_span = special_price_elem.find('span', attrs={'data-price-amount': True})
                    old_price_span = old_price_elem.find('span', attrs={'data-price-amount': True})

                    try:
                        current_price = float(current_price_span['data-price-amount']) if current_price_span else 0.0
                        old_price = float(old_price_span['data-price-amount']) if old_price_span else 0.0
                    except (ValueError, TypeError) as e:
                        logger.warning(f"Invalid price for product {product_id}: {e}, skipping")
                        continue
                else:
                    # Produto SEM desconto: usa primeiro data-price-amount
                    price_span = price_box.find('span', attrs={'data-price-amount': True})
                    if not price_span:
                        logger.warning(f"Product {product_id} has no price, skipping")
                        continue

                    try:
                        current_price = float(price_span['data-price-amount'])
                        old_price = 0.0
                    except (ValueError, TypeError) as e:
                        logger.warning(f"Invalid price for product {product_id}: {e}, skipping")
                        continue

                # Validar preço
                if current_price <= 0:
                    logger.warning(f"Product {product_id} has invalid price ({current_price}), skipping")
                    continue

                # 7. Criar objeto Product
                product = Product(
                    product_id=product_id,
                    name=product_name,
                    current_price_float=current_price,
                    old_price_float=old_price,
                    url=product_url,
                    image_url=image_url,
                    sku=product_id,  # Usar product_id como SKU
                    available=True,  # Produtos exibidos estão disponíveis
                    marketplace_name="Havan",
                    seller="Havan"
                )

                products.append(product)

            except Exception as e:
                logger.error(f"Unexpected error processing product item: {e}")
                continue

        logger.info(
            f"Extracted {len(products)} unique products "
            f"({duplicates_count} duplicates ignored)"
        )

        return products

    def is_last_page(self, response: ResponseData) -> bool:
        """
        Verifica se não há mais produtos (última página).

        Args:
            response: Objeto ResponseData contendo HTML

        Returns:
            True se for a última página, False caso contrário

        Note:
            Verifica:
            1. Mensagem "Não encontramos produtos para essa pesquisa"
            2. Lista de produtos vazia
            3. Nenhum elemento .product-item encontrado
        """
        if not response.is_html():
            logger.warning("Response is not HTML, assuming last page.")
            return True

        if response.is_not_found():
            logger.info("Response indicates no more pages (404 Not Found).")
            return True

        try:
            soup = self.BeautifulSoup(response.body, 'lxml')
        except Exception:
            soup = self.BeautifulSoup(response.body, 'html.parser')

        # Verificar mensagem de vazio
        empty_msg = soup.find('div', class_='message info empty')
        if empty_msg:
            text = empty_msg.get_text()
            if 'Não encontramos produtos' in text or 'não encontramos produtos' in text:
                logger.info("Found 'no products' message, this is the last page.")
                return True

        # Verificar se há itens de produto
        product_items = soup.find_all('li', class_='product-item')
        if not product_items or len(product_items) == 0:
            logger.info("No product items found, this is the last page.")
            return True

        return False

    def from_product_page_html(self, html_data: str) -> Optional[Product]:
        """
        Extrai um produto de uma página HTML de produto.

        Args:
            html_data: String contendo HTML da página de produto

        Returns:
            Objeto Product extraído ou None se não for possível extrair

        Raises:
            ParserError: Parser não suporta extração de página de produto HTML ainda
        """
        raise ParserError("Product page HTML parsing is not implemented for Havan yet.")

    def from_product_api_json(self, json_data: dict) -> Optional[Product]:
        """
        Extrai um produto de dados JSON da API.

        Args:
            json_data: Dicionário contendo resposta JSON da API

        Returns:
            Objeto Product extraído ou None se não for possível extrair

        Raises:
            ParserError: Parser não suporta extração de produto via API JSON ainda
        """
        raise ParserError("Product API JSON parsing is not implemented for Havan yet.")


class KabumAPIJSONParser(StoresParserInterface):
    """
    Parser para API da KaBuM!.

    Extrai produtos de respostas JSON da API pública da KaBuM!, incluindo:
    - ID do produto
    - Nome e descrição
    - Preços (atual, com desconto, ofertas especiais)
    - Estoque e disponibilidade
    - URLs (produto e imagens)
    - Marketplace e seller

    Validações automáticas:
    - Ignora produtos com preço inválido (≤ 0)
    - Trata ofertas especiais (campo 'offer')
    - Converte preços com fallback seguro
    - Trata ausência de campos opcionais

    Lógica de preços:
    - COM offer: current_price = offer.price_with_discount, old_price = price
    - SEM offer: current_price = price_with_discount, old_price = old_price

    Exemplo:
        >>> parser = KabumAPIJSONParser()
        >>> products = parser.from_json(kabum_api_response)
        >>> for product in products:
        ...     print(f"{product.name}: R$ {product.current_price}")
    """

    @staticmethod
    def _extract_coupon_code(stamps: dict) -> str:
        """
        Extrai código do cupom do campo stamps.

        Prioriza 'title' (formatado para usuário) sobre 'name' (técnico).

        Args:
            stamps: Dicionário com informações do cupom

        Returns:
            Código do cupom (ex: "CUPOM AOC10OFF" ou "cupom_aoc10off")

        Exemplo:
            >>> stamps = {"title": "CUPOM AOC10OFF", "name": "cupom_aoc10off"}
            >>> _extract_coupon_code(stamps)
            "CUPOM AOC10OFF"
        """
        return stamps.get("title", "") or stamps.get("name", "")

    @staticmethod
    def _extract_discount_value(description: str) -> float:
        """
        Extrai valor do desconto da descrição usando regex.

        Suporta padrões:
        - Percentuais: "10% OFF", "ganhe 10%", "10 % de desconto"
        - Valores fixos: "R$ 100 OFF", "ganhe R$ 50", "economize R$ 200"

        Args:
            description: Texto descritivo do cupom

        Returns:
            Valor do desconto (ex: 10.0 ou 100.0) ou 0.0 se não encontrar

        Exemplo:
            >>> _extract_discount_value("Use o cupom e ganhe 10% OFF")
            10.0
            >>> _extract_discount_value("Use o cupom KABUM100 e ganhe R$ 100 OFF")
            100.0
        """
        import re

        # Tentar extrair valor fixo em reais primeiro: "R$ 100 OFF"
        match_fixed = re.search(r'R\$\s*(\d+(?:[.,]\d+)?)', description)
        if match_fixed:
            # Converter vírgula para ponto se necessário
            value_str = match_fixed.group(1).replace(',', '.')
            return float(value_str)

        # Fallback: buscar percentual "10% OFF"
        match_percent = re.search(r'(\d+)\s*%', description)
        return float(match_percent.group(1)) if match_percent else 0.0

    @staticmethod
    def _extract_coupon_type(stamps: dict) -> str:
        """
        Determina o tipo do cupom baseado na descrição.

        Lógica:
        - Se descrição contém "R$" ou "reais": tipo "fixed"
        - Caso contrário: tipo "percentage" (padrão para KaBuM!)

        Args:
            stamps: Dicionário com informações do cupom

        Returns:
            Tipo do cupom: "percentage" ou "fixed"

        Exemplo:
            >>> stamps = {"description": "ganhe 10% OFF"}
            >>> _extract_coupon_type(stamps)
            "percentage"
        """
        description = stamps.get("description", "")
        if "R$" in description or "reais" in description.lower():
            return "fixed"
        return "percentage"

    def from_json(self, json_data: dict) -> list[Product]:
        """
        Extrai produtos da KaBuM! de dados JSON.

        Args:
            json_data: Dicionário contendo resposta JSON da API da KaBuM!
                      Estrutura esperada:
                      {
                          "meta": {
                              "total_items_count": 416,
                              "total_pages_count": 5,
                              "page": { "number": 1, "size": 100 }
                          },
                          "data": [
                              {
                                  "type": "product",
                                  "id": 170110,
                                  "attributes": {
                                      "title": "Nome Produto",
                                      "price": 99.90,
                                      "price_with_discount": 89.90,
                                      "old_price": 0.0,
                                      "offer": {
                                          "price": 79.90,
                                          "price_with_discount": 69.90
                                      },
                                      "product_link": "slug-produto",
                                      "photos": { "p": ["url1.jpg"] },
                                      "manufacturer": { "name": "Marca" },
                                      "available": true,
                                      "is_marketplace": false,
                                      "marketplace": {}
                                  }
                              }
                          ]
                      }

        Returns:
            Lista de objetos Product extraídos e formatados.
            Lista vazia se não houver produtos ou se campo 'data' não existir.

        Note:
            - Produtos com preço inválido (≤ 0 ou None) são ignorados
            - Se offer existe, usa offer.price_with_discount como preço atual
            - URLs são automaticamente formatadas: https://www.kabum.com.br/produto/{id}/{slug}
            - Marketplace/seller extraídos de attributes.marketplace
        """
        products: list[Product] = []
        logger.debug("Parsing KaBuM! products from JSON")

        data_list = json_data.get("data", [])
        if not data_list:
            logger.warning("No products found in 'data' field.")
            return []

        total_processed = 0
        total_ignored = 0

        for item in data_list:
            try:
                product_id = item.get("id")
                if not product_id:
                    logger.debug("Product without ID, skipping.")
                    total_ignored += 1
                    continue

                attrs = item.get("attributes", {})
                if not attrs:
                    logger.debug(f"Product {product_id} has no attributes, skipping.")
                    total_ignored += 1
                    continue

                title = attrs.get("title", "")
                if not title:
                    logger.debug(f"Product {product_id} has no title, skipping.")
                    total_ignored += 1
                    continue

                # Lógica de preços: priorizar offer se existir
                offer = attrs.get("offer")
                if offer and isinstance(offer, dict):
                    # COM offer: usa offer.price_with_discount vs price regular
                    try:
                        current_price = float(offer.get("price_with_discount", 0))
                        old_price = float(attrs.get("price", 0))
                    except (ValueError, TypeError) as e:
                        logger.warning(f"Invalid price in offer for product {product_id}: {e}, skipping.")
                        total_ignored += 1
                        continue
                else:
                    # SEM offer: usa price_with_discount vs old_price
                    try:
                        current_price = float(attrs.get("price_with_discount", 0))
                        old_price = float(attrs.get("old_price", 0))
                    except (ValueError, TypeError) as e:
                        logger.warning(f"Invalid price for product {product_id}: {e}, skipping.")
                        total_ignored += 1
                        continue

                # Validação: preço atual deve ser > 0
                if current_price <= 0:
                    logger.debug(f"Product {product_id} has invalid current_price ({current_price}), skipping.")
                    total_ignored += 1
                    continue

                # URL do produto
                product_link = attrs.get("product_link", "")
                product_url = f"https://www.kabum.com.br/produto/{product_id}/{product_link}" if product_link else ""

                # Imagem: primeira foto do array photos.p
                photos = attrs.get("photos", {})
                photos_list = photos.get("p", []) if isinstance(photos, dict) else []
                image_url = photos_list[0] if photos_list else ""

                # Seller/Marketplace
                is_marketplace = attrs.get("is_marketplace", False)
                marketplace = attrs.get("marketplace", {})
                if is_marketplace and isinstance(marketplace, dict):
                    seller = marketplace.get("seller_name", "KaBuM!")
                else:
                    seller = "KaBuM!"

                # Disponibilidade
                available = attrs.get("available", False)

                # Fabricante (opcional)
                manufacturer = attrs.get("manufacturer", {})
                manufacturer_name = manufacturer.get("name", "") if isinstance(manufacturer, dict) else ""

                # Cupons/Stamps (quando disponível)
                # IMPORTANTE: stamps é um dict (objeto único), não array!
                stamps = attrs.get("stamps")
                coupon = None
                coupon_text = stamps.get("description", "") if stamps and isinstance(stamps, dict) else ""
                if coupon_text:
                    logger.debug(f"Product {product_id} has coupon description: {coupon_text}")
                if stamps and isinstance(stamps, dict):
                    # Extrair informações do cupom usando métodos helper
                    code = self._extract_coupon_code(stamps)
                    description = stamps.get("description", "")
                    value = self._extract_discount_value(description)
                    coupon_type = self._extract_coupon_type(stamps)

                    # Só criar cupom se tiver código válido
                    if code:
                        from notify_utils.models import Coupon
                        coupon = Coupon(
                            code=code,                 # Ex: "CUPOM AOC10OFF"
                            discount_type=coupon_type, # Ex: "percentage"
                            discount_value=value,      # Ex: 10.0 (extraído via regex)
                            message=description        # Descrição completa do cupom
                        )

                product = Product(
                    product_id=str(product_id),
                    name=title,
                    current_price_float=current_price,
                    old_price_float=old_price,
                    url=product_url,
                    image_url=image_url,
                    sku=str(product_id),  # KaBuM! usa ID como identificador único
                    available=available,
                    marketplace_name="KaBuM!",
                    seller=seller,
                    coupon=coupon
                )

                products.append(product)
                total_processed += 1

            except Exception as e:
                logger.error(f"Error processing product {item.get('id', 'unknown')}: {e}")
                total_ignored += 1
                continue

        logger.info(f"KaBuM! parser: {total_processed} products extracted, {total_ignored} ignored.")
        return products

    def from_html(self, html_data: str) -> list[Product]:
        """
        HTML não suportado para KaBuM! API.

        Args:
            html_data: String contendo HTML

        Raises:
            ParserError: Sempre - KaBuM! API usa JSON, não HTML
        """
        raise ParserError("HTML parsing is not supported for KaBuM! API.")

    def is_last_page(self, response: ResponseData) -> bool:
        """
        Verifica se a resposta indica que é a última página de resultados.

        Lógica:
        1. Se não for JSON ou for 404, assume última página
        2. Verifica meta.page.number >= meta.total_pages_count
        3. Verifica se data está vazio

        Args:
            response: Objeto ResponseData contendo status e dados da resposta

        Returns:
            bool: True se for a última página, False caso contrário
        """
        if not response.is_json():
            logger.warning("Response is not JSON, cannot determine pagination.")
            return True

        if response.is_not_found():
            logger.info("Response indicates no more pages (404 Not Found).")
            return True

        json_data = response.to_json()
        if json_data is None:
            logger.warning("Failed to parse JSON response, assuming last page.")
            return True

        # Verificar se há produtos na resposta
        data_list = json_data.get("data", [])
        if not data_list:
            logger.info("No products found in response 'data', this is the last page.")
            return True

        # Verificar meta de paginação
        meta = json_data.get("meta", {})
        if meta:
            page_info = meta.get("page", {})
            current_page = page_info.get("number", 0)
            total_pages = meta.get("total_pages_count", 0)

            if current_page >= total_pages and total_pages > 0:
                logger.info(f"Current page ({current_page}) >= total pages ({total_pages}), this is the last page.")
                return True

        # Se chegou aqui, assume que há mais páginas
        return False

    def from_product_page_html(self, html_data: str) -> Optional[Product]:
        """
        Extrai um produto de uma página HTML de produto.

        Args:
            html_data: String contendo HTML da página de produto

        Returns:
            Objeto Product extraído ou None se não for possível extrair

        Raises:
            ParserError: Parser não suporta extração de página de produto HTML ainda
        """
        raise ParserError("Product page HTML parsing is not implemented for KaBuM! yet.")

    def from_product_api_json(self, json_data: dict) -> Optional[Product]:
        """
        Extrai um produto de dados JSON da API.

        Args:
            json_data: Dicionário contendo resposta JSON da API

        Returns:
            Objeto Product extraído ou None se não for possível extrair

        Raises:
            ParserError: Parser não suporta extração de produto via API JSON ainda
        """
        raise ParserError("Product API JSON parsing is not implemented for KaBuM! yet.")


class DafitiJSONParser(StoresParserInterface):
    """
    Parser para API da Dafiti (dafiti.com.br).

    A API da Dafiti retorna uma resposta JSON onde o campo `body.products`
    contém uma string HTML com os produtos da página. Este parser suporta
    ambos os formatos:

    - `from_json()`: Aceita a resposta JSON completa da API e extrai o HTML
      interno de `body.products` automaticamente.
    - `from_html()`: Aceita diretamente a string HTML do campo `body.products`.

    Características:
    - Parse do HTML de `body.products` com BeautifulSoup
    - Deduplicação automática por SKU (`data-sku`)
    - Lógica de preços:
      - COM desconto (`is-special-price`): `current_price = product-box-price-to`,
        `old_price = product-box-price-from`
      - SEM desconto: `current_price = product-box-price-from`, `old_price = 0.0`
    - Seller extraído de `.product-box-seller span` (exibido mesmo quando oculto)
    - Detecção de última página via campo `noResults` ou ausência de produtos

    Estrutura JSON esperada:
    ```json
    {
      "body": {
        "products": "<div class=\\"product-box\\" data-sku=\\"SKU123\\">...</div>",
        "pageSize": 48,
        "total": 3448,
        "page": 1,
        "noResults": "",
        "moreProducts": ""
      }
    }
    ```

    Estrutura HTML esperada (dentro de `body.products`):
    ```html
    <div class="product-box" data-sku="AD126APF15KYU">
        <div class="product-box-image">
            <a href="https://www.dafiti.com.br/Produto-123.html"
               class="product-box-link"
               data-model-picture="https://static.dafiti.com.br/p/...jpg">
                <img alt="Nome do Produto" data-original="...jpg"/>
            </a>
        </div>
        <div class="product-box-detail">
            <div class="product-box-brand"><span>Marca</span></div>
            <p class="product-box-title">Nome do Produto</p>
            <!-- COM desconto -->
            <div class="product-box-price is-special-price">
                <span class="product-box-price-from">R$ 89,90</span>
                <span class="product-box-price-to">R$ 39,90</span>
            </div>
            <!-- SEM desconto -->
            <div class="product-box-price">
                <span class="product-box-price-from">R$ 49,99</span>
            </div>
            <div class="product-box-seller" style="display: none;">
                <span>Nome do Seller</span>
            </div>
        </div>
    </div>
    ```

    Exemplo:
        >>> parser = DafitiJSONParser()
        >>> import json
        >>> with open('dafiti_products.json', 'r') as f:
        ...     data = json.load(f)
        >>> products = parser.from_json(data)
        >>> print(f"Extraídos {len(products)} produtos únicos")
        Extraídos 12 produtos únicos
    """

    def __init__(self):
        """Inicializa parser e verifica dependência BeautifulSoup."""
        try:
            from bs4 import BeautifulSoup
            self.BeautifulSoup = BeautifulSoup
        except ImportError:
            raise ImportError(
                "beautifulsoup4 é necessário para DafitiJSONParser. "
                "Instale com: pip install beautifulsoup4 lxml"
            )

    def from_json(self, json_data: dict) -> list[Product]:
        """
        Extrai produtos da Dafiti de resposta JSON da API.

        Extrai a string HTML do campo `body.products` e delega para `from_html()`.

        Args:
            json_data: Dicionário contendo a resposta JSON completa da API Dafiti.
                      Estrutura esperada:
                      {
                          "body": {
                              "products": "<html com produtos>",
                              "pageSize": 48,
                              "total": 3448,
                              "page": 1,
                              "noResults": "",
                          }
                      }

        Returns:
            Lista de objetos Product extraídos e deduplicados.
            Lista vazia se não houver produtos válidos.

        Raises:
            ParserError: Se o campo `body.products` não for encontrado no JSON.

        Example:
            >>> parser = DafitiJSONParser()
            >>> products = parser.from_json(api_response)
            >>> for p in products:
            ...     print(f"{p.product_id}: {p.name} - R$ {p.current_price_float:.2f}")
        """
        body = json_data.get("body", {})
        if not body:
            raise ParserError(
                "Campo 'body' não encontrado no JSON da Dafiti. "
                "Verifique se a resposta é da API correta."
            )

        # Prioridade: body.result.items (JSON estruturado, todos os produtos)
        result_items = body.get("result", {}).get("items", {})
        if result_items and isinstance(result_items, dict):
            logger.debug(f"Usando body.result.items: {len(result_items)} items encontrados")
            return self._parse_result_items(result_items)

        # Fallback: body.products (HTML, subconjunto dos produtos)
        html_products = body.get("products", "")
        if not html_products or not isinstance(html_products, str):
            logger.warning("Campo 'body.products' vazio ou não é string. Retornando lista vazia.")
            return []

        logger.debug("body.result.items não disponível, usando fallback HTML body.products")
        return self.from_html(html_products)

    def _parse_result_items(self, items: dict) -> list[Product]:
        """
        Extrai produtos do campo body.result.items da API da Dafiti.

        Cada chave do dicionário é um SKU de produto. Os dados estão em
        subcampos `meta`, `images`, `seller` e `link`.

        Args:
            items: Dicionário SKU → dados do produto de body.result.items.

        Returns:
            Lista de objetos Product extraídos e deduplicados.
        """
        products: list[Product] = []
        seen_skus: set[str] = set()

        for sku, item in items.items():
            try:
                if not sku or sku in seen_skus:
                    continue
                seen_skus.add(sku)

                meta = item.get("meta", {})

                name = meta.get("name", "").strip()
                if not name:
                    logger.warning(f"Produto {sku} sem nome, ignorando")
                    continue

                # Preços: special_price é o preço com desconto; price é o original
                price_raw = meta.get("price")
                special_raw = meta.get("special_price")

                try:
                    price_val = float(price_raw) if price_raw is not None else 0.0
                except (ValueError, TypeError):
                    price_val = 0.0

                try:
                    special_val = float(special_raw) if special_raw is not None else 0.0
                except (ValueError, TypeError):
                    special_val = 0.0

                if special_val > 0 and special_val < price_val:
                    # Desconto real: special menor que o preço original
                    current_price = special_val
                    old_price = price_val
                elif price_val > 0:
                    current_price = price_val
                    old_price = 0.0
                else:
                    logger.warning(f"Produto {sku} sem preço válido, ignorando")
                    continue

                # URL do produto (link relativo → absoluto)
                link = item.get("link", "")
                product_url = f"https://www.dafiti.com.br/{link}" if link else ""

                # Imagem (primeiro item do array images)
                image_url = ""
                images = item.get("images", [])
                if images and isinstance(images, list) and isinstance(images[0], dict):
                    image_url = images[0].get("url", "")
                    image_url = f'{image_url}-product.jpg' if image_url else ""

                # Seller
                seller_data = item.get("seller", {})
                seller = seller_data.get("shop_name", "") or seller_data.get("name", "") or "Dafiti"

                products.append(Product(
                    product_id=sku,
                    name=name,
                    current_price_float=current_price,
                    old_price_float=old_price,
                    url=product_url,
                    image_url=image_url,
                    sku=sku,
                    available=True,
                    marketplace_name="Dafiti",
                    seller=seller,
                ))

            except Exception as e:
                logger.error(f"Erro inesperado processando item {sku} da Dafiti: {e}")
                continue

        logger.info(f"Extraídos {len(products)} produtos únicos da Dafiti via result.items")
        return products

    def from_html(self, html_data: str) -> list[Product]:
        """
        Extrai produtos da Dafiti de HTML (conteúdo de `body.products`).

        Args:
            html_data: String contendo o HTML do campo `body.products` da API Dafiti.
                      Estrutura esperada:
                      ```html
                      <div class="product-box" data-sku="AD126APF15KYU">
                          <div class="product-box-image">
                              <a href="URL" class="product-box-link"
                                 data-model-picture="https://static.dafiti.com.br/...">
                                  <img alt="Nome" data-original="..."/>
                              </a>
                          </div>
                          <div class="product-box-detail">
                              <div class="product-box-brand"><span>Marca</span></div>
                              <p class="product-box-title">Nome do Produto</p>
                              <div class="product-box-price is-special-price">
                                  <span class="product-box-price-from">R$ 89,90</span>
                                  <span class="product-box-price-to">R$ 39,90</span>
                              </div>
                              <div class="product-box-seller">
                                  <span>Nome do Seller</span>
                              </div>
                          </div>
                      </div>
                      ```

        Returns:
            Lista de objetos Product únicos (deduplicados por SKU).
            Lista vazia se não houver produtos válidos.

        Note:
            - Produtos duplicados são automaticamente removidos via `seen_skus`
            - Produtos sem SKU ou preço inválido são ignorados com log de warning
            - Preço antigo é 0.0 quando não há desconto anunciado
            - Seller é extraído mesmo quando o elemento está oculto via CSS

        Example:
            >>> parser = DafitiJSONParser()
            >>> products = parser.from_html(html_products_string)
            >>> for p in products:
            ...     print(f"{p.sku}: {p.name} - R$ {p.current_price_float:.2f}")
        """
        # Tenta converter para JSON caso a resposta seja JSON mascarado como HTML
        stripped = html_data.strip()
        if stripped.startswith('{') or stripped.startswith('['):
            try:
                import json as _json
                json_data = _json.loads(html_data)
                logger.debug("from_html: corpo detectado como JSON, delegando para from_json()")
                return self.from_json(json_data)
            except (_json.JSONDecodeError, ValueError):
                pass

        products: list[Product] = []
        seen_skus: set[str] = set()
        logger.debug("Parsing Dafiti products from HTML")

        try:
            soup = self.BeautifulSoup(html_data, 'lxml')
        except Exception:
            soup = self.BeautifulSoup(html_data, 'html.parser')
            logger.debug("lxml não disponível, usando html.parser")

        product_boxes = soup.find_all('div', class_='product-box')
        logger.debug(f"Encontrados {len(product_boxes)} blocos product-box no HTML")

        duplicates_count = 0

        for box in product_boxes:
            try:
                # 1. Extrair SKU (identificador do produto)
                sku = box.get('data-sku', '').strip()
                if not sku:
                    logger.warning("Produto sem data-sku encontrado, ignorando")
                    continue

                # 2. Verificar duplicata
                if sku in seen_skus:
                    duplicates_count += 1
                    continue
                seen_skus.add(sku)

                # 3. Extrair URL e imagem do link
                link_elem = box.find('a', class_='product-box-link')
                product_url = link_elem.get('href', '') if link_elem else ''
                image_url = link_elem.get('data-model-picture', '') if link_elem else ''

                # 4. Extrair nome do produto
                title_elem = box.find('p', class_='product-box-title')
                product_name = title_elem.get_text(strip=True) if title_elem else ''

                if not product_name:
                    # Fallback: usar alt da imagem
                    img_elem = box.find('img')
                    product_name = img_elem.get('alt', '') if img_elem else ''

                # 5. Extrair preços
                price_box = box.find('div', class_='product-box-price')
                if not price_box:
                    logger.warning(f"Produto {sku} sem div.product-box-price, ignorando")
                    continue

                price_to_elem = price_box.find('span', class_='product-box-price-to')
                price_from_elem = price_box.find('span', class_='product-box-price-from')

                try:
                    if price_to_elem and price_from_elem:
                        # Produto COM desconto: price-to = atual, price-from = antigo
                        current_price = parse_price(price_to_elem.get_text(strip=True))
                        old_price = parse_price(price_from_elem.get_text(strip=True))
                    elif price_from_elem:
                        # Produto SEM desconto: price-from = preço atual
                        current_price = parse_price(price_from_elem.get_text(strip=True))
                        old_price = 0.0
                    else:
                        logger.warning(f"Produto {sku} sem spans de preço, ignorando")
                        continue
                except (ValueError, TypeError) as e:
                    logger.warning(f"Preço inválido para produto {sku}: {e}, ignorando")
                    continue

                # 6. Validar preço atual
                if current_price <= 0:
                    logger.warning(f"Produto {sku} com preço inválido ({current_price}), ignorando")
                    continue

                # 7. Extrair seller (campo pode estar oculto via CSS)
                seller_div = box.find('div', class_='product-box-seller')
                seller = "Dafiti"
                if seller_div:
                    seller_span = seller_div.find('span')
                    if seller_span:
                        seller_text = seller_span.get_text(strip=True)
                        if seller_text:
                            seller = seller_text

                # 8. Criar objeto Product
                product = Product(
                    product_id=sku,
                    name=product_name,
                    current_price_float=current_price,
                    old_price_float=old_price,
                    url=product_url,
                    image_url=image_url,
                    sku=sku,
                    available=True,
                    marketplace_name="Dafiti",
                    seller=seller
                )

                products.append(product)

            except Exception as e:
                logger.error(f"Erro inesperado processando produto da Dafiti: {e}")
                continue

        logger.info(
            f"Extraídos {len(products)} produtos únicos da Dafiti "
            f"({duplicates_count} duplicatas ignoradas)"
        )

        return products

    def is_last_page(self, response: ResponseData) -> bool:
        """
        Verifica se não há mais produtos (última página da Dafiti).

        Lógica de verificação (em ordem):
        1. Se a resposta for 404, retorna True
        2. Parseia o JSON e delega para from_json()
        3. Se a lista de produtos retornada for vazia, é a última página
        4. Se não for possível parsear, assume última página

        Args:
            response: Objeto ResponseData contendo a resposta HTTP da API Dafiti

        Returns:
            bool: True se for a última página, False caso contrário

        Note:
            A URL da API Dafiti usa o parâmetro `page` para paginação.
            Exemplo: `?page=2&ajax=true`
        """
        if response.is_not_found():
            logger.info("Resposta 404, assumindo última página da Dafiti.")
            return True

        try:
            json_data = json.loads(response.body)
        except Exception as e:
            logger.warning(f"Erro ao parsear JSON da Dafiti: {e}, assumindo última página.")
            return True

        products = self.from_json(json_data)
        if not products:
            logger.info("Nenhum produto retornado por from_json(), esta é a última página da Dafiti.")
            return True

        return False

    def from_product_page_html(self, html_data: str) -> Optional[Product]:
        """
        Extrai um produto de uma página HTML de produto.

        Args:
            html_data: String contendo HTML da página de produto

        Returns:
            Objeto Product extraído ou None se não for possível extrair

        Raises:
            ParserError: Parser não suporta extração de página de produto HTML ainda
        """
        raise ParserError("Product page HTML parsing is not implemented for Dafiti yet.")

    def from_product_api_json(self, json_data: dict) -> Optional[Product]:
        """
        Extrai um produto de dados JSON da API.

        Args:
            json_data: Dicionário contendo resposta JSON da API

        Returns:
            Objeto Product extraído ou None se não for possível extrair

        Raises:
            ParserError: Parser não suporta extração de produto via API JSON ainda
        """
        raise ParserError("Product API JSON parsing is not implemented for Dafiti yet.")


class KalungaHTMLParser(StoresParserInterface):
    """
    Parser para API da Kalunga (kalunga.com.br).

    A API da Kalunga retorna um JSON onde os campos principais contêm HTML embedded:
    - `templateProdutos`: HTML com lista de produtos (div.blocoproduto)
    - `templatePaginacao`: HTML com navegação de páginas
    - `templatefiltro`: HTML com filtros

    Este parser extrai produtos do campo `templateProdutos` usando BeautifulSoup.

    Características:
    - Parse de JSON com HTML embedded em `templateProdutos`
    - Deduplicação automática por product_id (extraído do href)
    - Lógica de preços:
      - COM desconto: `del.blocoproduto__oldprice` existe → old_price
      - SEM desconto: apenas `span.blocoproduto__price` → old_price = 0.0
    - Preço à vista (ignora preço a prazo)
    - Imagens: prioriza WebP (source[data-srcset]) sobre JPG (img[data-src])
    - Lazy loading: usa atributos `data-srcset` e `data-src`
    - Seller: hardcoded "Kalunga" (não identificado no HTML)
    - Disponibilidade: True sempre (produtos indisponíveis não aparecem na listagem)

    Estrutura JSON esperada:
    ```json
    {
      "templatePaginacao": "<nav>...</nav>",
      "templateProdutos": "<div class='blocoproduto'>...</div>...",
      "templatefiltro": "<div>...</div>"
    }
    ```

    Estrutura HTML esperada (dentro de `templateProdutos`):
    ```html
    <div class="blocoproduto col-6 col-md-4 col-xl-3">
        <div class="blocoproduto__row">
            <a class="blocoproduto__link"
               href="/prod/produto-nome-slug/775303">
                <picture>
                    <source data-srcset="https://img.kalunga.com.br/fotosdeprodutos/775303.webp" />
                    <img data-src="https://img.kalunga.com.br/fotosdeprodutos/775303.jpg" />
                </picture>
            </a>
            <a class="blocoproduto__link" href="/prod/.../775303">
                <h2 class="blocoproduto__title">Impressora Plotter ImagePROGRAF 24"...</h2>
            </a>
            <div class="blocoproduto__box">
                <!-- PRODUTO COM DESCONTO -->
                <del class="blocoproduto__oldprice small">De: R$ 3.028,50</del>
                <span class="blocoproduto__price">
                    R$ 2.519,10
                    <span class="blocoproduto__incash">à vista</span>
                </span>

                <!-- PRODUTO SEM DESCONTO (sem tag <del>) -->
                <span class="blocoproduto__price">
                    R$ 3.959,10
                    <span class="blocoproduto__incash">à vista</span>
                </span>
            </div>
        </div>
    </div>
    ```

    Exemplo:
        >>> parser = KalungaHTMLParser()
        >>> import json
        >>> with open('kalunga_response.json', 'r', encoding='utf-8') as f:
        ...     data = json.load(f)
        >>> products = parser.from_json(data)
        >>> print(f"Extraídos {len(products)} produtos únicos")
        Extraídos 60 produtos únicos
    """

    def __init__(self):
        """Inicializa parser e verifica dependência BeautifulSoup."""
        try:
            from bs4 import BeautifulSoup
            self.BeautifulSoup = BeautifulSoup
        except ImportError:
            raise ImportError(
                "beautifulsoup4 é necessário para KalungaHTMLParser. "
                "Instale com: pip install beautifulsoup4 lxml"
            )

    def from_json(self, json_data: dict) -> list[Product]:
        """
        Extrai produtos da Kalunga de resposta JSON da API.

        Extrai a string HTML do campo `templateProdutos` e delega para `from_html()`.

        Args:
            json_data: Dicionário JSON com estrutura:
                {
                    "templateProdutos": "HTML string com produtos",
                    "templatePaginacao": "HTML string com paginação",
                    "templatefiltro": "HTML string com filtros"
                }

        Returns:
            Lista de objetos Product extraídos do HTML embedded.
            Lista vazia se campo `templateProdutos` não existir ou estiver vazio.

        Raises:
            ParserError: Se estrutura do JSON for inválida

        Example:
            >>> parser = KalungaHTMLParser()
            >>> data = {"templateProdutos": "<div class='blocoproduto'>...</div>"}
            >>> products = parser.from_json(data)
        """
        logger.debug("Parsing Kalunga products from JSON")

        # Extrair HTML embedded do campo templateProdutos
        html_content = json_data.get('templateProdutos', '')
        if not html_content or not isinstance(html_content, str):
            logger.warning("Campo 'templateProdutos' não encontrado ou vazio no JSON")
            return []

        # Delegar para from_html()
        return self.from_html(html_content)

    def from_html(self, html_data: str) -> list[Product]:
        """
        Extrai produtos da Kalunga de HTML.

        Args:
            html_data: String contendo HTML com produtos (campo `templateProdutos`)
                      Estrutura esperada: múltiplos `<div class="blocoproduto">`

        Returns:
            Lista de objetos Product únicos (deduplicados por product_id).
            Lista vazia se não houver produtos válidos.

        Note:
            - Produtos duplicados são automaticamente removidos
            - Produtos sem product_id ou preço são ignorados com log de warning
            - Preço antigo é opcional (0.0 se não houver tag <del>)
            - Imagens WebP são priorizadas sobre JPG
            - Nome pode estar truncado com "..." no HTML

        Example:
            >>> parser = KalungaHTMLParser()
            >>> html = "<div class='blocoproduto'>...</div>"
            >>> products = parser.from_html(html)
            >>> for p in products:
            ...     print(f"{p.product_id}: {p.name} - R$ {p.current_price}")
        """
        products: list[Product] = []
        seen_ids: set[str] = set()
        logger.debug("Parsing Kalunga products from HTML")

        try:
            # Parse HTML com lxml (mais rápido) ou html.parser (fallback)
            soup = self.BeautifulSoup(html_data, 'lxml')
        except Exception:
            # Fallback para html.parser se lxml não estiver instalado
            soup = self.BeautifulSoup(html_data, 'html.parser')
            logger.debug("lxml not available, using html.parser")

        # Encontrar todos os divs de produtos
        product_divs = soup.find_all('div', class_='blocoproduto')
        logger.debug(f"Found {len(product_divs)} product divs in HTML")

        duplicates_count = 0

        for produto_div in product_divs:
            try:
                # 1. Extrair product_id do href usando regex
                product_id = self._extract_product_id(produto_div)
                if not product_id:
                    logger.warning("Product without ID, skipping")
                    continue

                # 2. Verificar duplicata
                if product_id in seen_ids:
                    duplicates_count += 1
                    continue

                seen_ids.add(product_id)

                # 3. Extrair nome
                product_name = self._extract_name(produto_div)
                if not product_name:
                    logger.warning(f"Product {product_id} without name, skipping")
                    continue

                # 4. Extrair URL
                product_url = self._extract_url(produto_div)

                # 5. Extrair imagem (prioriza WebP)
                image_url = self._extract_image(produto_div)

                # 6. Extrair preço atual (à vista)
                current_price = self._extract_current_price(produto_div)
                if current_price <= 0:
                    logger.warning(f"Product {product_id} has invalid price ({current_price}), skipping")
                    continue

                # 7. Extrair preço antigo (se houver <del>)
                old_price = self._extract_old_price(produto_div)

                # 8. Criar objeto Product
                product = Product(
                    product_id=product_id,
                    name=product_name,
                    current_price_float=current_price,
                    old_price_float=old_price,
                    url=product_url,
                    image_url=image_url,
                    sku=product_id,  # Kalunga usa product_id como identificador único
                    available=True,  # Produtos indisponíveis não aparecem na listagem
                    marketplace_name="Kalunga",
                    seller="Kalunga"
                )

                products.append(product)

            except Exception as e:
                logger.error(f"Error processing product: {e}")
                continue

        logger.info(
            f"Extracted {len(products)} unique Kalunga products "
            f"({duplicates_count} duplicates ignored)"
        )

        return products

    def _extract_product_id(self, elem) -> str:
        """
        Extrai product_id do href usando regex.

        O product_id está no final da URL: /prod/produto-slug/775303

        Args:
            elem: Elemento BeautifulSoup do div.blocoproduto

        Returns:
            Product ID como string, ou string vazia se não encontrado
        """
        import re

        link = elem.find('a', class_='blocoproduto__link')
        if not link:
            return ""

        href = link.get('href', '')
        if not href:
            return ""

        # Regex: extrai dígitos no final da URL após última barra
        match = re.search(r'/(\d+)$', href)
        if match:
            return match.group(1)

        return ""

    def _extract_name(self, elem) -> str:
        """
        Extrai nome do produto.

        Args:
            elem: Elemento BeautifulSoup do div.blocoproduto

        Returns:
            Nome do produto, ou string vazia se não encontrado

        Note:
            Nome pode estar truncado com "..." no final
        """
        titulo_h2 = elem.find('h2', class_='blocoproduto__title')
        if not titulo_h2:
            return ""

        return titulo_h2.get_text(strip=True)

    def _extract_url(self, elem) -> str:
        """
        Extrai URL do produto (converte para absoluta).

        Args:
            elem: Elemento BeautifulSoup do div.blocoproduto

        Returns:
            URL absoluta do produto, ou string vazia se não encontrado
        """
        link = elem.find('a', class_='blocoproduto__link')
        if not link:
            return ""

        href = link.get('href', '')
        if not href:
            return ""

        # Converter para URL absoluta
        if href.startswith('http'):
            return href

        if href.startswith('/'):
            return f"https://www.kalunga.com.br{href}"

        return f"https://www.kalunga.com.br/{href}"

    def _extract_image(self, elem) -> str:
        """
        Extrai URL da imagem (prioriza WebP sobre JPG).

        Imagens usam lazy loading: URLs reais estão em data-srcset (WebP)
        ou data-src (JPG), não no atributo src (que contém base64 placeholder).

        Args:
            elem: Elemento BeautifulSoup do div.blocoproduto

        Returns:
            URL da imagem (WebP se disponível, senão JPG), ou string vazia
        """
        picture = elem.find('picture')
        if not picture:
            return ""

        # Prioridade 1: WebP (source[data-srcset])
        source = picture.find('source')
        if source:
            webp_url = source.get('data-srcset') or source.get('srcset')
            if webp_url:
                return webp_url.strip()

        # Prioridade 2: JPG (img[data-src])
        img = picture.find('img')
        if img:
            jpg_url = img.get('data-src')
            if jpg_url:
                return jpg_url.strip()

        return ""

    def _extract_current_price(self, elem) -> float:
        """
        Extrai preço atual (à vista) do produto.

        O preço à vista está em span.blocoproduto__price (primeiro texto direto,
        ignorando filho <span class="blocoproduto__incash">).

        Args:
            elem: Elemento BeautifulSoup do div.blocoproduto

        Returns:
            Preço atual como float, ou 0.0 se não encontrado

        Note:
            Usa parse_price() do projeto para normalizar formato BR (R$ 1.299,90)
        """
        preco_span = elem.find('span', class_='blocoproduto__price')
        if not preco_span:
            return 0.0

        # Pegar apenas texto direto (ignorar filho <span class="blocoproduto__incash">)
        # stripped_strings retorna generator com todos os textos (incluindo filhos)
        preco_text_parts = list(preco_span.stripped_strings)
        if not preco_text_parts:
            return 0.0

        # Primeiro elemento é o preço, segundo é "à vista" (ignorar)
        preco_text = preco_text_parts[0]

        try:
            return parse_price(preco_text)
        except (ValueError, TypeError) as e:
            logger.debug(f"Failed to parse price '{preco_text}': {e}")
            return 0.0

    def _extract_old_price(self, elem) -> float:
        """
        Extrai preço antigo (se houver desconto).

        Produtos com desconto possuem tag <del class="blocoproduto__oldprice">
        com texto "De: R$ 3.028,50".

        Args:
            elem: Elemento BeautifulSoup do div.blocoproduto

        Returns:
            Preço antigo como float, ou 0.0 se não houver desconto

        Note:
            Remove prefixo "De:" antes de parsear
        """
        del_tag = elem.find('del', class_='blocoproduto__oldprice')
        if not del_tag:
            return 0.0

        old_price_text = del_tag.get_text(strip=True)
        if not old_price_text:
            return 0.0

        # Remover prefixo "De:" se presente
        old_price_text_clean = old_price_text.replace('De:', '').replace('de:', '').strip()

        try:
            return parse_price(old_price_text_clean)
        except (ValueError, TypeError) as e:
            logger.debug(f"Failed to parse old price '{old_price_text_clean}': {e}")
            return 0.0

    def is_last_page(self, response: ResponseData) -> bool:
        """
        Verifica se a resposta indica que é a última página de resultados.

        Lógica:
        1. Se status 404 → última página
        2. Se status 200 mas from_json() retorna lista vazia → última página
        3. Caso contrário → há mais páginas

        Args:
            response: Objeto ResponseData contendo status e dados da resposta

        Returns:
            bool: True se for a última página, False caso contrário

        Example:
            >>> response = ResponseData(
            ...     url="https://www.kalunga.com.br/api?page=10",
            ...     status_code=404,
            ...     headers={'content-type': 'application/json'},
            ...     body=""
            ... )
            >>> parser.is_last_page(response)
            True
        """
        # Caso 1: Status 404 = última página
        if response.is_not_found():
            logger.info("Resposta 404, assumindo última página da Kalunga.")
            return True

        # Caso 2: Status 200 mas sem produtos = última página
        try:
            json_data = response.to_json()
            if not json_data:
                logger.info("JSON vazio, assumindo última página da Kalunga.")
                return True

            # Tentar extrair produtos
            products = self.from_json(json_data)
            if not products or len(products) == 0:
                logger.info("Nenhum produto retornado, esta é a última página da Kalunga.")
                return True

        except Exception as e:
            logger.warning(f"Erro ao parsear JSON da Kalunga: {e}, assumindo última página.")
            return True

        # Caso 3: Há produtos = não é última página
        return False

    def from_product_page_html(self, html_data: str) -> Optional[Product]:
        """
        Extrai um produto de uma página HTML de produto.

        Args:
            html_data: String contendo HTML da página de produto

        Returns:
            Objeto Product extraído ou None se não for possível extrair

        Raises:
            ParserError: Parser não suporta extração de página de produto HTML ainda
        """
        raise ParserError("Product page HTML parsing is not implemented for Kalunga yet.")

    def from_product_api_json(self, json_data: dict) -> Optional[Product]:
        """
        Extrai um produto de dados JSON da API.

        Args:
            json_data: Dicionário contendo resposta JSON da API

        Returns:
            Objeto Product extraído ou None se não for possível extrair

        Raises:
            ParserError: Parser não suporta extração de produto via API JSON ainda
        """
        raise ParserError("Product API JSON parsing is not implemented for Kalunga yet.")


class NetShoesHTMLParser(StoresParserInterface):
    """
    Parser para HTML da Netshoes com dataLayer embedded.

    Extrai produtos de páginas HTML da Netshoes que contêm dados JSON
    embedded via Google Tag Manager DataLayer (window.dataLayer).

    Características:
    - Parse via regex: extrai JSON de `window.dataLayer = [...]`
    - Navega: `json_data[0]['ecommerce']['impressions']`
    - Calcula `old_price` a partir de `discount` (em centavos)
    - Formata URLs completas
    - **NÃO** suporta extração de cupons (dataLayer não fornece essa informação)

    Campos extraídos:
    - `product_id`: ID do produto (ex: "E48-0398-014")
    - `sku`: Mesmo que product_id
    - `name`: Nome completo do produto
    - `current_price_float`: Preço atual (field: `price`)
    - `old_price_float`: Preço antigo calculado (`price + discount/100`)
    - `url`: https://www.netshoes.com.br/p/{item_name}-{item_id}
    - `image_url`: https://static.netshoes.com.br/produtos/net_shoes/06/{id}/{id}_zoom1.jpg
    - `info_product_url`: https://www.netshoes.com.br/frdmprcsts/{product_id}/lazy
    - `marketplace_name`: "Netshoes" (hardcoded)
    - `seller`: "Netshoes" (hardcoded - todos produtos são próprios)
    - `available`: True (hardcoded - produtos indisponíveis não aparecem)
    - `coupon`: None (dataLayer não fornece informações de cupom)

    Lógica de preços:
    - `current_price = impressions[i].price`
    - `old_price = price + (discount / 100)` se `discount > 0`
    - `old_price = 0.0` se `discount == 0`

    Validações:
    - Ignora produtos com `price <= 0`
    - Deduplicação automática por `item_id`

    Exemplo:
        >>> parser = NetShoesHTMLParser()
        >>> with open('netshoes.html') as f:
        ...     html = f.read()
        >>> products = parser.from_html(html)
        >>> len(products)
        42
    """

    def from_html(self, html_data: str) -> list[Product]:
        """
        Extrai produtos da Netshoes de HTML com dataLayer embedded.

        Args:
            html_data: String contendo HTML completo da página

        Returns:
            Lista de objetos Product extraídos do dataLayer.
            Lista vazia se não houver produtos ou dataLayer não existir.

        Raises:
            ParserError: Se houver erro crítico no parsing do JSON

        Estrutura esperada (HTML):
            <script>
              window.dataLayer = [{
                "ecommerce": {
                  "impressions": [
                    {
                      "id": "E48-0398",
                      "name": "Monitor Smart LG...",
                      "brand": "LG",
                      "price": 2421.04,
                      "discount": 0,  // Em centavos!
                      "discountPercent": "0%",
                      "item_id": "E48-0398-014",
                      "item_name": "monitor-smart-lg-myview-32...",
                      "seller": "L_NETSHOES"
                    }
                  ]
                }
              }];
            </script>

        Example:
            >>> parser = NetShoesHTMLParser()
            >>> html = '<script>window.dataLayer = [{"ecommerce": {...}}];</script>'
            >>> products = parser.from_html(html)
        """
        import re

        products: list[Product] = []
        logger.debug("Parsing Netshoes products from HTML")

        # Extrair JSON do dataLayer via regex
        try:
            # Extrair conteúdo do window.dataLayer
            if 'window.dataLayer = ' not in html_data:
                logger.warning("window.dataLayer not found in HTML.")
                return []

            # Pegar tudo após 'window.dataLayer = '
            after_datalayer = html_data.split('window.dataLayer = ', 1)[1]

            # Encontrar o fim do array JSON contando brackets
            bracket_count = 0
            end_pos = 0
            for i, char in enumerate(after_datalayer):
                if char == '[':
                    bracket_count += 1
                elif char == ']':
                    bracket_count -= 1
                    if bracket_count == 0:
                        end_pos = i + 1
                        break

            if end_pos == 0:
                logger.warning("dataLayer array terminator not found.")
                return []

            json_str = after_datalayer[:end_pos]

            # Tentar orjson primeiro, fallback para json nativo
            try:
                import orjson
                datalayer = orjson.loads(json_str)
            except ImportError:
                import json as _json
                datalayer = _json.loads(json_str)

        except Exception as e:
            logger.error(f"Failed to parse dataLayer JSON: {e}")
            raise ParserError(f"Invalid dataLayer JSON format: {e}")

        # Navegar até impressions
        if not datalayer or not isinstance(datalayer, list) or len(datalayer) == 0:
            logger.warning("dataLayer is empty or not a list.")
            return []

        ecommerce = datalayer[0].get("ecommerce", {})
        impressions = ecommerce.get("impressions", [])

        if not impressions:
            logger.warning("No impressions found in dataLayer.")
            return []

        total_products_processed = 0
        total_products_ignored = 0
        seen_ids = set()

        for impression in impressions:
            try:
                # Campos obrigatórios
                product_id = impression.get("item_id") or impression.get("skuFather") or impression.get("id")
                if not product_id:
                    logger.debug("Product without ID, skipping.")
                    total_products_ignored += 1
                    continue

                # Deduplicação
                if product_id in seen_ids:
                    logger.debug(f"Duplicate product {product_id}, skipping.")
                    total_products_ignored += 1
                    continue
                seen_ids.add(product_id)

                product_name = impression.get("name", "")
                current_price = float(impression.get("price", 0))

                # Validação: Preço válido
                if current_price <= 0:
                    logger.debug(f"Product {product_id} has invalid price ({current_price}), skipping.")
                    total_products_ignored += 1
                    continue

                # Calcular old_price a partir do discount (em centavos!)
                discount_cents = impression.get("discount", 0)
                old_price = 0.0
                if discount_cents > 0:
                    discount_reais = float(discount_cents) / 100.0
                    old_price = current_price + discount_reais

                # URL do produto
                item_name = impression.get("item_name", "")
                product_url = f"https://www.netshoes.com.br/p/{item_name}-{product_id}" if item_name else ""

                # URL da imagem: https://static.netshoes.com.br/produtos/net_shoes/06/{id}/{id}_zoom1.jpg
                image_url = f"https://static.netshoes.com.br/produtos/net_shoes/06/{product_id}/{product_id}_zoom1.jpg"

                # URL da API de informações do produto
                product_info_url = f"https://www.netshoes.com.br/frdmprcsts/{product_id}/lazy"

                # Criar Product
                product = Product(
                    product_id=str(product_id),
                    name=product_name,
                    current_price_float=current_price,
                    old_price_float=old_price,
                    url=product_url,
                    image_url=image_url,
                    sku=str(product_id),
                    available=True,  # Produtos indisponíveis não aparecem
                    marketplace_name="Netshoes",
                    seller="Netshoes",  # Todos são L_NETSHOES
                    coupon=None,  # Não disponível no dataLayer
                    product_info_url=product_info_url
                )

                products.append(product)
                total_products_processed += 1

            except Exception as e:
                logger.error(f"Unexpected error processing product {impression.get('item_id')}: {e}")
                total_products_ignored += 1
                continue

        logger.info(
            f"Extracted {total_products_processed} products from {len(impressions)} impressions "
            f"({total_products_ignored} ignored)"
        )

        return products

    def from_json(self, json_data: dict) -> list[Product]:
        """
        JSON parsing não suportado para Netshoes HTML.

        Args:
            json_data: Dicionário JSON

        Raises:
            ParserError: Sempre - Netshoes usa HTML com dataLayer embedded
        """
        raise ParserError("JSON parsing is not supported for Netshoes HTML. Use from_html() instead.")

    def is_last_page(self, response: ResponseData) -> bool:
        """
        Verifica se é a última página de resultados.

        Lógica:
        - Extrai dataLayer do HTML
        - Verifica se `ecommerce.impressions` está vazio
        - Retorna True se não houver produtos

        Args:
            response: Objeto ResponseData contendo status e body HTML

        Returns:
            True se for a última página (sem produtos), False caso contrário

        Example:
            >>> response = ResponseData(url="...", status_code=200, headers={}, body=html)
            >>> parser.is_last_page(response)
            False
        """
        # Caso 1: HTTP 404
        if response.is_not_found():
            logger.info("Netshoes returned 404, last page detected.")
            return True

        # Caso 2: Parsear HTML e verificar se há produtos
        try:
            products = self.from_html(response.body or "")
            if not products or len(products) == 0:
                logger.info("No products in dataLayer, last page detected.")
                return True
        except Exception as e:
            logger.warning(f"Error parsing Netshoes HTML: {e}, assuming last page.")
            return True

        # Caso 3: Há produtos = não é última página
        return False

    def from_product_page_html(self, html_data: str) -> Optional[Product]:
        """
        Extrai um produto de uma página HTML de produto.

        Args:
            html_data: String contendo HTML da página de produto

        Returns:
            Objeto Product extraído ou None se não for possível extrair

        Raises:
            ParserError: Parser não suporta extração de página de produto HTML ainda
        """
        raise ParserError("Product page HTML parsing is not implemented for Netshoes yet.")

    def from_product_api_json(self, json_data: dict) -> Optional[Product]:
        """
        Extrai um produto único de dados JSON da API Netshoes (frdmprcsts).

        Esta API retorna informações detalhadas de um produto específico,
        incluindo preços, seller, parcelamento e disponibilidade.

        Args:
            json_data: Dicionário contendo resposta JSON da API
                URL típica: https://www.netshoes.com.br/frdmprcsts/{product_id}/lazy

        Returns:
            Objeto Product extraído ou None se não for possível extrair

        Estrutura esperada:
            {
                "sku": "LCT-0208-006-01",
                "sellerId": "29198",
                "sellerName": "Magalu Oficial",
                "listPrice": 59900,  // Centavos
                "salePrice": 45505,  // Centavos (com desconto PIX)
                "finalPriceWithoutPaymentBenefitDiscount": 47900,  // Centavos (sem PIX)
                "discountPrice": 12000,  // Centavos
                "discountPercent": 20,
                "freeShipping": true,
                "stamps": [...],
                "preSale": false
            }

        Lógica de preços:
        - current_price = salePrice (preço com desconto PIX)
        - old_price = listPrice (preço original de lista)
        - Se salePrice == 0, usa finalPriceWithoutPaymentBenefitDiscount

        Example:
            >>> parser = NetShoesHTMLParser()
            >>> with open('netshoes_product_api.json') as f:
            ...     data = json.load(f)
            >>> product = parser.from_product_api_json(data)
            >>> product.current_price_float
            455.05
        """
        logger.debug("Parsing Netshoes product from API JSON")

        try:
            # Campos obrigatórios
            sku = json_data.get("sku")
            if not sku:
                logger.warning("Product without SKU, cannot extract.")
                return None

            # Preços (em centavos)
            list_price_cents = json_data.get("listPrice", 0)
            sale_price_cents = json_data.get("salePrice", 0)
            final_price_cents = json_data.get("finalPriceWithoutPaymentBenefitDiscount", 0)

            # Lógica de preços
            # current_price: prioriza salePrice (PIX), fallback para finalPrice
            current_price = 0.0
            if sale_price_cents > 0:
                current_price = float(sale_price_cents) / 100.0
            elif final_price_cents > 0:
                current_price = float(final_price_cents) / 100.0

            # Validação: Preço válido
            if current_price <= 0:
                logger.debug(f"Product {sku} has invalid price ({current_price}), skipping.")
                return None

            # old_price: listPrice
            old_price = 0.0
            if list_price_cents > 0 and list_price_cents > sale_price_cents:
                old_price = float(list_price_cents) / 100.0

            # Seller
            seller_name = json_data.get("sellerName", "Netshoes")
            marketplace_name = "Netshoes"

            # Disponibilidade (assumimos disponível se a API retornou dados)
            available = not json_data.get("preSale", False)

            # URLs (não temos nome do produto nesta API, então usamos apenas SKU)
            product_id = sku
            product_url = f"https://www.netshoes.com.br/p/{sku}"  # Não temos slug nesta API
            image_url = f"https://static.netshoes.com.br/produtos/net_shoes/06/{sku}/{sku}_zoom1.jpg"
            product_info_url = f"https://www.netshoes.com.br/frdmprcsts/{sku}/lazy"

            # Nome do produto (não disponível nesta API, usar SKU)
            product_name = sku

            # Criar Product
            product = Product(
                product_id=str(product_id),
                name=product_name,
                current_price_float=current_price,
                old_price_float=old_price,
                url=product_url,
                image_url=image_url,
                sku=str(sku),
                available=available,
                marketplace_name=marketplace_name,
                seller=seller_name,
                coupon=None,  # Não disponível nesta API
                product_info_url=product_info_url
            )

            logger.debug(f"Extracted product {product_id} from API JSON")
            return product

        except Exception as e:
            logger.error(f"Unexpected error processing Netshoes product API JSON: {e}")
            return None


class StanleyHTMLParser(StoresParserInterface):
    """
    Parser para HTML da Stanley (Shopify).

    Extrai produtos de páginas HTML de coleções da Stanley (stanley1913.com.br),
    utilizando data-attributes dos product cards para máxima performance.

    Características:
    - Expansão de variantes: cada cor/variante vira um Product individual
    - Extração via data-attributes para máxima performance
    - Suporte a cupons de desconto via badge por variante
    - Deduplicação automática por variant_id
    - Detecção de paginação via data-next-url

    Campos extraídos por variante:
    - `product_id`: variant_id Shopify (único por variante)
    - `sku`: SKU do produto pai (data-product-sku)
    - `name`: Nome da variante (data-variant-title)
    - `current_price_float`: Preço da variante (data-value-price em centavos / 100)
    - `old_price_float`: Preço antigo (data-value-compare-price em centavos / 100)
    - `url`: URL da variante (data-variant-url)
    - `image_url`: Imagem da variante (data-primary-image)
    - `coupon`: Cupom específico da variante (data-badge)
    - `marketplace_name`: "Stanley" (hardcoded)
    - `seller`: "Stanley" (hardcoded)
    - `available`: data-available="true"/"false" por variante

    Produtos sem variantes: extraídos do card principal (1 Product).

    Exemplo:
        >>> parser = StanleyHTMLParser()
        >>> with open('stanley.html', 'r', encoding='utf-8') as f:
        ...     html = f.read()
        >>> products = parser.from_html(html)
        >>> len(products)  # > 22 (variantes expandidas)
        52
    """

    _BASE_URL = "https://www.stanley1913.com.br"

    def __init__(self):
        """Inicializa parser e verifica dependência BeautifulSoup."""
        try:
            from bs4 import BeautifulSoup
            self.BeautifulSoup = BeautifulSoup
        except ImportError:
            raise ImportError(
                "beautifulsoup4 é necessário para StanleyHTMLParser. "
                "Instale com: pip install beautifulsoup4 lxml"
            )

    def from_json(self, json_data: dict) -> list[Product]:
        """
        JSON não suportado para Stanley.

        Raises:
            ParserError: Sempre — Stanley usa HTML, não JSON
        """
        raise ParserError("Stanley usa HTML parsing, não JSON. Use from_html().")

    def from_html(self, html_data: str) -> list[Product]:
        """
        Extrai produtos da Stanley de HTML de coleção Shopify.

        Expande variantes: cada cor/variante vira um Product individual.
        Produtos sem variantes são extraídos do card principal.

        Args:
            html_data: String contendo HTML da página de coleção

        Returns:
            Lista de objetos Product (variantes expandidas, deduplicados por variant_id).
        """
        products: list[Product] = []
        seen_ids: set[str] = set()
        duplicates_count = 0
        logger.debug("Parsing Stanley products from HTML")

        try:
            soup = self.BeautifulSoup(html_data, 'lxml')
        except Exception:
            soup = self.BeautifulSoup(html_data, 'html.parser')
            logger.debug("lxml not available, using html.parser")

        cards = soup.find_all('div', attrs={'data-product-card': True})
        logger.debug(f"Found {len(cards)} product cards in HTML")

        for card in cards:
            try:
                parent_id = card.get('data-id', '').strip()
                if not parent_id:
                    logger.warning("Product card sem data-id, ignorando")
                    continue

                sku = card.get('data-product-sku', '').strip()

                # Buscar swatches de variantes
                swatches = card.find_all('button', attrs={'data-grid-item-swatch': True})

                if swatches:
                    # Produto com variantes: expandir cada uma
                    for swatch in swatches:
                        variant_id = swatch.get('data-variant-id', '').strip()
                        if not variant_id:
                            continue

                        # Deduplicação por variant_id
                        if variant_id in seen_ids:
                            duplicates_count += 1
                            continue
                        seen_ids.add(variant_id)

                        # Preço via centavos (mais preciso que parsing de texto)
                        price_cents = swatch.get('data-value-price', '').strip()
                        current_price = int(price_cents) / 100.0 if price_cents else 0.0
                        if current_price <= 0:
                            logger.warning(f"Variante {variant_id} com preço inválido")
                            continue

                        # Preço antigo via centavos
                        compare_cents = swatch.get('data-value-compare-price', '').strip()
                        old_price = int(compare_cents) / 100.0 if compare_cents else 0.0

                        # Nome da variante
                        name = swatch.get('data-variant-title', '').strip()

                        # URL da variante
                        variant_url = swatch.get('data-variant-url', '').strip()
                        url = f"{self._BASE_URL}{variant_url}" if variant_url else ''

                        # Imagem da variante (protocol-relative → https)
                        image_url = self._make_absolute_url(
                            swatch.get('data-primary-image', '')
                        )

                        # Cupom específico da variante
                        coupon = self._extract_coupon_from_swatch(swatch)

                        # Disponibilidade da variante
                        available = swatch.get('data-available') == 'true'

                        product = Product(
                            product_id=variant_id,
                            name=name,
                            current_price_float=current_price,
                            old_price_float=old_price,
                            url=url,
                            image_url=image_url,
                            sku=sku,
                            available=available,
                            marketplace_name="Stanley",
                            seller="Stanley",
                            coupon=coupon
                        )
                        products.append(product)
                else:
                    # Produto sem variantes: extrair do card principal
                    if parent_id in seen_ids:
                        duplicates_count += 1
                        continue
                    seen_ids.add(parent_id)

                    price_str = card.get('data-product-price', '').strip()
                    current_price = self._parse_price_br(price_str)
                    if current_price <= 0:
                        logger.warning(f"Produto {parent_id} com preço inválido: {price_str}")
                        continue

                    # Preço antigo do card
                    old_price = 0.0
                    if card.get('data-discount-price') == '1':
                        compare_el = card.find(attrs={'data-compare-price': True})
                        if compare_el:
                            compare_text = compare_el.get_text(strip=True)
                            if compare_text:
                                old_price = self._parse_price_br(
                                    compare_text.replace('R$', '').strip()
                                )

                    name = card.get('data-product-name', '').strip()

                    link_el = card.find('a', attrs={'data-grid-item-url': True})
                    href = link_el.get('href', '') if link_el else ''
                    url = f"{self._BASE_URL}{href}" if href else ''

                    img_el = card.find('img', attrs={'data-product-image': True})
                    image_url = self._make_absolute_url(
                        img_el.get('src', '') if img_el else ''
                    )

                    coupon = self._extract_coupon(card)

                    product = Product(
                        product_id=parent_id,
                        name=name,
                        current_price_float=current_price,
                        old_price_float=old_price,
                        url=url,
                        image_url=image_url,
                        sku=sku,
                        available=True,
                        marketplace_name="Stanley",
                        seller="Stanley",
                        coupon=coupon
                    )
                    products.append(product)

            except Exception as e:
                logger.error(f"Erro ao processar product card: {e}")
                continue

        logger.info(
            f"Stanley: extraídos {len(products)} variantes "
            f"({duplicates_count} duplicatas ignoradas)"
        )
        return products

    @staticmethod
    def _parse_price_br(price_str: str) -> float:
        """
        Converte preço formato BR para float.

        Exemplos: "1.269,00" → 1269.0, "269,00" → 269.0, "49,50" → 49.5

        Args:
            price_str: String de preço em formato brasileiro

        Returns:
            Valor float do preço, ou 0.0 se inválido
        """
        try:
            cleaned = price_str.replace('.', '').replace(',', '.')
            return float(cleaned)
        except (ValueError, AttributeError):
            return 0.0

    @staticmethod
    def _make_absolute_url(url: str) -> str:
        """
        Converte URL protocol-relative para absoluta com https.

        Args:
            url: URL que pode ser protocol-relative (//...) ou relativa

        Returns:
            URL absoluta com https:// ou string vazia
        """
        url = url.strip()
        if not url:
            return ''
        if url.startswith('//'):
            return f"https:{url}"
        return url

    def _extract_coupon_from_swatch(self, swatch) -> Optional['Coupon']:
        """
        Extrai cupom do data-badge de um swatch de variante.

        Args:
            swatch: Elemento button do swatch

        Returns:
            Objeto Coupon ou None
        """
        badge_text = swatch.get('data-badge', '').strip()
        if not badge_text or not badge_text.lower().startswith('cupom:'):
            return None
        return self._build_coupon(badge_text)

    def _extract_coupon(self, card) -> Optional['Coupon']:
        """
        Extrai cupom do badge do product card (para produtos sem variantes).

        Args:
            card: Elemento BeautifulSoup do product card

        Returns:
            Objeto Coupon ou None se não houver cupom
        """
        badge = card.find('span', attrs={'data-product-badge': True})
        if not badge:
            return None

        badge_text = badge.get('data-product-badge', '').strip()
        if not badge_text.lower().startswith('cupom:'):
            return None
        return self._build_coupon(badge_text)

    @staticmethod
    def _build_coupon(badge_text: str) -> Optional['Coupon']:
        """
        Cria Coupon a partir de texto de badge no formato "Cupom: CODE".

        Tenta extrair percentual do código via regex (ex: WEEK40 → 40%).

        Args:
            badge_text: Texto do badge (ex: "Cupom: WEEK40")

        Returns:
            Objeto Coupon ou None se código vazio
        """
        import re

        code = badge_text.split(':', 1)[1].strip().upper()
        if not code:
            return None

        discount_value = 0.0
        match = re.search(r'(\d{1,2})', code)
        if match:
            discount_value = float(match.group(1))

        from notify_utils.models import Coupon
        return Coupon(
            code=code,
            discount_type="percentage",
            discount_value=discount_value,
            message=badge_text
        )

    def is_last_page(self, response: ResponseData) -> bool:
        """
        Detecta última página da coleção Stanley.

        Verifica:
        1. Status 404
        2. Atributo data-next-url vazio no grid de produtos
        3. Ausência de product cards

        Args:
            response: Dados da resposta HTTP

        Returns:
            True se for a última página
        """
        if response.is_not_found():
            return True

        if not response.body:
            return True

        try:
            soup = self.BeautifulSoup(response.body, 'lxml')
        except Exception:
            soup = self.BeautifulSoup(response.body, 'html.parser')

        # Verificar data-next-url no grid
        grid = soup.find('ul', attrs={'data-product-grid': True})
        if grid:
            next_url = grid.get('data-next-url', '').strip()
            if not next_url:
                return True

        # Sem product cards = última página
        cards = soup.find_all('div', attrs={'data-product-card': True})
        if not cards:
            return True

        return False

    def from_product_api_json(self, json_data: dict) -> Optional[Product]:
        """
        Não implementado para Stanley.

        Raises:
            ParserError: Parser não suporta extração de produto via API JSON ainda
        """
        raise ParserError("Product API JSON parsing is not implemented for Stanley yet.")

    def from_product_page_html(self, html_data: str) -> Optional[Product]:
        """
        Não implementado para Stanley.

        Raises:
            ParserError: Parser não suporta extração de produto via HTML de página ainda
        """
        raise ParserError("Product page HTML parsing is not implemented for Stanley yet.")