from setuptools import setup, find_packages

setup(
    name="aura-browser",
    version="0.4.2",
    description="An AI-driven, lightning-fast stealth browser controller.",
    author="Your Name",
    author_email="your.email@example.com",
    packages=find_packages(),
    install_requires=[
        "DrissionPage>=4.0.0"
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.7',
)
