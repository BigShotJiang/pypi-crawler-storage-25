from DrissionPage import ChromiumPage, ChromiumOptions
from typing import List, Dict, Any

import time

class AIBrowser:
    def __init__(self, headless: bool = False, mute: bool = True, debug: bool = False):
        self.debug = debug
        co = ChromiumOptions()
        
        if headless:
            co.headless()
            
        if mute:
            co.mute(True)
            
        # Advanced stealth settings to bypass bot protection
        co.set_argument('--no-sandbox')
        co.set_argument('--disable-gpu')
        co.set_argument('--disable-blink-features=AutomationControlled')
        
        self.page = ChromiumPage(addr_or_opts=co)
        self.interactive_elements = {}
        if self.debug:
            print("[Aura-Browser] Initialized in DEBUG mode.")
        
    def go_to(self, url: str):
        """Navigate to a URL and wait for it to load completely."""
        if self.debug:
            print(f"[Aura-Browser] Navigating to: {url}")
        self.page.get(url)
        self.page.wait.doc_loaded() # Wait for the document
        time.sleep(3) # Extra wait for dynamic JavaScript frameworks (React/Vue) to render
        if self.debug:
            print(f"[Aura-Browser] Page fully loaded.")
        
    def get_interactive_elements(self) -> List[Dict[str, str]]:
        """
        Scans the page for interactive elements (buttons, links, inputs).
        Returns them as a list of dictionaries with unique IDs for AI to control.
        """
        self.interactive_elements.clear()
        elements_data = []
        
        # Selectors that an AI might want to interact with
        selectors = ['a', 'button', 'input', 'textarea', 'select', '[role="button"]']
        
        element_counter = 1
        for selector in selectors:
            for ele in self.page.eles(selector):
                try:
                    # Exclude hidden or non-interactive elements
                    if ele.states.is_displayed and not ele.attr('hidden') and not ele.states.is_disabled:
                        tag = ele.tag
                        # Filter out inputs that are likely not useful
                        if tag == 'input' and ele.attr('type') in ['hidden', 'checkbox', 'radio']:
                            continue
                            
                        eid = f"ID_{element_counter}"
                        self.interactive_elements[eid] = ele
                        
                        text_val = (ele.text or ele.attr('aria-label') or ele.attr('placeholder') or ele.attr('name') or '').strip()
                        elements_data.append({
                            "id": eid,
                            "tag": tag,
                            "text": text_val,
                            "type": ele.attr('type') if tag == 'input' else None
                        })
                        element_counter += 1
                except Exception:
                    pass
                    
        if self.debug:
            print(f"[Aura-Browser] Extracted {len(elements_data)} visible interactive elements.")
        return elements_data
        
    def _find_element_intelligently(self, identifier: str):
        """Finds an element by AI ID, fuzzy text match, or standard developer CSS/XPath locator."""
        # 1. Direct exact ID match (For AI)
        if identifier in self.interactive_elements:
            return self.interactive_elements[identifier]
            
        # 2. Intelligent fallback match (If AI hallucinates something like 'ID_SEARCH' or 'search')
        # We remove 'id_' just in case the AI made up a fake ID name.
        identifier_clean = identifier.lower().replace("id_", "").strip()
        if identifier_clean:
            for eid, ele in self.interactive_elements.items():
                text = ele.text or ele.attr('aria-label') or ele.attr('placeholder') or ele.attr('name') or ''
                if text and identifier_clean in text.lower():
                    return ele
                    
        # 3. For General Programmers! Treat identifier as a CSS/XPath or DrissionPage locator
        try:
            ele = self.page.ele(identifier, timeout=1)
            if ele:
                return ele
        except Exception:
            pass
            
        return None
        
    def click(self, element_id: str) -> bool:
        """Click an element intelligently."""
        ele = self._find_element_intelligently(element_id)
        if ele:
            try:
                # by_js=True helps bypass some tricky interceptors
                ele.click(by_js=True) 
                self.page.wait.doc_loaded()
                time.sleep(2)
                return True
            except Exception as e:
                print(f"Failed to click {element_id}: {e}")
                return False
        return False
        
    def type_text(self, element_id: str, text: str, press_enter: bool = False) -> bool:
        """Type text into an input intelligently."""
        ele = self._find_element_intelligently(element_id)
        if ele:
            try:
                ele.input(text, clear=True)
                if press_enter:
                    # Press enter key
                    self.page.actions.type('\n')
                self.page.wait.doc_loaded()
                time.sleep(2)
                return True
            except Exception as e:
                print(f"Failed to type in {element_id}: {e}")
                return False
        return False
        
    def take_screenshot(self, save_path: str = "screenshot.jpg"):
        """Take a screenshot of the current page and save it locally."""
        try:
            self.page.get_screenshot(path=save_path)
            return True
        except Exception as e:
            print(f"Failed to take screenshot: {e}")
            return False
        
    def get_page_text(self) -> str:
        """Extract clean, readable text from the current page."""
        return self.page.body.text
        
    def close(self):
        """Quit the browser."""
        self.page.quit()
