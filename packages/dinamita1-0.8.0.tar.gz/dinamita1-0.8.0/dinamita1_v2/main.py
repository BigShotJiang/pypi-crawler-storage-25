_CODIGO = '''\
# Problema 3

class Ciudad:

    def __init__(self):
        self.datos = []

    def ingresar(self):

        nombre = input("Ingrese nombre de la ciudad: ")

        while True:

            habitantes = int(input("Ingrese número de habitantes: "))

            if habitantes > 0:
                break

            else:
                print("Error: número de habitantes no válido")

        self.datos.append([nombre, habitantes])

    def vocales(self, texto):

        contador = 0
        i = 0

        while i < len(texto):

            letra = texto[i].lower()

            if letra == "a" or letra == "e" or letra == "i" or letra == "o" or letra == "u":
                contador += 1

            i += 1

        return contador

    def mostrar(self):

        for fila in self.datos:

            print("Ciudad:", fila[0])
            print("Habitantes:", fila[1])
            print("Cantidad de vocales:", self.vocales(fila[0]))


obj = Ciudad()
obj.ingresar()
obj.mostrar()

# Problema 4

class Cajero:

    def __init__(self, nombre, ventas):
        self.nombre = nombre
        self.ventas = ventas


class Negocio:

    def __init__(self):
        self.matriz = []

    def registrar(self):

        n = int(input("Ingrese cantidad de cajeros: "))

        for i in range(n):

            nombre = input("Ingrese nombre del cajero: ")

            while True:

                ventas = float(input("Ingrese ventas del día: "))

                if ventas >= 0:
                    break

                else:
                    print("Error: ventas no válidas")

            cajero = Cajero(nombre, ventas)

            self.matriz.append([cajero.nombre, cajero.ventas])

    def resultados(self):

        mayor = self.matriz[0]
        menor = self.matriz[0]

        i = 0

        while i < len(self.matriz):

            if self.matriz[i][1] > mayor[1]:
                mayor = self.matriz[i]

            elif self.matriz[i][1] < menor[1]:
                menor = self.matriz[i]

            i += 1

        print("Cajero con más ventas:", mayor[0])
        print("Cajero con menos ventas:", menor[0])


obj = Negocio()
obj.registrar()
obj.resultados()
'''


def mostrar_codigo():
    print(_CODIGO)
