# producto-codigo

Libreria que imprime el codigo del ejercicio de clase Producto.

## Instalacion

```bash
pip install producto-codigo
```

## Uso en Jupyter o Python

```python
from producto_codigo import mostrar_codigo

mostrar_codigo()
```
