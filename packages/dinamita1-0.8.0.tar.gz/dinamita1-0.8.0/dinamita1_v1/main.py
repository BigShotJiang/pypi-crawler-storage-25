_CODIGO = '''\
# Problema 1

class Cajero:

    def __init__(self, nombre, ventas):
        self.nombre = nombre
        self.ventas = ventas


class Empresa:

    def __init__(self):
        self.lista_cajeros = []

    def ingresar_datos(self):

        n = int(input("Ingrese cantidad de cajeros: "))

        for i in range(n):

            nombre = input("Ingrese nombre del cajero: ")

            while True:

                ventas = float(input("Ingrese ventas del día: "))

                if ventas >= 0:
                    break

                else:
                    print("Error: ventas no válidas")

            cajero = Cajero(nombre, ventas)
            self.lista_cajeros.append(cajero)

    def mostrar_resultados(self):

        mayor = self.lista_cajeros[0]
        menor = self.lista_cajeros[0]

        for cajero in self.lista_cajeros:

            if cajero.ventas > mayor.ventas:
                mayor = cajero

            elif cajero.ventas < menor.ventas:
                menor = cajero

        print("Cajero con más ventas:", mayor.nombre)
        print("Cajero con menos ventas:", menor.nombre)


obj = Empresa()
obj.ingresar_datos()
obj.mostrar_resultados()

# Problema 2

class Ciudad:

    def __init__(self):
        self.nombre = ""
        self.habitantes = 0

    def ingresar_datos(self):

        self.nombre = input("Ingrese nombre de la ciudad: ")

        while True:

            self.habitantes = int(input("Ingrese número de habitantes: "))

            if self.habitantes > 0:
                break

            else:
                print("Error: número de habitantes no válido")

    def contar_vocales(self):

        contador = 0

        for letra in self.nombre.lower():

            if letra == "a" or letra == "e" or letra == "i" or letra == "o" or letra == "u":
                contador += 1

        return contador

    def mostrar_resultado(self):

        print("Ciudad:", self.nombre)
        print("Habitantes:", self.habitantes)
        print("Cantidad de vocales:", self.contar_vocales())


obj = Ciudad()
obj.ingresar_datos()
obj.mostrar_resultado()
'''


def mostrar_codigo():
    print(_CODIGO)
