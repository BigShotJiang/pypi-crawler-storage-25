from __future__ import annotations

import os

import pytest

from capsule_sdk._config import ConnectionConfig


class TestConnectionConfig:
    def test_explicit_values(self) -> None:
        cfg = ConnectionConfig.resolve(
            base_url="http://example.com",
            token="token123",
            tenant_id="test-tenant",
            request_timeout=10.0,
            startup_timeout=50.0,
            operation_timeout=90.0,
        )
        assert cfg.base_url == "http://example.com"
        assert cfg.token == "token123"
        assert cfg.tenant_id == "test-tenant"
        assert cfg.timeout == 10.0
        assert cfg.request_timeout == 10.0
        assert cfg.startup_timeout == 50.0
        assert cfg.operation_timeout == 90.0
        assert "capsule-sdk-python" in cfg.user_agent

    def test_env_fallback(self, monkeypatch: object) -> None:
        import pytest

        mp = pytest.MonkeyPatch()
        mp.setenv("CAPSULE_BASE_URL", "http://env-host:9090")
        mp.setenv("CAPSULE_TOKEN", "env-token")
        mp.setenv("CAPSULE_TENANT_ID", "env-tenant")
        try:
            cfg = ConnectionConfig.resolve(tenant_id="")
            assert cfg.base_url == "http://env-host:9090"
            assert cfg.token == "env-token"
            assert cfg.tenant_id == "env-tenant"
        finally:
            mp.undo()

    def test_defaults(self) -> None:
        # Clear env vars if set
        env_backup = {}
        for key in ("CAPSULE_BASE_URL", "CAPSULE_TOKEN", "CAPSULE_TENANT_ID"):
            if key in os.environ:
                env_backup[key] = os.environ.pop(key)
        try:
            with pytest.raises(ValueError, match="tenant_id is required"):
                ConnectionConfig.resolve(tenant_id="")
        finally:
            os.environ.update(env_backup)

    def test_trailing_slash_stripped(self) -> None:
        cfg = ConnectionConfig.resolve(base_url="http://example.com/", tenant_id="test-tenant")
        assert cfg.base_url == "http://example.com"
