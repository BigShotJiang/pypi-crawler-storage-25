import logging,re
from functools import lru_cache
from typing import Any
from localstack_cli.utils.numbers import format_bytes
from localstack_cli.utils.strings import to_bytes
MAX_THREAD_NAME_LEN=12
MAX_NAME_LEN=26
LOG_FORMAT=f"%(asctime)s.%(msecs)03d %(ls_level)5s --- [%(ls_thread){MAX_THREAD_NAME_LEN}s] %(ls_name)-{MAX_NAME_LEN}s : %(message)s"
LOG_DATE_FORMAT='%Y-%m-%dT%H:%M:%S'
LOG_INPUT_FORMAT='%(input_type)s(%(input)s, headers=%(request_headers)s)'
LOG_OUTPUT_FORMAT='%(output_type)s(%(output)s, headers=%(response_headers)s)'
LOG_CONTEXT_FORMAT='%(account_id)s/%(region)s'
CUSTOM_LEVEL_NAMES={50:'FATAL',40:'ERROR',30:'WARN',20:'INFO',10:'DEBUG'}
class DefaultFormatter(logging.Formatter):
	def __init__(A,fmt=LOG_FORMAT,datefmt=LOG_DATE_FORMAT):super().__init__(fmt=fmt,datefmt=datefmt)
class AddFormattedAttributes(logging.Filter):
	max_name_len:int;max_thread_len:int
	def __init__(A,max_name_len:int=None,max_thread_len:int=None):C=max_thread_len;B=max_name_len;super().__init__();A.max_name_len=B if B else MAX_NAME_LEN;A.max_thread_len=C if C else MAX_THREAD_NAME_LEN
	def filter(B,record):A=record;A.ls_level=CUSTOM_LEVEL_NAMES.get(A.levelno,A.levelname);A.ls_name=B._get_compressed_logger_name(A.name);A.ls_thread=A.threadName[-B.max_thread_len:];return True
	@lru_cache(maxsize=256)
	def _get_compressed_logger_name(self,name):return compress_logger_name(name,self.max_name_len)
class MaskSensitiveInputFilter(logging.Filter):
	patterns:list[tuple[re.Pattern[bytes],bytes]]
	def __init__(A,sensitive_keys:list[str]):super().__init__();A.patterns=[(re.compile(to_bytes(f'"{A}":\\s*"[^"]+"')),to_bytes(f'"{A}": "******"'))for A in sensitive_keys]
	def filter(B,record):
		A=record
		if A.input and isinstance(A.input,bytes):A.input=B.mask_sensitive_msg(A.input)
		return True
	def mask_sensitive_msg(B,message:bytes)->bytes:
		A=message
		for(C,D)in B.patterns:A=re.sub(C,D,A)
		return A
def compress_logger_name(name:str,length:int)->str:
	D=length;C=name
	if len(C)<=D:return C
	A=C.split('.');A.reverse();B=[];E=len(A)*2-1
	for F in range(len(A)):
		G=A[F];H=E+(len(G)-1)
		if H>D:
			B+=[A[0]for A in A[F:]]
			if F==0:
				I=D-E
				if I>0:B[0]=G[:I+1]
			break
		B.append(G);E=H
	B.reverse();return'.'.join(B)
class TraceLoggingFormatter(logging.Formatter):
	aws_trace_log_format='; '.join([LOG_FORMAT,LOG_INPUT_FORMAT,LOG_OUTPUT_FORMAT]);bytes_length_display_threshold=512
	def __init__(A):super().__init__(fmt=A.aws_trace_log_format,datefmt=LOG_DATE_FORMAT)
	def _replace_large_payloads(A,input:Any)->Any:
		if isinstance(input,bytes)and len(input)>A.bytes_length_display_threshold:return f"Bytes({format_bytes(len(input))})"
		return input
	def format(B,record:logging.LogRecord)->str:A=record;A.input=B._replace_large_payloads(A.input);A.output=B._replace_large_payloads(A.output);return super().format(record=A)
class AwsTraceLoggingFormatter(TraceLoggingFormatter):
	aws_trace_log_format='; '.join([LOG_FORMAT,LOG_CONTEXT_FORMAT,LOG_INPUT_FORMAT,LOG_OUTPUT_FORMAT])
	def __init__(A):super().__init__()
	def _copy_service_dict(D,service_dict:dict)->dict:
		E=service_dict
		if not isinstance(E,dict):return E
		B={}
		for(C,A)in E.items():
			if isinstance(A,dict):B[C]=D._copy_service_dict(A)
			elif isinstance(A,bytes)and len(A)>D.bytes_length_display_threshold:B[C]=f"Bytes({format_bytes(len(A))})"
			elif isinstance(A,list):B[C]=[D._copy_service_dict(A)for A in A]
			else:B[C]=A
		return B
	def format(B,record:logging.LogRecord)->str:A=record;A.input=B._copy_service_dict(A.input);A.output=B._copy_service_dict(A.output);return super().format(record=A)