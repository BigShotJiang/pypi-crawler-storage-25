_BM='LOCALSTACK_CLI'
_BL='PROVIDER_OVERRIDE_'
_BK='STATE_SERIALIZATION_BACKEND'
_BJ='LOCALSTACK_RESPONSE_HEADER_ENABLED'
_BI='IN_MEMORY_CLIENT'
_BH='DISTRIBUTED_MODE'
_BG='DISABLE_BOTO_RETRIES'
_BF='DISABLE_CUSTOM_BOTO_WAITER_CONFIG'
_BE='BOTO_WAITER_MAX_ATTEMPTS'
_BD='BOTO_WAITER_DELAY'
_BC='DNS_VERIFICATION_DOMAIN'
_BB='DNS_SERVER'
_BA='DNS_RESOLVE_IP'
_B9='DNS_LOCAL_NAME_PATTERNS'
_B8='DNS_NAME_PATTERNS_TO_RESOLVE_UPSTREAM'
_B7='DNS_ADDRESS'
_B6='CFN_IGNORE_UNSUPPORTED_RESOURCE_TYPES'
_B5='CFN_PER_RESOURCE_TIMEOUT'
_B4='CFN_STRING_REPLACEMENT_DENY_LIST'
_B3='CFN_VERBOSE_ERRORS'
_B2='PARITY_AWS_ACCESS_KEY_ID'
_B1='MAIN_DOCKER_NETWORK'
_B0='PROVIDER_OVERRIDE_DYNAMODB'
_A_='PROVIDER_OVERRIDE_DYNAMODBSTREAMS'
_Az='SNS_SES_SENDER_ADDRESS'
_Ay='LEGACY_SNS_GCM_PUBLISHING'
_Ax='OPENSEARCH_ENDPOINT_STRATEGY'
_Aw='LAMBDA_SYNCHRONOUS_CREATE'
_Av='LAMBDA_TRUNCATE_STDOUT'
_Au='S3_SKIP_KMS_KEY_VALIDATION'
_At='S3_SKIP_SIGNATURE_VALIDATION'
_As='WINDOWS_DOCKER_MOUNT_PREFIX'
_Ar='LAMBDA_INIT_USER'
_Aq='LAMBDA_INIT_POST_INVOKE_WAIT_MS'
_Ap='LAMBDA_INIT_DELVE_PORT'
_Ao='LAMBDA_INIT_DELVE_PATH'
_An='LAMBDA_INIT_BOOTSTRAP_PATH'
_Am='LAMBDA_INIT_BIN_PATH'
_Al='LAMBDA_INIT_DEBUG'
_Ak='LAMBDA_INIT_RELEASE_VERSION'
_Aj='LAMBDA_DEV_PORT_EXPOSE'
_Ai='LAMBDA_LIMITS_MAX_FUNCTION_PAYLOAD_SIZE_BYTES'
_Ah='LAMBDA_LIMITS_MAX_FUNCTION_ENVVAR_SIZE_BYTES'
_Ag='LAMBDA_LIMITS_CREATE_FUNCTION_REQUEST_SIZE'
_Af='LAMBDA_LIMITS_CODE_SIZE_UNZIPPED'
_Ae='LAMBDA_LIMITS_CODE_SIZE_ZIPPED'
_Ad='LAMBDA_LIMITS_TOTAL_CODE_SIZE'
_Ac='LAMBDA_LIMITS_MINIMUM_UNRESERVED_CONCURRENCY'
_Ab='LAMBDA_LIMITS_CONCURRENT_EXECUTIONS'
_Aa='LAMBDA_KEEPALIVE_MS'
_AZ='LAMBDA_REMOVE_CONTAINERS'
_AY='LAMBDA_RUNTIME_VALIDATION'
_AX='LAMBDA_RUNTIME_IMAGE_MAPPING'
_AW='LAMBDA_RUNTIME_ENVIRONMENT_TIMEOUT'
_AV='LAMBDA_RUNTIME_EXECUTOR'
_AU='LAMBDA_PREBUILD_IMAGES'
_AT='LAMBDA_IGNORE_ARCHITECTURE'
_AS='LAMBDA_DOCKER_FLAGS'
_AR='LAMBDA_DOCKER_DNS'
_AQ='LAMBDA_DOCKER_NETWORK'
_AP='LAMBDA_DISABLE_AWS_ENDPOINT_URL'
_AO='BUCKET_MARKER_LOCAL'
_AN='HOSTNAME_FROM_LAMBDA'
_AM='SQS_CLOUDWATCH_METRICS_REPORT_INTERVAL'
_AL='SQS_DISABLE_CLOUDWATCH_METRICS'
_AK='SQS_ENDPOINT_STRATEGY'
_AJ='SQS_ENABLE_MESSAGE_RETENTION_PERIOD'
_AI='SQS_DELAY_RECENTLY_DELETED'
_AH='SQS_DELAY_PURGE_RETRY'
_AG='DYNAMODB_REMOVE_EXPIRED_ITEMS'
_AF='DYNAMODB_LOCAL_PORT'
_AE='DYNAMODB_SHARE_DB'
_AD='DYNAMODB_HEAP_SIZE'
_AC='DYNAMODB_WRITE_ERROR_PROBABILITY'
_AB='DYNAMODB_READ_ERROR_PROBABILITY'
_AA='DYNAMODB_ERROR_PROBABILITY'
_A9='KINESIS_ERROR_PROBABILITY'
_A8='KINESIS_MOCK_LOG_LEVEL'
_A7='KINESIS_MOCK_PERSIST_INTERVAL'
_A6='KINESIS_ON_DEMAND_STREAM_COUNT_LIMIT'
_A5='KINESIS_PERSISTENCE'
_A4='LAMBDA_JAVA_OPTS'
_A3='CONTAINER_RUNTIME'
_A2='EVENT_RULE_ENGINE'
_A1='OPENAPI_VALIDATE_REQUEST'
_A0='OPENAPI_VALIDATE_RESPONSE'
_z='OUTBOUND_HTTPS_PROXY'
_y='OUTBOUND_HTTP_PROXY'
_x='MAIN_CONTAINER_NAME'
_w='ALLOW_NONSTANDARD_REGIONS'
_v='REMOVE_SSL_CERT'
_u='CUSTOM_SSL_CERT_PATH'
_t='SKIP_SSL_CERT_DOWNLOAD'
_s='SKIP_INFRA_DOWNLOADS'
_r='STRICT_SERVICE_LOADING'
_q='EAGER_SERVICE_LOADING'
_p='DEBUG_HANDLER_CHAIN'
_o='DISABLE_EVENTS'
_n='EXTRA_CORS_ALLOWED_ORIGINS'
_m='EXTRA_CORS_EXPOSE_HEADERS'
_l='EXTRA_CORS_ALLOWED_HEADERS'
_k='DISABLE_CUSTOM_CORS_APIGATEWAY'
_j='DISABLE_CUSTOM_CORS_S3'
_i='DISABLE_CORS_CHECKS'
_h='DISABLE_CORS_HEADERS'
_g='ENABLE_CONFIG_UPDATES'
_f='DOCKER_SDK_DEFAULT_TIMEOUT_SECONDS'
_e='DOCKER_BRIDGE_IP'
_d='GATEWAY_SERVER'
_c='GATEWAY_LISTEN'
_b='LOCALSTACK_HOST'
_a='PORTS_CHECK_DOCKER_IMAGE'
_Z='LEGACY_DOCKER_CLIENT'
_Y='TF_COMPAT_MODE'
_X='USE_SSL'
_W='WAIT_FOR_DEBUGGER'
_V='DEVELOP_PORT'
_U='DEVELOP'
_T='LAMBDA_DEBUG_MODE'
_S='LS_LOG'
_R='SNAPSHOT_FLUSH_INTERVAL'
_Q='SNAPSHOT_SAVE_STRATEGY'
_P='SNAPSHOT_LOAD_STRATEGY'
_O='PERSISTENCE'
_N='DATA_DIR'
_M='default'
_L='no_proxy'
_K='docker'
_J='state'
_I='localstack'
_H='0.0.0.0'
_G='Directories'
_F='v2'
_E=','
_D=True
_C=False
_B='/'
_A=None
import ipaddress,logging,os,platform,re,socket,subprocess,tempfile,time,warnings
from collections import defaultdict
from collections.abc import Mapping
from typing import Any,TypeVar
from localstack_cli import constants
from localstack_cli.constants import DEFAULT_BUCKET_MARKER_LOCAL,DEFAULT_DEVELOP_PORT,DEFAULT_VOLUME_DIR,ENV_INTERNAL_TEST_COLLECT_METRIC,ENV_INTERNAL_TEST_RUN,ENV_INTERNAL_TEST_STORE_METRICS_IN_LOCALSTACK,FALSE_STRINGS,LOCALHOST,LOCALHOST_IP,LOCALSTACK_ROOT_FOLDER,LOG_LEVELS,TRACE_LOG_LEVELS,TRUE_STRINGS
T=TypeVar('T',str,int)
load_start_time=time.time()
class Directories:
	static_libs:str;var_libs:str;cache:str;tmp:str;mounted_tmp:str;functions:str;data:str;config:str;init:str;logs:str
	def __init__(self,static_libs:str,var_libs:str,cache:str,tmp:str,mounted_tmp:str,functions:str,data:str,config:str,init:str,logs:str)->_A:super().__init__();self.static_libs=static_libs;self.var_libs=var_libs;self.cache=cache;self.tmp=tmp;self.mounted_tmp=mounted_tmp;self.functions=functions;self.data=data;self.config=config;self.init=init;self.logs=logs
	@staticmethod
	def defaults()->_G:return Directories(static_libs='/usr/lib/localstack',var_libs=f"{DEFAULT_VOLUME_DIR}/lib",cache=f"{DEFAULT_VOLUME_DIR}/cache",tmp=os.path.join(tempfile.gettempdir(),_I),mounted_tmp=f"{DEFAULT_VOLUME_DIR}/tmp",functions=f"{DEFAULT_VOLUME_DIR}/tmp",data=f"{DEFAULT_VOLUME_DIR}/state",logs=f"{DEFAULT_VOLUME_DIR}/logs",config='/etc/localstack/conf.d',init='/etc/localstack/init')
	@staticmethod
	def for_container()->_G:defaults=Directories.defaults();return Directories(static_libs=defaults.static_libs,var_libs=defaults.var_libs,cache=defaults.cache,tmp=defaults.tmp,mounted_tmp=defaults.mounted_tmp,functions=defaults.functions,data=defaults.data if PERSISTENCE else os.path.join(defaults.tmp,_J),config=defaults.config,logs=defaults.logs,init=defaults.init)
	@staticmethod
	def for_host()->_G:root=os.environ.get('FILESYSTEM_ROOT')or os.path.join(LOCALSTACK_ROOT_FOLDER,'.filesystem');root=os.path.abspath(root);defaults=Directories.for_container();tmp=os.path.join(root,defaults.tmp.lstrip(_B));data=os.path.join(root,defaults.data.lstrip(_B));return Directories(static_libs=os.path.join(root,defaults.static_libs.lstrip(_B)),var_libs=os.path.join(root,defaults.var_libs.lstrip(_B)),cache=os.path.join(root,defaults.cache.lstrip(_B)),tmp=tmp,mounted_tmp=os.path.join(root,defaults.mounted_tmp.lstrip(_B)),functions=os.path.join(root,defaults.functions.lstrip(_B)),data=data if PERSISTENCE else os.path.join(tmp,_J),config=os.path.join(root,defaults.config.lstrip(_B)),init=os.path.join(root,defaults.init.lstrip(_B)),logs=os.path.join(root,defaults.logs.lstrip(_B)))
	@staticmethod
	def for_cli()->_G:A='localstack-cli';import tempfile;from localstack_cli.utils import files;tmp_dir=os.path.join(tempfile.gettempdir(),A);cache_dir=files.get_user_cache_dir().absolute()/A;return Directories(static_libs=_A,var_libs=_A,cache=str(cache_dir),tmp=tmp_dir,mounted_tmp=tmp_dir,functions=_A,data=os.path.join(tmp_dir,_J),logs=os.path.join(tmp_dir,'logs'),config=_A,init=_A)
	def mkdirs(self):
		for folder in[self.static_libs,self.var_libs,self.cache,self.tmp,self.mounted_tmp,self.functions,self.data,self.config,self.init,self.logs]:
			if folder and not os.path.exists(folder):
				try:os.makedirs(folder)
				except Exception:pass
	def __str__(self):return str(self.__dict__)
def eval_log_type(env_var_name:str)->str|bool:ls_log=os.environ.get(env_var_name,'').lower().strip();return ls_log if ls_log in LOG_LEVELS else _C
def parse_boolean_env(env_var_name:str)->bool|_A:
	value=os.environ.get(env_var_name,'').lower().strip()
	if value in TRUE_STRINGS:return _D
	if value in FALSE_STRINGS:return _C
def parse_comma_separated_list(env_var_name:str)->list[str]:return os.environ.get(env_var_name,'').strip().split(_E)
def is_env_true(env_var_name:str)->bool:return os.environ.get(env_var_name,'').lower().strip()in TRUE_STRINGS
def is_env_not_false(env_var_name:str)->bool:return os.environ.get(env_var_name,'').lower().strip()not in FALSE_STRINGS
def load_environment(profiles:str=_A,env=os.environ)->list[str]:
	if not profiles:profiles=_M
	profiles=profiles.split(_E);environment={};import dotenv
	for profile in profiles:
		profile=profile.strip();path=os.path.join(CONFIG_DIR,f"{profile}.env")
		if not os.path.exists(path):continue
		environment.update(dotenv.dotenv_values(path))
	for(k,v)in environment.items():
		if k not in env and v is not _A:env[k]=v
	return profiles
def is_persistence_enabled()->bool:return PERSISTENCE and dirs.data
def is_linux()->bool:return platform.system()=='Linux'
def is_macos()->bool:return platform.system()=='Darwin'
def is_windows()->bool:return platform.system().lower()=='windows'
def is_wsl()->bool:return platform.system().lower()=='linux'and os.environ.get('WSL_DISTRO_NAME')is not _A
def ping(host):is_in_windows=is_windows();ping_opts='-n 1 -w 2000'if is_in_windows else'-c 1 -W 2';args=f"ping {ping_opts} {host}";return subprocess.call(args,shell=not is_in_windows,stdout=subprocess.PIPE,stderr=subprocess.PIPE)==0
def in_docker():
	B='docker-';A='/proc/1/cgroup'
	if OVERRIDE_IN_DOCKER is not _A:return OVERRIDE_IN_DOCKER
	for path in['/usr/lib/localstack/.community-version','/usr/lib/localstack/.pro-version','/tmp/localstack/.marker']:
		if os.path.isfile(path):return _D
	if os.path.exists('/.dockerenv'):return _D
	if os.path.exists('/run/.containerenv'):return _D
	if not os.path.exists(A):return _C
	try:
		if any([os.path.exists('/sys/fs/cgroup/memory/docker/'),any(B in file_names for file_names in os.listdir('/sys/fs/cgroup/memory/system.slice')),os.path.exists('/sys/fs/cgroup/docker/'),any(B in file_names for file_names in os.listdir('/sys/fs/cgroup/system.slice/'))]):return _C
	except Exception:pass
	with open(A)as ifh:
		content=ifh.read()
		if _K in content or'buildkit'in content:return _D
		os_hostname=socket.gethostname()
		if os_hostname and os_hostname in content:return _D
	try:
		with open('/proc/mounts')as infile:
			for line in infile:
				line=line.strip()
				if not line:continue
				if line[0]=='#':continue
				parts=line.split()
				if len(parts)<4:continue
				mount_point=parts[1];options=parts[3]
				if mount_point!=_B:continue
				if'io.containerd'in options:return _D
	except FileNotFoundError:pass
	return _C
OVERRIDE_IN_DOCKER=parse_boolean_env('OVERRIDE_IN_DOCKER')
is_in_docker=in_docker()
is_in_linux=is_linux()
is_in_macos=is_macos()
is_in_windows=is_windows()
is_in_wsl=is_wsl()
default_ip=_H if is_in_docker else'127.0.0.1'
CONFIG_PROFILE=os.environ.get('CONFIG_PROFILE','').strip()
CONFIG_DIR=os.environ.get('CONFIG_DIR',os.path.expanduser('~/.localstack'))
try:LOADED_PROFILES=load_environment(CONFIG_PROFILE)
except ImportError:LOADED_PROFILES=_A
RUNTIME_COMPONENTS=os.environ.get('RUNTIME_COMPONENTS','').strip()
DATA_DIR=os.environ.get(_N,'').strip()
PERSISTENCE=is_env_true(_O)
SNAPSHOT_LOAD_STRATEGY=os.environ.get(_P,'').upper()
SNAPSHOT_SAVE_STRATEGY=os.environ.get(_Q,'').upper()
SNAPSHOT_FLUSH_INTERVAL=int(os.environ.get(_R)or 15)
CLEAR_TMP_FOLDER=is_env_not_false('CLEAR_TMP_FOLDER')
TMP_FOLDER=os.path.join(tempfile.gettempdir(),_I)
VOLUME_DIR=os.environ.get('LOCALSTACK_VOLUME_DIR','').strip()or TMP_FOLDER
if TMP_FOLDER.startswith('/var/folders/')and os.path.exists(f"/private{TMP_FOLDER}"):TMP_FOLDER=f"/private{TMP_FOLDER}"
LS_LOG=eval_log_type(_S)or eval_log_type('LOG')
DEBUG=is_env_true('DEBUG')or LS_LOG in TRACE_LOG_LEVELS
LAMBDA_DEBUG_MODE=is_env_true(_T)
LAMBDA_DEBUG_MODE_CONFIG_PATH=os.environ.get('LAMBDA_DEBUG_MODE_CONFIG_PATH')
LOG_LEVEL_OVERRIDES=os.environ.get('LOG_LEVEL_OVERRIDES','')
DEVELOP=is_env_true(_U)
DEVELOP_PORT=int(os.environ.get(_V,'').strip()or DEFAULT_DEVELOP_PORT)
WAIT_FOR_DEBUGGER=is_env_true(_W)
USE_SSL=is_env_true(_X)
FAIL_FAST=is_env_true('FAIL_FAST')
TF_COMPAT_MODE=is_env_true(_Y)
DEFAULT_ENCODING='utf-8'
DOCKER_SOCK=os.environ.get('DOCKER_SOCK','').strip()or'/var/run/docker.sock'
DOCKER_FLAGS=os.environ.get('DOCKER_FLAGS','').strip()
DOCKER_CMD=os.environ.get('DOCKER_CMD','').strip()or _K
LEGACY_DOCKER_CLIENT=is_env_true(_Z)
PORTS_CHECK_DOCKER_IMAGE=os.environ.get(_a,'').strip()
DOCKER_GLOBAL_IMAGE_PREFIX=os.environ.get('DOCKER_GLOBAL_IMAGE_PREFIX','').strip()
def is_trace_logging_enabled():
	if LS_LOG:log_level=str(LS_LOG).upper();return log_level.lower()in TRACE_LOG_LEVELS
	return _C
if DEBUG:logging.getLogger('').setLevel(logging.DEBUG);logging.getLogger(_I).setLevel(logging.DEBUG)
LOG=logging.getLogger(__name__)
if is_trace_logging_enabled():load_end_time=time.time();LOG.debug('Initializing the configuration took %s ms',int((load_end_time-load_start_time)*1000))
def is_ipv6_address(host:str)->bool:
	if not host:return _C
	try:ipaddress.IPv6Address(host);return _D
	except ipaddress.AddressValueError:return _C
class HostAndPort:
	host:str;port:int
	def __init__(self,host:str,port:int):self.host=host;self.port=port
	@classmethod
	def parse(cls,input:str,default_host:str,default_port:int)->'HostAndPort':
		host,port=default_host,default_port
		if input.startswith('['):
			ipv6_pattern=re.compile('^\\[(?P<host>[^]]+)\\](:(?P<port>\\d+))?$');match=ipv6_pattern.match(input)
			if match:
				host=match.group('host')
				if not is_ipv6_address(host):raise ValueError(f"input looks like an IPv6 address (is enclosed in square brackets), but is not valid: {host}")
				port_s=match.group('port')
				if port_s:port=cls._validate_port(port_s)
			else:raise ValueError(f'input looks like an IPv6 address, but is invalid. Should be formatted "[ip]:port": {input}')
		elif':'in input:
			hostname,port_s=input.split(':',1)
			if hostname.strip():host=hostname.strip()
			port=cls._validate_port(port_s)
		elif input.strip():host=input.strip()
		if port<0 or port>=2**16:raise ValueError('port out of range')
		return cls(host=host,port=port)
	@classmethod
	def _validate_port(cls,port_s:str)->int:
		try:port=int(port_s)
		except ValueError as e:raise ValueError(f"specified port {port_s} not a number")from e
		return port
	def _get_unprivileged_port_range_start(self)->int:
		try:
			with open('/proc/sys/net/ipv4/ip_unprivileged_port_start')as unprivileged_port_start:port=unprivileged_port_start.read();return int(port.strip())
		except Exception:return 1024
	def is_unprivileged(self)->bool:return self.port>=self._get_unprivileged_port_range_start()
	def host_and_port(self)->str:formatted_host=f"[{self.host}]"if is_ipv6_address(self.host)else self.host;return f"{formatted_host}:{self.port}"if self.port is not _A else formatted_host
	def __hash__(self)->int:return hash((self.host,self.port))
	def __eq__(self,other:'str | HostAndPort')->bool:
		if isinstance(other,self.__class__):return self.host==other.host and self.port==other.port
		elif isinstance(other,str):return str(self)==other
		else:raise TypeError(f"cannot compare {self.__class__} to {other.__class__}")
	def __str__(self)->str:return self.host_and_port()
	def __repr__(self)->str:return f"HostAndPort(host={self.host}, port={self.port})"
class UniqueHostAndPortList(list[HostAndPort]):
	def __init__(self,iterable:list[HostAndPort]|_A=_A):super().__init__(iterable or[]);self._ensure_unique()
	def _ensure_unique(self):
		if len(self)<=1:return
		unique:list[HostAndPort]=[];hosts_by_port:dict[int,list[str]]=defaultdict(list)
		for item in self:hosts_by_port[item.port].append(item.host)
		for(port,hosts)in hosts_by_port.items():
			deduped_hosts=set(hosts)
			if'::'in deduped_hosts:unique.append(HostAndPort(host='::',port=port));continue
			if _H in deduped_hosts:unique.append(HostAndPort(host=_H,port=port));continue
			unique.extend([HostAndPort(host=host,port=port)for host in deduped_hosts])
		self.clear();self.extend(unique)
	def append(self,value:HostAndPort):super().append(value);self._ensure_unique()
def populate_edge_configuration(environment:Mapping[str,str])->tuple[HostAndPort,UniqueHostAndPortList]:
	localstack_host_raw=environment.get(_b);gateway_listen_raw=environment.get(_c)
	if gateway_listen_raw is not _A:
		gateway_listen=[]
		for address in gateway_listen_raw.split(_E):gateway_listen.append(HostAndPort.parse(address.strip(),default_host=default_ip,default_port=constants.DEFAULT_PORT_EDGE))
	else:gateway_listen=[HostAndPort(host=default_ip,port=constants.DEFAULT_PORT_EDGE)]
	if localstack_host_raw is _A:localstack_host=HostAndPort(host=constants.LOCALHOST_HOSTNAME,port=gateway_listen[0].port)
	else:localstack_host=HostAndPort.parse(localstack_host_raw,default_host=constants.LOCALHOST_HOSTNAME,default_port=gateway_listen[0].port)
	assert gateway_listen is not _A;assert localstack_host is not _A;return localstack_host,UniqueHostAndPortList(gateway_listen)
LOCALSTACK_HOST,GATEWAY_LISTEN=populate_edge_configuration(os.environ)
GATEWAY_WORKER_COUNT=int(os.environ.get('GATEWAY_WORKER_COUNT')or 1000)
GATEWAY_SERVER=os.environ.get(_d,'').strip()or'twisted'
DOCKER_BRIDGE_IP=os.environ.get(_e,'').strip()
DOCKER_SDK_DEFAULT_TIMEOUT_SECONDS=int(os.environ.get(_f)or 60)
DOCKER_SDK_DEFAULT_RETRIES=int(os.environ.get('DOCKER_SDK_DEFAULT_RETRIES')or 0)
ENABLE_CONFIG_UPDATES=is_env_true(_g)
DISABLE_CORS_HEADERS=is_env_true(_h)
DISABLE_CORS_CHECKS=is_env_true(_i)
DISABLE_CUSTOM_CORS_S3=is_env_true(_j)
DISABLE_CUSTOM_CORS_APIGATEWAY=is_env_true(_k)
EXTRA_CORS_ALLOWED_HEADERS=os.environ.get(_l,'').strip()
EXTRA_CORS_EXPOSE_HEADERS=os.environ.get(_m,'').strip()
EXTRA_CORS_ALLOWED_ORIGINS=os.environ.get(_n,'').strip()
DISABLE_PREFLIGHT_PROCESSING=is_env_true('DISABLE_PREFLIGHT_PROCESSING')
DISABLE_EVENTS=is_env_true(_o)
DEBUG_ANALYTICS=is_env_true('DEBUG_ANALYTICS')
DEBUG_HANDLER_CHAIN=is_env_true(_p)
EAGER_SERVICE_LOADING=is_env_true(_q)
STRICT_SERVICE_LOADING=is_env_not_false(_r)
SKIP_INFRA_DOWNLOADS=os.environ.get(_s,'').strip()
SKIP_SSL_CERT_DOWNLOAD=is_env_true(_t)
CUSTOM_SSL_CERT_PATH=os.environ.get(_u,'').strip()
REMOVE_SSL_CERT=is_env_true(_v)
ALLOW_NONSTANDARD_REGIONS=is_env_true(_w)
if ALLOW_NONSTANDARD_REGIONS:os.environ['MOTO_ALLOW_NONEXISTENT_REGION']='true'
MAIN_CONTAINER_NAME=os.environ.get(_x,'').strip()or'localstack-main'
LOCALSTACK_BUILD_GIT_HASH=os.environ.get('LOCALSTACK_BUILD_GIT_HASH','').strip()or _A
LOCALSTACK_BUILD_DATE=os.environ.get('LOCALSTACK_BUILD_DATE','').strip()or _A
OUTBOUND_HTTP_PROXY=os.environ.get(_y,'')
OUTBOUND_HTTPS_PROXY=os.environ.get(_z,'')
OPENAPI_VALIDATE_RESPONSE=is_env_true(_A0)
OPENAPI_VALIDATE_REQUEST=is_env_true(_A1)
INCLUDE_STACK_TRACES_IN_HTTP_RESPONSE=is_env_true('INCLUDE_STACK_TRACES_IN_HTTP_RESPONSE')
FORCE_SHUTDOWN=is_env_not_false('FORCE_SHUTDOWN')
no_proxy=_E.join([constants.LOCALHOST_HOSTNAME,LOCALHOST,LOCALHOST_IP,'[::1]'])
if os.environ.get(_L):os.environ[_L]+=_E+no_proxy
elif os.environ.get('NO_PROXY'):os.environ['NO_PROXY']+=_E+no_proxy
else:os.environ[_L]=no_proxy
CLI_COMMANDS={}
if not DOCKER_BRIDGE_IP:
	DOCKER_BRIDGE_IP='172.17.0.1'
	if is_in_docker:
		candidates=DOCKER_BRIDGE_IP,'172.18.0.1'
		for ip in candidates:
			if ping(ip):DOCKER_BRIDGE_IP=ip;break
INTERNAL_RESOURCE_ACCOUNT=os.environ.get('INTERNAL_RESOURCE_ACCOUNT')or'949334387222'
EVENT_RULE_ENGINE=os.environ.get(_A2,'python').strip()
EXTERNAL_SERVICE_PORTS_START=int(os.environ.get('EXTERNAL_SERVICE_PORTS_START')or os.environ.get('SERVICE_INSTANCES_PORTS_START')or 4510)
EXTERNAL_SERVICE_PORTS_END=int(os.environ.get('EXTERNAL_SERVICE_PORTS_END')or os.environ.get('SERVICE_INSTANCES_PORTS_END')or EXTERNAL_SERVICE_PORTS_START+50)
CONTAINER_RUNTIME=os.environ.get(_A3,'').strip()or _K
LAMBDA_JAVA_OPTS=os.environ.get(_A4,'').strip()
KINESIS_SHARD_LIMIT=os.environ.get('KINESIS_SHARD_LIMIT','').strip()or'100'
KINESIS_PERSISTENCE=is_env_not_false(_A5)
KINESIS_ON_DEMAND_STREAM_COUNT_LIMIT=os.environ.get(_A6,'').strip()or'10'
KINESIS_LATENCY=os.environ.get('KINESIS_LATENCY','').strip()or'500'
KINESIS_MOCK_PERSIST_INTERVAL=os.environ.get(_A7,'').strip()or'5s'
KINESIS_MOCK_LOG_LEVEL=os.environ.get(_A8,'').strip()
KINESIS_ERROR_PROBABILITY=float(os.environ.get(_A9,'').strip()or .0)
KINESIS_MOCK_PROVIDER_ENGINE=os.environ.get('KINESIS_MOCK_PROVIDER_ENGINE','').strip()or'node'
KINESIS_MOCK_MAXIMUM_HEAP_SIZE=os.environ.get('KINESIS_MOCK_MAXIMUM_HEAP_SIZE','').strip()or'512m'
KINESIS_MOCK_INITIAL_HEAP_SIZE=os.environ.get('KINESIS_MOCK_INITIAL_HEAP_SIZE','').strip()or'256m'
DYNAMODB_ERROR_PROBABILITY=float(os.environ.get(_AA,'').strip()or .0)
DYNAMODB_READ_ERROR_PROBABILITY=float(os.environ.get(_AB,'').strip()or .0)
DYNAMODB_WRITE_ERROR_PROBABILITY=float(os.environ.get(_AC,'').strip()or .0)
DYNAMODB_HEAP_SIZE=os.environ.get(_AD,'').strip()or'256m'
DYNAMODB_SHARE_DB=int(os.environ.get(_AE)or 0)
DYNAMODB_LOCAL_PORT=int(os.environ.get(_AF)or 0)
DYNAMODB_REMOVE_EXPIRED_ITEMS=is_env_true(_AG)
SQS_DELAY_PURGE_RETRY=is_env_true(_AH)
SQS_DELAY_RECENTLY_DELETED=is_env_true(_AI)
SQS_ENABLE_MESSAGE_RETENTION_PERIOD=is_env_true(_AJ)
SQS_ENDPOINT_STRATEGY=os.environ.get(_AK,'')or'standard'
SQS_DISABLE_MAX_NUMBER_OF_MESSAGE_LIMIT=is_env_true('SQS_DISABLE_MAX_NUMBER_OF_MESSAGE_LIMIT')
SQS_DISABLE_CLOUDWATCH_METRICS=is_env_true(_AL)
SQS_CLOUDWATCH_METRICS_REPORT_INTERVAL=int(os.environ.get(_AM)or 60)
HOSTNAME_FROM_LAMBDA=os.environ.get(_AN,'').strip()
BUCKET_MARKER_LOCAL=os.environ.get(_AO,'').strip()or DEFAULT_BUCKET_MARKER_LOCAL
LAMBDA_DISABLE_AWS_ENDPOINT_URL=is_env_true(_AP)
LAMBDA_DOCKER_NETWORK=os.environ.get(_AQ,'').strip()
LAMBDA_DOCKER_DNS=os.environ.get(_AR,'').strip()
LAMBDA_DOCKER_FLAGS=os.environ.get(_AS,'').strip()
LAMBDA_IGNORE_ARCHITECTURE=is_env_true(_AT)
LAMBDA_PREBUILD_IMAGES=is_env_true(_AU)
LAMBDA_RUNTIME_EXECUTOR=os.environ.get(_AV,CONTAINER_RUNTIME).strip()
LAMBDA_RUNTIME_ENVIRONMENT_TIMEOUT=int(os.environ.get(_AW)or 20)
LAMBDA_RUNTIME_IMAGE_MAPPING=os.environ.get(_AX,'').strip()
LAMBDA_RUNTIME_VALIDATION=int(os.environ.get(_AY)or 0)
LAMBDA_REMOVE_CONTAINERS=os.environ.get(_AZ,'').lower().strip()not in FALSE_STRINGS
LAMBDA_KEEPALIVE_MS=int(os.environ.get(_Aa,600000))
LAMBDA_LIMITS_CONCURRENT_EXECUTIONS=int(os.environ.get(_Ab,1000))
LAMBDA_LIMITS_MINIMUM_UNRESERVED_CONCURRENCY=int(os.environ.get(_Ac,100))
LAMBDA_LIMITS_TOTAL_CODE_SIZE=int(os.environ.get(_Ad,80530636800))
LAMBDA_LIMITS_CODE_SIZE_ZIPPED=int(os.environ.get(_Ae,52428800))
LAMBDA_LIMITS_CODE_SIZE_UNZIPPED=int(os.environ.get(_Af,262144000))
LAMBDA_LIMITS_CREATE_FUNCTION_REQUEST_SIZE=int(os.environ.get(_Ag,70167211))
LAMBDA_LIMITS_MAX_FUNCTION_ENVVAR_SIZE_BYTES=int(os.environ.get(_Ah,4096))
LAMBDA_LIMITS_MAX_FUNCTION_PAYLOAD_SIZE_BYTES=int(os.environ.get(_Ai,6291556))
LAMBDA_DEV_PORT_EXPOSE=is_env_not_false(_Aj)if not is_in_docker and is_in_macos else is_env_true(_Aj)
LAMBDA_INIT_RELEASE_VERSION=os.environ.get(_Ak)
LAMBDA_INIT_DEBUG=is_env_true(_Al)
LAMBDA_INIT_BIN_PATH=os.environ.get(_Am)
LAMBDA_INIT_BOOTSTRAP_PATH=os.environ.get(_An)
LAMBDA_INIT_DELVE_PATH=os.environ.get(_Ao)
LAMBDA_INIT_DELVE_PORT=int(os.environ.get(_Ap)or 40000)
LAMBDA_INIT_POST_INVOKE_WAIT_MS=os.environ.get(_Aq)
LAMBDA_INIT_USER=os.environ.get(_Ar)
LAMBDA_EVENT_SOURCE_MAPPING_POLL_INTERVAL_SEC=float(os.environ.get('LAMBDA_EVENT_SOURCE_MAPPING_POLL_INTERVAL_SEC')or 1)
LAMBDA_EVENT_SOURCE_MAPPING_MAX_BACKOFF_ON_ERROR_SEC=float(os.environ.get('LAMBDA_EVENT_SOURCE_MAPPING_MAX_BACKOFF_ON_ERROR_SEC')or 60)
LAMBDA_EVENT_SOURCE_MAPPING_MAX_BACKOFF_ON_EMPTY_POLL_SEC=float(os.environ.get('LAMBDA_EVENT_SOURCE_MAPPING_MAX_BACKOFF_ON_EMPTY_POLL_SEC')or 10)
SFN_MOCK_CONFIG=os.environ.get('SFN_MOCK_CONFIG','').strip()
WINDOWS_DOCKER_MOUNT_PREFIX=os.environ.get(_As,'/host_mnt')
S3_SKIP_SIGNATURE_VALIDATION=is_env_not_false(_At)
S3_SKIP_KMS_KEY_VALIDATION=is_env_not_false(_Au)
LAMBDA_TRUNCATE_STDOUT=int(os.getenv(_Av)or 2000)
LAMBDA_RETRY_BASE_DELAY_SECONDS=int(os.getenv('LAMBDA_RETRY_BASE_DELAY')or 60)
LAMBDA_SYNCHRONOUS_CREATE=is_env_true(_Aw)
OPENSEARCH_CUSTOM_BACKEND=os.environ.get('OPENSEARCH_CUSTOM_BACKEND','').strip()
OPENSEARCH_ENDPOINT_STRATEGY=os.environ.get(_Ax,'').strip()or'domain'
if OPENSEARCH_ENDPOINT_STRATEGY=='off':OPENSEARCH_ENDPOINT_STRATEGY='port'
OPENSEARCH_MULTI_CLUSTER=is_env_not_false('OPENSEARCH_MULTI_CLUSTER')
LEGACY_SNS_GCM_PUBLISHING=is_env_true(_Ay)
SNS_SES_SENDER_ADDRESS=os.environ.get(_Az,'').strip()
SNS_CERT_URL_HOST=os.environ.get('SNS_CERT_URL_HOST','').strip()
APIGW_NEXT_GEN_PROVIDER=os.environ.get('PROVIDER_OVERRIDE_APIGATEWAY','')in('next_gen','')
DDB_STREAMS_PROVIDER_V2=os.environ.get(_A_,'')==_F
_override_dynamodb_v2=os.environ.get(_B0,'')
if DDB_STREAMS_PROVIDER_V2:
	if not _override_dynamodb_v2:os.environ[_B0]=_F
elif _override_dynamodb_v2==_F:os.environ[_A_]=_F;DDB_STREAMS_PROVIDER_V2=_D
SNS_PROVIDER_V2=os.environ.get('PROVIDER_OVERRIDE_SNS','')==_F
MAIN_DOCKER_NETWORK=os.environ.get(_B1,'')or LAMBDA_DOCKER_NETWORK
PARITY_AWS_ACCESS_KEY_ID=is_env_true(_B2)
CFN_VERBOSE_ERRORS=is_env_true(_B3)
CFN_STRING_REPLACEMENT_DENY_LIST=[x for x in os.environ.get(_B4,'').split(_E)if x]
CFN_PER_RESOURCE_TIMEOUT=int(os.environ.get(_B5)or 300)
CFN_IGNORE_UNSUPPORTED_RESOURCE_TYPES=is_env_not_false(_B6)
CFN_IGNORE_UNSUPPORTED_TYPE_CREATE=parse_comma_separated_list('CFN_IGNORE_UNSUPPORTED_TYPE_CREATE')
CFN_IGNORE_UNSUPPORTED_TYPE_UPDATE=parse_comma_separated_list('CFN_IGNORE_UNSUPPORTED_TYPE_UPDATE')
CFN_NO_WAIT_ITERATIONS:str|int|_A=os.environ.get('CFN_NO_WAIT_ITERATIONS')
DNS_ADDRESS=os.environ.get(_B7)or _H
DNS_PORT=int(os.environ.get('DNS_PORT','53'))
DNS_NAME_PATTERNS_TO_RESOLVE_UPSTREAM=(os.environ.get(_B8)or'').strip()
DNS_LOCAL_NAME_PATTERNS=(os.environ.get(_B9)or'').strip()
DNS_RESOLVE_IP=os.environ.get(_BA)or LOCALHOST_IP
DNS_SERVER=os.environ.get(_BB)
DNS_VERIFICATION_DOMAIN=os.environ.get(_BC)or'localstack.cloud'
def use_custom_dns():return str(DNS_ADDRESS)not in FALSE_STRINGS
S3_VIRTUAL_HOSTNAME=f"s3.{LOCALSTACK_HOST.host}"
S3_STATIC_WEBSITE_HOSTNAME=f"s3-website.{LOCALSTACK_HOST.host}"
BOTO_WAITER_DELAY=int(os.environ.get(_BD)or'1')
BOTO_WAITER_MAX_ATTEMPTS=int(os.environ.get(_BE)or'120')
DISABLE_CUSTOM_BOTO_WAITER_CONFIG=is_env_true(_BF)
DISABLE_BOTO_RETRIES=is_env_true(_BG)
DISTRIBUTED_MODE=is_env_true(_BH)
IN_MEMORY_CLIENT=is_env_true(_BI)
LOCALSTACK_RESPONSE_HEADER_ENABLED=is_env_not_false(_BJ)
STATE_SERIALIZATION_BACKEND=os.environ.get(_BK,'').strip()or'dill'
CONFIG_ENV_VARS=[_w,_BD,_BE,_AO,_B6,_B5,_B4,_B3,'CI',_A3,_u,'DEBUG',_p,_U,_V,_BG,_i,_h,_BF,_k,_j,_o,_BH,_B7,'DNS_PORT',_B9,_B8,_BA,_BB,_BC,_e,_f,_AA,_AD,'DYNAMODB_IN_MEMORY',_AF,_AE,_AB,_AG,_AC,_q,_g,_A2,_l,_n,_m,_c,_d,'GATEWAY_WORKER_THREAD_COUNT','HOSTNAME',_AN,_BI,_A9,_A7,_A8,_A6,_A5,_T,'LAMBDA_DEBUG_MODE_CONFIG',_AP,_AR,_AS,_AQ,'LAMBDA_EVENTS_INTERNAL_SQS','LAMBDA_EVENT_SOURCE_MAPPING',_AT,_Al,_Am,_An,_Ao,_Ap,_Aq,_Ar,_Ak,_Aa,_Ab,_Ac,_Ad,_Ae,_Af,_Ag,_Ah,_Ai,_AU,_AX,_AZ,'LAMBDA_RETRY_BASE_DELAY_SECONDS',_AV,_AW,_AY,_Aw,'LAMBDA_SQS_EVENT_SOURCE_MAPPING_INTERVAL',_Av,_Z,_Ay,'LOCALSTACK_API_KEY','LOCALSTACK_AUTH_TOKEN',_b,_BJ,'LOG_LICENSE_ISSUES',_S,_x,_B1,_A1,_A0,_Ax,_y,_z,_B2,_O,_a,'REQUESTS_CA_BUNDLE',_v,_At,_Au,'SERVICES',_s,_t,_P,_Q,_R,_Az,_AH,_AI,_AJ,_AK,_AL,_AM,_BK,_r,_Y,_X,_W,_As,'LEGACY_DIRECTORIES','SYNCHRONOUS_API_GATEWAY_EVENTS','SYNCHRONOUS_DYNAMODB_EVENTS','SYNCHRONOUS_SNS_EVENTS','SYNCHRONOUS_SQS_EVENTS','DEFAULT_REGION','EDGE_BIND_HOST','EDGE_FORWARD_URL','EDGE_PORT','EDGE_PORT_HTTP','ES_CUSTOM_BACKEND','ES_ENDPOINT_STRATEGY','ES_MULTI_CLUSTER','HOSTNAME_EXTERNAL','KINESIS_INITIALIZE_STREAMS','KINESIS_PROVIDER','KMS_PROVIDER','LAMBDA_XRAY_INIT','LAMBDA_CODE_EXTRACT_TIME','LAMBDA_CONTAINER_REGISTRY','LAMBDA_EXECUTOR','LAMBDA_FALLBACK_URL','LAMBDA_FORWARD_URL',_A4,'LAMBDA_REMOTE_DOCKER','LAMBDA_STAY_OPEN_MODE','LEGACY_EDGE_PROXY','LOCALSTACK_HOSTNAME','SQS_PORT_EXTERNAL','SYNCHRONOUS_KINESIS_EVENTS','USE_SINGLE_REGION','MOCK_UNIMPLEMENTED']
def is_local_test_mode()->bool:return is_env_true(ENV_INTERNAL_TEST_RUN)
def is_collect_metrics_mode()->bool:return is_env_true(ENV_INTERNAL_TEST_COLLECT_METRIC)
def store_test_metrics_in_local_filesystem()->bool:return is_env_true(ENV_INTERNAL_TEST_STORE_METRICS_IN_LOCALSTACK)
def collect_config_items()->list[tuple[str,Any]]:
	none=object();keys=[];keys.extend(CONFIG_ENV_VARS);keys.append(_N);keys.sort();values=globals();result=[]
	for k in keys:
		v=values.get(k,none)
		if v is none:continue
		result.append((k,v))
	result.sort();return result
def populate_config_env_var_names():A='LOCALSTACK_';global CONFIG_ENV_VARS;CONFIG_ENV_VARS+=[key for key in[key.upper()for key in os.environ]if(key.startswith(A)or key.startswith(_BL))and key!=_BM];CONFIG_ENV_VARS+=[A+v for v in CONFIG_ENV_VARS if not v.startswith(A)];CONFIG_ENV_VARS=list(set(CONFIG_ENV_VARS))
populate_config_env_var_names()
def get_protocol()->str:return'https'if USE_SSL else'http'
def external_service_url(host:str|_A=_A,port:int|_A=_A,protocol:str|_A=_A,subdomains:str|_A=_A)->str:protocol=protocol or get_protocol();subdomains=f"{subdomains}."if subdomains else'';host=host or LOCALSTACK_HOST.host;port=port or LOCALSTACK_HOST.port;return f"{protocol}://{subdomains}{host}:{port}"
def internal_service_url(host:str|_A=_A,port:int|_A=_A,protocol:str|_A=_A,subdomains:str|_A=_A)->str:protocol=protocol or get_protocol();subdomains=f"{subdomains}."if subdomains else'';host=host or LOCALHOST;port=port or GATEWAY_LISTEN[0].port;return f"{protocol}://{subdomains}{host}:{port}"
def service_url(service_key,host=_A,port=_A):warnings.warn('@deprecated: Use `internal_service_url()` instead. We assume that most usages are\n        internal but really need to check and update each usage accordingly.',DeprecationWarning,stacklevel=2);return internal_service_url(host=host,port=port)
def service_port(service_key:str,external:bool=_C)->int:
	warnings.warn('Deprecated: use `localstack_host().port` for external and `GATEWAY_LISTEN[0].port` for internal use.',DeprecationWarning,stacklevel=2)
	if external:return LOCALSTACK_HOST.port
	return GATEWAY_LISTEN[0].port
def get_edge_port_http():warnings.warn("@deprecated: Use `localstack_host().port` for external and `GATEWAY_LISTEN[0].port`\n        for internal use. This function is also not needed anymore because we don't separate\n        between HTTP and HTTP ports anymore since LocalStack listens to both.",DeprecationWarning,stacklevel=2);return GATEWAY_LISTEN[0].port
def get_edge_url(localstack_hostname=_A,protocol=_A):warnings.warn('@deprecated: Use `internal_service_url()` instead.\n    We assume that most usages are internal but really need to check and update each usage accordingly.\n    ',DeprecationWarning,stacklevel=2);return internal_service_url(host=localstack_hostname,protocol=protocol)
class ServiceProviderConfig(Mapping[str,str]):
	_provider_config:dict[str,str];default_value:str;override_prefix:str=_BL
	def __init__(self,default_value:str):self._provider_config={};self.default_value=default_value
	def load_from_environment(self,env:Mapping[str,str]=_A):
		if env is _A:env=os.environ
		for(key,value)in env.items():
			if key.startswith(self.override_prefix)and value:self.set_provider(key[len(self.override_prefix):].lower().replace('_','-'),value)
	def get_provider(self,service:str)->str:return self._provider_config.get(service,self.default_value)
	def set_provider_if_not_exists(self,service:str,provider:str)->_A:
		if service not in self._provider_config:self._provider_config[service]=provider
	def set_provider(self,service:str,provider:str):self._provider_config[service]=provider
	def bulk_set_provider_if_not_exists(self,services:list[str],provider:str):
		for service in services:self.set_provider_if_not_exists(service,provider)
	def __getitem__(self,item):return self.get_provider(item)
	def __setitem__(self,key,value):self.set_provider(key,value)
	def __len__(self):return len(self._provider_config)
	def __iter__(self):return self._provider_config.__iter__()
SERVICE_PROVIDER_CONFIG=ServiceProviderConfig(_M)
SERVICE_PROVIDER_CONFIG.load_from_environment()
def init_directories()->Directories:
	if is_in_docker:return Directories.for_container()
	else:
		if is_env_true(_BM):return Directories.for_cli()
		return Directories.for_host()
dirs:Directories
dirs=init_directories()