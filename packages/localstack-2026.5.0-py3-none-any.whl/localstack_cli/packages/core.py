_B='install'
_A=None
import logging,os,re
from abc import ABC
from functools import lru_cache
from sys import version_info
from typing import Any
import requests
from localstack_cli import config
from..constants import LOCALSTACK_VENV_FOLDER,MAVEN_REPO_URL
from..utils.archives import download_and_extract
from..utils.files import chmod_r,chown_r,mkdir,rm_rf
from..utils.http import download,get_proxies
from..utils.run import is_root,run
from..utils.venv import VirtualEnvironment
from.api import InstallTarget,PackageException,PackageInstaller
LOG=logging.getLogger(__name__)
class SystemNotSupportedException(PackageException):0
class ExecutableInstaller(PackageInstaller,ABC):
	def get_executable_path(A)->str|_A:
		B=A.get_installed_dir()
		if B:return A._get_install_marker_path(B)
class DownloadInstaller(ExecutableInstaller):
	def __init__(A,name:str,version:str):super().__init__(name,version)
	def _get_download_url(A)->str:raise NotImplementedError
	def _get_install_marker_path(A,install_dir:str)->str:B=A._get_download_url();C=os.path.basename(B);return os.path.join(install_dir,C)
	def _install(A,target:InstallTarget)->_A:B=A._get_install_dir(target);mkdir(B);C=A._get_download_url();D=A._get_install_marker_path(B);download(C,D)
class ArchiveDownloadAndExtractInstaller(ExecutableInstaller):
	def __init__(A,name:str,version:str,extract_single_directory:bool=False):super().__init__(name,version);A.extract_single_directory=extract_single_directory
	def _get_install_marker_path(A,install_dir:str)->str:raise NotImplementedError
	def _get_download_url(A)->str:raise NotImplementedError
	def _get_checksum_url(A)->str|_A:0
	def get_installed_dir(C)->str|_A:
		A=super().get_installed_dir();B=C._get_archive_subdir()
		if A and B:return os.path.join(A,B)
		return A
	def _get_archive_subdir(A)->str|_A:0
	def get_executable_path(B)->str|_A:
		C=B._get_archive_subdir()
		if C is _A:return super().get_executable_path()
		else:
			A=B.get_installed_dir()
			if A:A=A[:-len(C)];return B._get_install_marker_path(A)
	def _handle_single_directory_extraction(D,target_directory:str)->_A:
		A=target_directory
		if not D.extract_single_directory:return
		B=os.listdir(A)
		if len(B)!=1:return
		C=os.path.join(A,B[0])
		if not os.path.isdir(C):return
		os.rename(C,f"{A}.backup");rm_rf(A);os.rename(f"{A}.backup",A)
	def _download_archive(A,target:InstallTarget,download_url:str)->_A:
		B=download_url;C=A._get_install_dir(target);mkdir(C);B=B or A._get_download_url();E=os.path.basename(B);D=os.path.join(config.dirs.tmp,E);F=A._get_checksum_url()
		try:download_and_extract(B,retries=3,tmp_archive=D,target_dir=C,checksum_url=F);A._handle_single_directory_extraction(C)
		finally:rm_rf(D)
	def _install(A,target:InstallTarget)->_A:A._download_archive(target,A._get_download_url())
class PermissionDownloadInstaller(DownloadInstaller,ABC):
	def _install(A,target:InstallTarget)->_A:super()._install(target);chmod_r(A.get_executable_path(),511)
class GitHubReleaseInstaller(PermissionDownloadInstaller):
	def __init__(A,name:str,tag:str,github_slug:str):super().__init__(name,tag);A.github_tag_url=f"https://api.github.com/repos/{github_slug}/releases/tags/{A.version}"
	@lru_cache
	def _get_download_url(self)->str:
		A=self;D=A._get_github_asset_name();E=_A;F=os.environ.get('GITHUB_API_TOKEN')
		if F:E={'authorization':f"Bearer {F}"}
		B=requests.get(A.github_tag_url,headers=E,proxies=get_proxies())
		if not B.ok:raise PackageException(f"Could not get list of releases from {A.github_tag_url}: {B.text}")
		H=B.json();C=_A
		for G in H.get('assets',[]):
			if G['name']==D:C=G['browser_download_url'];break
		if C is _A:raise PackageException(f"Could not find required binary {D} in release {A.github_tag_url}")
		return C
	def _get_install_marker_path(A,install_dir:str)->str:return os.path.join(install_dir,A._get_github_asset_name())
	def _get_github_asset_name(A)->str:raise NotImplementedError
class NodePackageInstaller(ExecutableInstaller):
	def __init__(A,package_name:str,version:str,package_spec:str|_A=_A,main_module:str='main.js'):C=version;B=package_name;super().__init__(B,C);A.package_name=B;A.package_spec=package_spec or f"{A.package_name}@{C}";A.main_module=main_module
	def _get_install_marker_path(A,install_dir:str)->str:return os.path.join(install_dir,'node_modules',A.package_name,A.main_module)
	def _install(B,target:InstallTarget)->_A:
		A=B._get_install_dir(target);run(['npm',_B,'--prefix',A,B.package_spec])
		if is_root():LOG.debug('Setting ownership root:root on %s',A);chown_r(A,'root')
LOCALSTACK_VENV=VirtualEnvironment(LOCALSTACK_VENV_FOLDER)
class PythonPackageInstaller(PackageInstaller):
	normalized_name:str
	def __init__(A,name:str,version:str,*B:Any,**C:Any):super().__init__(name,version,*B,**C);A.normalized_name=A._normalize_package_name(name)
	def _normalize_package_name(A,name:str)->str:return re.sub('[-_.]+','-',name).lower()
	def _get_install_dir(A,target:InstallTarget)->str:return os.path.join(target.value,'python-packages')
	def _get_install_marker_path(A,install_dir:str)->str:B=f"python{version_info[0]}.{version_info[1]}";C=f"{A.normalized_name}-{A.version}.dist-info";return os.path.join(install_dir,'lib',B,'site-packages',C,'METADATA')
	def _get_venv(A,target:InstallTarget)->VirtualEnvironment:B=A._get_install_dir(target);return VirtualEnvironment(B)
	def _prepare_installation(B,target:InstallTarget)->_A:
		A=B._get_venv(target)
		if not A.exists:LOG.info('creating virtual environment at %s',A.venv_dir);A.create();LOG.info('adding localstack venv path %s',A.venv_dir);A.add_pth('localstack-venv',LOCALSTACK_VENV)
		LOG.debug('injecting venv into path %s',A.venv_dir);A.inject_to_sys_path()
	def _install(A,target:InstallTarget)->_A:B=A._get_venv(target);C=os.path.join(B.venv_dir,'bin/python');run([C,'-m','pip',_B,f"{A.name}=={A.version}"],print_error=False)
	def _setup_existing_installation(A,target:InstallTarget)->_A:A._prepare_installation(target)
class MavenDownloadInstaller(DownloadInstaller):
	group_id:str;artifact_id:str;install_dir_suffix:str|_A
	def __init__(A,package_url:str,install_dir_suffix:str|_A=_A):A.group_id,A.artifact_id,B=parse_maven_package_url(package_url);super().__init__(A.artifact_id,B);A.install_dir_suffix=install_dir_suffix
	def _get_download_url(A)->str:B=A.group_id.replace('.','/');return f"{MAVEN_REPO_URL}/{B}/{A.artifact_id}/{A.version}/{A.artifact_id}-{A.version}.jar"
	def _get_install_dir(A,target:InstallTarget)->str:
		B=target
		if A.install_dir_suffix:return os.path.join(B.value,A.install_dir_suffix)
		else:return super()._get_install_dir(B)
class MavenPackageInstaller(MavenDownloadInstaller):
	dependencies:list[MavenDownloadInstaller]
	def __init__(A,*B:str):
		super().__init__(B[0]);A.dependencies=[]
		for C in B[1:]:D=os.path.join(A.name,A.version);A.dependencies.append(MavenDownloadInstaller(C,D))
	def _install(B,target:InstallTarget)->_A:
		A=target
		for C in B.dependencies:C._install(A)
		super()._install(A)
def parse_maven_package_url(package_url:str)->tuple[str,str,str]:A=package_url.split('/');C=A[1];B=A[2].split('@');D=B[0];E=B[1];return C,D,E