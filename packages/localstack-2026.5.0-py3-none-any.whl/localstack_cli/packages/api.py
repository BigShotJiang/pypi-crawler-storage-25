from __future__ import annotations
_A=None
import abc,functools,logging,os
from collections import defaultdict
from collections.abc import Callable
from enum import Enum
from inspect import getmodule
from threading import Lock,RLock
from typing import Any,Generic,ParamSpec,TypeVar
from plux import Plugin,PluginManager,PluginSpec
from localstack_cli import config
LOG=logging.getLogger(__name__)
class PackageException(Exception):0
class NoSuchVersionException(PackageException):
	def __init__(D,package:str|_A=_A,version:str|_A=_A):
		B=version;A=package;C='Unable to find requested version'
		if A and B:C+=f"Unable to find requested version '{B}' for package '{A}'"
		super().__init__(C)
class InstallTarget(Enum):VAR_LIBS=config.dirs.var_libs;STATIC_LIBS=config.dirs.static_libs
class PackageInstaller(abc.ABC):
	def __init__(A,name:str,version:str,install_lock:Lock|_A=_A):A.name=name;A.version=version;A.install_lock=install_lock or RLock();(A._setup_for_target):dict[InstallTarget,bool]=defaultdict(lambda:False)
	def install(A,target:InstallTarget|_A=_A)->_A:
		B=target
		try:
			if not B:B=InstallTarget.VAR_LIBS
			with A.install_lock:
				if not A.is_installed():LOG.debug('Starting installation of %s %s...',A.name,A.version);A._prepare_installation(B);A._install(B);A._post_process(B);LOG.debug('Installation of %s %s finished.',A.name,A.version)
				else:
					LOG.debug('Installation of %s %s skipped (already installed).',A.name,A.version)
					if not A._setup_for_target[B]:LOG.debug('Performing runtime setup for already installed package.');A._setup_existing_installation(B)
		except PackageException as C:raise C
		except Exception as C:raise PackageException(f"Installation of {A.name} {A.version} failed.")from C
	def is_installed(A)->bool:return A.get_installed_dir()is not _A
	def get_installed_dir(B)->str|_A:
		for C in InstallTarget:
			A=B._get_install_dir(C)
			if A and os.path.exists(B._get_install_marker_path(A)):return A
	def _get_install_dir(A,target:InstallTarget)->str:return os.path.join(target.value,A.name,A.version)
	def _get_install_marker_path(A,install_dir:str)->str:raise NotImplementedError
	def _setup_existing_installation(A,target:InstallTarget)->_A:0
	def _prepare_installation(A,target:InstallTarget)->_A:0
	def _install(A,target:InstallTarget)->_A:raise NotImplementedError
	def _post_process(A,target:InstallTarget)->_A:0
T=TypeVar('T',bound=PackageInstaller)
class Package(abc.ABC,Generic[T]):
	def __init__(A,name:str,default_version:str):A.name=name;A.default_version=default_version
	def get_installed_dir(A,version:str|_A=_A)->str|_A:return A.get_installer(version).get_installed_dir()
	def install(A,version:str|_A=_A,target:InstallTarget|_A=_A)->_A:A.get_installer(version).install(target)
	@functools.lru_cache
	def get_installer(self,version:str|_A=_A)->T:
		B=version;A=self
		if not B:return A.get_installer(A.default_version)
		if B not in A.get_versions():raise NoSuchVersionException(package=A.name,version=B)
		return A._get_installer(B)
	def get_versions(A)->list[str]:raise NotImplementedError
	def _get_installer(A,version:str)->T:raise NotImplementedError
	def __str__(A)->str:return A.name
class MultiPackageInstaller(PackageInstaller):
	def __init__(B,name:str,version:str,package_installer:list[PackageInstaller]):A=package_installer;super().__init__(name=name,version=version);assert isinstance(A,list);assert len(A)>0;B.package_installer=A
	def install(A,target:InstallTarget|_A=_A)->_A:
		for B in A.package_installer:B.install(target=target)
	def get_installed_dir(A)->str|_A:return A.package_installer[0].get_installed_dir()
	def _install(A,target:InstallTarget)->_A:0
	def _get_install_dir(A,target:InstallTarget)->str:return A.package_installer[0]._get_install_dir(target)
	def _get_install_marker_path(A,install_dir:str)->str:return A.package_installer[0]._get_install_marker_path(install_dir)
PLUGIN_NAMESPACE='localstack.packages'
class PackagesPlugin(Plugin):
	api:str;name:str
	def __init__(A,name:str,scope:str,get_package:Callable[[],Package[PackageInstaller]|list[Package[PackageInstaller]]],should_load:Callable[[],bool]|_A=_A)->_A:super().__init__();A.name=name;A.scope=scope;A._get_package=get_package;A._should_load=should_load
	def should_load(A)->bool:
		if A._should_load:return A._should_load()
		return True
	def get_package(A)->Package[PackageInstaller]:return A._get_package()
class NoSuchPackageException(PackageException):0
class PackagesPluginManager(PluginManager[PackagesPlugin]):
	def __init__(A)->_A:super().__init__(PLUGIN_NAMESPACE)
	def get_all_packages(A)->list[tuple[str,str,Package[PackageInstaller]]]:return sorted([(A.name,A.scope,A.get_package())for A in A.load_all()])
	def get_packages(D,package_names:list[str],version:str|_A=_A)->list[Package[PackageInstaller]]:
		C=version;E=defaultdict(list)
		for B in D.list_plugin_specs():A,I,I=B.name.rpartition('/');E[A].append(B)
		F:list[Package[PackageInstaller]]=[]
		for A in package_names:
			G=E.get(A)
			if not G:raise NoSuchPackageException(f"unable to locate installer for package {A}")
			for B in G:
				H=D.load(B.name).get_package();F.append(H)
				if C and C not in H.get_versions():raise NoSuchPackageException(f"unable to locate installer for package {A} and version {C}")
		return F
P=ParamSpec('P')
T2=TypeVar('T2')
def package(name:str|_A=_A,scope:str='community',should_load:Callable[[],bool]|_A=_A)->Callable[[Callable[[],Package[Any]|list[Package[Any]]]],PluginSpec]:
	A=scope
	def B(fn:Callable[[],Package[Any]|list[Package[Any]]])->PluginSpec:
		B=name or getmodule(fn).__name__.split('.')[-2]
		@functools.wraps(fn)
		def C()->PackagesPlugin:return PackagesPlugin(name=B,scope=A,get_package=fn,should_load=should_load)
		return PluginSpec(PLUGIN_NAMESPACE,f"{B}/{A}",factory=C)
	return B
packages=package