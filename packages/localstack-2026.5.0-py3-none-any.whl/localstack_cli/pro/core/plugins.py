from __future__ import annotations
import logging,os,requests
from localstack_cli import config as localstack_config
from localstack_cli.config import HostAndPort
from localstack_cli.constants import API_ENDPOINT
from localstack_cli.pro.core import config as pro_config
from localstack_cli.pro.core.bootstrap import licensingv2
from localstack_cli.runtime import hooks
from localstack_cli.runtime.exceptions import LocalstackExit
from localstack_cli.utils.bootstrap import Container
LOG=logging.getLogger(__name__)
def modify_gateway_listen_config(cfg):
	if os.getenv('GATEWAY_LISTEN')is None:A='0.0.0.0'if localstack_config.in_docker()else'127.0.0.1';cfg.GATEWAY_LISTEN.append(HostAndPort(host=A,port=443))
@hooks.prepare_host(priority=200)
def patch_community_pro_detection():from localstack_cli.utils import bootstrap as A;A.is_auth_token_configured=pro_config.is_auth_token_configured
GRACE_PERIOD_ENDPOINT_PATH='/license/grace-period-check'
LICENSE_ERROR_MESSAGE='===============================================\nLocalStack requires an account to run.\n\n==> Have an account? Learn how to set LOCALSTACK_AUTH_TOKEN: https://app.localstack.cloud/settings/auth-tokens\n==> Need an account? Get started: https://www.localstack.cloud/pricing\n==> Want more time? Snooze until April 6, 2026 by setting LOCALSTACK_ACKNOWLEDGE_ACCOUNT_REQUIREMENT=1\n'
GRACE_PERIOD_EXPIRED_MESSAGE='===============================================\nLocalStack requires an account to run.\n\n==> Have an account? Learn how to set LOCALSTACK_AUTH_TOKEN: https://app.localstack.cloud/settings/auth-tokens\n==> Need an account? Get started: https://www.localstack.cloud/pricing\n'
def _check_grace_period_active(ack:bool)->bool:
	from localstack_cli.pro.core.bootstrap.licensingv2 import get_system_information_summary as C;from localstack_cli.pro.core.constants import VERSION as D;from localstack_cli.utils.analytics.metadata import get_client_metadata as E;from localstack_cli.utils.http import get_proxies as F;A=E();G={'machine':{'id':A.machine_id,'ci':A.is_ci,'system':C()},'version':D,'requesting_grace':ack};B=f"{API_ENDPOINT}{GRACE_PERIOD_ENDPOINT_PATH}";H=F()
	try:I=requests.post(B,json=G,verify=not localstack_config.is_env_true('SSL_NO_VERIFY'),proxies=H,timeout=10);return I.ok
	except requests.exceptions.RequestException:LOG.debug('Failed to reach grace period endpoint at %s',B);return False
@hooks.prepare_host(priority=100,should_load=pro_config.ACTIVATE_PRO)
def activate_pro_key_on_host():
	from localstack_cli.constants import OFFICIAL_IMAGES as D;from localstack_cli.utils.bootstrap import get_docker_image_to_start as E;C=E().split(':')[0]
	if C not in D:LOG.debug("Skipping host license activation for custom image '%s' (license expected to be baked into the image)",C);return
	try:licensingv2.get_licensed_environment().activate()
	except licensingv2.LicensingError as F:
		pro_config.ACTIVATE_PRO=False;A=localstack_config.is_env_true('LOCALSTACK_ACKNOWLEDGE_ACCOUNT_REQUIREMENT')or localstack_config.is_env_true('ACKNOWLEDGE_ACCOUNT_REQUIREMENT');B=_check_grace_period_active(A)
		if not A and B:raise LocalstackExit(reason=LICENSE_ERROR_MESSAGE,code=55)
		if A and B:LOG.info('Grace period active: starting LocalStack in community mode');return
		if A and not B:raise LocalstackExit(reason=GRACE_PERIOD_EXPIRED_MESSAGE,code=55)
		raise LocalstackExit(reason=F.get_user_friendly(),code=55)
@hooks.configure_localstack_container(priority=10,should_load=pro_config.ACTIVATE_PRO)
def configure_pro_container(container:Container):modify_gateway_listen_config(localstack_config);container.configure(licensingv2.configure_container_licensing)
@hooks.prepare_host(should_load=pro_config.ACTIVATE_PRO and pro_config.EXTENSION_DEV_MODE)
def configure_extensions_dev_host():from localstack_cli.pro.core.bootstrap.extensions.bootstrap import run_on_configure_host_hook as A;A()
@hooks.configure_localstack_container(should_load=pro_config.ACTIVATE_PRO and pro_config.EXTENSION_DEV_MODE)
def configure_extensions_dev_container(container:Container):from localstack_cli.pro.core.bootstrap.extensions.bootstrap import run_on_configure_localstack_container_hook as A;A(container)