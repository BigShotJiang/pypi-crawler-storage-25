_AU='MEDIACONVERT_DISABLE_JOB_DURATION'
_AT='NEPTUNE_GREMLIN_DEBUG'
_AS='NEPTUNE_ENABLE_TRANSACTION'
_AR='NEPTUNE_DB_TYPE'
_AQ='NEPTUNE_USE_SSL'
_AP='APPSYNC_JS_LIBS_VERSION'
_AO='PROVIDER_FORCE_EXPLICIT_LOADING'
_AN='POD_LOAD_CLI_TIMEOUT'
_AM='CODEBUILD_ENABLE_CUSTOM_IMAGES'
_AL='CODEBUILD_REMOVE_CONTAINERS'
_AK='CODEPIPELINE_GH_TOKEN'
_AJ='CI_PROJECT'
_AI='LS_CI_PROJECT'
_AH='DISABLE_LOCAL_DAEMON_CONNECTION'
_AG='ENABLE_POD_RESOURCES'
_AF='POD_ENCRYPTION'
_AE='AUTO_LOAD_POD'
_AD='LOCALSTACK_AUTH_TOKEN'
_AC='GLUE_JOB_EXECUTOR_PROVIDER'
_AB='GLUE_JOB_EXECUTOR'
_AA='AUTO_SSL_CERTS'
_A9='APIGW_ENABLE_NEXT_GEN_WEBSOCKETS_INVOCATION'
_A8='APIGW_ENABLE_NEXT_GEN_WEBSOCKETS'
_A7='DOCDB_PROXY_CONTAINER'
_A6='REDIS_CONTAINER_MODE'
_A5='RDS_CLUSTER_ENDPOINT_IP_BASED'
_A4='RDS_CLUSTER_ENDPOINT_HOST_ONLY'
_A3='RDS_MYSQL_DOCKER'
_A2='EKS_PERSIST_CLUSTER_CONTENTS'
_A1='EKS_VELERO_PLUGIN_AWS_IMAGE'
_A0='EKS_VELERO_IMAGE'
_z='EKS_POD_IDENTITY_WEBHOOK_IMAGE'
_y='EKS_K3S_FLAGS'
_x='EKS_STARTUP_TIMEOUT'
_w='EKS_MOCK_CREATE_CLUSTER_DELAY'
_v='EKS_K8S_PROVIDER'
_u='EKS_K3S_IMAGE_TAG'
_t='EKS_K3S_IMAGE_REPOSITORY'
_s='DMS_SERVERLESS_STATUS_CHANGE_WAITING_TIME'
_r='DMS_SERVERLESS_DEPROVISIONING_DELAY'
_q='ENABLE_DMS'
_p='EC2_REFERENCE_DOMAIN'
_o='EC2_LIBVIRT_POOL'
_n='EC2_LIBVIRT_NETWORK'
_m='EC2_HYPERVISOR_URI'
_l='EC2_DOCKER_INIT'
_k='EC2_REMOVE_CONTAINERS'
_j='EC2_VM_MANAGER'
_i='EC2_DOWNLOAD_DEFAULT_IMAGES'
_h='EC2_DOCKER_FLAGS'
_g='ECS_TASK_EXECUTOR'
_f='ECS_REMOVE_CONTAINERS'
_e='ECS_FLUENT_BIT_IMAGE_REPOSITORY'
_d='ECS_DOCKER_FLAGS'
_c='ECS_DISABLE_AWS_ENDPOINT_URL'
_b='CLOUDFRONT_STATIC_PORTS'
_a='CLOUDFRONT_LAMBDA_EDGE'
_Z='MWAA_DOCKER_FLAGS'
_Y='MWAA_S3_POLL_INTERVAL'
_X='MWAA_PIP_TRUSTED_HOSTS'
_W='LOCALSTACK_K8S_NAMESPACE'
_V='LOCALSTACK_K8S_ANNOTATIONS'
_U='LOCALSTACK_K8S_LABELS'
_T='KINESISANALYTICSV2_IMAGE'
_S='LDM_PREVIEW'
_R='LAMBDA_DOWNLOAD_AWS_LAYERS'
_Q='GRAPHQL_ENDPOINT_STRATEGY'
_P='domain'
_O='EXTENSION_AUTO_INSTALL'
_N='EXTENSION_DEV_MODE'
_M='KUBE_ENDPOINT'
_L='IAM_SOFT_MODE'
_K='ENFORCE_IAM'
_J='DISABLE_TRANSPARENT_ENDPOINT_INJECTION'
_I='TRANSPARENT_LOCAL_ENDPOINTS'
_H='SMTP_EMAIL'
_G='SMTP_PASS'
_F='SMTP_USER'
_E='SMTP_HOST'
_D=False
_C='default'
_B='legacy'
_A=True
import os
from typing import Literal
from localstack_cli import config as localstack_config
from localstack_cli import constants as localstack_constants
from localstack_cli.config import is_env_true
from localstack_cli.utils.urls import localstack_host
FALSE_STRINGS=localstack_constants.FALSE_STRINGS
ROOT_FOLDER=os.path.realpath(os.path.join(os.path.dirname(os.path.realpath(__file__)),'..','..','..'))
UNPROTECTED_FOLDERS=['aws','bootstrap','cli','packages','testing']
UNPROTECTED_FILES=['__init__.py','plugins.py','packages.py','localstack-pro-core/localstack/pro/core/runtime/plugin/api.py','*/appinspector/database/alembic/*']
API_URL=localstack_constants.API_ENDPOINT
LOCALHOST_IP='127.0.0.1'
RESOURCES_BASE_DOMAIN_NAME=os.environ.get('RESOURCES_BASE_DOMAIN_NAME','').strip()or localstack_host().host
DEV_PRODUCT_ENTITLEMENTS_LIST=os.environ.get('DEV_PRODUCT_ENTITLEMENTS_LIST','').strip()
DEV_PRODUCT_ENTITLEMENTS_ALLOW_ALL=localstack_config.is_env_not_false('DEV_PRODUCT_ENTITLEMENTS_ALLOW_ALL')
SMTP_HOST=os.environ.get(_E,'')
SMTP_USER=os.environ.get(_F,'')
SMTP_PASS=os.environ.get(_G,'')
SMTP_EMAIL=os.environ.get(_H,'')
TRANSPARENT_LOCAL_ENDPOINTS=localstack_config.is_env_not_false(_I)
DISABLE_TRANSPARENT_ENDPOINT_INJECTION=localstack_config.is_env_true(_J)
DNS_NAMES_RESOLVING_TO_LOCALSTACK=os.environ.get('DNS_NAMES_RESOLVING_TO_LOCALSTACK')
ENFORCE_IAM=localstack_config.is_env_true(_K)
IAM_SOFT_MODE=localstack_config.is_env_true(_L)
KUBE_ENDPOINT=os.environ.get(_M,'')
EXTENSION_DEV_MODE=localstack_config.is_env_true(_N)
EXTENSION_AUTO_INSTALL:list[str]=[A.strip()for A in(os.environ.get(_O)or'').split(',')if A.strip()]
GRAPHQL_ENDPOINT_STRATEGY:Literal[_B,_P,'path']=os.environ.get(_Q,'')or _B
LAMBDA_DOWNLOAD_AWS_LAYERS=localstack_config.is_env_not_false(_R)
LAMBDA_DISABLE_JAVA_SDK_V2_CERTIFICATE_VALIDATION=localstack_config.is_env_not_false('LAMBDA_DISABLE_JAVA_SDK_V2_CERTIFICATE_VALIDATION')
LDM_PREVIEW=localstack_config.is_env_not_false(_S)
LAMBDA_K8S_IMAGE_PREFIX=os.environ.get('LAMBDA_K8S_IMAGE_PREFIX')or'amazon/aws-lambda-'
KINESISANALYTICSV2_IMAGE=os.environ.get(_T)or'localstack/flink'
LOCALSTACK_K8S_LABELS=os.environ.get(_U)or os.environ.get('LAMBDA_K8S_LABELS')
LOCALSTACK_K8S_ANNOTATIONS=os.environ.get(_V)
K8S_CONTAINER_SECURITY_CONTEXT=os.environ.get('K8S_CONTAINER_SECURITY_CONTEXT')or os.environ.get('LAMBDA_K8S_SECURITY_CONTEXT')
K8S_CURL_INIT_IMAGE=os.environ.get('K8S_CURL_INIT_IMAGE')or'curlimages/curl:8.16.0'
LAMBDA_K8S_INIT_IMAGE=os.environ.get('LAMBDA_K8S_INIT_IMAGE')or K8S_CURL_INIT_IMAGE
LOCALSTACK_K8S_NAMESPACE=os.environ.get(_W,_C)
MWAA_PIP_TRUSTED_HOSTS=os.environ.get(_X)
MWAA_S3_POLL_INTERVAL=int(os.environ.get(_Y,30))
MWAA_DOCKER_FLAGS=os.environ.get(_Z)
CLOUDFRONT_LAMBDA_EDGE=is_env_true(_a)
CLOUDFRONT_STATIC_PORTS=localstack_config.is_env_true(_b)
ECS_DISABLE_AWS_ENDPOINT_URL=localstack_config.is_env_true(_c)
ECS_DOCKER_FLAGS=os.environ.get(_d,'').strip()
ECS_FLUENT_BIT_IMAGE_REPOSITORY=os.environ.get(_e,'amazon/aws-for-fluent-bit').strip()
ECS_REMOVE_CONTAINERS=localstack_config.is_env_not_false(_f)
ECS_TASK_EXECUTOR=os.environ.get(_g,localstack_config.CONTAINER_RUNTIME).strip()
EC2_DOCKER_FLAGS=os.environ.get(_h,'')
EC2_DOWNLOAD_DEFAULT_IMAGES=localstack_config.is_env_not_false(_i)
EC2_VM_MANAGER=os.environ.get(_j,localstack_config.CONTAINER_RUNTIME).strip()or'docker'
EC2_REMOVE_CONTAINERS=localstack_config.is_env_not_false(_k)
EC2_DOCKER_INIT=localstack_config.is_env_not_false(_l)
EC2_HYPERVISOR_URI=os.environ.get(_m,'').strip()or'qemu:///system'
EC2_LIBVIRT_NETWORK=os.environ.get(_n,_C).strip()
EC2_LIBVIRT_POOL=os.environ.get(_o,_C).strip()
EC2_REFERENCE_DOMAIN=os.environ.get(_p,'').strip()
ENABLE_DMS=localstack_config.is_env_true(_q)
DMS_SERVERLESS_DEPROVISIONING_DELAY=int(os.environ.get(_r,'60').strip())
DMS_SERVERLESS_STATUS_CHANGE_WAITING_TIME=int(os.environ.get(_s,'0').strip())
ECR_ENDPOINT_STRATEGY=os.environ.get('ECR_ENDPOINT_STRATEGY','')or _P
EKS_K3S_IMAGE_REPOSITORY=os.environ.get(_t,'rancher/k3s')
EKS_K3S_IMAGE_TAG=os.environ.get(_u,'').strip()
EKS_K8S_PROVIDER=os.environ.get(_v,'')or'k3s'
EKS_MOCK_CREATE_CLUSTER_DELAY=int(os.environ.get(_w,'0').strip())
EKS_STARTUP_TIMEOUT=int(os.environ.get(_x,'180').strip())
EKS_K3S_FLAGS=os.environ.get(_y)
EKS_POD_IDENTITY_WEBHOOK_IMAGE=os.environ.get(_z)or'localstack/amazon-eks-pod-identity-webhook:v0.6.7'
EKS_VELERO_IMAGE=os.environ.get(_A0)or'velero/velero:v1.17.0'
EKS_VELERO_PLUGIN_AWS_IMAGE=os.environ.get(_A1)or'velero/velero-plugin-for-aws:v1.13.0'
EKS_START_K3D_LB_INGRESS=localstack_config.is_env_true('EKS_START_K3D_LB_INGRESS')
EKS_PERSIST_CLUSTER_CONTENTS=localstack_config.is_env_true(_A2)
PORT_HIVE_METASTORE=int(os.getenv('PORT_HIVE_METASTORE')or 9083)
PORT_HIVE_SERVER=int(os.getenv('PORT_HIVE_SERVER')or 10000)
PORT_TRINO_SERVER=int(os.getenv('PORT_TRINO_SERVER')or 41983)
PORT_SPARK_MASTER=int(os.getenv('PORT_SPARK_MASTER')or 7077)
PORT_SPARK_UI=int(os.getenv('PORT_SPARK_UI')or 4040)
EMR_SPARK_VERSION=str(os.getenv('EMR_SPARK_VERSION')or'').strip()
RDS_PG_CUSTOM_VERSIONS=localstack_config.is_env_not_false('RDS_PG_CUSTOM_VERSIONS')
RDS_PG_MAX_CONNECTIONS=int(os.getenv('RDS_PG_MAX_CONNECTIONS')or 0)
RDS_MYSQL_DOCKER=localstack_config.is_env_not_false(_A3)
RDS_CONTAINER_USER_GROUP_ID=os.environ.get('RDS_CONTAINER_USER_GROUP_ID')or'1000:1000'
RDS_CLUSTER_ENDPOINT_HOST_ONLY=localstack_config.is_env_not_false(_A4)
RDS_CLUSTER_ENDPOINT_IP_BASED=localstack_config.is_env_true(_A5)
REDIS_CONTAINER_MODE=localstack_config.is_env_true(_A6)
DOCDB_PROXY_CONTAINER=localstack_config.is_env_true(_A7)
APIGW_ENABLE_NEXT_GEN_WEBSOCKETS=localstack_config.is_env_true(_A8)
APIGW_ENABLE_NEXT_GEN_WEBSOCKETS_INVOCATION=localstack_config.is_env_true(_A9)
K8S_WAIT_FOR_POD_READY_TIMEOUT=os.environ.get('K8S_WAIT_FOR_POD_READY_TIMEOUT','')
K8S_WAIT_FOR_DEPLOYMENT_READY_TIMEOUT=os.environ.get('K8S_WAIT_FOR_DEPLOYMENT_READY_TIMEOUT','')
K8S_WAIT_FOR_SERVICE_READY_TIMEOUT=os.environ.get('K8S_WAIT_FOR_SERVICE_READY_TIMEOUT','')
AUTH_CACHE_PATH=os.path.join(localstack_config.CONFIG_DIR,'auth.json')
AUTO_SSL_CERTS=localstack_config.is_env_true(_AA)
BEDROCK_PREWARM=localstack_config.is_env_true('BEDROCK_PREWARM')
DEFAULT_BEDROCK_MODEL=os.environ.get('DEFAULT_BEDROCK_MODEL','smollm2:360m').strip()
BEDROCK_PULL_MODELS={A.strip()for A in os.environ.get('BEDROCK_PULL_MODELS','').split(',')if A.strip()}|{DEFAULT_BEDROCK_MODEL}
GLUE_JOB_EXECUTOR=os.environ.get(_AB)or localstack_config.CONTAINER_RUNTIME
GLUE_JOB_EXECUTOR_PROVIDER=os.environ.get(_AC,'v2').strip()
def is_auth_token_set_in_cache()->bool:
	if not os.path.isfile(AUTH_CACHE_PATH):return _D
	try:
		import json
		with open(AUTH_CACHE_PATH,'rb')as A:
			if json.load(A).get(_AD):return _A
	except Exception:pass
	return _D
def is_auth_token_configured()->bool:
	if os.environ.get(_AD,'').strip():return _A
	if is_env_true('LOCALSTACK_CLI')and is_auth_token_set_in_cache():return _A
	if os.environ.get('LOCALSTACK_API_KEY','').strip():return _A
	return _D
ACTIVATE_PRO=_A
AUTO_LOAD_POD=os.environ.get(_AE,'')
MERGE_STRATEGY=(os.environ.get('MERGE_STRATEGY','')or'account-region-merge').strip()
POD_ENCRYPTION=is_env_true(_AF)
ENABLE_POD_RESOURCES=is_env_true(_AG)
CLI_INJECT_POD_IDENTITY=localstack_config.is_env_not_false('CLI_INJECT_POD_IDENTITY')
DEFAULT_PORT_LOCAL_DAEMON=4600
DEFAULT_PORT_LOCAL_DAEMON_ROOT=4601
DISABLE_LOCAL_DAEMON_CONNECTION=localstack_config.is_env_true(_AH)
CI_PROJECT=os.environ.get(_AI)or os.environ.get(_AJ)or''
CODEPIPELINE_GH_TOKEN=os.environ.get(_AK)
CODEBUILD_REMOVE_CONTAINERS=localstack_config.is_env_not_false(_AL)
CODEBUILD_ENABLE_CUSTOM_IMAGES=localstack_config.is_env_true(_AM)
COMMIT_INTERVAL_SECS=os.environ.get('COMMIT_INTERVAL_SECS',10)
SYNCHRONIZATION_RATE=os.environ.get('SYNCHRONIZATION_RATE',1)
BATCH_DOCKER_FLAGS=os.environ.get('BATCH_DOCKER_FLAGS','')
POD_LOAD_CLI_TIMEOUT=int(os.getenv(_AN,'60'))
PROVIDER_FORCE_EXPLICIT_LOADING=is_env_true(_AO)
APPSYNC_JS_LIBS_VERSION=os.getenv(_AP,'')
NEPTUNE_USE_SSL=localstack_config.is_env_true(_AQ)
NEPTUNE_DB_TYPE=(os.environ.get(_AR,'')or'tinkerpop').strip()
NEPTUNE_ENABLE_TRANSACTION=is_env_true(_AS)
NEPTUNE_GREMLIN_DEBUG=is_env_true(_AT)
MEDIACONVERT_DISABLE_JOB_DURATION=is_env_true(_AU)
KAFKA_LEGACY_PROVIDER_OVERRIDE=os.getenv('PROVIDER_OVERRIDE_KAFKA')==_B
RESOURCE_GROUPS_TAGGING_API_V2=os.environ.get('PROVIDER_OVERRIDE_RESOURCEGROUPSTAGGINGAPI','')=='v2'
APPINSPECTOR_DEV_ENABLE=is_env_true('APPINSPECTOR_DEV_ENABLE')
APPINSPECTOR_ENABLE=is_env_true('APPINSPECTOR_ENABLE')
localstack_config.CONFIG_ENV_VARS+=[_AP,'ACKNOWLEDGE_ACCOUNT_REQUIREMENT',_A8,_A9,_AE,_AA,'AUTOSTART_UTIL_CONTAINERS',_AJ,_AM,_AL,_AK,_b,_a,_AH,_A7,_c,_d,_e,_f,_g,_h,_l,_i,_m,_n,_o,_p,_k,_j,_t,_u,_v,_w,_A2,_x,_y,_z,_A0,_A1,_q,_AG,_r,_s,_AF,_K,_N,_O,_Q,_L,_M,_R,_S,_W,_U,_V,_T,'LOG_LICENSE_ISSUES',_AI,'LS_CI_LOGS',_AU,'MSSQL_ACCEPT_EULA',_X,_Y,_Z,'PERSIST_ALL',_H,_E,_G,_F,'SSL_NO_VERIFY','SYNC_POD_NAME',_I,_J,'PERSIST_FLUSH_STRATEGY',_AO,_A3,_A4,_A5,_A6,_AN,_AR,_AS,_AT,_AQ,'LAMBDA_XRAY_INIT',_AB,_AC]
localstack_config.populate_config_env_var_names()