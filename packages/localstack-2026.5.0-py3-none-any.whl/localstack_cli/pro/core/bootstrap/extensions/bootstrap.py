from __future__ import annotations
import logging,os
from pathlib import Path
from tempfile import gettempdir
from localstack_cli import config
from localstack_cli.utils.bootstrap import Container
from localstack_cli.utils.container_utils.container_client import BindMount
from localstack_cli.utils.json import FileMappedDocument
from localstack_cli.utils.strings import md5
LOG=logging.getLogger(__name__)
_ENTRYPOINT_SCRIPT='#!/bin/bash\necho "=================================================="\necho "LocalStack extension developer mode enabled"\nshopt -s nullglob\n\npkgs=$(echo /opt/code/localstack/.venv/lib/python3*/site-packages)\n\necho "import localstack_extensions_resolve;localstack_extensions_resolve.resolve()" > ${pkgs}/localstack-extensions-resolve.pth\n\ncat << EOF >> ${pkgs}/localstack_extensions_resolve.py\nimport os\nimport sys\nimport glob\n\nbase_dirs_visited = set()\n\ndef append_pth_recursively(base_dir):\n    if base_dir in base_dirs_visited:\n        return\n    base_dirs_visited.add(base_dir)\n\n    for f in glob.glob(f"{base_dir}/*.pth", recursive=True):\n        with open(f, "r") as fd:\n            abs_path = os.path.abspath(os.path.dirname(f))\n            lines = fd.readlines()\n            for line in lines:\n                if line := line.strip():\n                    if "import" in line:\n                        continue\n                    module_dir = os.path.abspath(os.path.join(abs_path, line)) if not os.path.isabs(line) else line\n                    if os.path.exists(module_dir) and os.path.isdir(module_dir):\n                        if module_dir not in sys.path:\n                            sys.path.append(module_dir)\n                        append_pth_recursively(module_dir)\n\n\ndef resolve():\n    append_pth_recursively(os.path.dirname(__file__))\nEOF\n\nfor d in /opt/code/extensions/* ;\ndo\n    echo "- mounting extension ${d}"\n    find ${d} -type d -name "site-packages" >> ${pkgs}/localstack-extensions-venv.pth\n    echo ${d} >> ${pkgs}/localstack-extensions-venv.pth\ndone\necho "Resuming normal execution, ..."\necho "=================================================="\nexec /usr/local/bin/docker-entrypoint.sh\n'
_host_extension_dirs:list[str]=[]
def run_on_configure_host_hook():
	B=FileMappedDocument(os.path.join(config.CONFIG_DIR,'extensions-dev.json'))
	for C in B.get('extensions',[]):
		A=C.get('host_path')
		if A and os.path.exists(A):_host_extension_dirs.append(A)
def run_on_configure_localstack_container_hook(container:Container):
	B=container;D=md5(_ENTRYPOINT_SCRIPT);A=Path(gettempdir(),f"docker-entrypoint-{D}.sh")
	if not A.exists():A.write_text(_ENTRYPOINT_SCRIPT,newline='\n',encoding='utf-8');A.chmod(511)
	B.config.volumes.add(BindMount(str(A),f"/tmp/{A.name}"));B.config.entrypoint=f"/tmp/{A.name}"
	for C in _host_extension_dirs:E=os.path.join('/opt/code/extensions',os.path.basename(C));B.config.volumes.add(BindMount(C,E,read_only=True))