_M='--delay'
_L='SIMPLE'
_K='replicator'
_J='profile_name'
_I='endpoint_url'
_H='aws_session_token'
_G='SINGLE_RESOURCE'
_F='region'
_E='region_name'
_D=True
_C='aws_secret_access_key'
_B='aws_access_key_id'
_A=None
import json,os,re,subprocess as sp,sys,time
from collections.abc import Mapping
from configparser import ConfigParser
from pathlib import Path
from typing import TypedDict
import click,requests
from localstack_cli import config
from localstack_cli.cli import console
from localstack_cli.cli.exceptions import CLIError
from.cli import RequiresPlatformLicenseGroup,_assert_host_reachable
AWS_CONFIG_ENV_VARS={_B:'{}_ACCESS_KEY_ID',_C:'{}_SECRET_ACCESS_KEY',_H:'{}_SESSION_TOKEN',_E:'{}_DEFAULT_REGION',_I:'{}_ENDPOINT_URL',_J:'{}_PROFILE'}
PREVIEW_BANNER="\n*** Preview Feature ***\n\nThis feature is currently in preview mode in our Teams offering and it's availability may change in future releases.\n"
REPLICATOR_HELP=PREVIEW_BANNER+'\n\nThe replicator command group allows you to replicate AWS resources into LocalStack.\n'
def run_check_output(cmd)->str:return sp.check_output(cmd,stderr=sp.PIPE,env=os.environ).decode('utf-8').strip()
class ProfileLoadError(RuntimeError):
	def __init__(A,profile_name:str):super().__init__(f"Could not find profile '{profile_name}'")
class ReplicatorCliGroup(RequiresPlatformLicenseGroup):
	name=_K;tier='Ultimate'
	def invoke(A,ctx:click.Context):print(PREVIEW_BANNER,file=sys.stderr);super().invoke(ctx)
class AWSConfig(TypedDict,total=False):aws_access_key_id:str;aws_secret_access_key:str;aws_session_token:str|_A;region_name:str;endpoint_url:str|_A;profile_name:str
def get_aws_env_config(prefix:str)->AWSConfig:A={A:os.getenv(B.format(prefix))for(A,B)in AWS_CONFIG_ENV_VARS.items()};return AWSConfig(**{B:A for(B,A)in A.items()if A})
def get_config_from_profile(profile_name:str,profile_dir:Path|_A=_A)->AWSConfig:
	B=profile_name;A=profile_dir;A=A or Path.home()/'.aws'
	def C(path:Path,profile_prefix:str='')->Mapping:
		A=ConfigParser();A.read(path)
		try:return A[f"{profile_prefix}{B}"]
		except KeyError:raise ProfileLoadError(B)
	E=C(A/'config',profile_prefix='profile ');D=C(A/'credentials');return AWSConfig(aws_access_key_id=D[_B],aws_secret_access_key=D[_C],region_name=E[_F],profile_name=B)
def get_awscli_config()->AWSConfig|_A:
	H='get';D='configure';C='aws'
	try:A=[C,D,'export-credentials'];E=json.loads(run_check_output(A))
	except sp.CalledProcessError as I:
		if b'AWS CLI version 2'in I.stderr:print('Warning: awscli v1 installed. Please use v2 for auto detection of credentials',file=sys.stderr)
		return
	try:A=[C,D,H,_I];F=run_check_output(A)
	except sp.CalledProcessError:F=os.getenv('AWS_ENDPOINT_URL')
	try:A=[C,D,H,_F];B=run_check_output(A)
	except sp.CalledProcessError:B=os.getenv('AWS_DEFAULT_REGION')
	if not B:
		try:
			A=[C,D,'list']
			for G in run_check_output(A).splitlines():
				if _F not in G:continue
				J=re.split('[:\\s]+',G)
				try:B=J[1];break
				except IndexError:return
		except(sp.CalledProcessError,FileNotFoundError):return
	return AWSConfig(aws_access_key_id=E['AccessKeyId'],aws_secret_access_key=E['SecretAccessKey'],aws_session_token=E.get('SessionToken'),region_name=B,endpoint_url=F)
def get_source_config(profile_dir:Path|_A=_A)->AWSConfig:
	D=get_awscli_config()
	if D:print('Configured credentials from the AWS CLI',file=sys.stderr);return D
	A=get_aws_env_config('AWS');E=A.get(_J)
	if A.get(_B)and not A.get(_C):raise CLIError("Unable to retrieve credentials: Partial credentials found in env. Need both 'AWS_ACCESS_KEY_ID' and 'AWS_SECRET_ACCESS_KEY'")
	if E:
		C=get_config_from_profile(profile_name=E,profile_dir=profile_dir)
		if A.get(_C):C.pop(_H,_A)
		C.update(A);A=C
	B=[]
	if not A.get(_E):B.append("'AWS_DEFAULT_REGION' must bet set in environment or in profile.")
	if not A.get(_B):B.append("'AWS_ACCESS_KEY_ID' must bet set in environment or in profile.")
	if not A.get(_C):B.append("'AWS_SECRET_ACCESS_KEY' must bet set in environment or in profile.")
	if B:raise CLIError('\n'.join(B))
	return A
def get_target_config(access_key:str='',region_name:str='')->AWSConfig:
	C=region_name;B=access_key;A=get_aws_env_config('TARGET')
	if B:A[_B]=B
	if C:A[_E]=C
	return A
def get_replicator_url():_assert_host_reachable();return f"{config.external_service_url()}/_localstack/replicator"
@click.group(name=_K,short_help='(Preview) Start a replication job or check its status',help=REPLICATOR_HELP,cls=ReplicatorCliGroup)
def replicator()->_A:0
def validate_start_command(replication_type:str,resource_arn:str|_A=_A,resource_type:str|_A=_A,resource_identifier:str|_A=_A)->_A:
	C='You must specify either --resource-arn or --resource_type';B=resource_type;A=resource_arn
	if replication_type==_G:
		if not(A or B):raise CLIError(C)
		if A and B:raise CLIError(C)
		if B and not resource_identifier:raise CLIError('You must specify --resource-id when using --resource-type')
		if A and not A.startswith('arn:aws:'):raise CLIError('--resource-arn must start with arn:aws:')
@replicator.command(name='start',short_help='Replicate an AWS resource',help='\nStarts a job to replicate an AWS resource into localstack.\nYou must have credentials with sufficient read access to the resource trying to replicate.\nAt the moment only environment variables are recognized.\n`AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY` and `AWS_DEFAULT_REGION` must be set. `AWS_ENDPOINT_URL` and `AWS_SESSION_TOKEN` are optional.\n')
@click.option('--replication-type',type=click.Choice([_G,'BATCH']),default=_G,show_default=_D,help='Type of replication job: SINGLE_RESOURCE, BATCH')
@click.option('--explore-strategy',type=click.Choice([_L,'TREE']),default=_L,show_default=_D,help='How we explore the resource tree. SIMPLE only replicates the resource requested.')
@click.option('--resource-arn',help='ARN of the resource to recreate. Optional for SINGLE_RESOURCE replication')
@click.option('--resource-type',help='CloudControl type of the resource to recreate. Optional for SINGLE_RESOURCE replication')
@click.option('--resource-identifier',help='CloudControl identifier of the resource to recreate. Mandatory if --resource-type is used')
@click.option('--target-account-id',help='Localstack account ID where the resources will be replicated. Defaults to 000000000000. See <docs> to enable same account replication')
@click.option('--target-region-name',help='Localstack region where the resources will be replicated. Only provide if different than source AWS account.')
@click.option(_M,help='Delay for the MOCK replication work')
def start(replication_type:str,explore_strategy:str,resource_arn:str|_A=_A,resource_type:str|_A=_A,resource_identifier:str|_A=_A,delay:str|_A=_A,target_account_id:str|_A=_A,target_region_name:str|_A=_A)->_A:
	G=delay;F=resource_identifier;E=resource_type;D=resource_arn;C=replication_type;validate_start_command(C,D,E,F);H=get_source_config();I=get_target_config(access_key=target_account_id,region_name=target_region_name);A={}
	if D:A['resource_arn']=D
	if E:A['resource_type']=E
	if F:A['resource_identifier']=F
	if C=='MOCK':A['delay']=float(G)if G else 1
	J=f"{get_replicator_url()}/jobs";K={'replication_type':C,'explore_strategy':explore_strategy,'replication_job_config':A,'source_aws_config':H,'target_aws_config':I};B=requests.post(J,json=K)
	if B.status_code==200:console.print_json(json=B.text)
	else:raise CLIError(f"Failed to create replication job: {B.status_code}, {B.text}")
@replicator.command(name='status',short_help='Check replication status',help='\nCheck the status of a replication job using its Job ID.\nUse the --follow flag to continuously check the status until the job is completed.\n')
@click.argument('job_id')
@click.option('--follow',is_flag=_D,help='Follow the status until completed')
@click.option(_M,help='Delay between calls',default=5,type=int)
def status(job_id,follow:bool,delay:int)->_A:
	D=f"{get_replicator_url()}/jobs/{job_id}"
	while _D:
		A=requests.get(D)
		if A.status_code==200:
			B=A.json();console.print_json(data=B);C=B.get('state')
			if C=='ERROR':raise CLIError(B.get('error_message'))
			elif C=='SUCCEEDED':return
		else:raise CLIError(f"Failed to replicate resource: {A.status_code}, {A.text}")
		if not follow:return
		time.sleep(float(delay))
@replicator.command(name='resources',short_help='List supported resources')
def resources():
	B=f"{get_replicator_url()}/resources";A=requests.get(B)
	if A.status_code!=200:raise CLIError(f"Failed to get list of resources: {A.status_code}, {A.text}")
	console.print_json(json=A.text)