_A=None
import typing as t
from gettext import gettext
import click,requests
from click import echo
from click._compat import get_text_stderr
from localstack_cli import config
from localstack_cli.cli.exceptions import CLIError
from localstack_cli.pro.core.bootstrap.licensingv2 import LicensingError,get_product_entitlements
class LicensingCLIError(CLIError):
	def format_message(A)->str:return click.style('👋 This feature is part of our paid offering!',fg='yellow')+A.message
	def show(B,file:t.IO[t.Any]|_A=_A)->_A:
		A=file
		if A is _A:A=get_text_stderr()
		echo(gettext(B.format_message()),file=A)
class RequiresLicenseGroup(click.Group):
	is_pro_command=True
	def invoke(C,ctx:click.Context)->t.Any:
		from localstack_cli.pro.core.bootstrap.licensingv2 import get_licensed_environment as A
		try:A().activate_license()
		except LicensingError as B:raise LicensingCLIError(B.get_user_friendly_cli())
		return super().invoke(ctx)
class RequiresPlatformLicenseGroup(click.Group):
	namespace='localstack.platform.plugin';tier='paid';name:str;is_pro_command=True
	def invoke(A,ctx:click.Context)->t.Any:
		try:
			if not A.is_feature_allowed():raise LicensingCLIError(f"""
=============================================
You tried to use a LocalStack feature that requires a {A.tier} subscription,
but the license did not contain the required subscription! 🔑❌

Due to this error, LocalStack has quit.

Please verify that your license includes the required tier for this feature. You can find your credentials in our
webapp at https://app.localstack.cloud.
""")
		except LicensingError as B:raise LicensingCLIError(B.get_user_friendly_cli())
		return super().invoke(ctx)
	def is_feature_allowed(A)->bool:from localstack_cli.pro.core.bootstrap.licensingv2 import get_licensed_environment as C;B=C();B.activate_license();D=f"{A.namespace}/{A.name}";return D in get_product_entitlements(B)
def _assert_host_reachable()->_A:
	try:requests.get(config.external_service_url())
	except requests.ConnectionError:raise CLIError('Destination host unreachable. Please make sure LocalStack is running.')