import functools
from plux import PluginManager,plugin
HOOKS_CONFIGURE_LOCALSTACK_CONTAINER='localstack_cli.hooks.configure_localstack_container'
HOOKS_PREPARE_HOST='localstack_cli.hooks.prepare_host'
def hook(namespace:str,priority:int=0,**A):
	def B(fn):fn.hook_priority=priority;return plugin(namespace=namespace,**A)(fn)
	return B
def hook_spec(namespace:str):B=namespace;A=functools.partial(hook,namespace=B);A.manager=HookManager(B);A.run=A.manager.run_in_order;return A
class HookManager(PluginManager):
	def load_all_sorted(B,propagate_exceptions=False):A=B.load_all(propagate_exceptions);A.sort(key=lambda _fn_plugin:getattr(_fn_plugin.fn,'hook_priority',0),reverse=True);return A
	def run_in_order(A,*B,**C):
		for D in A.load_all_sorted():D(*B,**C)
	def __str__(A):return f"HookManager({A.namespace})"
	def __repr__(A):return A.__str__()
configure_localstack_container=hook_spec(HOOKS_CONFIGURE_LOCALSTACK_CONTAINER)
prepare_host=hook_spec(HOOKS_PREPARE_HOST)