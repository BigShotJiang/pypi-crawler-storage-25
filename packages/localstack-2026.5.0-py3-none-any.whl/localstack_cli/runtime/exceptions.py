class LocalstackExit(Exception):
	def __init__(A,reason:str=None,code:int=1):B=reason;A.reason=B;A.code=code;super().__init__(B)