_B=False
_A=None
import itertools,logging
from multiprocessing.pool import ThreadPool
import click
from rich.console import Console
from localstack_cli import config
from localstack_cli.cli.exceptions import CLIError
from localstack_cli.packages import InstallTarget,Package
from localstack_cli.packages.api import NoSuchPackageException,PackagesPluginManager
from localstack_cli.utils.bootstrap import setup_logging
LOG=logging.getLogger(__name__)
console=Console()
@click.group()
def cli():setup_logging()
def _do_install_package(package:Package,version:str=_A,target:InstallTarget=_A):
	A=package;console.print(f"installing... [bold]{A}[/bold]")
	try:A.install(version=version,target=target);console.print(f"[green]installed[/green] [bold]{A}[/bold]")
	except Exception as B:console.print(f"[red]error[/red] installing {A}: {B}");raise B
@cli.command()
@click.argument('package',nargs=-1,required=True)
@click.option('--parallel',type=int,default=1,required=_B,help='how many installers to run in parallel processes')
@click.option('--version',type=str,default=_A,required=_B,help='version to install of a package')
@click.option('--target',type=click.Choice([A.name.lower()for A in InstallTarget]),default=_A,required=_B,help='target of the installation')
def install(package:list[str],parallel:int|_A=1,version:str|_A=_A,target:str|_A=_A):
	G='one or more package installations failed.';E=version;D=package;C=parallel;A=target
	try:
		if A:A=InstallTarget[str.upper(A)]
		else:A=InstallTarget.STATIC_LIBS
		console.print(f"resolving packages: {D}");F=PackagesPluginManager();F.load_all();H=F.get_packages(D,E)
		if C>1:console.print(f"install {C} packages in parallel:")
		config.dirs.mkdirs()
		with ThreadPool(processes=C)as I:I.starmap(_do_install_package,zip(H,itertools.repeat(E),itertools.repeat(A)))
	except NoSuchPackageException as B:LOG.debug(str(B),exc_info=B);raise CLIError(str(B))
	except Exception as B:LOG.debug(G,exc_info=B);raise CLIError(G)
@cli.command(name='list')
@click.option('-v','--verbose',is_flag=True,default=_B,required=_B,help='Verbose output (show additional info on packages)')
def list_packages(verbose:bool):
	B=PackagesPluginManager();B.load_all();D=B.get_all_packages()
	for(E,F,C)in D:
		console.print(f"[green]{E}[/green]/{F}")
		if verbose:
			for A in C.get_versions():
				if A==C.default_version:console.print(f"  - [bold]{A} (default)[/bold]",highlight=_B)
				else:console.print(f"  - {A}",highlight=_B)
if __name__=='__main__':cli()