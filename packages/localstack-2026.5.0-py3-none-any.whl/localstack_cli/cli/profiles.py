import argparse,os,sys
def set_and_remove_profile_from_sys_argv():
	B=argparse.ArgumentParser(add_help=False);B.add_argument('--profile');C,sys.argv=B.parse_known_args(sys.argv);A=C.profile
	if not A:A=parse_p_argument(sys.argv)
	if A:os.environ['CONFIG_PROFILE']=A.strip()
def parse_p_argument(args)->str|None:
	for(B,A)in enumerate(args):
		if A.startswith('-p='):return A[3:]
		if A=='-p':
			try:return args[B+1]
			except IndexError:return