_A='localstack_cli.plugins.cli'
import abc,logging,os,click
from plux import Plugin,PluginManager
LOG=logging.getLogger(__name__)
class LocalstackCli:
	group:click.Group
	def __call__(A,*B,**C):A.group(*B,**C)
class LocalstackCliPlugin(Plugin):
	namespace=_A
	def load(A,cli)->None:A.attach(cli)
	@abc.abstractmethod
	def attach(self,cli:LocalstackCli)->None:0
def load_cli_plugins(cli):
	if os.environ.get('DEBUG_PLUGINS','0').lower()in('true','1'):logging.basicConfig(level=logging.DEBUG)
	A=PluginManager(_A,load_args=(cli,));A.load_all()