_D='Entrypoints'
_C='--namespace'
_B='Name'
_A=True
import os,time,click
from plux import PluginManager
from plux.build.setuptools import find_plugins
from plux.core.entrypoint import spec_to_entry_point
from rich import print as rprint
from rich.console import Console
from rich.table import Table
from rich.tree import Tree
from localstack_cli.cli.exceptions import CLIError
console=Console()
@click.group()
def cli():0
@cli.command()
@click.option('--where',type=str,default=os.path.abspath(os.curdir))
@click.option('--exclude',multiple=_A,default=())
@click.option('--include',multiple=_A,default=('*',))
@click.option('--output',type=str,default='tree')
def find(where,exclude,include,output):
	C=where;B=output
	with console.status(f"Scanning path {C}"):D=find_plugins(C,exclude,include)
	if B=='tree':
		E=Tree(_D)
		for(F,G)in D.items():
			H=E.add(f"[bold]{F}");A=Table();A.add_column(_B);A.add_column('Location')
			for I in G:J,K=I.split('=');A.add_row(J,K)
			H.add(A)
		rprint(E)
	elif B=='dict':rprint(dict(D))
	else:raise CLIError(f"unknown output format {B}")
@cli.command('list')
@click.option(_C,type=str,required=_A)
def cmd_list(namespace):
	C=PluginManager(namespace);A=Table();A.add_column(_B);A.add_column('Factory')
	for B in C.list_plugin_specs():D=spec_to_entry_point(B);A.add_row(B.name,D.value)
	rprint(A)
@cli.command()
@click.option(_C,type=str,required=_A)
@click.option('--name',type=str,required=_A)
def load(namespace,name):
	B=name;A=namespace;C=PluginManager(A)
	with console.status(f"Loading {A}:{B}"):D=time.time();E=C.load(B);F=time.time()-D
	rprint(f":tada: successfully loaded [bold][green]{A}[/green][/bold]:[bold][cyan]{B}[/cyan][/bold] ({type(E)}");rprint(f":stopwatch:  loading took {F:.4f} s")
@cli.command()
@click.option(_C,type=str)
def cache(namespace):
	B=namespace;from stevedore._cache import _c;E=_c._get_data_for_path(None);C=Tree(_D)
	for(D,F)in E.get('groups').items():
		if B and D!=B:continue
		G=C.add(f"[bold]{D}");A=Table();A.add_column(_B);A.add_column('Value')
		for(H,I,J)in F:A.add_row(H,I)
		G.add(A)
		if B:rprint(A);return
	rprint(C)
if __name__=='__main__':cli()