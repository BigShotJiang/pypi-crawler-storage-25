import os
def main():os.environ['LOCALSTACK_CLI']='1';from.profiles import set_and_remove_profile_from_sys_argv as A;A();from.localstack import create_with_plugins as B;C=B();C()
if __name__=='__main__':main()