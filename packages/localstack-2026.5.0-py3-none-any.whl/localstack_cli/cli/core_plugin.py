from localstack_cli.cli.plugin import LocalstackCli,LocalstackCliPlugin
class CoreCliPlugin(LocalstackCliPlugin):
	name='core'
	def attach(A,cli:LocalstackCli)->None:0