_T='docker-images'
_S='localstack-cli'
_R='restart'
_Q='services'
_P='running'
_O='container_ip'
_N='container_name'
_M='Deprecated'
_L='Advanced'
_K='Commands'
_J='bold red'
_I='localstack'
_H='docker'
_G='json'
_F='dict'
_E='plain'
_D='table'
_C=True
_B=False
_A=None
import json,logging,os,sys,traceback
from typing import TypedDict
import click,requests
from localstack_cli import config
from localstack_cli.cli.exceptions import CLIError
from localstack_cli.constants import VERSION
from localstack_cli.utils.analytics.cli import publish_invocation
from localstack_cli.utils.bootstrap import get_container_default_logfile_location
from localstack_cli.utils.json import CustomEncoder
from.console import BANNER,console
from.plugin import LocalstackCli,load_cli_plugins
class LocalStackCliGroup(click.Group):
	advanced_commands=['aws','dns','extensions','license','login','logout','pod','state','ephemeral','replicator']
	def invoke(F,ctx:click.Context):
		C='debug';A=ctx
		try:return super().invoke(A)
		except click.exceptions.Exit:raise
		except click.ClickException:
			if A and A.params.get(C):click.echo(traceback.format_exc())
			raise
		except Exception as B:
			if A and A.params.get(C):click.echo(traceback.format_exc())
			from localstack_cli.utils.container_utils.container_client import ContainerException as D,DockerNotAvailable as E
			if isinstance(B,E):raise CLIError('Docker could not be found on the system.\nPlease make sure that you have a working docker environment on your machine.')
			elif isinstance(B,D):raise CLIError(B.message)
			else:raise CLIError(str(B))from B
	def format_commands(D,ctx:click.Context,formatter:click.HelpFormatter)->_A:
		E=formatter;F={_K:[],_L:[],_M:[]};B=[]
		for C in D.list_commands(ctx):
			A=D.get_command(ctx,C)
			if A is _A:continue
			if A.hidden:continue
			B.append((C,A))
		if len(B):
			H=E.width-6-max(len(A[0])for A in B)
			for(C,A)in B:help=A.get_short_help_str(H);F[D._get_category(A)].append((C,help))
		for(I,G)in F.items():
			if G:
				with E.section(I):E.write_dl(G)
	def _get_category(A,cmd)->str:
		if cmd.deprecated:return _M
		if cmd.name in A.advanced_commands:return _L
		return _K
def create_with_plugins()->LocalstackCli:A=LocalstackCli();A.group=localstack;load_cli_plugins(A);return A
def _setup_cli_debug()->_A:from localstack_cli.logging.setup import setup_logging_for_cli as A;config.DEBUG=_C;os.environ['DEBUG']='1';A(logging.DEBUG if config.DEBUG else logging.INFO)
_click_format_option=click.option('-f','--format','format_',type=click.Choice([_D,_E,_F,_G]),default=_D,help='The formatting style for the command output.')
@click.group(name=_I,help='The LocalStack Command Line Interface (CLI)',cls=LocalStackCliGroup,context_settings={'help_option_names':['-h','--help'],'show_default':_C})
@click.version_option(VERSION,'--version','-v',message='LocalStack CLI %(version)s',help='Show the version of the LocalStack CLI and exit')
@click.option('-d','--debug',is_flag=_C,help='Enable CLI debugging mode')
@click.option('-p','--profile',type=str,help='Set the configuration profile')
def localstack(debug,profile)->_A:
	if debug:_setup_cli_debug()
	from localstack_cli.utils.files import cache_dir as A
	if not os.environ.get('LOCALSTACK_VOLUME_DIR','').strip():config.VOLUME_DIR=str(A()/'volume')
	config.dirs.for_cli().mkdirs()
@localstack.group(name='config',short_help='Manage your LocalStack config')
def localstack_config()->_A:0
@localstack_config.command(name='show',short_help='Show your config')
@_click_format_option
@publish_invocation
def cmd_config_show(format_:str)->_A:
	A=format_;assert config
	try:from localstack_cli.pro.core import config as B;assert B
	except ImportError:return
	if A==_D:_print_config_table()
	elif A==_E:_print_config_pairs()
	elif A==_F:_print_config_dict()
	elif A==_G:_print_config_json()
	else:_print_config_pairs()
@localstack_config.command(name='validate',short_help='Validate your config')
@click.option('-f','--file',help='Path to compose file',default='docker-compose.yml',type=click.Path(exists=_C,file_okay=_C,readable=_C))
@publish_invocation
def cmd_config_validate(file:str)->_A:
	from localstack_cli.utils import bootstrap as A
	if A.validate_localstack_config(file):console.print('[green]:heavy_check_mark:[/green] config valid');sys.exit(0)
	else:console.print('[red]:heavy_multiplication_x:[/red] validation error');sys.exit(1)
def _print_config_json()->_A:import json;console.print(json.dumps(dict(config.collect_config_items()),cls=CustomEncoder))
def _print_config_pairs()->_A:
	for(A,B)in config.collect_config_items():console.print(f"{A}={B}")
def _print_config_dict()->_A:console.print(dict(config.collect_config_items()))
def _print_config_table()->_A:
	from rich.table import Table;A=Table(show_header=_C);A.add_column('Key');A.add_column('Value')
	for(B,C)in config.collect_config_items():A.add_row(B,str(C))
	console.print(A)
@localstack.group(name='status',short_help='Query status info',invoke_without_command=_C)
@click.pass_context
def localstack_status(ctx:click.Context)->_A:
	A=ctx
	if A.invoked_subcommand is _A:A.invoke(localstack_status.get_command(A,_H))
@localstack_status.command(name=_H,short_help='Query LocalStack Docker status')
@_click_format_option
def cmd_status_docker(format_:str)->_A:
	with console.status('Querying Docker status'):_print_docker_status(format_)
class DockerStatus(TypedDict,total=_B):running:bool;runtime_version:str;image_tag:str;image_id:str;image_created:str;container_name:str|_A;container_ip:str|_A
def _print_docker_status(format_:str)->_A:
	B=format_;from localstack_cli.utils import docker_utils as E;from localstack_cli.utils.bootstrap import get_docker_image_details as F,get_server_version as G;from localstack_cli.utils.container_networking import get_main_container_ip as H,get_main_container_name as I;C=F();J=config.MAIN_CONTAINER_NAME;D=E.DOCKER_CLIENT.is_container_running(J);A=DockerStatus(runtime_version=G(),image_tag=C['tag'],image_id=C['id'],image_created=C['created'],running=D)
	if D:A[_N]=I();A[_O]=H()
	if B==_F:console.print(A)
	if B==_D:_print_docker_status_table(A)
	if B==_G:console.print(json.dumps(A))
	if B==_E:
		for(K,L)in A.items():console.print(f"{K}={L}")
def _print_docker_status_table(status:DockerStatus)->_A:
	A=status;from rich.table import Table;B=Table(show_header=_B);B.add_column();B.add_column();B.add_row('Runtime version',f"[bold]{A["runtime_version"]}[/bold]");B.add_row('Docker image',f"tag: {A["image_tag"]}, id: {A["image_id"]}, :calendar: {A["image_created"]}");C='[bold][red]:heavy_multiplication_x: stopped'
	if A[_P]:C=f'[bold][green]:heavy_check_mark: running[/green][/bold] (name: "[italic]{A[_N]}[/italic]", IP: {A[_O]})'
	B.add_row('Runtime status',C);console.print(B)
@localstack_status.command(name=_Q,short_help='Query LocalStack services status')
@_click_format_option
def cmd_status_services(format_:str)->_A:
	A=format_;C=config.external_service_url()
	try:
		D=requests.get(f"{C}/_localstack/health",timeout=2);E=D.json();B=E.get(_Q,[])
		if A==_D:_print_service_table(B)
		if A==_E:
			for(F,G)in B.items():console.print(f"{F}={G}")
		if A==_F:console.print(B)
		if A==_G:console.print(json.dumps(B))
	except requests.ConnectionError:
		if config.DEBUG:console.print_exception()
		raise CLIError(f"could not connect to LocalStack health endpoint at {C}")
def _print_service_table(services:dict[str,str])->_A:
	A=services;from rich.table import Table;D={_P:'[green]:heavy_check_mark:[/green] running','starting':':hourglass_flowing_sand: starting','available':'[grey]:heavy_check_mark:[/grey] available','error':'[red]:heavy_multiplication_x:[/red] error'};B=Table();B.add_column('Service');B.add_column('Status');A=list(A.items());A.sort(key=lambda item:item[0])
	for(E,C)in A:
		if C in D:C=D[C]
		B.add_row(E,C)
	console.print(B)
@localstack.command(name='start',short_help='Start LocalStack')
@click.option('--docker',is_flag=_C,help='Start LocalStack in a docker container [default]')
@click.option('--host',is_flag=_C,help='Start LocalStack directly on the host',deprecated=_C)
@click.option('--no-banner',is_flag=_C,help='Disable LocalStack banner',default=_B)
@click.option('-d','--detached',is_flag=_C,help='Start LocalStack in the background',default=_B)
@click.option('--network',type=str,help='The container network the LocalStack container should be started in. By default, the default docker bridge network is used.',required=_B)
@click.option('--env','-e',help='Additional environment variables that are passed to the LocalStack container',multiple=_C,required=_B)
@click.option('--publish','-p',help='Additional port mappings that are passed to the LocalStack container',multiple=_C,required=_B)
@click.option('--volume','-v',help='Additional volume mounts that are passed to the LocalStack container',multiple=_C,required=_B)
@click.option('--host-dns',help='Expose the LocalStack DNS server to the host using port bindings.',required=_B,is_flag=_C,default=_B)
@click.option('--stack','-s',type=str,help='Use a specific stack with optional version. Examples: [localstack:4.5, snowflake]',required=_B)
@publish_invocation
def cmd_start(docker:bool,host:bool,no_banner:bool,detached:bool,network:str=_A,env:tuple=(),publish:tuple=(),volume:tuple=(),host_dns:bool=_B,stack:str=_A)->_A:
	F=detached;E=no_banner;D=host;B=network;A=stack
	if docker and D:raise CLIError('Please specify either --docker or --host')
	if D and F:raise CLIError('Cannot start detached in host mode')
	if A:
		G=A.split(':')[0];H=_I,'localstack-pro','snowflake'
		if G.lower()not in H:raise CLIError(f"Invalid stack '{G}'. Allowed stacks: {H}.")
		if':'not in A:A=f"{A}:latest"
		os.environ['IMAGE_NAME']=f"localstack/{A}"
	if not E:print_banner();print_version();print_profile();print_app();console.line()
	from localstack_cli.utils import bootstrap as C
	if not E:
		if D:console.log('starting LocalStack in host mode :laptop_computer:')
		else:console.log('starting LocalStack in Docker mode :whale:')
	if D:
		console.log('Warning: Starting LocalStack in host mode from the CLI is deprecated and will be removed soon. Please use the default Docker mode instead.',style=_J);C.prepare_host(console);os.environ['LOCALSTACK_CLI']='0';config.dirs=config.init_directories()
		try:C.start_infra_locally()
		except ImportError:
			if config.DEBUG:console.print_exception()
			raise CLIError('It appears you have a light install of localstack which only supports running in docker.\nIf you would like to use --host, please install localstack with Python using `pip install localstack[runtime]` instead.')
	else:
		config.OVERRIDE_IN_DOCKER=_B;config.is_in_docker=_B;config.dirs=config.init_directories();C.prepare_host(console);I=click.get_current_context().params
		if B:
			if config.MAIN_DOCKER_NETWORK:
				if config.MAIN_DOCKER_NETWORK!=B:raise CLIError(f"Values of MAIN_DOCKER_NETWORK={config.MAIN_DOCKER_NETWORK} and --network={B} do not match")
			else:config.MAIN_DOCKER_NETWORK=B;os.environ['MAIN_DOCKER_NETWORK']=B
		if F:C.start_infra_in_docker_detached(console,I)
		else:C.start_infra_in_docker(console,I)
@localstack.command(name='stop',short_help='Stop LocalStack')
@publish_invocation
def cmd_stop()->_A:
	from localstack_cli.utils.docker_utils import DOCKER_CLIENT as B;from..utils.container_utils.container_client import NoSuchContainer as C;A=config.MAIN_CONTAINER_NAME
	try:B.stop_container(A);console.print(f"container stopped: {A}")
	except C:raise CLIError(f'Expected a running LocalStack container named "{A}", but found none')
@localstack.command(name=_R,short_help='Restart LocalStack')
@publish_invocation
def cmd_restart()->_A:
	A=config.external_service_url()
	try:B=requests.post(f"{A}/_localstack/health",json={'action':_R});B.raise_for_status();console.print('LocalStack restarted within the container.')
	except requests.ConnectionError:
		if config.DEBUG:console.print_exception()
		raise CLIError('could not restart the LocalStack container')
@localstack.command(name='logs',short_help='Show LocalStack logs')
@click.option('-f','--follow',is_flag=_C,help='Block the terminal and follow the log output',default=_B)
@click.option('-n','--tail',type=int,help='Print only the last <N> lines of the log output',default=_A,metavar='N')
@publish_invocation
def cmd_logs(follow:bool,tail:int)->_A:
	A=tail;from localstack_cli.utils.docker_utils import DOCKER_CLIENT as C;B=config.MAIN_CONTAINER_NAME;F=get_container_default_logfile_location(B)
	if not C.is_container_running(B):
		console.print('localstack container not running')
		if os.path.exists(F):
			console.print('printing logs from previous run')
			with open(F)as H:
				for D in H:click.echo(D,nl=_B)
		sys.exit(1)
	if follow:
		G=0
		for D in C.stream_container_logs(B):
			print(D.decode('utf-8').rstrip('\r\n'));G+=1
			if A is not _A and G>=A:break
	else:
		E=C.get_container_logs(B)
		if A is not _A:E='\n'.join(E.split('\n')[-A:])
		print(E)
@localstack.command(name='wait',short_help='Wait for LocalStack')
@click.option('-t','--timeout',type=float,help='Only wait for <N> seconds before raising a timeout error',default=_A,metavar='N')
@publish_invocation
def cmd_wait(timeout:float|_A=_A)->_A:
	from localstack_cli.utils.bootstrap import wait_container_is_ready as A
	if not A(timeout=timeout):raise CLIError('timeout')
@localstack.command(name='ssh',short_help='Obtain a shell in LocalStack')
@publish_invocation
def cmd_ssh()->_A:
	from localstack_cli.utils.docker_utils import DOCKER_CLIENT as A
	if not A.is_container_running(config.MAIN_CONTAINER_NAME):raise CLIError(f'Expected a running LocalStack container named "{config.MAIN_CONTAINER_NAME}", but found none')
	os.execlp(_H,_H,'exec','-it',config.MAIN_CONTAINER_NAME,'bash')
@localstack.group(name='update',short_help='Update LocalStack')
def localstack_update()->_A:0
@localstack_update.command(name='all',short_help='Update all LocalStack components')
@click.pass_context
@publish_invocation
def cmd_update_all(ctx:click.Context)->_A:A=ctx;A.invoke(localstack_update.get_command(A,_S));A.invoke(localstack_update.get_command(A,_T))
@localstack_update.command(name=_S,short_help='Update LocalStack CLI')
@publish_invocation
def cmd_update_localstack_cli()->_A:
	if is_frozen_bundle():raise CLIError('The LocalStack CLI can only update itself if installed via PIP. Please follow the instructions on https://docs.localstack.cloud/ to update your CLI.')
	import subprocess as A;from subprocess import CalledProcessError as B;console.rule('Updating LocalStack CLI')
	with console.status('Updating LocalStack CLI...'):
		try:A.check_output([sys.executable,'-m','pip','install','--upgrade',_I]);console.print(':heavy_check_mark: LocalStack CLI updated')
		except B:console.print(':heavy_multiplication_x: LocalStack CLI update failed',style=_J)
@localstack_update.command(name=_T,short_help='Update docker images LocalStack depends on')
@publish_invocation
def cmd_update_docker_images()->_A:from localstack_cli.utils.docker_utils import DOCKER_CLIENT as A;console.rule('Updating docker images');B=A.get_docker_image_names(strip_latest=_B);C=['localstack/','public.ecr.aws/lambda'];D=[A for A in B if any(A.startswith(B)or A.startswith(f"docker.io/{B}")for B in C)and not A.endswith(':<none>')];update_images(D)
def update_images(image_list:list[str])->_A:
	D=image_list;from rich.markup import escape as E;from rich.progress import MofNCompleteColumn as J,Progress as F;from localstack_cli.utils.container_utils.container_client import ContainerException as K;from localstack_cli.utils.docker_utils import DOCKER_CLIENT as B;G=0;H=0;I=F(*F.get_default_columns(),J(),transient=_C,console=console)
	with I:
		for A in I.track(D,description='Processing image...'):
			try:
				C=_B;L=B.inspect_image(image_name=A,pull=_B)['Id'];B.pull_image(A)
				if L!=B.inspect_image(image_name=A,pull=_B)['Id']:C=_C;G+=1
				console.print(f":heavy_check_mark: Image {E(A)} {"updated"if C else"up-to-date"}.",style='bold'if C else _A,highlight=_B)
			except K as M:console.print(f":heavy_multiplication_x: Image {E(A)} pull failed: {M.message}",style=_J,highlight=_B);H+=1
	console.rule();console.print(f"Images updated: {G}, Images failed: {H}, total images processed: {len(D)}.")
@localstack.command(name='completion',short_help='CLI shell completion')
@click.pass_context
@click.argument('shell',required=_C,type=click.Choice(['bash','zsh','fish'],case_sensitive=_B))
@publish_invocation
def localstack_completion(ctx:click.Context,shell:str)->_A:
	import click.shell_completion;A=click.shell_completion.get_completion_class(shell)
	if A is _A:raise CLIError('Completion for given shell could not be found.')
	C=sys.argv[0];B=os.path.basename(C);D=f"_{B}_COMPLETE".replace('-','_').upper();E=A(ctx.command,{},B,D);click.echo(E.source())
def print_version()->_A:console.print(f"- [bold]LocalStack CLI:[/bold] [blue]{VERSION}[/blue]")
def print_profile()->_A:
	if config.LOADED_PROFILES:console.print(f"- [bold]Profile:[/bold] [blue]{", ".join(config.LOADED_PROFILES)}[/blue]")
def print_app()->_A:console.print('- [bold]App:[/bold] https://app.localstack.cloud')
def print_banner()->_A:print(BANNER)
def is_frozen_bundle()->bool:return getattr(sys,'frozen',_B)and hasattr(sys,'_MEIPASS')