from typing import Any
def format_number(number:float,decimals:int=2):
	A=f"{number:.{decimals}f}"
	if'.'in A:A=A.rstrip('0').rstrip('.')
	return A
def is_number(s:Any)->bool:
	A=False
	if s is A or s is True:return A
	try:float(s);return True
	except(TypeError,ValueError):return A
def to_number(s:Any)->int|float:
	try:return int(str(s))
	except ValueError:return float(str(s))
def format_bytes(count:float,default:str='n/a'):
	C=default;B=count
	if not is_number(B):return C
	A=float(B)
	if A<0:return C
	D='B','KB','MB','GB','TB'
	for E in D:
		if A<1000 or E==D[-1]:return f"{format_number(A,decimals=3)}{E}"
		A=A/1e3
	return B