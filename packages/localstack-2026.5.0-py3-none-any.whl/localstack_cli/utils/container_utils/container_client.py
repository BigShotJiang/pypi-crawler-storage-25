_J='--env-file'
_I='Config'
_H='no container dir specified'
_G='mode'
_F='bind'
_E='ro'
_D='tcp'
_C=True
_B=False
_A=None
import dataclasses,io,ipaddress,logging,os,re,shlex,tarfile,tempfile
from abc import ABCMeta,abstractmethod
from collections.abc import Callable
from enum import Enum,unique
from pathlib import Path
from typing import Literal,NamedTuple,Protocol,TypeAlias,TypedDict
import dotenv
from localstack_cli import config
from localstack_cli.constants import DEFAULT_VOLUME_DIR
from localstack_cli.utils.collections import HashableList,ensure_list
from localstack_cli.utils.files import TMP_FILES,chmod_r,rm_rf,save_file
from localstack_cli.utils.no_exit_argument_parser import NoExitArgumentParser
from localstack_cli.utils.strings import short_uid
LOG=logging.getLogger(__name__)
WELL_KNOWN_IMAGE_REPO_PREFIXES='localhost/','docker.io/library/'
def get_registry_from_image_name(image_name:str)->str:
	C='docker.io';A=image_name.split('/',maxsplit=1)
	if(D:=config.DOCKER_GLOBAL_IMAGE_PREFIX):return D
	if len(A)==1:return C
	B=A[0];E='.',':','localhost'
	if any(A in B for A in E):return B
	return C
@unique
class DockerContainerStatus(Enum):DOWN=-1;NON_EXISTENT=0;UP=1;PAUSED=2
class DockerContainerStats(TypedDict):Container:str;ID:str;Name:str;BlockIO:tuple[int,int];CPUPerc:float;MemPerc:float;MemUsage:tuple[int,int];NetIO:tuple[int,int];PIDs:int;SDKStats:dict|_A
class ContainerException(Exception):
	def __init__(A,message=_A,stdout=_A,stderr=_A)->_A:A.message=message or'Error during the communication with the docker daemon';A.stdout=stdout;A.stderr=stderr
class NoSuchObject(ContainerException):
	def __init__(C,object_id:str,message=_A,stdout=_A,stderr=_A)->_A:B=object_id;A=message;A=A or f"Docker object {B} not found";super().__init__(A,stdout,stderr);C.object_id=B
class NoSuchContainer(ContainerException):
	def __init__(C,container_name_or_id:str,message=_A,stdout=_A,stderr=_A)->_A:B=container_name_or_id;A=message;A=A or f"Docker container {B} not found";super().__init__(A,stdout,stderr);C.container_name_or_id=B
class NoSuchImage(ContainerException):
	def __init__(C,image_name:str,message=_A,stdout=_A,stderr=_A)->_A:B=image_name;A=message;A=A or f"Docker image {B} not found";super().__init__(A,stdout,stderr);C.image_name=B
class NoSuchNetwork(ContainerException):
	def __init__(C,network_name:str,message=_A,stdout=_A,stderr=_A)->_A:B=network_name;A=message;A=A or f"Docker network {B} not found";super().__init__(A,stdout,stderr);C.network_name=B
class RegistryConnectionError(ContainerException):
	def __init__(C,details:str,message=_A,stdout=_A,stderr=_A)->_A:B=details;A=message;A=A or f"Connection error: {B}";super().__init__(A,stdout,stderr);C.details=B
class DockerNotAvailable(ContainerException):
	def __init__(B,message=_A,stdout=_A,stderr=_A)->_A:A=message;A=A or'Docker not available';super().__init__(A,stdout,stderr)
class AccessDenied(ContainerException):
	def __init__(C,object_name:str,message=_A,stdout=_A,stderr=_A)->_A:B=object_name;A=message;A=A or f"Access denied to {B}";super().__init__(A,stdout,stderr);C.object_name=B
class CancellableStream(Protocol):
	def __iter__(A):raise NotImplementedError
	def __next__(A):raise NotImplementedError
	def close(A):raise NotImplementedError
class DockerPlatform(str):linux_amd64='linux/amd64';linux_arm64='linux/arm64'
@dataclasses.dataclass
class Ulimit:
	name:str;soft_limit:int;hard_limit:int|_A=_A
	def __repr__(A):
		B=f"{A.name}={A.soft_limit}"
		if A.hard_limit:B+=f":{A.hard_limit}"
		return B
PortRange=list|HashableList
PortProtocol=str
class PortMappings:
	bind_host:str;mappings:dict[tuple[PortRange,PortProtocol],list]
	def __init__(A,bind_host:str=_A):B=bind_host;A.bind_host=B if B else'';A.mappings={}
	def add(B,port:int|PortRange,mapped:int|PortRange=_A,protocol:PortProtocol=_D):
		D=protocol;C=mapped;A=port;C=C or A
		if isinstance(A,PortRange):
			for H in range(A[1]-A[0]+1):
				if isinstance(C,PortRange):B.add(A[0]+H,C[0]+H,D)
				else:B.add(A[0]+H,C,D)
			return
		if A is _A or int(A)<0:raise Exception(f"Unable to add mapping for invalid port: {A}")
		if B.contains(A,D):return
		G=_A
		for((E,K),F)in B.mappings.items():
			if not K==D:continue
			if not B.in_expanded_range(A,E):continue
			if not B.in_expanded_range(C,F):continue
			J=E[1]-E[0];L=F[1]-F[0];M=J==L
			if M:B.expand_range(A,E,protocol=D,remap=_C);B.expand_range(C,F,protocol=D)
			elif not B.in_range(C,F):continue
			elif J==1:B.expand_range(A,E,protocol=D,remap=_C)
			else:N=C-F[0];G=E[0]+N;B.bisect_range(C,F,protocol=D);B.bisect_range(G,E,protocol=D,remap=_C);break
			return
		if G is _A:I=[A,A]
		elif G<A:I=[G,A]
		else:I=[A,G]
		D=str(D or _D).lower();B.mappings[HashableList(I),D]=[C,C]
	def to_str(A)->str:
		C=f"{A.bind_host}:"if A.bind_host else''
		def B(k,v):
			A,E=k;B=v;D=f"/{E}"if E!=_D else''
			if A[0]==A[1]and B[0]==B[1]:return f"-p {C}{A[0]}:{B[0]}{D}"
			if A[0]!=A[1]and B[0]==B[1]:return f"-p {C}{A[0]}-{A[1]}:{B[0]}{D}"
			return f"-p {C}{A[0]}-{A[1]}:{B[0]}-{B[1]}{D}"
		return' '.join([B(A,C)for(A,C)in A.mappings.items()])
	def to_list(A)->list[str]:
		C=f"{A.bind_host}:"if A.bind_host else''
		def B(k,v):
			A,D=k;B=v;E=f"/{D}"if D!=_D else''
			if A[0]==A[1]and B[0]==B[1]:return['-p',f"{C}{A[0]}:{B[0]}{E}"]
			return['-p',f"{C}{A[0]}-{A[1]}:{B[0]}-{B[1]}{E}"]
		return[D for(A,C)in A.mappings.items()for D in B(A,C)]
	def to_dict(A)->dict[str,tuple[str,int|list[int]]|int]:
		C=A.bind_host or''
		def F(bind_address,host_port):
			B=bind_address;A=host_port
			if A==0:return
			elif B:return B,A
			else:return A
		def B(k,v):
			A,G=k;B=v;D=f"/{G}"
			if A[0]!=A[1]and B[0]==B[1]:H=B[0];E=list(range(A[0],A[1]+1));return[(f"{H}{D}",(C,E)if C else E)]
			return[(f"{A}{D}",F(C,B))for(A,B)in zip(range(B[0],B[1]+1),range(A[0],A[1]+1),strict=_B)]
		D=[D for(A,C)in A.mappings.items()for D in B(A,C)];return dict(D)
	def contains(A,port:int,protocol:PortProtocol=_D)->bool:
		for(B,E)in A.mappings.items():
			C=B[1]
			if C==protocol:
				D=B[0]
				if A.in_range(port,D):return _C
	def in_range(A,port:int,range:PortRange)->bool:return port>=range[0]and port<=range[1]
	def in_expanded_range(A,port:int,range:PortRange):return port>=range[0]-1 and port<=range[1]+1
	def expand_range(C,port:int,range:PortRange,protocol:PortProtocol=_D,remap:bool=_B):
		D=remap;A=port
		if C.in_range(A,range):return
		B=list(range)if D else range
		if A==range[0]-1:B[0]=A
		elif A==range[1]+1:B[1]=A
		else:raise Exception(f"Unable to add port {A} to existing range {range}")
		if D:C._remap_range(range,B,protocol=protocol)
	def bisect_range(C,port:int,range:PortRange,protocol:PortProtocol=_D,remap:bool=_B):
		D=remap;A=port
		if not C.in_range(A,range):return
		B=list(range)if D else range
		if A==range[0]:B[0]=A+1
		else:B[1]=A-1
		if D:C._remap_range(range,B,protocol)
	def _remap_range(A,old_key:PortRange,new_key:PortRange,protocol:PortProtocol):B=protocol;A.mappings[HashableList(new_key),B]=A.mappings.pop((HashableList(old_key),B))
	def __repr__(A):return f"<PortMappings: {A.to_dict()}>"
SimpleVolumeBind=tuple[str,str]
@dataclasses.dataclass
class Mount:
	def to_str(A)->str:return str(A)
@dataclasses.dataclass
class BindMount(Mount):
	host_dir:str;container_dir:str;read_only:bool=_B
	def to_str(A)->str:
		B=[]
		if A.host_dir:B.append(A.host_dir)
		if not A.container_dir:raise ValueError(_H)
		B.append(A.container_dir)
		if A.read_only:B.append(_E)
		return':'.join(B)
	def to_docker_sdk_parameters(A)->tuple[str,dict[str,str]]:return str(A.host_dir),{_F:A.container_dir,_G:_E if A.read_only else'rw'}
	@classmethod
	def parse(D,param:str)->'BindMount':
		B=param;A=B.split(':')
		if 1>len(A)>3:raise ValueError(f"Cannot parse volume bind {B}")
		C=D(A[0],A[1])
		if len(A)==3:
			if _E in A[2].split(','):C.read_only=_C
		return C
@dataclasses.dataclass
class VolumeDirMount(Mount):
	volume_path:str;container_path:str;read_only:bool=_B
	def to_str(A)->str:A._validate();from localstack_cli.utils.docker_utils import get_host_path_for_path_in_docker as B;C=B(A.volume_path);return f"{C}:{A.container_path}{":ro"if A.read_only else""}"
	def _validate(A):
		if not A.volume_path:raise ValueError('no volume dir specified')
		if config.is_in_docker and not A.volume_path.startswith(DEFAULT_VOLUME_DIR):raise ValueError(f"volume dir not starting with {DEFAULT_VOLUME_DIR}")
		if not A.container_path:raise ValueError(_H)
	def to_docker_sdk_parameters(A)->tuple[str,dict[str,str]]:A._validate();from localstack_cli.utils.docker_utils import get_host_path_for_path_in_docker as B;C=B(A.volume_path);return C,{_F:A.container_path,_G:_E if A.read_only else'rw'}
VolumeMappingSpecification:TypeAlias=SimpleVolumeBind|Mount
class VolumeMappings:
	mappings:list[VolumeMappingSpecification]
	def __init__(B,mappings:list[VolumeMappingSpecification]=_A):A=mappings;B.mappings=A if A is not _A else[]
	def add(A,mapping:VolumeMappingSpecification):A.append(mapping)
	def append(A,mapping:VolumeMappingSpecification):A.mappings.append(mapping)
	def find_target_mapping(B,container_dir:str)->VolumeMappingSpecification|_A:
		for A in B.mappings:
			C=A[1]if isinstance(A,tuple)else A.container_dir
			if container_dir==C:return A
	def __iter__(A):return A.mappings.__iter__()
	def __repr__(A):return A.mappings.__repr__()
	def __len__(A):return len(A.mappings)
	def __getitem__(A,item:int):return A.mappings[item]
VolumeType=Literal[_F,'volume']
class VolumeInfo(NamedTuple):type:VolumeType;source:str;destination:str;mode:str;rw:bool;propagation:str;name:str|_A=_A;driver:str|_A=_A
@dataclasses.dataclass
class LogConfig:type:Literal['json-file','syslog','journald','gelf','fluentd','none','awslogs','splunk'];config:dict[str,str]=dataclasses.field(default_factory=dict)
@dataclasses.dataclass
class ContainerConfiguration:image_name:str;name:str|_A=_A;volumes:VolumeMappings=dataclasses.field(default_factory=VolumeMappings);ports:PortMappings=dataclasses.field(default_factory=PortMappings);exposed_ports:list[str]=dataclasses.field(default_factory=list);entrypoint:list[str]|str|_A=_A;additional_flags:str|_A=_A;command:list[str]|_A=_A;env_vars:dict[str,str]=dataclasses.field(default_factory=dict);privileged:bool=_B;remove:bool=_B;interactive:bool=_B;tty:bool=_B;detach:bool=_B;stdin:str|_A=_A;user:str|_A=_A;cap_add:list[str]|_A=_A;cap_drop:list[str]|_A=_A;security_opt:list[str]|_A=_A;network:str|_A=_A;dns:str|_A=_A;workdir:str|_A=_A;platform:str|_A=_A;ulimits:list[Ulimit]|_A=_A;labels:dict[str,str]|_A=_A;init:bool|_A=_A;log_config:LogConfig|_A=_A;cpu_shares:int|_A=_A;mem_limit:int|str|_A=_A;auth_config:dict[str,str]|_A=_A
class ContainerConfigurator(Protocol):
	def __call__(A,configuration:ContainerConfiguration):...
@dataclasses.dataclass
class DockerRunFlags:env_vars:dict[str,str]|_A;extra_hosts:dict[str,str]|_A;labels:dict[str,str]|_A;volumes:list[SimpleVolumeBind]|_A;network:str|_A;platform:DockerPlatform|_A;privileged:bool|_A;ports:PortMappings|_A;ulimits:list[Ulimit]|_A;user:str|_A;dns:list[str]|_A
class RegistryResolverStrategy(Protocol):
	def resolve(A,image_name:str)->str:...
class HardCodedResolver:
	def resolve(A,image_name:str)->str:return image_name
class ContainerClient(metaclass=ABCMeta):
	registry_resolver_strategy:RegistryResolverStrategy=HardCodedResolver()
	@abstractmethod
	def get_system_info(self)->dict:0
	def get_system_id(A)->str:return A.get_system_info()['ID']
	@abstractmethod
	def get_container_status(self,container_name:str)->DockerContainerStatus:0
	def get_container_stats(A,container_name:str)->DockerContainerStats:0
	def get_networks(B,container_name:str)->list[str]:A=container_name;LOG.debug('Getting networks for container: %s',A);C=B.inspect_container(container_name_or_id=A);return list(C['NetworkSettings'].get('Networks',{}).keys())
	def get_container_ipv4_for_network(B,container_name_or_id:str,container_network:str)->str:
		C=container_network;A=container_name_or_id;LOG.debug('Getting ipv4 address for container %s in network %s.',A,C);E=B.get_container_id(container_name=A);F=B.inspect_network(C);G=F.get('Containers')or{}
		if E not in G:
			LOG.debug('Network attributes: %s',F)
			try:H=B.inspect_container(container_name_or_id=A);LOG.debug('Container %s Attributes: %s',A,H);I=B.get_container_logs(container_name_or_id=A);LOG.debug('Container %s Logs: %s',A,I)
			except ContainerException as D:LOG.debug('Cannot inspect container %s: %s',A,D)
			raise ContainerException('Container %s is not connected to target network %s',A,C)
		try:J=str(ipaddress.IPv4Interface(G[E]['IPv4Address']).ip)
		except Exception as D:raise ContainerException(f"Unable to detect IP address for container {A} in network {C}: {D}")
		return J
	@abstractmethod
	def stop_container(self,container_name:str,timeout:int=10):0
	@abstractmethod
	def restart_container(self,container_name:str,timeout:int=10):0
	@abstractmethod
	def pause_container(self,container_name:str):0
	@abstractmethod
	def unpause_container(self,container_name:str):0
	@abstractmethod
	def remove_container(self,container_name:str,force=_C,check_existence=_B,volumes=_B)->_A:0
	@abstractmethod
	def remove_image(self,image:str,force:bool=_C)->_A:0
	@abstractmethod
	def list_containers(self,filter:list[str]|str|_A=_A,all=_C)->list[dict]:0
	def get_running_container_names(A)->list[str]:return A.__get_container_names(return_all=_B)
	def get_all_container_names(A)->list[str]:return A.__get_container_names(return_all=_C)
	def is_container_running(A,container_name:str)->bool:return container_name in A.get_running_container_names()
	def create_file_in_container(C,container_name,file_contents:bytes,container_path:str,chmod_mode:int|_A=_A)->_A:
		B=chmod_mode
		with tempfile.NamedTemporaryFile()as A:
			A.write(file_contents);A.flush()
			if B is not _A:chmod_r(A.name,B)
			C.copy_into_container(container_name=container_name,local_path=A.name,container_path=container_path)
	@abstractmethod
	def copy_into_container(self,container_name:str,local_path:str,container_path:str)->_A:0
	@abstractmethod
	def copy_from_container(self,container_name:str,local_path:str,container_path:str)->_A:0
	@abstractmethod
	def pull_image(self,docker_image:str,platform:DockerPlatform|_A=_A,log_handler:Callable[[str],_A]|_A=_A,auth_config:dict[str,str]|_A=_A)->_A:0
	@abstractmethod
	def push_image(self,docker_image:str,auth_config:dict[str,str]|_A=_A)->_A:0
	@abstractmethod
	def build_image(self,dockerfile_path:str,image_name:str,context_path:str=_A,platform:DockerPlatform|_A=_A)->str:0
	@abstractmethod
	def tag_image(self,source_ref:str,target_name:str)->_A:0
	@abstractmethod
	def get_docker_image_names(self,strip_latest:bool=_C,include_tags:bool=_C,strip_wellknown_repo_prefixes:bool=_C)->list[str]:0
	@abstractmethod
	def get_container_logs(self,container_name_or_id:str,safe:bool=_B)->str:0
	@abstractmethod
	def stream_container_logs(self,container_name_or_id:str)->CancellableStream:0
	@abstractmethod
	def inspect_container(self,container_name_or_id:str)->dict[str,dict|str]:0
	def inspect_container_volumes(B,container_name_or_id)->list[VolumeInfo]:
		A=[]
		for C in B.inspect_container(container_name_or_id)['Mounts']:A.append(VolumeInfo(**{A.lower():B for(A,B)in C.items()}))
		return A
	@abstractmethod
	def inspect_image(self,image_name:str,pull:bool=_C,strip_wellknown_repo_prefixes:bool=_C)->dict[str,dict|list|str]:0
	@abstractmethod
	def create_network(self,network_name:str)->str:0
	@abstractmethod
	def delete_network(self,network_name:str)->_A:0
	@abstractmethod
	def inspect_network(self,network_name:str)->dict[str,dict|str]:0
	@abstractmethod
	def connect_container_to_network(self,network_name:str,container_name_or_id:str,aliases:list|_A=_A,link_local_ips:list[str]=_A)->_A:0
	@abstractmethod
	def disconnect_container_from_network(self,network_name:str,container_name_or_id:str)->_A:0
	def get_container_name(A,container_id:str)->str:return A.inspect_container(container_id)['Name'].lstrip('/')
	def get_container_id(A,container_name:str)->str:return A.inspect_container(container_name)['Id']
	@abstractmethod
	def get_container_ip(self,container_name_or_id:str)->str:0
	def get_image_cmd(A,docker_image:str,pull:bool=_C)->list[str]:B=A.inspect_image(docker_image,pull)[_I]['Cmd']or[];return B
	def get_image_entrypoint(B,docker_image:str,pull:bool=_C)->str:A=docker_image;LOG.debug('Getting the entrypoint for image: %s',A);C=B.inspect_image(A,pull)[_I].get('Entrypoint')or[];return shlex.join(C)
	@abstractmethod
	def has_docker(self)->bool:0
	@abstractmethod
	def commit(self,container_name_or_id:str,image_name:str,image_tag:str):0
	def create_container_from_config(B,container_config:ContainerConfiguration)->str:A=container_config;return B.create_container(image_name=A.image_name,name=A.name,entrypoint=A.entrypoint,remove=A.remove,interactive=A.interactive,tty=A.tty,command=A.command,volumes=A.volumes,ports=A.ports,exposed_ports=A.exposed_ports,env_vars=A.env_vars,user=A.user,cap_add=A.cap_add,cap_drop=A.cap_drop,security_opt=A.security_opt,network=A.network,dns=A.dns,additional_flags=A.additional_flags,workdir=A.workdir,privileged=A.privileged,platform=A.platform,labels=A.labels,ulimits=A.ulimits,init=A.init,log_config=A.log_config,cpu_shares=A.cpu_shares,mem_limit=A.mem_limit,auth_config=A.auth_config)
	@abstractmethod
	def create_container(self,image_name:str,*,name:str|_A=_A,entrypoint:list[str]|str|_A=_A,remove:bool=_B,interactive:bool=_B,tty:bool=_B,detach:bool=_B,command:list[str]|str|_A=_A,volumes:VolumeMappings|list[SimpleVolumeBind]|_A=_A,ports:PortMappings|_A=_A,exposed_ports:list[str]|_A=_A,env_vars:dict[str,str]|_A=_A,user:str|_A=_A,cap_add:list[str]|_A=_A,cap_drop:list[str]|_A=_A,security_opt:list[str]|_A=_A,network:str|_A=_A,dns:str|list[str]|_A=_A,additional_flags:str|_A=_A,workdir:str|_A=_A,privileged:bool|_A=_A,labels:dict[str,str]|_A=_A,platform:DockerPlatform|_A=_A,ulimits:list[Ulimit]|_A=_A,init:bool|_A=_A,log_config:LogConfig|_A=_A,cpu_shares:int|_A=_A,mem_limit:int|str|_A=_A,auth_config:dict[str,str]|_A=_A)->str:0
	@abstractmethod
	def run_container(self,image_name:str,stdin:bytes=_A,*,name:str|_A=_A,entrypoint:str|_A=_A,remove:bool=_B,interactive:bool=_B,tty:bool=_B,detach:bool=_B,command:list[str]|str|_A=_A,volumes:VolumeMappings|list[SimpleVolumeBind]|_A=_A,ports:PortMappings|_A=_A,exposed_ports:list[str]|_A=_A,env_vars:dict[str,str]|_A=_A,user:str|_A=_A,cap_add:list[str]|_A=_A,cap_drop:list[str]|_A=_A,security_opt:list[str]|_A=_A,network:str|_A=_A,dns:str|_A=_A,additional_flags:str|_A=_A,workdir:str|_A=_A,labels:dict[str,str]|_A=_A,platform:DockerPlatform|_A=_A,privileged:bool|_A=_A,ulimits:list[Ulimit]|_A=_A,init:bool|_A=_A,log_config:LogConfig|_A=_A,cpu_shares:int|_A=_A,mem_limit:int|str|_A=_A,auth_config:dict[str,str]|_A=_A)->tuple[bytes,bytes]:0
	def run_container_from_config(B,container_config:ContainerConfiguration)->tuple[bytes,bytes]:A=container_config;return B.run_container(image_name=A.image_name,stdin=A.stdin,name=A.name,entrypoint=A.entrypoint,remove=A.remove,interactive=A.interactive,tty=A.tty,detach=A.detach,command=A.command,volumes=A.volumes,ports=A.ports,exposed_ports=A.exposed_ports,env_vars=A.env_vars,user=A.user,cap_add=A.cap_add,cap_drop=A.cap_drop,security_opt=A.security_opt,network=A.network,dns=A.dns,additional_flags=A.additional_flags,workdir=A.workdir,platform=A.platform,privileged=A.privileged,ulimits=A.ulimits,init=A.init,log_config=A.log_config,cpu_shares=A.cpu_shares,mem_limit=A.mem_limit,auth_config=A.auth_config)
	@abstractmethod
	def exec_in_container(self,container_name_or_id:str,command:list[str]|str,interactive:bool=_B,detach:bool=_B,env_vars:dict[str,str|_A]|_A=_A,stdin:bytes|_A=_A,user:str|_A=_A,workdir:str|_A=_A)->tuple[bytes,bytes]:0
	@abstractmethod
	def start_container(self,container_name_or_id:str,stdin:bytes=_A,interactive:bool=_B,attach:bool=_B,flags:str|_A=_A)->tuple[bytes,bytes]:0
	@abstractmethod
	def attach_to_container(self,container_name_or_id:str):0
	@abstractmethod
	def login(self,username:str,password:str,registry:str|_A=_A)->_A:0
	def __get_container_names(B,return_all:bool)->list[str]:A=B.list_containers(all=return_all);A=[A['name']for A in A];return A
class Util:
	MAX_ENV_ARGS_LENGTH=20000
	@staticmethod
	def format_env_vars(key:str,value:str|_A):
		A=value
		if A is _A:return key
		return f"{key}={A}"
	@classmethod
	def create_env_vars_file_flag(B,env_vars:dict)->tuple[list[str],str|_A]:
		A=env_vars
		if not A:return[],_A
		E=[];A=dict(A);C=_A
		if len(str(A))>B.MAX_ENV_ARGS_LENGTH:
			C=B.mountable_tmp_file();F=''
			for(G,D)in dict(A).items():
				if len(D)>B.MAX_ENV_ARGS_LENGTH:continue
				A.pop(G);D=D.replace('\n','\\');F+=f"{B.format_env_vars(G,D)}\n"
			save_file(C,F);E+=[_J,C]
		H=[D for(A,C)in A.items()for D in['-e',B.format_env_vars(A,C)]];E+=H;return E,C
	@staticmethod
	def rm_env_vars_file(env_vars_file)->_A:
		A=env_vars_file
		if A:return rm_rf(A)
	@staticmethod
	def mountable_tmp_file():A=os.path.join(config.dirs.mounted_tmp,short_uid());TMP_FILES.append(A);return A
	@staticmethod
	def append_without_latest(image_names:list[str]):
		A=image_names;B=':latest'
		for C in list(A):
			if C.endswith(B):A.append(C[:-len(B)])
	@staticmethod
	def strip_wellknown_repo_prefixes(image_names:list[str])->list[str]:
		B=[]
		for A in image_names:
			for C in WELL_KNOWN_IMAGE_REPO_PREFIXES:
				if A.startswith(C):A=A.removeprefix(C);break
			B.append(A)
		return B
	@staticmethod
	def tar_path(path:str,target_path:str,is_dir:bool):
		A=path;B=tempfile.NamedTemporaryFile()
		with tarfile.open(mode='w',fileobj=B)as C:D=os.path.abspath(A);E=os.path.basename(A)if is_dir else os.path.basename(target_path)or os.path.basename(A);C.add(D,arcname=E)
		B.seek(0);return B
	@staticmethod
	def untar_to_path(tardata,target_path):
		A=target_path;A=Path(A)
		with tarfile.open(mode='r',fileobj=io.BytesIO(b''.join(A for A in tardata)))as B:
			if A.is_dir():B.extractall(path=A)
			else:
				C=B.next()
				if C:C.name=A.name;B.extract(C,A.parent)
				else:LOG.debug('File to copy empty, ignoring...')
	@staticmethod
	def _read_docker_cli_env_file(env_file:str)->dict[str,str]:
		B=env_file;C={}
		try:
			with open(B)as G:H=G.readlines()
		except FileNotFoundError as D:LOG.error("Specified env file '%s' not found. Please make sure the file is properly mounted into the LocalStack container. Error: %s",B,D);raise
		except OSError as D:LOG.error("Could not read env file '%s'. Please make sure the LocalStack container has the permissions to read it. Error: %s",B,D);raise
		for(K,A)in enumerate(H):
			A=A.strip()
			if not A or A.startswith('#'):continue
			E,I,F=A.partition('=')
			if F or I:C[E]=F
			elif(J:=os.environ.get(E)):C[E]=J
		return C
	@staticmethod
	def parse_additional_flags(additional_flags:str,env_vars:dict[str,str]|_A=_A,labels:dict[str,str]|_A=_A,volumes:list[SimpleVolumeBind]|_A=_A,network:str|_A=_A,platform:DockerPlatform|_A=_A,ports:PortMappings|_A=_A,privileged:bool|_A=_A,user:str|_A=_A,ulimits:list[Ulimit]|_A=_A,dns:str|list[str]|_A=_A)->DockerRunFlags:
		T=user;S=privileged;R=platform;Q=network;J=dns;I=ports;H=volumes;G=labels;E=ulimits;D='append';C=env_vars;B=NoExitArgumentParser(description='Docker run flags parser');B.add_argument('--add-host',help='Add a custom host-to-IP mapping (host:ip)',dest='add_hosts',action=D);B.add_argument('--env','-e',help='Set environment variables',dest='envs',action=D);B.add_argument(_J,help='Set environment variables via a file',dest='env_files',action=D);B.add_argument('--compose-env-file',help='Set environment variables via a file, with a docker-compose supported feature set.',dest='compose_env_files',action=D);B.add_argument('--label','-l',help='Add container meta data',dest='labels',action=D);B.add_argument('--network',help='Connect a container to a network');B.add_argument('--platform',type=DockerPlatform,help='Docker platform (e.g., linux/amd64 or linux/arm64)');B.add_argument('--privileged',help='Give extended privileges to this container',action='store_true');B.add_argument('--publish','-p',help='Publish container port(s) to the host',dest='publish_ports',action=D);B.add_argument('--ulimit',help='Container ulimit settings',dest='ulimits',action=D);B.add_argument('--user','-u',help='Username or UID to execute first process');B.add_argument('--volume','-v',help='Bind mount a volume',dest='volumes',action=D);B.add_argument('--dns',help='Set custom DNS servers',dest='dns',action=D);g=shlex.split(additional_flags);A=B.parse_args(g);K=_A
		if A.add_hosts:
			for h in A.add_hosts:K=K if K is not _A else{};Z=h.split(':');K[Z[0]]=Z[1]
		if A.env_files:
			C=C if C is not _A else{}
			for U in A.env_files:C.update(Util._read_docker_cli_env_file(U))
		if A.compose_env_files:
			C=C if C is not _A else{}
			for U in A.compose_env_files:C.update(dotenv.dotenv_values(U))
		if A.envs:
			C=C if C is not _A else{}
			for i in A.envs:j,M,V=i.partition('=');C[j]=V
		if A.labels:
			G=G if G is not _A else{}
			for k in A.labels:
				a,M,l=k.partition('=')
				if a:G[a]=l
		if A.network:LOG.warning("Overwriting Docker container network '%s' with new value '%s'",Q,A.network);Q=A.network
		if A.platform:LOG.warning("Overwriting Docker platform '%s' with new value '%s'",R,A.platform);R=A.platform
		if A.privileged:LOG.warning('Overwriting Docker container privileged flag %s with new value %s',S,A.privileged);S=A.privileged
		if A.publish_ports:
			for W in A.publish_ports:
				N=W.split(':');b=_D
				if len(N)==2:F,L=N
				elif len(N)==3:LOG.warning('Host part of port mappings are ignored currently in additional flags');M,F,L=N
				else:raise ValueError(f"Invalid port string provided: {W}")
				O=F.split('-')
				if len(O)==2:F=[int(O[0]),int(O[1])]
				elif len(O)==1:F=int(F)
				else:raise ValueError(f"Invalid port string provided: {W}")
				if'/'in L:L,b=L.split('/')
				I=I if I is not _A else PortMappings();I.add(F,int(L),b)
		if A.ulimits:
			E=E if E is not _A else[];X={A.name:A for A in E}
			for m in A.ulimits:
				Y,M,V=m.partition('=');c,M,d=V.partition(':');n=int(d)if d else int(c);e=Ulimit(name=Y,soft_limit=int(c),hard_limit=n)
				if X.get(Y):LOG.warning('Overwriting Docker ulimit %s',e)
				X[Y]=e
			E=list(X.values())
		if A.user:LOG.warning("Overwriting Docker user '%s' with new value '%s'",T,A.user);T=A.user
		if A.volumes:
			H=H if H is not _A else[]
			for f in A.volumes:
				P=re.match('(?P<host>[\\w\\s\\\\\\/:\\-.]+?):(?P<container>[\\w\\s\\/\\-.]+)(?::(?P<arg>ro|rw|z|Z))?',f)
				if not P:LOG.warning('Unable to parse volume mount Docker flags: %s',f);continue
				o=P.group('host');p=P.group('container');q=P.group('arg')
				if q:LOG.info('Volume options like :ro or :rw are currently ignored.')
				H.append((o,p))
		J=ensure_list(J or[])
		if A.dns:LOG.info('Extending Docker container DNS servers %s with additional values %s',J,A.dns);J.extend(A.dns)
		return DockerRunFlags(env_vars=C,extra_hosts=K,labels=G,volumes=H,ports=I,network=Q,platform=R,privileged=S,ulimits=E,user=T,dns=J)
	@staticmethod
	def convert_mount_list_to_dict(volumes:list[SimpleVolumeBind]|VolumeMappings)->dict[str,dict[str,str]]:
		def A(paths:VolumeMappingSpecification):
			A=paths
			if isinstance(A,(BindMount,VolumeDirMount)):return A.to_docker_sdk_parameters()
			else:return str(A[0]),{_F:A[1],_G:'rw'}
		return dict(map(A,volumes))
	@staticmethod
	def resolve_dockerfile_path(dockerfile_path:str)->str:
		A=dockerfile_path;B=os.path.join(A,'Dockerfile')
		if os.path.isdir(A)and os.path.exists(B):return B
		return A