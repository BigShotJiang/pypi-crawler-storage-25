_Z='no container with name or ID'
_Y='No such container'
_X='--workdir'
_W='--user'
_V='--detach'
_U='Unable to find image'
_T='auth_config'
_S='create'
_R='no such object'
_Q='inspect'
_P='access to the resource is denied'
_O='does not exist'
_N='No such image'
_M='--timeout'
_L='--filter'
_K='--interactive'
_J='.*network (.*) not found.*'
_I='Trying to pull'
_H='--platform'
_G='image not known'
_F='{{json .}}'
_E='network'
_D='--format'
_C=True
_B=False
_A=None
import functools,itertools,json,logging,os,re,shlex,subprocess
from collections.abc import Callable
from localstack_cli import config
from localstack_cli.utils.collections import ensure_list
from localstack_cli.utils.container_utils.container_client import AccessDenied,CancellableStream,ContainerClient,ContainerException,DockerContainerStats,DockerContainerStatus,DockerNotAvailable,DockerPlatform,LogConfig,Mount,NoSuchContainer,NoSuchImage,NoSuchNetwork,NoSuchObject,PortMappings,RegistryConnectionError,Ulimit,Util,VolumeMappingSpecification,get_registry_from_image_name
from localstack_cli.utils.run import run
from localstack_cli.utils.strings import first_char_to_upper,to_str
LOG=logging.getLogger(__name__)
class CancellableProcessStream(CancellableStream):
	process:subprocess.Popen
	def __init__(A,process:subprocess.Popen)->_A:super().__init__();A.process=process
	def __iter__(A):return A
	def __next__(B):
		A=B.process.stdout.readline()
		if not A:raise StopIteration
		return A
	def close(A):return A.process.terminate()
def parse_size_string(size_str:str)->int:
	A=size_str;A=A.strip().replace(' ','').upper()
	if A=='0B':return 0
	B=re.match('^([\\d.]+)([A-Za-z]+)$',A)
	if not B:return 0
	C=float(B.group(1));D=B.group(2);E={'B':1,'KB':10**3,'MB':10**6,'GB':10**9,'TB':10**12,'KIB':2**10,'MIB':2**20,'GIB':2**30,'TIB':2**40};return int(C*E.get(D,1))
class CmdDockerClient(ContainerClient):
	default_run_outfile:str|_A=_A
	def _docker_cmd(A)->list[str]:
		if not A.has_docker():raise DockerNotAvailable()
		return shlex.split(config.DOCKER_CMD)
	def get_system_info(A)->dict:B=[*A._docker_cmd(),'info',_D,_F];C=run(B);return json.loads(C)
	def get_container_status(E,container_name:str)->DockerContainerStatus:
		C=container_name;D=E._docker_cmd();D+=['ps','-a',_L,f"name={C}",_D,'{{ .Status }} - {{ .Names }}'];A=run(D);A=next((A for A in A.splitlines()if C in A),'');B=A.strip().lower()
		if len(B)==0:return DockerContainerStatus.NON_EXISTENT
		elif'(paused)'in B:return DockerContainerStatus.PAUSED
		elif B.startswith('up '):return DockerContainerStatus.UP
		else:return DockerContainerStatus.DOWN
	def get_container_stats(G,container_name:str)->DockerContainerStats:B='/';C=G._docker_cmd();C+=['stats','--no-stream',_D,_F,container_name];H=run(C);A=json.loads(H);D=A['BlockIO'].split(B);I=parse_size_string(D[0]);J=parse_size_string(D[1]);K=float(A['CPUPerc'].strip('%'));E=A['MemUsage'].split(B);L=parse_size_string(E[0]);M=parse_size_string(E[1]);N=float(A['MemPerc'].strip('%'));F=A['NetIO'].split(B);O=parse_size_string(F[0]);P=parse_size_string(F[1]);return DockerContainerStats(Container=A['ID'],ID=A['ID'],Name=A['Name'],BlockIO=(I,J),CPUPerc=round(K,2),MemPerc=round(N,2),MemUsage=(L,M),NetIO=(O,P),PIDs=int(A['PIDs']),SDKStats=_A)
	def stop_container(C,container_name:str,timeout:int=10)->_A:
		D=container_name;B=C._docker_cmd();B+=['stop',_M,str(timeout),D];LOG.debug('Stopping container with cmd %s',B)
		try:run(B)
		except subprocess.CalledProcessError as A:C._check_and_raise_no_such_container_error(D,error=A);raise ContainerException(f"Docker process returned with errorcode {A.returncode}",A.stdout,A.stderr)from A
	def restart_container(C,container_name:str,timeout:int=10)->_A:
		D=container_name;B=C._docker_cmd();B+=['restart',_M,str(timeout),D];LOG.debug('Restarting container with cmd %s',B)
		try:run(B)
		except subprocess.CalledProcessError as A:C._check_and_raise_no_such_container_error(D,error=A);raise ContainerException(f"Docker process returned with errorcode {A.returncode}",A.stdout,A.stderr)from A
	def pause_container(C,container_name:str)->_A:
		D=container_name;B=C._docker_cmd();B+=['pause',D];LOG.debug('Pausing container with cmd %s',B)
		try:run(B)
		except subprocess.CalledProcessError as A:C._check_and_raise_no_such_container_error(D,error=A);raise ContainerException(f"Docker process returned with errorcode {A.returncode}",A.stdout,A.stderr)from A
	def unpause_container(C,container_name:str)->_A:
		D=container_name;B=C._docker_cmd();B+=['unpause',D];LOG.debug('Unpausing container with cmd %s',B)
		try:run(B)
		except subprocess.CalledProcessError as A:C._check_and_raise_no_such_container_error(D,error=A);raise ContainerException(f"Docker process returned with errorcode {A.returncode}",A.stdout,A.stderr)from A
	def remove_image(E,image:str,force:bool=_C)->_A:
		D=force;B=image;C=E._docker_cmd();C+=['rmi',B]
		if D:C+=['--force']
		LOG.debug('Removing image %s %s',B,'(forced)'if D else'')
		try:run(C)
		except subprocess.CalledProcessError as A:
			F=[_N,_G]
			if any(B in to_str(A.stdout)for B in F):raise NoSuchImage(B,stdout=A.stdout,stderr=A.stderr)
			raise ContainerException(f"Docker process returned with errorcode {A.returncode}",A.stdout,A.stderr)from A
	def commit(C,container_name_or_id:str,image_name:str,image_tag:str):
		E=image_tag;D=image_name;B=container_name_or_id;F=C._docker_cmd();F+=['commit',B,f"{D}:{E}"];LOG.debug('Creating image from container %s as %s:%s',B,D,E)
		try:run(F)
		except subprocess.CalledProcessError as A:C._check_and_raise_no_such_container_error(B,error=A);raise ContainerException(f"Docker process returned with errorcode {A.returncode}",A.stdout,A.stderr)from A
	def remove_container(C,container_name:str,force=_C,check_existence=_B,volumes=_B)->_A:
		E=force;D=container_name
		if check_existence and D not in C.get_all_container_names():return
		A=C._docker_cmd()+['rm']
		if E:A.append('-f')
		if volumes:A.append('--volumes')
		A.append(D);LOG.debug('Removing container with cmd %s',A)
		try:
			F=run(A)
			if isinstance(F,str)and not E:C._check_output_and_raise_no_such_container_error(D,output=F)
		except subprocess.CalledProcessError as B:
			if not E:C._check_and_raise_no_such_container_error(D,error=B)
			raise ContainerException(f"Docker process returned with errorcode {B.returncode}",B.stdout,B.stderr)from B
	def list_containers(F,filter:list[str]|str|_A=_A,all=_C)->list[dict]:
		filter=[filter]if isinstance(filter,str)else filter;A=F._docker_cmd();A.append('ps')
		if all:A.append('-a')
		G=[]
		if filter:G+=[B for A in filter for B in[_L,A]]
		A+=G;A.append(_D);A.append('{{json . }}')
		try:C=run(A).strip()
		except subprocess.CalledProcessError as D:raise ContainerException(f"Docker process returned with errorcode {D.returncode}",D.stdout,D.stderr)from D
		E=[]
		if C:
			if C[0]=='[':E=json.loads(C)
			else:E=[json.loads(A)for A in C.splitlines()]
		H=[]
		for B in E:I=F._transform_container_labels(B['Labels']);H.append({'id':B.get('ID')or B['Id'],'image':B['Image'],'name':ensure_list(B['Names'])[0],'status':B['State'],'labels':I})
		return H
	def copy_into_container(D,container_name:str,local_path:str,container_path:str)->_A:
		B=container_name;C=D._docker_cmd();C+=['cp',local_path,f"{B}:{container_path}"];LOG.debug('Copying into container with cmd: %s',C)
		try:run(C)
		except subprocess.CalledProcessError as A:
			D._check_and_raise_no_such_container_error(B,error=A)
			if _O in to_str(A.stdout):raise NoSuchContainer(B,stdout=A.stdout,stderr=A.stderr)
			raise ContainerException(f"Docker process returned with errorcode {A.returncode}",A.stdout,A.stderr)from A
	def copy_from_container(D,container_name:str,local_path:str,container_path:str)->_A:
		B=container_name;C=D._docker_cmd();C+=['cp',f"{B}:{container_path}",local_path];LOG.debug('Copying from container with cmd: %s',C)
		try:run(C)
		except subprocess.CalledProcessError as A:
			D._check_and_raise_no_such_container_error(B,error=A)
			if re.match('.*container .+ does not exist',to_str(A.stdout)):raise NoSuchContainer(B,stdout=A.stdout,stderr=A.stderr)
			raise ContainerException(f"Docker process returned with errorcode {A.returncode}",A.stdout,A.stderr)from A
	def pull_image(D,docker_image:str,platform:DockerPlatform|_A=_A,log_handler:Callable[[str],_A]|_A=_A,auth_config:dict[str,str]|_A=_A)->_A:
		G=log_handler;F=platform;B=docker_image;D._login_if_needed(auth_config,B);C=D._docker_cmd();B=D.registry_resolver_strategy.resolve(B);C+=['pull',B]
		if F:C+=[_H,F]
		LOG.debug('Pulling image with cmd: %s',C)
		try:
			H=run(C)
			if G:
				for I in H.split('\n'):G(to_str(I))
		except subprocess.CalledProcessError as A:
			E=to_str(A.stdout)
			if'pull access denied'in E:raise NoSuchImage(B,stdout=A.stdout,stderr=A.stderr)
			if _I in E and _P in E:raise NoSuchImage(B,stdout=A.stdout,stderr=A.stderr)
			raise ContainerException(f"Docker process returned with errorcode {A.returncode}",A.stdout,A.stderr)from A
	def push_image(D,docker_image:str,auth_config:dict[str,str]|_A=_A)->_A:
		B=docker_image;D._login_if_needed(auth_config,B);C=D._docker_cmd();C+=['push',B];LOG.debug('Pushing image with cmd: %s',C)
		try:run(C)
		except subprocess.CalledProcessError as A:
			if'is denied'in to_str(A.stdout):raise AccessDenied(B)
			if'requesting higher privileges than access token allows'in to_str(A.stdout):raise AccessDenied(B)
			if'access token has insufficient scopes'in to_str(A.stdout):raise AccessDenied(B)
			if'authorization failed: no basic auth credentials'in to_str(A.stdout):raise AccessDenied(B)
			if'failed to authorize: failed to fetch oauth token'in to_str(A.stdout):raise AccessDenied(B)
			if _O in to_str(A.stdout):raise NoSuchImage(B)
			if'connection refused'in to_str(A.stdout):raise RegistryConnectionError(A.stdout)
			if'failed to do request:'in to_str(A.stdout):raise RegistryConnectionError(A.stdout)
			if _G in to_str(A.stdout):raise NoSuchImage(B)
			raise ContainerException(f"Docker process returned with errorcode {A.returncode}",A.stdout,A.stderr)from A
	def build_image(F,dockerfile_path:str,image_name:str,context_path:str=_A,platform:DockerPlatform|_A=_A):
		E=platform;D=context_path;B=dockerfile_path;A=F._docker_cmd();B=Util.resolve_dockerfile_path(B);D=D or os.path.dirname(B);A+=['build','-t',image_name,'-f',B]
		if E:A+=[_H,E]
		A+=[D];LOG.debug('Building Docker image: %s',A)
		try:return run(A)
		except subprocess.CalledProcessError as C:raise ContainerException(f"Docker build process returned with error code {C.returncode}",C.stdout,C.stderr)from C
	def tag_image(E,source_ref:str,target_name:str)->_A:
		C=target_name;B=source_ref;D=E._docker_cmd();D+=['tag',B,C];LOG.debug('Tagging Docker image %s as %s',B,C)
		try:run(D)
		except subprocess.CalledProcessError as A:
			F=[_N,_G]
			if any(B in to_str(A.stdout)for B in F):raise NoSuchImage(B)
			raise ContainerException(f"Docker process returned with error code {A.returncode}",A.stdout,A.stderr)from A
	def get_docker_image_names(C,strip_latest=_C,include_tags=_C,strip_wellknown_repo_prefixes:bool=_C):
		D='{{.Repository}}:{{.Tag}}'if include_tags else'{{.Repository}}';B=C._docker_cmd();B+=['images',_D,D]
		try:
			E=run(B);A=E.splitlines()
			if strip_wellknown_repo_prefixes:A=Util.strip_wellknown_repo_prefixes(A)
			if strip_latest:Util.append_without_latest(A)
			return A
		except Exception as F:LOG.info('Unable to list Docker images via "%s": %s',B,F);return[]
	def get_container_logs(B,container_name_or_id:str,safe=_B)->str:
		C=container_name_or_id;D=B._docker_cmd();D+=['logs',C]
		try:return run(D)
		except subprocess.CalledProcessError as A:
			if safe:return''
			B._check_and_raise_no_such_container_error(C,error=A);raise ContainerException(f"Docker process returned with errorcode {A.returncode}",A.stdout,A.stderr)from A
	def stream_container_logs(A,container_name_or_id:str)->CancellableStream:B=container_name_or_id;A.inspect_container(B);C=A._docker_cmd();C+=['logs','--follow',B];D:subprocess.Popen=run(C,asynchronous=_C,outfile=subprocess.PIPE,stderr=subprocess.STDOUT);return CancellableProcessStream(D)
	def _inspect_object(F,object_name_or_id:str)->dict[str,dict|list|str]:
		C=object_name_or_id;E=F._docker_cmd();E+=[_Q,_D,_F,C]
		try:G=run(E,print_error=_B)
		except subprocess.CalledProcessError as A:
			if _R in to_str(A.stdout).lower():raise NoSuchObject(C,stdout=A.stdout,stderr=A.stderr)
			raise ContainerException(f"Docker process returned with errorcode {A.returncode}",A.stdout,A.stderr)from A
		B=json.loads(G.strip())
		if isinstance(B,list):
			if len(B)==1:D=B[0];D={first_char_to_upper(A):B for(A,B)in D.items()};return D
			LOG.info('Expected a single object for `inspect` on ID %s, got %s',C,len(B))
		return B
	def inspect_container(A,container_name_or_id:str)->dict[str,dict|str]:
		try:return A._inspect_object(container_name_or_id)
		except NoSuchObject as B:raise NoSuchContainer(container_name_or_id=B.object_id)
	def inspect_image(C,image_name:str,pull:bool=_C,strip_wellknown_repo_prefixes:bool=_C)->dict[str,dict|list|str]:
		E='RepoTags';D='RepoDigests';B=image_name;B=C.registry_resolver_strategy.resolve(B)
		try:
			A=C._inspect_object(B)
			if strip_wellknown_repo_prefixes:
				if A.get(D):A[D]=Util.strip_wellknown_repo_prefixes(A[D])
				if A.get(E):A[E]=Util.strip_wellknown_repo_prefixes(A[E])
			return A
		except NoSuchObject as F:
			if pull:C.pull_image(B);return C.inspect_image(B,pull=_B)
			raise NoSuchImage(image_name=F.object_id)
	def create_network(C,network_name:str)->str:
		B=C._docker_cmd();B+=[_E,_S,network_name]
		try:return run(B).strip()
		except subprocess.CalledProcessError as A:raise ContainerException(f"Docker process returned with errorcode {A.returncode}",A.stdout,A.stderr)from A
	def delete_network(D,network_name:str)->_A:
		B=network_name;C=D._docker_cmd();C+=[_E,'rm',B]
		try:run(C)
		except subprocess.CalledProcessError as A:
			E=to_str(A.stdout)
			if re.match(_J,E):raise NoSuchNetwork(network_name=B)
			else:raise ContainerException(f"Docker process returned with errorcode {A.returncode}",A.stdout,A.stderr)from A
	def inspect_network(A,network_name:str)->dict[str,dict|str]:
		try:return A._inspect_object(network_name)
		except NoSuchObject as B:raise NoSuchNetwork(network_name=B.object_id)
	def connect_container_to_network(F,network_name:str,container_name_or_id:str,aliases:list|_A=_A,link_local_ips:list[str]=_A)->_A:
		G=link_local_ips;E=aliases;D=container_name_or_id;C=network_name;LOG.debug("Connecting container '%s' to network '%s' with aliases '%s'",D,C,E);B=F._docker_cmd();B+=[_E,'connect']
		if E:B+=['--alias',','.join(E)]
		if G:B+=['--link-local-ip',','.join(G)]
		B+=[C,D]
		try:run(B)
		except subprocess.CalledProcessError as A:
			H=to_str(A.stdout)
			if re.match(_J,H):raise NoSuchNetwork(network_name=C)
			F._check_and_raise_no_such_container_error(D,error=A);raise ContainerException(f"Docker process returned with errorcode {A.returncode}",A.stdout,A.stderr)from A
	def disconnect_container_from_network(D,network_name:str,container_name_or_id:str)->_A:
		C=container_name_or_id;B=network_name;LOG.debug("Disconnecting container '%s' from network '%s'",C,B);E=D._docker_cmd()+[_E,'disconnect',B,C]
		try:run(E)
		except subprocess.CalledProcessError as A:
			F=to_str(A.stdout)
			if re.match(_J,F):raise NoSuchNetwork(network_name=B)
			D._check_and_raise_no_such_container_error(C,error=A);raise ContainerException(f"Docker process returned with errorcode {A.returncode}",A.stdout,A.stderr)from A
	def get_container_ip(C,container_name_or_id:str)->str:
		B=container_name_or_id;D=C._docker_cmd();D+=[_Q,_D,'{{range .NetworkSettings.Networks}}{{.IPAddress}} {{end}}',B]
		try:E=run(D).strip();return E.split(' ')[0]if E else''
		except subprocess.CalledProcessError as A:
			C._check_and_raise_no_such_container_error(B,error=A)
			if _R in to_str(A.stdout).lower():raise NoSuchContainer(B,stdout=A.stdout,stderr=A.stderr)
			raise ContainerException(f"Docker process returned with errorcode {A.returncode}",A.stdout,A.stderr)from A
	def login(D,username:str,password:str,registry:str|_A=_A)->_A:
		C=registry;B=D._docker_cmd();B+=['login','-u',username,'-p',password]
		if C:B.append(C)
		try:run(B)
		except subprocess.CalledProcessError as A:raise ContainerException(f"Docker process returned with errorcode {A.returncode}",A.stdout,A.stderr)from A
	@functools.cache
	def has_docker(self)->bool:
		try:run(shlex.split(config.DOCKER_CMD)+['ps']);return _C
		except(subprocess.CalledProcessError,FileNotFoundError):return _B
	def create_container(C,image_name:str,**E)->str:
		B=image_name;G=E.pop(_T,_A);C._login_if_needed(G,B);B=C.registry_resolver_strategy.resolve(B);F,H=C._build_run_create_cmd(_S,B,**E);LOG.debug('Create container with cmd: %s',F)
		try:D=run(F);D=D.strip().split('\n')[-1];return D.strip()
		except subprocess.CalledProcessError as A:
			I=[_U,_I]
			if any(B in to_str(A.stdout)for B in I):raise NoSuchImage(B,stdout=A.stdout,stderr=A.stderr)
			raise ContainerException(f"Docker process returned with errorcode {A.returncode}",A.stdout,A.stderr)from A
		finally:Util.rm_env_vars_file(H)
	def run_container(C,image_name:str,stdin=_A,**D)->tuple[bytes,bytes]:
		A=image_name;F=D.pop(_T,_A);C._login_if_needed(F,A);A=C.registry_resolver_strategy.resolve(A);E,G=C._build_run_create_cmd('run',A,**D);LOG.debug('Run container with cmd: %s',E)
		try:return C._run_async_cmd(E,stdin,D.get('name')or'',A)
		except ContainerException as B:
			if _I in str(B)and _P in str(B):raise NoSuchImage(A,stdout=B.stdout,stderr=B.stderr)from B
			raise
		finally:Util.rm_env_vars_file(G)
	def exec_in_container(C,container_name_or_id:str,command:list[str]|str,interactive=_B,detach=_B,env_vars:dict[str,str|_A]|_A=_A,stdin:bytes|_A=_A,user:str|_A=_A,workdir:str|_A=_A)->tuple[bytes,bytes]:
		F=workdir;E=env_vars;D=container_name_or_id;B=command;G=_A;A=C._docker_cmd();A.append('exec')
		if interactive:A.append(_K)
		if detach:A.append(_V)
		if user:A+=[_W,user]
		if F:A+=[_X,F]
		if E:H,G=Util.create_env_vars_file_flag(E);A+=H
		A.append(D);A+=B if isinstance(B,list)else[B];LOG.debug('Execute command in container: %s',A)
		try:return C._run_async_cmd(A,stdin,D)
		finally:Util.rm_env_vars_file(G)
	def start_container(B,container_name_or_id:str,stdin=_A,interactive:bool=_B,attach:bool=_B,flags:str|_A=_A)->tuple[bytes,bytes]:
		D=flags;C=container_name_or_id;A=B._docker_cmd()+['start']
		if D:A.append(D)
		if interactive:A.append(_K)
		if attach:A.append('--attach')
		A.append(C);LOG.debug('Start container with cmd: %s',A);return B._run_async_cmd(A,stdin,C)
	def attach_to_container(B,container_name_or_id:str):A=container_name_or_id;C=B._docker_cmd()+['attach',A];LOG.debug('Attaching to container %s',A);return B._run_async_cmd(C,stdin=_A,container_name=A)
	def _run_async_cmd(G,cmd:list[str],stdin:bytes,container_name:str,image_name=_A)->tuple[bytes,bytes]:
		C=stdin;D={'inherit_env':_C,'asynchronous':_C,'stderr':subprocess.PIPE,'outfile':G.default_run_outfile or subprocess.PIPE}
		if C:D['stdin']=_C
		try:
			B=run(cmd,**D);E,F=B.communicate(input=C)
			if B.returncode!=0:raise subprocess.CalledProcessError(B.returncode,cmd,E,F)
			else:return E,F
		except subprocess.CalledProcessError as A:
			H=to_str(A.stderr)
			if _U in H:raise NoSuchImage(image_name or'',stdout=A.stdout,stderr=A.stderr)
			I=_Y,_Z
			if any(B.lower()in to_str(A.stderr).lower()for B in I):raise NoSuchContainer(container_name,stdout=A.stdout,stderr=A.stderr)
			raise ContainerException(f"Docker process returned with errorcode {A.returncode}",A.stdout,A.stderr)from A
	def _build_run_create_cmd(G,action:str,image_name:str,*,name:str|_A=_A,entrypoint:list[str]|str|_A=_A,remove:bool=_B,interactive:bool=_B,tty:bool=_B,detach:bool=_B,command:list[str]|str|_A=_A,volumes:list[VolumeMappingSpecification]|_A=_A,ports:PortMappings|_A=_A,exposed_ports:list[str]|_A=_A,env_vars:dict[str,str]|_A=_A,user:str|_A=_A,cap_add:list[str]|_A=_A,cap_drop:list[str]|_A=_A,security_opt:list[str]|_A=_A,network:str|_A=_A,dns:str|list[str]|_A=_A,additional_flags:str|_A=_A,workdir:str|_A=_A,privileged:bool|_A=_A,labels:dict[str,str]|_A=_A,platform:DockerPlatform|_A=_A,ulimits:list[Ulimit]|_A=_A,init:bool|_A=_A,log_config:LogConfig|_A=_A,cpu_shares:int|_A=_A,mem_limit:int|str|_A=_A)->tuple[list[str],str]:
		X='--entrypoint';V=mem_limit;U=cpu_shares;T=ulimits;S=platform;R=labels;Q=workdir;P=additional_flags;O=network;N=security_opt;M=cap_drop;L=cap_add;K=env_vars;J=exposed_ports;I=ports;H=volumes;D=log_config;C=command;B=entrypoint;W=_A;A=G._docker_cmd()+[action]
		if remove:A.append('--rm')
		if name:A+=['--name',name]
		if B is not _A:
			if isinstance(B,str):A+=[X,B]
			else:A+=[X,shlex.join(B)]
		if privileged:A+=['--privileged']
		if H:A+=[B for A in H for B in['-v',G._map_to_volume_param(A)]]
		if interactive:A.append(_K)
		if tty:A.append('--tty')
		if detach:A.append(_V)
		if I:A+=I.to_list()
		if J:A+=list(itertools.chain.from_iterable(['--expose',A]for A in J))
		if K:Y,W=Util.create_env_vars_file_flag(K);A+=Y
		if user:A+=[_W,user]
		if L:A+=list(itertools.chain.from_iterable(['--cap-add',A]for A in L))
		if M:A+=list(itertools.chain.from_iterable(['--cap-drop',A]for A in M))
		if N:A+=list(itertools.chain.from_iterable(['--security-opt',A]for A in N))
		if O:A+=['--network',O]
		if dns:
			for Z in ensure_list(dns):A+=['--dns',Z]
		if Q:A+=[_X,Q]
		if R:
			for(E,F)in R.items():A+=['--label',f"{E}={F}"]
		if S:A+=[_H,S]
		if T:A+=list(itertools.chain.from_iterable(['--ulimit',str(A)]for A in T))
		if init:A+=['--init']
		if D:
			A+=['--log-driver',D.type]
			for(E,F)in D.config.items():A+=['--log-opt',f"{E}={F}"]
		if U:A+=['--cpu-shares',str(U)]
		if V:A+=['--memory',str(V)]
		if P:A+=shlex.split(P)
		A.append(image_name)
		if C:A+=C if isinstance(C,list)else[C]
		return A,W
	@staticmethod
	def _map_to_volume_param(volume:VolumeMappingSpecification)->str:
		A=volume
		if isinstance(A,Mount):return A.to_str()
		else:return f"{A[0]}:{A[1]}"
	def _check_and_raise_no_such_container_error(B,container_name_or_id:str,error:subprocess.CalledProcessError):A=error;B._check_output_and_raise_no_such_container_error(container_name_or_id,str(A.stdout),error=str(A.stderr))
	def _check_output_and_raise_no_such_container_error(C,container_name_or_id:str,output:str,error:str|_A=_A):
		A=output;B=_Y,_Z
		if any(B.lower()in A.lower()for B in B):raise NoSuchContainer(container_name_or_id,stdout=A,stderr=error)
	def _transform_container_labels(B,labels:str|dict[str,str])->dict[str,str]:
		A=labels
		if isinstance(A,dict):return A
		A=A.split(',');A=[A.partition('=')for A in A];return{A[0]:A[2]for A in A}
	def _login_if_needed(B,auth_config:dict[str,str]|_A,image_name)->_A:
		A=auth_config
		if A:LOG.warning('Using global docker login for authentication in docker_cmd_client. This may lead to unexpected behaviors with concurrent requests to different registries. Consider stop using LEGACY_DOCKER_CLIENT for thread-safe authentication.');C=get_registry_from_image_name(image_name);B.login(username=A.get('username',''),password=A.get('password',''),registry=C)