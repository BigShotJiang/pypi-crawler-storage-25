_A=None
import functools,logging,platform,random
from localstack_cli import config
from localstack_cli.constants import DEFAULT_VOLUME_DIR,DOCKER_IMAGE_NAME_PRO
from localstack_cli.utils.collections import ensure_list
from localstack_cli.utils.container_utils.container_client import ContainerClient,DockerNotAvailable,PortMappings,VolumeInfo
from localstack_cli.utils.net import IntOrPort,Port,PortNotAvailableException,PortRange
from localstack_cli.utils.objects import singleton_factory
from localstack_cli.utils.strings import to_str
LOG=logging.getLogger(__name__)
PORT_START=0
PORT_END=65536
RANDOM_PORT_START=1024
RANDOM_PORT_END=65536
def is_docker_sdk_installed()->bool:
	try:import docker;return True
	except ModuleNotFoundError:return False
def create_docker_client()->ContainerClient:
	if config.LEGACY_DOCKER_CLIENT or not is_docker_sdk_installed()or not config.is_in_docker:from localstack_cli.utils.container_utils.docker_cmd_client import CmdDockerClient as A;LOG.debug('Using CmdDockerClient. LEGACY_DOCKER_CLIENT: %s, SDK installed: %s',config.LEGACY_DOCKER_CLIENT,is_docker_sdk_installed());return A()
	else:from localstack_cli.utils.container_utils.docker_sdk_client import SdkDockerClient as B;LOG.debug('Using SdkDockerClient. LEGACY_DOCKER_CLIENT: %s, SDK installed: %s',config.LEGACY_DOCKER_CLIENT,is_docker_sdk_installed());return B()
def get_current_container_id()->str:
	if not config.is_in_docker:raise ValueError('not in docker')
	A=platform.node()
	if not A:raise OSError('no hostname returned to use as container id')
	return A
def inspect_current_container_mounts()->list[VolumeInfo]:return DOCKER_CLIENT.inspect_container_volumes(get_current_container_id())
@functools.lru_cache
def get_default_volume_dir_mount()->VolumeInfo|_A:
	for A in inspect_current_container_mounts():
		if A.destination.rstrip('/')==DEFAULT_VOLUME_DIR:return A
def get_host_path_for_path_in_docker(path):
	A=path
	if config.is_in_docker and DOCKER_CLIENT.has_docker():
		B=get_default_volume_dir_mount()
		if B:
			if B.type!='bind':raise ValueError(f"Mount to {DEFAULT_VOLUME_DIR} needs to be a bind mount for mounting to work")
			if not A.startswith(f"{DEFAULT_VOLUME_DIR}/")and A!=DEFAULT_VOLUME_DIR:LOG.warning("Error while performing automatic host path replacement for path '%s' to source '%s'",A,B.source)
			else:C=A.removeprefix(DEFAULT_VOLUME_DIR);D=B.source+C;return D
		else:raise ValueError(f"No volume mounted to {DEFAULT_VOLUME_DIR}")
	return A
def container_ports_can_be_bound(ports:IntOrPort|list[IntOrPort],address:str|_A=_A)->bool:
	C=ports;D=PortMappings(bind_host=address or'');C=ensure_list(C)
	for A in C:A=Port.wrap(A);D.add(A.port,A.port,protocol=A.protocol)
	try:E=DOCKER_CLIENT.run_container(_get_ports_check_docker_image(),entrypoint='sh',command=['-c','echo test123'],ports=D,remove=True)
	except DockerNotAvailable as B:LOG.warning('Cannot perform port check because Docker is not available.');raise B
	except Exception as B:
		if'port is already allocated'not in str(B)and'address already in use'not in str(B):LOG.warning('Unexpected error when attempting to determine container port status',exc_info=LOG.isEnabledFor(logging.DEBUG))
		return False
	if to_str(E[0]or'').strip()!='test123':LOG.warning('Unexpected output when attempting to determine container port status: %s',E)
	return True
class _DockerPortRange(PortRange):
	def _port_can_be_bound(A,port:IntOrPort)->bool:return container_ports_can_be_bound(port)
reserved_docker_ports=_DockerPortRange(PORT_START,PORT_END)
def is_port_available_for_containers(port:IntOrPort)->bool:return not is_container_port_reserved(port)and container_ports_can_be_bound(port)
def reserve_container_port(port:IntOrPort,duration:int=_A):reserved_docker_ports.reserve_port(port,duration=duration)
def is_container_port_reserved(port:IntOrPort)->bool:A=port;A=Port.wrap(A);return reserved_docker_ports.is_port_reserved(A)
def reserve_available_container_port(duration:int=_A,port_start:int=_A,port_end:int=_A,protocol:str=_A)->int:
	D=port_end;C=port_start;B=protocol;B=B or'tcp'
	def F():
		A=_A
		while not A or reserved_docker_ports.is_port_reserved(A):E=random.randint(RANDOM_PORT_START if C is _A else C,RANDOM_PORT_END if D is _A else D);A=Port(port=E,protocol=B)
		return A
	E=10
	for H in range(E):
		A=F()
		try:reserve_container_port(A,duration=duration);return A.port
		except PortNotAvailableException as G:LOG.debug('Could not bind port %s, trying the next one: %s',A,G)
	raise PortNotAvailableException(f"Unable to determine available Docker container port after {E} retries")
@singleton_factory
def _get_ports_check_docker_image()->str:
	if config.PORTS_CHECK_DOCKER_IMAGE:return config.PORTS_CHECK_DOCKER_IMAGE
	if not config.is_in_docker:from localstack_cli.utils.bootstrap import get_docker_image_to_start as A;return A()
	try:B=DOCKER_CLIENT.inspect_container(get_current_container_id());return B['Config']['Image']
	except Exception:return DOCKER_IMAGE_NAME_PRO
DOCKER_CLIENT:ContainerClient=create_docker_client()