_A=True
import base64,decimal,json,logging,os
from datetime import date,datetime
from json import JSONDecodeError
from typing import Any
from localstack_cli.config import HostAndPort
from.numbers import is_number
from.strings import to_str
from.time import timestamp_millis
LOG=logging.getLogger(__name__)
class CustomEncoder(json.JSONEncoder):
	def default(A,o):
		import yaml
		if isinstance(o,HostAndPort):return str(o)
		if isinstance(o,decimal.Decimal):
			if o%1>0:return float(o)
			else:return int(o)
		if isinstance(o,(datetime,date)):return timestamp_millis(o)
		if isinstance(o,yaml.ScalarNode):
			if o.tag=='tag:yaml.org,2002:int':return int(o.value)
			if o.tag=='tag:yaml.org,2002:float':return float(o.value)
			if o.tag=='tag:yaml.org,2002:bool':return bool(o.value)
			return str(o.value)
		try:
			if isinstance(o,bytes):return to_str(o)
			return super().default(o)
		except Exception:return
class BytesEncoder(json.JSONEncoder):
	def default(B,obj):
		A=obj
		if isinstance(A,bytes):return to_str(base64.b64encode(A))
		return super().default(A)
class FileMappedDocument(dict):
	path:str|os.PathLike
	def __init__(A,path:str|os.PathLike,mode=436):super().__init__();A.path=path;A.mode=mode;A.load()
	def load(A):
		if not os.path.exists(A.path):return
		if os.path.isdir(A.path):raise IsADirectoryError
		with open(A.path)as B:A.update(json.load(B))
	def save(A):
		if os.path.isdir(A.path):raise IsADirectoryError
		if not os.path.exists(A.path):os.makedirs(os.path.dirname(A.path),exist_ok=_A)
		def B(path,flags):B=os.open(path,flags,A.mode);os.chmod(path,mode=A.mode,follow_symlinks=_A);return B
		with open(A.path,'w',opener=B)as C:json.dump(A,C)
def clone(item):return json.loads(json.dumps(item))
def clone_safe(item):return clone(json_safe(item))
def parse_json_or_yaml(markup:str)->Any:
	A=markup;import yaml as B
	try:return json.loads(A)
	except Exception:
		try:return clone_safe(B.safe_load(A))
		except Exception:
			try:return clone_safe(B.load(A,Loader=B.SafeLoader))
			except Exception:raise
def try_json(data:str):
	try:return json.loads(to_str(data or'{}'))
	except JSONDecodeError:LOG.warning('failed serialize to json, fallback to original');return data
def json_safe(item:Any)->Any:
	A=item
	try:return json.loads(json.dumps(A,cls=CustomEncoder))
	except Exception:A=fix_json_keys(A);return json.loads(json.dumps(A,cls=CustomEncoder))
def fix_json_keys(item:Any):
	A=item;B=A
	if isinstance(A,list):
		B=[]
		for C in A:B.append(fix_json_keys(C))
	if isinstance(A,dict):
		B={}
		for(D,E)in A.items():B[to_str(D)]=fix_json_keys(E)
	return B
def canonical_json(obj):return json.dumps(obj,sort_keys=_A)
def extract_jsonpath(value,path):from jsonpath_rw import parse;B=parse(path);A=[A.value for A in B.find(value)];A=A[0]if len(A)==1 else A;return A
def assign_to_path(target:dict,path:str,value:any,delimiter:str='.')->dict:
	E=value;C=delimiter;B=target;A=path.strip(C).split(C)
	if len(A)==1:B[A[0]]=E;return B
	F=C.join(A[:-1]);D=extract_from_jsonpointer_path(B,F,C,auto_create=_A)
	if not isinstance(D,dict):LOG.debug('Unable to find parent (type %s) for path "%s" in object: %s',type(D),path,B);return
	G=int(A[-1])if is_number(A[-1])else A[-1].replace('~1','/');D[G]=E;return B
def extract_from_jsonpointer_path(target,path:str,delimiter:str='/',auto_create=False):
	E=delimiter;A=target;F=path.strip(E).split(E)
	for C in F:
		B=int(C)if is_number(C)else C
		if isinstance(A,list)and not is_number(B):
			if B=='-':continue
			LOG.warning('Attempting to extract non-int index "%s" from list: %s',B,A);return
		D=A[B]if isinstance(A,list)else A.get(B)
		if D is None:
			if not auto_create:return
			A[B]=D={}
		A=D
	return A