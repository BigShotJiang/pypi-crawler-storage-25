_E='linear'
_D='exponential'
_C=True
_B=False
_A=None
import functools,threading,time
from collections import defaultdict
from collections.abc import Callable
from typing import Literal,TypeVar
class ShortCircuitWaitException(Exception):0
def wait_until(fn:Callable[[],bool],wait:float=1.,max_retries:int=10,strategy:Literal[_D,'static',_E]=_D,_retries:int=1,_max_wait:float=240)->bool:
	F=_max_wait;E=max_retries;C=strategy;B=_retries;A=wait;assert B>0
	if E<B:return _B
	try:G=fn()
	except ShortCircuitWaitException:return _B
	except Exception:G=_B
	if G:return _C
	else:
		if A>F:return _B
		time.sleep(A);D=A
		if C==_E:D=A/B*(B+1)
		elif C==_D:D=A*2
		return wait_until(fn,D,E,C,B+1,F)
T=TypeVar('T')
def retry(function:Callable[...,T],retries=3,sleep=1.,sleep_before=0,**D)->T:
	B=sleep_before;A=retries;C=_A
	if B>0:time.sleep(B)
	A=int(A)
	for F in range(0,A+1):
		try:return function(**D)
		except Exception as E:C=E;time.sleep(sleep)
	raise C
def poll_condition(condition,timeout:float=_A,interval:float=.5)->bool:
	C=interval;A=timeout;B=0
	if A is not _A:B=A
	while not condition():
		if A is not _A:
			B-=C
			if B<=0:return _B
		time.sleep(C)
	return _C
def synchronized(lock=_A):
	def A(wrapped):
		A=wrapped
		@functools.wraps(A)
		def B(*B,**C):
			with lock:return A(*B,**C)
		return B
	return A
def sleep_forever():
	while _C:time.sleep(1)
class SynchronizedDefaultDict(defaultdict):
	def __init__(A,*B,**C):super().__init__(*B,**C);A._lock=threading.RLock()
	def fromkeys(A,keys,value=_A):
		with A._lock:return super().fromkeys(keys,value)
	def __getitem__(A,key):
		with A._lock:return super().__getitem__(key)
	def __setitem__(A,key,value):
		with A._lock:super().__setitem__(key,value)
	def __delitem__(A,key):
		with A._lock:super().__delitem__(key)
	def __iter__(A):
		with A._lock:return super().__iter__()
	def __len__(A):
		with A._lock:return super().__len__()
	def __str__(A):
		with A._lock:return super().__str__()
class Once:
	_is_done:bool=_B;_mu:threading.Lock=threading.Lock()
	def do(A,fn:Callable[[],_A]):
		if A._is_done:return
		with A._mu:
			if not A._is_done:
				try:fn()
				finally:A._is_done=_C
def once_func(fn:Callable[...,T])->Callable[...,T|_A]:
	C=Once();B,A=_A,_A
	def D(*C,**D):
		nonlocal B,A
		try:B=fn(*C,**D)
		except Exception as E:A=E;raise
	@functools.wraps(fn)
	def E(*E,**F):
		C.do(lambda:D(*E,**F))
		if A is not _A:raise A
		return B
	return E