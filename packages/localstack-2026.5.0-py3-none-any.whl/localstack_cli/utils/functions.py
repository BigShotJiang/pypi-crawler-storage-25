_B=False
_A=None
import functools,inspect,logging
from collections.abc import Callable
from typing import Any
LOG=logging.getLogger(__name__)
def run_safe(_python_lambda,*B,_default=_A,**A):
	C=A.get('print_error',_B)
	try:return _python_lambda(*B,**A)
	except Exception as D:
		if C:LOG.warning('Unable to execute function: %s',D)
		return _default
def call_safe(func:Callable,args:tuple=_A,kwargs:dict=_A,exception_message:str=_A)->Any|_A:
	C=kwargs;B=args;A=exception_message
	if A is _A:A=f"error calling function {func.__name__}"
	if B is _A:B=()
	if C is _A:C={}
	try:return func(*B,**C)
	except Exception as D:
		if LOG.isEnabledFor(logging.DEBUG):LOG.exception(A)
		else:LOG.warning('%s: %s',A,D)
def prevent_stack_overflow(match_parameters=_B):
	def A(wrapped):
		B=wrapped
		@functools.wraps(B)
		def A(*C,**D):
			def E(frame):
				A=frame
				if A.function!=B.__name__:return _B
				A=A.frame
				if not match_parameters:return _B
				F={A.f_code.co_varnames[B]:A.f_locals[A.f_code.co_varnames[B]]for B in range(A.f_code.co_argcount)};G=inspect.signature(B);E=dict(zip(G.parameters.keys(),C,strict=_B));E.update(D);return F==E
			A=[A[2]for A in inspect.stack(context=1)if E(A)]
			if A:raise RecursionError('(Potential) infinite recursion detected')
			return B(*C,**D)
		return A
	return A
def empty_context_manager():import contextlib as A;return A.nullcontext()