_B=True
_A=None
import datetime,logging,threading
from collections import Counter
from typing import NamedTuple
from localstack_cli import config
try:from localstack_cli.runtime.shutdown import SHUTDOWN_HANDLERS
except ImportError:SHUTDOWN_HANDLERS=_A
from localstack_cli.utils import analytics
try:from localstack_cli.utils.scheduler import Scheduler
except ImportError:Scheduler=_A
LOG=logging.getLogger(__name__)
DEFAULT_FLUSH_INTERVAL_SECS=15
EVENT_NAME='aws_request_agg'
OPTIONAL_FIELDS=['err_type']
class ServiceRequestInfo(NamedTuple):service:str;operation:str;status_code:int;err_type:str|_A=_A
class ServiceRequestAggregator:
	def __init__(A,flush_interval:float=DEFAULT_FLUSH_INTERVAL_SECS):B=False;A.counter=Counter();A._flush_interval=flush_interval;A._flush_scheduler=Scheduler();A._mutex=threading.RLock();A._period_start_time=datetime.datetime.now(datetime.UTC);A._is_started=B;A._is_shutdown=B
	def start(A):
		with A._mutex:
			if A._is_started:return
			A._is_started=_B;A._flush_scheduler.schedule(func=A._flush,period=A._flush_interval,fixed_rate=_B);B=threading.Thread(target=A._flush_scheduler.run,daemon=_B);B.start();SHUTDOWN_HANDLERS.register(A.shutdown)
	def shutdown(A):
		with A._mutex:
			if not A._is_started:return
			if A._is_shutdown:return
			A._is_shutdown=_B;A._flush();A._flush_scheduler.close();SHUTDOWN_HANDLERS.unregister(A.shutdown)
	def add_request(A,request_info:ServiceRequestInfo):
		if config.DISABLE_EVENTS:return
		if A._is_shutdown:return
		with A._mutex:A.counter[request_info]+=1
	def _flush(A):
		with A._mutex:
			try:
				if len(A.counter)==0:return
				B=A._create_analytics_payload();A._emit_payload(B);A.counter.clear()
			finally:A._period_start_time=datetime.datetime.now(datetime.UTC)
	def _create_analytics_payload(A):B='+00:00';return{'period_start_time':A._period_start_time.isoformat().replace(B,'Z'),'period_end_time':datetime.datetime.now(datetime.UTC).isoformat().replace(B,'Z'),'api_calls':A._aggregate_api_calls(A.counter)}
	def _aggregate_api_calls(F,counter)->list:
		B=[]
		for(D,E)in counter.items():
			A=D._asdict()
			for C in OPTIONAL_FIELDS:
				if A.get(C)is _A:del A[C]
			A['count']=E;B.append(A)
		return B
	def _emit_payload(A,analytics_payload:dict):analytics.log.event(EVENT_NAME,analytics_payload)