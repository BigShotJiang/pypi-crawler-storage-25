import logging
from typing import Any
import requests
from localstack_cli import config,constants
from localstack_cli.utils.http import get_proxies
from localstack_cli.utils.time import now
from.events import Event,EventMetadata
from.metadata import ClientMetadata,get_session_id
LOG=logging.getLogger(__name__)
class SessionResponse:
	response:dict[str,Any];status:int
	def __init__(A,response:dict[str,Any],status:int=200):A.response=response;A.status=status
	def track_events(A)->bool:return A.response.get('track_events')
	def __repr__(A):return f"SessionResponse({A.status},{A.response!r})"
class AnalyticsClient:
	api:str
	def __init__(A,api=None):A.api=(api or constants.ANALYTICS_API).rstrip('/');A.debug=config.DEBUG_ANALYTICS;A.endpoint_session=A.api+'/session';A.endpoint_events=A.api+'/events';A.localstack_session_id=get_session_id();A.session=requests.Session()
	def close(A):A.session.close()
	def start_session(B,metadata:ClientMetadata)->SessionResponse:
		C=Event('session',EventMetadata(B.localstack_session_id,str(now())),payload=metadata);A=B.session.post(B.endpoint_session,headers=B._create_headers(),json=C.asdict(),proxies=get_proxies())
		if A.ok or A.status_code==403:return SessionResponse(A.json(),status=A.status_code)
		raise ValueError(f"error during session initiation with analytics backend. code: {A.status_code}")
	def append_events(A,events:list[Event]):
		E=events;B=A.endpoint_events
		if not E:return
		C=[]
		for F in E:
			try:C.append(F.asdict())
			except Exception:
				if A.debug:LOG.exception('error while recording event %s',F)
		G=A._create_headers()
		if A.debug:LOG.debug('posting to %s events %s',B,C)
		D=A.session.post(B,json={'events':C},headers=G,proxies=get_proxies())
		if A.debug:LOG.debug('response from %s was: %s %s',B,D.status_code,D.text)
		return D
	def _create_headers(A)->dict[str,str]:return{'User-Agent':'localstack/'+constants.VERSION,'Localstack-Session-ID':A.localstack_session_id}