import datetime,functools
from multiprocessing import Process
import click
from localstack_cli import config
from.client import AnalyticsClient
from.events import Event,EventMetadata
from.metadata import get_session_id
from.publisher import AnalyticsClientPublisher
ANALYTICS_API_RESPONSE_TIMEOUT_SECS=.5
def _publish_cmd_as_analytics_event(command_name:str,params:list[str]):A=Event(name='cli_cmd',payload={'cmd':command_name,'params':params},metadata=EventMetadata(session_id=get_session_id(),client_time=str(datetime.datetime.now())));B=AnalyticsClientPublisher(AnalyticsClient());B.publish([A])
def _get_parent_commands(ctx:click.Context)->list[str]:
	B=[];A=ctx.parent
	while A is not None:B.insert(0,A.command.name);A=A.parent
	return B
def publish_invocation(fn):
	@functools.wraps(fn)
	def A(*C,**D):
		if config.DISABLE_EVENTS:return fn(*C,**D)
		A=click.get_current_context();E=' '.join(_get_parent_commands(A)+[A.command.name]);B=Process(target=_publish_cmd_as_analytics_event,args=(E,[A for(A,B)in A.params.items()if B]));B.start();B.join(ANALYTICS_API_RESPONSE_TIMEOUT_SECS);B.terminate();return fn(*C,**D)
	return A