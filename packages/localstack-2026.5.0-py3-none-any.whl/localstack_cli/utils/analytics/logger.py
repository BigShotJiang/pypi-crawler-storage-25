_A=None
import datetime,hashlib
from localstack_cli.utils.strings import to_bytes
from.events import Event,EventHandler,EventMetadata,EventPayload
from.metadata import get_session_id
def get_hash(value)->str:B=10;A=hashlib.sha1();A.update(to_bytes(str(value)));C=A.hexdigest();return C[:B]
class EventLogger:
	def __init__(A,handler:EventHandler,session_id:str=_A):A.handler=handler;A.session_id=session_id or get_session_id()
	@staticmethod
	def hash(value):return get_hash(value)
	def event(C,event:str,payload:EventPayload=_A,**B):
		A=payload
		if B:
			if A is _A:A=B
			else:raise ValueError('either use payload or set kwargs, not both')
		C._log(event,payload=A)
	def _log(A,event:str,payload:EventPayload=_A):A.handler.handle(Event(name=event,metadata=A._metadata(),payload=payload))
	def _metadata(A)->EventMetadata:return EventMetadata(session_id=A.session_id,client_time=str(datetime.datetime.now()))