_C='unknown'
_B='machine.json'
_A=None
import dataclasses,logging,os,platform
from localstack_cli import config
from localstack_cli.constants import VERSION
from localstack_cli.runtime import get_current_runtime,hooks
from localstack_cli.utils.bootstrap import Container
from localstack_cli.utils.files import rm_rf
from localstack_cli.utils.functions import call_safe
from localstack_cli.utils.json import FileMappedDocument
from localstack_cli.utils.objects import singleton_factory
from localstack_cli.utils.strings import long_uid,md5
LOG=logging.getLogger(__name__)
_PHYSICAL_ID_SALT='ls'
@dataclasses.dataclass
class ClientMetadata:
	session_id:str;machine_id:str;api_key:str;system:str;version:str;is_ci:bool;is_docker:bool;is_testing:bool;product:str;edition:str
	def __repr__(D):
		C='api_key';B=dataclasses.asdict(D);A=B.get(C)
		if A:A='*'*len(A)
		B[C]=A;return f"ClientMetadata({B})"
def get_version_string()->str:
	A=config.LOCALSTACK_BUILD_GIT_HASH
	if A:return f"{VERSION}:{A}"
	else:return VERSION
def read_client_metadata()->ClientMetadata:return ClientMetadata(session_id=get_session_id(),machine_id=get_machine_id(),api_key=get_api_key_or_auth_token()or'',system=get_system(),version=get_version_string(),is_ci=os.getenv('CI')is not _A,is_docker=config.is_in_docker,is_testing=config.is_local_test_mode(),product=get_localstack_product(),edition=os.getenv('LOCALSTACK_TELEMETRY_EDITION')or get_localstack_edition())
@singleton_factory
def get_session_id()->str:return _generate_session_id()
@singleton_factory
def get_client_metadata()->ClientMetadata:
	A=read_client_metadata()
	if config.DEBUG_ANALYTICS:LOG.info('resolved client metadata: %s',A)
	return A
@singleton_factory
def get_machine_id()->str:
	C='machine_id';B=os.path.join(config.dirs.cache,_B)
	try:A=FileMappedDocument(B)
	except Exception:
		call_safe(rm_rf,args=(B,))
		try:A=FileMappedDocument(B)
		except Exception:return _generate_machine_id()
	if C not in A:A[C]=_generate_machine_id();call_safe(A.save)
	return A[C]
def get_localstack_edition()->str:B='-version';A=next((A for A in os.listdir(config.dirs.static_libs)if A.startswith('.')and A.endswith(B)),_A);return A.removesuffix(B).removeprefix('.')if A else _C
def get_localstack_product()->str:
	A=_A
	if get_current_runtime is not _A:
		try:A=get_current_runtime().components.name
		except(ValueError,AttributeError):pass
	return os.getenv('LOCALSTACK_TELEMETRY_PRODUCT')or A or _C
def is_license_activated()->bool:
	A=False
	try:from localstack_cli.pro.core import config
	except ImportError:return A
	try:from localstack_cli.pro.core.bootstrap import licensingv2 as B;return B.get_licensed_environment().activated
	except Exception:LOG.error('Could not determine license activation status',exc_info=LOG.isEnabledFor(logging.DEBUG));return A
def _generate_session_id()->str:return long_uid()
def _anonymize_physical_id(physical_id:str)->str:A=md5(_PHYSICAL_ID_SALT+physical_id);return A[:12]
def _generate_machine_id()->str:
	D='/etc/machine-id'
	try:
		from localstack_cli.utils.docker_utils import DOCKER_CLIENT as A;B=A.get_system_id()
		if B==A.get_system_id():return f"dkr_{_anonymize_physical_id(B)}"
	except Exception:pass
	if config.is_in_docker:return f"gen_{long_uid()[:12]}"
	try:
		if os.path.exists(D):
			with open(D)as E:
				C=str(E.read()).strip()
				if C:return f"sys_{_anonymize_physical_id(C)}"
	except Exception:pass
	return f"gen_{long_uid()[:12]}"
def get_api_key_or_auth_token()->str|_A:
	C='\'" ';A=os.environ.get('LOCALSTACK_AUTH_TOKEN','').strip(C)
	if A:return A
	B=os.environ.get('LOCALSTACK_API_KEY','').strip(C)
	if B:return B
@singleton_factory
def get_system()->str:
	B='OSType'
	try:
		from localstack_cli.utils.docker_utils import DOCKER_CLIENT as C;A=C.get_system_info()
		if A.get(B):return A.get(B).lower()
	except Exception:pass
	if config.is_in_docker:return'docker'
	return platform.system().lower()
@hooks.prepare_host()
def publish_invocation_metadata():get_machine_id()
@hooks.configure_localstack_container()
def set_analytics_header(container:Container):
	from localstack_cli.utils.container_utils.container_client import BindMount as B;A=os.path.join(config.dirs.cache,_B)
	if os.path.isfile(A):C=os.path.join(config.dirs.for_container().cache,_B);container.config.volumes.add(B(A,C,read_only=True))