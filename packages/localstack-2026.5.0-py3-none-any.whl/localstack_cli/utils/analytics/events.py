import abc,dataclasses
from typing import Any
EventPayload=dict[str,Any]|Any
@dataclasses.dataclass
class EventMetadata:session_id:str;client_time:str
@dataclasses.dataclass
class Event:
	name:str;metadata:EventMetadata=None;payload:EventPayload=None
	def asdict(A):return dataclasses.asdict(A)
class EventHandler(abc.ABC):
	def handle(A,event:Event):raise NotImplementedError