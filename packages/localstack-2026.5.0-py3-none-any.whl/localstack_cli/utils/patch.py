_C='__getattr__'
_B=True
_A=None
import functools,inspect,types
from collections.abc import Callable
from typing import Any
def get_defining_object(method):
	A=method
	if inspect.ismethod(A):return A.__self__
	if inspect.isfunction(A):
		C=A.__qualname__.split('.<locals>',1)[0].rsplit('.',1)[0]
		try:B=getattr(inspect.getmodule(A),C)
		except AttributeError:B=A.__globals__.get(C)
		if isinstance(B,type):return B
	return inspect.getmodule(A)
def to_metadata_string(obj:Any)->str:
	A=obj
	if inspect.isclass(A):return f"class({A.__module__}:{A.__name__})"
	if inspect.ismodule(A):return f"module({A.__name__})"
	if inspect.ismethod(A):return f"method({A.__module__}:{A.__qualname__})"
	if inspect.isfunction(A):return f"function({A.__module__}:{A.__qualname__})"
	if isinstance(A,object):return f"object({A.__module__}:{A.__class__.__name__})"
	return str(A)
def create_patch_proxy(target:Callable,new:Callable):
	A=target
	@functools.wraps(A)
	def B(*B,**D):
		if C:B=B[1:]
		return new(A,*B,**D)
	B.__subject__=new;C=inspect.ismethod(A)
	if C:B=types.MethodType(B,A.__self__)
	return B
class Patch:
	applied_patches:list['Patch']=[];obj:Any;name:str;new:Any
	def __init__(A,obj:Any,name:str,new:Any)->_A:
		super().__init__();A.obj=obj;A.name=name
		try:A.old=getattr(A.obj,name)
		except AttributeError:A.old=_A
		A.new=new;A.is_applied=False
	def apply(A):
		if A.is_applied:return
		if A.old and A.name==_C:raise Exception("You can't patch class types implementing __getattr__")
		if not A.old and A.name!=_C:raise AttributeError(f"`{A.obj.__name__}` object has no attribute `{A.name}`")
		setattr(A.obj,A.name,A.new);Patch.applied_patches.append(A);A.is_applied=_B
	def undo(A):
		if not A.is_applied:return
		setattr(A.obj,A.name,A.old)if A.old else delattr(A.obj,A.name);Patch.applied_patches.remove(A);A.is_applied=False
	def __enter__(A):A.apply();return A
	def __exit__(A,exc_type,exc_val,exc_tb):A.undo();return A
	@staticmethod
	def extend_class(target:type,fn:Callable):
		A=target
		def B(obj,name):
			if name!=fn.__name__:raise AttributeError(f"`{A.__name__}` object has no attribute `{name}`")
			return functools.partial(fn,obj)
		return Patch(A,_C,B)
	@staticmethod
	def function(target:Callable,fn:Callable,pass_target:bool=_B):
		C=target;A=fn;B=get_defining_object(C);D=C.__name__;F=not inspect.isclass(B)and not inspect.ismodule(B)
		if F:A.__name__=D;A=types.MethodType(A,B)
		if pass_target:E=create_patch_proxy(C,A)
		else:E=A
		return Patch(B,D,E)
	def __str__(A):
		try:B=A.new.__subject__
		except AttributeError:B=A.new
		C=A.old;return f"Patch({to_metadata_string(C)} -> {to_metadata_string(B)}, applied={A.is_applied})"
class Patches:
	patches:list[Patch]
	def __init__(A,patches:list[Patch]=_A)->_A:
		B=patches;super().__init__();A.patches=[]
		if B:A.patches.extend(B)
	def apply(A):
		for B in A.patches:B.apply()
	def undo(A):
		for B in A.patches:B.undo()
	def __enter__(A):A.apply();return A
	def __exit__(A,exc_type,exc_val,exc_tb):A.undo()
	def add(A,patch:Patch):A.patches.append(patch)
	def function(A,target:Callable,fn:Callable,pass_target:bool=_B):A.add(Patch.function(target,fn,pass_target))
def patch(target,pass_target=_B):
	B=target
	@functools.wraps(B)
	def A(fn):A=fn;A.patch=Patch.extend_class(B,A)if inspect.isclass(B)else Patch.function(B,A,pass_target=pass_target);A.patch.apply();return A
	return A