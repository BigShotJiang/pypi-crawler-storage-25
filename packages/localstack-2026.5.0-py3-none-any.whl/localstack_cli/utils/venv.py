import io,os,sys
from functools import cached_property
from pathlib import Path
from typing import Union
class VirtualEnvironment:
	def __init__(A,venv_dir:Union[str,os.PathLike]):A._venv_dir=venv_dir
	def create(A)->None:A.venv_dir.mkdir(parents=True,exist_ok=True);from venv import main;main([str(A.venv_dir)])
	@property
	def exists(self)->bool:
		A=False
		try:return True if self.site_dir else A
		except FileNotFoundError:return A
	@cached_property
	def venv_dir(self)->Path:return Path(self._venv_dir).absolute()
	@cached_property
	def site_dir(self)->Path:
		A=self.venv_dir
		if not A.exists():raise FileNotFoundError(f"expected venv directory to exist at {A}")
		if not A.is_dir():raise NotADirectoryError(f"expected {A} to be a directory")
		B=list(A.glob('lib/python*/site-packages'))
		if not B:raise FileNotFoundError(f"could not find site-packages directory in {A}")
		if len(B)>1:raise FileNotFoundError(f"multiple python versions found in {A}: {B}")
		return B[0]
	def inject_to_sys_path(B)->None:
		A=str(B.site_dir)
		if A and A not in sys.path:sys.path.append(A)
	def add_pth(D,name,path:Union[str,os.PathLike,'VirtualEnvironment'])->None:
		A=path;B=D.site_dir/f"{name}.pth"
		if isinstance(A,VirtualEnvironment):A=A.site_dir
		C=io.text_encoding(str(A))+'\n'
		if B.exists()and C in B.read_text():return
		with open(B,'a')as E:E.write(C)