_A='windows'
import platform
from functools import lru_cache
def is_mac_os()->bool:return'darwin'==platform.system().lower()
def is_linux()->bool:return'linux'==platform.system().lower()
def is_windows()->bool:return _A==platform.system().lower()
@lru_cache
def is_debian()->bool:from localstack_cli.utils.files import load_file as A;return'Debian'in A('/etc/issue','')
@lru_cache
def is_redhat()->bool:from localstack_cli.utils.files import load_file as A;return'rhel'in A('/etc/os-release','')
class Arch(str):amd64='amd64';arm64='arm64'
def standardized_arch(arch:str):
	A=arch
	if A=='x86_64':return Arch.amd64
	if A=='aarch64':return Arch.arm64
	return A
def get_arch()->str:A=platform.machine();return standardized_arch(A)
def is_arm_compatible()->bool:return get_arch()==Arch.arm64
def get_os()->str:
	if is_mac_os():return'osx'
	if is_linux():return'linux'
	if is_windows():return _A
	raise ValueError('Unable to determine local operating system')
def in_docker()->bool:from localstack_cli import config as A;return A.in_docker()