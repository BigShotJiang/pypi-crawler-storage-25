_B=False
_A=None
import time
from datetime import date,datetime,timezone,tzinfo
from zoneinfo import ZoneInfo
TIMESTAMP_FORMAT='%Y-%m-%dT%H:%M:%S'
TIMESTAMP_FORMAT_TZ='%Y-%m-%dT%H:%M:%SZ'
TIMESTAMP_FORMAT_MICROS='%Y-%m-%dT%H:%M:%S.%fZ'
TIMESTAMP_READABLE_FORMAT='%d/%b/%Y:%H:%M:%S %z'
def isoformat_milliseconds(t)->str:
	try:return t.isoformat(timespec='milliseconds')
	except TypeError:return t.isoformat()[:-3]
def timestamp(time=_A,format:str=TIMESTAMP_FORMAT)->str:
	A=time
	if not A:A=datetime.utcnow()
	if isinstance(A,(int,float)):A=datetime.fromtimestamp(A)
	return A.strftime(format)
def timestamp_millis(time=_A)->str:A=timestamp(time=time,format=TIMESTAMP_FORMAT_MICROS);return A[:-4]+A[-1]
def iso1806_to_epoch(t:str)->float:return datetime.fromisoformat(t).timestamp()
def epoch_to_iso1806(ts:int)->str:return datetime.utcfromtimestamp(ts).isoformat()
def epoch_timestamp()->float:return time.time()
def parse_timestamp(ts_str:str)->datetime:
	B=ts_str
	for C in[TIMESTAMP_FORMAT,TIMESTAMP_FORMAT_TZ,TIMESTAMP_FORMAT_MICROS,TIMESTAMP_READABLE_FORMAT]:
		try:
			A=datetime.strptime(B,C)
			if A.tzinfo is _A:A=A.replace(tzinfo=ZoneInfo('UTC'))
			return A
		except ValueError:pass
	raise Exception(f"Unable to parse timestamp string with any known formats: {B}")
def now(millis:bool=_B,tz:tzinfo|_A=_A)->int:return mktime(datetime.now(tz=tz),millis=millis)
def now_utc(millis:bool=_B)->int:return now(millis,timezone.utc)
def today_no_time()->int:return mktime(datetime.combine(date.today(),datetime.min.time()))
def mktime(ts:datetime,millis:bool=_B)->int:
	if millis:return int(ts.timestamp()*1000)
	return int(ts.timestamp())