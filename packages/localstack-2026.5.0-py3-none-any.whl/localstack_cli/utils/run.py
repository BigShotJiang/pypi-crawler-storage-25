_F='unicode-escape'
_E='decode'
_D='stdout'
_C=False
_B=True
_A=None
import io,logging,os,re,select,subprocess,sys,threading,time
from collections.abc import Callable
from functools import lru_cache
from queue import Queue
from typing import Any,AnyStr
from localstack_cli import config
from localstack_cli.utils.platform import is_linux,is_mac_os,is_windows
from.sync import retry
from.threads import FuncThread,start_worker_thread
LOG=logging.getLogger(__name__)
def run(cmd:str|list[str],print_error=_B,asynchronous=_C,stdin=_C,stderr=subprocess.STDOUT,outfile=_A,env_vars:dict[AnyStr,AnyStr]|_A=_A,inherit_cwd=_C,inherit_env=_B,tty=_C,shell=_B,cwd:str=_A)->str|subprocess.Popen:
	L=env_vars;K=asynchronous;I=tty;H=outfile;G=stderr;F=stdin;D=shell;C=cwd;A=cmd;LOG.debug('Executing command: %s',A);B=os.environ.copy()if inherit_env else{}
	if L:B.update(L)
	B={A:to_str(str(B))for(A,B)in B.items()}
	if isinstance(A,list):D=_C
	if I:K=_B;F=_B
	try:
		if inherit_cwd and not C:C=os.getcwd()
		if not K:
			if F:return subprocess.check_output(A,shell=D,stderr=G,env=B,stdin=subprocess.PIPE,cwd=C)
			R=subprocess.check_output(A,shell=D,stderr=G,env=B,cwd=C);return R.decode(config.DEFAULT_ENCODING)
		M=subprocess.PIPE if F else _A;N=open(H,'ab')if isinstance(H,str)else H;O=G
		if I:import pty;E,S=pty.openpty();M=S;N=O=_A
		P={}
		if is_linux()or is_mac_os():P['start_new_session']=_B
		Q=subprocess.Popen(A,shell=D,stdin=M,bufsize=-1,stderr=O,stdout=N,env=B,cwd=C,**P)
		if I:
			def T(*D):
				while Q.poll()is _A:
					A,F,G=select.select([sys.stdin,E],[],[])
					if sys.stdin in A:C=os.read(sys.stdin.fileno(),10240);os.write(E,C)
					elif E in A:
						B=os.read(E,10240)
						if B:os.write(sys.stdout.fileno(),B)
			FuncThread(T,name='pipe-streams').start()
		return Q
	except subprocess.CalledProcessError as J:
		if print_error:print(f"ERROR: '{A}': exit code {J.returncode}; output: {J.output}");sys.stdout.flush()
		raise J
def run_for_max_seconds(max_secs,_function,*D,**E):
	B=max_secs
	def F(*F):
		try:A=_function(*D,**E)
		except Exception as B:A=B
		A=_B if A is _A else A;C.put(A);return A
	G=time.time();C=Queue();start_worker_thread(F)
	for H in range(B*2):
		A=_A
		try:A=C.get_nowait()
		except Exception:pass
		if A is not _A:
			if isinstance(A,Exception):raise A
			return A
		if time.time()-G>=B:return
		time.sleep(.5)
def run_interactive(command:list[str]):subprocess.check_call(command)
def is_command_available(cmd:str)->bool:
	try:run(['which',cmd],print_error=_C);return _B
	except Exception:return _C
def kill_process_tree(parent_pid):
	A=parent_pid;import psutil as C;A=getattr(A,'pid',_A)or A;B=C.Process(A)
	for D in B.children(recursive=_B):
		try:D.kill()
		except Exception:pass
	B.kill()
def wait_for_process_to_be_killed(pid:int,sleep:float=_A,retries:int=_A):
	import psutil as A
	def B():assert not A.pid_exists(pid)
	retry(B,sleep=sleep,retries=retries)
def is_root()->bool:return get_os_user()=='root'
@lru_cache
def get_os_user()->str:return run('whoami').strip()
def to_str(obj:str|bytes,errors='strict'):A=obj;return A.decode(config.DEFAULT_ENCODING,errors)if isinstance(A,bytes)else A
class ShellCommandThread(FuncThread):
	def __init__(A,cmd:str|list[str],params:Any=_A,outfile:str|int=_A,env_vars:dict[str,str]=_A,stdin:bool=_C,auto_restart:bool=_C,quiet:bool=_B,inherit_cwd:bool=_C,inherit_env:bool=_B,log_listener:Callable=_A,stop_listener:Callable=_A,strip_color:bool=_C,name:str|_A=_A,cwd:str|_A=_A):C=env_vars;B=params;B=B if B is not _A else{};C=C if C is not _A else{};A.stopped=_C;A.cmd=cmd;A.process=_A;A.outfile=outfile;A.stdin=stdin;A.env_vars=C;A.inherit_cwd=inherit_cwd;A.inherit_env=inherit_env;A.auto_restart=auto_restart;A.log_listener=log_listener;A.stop_listener=stop_listener;A.strip_color=strip_color;A.started=threading.Event();A.cwd=cwd;FuncThread.__init__(A,A.run_cmd,B,quiet=quiet,name=name or'shell-cmd-thread')
	def run_cmd(A,params):
		while _B:
			A.do_run_cmd()
			try:from localstack_cli.runtime import events as C;B=C.infra_stopping.is_set()
			except ImportError:B=_C
			if B or not A.auto_restart or not A.process or A.process.returncode==0:return A.process.returncode if A.process else _A
			LOG.info('Restarting process (received exit code %s): %s',A.process.returncode,A.cmd)
	def do_run_cmd(A):
		def G(line):
			B=line;B=to_str(B or'')
			if A.strip_color:B=re.sub('\\x1b(\\[.*?[@-~]|\\].*?(\\x07|\\x1b\\\\))','',B)
			return f"{B.strip()}\r\n"
		def H(line):return'(Press CTRL+C to quit)'in line
		C=A.outfile or os.devnull
		if A.log_listener and C==os.devnull:C=subprocess.PIPE
		try:
			A.process=run(A.cmd,asynchronous=_B,stdin=A.stdin,outfile=C,env_vars=A.env_vars,inherit_cwd=A.inherit_cwd,inherit_env=A.inherit_env,cwd=A.cwd);A.started.set()
			if C:
				if C==subprocess.PIPE:
					I=(A.process.stdout,sys.stdout),(A.process.stderr,sys.stderr)
					for(D,E)in I:
						if not D:continue
						for B in iter(D.readline,_A):
							if B in[_A,'',b'']:break
							if not(B and B.strip())and A.is_killed():break
							B=G(B)
							if H(B):continue
							if A.log_listener:A.log_listener(B,stream=D)
							if A.outfile not in[_A,os.devnull]:E.write(B);E.flush()
				if A.process:A.process.wait()
			else:A.process.communicate()
		except Exception as F:
			A.result_future.set_exception(F)
			if A.process and not A.quiet:LOG.warning('Shell command error "%s": %s',F,A.cmd)
		if A.process and not A.quiet and A.process.returncode!=0:LOG.warning('Shell command exit code "%s": %s',A.process.returncode,A.cmd)
	def is_killed(A):
		try:from localstack_cli.runtime import events as C;B=C.infra_stopping.is_set()
		except ImportError:B=_C
		if not A.process:return _B
		if B:return _B
		import psutil as D;return not D.pid_exists(A.process.pid)
	def stop(A,quiet=_C):
		C=quiet
		if A.stopped:return
		if not A.process:LOG.warning("No process found for command '%s'",A.cmd);return
		D=A.process.pid
		try:kill_process_tree(D);A.process=_A
		except Exception as B:
			if not C:LOG.warning('Unable to kill process with pid %s: %s',D,B)
		try:A.stop_listener and A.stop_listener(A)
		except Exception as B:
			if not C:LOG.warning('Unable to run stop handler for shell command thread %s: %s',A,B)
		A.stopped=_B
class CaptureOutput:
	orig_stdout=sys.stdout;orig_stderr=sys.stderr;orig___stdout=sys.__stdout__;orig___stderr=sys.__stderr__;CONTEXTS_BY_THREAD={}
	class LogStreamIO(io.StringIO):
		def write(A,s):
			if isinstance(s,str)and hasattr(s,_E):s=s.decode(_F)
			return super(CaptureOutput.LogStreamIO,A).write(s)
	def __init__(A):A._stdout=A.LogStreamIO();A._stderr=A.LogStreamIO()
	def __enter__(A):
		D='stderr';from werkzeug.local import LocalProxy as B;C=A._ident()
		if C not in A.CONTEXTS_BY_THREAD:A.CONTEXTS_BY_THREAD[C]=A;A._set(B(A._proxy(sys.stdout,_D)),B(A._proxy(sys.stderr,D)),B(A._proxy(sys.__stdout__,_D)),B(A._proxy(sys.__stderr__,D)))
		return A
	def __exit__(A,type,value,traceback):
		C=A._ident();B=A.CONTEXTS_BY_THREAD.pop(C,_A)
		if not A.CONTEXTS_BY_THREAD:A._set(A.orig_stdout,A.orig_stderr,A.orig___stdout,A.orig___stderr)
		B._stdout.flush();B._stderr.flush();D=B._stdout.getvalue();E=B._stderr.getvalue();B._stdout.close();B._stderr.close();B._stdout=D;B._stderr=E
	def _set(A,out,err,__out,__err):sys.stdout,sys.stderr,sys.__stdout__,sys.__stderr__=out,err,__out,__err
	def _proxy(B,original_stream,type):
		def A():
			C=B._ident();A=B.CONTEXTS_BY_THREAD.get(C)
			if A:return A._stdout if type==_D else A._stderr
			return original_stream
		return A
	def _ident(A):return threading.current_thread().ident
	def stdout(A):return A._stream_value(A._stdout)
	def stderr(A):return A._stream_value(A._stderr)
	def _stream_value(B,stream):A=stream;return A.getvalue()if hasattr(A,'getvalue')else A
class CaptureOutputProcess:
	class LogStreamIO(io.StringIO):
		def write(A,s):
			if isinstance(s,str)and hasattr(s,_E):s=s.decode(_F)
			return super(CaptureOutputProcess.LogStreamIO,A).write(s)
	def __init__(A):A.orig_stdout=sys.stdout;A._stdout=A.LogStreamIO();A.orig_stderr=sys.stderr;A._stderr=A.LogStreamIO();A.stdout_value=_A;A.stderr_value=_A
	def __enter__(A):sys.stdout=A._stdout;sys.stderr=A._stderr;return A
	def __exit__(A,type,value,traceback):A._stdout.flush();A._stderr.flush();A.stdout_value=A._stdout.getvalue();A.stderr_value=A._stderr.getvalue();A._stdout.close();A._stderr.close();sys.stdout=A.orig_stdout;sys.stderr=A.orig_stderr
	def stdout(A):return A.stdout_value
	def stderr(A):return A.stderr_value