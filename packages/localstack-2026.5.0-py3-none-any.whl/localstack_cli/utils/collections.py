_C=True
_B=False
_A=None
import logging,re
from collections.abc import Callable,Generator,Iterable,Iterator,Mapping,Sized
from typing import Any,Optional,TypedDict,TypeVar,Union,cast,get_args,get_origin
import cachetools
LOG=logging.getLogger(__name__)
DEFAULT_REGEX_LIST_ITEM='[\\w-]+'
_E=TypeVar('_E')
class AccessTrackingDict(dict):
	def __init__(A,wrapped,callback:Callable[[dict,str,list,dict],Any]=_A):super().__init__(wrapped);A.callback=callback
	def __setitem__(A,key,value):B=value;A.callback and A.callback(A,'__setitem__',[key,B],{});return super().__setitem__(key,B)
class DelSafeDict(dict):
	def __delitem__(A,key,*B,**C):A[key]=_A
class ImmutableList(tuple):0
class HashableList(ImmutableList):
	def __hash__(A):return sum(hash(A)for A in A)
class ImmutableDict(Mapping):
	def __init__(A,seq=_A,**B):A._dict=dict(seq,**B)
	def __len__(A)->int:return A._dict.__len__()
	def __iter__(A)->Iterator:return A._dict.__iter__()
	def __getitem__(A,key):return A._dict.__getitem__(key)
	def __eq__(B,other):A=other;return B._dict.__eq__(A._dict if isinstance(A,ImmutableDict)else A)
	def __str__(A):return A._dict.__str__()
class HashableJsonDict(ImmutableDict):
	def __hash__(A):from localstack_cli.utils.json import canonical_json as B;return hash(B(A._dict))
class PaginatedList(list[_E]):
	DEFAULT_PAGE_SIZE=50
	def get_page(E,token_generator:Callable[[_E],str],next_token:str=_A,page_size:int=_A,filter_function:Callable[[_E],bool]=_A)->tuple[list[_E],str|_A]:
		G=filter_function;F=token_generator;C=next_token;B=page_size
		if G is not _A:A=list(filter(G,E))
		else:A=E
		if B is _A:B=E.DEFAULT_PAGE_SIZE
		if len(A)<=B and C is _A:return A,_A
		D=0
		try:H=next(A for A in A if F(A)==C);D=A.index(H)
		except StopIteration:pass
		if D+B<len(A):C=F(A[D+B])
		else:C=_A
		return A[D:D+B],C
class CustomExpiryTTLCache(cachetools.TTLCache):
	def set_expiry(A,key:Any,ttl:float|int)->float:
		with A.timer as B:A._TTLCache__getlink(key).expires=C=B+ttl;return C
def get_safe(dictionary,path,default_value=_A):
	F=default_value;D=path;C=dictionary
	if not isinstance(C,dict)or len(C)==0:return F
	E=D if isinstance(D,list)else D.split('.')
	if len(E)==0 or E[0]!='$':raise AttributeError('Safe navigation must begin with a root node "$"')
	A=C
	for B in E:
		if B=='$':continue
		if re.compile('^\\d+$').search(str(B)):B=int(B)
		if isinstance(A,dict)and B in A:A=A[B]
		elif isinstance(A,list)and B<len(A):A=A[B]
		else:A=_A
	return A or F
def set_safe_mutable(dictionary,path,value):
	D=path;C=dictionary
	if not isinstance(C,dict):raise AttributeError('"dictionary" must be of type "dict"')
	E=D if isinstance(D,list)else D.split('.');F=len(E)
	if F==0 or E[0]!='$':raise AttributeError('Dict navigation must begin with a root node "$"')
	A=C
	for G in range(F):
		B=E[G]
		if B=='$':continue
		if G<F-1:
			if B not in A:A[B]={}
			if not isinstance(A,dict):raise RuntimeError('Error while deeply setting a dict value. Supplied path is not of type "dict"')
		else:A[B]=value
		A=A[B]
	return C
def pick_attributes(dictionary,paths):
	A={}
	for B in paths:
		C=get_safe(dictionary,B)
		if C is not _A:set_safe_mutable(A,B,C)
	return A
def select_attributes(obj:dict,attributes:list[str])->dict:A=attributes;A=A if is_list_or_tuple(A)else[A];return{B:C for(B,C)in obj.items()if B in A}
def remove_attributes(obj:dict,attributes:list[str],recursive:bool=_B)->dict:
	B=obj;A=attributes;from localstack_cli.utils.objects import recurse_object as C
	if recursive:
		def D(o,**B):
			if isinstance(o,dict):remove_attributes(o,A)
			return o
		return C(B,D)
	A=ensure_list(A)
	for E in A:B.pop(E,_A)
	return B
def rename_attributes(obj:dict,old_to_new_attributes:dict[str,str],in_place:bool=_B)->dict:
	A=obj
	if not in_place:A=dict(A)
	for(B,C)in old_to_new_attributes.items():
		if B in A:A[C]=A.pop(B)
	return A
def is_list_or_tuple(obj)->bool:return isinstance(obj,(list,tuple))
def ensure_list(obj:Any,wrap_none=_B)->list|_A:
	A=obj
	if A is _A and not wrap_none:return A
	return A if isinstance(A,list)else[A]
def to_unique_items_list(inputs,comparator=_A):
	B=comparator
	def D(item):
		for C in A:
			if B:
				D=B(item,C)
				if D is _C or str(D)=='0':return _C
			elif item==C:return _C
	A=[]
	for C in inputs:
		if not D(C):A.append(C)
	return A
def merge_recursive(source,destination,none_values=_A,overwrite=_B):
	E=overwrite;B=none_values;A=destination
	if B is _A:B=[_A]
	for(C,D)in source.items():
		if isinstance(D,dict):F=A.setdefault(C,{});merge_recursive(D,F,none_values=B,overwrite=E)
		else:
			from requests.models import CaseInsensitiveDict as G
			if not isinstance(A,(dict,G)):LOG.warning('Destination for merging %s=%s is not dict: %s (%s)',C,D,A,type(A))
			if E or A.get(C)in B:A[C]=D
	return A
def merge_dicts(*E,**B):
	D='default';C={}
	for A in E:
		if A is _A and D in B:return B[D]
		if A:C.update(A)
	return C
def remove_none_values_from_dict(dict:dict)->dict:return{B:A for(B,A)in dict.items()if A is not _A}
def last_index_of(array,value):
	B=array;A=value;E=-1
	for C in reversed(range(len(B))):
		D=B[C]
		if D==A or callable(A)and A(D):return C
	return E
def is_sub_dict(child_dict:dict,parent_dict:dict)->bool:return all(parent_dict.get(A)==B for(A,B)in child_dict.items())
def items_equivalent(list1,list2,comparator):
	B=list2;A=list1
	def C(item):
		for A in B:
			if comparator(item,A):return _C
	if len(A)!=len(B):return _B
	for D in A:
		if not C(D):return _B
	return _C
def is_none_or_empty(obj:str|_A|list|_A)->bool:A=obj;return A is _A or isinstance(A,str)and A.strip()==''or isinstance(A,Sized)and len(A)==0
def select_from_typed_dict(typed_dict:type[TypedDict],obj:dict,filter:bool=_B)->dict:
	B=typed_dict;A=select_attributes(obj,[*B.__required_keys__,*B.__optional_keys__])
	if filter:A={B:A for(B,A)in A.items()if A}
	return A
T=TypeVar('T',bound=dict)
def convert_to_typed_dict(typed_dict:type[T],obj:dict,strict:bool=_B)->T:
	D=typed_dict;B=cast(T,select_from_typed_dict(D,obj,filter=_C))
	for(C,A)in D.__annotations__.items():
		if C in B:
			if get_origin(A)in[Union,Optional]:A=get_args(A)[0]
			if hasattr(A,'__required_keys__')and hasattr(A,'__optional_keys__'):B[C]=convert_to_typed_dict(A,B[C])
			else:
				try:B[C]=A(B[C])
				except TypeError as E:
					if strict:raise E
					else:LOG.debug('Could not convert %s to %s.',C,A)
	return B
def dict_multi_values(elements:list|dict)->dict[str,list[Any]]:
	A=elements;B={}
	if isinstance(A,dict):
		for(C,D)in A.items():
			if isinstance(D,list):B[C]=D
			else:B[C]=[D]
	elif isinstance(A,list):
		if isinstance(A[0],list):
			for(C,D)in A:
				if C in B:B[C].append(D)
				else:B[C]=[D]
		else:B[A[0]]=A[1:]
	return B
ItemType=TypeVar('ItemType')
def split_list_by(lst:Iterable[ItemType],predicate:Callable[[ItemType],bool])->tuple[list[ItemType],list[ItemType]]:
	B,C=[],[]
	for A in lst:
		if predicate(A):B.append(A)
		else:C.append(A)
	return B,C
def is_comma_delimited_list(string:str,item_regex:str|_A=_A)->bool:
	A=item_regex;A=A or DEFAULT_REGEX_LIST_ITEM;B=re.compile(rf"^\s*({A})(\s*,\s*{A})*\s*$")
	if B.match(string)is _A:return _B
	return _C
def optional_list(condition:bool,items:Iterable[_E])->list[_E]:return list(filter(lambda _:condition,items))
def iter_chunks(items:list[_E],chunk_size:int)->Generator[list[_E],_A,_A]:
	B=chunk_size;A=items
	for C in range(0,len(A),B):yield A[C:C+B]