import argparse,logging
from typing import NoReturn
LOG=logging.getLogger(__name__)
class NoExitArgumentParser(argparse.ArgumentParser):
	def exit(A,status:int=...,message:str|None=...)->NoReturn:LOG.warning('Error in argument parser but preventing exit: %s',message)
	def error(A,message:str)->NoReturn:raise NotImplementedError(f"Unsupported flag by this Docker client: {message}")