from __future__ import annotations
_b='ENTRYPOINT'
_a='EXTERNAL_SERVICE_PORTS_END'
_Z='EXTERNAL_SERVICE_PORTS_START'
_Y='GATEWAY_LISTEN'
_X='\\s*,\\s*'
_W='SERVICES'
_V='opensearch'
_U='cloudwatch'
_T='iam'
_S='apigateway'
_R='stepfunctions'
_Q='secretsmanager'
_P='cloudformation'
_O='dynamodbstreams'
_N='MAIN_CONTAINER_NAME'
_M='dynamodb'
_L='events'
_K='logs'
_J='firehose'
_I='sts'
_H='kinesis'
_G='sqs'
_F='sns'
_E='s3'
_D='lambda'
_C=False
_B=True
_A=None
import copy,functools,logging,os,re,shlex,signal,threading,time
from collections.abc import Callable,Iterable
from functools import wraps
from typing import Any
from localstack_cli import config,constants
from localstack_cli.config import HostAndPort,default_ip,is_env_not_false,load_environment
from localstack_cli.constants import VERSION
from localstack_cli.runtime import hooks
from localstack_cli.utils.container_networking import get_main_container_name
from localstack_cli.utils.container_utils.container_client import BindMount,CancellableStream,ContainerClient,ContainerConfiguration,ContainerConfigurator,ContainerException,NoSuchContainer,NoSuchImage,NoSuchNetwork,PortMappings,VolumeMappings,VolumeMappingSpecification
from localstack_cli.utils.container_utils.docker_cmd_client import CmdDockerClient
from localstack_cli.utils.docker_utils import DOCKER_CLIENT
from localstack_cli.utils.files import cache_dir,mkdir
from localstack_cli.utils.functions import call_safe
from localstack_cli.utils.net import get_free_tcp_port,get_free_tcp_port_range
from localstack_cli.utils.run import is_command_available,run,to_str
from localstack_cli.utils.serving import Server
from localstack_cli.utils.strings import short_uid
from localstack_cli.utils.sync import poll_condition
LOG=logging.getLogger(__name__)
API_DEPENDENCIES={_M:[_O],_O:[_H],'es':[_V],_P:[_E,_I],_D:[_E,_I],_J:[_H],'transcribe':[_E],_Q:['kms',_D],'ssm':[_Q]}
API_DEPENDENCIES_OPTIONAL={_J:['es',_V,_E,'redshift'],_D:[_U,_O,_L,_K,_H,_G,_F,_I],'ses':[_F],_F:[_G,_D,_J,'ses',_K],_G:[_U],_K:[_D,_H,_J],_P:[_Q,'ssm',_D],_L:[_D,_H,_J,_F,_G,_R,_K],_R:[_K,_D,_M,'ecs',_F,_G,_S,_L],_S:[_E,_G,_F,_H,'route53','servicediscovery',_D,_M,_R,_L],_E:[_L,_G,_F,_D,'kms'],_I:[_T],_T:[_I]}
API_COMPOSITES={'serverless':[_P,_U,_T,_I,_D,_M,_S,_E],'cognito':['cognito-idp','cognito-identity'],'timestream':['timestream-write','timestream-query']}
def log_duration(name=_A,min_ms=500):
	def A(f):
		@wraps(f)
		def A(*C,**D):
			from time import perf_counter as A;E=A()
			try:return f(*C,**D)
			finally:
				F=A();G=name or f.__name__;B=(F-E)*1000
				if B>min_ms:LOG.info('Execution of "%s" took %.2fms',G,B)
		return A
	return A
def get_docker_image_details(image_name:str=_A)->dict[str,str]:
	B=image_name;B=B or get_docker_image_to_start()
	try:A=DOCKER_CLIENT.inspect_image(B)
	except ContainerException:return{}
	C=A.get('RepoDigests');D=C[0].rpartition(':')[2]if C else'Unavailable';A={'id':A['Id'].replace('sha256:','')[:12],'sha256':D,'tag':(A.get('RepoTags')or['latest'])[0].split(':')[-1],'created':A['Created'].split('.')[0]};return A
def get_image_environment_variable(env_name:str)->str|_A:
	A=get_docker_image_to_start();B=DOCKER_CLIENT.inspect_image(A);C=B['Config']['Env']
	try:D=next(A for A in C if A.startswith(env_name))
	except StopIteration:return
	return D.split('=')[1]
def get_container_default_logfile_location(container_name:str)->str:return os.path.join(config.dirs.mounted_tmp,f"{container_name}_container.log")
def get_server_version_from_running_container()->str:
	C='--version';B='bin/localstack'
	try:D=get_main_container_name();A,E=DOCKER_CLIENT.exec_in_container(D,interactive=_B,command=[B,C]);A=to_str(A).strip().splitlines()[-1];return A
	except ContainerException:
		try:F=get_docker_image_to_start();A,E=DOCKER_CLIENT.run_container(F,remove=_B,interactive=_B,entrypoint='',command=[B,C]);A=to_str(A).strip().splitlines()[-1];return A
		except ContainerException:return VERSION
def get_server_version()->str:
	D=get_docker_image_details()['id'];A=cache_dir()/'image_metadata'/D/'localstack_version'
	if A.exists():E=A.read_text();return E.strip()
	B=get_image_environment_variable('LOCALSTACK_BUILD_VERSION')
	if B is not _A:A.parent.mkdir(exist_ok=_B,parents=_B);A.write_text(B);return B
	C=get_server_version_from_running_container();A.parent.mkdir(exist_ok=_B,parents=_B);A.write_text(C);return C
def setup_logging():from localstack_cli.logging.setup import setup_logging_from_config as A;A()
def resolve_apis(services:Iterable[str])->set[str]:
	B=[];C=set();B.extend(services)
	while B:
		A=B.pop()
		if A in C:continue
		if A in API_COMPOSITES:B.extend(API_COMPOSITES[A]);continue
		C.add(A)
		if A in API_DEPENDENCIES:B.extend(API_DEPENDENCIES[A])
	return C
@functools.lru_cache
def get_enabled_apis()->set[str]:
	try:from localstack_cli.services.plugins import SERVICE_PLUGINS as D
	except ImportError as E:raise ImportError('get_enabled_apis requires runtime dependencies. Not available in standalone CLI mode.')from E
	B=os.environ.get(_W,'').strip();A=D.list_available()
	if B and is_env_not_false('STRICT_SERVICE_LOADING'):
		C=[]
		for F in re.split(_X,B):G=re.split('[:=]',F);H=G[0];C.append(H)
		A=[B for B in C if B in A]
	return resolve_apis(A)
def is_api_enabled(api:str)->bool:return api in get_enabled_apis()
@functools.lru_cache
def get_preloaded_services()->set[str]:
	B=os.environ.get(_W,'').strip();A=[]
	if B:
		for C in re.split(_X,B):D=re.split('[:=]',C);E=D[0];A.append(E)
	if not A:
		try:from localstack_cli.services.plugins import SERVICE_PLUGINS as F
		except ImportError as G:raise ImportError('get_preloaded_services requires runtime dependencies when SERVICES is not set. Not available in standalone CLI mode.')from G
		A=F.list_available()
	return resolve_apis(A)
def start_infra_locally():
	try:from localstack_cli.runtime.main import main
	except ImportError as A:raise ImportError('Cannot start LocalStack in host mode. Runtime dependencies not installed. Use Docker mode instead: `localstack start`')from A
	return main()
def validate_localstack_config(name:str):
	M='image';L='docker-compose';D=name;from subprocess import CalledProcessError as N;from localstack_cli.cli import console as O;P=os.getcwd();E=D if os.path.isabs(D)else os.path.join(P,D);A=[]
	if is_command_available(L):F=[L]
	else:F=['docker','compose']
	Q=[*F,'-f',E,'config']
	try:run(Q,shell=_C,print_error=_C)
	except N as G:R=f"{G}\n{to_str(G.output)}".strip();raise ValueError(R)
	import yaml
	with open(E)as S:T=yaml.full_load(S)
	H=T.get('services',{});B=[A for(A,B)in H.items()if'localstack'in B.get(M,'')]
	if not B:raise Exception('No LocalStack service found in config (looking for image names containing "localstack")')
	if len(B)>1:A.append(f"Multiple candidates found for LocalStack service: {B}")
	B=B[0];C=H[B];I=C.get(M,'')
	if I.split(':')[0]not in constants.OFFICIAL_IMAGES:A.append(f'Using custom image "{I}", we recommend using an officially supported image: {constants.OFFICIAL_IMAGES}')
	U=C.get('container_name')or'';V=(A.split(':')[-2]for A in C.get('ports',[]));W={A.split('=')[0]:A.split('=')[1]for A in C.get('environment',{})};J=config.GATEWAY_LISTEN[0].port;K=config.MAIN_CONTAINER_NAME
	if K not in U and not W.get(_N):A.append(f'Please use "container_name: {K}" or add "MAIN_CONTAINER_NAME" in "environment".')
	def X(port):
		for A in V:
			if re.match(f"^([0-9]+-)?{port}(-[0-9]+)?$",A):return _B
	if not X(J):A.append(f'Edge port {J} is not exposed. You may have to add the entry to the "ports" section of the docker-compose file.')
	for Y in A:O.print('[yellow]:warning:[/yellow]',Y)
	if not A:return _B
	return _C
def get_docker_image_to_start():return os.environ.get('IMAGE_NAME',constants.DOCKER_IMAGE_NAME_PRO)
def extract_port_flags(user_flags,port_mappings:PortMappings):
	A=user_flags;C='-p\\s+([0-9]+)(\\-([0-9]+))?:([0-9]+)(\\-([0-9]+))?';F=re.match(f".*{C}",A)
	if F:
		for B in re.findall(C,A):D=int(B[0]);E=int(B[2]or B[0]);G=int(B[3]or D);H=int(B[5]or E);port_mappings.add([D,E],[G,H])
		A=re.sub(C,'',A)
	return A
class ContainerConfigurators:
	@staticmethod
	def mount_docker_socket(cfg:ContainerConfiguration):
		A=cfg;C=config.DOCKER_SOCK;B='/var/run/docker.sock'
		if A.volumes.find_target_mapping(B):return
		A.volumes.add(BindMount(C,B));A.env_vars['DOCKER_HOST']=f"unix://{B}"
	@staticmethod
	def mount_localstack_volume(host_path:str|os.PathLike=_A):
		A=host_path;A=A or config.VOLUME_DIR
		def B(cfg:ContainerConfiguration):
			if cfg.volumes.find_target_mapping(constants.DEFAULT_VOLUME_DIR):return
			cfg.volumes.add(BindMount(str(A),constants.DEFAULT_VOLUME_DIR))
		return B
	@staticmethod
	def config_env_vars(cfg:ContainerConfiguration):
		C={}
		if config.LOADED_PROFILES:load_environment(profiles=','.join(config.LOADED_PROFILES),env=C)
		B=[]
		for A in config.CONFIG_ENV_VARS:
			D=os.environ.get(A,_A)
			if D is not _A:
				if A!='CI'and not A.startswith('LOCALSTACK_')and A not in C:B.append(A)
				cfg.env_vars[A]=D
		if B:
			from localstack_cli.utils.analytics import log
			for E in B:LOG.warning('Non-prefixed environment variable %(env_var)s is forwarded to the LocalStack container! Please use `LOCALSTACK_%(env_var)s` instead of %(env_var)s to explicitly mark this environment variable to be forwarded from the CLI to the LocalStack Runtime.',{'env_var':E})
			log.event(event='non_prefixed_cli_env_vars',payload={'env_vars':B})
	@staticmethod
	def random_gateway_port(cfg:ContainerConfiguration):return ContainerConfigurators.gateway_listen(get_free_tcp_port())(cfg)
	@staticmethod
	def default_gateway_port(cfg:ContainerConfiguration):return ContainerConfigurators.gateway_listen(constants.DEFAULT_PORT_EDGE)(cfg)
	@staticmethod
	def gateway_listen(port:int|Iterable[int]|HostAndPort|Iterable[HostAndPort]):
		B=port
		if isinstance(B,int):A=[HostAndPort('',B)]
		elif isinstance(B,HostAndPort):A=[B]
		else:
			A=[]
			for C in B:
				if isinstance(C,int):A.append(HostAndPort('',C))
				else:A.append(C)
		def D(cfg:ContainerConfiguration):
			for B in A:cfg.ports.add(B.port)
			cfg.env_vars[_Y]=','.join([f"{A.host if A.host!=default_ip else""}:{A.port}"for A in A])
		return D
	@staticmethod
	def container_name(name:str):
		def A(cfg:ContainerConfiguration):A=cfg;A.name=name;A.env_vars[_N]=A.name
		return A
	@staticmethod
	def random_container_name(cfg:ContainerConfiguration):A=cfg;A.name=f"localstack-{short_uid()}";A.env_vars[_N]=A.name
	@staticmethod
	def default_container_name(cfg:ContainerConfiguration):A=cfg;A.name=config.MAIN_CONTAINER_NAME;A.env_vars[_N]=A.name
	@staticmethod
	def service_port_range(cfg:ContainerConfiguration):A=cfg;A.ports.add([config.EXTERNAL_SERVICE_PORTS_START,config.EXTERNAL_SERVICE_PORTS_END]);A.env_vars[_Z]=config.EXTERNAL_SERVICE_PORTS_START;A.env_vars[_a]=config.EXTERNAL_SERVICE_PORTS_END
	@staticmethod
	def random_service_port_range(num:int=50):
		def A(cfg:ContainerConfiguration):B=cfg;A=get_free_tcp_port_range(num);B.ports.add([A.start,A.end]);B.env_vars[_Z]=str(A.start);B.env_vars[_a]=str(A.end)
		return A
	@staticmethod
	def debug(cfg:ContainerConfiguration):cfg.env_vars['DEBUG']='1'
	@classmethod
	def develop(A,cfg:ContainerConfiguration):A.env_vars({'DEVELOP':'1'})(cfg);A.port(5678)(cfg)
	@staticmethod
	def network(network:str):
		def A(cfg:ContainerConfiguration):cfg.network=network
		return A
	@staticmethod
	def custom_command(cmd:list[str]):
		def A(cfg:ContainerConfiguration):cfg.command=cmd;cfg.entrypoint=''
		return A
	@staticmethod
	def env_vars(env_vars:dict[str,str]):
		def A(cfg:ContainerConfiguration):cfg.env_vars.update(env_vars)
		return A
	@staticmethod
	def port(*A,**B):
		def C(cfg:ContainerConfiguration):cfg.ports.add(*A,**B)
		return C
	@staticmethod
	def volume(volume:VolumeMappingSpecification):
		def A(cfg:ContainerConfiguration):cfg.volumes.add(volume)
		return A
	@staticmethod
	def cli_params(params:dict[str,Any]):
		A=params
		def B(cfg:ContainerConfiguration):
			C='network';B=cfg
			if A.get(C):B.network=A.get(C)
			if A.get('host_dns'):B.ports.add(config.DNS_PORT,config.DNS_PORT,'udp');B.ports.add(config.DNS_PORT,config.DNS_PORT,'tcp')
			ContainerConfigurators.env_cli_params(A.get('env'))(B);ContainerConfigurators.port_cli_params(A.get('publish'))(B);ContainerConfigurators.volume_cli_params(A.get('volume'))(B)
		return B
	@staticmethod
	def env_cli_params(params:Iterable[str]=_A):
		B=params
		def A(cfg:ContainerConfiguration):
			if not B:return
			for A in B:
				if'='in A:C,D=A.split('=',maxsplit=1);cfg.env_vars[C]=D
				else:cfg.env_vars[A]=os.getenv(A)
		return A
	@staticmethod
	def port_cli_params(params:Iterable[str]=_A):
		G=params
		def A(cfg:ContainerConfiguration):
			if not G:return
			for D in G:
				C=D.split(':');H='tcp'
				if len(C)==1:B=A=C[0]
				elif len(C)==2:B,A=C
				elif len(C)==3:I,B,A=C
				else:raise ValueError(f"Invalid port string provided: {D}")
				E=B.split('-')
				if len(E)==2:B=[int(E[0]),int(E[1])]
				elif len(E)==1:B=int(B)
				else:raise ValueError(f"Invalid port string provided: {D}")
				if'/'in A:A,H=A.split('/')
				F=A.split('-')
				if len(F)==2:A=[int(F[0]),int(F[1])]
				elif len(F)==1:A=int(A)
				else:raise ValueError(f"Invalid port string provided: {D}")
				cfg.ports.add(B,A,H)
		return A
	@staticmethod
	def volume_cli_params(params:Iterable[str]=_A):
		def A(cfg:ContainerConfiguration):
			for A in params:cfg.volumes.append(BindMount.parse(A))
		return A
def get_gateway_port(container:Container)->int:
	B=container;A:list[int];C=B.config.env_vars.get(_Y)
	if C:A=[HostAndPort.parse(A,default_host=constants.LOCALHOST_HOSTNAME,default_port=constants.DEFAULT_PORT_EDGE).port for A in C.split(',')]
	else:A=[constants.DEFAULT_PORT_EDGE]
	E=B.config.ports.to_dict()
	for F in A:
		D=E.get(f"{F}/tcp")
		if D:return D
	raise ValueError('no gateway port mapping found')
def get_gateway_url(container:Container,hostname:str=constants.LOCALHOST_HOSTNAME,protocol:str='http')->str:return f"{protocol}://{hostname}:{get_gateway_port(container)}"
class Container:
	def __init__(A,container_config:ContainerConfiguration,docker_client:ContainerClient|_A=_A):A.config=container_config;(A.running_container):RunningContainer|_A=_A;A.container_client=docker_client or DOCKER_CLIENT
	def configure(A,configurators:ContainerConfigurator|Iterable[ContainerConfigurator]):
		B=configurators
		try:C=iter(B)
		except TypeError:B(A.config);return
		for D in C:D(A.config)
	def start(A,attach:bool=_C)->RunningContainer:
		C=copy.deepcopy(A.config)
		if not C.additional_flags:C.additional_flags=''
		A._ensure_container_network(C.network)
		try:id=A.container_client.create_container_from_config(C)
		except ContainerException as B:
			if LOG.isEnabledFor(logging.DEBUG):LOG.exception('Error while creating container')
			else:LOG.error('Error while creating container: %s\n%s',B.message,to_str(B.stderr or'?'))
			raise
		try:A.container_client.start_container(id,attach=attach)
		except ContainerException as B:LOG.error('Error while starting LocalStack container: %s\n%s',B.message,to_str(B.stderr),exc_info=LOG.isEnabledFor(logging.DEBUG));raise
		A.running_container=RunningContainer(id,container_config=A.config);return A.running_container
	def _ensure_container_network(B,network:str|_A=_A):
		A=network
		if A:
			if A in['host','bridge']:return
			try:B.container_client.inspect_network(A)
			except NoSuchNetwork:LOG.debug('Container network %s not found, creating it',A);B.container_client.create_network(A)
class RunningContainer:
	def __init__(A,id:str,container_config:ContainerConfiguration,docker_client:ContainerClient|_A=_A):A.id=id;A.config=container_config;A.container_client=docker_client or DOCKER_CLIENT;A.name=A.container_client.get_container_name(A.id);A._shutdown=_C;A._mutex=threading.Lock()
	def __enter__(A):return A
	def __exit__(A,exc_type,exc_value,traceback):A.shutdown()
	def ip_address(A,docker_network:str|_A=_A)->str:
		B=docker_network
		if B is _A:return A.container_client.get_container_ip(container_name_or_id=A.id)
		else:return A.container_client.get_container_ipv4_for_network(container_name_or_id=A.id,container_network=B)
	def is_running(A)->bool:
		try:A.container_client.inspect_container(A.id);return _B
		except NoSuchContainer:return _C
	def get_logs(A)->str:return A.container_client.get_container_logs(A.id,safe=_B)
	def stream_logs(A)->CancellableStream:return A.container_client.stream_container_logs(A.id)
	def wait_until_ready(A,timeout:float=_A)->bool:return poll_condition(A.is_running,timeout)
	def shutdown(A,timeout:int=10,remove:bool=_B):
		with A._mutex:
			if A._shutdown:return
			A._shutdown=_B
		try:A.container_client.stop_container(container_name=A.id,timeout=timeout)
		except NoSuchContainer:pass
		if remove:
			try:A.container_client.remove_container(container_name=A.id,force=_B,check_existence=_C)
			except ContainerException as B:
				if'is already in progress'in str(B):return
				raise
	def inspect(A)->dict[str,dict|str]:return A.container_client.inspect_container(container_name_or_id=A.id)
	def attach(A):A.container_client.attach_to_container(container_name_or_id=A.id)
	def exec_in_container(A,*B,**C):return A.container_client.exec_in_container(*B,container_name_or_id=A.id,**C)
	def stopped(A)->Container:return Container(container_config=A.config,docker_client=A.container_client)
class ContainerLogPrinter:
	def __init__(A,container:Container,callback:Callable[[str],_A]=print):A.container=container;A.callback=callback;A._closed=threading.Event();(A._stream):CancellableStream|_A=_A
	def _can_start_streaming(A):
		if A._closed.is_set():raise OSError('Already stopped')
		if not A.container.running_container:return _C
		return A.container.running_container.is_running()
	def run(A):
		try:poll_condition(A._can_start_streaming)
		except OSError:return
		A._stream=A.container.running_container.stream_logs()
		for B in A._stream:A.callback(B.rstrip(b'\r\n').decode('utf-8'))
	def close(A):
		A._closed.set()
		if A._stream:A._stream.close()
class LocalstackContainerServer(Server):
	container:Container|RunningContainer
	def __init__(B,container_configuration:ContainerConfiguration|Container|_A=_A)->_A:
		A=container_configuration;super().__init__(config.GATEWAY_LISTEN[0].port,config.GATEWAY_LISTEN[0].host)
		if A is _A:
			C=PortMappings(bind_host=config.GATEWAY_LISTEN[0].host)
			for D in config.GATEWAY_LISTEN:C.add(D.port)
			A=ContainerConfiguration(image_name=get_docker_image_to_start(),name=config.MAIN_CONTAINER_NAME,volumes=VolumeMappings(),remove=_B,ports=C,entrypoint=os.environ.get(_b),command=shlex.split(os.environ.get('CMD',''))or _A,env_vars={})
		if isinstance(A,Container):B.container=A
		else:B.container=Container(A)
	def is_up(A)->bool:
		if not A.is_container_running():return _C
		B=A.container.get_logs()
		if constants.READY_MARKER_OUTPUT not in B.splitlines():return _C
		return super().is_up()
	def is_container_running(A)->bool:
		if not isinstance(A.container,RunningContainer):return _C
		return A.container.is_running()
	def wait_is_container_running(A,timeout=_A)->bool:return poll_condition(A.is_container_running,timeout)
	def start(A)->bool:
		if isinstance(A.container,RunningContainer):raise RuntimeError('cannot start container as container reference has been started')
		return super().start()
	def do_run(A):
		if A.is_container_running():raise ContainerRunning(f'LocalStack container named "{A.container.name}" is already running')
		config.dirs.mkdirs()
		if not isinstance(A.container,Container):raise ValueError(f"Invalid container type: {type(A.container)}")
		LOG.debug('starting LocalStack container');A.container=A.container.start(attach=_C)
		if isinstance(DOCKER_CLIENT,CmdDockerClient):DOCKER_CLIENT.default_run_outfile=get_container_default_logfile_location(A.container.config.name)
		A.container.attach();return A.container
	def shutdown(A):
		if not isinstance(A.container,RunningContainer):raise ValueError(f"Container {A.container} not started")
		return super().shutdown()
	def do_shutdown(A):
		try:A.container.shutdown(timeout=10);A.container=A.container.stopped()
		except Exception as B:LOG.info('error cleaning up localstack container %s: %s',A.container.name,B)
class ContainerExists(Exception):0
class ContainerRunning(Exception):0
def prepare_docker_start():
	A=config.MAIN_CONTAINER_NAME
	if DOCKER_CLIENT.is_container_running(A):raise ContainerRunning(f'LocalStack container named "{A}" is already running')
	if A in DOCKER_CLIENT.get_all_container_names():raise ContainerExists(f'LocalStack container named "{A}" already exists')
	config.dirs.mkdirs()
def configure_container(container:Container):
	A=container;C=PortMappings(bind_host=config.GATEWAY_LISTEN[0].host);A.config.image_name=get_docker_image_to_start();A.config.name=config.MAIN_CONTAINER_NAME;A.config.volumes=VolumeMappings();A.config.remove=_B;A.config.ports=C;A.config.entrypoint=os.environ.get(_b);A.config.command=shlex.split(os.environ.get('CMD',''))or _A;A.config.env_vars={};B=config.DOCKER_FLAGS;B=extract_port_flags(B,A.config.ports)
	if A.config.additional_flags is _A:A.config.additional_flags=B
	else:A.config.additional_flags=f"{A.config.additional_flags} {B}"
	hooks.configure_localstack_container.run(A)
	if config.DEVELOP:A.config.ports.add(config.DEVELOP_PORT)
	A.configure([ContainerConfigurators.service_port_range,ContainerConfigurators.mount_localstack_volume(config.VOLUME_DIR),ContainerConfigurators.mount_docker_socket,ContainerConfigurators.config_env_vars,ContainerConfigurators.gateway_listen(config.GATEWAY_LISTEN)])
@log_duration()
def prepare_host(console):
	A=console
	if os.environ.get(constants.LOCALSTACK_INFRA_PROCESS)in constants.TRUE_STRINGS:return
	try:mkdir(config.VOLUME_DIR)
	except Exception as B:
		A.print(f"Error while creating volume dir {config.VOLUME_DIR}: {B}")
		if config.DEBUG:A.print_exception()
	setup_logging();hooks.prepare_host.run()
def start_infra_in_docker(console,cli_params:dict[str,Any]=_A):
	C=console;prepare_docker_start();I=ContainerConfiguration(get_docker_image_to_start());A=Container(I);ensure_container_image(C,A);configure_container(A);A.configure(ContainerConfigurators.cli_params(cli_params or{}));E=C.status('Starting LocalStack container');E.start()
	def J(line):E.stop();C.rule('LocalStack Runtime Log (press [bold][yellow]CTRL-C[/yellow][/bold] to quit)');print(line);D.callback=print
	D=ContainerLogPrinter(A,callback=J)
	def F(*A):
		with K:
			if G.is_set():return
			G.set()
		print('Shutting down...');B.shutdown()
	G=threading.Event();K=threading.RLock();signal.signal(signal.SIGINT,F);B=LocalstackContainerServer(A);L=threading.Thread(target=D.run,name='container-log-printer',daemon=_B)
	try:
		B.start();L.start();B.join();H=B.get_error()
		if H:raise H
	except KeyboardInterrupt:print('ok, bye!');F()
	finally:D.close()
def ensure_container_image(console,container:Container):
	B=container;A=console
	try:DOCKER_CLIENT.inspect_image(B.config.image_name,pull=_C);return
	except NoSuchImage:A.log('container image not found on host')
	with A.status(f"Pulling container image {B.config.image_name}"):DOCKER_CLIENT.pull_image(B.config.image_name);A.log('download complete')
def start_infra_in_docker_detached(console,cli_params:dict[str,Any]=_A):
	A=console;A.log('preparing environment')
	try:prepare_docker_start()
	except ContainerRunning as E:A.print(str(E));return
	A.log('configuring container');B=ContainerConfiguration(get_docker_image_to_start());C=Container(B);ensure_container_image(A,C);configure_container(C);C.configure(ContainerConfigurators.cli_params(cli_params or{}));B.detach=_B;A.log('starting container');D=LocalstackContainerServer(B);D.start();D.wait_is_container_running();A.log('detaching')
def wait_container_is_ready(timeout:float|_A=_A):
	C=timeout;E=config.MAIN_CONTAINER_NAME;G=time.time()
	def H():return DOCKER_CLIENT.is_container_running(E)
	if not poll_condition(H,timeout=C):return _C
	A=DOCKER_CLIENT.stream_container_logs(E);B=_A
	if C:
		I=time.time()-G;F=C-I
		if F<=0:A.close();return _C
		B=threading.Timer(F,A.close);B.start()
	try:
		for D in A:
			D=D.decode('utf-8').strip()
			if D==constants.READY_MARKER_OUTPUT:return _B
		return _C
	finally:
		call_safe(A.close)
		if B:B.cancel()
def in_ci():
	for A in('CI','TRAVIS'):
		if os.environ.get(A,'')not in[_C,'','0','false']:return _B
	return _C
def is_auth_token_configured()->bool:return _B if os.environ.get('LOCALSTACK_AUTH_TOKEN','').strip()or os.environ.get('LOCALSTACK_API_KEY','').strip()else _C