import logging,os
from localstack_cli import config
from localstack_cli.constants import API_ENDPOINT,ASSETS_ENDPOINT
from localstack_cli.utils.crypto import generate_ssl_cert
from localstack_cli.utils.http import download
from localstack_cli.utils.time import now
from localstack_cli.version import __version__ as version
LOG=logging.getLogger(__name__)
SSL_CERT_URL=f"{ASSETS_ENDPOINT}/local-certs/localstack.cert.key?version={version}"
SSL_CERT_URL_FALLBACK=f"{API_ENDPOINT}/proxy/localstack.cert.key?version={version}"
_SERVER_CERT_PEM_FILE='server.test.pem'
def install_predefined_cert_if_available():
	try:
		if config.SKIP_SSL_CERT_DOWNLOAD:LOG.debug('Skipping download of local SSL cert, as SKIP_SSL_CERT_DOWNLOAD=1');return
		setup_ssl_cert()
	except Exception:pass
def setup_ssl_cert()->None:
	C='SSL certificate downloaded successfully';A=get_cert_pem_file_path()
	if os.path.exists(A):
		D=86400;E=os.path.getmtime(A)
		if E>now()-D:LOG.debug('Using cached SSL certificate (less than 6hrs since last update).');return
	LOG.debug('Attempting to download local SSL certificate file');B=5
	try:download(SSL_CERT_URL,A,timeout=B,quiet=True);LOG.debug(C)
	except Exception:
		try:download(SSL_CERT_URL_FALLBACK,A,timeout=B,quiet=True);LOG.debug(C)
		except Exception as F:LOG.info('Unable to download local test SSL certificate from %s to %s (using self-signed cert as fallback): %s',SSL_CERT_URL_FALLBACK,A,F);raise
def get_cert_pem_file_path():return config.CUSTOM_SSL_CERT_PATH or os.path.join(config.dirs.cache,_SERVER_CERT_PEM_FILE)
def create_ssl_cert(serial_number=None):A=get_cert_pem_file_path();return generate_ssl_cert(A,serial_number=serial_number)