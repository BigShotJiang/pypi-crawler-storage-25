_B='SubtypesInstanceManager'
_A=None
import functools,re,threading
from collections.abc import Callable
from typing import Any,Generic,TypeVar
from.collections import ensure_list
from.strings import first_char_to_lower,first_char_to_upper
ComplexType=list|dict|object
_T=TypeVar('_T')
class Value(Generic[_T]):
	value:_T|_A
	def __init__(A,value:_T=_A)->_A:A.value=value
	def clear(A):A.value=_A
	def set(A,value:_T):A.value=value
	def is_set(A)->bool:return A.value is not _A
	def get(A)->_T|_A:return A.value
	def __bool__(A):return True if A.value else False
class ArbitraryAccessObj:
	def __init__(A,name=_A):A.name=name
	def __getattr__(A,name,*B,**C):return ArbitraryAccessObj(name)
	def __call__(A,*B,**C):
		if A.name in['items','keys','values']and not B and not C:return[]
		return ArbitraryAccessObj()
	def __getitem__(A,*B,**C):return ArbitraryAccessObj()
	def __setitem__(A,*B,**C):return ArbitraryAccessObj()
class Mock:0
class ObjectIdHashComparator:
	def __init__(A,obj):A.obj=obj;A._hash=id(obj)
	def __hash__(A):return A._hash
	def __eq__(A,other):return A.obj==other.obj
class SubtypesInstanceManager:
	_instances:dict[str,_B]
	@classmethod
	def get(E,subtype_name:str,raise_if_missing:bool=True):
		A=subtype_name;B=E.instances();F=E.get_base_type();C=B.get(A)
		if C is _A:
			for G in get_all_subclasses(F):
				D=G.impl_name()
				if D not in B and A==D:B[D]=G()
			C=B.get(A)
		if not C and raise_if_missing:raise NotImplementedError(f"Unable to find implementation named '{A}' for base type {F}")
		return C
	@classmethod
	def instances(B)->dict[str,_B]:
		A=B.get_base_type()
		if not hasattr(A,'_instances'):A._instances={}
		return A._instances
	@staticmethod
	def impl_name()->str:raise NotImplementedError
	@classmethod
	def get_base_type(A)->type:return A
def get_all_subclasses(clazz:type)->set[type]:
	A=set();C=clazz.__subclasses__()
	for B in C:A.add(B);A.update(get_all_subclasses(B))
	return A
def fully_qualified_class_name(klass:type)->str:A=klass;return f"{A.__module__}.{A.__name__}"
def not_none_or(value:Any|_A,alternative:Any)->Any:A=value;return A if A is not _A else alternative
def recurse_object(obj:ComplexType,func:Callable,path:str='')->ComplexType:
	C=func;B=path;A=obj;A=C(A,path=B)
	if isinstance(A,list):
		for D in range(len(A)):E=f"{B or"."}[{D}]";A[D]=recurse_object(A[D],C,E)
	elif isinstance(A,dict):
		for(F,G)in A.items():E=f"{f"{B}."if B else""}{F}";A[F]=recurse_object(G,C,E)
	return A
def keys_to(obj:ComplexType,op:Callable[[str],str],skip_children_of:list[str]=_A)->ComplexType:
	A=skip_children_of;A=ensure_list(A or[])
	def B(o,path='',**D):
		if any(re.match(rf"(^|.*\.){A}($|[.\[].*)",path)for A in A):return o
		if isinstance(o,dict):
			for(B,C)in dict(o).items():o.pop(B);o[op(B)]=C
		return o
	C=recurse_object(obj,B);return C
def keys_to_lower(obj:ComplexType,skip_children_of:list[str]=_A)->ComplexType:return keys_to(obj,first_char_to_lower,skip_children_of)
def keys_to_upper(obj:ComplexType,skip_children_of:list[str]=_A)->ComplexType:return keys_to(obj,first_char_to_upper,skip_children_of)
def singleton_factory(factory:Callable[[],_T])->Callable[[],_T]:
	B=factory;D=threading.RLock();A:Value[_T]=Value()
	@functools.wraps(B)
	def C()->_T:
		if A.is_set():return A.get()
		with D:
			if not A:A.set(B())
			return A.get()
	C.clear=A.clear;return C
def get_value_from_path(data,path):
	A=path.split('.')
	try:B=functools.reduce(dict.__getitem__,A,data);return B
	except KeyError:return
def set_value_at_path(data,path,new_value):
	A=path.split('.');B=A[-1];C=functools.reduce(dict.__getitem__,A[:-1],data)
	try:C[B]=new_value
	except KeyError:raise ValueError(f"Invalid path: {path}")