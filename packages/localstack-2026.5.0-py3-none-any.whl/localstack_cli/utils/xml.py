import xml.etree.ElementTree as ET
from typing import Any
def obj_to_xml(obj:Any)->str:
	A=obj
	if isinstance(A,list):return''.join([obj_to_xml(A)for A in A])
	if isinstance(A,dict):return''.join([f"<{A}>{obj_to_xml(B)}</{A}>"for(A,B)in A.items()])
	return str(A)
def strip_xmlns(obj:Any)->Any:
	B='#text';A=obj
	if isinstance(A,list):return[strip_xmlns(A)for A in A]
	if isinstance(A,dict):
		A.pop('@xmlns',None)
		if len(A)==1 and B in A:return A[B]
		return{A:strip_xmlns(B)for(A,B)in A.items()}
	return A
def is_valid_xml(xml_string:str)->bool:
	try:ET.fromstring(xml_string.encode('utf-8'));return True
	except ET.ParseError:return False