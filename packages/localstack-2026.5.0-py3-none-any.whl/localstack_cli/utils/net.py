_F='PortRange'
_E='127.0.0.1'
_D='tcp'
_C=True
_B=False
_A=None
import logging,random,re,socket,threading
from collections.abc import MutableMapping
from contextlib import closing
from typing import Any,NamedTuple
from urllib.parse import urlparse
import dns.resolver
from dnslib import DNSRecord
from localstack_cli import config,constants
from.collections import CustomExpiryTTLCache
from.numbers import is_number
from.objects import singleton_factory
from.sync import retry
LOG=logging.getLogger(__name__)
IP_REGEX='^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$'
DYNAMIC_PORT_RANGE_START=32768
DYNAMIC_PORT_RANGE_END=65536
DEFAULT_PORT_RESERVED_SECONDS=6
class Port(NamedTuple):
	port:int;protocol:str
	@classmethod
	def wrap(B,port:'IntOrPort')->'Port':
		A=port
		if isinstance(A,Port):return A
		return Port(port=A,protocol=_D)
IntOrPort=int|Port
def is_port_open(port_or_url:int|str,http_path:str=_A,expect_success:bool=_C,protocols:str|list[str]|_A=_A,quiet:bool=_C):
	N='localhost';K=quiet;J=http_path;I=port_or_url;C=protocols;from localstack_cli.utils.http import safe_requests as O;C=C or[_D];B=I
	if is_number(B):B=int(B)
	A=N;L='http';C=C if isinstance(C,list)else[C]
	if isinstance(B,str):D=urlparse(I);B=D.port;A=D.hostname;L=D.scheme
	G=[];G+=[socket.SOCK_STREAM]if _D in C else[];G+=[socket.SOCK_DGRAM]if'udp'in C else[]
	for H in G:
		with closing(socket.socket(socket.AF_INET if':'not in A else socket.AF_INET6,H))as E:
			E.settimeout(1)
			if H==socket.SOCK_DGRAM:
				try:
					if B==53:P=_E if A==N else A;F=dns.resolver.Resolver();F.nameservers=[P];F.timeout=1;F.lifetime=1;Q=F.query('google.com','A');assert len(Q)>0
					else:E.sendto(b'',(A,B));E.recvfrom(1024)
				except Exception:
					if not K:LOG.error('Error connecting to UDP port %s:%s',A,B,exc_info=LOG.isEnabledFor(logging.DEBUG))
					return _B
			elif H==socket.SOCK_STREAM:
				M=E.connect_ex((A,B))
				if M!=0:
					if not K:LOG.warning('Error connecting to TCP port %s:%s (result=%s)',A,B,M)
					return _B
	if _D not in C or not J:return _C
	A=f"[{A}]"if':'in A else A;D=f"{L}://{A}:{B}{J}"
	try:R=O.get(D,verify=_B);return not expect_success or R.status_code<400
	except Exception:return _B
def wait_for_port_open(port:int,http_path:str=_A,expect_success=_C,retries=10,sleep_time=.5):return wait_for_port_status(port,http_path=http_path,expect_success=expect_success,retries=retries,sleep_time=sleep_time)
def wait_for_port_closed(port:int,http_path:str=_A,expect_success=_C,retries=10,sleep_time=.5):return wait_for_port_status(port,http_path=http_path,expect_success=expect_success,retries=retries,sleep_time=sleep_time,expect_closed=_C)
def wait_for_port_status(port:int,http_path:str=_A,expect_success=_C,retries=10,sleep_time=.5,expect_closed=_B):
	B=expect_closed;A=http_path
	def C():
		C=is_port_open(port,http_path=A,expect_success=expect_success)
		if bool(C)!=(not B):raise Exception('Port {} (path: {}) was not {}'.format(port,A,'closed'if B else'open'))
	return retry(C,sleep=sleep_time,retries=retries)
def port_can_be_bound(port:IntOrPort,address:str='')->bool:
	A=port
	try:
		A=Port.wrap(A)
		if A.protocol==_D:B=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
		elif A.protocol=='udp':B=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
		else:LOG.debug("Unsupported network protocol '%s' for port check",A.protocol);return _B
		B.bind((address,A.port));return _C
	except OSError:return _B
	except Exception:LOG.error('cannot bind port %s',A,exc_info=LOG.isEnabledFor(logging.DEBUG));return _B
def get_free_udp_port(blocklist:list[int]=_A)->int:
	A=blocklist;A=A or[]
	for D in range(10):
		B=socket.socket(socket.AF_INET,socket.SOCK_DGRAM);B.bind(('',0));E,C=B.getsockname();B.close()
		if C not in A:return C
	raise Exception(f"Unable to determine free UDP port with blocklist {A}")
def get_free_tcp_port(blocklist:list[int]=_A)->int:
	A=blocklist;A=A or[]
	for D in range(50):
		C=socket.socket(socket.AF_INET,socket.SOCK_STREAM);C.bind(('',0));E,B=C.getsockname();C.close()
		if B not in A and not dynamic_port_range.is_port_reserved(B):
			try:dynamic_port_range.mark_reserved(B)
			except ValueError:pass
			return B
	raise Exception(f"Unable to determine free TCP port with blocklist {A}")
def get_free_tcp_port_range(num_ports:int,max_attempts:int=50)->_F:
	A=num_ports
	if A<2:raise ValueError(f"invalid number of ports {A}")
	def D(_range:PortRange):
		for A in _range:
			if dynamic_port_range.is_port_reserved(A)or not port_can_be_bound(A):return _B
		return _C
	for F in range(max_attempts):
		C=random.randint(dynamic_port_range.start,dynamic_port_range.end-A-1);B=PortRange(C,C+A-1)
		if not D(B):continue
		for E in B:dynamic_port_range.mark_reserved(E)
		return B
	raise PortNotAvailableException('reached max_attempts when trying to find port range')
def resolve_hostname(hostname:str)->str|_A:
	try:return socket.gethostbyname(hostname)
	except OSError:return
def is_ip_address(addr:str)->bool:
	try:socket.inet_aton(addr);return _C
	except OSError:return _B
def is_ipv4_address(address:str)->bool:return bool(re.match(IP_REGEX,address))
class PortNotAvailableException(Exception):0
class PortRange:
	def __init__(A,start:int,end:int):A.start=start;A.end=end;(A._ports_cache):MutableMapping[Port,Any]=CustomExpiryTTLCache(maxsize=len(A),ttl=DEFAULT_PORT_RESERVED_SECONDS);A._ports_lock=threading.RLock()
	def subrange(A,start:int=_A,end:int=_A)->_F:
		C=end;B=start;B=B if B is not _A else A.start;C=C if C is not _A else A.end
		if B<A.start:raise ValueError(f"start not in range ({B} < {A.start})")
		if C>A.end:raise ValueError(f"end not in range ({C} < {A.end})")
		D=type(A)(B,C);D._ports_cache=A._ports_cache;D._ports_lock=A._ports_lock;return D
	def as_range(A)->range:return range(A.start,A.end+1)
	def reserve_port(B,port:IntOrPort|_A=_A,duration:int|_A=_A)->int:
		D=duration;A=port;C=B.as_range();A=Port.wrap(A)if A is not _A else A
		if A is not _A and A.port not in C:raise PortNotAvailableException(f"The requested port ({A}) is not in the port range ({C}).")
		with B._ports_lock:
			if A is not _A:return B._try_reserve_port(A,duration=D)
			else:
				for E in C:
					try:return B._try_reserve_port(E,duration=D)
					except PortNotAvailableException:pass
		raise PortNotAvailableException(f"No free network ports available in {B!r} (currently reserved: %s)",list(B._ports_cache.keys()))
	def is_port_reserved(B,port:IntOrPort)->bool:A=port;A=Port.wrap(A);return B._ports_cache.get(A)is not _A
	def mark_reserved(B,port:IntOrPort,duration:int=_A):
		C=duration;A=port;A=Port.wrap(A)
		if A.port not in B.as_range():raise ValueError(f"port {A} not in {B!r}")
		with B._ports_lock:
			B._ports_cache[A]='__reserved__'
			if C:B._ports_cache.set_expiry(A,C)
	def _try_reserve_port(B,port:IntOrPort,duration:int)->int:
		A=port;A=Port.wrap(A)
		if B.is_port_reserved(A):raise PortNotAvailableException(f"The given port ({A}) is already reserved.")
		if not B._port_can_be_bound(A):raise PortNotAvailableException(f"The given port ({A}) is already in use.")
		B.mark_reserved(A,duration);return A.port
	def _port_can_be_bound(A,port:IntOrPort)->bool:return port_can_be_bound(port)
	def __len__(A):return A.end-A.start+1
	def __iter__(A):return A.as_range().__iter__()
	def __repr__(A):return f"PortRange({A.start}:{A.end})"
@singleton_factory
def get_docker_host_from_container()->str:
	B='host.docker.internal';A=config.DOCKER_BRIDGE_IP
	try:
		if not config.is_in_docker and not config.is_in_linux:A=B
		if config.is_in_docker:
			try:A=socket.gethostbyname(B)
			except OSError:A=socket.gethostbyname('host.containers.internal')
	except OSError:pass
	return A
def get_addressable_container_host(default_local_hostname:str=_A)->str:A=default_local_hostname;A=A or constants.LOCALHOST_HOSTNAME;return get_docker_host_from_container()if config.is_in_docker else A
def send_dns_query(name:str,port:int=53,ip_address:str=_E,qtype:str='A',timeout:float=1.,tcp:bool=_B)->DNSRecord:A=ip_address;LOG.debug('querying %s:%d for name %s',A,port,name);B=DNSRecord.question(qname=name,qtype=qtype);C=B.send(dest=A,port=port,tcp=tcp,timeout=timeout,ipv6=_B);return DNSRecord.parse(C)
dynamic_port_range=PortRange(DYNAMIC_PORT_RANGE_START,DYNAMIC_PORT_RANGE_END)