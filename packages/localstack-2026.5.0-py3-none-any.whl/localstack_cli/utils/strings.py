_E='strict'
_D='utf-8'
_C='true'
_B=False
_A=True
import base64,binascii,hashlib,itertools,random,re,string,uuid,zlib
from localstack_cli.config import DEFAULT_ENCODING
_unprintables=range(0,9),range(10,10),range(11,13),range(14,32),range(55296,57344),range(65534,65536)
REGEX_UNPRINTABLE_CHARS=re.compile(f"[{re.escape("".join(map(chr,itertools.chain(*_unprintables))))}]")
def to_str(obj:str|bytes,encoding:str=DEFAULT_ENCODING,errors=_E)->str:A=obj;return A.decode(encoding,errors)if isinstance(A,bytes)else A
def to_bytes(obj:str|bytes,encoding:str=DEFAULT_ENCODING,errors=_E)->bytes:A=obj;return A.encode(encoding,errors)if isinstance(A,str)else A
def truncate(data:str,max_length:int=100)->str:B=max_length;A=data;A=str(A or'');return f"{A[:B]}..."if len(A)>B else A
def is_string(s,include_unicode=_A,exclude_binary=_B):
	if isinstance(s,bytes)and exclude_binary:return _B
	if isinstance(s,str):return _A
	if include_unicode and isinstance(s,str):return _A
	return _B
def is_string_or_bytes(s):return is_string(s)or isinstance(s,str)or isinstance(s,bytes)
def is_base64(s):A='^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$';return is_string(s)and re.match(A,s)
_re_camel_to_snake_case=re.compile('((?<=[a-z0-9])[A-Z]|(?!^)[A-Z](?=[a-z]))')
def camel_to_snake_case(string:str)->str:return _re_camel_to_snake_case.sub('_\\1',string).replace('__','_').lower()
def snake_to_camel_case(string:str,capitalize_first:bool=_A)->str:A=string.split('_');B=0 if capitalize_first else 1;A=[A.title()for A in A[B:]];return''.join(A)
def hyphen_to_snake_case(string:str)->str:return string.replace('-','_')
def canonicalize_bool_to_str(val:bool)->str:return _C if str(val).lower()==_C else'false'
def convert_to_printable_chars(value:list|dict|str)->str:
	A=value;from localstack_cli.utils.objects import recurse_object as B
	if isinstance(A,(dict,list)):
		def C(obj,**B):
			A=obj
			if isinstance(A,str):return convert_to_printable_chars(A)
			return A
		return B(A,C)
	D=REGEX_UNPRINTABLE_CHARS.sub('',A);return D
def first_char_to_lower(s:str)->str:return s and f"{s[0].lower()}{s[1:]}"
def first_char_to_upper(s:str)->str:return s and f"{s[0].upper()}{s[1:]}"
def str_to_bool(value):
	A=value
	if isinstance(A,str):B=[_C,'True'];return A in B
	return A
def str_insert(string,index,content):B=index;A=string;return f"{A[:B]}{content}{A[B:]}"
def str_remove(string,index,end_index=None):C=index;B=string;A=end_index;A=A or C+1;return f"{B[:C]}{B[A:]}"
def str_startswith_ignore_case(value:str,prefix:str)->bool:A=prefix;return value[:len(A)].lower()==A.lower()
def short_uid()->str:return str(uuid.uuid4())[0:8]
def short_uid_from_seed(seed:str)->str:hash=hashlib.sha1(seed.encode(_D)).hexdigest();A=hash[:32];return str(uuid.UUID(A))[0:8]
def long_uid()->str:return str(uuid.uuid4())
def md5(string:str|bytes)->str:A=hashlib.md5();A.update(to_bytes(string));return A.hexdigest()
def checksum_crc32(string:str|bytes)->str:bytes=to_bytes(string);A=zlib.crc32(bytes);return base64.b64encode(A.to_bytes(4,'big')).decode()
def checksum_crc32c(string:str|bytes):from botocore.httpchecksum import CrtCrc32cChecksum as B;A=B();A.update(to_bytes(string));return base64.b64encode(A.digest()).decode()
def checksum_crc64nvme(string:str|bytes):from botocore.httpchecksum import CrtCrc64NvmeChecksum as B;A=B();A.update(to_bytes(string));return base64.b64encode(A.digest()).decode()
def hash_sha1(string:str|bytes)->str:A=hashlib.sha1(to_bytes(string)).digest();return base64.b64encode(A).decode()
def hash_sha256(string:str|bytes)->str:A=hashlib.sha256(to_bytes(string)).digest();return base64.b64encode(A).decode()
def base64_to_hex(b64_string:str)->bytes:return binascii.hexlify(base64.b64decode(b64_string))
def base64_decode(data:str|bytes)->bytes:
	A=data;A=to_str(A);B=len(A)%4
	if B!=0:A=to_str(A)+'='*(4-B)
	if'-'in A or'_'in A:return base64.urlsafe_b64decode(A)
	return base64.b64decode(A)
def get_random_hex(length:int)->str:return''.join(random.choices(string.hexdigits[:16],k=length)).lower()
def remove_leading_extra_slashes(input:str)->str:return re.sub('^/+','/',input)
def prepend_with_slash(input:str)->str:
	if not input.startswith('/'):return f"/{input}"
	return input
def key_value_pairs_to_dict(pairs:str,delimiter:str=',',separator:str='=')->dict:A=[A.partition(separator)for A in pairs.split(delimiter)];return{A.strip():B.strip()for(A,C,B)in A}
def token_generator(item:str)->str:A=base64.b64encode(item.encode(_D));B=A.decode(_D);return B