_A='://'
from localstack_cli import config
from localstack_cli.config import HostAndPort
def path_from_url(url:str)->str:A=url;return f"/{A.partition(_A)[2].partition("/")[2]}"if _A in A else A
def hostname_from_url(url:str)->str:return url.split(_A)[-1].split('/')[0].split(':')[0]
def localstack_host(custom_port:int|None=None)->HostAndPort:A=custom_port or config.LOCALSTACK_HOST.port;B=config.LOCALSTACK_HOST.host;return HostAndPort(host=B,port=A)