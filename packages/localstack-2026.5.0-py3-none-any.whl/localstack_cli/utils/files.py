_B=False
_A=None
import configparser,inspect,logging,os,shutil,stat,tempfile
from pathlib import Path
LOG=logging.getLogger(__name__)
TMP_FILES=[]
def parse_config_file(file_or_str:str,single_section:bool=True)->dict:
	A=file_or_str;B=configparser.RawConfigParser()
	if os.path.exists(A):A=load_file(A)
	try:B.read_string(A)
	except configparser.MissingSectionHeaderError:A=f"[default]\n{A}";B.read_string(A)
	C=list(B.sections());D={A:dict(B.items(A))for A in C}
	if len(C)==1 and single_section:D=D[C[0]]
	return D
def get_user_cache_dir()->Path:
	from localstack_cli.utils.platform import is_linux as B,is_mac_os as C,is_windows as D
	if D():return Path(os.path.expandvars('%LOCALAPPDATA%\\cache'))
	if C():return Path.home()/'Library'/'Caches'
	if B():
		A=os.environ.get('XDG_CACHE_HOME')
		if A and os.path.isabs(A):return Path(A)
	return Path.home()/'.cache'
def cache_dir()->Path:return get_user_cache_dir()/'localstack'
def save_file(file,content,append=_B,permissions=_A):
	C=permissions;B=content;A='a'if append else'w+'
	if not isinstance(B,str):A=A+'b'
	def E(path,flags):return os.open(path,flags,C)
	mkdir(os.path.dirname(file))
	with open(file,A,opener=E if C else _A)as D:D.write(B);D.flush()
def load_file(file_path:str|os.PathLike,default:str|bytes|_A=_A,mode:str|_A=_A,strict:bool=_B)->str|bytes|_A:
	B=mode;A=file_path
	if not os.path.isfile(A):
		if strict:raise FileNotFoundError(A)
		else:return default
	if not B:B='r'
	with open(A,B)as C:D=C.read()
	return D
def get_or_create_file(file_path,content=_A,permissions=_A):
	B=file_path;A=content
	if os.path.exists(B):return load_file(B)
	A='{}'if A is _A else A
	try:save_file(B,A,permissions=permissions);return A
	except Exception:pass
def replace_in_file(search,replace,file_path):
	A=file_path;B=load_file(A)or'';C=B.replace(search,replace)
	if B!=C:save_file(A,C)
def mkdir(folder:str):
	A=folder
	if not os.path.exists(A):os.makedirs(A,exist_ok=True)
def is_empty_dir(directory:str,ignore_hidden:bool=_B)->bool:
	A=directory
	if not os.path.isdir(A):raise Exception(f"Path is not a directory: {A}")
	B=os.listdir(A)
	if ignore_hidden:B=[A for A in B if not A.startswith('.')]
	return not bool(B)
def ensure_readable(file_path:str,default_perms:int=_A):
	B=default_perms;A=file_path
	if B is _A:B=420
	try:
		with open(A,'rb'):0
	except Exception:LOG.info('Updating permissions as file is currently not readable: %s',A);os.chmod(A,B)
def chown_r(path:str,user:str):
	import grp,pwd;A=pwd.getpwnam(user).pw_uid;B=grp.getgrnam(user).gr_gid;os.chown(path,A,B)
	for(C,D,E)in os.walk(path):
		for F in D:os.chown(os.path.join(C,F),A,B)
		for G in E:os.chown(os.path.join(C,G),A,B)
def chmod_r(path:str,mode:int):
	B=mode;A=path
	if not os.path.exists(A):return
	idempotent_chmod(A,B)
	for(C,D,E)in os.walk(A):
		for F in D:idempotent_chmod(os.path.join(C,F),B)
		for G in E:idempotent_chmod(os.path.join(C,G),B)
def idempotent_chmod(path:str,mode:int):
	try:os.chmod(path,mode)
	except Exception:
		try:A=os.stat(path)
		except FileNotFoundError:return
		if mode in(A.st_mode,stat.S_IMODE(A.st_mode)):return
		raise
def rm_rf(path:str):
	A=path;from localstack_cli.utils.platform import is_debian as B;from localstack_cli.utils.run import run
	if not A or not os.path.exists(A):return
	if B():
		try:return run(f'rm -rf "{A}"')
		except Exception:pass
	try:chmod_r(A,511)
	except PermissionError:pass
	C=os.path.exists(A)and not os.path.isdir(A)
	if os.path.isfile(A)or C:os.remove(A)
	else:shutil.rmtree(A)
def cp_r(src:str,dst:str,rm_dest_on_conflict=_B,ignore_copystat_errors=_B,**C):
	F='dirs_exist_ok';B=src;A=dst;D=shutil.copystat
	if ignore_copystat_errors:
		def G(*A,**B):
			try:return D(*A,**B)
			except Exception:pass
		shutil.copystat=G
	try:
		if os.path.isfile(B):
			if os.path.isdir(A):A=os.path.join(A,os.path.basename(B))
			return shutil.copyfile(B,A)
		if F in inspect.getfullargspec(shutil.copytree).args:C[F]=True
		try:return shutil.copytree(B,A,**C)
		except FileExistsError:
			if rm_dest_on_conflict:rm_rf(A);return shutil.copytree(B,A,**C)
			raise
	except Exception as H:
		def E(_path):A=_path;return f"{A} (file={os.path.isfile(A)}, symlink={os.path.islink(A)})"
		LOG.debug('Error copying files from %s to %s: %s',E(B),E(A),H);raise
	finally:shutil.copystat=D
def disk_usage(path:str)->int:
	A=path
	if not os.path.exists(A):return 0
	if os.path.isfile(A):return os.path.getsize(A)
	B=0
	for(D,G,E)in os.walk(A):
		for F in E:
			C=os.path.join(D,F)
			if not os.path.islink(C):B+=os.path.getsize(C)
	return B
def file_exists_not_empty(path:str)->bool:return path and disk_usage(path)>0
def cleanup_tmp_files():
	for A in TMP_FILES:
		try:rm_rf(A)
		except Exception:pass
	del TMP_FILES[:]
def new_tmp_file(suffix:str|_A=_A,dir:str|_A=_A)->str:B,A=tempfile.mkstemp(suffix=suffix,dir=dir);os.close(B);TMP_FILES.append(A);return A
def new_tmp_dir(dir:str|_A=_A,mode:int=511)->str:A=tempfile.mkdtemp(dir=dir);TMP_FILES.append(A);idempotent_chmod(A,mode=mode);return A