_B=False
_A=None
import io,logging,os,re,threading
from asn1crypto import algos,cms,core,x509 as asn1_x509
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives import padding as sym_padding
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.primitives.asymmetric.rsa import RSAPublicKey
from cryptography.hazmat.primitives.ciphers import Cipher,algorithms,modes
from.files import TMP_FILES,file_exists_not_empty,load_file,new_tmp_file,save_file
from.strings import short_uid,to_bytes,to_str
from.sync import synchronized
from.urls import localstack_host
LOG=logging.getLogger(__name__)
BLOCK_SIZE=16
SSL_CERT_LOCK=threading.RLock()
PEM_CERT_START='-----BEGIN CERTIFICATE-----'
PEM_CERT_END='-----END CERTIFICATE-----'
PEM_KEY_START_REGEX='-----BEGIN(.*)PRIVATE KEY-----'
PEM_KEY_END_REGEX='-----END(.*)PRIVATE KEY-----'
OID_AES256_CBC='2.16.840.1.101.3.4.1.42'
OID_MGF1='1.2.840.113549.1.1.8'
OID_RSAES_OAEP='1.2.840.113549.1.1.7'
OID_SHA256='2.16.840.1.101.3.4.2.1'
@synchronized(lock=SSL_CERT_LOCK)
def generate_ssl_cert(target_file=_A,overwrite=_B,random=_B,return_content=_B,serial_number=_A):
	J=True;H=serial_number;A=target_file;from OpenSSL import crypto as B
	def K(*A):return all(os.path.exists(A)for A in A)
	def L(base_filename):E=base_filename;F=f"{E}.key";G=f"{E}.crt";B=load_file(A);D=re.search(PEM_KEY_START_REGEX,B);D=D.group(0);C=re.search(PEM_KEY_END_REGEX,B);C=C.group(0);H=B[B.index(D):B.index(C)+len(C)];I=B[B.index(PEM_CERT_START):B.rindex(PEM_CERT_END)+len(PEM_CERT_END)];save_file(F,H);save_file(G,I);return G,F
	if A and not overwrite and file_exists_not_empty(A):
		try:D,E=L(A)
		except Exception as I:LOG.info('Error storing key/cert SSL files (falling back to random tmp file names): %s',I);R=new_tmp_file();D,E=L(R)
		if K(D,E):return A,D,E
	if random and A:
		if'.'in A:A=A.replace('.',f".{short_uid()}.",1)
		else:A=f"{A}.{short_uid()}"
	G=B.PKey();G.generate_key(B.TYPE_RSA,2048);S=localstack_host();C=B.X509();F=C.get_subject();F.C='AU';F.ST='Some-State';F.L='Some-Locality';F.O='LocalStack Org';F.OU='Testing';F.CN='localhost';H=H or 1001;C.set_version(2);C.set_serial_number(H);C.gmtime_adj_notBefore(0);C.gmtime_adj_notAfter(63072000);C.set_issuer(C.get_subject());C.set_pubkey(G);T=f"DNS:localhost,DNS:test.localhost.atlassian.io,DNS:localhost.localstack.cloud,DNS:{S.host}IP:127.0.0.1".encode();C.add_extensions([B.X509Extension(b'subjectAltName',_B,T),B.X509Extension(b'basicConstraints',J,b'CA:false'),B.X509Extension(b'keyUsage',J,b'nonRepudiation,digitalSignature,keyEncipherment'),B.X509Extension(b'extendedKeyUsage',J,b'serverAuth')]);C.sign(G,'SHA256');M=io.StringIO();N=io.StringIO();M.write(to_str(B.dump_certificate(B.FILETYPE_PEM,C)));N.write(to_str(B.dump_privatekey(B.FILETYPE_PEM,G)));O=M.getvalue().strip();P=N.getvalue().strip();Q=f"{P}\n{O}"
	if A:
		E=f"{A}.key";D=f"{A}.crt"
		if not K(A,E,D):
			for U in range(2):
				try:save_file(A,Q);save_file(E,P);save_file(D,O);break
				except Exception as I:
					if U>0:raise
					LOG.info('Unable to store certificate file under %s, using tmp file instead: %s',A,I);A=f"{new_tmp_file()}.pem";E=f"{A}.key";D=f"{A}.crt"
			TMP_FILES.append(A);TMP_FILES.append(E);TMP_FILES.append(D)
		if not return_content:return A,D,E
	return Q
def pad(s:bytes)->bytes:return s+to_bytes((BLOCK_SIZE-len(s)%BLOCK_SIZE)*chr(BLOCK_SIZE-len(s)%BLOCK_SIZE))
def unpad(s:bytes)->bytes:return s[0:-s[-1]]
def encrypt(key:bytes,message:bytes,iv:bytes=_A,aad:bytes=_A)->tuple[bytes,bytes]:iv=iv or b'0'*BLOCK_SIZE;B=Cipher(algorithms.AES(key),modes.GCM(iv),backend=default_backend());A=B.encryptor();A.authenticate_additional_data(aad);C=A.update(pad(message))+A.finalize();return C,A.tag
def decrypt(key:bytes,encrypted:bytes,iv:bytes=_A,tag:bytes=_A,aad:bytes=_A)->bytes:iv=iv or b'0'*BLOCK_SIZE;C=Cipher(algorithms.AES(key),modes.GCM(iv,tag),backend=default_backend());A=C.decryptor();A.authenticate_additional_data(aad);B=A.update(encrypted)+A.finalize();B=unpad(B);return B
def pkcs7_envelope_encrypt(plaintext:bytes,recipient_pubkey:RSAPublicKey)->bytes:H='content_type';G='version';B='parameters';A='algorithm';C=os.urandom(32);D=os.urandom(16);I=recipient_pubkey.encrypt(C,padding.OAEP(mgf=padding.MGF1(algorithm=hashes.SHA256()),algorithm=hashes.SHA256(),label=_A));J=Cipher(algorithms.AES(C),modes.CBC(D),backend=default_backend());E=J.encryptor();F=sym_padding.PKCS7(algorithms.AES.block_size).padder();K=F.update(plaintext)+F.finalize();L=E.update(K)+E.finalize();M=cms.RecipientIdentifier(name='issuer_and_serial_number',value=cms.IssuerAndSerialNumber({'issuer':asn1_x509.Name.build({'common_name':'recipient'}),'serial_number':1}));N=cms.KeyEncryptionAlgorithm({A:OID_RSAES_OAEP,B:algos.RSAESOAEPParams({'hash_algorithm':algos.DigestAlgorithm({A:OID_SHA256}),'mask_gen_algorithm':algos.MaskGenAlgorithm({A:OID_MGF1,B:algos.DigestAlgorithm({A:OID_SHA256})})})});O=cms.KeyTransRecipientInfo({G:'v0','rid':M,'key_encryption_algorithm':N,'encrypted_key':I});P=cms.EncryptionAlgorithm({A:OID_AES256_CBC,B:core.OctetString(D)});Q=cms.EncryptedContentInfo({H:'data','content_encryption_algorithm':P,'encrypted_content':L});R=cms.EnvelopedData({G:'v0','recipient_infos':[O],'encrypted_content_info':Q});S=cms.ContentInfo({H:'enveloped_data','content':R});return S.dump()