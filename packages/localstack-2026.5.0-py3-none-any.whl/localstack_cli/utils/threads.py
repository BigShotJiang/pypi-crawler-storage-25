_C='name'
_B=False
_A=None
import concurrent.futures,inspect,logging,threading,traceback
from collections.abc import Callable
from concurrent.futures import Future
from multiprocessing.dummy import Pool
LOG=logging.getLogger(__name__)
TMP_THREADS=[]
TMP_PROCESSES=[]
counter_lock=threading.Lock()
counter=0
class FuncThread(threading.Thread):
	def __init__(A,func,params=_A,quiet=_B,on_stop:Callable[['FuncThread'],_A]=_A,name:str|_A=_A,daemon=True):
		B=daemon;global counter;global counter_lock
		if name:
			with counter_lock:counter+=1;C=counter
			threading.Thread.__init__(A,name=f"{name}-functhread{C}",daemon=B)
		else:threading.Thread.__init__(A,daemon=B)
		A.params=params;A.func=func;A.quiet=quiet;A.result_future=Future();A._stop_event=threading.Event();A.on_stop=on_stop
	def run(A):
		F='_thread';C=_A
		try:
			E={};D=inspect.getfullargspec(A.func)
			if D.varkw or F in(D.args or[])+(D.kwonlyargs or[]):E[F]=A
			C=A.func(A.params,**E)
		except Exception as B:
			A.result_future.set_exception(B);C=B
			if not A.quiet:LOG.info('Thread run method %s(%s) failed: %s %s',A.func,A.params,B,traceback.format_exc())
		finally:
			try:A.result_future.set_result(C)
			except concurrent.futures.InvalidStateError as B:LOG.debug(B)
	@property
	def running(self):return not self._stop_event.is_set()
	def stop(A,quiet:bool=_B)->_A:
		A._stop_event.set()
		if A.on_stop:
			try:A.on_stop(A)
			except Exception as B:LOG.warning('error while calling on_stop callback: %s',B)
def start_thread(method,*D,**A)->FuncThread:
	C=method;E=A.pop('_shutdown_hook',True)
	if not A.get(_C):LOG.debug('start_thread called without providing a custom name')
	A.setdefault(_C,C.__name__);B=FuncThread(C,*D,**A);B.start()
	if E:TMP_THREADS.append(B)
	return B
def start_worker_thread(method,*B,**A):A.setdefault(_C,'start_worker_thread');return start_thread(method,*B,_shutdown_hook=_B,**A)
def cleanup_threads_and_processes(quiet=True):
	from localstack_cli.utils.run import kill_process_tree as E
	for A in TMP_THREADS:
		if A:
			try:
				if hasattr(A,'shutdown'):A.shutdown();continue
				if hasattr(A,'kill'):A.kill();continue
				A.stop(quiet=quiet)
			except Exception as B:
				LOG.debug('[shutdown] Error stopping thread %s: %s',A,B)
				if not A.daemon:LOG.warning('[shutdown] Non-daemon thread %s may block localstack shutdown',A)
	for C in TMP_PROCESSES:
		try:E(C.pid)
		except Exception as B:LOG.debug('[shutdown] Error cleaning up process tree %s: %s',C,B)
	try:
		import asyncio as F
		for D in F.all_tasks():
			try:D.cancel()
			except Exception as B:LOG.debug('[shutdown] Error cancelling asyncio task %s: %s',D,B)
	except Exception:pass
	LOG.debug('[shutdown] Done cleaning up threads / processes / tasks');TMP_THREADS.clear();TMP_PROCESSES.clear()
def parallelize(func:Callable,arr:list,size:int=_A):
	A=size
	if not A:A=len(arr)
	if A<=0:return
	with Pool(A)as B:return B.map(func,arr)