_A=None
import logging,os,re
from functools import lru_cache
from localstack_cli import config,constants
from localstack_cli.utils.container_utils.container_client import ContainerException
from localstack_cli.utils.docker_utils import DOCKER_CLIENT
from localstack_cli.utils.net import get_docker_host_from_container
LOG=logging.getLogger(__name__)
@lru_cache
def get_main_container_network()->str|_A:
	if config.MAIN_DOCKER_NETWORK:
		if config.is_in_docker:
			A=DOCKER_CLIENT.get_networks(get_main_container_name())
			if config.MAIN_DOCKER_NETWORK not in A:LOG.warning("The specified 'MAIN_DOCKER_NETWORK' is not connected to the LocalStack container! Falling back to %s",A[0]);return A[0]
		return config.MAIN_DOCKER_NETWORK
	B='bridge'
	if config.is_in_docker:
		try:A=DOCKER_CLIENT.get_networks(get_main_container_name());B=A[0]
		except Exception as C:D=get_main_container_name();LOG.info('Unable to get network name of main container "%s", falling back to "bridge": %s',D,C)
	LOG.info('Determined main container network: %s',B);return B
@lru_cache
def get_endpoint_for_network(network:str|_A=_A)->str:
	D=network;E=get_main_container_name();D=D or get_main_container_network();A=_A
	try:
		if config.is_in_docker:A=DOCKER_CLIENT.get_container_ipv4_for_network(container_name_or_id=E,container_network=D)
		elif config.is_in_linux:A=DOCKER_CLIENT.inspect_network(D)['IPAM']['Config'][0]['Gateway']
		else:
			F=constants.DOCKER_IMAGE_NAME_PRO;B,H=DOCKER_CLIENT.run_container(F,remove=True,entrypoint='',command=['ping','-c','1','host.docker.internal']);B=B.decode(config.DEFAULT_ENCODING)if isinstance(B,bytes)else B;C=re.match('PING[^\\(]+\\(([^\\)]+)\\).*',B,re.MULTILINE|re.DOTALL);C=C and C.group(1)
			if C:A=C
		LOG.info('Determined main container target IP: %s',A)
	except Exception as G:LOG.info('Unable to get main container IP address: %s',G)
	if not A:return get_docker_host_from_container()
	return A
def get_main_container_ip():A=get_main_container_name();return DOCKER_CLIENT.get_container_ip(A)
def get_main_container_id():
	A=get_main_container_name()
	try:return DOCKER_CLIENT.get_container_id(A)
	except ContainerException:return
@lru_cache
def get_main_container_name():
	A=os.environ.get('HOSTNAME')
	if A:
		try:return DOCKER_CLIENT.get_container_name(A)
		except ContainerException:return config.MAIN_CONTAINER_NAME
	else:return config.MAIN_CONTAINER_NAME