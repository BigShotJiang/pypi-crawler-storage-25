from __future__ import annotations

from datetime import UTC
from datetime import datetime

from pydantic import BaseModel
from pydantic import Field
from pydantic import field_validator

from maicoin.ws.side import Side


# https://maicoin.github.io/max-websocket-docs/#/private_channels?id=trade-response
class Trade(BaseModel):
    id: int | None = Field(default=None, validation_alias="i")
    market: str | None = Field(default=None, validation_alias="M")
    side: Side | None = Field(default=None, validation_alias="sd")
    price: str = Field(validation_alias="p")
    volume: str = Field(validation_alias="v")
    fee: str | None = Field(default=None, validation_alias="f")
    fee_currency: str | None = Field(default=None, validation_alias="fc")
    fee_discounted: bool | None = Field(default=None, validation_alias="fd")
    funds: str | None = Field(default=None, validation_alias="fn")
    created_at: datetime = Field(validation_alias="T")
    updated_at: datetime | None = Field(default=None, validation_alias="TU")
    maker: bool | None = Field(default=None, validation_alias="m")
    order_id: int | None = Field(default=None, validation_alias="oi")
    trend: str | None = Field(default=None, validation_alias="tr")

    @field_validator("created_at", "updated_at", mode="before")
    @classmethod
    def convert_datetime(cls, t: int | None) -> datetime | None:
        if t is None:
            return None
        return datetime.fromtimestamp(int(t) / 1000, tz=UTC)
