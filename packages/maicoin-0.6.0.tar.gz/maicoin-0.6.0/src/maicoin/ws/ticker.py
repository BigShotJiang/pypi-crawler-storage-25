from __future__ import annotations

from pydantic import BaseModel
from pydantic import Field


# https://maicoin.github.io/max-websocket-docs/#/public_ticker?id=success-response
class Ticker(BaseModel):
    market: str = Field(validation_alias="M")
    open: str = Field(validation_alias="O")
    high: str = Field(validation_alias="H")
    low: str = Field(validation_alias="L")
    close: str = Field(validation_alias="C")
    volume: str = Field(validation_alias="v")
    volume_in_btc: str = Field(validation_alias="V")
