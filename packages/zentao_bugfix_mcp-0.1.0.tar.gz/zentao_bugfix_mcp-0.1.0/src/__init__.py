"""禅道 Bug MCP 服务：查询待处理缺陷与详情（安装包名 zentao_bugfix_mcp）。"""
