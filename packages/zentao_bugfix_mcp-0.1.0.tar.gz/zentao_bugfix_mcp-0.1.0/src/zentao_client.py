"""
禅道 REST API v1（/api.php/v1）。

职责摘要：
  - 账号密码换 Token，内存缓存；401 清 Token 重试一次，仍 401 则 ZentaoAuthError
  - Bug 详情、产品下 Bug 分页；get_my_bugs 优先 browseType 服务端过滤，失败则全量分页
  - _normalize_bug：人员/状态字段兼容 dict 与 str；步骤正文去 HTML，步骤内链接与 files 供详情展示
  - fetch_bug_image_attachments：带 Token 将步骤/ files 中的图片拉取到内存，供 MCP 以 Image 块返回 Cursor

参考：https://www.zentao.net/book/api/664.html
"""

from __future__ import annotations

import html
import logging
import re
from collections.abc import Callable
from typing import Any, NotRequired, TypedDict
from urllib.parse import urlparse, urljoin

import requests

log = logging.getLogger(__name__)


class BugInfo(TypedDict):
    """与禅道原始 JSON 解耦后的统一结构（供 MCP 展示与写 meta.json）。"""

    id: int
    title: str
    severity: int | None
    pri: int | None
    type: str
    status: str
    steps: str
    openedBy: str
    assignedTo: str
    openedDate: str
    deadline: str
    keywords: str
    product: NotRequired[Any]
    module: NotRequired[Any]
    project: NotRequired[Any]
    attachments: NotRequired[str]


class ZentaoAuthError(RuntimeError):
    """刷新 Token 后仍 401（密码错、会话被服务端踢等）。"""


class ZentaoClient:
    """禅道 v1 Bug 查询封装。"""

    def __init__(
        self,
        base_url: str,
        account: str,
        password: str,
        *,
        token_timeout: float | None = None,
        request_timeout: float | None = None,
        on_auth_failure: Callable[[], None] | None = None,
    ):
        """超时与 401 回调可由 config 注入；on_auth_failure 用于剔除外层缓存。"""
        self.base_url = base_url.rstrip("/")
        self.account = account
        self.password = password
        self._token_timeout = float(token_timeout) if token_timeout is not None else 15.0
        self._request_timeout = float(request_timeout) if request_timeout is not None else 30.0
        self._on_auth_failure = on_auth_failure
        self._token: str | None = None
        self._session = requests.Session()

    # --- Token ---

    def _get_token(self) -> str:
        """POST /tokens，成功则缓存至 self._token。"""
        if self._token:
            return self._token
        url = f"{self.base_url}/api.php/v1/tokens"
        log.info("正在获取禅道 Token: %s", url)
        resp = self._session.post(
            url,
            json={"account": self.account, "password": self.password},
            timeout=self._token_timeout,
        )
        resp.raise_for_status()
        self._token = resp.json()["token"]
        log.info("Token 获取成功")
        return self._token

    def _request(self, method: str, path: str, **kwargs: Any) -> dict:
        """统一加 Token 头；401 清缓存重试一轮；非 2xx 抛 HTTPError（带响应片段）。"""
        url = f"{self.base_url}/api.php/v1{path}"
        headers = dict(kwargs.pop("headers", {}))
        headers["Token"] = self._get_token()
        log.debug("%s %s", method, url)
        resp = self._session.request(
            method, url, headers=headers, timeout=self._request_timeout, **kwargs
        )
        if resp.status_code == 401:
            log.warning("Token 已过期，正在重新获取")
            self._token = None
            headers["Token"] = self._get_token()
            resp = self._session.request(
                method, url, headers=headers, timeout=self._request_timeout, **kwargs
            )
        if resp.status_code == 401:
            if self._on_auth_failure:
                self._on_auth_failure()
            snippet = (resp.text or "")[:500]
            raise ZentaoAuthError(
                f"禅道 API 认证失败（HTTP 401），请检查账号密码或 Token。响应片段: {snippet!r}"
            )
        if not resp.ok:
            snippet = (resp.text or "")[:500]
            raise requests.HTTPError(
                f"{resp.status_code} {resp.reason} for {url}: {snippet!r}",
                response=resp,
            )
        return resp.json()

    # --- 公开 API ---

    def get_bug(self, bug_id: int) -> BugInfo:
        """GET /bugs/{id}，返回标准化 BugInfo。"""
        data = self._request("GET", f"/bugs/{bug_id}")
        return self._normalize_bug(data)

    def fetch_bug_image_attachments(
        self,
        bug_id: int,
        *,
        max_bytes: int = 8 * 1024 * 1024,
    ) -> list[tuple[bytes, str, str]]:
        """带 Token 拉取 Bug 步骤与 files 中的图片到内存。

        返回 [(原始字节, FastMCP Image format 子类型如 png/jpeg, 来源 URL), ...]；
        非图片、HTML 登录页、超大或失败项会跳过并记日志。
        """
        data = self._request("GET", f"/bugs/{bug_id}")
        urls = self._collect_bug_attachment_urls(data)
        out: list[tuple[bytes, str, str]] = []
        for u in urls:
            try:
                self._assert_same_origin(u)
                raw, fmt = self._download_image_attachment(u, max_bytes)
                out.append((raw, fmt, u))
            except Exception as e:  # noqa: BLE001 — 逐项跳过
                log.warning("拉取图片附件失败，已跳过 %s: %s", u, e)
        return out

    def get_product_bugs(
        self,
        product_id: int,
        page: int = 1,
        limit: int = 100,
        *,
        browse_type: str | None = None,
    ) -> dict:
        """单页；browse_type 如 assignedtome / assigntome，视禅道版本而定。"""
        params: dict[str, Any] = {"page": page, "limit": limit}
        if browse_type:
            params["browseType"] = browse_type
        return self._request("GET", f"/products/{product_id}/bugs", params=params)

    def _iter_product_bug_pages(
        self,
        product_id: int,
        *,
        browse_type: str | None,
        limit: int = 100,
    ):
        """按 total 与累计条数终止，避免死循环。"""
        page = 1
        seen = 0
        while True:
            result = self.get_product_bugs(
                product_id, page=page, limit=limit, browse_type=browse_type
            )
            bugs = result.get("bugs", [])
            yield from bugs
            seen += len(bugs)
            total = int(result.get("total", 0))
            if not bugs or seen >= total:
                break
            page += 1

    def get_my_bugs(self, product_id: int) -> list[BugInfo]:
        """先探测 browseType 是否可用；列表侧再筛 assignedTo==本账号且 status==active。"""
        browse_type: str | None = None
        last_exc: Exception | None = None
        for bt in ("assignedtome", "assigntome"):
            try:
                self.get_product_bugs(product_id, page=1, limit=1, browse_type=bt)
                browse_type = bt
                log.info("使用 browseType=%s 拉取「指派给我」Bug 列表", bt)
                break
            except Exception as e:  # noqa: BLE001 — 不同版本参数兼容
                last_exc = e
                log.warning("browseType=%s 不可用，尝试下一策略: %s", bt, e)
        if browse_type is None and last_exc is not None:
            log.warning("browseType 均不可用，回退全量分页: %s", last_exc)
        my_bugs: list[BugInfo] = []
        for bug in self._iter_product_bug_pages(
            product_id, browse_type=browse_type, limit=100
        ):
            assigned = bug.get("assignedTo")
            if not assigned:
                continue
            acct = assigned.get("account", "") if isinstance(assigned, dict) else str(assigned)
            status = bug.get("status", "")
            if isinstance(status, dict):
                status = status.get("code", "")
            if acct == self.account and status == "active":
                my_bugs.append(self._normalize_bug(bug))
        log.info("属于 %s 的活跃 Bug: %d 条", self.account, len(my_bugs))
        return my_bugs

    # --- 标准化 ---

    def _normalize_bug(self, bug: dict) -> BugInfo:
        """禅道单条 Bug JSON → BugInfo（含 steps 清洗、步骤内外链与 files 附件说明）。"""
        bid = bug.get("id")
        raw_steps = bug.get("steps", "") or ""
        steps_text, embedded = self._format_steps_and_embedded_urls(raw_steps)
        files_note = self._format_bug_files(bug.get("files"))
        attachments = "\n\n".join(p for p in (embedded, files_note) if p).strip()
        out: BugInfo = {
            "id": int(bid) if bid is not None else 0,
            "title": bug.get("title", "") or "",
            "severity": bug.get("severity"),
            "pri": bug.get("pri"),
            "type": bug.get("type", "") or "",
            "status": self._extract_status(bug.get("status", "")),
            "steps": steps_text,
            "openedBy": self._extract_person_name(bug.get("openedBy")),
            "assignedTo": self._extract_person_name(bug.get("assignedTo")),
            "openedDate": bug.get("openedDate", "") or "",
            "deadline": bug.get("deadline", "") or "",
            "keywords": bug.get("keywords", "") or "",
            "product": bug.get("product"),
            "module": bug.get("module"),
            "project": bug.get("project"),
        }
        if attachments:
            out["attachments"] = attachments
        return out

    @staticmethod
    def _extract_person_name(value: Any) -> str:
        """openedBy / assignedTo 可能是 {realname, account} 或字符串。"""
        if not value:
            return ""
        if isinstance(value, dict):
            return value.get("realname") or value.get("account", "")
        return str(value)

    @staticmethod
    def _extract_status(value: Any) -> str:
        """status 可能是 {code, name} 或字符串。"""
        if not value:
            return ""
        if isinstance(value, dict):
            return value.get("name") or value.get("code", "")
        return str(value)

    @staticmethod
    def _clean_html(raw: str) -> str:
        """steps 常见为 HTML：br/p 换行，剥标签，html.unescape，压空行。"""
        if not raw:
            return ""
        text = raw.replace("&nbsp;", " ")
        text = re.sub(r"<br\s*/?>", "\n", text, flags=re.IGNORECASE)
        text = re.sub(r"</p>", "\n", text, flags=re.IGNORECASE)
        text = re.sub(r"<[^>]+>", "", text)
        text = html.unescape(text)
        lines = [line.strip() for line in text.splitlines()]
        return "\n".join(line for line in lines if line)

    _IMG_SRC = re.compile(r'<img[^>]+src\s*=\s*["\']([^"\']+)["\']', re.IGNORECASE)
    _A_HREF = re.compile(r'<a[^>]+href\s*=\s*["\']([^"\']+)["\']', re.IGNORECASE)
    _LINK_EXT = re.compile(r"\.(png|jpe?g|gif|webp|bmp|pdf|zip)(\?|#|$)", re.IGNORECASE)

    @classmethod
    def _extract_embedded_urls_from_html(cls, raw: str) -> list[str]:
        """步骤里嵌套的截图/附件链接：<img src> 与常见下载类 <a href>。"""
        if not raw:
            return []
        seen: set[str] = set()
        ordered: list[str] = []
        for m in cls._IMG_SRC.finditer(raw):
            u = (m.group(1) or "").strip()
            if u and u not in seen:
                seen.add(u)
                ordered.append(html.unescape(u))
        for m in cls._A_HREF.finditer(raw):
            u = (m.group(1) or "").strip()
            if not u or u in seen:
                continue
            if cls._LINK_EXT.search(u) or "file-read" in u or "file-download" in u or "/file/" in u:
                seen.add(u)
                ordered.append(html.unescape(u))
        return ordered

    def _format_steps_and_embedded_urls(self, raw: str) -> tuple[str, str]:
        """(纯文本步骤, 外链说明块)；外链块为空串表示无。"""
        text = self._clean_html(raw)
        urls = self._extract_embedded_urls_from_html(raw)
        if not urls:
            return text, ""
        lines = "\n".join(f"- {u}" for u in urls)
        block = f"[步骤中的图片/链接]\n{lines}"
        return text, block

    def _format_bug_files(self, files: Any) -> str:
        """GET /bugs/:id 的 files 数组 → 可读列表；字段随禅道版本略有差异。"""
        if not isinstance(files, list) or not files:
            return ""
        lines: list[str] = []
        for item in files:
            if not isinstance(item, dict):
                continue
            title = (item.get("title") or item.get("name") or "附件").strip() or "附件"
            web = item.get("webPath") or item.get("url") or item.get("downloadUrl")
            fid = item.get("id")
            if web:
                lines.append(f"- {title}: {html.unescape(str(web))}")
            elif fid is not None:
                guess = f"{self.base_url}/file-read-{fid}"
                lines.append(f"- {title}: {guess}（禅道下载路径因版本可能不同，打不开请登录 Web 查看）")
            else:
                pn = item.get("pathname") or ""
                lines.append(f"- {title}" + (f" ({pn})" if pn else ""))
        if not lines:
            return ""
        return "[禅道附件]\n" + "\n".join(lines)

    # --- 附件 URL 收集与带 Token 下载（供 MCP 返回 Image 给 Cursor） ---

    def _absolute_url(self, url: str) -> str:
        u = (url or "").strip()
        if u.startswith(("http://", "https://")):
            return html.unescape(u)
        base = self.base_url if self.base_url.endswith("/") else self.base_url + "/"
        return html.unescape(urljoin(base, u.lstrip("/")))

    def _assert_same_origin(self, abs_url: str) -> None:
        p = urlparse(abs_url)
        b = urlparse(self.base_url)
        if p.scheme not in ("http", "https"):
            raise ValueError(f"不支持的 URL 协议: {abs_url!r}")
        if p.netloc and p.netloc != b.netloc:
            raise ValueError(f"拒绝访问非禅道同源 URL: {abs_url!r}")

    def _collect_bug_attachment_urls(self, bug: dict) -> list[str]:
        seen: set[str] = set()
        ordered: list[str] = []
        raw_steps = bug.get("steps") or ""
        if isinstance(raw_steps, str):
            for u in self._extract_embedded_urls_from_html(raw_steps):
                au = self._absolute_url(u)
                if au not in seen:
                    seen.add(au)
                    ordered.append(au)
        files = bug.get("files")
        if isinstance(files, list):
            for item in files:
                if not isinstance(item, dict):
                    continue
                web = item.get("webPath") or item.get("url") or item.get("downloadUrl")
                fid = item.get("id")
                if web:
                    au = self._absolute_url(str(web))
                elif fid is not None:
                    au = f"{self.base_url}/file-read-{fid}"
                else:
                    continue
                if au not in seen:
                    seen.add(au)
                    ordered.append(au)
        return ordered

    @staticmethod
    def _looks_like_html(content: bytes) -> bool:
        head = content[:800].lower()
        if b"<html" in head or b"<!doctype html" in head:
            return True
        if b"login" in head and b"<form" in head:
            return True
        return False

    @staticmethod
    def _sniff_image_subtype(head: bytes) -> str | None:
        if len(head) >= 3 and head.startswith(b"\xff\xd8\xff"):
            return "jpeg"
        if head.startswith(b"\x89PNG\r\n\x1a\n"):
            return "png"
        if head.startswith(b"GIF87a") or head.startswith(b"GIF89a"):
            return "gif"
        if head.startswith(b"RIFF") and b"WEBP" in head[:16]:
            return "webp"
        if head.startswith(b"BM"):
            return "bmp"
        return None

    @staticmethod
    def _subtype_from_content_type(ct: str) -> str | None:
        ct = (ct or "").split(";")[0].strip().lower()
        if not ct.startswith("image/"):
            return None
        sub = ct.removeprefix("image/").strip()
        if sub in ("jpeg", "jpg", "pjpeg"):
            return "jpeg"
        if sub in ("png", "gif", "webp", "bmp"):
            return sub
        if "svg" in sub:
            return "svg+xml"
        return None

    def _download_image_attachment(self, abs_url: str, max_bytes: int) -> tuple[bytes, str]:
        headers = {"Token": self._get_token()}
        resp = self._session.get(
            abs_url, headers=headers, timeout=self._request_timeout, stream=True
        )
        if resp.status_code == 401:
            self._token = None
            headers["Token"] = self._get_token()
            resp = self._session.get(
                abs_url, headers=headers, timeout=self._request_timeout, stream=True
            )
        if resp.status_code == 401:
            if self._on_auth_failure:
                self._on_auth_failure()
            raise ZentaoAuthError("拉取附件时禅道认证失败（401）")
        try:
            if not resp.ok:
                raise requests.HTTPError(f"HTTP {resp.status_code}", response=resp)
            ct = resp.headers.get("Content-Type", "")
            chunks: list[bytes] = []
            total = 0
            first = True
            for chunk in resp.iter_content(chunk_size=65536):
                if not chunk:
                    continue
                if first:
                    first = False
                    if self._looks_like_html(chunk):
                        raise ValueError("响应为 HTML（Token 可能无权访问该 file-read URL）")
                total += len(chunk)
                if total > max_bytes:
                    raise ValueError(f"超过单附件上限 {max_bytes} bytes")
                chunks.append(chunk)
            data = b"".join(chunks)
            if not data:
                raise ValueError("空响应体")
            subtype = self._subtype_from_content_type(ct) or self._sniff_image_subtype(
                data[:32]
            )
            if not subtype:
                raise ValueError("非图片内容（Content-Type 与魔数均不匹配）")
            if subtype == "svg+xml":
                raise ValueError("暂不支持 SVG 作为视觉附件")
            return data, subtype
        finally:
            resp.close()
