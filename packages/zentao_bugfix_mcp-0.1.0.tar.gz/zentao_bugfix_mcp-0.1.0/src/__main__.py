"""启动入口：stdio（本地）或 streamable-http（服务端），由 MCP_TRANSPORT 控制。"""

from __future__ import annotations

import logging
import os
import sys
from pathlib import Path

# 直接 `python src/__main__.py` 时，sys.path 只有 src/，无法解析包名 `src`；pip / `python -m src` 不受影响
if not __package__:
    _root = Path(__file__).resolve().parent.parent
    if str(_root) not in sys.path:
        sys.path.insert(0, str(_root))

from starlette.middleware import Middleware

from src.auth import BearerTokenMiddleware, ZentaoConfigMiddleware
from src.mcp_app import mcp

# 配置Python日志系统
# - level: 设置日志级别为INFO，仅记录INFO及以上级别的日志
# - format: 定义日志输出格式，包含时间戳、记录器名、级别和消息
# - stream: 将日志输出到标准错误流(stderr)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
    stream=sys.stderr,
)



def main() -> None:
    """根据 MCP_TRANSPORT 启动 stdio 或 HTTP；HTTP 模式下挂载认证与禅道头中间件。"""
    transport = os.getenv("MCP_TRANSPORT", "streamable-http")

    if transport == "stdio":
        mcp.run(transport="stdio")
        return

    host = os.getenv("MCP_HOST", "0.0.0.0")
    port = int(os.getenv("MCP_PORT", "8000"))
    token = os.getenv("MCP_AUTH_TOKEN", "")

    # 有 token 时先 Bearer，再注入禅道头（顺序影响 scope 进入顺序，此处与语义一致即可）
    middlewares: list[Middleware] = []
    if token:
        middlewares.append(Middleware(BearerTokenMiddleware, token=token))
    middlewares.append(Middleware(ZentaoConfigMiddleware))

    mcp.run(
        transport="streamable-http",
        host=host,
        port=port,
        middleware=middlewares,
    )


if __name__ == "__main__":
    main()
