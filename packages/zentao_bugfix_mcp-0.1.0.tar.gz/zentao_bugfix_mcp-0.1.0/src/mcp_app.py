"""
MCP 层：FastMCP 实例、探活路由、禅道相关 Tool。

依赖：config（客户端）、zentao_client / auth。修复方案与代码在 Cursor 对话中完成。
"""

from __future__ import annotations

import logging

from fastmcp import FastMCP
from fastmcp.tools.base import ToolResult
from fastmcp.utilities.types import Image
from mcp.types import TextContent
from starlette.requests import Request
from starlette.responses import JSONResponse

from src.config import (
    ZENTAO_ATTACHMENT_MAX_BYTES,
    get_product_id,
    get_zentao,
    redact_message,
    resolve_zentao_config,
)

log = logging.getLogger(__name__)

mcp = FastMCP(name="Zentao Bug Fix Assistant")


@mcp.custom_route("/health", methods=["GET"])
async def _health_check(_request: Request) -> JSONResponse:
    """Docker HEALTHCHECK / 负载均衡探活，不走 MCP 协议。"""
    return JSONResponse({"status": "ok"})


# ---------------------------------------------------------------------------
# 列表展示：严重程度、优先级 → 中文
# ---------------------------------------------------------------------------
_SEVERITY = {1: "致命", 2: "严重", 3: "一般", 4: "轻微"}
_PRI = {1: "紧急", 2: "高", 3: "中", 4: "低"}


def _sev(n: int | None) -> str:
    """禅道 severity 数值 → 中文展示。"""
    return _SEVERITY.get(n or 0, str(n))


def _pri(n: int | None) -> str:
    """禅道 pri 数值 → 中文展示。"""
    return _PRI.get(n or 0, str(n))


def _bug_detail_markdown(b: dict) -> str:
    """与 get_bug_detail 相同的 Markdown 正文（不含外层包装）。"""
    att = b.get("attachments")
    att_block = f"\n\n### 附件与步骤内链接\n{att}\n" if att else ""
    steps_body = (b.get("steps") or "").strip()
    if not steps_body:
        steps_body = "见下方「附件与步骤内链接」" if att else "未提供"
    return f"""## Bug #{b['id']}：{b['title']}

| 属性 | 值 |
|------|-----|
| 严重程度 | {_sev(b['severity'])} |
| 优先级 | {_pri(b['pri'])} |
| 类型 | {b['type']} |
| 状态 | {b['status']} |
| 创建人 | {b['openedBy']} |
| 指派给 | {b['assignedTo']} |
| 创建时间 | {b['openedDate']} |
| 截止日期 | {b['deadline'] or '无'} |
| 关键字 | {b['keywords'] or '无'} |

### 重现步骤
{steps_body}{att_block}"""


@mcp.tool
def list_my_bugs(product_id: int | None = None) -> str:
    """查询禅道（Zentao）中指派给我的待处理 Bug / 缺陷列表。

    用户说「我的 Bug」「待处理缺陷」「禅道 Bug 列表」时调用。product_id 不传则用默认产品。
    """
    pid = get_product_id(product_id)
    if not pid:
        return "错误：未指定 product_id，也未在配置中设置默认产品 ID"
    try:
        bugs = get_zentao().get_my_bugs(pid)
    except Exception as e:
        log.exception("获取 Bug 列表失败")
        return f"获取 Bug 列表失败：{redact_message(str(e))}"
    if not bugs:
        _, account, _, _ = resolve_zentao_config()
        return f"产品 {pid} 中没有指派给 {account} 的活跃 Bug。"
    lines = [f"共 {len(bugs)} 个待处理 Bug：\n"]
    for b in bugs:
        lines.append(f"- **#{b['id']}** [{_sev(b['severity'])}][{_pri(b['pri'])}] {b['title']}")
    return "\n".join(lines)


@mcp.tool
def get_bug_detail(bug_id: int) -> str:
    """获取指定 Bug 完整详情（步骤、严重程度、优先级等）。

    用户提到 Bug 编号或要看缺陷详情时调用。
    """
    try:
        b = get_zentao().get_bug(bug_id)
    except Exception as e:
        log.exception("获取 Bug #%d 详情失败", bug_id)
        return f"获取 Bug #{bug_id} 详情失败：{redact_message(str(e))}"
    return _bug_detail_markdown(b)


@mcp.tool
def get_bug_detail_with_images(bug_id: int) -> ToolResult:
    """获取 Bug 文字详情，并把步骤/附件中的图片通过 MCP 图像块返回，供 Cursor 结合截图分析与处理。

    用户说「根据附件分析」「结合截图看这个 Bug」「看图分析」时优先调用本工具而非仅 get_bug_detail。
    """
    client = get_zentao()
    try:
        b = client.get_bug(bug_id)
    except Exception as e:
        log.exception("获取 Bug #%d 详情失败", bug_id)
        return ToolResult(
            content=[
                TextContent(
                    type="text",
                    text=f"获取 Bug #{bug_id} 详情失败：{redact_message(str(e))}",
                )
            ]
        )
    text = _bug_detail_markdown(b)
    try:
        images = client.fetch_bug_image_attachments(
            bug_id, max_bytes=ZENTAO_ATTACHMENT_MAX_BYTES
        )
    except Exception as e:
        log.exception("拉取 Bug #%d 图片附件失败", bug_id)
        return ToolResult(
            content=[
                TextContent(
                    type="text",
                    text=f"{text}\n\n（拉取图片失败：{redact_message(str(e))}）",
                )
            ]
        )

    blocks: list = [
        TextContent(
            type="text",
            text=text
            + "\n\n---\n以下为由禅道 Token 拉取的图片附件，请结合上文分析：\n",
        )
    ]
    if not images:
        blocks.append(
            TextContent(
                type="text",
                text="（未成功拉取到图片：可能仅有链接、非图片类型，或 file-read 返回登录页/HTML。）",
            )
        )
    else:
        for i, (raw, fmt, url) in enumerate(images, start=1):
            blocks.append(
                TextContent(type="text", text=f"**附件图 {i}** `{url}`\n")
            )
            blocks.append(Image(data=raw, format=fmt))
    return ToolResult(content=blocks)
