"""
HTTP ASGI 中间件（不用 BaseHTTPMiddleware，减少 Starlette 额外包装）。

- BearerTokenMiddleware：校验 MCP_AUTH_TOKEN
- ZentaoConfigMiddleware：把 X-Zentao-* 写入 config 里的 ContextVar
"""

from __future__ import annotations

import logging

from starlette.responses import JSONResponse
from starlette.types import ASGIApp, Receive, Scope, Send

from src.config import (
    zentao_account_var,
    zentao_password_var,
    zentao_product_id_var,
    zentao_url_var,
)

log = logging.getLogger(__name__)


def _header_value(scope: Scope, name: str) -> str | None:
    """ASGI headers 为 list[(bytes, bytes)]，大小写不敏感。"""
    want = name.lower().encode("latin-1")
    for key, value in scope.get("headers") or []:
        if key.lower() == want:
            return value.decode("latin-1")
    return None


class BearerTokenMiddleware:
    """Authorization 须严格等于 ``Bearer <MCP_AUTH_TOKEN>``。"""

    def __init__(self, app: ASGIApp, token: str):
        """``token`` 为裸令牌，内部会拼成 ``Bearer …``。"""
        self.app = app
        self.expected = f"Bearer {token}"

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        """非 http 直接透传；http 校验失败返回 401 JSON。"""
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return
        auth_header = _header_value(scope, "authorization") or ""
        if auth_header != self.expected:
            client = scope.get("client")
            host = client[0] if client else "unknown"
            path = scope.get("path", "")
            log.warning("认证失败: %s %s (来源: %s)", scope.get("method"), path, host)
            response = JSONResponse({"error": "Unauthorized"}, status_code=401)
            await response(scope, receive, send)
            return
        await self.app(scope, receive, send)


class ZentaoConfigMiddleware:
    """可选请求头（未传则用 .env）：URL / 账号 / 密码 / 产品 ID。密码须走 HTTPS。"""

    def __init__(self, app: ASGIApp):
        """仅保存内层 ASGI app。"""
        self.app = app

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        """在 http 请求上把 X-Zentao-* 写入 ContextVar，再进入下游。"""
        if scope["type"] == "http":
            if v := _header_value(scope, "x-zentao-url"):
                zentao_url_var.set(v)
            if v := _header_value(scope, "x-zentao-account"):
                zentao_account_var.set(v)
            if v := _header_value(scope, "x-zentao-password"):
                zentao_password_var.set(v)
            if v := _header_value(scope, "x-zentao-product-id"):
                try:
                    zentao_product_id_var.set(int(v))
                except ValueError:
                    pass
        await self.app(scope, receive, send)
