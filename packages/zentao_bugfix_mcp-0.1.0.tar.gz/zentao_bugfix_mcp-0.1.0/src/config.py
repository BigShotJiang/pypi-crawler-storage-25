"""
配置与依赖注入入口。

- .env 与服务端默认值
- HTTP 请求内通过 ContextVar 覆盖的禅道参数（由 auth 中间件写入）
- ZentaoClient 单例缓存（按 url+账号+密码指纹）
"""

from __future__ import annotations

import hashlib
import logging
import os
import re
from contextvars import ContextVar

from dotenv import load_dotenv

from src.zentao_client import ZentaoClient

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# 请求级 ContextVar：中间件 set，resolve_zentao_config / get_zentao 读
# product_id 未传请求头时为 None → 回落 .env（与显式传 0 区分）
# ---------------------------------------------------------------------------
zentao_url_var: ContextVar[str] = ContextVar("zentao_url", default="")
zentao_account_var: ContextVar[str] = ContextVar("zentao_account", default="")
zentao_password_var: ContextVar[str] = ContextVar("zentao_password", default="")
zentao_product_id_var: ContextVar[int | None] = ContextVar("zentao_product_id", default=None)

load_dotenv()

ZENTAO_URL = os.getenv("ZENTAO_URL", "")
ZENTAO_ACCOUNT = os.getenv("ZENTAO_ACCOUNT", "")
ZENTAO_PASSWORD = os.getenv("ZENTAO_PASSWORD", "")
ZENTAO_PRODUCT_ID = int(os.getenv("ZENTAO_PRODUCT_ID", "0") or "0")
ZENTAO_TOKEN_TIMEOUT = float(os.getenv("ZENTAO_TOKEN_TIMEOUT", "15") or "15")
ZENTAO_REQUEST_TIMEOUT = float(os.getenv("ZENTAO_REQUEST_TIMEOUT", "30") or "30")
# get_bug_detail_with_images 单张附件最大字节（默认 8MB，防内存爆）
ZENTAO_ATTACHMENT_MAX_BYTES = int(os.getenv("ZENTAO_ATTACHMENT_MAX_BYTES", "8388608") or "8388608")

_zentao_cache: dict[tuple[str, str, str], ZentaoClient] = {}


def _password_fingerprint(password: str) -> str:
    """缓存 key 组成部分：密码变更后自动换新客户端。"""
    return hashlib.sha256(password.encode("utf-8")).hexdigest()


def resolve_zentao_config() -> tuple[str, str, str, int]:
    """合并 ContextVar 与 .env，返回 (url, account, password, product_id)。"""
    url = zentao_url_var.get("") or ZENTAO_URL
    account = zentao_account_var.get("") or ZENTAO_ACCOUNT
    password = zentao_password_var.get("") or ZENTAO_PASSWORD
    header_pid = zentao_product_id_var.get(None)
    product_id = ZENTAO_PRODUCT_ID if header_pid is None else header_pid
    return url, account, password, product_id


def get_zentao() -> ZentaoClient:
    """按 (url, account, 密码指纹) 缓存；401 持久失败时 on_auth_failure 剔除缓存。"""
    url, account, password, _ = resolve_zentao_config()
    if not url or not account:
        raise RuntimeError(
            "禅道配置不完整，请在 mcp.json headers 中设置 X-Zentao-URL / X-Zentao-Account / X-Zentao-Password，"
            "或在服务端 .env 中配置 ZENTAO_URL / ZENTAO_ACCOUNT / ZENTAO_PASSWORD"
        )
    fp = _password_fingerprint(password)
    key = (url, account, fp)
    if key not in _zentao_cache:

        def invalidate() -> None:
            """供 ZentaoClient 在仍 401 时回调，避免坏客户端留在缓存里。"""
            _zentao_cache.pop(key, None)
            log.warning("已清除禅道客户端缓存（认证失败）: url=%s account=%s", url, account)

        _zentao_cache[key] = ZentaoClient(
            url,
            account,
            password,
            token_timeout=ZENTAO_TOKEN_TIMEOUT,
            request_timeout=ZENTAO_REQUEST_TIMEOUT,
            on_auth_failure=invalidate,
        )
    return _zentao_cache[key]


def get_product_id(override: int | None = None) -> int:
    """工具参数 > ContextVar/头 > .env；override is not None 时含 0。"""
    if override is not None:
        return override
    _, _, _, pid = resolve_zentao_config()
    return pid


# ---------------------------------------------------------------------------
# 工具返回给前端的错误串脱敏（非日志系统，仅字符串替换）
# ---------------------------------------------------------------------------
_SENSITIVE_PATTERNS = (
    (re.compile(r"(?i)(password|passwd|pwd|token|secret|api[_-]?key)\s*[:=]\s*\S+"), r"\1=***"),
    (re.compile(r"(?i)(bearer\s+)[\w\-._~+/]+=*", re.I), r"\1***"),
)


def redact_message(text: str) -> str:
    """弱化异常信息里形似密钥的片段。"""
    if not text:
        return text
    out = text
    for pattern, repl in _SENSITIVE_PATTERNS:
        out = pattern.sub(repl, out)
    return out
