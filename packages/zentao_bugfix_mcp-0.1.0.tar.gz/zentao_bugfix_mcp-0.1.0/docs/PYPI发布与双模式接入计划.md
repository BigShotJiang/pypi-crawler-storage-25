# PyPI 发布与双模式接入 — 执行计划

本文说明：**如何把 `zentao-bugfix-mcp` 发布到 PyPI**，并**同时保留**（1）服务器 **HTTP 远程**接入、（2）本机 **`uvx` + stdio** 接入。代码入口已具备，以下为发布与协作落地步骤。

---

## 一、两种接入方式对照

| 维度 | 方式 A：远程 HTTP（Docker / 裸机） | 方式 B：`uvx` + PyPI（stdio） |
|------|-----------------------------------|------------------------------|
| MCP 进程跑在哪 | 公司服务器 | 每个开发者本机子进程 |
| Cursor 配置 | `url` + `headers` | `command` + `args` + `env` |
| 禅道账号 | 经 `X-Zentao-*` 请求头（可每人不同） | 经环境变量 `ZENTAO_*`（每人本机配置） |
| 传输 | `streamable-http` | **必须** `MCP_TRANSPORT=stdio` |
| 适用场景 | 统一运维、内网 HTTPS、集中认证 | 不搭服务器、或用 PyPI 固定版本 |

**代码层面**：`src/__main__.py` 已按 `MCP_TRANSPORT` 分支；**无需为「双模式」再拆两套代码**，只需文档与示例配置齐全。

---

## 二、发布到 PyPI 前（仓库内检查清单）

1. **元数据**（`pyproject.toml`）
   - `[project]` 的 `name` 在 PyPI 上唯一：`zentao-bugfix-mcp`（若被占用需改名）。
   - `version`：每次发版递增（如 `0.1.0` → `0.1.1`）。
   - `authors`、`[project.urls]` 的 `Homepage` / `Repository`：改为真实组织/仓库地址。
2. **许可证**
   - 仓库根目录 `LICENSE`（MIT）已与 `license = "MIT"` 一致。
3. **构建校验**（本地）
   ```bash
   pip install build twine
   python -m build
   pip install -U twine packaging
   twine check dist/*
   ```
   若 `twine check` 报 `license-expression` / `license-file` 无法识别，多为 **twine 过旧**，升级后再执行即可。
4. **冒烟**（本地）
   ```bash
   pip install dist/zentao_bugfix_mcp-*.whl
   MCP_TRANSPORT=stdio ZENTAO_URL=... ZENTAO_ACCOUNT=... ZENTAO_PASSWORD=... zentao-bugfix-mcp
   ```
5. **账号**
   - 在 [pypi.org](https://pypi.org) 注册；推荐启用 **API token**，用 `twine upload` 或 **GitHub Actions**（`PYPI_API_TOKEN` secret）上传。

---

## 三、发布命令（首次与后续）

```bash
python -m build
twine upload dist/*
```

（或使用 trusted publishing / CI，按团队规范。）

发布后验证：

```bash
uvx zentao-bugfix-mcp --help
# 若入口无 --help，可仅验证 uvx 能安装并找到控制台脚本
```

Cursor 中配置见 `docs/cursor-mcp.uvx.example.json`。

---

## 四、Cursor 侧配置（当前阶段：优先 command / uvx）

1. 复制 `docs/cursor-mcp.uvx.example.json` 片段到 `~/.cursor/mcp.json` 或项目 `.cursor/mcp.json`。
2. 填写 `env` 中 `ZENTAO_URL`、`ZENTAO_ACCOUNT`、`ZENTAO_PASSWORD`、`ZENTAO_PRODUCT_ID`（**勿提交真实密码到 Git**）。
3. 确认 **`MCP_TRANSPORT=stdio`**。
4. 可选：固定版本 `"args": ["zentao-bugfix-mcp==0.1.0"]`（按实际上传版本改）。

远程 HTTP 方式仍可用：复制 `docs/cursor-mcp.http.example.json`，与 `uvx` 可并存为两个 server 名称（如 `zentao-bugfix-local` / `zentao-bugfix-remote`）。

---

## 五、与 Docker 部署的关系

- **服务器**继续：`docker compose up`，`MCP_TRANSPORT=streamable-http`，客户端用 **url + headers**。
- **PyPI + uvx** 不替代 Docker：是给「本机 stdio」用的另一条分发渠道。
- `.dockerignore` 已允许将 `LICENSE` 纳入构建上下文（若将来 Dockerfile 需要 `COPY LICENSE`）。

---

## 六、可选后续增强（非必须）

- GitHub Actions：`on: tag: v*` 时自动 `build` + `twine upload`。
- `CHANGELOG.md` 记录版本说明。
- PyPI 项目描述可在 README 首段写清「双模式」链接到本文档。

---

## 七、文档与示例文件索引

| 文件 | 说明 |
|------|------|
| `docs/cursor-mcp.uvx.example.json` | PyPI + `uvx` + stdio 示例 |
| `docs/cursor-mcp.http.example.json` | 远程 HTTPS + headers 示例 |
| `README.md` | 总览与团队接入（两种方式） |

完成以上步骤后，**代码无需为「双模式」再做结构性修改**；发版时主要维护 **version** 与 **README/示例** 即可。
