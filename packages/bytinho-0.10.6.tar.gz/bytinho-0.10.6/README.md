<div align="center">

<img src="https://bytinho.com/logo.png" width="120" alt="bytinho">

# bytinho

**A pixel pet that lives in your terminal and grows with every commit you ship.**

[![PyPI](https://img.shields.io/pypi/v/bytinho.svg)](https://pypi.org/project/bytinho/)
[![License: MIT](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)
[![Status: beta](https://img.shields.io/badge/status-beta-orange.svg)](#beta)
[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org)

![demo](demo.gif)

🇧🇷 [Leia em português](README.pt-BR.md)

</div>

---

## Why?

Look — your terminal already knows when you worked. Your `git log` is a more honest journal than any productivity app.
The problem isn't tracking; it's that nothing in your dev loop ever **says hi back**.

Bytinho is a tiny pixel pet that lives between your `git push` and your next coffee. It hatches from your first commit, grows from the diffs you actually ship, and naps when you do. No login. No email. No code ever leaves your machine.

It's not productivity software. It's not a dashboard. It's the closest thing to a Tamagotchi a CLI can have — *except it evolves from the work you actually ship*.

> *Your terminal already knows. The pet just reminds you.*

---

## Install

```bash
pipx install bytinho
cd your-repo
bytinho install-hook
bytinho
```

That's it. Make a commit. Watch your pet grow.

---

## What it does

The MVP is intentionally tiny. Five things, done well:

- 🥚 **Hatches on your first commit.** Egg → 8 evolution stages, 5 visual variants each.
- 📈 **Levels up with real commits.** XP scales with diff effort, not just commit count.
- 🔥 **Daily streak** with XP bonus up to **+100%** after 10 days shipping in a row.
- 💬 **Has personality.** Derived from your anonymous UUID — same dev, same pet, forever.
- 🏆 **Weekly leaderboard** at `bytinho ranking` and a public profile card at [`bytinho.com/u/<nick>`](https://bytinho.com/u/andryus).

That's the soft-launch surface. Anything bigger (`commit-guard`, `diff-review`, `standup`, custom skins, teams) is parked in the [roadmap](ROADMAP.md) until v0.10 finds its people.

---

## Commands

```bash
bytinho                    # open the TUI — see your pet, talk to it
bytinho install-hook       # add the post-commit hook to current repo
bytinho talk "hi"          # quick one-liner chat without opening the TUI
bytinho ranking            # top devs this week
bytinho streak             # consecutive days shipping
bytinho doctor             # check server, hook, python, uuid
bytinho nick <name>        # claim a public nickname
bytinho version
```

Run `bytinho --help` for the full list. Most flags follow the principle: *if you have to read docs, we failed*.

---

## Screenshot

A glimpse of the TUI:

```
╭──────────────────────────────────────────────────────────╮
│  @andryus · Floquinho · spark · lv 2                     │
│                                                          │
│     ▄▄▄▄▄         you shipped 3 commits today.          │
│    ▄█▀▀▀█▄        almost there — keep going 👀          │
│    █ ◉ ◉ █                                              │
│    ▀█▀▀▀█▀                                              │
│     ▀   ▀                                                │
│  spark ██████░░ 420/1000   🔥 3d                         │
│                                                          │
│  type to chat  ·  F1 stats  F2 ranking  F3 achievements  │
│                                                  Esc quit│
╰──────────────────────────────────────────────────────────╯
```

*Rendered with Rich + prompt_toolkit. Footer is live.*

---

## Roadmap

This is **v0.10 — soft launch**. The shape of v0.11 depends on what you tell us.

- **Now** — pet, hook, ranking, achievements, talk
- **Next (v0.11)** — Windows native, chat global v2, visual stability tests
- **Later** — private teams, GitHub PR integration, custom skins, plugin API

Full picture: [**ROADMAP.md**](ROADMAP.md). The fastest way to move something up is a thumbs-up on a [discussion](https://github.com/andryus/bytinho/discussions).

---

## Privacy

- Identity is an **anonymous UUID** generated locally on first run. No email, no account, no password.
- Optional, opt-in telemetry sends **only**: event name, CLI version, OS family. **Never** code, commit messages, diffs, file names, or paths.
- Inspect or wipe with `bytinho telemetry` (use `--forget` to delete everything from the server) or set `BYTINHO_NO_TELEMETRY=1` to disable locally.
- The git hook is non-destructive — `bytinho install-hook` merges with your existing `post-commit`, never overwrites it.

If any of this ever changes, it'll be in the changelog before it's in the code. Promise.

---

## Built with

Python 3.10+, [Typer](https://typer.tiangolo.com), [Rich](https://github.com/Textualize/rich), [prompt_toolkit](https://python-prompt-toolkit.readthedocs.io), [FastAPI](https://fastapi.tiangolo.com) on the server side.

MIT licensed. Made with too much café by [@andryus](https://github.com/andryus).
PRs welcome — small fixes get merged fast.

<a name="beta"></a>
> ⚠️ **Heads up — this is early.**
> Bytinho is in soft launch. Things will move. Footers will reflow. Your pet might take a nap it shouldn't.
> Open an [issue](https://github.com/andryus/bytinho/issues), send a friend, complain on a [discussion](https://github.com/andryus/bytinho/discussions) — your feedback literally shapes v0.11.
>
> *Got feedback? Every good idea starts with `git commit -m "idea"`.*
