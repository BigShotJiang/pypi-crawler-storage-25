"""Helpers do lado cliente relacionados ao dialogue (sem deps de server)."""
from __future__ import annotations

import random

IDLE_WHISPERS: dict[str, list[str]] = {
    "fofo":       ["tô aqui caso precise 💜", "respira fundo, viu fofuxo 🫶",
                   "cê tá indo bem, eu tô vendo 🌸"],
    "sarcástico": ["ainda olhando o stack trace? 🥱",
                   "esse bug não vai se resolver sozinho ☕",
                   "que silêncio suspeito 😏"],
    "motivador":  ["1 commit. só 1. BORA 🔥", "respira. retoma. ⚡",
                   "tá quase. eu sei que tá. 🚀"],
    "calmo":      ["respira 🍃", "uma coisa de cada vez",
                   "o vento já tá passando ☁️"],
    "agitado":    ["EITAA cadê ⚡", "kkk olha esse silêncio 🎉",
                   "alooo dev 🌀"],
    "caótico":    ["o void* está observando 🐈",
                   "pão de queijo resolve 🍞",
                   "git é só um diário fingindo 🌀"],
    "tímido":    ["...ei. tô aqui caso precise 🌷",
                   "pode falar, tô ouvindo com cuidado ✨",
                   "sem pressa, tá bem? 🤍"],
    "dramático": ["SILENÇIO SUSPEITO!! você tá bem?? 😱",
                   "o terminal parou... será o fim? 💫",
                   "VOLTE!! o código precisa de você!! 🎭"],
    "estudioso":  ["curiosidade: o que você tá estudando hoje? 🔍",
                   "esse silêncio é de leitura ou de debug? 📚",
                   "tem algo interessante pra compartilhar? 💡"],
    "gamer":      ["jogador inativo detectado 🎮",
                   "a quest não vai se completar sozinha ⚔️",
                   "ei, ainda tem save aqui 🏆"],
    "filosófico": ["o cursor piscando é um koan 🌌",
                   "o silêncio entre commits também é código 💭",
                   "o que te mantém aqui? 🔮"],
    "minimalista": [".", "aqui.", "fala."],
}


def idle_whisper_for(persona: str) -> str:
    bag = IDLE_WHISPERS.get(persona) or IDLE_WHISPERS["fofo"]
    return random.choice(bag)
