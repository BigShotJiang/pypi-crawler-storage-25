"""Preferências locais do usuário (skin, etc.).

Persistidas em DATA_DIR/prefs.json. Ficam só no PC, nunca sobem pro server.
"""
import json

from .config import PREFS_FILE

# Paleta de cores válidas (nomes Rich). Default = cyan.
SKINS: tuple[str, ...] = (
    "cyan", "green", "magenta", "red", "yellow", "blue", "white",
    "bright_cyan", "bright_green", "bright_magenta",
    "bright_red", "bright_yellow", "bright_blue",
)

DEFAULT_SKIN = "cyan"


def _load() -> dict:
    if not PREFS_FILE.exists():
        return {}
    try:
        return json.loads(PREFS_FILE.read_text(encoding="utf-8"))
    except (ValueError, OSError):
        return {}


def _save(data: dict) -> None:
    try:
        PREFS_FILE.write_text(json.dumps(data, indent=2), encoding="utf-8")
    except OSError:
        pass


def get_skin() -> str | None:
    """Retorna a skin escolhida, ou None se nunca foi setada."""
    return _load().get("skin")


def set_skin(name: str) -> tuple[bool, str]:
    """Salva a skin. Retorna (ok, mensagem)."""
    name = name.strip().lower()
    if name not in SKINS:
        return False, f"skin inválida. válidas: {', '.join(SKINS)}"
    data = _load()
    data["skin"] = name
    _save(data)
    return True, name


def reset_skin() -> None:
    data = _load()
    data.pop("skin", None)
    _save(data)


# ---------- catchphrase ---------------------------------------------------

CATCHPHRASE_MAX_LEN = 30


def get_catchphrase() -> str | None:
    """Retorna o bordão local do user, ou None se nunca foi setado."""
    v = _load().get("catchphrase")
    return v if isinstance(v, str) and v else None


def set_catchphrase(phrase: str) -> tuple[bool, str]:
    """Salva um bordão local. Retorna (ok, mensagem ou erro)."""
    phrase = (phrase or "").strip()
    if not phrase:
        return False, "bordão vazio"
    if len(phrase) > CATCHPHRASE_MAX_LEN:
        return False, f"máx {CATCHPHRASE_MAX_LEN} chars (tem {len(phrase)})"
    if "\n" in phrase or "\r" in phrase:
        return False, "sem quebras de linha"
    data = _load()
    data["catchphrase"] = phrase
    _save(data)
    return True, phrase


def reset_catchphrase() -> None:
    data = _load()
    data.pop("catchphrase", None)
    _save(data)


# ---------- persona override ---------------------------------------------

PERSONAS: tuple[str, ...] = (
    "minimalista", "calmo", "estudioso", "filosófico",
    "fofo", "tímido", "motivador", "sarcástico",
    "gamer", "agitado", "dramático", "caótico",
)


def get_persona() -> str | None:
    """Retorna persona escolhida pelo user, ou None pra usar a do servidor."""
    v = _load().get("persona")
    return v if isinstance(v, str) and v in PERSONAS else None


def get_effective_persona() -> str:
    """Persona efetiva: override do user > default minimalista.

    Garante que devs novos sempre comecem com tom sóbrio,
    independente do que o servidor sortear.
    """
    return get_persona() or "minimalista"


# Persona auto-evolui com o stage do pet. Tom mais simples cedo, mais
# sofisticado conforme o pet cresce. Pode ser sobrescrito com `bytinho persona`.
_STAGE_PERSONA: dict[str, str] = {
    "egg":       "tímido",
    "hatchling": "fofo",
    "junior":    "calmo",
    "pleno":     "estudioso",
    "senior":    "estudioso",
    "staff":     "filosófico",
    "tenx":      "filosófico",
    "legend":    "filosófico",
}


def persona_for_progress(pet: dict | None) -> str:
    """Retorna persona derivada do stage. Usa override do user se houver."""
    override = get_persona()
    if override:
        return override
    stage = (pet or {}).get("stage", "egg")
    return _STAGE_PERSONA.get(stage, "calmo")


def set_persona(name: str) -> tuple[bool, str]:
    """Salva persona override local. Retorna (ok, mensagem)."""
    name = name.strip().lower()
    if name not in PERSONAS:
        return False, f"persona inválida. válidas: {', '.join(PERSONAS)}"
    data = _load()
    data["persona"] = name
    _save(data)
    return True, name


def reset_persona() -> None:
    data = _load()
    data.pop("persona", None)
    _save(data)


# ---------- onboarding state ---------------------------------------------

def has_seen_tour() -> bool:
    return bool(_load().get("seen_tour"))


def mark_tour_seen() -> None:
    data = _load()
    data["seen_tour"] = True
    _save(data)
